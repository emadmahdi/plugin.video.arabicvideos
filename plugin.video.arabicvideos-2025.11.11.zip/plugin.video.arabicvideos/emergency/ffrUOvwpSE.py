# -*- coding: utf-8 -*-
import sys as tJKIOTASR7WyBUPeihuE05w
IIbSWsjGA8zw = tJKIOTASR7WyBUPeihuE05w.version_info [0] == 2
cc8rAVjkB9JCPzgLX4pv = 2048
gn8Tcumd3XpH = 7
def MMNlG1mpsuB86TFHzdtWw (i0keDnghdQLBjopaS):
	global q9XlCok5vFBuJ0tQUEy
	yCLPKT9sAWbd0n6zUjuoOhH2SDQ = ord (i0keDnghdQLBjopaS [-1])
	ydkCRbeBV6FW81OIriYoaQ5mD3q7fx = i0keDnghdQLBjopaS [:-1]
	WrRVm0TY2csqaMBvPNZjUi9 = yCLPKT9sAWbd0n6zUjuoOhH2SDQ % len (ydkCRbeBV6FW81OIriYoaQ5mD3q7fx)
	kf8v9PzUtuRWM7ErHKnY3V6w = ydkCRbeBV6FW81OIriYoaQ5mD3q7fx [:WrRVm0TY2csqaMBvPNZjUi9] + ydkCRbeBV6FW81OIriYoaQ5mD3q7fx [WrRVm0TY2csqaMBvPNZjUi9:]
	if IIbSWsjGA8zw:
		iC5qgpYFLK40VuGRc = unicode () .join ([unichr (ord (NGwTcKOvVjsLRQgiCFWke9Xm45xqn) - cc8rAVjkB9JCPzgLX4pv - (FsHWJUiaxLk0RqvVMlQ + yCLPKT9sAWbd0n6zUjuoOhH2SDQ) % gn8Tcumd3XpH) for FsHWJUiaxLk0RqvVMlQ, NGwTcKOvVjsLRQgiCFWke9Xm45xqn in enumerate (kf8v9PzUtuRWM7ErHKnY3V6w)])
	else:
		iC5qgpYFLK40VuGRc = str () .join ([chr (ord (NGwTcKOvVjsLRQgiCFWke9Xm45xqn) - cc8rAVjkB9JCPzgLX4pv - (FsHWJUiaxLk0RqvVMlQ + yCLPKT9sAWbd0n6zUjuoOhH2SDQ) % gn8Tcumd3XpH) for FsHWJUiaxLk0RqvVMlQ, NGwTcKOvVjsLRQgiCFWke9Xm45xqn in enumerate (kf8v9PzUtuRWM7ErHKnY3V6w)])
	return eval (iC5qgpYFLK40VuGRc)
tyoQzeTiMuON6KbpZ2BIv,BmpZUuaRbDWj7XN,yki0jsJ8LRxu3dgoAp6DlNOaS=MMNlG1mpsuB86TFHzdtWw,MMNlG1mpsuB86TFHzdtWw,MMNlG1mpsuB86TFHzdtWw
sEuazdZckqD6w0JmIiX2p,jjuXCT05fhE24r8pyb,PDOw5YrslygcHCmRJ2i4vbGeu=yki0jsJ8LRxu3dgoAp6DlNOaS,BmpZUuaRbDWj7XN,tyoQzeTiMuON6KbpZ2BIv
VqDnxC7X1rZmLty36ATlRwdEgpfHe,Yny7dFHLOjal8NCWT6,TI7lv43rNSKHmoOtep=PDOw5YrslygcHCmRJ2i4vbGeu,jjuXCT05fhE24r8pyb,sEuazdZckqD6w0JmIiX2p
KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ,mmXevlsZVWyidN,GGEWLCrDMQBTgny1VNpUfzhjIl=TI7lv43rNSKHmoOtep,Yny7dFHLOjal8NCWT6,VqDnxC7X1rZmLty36ATlRwdEgpfHe
j6gdsu0TNlGtS,VRcWJbKt0TYpf3,AW8wJINVcyLuQblgv5Z2TqfpCR=GGEWLCrDMQBTgny1VNpUfzhjIl,mmXevlsZVWyidN,KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ
qmsxGkXU6MFe42,Tp2KdNj4mI3tOPhwLY,OEezhg1y9qVi8SMpbxHLsfCot5jm=AW8wJINVcyLuQblgv5Z2TqfpCR,VRcWJbKt0TYpf3,j6gdsu0TNlGtS
Q4VxvMIpc8uKf3hWOUHLz,YnoJNgtGbDPxCLw5Whj,LKDiRBbUaglnMr50YFcC9koeH4=OEezhg1y9qVi8SMpbxHLsfCot5jm,Tp2KdNj4mI3tOPhwLY,qmsxGkXU6MFe42
c6WqRVHofEONTwZ,ohFNypgbu34tC1U2J0AGdTz5PY8fxO,tlOMscopuefm=LKDiRBbUaglnMr50YFcC9koeH4,YnoJNgtGbDPxCLw5Whj,Q4VxvMIpc8uKf3hWOUHLz
h6RU3Z2sctolNwBV4Jgyu,zWoml9DLSkK,vnEBxuCTlGyP04gQeb9YLi1kt3D=tlOMscopuefm,ohFNypgbu34tC1U2J0AGdTz5PY8fxO,c6WqRVHofEONTwZ
n8vA4ENFj3guxpWZGdO1Qh,RR8TDYNFtWJMhbjIziexLvo,LjEJpaqPrKXTkbi1AvDd60WQzw=vnEBxuCTlGyP04gQeb9YLi1kt3D,zWoml9DLSkK,h6RU3Z2sctolNwBV4Jgyu
xhDSweOPasGZFjEXoCvf4d3Tzb1H,woz7WC1Yuj9IPDZSap6RNkLlGf,Mh0FRgW9Et3aBnCoHs=LjEJpaqPrKXTkbi1AvDd60WQzw,RR8TDYNFtWJMhbjIziexLvo,n8vA4ENFj3guxpWZGdO1Qh
import xbmc as K9KDIcFZYqNThjXA,xbmcgui as yN0To9ivcK6ExbHUZuFM,sys as tJKIOTASR7WyBUPeihuE05w,os as hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ,requests as uIkoJHcqX6tlYFPBZzjVSxGMAKv5bf,re as NVR34ucn8ZTDxwHYsdBL,xbmcvfs as a8VbYziv3WZQGXMAeCp,base64 as oFWsTzEkbqLhNUwIlma3QVHR259,time as LLfi1jqAO6IvCNhmGP3SQKyp
feCPBFLJcHr9yQl6dkj3S = PDOw5YrslygcHCmRJ2i4vbGeu(u"ࠫࠬࠀ")
def hhmrscJlKGa8iBX(request):
	bbjoHzEqtaPnAWXTic = c6WqRVHofEONTwZ(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==tlOMscopuefm(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): K9KDIcFZYqNThjXA.executebuiltin(xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+bbjoHzEqtaPnAWXTic+AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࠨࠫࠪࠄ"))
	elif request==qmsxGkXU6MFe42(u"ࠩࡶࡸࡴࡶࠧࠅ"): K9KDIcFZYqNThjXA.executebuiltin(LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+bbjoHzEqtaPnAWXTic+xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"ࠫ࠮࠭ࠇ"))
	return
def UaN4SLPvgkYmEGw(kV5SKPGHDzfcLgOuZisX,qoisFZ9nzGpYWXyUk,C6m1NKPLu0kcqpM,c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,text):
	if not qoisFZ9nzGpYWXyUk: qoisFZ9nzGpYWXyUk = vnEBxuCTlGyP04gQeb9YLi1kt3D(u"้ࠬไศࠩࠈ")
	if not C6m1NKPLu0kcqpM: C6m1NKPLu0kcqpM = Tp2KdNj4mI3tOPhwLY(u"࠭ๆฺ็ࠪࠉ")
	if not c4cgmePql8AI0T6ZNFkoDQvXLWzJsU: c4cgmePql8AI0T6ZNFkoDQvXLWzJsU = LKDiRBbUaglnMr50YFcC9koeH4(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if gcOnMviEPaQKV7Bh: toHRX9wsSeykvAYTz = yN0To9ivcK6ExbHUZuFM.Dialog().yesno(c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,text,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,qoisFZ9nzGpYWXyUk,C6m1NKPLu0kcqpM)
	else: toHRX9wsSeykvAYTz = yN0To9ivcK6ExbHUZuFM.Dialog().yesno(c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,text,qoisFZ9nzGpYWXyUk,C6m1NKPLu0kcqpM)
	return toHRX9wsSeykvAYTz
def mHFPwE0eoBr(kV5SKPGHDzfcLgOuZisX,iOwZ1xngvqEjFI02TcDo,c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,text):
	if not c4cgmePql8AI0T6ZNFkoDQvXLWzJsU: c4cgmePql8AI0T6ZNFkoDQvXLWzJsU = RR8TDYNFtWJMhbjIziexLvo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return yN0To9ivcK6ExbHUZuFM.Dialog().ok(c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,text)
def A5AT8gl0Fp3stPXx(c4cgmePql8AI0T6ZNFkoDQvXLWzJsU=j6gdsu0TNlGtS(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),tF9XfsvhqUegyVkRz2pWInAL=feCPBFLJcHr9yQl6dkj3S):
	dqgBkNVp8JerLWOya = yN0To9ivcK6ExbHUZuFM.Dialog().input(c4cgmePql8AI0T6ZNFkoDQvXLWzJsU,tF9XfsvhqUegyVkRz2pWInAL,type=yN0To9ivcK6ExbHUZuFM.INPUT_ALPHANUM)
	dqgBkNVp8JerLWOya = dqgBkNVp8JerLWOya.strip(LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࠪࠤࠬࠍ")).replace(OEezhg1y9qVi8SMpbxHLsfCot5jm(u"ࠫࠥࠦࠠࠡࠩࠎ"),c6WqRVHofEONTwZ(u"ࠬࠦࠧࠏ")).replace(LKDiRBbUaglnMr50YFcC9koeH4(u"࠭ࠠࠡࠢࠪࠐ"),ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"ࠧࠡࠩࠑ")).replace(LKDiRBbUaglnMr50YFcC9koeH4(u"ࠨࠢࠣࠫࠒ"),RR8TDYNFtWJMhbjIziexLvo(u"ࠩࠣࠫࠓ"))
	return dqgBkNVp8JerLWOya
def awRjkvFmzGycVe2Nr8DhPXnW3ZxlC(kCB23F6Mfoap7lbwZgjRdsUO):
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,GGEWLCrDMQBTgny1VNpUfzhjIl(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if toHRX9wsSeykvAYTz!=tlOMscopuefm(u"࠱ࢫ"): return
	if not hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.exists(kCB23F6Mfoap7lbwZgjRdsUO):
		mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,vnEBxuCTlGyP04gQeb9YLi1kt3D(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = A5AT8gl0Fp3stPXx(h6RU3Z2sctolNwBV4Jgyu(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	HxsEW0j52Gg = K9KDIcFZYqNThjXA.getInfoLabel(YnoJNgtGbDPxCLw5Whj(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+sy5kXpH3qMo0mz28dtcgPDTlO+vnEBxuCTlGyP04gQeb9YLi1kt3D(u"ࠧࠪࠩ࠘"))
	file = open(kCB23F6Mfoap7lbwZgjRdsUO,sEuazdZckqD6w0JmIiX2p(u"ࠨࡴࡥࠫ࠙"))
	EAwf6QtoWryGL27Rpx8 = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.getsize(kCB23F6Mfoap7lbwZgjRdsUO)
	if EAwf6QtoWryGL27Rpx8>c6WqRVHofEONTwZ(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-c6WqRVHofEONTwZ(u"࠴࠲࠴࠴࠵࠶ࢬ"),hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(tyoQzeTiMuON6KbpZ2BIv(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	BB4UVxdqgKC2hczrQA8XR = NVR34ucn8ZTDxwHYsdBL.findall(h6RU3Z2sctolNwBV4Jgyu(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,NVR34ucn8ZTDxwHYsdBL.DOTALL)
	if not BB4UVxdqgKC2hczrQA8XR: BB4UVxdqgKC2hczrQA8XR = NVR34ucn8ZTDxwHYsdBL.findall(tlOMscopuefm(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,NVR34ucn8ZTDxwHYsdBL.DOTALL)
	if not BB4UVxdqgKC2hczrQA8XR: BB4UVxdqgKC2hczrQA8XR = NVR34ucn8ZTDxwHYsdBL.findall(xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,NVR34ucn8ZTDxwHYsdBL.DOTALL)
	BB4UVxdqgKC2hczrQA8XR = BB4UVxdqgKC2hczrQA8XR[vnEBxuCTlGyP04gQeb9YLi1kt3D(u"࠲ࢭ")] if BB4UVxdqgKC2hczrQA8XR else xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"࠭࠰࠱࠲࠳ࠫࠞ")
	BB4UVxdqgKC2hczrQA8XR = BB4UVxdqgKC2hczrQA8XR.split(yki0jsJ8LRxu3dgoAp6DlNOaS(u"ࠧ࡝ࡰࠪࠟ"),AW8wJINVcyLuQblgv5Z2TqfpCR(u"࠴ࢮ"))[LjEJpaqPrKXTkbi1AvDd60WQzw(u"࠴ࢯ")]
	if gcOnMviEPaQKV7Bh: BB4UVxdqgKC2hczrQA8XR = BB4UVxdqgKC2hczrQA8XR.encode(jjuXCT05fhE24r8pyb(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	SzV43HwxD9kyuIZBlRCgGr015 = jjuXCT05fhE24r8pyb(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+BB4UVxdqgKC2hczrQA8XR+RR8TDYNFtWJMhbjIziexLvo(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += sEuazdZckqD6w0JmIiX2p(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+BB4UVxdqgKC2hczrQA8XR+j6gdsu0TNlGtS(u"ࠬࠦ࠺ࠨࠤ")+Q4VxvMIpc8uKf3hWOUHLz(u"࠭࡜࡯ࠩࠥ")+PDOw5YrslygcHCmRJ2i4vbGeu(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+HxsEW0j52Gg+mmXevlsZVWyidN(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(YnoJNgtGbDPxCLw5Whj(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	b7bMXDrtQLj8SyzBEf2IHgNPlVW9i = oFWsTzEkbqLhNUwIlma3QVHR259.b64encode(data)
	rojwOcSTZf7MpENt4vzDdLHWK = {YnoJNgtGbDPxCLw5Whj(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):SzV43HwxD9kyuIZBlRCgGr015,j6gdsu0TNlGtS(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,TI7lv43rNSKHmoOtep(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):b7bMXDrtQLj8SyzBEf2IHgNPlVW9i}
	pxk0DMJ8b2XOlf = h6RU3Z2sctolNwBV4Jgyu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	wwGOMdjilXhe0VYqboKAQ = uIkoJHcqX6tlYFPBZzjVSxGMAKv5bf.request(LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࠧࡑࡑࡖࡘࠬ࠭"),pxk0DMJ8b2XOlf,data=rojwOcSTZf7MpENt4vzDdLHWK)
	if wwGOMdjilXhe0VYqboKAQ.status_code==tyoQzeTiMuON6KbpZ2BIv(u"࠷࠶࠰ࢰ"): mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def WZiLdzB83GFe1EXsxolPg2KHO06Q():
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,AW8wJINVcyLuQblgv5Z2TqfpCR(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if toHRX9wsSeykvAYTz!=ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"࠷ࢱ"): return
	B7kRwPOhcSqLJtxGoHNFm59C = kVDUxg3S4PHMup(z37KLHGjvVCJAbUPQNIr,Mh0FRgW9Et3aBnCoHs(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,vnEBxuCTlGyP04gQeb9YLi1kt3D(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def mmV7tMDSl0CGEksH4():
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,woz7WC1Yuj9IPDZSap6RNkLlGf(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if toHRX9wsSeykvAYTz!=BmpZUuaRbDWj7XN(u"࠱ࢲ"): return
	B7kRwPOhcSqLJtxGoHNFm59C = XS7i9lPrOa8p1Gte(RAZIMvP70XYdqr3Nusw4TQDktz8ca,AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࡕࡴࡸࡩࣈ"),AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࡕࡴࡸࡩࣈ"),Mh0FRgW9Et3aBnCoHs(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,BmpZUuaRbDWj7XN(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def kVDUxg3S4PHMup(gXWVjLbHCtimc7nvx1Js49R2ETZY6,F8vouPfwViXj7ZABtS):
	B7kRwPOhcSqLJtxGoHNFm59C = VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࡖࡵࡹࡪࣉ")
	if F8vouPfwViXj7ZABtS:
		toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,AW8wJINVcyLuQblgv5Z2TqfpCR(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if toHRX9wsSeykvAYTz!=Mh0FRgW9Et3aBnCoHs(u"࠲ࢳ"): return
	if hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.exists(gXWVjLbHCtimc7nvx1Js49R2ETZY6):
		try: hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.remove(gXWVjLbHCtimc7nvx1Js49R2ETZY6)
		except Exception as BiyrDf8vZK1S2VXM54Itc6aGU:
			B7kRwPOhcSqLJtxGoHNFm59C = ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"ࡉࡥࡱࡹࡥ࣊")
			if F8vouPfwViXj7ZABtS: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,str(BiyrDf8vZK1S2VXM54Itc6aGU))
	if F8vouPfwViXj7ZABtS:
		if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,zWoml9DLSkK(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,GGEWLCrDMQBTgny1VNpUfzhjIl(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return B7kRwPOhcSqLJtxGoHNFm59C
def XS7i9lPrOa8p1Gte(L0eI38VUKxYTaBhfG1,FlYVIj2zP6itcTD7O9gqKA3WJuS1,jP2BW4i85kxJAaHTVR,F8vouPfwViXj7ZABtS):
	B7kRwPOhcSqLJtxGoHNFm59C = tyoQzeTiMuON6KbpZ2BIv(u"ࡘࡷࡻࡥ࣋")
	if F8vouPfwViXj7ZABtS:
		toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,L0eI38VUKxYTaBhfG1+YnoJNgtGbDPxCLw5Whj(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if toHRX9wsSeykvAYTz!=YnoJNgtGbDPxCLw5Whj(u"࠳ࢴ"): return
	if hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.exists(L0eI38VUKxYTaBhfG1):
		for kyWYoTfHaR5cxe,OLQUnar7gYxB2A0pb,HH9tQyuA7SijoLnrf in hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.walk(L0eI38VUKxYTaBhfG1,topdown=Q4VxvMIpc8uKf3hWOUHLz(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for XkVtgpOsPv4K in HH9tQyuA7SijoLnrf:
				REFAGilf0UCopQJ8wdc3 = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(kyWYoTfHaR5cxe,XkVtgpOsPv4K)
				try: hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.remove(REFAGilf0UCopQJ8wdc3)
				except Exception as BiyrDf8vZK1S2VXM54Itc6aGU:
					B7kRwPOhcSqLJtxGoHNFm59C = Yny7dFHLOjal8NCWT6(u"ࡌࡡ࡭ࡵࡨ࣍")
					if F8vouPfwViXj7ZABtS: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,str(BiyrDf8vZK1S2VXM54Itc6aGU))
			if FlYVIj2zP6itcTD7O9gqKA3WJuS1:
				for q3D9cz7Ag0fkUIHKtNVS8xLMXrFEyb in OLQUnar7gYxB2A0pb:
					p0RenK9zsydPX7HkoZcqwArE2C = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(kyWYoTfHaR5cxe,q3D9cz7Ag0fkUIHKtNVS8xLMXrFEyb)
					try: hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.rmdir(p0RenK9zsydPX7HkoZcqwArE2C)
					except: pass
		if jP2BW4i85kxJAaHTVR:
			try: hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.rmdir(kyWYoTfHaR5cxe)
			except: pass
	if F8vouPfwViXj7ZABtS:
		if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,jjuXCT05fhE24r8pyb(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,Mh0FRgW9Et3aBnCoHs(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return B7kRwPOhcSqLJtxGoHNFm59C
def XvKCa5w6nHYWETP3LMoUj():
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if toHRX9wsSeykvAYTz!=GGEWLCrDMQBTgny1VNpUfzhjIl(u"࠴ࢵ"): return
	B7kRwPOhcSqLJtxGoHNFm59C = XS7i9lPrOa8p1Gte(mUPZV1dSNQK4TWC7RDk,LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࡕࡴࡸࡩ࣏"),TI7lv43rNSKHmoOtep(u"ࡆࡢ࡮ࡶࡩ࣎"),LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࡕࡴࡸࡩ࣏"))
	if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,qmsxGkXU6MFe42(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,AW8wJINVcyLuQblgv5Z2TqfpCR(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def WnIq0hjvD6QzOb():
	pxk0DMJ8b2XOlf = h6RU3Z2sctolNwBV4Jgyu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	wwGOMdjilXhe0VYqboKAQ = uIkoJHcqX6tlYFPBZzjVSxGMAKv5bf.request(KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠬࡍࡅࡕࠩࡀ"),pxk0DMJ8b2XOlf)
	OBm0IM4sPZErvF9dao15fwqG = wwGOMdjilXhe0VYqboKAQ.content
	OBm0IM4sPZErvF9dao15fwqG = OBm0IM4sPZErvF9dao15fwqG.decode(LjEJpaqPrKXTkbi1AvDd60WQzw(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	HH9tQyuA7SijoLnrf = NVR34ucn8ZTDxwHYsdBL.findall(sEuazdZckqD6w0JmIiX2p(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),OBm0IM4sPZErvF9dao15fwqG,NVR34ucn8ZTDxwHYsdBL.DOTALL)
	HH9tQyuA7SijoLnrf = sorted(HH9tQyuA7SijoLnrf,reverse=TI7lv43rNSKHmoOtep(u"ࡖࡵࡹࡪ࣐"))
	R3VNYOwEFcGI4Q8DCUos = yN0To9ivcK6ExbHUZuFM.Dialog().select(BmpZUuaRbDWj7XN(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),HH9tQyuA7SijoLnrf)
	if R3VNYOwEFcGI4Q8DCUos==-qmsxGkXU6MFe42(u"࠵ࢶ"): return
	filename = HH9tQyuA7SijoLnrf[R3VNYOwEFcGI4Q8DCUos]
	if gcOnMviEPaQKV7Bh: filename = filename.encode(tlOMscopuefm(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	XNdF60sUoYjKG82 = pxk0DMJ8b2XOlf.rsplit(h6RU3Z2sctolNwBV4Jgyu(u"ࠪ࠳ࠬࡅ"),tlOMscopuefm(u"࠶ࢷ"))[GGEWLCrDMQBTgny1VNpUfzhjIl(u"࠶ࢸ")]+RR8TDYNFtWJMhbjIziexLvo(u"ࠫ࠴࠭ࡆ")+tlOMscopuefm(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+Yny7dFHLOjal8NCWT6(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	B7kRwPOhcSqLJtxGoHNFm59C = VRcWJbKt0TYpf3(u"ࡉࡥࡱࡹࡥ࣑")
	wwGOMdjilXhe0VYqboKAQ = uIkoJHcqX6tlYFPBZzjVSxGMAKv5bf.request(KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠧࡈࡇࡗࠫࡉ"),XNdF60sUoYjKG82)
	if wwGOMdjilXhe0VYqboKAQ.status_code==qmsxGkXU6MFe42(u"࠲࠱࠲ࢹ"):
		qrUveBKMh8102HaEDb = wwGOMdjilXhe0VYqboKAQ.content
		import zipfile as VNL1pnwamJlKGjkOt4yv7EeM,io as BwpuhWzU26J
		Ud6cItk9bRAE85KJ = BwpuhWzU26J.BytesIO(qrUveBKMh8102HaEDb)
		XS7i9lPrOa8p1Gte(w4Wp1c5Usf6YuSqy,Tp2KdNj4mI3tOPhwLY(u"࡙ࡸࡵࡦ࣓"),Tp2KdNj4mI3tOPhwLY(u"࡙ࡸࡵࡦ࣓"),VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࡊࡦࡲࡳࡦ࣒"))
		fOwDUQ124PB = VNL1pnwamJlKGjkOt4yv7EeM.ZipFile(Ud6cItk9bRAE85KJ)
		fOwDUQ124PB.extractall(YKsnhvcfdTzFuL)
		LLfi1jqAO6IvCNhmGP3SQKyp.sleep(KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"࠲ࢺ"))
		K9KDIcFZYqNThjXA.executebuiltin(Yny7dFHLOjal8NCWT6(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		LLfi1jqAO6IvCNhmGP3SQKyp.sleep(AW8wJINVcyLuQblgv5Z2TqfpCR(u"࠳ࢻ"))
		b3CahJAUYKVsjN1gLZHoR7c = K9KDIcFZYqNThjXA.executeJSONRPC(AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+sy5kXpH3qMo0mz28dtcgPDTlO+n8vA4ENFj3guxpWZGdO1Qh(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if Yny7dFHLOjal8NCWT6(u"ࠫࡔࡑࠧࡍ") in b3CahJAUYKVsjN1gLZHoR7c: B7kRwPOhcSqLJtxGoHNFm59C = VRcWJbKt0TYpf3(u"࡚ࡲࡶࡧࣔ")
	if B7kRwPOhcSqLJtxGoHNFm59C:
		mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = Q4VxvMIpc8uKf3hWOUHLz(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		BBiS70H9dphgkuZEAVzOfRN(msg)
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,Tp2KdNj4mI3tOPhwLY(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def BBiS70H9dphgkuZEAVzOfRN(msg=PDOw5YrslygcHCmRJ2i4vbGeu(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,woz7WC1Yuj9IPDZSap6RNkLlGf(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),vnEBxuCTlGyP04gQeb9YLi1kt3D(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),feCPBFLJcHr9yQl6dkj3S,msg)
	if toHRX9wsSeykvAYTz==-h6RU3Z2sctolNwBV4Jgyu(u"࠴ࢼ"): return
	zKTQ47aRPo = LKDiRBbUaglnMr50YFcC9koeH4(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if toHRX9wsSeykvAYTz else VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	B7kRwPOhcSqLJtxGoHNFm59C = Yny7dFHLOjal8NCWT6(u"ࡆࡢ࡮ࡶࡩࣕ")
	abus2TFL3e0pg = yki0jsJ8LRxu3dgoAp6DlNOaS(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	KoYyGg8z709h3jUJBcx6NiD = n8vA4ENFj3guxpWZGdO1Qh(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if gcOnMviEPaQKV7Bh else YnoJNgtGbDPxCLw5Whj(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as z1ExbawdR98htP
		WZiu1C2MFgd5LfphT = z1ExbawdR98htP.connect(oFJGUyY1stLwrhbOqldBe)
		WZiu1C2MFgd5LfphT.text_factory = str
		PzQ6Nvb3lYp2OL74tafeu = WZiu1C2MFgd5LfphT.cursor()
		PzQ6Nvb3lYp2OL74tafeu.execute(KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+sy5kXpH3qMo0mz28dtcgPDTlO+c6WqRVHofEONTwZ(u"ࠪࠦࠥࡁ࡚ࠧ"))
		WUyaXxRoMvIjHf4ztQBlY3ek2AL5F = PzQ6Nvb3lYp2OL74tafeu.fetchall()
		if WUyaXxRoMvIjHf4ztQBlY3ek2AL5F and abus2TFL3e0pg not in str(WUyaXxRoMvIjHf4ztQBlY3ek2AL5F): PzQ6Nvb3lYp2OL74tafeu.execute(Q4VxvMIpc8uKf3hWOUHLz(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+abus2TFL3e0pg+woz7WC1Yuj9IPDZSap6RNkLlGf(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+sy5kXpH3qMo0mz28dtcgPDTlO+KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"࠭ࠢࠡ࠽ࠪ࡝"))
		PzQ6Nvb3lYp2OL74tafeu.execute(TI7lv43rNSKHmoOtep(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+KoYyGg8z709h3jUJBcx6NiD+c6WqRVHofEONTwZ(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+sy5kXpH3qMo0mz28dtcgPDTlO+zWoml9DLSkK(u"ࠩࠥࠤࡀ࠭ࡠ"))
		WUyaXxRoMvIjHf4ztQBlY3ek2AL5F = PzQ6Nvb3lYp2OL74tafeu.fetchall()
		gT5Fnv7d43wzGWbUYoM6KtmP8 = h6RU3Z2sctolNwBV4Jgyu(u"ࡈࡤࡰࡸ࡫ࣗ") if WUyaXxRoMvIjHf4ztQBlY3ek2AL5F else Tp2KdNj4mI3tOPhwLY(u"ࡕࡴࡸࡩࣖ")
		if not gT5Fnv7d43wzGWbUYoM6KtmP8 and LKDiRBbUaglnMr50YFcC9koeH4(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in zKTQ47aRPo: PzQ6Nvb3lYp2OL74tafeu.execute(VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+KoYyGg8z709h3jUJBcx6NiD+VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+sy5kXpH3qMo0mz28dtcgPDTlO+TI7lv43rNSKHmoOtep(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif gT5Fnv7d43wzGWbUYoM6KtmP8 and mmXevlsZVWyidN(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in zKTQ47aRPo:
			if gcOnMviEPaQKV7Bh: PzQ6Nvb3lYp2OL74tafeu.execute(c6WqRVHofEONTwZ(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+KoYyGg8z709h3jUJBcx6NiD+zWoml9DLSkK(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+sy5kXpH3qMo0mz28dtcgPDTlO+BmpZUuaRbDWj7XN(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: PzQ6Nvb3lYp2OL74tafeu.execute(n8vA4ENFj3guxpWZGdO1Qh(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+KoYyGg8z709h3jUJBcx6NiD+zWoml9DLSkK(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+sy5kXpH3qMo0mz28dtcgPDTlO+BmpZUuaRbDWj7XN(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		WZiu1C2MFgd5LfphT.commit()
		WZiu1C2MFgd5LfphT.close()
		B7kRwPOhcSqLJtxGoHNFm59C = PDOw5YrslygcHCmRJ2i4vbGeu(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if B7kRwPOhcSqLJtxGoHNFm59C:
		LLfi1jqAO6IvCNhmGP3SQKyp.sleep(j6gdsu0TNlGtS(u"࠵ࢽ"))
		K9KDIcFZYqNThjXA.executebuiltin(Tp2KdNj4mI3tOPhwLY(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		LLfi1jqAO6IvCNhmGP3SQKyp.sleep(OEezhg1y9qVi8SMpbxHLsfCot5jm(u"࠶ࢾ"))
		mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,GGEWLCrDMQBTgny1VNpUfzhjIl(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,LKDiRBbUaglnMr50YFcC9koeH4(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def ze36Kh8qH7V():
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,ohFNypgbu34tC1U2J0AGdTz5PY8fxO(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if toHRX9wsSeykvAYTz!=woz7WC1Yuj9IPDZSap6RNkLlGf(u"࠷ࢿ"): return
	ymXphHK8DOjYq1IxLoAZGU0 = XS7i9lPrOa8p1Gte(g6wcvEM8rDtipAPsujxh,n8vA4ENFj3guxpWZGdO1Qh(u"࡙ࡸࡵࡦࣚ"),AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࡊࡦࡲࡳࡦࣙ"),AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࡊࡦࡲࡳࡦࣙ"))
	zJ46hM9arBqDENdgwV = XS7i9lPrOa8p1Gte(DMo2Z6AXic9k,c6WqRVHofEONTwZ(u"ࡔࡳࡷࡨࣜ"),YnoJNgtGbDPxCLw5Whj(u"ࡌࡡ࡭ࡵࡨࣛ"),YnoJNgtGbDPxCLw5Whj(u"ࡌࡡ࡭ࡵࡨࣛ"))
	fL6ncZ0Mi3g = XS7i9lPrOa8p1Gte(UfP6nZEeOrJLH,YnoJNgtGbDPxCLw5Whj(u"ࡖࡵࡹࡪࣞ"),woz7WC1Yuj9IPDZSap6RNkLlGf(u"ࡇࡣ࡯ࡷࡪࣝ"),woz7WC1Yuj9IPDZSap6RNkLlGf(u"ࡇࡣ࡯ࡷࡪࣝ"))
	ZkIcPhXD4qseYE6umyJr = EQmdBzFSZIt4ryKo(YnoJNgtGbDPxCLw5Whj(u"ࡗࡶࡺ࡫ࣟ"))
	R0sa1tOV8c = hrbAdiI7vU()
	B7kRwPOhcSqLJtxGoHNFm59C = all([ymXphHK8DOjYq1IxLoAZGU0,zJ46hM9arBqDENdgwV,fL6ncZ0Mi3g,ZkIcPhXD4qseYE6umyJr,R0sa1tOV8c])
	if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,Tp2KdNj4mI3tOPhwLY(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,h6RU3Z2sctolNwBV4Jgyu(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def TWBLyQEqk15tG70fFImOHoxKPl():
	toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,yki0jsJ8LRxu3dgoAp6DlNOaS(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if toHRX9wsSeykvAYTz!=OEezhg1y9qVi8SMpbxHLsfCot5jm(u"࠱ࣀ"): return
	IfGnmEv0QSk34c = Mh0FRgW9Et3aBnCoHs(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	yZr95XvklVOIjK = qmsxGkXU6MFe42(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	gIACjsXiUh = c6WqRVHofEONTwZ(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	uWFAMEHgp0z = RR8TDYNFtWJMhbjIziexLvo(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	MsDNYICTjem8HG3nUqXwo70 = RR8TDYNFtWJMhbjIziexLvo(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	dykgDvpinS = Q4VxvMIpc8uKf3hWOUHLz(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	ymXphHK8DOjYq1IxLoAZGU0 = XS7i9lPrOa8p1Gte(IfGnmEv0QSk34c,tlOMscopuefm(u"࡙ࡸࡵࡦ࣡"),RR8TDYNFtWJMhbjIziexLvo(u"ࡊࡦࡲࡳࡦ࣠"),RR8TDYNFtWJMhbjIziexLvo(u"ࡊࡦࡲࡳࡦ࣠"))
	zJ46hM9arBqDENdgwV = XS7i9lPrOa8p1Gte(yZr95XvklVOIjK,h6RU3Z2sctolNwBV4Jgyu(u"ࡔࡳࡷࡨࣣ"),Tp2KdNj4mI3tOPhwLY(u"ࡌࡡ࡭ࡵࡨ࣢"),Tp2KdNj4mI3tOPhwLY(u"ࡌࡡ࡭ࡵࡨ࣢"))
	fL6ncZ0Mi3g = XS7i9lPrOa8p1Gte(gIACjsXiUh,xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"ࡖࡵࡹࡪࣥ"),n8vA4ENFj3guxpWZGdO1Qh(u"ࡇࡣ࡯ࡷࡪࣤ"),n8vA4ENFj3guxpWZGdO1Qh(u"ࡇࡣ࡯ࡷࡪࣤ"))
	ZkIcPhXD4qseYE6umyJr = XS7i9lPrOa8p1Gte(uWFAMEHgp0z,YnoJNgtGbDPxCLw5Whj(u"ࡘࡷࡻࡥࣧ"),KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࡉࡥࡱࡹࡥࣦ"),KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࡉࡥࡱࡹࡥࣦ"))
	R0sa1tOV8c = XS7i9lPrOa8p1Gte(MsDNYICTjem8HG3nUqXwo70,vnEBxuCTlGyP04gQeb9YLi1kt3D(u"࡚ࡲࡶࡧࣩ"),LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࡋࡧ࡬ࡴࡧࣨ"),LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࡋࡧ࡬ࡴࡧࣨ"))
	ZBOHIbkJwYWFaM2 = XS7i9lPrOa8p1Gte(dykgDvpinS,OEezhg1y9qVi8SMpbxHLsfCot5jm(u"ࡕࡴࡸࡩ࣫"),GGEWLCrDMQBTgny1VNpUfzhjIl(u"ࡆࡢ࡮ࡶࡩ࣪"),GGEWLCrDMQBTgny1VNpUfzhjIl(u"ࡆࡢ࡮ࡶࡩ࣪"))
	B7kRwPOhcSqLJtxGoHNFm59C = all([ymXphHK8DOjYq1IxLoAZGU0,zJ46hM9arBqDENdgwV,fL6ncZ0Mi3g,ZkIcPhXD4qseYE6umyJr,R0sa1tOV8c,ZBOHIbkJwYWFaM2])
	if B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,mmXevlsZVWyidN(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,woz7WC1Yuj9IPDZSap6RNkLlGf(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def EQmdBzFSZIt4ryKo(F8vouPfwViXj7ZABtS):
	B7kRwPOhcSqLJtxGoHNFm59C = BmpZUuaRbDWj7XN(u"ࡖࡵࡹࡪ࣬")
	if F8vouPfwViXj7ZABtS:
		toHRX9wsSeykvAYTz = UaN4SLPvgkYmEGw(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,n8vA4ENFj3guxpWZGdO1Qh(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if toHRX9wsSeykvAYTz!=KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"࠲ࣁ"): return
	try:
		import sqlite3 as z1ExbawdR98htP
		lRobYEx5LU07BM1hzSe = z1ExbawdR98htP.connect(FQPxJYIi9g6oWTEsfahcmSZe)
		lRobYEx5LU07BM1hzSe.text_factory = str
		PzQ6Nvb3lYp2OL74tafeu = lRobYEx5LU07BM1hzSe.cursor()
		PzQ6Nvb3lYp2OL74tafeu.execute(qmsxGkXU6MFe42(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		PzQ6Nvb3lYp2OL74tafeu.execute(h6RU3Z2sctolNwBV4Jgyu(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		PzQ6Nvb3lYp2OL74tafeu.execute(tlOMscopuefm(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		lRobYEx5LU07BM1hzSe.commit()
		PzQ6Nvb3lYp2OL74tafeu.execute(tlOMscopuefm(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		lRobYEx5LU07BM1hzSe.close()
	except: B7kRwPOhcSqLJtxGoHNFm59C = mmXevlsZVWyidN(u"ࡉࡥࡱࡹࡥ࣭")
	if F8vouPfwViXj7ZABtS and B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return B7kRwPOhcSqLJtxGoHNFm59C
def hrbAdiI7vU():
	B7kRwPOhcSqLJtxGoHNFm59C = AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࡘࡷࡻࡥ࣮")
	for file in hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.listdir(xXQGIoNF3ivaRt):
		if Tp2KdNj4mI3tOPhwLY(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or TI7lv43rNSKHmoOtep(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		REFAGilf0UCopQJ8wdc3 = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(xXQGIoNF3ivaRt,file)
		try:
			hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.remove(REFAGilf0UCopQJ8wdc3)
		except Exception as BiyrDf8vZK1S2VXM54Itc6aGU:
			B7kRwPOhcSqLJtxGoHNFm59C = BmpZUuaRbDWj7XN(u"ࡋࡧ࡬ࡴࡧ࣯")
			if F8vouPfwViXj7ZABtS and B7kRwPOhcSqLJtxGoHNFm59C: mHFPwE0eoBr(feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,feCPBFLJcHr9yQl6dkj3S,str(BiyrDf8vZK1S2VXM54Itc6aGU))
	return B7kRwPOhcSqLJtxGoHNFm59C
hhmrscJlKGa8iBX(zWoml9DLSkK(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
AA5WlCUrmqIvs = tJKIOTASR7WyBUPeihuE05w.argv[vnEBxuCTlGyP04gQeb9YLi1kt3D(u"࠳ࣂ")]
sy5kXpH3qMo0mz28dtcgPDTlO = OEezhg1y9qVi8SMpbxHLsfCot5jm(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
EBnhSg81bJDvqTWpXHcPIkf = K9KDIcFZYqNThjXA.getInfoLabel(mmXevlsZVWyidN(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
FE3gcnK2QpulrYGCtxi6hf9 = NVR34ucn8ZTDxwHYsdBL.findall(mmXevlsZVWyidN(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),EBnhSg81bJDvqTWpXHcPIkf,NVR34ucn8ZTDxwHYsdBL.DOTALL)
FE3gcnK2QpulrYGCtxi6hf9 = float(FE3gcnK2QpulrYGCtxi6hf9[qmsxGkXU6MFe42(u"࠳ࣃ")])
gcOnMviEPaQKV7Bh = FE3gcnK2QpulrYGCtxi6hf9<j6gdsu0TNlGtS(u"࠵࠾ࣄ")
upBzrKQHsAJ3OfTiY2j0 = FE3gcnK2QpulrYGCtxi6hf9>tyoQzeTiMuON6KbpZ2BIv(u"࠶࠾࠮࠺࠻ࣅ")
if upBzrKQHsAJ3OfTiY2j0:
	xXQGIoNF3ivaRt = a8VbYziv3WZQGXMAeCp.translatePath(zWoml9DLSkK(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	bK3Sdkxyh1w74qrgD6NXuC = a8VbYziv3WZQGXMAeCp.translatePath(h6RU3Z2sctolNwBV4Jgyu(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	yjnbFXJcfv = a8VbYziv3WZQGXMAeCp.translatePath(Q4VxvMIpc8uKf3hWOUHLz(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	oFJGUyY1stLwrhbOqldBe = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,LjEJpaqPrKXTkbi1AvDd60WQzw(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),zWoml9DLSkK(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),TI7lv43rNSKHmoOtep(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	xXQGIoNF3ivaRt = K9KDIcFZYqNThjXA.translatePath(Q4VxvMIpc8uKf3hWOUHLz(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	bK3Sdkxyh1w74qrgD6NXuC = K9KDIcFZYqNThjXA.translatePath(xhDSweOPasGZFjEXoCvf4d3Tzb1H(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	yjnbFXJcfv = K9KDIcFZYqNThjXA.translatePath(AW8wJINVcyLuQblgv5Z2TqfpCR(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	oFJGUyY1stLwrhbOqldBe = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,YnoJNgtGbDPxCLw5Whj(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),tyoQzeTiMuON6KbpZ2BIv(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),qmsxGkXU6MFe42(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
xsJTCDjP93ZreOoiq1bX6lBNQ = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,qmsxGkXU6MFe42(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),c6WqRVHofEONTwZ(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),sy5kXpH3qMo0mz28dtcgPDTlO)
z37KLHGjvVCJAbUPQNIr = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(xsJTCDjP93ZreOoiq1bX6lBNQ,VqDnxC7X1rZmLty36ATlRwdEgpfHe(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
RAZIMvP70XYdqr3Nusw4TQDktz8ca = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(yjnbFXJcfv,sy5kXpH3qMo0mz28dtcgPDTlO)
UfP6nZEeOrJLH = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,qmsxGkXU6MFe42(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),vnEBxuCTlGyP04gQeb9YLi1kt3D(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
YKsnhvcfdTzFuL = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
w4Wp1c5Usf6YuSqy = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(YKsnhvcfdTzFuL,sy5kXpH3qMo0mz28dtcgPDTlO)
g6wcvEM8rDtipAPsujxh = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(YKsnhvcfdTzFuL,c6WqRVHofEONTwZ(u"ࠪࡸࡪࡳࡰࠨ࢙"))
DMo2Z6AXic9k = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(YKsnhvcfdTzFuL,h6RU3Z2sctolNwBV4Jgyu(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
FQPxJYIi9g6oWTEsfahcmSZe = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(bK3Sdkxyh1w74qrgD6NXuC,VRcWJbKt0TYpf3(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),PDOw5YrslygcHCmRJ2i4vbGeu(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),Q4VxvMIpc8uKf3hWOUHLz(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
mUPZV1dSNQK4TWC7RDk = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(RAZIMvP70XYdqr3Nusw4TQDktz8ca,Mh0FRgW9Et3aBnCoHs(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
dvI1Dlq7fcaQjkBsJ5LMeV = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(xXQGIoNF3ivaRt,Q4VxvMIpc8uKf3hWOUHLz(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
MCjm1x7cNGVLrTpU = hhyfKVUuMbQe3sIWXlBgjnJ91EqpZ.path.join(xXQGIoNF3ivaRt,c6WqRVHofEONTwZ(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   AA5WlCUrmqIvs==KwAIj5ip3WtMUhraDc1bTHx0GNmEQJ(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: awRjkvFmzGycVe2Nr8DhPXnW3ZxlC(dvI1Dlq7fcaQjkBsJ5LMeV)
elif AA5WlCUrmqIvs==Tp2KdNj4mI3tOPhwLY(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: awRjkvFmzGycVe2Nr8DhPXnW3ZxlC(MCjm1x7cNGVLrTpU)
elif AA5WlCUrmqIvs==mmXevlsZVWyidN(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: WZiLdzB83GFe1EXsxolPg2KHO06Q()
elif AA5WlCUrmqIvs==YnoJNgtGbDPxCLw5Whj(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: mmV7tMDSl0CGEksH4()
elif AA5WlCUrmqIvs==TI7lv43rNSKHmoOtep(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: ze36Kh8qH7V()
elif AA5WlCUrmqIvs==LKDiRBbUaglnMr50YFcC9koeH4(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: TWBLyQEqk15tG70fFImOHoxKPl()
elif AA5WlCUrmqIvs==mmXevlsZVWyidN(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: WnIq0hjvD6QzOb()
elif AA5WlCUrmqIvs==c6WqRVHofEONTwZ(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: BBiS70H9dphgkuZEAVzOfRN()
elif AA5WlCUrmqIvs==h6RU3Z2sctolNwBV4Jgyu(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: XvKCa5w6nHYWETP3LMoUj()
hhmrscJlKGa8iBX(jjuXCT05fhE24r8pyb(u"࠭ࡳࡵࡱࡳࠫࢪ"))