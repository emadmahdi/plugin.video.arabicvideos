# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'IFILM'
qBAgzkG9oCL = '_IFL_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
talv2Us5Kn1 = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][1]
BZ1UIeSfWMxb6X = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][2]
FnfhCKJ7rb2MH3jQ9Z = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][3]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,GpwRnQ6q2o1fv0HbJTs,text):
	if   mode==20: Ubud2NhHKRnMTvI5mprQBVqk80 = AEMwPbseR8fpH7C403LiWoZQYhuOvK()
	elif mode==21: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR(url)
	elif mode==22: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==23: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==24: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url,text)
	elif mode==25: Ubud2NhHKRnMTvI5mprQBVqk80 = K5KhLaQINd3bnXER(url)
	elif mode==27: Ubud2NhHKRnMTvI5mprQBVqk80 = aZr8kT7yehG2Pu6dRKjU9A4(url)
	elif mode==28: Ubud2NhHKRnMTvI5mprQBVqk80 = emdfaziwrZ3byx2WRVLopc5()
	elif mode==29: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def AEMwPbseR8fpH7C403LiWoZQYhuOvK():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'عربي',S7EgasGcYdIo,21,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'English',talv2Us5Kn1,21,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فارسى',BZ1UIeSfWMxb6X,21,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فارسى 2',FnfhCKJ7rb2MH3jQ9Z,21,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	return
def emdfaziwrZ3byx2WRVLopc5():
	w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'عربي',S7EgasGcYdIo,27)
	w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'English',talv2Us5Kn1,27)
	w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'فارسى',BZ1UIeSfWMxb6X,27)
	w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'فارسى 2',FnfhCKJ7rb2MH3jQ9Z,27)
	return
def cBfe1kCEI4uZTVpKqwbGQR(sQgG8UO2vFEYSPB5zemaJ):
	mI6ayKxBvjd4CRthL = sQgG8UO2vFEYSPB5zemaJ
	if sQgG8UO2vFEYSPB5zemaJ=='IFILM-ARABIC': sQgG8UO2vFEYSPB5zemaJ = S7EgasGcYdIo
	elif sQgG8UO2vFEYSPB5zemaJ=='IFILM-ENGLISH': sQgG8UO2vFEYSPB5zemaJ = talv2Us5Kn1
	else: mI6ayKxBvjd4CRthL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(sQgG8UO2vFEYSPB5zemaJ)
	if holVgItZADkYa8Q2FLnw39=='ar' or mI6ayKxBvjd4CRthL=='IFILM-ARABIC':
		GCDmIxAh3o9r0bYVKuFQ = 'بحث في الموقع'
		eraCBg1RXLl7MvN9m6O2z3Zqni4 = 'مسلسلات - حالية'
		XQv4cBgdZD5k6OPwy3alsEGxtA = 'مسلسلات - أحدث'
		B01Fh9czqo = 'مسلسلات - أبجدي'
		PAbxXnjCLcEyNB97q0KRl = 'بث حي آي فيلم'
		GBKLJE1kZ7QRIwg6pACrc = 'أفلام'
		GxU7kRKJf8gtW4yQuv = 'موسيقى'
		uuaWKqFAwTdilkM2YRZH = 'برامج'
	elif holVgItZADkYa8Q2FLnw39=='en' or mI6ayKxBvjd4CRthL=='IFILM-ENGLISH':
		GCDmIxAh3o9r0bYVKuFQ = 'Search in site'
		eraCBg1RXLl7MvN9m6O2z3Zqni4 = 'Series - Current'
		XQv4cBgdZD5k6OPwy3alsEGxtA = 'Series - Latest'
		B01Fh9czqo = 'Series - Alphabet'
		PAbxXnjCLcEyNB97q0KRl = 'Live iFilm channel'
		GBKLJE1kZ7QRIwg6pACrc = 'Movies'
		GxU7kRKJf8gtW4yQuv = 'Music'
		uuaWKqFAwTdilkM2YRZH = 'Shows'
	elif holVgItZADkYa8Q2FLnw39 in ['fa','fa2']:
		GCDmIxAh3o9r0bYVKuFQ = 'جستجو در سایت'
		eraCBg1RXLl7MvN9m6O2z3Zqni4 = 'سريال - جاری'
		XQv4cBgdZD5k6OPwy3alsEGxtA = 'سريال - آخرین'
		B01Fh9czqo = 'سريال - الفبا'
		PAbxXnjCLcEyNB97q0KRl = 'پخش زنده اي فيلم'
		GBKLJE1kZ7QRIwg6pACrc = 'فيلم'
		GxU7kRKJf8gtW4yQuv = 'موسيقى'
		uuaWKqFAwTdilkM2YRZH = 'برنامه ها'
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+GCDmIxAh3o9r0bYVKuFQ,sQgG8UO2vFEYSPB5zemaJ,29,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('live',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+PAbxXnjCLcEyNB97q0KRl,sQgG8UO2vFEYSPB5zemaJ,27)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	oFQHL7AaItXmfCz4yPKT0pc1ie = ['Series','Program','Music']
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,sQgG8UO2vFEYSPB5zemaJ+'/home',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt=AxTYMhRlfyskNc0X19dvwtS.findall('button-menu(.*?)/Contact',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if any(value in cX2SpPxGLmADTKl for value in oFQHL7AaItXmfCz4yPKT0pc1ie):
				url = sQgG8UO2vFEYSPB5zemaJ+cX2SpPxGLmADTKl
				if 'Series' in cX2SpPxGLmADTKl:
					w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'100')
					w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+XQv4cBgdZD5k6OPwy3alsEGxtA,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
					w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+B01Fh9czqo,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'201')
				elif 'Film' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+GBKLJE1kZ7QRIwg6pACrc,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'100')
				elif 'Music' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+GxU7kRKJf8gtW4yQuv,url,25,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
				elif 'Program' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+uuaWKqFAwTdilkM2YRZH,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	return R8AE9e4mYxVhusL3Q
def K5KhLaQINd3bnXER(url):
	sQgG8UO2vFEYSPB5zemaJ = u5BpbsVWUwe(url)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-MUSIC_MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('Music-tools-header(.*?)Music-body',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	title = AxTYMhRlfyskNc0X19dvwtS.findall('<p>(.*?)</p>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = sQgG8UO2vFEYSPB5zemaJ + cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,23,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'101')
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,GpwRnQ6q2o1fv0HbJTs):
	sQgG8UO2vFEYSPB5zemaJ = u5BpbsVWUwe(url)
	holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(url)
	type = url.split('/')[-1]
	npAxI4LuCZ = str(int(GpwRnQ6q2o1fv0HbJTs)//100)
	GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)%100)
	if type=='Series' and GpwRnQ6q2o1fv0HbJTs=='0':
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-TITLES-1st')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('serial-body(.*?)class="row',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
			title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			title = riUKNnOEtVwdj4(title)
			cX2SpPxGLmADTKl = sQgG8UO2vFEYSPB5zemaJ + cX2SpPxGLmADTKl
			RRx0ri8bETI = sQgG8UO2vFEYSPB5zemaJ + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,23,RRx0ri8bETI,npAxI4LuCZ+'01')
	MeLFo0S9mPOJjCqIX8ln=0
	if type=='Series': PtATpb3YenChf5='3'
	if type=='Film': PtATpb3YenChf5='5'
	if type=='Program': PtATpb3YenChf5='7'
	if type in ['Series','Program','Film'] and GpwRnQ6q2o1fv0HbJTs!='0':
		nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Home/PageingItem?category='+PtATpb3YenChf5+'&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&orderby='+npAxI4LuCZ
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-TITLES-2nd')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,title,RRx0ri8bETI in items:
			title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			title = title.replace('\\',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			title = title.replace('"',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			MeLFo0S9mPOJjCqIX8ln += 1
			cX2SpPxGLmADTKl = sQgG8UO2vFEYSPB5zemaJ + '/' + type + '/Content/' + id
			RRx0ri8bETI = sQgG8UO2vFEYSPB5zemaJ + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
			if type=='Film': w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,24,RRx0ri8bETI,npAxI4LuCZ+'01')
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,23,RRx0ri8bETI,npAxI4LuCZ+'01')
	if type=='Music':
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,sQgG8UO2vFEYSPB5zemaJ+'/Music/Index?page='+GpwRnQ6q2o1fv0HbJTs,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-TITLES-3rd')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pagination-demo(.*?)pagination-demo',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
			MeLFo0S9mPOJjCqIX8ln += 1
			RRx0ri8bETI = sQgG8UO2vFEYSPB5zemaJ + RRx0ri8bETI
			cX2SpPxGLmADTKl = sQgG8UO2vFEYSPB5zemaJ + cX2SpPxGLmADTKl
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,23,RRx0ri8bETI,'101')
	if MeLFo0S9mPOJjCqIX8ln>20:
		title='صفحة '
		if holVgItZADkYa8Q2FLnw39=='en': title = 'Page '
		if holVgItZADkYa8Q2FLnw39=='fa': title = 'صفحه '
		if holVgItZADkYa8Q2FLnw39=='fa2': title = 'صفحه '
		for qBe2WSEkNtcz8ZbyYHwhR5KAm9f in range(1,11) :
			if not GpwRnQ6q2o1fv0HbJTs==str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f):
				b9bnlE2iFr0HLPh4jWTzpOJ = '0'+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f),url,22,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,npAxI4LuCZ+b9bnlE2iFr0HLPh4jWTzpOJ[-2:])
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url,GpwRnQ6q2o1fv0HbJTs):
	if not GpwRnQ6q2o1fv0HbJTs: GpwRnQ6q2o1fv0HbJTs = 0
	sQgG8UO2vFEYSPB5zemaJ = u5BpbsVWUwe(url)
	DuXcqRVY9WrkxbZQjndmSJTFoi2fM = u5BpbsVWUwe(url)
	holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(url)
	PCnrX0p2QmTt5ijBIkqu4La = url.split('/')
	id,type = PCnrX0p2QmTt5ijBIkqu4La[-1],PCnrX0p2QmTt5ijBIkqu4La[3]
	npAxI4LuCZ = str(int(GpwRnQ6q2o1fv0HbJTs)//100)
	GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)%100)
	MeLFo0S9mPOJjCqIX8ln = 0
	if type=='Series':
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-1st')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		title = ' - الحلقة '
		if holVgItZADkYa8Q2FLnw39=='en': title = ' - Episode '
		if holVgItZADkYa8Q2FLnw39=='fa': title = ' - قسمت '
		if holVgItZADkYa8Q2FLnw39=='fa2': title = ' - قسمت '
		if holVgItZADkYa8Q2FLnw39=='fa': zWYhyNd0br2TcgwFGB3ujXpKD976 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		else: zWYhyNd0br2TcgwFGB3ujXpKD976 = holVgItZADkYa8Q2FLnw39
		spAxr1HUSmv5GbFd0 = AxTYMhRlfyskNc0X19dvwtS.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for name,count,RRx0ri8bETI,cX2SpPxGLmADTKl in items:
			for azhwpE0qmevcFobdRi in range(int(count),0,-1):
				enDH4YQSKzsrujRUx1aL3tTJc = RRx0ri8bETI + zWYhyNd0br2TcgwFGB3ujXpKD976 + id + '/' + str(azhwpE0qmevcFobdRi) + '.png'
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = name + title + str(azhwpE0qmevcFobdRi)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = riUKNnOEtVwdj4(eraCBg1RXLl7MvN9m6O2z3Zqni4)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,url,24,enDH4YQSKzsrujRUx1aL3tTJc,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(azhwpE0qmevcFobdRi))
	elif type=='Program':
		nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&orderby=1'
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-2nd')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		title = ' - الحلقة '
		if holVgItZADkYa8Q2FLnw39=='en': title = ' - Episode '
		if holVgItZADkYa8Q2FLnw39=='fa': title = ' - قسمت '
		if holVgItZADkYa8Q2FLnw39=='fa2': title = ' - قسمت '
		for azhwpE0qmevcFobdRi,RRx0ri8bETI,cX2SpPxGLmADTKl,BBcEelyxVF7rWakAG1UHmRwL8qt3pJ,name in items:
			MeLFo0S9mPOJjCqIX8ln += 1
			enDH4YQSKzsrujRUx1aL3tTJc = DuXcqRVY9WrkxbZQjndmSJTFoi2fM + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
			name = kd8ZhJPCe7QzxLgij3TEHlGtOv(name)
			eraCBg1RXLl7MvN9m6O2z3Zqni4 = name + title + str(azhwpE0qmevcFobdRi)
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,nUDgc4absePT2xMt,24,enDH4YQSKzsrujRUx1aL3tTJc,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(MeLFo0S9mPOJjCqIX8ln))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Music/GetTracksBy?id='+str(id)+'&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&type=0'
			R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-3rd')
			items = AxTYMhRlfyskNc0X19dvwtS.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for RRx0ri8bETI,cX2SpPxGLmADTKl,name,title in items:
				MeLFo0S9mPOJjCqIX8ln += 1
				enDH4YQSKzsrujRUx1aL3tTJc = DuXcqRVY9WrkxbZQjndmSJTFoi2fM + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = name + ' - ' + title
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = eraCBg1RXLl7MvN9m6O2z3Zqni4.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = kd8ZhJPCe7QzxLgij3TEHlGtOv(eraCBg1RXLl7MvN9m6O2z3Zqni4)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,nUDgc4absePT2xMt,24,enDH4YQSKzsrujRUx1aL3tTJc,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(MeLFo0S9mPOJjCqIX8ln))
		elif 'Clips' in url:
			nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Music/GetTracksBy?id=0&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&type=15'
			R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-4th')
			items = AxTYMhRlfyskNc0X19dvwtS.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for RRx0ri8bETI,title,cX2SpPxGLmADTKl in items:
				MeLFo0S9mPOJjCqIX8ln += 1
				enDH4YQSKzsrujRUx1aL3tTJc = DuXcqRVY9WrkxbZQjndmSJTFoi2fM + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = kd8ZhJPCe7QzxLgij3TEHlGtOv(eraCBg1RXLl7MvN9m6O2z3Zqni4)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,nUDgc4absePT2xMt,24,enDH4YQSKzsrujRUx1aL3tTJc,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(MeLFo0S9mPOJjCqIX8ln))
		elif 'category' in url:
			if 'category=6' in url:
				nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Music/GetTracksBy?id=0&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&type=6'
				R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				nUDgc4absePT2xMt = sQgG8UO2vFEYSPB5zemaJ+'/Music/GetTracksBy?id=0&page='+GpwRnQ6q2o1fv0HbJTs+'&size=30&type=4'
				R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-EPISODES-6th')
			items = AxTYMhRlfyskNc0X19dvwtS.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for RRx0ri8bETI,cX2SpPxGLmADTKl,name,title in items:
				MeLFo0S9mPOJjCqIX8ln += 1
				enDH4YQSKzsrujRUx1aL3tTJc = DuXcqRVY9WrkxbZQjndmSJTFoi2fM + pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = name + ' - ' + title
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = eraCBg1RXLl7MvN9m6O2z3Zqni4.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				eraCBg1RXLl7MvN9m6O2z3Zqni4 = kd8ZhJPCe7QzxLgij3TEHlGtOv(eraCBg1RXLl7MvN9m6O2z3Zqni4)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+eraCBg1RXLl7MvN9m6O2z3Zqni4,nUDgc4absePT2xMt,24,enDH4YQSKzsrujRUx1aL3tTJc,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(MeLFo0S9mPOJjCqIX8ln))
	if type=='Music' or type=='Program':
		if MeLFo0S9mPOJjCqIX8ln>25:
			title='صفحة '
			if holVgItZADkYa8Q2FLnw39=='en': title = ' Page '
			if holVgItZADkYa8Q2FLnw39=='fa': title = ' صفحه '
			if holVgItZADkYa8Q2FLnw39=='fa2': title = ' صفحه '
			for qBe2WSEkNtcz8ZbyYHwhR5KAm9f in range(1,11):
				if not GpwRnQ6q2o1fv0HbJTs==str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f):
					b9bnlE2iFr0HLPh4jWTzpOJ = '0'+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f)
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f),url,23,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,npAxI4LuCZ+b9bnlE2iFr0HLPh4jWTzpOJ[-2:])
	return
def QgIZSJdUhsEnup8GPz3(url,azhwpE0qmevcFobdRi):
	DuXcqRVY9WrkxbZQjndmSJTFoi2fM = u5BpbsVWUwe(url)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-PLAY-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(url)
		PCnrX0p2QmTt5ijBIkqu4La = url.split('/')
		id,type = PCnrX0p2QmTt5ijBIkqu4La[-1],PCnrX0p2QmTt5ijBIkqu4La[3]
		cX2SpPxGLmADTKl = items[0][0]+holVgItZADkYa8Q2FLnw39+id+'/,'+azhwpE0qmevcFobdRi+','+azhwpE0qmevcFobdRi+'_'+items[0][2]
		GjC4atkJLwlTpsI.append('m3u8')
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(url)
		PCnrX0p2QmTt5ijBIkqu4La = url.split('/')
		id,type = PCnrX0p2QmTt5ijBIkqu4La[-1],PCnrX0p2QmTt5ijBIkqu4La[3]
		cX2SpPxGLmADTKl = items[0][0]+holVgItZADkYa8Q2FLnw39+id+'/'+azhwpE0qmevcFobdRi+items[0][2]
		GjC4atkJLwlTpsI.append('mp4 url')
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('source src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl in items:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('//','/')
		GjC4atkJLwlTpsI.append('mp4 src')
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('VideoAddress":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		cX2SpPxGLmADTKl = items[int(azhwpE0qmevcFobdRi)-1]
		cX2SpPxGLmADTKl = DuXcqRVY9WrkxbZQjndmSJTFoi2fM+pmhHwIbkcrRJeyzuxPUSDGnqM92(cX2SpPxGLmADTKl)
		GjC4atkJLwlTpsI.append('mp4 address')
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('VoiceAddress":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		cX2SpPxGLmADTKl = items[int(azhwpE0qmevcFobdRi)-1]
		cX2SpPxGLmADTKl = DuXcqRVY9WrkxbZQjndmSJTFoi2fM+pmhHwIbkcrRJeyzuxPUSDGnqM92(cX2SpPxGLmADTKl)
		GjC4atkJLwlTpsI.append('mp3 address')
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==1: cX2SpPxGLmADTKl = CBL4OQVtWbMAycUGl7Ex2SKZF[0]
	else:
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('اختر الفيديو المناسب:', GjC4atkJLwlTpsI)
		if qNmsBD1jJZVzcxi4onKuAOIC == -1 : return
		cX2SpPxGLmADTKl = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(cX2SpPxGLmADTKl,mI6ayKxBvjd4CRthL,'video')
	return
def u5BpbsVWUwe(url):
	if S7EgasGcYdIo in url: z4t2nu5ryZjPR = S7EgasGcYdIo
	elif talv2Us5Kn1 in url: z4t2nu5ryZjPR = talv2Us5Kn1
	elif BZ1UIeSfWMxb6X in url: z4t2nu5ryZjPR = BZ1UIeSfWMxb6X
	elif FnfhCKJ7rb2MH3jQ9Z in url: z4t2nu5ryZjPR = FnfhCKJ7rb2MH3jQ9Z
	else: z4t2nu5ryZjPR = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	return z4t2nu5ryZjPR
def KAU8tdmPbR0YBMjzW3fSeJk(url):
	if   S7EgasGcYdIo in url: holVgItZADkYa8Q2FLnw39 = 'ar'
	elif talv2Us5Kn1 in url: holVgItZADkYa8Q2FLnw39 = 'en'
	elif BZ1UIeSfWMxb6X in url: holVgItZADkYa8Q2FLnw39 = 'fa'
	elif FnfhCKJ7rb2MH3jQ9Z in url: holVgItZADkYa8Q2FLnw39 = 'fa2'
	else: holVgItZADkYa8Q2FLnw39 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	return holVgItZADkYa8Q2FLnw39
def aZr8kT7yehG2Pu6dRKjU9A4(url):
	holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(url)
	nUDgc4absePT2xMt = url + '/Home/Live'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-LIVE-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = AxTYMhRlfyskNc0X19dvwtS.findall('source src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	jYfvU9egTX62nrukVcoKEAyq = items[0]
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(jYfvU9egTX62nrukVcoKEAyq,mI6ayKxBvjd4CRthL,'live')
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search:
		search = TwDBf3QbKOnrmd5u9()
		if not search: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	if showDialogs:
		YY04QbZite7VBKhCIR = [ S7EgasGcYdIo , talv2Us5Kn1 , BZ1UIeSfWMxb6X , FnfhCKJ7rb2MH3jQ9Z ]
		OKeTmNpi32ral8uMwD6WtjRGcBI = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('اختر اللغة المناسبة:', OKeTmNpi32ral8uMwD6WtjRGcBI)
		if qNmsBD1jJZVzcxi4onKuAOIC == -1 : return
		website = YY04QbZite7VBKhCIR[qNmsBD1jJZVzcxi4onKuAOIC]
	else:
		if '_IFILM-ARABIC_' in sL9HIPc1tSZrhE60TUoz2KQa: website = S7EgasGcYdIo
		elif '_IFILM-ENGLISH_' in sL9HIPc1tSZrhE60TUoz2KQa: website = talv2Us5Kn1
		else: website = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if not website: return
	holVgItZADkYa8Q2FLnw39 = KAU8tdmPbR0YBMjzW3fSeJk(website)
	nUDgc4absePT2xMt = website + "/Home/Search?searchstring=" + ej9gRJkD6KGTcf
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'IFILM-SEARCH-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		for RRx0ri8bETI,PtATpb3YenChf5,id,title in items:
			if PtATpb3YenChf5 in ['3','7']:
				title = title.replace('\\',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				title = title.replace('"',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				if PtATpb3YenChf5=='3':
					type = 'Series'
					if holVgItZADkYa8Q2FLnw39=='ar': name = 'مسلسل : '
					elif holVgItZADkYa8Q2FLnw39=='en': name = 'Series : '
					elif holVgItZADkYa8Q2FLnw39=='fa': name = 'سريال ها : '
					elif holVgItZADkYa8Q2FLnw39=='fa2': name = 'سريال ها : '
				elif PtATpb3YenChf5=='5':
					type = 'Film'
					if holVgItZADkYa8Q2FLnw39=='ar': name = 'فيلم : '
					elif holVgItZADkYa8Q2FLnw39=='en': name = 'Movie : '
					elif holVgItZADkYa8Q2FLnw39=='fa': name = 'فيلم : '
					elif holVgItZADkYa8Q2FLnw39=='fa2': name = 'فلم ها : '
				elif PtATpb3YenChf5=='7':
					type = 'Program'
					if holVgItZADkYa8Q2FLnw39=='ar': name = 'برنامج : '
					elif holVgItZADkYa8Q2FLnw39=='en': name = 'Program : '
					elif holVgItZADkYa8Q2FLnw39=='fa': name = 'برنامه ها : '
					elif holVgItZADkYa8Q2FLnw39=='fa2': name = 'برنامه ها : '
				title = name + title
				cX2SpPxGLmADTKl = website + '/' + type + '/Content/' + id
				RRx0ri8bETI = pmhHwIbkcrRJeyzuxPUSDGnqM92(RRx0ri8bETI)
				RRx0ri8bETI = website+RRx0ri8bETI
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,23,RRx0ri8bETI,'101')
	return