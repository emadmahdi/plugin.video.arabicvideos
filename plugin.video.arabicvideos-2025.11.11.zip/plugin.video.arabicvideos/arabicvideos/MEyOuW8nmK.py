# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
import xbmc as mMaH8ZsXEch3TyYi0PA1gNSxCzLUW,re as AxTYMhRlfyskNc0X19dvwtS,sys as qv7XKecsSGz6rBTpt,xbmcaddon as i4HqIZ7Ba6epDElJ3bsXTA,random as DDLw3RXCNW,os as oNlez5gnM9x2B4,xbmcvfs as FTA9fWrSdaNCLk8UgVcXjM50,time as f7epsRlYtMz4,pickle as gfq3Q6ENyUTwoZ,zlib as ooIB8qKGdSvxWHOCXAefhgnw,xbmcgui as vRVl0MpXZDwAYB4ag68nc,xbmcplugin as NEYCX82mhdSJUptfu0LWk9szKy,sqlite3 as nhGFNAkSgW2qopEYeT9jz8ULatl,traceback as VGgFQrd6JwjRCmp2aPAos0ycLkv,threading as FK8OfSUyPDl30z,hashlib as s6erOG0HkXaS8L,json as WWNb0XnUxOPL9gF
from auPRixSgLw import *
import drzqWFkSHD
mI6ayKxBvjd4CRthL = B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧ෪")
rq4Bz50iokn = i4HqIZ7Ba6epDElJ3bsXTA.Addon().getAddonInfo(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡱࡣࡷ࡬ࠬ෫"))
j9AuClMcGVbqmB3 = oNlez5gnM9x2B4.path.join(rq4Bz50iokn,pbmKZA1w7L4zHjOM(u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪ෬"))
qv7XKecsSGz6rBTpt.path.append(j9AuClMcGVbqmB3)
cjEfQ4VpOPw = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣ෭"))
XqSerIMoFsRn2UQ1D5Alj6 = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧ෮"),cjEfQ4VpOPw,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
XqSerIMoFsRn2UQ1D5Alj6 = float(XqSerIMoFsRn2UQ1D5Alj6[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
yy7k5OazQ2E1AfpXvKoiglLc = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player
CGM5VAJ1B0meTIyjiwpSrb3P9 = vRVl0MpXZDwAYB4ag68nc.WindowXMLDialog
hT1JIgqPQsUOZp5tjCX0E = XqSerIMoFsRn2UQ1D5Alj6<pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠳࠼࿥")
fOohwvakqi29cx0l3yt5mzrAGpEg = XqSerIMoFsRn2UQ1D5Alj6>jBbkfIJSDqcVwl8irzy4Z3O(u"࠴࠼࠳࠿࠹࿦")
if fOohwvakqi29cx0l3yt5mzrAGpEg:
	kuRQZDYesABiH0EIxj = FTA9fWrSdaNCLk8UgVcXjM50.translatePath(nR0ok9zju84rFUQl1YC(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ෯"))
	CjHdi09xSDhplomnRJay = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.LOGINFO
	qsTZxjmy98KS4O,lodjqT9n2wA = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭෰"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ෱")
	JK5v49guLEX6mn3fDjNS = FTA9fWrSdaNCLk8UgVcXjM50.translatePath(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨෲ"))
	from urllib.parse import unquote as _lszP43bDC5et1yRkK
	qur032fAGe = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩෳ")
else:
	kuRQZDYesABiH0EIxj = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.translatePath(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ෴"))
	CjHdi09xSDhplomnRJay = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.LOGNOTICE
	qsTZxjmy98KS4O,lodjqT9n2wA = JZ45mOctiTszPNw1GVjxhep2Y(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ෵").encode(RMGz7OiD1e30P),JZ45mOctiTszPNw1GVjxhep2Y(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ෶").encode(RMGz7OiD1e30P)
	JK5v49guLEX6mn3fDjNS = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.translatePath(lRKCWnNi0Edr984eI(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭෷"))
	from urllib import unquote as _lszP43bDC5et1yRkK
	qur032fAGe = W2Vv30i8qxSuItfsolPLdFZA(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ෸").encode(RMGz7OiD1e30P)
fFwqoWYPMVRJDtN9m3bCihpz = qv7XKecsSGz6rBTpt.argv[nUaVQsoA6EXcK4Odht5wCge0J8Pib].split(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧ࠰ࠩ෹"))[H3OKMjDG1evnl4Ruiz]
yyRW7r1KOgHNcdmnJvS5iQ4f0 = int(qv7XKecsSGz6rBTpt.argv[xD9WeoEAsX7])
utdV6CEfRBM = qv7XKecsSGz6rBTpt.argv[H3OKMjDG1evnl4Ruiz]
FOrZM84s2y0Y3NSmi6Wh9uJ5Hdg17 = fFwqoWYPMVRJDtN9m3bCihpz.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ࠰ࠪ෺"))[H3OKMjDG1evnl4Ruiz]
FLRQJnBHTvsXU = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩ෻")+fFwqoWYPMVRJDtN9m3bCihpz+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࠭ࠬ෼"))
eC21aUbHsMhBQnfVypk8T = oNlez5gnM9x2B4.path.join(JK5v49guLEX6mn3fDjNS,fFwqoWYPMVRJDtN9m3bCihpz)
jaVSoQGFYUlCugWK9kLc = oNlez5gnM9x2B4.path.join(eC21aUbHsMhBQnfVypk8T,YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࡮ࡳࡡࡨࡧࡶࠫ෽"))
hpGOZ6jBuxm3U49oH2Lv = oNlez5gnM9x2B4.path.join(jaVSoQGFYUlCugWK9kLc,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬ෾"))
cZAymCuFIXp9fzL40 = oNlez5gnM9x2B4.path.join(jaVSoQGFYUlCugWK9kLc,W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡹࠧ෿"))
KK4Fa7Sj0L3CywRgQxZk = oNlez5gnM9x2B4.path.join(cZAymCuFIXp9fzL40,kAz7WRYjrfGm(u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪ฀"))
MMUsJDCWFAe = oNlez5gnM9x2B4.path.join(kuRQZDYesABiH0EIxj,rAYDiWlzm9MCU6x0GnROua(u"ࠨ࡯ࡨࡨ࡮ࡧࠧก"),rAYDiWlzm9MCU6x0GnROua(u"ࠩࡉࡳࡳࡺࡳࠨข"),pbmKZA1w7L4zHjOM(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭ฃ"))
mmEuUR4JdaHtAsS = oNlez5gnM9x2B4.path.join(eC21aUbHsMhBQnfVypk8T,YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡲࡧࡩ࡯ࡦࡤࡸࡦ࠴ࡤࡣࠩค"))
IZKily6gHndwh3qNe0TOfa1 = oNlez5gnM9x2B4.path.join(eC21aUbHsMhBQnfVypk8T,CCWqR3dmtzw6xoIX41(u"ࠬࡲࡡࡴࡶࡹ࡭ࡩ࡫࡯ࡴ࠰ࡧࡥࡹ࠭ฅ"))
rq4Bz50iokn = i4HqIZ7Ba6epDElJ3bsXTA.Addon().getAddonInfo(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡰࡢࡶ࡫ࠫฆ"))
YWHsNXrFZpPBOf37IgQtKhTc5ivR4j = oNlez5gnM9x2B4.path.join(rq4Bz50iokn,CCWqR3dmtzw6xoIX41(u"ࠧ࡮ࡧࡱࡹࡤࡸࡥࡥࡡ࠵࠴࠵ࡾ࠲࠶࠲࠱ࡴࡳ࡭ࠧง"))
KKydonNSglP1M08xw7O = int(f7epsRlYtMz4.time())
xeI7QzBgGEXN8ftCawRpO24nDh = i4HqIZ7Ba6epDElJ3bsXTA.Addon(id=fFwqoWYPMVRJDtN9m3bCihpz)
gUyh1AYOscH68IQW29fLK = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬจ"))
NNoTxCgkAQyV2hpFOPeRtq70jr4d = pLwgjkuTs6CS if gUyh1AYOscH68IQW29fLK==FLRQJnBHTvsXU else NFGqKBLtvUZn1S3dau
def J1jmhoWbQuqR8g2YpK(HHyOcE4DNohvx0MaIJZ1b,B387pSDQlZvhYs9OWVXzPtfLugw=jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡂࠫฉ")):
	if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡁࠬช") in HHyOcE4DNohvx0MaIJZ1b:
		if B387pSDQlZvhYs9OWVXzPtfLugw in HHyOcE4DNohvx0MaIJZ1b: nUDgc4absePT2xMt,iijZAMDmfILolcRECB = HHyOcE4DNohvx0MaIJZ1b.split(B387pSDQlZvhYs9OWVXzPtfLugw,ba49YvOK2Aw8Uhxt(u"࠵࿧"))
		else: nUDgc4absePT2xMt,iijZAMDmfILolcRECB = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,HHyOcE4DNohvx0MaIJZ1b
		iijZAMDmfILolcRECB = iijZAMDmfILolcRECB.split(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࠫ࠭ซ"))
		bo9ixEyvnlwmW = {}
		for Xm1a7RBC0OFTLH6sJQyW in iijZAMDmfILolcRECB:
			LE3wykUGQWTR7KD0crlC5F968hsJX,aqKOPHi3WXSMRIoE = Xm1a7RBC0OFTLH6sJQyW.split(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡃࠧฌ"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠶࿨"))
			bo9ixEyvnlwmW[LE3wykUGQWTR7KD0crlC5F968hsJX] = aqKOPHi3WXSMRIoE
	else: nUDgc4absePT2xMt,bo9ixEyvnlwmW = HHyOcE4DNohvx0MaIJZ1b,{}
	return nUDgc4absePT2xMt,bo9ixEyvnlwmW
def eEy0ApHLb7q5wOBXY(X3cxeAQbjSnkK2sY9ZgJB8ma):
	as6o13jbXVRz2DgPvYc,z4t2nu5ryZjPR,kz2QsgZbMJBwGu7aYEV = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	X3cxeAQbjSnkK2sY9ZgJB8ma = X3cxeAQbjSnkK2sY9ZgJB8ma.replace(qsTZxjmy98KS4O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(lodjqT9n2wA,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌ࠰࠹ࡅ࠴ࡊࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ญ"),X3cxeAQbjSnkK2sY9ZgJB8ma,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if oPeI4pms5LfYHrxygnAh: as6o13jbXVRz2DgPvYc,z4t2nu5ryZjPR,X3cxeAQbjSnkK2sY9ZgJB8ma = oPeI4pms5LfYHrxygnAh[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if as6o13jbXVRz2DgPvYc not in [WRsuxHTjDgYCIpoMQzLFAtS8rikP,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧ࠭ࠩฎ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O]: kz2QsgZbMJBwGu7aYEV = nR0ok9zju84rFUQl1YC(u"ࠨࡡࡐࡓࡉࡥࠧฏ")
	if z4t2nu5ryZjPR: z4t2nu5ryZjPR = pL73X0MYajJQG4n1qgD(u"ࠩࡢࠫฐ")+z4t2nu5ryZjPR+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡣࠬฑ")
	X3cxeAQbjSnkK2sY9ZgJB8ma = z4t2nu5ryZjPR+kz2QsgZbMJBwGu7aYEV+X3cxeAQbjSnkK2sY9ZgJB8ma
	return X3cxeAQbjSnkK2sY9ZgJB8ma
def WDg18QHF3rze(HHyOcE4DNohvx0MaIJZ1b):
	return _lszP43bDC5et1yRkK(HHyOcE4DNohvx0MaIJZ1b)
def XjPqWt1BdDk(rjVAgLNedkCaZQFKYRXxWb):
	a3IZXshl4ErBDteNm6LxSydG9k2HfM = {Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡹࡿࡰࡦࠩฒ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡳ࡯ࡥࡧࠪณ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡵࡳ࡮ࠪด"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠧࡵࡧࡻࡸࠬต"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠨࡲࡤ࡫ࡪ࠭ถ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠩࡱࡥࡲ࡫ࠧท"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CCWqR3dmtzw6xoIX41(u"ࠪ࡭ࡲࡧࡧࡦࠩธ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬน"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧบ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
	if ba49YvOK2Aw8Uhxt(u"࠭࠿ࠨป") in rjVAgLNedkCaZQFKYRXxWb: rjVAgLNedkCaZQFKYRXxWb = rjVAgLNedkCaZQFKYRXxWb.split(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡀࠩผ"),xD9WeoEAsX7)[xD9WeoEAsX7]
	nUDgc4absePT2xMt,NewOQW3kc1sbMhuzCpiK9q5lotBd7 = J1jmhoWbQuqR8g2YpK(rjVAgLNedkCaZQFKYRXxWb)
	aargs = dict(list(a3IZXshl4ErBDteNm6LxSydG9k2HfM.items())+list(NewOQW3kc1sbMhuzCpiK9q5lotBd7.items()))
	g2EfYkO8iXMFdIvLj5PH = aargs[CCWqR3dmtzw6xoIX41(u"ࠨ࡯ࡲࡨࡪ࠭ฝ")]
	yIFRpQwU7EolNWqMC1YBmjDskOf = WDg18QHF3rze(aargs[I6Bfzysrvb8DONZ(u"ࠩࡸࡶࡱ࠭พ")])
	lIRQHpWbFNdAGsMXUx0qV7hoaT2Jc = WDg18QHF3rze(aargs[nR0ok9zju84rFUQl1YC(u"ࠪࡸࡪࡾࡴࠨฟ")])
	cc9AnByQRehb4N8WVjH0Mx3 = WDg18QHF3rze(aargs[w9wfONXUP3(u"ࠫࡵࡧࡧࡦࠩภ")])
	GmCFdqPtRYTu6srLpcQKvjlOA3 = WDg18QHF3rze(aargs[CCWqR3dmtzw6xoIX41(u"ࠬࡺࡹࡱࡧࠪม")])
	ddBhHa2tpW8QKwnmusi4 = WDg18QHF3rze(aargs[ba49YvOK2Aw8Uhxt(u"࠭࡮ࡢ࡯ࡨࠫย")])
	rgO3oUuG6mxJLEjaW4qh7v = WDg18QHF3rze(aargs[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ร")])
	GGfVTFCnSmb3r = aargs[W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩฤ")]
	R1RapmPAYJlBxDOyikeQSnLw = WDg18QHF3rze(aargs[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫล")])
	if R1RapmPAYJlBxDOyikeQSnLw: R1RapmPAYJlBxDOyikeQSnLw = eval(R1RapmPAYJlBxDOyikeQSnLw)
	else: R1RapmPAYJlBxDOyikeQSnLw = {}
	if not g2EfYkO8iXMFdIvLj5PH: GmCFdqPtRYTu6srLpcQKvjlOA3 = hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡪࡴࡲࡤࡦࡴࠪฦ") ; g2EfYkO8iXMFdIvLj5PH = w9wfONXUP3(u"ࠫ࠷࠼࠰ࠨว")
	return GmCFdqPtRYTu6srLpcQKvjlOA3,ddBhHa2tpW8QKwnmusi4,yIFRpQwU7EolNWqMC1YBmjDskOf,g2EfYkO8iXMFdIvLj5PH,rgO3oUuG6mxJLEjaW4qh7v,cc9AnByQRehb4N8WVjH0Mx3,lIRQHpWbFNdAGsMXUx0qV7hoaT2Jc,GGfVTFCnSmb3r,R1RapmPAYJlBxDOyikeQSnLw
def yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL):
	BT8V1LuHlascWA9 = qv7XKecsSGz6rBTpt._getframe(xD9WeoEAsX7).f_code.co_name
	if not mI6ayKxBvjd4CRthL or not BT8V1LuHlascWA9 or BT8V1LuHlascWA9==ba49YvOK2Aw8Uhxt(u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧศ"):
		return jBbkfIJSDqcVwl8irzy4Z3O(u"࡛࠭ࠡࠩษ")+FOrZM84s2y0Y3NSmi6Wh9uJ5Hdg17.upper()+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡠࠩส")+FLRQJnBHTvsXU+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡡࠪห")+str(XqSerIMoFsRn2UQ1D5Alj6)+pL73X0MYajJQG4n1qgD(u"ࠩࠣࡡࠬฬ")
	return lRKCWnNi0Edr984eI(u"ࠪ࠲ࡡࡺࠧอ")+BT8V1LuHlascWA9
def UO05pib6mcvezR9(PLxHlAnj5rb,hTQ9zwprb4V0XWs3aE8FlUAjvY5utk=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not hTQ9zwprb4V0XWs3aE8FlUAjvY5utk: PLxHlAnj5rb,hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,PLxHlAnj5rb
	for qzVYuAeQ3gcMo5r2JG in PPOBCXoZRcN:
		if qzVYuAeQ3gcMo5r2JG in hTQ9zwprb4V0XWs3aE8FlUAjvY5utk: hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.replace(qzVYuAeQ3gcMo5r2JG,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡡࡾ࠰࠱ࠩฮ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if hT1JIgqPQsUOZp5tjCX0E:
		try: hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.decode(RMGz7OiD1e30P,f9fOpCmLAEaW2Go(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬฯ")).encode(RMGz7OiD1e30P,jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ะ"))
		except: hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.encode(RMGz7OiD1e30P,pYeVwat64v(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧั"))
	FtJy56aSnszmA7QfMvlcZbiY = CjHdi09xSDhplomnRJay
	FGgCZybURVmONe7sXtL4xj2M = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O]
	if PLxHlAnj5rb: hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.replace(oamlxBqLdu4ZM9nQrbIAhS5Pg7,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(qFghPAi5yz9Vf3NLwo0nuprl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	else: PLxHlAnj5rb = jZBtGcdApeKLEkb
	MPocSGUAWgaRmY,B387pSDQlZvhYs9OWVXzPtfLugw = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨ࡞ࡷࠫา"),NzlAQMRChm8J34urLwcUOn1f
	aJgKROwxj3 = jBbkfIJSDqcVwl8irzy4Z3O(u"࠴࠳࿪")*WRsuxHTjDgYCIpoMQzLFAtS8rikP if fOohwvakqi29cx0l3yt5mzrAGpEg else KKCrwPdOgGl(u"࠹࠱࿩")*WRsuxHTjDgYCIpoMQzLFAtS8rikP
	gpJ20FcP3sSjWhiIEuH = gybxTLFEw2*MPocSGUAWgaRmY
	if hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.startswith(CCWqR3dmtzw6xoIX41(u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪำ")): hTQ9zwprb4V0XWs3aE8FlUAjvY5utk = GTmHXIZUSdxRhMnqQKkO(u"ࠪ࠲ࡡࡺࠧิ")+hTQ9zwprb4V0XWs3aE8FlUAjvY5utk
	if UiO5y1oG8EXmD in PLxHlAnj5rb: FtJy56aSnszmA7QfMvlcZbiY = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.LOGERROR
	if PLxHlAnj5rb in [jZBtGcdApeKLEkb,UiO5y1oG8EXmD]: FGgCZybURVmONe7sXtL4xj2M = [hTQ9zwprb4V0XWs3aE8FlUAjvY5utk]
	elif PLxHlAnj5rb==gLv2Ra9NjkesOlrCF: FGgCZybURVmONe7sXtL4xj2M = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.split(B387pSDQlZvhYs9OWVXzPtfLugw)
	elif PLxHlAnj5rb==HHTRECw16nOjQcp79vL3mi24BfJ:
		fc1MjOx6b4FWTqt2BnJ5Asr = hTQ9zwprb4V0XWs3aE8FlUAjvY5utk.split(B387pSDQlZvhYs9OWVXzPtfLugw)
		FGgCZybURVmONe7sXtL4xj2M = [fc1MjOx6b4FWTqt2BnJ5Asr[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
		for OOWFun1mZvjJIiKlRSQgT624 in range(xD9WeoEAsX7,len(fc1MjOx6b4FWTqt2BnJ5Asr),H3OKMjDG1evnl4Ruiz):
			try: rljXSLWpf3F7BAe40Co8OaquzZYNTd = fc1MjOx6b4FWTqt2BnJ5Asr[OOWFun1mZvjJIiKlRSQgT624]+B387pSDQlZvhYs9OWVXzPtfLugw+fc1MjOx6b4FWTqt2BnJ5Asr[OOWFun1mZvjJIiKlRSQgT624+JZ45mOctiTszPNw1GVjxhep2Y(u"࠲࿫")]
			except: rljXSLWpf3F7BAe40Co8OaquzZYNTd = fc1MjOx6b4FWTqt2BnJ5Asr[OOWFun1mZvjJIiKlRSQgT624]
			FGgCZybURVmONe7sXtL4xj2M.append(rljXSLWpf3F7BAe40Co8OaquzZYNTd)
	M1o0sqxYjBz = FGgCZybURVmONe7sXtL4xj2M[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	for U5UbpdjACaHzQrZvB3lgk0YD8 in FGgCZybURVmONe7sXtL4xj2M[xD9WeoEAsX7:]:
		if PLxHlAnj5rb in [gLv2Ra9NjkesOlrCF,HHTRECw16nOjQcp79vL3mi24BfJ]: gpJ20FcP3sSjWhiIEuH += MPocSGUAWgaRmY
		M1o0sqxYjBz += b6JZWhsCvwOyV041EdQTcu+aJgKROwxj3+gpJ20FcP3sSjWhiIEuH+U5UbpdjACaHzQrZvB3lgk0YD8
	if PLxHlAnj5rb in [UiO5y1oG8EXmD,gLv2Ra9NjkesOlrCF]: M1o0sqxYjBz += b8sk5WyPoz03pXhRx
	M1o0sqxYjBz += KKCrwPdOgGl(u"ࠫࠥࡥࠧี")
	if ba49YvOK2Aw8Uhxt(u"ࠬࠫࠧึ") in M1o0sqxYjBz: M1o0sqxYjBz = WDg18QHF3rze(M1o0sqxYjBz)
	mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.log(M1o0sqxYjBz,level=FtJy56aSnszmA7QfMvlcZbiY)
	return
def II57PK1arVJLjERTkoG8p6Bmxq(UiRbWNAD9p1tIwZY):
	try: BlzEMV9YmO = nhGFNAkSgW2qopEYeT9jz8ULatl.connect(UiRbWNAD9p1tIwZY,check_same_thread=pLwgjkuTs6CS)
	except:
		if not oNlez5gnM9x2B4.path.exists(eC21aUbHsMhBQnfVypk8T):
			oNlez5gnM9x2B4.makedirs(eC21aUbHsMhBQnfVypk8T)
			BlzEMV9YmO = nhGFNAkSgW2qopEYeT9jz8ULatl.connect(UiRbWNAD9p1tIwZY,check_same_thread=pLwgjkuTs6CS)
	BlzEMV9YmO.text_factory = str
	Ew0cWnQIKTvoZDX = BlzEMV9YmO.cursor()
	Ew0cWnQIKTvoZDX.execute(nR0ok9zju84rFUQl1YC(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡶࡶࡲࡱࡦࡺࡩࡤࡡ࡬ࡲࡩ࡫ࡸ࠾ࡰࡲࠤࡀ࠭ื"))
	Ew0cWnQIKTvoZDX.execute(zWBnYSGIatjXVC(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳࠡ࠽ุࠪ"))
	Ew0cWnQIKTvoZDX.execute(lRKCWnNi0Edr984eI(u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉࠤࡀู࠭"))
	Ew0cWnQIKTvoZDX.execute(ba49YvOK2Aw8Uhxt(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡶࡽࡳࡩࡨࡳࡱࡱࡳࡺࡹ࠽ࡐࡈࡉࠤࡀฺ࠭"))
	BlzEMV9YmO.commit()
	return BlzEMV9YmO,Ew0cWnQIKTvoZDX
def YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,mUnIv2MufsWpzN,xASnYGMHkD8lE1KvF2rqtpXdB,zzmpYdoGRq4BvCbX8DcQfjVNr=()):
	GopHWf7DAQF = rrpMTe0FZlXBkD6jJfsKPboWhVd9
	timeout = kAz7WRYjrfGm(u"࠳࠳࿬")
	r7zaWb5PQCt3 = f7epsRlYtMz4.time()
	import UUtiyoRJ6h
	while f7epsRlYtMz4.time()-r7zaWb5PQCt3<timeout:
		try:
			if mUnIv2MufsWpzN: GopHWf7DAQF = Ew0cWnQIKTvoZDX.executemany(xASnYGMHkD8lE1KvF2rqtpXdB,zzmpYdoGRq4BvCbX8DcQfjVNr).fetchall()
			else: GopHWf7DAQF = Ew0cWnQIKTvoZDX.execute(xASnYGMHkD8lE1KvF2rqtpXdB,zzmpYdoGRq4BvCbX8DcQfjVNr).fetchall()
			break
		except Exception as MLxS28dZsnIeCi:
			if I6Bfzysrvb8DONZ(u"ࠪࡨࡦࡺࡡࡣࡣࡶࡩࠥ࡯ࡳࠡ࡮ࡲࡧࡰ࡫ࡤࠨ฻") not in str(MLxS28dZsnIeCi): break
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,rAYDiWlzm9MCU6x0GnROua(u"ࠫ࠳ࡢࡴࡅࡣࡷࡥࡧࡧࡳࡦࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡰࡴࡩ࡫ࡦࡦࠣࠤࠥ࠭฼")+UiRbWNAD9p1tIwZY+zWBnYSGIatjXVC(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡥࡹࡧࡦࡹࡹ࡯࡮ࡨࠢࡷ࡬࡮ࡹࠠࡴࡶࡤࡸࡪࡳࡥ࡯ࡶࠣࠤࠥ࠭฽")+xASnYGMHkD8lE1KvF2rqtpXdB)
		BlzEMV9YmO.commit()
		f7epsRlYtMz4.sleep(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠳࠲࠷࠻࿭"))
	BlzEMV9YmO.commit()
	return GopHWf7DAQF
def dYMLGvgfk4(UiRbWNAD9p1tIwZY,ZLlkb3hSRWseVwK,KIG3zOp5kFwurH2YdCgvR61jPiM,NB7AUL0peQcvM649EGtfwgYo=rrpMTe0FZlXBkD6jJfsKPboWhVd9):
	Y17JXktlo9gOwbc3LRxCI = vEZW7IfdB1P6u34yYGOQK(ZLlkb3hSRWseVwK)
	vVgpK5EQhZHfqbd = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(f9fOpCmLAEaW2Go(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ฾"))
	if KIG3zOp5kFwurH2YdCgvR61jPiM not in [zWBnYSGIatjXVC(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ฿"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡒࡏࡍ࡙࡚ࡅࡅࡡࡄࡐࡑ࠭เ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡋࡔࡕࡇࡍࡇࠪแ")] and UiRbWNAD9p1tIwZY==mmEuUR4JdaHtAsS and NB7AUL0peQcvM649EGtfwgYo!=CCWqR3dmtzw6xoIX41(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬโ"):
		if vVgpK5EQhZHfqbd==JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡘ࡚ࡏࡑࠩใ"): return Y17JXktlo9gOwbc3LRxCI
		zzpKCYP0jIqRFVXgoJtZaBWkThGr3c = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩไ"))
		if zzpKCYP0jIqRFVXgoJtZaBWkThGr3c==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ๅ"):
			rBLaP6i4jvs70wleySTcWq(UiRbWNAD9p1tIwZY,KIG3zOp5kFwurH2YdCgvR61jPiM,NB7AUL0peQcvM649EGtfwgYo)
			return Y17JXktlo9gOwbc3LRxCI
	pgNGl1Oh7LCv5 = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	if vVgpK5EQhZHfqbd==lRKCWnNi0Edr984eI(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨๆ"): pgNGl1Oh7LCv5 = XElcjkopwbuRJtK7I3Y
	BlzEMV9YmO,Ew0cWnQIKTvoZDX = II57PK1arVJLjERTkoG8p6Bmxq(UiRbWNAD9p1tIwZY)
	if pgNGl1Oh7LCv5: GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ็")+KIG3zOp5kFwurH2YdCgvR61jPiM+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁ่ࠫ")+str(KKydonNSglP1M08xw7O+pgNGl1Oh7LCv5)+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࠤࡀ้࠭"))
	GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,w9wfONXUP3(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎ๊ࠢࠥࠫ")+KIG3zOp5kFwurH2YdCgvR61jPiM+CCWqR3dmtzw6xoIX41(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂ๋ࠧ")+str(KKydonNSglP1M08xw7O)+CCWqR3dmtzw6xoIX41(u"࠭ࠠ࠼ࠩ์"))
	if NB7AUL0peQcvM649EGtfwgYo:
		GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,ba49YvOK2Aw8Uhxt(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬํ")+KIG3zOp5kFwurH2YdCgvR61jPiM+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ๎"),(str(NB7AUL0peQcvM649EGtfwgYo),))
		if GopHWf7DAQF:
			try:
				W0d8hJxSvNlqokHnugMU = ooIB8qKGdSvxWHOCXAefhgnw.decompress(GopHWf7DAQF[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib])
				Y17JXktlo9gOwbc3LRxCI = gfq3Q6ENyUTwoZ.loads(W0d8hJxSvNlqokHnugMU)
			except: pass
	else:
		GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,f9fOpCmLAEaW2Go(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ๏")+KIG3zOp5kFwurH2YdCgvR61jPiM+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࠦࠥࡁࠧ๐"))
		if GopHWf7DAQF:
			Y17JXktlo9gOwbc3LRxCI,MmEo2Xxdku3crVztWAlCLnigjP40Iy = {},[]
			for DiKamG3HtyV4whcfNXC26J,bo9ixEyvnlwmW in GopHWf7DAQF:
				aenBI6927xL8SojFDwbuVNMCU4H = ooIB8qKGdSvxWHOCXAefhgnw.decompress(bo9ixEyvnlwmW)
				bo9ixEyvnlwmW = gfq3Q6ENyUTwoZ.loads(aenBI6927xL8SojFDwbuVNMCU4H)
				Y17JXktlo9gOwbc3LRxCI[DiKamG3HtyV4whcfNXC26J] = bo9ixEyvnlwmW
				MmEo2Xxdku3crVztWAlCLnigjP40Iy.append(DiKamG3HtyV4whcfNXC26J)
			if MmEo2Xxdku3crVztWAlCLnigjP40Iy:
				Y17JXktlo9gOwbc3LRxCI[W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬ๑")] = MmEo2Xxdku3crVztWAlCLnigjP40Iy
				if ZLlkb3hSRWseVwK==slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡲࡩࡴࡶࠪ๒"): Y17JXktlo9gOwbc3LRxCI = MmEo2Xxdku3crVztWAlCLnigjP40Iy
	BlzEMV9YmO.close()
	return Y17JXktlo9gOwbc3LRxCI
def JZvkPS1QBs436RujaCnh9b5x2(UiRbWNAD9p1tIwZY,KIG3zOp5kFwurH2YdCgvR61jPiM,NB7AUL0peQcvM649EGtfwgYo,Y17JXktlo9gOwbc3LRxCI,JLmolRn8tIaB2364b,BBFQupYyl7jXWteE2TR=pLwgjkuTs6CS):
	vVgpK5EQhZHfqbd = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(pL73X0MYajJQG4n1qgD(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ๓"))
	if vVgpK5EQhZHfqbd==Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ๔") and JLmolRn8tIaB2364b>XElcjkopwbuRJtK7I3Y: JLmolRn8tIaB2364b = XElcjkopwbuRJtK7I3Y
	if BBFQupYyl7jXWteE2TR:
		YA8zxD2L9ielGsFuIW4vh,wzr0JNiAOxbySMf5WU6gvdPID = [],[]
		for r6dVWlzDj9va0FxqfkOwLYZEmP in range(len(NB7AUL0peQcvM649EGtfwgYo)):
			W0d8hJxSvNlqokHnugMU = gfq3Q6ENyUTwoZ.dumps(Y17JXktlo9gOwbc3LRxCI[r6dVWlzDj9va0FxqfkOwLYZEmP])
			IIZO8a7BrpL = ooIB8qKGdSvxWHOCXAefhgnw.compress(W0d8hJxSvNlqokHnugMU)
			YA8zxD2L9ielGsFuIW4vh.append((NB7AUL0peQcvM649EGtfwgYo[r6dVWlzDj9va0FxqfkOwLYZEmP],))
			wzr0JNiAOxbySMf5WU6gvdPID.append((JLmolRn8tIaB2364b+KKydonNSglP1M08xw7O,str(NB7AUL0peQcvM649EGtfwgYo[r6dVWlzDj9va0FxqfkOwLYZEmP]),IIZO8a7BrpL))
	else:
		W0d8hJxSvNlqokHnugMU = gfq3Q6ENyUTwoZ.dumps(Y17JXktlo9gOwbc3LRxCI)
		tUxkgZRWj2u98Q5 = ooIB8qKGdSvxWHOCXAefhgnw.compress(W0d8hJxSvNlqokHnugMU)
	BlzEMV9YmO,Ew0cWnQIKTvoZDX = II57PK1arVJLjERTkoG8p6Bmxq(UiRbWNAD9p1tIwZY)
	GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩ๕")+KIG3zOp5kFwurH2YdCgvR61jPiM+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࠥࠤ࠭࡫ࡸࡱ࡫ࡵࡽ࠱ࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠬࠤࡀ࠭๖"))
	if BBFQupYyl7jXWteE2TR:
		GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,NFGqKBLtvUZn1S3dau,pbmKZA1w7L4zHjOM(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ๗")+KIG3zOp5kFwurH2YdCgvR61jPiM+zWBnYSGIatjXVC(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ๘"),YA8zxD2L9ielGsFuIW4vh)
		GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,NFGqKBLtvUZn1S3dau,w9wfONXUP3(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ๙")+KIG3zOp5kFwurH2YdCgvR61jPiM+w9wfONXUP3(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ๚"),wzr0JNiAOxbySMf5WU6gvdPID)
	else:
		if JLmolRn8tIaB2364b:
			GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ๛")+KIG3zOp5kFwurH2YdCgvR61jPiM+ba49YvOK2Aw8Uhxt(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ๜"),(str(NB7AUL0peQcvM649EGtfwgYo),))
			GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,f9fOpCmLAEaW2Go(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ๝")+KIG3zOp5kFwurH2YdCgvR61jPiM+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ๞"),(JLmolRn8tIaB2364b+KKydonNSglP1M08xw7O,str(NB7AUL0peQcvM649EGtfwgYo),tUxkgZRWj2u98Q5))
		else:
			GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,jBbkfIJSDqcVwl8irzy4Z3O(u"࡚ࠫࡖࡄࡂࡖࡈࠤࠧ࠭๟")+KIG3zOp5kFwurH2YdCgvR61jPiM+pL73X0MYajJQG4n1qgD(u"ࠬࠨࠠࡔࡇࡗࠤࡩࡧࡴࡢࠢࡀࠤࡄࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ๠"),(tUxkgZRWj2u98Q5,str(NB7AUL0peQcvM649EGtfwgYo)))
	BlzEMV9YmO.close()
	return
def rBLaP6i4jvs70wleySTcWq(UiRbWNAD9p1tIwZY,KIG3zOp5kFwurH2YdCgvR61jPiM,NB7AUL0peQcvM649EGtfwgYo=rrpMTe0FZlXBkD6jJfsKPboWhVd9):
	BlzEMV9YmO,Ew0cWnQIKTvoZDX = II57PK1arVJLjERTkoG8p6Bmxq(UiRbWNAD9p1tIwZY)
	if NB7AUL0peQcvM649EGtfwgYo==rrpMTe0FZlXBkD6jJfsKPboWhVd9: GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,CCWqR3dmtzw6xoIX41(u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ๡")+KIG3zOp5kFwurH2YdCgvR61jPiM+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࠣࠢ࠾ࠫ๢"))
	else:
		dUR9hi2HlDywJ3gpMjLbm = (str(NB7AUL0peQcvM649EGtfwgYo),)
		if I6Bfzysrvb8DONZ(u"ࠨࠧࠪ๣") in NB7AUL0peQcvM649EGtfwgYo: GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ๤")+KIG3zOp5kFwurH2YdCgvR61jPiM+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡱ࡯࡫ࡦࠢࡂࠤࡀ࠭๥"),dUR9hi2HlDywJ3gpMjLbm)
		else: GopHWf7DAQF = YVIWMDPKg8JdhQXq9(UiRbWNAD9p1tIwZY,BlzEMV9YmO,Ew0cWnQIKTvoZDX,pLwgjkuTs6CS,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ๦")+KIG3zOp5kFwurH2YdCgvR61jPiM+I6Bfzysrvb8DONZ(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ๧"),dUR9hi2HlDywJ3gpMjLbm)
	BlzEMV9YmO.close()
	return
class qJTpto6QjUz4KhB1F2ls(): pass
class MMchHsDZqFwGLgO5yjQ7Xm(qJTpto6QjUz4KhB1F2ls):
	def __init__(RRJ40CMUDwHiEQ):
		RRJ40CMUDwHiEQ.url = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		RRJ40CMUDwHiEQ.code = -JZ45mOctiTszPNw1GVjxhep2Y(u"࠽࠾࿮")
		RRJ40CMUDwHiEQ.reason = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		RRJ40CMUDwHiEQ.content = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		RRJ40CMUDwHiEQ.headers = {}
		RRJ40CMUDwHiEQ.cookies = {}
		RRJ40CMUDwHiEQ.succeeded = pLwgjkuTs6CS
def vEZW7IfdB1P6u34yYGOQK(YYTAkfz3NaQrLuCyRE):
	if YYTAkfz3NaQrLuCyRE==djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡤࡪࡥࡷࠫ๨"): Y17JXktlo9gOwbc3LRxCI = {}
	elif YYTAkfz3NaQrLuCyRE==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧ࡭࡫ࡶࡸࠬ๩"): Y17JXktlo9gOwbc3LRxCI = []
	elif YYTAkfz3NaQrLuCyRE==pYeVwat64v(u"ࠨࡶࡸࡴࡱ࡫ࠧ๪"): Y17JXktlo9gOwbc3LRxCI = ()
	elif YYTAkfz3NaQrLuCyRE==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡶࡸࡷ࠭๫"): Y17JXktlo9gOwbc3LRxCI = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	elif YYTAkfz3NaQrLuCyRE==awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪ࡭ࡳࡺࠧ๬"): Y17JXktlo9gOwbc3LRxCI = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	elif YYTAkfz3NaQrLuCyRE==slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡧࡵ࡯࡭ࠩ๭"): Y17JXktlo9gOwbc3LRxCI = rrpMTe0FZlXBkD6jJfsKPboWhVd9
	elif YYTAkfz3NaQrLuCyRE==slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ๮"): Y17JXktlo9gOwbc3LRxCI = MMchHsDZqFwGLgO5yjQ7Xm()
	elif not YYTAkfz3NaQrLuCyRE: Y17JXktlo9gOwbc3LRxCI = rrpMTe0FZlXBkD6jJfsKPboWhVd9
	else: Y17JXktlo9gOwbc3LRxCI = rrpMTe0FZlXBkD6jJfsKPboWhVd9
	return Y17JXktlo9gOwbc3LRxCI
def LTbKCxY4nX92jSDy7t(a0FGdpIm98YbENU7Ots4zH):
	ru7AFDMwTYjGUXhfo = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(KKCrwPdOgGl(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩ๯"))
	JbC2ZL4shGiDE = drzqWFkSHD.AV_CLIENT_IDS.splitlines()
	NgRC8iIZUuHJ76Qj5 = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	NWDBfMliTaYoO73Vgr0mXG5pbuAyL = len(a0FGdpIm98YbENU7Ots4zH)
	rcgCYduJB6nePMShH3sLt1QFqyVR = [pLwgjkuTs6CS]*NWDBfMliTaYoO73Vgr0mXG5pbuAyL
	for pCkUtMyO3B7lQWJY2sZjSPz5gTExq in [KKydonNSglP1M08xw7O,KKydonNSglP1M08xw7O-V7DSdHck4Fjp]:
		Y7EbdgFmsDGSWjUxiH9KTnBA = str(pCkUtMyO3B7lQWJY2sZjSPz5gTExq*pL73X0MYajJQG4n1qgD(u"࠷࠰࠱࠲࠳࠴࠳࠶࿰")/kAz7WRYjrfGm(u"࠹࠹࠲࠱࠲࠳࿯"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib:Zb5cNeHWi6jP9SCYtUgR(u"࠴࿱")]
		if Y7EbdgFmsDGSWjUxiH9KTnBA!=NgRC8iIZUuHJ76Qj5:
			for OOWFun1mZvjJIiKlRSQgT624 in range(NWDBfMliTaYoO73Vgr0mXG5pbuAyL):
				if not rcgCYduJB6nePMShH3sLt1QFqyVR[OOWFun1mZvjJIiKlRSQgT624]:
					vNufqGIEFj9c4MaQlkKTdLD = pLwgjkuTs6CS
					for ZZoza84ncFwDe6mU1TYuMGX9t in JbC2ZL4shGiDE:
						ihr0dpYk2C7XJ59Rv6fI = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࡙ࠧ࠳࠼ࠫ๰")+a0FGdpIm98YbENU7Ots4zH[OOWFun1mZvjJIiKlRSQgT624]+zWBnYSGIatjXVC(u"ࠨ࠳࠻ࡁࠬ๱")+ZZoza84ncFwDe6mU1TYuMGX9t[-awSUTRNMkdIW7sFEvnHD2mLY(u"࠳࠶࿲"):]+FLRQJnBHTvsXU+Y7EbdgFmsDGSWjUxiH9KTnBA
						ihr0dpYk2C7XJ59Rv6fI = s6erOG0HkXaS8L.md5(ihr0dpYk2C7XJ59Rv6fI.encode(RMGz7OiD1e30P)).hexdigest()[:KKCrwPdOgGl(u"࠵࠵࿳")]
						if ihr0dpYk2C7XJ59Rv6fI in ru7AFDMwTYjGUXhfo:
							vNufqGIEFj9c4MaQlkKTdLD = NFGqKBLtvUZn1S3dau
							break
					rcgCYduJB6nePMShH3sLt1QFqyVR[OOWFun1mZvjJIiKlRSQgT624] = vNufqGIEFj9c4MaQlkKTdLD
		NgRC8iIZUuHJ76Qj5 = Y7EbdgFmsDGSWjUxiH9KTnBA
	return rcgCYduJB6nePMShH3sLt1QFqyVR
class cyeCjzpOrRwME(yy7k5OazQ2E1AfpXvKoiglLc):
	def __init__(RRJ40CMUDwHiEQ): pass
	def PtbsZGfnwepAK4SzOD(RRJ40CMUDwHiEQ,NpzdIJ0BxQjkh):
		RRJ40CMUDwHiEQ.xDuzUJsp7LP = CCWqR3dmtzw6xoIX41(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ๲") if drzqWFkSHD.nt9ZocbLGBOMx2 else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		RRJ40CMUDwHiEQ.NpzdIJ0BxQjkh = NpzdIJ0BxQjkh
		if not drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3:
			import YnWpIJVfFz
			YnWpIJVfFz.ZrQ1ou8I57L2EG9jwgiT3PY(qJ0xtbICjHuM45nmhO7fgpkr)
	def onPlayBackStopped(RRJ40CMUDwHiEQ): RRJ40CMUDwHiEQ.xDuzUJsp7LP = W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ๳")
	def onPlayBackError(RRJ40CMUDwHiEQ): RRJ40CMUDwHiEQ.xDuzUJsp7LP = w9wfONXUP3(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ๴")
	def onPlayBackEnded(RRJ40CMUDwHiEQ): RRJ40CMUDwHiEQ.xDuzUJsp7LP = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ๵")
	def onPlayBackStarted(RRJ40CMUDwHiEQ):
		RRJ40CMUDwHiEQ.xDuzUJsp7LP = GTmHXIZUSdxRhMnqQKkO(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ๶")
		dMuq0pKzcLXfUnCP = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=RRJ40CMUDwHiEQ.mmsTueJYlVEXq)
		dMuq0pKzcLXfUnCP.start()
	def onAVStarted(RRJ40CMUDwHiEQ):
		if drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3: RRJ40CMUDwHiEQ.xDuzUJsp7LP = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ๷")
		else: RRJ40CMUDwHiEQ.xDuzUJsp7LP = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ๸")
	def mmsTueJYlVEXq(RRJ40CMUDwHiEQ):
		SnzyBOw86DZtr0A = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		while not eval(w9wfONXUP3(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧ๹"),{B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡼࡧࡳࡣࠨ๺"):mMaH8ZsXEch3TyYi0PA1gNSxCzLUW}) and RRJ40CMUDwHiEQ.xDuzUJsp7LP==JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ๻"):
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.sleep(YzlId3Fs6vpehcbLGj0UaO(u"࠴࠴࠵࠶࿴"))
			SnzyBOw86DZtr0A += xD9WeoEAsX7
			if SnzyBOw86DZtr0A>MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠺࠵࿵"): return
		if drzqWFkSHD.nt9ZocbLGBOMx2: RRJ40CMUDwHiEQ.xDuzUJsp7LP = W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭๼")
		elif drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3: RRJ40CMUDwHiEQ.xDuzUJsp7LP = YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ๽")
		elif drzqWFkSHD.OpUqQARsFDdGT6gJ5HwI4KYV:
			import YnWpIJVfFz
			RRJ40CMUDwHiEQ.xDuzUJsp7LP = pbmKZA1w7L4zHjOM(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ๾")
			tvBhiQp5kIbKHMP6f(CCWqR3dmtzw6xoIX41(u"ࠨࡵࡷࡳࡵ࠭๿"),NFGqKBLtvUZn1S3dau)
			P2Oq7ua5N19MBJpswydGgl8H = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=YnWpIJVfFz.CZfMVvo97a2D1JPUuTQknpi4NHt,args=(RRJ40CMUDwHiEQ.NpzdIJ0BxQjkh,)).start()
			Vm4WPu18riGjK96 = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=YnWpIJVfFz.h2jp8tao1fyMTGXJHi3WgV).start()
		else: RRJ40CMUDwHiEQ.xDuzUJsp7LP = I6Bfzysrvb8DONZ(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ຀")
def yqhKrM97Wt6j4YxwflCe8():
	aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	uLkcpvjZgf = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(I6Bfzysrvb8DONZ(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩກ"))
	try:
		zWvERMkrqTp48ygAXSHbfjeODi = open(I6Bfzysrvb8DONZ(u"ࠫ࠴ࡶࡲࡰࡥ࠲ࡧࡵࡻࡩ࡯ࡨࡲࠫຂ"),CCWqR3dmtzw6xoIX41(u"ࠬࡸࡢࠨ຃")).read()
		if fOohwvakqi29cx0l3yt5mzrAGpEg: zWvERMkrqTp48ygAXSHbfjeODi = zWvERMkrqTp48ygAXSHbfjeODi.decode(RMGz7OiD1e30P)
		GxiMPbrS5Yel9IQD = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"࠭ࡓࡦࡴ࡬ࡥࡱ࠴ࠪࡀ࠼ࠣࠬ࠳࠰࠿ࠪࠦࠪຄ"),zWvERMkrqTp48ygAXSHbfjeODi,AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if GxiMPbrS5Yel9IQD: aPbHT8pzqM9dB3Zk7A2ViFUfJ = GxiMPbrS5Yel9IQD[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	except: pass
	try:
		import subprocess as oosjxt8yqQ1
		M6fj2psaiE3WkQDULq0xyghZn = oosjxt8yqQ1.Popen(w9wfONXUP3(u"ࠧࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡝ࠦࠢࠡ࠱ࡶࡸࡴࡸࡡࡨࡧ࠲ࡩࡲࡻ࡬ࡢࡶࡨࡨ࠴࠶ࠠ࠼ࠢࡶࡸࡦࡺࠠ࠮ࡥࠣࠦࠥࠫࡗࠡࠤࠣ࠳ࡻࡧࡲ࠰࡮ࡲ࡫ࠬ຅"),shell=NFGqKBLtvUZn1S3dau,stdin=oosjxt8yqQ1.PIPE,stdout=oosjxt8yqQ1.PIPE,stderr=oosjxt8yqQ1.PIPE)
		DClJk5zAB9 = M6fj2psaiE3WkQDULq0xyghZn.stdout.read()
		if DClJk5zAB9:
			if fOohwvakqi29cx0l3yt5mzrAGpEg:
				DClJk5zAB9 = DClJk5zAB9.decode(RMGz7OiD1e30P,CCWqR3dmtzw6xoIX41(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨຆ"))
			na89mPXId3uhHox = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠩࠣࠬࡡࡪࡻ࠲࠲ࢀ࠭ࠥ࠭ງ"),DClJk5zAB9,AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
			if na89mPXId3uhHox: JJy7oKAg8TOIEraQ = min(na89mPXId3uhHox)
	except: pass
	return uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ
def ih5mrq2OAK3tXFIpfcJRVe4Z(dEu4Ht1O6GsIXWAhRKDSgZMzbw2FUN=NFGqKBLtvUZn1S3dau,Zk8VSHPBsXfoepqw9KidyG5Ia=kAz7WRYjrfGm(u"࠸࠸࿶")):
	FYBJM37xo0d9jatgvR5wTGu = NFGqKBLtvUZn1S3dau
	if dEu4Ht1O6GsIXWAhRKDSgZMzbw2FUN:
		a7yuz8cxKiQhAldkoD1b6HJF = dYMLGvgfk4(mmEuUR4JdaHtAsS,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡰ࡮ࡹࡴࠨຈ"),kAz7WRYjrfGm(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧຉ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪຊ"))
		if a7yuz8cxKiQhAldkoD1b6HJF:
			Do5A9e0c4Om,RPUFIMvnxub7AiC95do3N,jHl12DYAxw,UULrN410if68gyFOwQvBGA3M = a7yuz8cxKiQhAldkoD1b6HJF
			FYBJM37xo0d9jatgvR5wTGu = dYMLGvgfk4(mmEuUR4JdaHtAsS,GTmHXIZUSdxRhMnqQKkO(u"࠭࡬ࡪࡵࡷࠫ຋"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪຌ"),f9fOpCmLAEaW2Go(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧຍ"))
			if FYBJM37xo0d9jatgvR5wTGu: uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ = FYBJM37xo0d9jatgvR5wTGu
			else: uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ = yqhKrM97Wt6j4YxwflCe8()
			if (RPUFIMvnxub7AiC95do3N,jHl12DYAxw,UULrN410if68gyFOwQvBGA3M)==(uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ):
				QdqfVrKtDAGvFzeob = b8sk5WyPoz03pXhRx.join(Do5A9e0c4Om)
				return QdqfVrKtDAGvFzeob
	if FYBJM37xo0d9jatgvR5wTGu: uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ = yqhKrM97Wt6j4YxwflCe8()
	global kt5Pom9KnuA,BBDeGjiTqRCW5rE
	kt5Pom9KnuA,BBDeGjiTqRCW5rE,yyxMweamsjvGncY7PgkLdzQZWro64 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Zk8VSHPBsXfoepqw9KidyG5Ia = Zk8VSHPBsXfoepqw9KidyG5Ia//H3OKMjDG1evnl4Ruiz
	spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=YZc8nxQWX5wsVb6mSKCo).start()
	spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=MsYt21x6DQ3EGKoBUO0HcFgA9lpivJ).start()
	for r6dVWlzDj9va0FxqfkOwLYZEmP in range(jBbkfIJSDqcVwl8irzy4Z3O(u"࠷࠰࿷")):
		f7epsRlYtMz4.sleep(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠰࠯࠷࿸"))
		if not yyxMweamsjvGncY7PgkLdzQZWro64:
			try:
				gWwPf2IjekGhEdCAZM9SrFKsqzR8 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡑࡩࡹࡽ࡯ࡳ࡭࠱ࡑࡦࡩࡁࡥࡦࡵࡩࡸࡹࠧຎ"))
				if gWwPf2IjekGhEdCAZM9SrFKsqzR8.count(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪ࠾ࠬຏ"))==Hip2swoNbVaZ30OrStQR1lF and gWwPf2IjekGhEdCAZM9SrFKsqzR8.count(w9wfONXUP3(u"ࠫ࠵࠭ຐ"))<slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠺࿹"):
					gWwPf2IjekGhEdCAZM9SrFKsqzR8 = gWwPf2IjekGhEdCAZM9SrFKsqzR8.lower().replace(zWBnYSGIatjXVC(u"ࠬࡀࠧຑ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
					yyxMweamsjvGncY7PgkLdzQZWro64 = str(int(gWwPf2IjekGhEdCAZM9SrFKsqzR8,f9fOpCmLAEaW2Go(u"࠳࠹࿺")))
			except: pass
		if kt5Pom9KnuA and BBDeGjiTqRCW5rE and yyxMweamsjvGncY7PgkLdzQZWro64: break
	dBtDMU2QfmZ6PTwhcevk3aIz9AgrjE = [BBDeGjiTqRCW5rE,kt5Pom9KnuA,yyxMweamsjvGncY7PgkLdzQZWro64,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࠰࠱࠳࠴࠶࠷࠹࠳࠵࠶࠸࠹࠻࠼࠷࠸ࠩຒ")]
	if aPbHT8pzqM9dB3Zk7A2ViFUfJ or JJy7oKAg8TOIEraQ:
		xhRJKL06NwUSbfE4Yr9i = [(gybxTLFEw2,aPbHT8pzqM9dB3Zk7A2ViFUfJ),(Hip2swoNbVaZ30OrStQR1lF,JJy7oKAg8TOIEraQ)]
		for LE3wykUGQWTR7KD0crlC5F968hsJX,aqKOPHi3WXSMRIoE in xhRJKL06NwUSbfE4Yr9i:
			aqKOPHi3WXSMRIoE = aqKOPHi3WXSMRIoE.strip(f9fOpCmLAEaW2Go(u"ࠧ࠱ࠩຓ"))
			if aqKOPHi3WXSMRIoE:
				if fOohwvakqi29cx0l3yt5mzrAGpEg: aqKOPHi3WXSMRIoE = aqKOPHi3WXSMRIoE.encode(RMGz7OiD1e30P)
				aqKOPHi3WXSMRIoE = str(int(s6erOG0HkXaS8L.md5(aqKOPHi3WXSMRIoE).hexdigest(),awSUTRNMkdIW7sFEvnHD2mLY(u"࠶࠺࿻")))
				ZI91ywsbxX2iMOQeoTud = [int(aqKOPHi3WXSMRIoE[zASjxuYBPUao:zASjxuYBPUao+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠵࠺࿼")]) for zASjxuYBPUao in range(len(aqKOPHi3WXSMRIoE)) if zASjxuYBPUao%KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠵࠺࿼")==nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				dBtDMU2QfmZ6PTwhcevk3aIz9AgrjE[LE3wykUGQWTR7KD0crlC5F968hsJX-xD9WeoEAsX7] = str(sum(ZI91ywsbxX2iMOQeoTud))
	JbC2ZL4shGiDE,YYBT9ZHkFmI1LzAVn2huR = [],pLwgjkuTs6CS
	for ZN0SwhX7WiYlueyxF,ZI91ywsbxX2iMOQeoTud in enumerate(dBtDMU2QfmZ6PTwhcevk3aIz9AgrjE):
		if not ZI91ywsbxX2iMOQeoTud: continue
		if YYBT9ZHkFmI1LzAVn2huR and ZI91ywsbxX2iMOQeoTud==dBtDMU2QfmZ6PTwhcevk3aIz9AgrjE[-xD9WeoEAsX7]: continue
		YYBT9ZHkFmI1LzAVn2huR = NFGqKBLtvUZn1S3dau
		ZI91ywsbxX2iMOQeoTud = pbmKZA1w7L4zHjOM(u"ࠨ࠲ࠪດ")*Zk8VSHPBsXfoepqw9KidyG5Ia+ZI91ywsbxX2iMOQeoTud
		ZI91ywsbxX2iMOQeoTud = ZI91ywsbxX2iMOQeoTud[-Zk8VSHPBsXfoepqw9KidyG5Ia:]
		qD59LGbCftsOplaoJw12dQM0m4,geQCT9mlWOJj2HS = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		sbglpBi0Lfm4HrY7UW = str(int(W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࠼ࠫຕ")*(Zk8VSHPBsXfoepqw9KidyG5Ia+xD9WeoEAsX7))-int(ZI91ywsbxX2iMOQeoTud))[-Zk8VSHPBsXfoepqw9KidyG5Ia:]
		for OOWFun1mZvjJIiKlRSQgT624 in list(range(nUaVQsoA6EXcK4Odht5wCge0J8Pib,Zk8VSHPBsXfoepqw9KidyG5Ia,gybxTLFEw2)):
			qD59LGbCftsOplaoJw12dQM0m4 += sbglpBi0Lfm4HrY7UW[OOWFun1mZvjJIiKlRSQgT624:OOWFun1mZvjJIiKlRSQgT624+gybxTLFEw2]+f9fOpCmLAEaW2Go(u"ࠪ࠱ࠬຖ")
			geQCT9mlWOJj2HS += str(sum(map(int,ZI91ywsbxX2iMOQeoTud[OOWFun1mZvjJIiKlRSQgT624:OOWFun1mZvjJIiKlRSQgT624+gybxTLFEw2]))%zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠶࠶࿽"))
		ZZoza84ncFwDe6mU1TYuMGX9t = str(ZN0SwhX7WiYlueyxF)+qD59LGbCftsOplaoJw12dQM0m4+geQCT9mlWOJj2HS
		JbC2ZL4shGiDE.append(ZZoza84ncFwDe6mU1TYuMGX9t)
	KqwQPUcrmv,Do5A9e0c4Om = [],[]
	for user in JbC2ZL4shGiDE:
		count = str(str(JbC2ZL4shGiDE).count(user[ba49YvOK2Aw8Uhxt(u"࠷࿾"):]))
		KqwQPUcrmv.append(count+user)
	KqwQPUcrmv = sorted(KqwQPUcrmv,reverse=NFGqKBLtvUZn1S3dau,key=lambda key: key[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
	for user in KqwQPUcrmv: Do5A9e0c4Om.append(user[xD9WeoEAsX7:])
	JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧທ"),w9wfONXUP3(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫຘ"),[uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ],BRMcS58jIbyDQWGYLk1term)
	JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,KKCrwPdOgGl(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩນ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡔࡋࡗࡉࡘࡥࡃࡉࡇࡆࡏࠬບ"),[Do5A9e0c4Om,uLkcpvjZgf,aPbHT8pzqM9dB3Zk7A2ViFUfJ,JJy7oKAg8TOIEraQ],BRMcS58jIbyDQWGYLk1term)
	for user in drzqWFkSHD.BADCOMMONIDS:
		if user in Do5A9e0c4Om: Do5A9e0c4Om.remove(user)
	QdqfVrKtDAGvFzeob = b8sk5WyPoz03pXhRx.join(Do5A9e0c4Om)
	return QdqfVrKtDAGvFzeob
def YZc8nxQWX5wsVb6mSKCo():
	global kt5Pom9KnuA
	try:
		import getmac82 as mnRPUb9jXTeIQs
		lTijOJrhuxb = mnRPUb9jXTeIQs.get_mac_address()
		if lTijOJrhuxb.count(w9wfONXUP3(u"ࠨ࠼ࠪປ"))==Hip2swoNbVaZ30OrStQR1lF and lTijOJrhuxb.count(pYeVwat64v(u"ࠩ࠳ࠫຜ"))<Zb5cNeHWi6jP9SCYtUgR(u"࠹࿿"):
			lTijOJrhuxb = lTijOJrhuxb.lower().replace(rAYDiWlzm9MCU6x0GnROua(u"ࠪ࠾ࠬຝ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			kt5Pom9KnuA = str(int(lTijOJrhuxb,W2Vv30i8qxSuItfsolPLdFZA(u"࠲࠸က")))
	except: pass
	return
def MsYt21x6DQ3EGKoBUO0HcFgA9lpivJ():
	global BBDeGjiTqRCW5rE
	try:
		import getmac95 as m4ikIAjBrtYp
		KegRbaWSyiGrsxFLpENqOJDXZV = m4ikIAjBrtYp.get_mac_address()
		if KegRbaWSyiGrsxFLpENqOJDXZV.count(KKCrwPdOgGl(u"ࠫ࠿࠭ພ"))==Hip2swoNbVaZ30OrStQR1lF and KegRbaWSyiGrsxFLpENqOJDXZV.count(hWRvZOYtjme9QNnV41u0Mswb(u"ࠬ࠶ࠧຟ"))<f9fOpCmLAEaW2Go(u"࠻ခ"):
			KegRbaWSyiGrsxFLpENqOJDXZV = KegRbaWSyiGrsxFLpENqOJDXZV.lower().replace(pYeVwat64v(u"࠭࠺ࠨຠ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			BBDeGjiTqRCW5rE = str(int(KegRbaWSyiGrsxFLpENqOJDXZV,YzlId3Fs6vpehcbLGj0UaO(u"࠴࠺ဂ")))
	except: pass
	return
def iL1QfsexHqmDz0FpjhrZ6nKSYgok39(YYTAkfz3NaQrLuCyRE,HHyOcE4DNohvx0MaIJZ1b,Y17JXktlo9gOwbc3LRxCI,MtT2SKcnYZHN6PzJhqAeWx17,KS8ozxwIk1EB4srRJtgHfbVp2AhQ,ffpPJZ1jr2HDB6qvm0da):
	aNXRWYnbow7s8fpvLVK = str(MtT2SKcnYZHN6PzJhqAeWx17)[nUaVQsoA6EXcK4Odht5wCge0J8Pib:pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠶࠺࠶ဃ")].replace(b8sk5WyPoz03pXhRx,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࡝࡞ࡱࠫມ")).replace(b6JZWhsCvwOyV041EdQTcu,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡞࡟ࡶࠬຢ")).replace(NNJKRTY8GlM29ezbCgPiXd,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(NzlAQMRChm8J34urLwcUOn1f,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	if len(str(MtT2SKcnYZHN6PzJhqAeWx17))>slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠷࠻࠰င"): aNXRWYnbow7s8fpvLVK = aNXRWYnbow7s8fpvLVK+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࠣ࠲࠳࠴ࠧຣ")
	bo9ixEyvnlwmW = GTmHXIZUSdxRhMnqQKkO(u"ࠪ࠲࠳࠴ࠧ຤")
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࠭ລ")+YYTAkfz3NaQrLuCyRE+Zb5cNeHWi6jP9SCYtUgR(u"ࠬࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ຦")+HHyOcE4DNohvx0MaIJZ1b+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨວ")+KS8ozxwIk1EB4srRJtgHfbVp2AhQ+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡵࡪࡲࡨ࠿࡛ࠦࠡࠩຨ")+ffpPJZ1jr2HDB6qvm0da+f9fOpCmLAEaW2Go(u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫຩ")+str(aNXRWYnbow7s8fpvLVK)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࠣࡡࠥࠦࠠࡅࡣࡷࡥ࠿࡛ࠦࠡࠩສ")+bo9ixEyvnlwmW+I6Bfzysrvb8DONZ(u"ࠪࠤࡢ࠭ຫ"))
	return
def nXGUokCph4aZJ(ffpPJZ1jr2HDB6qvm0da,ppJF7uRhD245fxU,Y17JXktlo9gOwbc3LRxCI=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MtT2SKcnYZHN6PzJhqAeWx17=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KS8ozxwIk1EB4srRJtgHfbVp2AhQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if fOohwvakqi29cx0l3yt5mzrAGpEg: import urllib.request as OtYjsD3B485AzLgxH
	else: import urllib2 as OtYjsD3B485AzLgxH
	if not MtT2SKcnYZHN6PzJhqAeWx17: MtT2SKcnYZHN6PzJhqAeWx17 = {CCWqR3dmtzw6xoIX41(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨຬ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
	if not Y17JXktlo9gOwbc3LRxCI: Y17JXktlo9gOwbc3LRxCI = {}
	DDSLTxjzXdEYogh6U8a = Y17JXktlo9gOwbc3LRxCI
	ff83qUC4GsOLdp7j9hzriKSAPWQkex = ppJF7uRhD245fxU in drzqWFkSHD.SITESURLS[lRKCWnNi0Edr984eI(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬອ")]
	if ff83qUC4GsOLdp7j9hzriKSAPWQkex:
		ffpPJZ1jr2HDB6qvm0da = CCWqR3dmtzw6xoIX41(u"࠭ࡐࡐࡕࡗࠫຮ")
		MtT2SKcnYZHN6PzJhqAeWx17[pYeVwat64v(u"ࠧࡂࡘ࠰ࡉࡳࡩࡲࡺࡲࡷ࡭ࡴࡴࠧຯ")] = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡘࡨࡶࡸ࡯࡯࡯ࠢ࠴࠲࠵࠭ະ")
		fJd2LlUcKCXvDQEhewWasjAkpBTgH = WWNb0XnUxOPL9gF.dumps(Y17JXktlo9gOwbc3LRxCI)
		import YnWpIJVfFz
		DDSLTxjzXdEYogh6U8a = YnWpIJVfFz.cNDxZnu5BPf(fJd2LlUcKCXvDQEhewWasjAkpBTgH,rAYDiWlzm9MCU6x0GnROua(u"࠾࠱࠳࠹࠷࠽࠸࠻࠶စ"))
		ppJF7uRhD245fxU = ppJF7uRhD245fxU+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡂࡹࡸ࡫ࡲ࠾ࠩັ")+QYhMUcDf60
	elif ffpPJZ1jr2HDB6qvm0da==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡋࡊ࡚ࠧາ"):
		ppJF7uRhD245fxU = ppJF7uRhD245fxU+W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡄ࠭ຳ")+g726UBevLKbpyh8o35Z4fdPiRrn9uG(Y17JXktlo9gOwbc3LRxCI)
		DDSLTxjzXdEYogh6U8a = rrpMTe0FZlXBkD6jJfsKPboWhVd9
	elif ffpPJZ1jr2HDB6qvm0da==YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡖࡏࡔࡖࠪິ") and hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡪࡴࡱࡱࠫີ") in str(MtT2SKcnYZHN6PzJhqAeWx17):
		Y17JXktlo9gOwbc3LRxCI = WWNb0XnUxOPL9gF.dumps(Y17JXktlo9gOwbc3LRxCI)
		DDSLTxjzXdEYogh6U8a = str(Y17JXktlo9gOwbc3LRxCI).encode(RMGz7OiD1e30P)
	elif ffpPJZ1jr2HDB6qvm0da==w9wfONXUP3(u"ࠧࡑࡑࡖࡘࠬຶ"):
		Y17JXktlo9gOwbc3LRxCI = g726UBevLKbpyh8o35Z4fdPiRrn9uG(Y17JXktlo9gOwbc3LRxCI)
		DDSLTxjzXdEYogh6U8a = Y17JXktlo9gOwbc3LRxCI.encode(RMGz7OiD1e30P)
	iL1QfsexHqmDz0FpjhrZ6nKSYgok39(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡗࡕࡐࡑࡏࡂ࡝ࡶ࡟ࡸࡔࡖࡅࡏࡡࡘࡖࡑ࠭ື"),ppJF7uRhD245fxU,Y17JXktlo9gOwbc3LRxCI,MtT2SKcnYZHN6PzJhqAeWx17,KS8ozxwIk1EB4srRJtgHfbVp2AhQ,ffpPJZ1jr2HDB6qvm0da)
	try:
		zRJ9B1LKmSOCqpPUF2kEuoX5j = OtYjsD3B485AzLgxH.Request(ppJF7uRhD245fxU,headers=MtT2SKcnYZHN6PzJhqAeWx17,data=DDSLTxjzXdEYogh6U8a)
		u5u7R6mqdcIMkAglJLt8npfvHKzjU = OtYjsD3B485AzLgxH.urlopen(zRJ9B1LKmSOCqpPUF2kEuoX5j)
		WnNTjl17I0ReLSmUFfBwtVhDbr5 = u5u7R6mqdcIMkAglJLt8npfvHKzjU.read()
		Ub0XuWZeTwH9vCnhF1l6c,opijuHCafekbUtW5Lv87R = CCWqR3dmtzw6xoIX41(u"࠲࠱࠲ဆ"),w9wfONXUP3(u"ࠩࡒࡏຸࠬ")
	except:
		WnNTjl17I0ReLSmUFfBwtVhDbr5 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		Ub0XuWZeTwH9vCnhF1l6c,opijuHCafekbUtW5Lv87R = -xD9WeoEAsX7,JZ45mOctiTszPNw1GVjxhep2Y(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴູࠪ")
	try:
		if ff83qUC4GsOLdp7j9hzriKSAPWQkex and WnNTjl17I0ReLSmUFfBwtVhDbr5:
			ZZl0CzKIpcn1 = {SnasPEKp3MYkN20u.lower(): qq7jWMYgA8 for SnasPEKp3MYkN20u, qq7jWMYgA8 in u5u7R6mqdcIMkAglJLt8npfvHKzjU.headers.items()}
			if ZZl0CzKIpcn1.get(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡦࡼ࠭ࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱ຺ࠫ"))==f9fOpCmLAEaW2Go(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠱࠯࠲ࠪົ"):
				WnNTjl17I0ReLSmUFfBwtVhDbr5,un0bydOYNFHtRB38SzV = YnWpIJVfFz.yy8iWo41x0hU7O(WnNTjl17I0ReLSmUFfBwtVhDbr5,B1YMtuvRAGNlJOkC46VyPKQE(u"࠹࠳࠵࠻࠹࠿࠳࠶࠸ဇ"))
				if un0bydOYNFHtRB38SzV==djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡉࡏࡘࡄࡐࡎࡊ࡟ࡕࡋࡐࡉࡘ࡚ࡁࡎࡒࠪຼ"):
					opijuHCafekbUtW5Lv87R,Ub0XuWZeTwH9vCnhF1l6c = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡊࡰࡹࡥࡱ࡯ࡤࠡࡃࡓࡍࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࠨຽ"),-Hip2swoNbVaZ30OrStQR1lF
					WnNTjl17I0ReLSmUFfBwtVhDbr5 = opijuHCafekbUtW5Lv87R
	except: WnNTjl17I0ReLSmUFfBwtVhDbr5 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if fOohwvakqi29cx0l3yt5mzrAGpEg and isinstance(WnNTjl17I0ReLSmUFfBwtVhDbr5,bytes): WnNTjl17I0ReLSmUFfBwtVhDbr5 = WnNTjl17I0ReLSmUFfBwtVhDbr5.decode(RMGz7OiD1e30P)
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,I6Bfzysrvb8DONZ(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ຾")+str(Ub0XuWZeTwH9vCnhF1l6c)+W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ຿")+opijuHCafekbUtW5Lv87R+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬເ")+KS8ozxwIk1EB4srRJtgHfbVp2AhQ+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪແ")+ppJF7uRhD245fxU+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࠦ࡝ࠨໂ"))
	return WnNTjl17I0ReLSmUFfBwtVhDbr5
def LebOcpUwr9K4fxihGDlTHZW2P(E5oOc6WKTxwv1UDn8BL):
	sJnQBblNXv0UY1jmcr = str(DDLw3RXCNW.randrange(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷ဈ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ဉ")))
	mWXYoujNO2c1Sr = {
		pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡵࡴࡧࡵࡣ࡮ࡪࠢໃ"):QYhMUcDf60,
		nR0ok9zju84rFUQl1YC(u"ࠢࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠦໄ"):str(XqSerIMoFsRn2UQ1D5Alj6),
		slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠣࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ໅"):FLRQJnBHTvsXU,
		w9wfONXUP3(u"ࠤࡧࡩࡻ࡯ࡣࡦࡡࡩࡥࡲ࡯࡬ࡺࠤໆ"):FLRQJnBHTvsXU,
		Zb5cNeHWi6jP9SCYtUgR(u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧ໇"): FLRQJnBHTvsXU,
		GTmHXIZUSdxRhMnqQKkO(u"ࠦࡨࡧࡲࡳ࡫ࡨࡶ່ࠧ"):W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗ້ࠧ"),
		awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡩࡱࠤ໊"): GTmHXIZUSdxRhMnqQKkO(u"ࠢࠥࡴࡨࡱࡴࡺࡥ໋ࠣ"),
		pbmKZA1w7L4zHjOM(u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢ໌"):pLwgjkuTs6CS
	}
	GTQpDrwmhP8iIbVB = []
	for MCNltWgOJ3B7Fcv0X6udS95hQwTj in E5oOc6WKTxwv1UDn8BL:
		W54GnOZLmrA = mWXYoujNO2c1Sr.copy()
		W54GnOZLmrA[hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ໍ")] = MCNltWgOJ3B7Fcv0X6udS95hQwTj
		W54GnOZLmrA[I6Bfzysrvb8DONZ(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭໎")] = {vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ໏"):MCNltWgOJ3B7Fcv0X6udS95hQwTj}
		W54GnOZLmrA[nR0ok9zju84rFUQl1YC(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ໐")] = {pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ໑"):MCNltWgOJ3B7Fcv0X6udS95hQwTj}
		GTQpDrwmhP8iIbVB.append(W54GnOZLmrA)
	Y17JXktlo9gOwbc3LRxCI = {
		djapWhrveLJbgnViDftFNY05ylq1S(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣ໒"):bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭໓"),
		zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ໔"):sJnQBblNXv0UY1jmcr,
		KKCrwPdOgGl(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥ໕"): GTQpDrwmhP8iIbVB
	}
	MtT2SKcnYZHN6PzJhqAeWx17 = {pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ໖"):jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ໗")}
	HHyOcE4DNohvx0MaIJZ1b = I6Bfzysrvb8DONZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ໘")
	yujTExGv4RfVKPsnUq0IJZ71CLmO = nXGUokCph4aZJ(CCWqR3dmtzw6xoIX41(u"ࠧࡑࡑࡖࡘࠬ໙"),HHyOcE4DNohvx0MaIJZ1b,Y17JXktlo9gOwbc3LRxCI,MtT2SKcnYZHN6PzJhqAeWx17,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧ໚"))
	return yujTExGv4RfVKPsnUq0IJZ71CLmO
def q7W61K3zEBMchdn2VA(f3O6K7VReP5jWyMnrg):
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(nR0ok9zju84rFUQl1YC(u"ࡴࠪࠬࡡࡹࠩࠣࠪ࡟ࡻ࠮࠭໛"), MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࡵࠫࡡ࠷࡜࡝ࠤ࡟࠶ࠬໜ"), f3O6K7VReP5jWyMnrg)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(kAz7WRYjrfGm(u"ࡶࠬ࠮࡜ࡸࠫࠥࠬࡡࡹࠩࠨໝ"), JZ45mOctiTszPNw1GVjxhep2Y(u"ࡷ࠭࡜࠲࡞࡟ࠦࡡ࠸ࠧໞ"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(YzlId3Fs6vpehcbLGj0UaO(u"ࡸࠧࠩ࡞ࡺ࠭ࠧ࠮࡜ࡸࠫࠪໟ"), CCWqR3dmtzw6xoIX41(u"ࡲࠨ࡞࠴ࡠࡡࠨ࡜࠳ࠩ໠"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࡳࠩࠫࡠࡸ࠯ࠢࠩ࡞ࡶ࠭ࠬ໡"), rAYDiWlzm9MCU6x0GnROua(u"ࡴࠪࡠ࠶ࡢ࡜ࠣ࡞࠵ࠫ໢"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(pbmKZA1w7L4zHjOM(u"ࡵࠦ࠭ࡢࡳࠪࠩࠫࡠࡼ࠯ࠢ໣"), JZ45mOctiTszPNw1GVjxhep2Y(u"ࡶࠧࡢ࠱࡝࡞ࠪࡠ࠷ࠨ໤"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(kAz7WRYjrfGm(u"ࡷࠨࠨ࡝ࡹࠬࠫ࠭ࡢࡳࠪࠤ໥"), hWRvZOYtjme9QNnV41u0Mswb(u"ࡸࠢ࡝࠳࡟ࡠࠬࡢ࠲ࠣ໦"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(pYeVwat64v(u"ࡲࠣࠪ࡟ࡻ࠮࠭ࠨ࡝ࡹࠬࠦ໧"), f9fOpCmLAEaW2Go(u"ࡳࠤ࡟࠵ࡡࡢࠧ࡝࠴ࠥ໨"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(rAYDiWlzm9MCU6x0GnROua(u"ࡴࠥࠬࡡࡹࠩࠨࠪ࡟ࡷ࠮ࠨ໩"), B1YMtuvRAGNlJOkC46VyPKQE(u"ࡵࠦࡡ࠷࡜࡝ࠩ࡟࠶ࠧ໪"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	NNGO5stY2Ucmjyl1To6ZWfVvhx = pL73X0MYajJQG4n1qgD(u"ࡶࠬࡡ࡜࡜࡞ࡠࡿࢂ࠮ࠩ࠻࠮ࡠࠫ໫")
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࡷ࠭ࠨ࡝ࡹࠬࠬࠬ໬") + NNGO5stY2Ucmjyl1To6ZWfVvhx + zWBnYSGIatjXVC(u"ࡸࠧࠪࠪ࡟ࡻ࠮࠭໭"), YzlId3Fs6vpehcbLGj0UaO(u"ࡲࠨ࡞࠴ࡠࡡࡢ࠲࡝࠵ࠪ໮"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(I6Bfzysrvb8DONZ(u"ࡳࠩࠫࡠࡸ࠯ࠨࠨ໯") + NNGO5stY2Ucmjyl1To6ZWfVvhx + w9wfONXUP3(u"ࡴࠪ࠭࠭ࡢࡷࠪࠩ໰"), ba49YvOK2Aw8Uhxt(u"ࡵࠫࡡ࠷࡜࡝࡞࠵ࡠ࠸࠭໱"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(f9fOpCmLAEaW2Go(u"ࡶࠬ࠮࡜ࡸࠫࠫࠫ໲") + NNGO5stY2Ucmjyl1To6ZWfVvhx + pL73X0MYajJQG4n1qgD(u"ࡷ࠭ࠩࠩ࡞ࡶ࠭ࠬ໳"), awSUTRNMkdIW7sFEvnHD2mLY(u"ࡸࠧ࡝࠳࡟ࡠࡡ࠸࡜࠴ࠩ໴"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(zWBnYSGIatjXVC(u"ࡲࠨࠪ࡟ࡷ࠮࠮ࠧ໵") + NNGO5stY2Ucmjyl1To6ZWfVvhx + GTmHXIZUSdxRhMnqQKkO(u"ࡳࠩࠬࠬࡡࡹࠩࠨ໶"), YzlId3Fs6vpehcbLGj0UaO(u"ࡴࠪࡠ࠶ࡢ࡜࡝࠴࡟࠷ࠬ໷"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	nyXh7oYwaFbr5xALBtD6cf3URVkSE4 = AxTYMhRlfyskNc0X19dvwtS.sub(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࡵࠫ࠭ࡢࡷࠪ࡞࡟ࠬࡡࡽࠩࠨ໸"), KKCrwPdOgGl(u"ࡶࠬࡢ࠱࡝࡞࡟ࡠࡡ࠸ࠧ໹"), nyXh7oYwaFbr5xALBtD6cf3URVkSE4)
	return nyXh7oYwaFbr5xALBtD6cf3URVkSE4
def rKY1tyQvh9OCxE2nl(ZLlkb3hSRWseVwK,lry65pw1AbmnNHzBFZ):
	lry65pw1AbmnNHzBFZ = lry65pw1AbmnNHzBFZ.replace(f9fOpCmLAEaW2Go(u"ࠬࡴࡵ࡭࡮ࠪ໺"),GTmHXIZUSdxRhMnqQKkO(u"࠭ࡎࡰࡰࡨࠫ໻"))
	lry65pw1AbmnNHzBFZ = lry65pw1AbmnNHzBFZ.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡵࡴࡸࡩࠬ໼"),KKCrwPdOgGl(u"ࠨࡖࡵࡹࡪ࠭໽"))
	lry65pw1AbmnNHzBFZ = lry65pw1AbmnNHzBFZ.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠩࡩࡥࡱࡹࡥࠨ໾"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡊࡦࡲࡳࡦࠩ໿"))
	lry65pw1AbmnNHzBFZ = lry65pw1AbmnNHzBFZ.replace(f9fOpCmLAEaW2Go(u"ࠫࡡ࠵ࠧༀ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠬ࠵ࠧ༁"))
	lry65pw1AbmnNHzBFZ = lry65pw1AbmnNHzBFZ.replace(nR0ok9zju84rFUQl1YC(u"࠭࡜ࡳࠩ༂"),nR0ok9zju84rFUQl1YC(u"ࠧ࡝࡞ࡵࠫ༃")).replace(f9fOpCmLAEaW2Go(u"ࠨ࡞ࡱࠫ༄"),f9fOpCmLAEaW2Go(u"ࠩ࡟ࡠࡳ࠭༅"))
	XMPkB7Dq80SxCf2YOcE,gg3XjydNI6qTre = [],[]
	import ast as eeBhUDTWw3vfZ6gAiHLxalKuQE
	try: XMPkB7Dq80SxCf2YOcE = eeBhUDTWw3vfZ6gAiHLxalKuQE.literal_eval(lry65pw1AbmnNHzBFZ)
	except:
		try:
			lry65pw1AbmnNHzBFZ = q7W61K3zEBMchdn2VA(lry65pw1AbmnNHzBFZ)
			XMPkB7Dq80SxCf2YOcE = eeBhUDTWw3vfZ6gAiHLxalKuQE.literal_eval(lry65pw1AbmnNHzBFZ)
		except:
			items = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࡵࠫࡡࡡ࡛࡟࡞ࡠࡡ࠯ࡢ࡝ࡽ࡞ࡾ࡟ࡣࢃ࡝ࠫ࡞ࢀࢀࡡ࠮࡛࡟ࠫࡠ࠮ࡡ࠯ࡼ࡜ࡠ࠯ࡠࡠࡢ࡝࡞࠭ࠪ༆"),lry65pw1AbmnNHzBFZ.strip(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡠࡣࠧ༇")))
			if items:
				for Uz7N5KAHwQ93iShW1xj in items:
					try: XMPkB7Dq80SxCf2YOcE.append(eeBhUDTWw3vfZ6gAiHLxalKuQE.literal_eval(Uz7N5KAHwQ93iShW1xj))
					except: gg3XjydNI6qTre.append(Uz7N5KAHwQ93iShW1xj)
			else: XMPkB7Dq80SxCf2YOcE = vEZW7IfdB1P6u34yYGOQK(ZLlkb3hSRWseVwK)
	return XMPkB7Dq80SxCf2YOcE
def a5zVkcDudSNEyOtRrfwxMPH01():
	YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = XjPqWt1BdDk(utdV6CEfRBM)
	oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡࠬ༈"),X3cxeAQbjSnkK2sY9ZgJB8ma,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if oPeI4pms5LfYHrxygnAh: X3cxeAQbjSnkK2sY9ZgJB8ma = X3cxeAQbjSnkK2sY9ZgJB8ma.split(oPeI4pms5LfYHrxygnAh[nUaVQsoA6EXcK4Odht5wCge0J8Pib],xD9WeoEAsX7)[xD9WeoEAsX7]
	h4aBTEirF3J26swgx7De9POQULq = f7epsRlYtMz4.strftime(I6Bfzysrvb8DONZ(u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭༉"),f7epsRlYtMz4.localtime(KKydonNSglP1M08xw7O))
	X3cxeAQbjSnkK2sY9ZgJB8ma = X3cxeAQbjSnkK2sY9ZgJB8ma+h4aBTEirF3J26swgx7De9POQULq
	IzNRi6kSZB = YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU
	Gz2Hy3m8uAVS = {}
	try:
		if oNlez5gnM9x2B4.path.exists(IZKily6gHndwh3qNe0TOfa1):
			Zk6eKvAhb4dNjBX78q = open(IZKily6gHndwh3qNe0TOfa1,zWBnYSGIatjXVC(u"ࠧࡳࡤࠪ༊")).read()
			if Zk6eKvAhb4dNjBX78q:
				if fOohwvakqi29cx0l3yt5mzrAGpEg: Zk6eKvAhb4dNjBX78q = Zk6eKvAhb4dNjBX78q.decode(RMGz7OiD1e30P)
				Gz2Hy3m8uAVS = rKY1tyQvh9OCxE2nl(pbmKZA1w7L4zHjOM(u"ࠨࡦ࡬ࡧࡹ࠭་"),Zk6eKvAhb4dNjBX78q)
		ripQKLJC6xTUmc4HM7zf0P = {}
		for avCTKc1SE6RfN in Gz2Hy3m8uAVS:
			if avCTKc1SE6RfN!=YYTAkfz3NaQrLuCyRE: ripQKLJC6xTUmc4HM7zf0P[avCTKc1SE6RfN] = Gz2Hy3m8uAVS[avCTKc1SE6RfN]
			else:
				if X3cxeAQbjSnkK2sY9ZgJB8ma and X3cxeAQbjSnkK2sY9ZgJB8ma!=KKCrwPdOgGl(u"ࠩ࠱࠲ࠬ༌"):
					VncUd7o8IjiplaLZDGymeugEvPQ = Gz2Hy3m8uAVS[avCTKc1SE6RfN]
					if IzNRi6kSZB in VncUd7o8IjiplaLZDGymeugEvPQ:
						qHmcPitXMaCJTswd7zj8W3Ux4u9l = VncUd7o8IjiplaLZDGymeugEvPQ.index(IzNRi6kSZB)
						del VncUd7o8IjiplaLZDGymeugEvPQ[qHmcPitXMaCJTswd7zj8W3Ux4u9l]
					ERIWgZzeGk9O0yVoDvs3FqwT = [IzNRi6kSZB]+VncUd7o8IjiplaLZDGymeugEvPQ
					ERIWgZzeGk9O0yVoDvs3FqwT = ERIWgZzeGk9O0yVoDvs3FqwT[:ba49YvOK2Aw8Uhxt(u"࠹࠵ည")]
					ripQKLJC6xTUmc4HM7zf0P[avCTKc1SE6RfN] = ERIWgZzeGk9O0yVoDvs3FqwT
				else: ripQKLJC6xTUmc4HM7zf0P[avCTKc1SE6RfN] = Gz2Hy3m8uAVS[avCTKc1SE6RfN]
		if YYTAkfz3NaQrLuCyRE not in list(ripQKLJC6xTUmc4HM7zf0P.keys()): ripQKLJC6xTUmc4HM7zf0P[YYTAkfz3NaQrLuCyRE] = [IzNRi6kSZB]
		ripQKLJC6xTUmc4HM7zf0P = str(ripQKLJC6xTUmc4HM7zf0P)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: ripQKLJC6xTUmc4HM7zf0P = ripQKLJC6xTUmc4HM7zf0P.encode(RMGz7OiD1e30P)
		open(IZKily6gHndwh3qNe0TOfa1,zWBnYSGIatjXVC(u"ࠪࡻࡧ࠭།")).write(ripQKLJC6xTUmc4HM7zf0P)
	except:
		import UUtiyoRJ6h,IxiP9D6sLd
		UUtiyoRJ6h.w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ฺ๊ࠫใๅหࠪ༎"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣ฽๋ีใࠡใํࠤ๊๊แࠡฤัีࠥอไโ์า๎ํํวหࠢ࠱࠲ࠥฮูะ๊ࠢิ์ࠦวๅำึห้ฯࠠิ๊ไࠤฯ฾็าࠢ็็ࠥืำศๆฬࠤศิั๊๋ࠢๅ๏ํวࠡฬึฮ฼๐ูࠡล้ࠤฯำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮࠯ࠢะ๎ะ๊ࠦอสࠣว๋ࠦสฯฬสีࠥหๅศࠢศู้ออࠡษ็้้็ࠠฤุ๊้ࠣำ็ࠡฬ่ห๊อࠧ༏"))
		IxiP9D6sLd.bx6AiCRucgDYqaW2pP1vtK(IZKily6gHndwh3qNe0TOfa1)
	return
def g726UBevLKbpyh8o35Z4fdPiRrn9uG(Y17JXktlo9gOwbc3LRxCI):
	if fOohwvakqi29cx0l3yt5mzrAGpEg: import urllib.parse as nn94LOKAoYFIWgRaJziEwSu7y
	else: import urllib as nn94LOKAoYFIWgRaJziEwSu7y
	nK4T091Lvwubmqef = nn94LOKAoYFIWgRaJziEwSu7y.urlencode(Y17JXktlo9gOwbc3LRxCI)
	return nK4T091Lvwubmqef
def ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(jYfvU9egTX62nrukVcoKEAyq,DuXcqRVY9WrkxbZQjndmSJTFoi2fM=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GmCFdqPtRYTu6srLpcQKvjlOA3=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	Q98VHsgC4SfDir = DuXcqRVY9WrkxbZQjndmSJTFoi2fM not in [KKCrwPdOgGl(u"࠭ࡍ࠴ࡗࠪ༐"),Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡊࡒࡗ࡚ࠬ༑")]
	if not GmCFdqPtRYTu6srLpcQKvjlOA3: GmCFdqPtRYTu6srLpcQKvjlOA3 = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡸ࡬ࡨࡪࡵࠧ༒")
	G4GwER6kHpBbxOi9r,kemLiD0zHhqcjr,INHWeFfpTkXOhPCAKLwS = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ༓"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if len(jYfvU9egTX62nrukVcoKEAyq)==anb4QpyjlmgVwANP:
		HHyOcE4DNohvx0MaIJZ1b,llrLZJqUcXjWAu9Gwm4Fs,INHWeFfpTkXOhPCAKLwS = jYfvU9egTX62nrukVcoKEAyq
		if llrLZJqUcXjWAu9Gwm4Fs: kemLiD0zHhqcjr = lRKCWnNi0Edr984eI(u"ࠪࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻ࠢ࡞ࠤࠬ༔")+llrLZJqUcXjWAu9Gwm4Fs+ba49YvOK2Aw8Uhxt(u"ࠫࠥࡣࠧ༕")
	else: HHyOcE4DNohvx0MaIJZ1b,llrLZJqUcXjWAu9Gwm4Fs,INHWeFfpTkXOhPCAKLwS = jYfvU9egTX62nrukVcoKEAyq,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.replace(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࠫ࠲࠱ࠩ༖"),WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	BQdRPYjZiS = azP0kLi9Uc6(HHyOcE4DNohvx0MaIJZ1b)
	if DuXcqRVY9WrkxbZQjndmSJTFoi2fM not in [fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ༗"),pYeVwat64v(u"ࠧࡊࡒࡗ࡚༘ࠬ")]:
		if DuXcqRVY9WrkxbZQjndmSJTFoi2fM!=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ༙ࠪ"): HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,lRKCWnNi0Edr984eI(u"ࠩࠨ࠶࠵࠭༚"))
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+YzlId3Fs6vpehcbLGj0UaO(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ༛")+HHyOcE4DNohvx0MaIJZ1b+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࠥࡣࠧ༜")+kemLiD0zHhqcjr)
		if BQdRPYjZiS==nR0ok9zju84rFUQl1YC(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ༝") and DuXcqRVY9WrkxbZQjndmSJTFoi2fM not in [rAYDiWlzm9MCU6x0GnROua(u"࠭ࡉࡑࡖ࡙ࠫ༞"),zWBnYSGIatjXVC(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ༟")]:
			import YnWpIJVfFz,UUtiyoRJ6h
			GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = YnWpIJVfFz.vn9QxuZF4f2YzCVpELgkc(DuXcqRVY9WrkxbZQjndmSJTFoi2fM,HHyOcE4DNohvx0MaIJZ1b)
			ND6jh1xZBfJktGV = len(CBL4OQVtWbMAycUGl7Ex2SKZF)
			if ND6jh1xZBfJktGV>xD9WeoEAsX7:
				qNmsBD1jJZVzcxi4onKuAOIC = UUtiyoRJ6h.YLUMzC9m0dc(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ༠")+str(ND6jh1xZBfJktGV)+hWRvZOYtjme9QNnV41u0Mswb(u"้้ࠩࠣ็ࠩࠨ༡"), GjC4atkJLwlTpsI)
				if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7:
					UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(rAYDiWlzm9MCU6x0GnROua(u"ࠪษ้เวยࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ༢"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡈࡧ࡮ࡤࡧ࡯ࠫ༣"))
					return G4GwER6kHpBbxOi9r
			else: qNmsBD1jJZVzcxi4onKuAOIC = nUaVQsoA6EXcK4Odht5wCge0J8Pib
			HHyOcE4DNohvx0MaIJZ1b = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
			if GjC4atkJLwlTpsI[nUaVQsoA6EXcK4Odht5wCge0J8Pib]!=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠳࠱ࠨ༤"):
				UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+w9wfONXUP3(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ༥")+GjC4atkJLwlTpsI[qNmsBD1jJZVzcxi4onKuAOIC]+f9fOpCmLAEaW2Go(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ༦")+HHyOcE4DNohvx0MaIJZ1b+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠢࡠࠫ༧"))
		if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪ༨") in HHyOcE4DNohvx0MaIJZ1b: HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ༩")
		elif pbmKZA1w7L4zHjOM(u"ࠫ࡭ࡺࡴࡱࠩ༪") in HHyOcE4DNohvx0MaIJZ1b.lower() and pbmKZA1w7L4zHjOM(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ༫") not in HHyOcE4DNohvx0MaIJZ1b and kAz7WRYjrfGm(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯ࠩ༬") not in HHyOcE4DNohvx0MaIJZ1b:
			HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b+rAYDiWlzm9MCU6x0GnROua(u"ࠧࡽࠩ༭") if zWBnYSGIatjXVC(u"ࠨࡾࠪ༮") not in HHyOcE4DNohvx0MaIJZ1b else HHyOcE4DNohvx0MaIJZ1b+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࠩࠫ༯")
			if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨ༰") not in HHyOcE4DNohvx0MaIJZ1b and GTmHXIZUSdxRhMnqQKkO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭༱") in HHyOcE4DNohvx0MaIJZ1b.lower(): HHyOcE4DNohvx0MaIJZ1b += rAYDiWlzm9MCU6x0GnROua(u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠧࠩ༲")
			if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡀࠫ༳") not in HHyOcE4DNohvx0MaIJZ1b.lower() and DuXcqRVY9WrkxbZQjndmSJTFoi2fM not in [vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡊࡒࡗ࡚ࠬ༴"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡏ࠶࡙༵ࠬ")]: HHyOcE4DNohvx0MaIJZ1b += I6Bfzysrvb8DONZ(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ༶")
			if rAYDiWlzm9MCU6x0GnROua(u"ࠪࡶࡪ࡬ࡥࡳࡧࡵࡁ༷ࠬ") not in HHyOcE4DNohvx0MaIJZ1b.lower(): HHyOcE4DNohvx0MaIJZ1b += ba49YvOK2Aw8Uhxt(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲࠩࠫ༸")
			if zWBnYSGIatjXVC(u"ࠬࡧࡣࡤࡧࡳࡸ࠲ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠽ࠨ༹") not in HHyOcE4DNohvx0MaIJZ1b.lower(): HHyOcE4DNohvx0MaIJZ1b += KKCrwPdOgGl(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠰ࡦࡸ࠻ࡲ࠿࠳࠲࠾ࠬࠧ༺")
	UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠡࠢࠣࡋࡴࡺࠠࡧ࡫ࡱࡥࡱࠦࡵࡳ࡮ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ༻")+HHyOcE4DNohvx0MaIJZ1b+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࠢࡠࠫ༼"))
	afTeYyAxJ4j = vRVl0MpXZDwAYB4ag68nc.ListItem()
	GmCFdqPtRYTu6srLpcQKvjlOA3,ddBhHa2tpW8QKwnmusi4,yIFRpQwU7EolNWqMC1YBmjDskOf,g2EfYkO8iXMFdIvLj5PH,rgO3oUuG6mxJLEjaW4qh7v,cc9AnByQRehb4N8WVjH0Mx3,lIRQHpWbFNdAGsMXUx0qV7hoaT2Jc,GGfVTFCnSmb3r,R1RapmPAYJlBxDOyikeQSnLw = XjPqWt1BdDk(utdV6CEfRBM)
	if DuXcqRVY9WrkxbZQjndmSJTFoi2fM not in [GTmHXIZUSdxRhMnqQKkO(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ༽"),GTmHXIZUSdxRhMnqQKkO(u"ࠪࡍࡕ࡚ࡖࠨ༾")]:
		rHhWw3PNJOFCf561kYXTb = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧ༿") if hT1JIgqPQsUOZp5tjCX0E else f9fOpCmLAEaW2Go(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࠪཀ")
		afTeYyAxJ4j.setProperty(rHhWw3PNJOFCf561kYXTb, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		afTeYyAxJ4j.setMimeType(w9wfONXUP3(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫཁ"))
		if XqSerIMoFsRn2UQ1D5Alj6<kAz7WRYjrfGm(u"࠷࠶ဋ"): afTeYyAxJ4j.setInfo(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡷ࡫ࡧࡩࡴ࠭ག"),{bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫགྷ"):fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡰࡳࡻ࡯ࡥࠨང")})
		else:
			uuP4TNowyWJ9QjCq7lZ5B = afTeYyAxJ4j.getVideoInfoTag()
			uuP4TNowyWJ9QjCq7lZ5B.setMediaType(KKCrwPdOgGl(u"ࠪࡱࡴࡼࡩࡦࠩཅ"))
		afTeYyAxJ4j.setArt({KKCrwPdOgGl(u"ࠫࡹ࡮ࡵ࡮ࡤࠪཆ"):rgO3oUuG6mxJLEjaW4qh7v,ba49YvOK2Aw8Uhxt(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬཇ"):rgO3oUuG6mxJLEjaW4qh7v,KKCrwPdOgGl(u"࠭ࡢࡢࡰࡱࡩࡷ࠭཈"):rgO3oUuG6mxJLEjaW4qh7v,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡧࡣࡱࡥࡷࡺࠧཉ"):rgO3oUuG6mxJLEjaW4qh7v,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪཊ"):rgO3oUuG6mxJLEjaW4qh7v,YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬཋ"):rgO3oUuG6mxJLEjaW4qh7v,lRKCWnNi0Edr984eI(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ཌ"):rgO3oUuG6mxJLEjaW4qh7v,KKCrwPdOgGl(u"ࠫ࡮ࡩ࡯࡯ࠩཌྷ"):rgO3oUuG6mxJLEjaW4qh7v})
		if BQdRPYjZiS in [lRKCWnNi0Edr984eI(u"ࠬ࠴࡭ࡱࡦࠪཎ"),CCWqR3dmtzw6xoIX41(u"࠭࠮࡮࠵ࡸ࠼ࠬཏ")]:
			afTeYyAxJ4j.setContentLookup(NFGqKBLtvUZn1S3dau)
		else: afTeYyAxJ4j.setContentLookup(pLwgjkuTs6CS)
		from IxiP9D6sLd import dJv9nZwNPYyes2zKA7rIX6Rgqp
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡳࡶࡰࡴࠬཐ") in HHyOcE4DNohvx0MaIJZ1b:
			dJv9nZwNPYyes2zKA7rIX6Rgqp(f9fOpCmLAEaW2Go(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫད"),pLwgjkuTs6CS)
		elif BQdRPYjZiS==vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࠱ࡱࡵࡪࠧདྷ") or pYeVwat64v(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪན") in HHyOcE4DNohvx0MaIJZ1b:
			dJv9nZwNPYyes2zKA7rIX6Rgqp(KKCrwPdOgGl(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫཔ"),pLwgjkuTs6CS)
			afTeYyAxJ4j.setProperty(rHhWw3PNJOFCf561kYXTb,lRKCWnNi0Edr984eI(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬཕ"))
			afTeYyAxJ4j.setProperty(GTmHXIZUSdxRhMnqQKkO(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭བ"),GTmHXIZUSdxRhMnqQKkO(u"ࠧ࡮ࡲࡧࠫབྷ"))
		if llrLZJqUcXjWAu9Gwm4Fs:
			afTeYyAxJ4j.setSubtitles([llrLZJqUcXjWAu9Gwm4Fs])
	if GmCFdqPtRYTu6srLpcQKvjlOA3==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡸ࡬ࡨࡪࡵࠧམ") and DuXcqRVY9WrkxbZQjndmSJTFoi2fM==nR0ok9zju84rFUQl1YC(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫཙ"):
		G4GwER6kHpBbxOi9r = nR0ok9zju84rFUQl1YC(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪཚ")
		DuXcqRVY9WrkxbZQjndmSJTFoi2fM = ba49YvOK2Aw8Uhxt(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫཛ")
	elif GmCFdqPtRYTu6srLpcQKvjlOA3==jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡼࡩࡥࡧࡲࠫཛྷ") and GGfVTFCnSmb3r.startswith(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭࠶ࠨཝ")):
		G4GwER6kHpBbxOi9r = pL73X0MYajJQG4n1qgD(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬཞ")
		DuXcqRVY9WrkxbZQjndmSJTFoi2fM = DuXcqRVY9WrkxbZQjndmSJTFoi2fM+ba49YvOK2Aw8Uhxt(u"ࠨࡡࡇࡐࠬཟ")
	if G4GwER6kHpBbxOi9r!=djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧའ"): a5zVkcDudSNEyOtRrfwxMPH01()
	LHipOJX9eRG8VrscYDzB7.PtbsZGfnwepAK4SzOD(DuXcqRVY9WrkxbZQjndmSJTFoi2fM)
	if LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP: return djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫཡ")
	if GmCFdqPtRYTu6srLpcQKvjlOA3==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡻ࡯ࡤࡦࡱࠪར") and not GGfVTFCnSmb3r.startswith(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࠼ࠧལ")):
		afTeYyAxJ4j.setPath(HHyOcE4DNohvx0MaIJZ1b)
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+pYeVwat64v(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ཤ")+HHyOcE4DNohvx0MaIJZ1b+nR0ok9zju84rFUQl1YC(u"ࠧࠡ࡟ࠪཥ"))
		NEYCX82mhdSJUptfu0LWk9szKy.setResolvedUrl(yyRW7r1KOgHNcdmnJvS5iQ4f0,NFGqKBLtvUZn1S3dau,afTeYyAxJ4j)
	elif GmCFdqPtRYTu6srLpcQKvjlOA3==JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࡮࡬ࡺࡪ࠭ས"):
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+zWBnYSGIatjXVC(u"ࠩࠣࠤࠥࡒࡩࡷࡧࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬཧ")+HHyOcE4DNohvx0MaIJZ1b+GTmHXIZUSdxRhMnqQKkO(u"ࠪࠤࡢ࠭ཨ"))
		LHipOJX9eRG8VrscYDzB7.play(HHyOcE4DNohvx0MaIJZ1b,afTeYyAxJ4j)
	oo3n0EuaHjYSz = pLwgjkuTs6CS
	if G4GwER6kHpBbxOi9r==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩཀྵ"):
		from QQepHMcv4F import lsvrBiaNnCVqAJZu9W36g8bU
		oo3n0EuaHjYSz = lsvrBiaNnCVqAJZu9W36g8bU(HHyOcE4DNohvx0MaIJZ1b,BQdRPYjZiS,DuXcqRVY9WrkxbZQjndmSJTFoi2fM)
		if oo3n0EuaHjYSz: a5zVkcDudSNEyOtRrfwxMPH01()
	else:
		Wzw7OA1X9P0iTJElDsVgB2MC8m,G4GwER6kHpBbxOi9r,bFfYgckSLRKsGU1W9Xo,J1mTtnKhk3,mn4NObJBKqRptlF2Cd = nUaVQsoA6EXcK4Odht5wCge0J8Pib,zWBnYSGIatjXVC(u"ࠬࡺࡲࡪࡧࡧࠫཪ"),pLwgjkuTs6CS,pYeVwat64v(u"࠱࠱࠲࠳ဍ"),pYeVwat64v(u"࠺࠵࠱࠲࠳ဌ")
		if Q98VHsgC4SfDir: import UUtiyoRJ6h
		while Wzw7OA1X9P0iTJElDsVgB2MC8m<mn4NObJBKqRptlF2Cd:
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.sleep(J1mTtnKhk3)
			Wzw7OA1X9P0iTJElDsVgB2MC8m += J1mTtnKhk3
			if LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧཫ") and not bFfYgckSLRKsGU1W9Xo:
				if Q98VHsgC4SfDir: UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(zWBnYSGIatjXVC(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส๐ฬศัࠣห้็๊ะ์๋ࠫཬ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩ཭"),f7epsRlYtMz4=f9fOpCmLAEaW2Go(u"࠸࠷࠳ဎ"))
				UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+Zb5cNeHWi6jP9SCYtUgR(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡴࡶࡤࡶࡹ࡫ࡤ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭཮")+HHyOcE4DNohvx0MaIJZ1b+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࠤࡢ࠭཯")+kemLiD0zHhqcjr)
				bFfYgckSLRKsGU1W9Xo = NFGqKBLtvUZn1S3dau
			elif LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP in [ba49YvOK2Aw8Uhxt(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ཰"),KKCrwPdOgGl(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬ཱ࠭")]:
				UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺ࡫ࡱ࡫ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ིࠢࠪ")+HHyOcE4DNohvx0MaIJZ1b+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࠡ࡟ཱིࠪ")+kemLiD0zHhqcjr)
				break
			elif LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP==pbmKZA1w7L4zHjOM(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨུ"):
				UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+zWBnYSGIatjXVC(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ཱུࠢࠪ")+HHyOcE4DNohvx0MaIJZ1b+pYeVwat64v(u"ࠪࠤࡢ࠭ྲྀ")+kemLiD0zHhqcjr)
				if Q98VHsgC4SfDir: UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨཷ"),ba49YvOK2Aw8Uhxt(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭ླྀ"),f7epsRlYtMz4=B1YMtuvRAGNlJOkC46VyPKQE(u"࠹࠸࠴ဏ"))
				break
			elif LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP==ba49YvOK2Aw8Uhxt(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧཹ"):
				UO05pib6mcvezR9(UiO5y1oG8EXmD,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+pbmKZA1w7L4zHjOM(u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤེࠬ")+HHyOcE4DNohvx0MaIJZ1b+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࠢࡠཻࠫ"))
				break
		else: G4GwER6kHpBbxOi9r = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶོࠪ")
	if G4GwER6kHpBbxOi9r in [Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦཽࠪ")] or LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP in [hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬཾ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ཿ")] or oo3n0EuaHjYSz: p71RVmeQ3ud0ENcITXY4KbxZ6AOFya(DuXcqRVY9WrkxbZQjndmSJTFoi2fM)
	else: exec(nR0ok9zju84rFUQl1YC(u"࠭ࡩ࡮ࡲࡲࡶࡹࠦࡸࡣ࡯ࡦ࠿ࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱྀࠪࠬࠫ"))
	Jh3fArxWiMwNURO6kymPuGCTeta = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player().isPlaying()
	if not Jh3fArxWiMwNURO6kymPuGCTeta and G4GwER6kHpBbxOi9r not in [slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ཱྀࠬ")]:
		msg = kAz7WRYjrfGm(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩྂ") if G4GwER6kHpBbxOi9r==CCWqR3dmtzw6xoIX41(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪྃ") else bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱ྄ࠫ")
		if Q98VHsgC4SfDir: UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ྅"),msg,f7epsRlYtMz4=W2Vv30i8qxSuItfsolPLdFZA(u"࠺࠹࠵တ"))
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࠦࠠࠡࠩ྆")+msg+JZ45mOctiTszPNw1GVjxhep2Y(u"࠭࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ྇")+HHyOcE4DNohvx0MaIJZ1b+lRKCWnNi0Edr984eI(u"ࠧࠡ࡟ࠪྈ")+kemLiD0zHhqcjr)
	return LHipOJX9eRG8VrscYDzB7.xDuzUJsp7LP
def azP0kLi9Uc6(HHyOcE4DNohvx0MaIJZ1b):
	if lRKCWnNi0Edr984eI(u"ࠨࡁࠪྉ") in HHyOcE4DNohvx0MaIJZ1b: HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡂࠫྊ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࢀࠬྋ") in HHyOcE4DNohvx0MaIJZ1b: HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.split(ba49YvOK2Aw8Uhxt(u"ࠫࢁ࠭ྌ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	path = nR0ok9zju84rFUQl1YC(u"ࠬ࠵ࠧྍ").join(HHyOcE4DNohvx0MaIJZ1b.split(jBbkfIJSDqcVwl8irzy4Z3O(u"࠭࠯ࠨྎ"))[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷ထ"):]) if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧ࠻࠱࠲ࠫྏ") in HHyOcE4DNohvx0MaIJZ1b else HHyOcE4DNohvx0MaIJZ1b
	f19Azhj2H3w7LtOl = AxTYMhRlfyskNc0X19dvwtS.findall(lRKCWnNi0Edr984eI(u"ࠨ࡞࠱ࠬࡠࡧ࠭ࡻ࠲࠰࠽ࡢࢁ࠲࠭࠶ࢀ࠭ࠬྐ"),path,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if f19Azhj2H3w7LtOl:
		f19Azhj2H3w7LtOl = f19Azhj2H3w7LtOl[-xD9WeoEAsX7]
		ddCE7xJQ2rniL8wW = [f9fOpCmLAEaW2Go(u"ࠩࡰ࠷ࡺ࠾ࠧྑ"),kAz7WRYjrfGm(u"ࠪࡱࡵ࠺ࠧྒ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡲࡶࡤࠨྒྷ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡽࡥࡣ࡯ࠪྔ"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡡࡷ࡫ࠪྕ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡢࡣࡦࠫྖ"),ba49YvOK2Aw8Uhxt(u"ࠨ࡯࠶ࡹࠬྗ"),I6Bfzysrvb8DONZ(u"ࠩࡰ࡯ࡻ࠭྘"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡪࡱࡼࠧྙ"),f9fOpCmLAEaW2Go(u"ࠫࡲࡶ࠳ࠨྚ"),pYeVwat64v(u"ࠬࡺࡳࠨྛ")]
		if f19Azhj2H3w7LtOl in ddCE7xJQ2rniL8wW: return pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭࠮ࠨྜ")+f19Azhj2H3w7LtOl
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
def p71RVmeQ3ud0ENcITXY4KbxZ6AOFya(W54GnOZLmrA):
	if not drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3: W54GnOZLmrA += KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡠࡖࡖࠫྜྷ")
	drzqWFkSHD.SEND_THESE_EVENTS.append(W54GnOZLmrA)
	return
def uZd7DmfIshGTlrbHo1L(I6qmSzBFVJoAywPT29=pLwgjkuTs6CS):
	dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(rAYDiWlzm9MCU6x0GnROua(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡆࡰࡪࡧࡲࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶ࢃࡽࠨྞ"))
	eaVguQqSdFGZWBKjt6zmE82Y(I6qmSzBFVJoAywPT29,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬྟ"))
	qv7XKecsSGz6rBTpt.exit()
def eaVguQqSdFGZWBKjt6zmE82Y(I6qmSzBFVJoAywPT29,YK1U4PZlH6MErXStRaVyb3J7hjnG):
	if YK1U4PZlH6MErXStRaVyb3J7hjnG:
		if YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ྠ") in YK1U4PZlH6MErXStRaVyb3J7hjnG: UO05pib6mcvezR9(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧྡ"))
		else:
			FQYEGNkpVyzhfgDx = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(w9wfONXUP3(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ྡྷ"))
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(pbmKZA1w7L4zHjOM(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧྣ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			import YnWpIJVfFz
			YnWpIJVfFz.gCc5fX6kpiwElGYJqaBePoOI(YK1U4PZlH6MErXStRaVyb3J7hjnG)
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(KKCrwPdOgGl(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨྤ"),FQYEGNkpVyzhfgDx)
	zzpKCYP0jIqRFVXgoJtZaBWkThGr3c = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(I6Bfzysrvb8DONZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬྥ"))
	if zzpKCYP0jIqRFVXgoJtZaBWkThGr3c==hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪྦ"): xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧྦྷ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫྨ"))
	elif zzpKCYP0jIqRFVXgoJtZaBWkThGr3c==B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬྩ"): xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(ba49YvOK2Aw8Uhxt(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪྪ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(pL73X0MYajJQG4n1qgD(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪྫ")) not in [KKCrwPdOgGl(u"ࠨࡃࡘࡘࡔ࠭ྫྷ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡖࡘࡔࡖࠧྭ"),zWBnYSGIatjXVC(u"ࠪࡅࡘࡑࠧྮ")]: xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(CCWqR3dmtzw6xoIX41(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧྯ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡇࡓࡌࠩྰ"))
	if xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫྱ")) not in [pbmKZA1w7L4zHjOM(u"ࠧࡂࡗࡗࡓࠬྲ"),rAYDiWlzm9MCU6x0GnROua(u"ࠨࡕࡗࡓࡕ࠭ླ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡄࡗࡐ࠭ྴ")]: xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨྵ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡆ࡙ࡋࠨྶ"))
	n2wlM0qyIA48xhKQJaFOi5eoPG6k = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪྷ"))
	rFuOmIeV4l6 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩྸ"))
	if zWBnYSGIatjXVC(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ྐྵ") in str(rFuOmIeV4l6) and n2wlM0qyIA48xhKQJaFOi5eoPG6k in [nR0ok9zju84rFUQl1YC(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫྺ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨྻ")]:
		f7epsRlYtMz4.sleep(zWBnYSGIatjXVC(u"࠵࠴࠱࠱࠲ဒ"))
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(nR0ok9zju84rFUQl1YC(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧྼ"))
	if nUaVQsoA6EXcK4Odht5wCge0J8Pib and yyRW7r1KOgHNcdmnJvS5iQ4f0>-xD9WeoEAsX7:
		NEYCX82mhdSJUptfu0LWk9szKy.setResolvedUrl(yyRW7r1KOgHNcdmnJvS5iQ4f0,pLwgjkuTs6CS,vRVl0MpXZDwAYB4ag68nc.ListItem())
		oo3n0EuaHjYSz,tyPEX0TBVzUfiHAN85w9xYnb2kp,s9s85D3mSx4RdzoMZAawgT6VcCeU = pLwgjkuTs6CS,pLwgjkuTs6CS,pLwgjkuTs6CS
		NEYCX82mhdSJUptfu0LWk9szKy.endOfDirectory(yyRW7r1KOgHNcdmnJvS5iQ4f0,oo3n0EuaHjYSz,tyPEX0TBVzUfiHAN85w9xYnb2kp,s9s85D3mSx4RdzoMZAawgT6VcCeU)
	if drzqWFkSHD.SEND_THESE_EVENTS: LebOcpUwr9K4fxihGDlTHZW2P(drzqWFkSHD.SEND_THESE_EVENTS)
	KkvpdQS6TG3f4mlDzqB7t = ccdRQGbtEaD2WSp()
	tvBhiQp5kIbKHMP6f(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡸࡺ࡯ࡱࠩ྽"),pLwgjkuTs6CS)
	if KkvpdQS6TG3f4mlDzqB7t and not drzqWFkSHD.resolveonly:
		drzqWFkSHD.resolveonly = NFGqKBLtvUZn1S3dau
		Jh3fArxWiMwNURO6kymPuGCTeta = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player().isPlaying()
		if not Jh3fArxWiMwNURO6kymPuGCTeta: dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(lRKCWnNi0Edr984eI(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬ྾"))
		else:
			Ev8bgftZIsS3TUJ = mj5TX9GeyDwBaR3i6zb0qov()
			if Ev8bgftZIsS3TUJ:
				import YnWpIJVfFz,UUtiyoRJ6h
				for OOWFun1mZvjJIiKlRSQgT624 in range(nUaVQsoA6EXcK4Odht5wCge0J8Pib,zzdmZ5urYvoKXV,anb4QpyjlmgVwANP):
					f7epsRlYtMz4.sleep(anb4QpyjlmgVwANP)
					Jh3fArxWiMwNURO6kymPuGCTeta = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player().isPlaying()
					if not Jh3fArxWiMwNURO6kymPuGCTeta:
						UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭วๅใํำ๏๎ࠠศๆ็หา่ࠧ྿"),pL73X0MYajJQG4n1qgD(u"ࠧฦๆ฽หฦࠦแฮืࠣหู้๊าใิหฯ࠭࿀"),f7epsRlYtMz4=pYeVwat64v(u"࠻࠰࠱ဓ"))
						break
				else:
					YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = XjPqWt1BdDk(Ev8bgftZIsS3TUJ)
					if not any(value in X3cxeAQbjSnkK2sY9ZgJB8ma for value in YnWpIJVfFz.NOT_TO_TEST_ALL_SERVERS):
						UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨษ็ๅ๏ี๊้ࠢส่้ออใࠩ࿁"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩไัฺࠦฬๆ์฼ࠤฬ๊ำ๋ำไีฬะࠧ࿂"),f7epsRlYtMz4=rAYDiWlzm9MCU6x0GnROua(u"࠷࠶࠲န"))
						f7epsRlYtMz4.sleep(H3OKMjDG1evnl4Ruiz)
						if hT1JIgqPQsUOZp5tjCX0E:
							HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.encode(RMGz7OiD1e30P)
						YnWpIJVfFz.zCtB6lUJjnOcHibaErDuP2xGf(OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh)
						Ubud2NhHKRnMTvI5mprQBVqk80 = YnWpIJVfFz.J3t4CspyDNgjv9MbzAqELQFx5Z(YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
						YnWpIJVfFz.zCtB6lUJjnOcHibaErDuP2xGf(btR0Zix9D2g,btR0Zix9D2g,btR0Zix9D2g)
						UUtiyoRJ6h.ARL0tsEeanKImhMByugPTvX7(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫ࿃"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫฬ์ส่๋ࠣๅา฻ࠠศๆึ๎ึ็ัศฬࠪ࿄"),f7epsRlYtMz4=I6Bfzysrvb8DONZ(u"࠸࠷࠳ပ"))
						I6qmSzBFVJoAywPT29 = pLwgjkuTs6CS
	rTnfMyoAJuXQGmtZCNgkR1j = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ࿅"))
	if KKCrwPdOgGl(u"࠭࠭ࠨ࿆") in rTnfMyoAJuXQGmtZCNgkR1j:
		rTnfMyoAJuXQGmtZCNgkR1j = rTnfMyoAJuXQGmtZCNgkR1j.replace(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧ࠮ࠩ࿇"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(pbmKZA1w7L4zHjOM(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ࿈"),rTnfMyoAJuXQGmtZCNgkR1j)
	if I6qmSzBFVJoAywPT29: mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(pL73X0MYajJQG4n1qgD(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭࿉"))
	return
def mj5TX9GeyDwBaR3i6zb0qov():
	h8VPdbyKWaiJqDu1f2T5CBH = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(rAYDiWlzm9MCU6x0GnROua(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡌ࡫ࡴࡊࡶࡨࡱࡸࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ࠽࡟ࠧࡺࡩࡵ࡮ࡨࠦ࠱ࠨࡦࡪ࡮ࡨࠦ࠱ࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤࡠࢁ࠱ࠨࡩࡥࠤ࠽࠵ࢂ࠭࿊"))
	Ubud2NhHKRnMTvI5mprQBVqk80 = WWNb0XnUxOPL9gF.loads(h8VPdbyKWaiJqDu1f2T5CBH)[GTmHXIZUSdxRhMnqQKkO(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ࿋")]
	Ev8bgftZIsS3TUJ = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	try: items = Ubud2NhHKRnMTvI5mprQBVqk80[W2Vv30i8qxSuItfsolPLdFZA(u"ࠬ࡯ࡴࡦ࡯ࡶࠫ࿌")]
	except: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if items:
		for u74UPEicpBdq32C,file in enumerate(items):
			path = file[awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡦࡪ࡮ࡨࠫ࿍")]
			if fFwqoWYPMVRJDtN9m3bCihpz not in path: continue
			path = path.split(fFwqoWYPMVRJDtN9m3bCihpz)[xD9WeoEAsX7][xD9WeoEAsX7:]
			if path==utdV6CEfRBM: break
		count = Ubud2NhHKRnMTvI5mprQBVqk80[Zb5cNeHWi6jP9SCYtUgR(u"ࠧ࡭࡫ࡰ࡭ࡹࡹࠧ࿎")][rAYDiWlzm9MCU6x0GnROua(u"ࠨࡶࡲࡸࡦࡲࠧ࿏")]
		if u74UPEicpBdq32C+xD9WeoEAsX7<count: Ev8bgftZIsS3TUJ = items[u74UPEicpBdq32C+xD9WeoEAsX7][awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡩ࡭ࡱ࡫ࠧ࿐")]
	return Ev8bgftZIsS3TUJ
def ccdRQGbtEaD2WSp():
	dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤࢀࢁࠬ࿑"))
	y2pD9zOcdsLGFJS = pLwgjkuTs6CS if slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡠࡣࠧ࿒") in str(dNoS1wQ9UD5F) else NFGqKBLtvUZn1S3dau
	return y2pD9zOcdsLGFJS
def tvBhiQp5kIbKHMP6f(E8EJPKSQybnH6,Thzjm3l5qgc=pLwgjkuTs6CS):
	if E8EJPKSQybnH6==w9wfONXUP3(u"ࠬࡹࡴࡰࡲࠪ࿓") and (Thzjm3l5qgc or drzqWFkSHD.busydialog_active):
		if Thzjm3l5qgc: mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(pYeVwat64v(u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭ࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠫࠪ࿔"))
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯࠭ࠬ࿕"))
		drzqWFkSHD.busydialog_active = pLwgjkuTs6CS
	if E8EJPKSQybnH6==f9fOpCmLAEaW2Go(u"ࠨࡵࡷࡥࡷࡺࠧ࿖") and (Thzjm3l5qgc or not drzqWFkSHD.busydialog_active):
		TmjiG3ND6eQ = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧ࿗") if XqSerIMoFsRn2UQ1D5Alj6>Zb5cNeHWi6jP9SCYtUgR(u"࠳࠺࠲࠾࠿ဖ") else kAz7WRYjrfGm(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧ࿘")
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭࿙")+TmjiG3ND6eQ+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬ࠯ࠧ࿚"))
		drzqWFkSHD.busydialog_active = NFGqKBLtvUZn1S3dau
	return
def spd4z80uZXHyGxo6YqPhWSLaw1b(*args,**BGqshVU3ycCNTWblpk2gFw4ij5):
	daemon = BGqshVU3ycCNTWblpk2gFw4ij5.pop(I6Bfzysrvb8DONZ(u"࠭ࡤࡢࡧࡰࡳࡳ࠭࿛"),pLwgjkuTs6CS)
	FHgcrTZdSNu = FK8OfSUyPDl30z.Thread(*args,**BGqshVU3ycCNTWblpk2gFw4ij5)
	try: FHgcrTZdSNu.setDaemon(daemon)
	except: pass
	try: FHgcrTZdSNu.daemon = daemon
	except: pass
	return FHgcrTZdSNu
JbC2ZL4shGiDE = dYMLGvgfk4(mmEuUR4JdaHtAsS,lRKCWnNi0Edr984eI(u"ࠧ࡭࡫ࡶࡸࠬ࿜"),zWBnYSGIatjXVC(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ࿝"),KKCrwPdOgGl(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ࿞"))
if JbC2ZL4shGiDE:
	Do5A9e0c4Om,RPUFIMvnxub7AiC95do3N,jHl12DYAxw,UULrN410if68gyFOwQvBGA3M = JbC2ZL4shGiDE
	drzqWFkSHD.AV_CLIENT_IDS = b8sk5WyPoz03pXhRx.join(Do5A9e0c4Om)
if not drzqWFkSHD.AV_CLIENT_IDS: drzqWFkSHD.AV_CLIENT_IDS = ih5mrq2OAK3tXFIpfcJRVe4Z()
LHipOJX9eRG8VrscYDzB7 = cyeCjzpOrRwME()
drzqWFkSHD.nt9ZocbLGBOMx2,drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3,drzqWFkSHD.OpUqQARsFDdGT6gJ5HwI4KYV,drzqWFkSHD.AAlBxcVDnSr,drzqWFkSHD.avprivsnorestrict,drzqWFkSHD.avprivslongperiod = LTbKCxY4nX92jSDy7t([f9fOpCmLAEaW2Go(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ࿟"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ࿠"),f9fOpCmLAEaW2Go(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪ࿡"),YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧ࿢"),GTmHXIZUSdxRhMnqQKkO(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡬࡮ࡇ࡚ࡊ࡜ࡅ࡙ࠩ࿣"),Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧ࿤")])
QYhMUcDf60 = drzqWFkSHD.AV_CLIENT_IDS.splitlines()[nUaVQsoA6EXcK4Odht5wCge0J8Pib][-KKCrwPdOgGl(u"࠵࠸ဗ"):]