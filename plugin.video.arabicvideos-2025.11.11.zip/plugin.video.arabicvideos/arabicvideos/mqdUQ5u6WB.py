# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'FASELHD1'
headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
qBAgzkG9oCL = '_FH1_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['جوائز الأوسكار','المراجعات','wwe']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==570: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==571: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==572: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==573: Ubud2NhHKRnMTvI5mprQBVqk80 = ErZkM18Pf2S0VKNAzb(url,text)
	elif mode==576: Ubud2NhHKRnMTvI5mprQBVqk80 = xUjIFbZmYk2oWsVt()
	elif mode==579: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+'لماذا الموقع بطيء',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,576)
	GGRexoVTLjusn6q,url = S7EgasGcYdIo,S7EgasGcYdIo
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD1-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',GGRexoVTLjusn6q,579,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'المميزة',GGRexoVTLjusn6q,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured1')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('class="h3">(.*?)<.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for title,cX2SpPxGLmADTKl in items:
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'details1')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"menu-primary"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		pyh0NfBVUbctiAQ12 = AxTYMhRlfyskNc0X19dvwtS.findall('<li (.*?)</li>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		Hf6n731i8DNLEthq = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		r6dVWlzDj9va0FxqfkOwLYZEmP = 0
		for oFQHL7AaItXmfCz4yPKT0pc1ie in pyh0NfBVUbctiAQ12:
			if r6dVWlzDj9va0FxqfkOwLYZEmP>0: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',oFQHL7AaItXmfCz4yPKT0pc1ie,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl=='#': continue
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+cX2SpPxGLmADTKl
				if title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: continue
				if any(value in title.lower() for value in kCIESuy4j5mVLZYtG9vDNnb7): continue
				title = Hf6n731i8DNLEthq[r6dVWlzDj9va0FxqfkOwLYZEmP]+title
				w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'details2')
			r6dVWlzDj9va0FxqfkOwLYZEmP += 1
	return
def xUjIFbZmYk2oWsVt():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD1-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('class="h4">(.*?)</div>(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not fxgnWRoUO7jNwtJkuB: return
	if type=='filters':
		vvuraxgW7YLIZ4hU0MbCt = [R8AE9e4mYxVhusL3Q.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"homeSlide"(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		VxGUiHPDWJtCbsa7qpEy0O,BA01W9olieErLycV7kwFvOhH5Y3ms,p3USGyZE9bKVhvjtd4W0 = zip(*items)
		items = zip(BA01W9olieErLycV7kwFvOhH5Y3ms,VxGUiHPDWJtCbsa7qpEy0O,p3USGyZE9bKVhvjtd4W0)
	elif type=='featured2':
		title,IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif type=='details2' and len(fxgnWRoUO7jNwtJkuB)>1:
		title = fxgnWRoUO7jNwtJkuB[0][0]
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured2')
		title = fxgnWRoUO7jNwtJkuB[1][0]
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'details3')
		return
	else:
		title,IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[-1]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		if any(value in title.lower() for value in kCIESuy4j5mVLZYtG9vDNnb7): continue
		RRx0ri8bETI = kd8ZhJPCe7QzxLgij3TEHlGtOv(RRx0ri8bETI)
		RRx0ri8bETI = RRx0ri8bETI.split('?resize=')[0]
		title = riUKNnOEtVwdj4(title)
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if '/collections/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,571,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and type==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			title = '_MOD_'+azhwpE0qmevcFobdRi[0][0]
			title = title.strip(' –')
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,573,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif 'episodes/' in cX2SpPxGLmADTKl or 'movies/' in cX2SpPxGLmADTKl or 'hindi/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,572,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,573,RRx0ri8bETI)
	if type=='filters':
		bWKf9xzqe5TVNtAlsMoI = AxTYMhRlfyskNc0X19dvwtS.findall('"more_button_page":(.*?),',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if bWKf9xzqe5TVNtAlsMoI:
			count = bWKf9xzqe5TVNtAlsMoI[0]
			cX2SpPxGLmADTKl = url+'/offset/'+count
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة أخرى',cX2SpPxGLmADTKl,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filters')
	elif 'details' in type:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall("class='pagination(.*?)</div>",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall("href='(.*?)'.*?>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				title = 'صفحة '+riUKNnOEtVwdj4(title)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,571,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'details4')
	return
def ErZkM18Pf2S0VKNAzb(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD1-SEASONS_EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	uySI4qTsgKzWVUG9frhj1owtx8i2p = False
	if not type:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"seasonList"(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if len(items)>1:
				GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
				uySI4qTsgKzWVUG9frhj1owtx8i2p = True
				for cX2SpPxGLmADTKl,RRx0ri8bETI,name,title in items:
					name = riUKNnOEtVwdj4(name)
					if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+cX2SpPxGLmADTKl
					title = name+' - '+title
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,573,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'episodes')
	if type=='episodes' or not uySI4qTsgKzWVUG9frhj1owtx8i2p:
		E7MF9aYlV4Q0 = AxTYMhRlfyskNc0X19dvwtS.findall('"posterImg".*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if E7MF9aYlV4Q0: RRx0ri8bETI = E7MF9aYlV4Q0[0]
		else: RRx0ri8bETI = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"epAll"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				title = riUKNnOEtVwdj4(title)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,572,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu,VVvfWS9rl36Lq1g4nx,GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = [],[],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD1-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	DLwj8YRTnlifSUm9EoXvV1 = AxTYMhRlfyskNc0X19dvwtS.findall('مستوى المشاهدة.*?">(.*?)</span>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if DLwj8YRTnlifSUm9EoXvV1:
		OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('"tag">(.*?)</a>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd): return
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"videoRow"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('&img=')[0]
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="streamHeader(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("href = '(.*?)'.*?</i>(.*?)</a>",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,name in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('&img=')[0]
			name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+name+'__watch')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="downloadLinks(.*?)blackwindow',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</span>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,name in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('&img=')[0]
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+name+'__download')
	for T5Pa8nUbDMGsfWmCJKgHtj3 in dU17fayKLj4kABu:
		cX2SpPxGLmADTKl,name = T5Pa8nUbDMGsfWmCJKgHtj3.split('?named')
		if cX2SpPxGLmADTKl not in VVvfWS9rl36Lq1g4nx:
			VVvfWS9rl36Lq1g4nx.append(cX2SpPxGLmADTKl)
			GQAq8OnFcBve2Zi4oLH0mzNWU6hYK.append(T5Pa8nUbDMGsfWmCJKgHtj3)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(GQAq8OnFcBve2Zi4oLH0mzNWU6hYK,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	nUDgc4absePT2xMt = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(nUDgc4absePT2xMt,'details5')
	return