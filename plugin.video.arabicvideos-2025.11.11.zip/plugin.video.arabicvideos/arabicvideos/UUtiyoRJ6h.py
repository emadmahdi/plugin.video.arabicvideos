# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from MEyOuW8nmK import *
class cNbV38o7ADCgnh(CGM5VAJ1B0meTIyjiwpSrb3P9):
	def __init__(RRJ40CMUDwHiEQ,*aargs,**kkwargs):
		RRJ40CMUDwHiEQ.choiceID = -xD9WeoEAsX7
	def onClick(RRJ40CMUDwHiEQ,EOGwjqTLl6FN2yW4AC5znXg):
		if EOGwjqTLl6FN2yW4AC5znXg>=ba49YvOK2Aw8Uhxt(u"࠿࠰࠲࠲ஂ"): RRJ40CMUDwHiEQ.choiceID = EOGwjqTLl6FN2yW4AC5znXg-ba49YvOK2Aw8Uhxt(u"࠿࠰࠲࠲ஂ")
		RRJ40CMUDwHiEQ.jmQKTgP8l2Xbohk()
	def RgH7UpSCIjTAE206bGWa4BXLh(RRJ40CMUDwHiEQ,*aargs):
		RRJ40CMUDwHiEQ.button0,RRJ40CMUDwHiEQ.button1,RRJ40CMUDwHiEQ.button2 = aargs[nUaVQsoA6EXcK4Odht5wCge0J8Pib],aargs[xD9WeoEAsX7],aargs[H3OKMjDG1evnl4Ruiz]
		RRJ40CMUDwHiEQ.header,RRJ40CMUDwHiEQ.text = aargs[anb4QpyjlmgVwANP],aargs[gybxTLFEw2]
		RRJ40CMUDwHiEQ.profile,RRJ40CMUDwHiEQ.direction = aargs[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠵ஃ")],aargs[W2Vv30i8qxSuItfsolPLdFZA(u"࠷஄")]
		RRJ40CMUDwHiEQ.buttonstimeout,RRJ40CMUDwHiEQ.closetimeout = aargs[pbmKZA1w7L4zHjOM(u"࠺ஆ")],aargs[zWBnYSGIatjXVC(u"࠺அ")]
		if RRJ40CMUDwHiEQ.buttonstimeout>nUaVQsoA6EXcK4Odht5wCge0J8Pib or RRJ40CMUDwHiEQ.closetimeout>bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠴இ"): RRJ40CMUDwHiEQ.enable_progressbar = NFGqKBLtvUZn1S3dau
		else: RRJ40CMUDwHiEQ.enable_progressbar = pLwgjkuTs6CS
		RRJ40CMUDwHiEQ.image_filename = KK4Fa7Sj0L3CywRgQxZk.replace(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ૮"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࡟ࠨ૯")+str(f7epsRlYtMz4.time())+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࡠࠩ૰"))
		RRJ40CMUDwHiEQ.image_filename = RRJ40CMUDwHiEQ.image_filename.replace(pbmKZA1w7L4zHjOM(u"ࠨ࡞࡟ࠫ૱"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࡟ࡠࡡࡢࠧ૲")).replace(pYeVwat64v(u"ࠪ࠳࠴࠭૳"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠴࠵࠯࠰ࠩ૴"))
		RRJ40CMUDwHiEQ.image_height = jxPI6iZF4rwObyT8V17ptSakEG3(RRJ40CMUDwHiEQ.button0,RRJ40CMUDwHiEQ.button1,RRJ40CMUDwHiEQ.button2,RRJ40CMUDwHiEQ.header,RRJ40CMUDwHiEQ.text,RRJ40CMUDwHiEQ.profile,RRJ40CMUDwHiEQ.direction,RRJ40CMUDwHiEQ.enable_progressbar,RRJ40CMUDwHiEQ.image_filename)
		RRJ40CMUDwHiEQ.show()
		RRJ40CMUDwHiEQ.getControl(B1YMtuvRAGNlJOkC46VyPKQE(u"࠾࠶࠵࠱ஈ")).setImage(RRJ40CMUDwHiEQ.image_filename)
		RRJ40CMUDwHiEQ.getControl(hWRvZOYtjme9QNnV41u0Mswb(u"࠿࠰࠶࠲உ")).setHeight(RRJ40CMUDwHiEQ.image_height)
		if not RRJ40CMUDwHiEQ.button1 and RRJ40CMUDwHiEQ.button0 and RRJ40CMUDwHiEQ.button2: RRJ40CMUDwHiEQ.getControl(KKCrwPdOgGl(u"࠺࠲࠴࠶஋")).setPosition(-pYeVwat64v(u"࠴࠵࠴஌"),zWBnYSGIatjXVC(u"࠰ஊ"))
		return RRJ40CMUDwHiEQ.image_filename,RRJ40CMUDwHiEQ.image_height
	def fpniqut0CxJk84PDjQrzZlI(RRJ40CMUDwHiEQ):
		if RRJ40CMUDwHiEQ.buttonstimeout:
			RRJ40CMUDwHiEQ.th1 = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=RRJ40CMUDwHiEQ.J6RianEQ43CSTLm)
			RRJ40CMUDwHiEQ.th1.start()
		else: RRJ40CMUDwHiEQ.tQ0B4hrc1m()
	def J6RianEQ43CSTLm(RRJ40CMUDwHiEQ):
		RRJ40CMUDwHiEQ.getControl(ba49YvOK2Aw8Uhxt(u"࠼࠴࠷࠶஍")).setEnabled(NFGqKBLtvUZn1S3dau)
		for r6dVWlzDj9va0FxqfkOwLYZEmP in range(xD9WeoEAsX7,RRJ40CMUDwHiEQ.buttonstimeout+xD9WeoEAsX7):
			f7epsRlYtMz4.sleep(xD9WeoEAsX7)
			uHsnLjwMVYWK7SpC3PUFA = int(kAz7WRYjrfGm(u"࠵࠵࠶எ")*r6dVWlzDj9va0FxqfkOwLYZEmP/RRJ40CMUDwHiEQ.buttonstimeout)
			RRJ40CMUDwHiEQ.XpDIvUk5MKRq6tJlcaS(uHsnLjwMVYWK7SpC3PUFA)
			if RRJ40CMUDwHiEQ.choiceID>kAz7WRYjrfGm(u"࠵ஏ"): break
		RRJ40CMUDwHiEQ.tQ0B4hrc1m()
	def a6aIbAdszG(RRJ40CMUDwHiEQ):
		if RRJ40CMUDwHiEQ.closetimeout:
			RRJ40CMUDwHiEQ.th2 = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=RRJ40CMUDwHiEQ.MaJC7F3tAWf6R9)
			RRJ40CMUDwHiEQ.th2.start()
		else: RRJ40CMUDwHiEQ.tQ0B4hrc1m()
	def MaJC7F3tAWf6R9(RRJ40CMUDwHiEQ):
		RRJ40CMUDwHiEQ.getControl(pYeVwat64v(u"࠿࠰࠳࠲ஐ")).setEnabled(NFGqKBLtvUZn1S3dau)
		f7epsRlYtMz4.sleep(RRJ40CMUDwHiEQ.buttonstimeout)
		for r6dVWlzDj9va0FxqfkOwLYZEmP in range(RRJ40CMUDwHiEQ.closetimeout-xD9WeoEAsX7,-xD9WeoEAsX7,-xD9WeoEAsX7):
			f7epsRlYtMz4.sleep(xD9WeoEAsX7)
			uHsnLjwMVYWK7SpC3PUFA = int(hWRvZOYtjme9QNnV41u0Mswb(u"࠱࠱࠲஑")*r6dVWlzDj9va0FxqfkOwLYZEmP/RRJ40CMUDwHiEQ.closetimeout)
			RRJ40CMUDwHiEQ.XpDIvUk5MKRq6tJlcaS(uHsnLjwMVYWK7SpC3PUFA)
			if RRJ40CMUDwHiEQ.choiceID>nUaVQsoA6EXcK4Odht5wCge0J8Pib: break
		if RRJ40CMUDwHiEQ.closetimeout>nUaVQsoA6EXcK4Odht5wCge0J8Pib: RRJ40CMUDwHiEQ.choiceID = pbmKZA1w7L4zHjOM(u"࠲࠲ஒ")
		RRJ40CMUDwHiEQ.jmQKTgP8l2Xbohk()
	def XpDIvUk5MKRq6tJlcaS(RRJ40CMUDwHiEQ,uHsnLjwMVYWK7SpC3PUFA):
		RRJ40CMUDwHiEQ.precent = uHsnLjwMVYWK7SpC3PUFA
		RRJ40CMUDwHiEQ.getControl(djapWhrveLJbgnViDftFNY05ylq1S(u"࠻࠳࠶࠵ஓ")).setPercent(RRJ40CMUDwHiEQ.precent)
	def tQ0B4hrc1m(RRJ40CMUDwHiEQ):
		if RRJ40CMUDwHiEQ.button0: RRJ40CMUDwHiEQ.getControl(W2Vv30i8qxSuItfsolPLdFZA(u"࠼࠴࠶࠶ஔ")).setEnabled(NFGqKBLtvUZn1S3dau)
		if RRJ40CMUDwHiEQ.button1: RRJ40CMUDwHiEQ.getControl(B1YMtuvRAGNlJOkC46VyPKQE(u"࠽࠵࠷࠱க")).setEnabled(NFGqKBLtvUZn1S3dau)
		if RRJ40CMUDwHiEQ.button2: RRJ40CMUDwHiEQ.getControl(W2Vv30i8qxSuItfsolPLdFZA(u"࠾࠶࠱࠳஖")).setEnabled(NFGqKBLtvUZn1S3dau)
	def jmQKTgP8l2Xbohk(RRJ40CMUDwHiEQ):
		RRJ40CMUDwHiEQ.close()
		try: oNlez5gnM9x2B4.remove(RRJ40CMUDwHiEQ.image_filename)
		except: pass
def w4dBvakygFs2IZO1Azt(*aargs,**kkwargs):
	if aargs:
		direction = aargs[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		nkLwNjDSFHe2pIWgC1P5 = aargs[xD9WeoEAsX7]
		if not direction: direction = hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ૵")
		if not nkLwNjDSFHe2pIWgC1P5: nkLwNjDSFHe2pIWgC1P5 = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭วิฬ่ีฬืࠧ૶")
		rrcSWI6RPp5yB3ZVha9NYxKnDu = aargs[H3OKMjDG1evnl4Ruiz]
		W0d8hJxSvNlqokHnugMU = b8sk5WyPoz03pXhRx.join(aargs[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠹஗"):])
	else: direction,nkLwNjDSFHe2pIWgC1P5,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡐࡍࠪ૷"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	uPS1UedvhXl6MHVbq7zr5Z92Tig(direction,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nkLwNjDSFHe2pIWgC1P5,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,**kkwargs)
	return
def hhTcd5XlykBUu68zAb9OmgC(*aargs,**kkwargs):
	direction = aargs[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	lMtNg45nSy8G = aargs[xD9WeoEAsX7]
	ccxu7BYM1CywGehrPaUdIg4 = aargs[H3OKMjDG1evnl4Ruiz]
	if ccxu7BYM1CywGehrPaUdIg4 or lMtNg45nSy8G: B1hoajruNzf = NFGqKBLtvUZn1S3dau
	else: B1hoajruNzf = pLwgjkuTs6CS
	rrcSWI6RPp5yB3ZVha9NYxKnDu = aargs[anb4QpyjlmgVwANP]
	W0d8hJxSvNlqokHnugMU = aargs[gybxTLFEw2]
	if not direction: direction = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ૸")
	if not lMtNg45nSy8G: lMtNg45nSy8G = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩๆ่ฬࠦࠠࡏࡱࠪૹ")
	if not ccxu7BYM1CywGehrPaUdIg4: ccxu7BYM1CywGehrPaUdIg4 = lRKCWnNi0Edr984eI(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬૺ")
	if len(aargs)>=kAz7WRYjrfGm(u"࠷ங"): W0d8hJxSvNlqokHnugMU += b8sk5WyPoz03pXhRx+aargs[pbmKZA1w7L4zHjOM(u"࠵஘")]
	if len(aargs)>=hWRvZOYtjme9QNnV41u0Mswb(u"࠹ச"): W0d8hJxSvNlqokHnugMU += b8sk5WyPoz03pXhRx+aargs[awSUTRNMkdIW7sFEvnHD2mLY(u"࠹஛")]
	RsKir4SuAxkEY = uPS1UedvhXl6MHVbq7zr5Z92Tig(direction,lMtNg45nSy8G,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ccxu7BYM1CywGehrPaUdIg4,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,**kkwargs)
	if RsKir4SuAxkEY==-pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠵ஜ") and B1hoajruNzf: RsKir4SuAxkEY = -xD9WeoEAsX7
	elif RsKir4SuAxkEY==-xD9WeoEAsX7 and not B1hoajruNzf: RsKir4SuAxkEY = pLwgjkuTs6CS
	elif RsKir4SuAxkEY==nUaVQsoA6EXcK4Odht5wCge0J8Pib: RsKir4SuAxkEY = pLwgjkuTs6CS
	elif RsKir4SuAxkEY==H3OKMjDG1evnl4Ruiz: RsKir4SuAxkEY = NFGqKBLtvUZn1S3dau
	return RsKir4SuAxkEY
def YLUMzC9m0dc(*aargs,**kkwargs):
	return vRVl0MpXZDwAYB4ag68nc.Dialog().select(*aargs,**kkwargs)
def ARL0tsEeanKImhMByugPTvX7(*aargs,**kkwargs):
	rrcSWI6RPp5yB3ZVha9NYxKnDu = aargs[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	W0d8hJxSvNlqokHnugMU = aargs[xD9WeoEAsX7]
	lSEzBJnqp0tM5Od9NFA = kkwargs[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡹ࡯࡭ࡦࠩૻ")] if CCWqR3dmtzw6xoIX41(u"ࠬࡺࡩ࡮ࡧࠪૼ") in list(kkwargs.keys()) else YzlId3Fs6vpehcbLGj0UaO(u"࠶࠶࠰࠱஝")
	SEtwgnmRVY7xdu8H1hya3jZFpPJ = aargs[H3OKMjDG1evnl4Ruiz] if len(aargs)>H3OKMjDG1evnl4Ruiz and MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡴࡪ࡯ࡨࠫ૽") not in aargs[H3OKMjDG1evnl4Ruiz] else MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ૾")
	FHgcrTZdSNu = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=JaxAto12iHSYXdNlIVyPRejFE,args=(rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,SEtwgnmRVY7xdu8H1hya3jZFpPJ,lSEzBJnqp0tM5Od9NFA))
	FHgcrTZdSNu.start()
	return
def JaxAto12iHSYXdNlIVyPRejFE(rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,SEtwgnmRVY7xdu8H1hya3jZFpPJ,lSEzBJnqp0tM5Od9NFA):
	Ngx4oKDuIB5hRL09EMwvbHa = SEtwgnmRVY7xdu8H1hya3jZFpPJ.replace(I6Bfzysrvb8DONZ(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࠨ૿"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	import OQ27yuoU3i
	name = OQ27yuoU3i.cqHgRBFQ7XmEkTx50nWLS6fIhDb(NFGqKBLtvUZn1S3dau,Ngx4oKDuIB5hRL09EMwvbHa+hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࠣ࠱ࠥ࠭଀")+rrcSWI6RPp5yB3ZVha9NYxKnDu+zWBnYSGIatjXVC(u"ࠪࠤ࠲ࠦࠧଁ")+W0d8hJxSvNlqokHnugMU)
	name = OQ27yuoU3i.bLXh6Qy5Tewk(name)
	image_filename = oNlez5gnM9x2B4.path.join(hpGOZ6jBuxm3U49oH2Lv,name+pYeVwat64v(u"ࠫ࠳ࡶ࡮ࡨࠩଂ"))
	if oNlez5gnM9x2B4.path.exists(image_filename):
		if SEtwgnmRVY7xdu8H1hya3jZFpPJ==YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡷ࡫ࡧࡶ࡮ࡤࡶࠬଃ"): image_height = djapWhrveLJbgnViDftFNY05ylq1S(u"࠷࠱࠸ஞ")
		elif SEtwgnmRVY7xdu8H1hya3jZFpPJ==awSUTRNMkdIW7sFEvnHD2mLY(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪ଄"): image_height = rAYDiWlzm9MCU6x0GnROua(u"࠲࠲࠲ட")
	else: image_height = jxPI6iZF4rwObyT8V17ptSakEG3(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,SEtwgnmRVY7xdu8H1hya3jZFpPJ,W2Vv30i8qxSuItfsolPLdFZA(u"ࠧ࡭ࡧࡩࡸࠬଅ"),pLwgjkuTs6CS,image_filename)
	TmjiG3ND6eQ = CGM5VAJ1B0meTIyjiwpSrb3P9(hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡆ࡬ࡥࡱࡵࡧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡏ࡭ࡢࡩࡨ࠲ࡽࡳ࡬ࠨଆ"),rq4Bz50iokn,ba49YvOK2Aw8Uhxt(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪଇ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠪ࠻࠷࠶ࡰࠨଈ"))
	TmjiG3ND6eQ.show()
	if SEtwgnmRVY7xdu8H1hya3jZFpPJ==kAz7WRYjrfGm(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡥࡺࡺ࡯ࠨଉ"):
		TmjiG3ND6eQ.getControl(djapWhrveLJbgnViDftFNY05ylq1S(u"࠻࠳࠸࠵஡")).setHeight(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠳࠳࠸஠"))
		TmjiG3ND6eQ.getControl(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠾࠶࠴࠱த")).setPosition(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠸࠹஢"),-kAz7WRYjrfGm(u"࠼࠵ண"))
		TmjiG3ND6eQ.getControl(awSUTRNMkdIW7sFEvnHD2mLY(u"࠿࠰࠶࠲஥")).setPosition(ba49YvOK2Aw8Uhxt(u"࠱࠳࠲஦"),-CCWqR3dmtzw6xoIX41(u"࠷࠲஧"))
		TmjiG3ND6eQ.getControl(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠸࠵࠶ப")).setPosition(CCWqR3dmtzw6xoIX41(u"࠻࠳ந"),-B1YMtuvRAGNlJOkC46VyPKQE(u"࠶࠹ன"))
	TmjiG3ND6eQ.getControl(hWRvZOYtjme9QNnV41u0Mswb(u"࠹࠶࠱஫")).setVisible(pLwgjkuTs6CS)
	TmjiG3ND6eQ.getControl(vl6rwMLasAQo4z1ZjD3IBKtF(u"࠺࠰࠳஬")).setVisible(pLwgjkuTs6CS)
	TmjiG3ND6eQ.getControl(CCWqR3dmtzw6xoIX41(u"࠹࠱࠷࠳஭")).setImage(image_filename)
	TmjiG3ND6eQ.getControl(zWBnYSGIatjXVC(u"࠺࠲࠸࠴ம")).setHeight(image_height)
	f7epsRlYtMz4.sleep(lSEzBJnqp0tM5Od9NFA//JZ45mOctiTszPNw1GVjxhep2Y(u"࠳࠳࠴࠵࠴࠰ய"))
	return
def okvXCAsSQLyfJ6xrUM0nz2(*aargs,**kkwargs):
	rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,profile,direction = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ba49YvOK2Aw8Uhxt(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ଊ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭࡬ࡦࡨࡷࠫଋ")
	if len(aargs)>=xD9WeoEAsX7: rrcSWI6RPp5yB3ZVha9NYxKnDu = aargs[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if len(aargs)>=H3OKMjDG1evnl4Ruiz: W0d8hJxSvNlqokHnugMU = aargs[xD9WeoEAsX7]
	if len(aargs)>=anb4QpyjlmgVwANP: profile = aargs[H3OKMjDG1evnl4Ruiz]
	if len(aargs)>=gybxTLFEw2: direction = aargs[anb4QpyjlmgVwANP]
	return RsYWOkAC8t4iMUoBd0K(direction,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,profile)
def U5UKxjWSshITucleR8B(*aargs,**kkwargs):
	return vRVl0MpXZDwAYB4ag68nc.Dialog().contextmenu(*aargs,**kkwargs)
def ddMy7StKng0rkXPIzaJOULwEo4(*aargs,**kkwargs):
	return vRVl0MpXZDwAYB4ag68nc.Dialog().browseSingle(*aargs,**kkwargs)
def AAuUIjVngEL9(*aargs,**kkwargs):
	return vRVl0MpXZDwAYB4ag68nc.Dialog().input(*aargs,**kkwargs)
def QHi2JtdhMaw0INlU(*aargs,**kkwargs):
	return vRVl0MpXZDwAYB4ag68nc.DialogProgress(*aargs,**kkwargs)
def uPS1UedvhXl6MHVbq7zr5Z92Tig(direction,button0=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,button1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,button2=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rrcSWI6RPp5yB3ZVha9NYxKnDu=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W0d8hJxSvNlqokHnugMU=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,profile=Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩଌ"),EEonUcx4IuKW5vMOHwyf3R=nUaVQsoA6EXcK4Odht5wCge0J8Pib,kMDj8KIWFwJlu4Q3HcLbqfaRrp=nUaVQsoA6EXcK4Odht5wCge0J8Pib):
	if not direction: direction = Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ଍")
	TmjiG3ND6eQ = cNbV38o7ADCgnh(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ଎"),rq4Bz50iokn,hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫଏ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࠼࠸࠰ࡱࠩଐ"))
	TmjiG3ND6eQ.RgH7UpSCIjTAE206bGWa4BXLh(button0,button1,button2,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,profile,direction,EEonUcx4IuKW5vMOHwyf3R,kMDj8KIWFwJlu4Q3HcLbqfaRrp)
	if EEonUcx4IuKW5vMOHwyf3R>nUaVQsoA6EXcK4Odht5wCge0J8Pib: TmjiG3ND6eQ.fpniqut0CxJk84PDjQrzZlI()
	if kMDj8KIWFwJlu4Q3HcLbqfaRrp>nUaVQsoA6EXcK4Odht5wCge0J8Pib: TmjiG3ND6eQ.a6aIbAdszG()
	if EEonUcx4IuKW5vMOHwyf3R==nUaVQsoA6EXcK4Odht5wCge0J8Pib and kMDj8KIWFwJlu4Q3HcLbqfaRrp==nUaVQsoA6EXcK4Odht5wCge0J8Pib: TmjiG3ND6eQ.tQ0B4hrc1m()
	TmjiG3ND6eQ.doModal()
	RsKir4SuAxkEY = TmjiG3ND6eQ.choiceID
	return RsKir4SuAxkEY
def RsYWOkAC8t4iMUoBd0K(direction,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,profile=KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭଑")):
	if not direction: direction = pbmKZA1w7L4zHjOM(u"࠭࡬ࡦࡨࡷࠫ଒")
	TmjiG3ND6eQ = CGM5VAJ1B0meTIyjiwpSrb3P9(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡔࡦࡺࡷ࡚࡮࡫ࡷࡦࡴࡉࡹࡱࡲࡓࡤࡴࡨࡩࡳ࠴ࡸ࡮࡮ࠪଓ"),rq4Bz50iokn,pL73X0MYajJQG4n1qgD(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩଔ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩ࠺࠶࠵ࡶࠧକ"))
	image_filename = KK4Fa7Sj0L3CywRgQxZk.replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪଖ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡤ࠭ଗ")+str(f7epsRlYtMz4.time())+zWBnYSGIatjXVC(u"ࠬࡥࠧଘ"))
	image_filename = image_filename.replace(zWBnYSGIatjXVC(u"࠭࡜࡝ࠩଙ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࡝࡞࡟ࡠࠬଚ")).replace(hWRvZOYtjme9QNnV41u0Mswb(u"ࠨ࠱࠲ࠫଛ"),zWBnYSGIatjXVC(u"ࠩ࠲࠳࠴࠵ࠧଜ"))
	image_height = jxPI6iZF4rwObyT8V17ptSakEG3(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rrcSWI6RPp5yB3ZVha9NYxKnDu,W0d8hJxSvNlqokHnugMU,profile,direction,pLwgjkuTs6CS,image_filename)
	TmjiG3ND6eQ.show()
	TmjiG3ND6eQ.getControl(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠼࠴࠺࠶ர")).setHeight(image_height)
	TmjiG3ND6eQ.getControl(f9fOpCmLAEaW2Go(u"࠽࠵࠻࠰ற")).setImage(image_filename)
	SSImYZHeRELAwbQcsyXNxTVB = TmjiG3ND6eQ.doModal()
	try: oNlez5gnM9x2B4.remove(image_filename)
	except: pass
	return SSImYZHeRELAwbQcsyXNxTVB
def jxPI6iZF4rwObyT8V17ptSakEG3(mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,yZcVk5mFe4w9p6,RRkCOJ5cxNa9tpboEm7V,QXZjnPmpKNYr,ggM5TzCxq24sDYLiEatpdSK7FQyGe,EEPtQZFbjN2kunlUHzroRBvSma,kkaz3iE6SdRIcunlHo9TrY5FBxVZ,SSWQ9gcbqyTNI58dFHvJVa24fKAkx,nlWuci0J9kh6eM8r1vUTKfHQy):
	vh163m8ACJrSdZxW9zM7sp = oNlez5gnM9x2B4.path.dirname(nlWuci0J9kh6eM8r1vUTKfHQy)
	if not oNlez5gnM9x2B4.path.exists(vh163m8ACJrSdZxW9zM7sp):
		try: oNlez5gnM9x2B4.makedirs(vh163m8ACJrSdZxW9zM7sp)
		except: pass
	qDt2pKTPSfuoJZNRm = w98ORKd2YN0jrmPxuECXVFg4y(EEPtQZFbjN2kunlUHzroRBvSma)
	ZaxKcAp4wFP1G0QvyTrCu = TTJfuigOKqsYWpFQ1RncD5N(qDt2pKTPSfuoJZNRm,mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,yZcVk5mFe4w9p6,RRkCOJ5cxNa9tpboEm7V,QXZjnPmpKNYr,ggM5TzCxq24sDYLiEatpdSK7FQyGe,EEPtQZFbjN2kunlUHzroRBvSma,kkaz3iE6SdRIcunlHo9TrY5FBxVZ,SSWQ9gcbqyTNI58dFHvJVa24fKAkx,nlWuci0J9kh6eM8r1vUTKfHQy)
	return ZaxKcAp4wFP1G0QvyTrCu
def w98ORKd2YN0jrmPxuECXVFg4y(EEPtQZFbjN2kunlUHzroRBvSma):
	rynFzTl246hOemLH8 = Hip2swoNbVaZ30OrStQR1lF
	ZZ1DPFRg4HuW = pL73X0MYajJQG4n1qgD(u"࠷࠶ல")
	LGpm6vwfrW5n = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠸࠰ள")
	wwlRB50jriEu8PMgzJOYhX = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	ECshV1zBRZPMkm = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡧࡪࡴࡴࡦࡴࠪଝ")
	vGBw7hF4KWYbrMmRAlU3n = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	g9UczwvjaZt2e8FdBi6V5sYOP = B1YMtuvRAGNlJOkC46VyPKQE(u"࠱࠺ழ")
	w2FWXhTZ0vfx7yt9RMKH = YzlId3Fs6vpehcbLGj0UaO(u"࠴࠲வ")
	ebfU6nI5DsgOCx = pYeVwat64v(u"࠺ஶ")
	Klbk1rNB0463HQy = NFGqKBLtvUZn1S3dau
	R6xo09vj3B2rLAksheEwiSKNGc = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠶࠻࠺ஷ")
	W0WTbXa5c3MxdHwvOEJq = pbmKZA1w7L4zHjOM(u"࠸࠶࠶ஸ")
	reVXZBdyc96FMpkm0JQ5sqOE4jAtHT = w9wfONXUP3(u"࠺࠶ஹ")
	LOenDCfYo0pSV9MGdPIWr34qwb7X = CCWqR3dmtzw6xoIX41(u"࠸࠸࠱஺")
	LoVnsBlvcOfFQXS3m6gbirWqD2MAe4 = KKCrwPdOgGl(u"࠲࠹஻")
	aVAiCekX4ES7q9lgIQcmO3KwoZ21 = Hip2swoNbVaZ30OrStQR1lF
	Hypqsmd6XUlxLP = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	ECgBNu1Uzrw9lpbc4e = pL73X0MYajJQG4n1qgD(u"࠴࠳஼")
	F0xs3wdRcLY2EOhkq96mg = [B1YMtuvRAGNlJOkC46VyPKQE(u"࠷࠻ி"),GTmHXIZUSdxRhMnqQKkO(u"࠵࠵஽"),CCWqR3dmtzw6xoIX41(u"࠵࠼ா")]
	from PIL import ImageDraw as AC7OWegnufd413MjYt8hkL,ImageFont as OCdumUP5SeA6yIqcDi17GHxrhEKs,Image as Kk1UQdDeWyGE7qnCXf8Y45Ji36V2g
	if lRKCWnNi0Edr984eI(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪଞ") in EEPtQZFbjN2kunlUHzroRBvSma:
		if EEPtQZFbjN2kunlUHzroRBvSma==kAz7WRYjrfGm(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡷ࡫ࡧࡶ࡮ࡤࡶࠬଟ"):
			GHE7yAabgTPFKLiBd = lRKCWnNi0Edr984eI(u"࠶࠷࠷ீ")
			ECshV1zBRZPMkm = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭࡬ࡦࡨࡷࠫଠ")
			Klbk1rNB0463HQy = pLwgjkuTs6CS
		elif EEPtQZFbjN2kunlUHzroRBvSma==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡡࡶࡶࡲࠫଡ"):
			GHE7yAabgTPFKLiBd = f9fOpCmLAEaW2Go(u"ࠨࡗࡓࡔࡊࡘࠧଢ")
			ECshV1zBRZPMkm = hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡵ࡭࡬࡮ࡴࠨଣ")
			wwlRB50jriEu8PMgzJOYhX = hWRvZOYtjme9QNnV41u0Mswb(u"࠷࠰ு")
		VLaWexEYOg = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠷࠳࠲ூ")
		F0xs3wdRcLY2EOhkq96mg = [rAYDiWlzm9MCU6x0GnROua(u"࠴࠵௃"),rAYDiWlzm9MCU6x0GnROua(u"࠴࠵௃"),rAYDiWlzm9MCU6x0GnROua(u"࠴࠵௃")]
		LGpm6vwfrW5n = pbmKZA1w7L4zHjOM(u"࠴࠳௄")
		ZZ1DPFRg4HuW = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		w2FWXhTZ0vfx7yt9RMKH = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠵࠴௅")
		g9UczwvjaZt2e8FdBi6V5sYOP = f9fOpCmLAEaW2Go(u"࠷࠺ெ")
	elif EEPtQZFbjN2kunlUHzroRBvSma==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭ତ"):
		F0xs3wdRcLY2EOhkq96mg,VLaWexEYOg,GHE7yAabgTPFKLiBd = [w9wfONXUP3(u"࠲࠹௉"),w9wfONXUP3(u"࠲࠹௉"),w9wfONXUP3(u"࠲࠹௉")],Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠷࠶࠰ே"),GTmHXIZUSdxRhMnqQKkO(u"࠸࠵࠱ை")
		vGBw7hF4KWYbrMmRAlU3n,w2FWXhTZ0vfx7yt9RMKH,g9UczwvjaZt2e8FdBi6V5sYOP, = nUaVQsoA6EXcK4Odht5wCge0J8Pib,-MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠲࠴ொ"),-kAz7WRYjrfGm(u"࠵࠳ோ")
		ZZ1DPFRg4HuW = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		dC3pbTFzR1rutOc5EG4YekUgLQBJ = Kk1UQdDeWyGE7qnCXf8Y45Ji36V2g.open(YWHsNXrFZpPBOf37IgQtKhTc5ivR4j)
		qHixdKb7mLU3Js8t1egz6nc = Kk1UQdDeWyGE7qnCXf8Y45Ji36V2g.new(ba49YvOK2Aw8Uhxt(u"ࠫࡗࡍࡂࡂࠩଥ"),(VLaWexEYOg,GHE7yAabgTPFKLiBd),(YzlId3Fs6vpehcbLGj0UaO(u"࠵࠹࠺ௌ"),nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib,YzlId3Fs6vpehcbLGj0UaO(u"࠵࠹࠺ௌ")))
	elif EEPtQZFbjN2kunlUHzroRBvSma==zWBnYSGIatjXVC(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩଦ"): F0xs3wdRcLY2EOhkq96mg,GHE7yAabgTPFKLiBd,VLaWexEYOg = [B1YMtuvRAGNlJOkC46VyPKQE(u"࠲࠹ௐ"),ba49YvOK2Aw8Uhxt(u"࠶࠹்"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠷࠶௎")],lRKCWnNi0Edr984eI(u"࠶࠲࠳௑"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠿࠰࠱௏")
	elif EEPtQZFbjN2kunlUHzroRBvSma==GTmHXIZUSdxRhMnqQKkO(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫଧ"): F0xs3wdRcLY2EOhkq96mg,GHE7yAabgTPFKLiBd,VLaWexEYOg = [bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶࠶௓"),kAz7WRYjrfGm(u"࠷࠾௕"),pYeVwat64v(u"࠴࠷௒")],YzlId3Fs6vpehcbLGj0UaO(u"࠻࠰࠱௖"),GTmHXIZUSdxRhMnqQKkO(u"࠽࠵࠶௔")
	elif EEPtQZFbjN2kunlUHzroRBvSma==f9fOpCmLAEaW2Go(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩନ"): F0xs3wdRcLY2EOhkq96mg,GHE7yAabgTPFKLiBd,VLaWexEYOg = [JZ45mOctiTszPNw1GVjxhep2Y(u"࠶࠺௚"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠳࠳ௗ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠴࠻௙")],GTmHXIZUSdxRhMnqQKkO(u"࠹࠵࠶௛"),pL73X0MYajJQG4n1qgD(u"࠺࠲࠳௘")
	elif EEPtQZFbjN2kunlUHzroRBvSma==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ଩"): GHE7yAabgTPFKLiBd,VLaWexEYOg = JZ45mOctiTszPNw1GVjxhep2Y(u"࠼࠺࠰௜"),I6Bfzysrvb8DONZ(u"࠷࠲࠸࠲௝")
	elif EEPtQZFbjN2kunlUHzroRBvSma==YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪପ"): GHE7yAabgTPFKLiBd,VLaWexEYOg = CCWqR3dmtzw6xoIX41(u"࡙ࠪࡕࡖࡅࡓࠩଫ"),I6Bfzysrvb8DONZ(u"࠱࠳࠹࠳௞")
	elif EEPtQZFbjN2kunlUHzroRBvSma==Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩବ"): F0xs3wdRcLY2EOhkq96mg,GHE7yAabgTPFKLiBd,VLaWexEYOg = [I6Bfzysrvb8DONZ(u"࠶࠽௢"),KKCrwPdOgGl(u"࠷࠹௣"),nR0ok9zju84rFUQl1YC(u"࠳࠻௠")],djapWhrveLJbgnViDftFNY05ylq1S(u"࠸࠶࠳௟"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠴࠶࠼࠶௡")
	elif EEPtQZFbjN2kunlUHzroRBvSma==B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨଭ"): F0xs3wdRcLY2EOhkq96mg,GHE7yAabgTPFKLiBd,VLaWexEYOg = [pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠳࠺௦"),YzlId3Fs6vpehcbLGj0UaO(u"࠴࠶௧"),w9wfONXUP3(u"࠱࠹௥")],pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡕࡑࡒࡈࡖࠬମ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠷࠲࠸࠲௤")
	vvHp9yOlxXA,i2HsQCyXAh,eIpY9U0aToyQg8SvDw3 = F0xs3wdRcLY2EOhkq96mg
	MuQljzvi6sH = OCdumUP5SeA6yIqcDi17GHxrhEKs.truetype(MMUsJDCWFAe,size=vvHp9yOlxXA)
	O6OJwXTKEhL = OCdumUP5SeA6yIqcDi17GHxrhEKs.truetype(MMUsJDCWFAe,size=i2HsQCyXAh)
	TxcUMQ3dvbCXE8pPLZ = OCdumUP5SeA6yIqcDi17GHxrhEKs.truetype(MMUsJDCWFAe,size=eIpY9U0aToyQg8SvDw3)
	yyeVu0hxbjt = VLaWexEYOg-w2FWXhTZ0vfx7yt9RMKH*H3OKMjDG1evnl4Ruiz
	NeQadcI5uUnKJj91 = Kk1UQdDeWyGE7qnCXf8Y45Ji36V2g.new(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡓࡉࡅࡅࠬଯ"),(yyeVu0hxbjt,w9wfONXUP3(u"࠴࠴࠵௨")),(f9fOpCmLAEaW2Go(u"࠶࠺࠻௩"),f9fOpCmLAEaW2Go(u"࠶࠺࠻௩"),f9fOpCmLAEaW2Go(u"࠶࠺࠻௩"),nUaVQsoA6EXcK4Odht5wCge0J8Pib))
	RZoi7rUxnp = AC7OWegnufd413MjYt8hkL.Draw(NeQadcI5uUnKJj91)
	yTpM2jheqN09IBd6rPFumw,Zo2zKjNdVDhWgMX4i7GH8cpYSsbtn = RZoi7rUxnp.textsize(CCWqR3dmtzw6xoIX41(u"ࠨࡊࡋࡌࠥࡈࡂࡃࠢ࠻࠼࠽ࠦ࠰࠱࠲ࠪର"),font=MuQljzvi6sH)
	wC9jPJgWsU0zE2XFHQh,mJX8dtzDa2oPfyEQurYAVckBC9v5e = RZoi7rUxnp.textsize(ba49YvOK2Aw8Uhxt(u"ࠩࡋࡌࡍࠦࡂࡃࡄࠣ࠼࠽࠾ࠠ࠱࠲࠳ࠫ଱"),font=O6OJwXTKEhL)
	LwmDqZEoT2pi69cOWUIaGCe = {zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡨࡪࡲࡥࡵࡧࡢ࡬ࡦࡸࡡ࡬ࡣࡷࠫଲ"):pLwgjkuTs6CS,Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡸࡻࡰࡱࡱࡵࡸࡤࡲࡩࡨࡣࡷࡹࡷ࡫ࡳࠨଳ"):NFGqKBLtvUZn1S3dau,YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡇࡒࡂࡄࡌࡇࠥࡒࡉࡈࡃࡗ࡙ࡗࡋࠠࡂࡎࡏࡅࡍ࠭଴"):pLwgjkuTs6CS}
	from arabic_reshaper import ArabicReshaper as SgF8X1fauA
	XD2NZiIOwCUalBh9vHLYgyQj57 = SgF8X1fauA(configuration=LwmDqZEoT2pi69cOWUIaGCe)
	qDt2pKTPSfuoJZNRm = {}
	nr8icJas7UHd = locals()
	for xngTvzlop02PjM7ZdA in nr8icJas7UHd: qDt2pKTPSfuoJZNRm[xngTvzlop02PjM7ZdA] = nr8icJas7UHd[xngTvzlop02PjM7ZdA]
	return qDt2pKTPSfuoJZNRm
def TTJfuigOKqsYWpFQ1RncD5N(qDt2pKTPSfuoJZNRm,mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,yZcVk5mFe4w9p6,RRkCOJ5cxNa9tpboEm7V,QXZjnPmpKNYr,ggM5TzCxq24sDYLiEatpdSK7FQyGe,EEPtQZFbjN2kunlUHzroRBvSma,kkaz3iE6SdRIcunlHo9TrY5FBxVZ,SSWQ9gcbqyTNI58dFHvJVa24fKAkx,nlWuci0J9kh6eM8r1vUTKfHQy):
	for xngTvzlop02PjM7ZdA in qDt2pKTPSfuoJZNRm: globals()[xngTvzlop02PjM7ZdA] = qDt2pKTPSfuoJZNRm[xngTvzlop02PjM7ZdA]
	global LoVnsBlvcOfFQXS3m6gbirWqD2MAe4,aVAiCekX4ES7q9lgIQcmO3KwoZ21
	if EEPtQZFbjN2kunlUHzroRBvSma!=djapWhrveLJbgnViDftFNY05ylq1S(u"࠭࡭ࡦࡰࡸࡣ࡮ࡺࡥ࡮ࠩଵ"):
		Fw8JeHMj9fkLrNpzVc3qug1ibaZQ = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨଶ"))
		if Fw8JeHMj9fkLrNpzVc3qug1ibaZQ:
			if mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪଷ"): mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb = YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࡜ࡩࡸ࠭ସ")
			elif mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ็้อࠠࠡࡐࡲࠫହ"): mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡓࡵࠧ଺")
			if yZcVk5mFe4w9p6==pYeVwat64v(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ଻"): yZcVk5mFe4w9p6 = CCWqR3dmtzw6xoIX41(u"࡙࠭ࡦࡵ଼ࠪ")
			elif yZcVk5mFe4w9p6==lRKCWnNi0Edr984eI(u"ࠧไๆสࠤࠥࡔ࡯ࠨଽ"): yZcVk5mFe4w9p6 = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡐࡲࠫା")
			if RRkCOJ5cxNa9tpboEm7V==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫି"): RRkCOJ5cxNa9tpboEm7V = zWBnYSGIatjXVC(u"ࠪ࡝ࡪࡹࠧୀ")
			elif RRkCOJ5cxNa9tpboEm7V==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"่๊ࠫวࠡࠢࡑࡳࠬୁ"): RRkCOJ5cxNa9tpboEm7V = ba49YvOK2Aw8Uhxt(u"ࠬࡔ࡯ࠨୂ")
			import OQ27yuoU3i
			lwfKMcpWgebLrA5sSa68 = OQ27yuoU3i.YfqbuvwVI6tC([mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,yZcVk5mFe4w9p6,RRkCOJ5cxNa9tpboEm7V,QXZjnPmpKNYr,ggM5TzCxq24sDYLiEatpdSK7FQyGe])
			if lwfKMcpWgebLrA5sSa68: mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,yZcVk5mFe4w9p6,RRkCOJ5cxNa9tpboEm7V,QXZjnPmpKNYr,ggM5TzCxq24sDYLiEatpdSK7FQyGe = lwfKMcpWgebLrA5sSa68
	if hT1JIgqPQsUOZp5tjCX0E:
		ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.decode(RMGz7OiD1e30P)
		QXZjnPmpKNYr = QXZjnPmpKNYr.decode(RMGz7OiD1e30P)
		mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb = mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb.decode(RMGz7OiD1e30P)
		yZcVk5mFe4w9p6 = yZcVk5mFe4w9p6.decode(RMGz7OiD1e30P)
		RRkCOJ5cxNa9tpboEm7V = RRkCOJ5cxNa9tpboEm7V.decode(RMGz7OiD1e30P)
	EFQsG0Kg9frP8YpRW1T = QXZjnPmpKNYr.count(b8sk5WyPoz03pXhRx)+xD9WeoEAsX7
	V54GQH0ISwrhU = ZZ1DPFRg4HuW+EFQsG0Kg9frP8YpRW1T*(Zo2zKjNdVDhWgMX4i7GH8cpYSsbtn+wwlRB50jriEu8PMgzJOYhX)-wwlRB50jriEu8PMgzJOYhX
	if ggM5TzCxq24sDYLiEatpdSK7FQyGe:
		pPX1LJdTyQM4CDZE6e0OVcWtUvArG = mJX8dtzDa2oPfyEQurYAVckBC9v5e+ebfU6nI5DsgOCx
		caRzOZA1ve9o428jwJLt = XD2NZiIOwCUalBh9vHLYgyQj57.reshape(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
		if Klbk1rNB0463HQy:
			LLHk9BseQGdICR1 = cUPjCuyw09ZfpK2Xkl8z5q1(RZoi7rUxnp,O6OJwXTKEhL,caRzOZA1ve9o428jwJLt,i2HsQCyXAh,yyeVu0hxbjt,pPX1LJdTyQM4CDZE6e0OVcWtUvArG)
			HW4uTxMfSwej8O65dFchBnCEqK = BMWpOhtDdCKN1(LLHk9BseQGdICR1)
			fP9DOSCxFQAUsXI = HW4uTxMfSwej8O65dFchBnCEqK.count(b8sk5WyPoz03pXhRx)+xD9WeoEAsX7
			Dhx6s9jBAZ53MX2oPd4ei0 = g9UczwvjaZt2e8FdBi6V5sYOP+fP9DOSCxFQAUsXI*pPX1LJdTyQM4CDZE6e0OVcWtUvArG-ebfU6nI5DsgOCx
		else:
			Dhx6s9jBAZ53MX2oPd4ei0 = g9UczwvjaZt2e8FdBi6V5sYOP+mJX8dtzDa2oPfyEQurYAVckBC9v5e
			HW4uTxMfSwej8O65dFchBnCEqK = caRzOZA1ve9o428jwJLt.split(b8sk5WyPoz03pXhRx)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			LLHk9BseQGdICR1 = caRzOZA1ve9o428jwJLt.split(b8sk5WyPoz03pXhRx)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	else: Dhx6s9jBAZ53MX2oPd4ei0 = g9UczwvjaZt2e8FdBi6V5sYOP
	vdzNmVkqp39rTXRgCAxDSa = Hypqsmd6XUlxLP+ECgBNu1Uzrw9lpbc4e
	if SSWQ9gcbqyTNI58dFHvJVa24fKAkx:
		D9jCRSgXNPnpI = W0WTbXa5c3MxdHwvOEJq-R6xo09vj3B2rLAksheEwiSKNGc
		vdzNmVkqp39rTXRgCAxDSa += D9jCRSgXNPnpI
	else: D9jCRSgXNPnpI = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	if mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb or yZcVk5mFe4w9p6 or RRkCOJ5cxNa9tpboEm7V: vdzNmVkqp39rTXRgCAxDSa += reVXZBdyc96FMpkm0JQ5sqOE4jAtHT
	ZaxKcAp4wFP1G0QvyTrCu = GHE7yAabgTPFKLiBd if GHE7yAabgTPFKLiBd!=pbmKZA1w7L4zHjOM(u"࠭ࡕࡑࡒࡈࡖࠬୃ") else V54GQH0ISwrhU+Dhx6s9jBAZ53MX2oPd4ei0+vdzNmVkqp39rTXRgCAxDSa
	NeQadcI5uUnKJj91 = Kk1UQdDeWyGE7qnCXf8Y45Ji36V2g.new(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡓࡉࡅࡅࠬୄ"),(VLaWexEYOg,ZaxKcAp4wFP1G0QvyTrCu),(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠷࠻࠵௪"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠷࠻࠵௪"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠷࠻࠵௪"),nUaVQsoA6EXcK4Odht5wCge0J8Pib))
	mJMks46jT9QHzox3t0ncGK2yWvSRe = AC7OWegnufd413MjYt8hkL.Draw(NeQadcI5uUnKJj91)
	Z0kcPvjM5HsWh = ZaxKcAp4wFP1G0QvyTrCu-V54GQH0ISwrhU-vdzNmVkqp39rTXRgCAxDSa-g9UczwvjaZt2e8FdBi6V5sYOP
	if not yZcVk5mFe4w9p6 and mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb and RRkCOJ5cxNa9tpboEm7V:
		LoVnsBlvcOfFQXS3m6gbirWqD2MAe4 += hWRvZOYtjme9QNnV41u0Mswb(u"࠷࠰࠶௫")
		aVAiCekX4ES7q9lgIQcmO3KwoZ21 -= Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠱࠲࠲௬")
	import bidi.algorithm as TwdBkcp9R8ilKZLJm36Sy0UQ7AEG
	if QXZjnPmpKNYr:
		Y1XnPAk4SNJKm0swGlqgtjfHb = ZZ1DPFRg4HuW
		QXZjnPmpKNYr = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(XD2NZiIOwCUalBh9vHLYgyQj57.reshape(QXZjnPmpKNYr))
		LJpgrc4nMwCGiaVq2Zo0dyARBDf = QXZjnPmpKNYr.splitlines()
		for q8qv3XSGmsDjJZeMRxYafhnQ in LJpgrc4nMwCGiaVq2Zo0dyARBDf:
			if q8qv3XSGmsDjJZeMRxYafhnQ:
				GGQEFRb82AmxBs5Z3HS,EovIkXwnZt53rqe0A = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(q8qv3XSGmsDjJZeMRxYafhnQ,font=MuQljzvi6sH)
				if ECshV1zBRZPMkm==jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ୅"): UUJVr9DRTW = rynFzTl246hOemLH8+(VLaWexEYOg-GGQEFRb82AmxBs5Z3HS)/H3OKMjDG1evnl4Ruiz
				elif ECshV1zBRZPMkm==jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡵ࡭࡬࡮ࡴࠨ୆"): UUJVr9DRTW = rynFzTl246hOemLH8+VLaWexEYOg-GGQEFRb82AmxBs5Z3HS-LGpm6vwfrW5n
				elif ECshV1zBRZPMkm==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡰࡪ࡬ࡴࠨେ"): UUJVr9DRTW = rynFzTl246hOemLH8+LGpm6vwfrW5n
				mJMks46jT9QHzox3t0ncGK2yWvSRe.text((UUJVr9DRTW,Y1XnPAk4SNJKm0swGlqgtjfHb),q8qv3XSGmsDjJZeMRxYafhnQ,font=MuQljzvi6sH,fill=w9wfONXUP3(u"ࠫࡾ࡫࡬࡭ࡱࡺࠫୈ"))
			Y1XnPAk4SNJKm0swGlqgtjfHb += vvHp9yOlxXA+wwlRB50jriEu8PMgzJOYhX
	if mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb or yZcVk5mFe4w9p6 or RRkCOJ5cxNa9tpboEm7V:
		IK1H5fjhLYTkexa = V54GQH0ISwrhU+Z0kcPvjM5HsWh+g9UczwvjaZt2e8FdBi6V5sYOP+D9jCRSgXNPnpI+Hypqsmd6XUlxLP
		if mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb:
			mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(XD2NZiIOwCUalBh9vHLYgyQj57.reshape(mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb))
			kXaUwlFhevQ6yB,YfSTxd2cJZglDCyRmvA6u = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,font=TxcUMQ3dvbCXE8pPLZ)
			haFmNOH64pfoBCu7rlKDMRVJL = LoVnsBlvcOfFQXS3m6gbirWqD2MAe4+nUaVQsoA6EXcK4Odht5wCge0J8Pib*(aVAiCekX4ES7q9lgIQcmO3KwoZ21+LOenDCfYo0pSV9MGdPIWr34qwb7X)+(LOenDCfYo0pSV9MGdPIWr34qwb7X-kXaUwlFhevQ6yB)/H3OKMjDG1evnl4Ruiz
			mJMks46jT9QHzox3t0ncGK2yWvSRe.text((haFmNOH64pfoBCu7rlKDMRVJL,IK1H5fjhLYTkexa),mPdaXE2VAlgDHiU7Ic15R9CTNjsQzb,font=TxcUMQ3dvbCXE8pPLZ,fill=KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ୉"))
		if yZcVk5mFe4w9p6:
			yZcVk5mFe4w9p6 = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(XD2NZiIOwCUalBh9vHLYgyQj57.reshape(yZcVk5mFe4w9p6))
			SZo6rjWI5Yf8XlkU9cDO,rXPOvx3yz4h9CoFnH6qBc = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(yZcVk5mFe4w9p6,font=TxcUMQ3dvbCXE8pPLZ)
			Comnb5BXFADP3 = LoVnsBlvcOfFQXS3m6gbirWqD2MAe4+xD9WeoEAsX7*(aVAiCekX4ES7q9lgIQcmO3KwoZ21+LOenDCfYo0pSV9MGdPIWr34qwb7X)+(LOenDCfYo0pSV9MGdPIWr34qwb7X-SZo6rjWI5Yf8XlkU9cDO)/H3OKMjDG1evnl4Ruiz
			mJMks46jT9QHzox3t0ncGK2yWvSRe.text((Comnb5BXFADP3,IK1H5fjhLYTkexa),yZcVk5mFe4w9p6,font=TxcUMQ3dvbCXE8pPLZ,fill=zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭୊"))
		if RRkCOJ5cxNa9tpboEm7V:
			RRkCOJ5cxNa9tpboEm7V = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(XD2NZiIOwCUalBh9vHLYgyQj57.reshape(RRkCOJ5cxNa9tpboEm7V))
			P0NjowyODdAkbmpBIt435nu6S1M,s4si5Io896FCLgASBUOukxf2Mlzy = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(RRkCOJ5cxNa9tpboEm7V,font=TxcUMQ3dvbCXE8pPLZ)
			OU5xpdEuTb2GtNlPHvAaF7jqgV = LoVnsBlvcOfFQXS3m6gbirWqD2MAe4+H3OKMjDG1evnl4Ruiz*(aVAiCekX4ES7q9lgIQcmO3KwoZ21+LOenDCfYo0pSV9MGdPIWr34qwb7X)+(LOenDCfYo0pSV9MGdPIWr34qwb7X-P0NjowyODdAkbmpBIt435nu6S1M)/H3OKMjDG1evnl4Ruiz
			mJMks46jT9QHzox3t0ncGK2yWvSRe.text((OU5xpdEuTb2GtNlPHvAaF7jqgV,IK1H5fjhLYTkexa),RRkCOJ5cxNa9tpboEm7V,font=TxcUMQ3dvbCXE8pPLZ,fill=MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧୋ"))
	if ggM5TzCxq24sDYLiEatpdSK7FQyGe:
		SoC6LnJN38qKHBaUM,R2EUWkKyepBf8rhqPJSwQ6HOv9N = [],[]
		LLHk9BseQGdICR1 = SSxKWgzNnUyhfdY(LLHk9BseQGdICR1)
		E32qNgc56CV0UXa = LLHk9BseQGdICR1.split(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩୌ"))
		for Qz7rDSVoI6RCpvJfGXyW2eYqm in E32qNgc56CV0UXa:
			vnB2EzyDtRgQVYLPqO0bTc = kkaz3iE6SdRIcunlHo9TrY5FBxVZ
			if   GTmHXIZUSdxRhMnqQKkO(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢ୍ࠫ") in Qz7rDSVoI6RCpvJfGXyW2eYqm: vnB2EzyDtRgQVYLPqO0bTc = hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡰࡪ࡬ࡴࠨ୎")
			elif YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ୏") in Qz7rDSVoI6RCpvJfGXyW2eYqm: vnB2EzyDtRgQVYLPqO0bTc = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡸࡩࡨࡪࡷࠫ୐")
			elif GTmHXIZUSdxRhMnqQKkO(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ୑") in Qz7rDSVoI6RCpvJfGXyW2eYqm: vnB2EzyDtRgQVYLPqO0bTc = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡤࡧࡱࡸࡪࡸࠧ୒")
			XOnNPabiHA39fwhVY7g = Qz7rDSVoI6RCpvJfGXyW2eYqm
			AAN2oEubYBDW1kyzd6Q5CTjs7Otrl = AxTYMhRlfyskNc0X19dvwtS.findall(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡡࡶࡷࡸࡥ࡟࠯ࠬࡂࡣࠬ୓"),Qz7rDSVoI6RCpvJfGXyW2eYqm,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for YL0ZQISt18vcXKm43ABDafw in AAN2oEubYBDW1kyzd6Q5CTjs7Otrl: XOnNPabiHA39fwhVY7g = XOnNPabiHA39fwhVY7g.replace(YL0ZQISt18vcXKm43ABDafw,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if XOnNPabiHA39fwhVY7g==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GGQEFRb82AmxBs5Z3HS,EovIkXwnZt53rqe0A = nUaVQsoA6EXcK4Odht5wCge0J8Pib,pPX1LJdTyQM4CDZE6e0OVcWtUvArG
			else: GGQEFRb82AmxBs5Z3HS,EovIkXwnZt53rqe0A = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(XOnNPabiHA39fwhVY7g,font=O6OJwXTKEhL)
			if   vnB2EzyDtRgQVYLPqO0bTc==W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡯ࡩ࡫ࡺࠧ୔"): sW6iovu2fmJMGLF9UlQc3 = vGBw7hF4KWYbrMmRAlU3n+w2FWXhTZ0vfx7yt9RMKH
			elif vnB2EzyDtRgQVYLPqO0bTc==f9fOpCmLAEaW2Go(u"ࠪࡶ࡮࡭ࡨࡵࠩ୕"): sW6iovu2fmJMGLF9UlQc3 = vGBw7hF4KWYbrMmRAlU3n+w2FWXhTZ0vfx7yt9RMKH+yyeVu0hxbjt-GGQEFRb82AmxBs5Z3HS
			elif vnB2EzyDtRgQVYLPqO0bTc==I6Bfzysrvb8DONZ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫୖ"): sW6iovu2fmJMGLF9UlQc3 = vGBw7hF4KWYbrMmRAlU3n+w2FWXhTZ0vfx7yt9RMKH+(yyeVu0hxbjt-GGQEFRb82AmxBs5Z3HS)/H3OKMjDG1evnl4Ruiz
			if sW6iovu2fmJMGLF9UlQc3<w2FWXhTZ0vfx7yt9RMKH: sW6iovu2fmJMGLF9UlQc3 = vGBw7hF4KWYbrMmRAlU3n+w2FWXhTZ0vfx7yt9RMKH
			SoC6LnJN38qKHBaUM.append(sW6iovu2fmJMGLF9UlQc3)
			R2EUWkKyepBf8rhqPJSwQ6HOv9N.append(GGQEFRb82AmxBs5Z3HS)
		sW6iovu2fmJMGLF9UlQc3 = SoC6LnJN38qKHBaUM[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		vanWsJZlAFCDG0YxjKHEOb7wLyo1i = LLHk9BseQGdICR1.split(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡥࡳࡴࡵࡢࠫୗ"))
		YvWny3gSjJH2 = (jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠷࠸௭"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠷࠸௭"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠷࠸௭"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠷࠸௭"))
		UY8dwfGN7QrRp3LPyg4Ej = YvWny3gSjJH2
		SP6oaF4BOxRhXAvgDNtbH0,ElMf6uH3KBqrp8U = nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib
		nnRCqcFyxUePD50TMXA = pLwgjkuTs6CS
		QQM1PugGzN6m = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		ssaSZRKPngqv9lwyCi5h3YuecUmW8N = V54GQH0ISwrhU+g9UczwvjaZt2e8FdBi6V5sYOP/H3OKMjDG1evnl4Ruiz
		if Dhx6s9jBAZ53MX2oPd4ei0<(Z0kcPvjM5HsWh+g9UczwvjaZt2e8FdBi6V5sYOP):
			llJKyWcQZXVn5tm8HA26DeG4C = (Z0kcPvjM5HsWh+g9UczwvjaZt2e8FdBi6V5sYOP-Dhx6s9jBAZ53MX2oPd4ei0)/H3OKMjDG1evnl4Ruiz
			ssaSZRKPngqv9lwyCi5h3YuecUmW8N = V54GQH0ISwrhU+g9UczwvjaZt2e8FdBi6V5sYOP+llJKyWcQZXVn5tm8HA26DeG4C-mJX8dtzDa2oPfyEQurYAVckBC9v5e/H3OKMjDG1evnl4Ruiz
		for q8qv3XSGmsDjJZeMRxYafhnQ in vanWsJZlAFCDG0YxjKHEOb7wLyo1i:
			if not q8qv3XSGmsDjJZeMRxYafhnQ or (q8qv3XSGmsDjJZeMRxYafhnQ and ord(q8qv3XSGmsDjJZeMRxYafhnQ[nUaVQsoA6EXcK4Odht5wCge0J8Pib])==vl6rwMLasAQo4z1ZjD3IBKtF(u"࠸࠸࠶࠼࠿௮")): continue
			eR8D3uLHm5rhVCawpBN = q8qv3XSGmsDjJZeMRxYafhnQ.split(I6Bfzysrvb8DONZ(u"࠭࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ୘"),xD9WeoEAsX7)
			yyHcku5UxPKM1w9WtpzTZliCFYS3J = q8qv3XSGmsDjJZeMRxYafhnQ.split(lRKCWnNi0Edr984eI(u"ࠧࡠࡰࡨࡻࡨࡵ࡬ࡰࡴࠪ୙"),xD9WeoEAsX7)
			sYFLTuoZ2C0Uc5eOli = q8qv3XSGmsDjJZeMRxYafhnQ.split(Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡡࡨࡲࡩࡩ࡯࡭ࡱࡵࡣࠬ୚"),xD9WeoEAsX7)
			bnBtZ0rvzWDNkCgLh7JPV53 = q8qv3XSGmsDjJZeMRxYafhnQ.split(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡢࡰ࡮ࡴࡥࡳࡶ࡯ࡣࠬ୛"),xD9WeoEAsX7)
			siCpvuOwGbeYPZMcnKk = q8qv3XSGmsDjJZeMRxYafhnQ.split(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧଡ଼"),xD9WeoEAsX7)
			RO9ZPrCIz1e = q8qv3XSGmsDjJZeMRxYafhnQ.split(KKCrwPdOgGl(u"ࠫࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩଢ଼"),xD9WeoEAsX7)
			ZdUt8cyAqipPXBSIw = q8qv3XSGmsDjJZeMRxYafhnQ.split(CCWqR3dmtzw6xoIX41(u"ࠬࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ୞"),xD9WeoEAsX7)
			if len(eR8D3uLHm5rhVCawpBN)>xD9WeoEAsX7:
				QQM1PugGzN6m += xD9WeoEAsX7
				q8qv3XSGmsDjJZeMRxYafhnQ = eR8D3uLHm5rhVCawpBN[xD9WeoEAsX7]
				SP6oaF4BOxRhXAvgDNtbH0 = nUaVQsoA6EXcK4Odht5wCge0J8Pib
				sW6iovu2fmJMGLF9UlQc3 = SoC6LnJN38qKHBaUM[QQM1PugGzN6m]
				ElMf6uH3KBqrp8U += pPX1LJdTyQM4CDZE6e0OVcWtUvArG
				nnRCqcFyxUePD50TMXA = pLwgjkuTs6CS
			elif len(yyHcku5UxPKM1w9WtpzTZliCFYS3J)>xD9WeoEAsX7:
				q8qv3XSGmsDjJZeMRxYafhnQ = yyHcku5UxPKM1w9WtpzTZliCFYS3J[xD9WeoEAsX7]
				UY8dwfGN7QrRp3LPyg4Ej = q8qv3XSGmsDjJZeMRxYafhnQ[nUaVQsoA6EXcK4Odht5wCge0J8Pib:slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠻௯")]
				UY8dwfGN7QrRp3LPyg4Ej = nR0ok9zju84rFUQl1YC(u"࠭ࠣࠨୟ")+UY8dwfGN7QrRp3LPyg4Ej[H3OKMjDG1evnl4Ruiz:]
				q8qv3XSGmsDjJZeMRxYafhnQ = q8qv3XSGmsDjJZeMRxYafhnQ[awSUTRNMkdIW7sFEvnHD2mLY(u"࠽௰"):]
			elif len(sYFLTuoZ2C0Uc5eOli)>xD9WeoEAsX7:
				q8qv3XSGmsDjJZeMRxYafhnQ = sYFLTuoZ2C0Uc5eOli[xD9WeoEAsX7]
				UY8dwfGN7QrRp3LPyg4Ej = YvWny3gSjJH2
			elif len(bnBtZ0rvzWDNkCgLh7JPV53)>xD9WeoEAsX7:
				q8qv3XSGmsDjJZeMRxYafhnQ = bnBtZ0rvzWDNkCgLh7JPV53[xD9WeoEAsX7]
				nnRCqcFyxUePD50TMXA = NFGqKBLtvUZn1S3dau
				SP6oaF4BOxRhXAvgDNtbH0 = R2EUWkKyepBf8rhqPJSwQ6HOv9N[QQM1PugGzN6m]
			elif len(siCpvuOwGbeYPZMcnKk)>pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠶௱"): q8qv3XSGmsDjJZeMRxYafhnQ = siCpvuOwGbeYPZMcnKk[xD9WeoEAsX7]
			elif len(RO9ZPrCIz1e)>Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠷௲"): q8qv3XSGmsDjJZeMRxYafhnQ = RO9ZPrCIz1e[xD9WeoEAsX7]
			elif len(ZdUt8cyAqipPXBSIw)>pYeVwat64v(u"࠱௳"): q8qv3XSGmsDjJZeMRxYafhnQ = ZdUt8cyAqipPXBSIw[xD9WeoEAsX7]
			if q8qv3XSGmsDjJZeMRxYafhnQ:
				FcdVMagWhzNt = ssaSZRKPngqv9lwyCi5h3YuecUmW8N+ElMf6uH3KBqrp8U
				q8qv3XSGmsDjJZeMRxYafhnQ = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(q8qv3XSGmsDjJZeMRxYafhnQ)
				GGQEFRb82AmxBs5Z3HS,EovIkXwnZt53rqe0A = mJMks46jT9QHzox3t0ncGK2yWvSRe.textsize(q8qv3XSGmsDjJZeMRxYafhnQ,font=O6OJwXTKEhL)
				if nnRCqcFyxUePD50TMXA: SP6oaF4BOxRhXAvgDNtbH0 -= GGQEFRb82AmxBs5Z3HS
				aWzmHpO6Rn8JbtMi3QTucy14GldwvZ = sW6iovu2fmJMGLF9UlQc3+SP6oaF4BOxRhXAvgDNtbH0
				mJMks46jT9QHzox3t0ncGK2yWvSRe.text((aWzmHpO6Rn8JbtMi3QTucy14GldwvZ,FcdVMagWhzNt),q8qv3XSGmsDjJZeMRxYafhnQ,font=O6OJwXTKEhL,fill=UY8dwfGN7QrRp3LPyg4Ej)
				if EEPtQZFbjN2kunlUHzroRBvSma==Zb5cNeHWi6jP9SCYtUgR(u"ࠧ࡮ࡧࡱࡹࡤ࡯ࡴࡦ࡯ࠪୠ"): mJMks46jT9QHzox3t0ncGK2yWvSRe.text((aWzmHpO6Rn8JbtMi3QTucy14GldwvZ+xD9WeoEAsX7,FcdVMagWhzNt+xD9WeoEAsX7),q8qv3XSGmsDjJZeMRxYafhnQ,font=O6OJwXTKEhL,fill=UY8dwfGN7QrRp3LPyg4Ej)
				if not nnRCqcFyxUePD50TMXA: SP6oaF4BOxRhXAvgDNtbH0 += GGQEFRb82AmxBs5Z3HS
				if FcdVMagWhzNt>Z0kcPvjM5HsWh+pPX1LJdTyQM4CDZE6e0OVcWtUvArG: break
	if EEPtQZFbjN2kunlUHzroRBvSma==Zb5cNeHWi6jP9SCYtUgR(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫୡ"):
		Kp3zeFuInW = dC3pbTFzR1rutOc5EG4YekUgLQBJ.copy()
		f7epsRlYtMz4.sleep(f9fOpCmLAEaW2Go(u"࠱࠰࠳࠹௴"))
		Kp3zeFuInW.paste(qHixdKb7mLU3Js8t1egz6nc,(nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib),mask=NeQadcI5uUnKJj91)
	else: Kp3zeFuInW = NeQadcI5uUnKJj91
	if hT1JIgqPQsUOZp5tjCX0E: nlWuci0J9kh6eM8r1vUTKfHQy = nlWuci0J9kh6eM8r1vUTKfHQy.decode(RMGz7OiD1e30P)
	try: Kp3zeFuInW.save(nlWuci0J9kh6eM8r1vUTKfHQy)
	except UnicodeError:
		if hT1JIgqPQsUOZp5tjCX0E:
			nlWuci0J9kh6eM8r1vUTKfHQy = nlWuci0J9kh6eM8r1vUTKfHQy.encode(RMGz7OiD1e30P)
			Kp3zeFuInW.save(nlWuci0J9kh6eM8r1vUTKfHQy)
	return ZaxKcAp4wFP1G0QvyTrCu
def cUPjCuyw09ZfpK2Xkl8z5q1(RZoi7rUxnp,O6OJwXTKEhL,JsvWDnPBphXSG,r5n7IiFRqNG1dj,yyeVu0hxbjt,vOlFTo6AjKsk2eUV):
	eczw9YobuRJW5saPArX0CK,kJefo2Y4dWyZtS,XT4g70cRY8qnjo6stzW = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nUaVQsoA6EXcK4Odht5wCge0J8Pib,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠳࠸࠴࠵࠶௵")
	JsvWDnPBphXSG = JsvWDnPBphXSG.replace(KKCrwPdOgGl(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪୢ"),pYeVwat64v(u"ࠪ࡟ࡈࡕࡌࡐࡔ࠽࠾࠿࠭ୣ"))
	e1fJFapMCmjwcLUS45vAlQ3 = yyeVu0hxbjt-r5n7IiFRqNG1dj*H3OKMjDG1evnl4Ruiz
	for lmegy5HOqTIhs7 in JsvWDnPBphXSG.splitlines():
		kJefo2Y4dWyZtS += vOlFTo6AjKsk2eUV
		d8qeSWJ5Ia63hELDlvF9CMH,fLNagCyP51I7A0BVsUHp8O2c = nUaVQsoA6EXcK4Odht5wCge0J8Pib,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		for Wd3SbZBaXGN9Y8F0n in lmegy5HOqTIhs7.split(WRsuxHTjDgYCIpoMQzLFAtS8rikP):
			Lu4UdlgrIY8BTHZAmOc5ijEN1D6oa = BMWpOhtDdCKN1(WRsuxHTjDgYCIpoMQzLFAtS8rikP+Wd3SbZBaXGN9Y8F0n)
			Jv3UakFAeB5cPH,GfA0KeTO3Mlhxzv5dNsjXLQ8b4ap2 = RZoi7rUxnp.textsize(Lu4UdlgrIY8BTHZAmOc5ijEN1D6oa,font=O6OJwXTKEhL)
			if d8qeSWJ5Ia63hELDlvF9CMH+Jv3UakFAeB5cPH<e1fJFapMCmjwcLUS45vAlQ3:
				if not fLNagCyP51I7A0BVsUHp8O2c: fLNagCyP51I7A0BVsUHp8O2c += Wd3SbZBaXGN9Y8F0n
				else: fLNagCyP51I7A0BVsUHp8O2c += WRsuxHTjDgYCIpoMQzLFAtS8rikP+Wd3SbZBaXGN9Y8F0n
				d8qeSWJ5Ia63hELDlvF9CMH += Jv3UakFAeB5cPH
			else:
				if Jv3UakFAeB5cPH<e1fJFapMCmjwcLUS45vAlQ3:
					fLNagCyP51I7A0BVsUHp8O2c += CCWqR3dmtzw6xoIX41(u"ࠫࡡࡴࠠࠨ୤")+Wd3SbZBaXGN9Y8F0n
					kJefo2Y4dWyZtS += vOlFTo6AjKsk2eUV
					d8qeSWJ5Ia63hELDlvF9CMH = Jv3UakFAeB5cPH
				else:
					while Jv3UakFAeB5cPH>e1fJFapMCmjwcLUS45vAlQ3:
						for WWlVCHMzIF7qwQGvma6yd in range(xD9WeoEAsX7,len(WRsuxHTjDgYCIpoMQzLFAtS8rikP+Wd3SbZBaXGN9Y8F0n),xD9WeoEAsX7):
							nnHj3aN9sod8L2BrVCXZDte1GbWK = WRsuxHTjDgYCIpoMQzLFAtS8rikP+Wd3SbZBaXGN9Y8F0n[:WWlVCHMzIF7qwQGvma6yd]
							eUMTlVsQBvO2Pcg46ur9aNCydbiDzE = Wd3SbZBaXGN9Y8F0n[WWlVCHMzIF7qwQGvma6yd:]
							sX2d1oZNWhKe7OVUBzlvSg4mPDAfk = BMWpOhtDdCKN1(nnHj3aN9sod8L2BrVCXZDte1GbWK)
							W0dkHqsOSGZuzh36IMj15DvAX9N,JBcbaZLWFsPgHKXYj38NiqT2C = RZoi7rUxnp.textsize(sX2d1oZNWhKe7OVUBzlvSg4mPDAfk,font=O6OJwXTKEhL)
							if d8qeSWJ5Ia63hELDlvF9CMH+W0dkHqsOSGZuzh36IMj15DvAX9N>e1fJFapMCmjwcLUS45vAlQ3:
								c5SkxeEVJr0DAX4j = Jv3UakFAeB5cPH-W0dkHqsOSGZuzh36IMj15DvAX9N
								fLNagCyP51I7A0BVsUHp8O2c += nnHj3aN9sod8L2BrVCXZDte1GbWK+b8sk5WyPoz03pXhRx
								kJefo2Y4dWyZtS += vOlFTo6AjKsk2eUV
								Jv3UakFAeB5cPH = c5SkxeEVJr0DAX4j
								if c5SkxeEVJr0DAX4j>e1fJFapMCmjwcLUS45vAlQ3:
									d8qeSWJ5Ia63hELDlvF9CMH = nUaVQsoA6EXcK4Odht5wCge0J8Pib
									Wd3SbZBaXGN9Y8F0n = eUMTlVsQBvO2Pcg46ur9aNCydbiDzE
								else:
									d8qeSWJ5Ia63hELDlvF9CMH = c5SkxeEVJr0DAX4j
									fLNagCyP51I7A0BVsUHp8O2c += eUMTlVsQBvO2Pcg46ur9aNCydbiDzE
								break
				if kJefo2Y4dWyZtS>XT4g70cRY8qnjo6stzW: break
		eczw9YobuRJW5saPArX0CK += b8sk5WyPoz03pXhRx+fLNagCyP51I7A0BVsUHp8O2c
		if kJefo2Y4dWyZtS>XT4g70cRY8qnjo6stzW: break
	eczw9YobuRJW5saPArX0CK = eczw9YobuRJW5saPArX0CK[xD9WeoEAsX7:]
	eczw9YobuRJW5saPArX0CK = eczw9YobuRJW5saPArX0CK.replace(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ୥"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࡛࠭ࡄࡑࡏࡓࡗࠦࠧ୦"))
	return eczw9YobuRJW5saPArX0CK
def BMWpOhtDdCKN1(Wd3SbZBaXGN9Y8F0n):
	if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࡜ࠩ୧") in Wd3SbZBaXGN9Y8F0n and rAYDiWlzm9MCU6x0GnROua(u"ࠨ࡟ࠪ୨") in Wd3SbZBaXGN9Y8F0n:
		AAN2oEubYBDW1kyzd6Q5CTjs7Otrl = [so4Z8OUJ5E,W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡞࠳ࡗ࡚ࡌ࡞ࠩ୩"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡟࠴ࡒࡅࡇࡖࡠࠫ୪"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡠ࠵ࡒࡊࡉࡋࡘࡢ࠭୫"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡡ࠯ࡄࡇࡑࡘࡊࡘ࡝ࠨ୬"),vl6rwMLasAQo4z1ZjD3IBKtF(u"࡛࠭ࡓࡖࡏࡡࠬ୭"),GTmHXIZUSdxRhMnqQKkO(u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠧ୮"),w9wfONXUP3(u"ࠨ࡝ࡕࡍࡌࡎࡔ࡞ࠩ୯"),Zb5cNeHWi6jP9SCYtUgR(u"ࠩ࡞ࡇࡊࡔࡔࡆࡔࡠࠫ୰")]
		vmUbJiVwdToHhRqzfsrXIu4LC = AxTYMhRlfyskNc0X19dvwtS.findall(lRKCWnNi0Edr984eI(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠳࠰࠿࡝࡟ࠪୱ"),Wd3SbZBaXGN9Y8F0n,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		QIAyxYdCtpjwXq6iul = AxTYMhRlfyskNc0X19dvwtS.findall(zWBnYSGIatjXVC(u"ࠫࡡࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺࠯ࠬࡂࡠࡢ࠭୲"),Wd3SbZBaXGN9Y8F0n,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		dDeSUVnhk8asBFpfHPuvMNAELq = AAN2oEubYBDW1kyzd6Q5CTjs7Otrl+vmUbJiVwdToHhRqzfsrXIu4LC+QIAyxYdCtpjwXq6iul
		for YL0ZQISt18vcXKm43ABDafw in dDeSUVnhk8asBFpfHPuvMNAELq: Wd3SbZBaXGN9Y8F0n = Wd3SbZBaXGN9Y8F0n.replace(YL0ZQISt18vcXKm43ABDafw,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	return Wd3SbZBaXGN9Y8F0n
def SSxKWgzNnUyhfdY(ggM5TzCxq24sDYLiEatpdSK7FQyGe):
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(b8sk5WyPoz03pXhRx,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡥࡳࡴࡵࡢࡣࡳ࡫ࡷ࡭࡫ࡱࡩࡤ࠭୳"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(Zb5cNeHWi6jP9SCYtUgR(u"࡛࠭ࡓࡖࡏࡡࠬ୴"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶࡹࡲ࡟ࠨ୵"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(GTmHXIZUSdxRhMnqQKkO(u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨ୶"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ୷"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫ୸"),ba49YvOK2Aw8Uhxt(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ୹"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(f9fOpCmLAEaW2Go(u"ࠬࡡࡃࡆࡐࡗࡉࡗࡣࠧ୺"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ୻"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(so4Z8OUJ5E,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡠࡵࡶࡷࡤࡥࡥ࡯ࡦࡦࡳࡱࡵࡲࡠࠩ୼"))
	MJhbOzwn5E6f = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢࠫ࠲࠯ࡅࠩ࡝࡟ࠪ୽"),ggM5TzCxq24sDYLiEatpdSK7FQyGe,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for UWcSvaF4qYojThfRADE in MJhbOzwn5E6f: ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.replace(w9wfONXUP3(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ୾")+UWcSvaF4qYojThfRADE+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡡࠬ୿"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ஀")+UWcSvaF4qYojThfRADE+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡥࠧ஁"))
	return ggM5TzCxq24sDYLiEatpdSK7FQyGe