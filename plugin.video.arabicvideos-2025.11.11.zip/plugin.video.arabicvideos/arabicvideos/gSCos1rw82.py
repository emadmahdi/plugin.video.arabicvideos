# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'GLOBALSEARCH'
qBAgzkG9oCL = '_GLS_'
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe,GpwRnQ6q2o1fv0HbJTs):
	if   t5fhagjUGXk0ynOlJWeAb==540: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif t5fhagjUGXk0ynOlJWeAb==541: Ubud2NhHKRnMTvI5mprQBVqk80 = a3arLItDdH7CTAR0U(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==542: Ubud2NhHKRnMTvI5mprQBVqk80 = Tuzc4GQ9PtdLfeh(ggM5TzCxq24sDYLiEatpdSK7FQyGe,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,GpwRnQ6q2o1fv0HbJTs)
	elif t5fhagjUGXk0ynOlJWeAb==543: Ubud2NhHKRnMTvI5mprQBVqk80 = I3Ikr2Pwyi5fGjBQ()
	elif t5fhagjUGXk0ynOlJWeAb==548: Ubud2NhHKRnMTvI5mprQBVqk80 = FC9tp4xVoT2nU(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==549: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder','بحث جديد لجميع المواقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,549)
	w3BfOGLdXcWzbiC1PYx9mE('link','كيف يعمل بحث جميع المواقع','',543)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'==== كلمات البحث المخزنة ===='+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	tt5rQBVLH9fE7d4FDAcUIjSgO = dYMLGvgfk4(mmEuUR4JdaHtAsS,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if tt5rQBVLH9fE7d4FDAcUIjSgO:
		tt5rQBVLH9fE7d4FDAcUIjSgO = tt5rQBVLH9fE7d4FDAcUIjSgO['__SEQUENCED_COLUMNS__']
		for a9YrjQPdZ8JicSD2LbG in reversed(tt5rQBVLH9fE7d4FDAcUIjSgO):
			w3BfOGLdXcWzbiC1PYx9mE('folder',a9YrjQPdZ8JicSD2LbG,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,549,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,a9YrjQPdZ8JicSD2LbG)
	return
def E3FwPg9Z6KB(a9YrjQPdZ8JicSD2LbG):
	if not a9YrjQPdZ8JicSD2LbG:
		a9YrjQPdZ8JicSD2LbG = TwDBf3QbKOnrmd5u9()
		if not a9YrjQPdZ8JicSD2LbG: return
		a9YrjQPdZ8JicSD2LbG = a9YrjQPdZ8JicSD2LbG.lower()
	f1EhmRrADV8KxiNQcayZ6tswPI = a9YrjQPdZ8JicSD2LbG.replace(qBAgzkG9oCL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	t0Q5BsEv3l8kVSbAz7iHwOp(f1EhmRrADV8KxiNQcayZ6tswPI,'_ALL',True)
	w3BfOGLdXcWzbiC1PYx9mE('link','بحث جماعي للمواقع - '+f1EhmRrADV8KxiNQcayZ6tswPI,'search_sites_all',542,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('folder','بحث منفرد للمواقع - '+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,541,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder','نتائج البحث مفصلة - '+f1EhmRrADV8KxiNQcayZ6tswPI,'opened_sites_all',542,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('folder','نتائج البحث مقسمة - '+f1EhmRrADV8KxiNQcayZ6tswPI,'listed_sites_all',542,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	return
def t0Q5BsEv3l8kVSbAz7iHwOp(gp0Z2IcW3O4uTiVjeSNvbzkXRmPs,g2YxGQJfuvXUH1WBj,Z2ZIvndPj8FKr):
	if g2YxGQJfuvXUH1WBj=='_ALL': f4zq3ogv1YQuAe6DVcMxwXUBba = '_GLS_'
	elif g2YxGQJfuvXUH1WBj=='_GOOGLE': f4zq3ogv1YQuAe6DVcMxwXUBba = '_GOS_'
	nk8CMw5AjpetRLWZfNxIv = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,gp0Z2IcW3O4uTiVjeSNvbzkXRmPs)
	zNup8GSMR7eiCVIB = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,f4zq3ogv1YQuAe6DVcMxwXUBba+gp0Z2IcW3O4uTiVjeSNvbzkXRmPs)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,gp0Z2IcW3O4uTiVjeSNvbzkXRmPs)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,f4zq3ogv1YQuAe6DVcMxwXUBba+gp0Z2IcW3O4uTiVjeSNvbzkXRmPs)
	SsjwkfBy58ur = nk8CMw5AjpetRLWZfNxIv+zNup8GSMR7eiCVIB
	if SsjwkfBy58ur and Z2ZIvndPj8FKr: gp0Z2IcW3O4uTiVjeSNvbzkXRmPs = f4zq3ogv1YQuAe6DVcMxwXUBba+gp0Z2IcW3O4uTiVjeSNvbzkXRmPs
	JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,gp0Z2IcW3O4uTiVjeSNvbzkXRmPs,SsjwkfBy58ur,QT1GPoWB7px)
	return
def nPJdWMlftiGvsp49BTFo(g2YxGQJfuvXUH1WBj):
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if e6f0ycMuYQEJraNLInmip!=1: return
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DETAILED'+g2YxGQJfuvXUH1WBj)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DIVIDED'+g2YxGQJfuvXUH1WBj)
	if g2YxGQJfuvXUH1WBj=='_GOOGLE': rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GOOGLESEARCH_RESULTS')
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def Tuzc4GQ9PtdLfeh(R3QM2nF54UfGIPBOHs0z9cEdX6xSo,s92QojlFDnw01fzhmg3d,ZgFCvEPGdtD3p0BNYhL7A9yI4r=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,QHkPUe3pl4TzbXuGDSiIrRd=iBjkvOZ4a9qRcboSGLyCTIf57KWn,L64Wn5djcJ0aUfxRY1vspVSg8NI={}):
	Qh5NRto2kCJvlZaqOIfHyciFpe,EptZ0yYTGNHcgqnf,k0rgLnfzymMDN8JvuVjGtOHW52A,kkU7GqEnjO2At8m,qE6SnPdprItLji9U4zc5Kxokwa = [],{},{},{},{}
	if '_all' in s92QojlFDnw01fzhmg3d: g2YxGQJfuvXUH1WBj,Lc1xDe8hOMKoA,f4zq3ogv1YQuAe6DVcMxwXUBba = '_ALL','_all','_GLS_'
	elif '_google' in s92QojlFDnw01fzhmg3d: g2YxGQJfuvXUH1WBj,Lc1xDe8hOMKoA,f4zq3ogv1YQuAe6DVcMxwXUBba = '_GOOGLE','_google','_GOS_'
	if s92QojlFDnw01fzhmg3d in ['listed_sites'+Lc1xDe8hOMKoA,'opened_sites'+Lc1xDe8hOMKoA,'closed_sites'+Lc1xDe8hOMKoA]:
		if s92QojlFDnw01fzhmg3d=='listed_sites'+Lc1xDe8hOMKoA: Qh5NRto2kCJvlZaqOIfHyciFpe = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,f4zq3ogv1YQuAe6DVcMxwXUBba+R3QM2nF54UfGIPBOHs0z9cEdX6xSo)
		elif s92QojlFDnw01fzhmg3d=='opened_sites'+Lc1xDe8hOMKoA: Qh5NRto2kCJvlZaqOIfHyciFpe = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GLOBALSEARCH_DETAILED'+g2YxGQJfuvXUH1WBj,R3QM2nF54UfGIPBOHs0z9cEdX6xSo)
		elif s92QojlFDnw01fzhmg3d=='closed_sites'+Lc1xDe8hOMKoA: Qh5NRto2kCJvlZaqOIfHyciFpe = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GLOBALSEARCH_DIVIDED'+g2YxGQJfuvXUH1WBj,(ZgFCvEPGdtD3p0BNYhL7A9yI4r,R3QM2nF54UfGIPBOHs0z9cEdX6xSo))
	if not Qh5NRto2kCJvlZaqOIfHyciFpe:
		jQxNuCVe4hzpObyKU = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		VLRK8jaf4GxrIm2tN = 'هل تريد الآن البحث في جميع المواقع عن \n "'+oamlxBqLdu4ZM9nQrbIAhS5Pg7+WRsuxHTjDgYCIpoMQzLFAtS8rikP+R3QM2nF54UfGIPBOHs0z9cEdX6xSo+WRsuxHTjDgYCIpoMQzLFAtS8rikP+so4Z8OUJ5E+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if s92QojlFDnw01fzhmg3d=='search_sites'+Lc1xDe8hOMKoA: mlrXUnyLzPAhEIj8ix5Ztpu = VLRK8jaf4GxrIm2tN
		else: mlrXUnyLzPAhEIj8ix5Ztpu = jQxNuCVe4hzpObyKU+VLRK8jaf4GxrIm2tN
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
		if e6f0ycMuYQEJraNLInmip!=1: return
		zCtB6lUJjnOcHibaErDuP2xGf(OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh)
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+'   Search For: [ '+R3QM2nF54UfGIPBOHs0z9cEdX6xSo+' ]')
		posfatSzZ2K = 1
		for z4t2nu5ryZjPR in QHkPUe3pl4TzbXuGDSiIrRd:
			g0pBxfvasRI6JVDeZqPj1NCzyokU = L64Wn5djcJ0aUfxRY1vspVSg8NI[z4t2nu5ryZjPR] if L64Wn5djcJ0aUfxRY1vspVSg8NI else R3QM2nF54UfGIPBOHs0z9cEdX6xSo
			try: Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
			except: continue
			EptZ0yYTGNHcgqnf[z4t2nu5ryZjPR] = []
			wVtSpAsUu0cMblPqxK1F = '_NODIALOGS_'
			if '-' in z4t2nu5ryZjPR: wVtSpAsUu0cMblPqxK1F = wVtSpAsUu0cMblPqxK1F+'_REMEMBERRESULTS__'+z4t2nu5ryZjPR+'_'
			if posfatSzZ2K:
				f7epsRlYtMz4.sleep(0.75)
				qE6SnPdprItLji9U4zc5Kxokwa[z4t2nu5ryZjPR] = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=KvBuT8dIwNVR7e61zJnWrmUGPh,args=(g0pBxfvasRI6JVDeZqPj1NCzyokU+wVtSpAsUu0cMblPqxK1F,))
				qE6SnPdprItLji9U4zc5Kxokwa[z4t2nu5ryZjPR].start()
			else: KvBuT8dIwNVR7e61zJnWrmUGPh(g0pBxfvasRI6JVDeZqPj1NCzyokU+wVtSpAsUu0cMblPqxK1F)
			ARL0tsEeanKImhMByugPTvX7(dOui5LJeABG0TYcMj(z4t2nu5ryZjPR),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f7epsRlYtMz4=1000)
		if posfatSzZ2K:
			f7epsRlYtMz4.sleep(2)
			for z4t2nu5ryZjPR in QHkPUe3pl4TzbXuGDSiIrRd: qE6SnPdprItLji9U4zc5Kxokwa[z4t2nu5ryZjPR].join(10)
			f7epsRlYtMz4.sleep(2)
		for z4t2nu5ryZjPR in QHkPUe3pl4TzbXuGDSiIrRd:
			try: Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
			except: continue
			for IzNRi6kSZB in drzqWFkSHD.menuItemsLIST:
				ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = IzNRi6kSZB
				if sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g in usYnJBXhFT:
					if 'IPTV-' in z4t2nu5ryZjPR and (239>=t5fhagjUGXk0ynOlJWeAb>=230 or 289>=t5fhagjUGXk0ynOlJWeAb>=280):
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['IPTV-LIVE']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['IPTV-MOVIES']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['IPTV-SERIES']: continue
						if 'صفحة' not in usYnJBXhFT:
							if   ZJksHpSUNh2f=='live': z4t2nu5ryZjPR = 'IPTV-LIVE'
							elif ZJksHpSUNh2f=='video': z4t2nu5ryZjPR = 'IPTV-MOVIES'
							elif ZJksHpSUNh2f=='folder': z4t2nu5ryZjPR = 'IPTV-SERIES'
						else:
							if   'LIVE' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'IPTV-LIVE'
							elif 'MOVIES' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'IPTV-MOVIES'
							elif 'SERIES' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'IPTV-SERIES'
					elif 'M3U-' in z4t2nu5ryZjPR and 729>=t5fhagjUGXk0ynOlJWeAb>=710:
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['M3U-LIVE']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['M3U-MOVIES']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['M3U-SERIES']: continue
						if 'صفحة' not in usYnJBXhFT:
							if   ZJksHpSUNh2f=='live': z4t2nu5ryZjPR = 'M3U-LIVE'
							elif ZJksHpSUNh2f=='video': z4t2nu5ryZjPR = 'M3U-MOVIES'
							elif ZJksHpSUNh2f=='folder': z4t2nu5ryZjPR = 'M3U-SERIES'
						else:
							if   'LIVE' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'M3U-LIVE'
							elif 'MOVIES' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'M3U-MOVIES'
							elif 'SERIES' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'M3U-SERIES'
					elif 'YOUTUBE-' in z4t2nu5ryZjPR and 149>=t5fhagjUGXk0ynOlJWeAb>=140:
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['YOUTUBE-CHANNELS']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['YOUTUBE-PLAYLISTS']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in usYnJBXhFT or ':: ' in usYnJBXhFT:
							continue
						else:
							if   t5fhagjUGXk0ynOlJWeAb==144 and 'USER' in usYnJBXhFT: z4t2nu5ryZjPR = 'YOUTUBE-CHANNELS'
							elif t5fhagjUGXk0ynOlJWeAb==144 and 'CHNL' in usYnJBXhFT: z4t2nu5ryZjPR = 'YOUTUBE-CHANNELS'
							elif t5fhagjUGXk0ynOlJWeAb==144 and 'LIST' in usYnJBXhFT: z4t2nu5ryZjPR = 'YOUTUBE-PLAYLISTS'
							elif t5fhagjUGXk0ynOlJWeAb==143: z4t2nu5ryZjPR = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in z4t2nu5ryZjPR and 419>=t5fhagjUGXk0ynOlJWeAb>=400:
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['DAILYMOTION-PLAYLISTS']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['DAILYMOTION-CHANNELS']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['DAILYMOTION-VIDEOS']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['DAILYMOTION-LIVES']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['DAILYMOTION-HASHTAGS']: continue
						if   t5fhagjUGXk0ynOlJWeAb in [401,405]: z4t2nu5ryZjPR = 'DAILYMOTION-PLAYLISTS'
						elif t5fhagjUGXk0ynOlJWeAb in [402,406]: z4t2nu5ryZjPR = 'DAILYMOTION-CHANNELS'
						elif t5fhagjUGXk0ynOlJWeAb in [404]: z4t2nu5ryZjPR = 'DAILYMOTION-VIDEOS'
						elif t5fhagjUGXk0ynOlJWeAb in [415]: z4t2nu5ryZjPR = 'DAILYMOTION-LIVES'
						elif t5fhagjUGXk0ynOlJWeAb in [416]: z4t2nu5ryZjPR = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in z4t2nu5ryZjPR and 39>=t5fhagjUGXk0ynOlJWeAb>=30:
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['PANET-SERIES']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['PANET-MOVIES']: continue
						if   t5fhagjUGXk0ynOlJWeAb in [32,39]: z4t2nu5ryZjPR = 'PANET-SERIES'
						elif t5fhagjUGXk0ynOlJWeAb in [33,39]: z4t2nu5ryZjPR = 'PANET-MOVIES'
					elif 'IFILM-' in z4t2nu5ryZjPR and 29>=t5fhagjUGXk0ynOlJWeAb>=20:
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['IFILM-ARABIC']: continue
						if IzNRi6kSZB in EptZ0yYTGNHcgqnf['IFILM-ENGLISH']: continue
						if   '/ar.' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'IFILM-ARABIC'
						elif '/en.' in s3chK0CpdkqFzAr6UvZloXHTwMxQmf: z4t2nu5ryZjPR = 'IFILM-ENGLISH'
					EptZ0yYTGNHcgqnf[z4t2nu5ryZjPR].append(IzNRi6kSZB)
		for z4t2nu5ryZjPR in list(EptZ0yYTGNHcgqnf.keys()):
			k0rgLnfzymMDN8JvuVjGtOHW52A[z4t2nu5ryZjPR] = []
			kkU7GqEnjO2At8m[z4t2nu5ryZjPR] = []
			for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in EptZ0yYTGNHcgqnf[z4t2nu5ryZjPR]:
				IzNRi6kSZB = (ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
				if 'صفحة' in usYnJBXhFT and ZJksHpSUNh2f=='folder': kkU7GqEnjO2At8m[z4t2nu5ryZjPR].append(IzNRi6kSZB)
				else: k0rgLnfzymMDN8JvuVjGtOHW52A[z4t2nu5ryZjPR].append(IzNRi6kSZB)
		Y9Vour2BpJcnaHkdC,tUL7XSlZNAQwEy8a = [],[]
		ouS6Wib0YIF9Hek5dVJK = list(k0rgLnfzymMDN8JvuVjGtOHW52A.keys())
		yEjQLZ4Neztkq9l0sXuxSndwD6hi1C = jiqeWO1UaLAVDZX0GRbMEhgJ(ouS6Wib0YIF9Hek5dVJK)
		Z10a6Tm3NzHwRirKlfFbGD9cSPg = []
		for z4t2nu5ryZjPR in yEjQLZ4Neztkq9l0sXuxSndwD6hi1C:
			if isinstance(z4t2nu5ryZjPR,tuple):
				Z10a6Tm3NzHwRirKlfFbGD9cSPg = [z4t2nu5ryZjPR]
				continue
			if z4t2nu5ryZjPR not in QHkPUe3pl4TzbXuGDSiIrRd: continue
			if k0rgLnfzymMDN8JvuVjGtOHW52A[z4t2nu5ryZjPR]:
				etBGrMFHfSk4yszmaLnKPlQ7O6 = dOui5LJeABG0TYcMj(z4t2nu5ryZjPR)
				MbxJPogYAufLcr29NHynaK = [('link',oamlxBqLdu4ZM9nQrbIAhS5Pg7+'===== '+etBGrMFHfSk4yszmaLnKPlQ7O6+' ====='+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)]
				if 0: phzyEmjeWnSUfc = R3QM2nF54UfGIPBOHs0z9cEdX6xSo+' - '+'بحث'+WRsuxHTjDgYCIpoMQzLFAtS8rikP+etBGrMFHfSk4yszmaLnKPlQ7O6
				else: phzyEmjeWnSUfc = 'بحث'+WRsuxHTjDgYCIpoMQzLFAtS8rikP+etBGrMFHfSk4yszmaLnKPlQ7O6+' - '+R3QM2nF54UfGIPBOHs0z9cEdX6xSo
				if len(k0rgLnfzymMDN8JvuVjGtOHW52A[z4t2nu5ryZjPR])<8: OumpPAn59UaQFkLhsMjJxTNe = []
				else:
					zztJ6bjwvMmxho5dFRsfXZ = qFghPAi5yz9Vf3NLwo0nuprl+phzyEmjeWnSUfc+so4Z8OUJ5E
					OumpPAn59UaQFkLhsMjJxTNe = [('folder',f4zq3ogv1YQuAe6DVcMxwXUBba+zztJ6bjwvMmxho5dFRsfXZ,'closed_sites'+Lc1xDe8hOMKoA,542,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,z4t2nu5ryZjPR,R3QM2nF54UfGIPBOHs0z9cEdX6xSo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)]
				ukglQ7pK8EjAF = k0rgLnfzymMDN8JvuVjGtOHW52A[z4t2nu5ryZjPR]+kkU7GqEnjO2At8m[z4t2nu5ryZjPR]
				fR352q0ix4 = Z10a6Tm3NzHwRirKlfFbGD9cSPg+MbxJPogYAufLcr29NHynaK+ukglQ7pK8EjAF[:7]+OumpPAn59UaQFkLhsMjJxTNe
				Y9Vour2BpJcnaHkdC += fR352q0ix4
				OlufrvCjy1YcWtQsaH = [('folder',f4zq3ogv1YQuAe6DVcMxwXUBba+phzyEmjeWnSUfc,'closed_sites'+Lc1xDe8hOMKoA,542,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,z4t2nu5ryZjPR,R3QM2nF54UfGIPBOHs0z9cEdX6xSo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)]
				JLwxB5VASyUKd9atpQjz6HOo8TgWPe = Z10a6Tm3NzHwRirKlfFbGD9cSPg+OlufrvCjy1YcWtQsaH
				tUL7XSlZNAQwEy8a += JLwxB5VASyUKd9atpQjz6HOo8TgWPe
				JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DIVIDED'+g2YxGQJfuvXUH1WBj,(z4t2nu5ryZjPR,R3QM2nF54UfGIPBOHs0z9cEdX6xSo),ukglQ7pK8EjAF,QT1GPoWB7px)
				Z10a6Tm3NzHwRirKlfFbGD9cSPg = []
		JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DETAILED'+g2YxGQJfuvXUH1WBj,R3QM2nF54UfGIPBOHs0z9cEdX6xSo,Y9Vour2BpJcnaHkdC,QT1GPoWB7px)
		rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,R3QM2nF54UfGIPBOHs0z9cEdX6xSo)
		JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'GLOBALSEARCH_SPLITTED'+g2YxGQJfuvXUH1WBj,f4zq3ogv1YQuAe6DVcMxwXUBba+R3QM2nF54UfGIPBOHs0z9cEdX6xSo,tUL7XSlZNAQwEy8a,QT1GPoWB7px)
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		Qh5NRto2kCJvlZaqOIfHyciFpe = tUL7XSlZNAQwEy8a if s92QojlFDnw01fzhmg3d=='listed_sites'+Lc1xDe8hOMKoA and tUL7XSlZNAQwEy8a else Y9Vour2BpJcnaHkdC
	if s92QojlFDnw01fzhmg3d in ['listed_sites'+Lc1xDe8hOMKoA,'opened_sites'+Lc1xDe8hOMKoA,'closed_sites'+Lc1xDe8hOMKoA]:
		for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in Qh5NRto2kCJvlZaqOIfHyciFpe:
			if s92QojlFDnw01fzhmg3d in ['listed_sites'+Lc1xDe8hOMKoA,'opened_sites'+Lc1xDe8hOMKoA] and 'صفحة' in usYnJBXhFT and ZJksHpSUNh2f=='folder': continue
			w3BfOGLdXcWzbiC1PYx9mE(ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
	zCtB6lUJjnOcHibaErDuP2xGf(btR0Zix9D2g,btR0Zix9D2g,btR0Zix9D2g)
	return
def a3arLItDdH7CTAR0U(search):
	yEjQLZ4Neztkq9l0sXuxSndwD6hi1C = jiqeWO1UaLAVDZX0GRbMEhgJ(oZpNRUMvIQDOXyJ26eYctahBz)
	for z4t2nu5ryZjPR in yEjQLZ4Neztkq9l0sXuxSndwD6hi1C:
		if '-' in z4t2nu5ryZjPR: continue
		if isinstance(z4t2nu5ryZjPR,tuple):
			drzqWFkSHD.menuItemsLIST.append(z4t2nu5ryZjPR)
			continue
		Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
		name = dOui5LJeABG0TYcMj(z4t2nu5ryZjPR)+' - '+search
		w3BfOGLdXcWzbiC1PYx9mE('folder',sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g+name,z4t2nu5ryZjPR,548,'','',search)
	return
def FC9tp4xVoT2nU(z4t2nu5ryZjPR,search):
	Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
	KvBuT8dIwNVR7e61zJnWrmUGPh(search)
	return
def I3Ikr2Pwyi5fGjBQ():
	w4dBvakygFs2IZO1Azt('','',F91YEzyWak5,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def gUNbCfdmjMiLKWp4wc(R3QM2nF54UfGIPBOHs0z9cEdX6xSo=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	a9YrjQPdZ8JicSD2LbG,wVtSpAsUu0cMblPqxK1F,showDialogs = EAgxpW09CSdZBy82KtTG4(R3QM2nF54UfGIPBOHs0z9cEdX6xSo)
	if not a9YrjQPdZ8JicSD2LbG:
		a9YrjQPdZ8JicSD2LbG = TwDBf3QbKOnrmd5u9()
		if not a9YrjQPdZ8JicSD2LbG: return
		a9YrjQPdZ8JicSD2LbG = a9YrjQPdZ8JicSD2LbG.lower()
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+'   Search For: [ '+a9YrjQPdZ8JicSD2LbG+' ]')
	ej9gRJkD6KGTcf = a9YrjQPdZ8JicSD2LbG+wVtSpAsUu0cMblPqxK1F
	if 0: SSUCRcG3aK9kW4ie7LwT2,f1EhmRrADV8KxiNQcayZ6tswPI = a9YrjQPdZ8JicSD2LbG+' - ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: SSUCRcG3aK9kW4ie7LwT2,f1EhmRrADV8KxiNQcayZ6tswPI = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,' - '+a9YrjQPdZ8JicSD2LbG
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'مواقع سيرفرات خاصة - قليلة المشاكل'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,157)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_M3U_'+SSUCRcG3aK9kW4ie7LwT2+'بحث M3U'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,719,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_IPT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث IPTV'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,239,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_BKR_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع بكرا'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,379,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_ART_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع تونز عربية'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,739,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_KRB_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع قناة كربلاء'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,329,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FH2_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فاصل الثاني'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,599,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_KTV_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع كتكوت تيفي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,819,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_EB1_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع ايجي بيست 1'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,779,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_EB2_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع ايجي بيست 2'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,789,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_IFL_'+SSUCRcG3aK9kW4ie7LwT2+'  بحث موقع قناة آي فيلم'+f1EhmRrADV8KxiNQcayZ6tswPI+zHYL9u48eyJot,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,29,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_AKO_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع أكوام القديم'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,79,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_AKW_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع أكوام الجديد'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,249,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_MRF_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع قناة المعارف'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,49,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SHM_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شوف ماكس'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,59,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,157)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_LRZ_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع لاروزا'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,709,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FJS_'+SSUCRcG3aK9kW4ie7LwT2+' بحث موقع فجر شو'+f1EhmRrADV8KxiNQcayZ6tswPI+WRsuxHTjDgYCIpoMQzLFAtS8rikP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,399,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TVF_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع تيفي فان'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,469,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_LDN_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع لودي نت'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,459,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CMN_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما ناو'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,309,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SHN_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شاهد نيوز'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,589,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf+'_NODIALOGS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder','_ARS_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع عرب سييد'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,259,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CCB_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما كلوب'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,829,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SH4_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شاهد فوريو'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,119,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf+'_NODIALOGS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SHT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شوفها تيفي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,649,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_WC1_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع وي سيما 1'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,569,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_WC2_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع وي سيما 2'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1009,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'مواقع سيرفرات عامة - كثيرة المشاكل'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,157)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TKT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع تكات'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,949,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FST_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فوستا'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,609,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FBK_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فبركة'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,629,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_YQT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع ياقوت'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,669,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SHB_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شبكتي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,969,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_VRB_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فاربون'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,879,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_BRS_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع برستيج'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,659,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_KRM_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع كرمالك'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,929,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_ANZ_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع انمي زد'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,979,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FSK_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فارسكو'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,999,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_HLC_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع هلا سيما'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,89,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_MST_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع المصطبة'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,869,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SNT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع شوف نت'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,849,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_DR7_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع دراما صح'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,689,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CFR_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما فري'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,839,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CMF_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما فانز'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,99,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CML_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما لايت'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,479,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_C4H_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما 400'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,699,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_ABD_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما عبدو'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,559,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_AKT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع اكوام تيوب'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,859,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_DCF_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع دراما كافيه'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,939,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FTV_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فوشار تيفي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,919,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_CWB_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما وبس'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,989,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_AHK_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع أهواك تيفي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,619,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_SRT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيريس تايم'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,899,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_FVD_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع فوشار فيديو'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,909,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_C4P_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع سيما فور بي'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,889,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_EB4_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع ايجي بيست 4'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,809,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'مواقع سيرفرات خاصة - قليلة المشاكل'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,157)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_YUT_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع يوتيوب'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,149,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_DLM_'+SSUCRcG3aK9kW4ie7LwT2+'بحث موقع دايلي موشن'+f1EhmRrADV8KxiNQcayZ6tswPI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ej9gRJkD6KGTcf)
	return