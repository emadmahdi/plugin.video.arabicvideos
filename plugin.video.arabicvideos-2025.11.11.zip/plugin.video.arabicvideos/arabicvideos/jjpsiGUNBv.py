# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'CIMAABDO'
qBAgzkG9oCL = '_ABD_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['الرئيسية','افلام للكبار فقط +18']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==550: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==551: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==552: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==553: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==559: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo+'/home',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(S7EgasGcYdIo,'url')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,559,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'اخترنا لك',GGRexoVTLjusn6q+'/home',551,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-content(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-name="(.*?)".*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for gV1lKIhwSm0GQ,title in items:
		cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/ajax/getItem?item='+gV1lKIhwSm0GQ+'&Ajax=1'
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,551)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"nav-main"(.*?)</nav>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if cX2SpPxGLmADTKl=='#': continue
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,551)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	for cX2SpPxGLmADTKl,title in items:
		if cX2SpPxGLmADTKl=='#': continue
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,551)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,gV1lKIhwSm0GQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
		aNXRWYnbow7s8fpvLVK = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-TITLES-1st')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = [R8AE9e4mYxVhusL3Q]
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-TITLES-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if gV1lKIhwSm0GQ=='featured':
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"container"(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		elif '"section-post mb-10"' in R8AE9e4mYxVhusL3Q:
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"section-post mb-10"(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		else:
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<article(.*?)"pagination"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: return
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if not items:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl).strip('/')
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,552,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and 'الحلقة' in title:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,553,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/movies/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,551,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,553,RRx0ri8bETI)
	if gV1lKIhwSm0GQ==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination"(.*?)<footer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl=="": continue
				if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'هناك المزيد',url,551)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"getSeasonsBySeries(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"list-episodes"(.*?)"container"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if j9HbACE1rmuP48NVX6pgQsUwfBWk and '/series/' not in url:
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,553,RRx0ri8bETI)
	elif fxgnWRoUO7jNwtJkuB:
		RRx0ri8bETI = AxTYMhRlfyskNc0X19dvwtS.findall('"image" src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		RRx0ri8bETI = RRx0ri8bETI[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,552,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	jYfvU9egTX62nrukVcoKEAyq = url.replace('/movies/','/watch_movies/')
	jYfvU9egTX62nrukVcoKEAyq = jYfvU9egTX62nrukVcoKEAyq.replace('/episodes/','/watch_episodes/')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',jYfvU9egTX62nrukVcoKEAyq,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(jYfvU9egTX62nrukVcoKEAyq,'url')
	dU17fayKLj4kABu = []
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('''<iframe.*?src=["'](.*?)["']''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'url')
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+LLzkoiPsbBZ+'__embed')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"servers"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		ccHBj2aGoTKM5DZLv71U0CO = AxTYMhRlfyskNc0X19dvwtS.findall('postID = "(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		ccHBj2aGoTKM5DZLv71U0CO = ccHBj2aGoTKM5DZLv71U0CO[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for LLzkoiPsbBZ,title in items:
				title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/ajax/getPlayer?server='+LLzkoiPsbBZ+'&postID='+ccHBj2aGoTKM5DZLv71U0CO+'&Ajax=1'
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
		else:
			items = AxTYMhRlfyskNc0X19dvwtS.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if items:
				LLzkoiPsbBZ,JA4kO6cVtsxildRwFIeDy,title = items[0]
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/ajax/getPlayerByName?server='+LLzkoiPsbBZ+'&multipleServers='+JA4kO6cVtsxildRwFIeDy+'&postID='+ccHBj2aGoTKM5DZLv71U0CO+'&Ajax=1'
				nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(cX2SpPxGLmADTKl)
				aNXRWYnbow7s8fpvLVK = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-PLAY-2nd')
				R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
				fc1MjOx6b4FWTqt2BnJ5Asr = AxTYMhRlfyskNc0X19dvwtS.findall('''<iframe src=["'](.*?)["']''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
				evGVuBpQUEL = fc1MjOx6b4FWTqt2BnJ5Asr[0] if fc1MjOx6b4FWTqt2BnJ5Asr else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				if '/iframe/' in evGVuBpQUEL:
					gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',evGVuBpQUEL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-PLAY-3rd')
					R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
					WMBgY8iZ3afwKcV = AxTYMhRlfyskNc0X19dvwtS.findall('version&quot;:&quot;(.*?)&',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					WMBgY8iZ3afwKcV = WMBgY8iZ3afwKcV[0]
					aNXRWYnbow7s8fpvLVK = {}
					aNXRWYnbow7s8fpvLVK['X-Inertia-Partial-Component'] = 'files/mirror/video'
					aNXRWYnbow7s8fpvLVK['X-Inertia'] = 'true'
					aNXRWYnbow7s8fpvLVK['X-Inertia-Partial-Data'] = 'streams'
					aNXRWYnbow7s8fpvLVK['X-Inertia-Version'] = WMBgY8iZ3afwKcV
					gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',evGVuBpQUEL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMAABDO-PLAY-4th')
					R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
					rwPbBae924NHUiRvqhkAgKQTZ = rKY1tyQvh9OCxE2nl('dict',R8AE9e4mYxVhusL3Q)
					groups = rwPbBae924NHUiRvqhkAgKQTZ['props']['streams']['data']
					for group in groups:
						XcvFdKRjNLz5wEpDf = group['label'].replace(' (source)',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						N8s7t3Sw0yr = group['mirrors']
						for ByUXzI2cFPNJ1AT in N8s7t3Sw0yr:
							LLzkoiPsbBZ = ByUXzI2cFPNJ1AT['driver']
							cX2SpPxGLmADTKl = 'http:'+ByUXzI2cFPNJ1AT['link']+'?named='+LLzkoiPsbBZ+'__watch____'+XcvFdKRjNLz5wEpDf
							dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"downs"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,name in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+name+'__download'
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'-')
	url = S7EgasGcYdIo+'/search/'+search+'.html'
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return