# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'CIMALIGHT'
qBAgzkG9oCL = '_CML_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['قنوات فضائية']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==470: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==471: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==472: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==473: Ubud2NhHKRnMTvI5mprQBVqk80 = odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,text)
	elif mode==474: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==479: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,479,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"content"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		title = title.replace(zHYL9u48eyJot,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('cat=online-movies1','cat=online-movies')
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,474)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('/category.php">(.*?)"navslide-divider"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall("'dropdown-menu'(.*?)</ul>",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,474)
	return
def I1C6JqXo3j9Ruyz(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if 'topvideos.php' in url: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"caret"(.*?)id="pm-grid"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"caret"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if 'topvideos.php' in cX2SpPxGLmADTKl:
				if 'topvideos.php?c=english-movies' in cX2SpPxGLmADTKl: continue
				if 'topvideos.php?c=online-movies1' in cX2SpPxGLmADTKl: continue
				if 'topvideos.php?c=misc' in cX2SpPxGLmADTKl: continue
				if 'topvideos.php?c=tv-channel' in cX2SpPxGLmADTKl: continue
				if 'منذ البداية' in title and 'do=rating' not in cX2SpPxGLmADTKl: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,471)
	else: ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = []
	if eBjxVKSvQC1=='featured_movies':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"container-fluid"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		BA01W9olieErLycV7kwFvOhH5Y3ms,p3USGyZE9bKVhvjtd4W0,Ye8b7N4cTJnXS = zip(*items)
		items = zip(Ye8b7N4cTJnXS,BA01W9olieErLycV7kwFvOhH5Y3ms,p3USGyZE9bKVhvjtd4W0)
	elif eBjxVKSvQC1=='featured_series':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('المسلسلات المميزة(.*?)<style>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		BA01W9olieErLycV7kwFvOhH5Y3ms,p3USGyZE9bKVhvjtd4W0,Ye8b7N4cTJnXS = zip(*items)
		items = zip(Ye8b7N4cTJnXS,BA01W9olieErLycV7kwFvOhH5Y3ms,p3USGyZE9bKVhvjtd4W0)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(data-echo=".*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"BlocksList"(.*?)"titleSectionCon"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="pm-grid"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="pm-related"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pm-ul-browse-videos(.*?)clearfix',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: return
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl).strip('/')
		title = title.replace('ماي سيما',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('مشاهدة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
		if 'http' not in RRx0ri8bETI: RRx0ri8bETI = GGRexoVTLjusn6q+'/'+RRx0ri8bETI.strip('/')
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة) \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			title = '_MOD_'+title
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,472,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and 'حلقة' in title:
			title = '_MOD_'+azhwpE0qmevcFobdRi[0][0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,473,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/movseries/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,471,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,473,RRx0ri8bETI)
	if eBjxVKSvQC1 not in ['featured_movies','featured_series']:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl=='#': continue
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				title = riUKNnOEtVwdj4(title)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,471)
		zGyAMhFIjxNdlb6ZeX54 = AxTYMhRlfyskNc0X19dvwtS.findall('showmore" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if zGyAMhFIjxNdlb6ZeX54:
			cX2SpPxGLmADTKl = zGyAMhFIjxNdlb6ZeX54[0]
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مشاهدة المزيد',cX2SpPxGLmADTKl,471)
	return
def odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,nRW2P4Ke3z7):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-EPISODES-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"SeasonsBox"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	items = []
	if j9HbACE1rmuP48NVX6pgQsUwfBWk and not nRW2P4Ke3z7:
		RRx0ri8bETI = AxTYMhRlfyskNc0X19dvwtS.findall('"series-header".*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		RRx0ri8bETI = RRx0ri8bETI[0] if RRx0ri8bETI else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(items)==1: nRW2P4Ke3z7 = items[0][0]
		elif len(items)>1:
			for nRW2P4Ke3z7,title in items: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,473,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nRW2P4Ke3z7)
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('id="'+nRW2P4Ke3z7+'"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if fxgnWRoUO7jNwtJkuB and len(items)<2:
		RRx0ri8bETI = AxTYMhRlfyskNc0X19dvwtS.findall('"series-header".*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		RRx0ri8bETI = RRx0ri8bETI[0] if RRx0ri8bETI else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for cX2SpPxGLmADTKl,title in items:
				title = title.replace('ماي سيما',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('مسلسل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,472,RRx0ri8bETI)
		else:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,472,RRx0ri8bETI)
	if 'id="pm-related"' in R8AE9e4mYxVhusL3Q:
		if items: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مواضيع ذات صلة',url,471)
	return
def QgIZSJdUhsEnup8GPz3(url):
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<div itemprop="description">(.*?)href=',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('<p>(.*?)</p>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd,True): return
	nUDgc4absePT2xMt = url.replace('/watch.php','/play.php')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-PLAY-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	HE6iYhkK2T = []
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('"embedURL" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		if cX2SpPxGLmADTKl and cX2SpPxGLmADTKl not in HE6iYhkK2T:
			HE6iYhkK2T.append(cX2SpPxGLmADTKl)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named=__embed'
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	items = AxTYMhRlfyskNc0X19dvwtS.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if cX2SpPxGLmADTKl not in HE6iYhkK2T:
			HE6iYhkK2T.append(cX2SpPxGLmADTKl)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	nUDgc4absePT2xMt = url.replace('/watch.php','/downloads.php')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMALIGHT-PLAY-3rd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"downloadlist"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<strong>(.*?)</strong>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if cX2SpPxGLmADTKl not in HE6iYhkK2T:
				HE6iYhkK2T.append(cX2SpPxGLmADTKl)
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(S7EgasGcYdIo,'url')
	url = LLzkoiPsbBZ+'/search.php?keywords='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return