# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'ALMSTBA'
qBAgzkG9oCL = '_MST_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['الرئيسية','يلا شوت']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==860: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==861: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==862: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==863: Ubud2NhHKRnMTvI5mprQBVqk80 = odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,text)
	elif mode==869: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo+'/indx1/',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,869,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"primary-links"(.*?)</u',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,861)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"list-categories"(.*?)<script',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl.lstrip('/')
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,861)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,i1svWTIM79yezDZXt2gnACupwY=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"home-content"(.*?)"footer"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('"overlay"','"duration"><')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		EaUe8ArOCD = []
		for RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,cX2SpPxGLmADTKl,title in items:
			title = title.strip(' ')
			title = riUKNnOEtVwdj4(title)
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if 'episodes' not in i1svWTIM79yezDZXt2gnACupwY and azhwpE0qmevcFobdRi:
				title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
				title = title.replace('اون لاين',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				if title not in EaUe8ArOCD:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,863,RRx0ri8bETI)
					EaUe8ArOCD.append(title)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,862,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''["']pagination["'](.*?)["']footer["']''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		i1svWTIM79yezDZXt2gnACupwY = 'episodes_pages' if 'episodes' in i1svWTIM79yezDZXt2gnACupwY else 'pages'
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,861,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,i1svWTIM79yezDZXt2gnACupwY)
	else:
		zzhxrZT7u4WJl3R1vU0jCtp = AxTYMhRlfyskNc0X19dvwtS.findall('class="pagination__next.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if zzhxrZT7u4WJl3R1vU0jCtp:
			cX2SpPxGLmADTKl = zzhxrZT7u4WJl3R1vU0jCtp[0]
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة لاحقة',cX2SpPxGLmADTKl,861,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,i1svWTIM79yezDZXt2gnACupwY)
	return
def odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,nRW2P4Ke3z7):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-EPISODES_SEASONS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"episodes-container"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	E7MF9aYlV4Q0 = AxTYMhRlfyskNc0X19dvwtS.findall('"thumbnailUrl":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	RRx0ri8bETI = E7MF9aYlV4Q0[0] if E7MF9aYlV4Q0 else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
	RRx0ri8bETI += '|Referer='+S7EgasGcYdIo
	items = []
	Plc3HUgEvQDiOIrsL4Sm1ZF8M = False
	if j9HbACE1rmuP48NVX6pgQsUwfBWk and not nRW2P4Ke3z7:
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-tab="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for nRW2P4Ke3z7,title in items:
			nRW2P4Ke3z7 = nRW2P4Ke3z7.strip('#')
			if len(items)>1: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,863,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nRW2P4Ke3z7)
			else: Plc3HUgEvQDiOIrsL4Sm1ZF8M = True
	else: Plc3HUgEvQDiOIrsL4Sm1ZF8M = True
	if Plc3HUgEvQDiOIrsL4Sm1ZF8M or not nRW2P4Ke3z7:
		if not nRW2P4Ke3z7: fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"tab-content.*?id="(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		else: fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"tab-content.*?id="'+nRW2P4Ke3z7+'"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if fxgnWRoUO7jNwtJkuB:
			IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('./')
				title = title.replace('</em><span>',WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,862,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu,OIbrTU8tkdvLRlSG9jZhgXoPC = [],[]
	nUDgc4absePT2xMt = url.strip('/')+'/?do=watch'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('iframe src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		OIbrTU8tkdvLRlSG9jZhgXoPC.append(cX2SpPxGLmADTKl)
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-PLAY-2nd')
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		evGVuBpQUEL = AxTYMhRlfyskNc0X19dvwtS.findall('iframe src="(.*?)"',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		evGVuBpQUEL = evGVuBpQUEL[0] if evGVuBpQUEL else cX2SpPxGLmADTKl
		evGVuBpQUEL = riUKNnOEtVwdj4(evGVuBpQUEL)
		if evGVuBpQUEL not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(evGVuBpQUEL)
			LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(evGVuBpQUEL,'name')
			evGVuBpQUEL = evGVuBpQUEL+'?named='+LLzkoiPsbBZ+'__embed'
			dU17fayKLj4kABu.append(evGVuBpQUEL)
	headers = {'Referer':url}
	YDidHrbPsIFGoTAvlwtL = AxTYMhRlfyskNc0X19dvwtS.findall('post_id:(\d+)',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nMe0uhTlSfRgtjbW = S7EgasGcYdIo+'/wp-admin/admin-ajax.php?action=video_info&post_id='+YDidHrbPsIFGoTAvlwtL[0]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nMe0uhTlSfRgtjbW,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMSTBA-PLAY-3rd')
	gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('"src":"(.*?)"',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('\/','/')
		if cX2SpPxGLmADTKl not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(cX2SpPxGLmADTKl)
			LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+LLzkoiPsbBZ+'__watch'
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('"Download" target="_blank" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		if cX2SpPxGLmADTKl not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(cX2SpPxGLmADTKl)
			LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+LLzkoiPsbBZ+'__download'
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return