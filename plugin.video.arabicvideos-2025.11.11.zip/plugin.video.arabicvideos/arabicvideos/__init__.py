# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from MEyOuW8nmK import *
mI6ayKxBvjd4CRthL = w9wfONXUP3(u"࠭ࡉࡏࡋࡗࠫᎅ")
Lj9T2B80zodAvMp7HIsqOyng1 = w9wfONXUP3(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧᎆ")
YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = XjPqWt1BdDk(utdV6CEfRBM)
RyTNClZWG89xSfOs = int(hhiINO8HfTXkUld3pZRqbsB0uyGz)
AAB086Sqz9xc = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(kAz7WRYjrfGm(u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩᎇ"))
AAB086Sqz9xc = AAB086Sqz9xc.replace(qsTZxjmy98KS4O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(lodjqT9n2wA,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
if RyTNClZWG89xSfOs==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶࠻࠶Ꭽ"): Gq2cyWeEkpoZJK = nR0ok9zju84rFUQl1YC(u"ࠩࠣࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪᎈ")+FLRQJnBHTvsXU+W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࠤࡢࠦࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪᎉ")+cjEfQ4VpOPw+pL73X0MYajJQG4n1qgD(u"ࠫࠥࡣࠧᎊ")
else:
	RFSOIJVQv7GyPwfTW8zX2ti3Um = WDg18QHF3rze(utdV6CEfRBM).replace(qFghPAi5yz9Vf3NLwo0nuprl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(oamlxBqLdu4ZM9nQrbIAhS5Pg7,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	RFSOIJVQv7GyPwfTW8zX2ti3Um = RFSOIJVQv7GyPwfTW8zX2ti3Um.replace(so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	RFSOIJVQv7GyPwfTW8zX2ti3Um = RFSOIJVQv7GyPwfTW8zX2ti3Um.replace(NNJKRTY8GlM29ezbCgPiXd,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(NzlAQMRChm8J34urLwcUOn1f,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	Gq2cyWeEkpoZJK = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫᎋ")+AAB086Sqz9xc+GTmHXIZUSdxRhMnqQKkO(u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᎌ")+hhiINO8HfTXkUld3pZRqbsB0uyGz+pYeVwat64v(u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧᎍ")+RFSOIJVQv7GyPwfTW8zX2ti3Um+ba49YvOK2Aw8Uhxt(u"ࠨࠢࡠࠫᎎ")
UO05pib6mcvezR9(jZBtGcdApeKLEkb,Lj9T2B80zodAvMp7HIsqOyng1+b8sk5WyPoz03pXhRx+yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+Gq2cyWeEkpoZJK)
if ba49YvOK2Aw8Uhxt(u"ࠩࡢࠫᎏ") in OZK8LwloB3azFd: FBTypVclJasDRHwI,MNS1KYt8qVU6PrC = OZK8LwloB3azFd.split(Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡣࠬ᎐"),xD9WeoEAsX7)
else: FBTypVclJasDRHwI,MNS1KYt8qVU6PrC = OZK8LwloB3azFd,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
drzqWFkSHD.fFDKeiZkOBhgvld634w79LoR,YK1U4PZlH6MErXStRaVyb3J7hjnG = pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
if FBTypVclJasDRHwI in [bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫ࠶࠭᎑"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠸ࠧ᎒"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭࠳ࠨ᎓"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࠵ࠩ᎔"),pYeVwat64v(u"ࠨ࠷ࠪ᎕"),pbmKZA1w7L4zHjOM(u"ࠩ࠴࠵ࠬ᎖"),GTmHXIZUSdxRhMnqQKkO(u"ࠪ࠵࠷࠭᎗"),YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࠶࠹ࠧ᎘")] and (pbmKZA1w7L4zHjOM(u"ࠬࡇࡄࡅࠩ᎙") in MNS1KYt8qVU6PrC or pL73X0MYajJQG4n1qgD(u"࠭ࡒࡆࡏࡒ࡚ࡊ࠭᎚") in MNS1KYt8qVU6PrC or B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡖࡒࠪ᎛") in MNS1KYt8qVU6PrC or zWBnYSGIatjXVC(u"ࠨࡆࡒ࡛ࡓ࠭᎜") in MNS1KYt8qVU6PrC):
	from erMQXvGoEs import Vve4TQb2KBYpr9OyRLFkzAwq8sS6
	Vve4TQb2KBYpr9OyRLFkzAwq8sS6(OZK8LwloB3azFd,FBTypVclJasDRHwI,MNS1KYt8qVU6PrC)
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭᎝"),utdV6CEfRBM)
	drzqWFkSHD.fFDKeiZkOBhgvld634w79LoR = NFGqKBLtvUZn1S3dau
elif not NNoTxCgkAQyV2hpFOPeRtq70jr4d and RyTNClZWG89xSfOs in [pL73X0MYajJQG4n1qgD(u"࠷࠹࠵Ꭾ"),YzlId3Fs6vpehcbLGj0UaO(u"࠽࠱࠶Ꭿ")]:
	ozc8fP05O4GntlhQgRyCZmeKI3F = str(CC8RbxJ4AHh9rgjTdBsU[w9wfONXUP3(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᎞")])
	mI6ayKxBvjd4CRthL = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡎࡖࡔࡗࠩ᎟") if RyTNClZWG89xSfOs==w9wfONXUP3(u"࠲࠴࠷Ꮀ") else nR0ok9zju84rFUQl1YC(u"ࠬࡓ࠳ࡖࠩᎠ")
	DfGvtP2p17cMEbylmO = mI6ayKxBvjd4CRthL.lower()
	xL93S8G1wJdkPsa = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(zWBnYSGIatjXVC(u"࠭ࡡࡷ࠰ࠪᎡ")+DfGvtP2p17cMEbylmO+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬᎢ")+ozc8fP05O4GntlhQgRyCZmeKI3F)
	YVbC0fFvJRDSZLlc1w7ojzE = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡣࡹ࠲ࠬᎣ")+DfGvtP2p17cMEbylmO+CCWqR3dmtzw6xoIX41(u"ࠩ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬᎤ")+ozc8fP05O4GntlhQgRyCZmeKI3F)
	if xL93S8G1wJdkPsa or YVbC0fFvJRDSZLlc1w7ojzE:
		HHyOcE4DNohvx0MaIJZ1b += nR0ok9zju84rFUQl1YC(u"ࠪࢀࠬᎥ")
		if xL93S8G1wJdkPsa: HHyOcE4DNohvx0MaIJZ1b += zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᎦ")+xL93S8G1wJdkPsa
		if YVbC0fFvJRDSZLlc1w7ojzE: HHyOcE4DNohvx0MaIJZ1b += vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᎧ")+YVbC0fFvJRDSZLlc1w7ojzE
		HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.replace(YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡼࠧࠩᎨ"),rAYDiWlzm9MCU6x0GnROua(u"ࠧࡽࠩᎩ"))
	uMVLxWUA5KqJ0p7vBjrtbI = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(KKCrwPdOgGl(u"ࠨࡣࡹ࠲ࠬᎪ")+DfGvtP2p17cMEbylmO+hWRvZOYtjme9QNnV41u0Mswb(u"ࠩ࠱ࡷࡪࡸࡶࡦࡴࡢࠫᎫ")+ozc8fP05O4GntlhQgRyCZmeKI3F)
	if uMVLxWUA5KqJ0p7vBjrtbI:
		IeSbrUfkBE3HNDl19chvnaZM = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭Ꭼ"),HHyOcE4DNohvx0MaIJZ1b,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		HHyOcE4DNohvx0MaIJZ1b = HHyOcE4DNohvx0MaIJZ1b.replace(IeSbrUfkBE3HNDl19chvnaZM[nUaVQsoA6EXcK4Odht5wCge0J8Pib],uMVLxWUA5KqJ0p7vBjrtbI)
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(HHyOcE4DNohvx0MaIJZ1b,mI6ayKxBvjd4CRthL,YYTAkfz3NaQrLuCyRE)
else:
	import YnWpIJVfFz
	try: YnWpIJVfFz.MV0nhLys81NdkOxJfRlAtqjQI(YYTAkfz3NaQrLuCyRE,X3cxeAQbjSnkK2sY9ZgJB8ma,HHyOcE4DNohvx0MaIJZ1b,hhiINO8HfTXkUld3pZRqbsB0uyGz,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,W0d8hJxSvNlqokHnugMU,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU,RyTNClZWG89xSfOs,FBTypVclJasDRHwI,MNS1KYt8qVU6PrC,AAB086Sqz9xc)
	except Exception as kXdvW6bDsJB35o4h98Q: YK1U4PZlH6MErXStRaVyb3J7hjnG = VGgFQrd6JwjRCmp2aPAos0ycLkv.format_exc()
eaVguQqSdFGZWBKjt6zmE82Y(drzqWFkSHD.fFDKeiZkOBhgvld634w79LoR,YK1U4PZlH6MErXStRaVyb3J7hjnG)