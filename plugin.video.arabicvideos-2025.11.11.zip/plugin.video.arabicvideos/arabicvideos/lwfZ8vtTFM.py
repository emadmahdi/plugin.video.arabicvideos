# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'MOVS4U'
qBAgzkG9oCL = '_M4U_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['انواع افلام','جودات افلام']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==380: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==381: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==382: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==383: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==389: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,389,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المميزة',S7EgasGcYdIo,381,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'الجانبية',S7EgasGcYdIo,381,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'sider')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVS4U-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<header>.*?<h2>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for u74UPEicpBdq32C in range(len(items)):
		title = items[u74UPEicpBdq32C]
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,S7EgasGcYdIo,381,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'latest'+str(u74UPEicpBdq32C))
	IxdmfnvhCA8Bc9ZlQ45oiqN = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="menu"(.*?)id="contenedor"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN += vvuraxgW7YLIZ4hU0MbCt[0]
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="sidebar(.*?)aside',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN += vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	hKlkUJZEvLmeDXgO6Gs50MnYb = True
	for cX2SpPxGLmADTKl,title in items:
		title = riUKNnOEtVwdj4(title)
		if title=='الأعلى مشاهدة':
			if hKlkUJZEvLmeDXgO6Gs50MnYb:
				title = 'الافلام '+title
				hKlkUJZEvLmeDXgO6Gs50MnYb = False
			else: title = 'المسلسلات '+title
		if title not in kCIESuy4j5mVLZYtG9vDNnb7:
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,381)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type):
	IxdmfnvhCA8Bc9ZlQ45oiqN,items = [],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVS4U-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if type=='search':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="search-page"(.*?)class="sidebar',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif type=='sider':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="widget(.*?)class="widget',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		rgk9UAjhMTxb4WItzZRsX2YEq = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		CBL4OQVtWbMAycUGl7Ex2SKZF,mjAR4Z1aeVDYbB,GjC4atkJLwlTpsI = zip(*rgk9UAjhMTxb4WItzZRsX2YEq)
		items = zip(mjAR4Z1aeVDYbB,CBL4OQVtWbMAycUGl7Ex2SKZF,GjC4atkJLwlTpsI)
	elif type=='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="slider-movies-tvshows"(.*?)<header>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif 'latest' in type:
		u74UPEicpBdq32C = int(type[-1:])
		R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('<header>','<end><start>')
		R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('<div class="sidebar','<end><div class="sidebar')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<start>(.*?)<end>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[u74UPEicpBdq32C]
		if u74UPEicpBdq32C==2: items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="content"(.*?)class="(pagination|sidebar)',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0][0]
			if '/collection/' in url:
				items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			elif '/quality/' in url:
				items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items and IxdmfnvhCA8Bc9ZlQ45oiqN:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		if 'serie' in title:
			title = AxTYMhRlfyskNc0X19dvwtS.findall('^(.*?)<.*?serie">(.*?)<',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			title = title[0][1]
			if title in EaUe8ArOCD: continue
			EaUe8ArOCD.append(title)
			title = '_MOD_'+title
		uoH6T37WPfCdv8JLnYZjK2r = AxTYMhRlfyskNc0X19dvwtS.findall('^(.*?)<',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if uoH6T37WPfCdv8JLnYZjK2r: title = uoH6T37WPfCdv8JLnYZjK2r[0]
		title = riUKNnOEtVwdj4(title)
		if '/tvshows/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,383,RRx0ri8bETI)
		elif '/episodes/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,383,RRx0ri8bETI)
		elif '/seasons/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,383,RRx0ri8bETI)
		elif '/collection/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,381,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,382,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		Fn2gkcvV13bJ7mf = vvuraxgW7YLIZ4hU0MbCt[0][0]
		m9vg4jhNMwX = vvuraxgW7YLIZ4hU0MbCt[0][1]
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0][2]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("href='(.*?)'.*?>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O or title==m9vg4jhNMwX: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,381,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,type)
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('/page/'+title+'/','/page/'+m9vg4jhNMwX+'/')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'اخر صفحة '+m9vg4jhNMwX,cX2SpPxGLmADTKl,381,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,type)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVS4U-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('class="C rated".*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd,False):
		w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+'المسلسل للكبار والمبرمج منعه',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('''class='item'><a href="(.*?)"''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if nUDgc4absePT2xMt:
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[1]
			SnpFbUovmMwfXalIGRNys6zYZtj(nUDgc4absePT2xMt)
			return
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''class='episodios'(.*?)id="cast"''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for RRx0ri8bETI,azhwpE0qmevcFobdRi,cX2SpPxGLmADTKl,name in items:
			title = azhwpE0qmevcFobdRi+' : '+name+' الحلقة'
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,382)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVS4U-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('class="C rated".*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd): return
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0][0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("data-url='(.*?)'.*?class='server'>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="remodal"(.*?)class="remodal-close"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return