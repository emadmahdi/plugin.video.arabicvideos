﻿# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,pZcuJiXwom08arE2De):
	if pZcuJiXwom08arE2De==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	if t5fhagjUGXk0ynOlJWeAb==1:
		jHlVEeTIoi9CQa4 = vRVl0MpXZDwAYB4ag68nc.getCurrentWindowDialogId()
		PHdfx5e6BjKlzFqGUJa1LEi = vRVl0MpXZDwAYB4ag68nc.Window(jHlVEeTIoi9CQa4)
		pZcuJiXwom08arE2De = X1gWZ9KMSF6jxE2Vsv(pZcuJiXwom08arE2De)
		PHdfx5e6BjKlzFqGUJa1LEi.getControl(311).setLabel(pZcuJiXwom08arE2De)
	if t5fhagjUGXk0ynOlJWeAb==0:
		YYTAkfz3NaQrLuCyRE='X'
		if fOohwvakqi29cx0l3yt5mzrAGpEg: yJ6O3AuhgdWPlqptjaVCIG2wX01 = isinstance(pZcuJiXwom08arE2De,str)
		else: yJ6O3AuhgdWPlqptjaVCIG2wX01 = isinstance(pZcuJiXwom08arE2De,unicode)
		if yJ6O3AuhgdWPlqptjaVCIG2wX01==True: YYTAkfz3NaQrLuCyRE='U'
		w1HcBZaK9DjWJCsyNn07l=str(type(pZcuJiXwom08arE2De))+WRsuxHTjDgYCIpoMQzLFAtS8rikP+pZcuJiXwom08arE2De+WRsuxHTjDgYCIpoMQzLFAtS8rikP+YYTAkfz3NaQrLuCyRE+WRsuxHTjDgYCIpoMQzLFAtS8rikP
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(0,len(pZcuJiXwom08arE2De),1):
			w1HcBZaK9DjWJCsyNn07l += hex(ord(pZcuJiXwom08arE2De[uKFGBAEj9tX1e03cyHOMUNhQl4r6])).replace('0x',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)+WRsuxHTjDgYCIpoMQzLFAtS8rikP
		pZcuJiXwom08arE2De = X1gWZ9KMSF6jxE2Vsv(pZcuJiXwom08arE2De)
		YYTAkfz3NaQrLuCyRE='X'
		if fOohwvakqi29cx0l3yt5mzrAGpEg: yJ6O3AuhgdWPlqptjaVCIG2wX01 = isinstance(pZcuJiXwom08arE2De, str)
		else: yJ6O3AuhgdWPlqptjaVCIG2wX01 = isinstance(pZcuJiXwom08arE2De, unicode)
		if yJ6O3AuhgdWPlqptjaVCIG2wX01==True: YYTAkfz3NaQrLuCyRE='U'
		ggFUbWzOC5ZBVQmvhd3LRq7ADJ=str(type(pZcuJiXwom08arE2De))+WRsuxHTjDgYCIpoMQzLFAtS8rikP+pZcuJiXwom08arE2De+WRsuxHTjDgYCIpoMQzLFAtS8rikP+YYTAkfz3NaQrLuCyRE+WRsuxHTjDgYCIpoMQzLFAtS8rikP
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(0,len(pZcuJiXwom08arE2De),1):
			ggFUbWzOC5ZBVQmvhd3LRq7ADJ += hex(ord(pZcuJiXwom08arE2De[uKFGBAEj9tX1e03cyHOMUNhQl4r6])).replace('0x',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)+WRsuxHTjDgYCIpoMQzLFAtS8rikP
	return