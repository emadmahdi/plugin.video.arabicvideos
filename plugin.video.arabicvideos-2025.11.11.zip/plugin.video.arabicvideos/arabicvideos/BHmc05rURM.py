# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
headers = { 'User-Agent' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
mI6ayKxBvjd4CRthL = 'AKOAMCAM'
qBAgzkG9oCL = '_AKC_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['مصارعة']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==350: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==351: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==352: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==353: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==354: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'FILTERS___'+text)
	elif mode==355: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'CATEGORIES___'+text)
	elif mode==356: Ubud2NhHKRnMTvI5mprQBVqk80 = HghVZS5Ud8O6uzA0yFDTKJXqsMx(url)
	elif mode==357: Ubud2NhHKRnMTvI5mprQBVqk80 = arxBH0dTFuoj4EO1(url)
	elif mode==359: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+oamlxBqLdu4ZM9nQrbIAhS5Pg7+'هذا الموقع مغلق'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,8)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,359,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',S7EgasGcYdIo,356)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',S7EgasGcYdIo,357)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-MENU-1st')
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('recently-container.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if nUDgc4absePT2xMt: nUDgc4absePT2xMt = nUDgc4absePT2xMt[0]
	else: nUDgc4absePT2xMt = S7EgasGcYdIo
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'اضيف حديثا',nUDgc4absePT2xMt,351)
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('@id":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if nUDgc4absePT2xMt: nUDgc4absePT2xMt = nUDgc4absePT2xMt[0]
	else: nUDgc4absePT2xMt = S7EgasGcYdIo
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المميزة',nUDgc4absePT2xMt,351,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-categories-list(.*?)main-categories-list',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?class="font.*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,351)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="categories-box(.*?)<footer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
			if title not in kCIESuy4j5mVLZYtG9vDNnb7: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,351)
	return R8AE9e4mYxVhusL3Q
def HghVZS5Ud8O6uzA0yFDTKJXqsMx(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="menu(.*?)<nav',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?text">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7:
				title = title+' مصنفة'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,355)
		if website==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return R8AE9e4mYxVhusL3Q
def arxBH0dTFuoj4EO1(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="menu(.*?)<nav',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?text">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7:
				title = title+' مفلترة'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,354)
		if website==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(RFowY7JrTPs8c5m02ydD1VgbeBup3N,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('swiper-container(.*?)swiper-button-prev',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="container"(.*?)main-footer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		EaUe8ArOCD = []
		for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|الحلقه) \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if azhwpE0qmevcFobdRi:
					title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
					if title not in EaUe8ArOCD:
						w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,352,RRx0ri8bETI)
						EaUe8ArOCD.append(title)
			elif 'مسلسل' in title:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,352,RRx0ri8bETI)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,353,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pagination(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href=["\'](.*?)["\'].*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,351)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo + '/?s='+ej9gRJkD6KGTcf
	Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAMCAM-EPISODES-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('text-white">الحلقات(.*?)<header',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		rhVCfIQyOJ = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in rhVCfIQyOJ:
			if 'الحلقة' in title or 'الحلقه' in title: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,353,RRx0ri8bETI)
	else:
		RRx0ri8bETI = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel('ListItem.Icon')
		if R8AE9e4mYxVhusL3Q.count('<title>')>1: title = AxTYMhRlfyskNc0X19dvwtS.findall('<title>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[1]
		else: title = 'رابط التشغيل'
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,url,353,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	CBL4OQVtWbMAycUGl7Ex2SKZF,GjC4atkJLwlTpsI = [],[]
	GyqzSBL7CwklWxfRD43UuYFHN = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-PLAY-1st')
	R8AE9e4mYxVhusL3Q = GyqzSBL7CwklWxfRD43UuYFHN.content
	ccHBj2aGoTKM5DZLv71U0CO = AxTYMhRlfyskNc0X19dvwtS.findall('post_id=(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if ccHBj2aGoTKM5DZLv71U0CO:
		ccHBj2aGoTKM5DZLv71U0CO = ccHBj2aGoTKM5DZLv71U0CO[0]
		headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':ccHBj2aGoTKM5DZLv71U0CO}
		nUDgc4absePT2xMt = S7EgasGcYdIo+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		ffp6bg0HV4AhuPX = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'POST',nUDgc4absePT2xMt,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-PLAY-1st')
		gwiPcfVU0T4qHMDF3Wdeh7YK = ffp6bg0HV4AhuPX.content
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-server="(.*?)".*?class="text">(.*?)<',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for QYWvDSNgqBiRaAdn,name in items:
			cX2SpPxGLmADTKl = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?postid='+ccHBj2aGoTKM5DZLv71U0CO+'&serverid='+QYWvDSNgqBiRaAdn+'?named='+name+'__watch'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			GjC4atkJLwlTpsI.append(name)
		nUDgc4absePT2xMt = S7EgasGcYdIo+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		ffp6bg0HV4AhuPX = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'POST',nUDgc4absePT2xMt,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAMCAM-PLAY-1st')
		gwiPcfVU0T4qHMDF3Wdeh7YK = ffp6bg0HV4AhuPX.content
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?class="text">(.*?)<',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			GjC4atkJLwlTpsI.append(title)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	agsNp4VJm8d3e = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='CATEGORIES':
		if agsNp4VJm8d3e[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(agsNp4VJm8d3e[0:-1])):
			if agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		nUDgc4absePT2xMt = url+'?'+pbIlAP6KNW
	elif type=='FILTERS':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'?'+J41jTEGvedKYQgclAiUuPxF
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها',nUDgc4absePT2xMt,351,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',nUDgc4absePT2xMt,351,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<form id(.*?)</form>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	dict = {}
	for CCkP7yi8aglTqbDOdBjRWNpco,name,IxdmfnvhCA8Bc9ZlQ45oiqN in i2KVkE3TFNIGfymrpJA:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<option(.*?)>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='CATEGORIES':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<=1:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: ENDRjPGicXYFvpVs3xk5uSg6y(nUDgc4absePT2xMt)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'CATEGORIES___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,351,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,355,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='FILTERS':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع : '+name,nUDgc4absePT2xMt,354,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			if 'value' not in value: value = HHvPeCLzN1fIWDStR
			else: value = AxTYMhRlfyskNc0X19dvwtS.findall('"(.*?)"',value,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' : '#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' : '+name
			if type=='FILTERS': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,354,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='CATEGORIES' and agsNp4VJm8d3e[-2]+'=' in gjOp9yI3iS:
				pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'all')
				jYfvU9egTX62nrukVcoKEAyq = url+'?'+pbIlAP6KNW
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,351,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,355,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	iuECgXkw3pcy1FAvK96G = ['cat','genre','release-year','quality','orderby']
	for key in iuECgXkw3pcy1FAvK96G:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd