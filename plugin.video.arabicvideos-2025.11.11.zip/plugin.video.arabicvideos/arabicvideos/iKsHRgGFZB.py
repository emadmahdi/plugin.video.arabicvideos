# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'SHAHID4U2'
qBAgzkG9oCL = '_SH2_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
headers = {'User-Agent':YwSBWkv2f3Us(True)}
kCIESuy4j5mVLZYtG9vDNnb7 = []
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==1090: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==1091: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==1092: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==1093: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url,text)
	elif mode==1094: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'FULL_FILTER___'+text)
	elif mode==1095: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'DEFINED_FILTER___'+text)
	elif mode==1099: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = S7EgasGcYdIo
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1099,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',GGRexoVTLjusn6q,1095)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',GGRexoVTLjusn6q,1094)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'المميزة',GGRexoVTLjusn6q,1091,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"main-menu"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+cX2SpPxGLmADTKl
			if 'netflix' in cX2SpPxGLmADTKl: title = 'نيتفلكس'
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1091)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,gV1lKIhwSm0GQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs: gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt,items,EaUe8ArOCD = [],[],[]
	if gV1lKIhwSm0GQ=='featured': vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"Slides--Main"(.*?)"filterTabs"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"BlocksHolder"(.*?)"pagination"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: return
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?data-src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
		if 'WWE' in title: continue
		if 'javascript' in cX2SpPxGLmADTKl: continue
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
		title = riUKNnOEtVwdj4(title)
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if '/film/' in cX2SpPxGLmADTKl or 'فيلم' in cX2SpPxGLmADTKl or any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1092,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1093,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/actor/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1091,RRx0ri8bETI)
		elif '/series/' in cX2SpPxGLmADTKl and '/list' not in url:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'/list'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1091,RRx0ri8bETI)
		elif '/list' in url and 'حلقة' in title:
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1092,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1093,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt and not gV1lKIhwSm0GQ:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<li>.*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			if title: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,1091,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,gV1lKIhwSm0GQ)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url,aa8KmPLfiyvUE):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="w-100(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="EpisodesList"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		AmQIl2Eqdr8J = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		urFf0wUIE8N = AmQIl2Eqdr8J.count('/season/')+AmQIl2Eqdr8J.count('/series/')
		NhmZs1Eda04QYrfz3 = AmQIl2Eqdr8J.count('href')-urFf0wUIE8N
		if len(vvuraxgW7YLIZ4hU0MbCt)==H3OKMjDG1evnl4Ruiz:
			OGjAClxERLDgkbi0Sd6wr = vvuraxgW7YLIZ4hU0MbCt[xD9WeoEAsX7]
			anipTRb3owqj1DUx = OGjAClxERLDgkbi0Sd6wr.count('/season/')+OGjAClxERLDgkbi0Sd6wr.count('/series/')
			ttsM8uKYIJgjfLN6nmw3aH = OGjAClxERLDgkbi0Sd6wr.count('href=')-anipTRb3owqj1DUx
		else: OGjAClxERLDgkbi0Sd6wr,anipTRb3owqj1DUx,ttsM8uKYIJgjfLN6nmw3aH = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib
		IxdmfnvhCA8Bc9ZlQ45oiqN = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if not aa8KmPLfiyvUE:
			if urFf0wUIE8N>xD9WeoEAsX7: IxdmfnvhCA8Bc9ZlQ45oiqN = AmQIl2Eqdr8J
			elif anipTRb3owqj1DUx>xD9WeoEAsX7: IxdmfnvhCA8Bc9ZlQ45oiqN = OGjAClxERLDgkbi0Sd6wr
		if not IxdmfnvhCA8Bc9ZlQ45oiqN:
			if NhmZs1Eda04QYrfz3: IxdmfnvhCA8Bc9ZlQ45oiqN = AmQIl2Eqdr8J
			elif ttsM8uKYIJgjfLN6nmw3aH: IxdmfnvhCA8Bc9ZlQ45oiqN = OGjAClxERLDgkbi0Sd6wr
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)<.*?<em>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,KK59iLYwJ6cWfItqyBjGRoF,uoH6T37WPfCdv8JLnYZjK2r in items:
			title = KK59iLYwJ6cWfItqyBjGRoF+WRsuxHTjDgYCIpoMQzLFAtS8rikP+uoH6T37WPfCdv8JLnYZjK2r
			if '/season/' not in cX2SpPxGLmADTKl and '/series/' not in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1092)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1093,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'season')
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	dU17fayKLj4kABu,MEek23FnTZBc = [],[]
	dGDEUyIlgQ8M0ZH = AxTYMhRlfyskNc0X19dvwtS.findall('class="watch" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	uK620tEb5aNp = AxTYMhRlfyskNc0X19dvwtS.findall('class="download" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if dGDEUyIlgQ8M0ZH:
		dGDEUyIlgQ8M0ZH = dGDEUyIlgQ8M0ZH[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',dGDEUyIlgQ8M0ZH,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-PLAY-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"watch"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('data-watch="(.*?)".*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl in MEek23FnTZBc: continue
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
				MEek23FnTZBc.append(cX2SpPxGLmADTKl)
	if uK620tEb5aNp:
		uK620tEb5aNp = uK620tEb5aNp[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',uK620tEb5aNp,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-PLAY-3rd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"DownList"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<quality>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl in MEek23FnTZBc: continue
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
				MEek23FnTZBc.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search:
		search = TwDBf3QbKOnrmd5u9()
		if not search: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return
def RKFfhG6MsCPv8BrNUpzo7d9gX(url):
	url = url.split('/smartemadfilter?')[0]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHID4U2-GET_FILTERS_BLOCKS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	i2KVkE3TFNIGfymrpJA = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('adv-filter(.*?)shows-container',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		XXF5kafMOKZnCEwVxL8dWQpicYgm4,cclJEkZuLNn7r3FOWwiGbATU2V,GtnfmdqIOijegYu = zip(*i2KVkE3TFNIGfymrpJA)
		i2KVkE3TFNIGfymrpJA = zip(cclJEkZuLNn7r3FOWwiGbATU2V,XXF5kafMOKZnCEwVxL8dWQpicYgm4,GtnfmdqIOijegYu)
	return i2KVkE3TFNIGfymrpJA
def vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN):
	items = AxTYMhRlfyskNc0X19dvwtS.findall('value="(.*?)".*?>\s*(.*?)\s*<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return items
def nFtcOfK8WPTVSGyvrIEXpU1g07zodM(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	VChIfEZU37zqWGnL = url.split('/smartemadfilter?')[0]
	kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	url = url.replace(VChIfEZU37zqWGnL,kkzeVtyGuvFbsDNpYgXLBUZrO6)
	url = url.replace('/smartemadfilter?','/?')
	return url
lVYsPXjJ40EwWgn1QBNuk = ['quality','year','genre','category']
Lc4lhNBeQpM3 = ['category','genre','year']
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='DEFINED_FILTER':
		if Lc4lhNBeQpM3[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = Lc4lhNBeQpM3[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(Lc4lhNBeQpM3[0:-1])):
			if Lc4lhNBeQpM3[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = Lc4lhNBeQpM3[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
	elif type=='FULL_FILTER':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'/smartemadfilter?'+J41jTEGvedKYQgclAiUuPxF
		jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها ',jYfvU9egTX62nrukVcoKEAyq,1091)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',jYfvU9egTX62nrukVcoKEAyq,1091)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	i2KVkE3TFNIGfymrpJA = RKFfhG6MsCPv8BrNUpzo7d9gX(url)
	dict = {}
	for name,CCkP7yi8aglTqbDOdBjRWNpco,IxdmfnvhCA8Bc9ZlQ45oiqN in i2KVkE3TFNIGfymrpJA:
		name = name.replace('كل ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		items = vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='DEFINED_FILTER':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<2:
				if CCkP7yi8aglTqbDOdBjRWNpco==Lc4lhNBeQpM3[-1]:
					jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
					ENDRjPGicXYFvpVs3xk5uSg6y(jYfvU9egTX62nrukVcoKEAyq)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'DEFINED_FILTER___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				if CCkP7yi8aglTqbDOdBjRWNpco==Lc4lhNBeQpM3[-1]:
					jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',jYfvU9egTX62nrukVcoKEAyq,1091)
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,1095,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='FULL_FILTER':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع :'+name,nUDgc4absePT2xMt,1094,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if value=='196533': HHvPeCLzN1fIWDStR = 'أفلام نيتفلكس'
			elif value=='196531': HHvPeCLzN1fIWDStR = 'مسلسلات نيتفلكس'
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' :'#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' :'+name
			if type=='FULL_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,1094,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='DEFINED_FILTER' and Lc4lhNBeQpM3[-2]+'=' in gjOp9yI3iS:
				pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'modified_filters')
				nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
				jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,1091)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,1095,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.replace('=&','=0&')
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for key in lVYsPXjJ40EwWgn1QBNuk:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if '%' not in value: value = pmhHwIbkcrRJeyzuxPUSDGnqM92(value)
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.replace('=0','=')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd