# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'CIMA4U'
headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
qBAgzkG9oCL = '_C4U_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==420: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==421: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==422: Ubud2NhHKRnMTvI5mprQBVqk80 = tvK8EfHFqA(url)
	elif mode==423: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==424: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==427: Ubud2NhHKRnMTvI5mprQBVqk80 = Gbek8c4fX1WoFKTdJtrBqsUVZzav(url)
	elif mode==429: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GGRexoVTLjusn6q = GGRexoVTLjusn6q[0].strip('/')
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(GGRexoVTLjusn6q,'url')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,429,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',GGRexoVTLjusn6q,425)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',GGRexoVTLjusn6q,424)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'الرئيسية',GGRexoVTLjusn6q,421)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('NavigationMenu(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="*(.*?)"*>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if '/actors' in cX2SpPxGLmADTKl: title = 'أفلام النجوم'
		elif '/netflix' in cX2SpPxGLmADTKl: title = 'أفلام ومسلسلات نيتفلكس'
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,421)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'قائمة تفصيلية',GGRexoVTLjusn6q,427)
	return
def Gbek8c4fX1WoFKTdJtrBqsUVZzav(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('FilteringTitle(.*?)PageTitle',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for PtATpb3YenChf5,id,cX2SpPxGLmADTKl,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if 'netflix-movies' in cX2SpPxGLmADTKl: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in cX2SpPxGLmADTKl: title = 'مسلسلات نيتفلكس'
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,PtATpb3YenChf5+'|'+id)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,gV1lKIhwSm0GQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if not gV1lKIhwSm0GQ or '|' in gV1lKIhwSm0GQ:
		if '|' not in gV1lKIhwSm0GQ: VtdBuGnAYI5HFzSgjixqXrRW1yM62 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		else: VtdBuGnAYI5HFzSgjixqXrRW1yM62 = '/archive/'+gV1lKIhwSm0GQ
		B387pSDQlZvhYs9OWVXzPtfLugw = False
		if 'PinSlider' in R8AE9e4mYxVhusL3Q:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'المميزة',url,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
			B387pSDQlZvhYs9OWVXzPtfLugw = True
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('PageTitle(.*?)PageContent',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			Lhi71X39bHs6zEZ4ypIaGewVJ = vvuraxgW7YLIZ4hU0MbCt[0]
			llN8cqbtajQJprPCKLnWVxXB = AxTYMhRlfyskNc0X19dvwtS.findall('data-tab="(.*?)".*?<span>(.*?)<',Lhi71X39bHs6zEZ4ypIaGewVJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for a6NJRLAGjy0KnQTVC,uoH6T37WPfCdv8JLnYZjK2r in llN8cqbtajQJprPCKLnWVxXB:
				evGVuBpQUEL = GGRexoVTLjusn6q+'/ajaxcenter/action/HomepageLoader/tab/'+a6NJRLAGjy0KnQTVC+VtdBuGnAYI5HFzSgjixqXrRW1yM62+'/'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL,421)
				B387pSDQlZvhYs9OWVXzPtfLugw = True
		if B387pSDQlZvhYs9OWVXzPtfLugw: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	if gV1lKIhwSm0GQ=='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('PinSlider(.*?)MultiFilter',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('PinSlider(.*?)PageTitle',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		else: IxdmfnvhCA8Bc9ZlQ45oiqN = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
	elif '/filter/' in url:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('PageContent(.*?)class="*pagination"*',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	elif '/actors' in url:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('PageContent(.*?)class="*pagination"*',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('Cima4uBlocks(.*?)</li></ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		else: IxdmfnvhCA8Bc9ZlQ45oiqN = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		if not title: continue
		if '?news=' in cX2SpPxGLmADTKl: continue
		title = title.replace('مشاهدة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = riUKNnOEtVwdj4(title)
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) حلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if azhwpE0qmevcFobdRi and 'حلقة' in title:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,422,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/actor/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,421,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,422,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt and gV1lKIhwSm0GQ!='featured':
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			title = title.replace('الصفحة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,421)
	zGyAMhFIjxNdlb6ZeX54 = AxTYMhRlfyskNc0X19dvwtS.findall('</li><a href="(.*?)".*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if zGyAMhFIjxNdlb6ZeX54:
		cX2SpPxGLmADTKl,title = zGyAMhFIjxNdlb6ZeX54[0]
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,421)
	return
def tvK8EfHFqA(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-SEASONS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="WatchNow".*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		url = vvuraxgW7YLIZ4hU0MbCt[0]
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-SEASONS-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('SeasonsSections(.*?)</div></div></div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if '/tag/' in url or '/actor' in url:
		ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif vvuraxgW7YLIZ4hU0MbCt:
		RRx0ri8bETI = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel('ListItem.Thumb')
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("href='(.*?)'>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		T3ZrOgeqFlbonv9WhHajC0LVI = ['مسلسل','موسم','برنامج','حلقة']
		for cX2SpPxGLmADTKl,title in items:
			if any(value in title for value in T3ZrOgeqFlbonv9WhHajC0LVI):
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,423,RRx0ri8bETI)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,426,RRx0ri8bETI)
	else: SnpFbUovmMwfXalIGRNys6zYZtj(url)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	RRx0ri8bETI = AxTYMhRlfyskNc0X19dvwtS.findall('"background-image:url\((.*?)\)',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if RRx0ri8bETI: RRx0ri8bETI = RRx0ri8bETI[0]
	else: RRx0ri8bETI = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	T2azjZYALKnvdeSg7BG = AxTYMhRlfyskNc0X19dvwtS.findall('EpisodesSection(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if T2azjZYALKnvdeSg7BG:
		IxdmfnvhCA8Bc9ZlQ45oiqN = T2azjZYALKnvdeSg7BG[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,azhwpE0qmevcFobdRi in items:
			title = title+WRsuxHTjDgYCIpoMQzLFAtS8rikP+azhwpE0qmevcFobdRi
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,426,RRx0ri8bETI)
	else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+'رابط التشغيل',url,426,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	jxs8Wyez5ai4FR = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.url
	if hT1JIgqPQsUOZp5tjCX0E: jxs8Wyez5ai4FR = jxs8Wyez5ai4FR.encode(RMGz7OiD1e30P)
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(jxs8Wyez5ai4FR,'url')
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('WatchSection(.*?)</div></div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-link="(.*?)".*? />(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for QYWvDSNgqBiRaAdn,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if 'myvid' in title.lower(): title = 'خاص '+title
			cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/structure/server.php?id='+QYWvDSNgqBiRaAdn+'?named='+title+'__watch'
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('DownloadServers(.*?)</div></div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*? />(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if 'myvid' in title.lower(): uoH6T37WPfCdv8JLnYZjK2r = '__خاص'
			else: uoH6T37WPfCdv8JLnYZjK2r = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'+uoH6T37WPfCdv8JLnYZjK2r
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/Search?q='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return
def RKFfhG6MsCPv8BrNUpzo7d9gX(url):
	if 'smartemadfilter' not in url: url = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('MultiFilter(.*?)PageTitle',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return i2KVkE3TFNIGfymrpJA
def vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN):
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-id="(.*?)".*?</div>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return items
def M0M1GZXwzE(url):
	VChIfEZU37zqWGnL = url.split('/smartemadfilter?')[0]
	kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	url = url.replace(VChIfEZU37zqWGnL,kkzeVtyGuvFbsDNpYgXLBUZrO6)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
agsNp4VJm8d3e = ['category','types','release-year']
iuECgXkw3pcy1FAvK96G = ['Quality','release-year','types','category']
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global agsNp4VJm8d3e
			agsNp4VJm8d3e = agsNp4VJm8d3e[1:]
		if agsNp4VJm8d3e[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(agsNp4VJm8d3e[0:-1])):
			if agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
	elif type=='ALL_ITEMS_FILTER':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'/smartemadfilter?'+J41jTEGvedKYQgclAiUuPxF
		nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها ',nUDgc4absePT2xMt,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',nUDgc4absePT2xMt,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	i2KVkE3TFNIGfymrpJA = RKFfhG6MsCPv8BrNUpzo7d9gX(url)
	dict = {}
	for name,IxdmfnvhCA8Bc9ZlQ45oiqN,CCkP7yi8aglTqbDOdBjRWNpco in i2KVkE3TFNIGfymrpJA:
		if '/category/' in url and CCkP7yi8aglTqbDOdBjRWNpco=='category': continue
		name = name.replace('--',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		items = vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='SPECIFIED_FILTER':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<2:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]:
					url = M0M1GZXwzE(url)
					ENDRjPGicXYFvpVs3xk5uSg6y(url)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'SPECIFIED_FILTER___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,425,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='ALL_ITEMS_FILTER':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع :'+name,nUDgc4absePT2xMt,424,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if value=='196533': HHvPeCLzN1fIWDStR = 'أفلام نيتفلكس'
			elif value=='196531': HHvPeCLzN1fIWDStR = 'مسلسلات نيتفلكس'
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' :'#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' :'+name
			if type=='ALL_ITEMS_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,424,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='SPECIFIED_FILTER' and agsNp4VJm8d3e[-2]+'=' in gjOp9yI3iS:
				pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'modified_filters')
				jYfvU9egTX62nrukVcoKEAyq = url+'/smartemadfilter?'+pbIlAP6KNW
				jYfvU9egTX62nrukVcoKEAyq = M0M1GZXwzE(jYfvU9egTX62nrukVcoKEAyq)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,421,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,425,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.replace('=&','=0&')
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for key in iuECgXkw3pcy1FAvK96G:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if '%' not in value: value = pmhHwIbkcrRJeyzuxPUSDGnqM92(value)
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.replace('=0','=')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd