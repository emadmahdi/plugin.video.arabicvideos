# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'MOVIZLAND'
headers = { 'User-Agent' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
qBAgzkG9oCL = '_MVZ_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
talv2Us5Kn1 = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][1]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==180: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==181: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==182: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==183: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==188: Ubud2NhHKRnMTvI5mprQBVqk80 = BB9hWCvFx1()
	elif mode==189: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def BB9hWCvFx1():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,message)
	return
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,189,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'بوكس اوفيس موفيز لاند',S7EgasGcYdIo,181,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'box-office')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'أحدث الافلام',S7EgasGcYdIo,181,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'latest-movies')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'تليفزيون موفيز لاند',S7EgasGcYdIo,181,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'tv')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'الاكثر مشاهدة',S7EgasGcYdIo,181,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'top-views')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'أقوى الافلام الحالية',S7EgasGcYdIo,181,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'top-movies')
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-MENU-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<h2><a href="(.*?)".*?">(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,181)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	elif type=='box-office': IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	elif type=='top-movies': IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('btn-2-overlay(.*?)<style>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	elif type=='top-views': IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	elif type=='tv': IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	else: IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
	if type in ['top-views','top-movies']:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: items = AxTYMhRlfyskNc0X19dvwtS.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	co0nsmRGuKp1HJaQN = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for RRx0ri8bETI,fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu,AtMlgVZSip0NmhwaLKOX2enqI5Q in items:
		if type in ['top-views','top-movies']:
			RRx0ri8bETI,cX2SpPxGLmADTKl,evGVuBpQUEL,title = RRx0ri8bETI,fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu,AtMlgVZSip0NmhwaLKOX2enqI5Q
		else: RRx0ri8bETI,title,cX2SpPxGLmADTKl,evGVuBpQUEL = RRx0ri8bETI,fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu,AtMlgVZSip0NmhwaLKOX2enqI5Q
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl)
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('?view=true',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = riUKNnOEtVwdj4(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('بجوده ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'الحلقة' in title or 'الحلقه' in title:
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|الحلقه) \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if azhwpE0qmevcFobdRi:
				title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
				if title not in EaUe8ArOCD:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,183,RRx0ri8bETI)
					EaUe8ArOCD.append(title)
		elif any(value in title for value in co0nsmRGuKp1HJaQN):
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl + '?servers=' + evGVuBpQUEL
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,182,RRx0ri8bETI)
		else:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl + '?servers=' + evGVuBpQUEL
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,183,RRx0ri8bETI)
	if type==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('\n<li><a href="(.*?)".*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			title = title.replace('الصفحة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,181)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	nUDgc4absePT2xMt = url.split('?servers=')[0]
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-EPISODES-1st')
	IxdmfnvhCA8Bc9ZlQ45oiqN = AxTYMhRlfyskNc0X19dvwtS.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	title,G20Fvhu5p3,RRx0ri8bETI = IxdmfnvhCA8Bc9ZlQ45oiqN[0]
	name = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="episodesNumbers"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl in items:
			cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl)
			title = AxTYMhRlfyskNc0X19dvwtS.findall('(الحلقة|الحلقه)-([0-9]+)',cX2SpPxGLmADTKl.split('/')[-2],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if not title: title = AxTYMhRlfyskNc0X19dvwtS.findall('()-([0-9]+)',cX2SpPxGLmADTKl.split('/')[-2],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if title: title = WRsuxHTjDgYCIpoMQzLFAtS8rikP + title[0][1]
			else: title = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			title = name + ' - ' + 'الحلقة' + title
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,182,RRx0ri8bETI)
	if not items:
		title = riUKNnOEtVwdj4(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('بجوده ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,url,182,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	ZvsEFTCDcPL = url.split('?servers=')
	nUDgc4absePT2xMt = ZvsEFTCDcPL[0]
	del ZvsEFTCDcPL[0]
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-PLAY-1st')
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('font-size: 25px;" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	if cX2SpPxGLmADTKl not in ZvsEFTCDcPL: ZvsEFTCDcPL.append(cX2SpPxGLmADTKl)
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	for cX2SpPxGLmADTKl in ZvsEFTCDcPL:
		if '://moshahda.' in cX2SpPxGLmADTKl:
			OguFRXVc7m1Nsq93 = cX2SpPxGLmADTKl
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(OguFRXVc7m1Nsq93+'?named=Main')
	for cX2SpPxGLmADTKl in ZvsEFTCDcPL:
		if '://vb.movizland.' in cX2SpPxGLmADTKl:
			R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-PLAY-2nd')
			R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.decode(wyNsOv6zCW7pdEHXUf3lFGqQAYj).encode(RMGz7OiD1e30P)
			R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if vvuraxgW7YLIZ4hU0MbCt:
				Uyb6AW5FflmEDXSa0scj,O0wTRBaWzSFf8IitYo5CmEgy = [],[]
				if len(vvuraxgW7YLIZ4hU0MbCt)==1:
					title = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
				else:
					for IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
						Lhi71X39bHs6zEZ4ypIaGewVJ = AxTYMhRlfyskNc0X19dvwtS.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						if Lhi71X39bHs6zEZ4ypIaGewVJ: IxdmfnvhCA8Bc9ZlQ45oiqN = 'src="/uploads/13721411411.png"  \n  ' + Lhi71X39bHs6zEZ4ypIaGewVJ[0][1]
						Lhi71X39bHs6zEZ4ypIaGewVJ = AxTYMhRlfyskNc0X19dvwtS.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						if Lhi71X39bHs6zEZ4ypIaGewVJ: IxdmfnvhCA8Bc9ZlQ45oiqN = 'src="/uploads/13721411411.png"  \n  ' + Lhi71X39bHs6zEZ4ypIaGewVJ[0]
						Lhi71X39bHs6zEZ4ypIaGewVJ = AxTYMhRlfyskNc0X19dvwtS.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						if Lhi71X39bHs6zEZ4ypIaGewVJ: IxdmfnvhCA8Bc9ZlQ45oiqN = Lhi71X39bHs6zEZ4ypIaGewVJ[0] + '  \n  src="/uploads/13721411411.png"'
						QQIt0mBH4yFNa = AxTYMhRlfyskNc0X19dvwtS.findall('<(.*?)http://up.movizland.(online|com)/uploads/',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						title = AxTYMhRlfyskNc0X19dvwtS.findall('> *([^<>]+) *<',QQIt0mBH4yFNa[0][0],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						title = WRsuxHTjDgYCIpoMQzLFAtS8rikP.join(title)
						title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
						title = title.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
						Uyb6AW5FflmEDXSa0scj.append(title)
					qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('أختر الفيديو المطلوب:', Uyb6AW5FflmEDXSa0scj)
					if qNmsBD1jJZVzcxi4onKuAOIC == -1 : return
					title = Uyb6AW5FflmEDXSa0scj[qNmsBD1jJZVzcxi4onKuAOIC]
					IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[qNmsBD1jJZVzcxi4onKuAOIC]
				cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http://moshahda\..*?/\w+.html)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				ewYH6snbVAzEMF3OI = cX2SpPxGLmADTKl[0]
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(ewYH6snbVAzEMF3OI+'?named=Forum')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('ـ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				zA10lKkdfxXt7YBJcGUsvSjpwFQ4 = AxTYMhRlfyskNc0X19dvwtS.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				for RvIa8ru1Ek in zA10lKkdfxXt7YBJcGUsvSjpwFQ4:
					type = AxTYMhRlfyskNc0X19dvwtS.findall(' typetype="(.*?)" ',RvIa8ru1Ek)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					items = AxTYMhRlfyskNc0X19dvwtS.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',RvIa8ru1Ek,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					for pLOFdGAn5Y01E8Q6cVzPm9SNk42,cX2SpPxGLmADTKl in items:
						title = AxTYMhRlfyskNc0X19dvwtS.findall('(\w+[ \w]*)<',pLOFdGAn5Y01E8Q6cVzPm9SNk42)
						title = title[-1]
						cX2SpPxGLmADTKl = cX2SpPxGLmADTKl + '?named=' + title + type
						CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	jYfvU9egTX62nrukVcoKEAyq = nUDgc4absePT2xMt.replace(S7EgasGcYdIo,talv2Us5Kn1)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,jYfvU9egTX62nrukVcoKEAyq,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-PLAY-3rd')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		JbBiUnsetk8fF7DrpoAIQjZPq = items[-1]
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(JbBiUnsetk8fF7DrpoAIQjZPq+'?named=Mobile')
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'MOVIZLAND-SEARCH-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<option value="(.*?)">(.*?)</option>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	fnqMdmxswNZD1F = [ VhaIfJdtZP1kiKbRq8nGvFo9juBp2O ]
	ppTADe7Jor6K3xZqItdng1CNHP8s5B = [ 'الكل وبدون فلتر' ]
	for PtATpb3YenChf5,title in items:
		fnqMdmxswNZD1F.append(PtATpb3YenChf5)
		ppTADe7Jor6K3xZqItdng1CNHP8s5B.append(title)
	if PtATpb3YenChf5:
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('اختر الفلتر المناسب:', ppTADe7Jor6K3xZqItdng1CNHP8s5B)
		if qNmsBD1jJZVzcxi4onKuAOIC == -1 : return
		PtATpb3YenChf5 = fnqMdmxswNZD1F[qNmsBD1jJZVzcxi4onKuAOIC]
	else: PtATpb3YenChf5 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	url = S7EgasGcYdIo + '/?s='+search+'&mcat='+PtATpb3YenChf5
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return