# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'KATKOUTE'
qBAgzkG9oCL = '_KTK_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['الصفحة الرئيسية','Sign in','الأقسام']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==670: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==671: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==672: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==673: Ubud2NhHKRnMTvI5mprQBVqk80 = odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,text)
	elif mode==674: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==679: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,679,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"navslide-divider"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,mode)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	items = gFLtwp2hNmQ6iHu7T4ReIOl(S7EgasGcYdIo+'/watch/browse.html')
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,674,RRx0ri8bETI)
	return
def gFLtwp2hNmQ6iHu7T4ReIOl(url):
	ZcdILQijMvDG5Pz2fhAmwtr170CT4 = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','KATKOUTE','CATEGORIES')
	if ZcdILQijMvDG5Pz2fhAmwtr170CT4: return ZcdILQijMvDG5Pz2fhAmwtr170CT4
	ZcdILQijMvDG5Pz2fhAmwtr170CT4 = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-CATEGORIES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"category-header"(.*?)<footer>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		ZcdILQijMvDG5Pz2fhAmwtr170CT4 = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if ZcdILQijMvDG5Pz2fhAmwtr170CT4: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'KATKOUTE','CATEGORIES',ZcdILQijMvDG5Pz2fhAmwtr170CT4,QTa0s1bvhkXjIim7lWF5qVBJUoNZ)
	return ZcdILQijMvDG5Pz2fhAmwtr170CT4
def I1C6JqXo3j9Ruyz(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-SUBMENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"caret"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if j9HbACE1rmuP48NVX6pgQsUwfBWk:
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('"presentation"','</ul>')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = [(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,IxdmfnvhCA8Bc9ZlQ45oiqN)]
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' فرز أو فلتر أو ترتيب '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		for wMVN0pF2Qqt1AGTI6ujBshRJO5fP,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if wMVN0pF2Qqt1AGTI6ujBshRJO5fP: wMVN0pF2Qqt1AGTI6ujBshRJO5fP = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+': '
			for cX2SpPxGLmADTKl,title in items:
				title = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+title
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,671)
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-category-subcats"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if fxgnWRoUO7jNwtJkuB:
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(items)<30:
			w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			for cX2SpPxGLmADTKl,title in items:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,671)
	if not j9HbACE1rmuP48NVX6pgQsUwfBWk and not fxgnWRoUO7jNwtJkuB: ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if eBjxVKSvQC1=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-TITLES-1st')
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-TITLES-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	IxdmfnvhCA8Bc9ZlQ45oiqN,items = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	if eBjxVKSvQC1=='ajax-search':
		IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
		llN8cqbtajQJprPCKLnWVxXB = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in llN8cqbtajQJprPCKLnWVxXB: items.append((VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,cX2SpPxGLmADTKl,title))
	elif eBjxVKSvQC1=='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-video-watch-featured"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	elif eBjxVKSvQC1=='new_episodes':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"row pm-ul-browse-videos(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	elif eBjxVKSvQC1=='new_movies':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"row pm-ul-browse-videos(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(vvuraxgW7YLIZ4hU0MbCt)>1: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[1]
	elif eBjxVKSvQC1=='featured_series':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		llN8cqbtajQJprPCKLnWVxXB = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in llN8cqbtajQJprPCKLnWVxXB: items.append((VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,cX2SpPxGLmADTKl,title))
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(data-echo=".*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if IxdmfnvhCA8Bc9ZlQ45oiqN and not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items: return
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,672,RRx0ri8bETI)
		elif eBjxVKSvQC1=='new_episodes':
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,672,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,673,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/movseries/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,671,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,673,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if cX2SpPxGLmADTKl=='#': continue
			if 'http' not in cX2SpPxGLmADTKl:
				nUDgc4absePT2xMt = url.rsplit('/',1)[0]
				cX2SpPxGLmADTKl = nUDgc4absePT2xMt+'/'+cX2SpPxGLmADTKl.strip('/')
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,671,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,eBjxVKSvQC1)
	return
def odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,nRW2P4Ke3z7):
	w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+'تشغيل الفيديو',url,672)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	ZcdILQijMvDG5Pz2fhAmwtr170CT4 = gFLtwp2hNmQ6iHu7T4ReIOl(S7EgasGcYdIo+'/watch/browse.html')
	WvVsuCZ1Ykw8xQER3T7lnaX,WjbXLNMBJtslEyFc,FkEo57hK6uRqGwIxeO3Zv4nWCp = zip(*ZcdILQijMvDG5Pz2fhAmwtr170CT4)
	ytfR6oa5Sb = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-EPISODES-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"row pm-video-heading"(.*?)id="player"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in BA01W9olieErLycV7kwFvOhH5Y3ms:
			if cX2SpPxGLmADTKl not in WvVsuCZ1Ykw8xQER3T7lnaX:
				Uz7N5KAHwQ93iShW1xj = (cX2SpPxGLmADTKl,title)
				ytfR6oa5Sb.append(Uz7N5KAHwQ93iShW1xj)
		if len(ytfR6oa5Sb)==1:
			cX2SpPxGLmADTKl,title = ytfR6oa5Sb[0]
			ENDRjPGicXYFvpVs3xk5uSg6y(cX2SpPxGLmADTKl,'new_episodes')
			return
		else:
			for cX2SpPxGLmADTKl,title in ytfR6oa5Sb:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,671,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'new_episodes')
	if not ytfR6oa5Sb: ENDRjPGicXYFvpVs3xk5uSg6y(url,'new_episodes')
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'KATKOUTE-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('sources:(.*?)flashplayer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('file: "(.*?)".*?label: "(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,XcvFdKRjNLz5wEpDf in BA01W9olieErLycV7kwFvOhH5Y3ms:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named=__watch__'+XcvFdKRjNLz5wEpDf
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('"embedded-video".*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not BA01W9olieErLycV7kwFvOhH5Y3ms: BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall("file: '(.*?)'",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if BA01W9olieErLycV7kwFvOhH5Y3ms:
		cX2SpPxGLmADTKl = BA01W9olieErLycV7kwFvOhH5Y3ms[0]
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed')
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/watch/search.php?keywords='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return