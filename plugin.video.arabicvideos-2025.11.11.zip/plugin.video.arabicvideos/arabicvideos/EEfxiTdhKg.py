# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
import bs4 as pOm7P6yXbECNIhv51eTWA4RBYM
mI6ayKxBvjd4CRthL = 'ELCINEMA'
qBAgzkG9oCL = '_ELC_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
headers = {'Referer':S7EgasGcYdIo}
kCIESuy4j5mVLZYtG9vDNnb7 = []
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==510: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==511: Ubud2NhHKRnMTvI5mprQBVqk80 = zKf2Aj5THg(url)
	elif mode==512: Ubud2NhHKRnMTvI5mprQBVqk80 = u7uPZDFTMfVHSGsa(url)
	elif mode==513: Ubud2NhHKRnMTvI5mprQBVqk80 = NdDILetU5KXaYjZ3HP6O2CBTV0(url)
	elif mode==514: Ubud2NhHKRnMTvI5mprQBVqk80 = hRy9rCM3ueV1AQYaP6HbfnG(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: Ubud2NhHKRnMTvI5mprQBVqk80 = hRy9rCM3ueV1AQYaP6HbfnG(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: Ubud2NhHKRnMTvI5mprQBVqk80 = mU6bi70l9HNyR(text)
	elif mode==517: Ubud2NhHKRnMTvI5mprQBVqk80 = G19fpSDqC0agQdes3(url)
	elif mode==518: Ubud2NhHKRnMTvI5mprQBVqk80 = HGMJbsfBy0lER7LYNz(url)
	elif mode==519: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	elif mode==520: Ubud2NhHKRnMTvI5mprQBVqk80 = qSlhWVumYJGIbMAtCFULZ(url)
	elif mode==521: Ubud2NhHKRnMTvI5mprQBVqk80 = E2KR410cVNgWXje3Zs(url)
	elif mode==522: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==523: Ubud2NhHKRnMTvI5mprQBVqk80 = txPuDmloTd(text)
	elif mode==524: Ubud2NhHKRnMTvI5mprQBVqk80 = oWuGfbpqJcrPjk0QRxT6gzsSOn7ZD1()
	elif mode==525: Ubud2NhHKRnMTvI5mprQBVqk80 = undVJMxUsme()
	elif mode==526: Ubud2NhHKRnMTvI5mprQBVqk80 = SYosNFWjAhOEQVtlRuBvc3g()
	elif mode==527: Ubud2NhHKRnMTvI5mprQBVqk80 = yclxRam2Ffqr4Q9o35ZvNk()
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث بموسوعة السينما',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,519)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'موسوعة الأعمال',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,525)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'موسوعة الأشخاص',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,526)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'موسوعة المصنفات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,527)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'موسوعة المنوعات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,524)
	return
def oWuGfbpqJcrPjk0QRxT6gzsSOn7ZD1():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' فيديوهات - خاصة',S7EgasGcYdIo+'/video',520)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فيديوهات - أحدث',S7EgasGcYdIo+'/video/latest',521)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فيديوهات - أقدم',S7EgasGcYdIo+'/video/oldest',521)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فيديوهات - أكثر مشاهدة',S7EgasGcYdIo+'/video/views',521)
	return
def undVJMxUsme():
	TXd2QIiPvkmFAzf7KqyUeVhurH8 = S7EgasGcYdIo+'/lineup?utf8=%E2%9C%93'
	l2XyAYo4PJTaEGH8d = TXd2QIiPvkmFAzf7KqyUeVhurH8+'&type=2&category=1&foreign=false&tag='
	w8wPAeHxG1l3zdFghvVpByQUTs2E = TXd2QIiPvkmFAzf7KqyUeVhurH8+'&type=2&category=3&foreign=false&tag='
	x9cuGpUoqLAr2n73FajO4w = TXd2QIiPvkmFAzf7KqyUeVhurH8+'&type=2&category=1&foreign=true&tag='
	l21lQcDSGv5tEyIdo6TU0smVJK7CYW = TXd2QIiPvkmFAzf7KqyUeVhurH8+'&type=2&category=3&foreign=true&tag='
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات أفلام عربي',l2XyAYo4PJTaEGH8d,511)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات مسلسلات عربي',w8wPAeHxG1l3zdFghvVpByQUTs2E,511)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات أفلام اجنبي',x9cuGpUoqLAr2n73FajO4w,511)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات مسلسلات اجنبي',l21lQcDSGv5tEyIdo6TU0smVJK7CYW,511)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس أعمال أبجدي',S7EgasGcYdIo+'/index/work/alphabet',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس  بلد الإنتاج',S7EgasGcYdIo+'/index/work/country',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس اللغة',S7EgasGcYdIo+'/index/work/language',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس مصنفات العمل',S7EgasGcYdIo+'/index/work/genre',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس سنة الإصدار',S7EgasGcYdIo+'/index/work/release_year',517)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مواسم - فلتر محدد',S7EgasGcYdIo+'/seasonals',515)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مواسم - فلتر كامل',S7EgasGcYdIo+'/seasonals',514)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات - فلتر محدد',S7EgasGcYdIo+'/lineup',515)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات - فلتر كامل',S7EgasGcYdIo+'/lineup',514)
	return
def yclxRam2Ffqr4Q9o35ZvNk():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo+'/lineup',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	IxdmfnvhCA8Bc9ZlQ45oiqN = A8aiLZSoKdPx2JuqVF1wmjNDy.find('select',attrs={'name':'tag'})
	sL9HIPc1tSZrhE60TUoz2KQa = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('option')
	for HHvPeCLzN1fIWDStR in sL9HIPc1tSZrhE60TUoz2KQa:
		value = HHvPeCLzN1fIWDStR.get('value')
		if not value: continue
		title = HHvPeCLzN1fIWDStR.text
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.encode(RMGz7OiD1e30P)
			value = value.encode(RMGz7OiD1e30P)
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,511)
	return
def SYosNFWjAhOEQVtlRuBvc3g():
	TXd2QIiPvkmFAzf7KqyUeVhurH8 = S7EgasGcYdIo+'/lineup?utf8=%E2%9C%93'
	S8VIk4HT36jKs0QzDyeUBv1h = TXd2QIiPvkmFAzf7KqyUeVhurH8+'&type=1&category=&foreign=&tag='
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات أشخاص',S8VIk4HT36jKs0QzDyeUBv1h,511)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس أشخاص أبجدي',S7EgasGcYdIo+'/index/person/alphabet',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس موطن',S7EgasGcYdIo+'/index/person/nationality',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس  تاريخ الميلاد',S7EgasGcYdIo+'/index/person/birth_year',517)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فهرس  تاريخ الوفاة',S7EgasGcYdIo+'/index/person/death_year',517)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات - فلتر محدد',S7EgasGcYdIo+'/lineup',515)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مصنفات - فلتر كامل',S7EgasGcYdIo+'/lineup',514)
	return
def zKf2Aj5THg(url):
	if '/seasonals' in url: qHmcPitXMaCJTswd7zj8W3Ux4u9l = 0
	elif '/lineup' in url: qHmcPitXMaCJTswd7zj8W3Ux4u9l = 1
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-LISTS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	GtnfmdqIOijegYu = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all(class_='jumbo-theater clearfix')
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		title = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('a')[qHmcPitXMaCJTswd7zj8W3Ux4u9l].text
		cX2SpPxGLmADTKl = S7EgasGcYdIo+IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('a')[qHmcPitXMaCJTswd7zj8W3Ux4u9l].get('href')
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
		if not GtnfmdqIOijegYu:
			u7uPZDFTMfVHSGsa(cX2SpPxGLmADTKl)
			return
		else:
			title = title.replace('قائمة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,512)
	lVL9WmPpg3nzufxACOB2wGESY(A8aiLZSoKdPx2JuqVF1wmjNDy,511)
	return
def lVL9WmPpg3nzufxACOB2wGESY(A8aiLZSoKdPx2JuqVF1wmjNDy,mode):
	IxdmfnvhCA8Bc9ZlQ45oiqN = A8aiLZSoKdPx2JuqVF1wmjNDy.find(class_='pagination')
	if IxdmfnvhCA8Bc9ZlQ45oiqN:
		voAqPhUMG3cB4VjEJ9x5u = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('a')
		gpNaVye3SL = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('li')
		eXkEiayvHQhGcSClN = list(zip(voAqPhUMG3cB4VjEJ9x5u,gpNaVye3SL))
		r6dVWlzDj9va0FxqfkOwLYZEmP = -1
		NWDBfMliTaYoO73Vgr0mXG5pbuAyL = len(eXkEiayvHQhGcSClN)
		for VIdjQswzuMv,gebTH52B4pfn6IFaL9OQiRs in eXkEiayvHQhGcSClN:
			r6dVWlzDj9va0FxqfkOwLYZEmP += 1
			gebTH52B4pfn6IFaL9OQiRs = gebTH52B4pfn6IFaL9OQiRs['class']
			if 'unavailable' in gebTH52B4pfn6IFaL9OQiRs or 'current' in gebTH52B4pfn6IFaL9OQiRs: continue
			XQv4cBgdZD5k6OPwy3alsEGxtA = VIdjQswzuMv.text
			evGVuBpQUEL = S7EgasGcYdIo+VIdjQswzuMv.get('href')
			if hT1JIgqPQsUOZp5tjCX0E:
				XQv4cBgdZD5k6OPwy3alsEGxtA = XQv4cBgdZD5k6OPwy3alsEGxtA.encode(RMGz7OiD1e30P)
				evGVuBpQUEL = evGVuBpQUEL.encode(RMGz7OiD1e30P)
			if   r6dVWlzDj9va0FxqfkOwLYZEmP==0: XQv4cBgdZD5k6OPwy3alsEGxtA = 'أولى'
			elif r6dVWlzDj9va0FxqfkOwLYZEmP==1: XQv4cBgdZD5k6OPwy3alsEGxtA = 'سابقة'
			elif r6dVWlzDj9va0FxqfkOwLYZEmP==NWDBfMliTaYoO73Vgr0mXG5pbuAyL-2: XQv4cBgdZD5k6OPwy3alsEGxtA = 'لاحقة'
			elif r6dVWlzDj9va0FxqfkOwLYZEmP==NWDBfMliTaYoO73Vgr0mXG5pbuAyL-1: XQv4cBgdZD5k6OPwy3alsEGxtA = 'أخيرة'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+XQv4cBgdZD5k6OPwy3alsEGxtA,evGVuBpQUEL,mode)
	return
def u7uPZDFTMfVHSGsa(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-TITLES1-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	GtnfmdqIOijegYu = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all(class_='row')
	items,hKlkUJZEvLmeDXgO6Gs50MnYb = [],True
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		if not IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='thumbnail-wrapper'): continue
		if hKlkUJZEvLmeDXgO6Gs50MnYb: hKlkUJZEvLmeDXgO6Gs50MnYb = False ; continue
		VDM29SFgA7vfPoUEiInBacYWduXL3j = []
		VVTIMRFtaLikOS3HcsyD7 = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all(class_=['censorship red','censorship purple'])
		for wOXnbdPmRLJH in VVTIMRFtaLikOS3HcsyD7:
			AAQaV7WCGnHBcJrm5gqfu = wOXnbdPmRLJH.find_all('li')[1].text
			if hT1JIgqPQsUOZp5tjCX0E:
				AAQaV7WCGnHBcJrm5gqfu = AAQaV7WCGnHBcJrm5gqfu.encode(RMGz7OiD1e30P)
			VDM29SFgA7vfPoUEiInBacYWduXL3j.append(AAQaV7WCGnHBcJrm5gqfu)
		if not OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VDM29SFgA7vfPoUEiInBacYWduXL3j,False):
			E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('data-src')
			title = IxdmfnvhCA8Bc9ZlQ45oiqN.find('h3')
			name = title.find('a').text
			cX2SpPxGLmADTKl = S7EgasGcYdIo+title.find('a').get('href')
			S2DgI5Y9rHOVcLoA = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='no-margin')
			spdW3TXUuMy2i = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='legend')
			if S2DgI5Y9rHOVcLoA: S2DgI5Y9rHOVcLoA = S2DgI5Y9rHOVcLoA.text
			if spdW3TXUuMy2i: spdW3TXUuMy2i = spdW3TXUuMy2i.text
			if hT1JIgqPQsUOZp5tjCX0E:
				E7MF9aYlV4Q0 = E7MF9aYlV4Q0.encode(RMGz7OiD1e30P)
				name = name.encode(RMGz7OiD1e30P)
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
				if S2DgI5Y9rHOVcLoA: S2DgI5Y9rHOVcLoA = S2DgI5Y9rHOVcLoA.encode(RMGz7OiD1e30P)
			CC8RbxJ4AHh9rgjTdBsU = {}
			if spdW3TXUuMy2i: CC8RbxJ4AHh9rgjTdBsU['stars'] = spdW3TXUuMy2i
			if S2DgI5Y9rHOVcLoA:
				S2DgI5Y9rHOVcLoA = S2DgI5Y9rHOVcLoA.replace(b8sk5WyPoz03pXhRx,' .. ')
				CC8RbxJ4AHh9rgjTdBsU['plot'] = S2DgI5Y9rHOVcLoA.replace('...اقرأ المزيد',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if '/work/' in cX2SpPxGLmADTKl:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,516,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CC8RbxJ4AHh9rgjTdBsU)
			elif '/person/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,513,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CC8RbxJ4AHh9rgjTdBsU)
	lVL9WmPpg3nzufxACOB2wGESY(A8aiLZSoKdPx2JuqVF1wmjNDy,512)
	return
def NdDILetU5KXaYjZ3HP6O2CBTV0(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-TITLES2-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	GtnfmdqIOijegYu = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all('li')
	cclJEkZuLNn7r3FOWwiGbATU2V,items = [],[]
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		if not IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='thumbnail-wrapper'): continue
		if not IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_=['unstyled','unstyled text-center']): continue
		if IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='hide'): continue
		title = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in cclJEkZuLNn7r3FOWwiGbATU2V: continue
		cclJEkZuLNn7r3FOWwiGbATU2V.append(name)
		cX2SpPxGLmADTKl = S7EgasGcYdIo+title.find('a').get('href')
		if '/search/work/' in url: E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('src')
		elif '/search/person/' in url: E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('data-src')
		elif '/search/video/' in url: E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('data-src')
		else: E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('src')
		if hT1JIgqPQsUOZp5tjCX0E:
			name = name.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
			E7MF9aYlV4Q0 = E7MF9aYlV4Q0.encode(RMGz7OiD1e30P)
		name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		items.append((name,cX2SpPxGLmADTKl,E7MF9aYlV4Q0))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,cX2SpPxGLmADTKl,E7MF9aYlV4Q0 in items:
		if '/search/video/' in url: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,522,E7MF9aYlV4Q0)
		elif '/search/person/' in url: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,513,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,516,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name)
	return
def mU6bi70l9HNyR(text):
	text = text.replace('الإعلان',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('لفيلم',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('الرسمي',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace('إعلان',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('فيلم',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('البرومو',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace('التشويقي',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('لمسلسل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('مسلسل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace(':',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(')',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('(',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(',',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace('_',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(';',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('-',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('.',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace('\'',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('\"',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	text = text.replace(NNJKRTY8GlM29ezbCgPiXd,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(NzlAQMRChm8J34urLwcUOn1f,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	text = text.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	xM6mPhjy5uc = text.count(WRsuxHTjDgYCIpoMQzLFAtS8rikP)+1
	if xM6mPhjy5uc==1:
		txPuDmloTd(text)
		return
	w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+qFghPAi5yz9Vf3NLwo0nuprl+'==== كلمات للبحث ===='+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	SmVuUwv9JC2b5Fc78ZMO1L3a = text.split(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	EFfBIumdz8QenY41MS6iPjCWbDKOxg = pow(2,xM6mPhjy5uc)
	fv3axOUBp6C2Qku = []
	def t5aBQEK4hcP2gTi9(ooxHaLpetPMAFsS,RuAY8K2ZThoEsOtwiIy9k6cC4r3Q):
		if ooxHaLpetPMAFsS=='1': return RuAY8K2ZThoEsOtwiIy9k6cC4r3Q
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for r6dVWlzDj9va0FxqfkOwLYZEmP in range(EFfBIumdz8QenY41MS6iPjCWbDKOxg,0,-1):
		fHlQxVZDnvi24yXhGwUKCts8 = list(xM6mPhjy5uc*'0'+bin(r6dVWlzDj9va0FxqfkOwLYZEmP)[2:])[-xM6mPhjy5uc:]
		fHlQxVZDnvi24yXhGwUKCts8 = reversed(fHlQxVZDnvi24yXhGwUKCts8)
		vv52HizJKaC = map(t5aBQEK4hcP2gTi9,fHlQxVZDnvi24yXhGwUKCts8,SmVuUwv9JC2b5Fc78ZMO1L3a)
		title = WRsuxHTjDgYCIpoMQzLFAtS8rikP.join(filter(None,vv52HizJKaC))
		if hT1JIgqPQsUOZp5tjCX0E: uoH6T37WPfCdv8JLnYZjK2r = title.decode(RMGz7OiD1e30P)
		else: uoH6T37WPfCdv8JLnYZjK2r = title
		if len(uoH6T37WPfCdv8JLnYZjK2r)>2 and title not in fv3axOUBp6C2Qku:
			fv3axOUBp6C2Qku.append(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,523,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,title)
	return
def txPuDmloTd(f1EhmRrADV8KxiNQcayZ6tswPI):
	if hT1JIgqPQsUOZp5tjCX0E:
		f1EhmRrADV8KxiNQcayZ6tswPI = f1EhmRrADV8KxiNQcayZ6tswPI.decode(RMGz7OiD1e30P)
		import arabic_reshaper as QUPNnY7wtZCmj1Eed4L2rAIMkH,bidi.algorithm as TwdBkcp9R8ilKZLJm36Sy0UQ7AEG
		f1EhmRrADV8KxiNQcayZ6tswPI = QUPNnY7wtZCmj1Eed4L2rAIMkH.ArabicReshaper().reshape(f1EhmRrADV8KxiNQcayZ6tswPI)
		f1EhmRrADV8KxiNQcayZ6tswPI = TwdBkcp9R8ilKZLJm36Sy0UQ7AEG.get_display(f1EhmRrADV8KxiNQcayZ6tswPI)
	import gSCos1rw82
	f1EhmRrADV8KxiNQcayZ6tswPI = TwDBf3QbKOnrmd5u9(e3wJkhfiTIAD=f1EhmRrADV8KxiNQcayZ6tswPI)
	gSCos1rw82.E3FwPg9Z6KB(f1EhmRrADV8KxiNQcayZ6tswPI)
	return
def G19fpSDqC0agQdes3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-INDEXES_LISTS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	IxdmfnvhCA8Bc9ZlQ45oiqN = A8aiLZSoKdPx2JuqVF1wmjNDy.find(class_='list-separator list-title')
	p3USGyZE9bKVhvjtd4W0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('a')
	items = []
	for title in p3USGyZE9bKVhvjtd4W0:
		name = title.text
		cX2SpPxGLmADTKl = S7EgasGcYdIo+title.get('href')
		if hT1JIgqPQsUOZp5tjCX0E:
			name = name.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
		if '#' not in cX2SpPxGLmADTKl: items.append((name,cX2SpPxGLmADTKl))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for Uz7N5KAHwQ93iShW1xj in items:
		name,cX2SpPxGLmADTKl = Uz7N5KAHwQ93iShW1xj
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,518)
	return
def HGMJbsfBy0lER7LYNz(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-INDEXES_TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	GtnfmdqIOijegYu = A8aiLZSoKdPx2JuqVF1wmjNDy.find(class_='expand').find_all('tr')
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		TA6Q4FvfZwe = IxdmfnvhCA8Bc9ZlQ45oiqN.find_all('a')
		if not TA6Q4FvfZwe: continue
		E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('data-src')
		name = TA6Q4FvfZwe[1].text
		cX2SpPxGLmADTKl = S7EgasGcYdIo+TA6Q4FvfZwe[1].get('href')
		spdW3TXUuMy2i = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='legend')
		if spdW3TXUuMy2i: spdW3TXUuMy2i = spdW3TXUuMy2i.text
		if hT1JIgqPQsUOZp5tjCX0E:
			name = name.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
			E7MF9aYlV4Q0 = E7MF9aYlV4Q0.encode(RMGz7OiD1e30P)
		CC8RbxJ4AHh9rgjTdBsU = {}
		if spdW3TXUuMy2i: CC8RbxJ4AHh9rgjTdBsU['stars'] = spdW3TXUuMy2i
		if '/work/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,516,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CC8RbxJ4AHh9rgjTdBsU)
		elif '/person/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+name,cX2SpPxGLmADTKl,513,E7MF9aYlV4Q0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CC8RbxJ4AHh9rgjTdBsU)
	lVL9WmPpg3nzufxACOB2wGESY(A8aiLZSoKdPx2JuqVF1wmjNDy,518)
	return
def qSlhWVumYJGIbMAtCFULZ(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-VIDEOS_LISTS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	p3USGyZE9bKVhvjtd4W0 = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all(class_='section-title inline')
	BA01W9olieErLycV7kwFvOhH5Y3ms = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all(class_='button green small right')
	items = zip(p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms)
	for title,cX2SpPxGLmADTKl in items:
		title = title.text
		cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl.get('href')
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
		title = title.replace(NNJKRTY8GlM29ezbCgPiXd,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(NzlAQMRChm8J34urLwcUOn1f,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,521)
	return
def E2KR410cVNgWXje3Zs(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-VIDEOS_TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	BBCS1b2RsVOw9oYPFT0KcaE = A8aiLZSoKdPx2JuqVF1wmjNDy.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	GtnfmdqIOijegYu = BBCS1b2RsVOw9oYPFT0KcaE.find_all('li')
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		title = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='title').text
		cX2SpPxGLmADTKl = S7EgasGcYdIo+IxdmfnvhCA8Bc9ZlQ45oiqN.find('a').get('href')
		E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN.find('img').get('data-src')
		w03zWJvcXaCUySB6HIq4mVe = IxdmfnvhCA8Bc9ZlQ45oiqN.find(class_='duration').text
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.encode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
			E7MF9aYlV4Q0 = E7MF9aYlV4Q0.encode(RMGz7OiD1e30P)
			w03zWJvcXaCUySB6HIq4mVe = w03zWJvcXaCUySB6HIq4mVe.encode(RMGz7OiD1e30P)
		w03zWJvcXaCUySB6HIq4mVe = w03zWJvcXaCUySB6HIq4mVe.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,522,E7MF9aYlV4Q0,w03zWJvcXaCUySB6HIq4mVe)
	lVL9WmPpg3nzufxACOB2wGESY(A8aiLZSoKdPx2JuqVF1wmjNDy,521)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	cX2SpPxGLmADTKl = A8aiLZSoKdPx2JuqVF1wmjNDy.find(class_='flex-video').find('iframe').get('src')
	if hT1JIgqPQsUOZp5tjCX0E: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.encode(RMGz7OiD1e30P)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2([cX2SpPxGLmADTKl],mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	url = S7EgasGcYdIo+'/search/?q='+search
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-SEARCH-1st')
	if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
		S8VIk4HT36jKs0QzDyeUBv1h = S7EgasGcYdIo+'/search_entity/?q='+search+'&entity=work'
		evGVuBpQUEL = S7EgasGcYdIo+'/search_entity/?q='+search+'&entity=person'
		mVh58FX3zfTpEu = S7EgasGcYdIo+'/search_entity/?q='+search+'&entity=video'
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن أعمال',S8VIk4HT36jKs0QzDyeUBv1h,513,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,search)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن أشخاص',evGVuBpQUEL,513,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,search)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن فيديوهات',mVh58FX3zfTpEu,513,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,search)
		return
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	A8aiLZSoKdPx2JuqVF1wmjNDy = pOm7P6yXbECNIhv51eTWA4RBYM.BeautifulSoup(R8AE9e4mYxVhusL3Q,'html.parser',multi_valued_attributes=None)
	GtnfmdqIOijegYu = A8aiLZSoKdPx2JuqVF1wmjNDy.find_all(class_='section-title left')
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		title = IxdmfnvhCA8Bc9ZlQ45oiqN.text
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.encode(RMGz7OiD1e30P)
		title = title.split('(',1)[0].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if   'أعمال' in title: cX2SpPxGLmADTKl = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: cX2SpPxGLmADTKl = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: cX2SpPxGLmADTKl = url.replace('/search/','/search/video/')
		else: continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,513)
	return
def hRy9rCM3ueV1AQYaP6HbfnG(url,text):
	global agsNp4VJm8d3e,iuECgXkw3pcy1FAvK96G
	if '/seasonals' in url:
		agsNp4VJm8d3e = ['seasonal','year','category']
		iuECgXkw3pcy1FAvK96G = ['seasonal','year','category']
	elif '/lineup' in url:
		agsNp4VJm8d3e = ['category','foreign','type']
		iuECgXkw3pcy1FAvK96G = ['category','foreign','type']
	EM3FsPBeAD2bQxi0LThaKG(url,text)
	return
def RKFfhG6MsCPv8BrNUpzo7d9gX(url):
	url = url.split('/smartemadfilter?')[0]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('form action="/(.*?)</form>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return i2KVkE3TFNIGfymrpJA
def vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN):
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<option value="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return items
def M0M1GZXwzE(url):
	VChIfEZU37zqWGnL = url.split('/smartemadfilter?')[0]
	kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def r5xtyuaAdg78jqzecPG(w4bR5rAa7OFdUxjPI3NVDHy,url):
	pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'all_filters')
	jYfvU9egTX62nrukVcoKEAyq = url+'/smartemadfilter?'+pbIlAP6KNW
	jYfvU9egTX62nrukVcoKEAyq = M0M1GZXwzE(jYfvU9egTX62nrukVcoKEAyq)
	return jYfvU9egTX62nrukVcoKEAyq
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if agsNp4VJm8d3e[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(agsNp4VJm8d3e[0:-1])):
			if agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
	elif type=='ALL_ITEMS_FILTER':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'/smartemadfilter?'+J41jTEGvedKYQgclAiUuPxF
		nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها ',nUDgc4absePT2xMt,511)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',nUDgc4absePT2xMt,511)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	i2KVkE3TFNIGfymrpJA = RKFfhG6MsCPv8BrNUpzo7d9gX(url)
	dict = {}
	for name,CCkP7yi8aglTqbDOdBjRWNpco,IxdmfnvhCA8Bc9ZlQ45oiqN in i2KVkE3TFNIGfymrpJA:
		name = name.replace('--',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		items = vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='SPECIFIED_FILTER':
			if CCkP7yi8aglTqbDOdBjRWNpco not in agsNp4VJm8d3e: continue
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<2:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]:
					url = M0M1GZXwzE(url)
					u7uPZDFTMfVHSGsa(url)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'SPECIFIED_FILTER___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,511)
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,515,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='ALL_ITEMS_FILTER':
			if CCkP7yi8aglTqbDOdBjRWNpco not in iuECgXkw3pcy1FAvK96G: continue
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع: '+name,nUDgc4absePT2xMt,514,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			if 'مصنفات أخرى' in HHvPeCLzN1fIWDStR: continue
			if 'الكل' in HHvPeCLzN1fIWDStR: continue
			if 'اللغة' in HHvPeCLzN1fIWDStR: continue
			HHvPeCLzN1fIWDStR = HHvPeCLzN1fIWDStR.replace('قائمة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			if name: title = HHvPeCLzN1fIWDStR+' :'+name
			else: title = HHvPeCLzN1fIWDStR
			if type=='ALL_ITEMS_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,514,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='SPECIFIED_FILTER' and agsNp4VJm8d3e[-2]+'=' in gjOp9yI3iS:
				jYfvU9egTX62nrukVcoKEAyq = r5xtyuaAdg78jqzecPG(w4bR5rAa7OFdUxjPI3NVDHy,url)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,511)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,515,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.replace('=&','=0&')
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for key in iuECgXkw3pcy1FAvK96G:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if '%' not in value: value = pmhHwIbkcrRJeyzuxPUSDGnqM92(value)
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all_filters': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.replace('=0','=')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd
agsNp4VJm8d3e = []
iuECgXkw3pcy1FAvK96G = []