# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'SERIES4WATCH'
headers = { 'User-Agent' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
qBAgzkG9oCL = '_SFW_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==210: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==211: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif mode==212: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==213: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==214: Ubud2NhHKRnMTvI5mprQBVqk80 = mz3ceo4GI6x(url)
	elif mode==215: Ubud2NhHKRnMTvI5mprQBVqk80 = iGd48DqxJApr(url)
	elif mode==218: Ubud2NhHKRnMTvI5mprQBVqk80 = BB9hWCvFx1()
	elif mode==219: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def BB9hWCvFx1():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'الموقع تغير بالكامل',message)
	return
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,219,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	url = S7EgasGcYdIo+'/getpostsPin?type=one&data=pin&limit=25'
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المميزة',url,211)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('FiltersButtons(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-get="(.*?)".*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		url = S7EgasGcYdIo+'/getposts?type=one&data='+cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,url,211)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('navigation-menu(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	kCIESuy4j5mVLZYtG9vDNnb7 = ['مسلسلات انمي','الرئيسية']
	for cX2SpPxGLmADTKl,title in items:
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if not any(value in title for value in kCIESuy4j5mVLZYtG9vDNnb7):
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,211)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('MediaGrid"(.*?)class="pagination"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		else: return
	items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	co0nsmRGuKp1HJaQN = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		if '/series/' in cX2SpPxGLmADTKl: continue
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl).strip('/')
		title = riUKNnOEtVwdj4(title)
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if '/film/' in cX2SpPxGLmADTKl or any(value in title for value in co0nsmRGuKp1HJaQN):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,212,RRx0ri8bETI)
		elif '/episode/' in cX2SpPxGLmADTKl and 'الحلقة' in title:
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if azhwpE0qmevcFobdRi:
				title = '_MOD_' + azhwpE0qmevcFobdRi[0]
				if title not in EaUe8ArOCD:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,213,RRx0ri8bETI)
					EaUe8ArOCD.append(title)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,213,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="pagination(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
			title = riUKNnOEtVwdj4(title)
			title = title.replace('الصفحة ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,211)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	dxn4RW6eo8BrJMiVtE2AgKjfXz5lQh,items,zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv = -1,[],[]
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-EPISODES-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('ti-list-numbered(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		GtnfmdqIOijegYu = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O.join(vvuraxgW7YLIZ4hU0MbCt)
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',GtnfmdqIOijegYu,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	items.append(url)
	items = set(items)
	for cX2SpPxGLmADTKl in items:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.strip('/')
		title = '_MOD_' + cX2SpPxGLmADTKl.split('/')[-1].replace('-',WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		KBtshNldD0nmAHTgEzcbIMWG9ri = AxTYMhRlfyskNc0X19dvwtS.findall('الحلقة-(\d+)',cX2SpPxGLmADTKl.split('/')[-1],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if KBtshNldD0nmAHTgEzcbIMWG9ri: KBtshNldD0nmAHTgEzcbIMWG9ri = KBtshNldD0nmAHTgEzcbIMWG9ri[0]
		else: KBtshNldD0nmAHTgEzcbIMWG9ri = '0'
		zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv.append([cX2SpPxGLmADTKl,title,KBtshNldD0nmAHTgEzcbIMWG9ri])
	items = sorted(zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv, reverse=False, key=lambda key: int(key[2]))
	FqvlMu4jXB6Oh = str(items).count('/season/')
	dxn4RW6eo8BrJMiVtE2AgKjfXz5lQh = str(items).count('/episode/')
	if FqvlMu4jXB6Oh>1 and dxn4RW6eo8BrJMiVtE2AgKjfXz5lQh>0 and '/season/' not in url:
		for cX2SpPxGLmADTKl,title,KBtshNldD0nmAHTgEzcbIMWG9ri in items:
			if '/season/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,213)
	else:
		for cX2SpPxGLmADTKl,title,KBtshNldD0nmAHTgEzcbIMWG9ri in items:
			if '/season/' not in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,212)
	return
def QgIZSJdUhsEnup8GPz3(url):
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	PCnrX0p2QmTt5ijBIkqu4La = url.split('/')
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in R8AE9e4mYxVhusL3Q:
		nUDgc4absePT2xMt = url.replace(PCnrX0p2QmTt5ijBIkqu4La[3],'watch')
		gwiPcfVU0T4qHMDF3Wdeh7YK = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-PLAY-2nd')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="servers-list(.*?)</div>',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if items:
				id = AxTYMhRlfyskNc0X19dvwtS.findall('post_id=(.*?)"',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if id:
					GKBq5DJiV9YMl4Fma3gr = id[0]
					for cX2SpPxGLmADTKl,title in items:
						cX2SpPxGLmADTKl = S7EgasGcYdIo+'/?postid='+GKBq5DJiV9YMl4Fma3gr+'&serverid='+cX2SpPxGLmADTKl+'?named='+title+'__watch'
						CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			else:
				items = AxTYMhRlfyskNc0X19dvwtS.findall('data-embedd=".*?(http.*?)("|&quot;)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				for cX2SpPxGLmADTKl,G20Fvhu5p3 in items:
					CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if '/download/' in R8AE9e4mYxVhusL3Q:
		nUDgc4absePT2xMt = url.replace(PCnrX0p2QmTt5ijBIkqu4La[3],'download')
		gwiPcfVU0T4qHMDF3Wdeh7YK = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-PLAY-3rd')
		id = AxTYMhRlfyskNc0X19dvwtS.findall('postId:"(.*?)"',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if id:
			GKBq5DJiV9YMl4Fma3gr = id[0]
			aNXRWYnbow7s8fpvLVK = { 'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O , 'X-Requested-With':'XMLHttpRequest' }
			nUDgc4absePT2xMt = S7EgasGcYdIo + '/ajaxCenter?_action=getdownloadlinks&postId='+GKBq5DJiV9YMl4Fma3gr
			gwiPcfVU0T4qHMDF3Wdeh7YK = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SERIES4WATCH-PLAY-4th')
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<h3.*?(\d+)(.*?)</div>',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if vvuraxgW7YLIZ4hU0MbCt:
				for gn321kUpDH8uExbi6wfrj07,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
					items = AxTYMhRlfyskNc0X19dvwtS.findall('<td>(.*?)<.*?href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					for name,cX2SpPxGLmADTKl in items:
						CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl+'?named='+name+'__download'+'____'+gn321kUpDH8uExbi6wfrj07)
			else:
				vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<h6(.*?)</table>',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = [gwiPcfVU0T4qHMDF3Wdeh7YK]
				for IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
					name = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					for cX2SpPxGLmADTKl in items:
						LLzkoiPsbBZ = '&&' + cX2SpPxGLmADTKl.split('/')[2].lower() + '&&'
						LLzkoiPsbBZ = LLzkoiPsbBZ.replace('.com&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('.co&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						LLzkoiPsbBZ = LLzkoiPsbBZ.replace('.net&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('.org&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						LLzkoiPsbBZ = LLzkoiPsbBZ.replace('.live&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('.online&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						LLzkoiPsbBZ = LLzkoiPsbBZ.replace('&&hd.',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('&&www.',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						LLzkoiPsbBZ = LLzkoiPsbBZ.replace('&&',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
						cX2SpPxGLmADTKl = cX2SpPxGLmADTKl + '?named=' + name + LLzkoiPsbBZ + '__download'
						CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo + '/search?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return