# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'GOOGLESEARCH'
qBAgzkG9oCL = '_GOS_'
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe):
	if   t5fhagjUGXk0ynOlJWeAb==1010: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif t5fhagjUGXk0ynOlJWeAb==1011: Ubud2NhHKRnMTvI5mprQBVqk80 = hh5SgxeGL2MQFY3D60EAC(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1012: Ubud2NhHKRnMTvI5mprQBVqk80 = GFn6mbqLvsuEMHjD9h(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1013: Ubud2NhHKRnMTvI5mprQBVqk80 = I3Ikr2Pwyi5fGjBQ()
	elif t5fhagjUGXk0ynOlJWeAb==1014: Ubud2NhHKRnMTvI5mprQBVqk80 = t8ahrc1XBJiNKZwI7bW0yS9ed(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1015: Ubud2NhHKRnMTvI5mprQBVqk80 = HB7zjXZ9fsigyqxULoKEhM5v(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1016: Ubud2NhHKRnMTvI5mprQBVqk80 = IMhz86XNJAWojnawk02ROxYr(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1018: Ubud2NhHKRnMTvI5mprQBVqk80 = GpNCPu2zRWrlMkiQdTf5J3Ky0L7ZxB(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==1019: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(ggM5TzCxq24sDYLiEatpdSK7FQyGe,False)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder','بحث جوجل جديد',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1019)
	w3BfOGLdXcWzbiC1PYx9mE('link','كيف يعمل بحث جوجل','',1013)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'==== كلمات البحث المخزنة ===='+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	tt5rQBVLH9fE7d4FDAcUIjSgO = dYMLGvgfk4(mmEuUR4JdaHtAsS,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if tt5rQBVLH9fE7d4FDAcUIjSgO:
		tt5rQBVLH9fE7d4FDAcUIjSgO = tt5rQBVLH9fE7d4FDAcUIjSgO['__SEQUENCED_COLUMNS__']
		for a9YrjQPdZ8JicSD2LbG in reversed(tt5rQBVLH9fE7d4FDAcUIjSgO):
			w3BfOGLdXcWzbiC1PYx9mE('folder',a9YrjQPdZ8JicSD2LbG,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1019,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,a9YrjQPdZ8JicSD2LbG)
	return
def GpNCPu2zRWrlMkiQdTf5J3Ky0L7ZxB(search):
	E3FwPg9Z6KB(search,True)
	GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def E3FwPg9Z6KB(search,kSIiQMF8Zqh=False):
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	f1EhmRrADV8KxiNQcayZ6tswPI = search.replace(qBAgzkG9oCL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).lower()
	B9exZVjCUyFQ3o7WSXvzuq0dT,K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = [],[],[]
	if not kSIiQMF8Zqh:
		B9exZVjCUyFQ3o7WSXvzuq0dT = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GOOGLESEARCH_RESULTS',f1EhmRrADV8KxiNQcayZ6tswPI)
		if B9exZVjCUyFQ3o7WSXvzuq0dT: K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = B9exZVjCUyFQ3o7WSXvzuq0dT
	if kSIiQMF8Zqh or not B9exZVjCUyFQ3o7WSXvzuq0dT:
		import gSCos1rw82
		gSCos1rw82.t0Q5BsEv3l8kVSbAz7iHwOp(f1EhmRrADV8KxiNQcayZ6tswPI,'_GOOGLE',True)
		zQ43tFEoMfdAIKT = wwU60DVYPxFtWvygzZs(f1EhmRrADV8KxiNQcayZ6tswPI)
		for Uz7N5KAHwQ93iShW1xj in zQ43tFEoMfdAIKT:
			name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR = Uz7N5KAHwQ93iShW1xj
			if z4t2nu5ryZjPR in gI02HPoNJVx6rcw5jisfKnUyuqSv: K3jUGfWFVt6RSyZMPYXaq5r.append(Uz7N5KAHwQ93iShW1xj)
			else: Irzw8mLOp9ogvT5JBdDsMuKn.append(Uz7N5KAHwQ93iShW1xj)
		K3jUGfWFVt6RSyZMPYXaq5r = sorted(K3jUGfWFVt6RSyZMPYXaq5r,reverse=pLwgjkuTs6CS,key=lambda key: key[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
		Irzw8mLOp9ogvT5JBdDsMuKn = sorted(Irzw8mLOp9ogvT5JBdDsMuKn,reverse=pLwgjkuTs6CS,key=lambda key: key[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
		JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,'GOOGLESEARCH_RESULTS',f1EhmRrADV8KxiNQcayZ6tswPI,[K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn],QT1GPoWB7px)
		rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DETAILED_GOOGLE',f1EhmRrADV8KxiNQcayZ6tswPI)
		gSCos1rw82.t0Q5BsEv3l8kVSbAz7iHwOp(f1EhmRrADV8KxiNQcayZ6tswPI,'_GOOGLE',False)
		rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+f1EhmRrADV8KxiNQcayZ6tswPI+"')")
		if K3jUGfWFVt6RSyZMPYXaq5r: w4dBvakygFs2IZO1Azt('','',F91YEzyWak5,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(K3jUGfWFVt6RSyZMPYXaq5r))+'  مواقع')
		else: K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = NUG5YBbrnOcdiI8mAVF97Jh2ewtk(f1EhmRrADV8KxiNQcayZ6tswPI,pLwgjkuTs6CS)
	w3BfOGLdXcWzbiC1PYx9mE('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('folder','بحث منفرد لمواقع جوجل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1011,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder','نتائج البحث مفصلة - '+f1EhmRrADV8KxiNQcayZ6tswPI,'opened_sites_google',1012,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('folder','نتائج البحث مقسمة - '+f1EhmRrADV8KxiNQcayZ6tswPI,'listed_sites_google',1012,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder','مواقع جوجل ('+str(len(K3jUGfWFVt6RSyZMPYXaq5r))+') - '+f1EhmRrADV8KxiNQcayZ6tswPI,'',1016,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f1EhmRrADV8KxiNQcayZ6tswPI)
	w3BfOGLdXcWzbiC1PYx9mE('link','إعادة بحث جوجل - '+f1EhmRrADV8KxiNQcayZ6tswPI,'',1018,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,search)
	return
def IMhz86XNJAWojnawk02ROxYr(f1EhmRrADV8KxiNQcayZ6tswPI):
	K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = NUG5YBbrnOcdiI8mAVF97Jh2ewtk(f1EhmRrADV8KxiNQcayZ6tswPI)
	if not K3jUGfWFVt6RSyZMPYXaq5r and not Irzw8mLOp9ogvT5JBdDsMuKn: return
	sRozCIrk8MQGWwfEJPYHt = {}
	for name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR in K3jUGfWFVt6RSyZMPYXaq5r: sRozCIrk8MQGWwfEJPYHt[z4t2nu5ryZjPR] = name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR
	ouS6Wib0YIF9Hek5dVJK = list(sRozCIrk8MQGWwfEJPYHt.keys())
	import gSCos1rw82
	yEjQLZ4Neztkq9l0sXuxSndwD6hi1C = gSCos1rw82.jiqeWO1UaLAVDZX0GRbMEhgJ(ouS6Wib0YIF9Hek5dVJK)
	for z4t2nu5ryZjPR in yEjQLZ4Neztkq9l0sXuxSndwD6hi1C:
		if isinstance(z4t2nu5ryZjPR,tuple):
			drzqWFkSHD.menuItemsLIST.append(z4t2nu5ryZjPR)
			continue
		name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR = sRozCIrk8MQGWwfEJPYHt[z4t2nu5ryZjPR]
		Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
		w3BfOGLdXcWzbiC1PYx9mE('folder',sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g+name,cX2SpPxGLmADTKl,1014,XDe1mWwvZJbRSgOkoYd6UctB,'',z4t2nu5ryZjPR)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+'مواقع بجوجل غير موجودة بالبرنامج'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1015)
	Irzw8mLOp9ogvT5JBdDsMuKn = sorted(Irzw8mLOp9ogvT5JBdDsMuKn,reverse=pLwgjkuTs6CS,key=lambda key: key[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
	for name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR in Irzw8mLOp9ogvT5JBdDsMuKn:
		w3BfOGLdXcWzbiC1PYx9mE('link','_GOS_'+name,cX2SpPxGLmADTKl,1015,XDe1mWwvZJbRSgOkoYd6UctB,'',z4t2nu5ryZjPR)
	return
def NUG5YBbrnOcdiI8mAVF97Jh2ewtk(f1EhmRrADV8KxiNQcayZ6tswPI,gdRFZpso5jX4MAx0t2aLuiQ6ITKwr=NFGqKBLtvUZn1S3dau):
	K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = [],[]
	if gdRFZpso5jX4MAx0t2aLuiQ6ITKwr:
		B9exZVjCUyFQ3o7WSXvzuq0dT = dYMLGvgfk4(mmEuUR4JdaHtAsS,'list','GOOGLESEARCH_RESULTS',f1EhmRrADV8KxiNQcayZ6tswPI)
		if B9exZVjCUyFQ3o7WSXvzuq0dT: K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = B9exZVjCUyFQ3o7WSXvzuq0dT
	if not K3jUGfWFVt6RSyZMPYXaq5r and not Irzw8mLOp9ogvT5JBdDsMuKn: w4dBvakygFs2IZO1Azt('','',F91YEzyWak5,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn
def GFn6mbqLvsuEMHjD9h(Lc1xDe8hOMKoA,f1EhmRrADV8KxiNQcayZ6tswPI):
	K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = NUG5YBbrnOcdiI8mAVF97Jh2ewtk(f1EhmRrADV8KxiNQcayZ6tswPI)
	if not K3jUGfWFVt6RSyZMPYXaq5r and not Irzw8mLOp9ogvT5JBdDsMuKn: return
	k4iZUnv1wgOGsLX0mz5xKcIP,zL7SYRfcdJT46QDOoG = [],{}
	for name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR in K3jUGfWFVt6RSyZMPYXaq5r:
		k4iZUnv1wgOGsLX0mz5xKcIP.append(z4t2nu5ryZjPR)
		zL7SYRfcdJT46QDOoG[z4t2nu5ryZjPR] = Pk9nN32Z1jSKTLw(text)
	import gSCos1rw82
	gSCos1rw82.Tuzc4GQ9PtdLfeh(f1EhmRrADV8KxiNQcayZ6tswPI,Lc1xDe8hOMKoA,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,k4iZUnv1wgOGsLX0mz5xKcIP,zL7SYRfcdJT46QDOoG)
	return
def hh5SgxeGL2MQFY3D60EAC(f1EhmRrADV8KxiNQcayZ6tswPI):
	K3jUGfWFVt6RSyZMPYXaq5r,Irzw8mLOp9ogvT5JBdDsMuKn = NUG5YBbrnOcdiI8mAVF97Jh2ewtk(f1EhmRrADV8KxiNQcayZ6tswPI)
	if not K3jUGfWFVt6RSyZMPYXaq5r and not Irzw8mLOp9ogvT5JBdDsMuKn: return
	sRozCIrk8MQGWwfEJPYHt = {}
	for name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR in K3jUGfWFVt6RSyZMPYXaq5r:
		sRozCIrk8MQGWwfEJPYHt[z4t2nu5ryZjPR] = name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR
	ouS6Wib0YIF9Hek5dVJK = list(sRozCIrk8MQGWwfEJPYHt.keys())
	import gSCos1rw82
	yEjQLZ4Neztkq9l0sXuxSndwD6hi1C = gSCos1rw82.jiqeWO1UaLAVDZX0GRbMEhgJ(ouS6Wib0YIF9Hek5dVJK)
	for z4t2nu5ryZjPR in yEjQLZ4Neztkq9l0sXuxSndwD6hi1C:
		if isinstance(z4t2nu5ryZjPR,tuple):
			drzqWFkSHD.menuItemsLIST.append(z4t2nu5ryZjPR)
			continue
		name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR = sRozCIrk8MQGWwfEJPYHt[z4t2nu5ryZjPR]
		Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
		text = Pk9nN32Z1jSKTLw(text)
		name = name+' - '+f1EhmRrADV8KxiNQcayZ6tswPI
		w3BfOGLdXcWzbiC1PYx9mE('folder',sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g+name,z4t2nu5ryZjPR,548,XDe1mWwvZJbRSgOkoYd6UctB,'',text)
	return
def Pk9nN32Z1jSKTLw(title):
	azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة)',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	uoH6T37WPfCdv8JLnYZjK2r = azhwpE0qmevcFobdRi[0][0] if azhwpE0qmevcFobdRi else title
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	uoH6T37WPfCdv8JLnYZjK2r = uoH6T37WPfCdv8JLnYZjK2r.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return uoH6T37WPfCdv8JLnYZjK2r
def wwU60DVYPxFtWvygzZs(search):
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	nUDgc4absePT2xMt = url+'&start=0&num=100&tbm=vid&udm=7'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'GOOGLESEARCH-SEARCH-1st')
	if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded: return []
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	bm18TiXKAHfIwxcgQ3Pr = oNlez5gnM9x2B4.path.join(jaVSoQGFYUlCugWK9kLc,'googlesearch')
	if not oNlez5gnM9x2B4.path.exists(bm18TiXKAHfIwxcgQ3Pr):
		try: oNlez5gnM9x2B4.makedirs(bm18TiXKAHfIwxcgQ3Pr)
		except: pass
	items = []
	GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if GtnfmdqIOijegYu:
		for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
			cX2SpPxGLmADTKl,title,text,E7MF9aYlV4Q0,name = IxdmfnvhCA8Bc9ZlQ45oiqN
			E7MF9aYlV4Q0 = ''
			items.append([cX2SpPxGLmADTKl,title,text,name,E7MF9aYlV4Q0])
	else:
		nUDgc4absePT2xMt = url+'&start=0&num=200'
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET::SCRAPERS',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'GOOGLESEARCH-SEARCH-2nd')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded: return []
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not GtnfmdqIOijegYu: GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
			IxdmfnvhCA8Bc9ZlQ45oiqN = rKY1tyQvh9OCxE2nl('list',IxdmfnvhCA8Bc9ZlQ45oiqN)
			if len(IxdmfnvhCA8Bc9ZlQ45oiqN)>17:
				cX2SpPxGLmADTKl = IxdmfnvhCA8Bc9ZlQ45oiqN[17]
				title,text,name,E7MF9aYlV4Q0 = IxdmfnvhCA8Bc9ZlQ45oiqN[31][0:4]
				items.append([cX2SpPxGLmADTKl,title,text,name,E7MF9aYlV4Q0])
	Vydb8QZiPDWknSAJN0t9sELu,uBcQWghrt1RL7ekb = [],[]
	for Uz7N5KAHwQ93iShW1xj in items:
		cX2SpPxGLmADTKl,title,text,name,E7MF9aYlV4Q0 = Uz7N5KAHwQ93iShW1xj
		name = name.strip(' ')
		if not name: name = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
		name = bLXh6Qy5Tewk(name)
		if 'http://' in E7MF9aYlV4Q0 or 'https://' in E7MF9aYlV4Q0: XDe1mWwvZJbRSgOkoYd6UctB = E7MF9aYlV4Q0
		elif 'data:image/' in E7MF9aYlV4Q0 and ';base64,' in E7MF9aYlV4Q0:
			S1piLbN37HPv0ld5Kmce6TFuOW94 = AxTYMhRlfyskNc0X19dvwtS.findall('data:image/(\w+);base64,',E7MF9aYlV4Q0)
			S1piLbN37HPv0ld5Kmce6TFuOW94 = S1piLbN37HPv0ld5Kmce6TFuOW94[0]
			XDe1mWwvZJbRSgOkoYd6UctB = oNlez5gnM9x2B4.path.join(bm18TiXKAHfIwxcgQ3Pr,name+'.'+S1piLbN37HPv0ld5Kmce6TFuOW94)
			if not oNlez5gnM9x2B4.path.exists(XDe1mWwvZJbRSgOkoYd6UctB):
				E7MF9aYlV4Q0 = E7MF9aYlV4Q0.replace('\\u003d','=')
				E7MF9aYlV4Q0 = E7MF9aYlV4Q0.replace('data:image/'+S1piLbN37HPv0ld5Kmce6TFuOW94+';base64,','')
				IEUDNeustx = j3kWVqdguK6O2QDmMf.b64decode(E7MF9aYlV4Q0)
				open(XDe1mWwvZJbRSgOkoYd6UctB,'wb').write(IEUDNeustx)
		else: XDe1mWwvZJbRSgOkoYd6UctB = ''
		z4t2nu5ryZjPR = p8vEbFa43hfe9AYRPxIut(name,cX2SpPxGLmADTKl)
		if z4t2nu5ryZjPR not in uBcQWghrt1RL7ekb:
			uBcQWghrt1RL7ekb.append(z4t2nu5ryZjPR)
			name = dOui5LJeABG0TYcMj(z4t2nu5ryZjPR)
			Vydb8QZiPDWknSAJN0t9sELu.append([name,cX2SpPxGLmADTKl,title,text,XDe1mWwvZJbRSgOkoYd6UctB,z4t2nu5ryZjPR])
	return Vydb8QZiPDWknSAJN0t9sELu
def t8ahrc1XBJiNKZwI7bW0yS9ed(cX2SpPxGLmADTKl,z4t2nu5ryZjPR):
	Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
	if sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g: Rdnmer47TgYcStA19l8pUj2XBuL3b()
	else: HB7zjXZ9fsigyqxULoKEhM5v()
	return
def I3Ikr2Pwyi5fGjBQ():
	w4dBvakygFs2IZO1Azt('','',F91YEzyWak5,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def HB7zjXZ9fsigyqxULoKEhM5v(z4t2nu5ryZjPR=''):
	w4dBvakygFs2IZO1Azt('','',z4t2nu5ryZjPR,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def p8vEbFa43hfe9AYRPxIut(name,cX2SpPxGLmADTKl):
	LD9qAHfuCQgp1VT8xeyXIaPk3027b = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	XQv4cBgdZD5k6OPwy3alsEGxtA = name.lower()
	vv52HizJKaC = ''
	for key in list(LD9qAHfuCQgp1VT8xeyXIaPk3027b.keys()):
		if key.lower() in XQv4cBgdZD5k6OPwy3alsEGxtA: vv52HizJKaC = LD9qAHfuCQgp1VT8xeyXIaPk3027b[key]
	if not vv52HizJKaC:
		evGVuBpQUEL = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'url')
		for z4t2nu5ryZjPR in list(drzqWFkSHD.SITESURLS.keys()):
			mVh58FX3zfTpEu = UUmYkruGeM3p8sKi6o2fcI(drzqWFkSHD.SITESURLS[z4t2nu5ryZjPR][0],'url')
			if evGVuBpQUEL==mVh58FX3zfTpEu: vv52HizJKaC = z4t2nu5ryZjPR
	if not vv52HizJKaC:
		XQv4cBgdZD5k6OPwy3alsEGxtA = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
		for z4t2nu5ryZjPR in list(drzqWFkSHD.SITESURLS.keys()):
			B01Fh9czqo = UUmYkruGeM3p8sKi6o2fcI(drzqWFkSHD.SITESURLS[z4t2nu5ryZjPR][0],'name')
			if XQv4cBgdZD5k6OPwy3alsEGxtA==B01Fh9czqo: vv52HizJKaC = z4t2nu5ryZjPR
	if not vv52HizJKaC: vv52HizJKaC = name
	vv52HizJKaC = vv52HizJKaC.upper()
	return vv52HizJKaC