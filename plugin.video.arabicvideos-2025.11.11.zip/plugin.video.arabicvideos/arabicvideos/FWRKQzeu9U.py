# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'FASELHD2'
headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
qBAgzkG9oCL = '_FH2_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
kCIESuy4j5mVLZYtG9vDNnb7 = ['FaselHD']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==590: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==591: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==592: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==593: Ubud2NhHKRnMTvI5mprQBVqk80 = ErZkM18Pf2S0VKNAzb(url,text)
	elif mode==599: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	GGRexoVTLjusn6q = S7EgasGcYdIo
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',GGRexoVTLjusn6q,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD2-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',GGRexoVTLjusn6q,599,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<h3>(.*?)<.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	u74UPEicpBdq32C = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	for title,cX2SpPxGLmADTKl in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if any(value in title for value in kCIESuy4j5mVLZYtG9vDNnb7): continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,591,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured'+str(u74UPEicpBdq32C))
		u74UPEicpBdq32C += xD9WeoEAsX7
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"main-menu"(.*?)</nav>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		pyh0NfBVUbctiAQ12 = AxTYMhRlfyskNc0X19dvwtS.findall('<li (.*?)</li>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for oFQHL7AaItXmfCz4yPKT0pc1ie in pyh0NfBVUbctiAQ12:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',oFQHL7AaItXmfCz4yPKT0pc1ie,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+cX2SpPxGLmADTKl
				w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,591)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,i1svWTIM79yezDZXt2gnACupwY=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD2-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = []
	if 'featured' in i1svWTIM79yezDZXt2gnACupwY:
		u74UPEicpBdq32C = i1svWTIM79yezDZXt2gnACupwY[-xD9WeoEAsX7]
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"boxes--holder"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[int(u74UPEicpBdq32C)]
	elif i1svWTIM79yezDZXt2gnACupwY=='filters':
		vvuraxgW7YLIZ4hU0MbCt = [R8AE9e4mYxVhusL3Q.replace('\\/','/').replace('\\"','"')]
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"boxes--holder"(.*?)"pagination"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	EaUe8ArOCD = []
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		try: title = title.encode(P7PMpzWXGkQcViT56ANdREyejZ8Cgo).decode(RMGz7OiD1e30P)
		except: pass
		title = riUKNnOEtVwdj4(title)
		if any(value in title.lower() for value in kCIESuy4j5mVLZYtG9vDNnb7): continue
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if '/movseries/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,591,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi:
			title = '_MOD_'+azhwpE0qmevcFobdRi[0][0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,593,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c): w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,592,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,593,RRx0ri8bETI)
	if i1svWTIM79yezDZXt2gnACupwY=='filters':
		bWKf9xzqe5TVNtAlsMoI = AxTYMhRlfyskNc0X19dvwtS.findall('"more_button_page":(.*?),',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if bWKf9xzqe5TVNtAlsMoI:
			count = bWKf9xzqe5TVNtAlsMoI[0]
			cX2SpPxGLmADTKl = url+'/offset/'+count
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة أخرى',cX2SpPxGLmADTKl,591,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filters')
	elif 'featured' not in i1svWTIM79yezDZXt2gnACupwY:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="pagination(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				title = riUKNnOEtVwdj4(title)
				cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,591,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'details4')
	return
def ErZkM18Pf2S0VKNAzb(url,data=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD2-SEASONS_EPISODES-1st')
		R8AE9e4mYxVhusL3Q = '"EpisodesList"'+gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content+'</div>'
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD2-SEASONS_EPISODES-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	E7MF9aYlV4Q0 = AxTYMhRlfyskNc0X19dvwtS.findall('"inner--image"><img src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	RRx0ri8bETI = E7MF9aYlV4Q0[nUaVQsoA6EXcK4Odht5wCge0J8Pib] if E7MF9aYlV4Q0 else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	items = []
	if not data:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"SeasonsList"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if len(items)>1:
				for YDidHrbPsIFGoTAvlwtL,nRW2P4Ke3z7,title in items:
					cX2SpPxGLmADTKl = S7EgasGcYdIo+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					bo9ixEyvnlwmW = 'season='+nRW2P4Ke3z7+'&post_id='+YDidHrbPsIFGoTAvlwtL
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,593,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bo9ixEyvnlwmW)
		data = NFGqKBLtvUZn1S3dau
	if data and len(items)<H3OKMjDG1evnl4Ruiz:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"EpisodesList"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<em>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,KK59iLYwJ6cWfItqyBjGRoF,uoH6T37WPfCdv8JLnYZjK2r in items:
				title = KK59iLYwJ6cWfItqyBjGRoF+WRsuxHTjDgYCIpoMQzLFAtS8rikP+uoH6T37WPfCdv8JLnYZjK2r
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,592,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	url = url.strip('/')+'/watch/'
	dU17fayKLj4kABu,VVvfWS9rl36Lq1g4nx,GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = [],[],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FASELHD2-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	DLwj8YRTnlifSUm9EoXvV1 = AxTYMhRlfyskNc0X19dvwtS.findall('العمر :.*?<strong">(.*?)</strong>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if DLwj8YRTnlifSUm9EoXvV1 and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,DLwj8YRTnlifSUm9EoXvV1): return
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('<iframe src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"main--contents"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for uuICHSBLGTPsV92nQbJ6aOidzY1,YDidHrbPsIFGoTAvlwtL,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+YDidHrbPsIFGoTAvlwtL+'&i='+uuICHSBLGTPsV92nQbJ6aOidzY1
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+title+'__watch')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"downloads"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,name in items:
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+name+'__download')
	for T5Pa8nUbDMGsfWmCJKgHtj3 in dU17fayKLj4kABu:
		cX2SpPxGLmADTKl,name = T5Pa8nUbDMGsfWmCJKgHtj3.split('?named')
		if cX2SpPxGLmADTKl not in VVvfWS9rl36Lq1g4nx:
			VVvfWS9rl36Lq1g4nx.append(cX2SpPxGLmADTKl)
			GQAq8OnFcBve2Zi4oLH0mzNWU6hYK.append(T5Pa8nUbDMGsfWmCJKgHtj3)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(GQAq8OnFcBve2Zi4oLH0mzNWU6hYK,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	GGRexoVTLjusn6q = S7EgasGcYdIo
	url = GGRexoVTLjusn6q+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'details5')
	return