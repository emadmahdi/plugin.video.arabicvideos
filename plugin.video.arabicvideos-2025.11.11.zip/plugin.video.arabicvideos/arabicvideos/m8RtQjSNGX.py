# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'TVFUN'
qBAgzkG9oCL = '_TVF_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['بث مباشر']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==460: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==461: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==462: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==463: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==469: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TVFUN-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,469,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"menu-btn"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)</span>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,461)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,gV1lKIhwSm0GQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	items = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TVFUN-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="head-title"(.*?)id="footer"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		EaUe8ArOCD = []
		Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
			title = '_MOD_'+title.replace('<br>',WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
			cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl)
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,462,RRx0ri8bETI)
			elif azhwpE0qmevcFobdRi and 'الحلقة' in title:
				title = '_MOD_' + azhwpE0qmevcFobdRi[0]
				if title not in EaUe8ArOCD:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,463,RRx0ri8bETI)
					EaUe8ArOCD.append(title)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,463,RRx0ri8bETI)
	if gV1lKIhwSm0GQ!='latest':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('<a href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				if cX2SpPxGLmADTKl=="": continue
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
				if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,461)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TVFUN-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="head-title"(.*?)id="footer"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
				title = '_MOD_'+title.replace('<br>',WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,462,RRx0ri8bETI)
		else:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('class="episode.*?href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,462)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if cX2SpPxGLmADTKl=="": continue
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
			if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,463)
	return
def QgIZSJdUhsEnup8GPz3(url):
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	nUDgc4absePT2xMt = url.replace('/video/','/watch/')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TVFUN-PLAY-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('VideoServers"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for QQRFEgvuBM8hTo5K,name in BA01W9olieErLycV7kwFvOhH5Y3ms:
			QQRFEgvuBM8hTo5K = QQRFEgvuBM8hTo5K[2:]
			if hT1JIgqPQsUOZp5tjCX0E: QQRFEgvuBM8hTo5K = QQRFEgvuBM8hTo5K.decode(RMGz7OiD1e30P)
			QQRFEgvuBM8hTo5K = j3kWVqdguK6O2QDmMf.b64decode(QQRFEgvuBM8hTo5K)
			if fOohwvakqi29cx0l3yt5mzrAGpEg: QQRFEgvuBM8hTo5K = QQRFEgvuBM8hTo5K.decode(RMGz7OiD1e30P)
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)"',QQRFEgvuBM8hTo5K,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
			if 'http' not in cX2SpPxGLmADTKl:
				if '//' in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
				else: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
			if cX2SpPxGLmADTKl not in CBL4OQVtWbMAycUGl7Ex2SKZF:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+name+'__watch'
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search:
		search = TwDBf3QbKOnrmd5u9()
		if not search: return
	if WRsuxHTjDgYCIpoMQzLFAtS8rikP in search:
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = S7EgasGcYdIo+'/q/'+search+'/'
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return