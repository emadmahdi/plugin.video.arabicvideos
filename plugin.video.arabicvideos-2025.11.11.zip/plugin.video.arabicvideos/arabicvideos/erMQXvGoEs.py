# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
qqJpX5yPB1ldDwvYTa6cbtK0FsUS2r = 'FAVORITES'
def DDZptNJ0s6GAThr5UdqyBH(t5fhagjUGXk0ynOlJWeAb,X0UVekNKCqm2fOMy6FuWDE5SB):
	if   t5fhagjUGXk0ynOlJWeAb==270: lwfKMcpWgebLrA5sSa68 = B4Fd26pWwzh5RZQgYa(X0UVekNKCqm2fOMy6FuWDE5SB)
	else: lwfKMcpWgebLrA5sSa68 = False
	return lwfKMcpWgebLrA5sSa68
def Vve4TQb2KBYpr9OyRLFkzAwq8sS6(WPHK5192hQ8lmL34OukgqMUS0CVF,X0UVekNKCqm2fOMy6FuWDE5SB,KuBIS516jaqMYhUXPJto9d):
	if not WPHK5192hQ8lmL34OukgqMUS0CVF: return
	if   KuBIS516jaqMYhUXPJto9d=='UP1'	: m876dxiwKcuaE(X0UVekNKCqm2fOMy6FuWDE5SB,True,xD9WeoEAsX7)
	elif KuBIS516jaqMYhUXPJto9d=='DOWN1'	: m876dxiwKcuaE(X0UVekNKCqm2fOMy6FuWDE5SB,False,xD9WeoEAsX7)
	elif KuBIS516jaqMYhUXPJto9d=='UP4'	: m876dxiwKcuaE(X0UVekNKCqm2fOMy6FuWDE5SB,True,gybxTLFEw2)
	elif KuBIS516jaqMYhUXPJto9d=='DOWN4'	: m876dxiwKcuaE(X0UVekNKCqm2fOMy6FuWDE5SB,False,gybxTLFEw2)
	elif KuBIS516jaqMYhUXPJto9d=='ADD1'	: MMVzLvZBm1P0khQRy5Edn3rXNiK9w(X0UVekNKCqm2fOMy6FuWDE5SB)
	elif KuBIS516jaqMYhUXPJto9d=='REMOVE1': RhDToGXKfZt(X0UVekNKCqm2fOMy6FuWDE5SB)
	elif KuBIS516jaqMYhUXPJto9d=='DELETELIST': tt7xCSzUP5IAvk6p(X0UVekNKCqm2fOMy6FuWDE5SB)
	return
def B4Fd26pWwzh5RZQgYa(X0UVekNKCqm2fOMy6FuWDE5SB):
	ErRs8CvimPy = GI8zDQKfRv40()
	if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()):
		try:
			KB24UEbGrgTQe8J1Nx6f = ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]
			if nUaVQsoA6EXcK4Odht5wCge0J8Pib and X0UVekNKCqm2fOMy6FuWDE5SB in ['5','11','12','13']:
				for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM in KB24UEbGrgTQe8J1Nx6f:
					if ZJksHpSUNh2f=='video':
						w3BfOGLdXcWzbiC1PYx9mE('video',qFghPAi5yz9Vf3NLwo0nuprl+'تشغيل من الأعلى إلى الأسفل'+so4Z8OUJ5E,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF)
						w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
						break
			for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM in KB24UEbGrgTQe8J1Nx6f:
				w3BfOGLdXcWzbiC1PYx9mE(ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM)
		except:
			ErRs8CvimPy = ApkBz5YUgSLJZF(ecXIT7UM4l0xYPFjGf3t)
			KB24UEbGrgTQe8J1Nx6f = ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]
			for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM in KB24UEbGrgTQe8J1Nx6f:
				w3BfOGLdXcWzbiC1PYx9mE(ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM)
	return
def MMVzLvZBm1P0khQRy5Edn3rXNiK9w(X0UVekNKCqm2fOMy6FuWDE5SB):
	ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM = XjPqWt1BdDk(utdV6CEfRBM)
	if X0UVekNKCqm2fOMy6FuWDE5SB in ['5','11','12','13'] and ZJksHpSUNh2f!='video':
		w4dBvakygFs2IZO1Azt('','',F91YEzyWak5,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	ahWqoR6MukN1XzZ = ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,xxRmTpBZPjKDXoaVnbSzAM
	ErRs8CvimPy = GI8zDQKfRv40()
	LLUN6d32Oz = {}
	for qtiYBKzPhLrpvuwDWd in list(ErRs8CvimPy.keys()):
		if qtiYBKzPhLrpvuwDWd!=X0UVekNKCqm2fOMy6FuWDE5SB: LLUN6d32Oz[qtiYBKzPhLrpvuwDWd] = ErRs8CvimPy[qtiYBKzPhLrpvuwDWd]
		else:
			if usYnJBXhFT and usYnJBXhFT!='..':
				GwpZgEvxMm64ReCi3JTact = ErRs8CvimPy[qtiYBKzPhLrpvuwDWd]
				if ahWqoR6MukN1XzZ in GwpZgEvxMm64ReCi3JTact:
					aDCgn69ckvy5JGNqWo4wYTQi8h03H = GwpZgEvxMm64ReCi3JTact.index(ahWqoR6MukN1XzZ)
					del GwpZgEvxMm64ReCi3JTact[aDCgn69ckvy5JGNqWo4wYTQi8h03H]
				iuTAj3rwcs9lzOHftSKYUxME = GwpZgEvxMm64ReCi3JTact+[ahWqoR6MukN1XzZ]
				LLUN6d32Oz[qtiYBKzPhLrpvuwDWd] = iuTAj3rwcs9lzOHftSKYUxME
			else: LLUN6d32Oz[qtiYBKzPhLrpvuwDWd] = ErRs8CvimPy[qtiYBKzPhLrpvuwDWd]
	if X0UVekNKCqm2fOMy6FuWDE5SB not in list(LLUN6d32Oz.keys()): LLUN6d32Oz[X0UVekNKCqm2fOMy6FuWDE5SB] = [ahWqoR6MukN1XzZ]
	IIJjOxgEYhf2T4GtHXU = str(LLUN6d32Oz)
	if fOohwvakqi29cx0l3yt5mzrAGpEg: IIJjOxgEYhf2T4GtHXU = IIJjOxgEYhf2T4GtHXU.encode(RMGz7OiD1e30P)
	open(ecXIT7UM4l0xYPFjGf3t,'wb').write(IIJjOxgEYhf2T4GtHXU)
	return
def RhDToGXKfZt(X0UVekNKCqm2fOMy6FuWDE5SB):
	ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM = XjPqWt1BdDk(utdV6CEfRBM)
	ahWqoR6MukN1XzZ = ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,xxRmTpBZPjKDXoaVnbSzAM
	ErRs8CvimPy = GI8zDQKfRv40()
	if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()) and ahWqoR6MukN1XzZ in ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]:
		ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB].remove(ahWqoR6MukN1XzZ)
		if len(ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB])==nUaVQsoA6EXcK4Odht5wCge0J8Pib: del ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]
		IIJjOxgEYhf2T4GtHXU = str(ErRs8CvimPy)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: IIJjOxgEYhf2T4GtHXU = IIJjOxgEYhf2T4GtHXU.encode(RMGz7OiD1e30P)
		open(ecXIT7UM4l0xYPFjGf3t,'wb').write(IIJjOxgEYhf2T4GtHXU)
	return
def m876dxiwKcuaE(X0UVekNKCqm2fOMy6FuWDE5SB,IlsGn04eFhyRbpiYzfktHmwLQPgO,GZmzws9echbLy):
	ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM = XjPqWt1BdDk(utdV6CEfRBM)
	ahWqoR6MukN1XzZ = ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,xxRmTpBZPjKDXoaVnbSzAM
	ErRs8CvimPy = GI8zDQKfRv40()
	if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()):
		GwpZgEvxMm64ReCi3JTact = ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]
		if ahWqoR6MukN1XzZ not in GwpZgEvxMm64ReCi3JTact: return
		JXvFnjekVOpQCq6MWxRcGfN = len(GwpZgEvxMm64ReCi3JTact)
		for WWlVCHMzIF7qwQGvma6yd in range(nUaVQsoA6EXcK4Odht5wCge0J8Pib,GZmzws9echbLy):
			PSdAh7t91BGc = GwpZgEvxMm64ReCi3JTact.index(ahWqoR6MukN1XzZ)
			if IlsGn04eFhyRbpiYzfktHmwLQPgO: HfsqX895TalvBrMejQx = PSdAh7t91BGc-xD9WeoEAsX7
			else: HfsqX895TalvBrMejQx = PSdAh7t91BGc+xD9WeoEAsX7
			if HfsqX895TalvBrMejQx>=JXvFnjekVOpQCq6MWxRcGfN: HfsqX895TalvBrMejQx = HfsqX895TalvBrMejQx-JXvFnjekVOpQCq6MWxRcGfN
			if HfsqX895TalvBrMejQx<nUaVQsoA6EXcK4Odht5wCge0J8Pib: HfsqX895TalvBrMejQx = HfsqX895TalvBrMejQx+JXvFnjekVOpQCq6MWxRcGfN
			GwpZgEvxMm64ReCi3JTact.insert(HfsqX895TalvBrMejQx, GwpZgEvxMm64ReCi3JTact.pop(PSdAh7t91BGc))
		ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB] = GwpZgEvxMm64ReCi3JTact
		IIJjOxgEYhf2T4GtHXU = str(ErRs8CvimPy)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: IIJjOxgEYhf2T4GtHXU = IIJjOxgEYhf2T4GtHXU.encode(RMGz7OiD1e30P)
		open(ecXIT7UM4l0xYPFjGf3t,'wb').write(IIJjOxgEYhf2T4GtHXU)
	return
def wAnhRYDE09(X0UVekNKCqm2fOMy6FuWDE5SB):
	if X0UVekNKCqm2fOMy6FuWDE5SB in ['1','2','3','4']: bwW0lMvJfKe36nHpskP,DXTk148PQlz3jiVcGxfyobdOrquHs = 'مفضلة',X0UVekNKCqm2fOMy6FuWDE5SB
	elif X0UVekNKCqm2fOMy6FuWDE5SB in ['5']: bwW0lMvJfKe36nHpskP,DXTk148PQlz3jiVcGxfyobdOrquHs = 'تشغيل','1'
	elif X0UVekNKCqm2fOMy6FuWDE5SB in ['11']: bwW0lMvJfKe36nHpskP,DXTk148PQlz3jiVcGxfyobdOrquHs = 'تشغيل','2'
	else: bwW0lMvJfKe36nHpskP,DXTk148PQlz3jiVcGxfyobdOrquHs = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	ogbeF3sD0udOjRcKm1y42P7AZJHCa8 = bwW0lMvJfKe36nHpskP+WRsuxHTjDgYCIpoMQzLFAtS8rikP+DXTk148PQlz3jiVcGxfyobdOrquHs
	return ogbeF3sD0udOjRcKm1y42P7AZJHCa8
def tt7xCSzUP5IAvk6p(X0UVekNKCqm2fOMy6FuWDE5SB):
	ogbeF3sD0udOjRcKm1y42P7AZJHCa8 = wAnhRYDE09(X0UVekNKCqm2fOMy6FuWDE5SB)
	vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هل تريد فعلا مسح جميع محتويات قائمة '+ogbeF3sD0udOjRcKm1y42P7AZJHCa8+' ؟!')
	if vvbjZeMTcKP4dXDQLf90B3mgwYV7!=1: return
	ErRs8CvimPy = GI8zDQKfRv40()
	if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()):
		del ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]
		IIJjOxgEYhf2T4GtHXU = str(ErRs8CvimPy)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: IIJjOxgEYhf2T4GtHXU = IIJjOxgEYhf2T4GtHXU.encode(RMGz7OiD1e30P)
		open(ecXIT7UM4l0xYPFjGf3t,'wb').write(IIJjOxgEYhf2T4GtHXU)
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم مسح جميع محتويات قائمة '+ogbeF3sD0udOjRcKm1y42P7AZJHCa8)
	return
def GI8zDQKfRv40():
	ErRs8CvimPy = {}
	if oNlez5gnM9x2B4.path.exists(ecXIT7UM4l0xYPFjGf3t):
		aaiRJAuY5dZSkD8cH0pBz2G = open(ecXIT7UM4l0xYPFjGf3t,'rb').read()
		if fOohwvakqi29cx0l3yt5mzrAGpEg: aaiRJAuY5dZSkD8cH0pBz2G = aaiRJAuY5dZSkD8cH0pBz2G.decode(RMGz7OiD1e30P)
		ErRs8CvimPy = rKY1tyQvh9OCxE2nl('dict',aaiRJAuY5dZSkD8cH0pBz2G)
	return ErRs8CvimPy
def qNG5hEgnJw1KHaiI(ErRs8CvimPy,ahWqoR6MukN1XzZ,dGRhqtK7Sv24WFMJOY):
	ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM = ahWqoR6MukN1XzZ
	if not t5fhagjUGXk0ynOlJWeAb: ZJksHpSUNh2f,t5fhagjUGXk0ynOlJWeAb = 'folder','260'
	SYqRkrZKw32,X0UVekNKCqm2fOMy6FuWDE5SB = [],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if 'context=' in utdV6CEfRBM:
		c6trdA5aIBvo = AxTYMhRlfyskNc0X19dvwtS.findall('context=(\d+)',utdV6CEfRBM,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if c6trdA5aIBvo: X0UVekNKCqm2fOMy6FuWDE5SB = str(c6trdA5aIBvo[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
	if t5fhagjUGXk0ynOlJWeAb=='270':
		X0UVekNKCqm2fOMy6FuWDE5SB = WPHK5192hQ8lmL34OukgqMUS0CVF
		if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()):
			ogbeF3sD0udOjRcKm1y42P7AZJHCa8 = wAnhRYDE09(X0UVekNKCqm2fOMy6FuWDE5SB)
			SYqRkrZKw32.append(('مسح قائمة '+ogbeF3sD0udOjRcKm1y42P7AZJHCa8,'RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_DELETELIST'+')'))
	else:
		if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()):
			count = len(ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB])
			if count>xD9WeoEAsX7: SYqRkrZKw32.append(('تحريك 1 للأعلى','RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_UP1)'))
			if count>gybxTLFEw2: SYqRkrZKw32.append(('تحريك 4 للأعلى','RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_UP4)'))
			if count>xD9WeoEAsX7: SYqRkrZKw32.append(('تحريك 1 للأسفل','RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_DOWN1)'))
			if count>gybxTLFEw2: SYqRkrZKw32.append(('تحريك 4 للأسفل','RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_DOWN4)'))
		for X0UVekNKCqm2fOMy6FuWDE5SB in ['1','2','3','4','5','11']:
			ogbeF3sD0udOjRcKm1y42P7AZJHCa8 = wAnhRYDE09(X0UVekNKCqm2fOMy6FuWDE5SB)
			if X0UVekNKCqm2fOMy6FuWDE5SB in list(ErRs8CvimPy.keys()) and ahWqoR6MukN1XzZ in ErRs8CvimPy[X0UVekNKCqm2fOMy6FuWDE5SB]:
				SYqRkrZKw32.append(('مسح من '+ogbeF3sD0udOjRcKm1y42P7AZJHCa8,'RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_REMOVE1)'))
			else: SYqRkrZKw32.append(('إضافة ل'+ogbeF3sD0udOjRcKm1y42P7AZJHCa8,'RunPlugin('+dGRhqtK7Sv24WFMJOY+'&context='+X0UVekNKCqm2fOMy6FuWDE5SB+'_ADD1)'))
	JcxTiBEWYq1Idv = []
	for LTFlib4e6nSk,fYaEM5Goivsn0zTcDjNdOl in SYqRkrZKw32:
		LTFlib4e6nSk = oamlxBqLdu4ZM9nQrbIAhS5Pg7+LTFlib4e6nSk+so4Z8OUJ5E
		JcxTiBEWYq1Idv.append((LTFlib4e6nSk,fYaEM5Goivsn0zTcDjNdOl,))
	return JcxTiBEWYq1Idv