# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'SHIAVOICE'
qBAgzkG9oCL = '_SHV_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
headers = {'User-Agent':None}
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==310: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==311: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif mode==312: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==313: Ubud2NhHKRnMTvI5mprQBVqk80 = cpTP8gvCGdAimHFSk90heMIoO7zUBZ(url)
	elif mode==314: Ubud2NhHKRnMTvI5mprQBVqk80 = DzQdbq9C70aF1uc(text)
	elif mode==319: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,319,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="menulinks"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<h5>(.*?)</h5>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
	for u74UPEicpBdq32C in range(len(items)):
		title = items[u74UPEicpBdq32C].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,S7EgasGcYdIo,314,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(u74UPEicpBdq32C+1))
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'مقاطع شهر',S7EgasGcYdIo,314,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'0')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<B>(.*?)</B>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,311)
	return R8AE9e4mYxVhusL3Q
def DzQdbq9C70aF1uc(u74UPEicpBdq32C):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-LATEST-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if u74UPEicpBdq32C=='0':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="tab-content"(.*?)</table>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,name,title in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			title = title+' ('+name+')'
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312)
	elif u74UPEicpBdq32C in ['1','2','3']:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(<h5>.*?)<div class="col-lg',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		uu9lOICi6JRwd7 = int(u74UPEicpBdq32C)-1
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[uu9lOICi6JRwd7]
		if u74UPEicpBdq32C=='1': items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		else: items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title,name in items:
			RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			title = title+' ('+name+')'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,311,RRx0ri8bETI)
	elif u74UPEicpBdq32C in ['4','5','6']:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(<h5>.*?)</table>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		u74UPEicpBdq32C = int(u74UPEicpBdq32C)-4
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[u74UPEicpBdq32C]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for RRx0ri8bETI,cX2SpPxGLmADTKl,eraCBg1RXLl7MvN9m6O2z3Zqni4,title,XQv4cBgdZD5k6OPwy3alsEGxtA in items:
			RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			eraCBg1RXLl7MvN9m6O2z3Zqni4 = eraCBg1RXLl7MvN9m6O2z3Zqni4.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			XQv4cBgdZD5k6OPwy3alsEGxtA = XQv4cBgdZD5k6OPwy3alsEGxtA.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if eraCBg1RXLl7MvN9m6O2z3Zqni4: name = eraCBg1RXLl7MvN9m6O2z3Zqni4
			else: name = XQv4cBgdZD5k6OPwy3alsEGxtA
			title = title+' ('+name+')'
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312,RRx0ri8bETI)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('ibox-heading"(.*?)class="float-right',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if 'catsum-mobile' in IxdmfnvhCA8Bc9ZlQ45oiqN:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for RRx0ri8bETI,cX2SpPxGLmADTKl,title,count in items:
				RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
				cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
				count = count.replace(' الصوتية: ',':')
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				title = title+' ('+count+')'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,311,RRx0ri8bETI)
	else:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,oWOTXpsGydUlR6tgZEi0fYu5C4c,w03zWJvcXaCUySB6HIq4mVe in items:
			if title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O or oWOTXpsGydUlR6tgZEi0fYu5C4c==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: continue
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = title+' ('+w03zWJvcXaCUySB6HIq4mVe+')'
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312)
	if not items: SnpFbUovmMwfXalIGRNys6zYZtj(R8AE9e4mYxVhusL3Q)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(R8AE9e4mYxVhusL3Q):
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="ibox-content"(.*?)class="pagination',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title,name,count,w03zWJvcXaCUySB6HIq4mVe in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		title = title+' ('+name+')'
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w03zWJvcXaCUySB6HIq4mVe)
	return
def cpTP8gvCGdAimHFSk90heMIoO7zUBZ(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-SEARCH_ITEMS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="ibox-content p-1"(.*?)class="ibox-content"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt:
		ENDRjPGicXYFvpVs3xk5uSg6y(url)
		return
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<strong>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if '/play-' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,311)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('<audio.*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('<video.*?src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl[0]
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(cX2SpPxGLmADTKl,mI6ayKxBvjd4CRthL,'video')
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	Id4pDKxYUma7gPOVh21Ef0Ht3C = ['&t=a','&t=c','&t=s']
	if showDialogs:
		JFfbCW4XLSuj18cYtGD = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('موقع صوت الشيعة - أختر البحث', JFfbCW4XLSuj18cYtGD)
		if qNmsBD1jJZVzcxi4onKuAOIC == -1: return
	elif '_SHIAVOICE-PERSONS_' in sL9HIPc1tSZrhE60TUoz2KQa: qNmsBD1jJZVzcxi4onKuAOIC = 0
	elif '_SHIAVOICE-ALBUMS_' in sL9HIPc1tSZrhE60TUoz2KQa: qNmsBD1jJZVzcxi4onKuAOIC = 1
	elif '_SHIAVOICE-AUDIOS_' in sL9HIPc1tSZrhE60TUoz2KQa: qNmsBD1jJZVzcxi4onKuAOIC = 2
	else: return
	type = Id4pDKxYUma7gPOVh21Ef0Ht3C[qNmsBD1jJZVzcxi4onKuAOIC]
	url = S7EgasGcYdIo+'/search.php?q='+search+type
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHIAVOICE-SEARCH-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="ibox-content"(.*?)class="ibox-content"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		if qNmsBD1jJZVzcxi4onKuAOIC in [0,1]:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,RRx0ri8bETI,title,name in items:
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				title = title+' ('+name+')'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,313,RRx0ri8bETI)
		elif qNmsBD1jJZVzcxi4onKuAOIC==2:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title,name in items:
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				title = title+' ('+name+')'
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,312)
	return