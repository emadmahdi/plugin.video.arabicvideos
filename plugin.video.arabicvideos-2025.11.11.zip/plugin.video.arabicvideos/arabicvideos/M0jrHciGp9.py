# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'ARABICTOONS'
qBAgzkG9oCL = '_ART_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==730: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==731: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==732: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==733: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==734: Ubud2NhHKRnMTvI5mprQBVqk80 = BQ4tA2qhDfrIVSwCMujxmo78in1Zd(url)
	elif mode==735: Ubud2NhHKRnMTvI5mprQBVqk80 = DUFgtSua1GC(url)
	elif mode==739: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,739,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'افلام',S7EgasGcYdIo+'/movies.php',731)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'مسلسلات',S7EgasGcYdIo+'/cartoon.php',734)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'مسلسلات مميزة',S7EgasGcYdIo+'/top.php',735)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'أحدث الأفلام المضافة',S7EgasGcYdIo,731,'','','LATEST_MOVIES')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'أحدث المسلسلات المضافة',S7EgasGcYdIo,731,'','','LATEST_SERIES')
	return
def BQ4tA2qhDfrIVSwCMujxmo78in1Zd(url):
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الكل',url,731)
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-SERIES_SUBMENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('label="navigation"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("href='(.*?)'>(.*?)</a>",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = 'حرف '+title
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,731)
	return
def DUFgtSua1GC(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-SERIES_FEATURED-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="slider"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for title,cX2SpPxGLmADTKl,RRx0ri8bETI in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,733,RRx0ri8bETI)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall("class='moviesBlocks(.*?)list-group",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if eBjxVKSvQC1=='LATEST_SERIES': IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[1]
	else: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
		RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'movies.php' in url or eBjxVKSvQC1=='LATEST_MOVIES':
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,732,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,733,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[-1]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,731)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall("class='moviesBlocks(.*?)script",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for title,cX2SpPxGLmADTKl,RRx0ri8bETI,ZOJvoimkA9Q471HCDXG3psK in items:
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
			RRx0ri8bETI = S7EgasGcYdIo+'/'+RRx0ri8bETI
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			title = title+WRsuxHTjDgYCIpoMQzLFAtS8rikP+ZOJvoimkA9Q471HCDXG3psK.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,732,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('source src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if BA01W9olieErLycV7kwFvOhH5Y3ms:
		cX2SpPxGLmADTKl = BA01W9olieErLycV7kwFvOhH5Y3ms[0]
		if 'Referer=' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'|Referer=https://www.arabic-toons.com'
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed')
	else:
		FDWEpfKZQMeOszdJ17T90 = AxTYMhRlfyskNc0X19dvwtS.findall(r'dynamique.*?}\);', R8AE9e4mYxVhusL3Q, AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not FDWEpfKZQMeOszdJ17T90: FDWEpfKZQMeOszdJ17T90 = AxTYMhRlfyskNc0X19dvwtS.findall(r'dynamique.*?}\)', R8AE9e4mYxVhusL3Q, AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if FDWEpfKZQMeOszdJ17T90:
			aErxncDS20BfA6GzyJZtNVodeCUli8 = FDWEpfKZQMeOszdJ17T90[0]
			wwFPCUH3sfulKZ1eWntjDAg0r = dict(AxTYMhRlfyskNc0X19dvwtS.findall(r'(\w+):\s*"([^"]+)"', aErxncDS20BfA6GzyJZtNVodeCUli8))
			PMfX3hIgaTUnc2 = AxTYMhRlfyskNc0X19dvwtS.search(r'const\s+(\w+)', aErxncDS20BfA6GzyJZtNVodeCUli8)
			c72bnzmgOfUp6SlAGvrDuZ4Hi = PMfX3hIgaTUnc2.group(1) if PMfX3hIgaTUnc2 else ""
			keys = AxTYMhRlfyskNc0X19dvwtS.findall(r'\$\{' + c72bnzmgOfUp6SlAGvrDuZ4Hi + r'\.(\w+)\}', aErxncDS20BfA6GzyJZtNVodeCUli8)
			if wwFPCUH3sfulKZ1eWntjDAg0r and keys:
				cX2SpPxGLmADTKl = "%s://%s/%s?%s" % (wwFPCUH3sfulKZ1eWntjDAg0r[keys[0]], wwFPCUH3sfulKZ1eWntjDAg0r[keys[1]], wwFPCUH3sfulKZ1eWntjDAg0r[keys[2]], wwFPCUH3sfulKZ1eWntjDAg0r[keys[3]])
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed')
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	CBL4OQVtWbMAycUGl7Ex2SKZF = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'m']
	OKeTmNpi32ral8uMwD6WtjRGcBI = ['مسلسلات','افلام']
	if showDialogs:
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('اختر النوع المطلوب:', OKeTmNpi32ral8uMwD6WtjRGcBI)
		if qNmsBD1jJZVzcxi4onKuAOIC==-1: return
	else: qNmsBD1jJZVzcxi4onKuAOIC = 0
	type = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	url = S7EgasGcYdIo+'/livesearch.php?'+type+'&q='+search
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARABICTOONS-SEARCH-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if type=='m': w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,732)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,733)
	return