﻿# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'ALMAAREF'
headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
qBAgzkG9oCL = '_MRF_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text,GpwRnQ6q2o1fv0HbJTs):
	if   mode==40: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==41: Ubud2NhHKRnMTvI5mprQBVqk80 = aZr8kT7yehG2Pu6dRKjU9A4()
	elif mode==42: Ubud2NhHKRnMTvI5mprQBVqk80 = f6JGa1bDEqSLZM0TPVCFy(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==43: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==44: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==49: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,49)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'البث الحي لقناة المعارف',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,41)
	f6JGa1bDEqSLZM0TPVCFy(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
	return
def MVL6nS8syd09cWbiwAgzYTf(sL9HIPc1tSZrhE60TUoz2KQa,nxtLvYfTCb2dUXFHJe0ishSrwyBV):
	search,sort,EWxbCXeptzhYjgNTLQyI6s,PtATpb3YenChf5,hVtcOKJNZ2jSvrPqWQzGuo8dkHT = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[],[],[]
	G20Fvhu5p3,l7T9pwFind1kKRE = J1jmhoWbQuqR8g2YpK(sL9HIPc1tSZrhE60TUoz2KQa)
	for HHvPeCLzN1fIWDStR in list(l7T9pwFind1kKRE.keys()):
		value = l7T9pwFind1kKRE[HHvPeCLzN1fIWDStR]
		if not value: continue
		if   HHvPeCLzN1fIWDStR=='sort': sort = [value]
		elif HHvPeCLzN1fIWDStR=='series': EWxbCXeptzhYjgNTLQyI6s = [value]
		elif HHvPeCLzN1fIWDStR=='search': search = value
		elif HHvPeCLzN1fIWDStR=='category': PtATpb3YenChf5 = [value]
		elif HHvPeCLzN1fIWDStR=='specialist': hVtcOKJNZ2jSvrPqWQzGuo8dkHT = [value]
	dXG96SRYbe = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":PtATpb3YenChf5,"specialist":hVtcOKJNZ2jSvrPqWQzGuo8dkHT,"series":EWxbCXeptzhYjgNTLQyI6s,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(nxtLvYfTCb2dUXFHJe0ishSrwyBV)}}
	dXG96SRYbe = WWNb0XnUxOPL9gF.dumps(dXG96SRYbe)
	cX2SpPxGLmADTKl = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',cX2SpPxGLmADTKl,dXG96SRYbe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	data = rKY1tyQvh9OCxE2nl('dict',R8AE9e4mYxVhusL3Q)
	return data
def f6JGa1bDEqSLZM0TPVCFy(sL9HIPc1tSZrhE60TUoz2KQa,level):
	GtnfmdqIOijegYu = MVL6nS8syd09cWbiwAgzYTf(sL9HIPc1tSZrhE60TUoz2KQa,'1')
	IxdmfnvhCA8Bc9ZlQ45oiqN = GtnfmdqIOijegYu['facets']
	if level=='1':
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN['video_categories']
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<div(.*?)/div>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for Uz7N5KAHwQ93iShW1xj in items:
			oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',Uz7N5KAHwQ93iShW1xj+'<',AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if not oPeI4pms5LfYHrxygnAh: oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall('data-value=\\"(.*?)\\">(.*?)<',Uz7N5KAHwQ93iShW1xj+'<',AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			PtATpb3YenChf5,title = oPeI4pms5LfYHrxygnAh[0]
			if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			if not sL9HIPc1tSZrhE60TUoz2KQa: w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,42,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'2','?category='+PtATpb3YenChf5)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,42,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'2',sL9HIPc1tSZrhE60TUoz2KQa+'&category='+PtATpb3YenChf5)
	if level=='2':
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN['specialist']
		items = AxTYMhRlfyskNc0X19dvwtS.findall('value="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for hVtcOKJNZ2jSvrPqWQzGuo8dkHT,title in items:
			if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			if not hVtcOKJNZ2jSvrPqWQzGuo8dkHT: title = title = 'الجميع'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,42,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'3',sL9HIPc1tSZrhE60TUoz2KQa+'&specialist='+hVtcOKJNZ2jSvrPqWQzGuo8dkHT)
	elif level=='3':
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN['series']
		items = AxTYMhRlfyskNc0X19dvwtS.findall('value="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for EWxbCXeptzhYjgNTLQyI6s,title in items:
			if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			if not EWxbCXeptzhYjgNTLQyI6s: title = title = 'الجميع'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,42,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'4',sL9HIPc1tSZrhE60TUoz2KQa+'&series='+EWxbCXeptzhYjgNTLQyI6s)
	elif level=='4':
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN['sort_video']
		items = AxTYMhRlfyskNc0X19dvwtS.findall('value="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for sort,title in items:
			if not sort: continue
			if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,44,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1',sL9HIPc1tSZrhE60TUoz2KQa+'&sort='+sort)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(sL9HIPc1tSZrhE60TUoz2KQa,nxtLvYfTCb2dUXFHJe0ishSrwyBV):
	GtnfmdqIOijegYu = MVL6nS8syd09cWbiwAgzYTf(sL9HIPc1tSZrhE60TUoz2KQa,nxtLvYfTCb2dUXFHJe0ishSrwyBV)
	IxdmfnvhCA8Bc9ZlQ45oiqN = GtnfmdqIOijegYu['template']
	items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,43,RRx0ri8bETI)
	IxdmfnvhCA8Bc9ZlQ45oiqN = GtnfmdqIOijegYu['facets']['pagination']
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-page="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for GpwRnQ6q2o1fv0HbJTs,title in items:
		if nxtLvYfTCb2dUXFHJe0ishSrwyBV==GpwRnQ6q2o1fv0HbJTs: continue
		if hT1JIgqPQsUOZp5tjCX0E: title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,44,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,sL9HIPc1tSZrhE60TUoz2KQa)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMAAREF-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('<video src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('youtube_url.*?(http.*?)&',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	dU17fayKLj4kABu = []
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0].replace('\/','/')
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def aZr8kT7yehG2Pu6dRKjU9A4():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo+'/البث-المباشر-6',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALMAAREF-LIVE-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	url = AxTYMhRlfyskNc0X19dvwtS.findall('data-item=.*?(http.*?)&',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	url = url[0].replace('\/','/')
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(url,mI6ayKxBvjd4CRthL,'live')
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	fvZRqeoG2LsDMtJ61dCUSBWVaPK = False
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
		search = TwDBf3QbKOnrmd5u9()
		fvZRqeoG2LsDMtJ61dCUSBWVaPK = True
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	if not fvZRqeoG2LsDMtJ61dCUSBWVaPK: ENDRjPGicXYFvpVs3xk5uSg6y('?search='+search,'1')
	else: f6JGa1bDEqSLZM0TPVCFy('?search='+search,'1')
	return