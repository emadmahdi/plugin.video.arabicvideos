# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'LIVETV'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS['PYTHON'][0]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url):
	if   mode==100: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==101: Ubud2NhHKRnMTvI5mprQBVqk80 = VuHht6MNBWRnOkX9S('0',True)
	elif mode==102: Ubud2NhHKRnMTvI5mprQBVqk80 = VuHht6MNBWRnOkX9S('1',True)
	elif mode==103: Ubud2NhHKRnMTvI5mprQBVqk80 = VuHht6MNBWRnOkX9S('2',True)
	elif mode==104: Ubud2NhHKRnMTvI5mprQBVqk80 = VuHht6MNBWRnOkX9S('3',True)
	elif mode==105: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==106: Ubud2NhHKRnMTvI5mprQBVqk80 = VuHht6MNBWRnOkX9S('4',True)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder','_M3U_'+'قوائم فيديوهات M3U',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,762)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_IPT_'+'قوائم فيديوهات IPTV',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,761)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TV0_'+'قنوات من مواقعها الأصلية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,101)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TV4_'+'قنوات مختارة من يوتيوب',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,106)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_YUT_'+'قنوات عربية من يوتيوب',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,147)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_YUT_'+'قنوات أجنبية من يوتيوب',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,148)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,28)
	w3BfOGLdXcWzbiC1PYx9mE('live','_MRF_'+'قناة المعارف من موقعهم',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,41)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TV1_'+'قنوات تلفزيونية عامة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,102)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TV2_'+'قنوات تلفزيونية خاصة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,103)
	w3BfOGLdXcWzbiC1PYx9mE('folder','_TV3_'+'قنوات تلفزيونية للفحص',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,104)
	return
def VuHht6MNBWRnOkX9S(oFQHL7AaItXmfCz4yPKT0pc1ie,showDialogs=True):
	qBAgzkG9oCL = '_TV'+oFQHL7AaItXmfCz4yPKT0pc1ie+'_'
	dXG96SRYbe = {'id':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'user':drzqWFkSHD.AV_CLIENT_IDS,'function':'list','menu':oFQHL7AaItXmfCz4yPKT0pc1ie}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',S7EgasGcYdIo,dXG96SRYbe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-ITEMS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = AxTYMhRlfyskNc0X19dvwtS.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(items)):
			name = items[uKFGBAEj9tX1e03cyHOMUNhQl4r6][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[uKFGBAEj9tX1e03cyHOMUNhQl4r6] = items[uKFGBAEj9tX1e03cyHOMUNhQl4r6][0],items[uKFGBAEj9tX1e03cyHOMUNhQl4r6][1],items[uKFGBAEj9tX1e03cyHOMUNhQl4r6][2],name,items[uKFGBAEj9tX1e03cyHOMUNhQl4r6][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for KS8ozxwIk1EB4srRJtgHfbVp2AhQ,LLzkoiPsbBZ,GKBq5DJiV9YMl4Fma3gr,name,RRx0ri8bETI in items:
			if '#' in KS8ozxwIk1EB4srRJtgHfbVp2AhQ: continue
			if KS8ozxwIk1EB4srRJtgHfbVp2AhQ!='URL': name = name+qFghPAi5yz9Vf3NLwo0nuprl+NzlAQMRChm8J34urLwcUOn1f+KS8ozxwIk1EB4srRJtgHfbVp2AhQ+so4Z8OUJ5E
			url = KS8ozxwIk1EB4srRJtgHfbVp2AhQ+';;'+LLzkoiPsbBZ+';;'+GKBq5DJiV9YMl4Fma3gr+';;'+oFQHL7AaItXmfCz4yPKT0pc1ie
			w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+VhaIfJdtZP1kiKbRq8nGvFo9juBp2O+name,url,105,RRx0ri8bETI)
	else:
		if showDialogs: w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+'هذه الخدمة مخصصة للمبرمج فقط',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return
def QgIZSJdUhsEnup8GPz3(id):
	KS8ozxwIk1EB4srRJtgHfbVp2AhQ,LLzkoiPsbBZ,GKBq5DJiV9YMl4Fma3gr,oFQHL7AaItXmfCz4yPKT0pc1ie = id.split(';;')
	url = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='URL': url = GKBq5DJiV9YMl4Fma3gr
	elif KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='YOUTUBE':
		url = drzqWFkSHD.SITESURLS['YOUTUBE'][0]+'/watch?v='+GKBq5DJiV9YMl4Fma3gr
		import v3w7fbWE0x
		v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2([url],mI6ayKxBvjd4CRthL,'live',url)
		return
	elif KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='GA':
		dXG96SRYbe = { 'id' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O, 'user' : drzqWFkSHD.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',S7EgasGcYdIo,dXG96SRYbe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-1st')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cookies = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.cookies
		b3bTeswNBmgvXkSztuOdPc8 = cookies['ASP.NET_SessionId']
		url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Location']
		dXG96SRYbe = { 'id' : GKBq5DJiV9YMl4Fma3gr , 'user' : drzqWFkSHD.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+b3bTeswNBmgvXkSztuOdPc8 }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',S7EgasGcYdIo,dXG96SRYbe,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-2nd')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		url = AxTYMhRlfyskNc0X19dvwtS.findall('resp":"(http.*?m3u8)(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		cX2SpPxGLmADTKl = url[0][0]
		LY97ojMUDA4d = url[0][1]
		WFQku5b0Eg1mOUXfS = 'http://38.'+LLzkoiPsbBZ+'777/'+GKBq5DJiV9YMl4Fma3gr+'_HD.m3u8'+LY97ojMUDA4d
		e19tSYPqEFlsAOaxuoNCB0pb = WFQku5b0Eg1mOUXfS.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		cctJBag9YnGRCk6mdMNbQq = WFQku5b0Eg1mOUXfS.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		GjC4atkJLwlTpsI = ['HD','SD1','SD2']
		CBL4OQVtWbMAycUGl7Ex2SKZF = [WFQku5b0Eg1mOUXfS,e19tSYPqEFlsAOaxuoNCB0pb,cctJBag9YnGRCk6mdMNbQq]
		qNmsBD1jJZVzcxi4onKuAOIC = 0
		if qNmsBD1jJZVzcxi4onKuAOIC == -1: return
		else: url = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	elif KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		dXG96SRYbe = { 'id' : GKBq5DJiV9YMl4Fma3gr , 'user' : drzqWFkSHD.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : oFQHL7AaItXmfCz4yPKT0pc1ie }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST', S7EgasGcYdIo, dXG96SRYbe, headers, False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-3rd')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Location']
		url = url.replace('%20',WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		url = url.replace('%3D','=')
		if 'Learn' in GKBq5DJiV9YMl4Fma3gr:
			url = url.replace('NTNNile',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			url = url.replace('learning1','Learning')
	elif KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='PL':
		dXG96SRYbe = { 'id' : GKBq5DJiV9YMl4Fma3gr , 'user' : drzqWFkSHD.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : oFQHL7AaItXmfCz4yPKT0pc1ie }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST', S7EgasGcYdIo, dXG96SRYbe, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-4th')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Location']
		headers = {'Referer':gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Referer']}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'POST',url, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers , VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-5th')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		items = AxTYMhRlfyskNc0X19dvwtS.findall('source src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		url = items[0]
	elif KS8ozxwIk1EB4srRJtgHfbVp2AhQ in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='TA': GKBq5DJiV9YMl4Fma3gr = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		dXG96SRYbe = { 'id' : GKBq5DJiV9YMl4Fma3gr , 'user' : drzqWFkSHD.AV_CLIENT_IDS , 'function' : 'play'+KS8ozxwIk1EB4srRJtgHfbVp2AhQ , 'menu' : oFQHL7AaItXmfCz4yPKT0pc1ie }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',S7EgasGcYdIo,dXG96SRYbe,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-6th')
		if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Location']
		if KS8ozxwIk1EB4srRJtgHfbVp2AhQ=='FM':
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET', url, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O, False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVETV-PLAY-7th')
			url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers['Location']
			url = url.replace('https','http')
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(url,mI6ayKxBvjd4CRthL,'live')
	return