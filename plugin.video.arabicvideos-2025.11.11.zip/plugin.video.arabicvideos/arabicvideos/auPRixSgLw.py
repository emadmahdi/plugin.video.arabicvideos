# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
nUaVQsoA6EXcK4Odht5wCge0J8Pib = kAz7WRYjrfGm(u"࠶ੜ")
xD9WeoEAsX7 = zWBnYSGIatjXVC(u"࠱੝")
H3OKMjDG1evnl4Ruiz = xD9WeoEAsX7+xD9WeoEAsX7
anb4QpyjlmgVwANP = H3OKMjDG1evnl4Ruiz+xD9WeoEAsX7
gybxTLFEw2 = anb4QpyjlmgVwANP+xD9WeoEAsX7
Hip2swoNbVaZ30OrStQR1lF = gybxTLFEw2+xD9WeoEAsX7
VhaIfJdtZP1kiKbRq8nGvFo9juBp2O = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࠪए")
WRsuxHTjDgYCIpoMQzLFAtS8rikP = w9wfONXUP3(u"ࠪࠤࠬऐ")
zHYL9u48eyJot = WRsuxHTjDgYCIpoMQzLFAtS8rikP*H3OKMjDG1evnl4Ruiz
NzlAQMRChm8J34urLwcUOn1f = WRsuxHTjDgYCIpoMQzLFAtS8rikP*anb4QpyjlmgVwANP
NNJKRTY8GlM29ezbCgPiXd = WRsuxHTjDgYCIpoMQzLFAtS8rikP*gybxTLFEw2
rrpMTe0FZlXBkD6jJfsKPboWhVd9 = None
NFGqKBLtvUZn1S3dau = ba49YvOK2Aw8Uhxt(u"ࡗࡶࡺ࡫૬")
pLwgjkuTs6CS = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࡊࡦࡲࡳࡦ૭")
ETuar3m5fsx97M1PQ0cdlgVRG = pYeVwat64v(u"ࠫࡹࡸࡵࡦࠩऑ")
OoTt1Fqj6pYCX25ZI8WLMvnf94Uh = pL73X0MYajJQG4n1qgD(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
XvNk2Fqt5MxdZaLCylfpDgYc8i = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
btR0Zix9D2g = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
qFghPAi5yz9Vf3NLwo0nuprl = I6Bfzysrvb8DONZ(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
oamlxBqLdu4ZM9nQrbIAhS5Pg7 = YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
bb03xjXNaRDtPEoSrC8d1ZTyO = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
LDeqjxXOodWPyp5RVv6TakfH4 = kAz7WRYjrfGm(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
K1KgXSeFsx = YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
so4Z8OUJ5E = rAYDiWlzm9MCU6x0GnROua(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
RMGz7OiD1e30P = YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡶࡶࡩ࠼ࠬछ")
P7PMpzWXGkQcViT56ANdREyejZ8Cgo = kAz7WRYjrfGm(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
wyNsOv6zCW7pdEHXUf3lFGqQAYj = awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
jZBtGcdApeKLEkb = Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
HHTRECw16nOjQcp79vL3mi24BfJ = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
UiO5y1oG8EXmD = ba49YvOK2Aw8Uhxt(u"ࠬࡋࡒࡓࡑࡕࠫठ")
gLv2Ra9NjkesOlrCF = hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
b8sk5WyPoz03pXhRx = CCWqR3dmtzw6xoIX41(u"ࠧ࡝ࡰࠪढ")
b6JZWhsCvwOyV041EdQTcu = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࡞ࡵࠫण")
F91YEzyWak5 = hWRvZOYtjme9QNnV41u0Mswb(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
ssLYQzptwvuk = jBbkfIJSDqcVwl8irzy4Z3O(u"࠲ਫ਼")
hctuin9mF4xl81gT0CaNskqp6LbJW = B1YMtuvRAGNlJOkC46VyPKQE(u"࠲࠱࠹੟")
Gz82dDr4wN5UHLTak9b631v7Y = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠴࠹੠")
ssfq3KzCgrA1Wh = kAz7WRYjrfGm(u"࠷࠵੡")
XXCO1RxIwBWQmyS = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠶࠶੢")
zzdmZ5urYvoKXV = awSUTRNMkdIW7sFEvnHD2mLY(u"࠷࠲࠱੣")
n6OMU42JhdAl8 = [
						 hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,f9fOpCmLAEaW2Go(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,w9wfONXUP3(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,f9fOpCmLAEaW2Go(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,I6Bfzysrvb8DONZ(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,kAz7WRYjrfGm(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,GTmHXIZUSdxRhMnqQKkO(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,CCWqR3dmtzw6xoIX41(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,I6Bfzysrvb8DONZ(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,pbmKZA1w7L4zHjOM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,CCWqR3dmtzw6xoIX41(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
ggEnKV0FoitaN1eCyjhWzZl9dO76RX = n6OMU42JhdAl8+[
				 djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,kAz7WRYjrfGm(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,f9fOpCmLAEaW2Go(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,pL73X0MYajJQG4n1qgD(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,lRKCWnNi0Edr984eI(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,CCWqR3dmtzw6xoIX41(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,KKCrwPdOgGl(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,pL73X0MYajJQG4n1qgD(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,f9fOpCmLAEaW2Go(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,f9fOpCmLAEaW2Go(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
wwP7Wlf1rMXa6AuYCtTQEU85 = [
						 zWBnYSGIatjXVC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,I6Bfzysrvb8DONZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,pbmKZA1w7L4zHjOM(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
RR1typGWKXVd6vNAaMEqo9h = Hip2swoNbVaZ30OrStQR1lF
bCuhHjwS9lEQ2eB1c = [awSUTRNMkdIW7sFEvnHD2mLY(u"ุࠩๅึ࠭े"),KKCrwPdOgGl(u"ࠪวํ๊ࠧै"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫะอๆ๋ࠩॉ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬัวๅอࠪॊ"),pbmKZA1w7L4zHjOM(u"࠭ัศส฼ࠫो"),KKCrwPdOgGl(u"ࠧฯษ่ืࠬौ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨีสำ्ุ࠭"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩึหอ฿ࠧॎ"),CCWqR3dmtzw6xoIX41(u"ࠪฯฬ๋ๆࠨॏ"),KKCrwPdOgGl(u"ࠫฯอำฺࠩॐ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬ฿วีำࠪ॑")]
wKBPndi5F6ZACa = ba49YvOK2Aw8Uhxt(u"࠶࠱੤")
UnxhPGeBSgLJH = kAz7WRYjrfGm(u"࠷࠲੥")*wKBPndi5F6ZACa
oBtriexQ2jUf1v7l30JXuyMcC9hVb = lRKCWnNi0Edr984eI(u"࠴࠷੦")*UnxhPGeBSgLJH
Tw12N0iAM6erFjRxY8cl = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶࠴੧")*oBtriexQ2jUf1v7l30JXuyMcC9hVb
RFowY7JrTPs8c5m02ydD1VgbeBup3N = nUaVQsoA6EXcK4Odht5wCge0J8Pib
qJ0xtbICjHuM45nmhO7fgpkr = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠷࠵੨")*wKBPndi5F6ZACa
V7DSdHck4Fjp = H3OKMjDG1evnl4Ruiz*UnxhPGeBSgLJH
BRMcS58jIbyDQWGYLk1term = I6Bfzysrvb8DONZ(u"࠶࠼੩")*UnxhPGeBSgLJH
QTa0s1bvhkXjIim7lWF5qVBJUoNZ = anb4QpyjlmgVwANP*oBtriexQ2jUf1v7l30JXuyMcC9hVb
QT1GPoWB7px = GTmHXIZUSdxRhMnqQKkO(u"࠹࠰੪")*oBtriexQ2jUf1v7l30JXuyMcC9hVb
iigI6zE7djY3yQasNTM5AW0PLOS4 = jBbkfIJSDqcVwl8irzy4Z3O(u"࠱࠳੫")*Tw12N0iAM6erFjRxY8cl
XElcjkopwbuRJtK7I3Y = UnxhPGeBSgLJH
hw9RKAyI2qkJiOpTQPXglUa6ZLN0jH = [Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),zWBnYSGIatjXVC(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
hw9RKAyI2qkJiOpTQPXglUa6ZLN0jH += [KKCrwPdOgGl(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),rAYDiWlzm9MCU6x0GnROua(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
JJQOUnH2FvYLWR509lySAfTEBD4qV = [djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),f9fOpCmLAEaW2Go(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),ba49YvOK2Aw8Uhxt(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
JJQOUnH2FvYLWR509lySAfTEBD4qV += [pL73X0MYajJQG4n1qgD(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),pbmKZA1w7L4zHjOM(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
YYvwA0cPWqzFd1HCIONK = [zWBnYSGIatjXVC(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),I6Bfzysrvb8DONZ(u"ࠫࡋࡕࡓࡕࡃࠪ६"),I6Bfzysrvb8DONZ(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),awSUTRNMkdIW7sFEvnHD2mLY(u"࡙࠭ࡂࡓࡒࡘࠬ८"),pYeVwat64v(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),zWBnYSGIatjXVC(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),lRKCWnNi0Edr984eI(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
YYvwA0cPWqzFd1HCIONK += [W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),I6Bfzysrvb8DONZ(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),ba49YvOK2Aw8Uhxt(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),nR0ok9zju84rFUQl1YC(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),I6Bfzysrvb8DONZ(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
YYvwA0cPWqzFd1HCIONK += [pL73X0MYajJQG4n1qgD(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),CCWqR3dmtzw6xoIX41(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),nR0ok9zju84rFUQl1YC(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),ba49YvOK2Aw8Uhxt(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
YYvwA0cPWqzFd1HCIONK += [vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),pYeVwat64v(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),f9fOpCmLAEaW2Go(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
YYvwA0cPWqzFd1HCIONK += [fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),Zb5cNeHWi6jP9SCYtUgR(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),lRKCWnNi0Edr984eI(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),I6Bfzysrvb8DONZ(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),rAYDiWlzm9MCU6x0GnROua(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),w9wfONXUP3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
nrKfYEH8sUJQSp2cPMA5ZibRo6xzD = [GTmHXIZUSdxRhMnqQKkO(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),lRKCWnNi0Edr984eI(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),I6Bfzysrvb8DONZ(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
nrKfYEH8sUJQSp2cPMA5ZibRo6xzD += [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),GTmHXIZUSdxRhMnqQKkO(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),kAz7WRYjrfGm(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),rAYDiWlzm9MCU6x0GnROua(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
gI02HPoNJVx6rcw5jisfKnUyuqSv = [ba49YvOK2Aw8Uhxt(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+hw9RKAyI2qkJiOpTQPXglUa6ZLN0jH+[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+JJQOUnH2FvYLWR509lySAfTEBD4qV+[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+YYvwA0cPWqzFd1HCIONK+[GTmHXIZUSdxRhMnqQKkO(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+nrKfYEH8sUJQSp2cPMA5ZibRo6xzD
u4u8PJC5oiy3YFnHA0S2ODLG = [Zb5cNeHWi6jP9SCYtUgR(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
wJ7c5gQb9pOjkzox = [fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),pbmKZA1w7L4zHjOM(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),pL73X0MYajJQG4n1qgD(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
ol4NiG0BbpT2V7 = [MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡐ࠷࡚࠭ঢ"),kAz7WRYjrfGm(u"ࠪࡍࡕ࡚ࡖࠨণ"),CCWqR3dmtzw6xoIX41(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡏࡆࡊࡎࡐࠫথ"),ba49YvOK2Aw8Uhxt(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
LWKr8ZkzO4vs0U21bm  = [pL73X0MYajJQG4n1qgD(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),CCWqR3dmtzw6xoIX41(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
LWKr8ZkzO4vs0U21bm += [f9fOpCmLAEaW2Go(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),CCWqR3dmtzw6xoIX41(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
LWKr8ZkzO4vs0U21bm += [ba49YvOK2Aw8Uhxt(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),rAYDiWlzm9MCU6x0GnROua(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
LWKr8ZkzO4vs0U21bm += [ba49YvOK2Aw8Uhxt(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
LWKr8ZkzO4vs0U21bm += [MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
HhlFCSAwOgxE3 = list(filter(lambda pJIMwPmtxzhH: pJIMwPmtxzhH not in LWKr8ZkzO4vs0U21bm+u4u8PJC5oiy3YFnHA0S2ODLG+wJ7c5gQb9pOjkzox+ol4NiG0BbpT2V7,gI02HPoNJVx6rcw5jisfKnUyuqSv))
oZpNRUMvIQDOXyJ26eYctahBz = HhlFCSAwOgxE3+ol4NiG0BbpT2V7
iBjkvOZ4a9qRcboSGLyCTIf57KWn = HhlFCSAwOgxE3+LWKr8ZkzO4vs0U21bm
HPLCf9g0SwpAUQ8Iv7 = iBjkvOZ4a9qRcboSGLyCTIf57KWn+u4u8PJC5oiy3YFnHA0S2ODLG
LVlOIga0UM = oZpNRUMvIQDOXyJ26eYctahBz+u4u8PJC5oiy3YFnHA0S2ODLG
BqoZewk2M6QW4iaRcIGTt8HJX1Aj = [B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡄࡏࡔࡇࡍࠨষ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),GTmHXIZUSdxRhMnqQKkO(u"ࠫࡎࡌࡉࡍࡏࠪহ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),pbmKZA1w7L4zHjOM(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),pbmKZA1w7L4zHjOM(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡒ࠹ࡕࠨী"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡏࡐࡕࡘࠪু"),lRKCWnNi0Edr984eI(u"࠭ࡂࡐࡍࡕࡅࠬূ"),I6Bfzysrvb8DONZ(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),f9fOpCmLAEaW2Go(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [zWBnYSGIatjXVC(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),nR0ok9zju84rFUQl1YC(u"ࠫࡤࡏࡆࡍࡡࠪে"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),pYeVwat64v(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),pYeVwat64v(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),ba49YvOK2Aw8Uhxt(u"ࠫࡤࡓࡕࠨৎ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡥࡉࡑࠩ৏"),f9fOpCmLAEaW2Go(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),f9fOpCmLAEaW2Go(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
wVRgKlTCjF = [rAYDiWlzm9MCU6x0GnROua(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),KKCrwPdOgGl(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),w9wfONXUP3(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),pbmKZA1w7L4zHjOM(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
VOEAvdM2TujwaP = [nUaVQsoA6EXcK4Odht5wCge0J8Pib,I6Bfzysrvb8DONZ(u"࠲࠷࠳੬"),lRKCWnNi0Edr984eI(u"࠳࠹࠴੻"),lRKCWnNi0Edr984eI(u"࠶࠽࠰੾"),rAYDiWlzm9MCU6x0GnROua(u"࠲࠻࠳ੳ"),pbmKZA1w7L4zHjOM(u"࠶࠻࠶੶"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠳࠺࠳੺"),ba49YvOK2Aw8Uhxt(u"࠵࠶࠴ੴ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠸࠺࠰੷"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠶࠴࠴੭"),pYeVwat64v(u"࠹࠵࠶੽"),pL73X0MYajJQG4n1qgD(u"࠵࠳࠲ੲ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"࠵࠴࠲੹"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠸࠸࠵ੵ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠺࠺࠵੼"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠷࠰࠲࠲ੱ"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠾࠿࠹࠱ੰ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠴࠴࠷࠶੮"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠵࠵࠾࠰੯"),lRKCWnNi0Edr984eI(u"࠷࠱࠱࠲੸")]
PPOBCXoZRcN = [KKCrwPdOgGl(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),zWBnYSGIatjXVC(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),CCWqR3dmtzw6xoIX41(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬ࠺࠴ࡧ࠶࠳࠼ࡩ࠺ࡡ࠳࡯ࡶ࡬࠶ࡨ࠳ࡣࡦ࠷࠽ࡦ࠼࠴࠹࠳࠺ࡪ࠺ࡶ࠱࠱࠳࠳࠷࡫ࡰࡳ࡯࠶ࡤ࠸࠶࠽ࡦࡤ࠷࠶࠴࠹࠸ࠧ৤"),nR0ok9zju84rFUQl1YC(u"࠭ࡢࡣ࠷࠶࠼࠶࠾࠰࠮࠷ࡧ࠵ࡦ࠳࠴ࡤ࠴࠹࠱ࡦࡨ࠶ࡣ࠯࠴࠺ࡧࡨ࠲࠵ࡤ࠹࠽ࡨ࠾ࡡ࠮࠲࠳࠱࠶ࡼ࠵࠺ࡣ࡫࠶࠺ࡷ࠱ࡢ࠸࠳ࠫ৥")]
BxAUtLk7vjND = [pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪ০"),Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬ১"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠧ২"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪ৩"),YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭৪"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨ৫"),w9wfONXUP3(u"࠭ࡳࡤࡴࡤࡴࡵ࡫ࡹ࠮ࡥࡲࡱࠬ৬"),pbmKZA1w7L4zHjOM(u"ࠧࡳࡧࡳࡰ࡮ࡺࠧ৭")]
ThW9Rpga4lduO = {
	 jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠴ࠬ৮")	: nUaVQsoA6EXcK4Odht5wCge0J8Pib
	,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡄࡐࡆࡘࡁࡃࠩ৯")		: CCWqR3dmtzw6xoIX41(u"࠷࠰੿")
	,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡍࡋࡏࡌࡎࠩৰ")		: bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠲࠱઀")
	,kAz7WRYjrfGm(u"ࠫࡕࡇࡎࡆࡖࠪৱ")		: ba49YvOK2Aw8Uhxt(u"࠴࠲ઁ")
	,ba49YvOK2Aw8Uhxt(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ৲")		: kAz7WRYjrfGm(u"࠶࠳ં")
	,rAYDiWlzm9MCU6x0GnROua(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ৳")		: vl6rwMLasAQo4z1ZjD3IBKtF(u"࠸࠴ઃ")
	,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ৴")		: slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠺࠵઄")
	,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡃࡎࡓࡆࡓࠧ৵")		: kAz7WRYjrfGm(u"࠼࠶અ")
	,Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ৶")		: nR0ok9zju84rFUQl1YC(u"࠾࠰આ")
	,kAz7WRYjrfGm(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ৷")		: awSUTRNMkdIW7sFEvnHD2mLY(u"࠹࠱ઇ")
	,hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡑࡏࡖࡆࡖ࡙ࠫ৸")		: Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠲࠲࠳ઈ")
	,W2Vv30i8qxSuItfsolPLdFZA(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ৹")		: KKCrwPdOgGl(u"࠳࠴࠴ઉ")
	,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ৺")		: W2Vv30i8qxSuItfsolPLdFZA(u"࠴࠶࠵ઊ")
	,pL73X0MYajJQG4n1qgD(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ৻")	: I6Bfzysrvb8DONZ(u"࠵࠸࠶ઋ")
	,CCWqR3dmtzw6xoIX41(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩৼ")		: GTmHXIZUSdxRhMnqQKkO(u"࠶࠺࠰ઌ")
	,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠶࠭৽")	: pbmKZA1w7L4zHjOM(u"࠷࠵࠱ઍ")
	,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡖࡆࡔࡄࡐࡏࡖࡣ࠵࠭৾")	: ba49YvOK2Aw8Uhxt(u"࠱࠷࠲઎")
	,nR0ok9zju84rFUQl1YC(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠲ࠨ৿")	: fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠲࠹࠳એ")
	,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ਀")	: CCWqR3dmtzw6xoIX41(u"࠳࠻࠴ઐ")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠵ࠪਁ")	: ba49YvOK2Aw8Uhxt(u"࠴࠽࠵ઑ")
	,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩਂ")		: w9wfONXUP3(u"࠶࠵࠶઒")
	,rAYDiWlzm9MCU6x0GnROua(u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧਃ")	: CCWqR3dmtzw6xoIX41(u"࠷࠷࠰ઓ")
	,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭਄")	: W2Vv30i8qxSuItfsolPLdFZA(u"࠸࠲࠱ઔ")
	,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡍࡕ࡚ࡖࡠ࠲ࠪਅ")		: CCWqR3dmtzw6xoIX41(u"࠲࠴࠲ક")
	,f9fOpCmLAEaW2Go(u"ࠫࡆࡑࡗࡂࡏࠪਆ")		: Zb5cNeHWi6jP9SCYtUgR(u"࠳࠶࠳ખ")
	,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧਇ")		: jBbkfIJSDqcVwl8irzy4Z3O(u"࠴࠸࠴ગ")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡍࡆࡐࡘࡗࡤ࠶ࠧਈ")		: awSUTRNMkdIW7sFEvnHD2mLY(u"࠵࠺࠵ઘ")
	,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡇࡃ࡙ࡓࡗࡏࡔࡆࡕࠪਉ")	: rAYDiWlzm9MCU6x0GnROua(u"࠶࠼࠶ઙ")
	,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡋࡓࡘ࡛ࡥ࠱ࠨਊ")		: rAYDiWlzm9MCU6x0GnROua(u"࠷࠾࠰ચ")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ਋")	: lRKCWnNi0Edr984eI(u"࠸࠹࠱છ")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ਌")		: slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠳࠱࠲જ")
	,lRKCWnNi0Edr984eI(u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ਍")	: djapWhrveLJbgnViDftFNY05ylq1S(u"࠴࠳࠳ઝ")
	,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ਎")	: MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠵࠵࠴ઞ")
	,jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨਏ")		: CCWqR3dmtzw6xoIX41(u"࠶࠷࠵ટ")
	,CCWqR3dmtzw6xoIX41(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࡡ࠷ࠫਐ")	: Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠷࠹࠶ઠ")
	,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ਑")		: rAYDiWlzm9MCU6x0GnROua(u"࠸࠻࠰ડ")
	,pYeVwat64v(u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ਒")		: KKCrwPdOgGl(u"࠹࠶࠱ઢ")
	,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡆࡔࡑࡒࡂࠩਓ")		: MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠳࠸࠲ણ")
	,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫਔ")		: Zb5cNeHWi6jP9SCYtUgR(u"࠴࠺࠳ત")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨਕ")	: zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵࠼࠴થ")
	,JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࡣ࠵࠭ਖ"): kAz7WRYjrfGm(u"࠷࠴࠵દ")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࡤ࠷ࠧਗ"): YzlId3Fs6vpehcbLGj0UaO(u"࠸࠶࠶ધ")
	,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨਘ")		: pbmKZA1w7L4zHjOM(u"࠹࠸࠰ન")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩਙ")		: f9fOpCmLAEaW2Go(u"࠺࠳࠱઩")
	,ba49YvOK2Aw8Uhxt(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫਚ")		: Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠴࠵࠲પ")
	,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬਛ")		: MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠵࠷࠳ફ")
	,pbmKZA1w7L4zHjOM(u"࡚ࠬࡖࡇࡗࡑࠫਜ")		: zWBnYSGIatjXVC(u"࠶࠹࠴બ")
	,W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩਝ")	: CCWqR3dmtzw6xoIX41(u"࠷࠻࠵ભ")
	,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩਞ")		: awSUTRNMkdIW7sFEvnHD2mLY(u"࠸࠽࠶મ")
	,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪਟ")		: CCWqR3dmtzw6xoIX41(u"࠹࠿࠰ય")
	,nR0ok9zju84rFUQl1YC(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠺࠭ਠ")	: kAz7WRYjrfGm(u"࠻࠰࠱ર")
	,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࡤ࠶ࠧਡ")	: zWBnYSGIatjXVC(u"࠵࠲࠲઱")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆࡥ࠱ࠨਢ")	: slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠶࠴࠳લ")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡓࡅࡏࡗࡖࡣ࠶࠭ਣ")		: MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠷࠶࠴ળ")
	,KKCrwPdOgGl(u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬਤ")	: Zb5cNeHWi6jP9SCYtUgR(u"࠸࠸࠵઴")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩਥ")		: rAYDiWlzm9MCU6x0GnROua(u"࠹࠺࠶વ")
	,pbmKZA1w7L4zHjOM(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩਦ")		: pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠺࠼࠰શ")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫਧ")		: GTmHXIZUSdxRhMnqQKkO(u"࠻࠷࠱ષ")
	,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧਨ")	: zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵࠹࠲સ")
	,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭਩")		: hWRvZOYtjme9QNnV41u0Mswb(u"࠶࠻࠳હ")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡌࡏࡔࡖࡄࠫਪ")		: jBbkfIJSDqcVwl8irzy4Z3O(u"࠸࠳࠴઺")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡁࡉ࡙ࡄࡏࠬਫ")		: jBbkfIJSDqcVwl8irzy4Z3O(u"࠹࠵࠵઻")
	,ba49YvOK2Aw8Uhxt(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨਬ")		: KKCrwPdOgGl(u"࠺࠷࠶઼")
	,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧਭ")	: W2Vv30i8qxSuItfsolPLdFZA(u"࠻࠹࠰ઽ")
	,nR0ok9zju84rFUQl1YC(u"ࠩࡖࡌࡔࡌࡈࡂࠩਮ")		: slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠼࠴࠱ા")
	,pbmKZA1w7L4zHjOM(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪਯ")		: pYeVwat64v(u"࠶࠶࠲િ")
	,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫ࡞ࡇࡑࡐࡖࠪਰ")		: zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠷࠸࠳ી")
	,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ਱")		: nR0ok9zju84rFUQl1YC(u"࠸࠺࠴ુ")
	,pbmKZA1w7L4zHjOM(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧਲ")		: YzlId3Fs6vpehcbLGj0UaO(u"࠹࠼࠵ૂ")
	,ba49YvOK2Aw8Uhxt(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨਲ਼")		: lRKCWnNi0Edr984eI(u"࠺࠾࠶ૃ")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡎࡄࡖࡔࡠࡁࠨ਴")		: B1YMtuvRAGNlJOkC46VyPKQE(u"࠼࠶࠰ૄ")
	,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡐ࠷࡚ࡥ࠰ࠨਵ")		: lRKCWnNi0Edr984eI(u"࠽࠱࠱ૅ")
	,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡑ࠸࡛࡟࠲ࠩਸ਼")		: zWBnYSGIatjXVC(u"࠷࠳࠲૆")
	,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ਷")	: W2Vv30i8qxSuItfsolPLdFZA(u"࠸࠵࠳ે")
	,rAYDiWlzm9MCU6x0GnROua(u"ࠬࡉࡌࡆࡃࡑࡉࡗࡥ࠰ࠨਸ")	: f9fOpCmLAEaW2Go(u"࠹࠷࠴ૈ")
	,kAz7WRYjrfGm(u"࠭ࡃࡍࡇࡄࡒࡊࡘ࡟࠲ࠩਹ")	: ba49YvOK2Aw8Uhxt(u"࠺࠹࠵ૉ")
	,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡓࡃࡑࡈࡔࡓࡓࡠ࠳ࠪ਺")	: B1YMtuvRAGNlJOkC46VyPKQE(u"࠻࠻࠶૊")
	,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ਻")		: lRKCWnNi0Edr984eI(u"࠼࠽࠰ો")
	,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵਼ࠫ")		: nR0ok9zju84rFUQl1YC(u"࠽࠸࠱ૌ")
	,zWBnYSGIatjXVC(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ਽")		: hWRvZOYtjme9QNnV41u0Mswb(u"࠷࠺࠲્")
	,KKCrwPdOgGl(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ਾ")		: zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠹࠲࠳૎")
	,CCWqR3dmtzw6xoIX41(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧਿ")		: lRKCWnNi0Edr984eI(u"࠺࠴࠴૏")
	,Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨੀ")		: bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠻࠶࠵ૐ")
	,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩੁ")		: pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠼࠸࠶૑")
	,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪੂ")		: zWBnYSGIatjXVC(u"࠽࠺࠰૒")
	,nR0ok9zju84rFUQl1YC(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ੃")	: lRKCWnNi0Edr984eI(u"࠾࠵࠱૓")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫ੄")		: JZ45mOctiTszPNw1GVjxhep2Y(u"࠸࠷࠲૔")
	,W2Vv30i8qxSuItfsolPLdFZA(u"࡛ࠫࡇࡒࡃࡑࡑࠫ੅")		: B1YMtuvRAGNlJOkC46VyPKQE(u"࠹࠹࠳૕")
	,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬ੆")		: pYeVwat64v(u"࠺࠻࠴૖")
	,hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪੇ")	: jBbkfIJSDqcVwl8irzy4Z3O(u"࠻࠽࠵૗")
	,w9wfONXUP3(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬੈ")	: CCWqR3dmtzw6xoIX41(u"࠽࠵࠶૘")
	,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ੉")		: bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠾࠷࠰૙")
	,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪ੊")		: nR0ok9zju84rFUQl1YC(u"࠿࠲࠱૚")
	,lRKCWnNi0Edr984eI(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ੋ")	: pbmKZA1w7L4zHjOM(u"࠹࠴࠲૛")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࡙ࠫࡏࡋࡂࡃࡗࠫੌ")		: nR0ok9zju84rFUQl1YC(u"࠺࠶࠳૜")
	,f9fOpCmLAEaW2Go(u"ࠬࡗࡆࡊࡎࡐ੍ࠫ")		: pbmKZA1w7L4zHjOM(u"࠻࠸࠴૝")
	,CCWqR3dmtzw6xoIX41(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩ੎")	: Zb5cNeHWi6jP9SCYtUgR(u"࠼࠺࠵૞")
	,KKCrwPdOgGl(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩ੏")		: vl6rwMLasAQo4z1ZjD3IBKtF(u"࠽࠼࠶૟")
	,w9wfONXUP3(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪ੐")		: zWBnYSGIatjXVC(u"࠾࠾࠰ૠ")
	,Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪੑ")		: KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠿࠹࠱ૡ")
	,JZ45mOctiTszPNw1GVjxhep2Y(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫ੒")		: pL73X0MYajJQG4n1qgD(u"࠱࠱࠲࠳ૢ")
	,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪ੓")	: W2Vv30i8qxSuItfsolPLdFZA(u"࠲࠲࠴࠴ૣ")
	,rAYDiWlzm9MCU6x0GnROua(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠷ࠩ੔")	: jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠳࠶࠵૤")
	,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪ੕")	: djapWhrveLJbgnViDftFNY05ylq1S(u"࠴࠴࠸࠶૥")
	,ba49YvOK2Aw8Uhxt(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪ੖")	: KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠵࠵࠺࠰૦")
	,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡃ࡜ࡐࡔࡒࠧ੗")		: jBbkfIJSDqcVwl8irzy4Z3O(u"࠶࠶࠵࠱૧")
	,KKCrwPdOgGl(u"ࠩࡈࡐࡎࡌࡖࡊࡆࡈࡓࠬ੘")	: jBbkfIJSDqcVwl8irzy4Z3O(u"࠷࠰࠷࠲૨")
	,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫਖ਼")		: KKCrwPdOgGl(u"࠱࠱࠹࠳૩")
	,I6Bfzysrvb8DONZ(u"ࠫࡈࡒࡅࡂࡐࡈࡖࡤ࠸ࠧਗ਼")	: GTmHXIZUSdxRhMnqQKkO(u"࠲࠲࠻࠴૪")
	,Zb5cNeHWi6jP9SCYtUgR(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠲ࠨਜ਼")	: KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠳࠳࠽࠵૫")
}