# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ௶")
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,s3chK0CpdkqFzAr6UvZloXHTwMxQmf):
	if   t5fhagjUGXk0ynOlJWeAb==rAYDiWlzm9MCU6x0GnROua(u"࠸࠹࠰಄"): Ubud2NhHKRnMTvI5mprQBVqk80 = xpJlic0dQMA8BzemTOv()
	elif t5fhagjUGXk0ynOlJWeAb==GTmHXIZUSdxRhMnqQKkO(u"࠹࠳࠲ಅ"): Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(s3chK0CpdkqFzAr6UvZloXHTwMxQmf)
	elif t5fhagjUGXk0ynOlJWeAb==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠳࠴࠴ಆ"): Ubud2NhHKRnMTvI5mprQBVqk80 = DwHVocxYzgEiUNI1ryPaG4AZknQS()
	elif t5fhagjUGXk0ynOlJWeAb==pbmKZA1w7L4zHjOM(u"࠴࠵࠶ಇ"): Ubud2NhHKRnMTvI5mprQBVqk80 = cxFWYLm4D6ECquJSTwkIUXr7Q()
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = pLwgjkuTs6CS
	return Ubud2NhHKRnMTvI5mprQBVqk80
def QgIZSJdUhsEnup8GPz3(s3chK0CpdkqFzAr6UvZloXHTwMxQmf):
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,mI6ayKxBvjd4CRthL,pL73X0MYajJQG4n1qgD(u"ࠫࡻ࡯ࡤࡦࡱࠪ௷"))
	return
def cxFWYLm4D6ECquJSTwkIUXr7Q():
	mlrXUnyLzPAhEIj8ix5Ztpu = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬษะ่สࠣษ้๏ࠠาษห฻ࠥอไโ์า๎ํࠦร้ࠢสฺ่๎สࠡใํࠤฬ๊ๅ้ไ฼ࠤฬ๊ๅุๆ๋ฬࠥัๅࠡลู฾฼ูࠦๅ๋ࠣึึࠦวๅไสส๊ฯࠠศๆํ้๏์ࠠฬ็ࠣวำะวาࠢࠥฮา๋๊ๅ่่ࠢๆอสࠡใํำ๏๎ࠢࠡอ่ࠤฬิสศำࠣำ็ฯࠠศๆุ์ึฯ้ࠠษัฮฬืࠠ็๊฼ࠤ๊๊แࠡษ็ูํืษ๊ࠡห฽ิํวࠡี๋ๅࠥ๐ศะลࠣห้ะอๆ์็ࠫ௸")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠭ืา์ๅอࠥะอๆ์็ࠤฬ๊ๅๅใสฮࠬ௹"),mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def xpJlic0dQMA8BzemTOv():
	w3BfOGLdXcWzbiC1PYx9mE(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧ࡭࡫ࡱ࡯ࠬ௺"),pbmKZA1w7L4zHjOM(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭௻"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"࠵࠶࠷ಈ"))
	w3BfOGLdXcWzbiC1PYx9mE(pbmKZA1w7L4zHjOM(u"ࠩ࡯࡭ࡳࡱࠧ௼"),kAz7WRYjrfGm(u"ࠪฮ฿๐๊า่ࠢ็ฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪ௽"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠶࠷࠷ಉ"))
	w3BfOGLdXcWzbiC1PYx9mE(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡱ࡯࡮࡬ࠩ௾"),qFghPAi5yz9Vf3NLwo0nuprl+Zb5cNeHWi6jP9SCYtUgR(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ௿")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"࠽࠾࠿࠹ಊ"))
	yvY6iXSuDGqkwLOsp9gJ4WTIjeM5 = JkSU3RLZlrfhPvCTaGwuoqd()
	SqX06EoAxjLVDYQkTPFC = oNlez5gnM9x2B4.stat(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5).st_mtime
	AehPEBHmikb0MnWaDZwUGQo = []
	if fOohwvakqi29cx0l3yt5mzrAGpEg: DD1PacxqGs4ivUubdZfKIYlTV37QAR = oNlez5gnM9x2B4.listdir(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5.encode(RMGz7OiD1e30P))
	else: DD1PacxqGs4ivUubdZfKIYlTV37QAR = oNlez5gnM9x2B4.listdir(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5.decode(RMGz7OiD1e30P))
	for jIqXUsh9yNOYaf32R in DD1PacxqGs4ivUubdZfKIYlTV37QAR:
		if fOohwvakqi29cx0l3yt5mzrAGpEg: jIqXUsh9yNOYaf32R = jIqXUsh9yNOYaf32R.decode(RMGz7OiD1e30P)
		if not jIqXUsh9yNOYaf32R.startswith(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡦࡪ࡮ࡨࡣࠬఀ")): continue
		WUmCToJdhjXe9v = oNlez5gnM9x2B4.path.join(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5,jIqXUsh9yNOYaf32R)
		SqX06EoAxjLVDYQkTPFC = oNlez5gnM9x2B4.path.getmtime(WUmCToJdhjXe9v)
		AehPEBHmikb0MnWaDZwUGQo.append([jIqXUsh9yNOYaf32R,SqX06EoAxjLVDYQkTPFC])
	AehPEBHmikb0MnWaDZwUGQo = sorted(AehPEBHmikb0MnWaDZwUGQo,reverse=NFGqKBLtvUZn1S3dau,key=lambda key: key[xD9WeoEAsX7])
	for jIqXUsh9yNOYaf32R,SqX06EoAxjLVDYQkTPFC in AehPEBHmikb0MnWaDZwUGQo:
		if hT1JIgqPQsUOZp5tjCX0E:
			try: jIqXUsh9yNOYaf32R = jIqXUsh9yNOYaf32R.decode(RMGz7OiD1e30P)
			except: pass
			jIqXUsh9yNOYaf32R = jIqXUsh9yNOYaf32R.encode(RMGz7OiD1e30P)
		WUmCToJdhjXe9v = oNlez5gnM9x2B4.path.join(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5,jIqXUsh9yNOYaf32R)
		w3BfOGLdXcWzbiC1PYx9mE(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡷ࡫ࡧࡩࡴ࠭ఁ"),jIqXUsh9yNOYaf32R,WUmCToJdhjXe9v,pYeVwat64v(u"࠸࠹࠱ಋ"))
	return
def JkSU3RLZlrfhPvCTaGwuoqd():
	yvY6iXSuDGqkwLOsp9gJ4WTIjeM5 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫం"))
	if yvY6iXSuDGqkwLOsp9gJ4WTIjeM5: return yvY6iXSuDGqkwLOsp9gJ4WTIjeM5
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬః"),eC21aUbHsMhBQnfVypk8T)
	return eC21aUbHsMhBQnfVypk8T
def DwHVocxYzgEiUNI1ryPaG4AZknQS():
	yvY6iXSuDGqkwLOsp9gJ4WTIjeM5 = JkSU3RLZlrfhPvCTaGwuoqd()
	VYrjvKZQcFNuUAeS8dHw0q49zyOxf1 = hhTcd5XlykBUu68zAb9OmgC(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡧࡪࡴࡴࡦࡴࠪఄ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨఅ"),oamlxBqLdu4ZM9nQrbIAhS5Pg7+yvY6iXSuDGqkwLOsp9gJ4WTIjeM5+so4Z8OUJ5E+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไโ์า๎ํࠦวๅฬํࠤฯำๅๅ้สࠤฬ์สࠡสสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะฺ๋์ิࠤฬ๊ๅไษ้ࠤฤ࠭ఆ"))
	if VYrjvKZQcFNuUAeS8dHw0q49zyOxf1==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠷ಌ"):
		DH7Sea623ChEKvkqfgpjdX4 = ddMy7StKng0rkXPIzaJOULwEo4(GTmHXIZUSdxRhMnqQKkO(u"࠳಍"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ๅไษ้ࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪఇ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧ࡭ࡱࡦࡥࡱ࠭ఈ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau,yvY6iXSuDGqkwLOsp9gJ4WTIjeM5)
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨఉ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"่ࠩ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไหฯ่๎้࠭ఊ"),oamlxBqLdu4ZM9nQrbIAhS5Pg7+yvY6iXSuDGqkwLOsp9gJ4WTIjeM5+so4Z8OUJ5E+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡠࡳࡢ࡮่าสࠤ์๎ࠠศๆ่็ฬ์ࠠศๆฯำ๏ีࠠๅฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ࠡสา่ฬࠦๅ็ࠢส่๊้ว็ࠢส่็ี๊ๆࠢยࠫఋ"))
		if e6f0ycMuYQEJraNLInmip==W2Vv30i8qxSuItfsolPLdFZA(u"࠲ಎ"):
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧఌ"),DH7Sea623ChEKvkqfgpjdX4)
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,I6Bfzysrvb8DONZ(u"ࠬะๅࠡฬ฽๎๏ืࠠๆๅส๊ࠥะฮำ์้ࠤฬ๊ๅๅใสฮࠥอไๆฯ่่ฮ࠭఍"))
	return
def lsvrBiaNnCVqAJZu9W36g8bU(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,BQdRPYjZiS=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ఎ")+s3chK0CpdkqFzAr6UvZloXHTwMxQmf+pbmKZA1w7L4zHjOM(u"ࠧࠡ࡟ࠪఏ"))
	if not BQdRPYjZiS: BQdRPYjZiS = azP0kLi9Uc6(s3chK0CpdkqFzAr6UvZloXHTwMxQmf)
	yvY6iXSuDGqkwLOsp9gJ4WTIjeM5 = JkSU3RLZlrfhPvCTaGwuoqd()
	hvIznkl0UTZtp6OXMaLd5juBP4EG8r = cqHgRBFQ7XmEkTx50nWLS6fIhDb(pLwgjkuTs6CS)
	jIqXUsh9yNOYaf32R = hvIznkl0UTZtp6OXMaLd5juBP4EG8r.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡡࠪఐ"))
	jIqXUsh9yNOYaf32R = bLXh6Qy5Tewk(jIqXUsh9yNOYaf32R)
	jIqXUsh9yNOYaf32R = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡩ࡭ࡱ࡫࡟ࠨ఑")+str(int(KKydonNSglP1M08xw7O))[-fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠶ಏ"):]+YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡣࠬఒ")+jIqXUsh9yNOYaf32R+BQdRPYjZiS
	iOUrJE4dltPaF0LCw = oNlez5gnM9x2B4.path.join(yvY6iXSuDGqkwLOsp9gJ4WTIjeM5,jIqXUsh9yNOYaf32R)
	Y64UgIz2uFvr30eLtDGyqanRZQKN = {}
	Y64UgIz2uFvr30eLtDGyqanRZQKN[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ఓ")] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Y64UgIz2uFvr30eLtDGyqanRZQKN[rAYDiWlzm9MCU6x0GnROua(u"ࠬࡇࡣࡤࡧࡳࡸࠬఔ")] = pbmKZA1w7L4zHjOM(u"࠭ࠪ࠰ࠬࠪక")
	s3chK0CpdkqFzAr6UvZloXHTwMxQmf = s3chK0CpdkqFzAr6UvZloXHTwMxQmf.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪఖ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if zWBnYSGIatjXVC(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭గ") in s3chK0CpdkqFzAr6UvZloXHTwMxQmf:
		nUDgc4absePT2xMt,xL93S8G1wJdkPsa = s3chK0CpdkqFzAr6UvZloXHTwMxQmf.rsplit(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧఘ"),nR0ok9zju84rFUQl1YC(u"࠴ಐ"))
		xL93S8G1wJdkPsa = xL93S8G1wJdkPsa.replace(KKCrwPdOgGl(u"ࠪࢀࠬఙ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(kAz7WRYjrfGm(u"ࠫࠫ࠭చ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	else: nUDgc4absePT2xMt,xL93S8G1wJdkPsa = s3chK0CpdkqFzAr6UvZloXHTwMxQmf,None
	if not xL93S8G1wJdkPsa: xL93S8G1wJdkPsa = YwSBWkv2f3Us()
	if xL93S8G1wJdkPsa: Y64UgIz2uFvr30eLtDGyqanRZQKN[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩఛ")] = xL93S8G1wJdkPsa
	if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨజ") in nUDgc4absePT2xMt: nUDgc4absePT2xMt,YVbC0fFvJRDSZLlc1w7ojzE = nUDgc4absePT2xMt.rsplit(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩఝ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵಑"))
	else: nUDgc4absePT2xMt,YVbC0fFvJRDSZLlc1w7ojzE = nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	nUDgc4absePT2xMt = nUDgc4absePT2xMt.strip(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡾࠪఞ")).strip(kAz7WRYjrfGm(u"ࠩࠩࠫట")).strip(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࢀࠬఠ")).strip(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࠫ࠭డ"))
	YVbC0fFvJRDSZLlc1w7ojzE = YVbC0fFvJRDSZLlc1w7ojzE.replace(ba49YvOK2Aw8Uhxt(u"ࠬࢂࠧఢ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(KKCrwPdOgGl(u"࠭ࠦࠨణ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if YVbC0fFvJRDSZLlc1w7ojzE:	Y64UgIz2uFvr30eLtDGyqanRZQKN[w9wfONXUP3(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨత")] = YVbC0fFvJRDSZLlc1w7ojzE
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+I6Bfzysrvb8DONZ(u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩథ")+nUDgc4absePT2xMt+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬద")+str(Y64UgIz2uFvr30eLtDGyqanRZQKN)+CCWqR3dmtzw6xoIX41(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪధ")+iOUrJE4dltPaF0LCw+KKCrwPdOgGl(u"ࠫࠥࡣࠧన"))
	zsnpLKb3Oi = B1YMtuvRAGNlJOkC46VyPKQE(u"࠶࠶࠲࠵ಒ")*B1YMtuvRAGNlJOkC46VyPKQE(u"࠶࠶࠲࠵ಒ")
	iQUrRqMOa2le4t0sNzI3f7bFkZ = aID4r82pKW1F0LM6AynBHiObkqt()//zsnpLKb3Oi
	if not iQUrRqMOa2le4t0sNzI3f7bFkZ:
		RsYWOkAC8t4iMUoBd0K(rAYDiWlzm9MCU6x0GnROua(u"ࠬࡸࡩࡨࡪࡷࠫ఩"),CCWqR3dmtzw6xoIX41(u"࠭ๅิษะอࠥอไหะี๎๋ࠦๅอ้๋่ฮ࠭ప"),w9wfONXUP3(u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣว๋๊ࠦฮัาࠤ๊่ฯศำุ้ࠣออสࠢส่ฯิา๋่ࠣห้็วา฼ฬࠤๆ๐ࠠอ้สึฺ่่ࠦๆํ๋ࠥ็ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ๊ࠥๆࠡ์฼ู้้ࠦ็ัๆࠤส๊้ࠡล้ࠤ๏่่ๆ่ࠢฬึ๋ฬ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠษฯ็ࠤ์ึ็ࠡษ็ู้้ไสࠢ็ห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢๅำࠥ๐ำษสࠣห๊ะไศรࠣะ์อาไࠢหห้๋ไโษอࠤํํะศࠢไ๎์ࠦฮุ๊ิอࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ์้ํะศࠢสุ่ฮศࠡไส้ࠥอไๆสิ้ัࠦๅลไอหࠥฮๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫఫ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫబ"))
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+KKCrwPdOgGl(u"ࠩࠣࠤ࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡦ࡬ࡷࡰࠦࡦࡳࡧࡨࠤࡸࡶࡡࡤࡧࠪభ"))
		return pLwgjkuTs6CS
	if BQdRPYjZiS==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩమ"):
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = vn9QxuZF4f2YzCVpELgkc(mI6ayKxBvjd4CRthL,nUDgc4absePT2xMt,Y64UgIz2uFvr30eLtDGyqanRZQKN)
		if len(GjC4atkJLwlTpsI)==w9wfONXUP3(u"࠶ಓ"):
			ARL0tsEeanKImhMByugPTvX7(kAz7WRYjrfGm(u"ࠫๆฺไࠡใํࠤส๐ฬศั้้ࠣ็ࠠศๆอั๊๐ไࠨయ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			return pLwgjkuTs6CS
		elif len(GjC4atkJLwlTpsI)==awSUTRNMkdIW7sFEvnHD2mLY(u"࠱ಔ"): qNmsBD1jJZVzcxi4onKuAOIC = rAYDiWlzm9MCU6x0GnROua(u"࠱ಕ")
		elif len(GjC4atkJLwlTpsI)>Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠳ಖ"):
			qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪర"), GjC4atkJLwlTpsI)
			if qNmsBD1jJZVzcxi4onKuAOIC == -GTmHXIZUSdxRhMnqQKkO(u"࠴ಗ") :
				ARL0tsEeanKImhMByugPTvX7(pbmKZA1w7L4zHjOM(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩఱ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				return pLwgjkuTs6CS
		nUDgc4absePT2xMt = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	ppoUgmhLrCzk7u86De = GTmHXIZUSdxRhMnqQKkO(u"࠴ಘ")
	import requests as SS8ZY4U9vcFkEJ0yQgueqAbo
	if BQdRPYjZiS==f9fOpCmLAEaW2Go(u"ࠧ࠯࡯࠶ࡹ࠽࠭ల"):
		iOUrJE4dltPaF0LCw = iOUrJE4dltPaF0LCw.rsplit(zWBnYSGIatjXVC(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧళ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࠱ࡱࡵ࠺ࠧఴ")
		VpCAFPuW7Nn0evcrZhQ3o8f = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,lRKCWnNi0Edr984eI(u"ࠪࡋࡊ࡚ࠧవ"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y64UgIz2uFvr30eLtDGyqanRZQKN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKCrwPdOgGl(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡠࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫశ"))
		LQ23ROASajyCKoWZtihr1vpzE6 = VpCAFPuW7Nn0evcrZhQ3o8f.content
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀ࠮ࠫࡁ࡞ࡠࡳࡢࡲ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭ష"),LQ23ROASajyCKoWZtihr1vpzE6+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭࡜࡯࡞ࡵࠫస"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not BA01W9olieErLycV7kwFvOhH5Y3ms:
			UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+CCWqR3dmtzw6xoIX41(u"ࠧࠡࠢࠣࡘ࡭࡫ࠠ࡮࠵ࡸ࠼ࠥ࡬ࡩ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡭ࡧࡶࡦࠢࡷ࡬ࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡ࡮࡬ࡲࡰࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪహ")+nUDgc4absePT2xMt+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠢࡠࠫ఺"))
			return pLwgjkuTs6CS
		cX2SpPxGLmADTKl = BA01W9olieErLycV7kwFvOhH5Y3ms[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if not cX2SpPxGLmADTKl.startswith(W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡫ࡸࡹࡶࠧ఻")):
			if cX2SpPxGLmADTKl.startswith(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪ࠳࠴఼࠭")): cX2SpPxGLmADTKl = nUDgc4absePT2xMt.split(CCWqR3dmtzw6xoIX41(u"ࠫ࠿࠭ఽ"),W2Vv30i8qxSuItfsolPLdFZA(u"࠶ಙ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+pL73X0MYajJQG4n1qgD(u"ࠬࡀࠧా")+cX2SpPxGLmADTKl
			elif cX2SpPxGLmADTKl.startswith(GTmHXIZUSdxRhMnqQKkO(u"࠭࠯ࠨి")): cX2SpPxGLmADTKl = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡶࡴ࡯ࠫీ"))+cX2SpPxGLmADTKl
			else: cX2SpPxGLmADTKl = nUDgc4absePT2xMt.rsplit(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨ࠱ࠪు"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠷ಚ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+pYeVwat64v(u"ࠩ࠲ࠫూ")+cX2SpPxGLmADTKl
		VpCAFPuW7Nn0evcrZhQ3o8f = SS8ZY4U9vcFkEJ0yQgueqAbo.request(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡋࡊ࡚ࠧృ"),cX2SpPxGLmADTKl,headers=Y64UgIz2uFvr30eLtDGyqanRZQKN,verify=pLwgjkuTs6CS)
		k7iPYnamBI3A1JvD5zoepM = VpCAFPuW7Nn0evcrZhQ3o8f.content
		riXNDzJuEpQUF2 = len(k7iPYnamBI3A1JvD5zoepM)
		tvzuM8RHS4GkoWO6Zagj = len(BA01W9olieErLycV7kwFvOhH5Y3ms)
		ppoUgmhLrCzk7u86De = riXNDzJuEpQUF2*tvzuM8RHS4GkoWO6Zagj
	else:
		riXNDzJuEpQUF2 = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠱ಛ")*zsnpLKb3Oi
		VpCAFPuW7Nn0evcrZhQ3o8f = SS8ZY4U9vcFkEJ0yQgueqAbo.request(kAz7WRYjrfGm(u"ࠫࡌࡋࡔࠨౄ"),nUDgc4absePT2xMt,headers=Y64UgIz2uFvr30eLtDGyqanRZQKN,verify=pLwgjkuTs6CS,stream=NFGqKBLtvUZn1S3dau)
		if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭౅") in VpCAFPuW7Nn0evcrZhQ3o8f.headers: ppoUgmhLrCzk7u86De = int(VpCAFPuW7Nn0evcrZhQ3o8f.headers[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧె")])
		tvzuM8RHS4GkoWO6Zagj = int(ppoUgmhLrCzk7u86De//riXNDzJuEpQUF2)
	XtUJzk5qbom4 = int(ppoUgmhLrCzk7u86De//zsnpLKb3Oi)+awSUTRNMkdIW7sFEvnHD2mLY(u"࠲ಜ")
	if ppoUgmhLrCzk7u86De<pL73X0MYajJQG4n1qgD(u"࠴࠴࠴࠵࠶ಝ"):
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+f9fOpCmLAEaW2Go(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩే")+nUDgc4absePT2xMt+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬై")+str(XtUJzk5qbom4)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ౉")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ొ")+iOUrJE4dltPaF0LCw+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࠥࡣࠧో"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧౌ"))
		return pLwgjkuTs6CS
	gSf5WwnatXmr7RYJB = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠷࠴࠵ಞ")
	KljBySvQzbeGkuY19fT6U = iQUrRqMOa2le4t0sNzI3f7bFkZ-XtUJzk5qbom4
	if KljBySvQzbeGkuY19fT6U<gSf5WwnatXmr7RYJB:
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ్ࠬ")+nUDgc4absePT2xMt+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ౎")+str(XtUJzk5qbom4)+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ౏")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࠣࡑࡇࠦ࠭ࠡࠩ౐")+str(gSf5WwnatXmr7RYJB)+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭౑")+iOUrJE4dltPaF0LCw+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࠥࡣࠧ౒"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"๊ࠬวࠡ์๋ะิࠦๅิษะอ้ࠥวโ์ฬࠤ้๊สฮ็ํ่ࠬ౓"),pL73X0MYajJQG4n1qgD(u"࠭วๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์ࠦออ็๊ࠤࠬ౔")+str(XtUJzk5qbom4)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อౕࠥ࠭")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+pbmKZA1w7L4zHjOM(u"ࠨ่ࠢ๎฿อศศ์อࠤํ๊ไๆฯสๅ฽ฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษั๋๊๋ࠥิศๅ็ࠤ๏าศࠡวหๆฬวࠠࠨౖ")+str(gSf5WwnatXmr7RYJB)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"้ࠩࠣ๏เวษษํฮࠥ็วา฼ฬࠤิอฦๆษࠣ์์ึวࠡ็฼๊ฬํࠠฤ่ࠣะ์อาไࠢ็หࠥะ่อัࠣๅ๏ํࠠๆีสัฮࠦใศใํอ๊ࠥสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊หࠫ౗"))
		return pLwgjkuTs6CS
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡧࡪࡴࡴࡦࡴࠪౘ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬౙ"),nR0ok9zju84rFUQl1YC(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫౚ")+str(XtUJzk5qbom4)+vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ౛")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ౜"))
	if e6f0ycMuYQEJraNLInmip!=KKCrwPdOgGl(u"࠵ಟ"):
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ౝ"))
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡴ࡬ࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ౞")+nUDgc4absePT2xMt+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ౟")+iOUrJE4dltPaF0LCw+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࠥࡣࠧౠ"))
		return pLwgjkuTs6CS
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+YzlId3Fs6vpehcbLGj0UaO(u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷࡹࡧࡲࡵࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠪౡ"))
	BEjxl7fs2e = QHi2JtdhMaw0INlU()
	BEjxl7fs2e.create(iOUrJE4dltPaF0LCw,djapWhrveLJbgnViDftFNY05ylq1S(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧౢ"))
	R6EpoXcQie27FnuNd9Y4t3Z0 = NFGqKBLtvUZn1S3dau
	YA8zxD2L9ielGsFuIW4vh = f7epsRlYtMz4.time()
	if not drzqWFkSHD.rRAX8UJPclQdTshyt2Mew4Vb3:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,hWRvZOYtjme9QNnV41u0Mswb(u"ࠧษีหฬࠥ฿ฯๆࠢส่ฯฮัฺࠢอ้ࠥหไ฻ษฤࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨౣ"))
		return pLwgjkuTs6CS
	if fOohwvakqi29cx0l3yt5mzrAGpEg: z4so3idKEZWnJRGk9TplPr8Mv0 = open(iOUrJE4dltPaF0LCw,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡹࡥࠫ౤"))
	else: z4so3idKEZWnJRGk9TplPr8Mv0 = open(iOUrJE4dltPaF0LCw.decode(RMGz7OiD1e30P),pL73X0MYajJQG4n1qgD(u"ࠩࡺࡦࠬ౥"))
	if BQdRPYjZiS==kAz7WRYjrfGm(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ౦"):
		for r6dVWlzDj9va0FxqfkOwLYZEmP in range(ba49YvOK2Aw8Uhxt(u"࠶ಠ"),tvzuM8RHS4GkoWO6Zagj+ba49YvOK2Aw8Uhxt(u"࠶ಠ")):
			cX2SpPxGLmADTKl = BA01W9olieErLycV7kwFvOhH5Y3ms[r6dVWlzDj9va0FxqfkOwLYZEmP-Zb5cNeHWi6jP9SCYtUgR(u"࠷ಡ")]
			if not cX2SpPxGLmADTKl.startswith(pYeVwat64v(u"ࠫ࡭ࡺࡴࡱࠩ౧")):
				if cX2SpPxGLmADTKl.startswith(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࠵࠯ࠨ౨")): cX2SpPxGLmADTKl = nUDgc4absePT2xMt.split(jBbkfIJSDqcVwl8irzy4Z3O(u"࠭࠺ࠨ౩"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠱ಢ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧ࠻ࠩ౪")+cX2SpPxGLmADTKl
				elif cX2SpPxGLmADTKl.startswith(pYeVwat64v(u"ࠨ࠱ࠪ౫")): cX2SpPxGLmADTKl = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡸࡶࡱ࠭౬"))+cX2SpPxGLmADTKl
				else: cX2SpPxGLmADTKl = nUDgc4absePT2xMt.rsplit(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪ࠳ࠬ౭"),lRKCWnNi0Edr984eI(u"࠲ಣ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫ࠴࠭౮")+cX2SpPxGLmADTKl
			VpCAFPuW7Nn0evcrZhQ3o8f = SS8ZY4U9vcFkEJ0yQgueqAbo.request(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡍࡅࡕࠩ౯"),cX2SpPxGLmADTKl,headers=Y64UgIz2uFvr30eLtDGyqanRZQKN,verify=pLwgjkuTs6CS)
			k7iPYnamBI3A1JvD5zoepM = VpCAFPuW7Nn0evcrZhQ3o8f.content
			VpCAFPuW7Nn0evcrZhQ3o8f.close()
			z4so3idKEZWnJRGk9TplPr8Mv0.write(k7iPYnamBI3A1JvD5zoepM)
			JkeMAgIa0bV = f7epsRlYtMz4.time()
			zX7WKJoCBxdV59g0reGkHa3 = JkeMAgIa0bV-YA8zxD2L9ielGsFuIW4vh
			hMBWq0refk2 = zX7WKJoCBxdV59g0reGkHa3//r6dVWlzDj9va0FxqfkOwLYZEmP
			FCfurJwOZzdNsMD3gqcEBhi = hMBWq0refk2*(tvzuM8RHS4GkoWO6Zagj+W2Vv30i8qxSuItfsolPLdFZA(u"࠳ತ"))
			HPSBvO2jRMosG9Yichtp = FCfurJwOZzdNsMD3gqcEBhi-zX7WKJoCBxdV59g0reGkHa3
			jRhY6cet0NVsfGIr(BEjxl7fs2e,int(zWBnYSGIatjXVC(u"࠵࠵࠶ದ")*r6dVWlzDj9va0FxqfkOwLYZEmP//(tvzuM8RHS4GkoWO6Zagj+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠴ಥ"))),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧ౰"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ౱"),str(r6dVWlzDj9va0FxqfkOwLYZEmP*riXNDzJuEpQUF2//zsnpLKb3Oi)+hWRvZOYtjme9QNnV41u0Mswb(u"ࠨ࠱ࠪ౲")+str(XtUJzk5qbom4)+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧ౳")+f7epsRlYtMz4.strftime(I6Bfzysrvb8DONZ(u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ౴"),f7epsRlYtMz4.gmtime(HPSBvO2jRMosG9Yichtp))+lRKCWnNi0Edr984eI(u"ࠫࠥๆࠧ౵"))
			if BEjxl7fs2e.iscanceled():
				R6EpoXcQie27FnuNd9Y4t3Z0 = pLwgjkuTs6CS
				break
	else:
		r6dVWlzDj9va0FxqfkOwLYZEmP = I6Bfzysrvb8DONZ(u"࠵ಧ")
		for k7iPYnamBI3A1JvD5zoepM in VpCAFPuW7Nn0evcrZhQ3o8f.iter_content(chunk_size=riXNDzJuEpQUF2):
			z4so3idKEZWnJRGk9TplPr8Mv0.write(k7iPYnamBI3A1JvD5zoepM)
			r6dVWlzDj9va0FxqfkOwLYZEmP = r6dVWlzDj9va0FxqfkOwLYZEmP+jBbkfIJSDqcVwl8irzy4Z3O(u"࠷ನ")
			JkeMAgIa0bV = f7epsRlYtMz4.time()
			zX7WKJoCBxdV59g0reGkHa3 = JkeMAgIa0bV-YA8zxD2L9ielGsFuIW4vh
			hMBWq0refk2 = zX7WKJoCBxdV59g0reGkHa3/r6dVWlzDj9va0FxqfkOwLYZEmP
			FCfurJwOZzdNsMD3gqcEBhi = hMBWq0refk2*(tvzuM8RHS4GkoWO6Zagj+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠱಩"))
			HPSBvO2jRMosG9Yichtp = FCfurJwOZzdNsMD3gqcEBhi-zX7WKJoCBxdV59g0reGkHa3
			jRhY6cet0NVsfGIr(BEjxl7fs2e,int(vl6rwMLasAQo4z1ZjD3IBKtF(u"࠳࠳࠴ಫ")*r6dVWlzDj9va0FxqfkOwLYZEmP/(tvzuM8RHS4GkoWO6Zagj+pbmKZA1w7L4zHjOM(u"࠲ಪ"))),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭౶"),JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭౷"),str(r6dVWlzDj9va0FxqfkOwLYZEmP*riXNDzJuEpQUF2//zsnpLKb3Oi)+zWBnYSGIatjXVC(u"ࠧ࠰ࠩ౸")+str(XtUJzk5qbom4)+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭౹")+f7epsRlYtMz4.strftime(pbmKZA1w7L4zHjOM(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ౺"),f7epsRlYtMz4.gmtime(HPSBvO2jRMosG9Yichtp))+GTmHXIZUSdxRhMnqQKkO(u"ࠪࠤๅ࠭౻"))
			if BEjxl7fs2e.iscanceled():
				R6EpoXcQie27FnuNd9Y4t3Z0 = pLwgjkuTs6CS
				break
		VpCAFPuW7Nn0evcrZhQ3o8f.close()
	z4so3idKEZWnJRGk9TplPr8Mv0.close()
	BEjxl7fs2e.close()
	if not R6EpoXcQie27FnuNd9Y4t3Z0:
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ౼")+nUDgc4absePT2xMt+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ౽")+iOUrJE4dltPaF0LCw+jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࠠ࡞ࠩ౾"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,hWRvZOYtjme9QNnV41u0Mswb(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ౿"))
		return NFGqKBLtvUZn1S3dau
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧಀ")+nUDgc4absePT2xMt+I6Bfzysrvb8DONZ(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩಁ")+iOUrJE4dltPaF0LCw+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࠤࡢ࠭ಂ"))
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪಃ"))
	return NFGqKBLtvUZn1S3dau