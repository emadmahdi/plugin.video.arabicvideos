# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨᱢ")
qBAgzkG9oCL = KKCrwPdOgGl(u"ࠨࡡࡏࡗ࡙ࡥࠧᱣ")
GGBXMJbitIEs = gybxTLFEw2
WJikI9S3MXfC = w9wfONXUP3(u"࠵࠵Ỏ")
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,url,ggM5TzCxq24sDYLiEatpdSK7FQyGe,GpwRnQ6q2o1fv0HbJTs,CC8RbxJ4AHh9rgjTdBsU):
	try: ozc8fP05O4GntlhQgRyCZmeKI3F = str(CC8RbxJ4AHh9rgjTdBsU[pL73X0MYajJQG4n1qgD(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱤ")])
	except: ozc8fP05O4GntlhQgRyCZmeKI3F = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if   t5fhagjUGXk0ynOlJWeAb==rAYDiWlzm9MCU6x0GnROua(u"࠶࠼࠰ỏ"): Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif t5fhagjUGXk0ynOlJWeAb==pL73X0MYajJQG4n1qgD(u"࠷࠶࠲Ố"): Ubud2NhHKRnMTvI5mprQBVqk80 = xxCV7gIP9bHURMdzA6Dkul(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==I6Bfzysrvb8DONZ(u"࠱࠷࠴ố"): Ubud2NhHKRnMTvI5mprQBVqk80 = pUByoDEWmkJlG5Ne04F68QAYx(ggM5TzCxq24sDYLiEatpdSK7FQyGe,I6Bfzysrvb8DONZ(u"࠱࠷࠴ố"))
	elif t5fhagjUGXk0ynOlJWeAb==f9fOpCmLAEaW2Go(u"࠲࠸࠶Ồ"): Ubud2NhHKRnMTvI5mprQBVqk80 = pUByoDEWmkJlG5Ne04F68QAYx(ggM5TzCxq24sDYLiEatpdSK7FQyGe,f9fOpCmLAEaW2Go(u"࠲࠸࠶Ồ"))
	elif t5fhagjUGXk0ynOlJWeAb==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠳࠹࠸ồ"): Ubud2NhHKRnMTvI5mprQBVqk80 = MYn4ja3VSqeZLCT1bf6d(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==awSUTRNMkdIW7sFEvnHD2mLY(u"࠴࠺࠺Ổ"): Ubud2NhHKRnMTvI5mprQBVqk80 = KEuNBQlIzJn(url,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==zWBnYSGIatjXVC(u"࠵࠻࠼ổ"): Ubud2NhHKRnMTvI5mprQBVqk80 = Qte6yJ813hS2frjn0bLKAVlZD(url,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==kAz7WRYjrfGm(u"࠶࠼࠷Ỗ"): Ubud2NhHKRnMTvI5mprQBVqk80 = QUZaDEuqdCw3AGNPY270bMmJyK6Lc8(url,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠷࠶࠹ỗ"): Ubud2NhHKRnMTvI5mprQBVqk80 = XXtDmFRPHoixnypOTSCM065ZNLg(url,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷࠷࠳Ộ"): Ubud2NhHKRnMTvI5mprQBVqk80 = NmF6DuTn0Y()
	elif t5fhagjUGXk0ynOlJWeAb==jBbkfIJSDqcVwl8irzy4Z3O(u"࠸࠸࠵ộ"): Ubud2NhHKRnMTvI5mprQBVqk80 = VBqTrbhewcRF8OEd0SyPuJlox()
	elif t5fhagjUGXk0ynOlJWeAb==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠹࠹࠷Ớ"): Ubud2NhHKRnMTvI5mprQBVqk80 = kf3rHC5bYFxAmT9go2PNeIyWhQ1(ozc8fP05O4GntlhQgRyCZmeKI3F,ggM5TzCxq24sDYLiEatpdSK7FQyGe,GpwRnQ6q2o1fv0HbJTs)
	elif t5fhagjUGXk0ynOlJWeAb==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠺࠺࠹ớ"): Ubud2NhHKRnMTvI5mprQBVqk80 = QKU1ST0w6PJuiI9dCsoOvftA(ozc8fP05O4GntlhQgRyCZmeKI3F,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠻࠻࠻Ờ"): Ubud2NhHKRnMTvI5mprQBVqk80 = BWGhuzI8S0xKp2A16PoO3cJYfaiqL(ozc8fP05O4GntlhQgRyCZmeKI3F,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = pLwgjkuTs6CS
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡪࡴࡲࡤࡦࡴࠪᱥ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫ็์่ศฬࠣฮ้็า๋๊้ࠤ฾ฺ่ศศํอࠬᱦ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠶࠼࠱ờ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱧ"))
	w3BfOGLdXcWzbiC1PYx9mE(rAYDiWlzm9MCU6x0GnROua(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱨ"),KKCrwPdOgGl(u"ࠧใี่ࠤ฾ฺ่ศศํࠫᱩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"࠷࠶࠳Ở"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᱪ"))
	w3BfOGLdXcWzbiC1PYx9mE(pYeVwat64v(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱫ"),I6Bfzysrvb8DONZ(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭ᱬ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"࠱࠷࠵ở"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱭ"))
	w3BfOGLdXcWzbiC1PYx9mE(ba49YvOK2Aw8Uhxt(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱮ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎ࠬᱯ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠲࠸࠷Ỡ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᱰ"))
	w3BfOGLdXcWzbiC1PYx9mE(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱱ"),pbmKZA1w7L4zHjOM(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬᱲ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠹࠹࠷ỡ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬᱳ"))
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠫࡱ࡯࡮࡬ࠩᱴ"),qFghPAi5yz9Vf3NLwo0nuprl+zWBnYSGIatjXVC(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᱵ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"࠼࠽࠾࠿Ợ"))
	w3BfOGLdXcWzbiC1PYx9mE(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱶ"),nR0ok9zju84rFUQl1YC(u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫᱷ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"࠵࠻࠹ợ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CCWqR3dmtzw6xoIX41(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱸ"))
	w3BfOGLdXcWzbiC1PYx9mE(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱹ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪᱺ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"࠶࠼࠳Ụ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᱻ"))
	w3BfOGLdXcWzbiC1PYx9mE(I6Bfzysrvb8DONZ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱼ"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭ᱽ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"࠷࠶࠳ụ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᱾"))
	w3BfOGLdXcWzbiC1PYx9mE(zWBnYSGIatjXVC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᱿"),lRKCWnNi0Edr984eI(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᲀ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"࠱࠷࠴Ủ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲁ"))
	w3BfOGLdXcWzbiC1PYx9mE(YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲂ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤอำหࠡ฻ื์ฬฬ๊ࠨᲃ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠲࠸࠷ủ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲄ"))
	w3BfOGLdXcWzbiC1PYx9mE(pL73X0MYajJQG4n1qgD(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲅ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᲆ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"࠹࠹࠹Ứ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲇ"))
	w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡰ࡮ࡴ࡫ࠨᲈ"),qFghPAi5yz9Vf3NLwo0nuprl+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᲉ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"࠼࠽࠾࠿ứ"))
	w3BfOGLdXcWzbiC1PYx9mE(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲊ"),KKCrwPdOgGl(u"࠭โ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫ᲋"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"࠵࠻࠹Ừ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᲌"))
	w3BfOGLdXcWzbiC1PYx9mE(nR0ok9zju84rFUQl1YC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᲍"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ᲎"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠶࠼࠳ừ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᲏"))
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲐ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭Ბ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠷࠶࠳Ử"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲒ"))
	w3BfOGLdXcWzbiC1PYx9mE(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲓ"),w9wfONXUP3(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩᲔ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ba49YvOK2Aw8Uhxt(u"࠱࠷࠴ử"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲕ"))
	w3BfOGLdXcWzbiC1PYx9mE(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲖ"),ba49YvOK2Aw8Uhxt(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨᲗ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"࠲࠸࠷Ữ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKCrwPdOgGl(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲘ"))
	w3BfOGLdXcWzbiC1PYx9mE(pL73X0MYajJQG4n1qgD(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Კ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᲚ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠹࠹࠸ữ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲛ"))
	return
def NmF6DuTn0Y():
	w3BfOGLdXcWzbiC1PYx9mE(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡩࡳࡱࡪࡥࡳࠩᲜ"),pL73X0MYajJQG4n1qgD(u"ࠪࡣࡎࡖࡔࡠࠩᲝ")+hWRvZOYtjme9QNnV41u0Mswb(u"ࠫๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤࡎࡖࡔࡗࠩᲞ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"࠺࠺࠹Ự"))
	w3BfOGLdXcWzbiC1PYx9mE(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡲࡩ࡯࡭ࠪᲟ"),qFghPAi5yz9Vf3NLwo0nuprl+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᲠ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"࠽࠾࠿࠹ự"))
	for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
		qBAgzkG9oCL = hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡠࡋࡓࠫᲡ")+str(ozc8fP05O4GntlhQgRyCZmeKI3F)+hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡡࠪᲢ")
		w3BfOGLdXcWzbiC1PYx9mE(hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡩࡳࡱࡪࡥࡳࠩᲣ"),qBAgzkG9oCL+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬᲤ")+bCuhHjwS9lEQ2eB1c[ozc8fP05O4GntlhQgRyCZmeKI3F],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"࠼࠼࠴Ỳ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲥ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
	return
def VBqTrbhewcRF8OEd0SyPuJlox():
	w3BfOGLdXcWzbiC1PYx9mE(CCWqR3dmtzw6xoIX41(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲦ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭࡟ࡎ࠵ࡘࡣࠬᲧ")+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡎ࠵ࡘࠫᲨ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"࠽࠶࠶ỳ"))
	w3BfOGLdXcWzbiC1PYx9mE(pL73X0MYajJQG4n1qgD(u"ࠨ࡮࡬ࡲࡰ࠭Ჩ"),qFghPAi5yz9Vf3NLwo0nuprl+GTmHXIZUSdxRhMnqQKkO(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᲪ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠹࠺࠻࠼Ỵ"))
	for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
		qBAgzkG9oCL = w9wfONXUP3(u"ࠪࡣࡒ࡛ࠧᲫ")+str(ozc8fP05O4GntlhQgRyCZmeKI3F)+f9fOpCmLAEaW2Go(u"ࠫࡤ࠭Წ")
		w3BfOGLdXcWzbiC1PYx9mE(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲭ"),qBAgzkG9oCL+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᲮ")+bCuhHjwS9lEQ2eB1c[ozc8fP05O4GntlhQgRyCZmeKI3F],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"࠸࠸࠸ỵ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲯ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
	return
def yyI64HnxXCTgNFVpQUs8e(z4t2nu5ryZjPR):
	global eDGnaI4iS7LX5uYCVbQp3sAMw,ENCzgrpsGS
	Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
	try:
		if f9fOpCmLAEaW2Go(u"ࠨࡋࡉࡍࡑࡓࠧᲰ") in z4t2nu5ryZjPR: Rdnmer47TgYcStA19l8pUj2XBuL3b(z4t2nu5ryZjPR)
		else: Rdnmer47TgYcStA19l8pUj2XBuL3b()
		gg3XjydNI6qTre = pLwgjkuTs6CS
	except:
		gCc5fX6kpiwElGYJqaBePoOI()
		gg3XjydNI6qTre = NFGqKBLtvUZn1S3dau
	z4t2nu5ryZjPR = dOui5LJeABG0TYcMj(z4t2nu5ryZjPR)
	if gg3XjydNI6qTre:
		ARL0tsEeanKImhMByugPTvX7(z4t2nu5ryZjPR,pbmKZA1w7L4zHjOM(u"ࠩไุ้ࠦไๅลึๅࠬᲱ"),f7epsRlYtMz4=W2Vv30i8qxSuItfsolPLdFZA(u"࠴࠳࠴࠵Ỷ"))
		eDGnaI4iS7LX5uYCVbQp3sAMw += xD9WeoEAsX7
		ENCzgrpsGS += f9fOpCmLAEaW2Go(u"ࠪࠤ࠳ࠦࠧᲲ")+z4t2nu5ryZjPR
	else: ARL0tsEeanKImhMByugPTvX7(z4t2nu5ryZjPR,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f7epsRlYtMz4=awSUTRNMkdIW7sFEvnHD2mLY(u"࠴࠴࠵࠶ỷ"))
	return
dosubM4RVU = {}
def NNuyoWnLO5YibAgcR0XqKxPfCad(vuAE2d4C1RGXnokTw=NFGqKBLtvUZn1S3dau):
	global eDGnaI4iS7LX5uYCVbQp3sAMw,ENCzgrpsGS,dosubM4RVU
	if not vuAE2d4C1RGXnokTw:
		dosubM4RVU = dYMLGvgfk4(mmEuUR4JdaHtAsS,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡩ࡯ࡣࡵࠩᲳ"),KKCrwPdOgGl(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭Ჴ"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫᲵ"))
		if dosubM4RVU: return
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(rAYDiWlzm9MCU6x0GnROua(u"ࠧࡤࡧࡱࡸࡪࡸࠧᲶ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨฯอํࠥะๅๅศ๋ࠣีํࠠศๆๅหห๋ษࠡ࠰࠱ࠤุ๐แฮืࠣห้ฮั็ษ่ะࠥาๅ๋฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡใํࠤฬ๊ศา่ส้ัࠦอห๋ࠣ๎ุะฮาฮ้๋ࠣํวࠡใๅ฻ࠥอไฤไึห๊ࠦวๅำษ๎ุ๐ษࠡ࠰࠱ࠤะ๋๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะี๊ࠥํะ่ࠢส่ศ่ำศ็ࠣัฯ๏ࠠๅษࠣฮาะวอࠢฦ๊ࠥะๅๅศ๊ห๋ࠥัสࠢฦาึ๏ࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࡜࡯࡞ࡱࠫᲷ")+qFghPAi5yz9Vf3NLwo0nuprl+hWRvZOYtjme9QNnV41u0Mswb(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสอ็฼ࠤ็อฦๆหࠣห้ษโิษ่ࠤฬ๊ย็ࠢยࠫᲸ")+so4Z8OUJ5E)
	if e6f0ycMuYQEJraNLInmip!=xD9WeoEAsX7: return
	zCtB6lUJjnOcHibaErDuP2xGf(OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh)
	u25xqgY4aMEzfjIBvJhWcCb8 = drzqWFkSHD.menuItemsLIST
	eDGnaI4iS7LX5uYCVbQp3sAMw,ENCzgrpsGS,threads = nUaVQsoA6EXcK4Odht5wCge0J8Pib,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{}
	for z4t2nu5ryZjPR in HPLCf9g0SwpAUQ8Iv7:
		f7epsRlYtMz4.sleep(xD9WeoEAsX7)
		threads[z4t2nu5ryZjPR] = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=yyI64HnxXCTgNFVpQUs8e,args=(z4t2nu5ryZjPR,))
		threads[z4t2nu5ryZjPR].start()
	else:
		for z4t2nu5ryZjPR in list(threads.keys()): threads[z4t2nu5ryZjPR].join()
	drzqWFkSHD.menuItemsLIST[:] = u25xqgY4aMEzfjIBvJhWcCb8
	dosubM4RVU = {}
	for z4t2nu5ryZjPR in list(threads.keys()):
		try: U3EjaDGcLJfn41bCeRIWhH8wig2M = drzqWFkSHD.menuItemsDICT[z4t2nu5ryZjPR]
		except: continue
		z4t2nu5ryZjPR = ba49YvOK2Aw8Uhxt(u"ࠪࡣࡑ࡙ࡔࡠࠩᲹ")+dOui5LJeABG0TYcMj(z4t2nu5ryZjPR)
		for ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM in U3EjaDGcLJfn41bCeRIWhH8wig2M:
			if not usYnJBXhFT: usYnJBXhFT = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫ࠳࠴࠮࠯ࠩᲺ")
			else:
				if usYnJBXhFT.count(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡥࠧ᲻"))>xD9WeoEAsX7: usYnJBXhFT = usYnJBXhFT.split(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭࡟ࠨ᲼"),H3OKMjDG1evnl4Ruiz)[H3OKMjDG1evnl4Ruiz]
				usYnJBXhFT = usYnJBXhFT.replace(hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࢡࠩᲽ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠢࡋࡈࠬᲾ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡋࡈࠥ࠭Ჿ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				usYnJBXhFT = usYnJBXhFT.replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪไࠬ᳀"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(CCWqR3dmtzw6xoIX41(u"ࠫฮ࠭᳁"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬํࠧ᳂")).replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ฤࠨ᳃"),nR0ok9zju84rFUQl1YC(u"้ࠧࠩ᳄"))
				usYnJBXhFT = usYnJBXhFT.replace(KKCrwPdOgGl(u"ࠨลࠪ᳅"),Zb5cNeHWi6jP9SCYtUgR(u"ࠩสࠫ᳆")).replace(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪษࠬ᳇"),lRKCWnNi0Edr984eI(u"ࠫฬ࠭᳈")).replace(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬศࠧ᳉"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭วࠨ᳊"))
				usYnJBXhFT = usYnJBXhFT.replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧๅลࠪ᳋"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨๆสࠫ᳌")).replace(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ็ษࠬ᳍"),rAYDiWlzm9MCU6x0GnROua(u"่ࠪฬ࠭᳎")).replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"้ࠫศࠧ᳏"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"๊ࠬวࠨ᳐"))
				usYnJBXhFT = usYnJBXhFT.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭๎ࠨ᳑"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(rAYDiWlzm9MCU6x0GnROua(u"ࠧ์ࠩ᳒"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(ba49YvOK2Aw8Uhxt(u"ࠨ๑ࠪ᳓"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ๏᳔ࠫ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				usYnJBXhFT = usYnJBXhFT.replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ๔᳕ࠬ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(lRKCWnNi0Edr984eI(u"ࠫ๒᳖࠭"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬ๘᳗ࠧ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(awSUTRNMkdIW7sFEvnHD2mLY(u"࠭๑ࠨ᳘"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				usYnJBXhFT = usYnJBXhFT.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡽ᳙ࠩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(f9fOpCmLAEaW2Go(u"ࠨࢀࠪ᳚"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				usYnJBXhFT = usYnJBXhFT.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩส์๋ࠦไศ์้ࠫ᳛"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪื๏๋วࠡๆส๎ฯ᳜࠭"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				BVEsTx9jwkazfHq81 = [Zb5cNeHWi6jP9SCYtUgR(u"ࠫฬู๊ศส᳝ࠪ"),kAz7WRYjrfGm(u"ࠬิ๊ศๆ᳞ࠪ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭วๅส๋้᳟ࠬ"),f9fOpCmLAEaW2Go(u"ࠧศๆส๊ࠬ᳠"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨษฺๅฬ๊ࠧ᳡"),ba49YvOK2Aw8Uhxt(u"ࠩะห้๐็ࠨ᳢"),zWBnYSGIatjXVC(u"ࠪห้เวำ᳣ࠩ"),rAYDiWlzm9MCU6x0GnROua(u"ฺࠫอไฮ᳤ࠩ"),pYeVwat64v(u"ࠬอไะ์᳥้ࠫ"),zWBnYSGIatjXVC(u"࠭ๅ้ษ็๎ิ᳦࠭"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧศๆ฼ห᳧้๋ࠧ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨษ฼้ฬ᳨๊ࠧ")]
				if not any(qeEpJgotKPZfS3hIynH in usYnJBXhFT for qeEpJgotKPZfS3hIynH in BVEsTx9jwkazfHq81): usYnJBXhFT = usYnJBXhFT.replace(nR0ok9zju84rFUQl1YC(u"ࠩส่ࠬᳩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				usYnJBXhFT = usYnJBXhFT.replace(GTmHXIZUSdxRhMnqQKkO(u"ࠪหำื๊ࠨᳪ"),I6Bfzysrvb8DONZ(u"ࠫฬิั๊ࠩᳫ")).replace(f9fOpCmLAEaW2Go(u"ࠬอฬ็ส์ࠫᳬ"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭วอ่ห๎᳭ࠬ")).replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ฺࠧษษ่๏ํࠧᳮ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨ฻สส้๐ࠧᳯ"))
				usYnJBXhFT = usYnJBXhFT.replace(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩสะ๋ฮ๊่ࠩᳰ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪหั์ศ๋ࠩᳱ")).replace(rAYDiWlzm9MCU6x0GnROua(u"ࠫ฾ืศ๋้ࠪᳲ"),zWBnYSGIatjXVC(u"ࠬ฿ัษ์ࠪᳳ")).replace(pL73X0MYajJQG4n1qgD(u"࠭ั้็สุ๊๐็ࠨ᳴"),Zb5cNeHWi6jP9SCYtUgR(u"ࠧา๊่หู๋๊ࠨᳵ"))
				usYnJBXhFT = usYnJBXhFT.replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ฼ิฬ๏ํࠧᳶ"),pYeVwat64v(u"ࠩ฽ีอ๐ࠧ᳷")).replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ์๋ࠥำๅี็หฯ࠭᳸"),KKCrwPdOgGl(u"ู๊ࠫไิๆสฮࠬ᳹")).replace(f9fOpCmLAEaW2Go(u"ࠬอฺศ่์ࠫᳺ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ว฻ษ้๎ࠬ᳻"))
				usYnJBXhFT = usYnJBXhFT.replace(Zb5cNeHWi6jP9SCYtUgR(u"ࠧหษิ๎ำ๐ࠧ᳼"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠨฬสี๏ิࠧ᳽")).replace(KKCrwPdOgGl(u"ࠩั๎ฬฺ๊ࠠๆ่๎ࠬ᳾"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪา๏อไࠨ᳿")).replace(pbmKZA1w7L4zHjOM(u"๊ࠫ๎ำ๋ไํ๋ࠬᴀ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"๋่ࠬิ์ๅํࠬᴁ"))
				usYnJBXhFT = usYnJBXhFT.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"࠭็็ั์ࠫᴂ"),kAz7WRYjrfGm(u"่่ࠧา๎ࠬᴃ")).replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ้้ำ๏ํࠧᴄ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"๊๊ࠩิ๐ࠧᴅ")).replace(nR0ok9zju84rFUQl1YC(u"ࠪ์ะอฦใ์๊ࠫᴆ"),kAz7WRYjrfGm(u"ࠫํัววไํࠫᴇ"))
				usYnJBXhFT = usYnJBXhFT.replace(KKCrwPdOgGl(u"ࠬะไ๋ใี๎ํ์๊่ࠩᴈ"),pL73X0MYajJQG4n1qgD(u"࠭สๅใี๎ํ์ࠧᴉ")).replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧหๆไึ๏๎ๆ๋้ࠪᴊ"),pbmKZA1w7L4zHjOM(u"ࠨฬ็ๅื๐่็ࠩᴋ")).replace(W2Vv30i8qxSuItfsolPLdFZA(u"๋ࠩࠤ่ืส้่ࠪᴌ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪ์่ืส้่ࠪᴍ"))
				usYnJBXhFT = usYnJBXhFT.replace(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫฬ๊อศๆํ๋ࠬᴎ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠬำวๅ์๊ࠫᴏ")).replace(pbmKZA1w7L4zHjOM(u"࠭ๅ้ี໏ๆ๏࠭ᴐ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧๆ๊ึ๎็๏ࠧᴑ")).replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨษ็ห๋๋๊ࠨᴒ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩส๊๊๐ࠧᴓ"))
				usYnJBXhFT = usYnJBXhFT.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪห้๋ำๅี็หฯ࠭ᴔ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ู๊ࠫไิๆสฮࠬᴕ")).replace(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬอไษำส้ั࠭ᴖ"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ศาษ่ะࠬᴗ")).replace(w9wfONXUP3(u"ࠧไษิฮํ์ࠧᴘ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨๅิฮํ์ࠧᴙ"))
				usYnJBXhFT = usYnJBXhFT.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩะีํฮࠧᴚ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠪัึฮࠧᴛ")).replace(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫฬ๊ว็ษื๎ิ࠭ᴜ"),kAz7WRYjrfGm(u"ࠬอๆศึํำࠬᴝ")).replace(djapWhrveLJbgnViDftFNY05ylq1S(u"࠭วิ์๋๎์࠭ᴞ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧศีํ์๏࠭ᴟ"))
				usYnJBXhFT = usYnJBXhFT.replace(I6Bfzysrvb8DONZ(u"ࠨ฻ิฬ๎࠭ᴠ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩ฼ีอ๐ࠧᴡ")).replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪฮึ้้ࠨᴢ"),GTmHXIZUSdxRhMnqQKkO(u"ࠫฯืใ๋ࠩᴣ")).replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬะัไ์๊ࠫᴤ"),lRKCWnNi0Edr984eI(u"࠭สาๅํࠫᴥ")).replace(kAz7WRYjrfGm(u"ࠧศๆฺ่ฬ็ࠧᴦ"),nR0ok9zju84rFUQl1YC(u"ࠨ็ูหๆ࠭ᴧ"))
				usYnJBXhFT = usYnJBXhFT.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠩิ๎ฬ฼๊ࠨᴨ"),kAz7WRYjrfGm(u"ࠪี๏อึสࠩᴩ")).replace(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫึ๐วื้ࠪᴪ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬื๊ศุฬࠫᴫ")).replace(ba49YvOK2Aw8Uhxt(u"࠭วิ์๋๎์࠭ᴬ"),ba49YvOK2Aw8Uhxt(u"ࠧศีํ์๏࠭ᴭ"))
				usYnJBXhFT = usYnJBXhFT.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠨๅ๋้๏ี้ࠨᴮ"),nR0ok9zju84rFUQl1YC(u"ࠩๆ์๊๐ฯ๋ࠩᴯ")).replace(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪ็ํ๋๊ะ์๊ࠫᴰ"),JZ45mOctiTszPNw1GVjxhep2Y(u"่ࠫ๎ๅ๋ัํࠫᴱ")).replace(GTmHXIZUSdxRhMnqQKkO(u"ࠬอๆ๋็ํࠫᴲ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ว็็ํࠫᴳ"))
				usYnJBXhFT = usYnJBXhFT.replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧศ่ํ้๏ฺๆࠨᴴ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨษ้้๏ฺๆࠨᴵ")).replace(lRKCWnNi0Edr984eI(u"ࠩส๊๊๏ࠧᴶ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪห๋๋๊ี่ࠪᴷ")).replace(pL73X0MYajJQG4n1qgD(u"ࠫฬ์ๅ๋ࠩᴸ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬอๆๆ์ื๊ࠬᴹ"))
				usYnJBXhFT = usYnJBXhFT.replace(I6Bfzysrvb8DONZ(u"࠭ว็็ํฺุ๋ๆࠨᴺ"),w9wfONXUP3(u"ࠧศ่่๎ู์ࠧᴻ")).replace(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨษ็ห๋๋๊ี่ࠪᴼ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩส๊๊๐ิ็ࠩᴽ")).replace(ba49YvOK2Aw8Uhxt(u"ࠪหๆ๊วๆ่ࠢืู้ไศฬࠪᴾ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬᴿ"))
				usYnJBXhFT = usYnJBXhFT.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(lRKCWnNi0Edr984eI(u"ࠬ࠳ࠧᵀ")).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if usYnJBXhFT not in list(dosubM4RVU.keys()): dosubM4RVU[usYnJBXhFT] = {}
			dosubM4RVU[usYnJBXhFT][z4t2nu5ryZjPR] = [ZJksHpSUNh2f,usYnJBXhFT,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,t5fhagjUGXk0ynOlJWeAb,NNxWvh3OimPqguS,YYXUAmT7uG6yFiRtDehn85qkpLcZj,ggM5TzCxq24sDYLiEatpdSK7FQyGe,WPHK5192hQ8lmL34OukgqMUS0CVF,xxRmTpBZPjKDXoaVnbSzAM]
	JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧᵁ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬᵂ"),dosubM4RVU,iigI6zE7djY3yQasNTM5AW0PLOS4)
	if eDGnaI4iS7LX5uYCVbQp3sAMw>=WJikI9S3MXfC: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡࠩᵃ")+str(eDGnaI4iS7LX5uYCVbQp3sAMw)+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"้ࠩࠣํู่ࠡ็้ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯๋๋่ࠢึวࠡ็ื็้ฯࠠิสห๋ฬูࠦศัฬࠤ๊์ࠠศๆศ๊ฯืๆ๋ฬࠣ฽๋ีใ๊ࠡส่๊๎วใ฻๋ࠣ๏ࡀࠧᵄ")+ENCzgrpsGS)
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,ba49YvOK2Aw8Uhxt(u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩᵅ"))
	zCtB6lUJjnOcHibaErDuP2xGf(btR0Zix9D2g,btR0Zix9D2g,btR0Zix9D2g)
	uZd7DmfIshGTlrbHo1L()
	return
def jpwcAFdgxsVaSi4H(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F):
	xtGwLN4faz1n0IA8kJUWyj = pLwgjkuTs6CS
	IAgwJrk6nhP7m3iyv28Z5c = drzqWFkSHD.menuItemsLIST
	drzqWFkSHD.menuItemsLIST[:] = []
	if xtGwLN4faz1n0IA8kJUWyj and GTmHXIZUSdxRhMnqQKkO(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᵆ") not in wVtSpAsUu0cMblPqxK1F:
		Ubud2NhHKRnMTvI5mprQBVqk80 = dYMLGvgfk4(mmEuUR4JdaHtAsS,pL73X0MYajJQG4n1qgD(u"ࠬࡲࡩࡴࡶࠪᵇ"),GTmHXIZUSdxRhMnqQKkO(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ᵈ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨᵉ")+ozc8fP05O4GntlhQgRyCZmeKI3F)
	elif zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨᵊ") not in wVtSpAsUu0cMblPqxK1F or hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡢ࡚ࡔࡊ࡟ࠨᵋ") not in wVtSpAsUu0cMblPqxK1F:
		import jILT90g1EU
		mlrXUnyLzPAhEIj8ix5Ztpu = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠาีสส้ࠦวๅสิ๊ฬ๋ฬࠨᵌ")
		if CCWqR3dmtzw6xoIX41(u"ࠫࡤࡒࡉࡗࡇࡢࠫᵍ") not in wVtSpAsUu0cMblPqxK1F:
			try: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᵎ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+pYeVwat64v(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵏ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᵐ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᵑ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵒ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫᵓ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,hWRvZOYtjme9QNnV41u0Mswb(u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᵔ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+ba49YvOK2Aw8Uhxt(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵕ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᵖ"),mlrXUnyLzPAhEIj8ix5Ztpu)
		if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡠࡘࡒࡈࡤ࠭ᵗ") not in wVtSpAsUu0cMblPqxK1F:
			try: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᵘ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+zWBnYSGIatjXVC(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵙ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨᵚ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,f9fOpCmLAEaW2Go(u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᵛ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+I6Bfzysrvb8DONZ(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵜ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫᵝ"),mlrXUnyLzPAhEIj8ix5Ztpu)
		Ubud2NhHKRnMTvI5mprQBVqk80 = drzqWFkSHD.menuItemsLIST
		if xtGwLN4faz1n0IA8kJUWyj: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,zWBnYSGIatjXVC(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᵞ"),pL73X0MYajJQG4n1qgD(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩᵟ")+ozc8fP05O4GntlhQgRyCZmeKI3F,Ubud2NhHKRnMTvI5mprQBVqk80,iigI6zE7djY3yQasNTM5AW0PLOS4)
	drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c
	return Ubud2NhHKRnMTvI5mprQBVqk80
def YNCAVFgUwvkZ1t3(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F):
	xtGwLN4faz1n0IA8kJUWyj = pLwgjkuTs6CS
	IAgwJrk6nhP7m3iyv28Z5c = drzqWFkSHD.menuItemsLIST
	drzqWFkSHD.menuItemsLIST[:] = []
	if xtGwLN4faz1n0IA8kJUWyj and Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᵠ") not in wVtSpAsUu0cMblPqxK1F:
		Ubud2NhHKRnMTvI5mprQBVqk80 = dYMLGvgfk4(mmEuUR4JdaHtAsS,lRKCWnNi0Edr984eI(u"ࠪࡰ࡮ࡹࡴࠨᵡ"),pYeVwat64v(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᵢ"),GTmHXIZUSdxRhMnqQKkO(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬᵣ")+ozc8fP05O4GntlhQgRyCZmeKI3F)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᵤ") not in wVtSpAsUu0cMblPqxK1F or djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡠࡘࡒࡈࡤ࠭ᵥ") not in wVtSpAsUu0cMblPqxK1F:
		import n89RCYixSH
		mlrXUnyLzPAhEIj8ix5Ztpu = GTmHXIZUSdxRhMnqQKkO(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥืำศศ็ࠤฬ๊ศา่ส้ั࠭ᵦ")
		if slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᵧ") not in wVtSpAsUu0cMblPqxK1F:
			try: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,YzlId3Fs6vpehcbLGj0UaO(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᵨ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+pbmKZA1w7L4zHjOM(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵩ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᵪ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,ba49YvOK2Aw8Uhxt(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᵫ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵬ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊แ๋ัํ์์อสࠨᵭ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,jBbkfIJSDqcVwl8irzy4Z3O(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᵮ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+kAz7WRYjrfGm(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵯ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᵰ"),mlrXUnyLzPAhEIj8ix5Ztpu)
		if rAYDiWlzm9MCU6x0GnROua(u"ࠬࡥࡖࡐࡆࡢࠫᵱ") not in wVtSpAsUu0cMblPqxK1F:
			try: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᵲ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵳ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬᵴ"),mlrXUnyLzPAhEIj8ix5Ztpu)
			try: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(ozc8fP05O4GntlhQgRyCZmeKI3F,ba49YvOK2Aw8Uhxt(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᵵ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,wVtSpAsUu0cMblPqxK1F+KKCrwPdOgGl(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵶ"),pLwgjkuTs6CS)
			except: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨᵷ"),mlrXUnyLzPAhEIj8ix5Ztpu)
		Ubud2NhHKRnMTvI5mprQBVqk80 = drzqWFkSHD.menuItemsLIST
		if xtGwLN4faz1n0IA8kJUWyj: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,I6Bfzysrvb8DONZ(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᵸ"),pbmKZA1w7L4zHjOM(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᵹ")+ozc8fP05O4GntlhQgRyCZmeKI3F,Ubud2NhHKRnMTvI5mprQBVqk80,iigI6zE7djY3yQasNTM5AW0PLOS4)
	drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c
	return Ubud2NhHKRnMTvI5mprQBVqk80
def kf3rHC5bYFxAmT9go2PNeIyWhQ1(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F,VA3LbJCwWf8rEiutyGO5vYP1S):
	zCtB6lUJjnOcHibaErDuP2xGf(XvNk2Fqt5MxdZaLCylfpDgYc8i,XvNk2Fqt5MxdZaLCylfpDgYc8i,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh)
	if VA3LbJCwWf8rEiutyGO5vYP1S: NNuyoWnLO5YibAgcR0XqKxPfCad(pLwgjkuTs6CS)
	elif KKCrwPdOgGl(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᵺ") in wVtSpAsUu0cMblPqxK1F and not VA3LbJCwWf8rEiutyGO5vYP1S: NNuyoWnLO5YibAgcR0XqKxPfCad(NFGqKBLtvUZn1S3dau)
	n1nhJVg7GcH3M = wVtSpAsUu0cMblPqxK1F.replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᵻ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵼ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(pL73X0MYajJQG4n1qgD(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵽ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if not VA3LbJCwWf8rEiutyGO5vYP1S:
		w3BfOGLdXcWzbiC1PYx9mE(zWBnYSGIatjXVC(u"ࠫࡱ࡯࡮࡬ࠩᵾ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬะอะ์ฮࠤ็อฦๆหࠣห้ษโิษ่ࠫᵿ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠻࠻࠹Ỹ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᶀ")+n1nhJVg7GcH3M,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶁ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
		w3BfOGLdXcWzbiC1PYx9mE(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨ࡮࡬ࡲࡰ࠭ᶂ"),qFghPAi5yz9Vf3NLwo0nuprl+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᶃ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠾࠿࠹࠺ỹ"))
		ZcdILQijMvDG5Pz2fhAmwtr170CT4 = [Zb5cNeHWi6jP9SCYtUgR(u"ࠪวๆ๊วๆࠩᶄ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ู๊ࠫไิๆสฮࠬᶅ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"๋ࠬำาฯํหฯ࠭ᶆ"),w9wfONXUP3(u"࠭ศาษ่ะࠬᶇ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧฤูไห้่ࠦไำอ์๋࠭ᶈ"),pL73X0MYajJQG4n1qgD(u"ࠨำฺ่ฬ์ࠧᶉ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩฦัิั࠭ฤะิࠫᶊ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪื้อำๅࠩᶋ"),JZ45mOctiTszPNw1GVjxhep2Y(u"๊ࠫ๎ำ๋ไ์ࠫᶌ"),pYeVwat64v(u"ࠬษิ่ำ࠰ว่ััࠨᶍ"),pL73X0MYajJQG4n1qgD(u"࠭วๅฤ้ࠫᶎ"),KKCrwPdOgGl(u"ࠧืฯๆࠫᶏ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨำํห฻ฯࠧᶐ"),rAYDiWlzm9MCU6x0GnROua(u"้ࠩ๎ฯ็ไไีࠪᶑ"),CCWqR3dmtzw6xoIX41(u"้๊ࠪัไ๋่ࠪᶒ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠫอัࠠฮ์ࠪᶓ"),CCWqR3dmtzw6xoIX41(u"ࠬี๊็์ฬࠫᶔ"),pL73X0MYajJQG4n1qgD(u"࠭ำ็๊สฮࠬᶕ"),pL73X0MYajJQG4n1qgD(u"ࠧฤะิํࠬᶖ")]
		VA3LbJCwWf8rEiutyGO5vYP1S = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		for J1WVrMQp0mEScaAzuBGt2N in ZcdILQijMvDG5Pz2fhAmwtr170CT4:
			VA3LbJCwWf8rEiutyGO5vYP1S += xD9WeoEAsX7
			w3BfOGLdXcWzbiC1PYx9mE(W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᶗ"),qBAgzkG9oCL+J1WVrMQp0mEScaAzuBGt2N,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠽࠶࠴Ỻ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(VA3LbJCwWf8rEiutyGO5vYP1S),n1nhJVg7GcH3M,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{w9wfONXUP3(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶘ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
	else:
		Ssw9ngPLhUqcprvmMQ83zel = [vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪหๆ๊วๆࠩᶙ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡲࡵࡶࡪࡧࠪᶚ"),pYeVwat64v(u"ࠬ็๊ๅ็ࠪᶛ"),pYeVwat64v(u"࠭แๅ็ࠪᶜ")]
		A91ArYpSTJf = [W2Vv30i8qxSuItfsolPLdFZA(u"ࠧๆี็ื้࠭ᶝ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡵࡨࡶ࡮࡫ࡳࠨᶞ")]
		niYTNQEKyrvfFUP5 = [zqKXfFe36rVoin9YA18Z20CxI4Lth(u"่ࠩืฬือࠨᶟ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ุ้ࠪือ๋ษอࠫᶠ")]
		FvRMtQHxcrdzCJpb31NPOu = [kAz7WRYjrfGm(u"ࠫอืวๆฮࠪᶡ"),CCWqR3dmtzw6xoIX41(u"ࠬࡹࡨࡰࡹࠪᶢ"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠭สๅใี๎ํ์ࠧᶣ"),f9fOpCmLAEaW2Go(u"ࠧหๆํๅื๐่็ࠩᶤ")]
		x9Ef82cd65tVunmOZwWUT = [W2Vv30i8qxSuItfsolPLdFZA(u"ࠨษ้้๏࠭ᶥ"),nR0ok9zju84rFUQl1YC(u"ࠩๆีฯ๎ๆࠨᶦ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠪ็ฬืส้่ࠪᶧ"),GTmHXIZUSdxRhMnqQKkO(u"ࠫࡰ࡯ࡤࡴࠩᶨ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ฽แๅࠩᶩ"),pL73X0MYajJQG4n1qgD(u"࠭วุใส่ࠬᶪ")]
		iobXKrS2eBv5 = [w9wfONXUP3(u"ࠧา็ูห๋࠭ᶫ")]
		DzQdbq9C70aF1uc = [zWBnYSGIatjXVC(u"ࠨษะำะ࠭ᶬ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩสาึ࠭ᶭ"),pL73X0MYajJQG4n1qgD(u"้ࠪํิัࠨᶮ"),nR0ok9zju84rFUQl1YC(u"ࠫัี๊ะࠩᶯ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"๋ࠬึศใࠪᶰ"),rAYDiWlzm9MCU6x0GnROua(u"࠭อะ์ฮࠫᶱ")]
		zzTHsBiO9WpFh = [KKCrwPdOgGl(u"ࠧิๆสื้࠭ᶲ"),zWBnYSGIatjXVC(u"ࠨี็ื้ํࠧᶳ")]
		OOk0eQAMTcDxh8rZ26H = [fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩส฾ฬ์๊ࠨᶴ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"้ࠪํู๊ใ๋ࠪᶵ"),YzlId3Fs6vpehcbLGj0UaO(u"่๊๊ࠫษࠩᶶ"),f9fOpCmLAEaW2Go(u"ࠬำแๅࠩᶷ"),Zb5cNeHWi6jP9SCYtUgR(u"࠭࡭ࡶࡵ࡬ࡧࠬᶸ")]
		V8TCUtXahWsHYF91vqJAE5DZOPgQ = [Zb5cNeHWi6jP9SCYtUgR(u"ࠧศๅฮีࠬᶹ"),pYeVwat64v(u"ࠨษื๋ึ࠭ᶺ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"่้ࠩ๏ุ็ࠨᶻ"),pbmKZA1w7L4zHjOM(u"ࠪห฾๊้ࠨᶼ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"๊ࠫิสศำ๊ࠫᶽ"),CCWqR3dmtzw6xoIX41(u"๋ࠬฮหษิหฯ࠭ᶾ"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭วใ๊์ࠫᶿ")]
		rl8CQFYBRd = [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧศๆส๊ࠬ᷀"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨฯส่๏࠭᷁"),KKCrwPdOgGl(u"่ࠩฯอะ᷂ࠧ"),I6Bfzysrvb8DONZ(u"ࠪีฬฬฬࠨ᷃")]
		fBHlEKT9I2si = [CCWqR3dmtzw6xoIX41(u"ࠫ฻ำใࠨ᷄"),pL73X0MYajJQG4n1qgD(u"้่ࠬๆ์า๎ࠬ᷅")]
		JeY6hviamzF = [djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ั๋ษู๋ࠬ᷆"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧไ๊ิ๋ࠬ᷇"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨ็ุหึ฿็ࠨ᷈"),kAz7WRYjrfGm(u"ࠩื์ฯ࠭᷉"),GTmHXIZUSdxRhMnqQKkO(u"ࠪี๏อึส᷊ࠩ")]
		vy1HJ0PknTXjOqgV4rsYZz7 = [pbmKZA1w7L4zHjOM(u"๋ࠫ๐สโๆๆืࠬ᷋"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭᷌"),Zb5cNeHWi6jP9SCYtUgR(u"࠭ๆ๋ฬไ่๏้ำࠨ᷍")]
		GTUNsCmZAS0Yx6gQ28Fr9K = [zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧๆ็ฮ่๏์᷎ࠧ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨษืาฬ฻᷏ࠧ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"้ࠩะํ๋᷐ࠧ")]
		aZr8kT7yehG2Pu6dRKjU9A4 = [KKCrwPdOgGl(u"ࠪฬะࠦอ๋ࠩ᷑"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡱ࡯ࡶࡦࠩ᷒"),pbmKZA1w7L4zHjOM(u"่ࠬๆศ้ࠪᷓ"),pbmKZA1w7L4zHjOM(u"࠭โ็๊สฮࠬᷔ")]
		P2RtsnTXbw71xGdoy09aBl = [KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧะ์้ࠫᷕ"),ba49YvOK2Aw8Uhxt(u"ࠨษา฽๏ํࠧᷖ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩี๎ฬืวหࠩᷗ"),nR0ok9zju84rFUQl1YC(u"่ࠪ฼๋๊ศฬࠪᷘ"),kAz7WRYjrfGm(u"ࠫิ฿วยࠩᷙ"),JZ45mOctiTszPNw1GVjxhep2Y(u"่ࠬัศ่ࠪᷚ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭โึษษำࠬᷛ"),KKCrwPdOgGl(u"ࠧาอสลࠬᷜ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ็ิะ฾๐็ࠨᷝ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩสิฬ์ࠧᷞ"),I6Bfzysrvb8DONZ(u"ࠪหุ๊วๆࠩᷟ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫฯ๎วี์ะࠫᷠ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬิืษࠩᷡ"),W2Vv30i8qxSuItfsolPLdFZA(u"࠭อ้ิ๋๎ࠬᷢ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ฺࠧฬหหฯ࠭ᷣ"),f9fOpCmLAEaW2Go(u"ࠨ็๋ห้๐ฯࠨᷤ"),rAYDiWlzm9MCU6x0GnROua(u"้ࠩ์ฬ฿๊ࠨᷥ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪ฽็อฦะࠩᷦ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫฬ์วี์าࠫᷧ")]
		PPJZbY2l67eEjD = [KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬ࠸࠰࠲࠲ࠪᷨ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭࠲࠱࠳࠴ࠫᷩ"),pbmKZA1w7L4zHjOM(u"ࠧ࠳࠲࠴࠶ࠬᷪ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨ࠴࠳࠵࠸࠭ᷫ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࠵࠴࠶࠺ࠧᷬ"),kAz7WRYjrfGm(u"ࠪ࠶࠵࠷࠵ࠨᷭ"),rAYDiWlzm9MCU6x0GnROua(u"ࠫ࠷࠶࠱࠷ࠩᷮ"),f9fOpCmLAEaW2Go(u"ࠬ࠸࠰࠲࠹ࠪᷯ"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭࠲࠱࠳࠻ࠫᷰ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧ࠳࠲࠴࠽ࠬᷱ"),nR0ok9zju84rFUQl1YC(u"ࠨ࠴࠳࠶࠵࠭ᷲ"),kAz7WRYjrfGm(u"ࠩ࠵࠴࠷࠷ࠧᷳ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ࠶࠵࠸࠲ࠨᷴ"),kAz7WRYjrfGm(u"ࠫ࠷࠶࠲࠴ࠩ᷵"),pL73X0MYajJQG4n1qgD(u"ࠬ࠸࠰࠳࠶ࠪ᷶"),W2Vv30i8qxSuItfsolPLdFZA(u"࠭࠲࠱࠴࠸᷷ࠫ"),zWBnYSGIatjXVC(u"ࠧ࠳࠲࠵࠺᷸ࠬ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨ࠴࠳࠶࠼᷹࠭"),I6Bfzysrvb8DONZ(u"ࠩ࠵࠴࠷࠾᷺ࠧ")]
		for usYnJBXhFT in sorted(list(dosubM4RVU.keys())):
			XQv4cBgdZD5k6OPwy3alsEGxtA = usYnJBXhFT.lower()
			PtATpb3YenChf5 = []
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in Ssw9ngPLhUqcprvmMQ83zel): PtATpb3YenChf5.append(xD9WeoEAsX7)
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in A91ArYpSTJf): PtATpb3YenChf5.append(H3OKMjDG1evnl4Ruiz)
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in niYTNQEKyrvfFUP5): PtATpb3YenChf5.append(anb4QpyjlmgVwANP)
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in FvRMtQHxcrdzCJpb31NPOu): PtATpb3YenChf5.append(gybxTLFEw2)
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in x9Ef82cd65tVunmOZwWUT): PtATpb3YenChf5.append(Hip2swoNbVaZ30OrStQR1lF)
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in iobXKrS2eBv5): PtATpb3YenChf5.append(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶ỻ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in DzQdbq9C70aF1uc) and XQv4cBgdZD5k6OPwy3alsEGxtA not in [CCWqR3dmtzw6xoIX41(u"ࠪหำื้ࠨ᷻")]: PtATpb3YenChf5.append(ba49YvOK2Aw8Uhxt(u"࠸Ỽ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in zzTHsBiO9WpFh): PtATpb3YenChf5.append(CCWqR3dmtzw6xoIX41(u"࠺ỽ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in OOk0eQAMTcDxh8rZ26H): PtATpb3YenChf5.append(ba49YvOK2Aw8Uhxt(u"࠼Ỿ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in V8TCUtXahWsHYF91vqJAE5DZOPgQ): PtATpb3YenChf5.append(rAYDiWlzm9MCU6x0GnROua(u"࠵࠵ỿ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in rl8CQFYBRd): PtATpb3YenChf5.append(pL73X0MYajJQG4n1qgD(u"࠶࠷ἀ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in fBHlEKT9I2si): PtATpb3YenChf5.append(GTmHXIZUSdxRhMnqQKkO(u"࠷࠲ἁ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in JeY6hviamzF): PtATpb3YenChf5.append(zWBnYSGIatjXVC(u"࠱࠴ἂ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in vy1HJ0PknTXjOqgV4rsYZz7): PtATpb3YenChf5.append(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠲࠶ἃ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in GTUNsCmZAS0Yx6gQ28Fr9K): PtATpb3YenChf5.append(B1YMtuvRAGNlJOkC46VyPKQE(u"࠳࠸ἄ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in aZr8kT7yehG2Pu6dRKjU9A4): PtATpb3YenChf5.append(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠴࠺ἅ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in P2RtsnTXbw71xGdoy09aBl): PtATpb3YenChf5.append(hWRvZOYtjme9QNnV41u0Mswb(u"࠵࠼ἆ"))
			if any(value in XQv4cBgdZD5k6OPwy3alsEGxtA for value in PPJZbY2l67eEjD): PtATpb3YenChf5.append(rAYDiWlzm9MCU6x0GnROua(u"࠶࠾ἇ"))
			if not PtATpb3YenChf5: PtATpb3YenChf5 = [bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠷࠹Ἀ")]
			for mpItOLs9bMwNR86hAr in PtATpb3YenChf5:
				if str(mpItOLs9bMwNR86hAr)==VA3LbJCwWf8rEiutyGO5vYP1S:
					w3BfOGLdXcWzbiC1PYx9mE(zWBnYSGIatjXVC(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᷼"),qBAgzkG9oCL+usYnJBXhFT,usYnJBXhFT,KKCrwPdOgGl(u"࠱࠷࠸Ἁ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,n1nhJVg7GcH3M+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠ᷽ࠩ"))
	zCtB6lUJjnOcHibaErDuP2xGf(XvNk2Fqt5MxdZaLCylfpDgYc8i,XvNk2Fqt5MxdZaLCylfpDgYc8i,btR0Zix9D2g)
	return
def QKU1ST0w6PJuiI9dCsoOvftA(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F):
	xtGwLN4faz1n0IA8kJUWyj = pLwgjkuTs6CS
	if xtGwLN4faz1n0IA8kJUWyj:
		w3BfOGLdXcWzbiC1PYx9mE(kAz7WRYjrfGm(u"࠭࡬ࡪࡰ࡮ࠫ᷾"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧหฯา๎ะࠦโศศ่อࠥษโิษ่ࠤࡎࡖࡔࡗ᷿ࠩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"࠸࠸࠷Ἂ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭Ḁ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{ba49YvOK2Aw8Uhxt(u"ࠩࡩࡳࡱࡪࡥࡳࠩḁ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
		w3BfOGLdXcWzbiC1PYx9mE(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡰ࡮ࡴ࡫ࠨḂ"),qFghPAi5yz9Vf3NLwo0nuprl+f9fOpCmLAEaW2Go(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩḃ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"࠻࠼࠽࠾Ἃ"))
	IAgwJrk6nhP7m3iyv28Z5c = drzqWFkSHD.menuItemsLIST[:]
	import jILT90g1EU
	if ozc8fP05O4GntlhQgRyCZmeKI3F:
		if not jILT90g1EU.rb1LQeqnckC(ozc8fP05O4GntlhQgRyCZmeKI3F,NFGqKBLtvUZn1S3dau): return
		olsV8eR4W7t = jpwcAFdgxsVaSi4H(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F)
		ERIWgZzeGk9O0yVoDvs3FqwT = sorted(olsV8eR4W7t,reverse=pLwgjkuTs6CS,key=lambda key: key[xD9WeoEAsX7].lower())
	else:
		if not jILT90g1EU.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
		if xtGwLN4faz1n0IA8kJUWyj and pbmKZA1w7L4zHjOM(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪḄ") not in wVtSpAsUu0cMblPqxK1F:
			ERIWgZzeGk9O0yVoDvs3FqwT = dYMLGvgfk4(mmEuUR4JdaHtAsS,YzlId3Fs6vpehcbLGj0UaO(u"࠭࡬ࡪࡵࡷࠫḅ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧḆ"),lRKCWnNi0Edr984eI(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬḇ"))
		else:
			etgv63p4lxIniRU0J7LK9Nu,ERIWgZzeGk9O0yVoDvs3FqwT,olsV8eR4W7t = [],[],[]
			for ir6FAtKkPRdUe2aCq3LSoHTW in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
				ERIWgZzeGk9O0yVoDvs3FqwT += jpwcAFdgxsVaSi4H(str(ir6FAtKkPRdUe2aCq3LSoHTW),wVtSpAsUu0cMblPqxK1F)
			for type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in ERIWgZzeGk9O0yVoDvs3FqwT:
				if ggM5TzCxq24sDYLiEatpdSK7FQyGe not in etgv63p4lxIniRU0J7LK9Nu:
					etgv63p4lxIniRU0J7LK9Nu.append(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
					WSwDlbsgkREr9YPJK1AfXpM7 = type,usYnJBXhFT,ggM5TzCxq24sDYLiEatpdSK7FQyGe,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠴࠺࠺Ἄ"),E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,wVtSpAsUu0cMblPqxK1F,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU
					olsV8eR4W7t.append(WSwDlbsgkREr9YPJK1AfXpM7)
			ERIWgZzeGk9O0yVoDvs3FqwT = sorted(olsV8eR4W7t,reverse=pLwgjkuTs6CS,key=lambda key: key[xD9WeoEAsX7].lower())
			if xtGwLN4faz1n0IA8kJUWyj: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,kAz7WRYjrfGm(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩḈ"),I6Bfzysrvb8DONZ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࡅࡑࡒࠧḉ"),ERIWgZzeGk9O0yVoDvs3FqwT,iigI6zE7djY3yQasNTM5AW0PLOS4)
	drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT
	GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def BWGhuzI8S0xKp2A16PoO3cJYfaiqL(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F):
	xtGwLN4faz1n0IA8kJUWyj = pLwgjkuTs6CS
	if xtGwLN4faz1n0IA8kJUWyj:
		w3BfOGLdXcWzbiC1PYx9mE(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡱ࡯࡮࡬ࠩḊ"),ba49YvOK2Aw8Uhxt(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡐ࠷࡚࠭ḋ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠻࠻࠻Ἅ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫḌ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{f9fOpCmLAEaW2Go(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḍ"):ozc8fP05O4GntlhQgRyCZmeKI3F})
		w3BfOGLdXcWzbiC1PYx9mE(pbmKZA1w7L4zHjOM(u"ࠨ࡮࡬ࡲࡰ࠭Ḏ"),qFghPAi5yz9Vf3NLwo0nuprl+KKCrwPdOgGl(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḏ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠾࠿࠹࠺Ἆ"))
	IAgwJrk6nhP7m3iyv28Z5c = drzqWFkSHD.menuItemsLIST[:]
	import n89RCYixSH
	if ozc8fP05O4GntlhQgRyCZmeKI3F:
		if not n89RCYixSH.rb1LQeqnckC(ozc8fP05O4GntlhQgRyCZmeKI3F,NFGqKBLtvUZn1S3dau): return
		olsV8eR4W7t = YNCAVFgUwvkZ1t3(ozc8fP05O4GntlhQgRyCZmeKI3F,wVtSpAsUu0cMblPqxK1F)
		ERIWgZzeGk9O0yVoDvs3FqwT = sorted(olsV8eR4W7t,reverse=pLwgjkuTs6CS,key=lambda key: key[xD9WeoEAsX7].lower())
	else:
		if not n89RCYixSH.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
		if xtGwLN4faz1n0IA8kJUWyj and GTmHXIZUSdxRhMnqQKkO(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨḐ") not in wVtSpAsUu0cMblPqxK1F:
			ERIWgZzeGk9O0yVoDvs3FqwT = dYMLGvgfk4(mmEuUR4JdaHtAsS,rAYDiWlzm9MCU6x0GnROua(u"ࠫࡱ࡯ࡳࡵࠩḑ"),Zb5cNeHWi6jP9SCYtUgR(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫḒ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩḓ"))
		else:
			etgv63p4lxIniRU0J7LK9Nu,ERIWgZzeGk9O0yVoDvs3FqwT,olsV8eR4W7t = [],[],[]
			for ir6FAtKkPRdUe2aCq3LSoHTW in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
				ERIWgZzeGk9O0yVoDvs3FqwT += YNCAVFgUwvkZ1t3(str(ir6FAtKkPRdUe2aCq3LSoHTW),wVtSpAsUu0cMblPqxK1F)
			for type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in ERIWgZzeGk9O0yVoDvs3FqwT:
				if ggM5TzCxq24sDYLiEatpdSK7FQyGe not in etgv63p4lxIniRU0J7LK9Nu:
					etgv63p4lxIniRU0J7LK9Nu.append(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
					WSwDlbsgkREr9YPJK1AfXpM7 = type,usYnJBXhFT,ggM5TzCxq24sDYLiEatpdSK7FQyGe,B1YMtuvRAGNlJOkC46VyPKQE(u"࠷࠶࠶Ἇ"),E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,wVtSpAsUu0cMblPqxK1F,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU
					olsV8eR4W7t.append(WSwDlbsgkREr9YPJK1AfXpM7)
			ERIWgZzeGk9O0yVoDvs3FqwT = sorted(olsV8eR4W7t,reverse=pLwgjkuTs6CS,key=lambda key: key[xD9WeoEAsX7].lower())
			if xtGwLN4faz1n0IA8kJUWyj: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,CCWqR3dmtzw6xoIX41(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭Ḕ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫḕ"),ERIWgZzeGk9O0yVoDvs3FqwT,iigI6zE7djY3yQasNTM5AW0PLOS4)
	drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT
	GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def KEuNBQlIzJn(group,wVtSpAsUu0cMblPqxK1F):
	xtGwLN4faz1n0IA8kJUWyj = pLwgjkuTs6CS
	Ubud2NhHKRnMTvI5mprQBVqk80 = []
	WjcdEyOurYX4Pz1UNH = kAz7WRYjrfGm(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩḖ") if f9fOpCmLAEaW2Go(u"ࠪࡍࡕ࡚ࡖࠨḗ") in wVtSpAsUu0cMblPqxK1F else pL73X0MYajJQG4n1qgD(u"ࠫࡤࡓ࠳ࡖࡡࠪḘ")
	if xtGwLN4faz1n0IA8kJUWyj: Ubud2NhHKRnMTvI5mprQBVqk80 = dYMLGvgfk4(mmEuUR4JdaHtAsS,hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡲࡩࡴࡶࠪḙ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨḚ")+WjcdEyOurYX4Pz1UNH[:-xD9WeoEAsX7],group)
	if not Ubud2NhHKRnMTvI5mprQBVqk80:
		for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
			if xtGwLN4faz1n0IA8kJUWyj: Ubud2NhHKRnMTvI5mprQBVqk80 += dYMLGvgfk4(mmEuUR4JdaHtAsS,pbmKZA1w7L4zHjOM(u"ࠧ࡭࡫ࡶࡸࠬḛ"),pYeVwat64v(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪḜ")+WjcdEyOurYX4Pz1UNH[:-xD9WeoEAsX7],rAYDiWlzm9MCU6x0GnROua(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫḝ")+WjcdEyOurYX4Pz1UNH+str(ozc8fP05O4GntlhQgRyCZmeKI3F))
			elif WjcdEyOurYX4Pz1UNH==hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡣࡎࡖࡔࡗࡡࠪḞ"): Ubud2NhHKRnMTvI5mprQBVqk80 += jpwcAFdgxsVaSi4H(str(ozc8fP05O4GntlhQgRyCZmeKI3F),zWBnYSGIatjXVC(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩḟ"))
			elif WjcdEyOurYX4Pz1UNH==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡥࡍ࠴ࡗࡢࠫḠ"): Ubud2NhHKRnMTvI5mprQBVqk80 += YNCAVFgUwvkZ1t3(str(ozc8fP05O4GntlhQgRyCZmeKI3F),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫḡ"))
		for type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in Ubud2NhHKRnMTvI5mprQBVqk80:
			if ggM5TzCxq24sDYLiEatpdSK7FQyGe==group: J3t4CspyDNgjv9MbzAqELQFx5Z(type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
		items,llN8cqbtajQJprPCKLnWVxXB = [],[]
		for type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in drzqWFkSHD.menuItemsLIST:
			t93GJZhdYIf7A0 = type,usYnJBXhFT[gybxTLFEw2:],url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			if t93GJZhdYIf7A0 not in llN8cqbtajQJprPCKLnWVxXB:
				llN8cqbtajQJprPCKLnWVxXB.append(t93GJZhdYIf7A0)
				Uz7N5KAHwQ93iShW1xj = type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU
				items.append(Uz7N5KAHwQ93iShW1xj)
		Ubud2NhHKRnMTvI5mprQBVqk80 = sorted(items,reverse=pLwgjkuTs6CS,key=lambda key: key[xD9WeoEAsX7].lower()[Zb5cNeHWi6jP9SCYtUgR(u"࠵ἐ"):])
		if xtGwLN4faz1n0IA8kJUWyj: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,lRKCWnNi0Edr984eI(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩḢ")+WjcdEyOurYX4Pz1UNH[:-xD9WeoEAsX7],group,Ubud2NhHKRnMTvI5mprQBVqk80,iigI6zE7djY3yQasNTM5AW0PLOS4)
	if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪḣ") in wVtSpAsUu0cMblPqxK1F and len(Ubud2NhHKRnMTvI5mprQBVqk80)>GGBXMJbitIEs:
		drzqWFkSHD.menuItemsLIST[:] = []
		w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠩࡩࡳࡱࡪࡥࡳࠩḤ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪ࡟ࠬḥ")+qFghPAi5yz9Vf3NLwo0nuprl+group+so4Z8OUJ5E+lRKCWnNi0Edr984eI(u"ࠫࠥࡀวๅไึ้ࡢ࠭Ḧ"),group,I6Bfzysrvb8DONZ(u"࠲࠸࠸ἑ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,WjcdEyOurYX4Pz1UNH+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḧ"))
		w3BfOGLdXcWzbiC1PYx9mE(nR0ok9zju84rFUQl1YC(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ḩ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭ḩ"),group,Zb5cNeHWi6jP9SCYtUgR(u"࠳࠹࠹ἒ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,WjcdEyOurYX4Pz1UNH+rAYDiWlzm9MCU6x0GnROua(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧḪ"))
		w3BfOGLdXcWzbiC1PYx9mE(hWRvZOYtjme9QNnV41u0Mswb(u"ࠩ࡯࡭ࡳࡱࠧḫ"),qFghPAi5yz9Vf3NLwo0nuprl+YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨḬ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CCWqR3dmtzw6xoIX41(u"࠼࠽࠾࠿ἓ"))
		Ubud2NhHKRnMTvI5mprQBVqk80 = drzqWFkSHD.menuItemsLIST+DDLw3RXCNW.sample(Ubud2NhHKRnMTvI5mprQBVqk80,GGBXMJbitIEs)
	drzqWFkSHD.menuItemsLIST[:] = Ubud2NhHKRnMTvI5mprQBVqk80
	GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def xxCV7gIP9bHURMdzA6Dkul(wVtSpAsUu0cMblPqxK1F):
	w3BfOGLdXcWzbiC1PYx9mE(lRKCWnNi0Edr984eI(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḭ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬหูศัฬࠤ฼๊ศࠡไ้์ฬะฺࠠึ๋หห๐ษࠨḮ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵࠻࠷ἔ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭ḯ"))
	w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧ࡭࡫ࡱ࡯ࠬḰ"),qFghPAi5yz9Vf3NLwo0nuprl+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ḱ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠾࠿࠹࠺ἕ"))
	UMQBidT3DR = drzqWFkSHD.menuItemsLIST[:]
	drzqWFkSHD.menuItemsLIST[:] = []
	import Hl2hUqPksn
	Hl2hUqPksn.VuHht6MNBWRnOkX9S(kAz7WRYjrfGm(u"ࠩ࠳ࠫḲ"),pLwgjkuTs6CS)
	Hl2hUqPksn.VuHht6MNBWRnOkX9S(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪ࠵ࠬḳ"),pLwgjkuTs6CS)
	Hl2hUqPksn.VuHht6MNBWRnOkX9S(f9fOpCmLAEaW2Go(u"ࠫ࠷࠭Ḵ"),pLwgjkuTs6CS)
	if KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧḵ") in wVtSpAsUu0cMblPqxK1F:
		drzqWFkSHD.menuItemsLIST[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
		if len(drzqWFkSHD.menuItemsLIST)>GGBXMJbitIEs: drzqWFkSHD.menuItemsLIST[:] = DDLw3RXCNW.sample(drzqWFkSHD.menuItemsLIST,GGBXMJbitIEs)
	drzqWFkSHD.menuItemsLIST[:] = UMQBidT3DR+drzqWFkSHD.menuItemsLIST
	return
def MYn4ja3VSqeZLCT1bf6d(wVtSpAsUu0cMblPqxK1F):
	wVtSpAsUu0cMblPqxK1F = wVtSpAsUu0cMblPqxK1F.replace(nR0ok9zju84rFUQl1YC(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḶ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḷ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	headers = { zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬḸ") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	url = YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨḹ")
	data = {pbmKZA1w7L4zHjOM(u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬḺ"):W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࠺࠶ࠧḻ")}
	data = g726UBevLKbpyh8o35Z4fdPiRrn9uG(data)
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(qJ0xtbICjHuM45nmhO7fgpkr,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡍࡅࡕࠩḼ"),url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"࠭ࡒࡂࡐࡇࡓࡒ࡙࠭ࡓࡃࡑࡈࡔࡓ࡟ࡗࡋࡇࡉࡔ࡙࡟ࡇࡔࡒࡑࡤ࡝ࡏࡓࡆࡖ࠱࠶ࡹࡴࠨḽ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩḾ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	items = AxTYMhRlfyskNc0X19dvwtS.findall(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ḿ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	u3PCJsXqa5ZnVMBT18gzWp6yk,oEYzI630P7BFm4UJV8HTZXNLGvn = list(zip(*items))
	U09WgC1S62YeBRGMmskyfHj = []
	ask1yEGJ6VoTdbHhvD8LWRMmpjFzi = [WRsuxHTjDgYCIpoMQzLFAtS8rikP,pL73X0MYajJQG4n1qgD(u"ࠩࠥࠫṀ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡤࠬṁ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࠱࠭Ṃ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ࠴ࠧṃ"),CCWqR3dmtzw6xoIX41(u"࠭࠺ࠨṄ"),f9fOpCmLAEaW2Go(u"ࠧ࠼ࠩṅ"),zWBnYSGIatjXVC(u"ࠣࠩࠥṆ"),rAYDiWlzm9MCU6x0GnROua(u"ࠩ࠰ࠫṇ")]
	Ao4GMxbSg0Z = oEYzI630P7BFm4UJV8HTZXNLGvn+u3PCJsXqa5ZnVMBT18gzWp6yk
	for Bdv8A3yIQsrhDb0OpukPoe1JUSVjx in Ao4GMxbSg0Z:
		if Bdv8A3yIQsrhDb0OpukPoe1JUSVjx in oEYzI630P7BFm4UJV8HTZXNLGvn: ubL8vAD1Ikfz0F6g4 = H3OKMjDG1evnl4Ruiz
		if Bdv8A3yIQsrhDb0OpukPoe1JUSVjx in u3PCJsXqa5ZnVMBT18gzWp6yk: ubL8vAD1Ikfz0F6g4 = gybxTLFEw2
		iO0MwKol64anjkqAYUsZ = [uKFGBAEj9tX1e03cyHOMUNhQl4r6 in Bdv8A3yIQsrhDb0OpukPoe1JUSVjx for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in ask1yEGJ6VoTdbHhvD8LWRMmpjFzi]
		if any(iO0MwKol64anjkqAYUsZ):
			qHmcPitXMaCJTswd7zj8W3Ux4u9l = iO0MwKol64anjkqAYUsZ.index(NFGqKBLtvUZn1S3dau)
			oI8EPce2Q3iL5J9gd = ask1yEGJ6VoTdbHhvD8LWRMmpjFzi[qHmcPitXMaCJTswd7zj8W3Ux4u9l]
			Q1a5yI0wvq829DpTLVMAEk6FeftbSs = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			if Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.count(oI8EPce2Q3iL5J9gd)>xD9WeoEAsX7: WqecEMR9bZvpFtCw4HPO76YGu1rJ,z9VUxNFf8DlAKyOp73emYPt,Q1a5yI0wvq829DpTLVMAEk6FeftbSs = Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.split(oI8EPce2Q3iL5J9gd,H3OKMjDG1evnl4Ruiz)
			else: WqecEMR9bZvpFtCw4HPO76YGu1rJ,z9VUxNFf8DlAKyOp73emYPt = Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.split(oI8EPce2Q3iL5J9gd,xD9WeoEAsX7)
			if len(WqecEMR9bZvpFtCw4HPO76YGu1rJ)>ubL8vAD1Ikfz0F6g4: U09WgC1S62YeBRGMmskyfHj.append(WqecEMR9bZvpFtCw4HPO76YGu1rJ.lower())
			if len(z9VUxNFf8DlAKyOp73emYPt)>ubL8vAD1Ikfz0F6g4: U09WgC1S62YeBRGMmskyfHj.append(z9VUxNFf8DlAKyOp73emYPt.lower())
			if len(Q1a5yI0wvq829DpTLVMAEk6FeftbSs)>ubL8vAD1Ikfz0F6g4: U09WgC1S62YeBRGMmskyfHj.append(Q1a5yI0wvq829DpTLVMAEk6FeftbSs.lower())
		elif len(Bdv8A3yIQsrhDb0OpukPoe1JUSVjx)>ubL8vAD1Ikfz0F6g4: U09WgC1S62YeBRGMmskyfHj.append(Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.lower())
	for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠿἖")): DDLw3RXCNW.shuffle(U09WgC1S62YeBRGMmskyfHj)
	if GTmHXIZUSdxRhMnqQKkO(u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫṈ") in wVtSpAsUu0cMblPqxK1F:
		EoGM7qcigmFArkuSn28axV = oZpNRUMvIQDOXyJ26eYctahBz
	elif pL73X0MYajJQG4n1qgD(u"ࠫࡤࡏࡐࡕࡘࡢࠫṉ") in wVtSpAsUu0cMblPqxK1F:
		EoGM7qcigmFArkuSn28axV = [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡏࡐࡕࡘࠪṊ")]
		import jILT90g1EU
		if not jILT90g1EU.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
	elif W2Vv30i8qxSuItfsolPLdFZA(u"࠭࡟ࡎ࠵ࡘࡣࠬṋ") in wVtSpAsUu0cMblPqxK1F:
		EoGM7qcigmFArkuSn28axV = [kAz7WRYjrfGm(u"ࠧࡎ࠵ࡘࠫṌ")]
		import n89RCYixSH
		if not n89RCYixSH.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
	count,fqps8MlYObte0w4zBRECSa3H1 = nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib
	w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṍ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠩ࡞ࠤࠥࡣࠠ࠻ษ็ฬาัฺ่ࠠࠪṎ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"࠱࠷࠶἗"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṏ")+wVtSpAsUu0cMblPqxK1F)
	w3BfOGLdXcWzbiC1PYx9mE(I6Bfzysrvb8DONZ(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṐ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬṑ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"࠲࠸࠷Ἐ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṒ")+wVtSpAsUu0cMblPqxK1F)
	w3BfOGLdXcWzbiC1PYx9mE(pbmKZA1w7L4zHjOM(u"ࠧ࡭࡫ࡱ࡯ࠬṓ"),qFghPAi5yz9Vf3NLwo0nuprl+nR0ok9zju84rFUQl1YC(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ṕ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠻࠼࠽࠾Ἑ"))
	qfcWBJ4UaL2DNey = drzqWFkSHD.menuItemsLIST[:]
	drzqWFkSHD.menuItemsLIST[:] = []
	WzlyIkNFfZmqKEC = []
	for Bdv8A3yIQsrhDb0OpukPoe1JUSVjx in U09WgC1S62YeBRGMmskyfHj:
		z9VUxNFf8DlAKyOp73emYPt = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠩ࡞ࠤࡡ࠲࡜࠼࡞࠽ࡠ࠲ࡢࠫ࡝࠿࡟ࠦࡡ࠭࡜࡜࡞ࡠࡠ࠭ࡢࠩ࡝ࡽ࡟ࢁࡡࠧ࡜ࡁࠩṕ")+CCWqR3dmtzw6xoIX41(u"ࠪࠧࠬṖ")+rAYDiWlzm9MCU6x0GnROua(u"ࠫࡡࠪ࡜ࠦ࡞ࡡࡠࠫࡢࠪ࡝ࡡ࡟ࡀࡡࡄ࡝ࠨṗ"),Bdv8A3yIQsrhDb0OpukPoe1JUSVjx,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if z9VUxNFf8DlAKyOp73emYPt: Bdv8A3yIQsrhDb0OpukPoe1JUSVjx = Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.split(z9VUxNFf8DlAKyOp73emYPt[nUaVQsoA6EXcK4Odht5wCge0J8Pib],xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		id05M2TErJ = Bdv8A3yIQsrhDb0OpukPoe1JUSVjx.replace(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬ๗ࠧṘ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭๎ࠨṙ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(W2Vv30i8qxSuItfsolPLdFZA(u"ࠧ์ࠩṚ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨ๑ࠪṛ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(kAz7WRYjrfGm(u"ࠩ๏ࠫṜ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		id05M2TErJ = id05M2TErJ.replace(YzlId3Fs6vpehcbLGj0UaO(u"ࠪ๔ࠬṝ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫ๒࠭Ṟ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ๘ࠧṟ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ฌࠨṠ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(nR0ok9zju84rFUQl1YC(u"ࠧแࠩṡ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		if id05M2TErJ: WzlyIkNFfZmqKEC.append(id05M2TErJ)
	FrwPL1khARNW2y9E7qfo5eOBH4 = []
	for r6dVWlzDj9va0FxqfkOwLYZEmP in range(nUaVQsoA6EXcK4Odht5wCge0J8Pib,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠵࠴Ἒ")):
		search = DDLw3RXCNW.sample(WzlyIkNFfZmqKEC,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if search in FrwPL1khARNW2y9E7qfo5eOBH4: continue
		FrwPL1khARNW2y9E7qfo5eOBH4.append(search)
		z4t2nu5ryZjPR = DDLw3RXCNW.sample(EoGM7qcigmFArkuSn28axV,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+pL73X0MYajJQG4n1qgD(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡧࡲࡤࡪࠣࠤࠥࡹࡩࡵࡧ࠽ࠫṢ")+str(z4t2nu5ryZjPR)+CCWqR3dmtzw6xoIX41(u"ࠩࠣࠤࡸ࡫ࡡࡳࡥ࡫࠾ࠬṣ")+search)
		Rdnmer47TgYcStA19l8pUj2XBuL3b,KvBuT8dIwNVR7e61zJnWrmUGPh,sBSQhi1aPIpFjUX9Ae6G5OdzKx2W7g = Fm3K4dSEpxINJjDQXwOThk6W(z4t2nu5ryZjPR)
		KvBuT8dIwNVR7e61zJnWrmUGPh(search+nR0ok9zju84rFUQl1YC(u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨṤ"))
		if len(drzqWFkSHD.menuItemsLIST)>nUaVQsoA6EXcK4Odht5wCge0J8Pib: break
	search = search.replace(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡤࡓࡏࡅࡡࠪṥ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	qfcWBJ4UaL2DNey[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7] = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡡࠧṦ")+qFghPAi5yz9Vf3NLwo0nuprl+search+so4Z8OUJ5E+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠠ࠻สะฯࠥ฿ๆ࡞ࠩṧ")
	drzqWFkSHD.menuItemsLIST[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
	if len(drzqWFkSHD.menuItemsLIST)>GGBXMJbitIEs: drzqWFkSHD.menuItemsLIST[:] = DDLw3RXCNW.sample(drzqWFkSHD.menuItemsLIST,GGBXMJbitIEs)
	drzqWFkSHD.menuItemsLIST[:] = qfcWBJ4UaL2DNey+drzqWFkSHD.menuItemsLIST
	return
def Qte6yJ813hS2frjn0bLKAVlZD(VcuqLlfnekyCoOjvQh387xK0NptA,wVtSpAsUu0cMblPqxK1F):
	VcuqLlfnekyCoOjvQh387xK0NptA = VcuqLlfnekyCoOjvQh387xK0NptA.replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡠࡏࡒࡈࡤ࠭Ṩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	wVtSpAsUu0cMblPqxK1F = wVtSpAsUu0cMblPqxK1F.replace(pYeVwat64v(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṩ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ṫ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	NNuyoWnLO5YibAgcR0XqKxPfCad(pLwgjkuTs6CS)
	if not dosubM4RVU: return
	if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬṫ") in wVtSpAsUu0cMblPqxK1F:
		w3BfOGLdXcWzbiC1PYx9mE(YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṬ"),pYeVwat64v(u"ࠬࡡࠧṭ")+qFghPAi5yz9Vf3NLwo0nuprl+VcuqLlfnekyCoOjvQh387xK0NptA+so4Z8OUJ5E+ba49YvOK2Aw8Uhxt(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨṮ"),VcuqLlfnekyCoOjvQh387xK0NptA,B1YMtuvRAGNlJOkC46VyPKQE(u"࠵࠻࠼Ἓ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṯ")+wVtSpAsUu0cMblPqxK1F)
		w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṰ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨṱ"),VcuqLlfnekyCoOjvQh387xK0NptA,zWBnYSGIatjXVC(u"࠶࠼࠶Ἔ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṲ")+wVtSpAsUu0cMblPqxK1F)
		w3BfOGLdXcWzbiC1PYx9mE(pYeVwat64v(u"ࠫࡱ࡯࡮࡬ࠩṳ"),qFghPAi5yz9Vf3NLwo0nuprl+Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪṴ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠿࠹࠺࠻Ἕ"))
	for website in sorted(list(dosubM4RVU[VcuqLlfnekyCoOjvQh387xK0NptA].keys())):
		type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = dosubM4RVU[VcuqLlfnekyCoOjvQh387xK0NptA][website]
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨṵ") in wVtSpAsUu0cMblPqxK1F or len(dosubM4RVU[VcuqLlfnekyCoOjvQh387xK0NptA])==xD9WeoEAsX7:
			J3t4CspyDNgjv9MbzAqELQFx5Z(type,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,url,Hz927w5lkDgynBGF,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			drzqWFkSHD.menuItemsLIST[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
			IAgwJrk6nhP7m3iyv28Z5c,ERIWgZzeGk9O0yVoDvs3FqwT = drzqWFkSHD.menuItemsLIST[:anb4QpyjlmgVwANP],drzqWFkSHD.menuItemsLIST[anb4QpyjlmgVwANP:]
			if YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩṶ") in wVtSpAsUu0cMblPqxK1F:
				for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(jBbkfIJSDqcVwl8irzy4Z3O(u"࠹἞")): DDLw3RXCNW.shuffle(ERIWgZzeGk9O0yVoDvs3FqwT)
				drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT[:GGBXMJbitIEs]
			else: drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT
		elif zWBnYSGIatjXVC(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩṷ") in wVtSpAsUu0cMblPqxK1F: w3BfOGLdXcWzbiC1PYx9mE(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡩࡳࡱࡪࡥࡳࠩṸ"),website,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
	return
def pUByoDEWmkJlG5Ne04F68QAYx(wVtSpAsUu0cMblPqxK1F,t5fhagjUGXk0ynOlJWeAb):
	wVtSpAsUu0cMblPqxK1F = wVtSpAsUu0cMblPqxK1F.replace(Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṹ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(KKCrwPdOgGl(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṺ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	usYnJBXhFT,ERIWgZzeGk9O0yVoDvs3FqwT = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
	w3BfOGLdXcWzbiC1PYx9mE(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṻ"),W2Vv30i8qxSuItfsolPLdFZA(u"࡛࠭ࠨṼ")+qFghPAi5yz9Vf3NLwo0nuprl+usYnJBXhFT+so4Z8OUJ5E+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩṽ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,t5fhagjUGXk0ynOlJWeAb,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ṿ")+wVtSpAsUu0cMblPqxK1F)
	w3BfOGLdXcWzbiC1PYx9mE(nR0ok9zju84rFUQl1YC(u"ࠩࡩࡳࡱࡪࡥࡳࠩṿ"),GTmHXIZUSdxRhMnqQKkO(u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪẀ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,t5fhagjUGXk0ynOlJWeAb,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẁ")+wVtSpAsUu0cMblPqxK1F)
	w3BfOGLdXcWzbiC1PYx9mE(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡲࡩ࡯࡭ࠪẂ"),qFghPAi5yz9Vf3NLwo0nuprl+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẃ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠺࠻࠼࠽἟"))
	IAgwJrk6nhP7m3iyv28Z5c = drzqWFkSHD.menuItemsLIST[:]
	drzqWFkSHD.menuItemsLIST[:] = []
	Ubud2NhHKRnMTvI5mprQBVqk80 = []
	if f9fOpCmLAEaW2Go(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨẄ") in wVtSpAsUu0cMblPqxK1F:
		NNuyoWnLO5YibAgcR0XqKxPfCad(pLwgjkuTs6CS)
		if not dosubM4RVU: return
		e5hZpAfUXxI2uOHiDYEgkK = list(dosubM4RVU.keys())
		VcuqLlfnekyCoOjvQh387xK0NptA = DDLw3RXCNW.sample(e5hZpAfUXxI2uOHiDYEgkK,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		U09WgC1S62YeBRGMmskyfHj = list(dosubM4RVU[VcuqLlfnekyCoOjvQh387xK0NptA].keys())
		website = DDLw3RXCNW.sample(U09WgC1S62YeBRGMmskyfHj,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = dosubM4RVU[VcuqLlfnekyCoOjvQh387xK0NptA][website]
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫẅ")+website+rAYDiWlzm9MCU6x0GnROua(u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬẆ")+usYnJBXhFT+pL73X0MYajJQG4n1qgD(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬẇ")+url+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧẈ")+str(Hz927w5lkDgynBGF))
	elif CCWqR3dmtzw6xoIX41(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬẉ") in wVtSpAsUu0cMblPqxK1F:
		import jILT90g1EU
		if not jILT90g1EU.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
		for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
			Ubud2NhHKRnMTvI5mprQBVqk80 += jpwcAFdgxsVaSi4H(str(ozc8fP05O4GntlhQgRyCZmeKI3F),wVtSpAsUu0cMblPqxK1F)
		if not Ubud2NhHKRnMTvI5mprQBVqk80: return
		type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = DDLw3RXCNW.sample(Ubud2NhHKRnMTvI5mprQBVqk80,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+CCWqR3dmtzw6xoIX41(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ẋ")+usYnJBXhFT+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩẋ")+url+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫẌ")+str(Hz927w5lkDgynBGF))
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡢࡑ࠸࡛࡟ࠨẍ") in wVtSpAsUu0cMblPqxK1F:
		import n89RCYixSH
		if not n89RCYixSH.rb1LQeqnckC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau): return
		for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
			Ubud2NhHKRnMTvI5mprQBVqk80 += YNCAVFgUwvkZ1t3(str(ozc8fP05O4GntlhQgRyCZmeKI3F),wVtSpAsUu0cMblPqxK1F)
		if not Ubud2NhHKRnMTvI5mprQBVqk80: return
		type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = DDLw3RXCNW.sample(Ubud2NhHKRnMTvI5mprQBVqk80,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+ba49YvOK2Aw8Uhxt(u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪẎ")+usYnJBXhFT+lRKCWnNi0Edr984eI(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭ẏ")+url+nR0ok9zju84rFUQl1YC(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨẐ")+str(Hz927w5lkDgynBGF))
	TqQfrYUuIMmj75apNhG = usYnJBXhFT
	N5iSm4rg0CDU1 = []
	for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(nUaVQsoA6EXcK4Odht5wCge0J8Pib,Zb5cNeHWi6jP9SCYtUgR(u"࠳࠳ἠ")):
		if uKFGBAEj9tX1e03cyHOMUNhQl4r6>nUaVQsoA6EXcK4Odht5wCge0J8Pib: UO05pib6mcvezR9(jZBtGcdApeKLEkb,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+lRKCWnNi0Edr984eI(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭ẑ")+usYnJBXhFT+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩẒ")+url+ba49YvOK2Aw8Uhxt(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫẓ")+str(Hz927w5lkDgynBGF))
		drzqWFkSHD.menuItemsLIST[:] = []
		if Hz927w5lkDgynBGF==YzlId3Fs6vpehcbLGj0UaO(u"࠵࠷࠹ἡ") and ba49YvOK2Aw8Uhxt(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪẔ") in ggM5TzCxq24sDYLiEatpdSK7FQyGe: Hz927w5lkDgynBGF = CCWqR3dmtzw6xoIX41(u"࠶࠸࠹ἢ")
		if Hz927w5lkDgynBGF==jBbkfIJSDqcVwl8irzy4Z3O(u"࠼࠷࠴ἣ") and zWBnYSGIatjXVC(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪẕ") in ggM5TzCxq24sDYLiEatpdSK7FQyGe: Hz927w5lkDgynBGF = CCWqR3dmtzw6xoIX41(u"࠽࠱࠴ἤ")
		if Hz927w5lkDgynBGF==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠱࠵࠶ἥ"): Hz927w5lkDgynBGF = vl6rwMLasAQo4z1ZjD3IBKtF(u"࠳࠻࠴ἦ")
		G20Fvhu5p3 = J3t4CspyDNgjv9MbzAqELQFx5Z(type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU)
		if pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡤࡏࡐࡕࡘࡢࠫẖ") in wVtSpAsUu0cMblPqxK1F and Hz927w5lkDgynBGF==KKCrwPdOgGl(u"࠳࠹࠻ἧ"): del drzqWFkSHD.menuItemsLIST[:anb4QpyjlmgVwANP]
		if CCWqR3dmtzw6xoIX41(u"ࠬࡥࡍ࠴ࡗࡢࠫẗ") in wVtSpAsUu0cMblPqxK1F and Hz927w5lkDgynBGF==ba49YvOK2Aw8Uhxt(u"࠴࠺࠽Ἠ"): del drzqWFkSHD.menuItemsLIST[:anb4QpyjlmgVwANP]
		ERIWgZzeGk9O0yVoDvs3FqwT[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
		if N5iSm4rg0CDU1 and RspX7vMFScnPqAubegiNlo1HDW83UE(awSUTRNMkdIW7sFEvnHD2mLY(u"ࡻࠧฮๆๅอࠬẘ")) in str(ERIWgZzeGk9O0yVoDvs3FqwT) or RspX7vMFScnPqAubegiNlo1HDW83UE(pYeVwat64v(u"ࡵࠨฯ็ๆ์࠭ẙ")) in str(ERIWgZzeGk9O0yVoDvs3FqwT):
			usYnJBXhFT = TqQfrYUuIMmj75apNhG
			ERIWgZzeGk9O0yVoDvs3FqwT[:] = N5iSm4rg0CDU1
			break
		TqQfrYUuIMmj75apNhG = usYnJBXhFT
		N5iSm4rg0CDU1 = ERIWgZzeGk9O0yVoDvs3FqwT
		if str(ERIWgZzeGk9O0yVoDvs3FqwT).count(f9fOpCmLAEaW2Go(u"ࠨࡸ࡬ࡨࡪࡵࠧẚ"))>nUaVQsoA6EXcK4Odht5wCge0J8Pib: break
		if str(ERIWgZzeGk9O0yVoDvs3FqwT).count(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩ࡯࡭ࡻ࡫ࠧẛ"))>nUaVQsoA6EXcK4Odht5wCge0J8Pib: break
		if Hz927w5lkDgynBGF==awSUTRNMkdIW7sFEvnHD2mLY(u"࠶࠸࠹Ἡ"): break
		if Hz927w5lkDgynBGF==nR0ok9zju84rFUQl1YC(u"࠼࠷࠳Ἢ"): break
		if Hz927w5lkDgynBGF==JZ45mOctiTszPNw1GVjxhep2Y(u"࠸࠹࠲Ἣ"): break
		if W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬẜ") in wVtSpAsUu0cMblPqxK1F and ERIWgZzeGk9O0yVoDvs3FqwT: type,usYnJBXhFT,url,Hz927w5lkDgynBGF,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU = DDLw3RXCNW.sample(ERIWgZzeGk9O0yVoDvs3FqwT,xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if not usYnJBXhFT: usYnJBXhFT = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࠳࠴࠮࠯ࠩẝ")
	elif usYnJBXhFT.count(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡥࠧẞ"))>xD9WeoEAsX7: usYnJBXhFT = usYnJBXhFT.split(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭࡟ࠨẟ"),H3OKMjDG1evnl4Ruiz)[H3OKMjDG1evnl4Ruiz]
	usYnJBXhFT = usYnJBXhFT.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠧࡖࡐࡎࡒࡔ࡝ࡎ࠻ࠢࠪẠ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	usYnJBXhFT = usYnJBXhFT.replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡡࡐࡓࡉࡥࠧạ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	IAgwJrk6nhP7m3iyv28Z5c[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7] = pbmKZA1w7L4zHjOM(u"ࠩ࡞ࠫẢ")+qFghPAi5yz9Vf3NLwo0nuprl+usYnJBXhFT+so4Z8OUJ5E+ba49YvOK2Aw8Uhxt(u"ࠪࠤ࠿อไใี่ࡡࠬả")
	if f9fOpCmLAEaW2Go(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ấ") in wVtSpAsUu0cMblPqxK1F:
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(awSUTRNMkdIW7sFEvnHD2mLY(u"࠹Ἤ")): DDLw3RXCNW.shuffle(ERIWgZzeGk9O0yVoDvs3FqwT)
		drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT[:GGBXMJbitIEs]
	else: drzqWFkSHD.menuItemsLIST[:] = IAgwJrk6nhP7m3iyv28Z5c+ERIWgZzeGk9O0yVoDvs3FqwT
	return
def QUZaDEuqdCw3AGNPY270bMmJyK6Lc8(c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY):
	uOywlfszKUAe23dY = uOywlfszKUAe23dY.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧấ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(YzlId3Fs6vpehcbLGj0UaO(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẦ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	siVIambzANdfvRhOJuSnW4Pq7 = uOywlfszKUAe23dY
	if lRKCWnNi0Edr984eI(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨầ") in uOywlfszKUAe23dY:
		siVIambzANdfvRhOJuSnW4Pq7 = uOywlfszKUAe23dY.split(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩẨ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		type = pYeVwat64v(u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬẩ")
	elif w9wfONXUP3(u"࡚ࠪࡔࡊࠧẪ") in c0haoBCblMIgiLHP65OAdWDu4Jjz9: type = W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧẫ")
	elif YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡒࡉࡗࡇࠪẬ") in c0haoBCblMIgiLHP65OAdWDu4Jjz9: type = hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧậ")
	w3BfOGLdXcWzbiC1PYx9mE(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẮ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡝ࠪắ")+qFghPAi5yz9Vf3NLwo0nuprl+type+siVIambzANdfvRhOJuSnW4Pq7+so4Z8OUJ5E+lRKCWnNi0Edr984eI(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫẰ"),c0haoBCblMIgiLHP65OAdWDu4Jjz9,jBbkfIJSDqcVwl8irzy4Z3O(u"࠲࠸࠺Ἥ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨằ")+uOywlfszKUAe23dY)
	w3BfOGLdXcWzbiC1PYx9mE(zWBnYSGIatjXVC(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẲ"),pbmKZA1w7L4zHjOM(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫẳ"),c0haoBCblMIgiLHP65OAdWDu4Jjz9,CCWqR3dmtzw6xoIX41(u"࠳࠹࠻Ἦ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẴ")+uOywlfszKUAe23dY)
	w3BfOGLdXcWzbiC1PYx9mE(Zb5cNeHWi6jP9SCYtUgR(u"ࠧ࡭࡫ࡱ࡯ࠬẵ"),qFghPAi5yz9Vf3NLwo0nuprl+pL73X0MYajJQG4n1qgD(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ặ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CCWqR3dmtzw6xoIX41(u"࠼࠽࠾࠿Ἧ"))
	import jILT90g1EU
	for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
		if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪặ") in uOywlfszKUAe23dY: jILT90g1EU.VGmzPvN3XkOw0Frs2I9EKDyhq(str(ozc8fP05O4GntlhQgRyCZmeKI3F),c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS)
		else: jILT90g1EU.VuHht6MNBWRnOkX9S(str(ozc8fP05O4GntlhQgRyCZmeKI3F),c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS)
	drzqWFkSHD.menuItemsLIST[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
	if len(drzqWFkSHD.menuItemsLIST)>(GGBXMJbitIEs+anb4QpyjlmgVwANP): drzqWFkSHD.menuItemsLIST[:] = drzqWFkSHD.menuItemsLIST[:anb4QpyjlmgVwANP]+DDLw3RXCNW.sample(drzqWFkSHD.menuItemsLIST[anb4QpyjlmgVwANP:],GGBXMJbitIEs)
	return
def XXtDmFRPHoixnypOTSCM065ZNLg(c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY):
	uOywlfszKUAe23dY = uOywlfszKUAe23dY.replace(rAYDiWlzm9MCU6x0GnROua(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬẸ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(CCWqR3dmtzw6xoIX41(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨẹ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	siVIambzANdfvRhOJuSnW4Pq7 = uOywlfszKUAe23dY
	if pL73X0MYajJQG4n1qgD(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬẺ") in uOywlfszKUAe23dY:
		siVIambzANdfvRhOJuSnW4Pq7 = uOywlfszKUAe23dY.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ẻ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		type = lRKCWnNi0Edr984eI(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪẼ")
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡘࡒࡈࠬẽ") in c0haoBCblMIgiLHP65OAdWDu4Jjz9: type = pbmKZA1w7L4zHjOM(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬẾ")
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡐࡎ࡜ࡅࠨế") in c0haoBCblMIgiLHP65OAdWDu4Jjz9: type = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬỀ")
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬề"),rAYDiWlzm9MCU6x0GnROua(u"࡛࠭ࠨỂ")+qFghPAi5yz9Vf3NLwo0nuprl+type+siVIambzANdfvRhOJuSnW4Pq7+so4Z8OUJ5E+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩể"),c0haoBCblMIgiLHP65OAdWDu4Jjz9,awSUTRNMkdIW7sFEvnHD2mLY(u"࠵࠻࠾ἰ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ễ")+uOywlfszKUAe23dY)
	w3BfOGLdXcWzbiC1PYx9mE(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡩࡳࡱࡪࡥࡳࠩễ"),nR0ok9zju84rFUQl1YC(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩỆ"),c0haoBCblMIgiLHP65OAdWDu4Jjz9,W2Vv30i8qxSuItfsolPLdFZA(u"࠶࠼࠸ἱ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩệ")+uOywlfszKUAe23dY)
	w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡲࡩ࡯࡭ࠪỈ"),qFghPAi5yz9Vf3NLwo0nuprl+I6Bfzysrvb8DONZ(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫỉ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"࠿࠹࠺࠻ἲ"))
	import n89RCYixSH
	for ozc8fP05O4GntlhQgRyCZmeKI3F in range(xD9WeoEAsX7,RR1typGWKXVd6vNAaMEqo9h+xD9WeoEAsX7):
		if CCWqR3dmtzw6xoIX41(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧỊ") in uOywlfszKUAe23dY: n89RCYixSH.VGmzPvN3XkOw0Frs2I9EKDyhq(str(ozc8fP05O4GntlhQgRyCZmeKI3F),c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS)
		else: n89RCYixSH.VuHht6MNBWRnOkX9S(str(ozc8fP05O4GntlhQgRyCZmeKI3F),c0haoBCblMIgiLHP65OAdWDu4Jjz9,uOywlfszKUAe23dY,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS)
	drzqWFkSHD.menuItemsLIST[:] = DTeCgVzF4nEZUlsfjtK3Iukap2c6(drzqWFkSHD.menuItemsLIST)
	if len(drzqWFkSHD.menuItemsLIST)>(GGBXMJbitIEs+anb4QpyjlmgVwANP): drzqWFkSHD.menuItemsLIST[:] = drzqWFkSHD.menuItemsLIST[:anb4QpyjlmgVwANP]+DDLw3RXCNW.sample(drzqWFkSHD.menuItemsLIST[anb4QpyjlmgVwANP:],GGBXMJbitIEs)
	return
def DTeCgVzF4nEZUlsfjtK3Iukap2c6(SmyQBIF5q7bdOvVMJ8AURgu3a1p):
	lQ7wVXOAayfSv = []
	for type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU in SmyQBIF5q7bdOvVMJ8AURgu3a1p:
		if pYeVwat64v(u"ࠨืไัฮ࠭ị") in usYnJBXhFT or GTmHXIZUSdxRhMnqQKkO(u"ุࠩๅาํࠧỌ") in usYnJBXhFT or pYeVwat64v(u"ࠪࡴࡦ࡭ࡥࠨọ") in usYnJBXhFT.lower(): continue
		lQ7wVXOAayfSv.append([type,usYnJBXhFT,url,t5fhagjUGXk0ynOlJWeAb,E7MF9aYlV4Q0,GpwRnQ6q2o1fv0HbJTs,ggM5TzCxq24sDYLiEatpdSK7FQyGe,OZK8LwloB3azFd,CC8RbxJ4AHh9rgjTdBsU])
	return lQ7wVXOAayfSv