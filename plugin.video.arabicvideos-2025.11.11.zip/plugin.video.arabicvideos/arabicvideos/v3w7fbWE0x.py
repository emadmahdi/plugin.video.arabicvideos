# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = w9wfONXUP3(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪἳ")
y8wc2Hp7A1kU4b = []
headers = {KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬἴ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
def FGtegqJ7m5nLx9idIhkNvB(url,SQxyVRe4u8qr1cGtAKO2,Nm3S9j4awYevPxs2qriCtT):
	url = url.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࠲ࡱ࡮ࡸࡲࡰࡴ࠲ࠫἵ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪ࠳࡮࡬ࡲࡢ࡯ࡨ࠳ࠬἶ")).replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨἷ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬ࠵ࡩࡧࡴࡤࡱࡪ࠵ࠧἸ"))
	url = url.replace(w9wfONXUP3(u"࠭࠯ࡸ࠰ࡰࡩ࡬ࡧ࡭ࡢࡺ࠱ࡱࡪ࠵ࠧἹ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧ࠰࡯ࡨ࡫ࡦࡳࡡࡹ࠰ࡰࡩ࠴࠭Ἲ"))
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡉࡈࡘࠬἻ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,pYeVwat64v(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍࡆࡉࡄࡑࡆ࡞࠭࠲ࡵࡷࠫἼ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	WMBgY8iZ3afwKcV = AxTYMhRlfyskNc0X19dvwtS.findall(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠪࡶࡻ࡯ࡵ࠽࠽ࠪࡶࡻ࡯ࡵ࠽ࠫ࠲࠯ࡅࠩࠧࡳࡸࡳࡹࡁࠧἽ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	headers = {hWRvZOYtjme9QNnV41u0Mswb(u"ࠫ࡝࠳ࡉ࡯ࡧࡵࡸ࡮ࡧࠧἾ"):pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡺࡲࡶࡧࠪἿ"),pbmKZA1w7L4zHjOM(u"࠭ࡘ࠮ࡋࡱࡩࡷࡺࡩࡢ࠯ࡓࡥࡷࡺࡩࡢ࡮࠰ࡈࡦࡺࡡࠨὀ"):slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡴࡶࡵࡩࡦࡳࡳࠨὁ"),nR0ok9zju84rFUQl1YC(u"ࠨ࡚࠰ࡍࡳ࡫ࡲࡵ࡫ࡤ࠱ࡕࡧࡲࡵ࡫ࡤࡰ࠲ࡉ࡯࡮ࡲࡲࡲࡪࡴࡴࠨὂ"):YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡩ࡭ࡱ࡫ࡳ࠰࡯࡬ࡶࡷࡵࡲ࠰ࡸ࡬ࡨࡪࡵࠧὃ")}
	headers[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪ࡜࠲ࡏ࡮ࡦࡴࡷ࡭ࡦ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧὄ")] = WMBgY8iZ3afwKcV[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡌࡋࡔࠨὅ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐࡉࡌࡇࡍࡂ࡚࠰࠶ࡳࡪࠧ὆"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	Hk6AIvPhe0R1G = WWNb0XnUxOPL9gF.loads(R8AE9e4mYxVhusL3Q)
	v6Hs1jlxutoLOnedQ = Hk6AIvPhe0R1G[I6Bfzysrvb8DONZ(u"࠭ࡰࡳࡱࡳࡷࠬ὇")][pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡴࡶࡵࡩࡦࡳࡳࠨὈ")][zWBnYSGIatjXVC(u"ࠨࡦࡤࡸࡦ࠭Ὁ")]
	dU17fayKLj4kABu = []
	for OOWFun1mZvjJIiKlRSQgT624 in range(len(v6Hs1jlxutoLOnedQ)):
		XcvFdKRjNLz5wEpDf = v6Hs1jlxutoLOnedQ[OOWFun1mZvjJIiKlRSQgT624][KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩ࡯ࡥࡧ࡫࡬ࠨὊ")]
		BA01W9olieErLycV7kwFvOhH5Y3ms = v6Hs1jlxutoLOnedQ[OOWFun1mZvjJIiKlRSQgT624][f9fOpCmLAEaW2Go(u"ࠪࡱ࡮ࡸࡲࡰࡴࡶࠫὋ")]
		for GGmgloh8aQxVSCJfLH in range(len(BA01W9olieErLycV7kwFvOhH5Y3ms)):
			title = BA01W9olieErLycV7kwFvOhH5Y3ms[GGmgloh8aQxVSCJfLH][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡩࡸࡩࡷࡧࡵࠫὌ")]
			cX2SpPxGLmADTKl = KKCrwPdOgGl(u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬὍ")+BA01W9olieErLycV7kwFvOhH5Y3ms[GGmgloh8aQxVSCJfLH][I6Bfzysrvb8DONZ(u"࠭࡬ࡪࡰ࡮ࠫ὎")]+Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ὏")+title+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡡࡢࠫὐ")+SQxyVRe4u8qr1cGtAKO2+hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡢࡣࠬὑ")+XcvFdKRjNLz5wEpDf
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	return dU17fayKLj4kABu
def ffsFXIPVASCJk3wU9(url,SQxyVRe4u8qr1cGtAKO2,Nm3S9j4awYevPxs2qriCtT):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡋࡊ࡚ࠧὒ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡃࡏࡆࡆࡖࡌࡂ࡛ࡈࡖ࠲࠷ࡳࡵࠩὓ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if fOohwvakqi29cx0l3yt5mzrAGpEg and isinstance(R8AE9e4mYxVhusL3Q,bytes): R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.decode(RMGz7OiD1e30P,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬὔ"))
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࠢࡢࡲ࡯ࡶ࠲ࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧὕ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(hWRvZOYtjme9QNnV41u0Mswb(u"ࠧ࠽ࡣࠣࡧࡱࡧࡳࡴ࠿ࠥࡥࡵࡲࡲ࠮࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫὖ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		dU17fayKLj4kABu = []
		for cX2SpPxGLmADTKl,title in items:
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+I6Bfzysrvb8DONZ(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩὗ")+title+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡢࡣࠬ὘")+SQxyVRe4u8qr1cGtAKO2)
	return dU17fayKLj4kABu
def mQwneov0bFMZEt2RjSqUYNPO7(url,SQxyVRe4u8qr1cGtAKO2,Nm3S9j4awYevPxs2qriCtT):
	qYilgFy4JTUPa = url.split(GTmHXIZUSdxRhMnqQKkO(u"ࠪ࠳ࠬὙ"))[YzlId3Fs6vpehcbLGj0UaO(u"࠴࿇")]
	mVh58FX3zfTpEu = j3kWVqdguK6O2QDmMf.b64decode(qYilgFy4JTUPa)
	if fOohwvakqi29cx0l3yt5mzrAGpEg: mVh58FX3zfTpEu = mVh58FX3zfTpEu.decode(RMGz7OiD1e30P)
	UmY0wRNr7xMPAHybl = WDg18QHF3rze(mVh58FX3zfTpEu)+rAYDiWlzm9MCU6x0GnROua(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ὚")+Nm3S9j4awYevPxs2qriCtT
	return [UmY0wRNr7xMPAHybl]
def WQJGuqSHelwh8inrDvBEU(wO24tIxWkhUTZ0,source):
	OIbrTU8tkdvLRlSG9jZhgXoPC,EEhiubwkqBtm6sZy0GnLd = [],[]
	for S8VIk4HT36jKs0QzDyeUBv1h in wO24tIxWkhUTZ0:
		k32OnDpq9SwGQhVM6 = AxTYMhRlfyskNc0X19dvwtS.findall(KKCrwPdOgGl(u"ࠬࡴࡡ࡮ࡧࡧࡁ࠳࠰࠿ࡠࡡࠫ࠲࠯ࡅࠩࡠࡡࠪὛ"),S8VIk4HT36jKs0QzDyeUBv1h+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࡟ࡠࠩ὜"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		w61WFj04Q9Xb3Zs8RBSqUgNdH2v = k32OnDpq9SwGQhVM6[nUaVQsoA6EXcK4Odht5wCge0J8Pib] if k32OnDpq9SwGQhVM6 else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		EuH53PamefqIQRUYTZ8pn,ZjokGdHO0eSb2,GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = S8VIk4HT36jKs0QzDyeUBv1h,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
		if f9fOpCmLAEaW2Go(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨὝ") in S8VIk4HT36jKs0QzDyeUBv1h: EuH53PamefqIQRUYTZ8pn,ZjokGdHO0eSb2 = S8VIk4HT36jKs0QzDyeUBv1h.split(pYeVwat64v(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ὞"),xD9WeoEAsX7)
		try:
			if I6Bfzysrvb8DONZ(u"ࠩࡤࡰࡧࡧࡰ࡭ࡣࡼࡩࡷ࠭Ὗ") in EuH53PamefqIQRUYTZ8pn: GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = ffsFXIPVASCJk3wU9(EuH53PamefqIQRUYTZ8pn,w61WFj04Q9Xb3Zs8RBSqUgNdH2v,ZjokGdHO0eSb2)
			elif zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡱࡪ࡭ࡡ࡮ࡣࡻࠫὠ") in EuH53PamefqIQRUYTZ8pn: GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = FGtegqJ7m5nLx9idIhkNvB(EuH53PamefqIQRUYTZ8pn,w61WFj04Q9Xb3Zs8RBSqUgNdH2v,ZjokGdHO0eSb2)
			elif GTmHXIZUSdxRhMnqQKkO(u"ࠫ࠴ࡲ࠯ࡢࡊࡕ࠴ࡨࡎࡍ࠷ࡎࡼ࠽ࠬὡ") in EuH53PamefqIQRUYTZ8pn: GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = mQwneov0bFMZEt2RjSqUYNPO7(EuH53PamefqIQRUYTZ8pn,w61WFj04Q9Xb3Zs8RBSqUgNdH2v,ZjokGdHO0eSb2)
		except: pass
		if GQAq8OnFcBve2Zi4oLH0mzNWU6hYK:
			for evGVuBpQUEL in GQAq8OnFcBve2Zi4oLH0mzNWU6hYK:
				Y7rUcNufE0lxCZVRi3,ZZgiBLKqHNawYsTktI4 = evGVuBpQUEL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ὢ") in evGVuBpQUEL: Y7rUcNufE0lxCZVRi3,ZZgiBLKqHNawYsTktI4 = evGVuBpQUEL.split(pL73X0MYajJQG4n1qgD(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧὣ"),xD9WeoEAsX7)
				if Y7rUcNufE0lxCZVRi3 not in OIbrTU8tkdvLRlSG9jZhgXoPC:
					OIbrTU8tkdvLRlSG9jZhgXoPC.append(Y7rUcNufE0lxCZVRi3)
					EEhiubwkqBtm6sZy0GnLd.append(evGVuBpQUEL)
		elif EuH53PamefqIQRUYTZ8pn not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(EuH53PamefqIQRUYTZ8pn)
			EEhiubwkqBtm6sZy0GnLd.append(S8VIk4HT36jKs0QzDyeUBv1h)
	return EEhiubwkqBtm6sZy0GnLd
def apu7BqgDXMYhdRy38lCPUo0Wv9kA(source,YYTAkfz3NaQrLuCyRE,url):
	UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧὤ")+source+pbmKZA1w7L4zHjOM(u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩὥ")+YYTAkfz3NaQrLuCyRE+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࠣࡡࠬὦ"))
	w27G90uSZsI5Cz8D = dYMLGvgfk4(mmEuUR4JdaHtAsS,kAz7WRYjrfGm(u"ࠪࡨ࡮ࡩࡴࠨὧ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧὨ"),JZ45mOctiTszPNw1GVjxhep2Y(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫὩ"))
	h4aBTEirF3J26swgx7De9POQULq = f7epsRlYtMz4.strftime(YzlId3Fs6vpehcbLGj0UaO(u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧὪ"),f7epsRlYtMz4.gmtime(KKydonNSglP1M08xw7O))
	bkhQVre594UyJ = h4aBTEirF3J26swgx7De9POQULq,url
	key = source+NNJKRTY8GlM29ezbCgPiXd+FLRQJnBHTvsXU+NNJKRTY8GlM29ezbCgPiXd+str(XqSerIMoFsRn2UQ1D5Alj6)
	mlrXUnyLzPAhEIj8ix5Ztpu = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if key not in list(w27G90uSZsI5Cz8D.keys()): w27G90uSZsI5Cz8D[key] = [bkhQVre594UyJ]
	else:
		if url not in str(w27G90uSZsI5Cz8D[key]): w27G90uSZsI5Cz8D[key].append(bkhQVre594UyJ)
		else: mlrXUnyLzPAhEIj8ix5Ztpu = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࡝ࡰ๋ࠣีอࠠศๆไ๎ิ๐่ࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋ࠠห฻่่ࠬὫ")
	ttqZRi4VpCHb = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	for key in list(w27G90uSZsI5Cz8D.keys()):
		w27G90uSZsI5Cz8D[key] = list(set(w27G90uSZsI5Cz8D[key]))
		ttqZRi4VpCHb += len(w27G90uSZsI5Cz8D[key])
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩὬ")+mlrXUnyLzPAhEIj8ix5Ztpu+nR0ok9zju84rFUQl1YC(u"ࠩ࡟ࡲࡡࡴࠠๅๆ฼่๊ࠦวๅสิ๊ฬ๋ฬࠡ์ๅ์๊ࠦศอ็฼ࠤ็อฦๆหࠣฬฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢํะิࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่๊ࠡึ์ๆฺ๊ࠦำูࠤ฾๊๊ไࠢส่อืๆศ็ฯࠤศ์ࠠหำึ่ࠥํะ่ࠢส่็อฦๆหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻้ำ๊อ๋ࠠืหัࠥ฿ฯะ้สࠤ࠺ࠦแ๋ัํ์์อสࠨὭ")+Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡠࡳࡢ࡮ࠨὮ")+CCWqR3dmtzw6xoIX41(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡษ็ๆฬฬๅสࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠧὯ")+str(ttqZRi4VpCHb))
	if ttqZRi4VpCHb>=Hip2swoNbVaZ30OrStQR1lF:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,GTmHXIZUSdxRhMnqQKkO(u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠷ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭ὰ"))
		if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
			GlD7Pcn16z2vQmw9jJapXk = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			for key in list(w27G90uSZsI5Cz8D.keys()):
				GlD7Pcn16z2vQmw9jJapXk += b8sk5WyPoz03pXhRx+key
				hgc0AIKNqJHDBxM4 = sorted(w27G90uSZsI5Cz8D[key],reverse=pLwgjkuTs6CS,key=lambda o137UDMtpS5a: o137UDMtpS5a[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
				for h4aBTEirF3J26swgx7De9POQULq,url in hgc0AIKNqJHDBxM4:
					GlD7Pcn16z2vQmw9jJapXk += b8sk5WyPoz03pXhRx+h4aBTEirF3J26swgx7De9POQULq+NNJKRTY8GlM29ezbCgPiXd+WDg18QHF3rze(url)
				GlD7Pcn16z2vQmw9jJapXk += CCWqR3dmtzw6xoIX41(u"࠭࡜࡯࡞ࡱࠫά")
			import IxiP9D6sLd
			oo3n0EuaHjYSz = IxiP9D6sLd.C4CdVtZQikT(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡗ࡫ࡧࡩࡴࡹࠧὲ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬέ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GlD7Pcn16z2vQmw9jJapXk)
			if oo3n0EuaHjYSz: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,I6Bfzysrvb8DONZ(u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬὴ"))
			else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨή"))
		if e6f0ycMuYQEJraNLInmip!=-xD9WeoEAsX7:
			w27G90uSZsI5Cz8D = {}
			rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,I6Bfzysrvb8DONZ(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧὶ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫί"))
	if w27G90uSZsI5Cz8D: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,lRKCWnNi0Edr984eI(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩὸ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭ό"),w27G90uSZsI5Cz8D,iigI6zE7djY3yQasNTM5AW0PLOS4)
	return
def s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,source,YYTAkfz3NaQrLuCyRE,url):
	if not dU17fayKLj4kABu:
		apu7BqgDXMYhdRy38lCPUo0Wv9kA(source,YYTAkfz3NaQrLuCyRE,url)
		return
	rTnfMyoAJuXQGmtZCNgkR1j = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬὺ"))
	ScqEPIdNv4FrbfRKt2GD = w9wfONXUP3(u"ࠩ࠰ࠫύ") not in rTnfMyoAJuXQGmtZCNgkR1j
	GQAq8OnFcBve2Zi4oLH0mzNWU6hYK = WQJGuqSHelwh8inrDvBEU(dU17fayKLj4kABu[:],source)
	if GQAq8OnFcBve2Zi4oLH0mzNWU6hYK!=dU17fayKLj4kABu and not ScqEPIdNv4FrbfRKt2GD:
		SSyjzaoRvql3Gm42YuCeOkBcIn = []
		for S8VIk4HT36jKs0QzDyeUBv1h in dU17fayKLj4kABu:
			DDJ9RnKZWYSHfyLAViPG2oX,Nm3S9j4awYevPxs2qriCtT = S8VIk4HT36jKs0QzDyeUBv1h,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫὼ") in S8VIk4HT36jKs0QzDyeUBv1h: DDJ9RnKZWYSHfyLAViPG2oX,Nm3S9j4awYevPxs2qriCtT = S8VIk4HT36jKs0QzDyeUBv1h.split(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬώ"),xD9WeoEAsX7)
			Nm3S9j4awYevPxs2qriCtT = Nm3S9j4awYevPxs2qriCtT.replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭὾"),pL73X0MYajJQG4n1qgD(u"࠭ࠧ὿")).replace(hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᾀ"),nR0ok9zju84rFUQl1YC(u"ࠨࠩᾁ")).replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪᾂ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࠫᾃ"))
			SSyjzaoRvql3Gm42YuCeOkBcIn.append(Nm3S9j4awYevPxs2qriCtT)
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(zWBnYSGIatjXVC(u"ࠫส฾็ศำࠣๆํอฦๆࠢส่ั๎ฯสࠩᾄ"),SSyjzaoRvql3Gm42YuCeOkBcIn)
	dU17fayKLj4kABu = list(set(GQAq8OnFcBve2Zi4oLH0mzNWU6hYK))
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = TuW1nNR68UfQJdBEiyjcCDLrpv3(dU17fayKLj4kABu,source)
	if drzqWFkSHD.resolveonly:
		xG4LhjKI3lcYXSnw = y14nLejasfKiuHv0bVdl95kFtYP2(GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,source,pLwgjkuTs6CS)
		return
	O8WuUvZ3Fc4h91Ey,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,KNRrVFokzZx,xG4LhjKI3lcYXSnw,PLMi9UzawIq,Uz7N5KAHwQ93iShW1xj = pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
	utHmKlcz2YLGspDEyUJ5ik7aRM4PV = pLwgjkuTs6CS if source in BqoZewk2M6QW4iaRcIGTt8HJX1Aj else NFGqKBLtvUZn1S3dau
	if utHmKlcz2YLGspDEyUJ5ik7aRM4PV:
		AFqMWvdBIp86L90zYbSJ4tyQlfw = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		VrAlcDYKZQkHMjb502 = dYMLGvgfk4(mmEuUR4JdaHtAsS,pL73X0MYajJQG4n1qgD(u"ࠬࡲࡩࡴࡶࠪᾅ"),W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇࠫᾆ"))
		LLnczKN2gDh4bedOf = dYMLGvgfk4(mmEuUR4JdaHtAsS,lRKCWnNi0Edr984eI(u"ࠧ࡭࡫ࡶࡸࠬᾇ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫᾈ"))
		Zh6CXn2uBjlNR = dYMLGvgfk4(mmEuUR4JdaHtAsS,ba49YvOK2Aw8Uhxt(u"ࠩ࡯࡭ࡸࡺࠧᾉ"),pL73X0MYajJQG4n1qgD(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬᾊ"))
		u74UPEicpBdq32C = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		for title,cX2SpPxGLmADTKl in list(zip(GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF)):
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split(KKCrwPdOgGl(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᾋ"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			if cX2SpPxGLmADTKl in VrAlcDYKZQkHMjb502:
				AFqMWvdBIp86L90zYbSJ4tyQlfw += xD9WeoEAsX7
				GjC4atkJLwlTpsI[u74UPEicpBdq32C] = bb03xjXNaRDtPEoSrC8d1ZTyO+title+so4Z8OUJ5E
			elif cX2SpPxGLmADTKl in Zh6CXn2uBjlNR:
				AFqMWvdBIp86L90zYbSJ4tyQlfw += xD9WeoEAsX7
				GjC4atkJLwlTpsI[u74UPEicpBdq32C] = qFghPAi5yz9Vf3NLwo0nuprl+title+so4Z8OUJ5E
			elif cX2SpPxGLmADTKl in LLnczKN2gDh4bedOf:
				AFqMWvdBIp86L90zYbSJ4tyQlfw += xD9WeoEAsX7
				GjC4atkJLwlTpsI[u74UPEicpBdq32C] = title
			else:
				AFqMWvdBIp86L90zYbSJ4tyQlfw += xD9WeoEAsX7
				GjC4atkJLwlTpsI[u74UPEicpBdq32C] = title
			u74UPEicpBdq32C += xD9WeoEAsX7
		Uz7N5KAHwQ93iShW1xj = [oamlxBqLdu4ZM9nQrbIAhS5Pg7+CCWqR3dmtzw6xoIX41(u"ࠬ็อึࠢฯ้๏฿ࠠศๆึ๎ึ็ัศฬࠪᾌ")+so4Z8OUJ5E]
	else: PLMi9UzawIq = oamlxBqLdu4ZM9nQrbIAhS5Pg7+jBbkfIJSDqcVwl8irzy4Z3O(u"࠭รฯฬิࠤฬ๊ำ๋ำไีࠥอไๆ่สือ࠭ᾍ")+so4Z8OUJ5E
	while NFGqKBLtvUZn1S3dau:
		l0uiad5n9xYUotfkEqvrH = NFGqKBLtvUZn1S3dau
		if utHmKlcz2YLGspDEyUJ5ik7aRM4PV:
			if ScqEPIdNv4FrbfRKt2GD and len(GjC4atkJLwlTpsI)==xD9WeoEAsX7: qNmsBD1jJZVzcxi4onKuAOIC = xD9WeoEAsX7
			else:
				Jn2qFre3uvoThZ4GxRWjV = str(GjC4atkJLwlTpsI).count(bb03xjXNaRDtPEoSrC8d1ZTyO)
				RjLViznQIdG43g9ZAeBDUM = str(GjC4atkJLwlTpsI).count(qFghPAi5yz9Vf3NLwo0nuprl)
				C0zeJycTi2sjSPEhkBI7wM = len(GjC4atkJLwlTpsI)-Jn2qFre3uvoThZ4GxRWjV-RjLViznQIdG43g9ZAeBDUM
				if hT1JIgqPQsUOZp5tjCX0E: PLMi9UzawIq = qFghPAi5yz9Vf3NLwo0nuprl+f9fOpCmLAEaW2Go(u"ࠧࠡࠢࠣื๏ฬษ࠻ࠩᾎ")+str(RjLViznQIdG43g9ZAeBDUM)+so4Z8OUJ5E+zWBnYSGIatjXVC(u"ࠨࠢࠣࠤ๊า็้ๆฬ࠾ࠬᾏ")+str(C0zeJycTi2sjSPEhkBI7wM)+bb03xjXNaRDtPEoSrC8d1ZTyO+CCWqR3dmtzw6xoIX41(u"ࠩฯ๎ิฯ࠺ࠨᾐ")+str(Jn2qFre3uvoThZ4GxRWjV)+so4Z8OUJ5E
				else: PLMi9UzawIq = bb03xjXNaRDtPEoSrC8d1ZTyO+pYeVwat64v(u"ࠪะ๏ีษ࠻ࠩᾑ")+str(Jn2qFre3uvoThZ4GxRWjV)+so4Z8OUJ5E+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࠥࠦࠠๆฮ๊์้ฯ࠺ࠨᾒ")+str(C0zeJycTi2sjSPEhkBI7wM)+qFghPAi5yz9Vf3NLwo0nuprl+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࠦࠠࠡีํสฮࡀࠧᾓ")+str(RjLViznQIdG43g9ZAeBDUM)+so4Z8OUJ5E
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(PLMi9UzawIq,Uz7N5KAHwQ93iShW1xj+GjC4atkJLwlTpsI)
			if qNmsBD1jJZVzcxi4onKuAOIC==nUaVQsoA6EXcK4Odht5wCge0J8Pib:
				l0uiad5n9xYUotfkEqvrH = pLwgjkuTs6CS
				start,end = nUaVQsoA6EXcK4Odht5wCge0J8Pib,len(GjC4atkJLwlTpsI)-xD9WeoEAsX7
				xG4LhjKI3lcYXSnw = y14nLejasfKiuHv0bVdl95kFtYP2(GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,source,NFGqKBLtvUZn1S3dau)
				KNRrVFokzZx = jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࡠࡣ࡯ࡰࠬᾔ") if xG4LhjKI3lcYXSnw else pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࡯ࡱࡷࡣࡷ࡫ࡳࡰ࡮ࡹࡥࡧࡲࡥࠨᾕ")
			elif qNmsBD1jJZVzcxi4onKuAOIC>nUaVQsoA6EXcK4Odht5wCge0J8Pib: start,end = qNmsBD1jJZVzcxi4onKuAOIC-xD9WeoEAsX7,qNmsBD1jJZVzcxi4onKuAOIC-xD9WeoEAsX7
		else:
			if ScqEPIdNv4FrbfRKt2GD and len(GjC4atkJLwlTpsI)==xD9WeoEAsX7: qNmsBD1jJZVzcxi4onKuAOIC = nUaVQsoA6EXcK4Odht5wCge0J8Pib
			else: qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(PLMi9UzawIq,GjC4atkJLwlTpsI)
			start,end = qNmsBD1jJZVzcxi4onKuAOIC,qNmsBD1jJZVzcxi4onKuAOIC
		if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7:
			KNRrVFokzZx = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᾖ")
			break
		if l0uiad5n9xYUotfkEqvrH:
			KNRrVFokzZx = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࡣࡴࡴࡥࠨᾗ")
			xG4LhjKI3lcYXSnw = y14nLejasfKiuHv0bVdl95kFtYP2([GjC4atkJLwlTpsI[start]],[CBL4OQVtWbMAycUGl7Ex2SKZF[start]],source,NFGqKBLtvUZn1S3dau)
			title,cX2SpPxGLmADTKl,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms,gQBOoaMYk4z2DclsZ985wHF = xG4LhjKI3lcYXSnw[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			G4GwER6kHpBbxOi9r,fCGwWRvKjE = AAliokBNPUV8t(title,cX2SpPxGLmADTKl,p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms,source,YYTAkfz3NaQrLuCyRE)
			if G4GwER6kHpBbxOi9r in [B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨᾘ"),f9fOpCmLAEaW2Go(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬᾙ"),w9wfONXUP3(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ᾚ")]:
				O8WuUvZ3Fc4h91Ey = NFGqKBLtvUZn1S3dau
				break
			else:
				if not Oo4wEPUfp2v05kqryhlH6cBgDiMYL: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = lRKCWnNi0Edr984eI(u"࠭ࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡪࡦ࡯࡬ࡦࡦࠪᾛ")
				title = qFghPAi5yz9Vf3NLwo0nuprl+title+so4Z8OUJ5E
				xG4LhjKI3lcYXSnw[nUaVQsoA6EXcK4Odht5wCge0J8Pib] = title,cX2SpPxGLmADTKl,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms,gQBOoaMYk4z2DclsZ985wHF
				VVnBAoG3jCqLtFivYrsN = cX2SpPxGLmADTKl.split(pbmKZA1w7L4zHjOM(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᾜ"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ᾝ"),VVnBAoG3jCqLtFivYrsN)
				if pYeVwat64v(u"ࠩࡼࡳࡺࡺࡵࠨᾞ") not in url: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬᾟ"),VVnBAoG3jCqLtFivYrsN,[Oo4wEPUfp2v05kqryhlH6cBgDiMYL,title,cX2SpPxGLmADTKl],BRMcS58jIbyDQWGYLk1term)
			if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾠ"): break
			kkESeQ6FdjC8O0Z = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧᾡ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,pYeVwat64v(u"࠭࡜࡯࡝ࡏࡉࡋ࡚࡝ࠡࠢࠪᾢ")) if Oo4wEPUfp2v05kqryhlH6cBgDiMYL.count(b8sk5WyPoz03pXhRx)>jBbkfIJSDqcVwl8irzy4Z3O(u"࠴࿈") else b8sk5WyPoz03pXhRx+Oo4wEPUfp2v05kqryhlH6cBgDiMYL
			if hT1JIgqPQsUOZp5tjCX0E: kkESeQ6FdjC8O0Z = kkESeQ6FdjC8O0Z.encode(RMGz7OiD1e30P)
			if KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᾣ") not in source: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,f9fOpCmLAEaW2Go(u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࡠࡳ࠭ᾤ")+kkESeQ6FdjC8O0Z,profile=CCWqR3dmtzw6xoIX41(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧᾥ"))
			if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==xD9WeoEAsX7 and Oo4wEPUfp2v05kqryhlH6cBgDiMYL: break
		for u74UPEicpBdq32C in range(start,end+xD9WeoEAsX7):
			eavPqocjyETfC5iw = nUaVQsoA6EXcK4Odht5wCge0J8Pib if l0uiad5n9xYUotfkEqvrH else u74UPEicpBdq32C
			title,cX2SpPxGLmADTKl,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms,gQBOoaMYk4z2DclsZ985wHF = xG4LhjKI3lcYXSnw[eavPqocjyETfC5iw]
			GjC4atkJLwlTpsI[u74UPEicpBdq32C] = GjC4atkJLwlTpsI[u74UPEicpBdq32C].replace(qFghPAi5yz9Vf3NLwo0nuprl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(bb03xjXNaRDtPEoSrC8d1ZTyO,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(K1KgXSeFsx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if gQBOoaMYk4z2DclsZ985wHF==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫᾦ"): GjC4atkJLwlTpsI[u74UPEicpBdq32C] = bb03xjXNaRDtPEoSrC8d1ZTyO+GjC4atkJLwlTpsI[u74UPEicpBdq32C]+so4Z8OUJ5E
			elif gQBOoaMYk4z2DclsZ985wHF==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᾧ"): GjC4atkJLwlTpsI[u74UPEicpBdq32C] = qFghPAi5yz9Vf3NLwo0nuprl+GjC4atkJLwlTpsI[u74UPEicpBdq32C]+so4Z8OUJ5E
			else: GjC4atkJLwlTpsI[u74UPEicpBdq32C] = GjC4atkJLwlTpsI[u74UPEicpBdq32C]
	if KNRrVFokzZx==B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭ᾨ"): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKCrwPdOgGl(u"࠭ไๅลึๅ๊ࠥวࠡ์๋ะิࠦำ๋ำไีฬะࠠอ์าอࠥ็๊้ࠡำหࠥอไโ์า๎ํࠦ࠮࠯ࠢะหํ๊ࠠฤ่ࠣฮอำหࠡ฻้ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎๋่ࠥศไ฼ࠤศิั๊ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠫᾩ"))
	if not O8WuUvZ3Fc4h91Ey or KNRrVFokzZx in [pbmKZA1w7L4zHjOM(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩᾪ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩᾫ")] or Oo4wEPUfp2v05kqryhlH6cBgDiMYL:
		dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(lRKCWnNi0Edr984eI(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩᾬ"))
	return
def y14nLejasfKiuHv0bVdl95kFtYP2(lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu,source,showDialogs):
	global HZiSat0FTLvb,zASB0M1NCQgOq,ppNqtWiy41Bv6lh8dJazXC,GGkwxjid61SK,jqdcmXhDbUGYw94u8enxSl6PyW2tr7,rIcSGCwpZLHh1
	HZiSat0FTLvb,zASB0M1NCQgOq,ppNqtWiy41Bv6lh8dJazXC,GGkwxjid61SK = [],[],[],[]
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7,rIcSGCwpZLHh1 = [],[]
	Ubud2NhHKRnMTvI5mprQBVqk80,dJqjUga8mCMs7LV15tOiNGDBfHyx,new = [],[],[]
	zCtB6lUJjnOcHibaErDuP2xGf(OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh,OoTt1Fqj6pYCX25ZI8WLMvnf94Uh)
	count = len(dU17fayKLj4kABu)
	for OOWFun1mZvjJIiKlRSQgT624 in range(count):
		HZiSat0FTLvb.append(rrpMTe0FZlXBkD6jJfsKPboWhVd9)
		zASB0M1NCQgOq.append(rrpMTe0FZlXBkD6jJfsKPboWhVd9)
		ppNqtWiy41Bv6lh8dJazXC.append(rrpMTe0FZlXBkD6jJfsKPboWhVd9)
		GGkwxjid61SK.append(rrpMTe0FZlXBkD6jJfsKPboWhVd9)
		jqdcmXhDbUGYw94u8enxSl6PyW2tr7.append(rrpMTe0FZlXBkD6jJfsKPboWhVd9)
		rIcSGCwpZLHh1.append(nUaVQsoA6EXcK4Odht5wCge0J8Pib)
		title = lFL9QtV2u1pa7WoieSmv3YzZPb[OOWFun1mZvjJIiKlRSQgT624]
		cX2SpPxGLmADTKl = dU17fayKLj4kABu[OOWFun1mZvjJIiKlRSQgT624].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(I6Bfzysrvb8DONZ(u"ࠪࠪࠬᾭ")).strip(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡄ࠭ᾮ")).strip(YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࠵ࠧᾯ"))
		if count>xD9WeoEAsX7 and showDialogs: ARL0tsEeanKImhMByugPTvX7(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭แฮืࠣื๏ืแาࠢิๆ๊ࠦࠠࠨᾰ")+str(OOWFun1mZvjJIiKlRSQgT624+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠳࿉")),title)
		boKNGQ1zBuO9Pr = [Zb5cNeHWi6jP9SCYtUgR(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᾱ"),pL73X0MYajJQG4n1qgD(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ᾲ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡄࡏ࡜ࡇࡍࠨᾳ")]
		if source in boKNGQ1zBuO9Pr: jqdcmXhDbUGYw94u8enxSl6PyW2tr7[OOWFun1mZvjJIiKlRSQgT624] = IftxnzVPlHgL(title,cX2SpPxGLmADTKl,source,OOWFun1mZvjJIiKlRSQgT624,NFGqKBLtvUZn1S3dau)
		else:
			if xD9WeoEAsX7:
				LsXq3DOdhm6jTAB4lWbN = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=IftxnzVPlHgL,args=(title,cX2SpPxGLmADTKl,source,OOWFun1mZvjJIiKlRSQgT624,count==YzlId3Fs6vpehcbLGj0UaO(u"࠴࿊")))
				dJqjUga8mCMs7LV15tOiNGDBfHyx.append(LsXq3DOdhm6jTAB4lWbN)
				new.append(OOWFun1mZvjJIiKlRSQgT624)
	def eKbtsxMT36pPDlYiXghUn():
		SaslN5qm6KdOWp7DCTwMJt014EQ = pLwgjkuTs6CS
		for cX2SpPxGLmADTKl in jqdcmXhDbUGYw94u8enxSl6PyW2tr7:
			if not cX2SpPxGLmADTKl: break
		else: SaslN5qm6KdOWp7DCTwMJt014EQ = NFGqKBLtvUZn1S3dau
		Jh3fArxWiMwNURO6kymPuGCTeta = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player().isPlaying() if drzqWFkSHD.resolveonly else NFGqKBLtvUZn1S3dau
		return SaslN5qm6KdOWp7DCTwMJt014EQ or not Jh3fArxWiMwNURO6kymPuGCTeta
	cxOYt1zLJqdR(dJqjUga8mCMs7LV15tOiNGDBfHyx,ssfq3KzCgrA1Wh,hctuin9mF4xl81gT0CaNskqp6LbJW,xD9WeoEAsX7,eKbtsxMT36pPDlYiXghUn)
	for OOWFun1mZvjJIiKlRSQgT624 in range(count):
		title = lFL9QtV2u1pa7WoieSmv3YzZPb[OOWFun1mZvjJIiKlRSQgT624]
		cX2SpPxGLmADTKl = dU17fayKLj4kABu[OOWFun1mZvjJIiKlRSQgT624].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠪࠬᾴ")).strip(YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡄ࠭᾵")).strip(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࠵ࠧᾶ"))
		VVnBAoG3jCqLtFivYrsN = cX2SpPxGLmADTKl.split(pL73X0MYajJQG4n1qgD(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᾷ"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib] if OOWFun1mZvjJIiKlRSQgT624 in new else pLwgjkuTs6CS
		stream = jqdcmXhDbUGYw94u8enxSl6PyW2tr7[OOWFun1mZvjJIiKlRSQgT624]
		if stream and not stream[nUaVQsoA6EXcK4Odht5wCge0J8Pib] and stream[H3OKMjDG1evnl4Ruiz]:
			gQBOoaMYk4z2DclsZ985wHF = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨᾸ")
			kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL = stream
			if VVnBAoG3jCqLtFivYrsN: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,kAz7WRYjrfGm(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭Ᾱ"),VVnBAoG3jCqLtFivYrsN,[kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL],BRMcS58jIbyDQWGYLk1term)
		elif stream and stream[nUaVQsoA6EXcK4Odht5wCge0J8Pib] and not stream[xD9WeoEAsX7] and not stream[H3OKMjDG1evnl4Ruiz]:
			gQBOoaMYk4z2DclsZ985wHF = pbmKZA1w7L4zHjOM(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪᾺ")
			kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤ࡝ࡰࠪΆ")+stream[nUaVQsoA6EXcK4Odht5wCge0J8Pib],[],[]
			if VVnBAoG3jCqLtFivYrsN: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,KKCrwPdOgGl(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭ᾼ"),VVnBAoG3jCqLtFivYrsN,[kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL],BRMcS58jIbyDQWGYLk1term)
		elif rIcSGCwpZLHh1[OOWFun1mZvjJIiKlRSQgT624]+xD9WeoEAsX7>Gz82dDr4wN5UHLTak9b631v7Y:
			gQBOoaMYk4z2DclsZ985wHF = pYeVwat64v(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭᾽")
			kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡹ࡯࡭ࡦࡦࠣࡳࡺࡺࠠࠩࠩι")+str(rIcSGCwpZLHh1[OOWFun1mZvjJIiKlRSQgT624])+w9wfONXUP3(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪ᾿"),[],[]
			if VVnBAoG3jCqLtFivYrsN: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,nR0ok9zju84rFUQl1YC(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ῀"),VVnBAoG3jCqLtFivYrsN,[kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL],BRMcS58jIbyDQWGYLk1term)
		elif not stream:
			gQBOoaMYk4z2DclsZ985wHF = pbmKZA1w7L4zHjOM(u"ࠩࡦࡥࡳࡩࡥ࡭ࠩ῁")
			kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠪῂ"),[],[]
			if VVnBAoG3jCqLtFivYrsN: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧῃ"),VVnBAoG3jCqLtFivYrsN,[kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL],BRMcS58jIbyDQWGYLk1term)
		else:
			gQBOoaMYk4z2DclsZ985wHF = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ῄ")
			kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL = I6Bfzysrvb8DONZ(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡵࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡸࡶࡪ࠭῅"),[],[]
			if VVnBAoG3jCqLtFivYrsN: JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪῆ"),VVnBAoG3jCqLtFivYrsN,[kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL],BRMcS58jIbyDQWGYLk1term)
		Ubud2NhHKRnMTvI5mprQBVqk80.append([title,cX2SpPxGLmADTKl,kkESeQ6FdjC8O0Z,uoH6T37WPfCdv8JLnYZjK2r,evGVuBpQUEL,gQBOoaMYk4z2DclsZ985wHF])
	zCtB6lUJjnOcHibaErDuP2xGf(btR0Zix9D2g,btR0Zix9D2g,btR0Zix9D2g)
	return Ubud2NhHKRnMTvI5mprQBVqk80
def IftxnzVPlHgL(LLzkoiPsbBZ,url,source,BO1DGbpgSfCz,lIU14VZxNK9cbruQ7keEH):
	global jqdcmXhDbUGYw94u8enxSl6PyW2tr7,rIcSGCwpZLHh1
	rIcSGCwpZLHh1[BO1DGbpgSfCz] = nUaVQsoA6EXcK4Odht5wCge0J8Pib
	YA8zxD2L9ielGsFuIW4vh = f7epsRlYtMz4.time()
	UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+f9fOpCmLAEaW2Go(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩῇ")+LLzkoiPsbBZ+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ὲ")+url+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࠤࡢ࠭Έ"))
	cX2SpPxGLmADTKl,gf7yYnKb9M3IXr2ULBsq = url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	lWZtu4JFEk = f9fOpCmLAEaW2Go(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨῊ")
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = oPb0IBWrL8jvhXROUJaC(url,source)
	if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==rAYDiWlzm9MCU6x0GnROua(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪΉ"):
		jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῌ"),[],[]
		rIcSGCwpZLHh1[BO1DGbpgSfCz] = f7epsRlYtMz4.time()-YA8zxD2L9ielGsFuIW4vh
		return jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz]
	elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ῍") in Oo4wEPUfp2v05kqryhlH6cBgDiMYL:
		gf7yYnKb9M3IXr2ULBsq = ba49YvOK2Aw8Uhxt(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥ࠮࠲࠮࠷ࠬࠫ῎")
		cX2SpPxGLmADTKl = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		lWZtu4JFEk,gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = xNLYwZCyVhIus(gf7yYnKb9M3IXr2ULBsq,cX2SpPxGLmADTKl,source,BO1DGbpgSfCz)
		if gf7yYnKb9M3IXr2ULBsq==pYeVwat64v(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ῏"):
			jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
			rIcSGCwpZLHh1[BO1DGbpgSfCz] = f7epsRlYtMz4.time()-YA8zxD2L9ielGsFuIW4vh
			return gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	elif Oo4wEPUfp2v05kqryhlH6cBgDiMYL: gf7yYnKb9M3IXr2ULBsq = f9fOpCmLAEaW2Go(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪῐ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)[:zWBnYSGIatjXVC(u"࠼࠵࿋")]
	if CBL4OQVtWbMAycUGl7Ex2SKZF:
		CBL4OQVtWbMAycUGl7Ex2SKZF = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)
		UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧῑ")+LLzkoiPsbBZ+nR0ok9zju84rFUQl1YC(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩῒ")+lWZtu4JFEk+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪΐ")+url+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ῔")+cX2SpPxGLmADTKl+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࠢࡠࠤ࡙ࠥࠦࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭῕")+str(CBL4OQVtWbMAycUGl7Ex2SKZF)+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࠣࡡࠬῖ"))
	else:
		KBa4HTd5kDLjtN = nR0ok9zju84rFUQl1YC(u"ࠪࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪῗ")+gf7yYnKb9M3IXr2ULBsq+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࠥࡣࠧῘ") if lIU14VZxNK9cbruQ7keEH else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if hT1JIgqPQsUOZp5tjCX0E: KBa4HTd5kDLjtN = KBa4HTd5kDLjtN.encode(RMGz7OiD1e30P)
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+I6Bfzysrvb8DONZ(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬῙ")+LLzkoiPsbBZ+vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪῚ")+url+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧΊ")+cX2SpPxGLmADTKl+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࠢࡠࠫ῜")+KBa4HTd5kDLjtN)
	gf7yYnKb9M3IXr2ULBsq = WDg18QHF3rze(gf7yYnKb9M3IXr2ULBsq)
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	rIcSGCwpZLHh1[BO1DGbpgSfCz] = f7epsRlYtMz4.time()-YA8zxD2L9ielGsFuIW4vh
	return gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def AAliokBNPUV8t(title,cX2SpPxGLmADTKl,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,source,YYTAkfz3NaQrLuCyRE=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if CBL4OQVtWbMAycUGl7Ex2SKZF:
		if not GjC4atkJLwlTpsI[nUaVQsoA6EXcK4Odht5wCge0J8Pib]: GjC4atkJLwlTpsI = CBL4OQVtWbMAycUGl7Ex2SKZF
		rTnfMyoAJuXQGmtZCNgkR1j = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭῝"))
		ScqEPIdNv4FrbfRKt2GD = lRKCWnNi0Edr984eI(u"ࠪ࠱ࠬ῞") not in rTnfMyoAJuXQGmtZCNgkR1j
		while NFGqKBLtvUZn1S3dau:
			if ScqEPIdNv4FrbfRKt2GD and len(CBL4OQVtWbMAycUGl7Ex2SKZF)==xD9WeoEAsX7: qNmsBD1jJZVzcxi4onKuAOIC = nUaVQsoA6EXcK4Odht5wCge0J8Pib
			else: qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ῟"),GjC4atkJLwlTpsI)
			if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: vv52HizJKaC = rAYDiWlzm9MCU6x0GnROua(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧῠ")
			else:
				MaTnYEG1WSq2beJAFNxrKtOHoIiZ = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
				UO05pib6mcvezR9(HHTRECw16nOjQcp79vL3mi24BfJ,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+f9fOpCmLAEaW2Go(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬῡ")+title+GTmHXIZUSdxRhMnqQKkO(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫῢ")+cX2SpPxGLmADTKl+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩΰ")+str(MaTnYEG1WSq2beJAFNxrKtOHoIiZ)+lRKCWnNi0Edr984eI(u"ࠩࠣࡡࠬῤ"))
				if pL73X0MYajJQG4n1qgD(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭ῥ") in MaTnYEG1WSq2beJAFNxrKtOHoIiZ and GTmHXIZUSdxRhMnqQKkO(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫῦ") in MaTnYEG1WSq2beJAFNxrKtOHoIiZ:
					kkESeQ6FdjC8O0Z,Uyb6AW5FflmEDXSa0scj,O0wTRBaWzSFf8IitYo5CmEgy = mWqNB5Y9MPRj4UIuQoxzLE(MaTnYEG1WSq2beJAFNxrKtOHoIiZ)
					if O0wTRBaWzSFf8IitYo5CmEgy: MaTnYEG1WSq2beJAFNxrKtOHoIiZ = O0wTRBaWzSFf8IitYo5CmEgy[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
					else: MaTnYEG1WSq2beJAFNxrKtOHoIiZ = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				if not MaTnYEG1WSq2beJAFNxrKtOHoIiZ: vv52HizJKaC = f9fOpCmLAEaW2Go(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩῧ")
				else: vv52HizJKaC = ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(MaTnYEG1WSq2beJAFNxrKtOHoIiZ,source,YYTAkfz3NaQrLuCyRE)
			if vv52HizJKaC in [pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧῨ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨῩ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭Ὺ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫΎ")] or len(CBL4OQVtWbMAycUGl7Ex2SKZF)==YzlId3Fs6vpehcbLGj0UaO(u"࠶࿌"): break
			elif vv52HizJKaC in [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪῬ"),ba49YvOK2Aw8Uhxt(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ῭"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡺࡲࡪࡧࡧࠫ΅")]: break
			else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ`"))
	else:
		vv52HizJKaC = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ῰")
		if azP0kLi9Uc6(cX2SpPxGLmADTKl): vv52HizJKaC = ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(cX2SpPxGLmADTKl,source,YYTAkfz3NaQrLuCyRE)
	return vv52HizJKaC,CBL4OQVtWbMAycUGl7Ex2SKZF
def h46JK3E1HzWQDTSdcBsPlo0x(url,source):
	nUDgc4absePT2xMt,ZZgiBLKqHNawYsTktI4,LLzkoiPsbBZ,U67ILi5O4PKQzSEFRt,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE = url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if pbmKZA1w7L4zHjOM(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ῱") in url:
		nUDgc4absePT2xMt,ZZgiBLKqHNawYsTktI4 = url.split(pYeVwat64v(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪῲ"),xD9WeoEAsX7)
		ZZgiBLKqHNawYsTktI4 = ZZgiBLKqHNawYsTktI4+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡣࡤ࠭ῳ")+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡤࡥࠧῴ")+lRKCWnNi0Edr984eI(u"ࠬࡥ࡟ࠨ῵")+pL73X0MYajJQG4n1qgD(u"࠭࡟ࡠࠩῶ")+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡠࡡࠪῷ")
		usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE,nHhfjIMTielYsUFda0CA8zRqN = ZZgiBLKqHNawYsTktI4.split(W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡡࡢࠫῸ"))[:pYeVwat64v(u"࠼࿍")]
	if not XcvFdKRjNLz5wEpDf: XcvFdKRjNLz5wEpDf = YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࠳ࠫΌ")
	else: XcvFdKRjNLz5wEpDf = XcvFdKRjNLz5wEpDf.replace(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡴࠬῺ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	nUDgc4absePT2xMt = nUDgc4absePT2xMt.strip(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡄ࠭Ώ")).strip(KKCrwPdOgGl(u"ࠬ࠵ࠧῼ")).strip(YzlId3Fs6vpehcbLGj0UaO(u"࠭ࠦࠨ´"))
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࡩࡱࡶࡸࠬ῾"))
	if usYnJBXhFT: U67ILi5O4PKQzSEFRt = usYnJBXhFT
	else: U67ILi5O4PKQzSEFRt = LLzkoiPsbBZ
	U67ILi5O4PKQzSEFRt = UUmYkruGeM3p8sKi6o2fcI(U67ILi5O4PKQzSEFRt,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡰࡤࡱࡪ࠭῿"))
	usYnJBXhFT = usYnJBXhFT.replace(I6Bfzysrvb8DONZ(u"๊ࠫฮวีำࠪࠀ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(CCWqR3dmtzw6xoIX41(u"ู๊ࠬาใิࠫࠁ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(rAYDiWlzm9MCU6x0GnROua(u"࠭วๅࠢࠪࠂ"),WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	ZZgiBLKqHNawYsTktI4 = ZZgiBLKqHNawYsTktI4.replace(YzlId3Fs6vpehcbLGj0UaO(u"ࠧๆสสุึ࠭ࠃ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(f9fOpCmLAEaW2Go(u"ࠨีํีๆืࠧࠄ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(pYeVwat64v(u"ࠩส่ࠥ࠭ࠅ"),WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	U67ILi5O4PKQzSEFRt = U67ILi5O4PKQzSEFRt.replace(lRKCWnNi0Edr984eI(u"้ࠪออิาࠩࠆ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(rAYDiWlzm9MCU6x0GnROua(u"ุࠫ๐ัโำࠪࠇ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(rAYDiWlzm9MCU6x0GnROua(u"ࠬอไࠡࠩࠈ"),WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	return nUDgc4absePT2xMt,ZZgiBLKqHNawYsTktI4,LLzkoiPsbBZ,U67ILi5O4PKQzSEFRt,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE
def MhvGoSeVYlZRNXB(url,source):
	tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,IHOLEVq7vF6teWcfQNPX28,Eczya1tZHoTFlkC85JM,Rfbzr2g5W8hjCxZOuNm,Nm3S9j4awYevPxs2qriCtT,lWZtu4JFEk = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rrpMTe0FZlXBkD6jJfsKPboWhVd9,rrpMTe0FZlXBkD6jJfsKPboWhVd9,rrpMTe0FZlXBkD6jJfsKPboWhVd9,rrpMTe0FZlXBkD6jJfsKPboWhVd9,rrpMTe0FZlXBkD6jJfsKPboWhVd9
	nUDgc4absePT2xMt,ZZgiBLKqHNawYsTktI4,LLzkoiPsbBZ,U67ILi5O4PKQzSEFRt,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE = h46JK3E1HzWQDTSdcBsPlo0x(url,source)
	if rAYDiWlzm9MCU6x0GnROua(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠉ") in url:
		if   YYTAkfz3NaQrLuCyRE==nR0ok9zju84rFUQl1YC(u"ࠧࡦ࡯ࡥࡩࡩ࠭ࠊ"): YYTAkfz3NaQrLuCyRE = WRsuxHTjDgYCIpoMQzLFAtS8rikP+pbmKZA1w7L4zHjOM(u"ࠨ็ไฺ้࠭ࠋ")
		elif YYTAkfz3NaQrLuCyRE==B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡺࡥࡹࡩࡨࠨࠌ"): YYTAkfz3NaQrLuCyRE = WRsuxHTjDgYCIpoMQzLFAtS8rikP+pbmKZA1w7L4zHjOM(u"ฺ๊ࠪࠩว่ัฬࠫࠍ")
		elif YYTAkfz3NaQrLuCyRE==B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡧࡵࡴࡩࠩࠎ"): YYTAkfz3NaQrLuCyRE = WRsuxHTjDgYCIpoMQzLFAtS8rikP+KKCrwPdOgGl(u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧࠏ")
		elif YYTAkfz3NaQrLuCyRE==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨࠐ"): YYTAkfz3NaQrLuCyRE = WRsuxHTjDgYCIpoMQzLFAtS8rikP+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࠦࠧࠨฮา๋๊ๅࠩࠑ")
		elif YYTAkfz3NaQrLuCyRE==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: YYTAkfz3NaQrLuCyRE = WRsuxHTjDgYCIpoMQzLFAtS8rikP+nR0ok9zju84rFUQl1YC(u"ࠨࠧࠨࠩࠪ࠭ࠒ")
		if kw7O9B5fZceYAn0RbNtL!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			if pYeVwat64v(u"ࠩࡰࡴ࠹࠭ࠓ") not in kw7O9B5fZceYAn0RbNtL: kw7O9B5fZceYAn0RbNtL = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࠩࠬࠔ")+kw7O9B5fZceYAn0RbNtL
			kw7O9B5fZceYAn0RbNtL = WRsuxHTjDgYCIpoMQzLFAtS8rikP+kw7O9B5fZceYAn0RbNtL
		if XcvFdKRjNLz5wEpDf!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			XcvFdKRjNLz5wEpDf = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧࠕ")+XcvFdKRjNLz5wEpDf
			XcvFdKRjNLz5wEpDf = WRsuxHTjDgYCIpoMQzLFAtS8rikP+XcvFdKRjNLz5wEpDf[-pL73X0MYajJQG4n1qgD(u"࠹࿎"):]
	if   Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡇࡋࡐࡃࡐࠫࠖ")		in source: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif w9wfONXUP3(u"࠭ࡁࡌ࡙ࡄࡑࠬࠗ")		in source and KKCrwPdOgGl(u"ࠧࡕࡗࡅࡉࠬ࠘") not in source: IHOLEVq7vF6teWcfQNPX28	= jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡣ࡮ࡻࡦࡳࠧ࠙")
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫࠚ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩࠛ")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ࠜ")		in source: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif KKCrwPdOgGl(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬࠝ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡦࡢࡵࡨࡰࠬࠞ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡵ࠹ࡰࡩࡪࡲࠧࠟ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif I6Bfzysrvb8DONZ(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨࠠ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫࠡ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫࠢ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif kAz7WRYjrfGm(u"ࠫ࡫ࡧࡪࡦࡴࠪࠣ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif I6Bfzysrvb8DONZ(u"ࠬ็ฬาࠩࠤ")			in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= zWBnYSGIatjXVC(u"࠭ࡦࡢ࡬ࡨࡶࠬࠥ")
	elif pbmKZA1w7L4zHjOM(u"ࠧโๆึ฻๏์ࠧࠦ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡲࡤࡰࡪࡹࡴࡪࡰࡨࠫࠧ")
	elif ba49YvOK2Aw8Uhxt(u"ࠩࡪࡨࡷ࡯ࡶࡦࠩࠨ")		in nUDgc4absePT2xMt:   IHOLEVq7vF6teWcfQNPX28	= bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪࠩ")
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡲࡿࡣࡪ࡯ࡤࠫࠪ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡽࡥࡤ࡫ࡰࡥࠬࠫ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧࠬ")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ࠭")		in usYnJBXhFT:   IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭࠮")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif lRKCWnNi0Edr984eI(u"ࠩࡥࡳࡰࡸࡡࠨ࠯")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡸࡻ࡬ࡵ࡯ࠩ࠰")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif KKCrwPdOgGl(u"ࠫࡹࡼ࡫ࡴࡣࠪ࠱")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭࠲")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif pbmKZA1w7L4zHjOM(u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ࠳")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif I6Bfzysrvb8DONZ(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ࠴")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif kAz7WRYjrfGm(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ࠵")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ࠶")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ࠷")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif hWRvZOYtjme9QNnV41u0Mswb(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭࠸")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif CCWqR3dmtzw6xoIX41(u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ࠹")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡲࡦࡦࡰࡳࡩࡾࠧ࠺")	 	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= kAz7WRYjrfGm(u"ࠧࡳࡧࡧࡱࡴࡪࡸࠨ࠻")
	elif vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡻࡲࡹࡹࡻࠧ࠼")	 	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= GTmHXIZUSdxRhMnqQKkO(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ࠽")
	elif pYeVwat64v(u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ࠾")	 	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= CCWqR3dmtzw6xoIX41(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ࠿")
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠬ࡫ࡧࡺ࠯ࡥࡩࡸࡺ࠮࡯ࡧࡷࠫࡀ")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= U67ILi5O4PKQzSEFRt
	elif Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫࡁ")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= pL73X0MYajJQG4n1qgD(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫࡂ")
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪࡃ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫࡄ")
	elif pL73X0MYajJQG4n1qgD(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫࡅ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= I6Bfzysrvb8DONZ(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ࡆ")
	elif lRKCWnNi0Edr984eI(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧࡇ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨࡈ")
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ࡉ")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= zWBnYSGIatjXVC(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧࡊ")
	elif ba49YvOK2Aw8Uhxt(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬࡋ")	in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= GTmHXIZUSdxRhMnqQKkO(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯ࠪࡌ")
	elif ba49YvOK2Aw8Uhxt(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬࡍ")		in LLzkoiPsbBZ: IHOLEVq7vF6teWcfQNPX28	= MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ࡎ")
	elif kAz7WRYjrfGm(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩࡏ")	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪࡐ")
	elif pYeVwat64v(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩࡑ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪࡒ")
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬࡓ")	 	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡨࡧࡴࡤࡪࠪࡔ")
	elif KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭ࡕ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= pbmKZA1w7L4zHjOM(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧࡖ")
	elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡷ࡫ࡧࡦࡲ࠭ࡗ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= rAYDiWlzm9MCU6x0GnROua(u"ࠨࡸ࡬ࡨࡧࡳࠧࡘ")
	elif KKCrwPdOgGl(u"ࠩࡹ࡭ࡩ࡮ࡤࠨ࡙")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡱࡾࡼࡩࡥ࡚ࠩ")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif nR0ok9zju84rFUQl1YC(u"ࠫࡲࡿࡶࡪ࡫ࡧ࡛ࠫ")		in LLzkoiPsbBZ: Nm3S9j4awYevPxs2qriCtT	= U67ILi5O4PKQzSEFRt
	elif slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ࡜")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ࡝")
	elif KKCrwPdOgGl(u"ࠧࡨࡱࡹ࡭ࡩ࠭࡞")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡩࡲࡺ࡮ࡪࠧ࡟")
	elif pYeVwat64v(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫࡠ") 	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬࡡ")
	elif hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧࡢ")	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨࡣ")
	elif vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫࡤ")	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬࡥ")
	elif CCWqR3dmtzw6xoIX41(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬࡦ") 	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ࡧ")
	elif KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫࡨ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= kAz7WRYjrfGm(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬࡩ")
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡻࡰࡱࠩࡪ") 			in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= pYeVwat64v(u"࠭ࡵࡱࡤࡲࡱࠬ࡫")
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡶࡲࡥࠫ࡬") 			in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡷࡳࡦࡴࡳࠧ࡭")
	elif Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡸࡵࡱࡵࡡࡥࠩ࡮") 		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ࡯")
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡻࡱࠧࡰ") 			in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡼ࡫ࠨࡱ")
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨࡲ") 	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= lRKCWnNi0Edr984eI(u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩࡳ")
	elif zWBnYSGIatjXVC(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨࡴ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩࡵ")
	elif fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪࡶ") 		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫࡷ")
	elif pYeVwat64v(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩࡸ") 	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪࡹ")
	elif KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫࡺ")	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬࡻ")
	elif I6Bfzysrvb8DONZ(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭ࡼ")	in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧࡽ")
	elif awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫࡾ")		in LLzkoiPsbBZ: Eczya1tZHoTFlkC85JM	= ba49YvOK2Aw8Uhxt(u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬࡿ")
	if   IHOLEVq7vF6teWcfQNPX28:	tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ฮศืࠪࢀ"),IHOLEVq7vF6teWcfQNPX28
	elif Nm3S9j4awYevPxs2qriCtT:		tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = w9wfONXUP3(u"ࠧࠦ็ะำิ࠭ࢁ"),Nm3S9j4awYevPxs2qriCtT
	elif Eczya1tZHoTFlkC85JM:		tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = pYeVwat64v(u"ࠨࠧࠨ฽ฬ๋ࠠๆ฻ิ์ๆ࠭ࢂ"),Eczya1tZHoTFlkC85JM
	elif Rfbzr2g5W8hjCxZOuNm:	tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࠨࠩࠪ฿วๆࠢัหึา๊ࠨࢃ"),Rfbzr2g5W8hjCxZOuNm
	elif lWZtu4JFEk:	tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = djapWhrveLJbgnViDftFNY05ylq1S(u"ฺࠪࠩࠪࠫࠥษ่ࠤำอัอ์ࠪࢄ"),U67ILi5O4PKQzSEFRt
	else:			tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT = awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࠪࠫࠥࠦࠧ฼ห๊ࠦๅอ้๋่ࠬࢅ"),U67ILi5O4PKQzSEFRt
	return tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf
def FyXbagjkG1Zz62nTxwOoEl7HPASI4(Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF):
	p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms = [],[]
	for title,cX2SpPxGLmADTKl in list(zip(GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF)):
		if azP0kLi9Uc6(cX2SpPxGLmADTKl):
			p3USGyZE9bKVhvjtd4W0.append(title)
			BA01W9olieErLycV7kwFvOhH5Y3ms.append(cX2SpPxGLmADTKl)
	if not BA01W9olieErLycV7kwFvOhH5Y3ms and not Oo4wEPUfp2v05kqryhlH6cBgDiMYL: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡌࡡࡪ࡮ࡨࡨࠬࢆ")
	return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,p3USGyZE9bKVhvjtd4W0,BA01W9olieErLycV7kwFvOhH5Y3ms
def oPb0IBWrL8jvhXROUJaC(url,source):
	nUDgc4absePT2xMt,Nm3S9j4awYevPxs2qriCtT,LLzkoiPsbBZ,U67ILi5O4PKQzSEFRt,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE = h46JK3E1HzWQDTSdcBsPlo0x(url,source)
	if   awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡹࡰࡷࡷࡹࠬࢇ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = zWBnYSGIatjXVC(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࢈"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	elif hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨࢉ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢊ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡥࡱࡨࡡࡱ࡮ࡤࡽࡪࡸࠧࢋ")	in nUDgc4absePT2xMt  : Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = XlBeCa6vgwprDAPW(nUDgc4absePT2xMt)
	elif pL73X0MYajJQG4n1qgD(u"ࠫࡆࡑࡏࡂࡏࠪࢌ")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = gCTbXtFaP3(nUDgc4absePT2xMt,usYnJBXhFT)
	elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡇࡋࡘࡃࡐࠫࢍ")		in source and I6Bfzysrvb8DONZ(u"࠭ࡔࡖࡄࡈࠫࢎ") not in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = R7N1PDkgeU(nUDgc4absePT2xMt,YYTAkfz3NaQrLuCyRE,XcvFdKRjNLz5wEpDf)
	elif ba49YvOK2Aw8Uhxt(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ࢏")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = mqdUQ5u6WB(nUDgc4absePT2xMt)
	elif W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ࢐")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = FWRKQzeu9U(nUDgc4absePT2xMt)
	elif nR0ok9zju84rFUQl1YC(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ࢑")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࢒"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ࢓")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = uU93MkwA62(nUDgc4absePT2xMt)
	elif KKCrwPdOgGl(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ࢔")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = LAbTHG0nuF(nUDgc4absePT2xMt)
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ࢕")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = IwmHi9nSTN(nUDgc4absePT2xMt)
	elif w9wfONXUP3(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ࢖")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = jjpsiGUNBv(nUDgc4absePT2xMt)
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠨࡕࡋࡓࡋࡎࡁࠨࢗ")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = q3t4Yg9mhf(nUDgc4absePT2xMt,YYTAkfz3NaQrLuCyRE,Nm3S9j4awYevPxs2qriCtT)
	elif jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ࢘")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = PXcpvrS3Vd(nUDgc4absePT2xMt,YVbC0fFvJRDSZLlc1w7ojzE)
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡐࡆࡘࡏ࡛ࡃ࢙ࠪ")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = o0m83SXWTh(nUDgc4absePT2xMt)
	elif bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࢚ࠬ")		in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = yVma6J7eNE(nUDgc4absePT2xMt)
	elif w9wfONXUP3(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࢛ࠩ")	in source: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = CIyMfY4RsL(nUDgc4absePT2xMt)
	elif GTmHXIZUSdxRhMnqQKkO(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ࢜")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = zft9XpDrAq(nUDgc4absePT2xMt)
	elif KKCrwPdOgGl(u"ࠧࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ࢝")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = BHmc05rURM(nUDgc4absePT2xMt)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ࢞")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = eRsm5xYk7q(nUDgc4absePT2xMt)
	elif nR0ok9zju84rFUQl1YC(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ࢟")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = uF1nZJ3EDU(nUDgc4absePT2xMt)
	elif lRKCWnNi0Edr984eI(u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬࢠ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = uF1nZJ3EDU(nUDgc4absePT2xMt)
	elif Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫࢡ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = O1n8Lz7f0a(nUDgc4absePT2xMt)
	elif lRKCWnNi0Edr984eI(u"ࠬࡺࡶࡧࡷࡱࠫࢢ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = m8RtQjSNGX(nUDgc4absePT2xMt)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡴࡷ࡭ࡶࡥࠬࢣ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = m8RtQjSNGX(nUDgc4absePT2xMt)
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠧࡵࡸ࠰ࡪ࠳ࡩ࡯࡮ࠩࢤ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = m8RtQjSNGX(nUDgc4absePT2xMt)
	elif CCWqR3dmtzw6xoIX41(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪࢥ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = I3TDYBFSvE(nUDgc4absePT2xMt)
	elif zWBnYSGIatjXVC(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫࢦ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = dxz8NlGe5E(nUDgc4absePT2xMt)
	elif ba49YvOK2Aw8Uhxt(u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬࢧ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = J7JBxon2wby5aYZ3RF4zXPl(nUDgc4absePT2xMt)
	elif vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡻࡹ࠴ࡶࠩࢨ")			in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = lwfZ8vtTFM(nUDgc4absePT2xMt)
	elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࡬ࡡ࡫ࡧࡵࠫࢩ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = Mt2bPXUIwJ(nUDgc4absePT2xMt)
	elif CCWqR3dmtzw6xoIX41(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧࢪ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = NWaJvRzG5C(nUDgc4absePT2xMt)
	elif YzlId3Fs6vpehcbLGj0UaO(u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨࢫ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = NWaJvRzG5C(nUDgc4absePT2xMt)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡥ࡬ࡱࡦ࠳࡬ࡪࡩ࡫ࡸࠬࢬ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = udzGthVKnl(nUDgc4absePT2xMt)
	elif GTmHXIZUSdxRhMnqQKkO(u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬࢭ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = udzGthVKnl(nUDgc4absePT2xMt)
	elif pL73X0MYajJQG4n1qgD(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪࢮ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = jjC6fFzkVI(nUDgc4absePT2xMt)
	elif slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫࢯ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VJXZc6qF1u(nUDgc4absePT2xMt)
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡨ࡯࡬ࡴࡤࠫࢰ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = ooptheiadS(nUDgc4absePT2xMt)
	elif zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫࢱ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = NNY0DyduVf(nUDgc4absePT2xMt)
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩࢲ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = IR68ycjAWQ(nUDgc4absePT2xMt)
	elif nR0ok9zju84rFUQl1YC(u"ࠨࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧࢳ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = ooBbhVisp7(nUDgc4absePT2xMt)
	elif slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧࢴ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	elif pbmKZA1w7L4zHjOM(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫࢵ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = FlPMyQw5G4(nUDgc4absePT2xMt)
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠪࢶ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = qO0jx34NUh(nUDgc4absePT2xMt)
	elif pYeVwat64v(u"ࠬࡻࡰࡣࡣࡰࠫࢷ") 		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	else: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢸ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	if not Oo4wEPUfp2v05kqryhlH6cBgDiMYL and not CBL4OQVtWbMAycUGl7Ex2SKZF: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = ba49YvOK2Aw8Uhxt(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷ࠠࡇࡣ࡬ࡰࡺࡸࡥࠨࢹ")
	elif Oo4wEPUfp2v05kqryhlH6cBgDiMYL not in [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࢺ"),nR0ok9zju84rFUQl1YC(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢻ")]: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࢼ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL
	return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def xNLYwZCyVhIus(gf7yYnKb9M3IXr2ULBsq,url,source,BO1DGbpgSfCz):
	global jqdcmXhDbUGYw94u8enxSl6PyW2tr7,HZiSat0FTLvb,zASB0M1NCQgOq,ppNqtWiy41Bv6lh8dJazXC,GGkwxjid61SK
	LqEmutK5xH6za9Mf4srOyviUZI = []
	for lWZtu4JFEk in [HZiSat0FTLvb,zASB0M1NCQgOq,ppNqtWiy41Bv6lh8dJazXC,GGkwxjid61SK]: lWZtu4JFEk[BO1DGbpgSfCz] = CCWqR3dmtzw6xoIX41(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬࢽ"),[],[]
	wvmNP9HV2kcgU,Fi96CoeIOPWyvJjTEQMD7Lwn = [CFvZdexRhVjT42EBQcNLrbAU,tdDLbC81mf,d429CjL0fZRk6IMO5p1euq,gx8fRyW1dM],[]
	if ba49YvOK2Aw8Uhxt(u"ࠬ࡬ࡲࡥ࡮ࠪࢾ") in url: wvmNP9HV2kcgU,Fi96CoeIOPWyvJjTEQMD7Lwn = [CFvZdexRhVjT42EBQcNLrbAU,tdDLbC81mf,gx8fRyW1dM],[ppNqtWiy41Bv6lh8dJazXC]
	if hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧࢿ") in url: wvmNP9HV2kcgU,Fi96CoeIOPWyvJjTEQMD7Lwn = [CFvZdexRhVjT42EBQcNLrbAU],[zASB0M1NCQgOq,ppNqtWiy41Bv6lh8dJazXC,GGkwxjid61SK]
	for lWZtu4JFEk in Fi96CoeIOPWyvJjTEQMD7Lwn: lWZtu4JFEk[BO1DGbpgSfCz] = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡔ࡭࡬ࡴࡵ࡫ࡤࠨࣀ"),[],[]
	for lWZtu4JFEk in wvmNP9HV2kcgU:
		pyovASKZB2xwUtrCq5QcfzTG = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=lWZtu4JFEk,args=(url,source,BO1DGbpgSfCz))
		LqEmutK5xH6za9Mf4srOyviUZI.append(pyovASKZB2xwUtrCq5QcfzTG)
	def uvq1Kj4loXzUfsnMHZJpB2WVQGi():
		g7dOA59lIBFZKuMnRjrmWsik3,xVOWn4UI1qLHiDgmyEdPpNk9Zz,obW1w8xtRelBH,mubUKnOdoNZ54FIipYh = pLwgjkuTs6CS,pLwgjkuTs6CS,pLwgjkuTs6CS,pLwgjkuTs6CS
		L8jxlAB27cs16EYCRT,title,cX2SpPxGLmADTKl = HZiSat0FTLvb[BO1DGbpgSfCz]
		if (cX2SpPxGLmADTKl and not L8jxlAB27cs16EYCRT) or (L8jxlAB27cs16EYCRT and L8jxlAB27cs16EYCRT!=pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩࣁ")): g7dOA59lIBFZKuMnRjrmWsik3 = NFGqKBLtvUZn1S3dau
		L8jxlAB27cs16EYCRT,title,cX2SpPxGLmADTKl = zASB0M1NCQgOq[BO1DGbpgSfCz]
		if (cX2SpPxGLmADTKl and not L8jxlAB27cs16EYCRT) or (L8jxlAB27cs16EYCRT and L8jxlAB27cs16EYCRT!=YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪࣂ")): xVOWn4UI1qLHiDgmyEdPpNk9Zz = NFGqKBLtvUZn1S3dau
		L8jxlAB27cs16EYCRT,title,cX2SpPxGLmADTKl = ppNqtWiy41Bv6lh8dJazXC[BO1DGbpgSfCz]
		if (cX2SpPxGLmADTKl and not L8jxlAB27cs16EYCRT) or (L8jxlAB27cs16EYCRT and L8jxlAB27cs16EYCRT!=CCWqR3dmtzw6xoIX41(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫࣃ")): obW1w8xtRelBH = NFGqKBLtvUZn1S3dau
		L8jxlAB27cs16EYCRT,title,cX2SpPxGLmADTKl = GGkwxjid61SK[BO1DGbpgSfCz]
		if (cX2SpPxGLmADTKl and not L8jxlAB27cs16EYCRT) or (L8jxlAB27cs16EYCRT and L8jxlAB27cs16EYCRT!=B1YMtuvRAGNlJOkC46VyPKQE(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬࣄ")): mubUKnOdoNZ54FIipYh = NFGqKBLtvUZn1S3dau
		SaslN5qm6KdOWp7DCTwMJt014EQ = all([g7dOA59lIBFZKuMnRjrmWsik3,xVOWn4UI1qLHiDgmyEdPpNk9Zz,obW1w8xtRelBH,mubUKnOdoNZ54FIipYh])
		Jh3fArxWiMwNURO6kymPuGCTeta = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.Player().isPlaying() if drzqWFkSHD.resolveonly else NFGqKBLtvUZn1S3dau
		return SaslN5qm6KdOWp7DCTwMJt014EQ or not Jh3fArxWiMwNURO6kymPuGCTeta
	cxOYt1zLJqdR(LqEmutK5xH6za9Mf4srOyviUZI,Gz82dDr4wN5UHLTak9b631v7Y,hctuin9mF4xl81gT0CaNskqp6LbJW,xD9WeoEAsX7,uvq1Kj4loXzUfsnMHZJpB2WVQGi)
	succeeded = f9fOpCmLAEaW2Go(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫࣅ")
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = HZiSat0FTLvb[BO1DGbpgSfCz]
	CBL4OQVtWbMAycUGl7Ex2SKZF = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==pYeVwat64v(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣆ") or CBL4OQVtWbMAycUGl7Ex2SKZF: return succeeded,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	gf7yYnKb9M3IXr2ULBsq += pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠡࠩࣇ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)[:zWBnYSGIatjXVC(u"࠹࠲࿏")]
	succeeded = lRKCWnNi0Edr984eI(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧࣈ")
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = zASB0M1NCQgOq[BO1DGbpgSfCz]
	CBL4OQVtWbMAycUGl7Ex2SKZF = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==pYeVwat64v(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣉ") or CBL4OQVtWbMAycUGl7Ex2SKZF: return succeeded,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	gf7yYnKb9M3IXr2ULBsq += lRKCWnNi0Edr984eI(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠤࠬ࣊")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)[:GTmHXIZUSdxRhMnqQKkO(u"࠺࠳࿐")]
	succeeded = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪ࣋")
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = ppNqtWiy41Bv6lh8dJazXC[BO1DGbpgSfCz]
	CBL4OQVtWbMAycUGl7Ex2SKZF = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==pL73X0MYajJQG4n1qgD(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࣌") or CBL4OQVtWbMAycUGl7Ex2SKZF: return succeeded,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	gf7yYnKb9M3IXr2ULBsq += fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠸࠿ࠦࠠࠨ࣍")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)[:w9wfONXUP3(u"࠻࠴࿑")]
	succeeded = I6Bfzysrvb8DONZ(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠺࠭࣎")
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = GGkwxjid61SK[BO1DGbpgSfCz]
	CBL4OQVtWbMAycUGl7Ex2SKZF = L0zeV62OKx(CBL4OQVtWbMAycUGl7Ex2SKZF)
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࣏࠭") or CBL4OQVtWbMAycUGl7Ex2SKZF: return succeeded,Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	gf7yYnKb9M3IXr2ULBsq += pbmKZA1w7L4zHjOM(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠵࠻࣐ࠢࠣࠫ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)[:CCWqR3dmtzw6xoIX41(u"࠼࠵࿒")]
	jqdcmXhDbUGYw94u8enxSl6PyW2tr7[BO1DGbpgSfCz] = gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	return succeeded,gf7yYnKb9M3IXr2ULBsq,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def CFvZdexRhVjT42EBQcNLrbAU(url,source,BO1DGbpgSfCz):
	nUDgc4absePT2xMt,Nm3S9j4awYevPxs2qriCtT,LLzkoiPsbBZ,U67ILi5O4PKQzSEFRt,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,YVbC0fFvJRDSZLlc1w7ojzE = h46JK3E1HzWQDTSdcBsPlo0x(url,source)
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	if ba49YvOK2Aw8Uhxt(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ࣑")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = NNY0DyduVf(url)
	elif ba49YvOK2Aw8Uhxt(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡹࡸ࡫ࡲࡤࡱ࣒ࠪ") in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = O5j62nCzdVLefoJZ1(url)
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡿ࡯ࡶࡶࡸ࣓ࠫ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = AA2VrR8U0iDlmj5gwIfkKhWLupOo(url)
	elif B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭ࣔ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = AA2VrR8U0iDlmj5gwIfkKhWLupOo(url)
	elif I6Bfzysrvb8DONZ(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭ࣕ")	in url   : Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = G5aWesUjBLpYnFtZ6q0Eykz1PhQxoc(url)
	elif slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪࣖ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = mWqNB5Y9MPRj4UIuQoxzLE(url)
	elif vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪࣗ")		in url   : Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = mqdUQ5u6WB(url)
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭ࣘ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = NpvkIPh8cAdLM(url)
	elif CCWqR3dmtzw6xoIX41(u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬࣙ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = CkAz34Wh6OIs(url)
	elif bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ࣚ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = GJdKiTABIv(url)
	elif zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭ࣛ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = oA1EmaXJkd7uphNCjiIUMRs(url)
	elif kAz7WRYjrfGm(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ࣜ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = AA05TgaW9vJMGdu4XopZbVz(url)
	elif rAYDiWlzm9MCU6x0GnROua(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫࣝ")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = AA05TgaW9vJMGdu4XopZbVz(url)
	elif bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡸࡴࡧࡧ࡭ࠨࣞ") 		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	elif I6Bfzysrvb8DONZ(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬࣟ") 	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = bmua0qOBZrSMn6P5RcGhxzV7jyUH2(url)
	elif YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ࣠")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = W8Yg0lRn2OHwixFVIoN1bDPjt(url)
	elif W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ࣡") 	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = oxzWbwY7Grpeh6TO0BE(url)
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ࣢")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = yZWoIQVcJPdt(url)
	elif YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡶࡲࡥࣣࠫ") 			in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = Rp21U6kBKzlnfiIFZwJa(url)
	elif fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡷࡳࡴࠬࣤ") 			in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = Rp21U6kBKzlnfiIFZwJa(url)
	elif pL73X0MYajJQG4n1qgD(u"ࠩࡸࡵࡱࡵࡡࡥࠩࣥ") 		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = E9143psThcGzmOD8Vtu2(url)
	elif Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡺࡰࣦ࠭")	 		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = GtoOrzB0nklW3cIfZQpu(nUDgc4absePT2xMt)
	elif lRKCWnNi0Edr984eI(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ࣧ") 	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = HHmg4AJfXeCTZKPEcav9M(url)
	elif pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡼࡩࡥࡤࡲࡦࠬࣨ")		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = kkig27fcBTPnp0vEy(url)
	elif pbmKZA1w7L4zHjOM(u"࠭ࡶࡪࡦࡲࡾࡦࣩ࠭") 		in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = qH0xPgy93Gzft6wAi8mQLd(url)
	elif kAz7WRYjrfGm(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ࣪") 	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = Li90KCPhzduwRZGAol5QXY4tx(url)
	elif KKCrwPdOgGl(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ࣫")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = YrpJiQmZaqW(url)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭࣬")	in LLzkoiPsbBZ: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = RJTjvbpXONKgGY(url)
	else: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[]
	global HZiSat0FTLvb
	if not Oo4wEPUfp2v05kqryhlH6cBgDiMYL and not CBL4OQVtWbMAycUGl7Ex2SKZF: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠴ࠣࡊࡦ࡯࡬ࡶࡴࡨ࣭ࠫ")
	elif Oo4wEPUfp2v05kqryhlH6cBgDiMYL not in [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࣮ࠩ"),w9wfONXUP3(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࣯")]: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࣰࠠࠡࠩ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL
	HZiSat0FTLvb[BO1DGbpgSfCz] = Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	return
def tdDLbC81mf(url,source,BO1DGbpgSfCz):
	global zASB0M1NCQgOq
	if pYeVwat64v(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨࣱ") in url:
		zASB0M1NCQgOq[BO1DGbpgSfCz] = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡗࡰ࡯ࡰࡱࡧࡧࣲࠫ"),[],[]
		return
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[]
	if azP0kLi9Uc6(url):
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	if not CBL4OQVtWbMAycUGl7Ex2SKZF:
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = ynev0T4PA6fC9(url)
	if not CBL4OQVtWbMAycUGl7Ex2SKZF:
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = AlFqdtz8a3Ls4(url)
	if not CBL4OQVtWbMAycUGl7Ex2SKZF:
		if Oo4wEPUfp2v05kqryhlH6cBgDiMYL==w9wfONXUP3(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣳ"): Oo4wEPUfp2v05kqryhlH6cBgDiMYL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL = I6Bfzysrvb8DONZ(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࣴ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL if Oo4wEPUfp2v05kqryhlH6cBgDiMYL else YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶ࠤࡋࡧࡩ࡭ࡷࡵࡩࠬࣵ")
	zASB0M1NCQgOq[BO1DGbpgSfCz] = Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	return
def d429CjL0fZRk6IMO5p1euq(url,source,BO1DGbpgSfCz):
	YK1U4PZlH6MErXStRaVyb3J7hjnG = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Ubud2NhHKRnMTvI5mprQBVqk80 = pLwgjkuTs6CS
	try:
		import resolveurl as fg0tpjH8X4bPK
		Ubud2NhHKRnMTvI5mprQBVqk80 = fg0tpjH8X4bPK.resolve(url)
	except Exception as L8jxlAB27cs16EYCRT: YK1U4PZlH6MErXStRaVyb3J7hjnG = str(L8jxlAB27cs16EYCRT)
	global ppNqtWiy41Bv6lh8dJazXC
	if not Ubud2NhHKRnMTvI5mprQBVqk80:
		if YK1U4PZlH6MErXStRaVyb3J7hjnG==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			YK1U4PZlH6MErXStRaVyb3J7hjnG = VGgFQrd6JwjRCmp2aPAos0ycLkv.format_exc()
			if YK1U4PZlH6MErXStRaVyb3J7hjnG!=GTmHXIZUSdxRhMnqQKkO(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨࣶ"): qv7XKecsSGz6rBTpt.stderr.write(YK1U4PZlH6MErXStRaVyb3J7hjnG)
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL = YK1U4PZlH6MErXStRaVyb3J7hjnG.splitlines()[-xD9WeoEAsX7]
		ppNqtWiy41Bv6lh8dJazXC[BO1DGbpgSfCz] = Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࣷ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL,[],[]
		return
	ppNqtWiy41Bv6lh8dJazXC[BO1DGbpgSfCz] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[Ubud2NhHKRnMTvI5mprQBVqk80]
	return
def gx8fRyW1dM(url,source,BO1DGbpgSfCz):
	YK1U4PZlH6MErXStRaVyb3J7hjnG = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Ubud2NhHKRnMTvI5mprQBVqk80 = {}
	try:
		import yt_dlp as EaRkOMJxFe6VnfzwtN0u59Dpy4
		bOzDC5JPRaSZ = EaRkOMJxFe6VnfzwtN0u59Dpy4.YoutubeDL({I6Bfzysrvb8DONZ(u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩࣸ"): NFGqKBLtvUZn1S3dau})
		Ubud2NhHKRnMTvI5mprQBVqk80 = bOzDC5JPRaSZ.extract_info(url,download=pLwgjkuTs6CS)
	except Exception as L8jxlAB27cs16EYCRT: YK1U4PZlH6MErXStRaVyb3J7hjnG = str(L8jxlAB27cs16EYCRT)
	global GGkwxjid61SK
	if kAz7WRYjrfGm(u"ࠨࡨࡲࡶࡲࡧࡴࡴࣹࠩ") not in Ubud2NhHKRnMTvI5mprQBVqk80:
		if YK1U4PZlH6MErXStRaVyb3J7hjnG==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			YK1U4PZlH6MErXStRaVyb3J7hjnG = VGgFQrd6JwjRCmp2aPAos0ycLkv.format_exc()
			if YK1U4PZlH6MErXStRaVyb3J7hjnG!=B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࣺࠬ"): qv7XKecsSGz6rBTpt.stderr.write(YK1U4PZlH6MErXStRaVyb3J7hjnG)
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL = YK1U4PZlH6MErXStRaVyb3J7hjnG.splitlines()[-xD9WeoEAsX7]
		GGkwxjid61SK[BO1DGbpgSfCz] = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࣻ")+Oo4wEPUfp2v05kqryhlH6cBgDiMYL,[],[]
	else:
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
		for cX2SpPxGLmADTKl in Ubud2NhHKRnMTvI5mprQBVqk80[rAYDiWlzm9MCU6x0GnROua(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬࣼ")]:
			GjC4atkJLwlTpsI.append(cX2SpPxGLmADTKl[CCWqR3dmtzw6xoIX41(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬࣽ")])
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl[Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡵࡳ࡮ࠪࣾ")])
		GGkwxjid61SK[BO1DGbpgSfCz] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	return
def ynev0T4PA6fC9(url,headers=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not headers:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,I6Bfzysrvb8DONZ(u"ࠧࡈࡇࡗࠫࣿ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡄࡊࡔࡈࡇ࡙ࡥࡕࡓࡎ࠰࠵ࡸࡺࠧऀ"))
		headers = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers
	cX2SpPxGLmADTKl = headers.get(I6Bfzysrvb8DONZ(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫँ")) or headers.get(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬं")) or VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if cX2SpPxGLmADTKl and azP0kLi9Uc6(cX2SpPxGLmADTKl): return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return pYeVwat64v(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧः"),[],[]
def L0zeV62OKx(ZvsEFTCDcPL):
	if isinstance(ZvsEFTCDcPL,list):
		BA01W9olieErLycV7kwFvOhH5Y3ms = []
		for cX2SpPxGLmADTKl in ZvsEFTCDcPL:
			if isinstance(cX2SpPxGLmADTKl,str): cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			BA01W9olieErLycV7kwFvOhH5Y3ms.append(cX2SpPxGLmADTKl)
	else: BA01W9olieErLycV7kwFvOhH5Y3ms = ZvsEFTCDcPL.replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	return BA01W9olieErLycV7kwFvOhH5Y3ms
def TuW1nNR68UfQJdBEiyjcCDLrpv3(O0wTRBaWzSFf8IitYo5CmEgy,source):
	data = dYMLGvgfk4(mmEuUR4JdaHtAsS,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡲࡩࡴࡶࠪऄ"),w9wfONXUP3(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧअ"),O0wTRBaWzSFf8IitYo5CmEgy)
	if data:
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = zip(*data)
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = list(GjC4atkJLwlTpsI),list(CBL4OQVtWbMAycUGl7Ex2SKZF)
		return GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,IOKDqPXWQ6Fiyh = [],[],[]
	for cX2SpPxGLmADTKl in O0wTRBaWzSFf8IitYo5CmEgy:
		if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧ࠰࠱ࠪआ") not in cX2SpPxGLmADTKl: continue
		tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf = MhvGoSeVYlZRNXB(cX2SpPxGLmADTKl,source)
		XcvFdKRjNLz5wEpDf = AxTYMhRlfyskNc0X19dvwtS.findall(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨ࡞ࡧ࠯ࠬइ"),XcvFdKRjNLz5wEpDf,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if XcvFdKRjNLz5wEpDf: XcvFdKRjNLz5wEpDf = int(XcvFdKRjNLz5wEpDf[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
		else: XcvFdKRjNLz5wEpDf = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,f9fOpCmLAEaW2Go(u"ࠩࡱࡥࡲ࡫ࠧई"))
		IOKDqPXWQ6Fiyh.append([tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,cX2SpPxGLmADTKl,LLzkoiPsbBZ])
	if IOKDqPXWQ6Fiyh:
		zCG9tMKQcR = sorted(IOKDqPXWQ6Fiyh,reverse=NFGqKBLtvUZn1S3dau,key=lambda key: (key[gybxTLFEw2],key[nUaVQsoA6EXcK4Odht5wCge0J8Pib],key[anb4QpyjlmgVwANP],key[H3OKMjDG1evnl4Ruiz],key[xD9WeoEAsX7],key[jBbkfIJSDqcVwl8irzy4Z3O(u"࠺࿓")],key[GTmHXIZUSdxRhMnqQKkO(u"࠼࿔")]))
		OIbrTU8tkdvLRlSG9jZhgXoPC,zIb4L2ntdXGUcWfvB6gwMPVE = [],[]
		for bkhQVre594UyJ in zCG9tMKQcR:
			tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,cX2SpPxGLmADTKl,LLzkoiPsbBZ = bkhQVre594UyJ
			if W2Vv30i8qxSuItfsolPLdFZA(u"้ࠪๆ฼ไࠨउ") in YYTAkfz3NaQrLuCyRE:
				zIb4L2ntdXGUcWfvB6gwMPVE.append(bkhQVre594UyJ)
				continue
			if bkhQVre594UyJ not in OIbrTU8tkdvLRlSG9jZhgXoPC: OIbrTU8tkdvLRlSG9jZhgXoPC.append(bkhQVre594UyJ)
		OIbrTU8tkdvLRlSG9jZhgXoPC = zIb4L2ntdXGUcWfvB6gwMPVE+OIbrTU8tkdvLRlSG9jZhgXoPC
		u74UPEicpBdq32C = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		for tUYi1TdPkAreca2B6msC9Ivqhj3,usYnJBXhFT,YYTAkfz3NaQrLuCyRE,kw7O9B5fZceYAn0RbNtL,XcvFdKRjNLz5wEpDf,cX2SpPxGLmADTKl,LLzkoiPsbBZ in OIbrTU8tkdvLRlSG9jZhgXoPC:
			XcvFdKRjNLz5wEpDf = str(XcvFdKRjNLz5wEpDf) if XcvFdKRjNLz5wEpDf else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			title = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ุࠫ๐ัโำࠪऊ")+WRsuxHTjDgYCIpoMQzLFAtS8rikP+YYTAkfz3NaQrLuCyRE+WRsuxHTjDgYCIpoMQzLFAtS8rikP+tUYi1TdPkAreca2B6msC9Ivqhj3+WRsuxHTjDgYCIpoMQzLFAtS8rikP+XcvFdKRjNLz5wEpDf+WRsuxHTjDgYCIpoMQzLFAtS8rikP+kw7O9B5fZceYAn0RbNtL+WRsuxHTjDgYCIpoMQzLFAtS8rikP+usYnJBXhFT
			if LLzkoiPsbBZ.lower() not in title.lower(): title = title+WRsuxHTjDgYCIpoMQzLFAtS8rikP+LLzkoiPsbBZ
			title = title.replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࠫࠧऋ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			u74UPEicpBdq32C += xD9WeoEAsX7
			title = str(u74UPEicpBdq32C)+pL73X0MYajJQG4n1qgD(u"࠭࠮ࠡࠩऌ")+title
			if cX2SpPxGLmADTKl not in CBL4OQVtWbMAycUGl7Ex2SKZF:
				GjC4atkJLwlTpsI.append(title)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		if CBL4OQVtWbMAycUGl7Ex2SKZF:
			data = list(zip(GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF))
			if data and slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡺࡱࡸࡸࡺ࠭ऍ") not in str(O0wTRBaWzSFf8IitYo5CmEgy): JZvkPS1QBs436RujaCnh9b5x2(mmEuUR4JdaHtAsS,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩऎ"),O0wTRBaWzSFf8IitYo5CmEgy,data,QTa0s1bvhkXjIim7lWF5qVBJUoNZ)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = list(GjC4atkJLwlTpsI),list(CBL4OQVtWbMAycUGl7Ex2SKZF)
	return GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def XlBeCa6vgwprDAPW(url):
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[]
	if f9fOpCmLAEaW2Go(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ए") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡋࡊ࡚ࠧऐ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡎࡅࡅࡕࡒࡁ࡚ࡇࡕ࠱࠶ࡹࡴࠨऑ"))
		cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.url
		if cX2SpPxGLmADTKl: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	elif CCWqR3dmtzw6xoIX41(u"ࠬࡹࡥࡳࡸࡀࠫऒ") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡇࡆࡖࠪओ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡑࡈࡁࡑࡎࡄ࡝ࡊࡘ࠭࠳ࡰࡧࠫऔ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧक"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: url = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else:
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠤࡄࡰࡧࡧࡐ࡭ࡣࡼࡩࡷࡉ࡯࡯ࡶࡵࡳࡱࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧࠣख"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl:
				url = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				url = j3kWVqdguK6O2QDmMf.b64decode(url)
				if fOohwvakqi29cx0l3yt5mzrAGpEg: url = url.decode(RMGz7OiD1e30P)
			else: return w9wfONXUP3(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡌࡃࡃࡓࡐࡆ࡟ࡅࡓࠩग"),[],[]
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = I6Bfzysrvb8DONZ(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧघ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu
def llIGqPUr0R(url,YYTAkfz3NaQrLuCyRE,Nm3S9j4awYevPxs2qriCtT):
	if ba49YvOK2Aw8Uhxt(u"ࠬࡷࡶࡪࡦࠪङ") in url:
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = ffsFXIPVASCJk3wU9(url,YYTAkfz3NaQrLuCyRE,Nm3S9j4awYevPxs2qriCtT)
		if CBL4OQVtWbMAycUGl7Ex2SKZF: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
		return w9wfONXUP3(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡑࡘ࡚ࡂࡂࠩच"),[],[]
	return hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪछ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def eRsm5xYk7q(url):
	if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧज") in url:
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = vn9QxuZF4f2YzCVpELgkc(mI6ayKxBvjd4CRthL,url)
		if CBL4OQVtWbMAycUGl7Ex2SKZF: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
		return pbmKZA1w7L4zHjOM(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࠹ࡕ࠹ࠩझ"),[],[]
	return awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ञ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def zft9XpDrAq(url):
	dU17fayKLj4kABu,lFL9QtV2u1pa7WoieSmv3YzZPb = [],[]
	if nR0ok9zju84rFUQl1YC(u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧट") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,I6Bfzysrvb8DONZ(u"ࠬࡍࡅࡕࠩठ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨड"))
		if KKCrwPdOgGl(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩढ") in gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers:
			cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[zWBnYSGIatjXVC(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪण")]
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
			LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,f9fOpCmLAEaW2Go(u"ࠩࡱࡥࡲ࡫ࠧत"))
			lFL9QtV2u1pa7WoieSmv3YzZPb.append(LLzkoiPsbBZ)
	elif I6Bfzysrvb8DONZ(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩथ") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,lRKCWnNi0Edr984eI(u"ࠫࡌࡋࡔࠨद"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧध"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		q93wm568WlTABRKEFxkpJehzQV = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭न"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if q93wm568WlTABRKEFxkpJehzQV:
			q93wm568WlTABRKEFxkpJehzQV = q93wm568WlTABRKEFxkpJehzQV[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			miZOSIfwj7EX2YRl = xrekzisgX82ncKpOZWo3REdLJ(q93wm568WlTABRKEFxkpJehzQV)
			vuG0YAh2lLc7HKUjTs43MWQbeXEm = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬऩ"),miZOSIfwj7EX2YRl,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if vuG0YAh2lLc7HKUjTs43MWQbeXEm:
				vuG0YAh2lLc7HKUjTs43MWQbeXEm = vuG0YAh2lLc7HKUjTs43MWQbeXEm[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				vuG0YAh2lLc7HKUjTs43MWQbeXEm = rKY1tyQvh9OCxE2nl(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡮࡬ࡷࡹ࠭प"),vuG0YAh2lLc7HKUjTs43MWQbeXEm)
				for dict in vuG0YAh2lLc7HKUjTs43MWQbeXEm:
					cX2SpPxGLmADTKl = dict[CCWqR3dmtzw6xoIX41(u"ࠩࡩ࡭ࡱ࡫ࠧफ")]
					XcvFdKRjNLz5wEpDf = dict[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡰࡦࡨࡥ࡭ࠩब")]
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
					LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,pbmKZA1w7L4zHjOM(u"ࠫࡳࡧ࡭ࡦࠩभ"))
					lFL9QtV2u1pa7WoieSmv3YzZPb.append(XcvFdKRjNLz5wEpDf+WRsuxHTjDgYCIpoMQzLFAtS8rikP+LLzkoiPsbBZ)
		elif JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧम") in gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers:
			cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨय")]
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
			LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,f9fOpCmLAEaW2Go(u"ࠧ࡯ࡣࡰࡩࠬर"))
			lFL9QtV2u1pa7WoieSmv3YzZPb.append(LLzkoiPsbBZ)
		if Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨऱ") in url:
			cX2SpPxGLmADTKl = url.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡂࡹࡷࡲ࠽ࠨल"))[xD9WeoEAsX7]
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࠪࠬळ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			if cX2SpPxGLmADTKl:
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
				lFL9QtV2u1pa7WoieSmv3YzZPb.append(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫऴ"))
	else:
		dU17fayKLj4kABu.append(url)
		LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(url,rAYDiWlzm9MCU6x0GnROua(u"ࠬࡴࡡ࡮ࡧࠪव"))
		lFL9QtV2u1pa7WoieSmv3YzZPb.append(LLzkoiPsbBZ)
	if not dU17fayKLj4kABu: return ba49YvOK2Aw8Uhxt(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪश"),[],[]
	elif len(dU17fayKLj4kABu)==xD9WeoEAsX7: cX2SpPxGLmADTKl = dU17fayKLj4kABu[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	else:
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬष"),lFL9QtV2u1pa7WoieSmv3YzZPb)
		if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭स"),[],[]
		cX2SpPxGLmADTKl = dU17fayKLj4kABu[qNmsBD1jJZVzcxi4onKuAOIC]
	return jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬह"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def O5j62nCzdVLefoJZ1(url):
	headers = {pYeVwat64v(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧऺ"):YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡐࡵࡤࡪ࠱ࠪऻ")+str(XqSerIMoFsRn2UQ1D5Alj6)}
	for r6dVWlzDj9va0FxqfkOwLYZEmP in range(CCWqR3dmtzw6xoIX41(u"࠵࠱࿕")):
		f7epsRlYtMz4.sleep(hctuin9mF4xl81gT0CaNskqp6LbJW)
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = uXzektcZW0j57(CCWqR3dmtzw6xoIX41(u"ࠬࡍࡅࡕ़ࠩ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪऽ"))
		if I6Bfzysrvb8DONZ(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩा") in list(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.keys()):
			cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[ba49YvOK2Aw8Uhxt(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪि")]
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+lRKCWnNi0Edr984eI(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨी")+headers[hWRvZOYtjme9QNnV41u0Mswb(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧु")]
			return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
		if gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.code!=MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠵࠴࠼࿖"): break
	return ba49YvOK2Aw8Uhxt(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪू"),[],[]
def G5aWesUjBLpYnFtZ6q0Eykz1PhQxoc(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡍࡅࡕࠩृ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅ࠮࠳ࡶࡸࠬॄ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳࠰࠿ࠪࠤ࠯࠲࠯ࡅࠬ࠯ࠬࡂ࠰࠭࠴ࠪࡀࠫ࠯ࠫॅ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl,XcvFdKRjNLz5wEpDf = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[XcvFdKRjNLz5wEpDf],[cX2SpPxGLmADTKl]
	return W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩॆ"),[],[]
def QsRXVtdSwO(url):
	if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩ࠲ࡻࡪ࡫ࡰࡪࡵ࠲ࠫे") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,ba49YvOK2Aw8Uhxt(u"ࠪࡋࡊ࡚ࠧै"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡇࡆࡍࡒࡇ࠲࠮࠳ࡶࡸࠬॉ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡲࡷࡤࡰ࡮ࡺࡹ࠿ࠩॊ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: url = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: return nR0ok9zju84rFUQl1YC(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁ࠳ࠩो"),[],[]
	return jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪौ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def mqdUQ5u6WB(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,lRKCWnNi0Edr984eI(u"ࠨࡉࡈࡘ्ࠬ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠷࠭࠲ࡵࡷࠫॎ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	R8AE9e4mYxVhusL3Q = UtODNPp4Ifm7gbTY58(R8AE9e4mYxVhusL3Q)
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫॏ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
	return f9fOpCmLAEaW2Go(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠱ࠨॐ"),[],[]
def FWRKQzeu9U(url):
	if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡅࡩࡥ࠿ࠪ॑") in url:
		headers = {YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩ॒ࠬ"):f9fOpCmLAEaW2Go(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ॓")}
		url,data = url.rsplit(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡁࠪ॔"),pYeVwat64v(u"࠳࿗"))
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,nR0ok9zju84rFUQl1YC(u"ࠩࡓࡓࡘ࡚ࠧॕ"),url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠲࠮࠳ࡶࡸࠬॖ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॗ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: url = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: return w9wfONXUP3(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡖࡉࡑࡎࡄ࠳ࠩक़"),[],[]
	return lRKCWnNi0Edr984eI(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩख़"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def o0m83SXWTh(url):
	if len(url)>pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠵࠴࠵࿘"):
		url = url.strip(nR0ok9zju84rFUQl1YC(u"ࠧ࠰ࠩग़"))+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࠱ࠪज़")
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,f9fOpCmLAEaW2Go(u"ࠩࡊࡉ࡙࠭ड़"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡌࡂࡔࡒ࡞ࡆ࠳࠱ࡴࡶࠪढ़"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib and B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠭ࠬफ़") in R8AE9e4mYxVhusL3Q:
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࠨ࡬ࡰࡣࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫय़"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if vvuraxgW7YLIZ4hU0MbCt:
				IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(zWBnYSGIatjXVC(u"࠭࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࡷࡣࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࠪॠ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if vvuraxgW7YLIZ4hU0MbCt:
					IxdmfnvhCA8Bc9ZlQ45oiqN = BoSgyk0vuwGcT3xlK6nFJfLh1Dd(vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
		elif len(R8AE9e4mYxVhusL3Q)<CCWqR3dmtzw6xoIX41(u"࠸࠵࠶࿙"): cX2SpPxGLmADTKl = R8AE9e4mYxVhusL3Q
		else: return slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡅࡗࡕ࡚ࡂࠩॡ"),[],[]
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return pL73X0MYajJQG4n1qgD(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫॢ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def q3t4Yg9mhf(url,YYTAkfz3NaQrLuCyRE,Nm3S9j4awYevPxs2qriCtT):
	if JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࠲ࡨࡴࡽ࡮࠯ࡲ࡫ࡴࠬॣ") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡋࡊ࡚ࠧ।"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡊࡍࡇ࠭࠲ࡵࡷࠫ॥"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡼࡩࡥࡧࡲ࠱ࡼࡸࡡࡱࡲࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭०"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		url = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ१"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def uU93MkwA62(url):
	if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ२") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡉࡈࡘࠬ३"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ४"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ५"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if zWBnYSGIatjXVC(u"ࠫ࡭ࡺࡴࡱࠩ६") in cX2SpPxGLmADTKl: return zWBnYSGIatjXVC(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ७"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
		return KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ८"),[],[]
	return W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ९"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def O1n8Lz7f0a(url):
	nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
	aNXRWYnbow7s8fpvLVK = {awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ॰"):pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪॱ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩॲ"):djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫॳ")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡖࡏࡔࡖࠪॴ"),nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡔࡏࡘ࠯࠴ࡷࡹ࠭ॵ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॶ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: return MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡎࡐ࡙ࠪॷ"),[],[]
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return KKCrwPdOgGl(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॸ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def dxz8NlGe5E(url):
	headers = {zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ॹ"):I6Bfzysrvb8DONZ(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬॺ")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡍࡅࡕࠩॻ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨॼ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॽ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
	if not cX2SpPxGLmADTKl: return I6Bfzysrvb8DONZ(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬॾ"),[],[]
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॿ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def I3TDYBFSvE(url):
	nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
	aNXRWYnbow7s8fpvLVK = {MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩঀ"):pYeVwat64v(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫঁ")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡖࡏࡔࡖࠪং"),nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡋࡅࡑࡇࡃࡊࡏࡄ࠱࠶ࡹࡴࠨঃ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩ঄"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
	if not cX2SpPxGLmADTKl: return nR0ok9zju84rFUQl1YC(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡌࡆࡒࡁࡄࡋࡐࡅࠬঅ"),[],[]
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡫ࡸࡹࡶࠧআ") not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪ࡬ࡹࡺࡰ࠻ࠩই")+cX2SpPxGLmADTKl
	return pbmKZA1w7L4zHjOM(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧঈ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def jjpsiGUNBv(url):
	evGVuBpQUEL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = url,[],[]
	if pYeVwat64v(u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࠬউ") in url:
		nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
		aNXRWYnbow7s8fpvLVK = {YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬঊ"):I6Bfzysrvb8DONZ(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧঋ")}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡒࡒࡗ࡙࠭ঌ"),nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫ঍"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		fc1MjOx6b4FWTqt2BnJ5Asr = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠪࠫࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧ঎"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if fc1MjOx6b4FWTqt2BnJ5Asr: evGVuBpQUEL = fc1MjOx6b4FWTqt2BnJ5Asr[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return I6Bfzysrvb8DONZ(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧএ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[evGVuBpQUEL]
def m8RtQjSNGX(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡍࡅࡕࠩঐ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬ঑"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	QQRFEgvuBM8hTo5K = AxTYMhRlfyskNc0X19dvwtS.findall(ba49YvOK2Aw8Uhxt(u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ঒"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
	if QQRFEgvuBM8hTo5K:
		QQRFEgvuBM8hTo5K = QQRFEgvuBM8hTo5K[nUaVQsoA6EXcK4Odht5wCge0J8Pib][pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷࿚"):]
		QQRFEgvuBM8hTo5K = j3kWVqdguK6O2QDmMf.b64decode(QQRFEgvuBM8hTo5K)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: QQRFEgvuBM8hTo5K = QQRFEgvuBM8hTo5K.decode(RMGz7OiD1e30P)
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ও"),QQRFEgvuBM8hTo5K,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: cX2SpPxGLmADTKl = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if not cX2SpPxGLmADTKl: return slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪঔ"),[],[]
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡬ࡹࡺࡰࠨক") not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = hWRvZOYtjme9QNnV41u0Mswb(u"ࠫ࡭ࡺࡴࡱ࠼ࠪখ")+cX2SpPxGLmADTKl
	return jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨগ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def J7JBxon2wby5aYZ3RF4zXPl(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,pYeVwat64v(u"࠭ࡇࡆࡖࠪঘ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩঙ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(ba49YvOK2Aw8Uhxt(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭চ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: return Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭ছ"),[],[]
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭জ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def NNY0DyduVf(url):
	id = url.split(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫ࠴࠭ঝ"))[-f9fOpCmLAEaW2Go(u"࠷࿛")]
	if jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬঞ") in url: url = url.replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭ট"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	url = url.replace(w9wfONXUP3(u"ࠧ࠯ࡥࡲࡱ࠴࠭ঠ"),rAYDiWlzm9MCU6x0GnROua(u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩড"))
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,ba49YvOK2Aw8Uhxt(u"ࠩࡊࡉ࡙࠭ঢ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨণ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	Oo4wEPUfp2v05kqryhlH6cBgDiMYL = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫত")
	L8jxlAB27cs16EYCRT = AxTYMhRlfyskNc0X19dvwtS.findall(rAYDiWlzm9MCU6x0GnROua(u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭থ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if L8jxlAB27cs16EYCRT: Oo4wEPUfp2v05kqryhlH6cBgDiMYL = L8jxlAB27cs16EYCRT[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	url = AxTYMhRlfyskNc0X19dvwtS.findall(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪদ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not url and Oo4wEPUfp2v05kqryhlH6cBgDiMYL:
		return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,[],[]
	cX2SpPxGLmADTKl = url[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(CCWqR3dmtzw6xoIX41(u"ࠧ࡝࡞ࠪধ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	Uyb6AW5FflmEDXSa0scj,O0wTRBaWzSFf8IitYo5CmEgy = vn9QxuZF4f2YzCVpELgkc(mI6ayKxBvjd4CRthL,cX2SpPxGLmADTKl)
	rTnfMyoAJuXQGmtZCNgkR1j = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬন"))
	if rTnfMyoAJuXQGmtZCNgkR1j and JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࠰ࠫ঩") not in rTnfMyoAJuXQGmtZCNgkR1j: title,cX2SpPxGLmADTKl = Uyb6AW5FflmEDXSa0scj[nUaVQsoA6EXcK4Odht5wCge0J8Pib],O0wTRBaWzSFf8IitYo5CmEgy[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	else:
		llcJk3NaZMHLtyWCgd5b = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࡡࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧপ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if llcJk3NaZMHLtyWCgd5b: FDKzyUAVbORm2jr8Gvcn3k,E7M6K08mckWqPH5GXp,pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW = llcJk3NaZMHLtyWCgd5b[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: FDKzyUAVbORm2jr8Gvcn3k,E7M6K08mckWqPH5GXp,pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW = pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW.replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡡ࠵ࠧফ"),Zb5cNeHWi6jP9SCYtUgR(u"ࠬ࠵ࠧব"))
		E7M6K08mckWqPH5GXp = kd8ZhJPCe7QzxLgij3TEHlGtOv(E7M6K08mckWqPH5GXp)
		GjC4atkJLwlTpsI = [qFghPAi5yz9Vf3NLwo0nuprl+hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡏࡘࡐࡈࡖ࠿ࠦࠠࠨভ")+E7M6K08mckWqPH5GXp+so4Z8OUJ5E]+Uyb6AW5FflmEDXSa0scj
		CBL4OQVtWbMAycUGl7Ex2SKZF = [pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW]+O0wTRBaWzSFf8IitYo5CmEgy
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(W2Vv30i8qxSuItfsolPLdFZA(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨম")+str(len(CBL4OQVtWbMAycUGl7Ex2SKZF)-zWBnYSGIatjXVC(u"࠱࿜"))+rAYDiWlzm9MCU6x0GnROua(u"ࠨ่่ࠢๆ࠯ࠧয"),GjC4atkJLwlTpsI)
		if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return kAz7WRYjrfGm(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧর"),[],[]
		elif qNmsBD1jJZVzcxi4onKuAOIC==nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			rt4bc2XdTRA0EavBwISqFVox3HnOW = qv7XKecsSGz6rBTpt.argv[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ঱")+pn0MlRZ6EG8fkJAhuLQ4F1vm9ODW+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࠫࡺࡥࡹࡶࡷࡁࠬল")+E7M6K08mckWqPH5GXp
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(kAz7WRYjrfGm(u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ঳")+rt4bc2XdTRA0EavBwISqFVox3HnOW+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࠩࠣ঴"))
			return GTmHXIZUSdxRhMnqQKkO(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ঵"),[],[]
		title,cX2SpPxGLmADTKl = GjC4atkJLwlTpsI[qNmsBD1jJZVzcxi4onKuAOIC],CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[title],[cX2SpPxGLmADTKl]
def ooptheiadS(cX2SpPxGLmADTKl):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡉࡈࡘࠬশ"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨষ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if rAYDiWlzm9MCU6x0GnROua(u"ࠪ࠲࡯ࡹ࡯࡯ࠩস") in cX2SpPxGLmADTKl: url = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫহ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: url = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ঺"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not url: return kAz7WRYjrfGm(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧ঻"),[],[]
	url = url[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡩࡶࡷࡴ়ࠬ") not in url: url = pYeVwat64v(u"ࠨࡪࡷࡸࡵࡀࠧঽ")+url
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def mWqNB5Y9MPRj4UIuQoxzLE(url):
	headers = { pYeVwat64v(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭া") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭ি") in url:
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࠭ী"))
		items = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫু"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
		else:
			mlrXUnyLzPAhEIj8ix5Ztpu = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫূ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if mlrXUnyLzPAhEIj8ix5Ztpu:
				w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩৃ"),mlrXUnyLzPAhEIj8ix5Ztpu[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
				return W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩৄ")+mlrXUnyLzPAhEIj8ix5Ztpu[nUaVQsoA6EXcK4Odht5wCge0J8Pib],[],[]
	else:
		XQv4cBgdZD5k6OPwy3alsEGxtA = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬ৅")
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬ৆"))
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ে"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: return KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩৈ"),[],[]
		evGVuBpQUEL = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]
		if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࠮ࡳࡣࡵࠫ৉") in IxdmfnvhCA8Bc9ZlQ45oiqN or fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧ࠯ࡼ࡬ࡴࠬ৊") in IxdmfnvhCA8Bc9ZlQ45oiqN: return MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭ো"),[],[]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪৌ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		dXG96SRYbe = {}
		for usYnJBXhFT,value in items:
			dXG96SRYbe[usYnJBXhFT] = value
		data = g726UBevLKbpyh8o35Z4fdPiRrn9uG(dXG96SRYbe)
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,evGVuBpQUEL,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨ্ࠬ"))
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩৎ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: return W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ৏"),[],[]
		download = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭৐"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		kVw0YQZ3rTqvsiX,GjC4atkJLwlTpsI,A0LEKGq2Bb9pnXy1ZTmduYlSf4UsM8,CBL4OQVtWbMAycUGl7Ex2SKZF,aa2xph7Qgzt1dvuPiIfA = [],[],[],[],[]
		for cX2SpPxGLmADTKl,title in items:
			if djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧ࠯࡯࠶ࡹ࠽࠭৑") in cX2SpPxGLmADTKl:
				kVw0YQZ3rTqvsiX,A0LEKGq2Bb9pnXy1ZTmduYlSf4UsM8 = vn9QxuZF4f2YzCVpELgkc(mI6ayKxBvjd4CRthL,cX2SpPxGLmADTKl)
				CBL4OQVtWbMAycUGl7Ex2SKZF = CBL4OQVtWbMAycUGl7Ex2SKZF + A0LEKGq2Bb9pnXy1ZTmduYlSf4UsM8
				if kVw0YQZ3rTqvsiX[nUaVQsoA6EXcK4Odht5wCge0J8Pib]==w9wfONXUP3(u"ࠨ࠯࠴ࠫ৒"): GjC4atkJLwlTpsI.append(nR0ok9zju84rFUQl1YC(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ৓")+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡱ࠸ࡻ࠸ࠡࠩ৔")+XQv4cBgdZD5k6OPwy3alsEGxtA)
				else:
					for title in kVw0YQZ3rTqvsiX:
						GjC4atkJLwlTpsI.append(CCWqR3dmtzw6xoIX41(u"ู๊ࠫࠥาใิࠤำอีࠡࠩ৕")+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡳ࠳ࡶ࠺ࠣࠫ৖")+XQv4cBgdZD5k6OPwy3alsEGxtA+WRsuxHTjDgYCIpoMQzLFAtS8rikP+title)
			else:
				title = title.replace(B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨৗ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				title = title.strip(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࠣࠩ৘"))
				title = nR0ok9zju84rFUQl1YC(u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧ৙")+lRKCWnNi0Edr984eI(u"ࠩࠣࡱࡵ࠺ࠠࠨ৚")+XQv4cBgdZD5k6OPwy3alsEGxtA+WRsuxHTjDgYCIpoMQzLFAtS8rikP+title
				GjC4atkJLwlTpsI.append(title)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		cX2SpPxGLmADTKl = pYeVwat64v(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬ৛") + download
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠸ࡸ࡭࠭ড়"))
		items = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭ࠤঢ়"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,t5fhagjUGXk0ynOlJWeAb,hash,gn321kUpDH8uExbi6wfrj07 in items:
			title = GTmHXIZUSdxRhMnqQKkO(u"࠭ࠠิ์ิๅึࠦสฮ็ํ่ࠥิวึࠢࠪ৞")+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࠡ࡯ࡳ࠸ࠥ࠭য়")+XQv4cBgdZD5k6OPwy3alsEGxtA+WRsuxHTjDgYCIpoMQzLFAtS8rikP+gn321kUpDH8uExbi6wfrj07.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡺࠪৠ"))[xD9WeoEAsX7]
			cX2SpPxGLmADTKl = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧৡ")+id+lRKCWnNi0Edr984eI(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪৢ")+t5fhagjUGXk0ynOlJWeAb+hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫৣ")+hash
			aa2xph7Qgzt1dvuPiIfA.append(gn321kUpDH8uExbi6wfrj07)
			GjC4atkJLwlTpsI.append(title)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		aa2xph7Qgzt1dvuPiIfA = set(aa2xph7Qgzt1dvuPiIfA)
		jedk9VHWs5N4m,bZxFg3wi9LtmNkWXGT5KdpD6E = [],[]
		for title in GjC4atkJLwlTpsI:
			HHkxhWYbrAnGKq1 = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧ৤"),title+kAz7WRYjrfGm(u"࠭ࠦࠧࠩ৥"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for gn321kUpDH8uExbi6wfrj07 in aa2xph7Qgzt1dvuPiIfA:
				if HHkxhWYbrAnGKq1[nUaVQsoA6EXcK4Odht5wCge0J8Pib] in gn321kUpDH8uExbi6wfrj07:
					title = title.replace(HHkxhWYbrAnGKq1[nUaVQsoA6EXcK4Odht5wCge0J8Pib],gn321kUpDH8uExbi6wfrj07.split(kAz7WRYjrfGm(u"ࠧࡹࠩ০"))[xD9WeoEAsX7])
			jedk9VHWs5N4m.append(title)
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(CBL4OQVtWbMAycUGl7Ex2SKZF)):
			items = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤ১"),lRKCWnNi0Edr984eI(u"ࠩࠩࠪࠬ২")+jedk9VHWs5N4m[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+GTmHXIZUSdxRhMnqQKkO(u"ࠪࠪࠫ࠭৩"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			bZxFg3wi9LtmNkWXGT5KdpD6E.append( [jedk9VHWs5N4m[uKFGBAEj9tX1e03cyHOMUNhQl4r6],CBL4OQVtWbMAycUGl7Ex2SKZF[uKFGBAEj9tX1e03cyHOMUNhQl4r6],items[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib],items[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]] )
		bZxFg3wi9LtmNkWXGT5KdpD6E = sorted(bZxFg3wi9LtmNkWXGT5KdpD6E, key=lambda pJIMwPmtxzhH: pJIMwPmtxzhH[anb4QpyjlmgVwANP], reverse=NFGqKBLtvUZn1S3dau)
		bZxFg3wi9LtmNkWXGT5KdpD6E = sorted(bZxFg3wi9LtmNkWXGT5KdpD6E, key=lambda pJIMwPmtxzhH: pJIMwPmtxzhH[H3OKMjDG1evnl4Ruiz], reverse=pLwgjkuTs6CS)
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(bZxFg3wi9LtmNkWXGT5KdpD6E)):
			GjC4atkJLwlTpsI.append(bZxFg3wi9LtmNkWXGT5KdpD6E[uKFGBAEj9tX1e03cyHOMUNhQl4r6][nUaVQsoA6EXcK4Odht5wCge0J8Pib])
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(bZxFg3wi9LtmNkWXGT5KdpD6E[uKFGBAEj9tX1e03cyHOMUNhQl4r6][xD9WeoEAsX7])
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return lRKCWnNi0Edr984eI(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ৪"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def oA1EmaXJkd7uphNCjiIUMRs(url):
	PCnrX0p2QmTt5ijBIkqu4La = url.split(f9fOpCmLAEaW2Go(u"ࠬࡅࠧ৫"))
	nUDgc4absePT2xMt = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	headers = { Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ৬") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺࠧ৭"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(rAYDiWlzm9MCU6x0GnROua(u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ৮"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	url = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return KKCrwPdOgGl(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ৯"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def GJdKiTABIv(url):
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	headers = { MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧৰ") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪৱ"))
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ৲"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if nUDgc4absePT2xMt: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
	else: return YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩ৳"),[],[]
def AA05TgaW9vJMGdu4XopZbVz(url):
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	headers = { MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ৴") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ৵"))
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁࠬࠦࠬ৶"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if nUDgc4absePT2xMt: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
	else: return bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠫ৷"),[],[]
def Mt2bPXUIwJ(url):
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,errno = [],[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ৸") in url:
		nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
		aNXRWYnbow7s8fpvLVK = {lRKCWnNi0Edr984eI(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ৹"):KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭৺")}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡑࡑࡖࡘࠬ৻"),nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧࠫৼ"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if gwiPcfVU0T4qHMDF3Wdeh7YK.startswith(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩ࡫ࡸࡹࡶࠧ৽")): nUDgc4absePT2xMt = gwiPcfVU0T4qHMDF3Wdeh7YK
		else:
			jYfvU9egTX62nrukVcoKEAyq = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ৾"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if jYfvU9egTX62nrukVcoKEAyq:
				nUDgc4absePT2xMt = jYfvU9egTX62nrukVcoKEAyq[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				jYfvU9egTX62nrukVcoKEAyq = AxTYMhRlfyskNc0X19dvwtS.findall(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫ࡞ࠪࠩࡣࠧ৿"),nUDgc4absePT2xMt,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if jYfvU9egTX62nrukVcoKEAyq:
					nUDgc4absePT2xMt = WDg18QHF3rze(jYfvU9egTX62nrukVcoKEAyq[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
					return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	elif I6Bfzysrvb8DONZ(u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࠭਀") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡇࡆࡖࠪਁ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠱ࡴࡶࠪਂ"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪਃ") in list(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.keys()): nUDgc4absePT2xMt = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[rAYDiWlzm9MCU6x0GnROua(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ਄")]
		else:
			nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਅ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib] if nUDgc4absePT2xMt else url
	if rAYDiWlzm9MCU6x0GnROua(u"ࠫ࠴ࡼ࠯ࠨਆ") in nUDgc4absePT2xMt or f9fOpCmLAEaW2Go(u"ࠬ࠵ࡦ࠰ࠩਇ") in nUDgc4absePT2xMt:
		nUDgc4absePT2xMt = nUDgc4absePT2xMt.replace(jBbkfIJSDqcVwl8irzy4Z3O(u"࠭࠯ࡧ࠱ࠪਈ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭ਉ"))
		nUDgc4absePT2xMt = nUDgc4absePT2xMt.replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ࠱ࡹ࠳ࠬਊ"),ba49YvOK2Aw8Uhxt(u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ਋"))
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡔࡔ࡙ࡔࠨ਌"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧ਍"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		items = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਎"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for cX2SpPxGLmADTKl,title in items:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(pYeVwat64v(u"࠭࡜࡝ࠩਏ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				GjC4atkJLwlTpsI.append(title)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		else:
			items = AxTYMhRlfyskNc0X19dvwtS.findall(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਐ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if items:
				cX2SpPxGLmADTKl = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ࡞࡟ࠫ਑"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				GjC4atkJLwlTpsI.append(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	else: return lRKCWnNi0Edr984eI(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ਒"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return I6Bfzysrvb8DONZ(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨਓ"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def lwfZ8vtTFM(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡌࡋࡔࠨਔ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬਕ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,errno = [],[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩਖ") in url or pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨਗ") in url:
		if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫਘ") in url:
			nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(pYeVwat64v(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਙ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: nUDgc4absePT2xMt = url
		if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪਚ") not in nUDgc4absePT2xMt: return zWBnYSGIatjXVC(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਛ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡍࡅࡕࠩਜ"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭ਝ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪਞ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਟ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for cX2SpPxGLmADTKl,AAB086Sqz9xc in items:
				GjC4atkJLwlTpsI.append(AAB086Sqz9xc)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	elif pL73X0MYajJQG4n1qgD(u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫਠ") in url:
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧਡ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡌࡋࡔࠨਢ"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬਣ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		jYfvU9egTX62nrukVcoKEAyq = AxTYMhRlfyskNc0X19dvwtS.findall(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨਤ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		jYfvU9egTX62nrukVcoKEAyq = jYfvU9egTX62nrukVcoKEAyq[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		GjC4atkJLwlTpsI.append(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(jYfvU9egTX62nrukVcoKEAyq)
	elif djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧਥ") in url:
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਦ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if nUDgc4absePT2xMt:
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			return jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬਧ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡗࡕ࠷࡙ࠬਨ"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def LAbTHG0nuF(url):
	if hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡄ࡭ࡥࡵ࠿ࠪ਩") in url:
		cX2SpPxGLmADTKl = url.split(YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡅࡧࡦࡶࡀࠫਪ"),xD9WeoEAsX7)[xD9WeoEAsX7]
		cX2SpPxGLmADTKl = j3kWVqdguK6O2QDmMf.b64decode(cX2SpPxGLmADTKl)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.decode(RMGz7OiD1e30P,pYeVwat64v(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ਫ"))
		return f9fOpCmLAEaW2Go(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਬ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	website = drzqWFkSHD.SITESURLS[I6Bfzysrvb8DONZ(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪਭ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	headers = {lRKCWnNi0Edr984eI(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪਮ"):website}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡋࡊ࡚ࠧਯ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡃ࠯࠵ࡲࡩ࠭ਰ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(url,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡻࡲ࡭ࠩ਱"))
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਲ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠢࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠬ࠮࠮ࠫࡁࠬࠫࠧਲ਼"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(rAYDiWlzm9MCU6x0GnROua(u"ࠣࡨ࡬ࡰࡪࡀࠧࠩ࠰࠭ࡃ࠮࠭ࠢ਴"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+I6Bfzysrvb8DONZ(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬਵ")+website
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠪਸ਼") in R8AE9e4mYxVhusL3Q:
		ZBeFap8Ey3v2KGJIuomS4wNQd9i5hn = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭਷"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if ZBeFap8Ey3v2KGJIuomS4wNQd9i5hn:
			cX2SpPxGLmADTKl = ZBeFap8Ey3v2KGJIuomS4wNQd9i5hn[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			cX2SpPxGLmADTKl = j3kWVqdguK6O2QDmMf.b64decode(cX2SpPxGLmADTKl)
			if fOohwvakqi29cx0l3yt5mzrAGpEg: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.decode(RMGz7OiD1e30P,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬਸ"))
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡨࡵࡶࡳ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࠮ࠪਹ"),cX2SpPxGLmADTKl,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+pbmKZA1w7L4zHjOM(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ਺")+website
				return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ਻"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def PXcpvrS3Vd(url,YVbC0fFvJRDSZLlc1w7ojzE):
	lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = [],[]
	if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࠲࠵࠴਼࠭") in url:
		cX2SpPxGLmADTKl = url.replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ࠳࠶࠵ࠧ਽"),f9fOpCmLAEaW2Go(u"ࠫ࠴࠺࠯ࠨਾ"))
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,ba49YvOK2Aw8Uhxt(u"ࠬࡍࡅࡕࠩਿ"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨੀ"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭ੁ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			items = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧੂ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,XcvFdKRjNLz5wEpDf in items:
				if cX2SpPxGLmADTKl not in dU17fayKLj4kABu:
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
					LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡱࡥࡲ࡫ࠧ੃"))
					lFL9QtV2u1pa7WoieSmv3YzZPb.append(LLzkoiPsbBZ+zHYL9u48eyJot+XcvFdKRjNLz5wEpDf)
			return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu
	elif f9fOpCmLAEaW2Go(u"ࠪ࠳ࡩ࠵ࠧ੄") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡌࡋࡔࠨ੅"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠶ࡳࡪࠧ੆"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(I6Bfzysrvb8DONZ(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧੇ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧ࠰࠳࠲ࠫੈ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࠱࠷࠳ࠬ੉"))
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,I6Bfzysrvb8DONZ(u"ࠩࡊࡉ࡙࠭੊"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࠬੋ"))
			gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫੌ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl: return MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ੍"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
	elif nR0ok9zju84rFUQl1YC(u"࠭࠯ࡳࡱ࡯ࡩ࠴࠭੎") in url:
		headers = {MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ੏"):YVbC0fFvJRDSZLlc1w7ojzE}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡉࡈࡘࠬ੐"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠵ࡶ࡫ࠫੑ"))
		cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ੒")]
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡌࡋࡔࠨ੓"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠹ࡹ࡮ࠧ੔"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = JxysfMpU59(cX2SpPxGLmADTKl,R8AE9e4mYxVhusL3Q)
		return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu
	elif pL73X0MYajJQG4n1qgD(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ੕") in url:
		nUDgc4absePT2xMt = url.replace(GTmHXIZUSdxRhMnqQKkO(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ੖"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨ࠱ࡶࡧࡷ࡯ࡰࡵ࠱ࠪ੗"))
		aNXRWYnbow7s8fpvLVK = {pbmKZA1w7L4zHjOM(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ੘"):YVbC0fFvJRDSZLlc1w7ojzE}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡋࡊ࡚ࠧਖ਼"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠹ࡸ࡭࠭ਗ਼"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਜ਼"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡇࡆࡖࠪੜ"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠽ࡴࡩࠩ੝"))
			R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪਫ਼") in list(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.keys()):
				cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ੟")]
				gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡋࡊ࡚ࠧ੠"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠻ࡸ࡭࠭੡"))
				R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
				Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu = JxysfMpU59(cX2SpPxGLmADTKl,R8AE9e4mYxVhusL3Q)
				if dU17fayKLj4kABu: return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu
			elif I6Bfzysrvb8DONZ(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭੢") in cX2SpPxGLmADTKl:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(nR0ok9zju84rFUQl1YC(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧ੣"),ba49YvOK2Aw8Uhxt(u"ࠧ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ੤"))
				return zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੥"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	else: return pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ੦"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	return zWBnYSGIatjXVC(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ੧"),[],[]
def FlPMyQw5G4(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡌࡋࡔࠨ੨"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠵ࡸࡺࠧ੩"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	data = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"࠭ࠢࡢࡥࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੪"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if data:
		Pq15N6VMGtxpoAvZrL,id,iMwEU7k1nRl8e0JTxWIOz = data[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		data = kAz7WRYjrfGm(u"ࠧࡰࡲࡀࠫ੫")+Pq15N6VMGtxpoAvZrL+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࠨ࡬ࡨࡂ࠭੬")+id+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࠩࡪࡳࡧ࡭ࡦ࠿ࠪ੭")+iMwEU7k1nRl8e0JTxWIOz
		headers = {jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ੮"):pbmKZA1w7L4zHjOM(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ੯")}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡖࡏࡔࡖࠪੰ"),url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠷ࡴࡤࠨੱ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠧࠣࡴࡨࡪࡪࡸࡥࡳࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪੲ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: return hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫੳ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]]
	return KKCrwPdOgGl(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ੴ"),[],[]
def ooBbhVisp7(url):
	headers = {YzlId3Fs6vpehcbLGj0UaO(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ੵ"):zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ੶")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡍࡅࡕࠩ੷"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱࠶ࡹࡴࠨ੸"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(CCWqR3dmtzw6xoIX41(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੹"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		return awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੺"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭੻"),[],[]
def ZTxb8H1gyn(url):
	nUDgc4absePT2xMt = url.split(GTmHXIZUSdxRhMnqQKkO(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ੼"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib].strip(I6Bfzysrvb8DONZ(u"ࠫࡄ࠭੽")).strip(w9wfONXUP3(u"ࠬ࠵ࠧ੾")).strip(vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࠦࠨ੿"))
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,items,jYfvU9egTX62nrukVcoKEAyq = [],[],[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	headers = { pbmKZA1w7L4zHjOM(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ઀"):B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨઁ") }
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,pYeVwat64v(u"ࠩࡊࡉ࡙࠭ં"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,NFGqKBLtvUZn1S3dau,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫઃ"))
	if lRKCWnNi0Edr984eI(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭઄") in list(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.keys()): jYfvU9egTX62nrukVcoKEAyq = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧઅ")]
	if B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡨࡵࡶࡳࠫઆ") in jYfvU9egTX62nrukVcoKEAyq:
		if pL73X0MYajJQG4n1qgD(u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨઇ") in url: jYfvU9egTX62nrukVcoKEAyq = jYfvU9egTX62nrukVcoKEAyq.replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨ࠱ࡩ࠳ࠬઈ"),lRKCWnNi0Edr984eI(u"ࠩ࠲ࡺ࠴࠭ઉ"))
		Hi7dgewh08plQ9amyqNZ = nUDgc4absePT2xMt.split(rAYDiWlzm9MCU6x0GnROua(u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬઊ"))[xD9WeoEAsX7]
		headers = { YzlId3Fs6vpehcbLGj0UaO(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨઋ"):headers[kAz7WRYjrfGm(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઌ")] , Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ઍ"):pbmKZA1w7L4zHjOM(u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨ઎")+Hi7dgewh08plQ9amyqNZ }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡉࡈࡘࠬએ"),jYfvU9egTX62nrukVcoKEAyq,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬઐ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪ࠳࡫࠵ࠧઑ") in jYfvU9egTX62nrukVcoKEAyq: items = AxTYMhRlfyskNc0X19dvwtS.findall(W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ઒"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		elif YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࠵ࡶ࠰ࠩઓ") in jYfvU9egTX62nrukVcoKEAyq: items = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪઔ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items: return [],[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[ items[nUaVQsoA6EXcK4Odht5wCge0J8Pib] ]
		elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭ક") in R8AE9e4mYxVhusL3Q:
			return YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫખ"),[],[]
	else: return JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬગ"),[],[]
def qO0jx34NUh(cX2SpPxGLmADTKl):
	PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬઘ"),cX2SpPxGLmADTKl+YzlId3Fs6vpehcbLGj0UaO(u"ࠫࠫࠬࠧઙ"),AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
	ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	url = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭ચ")+ccHBj2aGoTKM5DZLv71U0CO+GTmHXIZUSdxRhMnqQKkO(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪછ")+QYWvDSNgqBiRaAdn
	headers = { slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫજ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O , nR0ok9zju84rFUQl1YC(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫઝ"):MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪઞ") }
	nUDgc4absePT2xMt = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩટ"))
	return Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧઠ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
def jjC6fFzkVI(url):
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(url,CCWqR3dmtzw6xoIX41(u"ࠬࡻࡲ࡭ࠩડ"))
	aNXRWYnbow7s8fpvLVK = {rAYDiWlzm9MCU6x0GnROua(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧઢ"):LLzkoiPsbBZ,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩણ"):kAz7WRYjrfGm(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨત")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(qJ0xtbICjHuM45nmhO7fgpkr,I6Bfzysrvb8DONZ(u"ࠩࡊࡉ࡙࠭થ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪદ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬધ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nUDgc4absePT2xMt = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫન"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
		for title,cX2SpPxGLmADTKl in items:
			GjC4atkJLwlTpsI.append(title)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==xD9WeoEAsX7: nUDgc4absePT2xMt = CBL4OQVtWbMAycUGl7Ex2SKZF[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		elif len(CBL4OQVtWbMAycUGl7Ex2SKZF)>xD9WeoEAsX7:
			qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(pbmKZA1w7L4zHjOM(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ઩"), GjC4atkJLwlTpsI)
			if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return pL73X0MYajJQG4n1qgD(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬપ"),[],[]
			nUDgc4absePT2xMt = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(pbmKZA1w7L4zHjOM(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ફ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: nUDgc4absePT2xMt = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if not nUDgc4absePT2xMt: return Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡃࡊࡏࡄࠫબ"),[],[]
	return CCWqR3dmtzw6xoIX41(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ભ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
def VJXZc6qF1u(url):
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(url,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡺࡸ࡬ࠨમ"))
	aNXRWYnbow7s8fpvLVK = {awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ય"):LLzkoiPsbBZ,pL73X0MYajJQG4n1qgD(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨર"):Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ઱")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(qJ0xtbICjHuM45nmhO7fgpkr,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡉࡈࡘࠬલ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩળ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ઴"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nUDgc4absePT2xMt = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall(pYeVwat64v(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪવ"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
		for title,cX2SpPxGLmADTKl in items:
			GjC4atkJLwlTpsI.append(title)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==xD9WeoEAsX7: nUDgc4absePT2xMt = CBL4OQVtWbMAycUGl7Ex2SKZF[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		elif len(CBL4OQVtWbMAycUGl7Ex2SKZF)>xD9WeoEAsX7:
			qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(f9fOpCmLAEaW2Go(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪશ"),GjC4atkJLwlTpsI)
			if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫષ"),[],[]
			nUDgc4absePT2xMt = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]
	if not nUDgc4absePT2xMt:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(zWBnYSGIatjXVC(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬસ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: nUDgc4absePT2xMt = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	if not nUDgc4absePT2xMt: return zWBnYSGIatjXVC(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪહ"),[],[]
	return JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ઺"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
def BHmc05rURM(cX2SpPxGLmADTKl):
	PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ઻"),cX2SpPxGLmADTKl+JZ45mOctiTszPNw1GVjxhep2Y(u"઼ࠫࠫࠬࠧ"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	url,ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	data = {pYeVwat64v(u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭ઽ"):ccHBj2aGoTKM5DZLv71U0CO,B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ા"):QYWvDSNgqBiRaAdn}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,lRKCWnNi0Edr984eI(u"ࠧࡑࡑࡖࡘࠬિ"),url,data,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪી"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(I6Bfzysrvb8DONZ(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧુ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ૂ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
def CIyMfY4RsL(url):
	cX2SpPxGLmADTKl = url
	if Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡄࡹࡥࡳࡸࡀࠫૃ") in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡍࡅࡕࠩૄ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳࠱ࡴࡶࠪૅ"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૆"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: return hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧે"),[],[]
	return ba49YvOK2Aw8Uhxt(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૈ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def udzGthVKnl(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡋࡊ࡚ࠧૉ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ૊"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(I6Bfzysrvb8DONZ(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ો"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if cX2SpPxGLmADTKl: return fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩૌ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘ્ࠬ"),[],[]
def WhmqkdUitQ(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡉࡈࡘࠬ૎"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ૏"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૐ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	return pYeVwat64v(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૑"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def NWaJvRzG5C(url):
	VChIfEZU37zqWGnL = UUmYkruGeM3p8sKi6o2fcI(url,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡻࡲ࡭ࠩ૒"))
	if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭૓") in url:
		headers = {YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ૔"):VChIfEZU37zqWGnL}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡉࡈࡘࠬ૕"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ૖"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૗"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if nUDgc4absePT2xMt:
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			if rAYDiWlzm9MCU6x0GnROua(u"ࠫ࡭ࡺࡴࡱࠩ૘") not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = CCWqR3dmtzw6xoIX41(u"ࠬ࡮ࡴࡵࡲ࠽ࠫ૙")+nUDgc4absePT2xMt
			if B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ૚") in nUDgc4absePT2xMt:
				gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡈࡇࡗࠫ૛"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ૜"))
				gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
				items = AxTYMhRlfyskNc0X19dvwtS.findall(ba49YvOK2Aw8Uhxt(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૝"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if not items:
					vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣ࡜࠯ࠩ૞"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					if vvuraxgW7YLIZ4hU0MbCt:
						Lhi71X39bHs6zEZ4ypIaGewVJ = vvuraxgW7YLIZ4hU0MbCt[JZ45mOctiTszPNw1GVjxhep2Y(u"࠱࿝")]
						items = AxTYMhRlfyskNc0X19dvwtS.findall(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࠧࡢ࡛ࠩ࠰࠭ࡃ࠮ࡢ࡝ࠡࠪ࠱࠮ࡄ࠯ࠢࠨ૟"),Lhi71X39bHs6zEZ4ypIaGewVJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
						if items:
							oxJz1a7mUDSk2RBrVsKg3tYI64eHpj,paGUuZivbSx4LnR3Okrqf = zip(*items)
							items = list(zip(paGUuZivbSx4LnR3Okrqf,oxJz1a7mUDSk2RBrVsKg3tYI64eHpj))
				GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
				kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡻࡲ࡭ࠩૠ"))
				for cX2SpPxGLmADTKl,XcvFdKRjNLz5wEpDf in reversed(items):
					cX2SpPxGLmADTKl = kkzeVtyGuvFbsDNpYgXLBUZrO6+cX2SpPxGLmADTKl+Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩૡ")+kkzeVtyGuvFbsDNpYgXLBUZrO6
					GjC4atkJLwlTpsI.append(XcvFdKRjNLz5wEpDf)
					CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
				return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
			else: return pbmKZA1w7L4zHjOM(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪૢ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	nUDgc4absePT2xMt = url+W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫૣ")+VChIfEZU37zqWGnL
	if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩ࡫ࡸࡹࡶࠧ૤") not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = zWBnYSGIatjXVC(u"ࠪ࡬ࡹࡺࡰ࠻ࠩ૥")+nUDgc4absePT2xMt
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
def UT75McKxdvgFluwG3ZDb(cX2SpPxGLmADTKl):
	VChIfEZU37zqWGnL = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,lRKCWnNi0Edr984eI(u"ࠫࡺࡸ࡬ࠨ૦"))
	if lRKCWnNi0Edr984eI(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ૧") in cX2SpPxGLmADTKl:
		PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ૨"),cX2SpPxGLmADTKl+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࠧࠨࠪ૩"),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		url,ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		data = {bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨ࡫ࡧࠫ૪"):ccHBj2aGoTKM5DZLv71U0CO,nR0ok9zju84rFUQl1YC(u"ࠩࡶࡩࡷࡼࡥࡳࠩ૫"):QYWvDSNgqBiRaAdn}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡔࡔ࡙ࡔࠨ૬"),url,data,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ૭"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ૮"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if f9fOpCmLAEaW2Go(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ૯") in nUDgc4absePT2xMt:
			headers = {Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ૰"):VChIfEZU37zqWGnL,pYeVwat64v(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ૱"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡊࡉ࡙࠭૲"),nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ૳"))
			gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			items = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ૴"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
			kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡻࡲ࡭ࠩ૵"))
			for cX2SpPxGLmADTKl,XcvFdKRjNLz5wEpDf in reversed(items):
				cX2SpPxGLmADTKl = kkzeVtyGuvFbsDNpYgXLBUZrO6+cX2SpPxGLmADTKl+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ૶")+kkzeVtyGuvFbsDNpYgXLBUZrO6
				GjC4atkJLwlTpsI.append(XcvFdKRjNLz5wEpDf)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
		else: return W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ૷"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	else:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ૸")+VChIfEZU37zqWGnL
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
def yVma6J7eNE(url):
	if w9wfONXUP3(u"ࠩࡳࡳࡸࡺࡩࡥࠩૹ") in url:
		cX2SpPxGLmADTKl = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠴ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧૺ"),url,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if PCnrX0p2QmTt5ijBIkqu4La:
			nUDgc4absePT2xMt,ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			import string as gZlcqzuspvkaLKT
			n8diar79boS3X = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O.join(DDLw3RXCNW.choice(gZlcqzuspvkaLKT.ascii_letters+gZlcqzuspvkaLKT.digits) for _PxoY1uAMUNbRhp8j3Scg0Gv2 in range(pL73X0MYajJQG4n1qgD(u"࠳࠹࿞")))
			BSQrgL3x0DiVOWucCvhP6n7AyRJ = f9fOpCmLAEaW2Go(u"ࠫ࠲࠳࠭࠮࡙ࡨࡦࡐ࡯ࡴࡇࡱࡵࡱࡇࡵࡵ࡯ࡦࡤࡶࡾ࠭ૻ")+n8diar79boS3X
			aNXRWYnbow7s8fpvLVK = {awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫૼ"):slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࡭ࡶ࡮ࡷ࡭ࡵࡧࡲࡵ࠱ࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦࡢࡰࡷࡱࡨࡦࡸࡹ࠾ࠩ૽")+BSQrgL3x0DiVOWucCvhP6n7AyRJ}
			LY97ojMUDA4d = {zWBnYSGIatjXVC(u"ࠢࡑࡱࡶࡸࡎࡊࠢ૾"):ccHBj2aGoTKM5DZLv71U0CO,pL73X0MYajJQG4n1qgD(u"ࠣࡕࡨࡶࡻ࡫ࡲࡊࡆࠥ૿"):QYWvDSNgqBiRaAdn}
			PCnrX0p2QmTt5ijBIkqu4La = []
			for key,value in LY97ojMUDA4d.items(): PCnrX0p2QmTt5ijBIkqu4La.append(f9fOpCmLAEaW2Go(u"ࠩ࠰࠱ࠪࡹ࡜ࡳ࡞ࡱࡇࡴࡴࡴࡦࡰࡷ࠱ࡉ࡯ࡳࡱࡱࡶ࡭ࡹ࡯࡯࡯࠼ࠣࡪࡴࡸ࡭࠮ࡦࡤࡸࡦࡁࠠ࡯ࡣࡰࡩࡂࠨࠥࡴࠤ࡟ࡶࡡࡴ࡜ࡳ࡞ࡱࠩࡸ࠭଀")%(BSQrgL3x0DiVOWucCvhP6n7AyRJ,key,value))
			PCnrX0p2QmTt5ijBIkqu4La.append(pL73X0MYajJQG4n1qgD(u"ࠪ࠱࠲ࠫࡳ࠮࠯ࠪଁ") % BSQrgL3x0DiVOWucCvhP6n7AyRJ)
			bo9ixEyvnlwmW = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡡࡸ࡜࡯ࠩଂ").join(PCnrX0p2QmTt5ijBIkqu4La)
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡖࡏࡔࡖࠪଃ"),nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡓࡉ࡟ࡎࡆࡖ࠰࠵ࡸࡺࠧ଄"))
			cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if pL73X0MYajJQG4n1qgD(u"ࠧࡩࡶࡷࡴࠬଅ") not in cX2SpPxGLmADTKl: return ba49YvOK2Aw8Uhxt(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡐࡔࡊ࡙ࡏࡇࡗࠫଆ"),[],[]
	return nR0ok9zju84rFUQl1YC(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬଇ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
def IR68ycjAWQ(cX2SpPxGLmADTKl):
	if f9fOpCmLAEaW2Go(u"ࠪࡴࡴࡹࡴࡪࡦࠪଈ") in cX2SpPxGLmADTKl:
		PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ଉ"),cX2SpPxGLmADTKl+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࠬࠦࠨଊ"),AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		d9LWiaYycQh = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,pL73X0MYajJQG4n1qgD(u"࠭ࡵࡳ࡮ࠪଋ"))
		url = d9LWiaYycQh+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬଌ")+ccHBj2aGoTKM5DZLv71U0CO+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ଍")+QYWvDSNgqBiRaAdn
		headers = { Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭଎"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O , rAYDiWlzm9MCU6x0GnROua(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ଏ"):jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬଐ") }
		nUDgc4absePT2xMt = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ଑"))
		nUDgc4absePT2xMt = nUDgc4absePT2xMt.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(b6JZWhsCvwOyV041EdQTcu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		return pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ଒"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫଓ") in cX2SpPxGLmADTKl:
		aINuxABv6tbikfO4dzL = nUaVQsoA6EXcK4Odht5wCge0J8Pib
		while awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬଔ") in cX2SpPxGLmADTKl and aINuxABv6tbikfO4dzL<YzlId3Fs6vpehcbLGj0UaO(u"࠸࿟"):
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,pYeVwat64v(u"ࠩࡊࡉ࡙࠭କ"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬଖ"))
			if pbmKZA1w7L4zHjOM(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ଗ") in list(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.keys()): cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers[W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧଘ")]
			aINuxABv6tbikfO4dzL += xD9WeoEAsX7
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	else: return zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪଙ"),[],[]
def IwmHi9nSTN(url):
	LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(url,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࡶࡴ࡯ࠫଚ"))
	headers = {MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩଛ"):LLzkoiPsbBZ,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ଜ"):YwSBWkv2f3Us()}
	if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫଝ") in url:
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ଞ"))
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫଟ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(pL73X0MYajJQG4n1qgD(u"࠭ࡨࡵࡶࡳࡷࠬଠ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡩࡶࡷࡴࠬଡ"))
			return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	else:
		JJlAVRsp7gu4jTtm = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡉࡈࡘࠬଢ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫଣ"))
		R8AE9e4mYxVhusL3Q = JJlAVRsp7gu4jTtm.content
		aNXRWYnbow7s8fpvLVK = headers.copy()
		if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡣࡱࡴ࡫ࡠࠩତ") in str(JJlAVRsp7gu4jTtm.cookies):
			cookies = JJlAVRsp7gu4jTtm.cookies
			aNXRWYnbow7s8fpvLVK[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫଥ")] = WDg18QHF3rze(g726UBevLKbpyh8o35Z4fdPiRrn9uG(cookies))
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(rAYDiWlzm9MCU6x0GnROua(u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨଦ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not cX2SpPxGLmADTKl: return zWBnYSGIatjXVC(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩଧ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
		else:
			cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib])+Zb5cNeHWi6jP9SCYtUgR(u"ࠧࠧࡦࡀ࠵ࠬନ")
			wc09TNn7BAMLv8ViCghs2aDjz3 = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡉࡈࡘࠬ଩"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫପ"))
			R8AE9e4mYxVhusL3Q = wc09TNn7BAMLv8ViCghs2aDjz3.content
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(CCWqR3dmtzw6xoIX41(u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଫ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl:
				cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
				if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡲࡶ࠴ࠨବ") in cX2SpPxGLmADTKl and pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࠵ࡤ࠰ࠩଭ") in cX2SpPxGLmADTKl: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
				else: return pbmKZA1w7L4zHjOM(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩମ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫଯ"),[],[]
def uF1nZJ3EDU(cX2SpPxGLmADTKl):
	if pL73X0MYajJQG4n1qgD(u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬର") in cX2SpPxGLmADTKl:
		headers = {pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ଱"):fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫଲ")}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,kAz7WRYjrfGm(u"ࠫࡌࡋࡔࠨଳ"),cX2SpPxGLmADTKl,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ba49YvOK2Aw8Uhxt(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ଴"))
		url = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if url: return nR0ok9zju84rFUQl1YC(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩଵ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	else:
		PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨଶ"),cX2SpPxGLmADTKl,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if not PCnrX0p2QmTt5ijBIkqu4La: PCnrX0p2QmTt5ijBIkqu4La = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫଷ"),cX2SpPxGLmADTKl,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		ccHBj2aGoTKM5DZLv71U0CO,QYWvDSNgqBiRaAdn = PCnrX0p2QmTt5ijBIkqu4La[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡸࡶࡱ࠭ସ"))
		url = LLzkoiPsbBZ+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫହ")
		data = {w9wfONXUP3(u"ࠫ࡮ࡪࠧ଺"):ccHBj2aGoTKM5DZLv71U0CO,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬ࡯ࠧ଻"):QYWvDSNgqBiRaAdn}
		headers = {B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩ଼ࠩ"):pYeVwat64v(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨଽ"),lRKCWnNi0Edr984eI(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩା"):cX2SpPxGLmADTKl}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡓࡓࡘ࡚ࠧି"),url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬୀ"))
		gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩୁ"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if nUDgc4absePT2xMt:
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			return Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨୂ"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	return rAYDiWlzm9MCU6x0GnROua(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪୃ"),[],[]
def ZvMNFVRsio1H(GiA7T8bB5XPtM):
	Kqh6fwC1o0 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨୄ"))
	headers = {f9fOpCmLAEaW2Go(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ୅"):Kqh6fwC1o0} if Kqh6fwC1o0 else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,lRKCWnNi0Edr984eI(u"ࠩࡊࡉ࡙࠭୆"),GiA7T8bB5XPtM,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪେ"))
	A7rgTeoRdnFxcKvbSUBVZlsqI = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	s8EM1qARji6nrOHDvL = str(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers)
	uubmdYTtpHs2PDzIc6UVgZALq8e = s8EM1qARji6nrOHDvL+A7rgTeoRdnFxcKvbSUBVZlsqI
	if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠳ࡳࡰ࠵ࠩୈ") in uubmdYTtpHs2PDzIc6UVgZALq8e: A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = NFGqKBLtvUZn1S3dau
	else:
		R8veQ72zOTgodrPftJFXaljC,jb7G0mIu2nD,RhopD9bxzyOq1IBYaJP,qdgpsKEmioD09nv73wVteQB,A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS
		captcha = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"ࠬࡶࡡࡨࡧ࠰ࡶࡪࡪࡩࡳࡧࡦࡸ࠳࠰࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵ࡬ࡸࡪࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ୉"),A7rgTeoRdnFxcKvbSUBVZlsqI,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if captcha: RhopD9bxzyOq1IBYaJP,qdgpsKEmioD09nv73wVteQB = captcha[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		UDR0ehHy2srNwc9pL5WK1Fn4bkvfgi = drzqWFkSHD.SITESURLS[rAYDiWlzm9MCU6x0GnROua(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭୊")][f9fOpCmLAEaW2Go(u"࠻࿠")]
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			data = {B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡶࡵࡨࡶࠬୋ"):drzqWFkSHD.AV_CLIENT_IDS,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩୌ"):FLRQJnBHTvsXU,lRKCWnNi0Edr984eI(u"ࠩࡸࡶࡱ୍࠭"):GiA7T8bB5XPtM,kAz7WRYjrfGm(u"ࠪ࡯ࡪࡿࠧ୎"):qdgpsKEmioD09nv73wVteQB,f9fOpCmLAEaW2Go(u"ࠫ࡮ࡪࠧ୏"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡰ࡯ࡣࠩ୐"):YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧ୑")}
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡑࡑࡖࡘࠬ୒"),UDR0ehHy2srNwc9pL5WK1Fn4bkvfgi,data,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨ୓"))
			R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		R8AE9e4mYxVhusL3Q = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if R8AE9e4mYxVhusL3Q.startswith(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡘࡖࡑ࡙࠽ࠨ୔")):
			ZvsEFTCDcPL = rKY1tyQvh9OCxE2nl(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡰ࡮ࡹࡴࠨ୕"),R8AE9e4mYxVhusL3Q.split(djapWhrveLJbgnViDftFNY05ylq1S(u"࡚ࠫࡘࡌࡔ࠿ࠪୖ"),xD9WeoEAsX7)[xD9WeoEAsX7])
			for eBjxVKSvQC1 in ZvsEFTCDcPL:
				url = eBjxVKSvQC1[kAz7WRYjrfGm(u"ࠬࡻࡲ࡭ࠩୗ")]
				FH4TbrYnONxie = eBjxVKSvQC1[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭୘")]
				data = eBjxVKSvQC1[GTmHXIZUSdxRhMnqQKkO(u"ࠧࡥࡣࡷࡥࠬ୙")]
				headers = eBjxVKSvQC1[rAYDiWlzm9MCU6x0GnROua(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ୚")]
				gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,FH4TbrYnONxie,url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ୛"))
				A7rgTeoRdnFxcKvbSUBVZlsqI = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
				if W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࠲ࡲࡶ࠴ࠨଡ଼") in A7rgTeoRdnFxcKvbSUBVZlsqI:
					A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = NFGqKBLtvUZn1S3dau
					break
				s8EM1qARji6nrOHDvL = str(gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers)
				uubmdYTtpHs2PDzIc6UVgZALq8e = s8EM1qARji6nrOHDvL+A7rgTeoRdnFxcKvbSUBVZlsqI
				R8veQ72zOTgodrPftJFXaljC = AxTYMhRlfyskNc0X19dvwtS.findall(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࡞ࡺ࠯࠮࠴ࠪࡀࠤࠫࡩࡾࡐ࠮ࠫࡁࠬࠦࠬଢ଼"),uubmdYTtpHs2PDzIc6UVgZALq8e,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				jb7G0mIu2nD = AxTYMhRlfyskNc0X19dvwtS.findall(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴ࠮ࠫࡁࠥࠬ࠵࠹ࡁ࠯ࠬࡂ࠭ࠧ࠭୞"),uubmdYTtpHs2PDzIc6UVgZALq8e,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if jb7G0mIu2nD: jb7G0mIu2nD = jb7G0mIu2nD[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				if R8veQ72zOTgodrPftJFXaljC or jb7G0mIu2nD: break
		if not A0DvrNp1LJuZObd2EeUg6kmtnWI4F8:
			if not R8veQ72zOTgodrPftJFXaljC:
				if captcha and not jb7G0mIu2nD:
					if xD9WeoEAsX7: jb7G0mIu2nD = lraO5C2IRhob7jvGTdu9Dkf4(qdgpsKEmioD09nv73wVteQB,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡡࡳࠩୟ"),GiA7T8bB5XPtM)
					else:
						if not R8AE9e4mYxVhusL3Q.startswith(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡊࡆࡀࠫୠ")):
							data = {KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡷࡶࡩࡷ࠭ୡ"):drzqWFkSHD.AV_CLIENT_IDS,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪୢ"):FLRQJnBHTvsXU,lRKCWnNi0Edr984eI(u"ࠪࡹࡷࡲࠧୣ"):GiA7T8bB5XPtM,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡰ࡫ࡹࠨ୤"):qdgpsKEmioD09nv73wVteQB,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬ࡯ࡤࠨ୥"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"࠭ࡪࡰࡤࠪ୦"):JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡨࡧࡷ࡭ࡩ࠭୧")}
							gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡒࡒࡗ࡙࠭୨"),UDR0ehHy2srNwc9pL5WK1Fn4bkvfgi,data,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩ୩"))
							R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
						else: R8AE9e4mYxVhusL3Q = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫ୪")
						if R8AE9e4mYxVhusL3Q.startswith(pYeVwat64v(u"ࠫࡎࡊ࠽ࠨ୫")):
							yQ8NtkrnzMGbu9Li5 = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫ୬"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
							eg7JYAXEMjuLB0Q6DW5m2,Wzw7OA1X9P0iTJElDsVgB2MC8m = yQ8NtkrnzMGbu9Li5[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
							mlrXUnyLzPAhEIj8ix5Ztpu = pL73X0MYajJQG4n1qgD(u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫ୭")+Wzw7OA1X9P0iTJElDsVgB2MC8m+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࠡอส๊๏ฯࠧ୮")
							BEjxl7fs2e = QHi2JtdhMaw0INlU()
							BEjxl7fs2e.create(f9fOpCmLAEaW2Go(u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧ୯"),mlrXUnyLzPAhEIj8ix5Ztpu)
							Q14Q6ZMdnxqR9HPyf7YrSW8bTG0 = f7epsRlYtMz4.time()
							OkrJv5pwsMFTQlEBhDib1Kodux94,aaY0BtdlWZR5OKTvc = nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib
							while OkrJv5pwsMFTQlEBhDib1Kodux94<int(Wzw7OA1X9P0iTJElDsVgB2MC8m):
								jRhY6cet0NVsfGIr(BEjxl7fs2e,int(OkrJv5pwsMFTQlEBhDib1Kodux94/int(Wzw7OA1X9P0iTJElDsVgB2MC8m)*YzlId3Fs6vpehcbLGj0UaO(u"࠶࠶࠰࿡")),mlrXUnyLzPAhEIj8ix5Ztpu,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Wzw7OA1X9P0iTJElDsVgB2MC8m+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࠣ࠳ࠥ࠭୰")+str(int(OkrJv5pwsMFTQlEBhDib1Kodux94))+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࠤࠥัว็์ฬࠫୱ"))
								if OkrJv5pwsMFTQlEBhDib1Kodux94>aaY0BtdlWZR5OKTvc+pbmKZA1w7L4zHjOM(u"࠷࠰࿢"):
									data = {B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡺࡹࡥࡳࠩ୲"):drzqWFkSHD.AV_CLIENT_IDS,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭୳"):FLRQJnBHTvsXU,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡵࡳ࡮ࠪ୴"):GiA7T8bB5XPtM,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࡬ࡧࡼࠫ୵"):qdgpsKEmioD09nv73wVteQB,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨ࡫ࡧࠫ୶"):eg7JYAXEMjuLB0Q6DW5m2,W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡭ࡳࡧ࠭୷"):JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬ୸")}
									gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡕࡕࡓࡕࠩ୹"),UDR0ehHy2srNwc9pL5WK1Fn4bkvfgi,data,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ୺"))
									R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
									if R8AE9e4mYxVhusL3Q.startswith(YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡔࡐࡍࡈࡒࡂ࠭୻")):
										jb7G0mIu2nD = R8AE9e4mYxVhusL3Q.split(nR0ok9zju84rFUQl1YC(u"ࠧࡕࡑࡎࡉࡓࡃࠧ୼"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠱࿣"))[xD9WeoEAsX7]
										break
									aaY0BtdlWZR5OKTvc = OkrJv5pwsMFTQlEBhDib1Kodux94
								else: f7epsRlYtMz4.sleep(xD9WeoEAsX7)
								OkrJv5pwsMFTQlEBhDib1Kodux94 = f7epsRlYtMz4.time()-Q14Q6ZMdnxqR9HPyf7YrSW8bTG0
							BEjxl7fs2e.close()
				if jb7G0mIu2nD:
					GM59KlcsjqrEhiB6R21ubtxP = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.cookies
					b3bTeswNBmgvXkSztuOdPc8 = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ୽"),uubmdYTtpHs2PDzIc6UVgZALq8e,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					if KKCrwPdOgGl(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ୾") in list(GM59KlcsjqrEhiB6R21ubtxP.keys()): b3bTeswNBmgvXkSztuOdPc8 = GM59KlcsjqrEhiB6R21ubtxP[I6Bfzysrvb8DONZ(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪ୿")]
					elif b3bTeswNBmgvXkSztuOdPc8: b3bTeswNBmgvXkSztuOdPc8 = b3bTeswNBmgvXkSztuOdPc8[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
					captcha = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ஀"),A7rgTeoRdnFxcKvbSUBVZlsqI,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					if captcha: RhopD9bxzyOq1IBYaJP,qdgpsKEmioD09nv73wVteQB = captcha[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
					if b3bTeswNBmgvXkSztuOdPc8 and captcha:
						headers = {lRKCWnNi0Edr984eI(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ஁"):Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠧஂ")+b3bTeswNBmgvXkSztuOdPc8,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨஃ"):GiA7T8bB5XPtM,ba49YvOK2Aw8Uhxt(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ஄"):pL73X0MYajJQG4n1qgD(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨஅ")}
						data = lRKCWnNi0Edr984eI(u"ࠪ࡫࠲ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡴࡨࡷࡵࡵ࡮ࡴࡧࡀࠫஆ")+jb7G0mIu2nD
						gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nR0ok9zju84rFUQl1YC(u"ࠫࡕࡕࡓࡕࠩஇ"),RhopD9bxzyOq1IBYaJP,data,headers,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬஈ"))
						A7rgTeoRdnFxcKvbSUBVZlsqI = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
						try: cookies = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.cookies
						except: cookies = {}
						R8veQ72zOTgodrPftJFXaljC = AxTYMhRlfyskNc0X19dvwtS.findall(ba49YvOK2Aw8Uhxt(u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧஉ"),str(cookies),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if R8veQ72zOTgodrPftJFXaljC:
				usYnJBXhFT,R8veQ72zOTgodrPftJFXaljC = R8veQ72zOTgodrPftJFXaljC[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				Kqh6fwC1o0 = usYnJBXhFT+YzlId3Fs6vpehcbLGj0UaO(u"ࠧ࠾ࠩஊ")+R8veQ72zOTgodrPftJFXaljC
				xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ஋"),Kqh6fwC1o0)
				w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,Zb5cNeHWi6jP9SCYtUgR(u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭஌"))
				if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ࠲ࡲࡶ࠴ࠨ஍") not in A7rgTeoRdnFxcKvbSUBVZlsqI:
					headers = {pbmKZA1w7L4zHjOM(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫஎ"):Kqh6fwC1o0}
					gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡍࡅࡕࠩஏ"),GiA7T8bB5XPtM,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭ஐ"))
					A7rgTeoRdnFxcKvbSUBVZlsqI = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		if captcha and not A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 and not Kqh6fwC1o0: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,kAz7WRYjrfGm(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧ஑"))
	return A7rgTeoRdnFxcKvbSUBVZlsqI
def R7N1PDkgeU(url,YYTAkfz3NaQrLuCyRE,XcvFdKRjNLz5wEpDf):
	dU17fayKLj4kABu,lFL9QtV2u1pa7WoieSmv3YzZPb = [],[]
	GiA7T8bB5XPtM = url
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,w9wfONXUP3(u"ࠨࡉࡈࡘࠬஒ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨஓ"))
	gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	v1s43bg6ljFm = []
	if kAz7WRYjrfGm(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫஔ") in gwiPcfVU0T4qHMDF3Wdeh7YK or vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨக") in gwiPcfVU0T4qHMDF3Wdeh7YK:
		GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall(pbmKZA1w7L4zHjOM(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬ஖"),gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if GtnfmdqIOijegYu:
			for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
				BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ஗"),IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				for cX2SpPxGLmADTKl,title in BA01W9olieErLycV7kwFvOhH5Y3ms:
					if cX2SpPxGLmADTKl in dU17fayKLj4kABu: continue
					if w9wfONXUP3(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ஘") not in cX2SpPxGLmADTKl and KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬங") not in cX2SpPxGLmADTKl: continue
					if slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩสࠫச") not in title:
						v1s43bg6ljFm.append((title,cX2SpPxGLmADTKl))
						continue
					title = title.replace(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫ஛"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࠥ࠳ࠠࠨஜ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
					if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡹࡰࡢࡰࠪ஝") in title: continue
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
					lFL9QtV2u1pa7WoieSmv3YzZPb.append(title)
			for title,cX2SpPxGLmADTKl in v1s43bg6ljFm:
				if cX2SpPxGLmADTKl not in dU17fayKLj4kABu:
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
					lFL9QtV2u1pa7WoieSmv3YzZPb.append(title)
			qNmsBD1jJZVzcxi4onKuAOIC = nUaVQsoA6EXcK4Odht5wCge0J8Pib
			if len(dU17fayKLj4kABu)>xD9WeoEAsX7:
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(lRKCWnNi0Edr984eI(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭ஞ"),lFL9QtV2u1pa7WoieSmv3YzZPb)
				if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return KKCrwPdOgGl(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬட"),[],[]
			if dU17fayKLj4kABu and qNmsBD1jJZVzcxi4onKuAOIC>=nUaVQsoA6EXcK4Odht5wCge0J8Pib: GiA7T8bB5XPtM = dU17fayKLj4kABu[qNmsBD1jJZVzcxi4onKuAOIC]
	A7rgTeoRdnFxcKvbSUBVZlsqI = ZvMNFVRsio1H(GiA7T8bB5XPtM)
	CBL4OQVtWbMAycUGl7Ex2SKZF,GjC4atkJLwlTpsI = [],[]
	if YYTAkfz3NaQrLuCyRE==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ஠"):
		XfeNaHGg0oYL4MUI3kz = AxTYMhRlfyskNc0X19dvwtS.findall(I6Bfzysrvb8DONZ(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ஡"),A7rgTeoRdnFxcKvbSUBVZlsqI,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if XfeNaHGg0oYL4MUI3kz:
			cX2SpPxGLmADTKl = WDg18QHF3rze(XfeNaHGg0oYL4MUI3kz[nUaVQsoA6EXcK4Odht5wCge0J8Pib])
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			GjC4atkJLwlTpsI.append(XcvFdKRjNLz5wEpDf)
	elif YYTAkfz3NaQrLuCyRE==vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡻࡦࡺࡣࡩࠩ஢"):
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ண"),A7rgTeoRdnFxcKvbSUBVZlsqI,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,size in BA01W9olieErLycV7kwFvOhH5Y3ms:
			if not cX2SpPxGLmADTKl: continue
			if XcvFdKRjNLz5wEpDf in size:
				GjC4atkJLwlTpsI.append(size)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
				break
		if not CBL4OQVtWbMAycUGl7Ex2SKZF:
			for cX2SpPxGLmADTKl,size in BA01W9olieErLycV7kwFvOhH5Y3ms:
				if not cX2SpPxGLmADTKl: continue
				GjC4atkJLwlTpsI.append(size)
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if not CBL4OQVtWbMAycUGl7Ex2SKZF: return YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭த"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def gCTbXtFaP3(url,usYnJBXhFT):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,pL73X0MYajJQG4n1qgD(u"࠭ࡇࡆࡖࠪ஥"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭஦"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cookies = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.cookies
	if JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ஧") in list(cookies.keys()):
		Kqh6fwC1o0 = cookies[vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩந")]
		Kqh6fwC1o0 = WDg18QHF3rze(kd8ZhJPCe7QzxLgij3TEHlGtOv(Kqh6fwC1o0))
		items = AxTYMhRlfyskNc0X19dvwtS.findall(zWBnYSGIatjXVC(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫன"),Kqh6fwC1o0,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		nUDgc4absePT2xMt = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(kAz7WRYjrfGm(u"ࠫࡡ࠵ࠧப"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࠵ࠧ஫"))
		nUDgc4absePT2xMt = kd8ZhJPCe7QzxLgij3TEHlGtOv(nUDgc4absePT2xMt)
	else: nUDgc4absePT2xMt = url
	if ba49YvOK2Aw8Uhxt(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ஬") in nUDgc4absePT2xMt:
		DDhbYKecXqtB2MakjOEpzVA = nUDgc4absePT2xMt.split(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࠦ࠴ࡉࠫ஭"))[-xD9WeoEAsX7]
		nUDgc4absePT2xMt = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫம")+DDhbYKecXqtB2MakjOEpzVA
		return f9fOpCmLAEaW2Go(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬய"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[nUDgc4absePT2xMt]
	else:
		website = drzqWFkSHD.SITESURLS[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡅࡐࡕࡁࡎࠩர")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,CCWqR3dmtzw6xoIX41(u"ࠫࡌࡋࡔࠨற"),website,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NFGqKBLtvUZn1S3dau,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫல"))
		khQTvaW0yw9l4qdmBYMXN2GDb81 = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.url
		bkDX6uGHAc7OENTxrzSyUljia28 = nUDgc4absePT2xMt.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࠯ࠨள"))[H3OKMjDG1evnl4Ruiz]
		oStDybJYzrfm7TNvek = khQTvaW0yw9l4qdmBYMXN2GDb81.split(pL73X0MYajJQG4n1qgD(u"ࠧ࠰ࠩழ"))[H3OKMjDG1evnl4Ruiz]
		jYfvU9egTX62nrukVcoKEAyq = nUDgc4absePT2xMt.replace(bkDX6uGHAc7OENTxrzSyUljia28,oStDybJYzrfm7TNvek)
		headers = { hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬவ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O , fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬஶ"):KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫஷ") , I6Bfzysrvb8DONZ(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬஸ"):jYfvU9egTX62nrukVcoKEAyq }
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡖࡏࡔࡖࠪஹ"), jYfvU9egTX62nrukVcoKEAyq, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O, headers, pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬ஺"))
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		items = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ஻"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if not items:
			items = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ஼"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
			if not items:
				items = AxTYMhRlfyskNc0X19dvwtS.findall(YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ஽"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.IGNORECASE)
		if items:
			cX2SpPxGLmADTKl = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib].replace(YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡠ࠴࠭ா"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠴࠭ி"))
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.rstrip(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࠵ࠧீ"))
			if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡨࡵࡶࡳࠫு") not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡩࡶࡷࡴ࠿࠭ூ") + cX2SpPxGLmADTKl
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ௃"),nR0ok9zju84rFUQl1YC(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ௄"))
			if usYnJBXhFT==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
			else: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = f9fOpCmLAEaW2Go(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭௅"),[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
		else: Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = CCWqR3dmtzw6xoIX41(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬெ"),[],[]
		return Oo4wEPUfp2v05kqryhlH6cBgDiMYL,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def oxzWbwY7Grpeh6TO0BE(url):
	headers = { djapWhrveLJbgnViDftFNY05ylq1S(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩே") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪை"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ௉"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF,errno = [],[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if items:
		for cX2SpPxGLmADTKl,AAB086Sqz9xc in items:
			GjC4atkJLwlTpsI.append(AAB086Sqz9xc)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return lRKCWnNi0Edr984eI(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧொ"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def DrGMk2t9S43bnC0BiI1fdUaFg7XQmv(url):
	GKBq5DJiV9YMl4Fma3gr = url.split(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩ࠲ࠫோ"))[hWRvZOYtjme9QNnV41u0Mswb(u"࠴࿤")]
	data = pYeVwat64v(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠨ࡬ࡨࡂ࠭ௌ")+GKBq5DJiV9YMl4Fma3gr
	headers = {pbmKZA1w7L4zHjOM(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧ்ࠪ"):djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ௎")}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡐࡐࡕࡗࠫ௏"),url,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡗࡊࡌ࠮࠳ࡶࡸࠬௐ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = AxTYMhRlfyskNc0X19dvwtS.findall(pbmKZA1w7L4zHjOM(u"ࠨࡣࡧࡦࡱࡵࡣ࡬ࡡࡧࡩࡹ࡫ࡣࡵࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௑"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		url = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	return nR0ok9zju84rFUQl1YC(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡘࡄࡍࠩ௒"),[],[]
def GtoOrzB0nklW3cIfZQpu(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡋࡊ࡚ࠧ௓"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡍ࠰࠵ࡸࡺࠧ௔"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	try: R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.decode(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡻࡴࡧ࠺ࠪ௕"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡩࡨࡰࡲࡶࡪ࠭௖"))
	except: pass
	items = AxTYMhRlfyskNc0X19dvwtS.findall(W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡥࡱࡦࡷࡤࡴ࡯ࡠࡲࡵࡩࡻ࡯ࡥࡸࡡࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨௗ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		url = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	else:
		Oo4wEPUfp2v05kqryhlH6cBgDiMYL = AxTYMhRlfyskNc0X19dvwtS.findall(nR0ok9zju84rFUQl1YC(u"ࠨࠤࡹ࡭ࡩ࡫࡯ࡠࡧࡻࡸࡤࡳࡳࡨࠤࡁࡠࡳ࠱ࠨ࠯ࠬࡂ࠭ࡡࡴࠫ࠽ࠩ௘"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if Oo4wEPUfp2v05kqryhlH6cBgDiMYL: return Oo4wEPUfp2v05kqryhlH6cBgDiMYL[GTmHXIZUSdxRhMnqQKkO(u"࠲࿥")][:pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠺࠴࿦")],[],[]
	return nR0ok9zju84rFUQl1YC(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡑࠧ௙"),[],[]
def E9143psThcGzmOD8Vtu2(url):
	headers = {pbmKZA1w7L4zHjOM(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ௚"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ௛"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(KKCrwPdOgGl(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ௜"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		url = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+f9fOpCmLAEaW2Go(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ௝")+url
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	return JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩ௞"),[],[]
def HHmg4AJfXeCTZKPEcav9M(url):
	url = url.strip(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ࠱ࠪ௟"))
	if YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ௠") in url: DDhbYKecXqtB2MakjOEpzVA = url.split(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪ࠳ࠬ௡"))[gybxTLFEw2]
	else: DDhbYKecXqtB2MakjOEpzVA = url.split(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࠴࠭௢"))[-xD9WeoEAsX7]
	url = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩ௣") + DDhbYKecXqtB2MakjOEpzVA
	headers = { w9wfONXUP3(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ௤") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ௥"))
	R8AE9e4mYxVhusL3Q = R8AE9e4mYxVhusL3Q.replace(pL73X0MYajJQG4n1qgD(u"ࠨ࡞࡟ࠫ௦"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	items = AxTYMhRlfyskNc0X19dvwtS.findall(f9fOpCmLAEaW2Go(u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ௧"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[ items[nUaVQsoA6EXcK4Odht5wCge0J8Pib] ]
	return djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧ௨"),[],[]
def qH0xPgy93Gzft6wAi8mQLd(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫ௩"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ௪"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	for cX2SpPxGLmADTKl,AAB086Sqz9xc,HHkxhWYbrAnGKq1 in items:
		GjC4atkJLwlTpsI.append(AAB086Sqz9xc+WRsuxHTjDgYCIpoMQzLFAtS8rikP+HHkxhWYbrAnGKq1)
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨ௫"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def Li90KCPhzduwRZGAol5QXY4tx(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ௬"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(KKCrwPdOgGl(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ௭"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	items = set(items)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	for DDhbYKecXqtB2MakjOEpzVA,t5fhagjUGXk0ynOlJWeAb,teKf52yDwBrI4FZq,AAB086Sqz9xc,HHkxhWYbrAnGKq1 in items:
		url = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭௮")+DDhbYKecXqtB2MakjOEpzVA+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ௯")+t5fhagjUGXk0ynOlJWeAb+GTmHXIZUSdxRhMnqQKkO(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ௰")+teKf52yDwBrI4FZq
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CCWqR3dmtzw6xoIX41(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ௱"))
		items = AxTYMhRlfyskNc0X19dvwtS.findall(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௲"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl in items:
			GjC4atkJLwlTpsI.append(AAB086Sqz9xc+WRsuxHTjDgYCIpoMQzLFAtS8rikP+HHkxhWYbrAnGKq1)
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	if len(CBL4OQVtWbMAycUGl7Ex2SKZF)==nUaVQsoA6EXcK4Odht5wCge0J8Pib: return KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭௳"),[],[]
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
def Rp21U6kBKzlnfiIFZwJa(url):
	cX2SpPxGLmADTKl = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡍࡨࡽࡂ࠭௴") not in url:
		nUDgc4absePT2xMt = url.replace(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭௵"),ba49YvOK2Aw8Uhxt(u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ௶"))
		nUDgc4absePT2xMt = nUDgc4absePT2xMt.split(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫ࠴࠭௷"))
		DDhbYKecXqtB2MakjOEpzVA = nUDgc4absePT2xMt[anb4QpyjlmgVwANP]
		nUDgc4absePT2xMt = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠵ࠧ௸").join(nUDgc4absePT2xMt[nUaVQsoA6EXcK4Odht5wCge0J8Pib:gybxTLFEw2])
		dXG96SRYbe = {bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡩࡥࠩ௹"):DDhbYKecXqtB2MakjOEpzVA,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡰࡲࠪ௺"):w9wfONXUP3(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ௻"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧ௼"):lRKCWnNi0Edr984eI(u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪ௽")}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡕࡕࡓࡕࠩ௾"),nUDgc4absePT2xMt,dXG96SRYbe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠲ࡵࡷࠫ௿"))
		cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.get(hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨఀ")) or gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.get(YzlId3Fs6vpehcbLGj0UaO(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩఁ")) or VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if not cX2SpPxGLmADTKl and gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
			R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall(kAz7WRYjrfGm(u"ࠨ࡫ࡧࡁࠧࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬం"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡊࡉ࡙࠭ః"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩఄ"))
		cX2SpPxGLmADTKl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.get(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭అ")) or gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers.get(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧఆ")) or VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if cX2SpPxGLmADTKl: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	return pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧఇ"),[],[]
def bmua0qOBZrSMn6P5RcGhxzV7jyUH2(url):
	headers = { JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫఈ") : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪఉ"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨఊ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [],[]
	if items:
		GjC4atkJLwlTpsI.append(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡱࡵ࠺ࠧఋ"))
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(items[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7])
		GjC4atkJLwlTpsI.append(f9fOpCmLAEaW2Go(u"ࠫࡲ࠹ࡵ࠹ࠩఌ"))
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(items[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib])
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF
	else: return W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡋࡌ࡚ࡎࡊࡅࡐࠩ఍"),[],[]
def AA2VrR8U0iDlmj5gwIfkKhWLupOo(url):
	CoFhVUrItm2OPNzakjb7wTQ3ul18Xn = url.split(I6Bfzysrvb8DONZ(u"࠭࠯ࠨఎ"))[-xD9WeoEAsX7]
	CoFhVUrItm2OPNzakjb7wTQ3ul18Xn = CoFhVUrItm2OPNzakjb7wTQ3ul18Xn.split(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࠧࠩఏ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	CoFhVUrItm2OPNzakjb7wTQ3ul18Xn = CoFhVUrItm2OPNzakjb7wTQ3ul18Xn.replace(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪఐ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	EgAUQnSxLHwYz = drzqWFkSHD.SITESURLS[GTmHXIZUSdxRhMnqQKkO(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ఑")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭ఒ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn
	ggZG182rVfaMiolKCdjE = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࠧఓ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn
	DNTxgeJIKdhLH9qZYnB1U,YYQLPSo3cZNBx9vmA85 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	gqjko4Dv8CFztmK7PZbyhE = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	d9E1ri3BZcpfPSMDXmQqw,mUcBGLls4CubXQWkj1392fY = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{}
	jgmYcNVeaBhyPvO,WC2Vy5BvLIKmA = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{}
	headers = {lRKCWnNi0Edr984eI(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩఔ"):VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
	B2Xex34ilkh1K = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if xD9WeoEAsX7:
		dayk7sGOVAiul9q,qtZFO9Gk3JEv012TiHwgyNdK,a7akh9HWO4JvCTP,D2uAksXHVKJ = [],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib and not dayk7sGOVAiul9q:
			tGUzx9IYVD1T3Nevm = headers.copy()
			tGUzx9IYVD1T3Nevm.update({KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡘ࠮ࡔࡤࡴ࡮ࡪࡡࡱ࡫࠰ࡌࡴࡹࡴࠨక"):Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡦࡤࡸࡦࡨࡡࡴࡧ࠰ࡥࡳࡪ࠭ࡴࡣࡹࡩࡷ࠴ࡰ࠯ࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧఖ"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨ࡚࠰ࡖࡦࡶࡩࡥࡣࡳ࡭࠲ࡑࡥࡺࠩగ"):KKCrwPdOgGl(u"ࠩ࠷࠸࡫࠺࠰࠹ࡦ࠷ࡥ࠷ࡳࡳࡩ࠳ࡥ࠷ࡧࡪ࠴࠺ࡣ࠹࠸࠽࠷࠷ࡧ࠷ࡳ࠵࠵࠷࠰࠴ࡨ࡭ࡷࡳ࠺ࡡ࠵࠳࠺ࡪࡨ࠻࠳࠱࠶࠵ࠫఘ")})
			sFi6cZKSANDM7H4xJXeuzVLo = kAz7WRYjrfGm(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪࡡࡵࡣࡥࡥࡸ࡫࠭ࡢࡰࡧ࠱ࡸࡧࡶࡦࡴ࠱ࡴ࠳ࡸࡡࡱ࡫ࡧࡥࡵ࡯࠮ࡤࡱࡰ࠳࡛࡯ࡤࡦࡱࡢ࡭ࡳ࡬࡯ࡳ࡯ࡤࡸ࡮ࡵ࡮࠯ࡲ࡫ࡴ࠴ࡅࡩࡥ࠿ࠪఙ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn
			nm7eJAXsTWk389oRHyGN2Kb = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡌࡋࡔࠨచ"),sFi6cZKSANDM7H4xJXeuzVLo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,tGUzx9IYVD1T3Nevm,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠳ࡶࡩ࠭ఛ"))
			EcSgq9FRv1r = nm7eJAXsTWk389oRHyGN2Kb.content
			dayk7sGOVAiul9q = WWNb0XnUxOPL9gF.loads(EcSgq9FRv1r)
			mUcBGLls4CubXQWkj1392fY = dayk7sGOVAiul9q
		if xD9WeoEAsX7 and not dayk7sGOVAiul9q:
			sFi6cZKSANDM7H4xJXeuzVLo = KKCrwPdOgGl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡶࡧࡰࡵ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡳࡵࡴࡨࡥࡲࡅࡣࡰ࡯ࡰࡥࡳࡪ࠽࠮࠯ࡧࡹࡲࡶ࠭࡫ࡵࡲࡲࠥ࠳࠭࡯ࡱ࠰ࡻࡦࡸ࡮ࡪࡰࡪࡷࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪజ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn
			nm7eJAXsTWk389oRHyGN2Kb = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,pYeVwat64v(u"ࠧࡈࡇࡗࠫఝ"),sFi6cZKSANDM7H4xJXeuzVLo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩఞ"))
			EcSgq9FRv1r = nm7eJAXsTWk389oRHyGN2Kb.content
			EcSgq9FRv1r = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡾࠦࠬట")+EcSgq9FRv1r.split(zWBnYSGIatjXVC(u"ࠪࡨࡦࡺࡡ࠻ࠢࡾࠦࠬఠ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠵࿧"))[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠵࿧")].split(GTmHXIZUSdxRhMnqQKkO(u"ࠫࡩࡧࡴࡢ࠼ࠣࡇࡴࡳ࡭ࠨడ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠵࿧"))[lRKCWnNi0Edr984eI(u"࠵࿨")].strip()
			irjPCy0Qof9Icu4tVTSd1OZbp = WWNb0XnUxOPL9gF.loads(EcSgq9FRv1r)
			dayk7sGOVAiul9q = irjPCy0Qof9Icu4tVTSd1OZbp.get(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ఢ"),[])
			a7akh9HWO4JvCTP = irjPCy0Qof9Icu4tVTSd1OZbp.get(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡣࡩࡣࡱࡲࡪࡲࠧణ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			qtZFO9Gk3JEv012TiHwgyNdK = irjPCy0Qof9Icu4tVTSd1OZbp.get(YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࠫత"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			D2uAksXHVKJ = irjPCy0Qof9Icu4tVTSd1OZbp.get(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫథ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		if xD9WeoEAsX7 and not dayk7sGOVAiul9q:
			tGUzx9IYVD1T3Nevm = headers.copy()
			tGUzx9IYVD1T3Nevm.update({pbmKZA1w7L4zHjOM(u"࡛ࠩ࠱ࡗࡧࡰࡪࡦࡤࡴ࡮࠳ࡈࡰࡵࡷࠫద"):vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡸ࡫ࡡࡳࡥ࡫࠱ࡦࡴࡤ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴ࠳ࡸࡡࡱ࡫ࡧࡥࡵ࡯࠮ࡤࡱࡰࠫధ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࡝࠳ࡒࡢࡲ࡬ࡨࡦࡶࡩ࠮ࡍࡨࡽࠬన"):W2Vv30i8qxSuItfsolPLdFZA(u"ࠬ࠺࠴ࡧ࠶࠳࠼ࡩ࠺ࡡ࠳࡯ࡶ࡬࠶ࡨ࠳ࡣࡦ࠷࠽ࡦ࠼࠴࠹࠳࠺ࡪ࠺ࡶ࠱࠱࠳࠳࠷࡫ࡰࡳ࡯࠶ࡤ࠸࠶࠽ࡦࡤ࠷࠶࠴࠹࠸ࠧ఩"),w9wfONXUP3(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬప"):zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪఫ")})
			sFi6cZKSANDM7H4xJXeuzVLo = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡳࡺࡺࡵࡣࡧ࠰ࡷࡪࡧࡲࡤࡪ࠰ࡥࡳࡪ࠭ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࠲ࡷࡧࡰࡪࡦࡤࡴ࡮࠴ࡣࡰ࡯࠲ࡺ࡮ࡪࡥࡰ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࡃ࡮ࡪ࠽ࠨబ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn
			nm7eJAXsTWk389oRHyGN2Kb = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡊࡉ࡙࠭భ"),sFi6cZKSANDM7H4xJXeuzVLo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,tGUzx9IYVD1T3Nevm,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠴ࡴࡧࠫమ"))
			EcSgq9FRv1r = nm7eJAXsTWk389oRHyGN2Kb.content
			irjPCy0Qof9Icu4tVTSd1OZbp = WWNb0XnUxOPL9gF.loads(EcSgq9FRv1r)
			dayk7sGOVAiul9q = irjPCy0Qof9Icu4tVTSd1OZbp.get(rAYDiWlzm9MCU6x0GnROua(u"ࠫࡲ࡫ࡤࡪࡣࡶࠫయ"),[])
			D2uAksXHVKJ = irjPCy0Qof9Icu4tVTSd1OZbp.get(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨర"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		if xD9WeoEAsX7 and not dayk7sGOVAiul9q:
			tGUzx9IYVD1T3Nevm = headers.copy()
			tGUzx9IYVD1T3Nevm.update({pYeVwat64v(u"࠭ࡘ࠮ࡔࡤࡴ࡮ࡪࡡࡱ࡫࠰ࡌࡴࡹࡴࠨఱ"):rAYDiWlzm9MCU6x0GnROua(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡶ࠲ࡼࡩࡥࡧࡲ࠲ࡵ࠴ࡲࡢࡲ࡬ࡨࡦࡶࡩ࠯ࡥࡲࡱࠬల"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧళ"):lRKCWnNi0Edr984eI(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨఴ"),f9fOpCmLAEaW2Go(u"ࠪ࡜࠲ࡘࡡࡱ࡫ࡧࡥࡵ࡯࠭ࡌࡧࡼࠫవ"):JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫ࠹࠺ࡦ࠵࠲࠻ࡨ࠹ࡧ࠲࡮ࡵ࡫࠵ࡧ࠹ࡢࡥ࠶࠼ࡥ࠻࠺࠸࠲࠹ࡩ࠹ࡵ࠷࠰࠲࠲࠶ࡪ࡯ࡹ࡮࠵ࡣ࠷࠵࠼࡬ࡣ࠶࠵࠳࠸࠷࠭శ")})
			jLPqwVgIXp4Jt3h2vU = {zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡼࡩࡥࡧࡲࡣࡺࡸ࡬ࠨష"):EgAUQnSxLHwYz}
			sFi6cZKSANDM7H4xJXeuzVLo = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡶ࠲ࡼࡩࡥࡧࡲ࠲ࡵ࠴ࡲࡢࡲ࡬ࡨࡦࡶࡩ࠯ࡥࡲࡱ࠴ࡿࡴࡠࡵࡷࡶࡪࡧ࡭ࠨస")
			nm7eJAXsTWk389oRHyGN2Kb = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡑࡑࡖࡘࠬహ"),sFi6cZKSANDM7H4xJXeuzVLo,jLPqwVgIXp4Jt3h2vU,tGUzx9IYVD1T3Nevm,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩ఺"))
			EcSgq9FRv1r = nm7eJAXsTWk389oRHyGN2Kb.content
			irjPCy0Qof9Icu4tVTSd1OZbp = WWNb0XnUxOPL9gF.loads(EcSgq9FRv1r)
			dayk7sGOVAiul9q = irjPCy0Qof9Icu4tVTSd1OZbp.get(kAz7WRYjrfGm(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ఻"),[])
			a7akh9HWO4JvCTP = irjPCy0Qof9Icu4tVTSd1OZbp.get(nR0ok9zju84rFUQl1YC(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯఼ࠫ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			qtZFO9Gk3JEv012TiHwgyNdK = irjPCy0Qof9Icu4tVTSd1OZbp.get(ba49YvOK2Aw8Uhxt(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡤ࡯ࡤࠨఽ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			D2uAksXHVKJ = irjPCy0Qof9Icu4tVTSd1OZbp.get(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨా"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		if not dayk7sGOVAiul9q: return Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩࠦ࠭ࠡࡃࡓࡍࡸࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧి"),[],[]
		if not mUcBGLls4CubXQWkj1392fY:
			pyjcYOFXNWm18eGoZBCJM,JGp94WsfTL8ytQ3jCYO5SBqAv0FI = [],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			for bDXsARpdoGEYmh8lIV4 in dayk7sGOVAiul9q:
				LLUN6d32Oz = bDXsARpdoGEYmh8lIV4.copy()
				if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡪࡶࡤ࡫ࠬీ") not in LLUN6d32Oz: LLUN6d32Oz[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡫ࡷࡥ࡬࠭ు")] = LLUN6d32Oz.get(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡩࡳࡷࡳࡡࡵࡋࡧࠫూ"),LLUN6d32Oz.get(I6Bfzysrvb8DONZ(u"ࠪࡪࡴࡸ࡭ࡢࡶࡢ࡭ࡩ࠭ృ"),CCWqR3dmtzw6xoIX41(u"ࠫ࠵࠭ౄ")))
				if lRKCWnNi0Edr984eI(u"ࠬࡹࡢࠨ౅") in str(LLUN6d32Oz[jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡩࡵࡣࡪࠫె")]): continue
				if YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨే") not in LLUN6d32Oz: LLUN6d32Oz[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩై")] = LLUN6d32Oz.get(rAYDiWlzm9MCU6x0GnROua(u"ࠩࡷࡦࡷ࠭౉"),nUaVQsoA6EXcK4Odht5wCge0J8Pib)*fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠷࠰࠱࠲࿩")
				if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪొ") not in LLUN6d32Oz: LLUN6d32Oz[pYeVwat64v(u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫో")] = LLUN6d32Oz.get(I6Bfzysrvb8DONZ(u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ౌ"),nUaVQsoA6EXcK4Odht5wCge0J8Pib)
				if I6Bfzysrvb8DONZ(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ్") not in LLUN6d32Oz: LLUN6d32Oz[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ౎")] = LLUN6d32Oz.get(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡣࡶࡶࠬ౏"),nUaVQsoA6EXcK4Odht5wCge0J8Pib)
				if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩ࡬ࡲࡩ࡫ࡸࠨ౐") not in LLUN6d32Oz: LLUN6d32Oz[nR0ok9zju84rFUQl1YC(u"ࠪ࡭ࡳࡪࡥࡹࠩ౑")] = GTmHXIZUSdxRhMnqQKkO(u"ࠫ࠵࠳࠰ࠨ౒")
				if I6Bfzysrvb8DONZ(u"ࠬ࡯࡮ࡪࡶࠪ౓") not in LLUN6d32Oz: LLUN6d32Oz[JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡩ࡯ࡦࡨࡼࠬ౔")] = I6Bfzysrvb8DONZ(u"ࠧ࠱࠯࠳ౕࠫ")
				if W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡵ࡬ࡾࡪౖ࠭") not in LLUN6d32Oz: LLUN6d32Oz[zWBnYSGIatjXVC(u"ࠩࡶ࡭ࡿ࡫ࠧ౗")] = CCWqR3dmtzw6xoIX41(u"ࠪ࠴ࡽ࠶ࠧౘ")
				if GTmHXIZUSdxRhMnqQKkO(u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭ౙ") not in LLUN6d32Oz:
					XurvScqbf2eKCkxy3UEhizpB = LLUN6d32Oz.get(W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡼࡣࡰࡦࡨࡧࠬౚ")) if LLUN6d32Oz.get(B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡶࡤࡱࡧࡩࡨ࠭౛")) not in (rAYDiWlzm9MCU6x0GnROua(u"ࠧ࡯ࡱࡱࡩࠬ౜"), None) else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					Fpf4XKGmYqiSwzOWv63Is = LLUN6d32Oz.get(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡣࡦࡳࡩ࡫ࡣࠨౝ")) if LLUN6d32Oz.get(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡤࡧࡴࡪࡥࡤࠩ౞")) not in (YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡲࡴࡴࡥࠨ౟"), None) else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					NNI8lM7fR1bhzY0t = LLUN6d32Oz.get(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡻ࡯ࡤࡦࡱࡢࡩࡽࡺࠧౠ")) if LLUN6d32Oz.get(GTmHXIZUSdxRhMnqQKkO(u"ࠬࡼࡩࡥࡧࡲࡣࡪࡾࡴࠨౡ")) not in (kAz7WRYjrfGm(u"࠭࡮ࡰࡰࡨࠫౢ"), None) else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					KkLhHvZVmS = LLUN6d32Oz.get(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡢࡷࡧ࡭ࡴࡥࡥࡹࡶࠪౣ")) if LLUN6d32Oz.get(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡦࡺࡷࠫ౤")) not in (YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡱࡳࡳ࡫ࠧ౥"), None) else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					Yg06E3MRAHdvkFJDLIoQXlG = azP0kLi9Uc6(LLUN6d32Oz[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡹࡷࡲࠧ౦")]).strip(nR0ok9zju84rFUQl1YC(u"ࠫ࠳࠭౧")) or NNI8lM7fR1bhzY0t or KkLhHvZVmS or LLUN6d32Oz.get(KKCrwPdOgGl(u"ࠬ࡫ࡸࡵࠩ౨")) or CCWqR3dmtzw6xoIX41(u"࠭࡭ࡱ࠶ࠪ౩")
					zpPxoaGFnYhfv = hWRvZOYtjme9QNnV41u0Mswb(u"ࠧ࠭ࠢࠪ౪") if XurvScqbf2eKCkxy3UEhizpB and Fpf4XKGmYqiSwzOWv63Is else VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
					if LLUN6d32Oz[pbmKZA1w7L4zHjOM(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡦࡺࡷࠫ౫")] != pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡱࡳࡳ࡫ࠧ౬"): HQ5jDqhI6BZ4 = pbmKZA1w7L4zHjOM(u"ࠪࡺ࡮ࡪࡥࡰ࠱ࠨࡷࠬ౭") % Yg06E3MRAHdvkFJDLIoQXlG
					elif LLUN6d32Oz[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡦࡻࡤࡪࡱࡢࡩࡽࡺࠧ౮")] != KKCrwPdOgGl(u"ࠬࡴ࡯࡯ࡧࠪ౯"): HQ5jDqhI6BZ4 = KKCrwPdOgGl(u"࠭ࡡࡶࡦ࡬ࡳ࠴ࠫࡳࠨ౰") % Yg06E3MRAHdvkFJDLIoQXlG
					else: HQ5jDqhI6BZ4 = pYeVwat64v(u"ࠧࡷ࡫ࡧࡩࡴ࠵ࠥࡴࠩ౱") % Yg06E3MRAHdvkFJDLIoQXlG
					if not HQ5jDqhI6BZ4: eDIUOjKk5h8wCnbGPQ90ZLT3BVcqM = w9wfONXUP3(u"ࠨࡸ࡬ࡨࡪࡵ࠯ࡶࡰ࡮ࡲࡴࡽ࡮࠼ࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࡹࡳࡱ࡮ࡰࡹࡱ࠰ࠥࡻ࡮࡬ࡰࡲࡻࡳࠨࠧ౲")
					elif not XurvScqbf2eKCkxy3UEhizpB and not Fpf4XKGmYqiSwzOWv63Is: eDIUOjKk5h8wCnbGPQ90ZLT3BVcqM = awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࠨࡷࡀࠦࡣࡰࡦࡨࡧࡸࡃࠢࠦࡵࠥࠫ౳")%(HQ5jDqhI6BZ4, rAYDiWlzm9MCU6x0GnROua(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱ࠰ࠥࡻ࡮࡬ࡰࡲࡻࡳ࠭౴") if zpPxoaGFnYhfv else zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ౵"))
					else: eDIUOjKk5h8wCnbGPQ90ZLT3BVcqM = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࠫࡳ࠼ࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠩࡸࠫࡳࠦࡵࠥࠫ౶") % (HQ5jDqhI6BZ4, XurvScqbf2eKCkxy3UEhizpB, zpPxoaGFnYhfv, Fpf4XKGmYqiSwzOWv63Is)
					LLUN6d32Oz[KKCrwPdOgGl(u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ౷")] = eDIUOjKk5h8wCnbGPQ90ZLT3BVcqM
				if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡸࡶࡱ࠭౸") in LLUN6d32Oz: JGp94WsfTL8ytQ3jCYO5SBqAv0FI = LLUN6d32Oz[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡹࡷࡲࠧ౹")]
				pyjcYOFXNWm18eGoZBCJM.append(LLUN6d32Oz)
			mUcBGLls4CubXQWkj1392fY = {}
			mUcBGLls4CubXQWkj1392fY[hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ౺")] = {I6Bfzysrvb8DONZ(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ౻"):pyjcYOFXNWm18eGoZBCJM}
			mUcBGLls4CubXQWkj1392fY[lRKCWnNi0Edr984eI(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ౼")] = {KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡧࡵࡵࡪࡲࡶࠬ౽"):a7akh9HWO4JvCTP,pYeVwat64v(u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ౾"):qtZFO9Gk3JEv012TiHwgyNdK}
			mUcBGLls4CubXQWkj1392fY[lRKCWnNi0Edr984eI(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭౿")] = {Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡣࡸࡸ࡭ࡵࡲࠨಀ"):a7akh9HWO4JvCTP,hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬಁ"):qtZFO9Gk3JEv012TiHwgyNdK,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭ಂ"):{f9fOpCmLAEaW2Go(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨಃ"):[{zWBnYSGIatjXVC(u"ࠬࡻࡲ࡭ࠩ಄"):D2uAksXHVKJ}]}}
			if JGp94WsfTL8ytQ3jCYO5SBqAv0FI:
				if azP0kLi9Uc6(JGp94WsfTL8ytQ3jCYO5SBqAv0FI)==KKCrwPdOgGl(u"࠭࠮࡮࠵ࡸ࠼ࠬಅ"):
					mUcBGLls4CubXQWkj1392fY[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧಆ")][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩಇ")] = JGp94WsfTL8ytQ3jCYO5SBqAv0FI
				else:
					mUcBGLls4CubXQWkj1392fY[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩಈ")][Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬಉ")] = JGp94WsfTL8ytQ3jCYO5SBqAv0FI
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			w36wV9XdyjmpAQhlx1Lvu = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠱࿪")
			for r6dVWlzDj9va0FxqfkOwLYZEmP in range(w36wV9XdyjmpAQhlx1Lvu):
				gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡌࡋࡔࠨಊ"),EgAUQnSxLHwYz,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠷ࡸ࡭࠭ಋ"))
				R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			xxCo2yGh1duw8TYvF = AxTYMhRlfyskNc0X19dvwtS.findall(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡖ࡬ࡢࡻࡨࡶࡗ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪಌ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			d9E1ri3BZcpfPSMDXmQqw = xxCo2yGh1duw8TYvF[nUaVQsoA6EXcK4Odht5wCge0J8Pib] if xxCo2yGh1duw8TYvF else R8AE9e4mYxVhusL3Q
			mUcBGLls4CubXQWkj1392fY = rKY1tyQvh9OCxE2nl(hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡥ࡫ࡦࡸࠬ಍"),d9E1ri3BZcpfPSMDXmQqw)
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡉࡈࡘࠬಎ"),EgAUQnSxLHwYz,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪಏ"))
		gqjko4Dv8CFztmK7PZbyhE = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		XlBvIqNU52cE7Q8Vayn = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		zq6v0MQL7AVtPoygfuZ = AxTYMhRlfyskNc0X19dvwtS.findall(w9wfONXUP3(u"ࠪࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬಐ"),gqjko4Dv8CFztmK7PZbyhE,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if zq6v0MQL7AVtPoygfuZ:
			zq6v0MQL7AVtPoygfuZ = drzqWFkSHD.SITESURLS[nR0ok9zju84rFUQl1YC(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ಑")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+zq6v0MQL7AVtPoygfuZ[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡍࡅࡕࠩಒ"),zq6v0MQL7AVtPoygfuZ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠺ࡹ࡮ࠧಓ"))
			B2Xex34ilkh1K = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			o1inhxJQN8ADfKj75l = AxTYMhRlfyskNc0X19dvwtS.search(YzlId3Fs6vpehcbLGj0UaO(u"ࡲࠨࠪࡂ࠾ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡾࡶࡸࡸ࠯࡜ࡴࠬ࠽ࡠࡸ࠰ࠨࡀࡒ࠿ࡷࡹࡹ࠾࡜࠲࠰࠽ࡢࢁ࠵ࡾࠫࠪಔ"), B2Xex34ilkh1K)
			XlBvIqNU52cE7Q8Vayn = o1inhxJQN8ADfKj75l.group(rAYDiWlzm9MCU6x0GnROua(u"ࠨࡵࡷࡷࠬಕ"))
			XlBvIqNU52cE7Q8Vayn = f9fOpCmLAEaW2Go(u"ࠩ࠵࠴࠸࠺࠸ࠨಖ")
			zq6v0MQL7AVtPoygfuZ = pL73X0MYajJQG4n1qgD(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࠲࠳࠴࠹ࡪࡥ࠵࠴࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࡙ࡘ࠵ࡢࡢࡵࡨ࠲࡯ࡹࠧಗ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡌࡋࡔࠨಘ"),zq6v0MQL7AVtPoygfuZ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠺ࡸ࡭࠭ಙ"))
			B2Xex34ilkh1K = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		jYfvU9egTX62nrukVcoKEAyq = drzqWFkSHD.SITESURLS[rAYDiWlzm9MCU6x0GnROua(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧಚ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷࡅࡰࡳࡧࡷࡸࡾࡖࡲࡪࡰࡷࡁ࡫ࡧ࡬ࡴࡧࠪಛ")
		QWH1dgDnkKRat = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪಜ"))
		if QWH1dgDnkKRat.count(Zb5cNeHWi6jP9SCYtUgR(u"ࠩ࠽࠾࠿࠭ಝ"))==KKCrwPdOgGl(u"࠵࿫"):
			Ef9nDACy2z0XcVSFLG1lI7NWmBQ,key,BB4qHcbSvm3Rni,p8pCWFTXIk7EiYB,jb7G0mIu2nD = QWH1dgDnkKRat.split(kAz7WRYjrfGm(u"ࠪ࠾࠿ࡀࠧಞ"))
			headers[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫ࡝࠳ࡇࡰࡱࡪ࠱࡛࡯ࡳࡪࡶࡲࡶ࠲ࡏࡤࠨಟ")] = Ef9nDACy2z0XcVSFLG1lI7NWmBQ
		headers[zWBnYSGIatjXVC(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫಠ")] = CCWqR3dmtzw6xoIX41(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩಡ")
		if xD9WeoEAsX7:
			pPsAqmiJfEVyth2G49cX0DKB6w = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡼࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼࡙ࠣࠦ࡜ࡈࡕࡏࡏ࠹ࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠼࠴࠲࠱࠴࠸࠴࠾࠶࠲࠯࠲࠻࠲࠵࠶ࠢࡾࡿ࠯ࠤࠧࡼࡩࡥࡧࡲࡍࡩࠨ࠺ࠡࠤࠪಢ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࠤ࠯ࠤࠧࡶ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡵ࡮ࡵࡧࡱࡸࡕࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࠣ࠼ࠣࠫಣ")+XlBvIqNU52cE7Q8Vayn+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࢀࢁࢂ࠭ತ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡔࡔ࡙ࡔࠨಥ"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠺ࡷ࡬ࠬದ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if pYeVwat64v(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬಧ") in xxCo2yGh1duw8TYvF:
				d9E1ri3BZcpfPSMDXmQqw = xxCo2yGh1duw8TYvF.replace(I6Bfzysrvb8DONZ(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧನ"),CCWqR3dmtzw6xoIX41(u"ࠧࠧࠩ಩"))
				mUcBGLls4CubXQWkj1392fY = rKY1tyQvh9OCxE2nl(KKCrwPdOgGl(u"ࠨࡦ࡬ࡧࡹ࠭ಪ"),d9E1ri3BZcpfPSMDXmQqw)
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			pPsAqmiJfEVyth2G49cX0DKB6w = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡾࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠥࠨࡔࡗࡊࡗࡑࡑ࠻࡟ࡔࡋࡐࡔࡑ࡟ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠱࠯࠲ࠥࢁࢂ࠲ࠠࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ಫ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࠦ࠱ࠦࠢࡱ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣࡰࡰࡷࡩࡳࡺࡐ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡹࡩࡨࡰࡤࡸࡺࡸࡥࡕ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠥ࠾ࠥ࠭ಬ")+XlBvIqNU52cE7Q8Vayn+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࢂࢃࡽࠨಭ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,ba49YvOK2Aw8Uhxt(u"ࠬࡖࡏࡔࡖࠪಮ"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠽ࡹ࡮ࠧಯ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if ba49YvOK2Aw8Uhxt(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧರ") in xxCo2yGh1duw8TYvF:
				d9E1ri3BZcpfPSMDXmQqw = xxCo2yGh1duw8TYvF.replace(w9wfONXUP3(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩಱ"),pbmKZA1w7L4zHjOM(u"ࠩࠩࠫಲ"))
				mUcBGLls4CubXQWkj1392fY = rKY1tyQvh9OCxE2nl(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡨ࡮ࡩࡴࠨಳ"),d9E1ri3BZcpfPSMDXmQqw)
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			pPsAqmiJfEVyth2G49cX0DKB6w = pbmKZA1w7L4zHjOM(u"ࠫࢀࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡋࡒࡗࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠷࠶࠮࠲࠲࠱࠸ࠧࢃࡽ࠭ࠢࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨ಴")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࠨࠬࠡࠤࡳࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥࡲࡲࡹ࡫࡮ࡵࡒ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡗ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠧࡀࠠࠨವ")+XlBvIqNU52cE7Q8Vayn+rAYDiWlzm9MCU6x0GnROua(u"࠭ࡽࡾࡿࠪಶ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡑࡑࡖࡘࠬಷ"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷࠰ࡵࡪࠪಸ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩಹ") in xxCo2yGh1duw8TYvF:
				jgmYcNVeaBhyPvO = xxCo2yGh1duw8TYvF.replace(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ಺"),rAYDiWlzm9MCU6x0GnROua(u"ࠫࠫ࠭಻"))
				WC2Vy5BvLIKmA = rKY1tyQvh9OCxE2nl(hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡪࡩࡤࡶ಼ࠪ"),jgmYcNVeaBhyPvO)
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib and zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ಽ") not in d9E1ri3BZcpfPSMDXmQqw:
			d9E1ri3BZcpfPSMDXmQqw,mUcBGLls4CubXQWkj1392fY,mUcBGLls4CubXQWkj1392fY = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{},{}
			pPsAqmiJfEVyth2G49cX0DKB6w = ba49YvOK2Aw8Uhxt(u"ࠧࡼࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡒ࡝ࡅࡃࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠴࠱࠶࠵࠸࠵࠱࠵࠴࠵࠳࠶࠳࠯࠲࠳ࠦࢂࢃࠬࠡࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧಾ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࠤ࠯ࠤࠧࡶ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡵ࡮ࡵࡧࡱࡸࡕࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࠣ࠼ࠣࠫಿ")+XlBvIqNU52cE7Q8Vayn+hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࢀࢁࢂ࠭ೀ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,ba49YvOK2Aw8Uhxt(u"ࠪࡔࡔ࡙ࡔࠨು"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳࠴ࡸ࡭࠭ೂ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬೃ") in xxCo2yGh1duw8TYvF:
				d9E1ri3BZcpfPSMDXmQqw = xxCo2yGh1duw8TYvF.replace(hWRvZOYtjme9QNnV41u0Mswb(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧೄ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠧࠩ೅"))
				mUcBGLls4CubXQWkj1392fY = rKY1tyQvh9OCxE2nl(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡦ࡬ࡧࡹ࠭ೆ"),d9E1ri3BZcpfPSMDXmQqw)
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib and hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩೇ") not in d9E1ri3BZcpfPSMDXmQqw:
			d9E1ri3BZcpfPSMDXmQqw,mUcBGLls4CubXQWkj1392fY,mUcBGLls4CubXQWkj1392fY = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{},{}
			pPsAqmiJfEVyth2G49cX0DKB6w = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡿࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠦࠢࡘࡇࡅࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠶࠳࠸࠰࠳࠷࠳࠽࠵࠹࠮࠱࠶࠱࠴࠵ࠨࡽࡾ࠮ࠣࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩೈ")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࠧ࠲ࠠࠣࡲ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤࡱࡱࡸࡪࡴࡴࡑ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡳࡪࡩࡱࡥࡹࡻࡲࡦࡖ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠦ࠿ࠦࠧ೉")+XlBvIqNU52cE7Q8Vayn+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࢃࡽࡾࠩೊ")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡐࡐࡕࡗࠫೋ"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶࠸ࡴࡩࠩೌ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ್") in xxCo2yGh1duw8TYvF:
				d9E1ri3BZcpfPSMDXmQqw = xxCo2yGh1duw8TYvF.replace(W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ೎"),GTmHXIZUSdxRhMnqQKkO(u"ࠪࠪࠬ೏"))
				mUcBGLls4CubXQWkj1392fY = rKY1tyQvh9OCxE2nl(nR0ok9zju84rFUQl1YC(u"ࠫࡩ࡯ࡣࡵࠩ೐"),d9E1ri3BZcpfPSMDXmQqw)
		if xD9WeoEAsX7 and fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ೑") not in jgmYcNVeaBhyPvO:
			jgmYcNVeaBhyPvO,WC2Vy5BvLIKmA,WC2Vy5BvLIKmA = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{},{}
			pPsAqmiJfEVyth2G49cX0DKB6w = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡻࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡅࡓࡊࡒࡐࡋࡇࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠶࠵࠴࠱࠱࠰࠶࠼ࠧࢃࡽ࠭ࠢࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨ೒")+CoFhVUrItm2OPNzakjb7wTQ3ul18Xn+GTmHXIZUSdxRhMnqQKkO(u"ࠧࠣ࠮ࠣࠦࡵࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡴࡴࡴࡦࡰࡷࡔࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࠢ࠻ࠢࠪ೓")+XlBvIqNU52cE7Q8Vayn+ba49YvOK2Aw8Uhxt(u"ࠨࡿࢀࢁࠬ೔")
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡓࡓࡘ࡚ࠧೕ"),jYfvU9egTX62nrukVcoKEAyq,pPsAqmiJfEVyth2G49cX0DKB6w,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲࠵ࡷ࡬ࠬೖ"))
			xxCo2yGh1duw8TYvF = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			if nR0ok9zju84rFUQl1YC(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ೗") in xxCo2yGh1duw8TYvF:
				jgmYcNVeaBhyPvO = xxCo2yGh1duw8TYvF.replace(pL73X0MYajJQG4n1qgD(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭೘"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࠦࠨ೙"))
				WC2Vy5BvLIKmA = rKY1tyQvh9OCxE2nl(CCWqR3dmtzw6xoIX41(u"ࠧࡥ࡫ࡦࡸࠬ೚"),jgmYcNVeaBhyPvO)
	MWDnm4yz1YiJLZpVTOSdEF2,FGK6y3IUmsTj8xVH0wb,crTjz3AtUpExsoq01kBdF7ub,pcePi9t7d6Hbkhg = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[]
	Md1hX60ku2LItSz3UPGciv,aTwjYM8eVuJhfK,oMyDmwVdfhGEqcTs2vniQuj5C8,WAPDk2BQsElCR79Sn3bw6 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],[]
	try: FGK6y3IUmsTj8xVH0wb = mUcBGLls4CubXQWkj1392fY[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ೛")][YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ೜")]
	except: pass
	try: aTwjYM8eVuJhfK = WC2Vy5BvLIKmA[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪೝ")][Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬೞ")]
	except: pass
	try: MWDnm4yz1YiJLZpVTOSdEF2 = mUcBGLls4CubXQWkj1392fY[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ೟")][bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨೠ")]
	except: pass
	try: Md1hX60ku2LItSz3UPGciv = WC2Vy5BvLIKmA[W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧೡ")][fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪೢ")]
	except: pass
	try: crTjz3AtUpExsoq01kBdF7ub = mUcBGLls4CubXQWkj1392fY[rAYDiWlzm9MCU6x0GnROua(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩೣ")][pbmKZA1w7L4zHjOM(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ೤")]
	except: pass
	try: oMyDmwVdfhGEqcTs2vniQuj5C8 = WC2Vy5BvLIKmA[w9wfONXUP3(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ೥")][JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭೦")]
	except: pass
	try: pcePi9t7d6Hbkhg = mUcBGLls4CubXQWkj1392fY[YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭೧")][KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩ೨")]
	except: pass
	try: WAPDk2BQsElCR79Sn3bw6 = WC2Vy5BvLIKmA[CCWqR3dmtzw6xoIX41(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ೩")][kAz7WRYjrfGm(u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫ೪")]
	except: pass
	if not any([FGK6y3IUmsTj8xVH0wb,aTwjYM8eVuJhfK,MWDnm4yz1YiJLZpVTOSdEF2,Md1hX60ku2LItSz3UPGciv,crTjz3AtUpExsoq01kBdF7ub,oMyDmwVdfhGEqcTs2vniQuj5C8,pcePi9t7d6Hbkhg,WAPDk2BQsElCR79Sn3bw6]):
		jQxNuCVe4hzpObyKU = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡹࡳࡢࡩࡨࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭೫"),gqjko4Dv8CFztmK7PZbyhE,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		VLRK8jaf4GxrIm2tN = AxTYMhRlfyskNc0X19dvwtS.findall(pL73X0MYajJQG4n1qgD(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࡢࡻࠣࡴࡸࡲࡸࠨ࠺࡝࡝࡟ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ೬"),gqjko4Dv8CFztmK7PZbyhE,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		FJZlhomc1CP8GT6VQ = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ೭"),gqjko4Dv8CFztmK7PZbyhE,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		EHaB0uwx2d4CfPrzbmZI6YL = AxTYMhRlfyskNc0X19dvwtS.findall(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ೮"),gqjko4Dv8CFztmK7PZbyhE,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		gMAIF8nGswJvC1YHZk65X,JVW2PekNzO1qUjTGgamcMAI,i5y6l3pXDOenaWzBGU = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		try: gMAIF8nGswJvC1YHZk65X = mUcBGLls4CubXQWkj1392fY[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ೯")][bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭೰")][lRKCWnNi0Edr984eI(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪೱ")][f9fOpCmLAEaW2Go(u"ࠪࡸ࡮ࡺ࡬ࡦࠩೲ")][w9wfONXUP3(u"ࠫࡷࡻ࡮ࡴࠩೳ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][f9fOpCmLAEaW2Go(u"ࠬࡺࡥࡹࡶࠪ೴")]
		except:
			try: gMAIF8nGswJvC1YHZk65X = WC2Vy5BvLIKmA[rAYDiWlzm9MCU6x0GnROua(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ೵")][vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ೶")][KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ೷")][kAz7WRYjrfGm(u"ࠩࡷ࡭ࡹࡲࡥࠨ೸")][pL73X0MYajJQG4n1qgD(u"ࠪࡶࡺࡴࡳࠨ೹")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][zWBnYSGIatjXVC(u"ࠫࡹ࡫ࡸࡵࠩ೺")]
			except: pass
		try: JVW2PekNzO1qUjTGgamcMAI = mUcBGLls4CubXQWkj1392fY[vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ೻")][JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ೼")][slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ೽")][GTmHXIZUSdxRhMnqQKkO(u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩ೾")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][GTmHXIZUSdxRhMnqQKkO(u"ࠩࡵࡹࡳࡹࠧ೿")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡸࡪࡾࡴࠨഀ")]
		except:
			try: JVW2PekNzO1qUjTGgamcMAI = WC2Vy5BvLIKmA[hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨഁ")][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪം")][pL73X0MYajJQG4n1qgD(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧഃ")][I6Bfzysrvb8DONZ(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨഄ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨࡴࡸࡲࡸ࠭അ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡷࡩࡽࡺࠧആ")]
			except: pass
		try: i5y6l3pXDOenaWzBGU = mUcBGLls4CubXQWkj1392fY[KKCrwPdOgGl(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧഇ")][pL73X0MYajJQG4n1qgD(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫഈ")]
		except:
			try: i5y6l3pXDOenaWzBGU = WC2Vy5BvLIKmA[KKCrwPdOgGl(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩഉ")][CCWqR3dmtzw6xoIX41(u"࠭ࡲࡦࡣࡶࡳࡳ࠭ഊ")]
			except: pass
		XHjo8PKFCWu = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		DJuaZxUKdA72 = qFghPAi5yz9Vf3NLwo0nuprl+lRKCWnNi0Edr984eI(u"่ࠧาสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ๊๊วว็่ࠣอ฿ึࠡษ็ุ้ะฮะ็ํ๊ࠥ࠴࠮ࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࠥ࠴࠮ࠡล๋ࠤ๏๎ส๋๊หࠤ๏ำสศฮุࠣ๏วࠠๆฯาำࠥ࠴࠮ࠡล๋ࠤ๏๎ส๋๊หࠤ฿๐ัࠡไสำึࠦร็ࠢํุ฿๊ࠠศๆไ๎ิ๐่ࠡษ็ฦ๋࠭ഋ")+so4Z8OUJ5E
		if jQxNuCVe4hzpObyKU or VLRK8jaf4GxrIm2tN or FJZlhomc1CP8GT6VQ or EHaB0uwx2d4CfPrzbmZI6YL or gMAIF8nGswJvC1YHZk65X or JVW2PekNzO1qUjTGgamcMAI or i5y6l3pXDOenaWzBGU:
			if   jQxNuCVe4hzpObyKU: mlrXUnyLzPAhEIj8ix5Ztpu = jQxNuCVe4hzpObyKU[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			elif VLRK8jaf4GxrIm2tN: mlrXUnyLzPAhEIj8ix5Ztpu = VLRK8jaf4GxrIm2tN[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			elif FJZlhomc1CP8GT6VQ: mlrXUnyLzPAhEIj8ix5Ztpu = FJZlhomc1CP8GT6VQ[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			elif EHaB0uwx2d4CfPrzbmZI6YL: mlrXUnyLzPAhEIj8ix5Ztpu = EHaB0uwx2d4CfPrzbmZI6YL[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			elif gMAIF8nGswJvC1YHZk65X: mlrXUnyLzPAhEIj8ix5Ztpu = gMAIF8nGswJvC1YHZk65X
			elif JVW2PekNzO1qUjTGgamcMAI: mlrXUnyLzPAhEIj8ix5Ztpu = JVW2PekNzO1qUjTGgamcMAI
			elif i5y6l3pXDOenaWzBGU: mlrXUnyLzPAhEIj8ix5Ztpu = i5y6l3pXDOenaWzBGU
			XHjo8PKFCWu = mlrXUnyLzPAhEIj8ix5Ztpu.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			DJuaZxUKdA72 += kAz7WRYjrfGm(u"ࠨ࡞ࡱࡠࡳ࠭ഌ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩิืฬ๊ษࠡ็้ࠤ๏๎ส๋๊หࠫ഍")+so4Z8OUJ5E+b8sk5WyPoz03pXhRx+XHjo8PKFCWu
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧഎ"),DJuaZxUKdA72)
		if XHjo8PKFCWu: XHjo8PKFCWu = pbmKZA1w7L4zHjOM(u"ࠫ࠿ࠦࠧഏ")+XHjo8PKFCWu
		return pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬഐ")+XHjo8PKFCWu,[],[]
	AuQOImP7oU9,UUtCreW4VIkcsRvmDj,tcnpYWNg43RCy0 = [],[],[]
	EEtLS3FMvmwh6Xx = [FGK6y3IUmsTj8xVH0wb,aTwjYM8eVuJhfK]
	kyCqOHoErF0AQjfKV5vhDlJtigIbu = [MWDnm4yz1YiJLZpVTOSdEF2,Md1hX60ku2LItSz3UPGciv]
	OIbrTU8tkdvLRlSG9jZhgXoPC,tXb3CPWUhmcv6YuM8ykIsLB = [],[]
	pyjcYOFXNWm18eGoZBCJM = crTjz3AtUpExsoq01kBdF7ub+oMyDmwVdfhGEqcTs2vniQuj5C8
	for bDXsARpdoGEYmh8lIV4 in pyjcYOFXNWm18eGoZBCJM:
		if bDXsARpdoGEYmh8lIV4[B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡩࡵࡣࡪࠫ഑")] not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(bDXsARpdoGEYmh8lIV4[I6Bfzysrvb8DONZ(u"ࠧࡪࡶࡤ࡫ࠬഒ")])
			tXb3CPWUhmcv6YuM8ykIsLB.append(bDXsARpdoGEYmh8lIV4)
	OIbrTU8tkdvLRlSG9jZhgXoPC,slEPThHVc5veXz = [],[]
	for bDXsARpdoGEYmh8lIV4 in pcePi9t7d6Hbkhg+WAPDk2BQsElCR79Sn3bw6:
		if bDXsARpdoGEYmh8lIV4[pYeVwat64v(u"ࠨ࡫ࡷࡥ࡬࠭ഓ")] not in OIbrTU8tkdvLRlSG9jZhgXoPC:
			OIbrTU8tkdvLRlSG9jZhgXoPC.append(bDXsARpdoGEYmh8lIV4[ba49YvOK2Aw8Uhxt(u"ࠩ࡬ࡸࡦ࡭ࠧഔ")])
			slEPThHVc5veXz.append(bDXsARpdoGEYmh8lIV4)
	for dict in tXb3CPWUhmcv6YuM8ykIsLB+slEPThHVc5veXz:
		if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡹࡷࡲࠧക") not in dict: continue
		if pbmKZA1w7L4zHjOM(u"ࠫ࡮ࡺࡡࡨࠩഖ") in dict: dict[nR0ok9zju84rFUQl1YC(u"ࠬ࡯ࡴࡢࡩࠪഗ")] = str(dict[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡩࡵࡣࡪࠫഘ")])
		if YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡧࡲࡶࠫങ") in dict: dict[GTmHXIZUSdxRhMnqQKkO(u"ࠨࡨࡳࡷࠬച")] = str(dict[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡩࡴࡸ࠭ഛ")])
		if rAYDiWlzm9MCU6x0GnROua(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬജ") in dict: dict[nR0ok9zju84rFUQl1YC(u"ࠫࡹࡿࡰࡦࠩഝ")] = dict[ba49YvOK2Aw8Uhxt(u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧഞ")]
		if JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨട") in dict: dict[pYeVwat64v(u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫഠ")] = str(dict[nR0ok9zju84rFUQl1YC(u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪഡ")])
		if JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩഢ") in dict: dict[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫണ")] = str(dict[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫത")])
		if pbmKZA1w7L4zHjOM(u"ࠬࡽࡩࡥࡶ࡫ࠫഥ") in dict: dict[YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡳࡪࡼࡨࠫദ")] = str(dict[pYeVwat64v(u"ࠧࡸ࡫ࡧࡸ࡭࠭ധ")])+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡺࠪന")+str(dict[GTmHXIZUSdxRhMnqQKkO(u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩഩ")])
		if pbmKZA1w7L4zHjOM(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭പ") in dict: dict[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫ࡮ࡴࡩࡵࠩഫ")] = dict[rAYDiWlzm9MCU6x0GnROua(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨബ")][bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡳࡵࡣࡵࡸࠬഭ")]+I6Bfzysrvb8DONZ(u"ࠧ࠮ࠩമ")+dict[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫയ")][bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡨࡲࡩ࠭ര")]
		if YzlId3Fs6vpehcbLGj0UaO(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧറ") in dict: dict[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫ࡮ࡴࡤࡦࡺࠪല")] = dict[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩള")][GTmHXIZUSdxRhMnqQKkO(u"࠭ࡳࡵࡣࡵࡸࠬഴ")]+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࠮ࠩവ")+dict[zWBnYSGIatjXVC(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬശ")][B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡨࡲࡩ࠭ഷ")]
		if pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫസ") in dict: dict[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬഹ")] = dict[pbmKZA1w7L4zHjOM(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭ഺ")]
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡢࡪࡶࡵࡥࡹ࡫഻ࠧ") in dict and int(dict[KKCrwPdOgGl(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ഼")])>bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠳࠴࠵࠷࠸࠲࠴࠵࠶࿬"): del dict[lRKCWnNi0Edr984eI(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩഽ")]
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫാ") in dict:
			CLYfqa9DEXbxK0Wdc = dict[f9fOpCmLAEaW2Go(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬി")].split(w9wfONXUP3(u"ࠫࠫ࠭ീ"))
			for Uz7N5KAHwQ93iShW1xj in CLYfqa9DEXbxK0Wdc:
				key,value = Uz7N5KAHwQ93iShW1xj.split(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡃࠧു"),lRKCWnNi0Edr984eI(u"࠴࿭"))
				dict[key] = WDg18QHF3rze(value)
		if pYeVwat64v(u"࠭ࡣࡰࡦࡨࡧࡸࡃࠧൂ") in dict[kAz7WRYjrfGm(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩൃ")]: dict[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡥࡲࡨࡪࡩࡳࠨൄ")] = dict[pL73X0MYajJQG4n1qgD(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ൅")].split(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡧࡴࡪࡥࡤࡵࡀࠫെ"))[xD9WeoEAsX7].replace(lRKCWnNi0Edr984eI(u"ࠫࡡࠨࠧേ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace(w9wfONXUP3(u"ࠬࠨࠧൈ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		AuQOImP7oU9.append(dict)
	if B2Xex34ilkh1K:
		if hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭൉") in d9E1ri3BZcpfPSMDXmQqw+jgmYcNVeaBhyPvO:
			try:
				import youtube_signature.cipher as HuiWYUR2hQvbtLg,youtube_signature.json_script_engine as xcz1JNPjs82nHebk
				CLYfqa9DEXbxK0Wdc = ddHGiCFUEaXIA3h.CLYfqa9DEXbxK0Wdc.Cipher()
				CLYfqa9DEXbxK0Wdc._object_cache = {}
				pwV6Nt9fgGeJlWuxSPXykFq7H = CLYfqa9DEXbxK0Wdc._load_javascript(B2Xex34ilkh1K)
				t2xWJqk9VA7 = rKY1tyQvh9OCxE2nl(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡴࡶࡵࠫൊ"),str(pwV6Nt9fgGeJlWuxSPXykFq7H))
				hkY8lwcBtKyR0vxDUTfXgC4VGunF2I = ddHGiCFUEaXIA3h.wK14yBLcYh97geSMix5RbQl6mqrW.JsonScriptEngine(t2xWJqk9VA7)
			except: pass
		if nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			l4SRhnoaz2iJCpfwm31DZe6GFNAPuL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			h73hse0EqGxXo = AxTYMhRlfyskNc0X19dvwtS.findall(
				pbmKZA1w7L4zHjOM(u"ࡳࠩࠪࠫ࠭ࡅࡸࠪࠌࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊ࡞࠱࡫ࡪࡺ࡜ࠩࠤࡱࠦࡡ࠯࡜ࠪࠨࠩࡠ࠭ࡨ࠽ࡽࠌࠌࠍࠎࠏࠉࠩࡁ࠽ࠎࠎࠏࠉࠊࠋࠌࡦࡂ࡙ࡴࡳ࡫ࡱ࡫ࡡ࠴ࡦࡳࡱࡰࡇ࡭ࡧࡲࡄࡱࡧࡩࡡ࠮࠱࠲࠲࡟࠭ࢁࠐࠉࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡶࡸࡷࡥࡩࡥࡺࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࠰ࡠ࠯࠮ࠬࠦ࡝ࠪࡥࡁࠧࡴ࡮ࠣ࡞࡞ࡠ࠰࠮࠿ࡑ࠿ࡶࡸࡷࡥࡩࡥࡺࠬࡠࡢࠐࠉࠊࠋࠌࠍ࠮ࠐࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉ࠭࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬ࡞ࠫࡥࡡ࠯ࠩࡀ࠮ࡦࡁࡦࡢ࠮ࠋࠋࠌࠍࠎࠏࠉࠩࡁ࠽ࠎࠎࠏࠉࠊࠋࠌࠍ࡬࡫ࡴ࡝ࠪࡥࡠ࠮ࢂࠊࠊࠋࠌࠍࠎࠏࠉ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࡝ࡥࡠࡢࡢࡼ࡝ࡾࡱࡹࡱࡲࠊࠊࠋࠌࠍࠎࠏࠩ࡝ࠫࠩࠪࡡ࠮ࡣ࠾ࡾࠍࠍࠎࠏࠉࠊ࡞ࡥࠬࡄࡖ࠼ࡷࡣࡵࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡃࠊࠊࠋࠌࠍ࠮࠮࠿ࡑ࠾ࡱࡪࡺࡴࡣ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫࠫࡃ࠿ࡢ࡛ࠩࡁࡓࡀ࡮ࡪࡸ࠿࡞ࡧ࠯࠮ࡢ࡝ࠪࡁ࡟ࠬࡠࡧ࠭ࡻࡃ࠰࡞ࡢࡢࠩࠋࠋࠌࠍࠎ࠮࠿ࠩࡸࡤࡶ࠮࠲࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱࡜࠯ࡵࡨࡸࡡ࠮ࠨࡀ࠼ࠥࡲ࠰ࠨࡼ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪ࡞࠯ࠬࡄࡖ࠽ࡷࡣࡵ࠭ࡡ࠯ࠩࠨࠩࠪോ"),B2Xex34ilkh1K)
			if not h73hse0EqGxXo:
				h73hse0EqGxXo = AxTYMhRlfyskNc0X19dvwtS.findall(
					GTmHXIZUSdxRhMnqQKkO(u"ࡴࠪࠫࠬ࠮࠿ࡹࡵࠬࠎࠎࠏࠉࠊࠋ࠾ࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫ࡟ࡷ࠯ࡃ࡜ࡴࠬࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢࠩࠋࠋࠌࠍࠎࠏ࡜ࡴࠬ࡟ࡿ࠭ࡅ࠺ࠩࡁࠤࢁࡀ࠯࠮ࠪ࠭ࡂࡶࡪࡺࡵࡳࡰ࡟ࡷ࠯࠮࠿ࡑ࠾ࡴࡂࡠࠨࠧ࡞ࠫ࡞ࡠࡼ࠳࡝ࠬࡡࡺ࠼ࡤ࠮࠿ࡑ࠿ࡴ࠭ࡡࡹࠪ࡝࠭࡟ࡷ࠯ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠭ࠧࠨൌ"),
					B2Xex34ilkh1K)
			h73hse0EqGxXo = AxTYMhRlfyskNc0X19dvwtS.findall(h73hse0EqGxXo[nUaVQsoA6EXcK4Odht5wCge0J8Pib][H3OKMjDG1evnl4Ruiz]+I6Bfzysrvb8DONZ(u"ࠪࡁࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣ്ࠧ"),B2Xex34ilkh1K,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else:
			def _95ROKP6kb1LqiH(M8svrdxPzeh0jo3T5I):
				import ast as eeBhUDTWw3vfZ6gAiHLxalKuQE
				i2NXtDF0TVj396zyQJHbgEwGoqpm = YzlId3Fs6vpehcbLGj0UaO(u"ࡶࠬ࠭ࠧࠩࡁࡻ࠭ࠏࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡲ࠳ࡁ࡟ࠧࡢࠧ࡞ࠫࡸࡷࡪࡢࡳࠬࡵࡷࡶ࡮ࡩࡴࠩࡁࡓࡁࡶ࠷ࠩ࠼࡞ࡶ࠮ࠏࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡤࡱࡧࡩࡃࠐࠉࠊࠋࠌࠍࠎࡼࡡࡳ࡞ࡶ࠯࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝ࡵ࠭ࡁࡡࡹࠪࠋࠋࠌࠍࠎࠏࠉࠩࡁࡓࡀࡻࡧ࡬ࡶࡧࡁࠎࠎࠏࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡳ࠵ࡂࡠࠨ࡜ࠨ࡟ࠬࠬࡄࡀࠨࡀࠣࠫࡃࡕࡃࡱ࠳ࠫࠬ࠲ࢁࡢ࡜࠯ࠫ࠮ࠬࡄࡖ࠽ࡲ࠴ࠬࠎࠎࠏࠉࠊࠋࠌࠍࡡ࠴ࡳࡱ࡮࡬ࡸࡡ࠮ࠨࡀࡒ࠿ࡵ࠸ࡄ࡛ࠣࠩࡠ࠭࠭ࡅ࠺ࠩࡁࠤࠬࡄࡖ࠽ࡲ࠵ࠬ࠭࠳࠯ࠫࠩࡁࡓࡁࡶ࠹ࠩ࡝ࠫࠍࠍࠎࠏࠉࠊࠋࠌࢀࠏࠏࠉࠊࠋࠌࠍࠎࡢ࡛࡝ࡵ࠭ࠬࡄࡀࠨࡀࡒ࠿ࡵ࠹ࡄ࡛ࠣ࡞ࠪࡡ࠮࠮࠿࠻ࠪࡂࠥ࠭ࡅࡐ࠾ࡳ࠷࠭࠮࠴ࡼ࡝࡞࠱࠭࠯࠮࠿ࡑ࠿ࡴ࠸࠮ࡢࡳࠫ࠮ࡂࡠࡸ࠰ࠩࠬ࡞ࡠࠎࠎࠏࠉࠊࠋࠌ࠭ࠏࠏࠉࠊࠋࠌ࠭ࡠࡁࠬ࡞ࠌࠌࠍࠎࠏࠧࠨࠩൎ")
				o1inhxJQN8ADfKj75l = AxTYMhRlfyskNc0X19dvwtS.search(i2NXtDF0TVj396zyQJHbgEwGoqpm, M8svrdxPzeh0jo3T5I)
				if not o1inhxJQN8ADfKj75l: return None, None
				ZpFuhCs2dOV = o1inhxJQN8ADfKj75l.group(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡴࡡ࡮ࡧࠪ൏"))
				jOZbhpwqsxmKN = o1inhxJQN8ADfKj75l.group(lRKCWnNi0Edr984eI(u"࠭ࡶࡢ࡮ࡸࡩࠬ൐")).strip()
				RpkDf93N4IEyYLACrltKB = AxTYMhRlfyskNc0X19dvwtS.match(GTmHXIZUSdxRhMnqQKkO(u"ࡲࠨࠩࠪࠬࡄࡾࠩࠋࠋࠌࠍࠎࠏࠨࡀࡒ࠿ࡵࡃࡡࠢࠨ࡟ࠬࠬࡄࡖ࠼ࡴࡶࡵ࡭ࡳ࡭࠾࠯ࠬࡂ࠭࠭ࡅࡐ࠾ࡳࠬࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭࠮࠿ࡑ࠾ࡴ࠶ࡃࡡࠢࠨ࡟ࠬࠬࡄࡖ࠼ࡴࡧࡳࡂ࠳࠰࠿ࠪࠪࡂࡔࡂࡷ࠲ࠪ࡞ࠬࠎࠎࠏࠉࠊࠩࠪࠫ൑"), jOZbhpwqsxmKN)
				if RpkDf93N4IEyYLACrltKB:
					gZlcqzuspvkaLKT = RpkDf93N4IEyYLACrltKB.group(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡵࡷࡶ࡮ࡴࡧࠨ൒"))
					kLI8jw2xBz4AtPeHsp = RpkDf93N4IEyYLACrltKB.group(kAz7WRYjrfGm(u"ࠩࡶࡩࡵ࠭൓"))
					return ZpFuhCs2dOV, gZlcqzuspvkaLKT.split(kLI8jw2xBz4AtPeHsp)
				if jOZbhpwqsxmKN.startswith(KKCrwPdOgGl(u"ࠥ࡟ࠧൔ")) and jOZbhpwqsxmKN.endswith(I6Bfzysrvb8DONZ(u"ࠦࡢࠨൕ")):
					try:
						SBFEJOzWgGhwvCdq4xQf = eeBhUDTWw3vfZ6gAiHLxalKuQE.literal_eval(jOZbhpwqsxmKN)
						return ZpFuhCs2dOV, SBFEJOzWgGhwvCdq4xQf
					except: return ZpFuhCs2dOV, None
				return ZpFuhCs2dOV, None
			def _nU9zdv0OajEp5eosqtP(M8svrdxPzeh0jo3T5I):
				ZpFuhCs2dOV, chyNKu6EXMg5 = _95ROKP6kb1LqiH(M8svrdxPzeh0jo3T5I)
				inDT1G3QkMZLjc = None
				if chyNKu6EXMg5:
					try: basestring
					except NameError: basestring = str
					for qq7jWMYgA8 in chyNKu6EXMg5:
						if isinstance(qq7jWMYgA8, basestring) and qq7jWMYgA8.endswith(zWBnYSGIatjXVC(u"ࠬ࠳࡟ࡸ࠺ࡢࠫൖ")):
							inDT1G3QkMZLjc = qq7jWMYgA8
							break
				if inDT1G3QkMZLjc:
					i2NXtDF0TVj396zyQJHbgEwGoqpm = KKCrwPdOgGl(u"ࡸࠧࠨࠩࠫࡃࡽ࠯ࠊࠊࠋࠌࠍࠎࠏ࡜ࡼ࡞ࡶ࠮ࡷ࡫ࡴࡶࡴࡱࡠࡸ࠱ࠥࡴ࡞࡞ࠩࡩࡢ࡝࡝ࡵ࠭ࡠ࠰ࡢࡳࠫࠪࡂࡔࡁࡧࡲࡨࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝ࡵ࠭ࡠࢂࠐࠉࠊࠋࠌࠍࠬ࠭ࠧൗ") % (AxTYMhRlfyskNc0X19dvwtS.escape(ZpFuhCs2dOV), chyNKu6EXMg5.index(inDT1G3QkMZLjc))
					match = AxTYMhRlfyskNc0X19dvwtS.search(i2NXtDF0TVj396zyQJHbgEwGoqpm, M8svrdxPzeh0jo3T5I)
					if match:
						i2NXtDF0TVj396zyQJHbgEwGoqpm = JZ45mOctiTszPNw1GVjxhep2Y(u"ࡲࠨࠩࠪࠬࡄࡾࠩࠋࠋࠌࠍࠎࠏࠉࠊ࡞ࡾࡠࡸ࠰࡜ࠪࠧࡶࡠ࠭ࡢࡳࠫࠌࠌࠍࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎࠏࠉࠩࡁࡓࡀ࡫ࡻ࡮ࡤࡰࡤࡱࡪࡥࡡ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫ࡟ࡷ࠯ࡴ࡯ࡪࡶࡦࡲࡺ࡬࡜ࡴࠬࠍࠍࠎࠏࠉࠊࠋࠌࠍࢁࡴ࡯ࡪࡶࡦࡲࡺ࡬࡜ࡴࠬࡀࡠࡸ࠰ࠨࡀࡒ࠿ࡪࡺࡴࡣ࡯ࡣࡰࡩࡤࡨ࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪࠪࡂ࠾ࡡࡹࠫࡳࡣࡹ࠭ࡄࠐࠉࠊࠋࠌࠍࠎࠏࠩ࡜࠽࡟ࡲࡢࠐࠉࠊࠋࠌࠍࠎ࠭ࠧࠨ൘") % AxTYMhRlfyskNc0X19dvwtS.escape(match.group(pYeVwat64v(u"ࠨࡣࡵ࡫ࡳࡧ࡭ࡦࠩ൙"))[::-I6Bfzysrvb8DONZ(u"࠵࿮")])
						PlyxOAgkBpr8QwUsmXMTbqF = AxTYMhRlfyskNc0X19dvwtS.search(i2NXtDF0TVj396zyQJHbgEwGoqpm, M8svrdxPzeh0jo3T5I[match.start()::-I6Bfzysrvb8DONZ(u"࠶࿯")])
						if PlyxOAgkBpr8QwUsmXMTbqF:
							ooxHaLpetPMAFsS, RuAY8K2ZThoEsOtwiIy9k6cC4r3Q = PlyxOAgkBpr8QwUsmXMTbqF.group(Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡩࡹࡳࡩ࡮ࡢ࡯ࡨࡣࡦ࠭൚"), jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡪࡺࡴࡣ࡯ࡣࡰࡩࡤࡨࠧ൛"))
							return (ooxHaLpetPMAFsS or RuAY8K2ZThoEsOtwiIy9k6cC4r3Q)[::-CCWqR3dmtzw6xoIX41(u"࠷࿰")], ZpFuhCs2dOV, chyNKu6EXMg5
				rriqxFghRlaB6dwsHv07PE = AxTYMhRlfyskNc0X19dvwtS.compile(nR0ok9zju84rFUQl1YC(u"ࡶࠬ࠭ࠧࠩࡁࡻ࠭ࠏࠏࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࠏ࡜࠯ࡩࡨࡸࡡ࠮ࠢ࡯ࠤ࡟࠭ࡡ࠯ࠦࠧ࡞ࠫࡦࡂࢂࠊࠊࠋࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊࠋࠌࡦࡂ࡙ࡴࡳ࡫ࡱ࡫ࡡ࠴ࡦࡳࡱࡰࡇ࡭ࡧࡲࡄࡱࡧࡩࡡ࠮࠱࠲࠲࡟࠭ࢁࠐࠉࠊࠋࠌࠍࠎࠏࠨࡀࡒ࠿ࡷࡹࡸ࡟ࡪࡦࡻࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦ࠱ࡡ࠰࠯ࠦࠧ࡞ࠫࡦࡂࠨ࡮࡯ࠤ࡟࡟ࡡ࠱ࠨࡀࡒࡀࡷࡹࡸ࡟ࡪࡦࡻ࠭ࡡࡣࠊࠊࠋࠌࠍࠎࠏࠩࠋࠋࠌࠍࠎࠏࠉࠩࡁ࠽ࠎࠎࠏࠉࠊࠋࠌࠍ࠱ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢࠨࡢ࡞ࠬ࠭ࡄ࠲ࡣ࠾ࡣ࡟࠲ࠏࠏࠉࠊࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉࠊࠋࠌ࡫ࡪࡺ࡜ࠩࡤ࡟࠭ࢁࠐࠉࠊࠋࠌࠍࠎࠏࠉ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࡝ࡥࡠࡢࡢࡼ࡝ࡾࡱࡹࡱࡲࠊࠊࠋࠌࠍࠎࠏࠉࠪ࡞ࠬࠪࠫࡢࠨࡤ࠿ࡿࠎࠎࠏࠉࠊࠋࠌࡠࡧ࠮࠿ࡑ࠾ࡹࡥࡷࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࠾ࠌࠌࠍࠎࠏࠉࠪࠪࡂࡔࡁࡴࡦࡶࡰࡦࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮࠮࠿࠻࡞࡞ࠬࡄࡖ࠼ࡪࡦࡻࡂࡡࡪࠫࠪ࡞ࡠ࠭ࡄࡢࠨ࡜ࡣ࠰ࡾࡆ࠳࡚࡞࡞ࠬࠎࠎࠏࠉࠊࠋࠫࡃ࠭ࡼࡡࡳࠫ࠯࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠳ࡹࡥࡵ࡞ࠫࠬࡄࡀࠢ࡯࠭ࠥࢀࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡢࠬࠩࡁࡓࡁࡻࡧࡲࠪ࡞ࠬ࠭ࠏࠏࠉࠊࠋࠪࠫࠬ൜"))
				match = rriqxFghRlaB6dwsHv07PE.search(M8svrdxPzeh0jo3T5I)
				nGHb32CxhmeAc, IIUbmvhxWqeJDLkGfs1y5XcPij = (None, None)
				if match:
					nGHb32CxhmeAc = match.group(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡴࡦࡶࡰࡦࠫ൝"))
					IIUbmvhxWqeJDLkGfs1y5XcPij = match.group(kAz7WRYjrfGm(u"࠭ࡩࡥࡺࠪ൞"))
				if not nGHb32CxhmeAc:
					print(zWBnYSGIatjXVC(u"ࠧࡇࡣ࡯ࡰ࡮ࡴࡧࠡࡤࡤࡧࡰࠦࡴࡰࠢࡪࡩࡳ࡫ࡲࡪࡥࠣࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡴࡧࡤࡶࡨ࡮ࠧൟ"))
					q76sN3vzW5OV = AxTYMhRlfyskNc0X19dvwtS.search(B1YMtuvRAGNlJOkC46VyPKQE(u"ࡳࠩࠪࠫ࠭ࡅࡸࡴࠫࠍࠍࠎࠏࠉࠊࠋ࠾ࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫ࡟ࡷ࠯ࡃ࡜ࡴࠬࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢࠩࠋࠋࠌࠍࠎࠏࠉ࡝ࡵ࠭ࡠࢀ࠮࠿࠻ࠪࡂࠥࢂࡁࠩ࠯ࠫ࠮ࡃࡷ࡫ࡴࡶࡴࡱࡠࡸ࠰ࠨࡀࡒ࠿ࡵࡃࡡࠢࠨ࡟ࠬ࡟ࡡࡽ࠭࡞࠭ࡢࡻ࠽ࡥࠨࡀࡒࡀࡵ࠮ࡢࡳࠫ࡞࠮ࡠࡸ࠰࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠊࠊࠋࠌࠍࠎ࠭ࠧࠨൠ"), M8svrdxPzeh0jo3T5I)
					if q76sN3vzW5OV: return q76sN3vzW5OV.group(KKCrwPdOgGl(u"ࠩࡱࡥࡲ࡫ࠧൡ")), ZpFuhCs2dOV, chyNKu6EXMg5
					return None,None,None
				elif not IIUbmvhxWqeJDLkGfs1y5XcPij: return nGHb32CxhmeAc, ZpFuhCs2dOV, chyNKu6EXMg5
				uNz43Zk5VsI1cgtCaU0QjBnr = AxTYMhRlfyskNc0X19dvwtS.search(ba49YvOK2Aw8Uhxt(u"ࡵࠫࡻࡧࡲࠡࡽࢀࡠࡡࡹࠪ࠾࡞࡟ࡷ࠯࠮࡜࡝࡝࠱࠯ࡄࡢ࡜࡞ࠫ࡟ࡠࡸ࠰࡛࠭࠽ࡠࠫൢ").format(AxTYMhRlfyskNc0X19dvwtS.escape(nGHb32CxhmeAc)), M8svrdxPzeh0jo3T5I)
				if uNz43Zk5VsI1cgtCaU0QjBnr: return WWNb0XnUxOPL9gF.loads(fbGvwrEixHJWpgIauFzySQonP2(uNz43Zk5VsI1cgtCaU0QjBnr.group(W2Vv30i8qxSuItfsolPLdFZA(u"࠱࿱"))))[int(IIUbmvhxWqeJDLkGfs1y5XcPij)], ZpFuhCs2dOV, chyNKu6EXMg5
				return None, ZpFuhCs2dOV, chyNKu6EXMg5
			h73hse0EqGxXo, l4SRhnoaz2iJCpfwm31DZe6GFNAPuL, chyNKu6EXMg5 = _nU9zdv0OajEp5eosqtP(B2Xex34ilkh1K)
			if not h73hse0EqGxXo: w4dBvakygFs2IZO1Azt(hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࠬൣ"),kAz7WRYjrfGm(u"ࠬ࠭൤"),lRKCWnNi0Edr984eI(u"࡙࠭ࡰࡷࡷࡹࡧ࡫๋๊ࠠอ๎ํฮࠧ൥"),I6Bfzysrvb8DONZ(u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡥࡧࡦࡶࡾࡶࡴࡪࡰࡪࠤࡵࡲࡡࡺࠢ࡯࡭ࡳࡱࡳࠡ࡞ࡱࡠࡳࠦแีๆࠣๅ๏ࠦแหฯࠣฮู็๊าࠢิ์ฬฮืࠡษ็ๅ๏ี๊้ࠩ൦"))
			else:
				S8StKBE1PGjg0ApuVfIlvo = WWNb0XnUxOPL9gF.dumps(chyNKu6EXMg5)
				n6BR0geQsVj2hvyIYfmDuow1NLU = B2Xex34ilkh1K.find(h73hse0EqGxXo+f9fOpCmLAEaW2Go(u"ࠨ࠿ࡩࡹࡳࡩࡴࡪࡱࡱࠬࠬ൧"))
				LOeNgpAS8uDFh13rvH90IVz6Xwfob = B2Xex34ilkh1K.find(pL73X0MYajJQG4n1qgD(u"ࠩࢀ࠿ࠬ൨"), n6BR0geQsVj2hvyIYfmDuow1NLU)
				YpNltkbn2a5 = B2Xex34ilkh1K[n6BR0geQsVj2hvyIYfmDuow1NLU:LOeNgpAS8uDFh13rvH90IVz6Xwfob]+zWBnYSGIatjXVC(u"ࠪࢁࡀ࠭൩")
				csmfbywC67ZvgaSR5UO8nMe = AxTYMhRlfyskNc0X19dvwtS.findall(W2Vv30i8qxSuItfsolPLdFZA(u"ࡶࠬ࡯ࡦ࡝ࠪࡷࡽࡵ࡫࡯ࡧࠢ࠱࠮ࡄࡃ࠽࠾࠰࠭ࡃࡡ࠯ࡲࡦࡶࡸࡶࡳࠦ࠮࠼ࠩ൪"), YpNltkbn2a5, AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if csmfbywC67ZvgaSR5UO8nMe: YpNltkbn2a5 = YpNltkbn2a5.replace(csmfbywC67ZvgaSR5UO8nMe[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠱࿲")],W2Vv30i8qxSuItfsolPLdFZA(u"ࠬ࠭൫"))
				if not l4SRhnoaz2iJCpfwm31DZe6GFNAPuL: l4SRhnoaz2iJCpfwm31DZe6GFNAPuL = AxTYMhRlfyskNc0X19dvwtS.findall(pbmKZA1w7L4zHjOM(u"࠭ࡶࡢࡴࠣ࠲࠯ࡅ࠽ࠩ࠰࠭ࡃ࠮ࡢ࠮ࠨ൬"),YpNltkbn2a5,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
				YpNltkbn2a5 = YpNltkbn2a5.replace(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧ࡝ࡰࠪ൭"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				YpNltkbn2a5 = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠣࡸࡤࡶࠥࢁࡽࠡ࠿ࠣࡿࢂࡁ࡜࡯ࡽࢀࠦ൮").format(l4SRhnoaz2iJCpfwm31DZe6GFNAPuL, S8StKBE1PGjg0ApuVfIlvo, YpNltkbn2a5)
				VXquYwzfTkc8lQ = {}
				v5fLFCSdQoh3KMay6AbIRN = []
				for azunJ3rwKTx02 in AuQOImP7oU9:
					url = azunJ3rwKTx02[f9fOpCmLAEaW2Go(u"ࠩࡸࡶࡱ࠭൯")]
					if slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࠪࡳࡃࠧ൰") in url:
						BJjagXA3ZOhmeEub6NCzI2rfkstl = AxTYMhRlfyskNc0X19dvwtS.findall(rAYDiWlzm9MCU6x0GnROua(u"ࠫࠫࡴ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ൱"),url,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
						if BJjagXA3ZOhmeEub6NCzI2rfkstl not in list(VXquYwzfTkc8lQ.keys()):
							BeqzkRG1Fw = xehSBEVjbMUOmYL0NipDH9(YpNltkbn2a5,[h73hse0EqGxXo,BJjagXA3ZOhmeEub6NCzI2rfkstl])
							VXquYwzfTkc8lQ[BJjagXA3ZOhmeEub6NCzI2rfkstl] = BeqzkRG1Fw
						else: BeqzkRG1Fw = VXquYwzfTkc8lQ[BJjagXA3ZOhmeEub6NCzI2rfkstl]
						azunJ3rwKTx02[f9fOpCmLAEaW2Go(u"ࠬࡻࡲ࡭ࠩ൲")] = url.replace(I6Bfzysrvb8DONZ(u"࠭ࠦ࡯࠿ࠪ൳")+BJjagXA3ZOhmeEub6NCzI2rfkstl+KKCrwPdOgGl(u"ࠧࠧࠩ൴"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࠨࡱࡁࠬ൵")+BeqzkRG1Fw+CCWqR3dmtzw6xoIX41(u"ࠩࠩࠫ൶"))
					v5fLFCSdQoh3KMay6AbIRN.append(azunJ3rwKTx02)
				AuQOImP7oU9 = v5fLFCSdQoh3KMay6AbIRN.copy()
	for dict in AuQOImP7oU9:
		url = dict[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡹࡷࡲࠧ൷")]
		if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨ൸") in url or url.count(W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡹࡩࡨ࠿ࠪ൹"))>xD9WeoEAsX7: UUtCreW4VIkcsRvmDj.append(dict)
		elif B2Xex34ilkh1K and W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡳࠨൺ") in dict and I6Bfzysrvb8DONZ(u"ࠧࡴࡲࠪൻ") in dict:
			dJ3gr74yvMROu = hkY8lwcBtKyR0vxDUTfXgC4VGunF2I.execute(dict[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡵࠪർ")])
			if dJ3gr74yvMROu!=dict[kAz7WRYjrfGm(u"ࠩࡶࠫൽ")]:
				dict[w9wfONXUP3(u"ࠪࡹࡷࡲࠧൾ")] = url+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࠫ࠭ൿ")+dict[KKCrwPdOgGl(u"ࠬࡹࡰࠨ඀")]+I6Bfzysrvb8DONZ(u"࠭࠽ࠨඁ")+dJ3gr74yvMROu
				UUtCreW4VIkcsRvmDj.append(dict)
		else: UUtCreW4VIkcsRvmDj.append(dict)
	for dict in UUtCreW4VIkcsRvmDj:
		kw7O9B5fZceYAn0RbNtL,HO0rfZx3TpaqvyYbuEidJ6nAt9k,ojXrdanNREvbhiSHpfD7O0UTe8mBc,i1svWTIM79yezDZXt2gnACupwY,H6HeZjXpNDrwg,ggeavOjMDpm3kITVN82hySo1 = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨං"),zWBnYSGIatjXVC(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩඃ"),pYeVwat64v(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ඄"),pL73X0MYajJQG4n1qgD(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫඅ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫ࠵࠭ආ")
		try:
			sTQm3JtPgixMl4B = dict[I6Bfzysrvb8DONZ(u"ࠬࡺࡹࡱࡧࠪඇ")]
			sTQm3JtPgixMl4B = sTQm3JtPgixMl4B.replace(ba49YvOK2Aw8Uhxt(u"࠭ࠫࠨඈ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			items = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩඉ"),sTQm3JtPgixMl4B,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			i1svWTIM79yezDZXt2gnACupwY,kw7O9B5fZceYAn0RbNtL,H6HeZjXpNDrwg = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
			Wl0VOy1rtaD96x5sz3qFghe = H6HeZjXpNDrwg.split(hWRvZOYtjme9QNnV41u0Mswb(u"ࠨ࠮ࠪඊ"))
			HO0rfZx3TpaqvyYbuEidJ6nAt9k = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			for Uz7N5KAHwQ93iShW1xj in Wl0VOy1rtaD96x5sz3qFghe: HO0rfZx3TpaqvyYbuEidJ6nAt9k += Uz7N5KAHwQ93iShW1xj.split(YzlId3Fs6vpehcbLGj0UaO(u"ࠩ࠱ࠫඋ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+w9wfONXUP3(u"ࠪ࠰ࠬඌ")
			HO0rfZx3TpaqvyYbuEidJ6nAt9k = HO0rfZx3TpaqvyYbuEidJ6nAt9k.strip(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠱࠭ඍ"))
			if kAz7WRYjrfGm(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ඎ") in dict: ggeavOjMDpm3kITVN82hySo1 = str(int(dict[zWBnYSGIatjXVC(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧඏ")])//KKCrwPdOgGl(u"࠳࠳࠶࠹࿳"))+rAYDiWlzm9MCU6x0GnROua(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧඐ")
			else: ggeavOjMDpm3kITVN82hySo1 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			if i1svWTIM79yezDZXt2gnACupwY==nR0ok9zju84rFUQl1YC(u"ࠨࡶࡨࡼࡹ࠭එ"): continue
			elif MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࠯ࠫඒ") in sTQm3JtPgixMl4B:
				i1svWTIM79yezDZXt2gnACupwY = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡅ࠰࡜ࠧඓ")
				ojXrdanNREvbhiSHpfD7O0UTe8mBc = kw7O9B5fZceYAn0RbNtL+zHYL9u48eyJot+ggeavOjMDpm3kITVN82hySo1+dict[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡸ࡯ࡺࡦࠩඔ")].split(zWBnYSGIatjXVC(u"ࠬࡾࠧඕ"))[xD9WeoEAsX7]
			elif i1svWTIM79yezDZXt2gnACupwY==lRKCWnNi0Edr984eI(u"࠭ࡶࡪࡦࡨࡳࠬඖ"):
				i1svWTIM79yezDZXt2gnACupwY = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡗ࡫ࡧࡩࡴ࠭඗")
				ojXrdanNREvbhiSHpfD7O0UTe8mBc = ggeavOjMDpm3kITVN82hySo1+dict[hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡵ࡬ࡾࡪ࠭඘")].split(CCWqR3dmtzw6xoIX41(u"ࠩࡻࠫ඙"))[xD9WeoEAsX7]+zHYL9u48eyJot+dict[rAYDiWlzm9MCU6x0GnROua(u"ࠪࡪࡵࡹࠧක")]+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫ࡫ࡶࡳࠨඛ")+zHYL9u48eyJot+kw7O9B5fZceYAn0RbNtL
			elif i1svWTIM79yezDZXt2gnACupwY==Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡧࡵࡥ࡫ࡲࠫග"):
				i1svWTIM79yezDZXt2gnACupwY = Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡁࡶࡦ࡬ࡳࠬඝ")
				ojXrdanNREvbhiSHpfD7O0UTe8mBc = ggeavOjMDpm3kITVN82hySo1+str(int(dict[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫඞ")])/KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠴࠴࠵࠶࿴"))+zWBnYSGIatjXVC(u"ࠨ࡭࡫ࡾࠥࠦࠧඟ")+dict[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪච")]+YzlId3Fs6vpehcbLGj0UaO(u"ࠪࡧ࡭࠭ඡ")+zHYL9u48eyJot+kw7O9B5fZceYAn0RbNtL
		except:
			YK1U4PZlH6MErXStRaVyb3J7hjnG = VGgFQrd6JwjRCmp2aPAos0ycLkv.format_exc()
			if YK1U4PZlH6MErXStRaVyb3J7hjnG!=W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧජ"): qv7XKecsSGz6rBTpt.stderr.write(YK1U4PZlH6MErXStRaVyb3J7hjnG)
		url = WDg18QHF3rze(dict[I6Bfzysrvb8DONZ(u"ࠬࡻࡲ࡭ࠩඣ")])
		if zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࠦࡥࡷࡵࡁࠬඤ") in url: w03zWJvcXaCUySB6HIq4mVe = round(nR0ok9zju84rFUQl1YC(u"࠴࠳࠻࿵")+float(url.split(GTmHXIZUSdxRhMnqQKkO(u"ࠧࠧࡦࡸࡶࡂ࠭ඥ"),xD9WeoEAsX7)[xD9WeoEAsX7].split(Zb5cNeHWi6jP9SCYtUgR(u"ࠨࠨࠪඦ"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]))
		elif W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࠾ࡨࡺࡸ࠽ࠨට") in url: w03zWJvcXaCUySB6HIq4mVe = round(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵࠴࠵࿶")+float(url.split(W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࠿ࡩࡻࡲ࠾ࠩඨ"),xD9WeoEAsX7)[xD9WeoEAsX7].split(KKCrwPdOgGl(u"ࠫࡀ࠭ඩ"),xD9WeoEAsX7)[nUaVQsoA6EXcK4Odht5wCge0J8Pib]))
		elif w9wfONXUP3(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨඪ") in dict: w03zWJvcXaCUySB6HIq4mVe = round(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠶࠮࠶࿷")+float(dict[f9fOpCmLAEaW2Go(u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩණ")])/KKCrwPdOgGl(u"࠱࠱࠲࠳࿸"))
		else: w03zWJvcXaCUySB6HIq4mVe = Zb5cNeHWi6jP9SCYtUgR(u"ࠧ࠱ࠩඬ")
		if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩත") not in dict: ggeavOjMDpm3kITVN82hySo1 = dict[w9wfONXUP3(u"ࠩࡶ࡭ࡿ࡫ࠧථ")].split(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡼࠬද"))[xD9WeoEAsX7]
		else: ggeavOjMDpm3kITVN82hySo1 = str(int(dict[YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬධ")])//YzlId3Fs6vpehcbLGj0UaO(u"࠲࠲࠵࠸࿹"))
		if rAYDiWlzm9MCU6x0GnROua(u"ࠬ࡯࡮ࡪࡶࠪන") not in dict: dict[B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡩ࡯࡫ࡷࠫ඲")] = W2Vv30i8qxSuItfsolPLdFZA(u"ࠧ࠱࠯࠳ࠫඳ")
		dict[KKCrwPdOgGl(u"ࠨࡶ࡬ࡸࡱ࡫ࠧප")] = i1svWTIM79yezDZXt2gnACupwY+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩ࠽ࠤࠥ࠭ඵ")+ojXrdanNREvbhiSHpfD7O0UTe8mBc+lRKCWnNi0Edr984eI(u"ࠪࠤࠥ࠮ࠧබ")+HO0rfZx3TpaqvyYbuEidJ6nAt9k+nR0ok9zju84rFUQl1YC(u"ࠫ࠱࠭භ")+dict[ba49YvOK2Aw8Uhxt(u"ࠬ࡯ࡴࡢࡩࠪම")]+djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࠩࠨඹ")
		dict[hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨය")] = ojXrdanNREvbhiSHpfD7O0UTe8mBc.split(zHYL9u48eyJot)[nUaVQsoA6EXcK4Odht5wCge0J8Pib].split(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨ࡭ࡥࡴࡸ࠭ර"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		dict[ba49YvOK2Aw8Uhxt(u"ࠩࡷࡽࡵ࡫࠲ࠨ඼")] = i1svWTIM79yezDZXt2gnACupwY
		dict[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬල")] = kw7O9B5fZceYAn0RbNtL
		dict[lRKCWnNi0Edr984eI(u"ࠫࡨࡵࡤࡦࡥࡶࠫ඾")] = H6HeZjXpNDrwg
		dict[f9fOpCmLAEaW2Go(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ඿")] = w03zWJvcXaCUySB6HIq4mVe
		dict[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧව")] = ggeavOjMDpm3kITVN82hySo1
		tcnpYWNg43RCy0.append(dict)
	ijfU0DO5xmLnrZ4lNP6,oYx2hFGErZCT3g9BlqvKDckeRb,TfWqrGd2etSYJzLb3cy,LQDRBzOaSCF3mpe97oyqv8NVAl5T,OgywhDGfxSFpY5MzmL9WuQtn3vX = [],[],[],[],[]
	m9OGJlTIkHEuD6SbUNjw1Xr,NNQHWXyno7VZ,EjryLdYk3w4fC5BAegpInXq7hS12o,Fm5vMAikPNRCqhG,WmIjs8yrVY7Tu1pxUP3d0l = [],[],[],[],[]
	for N27XxPWvIzYQFcVwMJq in kyCqOHoErF0AQjfKV5vhDlJtigIbu:
		if not N27XxPWvIzYQFcVwMJq: continue
		dict = {}
		dict[f9fOpCmLAEaW2Go(u"ࠧࡵࡻࡳࡩ࠷࠭ශ")] = pbmKZA1w7L4zHjOM(u"ࠨࡃ࠮࡚ࠬෂ")
		dict[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫස")] = GTmHXIZUSdxRhMnqQKkO(u"ࠪࡱࡵࡪࠧහ")
		dict[pbmKZA1w7L4zHjOM(u"ࠫࡹ࡯ࡴ࡭ࡧࠪළ")] = dict[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡺࡹࡱࡧ࠵ࠫෆ")]+KKCrwPdOgGl(u"࠭࠺ࠡࠢࠪ෇")+dict[lRKCWnNi0Edr984eI(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ෈")]+zHYL9u48eyJot+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ෉")
		dict[YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡸࡶࡱ්࠭")] = N27XxPWvIzYQFcVwMJq
		dict[I6Bfzysrvb8DONZ(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ෋")] = GTmHXIZUSdxRhMnqQKkO(u"ࠫ࠵࠭෌")
		dict[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭෍")] = lRKCWnNi0Edr984eI(u"࠭࠱࠲࠳࠵࠶࠷࠹࠳࠴ࠩ෎")
		tcnpYWNg43RCy0.append(dict)
	for l3lXxhJwMAmSgQq8tfpOL2 in EEtLS3FMvmwh6Xx:
		if not l3lXxhJwMAmSgQq8tfpOL2: continue
		kVw0YQZ3rTqvsiX,A0LEKGq2Bb9pnXy1ZTmduYlSf4UsM8 = vn9QxuZF4f2YzCVpELgkc(mI6ayKxBvjd4CRthL,l3lXxhJwMAmSgQq8tfpOL2)
		SzJysZ5NDpTd = list(zip(kVw0YQZ3rTqvsiX,A0LEKGq2Bb9pnXy1ZTmduYlSf4UsM8))
		for title,cX2SpPxGLmADTKl in SzJysZ5NDpTd:
			dict = {}
			dict[pYeVwat64v(u"ࠧࡵࡻࡳࡩ࠷࠭ා")] = pYeVwat64v(u"ࠨࡃ࠮࡚ࠬැ")
			dict[YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫෑ")] = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡱ࠸ࡻ࠸ࠨි")
			dict[GTmHXIZUSdxRhMnqQKkO(u"ࠫࡺࡸ࡬ࠨී")] = cX2SpPxGLmADTKl
			if GTmHXIZUSdxRhMnqQKkO(u"ࠬࡱࡢࡱࡵࠪු") in title: dict[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ෕")] = title.split(pbmKZA1w7L4zHjOM(u"ࠧ࡬ࡤࡳࡷࠬූ"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib].rsplit(zHYL9u48eyJot)[-xD9WeoEAsX7]
			else: dict[GTmHXIZUSdxRhMnqQKkO(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ෗")] = ba49YvOK2Aw8Uhxt(u"ࠩ࠴࠴ࠬෘ")
			if title.count(zHYL9u48eyJot)>xD9WeoEAsX7:
				XcvFdKRjNLz5wEpDf = title.rsplit(zHYL9u48eyJot)[-anb4QpyjlmgVwANP]
				if XcvFdKRjNLz5wEpDf.isdigit(): dict[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫෙ")] = XcvFdKRjNLz5wEpDf
				else: dict[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬේ")] = YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࠶࠰࠱࠲ࠪෛ")
			if title==kAz7WRYjrfGm(u"࠭࠭࠲ࠩො"): dict[I6Bfzysrvb8DONZ(u"ࠧࡵ࡫ࡷࡰࡪ࠭ෝ")] = dict[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࡶࡼࡴࡪ࠸ࠧෞ")]+W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࠽ࠤࠥ࠭ෟ")+dict[rAYDiWlzm9MCU6x0GnROua(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ෠")]+zHYL9u48eyJot+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫั๎ฯสࠢำ็๏ฯࠧ෡")
			else: dict[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡺࡩࡵ࡮ࡨࠫ෢")] = dict[zWBnYSGIatjXVC(u"࠭ࡴࡺࡲࡨ࠶ࠬ෣")]+lRKCWnNi0Edr984eI(u"ࠧ࠻ࠢࠣࠫ෤")+dict[nR0ok9zju84rFUQl1YC(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ෥")]+zHYL9u48eyJot+dict[CCWqR3dmtzw6xoIX41(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ෦")]+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ෧")+dict[pbmKZA1w7L4zHjOM(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ෨")]
			tcnpYWNg43RCy0.append(dict)
	tcnpYWNg43RCy0 = sorted(tcnpYWNg43RCy0,reverse=NFGqKBLtvUZn1S3dau,key=lambda key: int(key[I6Bfzysrvb8DONZ(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭෩")]))
	GjC4atkJLwlTpsI,CBL4OQVtWbMAycUGl7Ex2SKZF = [jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ෪")],[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O]
	try: kwTdxbnQEXF3 = mUcBGLls4CubXQWkj1392fY[pL73X0MYajJQG4n1qgD(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩ෫")][vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ෬")][w9wfONXUP3(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩ෭")]
	except: kwTdxbnQEXF3 = []
	try: fftYwK3xmjn0LP8XROuCaZ59vQDWkp = mUcBGLls4CubXQWkj1392fY[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ෮")][nR0ok9zju84rFUQl1YC(u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ෯")][CCWqR3dmtzw6xoIX41(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ෰")]
	except: fftYwK3xmjn0LP8XROuCaZ59vQDWkp = []
	for gL1vWVAB3FeX in kwTdxbnQEXF3+fftYwK3xmjn0LP8XROuCaZ59vQDWkp:
		try:
			cX2SpPxGLmADTKl = gL1vWVAB3FeX[YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ෱")]
			try: title = gL1vWVAB3FeX[GTmHXIZUSdxRhMnqQKkO(u"ࠧ࡯ࡣࡰࡩࠬෲ")][MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬෳ")]
			except: title = gL1vWVAB3FeX[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࡱࡥࡲ࡫ࠧ෴")][lRKCWnNi0Edr984eI(u"ࠪࡶࡺࡴࡳࠨ෵")][nUaVQsoA6EXcK4Odht5wCge0J8Pib][nR0ok9zju84rFUQl1YC(u"ࠫࡹ࡫ࡸࡵࠩ෶")]
		except: continue
		if title not in GjC4atkJLwlTpsI:
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
			GjC4atkJLwlTpsI.append(title)
	if len(GjC4atkJLwlTpsI)>xD9WeoEAsX7:
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(W2Vv30i8qxSuItfsolPLdFZA(u"ࠬอฮหำࠣห้ะัอ็ฬࠤ࠭࠭෷")+str(len(GjC4atkJLwlTpsI))+jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࠠๆๆไ࠭ࠬ෸"),GjC4atkJLwlTpsI)
		if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ෹"),[],[]
		elif qNmsBD1jJZVzcxi4onKuAOIC!=nUaVQsoA6EXcK4Odht5wCge0J8Pib:
			cX2SpPxGLmADTKl = CBL4OQVtWbMAycUGl7Ex2SKZF[qNmsBD1jJZVzcxi4onKuAOIC]+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࠨࠪ෺")
			qaes4EVrFQJtXGnTxvH3pYy1N6f = AxTYMhRlfyskNc0X19dvwtS.findall(GTmHXIZUSdxRhMnqQKkO(u"ࠩࠩࠬ࡫ࡳࡴ࠾࠰࠭ࡃ࠮ࠬࠧ෻"),cX2SpPxGLmADTKl)
			if qaes4EVrFQJtXGnTxvH3pYy1N6f: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(qaes4EVrFQJtXGnTxvH3pYy1N6f[nUaVQsoA6EXcK4Odht5wCge0J8Pib],rAYDiWlzm9MCU6x0GnROua(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ෼"))
			else: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ෽")
			DNTxgeJIKdhLH9qZYnB1U = cX2SpPxGLmADTKl.strip(hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࠬࠧ෾"))
	BBamT8X6gqtA7RdEeUzy = []
	for dict in tcnpYWNg43RCy0:
		if dict[ba49YvOK2Aw8Uhxt(u"࠭ࡴࡺࡲࡨ࠶ࠬ෿")]==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡗ࡫ࡧࡩࡴ࠭฀"):
			ijfU0DO5xmLnrZ4lNP6.append(dict[f9fOpCmLAEaW2Go(u"ࠨࡶ࡬ࡸࡱ࡫ࠧก")])
			m9OGJlTIkHEuD6SbUNjw1Xr.append(dict)
		elif dict[pL73X0MYajJQG4n1qgD(u"ࠩࡷࡽࡵ࡫࠲ࠨข")]==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡅࡺࡪࡩࡰࠩฃ"):
			oYx2hFGErZCT3g9BlqvKDckeRb.append(dict[lRKCWnNi0Edr984eI(u"ࠫࡹ࡯ࡴ࡭ࡧࠪค")])
			NNQHWXyno7VZ.append(dict)
		elif dict[KKCrwPdOgGl(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧฅ")]==W2Vv30i8qxSuItfsolPLdFZA(u"࠭࡭ࡱࡦࠪฆ") or dict[lRKCWnNi0Edr984eI(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩง")]==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨ࡯࠶ࡹ࠽࠭จ"):
			title = dict[Zb5cNeHWi6jP9SCYtUgR(u"ࠩࡷ࡭ࡹࡲࡥࠨฉ")].replace(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪช"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬซ") not in dict: ggeavOjMDpm3kITVN82hySo1 = Zb5cNeHWi6jP9SCYtUgR(u"ࠬ࠶ࠧฌ")
			else: ggeavOjMDpm3kITVN82hySo1 = dict[pYeVwat64v(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧญ")]
			BBamT8X6gqtA7RdEeUzy.append([dict,{},title,ggeavOjMDpm3kITVN82hySo1])
		else:
			title = dict[I6Bfzysrvb8DONZ(u"ࠧࡵ࡫ࡷࡰࡪ࠭ฎ")].replace(pL73X0MYajJQG4n1qgD(u"ࠨࡃ࠮࡚࠿ࠦࠠࠨฏ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪฐ") not in dict: ggeavOjMDpm3kITVN82hySo1 = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪ࠴ࠬฑ")
			else: ggeavOjMDpm3kITVN82hySo1 = dict[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬฒ")]
			BBamT8X6gqtA7RdEeUzy.append([dict,{},title,ggeavOjMDpm3kITVN82hySo1])
			TfWqrGd2etSYJzLb3cy.append(title)
			EjryLdYk3w4fC5BAegpInXq7hS12o.append(dict)
		iTuKAkOWJ9xU6f5De2FZy37 = NFGqKBLtvUZn1S3dau
		if pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬณ") in dict:
			if Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡡࡷ࠲ࠪด") in dict[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡤࡱࡧࡩࡨࡹࠧต")]: iTuKAkOWJ9xU6f5De2FZy37 = pLwgjkuTs6CS
			elif XqSerIMoFsRn2UQ1D5Alj6<jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠻࿺") and pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡣࡹࡧࠬถ") not in dict[hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩท")] and pL73X0MYajJQG4n1qgD(u"ࠪࡱࡵ࠺ࡡࠨธ") not in dict[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡨࡵࡤࡦࡥࡶࠫน")]: iTuKAkOWJ9xU6f5De2FZy37 = pLwgjkuTs6CS
		if iTuKAkOWJ9xU6f5De2FZy37 and dict[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡺࡹࡱࡧ࠵ࠫบ")]==Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡖࡪࡦࡨࡳࠬป"):
			OgywhDGfxSFpY5MzmL9WuQtn3vX.append(dict[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࡵ࡫ࡷࡰࡪ࠭ผ")])
			WmIjs8yrVY7Tu1pxUP3d0l.append(dict)
		elif iTuKAkOWJ9xU6f5De2FZy37 and dict[lRKCWnNi0Edr984eI(u"ࠨࡶࡼࡴࡪ࠸ࠧฝ")]==nR0ok9zju84rFUQl1YC(u"ࠩࡄࡹࡩ࡯࡯ࠨพ"):
			LQDRBzOaSCF3mpe97oyqv8NVAl5T.append(dict[lRKCWnNi0Edr984eI(u"ࠪࡸ࡮ࡺ࡬ࡦࠩฟ")])
			Fm5vMAikPNRCqhG.append(dict)
	for l0luG6eYDOsSbHmQTaPZj in Fm5vMAikPNRCqhG:
		m7I9p8MoecwtZsdgkyOWiQ6xnrNPJ = l0luG6eYDOsSbHmQTaPZj[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬภ")]
		for Ic5vdh3Xt8pjGY1FsTZ in WmIjs8yrVY7Tu1pxUP3d0l:
			cxBdXvVWZr5mKMuU3TDl9b4n8 = Ic5vdh3Xt8pjGY1FsTZ[kAz7WRYjrfGm(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ม")]
			ggeavOjMDpm3kITVN82hySo1 = int(cxBdXvVWZr5mKMuU3TDl9b4n8)+int(m7I9p8MoecwtZsdgkyOWiQ6xnrNPJ)
			title = Ic5vdh3Xt8pjGY1FsTZ[rAYDiWlzm9MCU6x0GnROua(u"࠭ࡴࡪࡶ࡯ࡩࠬย")].replace(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠡࠩร"),zWBnYSGIatjXVC(u"ࠨࡤ࡬ࡲࡩࠦࠠࠨฤ"))
			title = title.replace(Ic5vdh3Xt8pjGY1FsTZ[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫล")]+zHYL9u48eyJot,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			title = title.replace(cxBdXvVWZr5mKMuU3TDl9b4n8+w9wfONXUP3(u"ࠪ࡯ࡧࡶࡳࠨฦ"),str(ggeavOjMDpm3kITVN82hySo1)+I6Bfzysrvb8DONZ(u"ࠫࡰࡨࡰࡴࠩว"))
			title = title+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࠮ࠧศ")+l0luG6eYDOsSbHmQTaPZj[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡴࡪࡶ࡯ࡩࠬษ")].split(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࠩࠩส"),xD9WeoEAsX7)[xD9WeoEAsX7]
			BBamT8X6gqtA7RdEeUzy.append([Ic5vdh3Xt8pjGY1FsTZ,l0luG6eYDOsSbHmQTaPZj,title,ggeavOjMDpm3kITVN82hySo1])
	QzIuCodsAXU4lRJ630FfcGEmT8a9 = []
	for stream in BBamT8X6gqtA7RdEeUzy:
		Ic5vdh3Xt8pjGY1FsTZ,l0luG6eYDOsSbHmQTaPZj,title,ggeavOjMDpm3kITVN82hySo1 = stream
		eeYTX97loFiWvSpP1Bx5Dz2tN = title[:anb4QpyjlmgVwANP]
		if bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨาๆ๎ฮ࠭ห") in title: eeYTX97loFiWvSpP1Bx5Dz2tN += KKCrwPdOgGl(u"ࠩ࠮ࠫฬ")
		QzIuCodsAXU4lRJ630FfcGEmT8a9.append([stream,eeYTX97loFiWvSpP1Bx5Dz2tN,int(ggeavOjMDpm3kITVN82hySo1)])
	vAXpyPkBxctiRd7GV01hD2S3lL5E9r = pLwgjkuTs6CS
	rMtxNiWLzbUoAIDeKHCsnQuEk = uuKa8OdGswI1Ypj3FJBg6tkE0DyTVf(mI6ayKxBvjd4CRthL,QzIuCodsAXU4lRJ630FfcGEmT8a9)
	if rMtxNiWLzbUoAIDeKHCsnQuEk:
		I4cL6xG7ofrzURJnTqEeHu9,kkxAqMdNYnWyJgZrV1Evc,title,ggeavOjMDpm3kITVN82hySo1 = rMtxNiWLzbUoAIDeKHCsnQuEk[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		YYQLPSo3cZNBx9vmA85 = I4cL6xG7ofrzURJnTqEeHu9[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡹࡷࡲࠧอ")]
		if vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡧ࡯࡮ࡥࠩฮ") in title and YYQLPSo3cZNBx9vmA85!=N27XxPWvIzYQFcVwMJq: vAXpyPkBxctiRd7GV01hD2S3lL5E9r = NFGqKBLtvUZn1S3dau
		AQ9BX1uSeYPbHwgh0 = title
	else:
		AYyxjl1BKp86M9 = uuKa8OdGswI1Ypj3FJBg6tkE0DyTVf(mI6ayKxBvjd4CRthL,QzIuCodsAXU4lRJ630FfcGEmT8a9,B1YMtuvRAGNlJOkC46VyPKQE(u"࠴࠹࠵࠶࿻"))
		AYyxjl1BKp86M9,R5CGtcq72Ygije3,l90kFbrdcQupzKR1L = zip(*AYyxjl1BKp86M9)
		IkEYHKgmolNx1zj6sBFfAc9uWS3,Lj3YCbinFy,aJgKROwxj3 = [],[],nUaVQsoA6EXcK4Odht5wCge0J8Pib
		BBamT8X6gqtA7RdEeUzy = sorted(BBamT8X6gqtA7RdEeUzy, reverse=NFGqKBLtvUZn1S3dau, key=lambda key: float(key[anb4QpyjlmgVwANP]))
		E7M6K08mckWqPH5GXp,xrvATpctFg0Y2EJQj6dbkMqLHs1Z,qDuPOSGg9kx = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		try: E7M6K08mckWqPH5GXp = mUcBGLls4CubXQWkj1392fY[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫฯ")][KKCrwPdOgGl(u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭ะ")]
		except:
			try: E7M6K08mckWqPH5GXp = WC2Vy5BvLIKmA[I6Bfzysrvb8DONZ(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ั")][w9wfONXUP3(u"ࠨࡣࡸࡸ࡭ࡵࡲࠨา")]
			except: pass
		try: xrvATpctFg0Y2EJQj6dbkMqLHs1Z = mUcBGLls4CubXQWkj1392fY[nR0ok9zju84rFUQl1YC(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨำ")][hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭ิ")]
		except:
			try: xrvATpctFg0Y2EJQj6dbkMqLHs1Z = WC2Vy5BvLIKmA[djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪี")][W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨึ")]
			except: pass
		if E7M6K08mckWqPH5GXp and xrvATpctFg0Y2EJQj6dbkMqLHs1Z:
			aJgKROwxj3 += xD9WeoEAsX7
			title = qFghPAi5yz9Vf3NLwo0nuprl+awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡏࡘࡐࡈࡖ࠿ࠦࠠࠨื")+E7M6K08mckWqPH5GXp+so4Z8OUJ5E
			cX2SpPxGLmADTKl = drzqWFkSHD.SITESURLS[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨุ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ูࠫ")+xrvATpctFg0Y2EJQj6dbkMqLHs1Z
			IkEYHKgmolNx1zj6sBFfAc9uWS3.append(title)
			Lj3YCbinFy.append(cX2SpPxGLmADTKl)
			try: qDuPOSGg9kx = mUcBGLls4CubXQWkj1392fY[W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨฺ")][f9fOpCmLAEaW2Go(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭฻")][w9wfONXUP3(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ฼")][-xD9WeoEAsX7][GTmHXIZUSdxRhMnqQKkO(u"ࠬࡻࡲ࡭ࠩ฽")]
			except:
				try: qDuPOSGg9kx = WC2Vy5BvLIKmA[awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ฾")][pL73X0MYajJQG4n1qgD(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪ฿")][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬเ")][-xD9WeoEAsX7][I6Bfzysrvb8DONZ(u"ࠩࡸࡶࡱ࠭แ")]
				except: pass
		for Ic5vdh3Xt8pjGY1FsTZ,l0luG6eYDOsSbHmQTaPZj,title,ggeavOjMDpm3kITVN82hySo1 in AYyxjl1BKp86M9:
			IkEYHKgmolNx1zj6sBFfAc9uWS3.append(title) ; Lj3YCbinFy.append(W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫโ"))
		if TfWqrGd2etSYJzLb3cy: IkEYHKgmolNx1zj6sBFfAc9uWS3.append(Zb5cNeHWi6jP9SCYtUgR(u"ฺࠫ๎ัสู๋ࠢํะࠠๆฯาำฮ࠭ใ")) ; Lj3YCbinFy.append(I6Bfzysrvb8DONZ(u"ࠬࡳࡵࡹࡧࡧࠫไ"))
		if BBamT8X6gqtA7RdEeUzy: IkEYHKgmolNx1zj6sBFfAc9uWS3.append(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ี้ำฬࠤํ฻่หࠢส่๊ะ่โำࠪๅ")) ; Lj3YCbinFy.append(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡢ࡮࡯ࠫๆ"))
		if OgywhDGfxSFpY5MzmL9WuQtn3vX: IkEYHKgmolNx1zj6sBFfAc9uWS3.append(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨษัฮึࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭็")) ; Lj3YCbinFy.append(w9wfONXUP3(u"ࠩࡥ࡭ࡳࡪ่ࠧ"))
		if ijfU0DO5xmLnrZ4lNP6: IkEYHKgmolNx1zj6sBFfAc9uWS3.append(Zb5cNeHWi6jP9SCYtUgR(u"ูࠪํืษࠡสา์๋ࠦี้ฬ้ࠪ")) ; Lj3YCbinFy.append(lRKCWnNi0Edr984eI(u"ࠫࡻ࡯ࡤࡦࡱ๊ࠪ"))
		if oYx2hFGErZCT3g9BlqvKDckeRb: IkEYHKgmolNx1zj6sBFfAc9uWS3.append(kAz7WRYjrfGm(u"ࠬ฻่หࠢหำํ์ࠠึ๊ิอ๋ࠬ")) ; Lj3YCbinFy.append(w9wfONXUP3(u"࠭ࡡࡶࡦ࡬ࡳࠬ์"))
		while NFGqKBLtvUZn1S3dau:
			qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(ggZG182rVfaMiolKCdjE,IkEYHKgmolNx1zj6sBFfAc9uWS3)
			if qNmsBD1jJZVzcxi4onKuAOIC==-xD9WeoEAsX7: return pYeVwat64v(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬํ"),[],[]
			elif qNmsBD1jJZVzcxi4onKuAOIC==nUaVQsoA6EXcK4Odht5wCge0J8Pib and E7M6K08mckWqPH5GXp:
				cX2SpPxGLmADTKl = Lj3YCbinFy[qNmsBD1jJZVzcxi4onKuAOIC]
				rt4bc2XdTRA0EavBwISqFVox3HnOW = qv7XKecsSGz6rBTpt.argv[nUaVQsoA6EXcK4Odht5wCge0J8Pib]+CCWqR3dmtzw6xoIX41(u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠷࠴࠲ࠨࡱࡥࡲ࡫࠽ࠨ๎")+pmhHwIbkcrRJeyzuxPUSDGnqM92(E7M6K08mckWqPH5GXp)+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࠩࡹࡷࡲ࠽ࠨ๏")+cX2SpPxGLmADTKl
				if qDuPOSGg9kx: rt4bc2XdTRA0EavBwISqFVox3HnOW = rt4bc2XdTRA0EavBwISqFVox3HnOW+rAYDiWlzm9MCU6x0GnROua(u"ࠪࠪ࡮ࡳࡡࡨࡧࡀࠫ๐")+pmhHwIbkcrRJeyzuxPUSDGnqM92(qDuPOSGg9kx)
				mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ๑")+rt4bc2XdTRA0EavBwISqFVox3HnOW+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧ࠯ࠢ๒"))
				return djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ๓"),[],[]
			jwgM2qYVpdK5ly = Lj3YCbinFy[qNmsBD1jJZVzcxi4onKuAOIC]
			AQ9BX1uSeYPbHwgh0 = IkEYHKgmolNx1zj6sBFfAc9uWS3[qNmsBD1jJZVzcxi4onKuAOIC]
			if jwgM2qYVpdK5ly==kAz7WRYjrfGm(u"ࠧࡥࡣࡶ࡬ࠬ๔"):
				YYQLPSo3cZNBx9vmA85 = N27XxPWvIzYQFcVwMJq
				break
			elif jwgM2qYVpdK5ly in [rAYDiWlzm9MCU6x0GnROua(u"ࠨࡣࡸࡨ࡮ࡵࠧ๕"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๖"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪࡱࡺࡾࡥࡥࠩ๗")]:
				if jwgM2qYVpdK5ly==rAYDiWlzm9MCU6x0GnROua(u"ࠫࡲࡻࡸࡦࡦࠪ๘"): GjC4atkJLwlTpsI,TFvLpdRztD3HN4weqOkJBfiEGAWIlg = TfWqrGd2etSYJzLb3cy,EjryLdYk3w4fC5BAegpInXq7hS12o
				elif jwgM2qYVpdK5ly==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬࡼࡩࡥࡧࡲࠫ๙"): GjC4atkJLwlTpsI,TFvLpdRztD3HN4weqOkJBfiEGAWIlg = ijfU0DO5xmLnrZ4lNP6,m9OGJlTIkHEuD6SbUNjw1Xr
				elif jwgM2qYVpdK5ly==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡡࡶࡦ࡬ࡳࠬ๚"): GjC4atkJLwlTpsI,TFvLpdRztD3HN4weqOkJBfiEGAWIlg = oYx2hFGErZCT3g9BlqvKDckeRb,NNQHWXyno7VZ
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧศะอีࠥอไๆๆไࠤ࠭࠭๛")+str(len(GjC4atkJLwlTpsI))+nR0ok9zju84rFUQl1YC(u"ࠨ่่ࠢๆ࠯ࠧ๜"),GjC4atkJLwlTpsI)
				if qNmsBD1jJZVzcxi4onKuAOIC!=-xD9WeoEAsX7:
					YYQLPSo3cZNBx9vmA85 = TFvLpdRztD3HN4weqOkJBfiEGAWIlg[qNmsBD1jJZVzcxi4onKuAOIC][kAz7WRYjrfGm(u"ࠩࡸࡶࡱ࠭๝")]
					AQ9BX1uSeYPbHwgh0 = GjC4atkJLwlTpsI[qNmsBD1jJZVzcxi4onKuAOIC]
					break
			elif jwgM2qYVpdK5ly==ba49YvOK2Aw8Uhxt(u"ࠪࡦ࡮ࡴࡤࠨ๞"):
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(zWBnYSGIatjXVC(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯࠠࠩࠩ๟")+str(len(OgywhDGfxSFpY5MzmL9WuQtn3vX))+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࠦๅๅใࠬࠫ๠"),OgywhDGfxSFpY5MzmL9WuQtn3vX)
				if qNmsBD1jJZVzcxi4onKuAOIC!=-xD9WeoEAsX7:
					AQ9BX1uSeYPbHwgh0 = OgywhDGfxSFpY5MzmL9WuQtn3vX[qNmsBD1jJZVzcxi4onKuAOIC]
					I4cL6xG7ofrzURJnTqEeHu9 = WmIjs8yrVY7Tu1pxUP3d0l[qNmsBD1jJZVzcxi4onKuAOIC]
					qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(GTmHXIZUSdxRhMnqQKkO(u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎สࠡࠪࠪ๡")+str(len(LQDRBzOaSCF3mpe97oyqv8NVAl5T))+W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࠡ็็ๅ࠮࠭๢"),LQDRBzOaSCF3mpe97oyqv8NVAl5T)
					if qNmsBD1jJZVzcxi4onKuAOIC!=-xD9WeoEAsX7:
						AQ9BX1uSeYPbHwgh0 += YzlId3Fs6vpehcbLGj0UaO(u"ࠨࠢ࠮ࠤࠬ๣")+LQDRBzOaSCF3mpe97oyqv8NVAl5T[qNmsBD1jJZVzcxi4onKuAOIC]
						kkxAqMdNYnWyJgZrV1Evc = Fm5vMAikPNRCqhG[qNmsBD1jJZVzcxi4onKuAOIC]
						vAXpyPkBxctiRd7GV01hD2S3lL5E9r = NFGqKBLtvUZn1S3dau
						break
			elif jwgM2qYVpdK5ly==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡤࡰࡱ࠭๤"):
				CCM50EFBkm,otUd7XG8uZL3DqsKe2P9YwymNA,jI8O9SNrDm,t05GkZLU82jgSDRNn1cuV = list(zip(*BBamT8X6gqtA7RdEeUzy))
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪหำะัࠡษ็้้็ࠠࠩࠩ๥")+str(len(jI8O9SNrDm))+djapWhrveLJbgnViDftFNY05ylq1S(u"๋ࠫࠥไโࠫࠪ๦"),jI8O9SNrDm)
				if qNmsBD1jJZVzcxi4onKuAOIC!=-xD9WeoEAsX7:
					AQ9BX1uSeYPbHwgh0 = jI8O9SNrDm[qNmsBD1jJZVzcxi4onKuAOIC]
					I4cL6xG7ofrzURJnTqEeHu9 = CCM50EFBkm[qNmsBD1jJZVzcxi4onKuAOIC]
					if pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡨࡩ࡯ࡦࠪ๧") in jI8O9SNrDm[qNmsBD1jJZVzcxi4onKuAOIC] and I4cL6xG7ofrzURJnTqEeHu9[zWBnYSGIatjXVC(u"࠭ࡵࡳ࡮ࠪ๨")]!=N27XxPWvIzYQFcVwMJq:
						kkxAqMdNYnWyJgZrV1Evc = otUd7XG8uZL3DqsKe2P9YwymNA[qNmsBD1jJZVzcxi4onKuAOIC]
						vAXpyPkBxctiRd7GV01hD2S3lL5E9r = NFGqKBLtvUZn1S3dau
					else: YYQLPSo3cZNBx9vmA85 = I4cL6xG7ofrzURJnTqEeHu9[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡶࡴ࡯ࠫ๩")]
					break
			elif jwgM2qYVpdK5ly==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ๪"):
				CCM50EFBkm,otUd7XG8uZL3DqsKe2P9YwymNA,jI8O9SNrDm,t05GkZLU82jgSDRNn1cuV = list(zip(*AYyxjl1BKp86M9))
				I4cL6xG7ofrzURJnTqEeHu9 = CCM50EFBkm[qNmsBD1jJZVzcxi4onKuAOIC-aJgKROwxj3]
				if Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡥ࡭ࡳࡪࠧ๫") in jI8O9SNrDm[qNmsBD1jJZVzcxi4onKuAOIC-aJgKROwxj3] and I4cL6xG7ofrzURJnTqEeHu9[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡹࡷࡲࠧ๬")]!=N27XxPWvIzYQFcVwMJq:
					kkxAqMdNYnWyJgZrV1Evc = otUd7XG8uZL3DqsKe2P9YwymNA[qNmsBD1jJZVzcxi4onKuAOIC-aJgKROwxj3]
					vAXpyPkBxctiRd7GV01hD2S3lL5E9r = NFGqKBLtvUZn1S3dau
				else: YYQLPSo3cZNBx9vmA85 = I4cL6xG7ofrzURJnTqEeHu9[YzlId3Fs6vpehcbLGj0UaO(u"ࠫࡺࡸ࡬ࠨ๭")]
				AQ9BX1uSeYPbHwgh0 = jI8O9SNrDm[qNmsBD1jJZVzcxi4onKuAOIC-aJgKROwxj3]
				break
	if vAXpyPkBxctiRd7GV01hD2S3lL5E9r:
		EgAUQnSxLHwYz = I4cL6xG7ofrzURJnTqEeHu9[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡻࡲ࡭ࠩ๮")].replace(YzlId3Fs6vpehcbLGj0UaO(u"࠭ࠦࠨ๯"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࠧࡣࡰࡴࡀ࠭๰"))
		NNGPQl9cqX8buEYgZ3FtrJ7Ch6 = kkxAqMdNYnWyJgZrV1Evc[KKCrwPdOgGl(u"ࠨࡷࡵࡰࠬ๱")].replace(GTmHXIZUSdxRhMnqQKkO(u"ࠩࠩࠫ๲"),zWBnYSGIatjXVC(u"ࠪࠪࡦࡳࡰ࠼ࠩ๳"))
		IvwWeMbx2mO = I4cL6xG7ofrzURJnTqEeHu9[Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡨࡵࡤࡦࡥࡶࠫ๴")]
		if I4cL6xG7ofrzURJnTqEeHu9[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ๵")]==kAz7WRYjrfGm(u"࠭࡭࠴ࡷ࠻ࠫ๶") or kkxAqMdNYnWyJgZrV1Evc[djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ๷")]==f9fOpCmLAEaW2Go(u"ࠨ࡯࠶ࡹ࠽࠭๸"):
			uxwklto2piqDF = w9wfONXUP3(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱ࠸ࡻ࠸ࠨ๹")
			DhFR7siY9xUfkKq4AEVHZzySGvT21  = KKCrwPdOgGl(u"ࠪࠧࡊ࡞ࡔࡎ࠵ࡘࡠࡳࠐࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫ๺")#zQ4iTNfLo25mD70ZgJlO6V-X-kDY1ytPVL4v7IXH:c0haoBCblMIgiLHP65OAdWDu4Jjz9=orFCjltPd1BkxVf6aJq7HGg95YN,uOywlfszKUAe23dY-hhGxUyMREorjl6snqdVit1=slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠦࡦࡧࠢ๻"),oOdA3zcHNJLW7txQ9MPqnlmI=lRKCWnNi0Edr984eI(u"ࠧࡧࠢ๼"),aWr7dMcvFSN2sJjR89UnZuth1wfbl=sWUOlSrnCEkjf,aPNZOm1elzVFui7rQMc6y4BDpjobdh=sWUOlSrnCEkjf,LG0vPtMr5bp=ba49YvOK2Aw8Uhxt(u"ࠨࠥࡴࠤ๽")\BQTKX3mOnYVHcLz6Z4gx72(u"ࠧࠡࠧࠣࡥࡺࡪࡩࡰࡡࡸࡶࡱࠐࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫ๾")#zQ4iTNfLo25mD70ZgJlO6V-X-iuUx9WX36vRbg-DUXMTpSdK2NxHPBCew7tlIj4ZyrWG:aC91P6jIMEFvurRyT=djapWhrveLJbgnViDftFNY05ylq1S(u"࠵࿼"),orFCjltPd1BkxVf6aJq7HGg95YN=jBbkfIJSDqcVwl8irzy4Z3O(u"ࠣࡣࡤࠦ๿")\GhRIoYSW0nBu246Os9%GAiZHfqDPxwFu4W6SnXJKCo5\XbtLm48GBQwr2zesgToUj7IS1(u"ࠩࠣࠩࠥࡼࡩࡥࡧࡲࡣࡺࡸ࡬ࠋࠋࠌࠍࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࡹ࡭ࡩ࡫࡯ࡅࡷࡵࡥࡹ࡯࡯࡯ࠢࡀࠤ࡮ࡴࡴࠩࡸ࡬ࡨࡪࡵࡄࡊࡅࡗ࡟ࠬ຀")yMKER2TGzQu68IH7cbp(u"ࠪࡡ࠮ࠐࠉࠊࠋࡤࡹࡩ࡯࡯ࡅࡷࡵࡥࡹ࡯࡯࡯ࠢࡀࠤ࡮ࡴࡴࠩࡣࡸࡨ࡮ࡵࡄࡊࡅࡗ࡟ࠬກ")gPvFohOLa4M1idnw5(u"ࠫࡢ࠯ࠊࠊࠋࠌࡨࡺࡸࡡࡵ࡫ࡲࡲࠥࡃࠠࡴࡶࡵࠬࡲࡧࡸࠩࡸ࡬ࡨࡪࡵࡄࡶࡴࡤࡸ࡮ࡵ࡮࠭ࡣࡸࡨ࡮ࡵࡄࡶࡴࡤࡸ࡮ࡵ࡮ࠪࠫࠍࠍࠎࠏࡢࡪࡰࡧࡣ࡫࡯࡬ࡦࡰࡤࡱࡪࠦ࠽ࠡࠩຂ")sxIlJgyC6ERiNkAHedWwhS27.ScnZy7I3rUFjzxdlpovV2E4bBMsa1(u"ࠬࠐࠉࠊࠋࡥ࡭ࡳࡪࠠࠡ࠿ࠣࠫ຃")<itunPOq8Vgsh type=w9wfONXUP3(u"ࠨࡳࡵࡣࡷ࡭ࡨࠨຄ") kYRyZArvqdLIe0Xiw8=I6Bfzysrvb8DONZ(u"ࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥ຅") fDzYUv8B214WhmL=zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠣࡒࡗࠩࡸ࡙ࠢຆ")>\ea5dQIMqG9zoyXNCFRPrHb1fmDp(u"ࠩࠣࠩࠥࡪࡵࡳࡣࡷ࡭ࡴࡴࠊࠊࠋࠌࡦ࡮ࡴࡤࠡ࠭ࡀࠤࠬງ")  <wJ5kRgy8drKFU9AOm70Pq id=hWRvZOYtjme9QNnV41u0Mswb(u"ࠥࡺ࠰ࡧࠢຈ")>\HJTBYQ2P6lEKjgxRZ4dqGMWzD3AIkw(u"ࠫࠏࠏࠉࠊࡤ࡬ࡲࡩࠦࠫ࠾ࠢࠪຉ")    <mseqUykfVPwiZ7z WWRYInMo94kNFw=rAYDiWlzm9MCU6x0GnROua(u"ࠧࡼࡩࡥࡧࡲ࠳ࠪࡹࠢຊ") H6HeZjXpNDrwg=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨࠥࡴࠤ຋") llF6cdhI5XxvQsrOjLk7RNumaKYp=pL73X0MYajJQG4n1qgD(u"ࠢ࠲ࠤຌ") Tt71i9KnjPsrlFDw6=CCWqR3dmtzw6xoIX41(u"ࠣࡶࡵࡹࡪࠨຍ")>\kpTsxEK0oBnuMUyvSDd1w(u"ࠩࠣࠩࠥ࠮ࡶࡪࡦࡨࡳࡉࡏࡃࡕ࡝ࠪຎ")wWNl5KSqYR1L0fso2ODjEpui(u"ࠪࡡ࠱ࠦࡶࡪࡦࡨࡳࡉࡏࡃࡕ࡝ࠪຏ")sIXSPG98T1pqortxYyN(u"ࠫࡢ࠯ࠊࠊࠋࠌࡦ࡮ࡴࡤࠡ࠭ࡀࠤࠬຐ")      <RW91NY5ZlDt0ie2jT6 id=lRKCWnNi0Edr984eI(u"ࠧࡼ࠱ࠣຑ")>\KKlVjQutfOmSR8F9pNC3GELADd0w(u"࠭ࠊࠊࠋࠌࡦ࡮ࡴࡤࠡ࠭ࡀࠤࠬຒ")        <lHtczxrf3Io6pCO>%GAiZHfqDPxwFu4W6SnXJKCo5</lHtczxrf3Io6pCO>\UEK302e4bouRMgTqaf7(u"ࠧࠡࠧࠣࡺ࡮ࡪࡥࡰࡡࡸࡶࡱࠐࠉࠊࠋ࡬ࡪࠥ࠭ຓ")Q3unL0sHmGty(u"ࠨࠢ࡬ࡲࠥࡼࡩࡥࡧࡲࡈࡎࡉࡔࠡࡣࡱࡨࠥ࠭ດ")n1YDjQot64pN(u"ࠩࠣ࡭ࡳࠦࡶࡪࡦࡨࡳࡉࡏࡃࡕ࠼ࠍࠍࠎࠏࠉࡣ࡫ࡱࡨࠥ࠱࠽ࠡࠩຕ")        <veBYFTErsGzQC5X ct0w8AKClWNEO1Zb9Q3DpiVeqUJu=KKCrwPdOgGl(u"ࠥࠩࡸࠨຖ")>\uuHyX4Msv7Dq(u"ࠫࠥࠫࠠࡷ࡫ࡧࡩࡴࡊࡉࡄࡖ࡞ࠫທ")DDTYAkIzEoRUXv9(u"ࠬࡣࠊࠊࠋࠌࠍࡧ࡯࡮ࡥࠢ࠮ࡁࠥ࠭ຘ")          <XXVIA76mSlBaZcRGT0YpLD2nUo range=pL73X0MYajJQG4n1qgD(u"ࠨࠥࡴࠤນ")/>\uySVF8X2Nfx0CReAW9QiJ(u"ࠧࠡࠧࠣࡺ࡮ࡪࡥࡰࡆࡌࡇ࡙ࡡࠧບ")eeTAbsktxpGhfX6WQ(u"ࠨ࡟ࠍࠍࠎࠏࠉࡣ࡫ࡱࡨࠥ࠱࠽ࠡࠩປ")        </veBYFTErsGzQC5X>\NUt6j3w7iYT9aI(u"ࠩࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫຜ")        <veBYFTErsGzQC5X ct0w8AKClWNEO1Zb9Q3DpiVeqUJu=KKCrwPdOgGl(u"ࠥ࠴࠲࠶ࠢຝ")>\aMbA9fqNZOvz5uHFwgSkJ(u"ࠫࠏࠏࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫພ")          <XXVIA76mSlBaZcRGT0YpLD2nUo range=YzlId3Fs6vpehcbLGj0UaO(u"ࠧ࠶࠭࠱ࠤຟ")/>\UEK302e4bouRMgTqaf7(u"࠭ࠊࠊࠋࠌࠍࡧ࡯࡮ࡥࠢ࠮ࡁࠥ࠭ຠ")        </veBYFTErsGzQC5X>\BQTKX3mOnYVHcLz6Z4gx72(u"ࠧࠋࠋࠌࠍࡧ࡯࡮ࡥࠢ࠮ࡁࠥ࠭ມ")      </RW91NY5ZlDt0ie2jT6>\ZnBzKtvJaf(u"ࠨࠌࠌࠍࠎࡨࡩ࡯ࡦࠣ࠯ࡂࠦࠧຢ")    </mseqUykfVPwiZ7z>\lZkaiSmztuTxCdf(u"ࠩࠍࠍࠎࠏࡢࡪࡰࡧࠤ࠰ࡃࠠࠨຣ")    <mseqUykfVPwiZ7z WWRYInMo94kNFw=jBbkfIJSDqcVwl8irzy4Z3O(u"ࠥࡥࡺࡪࡩࡰ࠱ࠨࡷࠧ຤") H6HeZjXpNDrwg=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠦࠪࡹࠢລ") llF6cdhI5XxvQsrOjLk7RNumaKYp=pL73X0MYajJQG4n1qgD(u"ࠧ࠷ࠢ຦") Tt71i9KnjPsrlFDw6=zWBnYSGIatjXVC(u"ࠨࡴࡳࡷࡨࠦວ")>\ea5dQIMqG9zoyXNCFRPrHb1fmDp(u"ࠧࠡࠧࠣࠬࡦࡻࡤࡪࡱࡇࡍࡈ࡚࡛ࠨຨ")lkyhCD6YsIzgtmLGwTEANRWe09ua(u"ࠨ࡟࠯ࠤࡦࡻࡤࡪࡱࡇࡍࡈ࡚࡛ࠨຩ")jjZEQLhxtw4keaG9JBcrYC(u"ࠩࡠ࠭ࠏࠏࠉࠊࡤ࡬ࡲࡩࠦࠫ࠾ࠢࠪສ")      <RW91NY5ZlDt0ie2jT6 id=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠥࡥ࠶ࠨຫ")>\ck2rmPN0Xy1Qf5bpYHeFwAGxo8ZsVl(u"ࠫࠏࠏࠉࠊࡤ࡬ࡲࡩࠦࠫ࠾ࠢࠪຬ")        <lHtczxrf3Io6pCO>%GAiZHfqDPxwFu4W6SnXJKCo5</lHtczxrf3Io6pCO>\aMbA9fqNZOvz5uHFwgSkJ(u"ࠬࠦࠥࠡࡣࡸࡨ࡮ࡵ࡟ࡶࡴ࡯ࠎࠎࠏࠉࡪࡨࠣࠫອ")k52b8B0Ry1QqG4HfX(u"࠭ࠠࡪࡰࠣࡥࡺࡪࡩࡰࡆࡌࡇ࡙ࠦࡡ࡯ࡦࠣࠫຮ")rUWD60aI7iYVdjzfFHePBLq5Sw(u"ࠧࠡ࡫ࡱࠤࡦࡻࡤࡪࡱࡇࡍࡈ࡚࠺ࠋࠋࠌࠍࠎࡨࡩ࡯ࡦࠣ࠯ࡂࠦࠧຯ")        <veBYFTErsGzQC5X ct0w8AKClWNEO1Zb9Q3DpiVeqUJu=YzlId3Fs6vpehcbLGj0UaO(u"ࠣࠧࡶࠦະ")>\ea5dQIMqG9zoyXNCFRPrHb1fmDp(u"ࠩࠣࠩࠥࡧࡵࡥ࡫ࡲࡈࡎࡉࡔ࡜ࠩັ")UTV7ErIzB2XRj0SGho5a(u"ࠪࡡࠏࠏࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫາ")          <XXVIA76mSlBaZcRGT0YpLD2nUo range=awSUTRNMkdIW7sFEvnHD2mLY(u"ࠦࠪࡹࠢຳ")/>\OHNjTf2omvqY43Vp(u"ࠬࠦࠥࠡࡣࡸࡨ࡮ࡵࡄࡊࡅࡗ࡟ࠬິ")Kw2EJiFoxYfRMSVtn048Gq6D3(u"࠭࡝ࠋࠋࠌࠍࠎࡨࡩ࡯ࡦࠣ࠯ࡂࠦࠧີ")        </veBYFTErsGzQC5X>\ppWwsBcUMAe13Tai0L52l84Hf7(u"ࠧࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡣ࡫ࡱࡨࠥ࠱࠽ࠡࠩຶ")        <veBYFTErsGzQC5X ct0w8AKClWNEO1Zb9Q3DpiVeqUJu=f9fOpCmLAEaW2Go(u"ࠣ࠲࠰࠴ࠧື")>\uURSWMxs0d4Ho5yKmZcQtGAkfLwT7(u"ࠩࠍࠍࠎࠏࠉࡣ࡫ࡱࡨࠥ࠱࠽ຸࠡࠩ")          <XXVIA76mSlBaZcRGT0YpLD2nUo range=w9wfONXUP3(u"ࠥ࠴࠲࠶ູࠢ")/>\KKlVjQutfOmSR8F9pNC3GELADd0w(u"ࠫࠏࠏࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿຺ࠣࠫ")        </veBYFTErsGzQC5X>\NLurpZ4alg(u"ࠬࠐࠉࠊࠋࡥ࡭ࡳࡪࠠࠬ࠿ࠣࠫົ")      </RW91NY5ZlDt0ie2jT6>\ppWwsBcUMAe13Tai0L52l84Hf7(u"࠭ࠊࠊࠋࠌࡦ࡮ࡴࡤࠡ࠭ࡀࠤࠬຼ")    </mseqUykfVPwiZ7z>\NLurpZ4alg(u"ࠧࠋࠋࠌࠍࡧ࡯࡮ࡥࠢ࠮ࡁࠥ࠭ຽ")  </wJ5kRgy8drKFU9AOm70Pq>\GhRIoYSW0nBu246Os9</itunPOq8Vgsh>\NLurpZ4alg(u"ࠨࠌࠌࠍࠎࠐࠉࠊࠌࠌࠍࠏࠏࠉࡪࡨࠣࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠷࠺ࠋࠋࠌࠍ࡮࡬ࠠࡑ࡛࠶࠾ࠏࠏࠉࠊࠋ࡬ࡱࡵࡵࡲࡵࠢ࡫ࡸࡹࡶ࠮ࡴࡧࡵࡺࡪࡸࠠࡢࡵࠣ࡬ࡹࡺࡰࡠࡵࡨࡶࡻ࡫ࡲࠋࠋࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥ࡮ࡴࡵࡲ࠱ࡧࡱ࡯ࡥ࡯ࡶࠣࡥࡸࠦࡨࡵࡶࡳࡣࡨࡲࡩࡦࡰࡷࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡆࡦࡹࡥࡉࡖࡗࡔࡘ࡫ࡲࡷࡧࡵࠤࡦࡹࠠࡩࡶࡷࡴࡤࡹࡥࡳࡸࡨࡶࠏࠏࠉࠊࠋ࡬ࡱࡵࡵࡲࡵࠢ࡫ࡸࡹࡶ࡬ࡪࡤࠣࡥࡸࠦࡨࡵࡶࡳࡣࡨࡲࡩࡦࡰࡷࠎࠎࠏࠉࡤ࡮ࡤࡷࡸࠦࡈࡕࡖࡓࡣࡘࡋࡒࡗࡇࡕࠬ࡭ࡺࡴࡱࡡࡶࡩࡷࡼࡥࡳ࠰ࡋࡘ࡙ࡖࡓࡦࡴࡹࡩࡷ࠯࠺ࠋࠋࠌࠍࠎࡪࡥࡧࠢࡢࡣ࡮ࡴࡩࡵࡡࡢࠬࡸ࡫࡬ࡧ࠮ࠣ࡭ࡵࡃࠧ຾")hWRvZOYtjme9QNnV41u0Mswb(u"࠶࠸࠷࠯࠲࿽").I6Bfzysrvb8DONZ(u"࠶࠮࿾")1unScramble19_opy2_(u"ࠩ࠯ࠤࡵࡵࡲࡵ࠿࠸࠹࠵࠻࠵࠭ࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨࡁࠬ຿")XXACZ2L3ar.j2jInlTgWe0RkK1aDmCvSoxZidcsw(u"ࠪ࠰ࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠧເ")<>fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫ࠮ࡀࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱࡭ࡵࠦ࠽ࠡ࡫ࡳࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡱࡱࡵࡸࠥࡃࠠࡱࡱࡵࡸࠏࠏࠉࠊࠋࠌࡷࡪࡲࡦ࠯ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣࡁࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡧࡴࡴࡴࡦࡰࡷࠤࡂࠦࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋࠌࠍࠎ࡮ࡴࡵࡲࡢࡷࡪࡸࡶࡦࡴ࠱ࡌ࡙࡚ࡐࡔࡧࡵࡺࡪࡸ࠮ࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠࠪࡶࡩࡱ࡬ࠬࠡࠪࡶࡩࡱ࡬࠮ࡪࡲ࠯ࠤࡸ࡫࡬ࡧ࠰ࡳࡳࡷࡺࠩ࠭ࠢࡋࡘ࡙ࡖ࡟ࡉࡃࡑࡈࡑࡋࡒࠪࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳࡬ࡩ࡭ࡧࡸࡶࡱࠦ࠽ࠡࠩແ")jMQ6fCHhiFGobBRUI://{}:{}/{}B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬ࠴ࡦࡰࡴࡰࡥࡹ࠮ࡳࡦ࡮ࡩ࠲࡮ࡶࠬࠡࡵࡨࡰ࡫࠴ࡰࡰࡴࡷ࠰ࠥࡹࡥ࡭ࡨ࠱ࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡢࡷ࡭ࡻࡴࡥࡱࡺࡲࡤࡹࡴࡢࡴࡷࡩࡩࠦ࠽ࠡࡈࡤࡰࡸ࡫ࠊࠊࠋࠌࠍࡩ࡫ࡦࠡࡵࡷࡥࡷࡺࠨࡴࡧ࡯ࡪ࠮ࡀࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡸ࡭ࡸࡥࡢࡦࡶࠤࡂࠦࡴࡩࡴࡨࡥࡩ࡯࡮ࡨ࠰ࡗ࡬ࡷ࡫ࡡࡥࠪࡷࡥࡷ࡭ࡥࡵ࠿ࡶࡩࡱ࡬࠮ࡴࡧࡵࡺࡪ࠯ࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡸ࡭ࡸࡥࡢࡦࡶ࠲ࡩࡧࡥ࡮ࡱࡱࠤࡂࠦࡔࡳࡷࡨࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡵࡪࡵࡩࡦࡪࡳ࠯ࡵࡷࡥࡷࡺࠨࠪࠌࠌࠍࠎࠏࡤࡦࡨࠣࡷࡪࡸࡶࡦࠪࡶࡩࡱ࡬ࠩ࠻ࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡱࡥࡦࡲࡵࡹࡳࡴࡩ࡯ࡩࠣࡁࠥࡧࡶࡣࡱࡲࡰࡪࡧ࡮ࡴࡶࡵࡹࡪࠐࠉࠊࠋࠌࠍࡼ࡮ࡩ࡭ࡧࠣࡷࡪࡲࡦ࠯࡭ࡨࡩࡵࡸࡵ࡯ࡰ࡬ࡲ࡬ࡀࠠࡴࡧ࡯ࡪ࠳࡮ࡡ࡯ࡦ࡯ࡩࡤࡸࡥࡲࡷࡨࡷࡹ࠮ࠩࠋࠋࠌࠍࠎࡪࡥࡧࠢࡶࡸࡴࡶࠨࡴࡧ࡯ࡪ࠮ࡀࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱࡯ࡪ࡫ࡰࡳࡷࡱࡲ࡮ࡴࡧࠡ࠿ࠣࡥࡻࡨ࡯ࡰ࡮ࡨࡥࡳࡹࡦࡢ࡮ࡶࡩࠏࠏࠉࠊࠋࠌࠎࠎࠏࠉࠊࠋࡦࡳࡳࡴࠠ࠾ࠢ࡫ࡸࡹࡶ࡟ࡤ࡮࡬ࡩࡳࡺ࠮ࡉࡖࡗࡔࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠩࡵࡨࡰ࡫࠴ࡩࡱ࠮ࠣࡷࡪࡲࡦ࠯ࡲࡲࡶࡹ࠯ࠊࠊࠋࠌࠍࠎࡩ࡯࡯ࡰ࠱ࡶࡪࡷࡵࡦࡵࡷࠬࠧࡎࡅࡂࡆࠥ࠰ࠥࠨ࠯ࠣࠫࠍࠍࠎࠏࠉࠊࡥࡲࡲࡳ࠴ࡧࡦࡶࡵࡩࡸࡶ࡯࡯ࡵࡨࠬ࠮ࠐࠉࠊࠋࠌࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡳࡰࡥ࡮ࡩࡹ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡷࡪࡸࡶࡦࡴࡢࡧࡱࡵࡳࡦࠪࠬࠎࠎࠏࠉࡤ࡮ࡤࡷࡸࠦࡈࡕࡖࡓࡣࡍࡇࡎࡅࡎࡈࡖ࠭࡮ࡴࡵࡲࡢࡷࡪࡸࡶࡦࡴ࠱ࡆࡦࡹࡥࡉࡖࡗࡔࡗ࡫ࡱࡶࡧࡶࡸࡍࡧ࡮ࡥ࡮ࡨࡶ࠮ࡀࠊࠊࠋࠌࠍࡩ࡫ࡦࠡࡦࡲࡣࡌࡋࡔࠩࡵࡨࡰ࡫࠯࠺ࠋࠋࠌࠍࠎࠏࡩࡧࠢࡶࡩࡱ࡬࠮ࡱࡣࡷ࡬࠳ࡹࡴࡳ࡫ࡳࠬࠬໂ")/CCWqR3dmtzw6xoIX41(u"࠭ࠩࠡࠣࡀࠤࡸ࡫࡬ࡧ࠰ࡶࡩࡷࡼࡥࡳ࠰ࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠾ࠏࠏࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡶࡩࡳࡪ࡟ࡳࡧࡶࡴࡴࡴࡳࡦࠪ࠷࠴࠹࠯ࠊࠊࠋࠌࠍࠎࠏࡳࡦ࡮ࡩ࠲ࡪࡴࡤࡠࡪࡨࡥࡩ࡫ࡲࡴࠪࠬࠎࠎࠏࠉࠊࠋࠌࡶࡪࡺࡵࡳࡰࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡳࡦࡰࡧࡣࡷ࡫ࡳࡱࡱࡱࡷࡪ࠮࠲࠱࠲ࠬࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡴࡧࡱࡨࡤ࡮ࡥࡢࡦࡨࡶ࠭࠭ໃ")xuUOsczLGqXw-RtMDeBiK451nuSb9wAzWdP(u"ࠧ࠭ࠢࠪໄ")text/ql3maocKkHIr9SNfMC7iZ4J68F5v2G(u"ࠨࠫࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡥ࡯ࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࠬ࠮ࠐࠉࠊࠋࠌࠍࡨࡵ࡮ࡵࡧࡱࡸࠥࡃࠠࡴࡧ࡯ࡪ࠳ࡹࡥࡳࡸࡨࡶ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠊࠋࠌࠍ࡮࡬ࠠࡑ࡛࠶࠾ࠏࠏࠉࠊࠋࠌࠍ࡮࡬ࠠࡪࡵ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠬࡨࡵ࡮ࡵࡧࡱࡸ࠱ࠦࡳࡵࡴࠬ࠾ࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࠽ࠡࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡨࡲࡨࡵࡤࡦࠪࡤࡺࡺࡺࡦ࠹ࠫࠍࠍࠎࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍࠎࠏࡩࡧࠢ࡬ࡷ࡮ࡴࡳࡵࡣࡱࡧࡪ࠮ࡣࡰࡰࡷࡩࡳࡺࠬࠡࡷࡱ࡭ࡨࡵࡤࡦࠫ࠽ࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡃࠠࡤࡱࡱࡸࡪࡴࡴ࠯ࡧࡱࡧࡴࡪࡥࠩࡣࡹࡹࡹ࡬࠸ࠪࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡽࡦࡪ࡮ࡨ࠲ࡼࡸࡩࡵࡧࠫࡧࡴࡴࡴࡦࡰࡷ࠭ࠏࠏࠉࠊࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡷࡪࡲࡦ࠯ࡵࡨࡶࡻ࡫ࡲ࠯ࡡࡶ࡬ࡺࡺࡤࡰࡹࡱࡣࡸࡺࡡࡳࡶࡨࡨ࠿ࠐࠉࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡷࡪࡸࡶࡦࡴ࠱ࡣࡸ࡮ࡵࡵࡦࡲࡻࡳࡥࡳࡵࡣࡵࡸࡪࡪࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࠋࠌࠍࠎࠏࡤࡦࡨࠣࡨࡪࡲࡡࡺࡧࡧࡣࡸ࡮ࡵࡵࡦࡲࡻࡳ࠮ࠩ࠻ࠌࠌࠍࠎࠏࠉࠊࠋࡷ࡭ࡲ࡫࠮ࡴ࡮ࡨࡩࡵ࠮࠵ࠪࠢࠣࠎࠎࠏࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡶࡩࡷࡼࡥࡳ࠰ࡶࡸࡴࡶࠨࠪࠌࠌࠍࠎࠏࠉࠊࡶ࡫ࡶࡪࡧࡤࡪࡰࡪ࠲࡙࡮ࡲࡦࡣࡧࠬࡹࡧࡲࡨࡧࡷࡁࡩ࡫࡬ࡢࡻࡨࡨࡤࡹࡨࡶࡶࡧࡳࡼࡴࠬࠡࡦࡤࡩࡲࡵ࡮࠾ࡖࡵࡹࡪ࠯࠮ࡴࡶࡤࡶࡹ࠮ࠩࠋࠋࠌࠍࠎࡪࡥࡧࠢࡧࡳࡤࡎࡅࡂࡆࠫࡷࡪࡲࡦࠪ࠼ࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡳࡦࡰࡧࡣࡷ࡫ࡳࡱࡱࡱࡷࡪ࠮࠲࠱࠲ࠬࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡦࡰࡧࡣ࡭࡫ࡡࡥࡧࡵࡷ࠭࠯ࠊࠊࠋࠌ࡬࡭ࡺࡴࡱࡦࠣࡁࠥࡎࡔࡕࡒࡢࡗࡊࡘࡖࡆࡔࠫࡪ࡮ࡲࡥ࡯ࡣࡰࡩࡂࡨࡩ࡯ࡦࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠱ࡩ࡯࡯ࡶࡨࡲࡹࡃࡢࡪࡰࡧ࠭ࠏࠏࠉࠊࡪ࡫ࡸࡹࡶࡤ࠯ࡵࡷࡥࡷࡺࠨࠪࠌࠌࠍࠎ࡬ࡩ࡯ࡣ࡯࡙ࡗࡒࠠ࠾ࠢ࡫࡬ࡹࡺࡰࡥ࠰ࡩ࡭ࡱ࡫ࡵࡳ࡮ࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡪࡨࠣࡔ࡞࠹࠺ࠋࠋࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥ࡮ࡴࡵࡲ࠱ࡷࡪࡸࡶࡦࡴࠣࡥࡸࠦࡨࡵࡶࡳࡣࡸ࡫ࡲࡷࡧࡵࠎࠎࠏࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡪࡷࡸࡵ࠴ࡣ࡭࡫ࡨࡲࡹࠦࡡࡴࠢ࡫ࡸࡹࡶ࡟ࡤ࡮࡬ࡩࡳࡺࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡂࡢࡵࡨࡌ࡙࡚ࡐࡔࡧࡵࡺࡪࡸࠠࡢࡵࠣ࡬ࡹࡺࡰࡠࡵࡨࡶࡻ࡫ࡲࠋࠋࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥ࡮ࡴࡵࡲ࡯࡭ࡧࠦࡡࡴࠢ࡫ࡸࡹࡶ࡟ࡤ࡮࡬ࡩࡳࡺࠊࠊࠋࠌࡧࡱࡧࡳࡴࠢࡋࡘ࡙ࡖ࡟ࡔࡇࡕ࡚ࡊࡘࠨࡩࡶࡷࡴࡤࡹࡥࡳࡸࡨࡶ࠳ࡎࡔࡕࡒࡖࡩࡷࡼࡥࡳࠫ࠽ࠎࠎࠏࠉࠊࠌࠌࠍࠎࠏࡤࡦࡨࠣࡣࡤ࡯࡮ࡪࡶࡢࡣ࠭ࡹࡥ࡭ࡨ࠯࡭ࡵࡃࠧ໅")bHNRjGxm6S3wdtZ2qB(u"ࠩ࠯ࡴࡴࡸࡴ࠾࠷࠸࠴࠺࠻ࠬ࡮ࡲࡧࡁࠬໆ")<>Zb5cNeHWi6jP9SCYtUgR(u"ࠪ࠭࠿ࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰࡬ࡴࠥࡃࠠࡪࡲࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡰࡰࡴࡷࠤࡂࠦࡰࡰࡴࡷࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮࡮ࡲࡧࠤࡂࠦ࡭ࡱࡦࠍࠍࠎࠏࠉࠊࡪࡷࡸࡵࡥࡳࡦࡴࡹࡩࡷ࠴ࡈࡕࡖࡓࡗࡪࡸࡶࡦࡴ࠱ࡣࡤ࡯࡮ࡪࡶࡢࡣ࠭ࡹࡥ࡭ࡨ࠯ࠬࡸ࡫࡬ࡧ࠰࡬ࡴ࠱ࡹࡥ࡭ࡨ࠱ࡴࡴࡸࡴࠪ࠮ࡋࡘ࡙ࡖ࡟ࡉࡃࡑࡈࡑࡋࡒࠪࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡳࡰࡥࡷࡵࡰࠥࡃࠠࠨ໇")jMQ6fCHhiFGobBRUI://zWBnYSGIatjXVC(u"ࠫ࠰࡯ࡰ່ࠬࠩ"):jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬ࠱ࡳࡵࡴࠫࡴࡴࡸࡴ້ࠪ࠭ࠪ")/sxIlJgyC6ERiNkAHedWwhS27.Dzy9ht3fCSguXiG7coldVW(u"࠭ࠊࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࡨࡪ࡬ࠠࡴࡶࡤࡶࡹ࠮ࡳࡦ࡮ࡩ࠭࠿ࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡷ࡬ࡷ࡫ࡡࡥࡵࠣࡁࠥࡉࡵࡴࡶࡲࡱ࡙࡮ࡲࡦࡣࡧࠬࡦࡼࡢࡰࡱ࡯ࡩࡦࡴࡳࡧࡣ࡯ࡷࡪ࠯ࠊࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱ࡸ࡭ࡸࡥࡢࡦࡶ࠲ࡸࡺࡡࡳࡶࡢࡲࡪࡽ࡟ࡵࡪࡵࡩࡦࡪࡤࠩࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠵࠱ࡹࡥ࡭ࡨ࠱ࡷࡪࡸࡶࡦࠫࠍࠍࠎࠏࠉࡥࡧࡩࠤࡸ࡫ࡲࡷࡧࠫࡷࡪࡲࡦࠪ࠼ࠍࠍࠎࠏࠉࠊࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡱࡥࡦࡲࡵࡹࡳࡴࡩ࡯ࡩࠣࡁࠥࡧࡶࡣࡱࡲࡰࡪࡧ࡮ࡴࡶࡵࡹࡪࠐࠉࠊࠋࠌࠍࠏࠏࠉࠊࠋࠌࡻ࡭࡯࡬ࡦࠢࡶࡩࡱ࡬࠮࡬ࡧࡨࡴࡷࡻ࡮࡯࡫ࡱ࡫࠿ࠐࠉࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࠍࠎࡹࡥ࡭ࡨ࠱࡬ࡦࡴࡤ࡭ࡧࡢࡶࡪࡷࡵࡦࡵࡷࠬ࠮ࠐࠉࠊࠋࠌࠍࠏࠏࠉࠊࠋࡧࡩ࡫ࠦࡳࡵࡱࡳࠬࡸ࡫࡬ࡧࠫ࠽ࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮࡬ࡧࡨࡴࡷࡻ࡮࡯࡫ࡱ࡫ࠥࡃࠠࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡪࡦࡲࡳࡦࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡹࡥ࡯ࡦࡢࡨࡺࡳ࡭ࡺࡡ࡫ࡸࡹࡶࠨࠪࠋࠍࠍࠎࠏࠉࡥࡧࡩࠤࡸ࡮ࡵࡵࡦࡲࡻࡳ࠮ࡳࡦ࡮ࡩ࠭࠿ࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡶࡸࡴࡶࠨࠪࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡹ࡯ࡤ࡭ࡨࡸ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡶࡩࡷࡼࡥࡳࡡࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࠏࠉࠊࠌࠌࠍࠎࠏࠉࠋࠋࠌࠍࠎࡪࡥࡧࠢ࡯ࡳࡦࡪࠨࡴࡧ࡯ࡪ࠱ࡳࡰࡥࠫ࠽ࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮࡮ࡲࡧࠤࡂࠦ࡭ࡱࡦࠍࠍࠎࠏࠉࡥࡧࡩࠤࡸ࡫࡮ࡥࡡࡧࡹࡲࡳࡹࡠࡪࡷࡸࡵ࠮ࡳࡦ࡮ࡩ࠭࠿ࠐࠉࠊࠋࠌࠍࡨࡩ࡯࡯ࡰࠣࡁࠥ࡮ࡴࡵࡲࡢࡧࡱ࡯ࡥ࡯ࡶ࠱ࡌ࡙࡚ࡐࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠬࡸ࡫࡬ࡧ࠰࡬ࡴ࠰໊࠭"):djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࠬࡵࡷࡶ࠭ࡹࡥ࡭ࡨ࠱ࡴࡴࡸࡴࠪࠫࠍࠍࠎࠏࠉࠊࡥࡦࡳࡳࡴ࠮ࡳࡧࡴࡹࡪࡹࡴࠩࠤࡋࡉࡆࡊࠢ࠭ࠢࠥ࠳ࠧ࠯ࠊࠊࠋࠌࡧࡱࡧࡳࡴࠢࡋࡘ࡙ࡖ࡟ࡉࡃࡑࡈࡑࡋࡒࠩࡪࡷࡸࡵࡥࡳࡦࡴࡹࡩࡷ࠴ࡂࡢࡵࡨࡌ࡙࡚ࡐࡓࡧࡴࡹࡪࡹࡴࡉࡣࡱࡨࡱ࡫ࡲࠪ࠼ࠍࠍࠎࠏࠉࡥࡧࡩࠤࡩࡵ࡟ࡈࡇࡗࠬࡸ࡫࡬ࡧࠫ࠽ࠎࠎࠏࠉࠊࠋࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡳࡦࡰࡧࡣࡷ࡫ࡳࡱࡱࡱࡷࡪ࠮࠲࠱࠲ࠬࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡴࡧࡱࡨࡤ࡮ࡥࡢࡦࡨࡶ໋࠭࠭")xuUOsczLGqXw-mMRJ0u9ygAPCopB1dl(u"ࠨ࠮ࠪ໌")text/DFga9sAwtYqQkRbJcx0fmi2dPHTv8(u"ࠩࠬࠎࠎࠏࠉࠊࠋࡶࡩࡱ࡬࠮ࡦࡰࡧࡣ࡭࡫ࡡࡥࡧࡵࡷ࠭࠯ࠊࠊࠋࠌࠍࠎࠐࠉࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡺࡪ࡮ࡲࡥ࠯ࡹࡵ࡭ࡹ࡫ࠨࡴࡧ࡯ࡪ࠳ࡹࡥࡳࡸࡨࡶ࠳ࡳࡰࡥ࠰ࡨࡲࡨࡵࡤࡦࠪࡤࡺࡺࡺࡦ࠹ࠫࠬࠎࠎࠏࠉࠊࠋࡷ࡭ࡲ࡫࠮ࡴ࡮ࡨࡩࡵ࠮ࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠳ࠬࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡨ࠱ࡴࡦࡺࡨ࠾࠿ࠪໍ")/sxIlJgyC6ERiNkAHedWwhS27.a1aqXshPpVjUdADM9g45JtlLCrI7(u"ࠪ࠾ࠥࡹࡥ࡭ࡨ࠱ࡷࡪࡸࡶࡦࡴ࠱ࡷ࡭ࡻࡴࡥࡱࡺࡲ࠭࠯ࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࡵࡨࡰ࡫࠴ࡰࡢࡶ࡫ࡁࡂ࠭໎")/R301bJ5UiZ(u"ࠫ࠿ࠦࡳࡦ࡮ࡩ࠲ࡸ࡫ࡲࡷࡧࡵ࠲ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠮ࠩࠋࠋࠌࠍࠎࡪࡥࡧࠢࡧࡳࡤࡎࡅࡂࡆࠫࡷࡪࡲࡦࠪ࠼ࠍࠍࠎࠏࠉࠊࠌࠌࠍࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡹࡥ࡯ࡦࡢࡶࡪࡹࡰࡰࡰࡶࡩ࠭࠸࠰࠱ࠫࠍࠍࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡥ࡯ࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࠬ࠮ࠐࠉࠊࠋ࡫࡬ࡹࡺࡰࡥࠢࡀࠤࡍ࡚ࡔࡑࡡࡖࡉࡗ࡜ࡅࡓࠪࠪ໏")hWRvZOYtjme9QNnV41u0Mswb(u"࠶࠸࠷࠯࠲࿽").I6Bfzysrvb8DONZ(u"࠶࠮࿾")1unScramble27_opy2_(u"ࠬ࠲࠵࠶࠲࠸࠹࠱ࡳࡰࡥࠫࠍࠍࠎࠏࡨࡩࡶࡷࡴࡩ࠴ࡳࡵࡣࡵࡸ࠭࠯ࠊࠊࠋࠌࡪ࡮ࡴࡡ࡭ࡗࡕࡐࠥࡃࠠࡩࡪࡷࡸࡵࡪ࠮࡮ࡲࡧࡹࡷࡲࠊࠊࠋࠍࠍࠎࠐࠉࠊࠌࠌࠍࠏࠏࠉࠋࠋࠌࠎࠎࠏࠊࠊࡧ࡯ࡷࡪࡀࠠࡩࡪࡷࡸࡵࡪࠠ࠾ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴ࠏࠏࡩࡧࠢࡓ࡝࠸ࡀࠠࡴࡪ࡬ࡪࡹ࠷ࠬࡴࡪ࡬ࡪࡹ࠸ࠠ࠾ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱࠭໐")\jGDwx12KTPJ5F6BbNSqhV(u"࠭ࠊࠊࡧ࡯ࡷࡪࡀࠠࡴࡪ࡬ࡪࡹ࠷ࠬࡴࡪ࡬ࡪࡹ࠸ࠠ࠾ࠢࠪ໑")\UMJ5ZHInOvqjoxsWbRXLNQ(u"ࠧ࠭ࡣࡹࡷࡵࡧࡣࡦࡵ࠳ࠎࠎࡲ࡯ࡨࡗࡕࡐࠥࡃࠠࡴࡪ࡬ࡪࡹ࠷ࠫࠨ໒")H5rXn6dA1JWtMY2wby: [ KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨ࠭ࡤࡹࡩ࡯࡯ࡅࡋࡆࡘࡠ࠭໓")qyYXaPNmDQr(u"ࠩࡠ࠯ࠬ໔") ]\GhRIoYSW0nBu246Os9\wM8tpYDS1r\zP7YRdB1MnvtuHCfbgUjmk5eEDLx(u"ࠪ࠯ࡸ࡮ࡩࡧࡶ࠵࠯ࠬ໕")uRhgbMz2Lvn3Fto: [ ba49YvOK2Aw8Uhxt(u"ࠫ࠰ࡼࡩࡥࡧࡲࡈࡎࡉࡔ࡜ࠩ໖")cWjGkqCzBeFaufA7(u"ࠬࡣࠫࠨ໗") ]CCWqR3dmtzw6xoIX41(u"࠭ࠠࡪࡨࠣࡲࡪ࡫ࡤࡠࡹࡨࡦࡤࡹࡥࡳࡸࡨࡶࠥ࡫࡬ࡴࡧࠣࡷ࡭࡯ࡦࡵ࠳࠮ࠫ໘")A+vD7Cz5uamPpTq3NehLX2ronxEgOZIK: [ fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࠬࡨ࡬ࡲࡦࡲࡕࡓࡎ࠮ࠫ໙") ]jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭ࡧࡶ࡯ࡱࡷ࡭ࡨ࡫࡬ࡪࡰࡨࡷ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭໚")\cjg9ZNDM3ih0zLfRnK5bdEGUJT7 HIeXnt9aOv6yrD2s1MjVUko: [ pYeVwat64v(u"ࠩ࠮ࡰࡴ࡭ࡔࡪࡶ࡯ࡩ࠰࠭໛") ]   pL73X0MYajJQG4n1qgD(u"ࠪ࠯ࡱࡵࡧࡖࡔࡏ࠭ࠏࠏࡩࡧࠢࡱࡳࡹࠦࡦࡪࡰࡤࡰ࡚ࡘࡌ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪໜ")tDm3g0LSONUuKwrQf    : wXejCBZLE5bcq uADtR8M6Ti fnzQH29pP6MZ7dKa3uIG8ob1yi4v(u"ࠫ࠱ࡡ࡝࠭࡝ࡠࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠎࡸࡥࡵࡷࡵࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰࠭࡝࡯ࡳ࡬࡚ࡩࡵ࡮ࡨࡡ࠱ࡡ࡛ࡧ࡫ࡱࡥࡱ࡛ࡒࡍ࠮ࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠬࡩࡪࡷࡸࡵࡪ࡝࡞ࠌࠍࡨࡪ࡬ࠠࡗࡋࡇࡆࡔࡈࠨࡶࡴ࡯࠭࠿ࠐࠉࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠠࠨໝ")User-KbDfAd6W7Rhgv(u"ࠬࠦ࠺ࠡࡣࡹࡷࡵࡧࡣࡦࡵ࠳ࠤࢂࠐࠉࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱ࡧࡶࡴࡲࡤࡧࡪࡹ࠰࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱࠭ໞ")v3w7fbWE0x-kkig27fcBTPnp0vEy-1stunScramble26_opy2_(u"࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨໟ")file:pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠢࠩ࠰࠭ࡃ࠮ࠨ໠")(,AAB086Sqz9xc:djapWhrveLJbgnViDftFNY05ylq1S(u"ࠣࠪ࠱࠮ࡄ࠯ࠢ໡")|)\}MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡴࡧࡷࠬ࡮ࡺࡥ࡮ࡵࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡩࡵࡧࡰࡷ࠱ࠦࡲࡦࡸࡨࡶࡸ࡫࠽ࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡸࡷࡻࡥ࠭ࠢ࡮ࡩࡾࡃ࡬ࡢ࡯ࡥࡨࡦࠦ࡫ࡦࡻ࠽ࠤࡰ࡫ࡹ࡜ࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠶ࡢ࠯ࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢࡱࡳࡹࠦࡩࡵࡧࡰࡷ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧ໢")tDm3g0LSONUuKwrQf: wXejCBZLE5bcq VX6D3jQPfFiWYrLsBJIU WWXapQDHweYlFcy3fGRBUqJkLo6NbK(u"ࠪ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡤࡶ࡯ࡰࡽ࠱ࡲࡡࡣࡧ࡯ࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ໣")https:awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫ࠱࠭໤")jMQ6fCHhiFGobBRUI:B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬ࠯ࠊࠊࠋ࡬ࡪࠥ࠭໥").iDbzuBdr3gXOSf6xws8t(u"࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࡵࡧࡰࡴ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࡴࡦ࡯ࡳࠤࡂࠦࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡯࡭ࡳࡱࡌࡊࡕࡗࠤ࠰ࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡵࡧࡰࡴࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࡟ࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠰࡞࠿ࡀࠫ໦")-1unScramble15_opy2_(u"ࠧ࠻ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭໧")سيرفر خاصnR0ok9zju84rFUQl1YC(u"ࠨ࠭ࠪ໨")   kcjDKE2Se4O3m0(u"ࠩࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡹ࡫࡭ࡱ࠼ࠍࠍࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ໩")سيرفر خاصzWBnYSGIatjXVC(u"ࠪ࠯ࡦࡼࡳࡱࡣࡦࡩࡸ࠹ࠫࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭໪")سيرفر خاصslQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫ࠰࠭໫")   foPYAkDIZE   vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࠱࡬ࡢࡤࡨࡰࠏࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠎࡩ࡫ࡦࠡࡅࡋࡉࡈࡑ࡟ࡇࡑࡕࡣࡌࡋࡎࡆࡔࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࡤࡒࡉࡏࡍࡖࠬࡺࡸ࡬࠭ࡪࡷࡱࡱ࠯࠺ࠋࠋࠍࠍࡹ࡯ࡴ࡭ࡧࡶࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡹࡌࡊࡕࡗ࠰ࡹ࡯ࡴ࡭ࡧࡶࡐࡎ࡙ࡔ࠳࠮࡯࡭ࡳࡱࡳࡍࡋࡖࡘ࠷࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡ࠱ࡡ࡝ࠋࠋ࡬ࡪࠥࡴ࡯ࡵࠢ࡬ࡷ࡮ࡴࡳࡵࡣࡱࡧࡪ࠮ࡨࡵ࡯࡯࠰ࡸࡺࡲࠪ࠼ࠣ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡦࡨࡧࡴࡪࡥࠩࡣࡹࡹࡹ࡬࠸࠭ࠩ໬")QmXib4ZRpC2t3r9aNEhx(u"࠭ࠩࠋࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ໭")<SBLhUlZKEvPpqtnbouc7R8OJ9Iy H3uZe7I5PGREdnzONAYBFpoCich.*?q07HP31RJMczmpnKYW=ba49YvOK2Aw8Uhxt(u"ࠢࠩ࠰࠭ࡃ࠮ࠨ໮")CCWqR3dmtzw6xoIX41(u"ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡈࡇࡗࡣ࡛ࡏࡄࡆࡑࡉࡍࡑࡋࡔ࡚ࡒࡈࠬࡱ࡯࡮࡬࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡣࠩ࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢ࡞ࡡࠏࠏࡩࡧࠢࡱࡳࡹࠦ࡬ࡪࡰ࡮࠾ࠥࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ໯")<source q07HP31RJMczmpnKYW=bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠤࠫ࠲࠯ࡅࠩࠣ໰")kAz7WRYjrfGm(u"ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡰ࡮ࡴ࡫ࠡࡣࡱࡨࠥࡴ࡯ࡵࠢࡊࡉ࡙ࡥࡖࡊࡆࡈࡓࡋࡏࡌࡆࡖ࡜ࡔࡊ࠮࡬ࡪࡰ࡮࡟ࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠰࡞ࠫ࠽ࠤࡱ࡯࡮࡬ࠢࡀࠤࡠࡣࠊࠊࠌࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡰ࡮ࡴ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ໱")enfQtPaWRipK4kGCBU.*?TT86NAlpyMFgJX9v=rAYDiWlzm9MCU6x0GnROua(u"ࠦ࠭࠴ࠪࡀࠫࠥ໲")w9wfONXUP3(u"ࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡥࡳࡪࠠ࡯ࡱࡷࠤࡌࡋࡔࡠࡘࡌࡈࡊࡕࡆࡊࡎࡈࡘ࡞ࡖࡅࠩ࡮࡬ࡲࡰࡡࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠲ࡠ࠭࠿ࠦ࡬ࡪࡰ࡮ࠤࡂ࡛ࠦ࡞ࠌࠌ࡭࡫ࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯ࡠࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠱࡟ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷࡹࡰ࡭࡫ࡷࠬࠬ໳").djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࠬ࠲ࠫ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠷࡝ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࡵࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋ࡯࡭ࡳࡱࡳࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭໴")vuG0YAh2lLc7HKUjTs43MWQbeXEm: *(\[.*?\])awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭໵")c72bnzmgOfUp6SlAGvrDuZ4Hi vuG0YAh2lLc7HKUjTs43MWQbeXEm = (\{.*?\})rAYDiWlzm9MCU6x0GnROua(u"ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠠࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ໶")c72bnzmgOfUp6SlAGvrDuZ4Hi BBT7GRajtOuEM6JWy = (\{.*?\})pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ໷")c72bnzmgOfUp6SlAGvrDuZ4Hi lNm9013pvxcjkBtriyzOHIVZQA7YE = .*?\((\{.*?\})\)W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࠊࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡦࡱࡵࡣ࡬ࡵ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠶࡝ࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡶࡹࡧ࠮ࡲࠨ໸")([\{\,][\wM8tpYDS1r\GAiZHfqDPxwFu4W6SnXJKCo5\GhRIoYSW0nBu246Os9\B8LbOWFAScfqNEdzp]*)(\lQbG3ORfcMNz1C80E25tigTuVyeqL+[\wM8tpYDS1r\GAiZHfqDPxwFu4W6SnXJKCo5]*):pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫ࠱ࡸࠧ໹")\1unScramble9_opy2_(u"ࠧࡢ࠲ࠣ໺"):rAYDiWlzm9MCU6x0GnROua(u"࠭ࠬࡣ࡮ࡲࡧࡰࡹࠩࠋࠋࠌࠍࠏࠏࠉࠊࠌࠌࠍࠎࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡆࡘࡄࡐ࠭࠭໻")jILstaHdpyXB5(u"ࠧ࠭ࡤ࡯ࡳࡨࡱࡳࠪࠌࠌࠍࠎ࡯ࡦࠡ࡫ࡶ࡭ࡳࡹࡴࡢࡰࡦࡩ࠭ࡨ࡬ࡰࡥ࡮ࡷ࠱ࡪࡩࡤࡶࠬ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠ࡜ࡤ࡯ࡳࡨࡱࡳ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢࡥࡰࡴࡩ࡫ࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࠊࠋࡩ࡭ࡱ࡫࡟ࡦࡺࡷࡩࡳࡹࡩࡰࡰ࠯ࡰ࡮ࡴ࡫ࠡ࠿ࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠲ࡡࡷࡵࡳࡥࡨ࡫ࡳ࠱ࠌࠌࠍࠎࠏࡩࡧࠢ࡬ࡷ࡮ࡴࡳࡵࡣࡱࡧࡪ࠮ࡢ࡭ࡱࡦ࡯࠱ࡪࡩࡤࡶࠬ࠾ࠏࠏࠉࠊࠋࠌ࡭࡫ࠦࠠࠡࠩ໼")mMRJ0u9ygAPCopB1dl(u"ࠨࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮࠾ࠥ࡬ࡩ࡭ࡧࡢࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦ࠽ࠡࡵࡷࡶ࠭ࡨ࡬ࡰࡥ࡮࡟ࠬ໽")Orlof5PX3GWTBIpw1N6yxH7dZ8Uh(u"ࠩࡠ࠭ࠏࠏࠉࠊࠋࠌ࡭࡫ࠦࠠࠡࠩ໾")FD9qocYetXxNUGh(u"ࠪࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡀࠠ࡭࡫ࡱ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰࡡࠧ໿")gksBUie5cnxD6CmoEab1V04GpHuT(u"ࠫࡢࠐࠉࠊࠋࠌࠍࡪࡲࡩࡧࠢࠪༀ")Wyq4uxOJ0dftz5XknVELF8Mgab9wR(u"ࠬࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࡜ࠩ༁")iUgxGsBoQd(u"࠭࡝ࠋࠋࠌࠍࠎࠏࡥ࡭࡫ࡩࠤࠬ༂")uNaYQpwE09LC32WGdVxPISkh(u"ࠧࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡱ࡯࡮࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࡞ࠫ༃")trIbud56iz(u"ࠨ࡟ࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࠥࠦࠧ༄")BsHVGDoClYIj(u"ࠩࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࡴࡶࡵࠬࡧࡲ࡯ࡤ࡭࡞ࠫ༅")m0mkKRvLuZOA(u"ࠪࡡ࠮ࠐࠉࠊࠋࠌࠍࡪࡲࡩࡧࠢࠪ༆")yvErMPtiqXGWksKBSoAudQ47m(u"ࠫࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡶࡸࡷ࠮ࡢ࡭ࡱࡦ࡯ࡠ࠭༇")ooC57hqdPpRbj9W0IHsGeB(u"ࠬࡣࠩࠋࠋࠌࠍࠎࠏࡥ࡭࡫ࡩࠤࠬ༈").kAz7WRYjrfGm(u"࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡶࡴࡱ࡯ࡴࠩࠩ༉").w9wfONXUP3(u"ࠧ࠭ࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠵࠮ࡡࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠳ࡠࠎࠎࠏࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠋࠌࠍࡪࡲࡩࡧࠢ࡬ࡷ࡮ࡴࡳࡵࡣࡱࡧࡪ࠮ࡢ࡭ࡱࡦ࡯࠱ࡹࡴࡳࠫ࠽ࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡳࡱ࡮࡬ࡸ࠭࠭༊").fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨ࠮ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠶࠯࡛ࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠴ࡡࠏࠏࠉࠊࠋ࡬ࡪࠥࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠲࠼ࠣࠤࠥࠐࠉࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡶࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠫࡢࡸࡶࡴࡦࡩࡥࡴ࠴࠮ࡪ࡮ࡲࡥࡠࡧࡻࡸࡪࡴࡳࡪࡱࡱ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡴࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡼ࡬ࡴ࠭ࡲࡩ࡯࡭ࡶࡐࡎ࡙ࡔ࠭ࡶ࡬ࡸࡱ࡫ࡳࡍࡋࡖࡘ࠮࠯࠺ࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ་")\\/bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩ࠯ࠫ༌")/kAz7WRYjrfGm(u"ࠪ࠭ࠏࠏࠉࡴࡧࡵࡺࡪࡸࠠ࠾ࠢࡖࡉࡗ࡜ࡅࡓࠪࡸࡶࡱ࠲ࠧ།")HxhvM2F3CZE(u"ࠫ࠮ࠐࠉࠊࡷࡶࡩࡷࡧࡧࡦࡰࡷࠤࡂࠦࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕࠪࠬࠎࠎࠏࡩࡧࠢࠪ༎")W8qhwCy2tZ3ofmXQEcJ(u"ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡲࡩ࡯࡭ࠣࡁࠥࡹࡥࡳࡸࡨࡶ࠰ࡲࡩ࡯࡭ࠍࠍࠎ࡯ࡦࠡࠩ༏").yTpsrPDiKS9EIAul6Vo(u"࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪ༐")User-vlTxW3u6aZ0fH1EVUd4Dmhy(u"ࠧ࠻ࡷࡶࡩࡷࡧࡧࡦࡰࡷ࠰ࠬ༑")WW7ykdmuStF26YUnAa(u"ࡳࠩ࠽ࡷࡪࡸࡶࡦࡴࢀࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡹࡌࡊࡕࡗ࠷࠱ࡲࡩ࡯࡭ࡶࡐࡎ࡙ࡔ࠴ࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭࡮࡬ࡲࡰ࠲ࡨࡦࡣࡧࡩࡷࡹࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࡵࡏࡍࡘ࡚࠲ࠡ࠭ࡀࠤࡱ࡯࡮࡬ࡵࡏࡍࡘ࡚࠳ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡶࡐࡎ࡙ࡔ࠳ࠢ࠮ࡁࠥࡺࡩࡵ࡮ࡨࡷࡑࡏࡓࡕ࠵ࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭༒")|User-Lo5eCRgnmXxBfDHTSruYW=zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩ࠮ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹ࠱ࠧ༓")&aFzQfVISMHE8U5RGtnB3=zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪ࠯ࡸ࡫ࡲࡷࡧࡵࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡸࡒࡉࡔࡖ࠵࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡸࡒࡉࡔࡖ࠵࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡹࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡵࡏࡍࡘ࡚ࠠ࠾ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࡡ࡝࠭࡝ࡠࠎࠎ࡯ࡦࠡ࡮࡬ࡲࡰࡹࡌࡊࡕࡗ࠶࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡳࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡶࡐࡎ࡙ࡔࠡ࠿ࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠲ࡴࡪࡶ࡯ࡩࡸࡒࡉࡔࡖ࠵࠰ࡱ࡯࡮࡬ࡵࡏࡍࡘ࡚࠲ࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌ࡭࡫ࠦࠧ༔")<w9wfONXUP3(u"ࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥ࡮ࡴ࡮࡮ࠣࡥࡳࡪࠠ࡭ࡧࡱࠬ࡭ࡺ࡭࡭ࠫ࠿࠵࠵࠶ࠠࡢࡰࡧࠤ࡭ࡺ࡭࡭࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫ࠥࡃࠠࡩࡶࡰࡰࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠍࠍࠎࠏ࡭ࡴࡩࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ༕")<jjJLPm8MTZzal9pK IQY4Ktfm8lOj=zWBnYSGIatjXVC(u"ࠧ࠴ࠪࡀࠤ༖")>(bx4XfDFBU6cILvyT3eE.*?)<KKCrwPdOgGl(u"࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࠐࠉࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡰࡷ࡬ࡀࠠ࡮ࡵࡪࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ༗")<jjJLPm8MTZzal9pK class=kAz7WRYjrfGm(u"ࠢࡷࡲࡢࡺ࡮ࡪࡥࡰࡡࡶࡸࡺࡨ࡟ࡵࡺࡷ༘ࠦ")>(.*?)<MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠋࠋࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡲࡹࡧ࠻ࠢࡰࡷ࡬ࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ༙࠭࠭")<vvPQN7BTybc6a1WVqYUjhGD>(M3MH165mBKNejrQp.*?)<CCWqR3dmtzw6xoIX41(u"ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡲࡹࡧ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪࠤࡂࠦ࡭ࡴࡩ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠶࡝ࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡶࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡹࡌࡊࡕࡗࠎࠏࡪࡥࡧ࡛ࠢࡗࡍࡇࡒࡊࡐࡊࠬࡱ࡯࡮࡬࡫ࡧ࠰ࡺࡸ࡬ࠪ࠼ࠍࠍ࡬ࡲ࡯ࡣࡣ࡯ࠤ࡝࡙ࡈࡂࡔࡌࡒࡌࡸࡥࡴࡷ࡯ࡸࡸࠐࠉࡶࡴ࡯ࠤࡂࠦࡵࡳ࡮࠱ࡷࡹࡸࡩࡱࠪࠪ༚")/djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪ࠭ࠏࠏࡵ࡯ࡲࡤࡧࡰ࡫ࡤ࠭ࡲࡤࡽࡱࡵࡡࡥࠢࡀࠤࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠬࡼࡿࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩ༛")User-Zvcq6BxWVKntdN4pPDao9IiO7zyMsl(u"ࠫ࠿ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠩࠫࢀࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡡࠧ༜")zNaTA5kstXcMj2e3(u"ࡷ࠭࡝ࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࠫࡹࡷࡲࠬࠨ༝")cyAMK6CQuGvzeN2g3JH(u"࠭ࠩࠋࠋࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࡠ࠭༞")XD3FYGBZReAKhzvfsLPS-ZZDo8OytSkB2Tm7Fbh6Qa4EcNdvi(u"ࠧ࡞ࠢࡀࠤࠬ༟")OX5rvzfl1GLTgNePitB6,nnym7MsN2O9kbrp6cQ0Lq;QUSmCb1DwNxfVaLcvohzrs4j5=I6Bfzysrvb8DONZ(u"࠶࠮࿾")9unScramble9_opy2_(u"ࠨࠌࠌ࡬ࡪࡧࡤࡦࡴࡶ࡟ࠬ༠")FFbuwA1QGEW-aZMY2zNVUPAb0hQX7nyWgmrivkp6-BokIir3Sh87(u"ࠩࡠࠤࡂࠦࠧ༡")IldhksrmA1uv(u"ࠪࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫ༢")AVewh5NSF9dILnEMs8Cmt(u"ࠫ࠱ࡻࡲ࡭࠮ࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࡡࡷࡵࡳࡥࡨ࡫ࡳ࠱࠮ࡤࡺࡧࡵ࡯࡭ࡧࡤࡲࡸ࡬ࡡ࡭ࡵࡨ࠰ࠬ༣")v3w7fbWE0x-DbJ1zVBxe80YsSv5jrNTHpEh9PwGA-1stunScramble9_opy2_(u"ࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴࡵࡲࡢࡧࡴࡪࡥࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯ࡥࡧࠍࠍ࡮࡬ࠠ࡯ࡱࡷࠤ࡮ࡹࡩ࡯ࡵࡷࡥࡳࡩࡥࠩࡪࡷࡱࡱ࠲ࡳࡵࡴࠬ࠾ࠥ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡨࡪࡩ࡯ࡥࡧࠫࡥࡻࡻࡴࡧ࠺࠯ࠫ༤")BBCy8YVIqaWLTUFOXtpeJKo(u"࠭ࠩࠋࠋ࡬ࡪࠥ࠭༥")LHJCNwqmx6aI5BTyiP2oQnAlG0g4FM(YGNlawVTzKSgMJ5pP3xLHO8qtbn9,ooxHaLpetPMAFsS,EfzvSx2kKFcNseD5HCA7VMh9P31b,SnasPEKp3MYkN20u,mmEDKLSMv94fQ0es5GohF8Ck1Blt,CCWqR3dmtzw6xoIX41(u"ࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠍࠍࠎࡶࡡࡤ࡭ࡨࡨࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ༦")(eval\(LHJCNwqmx6aI5BTyiP2oQnAlG0g4FM\(YGNlawVTzKSgMJ5pP3xLHO8qtbn9,ooxHaLpetPMAFsS,EfzvSx2kKFcNseD5HCA7VMh9P31b,SnasPEKp3MYkN20u,mmEDKLSMv94fQ0es5GohF8Ck1Blt,[MMaUAOEyZw0W2cxui].*?)</eeMEUzWIRhXL7DlZ8y0wp>awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢࡳࡥࡨࡱࡥࡥ࠼ࠍࠍࠎࠏࡴࡳࡻ࠽ࠤࡺࡴࡰࡢࡥ࡮ࡩࡩࠦ࠽ࠡࡗࡑࡔࡆࡉࡋࡆࡔࠫࡴࡦࡩ࡫ࡦࡦ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠶࡝ࠪࠌࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡵ࡯ࡲࡤࡧࡰ࡫ࡤࠡ࠿ࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵ࠐࠉࡪࡨࠣࠫ༧")LHJCNwqmx6aI5BTyiP2oQnAlG0g4FM(ZZ2XTxk5VMsA8W,u,GhRIoYSW0nBu246Os9,wM8tpYDS1r,mmEDKLSMv94fQ0es5GohF8Ck1Blt,B8LbOWFAScfqNEdzp)zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࡱࡣࡦ࡯ࡪࡪࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ༨")(eval\(LHJCNwqmx6aI5BTyiP2oQnAlG0g4FM\(ZZ2XTxk5VMsA8W,u,GhRIoYSW0nBu246Os9,wM8tpYDS1r,mmEDKLSMv94fQ0es5GohF8Ck1Blt,B8LbOWFAScfqNEdzp.*?)</eeMEUzWIRhXL7DlZ8y0wp>djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡵࡧࡣ࡬ࡧࡧ࠾ࠏࠏࠉࠊࡶࡵࡽ࠿ࠦࡵ࡯ࡲࡤࡧࡰ࡫ࡤࠡ࠿࡙ࠣࡓࡎࡕࡏࡖࡈࡖ࠭ࡶࡡࡤ࡭ࡨࡨࡠࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠱࡟ࠬࠎࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡦࠣࡁࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠋࠋ࡫ࡸࡲࡲ࠲ࠡ࠿ࠣ࡬ࡹࡳ࡬ࠬࡷࡱࡴࡦࡩ࡫ࡦࡦࠍࠍ࡮࡬ࠠࠨ༩")rAYDiWlzm9MCU6x0GnROua(u"ࠦ࡮ࡪ࠲ࠣ༪")w9wfONXUP3(u"ࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠲ࠡࡱࡵࠤࠬ༫")KKCrwPdOgGl(u"ࠨࡩࡥࠤ༬")zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠴࠽ࠎࠎࠏࡩࡪࡦࡧࠤࡂࠦࡵࡳ࡮࠱ࡷࡵࡲࡩࡵࠪࠪ༭")/KKCrwPdOgGl(u"ࠨࠫ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠹࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ༮")zIb4L2ntdXGUcWfvB6gwMPVE-KKCrwPdOgGl(u"ࠩ࠯ࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ༯").gQfJtIpndvWLTP(u"ࠪ࠰ࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠩࠋࠋࠌ࡭࡫ࠦࠧ༰")vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠦ࡮ࡪ࠲ࠣ༱")vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠲࠻ࠢࡳࡥࡾࡲ࡯ࡢࡦࠣࡁࠥࢁࠧ༲")nReh7rvK5JIp6wfycVjzQuilT(u"࠭࠺ࡪ࡫ࡧࡨ࠱࠭༳")eI9LqUkcNWC58fQul3nX(u"ࠧ࠻ࠩ༴")mTer1fE2CsGdBWkR(u"ࠨࡿࠍࠍࠎ࡫࡬ࡪࡨ༵ࠣࠫ")slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠤ࡬ࡨࠧ༶")hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠤ࡮ࡴࠠࡩࡶࡰࡰ࠷ࡀࠠࡱࡣࡼࡰࡴࡧࡤࠡ࠿ࠣࡿ༷ࠬ")P9PGoM0S3JsFiW(u"ࠫ࠿࡯ࡩࡥࡦ࠯ࠫ༸")PPz9pTMlBvV(u"ࠬࡀ༹ࠧ")rRFbik2cj54(u"࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳ࠯ࡥࡲࡴࡾ࠮ࠩࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭༺")xuUOsczLGqXw-FOL3VXiDnmkBzjKwSMPEo(u"ࠧ࡞ࠢࡀࠤࠬ༻")vDlAn3dpRt/pJIMwPmtxzhH-www-mM7BSti2nwdpcDH-C6YF3ME0ProDy4A(u"ࠨࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫ༼")AkpD47H0NowXE9jSxgMqf(u"ࠩ࠯ࡹࡷࡲࠬࡱࡣࡼࡰࡴࡧࡤ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠴࠯ࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠲ࡡࡷࡤࡲࡳࡱ࡫ࡡ࡯ࡵࡩࡥࡱࡹࡥ࠭ࠩ༽")v3w7fbWE0x-DbJ1zVBxe80YsSv5jrNTHpEh9PwGA-2ndunScramble32_opy2_(u"ࠪ࠭ࠏࠏࠉࡩࡶࡰࡰ࠷ࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠵࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡅࡋࡉࡈࡑ࡟ࡇࡑࡕࡣࡌࡋࡎࡆࡔࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࡤࡒࡉࡏࡍࡖࠬࡺࡸ࡬࠭ࡪࡷࡱࡱ࠸ࠩࠋࠋࠍࠍࠏࠏࡘࡔࡊࡄࡖࡎࡔࡇࡳࡧࡶࡹࡱࡺࡳ࡜࡮࡬ࡲࡰ࡯ࡤ࡞ࠢࡀࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗ࠰࡭ࡺࡴࡱࡡࡦࡳࡩ࡫ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠏ࡞ࡓࡉࡃࡕࡍࡓࡍࡲࡦࡵࡸࡰࡹࡹ࡙ࠬࡕࡋࡅࡗࡏࡎࡈࡩࡵࡳࡺࡶࡳࡪࡦࡶࠤࡂࠦࡻࡾ࠮ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࠐࠊࡥࡧࡩࠤࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࡧ࡭ࡱࡥࡥࡱࠦࡘࡔࡊࡄࡖࡎࡔࡇࡳࡧࡶࡹࡱࡺࡳ࡚࠭ࡖࡌࡆࡘࡉࡏࡉࡪࡶࡴࡻࡰࡴ࡫ࡧࡷࠏࠏࡘࡔࡊࡄࡖࡎࡔࡇࡨࡴࡲࡹࡵࡹࡩࡥࡵࠣ࠯ࡂࠦ࠱࠱࠲ࠍࠍ࡬ࡸ࡯ࡶࡲ࡬ࡨࠥࡃ࡙ࠠࡕࡋࡅࡗࡏࡎࡈࡩࡵࡳࡺࡶࡳࡪࡦࡶࠎࠎࡲࡩ࡯࡭ࡶࠤࡂ࡛ࠦࠩࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠵࠱ࡻࡲ࡭ࠫࡠࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࠌࠌࠎࠎࠐࠉࠋࠋࠍࠍࠏࠏࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ༾")/zIb4L2ntdXGUcWfvB6gwMPVE-w9wfONXUP3(u"ࠫ࠱࠭༿")/w9wfONXUP3(u"ࠬ࠯ࠊࠊࡲࡤࡶࡹࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧཀ")^(.*?://.*?)/(.*?)/(.*?)$JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࠬࡶࡴ࡯࠶࠰࠭ཁ")/pL73X0MYajJQG4n1qgD(u"ࠧ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡴࡳࡻ࠽ࠤࡸࡺࡡࡳࡶ࠯ࡱ࡮ࡪࡤ࡭ࡧ࠯ࡩࡳࡪࠠ࠾ࠢࡳࡥࡷࡺࡳ࡜ࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠴ࡢࠐࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠡࠩག")tDm3g0LSONUuKwrQf: wXejCBZLE5bcq VX6D3jQPfFiWYrLsBJIU isJvaIMPCbf7d(u"ࠨ࠮࡞ࡡ࠱ࡡ࡝ࠋࠋࡨࡲࡩࠦ࠽ࠡࡧࡱࡨ࠳ࡹࡴࡳ࡫ࡳࠬࠬགྷ")/fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࠬࠎࠎࡨࡡࡥࡡࡰ࡭ࡩࡪ࡬ࡦࠢࡀࠤࡱ࡫࡮ࠩ࡯࡬ࡨࡩࡲࡥࠪ࠾ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠹ࠦ࡯ࡳࠢࡰ࡭ࡩࡪ࡬ࡦࠢ࡬ࡲࠥࡡࠧང")IDRruX67PCd4AJhUVto82LS(u"ࠪ࠰ࠬཅ")XI2olBHdUbgnOTeYKux80(u"ࠫ࠱࠭ཆ")ccxBkS7fJ3P8iYMsgEyZD0GQ6(u"ࠬ࠲ࠧཇ")pphXCF8sjHZ4MmEtin3VrJP1gTfy2(u"࠭ࠬࠨ཈")PrxolT30c1peK78tZiDyE(u"ࠧ࠭ࠩཉ")A1ONacr4tvulgdMVJTpL3UK6PD5nkx(u"ࡳࠩࡠࠎࠎࠐࠉࡪࡨࠣࡲࡴࡺࠠࡣࡣࡧࡣࡲ࡯ࡤࡥ࡮ࡨ࠾ࠥࡲࡩ࡯࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠳࠮ࡶࡸࡦࡸࡴࠬࠩཊ")/zIb4L2ntdXGUcWfvB6gwMPVE-pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࠮ࡱ࡮ࡪࡤ࡭ࡧ࠮ࠫཋ")/hWRvZOYtjme9QNnV41u0Mswb(u"ࠪ࠯ࡪࡴࡤ࡞ࠫࠍࠍ࡮࡬ࠠࡦࡰࡧ࠾ࠥࡲࡩ࡯࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠴࠮ࡶࡸࡦࡸࡴࠬࠩཌ")/awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫ࠰ࡳࡩࡥࡦ࡯ࡩ࠰࠭ཌྷ")/zIb4L2ntdXGUcWfvB6gwMPVE-Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠱ࡥ࡯ࡦࡠ࠭ࠏࠏࡩࡧࠢࠪཎ").vQW9q3r7OEwR5g6LYJMP2pa(u"࠭ࠠࡪࡰࠣࡱ࡮ࡪࡤ࡭ࡧ࠽ࠎࠎࠏ࡭ࡪࡦࡧࡰࡪ࠸ࠠ࠾ࠢࡰ࡭ࡩࡪ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫཏ").rndULo8mZWJlA9(u"ࠧ࠭ࡣࡹࡷࡵࡧࡣࡦࡵ࠳࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠷࠰ࡸࡺࡡࡳࡶ࠮ࠫཐ")/zWBnYSGIatjXVC(u"ࠨ࠭ࡰ࡭ࡩࡪ࡬ࡦ࠴࠮ࠫད")/kAz7WRYjrfGm(u"ࠩ࠮ࡩࡳࡪ࡝ࠪࠌࠌࠍࡱ࡯࡮࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟࠺࠲ࡳࡵࡣࡵࡸ࠰࠭དྷ")/zIb4L2ntdXGUcWfvB6gwMPVE-Zb5cNeHWi6jP9SCYtUgR(u"ࠪ࠯ࡲ࡯ࡤࡥ࡮ࡨ࠶࠰࠭ན")/vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࠰࡫࡮ࡥ࡟ࠬࠎࠎࠏࡩࡧࠢࡨࡲࡩࡀࠠ࡭࡫ࡱ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛࠷࠮ࡶࡸࡦࡸࡴࠬࠩཔ")/kAz7WRYjrfGm(u"ࠬ࠱࡭ࡪࡦࡧࡰࡪ࠸ࠫࠨཕ")/zIb4L2ntdXGUcWfvB6gwMPVE-JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࠫࡦࡰࡧࡡ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭བ").NxH4duzyFJsaZG3g6Obvn(u"ࠧࠡ࡫ࡱࠤࡪࡴࡤ࠻ࠌࠌࠍࡪࡴࡤ࠳ࠢࡀࠤࡪࡴࡤ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪབྷ").kAaiKCrHzexf4u(u"ࠨ࠮ࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠮ࠐࠉࠊ࡮࡬ࡲࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜࠹࠯ࡷࡹࡧࡲࡵ࠭ࠪམ")/zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩ࠮ࡱ࡮ࡪࡤ࡭ࡧ࠮ࠫཙ")/KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࠯ࡪࡴࡤ࠳࡟ࠬࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡢࡢࡦࡢࡱ࡮ࡪࡤ࡭ࡧ࠽ࠤࡱ࡯࡮࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟࠽࠲ࡳࡵࡣࡵࡸ࠰࠭ཚ")/zIb4L2ntdXGUcWfvB6gwMPVE-slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫ࠰ࡳࡩࡥࡦ࡯ࡩ࠰࠭ཛ")/ba49YvOK2Aw8Uhxt(u"ࠬ࠱ࡥ࡯ࡦ࠵ࡡ࠮ࠐࠉࠊ࡮࡬ࡲࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜࠻࠯ࡷࡹࡧࡲࡵ࠭ࠪཛྷ")/jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࠫ࡮࡫ࡧࡨࡱ࡫ࠫࠨཝ")/zIb4L2ntdXGUcWfvB6gwMPVE-ba49YvOK2Aw8Uhxt(u"ࠧࠬࡧࡱࡨ࠷ࡣࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡦࡦࡪ࡟࡮࡫ࡧࡨࡱ࡫࠺ࠡ࡮࡬ࡲࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜࠳࠳࠰ࡸࡺࡡࡳࡶ࠮ࠫཞ")/zWBnYSGIatjXVC(u"ࠨ࠭ࡰ࡭ࡩࡪ࡬ࡦ࠭ࠪཟ").Jz8yQqoRutEaL(u"ࠩࡠ࠭ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡣࡣࡧࡣࡲ࡯ࡤࡥ࡮ࡨ࠾ࠥࡲࡩ࡯࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠷࠱࠭ࡵࡷࡥࡷࡺࠫࠨའ")/zIb4L2ntdXGUcWfvB6gwMPVE-JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪ࠯ࡲ࡯ࡤࡥ࡮ࡨ࠯ࠬཡ").ecg3ARKO2yCFGx(u"ࠫࡢ࠯ࠊࠊࠋ࡬ࡪࠥ࡫࡮ࡥ࠼ࠣࡰ࡮ࡴ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞࠵࠷࠲ࡳࡵࡣࡵࡸ࠰࠭ར")/ba49YvOK2Aw8Uhxt(u"ࠬ࠱࡭ࡪࡦࡧࡰࡪ࠱ࠧལ")/vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࠫࡦࡰࡧ࠯ࠬཤ").ORmAVo09pXfS5yCtaQHzeb8rYZ(u"ࠧ࡞ࠫࠍࠍࠎ࡯ࡦࠡࡧࡱࡨ࠿ࠦ࡬ࡪࡰ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡ࠱࠴࠮ࡶࡸࡦࡸࡴࠬࠩཥ")/GTmHXIZUSdxRhMnqQKkO(u"ࠨ࠭ࡰ࡭ࡩࡪ࡬ࡦ࠭ࠪས")/zIb4L2ntdXGUcWfvB6gwMPVE-djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩ࠮ࡩࡳࡪࠫࠨཧ").sXHbVor7JwM5Z(u"ࠪࡡ࠮ࠐࠉࡪࡨࠣࡦࡦࡪ࡟࡮࡫ࡧࡨࡱ࡫ࠠࡢࡰࡧࠤࡪࡴࡤ࠻ࠌࠌࠍࡪࡴࡤࠡ࠿ࠣࡩࡳࡪ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩཨ")/zIb4L2ntdXGUcWfvB6gwMPVE-ba49YvOK2Aw8Uhxt(u"ࠫ࠱࠭ཀྵ")/awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬ࠯ࠊࠊࠋ࡯࡭ࡳࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝࠴࠸࠱ࡹࡴࡢࡴࡷ࠯ࠬཪ")/W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࠫࡦࡰࡧࡡ࠮ࠐࠉࠊ࡮࡬ࡲࡰࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜࠳࠸࠰ࡸࡺࡡࡳࡶ࠮ࠫཫ")/zIb4L2ntdXGUcWfvB6gwMPVE-jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࠬࡧࡱࡨࡢ࠯ࠊࠊࠋ࡬ࡪࠥ࠭ཬ").KFybA7oGNS4c83EdRaLtXn(u"ࠨࠢ࡬ࡲࠥ࡫࡮ࡥ࠼ࠍࠍࠎࠏࡥ࡯ࡦ࠵ࠤࡂࠦࡥ࡯ࡦ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ཭").N1rz3OAGPFWYJUK(u"ࠩ࠯ࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞࠵࠻࠲ࡳࡵࡣࡵࡸ࠰࠭཮")/pL73X0MYajJQG4n1qgD(u"ࠪ࠯ࡪࡴࡤ࠳࡟ࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛࠲࠹࠯ࡷࡹࡧࡲࡵ࠭ࠪ཯")/zIb4L2ntdXGUcWfvB6gwMPVE-pL73X0MYajJQG4n1qgD(u"ࠫ࠰࡫࡮ࡥ࠴ࡠ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝࠴࠼࠱ࡹࡴࡢࡴࡷ࠯ࠬ཰")/pL73X0MYajJQG4n1qgD(u"ࠬ࠱ࡥ࡯ࡦ࠮ཱࠫ").FFQRAWgHr4q6dCK9aYXT(u"࠭࡝ࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠷࠹࠭ࡵࡷࡥࡷࡺࠫࠨི")/zIb4L2ntdXGUcWfvB6gwMPVE-jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࠬࡧࡱࡨ࠰ཱི࠭").y5pOvtCB3QfNdmbEXUiszjoxIV(u"ࠨ࡟ࠬࠎࠎࡧ࡬࡭ࡶ࡫ࡶࡪࡧࡤࡴ࠹ࠣࡁࠥࡡ࡝ࠋࠋࠍࠍ࡫ࡵࡲࠡ࡫ࡧ࠶࠱ࡲࡩ࡯࡭࠵ࠤ࡮ࡴࠠ࡭࡫ࡱ࡯ࡸࡀࠊࠊࠋ࡛ࡗࡍࡇࡒࡊࡐࡊࡶࡪࡹࡵ࡭ࡶࡶ࡟࡬ࡸ࡯ࡶࡲ࡬ࡨ࠰࡯ࡤ࠳࡟ࠣࡁࠥࡡࡡࡷࡤࡲࡳࡱ࡫ࡡ࡯ࡵࡱࡳࡳ࡫ࠬࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡲࡴࡴࡥ࠭ࡣࡹࡦࡴࡵ࡬ࡦࡣࡱࡷࡳࡵ࡮ࡦ࠮ࡤࡺࡧࡵ࡯࡭ࡧࡤࡲࡸࡴ࡯࡯ࡧࡠࠎࠎࠏࡴࡩࡴࡨࡥࡩ࠽ࠠ࠾ࠢࡗࡌࡗࡋࡁࡅࡋࡑࡋࡤ࡚ࡈࡓࡇࡄࡈ࠭ࡪࡡࡦ࡯ࡲࡲࡂࡧࡶࡣࡱࡲࡰࡪࡧ࡮ࡴࡶࡵࡹࡪ࠲ࡴࡢࡴࡪࡩࡹࡃࡘࡔࡊࡄࡖࡎࡔࡇ࠭ࡣࡵ࡫ࡸࡃࠨࡨࡴࡲࡹࡵ࡯ࡤࠬ࡫ࡧ࠶࠱ࡲࡩ࡯࡭࠵࠭࠮ࠐࠉࠊࡣ࡯ࡰࡹ࡮ࡲࡦࡣࡧࡷ࠼࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡩࡴࡨࡥࡩ࠽ࠩࠋࠋࡧࡩ࡫ࠦࡐࡍࡃ࡜ࡍࡓࡍ࡟ࡂࡐࡇࡣࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡔࡆࡕࡗࡣࡋ࡛ࡎࡄࠪࠬ࠾ࠏࠏࠉࡥࡱࡱࡩࠥࡃࠠࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡪࡦࡲࡳࡦࠌࠌࠍ࡫ࡵࡲࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡱࠤ࡝࡙ࡈࡂࡔࡌࡒࡌࡸࡥࡴࡷ࡯ࡸࡸࡀࠊࠊࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡶࡪࡹࡵ࡭ࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡩࡵ࡮ࡦࠢࡀࠤࡦࡼࡢࡰࡱ࡯ࡩࡦࡴࡳࡵࡴࡸࡩࠏࠏࠉࡱ࡮ࡤࡽ࡮ࡴࡧࠡ࠿ࠣࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠡ࡫ࡩࠤࡌࡒࡏࡃࡃࡏࡗ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡵ࡮࡭ࡻࠣࡩࡱࡹࡥࠡࡣࡹࡦࡴࡵ࡬ࡦࡣࡱࡷࡹࡸࡵࡦࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡩࡵ࡮ࡦࠢࡲࡶࠥࡴ࡯ࡵࠢࡳࡰࡦࡿࡩ࡯ࡩࠍࠍࡘ࡚ࡁࡓࡖࡢࡘࡍࡘࡅࡂࡆࡖࡣ࡙ࡎࡅࡏࡡ࡚ࡅࡎ࡚࡟ࡇࡋࡑࡍࡘࡎ࡟ࡐࡔࡢࡘࡎࡓࡅࡐࡗࡗࠬࡦࡲ࡬ࡵࡪࡵࡩࡦࡪࡳ࠸࠮ࡷ࡭ࡲ࡫࡯ࡶࡶࡢࡪࡴࡸ࡟ࡹࡵ࡫ࡥࡷ࡯࡮ࡨࡡࡵࡩࡸࡵ࡬ࡷࡧࡵ࠰ࡽࡹࡨࡢࡴ࡬ࡲ࡬ࡥࡤࡦ࡮ࡤࡽࡤࡨࡥࡵࡹࡨࡩࡳࡥ࡬ࡪࡰ࡮ࡷ࠱ࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠲࠮ࡓࡐࡆ࡟ࡉࡏࡉࡢࡅࡓࡊ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡗࡉࡘ࡚࡟ࡇࡗࡑࡇ࠮ࠐࠉࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࡡ࡝࠭࡝ࡠࠎࠎࡧ࡬࡭ࡡࡦࡳࡩ࡫ࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡧࡱࡵࠤ࡮ࡪ࠲࠭࡮࡬ࡲࡰࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࡪࡸࡲࡰࡴ࠷࠰ࡹ࡯ࡴ࡭ࡧ࠷࠰ࡱ࡯࡮࡬࠶࠯ࡧࡴࡪࡥ࠵ࠢࡀࠤ࡝࡙ࡈࡂࡔࡌࡒࡌࡸࡥࡴࡷ࡯ࡸࡸࡡࡧࡳࡱࡸࡴ࡮ࡪࠫࡪࡦ࠵ࡡࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡤࡲࡩࠦ࡬ࡪࡰ࡮࠸࠿ࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡴࡪࡶ࡯ࡩ࠹࠲࡬ࡪࡰ࡮࠸ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡦࡴࡵࡳࡷࡳࡳࡨࠢࡤࡲࡩࠦࡥࡳࡴࡲࡶ࠹ࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨࠢࡀࠤࡪࡸࡲࡰࡴ࠷ࠎࠎࠏࡩࡧࠢࡦࡳࡩ࡫࠴࠻ࠢࡤࡰࡱࡥࡣࡰࡦࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡩ࡯ࡥࡧ࠷࠭ࠏࠏࡡ࡭࡮ࡢࡧࡴࡪࡥࡴࠢࡀࠤࡱ࡯ࡳࡵࠪࡶࡩࡹ࠮ࡡ࡭࡮ࡢࡧࡴࡪࡥࡴࠫࠬࠎࠎ࡯ࡦࠡࡰࡲࡸࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠠࡢࡰࡧࠤࡱ࡫࡮ࠩࡣ࡯ࡰࡤࡩ࡯ࡥࡧࡶ࠭ࡂࡃࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠳࠽ࠎࠎࠏࡨࡵࡶࡳࡣࡨࡵࡤࡦࠢࡀࠤࡦࡲ࡬ࡠࡥࡲࡨࡪࡹ࡛ࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠳ࡡࠏࠏࠉࡪࡨࠣ࡬ࡹࡺࡰࡠࡥࡲࡨࡪࠧ࠽࠳࠲࠳࠾ࠏࠏࠉࠊ࡫ࡩࠤ࡭ࡺࡴࡱࡡࡦࡳࡩ࡫࠼ࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠳࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠠ࠾ུࠢࠪ")uRhgbMz2Lvn3Fto GpwRnQ6q2o1fv0HbJTs/LLzkoiPsbBZ is not JJCG0ONsPnpoBa5gzvHq2leQc(u"ࠩࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡨࡶࡷࡵࡲ࡮ࡵࡪࠤࡂཱུࠦࠧ")nnktUfTP7B tDm3g0LSONUuKwrQf: KKCrwPdOgGl(u"ࠪ࠯ࡸࡺࡲࠩࡪࡷࡸࡵࡥࡣࡰࡦࡨ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥࡖ࡙࠴࠼ࠣ࡭ࡲࡶ࡯ࡳࡶࠣ࡬ࡹࡺࡰ࠯ࡥ࡯࡭ࡪࡴࡴࠡࡣࡶࠤ࡭ࡺࡴࡱࡡࡦࡰ࡮࡫࡮ࡵࠌࠌࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠥ࡯࡭ࡱࡱࡵࡸࠥ࡮ࡴࡵࡲ࡯࡭ࡧࠦࡡࡴࠢ࡫ࡸࡹࡶ࡟ࡤ࡮࡬ࡩࡳࡺࠊࠊࠋࠌࠍࡹࡸࡹ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪࠤ࠰ࡃࠠࠨྲྀ") ( djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫ࠰࡮ࡴࡵࡲࡢࡧࡱ࡯ࡥ࡯ࡶ࠱ࡶࡪࡹࡰࡰࡰࡶࡩࡸࡡࡨࡵࡶࡳࡣࡨࡵࡤࡦ࡟࠮ࠫཷ") )B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࠐࠉࠊࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࠎࠎࡺࡩ࡮ࡧ࠱ࡷࡱ࡫ࡥࡱࠪࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠶࠯ࠊࠊࠌࠌࠎࠎࡸࡥࡵࡷࡵࡲࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠏࠏࠊࠊࠌࠍࠎࠏࠐࠊࠋࠌࠍࡧࡱࡧࡳࡴࠢࡦࡶࡪࡧࡴࡦࡔࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࡉ࡯ࡡ࡭ࡱࡪࠬࡽࡨ࡭ࡤࡩࡸ࡭࠳࡝ࡩ࡯ࡦࡲࡻࡉ࡯ࡡ࡭ࡱࡪ࠭࠿ࠐࠊࠊࡦࡨࡪࠥࡥ࡟ࡪࡰ࡬ࡸࡤࡥࠨࡴࡧ࡯ࡪ࠱ࠦࠪࡢࡴࡪࡷ࠱ࠦࠪࠫ࡭ࡺࡥࡷ࡭ࡳࠪ࠼ࠍࠍࠎࡨࡧࡠ࡫ࡰࡥ࡬࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡣࡧࡨࡴࡴࡦࡰ࡮ࡧࡩࡷ࠲ࠠࠨླྀ")ZgQS7MvxXhaKuFLoGIy13iw(u"࠭ࠬࠡࠩཹ")KW1mopEkAi4xUlvwD3qzO9g(u"ེࠧ࠭ࠢࠪ")LwMH4bEmN3BkC8oZeP.WMOuebzcLUs(u"ࠨࠫࠍࠍࠎࡩࡨࡦࡥ࡮ࡣ࡮ࡳࡡࡨࡧࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡦࡪࡤࡰࡰࡩࡳࡱࡪࡥࡳ࠮ཻࠣࠫ")dcI6LXEa40ADo5hSQOW(u"ࠩ࠯ࠤོࠬ")ZZTHvorWI8Ak7CVRFgsXMLGNmS(u"ࠪ࠰ཽࠥ࠭")ZcN1jtWP4e0RywKukimTGS.V9GZB64J1f0xI758yjw3(u"ࠫ࠮ࠐࠉࠊࡤࡸࡸࡹࡵ࡮ࡠࡨࡲࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡪࡴࡲࡤࡦࡴ࠯ࠤࠬཾ")vjcXMDmW0luHkBt1ZTLGnrKyEqsg(u"ࠬ࠲ࠠࠨཿ")otcOlLi6KfTIXe2A(u"ྀ࠭ࠬࠡࠩ")uLJt58fQSm3NdU4ZRwj.UepE7TiolOAFImyJrzKH31nSR4(u"ࠧࠪࠌࠌࠍࡧࡻࡴࡵࡱࡱࡣࡳࡵࡦࡰࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡥࡩࡪ࡯࡯ࡨࡲࡰࡩ࡫ࡲཱྀ࠭ࠢࠪ")VpUORclHj5EXNd7qvJM1mTWDoQgPsn(u"ࠨ࠮ࠣࠫྂ")ws3qmV21uQo8S(u"ࠩ࠯ࠤࠬྃ")i8iY9DC5yd4pSgBPEmsvhn.Yc8J5biWAmlHNjRD3X(u"ࠪ࠭ࠏࠏࠉࡣࡷࡷࡸࡴࡴ࡟ࡣࡩࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡦࡪࡤࡰࡰࡩࡳࡱࡪࡥࡳ࠮྄ࠣࠫ")aINwj3QktHGL70erpoWVz2gZSi1OEq(u"ࠫ࠱ࠦࠧ྅")AlXfZJIBiF4cLa5DW8MtE6ne7(u"ࠬ࠲ࠠࠨ྆")egHhBzbQywuWL4c5xnl2T60EO.HXqsVDQ20R6(u"࠭ࠩࠋࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡦࡥࡳࡩࡥ࡭࡮ࡨࡨࠥࡃࠠࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡪࡦࡲࡳࡦࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࠦ࠽ࠡ࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡣࠠࠫࠢ࠼ࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡨ࡮࡫ࡣࡷࡷࡸࡴࡴࠠ࠾ࠢ࡞ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠶࡝ࠡࠬࠣ࠽ࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡩࡨ࡬ࡵࡷࡥࡹ࡫ࠠ࠾ࠢ࡞ࡥࡻࡨ࡯ࡰ࡮ࡨࡥࡳࡹࡦࡢ࡮ࡶࡩࡢࠦࠪࠡ࠻ࠍࠎࠎࠏࡷࡪࡰࡢࡼ࠱ࠦࡷࡪࡰࡢࡽ࠱ࠦࡷࡪࡰࡢࡻ࠱ࠦࡷࡪࡰࡢ࡬ࠥࡃࠠ࠳࠷࠳࠰ࠥࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠱࠮ࠣ࠻࠵࠶ࠬࠡ࠹࠹࠴ࠏࠏࠉࡸ࡫ࡱࡣࡲ࡯ࡤࠡ࠿ࠣࡻ࡮ࡴ࡟ࡹ࠭ࡺ࡭ࡳࡥࡷ࠰࠱ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠷ࠐࠉࠊ࡫ࡰ࡫ࡤࡾࠬࠡ࡫ࡰ࡫ࡤࡿࠬࠡ࡫ࡰ࡫ࡤࡽࠬࠡ࡫ࡰ࡫ࡤ࡮ࠠ࠾ࠢ࠶࠹࠺࠲ࠠ࠲࠴࠳࠰ࠥ࠻࠰࠱࠮ࠣ࠹࠵࠶ࠊࠊࠋ࡬ࡱ࡬ࡥ࡭ࡪࡦࠣࡁࠥ࡯࡭ࡨࡡࡻ࠯࡮ࡳࡧࡠࡹ࠲࠳ࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠲ࠋࠋࠌࡦࡺࡺࡴࡰࡰࡢ࡫ࡦࡶࠬࠡࡤࡸࡸࡹࡵ࡮ࡠࡻ࠯ࠤࡧࡻࡴࡵࡱࡱࡣࡼ࠲ࠠࡣࡷࡷࡸࡴࡴ࡟ࡩࠢࡀࠤ࠶࠶࠰࠭ࠢ࠹࠹࠺࠲ࠠ࠲࠷࠳࠰ࠥ࠻࠰ࠋࠋࠌࡦࡺࡺࡴࡰࡰ࠴ࡣࡽࠦ࠽ࠡࡹ࡬ࡲࡤࡳࡩࡥ࠯ࡥࡹࡹࡺ࡯࡯ࡡࡺ࠱ࡧࡻࡴࡵࡱࡱࡣ࡬ࡧࡰ࠰࠱ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠷ࠐࠉࠊࡤࡸࡸࡹࡵ࡮࠳ࡡࡻࠤࡂࠦࡷࡪࡰࡢࡱ࡮ࡪࠫࡣࡷࡷࡸࡴࡴ࡟ࡨࡣࡳ࠳࠴ࡧࡶ࡯ࡷࡰࡦࡪࡸࡳ࠳ࠌࠌࠍࡲࡹࡧ࠲ࡡࡻ࠰ࠥࡳࡳࡨ࠳ࡢࡽ࠱ࠦ࡭ࡴࡩ࠴ࡣࡼ࠲ࠠ࡮ࡵࡪ࠵ࡤ࡮ࠠ࠾ࠢ࠶࠹࠺࠲ࠠ࠴࠲࠯ࠤ࠺࠶࠰࠭ࠢ࠸࠴ࠏࠏࠉ࡮ࡵࡪ࠶ࡤࡾࠬࠡ࡯ࡶ࡫࠷ࡥࡹ࠭ࠢࡰࡷ࡬࠸࡟ࡸ࠮ࠣࡱࡸ࡭࠲ࡠࡪࠣࡁࠥ࠹࠵࠶࠮ࠣ࠻࠵࠲ࠠ࠶࠲࠳࠰ࠥ࠻࠰ࠋࠋࠌࠎࠎࠏࡺࡰࡱࡰࠤࡂࠦ࠰࠯࠻ࠍࠍࠎࡽࡩ࡯ࡡࡻ࠰ࠥࡽࡩ࡯ࡡࡼ࠰ࠥࡽࡩ࡯ࡡࡺ࠰ࠥࡽࡩ࡯ࡡ࡫ࠤࡂࠦࡩ࡯ࡶࠫࡻ࡮ࡴ࡟ࡹࠬࡽࡳࡴࡳࠩ࠭ࠢ࡬ࡲࡹ࠮ࡷࡪࡰࡢࡽ࠯ࢀ࡯ࡰ࡯ࠬ࠰ࠥ࡯࡮ࡵࠪࡺ࡭ࡳࡥࡷࠫࡼࡲࡳࡲ࠯ࠬࠡ࡫ࡱࡸ࠭ࡽࡩ࡯ࡡ࡫࠮ࡿࡵ࡯࡮ࠫࠍࠍࠎ࡯࡭ࡨࡡࡻ࠰ࠥ࡯࡭ࡨࡡࡼ࠰ࠥ࡯࡭ࡨࡡࡺ࠰ࠥ࡯࡭ࡨࡡ࡫ࠤࡂࠦࡩ࡯ࡶࠫ࡭ࡲ࡭࡟ࡹࠬࡽࡳࡴࡳࠩ࠭ࠢ࡬ࡲࡹ࠮ࡩ࡮ࡩࡢࡽ࠯ࢀ࡯ࡰ࡯ࠬ࠰ࠥ࡯࡮ࡵࠪ࡬ࡱ࡬ࡥࡷࠫࡼࡲࡳࡲ࠯ࠬࠡ࡫ࡱࡸ࠭࡯࡭ࡨࡡ࡫࠮ࡿࡵ࡯࡮ࠫࠍࠍࠎࡨࡵࡵࡶࡲࡲ࠶ࡥࡸ࠭ࠢࡥࡹࡹࡺ࡯࡯࠳ࡢࡽ࠱ࠦࡢࡶࡶࡷࡳࡳ࠷࡟ࡸ࠮ࠣࡦࡺࡺࡴࡰࡰ࠴ࡣ࡭ࠦ࠽ࠡ࡫ࡱࡸ࠭ࡨࡵࡵࡶࡲࡲ࠶ࡥࡸࠫࡼࡲࡳࡲ࠯ࠬࠡ࡫ࡱࡸ࠭ࡨࡵࡵࡶࡲࡲࡤࡿࠪࡻࡱࡲࡱ࠮࠲ࠠࡪࡰࡷࠬࡧࡻࡴࡵࡱࡱࡣࡼ࠰ࡺࡰࡱࡰ࠭࠱ࠦࡩ࡯ࡶࠫࡦࡺࡺࡴࡰࡰࡢ࡬࠯ࢀ࡯ࡰ࡯ࠬࠎࠎࠏࡢࡶࡶࡷࡳࡳ࠸࡟ࡹ࠮ࠣࡦࡺࡺࡴࡰࡰ࠵ࡣࡾ࠲ࠠࡣࡷࡷࡸࡴࡴ࠲ࡠࡹ࠯ࠤࡧࡻࡴࡵࡱࡱ࠶ࡤ࡮ࠠ࠾ࠢ࡬ࡲࡹ࠮ࡢࡶࡶࡷࡳࡳ࠸࡟ࡹࠬࡽࡳࡴࡳࠩ࠭ࠢ࡬ࡲࡹ࠮ࡢࡶࡶࡷࡳࡳࡥࡹࠫࡼࡲࡳࡲ࠯ࠬࠡ࡫ࡱࡸ࠭ࡨࡵࡵࡶࡲࡲࡤࡽࠪࡻࡱࡲࡱ࠮࠲ࠠࡪࡰࡷࠬࡧࡻࡴࡵࡱࡱࡣ࡭࠰ࡺࡰࡱࡰ࠭ࠏࠏࠉ࡮ࡵࡪ࠵ࡤࡾࠬࠡ࡯ࡶ࡫࠶ࡥࡹ࠭ࠢࡰࡷ࡬࠷࡟ࡸ࠮ࠣࡱࡸ࡭࠱ࡠࡪࠣࡁࠥ࡯࡮ࡵࠪࡰࡷ࡬࠷࡟ࡹࠬࡽࡳࡴࡳࠩ࠭ࠢ࡬ࡲࡹ࠮࡭ࡴࡩ࠴ࡣࡾ࠰ࡺࡰࡱࡰ࠭࠱ࠦࡩ࡯ࡶࠫࡱࡸ࡭࠱ࡠࡹ࠭ࡾࡴࡵ࡭ࠪ࠮ࠣ࡭ࡳࡺࠨ࡮ࡵࡪ࠵ࡤ࡮ࠪࡻࡱࡲࡱ࠮ࠐࠉࠊ࡯ࡶ࡫࠷ࡥࡸ࠭ࠢࡰࡷ࡬࠸࡟ࡺ࠮ࠣࡱࡸ࡭࠲ࡠࡹ࠯ࠤࡲࡹࡧ࠳ࡡ࡫ࠤࡂࠦࡩ࡯ࡶࠫࡱࡸ࡭࠲ࡠࡺ࠭ࡾࡴࡵ࡭ࠪ࠮ࠣ࡭ࡳࡺࠨ࡮ࡵࡪ࠶ࡤࡿࠪࡻࡱࡲࡱ࠮࠲ࠠࡪࡰࡷࠬࡲࡹࡧ࠳ࡡࡺ࠮ࡿࡵ࡯࡮ࠫ࠯ࠤ࡮ࡴࡴࠩ࡯ࡶ࡫࠷ࡥࡨࠫࡼࡲࡳࡲ࠯ࠊࠋࠋࠌࡧࡹࡸ࡬ࡃࡣࡦ࡯࡬ࡵࡵ࡯ࡦࠣࡁࠥࡾࡢ࡮ࡥࡪࡹ࡮࠴ࡃࡰࡰࡷࡶࡴࡲࡉ࡮ࡣࡪࡩ࠭ࡽࡩ࡯ࡡࡻ࠰ࠥࡽࡩ࡯ࡡࡼ࠰ࠥࡽࡩ࡯ࡡࡺ࠰ࠥࡽࡩ࡯ࡡ࡫࠰ࠥࡨࡧࡠ࡫ࡰࡥ࡬࡫ࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡣࡧࡨࡈࡵ࡮ࡵࡴࡲࡰ࠭ࡩࡴࡳ࡮ࡅࡥࡨࡱࡧࡰࡷࡱࡨ࠮ࠐࠉࠊࡵࡨࡰ࡫࠴ࡩࡵࡧࡵࡥࡹ࡯࡯࡯ࠢࡀࠤࡰࡽࡡࡳࡩࡶ࠲࡬࡫ࡴࠩࠩ྇")dmAvQiwF072KLr(u"ࠧࠪࠌࠌࠍࡲࡹࡧ࠲ࠢࡀࠤࡦࡼࡣࡰ࡮ࡲࡶࡸࡿࡥ࡭࡮ࡲࡻ࠰࠭ྈ")فحص أنا إنسان ولست روبوت         Zb5cNeHWi6jP9SCYtUgR(u"ࠨ࠭ࠪྉ")المحاولة رقم  slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩ࠮ࡷࡹࡸࠨࡴࡧ࡯ࡪ࠳࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࠪ࠭ࡤࡺࡨࡵ࡬ࡰࡴࡶࡩࡳࡪࠊࠊࠋࡶࡩࡱ࡬࠮ࡴࡶࡵࡅࡨࡺࡩࡰࡰࡌࡲ࡫ࡵࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡇࡴࡴࡴࡳࡱ࡯ࡐࡦࡨࡥ࡭ࠪࡰࡷ࡬࠷࡟ࡹ࠮ࠣࡱࡸ࡭࠱ࡠࡻ࠯ࠤࡲࡹࡧ࠲ࡡࡺ࠰ࠥࡳࡳࡨ࠳ࡢ࡬࠱ࠦ࡭ࡴࡩ࠴࠰ࠥ࠭ྊ")giJGQRb3Mw0KO(u"ࠪ࠭ࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡧࡤࡥࡅࡲࡲࡹࡸ࡯࡭ࠪࡶࡩࡱ࡬࠮ࡴࡶࡵࡅࡨࡺࡩࡰࡰࡌࡲ࡫ࡵࠩࠋࠋࠌ࡭ࡲ࡭ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡇࡴࡴࡴࡳࡱ࡯ࡍࡲࡧࡧࡦࠪ࡬ࡱ࡬ࡥࡸ࠭ࠢ࡬ࡱ࡬ࡥࡹ࠭ࠢ࡬ࡱ࡬ࡥࡷ࠭ࠢ࡬ࡱ࡬ࡥࡨ࠭ࠢ࡮ࡻࡦࡸࡧࡴ࠰ࡪࡩࡹ࠮ࠧྋ")fnjclpFwDAQbJUsE5tVSyP86vMx(u"ࠫ࠮࠯ࠊࠊࠋࡶࡩࡱ࡬࠮ࡢࡦࡧࡇࡴࡴࡴࡳࡱ࡯ࠬ࡮ࡳࡧࠪࠌࠌࠍࡲࡹࡧ࠳ࠢࡀࠤࡦࡼࡣࡰ࡮ࡲࡶࡸࡿࡥ࡭࡮ࡲࡻ࠰ࡱࡷࡢࡴࡪࡷ࠳࡭ࡥࡵࠪࠪྌ")YKn3FgMSIZQPXD6(u"ࠬ࠯ࠫࡢࡸࡦࡳࡱࡵࡲࡴࡧࡱࡨࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡹࡴࡳࡃࡦࡸ࡮ࡵ࡮ࡊࡰࡩࡳࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡅࡲࡲࡹࡸ࡯࡭ࡎࡤࡦࡪࡲࠨ࡮ࡵࡪ࠶ࡤࡾࠬࠡ࡯ࡶ࡫࠷ࡥࡹ࠭ࠢࡰࡷ࡬࠸࡟ࡸ࠮ࠣࡱࡸ࡭࠲ࡠࡪ࠯ࠤࡲࡹࡧ࠳࠮ࠣࠫྍ")P8mbJFviNt9Z(u"࠭ࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡣࡧࡨࡈࡵ࡮ࡵࡴࡲࡰ࠭ࡹࡥ࡭ࡨ࠱ࡷࡹࡸࡁࡤࡶ࡬ࡳࡳࡏ࡮ࡧࡱࠬࠎࠎࠏࡴࡦࡺࡷࠤࡂࠦࡡࡷࡥࡲࡰࡴࡸࡳࡺࡧ࡯ࡰࡴࡽࠫࠨྎ")خروجY7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࠬࡣࡹࡧࡴࡲ࡯ࡳࡵࡨࡲࡩࠐࠉࠊࡵࡨࡰ࡫࠴ࡣࡢࡰࡦࡩࡱࡨࡵࡵࡶࡲࡲࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡅࡲࡲࡹࡸ࡯࡭ࡄࡸࡸࡹࡵ࡮ࠩࡤࡸࡸࡹࡵ࡮࠲ࡡࡻ࠰ࠥࡨࡵࡵࡶࡲࡲ࠶ࡥࡹ࠭ࠢࡥࡹࡹࡺ࡯࡯࠳ࡢࡻ࠱ࠦࡢࡶࡶࡷࡳࡳ࠷࡟ࡩ࠮ࠣࡸࡪࡾࡴ࠭ࠢࡩࡳࡨࡻࡳࡕࡧࡻࡸࡺࡸࡥ࠾ࡤࡸࡸࡹࡵ࡮ࡠࡤࡪ࠰ࠥࡴ࡯ࡇࡱࡦࡹࡸ࡚ࡥࡹࡶࡸࡶࡪࡃࡢࡶࡶࡷࡳࡳࡥࡦࡰ࠮ࠣࡥࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃ࠲ࠪࠌࠌࠍࡹ࡫ࡸࡵࠢࡀࠤࡦࡼࡣࡰ࡮ࡲࡶࡸࡿࡥ࡭࡮ࡲࡻ࠰࠭ྏ")استمرارslQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ࠭ࡤࡺࡨࡵ࡬ࡰࡴࡶࡩࡳࡪࠊࠊࠋࡶࡩࡱ࡬࠮ࡰ࡭ࡥࡹࡹࡺ࡯࡯ࠢࡀࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳ࡉ࡯࡯ࡶࡵࡳࡱࡈࡵࡵࡶࡲࡲ࠭ࡨࡵࡵࡶࡲࡲ࠷ࡥࡸ࠭ࠢࡥࡹࡹࡺ࡯࡯࠴ࡢࡽ࠱ࠦࡢࡶࡶࡷࡳࡳ࠸࡟ࡸ࠮ࠣࡦࡺࡺࡴࡰࡰ࠵ࡣ࡭࠲ࠠࡵࡧࡻࡸ࠱ࠦࡦࡰࡥࡸࡷ࡙࡫ࡸࡵࡷࡵࡩࡂࡨࡵࡵࡶࡲࡲࡤࡨࡧ࠭ࠢࡱࡳࡋࡵࡣࡶࡵࡗࡩࡽࡺࡵࡳࡧࡀࡦࡺࡺࡴࡰࡰࡢࡪࡴ࠲ࠠࡢ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀ࠶࠮ࠐࠉࠊࡵࡨࡰ࡫࠴ࡡࡥࡦࡆࡳࡳࡺࡲࡰ࡮ࠫࡷࡪࡲࡦ࠯ࡱ࡮ࡦࡺࡺࡴࡰࡰࠬࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡦࡪࡤࡄࡱࡱࡸࡷࡵ࡬ࠩࡵࡨࡰ࡫࠴ࡣࡢࡰࡦࡩࡱࡨࡵࡵࡶࡲࡲ࠮ࠐࠊࠊࠋࡳ࡬࠱ࠦࡰࡸࠢࡀࠤ࡮ࡳࡧࡠࡪ࠲࠳ࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠳࠭ࠢ࡬ࡱ࡬ࡥࡷ࠰࠱ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠸ࠐࠉࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࠼࠭࠿ࠐࠉࠊࠋࡵࡳࡼࠦ࠽ࠡ࡫ࠣ࠳࠴ࠦࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠵ࠍࠍࠎࠏࡣࡰ࡮ࠣࡁࠥ࡯ࠠࠦࠢࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠸ࠐࠉࠊࠋࡻࡣࡵࡵࡳࠡ࠿ࠣ࡭ࡲ࡭࡟ࡹࠢ࠮ࠤ࠭ࡶࡷࠡࠬࠣࡧࡴࡲࠩࠋࠋࠌࠍࡾࡥࡰࡰࡵࠣࡁࠥ࡯࡭ࡨࡡࡼࠤ࠰ࠦࠨࡱࡪࠣ࠮ࠥࡸ࡯ࡸࠫࠍࠍࠎࠏࡳࡦ࡮ࡩ࠲ࡨ࡮࡫࡜࡫ࡠࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡄࡱࡱࡸࡷࡵ࡬ࡊ࡯ࡤ࡫ࡪ࠮ࡸࡠࡲࡲࡷ࠱ࠦࡹࡠࡲࡲࡷ࠱ࠦࡰࡸ࠮ࠣࡴ࡭࠲ࠠࡤࡪࡨࡧࡰࡥࡩ࡮ࡣࡪࡩ࠮ࠐࠉࠊࠋࡶࡩࡱ࡬࠮ࡢࡦࡧࡇࡴࡴࡴࡳࡱ࡯ࠬࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡡࡩ࡞ࠫࠍࠍࠎࠏࡳࡦ࡮ࡩ࠲ࡨ࡮࡫࡜࡫ࡠ࠲ࡸ࡫ࡴࡗ࡫ࡶ࡭ࡧࡲࡥࠩࡣࡹࡦࡴࡵ࡬ࡦࡣࡱࡷ࡫ࡧ࡬ࡴࡧࠬࠎࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡩࡨ࡬ࡤࡸࡸࡹࡵ࡮࡜࡫ࡠࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡄࡱࡱࡸࡷࡵ࡬ࡃࡷࡷࡸࡴࡴࠨࡹࡡࡳࡳࡸ࠲ࠠࡺࡡࡳࡳࡸ࠲ࠠࡱࡹ࠯ࠤࡵ࡮ࠬࠡࡵࡷࡶ࠭࡯ࠠࠬࠢࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠶࠯ࠬࠡࡨࡲࡲࡹࡃࠧྐ")ukza5CARTOLQPg(u"ࠩ࠯ࠤ࡫ࡵࡣࡶࡵࡗࡩࡽࡺࡵࡳࡧࡀࡦࡺࡺࡴࡰࡰࡢࡪࡴ࠲ࠠ࡯ࡱࡉࡳࡨࡻࡳࡕࡧࡻࡸࡺࡸࡥ࠾ࡤࡸࡸࡹࡵ࡮ࡠࡰࡲࡪࡴ࠯ࠊࠊࠋࠌࡷࡪࡲࡦ࠯ࡣࡧࡨࡈࡵ࡮ࡵࡴࡲࡰ࠭ࡹࡥ࡭ࡨ࠱ࡧ࡭ࡱࡢࡶࡶࡷࡳࡳࡡࡩ࡞ࠫࠍࠎࠎࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠺ࠫ࠽ࠎࠎࠏࠉࡳࡱࡺࡣࡸࡺࡡࡳࡶࠣࡁࠥ࠮ࡩࠡ࠱࠲ࠤࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠳ࠪࠢ࠭ࠤࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠳ࠋࠋࠌࠍࡷ࡯ࡧࡩࡶࠣࡁࠥࡸ࡯ࡸࡡࡶࡸࡦࡸࡴࠡ࠭ࠣࠬ࡮ࠦࠫࠡࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠵࠮ࠦࠥࠡࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠷ࠏࠏࠉࠊ࡮ࡨࡪࡹࠦ࠽ࠡࡴࡲࡻࡤࡹࡴࡢࡴࡷࠤ࠰ࠦࠨࡪࠢ࠰ࠤࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠱ࠪࠢࠨࠤࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠳ࠋࠋࠌࠍࡺࡶࠠ࠾ࠢࠫ࡭ࠥ࠳ࠠࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠶࠭ࠥࠫࠠ࠺ࠌࠌࠍࠎࡪ࡯ࡸࡰࠣࡁࠥ࠮ࡩࠡ࠭ࠣࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠹ࠩࠡࠧࠣ࠽ࠏࠏࠉࠊࡵࡨࡰ࡫࠴ࡣࡩ࡭ࡥࡹࡹࡺ࡯࡯࡝࡬ࡡ࠳ࡩ࡯࡯ࡶࡵࡳࡱࡘࡩࡨࡪࡷࠬࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡨࡵࡵࡶࡲࡲࡠࡸࡩࡨࡪࡷࡡ࠮ࠐࠉࠊࠋࡶࡩࡱ࡬࠮ࡤࡪ࡮ࡦࡺࡺࡴࡰࡰ࡞࡭ࡢ࠴ࡣࡰࡰࡷࡶࡴࡲࡌࡦࡨࡷࠬࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡨࡵࡵࡶࡲࡲࡠࡲࡥࡧࡶࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡮ࠦ࠼࠾ࠢࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠷ࡀࠊࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡨࡵࡵࡶࡲࡲࡠ࡯࡝࠯ࡥࡲࡲࡹࡸ࡯࡭ࡗࡳࠬࡸ࡫࡬ࡧ࠰ࡲ࡯ࡧࡻࡴࡵࡱࡱ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡨࡵࡵࡶࡲࡲࡠ࡯࡝࠯ࡥࡲࡲࡹࡸ࡯࡭ࡗࡳࠬࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡨࡵࡵࡶࡲࡲࡠࡻࡰ࡞ࠫࠍࠎࠎࠏࠉࡪࡨࠣ࡭ࠥࡄ࠽ࠡ࠸࠽ࠎࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡣࡩ࡭ࡥࡹࡹࡺ࡯࡯࡝࡬ࡡ࠳ࡩ࡯࡯ࡶࡵࡳࡱࡊ࡯ࡸࡰࠫࡷࡪࡲࡦ࠯ࡱ࡮ࡦࡺࡺࡴࡰࡰࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡷࡪࡲࡦ࠯ࡥ࡫࡯ࡧࡻࡴࡵࡱࡱ࡟࡮ࡣ࠮ࡤࡱࡱࡸࡷࡵ࡬ࡅࡱࡺࡲ࠭ࡹࡥ࡭ࡨ࠱ࡧ࡭ࡱࡢࡶࡶࡷࡳࡳࡡࡤࡰࡹࡱࡡ࠮ࠐࠊࠊࠋࡶࡩࡱ࡬࠮ࡰ࡭ࡥࡹࡹࡺ࡯࡯࠰ࡦࡳࡳࡺࡲࡰ࡮ࡏࡩ࡫ࡺࠨࡴࡧ࡯ࡪ࠳ࡩࡡ࡯ࡥࡨࡰࡧࡻࡴࡵࡱࡱ࠭ࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡵ࡫ࡣࡷࡷࡸࡴࡴ࠮ࡤࡱࡱࡸࡷࡵ࡬ࡓ࡫ࡪ࡬ࡹ࠮ࡳࡦ࡮ࡩ࠲ࡨࡧ࡮ࡤࡧ࡯ࡦࡺࡺࡴࡰࡰࠬࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡨࡧ࡮ࡤࡧ࡯ࡦࡺࡺࡴࡰࡰ࠱ࡧࡴࡴࡴࡳࡱ࡯ࡐࡪ࡬ࡴࠩࡵࡨࡰ࡫࠴࡯࡬ࡤࡸࡸࡹࡵ࡮ࠪࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡦࡥࡳࡩࡥ࡭ࡤࡸࡸࡹࡵ࡮࠯ࡥࡲࡲࡹࡸ࡯࡭ࡔ࡬࡫࡭ࡺࠨࡴࡧ࡯ࡪ࠳ࡵ࡫ࡣࡷࡷࡸࡴࡴࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡱ࡮ࡦࡺࡺࡴࡰࡰ࠱ࡧࡴࡴࡴࡳࡱ࡯ࡈࡴࡽ࡮ࠩࡵࡨࡰ࡫࠴ࡣࡩ࡭ࡥࡹࡹࡺ࡯࡯࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠷ࡣࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡱ࡮ࡦࡺࡺࡴࡰࡰ࠱ࡧࡴࡴࡴࡳࡱ࡯࡙ࡵ࠮ࡳࡦ࡮ࡩ࠲ࡨ࡮࡫ࡣࡷࡷࡸࡴࡴ࡛࠹࡟ࠬࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡨࡧ࡮ࡤࡧ࡯ࡦࡺࡺࡴࡰࡰ࠱ࡧࡴࡴࡴࡳࡱ࡯ࡈࡴࡽ࡮ࠩࡵࡨࡰ࡫࠴ࡣࡩ࡭ࡥࡹࡹࡺ࡯࡯࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡣࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡥࡤࡲࡨ࡫࡬ࡣࡷࡷࡸࡴࡴ࠮ࡤࡱࡱࡸࡷࡵ࡬ࡖࡲࠫࡷࡪࡲࡦ࠯ࡥ࡫࡯ࡧࡻࡴࡵࡱࡱ࡟࠻ࡣࠩࠋࠋࠌࡷࡪࡲࡦ࠯ࡵࡨࡸࡋࡵࡣࡶࡵࠫࡷࡪࡲࡦ࠯ࡱ࡮ࡦࡺࡺࡴࡰࡰࠬࠎࠏࠏࡤࡦࡨࠣ࡫ࡪࡺࠨࡴࡧ࡯ࡪ࠮ࡀࠊࠊࠋࡶࡩࡱ࡬࠮ࡥࡱࡐࡳࡩࡧ࡬ࠩࠫࠍࠍࠎࡹࡥ࡭ࡨ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡳࡦ࡮ࡩ࠲ࡨࡧ࡮ࡤࡧ࡯ࡰࡪࡪ࠺ࠋࠋࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡠ࡯ࠠࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࠻ࠬࠤ࡮࡬ࠠࡴࡧ࡯ࡪ࠳ࡩࡨ࡬ࡵࡷࡥࡹ࡫࡛ࡪ࡟ࡠࠎࠏࠏࡤࡦࡨࠣࡳࡳࡉ࡯࡯ࡶࡵࡳࡱ࠮ࡳࡦ࡮ࡩ࠰ࠥࡩ࡯࡯ࡶࡵࡳࡱ࠯࠺ࠋࠋࠌ࡭࡫ࠦࡣࡰࡰࡷࡶࡴࡲ࠮ࡨࡧࡷࡍࡩ࠮ࠩࠡ࠿ࡀࠤࡸ࡫࡬ࡧ࠰ࡲ࡯ࡧࡻࡴࡵࡱࡱ࠲࡬࡫ࡴࡊࡦࠫ࠭ࠥࡧ࡮ࡥࠢࡤࡲࡾ࠮ࡳࡦ࡮ࡩ࠲ࡨ࡮࡫ࡴࡶࡤࡸࡪ࠯࠺ࠋࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠎࠎࠏࡥ࡭࡫ࡩࠤࡨࡵ࡮ࡵࡴࡲࡰ࠳࡭ࡥࡵࡋࡧࠬ࠮ࠦ࠽࠾ࠢࡶࡩࡱ࡬࠮ࡤࡣࡱࡧࡪࡲࡢࡶࡶࡷࡳࡳ࠴ࡧࡦࡶࡌࡨ࠭࠯࠺ࠋࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦࡥࡳࡩࡥ࡭࡮ࡨࡨࠥࡃࠠࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡸࡷࡻࡥࠋࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉ࡭ࡣࡥࡩࡱࠦ࠽ࠡࡥࡲࡲࡹࡸ࡯࡭࠰ࡪࡩࡹࡒࡡࡣࡧ࡯ࠬ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡲࡡࡣࡧ࡯࠲࡮ࡹ࡮ࡶ࡯ࡨࡶ࡮ࡩࠨࠪ࠼ࠍࠍࠎࠏࠉࡪࡰࡧࡩࡽࠦ࠽ࠡ࡫ࡱࡸ࠭ࡲࡡࡣࡧ࡯࠭ࠥ࠳ࠠࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠴ࠎࠎࠏࠉࠊࡵࡨࡰ࡫࠴ࡣࡩ࡭ࡶࡸࡦࡺࡥ࡜࡫ࡱࡨࡪࡾ࡝ࠡ࠿ࠣࡲࡴࡺࠠࡴࡧ࡯ࡪ࠳ࡩࡨ࡬ࡵࡷࡥࡹ࡫࡛ࡪࡰࡧࡩࡽࡣࠊࠊࠋࠌࠍࡸ࡫࡬ࡧ࠰ࡦ࡬ࡰࡡࡩ࡯ࡦࡨࡼࡢ࠴ࡳࡦࡶ࡙࡭ࡸ࡯ࡢ࡭ࡧࠫࡷࡪࡲࡦ࠯ࡥ࡫࡯ࡸࡺࡡࡵࡧ࡞࡭ࡳࡪࡥࡹ࡟ࠬࠎࠏࠏࡤࡦࡨࠣࡳࡳࡇࡣࡵ࡫ࡲࡲ࠭ࡹࡥ࡭ࡨ࠯ࠤࡦࡩࡴࡪࡱࡱ࠭࠿ࠐࠉࠊ࡫ࡩࠤࡦࡩࡴࡪࡱࡱࠤࡂࡃࠠ࠲࠲࠽ࠎࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡩࡡ࡯ࡥࡨࡰࡱ࡫ࡤࠡ࠿ࠣࡥࡻࡨ࡯ࡰ࡮ࡨࡥࡳࡹࡴࡳࡷࡨࠎࠎࠏࠉࡴࡧ࡯ࡪ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠊࡥࡧࡩࠤࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑࠬࡰ࡫ࡹ࠭࡮ࡤࡲ࡬࠲ࡵࡳ࡮ࠬ࠾ࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫྑ")DkubzWS0594fxR(u"ࡵࠫ࠿ࡻࡲ࡭࠮ࠪྒ")XD3FYGBZReAKhzvfsLPS-coshrR1pZY5u(u"ࠫ࠿ࡲࡡ࡯ࡩࢀࠎࠎࡩࡡࡱࡶࡦ࡬ࡦࡥࡵࡳ࡮ࠣࡁࠥ࠭ྒྷ")jMQ6fCHhiFGobBRUI://www.tvmsShT5oknA4yGi6rbz.com/mjKTXMzecFB5thU1RPNd/QQDXToYdLawSE0s9/q76sN3vzW5OV?SnasPEKp3MYkN20u=rAYDiWlzm9MCU6x0GnROua(u"ࠬ࠱࡫ࡦࡻࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࠩྔ")QzJ02f14Z6sIiE8t(u"࠭ࠬࡤࡣࡳࡸࡨ࡮ࡡࡠࡷࡵࡰ࠱ࡧࡶࡴࡲࡤࡧࡪࡹ࠰࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࡧࡶࡴࡲࡤࡧࡪࡹ࠰࠭ࠩྕ")v3w7fbWE0x-lraO5C2IRhob7jvGTdu9Dkf4-1stunScramble5_opy2_(u"ࠧࠪࠌࠌࡸࡴࡱࡥ࡯࠮࡬ࡸࡪࡸࡡࡵ࡫ࡲࡲࠥࡃࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲࠯ࡥࡻࡴࡵ࡮ࡤࡨࡶࡸ࠶ࠊࠊࡹ࡫࡭ࡱ࡫ࠠࡢࡸࡥࡳࡴࡲࡥࡢࡰࡶࡸࡷࡻࡥ࠻ࠌࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋࡳࡥࡾࡲ࡯ࡢࡦࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪྖ")MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠣࠪ࠲ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠵ࡡࡱ࡫࠵࠳ࡵࡧࡹ࡭ࡱࡤࡨࡠࡤࠢྗ")]+)pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࠯ࠤ࡭ࡺ࡭࡭ࠫࠍࠍࠎ࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࠡ࠭ࡀࠤࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠱ࠋࠋࠌࡱࡪࡹࡳࡢࡩࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ྘")<AAB086Sqz9xc[^>]+class=vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡴࡦࡺࡷࠦྙ")[^>]*>(.*?)</AAB086Sqz9xc>f9fOpCmLAEaW2Go(u"ࠫ࠱ࠦࡨࡵ࡯࡯࠭ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠ࡮ࡧࡶࡷࡦ࡭ࡥ࠻ࠢࡰࡩࡸࡹࡡࡨࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪྚ")<jjJLPm8MTZzal9pK[^>]+class=lRKCWnNi0Edr984eI(u"ࠧ࡬ࡢࡤ࠯࡬ࡱࡦ࡭ࡥࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡶࡷࡦ࡭ࡥ࠮ࡧࡵࡶࡴࡸࠢྛ")>(.*?)</jjJLPm8MTZzal9pK>fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࠬࠡࡪࡷࡱࡱ࠯ࠊࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡰࡩࡸࡹࡡࡨࡧ࠽ࠎࠎࠏࠉࡵࡱ࡮ࡩࡳࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ྜ")readonly>(.*?)<Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࠭ࠢ࡫ࡸࡲࡲࠩ࡜ࡣࡹࡲࡺࡳࡢࡦࡴࡶ࠴ࡢࠐࠉࠊࠋࡥࡶࡪࡧ࡫ࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࠦ࠽ࠡ࡯ࡨࡷࡸࡧࡧࡦ࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡣࠊࠊࠋࠌࡴࡦࡿ࡬ࡰࡣࡧࠤࡂࠦࡰࡢࡻ࡯ࡳࡦࡪ࡛ࡢࡸࡱࡹࡲࡨࡥࡳࡵ࠳ࡡࠏࠏࠉࡤࡸࡤࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࡷ࠭ྜྷ")name=YzlId3Fs6vpehcbLGj0UaO(u"ࠣࡥࠥྞ")\GAiZHfqDPxwFu4W6SnXJKCo5+value=slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠤࠫ࡟ࡣࠨྟ")]+)lRKCWnNi0Edr984eI(u"ࠪ࠰ࠥ࡮ࡴ࡮࡮ࠬ࡟ࡦࡼ࡮ࡶ࡯ࡥࡩࡷࡹ࠰࡞ࠌࠌࠍࡨࡧࡰࡵࡥ࡫ࡥࡤ࡯࡭ࡨࡷࡵࡰࠥࡃࠠࠨྠ")https://www.tvmsShT5oknA4yGi6rbz.com%D62KQplAzEmyN3hv57IgZLMqTSwYC(u"ࠫࠥࠫࠠࠩࡲࡤࡽࡱࡵࡡࡥ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫྡ")&rXaGl7vhsub3DEFfP9JoH6wdzBc14R;fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬ࠲ࠠࠨྡྷ")&w9wfONXUP3(u"࠭ࠩࠪࠌࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࡳࡧ࠱ࡷࡺࡨࠨࠨྣ")</?(jjJLPm8MTZzal9pK|BMe6ZYCEvsx9rVHl5uk)[^>]*>pL73X0MYajJQG4n1qgD(u"ࠧ࠭ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠩࠋࠋࠌࡳࡘࡵ࡬ࡷࡧࡵࠤࡂࠦࡣࡳࡧࡤࡸࡪࡘࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࡆ࡬ࡥࡱࡵࡧࠩࡥࡤࡴࡹࡩࡨࡢ࠿ࡦࡥࡵࡺࡣࡩࡣࡢ࡭ࡲ࡭ࡵࡳ࡮࠯ࠤࡲࡹࡧ࠾࡯ࡨࡷࡸࡧࡧࡦ࠮ࠣ࡭ࡹ࡫ࡲࡢࡶ࡬ࡳࡳࡃࡩࡵࡧࡵࡥࡹ࡯࡯࡯ࠫࠍࠍࠎࡩࡡࡱࡶࡦ࡬ࡦࡥࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡳࡘࡵ࡬ࡷࡧࡵ࠲࡬࡫ࡴࠩࠫࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡩࡡࡱࡶࡦ࡬ࡦࡥࡲࡦࡵࡳࡳࡳࡹࡥ࠻ࠢࡥࡶࡪࡧ࡫ࠋࠋࠌࡨࡦࡺࡡࠡ࠿ࠣࡿࠬྤ")nnCNrHZc8jzdOqAeT9P6xu3LoyIVD(u"ࠨ࠼ࠣࡧࡻࡧ࡬࠭ࠢࠪྥ")x0JZeSzIYcGnadtgkRmj9EHfsQBMy(u"ࠩ࠽ࠤࡨࡧࡰࡵࡥ࡫ࡥࡤࡸࡥࡴࡲࡲࡲࡸ࡫ࡽࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࠨྦ")opZ7rzV4xJtsPKCBi(u"ࠪ࠰ࡨࡧࡰࡵࡥ࡫ࡥࡤࡻࡲ࡭࠮ࡧࡥࡹࡧࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࡣࡹࡷࡵࡧࡣࡦࡵ࠳࠰ࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠬࠨྦྷ")v3w7fbWE0x-lraO5C2IRhob7jvGTdu9Dkf4-2ndunScramble0_opy2_(u"ࠫ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡵࡱ࡮ࡩࡳࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࠌࠍࠎࠏࠐࠊࠋࡦࡨࡪࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠩࡷࡵࡰ࠮ࡀࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠬࡢࡸࡶࡴࡦࡩࡥࡴ࠲࠯ࡥࡻࡹࡰࡢࡥࡨࡷ࠵࠲ࠧྨ")v3w7fbWE0x-NpvkIPh8cAdLM-1stunScramble24_opy2_(u"ࠬ࠯ࠊࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧྩ")yy1EhgunemzWIjiRvkAJ7QNB9DY5=B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡲࡦࡦࠥྪ")>(.*?)<fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠠࡳࡧࡷࡹࡷࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲࠯࡟ࡦࡼࡳࡱࡣࡦࡩࡸ࠶࡝࠭࡝ࠣ࡭ࡹ࡫࡭ࡴ࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡣࠠ࡞ࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪྫ")tDm3g0LSONUuKwrQf: wXejCBZLE5bcq VX6D3jQPfFiWYrLsBJIU FtuayskoSf92LBQPU(u"ࠨ࠮࡞ࡡ࠱ࡡ࡝ࠋࠌࡧࡩ࡫ࠦࡔࡐࡒ࠷ࡘࡔࡖࠨࡶࡴ࡯࠭࠿ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲࠯࡟ࡦࡼࡳࡱࡣࡦࡩࡸ࠶࡝࠭࡝ࡸࡶࡱࡣࠊࠋࡦࡨࡪࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠪࡸࡶࡱ࠯࠺ࠋࠋࠍࠍࡸ࡫ࡲࡷࡧࡵࠤࡂࠦࡵࡳ࡮࠱ࡷࡵࡲࡩࡵࠪࠪྫྷ")/Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࠬࠎࠎࡨࡡࡴࡧࡱࡥࡲ࡫ࠠ࠾ࠢࠪྭ")/KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࠲࡯ࡵࡩ࡯ࠪࡶࡩࡷࡼࡥࡳ࡝ࡤࡺࡳࡻ࡭ࡣࡧࡵࡷ࠵ࡀࡡࡷࡰࡸࡱࡧ࡫ࡲࡴ࠵ࡠ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࡤࡺࡸࡶࡡࡤࡧࡶ࠴࠱ࡧࡶࡴࡲࡤࡧࡪࡹ࠰࠭ࡣࡹࡷࡵࡧࡣࡦࡵ࠳࠰ࠬྮ")v3w7fbWE0x-RJTjvbpXONKgGY-1stunScramble7_opy2_(u"ࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ྯ")XNh1KEUR7GHmdf4tBb\zWBnYSGIatjXVC(u"ࠬࡢࠩ࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠢ࡟࠯ࠥࡢࠨࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩࠡ࡞࠮ࠤ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࡡ࠯ࠠ࡝࠭ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫྰ"),html,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu,AtMlgVZSip0NmhwaLKOX2enqI5Q,aaWcZUIDnEudzfHivmMOGbKs,buEZWx70Xmy9YzR,bDJcS4M3xyCYFV8sOoNBX0k = items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		c72bnzmgOfUp6SlAGvrDuZ4Hi = int(yg0RO5Z4qJBm9bu) % int(AtMlgVZSip0NmhwaLKOX2enqI5Q) + int(aaWcZUIDnEudzfHivmMOGbKs) % int(buEZWx70Xmy9YzR)
		url = ccQJnaRWozSE87wGjFgkBmsXYet + fo4hLHW18Uj0EPyz + str(c72bnzmgOfUp6SlAGvrDuZ4Hi) + bDJcS4M3xyCYFV8sOoNBX0k
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[url]
	else: return slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬྱ"),[],[]
def W8Yg0lRn2OHwixFVIoN1bDPjt(url):
	id = url.split(GTmHXIZUSdxRhMnqQKkO(u"ࠧ࠰ࠩྲ"))[-xD9WeoEAsX7]
	headers = { pYeVwat64v(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧླ") : kAz7WRYjrfGm(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨྴ") }
	dXG96SRYbe = { fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠥ࡭ࡩࠨྵ"):id , rAYDiWlzm9MCU6x0GnROua(u"ࠦࡴࡶࠢྶ"):YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣྷ") }
	eBjxVKSvQC1 = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,zWBnYSGIatjXVC(u"࠭ࡐࡐࡕࡗࠫྸ"), url, dXG96SRYbe, headers, VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKCrwPdOgGl(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠳࠱ࡴࡶࠪྐྵ"))
	if nR0ok9zju84rFUQl1YC(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪྺ") in list(eBjxVKSvQC1.headers.keys()): cX2SpPxGLmADTKl = eBjxVKSvQC1.headers[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫྻ")]
	else: cX2SpPxGLmADTKl = url
	if cX2SpPxGLmADTKl: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[cX2SpPxGLmADTKl]
	else: return jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡐ࠵ࡗࡓࡐࡔࡇࡄࠨྼ"),[],[]
def YrpJiQmZaqW(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ba49YvOK2Aw8Uhxt(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ྽"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ྾"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[ items[nUaVQsoA6EXcK4Odht5wCge0J8Pib] ]
	else: return B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡌࡒ࡙࡜ࡌࡊࡘࡈࠫ྿"),[],[]
def CkAz34Wh6OIs(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡉࡈࡊࡘࡈ࠱࠶ࡹࡴࠨ࿀"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࿁"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		url = url = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ࿂") + items[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[ url ]
	else: return KKCrwPdOgGl(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡄࡊࡌ࡚ࡊ࠭࿃"),[],[]
def ikTndP1FNXORp5ugWmaoGbM(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ࿄"))
	items = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࿅"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items: return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O],[ items[nUaVQsoA6EXcK4Odht5wCge0J8Pib] ]
	else: return fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎ࿆ࠩ"),[],[]