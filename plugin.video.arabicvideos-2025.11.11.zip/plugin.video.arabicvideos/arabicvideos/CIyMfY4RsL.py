# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'SHAHIDNEWS'
qBAgzkG9oCL = '_SHN_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['قنوات فضائية','فارسكو','Show more']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==580: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==581: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==582: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==583: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url,text)
	elif mode==584: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==589: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHIDNEWS-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,589,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('/category.php">(.*?)"navslide-divider"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall("'dropdown-menu'(.*?)</ul>",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for Lhi71X39bHs6zEZ4ypIaGewVJ in vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace(Lhi71X39bHs6zEZ4ypIaGewVJ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,584)
	return
def I1C6JqXo3j9Ruyz(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHIDNEWS-SUBMENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"caret"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if j9HbACE1rmuP48NVX6pgQsUwfBWk:
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('"presentation"','</ul>')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = [(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,IxdmfnvhCA8Bc9ZlQ45oiqN)]
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' فرز أو فلتر أو ترتيب '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		for wMVN0pF2Qqt1AGTI6ujBshRJO5fP,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if wMVN0pF2Qqt1AGTI6ujBshRJO5fP: wMVN0pF2Qqt1AGTI6ujBshRJO5fP = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+': '
			for cX2SpPxGLmADTKl,title in items:
				title = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+title
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,581)
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-category-subcats"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if fxgnWRoUO7jNwtJkuB:
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(items)<30:
			w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			for cX2SpPxGLmADTKl,title in items:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,581)
	if not j9HbACE1rmuP48NVX6pgQsUwfBWk and not fxgnWRoUO7jNwtJkuB: ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHIDNEWS-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(data-echo=".*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"BlocksList"(.*?)"titleSectionCon"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="pm-grid"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="pm-related"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: return
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl).strip('/')
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
		if 'http' not in RRx0ri8bETI: RRx0ri8bETI = GGRexoVTLjusn6q+'/'+RRx0ri8bETI.strip('/')
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,582,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and 'الحلقة' in title:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,583,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/movseries/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,581,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,583,RRx0ri8bETI)
	if eBjxVKSvQC1 not in ['featured_movies','featured_series']:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl=='#': continue
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				title = riUKNnOEtVwdj4(title)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,581)
		zGyAMhFIjxNdlb6ZeX54 = AxTYMhRlfyskNc0X19dvwtS.findall('showmore" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if zGyAMhFIjxNdlb6ZeX54:
			cX2SpPxGLmADTKl = zGyAMhFIjxNdlb6ZeX54[0]
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مشاهدة المزيد',cX2SpPxGLmADTKl,581)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url,nRW2P4Ke3z7):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHIDNEWS-EPISODES-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('nav-seasons"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	items = []
	Plc3HUgEvQDiOIrsL4Sm1ZF8M = False
	if j9HbACE1rmuP48NVX6pgQsUwfBWk and not nRW2P4Ke3z7:
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for nRW2P4Ke3z7,title in items:
			nRW2P4Ke3z7 = nRW2P4Ke3z7.strip('#')
			if len(items)>1: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,583,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nRW2P4Ke3z7)
			else: Plc3HUgEvQDiOIrsL4Sm1ZF8M = True
	else: Plc3HUgEvQDiOIrsL4Sm1ZF8M = True
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('id="'+nRW2P4Ke3z7+'"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if fxgnWRoUO7jNwtJkuB and Plc3HUgEvQDiOIrsL4Sm1ZF8M:
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if items:
			for cX2SpPxGLmADTKl,title in items:
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,582)
		else:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,582)
	return
def QgIZSJdUhsEnup8GPz3(url):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHAHIDNEWS-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('"Playerholder".*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
	if cX2SpPxGLmADTKl and 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
	VlzQ52gKbquFewdcptkIfEvYmUN9O1 = cX2SpPxGLmADTKl.split('hash=')[1]
	PCnrX0p2QmTt5ijBIkqu4La = VlzQ52gKbquFewdcptkIfEvYmUN9O1.split('__')
	eMPivF8NqbjcB,BA01W9olieErLycV7kwFvOhH5Y3ms,title = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for i1xLE74agTmA3FBVruGCQsWKjOc in PCnrX0p2QmTt5ijBIkqu4La:
		meMvSjaxWOC57YQG = ((4-len(i1xLE74agTmA3FBVruGCQsWKjOc)%4)%4)*'='
		try:
			i1xLE74agTmA3FBVruGCQsWKjOc = j3kWVqdguK6O2QDmMf.b64decode(i1xLE74agTmA3FBVruGCQsWKjOc+meMvSjaxWOC57YQG)
			if fOohwvakqi29cx0l3yt5mzrAGpEg: i1xLE74agTmA3FBVruGCQsWKjOc = i1xLE74agTmA3FBVruGCQsWKjOc.decode(RMGz7OiD1e30P,'ignore')
		except: pass
		eMPivF8NqbjcB += i1xLE74agTmA3FBVruGCQsWKjOc
	eMPivF8NqbjcB = eMPivF8NqbjcB.replace(' = ',' => ')
	flWqDGtYAQx7k4m2JRe68LEb = eMPivF8NqbjcB.splitlines()
	for cX2SpPxGLmADTKl in flWqDGtYAQx7k4m2JRe68LEb:
		if '://' in cX2SpPxGLmADTKl: BA01W9olieErLycV7kwFvOhH5Y3ms.append(cX2SpPxGLmADTKl)
	for cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
		if ' => ' in cX2SpPxGLmADTKl: title,cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split(' => ')
		elif 'http' in cX2SpPxGLmADTKl:
			title,cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('http')
			cX2SpPxGLmADTKl = 'http'+cX2SpPxGLmADTKl
		else: continue
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.strip(' ')
		if not title: title = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/search.php?keywords='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return