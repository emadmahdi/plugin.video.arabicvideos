# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
headers = { 'User-Agent' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
mI6ayKxBvjd4CRthL = 'AKOAM'
qBAgzkG9oCL = '_AKO_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
wun2b1IOSQCRViMqDk6foe3XgAFad = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==70: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==71: Ubud2NhHKRnMTvI5mprQBVqk80 = gFLtwp2hNmQ6iHu7T4ReIOl(url)
	elif mode==72: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==73: Ubud2NhHKRnMTvI5mprQBVqk80 = W1o8YpSshAjE4VezLcMOyCb3l(url)
	elif mode==74: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==79: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,79,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'سلسلة افلام',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,79,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'سلسلة افلام')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'سلاسل منوعة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,79,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'سلسلة')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	kCIESuy4j5mVLZYtG9vDNnb7 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="partions"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7:
				w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,71)
	return R8AE9e4mYxVhusL3Q
def gFLtwp2hNmQ6iHu7T4ReIOl(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAM-CATEGORIES-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('sect_parts(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,72)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'جميع الفروع',url,72)
	else: ENDRjPGicXYFvpVs3xk5uSg6y(url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('section_title featured_title(.*?)subjects-crousel',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif type=='search':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('akoam_result(.*?)<script',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif type=='more':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('section_title more_title(.*?)footer_bottom_services',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('navigation(.*?)<script',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items and vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		title = riUKNnOEtVwdj4(title)
		if any(value in title for value in wun2b1IOSQCRViMqDk6foe3XgAFad): w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,73,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,73,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="pagination"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall("</li><li >.*?href='(.*?)'>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,72,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,type)
	return
def U3TL8GmQ2v9A7JBegZnqbjFlE(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAM-SECTIONS-2nd')
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('"href","(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nUDgc4absePT2xMt = nUDgc4absePT2xMt[1]
	return nUDgc4absePT2xMt
def W1o8YpSshAjE4VezLcMOyCb3l(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKOAM-SECTIONS-1st')
	mHaOtF1RG0roslMuB4SEx9iKn2 = AxTYMhRlfyskNc0X19dvwtS.findall('"(https*://akwam.net/\w+.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	TIwv1e0aySnK = AxTYMhRlfyskNc0X19dvwtS.findall('"(https*://underurl.com/\w+.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if mHaOtF1RG0roslMuB4SEx9iKn2 or TIwv1e0aySnK:
		if mHaOtF1RG0roslMuB4SEx9iKn2: jYfvU9egTX62nrukVcoKEAyq = mHaOtF1RG0roslMuB4SEx9iKn2[0]
		elif TIwv1e0aySnK: jYfvU9egTX62nrukVcoKEAyq = U3TL8GmQ2v9A7JBegZnqbjFlE(TIwv1e0aySnK[0])
		jYfvU9egTX62nrukVcoKEAyq = WDg18QHF3rze(jYfvU9egTX62nrukVcoKEAyq)
		import R7N1PDkgeU
		if '/series/' in jYfvU9egTX62nrukVcoKEAyq or '/shows/' in jYfvU9egTX62nrukVcoKEAyq: R7N1PDkgeU.SnpFbUovmMwfXalIGRNys6zYZtj(jYfvU9egTX62nrukVcoKEAyq)
		else: R7N1PDkgeU.QgIZSJdUhsEnup8GPz3(jYfvU9egTX62nrukVcoKEAyq)
		return
	OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd): return
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		title = riUKNnOEtVwdj4(title)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,73)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt:
		ARL0tsEeanKImhMByugPTvX7('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,RRx0ri8bETI,IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	name = name.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	if 'sub_epsiode_title' in IxdmfnvhCA8Bc9ZlQ45oiqN:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else:
		rr3sHcDQldoLFE2jK9ZI715 = AxTYMhRlfyskNc0X19dvwtS.findall('sub_file_title\'>(.*?) - <i>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		items = []
		for filename in rr3sHcDQldoLFE2jK9ZI715:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O) ]
	count = 0
	GjC4atkJLwlTpsI,Y5FHiylDJmIMjfqc1ZA3 = [],[]
	size = len(items)
	for title,filename in items:
		kw7O9B5fZceYAn0RbNtL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: kw7O9B5fZceYAn0RbNtL = filename.split('.')[-1]
		title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		GjC4atkJLwlTpsI.append(title)
		Y5FHiylDJmIMjfqc1ZA3.append(count)
		count += 1
	if size>0:
		if any(value in name for value in wun2b1IOSQCRViMqDk6foe3XgAFad):
			if size==1:
				qNmsBD1jJZVzcxi4onKuAOIC = 0
			else:
				qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('اختر الفيديو المناسب:', GjC4atkJLwlTpsI)
				if qNmsBD1jJZVzcxi4onKuAOIC == -1: return
			QgIZSJdUhsEnup8GPz3(url+'?section='+str(1+Y5FHiylDJmIMjfqc1ZA3[size-qNmsBD1jJZVzcxi4onKuAOIC-1]))
		else:
			for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in reversed(range(size)):
				title = name + ' - ' + GjC4atkJLwlTpsI[uKFGBAEj9tX1e03cyHOMUNhQl4r6]
				title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				cX2SpPxGLmADTKl = url + '?section='+str(size-uKFGBAEj9tX1e03cyHOMUNhQl4r6)
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,74,RRx0ri8bETI)
	else:
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+'الرابط ليس فيديو',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	nUDgc4absePT2xMt,azhwpE0qmevcFobdRi = url.split('?section=')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKOAM-PLAY_AKOAM-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	DyjCSoGr6vUN7b94iu8d1Tt = vvuraxgW7YLIZ4hU0MbCt[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	DyjCSoGr6vUN7b94iu8d1Tt = DyjCSoGr6vUN7b94iu8d1Tt + 'direct_link_box'
	GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall('epsoide_box(.*?)direct_link_box',DyjCSoGr6vUN7b94iu8d1Tt,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	azhwpE0qmevcFobdRi = len(GtnfmdqIOijegYu)-int(azhwpE0qmevcFobdRi)
	IxdmfnvhCA8Bc9ZlQ45oiqN = GtnfmdqIOijegYu[azhwpE0qmevcFobdRi]
	dU17fayKLj4kABu = []
	Nt2vKu4B5dnADoTqGH37ZMm1cPF = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = AxTYMhRlfyskNc0X19dvwtS.findall("class='download_btn.*?href='(.*?)'",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl in items:
		dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=________akoam')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for dlsXW4P7qSILnDT0KeQ3E,cX2SpPxGLmADTKl in items:
		dlsXW4P7qSILnDT0KeQ3E = dlsXW4P7qSILnDT0KeQ3E.split('/')[-1]
		dlsXW4P7qSILnDT0KeQ3E = dlsXW4P7qSILnDT0KeQ3E.split('.')[0]
		if dlsXW4P7qSILnDT0KeQ3E in Nt2vKu4B5dnADoTqGH37ZMm1cPF:
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+Nt2vKu4B5dnADoTqGH37ZMm1cPF[dlsXW4P7qSILnDT0KeQ3E]+'________akoam')
		else: dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+dlsXW4P7qSILnDT0KeQ3E+'________akoam')
	if not dU17fayKLj4kABu:
		message = AxTYMhRlfyskNc0X19dvwtS.findall('sub-no-file.*?\n(.*?)\n',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if message: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'رسالة من الموقع الاصلي',message[0])
	else:
		import v3w7fbWE0x
		v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	url = S7EgasGcYdIo + '/search/'+ej9gRJkD6KGTcf
	Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return