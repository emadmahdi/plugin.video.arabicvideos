# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'ALARAB'
headers = {'User-Agent':VhaIfJdtZP1kiKbRq8nGvFo9juBp2O}
qBAgzkG9oCL = '_KLA_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==10: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==11: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif mode==12: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==13: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==14: Ubud2NhHKRnMTvI5mprQBVqk80 = DzQdbq9C70aF1uc()
	elif mode==15: Ubud2NhHKRnMTvI5mprQBVqk80 = aFSfLpdiKyHwZNc4jWXm1evEJun69D()
	elif mode==16: Ubud2NhHKRnMTvI5mprQBVqk80 = iobXKrS2eBv5()
	elif mode==19: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,19,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'آخر الإضافات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,14)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'مسلسلات رمضان',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,15)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALARAB-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt=AxTYMhRlfyskNc0X19dvwtS.findall('id="nav-slider"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	ZmqAjw6lOn3XIfN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',ZmqAjw6lOn3XIfN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,11)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="navbar"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	Lhi71X39bHs6zEZ4ypIaGewVJ = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',Lhi71X39bHs6zEZ4ypIaGewVJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,11)
	return R8AE9e4mYxVhusL3Q
def aFSfLpdiKyHwZNc4jWXm1evEJun69D():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'جميع المسلسلات العربية',S7EgasGcYdIo+'/view-8/مسلسلات-عربية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات السنة الأخيرة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,16)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان الأخيرة 1',S7EgasGcYdIo+'/view-8/مسلسلات-رمضان-2022',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان الأخيرة 2',S7EgasGcYdIo+'/view-8/مسلسلات-رمضان-2023',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2023',S7EgasGcYdIo+'/ramadan2023/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2022',S7EgasGcYdIo+'/ramadan2022/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2021',S7EgasGcYdIo+'/ramadan2021/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2020',S7EgasGcYdIo+'/ramadan2020/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2019',S7EgasGcYdIo+'/ramadan2019/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2018',S7EgasGcYdIo+'/ramadan2018/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2017',S7EgasGcYdIo+'/ramadan2017/مصرية',11)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات رمضان 2016',S7EgasGcYdIo+'/ramadan2016/مصرية',11)
	return
def DzQdbq9C70aF1uc():
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'ALARAB-LATEST-1st')
	vvuraxgW7YLIZ4hU0MbCt=AxTYMhRlfyskNc0X19dvwtS.findall('heading-top(.*?)div class=',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]+vvuraxgW7YLIZ4hU0MbCt[1]
	items=AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		url = S7EgasGcYdIo + cX2SpPxGLmADTKl
		if 'series' in url: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,11,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,url,12,RRx0ri8bETI)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,True,'ALARAB-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('video-category(.*?)right_content',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvuraxgW7YLIZ4hU0MbCt: return
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = False
	items = AxTYMhRlfyskNc0X19dvwtS.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD,zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv = [],[]
	for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
		if title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: title = cX2SpPxGLmADTKl.split('/')[-1].replace('-',WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		KBtshNldD0nmAHTgEzcbIMWG9ri = AxTYMhRlfyskNc0X19dvwtS.findall('(\d+)',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if KBtshNldD0nmAHTgEzcbIMWG9ri: KBtshNldD0nmAHTgEzcbIMWG9ri = int(KBtshNldD0nmAHTgEzcbIMWG9ri[0])
		else: KBtshNldD0nmAHTgEzcbIMWG9ri = 0
		zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv.append([RRx0ri8bETI,cX2SpPxGLmADTKl,title,KBtshNldD0nmAHTgEzcbIMWG9ri])
	zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv = sorted(zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv, reverse=True, key=lambda key: key[3])
	for RRx0ri8bETI,cX2SpPxGLmADTKl,title,KBtshNldD0nmAHTgEzcbIMWG9ri in zQlPRTrDnf6sx4HZtWh2awCGVUN0Xv:
		cX2SpPxGLmADTKl = S7EgasGcYdIo + cX2SpPxGLmADTKl
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('عالية على العرب',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('مشاهدة مباشرة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('اون لاين',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('اونلاين',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('بجودة عالية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('جودة عالية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('بدون تحميل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('على العرب',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.replace('مباشرة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		title = '_MOD_'+title
		uoH6T37WPfCdv8JLnYZjK2r = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if azhwpE0qmevcFobdRi: uoH6T37WPfCdv8JLnYZjK2r = azhwpE0qmevcFobdRi[0]
		if uoH6T37WPfCdv8JLnYZjK2r not in EaUe8ArOCD:
			EaUe8ArOCD.append(uoH6T37WPfCdv8JLnYZjK2r)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+uoH6T37WPfCdv8JLnYZjK2r,cX2SpPxGLmADTKl,13,RRx0ri8bETI)
				A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = True
			elif 'series' in cX2SpPxGLmADTKl:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,11,RRx0ri8bETI)
				A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = True
			else:
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,12,RRx0ri8bETI)
				A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = True
	if A0DvrNp1LJuZObd2EeUg6kmtnWI4F8:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,GpwRnQ6q2o1fv0HbJTs in items:
			url = S7EgasGcYdIo + cX2SpPxGLmADTKl
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+GpwRnQ6q2o1fv0HbJTs,url,11)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'ALARAB-EPISODES-1st')
	EWxbCXeptzhYjgNTLQyI6s = AxTYMhRlfyskNc0X19dvwtS.findall('href="(/series.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nUDgc4absePT2xMt = S7EgasGcYdIo+EWxbCXeptzhYjgNTLQyI6s[0]
	Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(nUDgc4absePT2xMt)
	return
def QgIZSJdUhsEnup8GPz3(url):
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'ALARAB-PLAY-1st')
	nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('class="resp-iframe" src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if nUDgc4absePT2xMt:
		nUDgc4absePT2xMt = nUDgc4absePT2xMt[0]
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('^(http.*?)(http.*?)$',nUDgc4absePT2xMt,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if BA01W9olieErLycV7kwFvOhH5Y3ms:
			hKlkUJZEvLmeDXgO6Gs50MnYb = BA01W9olieErLycV7kwFvOhH5Y3ms[0][0]
			zkeEW04618nQOdhiAqmJPTF,oKSe7CjclnUmbO5psPDB0GVwdJ = BA01W9olieErLycV7kwFvOhH5Y3ms[0][1].rsplit('/',1)
			jYfvU9egTX62nrukVcoKEAyq = zkeEW04618nQOdhiAqmJPTF+'?named=__watch'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(jYfvU9egTX62nrukVcoKEAyq)
			sFi6cZKSANDM7H4xJXeuzVLo = hKlkUJZEvLmeDXgO6Gs50MnYb+oKSe7CjclnUmbO5psPDB0GVwdJ
		else:
			gwiPcfVU0T4qHMDF3Wdeh7YK = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,False,'ALARAB-PLAY-2nd')
			nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('"src": "(.*?)"',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if nUDgc4absePT2xMt:
				nUDgc4absePT2xMt = nUDgc4absePT2xMt[0]+'?named=__watch__m3u8'
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(nUDgc4absePT2xMt)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('searchBox(.*?)<style>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		nUDgc4absePT2xMt = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if nUDgc4absePT2xMt:
			nUDgc4absePT2xMt = nUDgc4absePT2xMt[0]+'?named=__watch'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(nUDgc4absePT2xMt)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def iobXKrS2eBv5():
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'ALARAB-RAMADAN-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('id="content_sec"(.*?)id="left_content"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	R0VaiXLuok6M3qeG = AxTYMhRlfyskNc0X19dvwtS.findall('/ramadan([0-9]+)/',str(items),AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	R0VaiXLuok6M3qeG = R0VaiXLuok6M3qeG[0]
	for cX2SpPxGLmADTKl,title in items:
		url = S7EgasGcYdIo+cX2SpPxGLmADTKl
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)+WRsuxHTjDgYCIpoMQzLFAtS8rikP+R0VaiXLuok6M3qeG
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,11)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo + "/q/" + ej9gRJkD6KGTcf
	Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return