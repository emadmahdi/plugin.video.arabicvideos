# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = ba49YvOK2Aw8Uhxt(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩ࿿")
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb,ggM5TzCxq24sDYLiEatpdSK7FQyGe=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if   t5fhagjUGXk0ynOlJWeAb==I6Bfzysrvb8DONZ(u"࠱ዦ"): SC63Xn9Ga4FI8pPy17zdu(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==KKCrwPdOgGl(u"࠳ዧ"): pass
	elif t5fhagjUGXk0ynOlJWeAb==Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵የ"): fzpSeMdBQ7n1vtuPcNsW509wF38YK(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==kAz7WRYjrfGm(u"࠷ዩ"): nwdejBvc8Ef9tY1SZiUhA5sLboa()
	elif t5fhagjUGXk0ynOlJWeAb==jBbkfIJSDqcVwl8irzy4Z3O(u"࠹ዪ"): s5sq1JQ3OFxZSMryd(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠻ያ"): kbNUaBAmfIl4T9s()
	elif t5fhagjUGXk0ynOlJWeAb==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠶ዬ"): h4IsToyVmPgDkulwdx01CiqY()
	elif t5fhagjUGXk0ynOlJWeAb==djapWhrveLJbgnViDftFNY05ylq1S(u"࠸ይ"): naz7pycbdu9WEDgX0Z1ltvf()
	elif t5fhagjUGXk0ynOlJWeAb==w9wfONXUP3(u"࠺ዮ"): JG6QHBLYfo73nF0UyclhpRjiOuW()
	elif t5fhagjUGXk0ynOlJWeAb==hWRvZOYtjme9QNnV41u0Mswb(u"࠴࠹࠵ዯ"): oO5NVaQWTdz9()
	elif t5fhagjUGXk0ynOlJWeAb==W2Vv30i8qxSuItfsolPLdFZA(u"࠵࠺࠷ደ"): X3otudCq9wISJBEsx6YQLANTRir()
	elif t5fhagjUGXk0ynOlJWeAb==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶࠻࠲ዱ"): CCR4Px8kqVecZgd50YDFU()
	elif t5fhagjUGXk0ynOlJWeAb==CCWqR3dmtzw6xoIX41(u"࠷࠵࠴ዲ"): JmvsGiKyS9RpTj8eV5aQxh2BIw4()
	elif t5fhagjUGXk0ynOlJWeAb==KKCrwPdOgGl(u"࠱࠶࠶ዳ"): p9cTq18YjWQZNy3I6402()
	elif t5fhagjUGXk0ynOlJWeAb==zWBnYSGIatjXVC(u"࠲࠷࠸ዴ"): SoOsrDuHnbY7qh5TWX1()
	elif t5fhagjUGXk0ynOlJWeAb==jBbkfIJSDqcVwl8irzy4Z3O(u"࠳࠸࠺ድ"): llh5NOLQfIViEU8kMZPmw6()
	elif t5fhagjUGXk0ynOlJWeAb==KKCrwPdOgGl(u"࠴࠹࠼ዶ"): RGp4fwdLkvnAQmr72()
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠵࠺࠾ዷ"): IY7HzyfhW0vjX5GmuicDRAwl()
	elif t5fhagjUGXk0ynOlJWeAb==f9fOpCmLAEaW2Go(u"࠶࠻࠹ዸ"): IIADQXp1H0TvsEVgzPLdo(NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==djapWhrveLJbgnViDftFNY05ylq1S(u"࠷࠷࠱ዹ"): W3Or7Nfyegk6c()
	elif t5fhagjUGXk0ynOlJWeAb==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠱࠸࠳ዺ"): gcXKzDTLlSdBHrfbsny42Rt9u()
	elif t5fhagjUGXk0ynOlJWeAb==GTmHXIZUSdxRhMnqQKkO(u"࠲࠹࠵ዻ"): TyL7XGl6Fob([ggM5TzCxq24sDYLiEatpdSK7FQyGe],NFGqKBLtvUZn1S3dau,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
	elif t5fhagjUGXk0ynOlJWeAb==Zb5cNeHWi6jP9SCYtUgR(u"࠳࠺࠷ዼ"): dJv9nZwNPYyes2zKA7rIX6Rgqp(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨက"),NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==KKCrwPdOgGl(u"࠴࠻࠹ዽ"): dJv9nZwNPYyes2zKA7rIX6Rgqp(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬခ"),NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==kAz7WRYjrfGm(u"࠵࠼࠻ዾ"): ppwshG2lgK4ZIzHPv()
	elif t5fhagjUGXk0ynOlJWeAb==nR0ok9zju84rFUQl1YC(u"࠶࠽࠶ዿ"): OBf9J6LoamUd()
	elif t5fhagjUGXk0ynOlJWeAb==djapWhrveLJbgnViDftFNY05ylq1S(u"࠷࠷࠸ጀ"): yqj9AnCzihaSX2(GTmHXIZUSdxRhMnqQKkO(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧဂ"))
	elif t5fhagjUGXk0ynOlJWeAb==ba49YvOK2Aw8Uhxt(u"࠱࠸࠻ጁ"): yqj9AnCzihaSX2(CCWqR3dmtzw6xoIX41(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫဃ"))
	elif t5fhagjUGXk0ynOlJWeAb==Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠲࠻࠳ጂ"): QQqLmWdsxBOfD0RrzgHIVcKEt6()
	elif t5fhagjUGXk0ynOlJWeAb==f9fOpCmLAEaW2Go(u"࠳࠼࠵ጃ"): kUpLljcBfxaAeFXTOZy8og()
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠴࠽࠷ጄ"): AroyRGVsiX9wL6ZSI8g()
	elif t5fhagjUGXk0ynOlJWeAb==YzlId3Fs6vpehcbLGj0UaO(u"࠵࠾࠹ጅ"): VhoimJvaUXG()
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠶࠿࠴ጆ"): VNbKriZyHpT()
	elif t5fhagjUGXk0ynOlJWeAb==hWRvZOYtjme9QNnV41u0Mswb(u"࠷࠹࠶ጇ"): XDWnbHKFYy1Cek8rivZ45TNuE()
	elif t5fhagjUGXk0ynOlJWeAb==djapWhrveLJbgnViDftFNY05ylq1S(u"࠱࠺࠸ገ"): HXfbOJogBCrGvuW8Rhm6p()
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠲࠻࠺ጉ"): EEvNP5XwaSAF()
	elif t5fhagjUGXk0ynOlJWeAb==vl6rwMLasAQo4z1ZjD3IBKtF(u"࠳࠼࠼ጊ"): LZwKMPETqrdc()
	elif t5fhagjUGXk0ynOlJWeAb==kAz7WRYjrfGm(u"࠴࠽࠾ጋ"): Idy1FWCfe3()
	elif t5fhagjUGXk0ynOlJWeAb==W2Vv30i8qxSuItfsolPLdFZA(u"࠷࠹࠶ጌ"): nnWYAuhzRd5qcxH3wSTlsQymCt(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠸࠺࠱ግ"): zvqGmc2eaBW7SorAONQiMfbUtx()
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠹࠴࠳ጎ"): ps3tErumNn()
	elif t5fhagjUGXk0ynOlJWeAb==Zb5cNeHWi6jP9SCYtUgR(u"࠳࠵࠵ጏ"): hioQNAUkBj9v0ExmyC1()
	elif t5fhagjUGXk0ynOlJWeAb==jBbkfIJSDqcVwl8irzy4Z3O(u"࠴࠶࠸ጐ"): Ywg1qsZ0hCB2ENGtXUkA5o()
	elif t5fhagjUGXk0ynOlJWeAb==awSUTRNMkdIW7sFEvnHD2mLY(u"࠵࠷࠺጑"): UUD5pvqGoagPbMdtyVjIi(pLwgjkuTs6CS)
	elif t5fhagjUGXk0ynOlJWeAb==rAYDiWlzm9MCU6x0GnROua(u"࠶࠸࠼ጒ"): HYh2mJEufvP1Okd4I8(NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠷࠹࠾ጓ"): kvAF9I5DGxuE3qZTazOSLJKy1Me6UR()
	elif t5fhagjUGXk0ynOlJWeAb==vl6rwMLasAQo4z1ZjD3IBKtF(u"࠸࠺࠹ጔ"): Q8Qr2h3sHpeE9JdCIF6j401AfZzWMw(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪင"),NFGqKBLtvUZn1S3dau,NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==W2Vv30i8qxSuItfsolPLdFZA(u"࠻࠰࠱ጕ"): WCM54XVYm3Bhat0lJFTybkRDqiv1r()
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠵࠱࠳጖"): uTtoqhSbCQNKwzsXMg2k()
	elif t5fhagjUGXk0ynOlJWeAb==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠶࠲࠵጗"): Y0rdWVaSwpi1U()
	elif t5fhagjUGXk0ynOlJWeAb==pbmKZA1w7L4zHjOM(u"࠷࠳࠷ጘ"): bx6AiCRucgDYqaW2pP1vtK(IZKily6gHndwh3qNe0TOfa1)
	elif t5fhagjUGXk0ynOlJWeAb==nR0ok9zju84rFUQl1YC(u"࠸࠴࠹ጙ"): bx6AiCRucgDYqaW2pP1vtK(ecXIT7UM4l0xYPFjGf3t)
	elif t5fhagjUGXk0ynOlJWeAb==nR0ok9zju84rFUQl1YC(u"࠹࠵࠻ጚ"): jHfP63VTMAeG8cELIbD5Jm0qyoQUgh()
	elif t5fhagjUGXk0ynOlJWeAb==W2Vv30i8qxSuItfsolPLdFZA(u"࠺࠶࠶ጛ"): ReBiOy1dYvpLJFI8G(NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==f9fOpCmLAEaW2Go(u"࠻࠰࠸ጜ"): rsSFOCoV7Uw8efb5R6JtmdcMLDyTp()
	elif t5fhagjUGXk0ynOlJWeAb==pYeVwat64v(u"࠵࠱࠺ጝ"): Lz0Qvycnh5luYojpmB9ON()
	elif t5fhagjUGXk0ynOlJWeAb==nR0ok9zju84rFUQl1YC(u"࠲࠲࠵࠴ጞ"): r3cbWk42NgQJHnYL()
	elif t5fhagjUGXk0ynOlJWeAb==zWBnYSGIatjXVC(u"࠳࠳࠶࠶ጟ"): fGmD8VcaRBbljQ0US1vxHoy2trTp()
	elif t5fhagjUGXk0ynOlJWeAb==I6Bfzysrvb8DONZ(u"࠴࠴࠷࠸ጠ"): yqj9AnCzihaSX2(hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫစ"))
	elif t5fhagjUGXk0ynOlJWeAb==zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵࠵࠸࠳ጡ"): gvOY5msHZLu9tQ672ArnMDK4C()
	elif t5fhagjUGXk0ynOlJWeAb==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠶࠶࠲࠵ጢ"): qQIC9TtU0E(NFGqKBLtvUZn1S3dau)
	elif t5fhagjUGXk0ynOlJWeAb==JZ45mOctiTszPNw1GVjxhep2Y(u"࠷࠰࠳࠷ጣ"): lI8mptEZgVHdbD2acLv0PTsu4A3xn()
	return
def qQIC9TtU0E(showDialogs=pLwgjkuTs6CS):
	SM5clvLdQHEGwy8q = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࡽࡾࠩဆ"))
	SM5clvLdQHEGwy8q = WWNb0XnUxOPL9gF.loads(SM5clvLdQHEGwy8q)[W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡴࡨࡷࡺࡲࡴࠨဇ")][vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࡹࡥࡱࡻࡥࠨဈ")]
	choice,iJ16wzZmsMKuCVnTNG4xdY0orcbLk = H3OKMjDG1evnl4Ruiz,SM5clvLdQHEGwy8q[:]
	if showDialogs:
		gQBOoaMYk4z2DclsZ985wHF = f9fOpCmLAEaW2Go(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ๊็ูๅหࠣ์ฯ฿ๅๅࠩဉ") if W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫည") in SM5clvLdQHEGwy8q else W2Vv30i8qxSuItfsolPLdFZA(u"๊่ࠬฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦๅห๊ๅๅฮ࠭ဋ")
		choice = uPS1UedvhXl6MHVbq7zr5Z92Tig(awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ဌ"),KKCrwPdOgGl(u"ࠧฯำ๋ะࠬဍ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨวํๆฬ็ࠧဎ"),CCWqR3dmtzw6xoIX41(u"ࠩอุ฿๐ไࠨဏ"),F91YEzyWak5,qFghPAi5yz9Vf3NLwo0nuprl+gQBOoaMYk4z2DclsZ985wHF+so4Z8OUJ5E+b8sk5WyPoz03pXhRx+b8sk5WyPoz03pXhRx+awSUTRNMkdIW7sFEvnHD2mLY(u"๋ࠪีํࠠศๆ๋฼๏็ษࠡฬึ้าࠦศศีอาิอๅࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆหࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะูๆๆࠣฬาัࠠโ์้ࠣํอโฺࠢส่อืๆศ็ฯࠤออำหะาห๊ࠦวๅๆ฽อࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ์ࠥะำหูํ฽ࠥษๆࠡฬๆฮอࠦัิษ็อ๊ࠥไๆสิ้ัࠦศศๆ็฾ฮࠦวๅ฻ิฬ๏ฯࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢฦ้ࠥห๊ใษไ๋ฬࠦฟࠢࠣࠪတ"))
	if choice==H3OKMjDG1evnl4Ruiz and djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫထ") not in SM5clvLdQHEGwy8q: iJ16wzZmsMKuCVnTNG4xdY0orcbLk = [GTmHXIZUSdxRhMnqQKkO(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬဒ")]+SM5clvLdQHEGwy8q
	elif choice==xD9WeoEAsX7 and nR0ok9zju84rFUQl1YC(u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡑࡘࡇࡕࡘ࡞࠭ဓ") in SM5clvLdQHEGwy8q:
		iJ16wzZmsMKuCVnTNG4xdY0orcbLk = SM5clvLdQHEGwy8q[:]
		iJ16wzZmsMKuCVnTNG4xdY0orcbLk.remove(GTmHXIZUSdxRhMnqQKkO(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡒ࡙ࡈࡖ࡙࡟ࠧန"))
	if iJ16wzZmsMKuCVnTNG4xdY0orcbLk!=SM5clvLdQHEGwy8q:
		iJ16wzZmsMKuCVnTNG4xdY0orcbLk = str(iJ16wzZmsMKuCVnTNG4xdY0orcbLk).replace(YzlId3Fs6vpehcbLGj0UaO(u"ࠣࠩࠥပ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩࠥࠫဖ"))
		Ubud2NhHKRnMTvI5mprQBVqk80 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡦࡥࡱ࡫࠮࡬ࡧࡼࡦࡴࡧࡲࡥ࡮ࡤࡽࡴࡻࡴࡴࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠬဗ")+iJ16wzZmsMKuCVnTNG4xdY0orcbLk+pL73X0MYajJQG4n1qgD(u"ࠫࢂࢃࠧဘ"))
		if showDialogs:
			if W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࡺࡲࡶࡧࠪမ") in str(Ubud2NhHKRnMTvI5mprQBVqk80): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pL73X0MYajJQG4n1qgD(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪယ"))
			else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,YzlId3Fs6vpehcbLGj0UaO(u"ࠧๅๆฦืๆࠦวๅ฻่่๏ฯࠠโึ็ฮࠬရ"))
	return
def gvOY5msHZLu9tQ672ArnMDK4C():
	ggeavOjMDpm3kITVN82hySo1 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(pYeVwat64v(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬလ"))
	message = nR0ok9zju84rFUQl1YC(u"ࠩส่ึ่ๅࠡษ็้าีฯࠡฯส่๏อ่๊ࠠࠣ࠾ࠥࠦࠠࠨဝ")+str(ggeavOjMDpm3kITVN82hySo1)+ba49YvOK2Aw8Uhxt(u"ࠪࠤࡰࡨࡰࡴࠩသ") if ggeavOjMDpm3kITVN82hySo1 else f9fOpCmLAEaW2Go(u"ࠫฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤ๊ะ่ใใฬࠤาอไ๋ษࠪဟ")
	message = qFghPAi5yz9Vf3NLwo0nuprl+message+nR0ok9zju84rFUQl1YC(u"ࠬࡢ࡮่ๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่ࠥษ่ࠡฬ฽๎๏ืࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫဠ")+so4Z8OUJ5E
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(w9wfONXUP3(u"࠭ࡣࡦࡰࡷࡩࡷ࠭အ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧฯำ๋ะࠬဢ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨวํๆฬ็ࠧဣ"),w9wfONXUP3(u"ࠩอุ฿๐ไࠨဤ"),F91YEzyWak5,message+pbmKZA1w7L4zHjOM(u"ࠪࡠࡳࡢ࡮ศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ่ࠠ์ࠣ฽๊๊๊สࠢํๆํ๋ࠠษ้สࠤฬ๊ศา่ส้ัࠦศศะอ๎ฬืࠠฤ฻็ํࠥา่ะห้ࠣฯ๎แาห่ࠣึ่ๅࠡษ็ะํีษࠡษ็ิ๏ࠦว็ฬࠣฮาีฯ่ࠢไ๎ࠥํะ่ࠢสู่อิสࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢ฼๊ิ๋วࠡฬๅ์๊ࠦว็ฬࠣฬฯฺฺ๋ๆࠣๅ๏ี๊้ࠢไห๋ࠦวๅสิ๊ฬ๋ฬࠡๆ้ࠤ๏ูรๅๅࠣ฽๋ࠦวๅฮ๋ำฮࠦวๅฬํࠤฯื๊ะ้สࠤ้ษๆࠡษ็ฬึ์วๆฮࠣืํ็๋ࠠะอหึࠦวๅฮ๋ำฮࠦร้ฬ๋้ฬะ๊ไ์สࠤ࠳࠴ฺࠠๆ่หࠥอๆ่ࠢํะอࠦวฯฬํหึࠦัใ็ࠣะํีษࠡื฽๎ึࠦลัษࠣ็ฬ์สࠡษ็ษ๋ะั็ฬࠣ฽๋ีใࠡสฺ๎หฯࠠฤ๊ࠣๆ้๐ไสࠩဥ"))
	if jwgM2qYVpdK5ly in [-KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠱ጤ"),I6Bfzysrvb8DONZ(u"࠱ጥ")]: return
	if jwgM2qYVpdK5ly==ba49YvOK2Aw8Uhxt(u"࠳ጦ"):
		ggeavOjMDpm3kITVN82hySo1 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"๋ࠫาอหࠢ฼้้๐ษࠡวํๆฬ็ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠧဦ"))
	else:
		items = [Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠸࠵࠱ࠢ࡮ࡦࡵࡹࠧဧ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨဨ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧ࠸࠷࠳ࠤࡰࡨࡰࡴࠩဩ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨ࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫဪ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩ࠴࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬါ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪ࠵࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ာ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠫ࠶࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧိ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬ࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨီ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭࠲࠶࠲࠳ࠤࡰࡨࡰࡴࠩု"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧ࠴࠲࠳࠴ࠥࡱࡢࡱࡵࠪူ"),pbmKZA1w7L4zHjOM(u"ࠨ࠵࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫေ"),CCWqR3dmtzw6xoIX41(u"ࠩ࠷࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬဲ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪ࠸࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ဳ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫ࠺࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧဴ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬ࠼࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨဵ"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠭࠷࠱࠲࠳ࠤࡰࡨࡰࡴࠩံ"),rAYDiWlzm9MCU6x0GnROua(u"ࠧ࠹࠲࠳࠴ࠥࡱࡢࡱࡵ့ࠪ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨ࠻࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫး"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩ࠴࠴࠵࠶࠰ࠡ࡭ࡥࡴࡸ္࠭"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪ࠵࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹ်ࠧ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫ࠶࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨျ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠬ࠿࠹࠺࠻࠼ࠤࡰࡨࡰࡴࠩြ")]
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(YzlId3Fs6vpehcbLGj0UaO(u"࠭วฯฬิࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤฬ๊ๅ็ษึฬฮ࠭ွ"),items)
		if qNmsBD1jJZVzcxi4onKuAOIC==-kAz7WRYjrfGm(u"࠴ጧ"): return
		ggeavOjMDpm3kITVN82hySo1 = str(items[qNmsBD1jJZVzcxi4onKuAOIC][:-vl6rwMLasAQo4z1ZjD3IBKtF(u"࠹ጨ")])
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKCrwPdOgGl(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣ์ฯำฯ๋ัࠣี็๋ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ࡜࡯࡞ࡱࠫှ")+qFghPAi5yz9Vf3NLwo0nuprl+ggeavOjMDpm3kITVN82hySo1+KKCrwPdOgGl(u"ࠨࠢ࡮ࡦࡵࡹࠧဿ")+so4Z8OUJ5E)
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭၀"),ggeavOjMDpm3kITVN82hySo1)
	return
def fGmD8VcaRBbljQ0US1vxHoy2trTp(gdRFZpso5jX4MAx0t2aLuiQ6ITKwr=pLwgjkuTs6CS):
	y2pD9zOcdsLGFJS = ccdRQGbtEaD2WSp()
	gQBOoaMYk4z2DclsZ985wHF = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪห้ะิ฻์็ࠤฬ๊ไศฯๅࠤ๏฿ๅๅࠩ၁") if y2pD9zOcdsLGFJS else pYeVwat64v(u"ࠫฬ๊สี฼ํ่ࠥอไๅษะๆ๋ࠥส้ไไࠫ၂")
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(I6Bfzysrvb8DONZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ၃"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭ฮา๊ฯࠫ၄"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧฦ์ๅหๆ࠭၅"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨฬื฾๏๊ࠧ၆"),F91YEzyWak5,qFghPAi5yz9Vf3NLwo0nuprl+gQBOoaMYk4z2DclsZ985wHF+so4Z8OUJ5E+b8sk5WyPoz03pXhRx+W2Vv30i8qxSuItfsolPLdFZA(u"๊ࠩิ์ࠦวๅ๊฻๎ๆฯࠠหฮ฼่้่ࠥะ์ࠣวํะ่ๆษอ๎่๐วࠡ์ๅ์๊ࠦศหึ฽๎้ࠦวๅใํำ๏๎ࠠศๆ็หา่ࠠ࠯࠰ࠣษ๊อࠠษ฻าࠤฬ์ส่ษฤࠤฬ๊แ๋ัํ์ࠥอไฮษ็๎ࠥฮรไ็็๋ࠥ࠴࠮ࠡล๋ࠤอ฿ฯࠡษ็๊็ืฺࠠๆ์ࠤืืࠠࠣฬฯหํุࠠฦๆ์ࠤฬ๊ไศฯๅࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥหไ฻ษฤࠤฬ๊สี฼ํ่ࠥอไๅษะๆࠥฮวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨล๋ไสๅࠥอไโ์า๎ํࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠศๆสืฯ็วะห้๋ࠣࠦส฻์ํีࠥะัห์หࠤ๊ำส้์สฮࠥอไใ๊สส๊ࠦ࠮࠯๋ࠢาฬ฻ษࠡฬิฮ๏ฮࠠฮๆๅหฯࠦวๅ็ึุ่๊วหࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆ๋ࠣีํࠠศๆ๋฼๏็ษࠡล่ࠤส๐โศใ๊หࠥลࠡࠢࠩ၇"))
	if jwgM2qYVpdK5ly==xD9WeoEAsX7: dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(nR0ok9zju84rFUQl1YC(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟ࡢࢃࡽࠨ၈"))
	elif jwgM2qYVpdK5ly==H3OKMjDG1evnl4Ruiz: dNoS1wQ9UD5F = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(w9wfONXUP3(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࡠ࠷࡝ࡾࡿࠪ၉"))
	if jwgM2qYVpdK5ly in [xD9WeoEAsX7,H3OKMjDG1evnl4Ruiz]:
		if MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࡺࡲࡶࡧࠪ၊") in str(dNoS1wQ9UD5F): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,Zb5cNeHWi6jP9SCYtUgR(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ။"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧๅๆฦืๆࠦวๅ฻่่๏ฯࠠโึ็ฮࠬ၌"))
	return
def r3cbWk42NgQJHnYL():
	url = drzqWFkSHD.SITESURLS[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡔࡈࡐࡊࡇࡓࡆࡕࠪ၍")][zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵ጩ")]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩࡊࡉ࡙࠭၎"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡏࡎࡔࡖࡄࡐࡑࡥࡏࡍࡆࡢࡖࡊࡒࡅࡂࡕࡈ࠱࠶ࡹࡴࠨ၏"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	AehPEBHmikb0MnWaDZwUGQo = AxTYMhRlfyskNc0X19dvwtS.findall(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠫࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰࠭ࡃ࠮࠴ࡺࡪࡲࠥࠫၐ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	AehPEBHmikb0MnWaDZwUGQo = sorted(AehPEBHmikb0MnWaDZwUGQo,reverse=NFGqKBLtvUZn1S3dau)
	qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc(lRKCWnNi0Edr984eI(u"ࠬอฮหำࠣห้หีะษิࠤฬ๊ะ๋ࠢอี๏ีࠠหอห๎ฯํࠧၑ"),AehPEBHmikb0MnWaDZwUGQo)
	if qNmsBD1jJZVzcxi4onKuAOIC>=bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶ጪ"):
		Es0iut3o1TVyApnzIF6 = url.rsplit(W2Vv30i8qxSuItfsolPLdFZA(u"࠭࠯ࠨၒ"),GTmHXIZUSdxRhMnqQKkO(u"࠱ጫ"))[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠱ጬ")]+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧ࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࠨၓ")+AehPEBHmikb0MnWaDZwUGQo[qNmsBD1jJZVzcxi4onKuAOIC]+hWRvZOYtjme9QNnV41u0Mswb(u"ࠨ࠰ࡽ࡭ࡵ࠭ၔ")
		succeeded = mVyYk8a2Mxzh7oWD15wBZ(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧၕ"),Es0iut3o1TVyApnzIF6,NFGqKBLtvUZn1S3dau)
		if succeeded:
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(f9fOpCmLAEaW2Go(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧၖ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,w9wfONXUP3(u"ࠫฯ๋ࠠหอห๎ฯࠦลึัสี่ࠥฯ๋็่้ࠣฮั็ษ่ะࠥ࠴࠮ࠡๆๆ๊ࠥฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡล๋ฮํ๋วห์ๆ๎ฬࠦศหฯา๎ะࠦฬๆ์฼ࠤฬ๊ศาษ่ะࠥฮวิฬัำฬ๋ࠠระิࠤส฻ฯศำ้ࠣฯ๎แาࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣ์ึวࠡษ็ฬึ์วๆฮࠣรࠦࠧࠧၗ"))
			if e6f0ycMuYQEJraNLInmip: Q8Qr2h3sHpeE9JdCIF6j401AfZzWMw(CCWqR3dmtzw6xoIX41(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၘ"),NFGqKBLtvUZn1S3dau,NFGqKBLtvUZn1S3dau)
	return
def rsSFOCoV7Uw8efb5R6JtmdcMLDyTp():
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,kAz7WRYjrfGm(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳ࠦ็ัษࠣห้๋ำฮࠢึ์ๆ๊ࠦิสหࠤฯำฯ๋อࠣๅํื๊ࠡๆฯ้๏฿ฺ้ࠠสสๆࠦวๅสิ๊ฬ๋ฬࠡษ็ฮ๏ࠦสฺฬ่ำࠥ฿ไ๊่ࠢีํื้ࠠไอࠤ๊฿๊็ࠩၙ"))
	if e6f0ycMuYQEJraNLInmip:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(pYeVwat64v(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬၚ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(zWBnYSGIatjXVC(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨၛ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(f9fOpCmLAEaW2Go(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ၜ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(ba49YvOK2Aw8Uhxt(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫၝ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(GTmHXIZUSdxRhMnqQKkO(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ၞ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,I6Bfzysrvb8DONZ(u"ࠬะๅࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๋ࠢืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮสฮัํฯࠥํะ่ࠢส่ส฿ฯศัสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠหฯา๎ะู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡษ็์็ะࠧၟ"))
		GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def jHfP63VTMAeG8cELIbD5Jm0qyoQUgh():
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,ba49YvOK2Aw8Uhxt(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫၠ"),KKCrwPdOgGl(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪၡ"))
	G4KvzuqjQEnsPBMUD = sG0tNwPH7EKlpz(pLwgjkuTs6CS)
	ln5IrWaAq8jHSo3YOX9iKdkBZFDw = b8sk5WyPoz03pXhRx
	RV0eWHMYuCftDQ2dG93OFrpx6 = oamlxBqLdu4ZM9nQrbIAhS5Pg7+ba49YvOK2Aw8Uhxt(u"ࠨࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤࠬၢ")+so4Z8OUJ5E
	PocAMrTi6faxubj98LZeDh32v = b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+rAYDiWlzm9MCU6x0GnROua(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ၣ")+so4Z8OUJ5E+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪࡠࡳࡢ࡮ࠨၤ")
	for id,AGJCrVUZnp6KR,PbxjEmhyO2ZvD3t6JiaCoAQGI5u,EZ0uzBhdVb4OelfRwr8CJ59y,bJNRP3CvQFxg4EYKs8q,reason in reversed(G4KvzuqjQEnsPBMUD):
		if id==KKCrwPdOgGl(u"ࠫ࠵࠭ၥ"):
			TTZqgQphtdsI9aKwrzXPCYUlvGk,CJ3td1TWg5a = EZ0uzBhdVb4OelfRwr8CJ59y.split(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡢ࡮࠼࠽ࠪၦ"))
			continue
		if ln5IrWaAq8jHSo3YOX9iKdkBZFDw!=b8sk5WyPoz03pXhRx: ln5IrWaAq8jHSo3YOX9iKdkBZFDw += PocAMrTi6faxubj98LZeDh32v
		jQxNuCVe4hzpObyKU = nR0ok9zju84rFUQl1YC(u"࡛࠭ࡓࡖࡏࡡࠬၧ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+id+ba49YvOK2Aw8Uhxt(u"ࠧࠡ࠼ࠣࠫၨ")+w9wfONXUP3(u"ࠨษ็ืษอไࠡ࠼ࠣࠫၩ")+so4Z8OUJ5E+PbxjEmhyO2ZvD3t6JiaCoAQGI5u
		VLRK8jaf4GxrIm2tN = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟ࠪၪ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+KKCrwPdOgGl(u"ࠪห้า่ศสࠣ࠾ࠥ࠭ၫ")+so4Z8OUJ5E+EZ0uzBhdVb4OelfRwr8CJ59y
		FJZlhomc1CP8GT6VQ = hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡠࡘࡔࡍ࡟ࠪၬ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬอไฯูฦࠤ࠿ࠦࠧၭ")+so4Z8OUJ5E+bJNRP3CvQFxg4EYKs8q
		EHaB0uwx2d4CfPrzbmZI6YL = kAz7WRYjrfGm(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧၮ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧศๆึฬอࠦ࠺ࠡࠩၯ")+so4Z8OUJ5E+reason
		ln5IrWaAq8jHSo3YOX9iKdkBZFDw += jQxNuCVe4hzpObyKU+VLRK8jaf4GxrIm2tN+b8sk5WyPoz03pXhRx+RV0eWHMYuCftDQ2dG93OFrpx6+b8sk5WyPoz03pXhRx+FJZlhomc1CP8GT6VQ+EHaB0uwx2d4CfPrzbmZI6YL+b8sk5WyPoz03pXhRx
	RsYWOkAC8t4iMUoBd0K(pYeVwat64v(u"ࠨࡴ࡬࡫࡭ࡺࠧၰ"),CJ3td1TWg5a,ln5IrWaAq8jHSo3YOX9iKdkBZFDw,pbmKZA1w7L4zHjOM(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪၱ"))
	return
def bx6AiCRucgDYqaW2pP1vtK(file):
	if file==ecXIT7UM4l0xYPFjGf3t: jjZJqbyEhdDpe = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪၲ")
	elif file==IZKily6gHndwh3qNe0TOfa1: jjZJqbyEhdDpe = zWBnYSGIatjXVC(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫၳ")
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(pL73X0MYajJQG4n1qgD(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၴ"),kAz7WRYjrfGm(u"࠭ๅิฯࠪၵ"),pbmKZA1w7L4zHjOM(u"ࠧฦื็หา࠭ၶ"),rAYDiWlzm9MCU6x0GnROua(u"ࠨะิ์ั࠭ၷ"),F91YEzyWak5,B1YMtuvRAGNlJOkC46VyPKQE(u"๊่ࠩࠥะั๋ัࠣษฺ๊วฮ่่ࠢๆࠦࠧၸ")+jjZJqbyEhdDpe+nR0ok9zju84rFUQl1YC(u"ࠪࠤศ๋ࠠหำํำ๋ࠥำฮࠢส่๊๊แࠡมࠪၹ"))
	if jwgM2qYVpdK5ly==GTmHXIZUSdxRhMnqQKkO(u"࠲ጭ"):
		if oNlez5gnM9x2B4.path.exists(file):
			try: oNlez5gnM9x2B4.remove(file)
			except: pass
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,GTmHXIZUSdxRhMnqQKkO(u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩၺ")+jjZJqbyEhdDpe)
	elif jwgM2qYVpdK5ly==nR0ok9zju84rFUQl1YC(u"࠴ጮ"):
		data = ApkBz5YUgSLJZF(file)
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pbmKZA1w7L4zHjOM(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬၻ")+jjZJqbyEhdDpe)
	return
def uTtoqhSbCQNKwzsXMg2k():
	if XqSerIMoFsRn2UQ1D5Alj6<jBbkfIJSDqcVwl8irzy4Z3O(u"࠵࠽ጯ"):
		mlrXUnyLzPAhEIj8ix5Ztpu = djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩၼ")+str(XqSerIMoFsRn2UQ1D5Alj6)+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨၽ")
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
		return
	rFuOmIeV4l6 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫၾ"))
	E2E9QlGMW6rmIRxnXka = RmBYtTu0ig6DbQM([lRKCWnNi0Edr984eI(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨၿ")])
	JNLmUCZ106hznryPMFOaB,JT1mi5qh4EfxoPlbHU0Qw6zs9k,jYwJH0SL5Ktlsne6xfbuMvNo,sw1G689Demd0LMErPZqF5p7,OIEBakzfoA6bLhiwMGvy0XQ4N,STrF53vQyfb,MQsOFAN7dGn2DxZ = E2E9QlGMW6rmIRxnXka[W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩႀ")]
	if JNLmUCZ106hznryPMFOaB or I6Bfzysrvb8DONZ(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪႁ") not in str(rFuOmIeV4l6):
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪႂ"))
		oo3n0EuaHjYSz = Y0rdWVaSwpi1U()
		if not oo3n0EuaHjYSz: return
	MMpnGExYJOhlQm1(NFGqKBLtvUZn1S3dau)
	return
def MMpnGExYJOhlQm1(showDialogs=NFGqKBLtvUZn1S3dau):
	rFuOmIeV4l6 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(kAz7WRYjrfGm(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩႃ"))
	if w9wfONXUP3(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ႄ") not in str(rFuOmIeV4l6):
		if showDialogs:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,GTmHXIZUSdxRhMnqQKkO(u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ႅ"))
		return
	cvxSn9KLEJC8Atq = oNlez5gnM9x2B4.path.join(nYqRaDM7QlmrEUKSAevsC,w9wfONXUP3(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩႆ"),CCWqR3dmtzw6xoIX41(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩႇ"),lRKCWnNi0Edr984eI(u"ࠫ࠼࠸࠰ࡱࠩႈ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭ႉ"))
	if not oNlez5gnM9x2B4.path.exists(cvxSn9KLEJC8Atq): return
	Gz2Hy3m8uAVS = open(cvxSn9KLEJC8Atq,Zb5cNeHWi6jP9SCYtUgR(u"࠭ࡲࡣࠩႊ")).read()
	if fOohwvakqi29cx0l3yt5mzrAGpEg: Gz2Hy3m8uAVS = Gz2Hy3m8uAVS.decode(RMGz7OiD1e30P)
	xBipVClStwo9ObHMkqFuf = AxTYMhRlfyskNc0X19dvwtS.findall(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧႋ"),Gz2Hy3m8uAVS,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GGhM8yOpSWl7oJb1cQN,jZvUi15aKPoT8V = xBipVClStwo9ObHMkqFuf[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	DDYLZeGBCp0af7ngTN4cO5x = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩႌ")+GGhM8yOpSWl7oJb1cQN+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࠯ႍࠫ")+jZvUi15aKPoT8V+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬႎ")
	if showDialogs:
		fdD3HEYkbUW0PlAQ1XRJ = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(I6Bfzysrvb8DONZ(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩႏ"))
		if fdD3HEYkbUW0PlAQ1XRJ==jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ႐"): n2wlM0qyIA48xhKQJaFOi5eoPG6k = djapWhrveLJbgnViDftFNY05ylq1S(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭႑")
		elif fdD3HEYkbUW0PlAQ1XRJ==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭႒"): n2wlM0qyIA48xhKQJaFOi5eoPG6k = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭႓")
		else: n2wlM0qyIA48xhKQJaFOi5eoPG6k = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩๅ์ฬฬๅࠡลัี๎࠭႔")
		jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(CCWqR3dmtzw6xoIX41(u"ࠪࡧࡪࡴࡴࡦࡴࠪ႕"),nR0ok9zju84rFUQl1YC(u"ࠫ็๎วว็ࠣวำื้ࠨ႖"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ႗"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭โ้ษษ้ࠥอไึ๊ิࠫ႘"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫ႙")+n2wlM0qyIA48xhKQJaFOi5eoPG6k,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣࠫႚ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+zWBnYSGIatjXVC(u"ࠩࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦ࠭ႛ")+so4Z8OUJ5E)
		if jwgM2qYVpdK5ly==nR0ok9zju84rFUQl1YC(u"࠶ጰ"): qqC0d7xsnVauHUQ8y = ba49YvOK2Aw8Uhxt(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ႜ")
		elif jwgM2qYVpdK5ly==awSUTRNMkdIW7sFEvnHD2mLY(u"࠸ጱ"): qqC0d7xsnVauHUQ8y = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪႝ")
		else: qqC0d7xsnVauHUQ8y = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else:
		fdD3HEYkbUW0PlAQ1XRJ = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(f9fOpCmLAEaW2Go(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ႞"))
		if   fdD3HEYkbUW0PlAQ1XRJ==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: jwgM2qYVpdK5ly = pbmKZA1w7L4zHjOM(u"࠰ጲ")
		elif fdD3HEYkbUW0PlAQ1XRJ==B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ႟"): jwgM2qYVpdK5ly = awSUTRNMkdIW7sFEvnHD2mLY(u"࠲ጳ")
		elif fdD3HEYkbUW0PlAQ1XRJ==f9fOpCmLAEaW2Go(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭Ⴀ"): jwgM2qYVpdK5ly = W2Vv30i8qxSuItfsolPLdFZA(u"࠴ጴ")
		qqC0d7xsnVauHUQ8y = fdD3HEYkbUW0PlAQ1XRJ
	if   jwgM2qYVpdK5ly==kAz7WRYjrfGm(u"࠳ጵ"): w1fuN2pY6tUi = I6Bfzysrvb8DONZ(u"ࠨ࠷࠸࠰࠺࠺࠴࠭࠷࠸࠹ࠬႡ")
	elif jwgM2qYVpdK5ly==w9wfONXUP3(u"࠵ጶ"): w1fuN2pY6tUi = GTmHXIZUSdxRhMnqQKkO(u"ࠩ࠸࠸࠹࠲࠵࠶࠷࠯࠹࠺࠭Ⴂ")
	elif jwgM2qYVpdK5ly==nR0ok9zju84rFUQl1YC(u"࠷ጷ"): w1fuN2pY6tUi = zWBnYSGIatjXVC(u"ࠪ࠹࠺࠻ࠬ࠶࠷࠯࠹࠹࠺ࠧႣ")
	else: return
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(CCWqR3dmtzw6xoIX41(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩႤ"),qqC0d7xsnVauHUQ8y)
	PZVuJyN9FUvwMfGC = hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭Ⴅ")+w1fuN2pY6tUi+vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࠬࠨႦ")+jZvUi15aKPoT8V+zWBnYSGIatjXVC(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩႧ")
	ripQKLJC6xTUmc4HM7zf0P = Gz2Hy3m8uAVS.replace(DDYLZeGBCp0af7ngTN4cO5x,PZVuJyN9FUvwMfGC)
	if fOohwvakqi29cx0l3yt5mzrAGpEg: ripQKLJC6xTUmc4HM7zf0P = ripQKLJC6xTUmc4HM7zf0P.encode(RMGz7OiD1e30P)
	open(cvxSn9KLEJC8Atq,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡹࡥࠫႨ")).write(ripQKLJC6xTUmc4HM7zf0P)
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,lRKCWnNi0Edr984eI(u"ࠩ࠱ࡠࡹ࡙࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧႩ")+w1fuN2pY6tUi+CCWqR3dmtzw6xoIX41(u"ࠪࠤࡢ࠭Ⴊ"))
	if showDialogs: mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(CCWqR3dmtzw6xoIX41(u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪႫ"))
	return
def WCM54XVYm3Bhat0lJFTybkRDqiv1r():
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪႬ"))
	if e6f0ycMuYQEJraNLInmip==GTmHXIZUSdxRhMnqQKkO(u"࠷ጸ"): naz7pycbdu9WEDgX0Z1ltvf()
	return
def JG6QHBLYfo73nF0UyclhpRjiOuW():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩႭ"))
	return
def kvAF9I5DGxuE3qZTazOSLJKy1Me6UR():
	jQxNuCVe4hzpObyKU = oamlxBqLdu4ZM9nQrbIAhS5Pg7+GTmHXIZUSdxRhMnqQKkO(u"ࠧห฻าหิࠦิ๋฻ฬࠤว๊ࠠๆฯ่ำ๊ࠥำ็หࠣ࠶࠵࠸࠱ࠡ࠼ࠣࠫႮ")+so4Z8OUJ5E
	jQxNuCVe4hzpObyKU += Zb5cNeHWi6jP9SCYtUgR(u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧႯ")
	jQxNuCVe4hzpObyKU += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+zWBnYSGIatjXVC(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺࠧႰ")+so4Z8OUJ5E
	VLRK8jaf4GxrIm2tN = oamlxBqLdu4ZM9nQrbIAhS5Pg7+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪฬึ์วๆฮุࠣึ๐ืࠡษ็ุ้๊ๅࠡ࠼ࠣࠫႱ")+so4Z8OUJ5E
	VLRK8jaf4GxrIm2tN += JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨႲ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࠬႳ")+so4Z8OUJ5E
	mlrXUnyLzPAhEIj8ix5Ztpu = f9fOpCmLAEaW2Go(u"࡛࠭ࡓࡖࡏࡡࠬႴ")+jQxNuCVe4hzpObyKU+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬႵ")+VLRK8jaf4GxrIm2tN
	RsYWOkAC8t4iMUoBd0K(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡴ࡬࡫࡭ࡺࠧႶ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def UUD5pvqGoagPbMdtyVjIi(xtGwLN4faz1n0IA8kJUWyj):
	ZrQ1ou8I57L2EG9jwgiT3PY(RFowY7JrTPs8c5m02ydD1VgbeBup3N)
	G4KvzuqjQEnsPBMUD = sG0tNwPH7EKlpz(xtGwLN4faz1n0IA8kJUWyj)
	for W54GnOZLmrA in [pbmKZA1w7L4zHjOM(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫႷ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭Ⴘ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩႹ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࡠࡖࡖࠫႺ")]:
		if W54GnOZLmrA in drzqWFkSHD.SEND_THESE_EVENTS: drzqWFkSHD.SEND_THESE_EVENTS.remove(W54GnOZLmrA)
	p71RVmeQ3ud0ENcITXY4KbxZ6AOFya(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡄࡐࡐࡄࡘࡎࡕࡎࡔࠩႻ"))
	id,AGJCrVUZnp6KR,PbxjEmhyO2ZvD3t6JiaCoAQGI5u,EZ0uzBhdVb4OelfRwr8CJ59y,bJNRP3CvQFxg4EYKs8q,reason = G4KvzuqjQEnsPBMUD[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	TTZqgQphtdsI9aKwrzXPCYUlvGk,CJ3td1TWg5a = EZ0uzBhdVb4OelfRwr8CJ59y.split(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧ࡝ࡰ࠾࠿ࠬႼ"))
	VLRK8jaf4GxrIm2tN,FJZlhomc1CP8GT6VQ,EHaB0uwx2d4CfPrzbmZI6YL = bJNRP3CvQFxg4EYKs8q.split(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨ࡞ࡱ࠿ࡀ࠭Ⴝ"))
	y4KQeDZIn6P0dWOMAgi1Ybr = NFGqKBLtvUZn1S3dau
	while y4KQeDZIn6P0dWOMAgi1Ybr:
		EdfbDelgUsLyAxF4J9wP = uPS1UedvhXl6MHVbq7zr5Z92Tig(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩัีําࠧႾ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩႿ"),w9wfONXUP3(u"ࠫ็อฦๆหࠣห้ะศา฻สฮࠬჀ"),JZ45mOctiTszPNw1GVjxhep2Y(u"๊ࠬล๋ไสๅࠥอไฦ฻็ห๋อสࠡ࠼ࠣࠤฯฮัฺࠢฦ์ࠥอๅิฯࠣห้ฮั็ษ่ะࠬჁ"),VLRK8jaf4GxrIm2tN)
		if EdfbDelgUsLyAxF4J9wP==JZ45mOctiTszPNw1GVjxhep2Y(u"࠲ጹ"): fxhS9DijUkB47aZoIwX1Tser = uPS1UedvhXl6MHVbq7zr5Z92Tig(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ู้࠭ัฬࠫჂ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"ࠧๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧჃ"),FJZlhomc1CP8GT6VQ,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬჄ"))
		elif EdfbDelgUsLyAxF4J9wP==slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠲ጺ"): fzpSeMdBQ7n1vtuPcNsW509wF38YK()
		else: y4KQeDZIn6P0dWOMAgi1Ybr = pLwgjkuTs6CS
	if xtGwLN4faz1n0IA8kJUWyj: GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def Ywg1qsZ0hCB2ENGtXUkA5o():
	QQqLmWdsxBOfD0RrzgHIVcKEt6()
	KiJOpXeMVH0hUBoNIn1zR6jtrDaq = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨჅ"))
	mlrXUnyLzPAhEIj8ix5Ztpu = {}
	mlrXUnyLzPAhEIj8ix5Ztpu[lRKCWnNi0Edr984eI(u"ࠪࡅ࡚࡚ࡏࠨ჆")] = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪჇ")
	mlrXUnyLzPAhEIj8ix5Ztpu[GTmHXIZUSdxRhMnqQKkO(u"࡙ࠬࡔࡐࡒࠪ჈")] = zWBnYSGIatjXVC(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ჉")
	mlrXUnyLzPAhEIj8ix5Ztpu[hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ჊")] = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩ჋")+str(XElcjkopwbuRJtK7I3Y/pL73X0MYajJQG4n1qgD(u"࠸࠳ጻ"))+pYeVwat64v(u"ࠩࠣำ็๐โสࠢไๆ฼࠭჌")
	AmJoMeHFg8ckl1Z9063rUCwuy = mlrXUnyLzPAhEIj8ix5Ztpu[KiJOpXeMVH0hUBoNIn1zR6jtrDaq]
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪ็ฬฺࠠࠨჍ")+str(XElcjkopwbuRJtK7I3Y/fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠹࠴ጼ"))+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࠥีโ๋ไฬࠫ჎"),kAz7WRYjrfGm(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ჏"),W2Vv30i8qxSuItfsolPLdFZA(u"࠭ล๋ไสๅ้ࠥวๆๆࠪა"),AmJoMeHFg8ckl1Z9063rUCwuy,jBbkfIJSDqcVwl8irzy4Z3O(u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪბ"))
	if jwgM2qYVpdK5ly==GTmHXIZUSdxRhMnqQKkO(u"࠴ጽ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = pYeVwat64v(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩგ")
	elif jwgM2qYVpdK5ly==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠶ጾ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡄ࡙࡙ࡕࠧდ")
	elif jwgM2qYVpdK5ly==awSUTRNMkdIW7sFEvnHD2mLY(u"࠸ጿ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡗ࡙ࡕࡐࠨე")
	else: zp5TASaJ6cUV8Y0EboBZlme7RrnwO = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if zp5TASaJ6cUV8Y0EboBZlme7RrnwO:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪვ"),zp5TASaJ6cUV8Y0EboBZlme7RrnwO)
		YISuZcgJVkMvC65PHeN0yFG = mlrXUnyLzPAhEIj8ix5Ztpu[zp5TASaJ6cUV8Y0EboBZlme7RrnwO]
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YISuZcgJVkMvC65PHeN0yFG)
	return
def hioQNAUkBj9v0ExmyC1():
	mlrXUnyLzPAhEIj8ix5Ztpu = {}
	mlrXUnyLzPAhEIj8ix5Ztpu[ba49YvOK2Aw8Uhxt(u"ࠬࡇࡕࡕࡑࠪზ")] = rAYDiWlzm9MCU6x0GnROua(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢส่ฯ๊โศศํࠤ๏฿ๅๅ࠼ࠣࠫთ")
	mlrXUnyLzPAhEIj8ix5Ztpu[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࡂࡕࡎࠫი")] = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨีํีๆืࠠࡅࡐࡖࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้࠽ࠤࠬკ")
	mlrXUnyLzPAhEIj8ix5Ztpu[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡖࡘࡔࡖࠧლ")] = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪื๏ืแาࠢࡇࡒࡘࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭მ")
	LCxAhNB7l2kd = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(nR0ok9zju84rFUQl1YC(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫნ"))
	KiJOpXeMVH0hUBoNIn1zR6jtrDaq = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨო"))
	AmJoMeHFg8ckl1Z9063rUCwuy = mlrXUnyLzPAhEIj8ix5Ztpu[KiJOpXeMVH0hUBoNIn1zR6jtrDaq]+LCxAhNB7l2kd
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫპ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ჟ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠨวํๆฬ็ࠠไษ่่ࠬრ"),AmJoMeHFg8ckl1Z9063rUCwuy,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭ს"))
	if jwgM2qYVpdK5ly==YzlId3Fs6vpehcbLGj0UaO(u"࠰ፀ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪࡅࡘࡑࠧტ")
	elif jwgM2qYVpdK5ly==jBbkfIJSDqcVwl8irzy4Z3O(u"࠲ፁ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = I6Bfzysrvb8DONZ(u"ࠫࡆ࡛ࡔࡐࠩუ")
	elif jwgM2qYVpdK5ly==zWBnYSGIatjXVC(u"࠴ፂ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = pYeVwat64v(u"࡙ࠬࡔࡐࡒࠪფ")
	if jwgM2qYVpdK5ly in [rAYDiWlzm9MCU6x0GnROua(u"࠴ፄ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠴ፃ")]:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(nR0ok9zju84rFUQl1YC(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ქ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠧิ์ิๅึࡀࠠࠨღ")+drzqWFkSHD.DNS_SERVERS[xD9WeoEAsX7],awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨีํีๆื࠺ࠡࠩყ")+drzqWFkSHD.DNS_SERVERS[nUaVQsoA6EXcK4Odht5wCge0J8Pib],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨშ"))
		if e6f0ycMuYQEJraNLInmip==B1YMtuvRAGNlJOkC46VyPKQE(u"࠶ፅ"): zY1RHcGS59q7WMUoN2tsyuDirJp = drzqWFkSHD.DNS_SERVERS[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		else: zY1RHcGS59q7WMUoN2tsyuDirJp = drzqWFkSHD.DNS_SERVERS[xD9WeoEAsX7]
	elif jwgM2qYVpdK5ly==W2Vv30i8qxSuItfsolPLdFZA(u"࠸ፆ"): zY1RHcGS59q7WMUoN2tsyuDirJp = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: zp5TASaJ6cUV8Y0EboBZlme7RrnwO = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if zp5TASaJ6cUV8Y0EboBZlme7RrnwO:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(ba49YvOK2Aw8Uhxt(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ჩ"),zp5TASaJ6cUV8Y0EboBZlme7RrnwO)
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(nR0ok9zju84rFUQl1YC(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫც"),zY1RHcGS59q7WMUoN2tsyuDirJp)
		YISuZcgJVkMvC65PHeN0yFG = mlrXUnyLzPAhEIj8ix5Ztpu[zp5TASaJ6cUV8Y0EboBZlme7RrnwO]+zY1RHcGS59q7WMUoN2tsyuDirJp
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YISuZcgJVkMvC65PHeN0yFG)
	return
def ps3tErumNn():
	KiJOpXeMVH0hUBoNIn1zR6jtrDaq = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪძ"))
	mlrXUnyLzPAhEIj8ix5Ztpu = {}
	mlrXUnyLzPAhEIj8ix5Ztpu[djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡁࡖࡖࡒࠫწ")] = rAYDiWlzm9MCU6x0GnROua(u"ࠧศๆหีํ้ำ๋ࠢส่ฯ๊โศศํࠤัอ็ำࠢ็่฾๋ไࠨჭ")
	mlrXUnyLzPAhEIj8ix5Ztpu[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡃࡖࡏࠬხ")] = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩส่อื่ไีํࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้ࠪჯ")
	mlrXUnyLzPAhEIj8ix5Ztpu[kAz7WRYjrfGm(u"ࠪࡗ࡙ࡕࡐࠨჰ")] = KKCrwPdOgGl(u"ࠫฬ๊ศา๊ๆื๏ࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭ჱ")
	AmJoMeHFg8ckl1Z9063rUCwuy = mlrXUnyLzPAhEIj8ix5Ztpu[KiJOpXeMVH0hUBoNIn1zR6jtrDaq]
	jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪჲ"),pYeVwat64v(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬჳ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧฦ์ๅหๆࠦใศ็็ࠫჴ"),AmJoMeHFg8ckl1Z9063rUCwuy,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫჵ"))
	if jwgM2qYVpdK5ly==pL73X0MYajJQG4n1qgD(u"࠰ፇ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = ba49YvOK2Aw8Uhxt(u"ࠩࡄࡗࡐ࠭ჶ")
	elif jwgM2qYVpdK5ly==Zb5cNeHWi6jP9SCYtUgR(u"࠲ፈ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = nR0ok9zju84rFUQl1YC(u"ࠪࡅ࡚࡚ࡏࠨჷ")
	elif jwgM2qYVpdK5ly==zWBnYSGIatjXVC(u"࠴ፉ"): zp5TASaJ6cUV8Y0EboBZlme7RrnwO = pYeVwat64v(u"ࠫࡘ࡚ࡏࡑࠩჸ")
	else: zp5TASaJ6cUV8Y0EboBZlme7RrnwO = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if zp5TASaJ6cUV8Y0EboBZlme7RrnwO:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪჹ"),zp5TASaJ6cUV8Y0EboBZlme7RrnwO)
		YISuZcgJVkMvC65PHeN0yFG = mlrXUnyLzPAhEIj8ix5Ztpu[zp5TASaJ6cUV8Y0EboBZlme7RrnwO]
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YISuZcgJVkMvC65PHeN0yFG)
	return
def Lz0Qvycnh5luYojpmB9ON():
	d0yxHsSjKV7oaG = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(nR0ok9zju84rFUQl1YC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ჺ"))
	if d0yxHsSjKV7oaG==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡔࡖࡒࡔࠬ჻"): header = awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧჼ")
	else: header = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧჽ")
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪษ๏่วโࠩჾ"),nR0ok9zju84rFUQl1YC(u"ࠫฯ็ู๋ๆࠪჿ"),header,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"่่ࠬศศ่ࠤฬ๊ศา่ส้ั๊ࠦห็ࠣฮาี๊ฬ้สࠤศ๎ส้็สฮ๏้๊ศࠢห฽ิࠦ࠱࠷ࠢึห฾ฯࠠๆ่ࠣวํ๊ࠠฤีอาิอๅࠡ࠰࠱ࠤํห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠤ๏สฯ๋ࠢศ่๎ࠦสฮัํฯ์อࠠโ์ࠣ็้ࠦๅาหࠣ๎ฯ๋ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎็ัษࠣ๎ุฮศࠡสฺสࠥ็๊ࠡใอั่่ࠥศศ่ࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩᄀ"))
	if e6f0ycMuYQEJraNLInmip==-zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠴ፊ"): return
	elif e6f0ycMuYQEJraNLInmip:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ᄁ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡂࡗࡗࡓࠬᄂ"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,rAYDiWlzm9MCU6x0GnROua(u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪᄃ"))
	else:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩᄄ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡗ࡙ࡕࡐࠨᄅ"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭ᄆ"))
	return
def lI8mptEZgVHdbD2acLv0PTsu4A3xn():
	BBwXAkemFLgTan7ZRlCz61ydipWK85 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(KKCrwPdOgGl(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡷࡦࡤࡦࡥࡨ࡮ࡥࠨᄇ"))
	if BBwXAkemFLgTan7ZRlCz61ydipWK85==vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࡓࡕࡑࡓࠫᄈ"): header = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็ษ๋ะั็ฬ้ࠣฯ๎โโࠩᄉ")
	else: header = pL73X0MYajJQG4n1qgD(u"ࠨฮ็ฬࠥอไใ๊สส๊ࠦๅ็ࠢส่ส์สา่อࠤ๊็ูๅࠩᄊ")
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"ࠩศ๎็อแࠨᄋ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪฮๆ฿๊ๅࠩᄌ"),header,ba49YvOK2Aw8Uhxt(u"ࠫ็๎วว็ࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡัหฺฯࠠศๆ่ัั๎ศส่้่ࠢ์ࠠหะี๎๋ํวࠡใํࠤฬ๊ล็ฬิ๊ฯࠦแ๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊้ࠦฮาࠤๆ๐็ศุ่่๊ࠢษࠡฯฯฬࠥ࠴࠮้ࠡำ๋ࠥอไุำํๆฮࠦสิษ฼ำࠥ็๊ࠡไิหฦฯ้ࠠษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ออ๊หอ๊ࠥใ็่๊๋่ࠢࠥใ฻ࠣฬิ๐ไࠡ็อ์ๆื้ࠠ฼ํี๋ࠥออ๊หࠤࡡࡴ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦฬๅสࠣห้่่ศศ่ࠤ๊์ࠠศๆศ๊ฯืๆหࠢยࠥࠦ࠭ᄍ"))
	if e6f0ycMuYQEJraNLInmip==-awSUTRNMkdIW7sFEvnHD2mLY(u"࠵ፋ"): return
	elif e6f0ycMuYQEJraNLInmip:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡷࡦࡤࡦࡥࡨ࡮ࡥࠨᄎ"),CCWqR3dmtzw6xoIX41(u"࠭ࡁࡖࡖࡒࠫᄏ"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,nR0ok9zju84rFUQl1YC(u"ࠧห็ࠣฮๆ฿๊ๅࠢฯ่อࠦวๅไ๋หห๋ࠠๆ่ࠣห้๎๊ษࠩᄐ"))
	else:
		xeI7QzBgGEXN8ftCawRpO24nDh.setSetting(Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡺࡩࡧࡩࡡࡤࡪࡨࠫᄑ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡖࡘࡔࡖࠧᄒ"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKCrwPdOgGl(u"ࠪฮ๊ࠦล๋ไสๅࠥาไษࠢส่็๎วว็้๋ࠣࠦวๅ๊ํฬࠬᄓ"))
	return
def SC63Xn9Ga4FI8pPy17zdu(ggM5TzCxq24sDYLiEatpdSK7FQyGe):
	if ggM5TzCxq24sDYLiEatpdSK7FQyGe!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
		ggM5TzCxq24sDYLiEatpdSK7FQyGe = X1gWZ9KMSF6jxE2Vsv(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
		ggM5TzCxq24sDYLiEatpdSK7FQyGe = ggM5TzCxq24sDYLiEatpdSK7FQyGe.decode(RMGz7OiD1e30P).encode(RMGz7OiD1e30P)
		jHlVEeTIoi9CQa4 = CCWqR3dmtzw6xoIX41(u"࠶࠶࠱࠱࠵ፌ")
		PHdfx5e6BjKlzFqGUJa1LEi = vRVl0MpXZDwAYB4ag68nc.Window(jHlVEeTIoi9CQa4)
		PHdfx5e6BjKlzFqGUJa1LEi.getControl(GTmHXIZUSdxRhMnqQKkO(u"࠹࠱࠲ፍ")).setLabel(ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	return
lHkIcr8yK5 = [
			 GTmHXIZUSdxRhMnqQKkO(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤᄔ")
			,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨᄕ")
			,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨᄖ")
			,Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩᄗ")
			,zWBnYSGIatjXVC(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩᄘ")
			,w9wfONXUP3(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫᄙ")
			,hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩᄚ")+lRKCWnNi0Edr984eI(u"ࠫࠨ࠭ᄛ")+pYeVwat64v(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫᄜ")
			,djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩᄝ")
			,pbmKZA1w7L4zHjOM(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪᄞ")
			,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩᄟ")
			,pbmKZA1w7L4zHjOM(u"ࠩࡡࡢࡣࡤ࡞ࠨᄠ")
			,KKCrwPdOgGl(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨᄡ")
			,CCWqR3dmtzw6xoIX41(u"ࠫࡱࡧࡲࡨࡧࠣࡥࡺࡪࡩࡰࠢࡶࡽࡳࡩࠠࡦࡴࡵࡳࡷࡀࠧᄢ")
			,CCWqR3dmtzw6xoIX41(u"ࠬ࡯࡮ࡧࡱ࠽ࠤࡒ࡫ࡤࡪࡣࡦࡳࡩ࡫ࡣࠡࡦࡨࡧࡴࡪࡥࡳ࠼ࠪᄣ")
			]
def lIdJ9CtOP5xBgS6b(bkhQVre594UyJ):
	if B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫᄤ") in bkhQVre594UyJ and MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᄥ") in bkhQVre594UyJ: return NFGqKBLtvUZn1S3dau
	for ggM5TzCxq24sDYLiEatpdSK7FQyGe in lHkIcr8yK5:
		if ggM5TzCxq24sDYLiEatpdSK7FQyGe in bkhQVre594UyJ: return NFGqKBLtvUZn1S3dau
	return pLwgjkuTs6CS
def l8sCrLqQ3jdN(data):
	DIdypu9U1TE24ZRBJvzYAKs = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠸ፏ") if fOohwvakqi29cx0l3yt5mzrAGpEg else MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠱࠶ፎ")
	data = data.replace(pbmKZA1w7L4zHjOM(u"࠵࠳ፐ")*WRsuxHTjDgYCIpoMQzLFAtS8rikP,DIdypu9U1TE24ZRBJvzYAKs*WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	data = data.replace(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࠢ࠿࡫ࡪࡴࡥࡳࡣ࡯ࡂ࠿ࠦࠧᄦ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࠽ࠤࠬᄧ"))
	bo9ixEyvnlwmW = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for bkhQVre594UyJ in data.splitlines():
		jmQKTgP8l2Xbohk = AxTYMhRlfyskNc0X19dvwtS.findall(zWBnYSGIatjXVC(u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩᄨ"),bkhQVre594UyJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if jmQKTgP8l2Xbohk: bkhQVre594UyJ = bkhQVre594UyJ.replace(jmQKTgP8l2Xbohk[nUaVQsoA6EXcK4Odht5wCge0J8Pib],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		bo9ixEyvnlwmW += b8sk5WyPoz03pXhRx+bkhQVre594UyJ
	return bo9ixEyvnlwmW
def nnWYAuhzRd5qcxH3wSTlsQymCt(N4xrzmIvwPbnXUV9QhKCluYgZ5):
	if hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡔࡒࡄࠨᄩ") in N4xrzmIvwPbnXUV9QhKCluYgZ5:
		afhBzXs4JeO38HnGmKt1kWvuAQC = LwFGz5ZiSvs60a
		header = kAz7WRYjrfGm(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣรࠬᄪ")
	else:
		afhBzXs4JeO38HnGmKt1kWvuAQC = bHYSILv5x4mrnCuKVZt6XzfFGgR8j
		header = pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭ᄫ")
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,header,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๐อห๊ํࠤศ๐ึศࠢ฼่๎ࠦำอๆࠣห้อำหะาห๊ࠦ࠮๊ࠡส่ฬัๆฺ๋่ࠣึ๎ั๋ห่๊ࠣ฿ัโหࠣ็๏็ࠠฮัฮฮࠥอไๆึๆ่ฮ่ࠦๆษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅาํࠤุฮศࠡฯา์ะࠦวๅ็ื็้ฯࠠ࠯ࠢๆ์ิ๐๋ࠠฯอๅ฽ࠦศิฮ็๎๋ࠦ࠮ࠡษ็วํ๊่๊ࠠࠣหู้ฬๅࠢส่าอไ๋๋ࠢๅ๏ํࠠๆ฻็์๊อสࠡฬหำศࠦๅ็าࠣฬิอ๊สࠢส่ฯฺฺ๋ๆࠣห้ำวๅ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋ࠢห้๏ࠠศๆล๊ࠥ࠴ࠠฤ็สࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣๅ์๎ࠠศๆึะ้ࠦวๅีสฬ็ࠦวๅาํࠤฯ๋ࠠอ็฼๋๋ࠥๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦโษๆࠣฦำืࠠฦูไหฦࠦไ่ࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪᄬ"))
	if e6f0ycMuYQEJraNLInmip!=f9fOpCmLAEaW2Go(u"࠴ፑ"): return
	EaR4AyMqFtjx2vmbSHDIU3fG,aINuxABv6tbikfO4dzL = [],JZ45mOctiTszPNw1GVjxhep2Y(u"࠴ፒ")
	size,count = yxjuaUT04zJF(afhBzXs4JeO38HnGmKt1kWvuAQC)
	file = open(afhBzXs4JeO38HnGmKt1kWvuAQC,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨࡴࡥࠫᄭ"))
	if size>MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠷࠰࠱࠴࠳࠴ፔ"): file.seek(-pL73X0MYajJQG4n1qgD(u"࠶࠶࠰࠲࠲࠳ፓ"),oNlez5gnM9x2B4.SEEK_END)
	data = file.read()
	file.close()
	if fOohwvakqi29cx0l3yt5mzrAGpEg: data = data.decode(RMGz7OiD1e30P)
	data = l8sCrLqQ3jdN(data)
	FGgCZybURVmONe7sXtL4xj2M = data.split(b8sk5WyPoz03pXhRx)
	for bkhQVre594UyJ in reversed(FGgCZybURVmONe7sXtL4xj2M):
		ND7BqtPJjuhQkLIYi8a5wKc = lIdJ9CtOP5xBgS6b(bkhQVre594UyJ)
		if ND7BqtPJjuhQkLIYi8a5wKc: continue
		bkhQVre594UyJ = bkhQVre594UyJ.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡢࠫᄮ"),oamlxBqLdu4ZM9nQrbIAhS5Pg7+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᄯ")+so4Z8OUJ5E)
		bkhQVre594UyJ = bkhQVre594UyJ.replace(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫᄰ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈ࠳࠴࠵࠶࡝ࠨᄱ")+I6Bfzysrvb8DONZ(u"࠭ࡅࡓࡔࡒࡖ࠿࠭ᄲ")+so4Z8OUJ5E)
		iaU03elP7bLNrMZtHq8v5ws = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		eeJ0DCyRVaZnW1OHlUfGp = AxTYMhRlfyskNc0X19dvwtS.findall(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧᄳ"),bkhQVre594UyJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if eeJ0DCyRVaZnW1OHlUfGp:
			bkhQVre594UyJ = bkhQVre594UyJ.replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib],eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]).replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][H3OKMjDG1evnl4Ruiz],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			iaU03elP7bLNrMZtHq8v5ws = eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]
		else:
			eeJ0DCyRVaZnW1OHlUfGp = AxTYMhRlfyskNc0X19dvwtS.findall(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨᄴ"),bkhQVre594UyJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if eeJ0DCyRVaZnW1OHlUfGp:
				bkhQVre594UyJ = bkhQVre594UyJ.replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				iaU03elP7bLNrMZtHq8v5ws = eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		if iaU03elP7bLNrMZtHq8v5ws: bkhQVre594UyJ = bkhQVre594UyJ.replace(iaU03elP7bLNrMZtHq8v5ws,qFghPAi5yz9Vf3NLwo0nuprl+iaU03elP7bLNrMZtHq8v5ws+so4Z8OUJ5E)
		EaR4AyMqFtjx2vmbSHDIU3fG.append(bkhQVre594UyJ)
		if len(str(EaR4AyMqFtjx2vmbSHDIU3fG))>zWBnYSGIatjXVC(u"࠵࠱࠳࠳࠴ፕ"): break
	EaR4AyMqFtjx2vmbSHDIU3fG = reversed(EaR4AyMqFtjx2vmbSHDIU3fG)
	CkVZXFsiG8fzYUK637IEjwlN9q2nO = b8sk5WyPoz03pXhRx.join(EaR4AyMqFtjx2vmbSHDIU3fG)
	RsYWOkAC8t4iMUoBd0K(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࡯ࡩ࡫ࡺࠧᄵ"),pbmKZA1w7L4zHjOM(u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧᄶ"),CkVZXFsiG8fzYUK637IEjwlN9q2nO,CCWqR3dmtzw6xoIX41(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧᄷ"))
	return
def Idy1FWCfe3():
	dds3oZNWSVXcfzhJ = open(u1XW2Sawc4m3ORV0BCUpLITy,ba49YvOK2Aw8Uhxt(u"ࠬࡸࡢࠨᄸ")).read()
	if fOohwvakqi29cx0l3yt5mzrAGpEg: dds3oZNWSVXcfzhJ = dds3oZNWSVXcfzhJ.decode(RMGz7OiD1e30P)
	dds3oZNWSVXcfzhJ = dds3oZNWSVXcfzhJ.replace(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࡜ࡵࠩᄹ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠩᄺ"))
	E2E9QlGMW6rmIRxnXka = AxTYMhRlfyskNc0X19dvwtS.findall(ba49YvOK2Aw8Uhxt(u"ࠨࠪࡹࡠࡩ࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩᄻ"),dds3oZNWSVXcfzhJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for bkhQVre594UyJ in E2E9QlGMW6rmIRxnXka:
		dds3oZNWSVXcfzhJ = dds3oZNWSVXcfzhJ.replace(bkhQVre594UyJ,oamlxBqLdu4ZM9nQrbIAhS5Pg7+bkhQVre594UyJ+so4Z8OUJ5E)
	okvXCAsSQLyfJ6xrUM0nz2(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩส่ฯเ๊๋ำสฮࠥอไฤะํีฮࠦแ๋ࠢส่อืวๆฮࠪᄼ"),dds3oZNWSVXcfzhJ)
	return
def LZwKMPETqrdc():
	jQxNuCVe4hzpObyKU = JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪฬ฾฼ࠠศๆฦึึอัࠡ฻็ํࠥอไา์่์ฯࠦใ้่อีํ๊ࠠห๊ไีࠥหๅไษ้๎ฮࠦสใัํ้ࠥ๎สฤะํีࠥอไโ์า๎ํ่่ࠦา๊ࠤฬ๊รำำสีࠥํ๊ࠡษ็วุํๅ๊ࠡส่ศืโศ็้ࠣ฾ࠦศฺุࠣ์่อไหษ็๎ࠬᄽ")
	VLRK8jaf4GxrIm2tN = Zb5cNeHWi6jP9SCYtUgR(u"้ࠫะโะ์่ࠤฬ๊แ๋ัํ์ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ๆ์้ࠤํ๊สฤะํี์ࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋ีสีࠥ࠴ࠠฤ็สࠤ฾ีษࠡษึ๋๊ࠦๅหฬส่๏ฯࠠโ้ำ๋ࠥะโ้็ࠣฬฯำั๋ๅࠣห้็๊ะ์๋ࠤอ๎โหࠢส็อืࠠๆ่ࠣ์็ะࠠศๆึ๋๊ࠦวๅ๊สัิࠦ࠮ࠡล่หࠥอไิ้่ࠤฬ๊รฺๆ์ࠤํอไฤีไ่ࠥ็็้ࠢํัึ้ࠠศๆไ๎ิ๐่ࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥ๎ไไ่ࠣฬ็็าสࠢๆฬ๏ืษࠨᄾ")
	FJZlhomc1CP8GT6VQ = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬษๅศࠢส่ศืโศ็ࠣๅ์๐ࠠหีอาิ๋ࠠๅๆอๆิ๐ๅ๊ࠡส่ฯษฮ๋ำࠣ์้้ๆࠡส่ๆิอัࠡ฻าำࠥอไฬ๊ส๊๏่ࠦศๆาๆฬฬโࠡ࠰้ࠣะ๊วࠡำๅ้ࠥ࠻࠴࠵ࠢอ฽๋๐ࠠ࠶ࠢาๆฬฬโ๊ࠡࠣ࠸࠹ࠦหศ่ํอࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวยࠢหัุฮࠠศีอาิอๅไࠢ็ุ่ํๅࠡษ็๎๊๐ๆࠡล๋ࠤุํๅࠡษ็๎ุอัࠨᄿ")
	mlrXUnyLzPAhEIj8ix5Ztpu = jQxNuCVe4hzpObyKU+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࠺ࠡࠩᅀ")+VLRK8jaf4GxrIm2tN+pbmKZA1w7L4zHjOM(u"ࠧࠡ࠰ࠣࠫᅁ")+FJZlhomc1CP8GT6VQ
	RsYWOkAC8t4iMUoBd0K(ba49YvOK2Aw8Uhxt(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᅂ"),F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu,pL73X0MYajJQG4n1qgD(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᅃ"))
	return
def C4CdVtZQikT(type,mlrXUnyLzPAhEIj8ix5Ztpu,showDialogs=NFGqKBLtvUZn1S3dau,url=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KS8ozxwIk1EB4srRJtgHfbVp2AhQ=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ggM5TzCxq24sDYLiEatpdSK7FQyGe=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GlD7Pcn16z2vQmw9jJapXk=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	hLd0Rk1AZEHu = NFGqKBLtvUZn1S3dau
	if not drzqWFkSHD.nt9ZocbLGBOMx2:
		if showDialogs:
			Bt6ges8rxVSE = (djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪหู้ืา࠼ࠪᅄ") in mlrXUnyLzPAhEIj8ix5Ztpu and rAYDiWlzm9MCU6x0GnROua(u"ࠫฬ๊ๅไษ้࠾ࠬᅅ") in mlrXUnyLzPAhEIj8ix5Ztpu and pYeVwat64v(u"ࠬอไๆๆไ࠾ࠬᅆ") in mlrXUnyLzPAhEIj8ix5Ztpu and hWRvZOYtjme9QNnV41u0Mswb(u"࠭วๅะฺวࠬᅇ") in mlrXUnyLzPAhEIj8ix5Ztpu and djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧศๆู่ิื࠺ࠨᅈ") in mlrXUnyLzPAhEIj8ix5Ztpu)
			if not Bt6ges8rxVSE: hLd0Rk1AZEHu = hhTcd5XlykBUu68zAb9OmgC(pYeVwat64v(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᅉ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GTmHXIZUSdxRhMnqQKkO(u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭ᅊ"),mlrXUnyLzPAhEIj8ix5Ztpu.replace(kAz7WRYjrfGm(u"ࠪࡠࡡࡴࠧᅋ"),b8sk5WyPoz03pXhRx))
	elif showDialogs:
		mlrXUnyLzPAhEIj8ix5Ztpu = w9wfONXUP3(u"ࠫࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࠫᅌ")
		YuZkU8dvGhJ = hhTcd5XlykBUu68zAb9OmgC(I6Bfzysrvb8DONZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᅍ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᅎ")+GTmHXIZUSdxRhMnqQKkO(u"ࠧࠡࠢ࠴࠳࠺࠭ᅏ"),GTmHXIZUSdxRhMnqQKkO(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᅐ"))
		YQk2vPpRNboj = hhTcd5XlykBUu68zAb9OmgC(YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡦࡩࡳࡺࡥࡳࠩᅑ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪᅒ")+lRKCWnNi0Edr984eI(u"ࠫࠥࠦ࠲࠰࠷ࠪᅓ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪᅔ"))
		lUROY8MW5XNK0QI1A3kGCa = hhTcd5XlykBUu68zAb9OmgC(jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅕ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧᅖ")+hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࠢࠣ࠷࠴࠻ࠧᅗ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧᅘ"))
		WpLVGUciq7X6DzTtPsIFn8QAvgyM9o = hhTcd5XlykBUu68zAb9OmgC(CCWqR3dmtzw6xoIX41(u"ࠪࡧࡪࡴࡴࡦࡴࠪᅙ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᅚ")+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬࠦࠠ࠵࠱࠸ࠫᅛ"),ba49YvOK2Aw8Uhxt(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᅜ"))
		hLd0Rk1AZEHu = hhTcd5XlykBUu68zAb9OmgC(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡤࡧࡱࡸࡪࡸࠧᅝ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,I6Bfzysrvb8DONZ(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᅞ")+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࠣࠤ࠺࠵࠵ࠨᅟ"),Zb5cNeHWi6jP9SCYtUgR(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᅠ"))
	AGJCrVUZnp6KR = ih5mrq2OAK3tXFIpfcJRVe4Z(pLwgjkuTs6CS)
	vzMnlr3YNxa = CCWqR3dmtzw6xoIX41(u"ࠫࡆ࡜࠺ࠡࠩᅡ")+AGJCrVUZnp6KR+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠬ࠳ࠧᅢ")+type
	cmlg4zPtvT3nKNOoja = NFGqKBLtvUZn1S3dau if pbmKZA1w7L4zHjOM(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩᅣ") in ggM5TzCxq24sDYLiEatpdSK7FQyGe else pLwgjkuTs6CS
	if not hLd0Rk1AZEHu:
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,nR0ok9zju84rFUQl1YC(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪᅤ"))
		return pLwgjkuTs6CS
	nIrAWJbX8D52EYc3pxVHtBz = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel(pYeVwat64v(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧᅥ"))
	mlrXUnyLzPAhEIj8ix5Ztpu += MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨᅦ")+FLRQJnBHTvsXU+ba49YvOK2Aw8Uhxt(u"ࠪࠤ࠿ࡢ࡜࡯ࠩᅧ")
	mlrXUnyLzPAhEIj8ix5Ztpu += B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬᅨ")+AGJCrVUZnp6KR+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫᅩ")+cjEfQ4VpOPw+I6Bfzysrvb8DONZ(u"࠭ࠠ࠻࡞࡟ࡲࠬᅪ")
	mlrXUnyLzPAhEIj8ix5Ztpu += pYeVwat64v(u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬᅫ")+nIrAWJbX8D52EYc3pxVHtBz
	NrjfdKS6Hy17Beo5Clt2xJQqT = I7rKQBsXODTC4RSgUYMHLG()
	NrjfdKS6Hy17Beo5Clt2xJQqT = NrjfdKS6Hy17Beo5Clt2xJQqT.replace(f9fOpCmLAEaW2Go(u"ࠨ࠮࠯ࠫᅬ"),pL73X0MYajJQG4n1qgD(u"ࠩ࠯ࠫᅭ"))
	NrjfdKS6Hy17Beo5Clt2xJQqT = pmhHwIbkcrRJeyzuxPUSDGnqM92(NrjfdKS6Hy17Beo5Clt2xJQqT)
	if NrjfdKS6Hy17Beo5Clt2xJQqT: mlrXUnyLzPAhEIj8ix5Ztpu += W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬᅮ")+NrjfdKS6Hy17Beo5Clt2xJQqT
	if url: mlrXUnyLzPAhEIj8ix5Ztpu += I6Bfzysrvb8DONZ(u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨᅯ")+url
	if KS8ozxwIk1EB4srRJtgHfbVp2AhQ: mlrXUnyLzPAhEIj8ix5Ztpu += jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬᅰ")+KS8ozxwIk1EB4srRJtgHfbVp2AhQ
	mlrXUnyLzPAhEIj8ix5Ztpu += w9wfONXUP3(u"࠭ࠠ࠻࡞࡟ࡲࠬᅱ")
	if showDialogs: ARL0tsEeanKImhMByugPTvX7(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧอษิ๎ࠥอไฦำึห้࠭ᅲ"),lRKCWnNi0Edr984eI(u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪᅳ"))
	if cmlg4zPtvT3nKNOoja:
		if nR0ok9zju84rFUQl1YC(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩᅴ") in ggM5TzCxq24sDYLiEatpdSK7FQyGe: Hh6XPBVDgnw7t20rm3 = LwFGz5ZiSvs60a
		else: Hh6XPBVDgnw7t20rm3 = bHYSILv5x4mrnCuKVZt6XzfFGgR8j
		if not oNlez5gnM9x2B4.path.exists(Hh6XPBVDgnw7t20rm3):
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥเ๊า่ࠢ์ั๎ฯࠨᅵ"))
			return pLwgjkuTs6CS
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࠳ࡢࡴࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡳࡦࡰࡧࠤࡹ࡮ࡥࠡ࡮ࡲ࡫࡫࡯࡬ࡦࠩᅶ"))
		EaR4AyMqFtjx2vmbSHDIU3fG,aINuxABv6tbikfO4dzL = [],MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠱ፖ")
		file = open(Hh6XPBVDgnw7t20rm3,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬࡸࡢࠨᅷ"))
		size,count = yxjuaUT04zJF(Hh6XPBVDgnw7t20rm3)
		if size>Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵࠳࠵࠵࠶࠰ፗ"): file.seek(-Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠵࠳࠵࠵࠶࠰ፗ"),oNlez5gnM9x2B4.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(RMGz7OiD1e30P)
		data = l8sCrLqQ3jdN(data)
		FGgCZybURVmONe7sXtL4xj2M = data.splitlines()
		for bkhQVre594UyJ in reversed(FGgCZybURVmONe7sXtL4xj2M):
			ND7BqtPJjuhQkLIYi8a5wKc = lIdJ9CtOP5xBgS6b(bkhQVre594UyJ)
			if ND7BqtPJjuhQkLIYi8a5wKc: continue
			eeJ0DCyRVaZnW1OHlUfGp = AxTYMhRlfyskNc0X19dvwtS.findall(CCWqR3dmtzw6xoIX41(u"࠭࡞ࠩ࡞ࡧ࠯࠲࠮࡜ࡥ࠭࠰ࡠࡩ࠱ࠠ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭ࠬ࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ᅸ"),bkhQVre594UyJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if eeJ0DCyRVaZnW1OHlUfGp:
				bkhQVre594UyJ = bkhQVre594UyJ.replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][nUaVQsoA6EXcK4Odht5wCge0J8Pib],eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7]).replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][H3OKMjDG1evnl4Ruiz],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			else:
				eeJ0DCyRVaZnW1OHlUfGp = AxTYMhRlfyskNc0X19dvwtS.findall(Zb5cNeHWi6jP9SCYtUgR(u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧᅹ"),bkhQVre594UyJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if eeJ0DCyRVaZnW1OHlUfGp: bkhQVre594UyJ = bkhQVre594UyJ.replace(eeJ0DCyRVaZnW1OHlUfGp[nUaVQsoA6EXcK4Odht5wCge0J8Pib][xD9WeoEAsX7],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			EaR4AyMqFtjx2vmbSHDIU3fG.append(bkhQVre594UyJ)
			if len(str(EaR4AyMqFtjx2vmbSHDIU3fG))>pbmKZA1w7L4zHjOM(u"࠵࠹࠶࠶࠰࠱ፘ"): break
		EaR4AyMqFtjx2vmbSHDIU3fG = reversed(EaR4AyMqFtjx2vmbSHDIU3fG)
		CkVZXFsiG8fzYUK637IEjwlN9q2nO = nR0ok9zju84rFUQl1YC(u"ࠨ࡞ࡵࡠࡳ࠭ᅺ").join(EaR4AyMqFtjx2vmbSHDIU3fG)
	elif GlD7Pcn16z2vQmw9jJapXk: CkVZXFsiG8fzYUK637IEjwlN9q2nO = GlD7Pcn16z2vQmw9jJapXk
	else: CkVZXFsiG8fzYUK637IEjwlN9q2nO = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	url = drzqWFkSHD.SITESURLS[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᅻ")][H3OKMjDG1evnl4Ruiz]
	dXG96SRYbe = {Zb5cNeHWi6jP9SCYtUgR(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫᅼ"):vzMnlr3YNxa,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᅽ"):mlrXUnyLzPAhEIj8ix5Ztpu,f9fOpCmLAEaW2Go(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ᅾ"):CkVZXFsiG8fzYUK637IEjwlN9q2nO}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,GTmHXIZUSdxRhMnqQKkO(u"࠭ࡐࡐࡕࡗࠫᅿ"),url,dXG96SRYbe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡖࡉࡓࡊ࡟ࡆࡏࡄࡍࡑ࠳࠱ࡴࡶࠪᆀ"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡵࡨࡲࡩࡥࡳࡶࡥࡦࡩࡪࡪࡥࡥࠩᆁ") in R8AE9e4mYxVhusL3Q: oo3n0EuaHjYSz = NFGqKBLtvUZn1S3dau
	else: oo3n0EuaHjYSz = pLwgjkuTs6CS
	if showDialogs:
		if oo3n0EuaHjYSz:
			ARL0tsEeanKImhMByugPTvX7(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬᆂ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫᆃ"))
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪᆄ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧᆅ"))
		else:
			ARL0tsEeanKImhMByugPTvX7(pYeVwat64v(u"࠭ไๅลึๅࠥ็ิๅࠢส่สืำศๆࠪᆆ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡇࡣ࡬ࡰࡺࡸࡥࠨᆇ"))
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨะฺวࠥ๎แีๆࠣๅ๏ࠦลาีส่ࠥอไาีส่ฮ࠭ᆈ"))
	return oo3n0EuaHjYSz
def X3otudCq9wISJBEsx6YQLANTRir():
	jQxNuCVe4hzpObyKU = GTmHXIZUSdxRhMnqQKkO(u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪࠦ࡭ࡦࡰࡸࠤ࡮ࡺࡥ࡮ࡵࠣࡸࡴࠦࡡࠡ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠣࡳࡹ࡮ࡥࡳࠢࡷ࡬ࡦࡴࠠࡂࡴࡤࡦ࡮ࡩࠠ࠯࠰ࠣࡓࡷࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤࡸ࡮࡯ࡸࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡥࡳࡪࠠࡵࡧࡻࡸࠥࡅࠡࠨᆉ")
	VLRK8jaf4GxrIm2tN = kAz7WRYjrfGm(u"๋้ࠪࠦสา์าࠤฯืฬๆหࠣๆํอฦๆࠢส่อืๆศ็ฯࠤส๊้ࠡๆ฽อࠥษฮา๋ࠣ฾๏ืࠠศๆ฼ีอ๐ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหุ่ษิࠤฬ๊รฮำไࠤํอไไฬสฬฮࠦวๅ฻ิฬ๏ฯࠠภࠣࠪᆊ")
	choice = uPS1UedvhXl6MHVbq7zr5Z92Tig(pL73X0MYajJQG4n1qgD(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆋ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬิั้ฮࠣࡉࡽ࡯ࡴࠨᆌ"),lRKCWnNi0Edr984eI(u"࠭ࡔࡳࡣࡱࡷࡱࡧࡴࡦࠢอีั๋ษࠨᆍ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ฺࠧำห๎ࠥࡇࡲࡢࡤ࡬ࡧࠬᆎ"),F91YEzyWak5,jQxNuCVe4hzpObyKU+YzlId3Fs6vpehcbLGj0UaO(u"ࠨ࡞ࡱࡠࡳ࠭ᆏ")+VLRK8jaf4GxrIm2tN)
	if choice in [-B1YMtuvRAGNlJOkC46VyPKQE(u"࠵ፙ"),GTmHXIZUSdxRhMnqQKkO(u"࠵ፚ")]: return
	elif choice==KKCrwPdOgGl(u"࠷፛"):
		import DH2Bq30Yxp
		DH2Bq30Yxp.DMoX8BOqadnxhNRyYGE()
		return
	HlGKAspy6qBjD9 = NFGqKBLtvUZn1S3dau
	while HlGKAspy6qBjD9:
		HlGKAspy6qBjD9 = pLwgjkuTs6CS
		message = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩศิฬูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣࠦส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠤࠣฯฺ๊๋ࠦำࠣห้ิืࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࠮࠯ࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็ฺ๋ำࠣห้าไะࠢศ่๎ࠦร๋ࠢฯ่ิࠦหศ่ํࠤๆ๐็ࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣฯ๊ࠦศฺั๊หࠥเ๊าࠢส่ำ฽ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡวำห๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦไศࠢอ฼์ืࠠๅๅࠣ࠲࠳ࠦวั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡ࠰࠱ࠤะ๋ࠠ฻์ิࠤส฿ฯศัสฮࠥอไๆ๊ๅ฽ࠥอไอ฼ิหๆ๐ࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤๆะอࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡมࠤࠫᆐ")
		choice = uPS1UedvhXl6MHVbq7zr5Z92Tig(I6Bfzysrvb8DONZ(u"ࠪࡧࡪࡴࡴࡦࡴࠪᆑ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡊࡾࡩࡵࠢัีําࠧᆒ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬ࡟ࡥࡴ้ࠢ฽๊࠭ᆓ"),JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠠฦ่ฯ่๏ุ๊ࠨᆔ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ฺࠧั่ࠤ฽ํ่าࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอࠬᆕ"),message,profile=lRKCWnNi0Edr984eI(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ᆖ"))
		if choice==JZ45mOctiTszPNw1GVjxhep2Y(u"࠲፜"):
			message = pL73X0MYajJQG4n1qgD(u"ࠩࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦ࡬ࡦࡶࡷࡩࡷࡹࠠࡵࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡹࡵࠠࡢࡰࡼࠤࡴࡺࡨࡦࡴࠣࡷࡰ࡯࡮ࠡࡶ࡫ࡥࡹࠦࡨࡢࡸࡨࠤࡡࠨࡁࡳ࡫ࡤࡰࡡࠨࠠࡧࡱࡱࡸࠥ࠴࠮ࠡࡃࡱࡨࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࡟ࡲࠥࡏࡦࠡࡃࡵࡥࡧ࡯ࡣࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦ࠮࠯ࠢࡗ࡬ࡪࡴࠠࡰࡲࡨࡲࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡ࡞ࡱࡠࡳࠦࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡳࡵࡷࠡࡶࡲࠤࡴࡶࡥ࡯ࠢࡷ࡬ࡪࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡄࠧࠧᆗ")
			choice = uPS1UedvhXl6MHVbq7zr5Z92Tig(lRKCWnNi0Edr984eI(u"ࠪࡧࡪࡴࡴࡦࡴࠪᆘ"),pL73X0MYajJQG4n1qgD(u"ࠫࡊࡾࡩࡵࠢัีําࠧᆙ"),pL73X0MYajJQG4n1qgD(u"ࠬ࡟ࡥࡴ้ࠢ฽๊࠭ᆚ"),awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ࡁࡳࡣࡥ࡭ࡨูࠦาสํࠫᆛ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࡎ࡫ࡶࡷ࡮ࡴࡧࠡࡃࡵࡥࡧ࡯ࡣࠡࡈࡲࡲࡹࠦࠦࠡࡖࡨࡼࡹ࠭ᆜ"),message,profile=nR0ok9zju84rFUQl1YC(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ᆝ"))
			if choice==kAz7WRYjrfGm(u"࠳፝"): HlGKAspy6qBjD9 = NFGqKBLtvUZn1S3dau
		if choice==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠳፞"): h4IsToyVmPgDkulwdx01CiqY()
	return
def JmvsGiKyS9RpTj8eV5aQxh2BIw4():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,hWRvZOYtjme9QNnV41u0Mswb(u"ࠩ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬ๊ࠡ็่ฯษใะࠢๅ้ࠥฮสี฼ํ่ࠥอไาษห฻ࠥอไั์่ࠣฬฺ๊ࠦ็็ࠤะ๋ࠠใ็ࠣฬสืำศๆู้้ࠣไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣห้่วว็ฬࠤฬ๊ัว์ึ๎ฮࠦไๅสิ๊ฬ๋ฬࠨᆞ"))
	return
def p9cTq18YjWQZNy3I6402():
	mlrXUnyLzPAhEIj8ix5Ztpu = pL73X0MYajJQG4n1qgD(u"๋ࠪีอࠠศๆหี๋อๅอ่ࠢาฺ฻ࠠโไฺࠤฺ้๊สࠢส่฾ืศ๋หࠣ์้้ๆ้ࠡำห๊ࠥวࠡ์่๊฾่ࠦอ๊าࠤ๊๎วใ฻ࠣๅ๏ํวࠡลไ่ฬ๋้ࠠ็ึุ่๊วห่ࠢฮึาๅสࠢฦ์๋ࠥฯษๆฯอࠥหไ๊ࠢส่้เษࠡษ็฽ึฮ๊ส๋ࠢห้๏ࠠๅ฼สฮࠥอฮา๋ࠣ์้อ๋๊ࠠฯำูࠥศษࠢ็่ฯ้ัศำࠪᆟ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def SoOsrDuHnbY7qh5TWX1():
	mlrXUnyLzPAhEIj8ix5Ztpu = pL73X0MYajJQG4n1qgD(u"ࠫฬ๊ั้ษห฻ࠥอไษูํสฮࠦไศࠢ฼่ฬ่ษࠡๆ๊หࠥฮวๅสิ๊ฬ๋ฬ๊ࠡ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬࠨᆠ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def llh5NOLQfIViEU8kMZPmw6():
	mlrXUnyLzPAhEIj8ix5Ztpu = B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬํ๊ࠡีํีๆืวหࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠศีอาิอๅ่ษࠣฬุฮศࠡๅ๋๊์อࠠๆฯ่๎ฮࠦๅ็ࠢส่๊฻ฯาࠢฦ์ࠥฮอศฮฬࠤส๊้ࠡษืฮึอใࠡำึ้๏ࠦร้ࠢฯำ๏ีษࠡล๋ࠤ้อ๋ࠠ฻ิๅ์อࠠศๆหี๋อๅอࠩᆡ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,I6Bfzysrvb8DONZ(u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨᆢ"),mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def RGp4fwdLkvnAQmr72():
	mlrXUnyLzPAhEIj8ix5Ztpu = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬᆣ")
	RsYWOkAC8t4iMUoBd0K(GTmHXIZUSdxRhMnqQKkO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᆤ"),F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᆥ"))
	return
def IY7HzyfhW0vjX5GmuicDRAwl():
	jQxNuCVe4hzpObyKU = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊ฯใหࠣห้฿วๅ์ฬࠫᆦ")
	VLRK8jaf4GxrIm2tN = hWRvZOYtjme9QNnV41u0Mswb(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥษไࠡ࡯࠶ࡹ࠽࠭ᆧ")
	FJZlhomc1CP8GT6VQ = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅฬะ้๏๊้ࠠษ็ำฬ๎ๆๅ๊าࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᆨ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,jQxNuCVe4hzpObyKU,VLRK8jaf4GxrIm2tN,FJZlhomc1CP8GT6VQ)
	return
def QQqLmWdsxBOfD0RrzgHIVcKEt6():
	VLRK8jaf4GxrIm2tN = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭วๅๅสุࠥํ่ࠡ็ัึ๋ࠦๅลไอࠤ้๊ๅฺๆ๋้ฬะ๋ࠠีอาิ๋็ࠡษ็ฬึ์วๆฮ่ࠣำุๆࠡืไัฬะࠠศๆศ๊ฯืๆ๋ฬࠣ์ึ๎วษูࠣห้็๊ะ์๋๋ฬะࠠๅๆู๋ํ๊ࠠฦๆํ๋ฬࠦศิำ฼อࠥ๎ศะ๊้ࠤส์สา่ํฮࠥ๎วๅสิ๊ฬ๋ฬࠡ์่ืาํวࠡฬ็ๆฬฬ๊ศࠢห฽ิࠦว็ฬ๊หฦูࠦๆำ๊หࠥ๎รุ๋สࠤ฾์ฯࠡฬะำ๏ัࠠศๆหี๋อๅอࠢ࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤุฮูสࠢฦ๊ํอูࠡๆ฼้ึࠦวๅๅสุࠥࡀࠧᆩ")
	VLRK8jaf4GxrIm2tN += B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧ࡝ࡰ࡟ࡲࠬᆪ") + f9fOpCmLAEaW2Go(u"ࠨ࠳࠱ࠤะอศหࠢ็ฺ่็อศฬࠣห้ะ๊ࠡ็฼ีํ็ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ืࠠ็้สส๏อ้ࠠ็าฮ์ࠦࠧᆫ") + str(iigI6zE7djY3yQasNTM5AW0PLOS4/CCWqR3dmtzw6xoIX41(u"࠹࠴፟")/CCWqR3dmtzw6xoIX41(u"࠹࠴፟")/GTmHXIZUSdxRhMnqQKkO(u"࠶࠹፠")/f9fOpCmLAEaW2Go(u"࠸࠶፡")) + djapWhrveLJbgnViDftFNY05ylq1S(u"ุࠩࠣ์ืࠧᆬ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪ࠶࠳ࠦฬะษࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็้ๆื่ืࠢฦ๊์อࠠๅษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩᆭ") + str(QT1GPoWB7px/Zb5cNeHWi6jP9SCYtUgR(u"࠼࠰።")/Zb5cNeHWi6jP9SCYtUgR(u"࠼࠰።")/lRKCWnNi0Edr984eI(u"࠲࠵፣")) + f9fOpCmLAEaW2Go(u"ࠫࠥ๐่ๆࠩᆮ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩᆯ") + str(QTa0s1bvhkXjIim7lWF5qVBJUoNZ/bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠷࠲፤")/bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠷࠲፤")/MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠴࠷፥")) + bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"๋๊่࠭ࠠࠫᆰ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + f9fOpCmLAEaW2Go(u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩᆱ") + str(BRMcS58jIbyDQWGYLk1term/JZ45mOctiTszPNw1GVjxhep2Y(u"࠹࠴፦")/JZ45mOctiTszPNw1GVjxhep2Y(u"࠹࠴፦")) + zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࠢึห฾ฯࠧᆲ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩ࠸࠲่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠะษษ้ฬ่ࠦๆัอ๋ࠥ࠭ᆳ") + str(V7DSdHck4Fjp/rAYDiWlzm9MCU6x0GnROua(u"࠺࠵፧")/rAYDiWlzm9MCU6x0GnROua(u"࠺࠵፧")) + CCWqR3dmtzw6xoIX41(u"ࠪࠤุอูสࠩᆴ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + GTmHXIZUSdxRhMnqQKkO(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬᆵ") + str(qJ0xtbICjHuM45nmhO7fgpkr/rAYDiWlzm9MCU6x0GnROua(u"࠻࠶፨")) + KKCrwPdOgGl(u"ࠬࠦฯใ์ๅอࠬᆶ")
	VLRK8jaf4GxrIm2tN += b8sk5WyPoz03pXhRx + CCWqR3dmtzw6xoIX41(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨᆷ") + str(RFowY7JrTPs8c5m02ydD1VgbeBup3N) + zWBnYSGIatjXVC(u"ࠧࠡัๅ๎็ฯࠧᆸ")
	VLRK8jaf4GxrIm2tN += YzlId3Fs6vpehcbLGj0UaO(u"ࠨ࡞ࡱࡠࡳ࠭ᆹ") + hWRvZOYtjme9QNnV41u0Mswb(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭ᆺ") + str(BRMcS58jIbyDQWGYLk1term/pYeVwat64v(u"࠼࠰፩")/pYeVwat64v(u"࠼࠰፩")) + pYeVwat64v(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫᆻ") + str(QTa0s1bvhkXjIim7lWF5qVBJUoNZ/pYeVwat64v(u"࠼࠰፩")/pYeVwat64v(u"࠼࠰፩")/Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠲࠵፪")) + YzlId3Fs6vpehcbLGj0UaO(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪᆼ") + str(V7DSdHck4Fjp/pYeVwat64v(u"࠼࠰፩")/pYeVwat64v(u"࠼࠰፩")) + w9wfONXUP3(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩᆽ") + str(qJ0xtbICjHuM45nmhO7fgpkr/pYeVwat64v(u"࠼࠰፩")) + bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨᆾ") + str(RFowY7JrTPs8c5m02ydD1VgbeBup3N) + zWBnYSGIatjXVC(u"ࠧࠡัๅ๎็ฯࠧᆿ")
	RsYWOkAC8t4iMUoBd0K(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡴ࡬࡫࡭ࡺࠧᇀ"),JZ45mOctiTszPNw1GVjxhep2Y(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧᇁ"),VLRK8jaf4GxrIm2tN,w9wfONXUP3(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᇂ"))
	return
def kUpLljcBfxaAeFXTOZy8og():
	mlrXUnyLzPAhEIj8ix5Ztpu = pYeVwat64v(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧᇃ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def AroyRGVsiX9wL6ZSI8g():
	mlrXUnyLzPAhEIj8ix5Ztpu = W2Vv30i8qxSuItfsolPLdFZA(u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭ᇄ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def VhoimJvaUXG():
	mlrXUnyLzPAhEIj8ix5Ztpu = lRKCWnNi0Edr984eI(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪᇅ")
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
	return
def VNbKriZyHpT():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧๅๅํࠤ๏฿ๅๅ๊ࠢิฬࠦวๅ่๋฽๋ࠥๆࠡษ็ๅ๏ี๊้้สฮࠥࡢ࡮ࠡ์ฯฬࠥะแฺ์็ࠤส฼วโหࠣหุ๋็ศࠢ࡟ࡲࠥ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬᇆ"))
	dJv9nZwNPYyes2zKA7rIX6Rgqp(W2Vv30i8qxSuItfsolPLdFZA(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨᇇ"),NFGqKBLtvUZn1S3dau)
	return
def XDWnbHKFYy1Cek8rivZ45TNuE():
	mlrXUnyLzPAhEIj8ix5Ztpu  = slQajGY35wNHvXoVSrUC6AEPWyqhp(u"่ࠩศำืวࠡไส้ฯࠦศฺุุࠣึ้วหࠢส่ส์สา่อࠤฬ๊ฯ้ๆํࠤอ๎ึฺࠢ฼หห่ࠠืัࠣห้ฮัศ็ฯࠤ๊ัไࠡๅ๋ำ๏ࠦไหี่ัࠥ็โุࠢ็ฬ฾฼ࠠๆีอาิ๋๊ࠡษ็้ฯ฻แฮࠢหห้ีฮ้ๆ่๊ࠣ๎วใ฻ࠣห้็๊ะ์๋ࠫᇈ")
	mlrXUnyLzPAhEIj8ix5Ztpu += I6Bfzysrvb8DONZ(u"ࠪࠤํ์ส๋ฮฬࠤ้ํะศࠢส่฾อฦใࠢไห๋ํࠠหไิ๎ออࠠอ็ํ฽๋ࠥำหะา้๏ࠦศา่ส้ัࠦใ้ัํࠤ้อ๋ࠠีอ฻๏฿่็ࠢส่ิิ่ๅࠢ็ะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢะฮ๎ࠦๅฺࠢสืฯิฯศ็ࠪᇉ")
	mlrXUnyLzPAhEIj8ix5Ztpu += b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิัࠨᇊ")+so4Z8OUJ5E+b8sk5WyPoz03pXhRx
	mlrXUnyLzPAhEIj8ix5Ztpu += f9fOpCmLAEaW2Go(u"ࠬࡢ࡮ๅษ้ࠤ์ึวࠡๆ้ࠤ๏ำไࠡษ็ู้้ไส๋ࠢษ๋๋วࠡใๅ฻ู๊ࠥใ๊่ࠤอหีๅษะࠤอ฿ึࠡษ็้ํอโฺ๋ࠢษ฾อโส่ࠢ์ฬู่ࠡษัี๎ࠦใศ่อࠤฯ฿ๅๅࠢึหอ่วࠡสา์๋ࠦๅีษๆ่ࠬᇋ")
	RsYWOkAC8t4iMUoBd0K(pYeVwat64v(u"࠭ࡲࡪࡩ࡫ࡸࠬᇌ"),F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu,nR0ok9zju84rFUQl1YC(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᇍ"))
	mlrXUnyLzPAhEIj8ix5Ztpu = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫᇎ")
	mlrXUnyLzPAhEIj8ix5Ztpu += b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+ba49YvOK2Aw8Uhxt(u"ࠩࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨᇏ")+so4Z8OUJ5E
	mlrXUnyLzPAhEIj8ix5Ztpu += W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࡠࡳࡢ࡮ࠨᇐ")+zWBnYSGIatjXVC(u"ࠫฬ๊ฯ้ๆࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬᇑ")
	mlrXUnyLzPAhEIj8ix5Ztpu += b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+CCWqR3dmtzw6xoIX41(u"๋ࠬีาࠢࠣห้้่๋ฬࠣࠤศ๋๊าๅสࠤ้ࠥๆะษࠣࠤๆืๆิษࠣࠤฬ๊๊้่ส๊ࠥࠦศา์ฺห๋๐วࠡษ็ษ๊อัศฬࠣว้๋ว็์สࠤึ๎ำ๋ษࠣห้๐วษษ้ࠤฬ๊ำฺ๊า๎ฮࠦั้็ส๊๏อ่๊ࠠ็๊ิอࠧᇒ")+so4Z8OUJ5E
	mlrXUnyLzPAhEIj8ix5Ztpu += KKCrwPdOgGl(u"࠭࡜࡯࡞ࡱࠫᇓ")+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧศๆ่ฬึ๋ฬ๊ࠡฯำࠥ฽ั๋ไฬࠤ้ะฬศ๊ีࠤฬู๊ศศๅࠤํ๊ใ็้สࠤฯำสศฮࠣะ์ีࠠไสํีࠥ๎วๅ็หี๊าฺ๋้ࠠࠤฬ๊ๅีๅ็อࠥ฻ฺ๋ำฬࠤํ๊วࠡฬึฮา่ࠠศๆอ฽อࠦแฦาสࠤ้ี๊ไุ่่๊ࠢษࠡสส่ิิ่ๅࠢ็ฬ฾฼ࠠศๆ่์ฬู่๊ࠡฦ๎฻อࠠๅๅํࠤ๏ะึฮࠢะะ๊ࠦวๅ็ื็้ฯࠠࠨᇔ")
	mlrXUnyLzPAhEIj8ix5Ztpu += qFghPAi5yz9Vf3NLwo0nuprl+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨษิื้ࠦัิษ็อ๋ࠥฤะสฬࠤส๊้ࠡษ็้อืๅอ๋ࠢห่ะศࠡใํ๋ฬࠦวิ็ࠣฬ้ีใ๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮุะื๋฻ࠣำำ๎ไ่ษࠪᇕ")+so4Z8OUJ5E
	RsYWOkAC8t4iMUoBd0K(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡵ࡭࡬࡮ࡴࠨᇖ"),F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᇗ"))
	return
def HXfbOJogBCrGvuW8Rhm6p():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"ࠫะ๊วฬฺࠢี็ࠦไๅฬ๋หฺ๊ࠠๆ฻ࠣห้๋ศา็ฯࠫᇘ"),lRKCWnNi0Edr984eI(u"ࠬษัิๆࠣีุอไสࠢฦ์๋ࠥิไๆฬࠤ๊์ࠠใษษ้ฮࠦัิษษ่ࠥํะศࠢส่อืๆศ็ฯࡠࡳࡢ࡮ฤ๊ࠣฬฬูสฯัส้ࠥอไโ์ึฬํ้ࠠฤั้ห์ࡢ࡮ࠨᇙ")+qFghPAi5yz9Vf3NLwo0nuprl+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡦࡢࡥࡨࡦࡴࡵ࡫࠯ࡥࡲࡱ࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࠨᇚ")+so4Z8OUJ5E+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧ࡝ࡰ࡟ࡲศ๎ࠠษษิืฬ๊ࠠศ์่๎้ࠦวๅ๋ࠣวิ์ว่ࠢࠣࡠࡳࠦࠧᇛ")+qFghPAi5yz9Vf3NLwo0nuprl+YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࡄ࡬ࡳࡡࡪ࡮࠱ࡧࡴࡳࠧᇜ")+so4Z8OUJ5E)
	return
def s5sq1JQ3OFxZSMryd(showDialogs=NFGqKBLtvUZn1S3dau):
	if not showDialogs: showDialogs = NFGqKBLtvUZn1S3dau
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,nR0ok9zju84rFUQl1YC(u"ࠩࡊࡉ࡙࠭ᇝ"),pbmKZA1w7L4zHjOM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩᇞ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧᇟ"))
	if not gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.succeeded:
		P6Q4nOYwsJR2xvc8g = pLwgjkuTs6CS
		hvIznkl0UTZtp6OXMaLd5juBP4EG8r = cqHgRBFQ7XmEkTx50nWLS6fIhDb(pLwgjkuTs6CS)
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+GTmHXIZUSdxRhMnqQKkO(u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝ࠪᇠ")+hvIznkl0UTZtp6OXMaLd5juBP4EG8r+YzlId3Fs6vpehcbLGj0UaO(u"࠭࡝ࠨᇡ"))
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,W2Vv30i8qxSuItfsolPLdFZA(u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫᇢ"))
	else:
		P6Q4nOYwsJR2xvc8g = NFGqKBLtvUZn1S3dau
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,ba49YvOK2Aw8Uhxt(u"ࠨฮํำࠥาฯศࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡ์฼ู้้ࠦ็ัๆࠤํอไษำ้ห๊าࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬᇣ"))
	if not P6Q4nOYwsJR2xvc8g and showDialogs: CCR4Px8kqVecZgd50YDFU()
	return P6Q4nOYwsJR2xvc8g
def CCR4Px8kqVecZgd50YDFU():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨᇤ"))
	xqlgIY936Oo2cfnzU1Kd5C8DPE()
	return
def fzpSeMdBQ7n1vtuPcNsW509wF38YK(ggM5TzCxq24sDYLiEatpdSK7FQyGe=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	cmlg4zPtvT3nKNOoja = NFGqKBLtvUZn1S3dau
	if jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ᇥ") not in ggM5TzCxq24sDYLiEatpdSK7FQyGe:
		cmlg4zPtvT3nKNOoja = pLwgjkuTs6CS
		jwgM2qYVpdK5ly = uPS1UedvhXl6MHVbq7zr5Z92Tig(pbmKZA1w7L4zHjOM(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇦ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠬิั้ฮࠪᇧ"),pYeVwat64v(u"࠭ลาีส่๋ࠥิไๆฬࠫᇨ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧฦำึห้ࠦัิษ็อࠬᇩ"),F91YEzyWak5,f9fOpCmLAEaW2Go(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫᇪ"))
		if jwgM2qYVpdK5ly in [-awSUTRNMkdIW7sFEvnHD2mLY(u"࠲፫"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠲፬")]: return
		elif jwgM2qYVpdK5ly==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠴፭"):
			cmlg4zPtvT3nKNOoja = NFGqKBLtvUZn1S3dau
			ggM5TzCxq24sDYLiEatpdSK7FQyGe = lRKCWnNi0Edr984eI(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬᇫ")
	if cmlg4zPtvT3nKNOoja:
		if zWBnYSGIatjXVC(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪᇬ") not in ggM5TzCxq24sDYLiEatpdSK7FQyGe:
			e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(w9wfONXUP3(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇭ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬᇮ"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭ᇯ"))
			if e6f0ycMuYQEJraNLInmip!=vl6rwMLasAQo4z1ZjD3IBKtF(u"࠵፮"):
				w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪᇰ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫᇱ"))
				return
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,nR0ok9zju84rFUQl1YC(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ᇲ"))
	mlrXUnyLzPAhEIj8ix5Ztpu = TwDBf3QbKOnrmd5u9(header=Zb5cNeHWi6jP9SCYtUgR(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࠦࠠศๅอฬࠥืำศๆฬࠫᇳ"),source=mI6ayKxBvjd4CRthL)
	if not mlrXUnyLzPAhEIj8ix5Ztpu: return
	if cmlg4zPtvT3nKNOoja: type = hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬᇴ")
	else: type = GTmHXIZUSdxRhMnqQKkO(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ᇵ")
	oo3n0EuaHjYSz = C4CdVtZQikT(type,mlrXUnyLzPAhEIj8ix5Ztpu,NFGqKBLtvUZn1S3dau,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩᇶ"),ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	return
def nwdejBvc8Ef9tY1SZiUhA5sLboa():
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫᇷ")
	RsYWOkAC8t4iMUoBd0K(Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡴ࡬࡫࡭ࡺࠧᇸ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩᇹ"),ggM5TzCxq24sDYLiEatpdSK7FQyGe,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᇺ"))
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = kAz7WRYjrfGm(u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧᇻ")
	RsYWOkAC8t4iMUoBd0K(GTmHXIZUSdxRhMnqQKkO(u"ࠬࡲࡥࡧࡶࠪᇼ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫᇽ"),ggM5TzCxq24sDYLiEatpdSK7FQyGe,hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᇾ"))
	return
def gcXKzDTLlSdBHrfbsny42Rt9u():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭ᇿ"))
	VhoimJvaUXG()
	return
def OBf9J6LoamUd():
	l0LXrspu6xGzAgR2TO4HDt9iaqQBYF = {}
	iyEFXAbtdQG9Kg8CqO,jQALNrcmIRo6ye39dfa01isCgTD4F7,lzhRMLrYbkQI = FtmVMk6UHfwNYqeJxGpKb(pLwgjkuTs6CS)
	jQxNuCVe4hzpObyKU,VLRK8jaf4GxrIm2tN,FJZlhomc1CP8GT6VQ,EHaB0uwx2d4CfPrzbmZI6YL,Zv2kBpFRtMizyfsDNVuIrb7JlWx,Xy9SM1o5T6HQCEvG,ReTK75qm14b = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	jQxNuCVe4hzpObyKU = zHYL9u48eyJot.join(jQALNrcmIRo6ye39dfa01isCgTD4F7)
	VLRK8jaf4GxrIm2tN = zHYL9u48eyJot.join(lzhRMLrYbkQI)
	onzyAvL6HZlr4FEeK,y6cHXTsjLh,lAo3ienB67yUMRK9TqhGSPzXC2Iw = iyEFXAbtdQG9Kg8CqO
	for z4t2nu5ryZjPR,Ickl2ZTm8g,RiJ2zIEwNL5k4rMvSBst7FYVAU13o in y6cHXTsjLh:
		RiJ2zIEwNL5k4rMvSBst7FYVAU13o = kd8ZhJPCe7QzxLgij3TEHlGtOv(RiJ2zIEwNL5k4rMvSBst7FYVAU13o)
		RiJ2zIEwNL5k4rMvSBst7FYVAU13o = RiJ2zIEwNL5k4rMvSBst7FYVAU13o.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(rAYDiWlzm9MCU6x0GnROua(u"ࠩࠣ࠲ࠬሀ"))
		weyKRk3WNjf9aIlBprOL = z4t2nu5ryZjPR.replace(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪሁ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡆࡖࡉࠨሂ"))
		EHaB0uwx2d4CfPrzbmZI6YL += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+weyKRk3WNjf9aIlBprOL+rAYDiWlzm9MCU6x0GnROua(u"ࠬࡀࠠࠨሃ")+so4Z8OUJ5E+RiJ2zIEwNL5k4rMvSBst7FYVAU13o+b8sk5WyPoz03pXhRx
		if Ickl2ZTm8g.isdigit(): l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[z4t2nu5ryZjPR] = int(Ickl2ZTm8g)
	PO57SDAx3mt2,L26GjekaR8QVvTMOodSfJImAE,ts6EyLcf8l1ZKxnMXSTgq = list(zip(*y6cHXTsjLh))
	for z4t2nu5ryZjPR in sorted(LVlOIga0UM):
		if z4t2nu5ryZjPR not in PO57SDAx3mt2:
			EHaB0uwx2d4CfPrzbmZI6YL += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+z4t2nu5ryZjPR+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭࠺ࠡࠩሄ")+so4Z8OUJ5E+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧๅษࠣ๎ําฯࠨህ")+b8sk5WyPoz03pXhRx
			if z4t2nu5ryZjPR not in drzqWFkSHD.non_videos_actions: FJZlhomc1CP8GT6VQ += zHYL9u48eyJot+z4t2nu5ryZjPR
	for RiJ2zIEwNL5k4rMvSBst7FYVAU13o,aINuxABv6tbikfO4dzL in onzyAvL6HZlr4FEeK:
		RiJ2zIEwNL5k4rMvSBst7FYVAU13o = kd8ZhJPCe7QzxLgij3TEHlGtOv(RiJ2zIEwNL5k4rMvSBst7FYVAU13o)
		Zv2kBpFRtMizyfsDNVuIrb7JlWx += RiJ2zIEwNL5k4rMvSBst7FYVAU13o+zWBnYSGIatjXVC(u"ࠨ࠼ࠣࠫሆ")+qFghPAi5yz9Vf3NLwo0nuprl+str(aINuxABv6tbikfO4dzL)+so4Z8OUJ5E+NzlAQMRChm8J34urLwcUOn1f
	jQxNuCVe4hzpObyKU = jQxNuCVe4hzpObyKU.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	VLRK8jaf4GxrIm2tN = VLRK8jaf4GxrIm2tN.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	FJZlhomc1CP8GT6VQ = FJZlhomc1CP8GT6VQ.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	JVW2PekNzO1qUjTGgamcMAI = jQxNuCVe4hzpObyKU+GTmHXIZUSdxRhMnqQKkO(u"ࠩࠣࠤ࠳࠴ࠠࠡࠩሇ")+VLRK8jaf4GxrIm2tN
	gMAIF8nGswJvC1YHZk65X  = W2Vv30i8qxSuItfsolPLdFZA(u"้ࠪํอโฺࠢฯ๎ิฯࠠี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋ห๊ࠣࠬ์ࠠศๆฦ็ะืࠠฦๆ์ࠤฬ๊รใๆࠬࠫለ")+b8sk5WyPoz03pXhRx+pbmKZA1w7L4zHjOM(u"ࠫํํะศ่ࠢ฽๋อ็ࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎์๋ࠠโ้ํࠤ๊์ฺ่ࠠา็ࠥ๎ไ๋ีอࠤ๊์ࠠศๆหี๋อๅอ๋่ࠢฬࠦๅ็ࠢส่๊๎โฺࠩሉ")+b8sk5WyPoz03pXhRx
	gMAIF8nGswJvC1YHZk65X += qFghPAi5yz9Vf3NLwo0nuprl+JVW2PekNzO1qUjTGgamcMAI+so4Z8OUJ5E+kAz7WRYjrfGm(u"ࠬࡢ࡮࡝ࡰࠪሊ")
	gMAIF8nGswJvC1YHZk65X += bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦๅ็้สࠤฬ๊ศา่ส้ัࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ࠮ๅาฬหอࠥษศอัํ࠭ࠬላ")+b8sk5WyPoz03pXhRx+f9fOpCmLAEaW2Go(u"้้ࠧำหู๋ࠥ็ษ๊ࠤฬำสๆษ็ࠤํา่ะุ่่๊ࠢษࠡ฻้ำ่ࠦร้ࠢไ๎ࠥอไๆ๊ๅ฽ࠥษ่ࠡใํࠤฬ๊ศา่ส้ั࠭ሌ")+b8sk5WyPoz03pXhRx
	FJZlhomc1CP8GT6VQ = zHYL9u48eyJot.join(sorted(FJZlhomc1CP8GT6VQ.split(zHYL9u48eyJot)))
	gMAIF8nGswJvC1YHZk65X += qFghPAi5yz9Vf3NLwo0nuprl+FJZlhomc1CP8GT6VQ+so4Z8OUJ5E
	p1pqbgyZChiFG,aafMTRC3lWyD8vFS0,fh8iN41FvTUW,CQwNU1K247hzrl63md = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵፯"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵፯"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵፯"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠵፯")
	all = l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[zWBnYSGIatjXVC(u"ࠨࡃࡏࡐࠬል")]
	if CCWqR3dmtzw6xoIX41(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩሎ") in list(l0LXrspu6xGzAgR2TO4HDt9iaqQBYF.keys()): p1pqbgyZChiFG = l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[f9fOpCmLAEaW2Go(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪሏ")]
	if jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬሐ") in list(l0LXrspu6xGzAgR2TO4HDt9iaqQBYF.keys()): aafMTRC3lWyD8vFS0 = l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[GTmHXIZUSdxRhMnqQKkO(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭ሑ")]
	if pYeVwat64v(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪሒ") in list(l0LXrspu6xGzAgR2TO4HDt9iaqQBYF.keys()): fh8iN41FvTUW = l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫሓ")]
	if B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡔࡈࡔࡔ࡙ࠧሔ") in list(l0LXrspu6xGzAgR2TO4HDt9iaqQBYF.keys()): CQwNU1K247hzrl63md = l0LXrspu6xGzAgR2TO4HDt9iaqQBYF[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩࡕࡉࡕࡕࡓࠨሕ")]
	KKxAtNhXeWc4q = all-p1pqbgyZChiFG-aafMTRC3lWyD8vFS0-fh8iN41FvTUW-CQwNU1K247hzrl63md
	G20Fvhu5p3,hAzqIfmMJsOYBWDCgwoTFnby = lAo3ienB67yUMRK9TqhGSPzXC2Iw[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	G20Fvhu5p3,pvxO3wtukNnm2oIA = lAo3ienB67yUMRK9TqhGSPzXC2Iw[xD9WeoEAsX7]
	mAc3zDr0atRsbLlQdk1OqK8hT9 = hAzqIfmMJsOYBWDCgwoTFnby-pvxO3wtukNnm2oIA
	ReTK75qm14b += oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(pvxO3wtukNnm2oIA)+so4Z8OUJ5E+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪห้฿ฯะࠢส่า่๊ใ์่้ࠣษฬ่ิฬࠤ࠿ࠦࠧሖ")
	ReTK75qm14b += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(mAc3zDr0atRsbLlQdk1OqK8hT9)+so4Z8OUJ5E+CCWqR3dmtzw6xoIX41(u"ࠫออำหะาห๊ࠦࡰࡳࡱࡻࡽࠥษ่ࠡࡸࡳࡲࠥࡀࠠࠨሗ")
	ReTK75qm14b += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(hAzqIfmMJsOYBWDCgwoTFnby)+so4Z8OUJ5E+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾ࠥ࠭መ")
	ReTK75qm14b += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(len(lAo3ienB67yUMRK9TqhGSPzXC2Iw[nR0ok9zju84rFUQl1YC(u"࠸፰"):]))+so4Z8OUJ5E+vl6rwMLasAQo4z1ZjD3IBKtF(u"ู࠭ะัࠣห้ี่ๅࠢส่ฯ๐ࠠโ์๊หࠥษฬ่ิฬࠤ࠿ࠦ࡜࡯࡞ࡱࠫሙ")
	for SShkAgdY82JXFDbsB4yz9,AGJCrVUZnp6KR in lAo3ienB67yUMRK9TqhGSPzXC2Iw[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠲፱"):]:
		SShkAgdY82JXFDbsB4yz9 = kd8ZhJPCe7QzxLgij3TEHlGtOv(SShkAgdY82JXFDbsB4yz9)
		SShkAgdY82JXFDbsB4yz9 = SShkAgdY82JXFDbsB4yz9.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).strip(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࠡ࠰ࠪሚ"))
		ReTK75qm14b += SShkAgdY82JXFDbsB4yz9+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨ࠼ࠣࠫማ")+qFghPAi5yz9Vf3NLwo0nuprl+str(AGJCrVUZnp6KR)+so4Z8OUJ5E+I6Bfzysrvb8DONZ(u"ࠩࠣࠤࠥ࠭ሜ")
	Xy9SM1o5T6HQCEvG += oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(KKxAtNhXeWc4q)+so4Z8OUJ5E+ba49YvOK2Aw8Uhxt(u"ࠪๅ๏ี๊้้สฮࠥอิห฼็ฮࠥࡀࠠࠨም")
	Xy9SM1o5T6HQCEvG += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(p1pqbgyZChiFG)+so4Z8OUJ5E+ba49YvOK2Aw8Uhxt(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢࡄࡔࡎࠦ࠺ࠡࠩሞ")
	Xy9SM1o5T6HQCEvG += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(CQwNU1K247hzrl63md)+so4Z8OUJ5E+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬ฽ไษษอࠤุ๐ัโำࠣห้๋ำห๊า฽ࠥࡀࠠࠨሟ")
	Xy9SM1o5T6HQCEvG += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(aafMTRC3lWyD8vFS0)+so4Z8OUJ5E+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪሠ")
	Xy9SM1o5T6HQCEvG += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(fh8iN41FvTUW)+so4Z8OUJ5E+zWBnYSGIatjXVC(u"ࠧหอห๎ฯࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠾ࠥ࠭ሡ")
	Xy9SM1o5T6HQCEvG += b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+str(len(onzyAvL6HZlr4FEeK))+so4Z8OUJ5E+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨัฺฺ๋่ࠥๅฬࠣๅ๏ี๊้้สฮࠥࡀࠠࠨሢ")
	Xy9SM1o5T6HQCEvG += lRKCWnNi0Edr984eI(u"ࠩ࡟ࡲࡡࡴࠧሣ")+Zv2kBpFRtMizyfsDNVuIrb7JlWx
	RsYWOkAC8t4iMUoBd0K(hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡧࡪࡴࡴࡦࡴࠪሤ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬሥ"),Xy9SM1o5T6HQCEvG,nR0ok9zju84rFUQl1YC(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨሦ"))
	RsYWOkAC8t4iMUoBd0K(MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ሧ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪረ"),gMAIF8nGswJvC1YHZk65X,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫሩ"))
	RsYWOkAC8t4iMUoBd0K(w9wfONXUP3(u"ࠩ࡯ࡩ࡫ࡺࠧሪ"),w9wfONXUP3(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥอำหะา้ฯࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬራ"),EHaB0uwx2d4CfPrzbmZI6YL,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬሬ"))
	return
def EEvNP5XwaSAF():
	mlrXUnyLzPAhEIj8ix5Ztpu = pL73X0MYajJQG4n1qgD(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴࠧር")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬሮ")+so4Z8OUJ5E+hWRvZOYtjme9QNnV41u0Mswb(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯ࠩሯ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰࠩሰ")+so4Z8OUJ5E+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠩ࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠึ์ส๊ฮࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡ็฼่ํ๋วหࠢส่อืๆศ็ฯࠫሱ")
	RsYWOkAC8t4iMUoBd0K(rAYDiWlzm9MCU6x0GnROua(u"ࠪࡧࡪࡴࡴࡦࡴࠪሲ"),F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧሳ"))
	return
def zvqGmc2eaBW7SorAONQiMfbUtx():
	mlrXUnyLzPAhEIj8ix5Ztpu = pL73X0MYajJQG4n1qgD(u"ࠬอไาษห฻๏์ࠠฤั้ห์ࠦแ๋้่หࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬี้้๋ࠠࠤ฾ฮวาหࠣ฽๋ࠦสฬสํฮ้ࠥวๆๆࠣหํะ่ๆษอ๎่๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦๆ฻๊ࠤฬ฼วโหࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ่ࠦๆ฻๊ࠤฬ฼วโหࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี้ࠠ็฼๋ࠥอึศใฬࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢๅ๏ํࠠฤ์ูหࠥาๅ๋฻ࠣห฾ีวะฬࠣ็ํี๊ࠡษ็้฼๊่ษห่ࠣ฾๋ไࠡสิ๊ฬ๋ฬࠡ฻่หิ่ࠦไๆ๊หࠥะสๆࠢส์ฯ๎ๅศฬํ็๏อ้ࠠๆสࠤฯำสศฮࠣว๏ࠦๆ้฻้๋ࠣࠦวๅะหีฮࠦแ๋ࠢๆ์ิ๐ࠠฤ๊ࠣห้ิศาหࠣๅ๏ࠦสฬสํฮࠥษึศใสฮ้่ࠥะ์ࠪሴ")+b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+drzqWFkSHD.SITESURLS[nR0ok9zju84rFUQl1YC(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬስ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+so4Z8OUJ5E+JZ45mOctiTszPNw1GVjxhep2Y(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫሶ")+qFghPAi5yz9Vf3NLwo0nuprl+drzqWFkSHD.SITESURLS[hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧሷ")][xD9WeoEAsX7]+so4Z8OUJ5E
	mlrXUnyLzPAhEIj8ix5Ztpu += MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯ࠩሸ")+qFghPAi5yz9Vf3NLwo0nuprl+drzqWFkSHD.SITESURLS[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩሹ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+so4Z8OUJ5E+pL73X0MYajJQG4n1qgD(u"ࠫࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠨሺ")+qFghPAi5yz9Vf3NLwo0nuprl+drzqWFkSHD.SITESURLS[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡑࡏࡅࡋࡢࡗࡔ࡛ࡒࡄࡇࡖࠫሻ")][xD9WeoEAsX7]+so4Z8OUJ5E
	mlrXUnyLzPAhEIj8ix5Ztpu += nR0ok9zju84rFUQl1YC(u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩሼ")+b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+drzqWFkSHD.SITESURLS[vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡇࡋࡏࡉࡘࡥࡓࡐࡗࡕࡇࡊ࡙ࠧሽ")][nUaVQsoA6EXcK4Odht5wCge0J8Pib]+so4Z8OUJ5E
	RsYWOkAC8t4iMUoBd0K(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨሾ"),rAYDiWlzm9MCU6x0GnROua(u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨሿ"),mlrXUnyLzPAhEIj8ix5Ztpu,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ቀ"))
	return
def yqj9AnCzihaSX2(C5CHpAfo9IdymNDOKaugcvbr2RW4qP):
	mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪቁ")+C5CHpAfo9IdymNDOKaugcvbr2RW4qP+rAYDiWlzm9MCU6x0GnROua(u"ࠬ࠯ࠧቂ"), NFGqKBLtvUZn1S3dau)
	return
def h4IsToyVmPgDkulwdx01CiqY():
	tvBhiQp5kIbKHMP6f(GTmHXIZUSdxRhMnqQKkO(u"࠭ࡳࡵࡱࡳࠫቃ"))
	mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(GTmHXIZUSdxRhMnqQKkO(u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨቄ"))
	return
def kbNUaBAmfIl4T9s():
	mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(W2Vv30i8qxSuItfsolPLdFZA(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧቅ"), NFGqKBLtvUZn1S3dau)
	return
def W3Or7Nfyegk6c():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,I6Bfzysrvb8DONZ(u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦร้ࠢสืฯิฯๆࠢࠥห้้๊ษ๊ิำ่ࠧࠦศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣห฻เืࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠩቆ"))
	return
def oO5NVaQWTdz9():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,kAz7WRYjrfGm(u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠห่ๅีࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭ቇ"))
	return
def Y0rdWVaSwpi1U(VVIYJL6ohZsdHbpfT84Bc=kAz7WRYjrfGm(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪቈ"),showDialogs=NFGqKBLtvUZn1S3dau):
	rFuOmIeV4l6 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(w9wfONXUP3(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ቉"))
	data = WWNb0XnUxOPL9gF.loads(rFuOmIeV4l6)
	sgOBACxdRYaLWUSIyunqe = data[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ቊ")][Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡷࡣ࡯ࡹࡪ࠭ቋ")]
	if hT1JIgqPQsUOZp5tjCX0E: sgOBACxdRYaLWUSIyunqe = sgOBACxdRYaLWUSIyunqe.encode(RMGz7OiD1e30P)
	if showDialogs:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭ቌ")+sgOBACxdRYaLWUSIyunqe+GTmHXIZUSdxRhMnqQKkO(u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫቍ")+VVIYJL6ohZsdHbpfT84Bc+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࠤฤࠧࠧ቎"))
		if e6f0ycMuYQEJraNLInmip!=Zb5cNeHWi6jP9SCYtUgR(u"࠲፲"): return pLwgjkuTs6CS
	oo3n0EuaHjYSz,HPosOxiU4aWkGD9myRErNFATh,uSzRpoTdFNEWvBkrDcK = FbW9VNmzAso8HRLIDgJ23fpy(VVIYJL6ohZsdHbpfT84Bc,pLwgjkuTs6CS,pLwgjkuTs6CS)
	if oo3n0EuaHjYSz:
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,ba49YvOK2Aw8Uhxt(u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭቏"))
		vv52HizJKaC = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(lRKCWnNi0Edr984eI(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩቐ")+VVIYJL6ohZsdHbpfT84Bc+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࠢࡾࡿࠪቑ"))
		oo3n0EuaHjYSz = NFGqKBLtvUZn1S3dau if lRKCWnNi0Edr984eI(u"ࠧࡐࡍࠪቒ") in vv52HizJKaC else pLwgjkuTs6CS
		f7epsRlYtMz4.sleep(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠳፳"))
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(B1YMtuvRAGNlJOkC46VyPKQE(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨቓ"))
	elif showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤํะแฺ์็ࠤฬ๊ฬๅัࠣห้๋ืๅ๊หࠫቔ"))
	return oo3n0EuaHjYSz
def xqlgIY936Oo2cfnzU1Kd5C8DPE():
	url = f9fOpCmLAEaW2Go(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨቕ")
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,pL73X0MYajJQG4n1qgD(u"ࠫࡌࡋࡔࠨቖ"),url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨ቗"))
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	wzVWqxHp9ldmDncb7t0uJkRS58 = AxTYMhRlfyskNc0X19dvwtS.findall(vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬቘ"),R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	wzVWqxHp9ldmDncb7t0uJkRS58 = wzVWqxHp9ldmDncb7t0uJkRS58[nUaVQsoA6EXcK4Odht5wCge0J8Pib].split(f9fOpCmLAEaW2Go(u"ࠧ࠮ࠩ቙"))[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	WCw8hmlZBuG = str(XqSerIMoFsRn2UQ1D5Alj6)
	EHaB0uwx2d4CfPrzbmZI6YL = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪቚ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+wzVWqxHp9ldmDncb7t0uJkRS58+so4Z8OUJ5E
	EHaB0uwx2d4CfPrzbmZI6YL += Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࡟ࡲࡡࡴࠧቛ")+lRKCWnNi0Edr984eI(u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไั์ࠣห๋ะࠠหีอาิ๋็้๋ࠡࠤ࠿ࠦࠠࠡࠩቜ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+WCw8hmlZBuG+so4Z8OUJ5E
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,EHaB0uwx2d4CfPrzbmZI6YL)
	return
def RXjma91YKrFtsvDoNP():
	a4FfTsi9DxM6,BIxsJPR8XGM,cdrJUb7tIzgB1nf8OvHWLPNDhFR = pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	EGRPifTx29k0lh4zp,epZslNK6v2UiEjDBC4Yg,roV9YKSL67WlqxwaInsUpe = pLwgjkuTs6CS,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Z5GzAmilhtF6VONkqx9KIe3CR2J = [W2Vv30i8qxSuItfsolPLdFZA(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩቝ"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ቞"),f9fOpCmLAEaW2Go(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ቟")]
	E2E9QlGMW6rmIRxnXka = RmBYtTu0ig6DbQM(Z5GzAmilhtF6VONkqx9KIe3CR2J)
	for fFwqoWYPMVRJDtN9m3bCihpz in Z5GzAmilhtF6VONkqx9KIe3CR2J:
		if fFwqoWYPMVRJDtN9m3bCihpz not in list(E2E9QlGMW6rmIRxnXka.keys()): continue
		JNLmUCZ106hznryPMFOaB,iiauAvV58xI2yhkz,KVhdiHr0Nfv8xBPp9awI4MlE,Tna8uNemc7osHLE,ggrN0KjzRqCkQIE53ABW,lrXZw1kTS9HKoO5,WiCEZm8nVgvaIBjRq = E2E9QlGMW6rmIRxnXka[fFwqoWYPMVRJDtN9m3bCihpz]
		if fFwqoWYPMVRJDtN9m3bCihpz==pYeVwat64v(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬበ"):
			EGRPifTx29k0lh4zp = JNLmUCZ106hznryPMFOaB
			epZslNK6v2UiEjDBC4Yg = iiauAvV58xI2yhkz+GTmHXIZUSdxRhMnqQKkO(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨቡ")+dOui5LJeABG0TYcMj(lrXZw1kTS9HKoO5)+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࠣ࠭ࠬቢ")
			roV9YKSL67WlqxwaInsUpe = Tna8uNemc7osHLE
		elif fFwqoWYPMVRJDtN9m3bCihpz==ba49YvOK2Aw8Uhxt(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬባ"):
			a4FfTsi9DxM6 = a4FfTsi9DxM6 or JNLmUCZ106hznryPMFOaB
			BIxsJPR8XGM += pbmKZA1w7L4zHjOM(u"ࠫࠥࠦࠬࠡࠢࠪቤ")+iiauAvV58xI2yhkz+CCWqR3dmtzw6xoIX41(u"ࠬࠦࠠࠡࠢࠫࠤࠬብ")+dOui5LJeABG0TYcMj(lrXZw1kTS9HKoO5)+hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࠠࠪࠩቦ")
			cdrJUb7tIzgB1nf8OvHWLPNDhFR += MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠡࠢ࠯ࠤࠥ࠭ቧ")+Tna8uNemc7osHLE
		elif fFwqoWYPMVRJDtN9m3bCihpz==CCWqR3dmtzw6xoIX41(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧቨ"):
			l5QSfCXqPR760NA8g19 = JNLmUCZ106hznryPMFOaB
			dQYu8mUbsH7 = iiauAvV58xI2yhkz+zWBnYSGIatjXVC(u"ࠩࠣࠤࠥࠦࠨࠡࠩቩ")+dOui5LJeABG0TYcMj(lrXZw1kTS9HKoO5)+GTmHXIZUSdxRhMnqQKkO(u"ࠪࠤ࠮࠭ቪ")
			n4ipB9SMbvRP3uzwLtUN6xZAyj = Tna8uNemc7osHLE
	BIxsJPR8XGM = BIxsJPR8XGM.strip(djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫࠥࠦࠬࠡࠢࠪቫ"))
	cdrJUb7tIzgB1nf8OvHWLPNDhFR = cdrJUb7tIzgB1nf8OvHWLPNDhFR.strip(W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࠦࠠ࠭ࠢࠣࠫቬ"))
	OeF5CiHPAUrk9TlYdjg  = zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫቭ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+roV9YKSL67WlqxwaInsUpe+so4Z8OUJ5E
	OeF5CiHPAUrk9TlYdjg += b8sk5WyPoz03pXhRx+pYeVwat64v(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩቮ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+epZslNK6v2UiEjDBC4Yg+so4Z8OUJ5E
	OeF5CiHPAUrk9TlYdjg += KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨ࡞ࡱࡠࡳ࠭ቯ")+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่ืฯ๎ฯฺࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧተ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+cdrJUb7tIzgB1nf8OvHWLPNDhFR+so4Z8OUJ5E
	OeF5CiHPAUrk9TlYdjg += b8sk5WyPoz03pXhRx+zWBnYSGIatjXVC(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬቱ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+BIxsJPR8XGM+so4Z8OUJ5E
	OeF5CiHPAUrk9TlYdjg += Zb5cNeHWi6jP9SCYtUgR(u"ࠫࡡࡴ࡜࡯ࠩቲ")+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩታ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+n4ipB9SMbvRP3uzwLtUN6xZAyj+so4Z8OUJ5E
	OeF5CiHPAUrk9TlYdjg += b8sk5WyPoz03pXhRx+pbmKZA1w7L4zHjOM(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧቴ")+oamlxBqLdu4ZM9nQrbIAhS5Pg7+dQYu8mUbsH7+so4Z8OUJ5E
	JNLmUCZ106hznryPMFOaB = EGRPifTx29k0lh4zp or a4FfTsi9DxM6
	if JNLmUCZ106hznryPMFOaB:
		header = kAz7WRYjrfGm(u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩት")
		aenBI6927xL8SojFDwbuVNMCU4H = pL73X0MYajJQG4n1qgD(u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠩቶ")
	else:
		header = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪቷ")
		aenBI6927xL8SojFDwbuVNMCU4H = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬቸ")
	XXB5x24zvVyJpTIYQnmSE0WFkiC = djapWhrveLJbgnViDftFNY05ylq1S(u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬቹ")
	MMcdLWoFbyTej8xm6Qf9C1vhS43wP = OeF5CiHPAUrk9TlYdjg+GTmHXIZUSdxRhMnqQKkO(u"ࠬࡢ࡮࡝ࡰࠪቺ")+aenBI6927xL8SojFDwbuVNMCU4H+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭࡜࡯࡞ࡱࠫቻ")+XXB5x24zvVyJpTIYQnmSE0WFkiC
	RsYWOkAC8t4iMUoBd0K(rAYDiWlzm9MCU6x0GnROua(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ቼ"),header,MMcdLWoFbyTej8xm6Qf9C1vhS43wP,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫች"))
	return JNLmUCZ106hznryPMFOaB
def mVyYk8a2Mxzh7oWD15wBZ(fFwqoWYPMVRJDtN9m3bCihpz,WiCEZm8nVgvaIBjRq,showDialogs):
	oo3n0EuaHjYSz = pLwgjkuTs6CS
	if showDialogs:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬቾ"))
		if e6f0ycMuYQEJraNLInmip!=xD9WeoEAsX7: return pLwgjkuTs6CS
	ApIfX6dqyrwSYolDOhcN5Qsm = UNP40uFefR(WiCEZm8nVgvaIBjRq,{},showDialogs)
	if ApIfX6dqyrwSYolDOhcN5Qsm:
		SWa36GuHCQqwNvoMUI9 = oNlez5gnM9x2B4.path.join(BHyCtoKZYiVSqaAGdMxDbflr5U,fFwqoWYPMVRJDtN9m3bCihpz)
		RRAoUt0ihbYj(SWa36GuHCQqwNvoMUI9,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
		import zipfile as diRDSFTh1WwnsqQXPG48zJBKUN02fM,io as rJE2mM947cPiSBUT6x8VYIOK
		eesIMybNAa7lD8Lr1kuYjz = rJE2mM947cPiSBUT6x8VYIOK.BytesIO(ApIfX6dqyrwSYolDOhcN5Qsm)
		try:
			R8ReMBN5rjQTcDAf4ltk2v = diRDSFTh1WwnsqQXPG48zJBKUN02fM.ZipFile(eesIMybNAa7lD8Lr1kuYjz)
			R8ReMBN5rjQTcDAf4ltk2v.extractall(BHyCtoKZYiVSqaAGdMxDbflr5U)
			f7epsRlYtMz4.sleep(xD9WeoEAsX7)
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(f9fOpCmLAEaW2Go(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧቿ"))
			f7epsRlYtMz4.sleep(xD9WeoEAsX7)
			oo3n0EuaHjYSz = YZfG0x9uriTo(fFwqoWYPMVRJDtN9m3bCihpz)
		except: oo3n0EuaHjYSz = pLwgjkuTs6CS
	if showDialogs:
		if oo3n0EuaHjYSz: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pbmKZA1w7L4zHjOM(u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨኀ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,YzlId3Fs6vpehcbLGj0UaO(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪኁ"))
	return oo3n0EuaHjYSz
def dJv9nZwNPYyes2zKA7rIX6Rgqp(fFwqoWYPMVRJDtN9m3bCihpz,showDialogs=NFGqKBLtvUZn1S3dau):
	if showDialogs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: showDialogs = NFGqKBLtvUZn1S3dau
	KmaZek1QXv7Mzy9ItgRcnN = wJrKeyNqk1st40T([fFwqoWYPMVRJDtN9m3bCihpz])
	lRokxS3He7zj2iI,QW0galkKb9582prHoGUtBZiRn3Oh = KmaZek1QXv7Mzy9ItgRcnN[fFwqoWYPMVRJDtN9m3bCihpz]
	if QW0galkKb9582prHoGUtBZiRn3Oh:
		oo3n0EuaHjYSz = NFGqKBLtvUZn1S3dau
		if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,djapWhrveLJbgnViDftFNY05ylq1S(u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨኂ")+fFwqoWYPMVRJDtN9m3bCihpz+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪኃ"))
	else:
		oo3n0EuaHjYSz = pLwgjkuTs6CS
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨኄ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O+fFwqoWYPMVRJDtN9m3bCihpz+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠩࠣࡠࡳࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ฿๐ัࠡ็ไ฽้ฯࠠฤ๊ࠣ฾๏ืࠠๆ๊ฯ์ิฯ้ࠠษ็ฬึ์วๆฮࠣฬาอฬสࠢ็๋ฬࠦ࠮้ࠡ็ࠤฯื๊ะࠢอฯอ๐ส๊ࠡอๅ฾๐ไ้ࠡำ๋ࠥอไฦุสๅฮࠦวๅฤ้ࠤฤ࠭ኅ"))
		if e6f0ycMuYQEJraNLInmip==KKCrwPdOgGl(u"࠴፴"):
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(f9fOpCmLAEaW2Go(u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪኆ")+fFwqoWYPMVRJDtN9m3bCihpz+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࠮࠭ኇ"))
			f7epsRlYtMz4.sleep(hWRvZOYtjme9QNnV41u0Mswb(u"࠵፵"))
			mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬኈ"))
			f7epsRlYtMz4.sleep(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠶፶"))
			while mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getCondVisibility(nR0ok9zju84rFUQl1YC(u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪ኉")): f7epsRlYtMz4.sleep(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷፷"))
			oo3n0EuaHjYSz = YZfG0x9uriTo(fFwqoWYPMVRJDtN9m3bCihpz)
			if showDialogs and oo3n0EuaHjYSz: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧห็ࠣๅา฻ࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ์์๐ࠠศๆล๊ࠥาว่ิฬࠤ้๊วิฬัำฬ๋ࠧኊ"))
			elif showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨใื่ࠥ็๊ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯࠠ࠯๋ࠢห้ำไ้๋ࠡࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๆ่ࠣาฬืฬࠡษ็ฬึ์วๆฮࠪኋ"))
	return oo3n0EuaHjYSz
def IIADQXp1H0TvsEVgzPLdo(showDialogs):
	if not showDialogs: e6f0ycMuYQEJraNLInmip = NFGqKBLtvUZn1S3dau
	else: e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(pYeVwat64v(u"ࠩࡦࡩࡳࡺࡥࡳࠩኌ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦร็ࠢอ฻้ฮࠠๆ่ࠣ็ํี๊ࠡใะูࠥ๎สฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥลࠧኍ"))
	if e6f0ycMuYQEJraNLInmip==lRKCWnNi0Edr984eI(u"࠱፸"):
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(kAz7WRYjrfGm(u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧ኎"))
		if showDialogs:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pbmKZA1w7L4zHjOM(u"ࠬะๅࠡวิืฬุ๊ࠠๆหࠤส๊้ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦวๅาํࠤๆ๐ࠠอ้สึ่ࠦไไ์ࠣ๎็๎ๅࠡสอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤ࠳ࠦศๆษࠣๅ๏ํวࠡฬะำ๏ั่ࠠาสࠤฬ๊ศา่ส้ั่ࠦหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬ኏"))
	return
def naz7pycbdu9WEDgX0Z1ltvf():
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫነ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨኑ"))
	xqlgIY936Oo2cfnzU1Kd5C8DPE()
	JNLmUCZ106hznryPMFOaB = RXjma91YKrFtsvDoNP()
	if JNLmUCZ106hznryPMFOaB:
		HYh2mJEufvP1Okd4I8(NFGqKBLtvUZn1S3dau)
		IIADQXp1H0TvsEVgzPLdo(NFGqKBLtvUZn1S3dau)
		GGfDYrMCxAh59v4bSaXpnO1qHkIK(pLwgjkuTs6CS)
	return
def YZfG0x9uriTo(fFwqoWYPMVRJDtN9m3bCihpz):
	Ubud2NhHKRnMTvI5mprQBVqk80 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(nR0ok9zju84rFUQl1YC(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫኒ")+fFwqoWYPMVRJDtN9m3bCihpz+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧና"))
	succeeded = NFGqKBLtvUZn1S3dau if KKCrwPdOgGl(u"ࠪࡓࡐ࠭ኔ") in Ubud2NhHKRnMTvI5mprQBVqk80 else pLwgjkuTs6CS
	return succeeded
def CqzKnFtTWy4VHk7ZaOiGhR(fFwqoWYPMVRJDtN9m3bCihpz):
	Ubud2NhHKRnMTvI5mprQBVqk80 = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executeJSONRPC(YzlId3Fs6vpehcbLGj0UaO(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧን")+fFwqoWYPMVRJDtN9m3bCihpz+Zb5cNeHWi6jP9SCYtUgR(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡪࡦࡲࡳࡦࡿࢀࠫኖ"))
	succeeded = NFGqKBLtvUZn1S3dau if ba49YvOK2Aw8Uhxt(u"࠭ࡏࡌࠩኗ") in Ubud2NhHKRnMTvI5mprQBVqk80 else pLwgjkuTs6CS
	return succeeded
def FbW9VNmzAso8HRLIDgJ23fpy(fFwqoWYPMVRJDtN9m3bCihpz,showDialogs,dd0AX6Dz5LeCwRJtOhrZ,E2E9QlGMW6rmIRxnXka=None):
	e6f0ycMuYQEJraNLInmip,succeeded,HPosOxiU4aWkGD9myRErNFATh,iiauAvV58xI2yhkz = NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS,rAYDiWlzm9MCU6x0GnROua(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧኘ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if not E2E9QlGMW6rmIRxnXka: E2E9QlGMW6rmIRxnXka = RmBYtTu0ig6DbQM([fFwqoWYPMVRJDtN9m3bCihpz])
	if fFwqoWYPMVRJDtN9m3bCihpz in list(E2E9QlGMW6rmIRxnXka.keys()):
		JNLmUCZ106hznryPMFOaB,iiauAvV58xI2yhkz,KVhdiHr0Nfv8xBPp9awI4MlE,Tna8uNemc7osHLE,ggrN0KjzRqCkQIE53ABW,lrXZw1kTS9HKoO5,WiCEZm8nVgvaIBjRq = E2E9QlGMW6rmIRxnXka[fFwqoWYPMVRJDtN9m3bCihpz]
		if lrXZw1kTS9HKoO5==djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡩࡲࡳࡩ࠭ኙ"):
			succeeded,HPosOxiU4aWkGD9myRErNFATh = NFGqKBLtvUZn1S3dau,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪኚ")
			if dd0AX6Dz5LeCwRJtOhrZ and showDialogs:
				e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,kAz7WRYjrfGm(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠไ๊า๎ࠥ๐ำหะา้ࠥษฮาࠢศูิอัࠡ็อ์ๆืࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠๅ้ำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪኛ")+fFwqoWYPMVRJDtN9m3bCihpz+KKCrwPdOgGl(u"ࠫࡡࡴ࡜࡯้็ࠤฯื๊ะࠢศ฽ฬีษࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอ๋ࠥัสࠢฦาึ๏ࠧኜ"))
				if e6f0ycMuYQEJraNLInmip:
					succeeded = mVyYk8a2Mxzh7oWD15wBZ(fFwqoWYPMVRJDtN9m3bCihpz,WiCEZm8nVgvaIBjRq,pLwgjkuTs6CS)
					if succeeded:
						HPosOxiU4aWkGD9myRErNFATh = I6Bfzysrvb8DONZ(u"ࠬࡸࡥࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪኝ")
						if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,ba49YvOK2Aw8Uhxt(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢ์ั๎ฯสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮลฺษาอࠥะหษ์อ๋ฬࡢ࡮࡝ࡰࠪኞ")+fFwqoWYPMVRJDtN9m3bCihpz)
					else:
						HPosOxiU4aWkGD9myRErNFATh = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧኟ")
						w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,nR0ok9zju84rFUQl1YC(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡว฼หิฯࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨአ")+fFwqoWYPMVRJDtN9m3bCihpz)
		else:
			if showDialogs:
				if lrXZw1kTS9HKoO5==jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫኡ"): mlrXUnyLzPAhEIj8ix5Ztpu = f9fOpCmLAEaW2Go(u"้ࠪฯ๎โโหࠪኢ")
				elif lrXZw1kTS9HKoO5==KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠫࡴࡲࡤࠨኣ"): mlrXUnyLzPAhEIj8ix5Ztpu = W2Vv30i8qxSuItfsolPLdFZA(u"่ࠬฯ๋็ฬࠫኤ")
				elif lrXZw1kTS9HKoO5==jBbkfIJSDqcVwl8irzy4Z3O(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧእ"): mlrXUnyLzPAhEIj8ix5Ztpu = ba49YvOK2Aw8Uhxt(u"ࠧ฻์ิࠤ๊ัศหหࠪኦ")
				e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,lRKCWnNi0Edr984eI(u"ࠨ้ำ๋ࠥอไฦุสๅฮࠦࠧኧ")+mlrXUnyLzPAhEIj8ix5Ztpu+KKCrwPdOgGl(u"ࠩࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฤࠧ࡜࡯࡞ࡱࠫከ")+fFwqoWYPMVRJDtN9m3bCihpz)
			if not e6f0ycMuYQEJraNLInmip: HPosOxiU4aWkGD9myRErNFATh = bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬኩ")
			else:
				if lrXZw1kTS9HKoO5==fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ኪ"):
					succeeded = YZfG0x9uriTo(fFwqoWYPMVRJDtN9m3bCihpz)
					if succeeded:
						HPosOxiU4aWkGD9myRErNFATh = pYeVwat64v(u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ካ")
						if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,YzlId3Fs6vpehcbLGj0UaO(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫኬ")+fFwqoWYPMVRJDtN9m3bCihpz)
					elif showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,f9fOpCmLAEaW2Go(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪክ")+fFwqoWYPMVRJDtN9m3bCihpz)
				elif lrXZw1kTS9HKoO5 in [KKCrwPdOgGl(u"ࠨࡱ࡯ࡨࠬኮ"),pL73X0MYajJQG4n1qgD(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪኯ")]:
					succeeded = mVyYk8a2Mxzh7oWD15wBZ(fFwqoWYPMVRJDtN9m3bCihpz,WiCEZm8nVgvaIBjRq,pLwgjkuTs6CS)
					if succeeded:
						if lrXZw1kTS9HKoO5==zWBnYSGIatjXVC(u"ࠪࡳࡱࡪࠧኰ"): HPosOxiU4aWkGD9myRErNFATh = jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬ኱")
						elif lrXZw1kTS9HKoO5==ba49YvOK2Aw8Uhxt(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ኲ"): HPosOxiU4aWkGD9myRErNFATh = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩኳ")
						iiauAvV58xI2yhkz = Tna8uNemc7osHLE
						if showDialogs:
							if HPosOxiU4aWkGD9myRErNFATh==ba49YvOK2Aw8Uhxt(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨኴ"): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ็ี๊ๆหࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหฯา๎ะํว࡝ࡰ࡟ࡲࠬኵ")+fFwqoWYPMVRJDtN9m3bCihpz)
							elif HPosOxiU4aWkGD9myRErNFATh==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬ኶"): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫ኷")+fFwqoWYPMVRJDtN9m3bCihpz)
					elif showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤฯำฯ๋อࠣวํࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧኸ")+fFwqoWYPMVRJDtN9m3bCihpz)
	elif showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,rAYDiWlzm9MCU6x0GnROua(u"๊ࠬไฤีไࠤ࠳࠴่ࠠา๊ࠤฬ๊ลืษไอࠥเ๊า่ࠢ์ั๎ฯสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪኹ")+fFwqoWYPMVRJDtN9m3bCihpz)
	return succeeded,HPosOxiU4aWkGD9myRErNFATh,iiauAvV58xI2yhkz
def Q8Qr2h3sHpeE9JdCIF6j401AfZzWMw(fFwqoWYPMVRJDtN9m3bCihpz,showDialogs,ACcYnF0LIsV):
	mRbFSLVp2TWJaO8YZ = nhGFNAkSgW2qopEYeT9jz8ULatl.connect(HZ6XvFJC7kayRAL)
	mRbFSLVp2TWJaO8YZ.text_factory = str
	Ew0cWnQIKTvoZDX = mRbFSLVp2TWJaO8YZ.cursor()
	succeeded,NXJykW5vrz8aOIqsBpcx0RDoUw = NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS
	try:
		jKH0n61bFYO7gm9UJI5deQkClw = w9wfONXUP3(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨኺ")
		Ew0cWnQIKTvoZDX.execute(pYeVwat64v(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬኻ")+fFwqoWYPMVRJDtN9m3bCihpz+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࠤࠣ࠿ࠬኼ"))
		GopHWf7DAQF = Ew0cWnQIKTvoZDX.fetchall()
		if GopHWf7DAQF and jKH0n61bFYO7gm9UJI5deQkClw not in str(GopHWf7DAQF): Ew0cWnQIKTvoZDX.execute(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭ኽ")+jKH0n61bFYO7gm9UJI5deQkClw+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩኾ")+fFwqoWYPMVRJDtN9m3bCihpz+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࠧࠦ࠻ࠨ኿"))
		PNo5nQkurDil = pbmKZA1w7L4zHjOM(u"ࠬࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠨዀ") if hT1JIgqPQsUOZp5tjCX0E else slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠬ዁")
		Ew0cWnQIKTvoZDX.execute(kAz7WRYjrfGm(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨዂ")+PNo5nQkurDil+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ዃ")+fFwqoWYPMVRJDtN9m3bCihpz+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩࠥࠤࡀ࠭ዄ"))
		GopHWf7DAQF = Ew0cWnQIKTvoZDX.fetchall()
		if GopHWf7DAQF:
			if showDialogs: e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧዅ")+fFwqoWYPMVRJDtN9m3bCihpz+CCWqR3dmtzw6xoIX41(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫ዆")+qFghPAi5yz9Vf3NLwo0nuprl+hWRvZOYtjme9QNnV41u0Mswb(u"ࠬࠦๅห๊ๅๅࠥ๎ไศࠢํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ็ู๋ๆ๊ࠤฬ๊ย็ࠢยࠥࠦࠦࠧ዇")+so4Z8OUJ5E+w9wfONXUP3(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥห๊ใษไ๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠึ์ส๊ฮࠦศา่ส้ัูࠦๆษาࠫወ"))
			else: e6f0ycMuYQEJraNLInmip = xD9WeoEAsX7
			if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
				NXJykW5vrz8aOIqsBpcx0RDoUw = NFGqKBLtvUZn1S3dau
				Ew0cWnQIKTvoZDX.execute(GTmHXIZUSdxRhMnqQKkO(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࠭ዉ")+PNo5nQkurDil+Zb5cNeHWi6jP9SCYtUgR(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ዊ")+fFwqoWYPMVRJDtN9m3bCihpz+kAz7WRYjrfGm(u"ࠩࠥࠤࡀ࠭ዋ"))
		elif ACcYnF0LIsV:
			if showDialogs: e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,W2Vv30i8qxSuItfsolPLdFZA(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧዌ")+fFwqoWYPMVRJDtN9m3bCihpz+zWBnYSGIatjXVC(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫው")+qFghPAi5yz9Vf3NLwo0nuprl+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠬࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢࠪዎ")+so4Z8OUJ5E+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥะแฺ์็๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠึ์ส๊ฮࠦศา่ส้ัูࠦๆษาࠫዏ"))
			else: e6f0ycMuYQEJraNLInmip = xD9WeoEAsX7
			if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
				NXJykW5vrz8aOIqsBpcx0RDoUw = NFGqKBLtvUZn1S3dau
				if hT1JIgqPQsUOZp5tjCX0E: Ew0cWnQIKTvoZDX.execute(Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ዐ")+PNo5nQkurDil+ba49YvOK2Aw8Uhxt(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨዑ")+fFwqoWYPMVRJDtN9m3bCihpz+GTmHXIZUSdxRhMnqQKkO(u"ࠩࠥ࠭ࠥࡁࠧዒ"))
				else: Ew0cWnQIKTvoZDX.execute(pbmKZA1w7L4zHjOM(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩዓ")+PNo5nQkurDil+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨዔ")+fFwqoWYPMVRJDtN9m3bCihpz+zWBnYSGIatjXVC(u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬዕ"))
	except: succeeded = pLwgjkuTs6CS
	mRbFSLVp2TWJaO8YZ.commit()
	mRbFSLVp2TWJaO8YZ.close()
	if NXJykW5vrz8aOIqsBpcx0RDoUw:
		f7epsRlYtMz4.sleep(W2Vv30i8qxSuItfsolPLdFZA(u"࠲፹"))
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪዖ"))
		f7epsRlYtMz4.sleep(rAYDiWlzm9MCU6x0GnROua(u"࠳፺"))
		if showDialogs:
			if succeeded: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,W2Vv30i8qxSuItfsolPLdFZA(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣฮาี๊ฬࠢส่ส฼วโหࠣࡠࡳࡢ࡮ࠨ዗")+fFwqoWYPMVRJDtN9m3bCihpz)
			else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,CCWqR3dmtzw6xoIX41(u"ࠨใื่ฯูࠦๆๆํอࠥหีๅษะࠤฯำฯ๋อࠣห้หึศใฬࠤࡡࡴ࡜࡯ࠩዘ")+fFwqoWYPMVRJDtN9m3bCihpz)
	return NXJykW5vrz8aOIqsBpcx0RDoUw
def TyL7XGl6Fob(Z5GzAmilhtF6VONkqx9KIe3CR2J,showDialogs,dd0AX6Dz5LeCwRJtOhrZ,ACcYnF0LIsV):
	E2E9QlGMW6rmIRxnXka = RmBYtTu0ig6DbQM(Z5GzAmilhtF6VONkqx9KIe3CR2J)
	iOfkslgW0paB = pLwgjkuTs6CS
	for fFwqoWYPMVRJDtN9m3bCihpz in Z5GzAmilhtF6VONkqx9KIe3CR2J:
		succeeded,HPosOxiU4aWkGD9myRErNFATh,iiauAvV58xI2yhkz = FbW9VNmzAso8HRLIDgJ23fpy(fFwqoWYPMVRJDtN9m3bCihpz,showDialogs,dd0AX6Dz5LeCwRJtOhrZ,E2E9QlGMW6rmIRxnXka)
		NXJykW5vrz8aOIqsBpcx0RDoUw = Q8Qr2h3sHpeE9JdCIF6j401AfZzWMw(fFwqoWYPMVRJDtN9m3bCihpz,showDialogs,ACcYnF0LIsV)
		if NXJykW5vrz8aOIqsBpcx0RDoUw: iOfkslgW0paB = NFGqKBLtvUZn1S3dau
	if iOfkslgW0paB:
		f7epsRlYtMz4.sleep(awSUTRNMkdIW7sFEvnHD2mLY(u"࠴፻"))
		mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.executebuiltin(KKCrwPdOgGl(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ዙ"))
		f7epsRlYtMz4.sleep(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠵፼"))
	if showDialogs:
		if len(Z5GzAmilhtF6VONkqx9KIe3CR2J)>ba49YvOK2Aw8Uhxt(u"࠶፽"): w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪฮ๊ࠦศ็ฮสัࠥ็อึࠢฯ้๏฿ࠠศๆศฺฬ็วหࠩዚ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,GTmHXIZUSdxRhMnqQKkO(u"ࠫฯ๋ࠠษ่ฯหาࠦแฮืࠣห้หึศใฬࡠࡳࡢ࡮ࠨዛ")+Z5GzAmilhtF6VONkqx9KIe3CR2J[kAz7WRYjrfGm(u"࠶፾")])
	return
def HYh2mJEufvP1Okd4I8(showDialogs):
	gghJEM6queTlN = [ba49YvOK2Aw8Uhxt(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪዜ"),I6Bfzysrvb8DONZ(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨዝ"),pbmKZA1w7L4zHjOM(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫዞ"),KKCrwPdOgGl(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨዟ")]
	d2rFAlngBIcM = [W2Vv30i8qxSuItfsolPLdFZA(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫዠ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫዡ"),w9wfONXUP3(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧዢ"),f9fOpCmLAEaW2Go(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧዣ"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧዤ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࠫዥ")]
	for fFwqoWYPMVRJDtN9m3bCihpz in d2rFAlngBIcM: CqzKnFtTWy4VHk7ZaOiGhR(fFwqoWYPMVRJDtN9m3bCihpz)
	TyL7XGl6Fob(gghJEM6queTlN,showDialogs,pLwgjkuTs6CS,pLwgjkuTs6CS)
	return