# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'DAILYMOTION'
qBAgzkG9oCL = '_DLM_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
talv2Us5Kn1 = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][1]
BZ1UIeSfWMxb6X = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][2]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text,type,GpwRnQ6q2o1fv0HbJTs):
	if	 mode==400: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==401: Ubud2NhHKRnMTvI5mprQBVqk80 = CCtuepQFAlbNWUa(url,text)
	elif mode==402: Ubud2NhHKRnMTvI5mprQBVqk80 = OFfYCKioPkEtmnrl0HNe(url,text)
	elif mode==403: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url,text)
	elif mode==404: Ubud2NhHKRnMTvI5mprQBVqk80 = SgslnAc0RXNxw(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==405: Ubud2NhHKRnMTvI5mprQBVqk80 = rr7LvCchARPNGoFm61zxQOg(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==406: Ubud2NhHKRnMTvI5mprQBVqk80 = LGYArySDmNTOX(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==407: Ubud2NhHKRnMTvI5mprQBVqk80 = vA9GpgPCTQfLJ7OjSB0(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==408: Ubud2NhHKRnMTvI5mprQBVqk80 = RGV20bq6IaSHUncJ1sM(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==409: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==411: Ubud2NhHKRnMTvI5mprQBVqk80 = fmjh4CuMDwWF2Z68EOkoBrcGv(url,text)
	elif mode==414: Ubud2NhHKRnMTvI5mprQBVqk80 = Z8QG2mg3OVPWAl4q(text)
	elif mode==415: Ubud2NhHKRnMTvI5mprQBVqk80 = bAkFnigvKuweyJoOD7a36I(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==416: Ubud2NhHKRnMTvI5mprQBVqk80 = Spl569ROx8f4ZnukFIAErWP(text,GpwRnQ6q2o1fv0HbJTs)
	elif mode==417: Ubud2NhHKRnMTvI5mprQBVqk80 = RIJAyLUEbONhQCjnl9Sig403(url,GpwRnQ6q2o1fv0HbJTs)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الرئيسية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,414)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن فيديوهات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'videos?sortBy=','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن آخر الفيديوهات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن الفيديوهات الأكثر مشاهدة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن قوائم التشغيل',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'playlists','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن مستخدم',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'channels','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن بث حي',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'lives','_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث عن هاشتاك',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,409,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'hashtags','_REMEMBERRESULTS_')
	return
def OFfYCKioPkEtmnrl0HNe(url,HQkaKeGbJn8xUowtmNF5cZdW):
	if '/dm_' in url:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.headers
		if 'Location' in list(headers.keys()): url = S7EgasGcYdIo+headers['Location']
	HQkaKeGbJn8xUowtmNF5cZdW = qFghPAi5yz9Vf3NLwo0nuprl+HQkaKeGbJn8xUowtmNF5cZdW+so4Z8OUJ5E
	HQkaKeGbJn8xUowtmNF5cZdW = vy2dhqiSGpRtgCjUKV(HQkaKeGbJn8xUowtmNF5cZdW)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: بث حي',url,411,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'channel_lives_now')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: آخر الفيديوهات',url+'/videos',408)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: المميزة',url,411,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'channel_featured_videos')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: قوائم التشغيل',url+'/playlists',407)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: قنوات ذات صلة',url,411,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'channel_related_channel')
	return
def vy2dhqiSGpRtgCjUKV(title):
	title = title.rstrip('\\').strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace('\\\\','\\')
	title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
	return title
def QgIZSJdUhsEnup8GPz3(url,llcJk3NaZMHLtyWCgd5b):
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2([url],mI6ayKxBvjd4CRthL,'video',url)
	return
def SgslnAc0RXNxw(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	search = search.split('/videos')[0]
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	if sort==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysortmethod',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	else: eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = S7EgasGcYdIo+'/search/'+search+'/videos'
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"videos"(.*?)"VideoConnection"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,title,zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW,w03zWJvcXaCUySB6HIq4mVe,RRx0ri8bETI in items:
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+id
			title = vy2dhqiSGpRtgCjUKV(title)
			llcJk3NaZMHLtyWCgd5b = zuvjg1oUGsM3rcbdPXe5N+'::'+HQkaKeGbJn8xUowtmNF5cZdW
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,llcJk3NaZMHLtyWCgd5b)
		if '"hasNextPage":true' in R8AE9e4mYxVhusL3Q:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,404,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def rr7LvCchARPNGoFm61zxQOg(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	url = S7EgasGcYdIo+'/search/'+search+'/playlists'
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for id,name,zG7iYcbOgP2F8wWlrRDTyE,zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW,RRx0ri8bETI,count in items:
		RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
		cX2SpPxGLmADTKl = S7EgasGcYdIo+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = vy2dhqiSGpRtgCjUKV(title)
		llcJk3NaZMHLtyWCgd5b = zuvjg1oUGsM3rcbdPXe5N+'::'+HQkaKeGbJn8xUowtmNF5cZdW
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,401,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,llcJk3NaZMHLtyWCgd5b)
	if '"hasNextPage":true' in R8AE9e4mYxVhusL3Q:
		GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,405,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def LGYArySDmNTOX(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	url = S7EgasGcYdIo+'/search/'+search+'/channels'
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"channels"(.*?)"ChannelConnection"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,name,RRx0ri8bETI in items:
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+id
			title = 'USER:  '+name
			title = vy2dhqiSGpRtgCjUKV(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,402,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,name)
		if '"hasNextPage":true' in R8AE9e4mYxVhusL3Q:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,406,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def Z8QG2mg3OVPWAl4q(mAVxgev9CTXd7LrShF):
	eBjxVKSvQC1 = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['home']['neon']['sections']['edges']
		if not mAVxgev9CTXd7LrShF:
			iiWkyfBAj02qeX = []
			for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
				qqwDxBgS9cI4luV8dJeKkWROUAi = FfkU5bQno09gtyCJADWPRs6dEa['node']['title']
				if qqwDxBgS9cI4luV8dJeKkWROUAi not in iiWkyfBAj02qeX: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+qqwDxBgS9cI4luV8dJeKkWROUAi,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,414,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,qqwDxBgS9cI4luV8dJeKkWROUAi)
				iiWkyfBAj02qeX.append(qqwDxBgS9cI4luV8dJeKkWROUAi)
		else:
			for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
				qqwDxBgS9cI4luV8dJeKkWROUAi = FfkU5bQno09gtyCJADWPRs6dEa['node']['title']
				if qqwDxBgS9cI4luV8dJeKkWROUAi==mAVxgev9CTXd7LrShF:
					OeZ30ucbU5qzTv = FfkU5bQno09gtyCJADWPRs6dEa['node']['components']['edges']
					for EQLq9U5GponRBlNIgHX7VDyeYc1Ozs in OeZ30ucbU5qzTv:
						w03zWJvcXaCUySB6HIq4mVe = str(EQLq9U5GponRBlNIgHX7VDyeYc1Ozs['node']['duration'])
						title = kd8ZhJPCe7QzxLgij3TEHlGtOv(EQLq9U5GponRBlNIgHX7VDyeYc1Ozs['node']['title'])
						title = title.replace('\/','/')
						LW3eFsIR47SNzU8uop5AEKYdhkiT = EQLq9U5GponRBlNIgHX7VDyeYc1Ozs['node']['xid']
						RRx0ri8bETI = EQLq9U5GponRBlNIgHX7VDyeYc1Ozs['node']['thumbnailx480']
						RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
						cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
						w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
	return
def bAkFnigvKuweyJoOD7a36I(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	url = S7EgasGcYdIo+'/search/'+search+'/lives'
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		try: Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['search']['lives']['edges']
		except: Myulm5G7cTVjWQONotAhaniZX9 = []
		for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
			name = FfkU5bQno09gtyCJADWPRs6dEa['node']['title']
			name = kd8ZhJPCe7QzxLgij3TEHlGtOv(name)
			LW3eFsIR47SNzU8uop5AEKYdhkiT = FfkU5bQno09gtyCJADWPRs6dEa['node']['xid']
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
			w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+'LIVE: '+name,cX2SpPxGLmADTKl,403)
		if '"hasNextPage":true' in xxCo2yGh1duw8TYvF:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,415,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def iioBuUvGZH(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	url = S7EgasGcYdIo+'/search/'+search+'/topics'
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		try: Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['search']['topics']['edges']
		except: Myulm5G7cTVjWQONotAhaniZX9 = []
		for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
			name = FfkU5bQno09gtyCJADWPRs6dEa['node']['name']
			LW3eFsIR47SNzU8uop5AEKYdhkiT = FfkU5bQno09gtyCJADWPRs6dEa['node']['xid']
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/topic/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'TOPIC: '+name,cX2SpPxGLmADTKl,413)
		if '"hasNextPage":true' in xxCo2yGh1duw8TYvF:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,412,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def vOrhCzaqT0(url,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	LW3eFsIR47SNzU8uop5AEKYdhkiT = url.split('/')[-1]
	eBjxVKSvQC1 = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mytopicid',LW3eFsIR47SNzU8uop5AEKYdhkiT)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['topic']['videos']['edges']
		for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
			w03zWJvcXaCUySB6HIq4mVe = str(FfkU5bQno09gtyCJADWPRs6dEa['node']['duration'])
			title = kd8ZhJPCe7QzxLgij3TEHlGtOv(FfkU5bQno09gtyCJADWPRs6dEa['node']['title'])
			title = title.replace('\/','/')
			LW3eFsIR47SNzU8uop5AEKYdhkiT = FfkU5bQno09gtyCJADWPRs6dEa['node']['xid']
			RRx0ri8bETI = FfkU5bQno09gtyCJADWPRs6dEa['node']['thumbnailx480']
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
		if '"hasNextPage":true' in xxCo2yGh1duw8TYvF:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,413,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs)
	return
def CCtuepQFAlbNWUa(url,llcJk3NaZMHLtyWCgd5b):
	id = url.split('/')[-1]
	zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW = llcJk3NaZMHLtyWCgd5b.split('::',1)
	cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+zuvjg1oUGsM3rcbdPXe5N
	HQkaKeGbJn8xUowtmNF5cZdW = vy2dhqiSGpRtgCjUKV(HQkaKeGbJn8xUowtmNF5cZdW)
	title = qFghPAi5yz9Vf3NLwo0nuprl+'OWNER:  '+HQkaKeGbJn8xUowtmNF5cZdW+so4Z8OUJ5E
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,402,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,HQkaKeGbJn8xUowtmNF5cZdW)
	eBjxVKSvQC1 = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('myplaylistid',id)
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"collection_videos"(.*?)"SectionEdge"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,title,w03zWJvcXaCUySB6HIq4mVe,RRx0ri8bETI,zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW in items:
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+id
			title = vy2dhqiSGpRtgCjUKV(title)
			llcJk3NaZMHLtyWCgd5b = zuvjg1oUGsM3rcbdPXe5N+'::'+HQkaKeGbJn8xUowtmNF5cZdW
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,llcJk3NaZMHLtyWCgd5b)
	return
def RGV20bq6IaSHUncJ1sM(url,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	GKBq5DJiV9YMl4Fma3gr = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	eBjxVKSvQC1 = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mychannelid',GKBq5DJiV9YMl4Fma3gr)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysortmethod',sort)
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,title,w03zWJvcXaCUySB6HIq4mVe,zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW,RRx0ri8bETI in items:
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+id
			title = vy2dhqiSGpRtgCjUKV(title)
			llcJk3NaZMHLtyWCgd5b = zuvjg1oUGsM3rcbdPXe5N+'::'+HQkaKeGbJn8xUowtmNF5cZdW
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,llcJk3NaZMHLtyWCgd5b)
		if '"hasNextPage":true' in R8AE9e4mYxVhusL3Q:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,408,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs)
	return
def vA9GpgPCTQfLJ7OjSB0(url,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	GKBq5DJiV9YMl4Fma3gr = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	eBjxVKSvQC1 = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mychannelid',GKBq5DJiV9YMl4Fma3gr)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysortmethod',sort)
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for id,name,RRx0ri8bETI,count,zG7iYcbOgP2F8wWlrRDTyE,zuvjg1oUGsM3rcbdPXe5N,HQkaKeGbJn8xUowtmNF5cZdW in items:
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = vy2dhqiSGpRtgCjUKV(title)
			llcJk3NaZMHLtyWCgd5b = zuvjg1oUGsM3rcbdPXe5N+'::'+HQkaKeGbJn8xUowtmNF5cZdW
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,401,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,llcJk3NaZMHLtyWCgd5b)
		if '"hasNextPage":true' in R8AE9e4mYxVhusL3Q:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,407,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs)
	return
def fmjh4CuMDwWF2Z68EOkoBrcGv(url,F6nyLPflWskd2o):
	GKBq5DJiV9YMl4Fma3gr = url.split('/')[3]
	eBjxVKSvQC1 = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mychannelid',GKBq5DJiV9YMl4Fma3gr)
	R8AE9e4mYxVhusL3Q = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	DGNQtCreH9ayn = WWNb0XnUxOPL9gF.loads(R8AE9e4mYxVhusL3Q)
	try: items = DGNQtCreH9ayn['data']['channel'][F6nyLPflWskd2o]['edges']
	except: items = []
	if not items: w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+'لا توجد نتائج',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	else:
		for Uz7N5KAHwQ93iShW1xj in items:
			AAPvq9uWrhGY3siEHtfJpXo0Z = Uz7N5KAHwQ93iShW1xj['node']
			LW3eFsIR47SNzU8uop5AEKYdhkiT = AAPvq9uWrhGY3siEHtfJpXo0Z['xid']
			keys = list(AAPvq9uWrhGY3siEHtfJpXo0Z.keys())
			wePJX4glxq7onL = AAPvq9uWrhGY3siEHtfJpXo0Z['__typename'].lower()
			if wePJX4glxq7onL=='channel':
				name = AAPvq9uWrhGY3siEHtfJpXo0Z['name']
				OO4zeZtnGwvbQ9A65Uluch = AAPvq9uWrhGY3siEHtfJpXo0Z['displayName']
				title = 'USER:  '+OO4zeZtnGwvbQ9A65Uluch
				RRx0ri8bETI = AAPvq9uWrhGY3siEHtfJpXo0Z['coverURLx375']
			else:
				name = AAPvq9uWrhGY3siEHtfJpXo0Z['channel']['name']
				OO4zeZtnGwvbQ9A65Uluch = AAPvq9uWrhGY3siEHtfJpXo0Z['channel']['displayName']
				title = AAPvq9uWrhGY3siEHtfJpXo0Z['title']
				RRx0ri8bETI = AAPvq9uWrhGY3siEHtfJpXo0Z['thumbnailx360']
				if wePJX4glxq7onL=='live': title = 'LIVE:  '+title
			title = vy2dhqiSGpRtgCjUKV(title)
			llcJk3NaZMHLtyWCgd5b = name+'::'+OO4zeZtnGwvbQ9A65Uluch
			if hT1JIgqPQsUOZp5tjCX0E:
				title = title.encode(RMGz7OiD1e30P)
				llcJk3NaZMHLtyWCgd5b = llcJk3NaZMHLtyWCgd5b.encode(RMGz7OiD1e30P)
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			if wePJX4glxq7onL=='channel':
				cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,402,RRx0ri8bETI,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,llcJk3NaZMHLtyWCgd5b)
			else:
				if wePJX4glxq7onL=='video': w03zWJvcXaCUySB6HIq4mVe = str(AAPvq9uWrhGY3siEHtfJpXo0Z['duration'])
				else: w03zWJvcXaCUySB6HIq4mVe = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
				w3BfOGLdXcWzbiC1PYx9mE(wePJX4glxq7onL,qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,llcJk3NaZMHLtyWCgd5b)
	return
def Spl569ROx8f4ZnukFIAErWP(search,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	eBjxVKSvQC1 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mysearchwords',search)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagelimit','40')
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	url = S7EgasGcYdIo+'/search/'+search+'/hashtags'
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1,search)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		try: Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['search']['hashtags']['edges']
		except: Myulm5G7cTVjWQONotAhaniZX9 = []
		for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
			name = FfkU5bQno09gtyCJADWPRs6dEa['node']['name']
			name = kd8ZhJPCe7QzxLgij3TEHlGtOv(name)
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/hashtag/'+name[1:]
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'HSHTG: '+name,cX2SpPxGLmADTKl,417)
		if '"hasNextPage":true' in xxCo2yGh1duw8TYvF:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,416,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs,search)
	return
def RIJAyLUEbONhQCjnl9Sig403(url,GpwRnQ6q2o1fv0HbJTs=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if GpwRnQ6q2o1fv0HbJTs==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: GpwRnQ6q2o1fv0HbJTs = '1'
	name = url.split('/')[-1]
	eBjxVKSvQC1 = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('myhashtagname',name)
	eBjxVKSvQC1 = eBjxVKSvQC1.replace('mypagenumber',GpwRnQ6q2o1fv0HbJTs)
	xxCo2yGh1duw8TYvF = T0p2zb3mDx9LFK(eBjxVKSvQC1)
	if xxCo2yGh1duw8TYvF:
		MMrPUy3JhId2goYeA4l8fWmxQ1CO = rKY1tyQvh9OCxE2nl('dict',xxCo2yGh1duw8TYvF)
		Myulm5G7cTVjWQONotAhaniZX9 = MMrPUy3JhId2goYeA4l8fWmxQ1CO['data']['contentFeed']['edges']
		for FfkU5bQno09gtyCJADWPRs6dEa in Myulm5G7cTVjWQONotAhaniZX9:
			w03zWJvcXaCUySB6HIq4mVe = str(FfkU5bQno09gtyCJADWPRs6dEa['node']['post']['duration'])
			title = kd8ZhJPCe7QzxLgij3TEHlGtOv(FfkU5bQno09gtyCJADWPRs6dEa['node']['post']['title'])
			title = title.replace('\/','/')
			LW3eFsIR47SNzU8uop5AEKYdhkiT = FfkU5bQno09gtyCJADWPRs6dEa['node']['post']['xid']
			RRx0ri8bETI = FfkU5bQno09gtyCJADWPRs6dEa['node']['post']['thumbnailx480']
			RRx0ri8bETI = RRx0ri8bETI.replace('\/','/')
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/video/'+LW3eFsIR47SNzU8uop5AEKYdhkiT
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,403,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
		if '"hasNextPage":true' in xxCo2yGh1duw8TYvF:
			GpwRnQ6q2o1fv0HbJTs = str(int(GpwRnQ6q2o1fv0HbJTs)+1)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+GpwRnQ6q2o1fv0HbJTs,url,416,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,GpwRnQ6q2o1fv0HbJTs)
	return
def T0p2zb3mDx9LFK(eBjxVKSvQC1,search=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if fOohwvakqi29cx0l3yt5mzrAGpEg: eBjxVKSvQC1 = eBjxVKSvQC1.encode(RMGz7OiD1e30P)
	K1Ad9xmJOTInoB24L = ptsTrdY0UXhky4WH7VFCxo()
	headers = {"Authorization":K1Ad9xmJOTInoB24L,"Origin":S7EgasGcYdIo}
	if search:
		GGRexoVTLjusn6q = BZ1UIeSfWMxb6X
		headers.update({'Content-Type':'application/json','Referer':S7EgasGcYdIo+'/','X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		GGRexoVTLjusn6q = talv2Us5Kn1
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',talv2Us5Kn1,eBjxVKSvQC1,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'DAILYMOTION-GET_PAGEDATA-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	return R8AE9e4mYxVhusL3Q
def ptsTrdY0UXhky4WH7VFCxo():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'DAILYMOTION-GET_AUTHINTICATION-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	ixch1HKltCVnqXGbpYNs = AxTYMhRlfyskNc0X19dvwtS.findall('apiClientId.*?return"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	ixch1HKltCVnqXGbpYNs = ixch1HKltCVnqXGbpYNs[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	a8ab21sH5XRwWU9f7 = AxTYMhRlfyskNc0X19dvwtS.findall('apiClientSecret.*?return"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	a8ab21sH5XRwWU9f7 = a8ab21sH5XRwWU9f7[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
	qqlhGkX2Ep3SIFw1tK = 'https://graphql.api.dailymotion.com/oauth/token'
	Zetiwf2GINmza0 = 'client_credentials'
	data = {'client_id':ixch1HKltCVnqXGbpYNs,'client_secret':a8ab21sH5XRwWU9f7,'grant_type':Zetiwf2GINmza0}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',qqlhGkX2Ep3SIFw1tK,data,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	SfBELDzhVJdHt1gPcenmq9 = AxTYMhRlfyskNc0X19dvwtS.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	CWXPTifUeld48,wpkdL2uFB4sqh0no = SfBELDzhVJdHt1gPcenmq9[0]
	K1Ad9xmJOTInoB24L = wpkdL2uFB4sqh0no+" "+CWXPTifUeld48
	return K1Ad9xmJOTInoB24L
def E3FwPg9Z6KB(search,i1svWTIM79yezDZXt2gnACupwY=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not i1svWTIM79yezDZXt2gnACupwY and showDialogs:
		xFt3sX4TQp = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('موقع ديلي موشن - اختر البحث',xFt3sX4TQp)
		if qNmsBD1jJZVzcxi4onKuAOIC==-1: return
		elif qNmsBD1jJZVzcxi4onKuAOIC==0: i1svWTIM79yezDZXt2gnACupwY = 'videos?sortBy='
		elif qNmsBD1jJZVzcxi4onKuAOIC==1: i1svWTIM79yezDZXt2gnACupwY = 'videos?sortBy=RECENT'
		elif qNmsBD1jJZVzcxi4onKuAOIC==2: i1svWTIM79yezDZXt2gnACupwY = 'videos?sortBy=VIEW_COUNT'
		elif qNmsBD1jJZVzcxi4onKuAOIC==3: i1svWTIM79yezDZXt2gnACupwY = 'playlists'
		elif qNmsBD1jJZVzcxi4onKuAOIC==4: i1svWTIM79yezDZXt2gnACupwY = 'channels'
		elif qNmsBD1jJZVzcxi4onKuAOIC==5: i1svWTIM79yezDZXt2gnACupwY = 'lives'
		elif qNmsBD1jJZVzcxi4onKuAOIC==6: i1svWTIM79yezDZXt2gnACupwY = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in sL9HIPc1tSZrhE60TUoz2KQa: i1svWTIM79yezDZXt2gnACupwY = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in sL9HIPc1tSZrhE60TUoz2KQa: i1svWTIM79yezDZXt2gnACupwY = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in sL9HIPc1tSZrhE60TUoz2KQa: i1svWTIM79yezDZXt2gnACupwY = 'channels'
	elif '_DAILYMOTION-LIVES_' in sL9HIPc1tSZrhE60TUoz2KQa: i1svWTIM79yezDZXt2gnACupwY = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in sL9HIPc1tSZrhE60TUoz2KQa: i1svWTIM79yezDZXt2gnACupwY = 'hashtags'
	elif not i1svWTIM79yezDZXt2gnACupwY: i1svWTIM79yezDZXt2gnACupwY = 'videos?sortBy='
	if not search:
		search = TwDBf3QbKOnrmd5u9()
		if not search: return
	if 'videos' in i1svWTIM79yezDZXt2gnACupwY: SgslnAc0RXNxw(search+'/'+i1svWTIM79yezDZXt2gnACupwY)
	elif 'playlists' in i1svWTIM79yezDZXt2gnACupwY: rr7LvCchARPNGoFm61zxQOg(search)
	elif 'channels' in i1svWTIM79yezDZXt2gnACupwY: LGYArySDmNTOX(search)
	elif 'lives' in i1svWTIM79yezDZXt2gnACupwY: bAkFnigvKuweyJoOD7a36I(search)
	elif 'hashtags' in i1svWTIM79yezDZXt2gnACupwY: Spl569ROx8f4ZnukFIAErWP(search)
	return