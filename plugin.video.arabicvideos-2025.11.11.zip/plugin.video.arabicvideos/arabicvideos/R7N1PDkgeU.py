# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
headers = { 'User-Agent' : VhaIfJdtZP1kiKbRq8nGvFo9juBp2O }
mI6ayKxBvjd4CRthL = 'AKWAM'
qBAgzkG9oCL = '_AKW_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
hdJRwBVpaFfHq = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
kCIESuy4j5mVLZYtG9vDNnb7 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==240: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==241: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==242: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==243: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==244: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'FILTERS___'+text)
	elif mode==245: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'CATEGORIES___'+text)
	elif mode==246: Ubud2NhHKRnMTvI5mprQBVqk80 = HghVZS5Ud8O6uzA0yFDTKJXqsMx(url)
	elif mode==247: Ubud2NhHKRnMTvI5mprQBVqk80 = arxBH0dTFuoj4EO1(url)
	elif mode==248: Ubud2NhHKRnMTvI5mprQBVqk80 = zYikQbjIBtXrdThJwaWg()
	elif mode==249: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def zYikQbjIBtXrdThJwaWg():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKWAM-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	VVB9dmSDgE1RUCWbx2uMtsLyeJN4F = AxTYMhRlfyskNc0X19dvwtS.findall('home-site-btn-container.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if VVB9dmSDgE1RUCWbx2uMtsLyeJN4F: VVB9dmSDgE1RUCWbx2uMtsLyeJN4F = VVB9dmSDgE1RUCWbx2uMtsLyeJN4F[0]
	else: VVB9dmSDgE1RUCWbx2uMtsLyeJN4F = S7EgasGcYdIo
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',VVB9dmSDgE1RUCWbx2uMtsLyeJN4F,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKWAM-MENU-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,249,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',S7EgasGcYdIo,246)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',S7EgasGcYdIo,247)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المميزة',VVB9dmSDgE1RUCWbx2uMtsLyeJN4F,241,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'featured')
	srQF7hBNtnOZv3P = AxTYMhRlfyskNc0X19dvwtS.findall('recently-container.*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	cX2SpPxGLmADTKl = srQF7hBNtnOZv3P[0]
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'أضيف حديثا',cX2SpPxGLmADTKl,241)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,name,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
		if name in kCIESuy4j5mVLZYtG9vDNnb7: continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+name,cX2SpPxGLmADTKl,241)
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			title = name+WRsuxHTjDgYCIpoMQzLFAtS8rikP+title
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,241)
	return
def HghVZS5Ud8O6uzA0yFDTKJXqsMx(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKWAM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="menu(.*?)<nav',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?text">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7:
				title = title+' مصنفة'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,245)
		if website==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return R8AE9e4mYxVhusL3Q
def arxBH0dTFuoj4EO1(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'AKWAM-MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="menu(.*?)<nav',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?text">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title not in kCIESuy4j5mVLZYtG9vDNnb7:
				title = title+' مفلترة'
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,244)
		if website==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return R8AE9e4mYxVhusL3Q
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('swiper-container(.*?)swiper-button-prev',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="widget"(.*?)main-footer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not items:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for RRx0ri8bETI,cX2SpPxGLmADTKl,title in items:
			if '/series/' in cX2SpPxGLmADTKl or '/shows/' in cX2SpPxGLmADTKl:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,242,RRx0ri8bETI)
			elif '/movies/' in cX2SpPxGLmADTKl:
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,243,RRx0ri8bETI)
			elif '/games/' not in cX2SpPxGLmADTKl:
				w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,243,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pagination(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,241)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	url = S7EgasGcYdIo + '/search?q='+ej9gRJkD6KGTcf
	Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in R8AE9e4mYxVhusL3Q:
		RRx0ri8bETI = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel('ListItem.Icon')
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+'رابط التشغيل',url,243,RRx0ri8bETI)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('-episodes">(.*?)<div class="widget-4',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		rhVCfIQyOJ = AxTYMhRlfyskNc0X19dvwtS.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,RRx0ri8bETI in rhVCfIQyOJ:
			title = title.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,242,RRx0ri8bETI)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,243,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKWAM-PLAY-1st')
	OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('badge-danger.*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd): return
	aET9y5zIWeX = AxTYMhRlfyskNc0X19dvwtS.findall('li><a href="#(.*?)".*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	CBL4OQVtWbMAycUGl7Ex2SKZF,GjC4atkJLwlTpsI,GtnfmdqIOijegYu,baO1nfQVR7GWjUFesYNz = [],[],[],[]
	if aET9y5zIWeX:
		kw7O9B5fZceYAn0RbNtL = 'mp4'
		for nkLwNjDSFHe2pIWgC1P5,XcvFdKRjNLz5wEpDf in aET9y5zIWeX:
			vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('tab-content quality" id="'+nkLwNjDSFHe2pIWgC1P5+'".*?</div>.\s*</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			GtnfmdqIOijegYu.append(IxdmfnvhCA8Bc9ZlQ45oiqN)
			baO1nfQVR7GWjUFesYNz.append(XcvFdKRjNLz5wEpDf)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="qualities(.*?)<h3.*?>(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			IxdmfnvhCA8Bc9ZlQ45oiqN,filename = vvuraxgW7YLIZ4hU0MbCt[0]
			kiHhj6IaD2rWqOwdv0l4S7 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			kw7O9B5fZceYAn0RbNtL = filename.rsplit('.',1)[1].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if kw7O9B5fZceYAn0RbNtL in kiHhj6IaD2rWqOwdv0l4S7:
				w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'الملف ليس فيديو ولا صوت')
				return
		GtnfmdqIOijegYu.append(IxdmfnvhCA8Bc9ZlQ45oiqN)
		baO1nfQVR7GWjUFesYNz.append(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(GtnfmdqIOijegYu)):
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?icon-(.*?)"',GtnfmdqIOijegYu[uKFGBAEj9tX1e03cyHOMUNhQl4r6],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,VCKubUdS9QtP4cDnjmzh07s23 in BA01W9olieErLycV7kwFvOhH5Y3ms:
			if 'torrent' in VCKubUdS9QtP4cDnjmzh07s23: continue
			elif 'download' in VCKubUdS9QtP4cDnjmzh07s23: type = 'download'
			elif 'play' in VCKubUdS9QtP4cDnjmzh07s23: type = 'watch'
			else: type = 'unknown'
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named=__'+type+'____'+baO1nfQVR7GWjUFesYNz[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'__akwam'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	agsNp4VJm8d3e = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='CATEGORIES':
		if agsNp4VJm8d3e[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(agsNp4VJm8d3e[0:-1])):
			if agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		nUDgc4absePT2xMt = url+'?'+pbIlAP6KNW
	elif type=='FILTERS':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'?'+J41jTEGvedKYQgclAiUuPxF
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها',nUDgc4absePT2xMt,241,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',nUDgc4absePT2xMt,241,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,True,'AKWAM-FILTERS_MENU-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<form id(.*?)</form>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	dict = {}
	for CCkP7yi8aglTqbDOdBjRWNpco,name,IxdmfnvhCA8Bc9ZlQ45oiqN in i2KVkE3TFNIGfymrpJA:
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<option(.*?)>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='CATEGORIES':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<=1:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: ENDRjPGicXYFvpVs3xk5uSg6y(nUDgc4absePT2xMt)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'CATEGORIES___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,241,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',nUDgc4absePT2xMt,245,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='FILTERS':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع : '+name,nUDgc4absePT2xMt,244,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			if 'value' not in value: value = HHvPeCLzN1fIWDStR
			else: value = AxTYMhRlfyskNc0X19dvwtS.findall('"(.*?)"',value,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' : '#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' : '+name
			if type=='FILTERS': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,244,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='CATEGORIES' and agsNp4VJm8d3e[-2]+'=' in gjOp9yI3iS:
				pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'all')
				jYfvU9egTX62nrukVcoKEAyq = url+'?'+pbIlAP6KNW
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,241,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1')
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,245,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	iuECgXkw3pcy1FAvK96G = ['section','category','rating','year','language','formats','quality']
	for key in iuECgXkw3pcy1FAvK96G:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd