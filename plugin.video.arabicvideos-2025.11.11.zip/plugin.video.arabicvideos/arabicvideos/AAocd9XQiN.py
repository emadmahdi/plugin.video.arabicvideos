# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'VIDEONSAEM'
qBAgzkG9oCL = '_VNS_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','Show more','قصة عشق','عروض المصارعة الحرة مترجم']
headers = {'Referer':S7EgasGcYdIo}
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==1030: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==1031: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==1032: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==1033: Ubud2NhHKRnMTvI5mprQBVqk80 = odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,text)
	elif mode==1034: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==1039: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,1039,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''["']navslide-wrap["'](.*?)</ul>''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</i>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1034)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('/category.php">(.*?)"navslide-divider"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''["']dropdown-menu["'](.*?)</ul>''',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for Lhi71X39bHs6zEZ4ypIaGewVJ in vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace(Lhi71X39bHs6zEZ4ypIaGewVJ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if not title: continue
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1034)
	return
def I1C6JqXo3j9Ruyz(url):
	IeqB50YAbcLsum,llN8cqbtajQJprPCKLnWVxXB = [],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-SUBMENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"caret"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if j9HbACE1rmuP48NVX6pgQsUwfBWk and '.php' in str(j9HbACE1rmuP48NVX6pgQsUwfBWk):
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('"presentation"','</ul>')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = [(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,IxdmfnvhCA8Bc9ZlQ45oiqN)]
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' فرز أو فلتر أو ترتيب '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		for wMVN0pF2Qqt1AGTI6ujBshRJO5fP,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
			IeqB50YAbcLsum = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if wMVN0pF2Qqt1AGTI6ujBshRJO5fP: wMVN0pF2Qqt1AGTI6ujBshRJO5fP = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+': '
			for cX2SpPxGLmADTKl,title in IeqB50YAbcLsum:
				title = wMVN0pF2Qqt1AGTI6ujBshRJO5fP+title
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1031)
	fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-category-subcats"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if fxgnWRoUO7jNwtJkuB:
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		llN8cqbtajQJprPCKLnWVxXB = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if 1 or len(llN8cqbtajQJprPCKLnWVxXB)<30:
			if IeqB50YAbcLsum: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			for cX2SpPxGLmADTKl,title in llN8cqbtajQJprPCKLnWVxXB:
				if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1031)
	if not j9HbACE1rmuP48NVX6pgQsUwfBWk and not fxgnWRoUO7jNwtJkuB: ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if eBjxVKSvQC1=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		aNXRWYnbow7s8fpvLVK = headers.copy()
		aNXRWYnbow7s8fpvLVK['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',url,data,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-TITLES-1st')
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-TITLES-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	IxdmfnvhCA8Bc9ZlQ45oiqN,items = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	if eBjxVKSvQC1=='ajax-search':
		IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
		llN8cqbtajQJprPCKLnWVxXB = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in llN8cqbtajQJprPCKLnWVxXB: items.append((VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,cX2SpPxGLmADTKl,title))
	elif eBjxVKSvQC1=='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-carousel_featured"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	elif eBjxVKSvQC1=='new_episodes':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"row pm-ul-browse-videos(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	elif eBjxVKSvQC1=='new_movies':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"row pm-ul-browse-videos(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(vvuraxgW7YLIZ4hU0MbCt)>1: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[1]
	elif eBjxVKSvQC1=='featured_series':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pm-grid"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt: IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if IxdmfnvhCA8Bc9ZlQ45oiqN and not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not items: return
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
		RRx0ri8bETI += '|Referer='+S7EgasGcYdIo
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
		title = riUKNnOEtVwdj4(title)
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if eBjxVKSvQC1=='episodes' or any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1032,RRx0ri8bETI)
		elif eBjxVKSvQC1=='new_episodes':
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1032,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1033,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,1033,RRx0ri8bETI)
	if 1:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if cX2SpPxGLmADTKl=='#': continue
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/'+cX2SpPxGLmADTKl.strip('/')
				title = riUKNnOEtVwdj4(title)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,1031,'','',eBjxVKSvQC1)
	return
def odgWRe1tNlX78qVwxinT6mZ4Hp2Ey(url,nRW2P4Ke3z7):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-EPISODES_SEASONS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="eplist"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		rhVCfIQyOJ = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in rhVCfIQyOJ:
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,872)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<dt>(.*?)<dt>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if cX2SpPxGLmADTKl:
				ENDRjPGicXYFvpVs3xk5uSg6y(cX2SpPxGLmADTKl[-1],'episodes')
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu,OIbrTU8tkdvLRlSG9jZhgXoPC = [],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'VIDEONSAEM-PLAY-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if 'hash=' in R8AE9e4mYxVhusL3Q:
		HZEhcvJFGxL5XW = AxTYMhRlfyskNc0X19dvwtS.findall('hash=(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		HZEhcvJFGxL5XW = list(set(HZEhcvJFGxL5XW))
		for FuGekrm1E0pZ78vj4WhVdbR9aOtCD in HZEhcvJFGxL5XW:
			s4P2BrLJiAkjNyoleWhbEvKGZ = []
			PCnrX0p2QmTt5ijBIkqu4La = FuGekrm1E0pZ78vj4WhVdbR9aOtCD.split('__')
			for i1xLE74agTmA3FBVruGCQsWKjOc in PCnrX0p2QmTt5ijBIkqu4La:
				try:
					i1xLE74agTmA3FBVruGCQsWKjOc = j3kWVqdguK6O2QDmMf.b64decode(i1xLE74agTmA3FBVruGCQsWKjOc+'=')
					if fOohwvakqi29cx0l3yt5mzrAGpEg: i1xLE74agTmA3FBVruGCQsWKjOc = i1xLE74agTmA3FBVruGCQsWKjOc.decode(RMGz7OiD1e30P)
					s4P2BrLJiAkjNyoleWhbEvKGZ.append(i1xLE74agTmA3FBVruGCQsWKjOc)
				except: pass
			BA01W9olieErLycV7kwFvOhH5Y3ms = '>'.join(s4P2BrLJiAkjNyoleWhbEvKGZ)
			BA01W9olieErLycV7kwFvOhH5Y3ms = BA01W9olieErLycV7kwFvOhH5Y3ms.splitlines()
			for cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
				if ' => ' in cX2SpPxGLmADTKl:
					title,cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split(' => ')
					cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/search.php?keywords='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return