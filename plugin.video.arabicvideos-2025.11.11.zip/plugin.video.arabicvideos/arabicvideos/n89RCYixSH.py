# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
qqJpX5yPB1ldDwvYTa6cbtK0FsUS2r = 'M3U'
otY7B2WlSRvy3rECV = '_M3U_'
ll1VzW039ATNi27uYHfU4xchpEyk = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
rVWJO0Zo4smv2y = 4
def DDZptNJ0s6GAThr5UdqyBH(t5fhagjUGXk0ynOlJWeAb,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe,ZJksHpSUNh2f,YYXUAmT7uG6yFiRtDehn85qkpLcZj,xxRmTpBZPjKDXoaVnbSzAM):
	global otY7B2WlSRvy3rECV
	try:
		AcfzInE42p3Qh = str(xxRmTpBZPjKDXoaVnbSzAM['folder'])
		otY7B2WlSRvy3rECV = '_MU'+AcfzInE42p3Qh+'_'
	except: AcfzInE42p3Qh = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	try: lH4qDrXPiB2 = str(xxRmTpBZPjKDXoaVnbSzAM['sequence'])
	except: lH4qDrXPiB2 = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if   t5fhagjUGXk0ynOlJWeAb==710: lwfKMcpWgebLrA5sSa68 = O9kB7YXlqLnP58()
	elif t5fhagjUGXk0ynOlJWeAb==711: lwfKMcpWgebLrA5sSa68 = y3Ngcfoi5XRF4b0qIZ(AcfzInE42p3Qh,lH4qDrXPiB2)
	elif t5fhagjUGXk0ynOlJWeAb==712: lwfKMcpWgebLrA5sSa68 = zL7ZXKbV6nrfuGkhRTwl8x(AcfzInE42p3Qh)
	elif t5fhagjUGXk0ynOlJWeAb==713: lwfKMcpWgebLrA5sSa68 = VGmzPvN3XkOw0Frs2I9EKDyhq(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe,YYXUAmT7uG6yFiRtDehn85qkpLcZj)
	elif t5fhagjUGXk0ynOlJWeAb==714: lwfKMcpWgebLrA5sSa68 = VuHht6MNBWRnOkX9S(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe,YYXUAmT7uG6yFiRtDehn85qkpLcZj)
	elif t5fhagjUGXk0ynOlJWeAb==715: lwfKMcpWgebLrA5sSa68 = QgIZSJdUhsEnup8GPz3(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ZJksHpSUNh2f)
	elif t5fhagjUGXk0ynOlJWeAb==716: lwfKMcpWgebLrA5sSa68 = kC37LEplimYQboZtz2NxXT(AcfzInE42p3Qh,True)
	elif t5fhagjUGXk0ynOlJWeAb==717: lwfKMcpWgebLrA5sSa68 = ee5TZxvnCka79VQINUfl26jsWB8(AcfzInE42p3Qh,True)
	elif t5fhagjUGXk0ynOlJWeAb==718: lwfKMcpWgebLrA5sSa68 = WAyKP4FopO(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ggM5TzCxq24sDYLiEatpdSK7FQyGe)
	elif t5fhagjUGXk0ynOlJWeAb==719: lwfKMcpWgebLrA5sSa68 = hXmPJGkvHSYLdntjR9Vfu1b(ggM5TzCxq24sDYLiEatpdSK7FQyGe,AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,YYXUAmT7uG6yFiRtDehn85qkpLcZj)
	elif t5fhagjUGXk0ynOlJWeAb==720: lwfKMcpWgebLrA5sSa68 = B4Fd26pWwzh5RZQgYa(AcfzInE42p3Qh,True)
	elif t5fhagjUGXk0ynOlJWeAb==721: lwfKMcpWgebLrA5sSa68 = hc2DFeYx6yvb5R(AcfzInE42p3Qh)
	elif t5fhagjUGXk0ynOlJWeAb==722: lwfKMcpWgebLrA5sSa68 = MifcrJ12UWRKHItod3jLAZBaCQ(AcfzInE42p3Qh)
	elif t5fhagjUGXk0ynOlJWeAb==723: lwfKMcpWgebLrA5sSa68 = zrMHunxe8pFXl1v(AcfzInE42p3Qh)
	elif t5fhagjUGXk0ynOlJWeAb==726: lwfKMcpWgebLrA5sSa68 = DDdpeAHGlR7aLz(AcfzInE42p3Qh)
	elif t5fhagjUGXk0ynOlJWeAb==729: lwfKMcpWgebLrA5sSa68 = b198LikC6enZRjEgXHvdpNQ(ggM5TzCxq24sDYLiEatpdSK7FQyGe,AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,YYXUAmT7uG6yFiRtDehn85qkpLcZj)
	else: lwfKMcpWgebLrA5sSa68 = False
	return lwfKMcpWgebLrA5sSa68
def O9kB7YXlqLnP58():
	for AcfzInE42p3Qh in range(1,RR1typGWKXVd6vNAaMEqo9h+1):
		otY7B2WlSRvy3rECV = '_MU'+str(AcfzInE42p3Qh)+'_'
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قائمة مجلد '+bCuhHjwS9lEQ2eB1c[AcfzInE42p3Qh],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,720,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	return
def B4Fd26pWwzh5RZQgYa(AcfzInE42p3Qh=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,FBOMf1xKQphwczTvLNCjEkAnIa=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if AcfzInE42p3Qh:
		RTBA0dr32IvbNUJOCjnFeo1kMYVxs = {'folder':AcfzInE42p3Qh}
		f7C6EP5SDznwts = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else:
		RTBA0dr32IvbNUJOCjnFeo1kMYVxs = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		f7C6EP5SDznwts = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	kfaDY4SrBEWqmcdjT6uJ = rb1LQeqnckC(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa)
	if not kfaDY4SrBEWqmcdjT6uJ:
		w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+oamlxBqLdu4ZM9nQrbIAhS5Pg7+' إضافة وتغيير رابط'+f7C6EP5SDznwts+WRsuxHTjDgYCIpoMQzLFAtS8rikP+bCuhHjwS9lEQ2eB1c[1]+' '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,711,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh,'sequence':1})
		w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+oamlxBqLdu4ZM9nQrbIAhS5Pg7+' جلب ملفات'+f7C6EP5SDznwts+' '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,712,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	else:
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'بحث في الملفات'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,729,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مصنفة مرتبة'+f7C6EP5SDznwts,'LIVE_GROUPED_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مصنفة من القسم'+f7C6EP5SDznwts,'LIVE_FROM_GROUP_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مصنفة من الاسم'+f7C6EP5SDznwts,'LIVE_FROM_NAME_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مصنفة بلا ترتيب'+f7C6EP5SDznwts,'LIVE_GROUPED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات بلا ترتيب'+f7C6EP5SDznwts,'LIVE_ORIGINAL_GROUPED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مجهولة مرتبة'+f7C6EP5SDznwts,'LIVE_UNKNOWN_GROUPED_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'قنوات مجهولة بلا ترتيب'+f7C6EP5SDznwts,'LIVE_UNKNOWN_GROUPED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'فيديوهات بلا ترتيب'+f7C6EP5SDznwts,'VOD_ORIGINAL_GROUPED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'فيديوهات مصنفة القسم'+f7C6EP5SDznwts,'VOD_FROM_GROUP_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'فيديوهات مصنفة من الاسم'+f7C6EP5SDznwts,'VOD_FROM_NAME_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'فيديوهات مجهولة بلا ترتيب'+f7C6EP5SDznwts,'VOD_UNKNOWN_GROUPED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'فيديوهات مجهولة مرتبة'+f7C6EP5SDznwts,'VOD_UNKNOWN_GROUPED_SORTED',713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
		w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'إضافة وتغيير رابط'+f7C6EP5SDznwts+WRsuxHTjDgYCIpoMQzLFAtS8rikP+bCuhHjwS9lEQ2eB1c[BO1DGbpgSfCz],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,711,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh,'sequence':BO1DGbpgSfCz})
	w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'جلب ملفات'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,712,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
	w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'مسح ملفات'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,717,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
	w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'عدد فيديوهات'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,721,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
	w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'Referer تغيير'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,726,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
	w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+'User-Agent تغيير'+f7C6EP5SDznwts,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,723,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,RTBA0dr32IvbNUJOCjnFeo1kMYVxs)
	return
def kC37LEplimYQboZtz2NxXT(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	DCvEH1sbdzKxN5,NfTsweLCxD8Gi = False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	b92bu0WmeiCY,KmAnhFQyvJWqZxgcpU,VVOnKeTfxECqSh5o7NBMz,vvR9HbIYagCZytAhS6QlqGL0rU,b4bRjp8TeaSvdIAHk0oMZm3tY = fJUZDk9QaSjiOpPnLH(AcfzInE42p3Qh)
	if vvR9HbIYagCZytAhS6QlqGL0rU==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Y64UgIz2uFvr30eLtDGyqanRZQKN = fftOL25ErDvaseq(AcfzInE42p3Qh)
	if b92bu0WmeiCY:
		VpCAFPuW7Nn0evcrZhQ3o8f = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET',b92bu0WmeiCY,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y64UgIz2uFvr30eLtDGyqanRZQKN,False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'M3U-CHECK_ACCOUNT-1st')
		BxHzvikp0db2c = VpCAFPuW7Nn0evcrZhQ3o8f.content
		if VpCAFPuW7Nn0evcrZhQ3o8f.succeeded:
			HgA2CKVyDF,bSoBr5E8e1NRvpdA7GHKFmiJX4h,hmwc1uGXKbaQMWzVg2TpHk,qjxUoyBfLt2KQdXkb,pwknVsC3Gv7IyEBDUxmluOgLFra = 0,0,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			try:
				bDXsARpdoGEYmh8lIV4 = rKY1tyQvh9OCxE2nl('dict',BxHzvikp0db2c)
				NfTsweLCxD8Gi = bDXsARpdoGEYmh8lIV4['user_info']['status']
				DCvEH1sbdzKxN5 = True
				hmwc1uGXKbaQMWzVg2TpHk = bDXsARpdoGEYmh8lIV4['server_info']['time_now']
			except: pass
			if hmwc1uGXKbaQMWzVg2TpHk:
				try:
					JrYC7zTkGcEyFQ5p8W4s9A = f7epsRlYtMz4.strptime(hmwc1uGXKbaQMWzVg2TpHk,'%Y.%m.%d %H:%M:%S')
					HgA2CKVyDF = int(f7epsRlYtMz4.mktime(JrYC7zTkGcEyFQ5p8W4s9A))
					bSoBr5E8e1NRvpdA7GHKFmiJX4h = int(KKydonNSglP1M08xw7O-HgA2CKVyDF)
					bSoBr5E8e1NRvpdA7GHKFmiJX4h = int((bSoBr5E8e1NRvpdA7GHKFmiJX4h+900)/1800)*1800
				except: pass
				try:
					JrYC7zTkGcEyFQ5p8W4s9A = f7epsRlYtMz4.localtime(int(bDXsARpdoGEYmh8lIV4['user_info']['created_at']))
					qjxUoyBfLt2KQdXkb = f7epsRlYtMz4.strftime('%Y.%m.%d %H:%M:%S',JrYC7zTkGcEyFQ5p8W4s9A)
				except: pass
				try:
					JrYC7zTkGcEyFQ5p8W4s9A = f7epsRlYtMz4.localtime(int(bDXsARpdoGEYmh8lIV4['user_info']['exp_date']))
					pwknVsC3Gv7IyEBDUxmluOgLFra = f7epsRlYtMz4.strftime('%Y.%m.%d %H:%M:%S',JrYC7zTkGcEyFQ5p8W4s9A)
				except: pass
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.timestamp_'+AcfzInE42p3Qh,str(KKydonNSglP1M08xw7O))
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.timediff_'+AcfzInE42p3Qh,str(bSoBr5E8e1NRvpdA7GHKFmiJX4h))
			try:
				kkuaNm67eyPoziWr1Gb = '"server_info":'+BxHzvikp0db2c.split('"server_info":')[1]
				kkuaNm67eyPoziWr1Gb = kkuaNm67eyPoziWr1Gb.replace(':',': ').replace(',',', ').replace('}}','}')
				uepl7FVcgmMGaikWh3vNbP6J9X = AxTYMhRlfyskNc0X19dvwtS.findall('"url": "(.*?)", "port": "(.*?)"',kkuaNm67eyPoziWr1Gb,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL = uepl7FVcgmMGaikWh3vNbP6J9X[0]
			except: DCvEH1sbdzKxN5 = False
			if DCvEH1sbdzKxN5 and FBOMf1xKQphwczTvLNCjEkAnIa:
				max = bDXsARpdoGEYmh8lIV4['user_info']['max_connections']
				IIqPQN0nU6eJjt5cAES = bDXsARpdoGEYmh8lIV4['user_info']['active_cons']
				kBYlE4y1wsuhWCvQgxA0U = bDXsARpdoGEYmh8lIV4['user_info']['is_trial']
				C7bvx5PK9uU1YghqWj0niFJNo4eR = b92bu0WmeiCY.split('?',1)
				mlrXUnyLzPAhEIj8ix5Ztpu = 'URL:  '+qFghPAi5yz9Vf3NLwo0nuprl+b92bu0WmeiCY+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\n\nStatus:  '+qFghPAi5yz9Vf3NLwo0nuprl+NfTsweLCxD8Gi+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\nTrial:    '+qFghPAi5yz9Vf3NLwo0nuprl+str(kBYlE4y1wsuhWCvQgxA0U=='1')+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\nCreated  At:  '+qFghPAi5yz9Vf3NLwo0nuprl+qjxUoyBfLt2KQdXkb+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\nExpiry Date:  '+qFghPAi5yz9Vf3NLwo0nuprl+pwknVsC3Gv7IyEBDUxmluOgLFra+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\nConnections   ( Active / Maximum ) :  '+qFghPAi5yz9Vf3NLwo0nuprl+IIqPQN0nU6eJjt5cAES+' / '+max+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\nAllowed Outputs:   '+qFghPAi5yz9Vf3NLwo0nuprl+" , ".join(bDXsARpdoGEYmh8lIV4['user_info']['allowed_output_formats'])+so4Z8OUJ5E
				mlrXUnyLzPAhEIj8ix5Ztpu += '\n\n'+kkuaNm67eyPoziWr1Gb
				if NfTsweLCxD8Gi=='Active': okvXCAsSQLyfJ6xrUM0nz2('الاشتراك يعمل بدون مشاكل',mlrXUnyLzPAhEIj8ix5Ztpu)
				else: okvXCAsSQLyfJ6xrUM0nz2('يبدو أن هناك مشكلة في الاشتراك',mlrXUnyLzPAhEIj8ix5Ztpu)
	if b92bu0WmeiCY and DCvEH1sbdzKxN5 and NfTsweLCxD8Gi=='Active':
		UO05pib6mcvezR9(jZBtGcdApeKLEkb,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+b92bu0WmeiCY+' ]')
		ck9d5OzUV7qIj4BxCAWam3NJsH = True
	else:
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,'Checking M3U URL   [ Does not work ]   [ '+b92bu0WmeiCY+' ]')
		if FBOMf1xKQphwczTvLNCjEkAnIa: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		ck9d5OzUV7qIj4BxCAWam3NJsH = False
	return ck9d5OzUV7qIj4BxCAWam3NJsH,A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL
def VuHht6MNBWRnOkX9S(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH,tkUC2MqYKaH5duJeTDA,ZZQzs8ITl6imhJCot,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	if not ZZQzs8ITl6imhJCot: ZZQzs8ITl6imhJCot = '1'
	if not rb1LQeqnckC(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa): return
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH)
	snrNiTEh6zqZkUtlO = dYMLGvgfk4(FCoNx1Hbcjipz,'list',II4hU2E93TGRxYtNCcH,tkUC2MqYKaH5duJeTDA)
	p3pKOHrwThiUVZGyj5 = int(ZZQzs8ITl6imhJCot)*100
	swer0L6Rty8aHJ = p3pKOHrwThiUVZGyj5-100
	for WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN in snrNiTEh6zqZkUtlO[swer0L6Rty8aHJ:p3pKOHrwThiUVZGyj5]:
		GPtd1XQavKmL29jZqA5H = ('GROUPED' in II4hU2E93TGRxYtNCcH or II4hU2E93TGRxYtNCcH=='ALL')
		rz4J8St6Iulb = ('GROUPED' not in II4hU2E93TGRxYtNCcH and II4hU2E93TGRxYtNCcH!='ALL')
		if GPtd1XQavKmL29jZqA5H or rz4J8St6Iulb:
			if   'ARCHIVED'  in II4hU2E93TGRxYtNCcH: drzqWFkSHD.menuItemsLIST.append(['folder',otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,718,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ARCHIVED',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh}])
			elif 'EPG' 		 in II4hU2E93TGRxYtNCcH: drzqWFkSHD.menuItemsLIST.append(['folder',otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,718,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FULL_EPG',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh}])
			elif 'TIMESHIFT' in II4hU2E93TGRxYtNCcH: drzqWFkSHD.menuItemsLIST.append(['folder',otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,718,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'TIMESHIFT',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh}])
			elif 'LIVE' 	 in II4hU2E93TGRxYtNCcH: drzqWFkSHD.menuItemsLIST.append(['live',otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,715,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,WPHK5192hQ8lmL34OukgqMUS0CVF,{'folder':AcfzInE42p3Qh}])
			else: drzqWFkSHD.menuItemsLIST.append(['video',otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,715,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh}])
	X8XfkuPCiaIJptHFT1 = len(snrNiTEh6zqZkUtlO)
	lVL9WmPpg3nzufxACOB2wGESY(AcfzInE42p3Qh,ZZQzs8ITl6imhJCot,II4hU2E93TGRxYtNCcH,714,X8XfkuPCiaIJptHFT1,tkUC2MqYKaH5duJeTDA)
	return
def HZt2ziTGQ8Ew9BYWJOFLxR3m(keJ9FfLXP4TrN3xnOv0EZCI):
	w3BfOGLdXcWzbiC1PYx9mE('link',keJ9FfLXP4TrN3xnOv0EZCI+'هذه القائمة إما فارغة أو غير موجودة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('link',keJ9FfLXP4TrN3xnOv0EZCI+'أو الخدمة غير موجودة في اشتراكك',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('link',keJ9FfLXP4TrN3xnOv0EZCI+'أو رابط M3U الذي أنت أضفته غير صحيح',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	return
def VGmzPvN3XkOw0Frs2I9EKDyhq(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH,tkUC2MqYKaH5duJeTDA,ZZQzs8ITl6imhJCot,Bqfk14hGrAWJUFOv=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	if not ZZQzs8ITl6imhJCot: ZZQzs8ITl6imhJCot = '1'
	keJ9FfLXP4TrN3xnOv0EZCI = otY7B2WlSRvy3rECV
	if not rb1LQeqnckC(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa): return False
	if '__SERIES__' in tkUC2MqYKaH5duJeTDA: zzHhRaYQqSP7Uc4Wjdg,TT9k2jLrOBca1FUxMIESmgHWCyeY = tkUC2MqYKaH5duJeTDA.split('__SERIES__')
	else: zzHhRaYQqSP7Uc4Wjdg,TT9k2jLrOBca1FUxMIESmgHWCyeY = tkUC2MqYKaH5duJeTDA,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH)
	Y4AO6X0wl7n2ixmyRCjEM = dYMLGvgfk4(FCoNx1Hbcjipz,'list',II4hU2E93TGRxYtNCcH,'__GROUPS__')
	if not Y4AO6X0wl7n2ixmyRCjEM: return False
	zsE8QOyJBkpMlFc = []
	for NgZsLrE9mYIe0R51V7PGHUcM4J,QacvmqO47zo1MySl3BEN in Y4AO6X0wl7n2ixmyRCjEM:
		if '===== ===== =====' in NgZsLrE9mYIe0R51V7PGHUcM4J:
			w3BfOGLdXcWzbiC1PYx9mE('link',keJ9FfLXP4TrN3xnOv0EZCI+NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			w3BfOGLdXcWzbiC1PYx9mE('link',keJ9FfLXP4TrN3xnOv0EZCI+NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			continue
		if Bqfk14hGrAWJUFOv:
			if '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J: keJ9FfLXP4TrN3xnOv0EZCI = 'SERIES'
			elif '!!__UNKNOWN__!!' in NgZsLrE9mYIe0R51V7PGHUcM4J: keJ9FfLXP4TrN3xnOv0EZCI = 'UNKNOWN'
			elif 'LIVE' in II4hU2E93TGRxYtNCcH: keJ9FfLXP4TrN3xnOv0EZCI = 'LIVE'
			else: keJ9FfLXP4TrN3xnOv0EZCI = 'VIDEOS'
			keJ9FfLXP4TrN3xnOv0EZCI = ','+qFghPAi5yz9Vf3NLwo0nuprl+keJ9FfLXP4TrN3xnOv0EZCI+': '+so4Z8OUJ5E
		if '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J: GCh6FDfNpx,Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO = NgZsLrE9mYIe0R51V7PGHUcM4J.split('__SERIES__')
		else: GCh6FDfNpx,Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO = NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if not tkUC2MqYKaH5duJeTDA:
			if GCh6FDfNpx in zsE8QOyJBkpMlFc: continue
			zsE8QOyJBkpMlFc.append(GCh6FDfNpx)
			if 'RANDOM' in Bqfk14hGrAWJUFOv: w3BfOGLdXcWzbiC1PYx9mE('folder',keJ9FfLXP4TrN3xnOv0EZCI+GCh6FDfNpx,II4hU2E93TGRxYtNCcH,168,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
			elif '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J: w3BfOGLdXcWzbiC1PYx9mE('folder',keJ9FfLXP4TrN3xnOv0EZCI+GCh6FDfNpx,II4hU2E93TGRxYtNCcH,713,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',keJ9FfLXP4TrN3xnOv0EZCI+GCh6FDfNpx,II4hU2E93TGRxYtNCcH,714,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
		elif '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J and GCh6FDfNpx==zzHhRaYQqSP7Uc4Wjdg:
			if Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO in zsE8QOyJBkpMlFc: continue
			zsE8QOyJBkpMlFc.append(Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO)
			if 'RANDOM' in Bqfk14hGrAWJUFOv: w3BfOGLdXcWzbiC1PYx9mE('folder',keJ9FfLXP4TrN3xnOv0EZCI+Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO,II4hU2E93TGRxYtNCcH,168,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',keJ9FfLXP4TrN3xnOv0EZCI+Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO,II4hU2E93TGRxYtNCcH,714,QacvmqO47zo1MySl3BEN,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	drzqWFkSHD.menuItemsLIST[:] = sorted(drzqWFkSHD.menuItemsLIST,reverse=False,key=lambda xngTvzlop02PjM7ZdA: xngTvzlop02PjM7ZdA[1].lower())
	if not Bqfk14hGrAWJUFOv:
		p3pKOHrwThiUVZGyj5 = int(ZZQzs8ITl6imhJCot)*100
		swer0L6Rty8aHJ = p3pKOHrwThiUVZGyj5-100
		X8XfkuPCiaIJptHFT1 = len(drzqWFkSHD.menuItemsLIST)
		drzqWFkSHD.menuItemsLIST[:] = drzqWFkSHD.menuItemsLIST[swer0L6Rty8aHJ:p3pKOHrwThiUVZGyj5]
		lVL9WmPpg3nzufxACOB2wGESY(AcfzInE42p3Qh,ZZQzs8ITl6imhJCot,II4hU2E93TGRxYtNCcH,713,X8XfkuPCiaIJptHFT1,tkUC2MqYKaH5duJeTDA)
	return True
def WAyKP4FopO(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,iU4sx8bzPWHpRTIjuFaNcGoQ):
	if not rb1LQeqnckC(AcfzInE42p3Qh,True): return
	Y64UgIz2uFvr30eLtDGyqanRZQKN = fftOL25ErDvaseq(AcfzInE42p3Qh)
	HgA2CKVyDF = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.timestamp_'+AcfzInE42p3Qh)
	if not HgA2CKVyDF or KKydonNSglP1M08xw7O-int(HgA2CKVyDF)>24*UnxhPGeBSgLJH:
		ck9d5OzUV7qIj4BxCAWam3NJsH,A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL = kC37LEplimYQboZtz2NxXT(AcfzInE42p3Qh,False)
		if not ck9d5OzUV7qIj4BxCAWam3NJsH: return
	bSoBr5E8e1NRvpdA7GHKFmiJX4h = int(xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.timediff_'+AcfzInE42p3Qh))
	VVOnKeTfxECqSh5o7NBMz = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.server_'+AcfzInE42p3Qh)
	vvR9HbIYagCZytAhS6QlqGL0rU = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.username_'+AcfzInE42p3Qh)
	b4bRjp8TeaSvdIAHk0oMZm3tY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.password_'+AcfzInE42p3Qh)
	vvAxZlye5pNPUCEurqO4sgR2MQz9IL = s3chK0CpdkqFzAr6UvZloXHTwMxQmf.split('/')
	VqsDWtNZPFBlL5aEy6THjYfUIi = vvAxZlye5pNPUCEurqO4sgR2MQz9IL[-1].replace('.ts',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('.m3u8',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if iU4sx8bzPWHpRTIjuFaNcGoQ=='SHORT_EPG': ADe20GapINmQToHOdPhXilYkLu = 'get_short_epg'
	else: ADe20GapINmQToHOdPhXilYkLu = 'get_simple_data_table'
	b92bu0WmeiCY,KmAnhFQyvJWqZxgcpU,VVOnKeTfxECqSh5o7NBMz,vvR9HbIYagCZytAhS6QlqGL0rU,b4bRjp8TeaSvdIAHk0oMZm3tY = fJUZDk9QaSjiOpPnLH(AcfzInE42p3Qh)
	if not vvR9HbIYagCZytAhS6QlqGL0rU: return
	SA5fRjQErLWDku = b92bu0WmeiCY+'&action='+ADe20GapINmQToHOdPhXilYkLu+'&stream_id='+VqsDWtNZPFBlL5aEy6THjYfUIi
	BxHzvikp0db2c = hy0NjvEFJc8ankMr(RFowY7JrTPs8c5m02ydD1VgbeBup3N,SA5fRjQErLWDku,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Y64UgIz2uFvr30eLtDGyqanRZQKN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'M3U-EPG_ITEMS-2nd')
	b5CYaJsBp1HSiQ4UXl8oL3m = rKY1tyQvh9OCxE2nl('dict',BxHzvikp0db2c)
	oINiaOL1vgGAQ9mbXBYj = b5CYaJsBp1HSiQ4UXl8oL3m['epg_listings']
	H4AvkUZXBgsdLp9JlVftu6 = []
	if iU4sx8bzPWHpRTIjuFaNcGoQ in ['ARCHIVED','TIMESHIFT']:
		for bDXsARpdoGEYmh8lIV4 in oINiaOL1vgGAQ9mbXBYj:
			if bDXsARpdoGEYmh8lIV4['has_archive']==1:
				H4AvkUZXBgsdLp9JlVftu6.append(bDXsARpdoGEYmh8lIV4)
				if iU4sx8bzPWHpRTIjuFaNcGoQ in ['TIMESHIFT']: break
		if not H4AvkUZXBgsdLp9JlVftu6: return
		w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+qFghPAi5yz9Vf3NLwo0nuprl+'الملفات الأولي بهذه القائمة قد لا تعمل'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
		if iU4sx8bzPWHpRTIjuFaNcGoQ in ['TIMESHIFT']:
			P3TojN24tK1EisnW6x7IkrF = 2
			fTqBeAzVUC0SQF7JgO8yodlYsurnjP = P3TojN24tK1EisnW6x7IkrF*UnxhPGeBSgLJH
			H4AvkUZXBgsdLp9JlVftu6 = []
			YA5lKyeXapDW0MVzGk74hPE12j = int(int(bDXsARpdoGEYmh8lIV4['start_timestamp'])/fTqBeAzVUC0SQF7JgO8yodlYsurnjP)*fTqBeAzVUC0SQF7JgO8yodlYsurnjP
			gRHqBM56saeb0Kx1vIZYStLlj4FzUc = KKydonNSglP1M08xw7O+fTqBeAzVUC0SQF7JgO8yodlYsurnjP
			d1mBf2qnWiCa0FMrwh57Y = int((gRHqBM56saeb0Kx1vIZYStLlj4FzUc-YA5lKyeXapDW0MVzGk74hPE12j)/UnxhPGeBSgLJH)
			for Y5YTsXIKBLG0yv1WRupn3o7ia in range(d1mBf2qnWiCa0FMrwh57Y):
				if Y5YTsXIKBLG0yv1WRupn3o7ia>=6:
					if Y5YTsXIKBLG0yv1WRupn3o7ia%P3TojN24tK1EisnW6x7IkrF!=0: continue
					PpILFBsV1RSiMw = fTqBeAzVUC0SQF7JgO8yodlYsurnjP
				else: PpILFBsV1RSiMw = fTqBeAzVUC0SQF7JgO8yodlYsurnjP//2
				AiFcOXNSUYfp7HgTlKZB01JI6hx = YA5lKyeXapDW0MVzGk74hPE12j+Y5YTsXIKBLG0yv1WRupn3o7ia*UnxhPGeBSgLJH
				bDXsARpdoGEYmh8lIV4 = {}
				bDXsARpdoGEYmh8lIV4['title'] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				JrYC7zTkGcEyFQ5p8W4s9A = f7epsRlYtMz4.localtime(AiFcOXNSUYfp7HgTlKZB01JI6hx-bSoBr5E8e1NRvpdA7GHKFmiJX4h-UnxhPGeBSgLJH)
				bDXsARpdoGEYmh8lIV4['start'] = f7epsRlYtMz4.strftime('%Y.%m.%d %H:%M:%S',JrYC7zTkGcEyFQ5p8W4s9A)
				bDXsARpdoGEYmh8lIV4['start_timestamp'] = str(AiFcOXNSUYfp7HgTlKZB01JI6hx)
				bDXsARpdoGEYmh8lIV4['stop_timestamp'] = str(AiFcOXNSUYfp7HgTlKZB01JI6hx+PpILFBsV1RSiMw)
				H4AvkUZXBgsdLp9JlVftu6.append(bDXsARpdoGEYmh8lIV4)
	elif iU4sx8bzPWHpRTIjuFaNcGoQ in ['SHORT_EPG','FULL_EPG']: H4AvkUZXBgsdLp9JlVftu6 = oINiaOL1vgGAQ9mbXBYj
	if iU4sx8bzPWHpRTIjuFaNcGoQ=='FULL_EPG' and len(H4AvkUZXBgsdLp9JlVftu6)>0:
		w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+qFghPAi5yz9Vf3NLwo0nuprl+'هذه قائمة برامج القنوات (جدول فقط)ـ'+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	q9qiHuLavJxU27cKoGZp8l = []
	QacvmqO47zo1MySl3BEN = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel('ListItem.Icon')
	for bDXsARpdoGEYmh8lIV4 in H4AvkUZXBgsdLp9JlVftu6:
		oj5EvxCrn2m = j3kWVqdguK6O2QDmMf.b64decode(bDXsARpdoGEYmh8lIV4['title'])
		if fOohwvakqi29cx0l3yt5mzrAGpEg: oj5EvxCrn2m = oj5EvxCrn2m.decode(RMGz7OiD1e30P)
		AiFcOXNSUYfp7HgTlKZB01JI6hx = int(bDXsARpdoGEYmh8lIV4['start_timestamp'])
		QopzC4Hd93AhWZM5RkuI = int(bDXsARpdoGEYmh8lIV4['stop_timestamp'])
		XZNc3KheLkjrA = str(int((QopzC4Hd93AhWZM5RkuI-AiFcOXNSUYfp7HgTlKZB01JI6hx+59)/60))
		x8cAve9w2HSknVTF = bDXsARpdoGEYmh8lIV4['start'].replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,':')
		JrYC7zTkGcEyFQ5p8W4s9A = f7epsRlYtMz4.localtime(AiFcOXNSUYfp7HgTlKZB01JI6hx-UnxhPGeBSgLJH)
		wPo7Llku2qCEsjrN4A3HQUR9 = f7epsRlYtMz4.strftime('%H:%M',JrYC7zTkGcEyFQ5p8W4s9A)
		JJOeMQx7o1dG5ZXigVKfjE0YB = f7epsRlYtMz4.strftime('%a',JrYC7zTkGcEyFQ5p8W4s9A)
		if iU4sx8bzPWHpRTIjuFaNcGoQ=='SHORT_EPG': oj5EvxCrn2m = oamlxBqLdu4ZM9nQrbIAhS5Pg7+wPo7Llku2qCEsjrN4A3HQUR9+' ـ '+oj5EvxCrn2m+so4Z8OUJ5E
		elif iU4sx8bzPWHpRTIjuFaNcGoQ=='TIMESHIFT': oj5EvxCrn2m = JJOeMQx7o1dG5ZXigVKfjE0YB+WRsuxHTjDgYCIpoMQzLFAtS8rikP+wPo7Llku2qCEsjrN4A3HQUR9+' ('+XZNc3KheLkjrA+'min)'
		else: oj5EvxCrn2m = JJOeMQx7o1dG5ZXigVKfjE0YB+WRsuxHTjDgYCIpoMQzLFAtS8rikP+wPo7Llku2qCEsjrN4A3HQUR9+' ('+XZNc3KheLkjrA+'min)   '+oj5EvxCrn2m+' ـ'
		if iU4sx8bzPWHpRTIjuFaNcGoQ in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			iipmw3uEXKW8UR5Prx9tb = VVOnKeTfxECqSh5o7NBMz+'/timeshift/'+vvR9HbIYagCZytAhS6QlqGL0rU+'/'+b4bRjp8TeaSvdIAHk0oMZm3tY+'/'+XZNc3KheLkjrA+'/'+x8cAve9w2HSknVTF+'/'+VqsDWtNZPFBlL5aEy6THjYfUIi+'.m3u8'
			if iU4sx8bzPWHpRTIjuFaNcGoQ=='FULL_EPG': w3BfOGLdXcWzbiC1PYx9mE('link',otY7B2WlSRvy3rECV+oj5EvxCrn2m,iipmw3uEXKW8UR5Prx9tb,9999,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
			else: w3BfOGLdXcWzbiC1PYx9mE('video',otY7B2WlSRvy3rECV+oj5EvxCrn2m,iipmw3uEXKW8UR5Prx9tb,715,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
		q9qiHuLavJxU27cKoGZp8l.append(oj5EvxCrn2m)
	if iU4sx8bzPWHpRTIjuFaNcGoQ=='SHORT_EPG' and q9qiHuLavJxU27cKoGZp8l: l2zuERKXVvY1FpC6 = U5UKxjWSshITucleR8B(q9qiHuLavJxU27cKoGZp8l)
	return q9qiHuLavJxU27cKoGZp8l
def MifcrJ12UWRKHItod3jLAZBaCQ(AcfzInE42p3Qh):
	if not rb1LQeqnckC(AcfzInE42p3Qh,True): return
	VVOnKeTfxECqSh5o7NBMz,HcAISZu3Qqb9GCF74gvMptTN,L0LjKpm7VCx4nG9JT = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,0,0
	ck9d5OzUV7qIj4BxCAWam3NJsH,A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL = kC37LEplimYQboZtz2NxXT(AcfzInE42p3Qh,False)
	if ck9d5OzUV7qIj4BxCAWam3NJsH:
		mzeZcuGqjplkYTf1wOL9sRy = rtnmYvjuNKJiTZeS2xd(A5dEiPaRMX3CDp4jOGkntTfmSKl)
		HcAISZu3Qqb9GCF74gvMptTN = aBjKh31v5suG4yTA(mzeZcuGqjplkYTf1wOL9sRy[0],int(pfSZ2MEIXBYyL))
		FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,'LIVE_GROUPED')
		vZlukQzIfxCsKH4GW18XmNyq = dYMLGvgfk4(FCoNx1Hbcjipz,'list','LIVE_GROUPED')
		snrNiTEh6zqZkUtlO = dYMLGvgfk4(FCoNx1Hbcjipz,'list','LIVE_GROUPED',vZlukQzIfxCsKH4GW18XmNyq[1])
		s3chK0CpdkqFzAr6UvZloXHTwMxQmf = snrNiTEh6zqZkUtlO[0][2]
		ephTrV35zfR2U4kQEoDK8 = AxTYMhRlfyskNc0X19dvwtS.findall('://(.*?)/',s3chK0CpdkqFzAr6UvZloXHTwMxQmf,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		ephTrV35zfR2U4kQEoDK8 = ephTrV35zfR2U4kQEoDK8[0]
		if ':' in ephTrV35zfR2U4kQEoDK8: EZWg4Tb3kN6tUACpwKj5,t4to0kjHcy8 = ephTrV35zfR2U4kQEoDK8.split(':')
		else: EZWg4Tb3kN6tUACpwKj5,t4to0kjHcy8 = ephTrV35zfR2U4kQEoDK8,'80'
		OzZ5d1GQn9RjcuxN82grByeoHpK = rtnmYvjuNKJiTZeS2xd(EZWg4Tb3kN6tUACpwKj5)
		L0LjKpm7VCx4nG9JT = aBjKh31v5suG4yTA(OzZ5d1GQn9RjcuxN82grByeoHpK[0],int(t4to0kjHcy8))
	if HcAISZu3Qqb9GCF74gvMptTN and L0LjKpm7VCx4nG9JT:
		mlrXUnyLzPAhEIj8ix5Ztpu = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		mlrXUnyLzPAhEIj8ix5Ztpu += '\n\n'+'وقت ضائع في السيرفر الأصلي'+b8sk5WyPoz03pXhRx+str(int(L0LjKpm7VCx4nG9JT*1000))+' ملي ثانية'
		mlrXUnyLzPAhEIj8ix5Ztpu += '\n\n'+'وقت ضائع في السيرفر البديل'+b8sk5WyPoz03pXhRx+str(int(HcAISZu3Qqb9GCF74gvMptTN*1000))+' ملي ثانية'
		vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC('center','السيرفر الأصلي','السيرفر الأسرع',F91YEzyWak5,mlrXUnyLzPAhEIj8ix5Ztpu)
		if vvbjZeMTcKP4dXDQLf90B3mgwYV7==1 and HcAISZu3Qqb9GCF74gvMptTN<L0LjKpm7VCx4nG9JT: VVOnKeTfxECqSh5o7NBMz = A5dEiPaRMX3CDp4jOGkntTfmSKl+':'+pfSZ2MEIXBYyL
	else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'البرنامج لم يجد السيرفر البديل')
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.server_'+AcfzInE42p3Qh,VVOnKeTfxECqSh5o7NBMz)
	return
def QgIZSJdUhsEnup8GPz3(AcfzInE42p3Qh,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,ZJksHpSUNh2f):
	rowl9WdfMmBvHIY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.useragent_'+AcfzInE42p3Qh)
	QhU5Rs8WnFpcIX = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.referer_'+AcfzInE42p3Qh)
	if rowl9WdfMmBvHIY or QhU5Rs8WnFpcIX:
		s3chK0CpdkqFzAr6UvZloXHTwMxQmf += '|'
		if rowl9WdfMmBvHIY: s3chK0CpdkqFzAr6UvZloXHTwMxQmf += '&User-Agent='+rowl9WdfMmBvHIY
		if QhU5Rs8WnFpcIX: s3chK0CpdkqFzAr6UvZloXHTwMxQmf += '&Referer='+QhU5Rs8WnFpcIX
		s3chK0CpdkqFzAr6UvZloXHTwMxQmf = s3chK0CpdkqFzAr6UvZloXHTwMxQmf.replace('|&','|')
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(s3chK0CpdkqFzAr6UvZloXHTwMxQmf,qqJpX5yPB1ldDwvYTa6cbtK0FsUS2r,ZJksHpSUNh2f)
	return
def zrMHunxe8pFXl1v(AcfzInE42p3Qh):
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	rowl9WdfMmBvHIY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.useragent_'+AcfzInE42p3Qh)
	dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center','استخدام الأصلي','تعديل القديم',rowl9WdfMmBvHIY,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if dVXK860sCLrSIcRbBaGAMy==1: rowl9WdfMmBvHIY = TwDBf3QbKOnrmd5u9('أكتب ـM3U User-Agent جديد',rowl9WdfMmBvHIY,True)
	else: rowl9WdfMmBvHIY = 'Unknown'
	if rowl9WdfMmBvHIY==WRsuxHTjDgYCIpoMQzLFAtS8rikP:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rowl9WdfMmBvHIY,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if dVXK860sCLrSIcRbBaGAMy!=1:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم الإلغاء')
		return
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.useragent_'+AcfzInE42p3Qh,rowl9WdfMmBvHIY)
	KK5BTFDjA6RPp(AcfzInE42p3Qh)
	return
def DDdpeAHGlR7aLz(AcfzInE42p3Qh):
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	QhU5Rs8WnFpcIX = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.referer_'+AcfzInE42p3Qh)
	dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center','استخدام الأصلي','تعديل القديم',QhU5Rs8WnFpcIX,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if dVXK860sCLrSIcRbBaGAMy==1: QhU5Rs8WnFpcIX = TwDBf3QbKOnrmd5u9('أكتب ـM3U Referer جديد',QhU5Rs8WnFpcIX,True)
	else: QhU5Rs8WnFpcIX = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if QhU5Rs8WnFpcIX==WRsuxHTjDgYCIpoMQzLFAtS8rikP:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,QhU5Rs8WnFpcIX,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if dVXK860sCLrSIcRbBaGAMy!=1:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم الإلغاء')
		return
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.referer_'+AcfzInE42p3Qh,QhU5Rs8WnFpcIX)
	KK5BTFDjA6RPp(AcfzInE42p3Qh)
	return
def fJUZDk9QaSjiOpPnLH(AcfzInE42p3Qh,ii5bwqtmS0ByaPUcsu=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not IIkW6vK81iFA0BZNSaObfj: IIkW6vK81iFA0BZNSaObfj = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.url_'+AcfzInE42p3Qh)
	VVOnKeTfxECqSh5o7NBMz = UUmYkruGeM3p8sKi6o2fcI(IIkW6vK81iFA0BZNSaObfj,'url')
	vvR9HbIYagCZytAhS6QlqGL0rU = AxTYMhRlfyskNc0X19dvwtS.findall('username=(.*?)&',IIkW6vK81iFA0BZNSaObfj+'&',AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	b4bRjp8TeaSvdIAHk0oMZm3tY = AxTYMhRlfyskNc0X19dvwtS.findall('password=(.*?)&',IIkW6vK81iFA0BZNSaObfj+'&',AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not vvR9HbIYagCZytAhS6QlqGL0rU or not b4bRjp8TeaSvdIAHk0oMZm3tY:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	vvR9HbIYagCZytAhS6QlqGL0rU = vvR9HbIYagCZytAhS6QlqGL0rU[0]
	b4bRjp8TeaSvdIAHk0oMZm3tY = b4bRjp8TeaSvdIAHk0oMZm3tY[0]
	b92bu0WmeiCY = VVOnKeTfxECqSh5o7NBMz+'/player_api.php?username='+vvR9HbIYagCZytAhS6QlqGL0rU+'&password='+b4bRjp8TeaSvdIAHk0oMZm3tY
	KmAnhFQyvJWqZxgcpU = VVOnKeTfxECqSh5o7NBMz+'/get.php?username='+vvR9HbIYagCZytAhS6QlqGL0rU+'&password='+b4bRjp8TeaSvdIAHk0oMZm3tY+'&type=m3u_plus'
	return b92bu0WmeiCY,KmAnhFQyvJWqZxgcpU,VVOnKeTfxECqSh5o7NBMz,vvR9HbIYagCZytAhS6QlqGL0rU,b4bRjp8TeaSvdIAHk0oMZm3tY
def MnSKArGxY5m6(AcfzInE42p3Qh,b1cm7wYq4R5UEjspZiG2rzuKTg6=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	WEIRS5qfJDmGNX8L43uzaAt9jc = b1cm7wYq4R5UEjspZiG2rzuKTg6.replace('/','_').replace(':','_').replace('.','_')
	WEIRS5qfJDmGNX8L43uzaAt9jc = WEIRS5qfJDmGNX8L43uzaAt9jc.replace('?','_').replace('=','_').replace('&','_')
	WEIRS5qfJDmGNX8L43uzaAt9jc = oNlez5gnM9x2B4.path.join(eC21aUbHsMhBQnfVypk8T,WEIRS5qfJDmGNX8L43uzaAt9jc).strip('.m3u')+'.m3u'
	return WEIRS5qfJDmGNX8L43uzaAt9jc
def y3Ngcfoi5XRF4b0qIZ(AcfzInE42p3Qh,lH4qDrXPiB2):
	O7nKqfbapMlYURcyekATJL = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.url_'+AcfzInE42p3Qh+'_'+lH4qDrXPiB2)
	h5hO3WF4lJ0vGbQp9ZHPgnSTte = True
	if O7nKqfbapMlYURcyekATJL:
		dVXK860sCLrSIcRbBaGAMy = uPS1UedvhXl6MHVbq7zr5Z92Tig('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',qFghPAi5yz9Vf3NLwo0nuprl+O7nKqfbapMlYURcyekATJL+so4Z8OUJ5E+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if dVXK860sCLrSIcRbBaGAMy==-1: return
		elif dVXK860sCLrSIcRbBaGAMy==0: O7nKqfbapMlYURcyekATJL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		elif dVXK860sCLrSIcRbBaGAMy==2:
			dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if dVXK860sCLrSIcRbBaGAMy in [-1,0]: return
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم مسح الرابط')
			h5hO3WF4lJ0vGbQp9ZHPgnSTte = False
			y7DLSJYUTk3vBRr1cEfzI4b = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if h5hO3WF4lJ0vGbQp9ZHPgnSTte:
		y7DLSJYUTk3vBRr1cEfzI4b = TwDBf3QbKOnrmd5u9('اكتب رابط M3U كاملا',O7nKqfbapMlYURcyekATJL)
		y7DLSJYUTk3vBRr1cEfzI4b = y7DLSJYUTk3vBRr1cEfzI4b.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if not y7DLSJYUTk3vBRr1cEfzI4b:
			dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if dVXK860sCLrSIcRbBaGAMy in [-1,0]: return
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم مسح الرابط')
		else:
			mlrXUnyLzPAhEIj8ix5Ztpu = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			dVXK860sCLrSIcRbBaGAMy = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'الرابط الجديد هو:',qFghPAi5yz9Vf3NLwo0nuprl+y7DLSJYUTk3vBRr1cEfzI4b+so4Z8OUJ5E+'\n\n'+mlrXUnyLzPAhEIj8ix5Ztpu)
			if dVXK860sCLrSIcRbBaGAMy!=1:
				w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم الإلغاء')
				return
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.url_'+AcfzInE42p3Qh+'_'+lH4qDrXPiB2,y7DLSJYUTk3vBRr1cEfzI4b)
	rowl9WdfMmBvHIY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.useragent_'+AcfzInE42p3Qh)
	if not rowl9WdfMmBvHIY: xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.useragent_'+AcfzInE42p3Qh,'Unknown')
	KK5BTFDjA6RPp(AcfzInE42p3Qh)
	return
def bTRqpLQXA6mhguHaEs5z7i1e(LJpgrc4nMwCGiaVq2Zo0dyARBDf,r6lehPgt5UjSJHyoCMq0f2kZGVKBw3,GFVr4j7oCkhIlYXKm38Qu,OWr1M5Yj0DFzJuQxo38iVv,HLYhn8C2Ek7dXNM,j3jfh5sayUMv6nZ8LB,KmAnhFQyvJWqZxgcpU):
	snrNiTEh6zqZkUtlO,yjLoTdvM4J = [],[]
	XRcEB64u1IPlDvjwaqr2yWCAz = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for q8qv3XSGmsDjJZeMRxYafhnQ in LJpgrc4nMwCGiaVq2Zo0dyARBDf:
		if j3jfh5sayUMv6nZ8LB%473==0:
			jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,40+int(10*j3jfh5sayUMv6nZ8LB/HLYhn8C2Ek7dXNM),'قراءة الفيديوهات','الفيديو رقم:-',str(j3jfh5sayUMv6nZ8LB)+' / '+str(HLYhn8C2Ek7dXNM))
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return None,None,None
		s3chK0CpdkqFzAr6UvZloXHTwMxQmf = AxTYMhRlfyskNc0X19dvwtS.findall('^(.*?)\n+((http|https|rtmp).*?)$',q8qv3XSGmsDjJZeMRxYafhnQ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if s3chK0CpdkqFzAr6UvZloXHTwMxQmf:
			q8qv3XSGmsDjJZeMRxYafhnQ,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,nj7orTtZewDaWHdAL3Gp = s3chK0CpdkqFzAr6UvZloXHTwMxQmf[0]
			s3chK0CpdkqFzAr6UvZloXHTwMxQmf = s3chK0CpdkqFzAr6UvZloXHTwMxQmf.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			q8qv3XSGmsDjJZeMRxYafhnQ = q8qv3XSGmsDjJZeMRxYafhnQ.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		else:
			yjLoTdvM4J.append({'line':q8qv3XSGmsDjJZeMRxYafhnQ})
			continue
		vvYQUlwVBSkfm,WPHK5192hQ8lmL34OukgqMUS0CVF,NgZsLrE9mYIe0R51V7PGHUcM4J,oj5EvxCrn2m,ZJksHpSUNh2f,e0yAmJRBC7T6PnikxKbZGt2LrwsF = {},VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,False
		try:
			q8qv3XSGmsDjJZeMRxYafhnQ,oj5EvxCrn2m = q8qv3XSGmsDjJZeMRxYafhnQ.rsplit('",',1)
			q8qv3XSGmsDjJZeMRxYafhnQ = q8qv3XSGmsDjJZeMRxYafhnQ+'"'
		except:
			try: q8qv3XSGmsDjJZeMRxYafhnQ,oj5EvxCrn2m = q8qv3XSGmsDjJZeMRxYafhnQ.rsplit('1,',1)
			except: oj5EvxCrn2m = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		vvYQUlwVBSkfm['url'] = s3chK0CpdkqFzAr6UvZloXHTwMxQmf
		Be1lSTzVhCvDYFG3jtnNJRwgWpO2 = AxTYMhRlfyskNc0X19dvwtS.findall(' (.*?)="(.*?)"',q8qv3XSGmsDjJZeMRxYafhnQ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for xngTvzlop02PjM7ZdA,qeEpJgotKPZfS3hIynH in Be1lSTzVhCvDYFG3jtnNJRwgWpO2:
			xngTvzlop02PjM7ZdA = xngTvzlop02PjM7ZdA.replace('"',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			vvYQUlwVBSkfm[xngTvzlop02PjM7ZdA] = qeEpJgotKPZfS3hIynH.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		iitATlxFpEau = list(vvYQUlwVBSkfm.keys())
		if not oj5EvxCrn2m:
			if 'name' in iitATlxFpEau and vvYQUlwVBSkfm['name']: oj5EvxCrn2m = vvYQUlwVBSkfm['name']
		vvYQUlwVBSkfm['title'] = oj5EvxCrn2m.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'logo' in iitATlxFpEau:
			vvYQUlwVBSkfm['img'] = vvYQUlwVBSkfm['logo']
			del vvYQUlwVBSkfm['logo']
		else: vvYQUlwVBSkfm['img'] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if 'group' in iitATlxFpEau and vvYQUlwVBSkfm['group']: NgZsLrE9mYIe0R51V7PGHUcM4J = vvYQUlwVBSkfm['group']
		if any(value in s3chK0CpdkqFzAr6UvZloXHTwMxQmf.lower() for value in XRcEB64u1IPlDvjwaqr2yWCAz):
			e0yAmJRBC7T6PnikxKbZGt2LrwsF = True if 'm3u' not in s3chK0CpdkqFzAr6UvZloXHTwMxQmf else False
		if e0yAmJRBC7T6PnikxKbZGt2LrwsF or '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J or '__MOVIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J:
			ZJksHpSUNh2f = 'VOD'
			if '__SERIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J: ZJksHpSUNh2f = ZJksHpSUNh2f+'_SERIES'
			elif '__MOVIES__' in NgZsLrE9mYIe0R51V7PGHUcM4J: ZJksHpSUNh2f = ZJksHpSUNh2f+'_MOVIES'
			else: ZJksHpSUNh2f = ZJksHpSUNh2f+'_UNKNOWN'
			NgZsLrE9mYIe0R51V7PGHUcM4J = NgZsLrE9mYIe0R51V7PGHUcM4J.replace('__SERIES__',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('__MOVIES__',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		else:
			ZJksHpSUNh2f = 'LIVE'
			if oj5EvxCrn2m in r6lehPgt5UjSJHyoCMq0f2kZGVKBw3: WPHK5192hQ8lmL34OukgqMUS0CVF = WPHK5192hQ8lmL34OukgqMUS0CVF+'_EPG'
			if oj5EvxCrn2m in GFVr4j7oCkhIlYXKm38Qu: WPHK5192hQ8lmL34OukgqMUS0CVF = WPHK5192hQ8lmL34OukgqMUS0CVF+'_ARCHIVED'
			if not NgZsLrE9mYIe0R51V7PGHUcM4J: ZJksHpSUNh2f = ZJksHpSUNh2f+'_UNKNOWN'
			else: ZJksHpSUNh2f = ZJksHpSUNh2f+WPHK5192hQ8lmL34OukgqMUS0CVF
		NgZsLrE9mYIe0R51V7PGHUcM4J = NgZsLrE9mYIe0R51V7PGHUcM4J.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'LIVE_UNKNOWN' in ZJksHpSUNh2f: NgZsLrE9mYIe0R51V7PGHUcM4J = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ZJksHpSUNh2f: NgZsLrE9mYIe0R51V7PGHUcM4J = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ZJksHpSUNh2f:
			OVY9yJRKWn4XjzLaMpsNIQGr2A = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) [Ss]\d+ +[Ee]\d+',vvYQUlwVBSkfm['title'],AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if OVY9yJRKWn4XjzLaMpsNIQGr2A: OVY9yJRKWn4XjzLaMpsNIQGr2A = OVY9yJRKWn4XjzLaMpsNIQGr2A[0]
			else: OVY9yJRKWn4XjzLaMpsNIQGr2A = '!!__UNKNOWN_SERIES__!!'
			NgZsLrE9mYIe0R51V7PGHUcM4J = NgZsLrE9mYIe0R51V7PGHUcM4J+'__SERIES__'+OVY9yJRKWn4XjzLaMpsNIQGr2A
		if 'id' in iitATlxFpEau: del vvYQUlwVBSkfm['id']
		if 'ID' in iitATlxFpEau: del vvYQUlwVBSkfm['ID']
		if 'name' in iitATlxFpEau: del vvYQUlwVBSkfm['name']
		oj5EvxCrn2m = vvYQUlwVBSkfm['title']
		oj5EvxCrn2m = kd8ZhJPCe7QzxLgij3TEHlGtOv(oj5EvxCrn2m)
		oj5EvxCrn2m = kaXqMiEFzQwZ4sA(oj5EvxCrn2m)
		WCSnTNgQmk38L6f9,NgZsLrE9mYIe0R51V7PGHUcM4J = xYKHaOdeklpNToqEL5Dyt6Sih1(NgZsLrE9mYIe0R51V7PGHUcM4J)
		GuDIQh2wqxoscNK4SvUHdl,oj5EvxCrn2m = xYKHaOdeklpNToqEL5Dyt6Sih1(oj5EvxCrn2m)
		vvYQUlwVBSkfm['type'] = ZJksHpSUNh2f
		vvYQUlwVBSkfm['context'] = WPHK5192hQ8lmL34OukgqMUS0CVF
		vvYQUlwVBSkfm['group'] = NgZsLrE9mYIe0R51V7PGHUcM4J.upper()
		vvYQUlwVBSkfm['title'] = oj5EvxCrn2m.upper()
		vvYQUlwVBSkfm['country'] = GuDIQh2wqxoscNK4SvUHdl.upper()
		vvYQUlwVBSkfm['language'] = WCSnTNgQmk38L6f9.upper()
		snrNiTEh6zqZkUtlO.append(vvYQUlwVBSkfm)
		j3jfh5sayUMv6nZ8LB += 1
	return snrNiTEh6zqZkUtlO,j3jfh5sayUMv6nZ8LB,yjLoTdvM4J
def kaXqMiEFzQwZ4sA(oj5EvxCrn2m):
	oj5EvxCrn2m = oj5EvxCrn2m.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	oj5EvxCrn2m = oj5EvxCrn2m.replace('||','|').replace('___',':').replace('--','-')
	oj5EvxCrn2m = oj5EvxCrn2m.replace('[[','[').replace(']]',']')
	oj5EvxCrn2m = oj5EvxCrn2m.replace('((','(').replace('))',')')
	oj5EvxCrn2m = oj5EvxCrn2m.replace('<<','<').replace('>>','>')
	oj5EvxCrn2m = oj5EvxCrn2m.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	return oj5EvxCrn2m
def Mh3ztrXbHKTmJvDa9ZQAO85uP(BFciJYu80Qv46khb3dHjZAt,OWr1M5Yj0DFzJuQxo38iVv,lH4qDrXPiB2):
	TNQqlro2bMgSI4s0dw9UWVtvkD = {}
	for KCWGLSjkXcIs2lOa9 in ll1VzW039ATNi27uYHfU4xchpEyk: TNQqlro2bMgSI4s0dw9UWVtvkD[KCWGLSjkXcIs2lOa9+'_'+lH4qDrXPiB2] = []
	HLYhn8C2Ek7dXNM = len(BFciJYu80Qv46khb3dHjZAt)
	Dcq06fyONboAHQnamSg = str(HLYhn8C2Ek7dXNM)
	j3jfh5sayUMv6nZ8LB = 0
	yjLoTdvM4J = []
	for vvYQUlwVBSkfm in BFciJYu80Qv46khb3dHjZAt:
		if j3jfh5sayUMv6nZ8LB%873==0:
			jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,50+int(5*j3jfh5sayUMv6nZ8LB/HLYhn8C2Ek7dXNM),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(j3jfh5sayUMv6nZ8LB)+' / '+Dcq06fyONboAHQnamSg)
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return None,None
		NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN = vvYQUlwVBSkfm['group'],vvYQUlwVBSkfm['context'],vvYQUlwVBSkfm['title'],vvYQUlwVBSkfm['url'],vvYQUlwVBSkfm['img']
		GuDIQh2wqxoscNK4SvUHdl,WCSnTNgQmk38L6f9,KCWGLSjkXcIs2lOa9 = vvYQUlwVBSkfm['country'],vvYQUlwVBSkfm['language'],vvYQUlwVBSkfm['type']
		McVTxXsbG8WqmNlye = (NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN)
		YY3PqRdNApw6aGyj = False
		if 'LIVE' in KCWGLSjkXcIs2lOa9:
			if 'UNKNOWN' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_UNKNOWN_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			elif 'LIVE' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			else: YY3PqRdNApw6aGyj = True
			TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_ORIGINAL_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
		elif 'VOD' in KCWGLSjkXcIs2lOa9:
			if 'UNKNOWN' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_UNKNOWN_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			elif 'MOVIES' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_MOVIES_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			elif 'SERIES' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_SERIES_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			else: YY3PqRdNApw6aGyj = True
			TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_ORIGINAL_GROUPED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
		else: YY3PqRdNApw6aGyj = True
		if YY3PqRdNApw6aGyj: yjLoTdvM4J.append(vvYQUlwVBSkfm)
		j3jfh5sayUMv6nZ8LB += 1
	ZysJz4mWKeMk7afLV = sorted(BFciJYu80Qv46khb3dHjZAt,reverse=False,key=lambda xngTvzlop02PjM7ZdA: xngTvzlop02PjM7ZdA['title'].lower())
	del BFciJYu80Qv46khb3dHjZAt
	Dcq06fyONboAHQnamSg = str(HLYhn8C2Ek7dXNM)
	j3jfh5sayUMv6nZ8LB = 0
	for vvYQUlwVBSkfm in ZysJz4mWKeMk7afLV:
		j3jfh5sayUMv6nZ8LB += 1
		if j3jfh5sayUMv6nZ8LB%873==0:
			jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,55+int(5*j3jfh5sayUMv6nZ8LB/HLYhn8C2Ek7dXNM),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(j3jfh5sayUMv6nZ8LB)+' / '+Dcq06fyONboAHQnamSg)
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return None,None
		KCWGLSjkXcIs2lOa9 = vvYQUlwVBSkfm['type']
		NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN = vvYQUlwVBSkfm['group'],vvYQUlwVBSkfm['context'],vvYQUlwVBSkfm['title'],vvYQUlwVBSkfm['url'],vvYQUlwVBSkfm['img']
		GuDIQh2wqxoscNK4SvUHdl,WCSnTNgQmk38L6f9 = vvYQUlwVBSkfm['country'],vvYQUlwVBSkfm['language']
		C34BaTvG9pbERWs8mwDqf2zcnkjh = (NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF+'_TIMESHIFT',oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN)
		McVTxXsbG8WqmNlye = (NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN)
		ShoaTQr53x = (GuDIQh2wqxoscNK4SvUHdl,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN)
		uZK9qmGWzRHIsDLcfbTgBaNh0y2X = (WCSnTNgQmk38L6f9,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN)
		if 'LIVE' in KCWGLSjkXcIs2lOa9:
			if 'UNKNOWN' in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_UNKNOWN_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			else: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			if 'EPG'		in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_EPG_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			if 'ARCHIVED'	in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_ARCHIVED_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			if 'ARCHIVED'	in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_TIMESHIFT_GROUPED_SORTED_'+lH4qDrXPiB2].append(C34BaTvG9pbERWs8mwDqf2zcnkjh)
			TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_FROM_NAME_SORTED_'+lH4qDrXPiB2].append(ShoaTQr53x)
			TNQqlro2bMgSI4s0dw9UWVtvkD['LIVE_FROM_GROUP_SORTED_'+lH4qDrXPiB2].append(uZK9qmGWzRHIsDLcfbTgBaNh0y2X)
		elif 'VOD' in KCWGLSjkXcIs2lOa9:
			if   'UNKNOWN'	in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_UNKNOWN_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			elif 'MOVIES'	in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_MOVIES_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			elif 'SERIES'	in KCWGLSjkXcIs2lOa9: TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_SERIES_GROUPED_SORTED_'+lH4qDrXPiB2].append(McVTxXsbG8WqmNlye)
			TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_FROM_NAME_SORTED_'+lH4qDrXPiB2].append(ShoaTQr53x)
			TNQqlro2bMgSI4s0dw9UWVtvkD['VOD_FROM_GROUP_SORTED_'+lH4qDrXPiB2].append(uZK9qmGWzRHIsDLcfbTgBaNh0y2X)
	return TNQqlro2bMgSI4s0dw9UWVtvkD,yjLoTdvM4J
def xYKHaOdeklpNToqEL5Dyt6Sih1(oj5EvxCrn2m):
	if len(oj5EvxCrn2m)<3: return oj5EvxCrn2m,oj5EvxCrn2m
	mmc42gTad1Hbx8OXnrEPvoAGkw6z,xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	Vh3XcBw0odjLvtnf4m8EUD = oj5EvxCrn2m
	RTwlfoXPY29H = oj5EvxCrn2m[:1]
	L5kbnzqsOi0rMJaD6vWfUeKo = oj5EvxCrn2m[1:]
	if   RTwlfoXPY29H=='(': xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = ')'
	elif RTwlfoXPY29H=='[': xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = ']'
	elif RTwlfoXPY29H=='<': xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = '>'
	elif RTwlfoXPY29H=='|': xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = '|'
	if xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc and (xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc in L5kbnzqsOi0rMJaD6vWfUeKo):
		cQgL5HD9BUPoSwmIJGEyqjTanvWZf3,axANE7zlXFvQ = L5kbnzqsOi0rMJaD6vWfUeKo.split(xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc,1)
		mmc42gTad1Hbx8OXnrEPvoAGkw6z = cQgL5HD9BUPoSwmIJGEyqjTanvWZf3
		Vh3XcBw0odjLvtnf4m8EUD = RTwlfoXPY29H+cQgL5HD9BUPoSwmIJGEyqjTanvWZf3+xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc+WRsuxHTjDgYCIpoMQzLFAtS8rikP+axANE7zlXFvQ
	elif oj5EvxCrn2m.count('|')>=2:
		cQgL5HD9BUPoSwmIJGEyqjTanvWZf3,axANE7zlXFvQ = oj5EvxCrn2m.split('|',1)
		mmc42gTad1Hbx8OXnrEPvoAGkw6z = cQgL5HD9BUPoSwmIJGEyqjTanvWZf3
		Vh3XcBw0odjLvtnf4m8EUD = cQgL5HD9BUPoSwmIJGEyqjTanvWZf3+' |'+axANE7zlXFvQ
	else:
		xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = AxTYMhRlfyskNc0X19dvwtS.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oj5EvxCrn2m,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc: xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = AxTYMhRlfyskNc0X19dvwtS.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oj5EvxCrn2m,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc: xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc = AxTYMhRlfyskNc0X19dvwtS.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oj5EvxCrn2m,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc:
			cQgL5HD9BUPoSwmIJGEyqjTanvWZf3,axANE7zlXFvQ = oj5EvxCrn2m.split(xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc[0],1)
			mmc42gTad1Hbx8OXnrEPvoAGkw6z = cQgL5HD9BUPoSwmIJGEyqjTanvWZf3
			Vh3XcBw0odjLvtnf4m8EUD = cQgL5HD9BUPoSwmIJGEyqjTanvWZf3+WRsuxHTjDgYCIpoMQzLFAtS8rikP+xLsjTWQGkoyvE8B2dOUb6XK3CV5zrc[0]+WRsuxHTjDgYCIpoMQzLFAtS8rikP+axANE7zlXFvQ
	Vh3XcBw0odjLvtnf4m8EUD = Vh3XcBw0odjLvtnf4m8EUD.replace(NzlAQMRChm8J34urLwcUOn1f,WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	mmc42gTad1Hbx8OXnrEPvoAGkw6z = mmc42gTad1Hbx8OXnrEPvoAGkw6z.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	if not mmc42gTad1Hbx8OXnrEPvoAGkw6z: mmc42gTad1Hbx8OXnrEPvoAGkw6z = '!!__UNKNOWN__!!'
	mmc42gTad1Hbx8OXnrEPvoAGkw6z = mmc42gTad1Hbx8OXnrEPvoAGkw6z.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	Vh3XcBw0odjLvtnf4m8EUD = Vh3XcBw0odjLvtnf4m8EUD.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
	return mmc42gTad1Hbx8OXnrEPvoAGkw6z,Vh3XcBw0odjLvtnf4m8EUD
def fftOL25ErDvaseq(AcfzInE42p3Qh):
	Y64UgIz2uFvr30eLtDGyqanRZQKN = {}
	rowl9WdfMmBvHIY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.useragent_'+AcfzInE42p3Qh)
	if rowl9WdfMmBvHIY: Y64UgIz2uFvr30eLtDGyqanRZQKN['User-Agent'] = rowl9WdfMmBvHIY
	QhU5Rs8WnFpcIX = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.referer_'+AcfzInE42p3Qh)
	if QhU5Rs8WnFpcIX: Y64UgIz2uFvr30eLtDGyqanRZQKN['Referer'] = QhU5Rs8WnFpcIX
	return Y64UgIz2uFvr30eLtDGyqanRZQKN
def uy9bk2eYB8L1AJ(AcfzInE42p3Qh,lH4qDrXPiB2):
	global OWr1M5Yj0DFzJuQxo38iVv,TNQqlro2bMgSI4s0dw9UWVtvkD,cgLS8s69tRiqnkbHAdaXGMlCTvUm51,KTVLY0k2I57CQv3OqJH,LnMouxEwTQhdlKW0fNOmIC,vZlukQzIfxCsKH4GW18XmNyq,uNaY9r1ACesF5TSB63qmIJi,EEnlUD7m5F846ikdbJ1QYSTweajHKW,C4PbSYeskM5EVuUvWTfGIAFL
	KmAnhFQyvJWqZxgcpU = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.url_'+AcfzInE42p3Qh+'_'+lH4qDrXPiB2)
	rowl9WdfMmBvHIY = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.useragent_'+AcfzInE42p3Qh)
	Y64UgIz2uFvr30eLtDGyqanRZQKN = {'User-Agent':rowl9WdfMmBvHIY}
	WEIRS5qfJDmGNX8L43uzaAt9jc = uuipOUPQcSGmbIAlyWjr7RHtkD09.replace('___','_'+AcfzInE42p3Qh+'_'+lH4qDrXPiB2)
	if 1:
		ck9d5OzUV7qIj4BxCAWam3NJsH,A5dEiPaRMX3CDp4jOGkntTfmSKl,pfSZ2MEIXBYyL = True,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		if not ck9d5OzUV7qIj4BxCAWam3NJsH:
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not KmAnhFQyvJWqZxgcpU: UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(mI6ayKxBvjd4CRthL)+'   No M3U URL found to download M3U files')
			else: UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(qqJpX5yPB1ldDwvYTa6cbtK0FsUS2r)+'   Failed to download M3U files')
			return
		SoQMmVPBG4U3jxRsbNI2J5HO98tz = UNP40uFefR(KmAnhFQyvJWqZxgcpU,Y64UgIz2uFvr30eLtDGyqanRZQKN,True)
		if not SoQMmVPBG4U3jxRsbNI2J5HO98tz: return
		open(WEIRS5qfJDmGNX8L43uzaAt9jc,'wb').write(SoQMmVPBG4U3jxRsbNI2J5HO98tz)
	else: SoQMmVPBG4U3jxRsbNI2J5HO98tz = open(WEIRS5qfJDmGNX8L43uzaAt9jc,'rb').read()
	if fOohwvakqi29cx0l3yt5mzrAGpEg and SoQMmVPBG4U3jxRsbNI2J5HO98tz: SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.decode(RMGz7OiD1e30P)
	OWr1M5Yj0DFzJuQxo38iVv = QHi2JtdhMaw0INlU()
	OWr1M5Yj0DFzJuQxo38iVv.create('جلب ملفات M3U جديدة',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,15,'تنظيف الملف الرئيسي',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.replace('"tvg-','" tvg-')
	SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.replace('َ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ً',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ُ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ٌ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.replace('ّ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ِ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ٍ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('ْ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.replace('group-title=','group=').replace('tvg-',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	GFVr4j7oCkhIlYXKm38Qu,r6lehPgt5UjSJHyoCMq0f2kZGVKBw3 = [],[]
	SoQMmVPBG4U3jxRsbNI2J5HO98tz = SoQMmVPBG4U3jxRsbNI2J5HO98tz.replace(b6JZWhsCvwOyV041EdQTcu,b8sk5WyPoz03pXhRx)
	LJpgrc4nMwCGiaVq2Zo0dyARBDf = AxTYMhRlfyskNc0X19dvwtS.findall('NF:(.+?)'+'#'+'EXTI',SoQMmVPBG4U3jxRsbNI2J5HO98tz+'\n+'+'#'+'EXTINF:',AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if not LJpgrc4nMwCGiaVq2Zo0dyARBDf:
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,yyxuAh7r4WfZelpY8HXK(qqJpX5yPB1ldDwvYTa6cbtK0FsUS2r)+'   Folder:'+AcfzInE42p3Qh+'  Sequence:'+lH4qDrXPiB2+'   No video links found in M3U file')
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+b8sk5WyPoz03pXhRx+oamlxBqLdu4ZM9nQrbIAhS5Pg7+'مجلد رقم '+AcfzInE42p3Qh+'      رابط رقم '+lH4qDrXPiB2+so4Z8OUJ5E)
		OWr1M5Yj0DFzJuQxo38iVv.close()
		return
	yfEMVqH9n5UDYrx06mhWp2kgCZ = []
	for q8qv3XSGmsDjJZeMRxYafhnQ in LJpgrc4nMwCGiaVq2Zo0dyARBDf:
		pgtxYR87izfIBeZb = q8qv3XSGmsDjJZeMRxYafhnQ.lower()
		if 'adult' in pgtxYR87izfIBeZb: continue
		if 'xxx' in pgtxYR87izfIBeZb: continue
		yfEMVqH9n5UDYrx06mhWp2kgCZ.append(q8qv3XSGmsDjJZeMRxYafhnQ)
	LJpgrc4nMwCGiaVq2Zo0dyARBDf = yfEMVqH9n5UDYrx06mhWp2kgCZ
	del yfEMVqH9n5UDYrx06mhWp2kgCZ
	if 'iptv-org' in KmAnhFQyvJWqZxgcpU:
		yfEMVqH9n5UDYrx06mhWp2kgCZ,osxYG8TJUAyO = [],[]
		for q8qv3XSGmsDjJZeMRxYafhnQ in LJpgrc4nMwCGiaVq2Zo0dyARBDf:
			vZlukQzIfxCsKH4GW18XmNyq = AxTYMhRlfyskNc0X19dvwtS.findall('group="(.*?)"',q8qv3XSGmsDjJZeMRxYafhnQ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if vZlukQzIfxCsKH4GW18XmNyq:
				vZlukQzIfxCsKH4GW18XmNyq = vZlukQzIfxCsKH4GW18XmNyq[0]
				yym6TYhwluqa0dofiU7 = vZlukQzIfxCsKH4GW18XmNyq.split(';')
				if 'region' in KmAnhFQyvJWqZxgcpU: vdwCLniQlu7UIqhx30NJG19 = '1_'
				elif 'category' in KmAnhFQyvJWqZxgcpU: vdwCLniQlu7UIqhx30NJG19 = '2_'
				elif 'language' in KmAnhFQyvJWqZxgcpU: vdwCLniQlu7UIqhx30NJG19 = '3_'
				elif 'country' in KmAnhFQyvJWqZxgcpU: vdwCLniQlu7UIqhx30NJG19 = '4_'
				else: vdwCLniQlu7UIqhx30NJG19 = '5_'
				qZS9rOP5807puQ = q8qv3XSGmsDjJZeMRxYafhnQ.replace('group="'+vZlukQzIfxCsKH4GW18XmNyq+'"','group="'+vdwCLniQlu7UIqhx30NJG19+'~'+qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E+'"')
				yfEMVqH9n5UDYrx06mhWp2kgCZ.append(qZS9rOP5807puQ)
				for NgZsLrE9mYIe0R51V7PGHUcM4J in yym6TYhwluqa0dofiU7:
					qZS9rOP5807puQ = q8qv3XSGmsDjJZeMRxYafhnQ.replace('group="'+vZlukQzIfxCsKH4GW18XmNyq+'"','group="'+vdwCLniQlu7UIqhx30NJG19+NgZsLrE9mYIe0R51V7PGHUcM4J+'"')
					yfEMVqH9n5UDYrx06mhWp2kgCZ.append(qZS9rOP5807puQ)
			else: yfEMVqH9n5UDYrx06mhWp2kgCZ.append(q8qv3XSGmsDjJZeMRxYafhnQ)
		LJpgrc4nMwCGiaVq2Zo0dyARBDf = yfEMVqH9n5UDYrx06mhWp2kgCZ
		del yfEMVqH9n5UDYrx06mhWp2kgCZ,osxYG8TJUAyO
	SjJ4nLq59rTfzyb7ovuEQc6PKC = 1024*1024
	I8aDC1gcK0sJAQidOXn6Lo = 1+len(SoQMmVPBG4U3jxRsbNI2J5HO98tz)//SjJ4nLq59rTfzyb7ovuEQc6PKC//10
	del SoQMmVPBG4U3jxRsbNI2J5HO98tz
	xNoRLM85P31meDKYbOacWuI6vAl = len(LJpgrc4nMwCGiaVq2Zo0dyARBDf)
	osxYG8TJUAyO = YYQUxfRjykuwoi4a1(LJpgrc4nMwCGiaVq2Zo0dyARBDf,I8aDC1gcK0sJAQidOXn6Lo)
	del LJpgrc4nMwCGiaVq2Zo0dyARBDf
	for WWlVCHMzIF7qwQGvma6yd in range(I8aDC1gcK0sJAQidOXn6Lo):
		jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,35+int(5*WWlVCHMzIF7qwQGvma6yd/I8aDC1gcK0sJAQidOXn6Lo),'تقطيع الملف الرئيسي','الجزء رقم:-',str(WWlVCHMzIF7qwQGvma6yd+1)+' / '+str(I8aDC1gcK0sJAQidOXn6Lo))
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
		APiCsHb5OBlnk = str(osxYG8TJUAyO[WWlVCHMzIF7qwQGvma6yd])
		if fOohwvakqi29cx0l3yt5mzrAGpEg: APiCsHb5OBlnk = APiCsHb5OBlnk.encode(RMGz7OiD1e30P)
		open(WEIRS5qfJDmGNX8L43uzaAt9jc+'.00'+str(WWlVCHMzIF7qwQGvma6yd),'wb').write(APiCsHb5OBlnk)
	del osxYG8TJUAyO,APiCsHb5OBlnk
	rxGkHvKWhTC8P39LJit,BFciJYu80Qv46khb3dHjZAt,j3jfh5sayUMv6nZ8LB = [],[],0
	for WWlVCHMzIF7qwQGvma6yd in range(I8aDC1gcK0sJAQidOXn6Lo):
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
		APiCsHb5OBlnk = open(WEIRS5qfJDmGNX8L43uzaAt9jc+'.00'+str(WWlVCHMzIF7qwQGvma6yd),'rb').read()
		f7epsRlYtMz4.sleep(1)
		try: oNlez5gnM9x2B4.remove(WEIRS5qfJDmGNX8L43uzaAt9jc+'.00'+str(WWlVCHMzIF7qwQGvma6yd))
		except: pass
		if fOohwvakqi29cx0l3yt5mzrAGpEg: APiCsHb5OBlnk = APiCsHb5OBlnk.decode(RMGz7OiD1e30P)
		Za0dtXVBSo = rKY1tyQvh9OCxE2nl('list',APiCsHb5OBlnk)
		del APiCsHb5OBlnk
		snrNiTEh6zqZkUtlO,j3jfh5sayUMv6nZ8LB,yjLoTdvM4J = bTRqpLQXA6mhguHaEs5z7i1e(Za0dtXVBSo,r6lehPgt5UjSJHyoCMq0f2kZGVKBw3,GFVr4j7oCkhIlYXKm38Qu,OWr1M5Yj0DFzJuQxo38iVv,xNoRLM85P31meDKYbOacWuI6vAl,j3jfh5sayUMv6nZ8LB,KmAnhFQyvJWqZxgcpU)
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
		if not snrNiTEh6zqZkUtlO:
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
		BFciJYu80Qv46khb3dHjZAt += snrNiTEh6zqZkUtlO
		rxGkHvKWhTC8P39LJit += yjLoTdvM4J
	del Za0dtXVBSo,snrNiTEh6zqZkUtlO
	TNQqlro2bMgSI4s0dw9UWVtvkD,yjLoTdvM4J = Mh3ztrXbHKTmJvDa9ZQAO85uP(BFciJYu80Qv46khb3dHjZAt,OWr1M5Yj0DFzJuQxo38iVv,lH4qDrXPiB2)
	if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
		OWr1M5Yj0DFzJuQxo38iVv.close()
		return
	rxGkHvKWhTC8P39LJit += yjLoTdvM4J
	del BFciJYu80Qv46khb3dHjZAt,yjLoTdvM4J
	KTVLY0k2I57CQv3OqJH,LnMouxEwTQhdlKW0fNOmIC,vZlukQzIfxCsKH4GW18XmNyq,uNaY9r1ACesF5TSB63qmIJi,EEnlUD7m5F846ikdbJ1QYSTweajHKW = {},{},{},0,0
	bW12fu4aMKHRF78PzhJB9 = list(TNQqlro2bMgSI4s0dw9UWVtvkD.keys())
	C4PbSYeskM5EVuUvWTfGIAFL = len(bW12fu4aMKHRF78PzhJB9)*3
	if 1:
		qE6SnPdprItLji9U4zc5Kxokwa = {}
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH] = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=h7h5k1Y6elbMVmzL,args=(II4hU2E93TGRxYtNCcH,))
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH].start()
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH].join()
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
	else:
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			h7h5k1Y6elbMVmzL(II4hU2E93TGRxYtNCcH)
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return
	ISnpaPBOD58FX06YHAzd(AcfzInE42p3Qh,lH4qDrXPiB2,False)
	bW12fu4aMKHRF78PzhJB9 = list(KTVLY0k2I57CQv3OqJH.keys())
	cgLS8s69tRiqnkbHAdaXGMlCTvUm51 = 0
	if 1:
		qE6SnPdprItLji9U4zc5Kxokwa = {}
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH] = spd4z80uZXHyGxo6YqPhWSLaw1b(daemon=NFGqKBLtvUZn1S3dau,target=WXYGunoVhcKvtFikEBR08dD3,args=(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH))
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH].start()
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			qE6SnPdprItLji9U4zc5Kxokwa[II4hU2E93TGRxYtNCcH].join()
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
			OWr1M5Yj0DFzJuQxo38iVv.close()
			return
	else:
		for II4hU2E93TGRxYtNCcH in bW12fu4aMKHRF78PzhJB9:
			WXYGunoVhcKvtFikEBR08dD3(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH)
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return
	WWlVCHMzIF7qwQGvma6yd = 0
	QHjrzopMDa2qOVYTRAPu = len(rxGkHvKWhTC8P39LJit)
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,'IGNORED')
	for nLdVy0mHj6KR395BI8wF in rxGkHvKWhTC8P39LJit:
		if WWlVCHMzIF7qwQGvma6yd%27==0:
			jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,95+int(5*WWlVCHMzIF7qwQGvma6yd//QHjrzopMDa2qOVYTRAPu),'تخزين المهملة','الفيديو رقم:-',str(WWlVCHMzIF7qwQGvma6yd)+' / '+str(QHjrzopMDa2qOVYTRAPu))
			if OWr1M5Yj0DFzJuQxo38iVv.iscanceled():
				OWr1M5Yj0DFzJuQxo38iVv.close()
				return
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,'IGNORED_'+lH4qDrXPiB2,str(nLdVy0mHj6KR395BI8wF),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,iigI6zE7djY3yQasNTM5AW0PLOS4)
		WWlVCHMzIF7qwQGvma6yd += 1
	JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,'IGNORED_'+lH4qDrXPiB2,'__COUNT__',str(QHjrzopMDa2qOVYTRAPu),iigI6zE7djY3yQasNTM5AW0PLOS4)
	OWr1M5Yj0DFzJuQxo38iVv.close()
	f7epsRlYtMz4.sleep(1)
	KK5BTFDjA6RPp(AcfzInE42p3Qh)
	return
def h7h5k1Y6elbMVmzL(II4hU2E93TGRxYtNCcH):
	global OWr1M5Yj0DFzJuQxo38iVv,TNQqlro2bMgSI4s0dw9UWVtvkD,cgLS8s69tRiqnkbHAdaXGMlCTvUm51,KTVLY0k2I57CQv3OqJH,LnMouxEwTQhdlKW0fNOmIC,vZlukQzIfxCsKH4GW18XmNyq,uNaY9r1ACesF5TSB63qmIJi,EEnlUD7m5F846ikdbJ1QYSTweajHKW,C4PbSYeskM5EVuUvWTfGIAFL
	KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH] = {}
	SS3C6elVYnW7oiTqb15Pzmf,hZLCz2UAw1NGr53Jvt7Wl = {},[]
	uAO5nBNXpTvVPDaFsWmh13dt = len(TNQqlro2bMgSI4s0dw9UWVtvkD[II4hU2E93TGRxYtNCcH])
	KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH]['__COUNT__'] = uAO5nBNXpTvVPDaFsWmh13dt
	if uAO5nBNXpTvVPDaFsWmh13dt>0:
		uu4oVF5HzBOilXpYeEcIC,Aa6fFwtyr3lig15bQS8qnxI,DzKmpZ9QRaS1hi,yWBFS7Gdt3ZJN2nReiV,ggt1rBPqFCTU7463cR5xoSkVsZd = zip(*TNQqlro2bMgSI4s0dw9UWVtvkD[II4hU2E93TGRxYtNCcH])
		del Aa6fFwtyr3lig15bQS8qnxI,DzKmpZ9QRaS1hi,yWBFS7Gdt3ZJN2nReiV
		yym6TYhwluqa0dofiU7 = list(set(uu4oVF5HzBOilXpYeEcIC))
		for NgZsLrE9mYIe0R51V7PGHUcM4J in yym6TYhwluqa0dofiU7:
			SS3C6elVYnW7oiTqb15Pzmf[NgZsLrE9mYIe0R51V7PGHUcM4J] = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH][NgZsLrE9mYIe0R51V7PGHUcM4J] = []
		jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,60+int(15*EEnlUD7m5F846ikdbJ1QYSTweajHKW//C4PbSYeskM5EVuUvWTfGIAFL),'تصنيع القوائم','الجزء رقم:-',str(EEnlUD7m5F846ikdbJ1QYSTweajHKW)+' / '+str(C4PbSYeskM5EVuUvWTfGIAFL))
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled(): return
		EEnlUD7m5F846ikdbJ1QYSTweajHKW += 1
		LoJtlXGnmk = len(yym6TYhwluqa0dofiU7)
		del yym6TYhwluqa0dofiU7
		hZLCz2UAw1NGr53Jvt7Wl = list(set(zip(uu4oVF5HzBOilXpYeEcIC,ggt1rBPqFCTU7463cR5xoSkVsZd)))
		del uu4oVF5HzBOilXpYeEcIC,ggt1rBPqFCTU7463cR5xoSkVsZd
		for NgZsLrE9mYIe0R51V7PGHUcM4J,NNxWvh3OimPqguS in hZLCz2UAw1NGr53Jvt7Wl:
			if not SS3C6elVYnW7oiTqb15Pzmf[NgZsLrE9mYIe0R51V7PGHUcM4J] and NNxWvh3OimPqguS: SS3C6elVYnW7oiTqb15Pzmf[NgZsLrE9mYIe0R51V7PGHUcM4J] = NNxWvh3OimPqguS
		jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,60+int(15*EEnlUD7m5F846ikdbJ1QYSTweajHKW//C4PbSYeskM5EVuUvWTfGIAFL),'تصنيع القوائم','الجزء رقم:-',str(EEnlUD7m5F846ikdbJ1QYSTweajHKW)+' / '+str(C4PbSYeskM5EVuUvWTfGIAFL))
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled(): return
		EEnlUD7m5F846ikdbJ1QYSTweajHKW += 1
		E5SMmJN41L9uPcFyg8d0HnA = list(SS3C6elVYnW7oiTqb15Pzmf.keys())
		HzOD48wuQ1X7VtCYLBvqZMToEIljF = list(SS3C6elVYnW7oiTqb15Pzmf.values())
		del SS3C6elVYnW7oiTqb15Pzmf
		hZLCz2UAw1NGr53Jvt7Wl = list(zip(E5SMmJN41L9uPcFyg8d0HnA,HzOD48wuQ1X7VtCYLBvqZMToEIljF))
		del E5SMmJN41L9uPcFyg8d0HnA,HzOD48wuQ1X7VtCYLBvqZMToEIljF
		hZLCz2UAw1NGr53Jvt7Wl = sorted(hZLCz2UAw1NGr53Jvt7Wl)
	else: EEnlUD7m5F846ikdbJ1QYSTweajHKW += 2
	KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH]['__GROUPS__'] = hZLCz2UAw1NGr53Jvt7Wl
	del hZLCz2UAw1NGr53Jvt7Wl
	for NgZsLrE9mYIe0R51V7PGHUcM4J,WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN in TNQqlro2bMgSI4s0dw9UWVtvkD[II4hU2E93TGRxYtNCcH]:
		KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH][NgZsLrE9mYIe0R51V7PGHUcM4J].append((WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN))
	jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,60+int(15*EEnlUD7m5F846ikdbJ1QYSTweajHKW//C4PbSYeskM5EVuUvWTfGIAFL),'تصنيع القوائم','الجزء رقم:-',str(EEnlUD7m5F846ikdbJ1QYSTweajHKW)+' / '+str(C4PbSYeskM5EVuUvWTfGIAFL))
	if OWr1M5Yj0DFzJuQxo38iVv.iscanceled(): return
	EEnlUD7m5F846ikdbJ1QYSTweajHKW += 1
	del TNQqlro2bMgSI4s0dw9UWVtvkD[II4hU2E93TGRxYtNCcH]
	vZlukQzIfxCsKH4GW18XmNyq[II4hU2E93TGRxYtNCcH] = list(KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH].keys())
	LnMouxEwTQhdlKW0fNOmIC[II4hU2E93TGRxYtNCcH] = len(vZlukQzIfxCsKH4GW18XmNyq[II4hU2E93TGRxYtNCcH])
	uNaY9r1ACesF5TSB63qmIJi += LnMouxEwTQhdlKW0fNOmIC[II4hU2E93TGRxYtNCcH]
	return
def WXYGunoVhcKvtFikEBR08dD3(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH):
	global OWr1M5Yj0DFzJuQxo38iVv,TNQqlro2bMgSI4s0dw9UWVtvkD,cgLS8s69tRiqnkbHAdaXGMlCTvUm51,KTVLY0k2I57CQv3OqJH,LnMouxEwTQhdlKW0fNOmIC,vZlukQzIfxCsKH4GW18XmNyq,uNaY9r1ACesF5TSB63qmIJi,EEnlUD7m5F846ikdbJ1QYSTweajHKW,C4PbSYeskM5EVuUvWTfGIAFL
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH)
	for j3jfh5sayUMv6nZ8LB in range(1+LnMouxEwTQhdlKW0fNOmIC[II4hU2E93TGRxYtNCcH]//273):
		YSyu4AnT8XJbhizQZIafE2MeBPs9U = []
		ZZ6kPsMfHCFV = vZlukQzIfxCsKH4GW18XmNyq[II4hU2E93TGRxYtNCcH][0:273]
		for NgZsLrE9mYIe0R51V7PGHUcM4J in ZZ6kPsMfHCFV:
			YSyu4AnT8XJbhizQZIafE2MeBPs9U.append(KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH][NgZsLrE9mYIe0R51V7PGHUcM4J])
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,II4hU2E93TGRxYtNCcH,ZZ6kPsMfHCFV,YSyu4AnT8XJbhizQZIafE2MeBPs9U,iigI6zE7djY3yQasNTM5AW0PLOS4,True)
		cgLS8s69tRiqnkbHAdaXGMlCTvUm51 += len(ZZ6kPsMfHCFV)
		jRhY6cet0NVsfGIr(OWr1M5Yj0DFzJuQxo38iVv,75+int(20*cgLS8s69tRiqnkbHAdaXGMlCTvUm51//uNaY9r1ACesF5TSB63qmIJi),'تخزين القوائم','القائمة رقم:-',str(cgLS8s69tRiqnkbHAdaXGMlCTvUm51)+' / '+str(uNaY9r1ACesF5TSB63qmIJi))
		if OWr1M5Yj0DFzJuQxo38iVv.iscanceled(): return
		del vZlukQzIfxCsKH4GW18XmNyq[II4hU2E93TGRxYtNCcH][0:273]
	del KTVLY0k2I57CQv3OqJH[II4hU2E93TGRxYtNCcH],vZlukQzIfxCsKH4GW18XmNyq[II4hU2E93TGRxYtNCcH],LnMouxEwTQhdlKW0fNOmIC[II4hU2E93TGRxYtNCcH]
	return
def e9YbvcGiMdH4DZuo2lX0CpgK73(AcfzInE42p3Qh,lH4qDrXPiB2,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	bSnajBI1Ns4hedDRPpKrACc6Mk = 'عدد فيديوهات جميع الروابط'
	VvIJTBYgzHNPstndXw3aCbo4Oyi = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,'LIVE_ORIGINAL_GROUPED')
	FzpH56qmIj = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,'VOD_ORIGINAL_GROUPED')
	if lH4qDrXPiB2:
		bSnajBI1Ns4hedDRPpKrACc6Mk = 'عدد فيديوهات رابط '+bCuhHjwS9lEQ2eB1c[int(lH4qDrXPiB2)]
		lH4qDrXPiB2 = '_'+lH4qDrXPiB2
	QHjrzopMDa2qOVYTRAPu = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','IGNORED'+lH4qDrXPiB2,'__COUNT__')
	oY5tjA4VrcSIL7P69a = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','LIVE_ORIGINAL_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	yqzuFYX5wfToCr7aRcGPlUmZsN = dYMLGvgfk4(FzpH56qmIj,'int','VOD_ORIGINAL_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	drUNnD0P7W948fT1azwlbsXkIAhvE = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','LIVE_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	y9UWS68cmaMX1DN = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','LIVE_UNKNOWN_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	EWhRmpyaMnC1 = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','VOD_MOVIES_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	cgKnVDCrBP378MT4asdfHNFyj = dYMLGvgfk4(FzpH56qmIj,'int','VOD_SERIES_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	Rus5owJOg89m2x1KHFiSE = dYMLGvgfk4(VvIJTBYgzHNPstndXw3aCbo4Oyi,'int','VOD_UNKNOWN_GROUPED'+lH4qDrXPiB2,'__COUNT__')
	vZlukQzIfxCsKH4GW18XmNyq = dYMLGvgfk4(FzpH56qmIj,'list','VOD_SERIES_GROUPED'+lH4qDrXPiB2,'__GROUPS__')
	eoGVXSvf3t98UOpRubs0x = []
	for NgZsLrE9mYIe0R51V7PGHUcM4J,QacvmqO47zo1MySl3BEN in vZlukQzIfxCsKH4GW18XmNyq:
		ouObUQ1YI4vSfn8XtAZV9cM = NgZsLrE9mYIe0R51V7PGHUcM4J.split('__SERIES__')[1]
		eoGVXSvf3t98UOpRubs0x.append(ouObUQ1YI4vSfn8XtAZV9cM)
	fsIQOejy2JBdt4FlrUX3ECwS8GpVhx = len(eoGVXSvf3t98UOpRubs0x)
	X8XfkuPCiaIJptHFT1 = int(EWhRmpyaMnC1)+int(cgKnVDCrBP378MT4asdfHNFyj)+int(Rus5owJOg89m2x1KHFiSE)+int(y9UWS68cmaMX1DN)+int(drUNnD0P7W948fT1azwlbsXkIAhvE)
	pTvHSF3uoXeVyc = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	pTvHSF3uoXeVyc += 'قنوات: '+str(drUNnD0P7W948fT1azwlbsXkIAhvE)
	pTvHSF3uoXeVyc += '   .   أفلام: '+str(EWhRmpyaMnC1)
	pTvHSF3uoXeVyc += '\nمسلسلات: '+str(fsIQOejy2JBdt4FlrUX3ECwS8GpVhx)
	pTvHSF3uoXeVyc += '   .   حلقات: '+str(cgKnVDCrBP378MT4asdfHNFyj)
	pTvHSF3uoXeVyc += '\nقنوات مجهولة: '+str(y9UWS68cmaMX1DN)
	pTvHSF3uoXeVyc += '   .   فيدوهات مجهولة: '+str(Rus5owJOg89m2x1KHFiSE)
	pTvHSF3uoXeVyc += '\nمجموع القنوات: '+str(oY5tjA4VrcSIL7P69a)
	pTvHSF3uoXeVyc += '   .   مجموع الفيديوهات: '+str(yqzuFYX5wfToCr7aRcGPlUmZsN)
	pTvHSF3uoXeVyc += '\n\nمجموع المضافة: '+str(X8XfkuPCiaIJptHFT1)
	pTvHSF3uoXeVyc += '   .   مجموع المهملة: '+str(QHjrzopMDa2qOVYTRAPu)
	if FBOMf1xKQphwczTvLNCjEkAnIa: w4dBvakygFs2IZO1Azt('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bSnajBI1Ns4hedDRPpKrACc6Mk,pTvHSF3uoXeVyc)
	dutIvRmZ2KeySxqXlPTBUNwsQkg09h = pTvHSF3uoXeVyc.replace('\n\n',b8sk5WyPoz03pXhRx)
	if not lH4qDrXPiB2: lH4qDrXPiB2 = 'All'
	else: lH4qDrXPiB2 = lH4qDrXPiB2[1]
	UO05pib6mcvezR9(jZBtGcdApeKLEkb,'.\tCounts of M3U videos   Folder: '+AcfzInE42p3Qh+'   Sequence: '+lH4qDrXPiB2+b8sk5WyPoz03pXhRx+dutIvRmZ2KeySxqXlPTBUNwsQkg09h)
	return pTvHSF3uoXeVyc
def ISnpaPBOD58FX06YHAzd(AcfzInE42p3Qh,lH4qDrXPiB2,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	if FBOMf1xKQphwczTvLNCjEkAnIa:
		vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if vvbjZeMTcKP4dXDQLf90B3mgwYV7!=1: return
		z4so3idKEZWnJRGk9TplPr8Mv0 = uuipOUPQcSGmbIAlyWjr7RHtkD09.replace('___','_'+AcfzInE42p3Qh+'_'+lH4qDrXPiB2)
		try: oNlez5gnM9x2B4.remove(z4so3idKEZWnJRGk9TplPr8Mv0)
		except: pass
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if lH4qDrXPiB2:
		tbCjnHYaqdZk217T5orl6hLFWsIyz0 = []
		for yyl9ncuTXwQjaFIg1Sik2AhL4tG in ll1VzW039ATNi27uYHfU4xchpEyk:
			tbCjnHYaqdZk217T5orl6hLFWsIyz0.append(yyl9ncuTXwQjaFIg1Sik2AhL4tG+'_'+lH4qDrXPiB2)
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,'LINK_'+lH4qDrXPiB2)
	else:
		tbCjnHYaqdZk217T5orl6hLFWsIyz0 = ll1VzW039ATNi27uYHfU4xchpEyk
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,'DUMMY')
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,'GROUPS')
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,'ITEMS')
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,'SEARCH')
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'SECTIONS_M3U','SECTIONS_M3U_'+AcfzInE42p3Qh)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for II4hU2E93TGRxYtNCcH in tbCjnHYaqdZk217T5orl6hLFWsIyz0:
		rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,II4hU2E93TGRxYtNCcH)
	ReBiOy1dYvpLJFI8G(False)
	KK5BTFDjA6RPp(AcfzInE42p3Qh)
	if FBOMf1xKQphwczTvLNCjEkAnIa: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم مسح جميع ملفات ـM3U')
	return
def rb1LQeqnckC(AcfzInE42p3Qh=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,FBOMf1xKQphwczTvLNCjEkAnIa=True):
	if AcfzInE42p3Qh:
		FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(str(AcfzInE42p3Qh),'DUMMY')
		nj7orTtZewDaWHdAL3Gp = dYMLGvgfk4(FCoNx1Hbcjipz,'str','DUMMY','__DUMMY__')
		if nj7orTtZewDaWHdAL3Gp: return True
	else:
		AcfzInE42p3Qh = '1'
		for f7C6EP5SDznwts in range(1,RR1typGWKXVd6vNAaMEqo9h+1):
			FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(str(f7C6EP5SDznwts),'DUMMY')
			nj7orTtZewDaWHdAL3Gp = dYMLGvgfk4(FCoNx1Hbcjipz,'str','DUMMY','__DUMMY__')
			if nj7orTtZewDaWHdAL3Gp: return True
	if FBOMf1xKQphwczTvLNCjEkAnIa:
		lN4MCeIYcZ1xVBSFaJUL = 'https://iptv-org.github.io/iptv/index.region.m3u'
		xxuviH4BlY6djnhazE3sOceRK0WrQ = 'https://iptv-org.github.io/iptv/index.category.m3u'
		iX3Q6HY0WTK = 'https://iptv-org.github.io/iptv/index.language.m3u'
		iL2Y81Z9xP7w = 'https://iptv-org.github.io/iptv/index.country.m3u'
		cW54mMRdXOjBkSNTxsE1yIvuwq3V = lN4MCeIYcZ1xVBSFaJUL+b8sk5WyPoz03pXhRx+xxuviH4BlY6djnhazE3sOceRK0WrQ+b8sk5WyPoz03pXhRx+iX3Q6HY0WTK+b8sk5WyPoz03pXhRx+iL2Y81Z9xP7w
		vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+qFghPAi5yz9Vf3NLwo0nuprl+'http://github.com/iptv-org/iptv'+so4Z8OUJ5E+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+qFghPAi5yz9Vf3NLwo0nuprl+cW54mMRdXOjBkSNTxsE1yIvuwq3V+so4Z8OUJ5E,profile='confirm_smallfont')
		if vvbjZeMTcKP4dXDQLf90B3mgwYV7==1:
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.url_'+str(AcfzInE42p3Qh)+'_1',lN4MCeIYcZ1xVBSFaJUL)
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.url_'+str(AcfzInE42p3Qh)+'_2',xxuviH4BlY6djnhazE3sOceRK0WrQ)
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.url_'+str(AcfzInE42p3Qh)+'_3',iX3Q6HY0WTK)
			xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.m3u.url_'+str(AcfzInE42p3Qh)+'_4',iL2Y81Z9xP7w)
			vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if vvbjZeMTcKP4dXDQLf90B3mgwYV7==1:
				Y6vuFqnOyPSKAEQGlWVUB = zL7ZXKbV6nrfuGkhRTwl8x(AcfzInE42p3Qh)
				return Y6vuFqnOyPSKAEQGlWVUB
		else:
			bSnajBI1Ns4hedDRPpKrACc6Mk = 'إضافة وتغيير رابط '+bCuhHjwS9lEQ2eB1c[1]+' (مجلد '+bCuhHjwS9lEQ2eB1c[int(AcfzInE42p3Qh)]+')'
			vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bSnajBI1Ns4hedDRPpKrACc6Mk,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. ثانيا أنقر على إضافة رابط أو اشتراك M3U .. ثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if vvbjZeMTcKP4dXDQLf90B3mgwYV7==1: y3Ngcfoi5XRF4b0qIZ(AcfzInE42p3Qh,'1')
	return False
def hXmPJGkvHSYLdntjR9Vfu1b(wweqETA3WHOSBniZN,AcfzInE42p3Qh=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,II4hU2E93TGRxYtNCcH=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ZZQzs8ITl6imhJCot=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not ZZQzs8ITl6imhJCot: ZZQzs8ITl6imhJCot = '1'
	a9YrjQPdZ8JicSD2LbG,wVtSpAsUu0cMblPqxK1F,FBOMf1xKQphwczTvLNCjEkAnIa = EAgxpW09CSdZBy82KtTG4(wweqETA3WHOSBniZN)
	if not rb1LQeqnckC(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa): return
	if not a9YrjQPdZ8JicSD2LbG:
		a9YrjQPdZ8JicSD2LbG = TwDBf3QbKOnrmd5u9()
		if not a9YrjQPdZ8JicSD2LbG: return
	nTbx5t3HpS = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not II4hU2E93TGRxYtNCcH:
		if not FBOMf1xKQphwczTvLNCjEkAnIa:
			if   '_M3U-LIVE_' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[1]
			elif '_M3U-MOVIES' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[2]
			elif '_M3U-SERIES' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[3]
			else: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[0]
		else:
			Xa5yE8WPphu7cZidl1YUmvA3e42 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			jwgM2qYVpdK5ly = YLUMzC9m0dc('أختر البحث المناسب', Xa5yE8WPphu7cZidl1YUmvA3e42)
			if jwgM2qYVpdK5ly==-1: return
			II4hU2E93TGRxYtNCcH = nTbx5t3HpS[jwgM2qYVpdK5ly]
	a9YrjQPdZ8JicSD2LbG = a9YrjQPdZ8JicSD2LbG+'_NODIALOGS_'
	if AcfzInE42p3Qh: b198LikC6enZRjEgXHvdpNQ(a9YrjQPdZ8JicSD2LbG,AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH,ZZQzs8ITl6imhJCot)
	else:
		for AcfzInE42p3Qh in range(1,RR1typGWKXVd6vNAaMEqo9h+1):
			b198LikC6enZRjEgXHvdpNQ(a9YrjQPdZ8JicSD2LbG,str(AcfzInE42p3Qh),II4hU2E93TGRxYtNCcH,ZZQzs8ITl6imhJCot)
		drzqWFkSHD.menuItemsLIST[:] = sorted(drzqWFkSHD.menuItemsLIST,reverse=False,key=lambda xngTvzlop02PjM7ZdA: xngTvzlop02PjM7ZdA[1].lower())
	return
def b198LikC6enZRjEgXHvdpNQ(wweqETA3WHOSBniZN,AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,ZZQzs8ITl6imhJCot=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not ZZQzs8ITl6imhJCot: ZZQzs8ITl6imhJCot = '1'
	a9YrjQPdZ8JicSD2LbG,wVtSpAsUu0cMblPqxK1F,FBOMf1xKQphwczTvLNCjEkAnIa = EAgxpW09CSdZBy82KtTG4(wweqETA3WHOSBniZN)
	if not AcfzInE42p3Qh: return
	if not rb1LQeqnckC(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa): return
	if not a9YrjQPdZ8JicSD2LbG:
		a9YrjQPdZ8JicSD2LbG = TwDBf3QbKOnrmd5u9()
		if not a9YrjQPdZ8JicSD2LbG: return
	nTbx5t3HpS = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not II4hU2E93TGRxYtNCcH:
		if not FBOMf1xKQphwczTvLNCjEkAnIa:
			if   '_M3U-LIVE_' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[1]
			elif '_M3U-MOVIES' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[2]
			elif '_M3U-SERIES' in wVtSpAsUu0cMblPqxK1F: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[3]
			else: II4hU2E93TGRxYtNCcH = nTbx5t3HpS[0]
		else:
			Xa5yE8WPphu7cZidl1YUmvA3e42 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			jwgM2qYVpdK5ly = YLUMzC9m0dc('أختر البحث المناسب', Xa5yE8WPphu7cZidl1YUmvA3e42)
			if jwgM2qYVpdK5ly==-1: return
			II4hU2E93TGRxYtNCcH = nTbx5t3HpS[jwgM2qYVpdK5ly]
	MdEaoJOf1uQcqGT9z3PFI = a9YrjQPdZ8JicSD2LbG.lower()
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,'SEARCH')
	lwfKMcpWgebLrA5sSa68 = dYMLGvgfk4(FCoNx1Hbcjipz,'list','SEARCH',(II4hU2E93TGRxYtNCcH,MdEaoJOf1uQcqGT9z3PFI))
	if not lwfKMcpWgebLrA5sSa68:
		GuOW8CBdshMwKHXZAQbz,avmF8OftnK9Lgiqk0HWzBZN = [],[]
		if not II4hU2E93TGRxYtNCcH: S1RqJV9UsGn0aAQ7YNc = [1,2,3,4,5]
		else: S1RqJV9UsGn0aAQ7YNc = [nTbx5t3HpS.index(II4hU2E93TGRxYtNCcH)]
		for WWlVCHMzIF7qwQGvma6yd in S1RqJV9UsGn0aAQ7YNc:
			if WWlVCHMzIF7qwQGvma6yd!=3:
				snrNiTEh6zqZkUtlO = dYMLGvgfk4(FCoNx1Hbcjipz,'dict',nTbx5t3HpS[WWlVCHMzIF7qwQGvma6yd])
				del snrNiTEh6zqZkUtlO['__COUNT__']
				del snrNiTEh6zqZkUtlO['__GROUPS__']
				del snrNiTEh6zqZkUtlO['__SEQUENCED_COLUMNS__']
				vZlukQzIfxCsKH4GW18XmNyq = list(snrNiTEh6zqZkUtlO.keys())
				for NgZsLrE9mYIe0R51V7PGHUcM4J in vZlukQzIfxCsKH4GW18XmNyq:
					for WPHK5192hQ8lmL34OukgqMUS0CVF,oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN in snrNiTEh6zqZkUtlO[NgZsLrE9mYIe0R51V7PGHUcM4J]:
						if MdEaoJOf1uQcqGT9z3PFI in oj5EvxCrn2m.lower(): avmF8OftnK9Lgiqk0HWzBZN.append((oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN))
					del snrNiTEh6zqZkUtlO[NgZsLrE9mYIe0R51V7PGHUcM4J]
				del snrNiTEh6zqZkUtlO
			else: vZlukQzIfxCsKH4GW18XmNyq = dYMLGvgfk4(FCoNx1Hbcjipz,'list',nTbx5t3HpS[WWlVCHMzIF7qwQGvma6yd],'__GROUPS__')
			for NgZsLrE9mYIe0R51V7PGHUcM4J in vZlukQzIfxCsKH4GW18XmNyq:
				try: NgZsLrE9mYIe0R51V7PGHUcM4J,QacvmqO47zo1MySl3BEN = NgZsLrE9mYIe0R51V7PGHUcM4J
				except: QacvmqO47zo1MySl3BEN = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
				if MdEaoJOf1uQcqGT9z3PFI in NgZsLrE9mYIe0R51V7PGHUcM4J.lower():
					if WWlVCHMzIF7qwQGvma6yd!=3: qu4U6YDWeponadlXzvsAfG9 = NgZsLrE9mYIe0R51V7PGHUcM4J
					else:
						GCh6FDfNpx,Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO = NgZsLrE9mYIe0R51V7PGHUcM4J.split('__SERIES__')
						if MdEaoJOf1uQcqGT9z3PFI in GCh6FDfNpx.lower(): qu4U6YDWeponadlXzvsAfG9 = GCh6FDfNpx
						else: qu4U6YDWeponadlXzvsAfG9 = Pyp8JkcWFE9SQX6ADT3GB4HbLvKRO
					GuOW8CBdshMwKHXZAQbz.append((NgZsLrE9mYIe0R51V7PGHUcM4J,qu4U6YDWeponadlXzvsAfG9,nTbx5t3HpS[WWlVCHMzIF7qwQGvma6yd],QacvmqO47zo1MySl3BEN))
			del vZlukQzIfxCsKH4GW18XmNyq
		GuOW8CBdshMwKHXZAQbz = set(GuOW8CBdshMwKHXZAQbz)
		avmF8OftnK9Lgiqk0HWzBZN = set(avmF8OftnK9Lgiqk0HWzBZN)
		GuOW8CBdshMwKHXZAQbz = sorted(GuOW8CBdshMwKHXZAQbz,reverse=False,key=lambda xngTvzlop02PjM7ZdA: xngTvzlop02PjM7ZdA[1])
		avmF8OftnK9Lgiqk0HWzBZN = sorted(avmF8OftnK9Lgiqk0HWzBZN,reverse=False,key=lambda xngTvzlop02PjM7ZdA: xngTvzlop02PjM7ZdA[0])
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,'SEARCH',(II4hU2E93TGRxYtNCcH,MdEaoJOf1uQcqGT9z3PFI),(GuOW8CBdshMwKHXZAQbz,avmF8OftnK9Lgiqk0HWzBZN),iigI6zE7djY3yQasNTM5AW0PLOS4)
	else: GuOW8CBdshMwKHXZAQbz,avmF8OftnK9Lgiqk0HWzBZN = lwfKMcpWgebLrA5sSa68
	vZlukQzIfxCsKH4GW18XmNyq = len(GuOW8CBdshMwKHXZAQbz)
	c5cjEd3Q7vGMPylXIJA1D0w8oq = len(avmF8OftnK9Lgiqk0HWzBZN)
	YYXUAmT7uG6yFiRtDehn85qkpLcZj = int(ZZQzs8ITl6imhJCot)
	LdXRQbwyUKJHkf8g = max(0,(YYXUAmT7uG6yFiRtDehn85qkpLcZj-1)*100)
	iYQMjCUuBydq3E0RbteN = max(0,YYXUAmT7uG6yFiRtDehn85qkpLcZj*100)
	aadzjH2uTi4n0OmPQ5UDRLYeovw7q = max(0,LdXRQbwyUKJHkf8g-vZlukQzIfxCsKH4GW18XmNyq)
	IPUvC7oJ8k1GD = max(0,iYQMjCUuBydq3E0RbteN-vZlukQzIfxCsKH4GW18XmNyq)
	for NgZsLrE9mYIe0R51V7PGHUcM4J,qu4U6YDWeponadlXzvsAfG9,WJUA9lPvGoyFHxdzO6cqbpLu,QacvmqO47zo1MySl3BEN in GuOW8CBdshMwKHXZAQbz[LdXRQbwyUKJHkf8g:iYQMjCUuBydq3E0RbteN]:
		w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+qu4U6YDWeponadlXzvsAfG9,WJUA9lPvGoyFHxdzO6cqbpLu,714,QacvmqO47zo1MySl3BEN,'1',NgZsLrE9mYIe0R51V7PGHUcM4J,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	del GuOW8CBdshMwKHXZAQbz
	for oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,QacvmqO47zo1MySl3BEN in avmF8OftnK9Lgiqk0HWzBZN[aadzjH2uTi4n0OmPQ5UDRLYeovw7q:IPUvC7oJ8k1GD]:
		qS9zORZfbm0TNCMaUvLu = azP0kLi9Uc6(s3chK0CpdkqFzAr6UvZloXHTwMxQmf)
		ZJksHpSUNh2f = 'live'
		if '.mkv' in qS9zORZfbm0TNCMaUvLu or 'VOD' in II4hU2E93TGRxYtNCcH: ZJksHpSUNh2f = 'video'
		w3BfOGLdXcWzbiC1PYx9mE(ZJksHpSUNh2f,otY7B2WlSRvy3rECV+oj5EvxCrn2m,s3chK0CpdkqFzAr6UvZloXHTwMxQmf,715,QacvmqO47zo1MySl3BEN,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	del avmF8OftnK9Lgiqk0HWzBZN
	lVL9WmPpg3nzufxACOB2wGESY(AcfzInE42p3Qh,ZZQzs8ITl6imhJCot,II4hU2E93TGRxYtNCcH,719,vZlukQzIfxCsKH4GW18XmNyq+c5cjEd3Q7vGMPylXIJA1D0w8oq,a9YrjQPdZ8JicSD2LbG+'_NODIALOGS_')
	return
def lVL9WmPpg3nzufxACOB2wGESY(AcfzInE42p3Qh,ZZQzs8ITl6imhJCot,II4hU2E93TGRxYtNCcH,t5fhagjUGXk0ynOlJWeAb,X8XfkuPCiaIJptHFT1,ggM5TzCxq24sDYLiEatpdSK7FQyGe):
	if not ZZQzs8ITl6imhJCot: ZZQzs8ITl6imhJCot = '1'
	if ZZQzs8ITl6imhJCot!='1': w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'صفحة '+str(1),II4hU2E93TGRxYtNCcH,t5fhagjUGXk0ynOlJWeAb,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(1),ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	if not X8XfkuPCiaIJptHFT1: X8XfkuPCiaIJptHFT1 = 0
	D1YSANrciIG8kOK = int(X8XfkuPCiaIJptHFT1/100)+1
	for YYXUAmT7uG6yFiRtDehn85qkpLcZj in range(2,D1YSANrciIG8kOK):
		GPtd1XQavKmL29jZqA5H = (YYXUAmT7uG6yFiRtDehn85qkpLcZj%10==0 or int(ZZQzs8ITl6imhJCot)-4<YYXUAmT7uG6yFiRtDehn85qkpLcZj<int(ZZQzs8ITl6imhJCot)+4)
		rz4J8St6Iulb = (GPtd1XQavKmL29jZqA5H and int(ZZQzs8ITl6imhJCot)-40<YYXUAmT7uG6yFiRtDehn85qkpLcZj<int(ZZQzs8ITl6imhJCot)+40)
		if str(YYXUAmT7uG6yFiRtDehn85qkpLcZj)!=ZZQzs8ITl6imhJCot and (YYXUAmT7uG6yFiRtDehn85qkpLcZj%100==0 or rz4J8St6Iulb):
			w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'صفحة '+str(YYXUAmT7uG6yFiRtDehn85qkpLcZj),II4hU2E93TGRxYtNCcH,t5fhagjUGXk0ynOlJWeAb,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(YYXUAmT7uG6yFiRtDehn85qkpLcZj),ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	if str(D1YSANrciIG8kOK)!=ZZQzs8ITl6imhJCot: w3BfOGLdXcWzbiC1PYx9mE('folder',otY7B2WlSRvy3rECV+'أخر صفحة '+str(D1YSANrciIG8kOK),II4hU2E93TGRxYtNCcH,t5fhagjUGXk0ynOlJWeAb,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,str(D1YSANrciIG8kOK),ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,{'folder':AcfzInE42p3Qh})
	return
def wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,II4hU2E93TGRxYtNCcH):
	FCoNx1Hbcjipz = P2FyHpBjWi6Jh5xUEDkCnf9.replace('___','_'+AcfzInE42p3Qh)
	return FCoNx1Hbcjipz
def zL7ZXKbV6nrfuGkhRTwl8x(AcfzInE42p3Qh):
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if vvbjZeMTcKP4dXDQLf90B3mgwYV7!=1: return False
	ee5TZxvnCka79VQINUfl26jsWB8(AcfzInE42p3Qh,False)
	TSYebjHF7g = [0]
	for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
		b1cm7wYq4R5UEjspZiG2rzuKTg6 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.url_'+AcfzInE42p3Qh+'_'+str(BO1DGbpgSfCz))
		if b1cm7wYq4R5UEjspZiG2rzuKTg6: uy9bk2eYB8L1AJ(AcfzInE42p3Qh,str(BO1DGbpgSfCz))
		TSYebjHF7g.append(0)
	for II4hU2E93TGRxYtNCcH in ll1VzW039ATNi27uYHfU4xchpEyk:
		h1BIvOFpqj,LjReHd7S4GfiV,JN1WdDeX6Gb8EavM3FzpI,o5ovdx3igHpDZEX2YwWBJ1mKc,SS3C6elVYnW7oiTqb15Pzmf = 0,{},[],[],[]
		for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
			WJUA9lPvGoyFHxdzO6cqbpLu = II4hU2E93TGRxYtNCcH+'_'+str(BO1DGbpgSfCz)
			TNQqlro2bMgSI4s0dw9UWVtvkD = dYMLGvgfk4(FCoNx1Hbcjipz,'dict',WJUA9lPvGoyFHxdzO6cqbpLu)
			try:
				A0ej6NKYix5oFmIdr = TNQqlro2bMgSI4s0dw9UWVtvkD['__GROUPS__']
				Y5YTsXIKBLG0yv1WRupn3o7ia = TNQqlro2bMgSI4s0dw9UWVtvkD['__COUNT__']
			except: A0ej6NKYix5oFmIdr,Y5YTsXIKBLG0yv1WRupn3o7ia = [],'0'
			for bbjm9sTKghtJUDvZHpXAc6qzWSnNiw in A0ej6NKYix5oFmIdr:
				NgZsLrE9mYIe0R51V7PGHUcM4J,NNxWvh3OimPqguS = bbjm9sTKghtJUDvZHpXAc6qzWSnNiw
				snrNiTEh6zqZkUtlO = TNQqlro2bMgSI4s0dw9UWVtvkD[NgZsLrE9mYIe0R51V7PGHUcM4J]
				if NgZsLrE9mYIe0R51V7PGHUcM4J not in o5ovdx3igHpDZEX2YwWBJ1mKc:
					o5ovdx3igHpDZEX2YwWBJ1mKc.append(NgZsLrE9mYIe0R51V7PGHUcM4J)
					SS3C6elVYnW7oiTqb15Pzmf.append(bbjm9sTKghtJUDvZHpXAc6qzWSnNiw)
					LjReHd7S4GfiV[NgZsLrE9mYIe0R51V7PGHUcM4J] = []
				LjReHd7S4GfiV[NgZsLrE9mYIe0R51V7PGHUcM4J] += snrNiTEh6zqZkUtlO
			rBLaP6i4jvs70wleySTcWq(FCoNx1Hbcjipz,WJUA9lPvGoyFHxdzO6cqbpLu)
			JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,WJUA9lPvGoyFHxdzO6cqbpLu,'__COUNT__',Y5YTsXIKBLG0yv1WRupn3o7ia,iigI6zE7djY3yQasNTM5AW0PLOS4)
			TSYebjHF7g[BO1DGbpgSfCz] += int(Y5YTsXIKBLG0yv1WRupn3o7ia)
		for NgZsLrE9mYIe0R51V7PGHUcM4J in o5ovdx3igHpDZEX2YwWBJ1mKc:
			snrNiTEh6zqZkUtlO = list(set(LjReHd7S4GfiV[NgZsLrE9mYIe0R51V7PGHUcM4J]))
			if 'SORTED' in II4hU2E93TGRxYtNCcH: snrNiTEh6zqZkUtlO = sorted(snrNiTEh6zqZkUtlO,reverse=False,key=lambda key: key[1].lower())
			h1BIvOFpqj += len(snrNiTEh6zqZkUtlO)
			JN1WdDeX6Gb8EavM3FzpI.append(snrNiTEh6zqZkUtlO)
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,II4hU2E93TGRxYtNCcH,'__COUNT__',str(h1BIvOFpqj),iigI6zE7djY3yQasNTM5AW0PLOS4)
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,II4hU2E93TGRxYtNCcH,'__GROUPS__',SS3C6elVYnW7oiTqb15Pzmf,iigI6zE7djY3yQasNTM5AW0PLOS4)
		JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,II4hU2E93TGRxYtNCcH,o5ovdx3igHpDZEX2YwWBJ1mKc,JN1WdDeX6Gb8EavM3FzpI,iigI6zE7djY3yQasNTM5AW0PLOS4,True)
	qqLZ5UABCbzpt = False
	for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
		if int(TSYebjHF7g[BO1DGbpgSfCz])>0:
			b1cm7wYq4R5UEjspZiG2rzuKTg6 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.m3u.url_'+AcfzInE42p3Qh+'_'+str(BO1DGbpgSfCz))
			JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,'LINK_'+str(BO1DGbpgSfCz),'__LINK__',b1cm7wYq4R5UEjspZiG2rzuKTg6,iigI6zE7djY3yQasNTM5AW0PLOS4)
			qqLZ5UABCbzpt = True
	JZvkPS1QBs436RujaCnh9b5x2(FCoNx1Hbcjipz,'DUMMY','__DUMMY__','DUMMY',iigI6zE7djY3yQasNTM5AW0PLOS4)
	if not qqLZ5UABCbzpt:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم جلب ملفات M3U جديدة')
	hc2DFeYx6yvb5R(AcfzInE42p3Qh)
	ReBiOy1dYvpLJFI8G(False)
	GGfDYrMCxAh59v4bSaXpnO1qHkIK(False)
	return True
def hc2DFeYx6yvb5R(AcfzInE42p3Qh):
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	if not rb1LQeqnckC(AcfzInE42p3Qh,True): return
	for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
		b1cm7wYq4R5UEjspZiG2rzuKTg6 = dYMLGvgfk4(FCoNx1Hbcjipz,'str','LINK_'+str(BO1DGbpgSfCz),'__LINK__')
		if b1cm7wYq4R5UEjspZiG2rzuKTg6: pTvHSF3uoXeVyc = e9YbvcGiMdH4DZuo2lX0CpgK73(AcfzInE42p3Qh,str(BO1DGbpgSfCz))
	e9YbvcGiMdH4DZuo2lX0CpgK73(AcfzInE42p3Qh,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	return
def ee5TZxvnCka79VQINUfl26jsWB8(AcfzInE42p3Qh,FBOMf1xKQphwczTvLNCjEkAnIa):
	if FBOMf1xKQphwczTvLNCjEkAnIa:
		vvbjZeMTcKP4dXDQLf90B3mgwYV7 = hhTcd5XlykBUu68zAb9OmgC('center',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if vvbjZeMTcKP4dXDQLf90B3mgwYV7!=1: return
	FCoNx1Hbcjipz = wEPDM5JcLtn0zK4Nikvs7SU(AcfzInE42p3Qh,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	try: oNlez5gnM9x2B4.remove(FCoNx1Hbcjipz)
	except: pass
	for BO1DGbpgSfCz in range(1,rVWJO0Zo4smv2y+1):
		jIqXUsh9yNOYaf32R = uuipOUPQcSGmbIAlyWjr7RHtkD09.replace('___','_'+AcfzInE42p3Qh+'_'+str(BO1DGbpgSfCz))
		mmWoubA8KSCqp1YOVta03MUlnB = oNlez5gnM9x2B4.path.join(eC21aUbHsMhBQnfVypk8T,jIqXUsh9yNOYaf32R)
		try: oNlez5gnM9x2B4.remove(mmWoubA8KSCqp1YOVta03MUlnB)
		except: pass
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'SECTIONS_M3U','SECTIONS_M3U_'+AcfzInE42p3Qh)
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if FBOMf1xKQphwczTvLNCjEkAnIa:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'تم مسح جميع ملفات ـM3U')
		GGfDYrMCxAh59v4bSaXpnO1qHkIK(False)
	return
def KK5BTFDjA6RPp(AcfzInE42p3Qh):
	mY0Zz97nvTx = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.language.provider')
	zkZlYXMbWT7sSmhV2qP8 = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.language.code')
	rBLaP6i4jvs70wleySTcWq(mmEuUR4JdaHtAsS,'MENUS_CACHE_'+mY0Zz97nvTx+'_'+zkZlYXMbWT7sSmhV2qP8,'%_MU'+AcfzInE42p3Qh+'_%')
	return
GKjZ6lbUQTvkf47Rux = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}