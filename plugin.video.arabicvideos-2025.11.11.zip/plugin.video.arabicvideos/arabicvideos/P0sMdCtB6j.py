# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'SHOOFMAX'
qBAgzkG9oCL = '_SHM_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
talv2Us5Kn1 = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][1]
BZ1UIeSfWMxb6X = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][2]
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==50: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==51: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif mode==52: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==53: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==55: Ubud2NhHKRnMTvI5mprQBVqk80 = I8Gk5cPYOKCuJtHTEQl3()
	elif mode==56: Ubud2NhHKRnMTvI5mprQBVqk80 = b8vl2GAJ7XHYSZCEqUL()
	elif mode==57: Ubud2NhHKRnMTvI5mprQBVqk80 = OUhFr9412Q0jHRn8coLg(url,1)
	elif mode==58: Ubud2NhHKRnMTvI5mprQBVqk80 = OUhFr9412Q0jHRn8coLg(url,2)
	elif mode==59: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,59,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المسلسلات',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,56)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'الافلام',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,55)
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
def I8Gk5cPYOKCuJtHTEQl3():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أفلام مرتبة بسنة الإنتاج',S7EgasGcYdIo+'/movie/1/yop',57)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أفلام مرتبة بالأفضل تقييم',S7EgasGcYdIo+'/movie/1/review',57)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أفلام مرتبة بالأكثر مشاهدة',S7EgasGcYdIo+'/movie/1/views',57)
	return
def b8vl2GAJ7XHYSZCEqUL():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات مرتبة بسنة الإنتاج',S7EgasGcYdIo+'/series/1/yop',57)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات مرتبة بالأفضل تقييم',S7EgasGcYdIo+'/series/1/review',57)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسلات مرتبة بالأكثر مشاهدة',S7EgasGcYdIo+'/series/1/views',57)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url):
	if '?' in url:
		PCnrX0p2QmTt5ijBIkqu4La = url.split('?')
		url = PCnrX0p2QmTt5ijBIkqu4La[0]
		filter = '?' + pmhHwIbkcrRJeyzuxPUSDGnqM92(PCnrX0p2QmTt5ijBIkqu4La[1],'=&:/%')
	else: filter = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	type,GpwRnQ6q2o1fv0HbJTs,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': k32OnDpq9SwGQhVM6='فيلم'
		elif type=='series': k32OnDpq9SwGQhVM6='مسلسل'
		url = S7EgasGcYdIo + '/genre/filter/' + pmhHwIbkcrRJeyzuxPUSDGnqM92(k32OnDpq9SwGQhVM6) + '/' + GpwRnQ6q2o1fv0HbJTs + '/' + sort + filter
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-TITLES-1st')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		MeLFo0S9mPOJjCqIX8ln=0
		for id,title,nLxAQHlpEh3,RRx0ri8bETI in items:
			MeLFo0S9mPOJjCqIX8ln += 1
			RRx0ri8bETI = BZ1UIeSfWMxb6X + '/v2/img/program/main/' + RRx0ri8bETI + '-2.jpg'
			cX2SpPxGLmADTKl = S7EgasGcYdIo + '/program/' + id
			if type=='movie': w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,53,RRx0ri8bETI)
			if type=='series': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسل '+title,cX2SpPxGLmADTKl+'?ep='+nLxAQHlpEh3+'='+title+'='+RRx0ri8bETI,52,RRx0ri8bETI)
	else:
		if type=='movie': k32OnDpq9SwGQhVM6='movies'
		elif type=='series': k32OnDpq9SwGQhVM6='series'
		url = talv2Us5Kn1 + '/json/selected/' + sort + '-' + k32OnDpq9SwGQhVM6 + '-WW.json'
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-TITLES-2nd')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		MeLFo0S9mPOJjCqIX8ln=0
		for id,nLxAQHlpEh3,RRx0ri8bETI,title in items:
			MeLFo0S9mPOJjCqIX8ln += 1
			RRx0ri8bETI = talv2Us5Kn1 + '/img/program/' + RRx0ri8bETI + '-2.jpg'
			cX2SpPxGLmADTKl = S7EgasGcYdIo + '/program/' + id
			if type=='movie': w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,53,RRx0ri8bETI)
			elif type=='series': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مسلسل '+title,cX2SpPxGLmADTKl+'?ep='+nLxAQHlpEh3+'='+title+'='+RRx0ri8bETI,52,RRx0ri8bETI)
	title='صفحة '
	if MeLFo0S9mPOJjCqIX8ln==16:
		for qBe2WSEkNtcz8ZbyYHwhR5KAm9f in range(1,13) :
			if not GpwRnQ6q2o1fv0HbJTs==str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f):
				url = S7EgasGcYdIo+'/genre/filter/'+type+'/'+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f)+'/'+sort+filter
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title+str(qBe2WSEkNtcz8ZbyYHwhR5KAm9f),url,51)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	PCnrX0p2QmTt5ijBIkqu4La = url.split('=')
	nLxAQHlpEh3 = int(PCnrX0p2QmTt5ijBIkqu4La[1])
	name = WDg18QHF3rze(PCnrX0p2QmTt5ijBIkqu4La[2])
	name = name.replace('_MOD_مسلسل ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	RRx0ri8bETI = PCnrX0p2QmTt5ijBIkqu4La[3]
	url = url.split('?')[0]
	if nLxAQHlpEh3==0:
		R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-EPISODES-1st')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<select(.*?)</select>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('option value="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		nLxAQHlpEh3 = int(items[-1])
	for azhwpE0qmevcFobdRi in range(nLxAQHlpEh3,0,-1):
		cX2SpPxGLmADTKl = url + '?ep=' + str(azhwpE0qmevcFobdRi)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(azhwpE0qmevcFobdRi)
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,53,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-PLAY-1st')
	qSTf8pXcxtWdz5iReYEHF = AxTYMhRlfyskNc0X19dvwtS.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if qSTf8pXcxtWdz5iReYEHF:
		f7epsRlYtMz4 = qSTf8pXcxtWdz5iReYEHF[1].replace('T',NNJKRTY8GlM29ezbCgPiXd)
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+b8sk5WyPoz03pXhRx+f7epsRlYtMz4)
		return
	zOByVoE6WaRxTl38gF1YqbpLHGvtm,c3zCbmqTPIhgSONpL = [],[]
	UUf3pV87RFmEKOc9b = AxTYMhRlfyskNc0X19dvwtS.findall('var origin_link = "(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	Rx32d1lN9y0iPHbQWw = AxTYMhRlfyskNc0X19dvwtS.findall('var backup_origin_link = "(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('hls: (.*?)_link\+"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for LLzkoiPsbBZ,cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
		if 'backup' in LLzkoiPsbBZ:
			LLzkoiPsbBZ = 'backup server'
			url = Rx32d1lN9y0iPHbQWw + cX2SpPxGLmADTKl
		else:
			LLzkoiPsbBZ = 'main server'
			url = UUf3pV87RFmEKOc9b + cX2SpPxGLmADTKl
		if '.m3u8' in url:
			zOByVoE6WaRxTl38gF1YqbpLHGvtm.append(url)
			c3zCbmqTPIhgSONpL.append('m3u8  '+LLzkoiPsbBZ)
	BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	BA01W9olieErLycV7kwFvOhH5Y3ms += AxTYMhRlfyskNc0X19dvwtS.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for LLzkoiPsbBZ,cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
		filename = cX2SpPxGLmADTKl.split('/')[-1]
		filename = filename.replace('fallback',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		filename = filename.replace('.mp4',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		filename = filename.replace('-',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		if 'backup' in LLzkoiPsbBZ:
			LLzkoiPsbBZ = 'backup server'
			url = Rx32d1lN9y0iPHbQWw + cX2SpPxGLmADTKl
		else:
			LLzkoiPsbBZ = 'main server'
			url = UUf3pV87RFmEKOc9b + cX2SpPxGLmADTKl
		zOByVoE6WaRxTl38gF1YqbpLHGvtm.append(url)
		c3zCbmqTPIhgSONpL.append('mp4  '+LLzkoiPsbBZ+zHYL9u48eyJot+filename)
	qNmsBD1jJZVzcxi4onKuAOIC = YLUMzC9m0dc('Select Video Quality:', c3zCbmqTPIhgSONpL)
	if qNmsBD1jJZVzcxi4onKuAOIC == -1 : return
	url = zOByVoE6WaRxTl38gF1YqbpLHGvtm[qNmsBD1jJZVzcxi4onKuAOIC]
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(url,mI6ayKxBvjd4CRthL,'video')
	return
def OUhFr9412Q0jHRn8coLg(url,type):
	if 'series' in url: nUDgc4absePT2xMt = S7EgasGcYdIo + '/genre/مسلسل'
	else: nUDgc4absePT2xMt = S7EgasGcYdIo + '/genre/فيلم'
	nUDgc4absePT2xMt = pmhHwIbkcrRJeyzuxPUSDGnqM92(nUDgc4absePT2xMt)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-FILTERS-1st')
	if type==1: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('subgenre(.*?)div',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	elif type==2: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('country(.*?)div',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('option value="(.*?)">(.*?)</option',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if type==1:
		for SuExTw5QDh,title in items:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url+'?subgenre='+SuExTw5QDh,58)
	elif type==2:
		url,SuExTw5QDh = url.split('?')
		for SShkAgdY82JXFDbsB4yz9,title in items:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url+'?country='+SShkAgdY82JXFDbsB4yz9+'&'+SuExTw5QDh,51)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search: search = TwDBf3QbKOnrmd5u9()
	if not search: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	url = S7EgasGcYdIo+'/search?q='+ej9gRJkD6KGTcf
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,True,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'SHOOFMAX-SEARCH-2nd')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('general-body(.*?)search-bottom-padding',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if items:
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
			url = S7EgasGcYdIo + cX2SpPxGLmADTKl
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+pmhHwIbkcrRJeyzuxPUSDGnqM92(title)+'='+RRx0ri8bETI
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,52,RRx0ri8bETI)
				else:
					title = '_MOD_فيلم '+title
					w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,url,53,RRx0ri8bETI)
	return