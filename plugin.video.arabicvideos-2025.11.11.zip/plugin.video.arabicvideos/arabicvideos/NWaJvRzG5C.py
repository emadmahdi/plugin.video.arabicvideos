# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'CIMANOW'
qBAgzkG9oCL = '_CMN_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['قائمتي']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==300: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==301: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==302: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url)
	elif mode==303: Ubud2NhHKRnMTvI5mprQBVqk80 = tvK8EfHFqA(url)
	elif mode==304: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==305: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==306: Ubud2NhHKRnMTvI5mprQBVqk80 = xUjIFbZmYk2oWsVt()
	elif mode==309: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,309,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo+'/home',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<header(.*?)</header>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<li><a href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if not any(value in title for value in kCIESuy4j5mVLZYtG9vDNnb7):
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,301)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	I1C6JqXo3j9Ruyz(S7EgasGcYdIo+'/home',R8AE9e4mYxVhusL3Q)
	return R8AE9e4mYxVhusL3Q
def xUjIFbZmYk2oWsVt():
	w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def I1C6JqXo3j9Ruyz(url,R8AE9e4mYxVhusL3Q=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if not R8AE9e4mYxVhusL3Q:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-SUBMENU-1st')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	u74UPEicpBdq32C = 0
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<section>.*?</section>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
		u74UPEicpBdq32C += 1
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for title,HIoktZsN7fwvb0yUL5SB,cX2SpPxGLmADTKl in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: title = 'بووووو'
			if 'em><a' not in HIoktZsN7fwvb0yUL5SB:
				if IxdmfnvhCA8Bc9ZlQ45oiqN.count('/category/')>0:
					ZcdILQijMvDG5Pz2fhAmwtr170CT4 = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
					for cX2SpPxGLmADTKl in ZcdILQijMvDG5Pz2fhAmwtr170CT4:
						title = cX2SpPxGLmADTKl.split('/')[-2]
						w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,301)
					continue
				else: cX2SpPxGLmADTKl = url+'?sequence='+str(u74UPEicpBdq32C)
			if not any(value in title for value in kCIESuy4j5mVLZYtG9vDNnb7):
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,302)
	if not vvuraxgW7YLIZ4hU0MbCt: ENDRjPGicXYFvpVs3xk5uSg6y(url,R8AE9e4mYxVhusL3Q)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,R8AE9e4mYxVhusL3Q=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if R8AE9e4mYxVhusL3Q==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-TITLES-1st')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if '?sequence=' in url:
		url,u74UPEicpBdq32C = url.split('?sequence=')
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('(<section>.*?</section>)',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[int(u74UPEicpBdq32C)-1]
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"posts"(.*?)</body>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	for cX2SpPxGLmADTKl,data,RRx0ri8bETI in items:
		title = AxTYMhRlfyskNc0X19dvwtS.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if title: title = title[0][2].replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if not title or title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
			title = AxTYMhRlfyskNc0X19dvwtS.findall('title">.*?</em>(.*?)<',data,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if title: title = title[0].replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if not title or title==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O:
				title = AxTYMhRlfyskNc0X19dvwtS.findall('title">(.*?)<',data,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				title = title[0].replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		title = riUKNnOEtVwdj4(title)
		title = title.replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if title not in EaUe8ArOCD:
			EaUe8ArOCD.append(title)
			Lhi71X39bHs6zEZ4ypIaGewVJ = cX2SpPxGLmADTKl+data+RRx0ri8bETI
			if '/selary/' in Lhi71X39bHs6zEZ4ypIaGewVJ or 'مسلسل' in Lhi71X39bHs6zEZ4ypIaGewVJ or '"episode"' in Lhi71X39bHs6zEZ4ypIaGewVJ:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,303,RRx0ri8bETI)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,305,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"pagination"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<li><a href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,302)
	return
def tvK8EfHFqA(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-SEASONS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	name = AxTYMhRlfyskNc0X19dvwtS.findall('<title>(.*?)</title>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('Cima Now',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP).replace(zHYL9u48eyJot,WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		name = name.split('الحلقة')[0].strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)+' - '
	else: name = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('<section(.*?)</section>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if len(items)>1:
			for cX2SpPxGLmADTKl,title in items:
				title = name+title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,304)
		elif len(items)==1:
			cX2SpPxGLmADTKl,title = items[0]
			SnpFbUovmMwfXalIGRNys6zYZtj(cX2SpPxGLmADTKl)
		else: SnpFbUovmMwfXalIGRNys6zYZtj(url)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if '/selary/' not in url:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"episodes"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			title = 'الحلقة '+title
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,305)
	else:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"details"(.*?)"related"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[nUaVQsoA6EXcK4Odht5wCge0J8Pib]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
			title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,305,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	KUL2ueRt5cfBG8N = AxTYMhRlfyskNc0X19dvwtS.findall('class="shine" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if KUL2ueRt5cfBG8N:
		LLzkoiPsbBZ = UUmYkruGeM3p8sKi6o2fcI(KUL2ueRt5cfBG8N[0],'url')
		headers = {'Referer':LLzkoiPsbBZ}
	else: headers = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	nUDgc4absePT2xMt = url+'watching/'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'CIMANOW-PLAY-5th')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"download"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</i>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			XcvFdKRjNLz5wEpDf = AxTYMhRlfyskNc0X19dvwtS.findall('\d\d\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if XcvFdKRjNLz5wEpDf:
				XcvFdKRjNLz5wEpDf = '____'+XcvFdKRjNLz5wEpDf[0]
				title = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
			else: XcvFdKRjNLz5wEpDf = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
			evGVuBpQUEL = cX2SpPxGLmADTKl+'?named='+title+'__download'+XcvFdKRjNLz5wEpDf
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(evGVuBpQUEL)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"watch"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall('"embed".*?src="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
			title = UUmYkruGeM3p8sKi6o2fcI(cX2SpPxGLmADTKl,'name')
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__embed'
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
		BA01W9olieErLycV7kwFvOhH5Y3ms = [S7EgasGcYdIo+'/wp-content/themes/Cima%20Now%20New/core.php']
		if BA01W9olieErLycV7kwFvOhH5Y3ms:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for qHmcPitXMaCJTswd7zj8W3Ux4u9l,id,title in items:
				title = title.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				cX2SpPxGLmADTKl = BA01W9olieErLycV7kwFvOhH5Y3ms[0]+'?action=switch&index='+qHmcPitXMaCJTswd7zj8W3Ux4u9l+'&id='+id+'?named='+title+'__watch'
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo + '/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return