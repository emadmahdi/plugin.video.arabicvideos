# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'YOUTUBE'
qBAgzkG9oCL = '_YUT_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
CRx2in8dm7yEhwD0 = 0
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text,type,GpwRnQ6q2o1fv0HbJTs,name,E7MF9aYlV4Q0):
	if	 mode==140: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==141: Ubud2NhHKRnMTvI5mprQBVqk80 = b3JHzUDKQtOqEMsoLfIr5X6ymgh(url,name,E7MF9aYlV4Q0)
	elif mode==143: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url,type)
	elif mode==144: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,GpwRnQ6q2o1fv0HbJTs,text)
	elif mode==145: Ubud2NhHKRnMTvI5mprQBVqk80 = LXNCVcTRAasE8t(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==147: Ubud2NhHKRnMTvI5mprQBVqk80 = ZZp1TCylreK9VBqmP7UWGt0XFNAL()
	elif mode==148: Ubud2NhHKRnMTvI5mprQBVqk80 = ELZHFyBWY70AMtCT8dxoDrk3()
	elif mode==149: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	if 0:
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'قائمة 1',S7EgasGcYdIo+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'قائمة 2',S7EgasGcYdIo+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'شخص',S7EgasGcYdIo+'/user/TCNofficial',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'موقع',S7EgasGcYdIo+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'حساب',S7EgasGcYdIo+'/@TheSocialCTV',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'العاب',S7EgasGcYdIo+'/gaming',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'افلام',S7EgasGcYdIo+'/feed/storefront',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مختارات',S7EgasGcYdIo+'/feed/guide_builder',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'قصيرة',S7EgasGcYdIo+'/shorts',144,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'تصفح',S7EgasGcYdIo+'/youtubei/v1/guide?key=',144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'رئيسية',S7EgasGcYdIo+VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,144)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'رائج',S7EgasGcYdIo+'/feed/trending?bp=',144)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,149,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الرائجة',S7EgasGcYdIo+'/feed/trending',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'التصفح',S7EgasGcYdIo+'/youtubei/v1/guide?key=',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'القصيرة',S7EgasGcYdIo+'/shorts',144,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مختارات يوتيوب',S7EgasGcYdIo+'/feed/guide_builder',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مختارات البرنامج',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,290)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: قنوات عربية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,147)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: قنوات أجنبية',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,148)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: افلام عربية',S7EgasGcYdIo+'/results?search_query=فيلم',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: افلام اجنبية',S7EgasGcYdIo+'/results?search_query=movie',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: مسرحيات عربية',S7EgasGcYdIo+'/results?search_query=مسرحية',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: مسلسلات عربية',S7EgasGcYdIo+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: مسلسلات اجنبية',S7EgasGcYdIo+'/results?search_query=series&sp=EgIQAw==',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: مسلسلات كارتون',S7EgasGcYdIo+'/results?search_query=كارتون&sp=EgIQAw==',144)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث: خطبة المرجعية',S7EgasGcYdIo+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def b3JHzUDKQtOqEMsoLfIr5X6ymgh(url,name,E7MF9aYlV4Q0):
	name = eEy0ApHLb7q5wOBXY(name)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'CHNL:  '+name,url,144,E7MF9aYlV4Q0)
	return
def ZZp1TCylreK9VBqmP7UWGt0XFNAL():
	ENDRjPGicXYFvpVs3xk5uSg6y(S7EgasGcYdIo+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def ELZHFyBWY70AMtCT8dxoDrk3():
	ENDRjPGicXYFvpVs3xk5uSg6y(S7EgasGcYdIo+'/results?search_query=tv&sp=EgJAAQ==')
	return
def QgIZSJdUhsEnup8GPz3(url,type):
	url = url.split('&',1)[0]
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2([url],mI6ayKxBvjd4CRthL,type,url)
	return
def v7H509CBMaS2dT(BBY0tql1h35EOvwD2gspHFaRxVed,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l):
	level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = qHmcPitXMaCJTswd7zj8W3Ux4u9l.split('::')
	CMpkAO6iuncyQw7DbHPfNx,FMBmJe8OVbW756XLlSivNCw = [],[]
	if '/youtubei/v1/browse' in url: CMpkAO6iuncyQw7DbHPfNx.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: CMpkAO6iuncyQw7DbHPfNx.append("yccc['onResponseReceivedCommands']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': CMpkAO6iuncyQw7DbHPfNx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['entries']")
	CMpkAO6iuncyQw7DbHPfNx.append("yccc['items'][3]['guideSectionRenderer']['items']")
	lWTehJZkcwH39C8V1rSiMDxqoGI,nNfHBGs6tSoAVyRFXWTaLcb5,ipsHa3dP81yTxC9 = TmukKV98eq6iofHw1QbzG(BBY0tql1h35EOvwD2gspHFaRxVed,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
	if level=='1' and lWTehJZkcwH39C8V1rSiMDxqoGI:
		if len(nNfHBGs6tSoAVyRFXWTaLcb5)>1 and 'search_query' not in url:
			for NromTvM42zpyS6 in range(len(nNfHBGs6tSoAVyRFXWTaLcb5)):
				z3zVdXhKO81UFTbA = str(NromTvM42zpyS6)
				CMpkAO6iuncyQw7DbHPfNx = []
				CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['reloadContinuationItemsCommand']['continuationItems']")
				CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['command']")
				CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]")
				oo3n0EuaHjYSz,Uz7N5KAHwQ93iShW1xj,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(nNfHBGs6tSoAVyRFXWTaLcb5,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
				if oo3n0EuaHjYSz: FMBmJe8OVbW756XLlSivNCw.append([Uz7N5KAHwQ93iShW1xj,url,'2::'+z3zVdXhKO81UFTbA+'::0::0'])
			CMpkAO6iuncyQw7DbHPfNx.append("yccc['continuationEndpoint']")
			oo3n0EuaHjYSz,Uz7N5KAHwQ93iShW1xj,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(BBY0tql1h35EOvwD2gspHFaRxVed,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
			if oo3n0EuaHjYSz and FMBmJe8OVbW756XLlSivNCw and 'continuationCommand' in list(Uz7N5KAHwQ93iShW1xj.keys()):
				cX2SpPxGLmADTKl = S7EgasGcYdIo+'/my_main_page_shorts_link'
				FMBmJe8OVbW756XLlSivNCw.append([Uz7N5KAHwQ93iShW1xj,cX2SpPxGLmADTKl,'1::0::0::0'])
	return nNfHBGs6tSoAVyRFXWTaLcb5,lWTehJZkcwH39C8V1rSiMDxqoGI,FMBmJe8OVbW756XLlSivNCw,ipsHa3dP81yTxC9
def FqRE0BcvZswMAUhStndDOYLaik(BBY0tql1h35EOvwD2gspHFaRxVed,nNfHBGs6tSoAVyRFXWTaLcb5,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l):
	level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = qHmcPitXMaCJTswd7zj8W3Ux4u9l.split('::')
	CMpkAO6iuncyQw7DbHPfNx,g1WA8otEZXTVvrmH2DaJ = [],[]
	CMpkAO6iuncyQw7DbHPfNx.append("yddd[0]['itemSectionRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['reloadContinuationItemsCommand']['continuationItems']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: CMpkAO6iuncyQw7DbHPfNx.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: CMpkAO6iuncyQw7DbHPfNx.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yddd["+z3zVdXhKO81UFTbA+"]")
	Db0yJEf59xVT,RNyjQGm529g6hZE,NhSxPU23Ji4HqDpbW7 = TmukKV98eq6iofHw1QbzG(nNfHBGs6tSoAVyRFXWTaLcb5,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
	if level=='2' and Db0yJEf59xVT:
		if len(RNyjQGm529g6hZE)>1:
			for NromTvM42zpyS6 in range(len(RNyjQGm529g6hZE)):
				CpwgGuWPXZnQzJvNqkhIF = str(NromTvM42zpyS6)
				CMpkAO6iuncyQw7DbHPfNx = []
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['richSectionRenderer']['content']")
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]")
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['richItemRenderer']['content']")
				CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]")
				oo3n0EuaHjYSz,Uz7N5KAHwQ93iShW1xj,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(RNyjQGm529g6hZE,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
				if oo3n0EuaHjYSz: g1WA8otEZXTVvrmH2DaJ.append([Uz7N5KAHwQ93iShW1xj,url,'3::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::0'])
			CMpkAO6iuncyQw7DbHPfNx.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			CMpkAO6iuncyQw7DbHPfNx.append("yddd[1]")
			oo3n0EuaHjYSz,Uz7N5KAHwQ93iShW1xj,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(nNfHBGs6tSoAVyRFXWTaLcb5,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
			if oo3n0EuaHjYSz and g1WA8otEZXTVvrmH2DaJ and 'continuationItemRenderer' in list(Uz7N5KAHwQ93iShW1xj.keys()):
				g1WA8otEZXTVvrmH2DaJ.append([Uz7N5KAHwQ93iShW1xj,url,'3::0::0::0'])
	return RNyjQGm529g6hZE,Db0yJEf59xVT,g1WA8otEZXTVvrmH2DaJ,NhSxPU23Ji4HqDpbW7
def IFfc0pBvDhN3P5g1XjbU(BBY0tql1h35EOvwD2gspHFaRxVed,RNyjQGm529g6hZE,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l):
	level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = qHmcPitXMaCJTswd7zj8W3Ux4u9l.split('::')
	CMpkAO6iuncyQw7DbHPfNx,BpKcuG6732qQeSXw0N = [],[]
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['reelShelfRenderer']['items']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee["+CpwgGuWPXZnQzJvNqkhIF+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	CMpkAO6iuncyQw7DbHPfNx.append("yeee")
	C0CFNlwTcJfaIQ6KWoXtbEB8pA,Ux1aZGuMg0wdlA4JK5NXbWrYIq,wfW1N4dVoJC32hILiQD09pmXEtMqjB = TmukKV98eq6iofHw1QbzG(RNyjQGm529g6hZE,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
	if level=='3' and C0CFNlwTcJfaIQ6KWoXtbEB8pA:
		if len(Ux1aZGuMg0wdlA4JK5NXbWrYIq)>0:
			for NromTvM42zpyS6 in range(len(Ux1aZGuMg0wdlA4JK5NXbWrYIq)):
				pul1XHwI5hbO7ivtoM2 = str(NromTvM42zpyS6)
				CMpkAO6iuncyQw7DbHPfNx = []
				CMpkAO6iuncyQw7DbHPfNx.append("yfff["+pul1XHwI5hbO7ivtoM2+"]['richItemRenderer']['content']")
				CMpkAO6iuncyQw7DbHPfNx.append("yfff["+pul1XHwI5hbO7ivtoM2+"]['gameCardRenderer']['game']")
				CMpkAO6iuncyQw7DbHPfNx.append("yfff["+pul1XHwI5hbO7ivtoM2+"]['itemSectionRenderer']['contents'][0]")
				CMpkAO6iuncyQw7DbHPfNx.append("yfff["+pul1XHwI5hbO7ivtoM2+"]")
				CMpkAO6iuncyQw7DbHPfNx.append("yfff")
				oo3n0EuaHjYSz,Uz7N5KAHwQ93iShW1xj,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Ux1aZGuMg0wdlA4JK5NXbWrYIq,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,CMpkAO6iuncyQw7DbHPfNx)
				if oo3n0EuaHjYSz: BpKcuG6732qQeSXw0N.append([Uz7N5KAHwQ93iShW1xj,url,'4::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2])
	return Ux1aZGuMg0wdlA4JK5NXbWrYIq,C0CFNlwTcJfaIQ6KWoXtbEB8pA,BpKcuG6732qQeSXw0N,wfW1N4dVoJC32hILiQD09pmXEtMqjB
def TmukKV98eq6iofHw1QbzG(fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu,peds9UJi6PoBCk7u3):
	BBY0tql1h35EOvwD2gspHFaRxVed,yg0RO5Z4qJBm9bu = fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu
	nNfHBGs6tSoAVyRFXWTaLcb5,yg0RO5Z4qJBm9bu = fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu
	RNyjQGm529g6hZE,yg0RO5Z4qJBm9bu = fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu
	Ux1aZGuMg0wdlA4JK5NXbWrYIq,yg0RO5Z4qJBm9bu = fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu
	Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z = fo4hLHW18Uj0EPyz,yg0RO5Z4qJBm9bu
	count = len(peds9UJi6PoBCk7u3)
	for r6dVWlzDj9va0FxqfkOwLYZEmP in range(count):
		try:
			EQXHT20bzVr = eval(peds9UJi6PoBCk7u3[r6dVWlzDj9va0FxqfkOwLYZEmP])
			return True,EQXHT20bzVr,r6dVWlzDj9va0FxqfkOwLYZEmP+1
		except: pass
	return False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,0
def ENDRjPGicXYFvpVs3xk5uSg6y(url,qHmcPitXMaCJTswd7zj8W3Ux4u9l=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,data=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	FMBmJe8OVbW756XLlSivNCw,g1WA8otEZXTVvrmH2DaJ,BpKcuG6732qQeSXw0N = [],[],[]
	if '::' not in qHmcPitXMaCJTswd7zj8W3Ux4u9l: qHmcPitXMaCJTswd7zj8W3Ux4u9l = '1::0::0::0'
	level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = qHmcPitXMaCJTswd7zj8W3Ux4u9l.split('::')
	if level=='4': level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = '1',z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2
	data = data.replace('_REMEMBERRESULTS_',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	R8AE9e4mYxVhusL3Q,BBY0tql1h35EOvwD2gspHFaRxVed,bo9ixEyvnlwmW = ttDdzjFSw4B(url,data)
	qHmcPitXMaCJTswd7zj8W3Ux4u9l = level+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
	if level in ['1','2','3']:
		nNfHBGs6tSoAVyRFXWTaLcb5,lWTehJZkcwH39C8V1rSiMDxqoGI,FMBmJe8OVbW756XLlSivNCw,ipsHa3dP81yTxC9 = v7H509CBMaS2dT(BBY0tql1h35EOvwD2gspHFaRxVed,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
		if not lWTehJZkcwH39C8V1rSiMDxqoGI: return
		wj2ZlV05FraUiIgm34hsRXDTxMnu = len(FMBmJe8OVbW756XLlSivNCw)
		if wj2ZlV05FraUiIgm34hsRXDTxMnu<2:
			if level=='1': level = '2'
			FMBmJe8OVbW756XLlSivNCw = []
	qHmcPitXMaCJTswd7zj8W3Ux4u9l = level+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
	if level in ['2','3']:
		RNyjQGm529g6hZE,Db0yJEf59xVT,g1WA8otEZXTVvrmH2DaJ,NhSxPU23Ji4HqDpbW7 = FqRE0BcvZswMAUhStndDOYLaik(BBY0tql1h35EOvwD2gspHFaRxVed,nNfHBGs6tSoAVyRFXWTaLcb5,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
		if not Db0yJEf59xVT: return
		mazQC0Hj1DJ9BnfsOqu8rh = len(g1WA8otEZXTVvrmH2DaJ)
		if mazQC0Hj1DJ9BnfsOqu8rh<2:
			if level=='2': level = '3'
			g1WA8otEZXTVvrmH2DaJ = []
	qHmcPitXMaCJTswd7zj8W3Ux4u9l = level+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
	if level in ['3']:
		Ux1aZGuMg0wdlA4JK5NXbWrYIq,C0CFNlwTcJfaIQ6KWoXtbEB8pA,BpKcuG6732qQeSXw0N,wfW1N4dVoJC32hILiQD09pmXEtMqjB = IFfc0pBvDhN3P5g1XjbU(BBY0tql1h35EOvwD2gspHFaRxVed,RNyjQGm529g6hZE,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
		if not C0CFNlwTcJfaIQ6KWoXtbEB8pA: return
		LsmVYNDyhSOoZtebQR40fAXaMJpG7j = len(BpKcuG6732qQeSXw0N)
	for Uz7N5KAHwQ93iShW1xj,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l in FMBmJe8OVbW756XLlSivNCw+g1WA8otEZXTVvrmH2DaJ+BpKcuG6732qQeSXw0N:
		vNufqGIEFj9c4MaQlkKTdLD = SxIuLH5yclUwszb0FK6GB(Uz7N5KAHwQ93iShW1xj,url,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	return
def SxIuLH5yclUwszb0FK6GB(Uz7N5KAHwQ93iShW1xj,url=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,qHmcPitXMaCJTswd7zj8W3Ux4u9l=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if '::' in qHmcPitXMaCJTswd7zj8W3Ux4u9l: level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = qHmcPitXMaCJTswd7zj8W3Ux4u9l.split('::')
	else: level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = '1','0','0','0'
	oo3n0EuaHjYSz,title,cX2SpPxGLmADTKl,RRx0ri8bETI,count,w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg,cfpDRaOJiA2PC3tEZ,Ty2OipF5K9Zlraf6qwC3mU = i5p9qfgcSrhj1uPol(Uz7N5KAHwQ93iShW1xj)
	Y9Szp0kV3cNxHyEDWnRXwU1jZ = '/videos?' in cX2SpPxGLmADTKl or '/streams?' in cX2SpPxGLmADTKl or '/playlists?' in cX2SpPxGLmADTKl
	jJUD7YeWdPw = '/channels?' in cX2SpPxGLmADTKl or '/shorts?' in cX2SpPxGLmADTKl
	if Y9Szp0kV3cNxHyEDWnRXwU1jZ or jJUD7YeWdPw: cX2SpPxGLmADTKl = url
	Y9Szp0kV3cNxHyEDWnRXwU1jZ = 'watch?v=' not in cX2SpPxGLmADTKl and '/playlist?list=' not in cX2SpPxGLmADTKl
	jJUD7YeWdPw = '/gaming' not in cX2SpPxGLmADTKl  and '/feed/storefront' not in cX2SpPxGLmADTKl
	if qHmcPitXMaCJTswd7zj8W3Ux4u9l[0:5]=='3::0::' and Y9Szp0kV3cNxHyEDWnRXwU1jZ and jJUD7YeWdPw: cX2SpPxGLmADTKl = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in cX2SpPxGLmADTKl:
		level,z3zVdXhKO81UFTbA,CpwgGuWPXZnQzJvNqkhIF,pul1XHwI5hbO7ivtoM2 = '1','0','0','0'
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	bo9ixEyvnlwmW = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if '/youtubei/v1/browse' in cX2SpPxGLmADTKl or '/youtubei/v1/search' in cX2SpPxGLmADTKl or '/my_main_page_shorts_link' in url:
		data = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.youtube.data')
		if data.count(':::')==4:
			Ef9nDACy2z0XcVSFLG1lI7NWmBQ,key,BB4qHcbSvm3Rni,p8pCWFTXIk7EiYB,jb7G0mIu2nD = data.split(':::')
			bo9ixEyvnlwmW = Ef9nDACy2z0XcVSFLG1lI7NWmBQ+':::'+key+':::'+BB4qHcbSvm3Rni+':::'+p8pCWFTXIk7EiYB+':::'+Ty2OipF5K9Zlraf6qwC3mU
			if '/my_main_page_shorts_link' in url and not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = url
			else: cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?key='+key
	if not title:
		global CRx2in8dm7yEhwD0
		CRx2in8dm7yEhwD0 += 1
		title = 'فيديوهات '+str(CRx2in8dm7yEhwD0)
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = '3'+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
	if not oo3n0EuaHjYSz: return False
	elif 'searchPyvRenderer' in str(Uz7N5KAHwQ93iShW1xj): return False
	elif '/about' in cX2SpPxGLmADTKl: return False
	elif '/community' in cX2SpPxGLmADTKl: return False
	elif 'continuationItemRenderer' in list(Uz7N5KAHwQ93iShW1xj.keys()) or 'continuationCommand' in list(Uz7N5KAHwQ93iShW1xj.keys()):
		if int(level)>1: level = str(int(level)-1)
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = level+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+':: '+'صفحة أخرى',cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l,bo9ixEyvnlwmW)
	elif '/search' in cX2SpPxGLmADTKl:
		title = ':: '+title
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = '3'+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
		url = url.replace('/search',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,145,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,qHmcPitXMaCJTswd7zj8W3Ux4u9l,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not cX2SpPxGLmADTKl:
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = '3'+'::'+z3zVdXhKO81UFTbA+'::'+CpwgGuWPXZnQzJvNqkhIF+'::'+pul1XHwI5hbO7ivtoM2
		title = ':: '+title
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l,bo9ixEyvnlwmW)
	elif '/browse' in cX2SpPxGLmADTKl and url==S7EgasGcYdIo:
		title = ':: '+title
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = '2::0::0::0'
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l,bo9ixEyvnlwmW)
	elif not cX2SpPxGLmADTKl and 'horizontalMovieListRenderer' in str(Uz7N5KAHwQ93iShW1xj):
		title = ':: '+title
		qHmcPitXMaCJTswd7zj8W3Ux4u9l = '3::0::0::0'
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	elif 'messageRenderer' in str(Uz7N5KAHwQ93iShW1xj):
		w3BfOGLdXcWzbiC1PYx9mE('link',qBAgzkG9oCL+title,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	elif oXTnmRLOSktClA6c8sg:
		w3BfOGLdXcWzbiC1PYx9mE('live',qBAgzkG9oCL+oXTnmRLOSktClA6c8sg+title,cX2SpPxGLmADTKl,143,RRx0ri8bETI)
	elif '/playlist?list=' in cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('&playnext=1',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'LIST'+count+':  '+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	elif '/shorts/' in cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('&list=',1)[0]
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,143,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
	elif '/watch?v=' in cX2SpPxGLmADTKl:
		if '&list=' in cX2SpPxGLmADTKl and count:
			gymP4aqGpvOF8HEr = cX2SpPxGLmADTKl.split('&list=',1)[1]
			cX2SpPxGLmADTKl = S7EgasGcYdIo+'/playlist?list='+gymP4aqGpvOF8HEr
			qHmcPitXMaCJTswd7zj8W3Ux4u9l = '1::0::0::0'
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'LIST'+count+':  '+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
		else:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split('&list=',1)[0]
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,143,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
	elif '/channel/' in cX2SpPxGLmADTKl or '/c/' in cX2SpPxGLmADTKl or ('/@' in cX2SpPxGLmADTKl and cX2SpPxGLmADTKl.count('/')==3):
		if hT1JIgqPQsUOZp5tjCX0E:
			title = title.decode(RMGz7OiD1e30P).encode('raw_unicode_escape')
			title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'CHNL'+count+':  '+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	elif '/user/' in cX2SpPxGLmADTKl:
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'USER'+count+':  '+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	else:
		if not cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = url
		title = ':: '+title
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,144,RRx0ri8bETI,qHmcPitXMaCJTswd7zj8W3Ux4u9l,bo9ixEyvnlwmW)
	return True
def i5p9qfgcSrhj1uPol(Uz7N5KAHwQ93iShW1xj):
	oo3n0EuaHjYSz,title,cX2SpPxGLmADTKl,RRx0ri8bETI,count,w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg,cfpDRaOJiA2PC3tEZ,jb7G0mIu2nD = False,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if not isinstance(Uz7N5KAHwQ93iShW1xj,dict): return oo3n0EuaHjYSz,title,cX2SpPxGLmADTKl,RRx0ri8bETI,count,w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg,cfpDRaOJiA2PC3tEZ,jb7G0mIu2nD
	for o796Qp3HxD in list(Uz7N5KAHwQ93iShW1xj.keys()):
		hht2cV13NkvxPDQnOjAHMX4z = Uz7N5KAHwQ93iShW1xj[o796Qp3HxD]
		if isinstance(hht2cV13NkvxPDQnOjAHMX4z,dict): break
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['header']['richListHeaderRenderer']['title']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['headline']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['unplayableText']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['formattedTitle']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['title']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['title']['runs'][0]['text']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['text']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['text']['runs'][0]['text']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['title']['content']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['title']")
	CMpkAO6iuncyQw7DbHPfNx.append("item['title']")
	CMpkAO6iuncyQw7DbHPfNx.append("item['reelWatchEndpoint']['videoId']")
	oo3n0EuaHjYSz,title,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("item['commandMetadata']['webCommandMetadata']['url']")
	oo3n0EuaHjYSz,cX2SpPxGLmADTKl,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnail']['thumbnails'][0]['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	CMpkAO6iuncyQw7DbHPfNx.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	oo3n0EuaHjYSz,RRx0ri8bETI,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['videoCountShortText']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['videoCountText']['runs'][0]['text']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['videoCount']")
	oo3n0EuaHjYSz,count,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['lengthText']['simpleText']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	oo3n0EuaHjYSz,w03zWJvcXaCUySB6HIq4mVe,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	CMpkAO6iuncyQw7DbHPfNx = []
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	CMpkAO6iuncyQw7DbHPfNx.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	oo3n0EuaHjYSz,jb7G0mIu2nD,KBtshNldD0nmAHTgEzcbIMWG9ri = TmukKV98eq6iofHw1QbzG(Uz7N5KAHwQ93iShW1xj,hht2cV13NkvxPDQnOjAHMX4z,CMpkAO6iuncyQw7DbHPfNx)
	if 'LIVE' in w03zWJvcXaCUySB6HIq4mVe: w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVE:  '
	if 'مباشر' in w03zWJvcXaCUySB6HIq4mVe: w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'LIVE:  '
	if 'badges' in list(hht2cV13NkvxPDQnOjAHMX4z.keys()):
		DPtsd6lnIXLkiBR437ZQ9MyaoU2 = str(hht2cV13NkvxPDQnOjAHMX4z['badges'])
		if 'Free with Ads' in DPtsd6lnIXLkiBR437ZQ9MyaoU2: cfpDRaOJiA2PC3tEZ = '$:  '
		if 'LIVE' in DPtsd6lnIXLkiBR437ZQ9MyaoU2: oXTnmRLOSktClA6c8sg = 'LIVE:  '
		if 'Buy' in DPtsd6lnIXLkiBR437ZQ9MyaoU2 or 'Rent' in DPtsd6lnIXLkiBR437ZQ9MyaoU2: cfpDRaOJiA2PC3tEZ = '$$:  '
		if RspX7vMFScnPqAubegiNlo1HDW83UE(u'مباشر') in DPtsd6lnIXLkiBR437ZQ9MyaoU2: oXTnmRLOSktClA6c8sg = 'LIVE:  '
		if RspX7vMFScnPqAubegiNlo1HDW83UE(u'شراء') in DPtsd6lnIXLkiBR437ZQ9MyaoU2: cfpDRaOJiA2PC3tEZ = '$$:  '
		if RspX7vMFScnPqAubegiNlo1HDW83UE(u'استئجار') in DPtsd6lnIXLkiBR437ZQ9MyaoU2: cfpDRaOJiA2PC3tEZ = '$$:  '
		if RspX7vMFScnPqAubegiNlo1HDW83UE(u'إعلانات') in DPtsd6lnIXLkiBR437ZQ9MyaoU2: cfpDRaOJiA2PC3tEZ = '$:  '
	cX2SpPxGLmADTKl = kd8ZhJPCe7QzxLgij3TEHlGtOv(cX2SpPxGLmADTKl)
	if cX2SpPxGLmADTKl and 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+cX2SpPxGLmADTKl
	RRx0ri8bETI = RRx0ri8bETI.split('?')[0]
	if  RRx0ri8bETI and 'http' not in RRx0ri8bETI: RRx0ri8bETI = 'https:'+RRx0ri8bETI
	title = kd8ZhJPCe7QzxLgij3TEHlGtOv(title)
	if cfpDRaOJiA2PC3tEZ: title = cfpDRaOJiA2PC3tEZ+title
	w03zWJvcXaCUySB6HIq4mVe = w03zWJvcXaCUySB6HIq4mVe.replace(',',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	count = count.replace(',',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
	count = AxTYMhRlfyskNc0X19dvwtS.findall('\d+',count)
	if count: count = count[0]
	else: count = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	return True,title,cX2SpPxGLmADTKl,RRx0ri8bETI,count,w03zWJvcXaCUySB6HIq4mVe,oXTnmRLOSktClA6c8sg,cfpDRaOJiA2PC3tEZ,jb7G0mIu2nD
def ttDdzjFSw4B(url,data=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	if eBjxVKSvQC1==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: eBjxVKSvQC1 = 'ytInitialData'
	xL93S8G1wJdkPsa = YwSBWkv2f3Us()
	aNXRWYnbow7s8fpvLVK = {'User-Agent':xL93S8G1wJdkPsa,'Cookie':'PREF=hl=ar'}
	global xeI7QzBgGEXN8ftCawRpO24nDh
	if not data: data = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting('av.youtube.data')
	if data.count(':::')==4: Ef9nDACy2z0XcVSFLG1lI7NWmBQ,key,BB4qHcbSvm3Rni,p8pCWFTXIk7EiYB,jb7G0mIu2nD = data.split(':::')
	else: Ef9nDACy2z0XcVSFLG1lI7NWmBQ,key,BB4qHcbSvm3Rni,p8pCWFTXIk7EiYB,jb7G0mIu2nD = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	bo9ixEyvnlwmW = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":BB4qHcbSvm3Rni}}}
	if url==S7EgasGcYdIo+'/shorts' or '/my_main_page_shorts_link' in url:
		url = S7EgasGcYdIo+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		bo9ixEyvnlwmW['sequenceParams'] = Ef9nDACy2z0XcVSFLG1lI7NWmBQ
		bo9ixEyvnlwmW = str(bo9ixEyvnlwmW)
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',url,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = S7EgasGcYdIo+'/youtubei/v1/guide?key='+key
		bo9ixEyvnlwmW = str(bo9ixEyvnlwmW)
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',url,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and Ef9nDACy2z0XcVSFLG1lI7NWmBQ:
		bo9ixEyvnlwmW['continuation'] = jb7G0mIu2nD
		bo9ixEyvnlwmW['context']['client']['visitorData'] = Ef9nDACy2z0XcVSFLG1lI7NWmBQ
		bo9ixEyvnlwmW = str(bo9ixEyvnlwmW)
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'POST',url,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and p8pCWFTXIk7EiYB:
		aNXRWYnbow7s8fpvLVK.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':BB4qHcbSvm3Rni})
		aNXRWYnbow7s8fpvLVK.update({'Cookie':'VISITOR_INFO1_LIVE='+p8pCWFTXIk7EiYB})
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(V7DSdHck4Fjp,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'YOUTUBE-GET_PAGE_DATA-6th')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall('"innertubeApiKey".*?"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.I)
	if oPeI4pms5LfYHrxygnAh: key = oPeI4pms5LfYHrxygnAh[0]
	oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall('"cver".*?"value".*?"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.I)
	if oPeI4pms5LfYHrxygnAh: BB4qHcbSvm3Rni = oPeI4pms5LfYHrxygnAh[0]
	oPeI4pms5LfYHrxygnAh = AxTYMhRlfyskNc0X19dvwtS.findall('"visitorData".*?"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL|AxTYMhRlfyskNc0X19dvwtS.I)
	if oPeI4pms5LfYHrxygnAh: Ef9nDACy2z0XcVSFLG1lI7NWmBQ = oPeI4pms5LfYHrxygnAh[0]
	cookies = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): p8pCWFTXIk7EiYB = cookies['VISITOR_INFO1_LIVE']
	pPsAqmiJfEVyth2G49cX0DKB6w = Ef9nDACy2z0XcVSFLG1lI7NWmBQ+':::'+key+':::'+BB4qHcbSvm3Rni+':::'+p8pCWFTXIk7EiYB+':::'+jb7G0mIu2nD
	if eBjxVKSvQC1=='ytInitialData' and 'ytInitialData' in R8AE9e4mYxVhusL3Q:
		qq2gm9Q5C6ABenpoUF8w1vjDM = AxTYMhRlfyskNc0X19dvwtS.findall('window\["ytInitialData"\] = ({.*?});',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not qq2gm9Q5C6ABenpoUF8w1vjDM: qq2gm9Q5C6ABenpoUF8w1vjDM = AxTYMhRlfyskNc0X19dvwtS.findall('var ytInitialData = ({.*?});',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		yIC4Mow0Lgxr2blQZBYEdVcapS = rKY1tyQvh9OCxE2nl('str',qq2gm9Q5C6ABenpoUF8w1vjDM[0])
	elif eBjxVKSvQC1=='ytInitialGuideData' and 'ytInitialGuideData' in R8AE9e4mYxVhusL3Q:
		qq2gm9Q5C6ABenpoUF8w1vjDM = AxTYMhRlfyskNc0X19dvwtS.findall('var ytInitialGuideData = ({.*?});',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		yIC4Mow0Lgxr2blQZBYEdVcapS = rKY1tyQvh9OCxE2nl('str',qq2gm9Q5C6ABenpoUF8w1vjDM[0])
	elif '</script>' not in R8AE9e4mYxVhusL3Q: yIC4Mow0Lgxr2blQZBYEdVcapS = rKY1tyQvh9OCxE2nl('str',R8AE9e4mYxVhusL3Q)
	else: yIC4Mow0Lgxr2blQZBYEdVcapS = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if 0:
		BBY0tql1h35EOvwD2gspHFaRxVed = str(yIC4Mow0Lgxr2blQZBYEdVcapS)
		if fOohwvakqi29cx0l3yt5mzrAGpEg: BBY0tql1h35EOvwD2gspHFaRxVed = BBY0tql1h35EOvwD2gspHFaRxVed.encode(RMGz7OiD1e30P)
		open('S:\\0000emad.dat','wb').write(BBY0tql1h35EOvwD2gspHFaRxVed)
	xeI7QzBgGEXN8ftCawRpO24nDh.setSetting('av.youtube.data',pPsAqmiJfEVyth2G49cX0DKB6w)
	return R8AE9e4mYxVhusL3Q,yIC4Mow0Lgxr2blQZBYEdVcapS,pPsAqmiJfEVyth2G49cX0DKB6w
def LXNCVcTRAasE8t(url,qHmcPitXMaCJTswd7zj8W3Ux4u9l):
	search = TwDBf3QbKOnrmd5u9()
	if not search: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	nUDgc4absePT2xMt = url+'/search?query='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(nUDgc4absePT2xMt,qHmcPitXMaCJTswd7zj8W3Ux4u9l)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search:
		search = TwDBf3QbKOnrmd5u9()
		if not search: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	nUDgc4absePT2xMt = S7EgasGcYdIo+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in sL9HIPc1tSZrhE60TUoz2KQa: oiJslAxDe0aKThFwzZQPbdVmSqL = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in sL9HIPc1tSZrhE60TUoz2KQa: oiJslAxDe0aKThFwzZQPbdVmSqL = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in sL9HIPc1tSZrhE60TUoz2KQa: oiJslAxDe0aKThFwzZQPbdVmSqL = '&sp=EgIQAg%253D%253D'
		else: oiJslAxDe0aKThFwzZQPbdVmSqL = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		jYfvU9egTX62nrukVcoKEAyq = nUDgc4absePT2xMt+oiJslAxDe0aKThFwzZQPbdVmSqL
	else:
		MJOnNqSUsyhe70ktEIa,hu8jaV0lPm4nyrO9qJS5Z,uoH6T37WPfCdv8JLnYZjK2r = [],[],VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		CTBqfI2cGiFzYEmywd = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		eei8fcbHmR96ozEdWkP = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		hu7ZgbqXBjr2n54FIv9 = YLUMzC9m0dc('اختر البحث المناسب',CTBqfI2cGiFzYEmywd)
		if hu7ZgbqXBjr2n54FIv9 == -1: return
		Ehw6B2ya4KvdrJNjHqe = eei8fcbHmR96ozEdWkP[hu7ZgbqXBjr2n54FIv9]
		R8AE9e4mYxVhusL3Q,EfzvSx2kKFcNseD5HCA7VMh9P31b,data = ttDdzjFSw4B(nUDgc4absePT2xMt+Ehw6B2ya4KvdrJNjHqe)
		if EfzvSx2kKFcNseD5HCA7VMh9P31b:
			try:
				UUDso1KjXbrNx3e = EfzvSx2kKFcNseD5HCA7VMh9P31b['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for xxI9SUDw8ZvdmJOlECk in range(len(UUDso1KjXbrNx3e)):
					group = UUDso1KjXbrNx3e[xxI9SUDw8ZvdmJOlECk]['searchFilterGroupRenderer']['filters']
					for RhZsqBwHjcYJ8VD3n9k in range(len(group)):
						hht2cV13NkvxPDQnOjAHMX4z = group[RhZsqBwHjcYJ8VD3n9k]['searchFilterRenderer']
						if 'navigationEndpoint' in list(hht2cV13NkvxPDQnOjAHMX4z.keys()):
							cX2SpPxGLmADTKl = hht2cV13NkvxPDQnOjAHMX4z['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('\u0026','&')
							title = hht2cV13NkvxPDQnOjAHMX4z['tooltip']
							title = title.replace('البحث عن ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								uoH6T37WPfCdv8JLnYZjK2r = title
								evGVuBpQUEL = cX2SpPxGLmADTKl
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								uoH6T37WPfCdv8JLnYZjK2r = title
								evGVuBpQUEL = cX2SpPxGLmADTKl
							if 'Sort by' in title: continue
							MJOnNqSUsyhe70ktEIa.append(kd8ZhJPCe7QzxLgij3TEHlGtOv(title))
							hu8jaV0lPm4nyrO9qJS5Z.append(cX2SpPxGLmADTKl)
			except: pass
		if not uoH6T37WPfCdv8JLnYZjK2r: ZB8zvjSMofn0skdXcypHC2AUV = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
		else:
			MJOnNqSUsyhe70ktEIa = ['بدون فلتر',uoH6T37WPfCdv8JLnYZjK2r]+MJOnNqSUsyhe70ktEIa
			hu8jaV0lPm4nyrO9qJS5Z = [VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,evGVuBpQUEL]+hu8jaV0lPm4nyrO9qJS5Z
			aeTuPkBqCFz9IMHhXE = YLUMzC9m0dc('موقع يوتيوب - اختر الفلتر',MJOnNqSUsyhe70ktEIa)
			if aeTuPkBqCFz9IMHhXE == -1: return
			ZB8zvjSMofn0skdXcypHC2AUV = hu8jaV0lPm4nyrO9qJS5Z[aeTuPkBqCFz9IMHhXE]
		if ZB8zvjSMofn0skdXcypHC2AUV: jYfvU9egTX62nrukVcoKEAyq = S7EgasGcYdIo+ZB8zvjSMofn0skdXcypHC2AUV
		elif Ehw6B2ya4KvdrJNjHqe: jYfvU9egTX62nrukVcoKEAyq = nUDgc4absePT2xMt+Ehw6B2ya4KvdrJNjHqe
		else: jYfvU9egTX62nrukVcoKEAyq = nUDgc4absePT2xMt
	ENDRjPGicXYFvpVs3xk5uSg6y(jYfvU9egTX62nrukVcoKEAyq)
	return