# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'EGYNOW'
qBAgzkG9oCL = '_EGN_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==430: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==431: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==432: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==433: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==434: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==437: Ubud2NhHKRnMTvI5mprQBVqk80 = Gbek8c4fX1WoFKTdJtrBqsUVZzav(url)
	elif mode==439: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo+'/films',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = AxTYMhRlfyskNc0X19dvwtS.findall('"canonical" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GGRexoVTLjusn6q = GGRexoVTLjusn6q[0].strip('/')
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(GGRexoVTLjusn6q,'url')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,439,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',GGRexoVTLjusn6q,435)
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',GGRexoVTLjusn6q,434)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'المضاف حديثا',GGRexoVTLjusn6q,431)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'افلام اون لاين',GGRexoVTLjusn6q+'/films1',436)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'مسلسلات اون لاين',GGRexoVTLjusn6q+'/series-all1',436)
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'قائمة تفصيلية',GGRexoVTLjusn6q,437)
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"SiteNavigation"(.*?)"Search"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,431)
	return
def Gbek8c4fX1WoFKTdJtrBqsUVZzav(website=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',website+'/films',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	GGRexoVTLjusn6q = AxTYMhRlfyskNc0X19dvwtS.findall('"canonical" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	GGRexoVTLjusn6q = GGRexoVTLjusn6q[0].strip('/')
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(GGRexoVTLjusn6q,'url')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"ListDroped"(.*?)"SearchingMaster"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for PtATpb3YenChf5,value,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		cX2SpPxGLmADTKl = website+'/explore/?'+PtATpb3YenChf5+'='+value
		w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,431)
	return
def I1C6JqXo3j9Ruyz(url):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-SUBMENU-1st')
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع',url,431)
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"titleSectionCon"(.*?)</div></div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-key="(.*?)".*?<em>(.*?)</em>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for gV1lKIhwSm0GQ,title in items:
		if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
		nUDgc4absePT2xMt = GGRexoVTLjusn6q+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+gV1lKIhwSm0GQ
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,nUDgc4absePT2xMt,431)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,eBjxVKSvQC1=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
		aNXRWYnbow7s8fpvLVK = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-TITLES-1st')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		IxdmfnvhCA8Bc9ZlQ45oiqN = R8AE9e4mYxVhusL3Q
	elif eBjxVKSvQC1=='featured':
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-TITLES-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"MainSlider"(.*?)"MatchesTable"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-TITLES-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"BlocksList"(.*?)"Paginate"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if not vvuraxgW7YLIZ4hU0MbCt: vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"BlocksList"(.*?)"titleSectionCon"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	if not items: items = AxTYMhRlfyskNc0X19dvwtS.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	EaUe8ArOCD = []
	Nz9HCo7mkrpPAu5ytaibEvjgM2c = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
		cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl).strip('/')
		title = riUKNnOEtVwdj4(title)
		azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) الحلقة \d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if any(value in title for value in Nz9HCo7mkrpPAu5ytaibEvjgM2c):
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,432,RRx0ri8bETI)
		elif azhwpE0qmevcFobdRi and 'الحلقة' in title:
			title = '_MOD_' + azhwpE0qmevcFobdRi[0]
			if title not in EaUe8ArOCD:
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,433,RRx0ri8bETI)
				EaUe8ArOCD.append(title)
		elif '/movseries/' in cX2SpPxGLmADTKl:
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,431,RRx0ri8bETI)
		else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,433,RRx0ri8bETI)
	if eBjxVKSvQC1!='featured':
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"Paginate"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = GGRexoVTLjusn6q+cX2SpPxGLmADTKl
				cX2SpPxGLmADTKl = riUKNnOEtVwdj4(cX2SpPxGLmADTKl)
				title = riUKNnOEtVwdj4(title)
				if title!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,431)
		zGyAMhFIjxNdlb6ZeX54 = AxTYMhRlfyskNc0X19dvwtS.findall('showmore" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if zGyAMhFIjxNdlb6ZeX54:
			cX2SpPxGLmADTKl = zGyAMhFIjxNdlb6ZeX54[0]
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'مشاهدة المزيد',cX2SpPxGLmADTKl,431)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	j9HbACE1rmuP48NVX6pgQsUwfBWk,fxgnWRoUO7jNwtJkuB = [],[]
	if 'Episodes.php' in url:
		nUDgc4absePT2xMt,bo9ixEyvnlwmW = J1jmhoWbQuqR8g2YpK(url)
		aNXRWYnbow7s8fpvLVK = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'POST',nUDgc4absePT2xMt,bo9ixEyvnlwmW,aNXRWYnbow7s8fpvLVK,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-EPISODES-1st')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		fxgnWRoUO7jNwtJkuB = [R8AE9e4mYxVhusL3Q]
	else:
		gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-EPISODES-2nd')
		R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
		j9HbACE1rmuP48NVX6pgQsUwfBWk = AxTYMhRlfyskNc0X19dvwtS.findall('"SeasonsList"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		fxgnWRoUO7jNwtJkuB = AxTYMhRlfyskNc0X19dvwtS.findall('"EpisodesList"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if j9HbACE1rmuP48NVX6pgQsUwfBWk:
		RRx0ri8bETI = AxTYMhRlfyskNc0X19dvwtS.findall('"og:image" content="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		RRx0ri8bETI = RRx0ri8bETI[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = j9HbACE1rmuP48NVX6pgQsUwfBWk[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for FuGekrm1E0pZ78vj4WhVdbR9aOtCD,awdo9J3qEhHjsR2yiv,title in items:
			cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+awdo9J3qEhHjsR2yiv+'&post_id='+FuGekrm1E0pZ78vj4WhVdbR9aOtCD
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,433,RRx0ri8bETI)
	elif fxgnWRoUO7jNwtJkuB:
		RRx0ri8bETI = mMaH8ZsXEch3TyYi0PA1gNSxCzLUW.getInfoLabel('ListItem.Thumb')
		IxdmfnvhCA8Bc9ZlQ45oiqN = fxgnWRoUO7jNwtJkuB[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,azhwpE0qmevcFobdRi in items:
			title = title+WRsuxHTjDgYCIpoMQzLFAtS8rikP+azhwpE0qmevcFobdRi
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,432,RRx0ri8bETI)
	return
def QgIZSJdUhsEnup8GPz3(url):
	nUDgc4absePT2xMt = url+'/watch/'
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	CBL4OQVtWbMAycUGl7Ex2SKZF = []
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(nUDgc4absePT2xMt,'url')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"container-servers"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		YDidHrbPsIFGoTAvlwtL = AxTYMhRlfyskNc0X19dvwtS.findall('data-id="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if YDidHrbPsIFGoTAvlwtL:
			YDidHrbPsIFGoTAvlwtL = YDidHrbPsIFGoTAvlwtL[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('data-server="(.*?)".*?<span>(.*?)</span>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for LLzkoiPsbBZ,title in items:
				cX2SpPxGLmADTKl = GGRexoVTLjusn6q+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+LLzkoiPsbBZ+'&post_id='+YDidHrbPsIFGoTAvlwtL+'?named='+title+'__watch'
				CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	zIb4L2ntdXGUcWfvB6gwMPVE = AxTYMhRlfyskNc0X19dvwtS.findall('"container-iframe"><iframe src="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if zIb4L2ntdXGUcWfvB6gwMPVE:
		zIb4L2ntdXGUcWfvB6gwMPVE = zIb4L2ntdXGUcWfvB6gwMPVE[0].replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		title = UUmYkruGeM3p8sKi6o2fcI(zIb4L2ntdXGUcWfvB6gwMPVE,'name')
		cX2SpPxGLmADTKl = zIb4L2ntdXGUcWfvB6gwMPVE+'?named='+title+'__embed'
		CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"container-download"(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title,XcvFdKRjNLz5wEpDf in items:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace(b8sk5WyPoz03pXhRx,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
			if XcvFdKRjNLz5wEpDf!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: XcvFdKRjNLz5wEpDf = '____'+XcvFdKRjNLz5wEpDf
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__download'+XcvFdKRjNLz5wEpDf
			CBL4OQVtWbMAycUGl7Ex2SKZF.append(cX2SpPxGLmADTKl)
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(CBL4OQVtWbMAycUGl7Ex2SKZF,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	url = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url)
	return
def RKFfhG6MsCPv8BrNUpzo7d9gX(url):
	url = url.split('/smartemadfilter?')[0]
	GGRexoVTLjusn6q = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',GGRexoVTLjusn6q,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('("dropdown-button".*?)"SearchingMaster"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return i2KVkE3TFNIGfymrpJA
def vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN):
	items = AxTYMhRlfyskNc0X19dvwtS.findall('data-term="(\d+)" data-name="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return items
def M0M1GZXwzE(url):
	VChIfEZU37zqWGnL = url.split('/smartemadfilter?')[0]
	kkzeVtyGuvFbsDNpYgXLBUZrO6 = UUmYkruGeM3p8sKi6o2fcI(url,'url')
	url = url.replace(VChIfEZU37zqWGnL,kkzeVtyGuvFbsDNpYgXLBUZrO6)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def h2C74FvuN3DdOywiKfA8(w4bR5rAa7OFdUxjPI3NVDHy,url):
	pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'modified_filters')
	jYfvU9egTX62nrukVcoKEAyq = url+'/smartemadfilter?'+pbIlAP6KNW
	jYfvU9egTX62nrukVcoKEAyq = M0M1GZXwzE(jYfvU9egTX62nrukVcoKEAyq)
	return jYfvU9egTX62nrukVcoKEAyq
agsNp4VJm8d3e = ['category','country','genre','release-year']
iuECgXkw3pcy1FAvK96G = ['quality','release-year','genre','category','language','country']
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if agsNp4VJm8d3e[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(agsNp4VJm8d3e[0:-1])):
			if agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = agsNp4VJm8d3e[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
	elif type=='ALL_ITEMS_FILTER':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF!=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'modified_filters')
		if J41jTEGvedKYQgclAiUuPxF==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'/smartemadfilter?'+J41jTEGvedKYQgclAiUuPxF
		nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها ',nUDgc4absePT2xMt,431)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',nUDgc4absePT2xMt,431)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	i2KVkE3TFNIGfymrpJA = RKFfhG6MsCPv8BrNUpzo7d9gX(url)
	dict = {}
	for name,IxdmfnvhCA8Bc9ZlQ45oiqN,CCkP7yi8aglTqbDOdBjRWNpco in i2KVkE3TFNIGfymrpJA:
		name = name.replace('--',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		items = vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='SPECIFIED_FILTER':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<2:
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]:
					url = M0M1GZXwzE(url)
					ENDRjPGicXYFvpVs3xk5uSg6y(url)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'SPECIFIED_FILTER___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				nUDgc4absePT2xMt = M0M1GZXwzE(nUDgc4absePT2xMt)
				if CCkP7yi8aglTqbDOdBjRWNpco==agsNp4VJm8d3e[-1]: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع ',nUDgc4absePT2xMt,431)
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع ',nUDgc4absePT2xMt,435,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='ALL_ITEMS_FILTER':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع :'+name,nUDgc4absePT2xMt,434,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if value=='196533': HHvPeCLzN1fIWDStR = 'أفلام نيتفلكس'
			elif value=='196531': HHvPeCLzN1fIWDStR = 'مسلسلات نيتفلكس'
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' :'#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' :'+name
			if type=='ALL_ITEMS_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,434,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='SPECIFIED_FILTER' and agsNp4VJm8d3e[-2]+'=' in gjOp9yI3iS:
				jYfvU9egTX62nrukVcoKEAyq = h2C74FvuN3DdOywiKfA8(w4bR5rAa7OFdUxjPI3NVDHy,url)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,431)
			else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,435,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.replace('=&','=0&')
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for key in iuECgXkw3pcy1FAvK96G:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if '%' not in value: value = pmhHwIbkcrRJeyzuxPUSDGnqM92(value)
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all_filters': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.replace('=0','=')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd