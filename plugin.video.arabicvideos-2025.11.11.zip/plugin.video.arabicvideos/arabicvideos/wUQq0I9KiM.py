# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'ALFATIMI'
qBAgzkG9oCL = '_FTM_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
qBotHUf4ma2NAuYFpy = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
GNHCiaedkZYBVSpKzxvALD3 = ['3030','628']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==60: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==61: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==62: Ubud2NhHKRnMTvI5mprQBVqk80 = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	elif mode==63: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==64: Ubud2NhHKRnMTvI5mprQBVqk80 = VbpBg5ePdJwMXE7QqkH1hOo(text)
	elif mode==69: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,69,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'ما يتم مشاهدته الان',S7EgasGcYdIo,64,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'recent_viewed_vids')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'الاكثر مشاهدة',S7EgasGcYdIo,64,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'most_viewed_vids')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'اضيفت مؤخرا',S7EgasGcYdIo,64,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'recently_added_vids')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'فيديو عشوائي',S7EgasGcYdIo,64,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'random_vids')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'افلام ومسلسلات',S7EgasGcYdIo,61,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'-1')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'البرامج الدينية',S7EgasGcYdIo,61,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'-2')
	w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+'English Videos',S7EgasGcYdIo,61,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'-3')
	return VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
def ENDRjPGicXYFvpVs3xk5uSg6y(url,PtATpb3YenChf5):
	mpItOLs9bMwNR86hAr = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	if PtATpb3YenChf5 not in ['-1','-2','-3']: mpItOLs9bMwNR86hAr = '?cat='+PtATpb3YenChf5
	nUDgc4absePT2xMt = S7EgasGcYdIo+'/menu_level.php'+mpItOLs9bMwNR86hAr
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,nUDgc4absePT2xMt,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'ALFATIMI-TITLES-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	vTMFyE6XVi8eY4PO5Q,A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = False,False
	for cX2SpPxGLmADTKl,title,count in items:
		title = riUKNnOEtVwdj4(title)
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
		mpItOLs9bMwNR86hAr = AxTYMhRlfyskNc0X19dvwtS.findall('cat=(.*?)&',cX2SpPxGLmADTKl,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
		if PtATpb3YenChf5==mpItOLs9bMwNR86hAr: vTMFyE6XVi8eY4PO5Q = True
		elif vTMFyE6XVi8eY4PO5Q 	or (PtATpb3YenChf5=='-1' and mpItOLs9bMwNR86hAr in qBotHUf4ma2NAuYFpy)  						or (PtATpb3YenChf5=='-2' and mpItOLs9bMwNR86hAr not in GNHCiaedkZYBVSpKzxvALD3 and mpItOLs9bMwNR86hAr not in qBotHUf4ma2NAuYFpy)  						or (PtATpb3YenChf5=='-3' and mpItOLs9bMwNR86hAr in GNHCiaedkZYBVSpKzxvALD3):
							if count=='1': w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,63)
							else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,61,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,mpItOLs9bMwNR86hAr)
							A0DvrNp1LJuZObd2EeUg6kmtnWI4F8 = True
	if not A0DvrNp1LJuZObd2EeUg6kmtnWI4F8: SnpFbUovmMwfXalIGRNys6zYZtj(url)
	return
def SnpFbUovmMwfXalIGRNys6zYZtj(url):
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(BRMcS58jIbyDQWGYLk1term,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,True,'ALFATIMI-EPISODES-1st')
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('pagination(.*?)id="footer',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
	items = AxTYMhRlfyskNc0X19dvwtS.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	cX2SpPxGLmADTKl = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for RRx0ri8bETI,title,cX2SpPxGLmADTKl in items:
		title = title.replace('Add',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).replace('to Quicklist',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O).strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,63,RRx0ri8bETI)
	vvuraxgW7YLIZ4hU0MbCt=AxTYMhRlfyskNc0X19dvwtS.findall('(.*?)div',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	IxdmfnvhCA8Bc9ZlQ45oiqN=vvuraxgW7YLIZ4hU0MbCt[0]
	IxdmfnvhCA8Bc9ZlQ45oiqN=AxTYMhRlfyskNc0X19dvwtS.findall('pagination(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)[0]
	items=AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	nUDgc4absePT2xMt = url.split('?')[0]
	for cX2SpPxGLmADTKl,VIdjQswzuMv in items:
		cX2SpPxGLmADTKl = nUDgc4absePT2xMt + cX2SpPxGLmADTKl
		title = riUKNnOEtVwdj4(VIdjQswzuMv)
		title = 'صفحة ' + title
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,62)
	return cX2SpPxGLmADTKl
def QgIZSJdUhsEnup8GPz3(url):
	if 'videos.php' in url: url = SnpFbUovmMwfXalIGRNys6zYZtj(url)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,True,'ALFATIMI-PLAY-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('playlistfile:"(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	ljvayUBqRuXKi8pkmJZIzTPgMO5HQ(url,mI6ayKxBvjd4CRthL,'video')
	return
def VbpBg5ePdJwMXE7QqkH1hOo(PtATpb3YenChf5):
	dXG96SRYbe = { 'mode' : PtATpb3YenChf5 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = g726UBevLKbpyh8o35Z4fdPiRrn9uG(dXG96SRYbe)
	R8AE9e4mYxVhusL3Q = rklnGqfgbeMhWB8uVaCRXwjLPQDtA2(V7DSdHck4Fjp,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for cX2SpPxGLmADTKl,title,RRx0ri8bETI in items:
		title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
		if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = 'http:'+cX2SpPxGLmADTKl
		w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,63,RRx0ri8bETI)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo + '/search_result.php?query=' + ej9gRJkD6KGTcf
	SnpFbUovmMwfXalIGRNys6zYZtj(url)
	return