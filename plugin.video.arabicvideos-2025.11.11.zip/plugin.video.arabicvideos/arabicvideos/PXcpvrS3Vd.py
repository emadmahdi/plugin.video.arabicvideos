# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'EGYBEST1'
qBAgzkG9oCL = '_EB1_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['مكتبتي','ايجي بست']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,GpwRnQ6q2o1fv0HbJTs,text):
	if   mode==770: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==771: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==772: Ubud2NhHKRnMTvI5mprQBVqk80 = I1C6JqXo3j9Ruyz(url)
	elif mode==773: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==774: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'FULL_FILTER___'+text)
	elif mode==775: Ubud2NhHKRnMTvI5mprQBVqk80 = EM3FsPBeAD2bQxi0LThaKG(url,'DEFINED_FILTER___'+text)
	elif mode==776: Ubud2NhHKRnMTvI5mprQBVqk80 = ErZkM18Pf2S0VKNAzb(url,GpwRnQ6q2o1fv0HbJTs)
	elif mode==779: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text,url)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,779,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYBEST1-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('nav-list(.*?)</ul>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)</span>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			if any(value in title for value in kCIESuy4j5mVLZYtG9vDNnb7): continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,771)
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-article(.*?)social-box',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('main-title.*?">(.*?)<.*?href="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for title,cX2SpPxGLmADTKl in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'mainmenu')
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-menu(.*?)</div></div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,771)
	return R8AE9e4mYxVhusL3Q
def ErZkM18Pf2S0VKNAzb(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYBEST1-SEASONS_EPISODES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-article".*?">(.*?)<(.*?)article',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		uySI4qTsgKzWVUG9frhj1owtx8i2p,rhVCfIQyOJ,items = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,[]
		for name,IxdmfnvhCA8Bc9ZlQ45oiqN in vvuraxgW7YLIZ4hU0MbCt:
			if 'حلقات' in name: rhVCfIQyOJ = IxdmfnvhCA8Bc9ZlQ45oiqN
			if 'مواسم' in name: uySI4qTsgKzWVUG9frhj1owtx8i2p = IxdmfnvhCA8Bc9ZlQ45oiqN
		if uySI4qTsgKzWVUG9frhj1owtx8i2p and not type:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',uySI4qTsgKzWVUG9frhj1owtx8i2p,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if len(items)>1:
				for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,776,RRx0ri8bETI,'season')
		if rhVCfIQyOJ and len(items)<2:
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',rhVCfIQyOJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if items:
				for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
					w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,773,RRx0ri8bETI)
			else:
				items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)<',rhVCfIQyOJ,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				for cX2SpPxGLmADTKl,title in items:
					w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,773)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYBEST1-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	items,Jtn91QpsNAdqkSYzVi8mcPeKGyrh,MgyFSaLl60jzkrZ27 = [],False,False
	if not type:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('main-content(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?</i>(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,title in items:
				title = title.strip(WRsuxHTjDgYCIpoMQzLFAtS8rikP)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'submenu')
				Jtn91QpsNAdqkSYzVi8mcPeKGyrh = True
	if not type and 'p=' not in url:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('searchform(.*?)</form>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			if Jtn91QpsNAdqkSYzVi8mcPeKGyrh: w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر محدد',url,775,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'فلتر كامل',url,774,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث',url,779)
			w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
			MgyFSaLl60jzkrZ27 = True
	if not Jtn91QpsNAdqkSYzVi8mcPeKGyrh:
		vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('blocks(.*?)article',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if vvuraxgW7YLIZ4hU0MbCt:
			IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
			items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			for cX2SpPxGLmADTKl,RRx0ri8bETI,title in items:
				RRx0ri8bETI = RRx0ri8bETI.strip(b8sk5WyPoz03pXhRx)
				cX2SpPxGLmADTKl = WDg18QHF3rze(cX2SpPxGLmADTKl)
				if '/serie/' in cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,776,RRx0ri8bETI,'season')
				else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,773,RRx0ri8bETI)
			GpwRnQ6q2o1fv0HbJTs = '1'
			if 'p=' in url: url,GpwRnQ6q2o1fv0HbJTs = url.split('p=',1)
			BlzEMV9YmO = '&' if '?' in url else '?'
			url = url+BlzEMV9YmO
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(GpwRnQ6q2o1fv0HbJTs)+1)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الصفحة التالية',url,771)
			elif GpwRnQ6q2o1fv0HbJTs!='1':
				url = url+'p='+str(int(GpwRnQ6q2o1fv0HbJTs)-1)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الصفحة السابقة',url,771)
	return
def QgIZSJdUhsEnup8GPz3(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(RFowY7JrTPs8c5m02ydD1VgbeBup3N,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYBEST1-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	OOhn4JVk8esTi2G1cd = AxTYMhRlfyskNc0X19dvwtS.findall('<label>التصنيف</label>.*?">(.*?)<',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if OOhn4JVk8esTi2G1cd and OJzf0pXiZ8wArvYT(mI6ayKxBvjd4CRthL,url,OOhn4JVk8esTi2G1cd): return
	lFL9QtV2u1pa7WoieSmv3YzZPb,dU17fayKLj4kABu,MEek23FnTZBc = [],[],[]
	cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('download-section.*?action="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if cX2SpPxGLmADTKl:
		cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
		if cX2SpPxGLmADTKl not in MEek23FnTZBc:
			MEek23FnTZBc.append(cX2SpPxGLmADTKl)
			dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named=__embed______'+pmhHwIbkcrRJeyzuxPUSDGnqM92(url))
	GtnfmdqIOijegYu = AxTYMhRlfyskNc0X19dvwtS.findall('WatchServers(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	for IxdmfnvhCA8Bc9ZlQ45oiqN in GtnfmdqIOijegYu:
		BA01W9olieErLycV7kwFvOhH5Y3ms = AxTYMhRlfyskNc0X19dvwtS.findall("url='(.*?)'.*?>(.*?)<",IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,LLzkoiPsbBZ in BA01W9olieErLycV7kwFvOhH5Y3ms:
			if cX2SpPxGLmADTKl not in MEek23FnTZBc:
				MEek23FnTZBc.append(cX2SpPxGLmADTKl)
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+LLzkoiPsbBZ+'__both______'+pmhHwIbkcrRJeyzuxPUSDGnqM92(url))
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search,url=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if not search: search = TwDBf3QbKOnrmd5u9()
	if not search: return
	ej9gRJkD6KGTcf = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'%20')
	if not url: url = S7EgasGcYdIo+'/search?query='+ej9gRJkD6KGTcf
	else: url = url+'?title='+ej9gRJkD6KGTcf+'&genre=&year=&lang='
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return
def RKFfhG6MsCPv8BrNUpzo7d9gX(url):
	url = url.split('/smartemadfilter?')[0]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(QTa0s1bvhkXjIim7lWF5qVBJUoNZ,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	i2KVkE3TFNIGfymrpJA = []
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('form-row(.*?)</form>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		i2KVkE3TFNIGfymrpJA = AxTYMhRlfyskNc0X19dvwtS.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		XXF5kafMOKZnCEwVxL8dWQpicYgm4,cclJEkZuLNn7r3FOWwiGbATU2V,GtnfmdqIOijegYu = zip(*i2KVkE3TFNIGfymrpJA)
		i2KVkE3TFNIGfymrpJA = zip(cclJEkZuLNn7r3FOWwiGbATU2V,XXF5kafMOKZnCEwVxL8dWQpicYgm4,GtnfmdqIOijegYu)
	return i2KVkE3TFNIGfymrpJA
def vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN):
	items = AxTYMhRlfyskNc0X19dvwtS.findall('value="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	return items
def nFtcOfK8WPTVSGyvrIEXpU1g07zodM(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
lVYsPXjJ40EwWgn1QBNuk = ['year','lang','genre']
Lc4lhNBeQpM3 = ['year','lang','genre']
def EM3FsPBeAD2bQxi0LThaKG(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	else: gjOp9yI3iS,J41jTEGvedKYQgclAiUuPxF = filter.split('___')
	if type=='DEFINED_FILTER':
		if Lc4lhNBeQpM3[0]+'=' not in gjOp9yI3iS: PtATpb3YenChf5 = Lc4lhNBeQpM3[0]
		for uKFGBAEj9tX1e03cyHOMUNhQl4r6 in range(len(Lc4lhNBeQpM3[0:-1])):
			if Lc4lhNBeQpM3[uKFGBAEj9tX1e03cyHOMUNhQl4r6]+'=' in gjOp9yI3iS: PtATpb3YenChf5 = Lc4lhNBeQpM3[uKFGBAEj9tX1e03cyHOMUNhQl4r6+1]
		k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+PtATpb3YenChf5+'=0'
		w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+PtATpb3YenChf5+'=0'
		Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf.strip('&')+'___'+w4bR5rAa7OFdUxjPI3NVDHy.strip('&')
		pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
	elif type=='FULL_FILTER':
		X8XFujIern5yUpSHlY = qqZYmWaiG9NbMTejnw8DP7RQV(gjOp9yI3iS,'modified_values')
		X8XFujIern5yUpSHlY = WDg18QHF3rze(X8XFujIern5yUpSHlY)
		if J41jTEGvedKYQgclAiUuPxF: J41jTEGvedKYQgclAiUuPxF = qqZYmWaiG9NbMTejnw8DP7RQV(J41jTEGvedKYQgclAiUuPxF,'all')
		if not J41jTEGvedKYQgclAiUuPxF: nUDgc4absePT2xMt = url
		else: nUDgc4absePT2xMt = url+'/smartemadfilter?'+J41jTEGvedKYQgclAiUuPxF
		jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'أظهار قائمة الفيديو التي تم اختيارها ',jYfvU9egTX62nrukVcoKEAyq,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
		w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+' [[   '+X8XFujIern5yUpSHlY+'   ]]',jYfvU9egTX62nrukVcoKEAyq,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
		w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	i2KVkE3TFNIGfymrpJA = RKFfhG6MsCPv8BrNUpzo7d9gX(url)
	dict = {}
	for name,CCkP7yi8aglTqbDOdBjRWNpco,IxdmfnvhCA8Bc9ZlQ45oiqN in i2KVkE3TFNIGfymrpJA:
		name = name.replace('كل ',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
		items = vrsXwFMKyPN(IxdmfnvhCA8Bc9ZlQ45oiqN)
		if '=' not in nUDgc4absePT2xMt: nUDgc4absePT2xMt = url
		if type=='DEFINED_FILTER':
			if PtATpb3YenChf5!=CCkP7yi8aglTqbDOdBjRWNpco: continue
			elif len(items)<2:
				if CCkP7yi8aglTqbDOdBjRWNpco==Lc4lhNBeQpM3[-1]:
					jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
					ENDRjPGicXYFvpVs3xk5uSg6y(jYfvU9egTX62nrukVcoKEAyq)
				else: EM3FsPBeAD2bQxi0LThaKG(nUDgc4absePT2xMt,'DEFINED_FILTER___'+Brh1oNYgWFGZDTKIkHzd)
				return
			else:
				if CCkP7yi8aglTqbDOdBjRWNpco==Lc4lhNBeQpM3[-1]:
					jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع ',jYfvU9egTX62nrukVcoKEAyq,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
				else: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع ',nUDgc4absePT2xMt,775,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		elif type=='FULL_FILTER':
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'=0'
			Brh1oNYgWFGZDTKIkHzd = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'الجميع :'+name,nUDgc4absePT2xMt,774,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,Brh1oNYgWFGZDTKIkHzd)
		dict[CCkP7yi8aglTqbDOdBjRWNpco] = {}
		for value,HHvPeCLzN1fIWDStR in items:
			if not value: continue
			if HHvPeCLzN1fIWDStR in kCIESuy4j5mVLZYtG9vDNnb7: continue
			dict[CCkP7yi8aglTqbDOdBjRWNpco][value] = HHvPeCLzN1fIWDStR
			k6kxDquJ0nhoycOtZzlAb3gTdUjf = gjOp9yI3iS+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+HHvPeCLzN1fIWDStR
			w4bR5rAa7OFdUxjPI3NVDHy = J41jTEGvedKYQgclAiUuPxF+'&'+CCkP7yi8aglTqbDOdBjRWNpco+'='+value
			NU54yQnTW9hsZA1ocH = k6kxDquJ0nhoycOtZzlAb3gTdUjf+'___'+w4bR5rAa7OFdUxjPI3NVDHy
			title = HHvPeCLzN1fIWDStR+' :'#+dict[CCkP7yi8aglTqbDOdBjRWNpco]['0']
			title = HHvPeCLzN1fIWDStR+' :'+name
			if type=='FULL_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,774,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
			elif type=='DEFINED_FILTER' and Lc4lhNBeQpM3[-2]+'=' in gjOp9yI3iS:
				pbIlAP6KNW = qqZYmWaiG9NbMTejnw8DP7RQV(w4bR5rAa7OFdUxjPI3NVDHy,'modified_filters')
				nUDgc4absePT2xMt = url+'/smartemadfilter?'+pbIlAP6KNW
				jYfvU9egTX62nrukVcoKEAyq = nFtcOfK8WPTVSGyvrIEXpU1g07zodM(nUDgc4absePT2xMt)
				w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,jYfvU9egTX62nrukVcoKEAyq,771,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'filter')
			elif type=='DEFINED_FILTER': w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,url,775,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,NU54yQnTW9hsZA1ocH)
	return
def qqZYmWaiG9NbMTejnw8DP7RQV(MgyFSaLl60jzkrZ27,mode):
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.replace('=&','=0&')
	MgyFSaLl60jzkrZ27 = MgyFSaLl60jzkrZ27.strip('&')
	LM3xn2N487F9D = {}
	if '=' in MgyFSaLl60jzkrZ27:
		items = MgyFSaLl60jzkrZ27.split('&')
		for Uz7N5KAHwQ93iShW1xj in items:
			c72bnzmgOfUp6SlAGvrDuZ4Hi,value = Uz7N5KAHwQ93iShW1xj.split('=')
			LM3xn2N487F9D[c72bnzmgOfUp6SlAGvrDuZ4Hi] = value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
	for key in lVYsPXjJ40EwWgn1QBNuk:
		if key in list(LM3xn2N487F9D.keys()): value = LM3xn2N487F9D[key]
		else: value = '0'
		if '%' not in value: value = pmhHwIbkcrRJeyzuxPUSDGnqM92(value)
		if mode=='modified_values' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+' + '+value
		elif mode=='modified_filters' and value!='0': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
		elif mode=='all': NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd+'&'+key+'='+value
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip(' + ')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.strip('&')
	NNMyRTax2hXIq8DHUWQiJfmsBPprnd = NNMyRTax2hXIq8DHUWQiJfmsBPprnd.replace('=0','=')
	return NNMyRTax2hXIq8DHUWQiJfmsBPprnd