# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = w9wfONXUP3(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
qBAgzkG9oCL = Zb5cNeHWi6jP9SCYtUgR(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
e1cvdDOxnQ9h70ouMfIZy = oNlez5gnM9x2B4.path.join(BHyCtoKZYiVSqaAGdMxDbflr5U,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
rGcINgtFy7DkEwYjbC3OfTRx4oZhJ = oNlez5gnM9x2B4.path.join(BHyCtoKZYiVSqaAGdMxDbflr5U,pYeVwat64v(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
nFhRa45167DylfIKwkvPcjH0X = oNlez5gnM9x2B4.path.join(nYqRaDM7QlmrEUKSAevsC,rAYDiWlzm9MCU6x0GnROua(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
Di7ZW0pBKgNAJl6qF5IHho1TEO = W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
o0ES17VX3PmUbil = Zb5cNeHWi6jP9SCYtUgR(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
sxoUnA3GebqB57iOCuJM = GTmHXIZUSdxRhMnqQKkO(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
ldpbRFsG36 = nR0ok9zju84rFUQl1YC(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
fvA8KsBJnERLc9TdPe2Fu4YNDV = awSUTRNMkdIW7sFEvnHD2mLY(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
QO1NgWhSlmGAT93zwknyPIdt = zWBnYSGIatjXVC(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
rGDR2hfgx8 = jaVSoQGFYUlCugWK9kLc
Z1bnGVvkRrwfL = eC21aUbHsMhBQnfVypk8T
gmvZFcprRVBT7Uw4GIyfQ = wr09KHPobQzacATVJs4Eykd
def jtanDvbPkg21urO4ZL7EcQyqeG(t5fhagjUGXk0ynOlJWeAb):
	if   t5fhagjUGXk0ynOlJWeAb==MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠹࠷࠴ࣉ"): Ubud2NhHKRnMTvI5mprQBVqk80 = fr4o3Hm5w8FLX()
	elif t5fhagjUGXk0ynOlJWeAb==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠺࠸࠶࣊"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(e1cvdDOxnQ9h70ouMfIZy,NFGqKBLtvUZn1S3dau,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==ba49YvOK2Aw8Uhxt(u"࠻࠹࠸࣋"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(rGcINgtFy7DkEwYjbC3OfTRx4oZhJ,NFGqKBLtvUZn1S3dau,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠼࠺࠳࣌"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(nFhRa45167DylfIKwkvPcjH0X,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==awSUTRNMkdIW7sFEvnHD2mLY(u"࠽࠴࠵࣍"): Ubud2NhHKRnMTvI5mprQBVqk80 = YN82kmwonH4JtAX7ylqQ9OWUVSeK(NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==hWRvZOYtjme9QNnV41u0Mswb(u"࠷࠵࠷࣎"): Ubud2NhHKRnMTvI5mprQBVqk80 = OBoSgfmdHUvbJik(NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==I6Bfzysrvb8DONZ(u"࠸࠶࠹࣏"): Ubud2NhHKRnMTvI5mprQBVqk80 = oD9g3fpkYzN6c(NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==W2Vv30i8qxSuItfsolPLdFZA(u"࠹࠸࠴࣐"): Ubud2NhHKRnMTvI5mprQBVqk80 = kAhYftdKVHnbszCFGTqLw6ur5yQ()
	elif t5fhagjUGXk0ynOlJWeAb==pbmKZA1w7L4zHjOM(u"࠺࠹࠶࣑"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(Di7ZW0pBKgNAJl6qF5IHho1TEO,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠻࠺࠸࣒"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(o0ES17VX3PmUbil,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==JZ45mOctiTszPNw1GVjxhep2Y(u"࠼࠻࠳࣓"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(sxoUnA3GebqB57iOCuJM,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠽࠵࠵ࣔ"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(ldpbRFsG36,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==djapWhrveLJbgnViDftFNY05ylq1S(u"࠷࠶࠷ࣕ"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(fvA8KsBJnERLc9TdPe2Fu4YNDV,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==zWBnYSGIatjXVC(u"࠸࠷࠹ࣖ"): Ubud2NhHKRnMTvI5mprQBVqk80 = RRAoUt0ihbYj(QO1NgWhSlmGAT93zwknyPIdt,pLwgjkuTs6CS,NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==awSUTRNMkdIW7sFEvnHD2mLY(u"࠹࠸࠻ࣗ"): Ubud2NhHKRnMTvI5mprQBVqk80 = JAFc8KZw4XpP73oOLi9jedzEHla(NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==lRKCWnNi0Edr984eI(u"࠺࠹࠽ࣘ"): Ubud2NhHKRnMTvI5mprQBVqk80 = xFCzpUOSc0yeKBuYZjvHLqt9gW1();kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==w9wfONXUP3(u"࠵࠵࠾࠰ࣙ"): Ubud2NhHKRnMTvI5mprQBVqk80 = ZPhNw1RDSBciTYC()
	elif t5fhagjUGXk0ynOlJWeAb==Zb5cNeHWi6jP9SCYtUgR(u"࠶࠶࠸࠲ࣚ"): Ubud2NhHKRnMTvI5mprQBVqk80 = C9Lgl8i30JFoW5fIbmsU71(NFGqKBLtvUZn1S3dau);kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==awSUTRNMkdIW7sFEvnHD2mLY(u"࠷࠰࠹࠴ࣛ"): Ubud2NhHKRnMTvI5mprQBVqk80 = cW4eLK3h2avpZix();kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==GTmHXIZUSdxRhMnqQKkO(u"࠱࠱࠺࠶ࣜ"): Ubud2NhHKRnMTvI5mprQBVqk80 = KavzJmAU1kelxF2y();kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==hWRvZOYtjme9QNnV41u0Mswb(u"࠲࠲࠻࠸ࣝ"): Ubud2NhHKRnMTvI5mprQBVqk80 = DNTjoHaY2w9sCUL4RE();kDOyGIN3Cvm(Ubud2NhHKRnMTvI5mprQBVqk80)
	elif t5fhagjUGXk0ynOlJWeAb==B1YMtuvRAGNlJOkC46VyPKQE(u"࠳࠳࠼࠺ࣞ"): Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif t5fhagjUGXk0ynOlJWeAb==hWRvZOYtjme9QNnV41u0Mswb(u"࠴࠴࠽࠼ࣟ"): Ubud2NhHKRnMTvI5mprQBVqk80 = xG9hL84qZetRFXTW()
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = pLwgjkuTs6CS
	return Ubud2NhHKRnMTvI5mprQBVqk80
def xG9hL84qZetRFXTW():
	zsnpLKb3Oi = I6Bfzysrvb8DONZ(u"࠵࠵࠸࠴࣠")*I6Bfzysrvb8DONZ(u"࠵࠵࠸࠴࣠")
	iQUrRqMOa2le4t0sNzI3f7bFkZ = aID4r82pKW1F0LM6AynBHiObkqt()//zsnpLKb3Oi
	OSgjXatNkR = iQUrRqMOa2le4t0sNzI3f7bFkZ<B1YMtuvRAGNlJOkC46VyPKQE(u"࠺࠶࣡")
	size = qFghPAi5yz9Vf3NLwo0nuprl+nR0ok9zju84rFUQl1YC(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+so4Z8OUJ5E
	if OSgjXatNkR:
		UO05pib6mcvezR9(gLv2Ra9NjkesOlrCF,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(iQUrRqMOa2le4t0sNzI3f7bFkZ)+lRKCWnNi0Edr984eI(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,YzlId3Fs6vpehcbLGj0UaO(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,YzlId3Fs6vpehcbLGj0UaO(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return OSgjXatNkR
def kDOyGIN3Cvm(vNufqGIEFj9c4MaQlkKTdLD):
	if vNufqGIEFj9c4MaQlkKTdLD: GGfDYrMCxAh59v4bSaXpnO1qHkIK(NFGqKBLtvUZn1S3dau)
	return
def cBfe1kCEI4uZTVpKqwbGQR():
	w3BfOGLdXcWzbiC1PYx9mE(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷࠰࠹࠸࣢"))
	w3BfOGLdXcWzbiC1PYx9mE(kAz7WRYjrfGm(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠷࠶࠲ࣣ"))
	w3BfOGLdXcWzbiC1PYx9mE(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,lRKCWnNi0Edr984eI(u"࠸࠶࠳ࣤ"))
	w3BfOGLdXcWzbiC1PYx9mE(pYeVwat64v(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),ba49YvOK2Aw8Uhxt(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠳࠳࠼࠵ࣥ"))
	return
def ZPhNw1RDSBciTYC():
	VEaqjs1Gf6,wj2ZlV05FraUiIgm34hsRXDTxMnu = VPDIE5e8Cxg(rGDR2hfgx8)
	DfEGljexbIqhc2MJaYSvXWpR8tZ,mazQC0Hj1DJ9BnfsOqu8rh = VPDIE5e8Cxg(Z1bnGVvkRrwfL)
	Udxg4nAMtw6Q,LsmVYNDyhSOoZtebQR40fAXaMJpG7j = yxjuaUT04zJF(gmvZFcprRVBT7Uw4GIyfQ)
	yLFDfh6YORE4Bpx3PnTgizjXk,DDzFgpl0MahHE91CxXjku = VEaqjs1Gf6+DfEGljexbIqhc2MJaYSvXWpR8tZ+Udxg4nAMtw6Q,wj2ZlV05FraUiIgm34hsRXDTxMnu+mazQC0Hj1DJ9BnfsOqu8rh+LsmVYNDyhSOoZtebQR40fAXaMJpG7j
	OeF5CiHPAUrk9TlYdjg = zWBnYSGIatjXVC(u"ࠩࠣࠬࠬࠚ")+O6vWXsY8rKZ7lDMkP21dQyR5S(VEaqjs1Gf6)+pYeVwat64v(u"ࠪࠤ࠲ࠦࠧࠛ")+str(wj2ZlV05FraUiIgm34hsRXDTxMnu)+hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	aenBI6927xL8SojFDwbuVNMCU4H = fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠬࠦࠨࠨࠝ")+O6vWXsY8rKZ7lDMkP21dQyR5S(DfEGljexbIqhc2MJaYSvXWpR8tZ)+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࠠ࠮ࠢࠪࠞ")+str(mazQC0Hj1DJ9BnfsOqu8rh)+djapWhrveLJbgnViDftFNY05ylq1S(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	XXB5x24zvVyJpTIYQnmSE0WFkiC = Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࠢࠫࠫࠠ")+O6vWXsY8rKZ7lDMkP21dQyR5S(Udxg4nAMtw6Q)+ba49YvOK2Aw8Uhxt(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(LsmVYNDyhSOoZtebQR40fAXaMJpG7j)+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	MMcdLWoFbyTej8xm6Qf9C1vhS43wP = GTmHXIZUSdxRhMnqQKkO(u"ࠫࠥ࠮ࠧࠣ")+O6vWXsY8rKZ7lDMkP21dQyR5S(yLFDfh6YORE4Bpx3PnTgizjXk)+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬࠦ࠭ࠡࠩࠤ")+str(DDzFgpl0MahHE91CxXjku)+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	w3BfOGLdXcWzbiC1PYx9mE(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),qBAgzkG9oCL+ba49YvOK2Aw8Uhxt(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,awSUTRNMkdIW7sFEvnHD2mLY(u"࠴࠴࠽࠺ࣦ"))
	w3BfOGLdXcWzbiC1PYx9mE(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),qFghPAi5yz9Vf3NLwo0nuprl+hWRvZOYtjme9QNnV41u0Mswb(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠽࠾࠿࠹ࣧ"))
	w3BfOGLdXcWzbiC1PYx9mE(pYeVwat64v(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),qBAgzkG9oCL+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+OeF5CiHPAUrk9TlYdjg,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,rAYDiWlzm9MCU6x0GnROua(u"࠶࠶࠸࠲ࣨ"))
	w3BfOGLdXcWzbiC1PYx9mE(djapWhrveLJbgnViDftFNY05ylq1S(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),qBAgzkG9oCL+Zb5cNeHWi6jP9SCYtUgR(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+aenBI6927xL8SojFDwbuVNMCU4H,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠷࠰࠹࠴ࣩ"))
	w3BfOGLdXcWzbiC1PYx9mE(w9wfONXUP3(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),qBAgzkG9oCL+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+XXB5x24zvVyJpTIYQnmSE0WFkiC,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,B1YMtuvRAGNlJOkC46VyPKQE(u"࠱࠱࠺࠶࣪"))
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),qBAgzkG9oCL+w9wfONXUP3(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠲࠲࠻࠸࣫"))
	return
def DNTjoHaY2w9sCUL4RE():
	vNufqGIEFj9c4MaQlkKTdLD = pLwgjkuTs6CS
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,nR0ok9zju84rFUQl1YC(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if e6f0ycMuYQEJraNLInmip:
		gxTXZDnIb9ipPhmN8SfVkMer = KavzJmAU1kelxF2y()
		BH4rAhocbWsR0edPZnzN5kmfOyKJ37 = RRAoUt0ihbYj(eC21aUbHsMhBQnfVypk8T,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
		vNufqGIEFj9c4MaQlkKTdLD = gxTXZDnIb9ipPhmN8SfVkMer and BH4rAhocbWsR0edPZnzN5kmfOyKJ37
		if vNufqGIEFj9c4MaQlkKTdLD: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pbmKZA1w7L4zHjOM(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return vNufqGIEFj9c4MaQlkKTdLD
def cW4eLK3h2avpZix():
	import IxiP9D6sLd
	IxiP9D6sLd.QQqLmWdsxBOfD0RrzgHIVcKEt6()
	oo3n0EuaHjYSz = pLwgjkuTs6CS
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),GTmHXIZUSdxRhMnqQKkO(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
		oo3n0EuaHjYSz = RRAoUt0ihbYj(eC21aUbHsMhBQnfVypk8T,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
		if oo3n0EuaHjYSz: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,f9fOpCmLAEaW2Go(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zWBnYSGIatjXVC(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return oo3n0EuaHjYSz
def KavzJmAU1kelxF2y():
	oo3n0EuaHjYSz = pLwgjkuTs6CS
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(ba49YvOK2Aw8Uhxt(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧิฦส่ࠬ࠻"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
		try:
			oNlez5gnM9x2B4.remove(wr09KHPobQzacATVJs4Eykd)
			oo3n0EuaHjYSz = NFGqKBLtvUZn1S3dau
		except: pass
		if oo3n0EuaHjYSz: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return oo3n0EuaHjYSz
def ZPhNw1RDSBciTYC():
	VEaqjs1Gf6,wj2ZlV05FraUiIgm34hsRXDTxMnu = VPDIE5e8Cxg(rGDR2hfgx8)
	DfEGljexbIqhc2MJaYSvXWpR8tZ,mazQC0Hj1DJ9BnfsOqu8rh = VPDIE5e8Cxg(Z1bnGVvkRrwfL)
	Udxg4nAMtw6Q,LsmVYNDyhSOoZtebQR40fAXaMJpG7j = yxjuaUT04zJF(gmvZFcprRVBT7Uw4GIyfQ)
	yLFDfh6YORE4Bpx3PnTgizjXk,DDzFgpl0MahHE91CxXjku = VEaqjs1Gf6+DfEGljexbIqhc2MJaYSvXWpR8tZ+Udxg4nAMtw6Q,wj2ZlV05FraUiIgm34hsRXDTxMnu+mazQC0Hj1DJ9BnfsOqu8rh+LsmVYNDyhSOoZtebQR40fAXaMJpG7j
	OeF5CiHPAUrk9TlYdjg = kAz7WRYjrfGm(u"ࠫࠥ࠮ࠧ࠿")+O6vWXsY8rKZ7lDMkP21dQyR5S(VEaqjs1Gf6)+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬࠦ࠭ࠡࠩࡀ")+str(wj2ZlV05FraUiIgm34hsRXDTxMnu)+I6Bfzysrvb8DONZ(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	aenBI6927xL8SojFDwbuVNMCU4H = zWBnYSGIatjXVC(u"ࠧࠡࠪࠪࡂ")+O6vWXsY8rKZ7lDMkP21dQyR5S(DfEGljexbIqhc2MJaYSvXWpR8tZ)+I6Bfzysrvb8DONZ(u"ࠨࠢ࠰ࠤࠬࡃ")+str(mazQC0Hj1DJ9BnfsOqu8rh)+KKCrwPdOgGl(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	XXB5x24zvVyJpTIYQnmSE0WFkiC = W2Vv30i8qxSuItfsolPLdFZA(u"ࠪࠤ࠭࠭ࡅ")+O6vWXsY8rKZ7lDMkP21dQyR5S(Udxg4nAMtw6Q)+I6Bfzysrvb8DONZ(u"ࠫࠥ࠳ࠠࠨࡆ")+str(LsmVYNDyhSOoZtebQR40fAXaMJpG7j)+f9fOpCmLAEaW2Go(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	MMcdLWoFbyTej8xm6Qf9C1vhS43wP = JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࠠࠩࠩࡈ")+O6vWXsY8rKZ7lDMkP21dQyR5S(yLFDfh6YORE4Bpx3PnTgizjXk)+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࠡ࠯ࠣࠫࡉ")+str(DDzFgpl0MahHE91CxXjku)+KKCrwPdOgGl(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	w3BfOGLdXcWzbiC1PYx9mE(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),qBAgzkG9oCL+bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠳࠳࠼࠹࣬"))
	w3BfOGLdXcWzbiC1PYx9mE(pL73X0MYajJQG4n1qgD(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),qFghPAi5yz9Vf3NLwo0nuprl+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠼࠽࠾࠿࣭"))
	w3BfOGLdXcWzbiC1PYx9mE(bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),qBAgzkG9oCL+W2Vv30i8qxSuItfsolPLdFZA(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+OeF5CiHPAUrk9TlYdjg,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pL73X0MYajJQG4n1qgD(u"࠵࠵࠾࠱࣮"))
	w3BfOGLdXcWzbiC1PYx9mE(ba49YvOK2Aw8Uhxt(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),qBAgzkG9oCL+f9fOpCmLAEaW2Go(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+aenBI6927xL8SojFDwbuVNMCU4H,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,nR0ok9zju84rFUQl1YC(u"࠶࠶࠸࠳࣯"))
	w3BfOGLdXcWzbiC1PYx9mE(JZ45mOctiTszPNw1GVjxhep2Y(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),qBAgzkG9oCL+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+XXB5x24zvVyJpTIYQnmSE0WFkiC,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"࠷࠰࠹࠵ࣰ"))
	w3BfOGLdXcWzbiC1PYx9mE(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),qBAgzkG9oCL+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠱࠱࠺࠷ࣱ"))
	return
def fr4o3Hm5w8FLX():
	VEaqjs1Gf6,wj2ZlV05FraUiIgm34hsRXDTxMnu = VPDIE5e8Cxg(e1cvdDOxnQ9h70ouMfIZy)
	DfEGljexbIqhc2MJaYSvXWpR8tZ,mazQC0Hj1DJ9BnfsOqu8rh = VPDIE5e8Cxg(rGcINgtFy7DkEwYjbC3OfTRx4oZhJ)
	Udxg4nAMtw6Q,LsmVYNDyhSOoZtebQR40fAXaMJpG7j = VPDIE5e8Cxg(nFhRa45167DylfIKwkvPcjH0X)
	yLFDfh6YORE4Bpx3PnTgizjXk,DDzFgpl0MahHE91CxXjku = yxjuaUT04zJF(HJa8EMWF75SyD9)
	yLFDfh6YORE4Bpx3PnTgizjXk -= bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠴࠸࠻࠺࠹ࣲ")
	DDzFgpl0MahHE91CxXjku -= xD9WeoEAsX7
	AehPEBHmikb0MnWaDZwUGQo = str(oNlez5gnM9x2B4.listdir(DigQM5q012Zkmx6SKBChlJz))
	DIt9jYXMdA0sUcf4RBW = AehPEBHmikb0MnWaDZwUGQo.count(pbmKZA1w7L4zHjOM(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+AehPEBHmikb0MnWaDZwUGQo.count(lRKCWnNi0Edr984eI(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	OeF5CiHPAUrk9TlYdjg = KKCrwPdOgGl(u"࡙ࠩࠣࠬࠬ")+O6vWXsY8rKZ7lDMkP21dQyR5S(VEaqjs1Gf6)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࠤ࠲࡚ࠦࠧ")+str(wj2ZlV05FraUiIgm34hsRXDTxMnu)+Zb5cNeHWi6jP9SCYtUgR(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	aenBI6927xL8SojFDwbuVNMCU4H = ba49YvOK2Aw8Uhxt(u"ࠬࠦࠨࠨ࡜")+O6vWXsY8rKZ7lDMkP21dQyR5S(DfEGljexbIqhc2MJaYSvXWpR8tZ)+Zb5cNeHWi6jP9SCYtUgR(u"࠭ࠠ࠮ࠢࠪ࡝")+str(mazQC0Hj1DJ9BnfsOqu8rh)+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	XXB5x24zvVyJpTIYQnmSE0WFkiC = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࠢࠫࠫ࡟")+O6vWXsY8rKZ7lDMkP21dQyR5S(Udxg4nAMtw6Q)+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(LsmVYNDyhSOoZtebQR40fAXaMJpG7j)+B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	MMcdLWoFbyTej8xm6Qf9C1vhS43wP = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࠥ࠮ࠧࡢ")+O6vWXsY8rKZ7lDMkP21dQyR5S(yLFDfh6YORE4Bpx3PnTgizjXk)+GTmHXIZUSdxRhMnqQKkO(u"ࠬ࠯ࠧࡣ")
	qeIPnair6jYpMNtvdUz8Q0hLoJ = hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࠠࠩࠩࡤ")+str(DIt9jYXMdA0sUcf4RBW)+GTmHXIZUSdxRhMnqQKkO(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	JXvFnjekVOpQCq6MWxRcGfN = VEaqjs1Gf6+DfEGljexbIqhc2MJaYSvXWpR8tZ+Udxg4nAMtw6Q+yLFDfh6YORE4Bpx3PnTgizjXk
	Y5YTsXIKBLG0yv1WRupn3o7ia = wj2ZlV05FraUiIgm34hsRXDTxMnu+mazQC0Hj1DJ9BnfsOqu8rh+LsmVYNDyhSOoZtebQR40fAXaMJpG7j+DDzFgpl0MahHE91CxXjku+DIt9jYXMdA0sUcf4RBW
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = lRKCWnNi0Edr984eI(u"ࠨࠢࠫࠫࡦ")+O6vWXsY8rKZ7lDMkP21dQyR5S(JXvFnjekVOpQCq6MWxRcGfN)+CCWqR3dmtzw6xoIX41(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(Y5YTsXIKBLG0yv1WRupn3o7ia)+lRKCWnNi0Edr984eI(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	w3BfOGLdXcWzbiC1PYx9mE(hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),qBAgzkG9oCL+jBbkfIJSDqcVwl8irzy4Z3O(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pYeVwat64v(u"࠹࠷࠹ࣳ"))
	w3BfOGLdXcWzbiC1PYx9mE(nR0ok9zju84rFUQl1YC(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),qFghPAi5yz9Vf3NLwo0nuprl+I6Bfzysrvb8DONZ(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,f9fOpCmLAEaW2Go(u"࠼࠽࠾࠿ࣴ"))
	w3BfOGLdXcWzbiC1PYx9mE(KKCrwPdOgGl(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),qBAgzkG9oCL+slQajGY35wNHvXoVSrUC6AEPWyqhp(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+OeF5CiHPAUrk9TlYdjg,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKCrwPdOgGl(u"࠻࠹࠷ࣵ"))
	w3BfOGLdXcWzbiC1PYx9mE(kAz7WRYjrfGm(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),qBAgzkG9oCL+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+aenBI6927xL8SojFDwbuVNMCU4H,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠼࠺࠲ࣶ"))
	w3BfOGLdXcWzbiC1PYx9mE(KKCrwPdOgGl(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),qBAgzkG9oCL+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+XXB5x24zvVyJpTIYQnmSE0WFkiC,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,YzlId3Fs6vpehcbLGj0UaO(u"࠽࠴࠴ࣷ"))
	w3BfOGLdXcWzbiC1PYx9mE(YzlId3Fs6vpehcbLGj0UaO(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),qBAgzkG9oCL+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠷࠵࠶ࣸ"))
	w3BfOGLdXcWzbiC1PYx9mE(nR0ok9zju84rFUQl1YC(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),qBAgzkG9oCL+KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+qeIPnair6jYpMNtvdUz8Q0hLoJ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,hWRvZOYtjme9QNnV41u0Mswb(u"࠸࠶࠹ࣹ"))
	return
def kAhYftdKVHnbszCFGTqLw6ur5yQ():
	fmz1HKUXbalc = NFGqKBLtvUZn1S3dau if fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫ࠴࠭ࡷ") in nYqRaDM7QlmrEUKSAevsC else pLwgjkuTs6CS
	if not fmz1HKUXbalc:
		w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,pYeVwat64v(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	zzpKCYP0jIqRFVXgoJtZaBWkThGr3c = xeI7QzBgGEXN8ftCawRpO24nDh.getSetting(f9fOpCmLAEaW2Go(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not zzpKCYP0jIqRFVXgoJtZaBWkThGr3c: xFCzpUOSc0yeKBuYZjvHLqt9gW1()
	VEaqjs1Gf6,wj2ZlV05FraUiIgm34hsRXDTxMnu = VPDIE5e8Cxg(Di7ZW0pBKgNAJl6qF5IHho1TEO)
	DfEGljexbIqhc2MJaYSvXWpR8tZ,mazQC0Hj1DJ9BnfsOqu8rh = VPDIE5e8Cxg(o0ES17VX3PmUbil)
	Udxg4nAMtw6Q,LsmVYNDyhSOoZtebQR40fAXaMJpG7j = VPDIE5e8Cxg(sxoUnA3GebqB57iOCuJM)
	yLFDfh6YORE4Bpx3PnTgizjXk,DDzFgpl0MahHE91CxXjku = VPDIE5e8Cxg(ldpbRFsG36)
	UUDVswGC8khZPgfl7mYOcM,DIt9jYXMdA0sUcf4RBW = VPDIE5e8Cxg(fvA8KsBJnERLc9TdPe2Fu4YNDV)
	a3aFx0EZ2KX18TGBkMAdeP,IcM9BYkhpCVWKisux = VPDIE5e8Cxg(QO1NgWhSlmGAT93zwknyPIdt)
	OeF5CiHPAUrk9TlYdjg = rAYDiWlzm9MCU6x0GnROua(u"ࠧࠡࠪࠪࡺ")+O6vWXsY8rKZ7lDMkP21dQyR5S(VEaqjs1Gf6)+w9wfONXUP3(u"ࠨࠢ࠰ࠤࠬࡻ")+str(wj2ZlV05FraUiIgm34hsRXDTxMnu)+pL73X0MYajJQG4n1qgD(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	aenBI6927xL8SojFDwbuVNMCU4H = KKCrwPdOgGl(u"ࠪࠤ࠭࠭ࡽ")+O6vWXsY8rKZ7lDMkP21dQyR5S(DfEGljexbIqhc2MJaYSvXWpR8tZ)+pL73X0MYajJQG4n1qgD(u"ࠫࠥ࠳ࠠࠨࡾ")+str(mazQC0Hj1DJ9BnfsOqu8rh)+ba49YvOK2Aw8Uhxt(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	XXB5x24zvVyJpTIYQnmSE0WFkiC = KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࠠࠩࠩࢀ")+O6vWXsY8rKZ7lDMkP21dQyR5S(Udxg4nAMtw6Q)+nR0ok9zju84rFUQl1YC(u"ࠧࠡ࠯ࠣࠫࢁ")+str(LsmVYNDyhSOoZtebQR40fAXaMJpG7j)+GTmHXIZUSdxRhMnqQKkO(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	MMcdLWoFbyTej8xm6Qf9C1vhS43wP = YzlId3Fs6vpehcbLGj0UaO(u"ࠩࠣࠬࠬࢃ")+O6vWXsY8rKZ7lDMkP21dQyR5S(yLFDfh6YORE4Bpx3PnTgizjXk)+vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠪࠤ࠲ࠦࠧࢄ")+str(DDzFgpl0MahHE91CxXjku)+awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	qeIPnair6jYpMNtvdUz8Q0hLoJ = W2Vv30i8qxSuItfsolPLdFZA(u"ࠬࠦࠨࠨࢆ")+O6vWXsY8rKZ7lDMkP21dQyR5S(UUDVswGC8khZPgfl7mYOcM)+I6Bfzysrvb8DONZ(u"࠭ࠠ࠮ࠢࠪࢇ")+str(DIt9jYXMdA0sUcf4RBW)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	qs5hYZ8nRDNiHrjU9gOzJKbeMPy4lf = f9fOpCmLAEaW2Go(u"ࠨࠢࠫࠫࢉ")+O6vWXsY8rKZ7lDMkP21dQyR5S(a3aFx0EZ2KX18TGBkMAdeP)+fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(IcM9BYkhpCVWKisux)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	JXvFnjekVOpQCq6MWxRcGfN = VEaqjs1Gf6+DfEGljexbIqhc2MJaYSvXWpR8tZ+Udxg4nAMtw6Q+yLFDfh6YORE4Bpx3PnTgizjXk+UUDVswGC8khZPgfl7mYOcM+a3aFx0EZ2KX18TGBkMAdeP
	Y5YTsXIKBLG0yv1WRupn3o7ia = wj2ZlV05FraUiIgm34hsRXDTxMnu+mazQC0Hj1DJ9BnfsOqu8rh+LsmVYNDyhSOoZtebQR40fAXaMJpG7j+DDzFgpl0MahHE91CxXjku+DIt9jYXMdA0sUcf4RBW+IcM9BYkhpCVWKisux
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫࠥ࠮ࠧࢌ")+O6vWXsY8rKZ7lDMkP21dQyR5S(JXvFnjekVOpQCq6MWxRcGfN)+jBbkfIJSDqcVwl8irzy4Z3O(u"ࠬࠦ࠭ࠡࠩࢍ")+str(Y5YTsXIKBLG0yv1WRupn3o7ia)+jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	w3BfOGLdXcWzbiC1PYx9mE(ba49YvOK2Aw8Uhxt(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),qBAgzkG9oCL+GTmHXIZUSdxRhMnqQKkO(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,vl6rwMLasAQo4z1ZjD3IBKtF(u"࠹࠸࠼ࣺ"))
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),qBAgzkG9oCL+Zb5cNeHWi6jP9SCYtUgR(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+ggM5TzCxq24sDYLiEatpdSK7FQyGe,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠺࠹࠼ࣻ"))
	w3BfOGLdXcWzbiC1PYx9mE(f9fOpCmLAEaW2Go(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),qFghPAi5yz9Vf3NLwo0nuprl+YzlId3Fs6vpehcbLGj0UaO(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠽࠾࠿࠹ࣼ"))
	w3BfOGLdXcWzbiC1PYx9mE(fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),qBAgzkG9oCL+w9wfONXUP3(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+OeF5CiHPAUrk9TlYdjg,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠼࠻࠱ࣽ"))
	w3BfOGLdXcWzbiC1PYx9mE(w9wfONXUP3(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),qBAgzkG9oCL+KKCrwPdOgGl(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+aenBI6927xL8SojFDwbuVNMCU4H,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,kAz7WRYjrfGm(u"࠽࠵࠳ࣾ"))
	w3BfOGLdXcWzbiC1PYx9mE(jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),qBAgzkG9oCL+lRKCWnNi0Edr984eI(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+XXB5x24zvVyJpTIYQnmSE0WFkiC,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,w9wfONXUP3(u"࠷࠶࠵ࣿ"))
	w3BfOGLdXcWzbiC1PYx9mE(zWBnYSGIatjXVC(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),qBAgzkG9oCL+awSUTRNMkdIW7sFEvnHD2mLY(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+MMcdLWoFbyTej8xm6Qf9C1vhS43wP,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,KKCrwPdOgGl(u"࠸࠷࠷ऀ"))
	w3BfOGLdXcWzbiC1PYx9mE(vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),qBAgzkG9oCL+zWBnYSGIatjXVC(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+qeIPnair6jYpMNtvdUz8Q0hLoJ,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,jBbkfIJSDqcVwl8irzy4Z3O(u"࠹࠸࠹ँ"))
	w3BfOGLdXcWzbiC1PYx9mE(Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),qBAgzkG9oCL+pbmKZA1w7L4zHjOM(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+qs5hYZ8nRDNiHrjU9gOzJKbeMPy4lf,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,pbmKZA1w7L4zHjOM(u"࠺࠹࠻ं"))
	return
def C9Lgl8i30JFoW5fIbmsU71(showDialogs):
	if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	AYWckw1pefUqN5MVCab3I80n7j2v9,ILEf0hDB7T3MaUusmwlrCGKONovn = [],nUaVQsoA6EXcK4Odht5wCge0J8Pib
	for MNAzTb6RpslQZm,oGRUM2XV6yix9,J7RuYHvT3htcQK2fWFpzg in oNlez5gnM9x2B4.walk(jaVSoQGFYUlCugWK9kLc,topdown=pLwgjkuTs6CS):
		gfK04PiCWju6pdSmZhI = len(J7RuYHvT3htcQK2fWFpzg)
		if gfK04PiCWju6pdSmZhI>rAYDiWlzm9MCU6x0GnROua(u"࠹࠵࠶ः"): AYWckw1pefUqN5MVCab3I80n7j2v9.append(oGRUM2XV6yix9)
		ILEf0hDB7T3MaUusmwlrCGKONovn += gfK04PiCWju6pdSmZhI
	UUpaVkg8Q1CfAJx2zEcr = ILEf0hDB7T3MaUusmwlrCGKONovn>Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = qFghPAi5yz9Vf3NLwo0nuprl+KKCrwPdOgGl(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(ILEf0hDB7T3MaUusmwlrCGKONovn)+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+so4Z8OUJ5E
		if not AYWckw1pefUqN5MVCab3I80n7j2v9 and not UUpaVkg8Q1CfAJx2zEcr: e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: e6f0ycMuYQEJraNLInmip = xD9WeoEAsX7
	if e6f0ycMuYQEJraNLInmip==xD9WeoEAsX7:
		if UUpaVkg8Q1CfAJx2zEcr: RRAoUt0ihbYj(MNAzTb6RpslQZm,pLwgjkuTs6CS,pLwgjkuTs6CS)
		elif AYWckw1pefUqN5MVCab3I80n7j2v9:
			for oGRUM2XV6yix9 in AYWckw1pefUqN5MVCab3I80n7j2v9: RRAoUt0ihbYj(oGRUM2XV6yix9,pLwgjkuTs6CS,pLwgjkuTs6CS)
	return
def xFCzpUOSc0yeKBuYZjvHLqt9gW1():
	vNufqGIEFj9c4MaQlkKTdLD = pLwgjkuTs6CS
	e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if e6f0ycMuYQEJraNLInmip==-bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠷अ"): return
	if e6f0ycMuYQEJraNLInmip:
		import subprocess as oosjxt8yqQ1
		try:
			oosjxt8yqQ1.Popen(zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠪࡷࡺ࠭ࢧ"))
			vNufqGIEFj9c4MaQlkKTdLD = NFGqKBLtvUZn1S3dau
		except: pass
		if vNufqGIEFj9c4MaQlkKTdLD:
			jj8t9iFkx1LPJV3qH65 = Di7ZW0pBKgNAJl6qF5IHho1TEO+WRsuxHTjDgYCIpoMQzLFAtS8rikP+o0ES17VX3PmUbil+WRsuxHTjDgYCIpoMQzLFAtS8rikP+sxoUnA3GebqB57iOCuJM+WRsuxHTjDgYCIpoMQzLFAtS8rikP+ldpbRFsG36+WRsuxHTjDgYCIpoMQzLFAtS8rikP+fvA8KsBJnERLc9TdPe2Fu4YNDV+WRsuxHTjDgYCIpoMQzLFAtS8rikP+QO1NgWhSlmGAT93zwknyPIdt
			vHxUO75kNufzEWr = oosjxt8yqQ1.Popen(slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+jj8t9iFkx1LPJV3qH65+kAz7WRYjrfGm(u"ࠬࠨࠧࢩ"),shell=NFGqKBLtvUZn1S3dau,stdin=oosjxt8yqQ1.PIPE,stdout=oosjxt8yqQ1.PIPE,stderr=oosjxt8yqQ1.PIPE)
			w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return vNufqGIEFj9c4MaQlkKTdLD
def O6vWXsY8rKZ7lDMkP21dQyR5S(JXvFnjekVOpQCq6MWxRcGfN):
	for pJIMwPmtxzhH in [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡄࠪࢬ"),nR0ok9zju84rFUQl1YC(u"ࠩࡎࡆࠬࢭ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡑࡇ࠭ࢮ"),f9fOpCmLAEaW2Go(u"ࠫࡌࡈࠧࢯ"),pYeVwat64v(u"࡚ࠬࡂࠨࢰ")]:
		if JXvFnjekVOpQCq6MWxRcGfN<fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"࠱࠱࠴࠷आ"): break
		else: JXvFnjekVOpQCq6MWxRcGfN /= W2Vv30i8qxSuItfsolPLdFZA(u"࠲࠲࠵࠸࠳࠶इ")
	ggM5TzCxq24sDYLiEatpdSK7FQyGe = djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(JXvFnjekVOpQCq6MWxRcGfN,pJIMwPmtxzhH)
	return ggM5TzCxq24sDYLiEatpdSK7FQyGe
def VPDIE5e8Cxg(vfroZ7dCRmJtSlYbI=KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠧ࠯ࠩࢲ")):
	global hR25NB7LGl4xKoSf,rluitJnB2XDTKQqe1pdcFUCjhLHx
	hR25NB7LGl4xKoSf,rluitJnB2XDTKQqe1pdcFUCjhLHx = nUaVQsoA6EXcK4Odht5wCge0J8Pib,nUaVQsoA6EXcK4Odht5wCge0J8Pib
	def AF8s6t3rKhSunWmb(vfroZ7dCRmJtSlYbI):
		global hR25NB7LGl4xKoSf,rluitJnB2XDTKQqe1pdcFUCjhLHx
		if oNlez5gnM9x2B4.path.exists(vfroZ7dCRmJtSlYbI):
			if nUaVQsoA6EXcK4Odht5wCge0J8Pib and rAYDiWlzm9MCU6x0GnROua(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(oNlez5gnM9x2B4):
				for Slvs01QUa6DBpI in oNlez5gnM9x2B4.scandir(vfroZ7dCRmJtSlYbI):
					if Slvs01QUa6DBpI.is_dir(follow_symlinks=pLwgjkuTs6CS):
						AF8s6t3rKhSunWmb(Slvs01QUa6DBpI.path)
					elif Slvs01QUa6DBpI.is_file(follow_symlinks=pLwgjkuTs6CS):
						hR25NB7LGl4xKoSf += Slvs01QUa6DBpI.stat().st_size
						rluitJnB2XDTKQqe1pdcFUCjhLHx += xD9WeoEAsX7
			else:
				for Slvs01QUa6DBpI in oNlez5gnM9x2B4.listdir(vfroZ7dCRmJtSlYbI):
					JF29TqyMCBfuYzSvZ0waQLbDdRU = oNlez5gnM9x2B4.path.abspath(oNlez5gnM9x2B4.path.join(vfroZ7dCRmJtSlYbI,Slvs01QUa6DBpI))
					if oNlez5gnM9x2B4.path.isdir(JF29TqyMCBfuYzSvZ0waQLbDdRU):
						AF8s6t3rKhSunWmb(JF29TqyMCBfuYzSvZ0waQLbDdRU)
					elif oNlez5gnM9x2B4.path.isfile(JF29TqyMCBfuYzSvZ0waQLbDdRU):
						JXvFnjekVOpQCq6MWxRcGfN,Y5YTsXIKBLG0yv1WRupn3o7ia = yxjuaUT04zJF(JF29TqyMCBfuYzSvZ0waQLbDdRU)
						hR25NB7LGl4xKoSf += JXvFnjekVOpQCq6MWxRcGfN
						rluitJnB2XDTKQqe1pdcFUCjhLHx += Y5YTsXIKBLG0yv1WRupn3o7ia
		return
	try: AF8s6t3rKhSunWmb(vfroZ7dCRmJtSlYbI)
	except: pass
	return hR25NB7LGl4xKoSf,rluitJnB2XDTKQqe1pdcFUCjhLHx
def OBoSgfmdHUvbJik(showDialogs):
	if showDialogs:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,qFghPAi5yz9Vf3NLwo0nuprl+zqKXfFe36rVoin9YA18Z20CxI4Lth(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+b8sk5WyPoz03pXhRx+MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+b8sk5WyPoz03pXhRx+pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫฤࠧࠡࠨࢶ")+so4Z8OUJ5E)
		if e6f0ycMuYQEJraNLInmip!=xD9WeoEAsX7: return
	lWTehJZkcwH39C8V1rSiMDxqoGI = RRAoUt0ihbYj(e1cvdDOxnQ9h70ouMfIZy,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
	Db0yJEf59xVT = RRAoUt0ihbYj(rGcINgtFy7DkEwYjbC3OfTRx4oZhJ,NFGqKBLtvUZn1S3dau,pLwgjkuTs6CS)
	C0CFNlwTcJfaIQ6KWoXtbEB8pA = RRAoUt0ihbYj(nFhRa45167DylfIKwkvPcjH0X,pLwgjkuTs6CS,pLwgjkuTs6CS)
	XK4EI9BFwdR0YGt5sicHW3Q = YN82kmwonH4JtAX7ylqQ9OWUVSeK(pLwgjkuTs6CS)
	sWg8NZyBnq3LcawQe2E0KCdX = oD9g3fpkYzN6c(pLwgjkuTs6CS)
	succeeded = all([lWTehJZkcwH39C8V1rSiMDxqoGI,Db0yJEf59xVT,C0CFNlwTcJfaIQ6KWoXtbEB8pA,XK4EI9BFwdR0YGt5sicHW3Q,sWg8NZyBnq3LcawQe2E0KCdX])
	if showDialogs:
		if succeeded: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,B1YMtuvRAGNlJOkC46VyPKQE(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def JAFc8KZw4XpP73oOLi9jedzEHla(showDialogs):
	if showDialogs:
		jj8t9iFkx1LPJV3qH65 = Di7ZW0pBKgNAJl6qF5IHho1TEO+b8sk5WyPoz03pXhRx+o0ES17VX3PmUbil+b8sk5WyPoz03pXhRx+sxoUnA3GebqB57iOCuJM+b8sk5WyPoz03pXhRx+ldpbRFsG36+b8sk5WyPoz03pXhRx+fvA8KsBJnERLc9TdPe2Fu4YNDV+b8sk5WyPoz03pXhRx+QO1NgWhSlmGAT93zwknyPIdt
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,qFghPAi5yz9Vf3NLwo0nuprl+lRKCWnNi0Edr984eI(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+jj8t9iFkx1LPJV3qH65+so4Z8OUJ5E)
		if e6f0ycMuYQEJraNLInmip!=xD9WeoEAsX7: return
	lWTehJZkcwH39C8V1rSiMDxqoGI = RRAoUt0ihbYj(Di7ZW0pBKgNAJl6qF5IHho1TEO,pLwgjkuTs6CS,pLwgjkuTs6CS)
	Db0yJEf59xVT = RRAoUt0ihbYj(o0ES17VX3PmUbil,pLwgjkuTs6CS,pLwgjkuTs6CS)
	C0CFNlwTcJfaIQ6KWoXtbEB8pA = RRAoUt0ihbYj(sxoUnA3GebqB57iOCuJM,pLwgjkuTs6CS,pLwgjkuTs6CS)
	XK4EI9BFwdR0YGt5sicHW3Q = RRAoUt0ihbYj(ldpbRFsG36,pLwgjkuTs6CS,pLwgjkuTs6CS)
	sWg8NZyBnq3LcawQe2E0KCdX = RRAoUt0ihbYj(fvA8KsBJnERLc9TdPe2Fu4YNDV,pLwgjkuTs6CS,pLwgjkuTs6CS)
	sD9oHSa3TfWeIrE28dUOyuzj4 = RRAoUt0ihbYj(QO1NgWhSlmGAT93zwknyPIdt,pLwgjkuTs6CS,pLwgjkuTs6CS)
	succeeded = all([lWTehJZkcwH39C8V1rSiMDxqoGI,Db0yJEf59xVT,C0CFNlwTcJfaIQ6KWoXtbEB8pA,XK4EI9BFwdR0YGt5sicHW3Q,sWg8NZyBnq3LcawQe2E0KCdX,sD9oHSa3TfWeIrE28dUOyuzj4])
	if showDialogs:
		if succeeded: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,W2Vv30i8qxSuItfsolPLdFZA(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,rAYDiWlzm9MCU6x0GnROua(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def YN82kmwonH4JtAX7ylqQ9OWUVSeK(showDialogs):
	if showDialogs:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,qFghPAi5yz9Vf3NLwo0nuprl+Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+so4Z8OUJ5E)
		if e6f0ycMuYQEJraNLInmip!=ba49YvOK2Aw8Uhxt(u"࠳ई"): return pbmKZA1w7L4zHjOM(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = lRKCWnNi0Edr984eI(u"ࡘࡷࡻࡥऊ")
		BlzEMV9YmO = nhGFNAkSgW2qopEYeT9jz8ULatl.connect(HJa8EMWF75SyD9)
		BlzEMV9YmO.text_factory = str
		Ew0cWnQIKTvoZDX = BlzEMV9YmO.cursor()
		Ew0cWnQIKTvoZDX.execute(awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		Ew0cWnQIKTvoZDX.execute(rAYDiWlzm9MCU6x0GnROua(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		Ew0cWnQIKTvoZDX.execute(CCWqR3dmtzw6xoIX41(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		BlzEMV9YmO.commit()
		Ew0cWnQIKTvoZDX.execute(rAYDiWlzm9MCU6x0GnROua(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		BlzEMV9YmO.close()
	except: succeeded = djapWhrveLJbgnViDftFNY05ylq1S(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,zWBnYSGIatjXVC(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def oD9g3fpkYzN6c(showDialogs):
	if showDialogs:
		e6f0ycMuYQEJraNLInmip = hhTcd5XlykBUu68zAb9OmgC(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+b8sk5WyPoz03pXhRx+b8sk5WyPoz03pXhRx+qFghPAi5yz9Vf3NLwo0nuprl+kAz7WRYjrfGm(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+so4Z8OUJ5E)
		if e6f0ycMuYQEJraNLInmip!=xD9WeoEAsX7: return Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = vl6rwMLasAQo4z1ZjD3IBKtF(u"ࡔࡳࡷࡨऍ")
	for file in oNlez5gnM9x2B4.listdir(DigQM5q012Zkmx6SKBChlJz):
		if djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and awSUTRNMkdIW7sFEvnHD2mLY(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		dBTRVl43X5Kvu0b = oNlez5gnM9x2B4.path.join(DigQM5q012Zkmx6SKBChlJz,file)
		try: oNlez5gnM9x2B4.remove(dBTRVl43X5Kvu0b)
		except Exception as yHOSQbjvhko0wrMxdpg:
			succeeded = JZ45mOctiTszPNw1GVjxhep2Y(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,str(yHOSQbjvhko0wrMxdpg))
	if showDialogs:
		if succeeded: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,KKCrwPdOgGl(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: w4dBvakygFs2IZO1Azt(VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,F91YEzyWak5,rAYDiWlzm9MCU6x0GnROua(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded