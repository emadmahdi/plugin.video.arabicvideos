# -*- coding: utf-8 -*-
import sys as qv7XKecsSGz6rBTpt
BBcvUrluk3wDm4OpQ6PL2jh8f = qv7XKecsSGz6rBTpt.version_info [0] == 2
vo2dhAzDWVbBNEajQ8 = 2048
szu9wfcQV5beMKr6 = 7
def l1eDZPng0fCpxRzrwEFQijsOk2qtd (KoHJwj1q3P69rOTx47EdXvftmlbMne):
	global jdaEvDueZ7FowQUk0X8ctfpR6
	JWv9nqNkmUEg3CG5jDs1xi7FhbL6 = ord (KoHJwj1q3P69rOTx47EdXvftmlbMne [-1])
	m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 = KoHJwj1q3P69rOTx47EdXvftmlbMne [:-1]
	bIE7qn0ty2kF1Rg = JWv9nqNkmUEg3CG5jDs1xi7FhbL6 % len (m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2)
	vv2NHBUFEabnc1 = m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [:bIE7qn0ty2kF1Rg] + m3qhRSZ5gKsXp8xnFfAaBvEl9izyI2 [bIE7qn0ty2kF1Rg:]
	if BBcvUrluk3wDm4OpQ6PL2jh8f:
		EKAtCj14R6pJFOB = unicode () .join ([unichr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	else:
		EKAtCj14R6pJFOB = str () .join ([chr (ord (Ooi85x4dSZfLc) - vo2dhAzDWVbBNEajQ8 - (UXJqM4yznx1lefVvN6rO + JWv9nqNkmUEg3CG5jDs1xi7FhbL6) % szu9wfcQV5beMKr6) for UXJqM4yznx1lefVvN6rO, Ooi85x4dSZfLc in enumerate (vv2NHBUFEabnc1)])
	return eval (EKAtCj14R6pJFOB)
I6Bfzysrvb8DONZ,pL73X0MYajJQG4n1qgD,Zb5cNeHWi6jP9SCYtUgR=l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd,l1eDZPng0fCpxRzrwEFQijsOk2qtd
bb3AWcQ4gsKekujJxH92aTY8yBPhtz,nR0ok9zju84rFUQl1YC,pYeVwat64v=Zb5cNeHWi6jP9SCYtUgR,pL73X0MYajJQG4n1qgD,I6Bfzysrvb8DONZ
slQajGY35wNHvXoVSrUC6AEPWyqhp,djapWhrveLJbgnViDftFNY05ylq1S,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH=pYeVwat64v,nR0ok9zju84rFUQl1YC,bb3AWcQ4gsKekujJxH92aTY8yBPhtz
hWRvZOYtjme9QNnV41u0Mswb,zqKXfFe36rVoin9YA18Z20CxI4Lth,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn=Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH,djapWhrveLJbgnViDftFNY05ylq1S,slQajGY35wNHvXoVSrUC6AEPWyqhp
vl6rwMLasAQo4z1ZjD3IBKtF,YzlId3Fs6vpehcbLGj0UaO,KKCrwPdOgGl=fYkuxG1JSTrHdLQB9RDOah0Xs7Pn,zqKXfFe36rVoin9YA18Z20CxI4Lth,hWRvZOYtjme9QNnV41u0Mswb
ba49YvOK2Aw8Uhxt,awSUTRNMkdIW7sFEvnHD2mLY,rAYDiWlzm9MCU6x0GnROua=KKCrwPdOgGl,YzlId3Fs6vpehcbLGj0UaO,vl6rwMLasAQo4z1ZjD3IBKtF
pm6C9fzIWAKyeiOPqZkGV073Fwc2d,zWBnYSGIatjXVC,lRKCWnNi0Edr984eI=rAYDiWlzm9MCU6x0GnROua,awSUTRNMkdIW7sFEvnHD2mLY,ba49YvOK2Aw8Uhxt
B1YMtuvRAGNlJOkC46VyPKQE,w9wfONXUP3,GTmHXIZUSdxRhMnqQKkO=lRKCWnNi0Edr984eI,zWBnYSGIatjXVC,pm6C9fzIWAKyeiOPqZkGV073Fwc2d
jBbkfIJSDqcVwl8irzy4Z3O,f9fOpCmLAEaW2Go,kAz7WRYjrfGm=GTmHXIZUSdxRhMnqQKkO,w9wfONXUP3,B1YMtuvRAGNlJOkC46VyPKQE
KKd3lxRqZIbCVAtorHYSvnjF7Q089,pbmKZA1w7L4zHjOM,W2Vv30i8qxSuItfsolPLdFZA=kAz7WRYjrfGm,f9fOpCmLAEaW2Go,jBbkfIJSDqcVwl8irzy4Z3O
MLe2aPIuhtK5UrAWQE7pq4FGwdDzs,JZ45mOctiTszPNw1GVjxhep2Y,CCWqR3dmtzw6xoIX41=W2Vv30i8qxSuItfsolPLdFZA,pbmKZA1w7L4zHjOM,KKd3lxRqZIbCVAtorHYSvnjF7Q089
from auPRixSgLw import *
SITESURLS = {
			 f9fOpCmLAEaW2Go(u"ࠪࡅࡍ࡝ࡁࡌࠩಬ")		:[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ಭ")]
			,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬࡇࡋࡐࡃࡐࠫಮ")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪಯ")]
			,hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡂࡍ࡚ࡅࡒ࠭ರ")		:[djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨಱ")]
			,hWRvZOYtjme9QNnV41u0Mswb(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬಲ")	:[Zb5cNeHWi6jP9SCYtUgR(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢ࡭ࡺࡥࡲ࠴ࡴࡶࡤࡨࠫಳ")]
			,hWRvZOYtjme9QNnV41u0Mswb(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭಴")		:[rAYDiWlzm9MCU6x0GnROua(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫವ")]
			,jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧಶ")		:[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩಷ")]
			,KKCrwPdOgGl(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪಸ")		:[zWBnYSGIatjXVC(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪಹ")]
			,pL73X0MYajJQG4n1qgD(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ಺")	:[GTmHXIZUSdxRhMnqQKkO(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫ಻")]
			,CCWqR3dmtzw6xoIX41(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ಼ࠧ")		:[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭ಽ")]
			,GTmHXIZUSdxRhMnqQKkO(u"ࠧࡂ࡛ࡏࡓࡑ࠭ಾ")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨಿ")]
			,zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩࡅࡓࡐࡘࡁࠨೀ")		:[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧࡰ࡮ࡼࡥ࠯ࡥࡲࠫು")]
			,KKCrwPdOgGl(u"ࠫࡇࡘࡓࡕࡇࡍࠫೂ")		:[lRKCWnNi0Edr984eI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪೃ")]
			,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧೄ")		:[f9fOpCmLAEaW2Go(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭೅")]
			,Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨೆ")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠳ࡩࡩ࡮ࡣ࠷ࡴ࠳ࡩ࡯࡮ࠩೇ")]
			,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪೈ")		:[vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪ೉")]
			,KKCrwPdOgGl(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧೊ")		:[hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡯࠱ࡧ࡮ࡳࡡ࠴ࡤࡧࡳ࠳ࡩ࡯࡮ࠩೋ")]
			,lRKCWnNi0Edr984eI(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩೌ")		:[CCWqR3dmtzw6xoIX41(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡩ࡬ࡶࡤ್ࠪ")]
			,f9fOpCmLAEaW2Go(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ೎")	:[GTmHXIZUSdxRhMnqQKkO(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨ೏")]
			,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭೐")		:[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯ࠨ೑")]
			,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨ೒")		:[fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳ࡴࡷ࠰ࡦࡳࡲ࠭೓")]
			,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ೔")	:[jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨೕ")]
			,pbmKZA1w7L4zHjOM(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫೖ")		:[MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ೗")]
			,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ೘")		:[pbmKZA1w7L4zHjOM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪ೙")]
			,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ೚")	:[GTmHXIZUSdxRhMnqQKkO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ೛"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ೜"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ೝ")]
			,pbmKZA1w7L4zHjOM(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧೞ")	:[W2Vv30i8qxSuItfsolPLdFZA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠷࠱ࡨࡷࡧ࡭ࡢࡥࡤࡪࡪ࠳ࡴࡷ࠰ࡦࡳࡲ࠭೟")]
			,W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧೠ")		:[I6Bfzysrvb8DONZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵࡥࡲࡧࡳ࠸࠰ࡱࡩࡹ࠭ೡ")]
			,rAYDiWlzm9MCU6x0GnROua(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪೢ")		:[KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡫ࡻ࡮ࠨೣ")]
			,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ೤")		:[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡹࡶࠫ೥")]
			,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ೦")		:[JZ45mOctiTszPNw1GVjxhep2Y(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭೧")]
			,rAYDiWlzm9MCU6x0GnROua(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ೨")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨ೩")]
			,pbmKZA1w7L4zHjOM(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ೪")		:[ba49YvOK2Aw8Uhxt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪ೫")]
			,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭೬")		:[w9wfONXUP3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬ೭")]
			,YzlId3Fs6vpehcbLGj0UaO(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩ೮")	:[hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠯ࡧ࡯࡭࡫࠴࡮ࡦࡹࡶࠫ೯")]
			,kAz7WRYjrfGm(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ೰")		:[W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧೱ")]
			,rAYDiWlzm9MCU6x0GnROua(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ೲ")	:[GTmHXIZUSdxRhMnqQKkO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩೳ")]
			,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭೴")		:[rAYDiWlzm9MCU6x0GnROua(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡳ࠲࡫ࡧࡲࡦࡵ࡮ࡳ࠳ࡴࡥࡵࠩ೵")]
			,pbmKZA1w7L4zHjOM(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ೶")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧ೷")]
			,fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠩࡉࡓࡘ࡚ࡁࠨ೸")		:[f9fOpCmLAEaW2Go(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧ೹")]
			,vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬ೺")		:[Zb5cNeHWi6jP9SCYtUgR(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧ࠯ࡣ࡯ࡱࡪࡹࡨ࡬ࡣ࡫࠲ࡳ࡫ࡴࠨ೻")]
			,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨ೼")		:[hWRvZOYtjme9QNnV41u0Mswb(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤ࠱ࡪࡺࡹࡨࡢࡴ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ೽")]
			,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭೾")	:[KKCrwPdOgGl(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳࡬ࡵࡴࡪࡤࡶ࠳ࡼࡩࡥࡧࡲࠫ೿")]
			,B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬഀ")		:[pL73X0MYajJQG4n1qgD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭ഁ")]
			,CCWqR3dmtzw6xoIX41(u"ࠬࡏࡆࡊࡎࡐࠫം")		:[KKCrwPdOgGl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧഃ"),KKCrwPdOgGl(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨഄ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩഅ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫആ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪഇ")]
			,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧഈ")	:[w9wfONXUP3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭ഉ")]
			,f9fOpCmLAEaW2Go(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨഊ")		:[Zb5cNeHWi6jP9SCYtUgR(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭࡬ࡸࡰࡵࡴ࠯ࡥࡤࡱࠬഋ")]
			,GTmHXIZUSdxRhMnqQKkO(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩഌ")		:[Zb5cNeHWi6jP9SCYtUgR(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡺ࠴࡫ࡪࡴࡰࡥࡱࡱ࠮ࡤࡱࡰࠫ഍")]
			,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪഎ")		:[pbmKZA1w7L4zHjOM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩഏ")]
			,pL73X0MYajJQG4n1qgD(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഐ")		:[W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭഑")]
			,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪഒ")	:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨഓ")]
			,KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡓࡅࡓࡋࡔࠨഔ")		:[KKCrwPdOgGl(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬക")]
			,ba49YvOK2Aw8Uhxt(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ഖ")		:[I6Bfzysrvb8DONZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ഗ")]
			,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪഘ")	:[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬങ")]
			,djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪച")		:[lRKCWnNi0Edr984eI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠰࠸ࡺ࠴࡭ࡺࠩഛ")]
			,f9fOpCmLAEaW2Go(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭ജ")	:[YzlId3Fs6vpehcbLGj0UaO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮ࡧࡱࡵࡹࡲ࠭ഝ")]
			,ba49YvOK2Aw8Uhxt(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩഞ")	:[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬട")]
			,ba49YvOK2Aw8Uhxt(u"ࠧࡔࡊࡒࡊࡍࡇࠧഠ")		:[bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬഡ")]
			,zWBnYSGIatjXVC(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫഢ")		:[slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪണ"),nR0ok9zju84rFUQl1YC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫത"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨഥ")]
			,nR0ok9zju84rFUQl1YC(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨദ")		:[nR0ok9zju84rFUQl1YC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡸ࡮࡯ࡰࡨࡱࡩࡹ࠴࡯࡯࡮࡬ࡲࡪ࠭ധ")]
			,hWRvZOYtjme9QNnV41u0Mswb(u"ࠨࡖࡌࡏࡆࡇࡔࠨന")		:[pL73X0MYajJQG4n1qgD(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧഩ")]
			,lRKCWnNi0Edr984eI(u"ࠪࡘ࡛ࡌࡕࡏࠩപ")		:[f9fOpCmLAEaW2Go(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩഫ")]
			,MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬബ")		:[pYeVwat64v(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ഭ")]
			,slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫമ")	:[I6Bfzysrvb8DONZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫയ")]
			,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪര")		:[pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡹ࡫ࡡ࡮ࠩറ")]
			,kAz7WRYjrfGm(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬല")		:[djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡡࡤࠩള")]
			,lRKCWnNi0Edr984eI(u"࡙࠭ࡂࡓࡒࡘࠬഴ")		:[YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬവ")]
			,rAYDiWlzm9MCU6x0GnROua(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩശ")		:[pYeVwat64v(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬഷ")]
			,YzlId3Fs6vpehcbLGj0UaO(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩസ")	:[GTmHXIZUSdxRhMnqQKkO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧഹ")]
			,KKCrwPdOgGl(u"ࠬࡏࡐࡕࡘࠪഺ")			:[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O]
			,GTmHXIZUSdxRhMnqQKkO(u"࠭ࡍ࠴ࡗ഻ࠪ")			:[VhaIfJdtZP1kiKbRq8nGvFo9juBp2O]
			,pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡓࡇࡓࡓࡘ഼࠭")		:[I6Bfzysrvb8DONZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨഽ"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ാ"),ba49YvOK2Aw8Uhxt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧി")]
			,bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠱ࠨീ")	:[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩു"),f9fOpCmLAEaW2Go(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧൂ"),zWBnYSGIatjXVC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨൃ")]
			,w9wfONXUP3(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠶ࠬൄ")	:[kAz7WRYjrfGm(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ൅"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬെ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭േ")]
			,GTmHXIZUSdxRhMnqQKkO(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠴ࠩൈ")	:[ba49YvOK2Aw8Uhxt(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ൉"),ba49YvOK2Aw8Uhxt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬൊ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ോ")]
			,f9fOpCmLAEaW2Go(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨൌ")	:[ba49YvOK2Aw8Uhxt(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭്ࠬ"),hWRvZOYtjme9QNnV41u0Mswb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡯ࡴࡪࡩࠨൎ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫ൏")]
			,Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡆࡊࡎࡈࡗࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭൐"):[kAz7WRYjrfGm(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶࠧ൑")]
			,Zb5cNeHWi6jP9SCYtUgR(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ൒")	:[zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ൓"),CCWqR3dmtzw6xoIX41(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩൔ")]
			}
if xD9WeoEAsX7:
	SITESURLS[awSUTRNMkdIW7sFEvnHD2mLY(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫൕ")]      = [pYeVwat64v(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧൖ"),nR0ok9zju84rFUQl1YC(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫൗ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ൘"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭൙"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭൚"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ൛"),GTmHXIZUSdxRhMnqQKkO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ൜"),CCWqR3dmtzw6xoIX41(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭൝"),djapWhrveLJbgnViDftFNY05ylq1S(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ൞"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬൟ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫൠ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡺࡩࡧࡩࡡࡤࡪࡨࠫൡ")]
	SITESURLS[Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨൢ")] = [CCWqR3dmtzw6xoIX41(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨൣ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ൤"),f9fOpCmLAEaW2Go(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ൥"),fYkuxG1JSTrHdLQB9RDOah0Xs7Pn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ൦"),pbmKZA1w7L4zHjOM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ൧"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ൨"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭൩"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ൪"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ൫"),pYeVwat64v(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭൬"),zWBnYSGIatjXVC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ൭"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬ൮")]
	SITESURLS[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠸ࠧ൯")] = [zWBnYSGIatjXVC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭൰"),pL73X0MYajJQG4n1qgD(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ൱"),rAYDiWlzm9MCU6x0GnROua(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൲"),KKCrwPdOgGl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ൳"),KKCrwPdOgGl(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ൴"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ൵"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ൶"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ൷"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭൸"),pYeVwat64v(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ൹"),lRKCWnNi0Edr984eI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪൺ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪൻ")]
	SITESURLS[vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭ർ")] = [CCWqR3dmtzw6xoIX41(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨൽ"),CCWqR3dmtzw6xoIX41(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬൾ"),nR0ok9zju84rFUQl1YC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫൿ"),lRKCWnNi0Edr984eI(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ඀"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧඁ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪං"),pL73X0MYajJQG4n1qgD(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ඃ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ඄"),kAz7WRYjrfGm(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨඅ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ආ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬඇ"),jBbkfIJSDqcVwl8irzy4Z3O(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬඈ")]
else:
	SITESURLS[pYeVwat64v(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧඉ")]      = [pYeVwat64v(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫඊ"),w9wfONXUP3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨඋ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧඌ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඍ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪඎ"),vl6rwMLasAQo4z1ZjD3IBKtF(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ඏ"),ba49YvOK2Aw8Uhxt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩඐ"),ba49YvOK2Aw8Uhxt(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪඑ"),I6Bfzysrvb8DONZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫඒ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩඓ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨඔ"),lRKCWnNi0Edr984eI(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨඕ")]
	SITESURLS[W2Vv30i8qxSuItfsolPLdFZA(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫඖ")] = [pbmKZA1w7L4zHjOM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ඗"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ඘"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭඙"),zWBnYSGIatjXVC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩක"),kAz7WRYjrfGm(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩඛ"),f9fOpCmLAEaW2Go(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬග"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨඝ"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩඞ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪඟ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨච"),f9fOpCmLAEaW2Go(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧඡ"),pL73X0MYajJQG4n1qgD(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧජ")]
	SITESURLS[JZ45mOctiTszPNw1GVjxhep2Y(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪඣ")] = [I6Bfzysrvb8DONZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩඤ"),pYeVwat64v(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ඥ"),ba49YvOK2Aw8Uhxt(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬඦ"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨට"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨඨ"),zqKXfFe36rVoin9YA18Z20CxI4Lth(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫඩ"),zWBnYSGIatjXVC(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧඪ"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨණ"),zWBnYSGIatjXVC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩඬ"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧත"),pL73X0MYajJQG4n1qgD(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ථ"),kAz7WRYjrfGm(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ද")]
	SITESURLS[w9wfONXUP3(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠴ࠩධ")] = [awSUTRNMkdIW7sFEvnHD2mLY(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨන"),slQajGY35wNHvXoVSrUC6AEPWyqhp(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ඲"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫඳ"),CCWqR3dmtzw6xoIX41(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧප"),KKCrwPdOgGl(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧඵ"),pYeVwat64v(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪබ"),f9fOpCmLAEaW2Go(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭භ"),w9wfONXUP3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧම"),KKCrwPdOgGl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨඹ"),YzlId3Fs6vpehcbLGj0UaO(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ය"),CCWqR3dmtzw6xoIX41(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬර"),JZ45mOctiTszPNw1GVjxhep2Y(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬ඼")]
api_python_actions = [bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬල"),CCWqR3dmtzw6xoIX41(u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬ඾"),B1YMtuvRAGNlJOkC46VyPKQE(u"ࠬࡋࡍࡂࡋࡏࡗࠬ඿"),rAYDiWlzm9MCU6x0GnROua(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨව"),w9wfONXUP3(u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩශ"),pL73X0MYajJQG4n1qgD(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫෂ"),KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧස"),pL73X0MYajJQG4n1qgD(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫහ"),bb3AWcQ4gsKekujJxH92aTY8yBPhtz(u"࡙ࠫࡋࡓࡕࡋࡑࡋࠬළ"),pYeVwat64v(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧෆ"),Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"࠭ࡅ࡙ࡇࡆ࡙࡙ࡋࡊࡔࠩ෇"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡘࡇࡅࡇࡆࡉࡈࡆࠩ෈")]
api_repos_actions = [rAYDiWlzm9MCU6x0GnROua(u"ࠨࡃࡇࡈࡔࡔࡓࠨ෉"),MLe2aPIuhtK5UrAWQE7pq4FGwdDzs(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻්ࠫ"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ෋")]
non_videos_actions = [pbmKZA1w7L4zHjOM(u"ࠫࡆࡒࡌࠨ෌"),zWBnYSGIatjXVC(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ෍"),hWRvZOYtjme9QNnV41u0Mswb(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ෎"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫා"),kAz7WRYjrfGm(u"ࠨࡔࡈࡔࡔ࡙ࠧැ"),pYeVwat64v(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬෑ"),awSUTRNMkdIW7sFEvnHD2mLY(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭ි"),lRKCWnNi0Edr984eI(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪී"),YzlId3Fs6vpehcbLGj0UaO(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡋࡇࠫු"),f9fOpCmLAEaW2Go(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩ෕")]+api_python_actions+api_repos_actions
AAlBxcVDnSr = pLwgjkuTs6CS
OpUqQARsFDdGT6gJ5HwI4KYV = NFGqKBLtvUZn1S3dau
nt9ZocbLGBOMx2 = pLwgjkuTs6CS
rRAX8UJPclQdTshyt2Mew4Vb3 = pLwgjkuTs6CS
avprivsnorestrict = pLwgjkuTs6CS
avprivslongperiod = pLwgjkuTs6CS
resolveonly = pLwgjkuTs6CS
fFDKeiZkOBhgvld634w79LoR = pLwgjkuTs6CS
ALLOW_DNS_FIX = rrpMTe0FZlXBkD6jJfsKPboWhVd9
ALLOW_PROXY_FIX = rrpMTe0FZlXBkD6jJfsKPboWhVd9
ALLOW_SHOWDIALOGS_FIX = rrpMTe0FZlXBkD6jJfsKPboWhVd9
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [CCWqR3dmtzw6xoIX41(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩූ"),kAz7WRYjrfGm(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ෗"),YzlId3Fs6vpehcbLGj0UaO(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪෘ"),w9wfONXUP3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬෙ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫේ"),w9wfONXUP3(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧෛ"),B1YMtuvRAGNlJOkC46VyPKQE(u"࡙࠭ࡂࡓࡒࡘࠬො"),W2Vv30i8qxSuItfsolPLdFZA(u"ࠧࡗࡃࡕࡆࡔࡔࠧෝ"),KKCrwPdOgGl(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪෞ"),pm6C9fzIWAKyeiOPqZkGV073Fwc2d(u"ࠩࡓࡅࡓࡋࡔࠨෟ"),f9fOpCmLAEaW2Go(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭෠")]
BADWEBSITES += [Y7QXMeUA0c9SNCPO3wl8pdrqLJmGH(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ෡")]
BADCOMMONIDS = [KKd3lxRqZIbCVAtorHYSvnjF7Q089(u"ࠬ࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠹࠺࠻࠼࠱࠵࠶࠰࠱ࠩ෢"),pbmKZA1w7L4zHjOM(u"࠭࠹࠺࠺࠻࠱࠼࠽࠶࠷࠯࠸࠹࠹࠺࠭࠴࠵࠵࠶࠲࠸࠰࠹࠸ࠪ෣")]
GEOLOCATION_DATA = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
AV_CLIENT_IDS = VhaIfJdtZP1kiKbRq8nGvFo9juBp2O
DNS_SERVERS = [KKCrwPdOgGl(u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨ෤"),pL73X0MYajJQG4n1qgD(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ෥"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠩ࠴࠲࠵࠴࠰࠯࠳ࠪ෦"),GTmHXIZUSdxRhMnqQKkO(u"ࠪ࠼࠳࠾࠮࠵࠰࠷ࠫ෧"),jBbkfIJSDqcVwl8irzy4Z3O(u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠲࠯࠴࠵࠶ࠬ෨"),djapWhrveLJbgnViDftFNY05ylq1S(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠱࠰࠵࠶࠵࠭෩")]
busydialog_active = pLwgjkuTs6CS
dns_succeeded_urls = []
scrapers_succeeded = pLwgjkuTs6CS