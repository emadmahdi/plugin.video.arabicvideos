# -*- coding: utf-8 -*-
from YnWpIJVfFz import *
mI6ayKxBvjd4CRthL = 'FUSHARVIDEO'
qBAgzkG9oCL = '_FVD_'
S7EgasGcYdIo = drzqWFkSHD.SITESURLS[mI6ayKxBvjd4CRthL][0]
kCIESuy4j5mVLZYtG9vDNnb7 = ['الرئيسية','يلا شوت']
def jtanDvbPkg21urO4ZL7EcQyqeG(mode,url,text):
	if   mode==900: Ubud2NhHKRnMTvI5mprQBVqk80 = cBfe1kCEI4uZTVpKqwbGQR()
	elif mode==901: Ubud2NhHKRnMTvI5mprQBVqk80 = ENDRjPGicXYFvpVs3xk5uSg6y(url,text)
	elif mode==902: Ubud2NhHKRnMTvI5mprQBVqk80 = QgIZSJdUhsEnup8GPz3(url)
	elif mode==903: Ubud2NhHKRnMTvI5mprQBVqk80 = A91ArYpSTJf(url)
	elif mode==909: Ubud2NhHKRnMTvI5mprQBVqk80 = E3FwPg9Z6KB(text)
	else: Ubud2NhHKRnMTvI5mprQBVqk80 = False
	return Ubud2NhHKRnMTvI5mprQBVqk80
def cBfe1kCEI4uZTVpKqwbGQR():
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S7EgasGcYdIo,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-MENU-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'بحث في الموقع',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,909,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'_REMEMBERRESULTS_')
	w3BfOGLdXcWzbiC1PYx9mE('link',qFghPAi5yz9Vf3NLwo0nuprl+' ===== ===== ===== '+so4Z8OUJ5E,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,9999)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"primary-links"(.*?)</u',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?<span>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,901)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"list-categories"(.*?)</u',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			if 'http' not in cX2SpPxGLmADTKl: cX2SpPxGLmADTKl = S7EgasGcYdIo+'/'+cX2SpPxGLmADTKl.lstrip('/')
			if title in kCIESuy4j5mVLZYtG9vDNnb7: continue
			w3BfOGLdXcWzbiC1PYx9mE('folder',mI6ayKxBvjd4CRthL+'_SCRIPT_'+qBAgzkG9oCL+title,cX2SpPxGLmADTKl,901)
	return
def ENDRjPGicXYFvpVs3xk5uSg6y(url,type=VhaIfJdtZP1kiKbRq8nGvFo9juBp2O):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-TITLES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('"home-content"(.*?)"footer"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		IxdmfnvhCA8Bc9ZlQ45oiqN = IxdmfnvhCA8Bc9ZlQ45oiqN.replace('"overlay"','"duration"><')
		items = AxTYMhRlfyskNc0X19dvwtS.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		EaUe8ArOCD = []
		for RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe,cX2SpPxGLmADTKl,title in items:
			title = title.strip(' ')
			title = riUKNnOEtVwdj4(title)
			azhwpE0qmevcFobdRi = AxTYMhRlfyskNc0X19dvwtS.findall('(.*?) (الحلقة|حلقة).\d+',title,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if 'episodes' not in type and azhwpE0qmevcFobdRi:
				title = '_MOD_' + azhwpE0qmevcFobdRi[0][0]
				title = title.replace('اون لاين',VhaIfJdtZP1kiKbRq8nGvFo9juBp2O)
				if title not in EaUe8ArOCD:
					w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,903,RRx0ri8bETI)
					EaUe8ArOCD.append(title)
			else: w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,902,RRx0ri8bETI,w03zWJvcXaCUySB6HIq4mVe)
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('''["']pagination["'](.*?)["']footer["']''',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		items = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)">(.*?)</a>',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in items:
			title = riUKNnOEtVwdj4(title)
			w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة '+title,cX2SpPxGLmADTKl,901,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,type)
	else:
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('load-next-button" href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl: w3BfOGLdXcWzbiC1PYx9mE('folder',qBAgzkG9oCL+'صفحة جديدة',cX2SpPxGLmADTKl[0],901,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,type)
	return
def A91ArYpSTJf(url):
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-SERIES-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	vvuraxgW7YLIZ4hU0MbCt = AxTYMhRlfyskNc0X19dvwtS.findall('class="eplist"(.*?)</div>',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
	if vvuraxgW7YLIZ4hU0MbCt:
		IxdmfnvhCA8Bc9ZlQ45oiqN = vvuraxgW7YLIZ4hU0MbCt[0]
		rhVCfIQyOJ = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)" title="(.*?)"',IxdmfnvhCA8Bc9ZlQ45oiqN,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		for cX2SpPxGLmADTKl,title in rhVCfIQyOJ:
			w3BfOGLdXcWzbiC1PYx9mE('video',qBAgzkG9oCL+title,cX2SpPxGLmADTKl,902)
	else:
		cX2SpPxGLmADTKl = AxTYMhRlfyskNc0X19dvwtS.findall('"category".*?href="(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if cX2SpPxGLmADTKl:
			cX2SpPxGLmADTKl = cX2SpPxGLmADTKl[0]
			ENDRjPGicXYFvpVs3xk5uSg6y(cX2SpPxGLmADTKl,'episodes')
	return
def QgIZSJdUhsEnup8GPz3(url):
	dU17fayKLj4kABu,OIbrTU8tkdvLRlSG9jZhgXoPC = [],[]
	gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',url,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-PLAY-1st')
	R8AE9e4mYxVhusL3Q = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
	if 'hash=' in R8AE9e4mYxVhusL3Q:
		HZEhcvJFGxL5XW = AxTYMhRlfyskNc0X19dvwtS.findall('hash=(.*?)"',R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		HZEhcvJFGxL5XW = list(set(HZEhcvJFGxL5XW))
		for FuGekrm1E0pZ78vj4WhVdbR9aOtCD in HZEhcvJFGxL5XW:
			s4P2BrLJiAkjNyoleWhbEvKGZ = []
			PCnrX0p2QmTt5ijBIkqu4La = FuGekrm1E0pZ78vj4WhVdbR9aOtCD.split('__')
			for i1xLE74agTmA3FBVruGCQsWKjOc in PCnrX0p2QmTt5ijBIkqu4La:
				try:
					i1xLE74agTmA3FBVruGCQsWKjOc = j3kWVqdguK6O2QDmMf.b64decode(i1xLE74agTmA3FBVruGCQsWKjOc+'=')
					if fOohwvakqi29cx0l3yt5mzrAGpEg: i1xLE74agTmA3FBVruGCQsWKjOc = i1xLE74agTmA3FBVruGCQsWKjOc.decode(RMGz7OiD1e30P)
					s4P2BrLJiAkjNyoleWhbEvKGZ.append(i1xLE74agTmA3FBVruGCQsWKjOc)
				except: pass
			BA01W9olieErLycV7kwFvOhH5Y3ms = '>'.join(s4P2BrLJiAkjNyoleWhbEvKGZ)
			BA01W9olieErLycV7kwFvOhH5Y3ms = BA01W9olieErLycV7kwFvOhH5Y3ms.splitlines()
			for cX2SpPxGLmADTKl in BA01W9olieErLycV7kwFvOhH5Y3ms:
				if ' => ' in cX2SpPxGLmADTKl:
					title,cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.split(' => ')
					cX2SpPxGLmADTKl = cX2SpPxGLmADTKl+'?named='+title+'__watch'
					dU17fayKLj4kABu.append(cX2SpPxGLmADTKl)
	elif 'post_id' in R8AE9e4mYxVhusL3Q:
		ccHBj2aGoTKM5DZLv71U0CO = AxTYMhRlfyskNc0X19dvwtS.findall("post_id = '(.*?)'",R8AE9e4mYxVhusL3Q,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
		if ccHBj2aGoTKM5DZLv71U0CO:
			ccHBj2aGoTKM5DZLv71U0CO = ccHBj2aGoTKM5DZLv71U0CO[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			S8VIk4HT36jKs0QzDyeUBv1h = S7EgasGcYdIo+'/wp-admin/admin-ajax.php?action=video_info&post_id='+ccHBj2aGoTKM5DZLv71U0CO
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',S8VIk4HT36jKs0QzDyeUBv1h,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-PLAY-2nd')
			YPeCOSwjtUyl = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			PtnkvcG8AM5bysFaSNUQw7zdJl0fI = AxTYMhRlfyskNc0X19dvwtS.findall('"name":"(.*?)","src":"(.*?)"',YPeCOSwjtUyl,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if not PtnkvcG8AM5bysFaSNUQw7zdJl0fI:
				PtnkvcG8AM5bysFaSNUQw7zdJl0fI = AxTYMhRlfyskNc0X19dvwtS.findall('"src":"(.*?)"',YPeCOSwjtUyl,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
				if PtnkvcG8AM5bysFaSNUQw7zdJl0fI:
					i8ZUwomut4hysxFIjLPRfJB = ['']*len(PtnkvcG8AM5bysFaSNUQw7zdJl0fI)
					PtnkvcG8AM5bysFaSNUQw7zdJl0fI = list(zip(i8ZUwomut4hysxFIjLPRfJB,PtnkvcG8AM5bysFaSNUQw7zdJl0fI))
			for name,cX2SpPxGLmADTKl in PtnkvcG8AM5bysFaSNUQw7zdJl0fI:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('\\/','/')
				cX2SpPxGLmADTKl = pmhHwIbkcrRJeyzuxPUSDGnqM92(cX2SpPxGLmADTKl)
				if cX2SpPxGLmADTKl in OIbrTU8tkdvLRlSG9jZhgXoPC: continue
				else: OIbrTU8tkdvLRlSG9jZhgXoPC.append(cX2SpPxGLmADTKl)
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+name+'__watch')
			evGVuBpQUEL = S7EgasGcYdIo+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+ccHBj2aGoTKM5DZLv71U0CO+'&video_id=null&video_url=null&video_source=custom'
			gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs = Ut89nu2fO13R4XTZw0KGI7JYzgBWE(BRMcS58jIbyDQWGYLk1term,'GET',evGVuBpQUEL,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,headers,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,VhaIfJdtZP1kiKbRq8nGvFo9juBp2O,'FUSHARVIDEO-PLAY-3rd')
			gwiPcfVU0T4qHMDF3Wdeh7YK = gMUDF2vtLE1Cz6k4hZnAQw93aHSrOs.content
			paGUuZivbSx4LnR3Okrqf = AxTYMhRlfyskNc0X19dvwtS.findall('href="(.*?)".*?>(.*?)<',gwiPcfVU0T4qHMDF3Wdeh7YK,AxTYMhRlfyskNc0X19dvwtS.DOTALL)
			if paGUuZivbSx4LnR3Okrqf:
				EWBj8PcSwQ,uedGP9sWwpKFCEbVaJrfZNnmhcv16 = zip(*paGUuZivbSx4LnR3Okrqf)
				paGUuZivbSx4LnR3Okrqf = list(zip(uedGP9sWwpKFCEbVaJrfZNnmhcv16,EWBj8PcSwQ))
			for name,cX2SpPxGLmADTKl in paGUuZivbSx4LnR3Okrqf:
				cX2SpPxGLmADTKl = cX2SpPxGLmADTKl.replace('\\/','/')
				cX2SpPxGLmADTKl = pmhHwIbkcrRJeyzuxPUSDGnqM92(cX2SpPxGLmADTKl)
				if cX2SpPxGLmADTKl in OIbrTU8tkdvLRlSG9jZhgXoPC: continue
				else: OIbrTU8tkdvLRlSG9jZhgXoPC.append(cX2SpPxGLmADTKl)
				dU17fayKLj4kABu.append(cX2SpPxGLmADTKl+'?named='+name+'__download')
	import v3w7fbWE0x
	v3w7fbWE0x.s63lbyp7PtR5vNXxJGMu2(dU17fayKLj4kABu,mI6ayKxBvjd4CRthL,'video',url)
	return
def E3FwPg9Z6KB(search):
	search,sL9HIPc1tSZrhE60TUoz2KQa,showDialogs = EAgxpW09CSdZBy82KtTG4(search)
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: search = TwDBf3QbKOnrmd5u9()
	if search==VhaIfJdtZP1kiKbRq8nGvFo9juBp2O: return
	search = search.replace(WRsuxHTjDgYCIpoMQzLFAtS8rikP,'+')
	url = S7EgasGcYdIo+'/?s='+search
	ENDRjPGicXYFvpVs3xk5uSg6y(url,'search')
	return