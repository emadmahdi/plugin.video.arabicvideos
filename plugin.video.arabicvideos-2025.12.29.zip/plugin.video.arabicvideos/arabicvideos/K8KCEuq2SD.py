# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SERIES4WATCH'
headers = { 'User-Agent' : gby0BnUuTNFk }
JB9fyoHr05QOtPjp = '_SFW_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==210: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==211: WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	elif mode==212: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==213: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==214: WjryKiBebavP = bbEUvXtmCh4BPSq(url)
	elif mode==215: WjryKiBebavP = OJqadKfZMHbruQ5j(url)
	elif mode==218: WjryKiBebavP = wkBj5Hg72ONYxnZ1PXq64M()
	elif mode==219: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def wkBj5Hg72ONYxnZ1PXq64M():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'الموقع تغير بالكامل',message)
	return
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,219,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	url = LhFnEIuPHdoNc+'/getpostsPin?type=one&data=pin&limit=25'
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المميزة',url,211)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('FiltersButtons(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-get="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		url = LhFnEIuPHdoNc+'/getposts?type=one&data='+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,url,211)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('navigation-menu(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	d2gCoAnYPG89O = ['مسلسلات انمي','الرئيسية']
	for SSqweDUBYv4bkO,title in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if not any(value in title for value in d2gCoAnYPG89O):
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,211)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('MediaGrid"(.*?)class="pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		else: return
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	IoNyclRfU9K7WatGF4YeMvisuDC2 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if '/series/' in SSqweDUBYv4bkO: continue
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		title = Y7BxKQdU84R(title)
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if '/film/' in SSqweDUBYv4bkO or any(value in title for value in IoNyclRfU9K7WatGF4YeMvisuDC2):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,212,T6TRUSbecYGWIq29KF)
		elif '/episode/' in SSqweDUBYv4bkO and 'الحلقة' in title:
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if Cso7iV0ZOw2UW5Ez:
				title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,213,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,213,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
			title = Y7BxKQdU84R(title)
			title = title.replace('الصفحة ',gby0BnUuTNFk)
			if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,211)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	fSDXxLzOwgd7vYEHysG,items,MFyUAIPhQNR85i9X0DlsYZcvq67 = -1,[],[]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-EPISODES-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ti-list-numbered(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		bXMpofzj7h = gby0BnUuTNFk.join(QKqM0CwXDk8APOoJFpyntRb)
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',bXMpofzj7h,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	items.append(url)
	items = set(items)
	for SSqweDUBYv4bkO in items:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip('/')
		title = '_MOD_' + SSqweDUBYv4bkO.split('/')[-1].replace('-',UpN1CezytPO9XoduhxZSD)
		VUIYkcERzXphNiuwvxJybGT = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('الحلقة-(\d+)',SSqweDUBYv4bkO.split('/')[-1],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if VUIYkcERzXphNiuwvxJybGT: VUIYkcERzXphNiuwvxJybGT = VUIYkcERzXphNiuwvxJybGT[0]
		else: VUIYkcERzXphNiuwvxJybGT = '0'
		MFyUAIPhQNR85i9X0DlsYZcvq67.append([SSqweDUBYv4bkO,title,VUIYkcERzXphNiuwvxJybGT])
	items = sorted(MFyUAIPhQNR85i9X0DlsYZcvq67, reverse=False, key=lambda key: int(key[2]))
	rrJHRGiMsvEV1YPAK9WScuey = str(items).count('/season/')
	fSDXxLzOwgd7vYEHysG = str(items).count('/episode/')
	if rrJHRGiMsvEV1YPAK9WScuey>1 and fSDXxLzOwgd7vYEHysG>0 and '/season/' not in url:
		for SSqweDUBYv4bkO,title,VUIYkcERzXphNiuwvxJybGT in items:
			if '/season/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,213)
	else:
		for SSqweDUBYv4bkO,title,VUIYkcERzXphNiuwvxJybGT in items:
			if '/season/' not in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,212)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	rO9QBRygx3sqJcH5kZTM1uS74D = url.split('/')
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in jS6fQGXeouTB7xKd32ZMy:
		Tf5ueYGZIFl1hraoEOVKi = url.replace(rO9QBRygx3sqJcH5kZTM1uS74D[3],'watch')
		N84Yo7V9qS = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-PLAY-2nd')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="servers-list(.*?)</div>',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if items:
				id = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('post_id=(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if id:
					oH4W1v6egkntP8FXIORqj2 = id[0]
					for SSqweDUBYv4bkO,title in items:
						SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/?postid='+oH4W1v6egkntP8FXIORqj2+'&serverid='+SSqweDUBYv4bkO+'?named='+title+'__watch'
						eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
			else:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-embedd=".*?(http.*?)("|&quot;)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				for SSqweDUBYv4bkO,WDxo5FVQtNn7UaTlq6 in items:
					eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	if '/download/' in jS6fQGXeouTB7xKd32ZMy:
		Tf5ueYGZIFl1hraoEOVKi = url.replace(rO9QBRygx3sqJcH5kZTM1uS74D[3],'download')
		N84Yo7V9qS = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,'SERIES4WATCH-PLAY-3rd')
		id = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('postId:"(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if id:
			oH4W1v6egkntP8FXIORqj2 = id[0]
			IciL6hoO5F1MDSVPjypWZs8kKx = { 'User-Agent':gby0BnUuTNFk , 'X-Requested-With':'XMLHttpRequest' }
			Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc + '/ajaxCenter?_action=getdownloadlinks&postId='+oH4W1v6egkntP8FXIORqj2
			N84Yo7V9qS = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,'SERIES4WATCH-PLAY-4th')
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<h3.*?(\d+)(.*?)</div>',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if QKqM0CwXDk8APOoJFpyntRb:
				for jstCQzNikq,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
					items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<td>(.*?)<.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					for name,SSqweDUBYv4bkO in items:
						eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO+'?named='+name+'__download'+'____'+jstCQzNikq)
			else:
				QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<h6(.*?)</table>',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = [N84Yo7V9qS]
				for AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
					name = gby0BnUuTNFk
					items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					for SSqweDUBYv4bkO in items:
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = '&&' + SSqweDUBYv4bkO.split('/')[2].lower() + '&&'
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = TfYmiUDcZOCgQ86rENjVG1zaqXbWk.replace('.com&&',gby0BnUuTNFk).replace('.co&&',gby0BnUuTNFk)
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = TfYmiUDcZOCgQ86rENjVG1zaqXbWk.replace('.net&&',gby0BnUuTNFk).replace('.org&&',gby0BnUuTNFk)
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = TfYmiUDcZOCgQ86rENjVG1zaqXbWk.replace('.live&&',gby0BnUuTNFk).replace('.online&&',gby0BnUuTNFk)
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = TfYmiUDcZOCgQ86rENjVG1zaqXbWk.replace('&&hd.',gby0BnUuTNFk).replace('&&www.',gby0BnUuTNFk)
						TfYmiUDcZOCgQ86rENjVG1zaqXbWk = TfYmiUDcZOCgQ86rENjVG1zaqXbWk.replace('&&',gby0BnUuTNFk)
						SSqweDUBYv4bkO = SSqweDUBYv4bkO + '?named=' + name + TfYmiUDcZOCgQ86rENjVG1zaqXbWk + '__download'
						eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + '/search?s='+search
	Xw3tTz8UD4LK26C(url)
	return