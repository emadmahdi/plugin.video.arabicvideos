# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'MOVIZLAND'
headers = { 'User-Agent' : gby0BnUuTNFk }
JB9fyoHr05QOtPjp = '_MVZ_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
o5lILcsXUd9 = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][1]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==180: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==181: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==182: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==183: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==188: WjryKiBebavP = wkBj5Hg72ONYxnZ1PXq64M()
	elif mode==189: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def wkBj5Hg72ONYxnZ1PXq64M():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,message)
	return
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,189,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'بوكس اوفيس موفيز لاند',LhFnEIuPHdoNc,181,gby0BnUuTNFk,gby0BnUuTNFk,'box-office')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أحدث الافلام',LhFnEIuPHdoNc,181,gby0BnUuTNFk,gby0BnUuTNFk,'latest-movies')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'تليفزيون موفيز لاند',LhFnEIuPHdoNc,181,gby0BnUuTNFk,gby0BnUuTNFk,'tv')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الاكثر مشاهدة',LhFnEIuPHdoNc,181,gby0BnUuTNFk,gby0BnUuTNFk,'top-views')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أقوى الافلام الحالية',LhFnEIuPHdoNc,181,gby0BnUuTNFk,gby0BnUuTNFk,'top-movies')
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-MENU-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<h2><a href="(.*?)".*?">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,181)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	elif type=='box-office': AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	elif type=='top-movies': AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('btn-2-overlay(.*?)<style>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	elif type=='top-views': AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	elif type=='tv': AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	else: AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
	if type in ['top-views','top-movies']:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	IoNyclRfU9K7WatGF4YeMvisuDC2 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for T6TRUSbecYGWIq29KF,GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ,Ns6k3AvongF1YabKz7OmdxR in items:
		if type in ['top-views','top-movies']:
			T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,RkntpA1UJDV4vNgyaex6GPWK9YQIcC,title = T6TRUSbecYGWIq29KF,GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ,Ns6k3AvongF1YabKz7OmdxR
		else: T6TRUSbecYGWIq29KF,title,SSqweDUBYv4bkO,RkntpA1UJDV4vNgyaex6GPWK9YQIcC = T6TRUSbecYGWIq29KF,GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ,Ns6k3AvongF1YabKz7OmdxR
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('?view=true',gby0BnUuTNFk)
		title = Y7BxKQdU84R(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',gby0BnUuTNFk).replace('بجوده ',gby0BnUuTNFk)
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if 'الحلقة' in title or 'الحلقه' in title:
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|الحلقه) \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if Cso7iV0ZOw2UW5Ez:
				title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,183,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif any(value in title for value in IoNyclRfU9K7WatGF4YeMvisuDC2):
			SSqweDUBYv4bkO = SSqweDUBYv4bkO + '?servers=' + RkntpA1UJDV4vNgyaex6GPWK9YQIcC
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,182,T6TRUSbecYGWIq29KF)
		else:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO + '?servers=' + RkntpA1UJDV4vNgyaex6GPWK9YQIcC
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,183,T6TRUSbecYGWIq29KF)
	if type==gby0BnUuTNFk:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('\n<li><a href="(.*?)".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			title = title.replace('الصفحة ',gby0BnUuTNFk)
			if title!=gby0BnUuTNFk:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,181)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	Tf5ueYGZIFl1hraoEOVKi = url.split('?servers=')[0]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-EPISODES-1st')
	AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	title,WDxo5FVQtNn7UaTlq6,T6TRUSbecYGWIq29KF = AxiBv1cQueOs0[0]
	name = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="episodesNumbers"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO in items:
			SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
			title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(الحلقة|الحلقه)-([0-9]+)',SSqweDUBYv4bkO.split('/')[-2],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if not title: title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('()-([0-9]+)',SSqweDUBYv4bkO.split('/')[-2],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if title: title = UpN1CezytPO9XoduhxZSD + title[0][1]
			else: title = gby0BnUuTNFk
			title = name + ' - ' + 'الحلقة' + title
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,182,T6TRUSbecYGWIq29KF)
	if not items:
		title = Y7BxKQdU84R(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',gby0BnUuTNFk).replace('بجوده ',gby0BnUuTNFk)
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,url,182,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	PjWG1XInNqQ57SJfs40eviC968M = url.split('?servers=')
	Tf5ueYGZIFl1hraoEOVKi = PjWG1XInNqQ57SJfs40eviC968M[0]
	del PjWG1XInNqQ57SJfs40eviC968M[0]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-PLAY-1st')
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('font-size: 25px;" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	if SSqweDUBYv4bkO not in PjWG1XInNqQ57SJfs40eviC968M: PjWG1XInNqQ57SJfs40eviC968M.append(SSqweDUBYv4bkO)
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	for SSqweDUBYv4bkO in PjWG1XInNqQ57SJfs40eviC968M:
		if '://moshahda.' in SSqweDUBYv4bkO:
			rrxyS76dawh = SSqweDUBYv4bkO
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(rrxyS76dawh+'?named=Main')
	for SSqweDUBYv4bkO in PjWG1XInNqQ57SJfs40eviC968M:
		if '://vb.movizland.' in SSqweDUBYv4bkO:
			jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,SSqweDUBYv4bkO,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-PLAY-2nd')
			jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.decode(jwFLcuExkVa3W72t15GD).encode(JJQFjSIlALchiMzG9)
			jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if QKqM0CwXDk8APOoJFpyntRb:
				KKqcdDYsoOgme2NArHxpLIa1,cLtYnOqvefJu2KIF6PS5R = [],[]
				if len(QKqM0CwXDk8APOoJFpyntRb)==1:
					title = gby0BnUuTNFk
					AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
				else:
					for AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
						xki4Q3jNVZzFAsaWOPCge = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						if xki4Q3jNVZzFAsaWOPCge: AxiBv1cQueOs0 = 'src="/uploads/13721411411.png"  \n  ' + xki4Q3jNVZzFAsaWOPCge[0][1]
						xki4Q3jNVZzFAsaWOPCge = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						if xki4Q3jNVZzFAsaWOPCge: AxiBv1cQueOs0 = 'src="/uploads/13721411411.png"  \n  ' + xki4Q3jNVZzFAsaWOPCge[0]
						xki4Q3jNVZzFAsaWOPCge = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						if xki4Q3jNVZzFAsaWOPCge: AxiBv1cQueOs0 = xki4Q3jNVZzFAsaWOPCge[0] + '  \n  src="/uploads/13721411411.png"'
						rE15Yh7N2sSauH9yOlbZiPdn = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<(.*?)http://up.movizland.(online|com)/uploads/',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('> *([^<>]+) *<',rE15Yh7N2sSauH9yOlbZiPdn[0][0],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						title = UpN1CezytPO9XoduhxZSD.join(title)
						title = title.strip(UpN1CezytPO9XoduhxZSD)
						title = title.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
						KKqcdDYsoOgme2NArHxpLIa1.append(title)
					EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('أختر الفيديو المطلوب:', KKqcdDYsoOgme2NArHxpLIa1)
					if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1 : return
					title = KKqcdDYsoOgme2NArHxpLIa1[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
					AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
				SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http://moshahda\..*?/\w+.html)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				cFys8ij45WptfNoU0rzChaTZl3I = SSqweDUBYv4bkO[0]
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(cFys8ij45WptfNoU0rzChaTZl3I+'?named=Forum')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('ـ',gby0BnUuTNFk)
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				CP8lBoInuaRArOqHKf1zyQVS6Je = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				for KPrZzdkVE5CL8oBX in CP8lBoInuaRArOqHKf1zyQVS6Je:
					type = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(' typetype="(.*?)" ',KPrZzdkVE5CL8oBX)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = gby0BnUuTNFk
					items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',KPrZzdkVE5CL8oBX,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					for namcVuwFsAR2WYfrCv8oX9OdpP,SSqweDUBYv4bkO in items:
						title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(\w+[ \w]*)<',namcVuwFsAR2WYfrCv8oX9OdpP)
						title = title[-1]
						SSqweDUBYv4bkO = SSqweDUBYv4bkO + '?named=' + title + type
						eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi.replace(LhFnEIuPHdoNc,o5lILcsXUd9)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,mm7pzl3HMi0R8fGu,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-PLAY-3rd')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		m2u0dBPSsaetbW = items[-1]
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(m2u0dBPSsaetbW+'?named=Mobile')
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'MOVIZLAND-SEARCH-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<option value="(.*?)">(.*?)</option>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	CgnRlrY8XbL1cEIaM = [ gby0BnUuTNFk ]
	GG9ldJoChgba3Xs4uHpI = [ 'الكل وبدون فلتر' ]
	for zTFlfH8DhAVryqUjX,title in items:
		CgnRlrY8XbL1cEIaM.append(zTFlfH8DhAVryqUjX)
		GG9ldJoChgba3Xs4uHpI.append(title)
	if zTFlfH8DhAVryqUjX:
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('اختر الفلتر المناسب:', GG9ldJoChgba3Xs4uHpI)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1 : return
		zTFlfH8DhAVryqUjX = CgnRlrY8XbL1cEIaM[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	else: zTFlfH8DhAVryqUjX = gby0BnUuTNFk
	url = LhFnEIuPHdoNc + '/?s='+search+'&mcat='+zTFlfH8DhAVryqUjX
	Xw3tTz8UD4LK26C(url)
	return