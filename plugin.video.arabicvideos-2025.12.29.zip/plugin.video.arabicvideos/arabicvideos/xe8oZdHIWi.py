# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from V4OX6PRG0U import *
RLfOB3nsqaWXTugJvY(RRbvqditj184m3(u"ࠧࡕࡇࡖࡘࠬᏯ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡖࡈࡗ࡙࠭Ᏸ"))
sodfwxQDVXyIkJ6 = RRbvqditj184m3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡻ࠺࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡷ࡬࡮ࡴ࡫ࡣࡴࡲࡥࡩࡨࡡ࡯ࡦ࠱ࡧࡴࡳ࠯࠲࠲ࡐࡆ࠳ࢀࡩࡱࠩᏱ")
sodfwxQDVXyIkJ6 = NupI74tJCzYXmles9SbR6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵ࡫ࡥࡥࡶࡨࡷࡹ࠴ࡦࡵࡲ࠱ࡳࡹ࡫࡮ࡦࡶ࠱࡫ࡷ࠵ࡦࡪ࡮ࡨࡷ࠴ࡺࡥࡴࡶ࠴࠴࠵ࡱ࠮ࡥࡤࠪᏲ")
EckxoYzjdgLH0r(sodfwxQDVXyIkJ6,{},w8Ui6RsVhSPrqHfO4)
UJeuWoLKP7ZI15O4ypTVs8caj = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢแฮื࠱ࡱࡵ࠹ࠧᏳ")
UJeuWoLKP7ZI15O4ypTVs8caj = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡧ࡫࡯ࡩࡤ࠺࠸࠴࠶ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪᏴ")