# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMAFANS'
headers = { 'User-Agent' : gby0BnUuTNFk }
JB9fyoHr05QOtPjp = '_CMF_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==90: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==91: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl(url)
	elif mode==92: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==94: WjryKiBebavP = rjyJx1X2wZN()
	elif mode==95: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==99: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,99,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المضاف حديثا',gby0BnUuTNFk,94)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الأحدث',LhFnEIuPHdoNc+'/?type=latest',91)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الأعلى تقيماً',LhFnEIuPHdoNc+'/?type=imdb',91)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الأكثر مشاهدة',LhFnEIuPHdoNc+'/?type=view',91)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المثبت',LhFnEIuPHdoNc+'/?type=pin',91)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'جديد الأفلام',LhFnEIuPHdoNc+'/?type=newMovies',91)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'جديد الحلقات',LhFnEIuPHdoNc+'/?type=newEpisodes',91)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'CIMAFANS-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="mainmenu(.*?)nav',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li><a href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	d2gCoAnYPG89O = ['افلام للكبار فقط']
	for SSqweDUBYv4bkO,title in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if not any(value in title for value in d2gCoAnYPG89O):
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,91)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="f-cats"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li><a href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if not any(value in title for value in d2gCoAnYPG89O):
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,91)
	return jS6fQGXeouTB7xKd32ZMy
def O5XxuEh689Mvoq1Rnesl(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : gby0BnUuTNFk , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',url,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAFANS-ITEMS-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	else:
		headers = { 'User-Agent' : gby0BnUuTNFk }
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'CIMAFANS-ITEMS-2nd')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="movies-items(.*?)class="listfoot"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	else: AxiBv1cQueOs0 = gby0BnUuTNFk
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة [0-9]+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if Cso7iV0ZOw2UW5Ez:
				title = '_MOD_'+Cso7iV0ZOw2UW5Ez[0]
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,95,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/video/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,92,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,91,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			title = title.replace('الصفحة ',gby0BnUuTNFk)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,91)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'CIMAFANS-EPISODES-1st')
	T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="episodes-panel(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		name = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('itemprop="title">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if name: name = name[1]
		else:
			name = oKew16fsvuV8.getInfoLabel('ListItem.Label')
			if GGy0cQe765nPYZ9E8Th in name: name = name.split(GGy0cQe765nPYZ9E8Th,1)[1]
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?name">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+name+' - '+title,SSqweDUBYv4bkO,92,T6TRUSbecYGWIq29KF)
	else:
		CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="movietitle"><a href="(.*?)">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if CC7kQojDYxgLq4cBIUWnM6Xdtsh: SSqweDUBYv4bkO,title = CC7kQojDYxgLq4cBIUWnM6Xdtsh[0]
		else: SSqweDUBYv4bkO,title = url,name
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,92,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R,z3tZ0MvXgEOa19l5mS = [],[]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'CIMAFANS-PLAY-1st')
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('text-shadow: none;">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="links-panel(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?__download'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('nav-tabs"(.*?)video-panel-more',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="(.*?)".*?embed src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,SSqweDUBYv4bkO in items:
			title = 'سيرفر '+id
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-server-src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO in items:
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
			SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def rjyJx1X2wZN():
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'CIMAFANS-LATEST-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="index-last-movie(.*?)id="index-slider-movie',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if '/video/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,92,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,91,T6TRUSbecYGWIq29KF)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + '/search.php?t='+search
	O5XxuEh689Mvoq1Rnesl(url)
	return