# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from IER9OUbYLX import *
class ssCWHhKe45EkSFvJXiZtMrcYG30VB(ssknvl9JmSuB7N):
	def __init__(K2KAIOMzoptehNkf,*aargs,**kkwargs):
		K2KAIOMzoptehNkf.choiceID = -jxCVeKSLb9rGDOl0Qtw6
	def onClick(K2KAIOMzoptehNkf,Uvre4LbPIRhESoljD1c3TqYkONZiF):
		if Uvre4LbPIRhESoljD1c3TqYkONZiF>=iiauUxMktNW5X(u"࠻࠳࠵࠵அ"): K2KAIOMzoptehNkf.choiceID = Uvre4LbPIRhESoljD1c3TqYkONZiF-iiauUxMktNW5X(u"࠻࠳࠵࠵அ")
		K2KAIOMzoptehNkf.lz6gys8C0NbOFa()
	def YOHtUpXl85nks2hZMA(K2KAIOMzoptehNkf,*aargs):
		K2KAIOMzoptehNkf.button0,K2KAIOMzoptehNkf.button1,K2KAIOMzoptehNkf.button2 = aargs[xn867tCVlscY4qbWZfh],aargs[jxCVeKSLb9rGDOl0Qtw6],aargs[dNx9DVCtafk4r]
		K2KAIOMzoptehNkf.header,K2KAIOMzoptehNkf.text = aargs[jJ4LEcdl5w7BPMbQ],aargs[z5RruqXvsLaTf7e9c]
		K2KAIOMzoptehNkf.profile,K2KAIOMzoptehNkf.direction = aargs[q2qPkMFpR1G86dEAKXHivor9N(u"࠸ஆ")],aargs[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠺இ")]
		K2KAIOMzoptehNkf.buttonstimeout,K2KAIOMzoptehNkf.closetimeout = aargs[uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠽உ")],aargs[YZXtBgvUPoM5sb(u"࠽ஈ")]
		if K2KAIOMzoptehNkf.buttonstimeout>xn867tCVlscY4qbWZfh or K2KAIOMzoptehNkf.closetimeout>oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠰ஊ"): K2KAIOMzoptehNkf.enable_progressbar = w8Ui6RsVhSPrqHfO4
		else: K2KAIOMzoptehNkf.enable_progressbar = yrcbRSFswvAfEdIWVj
		K2KAIOMzoptehNkf.image_filename = eCqlQRPvasfzmcOLg627Vy.replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ૱"),iiLyoNwGbH03DIXhAkZn(u"ࠩࡢࠫ૲")+str(RyfYSek61do5OnQMc.time())+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡣࠬ૳"))
		K2KAIOMzoptehNkf.image_filename = K2KAIOMzoptehNkf.image_filename.replace(BarIC3eR9bS(u"ࠫࡡࡢࠧ૴"),iiLyoNwGbH03DIXhAkZn(u"ࠬࡢ࡜࡝࡞ࠪ૵")).replace(BarIC3eR9bS(u"࠭࠯࠰ࠩ૶"),nJF7oflOk6cLGSAey(u"ࠧ࠰࠱࠲࠳ࠬ૷"))
		K2KAIOMzoptehNkf.image_height = vlU461wE7xM9GKFNyhrWnePm(K2KAIOMzoptehNkf.button0,K2KAIOMzoptehNkf.button1,K2KAIOMzoptehNkf.button2,K2KAIOMzoptehNkf.header,K2KAIOMzoptehNkf.text,K2KAIOMzoptehNkf.profile,K2KAIOMzoptehNkf.direction,K2KAIOMzoptehNkf.enable_progressbar,K2KAIOMzoptehNkf.image_filename)
		K2KAIOMzoptehNkf.show()
		K2KAIOMzoptehNkf.getControl(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠺࠲࠸࠴஋")).setImage(K2KAIOMzoptehNkf.image_filename)
		K2KAIOMzoptehNkf.getControl(Ducd5PRjQXaB9SIN7VrJ1G(u"࠻࠳࠹࠵஌")).setHeight(K2KAIOMzoptehNkf.image_height)
		if not K2KAIOMzoptehNkf.button1 and K2KAIOMzoptehNkf.button0 and K2KAIOMzoptehNkf.button2: K2KAIOMzoptehNkf.getControl(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠽࠵࠷࠲எ")).setPosition(-RRbvqditj184m3(u"࠷࠸࠰ஏ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠳஍"))
		return K2KAIOMzoptehNkf.image_filename,K2KAIOMzoptehNkf.image_height
	def VVL0JiwQq2EvsZDIeB(K2KAIOMzoptehNkf):
		if K2KAIOMzoptehNkf.buttonstimeout:
			K2KAIOMzoptehNkf.th1 = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=K2KAIOMzoptehNkf.sS7zBrZuq1RwhX3C)
			K2KAIOMzoptehNkf.th1.start()
		else: K2KAIOMzoptehNkf.aUVuvlXQB3kSFfMe()
	def sS7zBrZuq1RwhX3C(K2KAIOMzoptehNkf):
		K2KAIOMzoptehNkf.getControl(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠿࠰࠳࠲ஐ")).setEnabled(w8Ui6RsVhSPrqHfO4)
		for t3t986iTduqY in range(jxCVeKSLb9rGDOl0Qtw6,K2KAIOMzoptehNkf.buttonstimeout+jxCVeKSLb9rGDOl0Qtw6):
			RyfYSek61do5OnQMc.sleep(jxCVeKSLb9rGDOl0Qtw6)
			ebOdJUSKt65faP8n3Xp0NQ7ugjvMR = int(IXE6voNmrb182AyQ(u"࠱࠱࠲஑")*t3t986iTduqY/K2KAIOMzoptehNkf.buttonstimeout)
			K2KAIOMzoptehNkf.qFkaQRbtl2W(ebOdJUSKt65faP8n3Xp0NQ7ugjvMR)
			if K2KAIOMzoptehNkf.choiceID>MlTVLBZ92kzorIq1Yw(u"࠱ஒ"): break
		K2KAIOMzoptehNkf.aUVuvlXQB3kSFfMe()
	def LsJ0ArFVX4PfH732eaxOW(K2KAIOMzoptehNkf):
		if K2KAIOMzoptehNkf.closetimeout:
			K2KAIOMzoptehNkf.th2 = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=K2KAIOMzoptehNkf.TypSIeKRYAQd7n9WzhDJtx1iBuU3)
			K2KAIOMzoptehNkf.th2.start()
		else: K2KAIOMzoptehNkf.aUVuvlXQB3kSFfMe()
	def TypSIeKRYAQd7n9WzhDJtx1iBuU3(K2KAIOMzoptehNkf):
		K2KAIOMzoptehNkf.getControl(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠻࠳࠶࠵ஓ")).setEnabled(w8Ui6RsVhSPrqHfO4)
		RyfYSek61do5OnQMc.sleep(K2KAIOMzoptehNkf.buttonstimeout)
		for t3t986iTduqY in range(K2KAIOMzoptehNkf.closetimeout-jxCVeKSLb9rGDOl0Qtw6,-jxCVeKSLb9rGDOl0Qtw6,-jxCVeKSLb9rGDOl0Qtw6):
			RyfYSek61do5OnQMc.sleep(jxCVeKSLb9rGDOl0Qtw6)
			ebOdJUSKt65faP8n3Xp0NQ7ugjvMR = int(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠴࠴࠵ஔ")*t3t986iTduqY/K2KAIOMzoptehNkf.closetimeout)
			K2KAIOMzoptehNkf.qFkaQRbtl2W(ebOdJUSKt65faP8n3Xp0NQ7ugjvMR)
			if K2KAIOMzoptehNkf.choiceID>xn867tCVlscY4qbWZfh: break
		if K2KAIOMzoptehNkf.closetimeout>xn867tCVlscY4qbWZfh: K2KAIOMzoptehNkf.choiceID = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠵࠵க")
		K2KAIOMzoptehNkf.lz6gys8C0NbOFa()
	def qFkaQRbtl2W(K2KAIOMzoptehNkf,ebOdJUSKt65faP8n3Xp0NQ7ugjvMR):
		K2KAIOMzoptehNkf.precent = ebOdJUSKt65faP8n3Xp0NQ7ugjvMR
		K2KAIOMzoptehNkf.getControl(q2qPkMFpR1G86dEAKXHivor9N(u"࠾࠶࠲࠱஖")).setPercent(K2KAIOMzoptehNkf.precent)
	def aUVuvlXQB3kSFfMe(K2KAIOMzoptehNkf):
		if K2KAIOMzoptehNkf.button0: K2KAIOMzoptehNkf.getControl(TeYukOUW7i5NBM926DCjaAn0(u"࠿࠰࠲࠲஗")).setEnabled(w8Ui6RsVhSPrqHfO4)
		if K2KAIOMzoptehNkf.button1: K2KAIOMzoptehNkf.getControl(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠹࠱࠳࠴஘")).setEnabled(w8Ui6RsVhSPrqHfO4)
		if K2KAIOMzoptehNkf.button2: K2KAIOMzoptehNkf.getControl(NupI74tJCzYXmles9SbR6(u"࠺࠲࠴࠶ங")).setEnabled(w8Ui6RsVhSPrqHfO4)
	def lz6gys8C0NbOFa(K2KAIOMzoptehNkf):
		K2KAIOMzoptehNkf.close()
		try: bCoOHfPdMryRgauz0IVpth.remove(K2KAIOMzoptehNkf.image_filename)
		except: pass
def tt3DVu1TU8dLAi(*aargs,**kkwargs):
	if aargs:
		direction = aargs[xn867tCVlscY4qbWZfh]
		yBk6nWlMr9 = aargs[jxCVeKSLb9rGDOl0Qtw6]
		if not direction: direction = FAwWlRJg0UkN1(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ૸")
		if not yBk6nWlMr9: yBk6nWlMr9 = zDSw8LCxMQyraeXhojIWKmU(u"ࠩสืฯ๋ัศำࠪૹ")
		tuzf5ToNUESqid4PIOMjR8KC = aargs[dNx9DVCtafk4r]
		czrd0xT7BIl6noGC29w = okfdjS4RmM.join(aargs[ggtuNcvTn3HQ7SpE2(u"࠵ச"):])
	else: direction,yBk6nWlMr9,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w = gby0BnUuTNFk,KJLkQsqSHMR1Np2(u"ࠪࡓࡐ࠭ૺ"),gby0BnUuTNFk,gby0BnUuTNFk
	yc8Ph4rFsCIvQbOA(direction,gby0BnUuTNFk,yBk6nWlMr9,gby0BnUuTNFk,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,**kkwargs)
	return
def c3iHohf1zAFQjtTV20pPlS(*aargs,**kkwargs):
	direction = aargs[xn867tCVlscY4qbWZfh]
	KHwBd1CxWltR = aargs[jxCVeKSLb9rGDOl0Qtw6]
	p5JoLnOzu7sS = aargs[dNx9DVCtafk4r]
	if p5JoLnOzu7sS or KHwBd1CxWltR: I3IrdOQmgzl47tcXD = w8Ui6RsVhSPrqHfO4
	else: I3IrdOQmgzl47tcXD = yrcbRSFswvAfEdIWVj
	tuzf5ToNUESqid4PIOMjR8KC = aargs[jJ4LEcdl5w7BPMbQ]
	czrd0xT7BIl6noGC29w = aargs[z5RruqXvsLaTf7e9c]
	if not direction: direction = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫૻ")
	if not KHwBd1CxWltR: KHwBd1CxWltR = NupI74tJCzYXmles9SbR6(u"้ࠬไศࠢࠣࡒࡴ࠭ૼ")
	if not p5JoLnOzu7sS: p5JoLnOzu7sS = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨ૽")
	if len(aargs)>=VzO1gCHmjZ2ebRIL(u"࠺ஜ"): czrd0xT7BIl6noGC29w += okfdjS4RmM+aargs[zDSw8LCxMQyraeXhojIWKmU(u"࠸஛")]
	if len(aargs)>=zDSw8LCxMQyraeXhojIWKmU(u"࠼஝"): czrd0xT7BIl6noGC29w += okfdjS4RmM+aargs[RRbvqditj184m3(u"࠼ஞ")]
	QA7oZDp3bUzwFde5ymVf = yc8Ph4rFsCIvQbOA(direction,KHwBd1CxWltR,gby0BnUuTNFk,p5JoLnOzu7sS,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,**kkwargs)
	if QA7oZDp3bUzwFde5ymVf==-IXE6voNmrb182AyQ(u"࠱ட") and I3IrdOQmgzl47tcXD: QA7oZDp3bUzwFde5ymVf = -jxCVeKSLb9rGDOl0Qtw6
	elif QA7oZDp3bUzwFde5ymVf==-jxCVeKSLb9rGDOl0Qtw6 and not I3IrdOQmgzl47tcXD: QA7oZDp3bUzwFde5ymVf = yrcbRSFswvAfEdIWVj
	elif QA7oZDp3bUzwFde5ymVf==xn867tCVlscY4qbWZfh: QA7oZDp3bUzwFde5ymVf = yrcbRSFswvAfEdIWVj
	elif QA7oZDp3bUzwFde5ymVf==dNx9DVCtafk4r: QA7oZDp3bUzwFde5ymVf = w8Ui6RsVhSPrqHfO4
	return QA7oZDp3bUzwFde5ymVf
def i4r2OdGLlMhDEWfCVU0TKe3(*aargs,**kkwargs):
	return SxtK1ciEvLXRAWFVfQDOMgBYC.Dialog().select(*aargs,**kkwargs)
def RLfOB3nsqaWXTugJvY(*args,**kwargs):
	tuzf5ToNUESqid4PIOMjR8KC = args[xn867tCVlscY4qbWZfh]
	czrd0xT7BIl6noGC29w = args[jxCVeKSLb9rGDOl0Qtw6]
	if len(args) > dNx9DVCtafk4r and q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡵ࡫ࡰࡩࠬ૾") not in str(args[iI7tuF0nEQoR(u"࠳஠")]):
		joxiLZ6wtMf9mTeyaNSbEq = args[dNx9DVCtafk4r]
		eyzvaQL70WqVUn3pxmXS6A9ds21 = kwargs.get(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡶ࡬ࡱࡪ࠭૿"), iiLyoNwGbH03DIXhAkZn(u"࠳࠳࠴࠵஡"))
	else:
		joxiLZ6wtMf9mTeyaNSbEq = YZXtBgvUPoM5sb(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ଀")
		eyzvaQL70WqVUn3pxmXS6A9ds21 = args[dNx9DVCtafk4r] if len(args) > dNx9DVCtafk4r else kwargs.get(BarIC3eR9bS(u"ࠪࡸ࡮ࡳࡥࠨଁ"), iiauUxMktNW5X(u"࠴࠴࠵࠶஢"))
	Q9cbjuO24JTZVd3 = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=Gpw8UNaO3coi9dF4rnPK5IBXSvs,args=(tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,joxiLZ6wtMf9mTeyaNSbEq,eyzvaQL70WqVUn3pxmXS6A9ds21))
	Q9cbjuO24JTZVd3.start()
	return
def Gpw8UNaO3coi9dF4rnPK5IBXSvs(tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,joxiLZ6wtMf9mTeyaNSbEq,eyzvaQL70WqVUn3pxmXS6A9ds21):
	nnfjNZw2LMCBID1YR8W = joxiLZ6wtMf9mTeyaNSbEq.replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࠫଂ"),gby0BnUuTNFk)
	import DzAjkuQ7ld
	name = DzAjkuQ7ld.RQxlZpTwMkW0F8fSIObUt5oDy7c(w8Ui6RsVhSPrqHfO4,nnfjNZw2LMCBID1YR8W+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࠦ࠭ࠡࠩଃ")+tuzf5ToNUESqid4PIOMjR8KC+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࠠ࠮ࠢࠪ଄")+czrd0xT7BIl6noGC29w)
	name = DzAjkuQ7ld.AAkN5aCpwrvOPhUYg9(name)
	image_filename = bCoOHfPdMryRgauz0IVpth.path.join(fsPkxEdtSDGogHLlvF,name+n6JjFHfmydIaLut(u"ࠧ࠯ࡲࡱ࡫ࠬଅ"))
	if bCoOHfPdMryRgauz0IVpth.path.exists(image_filename):
		if joxiLZ6wtMf9mTeyaNSbEq==nJF7oflOk6cLGSAey(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨଆ"): image_height = TeYukOUW7i5NBM926DCjaAn0(u"࠵࠶࠽ண")
		elif joxiLZ6wtMf9mTeyaNSbEq==sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭ଇ"): image_height = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠷࠷࠰த")
	else: image_height = vlU461wE7xM9GKFNyhrWnePm(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,joxiLZ6wtMf9mTeyaNSbEq,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡰࡪ࡬ࡴࠨଈ"),yrcbRSFswvAfEdIWVj,image_filename)
	syFkXfWRVlMOnHoh = ssknvl9JmSuB7N(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫଉ"),Obkt3DeiTmRGEIM,iI7tuF0nEQoR(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ଊ"),i80mE7lHUwVk(u"࠭࠷࠳࠲ࡳࠫଋ"))
	syFkXfWRVlMOnHoh.show()
	if joxiLZ6wtMf9mTeyaNSbEq==YZXtBgvUPoM5sb(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡡࡶࡶࡲࠫଌ"):
		syFkXfWRVlMOnHoh.getControl(zDSw8LCxMQyraeXhojIWKmU(u"࠹࠱࠶࠳஦")).setHeight(OUFxZPuXDoGAbRz(u"࠸࠱࠶஥"))
		syFkXfWRVlMOnHoh.getControl(nJF7oflOk6cLGSAey(u"࠼࠴࠹࠶ன")).setPosition(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠶࠷஧"),-TeYukOUW7i5NBM926DCjaAn0(u"࠺࠳ந"))
		syFkXfWRVlMOnHoh.getControl(FAwWlRJg0UkN1(u"࠽࠵࠻࠰ப")).setPosition(n6JjFHfmydIaLut(u"࠶࠸࠰஫"),-nJF7oflOk6cLGSAey(u"࠼࠰஬"))
		syFkXfWRVlMOnHoh.getControl(iI7tuF0nEQoR(u"࠶࠳࠴ய")).setPosition(q2qPkMFpR1G86dEAKXHivor9N(u"࠹࠱஭"),-Ducd5PRjQXaB9SIN7VrJ1G(u"࠴࠷ம"))
	syFkXfWRVlMOnHoh.getControl(NupI74tJCzYXmles9SbR6(u"࠷࠴࠶ர")).setVisible(yrcbRSFswvAfEdIWVj)
	syFkXfWRVlMOnHoh.getControl(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠸࠵࠸ற")).setVisible(yrcbRSFswvAfEdIWVj)
	syFkXfWRVlMOnHoh.getControl(DWgX6JfF3SnlsQwtN1cvGk8L(u"࠾࠶࠵࠱ல")).setImage(image_filename)
	syFkXfWRVlMOnHoh.getControl(mmbcsf2pd7gyjzreB(u"࠿࠰࠶࠲ள")).setHeight(image_height)
	RyfYSek61do5OnQMc.sleep(eyzvaQL70WqVUn3pxmXS6A9ds21/VzO1gCHmjZ2ebRIL(u"࠱࠱࠲࠳࠲࠵ழ"))
	return
def YNX5nvi2VegTUu(*aargs,**kkwargs):
	tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,profile,direction = gby0BnUuTNFk,gby0BnUuTNFk,n6JjFHfmydIaLut(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ଍"),FAwWlRJg0UkN1(u"ࠩ࡯ࡩ࡫ࡺࠧ଎")
	if len(aargs)>=jxCVeKSLb9rGDOl0Qtw6: tuzf5ToNUESqid4PIOMjR8KC = aargs[xn867tCVlscY4qbWZfh]
	if len(aargs)>=dNx9DVCtafk4r: czrd0xT7BIl6noGC29w = aargs[jxCVeKSLb9rGDOl0Qtw6]
	if len(aargs)>=jJ4LEcdl5w7BPMbQ: profile = aargs[dNx9DVCtafk4r]
	if len(aargs)>=z5RruqXvsLaTf7e9c: direction = aargs[jJ4LEcdl5w7BPMbQ]
	return sbqP27kMUtTxS0dyYO(direction,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,profile)
def MMgdej0E4XIrLa1bhxPQZJlB2Um(*aargs,**kkwargs):
	return SxtK1ciEvLXRAWFVfQDOMgBYC.Dialog().contextmenu(*aargs,**kkwargs)
def ongxYVNfem(*aargs,**kkwargs):
	return SxtK1ciEvLXRAWFVfQDOMgBYC.Dialog().browseSingle(*aargs,**kkwargs)
def f75Syme6HMwc1OqhGbTjE8Ptp(*aargs,**kkwargs):
	return SxtK1ciEvLXRAWFVfQDOMgBYC.Dialog().input(*aargs,**kkwargs)
def gX5UxB8Sce7tuvjkNaoIAHDq4(*aargs,**kkwargs):
	return SxtK1ciEvLXRAWFVfQDOMgBYC.DialogProgress(*aargs,**kkwargs)
def yc8Ph4rFsCIvQbOA(direction,button0=gby0BnUuTNFk,button1=gby0BnUuTNFk,button2=gby0BnUuTNFk,tuzf5ToNUESqid4PIOMjR8KC=gby0BnUuTNFk,czrd0xT7BIl6noGC29w=gby0BnUuTNFk,profile=Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬଏ"),AtHrDSMsIov67fXmT=xn867tCVlscY4qbWZfh,QknpuGhTivCSHWYLxIdZfrjE2MRA4=xn867tCVlscY4qbWZfh):
	if not direction: direction = i80mE7lHUwVk(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫଐ")
	syFkXfWRVlMOnHoh = ssCWHhKe45EkSFvJXiZtMrcYG30VB(nJF7oflOk6cLGSAey(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ଑"),Obkt3DeiTmRGEIM,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ଒"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧ࠸࠴࠳ࡴࠬଓ"))
	syFkXfWRVlMOnHoh.YOHtUpXl85nks2hZMA(button0,button1,button2,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,profile,direction,AtHrDSMsIov67fXmT,QknpuGhTivCSHWYLxIdZfrjE2MRA4)
	if AtHrDSMsIov67fXmT>xn867tCVlscY4qbWZfh: syFkXfWRVlMOnHoh.VVL0JiwQq2EvsZDIeB()
	if QknpuGhTivCSHWYLxIdZfrjE2MRA4>xn867tCVlscY4qbWZfh: syFkXfWRVlMOnHoh.LsJ0ArFVX4PfH732eaxOW()
	if AtHrDSMsIov67fXmT==xn867tCVlscY4qbWZfh and QknpuGhTivCSHWYLxIdZfrjE2MRA4==xn867tCVlscY4qbWZfh: syFkXfWRVlMOnHoh.aUVuvlXQB3kSFfMe()
	syFkXfWRVlMOnHoh.doModal()
	QA7oZDp3bUzwFde5ymVf = syFkXfWRVlMOnHoh.choiceID
	return QA7oZDp3bUzwFde5ymVf
def sbqP27kMUtTxS0dyYO(direction,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,profile=n6JjFHfmydIaLut(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩଔ")):
	if not direction: direction = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࡯ࡩ࡫ࡺࠧକ")
	syFkXfWRVlMOnHoh = ssknvl9JmSuB7N(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ଖ"),Obkt3DeiTmRGEIM,mmbcsf2pd7gyjzreB(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬଗ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࠽࠲࠱ࡲࠪଘ"))
	image_filename = eCqlQRPvasfzmcOLg627Vy.replace(FAwWlRJg0UkN1(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ଙ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡠࠩଚ")+str(RyfYSek61do5OnQMc.time())+zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡡࠪଛ"))
	image_filename = image_filename.replace(nJF7oflOk6cLGSAey(u"ࠩ࡟ࡠࠬଜ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡠࡡࡢ࡜ࠨଝ")).replace(zDSw8LCxMQyraeXhojIWKmU(u"ࠫ࠴࠵ࠧଞ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬ࠵࠯࠰࠱ࠪଟ"))
	image_height = vlU461wE7xM9GKFNyhrWnePm(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,tuzf5ToNUESqid4PIOMjR8KC,czrd0xT7BIl6noGC29w,profile,direction,yrcbRSFswvAfEdIWVj,image_filename)
	syFkXfWRVlMOnHoh.show()
	syFkXfWRVlMOnHoh.getControl(MlTVLBZ92kzorIq1Yw(u"࠺࠲࠸࠴வ")).setHeight(image_height)
	syFkXfWRVlMOnHoh.getControl(n6JjFHfmydIaLut(u"࠻࠳࠹࠵ஶ")).setImage(image_filename)
	BdSKW76Q9y1 = syFkXfWRVlMOnHoh.doModal()
	try: bCoOHfPdMryRgauz0IVpth.remove(image_filename)
	except: pass
	return BdSKW76Q9y1
def vlU461wE7xM9GKFNyhrWnePm(LaOn2jVAB6trlZE,uxwXQWyq09RUZpL2Hejzdkr6OtlC,U7xYBnAPOTrG3JK4m62hQS8dL1D,KZHNomSbgeIf1AFR7,fbmZ9V58PCTz,FazXB3n2d8Ik67rl,YeTVdK2qapxMNFHZEU8yO,uu2vi9CsD5f4Vz,USLRxXjO1k0cM5zBrpG):
	zcd4BA7b35tgiZXoSmk0 = bCoOHfPdMryRgauz0IVpth.path.dirname(USLRxXjO1k0cM5zBrpG)
	if not bCoOHfPdMryRgauz0IVpth.path.exists(zcd4BA7b35tgiZXoSmk0):
		try: bCoOHfPdMryRgauz0IVpth.makedirs(zcd4BA7b35tgiZXoSmk0)
		except: pass
	CCGEae5gBduNvWArfnxZ28skIOzwY = w1pG309m6TaEWHnvZuUSYgbNsRq(FazXB3n2d8Ik67rl)
	MUYv8PQV3TR6qy4S9Ch = ItbF43ydgCrGms7izZnlD2h(CCGEae5gBduNvWArfnxZ28skIOzwY,LaOn2jVAB6trlZE,uxwXQWyq09RUZpL2Hejzdkr6OtlC,U7xYBnAPOTrG3JK4m62hQS8dL1D,KZHNomSbgeIf1AFR7,fbmZ9V58PCTz,FazXB3n2d8Ik67rl,YeTVdK2qapxMNFHZEU8yO,uu2vi9CsD5f4Vz,USLRxXjO1k0cM5zBrpG)
	return MUYv8PQV3TR6qy4S9Ch
def w1pG309m6TaEWHnvZuUSYgbNsRq(FazXB3n2d8Ik67rl):
	AAeDl7mtXnwbsOcp4kdfzNK1UhaBjI = DVbaycS5iITnPMRsdueXqg1wQx6ltr
	NtO4uEH1RK3ci = KJLkQsqSHMR1Np2(u"࠵࠴ஷ")
	QQxdiJm1StNyvPRErIkMn = i80mE7lHUwVk(u"࠶࠵ஸ")
	MmbEtTwU6p3x8BJf9ocjWhOklHLI = xn867tCVlscY4qbWZfh
	Ai7zjHrmt2LdFVhBUfcJksIlSb = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ଠ")
	sn14PXBJqc = xn867tCVlscY4qbWZfh
	xwNtiUAkaQI19r2bnoEVLjXGg7 = Ducd5PRjQXaB9SIN7VrJ1G(u"࠶࠿ஹ")
	kkz0ZyfEobN9 = ne7wF4gSTRZo(u"࠹࠰஺")
	Hx0NZ7k9nYDA = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠸஻")
	neBjdM2liGPb1LCNIsA = w8Ui6RsVhSPrqHfO4
	RUlm9EVXNWz3kgpehPsJqFYf4LHcQI = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠴࠹࠸஼")
	jlAgDewUs5cfp3m4J1tM9iyTQB76S = FAwWlRJg0UkN1(u"࠶࠴࠴஽")
	ZqBYTINapwMtc6GERVm = n6JjFHfmydIaLut(u"࠸࠴ா")
	AkgtrmPbXjldRc5h47vC3BQFYif8G6 = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠶࠽࠶ி")
	jKd05w3buH8y = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠷࠾ீ")
	LL1Kjemt3E4oQxJhM5cql = DVbaycS5iITnPMRsdueXqg1wQx6ltr
	FF6vBTzXVeEOxZifJkW = xn867tCVlscY4qbWZfh
	Kj7Ss0ZpcgCz4doB = ne7wF4gSTRZo(u"࠹࠱ு")
	LLzqIdYxJ8tbBple = [TeYukOUW7i5NBM926DCjaAn0(u"࠵࠹௄"),ggtuNcvTn3HQ7SpE2(u"࠳࠳ூ"),KJLkQsqSHMR1Np2(u"࠳࠺௃")]
	from PIL import ImageDraw as Yc7bJegi8IySEnVrZjl69Gf,ImageFont as dNx2OZneM9zpV4vX8bS,Image as kNZV81f9a43SAro67UsIp5CPM
	if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ଡ") in FazXB3n2d8Ik67rl:
		if FazXB3n2d8Ik67rl==q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨଢ"):
			EnPqIBw2W86ATafRO = MlTVLBZ92kzorIq1Yw(u"࠴࠵࠼௅")
			Ai7zjHrmt2LdFVhBUfcJksIlSb = VzO1gCHmjZ2ebRIL(u"ࠩ࡯ࡩ࡫ࡺࠧଣ")
			neBjdM2liGPb1LCNIsA = yrcbRSFswvAfEdIWVj
		elif FazXB3n2d8Ik67rl==n6JjFHfmydIaLut(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵࠧତ"):
			EnPqIBw2W86ATafRO = mmbcsf2pd7gyjzreB(u"࡚ࠫࡖࡐࡆࡔࠪଥ")
			Ai7zjHrmt2LdFVhBUfcJksIlSb = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡸࡩࡨࡪࡷࠫଦ")
			MmbEtTwU6p3x8BJf9ocjWhOklHLI = FAwWlRJg0UkN1(u"࠵࠵ெ")
		c8NFbshQRUITd0MVoK1L2nWkJ5O = NupI74tJCzYXmles9SbR6(u"࠼࠸࠰ே")
		LLzqIdYxJ8tbBple = [BarIC3eR9bS(u"࠹࠳ை"),BarIC3eR9bS(u"࠹࠳ை"),BarIC3eR9bS(u"࠹࠳ை")]
		QQxdiJm1StNyvPRErIkMn = RRbvqditj184m3(u"࠲࠱௉")
		NtO4uEH1RK3ci = xn867tCVlscY4qbWZfh
		kkz0ZyfEobN9 = KJLkQsqSHMR1Np2(u"࠳࠲ொ")
		xwNtiUAkaQI19r2bnoEVLjXGg7 = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠵࠸ோ")
	elif FazXB3n2d8Ik67rl==iI7tuF0nEQoR(u"࠭࡭ࡦࡰࡸࡣ࡮ࡺࡥ࡮ࠩଧ"):
		LLzqIdYxJ8tbBple,c8NFbshQRUITd0MVoK1L2nWkJ5O,EnPqIBw2W86ATafRO = [YZXtBgvUPoM5sb(u"࠷࠾௎"),YZXtBgvUPoM5sb(u"࠷࠾௎"),YZXtBgvUPoM5sb(u"࠷࠾௎")],mmbcsf2pd7gyjzreB(u"࠵࠴࠵ௌ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠶࠺࠶்")
		sn14PXBJqc,kkz0ZyfEobN9,xwNtiUAkaQI19r2bnoEVLjXGg7, = xn867tCVlscY4qbWZfh,-KJLkQsqSHMR1Np2(u"࠷࠲௏"),-lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠳࠱ௐ")
		NtO4uEH1RK3ci = xn867tCVlscY4qbWZfh
		Ya76FIoZOWuEj9e = kNZV81f9a43SAro67UsIp5CPM.open(qhmgPE97uDMAwzkxiH)
		CN67qnDpuRAtXYecHoG = kNZV81f9a43SAro67UsIp5CPM.new(iI7tuF0nEQoR(u"ࠧࡓࡉࡅࡅࠬନ"),(c8NFbshQRUITd0MVoK1L2nWkJ5O,EnPqIBw2W86ATafRO),(iiLyoNwGbH03DIXhAkZn(u"࠳࠷࠸௑"),xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh,iiLyoNwGbH03DIXhAkZn(u"࠳࠷࠸௑")))
	elif FazXB3n2d8Ik67rl==IXE6voNmrb182AyQ(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ଩"): LLzqIdYxJ8tbBple,EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = [TeYukOUW7i5NBM926DCjaAn0(u"࠷࠾௕"),zDSw8LCxMQyraeXhojIWKmU(u"࠴࠷௒"),ggtuNcvTn3HQ7SpE2(u"࠵࠴௓")],n6JjFHfmydIaLut(u"࠻࠰࠱௖"),IXE6voNmrb182AyQ(u"࠽࠵࠶௔")
	elif FazXB3n2d8Ik67rl==sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧପ"): LLzqIdYxJ8tbBple,EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = [OUFxZPuXDoGAbRz(u"࠴࠴௘"),i80mE7lHUwVk(u"࠵࠼௚"),BarIC3eR9bS(u"࠲࠵ௗ")],ne7wF4gSTRZo(u"࠹࠵࠶௛"),iiauUxMktNW5X(u"࠻࠳࠴௙")
	elif FazXB3n2d8Ik67rl==MlTVLBZ92kzorIq1Yw(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬଫ"): LLzqIdYxJ8tbBple,EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = [oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠴࠸௟"),iiauUxMktNW5X(u"࠸࠸௜"),MlTVLBZ92kzorIq1Yw(u"࠲࠹௞")],iI7tuF0nEQoR(u"࠷࠳࠴௠"),OUFxZPuXDoGAbRz(u"࠿࠰࠱௝")
	elif FazXB3n2d8Ik67rl==nJF7oflOk6cLGSAey(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧବ"): EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = nJF7oflOk6cLGSAey(u"࠺࠸࠵௡"),zDSw8LCxMQyraeXhojIWKmU(u"࠵࠷࠽࠰௢")
	elif FazXB3n2d8Ik67rl==ne7wF4gSTRZo(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ଭ"): EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡕࡑࡒࡈࡖࠬମ"),n6JjFHfmydIaLut(u"࠶࠸࠷࠱௣")
	elif FazXB3n2d8Ik67rl==ne7wF4gSTRZo(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬଯ"): LLzqIdYxJ8tbBple,EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = [n6JjFHfmydIaLut(u"࠴࠻௧"),q2qPkMFpR1G86dEAKXHivor9N(u"࠵࠷௨"),KJLkQsqSHMR1Np2(u"࠱࠹௥")],oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠽࠴࠱௤"),IXE6voNmrb182AyQ(u"࠲࠴࠺࠴௦")
	elif FazXB3n2d8Ik67rl==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫର"): LLzqIdYxJ8tbBple,EnPqIBw2W86ATafRO,c8NFbshQRUITd0MVoK1L2nWkJ5O = [OUFxZPuXDoGAbRz(u"࠸࠸௫"),MlTVLBZ92kzorIq1Yw(u"࠲࠴௬"),NupI74tJCzYXmles9SbR6(u"࠶࠾௪")],VzO1gCHmjZ2ebRIL(u"ࠩࡘࡔࡕࡋࡒࠨ଱"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠵࠷࠽࠰௩")
	Zcx8fjFdXpGm9IuNqD,cHDt1SQ260dVsuK4vB589AMo,ppTh27Sce95JrAqblMads6t = LLzqIdYxJ8tbBple
	k71lw0z4efZESXagm = dNx2OZneM9zpV4vX8bS.truetype(XsRJxCK6MgPwj31mBdlOzv,size=Zcx8fjFdXpGm9IuNqD)
	Jelm3jRiPrk6 = dNx2OZneM9zpV4vX8bS.truetype(XsRJxCK6MgPwj31mBdlOzv,size=cHDt1SQ260dVsuK4vB589AMo)
	xnWRNBzAOmL0efQCrhi = dNx2OZneM9zpV4vX8bS.truetype(XsRJxCK6MgPwj31mBdlOzv,size=ppTh27Sce95JrAqblMads6t)
	UMsncFQ8W2fJat = c8NFbshQRUITd0MVoK1L2nWkJ5O-kkz0ZyfEobN9*dNx9DVCtafk4r
	V1XiDsobKI = kNZV81f9a43SAro67UsIp5CPM.new(ne7wF4gSTRZo(u"ࠪࡖࡌࡈࡁࠨଲ"),(UMsncFQ8W2fJat,VzO1gCHmjZ2ebRIL(u"࠲࠲࠳௭")),(iI7tuF0nEQoR(u"࠴࠸࠹௮"),iI7tuF0nEQoR(u"࠴࠸࠹௮"),iI7tuF0nEQoR(u"࠴࠸࠹௮"),xn867tCVlscY4qbWZfh))
	Dar0gLWdR8KHOGjY51weBQE = Yc7bJegi8IySEnVrZjl69Gf.Draw(V1XiDsobKI)
	tTxqQ9YAvG,WjBXUxib94mwKCoHY = Dar0gLWdR8KHOGjY51weBQE.textsize(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ଳ"),font=k71lw0z4efZESXagm)
	E0PSXb8Ml5Y9ruC3IN4OHsQhevm,aLfd5yZlDVCNnSzRMAKBFh6x = Dar0gLWdR8KHOGjY51weBQE.textsize(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡎࡈࡉࠢࡅࡆࡇࠦ࠸࠹࠺ࠣ࠴࠵࠶ࠧ଴"),font=Jelm3jRiPrk6)
	MYsVRdGjbZ6vunqETh = {GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡨࡢࡴࡤ࡯ࡦࡺࠧଵ"):yrcbRSFswvAfEdIWVj,VzO1gCHmjZ2ebRIL(u"ࠧࡴࡷࡳࡴࡴࡸࡴࡠ࡮࡬࡫ࡦࡺࡵࡳࡧࡶࠫଶ"):w8Ui6RsVhSPrqHfO4,zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡃࡕࡅࡇࡏࡃࠡࡎࡌࡋࡆ࡚ࡕࡓࡇࠣࡅࡑࡒࡁࡉࠩଷ"):yrcbRSFswvAfEdIWVj}
	from arabic_reshaper import ArabicReshaper as Ke26LZlY9Am7pVCcPtRX1Osjd
	IMe0fbWnRw7KaoG3JNrdDyYgXCA = Ke26LZlY9Am7pVCcPtRX1Osjd(configuration=MYsVRdGjbZ6vunqETh)
	CCGEae5gBduNvWArfnxZ28skIOzwY = {}
	aY9QBrVbxOGq8E7LySvzt3MiC6fP = locals()
	for VVPgcXqOTRbEUBmk2ao in aY9QBrVbxOGq8E7LySvzt3MiC6fP: CCGEae5gBduNvWArfnxZ28skIOzwY[VVPgcXqOTRbEUBmk2ao] = aY9QBrVbxOGq8E7LySvzt3MiC6fP[VVPgcXqOTRbEUBmk2ao]
	return CCGEae5gBduNvWArfnxZ28skIOzwY
def ItbF43ydgCrGms7izZnlD2h(CCGEae5gBduNvWArfnxZ28skIOzwY,LaOn2jVAB6trlZE,uxwXQWyq09RUZpL2Hejzdkr6OtlC,U7xYBnAPOTrG3JK4m62hQS8dL1D,KZHNomSbgeIf1AFR7,fbmZ9V58PCTz,FazXB3n2d8Ik67rl,YeTVdK2qapxMNFHZEU8yO,uu2vi9CsD5f4Vz,USLRxXjO1k0cM5zBrpG):
	for VVPgcXqOTRbEUBmk2ao in CCGEae5gBduNvWArfnxZ28skIOzwY: globals()[VVPgcXqOTRbEUBmk2ao] = CCGEae5gBduNvWArfnxZ28skIOzwY[VVPgcXqOTRbEUBmk2ao]
	global jKd05w3buH8y,LL1Kjemt3E4oQxJhM5cql
	if FazXB3n2d8Ik67rl!=iiLyoNwGbH03DIXhAkZn(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬସ"):
		xvjpJSVUCmqlLrMEeP4FgkyXdQO = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫହ"))
		if xvjpJSVUCmqlLrMEeP4FgkyXdQO:
			if LaOn2jVAB6trlZE==ne7wF4gSTRZo(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭଺"): LaOn2jVAB6trlZE = q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࡟ࡥࡴࠩ଻")
			elif LaOn2jVAB6trlZE==RRbvqditj184m3(u"࠭ใๅษࠣࠤࡓࡵ଼ࠧ"): LaOn2jVAB6trlZE = q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡏࡱࠪଽ")
			if uxwXQWyq09RUZpL2Hejzdkr6OtlC==ggtuNcvTn3HQ7SpE2(u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪା"): uxwXQWyq09RUZpL2Hejzdkr6OtlC = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩ࡜ࡩࡸ࠭ି")
			elif uxwXQWyq09RUZpL2Hejzdkr6OtlC==iI7tuF0nEQoR(u"ࠪ็้อࠠࠡࡐࡲࠫୀ"): uxwXQWyq09RUZpL2Hejzdkr6OtlC = zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡓࡵࠧୁ")
			if U7xYBnAPOTrG3JK4m62hQS8dL1D==DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧୂ"): U7xYBnAPOTrG3JK4m62hQS8dL1D = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࡙࠭ࡦࡵࠪୃ")
			elif U7xYBnAPOTrG3JK4m62hQS8dL1D==n6JjFHfmydIaLut(u"ࠧไๆสࠤࠥࡔ࡯ࠨୄ"): U7xYBnAPOTrG3JK4m62hQS8dL1D = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡐࡲࠫ୅")
			import DzAjkuQ7ld
			PgTIFSCwRY3haxjiok = DzAjkuQ7ld.EERDvQXPsT6([LaOn2jVAB6trlZE,uxwXQWyq09RUZpL2Hejzdkr6OtlC,U7xYBnAPOTrG3JK4m62hQS8dL1D,KZHNomSbgeIf1AFR7,fbmZ9V58PCTz])
			if PgTIFSCwRY3haxjiok: LaOn2jVAB6trlZE,uxwXQWyq09RUZpL2Hejzdkr6OtlC,U7xYBnAPOTrG3JK4m62hQS8dL1D,KZHNomSbgeIf1AFR7,fbmZ9V58PCTz = PgTIFSCwRY3haxjiok
	if cAIRPFK6boejVU549WzqBGCaJ0r:
		fbmZ9V58PCTz = fbmZ9V58PCTz.decode(JJQFjSIlALchiMzG9)
		KZHNomSbgeIf1AFR7 = KZHNomSbgeIf1AFR7.decode(JJQFjSIlALchiMzG9)
		LaOn2jVAB6trlZE = LaOn2jVAB6trlZE.decode(JJQFjSIlALchiMzG9)
		uxwXQWyq09RUZpL2Hejzdkr6OtlC = uxwXQWyq09RUZpL2Hejzdkr6OtlC.decode(JJQFjSIlALchiMzG9)
		U7xYBnAPOTrG3JK4m62hQS8dL1D = U7xYBnAPOTrG3JK4m62hQS8dL1D.decode(JJQFjSIlALchiMzG9)
	tOjIEx8mNVF = KZHNomSbgeIf1AFR7.count(okfdjS4RmM)+jxCVeKSLb9rGDOl0Qtw6
	buWXB2m6rF8ze4h9E = NtO4uEH1RK3ci+tOjIEx8mNVF*(WjBXUxib94mwKCoHY+MmbEtTwU6p3x8BJf9ocjWhOklHLI)-MmbEtTwU6p3x8BJf9ocjWhOklHLI
	if fbmZ9V58PCTz:
		GryAkP8gN1fZc25mTbOEBJYuQW7D = aLfd5yZlDVCNnSzRMAKBFh6x+Hx0NZ7k9nYDA
		xuO1lhYvDoICtjrPeN0 = IMe0fbWnRw7KaoG3JNrdDyYgXCA.reshape(fbmZ9V58PCTz)
		if neBjdM2liGPb1LCNIsA:
			yU0tAmF3NJQ = X2qjcN7u9FwbZTY(Dar0gLWdR8KHOGjY51weBQE,Jelm3jRiPrk6,xuO1lhYvDoICtjrPeN0,cHDt1SQ260dVsuK4vB589AMo,UMsncFQ8W2fJat,GryAkP8gN1fZc25mTbOEBJYuQW7D)
			t0tISAZQR2DHn = W4oV2PYyjvQ(yU0tAmF3NJQ)
			PPTbuV75KeEwRiGvHtJaCWj2 = t0tISAZQR2DHn.count(okfdjS4RmM)+jxCVeKSLb9rGDOl0Qtw6
			KRzNioHdhlQqtnIWYXVkT2b = xwNtiUAkaQI19r2bnoEVLjXGg7+PPTbuV75KeEwRiGvHtJaCWj2*GryAkP8gN1fZc25mTbOEBJYuQW7D-Hx0NZ7k9nYDA
		else:
			KRzNioHdhlQqtnIWYXVkT2b = xwNtiUAkaQI19r2bnoEVLjXGg7+aLfd5yZlDVCNnSzRMAKBFh6x
			t0tISAZQR2DHn = xuO1lhYvDoICtjrPeN0.split(okfdjS4RmM)[xn867tCVlscY4qbWZfh]
			yU0tAmF3NJQ = xuO1lhYvDoICtjrPeN0.split(okfdjS4RmM)[xn867tCVlscY4qbWZfh]
	else: KRzNioHdhlQqtnIWYXVkT2b = xwNtiUAkaQI19r2bnoEVLjXGg7
	srHRWIl7wK5UdLJQ9vBTfk8Ymuj = FF6vBTzXVeEOxZifJkW+Kj7Ss0ZpcgCz4doB
	if uu2vi9CsD5f4Vz:
		TTJwu4taXIP3gLqGQDfoCkb82mB = jlAgDewUs5cfp3m4J1tM9iyTQB76S-RUlm9EVXNWz3kgpehPsJqFYf4LHcQI
		srHRWIl7wK5UdLJQ9vBTfk8Ymuj += TTJwu4taXIP3gLqGQDfoCkb82mB
	else: TTJwu4taXIP3gLqGQDfoCkb82mB = xn867tCVlscY4qbWZfh
	if LaOn2jVAB6trlZE or uxwXQWyq09RUZpL2Hejzdkr6OtlC or U7xYBnAPOTrG3JK4m62hQS8dL1D: srHRWIl7wK5UdLJQ9vBTfk8Ymuj += ZqBYTINapwMtc6GERVm
	MUYv8PQV3TR6qy4S9Ch = EnPqIBw2W86ATafRO if EnPqIBw2W86ATafRO!=TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡘࡔࡕࡋࡒࠨ୆") else buWXB2m6rF8ze4h9E+KRzNioHdhlQqtnIWYXVkT2b+srHRWIl7wK5UdLJQ9vBTfk8Ymuj
	V1XiDsobKI = kNZV81f9a43SAro67UsIp5CPM.new(q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡖࡌࡈࡁࠨେ"),(c8NFbshQRUITd0MVoK1L2nWkJ5O,MUYv8PQV3TR6qy4S9Ch),(zDSw8LCxMQyraeXhojIWKmU(u"࠵࠹࠺௯"),zDSw8LCxMQyraeXhojIWKmU(u"࠵࠹࠺௯"),zDSw8LCxMQyraeXhojIWKmU(u"࠵࠹࠺௯"),xn867tCVlscY4qbWZfh))
	lQa5sSWr1Xp7YVOGUybqeTxftjoF = Yc7bJegi8IySEnVrZjl69Gf.Draw(V1XiDsobKI)
	ZwJ65dEMYq = MUYv8PQV3TR6qy4S9Ch-buWXB2m6rF8ze4h9E-srHRWIl7wK5UdLJQ9vBTfk8Ymuj-xwNtiUAkaQI19r2bnoEVLjXGg7
	if not uxwXQWyq09RUZpL2Hejzdkr6OtlC and LaOn2jVAB6trlZE and U7xYBnAPOTrG3JK4m62hQS8dL1D:
		jKd05w3buH8y += VzO1gCHmjZ2ebRIL(u"࠵࠵࠻௰")
		LL1Kjemt3E4oQxJhM5cql -= MlTVLBZ92kzorIq1Yw(u"࠶࠷࠰௱")
	import bidi.algorithm as rp2sN3VWncqZGwaAv
	if KZHNomSbgeIf1AFR7:
		EK4ypTWRlFAhCGrNUVazOY65 = NtO4uEH1RK3ci
		KZHNomSbgeIf1AFR7 = rp2sN3VWncqZGwaAv.get_display(IMe0fbWnRw7KaoG3JNrdDyYgXCA.reshape(KZHNomSbgeIf1AFR7))
		uA0Ja8qPSW9 = KZHNomSbgeIf1AFR7.splitlines()
		for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
			if dlb6TgxSrm0eHB:
				l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ,HYq3NdTMQ40jGyfuvIoBRgEa5ZCK18 = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(dlb6TgxSrm0eHB,font=k71lw0z4efZESXagm)
				if Ai7zjHrmt2LdFVhBUfcJksIlSb==RRbvqditj184m3(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫୈ"): iok61GIDCBmOtV7Ta5x = AAeDl7mtXnwbsOcp4kdfzNK1UhaBjI+(c8NFbshQRUITd0MVoK1L2nWkJ5O-l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ)/dNx9DVCtafk4r
				elif Ai7zjHrmt2LdFVhBUfcJksIlSb==mmbcsf2pd7gyjzreB(u"ࠬࡸࡩࡨࡪࡷࠫ୉"): iok61GIDCBmOtV7Ta5x = AAeDl7mtXnwbsOcp4kdfzNK1UhaBjI+c8NFbshQRUITd0MVoK1L2nWkJ5O-l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ-QQxdiJm1StNyvPRErIkMn
				elif Ai7zjHrmt2LdFVhBUfcJksIlSb==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭࡬ࡦࡨࡷࠫ୊"): iok61GIDCBmOtV7Ta5x = AAeDl7mtXnwbsOcp4kdfzNK1UhaBjI+QQxdiJm1StNyvPRErIkMn
				lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((iok61GIDCBmOtV7Ta5x,EK4ypTWRlFAhCGrNUVazOY65),dlb6TgxSrm0eHB,font=k71lw0z4efZESXagm,fill=RRbvqditj184m3(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧୋ"))
			EK4ypTWRlFAhCGrNUVazOY65 += Zcx8fjFdXpGm9IuNqD+MmbEtTwU6p3x8BJf9ocjWhOklHLI
	if LaOn2jVAB6trlZE or uxwXQWyq09RUZpL2Hejzdkr6OtlC or U7xYBnAPOTrG3JK4m62hQS8dL1D:
		vdfKkwqiI9yWUNseLR8pYM = buWXB2m6rF8ze4h9E+ZwJ65dEMYq+xwNtiUAkaQI19r2bnoEVLjXGg7+TTJwu4taXIP3gLqGQDfoCkb82mB+FF6vBTzXVeEOxZifJkW
		if LaOn2jVAB6trlZE:
			LaOn2jVAB6trlZE = rp2sN3VWncqZGwaAv.get_display(IMe0fbWnRw7KaoG3JNrdDyYgXCA.reshape(LaOn2jVAB6trlZE))
			Pa2lM3o8KxXF,fchokuRSZ6ysi5Y7XCB = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(LaOn2jVAB6trlZE,font=xnWRNBzAOmL0efQCrhi)
			r3WiV7S19gFtXQxPBO = jKd05w3buH8y+xn867tCVlscY4qbWZfh*(LL1Kjemt3E4oQxJhM5cql+AkgtrmPbXjldRc5h47vC3BQFYif8G6)+(AkgtrmPbXjldRc5h47vC3BQFYif8G6-Pa2lM3o8KxXF)/dNx9DVCtafk4r
			lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((r3WiV7S19gFtXQxPBO,vdfKkwqiI9yWUNseLR8pYM),LaOn2jVAB6trlZE,font=xnWRNBzAOmL0efQCrhi,fill=nJF7oflOk6cLGSAey(u"ࠨࡻࡨࡰࡱࡵࡷࠨୌ"))
		if uxwXQWyq09RUZpL2Hejzdkr6OtlC:
			uxwXQWyq09RUZpL2Hejzdkr6OtlC = rp2sN3VWncqZGwaAv.get_display(IMe0fbWnRw7KaoG3JNrdDyYgXCA.reshape(uxwXQWyq09RUZpL2Hejzdkr6OtlC))
			ZkfMtH6XBhQ4,lL4NXSI75fdVZPhyb3Ew6WtDxm1okg = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(uxwXQWyq09RUZpL2Hejzdkr6OtlC,font=xnWRNBzAOmL0efQCrhi)
			p7v8FlK6GBdn4tDHW20zPsZqoucOUx = jKd05w3buH8y+jxCVeKSLb9rGDOl0Qtw6*(LL1Kjemt3E4oQxJhM5cql+AkgtrmPbXjldRc5h47vC3BQFYif8G6)+(AkgtrmPbXjldRc5h47vC3BQFYif8G6-ZkfMtH6XBhQ4)/dNx9DVCtafk4r
			lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((p7v8FlK6GBdn4tDHW20zPsZqoucOUx,vdfKkwqiI9yWUNseLR8pYM),uxwXQWyq09RUZpL2Hejzdkr6OtlC,font=xnWRNBzAOmL0efQCrhi,fill=KJLkQsqSHMR1Np2(u"ࠩࡼࡩࡱࡲ࡯ࡸ୍ࠩ"))
		if U7xYBnAPOTrG3JK4m62hQS8dL1D:
			U7xYBnAPOTrG3JK4m62hQS8dL1D = rp2sN3VWncqZGwaAv.get_display(IMe0fbWnRw7KaoG3JNrdDyYgXCA.reshape(U7xYBnAPOTrG3JK4m62hQS8dL1D))
			k69rLFT0uHXPiZhC8I,LL2Oo3vylQpwgaImMtB8Vun = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(U7xYBnAPOTrG3JK4m62hQS8dL1D,font=xnWRNBzAOmL0efQCrhi)
			HVMeshZL7Ba9UOJ = jKd05w3buH8y+dNx9DVCtafk4r*(LL1Kjemt3E4oQxJhM5cql+AkgtrmPbXjldRc5h47vC3BQFYif8G6)+(AkgtrmPbXjldRc5h47vC3BQFYif8G6-k69rLFT0uHXPiZhC8I)/dNx9DVCtafk4r
			lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((HVMeshZL7Ba9UOJ,vdfKkwqiI9yWUNseLR8pYM),U7xYBnAPOTrG3JK4m62hQS8dL1D,font=xnWRNBzAOmL0efQCrhi,fill=iI7tuF0nEQoR(u"ࠪࡽࡪࡲ࡬ࡰࡹࠪ୎"))
	if fbmZ9V58PCTz:
		fjtDY1m9NJqyhE,t2ZCAVPFbaBL5Y0dvicKoTGHe = [],[]
		yU0tAmF3NJQ = vyEk6LBlHzgTm1hoc3QMix4fda(yU0tAmF3NJQ)
		HPwhD7MmJlk = yU0tAmF3NJQ.split(KJLkQsqSHMR1Np2(u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ୏"))
		for S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r in HPwhD7MmJlk:
			iFO96GK4E2v0BZQj8mM = YeTVdK2qapxMNFHZEU8yO
			if   ggtuNcvTn3HQ7SpE2(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ୐") in S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r: iFO96GK4E2v0BZQj8mM = BarIC3eR9bS(u"࠭࡬ࡦࡨࡷࠫ୑")
			elif GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ୒") in S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r: iFO96GK4E2v0BZQj8mM = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡴ࡬࡫࡭ࡺࠧ୓")
			elif FAwWlRJg0UkN1(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭୔") in S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r: iFO96GK4E2v0BZQj8mM = mmbcsf2pd7gyjzreB(u"ࠪࡧࡪࡴࡴࡦࡴࠪ୕")
			V8knJxdq6EvThuoQRbfYMyKzrF = S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r
			Y5OmzMsLIaVghv4t = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(ne7wF4gSTRZo(u"ࠫࡤࡹࡳࡴࡡࡢ࠲࠯ࡅ࡟ࠨୖ"),S5sFMEDcYeVGU4zqh9ukfWjoCXLb6r,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for U1UnS0ltM3DzquBdZhPp in Y5OmzMsLIaVghv4t: V8knJxdq6EvThuoQRbfYMyKzrF = V8knJxdq6EvThuoQRbfYMyKzrF.replace(U1UnS0ltM3DzquBdZhPp,gby0BnUuTNFk)
			if V8knJxdq6EvThuoQRbfYMyKzrF==gby0BnUuTNFk: l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ,HYq3NdTMQ40jGyfuvIoBRgEa5ZCK18 = xn867tCVlscY4qbWZfh,GryAkP8gN1fZc25mTbOEBJYuQW7D
			else: l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ,HYq3NdTMQ40jGyfuvIoBRgEa5ZCK18 = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(V8knJxdq6EvThuoQRbfYMyKzrF,font=Jelm3jRiPrk6)
			if   iFO96GK4E2v0BZQj8mM==NupI74tJCzYXmles9SbR6(u"ࠬࡲࡥࡧࡶࠪୗ"): TK9uob1J78OM3RN2 = sn14PXBJqc+kkz0ZyfEobN9
			elif iFO96GK4E2v0BZQj8mM==iI7tuF0nEQoR(u"࠭ࡲࡪࡩ࡫ࡸࠬ୘"): TK9uob1J78OM3RN2 = sn14PXBJqc+kkz0ZyfEobN9+UMsncFQ8W2fJat-l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ
			elif iFO96GK4E2v0BZQj8mM==OUFxZPuXDoGAbRz(u"ࠧࡤࡧࡱࡸࡪࡸࠧ୙"): TK9uob1J78OM3RN2 = sn14PXBJqc+kkz0ZyfEobN9+(UMsncFQ8W2fJat-l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ)/dNx9DVCtafk4r
			if TK9uob1J78OM3RN2<kkz0ZyfEobN9: TK9uob1J78OM3RN2 = sn14PXBJqc+kkz0ZyfEobN9
			fjtDY1m9NJqyhE.append(TK9uob1J78OM3RN2)
			t2ZCAVPFbaBL5Y0dvicKoTGHe.append(l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ)
		TK9uob1J78OM3RN2 = fjtDY1m9NJqyhE[xn867tCVlscY4qbWZfh]
		ssUxeQqny1 = yU0tAmF3NJQ.split(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡡࡶࡷࡸࡥࠧ୚"))
		dwzfpL14c28jHbY = (uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠸࠵࠶௲"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠸࠵࠶௲"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠸࠵࠶௲"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠸࠵࠶௲"))
		tJYLnzMrZQS65uU = dwzfpL14c28jHbY
		ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM,wGZECtxoyuSJhYj5MUFsHm2 = xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
		RmQXpdTMVYfNOk = yrcbRSFswvAfEdIWVj
		RREBo6v78JAsya0b4ZPmI = xn867tCVlscY4qbWZfh
		gYnabWyOK5LStuId082UXzqN = buWXB2m6rF8ze4h9E+xwNtiUAkaQI19r2bnoEVLjXGg7/dNx9DVCtafk4r
		if KRzNioHdhlQqtnIWYXVkT2b<(ZwJ65dEMYq+xwNtiUAkaQI19r2bnoEVLjXGg7):
			Ad3Fesgh1qjup5nXB48km = (ZwJ65dEMYq+xwNtiUAkaQI19r2bnoEVLjXGg7-KRzNioHdhlQqtnIWYXVkT2b)/dNx9DVCtafk4r
			gYnabWyOK5LStuId082UXzqN = buWXB2m6rF8ze4h9E+xwNtiUAkaQI19r2bnoEVLjXGg7+Ad3Fesgh1qjup5nXB48km-aLfd5yZlDVCNnSzRMAKBFh6x/dNx9DVCtafk4r
		for dlb6TgxSrm0eHB in ssUxeQqny1:
			if not dlb6TgxSrm0eHB or (dlb6TgxSrm0eHB and ord(dlb6TgxSrm0eHB[xn867tCVlscY4qbWZfh])==zDSw8LCxMQyraeXhojIWKmU(u"࠶࠶࠴࠺࠽௳")): continue
			PzL0lYGOIR6fpSsXaNib = dlb6TgxSrm0eHB.split(MlTVLBZ92kzorIq1Yw(u"ࠩࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ୛"),jxCVeKSLb9rGDOl0Qtw6)
			UUA4MySpzO6XmZHRBaueQC = dlb6TgxSrm0eHB.split(NupI74tJCzYXmles9SbR6(u"ࠪࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭ଡ଼"),jxCVeKSLb9rGDOl0Qtw6)
			wY8TtpyUqnz = dlb6TgxSrm0eHB.split(MlTVLBZ92kzorIq1Yw(u"ࠫࡤ࡫࡮ࡥࡥࡲࡰࡴࡸ࡟ࠨଢ଼"),jxCVeKSLb9rGDOl0Qtw6)
			OEBeNIfV2J8yz651T3AXm97 = dlb6TgxSrm0eHB.split(RRbvqditj184m3(u"ࠬࡥ࡬ࡪࡰࡨࡶࡹࡲ࡟ࠨ୞"),jxCVeKSLb9rGDOl0Qtw6)
			V0NEJgBfvHD9WACsG = dlb6TgxSrm0eHB.split(YZXtBgvUPoM5sb(u"࠭࡟࡭࡫ࡱࡩࡱ࡫ࡦࡵࡡࠪୟ"),jxCVeKSLb9rGDOl0Qtw6)
			NUrHR8k4LTzv73Cmxjog9q = dlb6TgxSrm0eHB.split(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡠ࡮࡬ࡲࡪࡸࡩࡨࡪࡷࡣࠬୠ"),jxCVeKSLb9rGDOl0Qtw6)
			cAhVsiGwWUMjZ0la = dlb6TgxSrm0eHB.split(RRbvqditj184m3(u"ࠨࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧୡ"),jxCVeKSLb9rGDOl0Qtw6)
			if len(PzL0lYGOIR6fpSsXaNib)>jxCVeKSLb9rGDOl0Qtw6:
				RREBo6v78JAsya0b4ZPmI += jxCVeKSLb9rGDOl0Qtw6
				dlb6TgxSrm0eHB = PzL0lYGOIR6fpSsXaNib[jxCVeKSLb9rGDOl0Qtw6]
				ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM = xn867tCVlscY4qbWZfh
				TK9uob1J78OM3RN2 = fjtDY1m9NJqyhE[RREBo6v78JAsya0b4ZPmI]
				wGZECtxoyuSJhYj5MUFsHm2 += GryAkP8gN1fZc25mTbOEBJYuQW7D
				RmQXpdTMVYfNOk = yrcbRSFswvAfEdIWVj
			elif len(UUA4MySpzO6XmZHRBaueQC)>jxCVeKSLb9rGDOl0Qtw6:
				dlb6TgxSrm0eHB = UUA4MySpzO6XmZHRBaueQC[jxCVeKSLb9rGDOl0Qtw6]
				tJYLnzMrZQS65uU = dlb6TgxSrm0eHB[xn867tCVlscY4qbWZfh:Ducd5PRjQXaB9SIN7VrJ1G(u"࠹௴")]
				tJYLnzMrZQS65uU = q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࠦࠫୢ")+tJYLnzMrZQS65uU[dNx9DVCtafk4r:]
				dlb6TgxSrm0eHB = dlb6TgxSrm0eHB[YZXtBgvUPoM5sb(u"࠻௵"):]
			elif len(wY8TtpyUqnz)>jxCVeKSLb9rGDOl0Qtw6:
				dlb6TgxSrm0eHB = wY8TtpyUqnz[jxCVeKSLb9rGDOl0Qtw6]
				tJYLnzMrZQS65uU = dwzfpL14c28jHbY
			elif len(OEBeNIfV2J8yz651T3AXm97)>jxCVeKSLb9rGDOl0Qtw6:
				dlb6TgxSrm0eHB = OEBeNIfV2J8yz651T3AXm97[jxCVeKSLb9rGDOl0Qtw6]
				RmQXpdTMVYfNOk = w8Ui6RsVhSPrqHfO4
				ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM = t2ZCAVPFbaBL5Y0dvicKoTGHe[RREBo6v78JAsya0b4ZPmI]
			elif len(V0NEJgBfvHD9WACsG)>KJLkQsqSHMR1Np2(u"࠴௶"): dlb6TgxSrm0eHB = V0NEJgBfvHD9WACsG[jxCVeKSLb9rGDOl0Qtw6]
			elif len(NUrHR8k4LTzv73Cmxjog9q)>FAwWlRJg0UkN1(u"࠵௷"): dlb6TgxSrm0eHB = NUrHR8k4LTzv73Cmxjog9q[jxCVeKSLb9rGDOl0Qtw6]
			elif len(cAhVsiGwWUMjZ0la)>zDSw8LCxMQyraeXhojIWKmU(u"࠶௸"): dlb6TgxSrm0eHB = cAhVsiGwWUMjZ0la[jxCVeKSLb9rGDOl0Qtw6]
			if dlb6TgxSrm0eHB:
				j1mhDok9YlC3PXL5dgxQwcbtA0EZ = gYnabWyOK5LStuId082UXzqN+wGZECtxoyuSJhYj5MUFsHm2
				dlb6TgxSrm0eHB = rp2sN3VWncqZGwaAv.get_display(dlb6TgxSrm0eHB)
				l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ,HYq3NdTMQ40jGyfuvIoBRgEa5ZCK18 = lQa5sSWr1Xp7YVOGUybqeTxftjoF.textsize(dlb6TgxSrm0eHB,font=Jelm3jRiPrk6)
				if RmQXpdTMVYfNOk: ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM -= l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ
				fRnTbGOVAMrSpXFu0oCawKBthq = TK9uob1J78OM3RN2+ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM
				lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((fRnTbGOVAMrSpXFu0oCawKBthq,j1mhDok9YlC3PXL5dgxQwcbtA0EZ),dlb6TgxSrm0eHB,font=Jelm3jRiPrk6,fill=tJYLnzMrZQS65uU)
				if FazXB3n2d8Ik67rl==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭ୣ"): lQa5sSWr1Xp7YVOGUybqeTxftjoF.text((fRnTbGOVAMrSpXFu0oCawKBthq+jxCVeKSLb9rGDOl0Qtw6,j1mhDok9YlC3PXL5dgxQwcbtA0EZ+jxCVeKSLb9rGDOl0Qtw6),dlb6TgxSrm0eHB,font=Jelm3jRiPrk6,fill=tJYLnzMrZQS65uU)
				if not RmQXpdTMVYfNOk: ExTS19Cjc7oLuHsmd6f2lwrRn0F8DM += l87ljWxEJmDNF4RHuM6gKz2Qhp5TAZ
				if j1mhDok9YlC3PXL5dgxQwcbtA0EZ>ZwJ65dEMYq+GryAkP8gN1fZc25mTbOEBJYuQW7D: break
	if FazXB3n2d8Ik67rl==IXE6voNmrb182AyQ(u"ࠫࡲ࡫࡮ࡶࡡ࡬ࡸࡪࡳࠧ୤"):
		swYp1y4mgHN = Ya76FIoZOWuEj9e.copy()
		RyfYSek61do5OnQMc.sleep(TeYukOUW7i5NBM926DCjaAn0(u"࠶࠮࠱࠷௹"))
		swYp1y4mgHN.paste(CN67qnDpuRAtXYecHoG,(xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh),mask=V1XiDsobKI)
	else: swYp1y4mgHN = V1XiDsobKI
	if cAIRPFK6boejVU549WzqBGCaJ0r: USLRxXjO1k0cM5zBrpG = USLRxXjO1k0cM5zBrpG.decode(JJQFjSIlALchiMzG9)
	try: swYp1y4mgHN.save(USLRxXjO1k0cM5zBrpG)
	except UnicodeError:
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			USLRxXjO1k0cM5zBrpG = USLRxXjO1k0cM5zBrpG.encode(JJQFjSIlALchiMzG9)
			swYp1y4mgHN.save(USLRxXjO1k0cM5zBrpG)
	return MUYv8PQV3TR6qy4S9Ch
def X2qjcN7u9FwbZTY(Dar0gLWdR8KHOGjY51weBQE,Jelm3jRiPrk6,K78rUnaQukAyhpRZbBEqjVc,EAV560B4aF8Q,UMsncFQ8W2fJat,Zd97cWzvXCjJnwyk0D28r16PfT5t):
	yh5M431fjnZoGDgIELKQpJ8v2YNrT,QQEcJBhM5Zd94k,NZPg08pQBJUO9yi1jYsW4uXMEVmkh = gby0BnUuTNFk,xn867tCVlscY4qbWZfh,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠱࠶࠲࠳࠴௺")
	K78rUnaQukAyhpRZbBEqjVc = K78rUnaQukAyhpRZbBEqjVc.replace(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭୥"),n6JjFHfmydIaLut(u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ୦"))
	xMsX98r4WnhwambKzYV3Cqlg1FLp = UMsncFQ8W2fJat-EAV560B4aF8Q*dNx9DVCtafk4r
	for HtpJh2VMxKL8l3 in K78rUnaQukAyhpRZbBEqjVc.splitlines():
		QQEcJBhM5Zd94k += Zd97cWzvXCjJnwyk0D28r16PfT5t
		X1PsiVtgkzjON0AuUf6pQvdEy,E2DPvA6CjZH7nze9xS5k = xn867tCVlscY4qbWZfh,gby0BnUuTNFk
		for Q6RUFLltKamChy5BZjvJHNoG74WMd in HtpJh2VMxKL8l3.split(UpN1CezytPO9XoduhxZSD):
			ZLWHx6oie7Gmwuk2S = W4oV2PYyjvQ(UpN1CezytPO9XoduhxZSD+Q6RUFLltKamChy5BZjvJHNoG74WMd)
			M0p5jlVAewHcxkg3,CY7Mit9wDKozdQcR1fJXsBhSn64a = Dar0gLWdR8KHOGjY51weBQE.textsize(ZLWHx6oie7Gmwuk2S,font=Jelm3jRiPrk6)
			if X1PsiVtgkzjON0AuUf6pQvdEy+M0p5jlVAewHcxkg3<xMsX98r4WnhwambKzYV3Cqlg1FLp:
				if not E2DPvA6CjZH7nze9xS5k: E2DPvA6CjZH7nze9xS5k += Q6RUFLltKamChy5BZjvJHNoG74WMd
				else: E2DPvA6CjZH7nze9xS5k += UpN1CezytPO9XoduhxZSD+Q6RUFLltKamChy5BZjvJHNoG74WMd
				X1PsiVtgkzjON0AuUf6pQvdEy += M0p5jlVAewHcxkg3
			else:
				if M0p5jlVAewHcxkg3<xMsX98r4WnhwambKzYV3Cqlg1FLp:
					E2DPvA6CjZH7nze9xS5k += IXE6voNmrb182AyQ(u"ࠧ࡝ࡰࠣࠫ୧")+Q6RUFLltKamChy5BZjvJHNoG74WMd
					QQEcJBhM5Zd94k += Zd97cWzvXCjJnwyk0D28r16PfT5t
					X1PsiVtgkzjON0AuUf6pQvdEy = M0p5jlVAewHcxkg3
				else:
					while M0p5jlVAewHcxkg3>xMsX98r4WnhwambKzYV3Cqlg1FLp:
						for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(jxCVeKSLb9rGDOl0Qtw6,len(UpN1CezytPO9XoduhxZSD+Q6RUFLltKamChy5BZjvJHNoG74WMd),jxCVeKSLb9rGDOl0Qtw6):
							bqJusv895SHCERZUYt4kIWmAj6OFM2 = UpN1CezytPO9XoduhxZSD+Q6RUFLltKamChy5BZjvJHNoG74WMd[:ZOfCnxmPUWEpvBVtYj5RSDMrcd]
							sygqwoRtWVv0UG = Q6RUFLltKamChy5BZjvJHNoG74WMd[ZOfCnxmPUWEpvBVtYj5RSDMrcd:]
							XOR10rQo63xJmDt = W4oV2PYyjvQ(bqJusv895SHCERZUYt4kIWmAj6OFM2)
							R1DBAGJl4esfgZzN5UaxMKCH3Wrc,kwsoBMlOqGnS3bRThzriVdQYZA0y = Dar0gLWdR8KHOGjY51weBQE.textsize(XOR10rQo63xJmDt,font=Jelm3jRiPrk6)
							if X1PsiVtgkzjON0AuUf6pQvdEy+R1DBAGJl4esfgZzN5UaxMKCH3Wrc>xMsX98r4WnhwambKzYV3Cqlg1FLp:
								JCozOWKycUst2 = M0p5jlVAewHcxkg3-R1DBAGJl4esfgZzN5UaxMKCH3Wrc
								E2DPvA6CjZH7nze9xS5k += bqJusv895SHCERZUYt4kIWmAj6OFM2+okfdjS4RmM
								QQEcJBhM5Zd94k += Zd97cWzvXCjJnwyk0D28r16PfT5t
								M0p5jlVAewHcxkg3 = JCozOWKycUst2
								if JCozOWKycUst2>xMsX98r4WnhwambKzYV3Cqlg1FLp:
									X1PsiVtgkzjON0AuUf6pQvdEy = xn867tCVlscY4qbWZfh
									Q6RUFLltKamChy5BZjvJHNoG74WMd = sygqwoRtWVv0UG
								else:
									X1PsiVtgkzjON0AuUf6pQvdEy = JCozOWKycUst2
									E2DPvA6CjZH7nze9xS5k += sygqwoRtWVv0UG
								break
				if QQEcJBhM5Zd94k>NZPg08pQBJUO9yi1jYsW4uXMEVmkh: break
		yh5M431fjnZoGDgIELKQpJ8v2YNrT += okfdjS4RmM+E2DPvA6CjZH7nze9xS5k
		if QQEcJBhM5Zd94k>NZPg08pQBJUO9yi1jYsW4uXMEVmkh: break
	yh5M431fjnZoGDgIELKQpJ8v2YNrT = yh5M431fjnZoGDgIELKQpJ8v2YNrT[jxCVeKSLb9rGDOl0Qtw6:]
	yh5M431fjnZoGDgIELKQpJ8v2YNrT = yh5M431fjnZoGDgIELKQpJ8v2YNrT.replace(VzO1gCHmjZ2ebRIL(u"ࠨ࡝ࡆࡓࡑࡕࡒ࠻࠼࠽ࠫ୨"),FAwWlRJg0UkN1(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ୩"))
	return yh5M431fjnZoGDgIELKQpJ8v2YNrT
def W4oV2PYyjvQ(Q6RUFLltKamChy5BZjvJHNoG74WMd):
	if YZXtBgvUPoM5sb(u"ࠪ࡟ࠬ୪") in Q6RUFLltKamChy5BZjvJHNoG74WMd and iiauUxMktNW5X(u"ࠫࡢ࠭୫") in Q6RUFLltKamChy5BZjvJHNoG74WMd:
		Y5OmzMsLIaVghv4t = [GGy0cQe765nPYZ9E8Th,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬࡡ࠯ࡓࡖࡏࡡࠬ୬"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"࡛࠭࠰ࡎࡈࡊ࡙ࡣࠧ୭"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧ࡜࠱ࡕࡍࡌࡎࡔ࡞ࠩ୮"),RRbvqditj184m3(u"ࠨ࡝࠲ࡇࡊࡔࡔࡆࡔࡠࠫ୯"),n6JjFHfmydIaLut(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ୰"),iiLyoNwGbH03DIXhAkZn(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪୱ"),iiLyoNwGbH03DIXhAkZn(u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ୲"),RRbvqditj184m3(u"ࠬࡡࡃࡆࡐࡗࡉࡗࡣࠧ୳")]
		uGNta2ScW5n8riQf7BoMyVsDPY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(VzO1gCHmjZ2ebRIL(u"࠭࡜࡜ࡅࡒࡐࡔࡘࠠ࠯ࠬࡂࡠࡢ࠭୴"),Q6RUFLltKamChy5BZjvJHNoG74WMd,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		DtCgiulAdXEUvhMw53Np = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(KJLkQsqSHMR1Np2(u"ࠧ࡝࡝ࡆࡓࡑࡕࡒ࠻࠼࠽࠲࠯ࡅ࡜࡞ࠩ୵"),Q6RUFLltKamChy5BZjvJHNoG74WMd,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		oWLa03YyFhpTUMeJmgZCsHjr2ItV = Y5OmzMsLIaVghv4t+uGNta2ScW5n8riQf7BoMyVsDPY+DtCgiulAdXEUvhMw53Np
		for U1UnS0ltM3DzquBdZhPp in oWLa03YyFhpTUMeJmgZCsHjr2ItV: Q6RUFLltKamChy5BZjvJHNoG74WMd = Q6RUFLltKamChy5BZjvJHNoG74WMd.replace(U1UnS0ltM3DzquBdZhPp,gby0BnUuTNFk)
	return Q6RUFLltKamChy5BZjvJHNoG74WMd
def vyEk6LBlHzgTm1hoc3QMix4fda(fbmZ9V58PCTz):
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(okfdjS4RmM,OUFxZPuXDoGAbRz(u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ୶"))
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(IXE6voNmrb182AyQ(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ୷"),BarIC3eR9bS(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡲࡵ࡮ࡢࠫ୸"))
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(mmbcsf2pd7gyjzreB(u"ࠫࡠࡒࡅࡇࡖࡠࠫ୹"),ggtuNcvTn3HQ7SpE2(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ୺"))
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(n6JjFHfmydIaLut(u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ୻"),iI7tuF0nEQoR(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ୼"))
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(iiLyoNwGbH03DIXhAkZn(u"ࠨ࡝ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ୽"),n6JjFHfmydIaLut(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭୾"))
	fbmZ9V58PCTz = fbmZ9V58PCTz.replace(GGy0cQe765nPYZ9E8Th,BarIC3eR9bS(u"ࠪࡣࡸࡹࡳࡠࡡࡨࡲࡩࡩ࡯࡭ࡱࡵࡣࠬ୿"))
	sdXRKGJucfEmBUkAtQOvyzMLiNw = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠮࠮ࠫࡁࠬࡠࡢ࠭஀"),fbmZ9V58PCTz,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for JJiXl9fpYRmrE in sdXRKGJucfEmBUkAtQOvyzMLiNw: fbmZ9V58PCTz = fbmZ9V58PCTz.replace(OUFxZPuXDoGAbRz(u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭஁")+JJiXl9fpYRmrE+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࡝ࠨஂ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨஃ")+JJiXl9fpYRmrE+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡡࠪ஄"))
	return fbmZ9V58PCTz