﻿# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,ZzqfXdOP6ewhAGIkxiC21Eu3W5F):
	if ZzqfXdOP6ewhAGIkxiC21Eu3W5F==gby0BnUuTNFk: return
	if mi63FgbZoVerXaTGNhsUkuR0ILQW==1:
		FA7pWnT8xtdIRbOlVgemMD4q2 = SxtK1ciEvLXRAWFVfQDOMgBYC.getCurrentWindowDialogId()
		ttK2pVxeZrvfbH8NmEy9GsIDQFkTU = SxtK1ciEvLXRAWFVfQDOMgBYC.Window(FA7pWnT8xtdIRbOlVgemMD4q2)
		ZzqfXdOP6ewhAGIkxiC21Eu3W5F = ThtMBSPziG0jZr9sHYCKa(ZzqfXdOP6ewhAGIkxiC21Eu3W5F)
		ttK2pVxeZrvfbH8NmEy9GsIDQFkTU.getControl(311).setLabel(ZzqfXdOP6ewhAGIkxiC21Eu3W5F)
	if mi63FgbZoVerXaTGNhsUkuR0ILQW==0:
		OORugdCwcD9UrzXtT7vML1FWasP='X'
		if nqkybtoMBH: lrfb2QcU8KGCmJgh1LwS73kBNeyxV = isinstance(ZzqfXdOP6ewhAGIkxiC21Eu3W5F,str)
		else: lrfb2QcU8KGCmJgh1LwS73kBNeyxV = isinstance(ZzqfXdOP6ewhAGIkxiC21Eu3W5F,unicode)
		if lrfb2QcU8KGCmJgh1LwS73kBNeyxV==True: OORugdCwcD9UrzXtT7vML1FWasP='U'
		GGs5D4cqQHX0jr=str(type(ZzqfXdOP6ewhAGIkxiC21Eu3W5F))+UpN1CezytPO9XoduhxZSD+ZzqfXdOP6ewhAGIkxiC21Eu3W5F+UpN1CezytPO9XoduhxZSD+OORugdCwcD9UrzXtT7vML1FWasP+UpN1CezytPO9XoduhxZSD
		for xuX6UN0WRQbHArDV in range(0,len(ZzqfXdOP6ewhAGIkxiC21Eu3W5F),1):
			GGs5D4cqQHX0jr += hex(ord(ZzqfXdOP6ewhAGIkxiC21Eu3W5F[xuX6UN0WRQbHArDV])).replace('0x',gby0BnUuTNFk)+UpN1CezytPO9XoduhxZSD
		ZzqfXdOP6ewhAGIkxiC21Eu3W5F = ThtMBSPziG0jZr9sHYCKa(ZzqfXdOP6ewhAGIkxiC21Eu3W5F)
		OORugdCwcD9UrzXtT7vML1FWasP='X'
		if nqkybtoMBH: lrfb2QcU8KGCmJgh1LwS73kBNeyxV = isinstance(ZzqfXdOP6ewhAGIkxiC21Eu3W5F, str)
		else: lrfb2QcU8KGCmJgh1LwS73kBNeyxV = isinstance(ZzqfXdOP6ewhAGIkxiC21Eu3W5F, unicode)
		if lrfb2QcU8KGCmJgh1LwS73kBNeyxV==True: OORugdCwcD9UrzXtT7vML1FWasP='U'
		PtIN1Z5s4U=str(type(ZzqfXdOP6ewhAGIkxiC21Eu3W5F))+UpN1CezytPO9XoduhxZSD+ZzqfXdOP6ewhAGIkxiC21Eu3W5F+UpN1CezytPO9XoduhxZSD+OORugdCwcD9UrzXtT7vML1FWasP+UpN1CezytPO9XoduhxZSD
		for xuX6UN0WRQbHArDV in range(0,len(ZzqfXdOP6ewhAGIkxiC21Eu3W5F),1):
			PtIN1Z5s4U += hex(ord(ZzqfXdOP6ewhAGIkxiC21Eu3W5F[xuX6UN0WRQbHArDV])).replace('0x',gby0BnUuTNFk)+UpN1CezytPO9XoduhxZSD
	return