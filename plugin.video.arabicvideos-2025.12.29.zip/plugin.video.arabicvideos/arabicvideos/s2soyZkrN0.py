# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'EGYBEST3'
JB9fyoHr05QOtPjp = '_EB3_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,kdwXYDMQOjz51Z08W,text):
	if   mode==790: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==791: WjryKiBebavP = Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W)
	elif mode==792: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==793: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==796: WjryKiBebavP = KKUF2Xzv518hY(url,kdwXYDMQOjz51Z08W)
	elif mode==799: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('list-pages(.*?)fa-folder',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)</span>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-article(.*?)social-box',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-title.*?">(.*?)<.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,SSqweDUBYv4bkO in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791,gby0BnUuTNFk,'mainmenu')
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-menu(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791)
	return jS6fQGXeouTB7xKd32ZMy
def KKUF2Xzv518hY(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-SEASONS_EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-article".*?">(.*?)<(.*?)article',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		QYjhVM3NwTm5l,JsAt0zywiZXQM3YKvnG6ClDq7N8L,items = gby0BnUuTNFk,gby0BnUuTNFk,[]
		for name,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			if 'حلقات' in name: JsAt0zywiZXQM3YKvnG6ClDq7N8L = AxiBv1cQueOs0
			if 'مواسم' in name: QYjhVM3NwTm5l = AxiBv1cQueOs0
		if QYjhVM3NwTm5l and not type:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',QYjhVM3NwTm5l,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if len(items)>1:
				for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,796,T6TRUSbecYGWIq29KF,'season')
		if JsAt0zywiZXQM3YKvnG6ClDq7N8L and len(items)<2:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',JsAt0zywiZXQM3YKvnG6ClDq7N8L,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if items:
				for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
					ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,793,T6TRUSbecYGWIq29KF)
			else:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',JsAt0zywiZXQM3YKvnG6ClDq7N8L,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				for SSqweDUBYv4bkO,title in items:
					ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,793)
	return
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	ZtKQh02YIoDfuFxUXz9,start,mKXQ5VxyYE81ZhAB2bCLduocF,select,PjB71C9rniV = 0,0,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	if 'pagination' in type:
		JvZoN3mt7w9F2eOKyplYf,data = avXHrARzQuBW4s(url)
		ZtKQh02YIoDfuFxUXz9 = int(data['limit'])
		start = int(data['start'])
		mKXQ5VxyYE81ZhAB2bCLduocF = data['type']
		select = data['select']
		uWIUplrbFd = 'limit='+str(ZtKQh02YIoDfuFxUXz9)+'&start='+str(start)+'&type='+mKXQ5VxyYE81ZhAB2bCLduocF+'&select='+select
		IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',JvZoN3mt7w9F2eOKyplYf,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		N84Yo7V9qS = 'blocks'+jS6fQGXeouTB7xKd32ZMy+'article'
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		N84Yo7V9qS = jS6fQGXeouTB7xKd32ZMy
		code = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if code:
			code = code[0].replace('var',gby0BnUuTNFk).replace(UpN1CezytPO9XoduhxZSD,gby0BnUuTNFk).replace("'",gby0BnUuTNFk).replace(';','&')
			WDxo5FVQtNn7UaTlq6,data = avXHrARzQuBW4s('?'+code)
			ZtKQh02YIoDfuFxUXz9 = int(data['limit'])
			start = int(data['start'])
			mKXQ5VxyYE81ZhAB2bCLduocF = data['type']
			select = data['select']
			PjB71C9rniV = data['ajaxurl']
			uWIUplrbFd = 'limit='+str(ZtKQh02YIoDfuFxUXz9)+'&start='+str(start)+'&type='+mKXQ5VxyYE81ZhAB2bCLduocF+'&select='+select
			JvZoN3mt7w9F2eOKyplYf = LhFnEIuPHdoNc+PjB71C9rniV
			IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded'}
			ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',JvZoN3mt7w9F2eOKyplYf,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-TITLES-3rd')
			N84Yo7V9qS = ccV0NKHwQpMun6FtZvAi.content
			N84Yo7V9qS = 'blocks'+N84Yo7V9qS+'article'
	items,Emr2jSpWsh81igTqMfVDlbey67,AiG7kxETBYMw15 = [],False,False
	if not type:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-content(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791,gby0BnUuTNFk,'submenu')
				Emr2jSpWsh81igTqMfVDlbey67 = True
	if not type:
		AiG7kxETBYMw15 = jeDm0qKNk4nVc35(jS6fQGXeouTB7xKd32ZMy)
	if not Emr2jSpWsh81igTqMfVDlbey67 and not AiG7kxETBYMw15:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('blocks(.*?)article',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
				T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.strip(okfdjS4RmM)
				SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
				if '/selary/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791,T6TRUSbecYGWIq29KF)
				elif 'مسلسل' in SSqweDUBYv4bkO and 'حلقة' not in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,796,T6TRUSbecYGWIq29KF)
				elif 'موسم' in SSqweDUBYv4bkO and 'حلقة' not in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,796,T6TRUSbecYGWIq29KF)
				else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,793,T6TRUSbecYGWIq29KF)
		ppNcItuL8fqZr6V = 12
		data = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="(load-more.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)==ppNcItuL8fqZr6V and (data or 'pagination' in type):
			uWIUplrbFd = 'limit='+str(ppNcItuL8fqZr6V)+'&start='+str(start+ppNcItuL8fqZr6V)+'&type='+mKXQ5VxyYE81ZhAB2bCLduocF+'&select='+select
			Tf5ueYGZIFl1hraoEOVKi = JvZoN3mt7w9F2eOKyplYf+'?next=page&'+uWIUplrbFd
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'المزيد',Tf5ueYGZIFl1hraoEOVKi,791,gby0BnUuTNFk,'pagination_'+type)
	return
def jeDm0qKNk4nVc35(jS6fQGXeouTB7xKd32ZMy):
	AiG7kxETBYMw15 = False
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-article(.*?)article',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if bXMpofzj7h: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		for zTFlfH8DhAVryqUjX,name,AxiBv1cQueOs0 in bXMpofzj7h:
			name = name.strip(UpN1CezytPO9XoduhxZSD)
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,value in items:
				title = name+':  '+value
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,791,gby0BnUuTNFk,'filter')
				AiG7kxETBYMw15 = True
	return AiG7kxETBYMw15
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST3-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ytc3dVjPkMHCSmlzvBuO820Q,LAzpDv0RCZE9yWIk3BXql1HuUjh = [],[]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('server-item.*?data-code="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for AJ1s3PxNoOu67 in items:
		ZT9fb4pG5HAdImi = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(AJ1s3PxNoOu67)
		if nqkybtoMBH: ZT9fb4pG5HAdImi = ZT9fb4pG5HAdImi.decode(JJQFjSIlALchiMzG9)
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)"',ZT9fb4pG5HAdImi,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if SSqweDUBYv4bkO:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
			if SSqweDUBYv4bkO not in LAzpDv0RCZE9yWIk3BXql1HuUjh:
				LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__watch')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="downloads(.*?)</section>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for DYNVS1Bbgs7,SSqweDUBYv4bkO in items:
			if SSqweDUBYv4bkO not in LAzpDv0RCZE9yWIk3BXql1HuUjh:
				if '/?url=' in SSqweDUBYv4bkO: SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('/?url=')[1]
				LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__download____'+DYNVS1Bbgs7)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(text):
	return