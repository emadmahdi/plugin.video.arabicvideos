# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
import bs4 as IIpjN2EPr64HJAns1mZeYB0
CC3nOPFMovd72u = 'ELCINEMA'
JB9fyoHr05QOtPjp = '_ELC_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
headers = {'Referer':LhFnEIuPHdoNc}
d2gCoAnYPG89O = []
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==510: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==511: WjryKiBebavP = yZTXMS5vKkouRcdgb3mU(url)
	elif mode==512: WjryKiBebavP = RY5naLxFlqvAur496UNchw2kX0(url)
	elif mode==513: WjryKiBebavP = WFjIM6YwANgivdVBX(url)
	elif mode==514: WjryKiBebavP = DDOwe07ibMNa8IsQ5BKhf23tnG6p(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: WjryKiBebavP = DDOwe07ibMNa8IsQ5BKhf23tnG6p(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: WjryKiBebavP = eeMK1sOZrbNABH8zxIPhJQc05LRGpq(text)
	elif mode==517: WjryKiBebavP = DtoRiTB0yMsN1k2(url)
	elif mode==518: WjryKiBebavP = HG9vxKj8uyZM5(url)
	elif mode==519: WjryKiBebavP = a3NI0EopMZw(text)
	elif mode==520: WjryKiBebavP = x2TqrHgNmGbkElM8oScDBysJiQ0z(url)
	elif mode==521: WjryKiBebavP = uc7P9RWfvLzdtUN0EV(url)
	elif mode==522: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==523: WjryKiBebavP = bB4ovn6dCXec7sPJSzwu1RHlkL9(text)
	elif mode==524: WjryKiBebavP = g4EhpuYd9qsW80LRDcU1nN5VoAtX3F()
	elif mode==525: WjryKiBebavP = lOA6aIysqpfw79LeBVg()
	elif mode==526: WjryKiBebavP = GKjdZBcFVi1YtlPkC0mArMa()
	elif mode==527: WjryKiBebavP = gmvcR1LIqrPe8hE23fYxWy4sD9()
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث بموسوعة السينما',gby0BnUuTNFk,519)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'موسوعة الأعمال',gby0BnUuTNFk,525)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'موسوعة الأشخاص',gby0BnUuTNFk,526)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'موسوعة المصنفات',gby0BnUuTNFk,527)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'موسوعة المنوعات',gby0BnUuTNFk,524)
	return
def g4EhpuYd9qsW80LRDcU1nN5VoAtX3F():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' فيديوهات - خاصة',LhFnEIuPHdoNc+'/video',520)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فيديوهات - أحدث',LhFnEIuPHdoNc+'/video/latest',521)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فيديوهات - أقدم',LhFnEIuPHdoNc+'/video/oldest',521)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فيديوهات - أكثر مشاهدة',LhFnEIuPHdoNc+'/video/views',521)
	return
def lOA6aIysqpfw79LeBVg():
	eeSGkQ1D5RIxfCpBMXlFVJ = LhFnEIuPHdoNc+'/lineup?utf8=%E2%9C%93'
	JowI8xNLX1u6H = eeSGkQ1D5RIxfCpBMXlFVJ+'&type=2&category=1&foreign=false&tag='
	bB1HTsKoGuwUj8l = eeSGkQ1D5RIxfCpBMXlFVJ+'&type=2&category=3&foreign=false&tag='
	p5eHkaEFIi026nSTfrK1X = eeSGkQ1D5RIxfCpBMXlFVJ+'&type=2&category=1&foreign=true&tag='
	cdyLhPoOIYmvqkpVR79a1gUEs4H = eeSGkQ1D5RIxfCpBMXlFVJ+'&type=2&category=3&foreign=true&tag='
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات أفلام عربي',JowI8xNLX1u6H,511)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات مسلسلات عربي',bB1HTsKoGuwUj8l,511)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات أفلام اجنبي',p5eHkaEFIi026nSTfrK1X,511)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات مسلسلات اجنبي',cdyLhPoOIYmvqkpVR79a1gUEs4H,511)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس أعمال أبجدي',LhFnEIuPHdoNc+'/index/work/alphabet',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس  بلد الإنتاج',LhFnEIuPHdoNc+'/index/work/country',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس اللغة',LhFnEIuPHdoNc+'/index/work/language',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس مصنفات العمل',LhFnEIuPHdoNc+'/index/work/genre',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس سنة الإصدار',LhFnEIuPHdoNc+'/index/work/release_year',517)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مواسم - فلتر محدد',LhFnEIuPHdoNc+'/seasonals',515)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مواسم - فلتر كامل',LhFnEIuPHdoNc+'/seasonals',514)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات - فلتر محدد',LhFnEIuPHdoNc+'/lineup',515)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات - فلتر كامل',LhFnEIuPHdoNc+'/lineup',514)
	return
def gmvcR1LIqrPe8hE23fYxWy4sD9():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc+'/lineup',gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	AxiBv1cQueOs0 = J8Bca9W3fkHsCTA.find('select',attrs={'name':'tag'})
	K7ETgQ2pb4ylWIB3vDHjJ = AxiBv1cQueOs0.find_all('option')
	for w7su60daQz13VIplrfxJk in K7ETgQ2pb4ylWIB3vDHjJ:
		value = w7su60daQz13VIplrfxJk.get('value')
		if not value: continue
		title = w7su60daQz13VIplrfxJk.text
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.encode(JJQFjSIlALchiMzG9)
			value = value.encode(JJQFjSIlALchiMzG9)
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',gby0BnUuTNFk)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,511)
	return
def GKjdZBcFVi1YtlPkC0mArMa():
	eeSGkQ1D5RIxfCpBMXlFVJ = LhFnEIuPHdoNc+'/lineup?utf8=%E2%9C%93'
	cX6y1lL0qeKMNY = eeSGkQ1D5RIxfCpBMXlFVJ+'&type=1&category=&foreign=&tag='
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات أشخاص',cX6y1lL0qeKMNY,511)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس أشخاص أبجدي',LhFnEIuPHdoNc+'/index/person/alphabet',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس موطن',LhFnEIuPHdoNc+'/index/person/nationality',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس  تاريخ الميلاد',LhFnEIuPHdoNc+'/index/person/birth_year',517)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فهرس  تاريخ الوفاة',LhFnEIuPHdoNc+'/index/person/death_year',517)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات - فلتر محدد',LhFnEIuPHdoNc+'/lineup',515)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مصنفات - فلتر كامل',LhFnEIuPHdoNc+'/lineup',514)
	return
def yZTXMS5vKkouRcdgb3mU(url):
	if '/seasonals' in url: xYDJcGlC5PSFpRaX03nLNjZO2Uqum = 0
	elif '/lineup' in url: xYDJcGlC5PSFpRaX03nLNjZO2Uqum = 1
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-LISTS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	bXMpofzj7h = J8Bca9W3fkHsCTA.find_all(class_='jumbo-theater clearfix')
	for AxiBv1cQueOs0 in bXMpofzj7h:
		title = AxiBv1cQueOs0.find_all('a')[xYDJcGlC5PSFpRaX03nLNjZO2Uqum].text
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+AxiBv1cQueOs0.find_all('a')[xYDJcGlC5PSFpRaX03nLNjZO2Uqum].get('href')
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
		if not bXMpofzj7h:
			RY5naLxFlqvAur496UNchw2kX0(SSqweDUBYv4bkO)
			return
		else:
			title = title.replace('قائمة ',gby0BnUuTNFk)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,512)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(J8Bca9W3fkHsCTA,511)
	return
def mXreMsKFhIB1PqT0OQ8uLdGvi3w(J8Bca9W3fkHsCTA,mode):
	AxiBv1cQueOs0 = J8Bca9W3fkHsCTA.find(class_='pagination')
	if AxiBv1cQueOs0:
		aZOlrCywGMpgKI5D6URS4i = AxiBv1cQueOs0.find_all('a')
		uQnmASC2Z8ctprwi = AxiBv1cQueOs0.find_all('li')
		qqfsiLlbaApEBGc9g3Hnzm1k8hx = list(zip(aZOlrCywGMpgKI5D6URS4i,uQnmASC2Z8ctprwi))
		t3t986iTduqY = -1
		ppNcItuL8fqZr6V = len(qqfsiLlbaApEBGc9g3Hnzm1k8hx)
		for ZmaDvrNx5TAYU3,H9H8TFgbthWnzRr in qqfsiLlbaApEBGc9g3Hnzm1k8hx:
			t3t986iTduqY += 1
			H9H8TFgbthWnzRr = H9H8TFgbthWnzRr['class']
			if 'unavailable' in H9H8TFgbthWnzRr or 'current' in H9H8TFgbthWnzRr: continue
			sMiRfjzPx90H8mEpD = ZmaDvrNx5TAYU3.text
			RkntpA1UJDV4vNgyaex6GPWK9YQIcC = LhFnEIuPHdoNc+ZmaDvrNx5TAYU3.get('href')
			if cAIRPFK6boejVU549WzqBGCaJ0r:
				sMiRfjzPx90H8mEpD = sMiRfjzPx90H8mEpD.encode(JJQFjSIlALchiMzG9)
				RkntpA1UJDV4vNgyaex6GPWK9YQIcC = RkntpA1UJDV4vNgyaex6GPWK9YQIcC.encode(JJQFjSIlALchiMzG9)
			if   t3t986iTduqY==0: sMiRfjzPx90H8mEpD = 'أولى'
			elif t3t986iTduqY==1: sMiRfjzPx90H8mEpD = 'سابقة'
			elif t3t986iTduqY==ppNcItuL8fqZr6V-2: sMiRfjzPx90H8mEpD = 'لاحقة'
			elif t3t986iTduqY==ppNcItuL8fqZr6V-1: sMiRfjzPx90H8mEpD = 'أخيرة'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+sMiRfjzPx90H8mEpD,RkntpA1UJDV4vNgyaex6GPWK9YQIcC,mode)
	return
def RY5naLxFlqvAur496UNchw2kX0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-TITLES1-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	bXMpofzj7h = J8Bca9W3fkHsCTA.find_all(class_='row')
	items,FzlcxgOGN3VoikMnbTW = [],True
	for AxiBv1cQueOs0 in bXMpofzj7h:
		if not AxiBv1cQueOs0.find(class_='thumbnail-wrapper'): continue
		if FzlcxgOGN3VoikMnbTW: FzlcxgOGN3VoikMnbTW = False ; continue
		MjCuosVzZLEferqvpgGcAdIO7iQ = []
		dk6bPWYIoV85iz0xLGa3KgJMl = AxiBv1cQueOs0.find_all(class_=['censorship red','censorship purple'])
		for DPhJCuevW7tOpsMa6oHjXnYT in dk6bPWYIoV85iz0xLGa3KgJMl:
			AnPViDKlOpB0 = DPhJCuevW7tOpsMa6oHjXnYT.find_all('li')[1].text
			if cAIRPFK6boejVU549WzqBGCaJ0r:
				AnPViDKlOpB0 = AnPViDKlOpB0.encode(JJQFjSIlALchiMzG9)
			MjCuosVzZLEferqvpgGcAdIO7iQ.append(AnPViDKlOpB0)
		if not OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,gby0BnUuTNFk,MjCuosVzZLEferqvpgGcAdIO7iQ,False):
			gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('data-src')
			title = AxiBv1cQueOs0.find('h3')
			name = title.find('a').text
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+title.find('a').get('href')
			QPzHVsASIln02BxbOGNy7ciKd = AxiBv1cQueOs0.find(class_='no-margin')
			PPUvgMjsBZhI = AxiBv1cQueOs0.find(class_='legend')
			if QPzHVsASIln02BxbOGNy7ciKd: QPzHVsASIln02BxbOGNy7ciKd = QPzHVsASIln02BxbOGNy7ciKd.text
			if PPUvgMjsBZhI: PPUvgMjsBZhI = PPUvgMjsBZhI.text
			if cAIRPFK6boejVU549WzqBGCaJ0r:
				gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.encode(JJQFjSIlALchiMzG9)
				name = name.encode(JJQFjSIlALchiMzG9)
				SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
				if QPzHVsASIln02BxbOGNy7ciKd: QPzHVsASIln02BxbOGNy7ciKd = QPzHVsASIln02BxbOGNy7ciKd.encode(JJQFjSIlALchiMzG9)
			ZgSKTRL2DlPprjU57W93zf4EF = {}
			if PPUvgMjsBZhI: ZgSKTRL2DlPprjU57W93zf4EF['stars'] = PPUvgMjsBZhI
			if QPzHVsASIln02BxbOGNy7ciKd:
				QPzHVsASIln02BxbOGNy7ciKd = QPzHVsASIln02BxbOGNy7ciKd.replace(okfdjS4RmM,' .. ')
				ZgSKTRL2DlPprjU57W93zf4EF['plot'] = QPzHVsASIln02BxbOGNy7ciKd.replace('...اقرأ المزيد',gby0BnUuTNFk)
			if '/work/' in SSqweDUBYv4bkO:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,516,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name,gby0BnUuTNFk,ZgSKTRL2DlPprjU57W93zf4EF)
			elif '/person/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,513,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name,gby0BnUuTNFk,ZgSKTRL2DlPprjU57W93zf4EF)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(J8Bca9W3fkHsCTA,512)
	return
def WFjIM6YwANgivdVBX(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-TITLES2-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	bXMpofzj7h = J8Bca9W3fkHsCTA.find_all('li')
	PDCFEVTazt6,items = [],[]
	for AxiBv1cQueOs0 in bXMpofzj7h:
		if not AxiBv1cQueOs0.find(class_='thumbnail-wrapper'): continue
		if not AxiBv1cQueOs0.find(class_=['unstyled','unstyled text-center']): continue
		if AxiBv1cQueOs0.find(class_='hide'): continue
		title = AxiBv1cQueOs0.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in PDCFEVTazt6: continue
		PDCFEVTazt6.append(name)
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+title.find('a').get('href')
		if '/search/work/' in url: gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('src')
		elif '/search/person/' in url: gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('data-src')
		elif '/search/video/' in url: gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('data-src')
		else: gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('src')
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			name = name.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
			gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.encode(JJQFjSIlALchiMzG9)
		name = name.strip(UpN1CezytPO9XoduhxZSD)
		items.append((name,SSqweDUBYv4bkO,gQmur3iRSZ9IAOX))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,SSqweDUBYv4bkO,gQmur3iRSZ9IAOX in items:
		if '/search/video/' in url: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,522,gQmur3iRSZ9IAOX)
		elif '/search/person/' in url: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,513,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,516,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name)
	return
def eeMK1sOZrbNABH8zxIPhJQc05LRGpq(text):
	text = text.replace('الإعلان',gby0BnUuTNFk).replace('لفيلم',gby0BnUuTNFk).replace('الرسمي',gby0BnUuTNFk)
	text = text.replace('إعلان',gby0BnUuTNFk).replace('فيلم',gby0BnUuTNFk).replace('البرومو',gby0BnUuTNFk)
	text = text.replace('التشويقي',gby0BnUuTNFk).replace('لمسلسل',gby0BnUuTNFk).replace('مسلسل',gby0BnUuTNFk)
	text = text.replace(':',gby0BnUuTNFk).replace(')',gby0BnUuTNFk).replace('(',gby0BnUuTNFk).replace(',',gby0BnUuTNFk)
	text = text.replace('_',gby0BnUuTNFk).replace(';',gby0BnUuTNFk).replace('-',gby0BnUuTNFk).replace('.',gby0BnUuTNFk)
	text = text.replace('\'',gby0BnUuTNFk).replace('\"',gby0BnUuTNFk)
	text = text.replace(TFAVlh4ONfuyivg,UpN1CezytPO9XoduhxZSD).replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	text = text.strip(UpN1CezytPO9XoduhxZSD)
	aJw96ZMbBEjIRcsx1VpGnhmi7rSu = text.count(UpN1CezytPO9XoduhxZSD)+1
	if aJw96ZMbBEjIRcsx1VpGnhmi7rSu==1:
		bB4ovn6dCXec7sPJSzwu1RHlkL9(text)
		return
	ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'==== كلمات للبحث ===='+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	rVetTwYdJm9xny7Fq8L = text.split(UpN1CezytPO9XoduhxZSD)
	PApf3SayVFI = pow(2,aJw96ZMbBEjIRcsx1VpGnhmi7rSu)
	DQ2I9hVndaHCFx = []
	def b41X6Rxshk5LjUDVeft(f096WzClEin3Jpvbm4Z5dIjtBuy,zkesUwy3MSYPpu2):
		if f096WzClEin3Jpvbm4Z5dIjtBuy=='1': return zkesUwy3MSYPpu2
		return gby0BnUuTNFk
	for t3t986iTduqY in range(PApf3SayVFI,0,-1):
		XreujiUc9LmSlQGV5hyoBx1Ok3 = list(aJw96ZMbBEjIRcsx1VpGnhmi7rSu*'0'+bin(t3t986iTduqY)[2:])[-aJw96ZMbBEjIRcsx1VpGnhmi7rSu:]
		XreujiUc9LmSlQGV5hyoBx1Ok3 = reversed(XreujiUc9LmSlQGV5hyoBx1Ok3)
		bV0XGurMKTotw26qY1JWeEm9CZdfa = map(b41X6Rxshk5LjUDVeft,XreujiUc9LmSlQGV5hyoBx1Ok3,rVetTwYdJm9xny7Fq8L)
		title = UpN1CezytPO9XoduhxZSD.join(filter(None,bV0XGurMKTotw26qY1JWeEm9CZdfa))
		if cAIRPFK6boejVU549WzqBGCaJ0r: T3Yrx4yZCRqcH = title.decode(JJQFjSIlALchiMzG9)
		else: T3Yrx4yZCRqcH = title
		if len(T3Yrx4yZCRqcH)>2 and title not in DQ2I9hVndaHCFx:
			DQ2I9hVndaHCFx.append(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,523,gby0BnUuTNFk,gby0BnUuTNFk,title)
	return
def bB4ovn6dCXec7sPJSzwu1RHlkL9(dKZiTbEUxecXgBCD):
	if cAIRPFK6boejVU549WzqBGCaJ0r:
		dKZiTbEUxecXgBCD = dKZiTbEUxecXgBCD.decode(JJQFjSIlALchiMzG9)
		import arabic_reshaper as MUV4lvfptAbEgs5GhIr9CB6FuzHoN,bidi.algorithm as rp2sN3VWncqZGwaAv
		dKZiTbEUxecXgBCD = MUV4lvfptAbEgs5GhIr9CB6FuzHoN.ArabicReshaper().reshape(dKZiTbEUxecXgBCD)
		dKZiTbEUxecXgBCD = rp2sN3VWncqZGwaAv.get_display(dKZiTbEUxecXgBCD)
	import hazVQrxyDA
	dKZiTbEUxecXgBCD = vRoGedUjt2Ac6pIbufBX8sKy(OO25Id38BVPYQuTfwqoy6ZA=dKZiTbEUxecXgBCD)
	hazVQrxyDA.a3NI0EopMZw(dKZiTbEUxecXgBCD)
	return
def DtoRiTB0yMsN1k2(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-INDEXES_LISTS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	AxiBv1cQueOs0 = J8Bca9W3fkHsCTA.find(class_='list-separator list-title')
	K6ucHgjCtqf9wBZxXAUh3Db5EMJW = AxiBv1cQueOs0.find_all('a')
	items = []
	for title in K6ucHgjCtqf9wBZxXAUh3Db5EMJW:
		name = title.text
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+title.get('href')
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			name = name.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
		if '#' not in SSqweDUBYv4bkO: items.append((name,SSqweDUBYv4bkO))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for BoRk2n4aEtT3cKL08HPhUO in items:
		name,SSqweDUBYv4bkO = BoRk2n4aEtT3cKL08HPhUO
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,518)
	return
def HG9vxKj8uyZM5(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-INDEXES_TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	bXMpofzj7h = J8Bca9W3fkHsCTA.find(class_='expand').find_all('tr')
	for AxiBv1cQueOs0 in bXMpofzj7h:
		fVQGw5L2nliXkI = AxiBv1cQueOs0.find_all('a')
		if not fVQGw5L2nliXkI: continue
		gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('data-src')
		name = fVQGw5L2nliXkI[1].text
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+fVQGw5L2nliXkI[1].get('href')
		PPUvgMjsBZhI = AxiBv1cQueOs0.find(class_='legend')
		if PPUvgMjsBZhI: PPUvgMjsBZhI = PPUvgMjsBZhI.text
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			name = name.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
			gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.encode(JJQFjSIlALchiMzG9)
		ZgSKTRL2DlPprjU57W93zf4EF = {}
		if PPUvgMjsBZhI: ZgSKTRL2DlPprjU57W93zf4EF['stars'] = PPUvgMjsBZhI
		if '/work/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,516,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name,gby0BnUuTNFk,ZgSKTRL2DlPprjU57W93zf4EF)
		elif '/person/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,513,gQmur3iRSZ9IAOX,gby0BnUuTNFk,name,gby0BnUuTNFk,ZgSKTRL2DlPprjU57W93zf4EF)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(J8Bca9W3fkHsCTA,518)
	return
def x2TqrHgNmGbkElM8oScDBysJiQ0z(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-VIDEOS_LISTS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	K6ucHgjCtqf9wBZxXAUh3Db5EMJW = J8Bca9W3fkHsCTA.find_all(class_='section-title inline')
	vx14CNdbsZTz = J8Bca9W3fkHsCTA.find_all(class_='button green small right')
	items = zip(K6ucHgjCtqf9wBZxXAUh3Db5EMJW,vx14CNdbsZTz)
	for title,SSqweDUBYv4bkO in items:
		title = title.text
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO.get('href')
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
		title = title.replace(TFAVlh4ONfuyivg,UpN1CezytPO9XoduhxZSD).replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,521)
	return
def uc7P9RWfvLzdtUN0EV(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-VIDEOS_TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	BIApmO0X83Gwq6CnoS12TJDxeEd = J8Bca9W3fkHsCTA.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	bXMpofzj7h = BIApmO0X83Gwq6CnoS12TJDxeEd.find_all('li')
	for AxiBv1cQueOs0 in bXMpofzj7h:
		title = AxiBv1cQueOs0.find(class_='title').text
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+AxiBv1cQueOs0.find('a').get('href')
		gQmur3iRSZ9IAOX = AxiBv1cQueOs0.find('img').get('data-src')
		a8tFl4fNpx2Ou65q = AxiBv1cQueOs0.find(class_='duration').text
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.encode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
			gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.encode(JJQFjSIlALchiMzG9)
			a8tFl4fNpx2Ou65q = a8tFl4fNpx2Ou65q.encode(JJQFjSIlALchiMzG9)
		a8tFl4fNpx2Ou65q = a8tFl4fNpx2Ou65q.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,522,gQmur3iRSZ9IAOX,a8tFl4fNpx2Ou65q)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(J8Bca9W3fkHsCTA,521)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	SSqweDUBYv4bkO = J8Bca9W3fkHsCTA.find(class_='flex-video').find('iframe').get('src')
	if cAIRPFK6boejVU549WzqBGCaJ0r: SSqweDUBYv4bkO = SSqweDUBYv4bkO.encode(JJQFjSIlALchiMzG9)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb([SSqweDUBYv4bkO],CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	url = LhFnEIuPHdoNc+'/search/?q='+search
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-SEARCH-1st')
	if not ccV0NKHwQpMun6FtZvAi.succeeded:
		cX6y1lL0qeKMNY = LhFnEIuPHdoNc+'/search_entity/?q='+search+'&entity=work'
		RkntpA1UJDV4vNgyaex6GPWK9YQIcC = LhFnEIuPHdoNc+'/search_entity/?q='+search+'&entity=person'
		deSYLq1hQC = LhFnEIuPHdoNc+'/search_entity/?q='+search+'&entity=video'
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن أعمال',cX6y1lL0qeKMNY,513,gby0BnUuTNFk,search)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن أشخاص',RkntpA1UJDV4vNgyaex6GPWK9YQIcC,513,gby0BnUuTNFk,search)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن فيديوهات',deSYLq1hQC,513,gby0BnUuTNFk,search)
		return
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	J8Bca9W3fkHsCTA = IIpjN2EPr64HJAns1mZeYB0.BeautifulSoup(jS6fQGXeouTB7xKd32ZMy,'html.parser',multi_valued_attributes=None)
	bXMpofzj7h = J8Bca9W3fkHsCTA.find_all(class_='section-title left')
	for AxiBv1cQueOs0 in bXMpofzj7h:
		title = AxiBv1cQueOs0.text
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.encode(JJQFjSIlALchiMzG9)
		title = title.split('(',1)[0].strip(UpN1CezytPO9XoduhxZSD)
		if   'أعمال' in title: SSqweDUBYv4bkO = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: SSqweDUBYv4bkO = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: SSqweDUBYv4bkO = url.replace('/search/','/search/video/')
		else: continue
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,513)
	return
def DDOwe07ibMNa8IsQ5BKhf23tnG6p(url,text):
	global FFCXkHm5TYPUbBp,ZfNKXALGqzaCsM68gw0d7lD
	if '/seasonals' in url:
		FFCXkHm5TYPUbBp = ['seasonal','year','category']
		ZfNKXALGqzaCsM68gw0d7lD = ['seasonal','year','category']
	elif '/lineup' in url:
		FFCXkHm5TYPUbBp = ['category','foreign','type']
		ZfNKXALGqzaCsM68gw0d7lD = ['category','foreign','type']
	PsoEh3mOJub72VQl1crzW5n(url,text)
	return
def G2dUpHgXKM1Nzu4w9(url):
	url = url.split('/smartemadfilter?')[0]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('form action="/(.*?)</form>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return tpQ9UZ8rIuhvW3box21X6iqsz
def Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0):
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<option value="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return items
def XI6uxNML5haHVWrm0p8U(url):
	c7oIqRywsVUpZ8rdTu6LNm20Y = url.split('/smartemadfilter?')[0]
	q53fXShJmaD0iWrz7KbnlAFBoR = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def jwnqt57EBpfMOdIU1mXuQyaS(vyD9F1UMQe,url):
	zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'all_filters')
	mm7pzl3HMi0R8fGu = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	mm7pzl3HMi0R8fGu = XI6uxNML5haHVWrm0p8U(mm7pzl3HMi0R8fGu)
	return mm7pzl3HMi0R8fGu
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if FFCXkHm5TYPUbBp[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[0]
		for xuX6UN0WRQbHArDV in range(len(FFCXkHm5TYPUbBp[0:-1])):
			if FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='ALL_ITEMS_FILTER':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+QfoFHUnpEi4W2OuT8DBg3
		Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها ',Tf5ueYGZIFl1hraoEOVKi,511)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',Tf5ueYGZIFl1hraoEOVKi,511)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	tpQ9UZ8rIuhvW3box21X6iqsz = G2dUpHgXKM1Nzu4w9(url)
	dict = {}
	for name,CCRe1gOK8Dtca0,AxiBv1cQueOs0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		name = name.replace('--',gby0BnUuTNFk)
		items = Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='SPECIFIED_FILTER':
			if CCRe1gOK8Dtca0 not in FFCXkHm5TYPUbBp: continue
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<2:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]:
					url = XI6uxNML5haHVWrm0p8U(url)
					RY5naLxFlqvAur496UNchw2kX0(url)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'SPECIFIED_FILTER___'+J21ulLnwtByA4XvcC)
				return
			else:
				Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,511)
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,515,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='ALL_ITEMS_FILTER':
			if CCRe1gOK8Dtca0 not in ZfNKXALGqzaCsM68gw0d7lD: continue
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع: '+name,Tf5ueYGZIFl1hraoEOVKi,514,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			if 'مصنفات أخرى' in w7su60daQz13VIplrfxJk: continue
			if 'الكل' in w7su60daQz13VIplrfxJk: continue
			if 'اللغة' in w7su60daQz13VIplrfxJk: continue
			w7su60daQz13VIplrfxJk = w7su60daQz13VIplrfxJk.replace('قائمة ',gby0BnUuTNFk)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			if name: title = w7su60daQz13VIplrfxJk+' :'+name
			else: title = w7su60daQz13VIplrfxJk
			if type=='ALL_ITEMS_FILTER': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,514,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='SPECIFIED_FILTER' and FFCXkHm5TYPUbBp[-2]+'=' in mW9DK3tVFwd:
				mm7pzl3HMi0R8fGu = jwnqt57EBpfMOdIU1mXuQyaS(vyD9F1UMQe,url)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,511)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,515,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.replace('=&','=0&')
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	for key in ZfNKXALGqzaCsM68gw0d7lD:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if '%' not in value: value = IcChbXakUDFLszgpSG2jqem9(value)
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all_filters': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	d28pn3tAz4V = d28pn3tAz4V.replace('=0','=')
	return d28pn3tAz4V
FFCXkHm5TYPUbBp = []
ZfNKXALGqzaCsM68gw0d7lD = []