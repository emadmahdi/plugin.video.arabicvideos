# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
BZqfNTuc7nKbG1lh = 'M3U'
IvnA0yjpu5HDFS9UOawMqcVW = '_M3U_'
JVs3roSjn5u = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
aaExwv5sSWFXk = 4
def CHyR2EGvqzpWZB9cAU4jibkPo(mi63FgbZoVerXaTGNhsUkuR0ILQW,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,ZZrjMgRGiY2IDN7q,LL4W9eHQmsxZ,lFYCHgrx5oeBMkD):
	global IvnA0yjpu5HDFS9UOawMqcVW
	try:
		Z27widCyESA = str(lFYCHgrx5oeBMkD['folder'])
		IvnA0yjpu5HDFS9UOawMqcVW = '_MU'+Z27widCyESA+'_'
	except: Z27widCyESA = gby0BnUuTNFk
	try: PhCw7H3Z1vpMOckgt04fr9 = str(lFYCHgrx5oeBMkD['sequence'])
	except: PhCw7H3Z1vpMOckgt04fr9 = gby0BnUuTNFk
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==710: PgTIFSCwRY3haxjiok = VDtxLSPUFz0I5()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==711: PgTIFSCwRY3haxjiok = BYRb8ALrn41jh7owmOH(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==712: PgTIFSCwRY3haxjiok = ptHWugwnXD9yc1QhKb(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==713: PgTIFSCwRY3haxjiok = MM6Qabwn2ecXOA3GK8pt5H(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==714: PgTIFSCwRY3haxjiok = O5XxuEh689Mvoq1Rnesl(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==715: PgTIFSCwRY3haxjiok = HthKAzX6MnLDiIF4aEC5sukp8WfJST(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,ZZrjMgRGiY2IDN7q)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==716: PgTIFSCwRY3haxjiok = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==717: PgTIFSCwRY3haxjiok = TowZRG0DMgvCQzb2qlcNI(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==718: PgTIFSCwRY3haxjiok = v9vmA6lnP4kCywrZX(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==719: PgTIFSCwRY3haxjiok = H7l4URTtJj2ksaBQwb(fbmZ9V58PCTz,Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==720: PgTIFSCwRY3haxjiok = NZihe4G13VvS2WTXY9HLk07A(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==721: PgTIFSCwRY3haxjiok = HwC0V7B8x2ZnSM6tp1FN4XPR(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==722: PgTIFSCwRY3haxjiok = yuDs1JYf8vNxPawg3FOL(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==723: PgTIFSCwRY3haxjiok = KKVfL5U4qplP8Nh0Q(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==726: PgTIFSCwRY3haxjiok = ndHSJiu89yjKoQbgzWM4DG1BwCFE(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==729: PgTIFSCwRY3haxjiok = zzVD2aYBrXNtmGqwxcJ3eLTnIps(fbmZ9V58PCTz,Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,LL4W9eHQmsxZ)
	else: PgTIFSCwRY3haxjiok = False
	return PgTIFSCwRY3haxjiok
def VDtxLSPUFz0I5():
	for Z27widCyESA in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
		IvnA0yjpu5HDFS9UOawMqcVW = '_MU'+str(Z27widCyESA)+'_'
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قائمة مجلد '+XVANElz3tLn5pFPQUWi[Z27widCyESA],gby0BnUuTNFk,720,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	return
def NZihe4G13VvS2WTXY9HLk07A(Z27widCyESA=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=gby0BnUuTNFk):
	if Z27widCyESA:
		TTpnMa9HmbjORSl0qhZ5V68x1YJA7c = {'folder':Z27widCyESA}
		jyPnJKCVoqRL3b1hE2Zwdt5Q = gby0BnUuTNFk
	else:
		TTpnMa9HmbjORSl0qhZ5V68x1YJA7c = gby0BnUuTNFk
		jyPnJKCVoqRL3b1hE2Zwdt5Q = gby0BnUuTNFk
	FkcA2PCJuvWn = hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u)
	if not FkcA2PCJuvWn:
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+bKN9diGf8nmgecQPEqUzHRpoDuaO+' إضافة وتغيير رابط'+jyPnJKCVoqRL3b1hE2Zwdt5Q+UpN1CezytPO9XoduhxZSD+XVANElz3tLn5pFPQUWi[1]+' '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,711,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA,'sequence':1})
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+bKN9diGf8nmgecQPEqUzHRpoDuaO+' جلب ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q+' '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,712,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	else:
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'بحث في الملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,729,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_',gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_GROUPED_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة من القسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_FROM_GROUP_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة من الاسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_FROM_NAME_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_GROUPED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_ORIGINAL_GROUPED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مجهولة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_UNKNOWN_GROUPED_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مجهولة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_UNKNOWN_GROUPED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_ORIGINAL_GROUPED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مصنفة القسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_FROM_GROUP_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مصنفة من الاسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_FROM_NAME_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مجهولة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_UNKNOWN_GROUPED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مجهولة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_UNKNOWN_GROUPED_SORTED',713,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'إضافة وتغيير رابط'+jyPnJKCVoqRL3b1hE2Zwdt5Q+UpN1CezytPO9XoduhxZSD+XVANElz3tLn5pFPQUWi[K25l1aSLE9OU7dikIj6r0HT],gby0BnUuTNFk,711,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA,'sequence':K25l1aSLE9OU7dikIj6r0HT})
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'جلب ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,712,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'مسح ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,717,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'عدد فيديوهات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,721,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'Referer تغيير'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,726,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'User-Agent تغيير'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,723,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	return
def k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,N9bXKIfsDVPjctLM5u=True):
	vISfBo3dLZO5aX1Wbr8pQAyK9wuq,Ke4zLZ0qNpGcnmSg = False,gby0BnUuTNFk
	pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = gby0BnUuTNFk,gby0BnUuTNFk
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if h5iRdFc13nsYS2MjPLgfNyGCtx==gby0BnUuTNFk: return False,gby0BnUuTNFk,gby0BnUuTNFk
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	if QLsvCVdeuE:
		WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',QLsvCVdeuE,gby0BnUuTNFk,vO65KkJHupCrocdLe,False,gby0BnUuTNFk,'M3U-CHECK_ACCOUNT-1st')
		LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
		if WeCU3qEsGrDNfh1tmXHVOZgPalK.succeeded:
			zJuHlOwIAR6vdQ1XaGVh2t8iE,aKy0b6OGmEjBX,KJRAebTL4ycph,qh329pGFD6zICYygSOxrb8QJ7vlTZ,o3RpjnUrFJ1 = 0,0,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
			try:
				daiRt93NpKI0hP8yTjcmYAMJlr6E = TqNUy3Z4SFWvplGwXC82A('dict',LviwW2t5HRmCMpxOqhDFo4d)
				Ke4zLZ0qNpGcnmSg = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['status']
				vISfBo3dLZO5aX1Wbr8pQAyK9wuq = True
				KJRAebTL4ycph = daiRt93NpKI0hP8yTjcmYAMJlr6E['server_info']['time_now']
			except: pass
			if KJRAebTL4ycph:
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.strptime(KJRAebTL4ycph,'%Y.%m.%d %H:%M:%S')
					zJuHlOwIAR6vdQ1XaGVh2t8iE = int(RyfYSek61do5OnQMc.mktime(pc31hyj70EoWbqH))
					aKy0b6OGmEjBX = int(X1X59MWmb8oBPDFCJARwcjONihTdeZ-zJuHlOwIAR6vdQ1XaGVh2t8iE)
					aKy0b6OGmEjBX = int((aKy0b6OGmEjBX+900)/1800)*1800
				except: pass
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['created_at']))
					qh329pGFD6zICYygSOxrb8QJ7vlTZ = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				except: pass
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['exp_date']))
					o3RpjnUrFJ1 = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				except: pass
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.timestamp_'+Z27widCyESA,str(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.timediff_'+Z27widCyESA,str(aKy0b6OGmEjBX))
			try:
				TbwogIEGRSiB = '"server_info":'+LviwW2t5HRmCMpxOqhDFo4d.split('"server_info":')[1]
				TbwogIEGRSiB = TbwogIEGRSiB.replace(':',': ').replace(',',', ').replace('}}','}')
				rrgxdszNbZP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"url": "(.*?)", "port": "(.*?)"',TbwogIEGRSiB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = rrgxdszNbZP[0]
			except: vISfBo3dLZO5aX1Wbr8pQAyK9wuq = False
			if vISfBo3dLZO5aX1Wbr8pQAyK9wuq and N9bXKIfsDVPjctLM5u:
				max = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['max_connections']
				pUoWcN32m5lxQSBfTRvV7EsGn = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['active_cons']
				HUFhC3cWSMBQxvrymno = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['is_trial']
				ZZU08dwLBRN3VKEJk4eip9 = QLsvCVdeuE.split('?',1)
				H7fCeh95oEyapvUl4itZDm2Njdx6z = 'URL:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+QLsvCVdeuE+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\nStatus:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+Ke4zLZ0qNpGcnmSg+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nTrial:    '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+str(HUFhC3cWSMBQxvrymno=='1')+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nCreated  At:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+qh329pGFD6zICYygSOxrb8QJ7vlTZ+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nExpiry Date:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+o3RpjnUrFJ1+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nConnections   ( Active / Maximum ) :  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+pUoWcN32m5lxQSBfTRvV7EsGn+' / '+max+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nAllowed Outputs:   '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+" , ".join(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['allowed_output_formats'])+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+TbwogIEGRSiB
				if Ke4zLZ0qNpGcnmSg=='Active': YNX5nvi2VegTUu('الاشتراك يعمل بدون مشاكل',H7fCeh95oEyapvUl4itZDm2Njdx6z)
				else: YNX5nvi2VegTUu('يبدو أن هناك مشكلة في الاشتراك',H7fCeh95oEyapvUl4itZDm2Njdx6z)
	if QLsvCVdeuE and vISfBo3dLZO5aX1Wbr8pQAyK9wuq and Ke4zLZ0qNpGcnmSg=='Active':
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+QLsvCVdeuE+' ]')
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV = True
	else:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,'Checking M3U URL   [ Does not work ]   [ '+QLsvCVdeuE+' ]')
		if N9bXKIfsDVPjctLM5u: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV = False
	return ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs
def O5XxuEh689Mvoq1Rnesl(Z27widCyESA,kVGU1uhays3EWfH,THmdqUzOsy,UwrnXuFkvEh9xRs5Z1,N9bXKIfsDVPjctLM5u=True):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',kVGU1uhays3EWfH,THmdqUzOsy)
	AH7qJLzK53xXvyC = int(UwrnXuFkvEh9xRs5Z1)*100
	NqOeKYDRCJX8rgaQLzA3FZ = AH7qJLzK53xXvyC-100
	for EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in T7hyMuvVz9EqkOasZDSJ[NqOeKYDRCJX8rgaQLzA3FZ:AH7qJLzK53xXvyC]:
		S3NTGxMIWYUHb68Ojy = ('GROUPED' in kVGU1uhays3EWfH or kVGU1uhays3EWfH=='ALL')
		JDhbLFOd9xEkpWjzcsC = ('GROUPED' not in kVGU1uhays3EWfH and kVGU1uhays3EWfH!='ALL')
		if S3NTGxMIWYUHb68Ojy or JDhbLFOd9xEkpWjzcsC:
			if   'ARCHIVED'  in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,718,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'ARCHIVED',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'EPG' 		 in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,718,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'FULL_EPG',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'TIMESHIFT' in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,718,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'TIMESHIFT',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'LIVE' 	 in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['live',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,715,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,EyvQhYU4jZoGuwtW7M9JXb,{'folder':Z27widCyESA}])
			else: wAcHkmPB8a.menuItemsLIST.append(['video',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,715,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA}])
	LbeM6usxzdNjYTXJ7iOoKEDgAkHf = len(T7hyMuvVz9EqkOasZDSJ)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,714,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,THmdqUzOsy)
	return
def DCPtLSv0hURE4(pRajc0eY57W9HhZlfBNQOgwsyGC):
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'هذه القائمة إما فارغة أو غير موجودة',gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'أو الخدمة غير موجودة في اشتراكك',gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'أو رابط M3U الذي أنت أضفته غير صحيح',gby0BnUuTNFk,9999)
	return
def MM6Qabwn2ecXOA3GK8pt5H(Z27widCyESA,kVGU1uhays3EWfH,THmdqUzOsy,UwrnXuFkvEh9xRs5Z1,XPmvhy6V1DcY5FQ=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=True):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	pRajc0eY57W9HhZlfBNQOgwsyGC = IvnA0yjpu5HDFS9UOawMqcVW
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return False
	if '__SERIES__' in THmdqUzOsy: ByvjFKdQ7orCEhqxpleRb5zU64aO,mJzQDOXswYUAR4o9Ce2g = THmdqUzOsy.split('__SERIES__')
	else: ByvjFKdQ7orCEhqxpleRb5zU64aO,mJzQDOXswYUAR4o9Ce2g = THmdqUzOsy,gby0BnUuTNFk
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	wrRZTAy34jL7h0oeVlN1zx = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',kVGU1uhays3EWfH,'__GROUPS__')
	if not wrRZTAy34jL7h0oeVlN1zx: return False
	g1NebzFUpmEhjDRyB56cvHAKV = []
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in wrRZTAy34jL7h0oeVlN1zx:
		if '===== ===== =====' in r9rIzYVD0ceyC1uUofpPJF45tWbR:
			ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,9999)
			ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,9999)
			continue
		if XPmvhy6V1DcY5FQ:
			if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: pRajc0eY57W9HhZlfBNQOgwsyGC = 'SERIES'
			elif '!!__UNKNOWN__!!' in r9rIzYVD0ceyC1uUofpPJF45tWbR: pRajc0eY57W9HhZlfBNQOgwsyGC = 'UNKNOWN'
			elif 'LIVE' in kVGU1uhays3EWfH: pRajc0eY57W9HhZlfBNQOgwsyGC = 'LIVE'
			else: pRajc0eY57W9HhZlfBNQOgwsyGC = 'VIDEOS'
			pRajc0eY57W9HhZlfBNQOgwsyGC = ','+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+pRajc0eY57W9HhZlfBNQOgwsyGC+': '+GGy0cQe765nPYZ9E8Th
		if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')
		else: KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk
		if not THmdqUzOsy:
			if KVxLWm5201GJnaIElF8ASUi in g1NebzFUpmEhjDRyB56cvHAKV: continue
			g1NebzFUpmEhjDRyB56cvHAKV.append(KVxLWm5201GJnaIElF8ASUi)
			if 'RANDOM' in XPmvhy6V1DcY5FQ: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,168,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			elif '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,713,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,714,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
		elif '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR and KVxLWm5201GJnaIElF8ASUi==ByvjFKdQ7orCEhqxpleRb5zU64aO:
			if Nd0fkcwTIV2JhMLxKbD7Go1e9A in g1NebzFUpmEhjDRyB56cvHAKV: continue
			g1NebzFUpmEhjDRyB56cvHAKV.append(Nd0fkcwTIV2JhMLxKbD7Go1e9A)
			if 'RANDOM' in XPmvhy6V1DcY5FQ: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+Nd0fkcwTIV2JhMLxKbD7Go1e9A,kVGU1uhays3EWfH,168,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+Nd0fkcwTIV2JhMLxKbD7Go1e9A,kVGU1uhays3EWfH,714,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
	wAcHkmPB8a.menuItemsLIST[:] = sorted(wAcHkmPB8a.menuItemsLIST,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1].lower())
	if not XPmvhy6V1DcY5FQ:
		AH7qJLzK53xXvyC = int(UwrnXuFkvEh9xRs5Z1)*100
		NqOeKYDRCJX8rgaQLzA3FZ = AH7qJLzK53xXvyC-100
		LbeM6usxzdNjYTXJ7iOoKEDgAkHf = len(wAcHkmPB8a.menuItemsLIST)
		wAcHkmPB8a.menuItemsLIST[:] = wAcHkmPB8a.menuItemsLIST[NqOeKYDRCJX8rgaQLzA3FZ:AH7qJLzK53xXvyC]
		mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,713,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,THmdqUzOsy)
	return True
def v9vmA6lnP4kCywrZX(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,lg6ihPJLUQc9zDw2M47f):
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,True): return
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	zJuHlOwIAR6vdQ1XaGVh2t8iE = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.timestamp_'+Z27widCyESA)
	if not zJuHlOwIAR6vdQ1XaGVh2t8iE or X1X59MWmb8oBPDFCJARwcjONihTdeZ-int(zJuHlOwIAR6vdQ1XaGVh2t8iE)>24*InYGW7Ad2QRM9rUblmh6:
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,False)
		if not ww8aEQ9UGz1ms3qOeXvDkfFMTdV: return
	aKy0b6OGmEjBX = int(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.timediff_'+Z27widCyESA))
	OTl0DRFHNiA = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.server_'+Z27widCyESA)
	h5iRdFc13nsYS2MjPLgfNyGCtx = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.username_'+Z27widCyESA)
	CKTBLx2pOZDrzXqj3Qcea = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.password_'+Z27widCyESA)
	tSfK8LmoT1zq6N = UJeuWoLKP7ZI15O4ypTVs8caj.split('/')
	j05Lq8fUVz9kuJEh4 = tSfK8LmoT1zq6N[-1].replace('.ts',gby0BnUuTNFk).replace('.m3u8',gby0BnUuTNFk)
	if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG': uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5 = 'get_short_epg'
	else: uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5 = 'get_simple_data_table'
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx: return
	l5hvSZxnX8JK1DE9d = QLsvCVdeuE+'&action='+uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5+'&stream_id='+j05Lq8fUVz9kuJEh4
	LviwW2t5HRmCMpxOqhDFo4d = mmQHlVdqUY8w9uEIfBhyaNRW6At(rraWHLSwQvPlVROcM5YAJfF7ojh,l5hvSZxnX8JK1DE9d,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,'M3U-EPG_ITEMS-2nd')
	IsXSAK45YWg = TqNUy3Z4SFWvplGwXC82A('dict',LviwW2t5HRmCMpxOqhDFo4d)
	SsDvZrLyicd5g9B = IsXSAK45YWg['epg_listings']
	R1OdQ7V9q6fNbl0piLKXhjyBmY = []
	if lg6ihPJLUQc9zDw2M47f in ['ARCHIVED','TIMESHIFT']:
		for daiRt93NpKI0hP8yTjcmYAMJlr6E in SsDvZrLyicd5g9B:
			if daiRt93NpKI0hP8yTjcmYAMJlr6E['has_archive']==1:
				R1OdQ7V9q6fNbl0piLKXhjyBmY.append(daiRt93NpKI0hP8yTjcmYAMJlr6E)
				if lg6ihPJLUQc9zDw2M47f in ['TIMESHIFT']: break
		if not R1OdQ7V9q6fNbl0piLKXhjyBmY: return
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'الملفات الأولي بهذه القائمة قد لا تعمل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		if lg6ihPJLUQc9zDw2M47f in ['TIMESHIFT']:
			rrwkvIfat8 = 2
			fJVzyHRjtD3GEZWaKF = rrwkvIfat8*InYGW7Ad2QRM9rUblmh6
			R1OdQ7V9q6fNbl0piLKXhjyBmY = []
			aZhJstwokBcRT = int(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'])/fJVzyHRjtD3GEZWaKF)*fJVzyHRjtD3GEZWaKF
			B5Pq1nguoCSdRUHYDEikIht2cX = X1X59MWmb8oBPDFCJARwcjONihTdeZ+fJVzyHRjtD3GEZWaKF
			Gw6TXC0pbjHx8tD7FknVgIqN12O3Ur = int((B5Pq1nguoCSdRUHYDEikIht2cX-aZhJstwokBcRT)/InYGW7Ad2QRM9rUblmh6)
			for aGmyTsKY0IECMSN in range(Gw6TXC0pbjHx8tD7FknVgIqN12O3Ur):
				if aGmyTsKY0IECMSN>=6:
					if aGmyTsKY0IECMSN%rrwkvIfat8!=0: continue
					wb1hXv8tps32eNGdgmTHqLUCVuZ = fJVzyHRjtD3GEZWaKF
				else: wb1hXv8tps32eNGdgmTHqLUCVuZ = fJVzyHRjtD3GEZWaKF//2
				Yhg8svjWFpuzoI7mxHEn = aZhJstwokBcRT+aGmyTsKY0IECMSN*InYGW7Ad2QRM9rUblmh6
				daiRt93NpKI0hP8yTjcmYAMJlr6E = {}
				daiRt93NpKI0hP8yTjcmYAMJlr6E['title'] = gby0BnUuTNFk
				pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(Yhg8svjWFpuzoI7mxHEn-aKy0b6OGmEjBX-InYGW7Ad2QRM9rUblmh6)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['start'] = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'] = str(Yhg8svjWFpuzoI7mxHEn)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['stop_timestamp'] = str(Yhg8svjWFpuzoI7mxHEn+wb1hXv8tps32eNGdgmTHqLUCVuZ)
				R1OdQ7V9q6fNbl0piLKXhjyBmY.append(daiRt93NpKI0hP8yTjcmYAMJlr6E)
	elif lg6ihPJLUQc9zDw2M47f in ['SHORT_EPG','FULL_EPG']: R1OdQ7V9q6fNbl0piLKXhjyBmY = SsDvZrLyicd5g9B
	if lg6ihPJLUQc9zDw2M47f=='FULL_EPG' and len(R1OdQ7V9q6fNbl0piLKXhjyBmY)>0:
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'هذه قائمة برامج القنوات (جدول فقط)ـ'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	OXjlDar5kLY30EuvUehgcGJW = []
	Eoyrc5lpZQdsfbq3jtzSWhxKUGM = oKew16fsvuV8.getInfoLabel('ListItem.Icon')
	for daiRt93NpKI0hP8yTjcmYAMJlr6E in R1OdQ7V9q6fNbl0piLKXhjyBmY:
		oGVqE4JR3DIcTNtAghW9 = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(daiRt93NpKI0hP8yTjcmYAMJlr6E['title'])
		if nqkybtoMBH: oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.decode(JJQFjSIlALchiMzG9)
		Yhg8svjWFpuzoI7mxHEn = int(daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'])
		PtLb1QyIas7kjTr2fUDuVCB = int(daiRt93NpKI0hP8yTjcmYAMJlr6E['stop_timestamp'])
		RRiY2n6EfZJUbhlQ = str(int((PtLb1QyIas7kjTr2fUDuVCB-Yhg8svjWFpuzoI7mxHEn+59)/60))
		YtG8N1esIZ4V9ajHcm = daiRt93NpKI0hP8yTjcmYAMJlr6E['start'].replace(UpN1CezytPO9XoduhxZSD,':')
		pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(Yhg8svjWFpuzoI7mxHEn-InYGW7Ad2QRM9rUblmh6)
		dSlYHKcVCaWJyGfFIriDQx4Mt1gz = RyfYSek61do5OnQMc.strftime('%H:%M',pc31hyj70EoWbqH)
		YSvhQcmiRJXp7za5y = RyfYSek61do5OnQMc.strftime('%a',pc31hyj70EoWbqH)
		if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG': oGVqE4JR3DIcTNtAghW9 = bKN9diGf8nmgecQPEqUzHRpoDuaO+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ـ '+oGVqE4JR3DIcTNtAghW9+GGy0cQe765nPYZ9E8Th
		elif lg6ihPJLUQc9zDw2M47f=='TIMESHIFT': oGVqE4JR3DIcTNtAghW9 = YSvhQcmiRJXp7za5y+UpN1CezytPO9XoduhxZSD+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ('+RRiY2n6EfZJUbhlQ+'min)'
		else: oGVqE4JR3DIcTNtAghW9 = YSvhQcmiRJXp7za5y+UpN1CezytPO9XoduhxZSD+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ('+RRiY2n6EfZJUbhlQ+'min)   '+oGVqE4JR3DIcTNtAghW9+' ـ'
		if lg6ihPJLUQc9zDw2M47f in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			xar2BQHqiEIGc = OTl0DRFHNiA+'/timeshift/'+h5iRdFc13nsYS2MjPLgfNyGCtx+'/'+CKTBLx2pOZDrzXqj3Qcea+'/'+RRiY2n6EfZJUbhlQ+'/'+YtG8N1esIZ4V9ajHcm+'/'+j05Lq8fUVz9kuJEh4+'.m3u8'
			if lg6ihPJLUQc9zDw2M47f=='FULL_EPG': ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,xar2BQHqiEIGc,9999,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('video',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,xar2BQHqiEIGc,715,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
		OXjlDar5kLY30EuvUehgcGJW.append(oGVqE4JR3DIcTNtAghW9)
	if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG' and OXjlDar5kLY30EuvUehgcGJW: YnUKjTgtHOaGZvkhD = MMgdej0E4XIrLa1bhxPQZJlB2Um(OXjlDar5kLY30EuvUehgcGJW)
	return OXjlDar5kLY30EuvUehgcGJW
def yuDs1JYf8vNxPawg3FOL(Z27widCyESA):
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,True): return
	OTl0DRFHNiA,zUGXJsLTlVpfF5EW,VjnOqSAvDyT = gby0BnUuTNFk,0,0
	ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,False)
	if ww8aEQ9UGz1ms3qOeXvDkfFMTdV:
		Y26Vib51mSIuMR0EAN8n = ElRUG8zKHm(pEdJtk92IBfq80N)
		zUGXJsLTlVpfF5EW = Xa2nju83yQLEKgMhC65PbcqzIRJ(Y26Vib51mSIuMR0EAN8n[0],int(Lt5J47xrFw9KRulCoVs))
		WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'LIVE_GROUPED')
		qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','LIVE_GROUPED')
		T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','LIVE_GROUPED',qleCEa50kOYvVNSJuDP1R4FdhtoIxw[1])
		UJeuWoLKP7ZI15O4ypTVs8caj = T7hyMuvVz9EqkOasZDSJ[0][2]
		msk1z4hY6ELvtP0H9jIfrW5JV = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('://(.*?)/',UJeuWoLKP7ZI15O4ypTVs8caj,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		msk1z4hY6ELvtP0H9jIfrW5JV = msk1z4hY6ELvtP0H9jIfrW5JV[0]
		if ':' in msk1z4hY6ELvtP0H9jIfrW5JV: vKXUiA1H2MgFla,OOaoAqWUK0h8xsIzu = msk1z4hY6ELvtP0H9jIfrW5JV.split(':')
		else: vKXUiA1H2MgFla,OOaoAqWUK0h8xsIzu = msk1z4hY6ELvtP0H9jIfrW5JV,'80'
		ntxkEmo013pWOe8r7QdKY2XjUARVbZ = ElRUG8zKHm(vKXUiA1H2MgFla)
		VjnOqSAvDyT = Xa2nju83yQLEKgMhC65PbcqzIRJ(ntxkEmo013pWOe8r7QdKY2XjUARVbZ[0],int(OOaoAqWUK0h8xsIzu))
	if zUGXJsLTlVpfF5EW and VjnOqSAvDyT:
		H7fCeh95oEyapvUl4itZDm2Njdx6z = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+'وقت ضائع في السيرفر الأصلي'+okfdjS4RmM+str(int(VjnOqSAvDyT*1000))+' ملي ثانية'
		H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+'وقت ضائع في السيرفر البديل'+okfdjS4RmM+str(int(zUGXJsLTlVpfF5EW*1000))+' ملي ثانية'
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center','السيرفر الأصلي','السيرفر الأسرع',e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if BeU98noROVkGhHqN15fumPCvyWQcxJ==1 and zUGXJsLTlVpfF5EW<VjnOqSAvDyT: OTl0DRFHNiA = pEdJtk92IBfq80N+':'+Lt5J47xrFw9KRulCoVs
	else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'البرنامج لم يجد السيرفر البديل')
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.server_'+Z27widCyESA,OTl0DRFHNiA)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,ZZrjMgRGiY2IDN7q):
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.useragent_'+Z27widCyESA)
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.referer_'+Z27widCyESA)
	if Z38Zes0IBSDYCLPGJfM6j or vBJn6DgVPG7sqoprY:
		UJeuWoLKP7ZI15O4ypTVs8caj += '|'
		if Z38Zes0IBSDYCLPGJfM6j: UJeuWoLKP7ZI15O4ypTVs8caj += '&User-Agent='+Z38Zes0IBSDYCLPGJfM6j
		if vBJn6DgVPG7sqoprY: UJeuWoLKP7ZI15O4ypTVs8caj += '&Referer='+vBJn6DgVPG7sqoprY
		UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace('|&','|')
	YAQOL1eVvqMjsEfIFc(UJeuWoLKP7ZI15O4ypTVs8caj,BZqfNTuc7nKbG1lh,ZZrjMgRGiY2IDN7q)
	return
def KKVfL5U4qplP8Nh0Q(Z27widCyESA):
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.useragent_'+Z27widCyESA)
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center','استخدام الأصلي','تعديل القديم',Z38Zes0IBSDYCLPGJfM6j,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if U6aeROxVWpCbY18==1: Z38Zes0IBSDYCLPGJfM6j = vRoGedUjt2Ac6pIbufBX8sKy('أكتب ـM3U User-Agent جديد',Z38Zes0IBSDYCLPGJfM6j,True)
	else: Z38Zes0IBSDYCLPGJfM6j = 'Unknown'
	if Z38Zes0IBSDYCLPGJfM6j==UpN1CezytPO9XoduhxZSD:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,Z38Zes0IBSDYCLPGJfM6j,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if U6aeROxVWpCbY18!=1:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
		return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.useragent_'+Z27widCyESA,Z38Zes0IBSDYCLPGJfM6j)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def ndHSJiu89yjKoQbgzWM4DG1BwCFE(Z27widCyESA):
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.referer_'+Z27widCyESA)
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center','استخدام الأصلي','تعديل القديم',vBJn6DgVPG7sqoprY,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if U6aeROxVWpCbY18==1: vBJn6DgVPG7sqoprY = vRoGedUjt2Ac6pIbufBX8sKy('أكتب ـM3U Referer جديد',vBJn6DgVPG7sqoprY,True)
	else: vBJn6DgVPG7sqoprY = gby0BnUuTNFk
	if vBJn6DgVPG7sqoprY==UpN1CezytPO9XoduhxZSD:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,vBJn6DgVPG7sqoprY,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if U6aeROxVWpCbY18!=1:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
		return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.referer_'+Z27widCyESA,vBJn6DgVPG7sqoprY)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def beDTGt1QHSI7Pul9BfOcC(Z27widCyESA,BncIlsSoVd5xaGX3wtu79WLYN=gby0BnUuTNFk):
	if not GGFNhAjfiwydO4QgMeabPXvID8tJU: GGFNhAjfiwydO4QgMeabPXvID8tJU = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.url_'+Z27widCyESA)
	OTl0DRFHNiA = mDR9euKnv4jMSdbEpwcktJz5W6Cf(GGFNhAjfiwydO4QgMeabPXvID8tJU,'url')
	h5iRdFc13nsYS2MjPLgfNyGCtx = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('username=(.*?)&',GGFNhAjfiwydO4QgMeabPXvID8tJU+'&',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	CKTBLx2pOZDrzXqj3Qcea = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('password=(.*?)&',GGFNhAjfiwydO4QgMeabPXvID8tJU+'&',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx or not CKTBLx2pOZDrzXqj3Qcea:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	h5iRdFc13nsYS2MjPLgfNyGCtx = h5iRdFc13nsYS2MjPLgfNyGCtx[0]
	CKTBLx2pOZDrzXqj3Qcea = CKTBLx2pOZDrzXqj3Qcea[0]
	QLsvCVdeuE = OTl0DRFHNiA+'/player_api.php?username='+h5iRdFc13nsYS2MjPLgfNyGCtx+'&password='+CKTBLx2pOZDrzXqj3Qcea
	y5Cv1XOeJmLa4zDr = OTl0DRFHNiA+'/get.php?username='+h5iRdFc13nsYS2MjPLgfNyGCtx+'&password='+CKTBLx2pOZDrzXqj3Qcea+'&type=m3u_plus'
	return QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea
def BX9HfPAtyJcwC7noM5uphFa2l(Z27widCyESA,Ugkved5DSE8ZpLVrA4GXoRN=gby0BnUuTNFk):
	P9PI1QNFzMEDk = Ugkved5DSE8ZpLVrA4GXoRN.replace('/','_').replace(':','_').replace('.','_')
	P9PI1QNFzMEDk = P9PI1QNFzMEDk.replace('?','_').replace('=','_').replace('&','_')
	P9PI1QNFzMEDk = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,P9PI1QNFzMEDk).strip('.m3u')+'.m3u'
	return P9PI1QNFzMEDk
def BYRb8ALrn41jh7owmOH(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9):
	Y8Ap23QdsDbG = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.url_'+Z27widCyESA+'_'+PhCw7H3Z1vpMOckgt04fr9)
	vvRr5jB1A4oqhYwd3HILWCQbF = True
	if Y8Ap23QdsDbG:
		U6aeROxVWpCbY18 = yc8Ph4rFsCIvQbOA('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+Y8Ap23QdsDbG+GGy0cQe765nPYZ9E8Th+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if U6aeROxVWpCbY18==-1: return
		elif U6aeROxVWpCbY18==0: Y8Ap23QdsDbG = gby0BnUuTNFk
		elif U6aeROxVWpCbY18==2:
			U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if U6aeROxVWpCbY18 in [-1,0]: return
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح الرابط')
			vvRr5jB1A4oqhYwd3HILWCQbF = False
			UFrX7jqQmYZlMv8zdPbpNSV = gby0BnUuTNFk
	if vvRr5jB1A4oqhYwd3HILWCQbF:
		UFrX7jqQmYZlMv8zdPbpNSV = vRoGedUjt2Ac6pIbufBX8sKy('اكتب رابط M3U كاملا',Y8Ap23QdsDbG)
		UFrX7jqQmYZlMv8zdPbpNSV = UFrX7jqQmYZlMv8zdPbpNSV.strip(UpN1CezytPO9XoduhxZSD)
		if not UFrX7jqQmYZlMv8zdPbpNSV:
			U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if U6aeROxVWpCbY18 in [-1,0]: return
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح الرابط')
		else:
			H7fCeh95oEyapvUl4itZDm2Njdx6z = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'الرابط الجديد هو:',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+UFrX7jqQmYZlMv8zdPbpNSV+GGy0cQe765nPYZ9E8Th+'\n\n'+H7fCeh95oEyapvUl4itZDm2Njdx6z)
			if U6aeROxVWpCbY18!=1:
				tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
				return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.url_'+Z27widCyESA+'_'+PhCw7H3Z1vpMOckgt04fr9,UFrX7jqQmYZlMv8zdPbpNSV)
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.useragent_'+Z27widCyESA)
	if not Z38Zes0IBSDYCLPGJfM6j: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.useragent_'+Z27widCyESA,'Unknown')
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def T5tyHdWREw2kJ(uA0Ja8qPSW9,BAVbEI0J5XxG,jjLJvOMTAEy5Gczn4bH,SGubLHYpURo5Dt63asfPM9eW,SQfeyZdsPa72rv9kLwcnDUFjhlWT,HTm1lXjkbF0UJCnpZOYERaG,y5Cv1XOeJmLa4zDr):
	T7hyMuvVz9EqkOasZDSJ,DmTNIZjxUY9HEd1 = [],[]
	ssW7FnU0o5Y39btBL = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
		if HTm1lXjkbF0UJCnpZOYERaG%473==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,40+int(10*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'قراءة الفيديوهات','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+str(SQfeyZdsPa72rv9kLwcnDUFjhlWT))
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None,None
		UJeuWoLKP7ZI15O4ypTVs8caj = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)\n+((http|https|rtmp).*?)$',dlb6TgxSrm0eHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if UJeuWoLKP7ZI15O4ypTVs8caj:
			dlb6TgxSrm0eHB,UJeuWoLKP7ZI15O4ypTVs8caj,G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = UJeuWoLKP7ZI15O4ypTVs8caj[0]
			UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace(okfdjS4RmM,gby0BnUuTNFk)
			dlb6TgxSrm0eHB = dlb6TgxSrm0eHB.replace(okfdjS4RmM,gby0BnUuTNFk)
		else:
			DmTNIZjxUY9HEd1.append({'line':dlb6TgxSrm0eHB})
			continue
		L2kZzbT7r5DjfishylqR61QOu,EyvQhYU4jZoGuwtW7M9JXb,r9rIzYVD0ceyC1uUofpPJF45tWbR,oGVqE4JR3DIcTNtAghW9,ZZrjMgRGiY2IDN7q,aaOKNe8gwz592oSGj1yrBnduH = {},gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,False
		try:
			dlb6TgxSrm0eHB,oGVqE4JR3DIcTNtAghW9 = dlb6TgxSrm0eHB.rsplit('",',1)
			dlb6TgxSrm0eHB = dlb6TgxSrm0eHB+'"'
		except:
			try: dlb6TgxSrm0eHB,oGVqE4JR3DIcTNtAghW9 = dlb6TgxSrm0eHB.rsplit('1,',1)
			except: oGVqE4JR3DIcTNtAghW9 = gby0BnUuTNFk
		L2kZzbT7r5DjfishylqR61QOu['url'] = UJeuWoLKP7ZI15O4ypTVs8caj
		jEJgDiVnmcqzRahbtySUs4AdI9HBp = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(' (.*?)="(.*?)"',dlb6TgxSrm0eHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for VVPgcXqOTRbEUBmk2ao,sspW29TnCh1 in jEJgDiVnmcqzRahbtySUs4AdI9HBp:
			VVPgcXqOTRbEUBmk2ao = VVPgcXqOTRbEUBmk2ao.replace('"',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			L2kZzbT7r5DjfishylqR61QOu[VVPgcXqOTRbEUBmk2ao] = sspW29TnCh1.strip(UpN1CezytPO9XoduhxZSD)
		DXxRozgLGqn3TC5vVsdh1j8P0Be = list(L2kZzbT7r5DjfishylqR61QOu.keys())
		if not oGVqE4JR3DIcTNtAghW9:
			if 'name' in DXxRozgLGqn3TC5vVsdh1j8P0Be and L2kZzbT7r5DjfishylqR61QOu['name']: oGVqE4JR3DIcTNtAghW9 = L2kZzbT7r5DjfishylqR61QOu['name']
		L2kZzbT7r5DjfishylqR61QOu['title'] = oGVqE4JR3DIcTNtAghW9.strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if 'logo' in DXxRozgLGqn3TC5vVsdh1j8P0Be:
			L2kZzbT7r5DjfishylqR61QOu['img'] = L2kZzbT7r5DjfishylqR61QOu['logo']
			del L2kZzbT7r5DjfishylqR61QOu['logo']
		else: L2kZzbT7r5DjfishylqR61QOu['img'] = gby0BnUuTNFk
		if 'group' in DXxRozgLGqn3TC5vVsdh1j8P0Be and L2kZzbT7r5DjfishylqR61QOu['group']: r9rIzYVD0ceyC1uUofpPJF45tWbR = L2kZzbT7r5DjfishylqR61QOu['group']
		if any(value in UJeuWoLKP7ZI15O4ypTVs8caj.lower() for value in ssW7FnU0o5Y39btBL):
			aaOKNe8gwz592oSGj1yrBnduH = True if 'm3u' not in UJeuWoLKP7ZI15O4ypTVs8caj else False
		if aaOKNe8gwz592oSGj1yrBnduH or '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR or '__MOVIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR:
			ZZrjMgRGiY2IDN7q = 'VOD'
			if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_SERIES'
			elif '__MOVIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_MOVIES'
			else: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_UNKNOWN'
			r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.replace('__SERIES__',gby0BnUuTNFk).replace('__MOVIES__',gby0BnUuTNFk)
		else:
			ZZrjMgRGiY2IDN7q = 'LIVE'
			if oGVqE4JR3DIcTNtAghW9 in BAVbEI0J5XxG: EyvQhYU4jZoGuwtW7M9JXb = EyvQhYU4jZoGuwtW7M9JXb+'_EPG'
			if oGVqE4JR3DIcTNtAghW9 in jjLJvOMTAEy5Gczn4bH: EyvQhYU4jZoGuwtW7M9JXb = EyvQhYU4jZoGuwtW7M9JXb+'_ARCHIVED'
			if not r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_UNKNOWN'
			else: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+EyvQhYU4jZoGuwtW7M9JXb
		r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if 'LIVE_UNKNOWN' in ZZrjMgRGiY2IDN7q: r9rIzYVD0ceyC1uUofpPJF45tWbR = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ZZrjMgRGiY2IDN7q: r9rIzYVD0ceyC1uUofpPJF45tWbR = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ZZrjMgRGiY2IDN7q:
			BSW4piKu1cvol2MZbwtR5yk = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) [Ss]\d+ +[Ee]\d+',L2kZzbT7r5DjfishylqR61QOu['title'],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if BSW4piKu1cvol2MZbwtR5yk: BSW4piKu1cvol2MZbwtR5yk = BSW4piKu1cvol2MZbwtR5yk[0]
			else: BSW4piKu1cvol2MZbwtR5yk = '!!__UNKNOWN_SERIES__!!'
			r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR+'__SERIES__'+BSW4piKu1cvol2MZbwtR5yk
		if 'id' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['id']
		if 'ID' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['ID']
		if 'name' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['name']
		oGVqE4JR3DIcTNtAghW9 = L2kZzbT7r5DjfishylqR61QOu['title']
		oGVqE4JR3DIcTNtAghW9 = biVjhGCg0v5eEzkHwTrK9FIAtPU2(oGVqE4JR3DIcTNtAghW9)
		oGVqE4JR3DIcTNtAghW9 = kkTuFIfJsSM6Q(oGVqE4JR3DIcTNtAghW9)
		ZszECJvNng3TF,r9rIzYVD0ceyC1uUofpPJF45tWbR = ANoYGmuWy8w3FISMcxJ2B(r9rIzYVD0ceyC1uUofpPJF45tWbR)
		Wel7UCTIciR6pxYm8hzk1,oGVqE4JR3DIcTNtAghW9 = ANoYGmuWy8w3FISMcxJ2B(oGVqE4JR3DIcTNtAghW9)
		L2kZzbT7r5DjfishylqR61QOu['type'] = ZZrjMgRGiY2IDN7q
		L2kZzbT7r5DjfishylqR61QOu['context'] = EyvQhYU4jZoGuwtW7M9JXb
		L2kZzbT7r5DjfishylqR61QOu['group'] = r9rIzYVD0ceyC1uUofpPJF45tWbR.upper()
		L2kZzbT7r5DjfishylqR61QOu['title'] = oGVqE4JR3DIcTNtAghW9.upper()
		L2kZzbT7r5DjfishylqR61QOu['country'] = Wel7UCTIciR6pxYm8hzk1.upper()
		L2kZzbT7r5DjfishylqR61QOu['language'] = ZszECJvNng3TF.upper()
		T7hyMuvVz9EqkOasZDSJ.append(L2kZzbT7r5DjfishylqR61QOu)
		HTm1lXjkbF0UJCnpZOYERaG += 1
	return T7hyMuvVz9EqkOasZDSJ,HTm1lXjkbF0UJCnpZOYERaG,DmTNIZjxUY9HEd1
def kkTuFIfJsSM6Q(oGVqE4JR3DIcTNtAghW9):
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('||','|').replace('___',':').replace('--','-')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('[[','[').replace(']]',']')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('((','(').replace('))',')')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('<<','<').replace('>>','>')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.strip(UpN1CezytPO9XoduhxZSD)
	return oGVqE4JR3DIcTNtAghW9
def BwXOlFxGUdNjyW(pa4dtfsv23hgT0YK6cqCPDNlob,SGubLHYpURo5Dt63asfPM9eW,PhCw7H3Z1vpMOckgt04fr9):
	zjtcCHiX5rJ9TkVW = {}
	for Qw87uAPEDiOabR31 in JVs3roSjn5u: zjtcCHiX5rJ9TkVW[Qw87uAPEDiOabR31+'_'+PhCw7H3Z1vpMOckgt04fr9] = []
	SQfeyZdsPa72rv9kLwcnDUFjhlWT = len(pa4dtfsv23hgT0YK6cqCPDNlob)
	YYtTsJaAfEx3VcGlmpoQzrw = str(SQfeyZdsPa72rv9kLwcnDUFjhlWT)
	HTm1lXjkbF0UJCnpZOYERaG = 0
	DmTNIZjxUY9HEd1 = []
	for L2kZzbT7r5DjfishylqR61QOu in pa4dtfsv23hgT0YK6cqCPDNlob:
		if HTm1lXjkbF0UJCnpZOYERaG%873==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,50+int(5*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+YYtTsJaAfEx3VcGlmpoQzrw)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None
		r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = L2kZzbT7r5DjfishylqR61QOu['group'],L2kZzbT7r5DjfishylqR61QOu['context'],L2kZzbT7r5DjfishylqR61QOu['title'],L2kZzbT7r5DjfishylqR61QOu['url'],L2kZzbT7r5DjfishylqR61QOu['img']
		Wel7UCTIciR6pxYm8hzk1,ZszECJvNng3TF,Qw87uAPEDiOabR31 = L2kZzbT7r5DjfishylqR61QOu['country'],L2kZzbT7r5DjfishylqR61QOu['language'],L2kZzbT7r5DjfishylqR61QOu['type']
		u2O8xRJtfD = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		yTr9NcszeEp4hMubAfDdij5lBStHR = False
		if 'LIVE' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_UNKNOWN_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			elif 'LIVE' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
			zjtcCHiX5rJ9TkVW['LIVE_ORIGINAL_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
		elif 'VOD' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_UNKNOWN_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			elif 'MOVIES' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_MOVIES_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			elif 'SERIES' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_SERIES_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
			zjtcCHiX5rJ9TkVW['VOD_ORIGINAL_GROUPED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
		else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
		if yTr9NcszeEp4hMubAfDdij5lBStHR: DmTNIZjxUY9HEd1.append(L2kZzbT7r5DjfishylqR61QOu)
		HTm1lXjkbF0UJCnpZOYERaG += 1
	MO7F532BTYQLnl0 = sorted(pa4dtfsv23hgT0YK6cqCPDNlob,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao['title'].lower())
	del pa4dtfsv23hgT0YK6cqCPDNlob
	YYtTsJaAfEx3VcGlmpoQzrw = str(SQfeyZdsPa72rv9kLwcnDUFjhlWT)
	HTm1lXjkbF0UJCnpZOYERaG = 0
	for L2kZzbT7r5DjfishylqR61QOu in MO7F532BTYQLnl0:
		HTm1lXjkbF0UJCnpZOYERaG += 1
		if HTm1lXjkbF0UJCnpZOYERaG%873==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,55+int(5*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+YYtTsJaAfEx3VcGlmpoQzrw)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None
		Qw87uAPEDiOabR31 = L2kZzbT7r5DjfishylqR61QOu['type']
		r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = L2kZzbT7r5DjfishylqR61QOu['group'],L2kZzbT7r5DjfishylqR61QOu['context'],L2kZzbT7r5DjfishylqR61QOu['title'],L2kZzbT7r5DjfishylqR61QOu['url'],L2kZzbT7r5DjfishylqR61QOu['img']
		Wel7UCTIciR6pxYm8hzk1,ZszECJvNng3TF = L2kZzbT7r5DjfishylqR61QOu['country'],L2kZzbT7r5DjfishylqR61QOu['language']
		TEsoblmKGP1aBIYc30uRw = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb+'_TIMESHIFT',oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		u2O8xRJtfD = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		IIWRQcw15hV = (Wel7UCTIciR6pxYm8hzk1,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		a3aGkSQUh0VzCov = (ZszECJvNng3TF,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		if 'LIVE' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_UNKNOWN_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			else: zjtcCHiX5rJ9TkVW['LIVE_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			if 'EPG'		in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_EPG_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			if 'ARCHIVED'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_ARCHIVED_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			if 'ARCHIVED'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_TIMESHIFT_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(TEsoblmKGP1aBIYc30uRw)
			zjtcCHiX5rJ9TkVW['LIVE_FROM_NAME_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(IIWRQcw15hV)
			zjtcCHiX5rJ9TkVW['LIVE_FROM_GROUP_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(a3aGkSQUh0VzCov)
		elif 'VOD' in Qw87uAPEDiOabR31:
			if   'UNKNOWN'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_UNKNOWN_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			elif 'MOVIES'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_MOVIES_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			elif 'SERIES'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_SERIES_GROUPED_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(u2O8xRJtfD)
			zjtcCHiX5rJ9TkVW['VOD_FROM_NAME_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(IIWRQcw15hV)
			zjtcCHiX5rJ9TkVW['VOD_FROM_GROUP_SORTED_'+PhCw7H3Z1vpMOckgt04fr9].append(a3aGkSQUh0VzCov)
	return zjtcCHiX5rJ9TkVW,DmTNIZjxUY9HEd1
def ANoYGmuWy8w3FISMcxJ2B(oGVqE4JR3DIcTNtAghW9):
	if len(oGVqE4JR3DIcTNtAghW9)<3: return oGVqE4JR3DIcTNtAghW9,oGVqE4JR3DIcTNtAghW9
	wdKVTULEc7BlX62J,seH2r3E7MIu6nc = gby0BnUuTNFk,gby0BnUuTNFk
	mSILAkdsGBCpx = oGVqE4JR3DIcTNtAghW9
	dGa2sRtqhwrvUT6HIeJC9c = oGVqE4JR3DIcTNtAghW9[:1]
	MNbGEJ84v7okqsOaIZenuy2hlXFWt = oGVqE4JR3DIcTNtAghW9[1:]
	if   dGa2sRtqhwrvUT6HIeJC9c=='(': seH2r3E7MIu6nc = ')'
	elif dGa2sRtqhwrvUT6HIeJC9c=='[': seH2r3E7MIu6nc = ']'
	elif dGa2sRtqhwrvUT6HIeJC9c=='<': seH2r3E7MIu6nc = '>'
	elif dGa2sRtqhwrvUT6HIeJC9c=='|': seH2r3E7MIu6nc = '|'
	if seH2r3E7MIu6nc and (seH2r3E7MIu6nc in MNbGEJ84v7okqsOaIZenuy2hlXFWt):
		CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = MNbGEJ84v7okqsOaIZenuy2hlXFWt.split(seH2r3E7MIu6nc,1)
		wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
		mSILAkdsGBCpx = dGa2sRtqhwrvUT6HIeJC9c+CQE8ZILpTt7wYyhciVe4fUdo3nA+seH2r3E7MIu6nc+UpN1CezytPO9XoduhxZSD+dcCoDw5B9K8HftYG
	elif oGVqE4JR3DIcTNtAghW9.count('|')>=2:
		CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = oGVqE4JR3DIcTNtAghW9.split('|',1)
		wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
		mSILAkdsGBCpx = CQE8ZILpTt7wYyhciVe4fUdo3nA+' |'+dcCoDw5B9K8HftYG
	else:
		seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not seH2r3E7MIu6nc: seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not seH2r3E7MIu6nc: seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if seH2r3E7MIu6nc:
			CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = oGVqE4JR3DIcTNtAghW9.split(seH2r3E7MIu6nc[0],1)
			wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
			mSILAkdsGBCpx = CQE8ZILpTt7wYyhciVe4fUdo3nA+UpN1CezytPO9XoduhxZSD+seH2r3E7MIu6nc[0]+UpN1CezytPO9XoduhxZSD+dcCoDw5B9K8HftYG
	mSILAkdsGBCpx = mSILAkdsGBCpx.replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	wdKVTULEc7BlX62J = wdKVTULEc7BlX62J.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	if not wdKVTULEc7BlX62J: wdKVTULEc7BlX62J = '!!__UNKNOWN__!!'
	wdKVTULEc7BlX62J = wdKVTULEc7BlX62J.strip(UpN1CezytPO9XoduhxZSD)
	mSILAkdsGBCpx = mSILAkdsGBCpx.strip(UpN1CezytPO9XoduhxZSD)
	return wdKVTULEc7BlX62J,mSILAkdsGBCpx
def dWxL30fTGqPpl1z8Bo(Z27widCyESA):
	vO65KkJHupCrocdLe = {}
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.useragent_'+Z27widCyESA)
	if Z38Zes0IBSDYCLPGJfM6j: vO65KkJHupCrocdLe['User-Agent'] = Z38Zes0IBSDYCLPGJfM6j
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.referer_'+Z27widCyESA)
	if vBJn6DgVPG7sqoprY: vO65KkJHupCrocdLe['Referer'] = vBJn6DgVPG7sqoprY
	return vO65KkJHupCrocdLe
def uj7O46p1qPsiHlyTKRtwe8N2(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	y5Cv1XOeJmLa4zDr = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.url_'+Z27widCyESA+'_'+PhCw7H3Z1vpMOckgt04fr9)
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.useragent_'+Z27widCyESA)
	vO65KkJHupCrocdLe = {'User-Agent':Z38Zes0IBSDYCLPGJfM6j}
	P9PI1QNFzMEDk = dxb4sYrRAG.replace('___','_'+Z27widCyESA+'_'+PhCw7H3Z1vpMOckgt04fr9)
	if 1:
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = True,gby0BnUuTNFk,gby0BnUuTNFk
		if not ww8aEQ9UGz1ms3qOeXvDkfFMTdV:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not y5Cv1XOeJmLa4zDr: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+'   No M3U URL found to download M3U files')
			else: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(BZqfNTuc7nKbG1lh)+'   Failed to download M3U files')
			return
		U8U4QPpgIaovkiCuc30mBEd9yNLXsO = EckxoYzjdgLH0r(y5Cv1XOeJmLa4zDr,vO65KkJHupCrocdLe,True)
		if not U8U4QPpgIaovkiCuc30mBEd9yNLXsO: return
		open(P9PI1QNFzMEDk,'wb').write(U8U4QPpgIaovkiCuc30mBEd9yNLXsO)
	else: U8U4QPpgIaovkiCuc30mBEd9yNLXsO = open(P9PI1QNFzMEDk,'rb').read()
	if nqkybtoMBH and U8U4QPpgIaovkiCuc30mBEd9yNLXsO: U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.decode(JJQFjSIlALchiMzG9)
	SGubLHYpURo5Dt63asfPM9eW = gX5UxB8Sce7tuvjkNaoIAHDq4()
	SGubLHYpURo5Dt63asfPM9eW.create('جلب ملفات M3U جديدة',gby0BnUuTNFk)
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,15,'تنظيف الملف الرئيسي',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('"tvg-','" tvg-')
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('َ',gby0BnUuTNFk).replace('ً',gby0BnUuTNFk).replace('ُ',gby0BnUuTNFk).replace('ٌ',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('ّ',gby0BnUuTNFk).replace('ِ',gby0BnUuTNFk).replace('ٍ',gby0BnUuTNFk).replace('ْ',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('group-title=','group=').replace('tvg-',gby0BnUuTNFk)
	jjLJvOMTAEy5Gczn4bH,BAVbEI0J5XxG = [],[]
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace(Hd14YjcWpvPhN8sZXK3,okfdjS4RmM)
	uA0Ja8qPSW9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('NF:(.+?)'+'#'+'EXTI',U8U4QPpgIaovkiCuc30mBEd9yNLXsO+'\n+'+'#'+'EXTINF:',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not uA0Ja8qPSW9:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(BZqfNTuc7nKbG1lh)+'   Folder:'+Z27widCyESA+'  Sequence:'+PhCw7H3Z1vpMOckgt04fr9+'   No video links found in M3U file')
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+'مجلد رقم '+Z27widCyESA+'      رابط رقم '+PhCw7H3Z1vpMOckgt04fr9+GGy0cQe765nPYZ9E8Th)
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	hjufnKU5rGEgRD4H8 = []
	for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
		HranyDdf74SG1JQq6oXkmc = dlb6TgxSrm0eHB.lower()
		if 'adult' in HranyDdf74SG1JQq6oXkmc: continue
		if 'xxx' in HranyDdf74SG1JQq6oXkmc: continue
		hjufnKU5rGEgRD4H8.append(dlb6TgxSrm0eHB)
	uA0Ja8qPSW9 = hjufnKU5rGEgRD4H8
	del hjufnKU5rGEgRD4H8
	if 'iptv-org' in y5Cv1XOeJmLa4zDr:
		hjufnKU5rGEgRD4H8,CZOBcqyYQhTdkV2EMveXb0R3ULN8D7 = [],[]
		for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
			qleCEa50kOYvVNSJuDP1R4FdhtoIxw = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('group="(.*?)"',dlb6TgxSrm0eHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
				qleCEa50kOYvVNSJuDP1R4FdhtoIxw = qleCEa50kOYvVNSJuDP1R4FdhtoIxw[0]
				YYriFXHUaqeKEjbT98PRzSNukgQ = qleCEa50kOYvVNSJuDP1R4FdhtoIxw.split(';')
				if 'region' in y5Cv1XOeJmLa4zDr: S5FloOdPZMqXh2JRmNxY9Wpt7 = '1_'
				elif 'category' in y5Cv1XOeJmLa4zDr: S5FloOdPZMqXh2JRmNxY9Wpt7 = '2_'
				elif 'language' in y5Cv1XOeJmLa4zDr: S5FloOdPZMqXh2JRmNxY9Wpt7 = '3_'
				elif 'country' in y5Cv1XOeJmLa4zDr: S5FloOdPZMqXh2JRmNxY9Wpt7 = '4_'
				else: S5FloOdPZMqXh2JRmNxY9Wpt7 = '5_'
				YNUV0kdwMeB4sX = dlb6TgxSrm0eHB.replace('group="'+qleCEa50kOYvVNSJuDP1R4FdhtoIxw+'"','group="'+S5FloOdPZMqXh2JRmNxY9Wpt7+'~'+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th+'"')
				hjufnKU5rGEgRD4H8.append(YNUV0kdwMeB4sX)
				for r9rIzYVD0ceyC1uUofpPJF45tWbR in YYriFXHUaqeKEjbT98PRzSNukgQ:
					YNUV0kdwMeB4sX = dlb6TgxSrm0eHB.replace('group="'+qleCEa50kOYvVNSJuDP1R4FdhtoIxw+'"','group="'+S5FloOdPZMqXh2JRmNxY9Wpt7+r9rIzYVD0ceyC1uUofpPJF45tWbR+'"')
					hjufnKU5rGEgRD4H8.append(YNUV0kdwMeB4sX)
			else: hjufnKU5rGEgRD4H8.append(dlb6TgxSrm0eHB)
		uA0Ja8qPSW9 = hjufnKU5rGEgRD4H8
		del hjufnKU5rGEgRD4H8,CZOBcqyYQhTdkV2EMveXb0R3ULN8D7
	fMY5WCpDr7XGTzUv1qZHd = 1024*1024
	Lnd4Juz7KaNUXy6Cop = 1+len(U8U4QPpgIaovkiCuc30mBEd9yNLXsO)//fMY5WCpDr7XGTzUv1qZHd//10
	del U8U4QPpgIaovkiCuc30mBEd9yNLXsO
	NIERLMmxdG = len(uA0Ja8qPSW9)
	CZOBcqyYQhTdkV2EMveXb0R3ULN8D7 = Zdw6qDQULYRG(uA0Ja8qPSW9,Lnd4Juz7KaNUXy6Cop)
	del uA0Ja8qPSW9
	for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(Lnd4Juz7KaNUXy6Cop):
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,35+int(5*ZOfCnxmPUWEpvBVtYj5RSDMrcd/Lnd4Juz7KaNUXy6Cop),'تقطيع الملف الرئيسي','الجزء رقم:-',str(ZOfCnxmPUWEpvBVtYj5RSDMrcd+1)+' / '+str(Lnd4Juz7KaNUXy6Cop))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		W8WyuMC9mTN5c = str(CZOBcqyYQhTdkV2EMveXb0R3ULN8D7[ZOfCnxmPUWEpvBVtYj5RSDMrcd])
		if nqkybtoMBH: W8WyuMC9mTN5c = W8WyuMC9mTN5c.encode(JJQFjSIlALchiMzG9)
		open(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd),'wb').write(W8WyuMC9mTN5c)
	del CZOBcqyYQhTdkV2EMveXb0R3ULN8D7,W8WyuMC9mTN5c
	G3LX0b8akfYvWPh7zm2tqU,pa4dtfsv23hgT0YK6cqCPDNlob,HTm1lXjkbF0UJCnpZOYERaG = [],[],0
	for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(Lnd4Juz7KaNUXy6Cop):
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		W8WyuMC9mTN5c = open(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd),'rb').read()
		RyfYSek61do5OnQMc.sleep(1)
		try: bCoOHfPdMryRgauz0IVpth.remove(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd))
		except: pass
		if nqkybtoMBH: W8WyuMC9mTN5c = W8WyuMC9mTN5c.decode(JJQFjSIlALchiMzG9)
		mwJHTsvSGF3hP90 = TqNUy3Z4SFWvplGwXC82A('list',W8WyuMC9mTN5c)
		del W8WyuMC9mTN5c
		T7hyMuvVz9EqkOasZDSJ,HTm1lXjkbF0UJCnpZOYERaG,DmTNIZjxUY9HEd1 = T5tyHdWREw2kJ(mwJHTsvSGF3hP90,BAVbEI0J5XxG,jjLJvOMTAEy5Gczn4bH,SGubLHYpURo5Dt63asfPM9eW,NIERLMmxdG,HTm1lXjkbF0UJCnpZOYERaG,y5Cv1XOeJmLa4zDr)
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		if not T7hyMuvVz9EqkOasZDSJ:
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		pa4dtfsv23hgT0YK6cqCPDNlob += T7hyMuvVz9EqkOasZDSJ
		G3LX0b8akfYvWPh7zm2tqU += DmTNIZjxUY9HEd1
	del mwJHTsvSGF3hP90,T7hyMuvVz9EqkOasZDSJ
	zjtcCHiX5rJ9TkVW,DmTNIZjxUY9HEd1 = BwXOlFxGUdNjyW(pa4dtfsv23hgT0YK6cqCPDNlob,SGubLHYpURo5Dt63asfPM9eW,PhCw7H3Z1vpMOckgt04fr9)
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	G3LX0b8akfYvWPh7zm2tqU += DmTNIZjxUY9HEd1
	del pa4dtfsv23hgT0YK6cqCPDNlob,DmTNIZjxUY9HEd1
	PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE = {},{},{},0,0
	KSPsvbM056hiYzuHVTJDEtdAxl = list(zjtcCHiX5rJ9TkVW.keys())
	oYJIFdRbM8y9HpcrNPaz2 = len(KSPsvbM056hiYzuHVTJDEtdAxl)*3
	if 1:
		QQAPWB1Gs3xdF5 = {}
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=HLl9n75QpKU,args=(kVGU1uhays3EWfH,))
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].start()
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].join()
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
	else:
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			HLl9n75QpKU(kVGU1uhays3EWfH)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
	D7u5TUiYHQ(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9,False)
	KSPsvbM056hiYzuHVTJDEtdAxl = list(PuIwj1QHal3U2c.keys())
	QDZz9UxbmYgBlfjEW45hyrsCdw76 = 0
	if 1:
		QQAPWB1Gs3xdF5 = {}
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=pKUDsgqGoOZ1CvSyaPTrW4m0c6,args=(Z27widCyESA,kVGU1uhays3EWfH))
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].start()
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].join()
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
	else:
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			pKUDsgqGoOZ1CvSyaPTrW4m0c6(Z27widCyESA,kVGU1uhays3EWfH)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
	ZOfCnxmPUWEpvBVtYj5RSDMrcd = 0
	NxgpIr8GPm = len(G3LX0b8akfYvWPh7zm2tqU)
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'IGNORED')
	for vGAHiWjyCMoz in G3LX0b8akfYvWPh7zm2tqU:
		if ZOfCnxmPUWEpvBVtYj5RSDMrcd%27==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,95+int(5*ZOfCnxmPUWEpvBVtYj5RSDMrcd//NxgpIr8GPm),'تخزين المهملة','الفيديو رقم:-',str(ZOfCnxmPUWEpvBVtYj5RSDMrcd)+' / '+str(NxgpIr8GPm))
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
		CExrgJh48PYI2(WXZRrenmT8v,'IGNORED_'+PhCw7H3Z1vpMOckgt04fr9,str(vGAHiWjyCMoz),gby0BnUuTNFk,Z83rChqtg1oXUjI4YL)
		ZOfCnxmPUWEpvBVtYj5RSDMrcd += 1
	CExrgJh48PYI2(WXZRrenmT8v,'IGNORED_'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__',str(NxgpIr8GPm),Z83rChqtg1oXUjI4YL)
	SGubLHYpURo5Dt63asfPM9eW.close()
	RyfYSek61do5OnQMc.sleep(1)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def HLl9n75QpKU(kVGU1uhays3EWfH):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	PuIwj1QHal3U2c[kVGU1uhays3EWfH] = {}
	lS861QGjDwFJHqcC,G0pBESAFe8XRxgO3IUC9oVJkblfQ = {},[]
	CNxVvOGKPJ41gTkt = len(zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH])
	PuIwj1QHal3U2c[kVGU1uhays3EWfH]['__COUNT__'] = CNxVvOGKPJ41gTkt
	if CNxVvOGKPJ41gTkt>0:
		OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,qNPtwrdCkyVWQUYoiES0,P5kgKvGWa9RCDA8c4fmV0,WI8aunoi406OY1hRpB7,P37Ptlixv2AeSLnY5BWXq = zip(*zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH])
		del qNPtwrdCkyVWQUYoiES0,P5kgKvGWa9RCDA8c4fmV0,WI8aunoi406OY1hRpB7
		YYriFXHUaqeKEjbT98PRzSNukgQ = list(set(OIG9wLUcAxDp6mQNzJYHekPSqW5XZV))
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in YYriFXHUaqeKEjbT98PRzSNukgQ:
			lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] = gby0BnUuTNFk
			PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR] = []
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		GibLO06T1KCmdjNXE += 1
		J56yUgZ3FPm87 = len(YYriFXHUaqeKEjbT98PRzSNukgQ)
		del YYriFXHUaqeKEjbT98PRzSNukgQ
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = list(set(zip(OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,P37Ptlixv2AeSLnY5BWXq)))
		del OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,P37Ptlixv2AeSLnY5BWXq
		for r9rIzYVD0ceyC1uUofpPJF45tWbR,bxTDyYw3SV82Pt in G0pBESAFe8XRxgO3IUC9oVJkblfQ:
			if not lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] and bxTDyYw3SV82Pt: lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] = bxTDyYw3SV82Pt
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		GibLO06T1KCmdjNXE += 1
		VVzGqXedovr0kjHwWIxJR = list(lS861QGjDwFJHqcC.keys())
		YH6tTUMIa8vJOy0d1s7zAbiCr = list(lS861QGjDwFJHqcC.values())
		del lS861QGjDwFJHqcC
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = list(zip(VVzGqXedovr0kjHwWIxJR,YH6tTUMIa8vJOy0d1s7zAbiCr))
		del VVzGqXedovr0kjHwWIxJR,YH6tTUMIa8vJOy0d1s7zAbiCr
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = sorted(G0pBESAFe8XRxgO3IUC9oVJkblfQ)
	else: GibLO06T1KCmdjNXE += 2
	PuIwj1QHal3U2c[kVGU1uhays3EWfH]['__GROUPS__'] = G0pBESAFe8XRxgO3IUC9oVJkblfQ
	del G0pBESAFe8XRxgO3IUC9oVJkblfQ
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH]:
		PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR].append((EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
	GibLO06T1KCmdjNXE += 1
	del zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH]
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH] = list(PuIwj1QHal3U2c[kVGU1uhays3EWfH].keys())
	R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH] = len(qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH])
	uUyTZEwvm5 += R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]
	return
def pKUDsgqGoOZ1CvSyaPTrW4m0c6(Z27widCyESA,kVGU1uhays3EWfH):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	for HTm1lXjkbF0UJCnpZOYERaG in range(1+R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]//273):
		zzHkOcQNLo = []
		cIgxGlNm9jwQXF = qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH][0:273]
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in cIgxGlNm9jwQXF:
			zzHkOcQNLo.append(PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR])
		CExrgJh48PYI2(WXZRrenmT8v,kVGU1uhays3EWfH,cIgxGlNm9jwQXF,zzHkOcQNLo,Z83rChqtg1oXUjI4YL,True)
		QDZz9UxbmYgBlfjEW45hyrsCdw76 += len(cIgxGlNm9jwQXF)
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,75+int(20*QDZz9UxbmYgBlfjEW45hyrsCdw76//uUyTZEwvm5),'تخزين القوائم','القائمة رقم:-',str(QDZz9UxbmYgBlfjEW45hyrsCdw76)+' / '+str(uUyTZEwvm5))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		del qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH][0:273]
	del PuIwj1QHal3U2c[kVGU1uhays3EWfH],qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH],R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]
	return
def U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9,N9bXKIfsDVPjctLM5u=True):
	hmSXQ5yx8F4TCLMPpwB1DkY = 'عدد فيديوهات جميع الروابط'
	qCsgKhSfyce7NFZb2kAVIGm = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'LIVE_ORIGINAL_GROUPED')
	HAz5YEkZLQscingdRpX71yeFOmWv = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'VOD_ORIGINAL_GROUPED')
	if PhCw7H3Z1vpMOckgt04fr9:
		hmSXQ5yx8F4TCLMPpwB1DkY = 'عدد فيديوهات رابط '+XVANElz3tLn5pFPQUWi[int(PhCw7H3Z1vpMOckgt04fr9)]
		PhCw7H3Z1vpMOckgt04fr9 = '_'+PhCw7H3Z1vpMOckgt04fr9
	NxgpIr8GPm = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','IGNORED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	boDu2swfFIp = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_ORIGINAL_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	UOKaoQbxiZcP6IBRTW3uD0zFHkSyg = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'int','VOD_ORIGINAL_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	CCn71Ta3VmBIjc9sEUbopYAtZQG = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	nh3wDaGEs81ZWAomckugNdFte = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_UNKNOWN_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	IIS7m2LvHghPKrABR = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','VOD_MOVIES_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	dB2chsoPHL6fmZEO9I7AMC30UK = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'int','VOD_SERIES_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	vly38JEpOTiSrKf4D19w = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','VOD_UNKNOWN_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__COUNT__')
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'list','VOD_SERIES_GROUPED'+PhCw7H3Z1vpMOckgt04fr9,'__GROUPS__')
	Xeb0kM6wo9qYQxrSnsNvLiHfEhVP = []
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
		YodFENhiTUXJtr = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')[1]
		Xeb0kM6wo9qYQxrSnsNvLiHfEhVP.append(YodFENhiTUXJtr)
	pYslW6Ph8OxaFQVuA14f5zSELB3Ui7 = len(Xeb0kM6wo9qYQxrSnsNvLiHfEhVP)
	LbeM6usxzdNjYTXJ7iOoKEDgAkHf = int(IIS7m2LvHghPKrABR)+int(dB2chsoPHL6fmZEO9I7AMC30UK)+int(vly38JEpOTiSrKf4D19w)+int(nh3wDaGEs81ZWAomckugNdFte)+int(CCn71Ta3VmBIjc9sEUbopYAtZQG)
	XgSmd7DqBQhbcKj3GaZW = gby0BnUuTNFk
	XgSmd7DqBQhbcKj3GaZW += 'قنوات: '+str(CCn71Ta3VmBIjc9sEUbopYAtZQG)
	XgSmd7DqBQhbcKj3GaZW += '   .   أفلام: '+str(IIS7m2LvHghPKrABR)
	XgSmd7DqBQhbcKj3GaZW += '\nمسلسلات: '+str(pYslW6Ph8OxaFQVuA14f5zSELB3Ui7)
	XgSmd7DqBQhbcKj3GaZW += '   .   حلقات: '+str(dB2chsoPHL6fmZEO9I7AMC30UK)
	XgSmd7DqBQhbcKj3GaZW += '\nقنوات مجهولة: '+str(nh3wDaGEs81ZWAomckugNdFte)
	XgSmd7DqBQhbcKj3GaZW += '   .   فيدوهات مجهولة: '+str(vly38JEpOTiSrKf4D19w)
	XgSmd7DqBQhbcKj3GaZW += '\nمجموع القنوات: '+str(boDu2swfFIp)
	XgSmd7DqBQhbcKj3GaZW += '   .   مجموع الفيديوهات: '+str(UOKaoQbxiZcP6IBRTW3uD0zFHkSyg)
	XgSmd7DqBQhbcKj3GaZW += '\n\nمجموع المضافة: '+str(LbeM6usxzdNjYTXJ7iOoKEDgAkHf)
	XgSmd7DqBQhbcKj3GaZW += '   .   مجموع المهملة: '+str(NxgpIr8GPm)
	if N9bXKIfsDVPjctLM5u: tt3DVu1TU8dLAi('center',gby0BnUuTNFk,hmSXQ5yx8F4TCLMPpwB1DkY,XgSmd7DqBQhbcKj3GaZW)
	SSTV7KAnNCQPUvhL = XgSmd7DqBQhbcKj3GaZW.replace('\n\n',okfdjS4RmM)
	if not PhCw7H3Z1vpMOckgt04fr9: PhCw7H3Z1vpMOckgt04fr9 = 'All'
	else: PhCw7H3Z1vpMOckgt04fr9 = PhCw7H3Z1vpMOckgt04fr9[1]
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,'.\tCounts of M3U videos   Folder: '+Z27widCyESA+'   Sequence: '+PhCw7H3Z1vpMOckgt04fr9+okfdjS4RmM+SSTV7KAnNCQPUvhL)
	return XgSmd7DqBQhbcKj3GaZW
def D7u5TUiYHQ(Z27widCyESA,PhCw7H3Z1vpMOckgt04fr9,N9bXKIfsDVPjctLM5u=True):
	if N9bXKIfsDVPjctLM5u:
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return
		oP4hs5zHkY2 = dxb4sYrRAG.replace('___','_'+Z27widCyESA+'_'+PhCw7H3Z1vpMOckgt04fr9)
		try: bCoOHfPdMryRgauz0IVpth.remove(oP4hs5zHkY2)
		except: pass
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,gby0BnUuTNFk)
	if PhCw7H3Z1vpMOckgt04fr9:
		SsaMjb7RP8GzNVm = []
		for VcJ3oy4jdr2p8OXzYM in JVs3roSjn5u:
			SsaMjb7RP8GzNVm.append(VcJ3oy4jdr2p8OXzYM+'_'+PhCw7H3Z1vpMOckgt04fr9)
		dNqGfAEk0iXLwFU(WXZRrenmT8v,'LINK_'+PhCw7H3Z1vpMOckgt04fr9)
	else:
		SsaMjb7RP8GzNVm = JVs3roSjn5u
		dNqGfAEk0iXLwFU(WXZRrenmT8v,'DUMMY')
		dNqGfAEk0iXLwFU(WXZRrenmT8v,'GROUPS')
		dNqGfAEk0iXLwFU(WXZRrenmT8v,'ITEMS')
		dNqGfAEk0iXLwFU(WXZRrenmT8v,'SEARCH')
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_M3U','SECTIONS_M3U_'+Z27widCyESA)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for kVGU1uhays3EWfH in SsaMjb7RP8GzNVm:
		dNqGfAEk0iXLwFU(WXZRrenmT8v,kVGU1uhays3EWfH)
	Cjio8VzFbEgRfTNH3UrDJMZ(False)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	if N9bXKIfsDVPjctLM5u: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح جميع ملفات ـM3U')
	return
def hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=True):
	if Z27widCyESA:
		WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(str(Z27widCyESA),'DUMMY')
		G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'str','DUMMY','__DUMMY__')
		if G2A1zJCal59LbeSXhnPpcYqN8OD7Zw: return True
	else:
		Z27widCyESA = '1'
		for jyPnJKCVoqRL3b1hE2Zwdt5Q in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
			WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(str(jyPnJKCVoqRL3b1hE2Zwdt5Q),'DUMMY')
			G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'str','DUMMY','__DUMMY__')
			if G2A1zJCal59LbeSXhnPpcYqN8OD7Zw: return True
	if N9bXKIfsDVPjctLM5u:
		CCYpcVS78RlWL2ZPDOuUo5tz43i = 'https://iptv-org.github.io/iptv/index.region.m3u'
		SqkR8YbxaDPCfjBAdKL5 = 'https://iptv-org.github.io/iptv/index.category.m3u'
		f1WuHhaLc2KR8tTroXS6JNnY5siM = 'https://iptv-org.github.io/iptv/index.language.m3u'
		ICKzFlsLdtiZMbA3XQ8EY = 'https://iptv-org.github.io/iptv/index.country.m3u'
		boUQfIAxkt8qL2hm = CCYpcVS78RlWL2ZPDOuUo5tz43i+okfdjS4RmM+SqkR8YbxaDPCfjBAdKL5+okfdjS4RmM+f1WuHhaLc2KR8tTroXS6JNnY5siM+okfdjS4RmM+ICKzFlsLdtiZMbA3XQ8EY
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'http://github.com/iptv-org/iptv'+GGy0cQe765nPYZ9E8Th+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+boUQfIAxkt8qL2hm+GGy0cQe765nPYZ9E8Th,profile='confirm_smallfont')
		if BeU98noROVkGhHqN15fumPCvyWQcxJ==1:
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.url_'+str(Z27widCyESA)+'_1',CCYpcVS78RlWL2ZPDOuUo5tz43i)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.url_'+str(Z27widCyESA)+'_2',SqkR8YbxaDPCfjBAdKL5)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.url_'+str(Z27widCyESA)+'_3',f1WuHhaLc2KR8tTroXS6JNnY5siM)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.m3u.url_'+str(Z27widCyESA)+'_4',ICKzFlsLdtiZMbA3XQ8EY)
			BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if BeU98noROVkGhHqN15fumPCvyWQcxJ==1:
				w7wxoirQ4jV = ptHWugwnXD9yc1QhKb(Z27widCyESA)
				return w7wxoirQ4jV
		else:
			hmSXQ5yx8F4TCLMPpwB1DkY = 'إضافة وتغيير رابط '+XVANElz3tLn5pFPQUWi[1]+' (مجلد '+XVANElz3tLn5pFPQUWi[int(Z27widCyESA)]+')'
			BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,hmSXQ5yx8F4TCLMPpwB1DkY,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. ثانيا أنقر على إضافة رابط أو اشتراك M3U .. ثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if BeU98noROVkGhHqN15fumPCvyWQcxJ==1: BYRb8ALrn41jh7owmOH(Z27widCyESA,'1')
	return False
def H7l4URTtJj2ksaBQwb(Dak6tVP8I7zdT5329ijCLFwGsgMo,Z27widCyESA=gby0BnUuTNFk,kVGU1uhays3EWfH=gby0BnUuTNFk,UwrnXuFkvEh9xRs5Z1=gby0BnUuTNFk):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	JmMO69oYEwIj,N1FbhV4lx6QcWOo,N9bXKIfsDVPjctLM5u = ZZV4kLG1nmbIjt(Dak6tVP8I7zdT5329ijCLFwGsgMo)
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
	OFlhCn7jy3vTA9VSesDx = [gby0BnUuTNFk,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not kVGU1uhays3EWfH:
		if not N9bXKIfsDVPjctLM5u:
			if   '_M3U-LIVE_' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[1]
			elif '_M3U-MOVIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[2]
			elif '_M3U-SERIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[3]
			else: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[0]
		else:
			k4T65Vrzap3sL7Z9ybW = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			JlbGIYdQZkvtqjmR5r7 = i4r2OdGLlMhDEWfCVU0TKe3('أختر البحث المناسب', k4T65Vrzap3sL7Z9ybW)
			if JlbGIYdQZkvtqjmR5r7==-1: return
			kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[JlbGIYdQZkvtqjmR5r7]
	JmMO69oYEwIj = JmMO69oYEwIj+'_NODIALOGS_'
	if Z27widCyESA: zzVD2aYBrXNtmGqwxcJ3eLTnIps(JmMO69oYEwIj,Z27widCyESA,kVGU1uhays3EWfH,UwrnXuFkvEh9xRs5Z1)
	else:
		for Z27widCyESA in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
			zzVD2aYBrXNtmGqwxcJ3eLTnIps(JmMO69oYEwIj,str(Z27widCyESA),kVGU1uhays3EWfH,UwrnXuFkvEh9xRs5Z1)
		wAcHkmPB8a.menuItemsLIST[:] = sorted(wAcHkmPB8a.menuItemsLIST,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1].lower())
	return
def zzVD2aYBrXNtmGqwxcJ3eLTnIps(Dak6tVP8I7zdT5329ijCLFwGsgMo,Z27widCyESA,kVGU1uhays3EWfH=gby0BnUuTNFk,UwrnXuFkvEh9xRs5Z1=gby0BnUuTNFk):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	JmMO69oYEwIj,N1FbhV4lx6QcWOo,N9bXKIfsDVPjctLM5u = ZZV4kLG1nmbIjt(Dak6tVP8I7zdT5329ijCLFwGsgMo)
	if not Z27widCyESA: return
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
	OFlhCn7jy3vTA9VSesDx = [gby0BnUuTNFk,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not kVGU1uhays3EWfH:
		if not N9bXKIfsDVPjctLM5u:
			if   '_M3U-LIVE_' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[1]
			elif '_M3U-MOVIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[2]
			elif '_M3U-SERIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[3]
			else: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[0]
		else:
			k4T65Vrzap3sL7Z9ybW = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			JlbGIYdQZkvtqjmR5r7 = i4r2OdGLlMhDEWfCVU0TKe3('أختر البحث المناسب', k4T65Vrzap3sL7Z9ybW)
			if JlbGIYdQZkvtqjmR5r7==-1: return
			kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[JlbGIYdQZkvtqjmR5r7]
	HRcCyi6sX0tZNjBwDKlrGmk = JmMO69oYEwIj.lower()
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'SEARCH')
	PgTIFSCwRY3haxjiok = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','SEARCH',(kVGU1uhays3EWfH,HRcCyi6sX0tZNjBwDKlrGmk))
	if not PgTIFSCwRY3haxjiok:
		RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ = [],[]
		if not kVGU1uhays3EWfH: g87gzmJhBN5kSHrQwEf = [1,2,3,4,5]
		else: g87gzmJhBN5kSHrQwEf = [OFlhCn7jy3vTA9VSesDx.index(kVGU1uhays3EWfH)]
		for ZOfCnxmPUWEpvBVtYj5RSDMrcd in g87gzmJhBN5kSHrQwEf:
			if ZOfCnxmPUWEpvBVtYj5RSDMrcd!=3:
				T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'dict',OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd])
				del T7hyMuvVz9EqkOasZDSJ['__COUNT__']
				del T7hyMuvVz9EqkOasZDSJ['__GROUPS__']
				del T7hyMuvVz9EqkOasZDSJ['__SEQUENCED_COLUMNS__']
				qleCEa50kOYvVNSJuDP1R4FdhtoIxw = list(T7hyMuvVz9EqkOasZDSJ.keys())
				for r9rIzYVD0ceyC1uUofpPJF45tWbR in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
					for EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in T7hyMuvVz9EqkOasZDSJ[r9rIzYVD0ceyC1uUofpPJF45tWbR]:
						if HRcCyi6sX0tZNjBwDKlrGmk in oGVqE4JR3DIcTNtAghW9.lower(): ffgipIRaySJeEPmQ.append((oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
					del T7hyMuvVz9EqkOasZDSJ[r9rIzYVD0ceyC1uUofpPJF45tWbR]
				del T7hyMuvVz9EqkOasZDSJ
			else: qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd],'__GROUPS__')
			for r9rIzYVD0ceyC1uUofpPJF45tWbR in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
				try: r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = r9rIzYVD0ceyC1uUofpPJF45tWbR
				except: Eoyrc5lpZQdsfbq3jtzSWhxKUGM = gby0BnUuTNFk
				if HRcCyi6sX0tZNjBwDKlrGmk in r9rIzYVD0ceyC1uUofpPJF45tWbR.lower():
					if ZOfCnxmPUWEpvBVtYj5RSDMrcd!=3: h2ixLA9FTfVW15QpBjZtID0arN3y7 = r9rIzYVD0ceyC1uUofpPJF45tWbR
					else:
						KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')
						if HRcCyi6sX0tZNjBwDKlrGmk in KVxLWm5201GJnaIElF8ASUi.lower(): h2ixLA9FTfVW15QpBjZtID0arN3y7 = KVxLWm5201GJnaIElF8ASUi
						else: h2ixLA9FTfVW15QpBjZtID0arN3y7 = Nd0fkcwTIV2JhMLxKbD7Go1e9A
					RRjw4NMhdxlQoFiO1fZCuKc.append((r9rIzYVD0ceyC1uUofpPJF45tWbR,h2ixLA9FTfVW15QpBjZtID0arN3y7,OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd],Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
			del qleCEa50kOYvVNSJuDP1R4FdhtoIxw
		RRjw4NMhdxlQoFiO1fZCuKc = set(RRjw4NMhdxlQoFiO1fZCuKc)
		ffgipIRaySJeEPmQ = set(ffgipIRaySJeEPmQ)
		RRjw4NMhdxlQoFiO1fZCuKc = sorted(RRjw4NMhdxlQoFiO1fZCuKc,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1])
		ffgipIRaySJeEPmQ = sorted(ffgipIRaySJeEPmQ,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[0])
		CExrgJh48PYI2(WXZRrenmT8v,'SEARCH',(kVGU1uhays3EWfH,HRcCyi6sX0tZNjBwDKlrGmk),(RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ),Z83rChqtg1oXUjI4YL)
	else: RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ = PgTIFSCwRY3haxjiok
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw = len(RRjw4NMhdxlQoFiO1fZCuKc)
	SjFdfrleWyqA9QIB = len(ffgipIRaySJeEPmQ)
	LL4W9eHQmsxZ = int(UwrnXuFkvEh9xRs5Z1)
	UhIg7pn4wxLXPJG3VH6M0oWzEjvO = max(0,(LL4W9eHQmsxZ-1)*100)
	jEYe1imyKQOcgBhM4X = max(0,LL4W9eHQmsxZ*100)
	XKBi93PeRLzw0NjZSYVmf = max(0,UhIg7pn4wxLXPJG3VH6M0oWzEjvO-qleCEa50kOYvVNSJuDP1R4FdhtoIxw)
	l8iSjTnkEzf3Be4M9 = max(0,jEYe1imyKQOcgBhM4X-qleCEa50kOYvVNSJuDP1R4FdhtoIxw)
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,h2ixLA9FTfVW15QpBjZtID0arN3y7,dsMGf6S2kKcFOBHAuhjq83EoY,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in RRjw4NMhdxlQoFiO1fZCuKc[UhIg7pn4wxLXPJG3VH6M0oWzEjvO:jEYe1imyKQOcgBhM4X]:
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+h2ixLA9FTfVW15QpBjZtID0arN3y7,dsMGf6S2kKcFOBHAuhjq83EoY,714,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
	del RRjw4NMhdxlQoFiO1fZCuKc
	for oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in ffgipIRaySJeEPmQ[XKBi93PeRLzw0NjZSYVmf:l8iSjTnkEzf3Be4M9]:
		t6GiBhlvwIjD0RY = ymlrSBXjxRaY5kcKtU7MTVpAfeJL(UJeuWoLKP7ZI15O4ypTVs8caj)
		ZZrjMgRGiY2IDN7q = 'live'
		if '.mkv' in t6GiBhlvwIjD0RY or 'VOD' in kVGU1uhays3EWfH: ZZrjMgRGiY2IDN7q = 'video'
		ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,715,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	del ffgipIRaySJeEPmQ
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,719,qleCEa50kOYvVNSJuDP1R4FdhtoIxw+SjFdfrleWyqA9QIB,JmMO69oYEwIj+'_NODIALOGS_')
	return
def mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,fbmZ9V58PCTz):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	if UwrnXuFkvEh9xRs5Z1!='1': ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'صفحة '+str(1),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(1),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	if not LbeM6usxzdNjYTXJ7iOoKEDgAkHf: LbeM6usxzdNjYTXJ7iOoKEDgAkHf = 0
	J7JD2UFyElmsMQdwIZc0rP = int(LbeM6usxzdNjYTXJ7iOoKEDgAkHf/100)+1
	for LL4W9eHQmsxZ in range(2,J7JD2UFyElmsMQdwIZc0rP):
		S3NTGxMIWYUHb68Ojy = (LL4W9eHQmsxZ%10==0 or int(UwrnXuFkvEh9xRs5Z1)-4<LL4W9eHQmsxZ<int(UwrnXuFkvEh9xRs5Z1)+4)
		JDhbLFOd9xEkpWjzcsC = (S3NTGxMIWYUHb68Ojy and int(UwrnXuFkvEh9xRs5Z1)-40<LL4W9eHQmsxZ<int(UwrnXuFkvEh9xRs5Z1)+40)
		if str(LL4W9eHQmsxZ)!=UwrnXuFkvEh9xRs5Z1 and (LL4W9eHQmsxZ%100==0 or JDhbLFOd9xEkpWjzcsC):
			ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'صفحة '+str(LL4W9eHQmsxZ),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(LL4W9eHQmsxZ),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	if str(J7JD2UFyElmsMQdwIZc0rP)!=UwrnXuFkvEh9xRs5Z1: ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أخر صفحة '+str(J7JD2UFyElmsMQdwIZc0rP),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(J7JD2UFyElmsMQdwIZc0rP),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	return
def VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH):
	WXZRrenmT8v = LLIhz0iVEgQeN.replace('___','_'+Z27widCyESA)
	return WXZRrenmT8v
def ptHWugwnXD9yc1QhKb(Z27widCyESA):
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,gby0BnUuTNFk)
	BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return False
	TowZRG0DMgvCQzb2qlcNI(Z27widCyESA,False)
	YVr6oXZ29S4IFsKqRHAUwbWEPiy8J = [0]
	for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
		Ugkved5DSE8ZpLVrA4GXoRN = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.url_'+Z27widCyESA+'_'+str(K25l1aSLE9OU7dikIj6r0HT))
		if Ugkved5DSE8ZpLVrA4GXoRN: uj7O46p1qPsiHlyTKRtwe8N2(Z27widCyESA,str(K25l1aSLE9OU7dikIj6r0HT))
		YVr6oXZ29S4IFsKqRHAUwbWEPiy8J.append(0)
	for kVGU1uhays3EWfH in JVs3roSjn5u:
		OlC6kr5nWP,DLrbMygXNisxo5KqHEdG42j,XD5Zzhj2HwK3648BW0RJo1FlnTCt,VFRJcI6xvNyfht4YiguQA1O,lS861QGjDwFJHqcC = 0,{},[],[],[]
		for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
			dsMGf6S2kKcFOBHAuhjq83EoY = kVGU1uhays3EWfH+'_'+str(K25l1aSLE9OU7dikIj6r0HT)
			zjtcCHiX5rJ9TkVW = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'dict',dsMGf6S2kKcFOBHAuhjq83EoY)
			try:
				zCvKou38wsbOAFMxYLJ4iRV = zjtcCHiX5rJ9TkVW['__GROUPS__']
				aGmyTsKY0IECMSN = zjtcCHiX5rJ9TkVW['__COUNT__']
			except: zCvKou38wsbOAFMxYLJ4iRV,aGmyTsKY0IECMSN = [],'0'
			for FI8wnWS42uOhebLZqYJ in zCvKou38wsbOAFMxYLJ4iRV:
				r9rIzYVD0ceyC1uUofpPJF45tWbR,bxTDyYw3SV82Pt = FI8wnWS42uOhebLZqYJ
				T7hyMuvVz9EqkOasZDSJ = zjtcCHiX5rJ9TkVW[r9rIzYVD0ceyC1uUofpPJF45tWbR]
				if r9rIzYVD0ceyC1uUofpPJF45tWbR not in VFRJcI6xvNyfht4YiguQA1O:
					VFRJcI6xvNyfht4YiguQA1O.append(r9rIzYVD0ceyC1uUofpPJF45tWbR)
					lS861QGjDwFJHqcC.append(FI8wnWS42uOhebLZqYJ)
					DLrbMygXNisxo5KqHEdG42j[r9rIzYVD0ceyC1uUofpPJF45tWbR] = []
				DLrbMygXNisxo5KqHEdG42j[r9rIzYVD0ceyC1uUofpPJF45tWbR] += T7hyMuvVz9EqkOasZDSJ
			dNqGfAEk0iXLwFU(WXZRrenmT8v,dsMGf6S2kKcFOBHAuhjq83EoY)
			CExrgJh48PYI2(WXZRrenmT8v,dsMGf6S2kKcFOBHAuhjq83EoY,'__COUNT__',aGmyTsKY0IECMSN,Z83rChqtg1oXUjI4YL)
			YVr6oXZ29S4IFsKqRHAUwbWEPiy8J[K25l1aSLE9OU7dikIj6r0HT] += int(aGmyTsKY0IECMSN)
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in VFRJcI6xvNyfht4YiguQA1O:
			T7hyMuvVz9EqkOasZDSJ = list(set(DLrbMygXNisxo5KqHEdG42j[r9rIzYVD0ceyC1uUofpPJF45tWbR]))
			if 'SORTED' in kVGU1uhays3EWfH: T7hyMuvVz9EqkOasZDSJ = sorted(T7hyMuvVz9EqkOasZDSJ,reverse=False,key=lambda key: key[1].lower())
			OlC6kr5nWP += len(T7hyMuvVz9EqkOasZDSJ)
			XD5Zzhj2HwK3648BW0RJo1FlnTCt.append(T7hyMuvVz9EqkOasZDSJ)
		CExrgJh48PYI2(WXZRrenmT8v,kVGU1uhays3EWfH,'__COUNT__',str(OlC6kr5nWP),Z83rChqtg1oXUjI4YL)
		CExrgJh48PYI2(WXZRrenmT8v,kVGU1uhays3EWfH,'__GROUPS__',lS861QGjDwFJHqcC,Z83rChqtg1oXUjI4YL)
		CExrgJh48PYI2(WXZRrenmT8v,kVGU1uhays3EWfH,VFRJcI6xvNyfht4YiguQA1O,XD5Zzhj2HwK3648BW0RJo1FlnTCt,Z83rChqtg1oXUjI4YL,True)
	Qf4K7b5q2JrCGYAe10tghx = False
	for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
		if int(YVr6oXZ29S4IFsKqRHAUwbWEPiy8J[K25l1aSLE9OU7dikIj6r0HT])>0:
			Ugkved5DSE8ZpLVrA4GXoRN = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.m3u.url_'+Z27widCyESA+'_'+str(K25l1aSLE9OU7dikIj6r0HT))
			CExrgJh48PYI2(WXZRrenmT8v,'LINK_'+str(K25l1aSLE9OU7dikIj6r0HT),'__LINK__',Ugkved5DSE8ZpLVrA4GXoRN,Z83rChqtg1oXUjI4YL)
			Qf4K7b5q2JrCGYAe10tghx = True
	CExrgJh48PYI2(WXZRrenmT8v,'DUMMY','__DUMMY__','DUMMY',Z83rChqtg1oXUjI4YL)
	if not Qf4K7b5q2JrCGYAe10tghx:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم جلب ملفات M3U جديدة')
	HwC0V7B8x2ZnSM6tp1FN4XPR(Z27widCyESA)
	Cjio8VzFbEgRfTNH3UrDJMZ(False)
	nR4jOE8geFDJhKIuisTc2ZPa(False)
	return True
def HwC0V7B8x2ZnSM6tp1FN4XPR(Z27widCyESA):
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,gby0BnUuTNFk)
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,True): return
	for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
		Ugkved5DSE8ZpLVrA4GXoRN = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'str','LINK_'+str(K25l1aSLE9OU7dikIj6r0HT),'__LINK__')
		if Ugkved5DSE8ZpLVrA4GXoRN: XgSmd7DqBQhbcKj3GaZW = U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA,str(K25l1aSLE9OU7dikIj6r0HT))
	U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA,gby0BnUuTNFk)
	return
def TowZRG0DMgvCQzb2qlcNI(Z27widCyESA,N9bXKIfsDVPjctLM5u):
	if N9bXKIfsDVPjctLM5u:
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,gby0BnUuTNFk)
	try: bCoOHfPdMryRgauz0IVpth.remove(WXZRrenmT8v)
	except: pass
	for K25l1aSLE9OU7dikIj6r0HT in range(1,aaExwv5sSWFXk+1):
		Vmt1upxAblHXSw = dxb4sYrRAG.replace('___','_'+Z27widCyESA+'_'+str(K25l1aSLE9OU7dikIj6r0HT))
		R7jxUogPatXI = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,Vmt1upxAblHXSw)
		try: bCoOHfPdMryRgauz0IVpth.remove(R7jxUogPatXI)
		except: pass
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_M3U','SECTIONS_M3U_'+Z27widCyESA)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if N9bXKIfsDVPjctLM5u:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح جميع ملفات ـM3U')
		nR4jOE8geFDJhKIuisTc2ZPa(False)
	return
def N3NqxCYlUkuSAGb4meh(Z27widCyESA):
	LjRQAE38xSeub = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.language.provider')
	JugE9FAshRvzo4lXYPfiCZqSjpeIH = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.language.code')
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'MENUS_CACHE_'+LjRQAE38xSeub+'_'+JugE9FAshRvzo4lXYPfiCZqSjpeIH,'%_MU'+Z27widCyESA+'_%')
	return
IYwtLqv1WJH0Au78EjZRrgxaiP94eC = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}