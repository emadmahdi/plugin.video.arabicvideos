# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from V4OX6PRG0U import *
CC3nOPFMovd72u = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ௻")
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,UJeuWoLKP7ZI15O4ypTVs8caj):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠶࠷࠵ಉ"): WjryKiBebavP = pR6M0EIL3JZBVF4q2ObntzyrP()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠷࠸࠷ಊ"): WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(UJeuWoLKP7ZI15O4ypTVs8caj)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠸࠹࠲ಋ"): WjryKiBebavP = LLynEZr2VlRKf84aPdSB16WiOTho()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠹࠳࠴ಌ"): WjryKiBebavP = MOdIUgPxZfm()
	else: WjryKiBebavP = yrcbRSFswvAfEdIWVj
	return WjryKiBebavP
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(UJeuWoLKP7ZI15O4ypTVs8caj):
	YAQOL1eVvqMjsEfIFc(UJeuWoLKP7ZI15O4ypTVs8caj,CC3nOPFMovd72u,q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ௼"))
	return
def MOdIUgPxZfm():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = n6JjFHfmydIaLut(u"ࠪวีํศࠡว็ํࠥืวษูࠣห้็๊ะ์๋ࠤศ๎ࠠศๆุ์ฯࠦแ๋ࠢส่๊๎โฺࠢส่๊฽ไ้สࠣฯ๊ࠦรื฼ฺࠤ฾๊้ࠡิิࠤฬ๊โศศ่อࠥอไ๋็ํ๊ࠥัๅࠡลัฮฬืࠠࠣฬะ้๏๊ࠠๆๆไหฯࠦแ๋ัํ์ࠧࠦหๆࠢสาฯอัࠡัๅอࠥอไึ๊ิอࠥ๎วฯฬสีࠥ์ฺ่่่ࠢๆࠦวๅื๋ีฮ่ࠦษ฻า๋ฬࠦำ้ใࠣ๎อีรࠡษ็ฮา๋๊ๅࠩ௽")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,iI7tuF0nEQoR(u"ࠫ฼ื๊ใหࠣฮา๋๊ๅࠢส่๊๊แศฬࠪ௾"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def pR6M0EIL3JZBVF4q2ObntzyrP():
	ygWIQGf25qwVxLkXrYDjp(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬࡲࡩ࡯࡭ࠪ௿"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ืา์ๅอࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫఀ"),gby0BnUuTNFk,NupI74tJCzYXmles9SbR6(u"࠳࠴࠵಍"))
	ygWIQGf25qwVxLkXrYDjp(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧ࡭࡫ࡱ࡯ࠬఁ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨం"),gby0BnUuTNFk,YZXtBgvUPoM5sb(u"࠴࠵࠵ಎ"))
	ygWIQGf25qwVxLkXrYDjp(ne7wF4gSTRZo(u"ࠩ࡯࡭ࡳࡱࠧః"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩఄ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,ggtuNcvTn3HQ7SpE2(u"࠻࠼࠽࠾ಏ"))
	t2iv6w3El1nBaMsfuWbFJ4DyoSxqr = azfWdVUxrtjRTuGhqZDNE()
	xwON7bUifdX36IuTQvcjA = bCoOHfPdMryRgauz0IVpth.stat(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr).st_mtime
	k3Vt7bYx64IXQRDKp1vMqJOUBL8 = []
	if nqkybtoMBH: zFtuBdqvP8AC = bCoOHfPdMryRgauz0IVpth.listdir(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr.encode(JJQFjSIlALchiMzG9))
	else: zFtuBdqvP8AC = bCoOHfPdMryRgauz0IVpth.listdir(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr.decode(JJQFjSIlALchiMzG9))
	for Vmt1upxAblHXSw in zFtuBdqvP8AC:
		if nqkybtoMBH: Vmt1upxAblHXSw = Vmt1upxAblHXSw.decode(JJQFjSIlALchiMzG9)
		if not Vmt1upxAblHXSw.startswith(iI7tuF0nEQoR(u"ࠫ࡫࡯࡬ࡦࡡࠪఅ")): continue
		ibgSLAhPNOmKG9T467FRD = bCoOHfPdMryRgauz0IVpth.path.join(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr,Vmt1upxAblHXSw)
		xwON7bUifdX36IuTQvcjA = bCoOHfPdMryRgauz0IVpth.path.getmtime(ibgSLAhPNOmKG9T467FRD)
		k3Vt7bYx64IXQRDKp1vMqJOUBL8.append([Vmt1upxAblHXSw,xwON7bUifdX36IuTQvcjA])
	k3Vt7bYx64IXQRDKp1vMqJOUBL8 = sorted(k3Vt7bYx64IXQRDKp1vMqJOUBL8,reverse=w8Ui6RsVhSPrqHfO4,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6])
	for Vmt1upxAblHXSw,xwON7bUifdX36IuTQvcjA in k3Vt7bYx64IXQRDKp1vMqJOUBL8:
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			try: Vmt1upxAblHXSw = Vmt1upxAblHXSw.decode(JJQFjSIlALchiMzG9)
			except: pass
			Vmt1upxAblHXSw = Vmt1upxAblHXSw.encode(JJQFjSIlALchiMzG9)
		ibgSLAhPNOmKG9T467FRD = bCoOHfPdMryRgauz0IVpth.path.join(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr,Vmt1upxAblHXSw)
		ygWIQGf25qwVxLkXrYDjp(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡼࡩࡥࡧࡲࠫఆ"),Vmt1upxAblHXSw,ibgSLAhPNOmKG9T467FRD,Ducd5PRjQXaB9SIN7VrJ1G(u"࠶࠷࠶ಐ"))
	return
def azfWdVUxrtjRTuGhqZDNE():
	t2iv6w3El1nBaMsfuWbFJ4DyoSxqr = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(BarIC3eR9bS(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩఇ"))
	if t2iv6w3El1nBaMsfuWbFJ4DyoSxqr: return t2iv6w3El1nBaMsfuWbFJ4DyoSxqr
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪఈ"),jjzt6rqdQKM)
	return jjzt6rqdQKM
def LLynEZr2VlRKf84aPdSB16WiOTho():
	t2iv6w3El1nBaMsfuWbFJ4DyoSxqr = azfWdVUxrtjRTuGhqZDNE()
	WwsfRtInQ0mr194KZJd8ea = c3iHohf1zAFQjtTV20pPlS(zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨఉ"),gby0BnUuTNFk,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"่ࠩ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไหฯ่๎้࠭ఊ"),bKN9diGf8nmgecQPEqUzHRpoDuaO+t2iv6w3El1nBaMsfuWbFJ4DyoSxqr+GGy0cQe765nPYZ9E8Th+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡠࡳࡢ࡮่าสࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣฮ฿๐๊าࠢส่๊้ว็ࠢยࠫఋ"))
	if WwsfRtInQ0mr194KZJd8ea==MlTVLBZ92kzorIq1Yw(u"࠵಑"):
		EEn84Bkzib = ongxYVNfem(OUFxZPuXDoGAbRz(u"࠸ಒ"),RRbvqditj184m3(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨఌ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠬࡲ࡯ࡤࡣ࡯ࠫ఍"),gby0BnUuTNFk,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4,t2iv6w3El1nBaMsfuWbFJ4DyoSxqr)
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(TeYukOUW7i5NBM926DCjaAn0(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ఎ"),gby0BnUuTNFk,gby0BnUuTNFk,n6JjFHfmydIaLut(u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫఏ"),bKN9diGf8nmgecQPEqUzHRpoDuaO+t2iv6w3El1nBaMsfuWbFJ4DyoSxqr+GGy0cQe765nPYZ9E8Th+mmbcsf2pd7gyjzreB(u"ࠨ࡞ࡱࡠࡳํะศ๊ࠢ์ࠥอไๆๅส๊ࠥอไอัํำ๊ࠥสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฬูสฯัส้์ࠦศะๆสࠤ๊์ࠠศๆ่็ฬ์ࠠศๆๅำ๏๋ࠠภࠩఐ"))
		if PpQu9EkGTxa==YZXtBgvUPoM5sb(u"࠷ಓ"):
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(IXE6voNmrb182AyQ(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬ఑"),EEn84Bkzib)
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫఒ"))
	return
def CCEelJIdxm(UJeuWoLKP7ZI15O4ypTVs8caj,QZ4YSx75ltrFXDCgA0iGKcqeR=gby0BnUuTNFk,website=gby0BnUuTNFk):
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+nJF7oflOk6cLGSAey(u"ࠫࠥࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫఓ")+UJeuWoLKP7ZI15O4ypTVs8caj+MlTVLBZ92kzorIq1Yw(u"ࠬࠦ࡝ࠨఔ"))
	if not QZ4YSx75ltrFXDCgA0iGKcqeR: QZ4YSx75ltrFXDCgA0iGKcqeR = ymlrSBXjxRaY5kcKtU7MTVpAfeJL(UJeuWoLKP7ZI15O4ypTVs8caj)
	t2iv6w3El1nBaMsfuWbFJ4DyoSxqr = azfWdVUxrtjRTuGhqZDNE()
	UJgI4DY2r9oT5c = RQxlZpTwMkW0F8fSIObUt5oDy7c(yrcbRSFswvAfEdIWVj)
	Vmt1upxAblHXSw = UJgI4DY2r9oT5c.replace(UpN1CezytPO9XoduhxZSD,iiauUxMktNW5X(u"࠭࡟ࠨక"))
	Vmt1upxAblHXSw = AAkN5aCpwrvOPhUYg9(Vmt1upxAblHXSw)
	Vmt1upxAblHXSw = RRbvqditj184m3(u"ࠧࡧ࡫࡯ࡩࡤ࠭ఖ")+str(int(X1X59MWmb8oBPDFCJARwcjONihTdeZ))[-Ducd5PRjQXaB9SIN7VrJ1G(u"࠴ಔ"):]+FAwWlRJg0UkN1(u"ࠨࡡࠪగ")+Vmt1upxAblHXSw+QZ4YSx75ltrFXDCgA0iGKcqeR
	WyfNK5ogAQMdSE0nVbRxJI3q = bCoOHfPdMryRgauz0IVpth.path.join(t2iv6w3El1nBaMsfuWbFJ4DyoSxqr,Vmt1upxAblHXSw)
	vO65KkJHupCrocdLe = {}
	vO65KkJHupCrocdLe[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫఘ")] = gby0BnUuTNFk
	vO65KkJHupCrocdLe[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡅࡨࡩࡥࡱࡶࠪఙ")] = q2qPkMFpR1G86dEAKXHivor9N(u"ࠫ࠯࠵ࠪࠨచ")
	UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨఛ"),gby0BnUuTNFk)
	if uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫజ") in UJeuWoLKP7ZI15O4ypTVs8caj:
		Tf5ueYGZIFl1hraoEOVKi,E9LlzOuYdp20rKcn13BUqDGsh8StIQ = UJeuWoLKP7ZI15O4ypTVs8caj.rsplit(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬఝ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠲ಕ"))
		E9LlzOuYdp20rKcn13BUqDGsh8StIQ = E9LlzOuYdp20rKcn13BUqDGsh8StIQ.replace(YZXtBgvUPoM5sb(u"ࠨࡾࠪఞ"),gby0BnUuTNFk).replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࠩࠫట"),gby0BnUuTNFk)
	else: Tf5ueYGZIFl1hraoEOVKi,E9LlzOuYdp20rKcn13BUqDGsh8StIQ = UJeuWoLKP7ZI15O4ypTVs8caj,None
	if not E9LlzOuYdp20rKcn13BUqDGsh8StIQ: E9LlzOuYdp20rKcn13BUqDGsh8StIQ = Zc6lYG3a02XVPA1WLr()
	if E9LlzOuYdp20rKcn13BUqDGsh8StIQ: vO65KkJHupCrocdLe[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧఠ")] = E9LlzOuYdp20rKcn13BUqDGsh8StIQ
	if NupI74tJCzYXmles9SbR6(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭డ") in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi,vz5laUNHCeWuwr81 = Tf5ueYGZIFl1hraoEOVKi.rsplit(ggtuNcvTn3HQ7SpE2(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧఢ"),iI7tuF0nEQoR(u"࠳ಖ"))
	else: Tf5ueYGZIFl1hraoEOVKi,vz5laUNHCeWuwr81 = Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk
	Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi.strip(BarIC3eR9bS(u"࠭ࡼࠨణ")).strip(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࠧࠩత")).strip(FAwWlRJg0UkN1(u"ࠨࡾࠪథ")).strip(VzO1gCHmjZ2ebRIL(u"ࠩࠩࠫద"))
	vz5laUNHCeWuwr81 = vz5laUNHCeWuwr81.replace(VzO1gCHmjZ2ebRIL(u"ࠪࢀࠬధ"),gby0BnUuTNFk).replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠫࠫ࠭న"),gby0BnUuTNFk)
	if vz5laUNHCeWuwr81:	vO65KkJHupCrocdLe[KJLkQsqSHMR1Np2(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭఩")] = vz5laUNHCeWuwr81
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧప")+Tf5ueYGZIFl1hraoEOVKi+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪఫ")+str(vO65KkJHupCrocdLe)+FAwWlRJg0UkN1(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨబ")+WyfNK5ogAQMdSE0nVbRxJI3q+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩࠣࡡࠬభ"))
	XfoEk6pQmbLA = MlTVLBZ92kzorIq1Yw(u"࠴࠴࠷࠺ಗ")*MlTVLBZ92kzorIq1Yw(u"࠴࠴࠷࠺ಗ")
	YnFZhcd1G2tbom9HCpzTJ8irQwegSW = UcWYT0gz7mALe()//XfoEk6pQmbLA
	if not YnFZhcd1G2tbom9HCpzTJ8irQwegSW:
		sbqP27kMUtTxS0dyYO(BarIC3eR9bS(u"ࠪࡶ࡮࡭ࡨࡵࠩమ"),BarIC3eR9bS(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫయ"),FAwWlRJg0UkN1(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩర"),TeYukOUW7i5NBM926DCjaAn0(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩఱ"))
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࡙ࠧࠡࠢࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡷ࡬ࡪࠦࡤࡪࡵ࡮ࠤ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨల"))
		return yrcbRSFswvAfEdIWVj
	if QZ4YSx75ltrFXDCgA0iGKcqeR==sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧళ"):
		uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R = IYTJXVfryDt42MvaRNKLC(CC3nOPFMovd72u,Tf5ueYGZIFl1hraoEOVKi,vO65KkJHupCrocdLe)
		if len(uufJivSZQyj45ql3)==q2qPkMFpR1G86dEAKXHivor9N(u"࠴ಘ"):
			RLfOB3nsqaWXTugJvY(iiLyoNwGbH03DIXhAkZn(u"ࠩไุ้ࠦแ๋ࠢศ๎ัอฯࠡ็็ๅࠥอไหฯ่๎้࠭ఴ"),gby0BnUuTNFk)
			return yrcbRSFswvAfEdIWVj
		elif len(uufJivSZQyj45ql3)==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠶ಙ"): EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = Ducd5PRjQXaB9SIN7VrJ1G(u"࠶ಚ")
		elif len(uufJivSZQyj45ql3)>lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠱ಛ"):
			EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3(BarIC3eR9bS(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨవ"), uufJivSZQyj45ql3)
			if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -Ducd5PRjQXaB9SIN7VrJ1G(u"࠲ಜ") :
				RLfOB3nsqaWXTugJvY(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬะ้๏๊ࠧశ"),gby0BnUuTNFk)
				return yrcbRSFswvAfEdIWVj
		Tf5ueYGZIFl1hraoEOVKi = eE9BXgNu4MPKIbw2aLDl1AY3R[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz = n6JjFHfmydIaLut(u"࠲ಝ")
	import requests as NGcESCFxok0
	if QZ4YSx75ltrFXDCgA0iGKcqeR==IXE6voNmrb182AyQ(u"ࠬ࠴࡭࠴ࡷ࠻ࠫష"):
		WyfNK5ogAQMdSE0nVbRxJI3q = WyfNK5ogAQMdSE0nVbRxJI3q.rsplit(mmbcsf2pd7gyjzreB(u"࠭࠮࡮࠵ࡸ࠼ࠬస"))[xn867tCVlscY4qbWZfh]+i80mE7lHUwVk(u"ࠧ࠯࡯ࡳ࠸ࠬహ")
		WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡉࡈࡘࠬ఺"),Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ࠱ࡉࡕࡗࡏࡎࡒࡅࡉࡥࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ఻"))
		TLdSfhMKk4sm = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(n6JjFHfmydIaLut(u"ࠪࠧࡊ࡞ࡔࡊࡐࡉ࠾࠳࠰࠿࡜࡞ࡱࡠࡷࡣࠨ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠ఼ࠫ"),TLdSfhMKk4sm+mmbcsf2pd7gyjzreB(u"ࠫࡡࡴ࡜ࡳࠩఽ"),ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not vx14CNdbsZTz:
			SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+ne7wF4gSTRZo(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨా")+Tf5ueYGZIFl1hraoEOVKi+KJLkQsqSHMR1Np2(u"࠭ࠠ࡞ࠩి"))
			return yrcbRSFswvAfEdIWVj
		SSqweDUBYv4bkO = vx14CNdbsZTz[xn867tCVlscY4qbWZfh]
		if not SSqweDUBYv4bkO.startswith(TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡩࡶࡷࡴࠬీ")):
			if SSqweDUBYv4bkO.startswith(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨ࠱࠲ࠫు")): SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi.split(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࠽ࠫూ"),ggtuNcvTn3HQ7SpE2(u"࠴ಞ"))[xn867tCVlscY4qbWZfh]+ne7wF4gSTRZo(u"ࠪ࠾ࠬృ")+SSqweDUBYv4bkO
			elif SSqweDUBYv4bkO.startswith(q2qPkMFpR1G86dEAKXHivor9N(u"ࠫ࠴࠭ౄ")): SSqweDUBYv4bkO = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Tf5ueYGZIFl1hraoEOVKi,n6JjFHfmydIaLut(u"ࠬࡻࡲ࡭ࠩ౅"))+SSqweDUBYv4bkO
			else: SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi.rsplit(NupI74tJCzYXmles9SbR6(u"࠭࠯ࠨె"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠵ಟ"))[xn867tCVlscY4qbWZfh]+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧ࠰ࠩే")+SSqweDUBYv4bkO
		WeCU3qEsGrDNfh1tmXHVOZgPalK = NGcESCFxok0.request(BarIC3eR9bS(u"ࠨࡉࡈࡘࠬై"),SSqweDUBYv4bkO,headers=vO65KkJHupCrocdLe,verify=yrcbRSFswvAfEdIWVj)
		Kt2HNL6opfRBeniQIJwlhgqDAYzTy = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
		ooBOthibjqwZJv2ysMIluPeQdF1f = len(Kt2HNL6opfRBeniQIJwlhgqDAYzTy)
		fV2wJh8mB5d = len(vx14CNdbsZTz)
		HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz = ooBOthibjqwZJv2ysMIluPeQdF1f*fV2wJh8mB5d
	else:
		ooBOthibjqwZJv2ysMIluPeQdF1f = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠶ಠ")*XfoEk6pQmbLA
		WeCU3qEsGrDNfh1tmXHVOZgPalK = NGcESCFxok0.request(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࡊࡉ࡙࠭౉"),Tf5ueYGZIFl1hraoEOVKi,headers=vO65KkJHupCrocdLe,verify=yrcbRSFswvAfEdIWVj,stream=w8Ui6RsVhSPrqHfO4)
		if ne7wF4gSTRZo(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫొ") in WeCU3qEsGrDNfh1tmXHVOZgPalK.headers: HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz = int(WeCU3qEsGrDNfh1tmXHVOZgPalK.headers[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬో")])
		fV2wJh8mB5d = int(HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz//ooBOthibjqwZJv2ysMIluPeQdF1f)
	iQV7sZJfuqLpjme6F93POrIRz = int(HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz//XfoEk6pQmbLA)+DWgX6JfF3SnlsQwtN1cvGk8L(u"࠷ಡ")
	if HHR0Ay9jEC6Beokwh4N7L1WTXYPZGz<OUFxZPuXDoGAbRz(u"࠲࠲࠲࠳࠴ಢ"):
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+ne7wF4gSTRZo(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡶࡲࡳࠥࡹ࡭ࡢ࡮࡯ࠤࡴࡸࠠࡪࡶࠣ࡭ࡸࠦ࡭࠴ࡷ࠻ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧౌ")+Tf5ueYGZIFl1hraoEOVKi+i80mE7lHUwVk(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜్ࠢࠪ")+str(iQV7sZJfuqLpjme6F93POrIRz)+MlTVLBZ92kzorIq1Yw(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭౎")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+iiauUxMktNW5X(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ౏")+WyfNK5ogAQMdSE0nVbRxJI3q+NupI74tJCzYXmles9SbR6(u"ࠩࠣࡡࠬ౐"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬ౑"))
		return yrcbRSFswvAfEdIWVj
	c1omTBPZVsbDWCSkz4Khdx8FHJQ = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠵࠲࠳ಣ")
	M2jWxbm0hArg9BVdLpGQoE = YnFZhcd1G2tbom9HCpzTJ8irQwegSW-iQV7sZJfuqLpjme6F93POrIRz
	if M2jWxbm0hArg9BVdLpGQoE<c1omTBPZVsbDWCSkz4Khdx8FHJQ:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+iiLyoNwGbH03DIXhAkZn(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ౒")+Tf5ueYGZIFl1hraoEOVKi+NupI74tJCzYXmles9SbR6(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ౓")+str(iQV7sZJfuqLpjme6F93POrIRz)+YZXtBgvUPoM5sb(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ౔")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+zDSw8LCxMQyraeXhojIWKmU(u"ࠧࠡࡏࡅࠤ࠲ౕࠦࠧ")+str(c1omTBPZVsbDWCSkz4Khdx8FHJQ)+iI7tuF0nEQoR(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ౖࠣࠫ")+WyfNK5ogAQMdSE0nVbRxJI3q+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࠣࡡࠬ౗"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪౘ"),mmbcsf2pd7gyjzreB(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪౙ")+str(iQV7sZJfuqLpjme6F93POrIRz)+RRbvqditj184m3(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫౚ")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+TeYukOUW7i5NBM926DCjaAn0(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭౛")+str(c1omTBPZVsbDWCSkz4Khdx8FHJQ)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩ౜"))
		return yrcbRSFswvAfEdIWVj
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(BarIC3eR9bS(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨౝ"),gby0BnUuTNFk,gby0BnUuTNFk,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪ౞"),KJLkQsqSHMR1Np2(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩ౟")+str(iQV7sZJfuqLpjme6F93POrIRz)+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪౠ")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+n6JjFHfmydIaLut(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨౡ"))
	if PpQu9EkGTxa!=ggtuNcvTn3HQ7SpE2(u"࠳ತ"):
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫౢ"))
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+DWgX6JfF3SnlsQwtN1cvGk8L(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩౣ")+Tf5ueYGZIFl1hraoEOVKi+KJLkQsqSHMR1Np2(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ౤")+WyfNK5ogAQMdSE0nVbRxJI3q+iiLyoNwGbH03DIXhAkZn(u"ࠩࠣࡡࠬ౥"))
		return yrcbRSFswvAfEdIWVj
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+nJF7oflOk6cLGSAey(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨ౦"))
	XAbSTLwjmJDs8WgraYFn = gX5UxB8Sce7tuvjkNaoIAHDq4()
	XAbSTLwjmJDs8WgraYFn.create(WyfNK5ogAQMdSE0nVbRxJI3q,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬ౧"))
	Yx2ahobNmPZ5I76OLR89kvCr = w8Ui6RsVhSPrqHfO4
	LjWyqBVS3gE = RyfYSek61do5OnQMc.time()
	if not wAcHkmPB8a.NiXZIL0GzwCV:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,zDSw8LCxMQyraeXhojIWKmU(u"ࠬฮำษสࠣ฽ิ๋ࠠศๆอฬึ฿ࠠห็ࠣษ้เวยࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭౨"))
		return yrcbRSFswvAfEdIWVj
	if nqkybtoMBH: oP4hs5zHkY2 = open(WyfNK5ogAQMdSE0nVbRxJI3q,uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡷࡣࠩ౩"))
	else: oP4hs5zHkY2 = open(WyfNK5ogAQMdSE0nVbRxJI3q.decode(JJQFjSIlALchiMzG9),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡸࡤࠪ౪"))
	if QZ4YSx75ltrFXDCgA0iGKcqeR==nJF7oflOk6cLGSAey(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ౫"):
		for t3t986iTduqY in range(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠴ಥ"),fV2wJh8mB5d+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠴ಥ")):
			SSqweDUBYv4bkO = vx14CNdbsZTz[t3t986iTduqY-VzO1gCHmjZ2ebRIL(u"࠵ದ")]
			if not SSqweDUBYv4bkO.startswith(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩ࡫ࡸࡹࡶࠧ౬")):
				if SSqweDUBYv4bkO.startswith(KJLkQsqSHMR1Np2(u"ࠪ࠳࠴࠭౭")): SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi.split(i80mE7lHUwVk(u"ࠫ࠿࠭౮"),DWgX6JfF3SnlsQwtN1cvGk8L(u"࠶ಧ"))[xn867tCVlscY4qbWZfh]+zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡀࠧ౯")+SSqweDUBYv4bkO
				elif SSqweDUBYv4bkO.startswith(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭࠯ࠨ౰")): SSqweDUBYv4bkO = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Tf5ueYGZIFl1hraoEOVKi,RRbvqditj184m3(u"ࠧࡶࡴ࡯ࠫ౱"))+SSqweDUBYv4bkO
				else: SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi.rsplit(i80mE7lHUwVk(u"ࠨ࠱ࠪ౲"),BarIC3eR9bS(u"࠷ನ"))[xn867tCVlscY4qbWZfh]+iiLyoNwGbH03DIXhAkZn(u"ࠩ࠲ࠫ౳")+SSqweDUBYv4bkO
			WeCU3qEsGrDNfh1tmXHVOZgPalK = NGcESCFxok0.request(zDSw8LCxMQyraeXhojIWKmU(u"ࠪࡋࡊ࡚ࠧ౴"),SSqweDUBYv4bkO,headers=vO65KkJHupCrocdLe,verify=yrcbRSFswvAfEdIWVj)
			Kt2HNL6opfRBeniQIJwlhgqDAYzTy = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
			WeCU3qEsGrDNfh1tmXHVOZgPalK.close()
			oP4hs5zHkY2.write(Kt2HNL6opfRBeniQIJwlhgqDAYzTy)
			xxqCHUsB5QXtKcYif6Tw = RyfYSek61do5OnQMc.time()
			v4CqmKbrwOtex1SVpZXEMGB = xxqCHUsB5QXtKcYif6Tw-LjWyqBVS3gE
			fJmBSZaxA3Rqu = v4CqmKbrwOtex1SVpZXEMGB//t3t986iTduqY
			K4L2ixDVEPRlOrkMn = fJmBSZaxA3Rqu*(fV2wJh8mB5d+q2qPkMFpR1G86dEAKXHivor9N(u"࠱಩"))
			GXYZKhB5HRcCpagW9z = K4L2ixDVEPRlOrkMn-v4CqmKbrwOtex1SVpZXEMGB
			OCdLHyt7V58QGMokw(XAbSTLwjmJDs8WgraYFn,int(VzO1gCHmjZ2ebRIL(u"࠳࠳࠴ಫ")*t3t986iTduqY//(fV2wJh8mB5d+iiLyoNwGbH03DIXhAkZn(u"࠲ಪ"))),mmbcsf2pd7gyjzreB(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬ౵"),FAwWlRJg0UkN1(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ౶"),str(t3t986iTduqY*ooBOthibjqwZJv2ysMIluPeQdF1f//XfoEk6pQmbLA)+MlTVLBZ92kzorIq1Yw(u"࠭࠯ࠨ౷")+str(iQV7sZJfuqLpjme6F93POrIRz)+OUFxZPuXDoGAbRz(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ౸")+RyfYSek61do5OnQMc.strftime(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ౹"),RyfYSek61do5OnQMc.gmtime(GXYZKhB5HRcCpagW9z))+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࠣไࠬ౺"))
			if XAbSTLwjmJDs8WgraYFn.iscanceled():
				Yx2ahobNmPZ5I76OLR89kvCr = yrcbRSFswvAfEdIWVj
				break
	else:
		t3t986iTduqY = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠳ಬ")
		for Kt2HNL6opfRBeniQIJwlhgqDAYzTy in WeCU3qEsGrDNfh1tmXHVOZgPalK.iter_content(chunk_size=ooBOthibjqwZJv2ysMIluPeQdF1f):
			oP4hs5zHkY2.write(Kt2HNL6opfRBeniQIJwlhgqDAYzTy)
			t3t986iTduqY = t3t986iTduqY+kreQUwJis7YmC2yqWtIF09pgjbD(u"࠵ಭ")
			xxqCHUsB5QXtKcYif6Tw = RyfYSek61do5OnQMc.time()
			v4CqmKbrwOtex1SVpZXEMGB = xxqCHUsB5QXtKcYif6Tw-LjWyqBVS3gE
			fJmBSZaxA3Rqu = v4CqmKbrwOtex1SVpZXEMGB/t3t986iTduqY
			K4L2ixDVEPRlOrkMn = fJmBSZaxA3Rqu*(fV2wJh8mB5d+zDSw8LCxMQyraeXhojIWKmU(u"࠶ಮ"))
			GXYZKhB5HRcCpagW9z = K4L2ixDVEPRlOrkMn-v4CqmKbrwOtex1SVpZXEMGB
			OCdLHyt7V58QGMokw(XAbSTLwjmJDs8WgraYFn,int(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠱࠱࠲ರ")*t3t986iTduqY/(fV2wJh8mB5d+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠷ಯ"))),iiauUxMktNW5X(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ౻"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ౼"),str(t3t986iTduqY*ooBOthibjqwZJv2ysMIluPeQdF1f//XfoEk6pQmbLA)+mmbcsf2pd7gyjzreB(u"ࠬ࠵ࠧ౽")+str(iQV7sZJfuqLpjme6F93POrIRz)+q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ౾")+RyfYSek61do5OnQMc.strftime(mmbcsf2pd7gyjzreB(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ౿"),RyfYSek61do5OnQMc.gmtime(GXYZKhB5HRcCpagW9z))+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࠢใࠫಀ"))
			if XAbSTLwjmJDs8WgraYFn.iscanceled():
				Yx2ahobNmPZ5I76OLR89kvCr = yrcbRSFswvAfEdIWVj
				break
		WeCU3qEsGrDNfh1tmXHVOZgPalK.close()
	oP4hs5zHkY2.close()
	XAbSTLwjmJDs8WgraYFn.close()
	if not Yx2ahobNmPZ5I76OLR89kvCr:
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+KJLkQsqSHMR1Np2(u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠴࡯࡮ࡵࡧࡵࡶࡺࡶࡴࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡶࡴࡩࡥࡴࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ಁ")+Tf5ueYGZIFl1hraoEOVKi+BarIC3eR9bS(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪಂ")+WyfNK5ogAQMdSE0nVbRxJI3q+YZXtBgvUPoM5sb(u"ࠫࠥࡣࠧಃ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"ࠬฮอิสࠣ฻้ฮใࠡฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭಄"))
		return w8Ui6RsVhSPrqHfO4
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+q2qPkMFpR1G86dEAKXHivor9N(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬಅ")+Tf5ueYGZIFl1hraoEOVKi+zDSw8LCxMQyraeXhojIWKmU(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧಆ")+WyfNK5ogAQMdSE0nVbRxJI3q+TeYukOUW7i5NBM926DCjaAn0(u"ࠨࠢࡠࠫಇ"))
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ggtuNcvTn3HQ7SpE2(u"ࠩอ้ࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢห๊ัออࠨಈ"))
	return w8Ui6RsVhSPrqHfO4