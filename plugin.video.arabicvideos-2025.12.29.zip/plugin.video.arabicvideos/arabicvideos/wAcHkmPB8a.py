# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from GVnzsDeQ36 import *
SITESURLS = {
			 iiauUxMktNW5X(u"ࠨࡃࡋ࡛ࡆࡑࠧಱ")		:[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫಲ")]
			,iiLyoNwGbH03DIXhAkZn(u"ࠪࡅࡐࡕࡁࡎࠩಳ")		:[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨ಴")]
			,mmbcsf2pd7gyjzreB(u"ࠬࡇࡋࡘࡃࡐࠫವ")		:[n6JjFHfmydIaLut(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭ಶ")]
			,RRbvqditj184m3(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪಷ")	:[iiauUxMktNW5X(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡧ࡫ࡸࡣࡰ࠲ࡹࡻࡢࡦࠩಸ")]
			,ne7wF4gSTRZo(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫಹ")		:[MlTVLBZ92kzorIq1Yw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩ಺")]
			,OUFxZPuXDoGAbRz(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬ಻")		:[iI7tuF0nEQoR(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡱࡳࡳࡵࡤࡤ࠲ࡹࡼ಼ࠧ")]
			,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨಽ")		:[ne7wF4gSTRZo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱ࡭ࡲ࡫ࡺࡪࡦ࠱ࡷ࡭ࡵࡷࠨಾ")]
			,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ಿ")	:[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩೀ")]
			,n6JjFHfmydIaLut(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬು")		:[kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫೂ")]
			,RRbvqditj184m3(u"ࠬࡇ࡙ࡍࡑࡏࠫೃ")		:[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧ࠱ࡥࡾࡲ࡯࡭࠰ࡱࡩࡹ࠭ೄ")]
			,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡃࡑࡎࡖࡆ࠭೅")		:[FAwWlRJg0UkN1(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦ࡮ࡩࡥ࡮࡬ࡺࡪ࠴ࡣࡰࠩೆ")]
			,RRbvqditj184m3(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩೇ")		:[n6JjFHfmydIaLut(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨೈ")]
			,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ೉")		:[IXE6voNmrb182AyQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫೊ")]
			,RRbvqditj184m3(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ೋ")		:[FAwWlRJg0UkN1(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠱ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧೌ")]
			,iiLyoNwGbH03DIXhAkZn(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ್")		:[i80mE7lHUwVk(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ೎")]
			,iiauUxMktNW5X(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ೏")		:[GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡭࠯ࡥ࡬ࡱࡦ࠹ࡢࡥࡱ࠱ࡧࡴࡳࠧ೐")]
			,iiLyoNwGbH03DIXhAkZn(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೑")		:[mmbcsf2pd7gyjzreB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡧࡱࡻࡢࠨ೒")]
			,VzO1gCHmjZ2ebRIL(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭೓")	:[MlTVLBZ92kzorIq1Yw(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭೔")]
			,iI7tuF0nEQoR(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫೕ")		:[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴ࠭ೖ")]
			,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭೗")		:[uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠱ࡹࡼ࠮ࡤࡱࡰࠫ೘")]
			,VzO1gCHmjZ2ebRIL(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ೙")	:[nJF7oflOk6cLGSAey(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼ࠱ࡨ࡯࡭ࡢ࠰ࡱࡩࡹ࠭೚")]
			,RRbvqditj184m3(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ೛")		:[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧ೜")]
			,mmbcsf2pd7gyjzreB(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬೝ")		:[n6JjFHfmydIaLut(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹࡤ࡫ࡰࡥ࠳ࡩࡣࠨೞ")]
			,i80mE7lHUwVk(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೟")	:[iiLyoNwGbH03DIXhAkZn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ೠ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨೡ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡦࡸࡣࡩ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫೢ")]
			,zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬೣ")	:[iiauUxMktNW5X(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠸࠵࠯ࡦࡵࡥࡲࡧࡣࡢࡨࡨ࠱ࡹࡼ࠮ࡤࡱࡰࠫ೤")]
			,OUFxZPuXDoGAbRz(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ೥")		:[mmbcsf2pd7gyjzreB(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡳࡣࡰࡥࡸ࠽࠮࡯ࡧࡷࠫ೦")]
			,ne7wF4gSTRZo(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ೧")		:[kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡩࡹࡳ࠭೨")]
			,ne7wF4gSTRZo(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ೩")		:[n6JjFHfmydIaLut(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡳ࡫ࡷࡴࠩ೪")]
			,RRbvqditj184m3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ೫")		:[iI7tuF0nEQoR(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫ೬")]
			,BarIC3eR9bS(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ೭")		:[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭೮")]
			,NupI74tJCzYXmles9SbR6(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ೯")		:[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨ೰")]
			,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫೱ")		:[MlTVLBZ92kzorIq1Yw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪೲ")]
			,OUFxZPuXDoGAbRz(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧೳ")	:[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠴ࡥ࡭࡫ࡩ࠲ࡳ࡫ࡷࡴࠩ೴")]
			,BarIC3eR9bS(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ೵")		:[IXE6voNmrb182AyQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬ೶")]
			,IXE6voNmrb182AyQ(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ೷")	:[n6JjFHfmydIaLut(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧ೸")]
			,nJF7oflOk6cLGSAey(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫ೹")		:[tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡱ࠰ࡩࡥࡷ࡫ࡳ࡬ࡱ࠱ࡲࡪࡺࠧ೺")]
			,NupI74tJCzYXmles9SbR6(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ೻")		:[n6JjFHfmydIaLut(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬ೼")]
			,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡇࡑࡖࡘࡆ࠭೽")		:[mmbcsf2pd7gyjzreB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬ೾")]
			,nJF7oflOk6cLGSAey(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪ೿")		:[iI7tuF0nEQoR(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࠴ࡡ࡭࡯ࡨࡷ࡭ࡱࡡࡩ࠰ࡱࡩࡹ࠭ഀ")]
			,iiauUxMktNW5X(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ഁ")		:[uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢ࠯ࡨࡸࡷ࡭ࡧࡲ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨം")]
			,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫഃ")	:[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡪࡺࡹࡨࡢࡴ࠱ࡺ࡮ࡪࡥࡰࠩഄ")]
			,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪഅ")		:[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡳࡥࡥ࡫ࡤࠫആ")]
			,n6JjFHfmydIaLut(u"ࠪࡍࡋࡏࡌࡎࠩഇ")		:[VzO1gCHmjZ2ebRIL(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬഈ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ഉ"),FAwWlRJg0UkN1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧഊ"),ggtuNcvTn3HQ7SpE2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩഋ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨഌ")]
			,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ഍")	:[RRbvqditj184m3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫഎ")]
			,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ഏ")		:[TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡪࡶ࡮ࡳࡹ࠴ࡣࡢ࡯ࠪഐ")]
			,FAwWlRJg0UkN1(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ഑")		:[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡸ࠲ࡰ࡯ࡲ࡮ࡣ࡯࡯࠳ࡩ࡯࡮ࠩഒ")]
			,i80mE7lHUwVk(u"ࠨࡎࡄࡖࡔࡠࡁࠨഓ")		:[nJF7oflOk6cLGSAey(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰࡦࡸ࡯ࡻࡣ࠱࡭ࡳࡱࠧഔ")]
			,ne7wF4gSTRZo(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫക")		:[NupI74tJCzYXmles9SbR6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴ࡦࡶࡰࠪഖ")]
			,nJF7oflOk6cLGSAey(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨഗ")	:[kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱ࡱࡦࡹࡡ࠯ࡰࡨࡻࡸ࠭ഘ")]
			,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡑࡃࡑࡉ࡙࠭ങ")		:[YZXtBgvUPoM5sb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪച")]
			,iiLyoNwGbH03DIXhAkZn(u"ࠩࡕࡉࡑࡋࡁࡔࡇࡖࠫഛ")		:[TeYukOUW7i5NBM926DCjaAn0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠵ࡥ࡮ࡣࡧࡣࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡳࡱࡪ࠯ࡪࡰࡧࡩࡽ࠴ࡨࡵ࡯࡯ࠫജ")]
			,BarIC3eR9bS(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨഝ")	:[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡢ࠰ࡶࡩࡷ࡯ࡥࡴࡶ࡬ࡱࡪ࠴ࡣࡢ࡯ࠪഞ")]
			,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨട")		:[YZXtBgvUPoM5sb(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫࡬ࡦ࡮ࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩഠ")]
			,ne7wF4gSTRZo(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠵ࠫഡ")	:[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳࡬࡯ࡳࡷࡰࠫഢ")]
			,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧണ")	:[zDSw8LCxMQyraeXhojIWKmU(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪത")]
			,mmbcsf2pd7gyjzreB(u"࡙ࠬࡈࡐࡈࡋࡅࠬഥ")		:[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪദ")]
			,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩധ")		:[TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨന"),iiLyoNwGbH03DIXhAkZn(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩഩ"),OUFxZPuXDoGAbRz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭പ")]
			,zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭ഫ")		:[iiauUxMktNW5X(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡶ࡬ࡴࡵࡦ࡯ࡧࡷ࠲ࡴࡴ࡬ࡪࡰࡨࠫബ")]
			,zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡔࡊࡍࡄࡅ࡙࠭ഭ")		:[MlTVLBZ92kzorIq1Yw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬࡯ࡦࡧࡴ࠯ࡰࡨࡸࠬമ")]
			,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡖ࡙ࡊ࡚ࡔࠧയ")		:[RRbvqditj184m3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡧࡷࡱ࠲ࡲ࡫ࠧര")]
			,kreQUwJis7YmC2yqWtIF09pgjbD(u"࡚ࠪࡆࡘࡂࡐࡐࠪറ")		:[ggtuNcvTn3HQ7SpE2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳ࠮ࡷࡣࡵࡦࡴࡴ࠮ࡤࡣࡰࠫല")]
			,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩള")	:[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠴࡮ࡴࡣࡨࡱ࠳ࡴࡥࡵࠩഴ")]
			,nJF7oflOk6cLGSAey(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨവ")		:[DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡨ࡯࡭ࡢ࠰ࡷࡩࡦࡳࠧശ")]
			,OUFxZPuXDoGAbRz(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪഷ")		:[FAwWlRJg0UkN1(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡦࡩࠧസ")]
			,BarIC3eR9bS(u"ࠫ࡞ࡇࡑࡐࡖࠪഹ")		:[OUFxZPuXDoGAbRz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹ࠯ࡻࡤࡵࡴࡺ࠮ࡵࡸࠪഺ")]
			,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ഻ࠧ")		:[iiauUxMktNW5X(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯഼ࠪ")]
			,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧഽ")	:[NupI74tJCzYXmles9SbR6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬാ")]
			,NupI74tJCzYXmles9SbR6(u"ࠪࡍࡕ࡚ࡖࠨി")			:[gby0BnUuTNFk]
			,MlTVLBZ92kzorIq1Yw(u"ࠫࡒ࠹ࡕࠨീ")			:[gby0BnUuTNFk]
			,iiLyoNwGbH03DIXhAkZn(u"ࠬࡘࡅࡑࡑࡖࠫു")		:[mmbcsf2pd7gyjzreB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ൂ"),OUFxZPuXDoGAbRz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫൃ"),ne7wF4gSTRZo(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬൄ")]
			,NupI74tJCzYXmles9SbR6(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠶࠭൅")	:[iiLyoNwGbH03DIXhAkZn(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡲࡦࡨࡶ࠳࡭࡫ࡡࡥࡵ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧെ"),MlTVLBZ92kzorIq1Yw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯ࡳࡧࡩࡷ࠴࡮ࡥࡢࡦࡶ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬേ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ൈ")]
			,VzO1gCHmjZ2ebRIL(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠴ࠪ൉")	:[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬൊ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪോ"),iiLyoNwGbH03DIXhAkZn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫൌ")]
			,n6JjFHfmydIaLut(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠹്ࠧ")	:[DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬൎ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ൏"),iI7tuF0nEQoR(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ൐")]
			,OUFxZPuXDoGAbRz(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭൑")	:[ggtuNcvTn3HQ7SpE2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫ࠪ൒"),IXE6voNmrb182AyQ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡭ࡲࡨ࡮࠭൓"),FAwWlRJg0UkN1(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡰࡵࡤࡪࠩൔ")]
			,iI7tuF0nEQoR(u"ࠫࡋࡏࡌࡆࡕࡢࡗࡔ࡛ࡒࡄࡇࡖࠫൕ"):[q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴࠬൖ")]
			,iiLyoNwGbH03DIXhAkZn(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬൗ")	:[OUFxZPuXDoGAbRz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦࠪ൘"),iiLyoNwGbH03DIXhAkZn(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࠲࡫ࡽࡳ࠯ࡵࡷࡳࡷ࡫ࠧ൙")]
			}
if jxCVeKSLb9rGDOl0Qtw6:
	SITESURLS[iI7tuF0nEQoR(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ൚")]      = [tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ൛"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ൜"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ൝"),KJLkQsqSHMR1Np2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ൞"),n6JjFHfmydIaLut(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫൟ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧൠ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪൡ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫൢ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬൣ"),FAwWlRJg0UkN1(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ൤"),BarIC3eR9bS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩ൥"),RRbvqditj184m3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩ൦")]
	SITESURLS[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭൧")] = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭൨"),KJLkQsqSHMR1Np2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ൩"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൪"),BarIC3eR9bS(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ൫"),i80mE7lHUwVk(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ൬"),FAwWlRJg0UkN1(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ൭"),KJLkQsqSHMR1Np2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ൮"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ൯"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭൰"),KJLkQsqSHMR1Np2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ൱"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ൲"),n6JjFHfmydIaLut(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪ൳")]
	SITESURLS[MlTVLBZ92kzorIq1Yw(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬ൴")] = [tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭൵"),VzO1gCHmjZ2ebRIL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ൶"),FAwWlRJg0UkN1(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൷"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ൸"),NupI74tJCzYXmles9SbR6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ൹"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨൺ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫൻ"),ne7wF4gSTRZo(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬർ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ൽ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫൾ"),RRbvqditj184m3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪൿ"),ne7wF4gSTRZo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪ඀")]
	SITESURLS[IXE6voNmrb182AyQ(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫඁ")] = [OUFxZPuXDoGAbRz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪං"),nJF7oflOk6cLGSAey(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧඃ"),MlTVLBZ92kzorIq1Yw(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭඄"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩඅ"),IXE6voNmrb182AyQ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩආ"),iiLyoNwGbH03DIXhAkZn(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬඇ"),mmbcsf2pd7gyjzreB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨඈ"),mmbcsf2pd7gyjzreB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩඉ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪඊ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨඋ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧඌ"),iiLyoNwGbH03DIXhAkZn(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧඍ")]
else:
	SITESURLS[mmbcsf2pd7gyjzreB(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬඎ")]      = [RRbvqditj184m3(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩඏ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ඐ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬඑ"),mmbcsf2pd7gyjzreB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨඒ"),NupI74tJCzYXmles9SbR6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨඓ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫඔ"),KJLkQsqSHMR1Np2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧඕ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨඖ"),BarIC3eR9bS(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ඗"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ඘"),iI7tuF0nEQoR(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭඙"),MlTVLBZ92kzorIq1Yw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ක")]
	SITESURLS[VzO1gCHmjZ2ebRIL(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩඛ")] = [BarIC3eR9bS(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨග"),IXE6voNmrb182AyQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬඝ"),mmbcsf2pd7gyjzreB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫඞ"),BarIC3eR9bS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧඟ"),NupI74tJCzYXmles9SbR6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧච"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪඡ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ජ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧඣ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨඤ"),mmbcsf2pd7gyjzreB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ඥ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬඦ"),ne7wF4gSTRZo(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬට")]
	SITESURLS[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠲ࠨඨ")] = [MlTVLBZ92kzorIq1Yw(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧඩ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫඪ"),zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪණ"),BarIC3eR9bS(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ඬ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ත"),iiauUxMktNW5X(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩථ"),nJF7oflOk6cLGSAey(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬද"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ධ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧන"),MlTVLBZ92kzorIq1Yw(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ඲"),nJF7oflOk6cLGSAey(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫඳ"),RRbvqditj184m3(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡺࡩࡧࡩࡡࡤࡪࡨࠫප")]
	SITESURLS[uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧඵ")] = [i80mE7lHUwVk(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭බ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪභ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩම"),DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬඹ"),NupI74tJCzYXmles9SbR6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬය"),ggtuNcvTn3HQ7SpE2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨර"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ඼"),iiauUxMktNW5X(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬල"),VzO1gCHmjZ2ebRIL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭඾"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ඿"),YZXtBgvUPoM5sb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪව"),iI7tuF0nEQoR(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪශ")]
api_python_actions = [Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪෂ"),iiauUxMktNW5X(u"ࠩࡕࡉࡕࡕࡒࡕࡕࠪස"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡉࡒࡇࡉࡍࡕࠪහ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ළ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡏࡓࡍࡃࡐࡍࡈ࡙ࠧෆ"),ggtuNcvTn3HQ7SpE2(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ෇"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡌࡐࡒ࡛ࡓࡋࡒࡓࡑࡕࡗࠬ෈"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩ෉"),mmbcsf2pd7gyjzreB(u"ࠩࡗࡉࡘ࡚ࡉࡏࡉ්ࠪ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡉ࡝࡚ࡒࡂࡒ࡜ࡘࡍࡕࡎࡄࡑࡇࡉࠬ෋"),YZXtBgvUPoM5sb(u"ࠫࡊ࡞ࡅࡄࡗࡗࡉࡏ࡙ࠧ෌"),zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࡝ࡅࡃࡅࡄࡇࡍࡋࠧ෍")]
api_repos_actions = [mmbcsf2pd7gyjzreB(u"࠭ࡁࡅࡆࡒࡒࡘ࠭෎"),BarIC3eR9bS(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩා"),RRbvqditj184m3(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪැ")]
non_videos_actions = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࡄࡐࡑ࠭ෑ"),ggtuNcvTn3HQ7SpE2(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪි"),n6JjFHfmydIaLut(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬී"),KJLkQsqSHMR1Np2(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩු"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡒࡆࡒࡒࡗࠬ෕"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡅࡑࡑࡅ࡙ࡏࡏࡏࡕࠪූ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࡋࡇࠫ෗"),KJLkQsqSHMR1Np2(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࡗࡓࡐࡋࡎࠨෘ"),VzO1gCHmjZ2ebRIL(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡋࡊ࡚ࡉࡅࠩෙ"),OUFxZPuXDoGAbRz(u"ࠫࡘࡏࡔࡆࡕࡘࡖࡑ࡙ࠧේ")]+api_python_actions+api_repos_actions
ekiYyQnB4E2W830DC = yrcbRSFswvAfEdIWVj
UdPmqCi4yVlQaf = w8Ui6RsVhSPrqHfO4
D9ZNeIiFunAftqWhB8Q = yrcbRSFswvAfEdIWVj
NiXZIL0GzwCV = yrcbRSFswvAfEdIWVj
avprivsnorestrict = yrcbRSFswvAfEdIWVj
avprivslongperiod = yrcbRSFswvAfEdIWVj
resolveonly = yrcbRSFswvAfEdIWVj
Uzo7FMNr5YDA2q13d6 = yrcbRSFswvAfEdIWVj
ALLOW_DNS_FIX = D0DRCGqknfT2tKPY6N
ALLOW_PROXY_FIX = D0DRCGqknfT2tKPY6N
ALLOW_SHOWDIALOGS_FIX = D0DRCGqknfT2tKPY6N
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧෛ"),i80mE7lHUwVk(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩො"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨෝ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪෞ"),iiLyoNwGbH03DIXhAkZn(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩෟ"),RRbvqditj184m3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ෠"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠫ࡞ࡇࡑࡐࡖࠪ෡"),RRbvqditj184m3(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬ෢"),MlTVLBZ92kzorIq1Yw(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ෣"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡑࡃࡑࡉ࡙࠭෤"),i80mE7lHUwVk(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ෥")]
BADWEBSITES += [Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ෦")]
BADCOMMONIDS = [i80mE7lHUwVk(u"ࠪ࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠹࠺࠻࠼࠱࠾࠿࠹࠺࠯࠳࠴࠵࠶ࠧ෧"),OUFxZPuXDoGAbRz(u"ࠫ࠾࠿࠸࠹࠯࠺࠻࠻࠼࠭࠶࠷࠷࠸࠲࠹࠳࠳࠴࠰࠶࠵࠾࠶ࠨ෨")]
GEOLOCATION_DATA = gby0BnUuTNFk
AV_CLIENT_IDS = gby0BnUuTNFk
DNS_SERVERS = [n6JjFHfmydIaLut(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭෩"),iI7tuF0nEQoR(u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ෪"),BarIC3eR9bS(u"ࠧ࠲࠰࠳࠲࠵࠴࠱ࠨ෫"),OUFxZPuXDoGAbRz(u"ࠨ࠺࠱࠼࠳࠺࠮࠵ࠩ෬"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠷࠴࠲࠳࠴ࠪ෭"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠶࠮࠳࠴࠳ࠫ෮")]
busydialog_active = yrcbRSFswvAfEdIWVj
dns_succeeded_urls = []
scrapers_succeeded = yrcbRSFswvAfEdIWVj