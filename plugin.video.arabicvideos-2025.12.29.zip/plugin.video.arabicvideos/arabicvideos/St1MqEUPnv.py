# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'ALFATIMI'
JB9fyoHr05QOtPjp = '_FTM_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
yKoid0O7U6awG = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
oasefH14xY6SRybz = ['3030','628']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==60: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==61: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==62: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==63: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==64: WjryKiBebavP = uB7cIjEbYfR2XUxdD(text)
	elif mode==69: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,69,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'ما يتم مشاهدته الان',LhFnEIuPHdoNc,64,gby0BnUuTNFk,gby0BnUuTNFk,'recent_viewed_vids')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الاكثر مشاهدة',LhFnEIuPHdoNc,64,gby0BnUuTNFk,gby0BnUuTNFk,'most_viewed_vids')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'اضيفت مؤخرا',LhFnEIuPHdoNc,64,gby0BnUuTNFk,gby0BnUuTNFk,'recently_added_vids')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'فيديو عشوائي',LhFnEIuPHdoNc,64,gby0BnUuTNFk,gby0BnUuTNFk,'random_vids')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'افلام ومسلسلات',LhFnEIuPHdoNc,61,gby0BnUuTNFk,gby0BnUuTNFk,'-1')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'البرامج الدينية',LhFnEIuPHdoNc,61,gby0BnUuTNFk,gby0BnUuTNFk,'-2')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'English Videos',LhFnEIuPHdoNc,61,gby0BnUuTNFk,gby0BnUuTNFk,'-3')
	return gby0BnUuTNFk
def Xw3tTz8UD4LK26C(url,zTFlfH8DhAVryqUjX):
	FTZOc0As483 = gby0BnUuTNFk
	if zTFlfH8DhAVryqUjX not in ['-1','-2','-3']: FTZOc0As483 = '?cat='+zTFlfH8DhAVryqUjX
	Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+'/menu_level.php'+FTZOc0As483
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ALFATIMI-TITLES-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	TTURPtmHYpNLy1FCi8Slvdk,znBDIy3fxKUPoTGJR6SCp5 = False,False
	for SSqweDUBYv4bkO,title,count in items:
		title = Y7BxKQdU84R(title)
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
		FTZOc0As483 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('cat=(.*?)&',SSqweDUBYv4bkO,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
		if zTFlfH8DhAVryqUjX==FTZOc0As483: TTURPtmHYpNLy1FCi8Slvdk = True
		elif TTURPtmHYpNLy1FCi8Slvdk 	or (zTFlfH8DhAVryqUjX=='-1' and FTZOc0As483 in yKoid0O7U6awG)  						or (zTFlfH8DhAVryqUjX=='-2' and FTZOc0As483 not in oasefH14xY6SRybz and FTZOc0As483 not in yKoid0O7U6awG)  						or (zTFlfH8DhAVryqUjX=='-3' and FTZOc0As483 in oasefH14xY6SRybz):
							if count=='1': ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,63)
							else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,61,gby0BnUuTNFk,gby0BnUuTNFk,FTZOc0As483)
							znBDIy3fxKUPoTGJR6SCp5 = True
	if not znBDIy3fxKUPoTGJR6SCp5: Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,True,'ALFATIMI-EPISODES-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination(.*?)id="footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	SSqweDUBYv4bkO = gby0BnUuTNFk
	for T6TRUSbecYGWIq29KF,title,SSqweDUBYv4bkO in items:
		title = title.replace('Add',gby0BnUuTNFk).replace('to Quicklist',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,63,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?)div',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0=QKqM0CwXDk8APOoJFpyntRb[0]
	AxiBv1cQueOs0=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	items=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Tf5ueYGZIFl1hraoEOVKi = url.split('?')[0]
	for SSqweDUBYv4bkO,ZmaDvrNx5TAYU3 in items:
		SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi + SSqweDUBYv4bkO
		title = Y7BxKQdU84R(ZmaDvrNx5TAYU3)
		title = 'صفحة ' + title
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,62)
	return SSqweDUBYv4bkO
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	if 'videos.php' in url: url = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,gby0BnUuTNFk,True,'ALFATIMI-PLAY-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('playlistfile:"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	YAQOL1eVvqMjsEfIFc(url,CC3nOPFMovd72u,'video')
	return
def uB7cIjEbYfR2XUxdD(zTFlfH8DhAVryqUjX):
	pjBAh5E2XWYmHx = { 'mode' : zTFlfH8DhAVryqUjX }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = Atv9rwjEMV7acSCxosyhQnF(pjBAh5E2XWYmHx)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(cjSzHQn9N4BuIZO0xJ,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,63,T6TRUSbecYGWIq29KF)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + '/search_result.php?query=' + apTFWBhb175nwjvKtmJ2
	Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	return