# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMALIGHT'
JB9fyoHr05QOtPjp = '_CML_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['قنوات فضائية']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==470: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==471: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==472: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==473: WjryKiBebavP = tHWd5iUKp0uBRESTL1FCAOGabsV(url,text)
	elif mode==474: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==479: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,479,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"content"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		title = title.replace(rBcdwYZInhgO29jtkFAfGxi7,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('cat=online-movies1','cat=online-movies')
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,474)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('/category.php">(.*?)"navslide-divider"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("'dropdown-menu'(.*?)</ul>",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,474)
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if 'topvideos.php' in url: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"caret"(.*?)id="pm-grid"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"caret"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if 'topvideos.php' in SSqweDUBYv4bkO:
				if 'topvideos.php?c=english-movies' in SSqweDUBYv4bkO: continue
				if 'topvideos.php?c=online-movies1' in SSqweDUBYv4bkO: continue
				if 'topvideos.php?c=misc' in SSqweDUBYv4bkO: continue
				if 'topvideos.php?c=tv-channel' in SSqweDUBYv4bkO: continue
				if 'منذ البداية' in title and 'do=rating' not in SSqweDUBYv4bkO: continue
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,471)
	else: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = []
	if Z05rTiu6LwakteK8VfY=='featured_movies':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container-fluid"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		vx14CNdbsZTz,K6ucHgjCtqf9wBZxXAUh3Db5EMJW,NN13lIncVSJ0K9kQG2eHdu = zip(*items)
		items = zip(NN13lIncVSJ0K9kQG2eHdu,vx14CNdbsZTz,K6ucHgjCtqf9wBZxXAUh3Db5EMJW)
	elif Z05rTiu6LwakteK8VfY=='featured_series':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('المسلسلات المميزة(.*?)<style>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		vx14CNdbsZTz,K6ucHgjCtqf9wBZxXAUh3Db5EMJW,NN13lIncVSJ0K9kQG2eHdu = zip(*items)
		items = zip(NN13lIncVSJ0K9kQG2eHdu,vx14CNdbsZTz,K6ucHgjCtqf9wBZxXAUh3Db5EMJW)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(data-echo=".*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"BlocksList"(.*?)"titleSectionCon"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="pm-grid"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="pm-related"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pm-ul-browse-videos(.*?)clearfix',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: return
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		title = title.replace('ماي سيما',gby0BnUuTNFk).replace('مشاهدة',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
		if 'http' not in T6TRUSbecYGWIq29KF: T6TRUSbecYGWIq29KF = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+T6TRUSbecYGWIq29KF.strip('/')
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة) \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			title = '_MOD_'+title
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,472,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'حلقة' in title:
			title = '_MOD_'+Cso7iV0ZOw2UW5Ez[0][0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,473,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movseries/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,471,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,473,T6TRUSbecYGWIq29KF)
	if Z05rTiu6LwakteK8VfY not in ['featured_movies','featured_series']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=='#': continue
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				title = Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,471)
		fhW8oRx6TUJiuFK5GXQH9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('showmore" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if fhW8oRx6TUJiuFK5GXQH9:
			SSqweDUBYv4bkO = fhW8oRx6TUJiuFK5GXQH9[0]
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مشاهدة المزيد',SSqweDUBYv4bkO,471)
	return
def tHWd5iUKp0uBRESTL1FCAOGabsV(url,YYOman4GEXScVfjg89bRkDq):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-EPISODES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsBox"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	items = []
	if l2Np9PfFqv4RcW7Y and not YYOman4GEXScVfjg89bRkDq:
		T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"series-header".*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0] if T6TRUSbecYGWIq29KF else gby0BnUuTNFk
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)==1: YYOman4GEXScVfjg89bRkDq = items[0][0]
		elif len(items)>1:
			for YYOman4GEXScVfjg89bRkDq,title in items: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,473,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,YYOman4GEXScVfjg89bRkDq)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="'+YYOman4GEXScVfjg89bRkDq+'"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7 and len(items)<2:
		T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"series-header".*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0] if T6TRUSbecYGWIq29KF else gby0BnUuTNFk
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for SSqweDUBYv4bkO,title in items:
				title = title.replace('ماي سيما',gby0BnUuTNFk).replace('مسلسل',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,472,T6TRUSbecYGWIq29KF)
		else:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,472,T6TRUSbecYGWIq29KF)
	if 'id="pm-related"' in jS6fQGXeouTB7xKd32ZMy:
		if items: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مواضيع ذات صلة',url,471)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<div itemprop="description">(.*?)href=',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<p>(.*?)</p>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY,True): return
	Tf5ueYGZIFl1hraoEOVKi = url.replace('/watch.php','/play.php')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-PLAY-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	vvosC60Txqeft3maJ = []
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embedURL" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		if SSqweDUBYv4bkO and SSqweDUBYv4bkO not in vvosC60Txqeft3maJ:
			vvosC60Txqeft3maJ.append(SSqweDUBYv4bkO)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named=__embed'
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if SSqweDUBYv4bkO not in vvosC60Txqeft3maJ:
			vvosC60Txqeft3maJ.append(SSqweDUBYv4bkO)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	Tf5ueYGZIFl1hraoEOVKi = url.replace('/watch.php','/downloads.php')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMALIGHT-PLAY-3rd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"downloadlist"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<strong>(.*?)</strong>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if SSqweDUBYv4bkO not in vvosC60Txqeft3maJ:
				vvosC60Txqeft3maJ.append(SSqweDUBYv4bkO)
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(LhFnEIuPHdoNc,'url')
	url = TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'/search.php?keywords='+search
	Xw3tTz8UD4LK26C(url,'search')
	return