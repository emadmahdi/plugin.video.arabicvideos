# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'EGYBESTVIP'
JB9fyoHr05QOtPjp = '_EGV_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,kdwXYDMQOjz51Z08W,text):
	if   mode==220: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==221: WjryKiBebavP = Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W)
	elif mode==222: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==223: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==224: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url)
	elif mode==229: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,229,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="i i-home"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,222)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="ba(.*?)<script',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,SSqweDUBYv4bkO in items:
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,221)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if 'html' not in SSqweDUBYv4bkO: continue
			if not SSqweDUBYv4bkO.endswith('/'): ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,221)
	return jS6fQGXeouTB7xKd32ZMy
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="rs_scroll"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,224)
	return
def PsoEh3mOJub72VQl1crzW5n(url):
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',url,221)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-FILTERS_MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="sub_nav(.*?)id="movies',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".+?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if SSqweDUBYv4bkO=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,221)
	else: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W='1'):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	if '/search' in url or '?' in url: Tf5ueYGZIFl1hraoEOVKi = url + '&'
	else: Tf5ueYGZIFl1hraoEOVKi = url + '?'
	Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi + 'page=' + kdwXYDMQOjz51Z08W
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pda"(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[-1]
	elif '/series/' in url:
		QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="owl-carousel owl-carousel(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	else:
		QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="movies(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[-1]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		title = Y7BxKQdU84R(title)
		if '/movie/' in SSqweDUBYv4bkO or '/episode' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO.rstrip('/'),223,T6TRUSbecYGWIq29KF)
		else:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,221,T6TRUSbecYGWIq29KF)
	if len(items)>=16:
		KDBCxfWu1m6wiPL7absXZVOtT = ['/movies','/tv','/search','/trending']
		kdwXYDMQOjz51Z08W = int(kdwXYDMQOjz51Z08W)
		if any(value in url for value in KDBCxfWu1m6wiPL7absXZVOtT):
			for V5307fsKxWXEniF in range(0,1000,100):
				if int(kdwXYDMQOjz51Z08W/100)*100==V5307fsKxWXEniF:
					for xuX6UN0WRQbHArDV in range(V5307fsKxWXEniF,V5307fsKxWXEniF+100,10):
						if int(kdwXYDMQOjz51Z08W/10)*10==xuX6UN0WRQbHArDV:
							for aA0yGgzrdjoENpWKS in range(xuX6UN0WRQbHArDV,xuX6UN0WRQbHArDV+10,1):
								if not kdwXYDMQOjz51Z08W==aA0yGgzrdjoENpWKS and aA0yGgzrdjoENpWKS!=0:
									ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+str(aA0yGgzrdjoENpWKS),url,221,gby0BnUuTNFk,str(aA0yGgzrdjoENpWKS))
						elif xuX6UN0WRQbHArDV!=0: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+str(xuX6UN0WRQbHArDV),url,221,gby0BnUuTNFk,str(xuX6UN0WRQbHArDV))
						else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+str(1),url,221,gby0BnUuTNFk,str(1))
				elif V5307fsKxWXEniF!=0: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+str(V5307fsKxWXEniF),url,221,gby0BnUuTNFk,str(V5307fsKxWXEniF))
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+str(1),url,221)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R = [],[]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-PLAY-1st')
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<td>التصنيف</td>.*?">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	gaF7eDxrbm9BNMPRlHwo5,HwFsq9iob2Ly7kOYeC0 = gby0BnUuTNFk,gby0BnUuTNFk
	AAsHwdLoCDOFJb9QI3jvgfyp,ljAoiPRet3LsHmG91UdDbn = jS6fQGXeouTB7xKd32ZMy,jS6fQGXeouTB7xKd32ZMy
	RhtAC3E4G7nf9q = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('show_dl api" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if RhtAC3E4G7nf9q:
		for SSqweDUBYv4bkO in RhtAC3E4G7nf9q:
			if '/watch/' in SSqweDUBYv4bkO: gaF7eDxrbm9BNMPRlHwo5 = SSqweDUBYv4bkO
			elif '/download/' in SSqweDUBYv4bkO: HwFsq9iob2Ly7kOYeC0 = SSqweDUBYv4bkO
		if gaF7eDxrbm9BNMPRlHwo5!=gby0BnUuTNFk: AAsHwdLoCDOFJb9QI3jvgfyp = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,gaF7eDxrbm9BNMPRlHwo5,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-PLAY-2nd')
		if HwFsq9iob2Ly7kOYeC0!=gby0BnUuTNFk: ljAoiPRet3LsHmG91UdDbn = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,HwFsq9iob2Ly7kOYeC0,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-PLAY-3rd')
	byFmghvKkBH9xw06VcTuGl = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="video".*?data-src="(.*?)"',AAsHwdLoCDOFJb9QI3jvgfyp,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if byFmghvKkBH9xw06VcTuGl:
		Tf5ueYGZIFl1hraoEOVKi = byFmghvKkBH9xw06VcTuGl[0]
		if Tf5ueYGZIFl1hraoEOVKi!=gby0BnUuTNFk and 'uploaded.egybest.download' in Tf5ueYGZIFl1hraoEOVKi and '/?id=_' not in Tf5ueYGZIFl1hraoEOVKi:
			N84Yo7V9qS = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-PLAY-4th')
			IfdjZOLtapQE037i1exc8zMNyDs2 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('source src="(.*?)" title="(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if IfdjZOLtapQE037i1exc8zMNyDs2:
				for SSqweDUBYv4bkO,DYNVS1Bbgs7 in IfdjZOLtapQE037i1exc8zMNyDs2:
					eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO+'?named=ed.egybest.do__watch__mp4__'+DYNVS1Bbgs7)
			else:
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = Tf5ueYGZIFl1hraoEOVKi.split('/')[2]
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(Tf5ueYGZIFl1hraoEOVKi+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__watch')
		elif Tf5ueYGZIFl1hraoEOVKi!=gby0BnUuTNFk:
			TfYmiUDcZOCgQ86rENjVG1zaqXbWk = Tf5ueYGZIFl1hraoEOVKi.split('/')[2]
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(Tf5ueYGZIFl1hraoEOVKi+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__watch')
	Sr6xGHm1yclzYfaO5ADEoNB4T = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<table class="dls_table(.*?)</table>',ljAoiPRet3LsHmG91UdDbn,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Sr6xGHm1yclzYfaO5ADEoNB4T:
		Sr6xGHm1yclzYfaO5ADEoNB4T = Sr6xGHm1yclzYfaO5ADEoNB4T[0]
		BJZaxXwLIz1WEPsSloeYKjQMV29 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',Sr6xGHm1yclzYfaO5ADEoNB4T,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if BJZaxXwLIz1WEPsSloeYKjQMV29:
			for DYNVS1Bbgs7,SSqweDUBYv4bkO in BJZaxXwLIz1WEPsSloeYKjQMV29:
				if 'myegyvip' not in SSqweDUBYv4bkO: continue
				if SSqweDUBYv4bkO.count('/')>=2:
					TfYmiUDcZOCgQ86rENjVG1zaqXbWk = SSqweDUBYv4bkO.split('/')[2]
					eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__download__mp4__'+DYNVS1Bbgs7)
	ReBKsmpDSTAkwQnjghx20cbrUo84 = []
	for SSqweDUBYv4bkO in eE9BXgNu4MPKIbw2aLDl1AY3R:
		ReBKsmpDSTAkwQnjghx20cbrUo84.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ReBKsmpDSTAkwQnjghx20cbrUo84,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(cjSzHQn9N4BuIZO0xJ,LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBESTVIP-SEARCH-1st')
	JkjTvbtFlIoDZ70wBiEVcqeWMRL = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('name="_token" value="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if JkjTvbtFlIoDZ70wBiEVcqeWMRL:
		url = LhFnEIuPHdoNc+'/search?_token='+JkjTvbtFlIoDZ70wBiEVcqeWMRL[0]+'&q='+apTFWBhb175nwjvKtmJ2
		Xw3tTz8UD4LK26C(url)
	return