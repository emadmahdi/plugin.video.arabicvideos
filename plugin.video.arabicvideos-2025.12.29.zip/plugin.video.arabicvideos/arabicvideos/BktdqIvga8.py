# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from V4OX6PRG0U import *
CC3nOPFMovd72u = sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨၠ")
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,fbmZ9V58PCTz=gby0BnUuTNFk):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==VzO1gCHmjZ2ebRIL(u"࠶ፔ"): CiO9l3RYXSry74p(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==RRbvqditj184m3(u"࠱ፕ"): pass
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠳ፖ"): JJ8MfBcExXU(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠵ፗ"): LOSzjpk5Awrv01gx4mU3MyY8KViqaN()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==Ducd5PRjQXaB9SIN7VrJ1G(u"࠷ፘ"): jWo6yJ0b42(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠹ፙ"): N1OvkDdy9EMHXP0gCThqU()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠻ፚ"): luwOqbBJjTv()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠽፛"): v2GXgKVoAk8DztPMNIZeyfbTuHpm()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠸፜"): BxFX7ehown18DEktRIf392()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==VzO1gCHmjZ2ebRIL(u"࠲࠷࠳፝"): AqPEgXDls8Oo51kad3npxumz()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠳࠸࠵፞"): DFmAwPGCJEieMHOhXQkxN()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==NupI74tJCzYXmles9SbR6(u"࠴࠹࠷፟"): mcsLZ970qCN6z38tdyPDHvu4()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠵࠺࠹፠"): FtuZKfycwIxoer()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠶࠻࠴፡"): xIqTXFYAz1Jgdf6r8tkb3Diw4KZlnS()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==YZXtBgvUPoM5sb(u"࠷࠵࠶።"): TFEkqojQX2wel0aV8iyDPcpRW5uv1S()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠱࠶࠸፣"): PxF5CVrnSMLOBg0q()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==q2qPkMFpR1G86dEAKXHivor9N(u"࠲࠷࠺፤"): hkaHbpoX2SVQRUczLEM()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠳࠸࠼፥"): uOTwtcpegdmLN6P()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠴࠹࠾፦"): JSLmRgwKGdQU(w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠵࠼࠶፧"): Ll4cuU5AVG()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iI7tuF0nEQoR(u"࠶࠽࠱፨"): LVmuDZaTXF6fMkSU17Y()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠷࠷࠳፩"): hIqY7oRDuE18WSstUCdb([fbmZ9V58PCTz],w8Ui6RsVhSPrqHfO4,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==OUFxZPuXDoGAbRz(u"࠱࠸࠵፪"): IRMxnQpdEFikJw6L7y0(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧၡ"),w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠲࠹࠷፫"): IRMxnQpdEFikJw6L7y0(YZXtBgvUPoM5sb(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫၢ"),w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iI7tuF0nEQoR(u"࠳࠺࠹፬"): uxjer0yKiOHow2IScLzWf3MgqQ6nXl()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==KJLkQsqSHMR1Np2(u"࠴࠻࠻፭"): V3vqXLS1nHU()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠵࠼࠽፮"): B0diD3JVGq7L(iI7tuF0nEQoR(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ၣ"))
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==q2qPkMFpR1G86dEAKXHivor9N(u"࠶࠽࠹፯"): B0diD3JVGq7L(ggtuNcvTn3HQ7SpE2(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪၤ"))
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠷࠹࠱፰"): KszlZctk8SWyf()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠱࠺࠳፱"): ZwCAKlIWQhD38fxHORezp27YvcE()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠲࠻࠵፲"): M7NzYHc5WO8ma4oh1pC()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠳࠼࠷፳"): gpSKtR0uC5ZbT9()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠴࠽࠹፴"): MPtqdaVFJCSyTxIDzrwlAhR()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠵࠾࠻፵"): QJYnrO0B63t15DEIdgPxAq4R()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠶࠿࠶፶"): rnPW4Z1YL5e6SRkoQ8NIfFVOKJT()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠷࠹࠸፷"): KDVAhoUcjsRE74lYTMLfBdk91gvyNG()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠱࠺࠺፸"): n62DFrI1fTPiULoxOJzQ()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==NupI74tJCzYXmles9SbR6(u"࠲࠻࠼፹"): KK4YR8pck7WstMhuTPOXHVrG()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ggtuNcvTn3HQ7SpE2(u"࠵࠷࠴፺"): rqng05yhKlzosteX8BD(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠶࠸࠶፻"): aH3DdLgITVhzb7pik04xyJM()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠷࠹࠸፼"): UeiZ1rO7MJQmlfH()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠸࠺࠳፽"): Mlg347zA9xyWtjL1Cowm8IDrNBQ()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠹࠴࠶፾"): So8eYw3anPGiOu9KCxvzy()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠳࠵࠸፿"): h7oab3SLi5pUcvusmJqy9EZAgn(yrcbRSFswvAfEdIWVj)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==VzO1gCHmjZ2ebRIL(u"࠴࠶࠺ᎀ"): TAFLUzpWg63Rf(w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==q2qPkMFpR1G86dEAKXHivor9N(u"࠵࠷࠼ᎁ"): k1knLKAimG()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==RRbvqditj184m3(u"࠶࠸࠾ᎂ"): N8zQWwifyKGJbOVprhl4(OUFxZPuXDoGAbRz(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၥ"),w8Ui6RsVhSPrqHfO4,w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==zDSw8LCxMQyraeXhojIWKmU(u"࠹࠵࠶ᎃ"): iAvq6GUWyOIoZSNQ()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠺࠶࠱ᎄ"): sshedVIknBYMRcF9L8wi7HzuSEWq6T()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ggtuNcvTn3HQ7SpE2(u"࠻࠰࠳ᎅ"): zpg1Sr387t()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠱࠵ᎆ"): Oo6y58XLMmUTGq(sTZKJYrgqmkxtvpP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠶࠲࠷ᎇ"): Oo6y58XLMmUTGq(U24naHzCgdv7wWF)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ggtuNcvTn3HQ7SpE2(u"࠷࠳࠹ᎈ"): MdOqL8p7EvkZl2PxiTn()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠸࠴࠻ᎉ"): Cjio8VzFbEgRfTNH3UrDJMZ(w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==kreQUwJis7YmC2yqWtIF09pgjbD(u"࠹࠵࠽ᎊ"): QY31epUBWow56Njb8zAOaLCSFsyt()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠺࠶࠸ᎋ"): JcbFsjyMSX7()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠷࠰࠳࠲ᎌ"): XXDAVkhr6iZKmEv()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==q2qPkMFpR1G86dEAKXHivor9N(u"࠱࠱࠴࠴ᎍ"): iuSfa9V3vEjBgWRlCKILbzDpw()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠲࠲࠵࠶ᎎ"): B0diD3JVGq7L(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၦ"))
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠳࠳࠶࠸ᎏ"): Ma5OZno38AUPT1ihNVswvcFd()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiauUxMktNW5X(u"࠴࠴࠷࠺᎐"): TXUl3chADy(w8Ui6RsVhSPrqHfO4)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠵࠵࠸࠵᎑"): nLy53gmGpD1NxduTi()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠶࠶࠲࠷᎒"): bO7kXxGMWdR()
	return
def TXUl3chADy(showDialogs=yrcbRSFswvAfEdIWVj):
	NAitbHsaR5EqySXuM = oKew16fsvuV8.executeJSONRPC(nJF7oflOk6cLGSAey(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡩࡡ࡭ࡧ࠱࡯ࡪࡿࡢࡰࡣࡵࡨࡱࡧࡹࡰࡷࡷࡷࠧࢃࡽࠨၧ"))
	NAitbHsaR5EqySXuM = FoCsyPaNjhWf.loads(NAitbHsaR5EqySXuM)[iiauUxMktNW5X(u"ࠧࡳࡧࡶࡹࡱࡺࠧၨ")][YZXtBgvUPoM5sb(u"ࠨࡸࡤࡰࡺ࡫ࠧၩ")]
	choice,YqFWadgr4t36cnk9iRs78DT = dNx9DVCtafk4r,NAitbHsaR5EqySXuM[:]
	if showDialogs:
		RDL5wSZqKT = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣๆ฿ไส๋ࠢฮ฾๋ไࠨၪ") if FAwWlRJg0UkN1(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪၫ") in NAitbHsaR5EqySXuM else NupI74tJCzYXmles9SbR6(u"้ࠫ๎อสࠢส่๊็วห์ะࠤฬู๊าสํอ๋ࠥส้ไไอࠬၬ")
		choice = yc8Ph4rFsCIvQbOA(n6JjFHfmydIaLut(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၭ"),OUFxZPuXDoGAbRz(u"࠭ฮา๊ฯࠫၮ"),BarIC3eR9bS(u"ࠧฦ์ๅหๆ࠭ၯ"),i80mE7lHUwVk(u"ࠨฬื฾๏๊ࠧၰ"),e1nNXbPrBVDZw,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+RDL5wSZqKT+GGy0cQe765nPYZ9E8Th+okfdjS4RmM+okfdjS4RmM+NupI74tJCzYXmles9SbR6(u"๊ࠩิ์ࠦวๅ๊฻๎ๆฯࠠหี่ัࠥฮวิฬัำฬ๋ࠠๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡษ็้ํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์สࠡฬึฮ฼๐ูࠡล้ࠤฯ฿ๅๅࠢหัะࠦแ๋่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣฬฬูสฯัส้ࠥอไๅ฼ฬࠤฬู๊าสํอࠥ࠴࠮ࠡล๋ࠤฯูสุ์฼ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤ้๊ๅษำ่ะࠥฮวๅๆ฽อࠥอไฺำห๎ฮࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊ࠠๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡล่ࠤส๐โศใ๊หࠥลࠡࠢࠩၱ"))
	if choice==dNx9DVCtafk4r and sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪၲ") not in NAitbHsaR5EqySXuM: YqFWadgr4t36cnk9iRs78DT = [IXE6voNmrb182AyQ(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫၳ")]+NAitbHsaR5EqySXuM
	elif choice==jxCVeKSLb9rGDOl0Qtw6 and tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬၴ") in NAitbHsaR5EqySXuM:
		YqFWadgr4t36cnk9iRs78DT = NAitbHsaR5EqySXuM[:]
		YqFWadgr4t36cnk9iRs78DT.remove(n6JjFHfmydIaLut(u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡑࡘࡇࡕࡘ࡞࠭ၵ"))
	if YqFWadgr4t36cnk9iRs78DT!=NAitbHsaR5EqySXuM:
		YqFWadgr4t36cnk9iRs78DT = str(YqFWadgr4t36cnk9iRs78DT).replace(n6JjFHfmydIaLut(u"ࠢࠨࠤၶ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࠤࠪၷ"))
		WjryKiBebavP = oKew16fsvuV8.executeJSONRPC(iiLyoNwGbH03DIXhAkZn(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡥࡤࡰࡪ࠴࡫ࡦࡻࡥࡳࡦࡸࡤ࡭ࡣࡼࡳࡺࡺࡳࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠫၸ")+YqFWadgr4t36cnk9iRs78DT+TeYukOUW7i5NBM926DCjaAn0(u"ࠪࢁࢂ࠭ၹ"))
		if showDialogs:
			if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡹࡸࡵࡦࠩၺ") in str(WjryKiBebavP): tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,n6JjFHfmydIaLut(u"ࠬะๅหࠢส่฾๋ไ๋หࠣฬ๋าวฮࠩၻ"))
			else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ไๅลึๅࠥอไฺ็็๎ฮࠦแีๆอࠫၼ"))
	return
def Ma5OZno38AUPT1ihNVswvcFd():
	H43svmuKOrRD2APk6w51hVGjabxiTt = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(NupI74tJCzYXmles9SbR6(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫၽ"))
	message = ggtuNcvTn3HQ7SpE2(u"ࠨษ็ี็๋ࠠศๆ่ัิีࠠฮษ็๎ฬࠦ็้ࠢ࠽ࠤࠥࠦࠧၾ")+str(H43svmuKOrRD2APk6w51hVGjabxiTt)+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࠣ࡯ࡧࡶࡳࠨၿ") if H43svmuKOrRD2APk6w51hVGjabxiTt else uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋ห้ࠣฯ๎โโหࠣัฬ๊๊ศࠩႀ")
	message = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+message+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡡࡴ็ๅࠢอี๏ีࠠศๆล๊ࠥะิ฻์็ࠤศ๎ࠠห฼ํ๎ึࠦัใ็ࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠪႁ")+GGy0cQe765nPYZ9E8Th
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬႂ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ฮา๊ฯࠫႃ"),KJLkQsqSHMR1Np2(u"ࠧฦ์ๅหๆ࠭ႄ"),NupI74tJCzYXmles9SbR6(u"ࠨฬื฾๏๊ࠧႅ"),e1nNXbPrBVDZw,message+zDSw8LCxMQyraeXhojIWKmU(u"ࠩ࡟ࡲࡡࡴวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࠦ็๋ࠢ฼้้๐ษࠡ์ๅ์๊ࠦศ่ษࠣห้ฮั็ษ่ะࠥฮวฯฬํหึࠦรฺๆ์ࠤั๎ฯส่ࠢฮํ็ัสࠢ็ี็๋ࠠศๆฯ์ิฯࠠศๆำ๎ࠥอๆหࠢอัิี็ࠡใํࠤ์ึ็ࠡษ็ุฬฺษࠡ࠰࠱ࠤํํะศ่ࠢ฽๋อ็ࠡ฻้ำ๊อࠠหไ๋้ࠥอๆหࠢหฮูเ๊ๅࠢไ๎ิ๐่ࠡใส๊ࠥอไษำ้ห๊าࠠๅ่ࠣ๎ุษไไࠢ฼๊ࠥอไอ๊าอࠥอไห์ࠣฮึ๐ฯ่ษ่ࠣศ์ࠠศๆหี๋อๅอࠢึ์ๆ๊ࠦฯฬสีࠥอไอ๊าอࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳ูࠦๅ็สࠤฬ์็ࠡ์ฯฬࠥอฮห์สีࠥืโๆࠢฯ์ิฯࠠึ฼ํีࠥหะศࠢๆห๋ะࠠศๆศ๊ฯืๆหࠢ฼๊ิ้ࠠษูํสฮࠦร้ࠢๅ่๏๊ษࠨႆ"))
	if JlbGIYdQZkvtqjmR5r7 in [-NupI74tJCzYXmles9SbR6(u"࠷᎓"),OUFxZPuXDoGAbRz(u"࠰᎔")]: return
	if JlbGIYdQZkvtqjmR5r7==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠲᎕"):
		H43svmuKOrRD2APk6w51hVGjabxiTt = gby0BnUuTNFk
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ์ๅหๆࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮ࠭ႇ"))
	else:
		items = [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫ࠷࠻࠰ࠡ࡭ࡥࡴࡸ࠭ႈ"),KJLkQsqSHMR1Np2(u"ࠬ࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧႉ"),mmbcsf2pd7gyjzreB(u"࠭࠷࠶࠲ࠣ࡯ࡧࡶࡳࠨႊ"),ne7wF4gSTRZo(u"ࠧ࠲࠲࠳࠴ࠥࡱࡢࡱࡵࠪႋ"),BarIC3eR9bS(u"ࠨ࠳࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫႌ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩ࠴࠹࠵࠶ࠠ࡬ࡤࡳࡷႍࠬ"),i80mE7lHUwVk(u"ࠪ࠵࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭ႎ"),iI7tuF0nEQoR(u"ࠫ࠷࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႏ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࠸࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ႐"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࠳࠱࠲࠳ࠤࡰࡨࡰࡴࠩ႑"),VzO1gCHmjZ2ebRIL(u"ࠧ࠴࠷࠳࠴ࠥࡱࡢࡱࡵࠪ႒"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨ࠶࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ႓"),zDSw8LCxMQyraeXhojIWKmU(u"ࠩ࠷࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ႔"),n6JjFHfmydIaLut(u"ࠪ࠹࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭႕"),VzO1gCHmjZ2ebRIL(u"ࠫ࠻࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ႖"),NupI74tJCzYXmles9SbR6(u"ࠬ࠽࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ႗"),YZXtBgvUPoM5sb(u"࠭࠸࠱࠲࠳ࠤࡰࡨࡰࡴࠩ႘"),RRbvqditj184m3(u"ࠧ࠺࠲࠳࠴ࠥࡱࡢࡱࡵࠪ႙"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨ࠳࠳࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႚ"),KJLkQsqSHMR1Np2(u"ࠩ࠴࠵࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ႛ"),iiauUxMktNW5X(u"ࠪ࠵࠷࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႜ"),i80mE7lHUwVk(u"ࠫ࠾࠿࠹࠺࠻ࠣ࡯ࡧࡶࡳࠨႝ")]
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3(iI7tuF0nEQoR(u"ࠬอฮหำࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠣห้๋ๆศีหอࠬ႞"),items)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==-ggtuNcvTn3HQ7SpE2(u"࠳᎖"): return
		H43svmuKOrRD2APk6w51hVGjabxiTt = str(items[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc][:-iiauUxMktNW5X(u"࠸᎗")])
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ne7wF4gSTRZo(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮูเ๊ๅ๋ࠢฮาี๊ะࠢิๆ๊ࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࡢ࡮࡝ࡰࠪ႟")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+H43svmuKOrRD2APk6w51hVGjabxiTt+TeYukOUW7i5NBM926DCjaAn0(u"ࠧࠡ࡭ࡥࡴࡸ࠭Ⴀ")+GGy0cQe765nPYZ9E8Th)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬႡ"),H43svmuKOrRD2APk6w51hVGjabxiTt)
	return
def iuSfa9V3vEjBgWRlCKILbzDpw(Ayw8bscToPaX29HMBS=yrcbRSFswvAfEdIWVj):
	LLwVRgidmetPb = UqjvYNdPnIueDXbZW9caHSCt10w()
	RDL5wSZqKT = ggtuNcvTn3HQ7SpE2(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไࠣ๎฾๋ไࠨႢ") if LLwVRgidmetPb else n6JjFHfmydIaLut(u"ࠪห้ะิ฻์็ࠤฬ๊ไศฯๅࠤ๊ะ่ใใࠪႣ")
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႤ"),IXE6voNmrb182AyQ(u"ࠬิั้ฮࠪႥ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ล๋ไสๅࠬႦ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧหึ฽๎้࠭Ⴇ"),e1nNXbPrBVDZw,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+RDL5wSZqKT+GGy0cQe765nPYZ9E8Th+okfdjS4RmM+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสอ฻็ࠤ่๎ฯ๋ࠢฦ์ฯ๎ๅศฬํ็๏อ๋ࠠไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦวๅๆสั็ࠦ࠮࠯ࠢศ้ฬࠦศฺัࠣห๋ะ็ศรࠣห้็๊ะ์๋ࠤฬ๊อศๆํࠤอษใๆๆ๊ࠤ࠳࠴ࠠฤ๊ࠣฬ฾ีࠠศๆ้ๆึูࠦๅ๋ࠣึึࠦࠢหฮส์ืࠦลๅ๋ࠣห้๊วฮไࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤสฺ๊ศรࠣห้ะิ฻์็ࠤฬ๊ไศฯๅࠤออไ็ไิࠤ฾๊้ࠡิิࠤࠧห๊ใษไࠤฬ๊แ๋ัํ์ࠧࠦ࠮࠯๋ࠢว๏฼วࠡ็่็๋ࠦวๅษึฮๆอฯส่๊ࠢࠥะฺ๋์ิࠤฯืส๋ส้ࠣาะ่๋ษอࠤฬ๊โ้ษษ้ࠥ࠴࠮๊ࠡัหฺฯࠠหำอ๎อࠦอๅไสฮࠥอไๆี็ื้อสࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅ๊ࠢิ์ࠦวๅ๊฻๎ๆฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨႨ"))
	if JlbGIYdQZkvtqjmR5r7==jxCVeKSLb9rGDOl0Qtw6: DD2fKSgreiUOPQYd0c8ba = oKew16fsvuV8.executeJSONRPC(iiLyoNwGbH03DIXhAkZn(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞ࡡࢂࢃࠧႩ"))
	elif JlbGIYdQZkvtqjmR5r7==dNx9DVCtafk4r: DD2fKSgreiUOPQYd0c8ba = oKew16fsvuV8.executeJSONRPC(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟࠶ࡣࡽࡾࠩႪ"))
	if JlbGIYdQZkvtqjmR5r7 in [jxCVeKSLb9rGDOl0Qtw6,dNx9DVCtafk4r]:
		if BarIC3eR9bS(u"ࠫࡹࡸࡵࡦࠩႫ") in str(DD2fKSgreiUOPQYd0c8ba): tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,BarIC3eR9bS(u"ࠬะๅหࠢส่฾๋ไ๋หࠣฬ๋าวฮࠩႬ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ไๅลึๅࠥอไฺ็็๎ฮࠦแีๆอࠫႭ"))
	return
def XXDAVkhr6iZKmEv():
	url = wAcHkmPB8a.SITESURLS[Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡓࡇࡏࡉࡆ࡙ࡅࡔࠩႮ")][DWgX6JfF3SnlsQwtN1cvGk8L(u"࠴᎘")]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,FAwWlRJg0UkN1(u"ࠨࡉࡈࡘࠬႯ"),url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡎࡔࡓࡕࡃࡏࡐࡤࡕࡌࡅࡡࡕࡉࡑࡋࡁࡔࡇ࠰࠵ࡸࡺࠧႰ"))
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	k3Vt7bYx64IXQRDKp1vMqJOUBL8 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࠪࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠯ࠬࡂ࠭࠳ࢀࡩࡱࠤࠪႱ"),jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	k3Vt7bYx64IXQRDKp1vMqJOUBL8 = sorted(k3Vt7bYx64IXQRDKp1vMqJOUBL8,reverse=w8Ui6RsVhSPrqHfO4)
	EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3(MlTVLBZ92kzorIq1Yw(u"ࠫฬิสาࠢส่ส฻ฯศำࠣห้ึ๊ࠡฬิ๎ิࠦสฬสํฮ์࠭Ⴒ"),k3Vt7bYx64IXQRDKp1vMqJOUBL8)
	if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc>=iI7tuF0nEQoR(u"࠵᎙"):
		nnbeuhcVmav = url.rsplit(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࠵ࠧႳ"),q2qPkMFpR1G86dEAKXHivor9N(u"࠷᎚"))[GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠰᎛")]+ggtuNcvTn3HQ7SpE2(u"࠭࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠧႴ")+k3Vt7bYx64IXQRDKp1vMqJOUBL8[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧ࠯ࡼ࡬ࡴࠬႵ")
		succeeded = tQWY8jTOlUgcCzSEDpyF(ne7wF4gSTRZo(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭Ⴖ"),nnbeuhcVmav,w8Ui6RsVhSPrqHfO4)
		if succeeded:
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭Ⴗ"),gby0BnUuTNFk)
			PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"ࠪฮ๊ࠦสฬสํฮࠥหีะษิࠤ็ี๊ๆࠢ็่อืๆศ็ฯࠤ࠳࠴ࠠๅๅ้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠฤ๊อ์๊อส๋ๅํหࠥฮสฮัํฯࠥาๅ๋฻ࠣห้ฮัศ็ฯࠤออำหะาห๊ࠦยฯำࠣษฺีวา่ࠢฮํ็ัࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣษ๏่วโࠢส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็๋ีอࠠศๆหี๋อๅอࠢยࠥࠦ࠭Ⴘ"))
			if PpQu9EkGTxa: N8zQWwifyKGJbOVprhl4(NupI74tJCzYXmles9SbR6(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩႹ"),w8Ui6RsVhSPrqHfO4,w8Ui6RsVhSPrqHfO4)
	return
def QY31epUBWow56Njb8zAOaLCSFsyt():
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iI7tuF0nEQoR(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥํะศࠢสู่๊อࠡี๋ๅࠥ๐ำษสࠣฮาี๊ฬࠢไ์ึ๐ࠠๅฮ่๎฾ู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡ็ิ์ึ่ࠦใฬ้ࠣ฾๐ๆࠨႺ"))
	if PpQu9EkGTxa:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(IXE6voNmrb182AyQ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫႻ"),gby0BnUuTNFk)
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(OUFxZPuXDoGAbRz(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧႼ"),gby0BnUuTNFk)
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬႽ"),gby0BnUuTNFk)
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(IXE6voNmrb182AyQ(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪႾ"),gby0BnUuTNFk)
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(i80mE7lHUwVk(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬႿ"),gby0BnUuTNFk)
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,NupI74tJCzYXmles9SbR6(u"ࠫฯ๋ࠠๆีะࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠศๆัหฺฯࠠษ๊ๅฮࠥาไษࠢส่ฯำฯ๋อสฮࠥ࠴࠮๊ࠡึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอะอะ์ฮࠤ์ึ็ࠡษ็ษ฾ีวะษอࠤ࠳࠴้ࠠลํฺฬࠦสฮัํฯࠥ๎ุศศไࠤฬ๊ศา่ส้ัࠦวๅฬํࠤฯ฿สๆัࠣ฽้๏ࠠศๆ๋ๆฯ࠭Ⴠ"))
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def MdOqL8p7EvkZl2PxiTn():
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪჁ"),MlTVLBZ92kzorIq1Yw(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩჂ"))
	RRFCDEHdLj = LzVS3hOHQ6yfWtquRnbeC7l(yrcbRSFswvAfEdIWVj)
	hiVMTmk6Zxj7CUdBb8nF5oKDI = okfdjS4RmM
	qqioEWLsDh = bKN9diGf8nmgecQPEqUzHRpoDuaO+zDSw8LCxMQyraeXhojIWKmU(u"ࠧࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣࠫჃ")+GGy0cQe765nPYZ9E8Th
	dlWEBqsy9kFVbt8ezUI5a1nxX = okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬჄ")+GGy0cQe765nPYZ9E8Th+q2qPkMFpR1G86dEAKXHivor9N(u"ࠩ࡟ࡲࡡࡴࠧჅ")
	for id,k2EpeoX7YHr,IqrdX3A6BVkeFhpgu5nWbPf,jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB,reason in reversed(RRFCDEHdLj):
		if id==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࠴ࠬ჆"):
			pVw0rTSl5HtcN6Qk3mvuRKLio,GLK9WMOjARXp51J68kl4tb0en = jSEzXFL5y01pYgdrZUJKulC74Reo.split(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡡࡴ࠻࠼ࠩჇ"))
			continue
		if hiVMTmk6Zxj7CUdBb8nF5oKDI!=okfdjS4RmM: hiVMTmk6Zxj7CUdBb8nF5oKDI += dlWEBqsy9kFVbt8ezUI5a1nxX
		GThjqYb326ip1LcsD = mmbcsf2pd7gyjzreB(u"ࠬࡡࡒࡕࡎࡠࠫ჈")+bKN9diGf8nmgecQPEqUzHRpoDuaO+id+i80mE7lHUwVk(u"࠭ࠠ࠻ࠢࠪ჉")+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ჊")+GGy0cQe765nPYZ9E8Th+IqrdX3A6BVkeFhpgu5nWbPf
		fkAEpsvyhbeHlMtgr1nXNauO07CKZm = iiLyoNwGbH03DIXhAkZn(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ჋")+bKN9diGf8nmgecQPEqUzHRpoDuaO+KJLkQsqSHMR1Np2(u"ࠩส่ั๎วษࠢ࠽ࠤࠬ჌")+GGy0cQe765nPYZ9E8Th+jSEzXFL5y01pYgdrZUJKulC74Reo
		dt4hy7ZRUsEwa = OUFxZPuXDoGAbRz(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩჍ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫฬ๊ฮุลࠣ࠾ࠥ࠭჎")+GGy0cQe765nPYZ9E8Th+l0lLk63Fj5YqivAJIuB
		A63b1YhdfEBHTaQSqo0jWtzeM = n6JjFHfmydIaLut(u"ࠬࡢ࡮࡜ࡔࡗࡐࡢ࠭჏")+bKN9diGf8nmgecQPEqUzHRpoDuaO+i80mE7lHUwVk(u"࠭วๅีหฬࠥࡀࠠࠨა")+GGy0cQe765nPYZ9E8Th+reason
		hiVMTmk6Zxj7CUdBb8nF5oKDI += GThjqYb326ip1LcsD+fkAEpsvyhbeHlMtgr1nXNauO07CKZm+okfdjS4RmM+qqioEWLsDh+okfdjS4RmM+dt4hy7ZRUsEwa+A63b1YhdfEBHTaQSqo0jWtzeM+okfdjS4RmM
	sbqP27kMUtTxS0dyYO(VzO1gCHmjZ2ebRIL(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ბ"),GLK9WMOjARXp51J68kl4tb0en,hiVMTmk6Zxj7CUdBb8nF5oKDI,MlTVLBZ92kzorIq1Yw(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩგ"))
	return
def Oo6y58XLMmUTGq(file):
	if file==U24naHzCgdv7wWF: M56hvy1luK78UasYzDtEqJ = MlTVLBZ92kzorIq1Yw(u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩდ")
	elif file==sTZKJYrgqmkxtvpP: M56hvy1luK78UasYzDtEqJ = KJLkQsqSHMR1Np2(u"ࠪๆํอฦๆࠢลาึࠦวๅใํำ๏๎็ศฬࠪე")
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(nJF7oflOk6cLGSAey(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫვ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๋ࠬำฮࠩზ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ลึๆสัࠬთ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧฯำ๋ะࠬი"),e1nNXbPrBVDZw,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨ้็ࠤฯื๊ะࠢศู้ออࠡ็็ๅࠥ࠭კ")+M56hvy1luK78UasYzDtEqJ+VzO1gCHmjZ2ebRIL(u"ࠩࠣว๊ࠦสา์าࠤู๊อࠡษ็้้็ࠠภࠩლ"))
	if JlbGIYdQZkvtqjmR5r7==zDSw8LCxMQyraeXhojIWKmU(u"࠱᎜"):
		if bCoOHfPdMryRgauz0IVpth.path.exists(file):
			try: bCoOHfPdMryRgauz0IVpth.remove(file)
			except: pass
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠪฮ๊ࠦๅิฯ้้ࠣ็ࠠࠨმ")+M56hvy1luK78UasYzDtEqJ)
	elif JlbGIYdQZkvtqjmR5r7==sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠳᎝"):
		data = nLva0Z9oCXSR2bc4WmspwGEO(file)
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫნ")+M56hvy1luK78UasYzDtEqJ)
	return
def sshedVIknBYMRcF9L8wi7HzuSEWq6T():
	if h4ETRzHBcxIbW<nJF7oflOk6cLGSAey(u"࠴࠼᎞"):
		H7fCeh95oEyapvUl4itZDm2Njdx6z = NupI74tJCzYXmles9SbR6(u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨო")+str(h4ETRzHBcxIbW)+n6JjFHfmydIaLut(u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧპ")
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
		return
	xxwfRPaC2QvI = oKew16fsvuV8.executeJSONRPC(OUFxZPuXDoGAbRz(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪჟ"))
	CCLxuVfgQ54G7tXe = zkOFlha1KsAoNrVCwPSRt4c([iiauUxMktNW5X(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧრ")])
	zRpWtZeDEKClrd,byr5VoYHRxflLTQ8pdN,vvJZQd2S9X,kkDAR6pbUVoaf5FeLWyqIH,PozDLp4FYcNS5M1f23QRVmJwK,StDVNT5MliJCb3g74hKE2RkPQuA,RNleB9M0oLwhZbUcD4g3j7 = CCLxuVfgQ54G7tXe[Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨს")]
	if zRpWtZeDEKClrd or VzO1gCHmjZ2ebRIL(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩტ") not in str(xxwfRPaC2QvI):
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,RRbvqditj184m3(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩუ"))
		GGinQY9gb7uy8VeIrxH5 = zpg1Sr387t()
		if not GGinQY9gb7uy8VeIrxH5: return
	pIahvX6fULC4gm8qoPnJ9VMyEclW(w8Ui6RsVhSPrqHfO4)
	return
def pIahvX6fULC4gm8qoPnJ9VMyEclW(showDialogs=w8Ui6RsVhSPrqHfO4):
	xxwfRPaC2QvI = oKew16fsvuV8.executeJSONRPC(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨფ"))
	if NupI74tJCzYXmles9SbR6(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬქ") not in str(xxwfRPaC2QvI):
		if showDialogs:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iI7tuF0nEQoR(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬღ"))
		return
	Rq6M3YcWoD7LzavweugijdA = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡣࡧࡨࡴࡴࡳࠨყ"),BarIC3eR9bS(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨშ"),MlTVLBZ92kzorIq1Yw(u"ࠪ࠻࠷࠶ࡰࠨჩ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬც"))
	if not bCoOHfPdMryRgauz0IVpth.path.exists(Rq6M3YcWoD7LzavweugijdA): return
	zdXhftGwka4WTRjsc6p3E8LgAm5v = open(Rq6M3YcWoD7LzavweugijdA,iI7tuF0nEQoR(u"ࠬࡸࡢࠨძ")).read()
	if nqkybtoMBH: zdXhftGwka4WTRjsc6p3E8LgAm5v = zdXhftGwka4WTRjsc6p3E8LgAm5v.decode(JJQFjSIlALchiMzG9)
	wuTKGFMDy64Brv7CV9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠨ࡝ࡦ࠮࠰ࡡࡪࠫ࠭࡞ࡧ࠯࠮࠲ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭წ"),zdXhftGwka4WTRjsc6p3E8LgAm5v,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	bvUdBR2hGfcIxr8pqFAYLZTHKCP3,cK3UiNZL5pJdMb = wuTKGFMDy64Brv7CV9[xn867tCVlscY4qbWZfh]
	iiwVUAbXvpDJ9ucO6H3RaQheZf = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨჭ")+bvUdBR2hGfcIxr8pqFAYLZTHKCP3+q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࠮ࠪხ")+cK3UiNZL5pJdMb+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫჯ")
	if showDialogs:
		ilqJpYyN1Eo9m = oKew16fsvuV8.getInfoLabel(BarIC3eR9bS(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡖࡪࡧࡺࡱࡴࡪࡥࠨჰ"))
		if ilqJpYyN1Eo9m==iiLyoNwGbH03DIXhAkZn(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧჱ"): KX6JTBi2oWVU = nJF7oflOk6cLGSAey(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬჲ")
		elif ilqJpYyN1Eo9m==iiauUxMktNW5X(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬჳ"): KX6JTBi2oWVU = nJF7oflOk6cLGSAey(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬჴ")
		else: KX6JTBi2oWVU = iiLyoNwGbH03DIXhAkZn(u"ࠨไ๋หห๋ࠠฤะิํࠬჵ")
		JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(iiauUxMktNW5X(u"ࠩࡦࡩࡳࡺࡥࡳࠩჶ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪๆํอฦๆࠢฦาึ๏ࠧჷ"),NupI74tJCzYXmles9SbR6(u"ࠫ็๎วว็ࠣห้้สศสฬࠫჸ"),ne7wF4gSTRZo(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪჹ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ว็ฬࠣัฬ๊๊ศࠢอืฯิฯๆࠢࠪჺ")+KX6JTBi2oWVU,i80mE7lHUwVk(u"ࠧศ่อࠤฬ๊ย็ࠢอืฯิฯๆࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣ์์ึวࠡ็฼๊ฬํࠠศ่ๆࠤฯูสุ์฼ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠษั็ห๋ࠥๆࠡไ๋หห๋ࠠศๆๆฮฬฮษࠡ࠰ࠣ์ศ๐ึศࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ษࠣๅ๏ࠦร๋๋ࠢๆฯࠦสีษฤࠤࡡࡴ࡜࡯ࠢࠪ჻")+bKN9diGf8nmgecQPEqUzHRpoDuaO+KJLkQsqSHMR1Np2(u"ࠨࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࠬჼ")+GGy0cQe765nPYZ9E8Th)
		if JlbGIYdQZkvtqjmR5r7==ne7wF4gSTRZo(u"࠵᎟"): w5JHBNKVQtDfEMAZqvjd = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬჽ")
		elif JlbGIYdQZkvtqjmR5r7==KJLkQsqSHMR1Np2(u"࠷Ꭰ"): w5JHBNKVQtDfEMAZqvjd = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩჾ")
		else: w5JHBNKVQtDfEMAZqvjd = gby0BnUuTNFk
	else:
		ilqJpYyN1Eo9m = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(iiLyoNwGbH03DIXhAkZn(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩჿ"))
		if   ilqJpYyN1Eo9m==gby0BnUuTNFk: JlbGIYdQZkvtqjmR5r7 = i80mE7lHUwVk(u"࠶Ꭱ")
		elif ilqJpYyN1Eo9m==KJLkQsqSHMR1Np2(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨᄀ"): JlbGIYdQZkvtqjmR5r7 = NupI74tJCzYXmles9SbR6(u"࠱Ꭲ")
		elif ilqJpYyN1Eo9m==VzO1gCHmjZ2ebRIL(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬᄁ"): JlbGIYdQZkvtqjmR5r7 = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠳Ꭳ")
		w5JHBNKVQtDfEMAZqvjd = ilqJpYyN1Eo9m
	if   JlbGIYdQZkvtqjmR5r7==MlTVLBZ92kzorIq1Yw(u"࠲Ꭴ"): GhTEK51OIJnDixtpmlb = TeYukOUW7i5NBM926DCjaAn0(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫᄂ")
	elif JlbGIYdQZkvtqjmR5r7==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠴Ꭵ"): GhTEK51OIJnDixtpmlb = nJF7oflOk6cLGSAey(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬᄃ")
	elif JlbGIYdQZkvtqjmR5r7==MlTVLBZ92kzorIq1Yw(u"࠶Ꭶ"): GhTEK51OIJnDixtpmlb = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭ᄄ")
	else: return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(NupI74tJCzYXmles9SbR6(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨᄅ"),w5JHBNKVQtDfEMAZqvjd)
	pZr0q6Fi98k3NXnyfQH = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬᄆ")+GhTEK51OIJnDixtpmlb+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬ࠲ࠧᄇ")+cK3UiNZL5pJdMb+mmbcsf2pd7gyjzreB(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨᄈ")
	j6wCIHqUA2nOSF = zdXhftGwka4WTRjsc6p3E8LgAm5v.replace(iiwVUAbXvpDJ9ucO6H3RaQheZf,pZr0q6Fi98k3NXnyfQH)
	if nqkybtoMBH: j6wCIHqUA2nOSF = j6wCIHqUA2nOSF.encode(JJQFjSIlALchiMzG9)
	open(Rq6M3YcWoD7LzavweugijdA,NupI74tJCzYXmles9SbR6(u"ࠧࡸࡤࠪᄉ")).write(j6wCIHqUA2nOSF)
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨ࠰࡟ࡸࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭ᄊ")+GhTEK51OIJnDixtpmlb+IXE6voNmrb182AyQ(u"ࠩࠣࡡࠬᄋ"))
	if showDialogs: oKew16fsvuV8.executebuiltin(OUFxZPuXDoGAbRz(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩᄌ"))
	return
def iAvq6GUWyOIoZSNQ():
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫอืๆศ็ฯࠤ฾๋วะࠢไ๎์ࠦๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴ࠠฦ็สࠤศ๊ลึัสี่ࠥฯ๋็ࠣ࠲࠳࠴ࠠฤ๊ࠣห๋ะࠠๆ็้์฾ࠦๅ็ࠢสืฯิฯศ็ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯ࠢฦ์๊ࠥฯ๋ๅู้้ࠣไสࠢฦาึ๏ࠠหะุࠤัํวำๅࠣว๋ะ้ࠠๆสࠤฯิีࠡสๅ๎ฮࠦฮๅไࠣห้๊็ࠡ࡞ࡱࡠࡳࠦอศ๊็ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥษ่ࠡษอู้ࠦศศๆ่ฬึ๋ฬࠡๆ่฽ึ็ษࠡีหฬࠥอไๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢไัฺࠦวๅฬะำ๏ัวหࠢส่ว์ࠠภࠩᄍ"))
	if PpQu9EkGTxa==NupI74tJCzYXmles9SbR6(u"࠶Ꭷ"): v2GXgKVoAk8DztPMNIZeyfbTuHpm()
	return
def BxFX7ehown18DEktRIf392():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,RRbvqditj184m3(u"ࠬํะศࠢส่๊๎โฺ่ࠢ฾้่ࠠๆ่ࠣห้๋ีะำࠣ์฿๐ัࠡ็฼ีํ็ࠠๆฬํࠤ๏ืฬฺࠢ็่฾๋ไࠨᄎ"))
	return
def k1knLKAimG():
	GThjqYb326ip1LcsD = bKN9diGf8nmgecQPEqUzHRpoDuaO+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭สฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢࠪᄏ")+GGy0cQe765nPYZ9E8Th
	GThjqYb326ip1LcsD += NupI74tJCzYXmles9SbR6(u"ࠧศๆ่์็฿ࠠฤั้ห์ࠦแ๋้ࠣษา฻วว์ฬࠤ้฿ฯะࠢสู่๐ูสࠢไ๎ࠥอไฺษ็้ࠥะๅࠡฮ่฽์อࠠๆ่ࠣะ๊๐ูࠡษ็ฺ้อฯาࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่็ี๊ๆหࠣ์ฬ๊ฬะ์าอࠥอไฮๅ๋้๏ฯ้ࠠษ็฾๏ืࠠฮๅ๋้๏ฯ้ࠠ็้ࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊ࠦหๆࠢอ้ࠥะ่ฮ์า๋ฬ่ࠦฮีสฬࠥอไๆ฻า่ࠥำำษࠢึ็ฬ์ࠠะ๊็ࠤฬู๊ศๆ่ࠤู้ๆสࠢ࠵࠴࠷࠷้้ࠠํࠤฬ๊ลฮืสส๏ฯࠠศๆฦัิั้ࠠษ็วู๋ไࠡษ็ฮ๏ࠦสๆࠢ฼้้ํวࠡใํࠤฬ๊ำ็๊สฮࠥอไฺึิอࠥอไๆษู๎ฮ࠭ᄐ")
	GThjqYb326ip1LcsD += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+iiLyoNwGbH03DIXhAkZn(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡷ࡭࡯ࡡࡤࡱࡸࡲࡹ࠭ᄑ")+GGy0cQe765nPYZ9E8Th
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = bKN9diGf8nmgecQPEqUzHRpoDuaO+YZXtBgvUPoM5sb(u"ࠩหี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢࠪᄒ")+GGy0cQe765nPYZ9E8Th
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += nJF7oflOk6cLGSAey(u"๋ࠪํูࠦษษิอࠥ฿ๆࠡสิ๊ฬ๋ฬࠡ์๋ๅึࠦๅฺๆ๋้ฬะࠠฮีสฬ๏ฯࠠไอํีฮࠦส่็ࠣะ๊๐ูࠡษ็ุ้๊ๅ๋่้ࠣะ๊ࠠฤ๊ๅหฯࠦวๅื็หฮ่ࠦฤ๊ๅหฯࠦวๅๅึ์ๆ่ࠦศๆัืํ็้ࠠึๆ่ࠥอไใ็ิࠤํษ่ใษอࠤฬ๊โๆำࠣ์ศ๐ึศࠢํ์ๆืࠠาฦํอࠥอไ่ๆส่ࠥ็๊ࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣ์ศ๐ึศࠢไ๎์ࠦสใ๊ํ้๋๊ࠥๅษา๎ࠥ๎็อำํࠤํ็๊่ࠢฦ๎฻อࠠษฯฮࠤํ่ัศรฬࠤฬ๊โาฤ้ࠤํษ๊ืษࠣๅ๏ํࠠศีอาฬืษ๊ࠡอๅฬสไ๊ࠡไ๎์ࠦรใ๊ส่๋ࠥๆิ๊หอ๊ࠥไฤ็ส้ࠥ฿ไ๋๋ࠢว๊๎ัࠡลัี๎ࠦส่็ࠣ็้ࠦๅิๆ่ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ็ๆฮํฮࠠษๆ฽อࠥาวโษࠣื่ืศห๋ࠢ๎ุะฮะ็๊ࠣ฽อๅ๊ࠡํ๊ิ๎าࠡฬะฮࠥฮ๊วหࠣ์๏์ฯ้ิࠣ็ฬา๊ห๋้ࠢำ฻ีࠡใๅ฻๊ࠥรอ้ีอࠥอไ้์้ำํุࠠ࠯ࠢส่๊๎โฺࠢส่ึูๅ๋ࠢ็่อืๆศ็ฯࠤ์๎ࠧᄓ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+ggtuNcvTn3HQ7SpE2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡭ࡶࡵ࡯࡭ࡲࡸࡵ࡭ࡧࡵࠫᄔ")+GGy0cQe765nPYZ9E8Th
	H7fCeh95oEyapvUl4itZDm2Njdx6z = OUFxZPuXDoGAbRz(u"ࠬࡡࡒࡕࡎࡠࠫᄕ")+GThjqYb326ip1LcsD+q2qPkMFpR1G86dEAKXHivor9N(u"࠭࡜࡯࡞ࡱࡠࡳࡡࡒࡕࡎࡠࠫᄖ")+fkAEpsvyhbeHlMtgr1nXNauO07CKZm
	sbqP27kMUtTxS0dyYO(OUFxZPuXDoGAbRz(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᄗ"),gby0BnUuTNFk,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def h7oab3SLi5pUcvusmJqy9EZAgn(EyaNdiZUtzq2rMulW9JL1ITHP3fgC):
	cfby3Jj71rT6IwB05V(rraWHLSwQvPlVROcM5YAJfF7ojh)
	RRFCDEHdLj = LzVS3hOHQ6yfWtquRnbeC7l(EyaNdiZUtzq2rMulW9JL1ITHP3fgC)
	for cAtWCV6Y8koO2wL1z7TS0H4QE in [sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᄘ"),YZXtBgvUPoM5sb(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬᄙ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᄚ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࡟ࡕࡕࠪᄛ")]:
		if cAtWCV6Y8koO2wL1z7TS0H4QE in wAcHkmPB8a.SEND_THESE_EVENTS: wAcHkmPB8a.SEND_THESE_EVENTS.remove(cAtWCV6Y8koO2wL1z7TS0H4QE)
	XTWNueqE1H(zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡊࡏࡏࡃࡗࡍࡔࡔࡓࠨᄜ"))
	id,k2EpeoX7YHr,IqrdX3A6BVkeFhpgu5nWbPf,jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB,reason = RRFCDEHdLj[xn867tCVlscY4qbWZfh]
	pVw0rTSl5HtcN6Qk3mvuRKLio,GLK9WMOjARXp51J68kl4tb0en = jSEzXFL5y01pYgdrZUJKulC74Reo.split(BarIC3eR9bS(u"࠭࡜࡯࠽࠾ࠫᄝ"))
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm,dt4hy7ZRUsEwa,A63b1YhdfEBHTaQSqo0jWtzeM = l0lLk63Fj5YqivAJIuB.split(nJF7oflOk6cLGSAey(u"ࠧ࡝ࡰ࠾࠿ࠬᄞ"))
	VAeiwmYUXJTG20n1y8bELdcZ4 = w8Ui6RsVhSPrqHfO4
	while VAeiwmYUXJTG20n1y8bELdcZ4:
		AQI4lVsLjWXphJKZ2 = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨะิ์ั࠭ᄟ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨᄠ"),MlTVLBZ92kzorIq1Yw(u"ࠪๆฬฬๅสࠢส่ฯฮัฺษอࠫᄡ"),KJLkQsqSHMR1Np2(u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠ࠻ࠢࠣฮอืูࠡล๋ࠤฬ๋ำฮࠢส่อืๆศ็ฯࠫᄢ"),fkAEpsvyhbeHlMtgr1nXNauO07CKZm)
		if AQI4lVsLjWXphJKZ2==VzO1gCHmjZ2ebRIL(u"࠸Ꭸ"): jh1Q8Zg7F0c2E9V = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠬ฿่ะหࠪᄣ"),gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭ᄤ"),dt4hy7ZRUsEwa,iiauUxMktNW5X(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫᄥ"))
		elif AQI4lVsLjWXphJKZ2==Ducd5PRjQXaB9SIN7VrJ1G(u"࠱Ꭹ"): JJ8MfBcExXU()
		else: VAeiwmYUXJTG20n1y8bELdcZ4 = yrcbRSFswvAfEdIWVj
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def So8eYw3anPGiOu9KCxvzy():
	KszlZctk8SWyf()
	RX8xstYNcGUBh3F = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(iiLyoNwGbH03DIXhAkZn(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪᄦ"))
	H7fCeh95oEyapvUl4itZDm2Njdx6z = {}
	H7fCeh95oEyapvUl4itZDm2Njdx6z[BarIC3eR9bS(u"ࠩࡄ࡙࡙ࡕࠧᄧ")] = FAwWlRJg0UkN1(u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩᄨ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[nJF7oflOk6cLGSAey(u"ࠫࡘ࡚ࡏࡑࠩᄩ")] = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫᄪ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧᄫ")] = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨᄬ")+str(C4bRXFx2EHdlUQAmBYi8traW1ojp/DWgX6JfF3SnlsQwtN1cvGk8L(u"࠷࠲Ꭺ"))+iiauUxMktNW5X(u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬᄭ")
	C6CsMR1r2ALzS = H7fCeh95oEyapvUl4itZDm2Njdx6z[RX8xstYNcGUBh3F]
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,IXE6voNmrb182AyQ(u"ࠩๆหูࠦࠧᄮ")+str(C4bRXFx2EHdlUQAmBYi8traW1ojp/KJLkQsqSHMR1Np2(u"࠸࠳Ꭻ"))+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࠤิ่๊ใหࠪᄯ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪᄰ"),MlTVLBZ92kzorIq1Yw(u"ࠬห๊ใษไࠤ่อๅๅࠩᄱ"),C6CsMR1r2ALzS,KJLkQsqSHMR1Np2(u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩᄲ"))
	if JlbGIYdQZkvtqjmR5r7==MlTVLBZ92kzorIq1Yw(u"࠳Ꭼ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = i80mE7lHUwVk(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨᄳ")
	elif JlbGIYdQZkvtqjmR5r7==ne7wF4gSTRZo(u"࠵Ꭽ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡃࡘࡘࡔ࠭ᄴ")
	elif JlbGIYdQZkvtqjmR5r7==iiauUxMktNW5X(u"࠷Ꭾ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = iiauUxMktNW5X(u"ࠩࡖࡘࡔࡖࠧᄵ")
	else: P9vLVatyd4XR5zBKOxDpCjQ60Yuc = gby0BnUuTNFk
	if P9vLVatyd4XR5zBKOxDpCjQ60Yuc:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ne7wF4gSTRZo(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡣࡢࡥ࡫ࡩࠬᄶ"),P9vLVatyd4XR5zBKOxDpCjQ60Yuc)
		TBsfQCewVpOYgHPm0G8XuzJbayD = H7fCeh95oEyapvUl4itZDm2Njdx6z[P9vLVatyd4XR5zBKOxDpCjQ60Yuc]
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TBsfQCewVpOYgHPm0G8XuzJbayD)
	return
def Mlg347zA9xyWtjL1Cowm8IDrNBQ():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = {}
	H7fCeh95oEyapvUl4itZDm2Njdx6z[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡆ࡛ࡔࡐࠩᄷ")] = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪᄸ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[i80mE7lHUwVk(u"࠭ࡁࡔࡍࠪᄹ")] = VzO1gCHmjZ2ebRIL(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫᄺ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[ne7wF4gSTRZo(u"ࠨࡕࡗࡓࡕ࠭ᄻ")] = iI7tuF0nEQoR(u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬᄼ")
	NqO1vKP2JgdXYz = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(mmbcsf2pd7gyjzreB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᄽ"))
	RX8xstYNcGUBh3F = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᄾ"))
	C6CsMR1r2ALzS = H7fCeh95oEyapvUl4itZDm2Njdx6z[RX8xstYNcGUBh3F]+NqO1vKP2JgdXYz
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,ne7wF4gSTRZo(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪᄿ"),i80mE7lHUwVk(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬᅀ"),IXE6voNmrb182AyQ(u"ࠧฦ์ๅหๆࠦใศ็็ࠫᅁ"),C6CsMR1r2ALzS,FAwWlRJg0UkN1(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬᅂ"))
	if JlbGIYdQZkvtqjmR5r7==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠶Ꭿ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = BarIC3eR9bS(u"ࠩࡄࡗࡐ࠭ᅃ")
	elif JlbGIYdQZkvtqjmR5r7==IXE6voNmrb182AyQ(u"࠱Ꮀ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = iiauUxMktNW5X(u"ࠪࡅ࡚࡚ࡏࠨᅄ")
	elif JlbGIYdQZkvtqjmR5r7==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠳Ꮁ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡘ࡚ࡏࡑࠩᅅ")
	if JlbGIYdQZkvtqjmR5r7 in [oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠳Ꮃ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠳Ꮂ")]:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᅆ"),q2qPkMFpR1G86dEAKXHivor9N(u"࠭ำ๋ำไี࠿ࠦࠧᅇ")+wAcHkmPB8a.DNS_SERVERS[jxCVeKSLb9rGDOl0Qtw6],mmbcsf2pd7gyjzreB(u"ࠧิ์ิๅึࡀࠠࠨᅈ")+wAcHkmPB8a.DNS_SERVERS[xn867tCVlscY4qbWZfh],gby0BnUuTNFk,TeYukOUW7i5NBM926DCjaAn0(u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧᅉ"))
		if PpQu9EkGTxa==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠵Ꮄ"): gipVDLXZQ24C = wAcHkmPB8a.DNS_SERVERS[xn867tCVlscY4qbWZfh]
		else: gipVDLXZQ24C = wAcHkmPB8a.DNS_SERVERS[jxCVeKSLb9rGDOl0Qtw6]
	elif JlbGIYdQZkvtqjmR5r7==IXE6voNmrb182AyQ(u"࠷Ꮅ"): gipVDLXZQ24C = gby0BnUuTNFk
	else: P9vLVatyd4XR5zBKOxDpCjQ60Yuc = gby0BnUuTNFk
	if P9vLVatyd4XR5zBKOxDpCjQ60Yuc:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(iiLyoNwGbH03DIXhAkZn(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᅊ"),P9vLVatyd4XR5zBKOxDpCjQ60Yuc)
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᅋ"),gipVDLXZQ24C)
		TBsfQCewVpOYgHPm0G8XuzJbayD = H7fCeh95oEyapvUl4itZDm2Njdx6z[P9vLVatyd4XR5zBKOxDpCjQ60Yuc]+gipVDLXZQ24C
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TBsfQCewVpOYgHPm0G8XuzJbayD)
	return
def UeiZ1rO7MJQmlfH():
	RX8xstYNcGUBh3F = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᅌ"))
	H7fCeh95oEyapvUl4itZDm2Njdx6z = {}
	H7fCeh95oEyapvUl4itZDm2Njdx6z[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡇࡕࡕࡑࠪᅍ")] = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧᅎ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡂࡕࡎࠫᅏ")] = BarIC3eR9bS(u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩᅐ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z[YZXtBgvUPoM5sb(u"ࠩࡖࡘࡔࡖࠧᅑ")] = ggtuNcvTn3HQ7SpE2(u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬᅒ")
	C6CsMR1r2ALzS = H7fCeh95oEyapvUl4itZDm2Njdx6z[RX8xstYNcGUBh3F]
	JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩᅓ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫᅔ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ล๋ไสๅ้ࠥวๆๆࠪᅕ"),C6CsMR1r2ALzS,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪᅖ"))
	if JlbGIYdQZkvtqjmR5r7==nJF7oflOk6cLGSAey(u"࠶Ꮆ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = OUFxZPuXDoGAbRz(u"ࠨࡃࡖࡏࠬᅗ")
	elif JlbGIYdQZkvtqjmR5r7==YZXtBgvUPoM5sb(u"࠱Ꮇ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡄ࡙࡙ࡕࠧᅘ")
	elif JlbGIYdQZkvtqjmR5r7==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠳Ꮈ"): P9vLVatyd4XR5zBKOxDpCjQ60Yuc = MlTVLBZ92kzorIq1Yw(u"ࠪࡗ࡙ࡕࡐࠨᅙ")
	else: P9vLVatyd4XR5zBKOxDpCjQ60Yuc = gby0BnUuTNFk
	if P9vLVatyd4XR5zBKOxDpCjQ60Yuc:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᅚ"),P9vLVatyd4XR5zBKOxDpCjQ60Yuc)
		TBsfQCewVpOYgHPm0G8XuzJbayD = H7fCeh95oEyapvUl4itZDm2Njdx6z[P9vLVatyd4XR5zBKOxDpCjQ60Yuc]
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TBsfQCewVpOYgHPm0G8XuzJbayD)
	return
def bO7kXxGMWdR():
	P7LiIoMa0knNHKdShe8JUFvgD = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(YZXtBgvUPoM5sb(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡣࡸࡸࡴࡹࡣࡳࡣࡳࡩࡷࡹࠧᅛ"))
	if P7LiIoMa0knNHKdShe8JUFvgD==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡓࡕࡑࡓࠫᅜ"): header = NupI74tJCzYXmles9SbR6(u"ࠧหฮส์ืࠦวๅฯฯฬࠥอไฤ๊อ์๊อส๋ๅํࠤ๊ะ่ใใࠪᅝ")
	else: header = zDSw8LCxMQyraeXhojIWKmU(u"ࠨฬฯหํุࠠศๆะะอࠦวๅล๋ฮํ๋วห์ๆ๎๋ࠥแฺๆࠪᅞ")
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩศ๎็อแࠨᅟ"),BarIC3eR9bS(u"ࠪฮๆ฿๊ๅࠩᅠ"),header,KJLkQsqSHMR1Np2(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอ฽ฬ์๊ࠡ็้ࠤฺ๊ใๅหࠣห้ำฬษࠢ࠱࠲ࠥํะศࠢส่าาศࠡ์่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤๆะอࠡษ็ูๆำวห๋ࠢๆึอมห้สࠤ࠳࠴่่ࠠสࠤฯูสุ์฼ࠤศ์ࠠหี่ั๊ࠥไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡล๋ฮํ๋วห์ๆ๎ฬࠦศๆฯส์้ฯࠠหฮส์ืࠦ็ัษࠣห้ำฬษࠢ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอะฬ๎าࠡษ็ััฮࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦฟࠢࠣࠪᅡ"))
	if PpQu9EkGTxa==-YZXtBgvUPoM5sb(u"࠳Ꮉ"): return
	elif PpQu9EkGTxa:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(FAwWlRJg0UkN1(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡣࡸࡸࡴࡹࡣࡳࡣࡳࡩࡷࡹࠧᅢ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡁࡖࡖࡒࠫᅣ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧห็ࠣฮๆ฿๊ๅࠢอะฬ๎าࠡษ็ััฮࠠศๆฦ์ฯ๎ๅศฬํ็๏࠭ᅤ"))
	else:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(iiLyoNwGbH03DIXhAkZn(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡦࡻࡴࡰࡵࡦࡶࡦࡶࡥࡳࡵࠪᅥ"),NupI74tJCzYXmles9SbR6(u"ࠩࡖࡘࡔࡖࠧᅦ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪฮ๊ࠦล๋ไสๅࠥะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋ࠩᅧ"))
	return
def JcbFsjyMSX7():
	P7LiIoMa0knNHKdShe8JUFvgD = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᅨ"))
	if P7LiIoMa0knNHKdShe8JUFvgD==NupI74tJCzYXmles9SbR6(u"࡙ࠬࡔࡐࡒࠪᅩ"): header = IXE6voNmrb182AyQ(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅห๊ๅๅࠬᅪ")
	else: header = ne7wF4gSTRZo(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆใ฼่ࠬᅫ")
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"ࠨวํๆฬ็ࠧᅬ"),OUFxZPuXDoGAbRz(u"ࠩอๅ฾๐ไࠨᅭ"),header,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧᅮ"))
	if PpQu9EkGTxa==-nJF7oflOk6cLGSAey(u"࠴Ꮊ"): return
	elif PpQu9EkGTxa:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(BarIC3eR9bS(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᅯ"),ne7wF4gSTRZo(u"ࠬࡇࡕࡕࡑࠪᅰ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨᅱ"))
	else:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧᅲ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡕࡗࡓࡕ࠭ᅳ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,n6JjFHfmydIaLut(u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫᅴ"))
	return
def nLy53gmGpD1NxduTi():
	qzfmt6c4VSZX0uFbkMQrg = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(OUFxZPuXDoGAbRz(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᅵ"))
	if qzfmt6c4VSZX0uFbkMQrg==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࡘ࡚ࡏࡑࠩᅶ"): header = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬาไษࠢส่็๎วว็้๋ࠣࠦวๅว้ฮึ์สࠡ็อ์็็ࠧᅷ")
	else: header = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ฬๅสࠣห้่่ศศ่ࠤ๊์ࠠศๆศ๊ฯืๆห่ࠢๅ฾๊ࠧᅸ")
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧฦ์ๅหๆ࠭ᅹ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨฬไ฽๏๊ࠧᅺ"),header,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩๅ์ฬฬๅࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฯษุอࠥอไๆฯฯ์อฯࠠๆ็ๆ๊ࠥะฮำ์้๋ฬࠦแ๋ࠢส่ส์สา่อࠤๆ๐ࠠิ์ิๅึอสࠡๆสࠤ๏๎ฬะࠢไ๎์อࠠๆึๆ่ฮࠦออสࠣ࠲࠳ࠦ็ั้ࠣห้฽ั๋ไฬࠤฯูวฺัࠣๅ๏ࠦโาษฤอࠥ๎วิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็้าา่ษห่่ࠣ์ࠠๆ่้ࠣํู่ࠡสา๎้ࠦๅห๊ไีࠥ๎ฺ๋ำ้ࠣาา่ษࠢ࡟ࡲࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅࠢฦ้ࠥห๊ใษไࠤั๊ศࠡษ็ๆํอฦๆ่๊ࠢࠥอไฦ่อี๋ะࠠภࠣࠤࠫᅻ"))
	if PpQu9EkGTxa==-ggtuNcvTn3HQ7SpE2(u"࠵Ꮋ"): return
	elif PpQu9EkGTxa:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(i80mE7lHUwVk(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᅼ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡆ࡛ࡔࡐࠩᅽ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,IXE6voNmrb182AyQ(u"ࠬะๅࠡฬไ฽๏๊ࠠอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็์๏ฮࠧᅾ"))
	else:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(FAwWlRJg0UkN1(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡸࡧࡥࡧࡦࡩࡨࡦࠩᅿ"),iiLyoNwGbH03DIXhAkZn(u"ࠧࡔࡖࡒࡔࠬᆀ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iI7tuF0nEQoR(u"ࠨฬ่ࠤส๐โศใࠣะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊่๋สࠪᆁ"))
	return
def CiO9l3RYXSry74p(fbmZ9V58PCTz):
	if fbmZ9V58PCTz!=gby0BnUuTNFk:
		fbmZ9V58PCTz = ThtMBSPziG0jZr9sHYCKa(fbmZ9V58PCTz)
		fbmZ9V58PCTz = fbmZ9V58PCTz.decode(JJQFjSIlALchiMzG9).encode(JJQFjSIlALchiMzG9)
		FA7pWnT8xtdIRbOlVgemMD4q2 = MlTVLBZ92kzorIq1Yw(u"࠶࠶࠱࠱࠵Ꮌ")
		ttK2pVxeZrvfbH8NmEy9GsIDQFkTU = SxtK1ciEvLXRAWFVfQDOMgBYC.Window(FA7pWnT8xtdIRbOlVgemMD4q2)
		ttK2pVxeZrvfbH8NmEy9GsIDQFkTU.getControl(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠹࠱࠲Ꮍ")).setLabel(fbmZ9V58PCTz)
	return
EEhOCc951y = [
			 IXE6voNmrb182AyQ(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢᆂ")
			,ggtuNcvTn3HQ7SpE2(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭ᆃ")
			,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ᆄ")
			,Ducd5PRjQXaB9SIN7VrJ1G(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧᆅ")
			,RRbvqditj184m3(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧᆆ")
			,NupI74tJCzYXmles9SbR6(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩᆇ")
			,nJF7oflOk6cLGSAey(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧᆈ")+MlTVLBZ92kzorIq1Yw(u"ࠩࠦࠫᆉ")+q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩᆊ")
			,MlTVLBZ92kzorIq1Yw(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧᆋ")
			,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨᆌ")
			,VzO1gCHmjZ2ebRIL(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧᆍ")
			,ggtuNcvTn3HQ7SpE2(u"ࠧ࡟ࡠࡡࡢࡣ࠭ᆎ")
			,BarIC3eR9bS(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ᆏ")
			,BarIC3eR9bS(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬᆐ")
			,i80mE7lHUwVk(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨᆑ")
			]
def cOEjRnbK0k2(sMbhOUmwFS5e):
	if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩᆒ") in sMbhOUmwFS5e and zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᆓ") in sMbhOUmwFS5e: return w8Ui6RsVhSPrqHfO4
	for fbmZ9V58PCTz in EEhOCc951y:
		if fbmZ9V58PCTz in sMbhOUmwFS5e: return w8Ui6RsVhSPrqHfO4
	return yrcbRSFswvAfEdIWVj
def h2RpdNBUFrAK35YsSiJXq61Pxj(data):
	QdcHfV8r2KPt5Ivxmg = TeYukOUW7i5NBM926DCjaAn0(u"࠸Ꮏ") if nqkybtoMBH else iI7tuF0nEQoR(u"࠱࠶Ꮎ")
	data = data.replace(q2qPkMFpR1G86dEAKXHivor9N(u"࠵࠳Ꮐ")*UpN1CezytPO9XoduhxZSD,QdcHfV8r2KPt5Ivxmg*UpN1CezytPO9XoduhxZSD)
	data = data.replace(NupI74tJCzYXmles9SbR6(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬᆔ"),NupI74tJCzYXmles9SbR6(u"ࠧ࠻ࠢࠪᆕ"))
	uWIUplrbFd = gby0BnUuTNFk
	for sMbhOUmwFS5e in data.splitlines():
		lz6gys8C0NbOFa = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iiLyoNwGbH03DIXhAkZn(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᆖ"),sMbhOUmwFS5e,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if lz6gys8C0NbOFa: sMbhOUmwFS5e = sMbhOUmwFS5e.replace(lz6gys8C0NbOFa[xn867tCVlscY4qbWZfh],gby0BnUuTNFk)
		uWIUplrbFd += okfdjS4RmM+sMbhOUmwFS5e
	return uWIUplrbFd
def rqng05yhKlzosteX8BD(RQsCYOIl3KiVE):
	if NupI74tJCzYXmles9SbR6(u"ࠩࡒࡐࡉ࠭ᆗ") in RQsCYOIl3KiVE:
		G2f8TWq97imXRs = G30FNgWuTRO5jlCMoiKBIPnf
		header = zDSw8LCxMQyraeXhojIWKmU(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪᆘ")
	else:
		G2f8TWq97imXRs = gO3wqNsBZFrc2Epi1T0ALDb6WUK5
		header = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫᆙ")
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,header,RRbvqditj184m3(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨᆚ"))
	if PpQu9EkGTxa!=n6JjFHfmydIaLut(u"࠴Ꮑ"): return
	EyB6zIgrGmxYdKl8fW,MDR8lFgdHfhtqAkb = [],i80mE7lHUwVk(u"࠴Ꮒ")
	size,count = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(G2f8TWq97imXRs)
	file = open(G2f8TWq97imXRs,FAwWlRJg0UkN1(u"࠭ࡲࡣࠩᆛ"))
	if size>tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠷࠰࠱࠴࠳࠴Ꮔ"): file.seek(-zDSw8LCxMQyraeXhojIWKmU(u"࠶࠶࠰࠲࠲࠳Ꮓ"),bCoOHfPdMryRgauz0IVpth.SEEK_END)
	data = file.read()
	file.close()
	if nqkybtoMBH: data = data.decode(JJQFjSIlALchiMzG9)
	data = h2RpdNBUFrAK35YsSiJXq61Pxj(data)
	pphu4kvVyHtj7 = data.split(okfdjS4RmM)
	for sMbhOUmwFS5e in reversed(pphu4kvVyHtj7):
		q4WzIU7Erg2TJx = cOEjRnbK0k2(sMbhOUmwFS5e)
		if q4WzIU7Erg2TJx: continue
		sMbhOUmwFS5e = sMbhOUmwFS5e.replace(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩᆜ"),bKN9diGf8nmgecQPEqUzHRpoDuaO+ne7wF4gSTRZo(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᆝ")+GGy0cQe765nPYZ9E8Th)
		sMbhOUmwFS5e = sMbhOUmwFS5e.replace(zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩᆞ"),ne7wF4gSTRZo(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ᆟ")+ggtuNcvTn3HQ7SpE2(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫᆠ")+GGy0cQe765nPYZ9E8Th)
		mvPYXVuZskbWQEJNG07AnhL35Kjzre = gby0BnUuTNFk
		bMsyDBGxYWV0APJZj38zEaCdv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᆡ"),sMbhOUmwFS5e,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if bMsyDBGxYWV0APJZj38zEaCdv:
			sMbhOUmwFS5e = sMbhOUmwFS5e.replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][xn867tCVlscY4qbWZfh],bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6]).replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][dNx9DVCtafk4r],gby0BnUuTNFk)
			mvPYXVuZskbWQEJNG07AnhL35Kjzre = bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6]
		else:
			bMsyDBGxYWV0APJZj38zEaCdv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(MlTVLBZ92kzorIq1Yw(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ᆢ"),sMbhOUmwFS5e,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if bMsyDBGxYWV0APJZj38zEaCdv:
				sMbhOUmwFS5e = sMbhOUmwFS5e.replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6],gby0BnUuTNFk)
				mvPYXVuZskbWQEJNG07AnhL35Kjzre = bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][xn867tCVlscY4qbWZfh]
		if mvPYXVuZskbWQEJNG07AnhL35Kjzre: sMbhOUmwFS5e = sMbhOUmwFS5e.replace(mvPYXVuZskbWQEJNG07AnhL35Kjzre,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+mvPYXVuZskbWQEJNG07AnhL35Kjzre+GGy0cQe765nPYZ9E8Th)
		EyB6zIgrGmxYdKl8fW.append(sMbhOUmwFS5e)
		if len(str(EyB6zIgrGmxYdKl8fW))>BarIC3eR9bS(u"࠵࠱࠳࠳࠴Ꮕ"): break
	EyB6zIgrGmxYdKl8fW = reversed(EyB6zIgrGmxYdKl8fW)
	FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ = okfdjS4RmM.join(EyB6zIgrGmxYdKl8fW)
	sbqP27kMUtTxS0dyYO(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧ࡭ࡧࡩࡸࠬᆣ"),OUFxZPuXDoGAbRz(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬᆤ"),FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ,zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᆥ"))
	return
def KK4YR8pck7WstMhuTPOXHVrG():
	nnWrCxekJ6D2Yg5 = open(gDcYwjhCOs4ltaKqWFnoB,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡶࡧ࠭ᆦ")).read()
	if nqkybtoMBH: nnWrCxekJ6D2Yg5 = nnWrCxekJ6D2Yg5.decode(JJQFjSIlALchiMzG9)
	nnWrCxekJ6D2Yg5 = nnWrCxekJ6D2Yg5.replace(i80mE7lHUwVk(u"ࠫࡡࡺࠧᆧ"),KJLkQsqSHMR1Np2(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧᆨ"))
	CCLxuVfgQ54G7tXe = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧᆩ"),nnWrCxekJ6D2Yg5,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for sMbhOUmwFS5e in CCLxuVfgQ54G7tXe:
		nnWrCxekJ6D2Yg5 = nnWrCxekJ6D2Yg5.replace(sMbhOUmwFS5e,bKN9diGf8nmgecQPEqUzHRpoDuaO+sMbhOUmwFS5e+GGy0cQe765nPYZ9E8Th)
	YNX5nvi2VegTUu(FAwWlRJg0UkN1(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨᆪ"),nnWrCxekJ6D2Yg5)
	return
def n62DFrI1fTPiULoxOJzQ():
	GThjqYb326ip1LcsD = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪᆫ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = BarIC3eR9bS(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ᆬ")
	dt4hy7ZRUsEwa = ggtuNcvTn3HQ7SpE2(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ᆭ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z = GThjqYb326ip1LcsD+KJLkQsqSHMR1Np2(u"ࠫ࠿ࠦࠧᆮ")+fkAEpsvyhbeHlMtgr1nXNauO07CKZm+ggtuNcvTn3HQ7SpE2(u"ࠬࠦ࠮ࠡࠩᆯ")+dt4hy7ZRUsEwa
	sbqP27kMUtTxS0dyYO(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆰ"),e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z,iiauUxMktNW5X(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᆱ"))
	return
def vsXN6oYheWk4r(type,H7fCeh95oEyapvUl4itZDm2Njdx6z,showDialogs=w8Ui6RsVhSPrqHfO4,url=gby0BnUuTNFk,bTh6JaVi1mOoCEeKZ4kS8AWsnl=gby0BnUuTNFk,fbmZ9V58PCTz=gby0BnUuTNFk,FiR80j26cPJoGeDxpsQBut43EXUZ=gby0BnUuTNFk):
	oKgF7GCtMrLX9PVdYU = w8Ui6RsVhSPrqHfO4
	if not wAcHkmPB8a.D9ZNeIiFunAftqWhB8Q:
		if showDialogs:
			Asa6Rruvo2ZifeYjT8kcPgEL = (nJF7oflOk6cLGSAey(u"ࠨษ็ื฼ื࠺ࠨᆲ") in H7fCeh95oEyapvUl4itZDm2Njdx6z and tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩส่๊้ว็࠼ࠪᆳ") in H7fCeh95oEyapvUl4itZDm2Njdx6z and tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪห้๋ไโ࠼ࠪᆴ") in H7fCeh95oEyapvUl4itZDm2Njdx6z and ne7wF4gSTRZo(u"ࠫฬ๊ฮุลࠪᆵ") in H7fCeh95oEyapvUl4itZDm2Njdx6z and mmbcsf2pd7gyjzreB(u"ࠬอไๆืาี࠿࠭ᆶ") in H7fCeh95oEyapvUl4itZDm2Njdx6z)
			if not Asa6Rruvo2ZifeYjT8kcPgEL: oKgF7GCtMrLX9PVdYU = c3iHohf1zAFQjtTV20pPlS(mmbcsf2pd7gyjzreB(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆷ"),gby0BnUuTNFk,gby0BnUuTNFk,n6JjFHfmydIaLut(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫᆸ"),H7fCeh95oEyapvUl4itZDm2Njdx6z.replace(iiLyoNwGbH03DIXhAkZn(u"ࠨ࡞࡟ࡲࠬᆹ"),okfdjS4RmM))
	elif showDialogs:
		H7fCeh95oEyapvUl4itZDm2Njdx6z = FAwWlRJg0UkN1(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩᆺ")
		BiQIFGvWYuzVP = c3iHohf1zAFQjtTV20pPlS(nJF7oflOk6cLGSAey(u"ࠪࡧࡪࡴࡴࡦࡴࠪᆻ"),gby0BnUuTNFk,gby0BnUuTNFk,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᆼ")+iiauUxMktNW5X(u"ࠬࠦࠠ࠲࠱࠸ࠫᆽ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᆾ"))
		EGTdy6KVbQjRig78HB5wzY39aFZOP = c3iHohf1zAFQjtTV20pPlS(iiLyoNwGbH03DIXhAkZn(u"ࠧࡤࡧࡱࡸࡪࡸࠧᆿ"),gby0BnUuTNFk,gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᇀ")+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࠣࠤ࠷࠵࠵ࠨᇁ"),BarIC3eR9bS(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᇂ"))
		cd9vVlXRbNFEpO7x = c3iHohf1zAFQjtTV20pPlS(zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇃ"),gby0BnUuTNFk,gby0BnUuTNFk,n6JjFHfmydIaLut(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬᇄ")+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࠠࠡ࠵࠲࠹ࠬᇅ"),nJF7oflOk6cLGSAey(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᇆ"))
		ooAVtqgTv3dXHwRM9PB6W0EIJ4el = c3iHohf1zAFQjtTV20pPlS(nJF7oflOk6cLGSAey(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇇ"),gby0BnUuTNFk,gby0BnUuTNFk,iiLyoNwGbH03DIXhAkZn(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᇈ")+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࠤࠥ࠺࠯࠶ࠩᇉ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᇊ"))
		oKgF7GCtMrLX9PVdYU = c3iHohf1zAFQjtTV20pPlS(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᇋ"),gby0BnUuTNFk,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᇌ")+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࠡࠢ࠸࠳࠺࠭ᇍ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᇎ"))
	k2EpeoX7YHr = eaSX4yMEPVYHDIAJ(yrcbRSFswvAfEdIWVj)
	GlYmtd5qLnkTeZ = VzO1gCHmjZ2ebRIL(u"ࠩࡄ࡚࠿ࠦࠧᇏ")+k2EpeoX7YHr+KJLkQsqSHMR1Np2(u"ࠪ࠱ࠬᇐ")+type
	OsWlX1aE9Yg = w8Ui6RsVhSPrqHfO4 if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧᇑ") in fbmZ9V58PCTz else yrcbRSFswvAfEdIWVj
	if not oKgF7GCtMrLX9PVdYU:
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨᇒ"))
		return yrcbRSFswvAfEdIWVj
	CwbDciAegHphu2LOTU1 = oKew16fsvuV8.getInfoLabel(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬᇓ"))
	H7fCeh95oEyapvUl4itZDm2Njdx6z += kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭ᇔ")+eQNGiXdboqPt57O+BarIC3eR9bS(u"ࠨࠢ࠽ࡠࡡࡴࠧᇕ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += BarIC3eR9bS(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪᇖ")+k2EpeoX7YHr+nJF7oflOk6cLGSAey(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩᇗ")+czEtQTYp3Hl0VAePNInKuM7kCODmj+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࠥࡀ࡜࡝ࡰࠪᇘ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪᇙ")+CwbDciAegHphu2LOTU1
	JKTRUIfhmnSApPD5cr = mJNpiuFnh2GqT()
	JKTRUIfhmnSApPD5cr = JKTRUIfhmnSApPD5cr.replace(n6JjFHfmydIaLut(u"࠭ࠬ࠭ࠩᇚ"),i80mE7lHUwVk(u"ࠧ࠭ࠩᇛ"))
	JKTRUIfhmnSApPD5cr = IcChbXakUDFLszgpSG2jqem9(JKTRUIfhmnSApPD5cr)
	if JKTRUIfhmnSApPD5cr: H7fCeh95oEyapvUl4itZDm2Njdx6z += mmbcsf2pd7gyjzreB(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪᇜ")+JKTRUIfhmnSApPD5cr
	if url: H7fCeh95oEyapvUl4itZDm2Njdx6z += VzO1gCHmjZ2ebRIL(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ᇝ")+url
	if bTh6JaVi1mOoCEeKZ4kS8AWsnl: H7fCeh95oEyapvUl4itZDm2Njdx6z += GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪᇞ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl
	H7fCeh95oEyapvUl4itZDm2Njdx6z += OUFxZPuXDoGAbRz(u"ࠫࠥࡀ࡜࡝ࡰࠪᇟ")
	if showDialogs: RLfOB3nsqaWXTugJvY(mmbcsf2pd7gyjzreB(u"ࠬาวา์ࠣห้หัิษ็ࠫᇠ"),i80mE7lHUwVk(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨᇡ"))
	if OsWlX1aE9Yg:
		if FAwWlRJg0UkN1(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧᇢ") in fbmZ9V58PCTz: x3lbt6WXeYcfjG9yTpkV = G30FNgWuTRO5jlCMoiKBIPnf
		else: x3lbt6WXeYcfjG9yTpkV = gO3wqNsBZFrc2Epi1T0ALDb6WUK5
		if not bCoOHfPdMryRgauz0IVpth.path.exists(x3lbt6WXeYcfjG9yTpkV):
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiauUxMktNW5X(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ᇣ"))
			return yrcbRSFswvAfEdIWVj
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,RRbvqditj184m3(u"ࠩ࠱ࡠࡹࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡷ࡬ࡪࠦ࡬ࡰࡩࡩ࡭ࡱ࡫ࠧᇤ"))
		EyB6zIgrGmxYdKl8fW,MDR8lFgdHfhtqAkb = [],TeYukOUW7i5NBM926DCjaAn0(u"࠱Ꮖ")
		file = open(x3lbt6WXeYcfjG9yTpkV,VzO1gCHmjZ2ebRIL(u"ࠪࡶࡧ࠭ᇥ"))
		size,count = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(x3lbt6WXeYcfjG9yTpkV)
		if size>Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠳࠵࠵࠶࠰Ꮗ"): file.seek(-Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠳࠵࠵࠶࠰Ꮗ"),bCoOHfPdMryRgauz0IVpth.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(JJQFjSIlALchiMzG9)
		data = h2RpdNBUFrAK35YsSiJXq61Pxj(data)
		pphu4kvVyHtj7 = data.splitlines()
		for sMbhOUmwFS5e in reversed(pphu4kvVyHtj7):
			q4WzIU7Erg2TJx = cOEjRnbK0k2(sMbhOUmwFS5e)
			if q4WzIU7Erg2TJx: continue
			bMsyDBGxYWV0APJZj38zEaCdv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫᇦ"),sMbhOUmwFS5e,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if bMsyDBGxYWV0APJZj38zEaCdv:
				sMbhOUmwFS5e = sMbhOUmwFS5e.replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][xn867tCVlscY4qbWZfh],bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6]).replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][dNx9DVCtafk4r],gby0BnUuTNFk)
			else:
				bMsyDBGxYWV0APJZj38zEaCdv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᇧ"),sMbhOUmwFS5e,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if bMsyDBGxYWV0APJZj38zEaCdv: sMbhOUmwFS5e = sMbhOUmwFS5e.replace(bMsyDBGxYWV0APJZj38zEaCdv[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6],gby0BnUuTNFk)
			EyB6zIgrGmxYdKl8fW.append(sMbhOUmwFS5e)
			if len(str(EyB6zIgrGmxYdKl8fW))>OUFxZPuXDoGAbRz(u"࠵࠹࠶࠶࠰࠱Ꮘ"): break
		EyB6zIgrGmxYdKl8fW = reversed(EyB6zIgrGmxYdKl8fW)
		FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭࡜ࡳ࡞ࡱࠫᇨ").join(EyB6zIgrGmxYdKl8fW)
	elif FiR80j26cPJoGeDxpsQBut43EXUZ: FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ = FiR80j26cPJoGeDxpsQBut43EXUZ
	else: FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ = gby0BnUuTNFk
	url = wAcHkmPB8a.SITESURLS[TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᇩ")][dNx9DVCtafk4r]
	pjBAh5E2XWYmHx = {IXE6voNmrb182AyQ(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩᇪ"):GlYmtd5qLnkTeZ,ggtuNcvTn3HQ7SpE2(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᇫ"):H7fCeh95oEyapvUl4itZDm2Njdx6z,FAwWlRJg0UkN1(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫᇬ"):FIOl5Pu80Ci3BVH1y62dar4oUwWDtQ}
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡕࡕࡓࡕࠩᇭ"),url,pjBAh5E2XWYmHx,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨᇮ"))
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if YZXtBgvUPoM5sb(u"࠭ࡳࡦࡰࡧࡣࡸࡻࡣࡤࡧࡨࡨࡪࡪࠧᇯ") in jS6fQGXeouTB7xKd32ZMy: GGinQY9gb7uy8VeIrxH5 = w8Ui6RsVhSPrqHfO4
	else: GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
	if showDialogs:
		if GGinQY9gb7uy8VeIrxH5:
			RLfOB3nsqaWXTugJvY(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪᇰ"),i80mE7lHUwVk(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩᇱ"))
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨᇲ"),iiLyoNwGbH03DIXhAkZn(u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬᇳ"))
		else:
			RLfOB3nsqaWXTugJvY(ggtuNcvTn3HQ7SpE2(u"้๊ࠫริใࠣๅู๊ࠠศๆศีุอไࠨᇴ"),YZXtBgvUPoM5sb(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭ᇵ"))
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫᇶ"))
	return GGinQY9gb7uy8VeIrxH5
def DFmAwPGCJEieMHOhXQkxN():
	GThjqYb326ip1LcsD = KJLkQsqSHMR1Np2(u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠤࡲ࡫࡮ࡶࠢ࡬ࡸࡪࡳࡳࠡࡶࡲࠤࡦࠦ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠡࡱࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡇࡲࡢࡤ࡬ࡧࠥ࠴࠮ࠡࡑࡵࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡶ࡬ࡴࡽࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡺࡥࡹࡶࠣࡃࠦ࠭ᇷ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = iiauUxMktNW5X(u"ࠨ้็ࠤฯื๊ะࠢอีั๋ษࠡไ๋หห๋ࠠศๆหี๋อๅอࠢศ่๎ࠦไ฻หࠣวำื้ࠡ฼ํีࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษ฽ํวาࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอࠥลࠡࠨᇸ")
	choice = yc8Ph4rFsCIvQbOA(TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡦࡩࡳࡺࡥࡳࠩᇹ"),iI7tuF0nEQoR(u"ࠪาึ๎ฬࠡࡇࡻ࡭ࡹ࠭ᇺ"),mmbcsf2pd7gyjzreB(u"࡙ࠫࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠠหำฯ้ฮ࠭ᇻ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ฿ัษ์ࠣࡅࡷࡧࡢࡪࡥࠪᇼ"),e1nNXbPrBVDZw,GThjqYb326ip1LcsD+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࡜࡯࡞ࡱࠫᇽ")+fkAEpsvyhbeHlMtgr1nXNauO07CKZm)
	if choice in [-ggtuNcvTn3HQ7SpE2(u"࠵Ꮙ"),nJF7oflOk6cLGSAey(u"࠵Ꮚ")]: return
	elif choice==FAwWlRJg0UkN1(u"࠷Ꮛ"):
		import nwToA5cgkt
		nwToA5cgkt.ticqHYuM3y8IZmzoeG6lpfh()
		return
	RRp86EVoG5tsTIQWNHl2KCLSMO = w8Ui6RsVhSPrqHfO4
	while RRp86EVoG5tsTIQWNHl2KCLSMO:
		RRp86EVoG5tsTIQWNHl2KCLSMO = yrcbRSFswvAfEdIWVj
		message = VzO1gCHmjZ2ebRIL(u"ࠧฦาสࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ฿๐ัࠡษ็ะ้ีࠠฦๆ์ࠤศ๐ࠠอๆาࠤะอๆ๋ࠢไ๎์ࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡอ่ࠤอ฿ฯ่ษࠣ฾๏ืࠠศๆั฻ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦลัษ่ࠣํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ้อࠠหฺ๊ี๊ࠥใࠡ࠰࠱ࠤฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦ࠮࠯ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋่ใ฻ࠣห้าฺาษไ๎ࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฬ๊ย็ࠢไฮาࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦฟࠢࠩᇾ")
		choice = yc8Ph4rFsCIvQbOA(KJLkQsqSHMR1Np2(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇿ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬሀ"),KJLkQsqSHMR1Np2(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫሁ"),IXE6voNmrb182AyQ(u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠥหๆอๆํึ๏࠭ሂ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬ฿ฯๆࠢ฻๋ํืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠪሃ"),message,profile=ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫሄ"))
		if choice==kreQUwJis7YmC2yqWtIF09pgjbD(u"࠲Ꮜ"):
			message = ggtuNcvTn3HQ7SpE2(u"ࠧࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡱ࡫ࡴࡵࡧࡵࡷࠥࡺࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡷࡳࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡵ࡮࡭ࡳࠦࡴࡩࡣࡷࠤ࡭ࡧࡶࡦࠢ࡟ࠦࡆࡸࡩࡢ࡮࡟ࠦࠥ࡬࡯࡯ࡶࠣ࠲࠳ࠦࡁ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࡝ࡰࠣࡍ࡫ࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤ࠳࠴ࠠࡕࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦ࡜࡯࡞ࡱࠤࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡱࡳࡼࠦࡴࡰࠢࡲࡴࡪࡴࠠࡵࡪࡨࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡂࠥࠬህ")
			choice = yc8Ph4rFsCIvQbOA(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨሆ"),iI7tuF0nEQoR(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬሇ"),iiauUxMktNW5X(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫለ"),iiauUxMktNW5X(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤ฾ืศ๋ࠩሉ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡁࡳࡣࡥ࡭ࡨࠦࡆࡰࡰࡷࠤࠫࠦࡔࡦࡺࡷࠫሊ"),message,profile=YZXtBgvUPoM5sb(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫላ"))
			if choice==IXE6voNmrb182AyQ(u"࠳Ꮝ"): RRp86EVoG5tsTIQWNHl2KCLSMO = w8Ui6RsVhSPrqHfO4
		if choice==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠳Ꮞ"): luwOqbBJjTv()
	return
def FtuZKfycwIxoer():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,i80mE7lHUwVk(u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭ሌ"))
	return
def xIqTXFYAz1Jgdf6r8tkb3Diw4KZlnS():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = iiauUxMktNW5X(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨል")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def TFEkqojQX2wel0aV8iyDPcpRW5uv1S():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭ሎ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def PxF5CVrnSMLOBg0q():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = VzO1gCHmjZ2ebRIL(u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧሏ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,i80mE7lHUwVk(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ሐ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def hkaHbpoX2SVQRUczLEM():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = iI7tuF0nEQoR(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪሑ")
	sbqP27kMUtTxS0dyYO(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ሒ"),e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z,NupI74tJCzYXmles9SbR6(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪሓ"))
	return
def uOTwtcpegdmLN6P():
	GThjqYb326ip1LcsD = IXE6voNmrb182AyQ(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩሔ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = iiLyoNwGbH03DIXhAkZn(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫሕ")
	dt4hy7ZRUsEwa = VzO1gCHmjZ2ebRIL(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫሖ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,GThjqYb326ip1LcsD,fkAEpsvyhbeHlMtgr1nXNauO07CKZm,dt4hy7ZRUsEwa)
	return
def KszlZctk8SWyf():
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = TeYukOUW7i5NBM926DCjaAn0(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬሗ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡢ࡮࡝ࡰࠪመ") + KJLkQsqSHMR1Np2(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬሙ") + str(Z83rChqtg1oXUjI4YL/zDSw8LCxMQyraeXhojIWKmU(u"࠹࠴Ꮟ")/zDSw8LCxMQyraeXhojIWKmU(u"࠹࠴Ꮟ")/VzO1gCHmjZ2ebRIL(u"࠶࠹Ꮠ")/Ducd5PRjQXaB9SIN7VrJ1G(u"࠸࠶Ꮡ")) + oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࠡึ๊ีࠬሚ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + iiauUxMktNW5X(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧማ") + str(oHkZjQME4V1vhcUFtCPJ/ggtuNcvTn3HQ7SpE2(u"࠼࠰Ꮢ")/ggtuNcvTn3HQ7SpE2(u"࠼࠰Ꮢ")/sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠲࠵Ꮣ")) + TeYukOUW7i5NBM926DCjaAn0(u"ࠩࠣ๎ํ๋ࠧሜ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + NupI74tJCzYXmles9SbR6(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧም") + str(Q3J7xTKDuAUoaPlB/kreQUwJis7YmC2yqWtIF09pgjbD(u"࠷࠲Ꮤ")/kreQUwJis7YmC2yqWtIF09pgjbD(u"࠷࠲Ꮤ")/KJLkQsqSHMR1Np2(u"࠴࠷Ꮥ")) + IXE6voNmrb182AyQ(u"ࠫࠥ๐่ๆࠩሞ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧሟ") + str(DNh1dgpa4BK/n6JjFHfmydIaLut(u"࠹࠴Ꮦ")/n6JjFHfmydIaLut(u"࠹࠴Ꮦ")) + Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࠠิษ฼อࠬሠ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫሡ") + str(cjSzHQn9N4BuIZO0xJ/i80mE7lHUwVk(u"࠺࠵Ꮧ")/i80mE7lHUwVk(u"࠺࠵Ꮧ")) + q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࠢึห฾ฯࠧሢ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + i80mE7lHUwVk(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪሣ") + str(ECtBvFXOLM/ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠻࠶Ꮨ")) + OUFxZPuXDoGAbRz(u"ࠪࠤิ่๊ใหࠪሤ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += okfdjS4RmM + tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭ሥ") + str(rraWHLSwQvPlVROcM5YAJfF7ojh) + ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࠦฯใ์ๅอࠬሦ")
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm += mmbcsf2pd7gyjzreB(u"࠭࡜࡯࡞ࡱࠫሧ") + Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษࠣࠫረ") + str(DNh1dgpa4BK/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")) + q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩሩ") + str(Q3J7xTKDuAUoaPlB/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")/ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠲࠵Ꮪ")) + VzO1gCHmjZ2ebRIL(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨሪ") + str(cjSzHQn9N4BuIZO0xJ/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")) + TeYukOUW7i5NBM926DCjaAn0(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์ࠦࠧራ") + str(ECtBvFXOLM/FAwWlRJg0UkN1(u"࠼࠰Ꮩ")) + NupI74tJCzYXmles9SbR6(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭ሬ") + str(rraWHLSwQvPlVROcM5YAJfF7ojh) + VzO1gCHmjZ2ebRIL(u"ࠬࠦฯใ์ๅอࠬር")
	sbqP27kMUtTxS0dyYO(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡲࡪࡩ࡫ࡸࠬሮ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬሯ"),fkAEpsvyhbeHlMtgr1nXNauO07CKZm,i80mE7lHUwVk(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫሰ"))
	return
def ZwCAKlIWQhD38fxHORezp27YvcE():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = mmbcsf2pd7gyjzreB(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬሱ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def M7NzYHc5WO8ma4oh1pC():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = NupI74tJCzYXmles9SbR6(u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫሲ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def gpSKtR0uC5ZbT9():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = i80mE7lHUwVk(u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨሳ")
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
	return
def MPtqdaVFJCSyTxIDzrwlAhR():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪሴ"))
	IRMxnQpdEFikJw6L7y0(iiLyoNwGbH03DIXhAkZn(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ስ"),w8Ui6RsVhSPrqHfO4)
	return
def QJYnrO0B63t15DEIdgPxAq4R():
	H7fCeh95oEyapvUl4itZDm2Njdx6z  = IXE6voNmrb182AyQ(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩሶ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨሷ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+NupI74tJCzYXmles9SbR6(u"ࠩใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึ࠭ሸ")+GGy0cQe765nPYZ9E8Th+okfdjS4RmM
	H7fCeh95oEyapvUl4itZDm2Njdx6z += VzO1gCHmjZ2ebRIL(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪሹ")
	sbqP27kMUtTxS0dyYO(zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡷ࡯ࡧࡩࡶࠪሺ"),e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z,iI7tuF0nEQoR(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨሻ"))
	H7fCeh95oEyapvUl4itZDm2Njdx6z = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩሼ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ሽ")+GGy0cQe765nPYZ9E8Th
	H7fCeh95oEyapvUl4itZDm2Njdx6z += RRbvqditj184m3(u"ࠨ࡞ࡱࡠࡳ࠭ሾ")+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪሿ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+TeYukOUW7i5NBM926DCjaAn0(u"ฺ้ࠪืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࠬቀ")+GGy0cQe765nPYZ9E8Th
	H7fCeh95oEyapvUl4itZDm2Njdx6z += NupI74tJCzYXmles9SbR6(u"ࠫࡡࡴ࡜࡯ࠩቁ")+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭ቂ")
	H7fCeh95oEyapvUl4itZDm2Njdx6z += MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+nJF7oflOk6cLGSAey(u"࠭วาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํวࠨቃ")+GGy0cQe765nPYZ9E8Th
	sbqP27kMUtTxS0dyYO(zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ቄ"),e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z,RRbvqditj184m3(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫቅ"))
	return
def rnPW4Z1YL5e6SRkoQ8NIfFVOKJT():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩቆ"),KJLkQsqSHMR1Np2(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤึูววๆ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳ࠭ቇ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+iiLyoNwGbH03DIXhAkZn(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠭ቈ")+GGy0cQe765nPYZ9E8Th+i80mE7lHUwVk(u"ࠬࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࠬ቉")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+KJLkQsqSHMR1Np2(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࠬቊ")+GGy0cQe765nPYZ9E8Th)
	return
def jWo6yJ0b42(showDialogs=w8Ui6RsVhSPrqHfO4):
	if not showDialogs: showDialogs = w8Ui6RsVhSPrqHfO4
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡈࡇࡗࠫቋ"),n6JjFHfmydIaLut(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧቌ"),gby0BnUuTNFk,gby0BnUuTNFk,yrcbRSFswvAfEdIWVj,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬቍ"))
	if not ccV0NKHwQpMun6FtZvAi.succeeded:
		RRuCPcTIazWAF0vKtEHDdh = yrcbRSFswvAfEdIWVj
		UJgI4DY2r9oT5c = RQxlZpTwMkW0F8fSIObUt5oDy7c(yrcbRSFswvAfEdIWVj)
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+zDSw8LCxMQyraeXhojIWKmU(u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨ቎")+UJgI4DY2r9oT5c+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡢ࠭቏"))
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ggtuNcvTn3HQ7SpE2(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩቐ"))
	else:
		RRuCPcTIazWAF0vKtEHDdh = w8Ui6RsVhSPrqHfO4
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ggtuNcvTn3HQ7SpE2(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪቑ"))
	if not RRuCPcTIazWAF0vKtEHDdh and showDialogs: mcsLZ970qCN6z38tdyPDHvu4()
	return RRuCPcTIazWAF0vKtEHDdh
def mcsLZ970qCN6z38tdyPDHvu4():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,RRbvqditj184m3(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭ቒ"))
	rK0l49fR73AqijS68()
	return
def JJ8MfBcExXU(fbmZ9V58PCTz=gby0BnUuTNFk):
	OsWlX1aE9Yg = w8Ui6RsVhSPrqHfO4
	if BarIC3eR9bS(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫቓ") not in fbmZ9V58PCTz:
		OsWlX1aE9Yg = yrcbRSFswvAfEdIWVj
		JlbGIYdQZkvtqjmR5r7 = yc8Ph4rFsCIvQbOA(NupI74tJCzYXmles9SbR6(u"ࠩࡦࡩࡳࡺࡥࡳࠩቔ"),YZXtBgvUPoM5sb(u"ࠪาึ๎ฬࠨቕ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠫสืำศๆู้้ࠣไสࠩቖ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬหัิษ็ࠤึูวๅหࠪ቗"),e1nNXbPrBVDZw,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩቘ"))
		if JlbGIYdQZkvtqjmR5r7 in [-KJLkQsqSHMR1Np2(u"࠲Ꮫ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠲Ꮬ")]: return
		elif JlbGIYdQZkvtqjmR5r7==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠴Ꮭ"):
			OsWlX1aE9Yg = w8Ui6RsVhSPrqHfO4
			fbmZ9V58PCTz = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ቙")
	if OsWlX1aE9Yg:
		if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨቚ") not in fbmZ9V58PCTz:
			PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(YZXtBgvUPoM5sb(u"ࠩࡦࡩࡳࡺࡥࡳࠩቛ"),gby0BnUuTNFk,gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪቜ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫቝ"))
			if PpQu9EkGTxa!=lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠵Ꮮ"):
				tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ቞"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ቟"))
				return
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiauUxMktNW5X(u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไฦ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫበ"))
	H7fCeh95oEyapvUl4itZDm2Njdx6z = vRoGedUjt2Ac6pIbufBX8sKy(header=ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩቡ"),source=CC3nOPFMovd72u)
	if not H7fCeh95oEyapvUl4itZDm2Njdx6z: return
	if OsWlX1aE9Yg: type = FAwWlRJg0UkN1(u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪቢ")
	else: type = i80mE7lHUwVk(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫባ")
	GGinQY9gb7uy8VeIrxH5 = vsXN6oYheWk4r(type,H7fCeh95oEyapvUl4itZDm2Njdx6z,w8Ui6RsVhSPrqHfO4,gby0BnUuTNFk,RRbvqditj184m3(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧቤ"),fbmZ9V58PCTz)
	return
def LOSzjpk5Awrv01gx4mU3MyY8KViqaN():
	fbmZ9V58PCTz = mmbcsf2pd7gyjzreB(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩብ")
	sbqP27kMUtTxS0dyYO(zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡲࡪࡩ࡫ࡸࠬቦ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧቧ"),fbmZ9V58PCTz,mmbcsf2pd7gyjzreB(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫቨ"))
	fbmZ9V58PCTz = OUFxZPuXDoGAbRz(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬቩ")
	sbqP27kMUtTxS0dyYO(nJF7oflOk6cLGSAey(u"ࠪࡰࡪ࡬ࡴࠨቪ"),ggtuNcvTn3HQ7SpE2(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩቫ"),fbmZ9V58PCTz,ggtuNcvTn3HQ7SpE2(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨቬ"))
	return
def LVmuDZaTXF6fMkSU17Y():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,BarIC3eR9bS(u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫቭ"))
	gpSKtR0uC5ZbT9()
	return
def V3vqXLS1nHU():
	Lx9uOp0WBisz = {}
	yeAYHl6TokLtp,aNzq5td91wvbHCPeh3kWUSQIniRGM,pBzQb0rePEJ4T62iLDsdWtwFIOxcl = EWdkJfTB1xOsb(yrcbRSFswvAfEdIWVj)
	GThjqYb326ip1LcsD,fkAEpsvyhbeHlMtgr1nXNauO07CKZm,dt4hy7ZRUsEwa,A63b1YhdfEBHTaQSqo0jWtzeM,Z1DyfRaFphS30TsdbV6qxWPcK9t,fbFPVasT1Zx4G,yuA9Qaxkmw = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	GThjqYb326ip1LcsD = rBcdwYZInhgO29jtkFAfGxi7.join(aNzq5td91wvbHCPeh3kWUSQIniRGM)
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = rBcdwYZInhgO29jtkFAfGxi7.join(pBzQb0rePEJ4T62iLDsdWtwFIOxcl)
	PPqQKi3NLtoR,okQJCyRB8Nxrpq6nHmf,cAJum6KfMUlnZq0F = yeAYHl6TokLtp
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1,mihCYbzk2BDv7xULnue1E8VtaF95MA,xWJX0pYFSHq8zjKoDlPhUVNiab in okQJCyRB8Nxrpq6nHmf:
		xWJX0pYFSHq8zjKoDlPhUVNiab = biVjhGCg0v5eEzkHwTrK9FIAtPU2(xWJX0pYFSHq8zjKoDlPhUVNiab)
		xWJX0pYFSHq8zjKoDlPhUVNiab = xWJX0pYFSHq8zjKoDlPhUVNiab.strip(UpN1CezytPO9XoduhxZSD).strip(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࠡ࠰ࠪቮ"))
		wM0bsUyh6NaAtZ = gwiQ59eNbhY2SlLZB7aOpTDdsk1.replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨቯ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡄࡔࡎ࠭ተ"))
		A63b1YhdfEBHTaQSqo0jWtzeM += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+wM0bsUyh6NaAtZ+YZXtBgvUPoM5sb(u"ࠪ࠾ࠥ࠭ቱ")+GGy0cQe765nPYZ9E8Th+xWJX0pYFSHq8zjKoDlPhUVNiab+okfdjS4RmM
		if mihCYbzk2BDv7xULnue1E8VtaF95MA.isdigit(): Lx9uOp0WBisz[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = int(mihCYbzk2BDv7xULnue1E8VtaF95MA)
	OiPAnGugXda0MlFtfbs68JrKmVI1Z,juz3sQXLpGMdFRNUCeahI78JyvWwt,CvEnW5g2dDJLbsZSaB6RrkUfFuNMy3 = list(zip(*okQJCyRB8Nxrpq6nHmf))
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in sorted(C1eYW9FIEvuGlRZki3wrd7Q):
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in OiPAnGugXda0MlFtfbs68JrKmVI1Z:
			A63b1YhdfEBHTaQSqo0jWtzeM += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+gwiQ59eNbhY2SlLZB7aOpTDdsk1+iiauUxMktNW5X(u"ࠫ࠿ࠦࠧቲ")+GGy0cQe765nPYZ9E8Th+ggtuNcvTn3HQ7SpE2(u"๊ࠬวࠡ์๋ะิ࠭ታ")+okfdjS4RmM
			if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in wAcHkmPB8a.non_videos_actions: dt4hy7ZRUsEwa += rBcdwYZInhgO29jtkFAfGxi7+gwiQ59eNbhY2SlLZB7aOpTDdsk1
	for xWJX0pYFSHq8zjKoDlPhUVNiab,MDR8lFgdHfhtqAkb in PPqQKi3NLtoR:
		xWJX0pYFSHq8zjKoDlPhUVNiab = biVjhGCg0v5eEzkHwTrK9FIAtPU2(xWJX0pYFSHq8zjKoDlPhUVNiab)
		Z1DyfRaFphS30TsdbV6qxWPcK9t += xWJX0pYFSHq8zjKoDlPhUVNiab+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭࠺ࠡࠩቴ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+str(MDR8lFgdHfhtqAkb)+GGy0cQe765nPYZ9E8Th+AXmnlSGOyNfW7PxEdv
	GThjqYb326ip1LcsD = GThjqYb326ip1LcsD.strip(UpN1CezytPO9XoduhxZSD)
	fkAEpsvyhbeHlMtgr1nXNauO07CKZm = fkAEpsvyhbeHlMtgr1nXNauO07CKZm.strip(UpN1CezytPO9XoduhxZSD)
	dt4hy7ZRUsEwa = dt4hy7ZRUsEwa.strip(UpN1CezytPO9XoduhxZSD)
	WL32jIcPmMu = GThjqYb326ip1LcsD+ggtuNcvTn3HQ7SpE2(u"ࠧࠡࠢ࠱࠲ࠥࠦࠧት")+fkAEpsvyhbeHlMtgr1nXNauO07CKZm
	hNzjHTqcICbEZRvf0XMV532gJYdyt  = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨ็๋ห็฿ࠠอ์าอฺฺࠥๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่๊ࠡࠪࠥอไฤๅฮีࠥหไ๊ࠢส่ศ่ไࠪࠩቶ")+okfdjS4RmM+mmbcsf2pd7gyjzreB(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๊้ࠥ็็๋่๊ࠢࠥ฿ๆะๅࠣ์้๐ำห่๊ࠢࠥอไษำ้ห๊า้ࠠๆสࠤ๊์ࠠศๆ่์็฿ࠧቷ")+okfdjS4RmM
	hNzjHTqcICbEZRvf0XMV532gJYdyt += MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+WL32jIcPmMu+GGy0cQe765nPYZ9E8Th+ggtuNcvTn3HQ7SpE2(u"ࠪࡠࡳࡢ࡮ࠨቸ")
	hNzjHTqcICbEZRvf0XMV532gJYdyt += MlTVLBZ92kzorIq1Yw(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤ๊์็ศࠢส่อืๆศ็ฯࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋ห๊ࠣࠬืสษหࠣวอาฯ๋ࠫࠪቹ")+okfdjS4RmM+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅ๋ࠢะํีࠠๆึๆ่ฮูࠦ็ัๆࠤศ๎ࠠโ์ࠣห้๋่ใ฻ࠣวํࠦแ๋ࠢส่อืๆศ็ฯࠫቺ")+okfdjS4RmM
	dt4hy7ZRUsEwa = rBcdwYZInhgO29jtkFAfGxi7.join(sorted(dt4hy7ZRUsEwa.split(rBcdwYZInhgO29jtkFAfGxi7)))
	hNzjHTqcICbEZRvf0XMV532gJYdyt += MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+dt4hy7ZRUsEwa+GGy0cQe765nPYZ9E8Th
	mm0he8XZQntiqgEjlR3v,Z7ZEAeVyDvpz3nFXxJ,Dk9gj6GJHbZWEwLOot8vnyf,aQIJyDqwZslCOundEW3m7Uv0 = RRbvqditj184m3(u"࠵Ꮯ"),RRbvqditj184m3(u"࠵Ꮯ"),RRbvqditj184m3(u"࠵Ꮯ"),RRbvqditj184m3(u"࠵Ꮯ")
	all = Lx9uOp0WBisz[nJF7oflOk6cLGSAey(u"࠭ࡁࡍࡎࠪቻ")]
	if NupI74tJCzYXmles9SbR6(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧቼ") in list(Lx9uOp0WBisz.keys()): mm0he8XZQntiqgEjlR3v = Lx9uOp0WBisz[ggtuNcvTn3HQ7SpE2(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨች")]
	if q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪቾ") in list(Lx9uOp0WBisz.keys()): Z7ZEAeVyDvpz3nFXxJ = Lx9uOp0WBisz[GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫቿ")]
	if lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨኀ") in list(Lx9uOp0WBisz.keys()): Dk9gj6GJHbZWEwLOot8vnyf = Lx9uOp0WBisz[BarIC3eR9bS(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩኁ")]
	if YZXtBgvUPoM5sb(u"࠭ࡒࡆࡒࡒࡗࠬኂ") in list(Lx9uOp0WBisz.keys()): aQIJyDqwZslCOundEW3m7Uv0 = Lx9uOp0WBisz[iI7tuF0nEQoR(u"ࠧࡓࡇࡓࡓࡘ࠭ኃ")]
	mq9N3EDf2zkiIpHJTsCdy = all-mm0he8XZQntiqgEjlR3v-Z7ZEAeVyDvpz3nFXxJ-Dk9gj6GJHbZWEwLOot8vnyf-aQIJyDqwZslCOundEW3m7Uv0
	WDxo5FVQtNn7UaTlq6,AFjC3oPiGKkDNn = cAJum6KfMUlnZq0F[xn867tCVlscY4qbWZfh]
	WDxo5FVQtNn7UaTlq6,h5bCspekQf9PVBJNlot0EAjyZX4g = cAJum6KfMUlnZq0F[jxCVeKSLb9rGDOl0Qtw6]
	kZ75KF2gEf6YV0OPzydeDbA1qp = AFjC3oPiGKkDNn-h5bCspekQf9PVBJNlot0EAjyZX4g
	yuA9Qaxkmw += bKN9diGf8nmgecQPEqUzHRpoDuaO+str(h5bCspekQf9PVBJNlot0EAjyZX4g)+GGy0cQe765nPYZ9E8Th+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬኄ")
	yuA9Qaxkmw += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(kZ75KF2gEf6YV0OPzydeDbA1qp)+GGy0cQe765nPYZ9E8Th+MlTVLBZ92kzorIq1Yw(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭ኅ")
	yuA9Qaxkmw += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(AFjC3oPiGKkDNn)+GGy0cQe765nPYZ9E8Th+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫኆ")
	yuA9Qaxkmw += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(len(cAJum6KfMUlnZq0F[n6JjFHfmydIaLut(u"࠸Ꮰ"):]))+GGy0cQe765nPYZ9E8Th+YZXtBgvUPoM5sb(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩኇ")
	for qqXs9KORkeyc,k2EpeoX7YHr in cAJum6KfMUlnZq0F[ne7wF4gSTRZo(u"࠲Ꮱ"):]:
		qqXs9KORkeyc = biVjhGCg0v5eEzkHwTrK9FIAtPU2(qqXs9KORkeyc)
		qqXs9KORkeyc = qqXs9KORkeyc.strip(UpN1CezytPO9XoduhxZSD).strip(i80mE7lHUwVk(u"ࠬࠦ࠮ࠨኈ"))
		yuA9Qaxkmw += qqXs9KORkeyc+KJLkQsqSHMR1Np2(u"࠭࠺ࠡࠩ኉")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+str(k2EpeoX7YHr)+GGy0cQe765nPYZ9E8Th+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࠡࠢࠣࠫኊ")
	fbFPVasT1Zx4G += bKN9diGf8nmgecQPEqUzHRpoDuaO+str(mq9N3EDf2zkiIpHJTsCdy)+GGy0cQe765nPYZ9E8Th+MlTVLBZ92kzorIq1Yw(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭ኋ")
	fbFPVasT1Zx4G += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(mm0he8XZQntiqgEjlR3v)+GGy0cQe765nPYZ9E8Th+KJLkQsqSHMR1Np2(u"ฺ่ࠩออสࠡีํีๆืࠠࡂࡒࡌࠤ࠿ࠦࠧኌ")
	fbFPVasT1Zx4G += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(aQIJyDqwZslCOundEW3m7Uv0)+GGy0cQe765nPYZ9E8Th+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ኍ")
	fbFPVasT1Zx4G += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(Z7ZEAeVyDvpz3nFXxJ)+GGy0cQe765nPYZ9E8Th+nJF7oflOk6cLGSAey(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨ኎")
	fbFPVasT1Zx4G += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(Dk9gj6GJHbZWEwLOot8vnyf)+GGy0cQe765nPYZ9E8Th+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫ኏")
	fbFPVasT1Zx4G += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+str(len(PPqQKi3NLtoR))+GGy0cQe765nPYZ9E8Th+TeYukOUW7i5NBM926DCjaAn0(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭ነ")
	fbFPVasT1Zx4G += iiauUxMktNW5X(u"ࠧ࡝ࡰ࡟ࡲࠬኑ")+Z1DyfRaFphS30TsdbV6qxWPcK9t
	sbqP27kMUtTxS0dyYO(n6JjFHfmydIaLut(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨኒ"),iiLyoNwGbH03DIXhAkZn(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪና"),fbFPVasT1Zx4G,RRbvqditj184m3(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ኔ"))
	sbqP27kMUtTxS0dyYO(IXE6voNmrb182AyQ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫን"),n6JjFHfmydIaLut(u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨኖ"),hNzjHTqcICbEZRvf0XMV532gJYdyt,RRbvqditj184m3(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩኗ"))
	sbqP27kMUtTxS0dyYO(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧ࡭ࡧࡩࡸࠬኘ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣหุะฮะ็อࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪኙ"),A63b1YhdfEBHTaQSqo0jWtzeM,FAwWlRJg0UkN1(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪኚ"))
	return
def KDVAhoUcjsRE74lYTMLfBdk91gvyNG():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = MlTVLBZ92kzorIq1Yw(u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࠬኛ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+iiauUxMktNW5X(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪኜ")+GGy0cQe765nPYZ9E8Th+n6JjFHfmydIaLut(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴࠧኝ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵࠧኞ")+GGy0cQe765nPYZ9E8Th+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ่ࠠา๊ࠤฬ๊ัิษ็อࠥ๎ฺ๋ำ๊ห้ࠥห๋ำ้ࠣํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤฬ๊ศา่ส้ั่ࠦศๆ่ึ๏ีࠠฤ์ูห๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦๅฺๆ๋้ฬะࠠศๆหี๋อๅอࠩኟ")
	sbqP27kMUtTxS0dyYO(ggtuNcvTn3HQ7SpE2(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨአ"),e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬኡ"))
	return
def aH3DdLgITVhzb7pik04xyJM():
	H7fCeh95oEyapvUl4itZDm2Njdx6z = OUFxZPuXDoGAbRz(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨኢ")+okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wAcHkmPB8a.SITESURLS[mmbcsf2pd7gyjzreB(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪኣ")][xn867tCVlscY4qbWZfh]+GGy0cQe765nPYZ9E8Th+FAwWlRJg0UkN1(u"ࠬࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠩኤ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wAcHkmPB8a.SITESURLS[IXE6voNmrb182AyQ(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬእ")][jxCVeKSLb9rGDOl0Qtw6]+GGy0cQe765nPYZ9E8Th
	H7fCeh95oEyapvUl4itZDm2Njdx6z += iiLyoNwGbH03DIXhAkZn(u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼ࠦระ่ส๋ࠥํ่ࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴࠧኦ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wAcHkmPB8a.SITESURLS[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧኧ")][xn867tCVlscY4qbWZfh]+GGy0cQe765nPYZ9E8Th+n6JjFHfmydIaLut(u"ࠩࠣࠤࠥࠦร้ࠢࠣࠤࠥ࠭ከ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wAcHkmPB8a.SITESURLS[RRbvqditj184m3(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩኩ")][jxCVeKSLb9rGDOl0Qtw6]+GGy0cQe765nPYZ9E8Th
	H7fCeh95oEyapvUl4itZDm2Njdx6z += q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํࠧኪ")+okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wAcHkmPB8a.SITESURLS[Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡌࡉࡍࡇࡖࡣࡘࡕࡕࡓࡅࡈࡗࠬካ")][xn867tCVlscY4qbWZfh]+GGy0cQe765nPYZ9E8Th
	sbqP27kMUtTxS0dyYO(i80mE7lHUwVk(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ኬ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠧศๆ่์ฬู่ࠡษ็ีุ๋๊สࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭ክ"),H7fCeh95oEyapvUl4itZDm2Njdx6z,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫኮ"))
	return
def B0diD3JVGq7L(nfNkx8amqou5eOZcMSF23XWdzPLgY):
	oKew16fsvuV8.executebuiltin(YZXtBgvUPoM5sb(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࠨኯ")+nfNkx8amqou5eOZcMSF23XWdzPLgY+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࠭ࠬኰ"), w8Ui6RsVhSPrqHfO4)
	return
def luwOqbBJjTv():
	KCaOHml1tPNASTiqMbRcghu(ne7wF4gSTRZo(u"ࠫࡸࡺ࡯ࡱࠩ኱"))
	oKew16fsvuV8.executebuiltin(VzO1gCHmjZ2ebRIL(u"ࠧࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࡕࡨࡸࡹ࡯࡮ࡨࡵࠬࠦኲ"))
	return
def N1OvkDdy9EMHXP0gCThqU():
	oKew16fsvuV8.executebuiltin(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠭ࠬኳ"), w8Ui6RsVhSPrqHfO4)
	return
def Ll4cuU5AVG():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,IXE6voNmrb182AyQ(u"ࠧๅ็ึั๋ࠥอห๊ํหฯࠦโศศ่อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่็อฦๆหࠣห้ะ๊ࠡฬิ๎ิࠦๅิฯ๊หࠥ๎ไศࠢอำำ๊ࠠฦๆํ๋ฬ่ࠦๅๅ้ࠤออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤศ๎ࠠศีอาิ๋ࠠࠣษ็็๏ฮ่าัࠥࠤํอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡษู฾฼ูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠧኴ"))
	return
def AqPEgXDls8Oo51kad3npxumz():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫኵ"))
	return
def zpg1Sr387t(A1AZDUBW7CKVsbHYx4wJk96Qiyz=nJF7oflOk6cLGSAey(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ኶"),showDialogs=w8Ui6RsVhSPrqHfO4):
	xxwfRPaC2QvI = oKew16fsvuV8.executeJSONRPC(KJLkQsqSHMR1Np2(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭኷"))
	data = FoCsyPaNjhWf.loads(xxwfRPaC2QvI)
	ii7mnAJctHoIV6vZRkXTO5dCyL = data[YZXtBgvUPoM5sb(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫኸ")][i80mE7lHUwVk(u"ࠬࡼࡡ࡭ࡷࡨࠫኹ")]
	if cAIRPFK6boejVU549WzqBGCaJ0r: ii7mnAJctHoIV6vZRkXTO5dCyL = ii7mnAJctHoIV6vZRkXTO5dCyL.encode(JJQFjSIlALchiMzG9)
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,NupI74tJCzYXmles9SbR6(u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫኺ")+ii7mnAJctHoIV6vZRkXTO5dCyL+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩኻ")+A1AZDUBW7CKVsbHYx4wJk96Qiyz+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࠢยࠥࠬኼ"))
		if PpQu9EkGTxa!=iiLyoNwGbH03DIXhAkZn(u"࠲Ꮲ"): return yrcbRSFswvAfEdIWVj
	GGinQY9gb7uy8VeIrxH5,OAK6JCzpNuFtD95,Ll9xM2sHk1yJtDcVS3fUaFwpnvAIE = sfrcxznX1BiOl2ZF8WGYabjE(A1AZDUBW7CKVsbHYx4wJk96Qiyz,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	if GGinQY9gb7uy8VeIrxH5:
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ne7wF4gSTRZo(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫኽ"))
		bV0XGurMKTotw26qY1JWeEm9CZdfa = oKew16fsvuV8.executeJSONRPC(OUFxZPuXDoGAbRz(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧኾ")+A1AZDUBW7CKVsbHYx4wJk96Qiyz+nJF7oflOk6cLGSAey(u"ࠫࠧࢃࡽࠨ኿"))
		GGinQY9gb7uy8VeIrxH5 = w8Ui6RsVhSPrqHfO4 if iiLyoNwGbH03DIXhAkZn(u"ࠬࡕࡋࠨዀ") in bV0XGurMKTotw26qY1JWeEm9CZdfa else yrcbRSFswvAfEdIWVj
		RyfYSek61do5OnQMc.sleep(iiLyoNwGbH03DIXhAkZn(u"࠳Ꮳ"))
		oKew16fsvuV8.executebuiltin(mmbcsf2pd7gyjzreB(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭዁"))
	elif showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩዂ"))
	return GGinQY9gb7uy8VeIrxH5
def rK0l49fR73AqijS68():
	url = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭ዃ")
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡊࡉ࡙࠭ዄ"),url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭ዅ"))
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	adzh3bVUXxcqL0A = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪ዆"),jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	adzh3bVUXxcqL0A = adzh3bVUXxcqL0A[xn867tCVlscY4qbWZfh].split(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࠳ࠧ዇"))[xn867tCVlscY4qbWZfh]
	HHIofNRJCAxKXWZl = str(h4ETRzHBcxIbW)
	A63b1YhdfEBHTaQSqo0jWtzeM = uebroqCELQSJIcVPRz16x2Mv0DmB(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็วำ๐ัࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨወ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+adzh3bVUXxcqL0A+GGy0cQe765nPYZ9E8Th
	A63b1YhdfEBHTaQSqo0jWtzeM += nJF7oflOk6cLGSAey(u"ࠧ࡝ࡰ࡟ࡲࠬዉ")+q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧዊ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+HHIofNRJCAxKXWZl+GGy0cQe765nPYZ9E8Th
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,A63b1YhdfEBHTaQSqo0jWtzeM)
	return
def dgLFMOcKV5lrE9wQCezky1H7NTu():
	dBSD8lQvTYpxc5g6qXmrMtCosi,z1KRIoM4tUye6hwnqTJHGBjYb,JeyVXPiFh3A2ZMB1Q9GwznOC = yrcbRSFswvAfEdIWVj,gby0BnUuTNFk,gby0BnUuTNFk
	L9LSpKwhx2NPeqYdGJQE,ssl8Ej6UOyXdxh0Gp2Zb1CtqIDnVAN,COnpdBgvzGsbYD = yrcbRSFswvAfEdIWVj,gby0BnUuTNFk,gby0BnUuTNFk
	DLP5BmAOa4 = [YZXtBgvUPoM5sb(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧዋ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬዌ"),ne7wF4gSTRZo(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪው")]
	CCLxuVfgQ54G7tXe = zkOFlha1KsAoNrVCwPSRt4c(DLP5BmAOa4)
	for Ym0kMIiBp4dFarGHxs6Svle in DLP5BmAOa4:
		if Ym0kMIiBp4dFarGHxs6Svle not in list(CCLxuVfgQ54G7tXe.keys()): continue
		zRpWtZeDEKClrd,TsXNzW6OARoHj0BeYJC,vmXNf1pAdiK9qlCBHJus5QV7wGEhT,kg9qm6iLTDBo,N8r9P3izbTv,SM8hA7txDZH2f,AOXWQxNpyfsz7kcbMYTdGwIl = CCLxuVfgQ54G7tXe[Ym0kMIiBp4dFarGHxs6Svle]
		if Ym0kMIiBp4dFarGHxs6Svle==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪዎ"):
			L9LSpKwhx2NPeqYdGJQE = zRpWtZeDEKClrd
			ssl8Ej6UOyXdxh0Gp2Zb1CtqIDnVAN = TsXNzW6OARoHj0BeYJC+ggtuNcvTn3HQ7SpE2(u"࠭ࠠࠡࠢࠣࠬࠥ࠭ዏ")+hjtyidLuHrs3(SM8hA7txDZH2f)+iiLyoNwGbH03DIXhAkZn(u"ࠧࠡࠫࠪዐ")
			COnpdBgvzGsbYD = kg9qm6iLTDBo
		elif Ym0kMIiBp4dFarGHxs6Svle==zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪዑ"):
			dBSD8lQvTYpxc5g6qXmrMtCosi = dBSD8lQvTYpxc5g6qXmrMtCosi or zRpWtZeDEKClrd
			z1KRIoM4tUye6hwnqTJHGBjYb += iiauUxMktNW5X(u"ࠩࠣࠤ࠱ࠦࠠࠨዒ")+TsXNzW6OARoHj0BeYJC+KJLkQsqSHMR1Np2(u"ࠪࠤࠥࠦࠠࠩࠢࠪዓ")+hjtyidLuHrs3(SM8hA7txDZH2f)+NupI74tJCzYXmles9SbR6(u"ࠫࠥ࠯ࠧዔ")
			JeyVXPiFh3A2ZMB1Q9GwznOC += mmbcsf2pd7gyjzreB(u"ࠬࠦࠠ࠭ࠢࠣࠫዕ")+kg9qm6iLTDBo
		elif Ym0kMIiBp4dFarGHxs6Svle==MlTVLBZ92kzorIq1Yw(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬዖ"):
			sBIcJ6LAEUPx2 = zRpWtZeDEKClrd
			y9yMFgRHWLsUPVv = TsXNzW6OARoHj0BeYJC+iiLyoNwGbH03DIXhAkZn(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧ዗")+hjtyidLuHrs3(SM8hA7txDZH2f)+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࠢࠬࠫዘ")
			B4syLFfUVoabTtr0ISiqgj = kg9qm6iLTDBo
	z1KRIoM4tUye6hwnqTJHGBjYb = z1KRIoM4tUye6hwnqTJHGBjYb.strip(ne7wF4gSTRZo(u"ࠩࠣࠤ࠱ࠦࠠࠨዙ"))
	JeyVXPiFh3A2ZMB1Q9GwznOC = JeyVXPiFh3A2ZMB1Q9GwznOC.strip(BarIC3eR9bS(u"ࠪࠤࠥ࠲ࠠࠡࠩዚ"))
	CHycMebI24Bi6l3WKwP  = iI7tuF0nEQoR(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩዛ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+COnpdBgvzGsbYD+GGy0cQe765nPYZ9E8Th
	CHycMebI24Bi6l3WKwP += okfdjS4RmM+ne7wF4gSTRZo(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧዜ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+ssl8Ej6UOyXdxh0Gp2Zb1CtqIDnVAN+GGy0cQe765nPYZ9E8Th
	CHycMebI24Bi6l3WKwP += RRbvqditj184m3(u"࠭࡜࡯࡞ࡱࠫዝ")+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬዞ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+JeyVXPiFh3A2ZMB1Q9GwznOC+GGy0cQe765nPYZ9E8Th
	CHycMebI24Bi6l3WKwP += okfdjS4RmM+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪዟ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+z1KRIoM4tUye6hwnqTJHGBjYb+GGy0cQe765nPYZ9E8Th
	CHycMebI24Bi6l3WKwP += kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩ࡟ࡲࡡࡴࠧዠ")+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧዡ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+B4syLFfUVoabTtr0ISiqgj+GGy0cQe765nPYZ9E8Th
	CHycMebI24Bi6l3WKwP += okfdjS4RmM+n6JjFHfmydIaLut(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬዢ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+y9yMFgRHWLsUPVv+GGy0cQe765nPYZ9E8Th
	zRpWtZeDEKClrd = L9LSpKwhx2NPeqYdGJQE or dBSD8lQvTYpxc5g6qXmrMtCosi
	if zRpWtZeDEKClrd:
		header = KJLkQsqSHMR1Np2(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧዣ")
		FFrmNLTeVf5HnKwgcIXqa = Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧዤ")
	else:
		header = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨዥ")
		FFrmNLTeVf5HnKwgcIXqa = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪዦ")
	Fl8ShODyiRL = iiLyoNwGbH03DIXhAkZn(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪዧ")
	Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F = CHycMebI24Bi6l3WKwP+YZXtBgvUPoM5sb(u"ࠪࡠࡳࡢ࡮ࠨየ")+FFrmNLTeVf5HnKwgcIXqa+KJLkQsqSHMR1Np2(u"ࠫࡡࡴ࡜࡯ࠩዩ")+Fl8ShODyiRL
	sbqP27kMUtTxS0dyYO(ggtuNcvTn3HQ7SpE2(u"ࠬࡸࡩࡨࡪࡷࠫዪ"),header,Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,iiauUxMktNW5X(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩያ"))
	return zRpWtZeDEKClrd
def tQWY8jTOlUgcCzSEDpyF(Ym0kMIiBp4dFarGHxs6Svle,AOXWQxNpyfsz7kcbMYTdGwIl,showDialogs):
	GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฼ฺู้่้ࠣหึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦไไ์ࠣ๎ฯ๋ࠠหอห๎ฯํฺࠠๆ์ࠤ่๎ฯ๋ࠢ࠱ࠤฬ๊ๅๅใࠣๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢส่ว์ࠠภࠣࠪዬ"))
		if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return yrcbRSFswvAfEdIWVj
	q9PoFR4gw0yaQiK = EckxoYzjdgLH0r(AOXWQxNpyfsz7kcbMYTdGwIl,{},showDialogs)
	if q9PoFR4gw0yaQiK:
		m8EyHDqsn4Br = bCoOHfPdMryRgauz0IVpth.path.join(J2J0PpyrD4IMnwadv6YThZeBuqQ5sR,Ym0kMIiBp4dFarGHxs6Svle)
		LamxwbXfkZ6JDoCRlgBIehsEc(m8EyHDqsn4Br,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
		import zipfile as VVIeyCO8qDSvokm,io as tmoMNEcWw0bS32Jl1qd7vynikQU4
		rxDcUuzjhqBWmnZ8opT7IfHLM = tmoMNEcWw0bS32Jl1qd7vynikQU4.BytesIO(q9PoFR4gw0yaQiK)
		try:
			By69F2mq4Cucx = VVIeyCO8qDSvokm.ZipFile(rxDcUuzjhqBWmnZ8opT7IfHLM)
			By69F2mq4Cucx.extractall(J2J0PpyrD4IMnwadv6YThZeBuqQ5sR)
			RyfYSek61do5OnQMc.sleep(jxCVeKSLb9rGDOl0Qtw6)
			oKew16fsvuV8.executebuiltin(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬይ"))
			RyfYSek61do5OnQMc.sleep(jxCVeKSLb9rGDOl0Qtw6)
			GGinQY9gb7uy8VeIrxH5 = XhsgNzVaI0Q41WdKZ2FGmTkyfu97R(Ym0kMIiBp4dFarGHxs6Svle)
		except: GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
	if showDialogs:
		if GGinQY9gb7uy8VeIrxH5: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,IXE6voNmrb182AyQ(u"ࠩอ้ࠥฮๆอษะࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ዮ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,kreQUwJis7YmC2yqWtIF09pgjbD(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨዯ"))
	return GGinQY9gb7uy8VeIrxH5
def IRMxnQpdEFikJw6L7y0(Ym0kMIiBp4dFarGHxs6Svle,showDialogs=w8Ui6RsVhSPrqHfO4):
	if showDialogs==gby0BnUuTNFk: showDialogs = w8Ui6RsVhSPrqHfO4
	FrHyJNvZzDpdRkojgQx4CseUV597 = FG7MISaqyKQ1o83fjw4e6VmB29W5Ul([Ym0kMIiBp4dFarGHxs6Svle])
	ooZYDsfChl,xrvfhDVnp6XYaus5b = FrHyJNvZzDpdRkojgQx4CseUV597[Ym0kMIiBp4dFarGHxs6Svle]
	if xrvfhDVnp6XYaus5b:
		GGinQY9gb7uy8VeIrxH5 = w8Ui6RsVhSPrqHfO4
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ggtuNcvTn3HQ7SpE2(u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭ደ")+Ym0kMIiBp4dFarGHxs6Svle+RRbvqditj184m3(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨዱ"))
	else:
		GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ዲ"),gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,gby0BnUuTNFk+Ym0kMIiBp4dFarGHxs6Svle+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࠡ࡞ࡱࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ๎วๅสิ๊ฬ๋ฬࠡสะหัฯࠠๅ้สࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫዳ"))
		if PpQu9EkGTxa==uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠴Ꮴ"):
			oKew16fsvuV8.executebuiltin(MlTVLBZ92kzorIq1Yw(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨዴ")+Ym0kMIiBp4dFarGHxs6Svle+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࠬࠫድ"))
			RyfYSek61do5OnQMc.sleep(KJLkQsqSHMR1Np2(u"࠵Ꮵ"))
			oKew16fsvuV8.executebuiltin(YZXtBgvUPoM5sb(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪዶ"))
			RyfYSek61do5OnQMc.sleep(VzO1gCHmjZ2ebRIL(u"࠶Ꮶ"))
			while oKew16fsvuV8.getCondVisibility(NupI74tJCzYXmles9SbR6(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨዷ")): RyfYSek61do5OnQMc.sleep(iiLyoNwGbH03DIXhAkZn(u"࠷Ꮷ"))
			GGinQY9gb7uy8VeIrxH5 = XhsgNzVaI0Q41WdKZ2FGmTkyfu97R(Ym0kMIiBp4dFarGHxs6Svle)
			if showDialogs and GGinQY9gb7uy8VeIrxH5: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,TeYukOUW7i5NBM926DCjaAn0(u"ࠬะๅࠡใะูࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬዸ"))
			elif showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨዹ"))
	return GGinQY9gb7uy8VeIrxH5
def JSLmRgwKGdQU(showDialogs):
	if not showDialogs: PpQu9EkGTxa = w8Ui6RsVhSPrqHfO4
	else: PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(BarIC3eR9bS(u"ࠧࡤࡧࡱࡸࡪࡸࠧዺ"),gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiauUxMktNW5X(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤศ์ࠠหู็ฬ๋ࠥๆࠡๅ๋ำ๏ࠦแฮืࠣ์ฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣรࠬዻ"))
	if PpQu9EkGTxa==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠱Ꮸ"):
		oKew16fsvuV8.executebuiltin(iiLyoNwGbH03DIXhAkZn(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬዼ"))
		if showDialogs:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,YZXtBgvUPoM5sb(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪዽ"))
	return
def v2GXgKVoAk8DztPMNIZeyfbTuHpm():
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩዾ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ዿ"))
	rK0l49fR73AqijS68()
	zRpWtZeDEKClrd = dgLFMOcKV5lrE9wQCezky1H7NTu()
	if zRpWtZeDEKClrd:
		TAFLUzpWg63Rf(w8Ui6RsVhSPrqHfO4)
		JSLmRgwKGdQU(w8Ui6RsVhSPrqHfO4)
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def XhsgNzVaI0Q41WdKZ2FGmTkyfu97R(Ym0kMIiBp4dFarGHxs6Svle):
	WjryKiBebavP = oKew16fsvuV8.executeJSONRPC(iiauUxMktNW5X(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩጀ")+Ym0kMIiBp4dFarGHxs6Svle+FAwWlRJg0UkN1(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬጁ"))
	succeeded = w8Ui6RsVhSPrqHfO4 if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡑࡎࠫጂ") in WjryKiBebavP else yrcbRSFswvAfEdIWVj
	return succeeded
def AK7fSFrROa6gd(Ym0kMIiBp4dFarGHxs6Svle):
	WjryKiBebavP = oKew16fsvuV8.executeJSONRPC(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬጃ")+Ym0kMIiBp4dFarGHxs6Svle+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩጄ"))
	succeeded = w8Ui6RsVhSPrqHfO4 if YZXtBgvUPoM5sb(u"ࠫࡔࡑࠧጅ") in WjryKiBebavP else yrcbRSFswvAfEdIWVj
	return succeeded
def sfrcxznX1BiOl2ZF8WGYabjE(Ym0kMIiBp4dFarGHxs6Svle,showDialogs,mKVw9pS7itzq1nZlL2Asc8PvC,CCLxuVfgQ54G7tXe=None):
	PpQu9EkGTxa,succeeded,OAK6JCzpNuFtD95,TsXNzW6OARoHj0BeYJC = w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj,n6JjFHfmydIaLut(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬጆ"),gby0BnUuTNFk
	if not CCLxuVfgQ54G7tXe: CCLxuVfgQ54G7tXe = zkOFlha1KsAoNrVCwPSRt4c([Ym0kMIiBp4dFarGHxs6Svle])
	if Ym0kMIiBp4dFarGHxs6Svle in list(CCLxuVfgQ54G7tXe.keys()):
		zRpWtZeDEKClrd,TsXNzW6OARoHj0BeYJC,vmXNf1pAdiK9qlCBHJus5QV7wGEhT,kg9qm6iLTDBo,N8r9P3izbTv,SM8hA7txDZH2f,AOXWQxNpyfsz7kcbMYTdGwIl = CCLxuVfgQ54G7tXe[Ym0kMIiBp4dFarGHxs6Svle]
		if SM8hA7txDZH2f==KJLkQsqSHMR1Np2(u"࠭ࡧࡰࡱࡧࠫጇ"):
			succeeded,OAK6JCzpNuFtD95 = w8Ui6RsVhSPrqHfO4,TeYukOUW7i5NBM926DCjaAn0(u"ࠧ࡯ࡱࡷ࡬࡮ࡴࡧࠨገ")
			if mKVw9pS7itzq1nZlL2Asc8PvC and showDialogs:
				PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨጉ")+Ym0kMIiBp4dFarGHxs6Svle+iI7tuF0nEQoR(u"ࠩ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห้ࠣึฯࠠฤะิํࠬጊ"))
				if PpQu9EkGTxa:
					succeeded = tQWY8jTOlUgcCzSEDpyF(Ym0kMIiBp4dFarGHxs6Svle,AOXWQxNpyfsz7kcbMYTdGwIl,yrcbRSFswvAfEdIWVj)
					if succeeded:
						OAK6JCzpNuFtD95 = IXE6voNmrb182AyQ(u"ࠪࡶࡪ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨጋ")
						if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆ๊ฯ์ิฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬส฿วะหࠣฮะฮ๊ห้สࡠࡳࡢ࡮ࠨጌ")+Ym0kMIiBp4dFarGHxs6Svle)
					else:
						OAK6JCzpNuFtD95 = i80mE7lHUwVk(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬግ")
						tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ጎ")+Ym0kMIiBp4dFarGHxs6Svle)
		else:
			if showDialogs:
				if SM8hA7txDZH2f==MlTVLBZ92kzorIq1Yw(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩጏ"): H7fCeh95oEyapvUl4itZDm2Njdx6z = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ็อ์็็ษࠨጐ")
				elif SM8hA7txDZH2f==i80mE7lHUwVk(u"ࠩࡲࡰࡩ࠭጑"): H7fCeh95oEyapvUl4itZDm2Njdx6z = TeYukOUW7i5NBM926DCjaAn0(u"ࠪๆิ๐ๅสࠩጒ")
				elif SM8hA7txDZH2f==n6JjFHfmydIaLut(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬጓ"): H7fCeh95oEyapvUl4itZDm2Njdx6z = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬเ๊า่ࠢฯอะษࠨጔ")
				PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭็ั้ࠣห้หึศใฬࠤࠬጕ")+H7fCeh95oEyapvUl4itZDm2Njdx6z+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩ጖")+Ym0kMIiBp4dFarGHxs6Svle)
			if not PpQu9EkGTxa: OAK6JCzpNuFtD95 = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪ጗")
			else:
				if SM8hA7txDZH2f==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫጘ"):
					succeeded = XhsgNzVaI0Q41WdKZ2FGmTkyfu97R(Ym0kMIiBp4dFarGHxs6Svle)
					if succeeded:
						OAK6JCzpNuFtD95 = MlTVLBZ92kzorIq1Yw(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫጙ")
						if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩጚ")+Ym0kMIiBp4dFarGHxs6Svle)
					elif showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ggtuNcvTn3HQ7SpE2(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆศฺฬ็ษࠡ็อ์็็ษࠡ࠰࠱ࠤํ๊ๅࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨጛ")+Ym0kMIiBp4dFarGHxs6Svle)
				elif SM8hA7txDZH2f in [kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭࡯࡭ࡦࠪጜ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨጝ")]:
					succeeded = tQWY8jTOlUgcCzSEDpyF(Ym0kMIiBp4dFarGHxs6Svle,AOXWQxNpyfsz7kcbMYTdGwIl,yrcbRSFswvAfEdIWVj)
					if succeeded:
						if SM8hA7txDZH2f==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡱ࡯ࡨࠬጞ"): OAK6JCzpNuFtD95 = IXE6voNmrb182AyQ(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪጟ")
						elif SM8hA7txDZH2f==IXE6voNmrb182AyQ(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫጠ"): OAK6JCzpNuFtD95 = mmbcsf2pd7gyjzreB(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧጡ")
						TsXNzW6OARoHj0BeYJC = kg9qm6iLTDBo
						if showDialogs:
							if OAK6JCzpNuFtD95==BarIC3eR9bS(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ጢ"): tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪጣ")+Ym0kMIiBp4dFarGHxs6Svle)
							elif OAK6JCzpNuFtD95==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪጤ"): tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,mmbcsf2pd7gyjzreB(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩጥ")+Ym0kMIiBp4dFarGHxs6Svle)
					elif showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬጦ")+Ym0kMIiBp4dFarGHxs6Svle)
	elif showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,q2qPkMFpR1G86dEAKXHivor9N(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨጧ")+Ym0kMIiBp4dFarGHxs6Svle)
	return succeeded,OAK6JCzpNuFtD95,TsXNzW6OARoHj0BeYJC
def N8zQWwifyKGJbOVprhl4(Ym0kMIiBp4dFarGHxs6Svle,showDialogs,l64p7KsJNMEnD):
	Nv9CrIuMzsJW = H6JBPsvmfLRhZI4YzUnebWdXKV8ig.connect(OOcgTBrf9EC32tlhwQPa)
	Nv9CrIuMzsJW.text_factory = str
	MnOPIpuYDZFJ = Nv9CrIuMzsJW.cursor()
	succeeded,ERidftMjIozPbeOrQ07BvkJgx9ypG = w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj
	try:
		i0x1MDIceoB = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ጨ")
		MnOPIpuYDZFJ.execute(KJLkQsqSHMR1Np2(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪጩ")+Ym0kMIiBp4dFarGHxs6Svle+zDSw8LCxMQyraeXhojIWKmU(u"࠭ࠢࠡ࠽ࠪጪ"))
		npRAlrWYXkFuDwga9K031eiho5 = MnOPIpuYDZFJ.fetchall()
		if npRAlrWYXkFuDwga9K031eiho5 and i0x1MDIceoB not in str(npRAlrWYXkFuDwga9K031eiho5): MnOPIpuYDZFJ.execute(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫጫ")+i0x1MDIceoB+KJLkQsqSHMR1Np2(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧጬ")+Ym0kMIiBp4dFarGHxs6Svle+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࠥࠤࡀ࠭ጭ"))
		c6cCVGhQRqysrLY = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ጮ") if cAIRPFK6boejVU549WzqBGCaJ0r else uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪጯ")
		MnOPIpuYDZFJ.execute(DWgX6JfF3SnlsQwtN1cvGk8L(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ጰ")+c6cCVGhQRqysrLY+FAwWlRJg0UkN1(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫጱ")+Ym0kMIiBp4dFarGHxs6Svle+n6JjFHfmydIaLut(u"ࠧࠣࠢ࠾ࠫጲ"))
		npRAlrWYXkFuDwga9K031eiho5 = MnOPIpuYDZFJ.fetchall()
		if npRAlrWYXkFuDwga9K031eiho5:
			if showDialogs: PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,mmbcsf2pd7gyjzreB(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬጳ")+Ym0kMIiBp4dFarGHxs6Svle+mmbcsf2pd7gyjzreB(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩጴ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+VzO1gCHmjZ2ebRIL(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬጵ")+GGy0cQe765nPYZ9E8Th+BarIC3eR9bS(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩጶ"))
			else: PpQu9EkGTxa = jxCVeKSLb9rGDOl0Qtw6
			if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
				ERidftMjIozPbeOrQ07BvkJgx9ypG = w8Ui6RsVhSPrqHfO4
				MnOPIpuYDZFJ.execute(RRbvqditj184m3(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫጷ")+c6cCVGhQRqysrLY+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫጸ")+Ym0kMIiBp4dFarGHxs6Svle+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࠣࠢ࠾ࠫጹ"))
		elif l64p7KsJNMEnD:
			if showDialogs: PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,IXE6voNmrb182AyQ(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬጺ")+Ym0kMIiBp4dFarGHxs6Svle+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩጻ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+zDSw8LCxMQyraeXhojIWKmU(u"ࠪࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠࠨጼ")+GGy0cQe765nPYZ9E8Th+i80mE7lHUwVk(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩጽ"))
			else: PpQu9EkGTxa = jxCVeKSLb9rGDOl0Qtw6
			if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
				ERidftMjIozPbeOrQ07BvkJgx9ypG = w8Ui6RsVhSPrqHfO4
				if cAIRPFK6boejVU549WzqBGCaJ0r: MnOPIpuYDZFJ.execute(iiauUxMktNW5X(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫጾ")+c6cCVGhQRqysrLY+FAwWlRJg0UkN1(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ጿ")+Ym0kMIiBp4dFarGHxs6Svle+YZXtBgvUPoM5sb(u"ࠧࠣࠫࠣ࠿ࠬፀ"))
				else: MnOPIpuYDZFJ.execute(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧፁ")+c6cCVGhQRqysrLY+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ፂ")+Ym0kMIiBp4dFarGHxs6Svle+TeYukOUW7i5NBM926DCjaAn0(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪፃ"))
	except: succeeded = yrcbRSFswvAfEdIWVj
	Nv9CrIuMzsJW.commit()
	Nv9CrIuMzsJW.close()
	if ERidftMjIozPbeOrQ07BvkJgx9ypG:
		RyfYSek61do5OnQMc.sleep(ne7wF4gSTRZo(u"࠲Ꮹ"))
		oKew16fsvuV8.executebuiltin(iiauUxMktNW5X(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨፄ"))
		RyfYSek61do5OnQMc.sleep(OUFxZPuXDoGAbRz(u"࠳Ꮺ"))
		if showDialogs:
			if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiLyoNwGbH03DIXhAkZn(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ፅ")+Ym0kMIiBp4dFarGHxs6Svle)
			else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭แีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢอัิ๐หࠡษ็ษ฻อแสࠢ࡟ࡲࡡࡴࠧፆ")+Ym0kMIiBp4dFarGHxs6Svle)
	return ERidftMjIozPbeOrQ07BvkJgx9ypG
def hIqY7oRDuE18WSstUCdb(DLP5BmAOa4,showDialogs,mKVw9pS7itzq1nZlL2Asc8PvC,l64p7KsJNMEnD):
	CCLxuVfgQ54G7tXe = zkOFlha1KsAoNrVCwPSRt4c(DLP5BmAOa4)
	l6lgnqT5OKuGyV = yrcbRSFswvAfEdIWVj
	for Ym0kMIiBp4dFarGHxs6Svle in DLP5BmAOa4:
		succeeded,OAK6JCzpNuFtD95,TsXNzW6OARoHj0BeYJC = sfrcxznX1BiOl2ZF8WGYabjE(Ym0kMIiBp4dFarGHxs6Svle,showDialogs,mKVw9pS7itzq1nZlL2Asc8PvC,CCLxuVfgQ54G7tXe)
		ERidftMjIozPbeOrQ07BvkJgx9ypG = N8zQWwifyKGJbOVprhl4(Ym0kMIiBp4dFarGHxs6Svle,showDialogs,l64p7KsJNMEnD)
		if ERidftMjIozPbeOrQ07BvkJgx9ypG: l6lgnqT5OKuGyV = w8Ui6RsVhSPrqHfO4
	if l6lgnqT5OKuGyV:
		RyfYSek61do5OnQMc.sleep(zDSw8LCxMQyraeXhojIWKmU(u"࠴Ꮻ"))
		oKew16fsvuV8.executebuiltin(TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫፇ"))
		RyfYSek61do5OnQMc.sleep(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠵Ꮼ"))
	if showDialogs:
		if len(DLP5BmAOa4)>uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠶Ꮽ"): tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,KJLkQsqSHMR1Np2(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠอ็ํ฽ࠥอไฦุสๅฬะࠧፈ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩอ้ࠥฮๆอษะࠤๆำีࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ፉ")+DLP5BmAOa4[ne7wF4gSTRZo(u"࠶Ꮾ")])
	return
def TAFLUzpWg63Rf(showDialogs):
	LDTmC4nqZ9gApzXQoUtyIjuJwcke = [n6JjFHfmydIaLut(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨፊ"),NupI74tJCzYXmles9SbR6(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ፋ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩፌ"),NupI74tJCzYXmles9SbR6(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ፍ")]
	QQLMTjxOHySEXUuskB3rY = [tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩፎ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩፏ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࠬፐ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬፑ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬፒ"),NupI74tJCzYXmles9SbR6(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩፓ")]
	for Ym0kMIiBp4dFarGHxs6Svle in QQLMTjxOHySEXUuskB3rY: AK7fSFrROa6gd(Ym0kMIiBp4dFarGHxs6Svle)
	hIqY7oRDuE18WSstUCdb(LDTmC4nqZ9gApzXQoUtyIjuJwcke,showDialogs,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	return