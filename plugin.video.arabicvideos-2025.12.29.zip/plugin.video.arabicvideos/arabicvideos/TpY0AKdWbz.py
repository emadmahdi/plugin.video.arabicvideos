# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMAABDO'
JB9fyoHr05QOtPjp = '_ABD_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['الرئيسية','افلام للكبار فقط +18']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==550: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==551: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==552: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==553: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==559: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc+'/home',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(LhFnEIuPHdoNc,'url')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,559,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'اخترنا لك',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/home',551,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-content(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-name="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for xxGw3Q5hHDkP8WfVe7m,title in items:
		SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajax/getItem?item='+xxGw3Q5hHDkP8WfVe7m+'&Ajax=1'
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,551)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"nav-main"(.*?)</nav>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if SSqweDUBYv4bkO=='#': continue
		if title in d2gCoAnYPG89O: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,551)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	for SSqweDUBYv4bkO,title in items:
		if SSqweDUBYv4bkO=='#': continue
		if title in d2gCoAnYPG89O: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,551)
	return
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd = avXHrARzQuBW4s(url)
		IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = [jS6fQGXeouTB7xKd32ZMy]
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		if xxGw3Q5hHDkP8WfVe7m=='featured':
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		elif '"section-post mb-10"' in jS6fQGXeouTB7xKd32ZMy:
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"section-post mb-10"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		else:
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<article(.*?)"pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,552,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,553,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movies/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,551,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,553,T6TRUSbecYGWIq29KF)
	if xxGw3Q5hHDkP8WfVe7m==gby0BnUuTNFk:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)<footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=="": continue
				if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'هناك المزيد',url,551)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"getSeasonsBySeries(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"list-episodes"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y and '/series/' not in url:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,553,T6TRUSbecYGWIq29KF)
	elif qsQxHTa4e0JYLUSKF7:
		T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"image" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,552,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	mm7pzl3HMi0R8fGu = url.replace('/movies/','/watch_movies/')
	mm7pzl3HMi0R8fGu = mm7pzl3HMi0R8fGu.replace('/episodes/','/watch_episodes/')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',mm7pzl3HMi0R8fGu,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(mm7pzl3HMi0R8fGu,'url')
	ytc3dVjPkMHCSmlzvBuO820Q = []
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''<iframe.*?src=["'](.*?)["']''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'url')
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__embed')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"servers"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		rtdPCiNqKeO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('postID = "(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		rtdPCiNqKeO = rtdPCiNqKeO[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for TfYmiUDcZOCgQ86rENjVG1zaqXbWk,title in items:
				title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajax/getPlayer?server='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'&postID='+rtdPCiNqKeO+'&Ajax=1'
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
		else:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if items:
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk,zylKwxYHRr9Jjt3OpEfM,title = items[0]
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajax/getPlayerByName?server='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'&multipleServers='+zylKwxYHRr9Jjt3OpEfM+'&postID='+rtdPCiNqKeO+'&Ajax=1'
				Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd = avXHrARzQuBW4s(SSqweDUBYv4bkO)
				IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-PLAY-2nd')
				jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
				UURGPoTl3YX1aSHC7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''<iframe src=["'](.*?)["']''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
				RkntpA1UJDV4vNgyaex6GPWK9YQIcC = UURGPoTl3YX1aSHC7[0] if UURGPoTl3YX1aSHC7 else gby0BnUuTNFk
				if '/iframe/' in RkntpA1UJDV4vNgyaex6GPWK9YQIcC:
					ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',RkntpA1UJDV4vNgyaex6GPWK9YQIcC,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-PLAY-3rd')
					jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
					eu3pfx2oBCUAOm = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('version&quot;:&quot;(.*?)&',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					eu3pfx2oBCUAOm = eu3pfx2oBCUAOm[0]
					IciL6hoO5F1MDSVPjypWZs8kKx = {}
					IciL6hoO5F1MDSVPjypWZs8kKx['X-Inertia-Partial-Component'] = 'files/mirror/video'
					IciL6hoO5F1MDSVPjypWZs8kKx['X-Inertia'] = 'true'
					IciL6hoO5F1MDSVPjypWZs8kKx['X-Inertia-Partial-Data'] = 'streams'
					IciL6hoO5F1MDSVPjypWZs8kKx['X-Inertia-Version'] = eu3pfx2oBCUAOm
					ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',RkntpA1UJDV4vNgyaex6GPWK9YQIcC,gby0BnUuTNFk,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'CIMAABDO-PLAY-4th')
					jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
					G2towD6WFpK = TqNUy3Z4SFWvplGwXC82A('dict',jS6fQGXeouTB7xKd32ZMy)
					groups = G2towD6WFpK['props']['streams']['data']
					for group in groups:
						DYNVS1Bbgs7 = group['label'].replace(' (source)',gby0BnUuTNFk)
						bC2kj184S6gAULsMypR = group['mirrors']
						for PPpGsYnDAj5oESw7Nf8mgi3H in bC2kj184S6gAULsMypR:
							TfYmiUDcZOCgQ86rENjVG1zaqXbWk = PPpGsYnDAj5oESw7Nf8mgi3H['driver']
							SSqweDUBYv4bkO = 'http:'+PPpGsYnDAj5oESw7Nf8mgi3H['link']+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__watch____'+DYNVS1Bbgs7
							ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"downs"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+name+'__download'
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'-')
	url = LhFnEIuPHdoNc+'/search/'+search+'.html'
	Xw3tTz8UD4LK26C(url)
	return