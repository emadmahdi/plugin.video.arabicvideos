# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SHIAVOICE'
JB9fyoHr05QOtPjp = '_SHV_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
headers = {'User-Agent':None}
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==310: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==311: WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	elif mode==312: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==313: WjryKiBebavP = iXVAT9pF4OmQBHzERMuf3t6csN(url)
	elif mode==314: WjryKiBebavP = rjyJx1X2wZN(text)
	elif mode==319: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,319,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="menulinks"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<h5>(.*?)</h5>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
	for KQydxfMmoJERw in range(len(items)):
		title = items[KQydxfMmoJERw].strip(UpN1CezytPO9XoduhxZSD)
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,LhFnEIuPHdoNc,314,gby0BnUuTNFk,gby0BnUuTNFk,str(KQydxfMmoJERw+1))
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مقاطع شهر',LhFnEIuPHdoNc,314,gby0BnUuTNFk,gby0BnUuTNFk,'0')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<B>(.*?)</B>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,311)
	return jS6fQGXeouTB7xKd32ZMy
def rjyJx1X2wZN(KQydxfMmoJERw):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-LATEST-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if KQydxfMmoJERw=='0':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="tab-content"(.*?)</table>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			name = name.strip(UpN1CezytPO9XoduhxZSD)
			title = title+' ('+name+')'
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312)
	elif KQydxfMmoJERw in ['1','2','3']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(<h5>.*?)<div class="col-lg',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		wynYLWk0soP32ZFAMI7QmB = int(KQydxfMmoJERw)-1
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[wynYLWk0soP32ZFAMI7QmB]
		if KQydxfMmoJERw=='1': items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		else: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title,name in items:
			T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			name = name.strip(UpN1CezytPO9XoduhxZSD)
			title = title+' ('+name+')'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,311,T6TRUSbecYGWIq29KF)
	elif KQydxfMmoJERw in ['4','5','6']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(<h5>.*?)</table>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		KQydxfMmoJERw = int(KQydxfMmoJERw)-4
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[KQydxfMmoJERw]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,zBsWAhdqRc0NMjfkVPmvt4rKG215T,title,sMiRfjzPx90H8mEpD in items:
			T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			zBsWAhdqRc0NMjfkVPmvt4rKG215T = zBsWAhdqRc0NMjfkVPmvt4rKG215T.strip(UpN1CezytPO9XoduhxZSD)
			sMiRfjzPx90H8mEpD = sMiRfjzPx90H8mEpD.strip(UpN1CezytPO9XoduhxZSD)
			if zBsWAhdqRc0NMjfkVPmvt4rKG215T: name = zBsWAhdqRc0NMjfkVPmvt4rKG215T
			else: name = sMiRfjzPx90H8mEpD
			title = title+' ('+name+')'
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312,T6TRUSbecYGWIq29KF)
	return
def Xw3tTz8UD4LK26C(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ibox-heading"(.*?)class="float-right',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if 'catsum-mobile' in AxiBv1cQueOs0:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title,count in items:
				T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
				count = count.replace(' الصوتية: ',':')
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				title = title+' ('+count+')'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,311,T6TRUSbecYGWIq29KF)
	else:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,C3EcJ1g8moD,a8tFl4fNpx2Ou65q in items:
			if title==gby0BnUuTNFk or C3EcJ1g8moD==gby0BnUuTNFk: continue
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title+' ('+a8tFl4fNpx2Ou65q+')'
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312)
	if not items: Ra4XAK1tDxc3kfOrIdsjLpzmGN0(jS6fQGXeouTB7xKd32ZMy)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(jS6fQGXeouTB7xKd32ZMy):
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="ibox-content"(.*?)class="pagination',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title,name,count,a8tFl4fNpx2Ou65q in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		name = name.strip(UpN1CezytPO9XoduhxZSD)
		title = title+' ('+name+')'
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312,gby0BnUuTNFk,a8tFl4fNpx2Ou65q)
	return
def iXVAT9pF4OmQBHzERMuf3t6csN(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-SEARCH_ITEMS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="ibox-content p-1"(.*?)class="ibox-content"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb:
		Xw3tTz8UD4LK26C(url)
		return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<strong>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if '/play-' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,311)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<audio.*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not SSqweDUBYv4bkO: SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<video.*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO[0]
	YAQOL1eVvqMjsEfIFc(SSqweDUBYv4bkO,CC3nOPFMovd72u,'video')
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	UloV7H8OpKMPts2h0r5IxaQeY4 = ['&t=a','&t=c','&t=s']
	if showDialogs:
		rwk90Qp8CM = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('موقع صوت الشيعة - أختر البحث', rwk90Qp8CM)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1: return
	elif '_SHIAVOICE-PERSONS_' in K7ETgQ2pb4ylWIB3vDHjJ: EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 0
	elif '_SHIAVOICE-ALBUMS_' in K7ETgQ2pb4ylWIB3vDHjJ: EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 1
	elif '_SHIAVOICE-AUDIOS_' in K7ETgQ2pb4ylWIB3vDHjJ: EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 2
	else: return
	type = UloV7H8OpKMPts2h0r5IxaQeY4[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	url = LhFnEIuPHdoNc+'/search.php?q='+search+type
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHIAVOICE-SEARCH-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="ibox-content"(.*?)class="ibox-content"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc in [0,1]:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title,name in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				name = name.strip(UpN1CezytPO9XoduhxZSD)
				title = title+' ('+name+')'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,313,T6TRUSbecYGWIq29KF)
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==2:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title,name in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				name = name.strip(UpN1CezytPO9XoduhxZSD)
				title = title+' ('+name+')'
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,312)
	return