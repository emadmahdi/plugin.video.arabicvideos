# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'HALACIMA'
JB9fyoHr05QOtPjp = '_HLC_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==80: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==81: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==82: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==83: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==89: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'HALACIMA-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(LhFnEIuPHdoNc,'url')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,89,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-content(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-name="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for xxGw3Q5hHDkP8WfVe7m,title in items:
		SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajax/getItem?item='+xxGw3Q5hHDkP8WfVe7m+'&Ajax=1'
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,81)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"nav-main"(.*?)</nav>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if SSqweDUBYv4bkO=='#': continue
		if title in d2gCoAnYPG89O: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,81)
	return
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd = avXHrARzQuBW4s(url)
		IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'HALACIMA-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = [jS6fQGXeouTB7xKd32ZMy]
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'HALACIMA-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		if xxGw3Q5hHDkP8WfVe7m=='featured':
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		elif '"section-post mb-10"' in jS6fQGXeouTB7xKd32ZMy:
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"section-post mb-10"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		else:
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<article(.*?)"pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '/series/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,83,T6TRUSbecYGWIq29KF)
		elif 'سلاسل' not in url and any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,82,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,83,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movies/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,81,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,83,T6TRUSbecYGWIq29KF)
	if xxGw3Q5hHDkP8WfVe7m==gby0BnUuTNFk:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)<footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=="": continue
				if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'هناك المزيد',url,81)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'HALACIMA-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"getSeasonsBySeries(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"list-episodes"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y and '/series/' not in url:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,83,T6TRUSbecYGWIq29KF)
	elif qsQxHTa4e0JYLUSKF7:
		T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"image" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,82,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	Tf5ueYGZIFl1hraoEOVKi = url.replace('/movies/','/watch_movies/')
	Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi.replace('/episodes/','/watch_episodes/')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'HALACIMA-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Tf5ueYGZIFl1hraoEOVKi,'url')
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"servers"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		rtdPCiNqKeO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('postID = "(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		rtdPCiNqKeO = rtdPCiNqKeO[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for TfYmiUDcZOCgQ86rENjVG1zaqXbWk,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajax/getPlayer?server='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'&postID='+rtdPCiNqKeO+'&Ajax=1'
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"downs"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+name+'__download'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'-')
	url = LhFnEIuPHdoNc+'/search/'+search+'.html'
	Xw3tTz8UD4LK26C(url)
	return