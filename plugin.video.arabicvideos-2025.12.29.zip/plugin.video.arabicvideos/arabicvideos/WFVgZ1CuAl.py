# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from V4OX6PRG0U import *
CC3nOPFMovd72u = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭᳉")
JB9fyoHr05QOtPjp = mmbcsf2pd7gyjzreB(u"࠭࡟ࡍࡕࡗࡣࠬ᳊")
GGCyzqHVFWKjRch = z5RruqXvsLaTf7e9c
UUT98ftmy56ujZICqNpS0d7JxkrK = NupI74tJCzYXmles9SbR6(u"࠳࠳ἵ")
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,url,fbmZ9V58PCTz,kdwXYDMQOjz51Z08W,ZgSKTRL2DlPprjU57W93zf4EF):
	try: To1jOLBdtPWhFayp = str(ZgSKTRL2DlPprjU57W93zf4EF[BarIC3eR9bS(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳋")])
	except: To1jOLBdtPWhFayp = gby0BnUuTNFk
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠴࠺࠵ἶ"): WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠵࠻࠷ἷ"): WjryKiBebavP = l29uxntUGA(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==nJF7oflOk6cLGSAey(u"࠶࠼࠲Ἰ"): WjryKiBebavP = NNs8p9veDEOSFxywnP5I3GqR(fbmZ9V58PCTz,nJF7oflOk6cLGSAey(u"࠶࠼࠲Ἰ"))
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠷࠶࠴Ἱ"): WjryKiBebavP = NNs8p9veDEOSFxywnP5I3GqR(fbmZ9V58PCTz,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠷࠶࠴Ἱ"))
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==KJLkQsqSHMR1Np2(u"࠱࠷࠶Ἲ"): WjryKiBebavP = vvSalsRhmq(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==KJLkQsqSHMR1Np2(u"࠲࠸࠸Ἳ"): WjryKiBebavP = ssNzu0Qm14ZtnFdoE(url,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠳࠹࠺Ἴ"): WjryKiBebavP = ZeiJmb0uEYcCzjfFWLsKMv2oDq(url,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠴࠺࠼Ἵ"): WjryKiBebavP = tQ9ke1r4dxawJIUFf(url,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ggtuNcvTn3HQ7SpE2(u"࠵࠻࠾Ἶ"): WjryKiBebavP = m7AzytbLlui(url,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiauUxMktNW5X(u"࠼࠼࠱Ἷ"): WjryKiBebavP = ttlgXS3VF9yR7YAkEm()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ggtuNcvTn3HQ7SpE2(u"࠽࠶࠳ὀ"): WjryKiBebavP = g28lQznsoXjqGe3FkbBwJuDIN()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==Ducd5PRjQXaB9SIN7VrJ1G(u"࠷࠷࠵ὁ"): WjryKiBebavP = wFcArN5U4x2Mu6VOGeR9hn7KfkPZiX(To1jOLBdtPWhFayp,fbmZ9V58PCTz,kdwXYDMQOjz51Z08W)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==OUFxZPuXDoGAbRz(u"࠸࠸࠷ὂ"): WjryKiBebavP = dz5u61aRXkfgNCHq(To1jOLBdtPWhFayp,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==q2qPkMFpR1G86dEAKXHivor9N(u"࠹࠹࠹ὃ"): WjryKiBebavP = zNM39KuPBf2qOCSR(To1jOLBdtPWhFayp,fbmZ9V58PCTz)
	else: WjryKiBebavP = yrcbRSFswvAfEdIWVj
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳌"),iiauUxMktNW5X(u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪ᳍"),gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠴࠺࠶ὄ"),gby0BnUuTNFk,gby0BnUuTNFk,IXE6voNmrb182AyQ(u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᳎"))
	ygWIQGf25qwVxLkXrYDjp(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳏"),ggtuNcvTn3HQ7SpE2(u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ᳐"),gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"࠵࠻࠸ὅ"),gby0BnUuTNFk,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳑"))
	ygWIQGf25qwVxLkXrYDjp(iiauUxMktNW5X(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳒"),FAwWlRJg0UkN1(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ᳓"),gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠶࠼࠳὆"),gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳔ࠧ"))
	ygWIQGf25qwVxLkXrYDjp(mmbcsf2pd7gyjzreB(u"ࠪࡪࡴࡲࡤࡦࡴ᳕ࠪ"),IXE6voNmrb182AyQ(u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์᳖ࠪ"),gby0BnUuTNFk,iiauUxMktNW5X(u"࠷࠶࠵὇"),gby0BnUuTNFk,gby0BnUuTNFk,iI7tuF0nEQoR(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳗ࠪ"))
	ygWIQGf25qwVxLkXrYDjp(OUFxZPuXDoGAbRz(u"࠭ࡦࡰ࡮ࡧࡩࡷ᳘࠭"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็᳙ࠪ"),gby0BnUuTNFk,ne7wF4gSTRZo(u"࠷࠷࠵Ὀ"),gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ᳚"))
	ygWIQGf25qwVxLkXrYDjp(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࡯࡭ࡳࡱࠧ᳛"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+BarIC3eR9bS(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽᳜ࠡࠩ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,BarIC3eR9bS(u"࠺࠻࠼࠽Ὁ"))
	ygWIQGf25qwVxLkXrYDjp(KJLkQsqSHMR1Np2(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),i80mE7lHUwVk(u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส᳞ࠩ"),gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠳࠹࠷Ὂ"),gby0BnUuTNFk,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳟"))
	ygWIQGf25qwVxLkXrYDjp(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ᳡"),gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"࠴࠺࠸Ὃ"),gby0BnUuTNFk,gby0BnUuTNFk,ggtuNcvTn3HQ7SpE2(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳢ࠪ"))
	ygWIQGf25qwVxLkXrYDjp(IXE6voNmrb182AyQ(u"ࠪࡪࡴࡲࡤࡦࡴ᳣ࠪ"),RRbvqditj184m3(u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํ᳤ࠫ"),gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠵࠻࠸Ὄ"),gby0BnUuTNFk,gby0BnUuTNFk,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᳥࠭"))
	ygWIQGf25qwVxLkXrYDjp(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡦࡰ࡮ࡧࡩࡷ᳦࠭"),mmbcsf2pd7gyjzreB(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐᳧ࠧ"),gby0BnUuTNFk,BarIC3eR9bS(u"࠶࠼࠲Ὅ"),gby0BnUuTNFk,gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳨"))
	ygWIQGf25qwVxLkXrYDjp(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩࡩࡳࡱࡪࡥࡳࠩᳩ"),iI7tuF0nEQoR(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭ᳪ"),gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠷࠶࠵὎"),gby0BnUuTNFk,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᳫ"))
	ygWIQGf25qwVxLkXrYDjp(TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳬ"),q2qPkMFpR1G86dEAKXHivor9N(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊᳭࠭"),gby0BnUuTNFk,RRbvqditj184m3(u"࠷࠷࠷὏"),gby0BnUuTNFk,gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᳮ"))
	ygWIQGf25qwVxLkXrYDjp(iI7tuF0nEQoR(u"ࠨ࡮࡬ࡲࡰ࠭ᳯ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+nJF7oflOk6cLGSAey(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᳰ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠺࠻࠼࠽ὐ"))
	ygWIQGf25qwVxLkXrYDjp(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),ne7wF4gSTRZo(u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩᳲ"),gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"࠳࠹࠷ὑ"),gby0BnUuTNFk,gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᳳ"))
	ygWIQGf25qwVxLkXrYDjp(OUFxZPuXDoGAbRz(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳴"),TeYukOUW7i5NBM926DCjaAn0(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨᳵ"),gby0BnUuTNFk,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠴࠺࠸ὒ"),gby0BnUuTNFk,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᳶ"))
	ygWIQGf25qwVxLkXrYDjp(iI7tuF0nEQoR(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳷"),iiLyoNwGbH03DIXhAkZn(u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ᳸"),gby0BnUuTNFk,NupI74tJCzYXmles9SbR6(u"࠵࠻࠸ὓ"),gby0BnUuTNFk,gby0BnUuTNFk,n6JjFHfmydIaLut(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳹"))
	ygWIQGf25qwVxLkXrYDjp(TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳺ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ᳻"),gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"࠶࠼࠲ὔ"),gby0BnUuTNFk,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳼"))
	ygWIQGf25qwVxLkXrYDjp(VzO1gCHmjZ2ebRIL(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳽"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏࠭᳾"),gby0BnUuTNFk,IXE6voNmrb182AyQ(u"࠷࠶࠵ὕ"),gby0BnUuTNFk,gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳿"))
	ygWIQGf25qwVxLkXrYDjp(zDSw8LCxMQyraeXhojIWKmU(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴀ"),MlTVLBZ92kzorIq1Yw(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭ᴁ"),gby0BnUuTNFk,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠷࠷࠶ὖ"),gby0BnUuTNFk,gby0BnUuTNFk,TeYukOUW7i5NBM926DCjaAn0(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴂ"))
	return
def ttlgXS3VF9yR7YAkEm():
	ygWIQGf25qwVxLkXrYDjp(ne7wF4gSTRZo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴃ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡡࡌࡔ࡙ࡥࠧᴄ")+NupI74tJCzYXmles9SbR6(u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧᴅ"),gby0BnUuTNFk,IXE6voNmrb182AyQ(u"࠸࠸࠷ὗ"))
	ygWIQGf25qwVxLkXrYDjp(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡰ࡮ࡴ࡫ࠨᴆ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᴇ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,iiauUxMktNW5X(u"࠻࠼࠽࠾὘"))
	for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
		JB9fyoHr05QOtPjp = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡥࡉࡑࠩᴈ")+str(To1jOLBdtPWhFayp)+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭࡟ࠨᴉ")
		ygWIQGf25qwVxLkXrYDjp(iiauUxMktNW5X(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴊ"),JB9fyoHr05QOtPjp+zDSw8LCxMQyraeXhojIWKmU(u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪᴋ")+XVANElz3tLn5pFPQUWi[To1jOLBdtPWhFayp],gby0BnUuTNFk,KJLkQsqSHMR1Np2(u"࠺࠺࠹Ὑ"),gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{BarIC3eR9bS(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴌ"):To1jOLBdtPWhFayp})
	return
def g28lQznsoXjqGe3FkbBwJuDIN():
	ygWIQGf25qwVxLkXrYDjp(MlTVLBZ92kzorIq1Yw(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴍ"),IXE6voNmrb182AyQ(u"ࠫࡤࡓ࠳ࡖࡡࠪᴎ")+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩᴏ"),gby0BnUuTNFk,iI7tuF0nEQoR(u"࠻࠻࠻὚"))
	ygWIQGf25qwVxLkXrYDjp(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭࡬ࡪࡰ࡮ࠫᴐ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+zDSw8LCxMQyraeXhojIWKmU(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᴑ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"࠾࠿࠹࠺Ὓ"))
	for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
		JB9fyoHr05QOtPjp = nJF7oflOk6cLGSAey(u"ࠨࡡࡐ࡙ࠬᴒ")+str(To1jOLBdtPWhFayp)+IXE6voNmrb182AyQ(u"ࠩࡢࠫᴓ")
		ygWIQGf25qwVxLkXrYDjp(mmbcsf2pd7gyjzreB(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴔ"),JB9fyoHr05QOtPjp+ggtuNcvTn3HQ7SpE2(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᴕ")+XVANElz3tLn5pFPQUWi[To1jOLBdtPWhFayp],gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠽࠶࠶὜"),gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴖ"):To1jOLBdtPWhFayp})
	return
def ooqnytdDuHiCT1kJsNKfzg5bAY2mBI(gwiQ59eNbhY2SlLZB7aOpTDdsk1):
	global qbSafePhTuk5BmJ,GGLSapkMD4mdwtlCZRYvbE6
	DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	try:
		if TeYukOUW7i5NBM926DCjaAn0(u"࠭ࡉࡇࡋࡏࡑࠬᴗ") in gwiQ59eNbhY2SlLZB7aOpTDdsk1: DeScCQAb5ti1ZxUPE(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		else: DeScCQAb5ti1ZxUPE()
		F6BHwhZrPXqoy7YnRi3lTLGOeM0 = yrcbRSFswvAfEdIWVj
	except:
		xTdl05McQ1krVim4nFPzfReg32Yh()
		F6BHwhZrPXqoy7YnRi3lTLGOeM0 = w8Ui6RsVhSPrqHfO4
	gwiQ59eNbhY2SlLZB7aOpTDdsk1 = hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	if F6BHwhZrPXqoy7YnRi3lTLGOeM0:
		RLfOB3nsqaWXTugJvY(gwiQ59eNbhY2SlLZB7aOpTDdsk1,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧโึ็ࠤ้๊ริใࠪᴘ"),RyfYSek61do5OnQMc=tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠲࠱࠲࠳Ὕ"))
		qbSafePhTuk5BmJ += jxCVeKSLb9rGDOl0Qtw6
		GGLSapkMD4mdwtlCZRYvbE6 += FAwWlRJg0UkN1(u"ࠨࠢ࠱ࠤࠬᴙ")+gwiQ59eNbhY2SlLZB7aOpTDdsk1
	else: RLfOB3nsqaWXTugJvY(gwiQ59eNbhY2SlLZB7aOpTDdsk1,gby0BnUuTNFk,RyfYSek61do5OnQMc=Ducd5PRjQXaB9SIN7VrJ1G(u"࠲࠲࠳࠴὞"))
	return
PwBW3hUyG7osmXJ5NivCEt1R0AM = {}
def rYfVJAbIE3(Vn4Osa9HN3Yi=w8Ui6RsVhSPrqHfO4):
	global qbSafePhTuk5BmJ,GGLSapkMD4mdwtlCZRYvbE6,PwBW3hUyG7osmXJ5NivCEt1R0AM
	if not Vn4Osa9HN3Yi:
		PwBW3hUyG7osmXJ5NivCEt1R0AM = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,OUFxZPuXDoGAbRz(u"ࠩࡧ࡭ࡨࡺࠧᴚ"),FAwWlRJg0UkN1(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫᴛ"),ne7wF4gSTRZo(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩᴜ"))
		if PwBW3hUyG7osmXJ5NivCEt1R0AM: return
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᴝ"),gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ne7wF4gSTRZo(u"࠭อห๋ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮࠯ࠢึ๎ๆำีࠡษ็ฬึ์วๆฮࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤาะ้ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴࠮้ࠡำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤࡡࡴ࡜࡯ࠩᴞ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+ggtuNcvTn3HQ7SpE2(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯาๅฺࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩᴟ")+GGy0cQe765nPYZ9E8Th)
	if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return
	zyZYjwM8GFn(qrejGtHg2Z,qrejGtHg2Z,qrejGtHg2Z)
	vN6LDiAUfEIMWXCQ1oSGKjB3HVzP = wAcHkmPB8a.menuItemsLIST
	qbSafePhTuk5BmJ,GGLSapkMD4mdwtlCZRYvbE6,tLDSIOX2mipNhEYq = xn867tCVlscY4qbWZfh,gby0BnUuTNFk,{}
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in dkrEBbSmqg8QwX13I:
		RyfYSek61do5OnQMc.sleep(jxCVeKSLb9rGDOl0Qtw6)
		tLDSIOX2mipNhEYq[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=ooqnytdDuHiCT1kJsNKfzg5bAY2mBI,args=(gwiQ59eNbhY2SlLZB7aOpTDdsk1,))
		tLDSIOX2mipNhEYq[gwiQ59eNbhY2SlLZB7aOpTDdsk1].start()
	else:
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in list(tLDSIOX2mipNhEYq.keys()): tLDSIOX2mipNhEYq[gwiQ59eNbhY2SlLZB7aOpTDdsk1].join()
	wAcHkmPB8a.menuItemsLIST[:] = vN6LDiAUfEIMWXCQ1oSGKjB3HVzP
	PwBW3hUyG7osmXJ5NivCEt1R0AM = {}
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in list(tLDSIOX2mipNhEYq.keys()):
		try: nnBDXI8xmqFsauKZj9LCEgQTUYek3A = wAcHkmPB8a.menuItemsDICT[gwiQ59eNbhY2SlLZB7aOpTDdsk1]
		except: continue
		gwiQ59eNbhY2SlLZB7aOpTDdsk1 = TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡡࡏࡗ࡙ࡥࠧᴠ")+hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD in nnBDXI8xmqFsauKZj9LCEgQTUYek3A:
			if not DPkEMfnRe82d: DPkEMfnRe82d = iiauUxMktNW5X(u"ࠩ࠱࠲࠳࠴ࠧᴡ")
			else:
				if DPkEMfnRe82d.count(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡣࠬᴢ"))>jxCVeKSLb9rGDOl0Qtw6: DPkEMfnRe82d = DPkEMfnRe82d.split(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡤ࠭ᴣ"),dNx9DVCtafk4r)[dNx9DVCtafk4r]
				DPkEMfnRe82d = DPkEMfnRe82d.replace(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࢦࠧᴤ"),gby0BnUuTNFk).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࠠࡉࡆࠪᴥ"),gby0BnUuTNFk).replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡉࡆࠣࠫᴦ"),gby0BnUuTNFk)
				DPkEMfnRe82d = DPkEMfnRe82d.replace(MlTVLBZ92kzorIq1Yw(u"ࠨโࠪᴧ"),gby0BnUuTNFk).replace(ggtuNcvTn3HQ7SpE2(u"ࠩฬࠫᴨ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๋ࠪࠬᴩ")).replace(iiLyoNwGbH03DIXhAkZn(u"ࠫษ࠭ᴪ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬ๎ࠧᴫ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(OUFxZPuXDoGAbRz(u"࠭รࠨᴬ"),KJLkQsqSHMR1Np2(u"ࠧศࠩᴭ")).replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨวࠪᴮ"),KJLkQsqSHMR1Np2(u"ࠩสࠫᴯ")).replace(i80mE7lHUwVk(u"ࠪฦࠬᴰ"),RRbvqditj184m3(u"ࠫฬ࠭ᴱ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(ggtuNcvTn3HQ7SpE2(u"๊ࠬรࠨᴲ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ไศࠩᴳ")).replace(iiauUxMktNW5X(u"ࠧๅวࠪᴴ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨๆสࠫᴵ")).replace(RRbvqditj184m3(u"ࠩ็ฦࠬᴶ"),BarIC3eR9bS(u"่ࠪฬ࠭ᴷ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫ๓࠭ᴸ"),gby0BnUuTNFk).replace(RRbvqditj184m3(u"ࠬ๑ࠧᴹ"),gby0BnUuTNFk).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"࠭๏ࠨᴺ"),gby0BnUuTNFk).replace(MlTVLBZ92kzorIq1Yw(u"ࠧํࠩᴻ"),gby0BnUuTNFk)
				DPkEMfnRe82d = DPkEMfnRe82d.replace(ne7wF4gSTRZo(u"ࠨ๒ࠪᴼ"),gby0BnUuTNFk).replace(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩ๐ࠫᴽ"),gby0BnUuTNFk).replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠪ๖ࠬᴾ"),gby0BnUuTNFk).replace(BarIC3eR9bS(u"ࠫ๖࠭ᴿ"),gby0BnUuTNFk)
				DPkEMfnRe82d = DPkEMfnRe82d.replace(iI7tuF0nEQoR(u"ࠬࢂࠧᵀ"),gby0BnUuTNFk).replace(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡾࠨᵁ"),gby0BnUuTNFk)
				DPkEMfnRe82d = DPkEMfnRe82d.replace(iiauUxMktNW5X(u"ࠧศ๊้ࠤ้อ๊็ࠩᵂ"),gby0BnUuTNFk).replace(VzO1gCHmjZ2ebRIL(u"ࠨีํ้ฬࠦไศ์อࠫᵃ"),gby0BnUuTNFk)
				X6cMmAtbCS2UdIpJLZEw57j = [tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩส่฾อศࠨᵄ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠪา๏อไࠨᵅ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫฬ๊ศ้็ࠪᵆ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬอไศ่ࠪᵇ"),Ducd5PRjQXaB9SIN7VrJ1G(u"࠭วุใส่ࠬᵈ"),RRbvqditj184m3(u"ࠧฮษ็๎์࠭ᵉ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠨษ็฾ฬุࠧᵊ"),MlTVLBZ92kzorIq1Yw(u"ุࠩห้ำࠧᵋ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪห้ี๊็ࠩᵌ"),VzO1gCHmjZ2ebRIL(u"๊ࠫ๎วๅ์าࠫᵍ"),FAwWlRJg0UkN1(u"ࠬอไฺษ็้ࠬᵎ"),q2qPkMFpR1G86dEAKXHivor9N(u"࠭วฺ็ส่ࠬᵏ")]
				if not any(sspW29TnCh1 in DPkEMfnRe82d for sspW29TnCh1 in X6cMmAtbCS2UdIpJLZEw57j): DPkEMfnRe82d = DPkEMfnRe82d.replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠧศๆࠪᵐ"),gby0BnUuTNFk)
				DPkEMfnRe82d = DPkEMfnRe82d.replace(zDSw8LCxMQyraeXhojIWKmU(u"ࠨษัี๏࠭ᵑ"),iiLyoNwGbH03DIXhAkZn(u"ࠩสาึ๏ࠧᵒ")).replace(iI7tuF0nEQoR(u"ࠪหั์ศ๊ࠩᵓ"),NupI74tJCzYXmles9SbR6(u"ࠫฬาๆษ์ࠪᵔ")).replace(OUFxZPuXDoGAbRz(u"ࠬ฿ววๆํ๋ࠬᵕ"),IXE6voNmrb182AyQ(u"ู࠭ศศ็๎ࠬᵖ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(KJLkQsqSHMR1Np2(u"ࠧศฮ้ฬ๏ํࠧᵗ"),VzO1gCHmjZ2ebRIL(u"ࠨษฯ๊อ๐ࠧᵘ")).replace(mmbcsf2pd7gyjzreB(u"ࠩ฼ีอ๐็ࠨᵙ"),ggtuNcvTn3HQ7SpE2(u"ࠪ฽ึฮ๊ࠨᵚ")).replace(FAwWlRJg0UkN1(u"ࠫึ๎ๅศ่ึ๎์࠭ᵛ"),n6JjFHfmydIaLut(u"ࠬื่ๆษ้ื๏࠭ᵜ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(NupI74tJCzYXmles9SbR6(u"ฺ࠭าสํ๋ࠬᵝ"),nJF7oflOk6cLGSAey(u"ࠧ฻ำห๎ࠬᵞ")).replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨุ๊้๊ࠣำๅษอࠫᵟ"),KJLkQsqSHMR1Np2(u"่ࠩืู้ไศฬࠪᵠ")).replace(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪห฿อๆ๊ࠩᵡ"),KJLkQsqSHMR1Np2(u"ࠫฬเว็์ࠪᵢ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(KJLkQsqSHMR1Np2(u"ࠬะวา์ั๎ࠬᵣ"),KJLkQsqSHMR1Np2(u"࠭สศำําࠬᵤ")).replace(YZXtBgvUPoM5sb(u"ࠧฯ์ส่ࠥ฿ไๆ์ࠪᵥ"),FAwWlRJg0UkN1(u"ࠨะํห้࠭ᵦ")).replace(zDSw8LCxMQyraeXhojIWKmU(u"่ࠩ์ุ๐โ๋้ࠪᵧ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"้ࠪํู๊ใ๋ࠪᵨ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫ์์ฯ๊ࠩᵩ"),iiauUxMktNW5X(u"ࠬํๆะ์ࠪᵪ")).replace(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭็็ัํ๋ࠬᵫ"),TeYukOUW7i5NBM926DCjaAn0(u"่่ࠧา๎ࠬᵬ")).replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠨ๊ฮหห่๊่ࠩᵭ"),Ducd5PRjQXaB9SIN7VrJ1G(u"๋ࠩฯฬฬโ๋ࠩᵮ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(OUFxZPuXDoGAbRz(u"ࠪฮ้๐แำ์๋๊๏ํࠧᵯ"),BarIC3eR9bS(u"ࠫฯ๊แำ์๋๊ࠬᵰ")).replace(iI7tuF0nEQoR(u"ࠬะไโิํ์๋๐็ࠨᵱ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭สๅใี๎ํ์ࠧᵲ")).replace(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"้ࠧࠢๆีฯ๎ๆࠨᵳ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨ๊ๆีฯ๎ๆࠨᵴ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩส่าอไ๋้ࠪᵵ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪัฬ๊๊่ࠩᵶ")).replace(zDSw8LCxMQyraeXhojIWKmU(u"๊ࠫ๎ำໍไํࠫᵷ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"๋่ࠬิ์ๅํࠬᵸ")).replace(i80mE7lHUwVk(u"࠭วๅษ้้๏࠭ᵹ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧศ่่๎ࠬᵺ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(OUFxZPuXDoGAbRz(u"ࠨษ็ุ้๊ำๅษอࠫᵻ"),iI7tuF0nEQoR(u"่ࠩืู้ไศฬࠪᵼ")).replace(FAwWlRJg0UkN1(u"ࠪห้ฮัศ็ฯࠫᵽ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫอืวๆฮࠪᵾ")).replace(q2qPkMFpR1G86dEAKXHivor9N(u"้ࠬวาฬ๋๊ࠬᵿ"),iI7tuF0nEQoR(u"࠭ใาฬ๋๊ࠬᶀ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧฮำ๋ฬࠬᶁ"),n6JjFHfmydIaLut(u"ࠨฯิฬࠬᶂ")).replace(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩส่ฬ์วี์าࠫᶃ"),VzO1gCHmjZ2ebRIL(u"ࠪห๋อิ๋ัࠪᶄ")).replace(OUFxZPuXDoGAbRz(u"ࠫฬู๊้์๊ࠫᶅ"),iI7tuF0nEQoR(u"ࠬอำ๋๊ํࠫᶆ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(DWgX6JfF3SnlsQwtN1cvGk8L(u"ู࠭าส์ࠫᶇ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ฺࠧำห๎ࠬᶈ")).replace(YZXtBgvUPoM5sb(u"ࠨฬิ็๎࠭ᶉ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠩอี่๐ࠧᶊ")).replace(ne7wF4gSTRZo(u"ࠪฮึ้๊่ࠩᶋ"),nJF7oflOk6cLGSAey(u"ࠫฯืใ๋ࠩᶌ")).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬอไๆุสๅࠬᶍ"),nJF7oflOk6cLGSAey(u"࠭ๅืษไࠫᶎ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(NupI74tJCzYXmles9SbR6(u"ࠧา์สฺ๏࠭ᶏ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨำํห฻ฯࠧᶐ")).replace(NupI74tJCzYXmles9SbR6(u"ࠩิ๎ฬ฼็ࠨᶑ"),iiauUxMktNW5X(u"ࠪี๏อึสࠩᶒ")).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫฬู๊้์๊ࠫᶓ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬอำ๋๊ํࠫᶔ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(nJF7oflOk6cLGSAey(u"࠭ใ้็ํำ๎࠭ᶕ"),VzO1gCHmjZ2ebRIL(u"ࠧไ๊่๎ิ๐ࠧᶖ")).replace(iI7tuF0nEQoR(u"ࠨๅ๋้๏ี๊่ࠩᶗ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠩๆ์๊๐ฯ๋ࠩᶘ")).replace(zDSw8LCxMQyraeXhojIWKmU(u"ࠪห๋๐ๅ๋ࠩᶙ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠫฬ์ๅ๋ࠩᶚ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬอๆ๋็ํุ๋࠭ᶛ"),KJLkQsqSHMR1Np2(u"࠭ว็็ํุ๋࠭ᶜ")).replace(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧศ่่ํࠬᶝ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨษ้้๏ฺๆࠨᶞ")).replace(i80mE7lHUwVk(u"ࠩส๊๊๐ࠧᶟ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪห๋๋๊ี่ࠪᶠ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(FAwWlRJg0UkN1(u"ࠫฬ์ๅ๋ึุ้๋࠭ᶡ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬอๆๆ์ื๊ࠬᶢ")).replace(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭วๅษ้้๏ฺๆࠨᶣ"),ne7wF4gSTRZo(u"ࠧศ่่๎ู์ࠧᶤ")).replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨษไ่ฬ๋ࠠๆี็ื้อสࠨᶥ"),BarIC3eR9bS(u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪᶦ"))
				DPkEMfnRe82d = DPkEMfnRe82d.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).strip(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࠱ࠬᶧ")).strip(UpN1CezytPO9XoduhxZSD)
			if DPkEMfnRe82d not in list(PwBW3hUyG7osmXJ5NivCEt1R0AM.keys()): PwBW3hUyG7osmXJ5NivCEt1R0AM[DPkEMfnRe82d] = {}
			PwBW3hUyG7osmXJ5NivCEt1R0AM[DPkEMfnRe82d][gwiQ59eNbhY2SlLZB7aOpTDdsk1] = [ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD]
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,ggtuNcvTn3HQ7SpE2(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᶨ"),KJLkQsqSHMR1Np2(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᶩ"),PwBW3hUyG7osmXJ5NivCEt1R0AM,Z83rChqtg1oXUjI4YL)
	if qbSafePhTuk5BmJ>=UUT98ftmy56ujZICqNpS0d7JxkrK: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧᶪ")+str(qbSafePhTuk5BmJ)+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࠡ็๋ๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้้ࠠๆิฬࠦๅีๅ็อูࠥศษ้สࠤ฾อฯส่๊ࠢࠥอไฦ่อี๋๐สࠡ฻้ำ่่ࠦศๆ่์ฬู่้ࠡํ࠾ࠬᶫ")+GGLSapkMD4mdwtlCZRYvbE6)
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧᶬ"))
	zyZYjwM8GFn(H14j5s97qxM,H14j5s97qxM,H14j5s97qxM)
	cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	return
def tcWLgqTQs8V3Aw(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo):
	EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
	PPB0Jlbxuf2RiWdnpAGS1eZt8H = wAcHkmPB8a.menuItemsLIST
	wAcHkmPB8a.menuItemsLIST[:] = []
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC and IXE6voNmrb182AyQ(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᶭ") not in N1FbhV4lx6QcWOo:
		WjryKiBebavP = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,RRbvqditj184m3(u"ࠪࡰ࡮ࡹࡴࠨᶮ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫᶯ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭ᶰ")+To1jOLBdtPWhFayp)
	elif ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᶱ") not in N1FbhV4lx6QcWOo or ggtuNcvTn3HQ7SpE2(u"ࠧࡠࡘࡒࡈࡤ࠭ᶲ") not in N1FbhV4lx6QcWOo:
		import BBhJgplbfL
		H7fCeh95oEyapvUl4itZDm2Njdx6z = BarIC3eR9bS(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥืำศศ็ࠤฬ๊ศา่ส้ั࠭ᶳ")
		if VzO1gCHmjZ2ebRIL(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᶴ") not in N1FbhV4lx6QcWOo:
			try: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,i80mE7lHUwVk(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶵ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+nJF7oflOk6cLGSAey(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶶ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᶷ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,FAwWlRJg0UkN1(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᶸ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+iI7tuF0nEQoR(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶹ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,IXE6voNmrb182AyQ(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᶺ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,VzO1gCHmjZ2ebRIL(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶻ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+iiLyoNwGbH03DIXhAkZn(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶼ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,i80mE7lHUwVk(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᶽ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡥࡖࡐࡆࡢࠫᶾ") not in N1FbhV4lx6QcWOo:
			try: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,FAwWlRJg0UkN1(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᶿ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+ggtuNcvTn3HQ7SpE2(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᷀"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,iiLyoNwGbH03DIXhAkZn(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭᷁"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᷂"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+i80mE7lHUwVk(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᷃"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ᷄"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
		WjryKiBebavP = wAcHkmPB8a.menuItemsLIST
		if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ᷅"),MlTVLBZ92kzorIq1Yw(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ᷆")+To1jOLBdtPWhFayp,WjryKiBebavP,Z83rChqtg1oXUjI4YL)
	wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H
	return WjryKiBebavP
def mkOVAYGJNI96SEWeU(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo):
	EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
	PPB0Jlbxuf2RiWdnpAGS1eZt8H = wAcHkmPB8a.menuItemsLIST
	wAcHkmPB8a.menuItemsLIST[:] = []
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC and TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ᷇") not in N1FbhV4lx6QcWOo:
		WjryKiBebavP = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,ne7wF4gSTRZo(u"ࠨ࡮࡬ࡷࡹ࠭᷈"),KJLkQsqSHMR1Np2(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ᷉"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡ᷊ࠪ")+To1jOLBdtPWhFayp)
	elif ne7wF4gSTRZo(u"ࠫࡤࡒࡉࡗࡇࡢࠫ᷋") not in N1FbhV4lx6QcWOo or nJF7oflOk6cLGSAey(u"ࠬࡥࡖࡐࡆࡢࠫ᷌") not in N1FbhV4lx6QcWOo:
		import yYCGB8hzwT
		H7fCeh95oEyapvUl4itZDm2Njdx6z = YZXtBgvUPoM5sb(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫ᷍")
		if FAwWlRJg0UkN1(u"ࠧࡠࡎࡌ࡚ࡊࡥ᷎ࠧ") not in N1FbhV4lx6QcWOo:
			try: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ᷏ࠧ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+iiLyoNwGbH03DIXhAkZn(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᷐ࠧ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,TeYukOUW7i5NBM926DCjaAn0(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ᷑"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ᷒"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+i80mE7lHUwVk(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷓ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,iiauUxMktNW5X(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᷔ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᷕ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷖ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,RRbvqditj184m3(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᷗ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if iI7tuF0nEQoR(u"ࠪࡣ࡛ࡕࡄࡠࠩᷘ") not in N1FbhV4lx6QcWOo:
			try: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,YZXtBgvUPoM5sb(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᷙ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+BarIC3eR9bS(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷚ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪᷛ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
			try: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(To1jOLBdtPWhFayp,YZXtBgvUPoM5sb(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᷜ"),gby0BnUuTNFk,gby0BnUuTNFk,N1FbhV4lx6QcWOo+MlTVLBZ92kzorIq1Yw(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷝ"),yrcbRSFswvAfEdIWVj)
			except: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᷞ"),H7fCeh95oEyapvUl4itZDm2Njdx6z)
		WjryKiBebavP = wAcHkmPB8a.menuItemsLIST
		if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,n6JjFHfmydIaLut(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᷟ"),iI7tuF0nEQoR(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫᷠ")+To1jOLBdtPWhFayp,WjryKiBebavP,Z83rChqtg1oXUjI4YL)
	wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H
	return WjryKiBebavP
def wFcArN5U4x2Mu6VOGeR9hn7KfkPZiX(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo,SUFhKauDvdecfmQVT7yJE61HLjspoI):
	zyZYjwM8GFn(MjwcelItRYVzaPG9QFs1yvSrD74A,MjwcelItRYVzaPG9QFs1yvSrD74A,qrejGtHg2Z)
	if SUFhKauDvdecfmQVT7yJE61HLjspoI: rYfVJAbIE3(yrcbRSFswvAfEdIWVj)
	elif YZXtBgvUPoM5sb(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᷡ") in N1FbhV4lx6QcWOo and not SUFhKauDvdecfmQVT7yJE61HLjspoI: rYfVJAbIE3(w8Ui6RsVhSPrqHfO4)
	RmCPEfdwqNMZu = N1FbhV4lx6QcWOo.replace(MlTVLBZ92kzorIq1Yw(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᷢ"),gby0BnUuTNFk).replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᷣ"),gby0BnUuTNFk).replace(NupI74tJCzYXmles9SbR6(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᷤ"),gby0BnUuTNFk)
	if not SUFhKauDvdecfmQVT7yJE61HLjspoI:
		ygWIQGf25qwVxLkXrYDjp(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩ࡯࡭ࡳࡱࠧᷥ"),ne7wF4gSTRZo(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡษ็ว็ูวๆࠩᷦ"),gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"࠹࠹࠷Ὗ"),gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᷧ")+RmCPEfdwqNMZu,gby0BnUuTNFk,{q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷨ"):To1jOLBdtPWhFayp})
		ygWIQGf25qwVxLkXrYDjp(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭࡬ࡪࡰ࡮ࠫᷩ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+RRbvqditj184m3(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᷪ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"࠼࠽࠾࠿ὠ"))
		joAn4ETVPG81bXNRyHfBFiaxZgLs = [IXE6voNmrb182AyQ(u"ࠨลไ่ฬ๋ࠧᷫ"),n6JjFHfmydIaLut(u"่ࠩืู้ไศฬࠪᷬ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ุ้ࠪือ๋ษอࠫᷭ"),YZXtBgvUPoM5sb(u"ࠫอืวๆฮࠪᷮ"),NupI74tJCzYXmles9SbR6(u"ࠬษืโษ็ࠤํ้ัห๊้ࠫᷯ"),nJF7oflOk6cLGSAey(u"࠭ัๆุส๊ࠬᷰ"),mmbcsf2pd7gyjzreB(u"ࠧฤฯาฯ࠲ษฮาࠩᷱ"),n6JjFHfmydIaLut(u"ࠨี็หุ๊ࠧᷲ"),iiLyoNwGbH03DIXhAkZn(u"่ࠩ์ุ๐โ๊ࠩᷳ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪวูํั࠮ลๆฯึ࠭ᷴ"),nJF7oflOk6cLGSAey(u"ࠫฬ๊ย็ࠩ᷵"),BarIC3eR9bS(u"ࠬ฼อไࠩ᷶"),TeYukOUW7i5NBM926DCjaAn0(u"࠭ั๋ษูอ᷷ࠬ"),ne7wF4gSTRZo(u"ࠧ็์อๅ้้ำࠨ᷸"),iI7tuF0nEQoR(u"ࠨ็่ฯ้๐ๆࠨ᷹"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩหฯࠥำ๊ࠨ᷺"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠪำ๏์๊สࠩ᷻"),nJF7oflOk6cLGSAey(u"ุࠫ์่ศฬࠪ᷼"),iI7tuF0nEQoR(u"ࠬษฮา๋᷽ࠪ")]
		SUFhKauDvdecfmQVT7yJE61HLjspoI = xn867tCVlscY4qbWZfh
		for WWy5N3DPLsive in joAn4ETVPG81bXNRyHfBFiaxZgLs:
			SUFhKauDvdecfmQVT7yJE61HLjspoI += jxCVeKSLb9rGDOl0Qtw6
			ygWIQGf25qwVxLkXrYDjp(q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᷾"),JB9fyoHr05QOtPjp+WWy5N3DPLsive,gby0BnUuTNFk,RRbvqditj184m3(u"࠻࠻࠹ὡ"),gby0BnUuTNFk,str(SUFhKauDvdecfmQVT7yJE61HLjspoI),RmCPEfdwqNMZu,gby0BnUuTNFk,{i80mE7lHUwVk(u"ࠧࡧࡱ࡯ࡨࡪࡸ᷿ࠧ"):To1jOLBdtPWhFayp})
	else:
		iAd2R3kGOopQuhyTaUZzf4mCt = [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨษไ่ฬ๋ࠧḀ"),iI7tuF0nEQoR(u"ࠩࡰࡳࡻ࡯ࡥࠨḁ"),i80mE7lHUwVk(u"ࠪๅ๏๊ๅࠨḂ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫๆ๊ๅࠨḃ")]
		S2urBMEk9V4v3sjeK = [n6JjFHfmydIaLut(u"๋ࠬำๅี็ࠫḄ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ḅ")]
		TkoQhEZ7lgBm8d = [TeYukOUW7i5NBM926DCjaAn0(u"ࠧๆีสีา࠭Ḇ"),VzO1gCHmjZ2ebRIL(u"ࠨ็ึีา๐วหࠩḇ")]
		uCRPNk7Vl4AFg61Mzi8U0X9xemB2oh = [lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩหีฬ๋ฬࠨḈ"),MlTVLBZ92kzorIq1Yw(u"ࠪࡷ࡭ࡵࡷࠨḉ"),ne7wF4gSTRZo(u"ࠫฯ๊แำ์๋๊ࠬḊ"),ggtuNcvTn3HQ7SpE2(u"ࠬะไ๋ใี๎ํ์ࠧḋ")]
		hVTEbOPqz42jRsfxveyoNJw9liD = [VzO1gCHmjZ2ebRIL(u"࠭ว็็ํࠫḌ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧไำอ์๋࠭ḍ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨๅสีฯ๎ๆࠨḎ"),mmbcsf2pd7gyjzreB(u"ࠩ࡮࡭ࡩࡹࠧḏ"),VzO1gCHmjZ2ebRIL(u"ࠪ฻ๆ๊ࠧḐ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫฬ฽แศๆࠪḑ")]
		TqoQ3npgBuNcK = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬืๅืษ้ࠫḒ")]
		rjyJx1X2wZN = [TeYukOUW7i5NBM926DCjaAn0(u"࠭วฮัฮࠫḓ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧศะิࠫḔ"),IXE6voNmrb182AyQ(u"ࠨ็๋าึ࠭ḕ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩฯำ๏ีࠧḖ"),mmbcsf2pd7gyjzreB(u"้ࠪ฻อแࠨḗ"),VzO1gCHmjZ2ebRIL(u"ࠫาี๊ฬࠩḘ")]
		DHLZvX36hwnfOlUpxKViu2BYqr7 = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ูࠬไศี็ࠫḙ"),mmbcsf2pd7gyjzreB(u"࠭ำๅี็๋ࠬḚ")]
		Z95J87PwUFWONvL = [lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧศ฼ส๊๏࠭ḛ"),BarIC3eR9bS(u"ࠨ็๋ื๏่้ࠨḜ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩๆ่๏ฮࠧḝ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪัๆ๊ࠧḞ"),FAwWlRJg0UkN1(u"ࠫࡲࡻࡳࡪࡥࠪḟ")]
		kX7ZnSzVBwKe0NoIT8dh = [ggtuNcvTn3HQ7SpE2(u"ࠬอใฬำࠪḠ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭วี้ิࠫḡ"),YZXtBgvUPoM5sb(u"ࠧๆ็ํึ์࠭Ḣ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨษ฼่๎࠭ḣ"),iiLyoNwGbH03DIXhAkZn(u"่ࠩาฯอั่ࠩḤ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"้ࠪำะวาษอࠫḥ"),RRbvqditj184m3(u"ࠫฬ่่๊ࠩḦ")]
		xRlKt9XmQ2yzkI0ahD4CfLF8vs6 = [iI7tuF0nEQoR(u"ࠬอไศ่ࠪḧ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭อศๆํࠫḨ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧๆอหฮࠬḩ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨำสสั࠭Ḫ")]
		job2CP1zVw7 = [tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ูࠩั่࠭ḫ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠪ็ํ๋๊ะ์ࠪḬ")]
		riCsD3oxuGzfT0y264JX = [zDSw8LCxMQyraeXhojIWKmU(u"ࠫึ๐วื้ࠪḭ"),OUFxZPuXDoGAbRz(u"้่ࠬา้ࠪḮ"),nJF7oflOk6cLGSAey(u"࠭ๅึษิ฽์࠭ḯ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧี๊อࠫḰ"),KJLkQsqSHMR1Np2(u"ࠨำํห฻ฯࠧḱ")]
		p1vcSJ3fFqWZbsoNjgk8h7mUnDEPIa = [IXE6voNmrb182AyQ(u"้ࠩ๎ฯ็ไไีࠪḲ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫḳ"),MlTVLBZ92kzorIq1Yw(u"๋ࠫ๐สโๆํ็ุ࠭Ḵ")]
		oTJzYI8FrdEjiGVD91b27W4ONcnLf = [mmbcsf2pd7gyjzreB(u"๋ࠬๅฬๆํ๊ࠬḵ"),Ducd5PRjQXaB9SIN7VrJ1G(u"࠭วีะสูࠬḶ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧ็ฮ๋้ࠬḷ")]
		fZiYAJH1PcQI2O6LyX4rgT9au8l = [NupI74tJCzYXmles9SbR6(u"ࠨสฮࠤา๐ࠧḸ"),ne7wF4gSTRZo(u"ࠩ࡯࡭ࡻ࡫ࠧḹ"),iiauUxMktNW5X(u"ࠪๆ๋อ็ࠨḺ"),NupI74tJCzYXmles9SbR6(u"ࠫ็์่ศฬࠪḻ")]
		peX1xAakQPZ0SqVD3 = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬี๊็ࠩḼ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭วะ฻ํ๋ࠬḽ"),nJF7oflOk6cLGSAey(u"ࠧำ์สีฬะࠧḾ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨๆฺ้๏อสࠨḿ"),MlTVLBZ92kzorIq1Yw(u"ࠩา฽ฬวࠧṀ"),nJF7oflOk6cLGSAey(u"ࠪๆึอๆࠨṁ"),VzO1gCHmjZ2ebRIL(u"ࠫ็฻ววัࠪṂ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬืหศรࠪṃ"),IXE6voNmrb182AyQ(u"࠭ๅาฮ฼๎์࠭Ṅ"),iI7tuF0nEQoR(u"ࠧศาส๊ࠬṅ"),NupI74tJCzYXmles9SbR6(u"ࠨษึ่ฬ๋ࠧṆ"),ggtuNcvTn3HQ7SpE2(u"ࠩอ์ฬฺ๊ฮࠩṇ"),VzO1gCHmjZ2ebRIL(u"ࠪา฼ฮࠧṈ"),nJF7oflOk6cLGSAey(u"ࠫา๎า้์ࠪṉ"),YZXtBgvUPoM5sb(u"ࠬ฿สษษอࠫṊ"),zDSw8LCxMQyraeXhojIWKmU(u"࠭ๅ้ษ็๎ิ࠭ṋ"),ne7wF4gSTRZo(u"ࠧ็๊ส฽๏࠭Ṍ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨ฻ๅหหีࠧṍ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠩส๊ฬฺ๊ะࠩṎ")]
		oo4JqIwle2AQDtxF5U6 = [iI7tuF0nEQoR(u"ࠪ࠶࠵࠷࠰ࠨṏ"),mmbcsf2pd7gyjzreB(u"ࠫ࠷࠶࠱࠲ࠩṐ"),NupI74tJCzYXmles9SbR6(u"ࠬ࠸࠰࠲࠴ࠪṑ"),VzO1gCHmjZ2ebRIL(u"࠭࠲࠱࠳࠶ࠫṒ"),iI7tuF0nEQoR(u"ࠧ࠳࠲࠴࠸ࠬṓ"),ggtuNcvTn3HQ7SpE2(u"ࠨ࠴࠳࠵࠺࠭Ṕ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩ࠵࠴࠶࠼ࠧṕ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪ࠶࠵࠷࠷ࠨṖ"),i80mE7lHUwVk(u"ࠫ࠷࠶࠱࠹ࠩṗ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࠸࠰࠲࠻ࠪṘ"),iiauUxMktNW5X(u"࠭࠲࠱࠴࠳ࠫṙ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧ࠳࠲࠵࠵ࠬṚ"),KJLkQsqSHMR1Np2(u"ࠨ࠴࠳࠶࠷࠭ṛ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩ࠵࠴࠷࠹ࠧṜ"),mmbcsf2pd7gyjzreB(u"ࠪ࠶࠵࠸࠴ࠨṝ"),BarIC3eR9bS(u"ࠫ࠷࠶࠲࠶ࠩṞ"),iI7tuF0nEQoR(u"ࠬ࠸࠰࠳࠸ࠪṟ"),KJLkQsqSHMR1Np2(u"࠭࠲࠱࠴࠺ࠫṠ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧ࠳࠲࠵࠼ࠬṡ")]
		for DPkEMfnRe82d in sorted(list(PwBW3hUyG7osmXJ5NivCEt1R0AM.keys())):
			sMiRfjzPx90H8mEpD = DPkEMfnRe82d.lower()
			zTFlfH8DhAVryqUjX = []
			if any(value in sMiRfjzPx90H8mEpD for value in iAd2R3kGOopQuhyTaUZzf4mCt): zTFlfH8DhAVryqUjX.append(jxCVeKSLb9rGDOl0Qtw6)
			if any(value in sMiRfjzPx90H8mEpD for value in S2urBMEk9V4v3sjeK): zTFlfH8DhAVryqUjX.append(dNx9DVCtafk4r)
			if any(value in sMiRfjzPx90H8mEpD for value in TkoQhEZ7lgBm8d): zTFlfH8DhAVryqUjX.append(jJ4LEcdl5w7BPMbQ)
			if any(value in sMiRfjzPx90H8mEpD for value in uCRPNk7Vl4AFg61Mzi8U0X9xemB2oh): zTFlfH8DhAVryqUjX.append(z5RruqXvsLaTf7e9c)
			if any(value in sMiRfjzPx90H8mEpD for value in hVTEbOPqz42jRsfxveyoNJw9liD): zTFlfH8DhAVryqUjX.append(DVbaycS5iITnPMRsdueXqg1wQx6ltr)
			if any(value in sMiRfjzPx90H8mEpD for value in TqoQ3npgBuNcK): zTFlfH8DhAVryqUjX.append(KJLkQsqSHMR1Np2(u"࠻ὢ"))
			if any(value in sMiRfjzPx90H8mEpD for value in rjyJx1X2wZN) and sMiRfjzPx90H8mEpD not in [uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨษัี๎࠭Ṣ")]: zTFlfH8DhAVryqUjX.append(MlTVLBZ92kzorIq1Yw(u"࠽ὣ"))
			if any(value in sMiRfjzPx90H8mEpD for value in DHLZvX36hwnfOlUpxKViu2BYqr7): zTFlfH8DhAVryqUjX.append(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠸ὤ"))
			if any(value in sMiRfjzPx90H8mEpD for value in Z95J87PwUFWONvL): zTFlfH8DhAVryqUjX.append(iiauUxMktNW5X(u"࠺ὥ"))
			if any(value in sMiRfjzPx90H8mEpD for value in kX7ZnSzVBwKe0NoIT8dh): zTFlfH8DhAVryqUjX.append(VzO1gCHmjZ2ebRIL(u"࠳࠳ὦ"))
			if any(value in sMiRfjzPx90H8mEpD for value in xRlKt9XmQ2yzkI0ahD4CfLF8vs6): zTFlfH8DhAVryqUjX.append(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠴࠵ὧ"))
			if any(value in sMiRfjzPx90H8mEpD for value in job2CP1zVw7): zTFlfH8DhAVryqUjX.append(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠵࠷Ὠ"))
			if any(value in sMiRfjzPx90H8mEpD for value in riCsD3oxuGzfT0y264JX): zTFlfH8DhAVryqUjX.append(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠶࠹Ὡ"))
			if any(value in sMiRfjzPx90H8mEpD for value in p1vcSJ3fFqWZbsoNjgk8h7mUnDEPIa): zTFlfH8DhAVryqUjX.append(nJF7oflOk6cLGSAey(u"࠷࠴Ὢ"))
			if any(value in sMiRfjzPx90H8mEpD for value in oTJzYI8FrdEjiGVD91b27W4ONcnLf): zTFlfH8DhAVryqUjX.append(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠱࠶Ὣ"))
			if any(value in sMiRfjzPx90H8mEpD for value in fZiYAJH1PcQI2O6LyX4rgT9au8l): zTFlfH8DhAVryqUjX.append(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠲࠸Ὤ"))
			if any(value in sMiRfjzPx90H8mEpD for value in peX1xAakQPZ0SqVD3): zTFlfH8DhAVryqUjX.append(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠳࠺Ὥ"))
			if any(value in sMiRfjzPx90H8mEpD for value in oo4JqIwle2AQDtxF5U6): zTFlfH8DhAVryqUjX.append(TeYukOUW7i5NBM926DCjaAn0(u"࠴࠼Ὦ"))
			if not zTFlfH8DhAVryqUjX: zTFlfH8DhAVryqUjX = [oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠵࠾Ὧ")]
			for FTZOc0As483 in zTFlfH8DhAVryqUjX:
				if str(FTZOc0As483)==SUFhKauDvdecfmQVT7yJE61HLjspoI:
					ygWIQGf25qwVxLkXrYDjp(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡩࡳࡱࡪࡥࡳࠩṣ"),JB9fyoHr05QOtPjp+DPkEMfnRe82d,DPkEMfnRe82d,mmbcsf2pd7gyjzreB(u"࠶࠼࠶ὰ"),gby0BnUuTNFk,gby0BnUuTNFk,RmCPEfdwqNMZu+n6JjFHfmydIaLut(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṤ"))
	zyZYjwM8GFn(MjwcelItRYVzaPG9QFs1yvSrD74A,MjwcelItRYVzaPG9QFs1yvSrD74A,H14j5s97qxM)
	return
def dz5u61aRXkfgNCHq(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo):
	EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC:
		ygWIQGf25qwVxLkXrYDjp(BarIC3eR9bS(u"ࠫࡱ࡯࡮࡬ࠩṥ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧṦ"),gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠽࠶࠵ά"),gby0BnUuTNFk,gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫṧ"),gby0BnUuTNFk,{GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṨ"):To1jOLBdtPWhFayp})
		ygWIQGf25qwVxLkXrYDjp(i80mE7lHUwVk(u"ࠨ࡮࡬ࡲࡰ࠭ṩ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+iI7tuF0nEQoR(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧṪ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠹࠺࠻࠼ὲ"))
	PPB0Jlbxuf2RiWdnpAGS1eZt8H = wAcHkmPB8a.menuItemsLIST[:]
	import BBhJgplbfL
	if To1jOLBdtPWhFayp:
		if not BBhJgplbfL.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(To1jOLBdtPWhFayp,w8Ui6RsVhSPrqHfO4): return
		I6o4E51WlT3J2P7HC = tcWLgqTQs8V3Aw(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo)
		ReBKsmpDSTAkwQnjghx20cbrUo84 = sorted(I6o4E51WlT3J2P7HC,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6].lower())
	else:
		if not BBhJgplbfL.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
		if EyaNdiZUtzq2rMulW9JL1ITHP3fgC and iiLyoNwGbH03DIXhAkZn(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨṫ") not in N1FbhV4lx6QcWOo:
			ReBKsmpDSTAkwQnjghx20cbrUo84 = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡱ࡯ࡳࡵࠩṬ"),q2qPkMFpR1G86dEAKXHivor9N(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬṭ"),i80mE7lHUwVk(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪṮ"))
		else:
			iiQuUnztexVMa,ReBKsmpDSTAkwQnjghx20cbrUo84,I6o4E51WlT3J2P7HC = [],[],[]
			for RXSYx9fwk0yETFjHCAJ3r7qlOBs8 in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
				ReBKsmpDSTAkwQnjghx20cbrUo84 += tcWLgqTQs8V3Aw(str(RXSYx9fwk0yETFjHCAJ3r7qlOBs8),N1FbhV4lx6QcWOo)
			for type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in ReBKsmpDSTAkwQnjghx20cbrUo84:
				if fbmZ9V58PCTz not in iiQuUnztexVMa:
					iiQuUnztexVMa.append(fbmZ9V58PCTz)
					IIFOQ2qyoje50nWlA = type,DPkEMfnRe82d,fbmZ9V58PCTz,iiauUxMktNW5X(u"࠲࠸࠸έ"),gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,N1FbhV4lx6QcWOo,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF
					I6o4E51WlT3J2P7HC.append(IIFOQ2qyoje50nWlA)
			ReBKsmpDSTAkwQnjghx20cbrUo84 = sorted(I6o4E51WlT3J2P7HC,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6].lower())
			if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,n6JjFHfmydIaLut(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧṯ"),NupI74tJCzYXmles9SbR6(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬṰ"),ReBKsmpDSTAkwQnjghx20cbrUo84,Z83rChqtg1oXUjI4YL)
	wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84
	nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def zNM39KuPBf2qOCSR(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo):
	EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC:
		ygWIQGf25qwVxLkXrYDjp(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࡯࡭ࡳࡱࠧṱ"),i80mE7lHUwVk(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡎ࠵ࡘࠫṲ"),gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠹࠹࠹ὴ"),gby0BnUuTNFk,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṳ"),gby0BnUuTNFk,{GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṴ"):To1jOLBdtPWhFayp})
		ygWIQGf25qwVxLkXrYDjp(YZXtBgvUPoM5sb(u"࠭࡬ࡪࡰ࡮ࠫṵ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+VzO1gCHmjZ2ebRIL(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṶ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,n6JjFHfmydIaLut(u"࠼࠽࠾࠿ή"))
	PPB0Jlbxuf2RiWdnpAGS1eZt8H = wAcHkmPB8a.menuItemsLIST[:]
	import yYCGB8hzwT
	if To1jOLBdtPWhFayp:
		if not yYCGB8hzwT.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(To1jOLBdtPWhFayp,w8Ui6RsVhSPrqHfO4): return
		I6o4E51WlT3J2P7HC = mkOVAYGJNI96SEWeU(To1jOLBdtPWhFayp,N1FbhV4lx6QcWOo)
		ReBKsmpDSTAkwQnjghx20cbrUo84 = sorted(I6o4E51WlT3J2P7HC,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6].lower())
	else:
		if not yYCGB8hzwT.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
		if EyaNdiZUtzq2rMulW9JL1ITHP3fgC and q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ṷ") not in N1FbhV4lx6QcWOo:
			ReBKsmpDSTAkwQnjghx20cbrUo84 = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,zDSw8LCxMQyraeXhojIWKmU(u"ࠩ࡯࡭ࡸࡺࠧṸ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩṹ"),ne7wF4gSTRZo(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧṺ"))
		else:
			iiQuUnztexVMa,ReBKsmpDSTAkwQnjghx20cbrUo84,I6o4E51WlT3J2P7HC = [],[],[]
			for RXSYx9fwk0yETFjHCAJ3r7qlOBs8 in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
				ReBKsmpDSTAkwQnjghx20cbrUo84 += mkOVAYGJNI96SEWeU(str(RXSYx9fwk0yETFjHCAJ3r7qlOBs8),N1FbhV4lx6QcWOo)
			for type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in ReBKsmpDSTAkwQnjghx20cbrUo84:
				if fbmZ9V58PCTz not in iiQuUnztexVMa:
					iiQuUnztexVMa.append(fbmZ9V58PCTz)
					IIFOQ2qyoje50nWlA = type,DPkEMfnRe82d,fbmZ9V58PCTz,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠵࠻࠻ὶ"),gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,N1FbhV4lx6QcWOo,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF
					I6o4E51WlT3J2P7HC.append(IIFOQ2qyoje50nWlA)
			ReBKsmpDSTAkwQnjghx20cbrUo84 = sorted(I6o4E51WlT3J2P7HC,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6].lower())
			if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,YZXtBgvUPoM5sb(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫṻ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩṼ"),ReBKsmpDSTAkwQnjghx20cbrUo84,Z83rChqtg1oXUjI4YL)
	wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84
	nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def ssNzu0Qm14ZtnFdoE(group,N1FbhV4lx6QcWOo):
	EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
	WjryKiBebavP = []
	kNazVPSlywenAsc6rOGYI = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧṽ") if ne7wF4gSTRZo(u"ࠨࡋࡓࡘ࡛࠭Ṿ") in N1FbhV4lx6QcWOo else IXE6voNmrb182AyQ(u"ࠩࡢࡑ࠸࡛࡟ࠨṿ")
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: WjryKiBebavP = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,iiLyoNwGbH03DIXhAkZn(u"ࠪࡰ࡮ࡹࡴࠨẀ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭ẁ")+kNazVPSlywenAsc6rOGYI[:-jxCVeKSLb9rGDOl0Qtw6],group)
	if not WjryKiBebavP:
		for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
			if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: WjryKiBebavP += hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,i80mE7lHUwVk(u"ࠬࡲࡩࡴࡶࠪẂ"),ggtuNcvTn3HQ7SpE2(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨẃ")+kNazVPSlywenAsc6rOGYI[:-jxCVeKSLb9rGDOl0Qtw6],DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩẄ")+kNazVPSlywenAsc6rOGYI+str(To1jOLBdtPWhFayp))
			elif kNazVPSlywenAsc6rOGYI==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨẅ"): WjryKiBebavP += tcWLgqTQs8V3Aw(str(To1jOLBdtPWhFayp),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧẆ"))
			elif kNazVPSlywenAsc6rOGYI==TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡣࡒ࠹ࡕࡠࠩẇ"): WjryKiBebavP += mkOVAYGJNI96SEWeU(str(To1jOLBdtPWhFayp),iiauUxMktNW5X(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩẈ"))
		for type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in WjryKiBebavP:
			if fbmZ9V58PCTz==group: nnHojZ4NcvVXhU0uzCw3OGEQrJ(type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
		items,vv7qYWmFwzBPofI5e2ls = [],[]
		for type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in wAcHkmPB8a.menuItemsLIST:
			XvYWor3zfCAHKJkgsmq7U5uG = type,DPkEMfnRe82d[z5RruqXvsLaTf7e9c:],url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,gby0BnUuTNFk
			if XvYWor3zfCAHKJkgsmq7U5uG not in vv7qYWmFwzBPofI5e2ls:
				vv7qYWmFwzBPofI5e2ls.append(XvYWor3zfCAHKJkgsmq7U5uG)
				BoRk2n4aEtT3cKL08HPhUO = type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF
				items.append(BoRk2n4aEtT3cKL08HPhUO)
		WjryKiBebavP = sorted(items,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6].lower()[ggtuNcvTn3HQ7SpE2(u"࠺ί"):])
		if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,iI7tuF0nEQoR(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧẉ")+kNazVPSlywenAsc6rOGYI[:-jxCVeKSLb9rGDOl0Qtw6],group,WjryKiBebavP,Z83rChqtg1oXUjI4YL)
	if ne7wF4gSTRZo(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨẊ") in N1FbhV4lx6QcWOo and len(WjryKiBebavP)>GGCyzqHVFWKjRch:
		wAcHkmPB8a.menuItemsLIST[:] = []
		ygWIQGf25qwVxLkXrYDjp(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẋ"),FAwWlRJg0UkN1(u"ࠨ࡝ࠪẌ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+group+GGy0cQe765nPYZ9E8Th+ne7wF4gSTRZo(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫẍ"),group,ne7wF4gSTRZo(u"࠷࠶࠶ὸ"),gby0BnUuTNFk,gby0BnUuTNFk,kNazVPSlywenAsc6rOGYI+iI7tuF0nEQoR(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẎ"))
		ygWIQGf25qwVxLkXrYDjp(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẏ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫẐ"),group,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠱࠷࠷ό"),gby0BnUuTNFk,gby0BnUuTNFk,kNazVPSlywenAsc6rOGYI+mmbcsf2pd7gyjzreB(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬẑ"))
		ygWIQGf25qwVxLkXrYDjp(iiLyoNwGbH03DIXhAkZn(u"ࠧ࡭࡫ࡱ࡯ࠬẒ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+OUFxZPuXDoGAbRz(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ẓ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠺࠻࠼࠽ὺ"))
		WjryKiBebavP = wAcHkmPB8a.menuItemsLIST+l8YH46ObxQJTk1.sample(WjryKiBebavP,GGCyzqHVFWKjRch)
	wAcHkmPB8a.menuItemsLIST[:] = WjryKiBebavP
	nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def l29uxntUGA(N1FbhV4lx6QcWOo):
	ygWIQGf25qwVxLkXrYDjp(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡩࡳࡱࡪࡥࡳࠩẔ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭ẕ"),gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"࠳࠹࠵ύ"),gby0BnUuTNFk,gby0BnUuTNFk,nJF7oflOk6cLGSAey(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫẖ"))
	ygWIQGf25qwVxLkXrYDjp(IXE6voNmrb182AyQ(u"ࠬࡲࡩ࡯࡭ࠪẗ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+q2qPkMFpR1G86dEAKXHivor9N(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẘ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"࠼࠽࠾࠿ὼ"))
	TJpMAUdoIkV9hizXa = wAcHkmPB8a.menuItemsLIST[:]
	wAcHkmPB8a.menuItemsLIST[:] = []
	import MdsDcCgOkL
	MdsDcCgOkL.O5XxuEh689Mvoq1Rnesl(iiauUxMktNW5X(u"ࠧ࠱ࠩẙ"),yrcbRSFswvAfEdIWVj)
	MdsDcCgOkL.O5XxuEh689Mvoq1Rnesl(BarIC3eR9bS(u"ࠨ࠳ࠪẚ"),yrcbRSFswvAfEdIWVj)
	MdsDcCgOkL.O5XxuEh689Mvoq1Rnesl(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩ࠵ࠫẛ"),yrcbRSFswvAfEdIWVj)
	if NupI74tJCzYXmles9SbR6(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬẜ") in N1FbhV4lx6QcWOo:
		wAcHkmPB8a.menuItemsLIST[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
		if len(wAcHkmPB8a.menuItemsLIST)>GGCyzqHVFWKjRch: wAcHkmPB8a.menuItemsLIST[:] = l8YH46ObxQJTk1.sample(wAcHkmPB8a.menuItemsLIST,GGCyzqHVFWKjRch)
	wAcHkmPB8a.menuItemsLIST[:] = TJpMAUdoIkV9hizXa+wAcHkmPB8a.menuItemsLIST
	return
def vvSalsRhmq(N1FbhV4lx6QcWOo):
	N1FbhV4lx6QcWOo = N1FbhV4lx6QcWOo.replace(FAwWlRJg0UkN1(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẝ"),gby0BnUuTNFk).replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẞ"),gby0BnUuTNFk)
	headers = { KJLkQsqSHMR1Np2(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪẟ") : gby0BnUuTNFk }
	url = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭Ạ")
	data = {YZXtBgvUPoM5sb(u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪạ"):lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩ࠸࠴ࠬẢ")}
	data = Atv9rwjEMV7acSCxosyhQnF(data)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(ECtBvFXOLM,BarIC3eR9bS(u"ࠪࡋࡊ࡚ࠧả"),url,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭Ấ"))
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iiLyoNwGbH03DIXhAkZn(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧấ"),jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫẦ"),AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	FNa1tfIJZnCAWT3MyKxVQEPz7,AJ4r16T3gmiBZyL2QlNtRHd7Ikh = list(zip(*items))
	a0AHmy6Uq4V2cW5KMSXujCgQF3 = []
	ZXqhg38mWrkK = [UpN1CezytPO9XoduhxZSD,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࠣࠩầ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡢࠪẨ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࠯ࠫẩ"),RRbvqditj184m3(u"ࠪ࠲ࠬẪ"),YZXtBgvUPoM5sb(u"ࠫ࠿࠭ẫ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡁࠧẬ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࠧࠣậ"),mmbcsf2pd7gyjzreB(u"ࠧ࠮ࠩẮ")]
	HiM0mrvW97FJc2b8TnkCusQKDgLw5Z = AJ4r16T3gmiBZyL2QlNtRHd7Ikh+FNa1tfIJZnCAWT3MyKxVQEPz7
	for q74czO5ixFJebQt2u1BS in HiM0mrvW97FJc2b8TnkCusQKDgLw5Z:
		if q74czO5ixFJebQt2u1BS in AJ4r16T3gmiBZyL2QlNtRHd7Ikh: Q64QA0ahSxVv = dNx9DVCtafk4r
		if q74czO5ixFJebQt2u1BS in FNa1tfIJZnCAWT3MyKxVQEPz7: Q64QA0ahSxVv = z5RruqXvsLaTf7e9c
		CL6MoPgWi91eVhtqaUymT = [xuX6UN0WRQbHArDV in q74czO5ixFJebQt2u1BS for xuX6UN0WRQbHArDV in ZXqhg38mWrkK]
		if any(CL6MoPgWi91eVhtqaUymT):
			xYDJcGlC5PSFpRaX03nLNjZO2Uqum = CL6MoPgWi91eVhtqaUymT.index(w8Ui6RsVhSPrqHfO4)
			B236BxJZTcDgCNs8 = ZXqhg38mWrkK[xYDJcGlC5PSFpRaX03nLNjZO2Uqum]
			YbKsGmorH0wJvzfMAFjc3BU2xTR6pZ = gby0BnUuTNFk
			if q74czO5ixFJebQt2u1BS.count(B236BxJZTcDgCNs8)>jxCVeKSLb9rGDOl0Qtw6: B1GZvpntDNEfWdMhKIo8r0,vOPEjbSFg6ikQfdHsYUtVRcNLruXa,YbKsGmorH0wJvzfMAFjc3BU2xTR6pZ = q74czO5ixFJebQt2u1BS.split(B236BxJZTcDgCNs8,dNx9DVCtafk4r)
			else: B1GZvpntDNEfWdMhKIo8r0,vOPEjbSFg6ikQfdHsYUtVRcNLruXa = q74czO5ixFJebQt2u1BS.split(B236BxJZTcDgCNs8,jxCVeKSLb9rGDOl0Qtw6)
			if len(B1GZvpntDNEfWdMhKIo8r0)>Q64QA0ahSxVv: a0AHmy6Uq4V2cW5KMSXujCgQF3.append(B1GZvpntDNEfWdMhKIo8r0.lower())
			if len(vOPEjbSFg6ikQfdHsYUtVRcNLruXa)>Q64QA0ahSxVv: a0AHmy6Uq4V2cW5KMSXujCgQF3.append(vOPEjbSFg6ikQfdHsYUtVRcNLruXa.lower())
			if len(YbKsGmorH0wJvzfMAFjc3BU2xTR6pZ)>Q64QA0ahSxVv: a0AHmy6Uq4V2cW5KMSXujCgQF3.append(YbKsGmorH0wJvzfMAFjc3BU2xTR6pZ.lower())
		elif len(q74czO5ixFJebQt2u1BS)>Q64QA0ahSxVv: a0AHmy6Uq4V2cW5KMSXujCgQF3.append(q74czO5ixFJebQt2u1BS.lower())
	for xuX6UN0WRQbHArDV in range(TeYukOUW7i5NBM926DCjaAn0(u"࠽ώ")): l8YH46ObxQJTk1.shuffle(a0AHmy6Uq4V2cW5KMSXujCgQF3)
	if OUFxZPuXDoGAbRz(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩắ") in N1FbhV4lx6QcWOo:
		sxS9K72jDU = mVkdN4u5U7fSnF6z8TDI3q
	elif sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩẰ") in N1FbhV4lx6QcWOo:
		sxS9K72jDU = [VzO1gCHmjZ2ebRIL(u"ࠪࡍࡕ࡚ࡖࠨằ")]
		import BBhJgplbfL
		if not BBhJgplbfL.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
	elif ne7wF4gSTRZo(u"ࠫࡤࡓ࠳ࡖࡡࠪẲ") in N1FbhV4lx6QcWOo:
		sxS9K72jDU = [YZXtBgvUPoM5sb(u"ࠬࡓ࠳ࡖࠩẳ")]
		import yYCGB8hzwT
		if not yYCGB8hzwT.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
	count,NnWxOSjhBmt8YL = xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
	ygWIQGf25qwVxLkXrYDjp(i80mE7lHUwVk(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ẵ"),MlTVLBZ92kzorIq1Yw(u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨẵ"),gby0BnUuTNFk,iI7tuF0nEQoR(u"࠶࠼࠴὾"),gby0BnUuTNFk,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ặ")+N1FbhV4lx6QcWOo)
	ygWIQGf25qwVxLkXrYDjp(IXE6voNmrb182AyQ(u"ࠩࡩࡳࡱࡪࡥࡳࠩặ"),iiLyoNwGbH03DIXhAkZn(u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪẸ"),gby0BnUuTNFk,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠷࠶࠵὿"),gby0BnUuTNFk,gby0BnUuTNFk,iiauUxMktNW5X(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẹ")+N1FbhV4lx6QcWOo)
	ygWIQGf25qwVxLkXrYDjp(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡲࡩ࡯࡭ࠪẺ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+OUFxZPuXDoGAbRz(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẻ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠹࠺࠻࠼ᾀ"))
	f58z9SaNhFLsIilmYb071eDAwcWg = wAcHkmPB8a.menuItemsLIST[:]
	wAcHkmPB8a.menuItemsLIST[:] = []
	usEHwJd4TxBfa = []
	for q74czO5ixFJebQt2u1BS in a0AHmy6Uq4V2cW5KMSXujCgQF3:
		vOPEjbSFg6ikQfdHsYUtVRcNLruXa = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(i80mE7lHUwVk(u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧẼ")+iI7tuF0nEQoR(u"ࠨࠥࠪẽ")+ne7wF4gSTRZo(u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭Ế"),q74czO5ixFJebQt2u1BS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if vOPEjbSFg6ikQfdHsYUtVRcNLruXa: q74czO5ixFJebQt2u1BS = q74czO5ixFJebQt2u1BS.split(vOPEjbSFg6ikQfdHsYUtVRcNLruXa[xn867tCVlscY4qbWZfh],jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		GyZMbXWijf = q74czO5ixFJebQt2u1BS.replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪ๕ࠬế"),gby0BnUuTNFk).replace(BarIC3eR9bS(u"ࠫ๓࠭Ề"),gby0BnUuTNFk).replace(iiauUxMktNW5X(u"ࠬ๑ࠧề"),gby0BnUuTNFk).replace(BarIC3eR9bS(u"࠭๏ࠨỂ"),gby0BnUuTNFk).replace(ggtuNcvTn3HQ7SpE2(u"ࠧํࠩể"),gby0BnUuTNFk)
		GyZMbXWijf = GyZMbXWijf.replace(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨ๒ࠪỄ"),gby0BnUuTNFk).replace(VzO1gCHmjZ2ebRIL(u"ࠩ๐ࠫễ"),gby0BnUuTNFk).replace(YZXtBgvUPoM5sb(u"ࠪ๖ࠬỆ"),gby0BnUuTNFk).replace(mmbcsf2pd7gyjzreB(u"ࠫฑ࠭ệ"),gby0BnUuTNFk).replace(ggtuNcvTn3HQ7SpE2(u"ࠬๆࠧỈ"),gby0BnUuTNFk)
		if GyZMbXWijf: usEHwJd4TxBfa.append(GyZMbXWijf)
	ccnt2gUBKIiJ8VqmxzuSAsZ51 = []
	for t3t986iTduqY in range(xn867tCVlscY4qbWZfh,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠳࠲ᾁ")):
		search = l8YH46ObxQJTk1.sample(usEHwJd4TxBfa,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		if search in ccnt2gUBKIiJ8VqmxzuSAsZ51: continue
		ccnt2gUBKIiJ8VqmxzuSAsZ51.append(search)
		gwiQ59eNbhY2SlLZB7aOpTDdsk1 = l8YH46ObxQJTk1.sample(sxS9K72jDU,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩỉ")+str(gwiQ59eNbhY2SlLZB7aOpTDdsk1)+iI7tuF0nEQoR(u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪỊ")+search)
		DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		A52cxoCyGIJdvbTLNnSFtlj70(search+n6JjFHfmydIaLut(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ị"))
		if len(wAcHkmPB8a.menuItemsLIST)>xn867tCVlscY4qbWZfh: break
	search = search.replace(ggtuNcvTn3HQ7SpE2(u"ࠩࡢࡑࡔࡊ࡟ࠨỌ"),gby0BnUuTNFk)
	f58z9SaNhFLsIilmYb071eDAwcWg[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6] = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࡟ࠬọ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+search+GGy0cQe765nPYZ9E8Th+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࠥࡀศฮอࠣ฽๋ࡣࠧỎ")
	wAcHkmPB8a.menuItemsLIST[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
	if len(wAcHkmPB8a.menuItemsLIST)>GGCyzqHVFWKjRch: wAcHkmPB8a.menuItemsLIST[:] = l8YH46ObxQJTk1.sample(wAcHkmPB8a.menuItemsLIST,GGCyzqHVFWKjRch)
	wAcHkmPB8a.menuItemsLIST[:] = f58z9SaNhFLsIilmYb071eDAwcWg+wAcHkmPB8a.menuItemsLIST
	return
def ZeiJmb0uEYcCzjfFWLsKMv2oDq(tfQTuPULz0,N1FbhV4lx6QcWOo):
	tfQTuPULz0 = tfQTuPULz0.replace(NupI74tJCzYXmles9SbR6(u"ࠬࡥࡍࡐࡆࡢࠫỏ"),gby0BnUuTNFk)
	N1FbhV4lx6QcWOo = N1FbhV4lx6QcWOo.replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨỐ"),gby0BnUuTNFk).replace(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫố"),gby0BnUuTNFk)
	rYfVJAbIE3(yrcbRSFswvAfEdIWVj)
	if not PwBW3hUyG7osmXJ5NivCEt1R0AM: return
	if GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪỒ") in N1FbhV4lx6QcWOo:
		ygWIQGf25qwVxLkXrYDjp(BarIC3eR9bS(u"ࠩࡩࡳࡱࡪࡥࡳࠩồ"),FAwWlRJg0UkN1(u"ࠪ࡟ࠬỔ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+tfQTuPULz0+GGy0cQe765nPYZ9E8Th+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࠥࡀวๅไึ้ࡢ࠭ổ"),tfQTuPULz0,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠳࠹࠺ᾂ"),gby0BnUuTNFk,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỖ")+N1FbhV4lx6QcWOo)
		ygWIQGf25qwVxLkXrYDjp(FAwWlRJg0UkN1(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ỗ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭Ộ"),tfQTuPULz0,zDSw8LCxMQyraeXhojIWKmU(u"࠴࠺࠻ᾃ"),gby0BnUuTNFk,gby0BnUuTNFk,iiauUxMktNW5X(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ộ")+N1FbhV4lx6QcWOo)
		ygWIQGf25qwVxLkXrYDjp(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ࡯࡭ࡳࡱࠧỚ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+NupI74tJCzYXmles9SbR6(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨớ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠽࠾࠿࠹ᾄ"))
	for website in sorted(list(PwBW3hUyG7osmXJ5NivCEt1R0AM[tfQTuPULz0].keys())):
		ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = PwBW3hUyG7osmXJ5NivCEt1R0AM[tfQTuPULz0][website]
		if q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ờ") in N1FbhV4lx6QcWOo or len(PwBW3hUyG7osmXJ5NivCEt1R0AM[tfQTuPULz0])==jxCVeKSLb9rGDOl0Qtw6:
			nnHojZ4NcvVXhU0uzCw3OGEQrJ(ZZrjMgRGiY2IDN7q,gby0BnUuTNFk,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,gby0BnUuTNFk,gby0BnUuTNFk)
			wAcHkmPB8a.menuItemsLIST[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
			PPB0Jlbxuf2RiWdnpAGS1eZt8H,ReBKsmpDSTAkwQnjghx20cbrUo84 = wAcHkmPB8a.menuItemsLIST[:jJ4LEcdl5w7BPMbQ],wAcHkmPB8a.menuItemsLIST[jJ4LEcdl5w7BPMbQ:]
			if q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧờ") in N1FbhV4lx6QcWOo:
				for xuX6UN0WRQbHArDV in range(OUFxZPuXDoGAbRz(u"࠾ᾅ")): l8YH46ObxQJTk1.shuffle(ReBKsmpDSTAkwQnjghx20cbrUo84)
				wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84[:GGCyzqHVFWKjRch]
			else: wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84
		elif KJLkQsqSHMR1Np2(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧỞ") in N1FbhV4lx6QcWOo: ygWIQGf25qwVxLkXrYDjp(i80mE7lHUwVk(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧở"),website,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
	return
def NNs8p9veDEOSFxywnP5I3GqR(N1FbhV4lx6QcWOo,mi63FgbZoVerXaTGNhsUkuR0ILQW):
	N1FbhV4lx6QcWOo = N1FbhV4lx6QcWOo.replace(mmbcsf2pd7gyjzreB(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỠ"),gby0BnUuTNFk).replace(KJLkQsqSHMR1Np2(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ỡ"),gby0BnUuTNFk)
	DPkEMfnRe82d,ReBKsmpDSTAkwQnjghx20cbrUo84 = gby0BnUuTNFk,[]
	ygWIQGf25qwVxLkXrYDjp(q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡪࡴࡲࡤࡦࡴࠪỢ"),RRbvqditj184m3(u"ࠫࡠ࠭ợ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+DPkEMfnRe82d+GGy0cQe765nPYZ9E8Th+ggtuNcvTn3HQ7SpE2(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧỤ"),gby0BnUuTNFk,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫụ")+N1FbhV4lx6QcWOo)
	ygWIQGf25qwVxLkXrYDjp(n6JjFHfmydIaLut(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỦ"),BarIC3eR9bS(u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨủ"),gby0BnUuTNFk,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,gby0BnUuTNFk,RRbvqditj184m3(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧỨ")+N1FbhV4lx6QcWOo)
	ygWIQGf25qwVxLkXrYDjp(n6JjFHfmydIaLut(u"ࠪࡰ࡮ࡴ࡫ࠨứ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+FAwWlRJg0UkN1(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩỪ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"࠿࠹࠺࠻ᾆ"))
	PPB0Jlbxuf2RiWdnpAGS1eZt8H = wAcHkmPB8a.menuItemsLIST[:]
	wAcHkmPB8a.menuItemsLIST[:] = []
	WjryKiBebavP = []
	if GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭ừ") in N1FbhV4lx6QcWOo:
		rYfVJAbIE3(yrcbRSFswvAfEdIWVj)
		if not PwBW3hUyG7osmXJ5NivCEt1R0AM: return
		P9po02GErv6BiqayZR = list(PwBW3hUyG7osmXJ5NivCEt1R0AM.keys())
		tfQTuPULz0 = l8YH46ObxQJTk1.sample(P9po02GErv6BiqayZR,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		a0AHmy6Uq4V2cW5KMSXujCgQF3 = list(PwBW3hUyG7osmXJ5NivCEt1R0AM[tfQTuPULz0].keys())
		website = l8YH46ObxQJTk1.sample(a0AHmy6Uq4V2cW5KMSXujCgQF3,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = PwBW3hUyG7osmXJ5NivCEt1R0AM[tfQTuPULz0][website]
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+n6JjFHfmydIaLut(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩỬ")+website+MlTVLBZ92kzorIq1Yw(u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪử")+DPkEMfnRe82d+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪỮ")+url+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬữ")+str(xILNdBX0itURo3Gg5a7fqzcAM9yrm))
	elif q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡣࡎࡖࡔࡗࡡࠪỰ") in N1FbhV4lx6QcWOo:
		import BBhJgplbfL
		if not BBhJgplbfL.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
		for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
			WjryKiBebavP += tcWLgqTQs8V3Aw(str(To1jOLBdtPWhFayp),N1FbhV4lx6QcWOo)
		if not WjryKiBebavP: return
		ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = l8YH46ObxQJTk1.sample(WjryKiBebavP,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫự")+DPkEMfnRe82d+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧỲ")+url+MlTVLBZ92kzorIq1Yw(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỳ")+str(xILNdBX0itURo3Gg5a7fqzcAM9yrm))
	elif iiauUxMktNW5X(u"ࠧࡠࡏ࠶࡙ࡤ࠭Ỵ") in N1FbhV4lx6QcWOo:
		import yYCGB8hzwT
		if not yYCGB8hzwT.hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4): return
		for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
			WjryKiBebavP += mkOVAYGJNI96SEWeU(str(To1jOLBdtPWhFayp),N1FbhV4lx6QcWOo)
		if not WjryKiBebavP: return
		ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = l8YH46ObxQJTk1.sample(WjryKiBebavP,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+iiauUxMktNW5X(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨỵ")+DPkEMfnRe82d+mmbcsf2pd7gyjzreB(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫỶ")+url+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ỷ")+str(xILNdBX0itURo3Gg5a7fqzcAM9yrm))
	xXvV4gKCijw1eETQd2FSo573 = DPkEMfnRe82d
	iwsqm9ByPZ5WYc13vlfExT = []
	for xuX6UN0WRQbHArDV in range(xn867tCVlscY4qbWZfh,n6JjFHfmydIaLut(u"࠱࠱ᾇ")):
		if xuX6UN0WRQbHArDV>xn867tCVlscY4qbWZfh: SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+RRbvqditj184m3(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫỸ")+DPkEMfnRe82d+n6JjFHfmydIaLut(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧỹ")+url+OUFxZPuXDoGAbRz(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỺ")+str(xILNdBX0itURo3Gg5a7fqzcAM9yrm))
		wAcHkmPB8a.menuItemsLIST[:] = []
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==Ducd5PRjQXaB9SIN7VrJ1G(u"࠳࠵࠷ᾈ") and RRbvqditj184m3(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨỻ") in fbmZ9V58PCTz: xILNdBX0itURo3Gg5a7fqzcAM9yrm = zDSw8LCxMQyraeXhojIWKmU(u"࠴࠶࠷ᾉ")
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠺࠵࠹ᾊ") and KJLkQsqSHMR1Np2(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨỼ") in fbmZ9V58PCTz: xILNdBX0itURo3Gg5a7fqzcAM9yrm = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠻࠶࠹ᾋ")
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==IXE6voNmrb182AyQ(u"࠶࠺࠴ᾌ"): xILNdBX0itURo3Gg5a7fqzcAM9yrm = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠸࠹࠲ᾍ")
		WDxo5FVQtNn7UaTlq6 = nnHojZ4NcvVXhU0uzCw3OGEQrJ(ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
		if i80mE7lHUwVk(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩỽ") in N1FbhV4lx6QcWOo and xILNdBX0itURo3Gg5a7fqzcAM9yrm==KJLkQsqSHMR1Np2(u"࠱࠷࠹ᾎ"): del wAcHkmPB8a.menuItemsLIST[:jJ4LEcdl5w7BPMbQ]
		if tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡣࡒ࠹ࡕࡠࠩỾ") in N1FbhV4lx6QcWOo and xILNdBX0itURo3Gg5a7fqzcAM9yrm==sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠲࠸࠻ᾏ"): del wAcHkmPB8a.menuItemsLIST[:jJ4LEcdl5w7BPMbQ]
		ReBKsmpDSTAkwQnjghx20cbrUo84[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
		if iwsqm9ByPZ5WYc13vlfExT and syFKrN8pIlTDZL6x(IXE6voNmrb182AyQ(u"ࡹࠬำไใหࠪỿ")) in str(ReBKsmpDSTAkwQnjghx20cbrUo84) or syFKrN8pIlTDZL6x(iI7tuF0nEQoR(u"ࡺ࠭อๅไ๊ࠫἀ")) in str(ReBKsmpDSTAkwQnjghx20cbrUo84):
			DPkEMfnRe82d = xXvV4gKCijw1eETQd2FSo573
			ReBKsmpDSTAkwQnjghx20cbrUo84[:] = iwsqm9ByPZ5WYc13vlfExT
			break
		xXvV4gKCijw1eETQd2FSo573 = DPkEMfnRe82d
		iwsqm9ByPZ5WYc13vlfExT = ReBKsmpDSTAkwQnjghx20cbrUo84
		if str(ReBKsmpDSTAkwQnjghx20cbrUo84).count(FAwWlRJg0UkN1(u"࠭ࡶࡪࡦࡨࡳࠬἁ"))>xn867tCVlscY4qbWZfh: break
		if str(ReBKsmpDSTAkwQnjghx20cbrUo84).count(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧ࡭࡫ࡹࡩࠬἂ"))>xn867tCVlscY4qbWZfh: break
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==n6JjFHfmydIaLut(u"࠴࠶࠷ᾐ"): break
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠺࠵࠸ᾑ"): break
		if xILNdBX0itURo3Gg5a7fqzcAM9yrm==kreQUwJis7YmC2yqWtIF09pgjbD(u"࠶࠾࠷ᾒ"): break
		if nJF7oflOk6cLGSAey(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪἃ") in N1FbhV4lx6QcWOo and ReBKsmpDSTAkwQnjghx20cbrUo84: ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,url,xILNdBX0itURo3Gg5a7fqzcAM9yrm,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = l8YH46ObxQJTk1.sample(ReBKsmpDSTAkwQnjghx20cbrUo84,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
	if not DPkEMfnRe82d: DPkEMfnRe82d = ne7wF4gSTRZo(u"ࠩ࠱࠲࠳࠴ࠧἄ")
	elif DPkEMfnRe82d.count(iI7tuF0nEQoR(u"ࠪࡣࠬἅ"))>jxCVeKSLb9rGDOl0Qtw6: DPkEMfnRe82d = DPkEMfnRe82d.split(BarIC3eR9bS(u"ࠫࡤ࠭ἆ"),dNx9DVCtafk4r)[dNx9DVCtafk4r]
	DPkEMfnRe82d = DPkEMfnRe82d.replace(VzO1gCHmjZ2ebRIL(u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨἇ"),gby0BnUuTNFk)
	DPkEMfnRe82d = DPkEMfnRe82d.replace(MlTVLBZ92kzorIq1Yw(u"࠭࡟ࡎࡑࡇࡣࠬἈ"),gby0BnUuTNFk)
	PPB0Jlbxuf2RiWdnpAGS1eZt8H[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6] = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧ࡜ࠩἉ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+DPkEMfnRe82d+GGy0cQe765nPYZ9E8Th+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪἊ")
	if YZXtBgvUPoM5sb(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫἋ") in N1FbhV4lx6QcWOo:
		for xuX6UN0WRQbHArDV in range(i80mE7lHUwVk(u"࠾ᾓ")): l8YH46ObxQJTk1.shuffle(ReBKsmpDSTAkwQnjghx20cbrUo84)
		wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84[:GGCyzqHVFWKjRch]
	else: wAcHkmPB8a.menuItemsLIST[:] = PPB0Jlbxuf2RiWdnpAGS1eZt8H+ReBKsmpDSTAkwQnjghx20cbrUo84
	return
def tQ9ke1r4dxawJIUFf(Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn):
	zTY47Zcdmy83SDOHn = zTY47Zcdmy83SDOHn.replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬἌ"),gby0BnUuTNFk).replace(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨἍ"),gby0BnUuTNFk)
	GFJLX2lDpRbs5K1gea4AzjkQqiVnh6 = zTY47Zcdmy83SDOHn
	if NupI74tJCzYXmles9SbR6(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ἆ") in zTY47Zcdmy83SDOHn:
		GFJLX2lDpRbs5K1gea4AzjkQqiVnh6 = zTY47Zcdmy83SDOHn.split(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧἏ"))[xn867tCVlscY4qbWZfh]
		type = zDSw8LCxMQyraeXhojIWKmU(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪἐ")
	elif IXE6voNmrb182AyQ(u"ࠨࡘࡒࡈࠬἑ") in Vz62Fm7iPHEhGvIJ: type = FAwWlRJg0UkN1(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬἒ")
	elif mmbcsf2pd7gyjzreB(u"ࠪࡐࡎ࡜ࡅࠨἓ") in Vz62Fm7iPHEhGvIJ: type = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬἔ")
	ygWIQGf25qwVxLkXrYDjp(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἕ"),n6JjFHfmydIaLut(u"࡛࠭ࠨ἖")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+type+GFJLX2lDpRbs5K1gea4AzjkQqiVnh6+GGy0cQe765nPYZ9E8Th+BarIC3eR9bS(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩ἗"),Vz62Fm7iPHEhGvIJ,zDSw8LCxMQyraeXhojIWKmU(u"࠷࠶࠸ᾔ"),gby0BnUuTNFk,gby0BnUuTNFk,ne7wF4gSTRZo(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ἐ")+zTY47Zcdmy83SDOHn)
	ygWIQGf25qwVxLkXrYDjp(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡩࡳࡱࡪࡥࡳࠩἙ"),ggtuNcvTn3HQ7SpE2(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩἚ"),Vz62Fm7iPHEhGvIJ,zDSw8LCxMQyraeXhojIWKmU(u"࠱࠷࠹ᾕ"),gby0BnUuTNFk,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩἛ")+zTY47Zcdmy83SDOHn)
	ygWIQGf25qwVxLkXrYDjp(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡲࡩ࡯࡭ࠪἜ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+ggtuNcvTn3HQ7SpE2(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫἝ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,TeYukOUW7i5NBM926DCjaAn0(u"࠺࠻࠼࠽ᾖ"))
	import BBhJgplbfL
	for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
		if ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ἞") in zTY47Zcdmy83SDOHn: BBhJgplbfL.MM6Qabwn2ecXOA3GK8pt5H(str(To1jOLBdtPWhFayp),Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn,gby0BnUuTNFk,yrcbRSFswvAfEdIWVj)
		else: BBhJgplbfL.O5XxuEh689Mvoq1Rnesl(str(To1jOLBdtPWhFayp),Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn,gby0BnUuTNFk,yrcbRSFswvAfEdIWVj)
	wAcHkmPB8a.menuItemsLIST[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
	if len(wAcHkmPB8a.menuItemsLIST)>(GGCyzqHVFWKjRch+jJ4LEcdl5w7BPMbQ): wAcHkmPB8a.menuItemsLIST[:] = wAcHkmPB8a.menuItemsLIST[:jJ4LEcdl5w7BPMbQ]+l8YH46ObxQJTk1.sample(wAcHkmPB8a.menuItemsLIST[jJ4LEcdl5w7BPMbQ:],GGCyzqHVFWKjRch)
	return
def m7AzytbLlui(Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn):
	zTY47Zcdmy83SDOHn = zTY47Zcdmy83SDOHn.replace(BarIC3eR9bS(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ἟"),gby0BnUuTNFk).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἠ"),gby0BnUuTNFk)
	GFJLX2lDpRbs5K1gea4AzjkQqiVnh6 = zTY47Zcdmy83SDOHn
	if OUFxZPuXDoGAbRz(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪἡ") in zTY47Zcdmy83SDOHn:
		GFJLX2lDpRbs5K1gea4AzjkQqiVnh6 = zTY47Zcdmy83SDOHn.split(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἢ"))[xn867tCVlscY4qbWZfh]
		type = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨἣ")
	elif RRbvqditj184m3(u"࠭ࡖࡐࡆࠪἤ") in Vz62Fm7iPHEhGvIJ: type = ne7wF4gSTRZo(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪἥ")
	elif KJLkQsqSHMR1Np2(u"ࠨࡎࡌ࡚ࡊ࠭ἦ") in Vz62Fm7iPHEhGvIJ: type = VzO1gCHmjZ2ebRIL(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪἧ")
	ygWIQGf25qwVxLkXrYDjp(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡪࡴࡲࡤࡦࡴࠪἨ"),MlTVLBZ92kzorIq1Yw(u"ࠫࡠ࠭Ἡ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+type+GFJLX2lDpRbs5K1gea4AzjkQqiVnh6+GGy0cQe765nPYZ9E8Th+nJF7oflOk6cLGSAey(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧἪ"),Vz62Fm7iPHEhGvIJ,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠳࠹࠼ᾗ"),gby0BnUuTNFk,gby0BnUuTNFk,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἫ")+zTY47Zcdmy83SDOHn)
	ygWIQGf25qwVxLkXrYDjp(i80mE7lHUwVk(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἬ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧἭ"),Vz62Fm7iPHEhGvIJ,OUFxZPuXDoGAbRz(u"࠴࠺࠽ᾘ"),gby0BnUuTNFk,gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἮ")+zTY47Zcdmy83SDOHn)
	ygWIQGf25qwVxLkXrYDjp(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡰ࡮ࡴ࡫ࠨἯ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩἰ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠽࠾࠿࠹ᾙ"))
	import yYCGB8hzwT
	for To1jOLBdtPWhFayp in range(jxCVeKSLb9rGDOl0Qtw6,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+jxCVeKSLb9rGDOl0Qtw6):
		if oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬἱ") in zTY47Zcdmy83SDOHn: yYCGB8hzwT.MM6Qabwn2ecXOA3GK8pt5H(str(To1jOLBdtPWhFayp),Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn,gby0BnUuTNFk,yrcbRSFswvAfEdIWVj)
		else: yYCGB8hzwT.O5XxuEh689Mvoq1Rnesl(str(To1jOLBdtPWhFayp),Vz62Fm7iPHEhGvIJ,zTY47Zcdmy83SDOHn,gby0BnUuTNFk,yrcbRSFswvAfEdIWVj)
	wAcHkmPB8a.menuItemsLIST[:] = BCZ6WdI3mrN2nzOUF7ixtwH4pVa(wAcHkmPB8a.menuItemsLIST)
	if len(wAcHkmPB8a.menuItemsLIST)>(GGCyzqHVFWKjRch+jJ4LEcdl5w7BPMbQ): wAcHkmPB8a.menuItemsLIST[:] = wAcHkmPB8a.menuItemsLIST[:jJ4LEcdl5w7BPMbQ]+l8YH46ObxQJTk1.sample(wAcHkmPB8a.menuItemsLIST[jJ4LEcdl5w7BPMbQ:],GGCyzqHVFWKjRch)
	return
def BCZ6WdI3mrN2nzOUF7ixtwH4pVa(rJ7VgqhUyQGFAMOBP6):
	odcYn4sayvpFmhURDtB0u = []
	for type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in rJ7VgqhUyQGFAMOBP6:
		if zDSw8LCxMQyraeXhojIWKmU(u"࠭ีโฯฬࠫἲ") in DPkEMfnRe82d or VzO1gCHmjZ2ebRIL(u"ࠧึใะ๋ࠬἳ") in DPkEMfnRe82d or IXE6voNmrb182AyQ(u"ࠨࡲࡤ࡫ࡪ࠭ἴ") in DPkEMfnRe82d.lower(): continue
		odcYn4sayvpFmhURDtB0u.append([type,DPkEMfnRe82d,url,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF])
	return odcYn4sayvpFmhURDtB0u