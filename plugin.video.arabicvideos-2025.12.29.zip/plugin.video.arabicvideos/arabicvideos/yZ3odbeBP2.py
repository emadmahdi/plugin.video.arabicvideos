# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
headers = { 'User-Agent' : gby0BnUuTNFk }
CC3nOPFMovd72u = 'AKOAM'
JB9fyoHr05QOtPjp = '_AKO_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
ll0iWTzkUNsgqZOIJYC3eAh7K8 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==70: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==71: WjryKiBebavP = BJeTzN8vSh(url)
	elif mode==72: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==73: WjryKiBebavP = C7F8g3Z5ikLPYOGUdj9nW(url)
	elif mode==74: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==79: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,79,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'سلسلة افلام',gby0BnUuTNFk,79,gby0BnUuTNFk,gby0BnUuTNFk,'سلسلة افلام')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'سلاسل منوعة',gby0BnUuTNFk,79,gby0BnUuTNFk,gby0BnUuTNFk,'سلسلة')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	d2gCoAnYPG89O = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKOAM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="partions"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O:
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,71)
	return jS6fQGXeouTB7xKd32ZMy
def BJeTzN8vSh(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKOAM-CATEGORIES-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sect_parts(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,72)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'جميع الفروع',url,72)
	else: Xw3tTz8UD4LK26C(url,gby0BnUuTNFk)
	return
def Xw3tTz8UD4LK26C(url,type):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('section_title featured_title(.*?)subjects-crousel',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='search':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('akoam_result(.*?)<script',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='more':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('section_title more_title(.*?)footer_bottom_services',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('navigation(.*?)<script',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items and QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		title = Y7BxKQdU84R(title)
		if any(value in title for value in ll0iWTzkUNsgqZOIJYC3eAh7K8): ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,73,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,73,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("</li><li >.*?href='(.*?)'>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,72,gby0BnUuTNFk,gby0BnUuTNFk,type)
	return
def uWw0NSihOkytxP52ZQITJ3Da(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,True,'AKOAM-SECTIONS-2nd')
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"href","(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[1]
	return Tf5ueYGZIFl1hraoEOVKi
def C7F8g3Z5ikLPYOGUdj9nW(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'AKOAM-SECTIONS-1st')
	ZVmLlK6xYMrTjQ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(https*://akwam.net/\w+.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	lGAMkFid4ztJQSfPwOBybXgo3hIW7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(https*://underurl.com/\w+.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if ZVmLlK6xYMrTjQ or lGAMkFid4ztJQSfPwOBybXgo3hIW7:
		if ZVmLlK6xYMrTjQ: mm7pzl3HMi0R8fGu = ZVmLlK6xYMrTjQ[0]
		elif lGAMkFid4ztJQSfPwOBybXgo3hIW7: mm7pzl3HMi0R8fGu = uWw0NSihOkytxP52ZQITJ3Da(lGAMkFid4ztJQSfPwOBybXgo3hIW7[0])
		mm7pzl3HMi0R8fGu = pFnO2T7r16k(mm7pzl3HMi0R8fGu)
		import sQFHBNpE3k
		if '/series/' in mm7pzl3HMi0R8fGu or '/shows/' in mm7pzl3HMi0R8fGu: sQFHBNpE3k.Ra4XAK1tDxc3kfOrIdsjLpzmGN0(mm7pzl3HMi0R8fGu)
		else: sQFHBNpE3k.HthKAzX6MnLDiIF4aEC5sukp8WfJST(mm7pzl3HMi0R8fGu)
		return
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		title = Y7BxKQdU84R(title)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,73)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb:
		RLfOB3nsqaWXTugJvY('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,T6TRUSbecYGWIq29KF,AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	name = name.strip(UpN1CezytPO9XoduhxZSD)
	if 'sub_epsiode_title' in AxiBv1cQueOs0:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		JWecj3t6FpmNP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sub_file_title\'>(.*?) - <i>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		items = []
		for filename in JWecj3t6FpmNP:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',gby0BnUuTNFk) ]
	count = 0
	uufJivSZQyj45ql3,K73srqSefn4hb21lJ58kFMaT = [],[]
	size = len(items)
	for title,filename in items:
		byqNDIa3HSpucQLm = gby0BnUuTNFk
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: byqNDIa3HSpucQLm = filename.split('.')[-1]
		title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		uufJivSZQyj45ql3.append(title)
		K73srqSefn4hb21lJ58kFMaT.append(count)
		count += 1
	if size>0:
		if any(value in name for value in ll0iWTzkUNsgqZOIJYC3eAh7K8):
			if size==1:
				EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 0
			else:
				EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('اختر الفيديو المناسب:', uufJivSZQyj45ql3)
				if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1: return
			HthKAzX6MnLDiIF4aEC5sukp8WfJST(url+'?section='+str(1+K73srqSefn4hb21lJ58kFMaT[size-EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc-1]))
		else:
			for xuX6UN0WRQbHArDV in reversed(range(size)):
				title = name + ' - ' + uufJivSZQyj45ql3[xuX6UN0WRQbHArDV]
				title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
				SSqweDUBYv4bkO = url + '?section='+str(size-xuX6UN0WRQbHArDV)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,74,T6TRUSbecYGWIq29KF)
	else:
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+'الرابط ليس فيديو',gby0BnUuTNFk,9999,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	Tf5ueYGZIFl1hraoEOVKi,Cso7iV0ZOw2UW5Ez = url.split('?section=')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,True,gby0BnUuTNFk,'AKOAM-PLAY_AKOAM-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	ysmph0BW6bRZxcFDdvGiOPw = QKqM0CwXDk8APOoJFpyntRb[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	ysmph0BW6bRZxcFDdvGiOPw = ysmph0BW6bRZxcFDdvGiOPw + 'direct_link_box'
	bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('epsoide_box(.*?)direct_link_box',ysmph0BW6bRZxcFDdvGiOPw,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Cso7iV0ZOw2UW5Ez = len(bXMpofzj7h)-int(Cso7iV0ZOw2UW5Ez)
	AxiBv1cQueOs0 = bXMpofzj7h[Cso7iV0ZOw2UW5Ez]
	ytc3dVjPkMHCSmlzvBuO820Q = []
	oFL4J1lrOnWucIjStDYEqg9GpX7mCs = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='download_btn.*?href='(.*?)'",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO in items:
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=________akoam')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for Bl3bedv5A9csSEf1pOj0uxQ6,SSqweDUBYv4bkO in items:
		Bl3bedv5A9csSEf1pOj0uxQ6 = Bl3bedv5A9csSEf1pOj0uxQ6.split('/')[-1]
		Bl3bedv5A9csSEf1pOj0uxQ6 = Bl3bedv5A9csSEf1pOj0uxQ6.split('.')[0]
		if Bl3bedv5A9csSEf1pOj0uxQ6 in oFL4J1lrOnWucIjStDYEqg9GpX7mCs:
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+oFL4J1lrOnWucIjStDYEqg9GpX7mCs[Bl3bedv5A9csSEf1pOj0uxQ6]+'________akoam')
		else: ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+Bl3bedv5A9csSEf1pOj0uxQ6+'________akoam')
	if not ytc3dVjPkMHCSmlzvBuO820Q:
		message = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sub-no-file.*?\n(.*?)\n',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if message: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'رسالة من الموقع الاصلي',message[0])
	else:
		import Wlc38MqyKf
		Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	url = LhFnEIuPHdoNc + '/search/'+apTFWBhb175nwjvKtmJ2
	WjryKiBebavP = Xw3tTz8UD4LK26C(url,'search')
	return