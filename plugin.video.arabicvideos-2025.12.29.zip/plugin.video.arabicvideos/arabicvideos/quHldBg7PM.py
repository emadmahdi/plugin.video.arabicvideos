# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SHOOFMAX'
JB9fyoHr05QOtPjp = '_SHM_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
o5lILcsXUd9 = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][1]
pdHZtCkK1x = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][2]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==50: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==51: WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	elif mode==52: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==53: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==55: WjryKiBebavP = ilnDt5gZJAo0M()
	elif mode==56: WjryKiBebavP = yyA3tUEuIOj1()
	elif mode==57: WjryKiBebavP = jeDm0qKNk4nVc35(url,1)
	elif mode==58: WjryKiBebavP = jeDm0qKNk4nVc35(url,2)
	elif mode==59: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,59,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المسلسلات',gby0BnUuTNFk,56)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الافلام',gby0BnUuTNFk,55)
	return gby0BnUuTNFk
def ilnDt5gZJAo0M():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أفلام مرتبة بسنة الإنتاج',LhFnEIuPHdoNc+'/movie/1/yop',57)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أفلام مرتبة بالأفضل تقييم',LhFnEIuPHdoNc+'/movie/1/review',57)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أفلام مرتبة بالأكثر مشاهدة',LhFnEIuPHdoNc+'/movie/1/views',57)
	return
def yyA3tUEuIOj1():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات مرتبة بسنة الإنتاج',LhFnEIuPHdoNc+'/series/1/yop',57)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات مرتبة بالأفضل تقييم',LhFnEIuPHdoNc+'/series/1/review',57)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات مرتبة بالأكثر مشاهدة',LhFnEIuPHdoNc+'/series/1/views',57)
	return
def Xw3tTz8UD4LK26C(url):
	if '?' in url:
		rO9QBRygx3sqJcH5kZTM1uS74D = url.split('?')
		url = rO9QBRygx3sqJcH5kZTM1uS74D[0]
		filter = '?' + IcChbXakUDFLszgpSG2jqem9(rO9QBRygx3sqJcH5kZTM1uS74D[1],'=&:/%')
	else: filter = gby0BnUuTNFk
	type,kdwXYDMQOjz51Z08W,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': ttFbmiRrEfBUl='فيلم'
		elif type=='series': ttFbmiRrEfBUl='مسلسل'
		url = LhFnEIuPHdoNc + '/genre/filter/' + IcChbXakUDFLszgpSG2jqem9(ttFbmiRrEfBUl) + '/' + kdwXYDMQOjz51Z08W + '/' + sort + filter
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHOOFMAX-TITLES-1st')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		tRuqCwDg0er=0
		for id,title,x7LoaKACWqG,T6TRUSbecYGWIq29KF in items:
			tRuqCwDg0er += 1
			T6TRUSbecYGWIq29KF = pdHZtCkK1x + '/v2/img/program/main/' + T6TRUSbecYGWIq29KF + '-2.jpg'
			SSqweDUBYv4bkO = LhFnEIuPHdoNc + '/program/' + id
			if type=='movie': ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,53,T6TRUSbecYGWIq29KF)
			if type=='series': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسل '+title,SSqweDUBYv4bkO+'?ep='+x7LoaKACWqG+'='+title+'='+T6TRUSbecYGWIq29KF,52,T6TRUSbecYGWIq29KF)
	else:
		if type=='movie': ttFbmiRrEfBUl='movies'
		elif type=='series': ttFbmiRrEfBUl='series'
		url = o5lILcsXUd9 + '/json/selected/' + sort + '-' + ttFbmiRrEfBUl + '-WW.json'
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHOOFMAX-TITLES-2nd')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		tRuqCwDg0er=0
		for id,x7LoaKACWqG,T6TRUSbecYGWIq29KF,title in items:
			tRuqCwDg0er += 1
			T6TRUSbecYGWIq29KF = o5lILcsXUd9 + '/img/program/' + T6TRUSbecYGWIq29KF + '-2.jpg'
			SSqweDUBYv4bkO = LhFnEIuPHdoNc + '/program/' + id
			if type=='movie': ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,53,T6TRUSbecYGWIq29KF)
			elif type=='series': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسل '+title,SSqweDUBYv4bkO+'?ep='+x7LoaKACWqG+'='+title+'='+T6TRUSbecYGWIq29KF,52,T6TRUSbecYGWIq29KF)
	title='صفحة '
	if tRuqCwDg0er==16:
		for jzr3gwSik2yORxcoWGMq84QumvZV in range(1,13) :
			if not kdwXYDMQOjz51Z08W==str(jzr3gwSik2yORxcoWGMq84QumvZV):
				url = LhFnEIuPHdoNc+'/genre/filter/'+type+'/'+str(jzr3gwSik2yORxcoWGMq84QumvZV)+'/'+sort+filter
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title+str(jzr3gwSik2yORxcoWGMq84QumvZV),url,51)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	rO9QBRygx3sqJcH5kZTM1uS74D = url.split('=')
	x7LoaKACWqG = int(rO9QBRygx3sqJcH5kZTM1uS74D[1])
	name = pFnO2T7r16k(rO9QBRygx3sqJcH5kZTM1uS74D[2])
	name = name.replace('_MOD_مسلسل ',gby0BnUuTNFk)
	T6TRUSbecYGWIq29KF = rO9QBRygx3sqJcH5kZTM1uS74D[3]
	url = url.split('?')[0]
	if x7LoaKACWqG==0:
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHOOFMAX-EPISODES-1st')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<select(.*?)</select>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('option value="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		x7LoaKACWqG = int(items[-1])
	for Cso7iV0ZOw2UW5Ez in range(x7LoaKACWqG,0,-1):
		SSqweDUBYv4bkO = url + '?ep=' + str(Cso7iV0ZOw2UW5Ez)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(Cso7iV0ZOw2UW5Ez)
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,53,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHOOFMAX-PLAY-1st')
	JYa3QFipf4TcmrUyVuS2X = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if JYa3QFipf4TcmrUyVuS2X:
		RyfYSek61do5OnQMc = JYa3QFipf4TcmrUyVuS2X[1].replace('T',TFAVlh4ONfuyivg)
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+okfdjS4RmM+RyfYSek61do5OnQMc)
		return
	Nd2Eo50UapZkzhqSDvcbJi6j,UJFA35gOu9Dcmz0 = [],[]
	uuG8m4OUcoWJgMlrS9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('var origin_link = "(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	sKhbfqwleBmtUE3T = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('var backup_origin_link = "(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('hls: (.*?)_link\+"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for TfYmiUDcZOCgQ86rENjVG1zaqXbWk,SSqweDUBYv4bkO in vx14CNdbsZTz:
		if 'backup' in TfYmiUDcZOCgQ86rENjVG1zaqXbWk:
			TfYmiUDcZOCgQ86rENjVG1zaqXbWk = 'backup server'
			url = sKhbfqwleBmtUE3T + SSqweDUBYv4bkO
		else:
			TfYmiUDcZOCgQ86rENjVG1zaqXbWk = 'main server'
			url = uuG8m4OUcoWJgMlrS9 + SSqweDUBYv4bkO
		if '.m3u8' in url:
			Nd2Eo50UapZkzhqSDvcbJi6j.append(url)
			UJFA35gOu9Dcmz0.append('m3u8  '+TfYmiUDcZOCgQ86rENjVG1zaqXbWk)
	vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	vx14CNdbsZTz += ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for TfYmiUDcZOCgQ86rENjVG1zaqXbWk,SSqweDUBYv4bkO in vx14CNdbsZTz:
		filename = SSqweDUBYv4bkO.split('/')[-1]
		filename = filename.replace('fallback',gby0BnUuTNFk)
		filename = filename.replace('.mp4',gby0BnUuTNFk)
		filename = filename.replace('-',gby0BnUuTNFk)
		if 'backup' in TfYmiUDcZOCgQ86rENjVG1zaqXbWk:
			TfYmiUDcZOCgQ86rENjVG1zaqXbWk = 'backup server'
			url = sKhbfqwleBmtUE3T + SSqweDUBYv4bkO
		else:
			TfYmiUDcZOCgQ86rENjVG1zaqXbWk = 'main server'
			url = uuG8m4OUcoWJgMlrS9 + SSqweDUBYv4bkO
		Nd2Eo50UapZkzhqSDvcbJi6j.append(url)
		UJFA35gOu9Dcmz0.append('mp4  '+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+rBcdwYZInhgO29jtkFAfGxi7+filename)
	EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('Select Video Quality:', UJFA35gOu9Dcmz0)
	if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1 : return
	url = Nd2Eo50UapZkzhqSDvcbJi6j[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	YAQOL1eVvqMjsEfIFc(url,CC3nOPFMovd72u,'video')
	return
def jeDm0qKNk4nVc35(url,type):
	if 'series' in url: Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc + '/genre/مسلسل'
	else: Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc + '/genre/فيلم'
	Tf5ueYGZIFl1hraoEOVKi = IcChbXakUDFLszgpSG2jqem9(Tf5ueYGZIFl1hraoEOVKi)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHOOFMAX-FILTERS-1st')
	if type==1: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('subgenre(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type==2: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('country(.*?)div',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('option value="(.*?)">(.*?)</option',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if type==1:
		for s35serM8B0SvcFIu,title in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url+'?subgenre='+s35serM8B0SvcFIu,58)
	elif type==2:
		url,s35serM8B0SvcFIu = url.split('?')
		for qqXs9KORkeyc,title in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url+'?country='+qqXs9KORkeyc+'&'+s35serM8B0SvcFIu,51)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if not search: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	url = LhFnEIuPHdoNc+'/search?q='+apTFWBhb175nwjvKtmJ2
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,True,gby0BnUuTNFk,'SHOOFMAX-SEARCH-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('general-body(.*?)search-bottom-padding',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			url = LhFnEIuPHdoNc + SSqweDUBYv4bkO
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+IcChbXakUDFLszgpSG2jqem9(title)+'='+T6TRUSbecYGWIq29KF
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,52,T6TRUSbecYGWIq29KF)
				else:
					title = '_MOD_فيلم '+title
					ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,url,53,T6TRUSbecYGWIq29KF)
	return