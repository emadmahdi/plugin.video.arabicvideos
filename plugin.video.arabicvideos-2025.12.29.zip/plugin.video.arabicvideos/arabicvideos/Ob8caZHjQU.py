# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMANOW'
JB9fyoHr05QOtPjp = '_CMN_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['قائمتي']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==300: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==301: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==302: WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	elif mode==303: WjryKiBebavP = KZhF4Vljtk5Gcp8M7Wf0JmYa(url)
	elif mode==304: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==305: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==306: WjryKiBebavP = Kg4CL9PwtDnNIbVOkAvBs05()
	elif mode==309: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,309,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc+'/home',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<header(.*?)</header>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li><a href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if not any(value in title for value in d2gCoAnYPG89O):
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,301)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	Ce5f6gUsbyKJ12TDnVOB7WLAhG(LhFnEIuPHdoNc+'/home',jS6fQGXeouTB7xKd32ZMy)
	return jS6fQGXeouTB7xKd32ZMy
def Kg4CL9PwtDnNIbVOkAvBs05():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url,jS6fQGXeouTB7xKd32ZMy=gby0BnUuTNFk):
	if not jS6fQGXeouTB7xKd32ZMy:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-SUBMENU-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	KQydxfMmoJERw = 0
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<section>.*?</section>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
		KQydxfMmoJERw += 1
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,HzboAGF6TnNYhlSgD,SSqweDUBYv4bkO in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if title==gby0BnUuTNFk: title = 'بووووو'
			if 'em><a' not in HzboAGF6TnNYhlSgD:
				if AxiBv1cQueOs0.count('/category/')>0:
					joAn4ETVPG81bXNRyHfBFiaxZgLs = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					for SSqweDUBYv4bkO in joAn4ETVPG81bXNRyHfBFiaxZgLs:
						title = SSqweDUBYv4bkO.split('/')[-2]
						ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,301)
					continue
				else: SSqweDUBYv4bkO = url+'?sequence='+str(KQydxfMmoJERw)
			if not any(value in title for value in d2gCoAnYPG89O):
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,302)
	if not QKqM0CwXDk8APOoJFpyntRb: Xw3tTz8UD4LK26C(url,jS6fQGXeouTB7xKd32ZMy)
	return
def Xw3tTz8UD4LK26C(url,jS6fQGXeouTB7xKd32ZMy=gby0BnUuTNFk):
	if jS6fQGXeouTB7xKd32ZMy==gby0BnUuTNFk:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if '?sequence=' in url:
		url,KQydxfMmoJERw = url.split('?sequence=')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(<section>.*?</section>)',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[int(KQydxfMmoJERw)-1]
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"posts"(.*?)</body>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for SSqweDUBYv4bkO,data,T6TRUSbecYGWIq29KF in items:
		title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if title: title = title[0][2].replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		if not title or title==gby0BnUuTNFk:
			title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('title">.*?</em>(.*?)<',data,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if title: title = title[0].replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			if not title or title==gby0BnUuTNFk:
				title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('title">(.*?)<',data,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				title = title[0].replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		title = Y7BxKQdU84R(title)
		title = title.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
			NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			xki4Q3jNVZzFAsaWOPCge = SSqweDUBYv4bkO+data+T6TRUSbecYGWIq29KF
			if '/selary/' in xki4Q3jNVZzFAsaWOPCge or 'مسلسل' in xki4Q3jNVZzFAsaWOPCge or '"episode"' in xki4Q3jNVZzFAsaWOPCge:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,303,T6TRUSbecYGWIq29KF)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,305,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li><a href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,302)
	return
def KZhF4Vljtk5Gcp8M7Wf0JmYa(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-SEASONS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	name = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<title>(.*?)</title>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',gby0BnUuTNFk).replace('Cima Now',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		name = name.split('الحلقة')[0].strip(UpN1CezytPO9XoduhxZSD)+' - '
	else: name = gby0BnUuTNFk
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<section(.*?)</section>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)>1:
			for SSqweDUBYv4bkO,title in items:
				title = name+title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,304)
		elif len(items)==1:
			SSqweDUBYv4bkO,title = items[0]
			Ra4XAK1tDxc3kfOrIdsjLpzmGN0(SSqweDUBYv4bkO)
		else: Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if '/selary/' not in url:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"episodes"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			title = 'الحلقة '+title
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,305)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"details"(.*?)"related"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,305,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	UyPXuBpHJOb9AwINsjLlicn = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="shine" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if UyPXuBpHJOb9AwINsjLlicn:
		TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(UyPXuBpHJOb9AwINsjLlicn[0],'url')
		headers = {'Referer':TfYmiUDcZOCgQ86rENjVG1zaqXbWk}
	else: headers = gby0BnUuTNFk
	Tf5ueYGZIFl1hraoEOVKi = url+'watching/'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'CIMANOW-PLAY-5th')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"download"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			DYNVS1Bbgs7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('\d\d\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if DYNVS1Bbgs7:
				DYNVS1Bbgs7 = '____'+DYNVS1Bbgs7[0]
				title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
			else: DYNVS1Bbgs7 = gby0BnUuTNFk
			RkntpA1UJDV4vNgyaex6GPWK9YQIcC = SSqweDUBYv4bkO+'?named='+title+'__download'+DYNVS1Bbgs7
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(RkntpA1UJDV4vNgyaex6GPWK9YQIcC)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"watch"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embed".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO in vx14CNdbsZTz:
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
			title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__embed'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
		vx14CNdbsZTz = [LhFnEIuPHdoNc+'/wp-content/themes/Cima%20Now%20New/core.php']
		if vx14CNdbsZTz:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for xYDJcGlC5PSFpRaX03nLNjZO2Uqum,id,title in items:
				title = title.replace(okfdjS4RmM,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
				SSqweDUBYv4bkO = vx14CNdbsZTz[0]+'?action=switch&index='+xYDJcGlC5PSFpRaX03nLNjZO2Uqum+'&id='+id+'?named='+title+'__watch'
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + '/?s='+search
	Xw3tTz8UD4LK26C(url)
	return