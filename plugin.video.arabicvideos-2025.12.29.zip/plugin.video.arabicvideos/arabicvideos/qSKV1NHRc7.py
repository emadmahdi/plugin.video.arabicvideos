﻿# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'ALMAAREF'
headers = {'User-Agent':gby0BnUuTNFk}
JB9fyoHr05QOtPjp = '_MRF_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text,kdwXYDMQOjz51Z08W):
	if   mode==40: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==41: WjryKiBebavP = fZiYAJH1PcQI2O6LyX4rgT9au8l()
	elif mode==42: WjryKiBebavP = aIlYrXLsv2K(text,kdwXYDMQOjz51Z08W)
	elif mode==43: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==44: WjryKiBebavP = Xw3tTz8UD4LK26C(text,kdwXYDMQOjz51Z08W)
	elif mode==49: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,49)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'البث الحي لقناة المعارف',gby0BnUuTNFk,41)
	aIlYrXLsv2K(gby0BnUuTNFk,'1')
	return
def NpiZlDX0JH35b6vydUuo4Q(K7ETgQ2pb4ylWIB3vDHjJ,Hl3Dv2jZByIfkTcSds0YzhUwbou):
	search,sort,jpoe3KZUgTv,zTFlfH8DhAVryqUjX,CGEMqhOWp3ec18zT = gby0BnUuTNFk,[],[],[],[]
	WDxo5FVQtNn7UaTlq6,tZPgWqnGf8QplABuk3MDs5jHe = avXHrARzQuBW4s(K7ETgQ2pb4ylWIB3vDHjJ)
	for w7su60daQz13VIplrfxJk in list(tZPgWqnGf8QplABuk3MDs5jHe.keys()):
		value = tZPgWqnGf8QplABuk3MDs5jHe[w7su60daQz13VIplrfxJk]
		if not value: continue
		if   w7su60daQz13VIplrfxJk=='sort': sort = [value]
		elif w7su60daQz13VIplrfxJk=='series': jpoe3KZUgTv = [value]
		elif w7su60daQz13VIplrfxJk=='search': search = value
		elif w7su60daQz13VIplrfxJk=='category': zTFlfH8DhAVryqUjX = [value]
		elif w7su60daQz13VIplrfxJk=='specialist': CGEMqhOWp3ec18zT = [value]
	pjBAh5E2XWYmHx = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":zTFlfH8DhAVryqUjX,"specialist":CGEMqhOWp3ec18zT,"series":jpoe3KZUgTv,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(Hl3Dv2jZByIfkTcSds0YzhUwbou)}}
	pjBAh5E2XWYmHx = FoCsyPaNjhWf.dumps(pjBAh5E2XWYmHx)
	SSqweDUBYv4bkO = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',SSqweDUBYv4bkO,pjBAh5E2XWYmHx,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	data = TqNUy3Z4SFWvplGwXC82A('dict',jS6fQGXeouTB7xKd32ZMy)
	return data
def aIlYrXLsv2K(K7ETgQ2pb4ylWIB3vDHjJ,level):
	bXMpofzj7h = NpiZlDX0JH35b6vydUuo4Q(K7ETgQ2pb4ylWIB3vDHjJ,'1')
	AxiBv1cQueOs0 = bXMpofzj7h['facets']
	if level=='1':
		AxiBv1cQueOs0 = AxiBv1cQueOs0['video_categories']
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<div(.*?)/div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for BoRk2n4aEtT3cKL08HPhUO in items:
			CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',BoRk2n4aEtT3cKL08HPhUO+'<',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if not CC7kQojDYxgLq4cBIUWnM6Xdtsh: CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-value=\\"(.*?)\\">(.*?)<',BoRk2n4aEtT3cKL08HPhUO+'<',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			zTFlfH8DhAVryqUjX,title = CC7kQojDYxgLq4cBIUWnM6Xdtsh[0]
			if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			if not K7ETgQ2pb4ylWIB3vDHjJ: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,42,gby0BnUuTNFk,'2','?category='+zTFlfH8DhAVryqUjX)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,42,gby0BnUuTNFk,'2',K7ETgQ2pb4ylWIB3vDHjJ+'&category='+zTFlfH8DhAVryqUjX)
	if level=='2':
		AxiBv1cQueOs0 = AxiBv1cQueOs0['specialist']
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('value="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for CGEMqhOWp3ec18zT,title in items:
			if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			if not CGEMqhOWp3ec18zT: title = title = 'الجميع'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,42,gby0BnUuTNFk,'3',K7ETgQ2pb4ylWIB3vDHjJ+'&specialist='+CGEMqhOWp3ec18zT)
	elif level=='3':
		AxiBv1cQueOs0 = AxiBv1cQueOs0['series']
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('value="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for jpoe3KZUgTv,title in items:
			if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			if not jpoe3KZUgTv: title = title = 'الجميع'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,42,gby0BnUuTNFk,'4',K7ETgQ2pb4ylWIB3vDHjJ+'&series='+jpoe3KZUgTv)
	elif level=='4':
		AxiBv1cQueOs0 = AxiBv1cQueOs0['sort_video']
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('value="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for sort,title in items:
			if not sort: continue
			if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,44,gby0BnUuTNFk,'1',K7ETgQ2pb4ylWIB3vDHjJ+'&sort='+sort)
	return
def Xw3tTz8UD4LK26C(K7ETgQ2pb4ylWIB3vDHjJ,Hl3Dv2jZByIfkTcSds0YzhUwbou):
	bXMpofzj7h = NpiZlDX0JH35b6vydUuo4Q(K7ETgQ2pb4ylWIB3vDHjJ,Hl3Dv2jZByIfkTcSds0YzhUwbou)
	AxiBv1cQueOs0 = bXMpofzj7h['template']
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,43,T6TRUSbecYGWIq29KF)
	AxiBv1cQueOs0 = bXMpofzj7h['facets']['pagination']
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-page="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for kdwXYDMQOjz51Z08W,title in items:
		if Hl3Dv2jZByIfkTcSds0YzhUwbou==kdwXYDMQOjz51Z08W: continue
		if cAIRPFK6boejVU549WzqBGCaJ0r: title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,gby0BnUuTNFk,44,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,K7ETgQ2pb4ylWIB3vDHjJ)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ALMAAREF-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<video src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not SSqweDUBYv4bkO: SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('youtube_url.*?(http.*?)&',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	ytc3dVjPkMHCSmlzvBuO820Q = []
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0].replace('\/','/')
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def fZiYAJH1PcQI2O6LyX4rgT9au8l():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc+'/البث-المباشر-6',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ALMAAREF-LIVE-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	url = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-item=.*?(http.*?)&',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	url = url[0].replace('\/','/')
	YAQOL1eVvqMjsEfIFc(url,CC3nOPFMovd72u,'live')
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	OpmXsvEuJAfFC4NSMx = False
	if search==gby0BnUuTNFk:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		OpmXsvEuJAfFC4NSMx = True
	if search==gby0BnUuTNFk: return
	if not OpmXsvEuJAfFC4NSMx: Xw3tTz8UD4LK26C('?search='+search,'1')
	else: aIlYrXLsv2K('?search='+search,'1')
	return