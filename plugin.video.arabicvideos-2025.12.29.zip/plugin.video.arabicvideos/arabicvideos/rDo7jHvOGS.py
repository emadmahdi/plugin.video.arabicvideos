# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'GOOGLESEARCH'
JB9fyoHr05QOtPjp = '_GOS_'
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==1010: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1011: WjryKiBebavP = RIoLuqH7P1dWpFwQcaeTnJ(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1012: WjryKiBebavP = TBCQEFDAh1ntcUpYiSwluvRG(UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1013: WjryKiBebavP = TVzJKmEdUj3s()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1014: WjryKiBebavP = GB6NaH3OqfYSAmryVcJgWkZ8u7zosb(UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1015: WjryKiBebavP = paAiHyrMBwl9JIoNPG0K64ctC(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1016: WjryKiBebavP = nYkEigQCU8c(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1018: WjryKiBebavP = wDfBSJxOogEMGnR0uVzbWchU2(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==1019: WjryKiBebavP = a3NI0EopMZw(fbmZ9V58PCTz,False)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder','بحث جوجل جديد',gby0BnUuTNFk,1019)
	ygWIQGf25qwVxLkXrYDjp('link','كيف يعمل بحث جوجل','',1013)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'==== كلمات البحث المخزنة ===='+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	CMJFpEZB6xcdYOmewVUbuiRjz = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if CMJFpEZB6xcdYOmewVUbuiRjz:
		CMJFpEZB6xcdYOmewVUbuiRjz = CMJFpEZB6xcdYOmewVUbuiRjz['__SEQUENCED_COLUMNS__']
		for JmMO69oYEwIj in reversed(CMJFpEZB6xcdYOmewVUbuiRjz):
			ygWIQGf25qwVxLkXrYDjp('folder',JmMO69oYEwIj,gby0BnUuTNFk,1019,gby0BnUuTNFk,gby0BnUuTNFk,JmMO69oYEwIj)
	return
def wDfBSJxOogEMGnR0uVzbWchU2(search):
	a3NI0EopMZw(search,True)
	nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def a3NI0EopMZw(search,KXv2edlsq39jx6azAhGrHL7=False):
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	dKZiTbEUxecXgBCD = search.replace(JB9fyoHr05QOtPjp,gby0BnUuTNFk).lower()
	yQL3CMJlYoruDUzRgqFvi,e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = [],[],[]
	if not KXv2edlsq39jx6azAhGrHL7:
		yQL3CMJlYoruDUzRgqFvi = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GOOGLESEARCH_RESULTS',dKZiTbEUxecXgBCD)
		if yQL3CMJlYoruDUzRgqFvi: e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = yQL3CMJlYoruDUzRgqFvi
	if KXv2edlsq39jx6azAhGrHL7 or not yQL3CMJlYoruDUzRgqFvi:
		import hazVQrxyDA
		hazVQrxyDA.JJBxCjHYuZ6ifgasN70(dKZiTbEUxecXgBCD,'_GOOGLE',True)
		vSIAG6u35NP2TsWfxLJDeblC7z = raDWxdNlMBR638O(dKZiTbEUxecXgBCD)
		for BoRk2n4aEtT3cKL08HPhUO in vSIAG6u35NP2TsWfxLJDeblC7z:
			name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 = BoRk2n4aEtT3cKL08HPhUO
			if gwiQ59eNbhY2SlLZB7aOpTDdsk1 in QQMChIwdeVvs3NbaA8xHpi5P: e7Z1bTnG32VhN49cztf.append(BoRk2n4aEtT3cKL08HPhUO)
			else: sAXjFfoJ6uO7gvCGUd.append(BoRk2n4aEtT3cKL08HPhUO)
		e7Z1bTnG32VhN49cztf = sorted(e7Z1bTnG32VhN49cztf,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[xn867tCVlscY4qbWZfh])
		sAXjFfoJ6uO7gvCGUd = sorted(sAXjFfoJ6uO7gvCGUd,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[xn867tCVlscY4qbWZfh])
		CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'GOOGLESEARCH_RESULTS',dKZiTbEUxecXgBCD,[e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd],oHkZjQME4V1vhcUFtCPJ)
		dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DETAILED_GOOGLE',dKZiTbEUxecXgBCD)
		hazVQrxyDA.JJBxCjHYuZ6ifgasN70(dKZiTbEUxecXgBCD,'_GOOGLE',False)
		dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+dKZiTbEUxecXgBCD+"')")
		if e7Z1bTnG32VhN49cztf: tt3DVu1TU8dLAi('','',e1nNXbPrBVDZw,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(e7Z1bTnG32VhN49cztf))+'  مواقع')
		else: e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = jf8yViLFDoqzgC4RB7huQX9lOZb2(dKZiTbEUxecXgBCD,yrcbRSFswvAfEdIWVj)
	ygWIQGf25qwVxLkXrYDjp('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('folder','بحث منفرد لمواقع جوجل',gby0BnUuTNFk,1011,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder','نتائج البحث مفصلة - '+dKZiTbEUxecXgBCD,'opened_sites_google',1012,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('folder','نتائج البحث مقسمة - '+dKZiTbEUxecXgBCD,'listed_sites_google',1012,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder','مواقع جوجل ('+str(len(e7Z1bTnG32VhN49cztf))+') - '+dKZiTbEUxecXgBCD,'',1016,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('link','إعادة بحث جوجل - '+dKZiTbEUxecXgBCD,'',1018,gby0BnUuTNFk,gby0BnUuTNFk,search)
	return
def nYkEigQCU8c(dKZiTbEUxecXgBCD):
	e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = jf8yViLFDoqzgC4RB7huQX9lOZb2(dKZiTbEUxecXgBCD)
	if not e7Z1bTnG32VhN49cztf and not sAXjFfoJ6uO7gvCGUd: return
	aR52oUbOs8d = {}
	for name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 in e7Z1bTnG32VhN49cztf: aR52oUbOs8d[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1
	iarqh36w9VM = list(aR52oUbOs8d.keys())
	import hazVQrxyDA
	BGFSCc6fXDjPtyniZp = hazVQrxyDA.ynLAZbiodSG3QtgIJu2(iarqh36w9VM)
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in BGFSCc6fXDjPtyniZp:
		if isinstance(gwiQ59eNbhY2SlLZB7aOpTDdsk1,tuple):
			wAcHkmPB8a.menuItemsLIST.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			continue
		name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 = aR52oUbOs8d[gwiQ59eNbhY2SlLZB7aOpTDdsk1]
		DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		ygWIQGf25qwVxLkXrYDjp('folder',bcBlK1vyM5VaC2e+name,SSqweDUBYv4bkO,1014,F0u6BZVkOn7H9TvtwyNmh,'',gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'مواقع بجوجل غير موجودة بالبرنامج'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,1015)
	sAXjFfoJ6uO7gvCGUd = sorted(sAXjFfoJ6uO7gvCGUd,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: key[xn867tCVlscY4qbWZfh])
	for name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 in sAXjFfoJ6uO7gvCGUd:
		ygWIQGf25qwVxLkXrYDjp('link','_GOS_'+name,SSqweDUBYv4bkO,1015,F0u6BZVkOn7H9TvtwyNmh,'',gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	return
def jf8yViLFDoqzgC4RB7huQX9lOZb2(dKZiTbEUxecXgBCD,Ayw8bscToPaX29HMBS=w8Ui6RsVhSPrqHfO4):
	e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = [],[]
	if Ayw8bscToPaX29HMBS:
		yQL3CMJlYoruDUzRgqFvi = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GOOGLESEARCH_RESULTS',dKZiTbEUxecXgBCD)
		if yQL3CMJlYoruDUzRgqFvi: e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = yQL3CMJlYoruDUzRgqFvi
	if not e7Z1bTnG32VhN49cztf and not sAXjFfoJ6uO7gvCGUd: tt3DVu1TU8dLAi('','',e1nNXbPrBVDZw,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd
def TBCQEFDAh1ntcUpYiSwluvRG(OwdMnetIWPCHxajY,dKZiTbEUxecXgBCD):
	e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = jf8yViLFDoqzgC4RB7huQX9lOZb2(dKZiTbEUxecXgBCD)
	if not e7Z1bTnG32VhN49cztf and not sAXjFfoJ6uO7gvCGUd: return
	Sa08qyNhlwrkIUeHFvZnC6jR,uy8dKZl6gTvItDimMLPR2CUoAh05Vn = [],{}
	for name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 in e7Z1bTnG32VhN49cztf:
		Sa08qyNhlwrkIUeHFvZnC6jR.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		uy8dKZl6gTvItDimMLPR2CUoAh05Vn[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = hsuNMcwjLK(text)
	import hazVQrxyDA
	hazVQrxyDA.V8R3ZQEmy2dPn0jokFJDCN(dKZiTbEUxecXgBCD,OwdMnetIWPCHxajY,gby0BnUuTNFk,Sa08qyNhlwrkIUeHFvZnC6jR,uy8dKZl6gTvItDimMLPR2CUoAh05Vn)
	return
def RIoLuqH7P1dWpFwQcaeTnJ(dKZiTbEUxecXgBCD):
	e7Z1bTnG32VhN49cztf,sAXjFfoJ6uO7gvCGUd = jf8yViLFDoqzgC4RB7huQX9lOZb2(dKZiTbEUxecXgBCD)
	if not e7Z1bTnG32VhN49cztf and not sAXjFfoJ6uO7gvCGUd: return
	aR52oUbOs8d = {}
	for name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 in e7Z1bTnG32VhN49cztf:
		aR52oUbOs8d[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1
	iarqh36w9VM = list(aR52oUbOs8d.keys())
	import hazVQrxyDA
	BGFSCc6fXDjPtyniZp = hazVQrxyDA.ynLAZbiodSG3QtgIJu2(iarqh36w9VM)
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in BGFSCc6fXDjPtyniZp:
		if isinstance(gwiQ59eNbhY2SlLZB7aOpTDdsk1,tuple):
			wAcHkmPB8a.menuItemsLIST.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			continue
		name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1 = aR52oUbOs8d[gwiQ59eNbhY2SlLZB7aOpTDdsk1]
		DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		text = hsuNMcwjLK(text)
		name = name+' - '+dKZiTbEUxecXgBCD
		ygWIQGf25qwVxLkXrYDjp('folder',bcBlK1vyM5VaC2e+name,gwiQ59eNbhY2SlLZB7aOpTDdsk1,548,F0u6BZVkOn7H9TvtwyNmh,'',text)
	return
def hsuNMcwjLK(title):
	Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة)',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	T3Yrx4yZCRqcH = Cso7iV0ZOw2UW5Ez[0][0] if Cso7iV0ZOw2UW5Ez else title
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	T3Yrx4yZCRqcH = T3Yrx4yZCRqcH.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return T3Yrx4yZCRqcH
def raDWxdNlMBR638O(search):
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	Tf5ueYGZIFl1hraoEOVKi = url+'&start=0&num=100&tbm=vid&udm=7'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'GOOGLESEARCH-SEARCH-1st')
	if not ccV0NKHwQpMun6FtZvAi.succeeded: return []
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	xFmMzKs3GrX2QOdNY1y8VRe4 = bCoOHfPdMryRgauz0IVpth.path.join(Qbw6RD7GBut,'googlesearch')
	if not bCoOHfPdMryRgauz0IVpth.path.exists(xFmMzKs3GrX2QOdNY1y8VRe4):
		try: bCoOHfPdMryRgauz0IVpth.makedirs(xFmMzKs3GrX2QOdNY1y8VRe4)
		except: pass
	items = []
	bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if bXMpofzj7h:
		for AxiBv1cQueOs0 in bXMpofzj7h:
			SSqweDUBYv4bkO,title,text,gQmur3iRSZ9IAOX,name = AxiBv1cQueOs0
			gQmur3iRSZ9IAOX = ''
			items.append([SSqweDUBYv4bkO,title,text,name,gQmur3iRSZ9IAOX])
	else:
		Tf5ueYGZIFl1hraoEOVKi = url+'&start=0&num=200'
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET::SCRAPERS',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'GOOGLESEARCH-SEARCH-2nd')
		if not ccV0NKHwQpMun6FtZvAi.succeeded: return []
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not bXMpofzj7h: bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for AxiBv1cQueOs0 in bXMpofzj7h:
			AxiBv1cQueOs0 = TqNUy3Z4SFWvplGwXC82A('list',AxiBv1cQueOs0)
			if len(AxiBv1cQueOs0)>17:
				SSqweDUBYv4bkO = AxiBv1cQueOs0[17]
				title,text,name,gQmur3iRSZ9IAOX = AxiBv1cQueOs0[31][0:4]
				items.append([SSqweDUBYv4bkO,title,text,name,gQmur3iRSZ9IAOX])
	lH9aPBWjLkINZ3qtU8vg5wmCX,LURPYS5ivD6gqeuIHjrFlVf7 = [],[]
	for BoRk2n4aEtT3cKL08HPhUO in items:
		SSqweDUBYv4bkO,title,text,name,gQmur3iRSZ9IAOX = BoRk2n4aEtT3cKL08HPhUO
		name = name.strip(' ')
		if not name: name = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
		name = AAkN5aCpwrvOPhUYg9(name)
		if 'http://' in gQmur3iRSZ9IAOX or 'https://' in gQmur3iRSZ9IAOX: F0u6BZVkOn7H9TvtwyNmh = gQmur3iRSZ9IAOX
		elif 'data:image/' in gQmur3iRSZ9IAOX and ';base64,' in gQmur3iRSZ9IAOX:
			wXiC9aVk7QbDNn0Jxcgz8rTqOW = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data:image/(\w+);base64,',gQmur3iRSZ9IAOX)
			wXiC9aVk7QbDNn0Jxcgz8rTqOW = wXiC9aVk7QbDNn0Jxcgz8rTqOW[0]
			F0u6BZVkOn7H9TvtwyNmh = bCoOHfPdMryRgauz0IVpth.path.join(xFmMzKs3GrX2QOdNY1y8VRe4,name+'.'+wXiC9aVk7QbDNn0Jxcgz8rTqOW)
			if not bCoOHfPdMryRgauz0IVpth.path.exists(F0u6BZVkOn7H9TvtwyNmh):
				gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.replace('\\u003d','=')
				gQmur3iRSZ9IAOX = gQmur3iRSZ9IAOX.replace('data:image/'+wXiC9aVk7QbDNn0Jxcgz8rTqOW+';base64,','')
				NLKv9etIAHzZ4r = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(gQmur3iRSZ9IAOX)
				open(F0u6BZVkOn7H9TvtwyNmh,'wb').write(NLKv9etIAHzZ4r)
		else: F0u6BZVkOn7H9TvtwyNmh = ''
		gwiQ59eNbhY2SlLZB7aOpTDdsk1 = xDwmHBlp2M6bsScuNaoI90E(name,SSqweDUBYv4bkO)
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in LURPYS5ivD6gqeuIHjrFlVf7:
			LURPYS5ivD6gqeuIHjrFlVf7.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			name = hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			lH9aPBWjLkINZ3qtU8vg5wmCX.append([name,SSqweDUBYv4bkO,title,text,F0u6BZVkOn7H9TvtwyNmh,gwiQ59eNbhY2SlLZB7aOpTDdsk1])
	return lH9aPBWjLkINZ3qtU8vg5wmCX
def GB6NaH3OqfYSAmryVcJgWkZ8u7zosb(SSqweDUBYv4bkO,gwiQ59eNbhY2SlLZB7aOpTDdsk1):
	DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	if bcBlK1vyM5VaC2e: DeScCQAb5ti1ZxUPE()
	else: paAiHyrMBwl9JIoNPG0K64ctC()
	return
def TVzJKmEdUj3s():
	tt3DVu1TU8dLAi('','',e1nNXbPrBVDZw,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def paAiHyrMBwl9JIoNPG0K64ctC(gwiQ59eNbhY2SlLZB7aOpTDdsk1=''):
	tt3DVu1TU8dLAi('','',gwiQ59eNbhY2SlLZB7aOpTDdsk1,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def xDwmHBlp2M6bsScuNaoI90E(name,SSqweDUBYv4bkO):
	p9PORByu6b4aso7CAHLS3Vevtq = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	sMiRfjzPx90H8mEpD = name.lower()
	bV0XGurMKTotw26qY1JWeEm9CZdfa = ''
	for key in list(p9PORByu6b4aso7CAHLS3Vevtq.keys()):
		if key.lower() in sMiRfjzPx90H8mEpD: bV0XGurMKTotw26qY1JWeEm9CZdfa = p9PORByu6b4aso7CAHLS3Vevtq[key]
	if not bV0XGurMKTotw26qY1JWeEm9CZdfa:
		RkntpA1UJDV4vNgyaex6GPWK9YQIcC = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'url')
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in list(wAcHkmPB8a.SITESURLS.keys()):
			deSYLq1hQC = mDR9euKnv4jMSdbEpwcktJz5W6Cf(wAcHkmPB8a.SITESURLS[gwiQ59eNbhY2SlLZB7aOpTDdsk1][0],'url')
			if RkntpA1UJDV4vNgyaex6GPWK9YQIcC==deSYLq1hQC: bV0XGurMKTotw26qY1JWeEm9CZdfa = gwiQ59eNbhY2SlLZB7aOpTDdsk1
	if not bV0XGurMKTotw26qY1JWeEm9CZdfa:
		sMiRfjzPx90H8mEpD = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in list(wAcHkmPB8a.SITESURLS.keys()):
			zKQj0YUiT7Fl4Os9BAt = mDR9euKnv4jMSdbEpwcktJz5W6Cf(wAcHkmPB8a.SITESURLS[gwiQ59eNbhY2SlLZB7aOpTDdsk1][0],'name')
			if sMiRfjzPx90H8mEpD==zKQj0YUiT7Fl4Os9BAt: bV0XGurMKTotw26qY1JWeEm9CZdfa = gwiQ59eNbhY2SlLZB7aOpTDdsk1
	if not bV0XGurMKTotw26qY1JWeEm9CZdfa: bV0XGurMKTotw26qY1JWeEm9CZdfa = name
	bV0XGurMKTotw26qY1JWeEm9CZdfa = bV0XGurMKTotw26qY1JWeEm9CZdfa.upper()
	return bV0XGurMKTotw26qY1JWeEm9CZdfa