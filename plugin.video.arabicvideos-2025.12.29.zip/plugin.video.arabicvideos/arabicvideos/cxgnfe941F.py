# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'YOUTUBE'
JB9fyoHr05QOtPjp = '_YUT_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
eAWmCVg3p67vzq4l9h28os = 0
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text,type,kdwXYDMQOjz51Z08W,name,gQmur3iRSZ9IAOX):
	if	 mode==140: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==141: WjryKiBebavP = soLS1FfXUlh8IvqxWPnKz9VDye(url,name,gQmur3iRSZ9IAOX)
	elif mode==143: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,type)
	elif mode==144: WjryKiBebavP = Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W,text)
	elif mode==145: WjryKiBebavP = iaI1v6JlA2Wnox3prGD9Ph4LqSYyBN(url,kdwXYDMQOjz51Z08W)
	elif mode==147: WjryKiBebavP = IXJR43bYu5C()
	elif mode==148: WjryKiBebavP = pM6BqX7z3atFDv0f()
	elif mode==149: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	if 0:
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'قائمة 1',LhFnEIuPHdoNc+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'قائمة 2',LhFnEIuPHdoNc+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'شخص',LhFnEIuPHdoNc+'/user/TCNofficial',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'موقع',LhFnEIuPHdoNc+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'حساب',LhFnEIuPHdoNc+'/@TheSocialCTV',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'العاب',LhFnEIuPHdoNc+'/gaming',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'افلام',LhFnEIuPHdoNc+'/feed/storefront',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مختارات',LhFnEIuPHdoNc+'/feed/guide_builder',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'قصيرة',LhFnEIuPHdoNc+'/shorts',144,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'تصفح',LhFnEIuPHdoNc+'/youtubei/v1/guide?key=',144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'رئيسية',LhFnEIuPHdoNc+gby0BnUuTNFk,144)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'رائج',LhFnEIuPHdoNc+'/feed/trending?bp=',144)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,149,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الرائجة',LhFnEIuPHdoNc+'/feed/trending',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'التصفح',LhFnEIuPHdoNc+'/youtubei/v1/guide?key=',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'القصيرة',LhFnEIuPHdoNc+'/shorts',144,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مختارات يوتيوب',LhFnEIuPHdoNc+'/feed/guide_builder',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مختارات البرنامج',gby0BnUuTNFk,290)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: قنوات عربية',gby0BnUuTNFk,147)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: قنوات أجنبية',gby0BnUuTNFk,148)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: افلام عربية',LhFnEIuPHdoNc+'/results?search_query=فيلم',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: افلام اجنبية',LhFnEIuPHdoNc+'/results?search_query=movie',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: مسرحيات عربية',LhFnEIuPHdoNc+'/results?search_query=مسرحية',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: مسلسلات عربية',LhFnEIuPHdoNc+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: مسلسلات اجنبية',LhFnEIuPHdoNc+'/results?search_query=series&sp=EgIQAw==',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: مسلسلات كارتون',LhFnEIuPHdoNc+'/results?search_query=كارتون&sp=EgIQAw==',144)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث: خطبة المرجعية',LhFnEIuPHdoNc+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def soLS1FfXUlh8IvqxWPnKz9VDye(url,name,gQmur3iRSZ9IAOX):
	name = A8aFK3BwGne5LIziU(name)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'CHNL:  '+name,url,144,gQmur3iRSZ9IAOX)
	return
def IXJR43bYu5C():
	Xw3tTz8UD4LK26C(LhFnEIuPHdoNc+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def pM6BqX7z3atFDv0f():
	Xw3tTz8UD4LK26C(LhFnEIuPHdoNc+'/results?search_query=tv&sp=EgJAAQ==')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,type):
	url = url.split('&',1)[0]
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb([url],CC3nOPFMovd72u,type,url)
	return
def JvCEb2BZqrM3nXWHfjAi7TVxu(pbx6tGDSRBjg0EsuW2FQ1m,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum):
	level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = xYDJcGlC5PSFpRaX03nLNjZO2Uqum.split('::')
	Hp59hyPUND6kQtMle0xOvg,QkVBNh7Ac0 = [],[]
	if '/youtubei/v1/browse' in url: Hp59hyPUND6kQtMle0xOvg.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: Hp59hyPUND6kQtMle0xOvg.append("yccc['onResponseReceivedCommands']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': Hp59hyPUND6kQtMle0xOvg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['entries']")
	Hp59hyPUND6kQtMle0xOvg.append("yccc['items'][3]['guideSectionRenderer']['items']")
	AdphLnQVWrPZ8EtKvwkqRYl,XNqmZCb6UP,KKB7SotN3RuUaiVF8XYjdEGgpb2 = nr9oJlVBsijM7Qub(pbx6tGDSRBjg0EsuW2FQ1m,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
	if level=='1' and AdphLnQVWrPZ8EtKvwkqRYl:
		if len(XNqmZCb6UP)>1 and 'search_query' not in url:
			for Hvz5hXMmJs37u in range(len(XNqmZCb6UP)):
				PkNp9jg3SscVR5tmME0ALZw = str(Hvz5hXMmJs37u)
				Hp59hyPUND6kQtMle0xOvg = []
				Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['reloadContinuationItemsCommand']['continuationItems']")
				Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['command']")
				Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]")
				GGinQY9gb7uy8VeIrxH5,BoRk2n4aEtT3cKL08HPhUO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(XNqmZCb6UP,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
				if GGinQY9gb7uy8VeIrxH5: QkVBNh7Ac0.append([BoRk2n4aEtT3cKL08HPhUO,url,'2::'+PkNp9jg3SscVR5tmME0ALZw+'::0::0'])
			Hp59hyPUND6kQtMle0xOvg.append("yccc['continuationEndpoint']")
			GGinQY9gb7uy8VeIrxH5,BoRk2n4aEtT3cKL08HPhUO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(pbx6tGDSRBjg0EsuW2FQ1m,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
			if GGinQY9gb7uy8VeIrxH5 and QkVBNh7Ac0 and 'continuationCommand' in list(BoRk2n4aEtT3cKL08HPhUO.keys()):
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/my_main_page_shorts_link'
				QkVBNh7Ac0.append([BoRk2n4aEtT3cKL08HPhUO,SSqweDUBYv4bkO,'1::0::0::0'])
	return XNqmZCb6UP,AdphLnQVWrPZ8EtKvwkqRYl,QkVBNh7Ac0,KKB7SotN3RuUaiVF8XYjdEGgpb2
def KtNgXbZM3AaLJ4dzCIP(pbx6tGDSRBjg0EsuW2FQ1m,XNqmZCb6UP,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum):
	level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = xYDJcGlC5PSFpRaX03nLNjZO2Uqum.split('::')
	Hp59hyPUND6kQtMle0xOvg,d5LY2J4XfzSprmGvs = [],[]
	Hp59hyPUND6kQtMle0xOvg.append("yddd[0]['itemSectionRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['reloadContinuationItemsCommand']['continuationItems']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: Hp59hyPUND6kQtMle0xOvg.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: Hp59hyPUND6kQtMle0xOvg.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yddd["+PkNp9jg3SscVR5tmME0ALZw+"]")
	MKF6qGh5uj,RPzyDZ8CHr0TuvohSfcl,i5ieflG1QtrmoUNkEpHJd6Kv0zcWX = nr9oJlVBsijM7Qub(XNqmZCb6UP,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
	if level=='2' and MKF6qGh5uj:
		if len(RPzyDZ8CHr0TuvohSfcl)>1:
			for Hvz5hXMmJs37u in range(len(RPzyDZ8CHr0TuvohSfcl)):
				OzRDv7jaqg56ihbmQntc8VkJs = str(Hvz5hXMmJs37u)
				Hp59hyPUND6kQtMle0xOvg = []
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['richSectionRenderer']['content']")
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]")
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['richItemRenderer']['content']")
				Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]")
				GGinQY9gb7uy8VeIrxH5,BoRk2n4aEtT3cKL08HPhUO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(RPzyDZ8CHr0TuvohSfcl,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
				if GGinQY9gb7uy8VeIrxH5: d5LY2J4XfzSprmGvs.append([BoRk2n4aEtT3cKL08HPhUO,url,'3::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::0'])
			Hp59hyPUND6kQtMle0xOvg.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			Hp59hyPUND6kQtMle0xOvg.append("yddd[1]")
			GGinQY9gb7uy8VeIrxH5,BoRk2n4aEtT3cKL08HPhUO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(XNqmZCb6UP,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
			if GGinQY9gb7uy8VeIrxH5 and d5LY2J4XfzSprmGvs and 'continuationItemRenderer' in list(BoRk2n4aEtT3cKL08HPhUO.keys()):
				d5LY2J4XfzSprmGvs.append([BoRk2n4aEtT3cKL08HPhUO,url,'3::0::0::0'])
	return RPzyDZ8CHr0TuvohSfcl,MKF6qGh5uj,d5LY2J4XfzSprmGvs,i5ieflG1QtrmoUNkEpHJd6Kv0zcWX
def xW8o7F2IM0REAOXuj6(pbx6tGDSRBjg0EsuW2FQ1m,RPzyDZ8CHr0TuvohSfcl,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum):
	level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = xYDJcGlC5PSFpRaX03nLNjZO2Uqum.split('::')
	Hp59hyPUND6kQtMle0xOvg,YsmxrLlyd60R = [],[]
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['reelShelfRenderer']['items']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee["+OzRDv7jaqg56ihbmQntc8VkJs+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Hp59hyPUND6kQtMle0xOvg.append("yeee")
	yPG4czXkLDNKh1mV0oAJYgfqWQueI,yqZBP7CIsugUEoRaNGYD,korniLJZ2HUj6 = nr9oJlVBsijM7Qub(RPzyDZ8CHr0TuvohSfcl,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
	if level=='3' and yPG4czXkLDNKh1mV0oAJYgfqWQueI:
		if len(yqZBP7CIsugUEoRaNGYD)>0:
			for Hvz5hXMmJs37u in range(len(yqZBP7CIsugUEoRaNGYD)):
				CL65fPGvJR8 = str(Hvz5hXMmJs37u)
				Hp59hyPUND6kQtMle0xOvg = []
				Hp59hyPUND6kQtMle0xOvg.append("yfff["+CL65fPGvJR8+"]['richItemRenderer']['content']")
				Hp59hyPUND6kQtMle0xOvg.append("yfff["+CL65fPGvJR8+"]['gameCardRenderer']['game']")
				Hp59hyPUND6kQtMle0xOvg.append("yfff["+CL65fPGvJR8+"]['itemSectionRenderer']['contents'][0]")
				Hp59hyPUND6kQtMle0xOvg.append("yfff["+CL65fPGvJR8+"]")
				Hp59hyPUND6kQtMle0xOvg.append("yfff")
				GGinQY9gb7uy8VeIrxH5,BoRk2n4aEtT3cKL08HPhUO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(yqZBP7CIsugUEoRaNGYD,gby0BnUuTNFk,Hp59hyPUND6kQtMle0xOvg)
				if GGinQY9gb7uy8VeIrxH5: YsmxrLlyd60R.append([BoRk2n4aEtT3cKL08HPhUO,url,'4::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8])
	return yqZBP7CIsugUEoRaNGYD,yPG4czXkLDNKh1mV0oAJYgfqWQueI,YsmxrLlyd60R,korniLJZ2HUj6
def nr9oJlVBsijM7Qub(GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ,ZQj4wgPeMG7):
	pbx6tGDSRBjg0EsuW2FQ1m,mAvBR12qeiKOGh5aZkNQ = GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ
	XNqmZCb6UP,mAvBR12qeiKOGh5aZkNQ = GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ
	RPzyDZ8CHr0TuvohSfcl,mAvBR12qeiKOGh5aZkNQ = GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ
	yqZBP7CIsugUEoRaNGYD,mAvBR12qeiKOGh5aZkNQ = GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ
	BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx = GGP8MmYrOhZBaQ0y,mAvBR12qeiKOGh5aZkNQ
	count = len(ZQj4wgPeMG7)
	for t3t986iTduqY in range(count):
		try:
			ToxyKtgAqZujns4U2kIeVf5r = eval(ZQj4wgPeMG7[t3t986iTduqY])
			return True,ToxyKtgAqZujns4U2kIeVf5r,t3t986iTduqY+1
		except: pass
	return False,gby0BnUuTNFk,0
def Xw3tTz8UD4LK26C(url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum=gby0BnUuTNFk,data=gby0BnUuTNFk):
	QkVBNh7Ac0,d5LY2J4XfzSprmGvs,YsmxrLlyd60R = [],[],[]
	if '::' not in xYDJcGlC5PSFpRaX03nLNjZO2Uqum: xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '1::0::0::0'
	level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = xYDJcGlC5PSFpRaX03nLNjZO2Uqum.split('::')
	if level=='4': level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = '1',PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8
	data = data.replace('_REMEMBERRESULTS_',gby0BnUuTNFk)
	jS6fQGXeouTB7xKd32ZMy,pbx6tGDSRBjg0EsuW2FQ1m,uWIUplrbFd = nLZiDBGbsUaqjPeXxcYvNkEm0WJ(url,data)
	xYDJcGlC5PSFpRaX03nLNjZO2Uqum = level+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
	if level in ['1','2','3']:
		XNqmZCb6UP,AdphLnQVWrPZ8EtKvwkqRYl,QkVBNh7Ac0,KKB7SotN3RuUaiVF8XYjdEGgpb2 = JvCEb2BZqrM3nXWHfjAi7TVxu(pbx6tGDSRBjg0EsuW2FQ1m,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
		if not AdphLnQVWrPZ8EtKvwkqRYl: return
		qtTHIYlrJLF12KndxDjcBoSNPXi5 = len(QkVBNh7Ac0)
		if qtTHIYlrJLF12KndxDjcBoSNPXi5<2:
			if level=='1': level = '2'
			QkVBNh7Ac0 = []
	xYDJcGlC5PSFpRaX03nLNjZO2Uqum = level+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
	if level in ['2','3']:
		RPzyDZ8CHr0TuvohSfcl,MKF6qGh5uj,d5LY2J4XfzSprmGvs,i5ieflG1QtrmoUNkEpHJd6Kv0zcWX = KtNgXbZM3AaLJ4dzCIP(pbx6tGDSRBjg0EsuW2FQ1m,XNqmZCb6UP,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
		if not MKF6qGh5uj: return
		VHiT7ZGQuIrFJBa30pMtP = len(d5LY2J4XfzSprmGvs)
		if VHiT7ZGQuIrFJBa30pMtP<2:
			if level=='2': level = '3'
			d5LY2J4XfzSprmGvs = []
	xYDJcGlC5PSFpRaX03nLNjZO2Uqum = level+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
	if level in ['3']:
		yqZBP7CIsugUEoRaNGYD,yPG4czXkLDNKh1mV0oAJYgfqWQueI,YsmxrLlyd60R,korniLJZ2HUj6 = xW8o7F2IM0REAOXuj6(pbx6tGDSRBjg0EsuW2FQ1m,RPzyDZ8CHr0TuvohSfcl,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
		if not yPG4czXkLDNKh1mV0oAJYgfqWQueI: return
		Bz4AdMhOJWPF7Iye5igrQjcDpuH9 = len(YsmxrLlyd60R)
	for BoRk2n4aEtT3cKL08HPhUO,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum in QkVBNh7Ac0+d5LY2J4XfzSprmGvs+YsmxrLlyd60R:
		YIt52RTEZ1uoKewhMDBJcOr0z = E4FfaTU7kxAXHqYPOM8t6(BoRk2n4aEtT3cKL08HPhUO,url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	return
def E4FfaTU7kxAXHqYPOM8t6(BoRk2n4aEtT3cKL08HPhUO,url=gby0BnUuTNFk,xYDJcGlC5PSFpRaX03nLNjZO2Uqum=gby0BnUuTNFk):
	if '::' in xYDJcGlC5PSFpRaX03nLNjZO2Uqum: level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = xYDJcGlC5PSFpRaX03nLNjZO2Uqum.split('::')
	else: level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = '1','0','0','0'
	GGinQY9gb7uy8VeIrxH5,title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,count,a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK,TYPStg4uhbnDJ3q5fasMFcWUErB,kQShFUtmHjisOJD8e3PYpNACz = Um95bOYI3ex(BoRk2n4aEtT3cKL08HPhUO)
	XxDqV6Qa2JhTiFBIcPWrLypts93 = '/videos?' in SSqweDUBYv4bkO or '/streams?' in SSqweDUBYv4bkO or '/playlists?' in SSqweDUBYv4bkO
	DItaA3JplQm408OW5evz6MLU = '/channels?' in SSqweDUBYv4bkO or '/shorts?' in SSqweDUBYv4bkO
	if XxDqV6Qa2JhTiFBIcPWrLypts93 or DItaA3JplQm408OW5evz6MLU: SSqweDUBYv4bkO = url
	XxDqV6Qa2JhTiFBIcPWrLypts93 = 'watch?v=' not in SSqweDUBYv4bkO and '/playlist?list=' not in SSqweDUBYv4bkO
	DItaA3JplQm408OW5evz6MLU = '/gaming' not in SSqweDUBYv4bkO  and '/feed/storefront' not in SSqweDUBYv4bkO
	if xYDJcGlC5PSFpRaX03nLNjZO2Uqum[0:5]=='3::0::' and XxDqV6Qa2JhTiFBIcPWrLypts93 and DItaA3JplQm408OW5evz6MLU: SSqweDUBYv4bkO = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in SSqweDUBYv4bkO:
		level,PkNp9jg3SscVR5tmME0ALZw,OzRDv7jaqg56ihbmQntc8VkJs,CL65fPGvJR8 = '1','0','0','0'
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = gby0BnUuTNFk
	uWIUplrbFd = gby0BnUuTNFk
	if '/youtubei/v1/browse' in SSqweDUBYv4bkO or '/youtubei/v1/search' in SSqweDUBYv4bkO or '/my_main_page_shorts_link' in url:
		data = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.youtube.data')
		if data.count(':::')==4:
			NeTZiXsjv0R1k4JMSbqArWn,key,i5wEQ7r8ms0vfX2RqJgb,ew8vYW7mHMDoEJP5dF4,JkjTvbtFlIoDZ70wBiEVcqeWMRL = data.split(':::')
			uWIUplrbFd = NeTZiXsjv0R1k4JMSbqArWn+':::'+key+':::'+i5wEQ7r8ms0vfX2RqJgb+':::'+ew8vYW7mHMDoEJP5dF4+':::'+kQShFUtmHjisOJD8e3PYpNACz
			if '/my_main_page_shorts_link' in url and not SSqweDUBYv4bkO: SSqweDUBYv4bkO = url
			else: SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?key='+key
	if not title:
		global eAWmCVg3p67vzq4l9h28os
		eAWmCVg3p67vzq4l9h28os += 1
		title = 'فيديوهات '+str(eAWmCVg3p67vzq4l9h28os)
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '3'+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
	if not GGinQY9gb7uy8VeIrxH5: return False
	elif 'searchPyvRenderer' in str(BoRk2n4aEtT3cKL08HPhUO): return False
	elif '/about' in SSqweDUBYv4bkO: return False
	elif '/community' in SSqweDUBYv4bkO: return False
	elif 'continuationItemRenderer' in list(BoRk2n4aEtT3cKL08HPhUO.keys()) or 'continuationCommand' in list(BoRk2n4aEtT3cKL08HPhUO.keys()):
		if int(level)>1: level = str(int(level)-1)
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = level+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: '+'صفحة أخرى',SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum,uWIUplrbFd)
	elif '/search' in SSqweDUBYv4bkO:
		title = ':: '+title
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '3'+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
		url = url.replace('/search',gby0BnUuTNFk)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,145,gby0BnUuTNFk,xYDJcGlC5PSFpRaX03nLNjZO2Uqum,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not SSqweDUBYv4bkO:
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '3'+'::'+PkNp9jg3SscVR5tmME0ALZw+'::'+OzRDv7jaqg56ihbmQntc8VkJs+'::'+CL65fPGvJR8
		title = ':: '+title
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum,uWIUplrbFd)
	elif '/browse' in SSqweDUBYv4bkO and url==LhFnEIuPHdoNc:
		title = ':: '+title
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '2::0::0::0'
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum,uWIUplrbFd)
	elif not SSqweDUBYv4bkO and 'horizontalMovieListRenderer' in str(BoRk2n4aEtT3cKL08HPhUO):
		title = ':: '+title
		xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '3::0::0::0'
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	elif 'messageRenderer' in str(BoRk2n4aEtT3cKL08HPhUO):
		ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+title,gby0BnUuTNFk,9999)
	elif PsFSzbRdNeML09QpW87xU4o6VTK:
		ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+PsFSzbRdNeML09QpW87xU4o6VTK+title,SSqweDUBYv4bkO,143,T6TRUSbecYGWIq29KF)
	elif '/playlist?list=' in SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('&playnext=1',gby0BnUuTNFk)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'LIST'+count+':  '+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	elif '/shorts/' in SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('&list=',1)[0]
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,143,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
	elif '/watch?v=' in SSqweDUBYv4bkO:
		if '&list=' in SSqweDUBYv4bkO and count:
			Lc8GAfiPKJ = SSqweDUBYv4bkO.split('&list=',1)[1]
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/playlist?list='+Lc8GAfiPKJ
			xYDJcGlC5PSFpRaX03nLNjZO2Uqum = '1::0::0::0'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'LIST'+count+':  '+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
		else:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('&list=',1)[0]
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,143,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
	elif '/channel/' in SSqweDUBYv4bkO or '/c/' in SSqweDUBYv4bkO or ('/@' in SSqweDUBYv4bkO and SSqweDUBYv4bkO.count('/')==3):
		if cAIRPFK6boejVU549WzqBGCaJ0r:
			title = title.decode(JJQFjSIlALchiMzG9).encode('raw_unicode_escape')
			title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'CHNL'+count+':  '+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	elif '/user/' in SSqweDUBYv4bkO:
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'USER'+count+':  '+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	else:
		if not SSqweDUBYv4bkO: SSqweDUBYv4bkO = url
		title = ':: '+title
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,144,T6TRUSbecYGWIq29KF,xYDJcGlC5PSFpRaX03nLNjZO2Uqum,uWIUplrbFd)
	return True
def Um95bOYI3ex(BoRk2n4aEtT3cKL08HPhUO):
	GGinQY9gb7uy8VeIrxH5,title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,count,a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK,TYPStg4uhbnDJ3q5fasMFcWUErB,JkjTvbtFlIoDZ70wBiEVcqeWMRL = False,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	if not isinstance(BoRk2n4aEtT3cKL08HPhUO,dict): return GGinQY9gb7uy8VeIrxH5,title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,count,a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK,TYPStg4uhbnDJ3q5fasMFcWUErB,JkjTvbtFlIoDZ70wBiEVcqeWMRL
	for aQKz8qIBCj in list(BoRk2n4aEtT3cKL08HPhUO.keys()):
		qkHKI2PglUetGSBfuQrEhNx = BoRk2n4aEtT3cKL08HPhUO[aQKz8qIBCj]
		if isinstance(qkHKI2PglUetGSBfuQrEhNx,dict): break
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['header']['richListHeaderRenderer']['title']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['headline']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['unplayableText']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['formattedTitle']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['title']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['title']['runs'][0]['text']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['text']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['text']['runs'][0]['text']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['title']['content']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['title']")
	Hp59hyPUND6kQtMle0xOvg.append("item['title']")
	Hp59hyPUND6kQtMle0xOvg.append("item['reelWatchEndpoint']['videoId']")
	GGinQY9gb7uy8VeIrxH5,title,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Hp59hyPUND6kQtMle0xOvg.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Hp59hyPUND6kQtMle0xOvg.append("item['commandMetadata']['webCommandMetadata']['url']")
	GGinQY9gb7uy8VeIrxH5,SSqweDUBYv4bkO,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnail']['thumbnails'][0]['url']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	Hp59hyPUND6kQtMle0xOvg.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	GGinQY9gb7uy8VeIrxH5,T6TRUSbecYGWIq29KF,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['videoCountShortText']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['videoCountText']['runs'][0]['text']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['videoCount']")
	GGinQY9gb7uy8VeIrxH5,count,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['lengthText']['simpleText']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	GGinQY9gb7uy8VeIrxH5,a8tFl4fNpx2Ou65q,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	Hp59hyPUND6kQtMle0xOvg = []
	Hp59hyPUND6kQtMle0xOvg.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	Hp59hyPUND6kQtMle0xOvg.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	GGinQY9gb7uy8VeIrxH5,JkjTvbtFlIoDZ70wBiEVcqeWMRL,VUIYkcERzXphNiuwvxJybGT = nr9oJlVBsijM7Qub(BoRk2n4aEtT3cKL08HPhUO,qkHKI2PglUetGSBfuQrEhNx,Hp59hyPUND6kQtMle0xOvg)
	if 'LIVE' in a8tFl4fNpx2Ou65q: a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK = gby0BnUuTNFk,'LIVE:  '
	if 'مباشر' in a8tFl4fNpx2Ou65q: a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK = gby0BnUuTNFk,'LIVE:  '
	if 'badges' in list(qkHKI2PglUetGSBfuQrEhNx.keys()):
		QngLJwX52ad3clVEpsSfbFqBDMr = str(qkHKI2PglUetGSBfuQrEhNx['badges'])
		if 'Free with Ads' in QngLJwX52ad3clVEpsSfbFqBDMr: TYPStg4uhbnDJ3q5fasMFcWUErB = '$:  '
		if 'LIVE' in QngLJwX52ad3clVEpsSfbFqBDMr: PsFSzbRdNeML09QpW87xU4o6VTK = 'LIVE:  '
		if 'Buy' in QngLJwX52ad3clVEpsSfbFqBDMr or 'Rent' in QngLJwX52ad3clVEpsSfbFqBDMr: TYPStg4uhbnDJ3q5fasMFcWUErB = '$$:  '
		if syFKrN8pIlTDZL6x(u'مباشر') in QngLJwX52ad3clVEpsSfbFqBDMr: PsFSzbRdNeML09QpW87xU4o6VTK = 'LIVE:  '
		if syFKrN8pIlTDZL6x(u'شراء') in QngLJwX52ad3clVEpsSfbFqBDMr: TYPStg4uhbnDJ3q5fasMFcWUErB = '$$:  '
		if syFKrN8pIlTDZL6x(u'استئجار') in QngLJwX52ad3clVEpsSfbFqBDMr: TYPStg4uhbnDJ3q5fasMFcWUErB = '$$:  '
		if syFKrN8pIlTDZL6x(u'إعلانات') in QngLJwX52ad3clVEpsSfbFqBDMr: TYPStg4uhbnDJ3q5fasMFcWUErB = '$:  '
	SSqweDUBYv4bkO = biVjhGCg0v5eEzkHwTrK9FIAtPU2(SSqweDUBYv4bkO)
	if SSqweDUBYv4bkO and 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
	T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.split('?')[0]
	if  T6TRUSbecYGWIq29KF and 'http' not in T6TRUSbecYGWIq29KF: T6TRUSbecYGWIq29KF = 'https:'+T6TRUSbecYGWIq29KF
	title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
	if TYPStg4uhbnDJ3q5fasMFcWUErB: title = TYPStg4uhbnDJ3q5fasMFcWUErB+title
	a8tFl4fNpx2Ou65q = a8tFl4fNpx2Ou65q.replace(',',gby0BnUuTNFk)
	count = count.replace(',',gby0BnUuTNFk)
	count = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('\d+',count)
	if count: count = count[0]
	else: count = gby0BnUuTNFk
	return True,title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,count,a8tFl4fNpx2Ou65q,PsFSzbRdNeML09QpW87xU4o6VTK,TYPStg4uhbnDJ3q5fasMFcWUErB,JkjTvbtFlIoDZ70wBiEVcqeWMRL
def nLZiDBGbsUaqjPeXxcYvNkEm0WJ(url,data=gby0BnUuTNFk,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	if Z05rTiu6LwakteK8VfY==gby0BnUuTNFk: Z05rTiu6LwakteK8VfY = 'ytInitialData'
	E9LlzOuYdp20rKcn13BUqDGsh8StIQ = Zc6lYG3a02XVPA1WLr()
	IciL6hoO5F1MDSVPjypWZs8kKx = {'User-Agent':E9LlzOuYdp20rKcn13BUqDGsh8StIQ,'Cookie':'PREF=hl=ar'}
	global SF3Htydw7Y5sgjIE0OrLTKoQ
	if not data: data = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.youtube.data')
	if data.count(':::')==4: NeTZiXsjv0R1k4JMSbqArWn,key,i5wEQ7r8ms0vfX2RqJgb,ew8vYW7mHMDoEJP5dF4,JkjTvbtFlIoDZ70wBiEVcqeWMRL = data.split(':::')
	else: NeTZiXsjv0R1k4JMSbqArWn,key,i5wEQ7r8ms0vfX2RqJgb,ew8vYW7mHMDoEJP5dF4,JkjTvbtFlIoDZ70wBiEVcqeWMRL = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	uWIUplrbFd = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":i5wEQ7r8ms0vfX2RqJgb}}}
	if url==LhFnEIuPHdoNc+'/shorts' or '/my_main_page_shorts_link' in url:
		url = LhFnEIuPHdoNc+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		uWIUplrbFd['sequenceParams'] = NeTZiXsjv0R1k4JMSbqArWn
		uWIUplrbFd = str(uWIUplrbFd)
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',url,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = LhFnEIuPHdoNc+'/youtubei/v1/guide?key='+key
		uWIUplrbFd = str(uWIUplrbFd)
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',url,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and NeTZiXsjv0R1k4JMSbqArWn:
		uWIUplrbFd['continuation'] = JkjTvbtFlIoDZ70wBiEVcqeWMRL
		uWIUplrbFd['context']['client']['visitorData'] = NeTZiXsjv0R1k4JMSbqArWn
		uWIUplrbFd = str(uWIUplrbFd)
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',url,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and ew8vYW7mHMDoEJP5dF4:
		IciL6hoO5F1MDSVPjypWZs8kKx.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':i5wEQ7r8ms0vfX2RqJgb})
		IciL6hoO5F1MDSVPjypWZs8kKx.update({'Cookie':'VISITOR_INFO1_LIVE='+ew8vYW7mHMDoEJP5dF4})
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'YOUTUBE-GET_PAGE_DATA-6th')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"innertubeApiKey".*?"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.I)
	if CC7kQojDYxgLq4cBIUWnM6Xdtsh: key = CC7kQojDYxgLq4cBIUWnM6Xdtsh[0]
	CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"cver".*?"value".*?"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.I)
	if CC7kQojDYxgLq4cBIUWnM6Xdtsh: i5wEQ7r8ms0vfX2RqJgb = CC7kQojDYxgLq4cBIUWnM6Xdtsh[0]
	CC7kQojDYxgLq4cBIUWnM6Xdtsh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"visitorData".*?"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.I)
	if CC7kQojDYxgLq4cBIUWnM6Xdtsh: NeTZiXsjv0R1k4JMSbqArWn = CC7kQojDYxgLq4cBIUWnM6Xdtsh[0]
	cookies = ccV0NKHwQpMun6FtZvAi.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): ew8vYW7mHMDoEJP5dF4 = cookies['VISITOR_INFO1_LIVE']
	XrZ4CFAnRta5oSET9Vwe02lKGh = NeTZiXsjv0R1k4JMSbqArWn+':::'+key+':::'+i5wEQ7r8ms0vfX2RqJgb+':::'+ew8vYW7mHMDoEJP5dF4+':::'+JkjTvbtFlIoDZ70wBiEVcqeWMRL
	if Z05rTiu6LwakteK8VfY=='ytInitialData' and 'ytInitialData' in jS6fQGXeouTB7xKd32ZMy:
		wb4j8vJcZ35DfkSm0aCU9XQN7pOP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('window\["ytInitialData"\] = ({.*?});',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not wb4j8vJcZ35DfkSm0aCU9XQN7pOP: wb4j8vJcZ35DfkSm0aCU9XQN7pOP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('var ytInitialData = ({.*?});',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		BlybRIgH3umC2pDK1c4QkWYXSLiVf = TqNUy3Z4SFWvplGwXC82A('str',wb4j8vJcZ35DfkSm0aCU9XQN7pOP[0])
	elif Z05rTiu6LwakteK8VfY=='ytInitialGuideData' and 'ytInitialGuideData' in jS6fQGXeouTB7xKd32ZMy:
		wb4j8vJcZ35DfkSm0aCU9XQN7pOP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('var ytInitialGuideData = ({.*?});',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		BlybRIgH3umC2pDK1c4QkWYXSLiVf = TqNUy3Z4SFWvplGwXC82A('str',wb4j8vJcZ35DfkSm0aCU9XQN7pOP[0])
	elif '</script>' not in jS6fQGXeouTB7xKd32ZMy: BlybRIgH3umC2pDK1c4QkWYXSLiVf = TqNUy3Z4SFWvplGwXC82A('str',jS6fQGXeouTB7xKd32ZMy)
	else: BlybRIgH3umC2pDK1c4QkWYXSLiVf = gby0BnUuTNFk
	if 0:
		pbx6tGDSRBjg0EsuW2FQ1m = str(BlybRIgH3umC2pDK1c4QkWYXSLiVf)
		if nqkybtoMBH: pbx6tGDSRBjg0EsuW2FQ1m = pbx6tGDSRBjg0EsuW2FQ1m.encode(JJQFjSIlALchiMzG9)
		open('S:\\0000emad.dat','wb').write(pbx6tGDSRBjg0EsuW2FQ1m)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.youtube.data',XrZ4CFAnRta5oSET9Vwe02lKGh)
	return jS6fQGXeouTB7xKd32ZMy,BlybRIgH3umC2pDK1c4QkWYXSLiVf,XrZ4CFAnRta5oSET9Vwe02lKGh
def iaI1v6JlA2Wnox3prGD9Ph4LqSYyBN(url,xYDJcGlC5PSFpRaX03nLNjZO2Uqum):
	search = vRoGedUjt2Ac6pIbufBX8sKy()
	if not search: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	Tf5ueYGZIFl1hraoEOVKi = url+'/search?query='+search
	Xw3tTz8UD4LK26C(Tf5ueYGZIFl1hraoEOVKi,xYDJcGlC5PSFpRaX03nLNjZO2Uqum)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in K7ETgQ2pb4ylWIB3vDHjJ: btFaUz5SKCMT2ORVu9i76 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in K7ETgQ2pb4ylWIB3vDHjJ: btFaUz5SKCMT2ORVu9i76 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in K7ETgQ2pb4ylWIB3vDHjJ: btFaUz5SKCMT2ORVu9i76 = '&sp=EgIQAg%253D%253D'
		else: btFaUz5SKCMT2ORVu9i76 = gby0BnUuTNFk
		mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi+btFaUz5SKCMT2ORVu9i76
	else:
		vAqxjKhwn16IM274TDEUgfHbeptu3,jIn6votTHzlE0kc,T3Yrx4yZCRqcH = [],[],gby0BnUuTNFk
		DDgLzYb9hWaBpN1qsZj = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		t7obPZcCqH3jXY = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		t8J5Wh0KDdXQvkL7xyE = i4r2OdGLlMhDEWfCVU0TKe3('اختر البحث المناسب',DDgLzYb9hWaBpN1qsZj)
		if t8J5Wh0KDdXQvkL7xyE == -1: return
		I62IhBOQ7daXSL = t7obPZcCqH3jXY[t8J5Wh0KDdXQvkL7xyE]
		jS6fQGXeouTB7xKd32ZMy,FyTHmCkslS7Y5UvdRLEnGD,data = nLZiDBGbsUaqjPeXxcYvNkEm0WJ(Tf5ueYGZIFl1hraoEOVKi+I62IhBOQ7daXSL)
		if FyTHmCkslS7Y5UvdRLEnGD:
			try:
				P6VbyziFnqGxjNwAEhf7 = FyTHmCkslS7Y5UvdRLEnGD['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for BB9eKIphS4Has2t in range(len(P6VbyziFnqGxjNwAEhf7)):
					group = P6VbyziFnqGxjNwAEhf7[BB9eKIphS4Has2t]['searchFilterGroupRenderer']['filters']
					for E9EBGVc8xgSqT1asldhFofnD in range(len(group)):
						qkHKI2PglUetGSBfuQrEhNx = group[E9EBGVc8xgSqT1asldhFofnD]['searchFilterRenderer']
						if 'navigationEndpoint' in list(qkHKI2PglUetGSBfuQrEhNx.keys()):
							SSqweDUBYv4bkO = qkHKI2PglUetGSBfuQrEhNx['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('\u0026','&')
							title = qkHKI2PglUetGSBfuQrEhNx['tooltip']
							title = title.replace('البحث عن ',gby0BnUuTNFk)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								T3Yrx4yZCRqcH = title
								RkntpA1UJDV4vNgyaex6GPWK9YQIcC = SSqweDUBYv4bkO
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',gby0BnUuTNFk)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								T3Yrx4yZCRqcH = title
								RkntpA1UJDV4vNgyaex6GPWK9YQIcC = SSqweDUBYv4bkO
							if 'Sort by' in title: continue
							vAqxjKhwn16IM274TDEUgfHbeptu3.append(biVjhGCg0v5eEzkHwTrK9FIAtPU2(title))
							jIn6votTHzlE0kc.append(SSqweDUBYv4bkO)
			except: pass
		if not T3Yrx4yZCRqcH: ChVc1iKk4Z7mMnubJ8qLrEdH = gby0BnUuTNFk
		else:
			vAqxjKhwn16IM274TDEUgfHbeptu3 = ['بدون فلتر',T3Yrx4yZCRqcH]+vAqxjKhwn16IM274TDEUgfHbeptu3
			jIn6votTHzlE0kc = [gby0BnUuTNFk,RkntpA1UJDV4vNgyaex6GPWK9YQIcC]+jIn6votTHzlE0kc
			qkPxQcJOHnVMhEL5WFBgy79 = i4r2OdGLlMhDEWfCVU0TKe3('موقع يوتيوب - اختر الفلتر',vAqxjKhwn16IM274TDEUgfHbeptu3)
			if qkPxQcJOHnVMhEL5WFBgy79 == -1: return
			ChVc1iKk4Z7mMnubJ8qLrEdH = jIn6votTHzlE0kc[qkPxQcJOHnVMhEL5WFBgy79]
		if ChVc1iKk4Z7mMnubJ8qLrEdH: mm7pzl3HMi0R8fGu = LhFnEIuPHdoNc+ChVc1iKk4Z7mMnubJ8qLrEdH
		elif I62IhBOQ7daXSL: mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi+I62IhBOQ7daXSL
		else: mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi
	Xw3tTz8UD4LK26C(mm7pzl3HMi0R8fGu)
	return