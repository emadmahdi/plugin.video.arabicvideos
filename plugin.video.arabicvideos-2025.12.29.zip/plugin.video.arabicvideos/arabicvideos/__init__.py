# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from IER9OUbYLX import *
CC3nOPFMovd72u = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡉࡏࡋࡗࠫᏵ")
ymZblQcjn0EKDAaxFX5SpdVRvM = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧ᏶")
OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = LLaKvkewEFxtfplOgHJCM(CH4Gk8XMzDVvl)
LxWiszo6Gm0J9RvuMNn = int(KIwAPk6E3vN4iUqf1n8HrJLQb)
JRNUShdGaF9mZrC = oKew16fsvuV8.getInfoLabel(IXE6voNmrb182AyQ(u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ᏷"))
JRNUShdGaF9mZrC = JRNUShdGaF9mZrC.replace(p5pEP1SAfZu0xnHryoDMeslWz8,gby0BnUuTNFk).replace(AA3TV9QvHD5sRPulgJn6,gby0BnUuTNFk)
if LxWiszo6Gm0J9RvuMNn==Ducd5PRjQXaB9SIN7VrJ1G(u"࠲࠷࠲ᐠ"): Kvu4mwk0qabJlRQ = ne7wF4gSTRZo(u"ࠩࠣࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪᏸ")+eQNGiXdboqPt57O+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࠤࡢࠦࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪᏹ")+czEtQTYp3Hl0VAePNInKuM7kCODmj+MlTVLBZ92kzorIq1Yw(u"ࠫࠥࡣࠧᏺ")
else:
	lUiDj895LKosZNYbdw13OhV2B = pFnO2T7r16k(CH4Gk8XMzDVvl).replace(MMDuRFyAGhOpnq4YmXa9Jc7dNfSx,gby0BnUuTNFk).replace(bKN9diGf8nmgecQPEqUzHRpoDuaO,gby0BnUuTNFk)
	lUiDj895LKosZNYbdw13OhV2B = lUiDj895LKosZNYbdw13OhV2B.replace(GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
	lUiDj895LKosZNYbdw13OhV2B = lUiDj895LKosZNYbdw13OhV2B.replace(TFAVlh4ONfuyivg,UpN1CezytPO9XoduhxZSD).replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	if DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࠬࡵࡳ࡮ࡀࠫᏻ") in lUiDj895LKosZNYbdw13OhV2B:
		lUiDj895LKosZNYbdw13OhV2B,NI2LdU678ouKXJicxfgnjVHPysEZ = lUiDj895LKosZNYbdw13OhV2B.rsplit(iiauUxMktNW5X(u"࠭ࠦࡶࡴ࡯ࡁࠬᏼ"),n6JjFHfmydIaLut(u"࠲ᐡ"))
		lUiDj895LKosZNYbdw13OhV2B += nJF7oflOk6cLGSAey(u"ࠧࠧࡷࡵࡰࡂ࠭ᏽ")+oHSEYlfpLzQrC1(NI2LdU678ouKXJicxfgnjVHPysEZ,CC3nOPFMovd72u)
	Kvu4mwk0qabJlRQ = RRbvqditj184m3(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ᏾")+JRNUShdGaF9mZrC+TeYukOUW7i5NBM926DCjaAn0(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ᏿")+KIwAPk6E3vN4iUqf1n8HrJLQb+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ᐀")+lUiDj895LKosZNYbdw13OhV2B+iI7tuF0nEQoR(u"ࠫࠥࡣࠧᐁ")
SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,ymZblQcjn0EKDAaxFX5SpdVRvM+okfdjS4RmM+FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+Kvu4mwk0qabJlRQ)
if iiauUxMktNW5X(u"ࠬࡥࠧᐂ") in wH1a6KyFuLn: BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn = wH1a6KyFuLn.split(iiauUxMktNW5X(u"࠭࡟ࠨᐃ"),jxCVeKSLb9rGDOl0Qtw6)
else: BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn = wH1a6KyFuLn,gby0BnUuTNFk
wAcHkmPB8a.Uzo7FMNr5YDA2q13d6,fSqpV0sUvcr153IYbT9lKezQRE7 = yrcbRSFswvAfEdIWVj,gby0BnUuTNFk
aD7nWjOPz2Vb9eiwsU65k3qd = yrcbRSFswvAfEdIWVj
if BF13hLNMY6OJqRyCmiGZ9s7zwPr5t in [FAwWlRJg0UkN1(u"ࠧ࠲ࠩᐄ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨ࠴ࠪᐅ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠩ࠶ࠫᐆ"),MlTVLBZ92kzorIq1Yw(u"ࠪ࠸ࠬᐇ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫ࠺࠭ᐈ"),YZXtBgvUPoM5sb(u"ࠬ࠷࠱ࠨᐉ"),iiLyoNwGbH03DIXhAkZn(u"࠭࠱࠳ࠩᐊ"),FAwWlRJg0UkN1(u"ࠧ࠲࠵ࠪᐋ")] and (YZXtBgvUPoM5sb(u"ࠨࡃࡇࡈࠬᐌ") in QOazpItrTElo23ULn or i80mE7lHUwVk(u"ࠩࡕࡉࡒࡕࡖࡆࠩᐍ") in QOazpItrTElo23ULn or ne7wF4gSTRZo(u"࡙ࠪࡕ࠭ᐎ") in QOazpItrTElo23ULn or q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡉࡕࡗࡏࠩᐏ") in QOazpItrTElo23ULn):
	from N7YIpvW3kX import qG8C65PDabzS
	qG8C65PDabzS(wH1a6KyFuLn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᐐ"),CH4Gk8XMzDVvl)
	wAcHkmPB8a.Uzo7FMNr5YDA2q13d6 = w8Ui6RsVhSPrqHfO4
elif not BF13hLNMY6OJqRyCmiGZ9s7zwPr5t and not jxBbwd2W6Xk and LxWiszo6Gm0J9RvuMNn in [IXE6voNmrb182AyQ(u"࠴࠶࠹ᐢ"),YZXtBgvUPoM5sb(u"࠺࠵࠺ᐣ")]:
	To1jOLBdtPWhFayp = str(ZgSKTRL2DlPprjU57W93zf4EF[n6JjFHfmydIaLut(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐑ")])
	CC3nOPFMovd72u = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡊࡒࡗ࡚ࠬᐒ") if LxWiszo6Gm0J9RvuMNn==nJF7oflOk6cLGSAey(u"࠶࠸࠻ᐤ") else q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡏ࠶࡙ࠬᐓ")
	Wu9mv73HOfeLciq = CC3nOPFMovd72u.lower()
	E9LlzOuYdp20rKcn13BUqDGsh8StIQ = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(RRbvqditj184m3(u"ࠩࡤࡺ࠳࠭ᐔ")+Wu9mv73HOfeLciq+FAwWlRJg0UkN1(u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨᐕ")+To1jOLBdtPWhFayp)
	vz5laUNHCeWuwr81 = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(MlTVLBZ92kzorIq1Yw(u"ࠫࡦࡼ࠮ࠨᐖ")+Wu9mv73HOfeLciq+NupI74tJCzYXmles9SbR6(u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨᐗ")+To1jOLBdtPWhFayp)
	if E9LlzOuYdp20rKcn13BUqDGsh8StIQ or vz5laUNHCeWuwr81:
		KKFPNRzufO += iiauUxMktNW5X(u"࠭ࡼࠨᐘ")
		if E9LlzOuYdp20rKcn13BUqDGsh8StIQ: KKFPNRzufO += MlTVLBZ92kzorIq1Yw(u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᐙ")+E9LlzOuYdp20rKcn13BUqDGsh8StIQ
		if vz5laUNHCeWuwr81: KKFPNRzufO += MlTVLBZ92kzorIq1Yw(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᐚ")+vz5laUNHCeWuwr81
		KKFPNRzufO = KKFPNRzufO.replace(RRbvqditj184m3(u"ࠩࡿࠪࠬᐛ"),VzO1gCHmjZ2ebRIL(u"ࠪࢀࠬᐜ"))
	Jm3fKMdlR9Z0z2TrF6w8sVGxu7AaL = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(n6JjFHfmydIaLut(u"ࠫࡦࡼ࠮ࠨᐝ")+Wu9mv73HOfeLciq+mmbcsf2pd7gyjzreB(u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧᐞ")+To1jOLBdtPWhFayp)
	if Jm3fKMdlR9Z0z2TrF6w8sVGxu7AaL:
		wVxBARKaOF406f5Ui2YEuCJ1cb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iiauUxMktNW5X(u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩᐟ"),KKFPNRzufO,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		KKFPNRzufO = KKFPNRzufO.replace(wVxBARKaOF406f5Ui2YEuCJ1cb[xn867tCVlscY4qbWZfh],Jm3fKMdlR9Z0z2TrF6w8sVGxu7AaL)
	YAQOL1eVvqMjsEfIFc(KKFPNRzufO,CC3nOPFMovd72u,OORugdCwcD9UrzXtT7vML1FWasP)
	aD7nWjOPz2Vb9eiwsU65k3qd = w8Ui6RsVhSPrqHfO4
else:
	import V4OX6PRG0U
	try: V4OX6PRG0U.SKYeAy2ROlnkE0vP3Z(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF,LxWiszo6Gm0J9RvuMNn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn,JRNUShdGaF9mZrC)
	except Exception as xNE4SpiDJq6Cw8l: fSqpV0sUvcr153IYbT9lKezQRE7 = WhjmDeqacBg.format_exc()
y81yf2hrBiMXKd(wAcHkmPB8a.Uzo7FMNr5YDA2q13d6,fSqpV0sUvcr153IYbT9lKezQRE7,aD7nWjOPz2Vb9eiwsU65k3qd)