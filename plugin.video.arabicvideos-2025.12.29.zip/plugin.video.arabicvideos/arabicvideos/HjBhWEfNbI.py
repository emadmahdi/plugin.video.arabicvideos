# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'BOKRA'
JB9fyoHr05QOtPjp = '_BKR_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
headers = {'User-Agent':gby0BnUuTNFk}
d2gCoAnYPG89O = ['افلام للكبار','بكرا TV']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==370: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==371: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==372: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==374: WjryKiBebavP = bQsEyAWJgHY(url)
	elif mode==375: WjryKiBebavP = kX7ZnSzVBwKe0NoIT8dh(url)
	elif mode==376: WjryKiBebavP = QHoncN8JMhz2ErkKltOZ(0,url)
	elif mode==377: WjryKiBebavP = QHoncN8JMhz2ErkKltOZ(1,url)
	elif mode==379: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-MENU-1st')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,379,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('right-side(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المميزة',LhFnEIuPHdoNc,375)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الأحدث',LhFnEIuPHdoNc,376)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'قائمة الممثلين',LhFnEIuPHdoNc,374)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="container"(.*?)top-menu',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items[7:]:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371)
		for SSqweDUBYv4bkO,title in items[0:7]:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371)
	return
def bQsEyAWJgHY(website=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-ACTORSMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="row cat Tags"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if 'http' in SSqweDUBYv4bkO: continue
			else: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371)
	return
def kX7ZnSzVBwKe0NoIT8dh(website=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-FEATURED-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"MainContent"(.*?)main-title2',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('://',':///').replace('//','/').replace(UpN1CezytPO9XoduhxZSD,'%20')
				ygWIQGf25qwVxLkXrYDjp('video',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,372,T6TRUSbecYGWIq29KF)
	return
def QHoncN8JMhz2ErkKltOZ(id,website=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-WATCHINGNOW-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-title2(.*?)class="row',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[id]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if not any(value in title for value in d2gCoAnYPG89O):
				T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('://',':///').replace('//','/').replace(UpN1CezytPO9XoduhxZSD,'%20')
				ygWIQGf25qwVxLkXrYDjp('video',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,372,T6TRUSbecYGWIq29KF)
	return
def Xw3tTz8UD4LK26C(url,ttFbmiRrEfBUl=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if 'vidpage_' in url:
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(/Album-.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if SSqweDUBYv4bkO:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO[0]
			Xw3tTz8UD4LK26C(SSqweDUBYv4bkO)
			return
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class=" subcats"(.*?)class="col-md-3',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if ttFbmiRrEfBUl==gby0BnUuTNFk and QKqM0CwXDk8APOoJFpyntRb and QKqM0CwXDk8APOoJFpyntRb[0].count('href')>1:
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',url,371,gby0BnUuTNFk,gby0BnUuTNFk,'titles')
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371)
	else:
		NGcX5a4OifEhZKrY7C0QVyjRA = []
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="col-md-3(.*?)col-xs-12',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="col-sm-8"(.*?)col-xs-12',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('://',':///').replace('//','/').replace(UpN1CezytPO9XoduhxZSD,'%20')
				if '/al_' in SSqweDUBYv4bkO:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371,T6TRUSbecYGWIq29KF)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) - +الحلقة +\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					if Cso7iV0ZOw2UW5Ez: title = '_MOD_مسلسل '+Cso7iV0ZOw2UW5Ez[0]
					if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
						NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
						ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371,T6TRUSbecYGWIq29KF)
				else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,372,T6TRUSbecYGWIq29KF)
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				title = 'صفحة '+Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,371,gby0BnUuTNFk,gby0BnUuTNFk,'titles')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('label-success mrg-btm-5 ">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	mm7pzl3HMi0R8fGu = gby0BnUuTNFk
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('var url = "(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]
	else: Tf5ueYGZIFl1hraoEOVKi = url.replace('/vidpage_','/Play/')
	if 'http' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+Tf5ueYGZIFl1hraoEOVKi
	Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi.strip('-')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(ECtBvFXOLM,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'BOKRA-PLAY-2nd')
	N84Yo7V9qS = ccV0NKHwQpMun6FtZvAi.content
	mm7pzl3HMi0R8fGu = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if mm7pzl3HMi0R8fGu:
		mm7pzl3HMi0R8fGu = mm7pzl3HMi0R8fGu[-1]
		if 'http' not in mm7pzl3HMi0R8fGu: mm7pzl3HMi0R8fGu = 'http:'+mm7pzl3HMi0R8fGu
		if '/PLAY/' not in Tf5ueYGZIFl1hraoEOVKi:
			if 'embed.min.js' in mm7pzl3HMi0R8fGu:
				q34qxUX6aRHJbkYvDNcr = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if q34qxUX6aRHJbkYvDNcr:
					T60FdPzC3OYhXKZNn4H, hhN5LwzWU3V = q34qxUX6aRHJbkYvDNcr[0]
					mm7pzl3HMi0R8fGu = mDR9euKnv4jMSdbEpwcktJz5W6Cf(mm7pzl3HMi0R8fGu,'url')+'/v2/'+T60FdPzC3OYhXKZNn4H+'/config/'+hhN5LwzWU3V+'.json'
		import Wlc38MqyKf
		Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb([mm7pzl3HMi0R8fGu],CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/Search/'+search
	Xw3tTz8UD4LK26C(url)
	return