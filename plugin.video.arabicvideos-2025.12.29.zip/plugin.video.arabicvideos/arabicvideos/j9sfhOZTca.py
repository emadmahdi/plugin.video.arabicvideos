# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'EGYBEST4'
JB9fyoHr05QOtPjp = '_EB4_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,kdwXYDMQOjz51Z08W,text):
	if   mode==800: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==801: WjryKiBebavP = Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W)
	elif mode==802: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==803: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==804: WjryKiBebavP = jeDm0qKNk4nVc35(url)
	elif mode==806: WjryKiBebavP = KKUF2Xzv518hY(url,kdwXYDMQOjz51Z08W)
	elif mode==809: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,809,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر',LhFnEIuPHdoNc+'/trending',804,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('nav-categories(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mainContent(.*?)<footer>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801,gby0BnUuTNFk,'mainmenu')
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-menu(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if any(value in title for value in d2gCoAnYPG89O): continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801)
	return jS6fQGXeouTB7xKd32ZMy
def KKUF2Xzv518hY(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-SEASONS_EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mainTitle.*?>(.*?)<(.*?)pageContent',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		QYjhVM3NwTm5l,JsAt0zywiZXQM3YKvnG6ClDq7N8L,items = gby0BnUuTNFk,gby0BnUuTNFk,[]
		for name,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			if 'حلقات' in name: JsAt0zywiZXQM3YKvnG6ClDq7N8L = AxiBv1cQueOs0
			if 'مواسم' in name: QYjhVM3NwTm5l = AxiBv1cQueOs0
		if QYjhVM3NwTm5l and not type:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',QYjhVM3NwTm5l,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if len(items)>1:
				for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,806,T6TRUSbecYGWIq29KF,'season')
		if JsAt0zywiZXQM3YKvnG6ClDq7N8L and len(items)<2:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',JsAt0zywiZXQM3YKvnG6ClDq7N8L,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if items:
				for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
					ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,803,T6TRUSbecYGWIq29KF)
			else:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',JsAt0zywiZXQM3YKvnG6ClDq7N8L,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				for SSqweDUBYv4bkO,title in items:
					ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,803)
	return
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	ZtKQh02YIoDfuFxUXz9,start,mKXQ5VxyYE81ZhAB2bCLduocF,select,PjB71C9rniV = 0,0,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	if 'pagination' in type:
		JvZoN3mt7w9F2eOKyplYf,uWIUplrbFd = url.split('?next=page&')
		IciL6hoO5F1MDSVPjypWZs8kKx = {'Content-Type':'application/x-www-form-urlencoded'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',JvZoN3mt7w9F2eOKyplYf,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		N84Yo7V9qS = 'secContent'+jS6fQGXeouTB7xKd32ZMy+'<footer>'
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		N84Yo7V9qS = jS6fQGXeouTB7xKd32ZMy
	items,Emr2jSpWsh81igTqMfVDlbey67,AiG7kxETBYMw15 = [],False,False
	if not type and '/collections' not in url:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mainContent(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801,gby0BnUuTNFk,'submenu')
				Emr2jSpWsh81igTqMfVDlbey67 = True
	if not Emr2jSpWsh81igTqMfVDlbey67:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('secContent(.*?)mainContent',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
				SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
				T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.strip(okfdjS4RmM)
				title = Y7BxKQdU84R(title)
				if '/series/' in SSqweDUBYv4bkO and type=='season': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,806,T6TRUSbecYGWIq29KF,'season')
				elif '/series/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,806,T6TRUSbecYGWIq29KF)
				elif '/seasons/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801,T6TRUSbecYGWIq29KF,'season')
				elif '/collections' in url: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801,T6TRUSbecYGWIq29KF,'collections')
				else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,803,T6TRUSbecYGWIq29KF)
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('loadMoreParams = (.*?);',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			S9IunMKjOdY0 = TqNUy3Z4SFWvplGwXC82A('dict',AxiBv1cQueOs0)
			PjB71C9rniV = S9IunMKjOdY0['ajaxurl']
			BBOEKWQ1ueVhnrZ3dJxv = int(S9IunMKjOdY0['current_page'])+1
			iSa12tPzucOGWNT8hsHLl5bn = int(S9IunMKjOdY0['max_page'])
			oXI7KLSQwt2Ug4v0Am3R = S9IunMKjOdY0['posts'].replace('False','false').replace('True','true').replace('None','null')
			if BBOEKWQ1ueVhnrZ3dJxv<iSa12tPzucOGWNT8hsHLl5bn:
				uWIUplrbFd = 'action=loadmore&query='+IcChbXakUDFLszgpSG2jqem9(oXI7KLSQwt2Ug4v0Am3R,gby0BnUuTNFk)+'&page='+str(BBOEKWQ1ueVhnrZ3dJxv)
				Tf5ueYGZIFl1hraoEOVKi = PjB71C9rniV+'?next=page&'+uWIUplrbFd
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'جلب المزيد',Tf5ueYGZIFl1hraoEOVKi,801,gby0BnUuTNFk,'pagination_'+type)
		elif '?next=page&' in url:
			uWIUplrbFd,ZmaDvrNx5TAYU3 = uWIUplrbFd.rsplit('=',1)
			ZmaDvrNx5TAYU3 = int(ZmaDvrNx5TAYU3)+1
			Tf5ueYGZIFl1hraoEOVKi = JvZoN3mt7w9F2eOKyplYf+'?next=page&'+uWIUplrbFd+'='+str(ZmaDvrNx5TAYU3)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'جلب المزيد',Tf5ueYGZIFl1hraoEOVKi,801,gby0BnUuTNFk,'pagination_'+type)
	return
def jeDm0qKNk4nVc35(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-FILTERS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sub_nav(.*?)secContent ',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		bXMpofzj7h = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"current_opt">(.*?)<(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for name,AxiBv1cQueOs0 in bXMpofzj7h:
			if 'التصنيف' in name: continue
			name = name.strip(UpN1CezytPO9XoduhxZSD)
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,value in items:
				title = name+':  '+value
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,801,gby0BnUuTNFk,'filter')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYBEST4-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<td>التصنيف</td>.*?">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	ytc3dVjPkMHCSmlzvBuO820Q,LAzpDv0RCZE9yWIk3BXql1HuUjh = [],[]
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('postEmbed.*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0].replace(okfdjS4RmM,gby0BnUuTNFk)
		LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
		TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__embed')
	pyiNVePx0gnCk3WBdUGsmEhQZ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if pyiNVePx0gnCk3WBdUGsmEhQZ:
		PjB71C9rniV,rtdPCiNqKeO = pyiNVePx0gnCk3WBdUGsmEhQZ[0]
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('postPlayer(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			hh8BPgYUy0HAbRf1 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li.*?id\,(.*?)\);">(.*?)</li>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for JRIaLd0bOoZhwYinAfB4HQce3VGK,name in hh8BPgYUy0HAbRf1:
				SSqweDUBYv4bkO = PjB71C9rniV+'/temp/ajax/iframe.php?id='+rtdPCiNqKeO+'&video='+JRIaLd0bOoZhwYinAfB4HQce3VGK
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+name+'__watch')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pageContentDown(.*?)</table>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for DYNVS1Bbgs7,SSqweDUBYv4bkO in items:
			if SSqweDUBYv4bkO not in LAzpDv0RCZE9yWIk3BXql1HuUjh:
				if '/?url=' in SSqweDUBYv4bkO: SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('/?url=')[1]
				LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__download____'+DYNVS1Bbgs7)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if not search: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+apTFWBhb175nwjvKtmJ2
	Xw3tTz8UD4LK26C(url,'search')
	return