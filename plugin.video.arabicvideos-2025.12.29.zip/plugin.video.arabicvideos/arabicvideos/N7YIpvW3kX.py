# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
BZqfNTuc7nKbG1lh = 'FAVORITES'
def CHyR2EGvqzpWZB9cAU4jibkPo(mi63FgbZoVerXaTGNhsUkuR0ILQW,ddk9bj6PuKy):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==270: PgTIFSCwRY3haxjiok = NZihe4G13VvS2WTXY9HLk07A(ddk9bj6PuKy)
	else: PgTIFSCwRY3haxjiok = False
	return PgTIFSCwRY3haxjiok
def qG8C65PDabzS(EyvQhYU4jZoGuwtW7M9JXb,ddk9bj6PuKy,Fo6qVNAWaeg0D91m):
	if not EyvQhYU4jZoGuwtW7M9JXb: return
	if   Fo6qVNAWaeg0D91m=='UP1'	: SRZs8hFId7CK4rExqe2ko0t(ddk9bj6PuKy,True,jxCVeKSLb9rGDOl0Qtw6)
	elif Fo6qVNAWaeg0D91m=='DOWN1'	: SRZs8hFId7CK4rExqe2ko0t(ddk9bj6PuKy,False,jxCVeKSLb9rGDOl0Qtw6)
	elif Fo6qVNAWaeg0D91m=='UP4'	: SRZs8hFId7CK4rExqe2ko0t(ddk9bj6PuKy,True,z5RruqXvsLaTf7e9c)
	elif Fo6qVNAWaeg0D91m=='DOWN4'	: SRZs8hFId7CK4rExqe2ko0t(ddk9bj6PuKy,False,z5RruqXvsLaTf7e9c)
	elif Fo6qVNAWaeg0D91m=='ADD1'	: jinEr2xd7U(ddk9bj6PuKy)
	elif Fo6qVNAWaeg0D91m=='REMOVE1': gLTOcmfrvZ4xzl2F3JbiN(ddk9bj6PuKy)
	elif Fo6qVNAWaeg0D91m=='DELETELIST': cQE1G2u7ktiXNYTqCp9wJhHlmZ5jb(ddk9bj6PuKy)
	return
def NZihe4G13VvS2WTXY9HLk07A(ddk9bj6PuKy):
	jdDnHmaAKhgEBQeoIrq = lhAziv130Woe2GqdyRbHOVrg()
	if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()):
		try:
			EDeqGPfvOb34g = jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]
			if xn867tCVlscY4qbWZfh and ddk9bj6PuKy in ['5','11','12','13']:
				for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD in EDeqGPfvOb34g:
					if ZZrjMgRGiY2IDN7q=='video':
						ygWIQGf25qwVxLkXrYDjp('video',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'تشغيل من الأعلى إلى الأسفل'+GGy0cQe765nPYZ9E8Th,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb)
						ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
						break
			for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD in EDeqGPfvOb34g:
				ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD)
		except:
			jdDnHmaAKhgEBQeoIrq = nLva0Z9oCXSR2bc4WmspwGEO(U24naHzCgdv7wWF)
			EDeqGPfvOb34g = jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]
			for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD in EDeqGPfvOb34g:
				ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD)
	return
def jinEr2xd7U(ddk9bj6PuKy):
	ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD = LLaKvkewEFxtfplOgHJCM(CH4Gk8XMzDVvl)
	if ddk9bj6PuKy in ['5','11','12','13'] and ZZrjMgRGiY2IDN7q!='video':
		tt3DVu1TU8dLAi('','',e1nNXbPrBVDZw,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	UBuy9ezWG6DxniYfpP0Nc = ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,gby0BnUuTNFk,lFYCHgrx5oeBMkD
	jdDnHmaAKhgEBQeoIrq = lhAziv130Woe2GqdyRbHOVrg()
	XfLyTKCVbdNRHzvo = {}
	for lZOxzmdhsgc16ujFCEnA0TePbILN2 in list(jdDnHmaAKhgEBQeoIrq.keys()):
		if lZOxzmdhsgc16ujFCEnA0TePbILN2!=ddk9bj6PuKy: XfLyTKCVbdNRHzvo[lZOxzmdhsgc16ujFCEnA0TePbILN2] = jdDnHmaAKhgEBQeoIrq[lZOxzmdhsgc16ujFCEnA0TePbILN2]
		else:
			if DPkEMfnRe82d and DPkEMfnRe82d!='..':
				k4SDvcr80sVKAGzYXFxfEbwIeH5U = jdDnHmaAKhgEBQeoIrq[lZOxzmdhsgc16ujFCEnA0TePbILN2]
				if UBuy9ezWG6DxniYfpP0Nc in k4SDvcr80sVKAGzYXFxfEbwIeH5U:
					C20tNUdGXEYW8Fb4SPIAyDB6rcOn = k4SDvcr80sVKAGzYXFxfEbwIeH5U.index(UBuy9ezWG6DxniYfpP0Nc)
					del k4SDvcr80sVKAGzYXFxfEbwIeH5U[C20tNUdGXEYW8Fb4SPIAyDB6rcOn]
				QJFZxvdtuqSEyl894 = k4SDvcr80sVKAGzYXFxfEbwIeH5U+[UBuy9ezWG6DxniYfpP0Nc]
				XfLyTKCVbdNRHzvo[lZOxzmdhsgc16ujFCEnA0TePbILN2] = QJFZxvdtuqSEyl894
			else: XfLyTKCVbdNRHzvo[lZOxzmdhsgc16ujFCEnA0TePbILN2] = jdDnHmaAKhgEBQeoIrq[lZOxzmdhsgc16ujFCEnA0TePbILN2]
	if ddk9bj6PuKy not in list(XfLyTKCVbdNRHzvo.keys()): XfLyTKCVbdNRHzvo[ddk9bj6PuKy] = [UBuy9ezWG6DxniYfpP0Nc]
	ntzpIhCBU2s4D0xF = str(XfLyTKCVbdNRHzvo)
	if nqkybtoMBH: ntzpIhCBU2s4D0xF = ntzpIhCBU2s4D0xF.encode(JJQFjSIlALchiMzG9)
	open(U24naHzCgdv7wWF,'wb').write(ntzpIhCBU2s4D0xF)
	return
def gLTOcmfrvZ4xzl2F3JbiN(ddk9bj6PuKy):
	ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD = LLaKvkewEFxtfplOgHJCM(CH4Gk8XMzDVvl)
	UBuy9ezWG6DxniYfpP0Nc = ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,gby0BnUuTNFk,lFYCHgrx5oeBMkD
	jdDnHmaAKhgEBQeoIrq = lhAziv130Woe2GqdyRbHOVrg()
	if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()) and UBuy9ezWG6DxniYfpP0Nc in jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]:
		jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy].remove(UBuy9ezWG6DxniYfpP0Nc)
		if len(jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy])==xn867tCVlscY4qbWZfh: del jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]
		ntzpIhCBU2s4D0xF = str(jdDnHmaAKhgEBQeoIrq)
		if nqkybtoMBH: ntzpIhCBU2s4D0xF = ntzpIhCBU2s4D0xF.encode(JJQFjSIlALchiMzG9)
		open(U24naHzCgdv7wWF,'wb').write(ntzpIhCBU2s4D0xF)
	return
def SRZs8hFId7CK4rExqe2ko0t(ddk9bj6PuKy,GTjclZR8nwXEkb,c1fE5vkRXL):
	ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD = LLaKvkewEFxtfplOgHJCM(CH4Gk8XMzDVvl)
	UBuy9ezWG6DxniYfpP0Nc = ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,gby0BnUuTNFk,lFYCHgrx5oeBMkD
	jdDnHmaAKhgEBQeoIrq = lhAziv130Woe2GqdyRbHOVrg()
	if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()):
		k4SDvcr80sVKAGzYXFxfEbwIeH5U = jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]
		if UBuy9ezWG6DxniYfpP0Nc not in k4SDvcr80sVKAGzYXFxfEbwIeH5U: return
		ZThc7IsAKtk3lXCgj4 = len(k4SDvcr80sVKAGzYXFxfEbwIeH5U)
		for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(xn867tCVlscY4qbWZfh,c1fE5vkRXL):
			hNAFb38vie7p6 = k4SDvcr80sVKAGzYXFxfEbwIeH5U.index(UBuy9ezWG6DxniYfpP0Nc)
			if GTjclZR8nwXEkb: sBfqDVU4FiGbQ5 = hNAFb38vie7p6-jxCVeKSLb9rGDOl0Qtw6
			else: sBfqDVU4FiGbQ5 = hNAFb38vie7p6+jxCVeKSLb9rGDOl0Qtw6
			if sBfqDVU4FiGbQ5>=ZThc7IsAKtk3lXCgj4: sBfqDVU4FiGbQ5 = sBfqDVU4FiGbQ5-ZThc7IsAKtk3lXCgj4
			if sBfqDVU4FiGbQ5<xn867tCVlscY4qbWZfh: sBfqDVU4FiGbQ5 = sBfqDVU4FiGbQ5+ZThc7IsAKtk3lXCgj4
			k4SDvcr80sVKAGzYXFxfEbwIeH5U.insert(sBfqDVU4FiGbQ5, k4SDvcr80sVKAGzYXFxfEbwIeH5U.pop(hNAFb38vie7p6))
		jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy] = k4SDvcr80sVKAGzYXFxfEbwIeH5U
		ntzpIhCBU2s4D0xF = str(jdDnHmaAKhgEBQeoIrq)
		if nqkybtoMBH: ntzpIhCBU2s4D0xF = ntzpIhCBU2s4D0xF.encode(JJQFjSIlALchiMzG9)
		open(U24naHzCgdv7wWF,'wb').write(ntzpIhCBU2s4D0xF)
	return
def na4ZRbz5iukG1rotShvf(ddk9bj6PuKy):
	if ddk9bj6PuKy in ['1','2','3','4']: E9BYCiLHP4ArckX170S5Dz2,W8xcbmjkOnv2GqME9y5FRXwHsU = 'مفضلة',ddk9bj6PuKy
	elif ddk9bj6PuKy in ['5']: E9BYCiLHP4ArckX170S5Dz2,W8xcbmjkOnv2GqME9y5FRXwHsU = 'تشغيل','1'
	elif ddk9bj6PuKy in ['11']: E9BYCiLHP4ArckX170S5Dz2,W8xcbmjkOnv2GqME9y5FRXwHsU = 'تشغيل','2'
	else: E9BYCiLHP4ArckX170S5Dz2,W8xcbmjkOnv2GqME9y5FRXwHsU = gby0BnUuTNFk,gby0BnUuTNFk
	LoFhj8bzxnmYiKINW0Md = E9BYCiLHP4ArckX170S5Dz2+UpN1CezytPO9XoduhxZSD+W8xcbmjkOnv2GqME9y5FRXwHsU
	return LoFhj8bzxnmYiKINW0Md
def cQE1G2u7ktiXNYTqCp9wJhHlmZ5jb(ddk9bj6PuKy):
	LoFhj8bzxnmYiKINW0Md = na4ZRbz5iukG1rotShvf(ddk9bj6PuKy)
	BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هل تريد فعلا مسح جميع محتويات قائمة '+LoFhj8bzxnmYiKINW0Md+' ؟!')
	if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return
	jdDnHmaAKhgEBQeoIrq = lhAziv130Woe2GqdyRbHOVrg()
	if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()):
		del jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]
		ntzpIhCBU2s4D0xF = str(jdDnHmaAKhgEBQeoIrq)
		if nqkybtoMBH: ntzpIhCBU2s4D0xF = ntzpIhCBU2s4D0xF.encode(JJQFjSIlALchiMzG9)
		open(U24naHzCgdv7wWF,'wb').write(ntzpIhCBU2s4D0xF)
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح جميع محتويات قائمة '+LoFhj8bzxnmYiKINW0Md)
	return
def lhAziv130Woe2GqdyRbHOVrg():
	jdDnHmaAKhgEBQeoIrq = {}
	if bCoOHfPdMryRgauz0IVpth.path.exists(U24naHzCgdv7wWF):
		hCbKGcDs83gXn = open(U24naHzCgdv7wWF,'rb').read()
		if nqkybtoMBH: hCbKGcDs83gXn = hCbKGcDs83gXn.decode(JJQFjSIlALchiMzG9)
		jdDnHmaAKhgEBQeoIrq = TqNUy3Z4SFWvplGwXC82A('dict',hCbKGcDs83gXn)
	return jdDnHmaAKhgEBQeoIrq
def KKOQTsX7Ah(jdDnHmaAKhgEBQeoIrq,UBuy9ezWG6DxniYfpP0Nc,jRLg7P0elX):
	ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,bxTDyYw3SV82Pt,LL4W9eHQmsxZ,fbmZ9V58PCTz,EyvQhYU4jZoGuwtW7M9JXb,lFYCHgrx5oeBMkD = UBuy9ezWG6DxniYfpP0Nc
	if not mi63FgbZoVerXaTGNhsUkuR0ILQW: ZZrjMgRGiY2IDN7q,mi63FgbZoVerXaTGNhsUkuR0ILQW = 'folder','260'
	ch67nkSjvGUpCwLRJd,ddk9bj6PuKy = [],gby0BnUuTNFk
	if 'context=' in CH4Gk8XMzDVvl:
		SRGJLIAcaVNFomyeDZbXi4Ut = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('context=(\d+)',CH4Gk8XMzDVvl,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if SRGJLIAcaVNFomyeDZbXi4Ut: ddk9bj6PuKy = str(SRGJLIAcaVNFomyeDZbXi4Ut[xn867tCVlscY4qbWZfh])
	if mi63FgbZoVerXaTGNhsUkuR0ILQW=='270':
		ddk9bj6PuKy = EyvQhYU4jZoGuwtW7M9JXb
		if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()):
			LoFhj8bzxnmYiKINW0Md = na4ZRbz5iukG1rotShvf(ddk9bj6PuKy)
			ch67nkSjvGUpCwLRJd.append(('مسح قائمة '+LoFhj8bzxnmYiKINW0Md,'RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_DELETELIST'+')'))
	else:
		if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()):
			count = len(jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy])
			if count>jxCVeKSLb9rGDOl0Qtw6: ch67nkSjvGUpCwLRJd.append(('تحريك 1 للأعلى','RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_UP1)'))
			if count>z5RruqXvsLaTf7e9c: ch67nkSjvGUpCwLRJd.append(('تحريك 4 للأعلى','RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_UP4)'))
			if count>jxCVeKSLb9rGDOl0Qtw6: ch67nkSjvGUpCwLRJd.append(('تحريك 1 للأسفل','RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_DOWN1)'))
			if count>z5RruqXvsLaTf7e9c: ch67nkSjvGUpCwLRJd.append(('تحريك 4 للأسفل','RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_DOWN4)'))
		for ddk9bj6PuKy in ['1','2','3','4','5','11']:
			LoFhj8bzxnmYiKINW0Md = na4ZRbz5iukG1rotShvf(ddk9bj6PuKy)
			if ddk9bj6PuKy in list(jdDnHmaAKhgEBQeoIrq.keys()) and UBuy9ezWG6DxniYfpP0Nc in jdDnHmaAKhgEBQeoIrq[ddk9bj6PuKy]:
				ch67nkSjvGUpCwLRJd.append(('مسح من '+LoFhj8bzxnmYiKINW0Md,'RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_REMOVE1)'))
			else: ch67nkSjvGUpCwLRJd.append(('إضافة ل'+LoFhj8bzxnmYiKINW0Md,'RunPlugin('+jRLg7P0elX+'&context='+ddk9bj6PuKy+'_ADD1)'))
	UeAlp8IbYT20imt4s = []
	for kZ5Ho3zMR2GQEXa4teBgvyOFq09,BcFVRwAe6TpL9mbiqU in ch67nkSjvGUpCwLRJd:
		kZ5Ho3zMR2GQEXa4teBgvyOFq09 = bKN9diGf8nmgecQPEqUzHRpoDuaO+kZ5Ho3zMR2GQEXa4teBgvyOFq09+GGy0cQe765nPYZ9E8Th
		UeAlp8IbYT20imt4s.append((kZ5Ho3zMR2GQEXa4teBgvyOFq09,BcFVRwAe6TpL9mbiqU,))
	return UeAlp8IbYT20imt4s