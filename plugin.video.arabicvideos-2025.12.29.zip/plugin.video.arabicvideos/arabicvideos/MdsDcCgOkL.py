# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'LIVETV'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS['PYTHON'][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url):
	if   mode==100: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==101: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl('0',True)
	elif mode==102: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl('1',True)
	elif mode==103: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl('2',True)
	elif mode==104: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl('3',True)
	elif mode==105: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==106: WjryKiBebavP = O5XxuEh689Mvoq1Rnesl('4',True)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder','_M3U_'+'قوائم فيديوهات M3U',gby0BnUuTNFk,762)
	ygWIQGf25qwVxLkXrYDjp('folder','_IPT_'+'قوائم فيديوهات IPTV',gby0BnUuTNFk,761)
	ygWIQGf25qwVxLkXrYDjp('folder','_TV0_'+'قنوات من مواقعها الأصلية',gby0BnUuTNFk,101)
	ygWIQGf25qwVxLkXrYDjp('folder','_TV4_'+'قنوات مختارة من يوتيوب',gby0BnUuTNFk,106)
	ygWIQGf25qwVxLkXrYDjp('folder','_YUT_'+'قنوات عربية من يوتيوب',gby0BnUuTNFk,147)
	ygWIQGf25qwVxLkXrYDjp('folder','_YUT_'+'قنوات أجنبية من يوتيوب',gby0BnUuTNFk,148)
	ygWIQGf25qwVxLkXrYDjp('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',gby0BnUuTNFk,28)
	ygWIQGf25qwVxLkXrYDjp('live','_MRF_'+'قناة المعارف من موقعهم',gby0BnUuTNFk,41)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder','_TV1_'+'قنوات تلفزيونية عامة',gby0BnUuTNFk,102)
	ygWIQGf25qwVxLkXrYDjp('folder','_TV2_'+'قنوات تلفزيونية خاصة',gby0BnUuTNFk,103)
	ygWIQGf25qwVxLkXrYDjp('folder','_TV3_'+'قنوات تلفزيونية للفحص',gby0BnUuTNFk,104)
	return
def O5XxuEh689Mvoq1Rnesl(vDOcF6sdlBTWr3,showDialogs=True):
	JB9fyoHr05QOtPjp = '_TV'+vDOcF6sdlBTWr3+'_'
	pjBAh5E2XWYmHx = {'id':gby0BnUuTNFk,'user':wAcHkmPB8a.AV_CLIENT_IDS,'function':'list','menu':vDOcF6sdlBTWr3}
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',LhFnEIuPHdoNc,pjBAh5E2XWYmHx,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LIVETV-ITEMS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		for xuX6UN0WRQbHArDV in range(len(items)):
			name = items[xuX6UN0WRQbHArDV][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[xuX6UN0WRQbHArDV] = items[xuX6UN0WRQbHArDV][0],items[xuX6UN0WRQbHArDV][1],items[xuX6UN0WRQbHArDV][2],name,items[xuX6UN0WRQbHArDV][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for bTh6JaVi1mOoCEeKZ4kS8AWsnl,TfYmiUDcZOCgQ86rENjVG1zaqXbWk,oH4W1v6egkntP8FXIORqj2,name,T6TRUSbecYGWIq29KF in items:
			if '#' in bTh6JaVi1mOoCEeKZ4kS8AWsnl: continue
			if bTh6JaVi1mOoCEeKZ4kS8AWsnl!='URL': name = name+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+AXmnlSGOyNfW7PxEdv+bTh6JaVi1mOoCEeKZ4kS8AWsnl+GGy0cQe765nPYZ9E8Th
			url = bTh6JaVi1mOoCEeKZ4kS8AWsnl+';;'+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+';;'+oH4W1v6egkntP8FXIORqj2+';;'+vDOcF6sdlBTWr3
			ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+gby0BnUuTNFk+name,url,105,T6TRUSbecYGWIq29KF)
	else:
		if showDialogs: ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+'هذه الخدمة مخصصة للمبرمج فقط',gby0BnUuTNFk,9999)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(id):
	bTh6JaVi1mOoCEeKZ4kS8AWsnl,TfYmiUDcZOCgQ86rENjVG1zaqXbWk,oH4W1v6egkntP8FXIORqj2,vDOcF6sdlBTWr3 = id.split(';;')
	url = gby0BnUuTNFk
	if bTh6JaVi1mOoCEeKZ4kS8AWsnl=='URL': url = oH4W1v6egkntP8FXIORqj2
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl=='YOUTUBE':
		url = wAcHkmPB8a.SITESURLS['YOUTUBE'][0]+'/watch?v='+oH4W1v6egkntP8FXIORqj2
		import Wlc38MqyKf
		Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb([url],CC3nOPFMovd72u,'live',url)
		return
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl=='GA':
		pjBAh5E2XWYmHx = { 'id' : gby0BnUuTNFk, 'user' : wAcHkmPB8a.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : gby0BnUuTNFk }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,pjBAh5E2XWYmHx,gby0BnUuTNFk,False,gby0BnUuTNFk,'LIVETV-PLAY-1st')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		cookies = ccV0NKHwQpMun6FtZvAi.cookies
		wpMDBchLPsWxoCNjmkKAF0HG = cookies['ASP.NET_SessionId']
		url = ccV0NKHwQpMun6FtZvAi.headers['Location']
		pjBAh5E2XWYmHx = { 'id' : oH4W1v6egkntP8FXIORqj2 , 'user' : wAcHkmPB8a.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : gby0BnUuTNFk }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+wpMDBchLPsWxoCNjmkKAF0HG }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,pjBAh5E2XWYmHx,headers,gby0BnUuTNFk,gby0BnUuTNFk,'LIVETV-PLAY-2nd')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		url = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('resp":"(http.*?m3u8)(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		SSqweDUBYv4bkO = url[0][0]
		S9IunMKjOdY0 = url[0][1]
		PPBjeZlFMvYVTtx34Hn7W = 'http://38.'+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'777/'+oH4W1v6egkntP8FXIORqj2+'_HD.m3u8'+S9IunMKjOdY0
		C9R2DYvrd3OMjAh1pmaX8Uw0Fg7zi = PPBjeZlFMvYVTtx34Hn7W.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		xIKncWlaEwhB21uFNgf9ZjH = PPBjeZlFMvYVTtx34Hn7W.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		uufJivSZQyj45ql3 = ['HD','SD1','SD2']
		eE9BXgNu4MPKIbw2aLDl1AY3R = [PPBjeZlFMvYVTtx34Hn7W,C9R2DYvrd3OMjAh1pmaX8Uw0Fg7zi,xIKncWlaEwhB21uFNgf9ZjH]
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 0
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1: return
		else: url = eE9BXgNu4MPKIbw2aLDl1AY3R[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		pjBAh5E2XWYmHx = { 'id' : oH4W1v6egkntP8FXIORqj2 , 'user' : wAcHkmPB8a.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : vDOcF6sdlBTWr3 }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST', LhFnEIuPHdoNc, pjBAh5E2XWYmHx, headers, False,gby0BnUuTNFk,'LIVETV-PLAY-3rd')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		url = ccV0NKHwQpMun6FtZvAi.headers['Location']
		url = url.replace('%20',UpN1CezytPO9XoduhxZSD)
		url = url.replace('%3D','=')
		if 'Learn' in oH4W1v6egkntP8FXIORqj2:
			url = url.replace('NTNNile',gby0BnUuTNFk)
			url = url.replace('learning1','Learning')
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl=='PL':
		pjBAh5E2XWYmHx = { 'id' : oH4W1v6egkntP8FXIORqj2 , 'user' : wAcHkmPB8a.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : vDOcF6sdlBTWr3 }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST', LhFnEIuPHdoNc, pjBAh5E2XWYmHx, gby0BnUuTNFk,False,gby0BnUuTNFk,'LIVETV-PLAY-4th')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		url = ccV0NKHwQpMun6FtZvAi.headers['Location']
		headers = {'Referer':ccV0NKHwQpMun6FtZvAi.headers['Referer']}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'POST',url, gby0BnUuTNFk,headers , gby0BnUuTNFk,gby0BnUuTNFk,'LIVETV-PLAY-5th')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('source src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		url = items[0]
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if bTh6JaVi1mOoCEeKZ4kS8AWsnl=='TA': oH4W1v6egkntP8FXIORqj2 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		pjBAh5E2XWYmHx = { 'id' : oH4W1v6egkntP8FXIORqj2 , 'user' : wAcHkmPB8a.AV_CLIENT_IDS , 'function' : 'play'+bTh6JaVi1mOoCEeKZ4kS8AWsnl , 'menu' : vDOcF6sdlBTWr3 }
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',LhFnEIuPHdoNc,pjBAh5E2XWYmHx,headers,gby0BnUuTNFk,gby0BnUuTNFk,'LIVETV-PLAY-6th')
		if not ccV0NKHwQpMun6FtZvAi.succeeded:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		url = ccV0NKHwQpMun6FtZvAi.headers['Location']
		if bTh6JaVi1mOoCEeKZ4kS8AWsnl=='FM':
			ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET', url, gby0BnUuTNFk, gby0BnUuTNFk, False,gby0BnUuTNFk,'LIVETV-PLAY-7th')
			url = ccV0NKHwQpMun6FtZvAi.headers['Location']
			url = url.replace('https','http')
	YAQOL1eVvqMjsEfIFc(url,CC3nOPFMovd72u,'live')
	return