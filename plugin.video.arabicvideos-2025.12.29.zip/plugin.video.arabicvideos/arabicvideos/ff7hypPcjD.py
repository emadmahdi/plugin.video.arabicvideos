# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'TVFUN'
JB9fyoHr05QOtPjp = '_TVF_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['بث مباشر']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==460: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==461: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==462: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==463: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==469: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'TVFUN-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,469,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"menu-btn"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)</span>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in d2gCoAnYPG89O: continue
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,461)
	return
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk):
	items = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'TVFUN-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="head-title"(.*?)id="footer"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		NGcX5a4OifEhZKrY7C0QVyjRA = []
		rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			title = '_MOD_'+title.replace('<br>',UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).strip(UpN1CezytPO9XoduhxZSD)
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO)
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,462,T6TRUSbecYGWIq29KF)
			elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title:
				title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,463,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,463,T6TRUSbecYGWIq29KF)
	if xxGw3Q5hHDkP8WfVe7m!='latest':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip(UpN1CezytPO9XoduhxZSD)
				if SSqweDUBYv4bkO=="": continue
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,461)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'TVFUN-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="head-title"(.*?)id="footer"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
				title = '_MOD_'+title.replace('<br>',UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).strip(UpN1CezytPO9XoduhxZSD)
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,462,T6TRUSbecYGWIq29KF)
		else:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="episode.*?href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,462)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip(UpN1CezytPO9XoduhxZSD)
			if SSqweDUBYv4bkO=="": continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,463)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	Tf5ueYGZIFl1hraoEOVKi = url.replace('/video/','/watch/')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'TVFUN-PLAY-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('VideoServers"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for bUhR5Z3vYKOX8fGg,name in vx14CNdbsZTz:
			bUhR5Z3vYKOX8fGg = bUhR5Z3vYKOX8fGg[2:]
			if cAIRPFK6boejVU549WzqBGCaJ0r: bUhR5Z3vYKOX8fGg = bUhR5Z3vYKOX8fGg.decode(JJQFjSIlALchiMzG9)
			bUhR5Z3vYKOX8fGg = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(bUhR5Z3vYKOX8fGg)
			if nqkybtoMBH: bUhR5Z3vYKOX8fGg = bUhR5Z3vYKOX8fGg.decode(JJQFjSIlALchiMzG9)
			SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)"',bUhR5Z3vYKOX8fGg,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
			if 'http' not in SSqweDUBYv4bkO:
				if '//' in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
				else: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			if SSqweDUBYv4bkO not in eE9BXgNu4MPKIbw2aLDl1AY3R:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+name+'__watch'
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	if UpN1CezytPO9XoduhxZSD in search:
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = LhFnEIuPHdoNc+'/q/'+search+'/'
	Xw3tTz8UD4LK26C(url)
	return