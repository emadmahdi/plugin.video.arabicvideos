# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'FASELHD1'
headers = {'User-Agent':gby0BnUuTNFk}
JB9fyoHr05QOtPjp = '_FH1_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['جوائز الأوسكار','المراجعات','wwe']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==570: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==571: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==572: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==573: WjryKiBebavP = KKUF2Xzv518hY(url,text)
	elif mode==576: WjryKiBebavP = Kg4CL9PwtDnNIbVOkAvBs05()
	elif mode==579: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+'لماذا الموقع بطيء',gby0BnUuTNFk,576)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,url = LhFnEIuPHdoNc,LhFnEIuPHdoNc
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD1-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,579,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'المميزة',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,571,gby0BnUuTNFk,gby0BnUuTNFk,'featured1')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="h3">(.*?)<.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for title,SSqweDUBYv4bkO in items:
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,571,gby0BnUuTNFk,gby0BnUuTNFk,'details1')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"menu-primary"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		mFWJ8ZAsqkK = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li (.*?)</li>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		jNrhlbkCtJ6sMLn4 = [gby0BnUuTNFk,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		t3t986iTduqY = 0
		for vDOcF6sdlBTWr3 in mFWJ8ZAsqkK:
			if t3t986iTduqY>0: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',vDOcF6sdlBTWr3,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=='#': continue
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
				if title==gby0BnUuTNFk: continue
				if any(value in title.lower() for value in d2gCoAnYPG89O): continue
				title = jNrhlbkCtJ6sMLn4[t3t986iTduqY]+title
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,571,gby0BnUuTNFk,gby0BnUuTNFk,'details2')
			t3t986iTduqY += 1
	return
def Kg4CL9PwtDnNIbVOkAvBs05():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD1-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="h4">(.*?)</div>(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not qsQxHTa4e0JYLUSKF7: return
	if type=='filters':
		QKqM0CwXDk8APOoJFpyntRb = [jS6fQGXeouTB7xKd32ZMy.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"homeSlide"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		qacDNJGgIRP4mkQBXWTAFvUnl,vx14CNdbsZTz,K6ucHgjCtqf9wBZxXAUh3Db5EMJW = zip(*items)
		items = zip(vx14CNdbsZTz,qacDNJGgIRP4mkQBXWTAFvUnl,K6ucHgjCtqf9wBZxXAUh3Db5EMJW)
	elif type=='featured2':
		title,AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='details2' and len(qsQxHTa4e0JYLUSKF7)>1:
		title = qsQxHTa4e0JYLUSKF7[0][0]
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,571,gby0BnUuTNFk,gby0BnUuTNFk,'featured2')
		title = qsQxHTa4e0JYLUSKF7[1][0]
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,571,gby0BnUuTNFk,gby0BnUuTNFk,'details3')
		return
	else:
		title,AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[-1]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		if any(value in title.lower() for value in d2gCoAnYPG89O): continue
		T6TRUSbecYGWIq29KF = biVjhGCg0v5eEzkHwTrK9FIAtPU2(T6TRUSbecYGWIq29KF)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.split('?resize=')[0]
		title = Y7BxKQdU84R(title)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '/collections/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,571,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and type==gby0BnUuTNFk:
			title = '_MOD_'+Cso7iV0ZOw2UW5Ez[0][0]
			title = title.strip(' –')
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,573,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif 'episodes/' in SSqweDUBYv4bkO or 'movies/' in SSqweDUBYv4bkO or 'hindi/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,572,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,573,T6TRUSbecYGWIq29KF)
	if type=='filters':
		BBOEKWQ1ueVhnrZ3dJxv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"more_button_page":(.*?),',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if BBOEKWQ1ueVhnrZ3dJxv:
			count = BBOEKWQ1ueVhnrZ3dJxv[0]
			SSqweDUBYv4bkO = url+'/offset/'+count
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة أخرى',SSqweDUBYv4bkO,571,gby0BnUuTNFk,gby0BnUuTNFk,'filters')
	elif 'details' in type:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='pagination(.*?)</div>",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("href='(.*?)'.*?>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = 'صفحة '+Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,571,gby0BnUuTNFk,gby0BnUuTNFk,'details4')
	return
def KKUF2Xzv518hY(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD1-SEASONS_EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QYjhVM3NwTm5l = False
	if not type:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"seasonList"(.*?)"container"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if len(items)>1:
				Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
				QYjhVM3NwTm5l = True
				for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,name,title in items:
					name = Y7BxKQdU84R(name)
					if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
					title = name+' - '+title
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,573,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,'episodes')
	if type=='episodes' or not QYjhVM3NwTm5l:
		gQmur3iRSZ9IAOX = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"posterImg".*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if gQmur3iRSZ9IAOX: T6TRUSbecYGWIq29KF = gQmur3iRSZ9IAOX[0]
		else: T6TRUSbecYGWIq29KF = gby0BnUuTNFk
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"epAll"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				title = Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,572,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q,SCJrDKXILuhW25QUlBV1iT,xqKNBIhz8Wf = [],[],[]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD1-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	cEMC0VKHF64RhfGsSBLnTgYQDwN9lp = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('مستوى المشاهدة.*?">(.*?)</span>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if cEMC0VKHF64RhfGsSBLnTgYQDwN9lp:
		Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"tag">(.*?)</a>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"videoRow"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('&img=')[0]
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=__embed')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="streamHeader(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("href = '(.*?)'.*?</i>(.*?)</a>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('&img=')[0]
			name = name.strip(UpN1CezytPO9XoduhxZSD)
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+name+'__watch')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="downloadLinks(.*?)blackwindow',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</span>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('&img=')[0]
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+name+'__download')
	for NSkqQWjPpEJDHstxrKBb2vFIYnaOX in ytc3dVjPkMHCSmlzvBuO820Q:
		SSqweDUBYv4bkO,name = NSkqQWjPpEJDHstxrKBb2vFIYnaOX.split('?named')
		if SSqweDUBYv4bkO not in SCJrDKXILuhW25QUlBV1iT:
			SCJrDKXILuhW25QUlBV1iT.append(SSqweDUBYv4bkO)
			xqKNBIhz8Wf.append(NSkqQWjPpEJDHstxrKBb2vFIYnaOX)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(xqKNBIhz8Wf,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(Tf5ueYGZIFl1hraoEOVKi,'details5')
	return