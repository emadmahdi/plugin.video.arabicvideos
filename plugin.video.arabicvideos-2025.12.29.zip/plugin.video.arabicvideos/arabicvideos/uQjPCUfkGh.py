# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'AKWAMTUBE'
JB9fyoHr05QOtPjp = '_AKT_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['الرئيسية','يلا شوت','افلام بحسب النوع']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==850: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==851: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==852: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==853: WjryKiBebavP = S2urBMEk9V4v3sjeK(url)
	elif mode==859: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAMTUBE-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,859,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"primary-links"(.*?)</u',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,851)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"list-categories"(.*?)</u',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO.lstrip('/')
			if title in d2gCoAnYPG89O: continue
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,851)
	return
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAMTUBE-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"home-content"(.*?)"footer"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('"overlay"','"duration"><')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		NGcX5a4OifEhZKrY7C0QVyjRA = []
		for T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q,SSqweDUBYv4bkO,title in items:
			title = title.strip(' ')
			title = Y7BxKQdU84R(title)
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if 0 and 'episodes' not in OORugdCwcD9UrzXtT7vML1FWasP and Cso7iV0ZOw2UW5Ez:
				title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
				title = title.replace('اون لاين',gby0BnUuTNFk)
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,853,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,852,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''["']pagination["'](.*?)["']footer["']''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,851,gby0BnUuTNFk,gby0BnUuTNFk,type)
	return
def S2urBMEk9V4v3sjeK(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAMTUBE-SERIES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="eplist"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		JsAt0zywiZXQM3YKvnG6ClDq7N8L = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in JsAt0zywiZXQM3YKvnG6ClDq7N8L:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,872)
	else:
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"category".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if SSqweDUBYv4bkO:
			SSqweDUBYv4bkO = IcChbXakUDFLszgpSG2jqem9(SSqweDUBYv4bkO[0])
			Xw3tTz8UD4LK26C(SSqweDUBYv4bkO,'episodes')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAMTUBE-PLAY-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if 'hash=' in jS6fQGXeouTB7xKd32ZMy:
		I1M8Xen0kap = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('hash=(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		I1M8Xen0kap = list(set(I1M8Xen0kap))
		for y6yAgrGq2LNQYBUzsZcCW0xfPO in I1M8Xen0kap:
			sYcpLozv5StGuDUfaAxE = []
			rO9QBRygx3sqJcH5kZTM1uS74D = y6yAgrGq2LNQYBUzsZcCW0xfPO.split('__')
			for ZZ6otChQWuiUvPTFmlXz2JI in rO9QBRygx3sqJcH5kZTM1uS74D:
				try:
					ZZ6otChQWuiUvPTFmlXz2JI = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(ZZ6otChQWuiUvPTFmlXz2JI+'=')
					if nqkybtoMBH: ZZ6otChQWuiUvPTFmlXz2JI = ZZ6otChQWuiUvPTFmlXz2JI.decode(JJQFjSIlALchiMzG9)
					sYcpLozv5StGuDUfaAxE.append(ZZ6otChQWuiUvPTFmlXz2JI)
				except: pass
			vx14CNdbsZTz = '>'.join(sYcpLozv5StGuDUfaAxE)
			vx14CNdbsZTz = vx14CNdbsZTz.splitlines()
			for SSqweDUBYv4bkO in vx14CNdbsZTz:
				if ' => ' in SSqweDUBYv4bkO:
					title,SSqweDUBYv4bkO = SSqweDUBYv4bkO.split(' => ')
					SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
					ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	elif 'post_id' in jS6fQGXeouTB7xKd32ZMy:
		rtdPCiNqKeO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("post_id = '(.*?)'",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if rtdPCiNqKeO:
			rtdPCiNqKeO = rtdPCiNqKeO[0]
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/wp-admin/admin-ajax.php?action=video_info&post_id='+rtdPCiNqKeO
			ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',SSqweDUBYv4bkO,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ALMSTBA-PLAY-2nd')
			jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
			vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"name":"(.*?)","src":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if not vx14CNdbsZTz: vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(src)":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for name,SSqweDUBYv4bkO in vx14CNdbsZTz:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('\\/','/')
				SSqweDUBYv4bkO = IcChbXakUDFLszgpSG2jqem9(SSqweDUBYv4bkO)
				if name=='src': name = ''
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+name+'__watch')
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return