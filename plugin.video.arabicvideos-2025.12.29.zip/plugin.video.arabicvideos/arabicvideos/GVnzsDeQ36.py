# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
xn867tCVlscY4qbWZfh = Ducd5PRjQXaB9SIN7VrJ1G(u"࠲੟")
jxCVeKSLb9rGDOl0Qtw6 = iiLyoNwGbH03DIXhAkZn(u"࠴੠")
dNx9DVCtafk4r = jxCVeKSLb9rGDOl0Qtw6+jxCVeKSLb9rGDOl0Qtw6
jJ4LEcdl5w7BPMbQ = dNx9DVCtafk4r+jxCVeKSLb9rGDOl0Qtw6
z5RruqXvsLaTf7e9c = jJ4LEcdl5w7BPMbQ+jxCVeKSLb9rGDOl0Qtw6
DVbaycS5iITnPMRsdueXqg1wQx6ltr = z5RruqXvsLaTf7e9c+jxCVeKSLb9rGDOl0Qtw6
gby0BnUuTNFk = MlTVLBZ92kzorIq1Yw(u"ࠩࠪए")
UpN1CezytPO9XoduhxZSD = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࠤࠬऐ")
rBcdwYZInhgO29jtkFAfGxi7 = UpN1CezytPO9XoduhxZSD*dNx9DVCtafk4r
AXmnlSGOyNfW7PxEdv = UpN1CezytPO9XoduhxZSD*jJ4LEcdl5w7BPMbQ
TFAVlh4ONfuyivg = UpN1CezytPO9XoduhxZSD*z5RruqXvsLaTf7e9c
D0DRCGqknfT2tKPY6N = None
w8Ui6RsVhSPrqHfO4 = ne7wF4gSTRZo(u"࡚ࡲࡶࡧ૯")
yrcbRSFswvAfEdIWVj = FAwWlRJg0UkN1(u"ࡆࡢ࡮ࡶࡩ૰")
ygrt5mUZHAdjkfb1 = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡹࡸࡵࡦࠩऑ")
qrejGtHg2Z = FAwWlRJg0UkN1(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
MjwcelItRYVzaPG9QFs1yvSrD74A = iiauUxMktNW5X(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
H14j5s97qxM = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
MMDuRFyAGhOpnq4YmXa9Jc7dNfSx = mmbcsf2pd7gyjzreB(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
bKN9diGf8nmgecQPEqUzHRpoDuaO = ne7wF4gSTRZo(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
hjSQKratoXiExCbUY = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
vjSWtmG2J18kVOi4luaNUoP06C5Ry = nJF7oflOk6cLGSAey(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
KtO5fXzgHnCpvEbs4NwlIQGcxS79 = OUFxZPuXDoGAbRz(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
GGy0cQe765nPYZ9E8Th = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
JJQFjSIlALchiMzG9 = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡶࡶࡩ࠼ࠬछ")
LmIPKScVGEs = MlTVLBZ92kzorIq1Yw(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
jwFLcuExkVa3W72t15GD = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
Z4h3BfbPzS = iiLyoNwGbH03DIXhAkZn(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
lSzTMvWknXwgsyardOVLE9h6uQPt = TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
ssVNKofIc1BDdv7 = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡋࡒࡓࡑࡕࠫठ")
hDXl7UZPovbmC6kQL912Icr30qwBMn = n6JjFHfmydIaLut(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
okfdjS4RmM = iI7tuF0nEQoR(u"ࠧ࡝ࡰࠪढ")
Hd14YjcWpvPhN8sZXK3 = iI7tuF0nEQoR(u"ࠨ࡞ࡵࠫण")
e1nNXbPrBVDZw = KJLkQsqSHMR1Np2(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
O0FZGCuNkqpno8 = n6JjFHfmydIaLut(u"࠵੡")
IVCo8y1lPEMDiHRx3WGZfaT92Y = NupI74tJCzYXmles9SbR6(u"࠵࠴࠵੢")
jrByZEY4DiQN = sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠷࠵੣")
RQNqADGoVZJkOWytpH1C8Yla = Ducd5PRjQXaB9SIN7VrJ1G(u"࠳࠱੤")
OMx74ANuh8sIcby0z = FAwWlRJg0UkN1(u"࠲࠲੥")
qLAyY1EojFVrRvefO7uk = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠳࠵࠴੦")
cQtJGSiEvRdY1r04L3VklZfDFP8 = [
						 nJF7oflOk6cLGSAey(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,TeYukOUW7i5NBM926DCjaAn0(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,FAwWlRJg0UkN1(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,ggtuNcvTn3HQ7SpE2(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,n6JjFHfmydIaLut(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,NupI74tJCzYXmles9SbR6(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,IXE6voNmrb182AyQ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,BarIC3eR9bS(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,FAwWlRJg0UkN1(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,KJLkQsqSHMR1Np2(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,mmbcsf2pd7gyjzreB(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,YZXtBgvUPoM5sb(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
ttxcaynV6eCp = cQtJGSiEvRdY1r04L3VklZfDFP8+[
				 KJLkQsqSHMR1Np2(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,OUFxZPuXDoGAbRz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,ggtuNcvTn3HQ7SpE2(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,VzO1gCHmjZ2ebRIL(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,YZXtBgvUPoM5sb(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,n6JjFHfmydIaLut(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,VzO1gCHmjZ2ebRIL(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,FAwWlRJg0UkN1(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,YZXtBgvUPoM5sb(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
rrJsCLhN4SjQUv7OMBTEgeVPl6 = [
						 sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,OUFxZPuXDoGAbRz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,OUFxZPuXDoGAbRz(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
kkpzPXS6F1ylG3WibMZTjwxR7UQtdH = DVbaycS5iITnPMRsdueXqg1wQx6ltr
XVANElz3tLn5pFPQUWi = [NupI74tJCzYXmles9SbR6(u"ุࠩๅึ࠭े"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪวํ๊ࠧै"),n6JjFHfmydIaLut(u"ࠫะอๆ๋ࠩॉ"),iiauUxMktNW5X(u"ࠬัวๅอࠪॊ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ัศส฼ࠫो"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧฯษ่ืࠬौ"),BarIC3eR9bS(u"ࠨีสำ्ุ࠭"),nJF7oflOk6cLGSAey(u"ࠩึหอ฿ࠧॎ"),FAwWlRJg0UkN1(u"ࠪฯฬ๋ๆࠨॏ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠫฯอำฺࠩॐ"),iiLyoNwGbH03DIXhAkZn(u"ࠬ฿วีำࠪ॑")]
nlXusZEpqHKgaYrV1UP0xT6F = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠹࠴੧")
InYGW7Ad2QRM9rUblmh6 = iiLyoNwGbH03DIXhAkZn(u"࠺࠵੨")*nlXusZEpqHKgaYrV1UP0xT6F
ykiUw6rCdx2074YH8Zcn = iiauUxMktNW5X(u"࠷࠺੩")*InYGW7Ad2QRM9rUblmh6
ppWA8zMwgeXn = q2qPkMFpR1G86dEAKXHivor9N(u"࠹࠰੪")*ykiUw6rCdx2074YH8Zcn
rraWHLSwQvPlVROcM5YAJfF7ojh = xn867tCVlscY4qbWZfh
ECtBvFXOLM = KJLkQsqSHMR1Np2(u"࠳࠱੫")*nlXusZEpqHKgaYrV1UP0xT6F
cjSzHQn9N4BuIZO0xJ = dNx9DVCtafk4r*InYGW7Ad2QRM9rUblmh6
DNh1dgpa4BK = i80mE7lHUwVk(u"࠲࠸੬")*InYGW7Ad2QRM9rUblmh6
Q3J7xTKDuAUoaPlB = jJ4LEcdl5w7BPMbQ*ykiUw6rCdx2074YH8Zcn
oHkZjQME4V1vhcUFtCPJ = KJLkQsqSHMR1Np2(u"࠵࠳੭")*ykiUw6rCdx2074YH8Zcn
Z83rChqtg1oXUjI4YL = MlTVLBZ92kzorIq1Yw(u"࠴࠶੮")*ppWA8zMwgeXn
C4bRXFx2EHdlUQAmBYi8traW1ojp = InYGW7Ad2QRM9rUblmh6
kW2UYMoJPluhvCnFwrK = [q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),FAwWlRJg0UkN1(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),IXE6voNmrb182AyQ(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),YZXtBgvUPoM5sb(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),iiLyoNwGbH03DIXhAkZn(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),YZXtBgvUPoM5sb(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
kW2UYMoJPluhvCnFwrK += [tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
a1DBCs5Tzi6XgIce0lJHAhyv7uKk = [oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),mmbcsf2pd7gyjzreB(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),VzO1gCHmjZ2ebRIL(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),OUFxZPuXDoGAbRz(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),iI7tuF0nEQoR(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),nJF7oflOk6cLGSAey(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
a1DBCs5Tzi6XgIce0lJHAhyv7uKk += [VzO1gCHmjZ2ebRIL(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),iiLyoNwGbH03DIXhAkZn(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),YZXtBgvUPoM5sb(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
QHPMR0ZIKVx = [DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),YZXtBgvUPoM5sb(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡋࡕࡓࡕࡃࠪ६"),iI7tuF0nEQoR(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࡙࠭ࡂࡓࡒࡘࠬ८"),IXE6voNmrb182AyQ(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
QHPMR0ZIKVx += [lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),BarIC3eR9bS(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),nJF7oflOk6cLGSAey(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),MlTVLBZ92kzorIq1Yw(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
QHPMR0ZIKVx += [OUFxZPuXDoGAbRz(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),ne7wF4gSTRZo(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),ggtuNcvTn3HQ7SpE2(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),nJF7oflOk6cLGSAey(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
QHPMR0ZIKVx += [kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),nJF7oflOk6cLGSAey(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),BarIC3eR9bS(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),IXE6voNmrb182AyQ(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),BarIC3eR9bS(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
QHPMR0ZIKVx += [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),FAwWlRJg0UkN1(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),mmbcsf2pd7gyjzreB(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),IXE6voNmrb182AyQ(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),mmbcsf2pd7gyjzreB(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),nJF7oflOk6cLGSAey(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),KJLkQsqSHMR1Np2(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),ggtuNcvTn3HQ7SpE2(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
YAZwqSJVvXDBcOHIspKERLoCxiF7g3 = [ggtuNcvTn3HQ7SpE2(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),iiLyoNwGbH03DIXhAkZn(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),ne7wF4gSTRZo(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
YAZwqSJVvXDBcOHIspKERLoCxiF7g3 += [OUFxZPuXDoGAbRz(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),VzO1gCHmjZ2ebRIL(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),YZXtBgvUPoM5sb(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),IXE6voNmrb182AyQ(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
QQMChIwdeVvs3NbaA8xHpi5P = [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+kW2UYMoJPluhvCnFwrK+[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+a1DBCs5Tzi6XgIce0lJHAhyv7uKk+[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+QHPMR0ZIKVx+[YZXtBgvUPoM5sb(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+YAZwqSJVvXDBcOHIspKERLoCxiF7g3
QUkdxqeMmEfjnzslXN = [TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
GjfPVTL5eENhBR0 = [lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),n6JjFHfmydIaLut(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
xseVAz5fM8XrLdtObR3gBZITkJ6l = [RRbvqditj184m3(u"ࠩࡐ࠷࡚࠭ঢ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡍࡕ࡚ࡖࠨণ"),ne7wF4gSTRZo(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),ne7wF4gSTRZo(u"ࠬࡏࡆࡊࡎࡐࠫথ"),KJLkQsqSHMR1Np2(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
WkJTUusi5rawGyPOBhYfjoV  = [oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),nJF7oflOk6cLGSAey(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),i80mE7lHUwVk(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),n6JjFHfmydIaLut(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
WkJTUusi5rawGyPOBhYfjoV += [tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),IXE6voNmrb182AyQ(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
WkJTUusi5rawGyPOBhYfjoV += [Ducd5PRjQXaB9SIN7VrJ1G(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
WkJTUusi5rawGyPOBhYfjoV += [TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),i80mE7lHUwVk(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),iiauUxMktNW5X(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
WkJTUusi5rawGyPOBhYfjoV += [kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),YZXtBgvUPoM5sb(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
yPG4dib3NHmBeR9I = list(filter(lambda aZGH4TnOcb8FW: aZGH4TnOcb8FW not in WkJTUusi5rawGyPOBhYfjoV+QUkdxqeMmEfjnzslXN+GjfPVTL5eENhBR0+xseVAz5fM8XrLdtObR3gBZITkJ6l,QQMChIwdeVvs3NbaA8xHpi5P))
mVkdN4u5U7fSnF6z8TDI3q = yPG4dib3NHmBeR9I+xseVAz5fM8XrLdtObR3gBZITkJ6l
cWH9rw1MqQ = yPG4dib3NHmBeR9I+WkJTUusi5rawGyPOBhYfjoV
dkrEBbSmqg8QwX13I = cWH9rw1MqQ+QUkdxqeMmEfjnzslXN
C1eYW9FIEvuGlRZki3wrd7Q = mVkdN4u5U7fSnF6z8TDI3q+QUkdxqeMmEfjnzslXN
k3kEj2ilH4gtL96 = [IXE6voNmrb182AyQ(u"ࠩࡄࡏࡔࡇࡍࠨষ"),RRbvqditj184m3(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),iI7tuF0nEQoR(u"ࠫࡎࡌࡉࡍࡏࠪহ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),iI7tuF0nEQoR(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),iiLyoNwGbH03DIXhAkZn(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),i80mE7lHUwVk(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),FAwWlRJg0UkN1(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡒ࠹ࡕࠨী"),n6JjFHfmydIaLut(u"ࠬࡏࡐࡕࡘࠪু"),mmbcsf2pd7gyjzreB(u"࠭ࡂࡐࡍࡕࡅࠬূ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),ne7wF4gSTRZo(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [MlTVLBZ92kzorIq1Yw(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),YZXtBgvUPoM5sb(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡤࡏࡆࡍࡡࠪে"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),BarIC3eR9bS(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),NupI74tJCzYXmles9SbR6(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),NupI74tJCzYXmles9SbR6(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),BarIC3eR9bS(u"ࠫࡤࡓࡕࠨৎ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡥࡉࡑࠩ৏"),BarIC3eR9bS(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),OUFxZPuXDoGAbRz(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),VzO1gCHmjZ2ebRIL(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
N94yFzdQwhu5ML0j6E = [ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),i80mE7lHUwVk(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),ne7wF4gSTRZo(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),MlTVLBZ92kzorIq1Yw(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),ggtuNcvTn3HQ7SpE2(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),mmbcsf2pd7gyjzreB(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
ikSteX168vjcWg = [xn867tCVlscY4qbWZfh,iI7tuF0nEQoR(u"࠵࠺࠶੯"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠶࠼࠰੾"),NupI74tJCzYXmles9SbR6(u"࠲࠹࠳ઁ"),n6JjFHfmydIaLut(u"࠵࠾࠶੶"),OUFxZPuXDoGAbRz(u"࠲࠷࠲੹"),BarIC3eR9bS(u"࠶࠽࠶੽"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠸࠹࠰੷"),i80mE7lHUwVk(u"࠴࠶࠳੺"),FAwWlRJg0UkN1(u"࠹࠷࠰ੰ"),ggtuNcvTn3HQ7SpE2(u"࠵࠱࠲઀"),KJLkQsqSHMR1Np2(u"࠸࠶࠵ੵ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠸࠷࠵੼"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠻࠴࠱੸"),iI7tuF0nEQoR(u"࠽࠶࠱੿"),n6JjFHfmydIaLut(u"࠳࠳࠵࠵ੴ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠺࠻࠼࠴ੳ"),nJF7oflOk6cLGSAey(u"࠷࠰࠳࠲ੱ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠱࠱࠺࠳ੲ"),mmbcsf2pd7gyjzreB(u"࠳࠴࠴࠵੻")]
KvISzcqJxT32p0riDPUlbaE = [uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),YZXtBgvUPoM5sb(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),nJF7oflOk6cLGSAey(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),MlTVLBZ92kzorIq1Yw(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),iI7tuF0nEQoR(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),iiLyoNwGbH03DIXhAkZn(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),ggtuNcvTn3HQ7SpE2(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),iiLyoNwGbH03DIXhAkZn(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬ࠺࠴ࡧ࠶࠳࠼ࡩ࠺ࡡ࠳࡯ࡶ࡬࠶ࡨ࠳ࡣࡦ࠷࠽ࡦ࠼࠴࠹࠳࠺ࡪ࠺ࡶ࠱࠱࠳࠳࠷࡫ࡰࡳ࡯࠶ࡤ࠸࠶࠽ࡦࡤ࠷࠶࠴࠹࠸ࠧ৤"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡢࡣ࠷࠶࠼࠶࠾࠰࠮࠷ࡧ࠵ࡦ࠳࠴ࡤ࠴࠹࠱ࡦࡨ࠶ࡣ࠯࠴࠺ࡧࡨ࠲࠵ࡤ࠹࠽ࡨ࠾ࡡ࠮࠲࠳࠱࠶ࡼ࠵࠺ࡣ࡫࠶࠺ࡷ࠱ࡢ࠸࠳ࠫ৥"),n6JjFHfmydIaLut(u"ࠧࡧ࠻ࡩ࠼࠶࠽࠷࠵࠯ࡤࡦ࠾࠾࠭࠵࠳ࡧ࠶࠲࠾࠷࠱ࡦ࠰࠺࠷࠻ࡢ࠹࠶࠹࠹࠷࠻࠳࠲࠯࠳࠴࠲࠷࡭ࡪࡥ࠷ࡨࡪࡲ࡬ࡨࡥࡥࡶࠬ০")]
OOnM4rmxZK3D2fV = [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶࠫ১"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭২"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨ৩"),MlTVLBZ92kzorIq1Yw(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫ৪"),ggtuNcvTn3HQ7SpE2(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧ৫"),q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰࠩ৬"),NupI74tJCzYXmles9SbR6(u"ࠧࡳࡣࡳ࡭ࡩࡧࡰࡪ࠰ࡦࡳࡲ࠭৭"),NupI74tJCzYXmles9SbR6(u"ࠨࡴࡨࡴࡱ࡯ࡴ࠯ࡦࡨࡺࠬ৮"),OUFxZPuXDoGAbRz(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ৯"),KJLkQsqSHMR1Np2(u"ࠪࡷࡪࡸࡶࡦࡴ࠵࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠭ৰ")]
QXPkA8BsDgRG4 = {
	 iiLyoNwGbH03DIXhAkZn(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠰ࠨৱ")	: xn867tCVlscY4qbWZfh
	,ggtuNcvTn3HQ7SpE2(u"ࠬࡇࡌࡂࡔࡄࡆࠬ৲")		: Ducd5PRjQXaB9SIN7VrJ1G(u"࠳࠳ં")
	,iiauUxMktNW5X(u"࠭ࡉࡇࡋࡏࡑࠬ৳")		: n6JjFHfmydIaLut(u"࠵࠴ઃ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡑࡃࡑࡉ࡙࠭৴")		: n6JjFHfmydIaLut(u"࠷࠵઄")
	,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ৵")		: NupI74tJCzYXmles9SbR6(u"࠹࠶અ")
	,ne7wF4gSTRZo(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ৶")		: n6JjFHfmydIaLut(u"࠻࠰આ")
	,IXE6voNmrb182AyQ(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ৷")		: oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠶࠱ઇ")
	,RRbvqditj184m3(u"ࠫࡆࡑࡏࡂࡏࠪ৸")		: MlTVLBZ92kzorIq1Yw(u"࠸࠲ઈ")
	,nJF7oflOk6cLGSAey(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ৹")		: sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠺࠳ઉ")
	,FAwWlRJg0UkN1(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ৺")		: oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠼࠴ઊ")
	,VzO1gCHmjZ2ebRIL(u"ࠧࡍࡋ࡙ࡉ࡙࡜ࠧ৻")		: nJF7oflOk6cLGSAey(u"࠵࠵࠶ઋ")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪৼ")		: lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠶࠷࠰ઌ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ৽")		: ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠷࠲࠱ઍ")
	,mmbcsf2pd7gyjzreB(u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭৾")	: NupI74tJCzYXmles9SbR6(u"࠱࠴࠲઎")
	,VzO1gCHmjZ2ebRIL(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ৿")		: ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠲࠶࠳એ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠲ࠩ਀")	: NupI74tJCzYXmles9SbR6(u"࠳࠸࠴ઐ")
	,RRbvqditj184m3(u"࠭ࡒࡂࡐࡇࡓࡒ࡙࡟࠱ࠩਁ")	: Ducd5PRjQXaB9SIN7VrJ1G(u"࠴࠺࠵ઑ")
	,IXE6voNmrb182AyQ(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࡡ࠵ࠫਂ")	: sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠵࠼࠶઒")
	,MlTVLBZ92kzorIq1Yw(u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫਃ")	: iI7tuF0nEQoR(u"࠶࠾࠰ઓ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠸࠭਄")	: NupI74tJCzYXmles9SbR6(u"࠷࠹࠱ઔ")
	,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬਅ")		: uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠲࠱࠲ક")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪਆ")	: iiauUxMktNW5X(u"࠳࠳࠳ખ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩਇ")	: ne7wF4gSTRZo(u"࠴࠵࠴ગ")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡉࡑࡖ࡙ࡣ࠵࠭ਈ")		: KJLkQsqSHMR1Np2(u"࠵࠷࠵ઘ")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡂࡍ࡚ࡅࡒ࠭ਉ")		: IXE6voNmrb182AyQ(u"࠶࠹࠶ઙ")
	,VzO1gCHmjZ2ebRIL(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪਊ")		: i80mE7lHUwVk(u"࠷࠻࠰ચ")
	,n6JjFHfmydIaLut(u"ࠩࡐࡉࡓ࡛ࡓࡠ࠲ࠪ਋")		: q2qPkMFpR1G86dEAKXHivor9N(u"࠸࠶࠱છ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡊࡆ࡜ࡏࡓࡋࡗࡉࡘ࠭਌")	: iI7tuF0nEQoR(u"࠲࠸࠲જ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡎࡖࡔࡗࡡ࠴ࠫ਍")		: iiLyoNwGbH03DIXhAkZn(u"࠳࠺࠳ઝ")
	,KJLkQsqSHMR1Np2(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ਎")	: kreQUwJis7YmC2yqWtIF09pgjbD(u"࠴࠼࠴ઞ")
	,FAwWlRJg0UkN1(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧਏ")		: MlTVLBZ92kzorIq1Yw(u"࠶࠴࠵ટ")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪਐ")	: oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠷࠶࠶ઠ")
	,RRbvqditj184m3(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ਑")	: zDSw8LCxMQyraeXhojIWKmU(u"࠸࠸࠰ડ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ਒")		: iiLyoNwGbH03DIXhAkZn(u"࠹࠳࠱ઢ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠺ࠧਓ")	: ne7wF4gSTRZo(u"࠳࠵࠲ણ")
	,MlTVLBZ92kzorIq1Yw(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ਔ")		: FAwWlRJg0UkN1(u"࠴࠷࠳ત")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬਕ")		: ne7wF4gSTRZo(u"࠵࠹࠴થ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡂࡐࡍࡕࡅࠬਖ")		: FAwWlRJg0UkN1(u"࠶࠻࠵દ")
	,YZXtBgvUPoM5sb(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧਗ")		: lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠷࠽࠶ધ")
	,ggtuNcvTn3HQ7SpE2(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫਘ")	: TeYukOUW7i5NBM926DCjaAn0(u"࠸࠿࠰ન")
	,OUFxZPuXDoGAbRz(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࡟࠱ࠩਙ"): ggtuNcvTn3HQ7SpE2(u"࠺࠰࠱઩")
	,mmbcsf2pd7gyjzreB(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࡠ࠳ࠪਚ"): iiauUxMktNW5X(u"࠴࠲࠲પ")
	,iiLyoNwGbH03DIXhAkZn(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫਛ")		: TeYukOUW7i5NBM926DCjaAn0(u"࠵࠴࠳ફ")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬਜ")		: mmbcsf2pd7gyjzreB(u"࠶࠶࠴બ")
	,kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧਝ")		: iI7tuF0nEQoR(u"࠷࠸࠵ભ")
	,iiauUxMktNW5X(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨਞ")		: zDSw8LCxMQyraeXhojIWKmU(u"࠸࠺࠶મ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡖ࡙ࡊ࡚ࡔࠧਟ")		: GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠹࠼࠰ય")
	,mmbcsf2pd7gyjzreB(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬਠ")	: q2qPkMFpR1G86dEAKXHivor9N(u"࠺࠷࠱ર")
	,iI7tuF0nEQoR(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬਡ")		: zDSw8LCxMQyraeXhojIWKmU(u"࠴࠹࠲઱")
	,RRbvqditj184m3(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭ਢ")		: IXE6voNmrb182AyQ(u"࠵࠻࠳લ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠶ࠩਣ")	: iiauUxMktNW5X(u"࠷࠳࠴ળ")
	,nJF7oflOk6cLGSAey(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࡠ࠲ࠪਤ")	: ggtuNcvTn3HQ7SpE2(u"࠸࠵࠵઴")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࡡ࠴ࠫਥ")	: iI7tuF0nEQoR(u"࠹࠷࠶વ")
	,mmbcsf2pd7gyjzreB(u"ࠨࡏࡈࡒ࡚࡙࡟࠲ࠩਦ")		: iI7tuF0nEQoR(u"࠺࠹࠰શ")
	,NupI74tJCzYXmles9SbR6(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨਧ")	: n6JjFHfmydIaLut(u"࠻࠴࠱ષ")
	,n6JjFHfmydIaLut(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬਨ")		: ne7wF4gSTRZo(u"࠵࠶࠲સ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬ਩")		: BarIC3eR9bS(u"࠶࠸࠳હ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧਪ")		: ggtuNcvTn3HQ7SpE2(u"࠷࠺࠴઺")
	,ne7wF4gSTRZo(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪਫ")	: i80mE7lHUwVk(u"࠸࠼࠵઻")
	,VzO1gCHmjZ2ebRIL(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩਬ")		: NupI74tJCzYXmles9SbR6(u"࠹࠾࠶઼")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡈࡒࡗ࡙ࡇࠧਭ")		: ggtuNcvTn3HQ7SpE2(u"࠻࠶࠰ઽ")
	,ne7wF4gSTRZo(u"ࠩࡄࡌ࡜ࡇࡋࠨਮ")		: BarIC3eR9bS(u"࠼࠱࠱ા")
	,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫਯ")		: BarIC3eR9bS(u"࠶࠳࠲િ")
	,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪਰ")	: sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠷࠵࠳ી")
	,MlTVLBZ92kzorIq1Yw(u"࡙ࠬࡈࡐࡈࡋࡅࠬ਱")		: zDSw8LCxMQyraeXhojIWKmU(u"࠸࠷࠴ુ")
	,RRbvqditj184m3(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ਲ")		: n6JjFHfmydIaLut(u"࠹࠹࠵ૂ")
	,ggtuNcvTn3HQ7SpE2(u"࡚ࠧࡃࡔࡓ࡙࠭ਲ਼")		: NupI74tJCzYXmles9SbR6(u"࠺࠻࠶ૃ")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ਴")		: YZXtBgvUPoM5sb(u"࠻࠽࠰ૄ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪਵ")		: RRbvqditj184m3(u"࠼࠸࠱ૅ")
	,ggtuNcvTn3HQ7SpE2(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫਸ਼")		: ne7wF4gSTRZo(u"࠶࠺࠲૆")
	,NupI74tJCzYXmles9SbR6(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ਷")		: TeYukOUW7i5NBM926DCjaAn0(u"࠸࠲࠳ે")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡓ࠳ࡖࡡ࠳ࠫਸ")		: tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠹࠴࠴ૈ")
	,zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡍ࠴ࡗࡢ࠵ࠬਹ")		: tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠺࠶࠵ૉ")
	,OUFxZPuXDoGAbRz(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ਺")	: RRbvqditj184m3(u"࠻࠸࠶૊")
	,i80mE7lHUwVk(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠳ࠫ਻")	: IXE6voNmrb182AyQ(u"࠼࠺࠰ો")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡆࡐࡊࡇࡎࡆࡔࡢ࠵਼ࠬ")	: DWgX6JfF3SnlsQwtN1cvGk8L(u"࠽࠵࠱ૌ")
	,iiLyoNwGbH03DIXhAkZn(u"ࠪࡖࡆࡔࡄࡐࡏࡖࡣ࠶࠭਽")	: ggtuNcvTn3HQ7SpE2(u"࠷࠷࠲્")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ਾ")		: MlTVLBZ92kzorIq1Yw(u"࠸࠹࠳૎")
	,VzO1gCHmjZ2ebRIL(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧਿ")		: mmbcsf2pd7gyjzreB(u"࠹࠻࠴૏")
	,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨੀ")		: uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠺࠽࠵ૐ")
	,iiauUxMktNW5X(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩੁ")		: q2qPkMFpR1G86dEAKXHivor9N(u"࠼࠵࠶૑")
	,ggtuNcvTn3HQ7SpE2(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪੂ")		: ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠽࠷࠰૒")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ੃")		: KJLkQsqSHMR1Np2(u"࠾࠲࠱૓")
	,KJLkQsqSHMR1Np2(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬ੄")		: KJLkQsqSHMR1Np2(u"࠸࠴࠲૔")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭੅")		: oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠹࠶࠳૕")
	,KJLkQsqSHMR1Np2(u"ࠬࡇࡋࡘࡃࡐࡘ࡚ࡈࡅࠨ੆")	: mmbcsf2pd7gyjzreB(u"࠺࠸࠴૖")
	,YZXtBgvUPoM5sb(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧੇ")		: ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠻࠺࠵૗")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡗࡃࡕࡆࡔࡔࠧੈ")		: VzO1gCHmjZ2ebRIL(u"࠼࠼࠶૘")
	,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨ੉")		: GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠽࠾࠰૙")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭੊")	: iI7tuF0nEQoR(u"࠾࠹࠱૚")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨੋ")	: GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠹࠱࠲૛")
	,FAwWlRJg0UkN1(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ੌ")		: IXE6voNmrb182AyQ(u"࠺࠳࠳૜")
	,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡑࡉࡓࡏࡄࡐࡐ੍࠭")		: OUFxZPuXDoGAbRz(u"࠻࠵࠴૝")
	,nJF7oflOk6cLGSAey(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩ੎")	: GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠼࠷࠵૞")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧ੏")		: DWgX6JfF3SnlsQwtN1cvGk8L(u"࠽࠹࠶૟")
	,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡓࡉࡍࡑࡓࠧ੐")		: mmbcsf2pd7gyjzreB(u"࠾࠻࠰ૠ")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬੑ")	: IXE6voNmrb182AyQ(u"࠿࠶࠱ૡ")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ੒")		: Ducd5PRjQXaB9SIN7VrJ1G(u"࠹࠸࠲ૢ")
	,RRbvqditj184m3(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭੓")		: tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠺࠺࠳ૣ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭੔")		: GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠻࠼࠴૤")
	,uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧ੕")		: Ducd5PRjQXaB9SIN7VrJ1G(u"࠴࠴࠵࠶૥")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡈࡑࡒࡋࡑࡋࡓࡆࡃࡕࡇࡍ࠭੖")	: tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠵࠵࠷࠰૦")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠺ࠬ੗")	: tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠶࠶࠲࠱૧")
	,OUFxZPuXDoGAbRz(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭੘")	: YZXtBgvUPoM5sb(u"࠷࠰࠴࠲૨")
	,iiauUxMktNW5X(u"ࠪࡑࡆ࡙ࡁࡗࡋࡇࡉࡔ࠭ਖ਼")	: mmbcsf2pd7gyjzreB(u"࠱࠱࠶࠳૩")
	,mmbcsf2pd7gyjzreB(u"ࠫࡆ࡟ࡌࡐࡎࠪਗ਼")		: uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠲࠲࠸࠴૪")
	,nJF7oflOk6cLGSAey(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨਜ਼")	: BarIC3eR9bS(u"࠳࠳࠺࠵૫")
	,mmbcsf2pd7gyjzreB(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧੜ")		: ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠴࠴࠼࠶૬")
	,n6JjFHfmydIaLut(u"ࠧࡄࡎࡈࡅࡓࡋࡒࡠ࠴ࠪ੝")	: ne7wF4gSTRZo(u"࠵࠵࠾࠰૭")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠵ࠫਫ਼")	: KJLkQsqSHMR1Np2(u"࠶࠶࠹࠱૮")
}