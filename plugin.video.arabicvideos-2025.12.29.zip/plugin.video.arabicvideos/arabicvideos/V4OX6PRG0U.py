# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from IER9OUbYLX import *
from dhyPruobnI import *
import base64 as dY1hxU8QXz7vD2Cj5ZtlJg64
CC3nOPFMovd72u = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡌࡊࡄࡖࡘ࡜ࡕࠧၵ")
if nqkybtoMBH:
	ddvbjM1HF8X = p1GKFMthlSdiUNvPc5WVqn.translatePath(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨၶ"))
	V8AUXlPnuQ1OZTc5rkRBw = p1GKFMthlSdiUNvPc5WVqn.translatePath(nJF7oflOk6cLGSAey(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬၷ"))
	OOcgTBrf9EC32tlhwQPa = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,n6JjFHfmydIaLut(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫၸ"),YZXtBgvUPoM5sb(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬၹ"),nJF7oflOk6cLGSAey(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩၺ"))
	NJiphKOoz4lm2 = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧၻ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨၼ"),OUFxZPuXDoGAbRz(u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧၽ"))
	fANHCcB7ysluYd4Z0iTF1e = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,VzO1gCHmjZ2ebRIL(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪၾ"),IXE6voNmrb182AyQ(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫၿ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪႀ"))
	from urllib.parse import quote as _0sL2twdoICPy7q
else:
	ddvbjM1HF8X = oKew16fsvuV8.translatePath(VzO1gCHmjZ2ebRIL(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬႁ"))
	V8AUXlPnuQ1OZTc5rkRBw = oKew16fsvuV8.translatePath(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩႂ"))
	OOcgTBrf9EC32tlhwQPa = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,OUFxZPuXDoGAbRz(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨႃ"),OUFxZPuXDoGAbRz(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩႄ"),iiLyoNwGbH03DIXhAkZn(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭ႅ"))
	NJiphKOoz4lm2 = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫႆ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬႇ"),KJLkQsqSHMR1Np2(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫႈ"))
	fANHCcB7ysluYd4Z0iTF1e = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,nJF7oflOk6cLGSAey(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧႉ"),Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨႊ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧႋ"))
	from urllib import quote as _0sL2twdoICPy7q
gO3wqNsBZFrc2Epi1T0ALDb6WUK5 = bCoOHfPdMryRgauz0IVpth.path.join(V8AUXlPnuQ1OZTc5rkRBw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪႌ"))
G30FNgWuTRO5jlCMoiKBIPnf = bCoOHfPdMryRgauz0IVpth.path.join(V8AUXlPnuQ1OZTc5rkRBw,iiLyoNwGbH03DIXhAkZn(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨႍ"))
bGZat8TIQDBiAwWYOn = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,OUFxZPuXDoGAbRz(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬႎ"))
I0oFsWqUfGcDdlx = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,iiauUxMktNW5X(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ႏ"))
LLIhz0iVEgQeN = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ႐"))
U24naHzCgdv7wWF = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ႑"))
uczY4EiMm1 = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,iiauUxMktNW5X(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ႒"))
dxb4sYrRAG = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,mmbcsf2pd7gyjzreB(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ႓"))
tgWGmIC7nAMBpZE3TON = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,BarIC3eR9bS(u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ႔"))
UxnJGVkCd7 = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,n6JjFHfmydIaLut(u"ࠪࡸ࡭ࡻ࡭ࡣ࠰ࡳࡲ࡬࠭႕"))
KJdezaFnjf = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲ࡵࡴࡧࠨ႖"))
VUEApCTylna65cR = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡨࡡ࡯ࡰࡨࡶ࠳ࡶ࡮ࡨࠩ႗"))
C2yaV7kKeNWZPvcjXRpE694lsT5Jq = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦ࠰ࡳࡲ࡬࠭႘"))
LtilSro4UYPJbARDxj2Wv5hne = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,n6JjFHfmydIaLut(u"ࠧࡱࡱࡶࡸࡪࡸ࠮ࡱࡰࡪࠫ႙"))
pJk07dFn2hX6YGS4eIclV8fDsUEw1L = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲ࠲ࡵࡴࡧࠨႚ"))
KDQNFgIbv4BHtWXJj = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,OUFxZPuXDoGAbRz(u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷ࠲ࡵࡴࡧࠨႛ"))
gDcYwjhCOs4ltaKqWFnoB = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,mmbcsf2pd7gyjzreB(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪႜ"))
J2J0PpyrD4IMnwadv6YThZeBuqQ5sR = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡦࡪࡤࡰࡰࡶࠫႝ"))
S69fH8RGlAuk2Pe = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,iiauUxMktNW5X(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ႞"),VzO1gCHmjZ2ebRIL(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ႟"),Ym0kMIiBp4dFarGHxs6Svle)
B5BloRSAtILFqCTdO = bCoOHfPdMryRgauz0IVpth.path.join(S69fH8RGlAuk2Pe,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭Ⴀ"))
JJ4XyiucvbwgdQZoMzaTYD6tESkI = set(wAcHkmPB8a.BADWEBSITES)
dkrEBbSmqg8QwX13I = [BoRk2n4aEtT3cKL08HPhUO for BoRk2n4aEtT3cKL08HPhUO in dkrEBbSmqg8QwX13I if BoRk2n4aEtT3cKL08HPhUO not in JJ4XyiucvbwgdQZoMzaTYD6tESkI]
cWH9rw1MqQ = [BoRk2n4aEtT3cKL08HPhUO for BoRk2n4aEtT3cKL08HPhUO in cWH9rw1MqQ if BoRk2n4aEtT3cKL08HPhUO not in JJ4XyiucvbwgdQZoMzaTYD6tESkI]
QQMChIwdeVvs3NbaA8xHpi5P = [BoRk2n4aEtT3cKL08HPhUO for BoRk2n4aEtT3cKL08HPhUO in QQMChIwdeVvs3NbaA8xHpi5P if BoRk2n4aEtT3cKL08HPhUO not in JJ4XyiucvbwgdQZoMzaTYD6tESkI]
mVkdN4u5U7fSnF6z8TDI3q = [BoRk2n4aEtT3cKL08HPhUO for BoRk2n4aEtT3cKL08HPhUO in mVkdN4u5U7fSnF6z8TDI3q if BoRk2n4aEtT3cKL08HPhUO not in JJ4XyiucvbwgdQZoMzaTYD6tESkI]
C1eYW9FIEvuGlRZki3wrd7Q = [BoRk2n4aEtT3cKL08HPhUO for BoRk2n4aEtT3cKL08HPhUO in C1eYW9FIEvuGlRZki3wrd7Q if BoRk2n4aEtT3cKL08HPhUO not in JJ4XyiucvbwgdQZoMzaTYD6tESkI]
class N3fAtRaD2wzZ7quOsHU0VMK1SbXeLc():
	def __init__(K2KAIOMzoptehNkf,showDialogs=yrcbRSFswvAfEdIWVj,logErrors=w8Ui6RsVhSPrqHfO4):
		K2KAIOMzoptehNkf.showDialogs = showDialogs
		K2KAIOMzoptehNkf.logErrors = logErrors
		K2KAIOMzoptehNkf.finishedLIST,K2KAIOMzoptehNkf.failedLIST = [],[]
		K2KAIOMzoptehNkf.statusDICT,K2KAIOMzoptehNkf.resultsDICT = {},{}
		K2KAIOMzoptehNkf.processesLIST = []
		K2KAIOMzoptehNkf.starttimeDICT,K2KAIOMzoptehNkf.finishtimeDICT,K2KAIOMzoptehNkf.elpasedtimeDICT = {},{},{}
	def SPCcrbm56KYaRNuTnzwgl8VtLd(K2KAIOMzoptehNkf,JJ4wRxzq6WNrabTVlSyE,DCkeJxfrmnobTVHhWjs96OwU,*aargs):
		JJ4wRxzq6WNrabTVlSyE = str(JJ4wRxzq6WNrabTVlSyE)
		K2KAIOMzoptehNkf.statusDICT[JJ4wRxzq6WNrabTVlSyE] = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩႡ")
		if K2KAIOMzoptehNkf.showDialogs: RLfOB3nsqaWXTugJvY(gby0BnUuTNFk,JJ4wRxzq6WNrabTVlSyE)
		Q9cbjuO24JTZVd3 = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=K2KAIOMzoptehNkf.bboPFxU6aQhRzn7HumYMgJTsON32Zr,args=(JJ4wRxzq6WNrabTVlSyE,DCkeJxfrmnobTVHhWjs96OwU,aargs))
		K2KAIOMzoptehNkf.processesLIST.append(Q9cbjuO24JTZVd3)
		return Q9cbjuO24JTZVd3
	def C69BPkYpSoW5JnUOsVGFm4bh(K2KAIOMzoptehNkf,JJ4wRxzq6WNrabTVlSyE,DCkeJxfrmnobTVHhWjs96OwU,*aargs):
		Q9cbjuO24JTZVd3 = K2KAIOMzoptehNkf.SPCcrbm56KYaRNuTnzwgl8VtLd(JJ4wRxzq6WNrabTVlSyE,DCkeJxfrmnobTVHhWjs96OwU,*aargs)
		Q9cbjuO24JTZVd3.start()
	def bboPFxU6aQhRzn7HumYMgJTsON32Zr(K2KAIOMzoptehNkf,JJ4wRxzq6WNrabTVlSyE,DCkeJxfrmnobTVHhWjs96OwU,aargs):
		JJ4wRxzq6WNrabTVlSyE = str(JJ4wRxzq6WNrabTVlSyE)
		K2KAIOMzoptehNkf.starttimeDICT[JJ4wRxzq6WNrabTVlSyE] = RyfYSek61do5OnQMc.time()
		try:
			K2KAIOMzoptehNkf.resultsDICT[JJ4wRxzq6WNrabTVlSyE] = DCkeJxfrmnobTVHhWjs96OwU(*aargs)
			if n6JjFHfmydIaLut(u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪႢ") in str(DCkeJxfrmnobTVHhWjs96OwU) and not K2KAIOMzoptehNkf.resultsDICT[JJ4wRxzq6WNrabTVlSyE].succeeded: cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
			K2KAIOMzoptehNkf.finishedLIST.append(JJ4wRxzq6WNrabTVlSyE)
			K2KAIOMzoptehNkf.statusDICT[JJ4wRxzq6WNrabTVlSyE] = ne7wF4gSTRZo(u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬႣ")
		except Exception as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			if K2KAIOMzoptehNkf.logErrors:
				fSqpV0sUvcr153IYbT9lKezQRE7 = WhjmDeqacBg.format_exc()
				if fSqpV0sUvcr153IYbT9lKezQRE7!=RRbvqditj184m3(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧႤ"): Pt41K3suxDF9nE0wLvU7dGq2ceNT.stderr.write(fSqpV0sUvcr153IYbT9lKezQRE7)
			K2KAIOMzoptehNkf.failedLIST.append(JJ4wRxzq6WNrabTVlSyE)
			K2KAIOMzoptehNkf.statusDICT[JJ4wRxzq6WNrabTVlSyE] = BarIC3eR9bS(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬႥ")
		K2KAIOMzoptehNkf.finishtimeDICT[JJ4wRxzq6WNrabTVlSyE] = RyfYSek61do5OnQMc.time()
		K2KAIOMzoptehNkf.elpasedtimeDICT[JJ4wRxzq6WNrabTVlSyE] = K2KAIOMzoptehNkf.finishtimeDICT[JJ4wRxzq6WNrabTVlSyE] - K2KAIOMzoptehNkf.starttimeDICT[JJ4wRxzq6WNrabTVlSyE]
	def b62Lvx73wIFjlMECeGXOHmpnSU9Zt(K2KAIOMzoptehNkf):
		for H3mocdwUKO1abWY2pENCJIySg in K2KAIOMzoptehNkf.processesLIST:
			H3mocdwUKO1abWY2pENCJIySg.start()
	def MM10NzFscuQVlLBwIK9(K2KAIOMzoptehNkf):
		while IXE6voNmrb182AyQ(u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧႦ") in list(K2KAIOMzoptehNkf.statusDICT.values()): RyfYSek61do5OnQMc.sleep(i80mE7lHUwVk(u"࠷ᛩ"))
def uyh1JOGNzTpLPd8IFq():
	if not jxBbwd2W6Xk: return GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪႧ")
	NJmC68DgXQsj = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭Ⴈ")
	orSiwcklYPVqb6NLJQg0xA1G = [Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ࠻࠲࠺࠴࠰ࠨႩ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠪ࠶࠵࠸࠱࠯࠳࠳࠲࠶࠿ࠧႪ"),MlTVLBZ92kzorIq1Yw(u"ࠫ࠷࠶࠲࠲࠰࠴࠵࠳࠸࠴ࡢࠩႫ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬ࠸࠰࠳࠳࠱࠵࠷࠴࠳࠱ࠩႬ"),ne7wF4gSTRZo(u"࠭࠲࠱࠴࠵࠲࠵࠸࠮࠱࠴ࠪႭ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧ࠳࠲࠵࠶࠳࠷࠰࠯࠴࠵ࠫႮ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨ࠴࠳࠶࠸࠴࠰࠴࠰࠳࠺ࠬႯ"),n6JjFHfmydIaLut(u"ࠩ࠵࠴࠷࠹࠮࠱࠷࠱࠵࠻࠭Ⴐ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪ࠶࠵࠸࠳࠯࠲࠹࠲࠵࠼ࠧႱ"),iiauUxMktNW5X(u"ࠫ࠷࠶࠲࠴࠰࠴࠴࠳࠸࠸ࠨႲ"),mmbcsf2pd7gyjzreB(u"ࠬ࠸࠰࠳࠶࠱࠴࠶࠴࠱࠵ࠩႳ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭࠲࠱࠴࠷࠲࠵࠽࠮࠳࠲ࠪႴ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠧ࠳࠲࠵࠹࠳࠶࠵࠯࠲࠸ࠫႵ"),iI7tuF0nEQoR(u"ࠨ࠴࠳࠶࠺࠴࠱࠲࠰࠶࠴ࠬႶ")]
	gTZu78I0DqXHp4NYal = orSiwcklYPVqb6NLJQg0xA1G[-jxCVeKSLb9rGDOl0Qtw6]
	KcxSuNvdElXoH = NNLyWfbPqkGF5jBxp46oJ(gTZu78I0DqXHp4NYal)
	kIByqV0NwLxa9H = NNLyWfbPqkGF5jBxp46oJ(eQNGiXdboqPt57O)
	if kIByqV0NwLxa9H>KcxSuNvdElXoH:
		NJmC68DgXQsj = ggtuNcvTn3HQ7SpE2(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩႷ")
	return NJmC68DgXQsj
def Ci4do9lZhuSczJ(EyaNdiZUtzq2rMulW9JL1ITHP3fgC):
	svJ3rSD2dC8ebV60wihUpOaZ5YP,z4zyWg1CZSHixkr = gby0BnUuTNFk,yrcbRSFswvAfEdIWVj
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC: svJ3rSD2dC8ebV60wihUpOaZ5YP = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,VzO1gCHmjZ2ebRIL(u"ࠪࡷࡹࡸࠧႸ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩႹ"),iiauUxMktNW5X(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧႺ"))
	if not svJ3rSD2dC8ebV60wihUpOaZ5YP:
		KKFPNRzufO = wAcHkmPB8a.SITESURLS[KJLkQsqSHMR1Np2(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭Ⴛ")][mmbcsf2pd7gyjzreB(u"࠹ᛪ")]
		DI1M026yiGjnZXhTc58 = {DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡶࡵࡨࡶࠬႼ"):wAcHkmPB8a.AV_CLIENT_IDS,ggtuNcvTn3HQ7SpE2(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩႽ"):eQNGiXdboqPt57O}
		svJ3rSD2dC8ebV60wihUpOaZ5YP = mma7hVpzo3Mfc5SO(n6JjFHfmydIaLut(u"ࠩࡓࡓࡘ࡚ࠧႾ"),KKFPNRzufO,DI1M026yiGjnZXhTc58,gby0BnUuTNFk,FAwWlRJg0UkN1(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡢࡔ࡞࡚ࡈࡐࡐࡢࡇࡔࡊࡅ࠮࠳ࡶࡸࠬႿ"))
		XTWNueqE1H(wAcHkmPB8a.api_python_actions[YZXtBgvUPoM5sb(u"࠺᛫")])
		if svJ3rSD2dC8ebV60wihUpOaZ5YP: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,iiauUxMktNW5X(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩჀ"),iiLyoNwGbH03DIXhAkZn(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧჁ"),svJ3rSD2dC8ebV60wihUpOaZ5YP,Z83rChqtg1oXUjI4YL)
		z4zyWg1CZSHixkr = w8Ui6RsVhSPrqHfO4
	if svJ3rSD2dC8ebV60wihUpOaZ5YP:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,hhzJGjrNKpA8cHqY9
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,hhzJGjrNKpA8cHqY9 = {},[],{},[],{}
		exec(svJ3rSD2dC8ebV60wihUpOaZ5YP,globals(),locals())
		wAcHkmPB8a.SITESURLS.update(NEW_SITESURLS)
		wAcHkmPB8a.WEBCACHEDATA.update(hhzJGjrNKpA8cHqY9)
		wAcHkmPB8a.BADSCRAPERS = list(set(wAcHkmPB8a.BADSCRAPERS+NEW_BADSCRAPERS))
		wAcHkmPB8a.BADCOMMONIDS = list(set(wAcHkmPB8a.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if eQNGiXdboqPt57O in list(NEW_BADWEBSITES.keys()): wAcHkmPB8a.BADWEBSITES += NEW_BADWEBSITES[eQNGiXdboqPt57O]
	return z4zyWg1CZSHixkr
def dXjNapb70Y():
	try: bCoOHfPdMryRgauz0IVpth.makedirs(jjzt6rqdQKM)
	except: pass
	HCEfmJdK8Gi = uyh1JOGNzTpLPd8IFq()
	if HCEfmJdK8Gi==NupI74tJCzYXmles9SbR6(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭Ⴢ"): SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧ࠯࡞ࡷࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭Ⴣ")+CH4Gk8XMzDVvl+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࠢࡠࠫჄ"))
	else: SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,YZXtBgvUPoM5sb(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭Ⴥ")+CH4Gk8XMzDVvl+VzO1gCHmjZ2ebRIL(u"ࠪࠤࡢ࠭჆"))
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫჇ")+eQNGiXdboqPt57O)
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ჈"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,FAwWlRJg0UkN1(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫ჉"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠶ࠬ჊"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,VzO1gCHmjZ2ebRIL(u"ࠨࡄࡏࡓࡈࡑࡅࡅࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖࠫ჋"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,iI7tuF0nEQoR(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ჌"),n6JjFHfmydIaLut(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨჍ"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,IXE6voNmrb182AyQ(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ჎"),OUFxZPuXDoGAbRz(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪ჏"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,MlTVLBZ92kzorIq1Yw(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩა"),MlTVLBZ92kzorIq1Yw(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭ბ"))
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨგ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(RRbvqditj184m3(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫდ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ე"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ggtuNcvTn3HQ7SpE2(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧვ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨზ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨთ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(VzO1gCHmjZ2ebRIL(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬი"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨკ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ლ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(IXE6voNmrb182AyQ(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫმ"),gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ნ"),gby0BnUuTNFk)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,n6JjFHfmydIaLut(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ო"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭პ"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ჟ"))
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,OUFxZPuXDoGAbRz(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪრ"))
	Cjio8VzFbEgRfTNH3UrDJMZ(yrcbRSFswvAfEdIWVj)
	cfby3Jj71rT6IwB05V(rraWHLSwQvPlVROcM5YAJfF7ojh)
	import BktdqIvga8
	BktdqIvga8.IRMxnQpdEFikJw6L7y0(iI7tuF0nEQoR(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩს"),yrcbRSFswvAfEdIWVj)
	BktdqIvga8.IRMxnQpdEFikJw6L7y0(TeYukOUW7i5NBM926DCjaAn0(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ტ"),yrcbRSFswvAfEdIWVj)
	BktdqIvga8.IRMxnQpdEFikJw6L7y0(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡩࡪࡲࡶࡥࡨࡦ࡬ࡶࡪࡩࡴࠨუ"),yrcbRSFswvAfEdIWVj)
	BktdqIvga8.TAFLUzpWg63Rf(w8Ui6RsVhSPrqHfO4)
	BktdqIvga8.TXUl3chADy(yrcbRSFswvAfEdIWVj)
	if HCEfmJdK8Gi==VzO1gCHmjZ2ebRIL(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬფ"):
		FdPerk1Bcfxo4Hi63tLg8(w8Ui6RsVhSPrqHfO4,[la983tXRDchGbrdIFQJf7kHeE])
	else:
		FdPerk1Bcfxo4Hi63tLg8(yrcbRSFswvAfEdIWVj,[])
		BktdqIvga8.aH3DdLgITVhzb7pik04xyJM()
		try:
			BcHx2Z06JVbuRsfCFgLh = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,iI7tuF0nEQoR(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨქ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫღ"),OUFxZPuXDoGAbRz(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬყ"),ggtuNcvTn3HQ7SpE2(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨშ"))
			k2F8uBSfpNa4jD0drAMwLXREvV = N2hY40LMzH8ZKfTeo5wkpnDRyC.Addon(id=i80mE7lHUwVk(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧჩ"))
			k2F8uBSfpNa4jD0drAMwLXREvV.setSetting(nJF7oflOk6cLGSAey(u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪც"),iiLyoNwGbH03DIXhAkZn(u"ࠬࡌࡡ࡭ࡵࡨࠫძ"))
		except: pass
		try:
			BcHx2Z06JVbuRsfCFgLh = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,MlTVLBZ92kzorIq1Yw(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨწ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫჭ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨხ"),iiauUxMktNW5X(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨჯ"))
			k2F8uBSfpNa4jD0drAMwLXREvV = N2hY40LMzH8ZKfTeo5wkpnDRyC.Addon(id=lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪჰ"))
			k2F8uBSfpNa4jD0drAMwLXREvV.setSetting(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧჱ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬ࠹ࠧჲ"))
		except: pass
		try:
			BcHx2Z06JVbuRsfCFgLh = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,VzO1gCHmjZ2ebRIL(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨჳ"),IXE6voNmrb182AyQ(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫჴ"),IXE6voNmrb182AyQ(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨჵ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨჶ"))
			k2F8uBSfpNa4jD0drAMwLXREvV = N2hY40LMzH8ZKfTeo5wkpnDRyC.Addon(id=Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪჷ"))
			k2F8uBSfpNa4jD0drAMwLXREvV.setSetting(ggtuNcvTn3HQ7SpE2(u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩჸ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠬ࠸ࠧჹ"))
		except: pass
	jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = nLva0Z9oCXSR2bc4WmspwGEO(sTZKJYrgqmkxtvpP)
	jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = nLva0Z9oCXSR2bc4WmspwGEO(U24naHzCgdv7wWF)
	BktdqIvga8.pIahvX6fULC4gm8qoPnJ9VMyEclW(yrcbRSFswvAfEdIWVj)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(iI7tuF0nEQoR(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪჺ"),eQNGiXdboqPt57O)
	nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def F9i5MbESDeT6l4A(LxWiszo6Gm0J9RvuMNn):
	z4zyWg1CZSHixkr = Ci4do9lZhuSczJ(w8Ui6RsVhSPrqHfO4)
	if z4zyWg1CZSHixkr:
		return
	Dl5Idi7EMwNy1OfoR4F = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(MlTVLBZ92kzorIq1Yw(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬ჻")))
	Dl5Idi7EMwNy1OfoR4F = xn867tCVlscY4qbWZfh if not Dl5Idi7EMwNy1OfoR4F else int(Dl5Idi7EMwNy1OfoR4F)
	if not Dl5Idi7EMwNy1OfoR4F or not xn867tCVlscY4qbWZfh<=X1X59MWmb8oBPDFCJARwcjONihTdeZ-Dl5Idi7EMwNy1OfoR4F<=cjSzHQn9N4BuIZO0xJ:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭ჼ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
		cfby3Jj71rT6IwB05V(rraWHLSwQvPlVROcM5YAJfF7ojh)
		return
	uRV2sw5ivML93fWB0SJYThzeQn = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫჽ")))
	uRV2sw5ivML93fWB0SJYThzeQn = xn867tCVlscY4qbWZfh if not uRV2sw5ivML93fWB0SJYThzeQn else int(uRV2sw5ivML93fWB0SJYThzeQn)
	BMnu1kRfzjhy = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(nJF7oflOk6cLGSAey(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬჾ")))
	BMnu1kRfzjhy = xn867tCVlscY4qbWZfh if not BMnu1kRfzjhy else int(BMnu1kRfzjhy)
	if not uRV2sw5ivML93fWB0SJYThzeQn or not BMnu1kRfzjhy or not xn867tCVlscY4qbWZfh<=X1X59MWmb8oBPDFCJARwcjONihTdeZ-BMnu1kRfzjhy<=uRV2sw5ivML93fWB0SJYThzeQn:
		QA5SZJyNrBaXTK7PYGVpseCDzL(w8Ui6RsVhSPrqHfO4,uRV2sw5ivML93fWB0SJYThzeQn)
		return
	DEqw6zZbxcNypB7gjhQ8RflAK = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(NupI74tJCzYXmles9SbR6(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫჿ")))
	DEqw6zZbxcNypB7gjhQ8RflAK = xn867tCVlscY4qbWZfh if not DEqw6zZbxcNypB7gjhQ8RflAK else int(DEqw6zZbxcNypB7gjhQ8RflAK)
	if not DEqw6zZbxcNypB7gjhQ8RflAK or not xn867tCVlscY4qbWZfh<=X1X59MWmb8oBPDFCJARwcjONihTdeZ-DEqw6zZbxcNypB7gjhQ8RflAK<=DNh1dgpa4BK:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(NupI74tJCzYXmles9SbR6(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬᄀ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
		Ci4do9lZhuSczJ(yrcbRSFswvAfEdIWVj)
		return
	if yrcbRSFswvAfEdIWVj:
		YYqyRurD0V = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(i80mE7lHUwVk(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪᄁ")))
		YYqyRurD0V = xn867tCVlscY4qbWZfh if not YYqyRurD0V else int(YYqyRurD0V)
		if not YYqyRurD0V or not xn867tCVlscY4qbWZfh<=X1X59MWmb8oBPDFCJARwcjONihTdeZ-YYqyRurD0V<=Q3J7xTKDuAUoaPlB:
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(MlTVLBZ92kzorIq1Yw(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫᄂ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
	return
def QA5SZJyNrBaXTK7PYGVpseCDzL(EyaNdiZUtzq2rMulW9JL1ITHP3fgC,uRV2sw5ivML93fWB0SJYThzeQn):
	WlFvBQqZKAuwhGLgPMreJ7HN = jxCVeKSLb9rGDOl0Qtw6
	TYDprLEUsJZx = yrcbRSFswvAfEdIWVj if wAcHkmPB8a.ekiYyQnB4E2W830DC else w8Ui6RsVhSPrqHfO4
	if TYDprLEUsJZx:
		if not uRV2sw5ivML93fWB0SJYThzeQn: EyaNdiZUtzq2rMulW9JL1ITHP3fgC = yrcbRSFswvAfEdIWVj
		RRFCDEHdLj = LzVS3hOHQ6yfWtquRnbeC7l(EyaNdiZUtzq2rMulW9JL1ITHP3fgC)
		if len(RRFCDEHdLj)>jxCVeKSLb9rGDOl0Qtw6:
			SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨ࠰࡟ࡸࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫᄃ")+CH4Gk8XMzDVvl+IXE6voNmrb182AyQ(u"ࠩࠣࡡࠬᄄ"))
			JJ4wRxzq6WNrabTVlSyE,k2EpeoX7YHr,IqrdX3A6BVkeFhpgu5nWbPf,jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB,PJnMHzOorxmLAwc = RRFCDEHdLj[xn867tCVlscY4qbWZfh]
			pVw0rTSl5HtcN6Qk3mvuRKLio,GLK9WMOjARXp51J68kl4tb0en = jSEzXFL5y01pYgdrZUJKulC74Reo.split(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡠࡳࡁ࠻ࠨᄅ"))
			del RRFCDEHdLj[xn867tCVlscY4qbWZfh]
			opjwWPSagr97hMKVsDcE2Qe = l8YH46ObxQJTk1.sample(RRFCDEHdLj,jxCVeKSLb9rGDOl0Qtw6)
			JJ4wRxzq6WNrabTVlSyE,k2EpeoX7YHr,IqrdX3A6BVkeFhpgu5nWbPf,jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB,PJnMHzOorxmLAwc = opjwWPSagr97hMKVsDcE2Qe[xn867tCVlscY4qbWZfh]
			IqrdX3A6BVkeFhpgu5nWbPf = uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡠࡘࡔࡍ࡟ࠪᄆ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+ggtuNcvTn3HQ7SpE2(u"ࠬࠦ࠺ࠡࠩᄇ")+JJ4wRxzq6WNrabTVlSyE+GGy0cQe765nPYZ9E8Th+IqrdX3A6BVkeFhpgu5nWbPf
			l0lLk63Fj5YqivAJIuB = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬᄈ")
			Nw4CqZyuYgaiJWcbGl = OUFxZPuXDoGAbRz(u"ࠧศๆอฬึ฿วหࠩᄉ")
			button0,button1 = jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB
			LCbazZhTH3tOypqo5cF7 = [button0,button1,Nw4CqZyuYgaiJWcbGl]
			p0JCWU8KuhLfkPytQEaMbZxG = jxCVeKSLb9rGDOl0Qtw6 if wAcHkmPB8a.NiXZIL0GzwCV else tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠳࠳᛬")
			QA7oZDp3bUzwFde5ymVf = -tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠼᛭")
			while QA7oZDp3bUzwFde5ymVf<xn867tCVlscY4qbWZfh:
				DKvMnsX20uRES = l8YH46ObxQJTk1.sample(LCbazZhTH3tOypqo5cF7,jJ4LEcdl5w7BPMbQ)
				QA7oZDp3bUzwFde5ymVf = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,DKvMnsX20uRES[xn867tCVlscY4qbWZfh],DKvMnsX20uRES[jxCVeKSLb9rGDOl0Qtw6],DKvMnsX20uRES[dNx9DVCtafk4r],pVw0rTSl5HtcN6Qk3mvuRKLio,IqrdX3A6BVkeFhpgu5nWbPf,n6JjFHfmydIaLut(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᄊ"),p0JCWU8KuhLfkPytQEaMbZxG,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠺࠵ᛮ"))
				if QA7oZDp3bUzwFde5ymVf==OUFxZPuXDoGAbRz(u"࠶࠶ᛯ"): break
				import BktdqIvga8
				if QA7oZDp3bUzwFde5ymVf>=xn867tCVlscY4qbWZfh and DKvMnsX20uRES[QA7oZDp3bUzwFde5ymVf]==LCbazZhTH3tOypqo5cF7[jxCVeKSLb9rGDOl0Qtw6]:
					BktdqIvga8.JJ8MfBcExXU()
					if QA7oZDp3bUzwFde5ymVf>=xn867tCVlscY4qbWZfh: QA7oZDp3bUzwFde5ymVf = -n6JjFHfmydIaLut(u"࠿ᛰ")
				elif QA7oZDp3bUzwFde5ymVf>=xn867tCVlscY4qbWZfh and DKvMnsX20uRES[QA7oZDp3bUzwFde5ymVf]==LCbazZhTH3tOypqo5cF7[dNx9DVCtafk4r]:
					BktdqIvga8.h7oab3SLi5pUcvusmJqy9EZAgn(yrcbRSFswvAfEdIWVj)
				if QA7oZDp3bUzwFde5ymVf==-jxCVeKSLb9rGDOl0Qtw6: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,bKN9diGf8nmgecQPEqUzHRpoDuaO+RRbvqditj184m3(u"ࠩัีําࠠฯูฦࠫᄋ")+GGy0cQe765nPYZ9E8Th+i80mE7lHUwVk(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨᄌ"))
			WlFvBQqZKAuwhGLgPMreJ7HN = jxCVeKSLb9rGDOl0Qtw6
		else: WlFvBQqZKAuwhGLgPMreJ7HN = xn867tCVlscY4qbWZfh
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(iiauUxMktNW5X(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ᄍ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,iiauUxMktNW5X(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨᄎ"),nJF7oflOk6cLGSAey(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫᄏ"),WlFvBQqZKAuwhGLgPMreJ7HN,Z83rChqtg1oXUjI4YL)
	return
def ZJIojp1dmBMRl9(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF,LxWiszo6Gm0J9RvuMNn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn):
	if BF13hLNMY6OJqRyCmiGZ9s7zwPr5t in [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧ࠲ࠩᄐ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠨ࠴ࠪᄑ"),FAwWlRJg0UkN1(u"ࠩ࠶ࠫᄒ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪ࠸ࠬᄓ"),ne7wF4gSTRZo(u"ࠫ࠺࠭ᄔ"),ne7wF4gSTRZo(u"ࠬ࠷࠱ࠨᄕ"),BarIC3eR9bS(u"࠭࠱࠳ࠩᄖ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧ࠲࠵ࠪᄗ")] and QOazpItrTElo23ULn:
		import N7YIpvW3kX
		N7YIpvW3kX.qG8C65PDabzS(wH1a6KyFuLn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn)
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj,CH4Gk8XMzDVvl)
	elif BF13hLNMY6OJqRyCmiGZ9s7zwPr5t==mmbcsf2pd7gyjzreB(u"ࠨ࠸ࠪᄘ"):
		import V4OX6PRG0U,dhyPruobnI
		if QOazpItrTElo23ULn==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫᄙ"): dhyPruobnI.RLfOB3nsqaWXTugJvY(zDSw8LCxMQyraeXhojIWKmU(u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪᄚ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫᄛ"),RyfYSek61do5OnQMc=oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠲࠱࠲࠳ᛱ"))
		elif QOazpItrTElo23ULn==i80mE7lHUwVk(u"ࠬࡊࡅࡍࡇࡗࡉࠬᄜ"): eWtDTvwY3XLnlo4H5(UJeuWoLKP7ZI15O4ypTVs8caj,yrcbRSFswvAfEdIWVj)
		WjryKiBebavP = V4OX6PRG0U.nnHojZ4NcvVXhU0uzCw3OGEQrJ(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,LxWiszo6Gm0J9RvuMNn,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
		if QOazpItrTElo23ULn==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨᄝ"): cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	elif wH1a6KyFuLn==DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧ࠸ࠩᄞ"):
		import hazVQrxyDA
		hazVQrxyDA.TvG3S2WbUjnpgZ7JA0rDc1zBVPmRo8(VzO1gCHmjZ2ebRIL(u"ࠨࡡࡄࡐࡑ࠭ᄟ"))
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	elif wH1a6KyFuLn==OUFxZPuXDoGAbRz(u"ࠩ࠻ࠫᄠ"): oKew16fsvuV8.executebuiltin(iiLyoNwGbH03DIXhAkZn(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩᄡ")+Ym0kMIiBp4dFarGHxs6Svle+MlTVLBZ92kzorIq1Yw(u"ࠫࡄࡳ࡯ࡥࡧࡀࠫᄢ")+str(KIwAPk6E3vN4iUqf1n8HrJLQb)+YZXtBgvUPoM5sb(u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬᄣ"))
	elif wH1a6KyFuLn==mmbcsf2pd7gyjzreB(u"࠭࠹ࠨᄤ"):
		nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4)
	elif wH1a6KyFuLn==RRbvqditj184m3(u"ࠧ࠲࠲ࠪᄥ"):
		import hazVQrxyDA
		hazVQrxyDA.TvG3S2WbUjnpgZ7JA0rDc1zBVPmRo8(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡡࡊࡓࡔࡍࡌࡆࠩᄦ"))
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	elif wH1a6KyFuLn==iiLyoNwGbH03DIXhAkZn(u"ࠩ࠴࠸ࠬᄧ"): nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4,ggtuNcvTn3HQ7SpE2(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡘࡊࡓࡐࠨᄨ"))
	elif wH1a6KyFuLn==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࠶࠻ࠧᄩ"): nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4,VzO1gCHmjZ2ebRIL(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪᄪ"))
	elif wH1a6KyFuLn==ggtuNcvTn3HQ7SpE2(u"࠭࠱࠷ࠩᄫ"): nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4,iiauUxMktNW5X(u"ࠧࡎࡇࡑ࡙ࡤࡊࡅࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭ᄬ"))
	elif wH1a6KyFuLn==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨ࠳࠺ࠫᄭ"): nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩᄮ"))
	elif wH1a6KyFuLn==OUFxZPuXDoGAbRz(u"ࠪ࠵࠽࠭ᄯ"):
		H43svmuKOrRD2APk6w51hVGjabxiTt = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(iI7tuF0nEQoR(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨᄰ"))
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(VzO1gCHmjZ2ebRIL(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩᄱ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࠭ࠨᄲ")+H43svmuKOrRD2APk6w51hVGjabxiTt)
	if wH1a6KyFuLn in [ggtuNcvTn3HQ7SpE2(u"ࠧ࠺ࠩᄳ"),iiLyoNwGbH03DIXhAkZn(u"ࠨ࠳࠷ࠫᄴ"),mmbcsf2pd7gyjzreB(u"ࠩ࠴࠹ࠬᄵ"),NupI74tJCzYXmles9SbR6(u"ࠪ࠵࠻࠭ᄶ"),YZXtBgvUPoM5sb(u"ࠫ࠶࠽ࠧᄷ")]: cnsQb3Kk7jpPtlm5VSoTz2NIqFih(w8Ui6RsVhSPrqHfO4)
	return
def SKYeAy2ROlnkE0vP3Z(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF,LxWiszo6Gm0J9RvuMNn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn,JRNUShdGaF9mZrC):
	if jxBbwd2W6Xk: dXjNapb70Y()
	if wH1a6KyFuLn: ZJIojp1dmBMRl9(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF,LxWiszo6Gm0J9RvuMNn,BF13hLNMY6OJqRyCmiGZ9s7zwPr5t,QOazpItrTElo23ULn)
	F9i5MbESDeT6l4A(LxWiszo6Gm0J9RvuMNn)
	GGinQY9gb7uy8VeIrxH5,wwd9uU78cW23oA,bbm2i1qXDRsAjZJlV = w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj
	NNTh5mvfpJoFZe = ZOrzsPaG7olf31puLRxyHg9(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF,LxWiszo6Gm0J9RvuMNn,JRNUShdGaF9mZrC,GGinQY9gb7uy8VeIrxH5,wwd9uU78cW23oA,bbm2i1qXDRsAjZJlV)
	HNnSPWCLa5KA,XXnW8EheSJumUP,X4Pt7Kmqi9O,UJgI4DY2r9oT5c,pydcgC4K6Q,ZKkn8BAPNjcv3zdGRbYUigMFLh,VVGabjmRPNoT9ch5zs1C,hhmuOY4k2S = NNTh5mvfpJoFZe
	if HNnSPWCLa5KA: return
	if XXnW8EheSJumUP==YZXtBgvUPoM5sb(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬᄸ"): cfby3Jj71rT6IwB05V(rraWHLSwQvPlVROcM5YAJfF7ojh)
	KCaOHml1tPNASTiqMbRcghu(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡳࡵࡣࡵࡸࠬᄹ"))
	if SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(ggtuNcvTn3HQ7SpE2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡧࡦࡩࡨࡦࠩᄺ")) not in [TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡃࡘࡘࡔ࠭ᄻ"),VzO1gCHmjZ2ebRIL(u"ࠩࡖࡘࡔࡖࠧᄼ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫᄽ")]: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(OUFxZPuXDoGAbRz(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡤࡣࡦ࡬ࡪ࠭ᄾ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡇࡕࡕࡑࠪᄿ"))
	if SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡤࡹࡹࡵࡳࡤࡴࡤࡴࡪࡸࡳࠨᅀ")) not in [ggtuNcvTn3HQ7SpE2(u"ࠧࡂࡗࡗࡓࠬᅁ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡕࡗࡓࡕ࠭ᅂ")]: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡧࡵࡵࡱࡶࡧࡷࡧࡰࡦࡴࡶࠫᅃ"),n6JjFHfmydIaLut(u"ࠪࡅ࡚࡚ࡏࠨᅄ"))
	if not SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫᅅ")): SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ne7wF4gSTRZo(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬᅆ"),wAcHkmPB8a.DNS_SERVERS[xn867tCVlscY4qbWZfh])
	WjryKiBebavP = nnHojZ4NcvVXhU0uzCw3OGEQrJ(OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
	if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᅇ") in czrd0xT7BIl6noGC29w: wwd9uU78cW23oA = w8Ui6RsVhSPrqHfO4
	if OORugdCwcD9UrzXtT7vML1FWasP==iiauUxMktNW5X(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅈ"):
		if UJgI4DY2r9oT5c!=iI7tuF0nEQoR(u"ࠨ࠰࠱ࠫᅉ") and pydcgC4K6Q: YwAH3JsmDVNuafPFk()
		if ASul40difkXOIV>-jxCVeKSLb9rGDOl0Qtw6:
			oOeKYMEC2w8clVBUWuLf = [xn867tCVlscY4qbWZfh,q2qPkMFpR1G86dEAKXHivor9N(u"࠳࠸ᛳ"),OUFxZPuXDoGAbRz(u"࠴࠻ᛴ"),n6JjFHfmydIaLut(u"࠵࠾ᛵ"),RRbvqditj184m3(u"࠳࠸ᛲ"),ggtuNcvTn3HQ7SpE2(u"࠳࠵ᛸ"),OUFxZPuXDoGAbRz(u"࠺࠶ᛶ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠻࠳ᛷ"),iI7tuF0nEQoR(u"࠲࠳࠳᛹")]
			if (hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,VzO1gCHmjZ2ebRIL(u"ࠩ࡬ࡲࡹ࠭ᅊ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ᅋ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩᅌ")) or LxWiszo6Gm0J9RvuMNn not in oOeKYMEC2w8clVBUWuLf) and not wAcHkmPB8a.D9ZNeIiFunAftqWhB8Q:
				from nwToA5cgkt import Y5xSKyboT1Xtn
				VCKUfdcutwk,aaVIe6rSTpo8Q7sJNmtwH2qX = tA3CjNJfwQsPBZibxKhuD(Y5xSKyboT1Xtn)
				HNnSPWCLa5KA = ttVCcmzUqxefiWKIo1HJB(X4Pt7Kmqi9O,VCKUfdcutwk,GGinQY9gb7uy8VeIrxH5,wwd9uU78cW23oA,bbm2i1qXDRsAjZJlV)
				if VCKUfdcutwk and ZKkn8BAPNjcv3zdGRbYUigMFLh:
					if aaVIe6rSTpo8Q7sJNmtwH2qX: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,OUFxZPuXDoGAbRz(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫᅍ")+VVGabjmRPNoT9ch5zs1C+n6JjFHfmydIaLut(u"࠭࡟ࠨᅎ")+hhmuOY4k2S,X4Pt7Kmqi9O,VCKUfdcutwk,DNh1dgpa4BK)
					else: dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ᅏ")+VVGabjmRPNoT9ch5zs1C+nJF7oflOk6cLGSAey(u"ࠨࡡࠪᅐ")+hhmuOY4k2S,X4Pt7Kmqi9O)
			else:
				oo3hLMPNDkiAbvV.addDirectoryItem(ASul40difkXOIV,KJLkQsqSHMR1Np2(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬᅑ")+Ym0kMIiBp4dFarGHxs6Svle+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪᅒ"),SxtK1ciEvLXRAWFVfQDOMgBYC.ListItem(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪᅓ")))
				oo3hLMPNDkiAbvV.addDirectoryItem(ASul40difkXOIV,i80mE7lHUwVk(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨᅔ")+Ym0kMIiBp4dFarGHxs6Svle+DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭ᅕ"),SxtK1ciEvLXRAWFVfQDOMgBYC.ListItem(RRbvqditj184m3(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭ᅖ")))
			oo3hLMPNDkiAbvV.endOfDirectory(ASul40difkXOIV,GGinQY9gb7uy8VeIrxH5,wwd9uU78cW23oA,bbm2i1qXDRsAjZJlV)
	return
def cfby3Jj71rT6IwB05V(ofXaRUwli1thPBkZO):
	if i80mE7lHUwVk(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᅗ") in str(wAcHkmPB8a.SEND_THESE_EVENTS): return
	JTKDhtHY0LbUjqG32IgzdXu4 = yrcbRSFswvAfEdIWVj if ofXaRUwli1thPBkZO else w8Ui6RsVhSPrqHfO4
	if not JTKDhtHY0LbUjqG32IgzdXu4:
		mHuCn39xZo0Ab = jh4de7rmHqSsJNk9Zp(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(OUFxZPuXDoGAbRz(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪᅘ")))
		mHuCn39xZo0Ab = xn867tCVlscY4qbWZfh if not mHuCn39xZo0Ab else int(mHuCn39xZo0Ab)
		if not mHuCn39xZo0Ab or not xn867tCVlscY4qbWZfh<=X1X59MWmb8oBPDFCJARwcjONihTdeZ-mHuCn39xZo0Ab<=ofXaRUwli1thPBkZO: JTKDhtHY0LbUjqG32IgzdXu4 = w8Ui6RsVhSPrqHfO4
	if not JTKDhtHY0LbUjqG32IgzdXu4:
		X0qf2HRmkTlE6 = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(IXE6voNmrb182AyQ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨᅙ"))
		if X0qf2HRmkTlE6 in [gby0BnUuTNFk,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᅚ"),OUFxZPuXDoGAbRz(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫᅛ")]: JTKDhtHY0LbUjqG32IgzdXu4 = w8Ui6RsVhSPrqHfO4
	if not JTKDhtHY0LbUjqG32IgzdXu4:
		DVnOP3uBWwhCYQIJs8Tix9Sbd = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩᅜ"))
		DEOf7aYR4rZXubkAHBUMzhlmCgK,MnOPIpuYDZFJ = d7avUpQLRnJM(la983tXRDchGbrdIFQJf7kHeE)
		k2EsUy69W8ncLIh4maNilPXF = oYuwtBRKxPD1yl(la983tXRDchGbrdIFQJf7kHeE,DEOf7aYR4rZXubkAHBUMzhlmCgK,MnOPIpuYDZFJ,yrcbRSFswvAfEdIWVj,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡤ࡯ࡤࠡ࠽ࠪᅝ"))
		k2EsUy69W8ncLIh4maNilPXF = k2EsUy69W8ncLIh4maNilPXF[IXE6voNmrb182AyQ(u"࠲᛺")][IXE6voNmrb182AyQ(u"࠲᛺")]
		DEOf7aYR4rZXubkAHBUMzhlmCgK.close()
		y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(RRbvqditj184m3(u"࠸᛻")*DVnOP3uBWwhCYQIJs8Tix9Sbd.encode(JJQFjSIlALchiMzG9)).hexdigest()
		y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠵࠹᛼")*y0HETYJ4Crxi6RKvOMgGzBIeZ.encode(JJQFjSIlALchiMzG9)).hexdigest()
		y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(nJF7oflOk6cLGSAey(u"࠶࠿᛽")*y0HETYJ4Crxi6RKvOMgGzBIeZ.encode(JJQFjSIlALchiMzG9)).hexdigest()
		y0HETYJ4Crxi6RKvOMgGzBIeZ = str(int(y0HETYJ4Crxi6RKvOMgGzBIeZ[YZXtBgvUPoM5sb(u"࠳᛿"):tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠲࠴ᜀ")],tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠳࠹ᜁ")))[:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠿᛾")]
		if y0HETYJ4Crxi6RKvOMgGzBIeZ!=k2EsUy69W8ncLIh4maNilPXF: JTKDhtHY0LbUjqG32IgzdXu4 = w8Ui6RsVhSPrqHfO4
	if JTKDhtHY0LbUjqG32IgzdXu4: xnKMIOTmSWPqENY(yrcbRSFswvAfEdIWVj)
	return
def QQD6EVK5kJU1rWSfz(g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc,bTh6JaVi1mOoCEeKZ4kS8AWsnl,showDialogs):
	for AtSuQyEVeIHiY2h9461sX5J0mRl3 in KvISzcqJxT32p0riDPUlbaE:
		if AtSuQyEVeIHiY2h9461sX5J0mRl3 in PJnMHzOorxmLAwc: PJnMHzOorxmLAwc = PJnMHzOorxmLAwc.replace(AtSuQyEVeIHiY2h9461sX5J0mRl3,gby0BnUuTNFk)
	gwiQ59eNbhY2SlLZB7aOpTDdsk1 = bTh6JaVi1mOoCEeKZ4kS8AWsnl.split(iiauUxMktNW5X(u"ࠨ࠯ࠪᅞ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh] if GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩ࠰ࠫᅟ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl else bTh6JaVi1mOoCEeKZ4kS8AWsnl
	if not showDialogs or bTh6JaVi1mOoCEeKZ4kS8AWsnl in cQtJGSiEvRdY1r04L3VklZfDFP8: return yrcbRSFswvAfEdIWVj
	xxQfzpA2cJb7lH1BVS = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(iiLyoNwGbH03DIXhAkZn(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᅠ"))
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(KJLkQsqSHMR1Np2(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᅡ"),gby0BnUuTNFk)
	lsWcFk8qY3dwSXQeaj0Ot54DIEJxB = g8E2PLGXKpYsZnAHjtol in [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠽ᜅ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠵࠶࠶࠰࠲ᜃ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠴࠵࠵࠶࠲ᜂ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠶࠶࠰࠶࠶ᜄ")]
	if oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡅࡵࡴࡧࡵࡁࠬᅢ") in PJnMHzOorxmLAwc: PJnMHzOorxmLAwc = PJnMHzOorxmLAwc.split(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭࠿ࡶࡵࡨࡶࡂ࠭ᅣ"),TeYukOUW7i5NBM926DCjaAn0(u"࠱ᜆ"))[KJLkQsqSHMR1Np2(u"࠱ᜇ")]+VzO1gCHmjZ2ebRIL(u"ࠧࠪࠩᅤ")
	TBFHEgKm8V51WlO6nUS = PJnMHzOorxmLAwc.lower()
	CLE5vp28AXsg63bdWnMQBVJ = g8E2PLGXKpYsZnAHjtol in [xn867tCVlscY4qbWZfh,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠵࠵࠺ᜊ"),q2qPkMFpR1G86dEAKXHivor9N(u"࠳࠳࠴࠻࠷ᜈ"),TeYukOUW7i5NBM926DCjaAn0(u"࠴࠵࠶ᜉ")]
	bfjYlngwvM5qHKhGp7L = KJLkQsqSHMR1Np2(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩᅥ") in TBFHEgKm8V51WlO6nUS
	dnsOgYCL7E = RRbvqditj184m3(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩᅦ") in TBFHEgKm8V51WlO6nUS
	qGL7VAznYhiN4EwaO9BUmRC2XWl = iiauUxMktNW5X(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪᅧ") in TBFHEgKm8V51WlO6nUS
	MWO7P3BchmFaq29dxRYNrul = FAwWlRJg0UkN1(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭ᅨ") in TBFHEgKm8V51WlO6nUS
	xtyzhsQckIVv = nJF7oflOk6cLGSAey(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡰ࡭ࡸࡹࡩ࡯ࡩࠣ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠠࡤࡪࡨࡧࡰ࠭ᅩ") in TBFHEgKm8V51WlO6nUS
	Eb4pxZHRNmAoX1Q370fsqiTv2Bgw = nJF7oflOk6cLGSAey(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡽࡴࡻࡲࠡࡰࡨࡸࡼࡵࡲ࡬ࠢࡧࡩࡻ࡯ࡣࡦࡵࠪᅪ") in TBFHEgKm8V51WlO6nUS
	wR71aegTz8IfilEUDKCx2OY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(KJLkQsqSHMR1Np2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᅫ"))
	VVRYrMqftdmjBAEQoXkcewuI2JTD0 = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᅬ"))
	x6lB0smR41yNek5hP7ZDYfMuGUIXF3 = VzO1gCHmjZ2ebRIL(u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫᅭ")
	ccXNWGRkZxzy6FQCM7jhLs = nJF7oflOk6cLGSAey(u"ࠪࡉࡷࡸ࡯ࡳࠢࠪᅮ")+str(g8E2PLGXKpYsZnAHjtol)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫ࠿ࠦࠧᅯ")+PJnMHzOorxmLAwc
	ccXNWGRkZxzy6FQCM7jhLs = pFnO2T7r16k(ccXNWGRkZxzy6FQCM7jhLs)
	if any([CLE5vp28AXsg63bdWnMQBVJ,bfjYlngwvM5qHKhGp7L,dnsOgYCL7E,qGL7VAznYhiN4EwaO9BUmRC2XWl,MWO7P3BchmFaq29dxRYNrul,xtyzhsQckIVv,Eb4pxZHRNmAoX1Q370fsqiTv2Bgw]): x6lB0smR41yNek5hP7ZDYfMuGUIXF3 += OUFxZPuXDoGAbRz(u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬᅰ")
	if lsWcFk8qY3dwSXQeaj0Ot54DIEJxB: x6lB0smR41yNek5hP7ZDYfMuGUIXF3 += zDSw8LCxMQyraeXhojIWKmU(u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭ᅱ")
	ccXNWGRkZxzy6FQCM7jhLs = okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+ccXNWGRkZxzy6FQCM7jhLs+GGy0cQe765nPYZ9E8Th
	if wR71aegTz8IfilEUDKCx2OY==MlTVLBZ92kzorIq1Yw(u"ࠧࡂࡕࡎࠫᅲ") or VVRYrMqftdmjBAEQoXkcewuI2JTD0==n6JjFHfmydIaLut(u"ࠨࡃࡖࡏࠬᅳ"):
		x6lB0smR41yNek5hP7ZDYfMuGUIXF3 += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+i80mE7lHUwVk(u"๊่ࠩࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤࠫᅴ")+GGy0cQe765nPYZ9E8Th
	PNS2WCYDafK6qmjvo7wpsgL4z05t = yrcbRSFswvAfEdIWVj
	if wR71aegTz8IfilEUDKCx2OY==iiLyoNwGbH03DIXhAkZn(u"ࠪࡅࡘࡑࠧᅵ") or VVRYrMqftdmjBAEQoXkcewuI2JTD0==zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡆ࡙ࡋࠨᅶ"):
		QA7oZDp3bUzwFde5ymVf = yc8Ph4rFsCIvQbOA(ne7wF4gSTRZo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᅷ"),mmbcsf2pd7gyjzreB(u"࠭ฮา๊ฯࠫᅸ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠧฦำึห้ࠦไๅ็หี๊าࠧᅹ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨฬุ่๏ำࠠศๆุ่่๊ษࠨᅺ"),gwiQ59eNbhY2SlLZB7aOpTDdsk1+AXmnlSGOyNfW7PxEdv+hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1),x6lB0smR41yNek5hP7ZDYfMuGUIXF3+okfdjS4RmM+ccXNWGRkZxzy6FQCM7jhLs)
		if QA7oZDp3bUzwFde5ymVf==jxCVeKSLb9rGDOl0Qtw6:
			from BktdqIvga8 import JJ8MfBcExXU
			JJ8MfBcExXU()
		elif QA7oZDp3bUzwFde5ymVf==dNx9DVCtafk4r: PNS2WCYDafK6qmjvo7wpsgL4z05t = w8Ui6RsVhSPrqHfO4
	else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gwiQ59eNbhY2SlLZB7aOpTDdsk1+AXmnlSGOyNfW7PxEdv+hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1),x6lB0smR41yNek5hP7ZDYfMuGUIXF3,ccXNWGRkZxzy6FQCM7jhLs)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᅻ"),xxQfzpA2cJb7lH1BVS)
	return PNS2WCYDafK6qmjvo7wpsgL4z05t
def FdPerk1Bcfxo4Hi63tLg8(iP2nJo9WOLqQdDSE3hI1=yrcbRSFswvAfEdIWVj,o5xV3EIlHCn4imuG=[]):
	TLmzkyRQINn9ftCvOB04pu2l = [sTZKJYrgqmkxtvpP,U24naHzCgdv7wWF]+o5xV3EIlHCn4imuG
	for eGqj6NWXtO8Mogcu3yrwlRUbS9kh in bCoOHfPdMryRgauz0IVpth.listdir(jjzt6rqdQKM):
		if iP2nJo9WOLqQdDSE3hI1 and (eGqj6NWXtO8Mogcu3yrwlRUbS9kh.startswith(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࡭ࡵࡺࡶࠨᅼ")) or eGqj6NWXtO8Mogcu3yrwlRUbS9kh.startswith(VzO1gCHmjZ2ebRIL(u"ࠫࡲ࠹ࡵࠨᅽ"))): continue
		if eGqj6NWXtO8Mogcu3yrwlRUbS9kh.startswith(nJF7oflOk6cLGSAey(u"ࠬ࡬ࡩ࡭ࡧࡢࠫᅾ")): continue
		ddFoMfGl4YrjR2h0tEIkQAUVNia8H = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,eGqj6NWXtO8Mogcu3yrwlRUbS9kh)
		if ddFoMfGl4YrjR2h0tEIkQAUVNia8H in TLmzkyRQINn9ftCvOB04pu2l: continue
		try: bCoOHfPdMryRgauz0IVpth.remove(ddFoMfGl4YrjR2h0tEIkQAUVNia8H)
		except: pass
	if Qbw6RD7GBut not in TLmzkyRQINn9ftCvOB04pu2l: LamxwbXfkZ6JDoCRlgBIehsEc(Qbw6RD7GBut,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
	RyfYSek61do5OnQMc.sleep(uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠶ᜋ"))
	return
def KZj7PFMYXRolusEUcrJ(X0Vt9p7GnexUq8v2S3PlYsfkQbO,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4=w8Ui6RsVhSPrqHfO4,cIO1sJZ5mTV94jpnl=w8Ui6RsVhSPrqHfO4):
	KKFPNRzufO = KKFPNRzufO+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᅿ")+X0Vt9p7GnexUq8v2S3PlYsfkQbO
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4,cIO1sJZ5mTV94jpnl)
	if KKFPNRzufO in tKObfFRod18ZU.content: tKObfFRod18ZU.succeeded = yrcbRSFswvAfEdIWVj
	if not tKObfFRod18ZU.succeeded:
		cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	return tKObfFRod18ZU
def Ue1tnoLgHpSwm8vuRrMJq7DEYiV9cZ(KKFPNRzufO):
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,FAwWlRJg0UkN1(u"ࠧࡈࡇࡗࠫᆀ"),KKFPNRzufO,gby0BnUuTNFk,gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩᆁ"),w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
	A7AnHmraxhQl2jEvMiBwPy94VL = []
	if tKObfFRod18ZU.succeeded:
		cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
		bXAeVl3gmNOBQGCLtF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬᆂ"),cHuIdQiPshK8mwFUlkADGLv42fpeR)
		if bXAeVl3gmNOBQGCLtF: cHuIdQiPshK8mwFUlkADGLv42fpeR = okfdjS4RmM.join(bXAeVl3gmNOBQGCLtF)
		RoMUgG4lAyZ2ExSimCpqz = cHuIdQiPshK8mwFUlkADGLv42fpeR.replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk).strip(okfdjS4RmM).split(okfdjS4RmM)
		A7AnHmraxhQl2jEvMiBwPy94VL = []
		for X0Vt9p7GnexUq8v2S3PlYsfkQbO in RoMUgG4lAyZ2ExSimCpqz:
			if X0Vt9p7GnexUq8v2S3PlYsfkQbO.count(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࠲ࠬᆃ"))==jJ4LEcdl5w7BPMbQ: A7AnHmraxhQl2jEvMiBwPy94VL.append(X0Vt9p7GnexUq8v2S3PlYsfkQbO)
	return A7AnHmraxhQl2jEvMiBwPy94VL
def vUzhT0KMgXLsxB6GJat2pWA(*aargs):
	DR8rSiVXa6Kz7nGtf2PqohTI9OFJy = MlTVLBZ92kzorIq1Yw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬᆄ")
	eu2iSsfRJLZVkEm1OMXb = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩᆅ")
	GkeTMmuHihp7 = Ue1tnoLgHpSwm8vuRrMJq7DEYiV9cZ(eu2iSsfRJLZVkEm1OMXb)
	A7AnHmraxhQl2jEvMiBwPy94VL = Ue1tnoLgHpSwm8vuRrMJq7DEYiV9cZ(DR8rSiVXa6Kz7nGtf2PqohTI9OFJy)
	QFEhIp5iPZcs = GkeTMmuHihp7+A7AnHmraxhQl2jEvMiBwPy94VL
	SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬᆆ")+str(len(GkeTMmuHihp7))+ne7wF4gSTRZo(u"ࠧࠬࠩᆇ")+str(len(A7AnHmraxhQl2jEvMiBwPy94VL))+TeYukOUW7i5NBM926DCjaAn0(u"ࠨࠢࡠࠫᆈ"))
	X0Vt9p7GnexUq8v2S3PlYsfkQbO = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(iiLyoNwGbH03DIXhAkZn(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩᆉ"))
	tKObfFRod18ZU = PKSnHM3QkOgGUyABi12slV()
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(mmbcsf2pd7gyjzreB(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪᆊ"),gby0BnUuTNFk)
	if X0Vt9p7GnexUq8v2S3PlYsfkQbO or QFEhIp5iPZcs:
		JJ4wRxzq6WNrabTVlSyE,BImTkcn8Lh1gOACeHiwob = xn867tCVlscY4qbWZfh,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠷࠰ᜌ")
		BL1qdJmpgXQYK3wMGHkxA = len(QFEhIp5iPZcs)
		QH5D7WT6OwKe3zk = BImTkcn8Lh1gOACeHiwob
		if BL1qdJmpgXQYK3wMGHkxA>QH5D7WT6OwKe3zk: vhRf7IJAGUPVa6StlKbCDr85qxEWZT = QH5D7WT6OwKe3zk
		else: vhRf7IJAGUPVa6StlKbCDr85qxEWZT = BL1qdJmpgXQYK3wMGHkxA
		O3vhgJXDcTbzmynVi9RKL = l8YH46ObxQJTk1.sample(QFEhIp5iPZcs,vhRf7IJAGUPVa6StlKbCDr85qxEWZT)
		if X0Vt9p7GnexUq8v2S3PlYsfkQbO: O3vhgJXDcTbzmynVi9RKL = [X0Vt9p7GnexUq8v2S3PlYsfkQbO]+O3vhgJXDcTbzmynVi9RKL
		DEIMqdruWs = N3fAtRaD2wzZ7quOsHU0VMK1SbXeLc(yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
		LjWyqBVS3gE = RyfYSek61do5OnQMc.time()
		while RyfYSek61do5OnQMc.time()-LjWyqBVS3gE<=BImTkcn8Lh1gOACeHiwob and not DEIMqdruWs.finishedLIST:
			if JJ4wRxzq6WNrabTVlSyE<vhRf7IJAGUPVa6StlKbCDr85qxEWZT:
				X0Vt9p7GnexUq8v2S3PlYsfkQbO = O3vhgJXDcTbzmynVi9RKL[JJ4wRxzq6WNrabTVlSyE]
				DEIMqdruWs.C69BPkYpSoW5JnUOsVGFm4bh(JJ4wRxzq6WNrabTVlSyE,KZj7PFMYXRolusEUcrJ,X0Vt9p7GnexUq8v2S3PlYsfkQbO,*aargs)
			RyfYSek61do5OnQMc.sleep(nJF7oflOk6cLGSAey(u"࠰࠯࠹࠸ᜍ"))
			JJ4wRxzq6WNrabTVlSyE += jxCVeKSLb9rGDOl0Qtw6
			SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭ᆋ")+X0Vt9p7GnexUq8v2S3PlYsfkQbO+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࠦ࡝ࠨᆌ"))
		finishedLIST = DEIMqdruWs.finishedLIST
		if finishedLIST:
			resultsDICT = DEIMqdruWs.resultsDICT
			cuJP53XVrLNjslCFESBYbWKoIM = finishedLIST[xn867tCVlscY4qbWZfh]
			tKObfFRod18ZU = resultsDICT[cuJP53XVrLNjslCFESBYbWKoIM]
			X0Vt9p7GnexUq8v2S3PlYsfkQbO = O3vhgJXDcTbzmynVi9RKL[int(cuJP53XVrLNjslCFESBYbWKoIM)]
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ggtuNcvTn3HQ7SpE2(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭ᆍ"),X0Vt9p7GnexUq8v2S3PlYsfkQbO)
			if cuJP53XVrLNjslCFESBYbWKoIM!=xn867tCVlscY4qbWZfh: SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+TeYukOUW7i5NBM926DCjaAn0(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪᆎ")+X0Vt9p7GnexUq8v2S3PlYsfkQbO+FAwWlRJg0UkN1(u"ࠨࠢࡠࠫᆏ"))
			else: SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫᆐ")+X0Vt9p7GnexUq8v2S3PlYsfkQbO+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࠤࡢ࠭ᆑ"))
	return tKObfFRod18ZU
def CUswqTPGY5okFjxzZnvyrV6IBAWb(jaG5xMmILXvegsAphnTK,o742nplw96aA,ee6NmZrgyIpVBLP7j9H0Kwt4i18f=w8Ui6RsVhSPrqHfO4):
	arhl1O0zEt2gDPqQBn5mfFJ7IbCTv = jaG5xMmILXvegsAphnTK.create_connection
	def GIjUtMYv6Qs0kq9pC8SV25iOayD(aPqDfxk0W1iGRJrCF3,*aargs,**kkwargs):
		Xnv4AQJeLGuZOMpDx72oH,gg6BsId5tceL = aPqDfxk0W1iGRJrCF3
		mpJ0w5ZMqU83TuOoxdXbv = ElRUG8zKHm(Xnv4AQJeLGuZOMpDx72oH,o742nplw96aA)
		if mpJ0w5ZMqU83TuOoxdXbv: Xnv4AQJeLGuZOMpDx72oH = mpJ0w5ZMqU83TuOoxdXbv[xn867tCVlscY4qbWZfh]
		elif ee6NmZrgyIpVBLP7j9H0Kwt4i18f:
			if o742nplw96aA in wAcHkmPB8a.DNS_SERVERS: wAcHkmPB8a.DNS_SERVERS.remove(o742nplw96aA)
			if wAcHkmPB8a.DNS_SERVERS:
				nAIzXd1tOTxrVKGg = wAcHkmPB8a.DNS_SERVERS[xn867tCVlscY4qbWZfh]
				mpJ0w5ZMqU83TuOoxdXbv = ElRUG8zKHm(Xnv4AQJeLGuZOMpDx72oH,nAIzXd1tOTxrVKGg)
				if mpJ0w5ZMqU83TuOoxdXbv: Xnv4AQJeLGuZOMpDx72oH = mpJ0w5ZMqU83TuOoxdXbv[xn867tCVlscY4qbWZfh]
		if mpJ0w5ZMqU83TuOoxdXbv: wAcHkmPB8a.dns_succeeded_urls.append(Xnv4AQJeLGuZOMpDx72oH)
		aPqDfxk0W1iGRJrCF3 = (Xnv4AQJeLGuZOMpDx72oH,gg6BsId5tceL)
		return arhl1O0zEt2gDPqQBn5mfFJ7IbCTv(aPqDfxk0W1iGRJrCF3,*aargs,**kkwargs)
	jaG5xMmILXvegsAphnTK.create_connection = GIjUtMYv6Qs0kq9pC8SV25iOayD
	return arhl1O0zEt2gDPqQBn5mfFJ7IbCTv
def Hn1IRyOWfKx(KKFPNRzufO):
	uM9V0nm16N3Tf,LIFbVhGpNt = KKFPNRzufO.split(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫ࠴࠭ᆒ"))[dNx9DVCtafk4r],ggtuNcvTn3HQ7SpE2(u"࠹࠲ᜎ")
	if ne7wF4gSTRZo(u"ࠬࡀࠧᆓ") in uM9V0nm16N3Tf: uM9V0nm16N3Tf,LIFbVhGpNt = uM9V0nm16N3Tf.split(BarIC3eR9bS(u"࠭࠺ࠨᆔ"))
	soAeONHLV3CMDv5uYh1STcRi2z = MlTVLBZ92kzorIq1Yw(u"ࠧ࠰ࠩᆕ")+VzO1gCHmjZ2ebRIL(u"ࠨ࠱ࠪᆖ").join(KKFPNRzufO.split(FAwWlRJg0UkN1(u"ࠩ࠲ࠫᆗ"))[FAwWlRJg0UkN1(u"࠵ᜏ"):])
	Z05rTiu6LwakteK8VfY = YZXtBgvUPoM5sb(u"ࠪࡋࡊ࡚ࠠࠨᆘ")+soAeONHLV3CMDv5uYh1STcRi2z+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫᆙ")
	Z05rTiu6LwakteK8VfY += NupI74tJCzYXmles9SbR6(u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬᆚ")+uM9V0nm16N3Tf+BarIC3eR9bS(u"࠭࡜ࡳ࡞ࡱࠫᆛ")
	Z05rTiu6LwakteK8VfY += IXE6voNmrb182AyQ(u"ࠧ࡝ࡴ࡟ࡲࠬᆜ")
	from socket import socket as RLP7vbMuqwBJNgK0aeIGks65,AF_INET as dNx2OZneM9zpV4vX8bS,SOCK_STREAM as kNZV81f9a43SAro67UsIp5CPM
	try:
		fgXu9pV0m31TLPGNxHS = RLP7vbMuqwBJNgK0aeIGks65(dNx2OZneM9zpV4vX8bS,kNZV81f9a43SAro67UsIp5CPM)
		fgXu9pV0m31TLPGNxHS.connect((uM9V0nm16N3Tf,LIFbVhGpNt))
		fgXu9pV0m31TLPGNxHS.send(Z05rTiu6LwakteK8VfY.encode(JJQFjSIlALchiMzG9))
		mLstTS7yCYWIgb61vDxu980aNB = fgXu9pV0m31TLPGNxHS.recv(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠸࠵࠿࠶ᜑ")*uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠴࠴࠷࠺ᜐ"))
		cHuIdQiPshK8mwFUlkADGLv42fpeR = repr(mLstTS7yCYWIgb61vDxu980aNB)
	except: cHuIdQiPshK8mwFUlkADGLv42fpeR = gby0BnUuTNFk
	return cHuIdQiPshK8mwFUlkADGLv42fpeR
def syFKrN8pIlTDZL6x(critSDjMTkyKQ5LgCWd4IGpxnf):
	fKWT2v0bLhxjUYGNH8POI3qtp9Me6Z = repr(critSDjMTkyKQ5LgCWd4IGpxnf.encode(JJQFjSIlALchiMzG9)).replace(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠣࠩࠥᆝ"),gby0BnUuTNFk)
	return fKWT2v0bLhxjUYGNH8POI3qtp9Me6Z
def ThtMBSPziG0jZr9sHYCKa(PiwtNbsoZT):
	f5hOmtlXy9Mqb08IeFcU1 = gby0BnUuTNFk
	if cAIRPFK6boejVU549WzqBGCaJ0r: PiwtNbsoZT = PiwtNbsoZT.decode(JJQFjSIlALchiMzG9)
	from unicodedata import decomposition as Ke26LZlY9Am7pVCcPtRX1Osjd
	for ZLCI4dSEXy in PiwtNbsoZT:
		if   ZLCI4dSEXy==mmbcsf2pd7gyjzreB(u"ࡷࠪฦࠬᆞ"): YRQieINljWytVpKMZaod1Cx = TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫᆟ")
		elif ZLCI4dSEXy==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࡹࠬษࠧᆠ"): YRQieINljWytVpKMZaod1Cx = zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ᆡ")
		elif ZLCI4dSEXy==NupI74tJCzYXmles9SbR6(u"ࡻࠧลࠩᆢ"): YRQieINljWytVpKMZaod1Cx = RRbvqditj184m3(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨᆣ")
		elif ZLCI4dSEXy==nJF7oflOk6cLGSAey(u"ࡶࠩศࠫᆤ"): YRQieINljWytVpKMZaod1Cx = ggtuNcvTn3HQ7SpE2(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪᆥ")
		elif ZLCI4dSEXy==RRbvqditj184m3(u"ࡸࠫห࠭ᆦ"): YRQieINljWytVpKMZaod1Cx = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬᆧ")
		else:
			oCpk3FHaTG42 = Ke26LZlY9Am7pVCcPtRX1Osjd(ZLCI4dSEXy)
			if UpN1CezytPO9XoduhxZSD in oCpk3FHaTG42: YRQieINljWytVpKMZaod1Cx = iI7tuF0nEQoR(u"ࠬࡢ࡜ࡶࠩᆨ")+oCpk3FHaTG42.split(UpN1CezytPO9XoduhxZSD,jxCVeKSLb9rGDOl0Qtw6)[jxCVeKSLb9rGDOl0Qtw6]
			else:
				YRQieINljWytVpKMZaod1Cx = iiauUxMktNW5X(u"࠭࠰࠱࠲࠳ࠫᆩ")+hex(ord(ZLCI4dSEXy)).replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧ࠱ࡺࠪᆪ"),gby0BnUuTNFk)
				YRQieINljWytVpKMZaod1Cx = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨ࡞࡟ࡹࠬᆫ")+YRQieINljWytVpKMZaod1Cx[-z5RruqXvsLaTf7e9c:]
		f5hOmtlXy9Mqb08IeFcU1 += YRQieINljWytVpKMZaod1Cx
	f5hOmtlXy9Mqb08IeFcU1 = f5hOmtlXy9Mqb08IeFcU1.replace(ne7wF4gSTRZo(u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪᆬ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫᆭ"))
	if cAIRPFK6boejVU549WzqBGCaJ0r: f5hOmtlXy9Mqb08IeFcU1 = f5hOmtlXy9Mqb08IeFcU1.decode(iI7tuF0nEQoR(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬᆮ")).encode(JJQFjSIlALchiMzG9)
	else: f5hOmtlXy9Mqb08IeFcU1 = f5hOmtlXy9Mqb08IeFcU1.encode(JJQFjSIlALchiMzG9).decode(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ᆯ"))
	return f5hOmtlXy9Mqb08IeFcU1
def vRoGedUjt2Ac6pIbufBX8sKy(header=ggtuNcvTn3HQ7SpE2(u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭ᆰ"),OO25Id38BVPYQuTfwqoy6ZA=gby0BnUuTNFk,e7xDrkFVzdSCKyuiXtI8=yrcbRSFswvAfEdIWVj,source=gby0BnUuTNFk):
	czrd0xT7BIl6noGC29w = f75Syme6HMwc1OqhGbTjE8Ptp(header,OO25Id38BVPYQuTfwqoy6ZA,type=SxtK1ciEvLXRAWFVfQDOMgBYC.INPUT_ALPHANUM)
	czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w.strip(UpN1CezytPO9XoduhxZSD).replace(TFAVlh4ONfuyivg,UpN1CezytPO9XoduhxZSD).replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	if not czrd0xT7BIl6noGC29w and not e7xDrkFVzdSCKyuiXtI8:
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,iiauUxMktNW5X(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫᆱ")+czrd0xT7BIl6noGC29w+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࠤࠪᆲ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬᆳ"))
		return gby0BnUuTNFk
	if czrd0xT7BIl6noGC29w not in [gby0BnUuTNFk,UpN1CezytPO9XoduhxZSD]:
		czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w.strip(UpN1CezytPO9XoduhxZSD)
		czrd0xT7BIl6noGC29w = ThtMBSPziG0jZr9sHYCKa(czrd0xT7BIl6noGC29w)
	if source!=q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬᆴ") and OAfn469BaprdwGYVkvyE2F0x(ne7wF4gSTRZo(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭ᆵ"),gby0BnUuTNFk,[czrd0xT7BIl6noGC29w],yrcbRSFswvAfEdIWVj):
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,iI7tuF0nEQoR(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨᆶ")+czrd0xT7BIl6noGC29w+ne7wF4gSTRZo(u"࠭ࠢࠨᆷ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩᆸ"))
		return gby0BnUuTNFk
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,ne7wF4gSTRZo(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫᆹ")+czrd0xT7BIl6noGC29w+n6JjFHfmydIaLut(u"ࠩࠥࠫᆺ"))
	return czrd0xT7BIl6noGC29w
def IYTJXVfryDt42MvaRNKLC(CC3nOPFMovd72u,Tf5ueYGZIFl1hraoEOVKi,IciL6hoO5F1MDSVPjypWZs8kKx={}):
	KKFPNRzufO,uuYHU36PtpR8Ll5y,xmN8TMoaUAjwHGpQ,jlHeTn9pz15 = Tf5ueYGZIFl1hraoEOVKi,{},{},gby0BnUuTNFk
	if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࢀࠬᆻ") in Tf5ueYGZIFl1hraoEOVKi: KKFPNRzufO,uuYHU36PtpR8Ll5y = avXHrARzQuBW4s(Tf5ueYGZIFl1hraoEOVKi,NupI74tJCzYXmles9SbR6(u"ࠫࢁ࠭ᆼ"))
	p1yV9gLZPAcKhJod2NtGDwi0vB = list(set(list(IciL6hoO5F1MDSVPjypWZs8kKx.keys())+list(uuYHU36PtpR8Ll5y.keys())))
	for YYtF0fR1d8ThnNaHXBCDwmz9uEZK in p1yV9gLZPAcKhJod2NtGDwi0vB:
		if YYtF0fR1d8ThnNaHXBCDwmz9uEZK in list(uuYHU36PtpR8Ll5y.keys()): xmN8TMoaUAjwHGpQ[YYtF0fR1d8ThnNaHXBCDwmz9uEZK] = uuYHU36PtpR8Ll5y[YYtF0fR1d8ThnNaHXBCDwmz9uEZK]
		else: xmN8TMoaUAjwHGpQ[YYtF0fR1d8ThnNaHXBCDwmz9uEZK] = IciL6hoO5F1MDSVPjypWZs8kKx[YYtF0fR1d8ThnNaHXBCDwmz9uEZK]
	if FAwWlRJg0UkN1(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᆽ") not in p1yV9gLZPAcKhJod2NtGDwi0vB: xmN8TMoaUAjwHGpQ[GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᆾ")] = Zc6lYG3a02XVPA1WLr()
	if TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᆿ") not in p1yV9gLZPAcKhJod2NtGDwi0vB: xmN8TMoaUAjwHGpQ[sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᇀ")] = mDR9euKnv4jMSdbEpwcktJz5W6Cf(KKFPNRzufO,NupI74tJCzYXmles9SbR6(u"ࠩࡸࡶࡱ࠭ᇁ"))
	if GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬᇂ") not in p1yV9gLZPAcKhJod2NtGDwi0vB: xmN8TMoaUAjwHGpQ[zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ᇃ")] = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬ࡫࡮࠭ࡣࡵ࠿ࡶࡃ࠰࠯࠻ࠪᇄ")
	for YYtF0fR1d8ThnNaHXBCDwmz9uEZK in list(xmN8TMoaUAjwHGpQ.keys()): jlHeTn9pz15 += lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࠦࠨᇅ")+YYtF0fR1d8ThnNaHXBCDwmz9uEZK+BarIC3eR9bS(u"ࠧ࠾ࠩᇆ")+xmN8TMoaUAjwHGpQ[YYtF0fR1d8ThnNaHXBCDwmz9uEZK]
	if jlHeTn9pz15: jlHeTn9pz15 = iiLyoNwGbH03DIXhAkZn(u"ࠨࡾࠪᇇ")+jlHeTn9pz15[jxCVeKSLb9rGDOl0Qtw6:]
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(ECtBvFXOLM,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࡊࡉ࡙࠭ᇈ"),KKFPNRzufO,gby0BnUuTNFk,xmN8TMoaUAjwHGpQ,gby0BnUuTNFk,gby0BnUuTNFk,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧᇉ"),yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
	if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨᇊ") not in cHuIdQiPshK8mwFUlkADGLv42fpeR: return [YZXtBgvUPoM5sb(u"ࠬ࠳࠱ࠨᇋ")],[KKFPNRzufO+jlHeTn9pz15]
	if ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪᇌ") in cHuIdQiPshK8mwFUlkADGLv42fpeR: return [tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧ࠮࠳ࠪᇍ")],[KKFPNRzufO+jlHeTn9pz15]
	if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬᇎ") in cHuIdQiPshK8mwFUlkADGLv42fpeR: return [NupI74tJCzYXmles9SbR6(u"ࠩ࠰࠵ࠬᇏ")],[KKFPNRzufO+jlHeTn9pz15]
	uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R,HxyTDVl2Zb3SaIUw,DGoknQZBbEaLY = [],[],[],[]
	pphu4kvVyHtj7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(TeYukOUW7i5NBM926DCjaAn0(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫᇐ"),cHuIdQiPshK8mwFUlkADGLv42fpeR+okfdjS4RmM,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not pphu4kvVyHtj7: return [IXE6voNmrb182AyQ(u"ࠫ࠲࠷ࠧᇑ")],[KKFPNRzufO+jlHeTn9pz15]
	for qqefz4pwxlcIZSkm30Cg,SSQHn7pvhlREIWXaOTz in pphu4kvVyHtj7:
		Tl0XoQjyt7WHpZ1kD,H43svmuKOrRD2APk6w51hVGjabxiTt,DYNVS1Bbgs7 = {},-KJLkQsqSHMR1Np2(u"࠶ᜒ"),-KJLkQsqSHMR1Np2(u"࠶ᜒ")
		loeSiBRfO8K6DkbGzCnpL3FZ = gby0BnUuTNFk
		pYNRI5bDO2zFkejHSoqB7 = qqefz4pwxlcIZSkm30Cg.split(iiauUxMktNW5X(u"ࠬ࠲ࠧᇒ"))
		for AvDtLJr2PUKNG0uanEMI in pYNRI5bDO2zFkejHSoqB7:
			if ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࠽ࠨᇓ") in AvDtLJr2PUKNG0uanEMI:
				YYtF0fR1d8ThnNaHXBCDwmz9uEZK,qkElOYv2aF = AvDtLJr2PUKNG0uanEMI.split(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧ࠾ࠩᇔ"),MlTVLBZ92kzorIq1Yw(u"࠷ᜓ"))
				Tl0XoQjyt7WHpZ1kD[YYtF0fR1d8ThnNaHXBCDwmz9uEZK.lower()] = qkElOYv2aF
		if FAwWlRJg0UkN1(u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬᇕ") in qqefz4pwxlcIZSkm30Cg.lower():
			H43svmuKOrRD2APk6w51hVGjabxiTt = int(Tl0XoQjyt7WHpZ1kD[BarIC3eR9bS(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ᇖ")])//ne7wF4gSTRZo(u"࠱࠱࠴࠷᜔")
			loeSiBRfO8K6DkbGzCnpL3FZ += str(H43svmuKOrRD2APk6w51hVGjabxiTt)+iiauUxMktNW5X(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪᇗ")
		elif TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧᇘ") in qqefz4pwxlcIZSkm30Cg.lower():
			H43svmuKOrRD2APk6w51hVGjabxiTt = int(Tl0XoQjyt7WHpZ1kD[RRbvqditj184m3(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨᇙ")])//tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠲࠲࠵࠸᜕")
			loeSiBRfO8K6DkbGzCnpL3FZ += str(H43svmuKOrRD2APk6w51hVGjabxiTt)+i80mE7lHUwVk(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ᇚ")
		if i80mE7lHUwVk(u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫᇛ") in qqefz4pwxlcIZSkm30Cg.lower():
			DYNVS1Bbgs7 = int(Tl0XoQjyt7WHpZ1kD[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬᇜ")].split(mmbcsf2pd7gyjzreB(u"ࠩࡻࠫᇝ"))[jxCVeKSLb9rGDOl0Qtw6])
			loeSiBRfO8K6DkbGzCnpL3FZ += str(DYNVS1Bbgs7)+rBcdwYZInhgO29jtkFAfGxi7
		loeSiBRfO8K6DkbGzCnpL3FZ = loeSiBRfO8K6DkbGzCnpL3FZ.strip(rBcdwYZInhgO29jtkFAfGxi7)
		if not loeSiBRfO8K6DkbGzCnpL3FZ: loeSiBRfO8K6DkbGzCnpL3FZ = ggtuNcvTn3HQ7SpE2(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫᇞ")
		if not SSQHn7pvhlREIWXaOTz.startswith(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫ࡭ࡺࡴࡱࠩᇟ")):
			if SSQHn7pvhlREIWXaOTz.startswith(BarIC3eR9bS(u"ࠬ࠵࠯ࠨᇠ")): SSQHn7pvhlREIWXaOTz = KKFPNRzufO.split(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭࠺ࠨᇡ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧ࠻ࠩᇢ")+SSQHn7pvhlREIWXaOTz
			elif SSQHn7pvhlREIWXaOTz.startswith(MlTVLBZ92kzorIq1Yw(u"ࠨ࠱ࠪᇣ")): SSQHn7pvhlREIWXaOTz = mDR9euKnv4jMSdbEpwcktJz5W6Cf(KKFPNRzufO,NupI74tJCzYXmles9SbR6(u"ࠩࡸࡶࡱ࠭ᇤ"))+SSQHn7pvhlREIWXaOTz
			else: SSQHn7pvhlREIWXaOTz = KKFPNRzufO.rsplit(MlTVLBZ92kzorIq1Yw(u"ࠪ࠳ࠬᇥ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]+OUFxZPuXDoGAbRz(u"ࠫ࠴࠭ᇦ")+SSQHn7pvhlREIWXaOTz
		if ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧᇧ") in list(Tl0XoQjyt7WHpZ1kD.keys()):
			RkntpA1UJDV4vNgyaex6GPWK9YQIcC = Tl0XoQjyt7WHpZ1kD[OUFxZPuXDoGAbRz(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨᇨ")]
			RkntpA1UJDV4vNgyaex6GPWK9YQIcC = RkntpA1UJDV4vNgyaex6GPWK9YQIcC.replace(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࠣࠩᇩ"),gby0BnUuTNFk).replace(YZXtBgvUPoM5sb(u"ࠣࠩࠥᇪ"),gby0BnUuTNFk).split(mmbcsf2pd7gyjzreB(u"ࠩࠦࠫᇫ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
			QZ4YSx75ltrFXDCgA0iGKcqeR = ymlrSBXjxRaY5kcKtU7MTVpAfeJL(RkntpA1UJDV4vNgyaex6GPWK9YQIcC)
			if QZ4YSx75ltrFXDCgA0iGKcqeR: T3Yrx4yZCRqcH = loeSiBRfO8K6DkbGzCnpL3FZ+rBcdwYZInhgO29jtkFAfGxi7+QZ4YSx75ltrFXDCgA0iGKcqeR
			else: T3Yrx4yZCRqcH = loeSiBRfO8K6DkbGzCnpL3FZ
			T3Yrx4yZCRqcH = T3Yrx4yZCRqcH+iiauUxMktNW5X(u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪᇬ")
			T3Yrx4yZCRqcH = T3Yrx4yZCRqcH+rBcdwYZInhgO29jtkFAfGxi7+mDR9euKnv4jMSdbEpwcktJz5W6Cf(RkntpA1UJDV4vNgyaex6GPWK9YQIcC,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡳࡧ࡭ࡦࠩᇭ"))
			uufJivSZQyj45ql3.append(T3Yrx4yZCRqcH)
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(RkntpA1UJDV4vNgyaex6GPWK9YQIcC)
			HxyTDVl2Zb3SaIUw.append(DYNVS1Bbgs7)
			DGoknQZBbEaLY.append(H43svmuKOrRD2APk6w51hVGjabxiTt)
		SSQHn7pvhlREIWXaOTz = SSQHn7pvhlREIWXaOTz.split(iiauUxMktNW5X(u"ࠬࠩࠧᇮ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
		QZ4YSx75ltrFXDCgA0iGKcqeR = ymlrSBXjxRaY5kcKtU7MTVpAfeJL(SSQHn7pvhlREIWXaOTz)
		if QZ4YSx75ltrFXDCgA0iGKcqeR: loeSiBRfO8K6DkbGzCnpL3FZ = loeSiBRfO8K6DkbGzCnpL3FZ+rBcdwYZInhgO29jtkFAfGxi7+QZ4YSx75ltrFXDCgA0iGKcqeR
		loeSiBRfO8K6DkbGzCnpL3FZ = loeSiBRfO8K6DkbGzCnpL3FZ+rBcdwYZInhgO29jtkFAfGxi7+mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSQHn7pvhlREIWXaOTz,NupI74tJCzYXmles9SbR6(u"࠭࡮ࡢ࡯ࡨࠫᇯ"))
		uufJivSZQyj45ql3.append(loeSiBRfO8K6DkbGzCnpL3FZ)
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSQHn7pvhlREIWXaOTz)
		HxyTDVl2Zb3SaIUw.append(DYNVS1Bbgs7)
		DGoknQZBbEaLY.append(H43svmuKOrRD2APk6w51hVGjabxiTt)
	kiSZOPl4rBqWcby7H = list(zip(uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R,HxyTDVl2Zb3SaIUw,DGoknQZBbEaLY))
	kiSZOPl4rBqWcby7H = sorted(kiSZOPl4rBqWcby7H, reverse=w8Ui6RsVhSPrqHfO4, key=lambda key: key[jJ4LEcdl5w7BPMbQ])
	uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R,HxyTDVl2Zb3SaIUw,DGoknQZBbEaLY = list(zip(*kiSZOPl4rBqWcby7H))
	uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R = list(uufJivSZQyj45ql3),list(eE9BXgNu4MPKIbw2aLDl1AY3R)
	cLtYnOqvefJu2KIF6PS5R = []
	for SSQHn7pvhlREIWXaOTz in eE9BXgNu4MPKIbw2aLDl1AY3R: cLtYnOqvefJu2KIF6PS5R.append(SSQHn7pvhlREIWXaOTz+jlHeTn9pz15)
	tf5bMO7qdpr0 = list(zip(cLtYnOqvefJu2KIF6PS5R,[nJF7oflOk6cLGSAey(u"ࠧࡥࡷࡰࡱࡾ࠭ᇰ")]*len(cLtYnOqvefJu2KIF6PS5R),DGoknQZBbEaLY))
	gHuX6TSnqAYcxdwrm2vsBEU9tMG = evjaBmTwVQ(CC3nOPFMovd72u,tf5bMO7qdpr0)
	if gHuX6TSnqAYcxdwrm2vsBEU9tMG:
		SSqweDUBYv4bkO,WDxo5FVQtNn7UaTlq6,H43svmuKOrRD2APk6w51hVGjabxiTt = gHuX6TSnqAYcxdwrm2vsBEU9tMG[i80mE7lHUwVk(u"࠲᜖")]
		index = cLtYnOqvefJu2KIF6PS5R.index(SSqweDUBYv4bkO)
		title = uufJivSZQyj45ql3[index]
		uufJivSZQyj45ql3,cLtYnOqvefJu2KIF6PS5R = [title],[SSqweDUBYv4bkO]
	return uufJivSZQyj45ql3,cLtYnOqvefJu2KIF6PS5R
def ElRUG8zKHm(Xnv4AQJeLGuZOMpDx72oH,o742nplw96aA=gby0BnUuTNFk):
	if not o742nplw96aA: o742nplw96aA = wAcHkmPB8a.DNS_SERVERS[xn867tCVlscY4qbWZfh]
	if Xnv4AQJeLGuZOMpDx72oH.replace(iiauUxMktNW5X(u"ࠨ࠰ࠪᇱ"),gby0BnUuTNFk).isdigit(): return [Xnv4AQJeLGuZOMpDx72oH]
	from struct import pack as qTOViDJ6UvpB2EzsaSnFMoGLmXW1c,unpack_from as EVotQZ8BMjSrNm3fTOPDklcCaqubK
	from socket import socket as RLP7vbMuqwBJNgK0aeIGks65,AF_INET as dNx2OZneM9zpV4vX8bS,SOCK_DGRAM as iiq0jUY7Lw
	try:
		pkuTKUFicgWI5Gyt0JlM = qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠤࡁࡌࠧᇲ"), KJLkQsqSHMR1Np2(u"࠴࠶࠵࠺࠹᜗"))
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(KJLkQsqSHMR1Np2(u"ࠥࡂࡍࠨᇳ"), RRbvqditj184m3(u"࠶࠺࠼᜘"))
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠦࡃࡎࠢᇴ"), jxCVeKSLb9rGDOl0Qtw6)
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡄࡈࠣᇵ"), xn867tCVlscY4qbWZfh)
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨ࠾ࡉࠤᇶ"), xn867tCVlscY4qbWZfh)
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(zDSw8LCxMQyraeXhojIWKmU(u"ࠢ࠿ࡊࠥᇷ"), xn867tCVlscY4qbWZfh)
		if nqkybtoMBH: kPm4YMhblnKypgN = Xnv4AQJeLGuZOMpDx72oH.split(FAwWlRJg0UkN1(u"ࠨ࠰ࠪᇸ"))
		else: kPm4YMhblnKypgN = Xnv4AQJeLGuZOMpDx72oH.decode(JJQFjSIlALchiMzG9).split(iiauUxMktNW5X(u"ࠩ࠱ࠫᇹ"))
		for a5w6quChgWOoQIX in kPm4YMhblnKypgN:
			fygK3musnrWLvadzkl9wbZT07OX = a5w6quChgWOoQIX.encode(JJQFjSIlALchiMzG9)
			pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(ggtuNcvTn3HQ7SpE2(u"ࠥࡆࠧᇺ"), len(a5w6quChgWOoQIX))
			for Vl1TFyIG7CvA4k9SiWRfwU0 in a5w6quChgWOoQIX:
				pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(FAwWlRJg0UkN1(u"ࠦࡨࠨᇻ"), Vl1TFyIG7CvA4k9SiWRfwU0.encode(JJQFjSIlALchiMzG9))
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(NupI74tJCzYXmles9SbR6(u"ࠧࡈࠢᇼ"), xn867tCVlscY4qbWZfh)
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨ࠾ࡉࠤᇽ"), jxCVeKSLb9rGDOl0Qtw6)
		pkuTKUFicgWI5Gyt0JlM += qTOViDJ6UvpB2EzsaSnFMoGLmXW1c(NupI74tJCzYXmles9SbR6(u"ࠢ࠿ࡊࠥᇾ"), jxCVeKSLb9rGDOl0Qtw6)
		ppo8escbBr4nJF70QSvlEzyYHADK = RLP7vbMuqwBJNgK0aeIGks65(dNx2OZneM9zpV4vX8bS,iiq0jUY7Lw)
		ppo8escbBr4nJF70QSvlEzyYHADK.sendto(bytes(pkuTKUFicgWI5Gyt0JlM),(o742nplw96aA,nJF7oflOk6cLGSAey(u"࠺࠹᜙")))
		ppo8escbBr4nJF70QSvlEzyYHADK.settimeout(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠼᜚"))
		jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, uE3AwlKVY6oky4QBW8t = ppo8escbBr4nJF70QSvlEzyYHADK.recvfrom(YZXtBgvUPoM5sb(u"࠱࠱࠴࠷᜛"))
		ppo8escbBr4nJF70QSvlEzyYHADK.close()
		JjVfocaDPxiUEA0rsqY15HL = EVotQZ8BMjSrNm3fTOPDklcCaqubK(nJF7oflOk6cLGSAey(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤᇿ"), jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, xn867tCVlscY4qbWZfh)
		vc2Z9FOEpeiR3zbyJMBWL6woXsgH = JjVfocaDPxiUEA0rsqY15HL[jJ4LEcdl5w7BPMbQ]
		VYhcisPtFDdE = len(Xnv4AQJeLGuZOMpDx72oH)+nJF7oflOk6cLGSAey(u"࠲࠺᜜")
		jSEzXFL5y01pYgdrZUJKulC74Reo = []
		for _pnM1AgGibW in range(vc2Z9FOEpeiR3zbyJMBWL6woXsgH):
			dV32CzJZN7sEYv = VYhcisPtFDdE
			LyTIhGMOF2wz9DiCb0jXBn = jxCVeKSLb9rGDOl0Qtw6
			WW5gDvpYxZl1rym = yrcbRSFswvAfEdIWVj
			while w8Ui6RsVhSPrqHfO4:
				Vl1TFyIG7CvA4k9SiWRfwU0 = EVotQZ8BMjSrNm3fTOPDklcCaqubK(IXE6voNmrb182AyQ(u"ࠤࡁࡆࠧሀ"), jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, dV32CzJZN7sEYv)[xn867tCVlscY4qbWZfh]
				if Vl1TFyIG7CvA4k9SiWRfwU0 == xn867tCVlscY4qbWZfh:
					dV32CzJZN7sEYv += jxCVeKSLb9rGDOl0Qtw6
					break
				if Vl1TFyIG7CvA4k9SiWRfwU0 >= zDSw8LCxMQyraeXhojIWKmU(u"࠳࠼࠶᜝"):
					YSJk3Mme9GzBqPQ7raiA1EwH = EVotQZ8BMjSrNm3fTOPDklcCaqubK(YZXtBgvUPoM5sb(u"ࠥࡂࡇࠨሁ"), jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, dV32CzJZN7sEYv + jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
					dV32CzJZN7sEYv = ((Vl1TFyIG7CvA4k9SiWRfwU0 << uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠻᜞")) + YSJk3Mme9GzBqPQ7raiA1EwH - 0xc000) - jxCVeKSLb9rGDOl0Qtw6
					WW5gDvpYxZl1rym = w8Ui6RsVhSPrqHfO4
				dV32CzJZN7sEYv += jxCVeKSLb9rGDOl0Qtw6
				if WW5gDvpYxZl1rym == yrcbRSFswvAfEdIWVj: LyTIhGMOF2wz9DiCb0jXBn += jxCVeKSLb9rGDOl0Qtw6
			if WW5gDvpYxZl1rym == w8Ui6RsVhSPrqHfO4: LyTIhGMOF2wz9DiCb0jXBn += jxCVeKSLb9rGDOl0Qtw6
			VYhcisPtFDdE = VYhcisPtFDdE + LyTIhGMOF2wz9DiCb0jXBn
			peoEGPwTd5CWQO = EVotQZ8BMjSrNm3fTOPDklcCaqubK(nJF7oflOk6cLGSAey(u"ࠦࡃࡎࡈࡊࡊࠥሂ"), jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, VYhcisPtFDdE)
			VYhcisPtFDdE = VYhcisPtFDdE + NupI74tJCzYXmles9SbR6(u"࠵࠵ᜟ")
			Zy0Ar3l8GP1xNqLfvp47oe52QtW = peoEGPwTd5CWQO[xn867tCVlscY4qbWZfh]
			QQS70GIlKWh4DRm5pUv6OB3nePx8Y = peoEGPwTd5CWQO[jJ4LEcdl5w7BPMbQ]
			if Zy0Ar3l8GP1xNqLfvp47oe52QtW == jxCVeKSLb9rGDOl0Qtw6:
				uCwKZFxR9d0IeWDSJmcBUP = EVotQZ8BMjSrNm3fTOPDklcCaqubK(OUFxZPuXDoGAbRz(u"ࠧࡄࠢሃ")+FAwWlRJg0UkN1(u"ࠨࡂࠣሄ")*QQS70GIlKWh4DRm5pUv6OB3nePx8Y, jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, VYhcisPtFDdE)
				mpJ0w5ZMqU83TuOoxdXbv = gby0BnUuTNFk
				for Vl1TFyIG7CvA4k9SiWRfwU0 in uCwKZFxR9d0IeWDSJmcBUP: mpJ0w5ZMqU83TuOoxdXbv += str(Vl1TFyIG7CvA4k9SiWRfwU0) + i80mE7lHUwVk(u"ࠧ࠯ࠩህ")
				mpJ0w5ZMqU83TuOoxdXbv = mpJ0w5ZMqU83TuOoxdXbv[xn867tCVlscY4qbWZfh:-jxCVeKSLb9rGDOl0Qtw6]
				jSEzXFL5y01pYgdrZUJKulC74Reo.append(mpJ0w5ZMqU83TuOoxdXbv)
			if Zy0Ar3l8GP1xNqLfvp47oe52QtW in [jxCVeKSLb9rGDOl0Qtw6,dNx9DVCtafk4r,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠵ᜢ"),ne7wF4gSTRZo(u"࠷ᜣ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠷࠵ᜡ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠷࠾ᜠ")]: VYhcisPtFDdE = VYhcisPtFDdE + QQS70GIlKWh4DRm5pUv6OB3nePx8Y
	except: jSEzXFL5y01pYgdrZUJKulC74Reo = []
	if not jSEzXFL5y01pYgdrZUJKulC74Reo: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧሆ")+Xnv4AQJeLGuZOMpDx72oH+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࠣࡡࠬሇ"))
	return jSEzXFL5y01pYgdrZUJKulC74Reo
def OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,KKFPNRzufO,Zu5IqlPBEWfSHY,showDialogs=w8Ui6RsVhSPrqHfO4):
	if wAcHkmPB8a.avprivsnorestrict or not Zu5IqlPBEWfSHY: return yrcbRSFswvAfEdIWVj
	DjeoMlRs4Q3B06CNmriEhTw = [zDSw8LCxMQyraeXhojIWKmU(u"ࠪࡥࡩࡻ࡬ࡵࠩለ"),KJLkQsqSHMR1Np2(u"ࠫ࠶࠾ࠫࠨሉ"),iiLyoNwGbH03DIXhAkZn(u"ࠬࡾࡸࠨሊ"),IXE6voNmrb182AyQ(u"࠭ࡰࡰࡴࡱࠫላ"),iiLyoNwGbH03DIXhAkZn(u"ࠧࡴࡧࡻࠫሌ"),NupI74tJCzYXmles9SbR6(u"ࠨࡰࡶࡪࡼ࠭ል"),i80mE7lHUwVk(u"ࠩࡰࡥࡹࡻࡲࡦࠩሎ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪ็ออัࠨሏ"),mmbcsf2pd7gyjzreB(u"ࠫออไ฻ࠩሐ"),iI7tuF0nEQoR(u"ࠬอศศฯํࠫሑ"),nJF7oflOk6cLGSAey(u"࠭ฬ็ีࠪሒ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠧๆ็้์฾࠭ሓ")]
	if CC3nOPFMovd72u!=nJF7oflOk6cLGSAey(u"ࠨࡄࡒࡏࡗࡇࠧሔ"): DjeoMlRs4Q3B06CNmriEhTw += [FAwWlRJg0UkN1(u"ࠩࡵ࠾ࠬሕ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪ࠾ࡷ࠭ሖ"),iiauUxMktNW5X(u"ࠫࡷ࠳ࠧሗ"),i80mE7lHUwVk(u"ࠬ࠳ࡲࠨመ"),IXE6voNmrb182AyQ(u"࠭࠭࡮ࡣࠪሙ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧ࡮ࡣ࠰ࠫሚ")]
	for AnPViDKlOpB0 in Zu5IqlPBEWfSHY:
		AnPViDKlOpB0 = AnPViDKlOpB0.lower()
		if n6JjFHfmydIaLut(u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪማ") in AnPViDKlOpB0: continue
		if GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩࡱࡳࡹࠦࡲࡢࡶࡨࡨࠬሜ") in AnPViDKlOpB0: continue
		if iiLyoNwGbH03DIXhAkZn(u"ࠪࡹࡳࡸࡡࡵࡧࡧࠫም") in AnPViDKlOpB0: continue
		if n6JjFHfmydIaLut(u"ࠫา๊โสࠩሞ") in AnPViDKlOpB0: continue
		if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬเ๊าู่๋ࠢ็ࠧሟ") in AnPViDKlOpB0: continue
		AnPViDKlOpB0 = AnPViDKlOpB0.replace(n6JjFHfmydIaLut(u"࠭รࠨሠ"),i80mE7lHUwVk(u"ࠧศࠩሡ")).replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨวࠪሢ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩสࠫሣ")).replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪฦࠬሤ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫฬ࠭ሥ")).replace(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ๔ࠧሦ"),gby0BnUuTNFk).replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"๋࠭ࠨሧ"),gby0BnUuTNFk)
		AnPViDKlOpB0 = AnPViDKlOpB0.replace(NupI74tJCzYXmles9SbR6(u"ࠧ๐ࠩረ"),gby0BnUuTNFk).replace(n6JjFHfmydIaLut(u"ࠨ๒ࠪሩ"),gby0BnUuTNFk).replace(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ๐ࠫሪ"),gby0BnUuTNFk).replace(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪ๕ࠬራ"),gby0BnUuTNFk)
		AnPViDKlOpB0 = AnPViDKlOpB0.replace(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫๅ࠭ሬ"),gby0BnUuTNFk).replace(VzO1gCHmjZ2ebRIL(u"ࠬࡀࠧር"),gby0BnUuTNFk)
		if cAIRPFK6boejVU549WzqBGCaJ0r: AnPViDKlOpB0 = AnPViDKlOpB0.decode(JJQFjSIlALchiMzG9).encode(JJQFjSIlALchiMzG9)
		WW3BUGb7EorwsdACJMz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iiLyoNwGbH03DIXhAkZn(u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪሮ"),AnPViDKlOpB0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		DL6OV8lPzxB2Jyu7pfGCtQ = yrcbRSFswvAfEdIWVj
		for VWRxNmzbOJFdZa in WW3BUGb7EorwsdACJMz:
			if len(VWRxNmzbOJFdZa)==dNx9DVCtafk4r:
				DL6OV8lPzxB2Jyu7pfGCtQ = w8Ui6RsVhSPrqHfO4
				break
		if AnPViDKlOpB0 in [RRbvqditj184m3(u"ࠧࡳࠩሯ")] or DL6OV8lPzxB2Jyu7pfGCtQ or any(value in AnPViDKlOpB0 for value in DjeoMlRs4Q3B06CNmriEhTw):
			SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࠢࠣࠤࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡧࡤࡶ࡮ࡷࡷࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦ࠮࠯࠰࠱࠲ࠥࡣࠧሰ"))
			if showDialogs: RLfOB3nsqaWXTugJvY(e1nNXbPrBVDZw,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫሱ"))
			return w8Ui6RsVhSPrqHfO4
	return yrcbRSFswvAfEdIWVj
def Zc6lYG3a02XVPA1WLr(xlPEj8hV17Z=w8Ui6RsVhSPrqHfO4):
	if xlPEj8hV17Z:
		E9LlzOuYdp20rKcn13BUqDGsh8StIQ = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,ne7wF4gSTRZo(u"ࠪࡷࡹࡸࠧሲ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩሳ"),nJF7oflOk6cLGSAey(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨሴ"))
		if E9LlzOuYdp20rKcn13BUqDGsh8StIQ: return E9LlzOuYdp20rKcn13BUqDGsh8StIQ
	czrd0xT7BIl6noGC29w = gby0BnUuTNFk
	if xn867tCVlscY4qbWZfh and tKObfFRod18ZU.succeeded:
		cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
		ZZYB0cKL9nkA1dxaovh58HztwS = cHuIdQiPshK8mwFUlkADGLv42fpeR.count(KJLkQsqSHMR1Np2(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧስ"))
		if ZZYB0cKL9nkA1dxaovh58HztwS>mmbcsf2pd7gyjzreB(u"࠺࠳ᜤ"):
			czrd0xT7BIl6noGC29w = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(i80mE7lHUwVk(u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩሶ"),cHuIdQiPshK8mwFUlkADGLv42fpeR,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w[xn867tCVlscY4qbWZfh]
	if not czrd0xT7BIl6noGC29w:
		hu5peSZxkMEyLRjrqItXnJ1 = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,iiauUxMktNW5X(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧሷ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶࠪሸ"))
		czrd0xT7BIl6noGC29w = open(hu5peSZxkMEyLRjrqItXnJ1,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡶࡧ࠭ሹ")).read()
		if nqkybtoMBH: czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w.decode(JJQFjSIlALchiMzG9)
		czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w.replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk)
	ugDcRJFEBW16Q7H = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫ࠭ࡓ࡯ࡻ࡫࡯ࡰࡦ࠴ࠪࡀࠫ࡟ࡲࠬሺ"),czrd0xT7BIl6noGC29w,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Mc9oVThfzEa = []
	for qqefz4pwxlcIZSkm30Cg in ugDcRJFEBW16Q7H:
		JLfb1oFgYrCzwD = qqefz4pwxlcIZSkm30Cg.lower()
		if tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭ሻ") in JLfb1oFgYrCzwD: continue
		if Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࡵࡣࡷࡱࡸࡺ࠭ሼ") in JLfb1oFgYrCzwD: continue
		if VzO1gCHmjZ2ebRIL(u"ࠧࡪࡲ࡫ࡳࡳ࡫ࠧሽ") in JLfb1oFgYrCzwD: continue
		if iiLyoNwGbH03DIXhAkZn(u"ࠨࡥࡵࡳࡸ࠭ሾ") in JLfb1oFgYrCzwD: continue
		Mc9oVThfzEa.append(qqefz4pwxlcIZSkm30Cg)
	E9LlzOuYdp20rKcn13BUqDGsh8StIQ = l8YH46ObxQJTk1.sample(Mc9oVThfzEa,jxCVeKSLb9rGDOl0Qtw6)
	E9LlzOuYdp20rKcn13BUqDGsh8StIQ = E9LlzOuYdp20rKcn13BUqDGsh8StIQ[xn867tCVlscY4qbWZfh]
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,n6JjFHfmydIaLut(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧሿ"),NupI74tJCzYXmles9SbR6(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭ቀ"),E9LlzOuYdp20rKcn13BUqDGsh8StIQ,DNh1dgpa4BK)
	return E9LlzOuYdp20rKcn13BUqDGsh8StIQ
def xTdl05McQ1krVim4nFPzfReg32Yh(fSqpV0sUvcr153IYbT9lKezQRE7=gby0BnUuTNFk):
	if wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX==yrcbRSFswvAfEdIWVj: return
	if not fSqpV0sUvcr153IYbT9lKezQRE7: fSqpV0sUvcr153IYbT9lKezQRE7 = WhjmDeqacBg.format_exc()
	if sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡘࡿࡳࡵࡧࡰࡉࡽ࡯ࡴࠨቁ") in fSqpV0sUvcr153IYbT9lKezQRE7 or FAwWlRJg0UkN1(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨቂ") in fSqpV0sUvcr153IYbT9lKezQRE7: return
	if fSqpV0sUvcr153IYbT9lKezQRE7!=lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩቃ"): Pt41K3suxDF9nE0wLvU7dGq2ceNT.stderr.write(fSqpV0sUvcr153IYbT9lKezQRE7)
	pphu4kvVyHtj7 = fSqpV0sUvcr153IYbT9lKezQRE7.splitlines()
	xNE4SpiDJq6Cw8l = pphu4kvVyHtj7[-q2qPkMFpR1G86dEAKXHivor9N(u"࠴ᜥ")]
	FfhmcMU0ISOjt61VbnqZK9XQCHB = open(gO3wqNsBZFrc2Epi1T0ALDb6WUK5,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡳࡤࠪቄ")).read()
	if nqkybtoMBH: FfhmcMU0ISOjt61VbnqZK9XQCHB = FfhmcMU0ISOjt61VbnqZK9XQCHB.decode(JJQFjSIlALchiMzG9)
	FfhmcMU0ISOjt61VbnqZK9XQCHB = FfhmcMU0ISOjt61VbnqZK9XQCHB[-zDSw8LCxMQyraeXhojIWKmU(u"࠼࠵࠶࠰ᜦ"):]
	hvoMKNipYI16GgRlOQ3ZEA8UTWek = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ࠿ࠪቅ")*Ducd5PRjQXaB9SIN7VrJ1G(u"࠶࠶࠰ᜧ")
	if hvoMKNipYI16GgRlOQ3ZEA8UTWek in FfhmcMU0ISOjt61VbnqZK9XQCHB: FfhmcMU0ISOjt61VbnqZK9XQCHB = FfhmcMU0ISOjt61VbnqZK9XQCHB.rsplit(hvoMKNipYI16GgRlOQ3ZEA8UTWek,jxCVeKSLb9rGDOl0Qtw6)[jxCVeKSLb9rGDOl0Qtw6]
	if xNE4SpiDJq6Cw8l in FfhmcMU0ISOjt61VbnqZK9XQCHB: FfhmcMU0ISOjt61VbnqZK9XQCHB = FfhmcMU0ISOjt61VbnqZK9XQCHB.rsplit(xNE4SpiDJq6Cw8l,jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
	ifTOXc6U2l90Np7au = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(ne7wF4gSTRZo(u"ࠩࠫࡗࡴࡻࡲࡤࡧࡿࡑࡴࡪࡥࠪ࠼ࠣࡠࡠࠦࠨ࠯ࠬࡂ࠭ࠥࡢ࡝ࠨቆ"),FfhmcMU0ISOjt61VbnqZK9XQCHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for IIEsJOmZGenK2LjNla58uk,bTh6JaVi1mOoCEeKZ4kS8AWsnl in reversed(ifTOXc6U2l90Np7au):
		if bTh6JaVi1mOoCEeKZ4kS8AWsnl: break
	else: bTh6JaVi1mOoCEeKZ4kS8AWsnl = OUFxZPuXDoGAbRz(u"ࠪࡒࡔ࡚ࠠࡔࡒࡈࡇࡎࡌࡉࡆࡆࠪቇ")
	APkujXVWbdt6p98Y,qqefz4pwxlcIZSkm30Cg,DCkeJxfrmnobTVHhWjs96OwU = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	yJobwEBGVLq = OUFxZPuXDoGAbRz(u"ࠫࡠࡘࡔࡍ࡟ࠪቈ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬอไฯูฦ࠾ࠥࠦࠧ቉")+GGy0cQe765nPYZ9E8Th+xNE4SpiDJq6Cw8l
	EzcSMyRpkv = iiLyoNwGbH03DIXhAkZn(u"࡛࠭ࡓࡖࡏࡡࠬቊ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+q2qPkMFpR1G86dEAKXHivor9N(u"ࠧศๆู่ิื࠺ࠡࠢࠪቋ")+GGy0cQe765nPYZ9E8Th+bTh6JaVi1mOoCEeKZ4kS8AWsnl
	for DLiEF5JqfuPYe8n4xo1 in reversed(pphu4kvVyHtj7):
		if i80mE7lHUwVk(u"ࠨࡈ࡬ࡰࡪࠦࠢࠨቌ") in DLiEF5JqfuPYe8n4xo1 and YZXtBgvUPoM5sb(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨቍ") in DLiEF5JqfuPYe8n4xo1: break
	DLiEF5JqfuPYe8n4xo1 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࠩࠣ࡞࠯ࠤࡱ࡯࡮ࡦࠢࠫ࠲࠯ࡅࠩ࡝࠮ࠣ࡭ࡳࠦࠨ࠯ࠬࡂ࠭ࠩ࠭቎"),DLiEF5JqfuPYe8n4xo1,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if DLiEF5JqfuPYe8n4xo1:
		APkujXVWbdt6p98Y,qqefz4pwxlcIZSkm30Cg,DCkeJxfrmnobTVHhWjs96OwU = DLiEF5JqfuPYe8n4xo1[xn867tCVlscY4qbWZfh]
		if tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫ࠴࠭቏") in APkujXVWbdt6p98Y: APkujXVWbdt6p98Y = APkujXVWbdt6p98Y.rsplit(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬ࠵ࠧቐ"),jxCVeKSLb9rGDOl0Qtw6)[jxCVeKSLb9rGDOl0Qtw6]
		else: APkujXVWbdt6p98Y = APkujXVWbdt6p98Y.rsplit(DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭࡜࡝ࠩቑ"),jxCVeKSLb9rGDOl0Qtw6)[jxCVeKSLb9rGDOl0Qtw6]
		OOpS2wAQ6ldUr4RhoEvY1c8aeCt = nJF7oflOk6cLGSAey(u"ࠧ࡜ࡔࡗࡐࡢ࠭ቒ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨษ็้้็࠺ࠡࠢࠪቓ")+GGy0cQe765nPYZ9E8Th+APkujXVWbdt6p98Y
		rZszBy9Dxq3kmhSNboJUl = MlTVLBZ92kzorIq1Yw(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨቔ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+OUFxZPuXDoGAbRz(u"ࠪหู้ืา࠼ࠣࠤࠬቕ")+GGy0cQe765nPYZ9E8Th+qqefz4pwxlcIZSkm30Cg
		g9fmWywaBbzjeL5GucY = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡠࡘࡔࡍ࡟ࠪቖ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+ggtuNcvTn3HQ7SpE2(u"ࠬอไๆๅส๊࠿ࠦࠠࠨ቗")+GGy0cQe765nPYZ9E8Th+DCkeJxfrmnobTVHhWjs96OwU
		FK0w67VIALyWjOx3DXgTtvBh1s5pE = OOpS2wAQ6ldUr4RhoEvY1c8aeCt+okfdjS4RmM+rZszBy9Dxq3kmhSNboJUl+okfdjS4RmM+g9fmWywaBbzjeL5GucY+okfdjS4RmM+EzcSMyRpkv+okfdjS4RmM+yJobwEBGVLq
		RbFQAUoi0xOKl = rZszBy9Dxq3kmhSNboJUl+okfdjS4RmM+EzcSMyRpkv+okfdjS4RmM+yJobwEBGVLq+okfdjS4RmM+OOpS2wAQ6ldUr4RhoEvY1c8aeCt+okfdjS4RmM+g9fmWywaBbzjeL5GucY
		RFfNJaWQACk5Bt = rZszBy9Dxq3kmhSNboJUl+okfdjS4RmM+yJobwEBGVLq+okfdjS4RmM+OOpS2wAQ6ldUr4RhoEvY1c8aeCt+okfdjS4RmM+g9fmWywaBbzjeL5GucY
	else:
		OOpS2wAQ6ldUr4RhoEvY1c8aeCt,rZszBy9Dxq3kmhSNboJUl,g9fmWywaBbzjeL5GucY = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
		FK0w67VIALyWjOx3DXgTtvBh1s5pE = EzcSMyRpkv+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭࡜࡯࡞ࡱࠫቘ")+yJobwEBGVLq
		RbFQAUoi0xOKl = EzcSMyRpkv+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧ࡝ࡰ࡟ࡲࠬ቙")+yJobwEBGVLq
		RFfNJaWQACk5Bt = yJobwEBGVLq
	jj9SkJUdsgT1LuE2nZIiYtAmWc = zDSw8LCxMQyraeXhojIWKmU(u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬቚ")+okfdjS4RmM
	wvrjPdXcWh7Auie1spJEVGo = GOqi5wrzF6nBV2yAkQtEp()
	bbqGcUZolEOMp = []
	WjryKiBebavP = wvrjPdXcWh7Auie1spJEVGo[uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧቛ")]
	kIByqV0NwLxa9H = NNLyWfbPqkGF5jBxp46oJ(eQNGiXdboqPt57O)
	if lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨቜ") in list(wvrjPdXcWh7Auie1spJEVGo.keys()):
		for PDTqn9RuQBJ7KlaS4wk3yMpEZHOj,vv0dEak2swXFT8OZMIz,HkiCpxGYayqz5w in WjryKiBebavP:
			bbqGcUZolEOMp = max(bbqGcUZolEOMp,vv0dEak2swXFT8OZMIz)
		if kIByqV0NwLxa9H<bbqGcUZolEOMp:
			tuzf5ToNUESqid4PIOMjR8KC = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫ็๋ࠠษฬะำ๏ัࠠศๆหี๋อๅอࠢๅฬ้ࠦลาีส่ࠥอไฤะฺหฦࠦไๅ็หี๊าࠧቝ")
			QA7oZDp3bUzwFde5ymVf = yc8Ph4rFsCIvQbOA(IXE6voNmrb182AyQ(u"ࠬࡸࡩࡨࡪࡷࠫ቞"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ቟"),VzO1gCHmjZ2ebRIL(u"ࠧหฯา๎ะ࠭በ"),FAwWlRJg0UkN1(u"ࠨะิ์ั࠭ቡ"),jj9SkJUdsgT1LuE2nZIiYtAmWc+tuzf5ToNUESqid4PIOMjR8KC,FK0w67VIALyWjOx3DXgTtvBh1s5pE)
			if QA7oZDp3bUzwFde5ymVf==jxCVeKSLb9rGDOl0Qtw6:
				import BktdqIvga8
				BktdqIvga8.TAFLUzpWg63Rf(w8Ui6RsVhSPrqHfO4)
				cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
			elif QA7oZDp3bUzwFde5ymVf==dNx9DVCtafk4r: cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	Hk21WitgzMsdbQIUKmCe = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩ࡯࡭ࡸࡺࠧቢ"),OUFxZPuXDoGAbRz(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ባ"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭ቤ"))
	if not Hk21WitgzMsdbQIUKmCe: Hk21WitgzMsdbQIUKmCe = []
	RbFQAUoi0xOKl = RbFQAUoi0xOKl.replace(okfdjS4RmM,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡢ࡜࡯ࠩብ")).replace(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࡛࠭ࡓࡖࡏࡡࠬቦ"),gby0BnUuTNFk).replace(bKN9diGf8nmgecQPEqUzHRpoDuaO,gby0BnUuTNFk).replace(GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk)
	RFfNJaWQACk5Bt = RFfNJaWQACk5Bt.replace(okfdjS4RmM,BarIC3eR9bS(u"ࠧ࡝࡞ࡱࠫቧ")).replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࡝ࡕࡘࡑࡣࠧቨ"),gby0BnUuTNFk).replace(bKN9diGf8nmgecQPEqUzHRpoDuaO,gby0BnUuTNFk).replace(GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk)
	m2mo56aT8Kh = eQNGiXdboqPt57O+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࠽࠾ࠬቩ")+RFfNJaWQACk5Bt
	if m2mo56aT8Kh in Hk21WitgzMsdbQIUKmCe:
		tuzf5ToNUESqid4PIOMjR8KC = sqcK91hDCiHbPG52vfdLFaMy83nA(u"่ࠪ็ีࠠใ็อࠤฬ์สࠡีสฬ็อࠠษวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨቪ")
		tt3DVu1TU8dLAi(FAwWlRJg0UkN1(u"ࠫࡷ࡯ࡧࡩࡶࠪቫ"),gby0BnUuTNFk,jj9SkJUdsgT1LuE2nZIiYtAmWc+tuzf5ToNUESqid4PIOMjR8KC,FK0w67VIALyWjOx3DXgTtvBh1s5pE)
		return
	t05djVSiOhJbqansulQ7 = str(h4ETRzHBcxIbW).split(zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࠴ࠧቬ"))[xn867tCVlscY4qbWZfh]
	KKFPNRzufO = wAcHkmPB8a.SITESURLS[zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ቭ")][YZXtBgvUPoM5sb(u"࠼ᜨ")]
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࡑࡑࡖࡘࠬቮ"),KKFPNRzufO,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗ࠲࠷ࡳࡵࠩቯ"),yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
	yyKhEpGWxkBRNjtfdu = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(RRbvqditj184m3(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࡆࡐࡇ࠾࠿ࡋࡎࡅࠩተ"),cHuIdQiPshK8mwFUlkADGLv42fpeR,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for kVSrf6wvgbxU70MXTpACIZW9H15e,lw9RhHgJpPcZ,GB9W5xCqDKJjIfwMRiAdv2ZN6Ule,ifSpTdCRZXBe0jv5AL6cKhFbg in yyKhEpGWxkBRNjtfdu:
		kVSrf6wvgbxU70MXTpACIZW9H15e = kVSrf6wvgbxU70MXTpACIZW9H15e.split(VzO1gCHmjZ2ebRIL(u"ࠪ࠯ࠬቱ"))
		GB9W5xCqDKJjIfwMRiAdv2ZN6Ule = GB9W5xCqDKJjIfwMRiAdv2ZN6Ule.split(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫ࠰࠭ቲ"))
		ifSpTdCRZXBe0jv5AL6cKhFbg = ifSpTdCRZXBe0jv5AL6cKhFbg.split(iI7tuF0nEQoR(u"ࠬ࠱ࠧታ"))
		if qqefz4pwxlcIZSkm30Cg in kVSrf6wvgbxU70MXTpACIZW9H15e and xNE4SpiDJq6Cw8l==lw9RhHgJpPcZ and eQNGiXdboqPt57O in GB9W5xCqDKJjIfwMRiAdv2ZN6Ule and t05djVSiOhJbqansulQ7 in ifSpTdCRZXBe0jv5AL6cKhFbg:
			tuzf5ToNUESqid4PIOMjR8KC = VzO1gCHmjZ2ebRIL(u"࠭็ัษࠣห้ิืฤ่ࠢ฽ึ๎แ๊ࠡึ๎฾อไอࠢหห้หีะษิࠤฬ๊โศั่ࠫቴ")
			PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ት"),VzO1gCHmjZ2ebRIL(u"ࠨะิ์ั࠭ቶ"),BarIC3eR9bS(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ቷ"),jj9SkJUdsgT1LuE2nZIiYtAmWc+tuzf5ToNUESqid4PIOMjR8KC,FK0w67VIALyWjOx3DXgTtvBh1s5pE)
			if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6: tt3DVu1TU8dLAi(MlTVLBZ92kzorIq1Yw(u"ࠪࡧࡪࡴࡴࡦࡴࠪቸ"),gby0BnUuTNFk,gby0BnUuTNFk,tuzf5ToNUESqid4PIOMjR8KC)
			return
	tuzf5ToNUESqid4PIOMjR8KC = BarIC3eR9bS(u"ࠫฬ๊ัอษฤࠤสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫቹ")
	choice = yc8Ph4rFsCIvQbOA(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡸࡩࡨࡪࡷࠫቺ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪቻ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧหฯา๎ะࠦฬำศํࠫቼ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠨฬะำ๏ัࠠศๆหี๋อๅอࠩች"),jj9SkJUdsgT1LuE2nZIiYtAmWc+tuzf5ToNUESqid4PIOMjR8KC,FK0w67VIALyWjOx3DXgTtvBh1s5pE)
	if choice==jxCVeKSLb9rGDOl0Qtw6:
		Ci4do9lZhuSczJ(yrcbRSFswvAfEdIWVj)
		RLfOB3nsqaWXTugJvY(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"้ࠩะาะฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠠศๆฯึห๐ࠧቾ"),iiLyoNwGbH03DIXhAkZn(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫቿ"),RyfYSek61do5OnQMc=uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠷࠶࠲ᜩ"))
		cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	elif choice==dNx9DVCtafk4r:
		import BktdqIvga8
		BktdqIvga8.TAFLUzpWg63Rf(w8Ui6RsVhSPrqHfO4)
		cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(n6JjFHfmydIaLut(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫኀ"),gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,zDSw8LCxMQyraeXhojIWKmU(u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭ኁ"))
	if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6: OsWlX1aE9Yg = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩኂ")
	else:
		tt3DVu1TU8dLAi(ggtuNcvTn3HQ7SpE2(u"ࠧࡤࡧࡱࡸࡪࡸࠧኃ"),gby0BnUuTNFk,e1nNXbPrBVDZw,bKN9diGf8nmgecQPEqUzHRpoDuaO+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽รࠨኄ")+GGy0cQe765nPYZ9E8Th+MlTVLBZ92kzorIq1Yw(u"ࠩ࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬኅ"))
		return
	yl4wARgr1beKpxXCfVZkNTJGDnhz = RbFQAUoi0xOKl
	import BktdqIvga8
	GGinQY9gb7uy8VeIrxH5 = BktdqIvga8.vsXN6oYheWk4r(RRbvqditj184m3(u"ࠪࡉࡷࡸ࡯ࡳࡵࠪኆ"),yl4wARgr1beKpxXCfVZkNTJGDnhz,w8Ui6RsVhSPrqHfO4,gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫኇ"),OsWlX1aE9Yg)
	if GGinQY9gb7uy8VeIrxH5 and OsWlX1aE9Yg:
		Hk21WitgzMsdbQIUKmCe.append(m2mo56aT8Kh)
		CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨኈ"),Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ኉"),Hk21WitgzMsdbQIUKmCe,Z83rChqtg1oXUjI4YL)
	return
def E7Esu23YHzndlkAxFi(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,filename=D0DRCGqknfT2tKPY6N):
	RyfYSek61do5OnQMc.sleep(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠱࠰࠳࠶࠺ᜪ"))
	jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk.encode(JJQFjSIlALchiMzG9) if (nqkybtoMBH and isinstance(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, str)) or (not nqkybtoMBH and isinstance(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk, unicode)) else str(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk)
	if not filename: eGqj6NWXtO8Mogcu3yrwlRUbS9kh = FAwWlRJg0UkN1(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧኊ")+str(RyfYSek61do5OnQMc.time())+q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࠰ࡧࡥࡹ࠭ኋ")
	else: eGqj6NWXtO8Mogcu3yrwlRUbS9kh = FAwWlRJg0UkN1(u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤࡠࠩኌ")+filename+i80mE7lHUwVk(u"ࠪ࠲ࡩࡧࡴࠨኍ")
	open(eGqj6NWXtO8Mogcu3yrwlRUbS9kh,zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡼࡨࠧ኎")).write(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk)
	return
def LzVS3hOHQ6yfWtquRnbeC7l(EyaNdiZUtzq2rMulW9JL1ITHP3fgC):
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC:
		RRFCDEHdLj = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,ggtuNcvTn3HQ7SpE2(u"ࠬࡲࡩࡴࡶࠪ኏"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫነ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪኑ"))
		if RRFCDEHdLj: return RRFCDEHdLj
	KKFPNRzufO = wAcHkmPB8a.SITESURLS[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨኒ")][q2qPkMFpR1G86dEAKXHivor9N(u"࠷ᜫ")]
	k2EpeoX7YHr = eaSX4yMEPVYHDIAJ(yrcbRSFswvAfEdIWVj) if not EyaNdiZUtzq2rMulW9JL1ITHP3fgC else wAcHkmPB8a.AV_CLIENT_IDS
	JKTRUIfhmnSApPD5cr = mJNpiuFnh2GqT()
	qqXs9KORkeyc = JKTRUIfhmnSApPD5cr.split(BarIC3eR9bS(u"ࠩ࠯࠰ࠬና"))[dNx9DVCtafk4r]
	o0WAEei5KqwlRpPHZfmYUDyj6h = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,OUFxZPuXDoGAbRz(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩኔ"))
	CU3fjutQVEg7eavn9r5kWD0NB46GSp = zwDxtdB8C3LA()
	DI1M026yiGjnZXhTc58 = {RRbvqditj184m3(u"ࠫࡺࡹࡥࡳࠩን"):k2EpeoX7YHr,nJF7oflOk6cLGSAey(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ኖ"):eQNGiXdboqPt57O,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧኗ"):qqXs9KORkeyc,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡪࡦࡶࠫኘ"):DhxNVwJ7EQULzCK8acfiPZkM20sYg(CU3fjutQVEg7eavn9r5kWD0NB46GSp)}
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡒࡒࡗ࡙࠭ኙ"),KKFPNRzufO,DI1M026yiGjnZXhTc58,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,BarIC3eR9bS(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧኚ"))
	RRFCDEHdLj = []
	if tKObfFRod18ZU.succeeded:
		cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
		RRFCDEHdLj = cHuIdQiPshK8mwFUlkADGLv42fpeR.replace(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡠࡡࡸࠧኛ"),okfdjS4RmM).replace(TeYukOUW7i5NBM926DCjaAn0(u"ࠫࡡࡢ࡮ࠨኜ"),okfdjS4RmM).replace(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡢࡲ࡝ࡰࠪኝ"),okfdjS4RmM).replace(Hd14YjcWpvPhN8sZXK3,okfdjS4RmM)
		RRFCDEHdLj = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩኞ"),RRFCDEHdLj,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if RRFCDEHdLj:
			RRFCDEHdLj = sorted(RRFCDEHdLj,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: int(key[xn867tCVlscY4qbWZfh]))
			JJ4wRxzq6WNrabTVlSyE,k2EpeoX7YHr,IqrdX3A6BVkeFhpgu5nWbPf,jSEzXFL5y01pYgdrZUJKulC74Reo,l0lLk63Fj5YqivAJIuB,PJnMHzOorxmLAwc = RRFCDEHdLj[xn867tCVlscY4qbWZfh]
			ddpf5Po4ulMhVXaqZK = PJnMHzOorxmLAwc if wAcHkmPB8a.avprivslongperiod else IqrdX3A6BVkeFhpgu5nWbPf
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩኟ"),ddpf5Po4ulMhVXaqZK)
			CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭አ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬኡ"),RRFCDEHdLj,DNh1dgpa4BK)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(i80mE7lHUwVk(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬኢ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
	return RRFCDEHdLj
def Zdw6qDQULYRG(pYNRI5bDO2zFkejHSoqB7,lELT75ZHBnX=xn867tCVlscY4qbWZfh,Tm1yNIw9L0xA=xn867tCVlscY4qbWZfh):
	if lELT75ZHBnX and not Tm1yNIw9L0xA: Tm1yNIw9L0xA = len(pYNRI5bDO2zFkejHSoqB7)//lELT75ZHBnX
	O0fudRPt8KGBAS5I1nchlEmsqHr,t3t986iTduqY,W09UxYnrV5Jk3wfM84DzaC6PFIOKy = [],-jxCVeKSLb9rGDOl0Qtw6,xn867tCVlscY4qbWZfh
	for AvDtLJr2PUKNG0uanEMI in pYNRI5bDO2zFkejHSoqB7:
		if W09UxYnrV5Jk3wfM84DzaC6PFIOKy%Tm1yNIw9L0xA==xn867tCVlscY4qbWZfh:
			t3t986iTduqY += jxCVeKSLb9rGDOl0Qtw6
			O0fudRPt8KGBAS5I1nchlEmsqHr.append([])
		O0fudRPt8KGBAS5I1nchlEmsqHr[t3t986iTduqY].append(AvDtLJr2PUKNG0uanEMI)
		W09UxYnrV5Jk3wfM84DzaC6PFIOKy += jxCVeKSLb9rGDOl0Qtw6
	return O0fudRPt8KGBAS5I1nchlEmsqHr
def GrHZTXnek6o4Yv79pubLxIR(eGqj6NWXtO8Mogcu3yrwlRUbS9kh,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk):
	DlBXgmHAu0T9ydiajxqZnG64PS = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,eGqj6NWXtO8Mogcu3yrwlRUbS9kh)
	if jxCVeKSLb9rGDOl0Qtw6 or NupI74tJCzYXmles9SbR6(u"ࠫࡎࡖࡔࡗࡡࠪኣ") not in eGqj6NWXtO8Mogcu3yrwlRUbS9kh or VzO1gCHmjZ2ebRIL(u"ࠬࡓ࠳ࡖࡡࠪኤ") not in eGqj6NWXtO8Mogcu3yrwlRUbS9kh: czrd0xT7BIl6noGC29w = str(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk)
	else:
		O0fudRPt8KGBAS5I1nchlEmsqHr = Zdw6qDQULYRG(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,NupI74tJCzYXmles9SbR6(u"࠻ᜬ"))
		czrd0xT7BIl6noGC29w = gby0BnUuTNFk
		for G0xnTY9kLXdN7VwzCSjiZg in O0fudRPt8KGBAS5I1nchlEmsqHr:
			czrd0xT7BIl6noGC29w += str(G0xnTY9kLXdN7VwzCSjiZg)+mmbcsf2pd7gyjzreB(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬእ")
		czrd0xT7BIl6noGC29w = czrd0xT7BIl6noGC29w.strip(zDSw8LCxMQyraeXhojIWKmU(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ኦ"))
	RRyc2MjgSO5vZdfz96XWtknAeCLH = VjvOwLtso6AIH7ClEWUdmSkPyM5.compress(czrd0xT7BIl6noGC29w)
	open(DlBXgmHAu0T9ydiajxqZnG64PS,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡹࡥࠫኧ")).write(RRyc2MjgSO5vZdfz96XWtknAeCLH)
	return
def iDX8cLh9UCVg0Tn4F6QmS3W(OgCN3TRxulWXwMQ,eGqj6NWXtO8Mogcu3yrwlRUbS9kh):
	if OgCN3TRxulWXwMQ==YZXtBgvUPoM5sb(u"ࠩࡧ࡭ࡨࡺࠧከ"): jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = {}
	elif OgCN3TRxulWXwMQ==q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡰ࡮ࡹࡴࠨኩ"): jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = []
	elif OgCN3TRxulWXwMQ==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡸࡺࡲࠨኪ"): jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = gby0BnUuTNFk
	elif OgCN3TRxulWXwMQ==NupI74tJCzYXmles9SbR6(u"ࠬ࡯࡮ࡵࠩካ"): jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = xn867tCVlscY4qbWZfh
	else: jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = D0DRCGqknfT2tKPY6N
	DlBXgmHAu0T9ydiajxqZnG64PS = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,eGqj6NWXtO8Mogcu3yrwlRUbS9kh)
	RRyc2MjgSO5vZdfz96XWtknAeCLH = open(DlBXgmHAu0T9ydiajxqZnG64PS,YZXtBgvUPoM5sb(u"࠭ࡲࡣࠩኬ")).read()
	czrd0xT7BIl6noGC29w = VjvOwLtso6AIH7ClEWUdmSkPyM5.decompress(RRyc2MjgSO5vZdfz96XWtknAeCLH)
	if tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ክ") not in czrd0xT7BIl6noGC29w: jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = eval(czrd0xT7BIl6noGC29w)
	else:
		O0fudRPt8KGBAS5I1nchlEmsqHr = czrd0xT7BIl6noGC29w.split(NupI74tJCzYXmles9SbR6(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧኮ"))
		del czrd0xT7BIl6noGC29w
		jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = []
		KPNcFH6zYnWlisuXpe7aRBfO = N3fAtRaD2wzZ7quOsHU0VMK1SbXeLc()
		JJ4wRxzq6WNrabTVlSyE = xn867tCVlscY4qbWZfh
		for G0xnTY9kLXdN7VwzCSjiZg in O0fudRPt8KGBAS5I1nchlEmsqHr:
			KPNcFH6zYnWlisuXpe7aRBfO.SPCcrbm56KYaRNuTnzwgl8VtLd(str(JJ4wRxzq6WNrabTVlSyE),eval,G0xnTY9kLXdN7VwzCSjiZg)
			JJ4wRxzq6WNrabTVlSyE += jxCVeKSLb9rGDOl0Qtw6
		del O0fudRPt8KGBAS5I1nchlEmsqHr
		KPNcFH6zYnWlisuXpe7aRBfO.b62Lvx73wIFjlMECeGXOHmpnSU9Zt()
		KPNcFH6zYnWlisuXpe7aRBfO.MM10NzFscuQVlLBwIK9()
		ZoRlH8nhKejzE3vDxfCJ = list(KPNcFH6zYnWlisuXpe7aRBfO.resultsDICT.keys())
		wOWpsGeYxc3 = sorted(ZoRlH8nhKejzE3vDxfCJ,reverse=yrcbRSFswvAfEdIWVj,key=lambda key: int(key))
		for JJ4wRxzq6WNrabTVlSyE in wOWpsGeYxc3:
			jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk += KPNcFH6zYnWlisuXpe7aRBfO.resultsDICT[JJ4wRxzq6WNrabTVlSyE]
	return jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk
def Iq4w9SWca8g5vhsTXdU(Ym0kMIiBp4dFarGHxs6Svle):
	aADIsJHOjzyYZ1RWdk4CmoPiQTlhBg = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,KJLkQsqSHMR1Np2(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩኯ"),Ym0kMIiBp4dFarGHxs6Svle,mmbcsf2pd7gyjzreB(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ኰ"))
	try: use27FOMSU03r5vq1 = open(aADIsJHOjzyYZ1RWdk4CmoPiQTlhBg,iI7tuF0nEQoR(u"ࠫࡷࡨࠧ኱")).read()
	except:
		LBFUIzNK8w7u2eVD1nomGH4ytO3dZ = bCoOHfPdMryRgauz0IVpth.path.join(jhlX1ra7vJ0ykCtcYfmBIiW,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡧࡤࡥࡱࡱࡷࠬኲ"),Ym0kMIiBp4dFarGHxs6Svle,iiLyoNwGbH03DIXhAkZn(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩኳ"))
		try: use27FOMSU03r5vq1 = open(LBFUIzNK8w7u2eVD1nomGH4ytO3dZ,TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡳࡤࠪኴ")).read()
		except: return gby0BnUuTNFk,[]
	if nqkybtoMBH: use27FOMSU03r5vq1 = use27FOMSU03r5vq1.decode(JJQFjSIlALchiMzG9)
	B8YTWSCNQuLqJH1d2wtDaXh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(n6JjFHfmydIaLut(u"ࠨ࡫ࡧࡁ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾࡝࡟ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠣ࡞ࠪࡡࠬኵ"),use27FOMSU03r5vq1,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
	if not B8YTWSCNQuLqJH1d2wtDaXh: return gby0BnUuTNFk,[]
	gjtApaOGdKhs3L9C0QMu1,LanyqTsF7Q = B8YTWSCNQuLqJH1d2wtDaXh[xn867tCVlscY4qbWZfh],NNLyWfbPqkGF5jBxp46oJ(B8YTWSCNQuLqJH1d2wtDaXh[xn867tCVlscY4qbWZfh])
	return gjtApaOGdKhs3L9C0QMu1,LanyqTsF7Q
def GOqi5wrzF6nBV2yAkQtEp():
	z2VbpFCZ0Uw9ABsnjT4DvWlHGhr = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,i80mE7lHUwVk(u"ࠩࡧ࡭ࡨࡺࠧ኶"),zDSw8LCxMQyraeXhojIWKmU(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ኷"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬኸ"))
	if z2VbpFCZ0Uw9ABsnjT4DvWlHGhr: return z2VbpFCZ0Uw9ABsnjT4DvWlHGhr
	wvrjPdXcWh7Auie1spJEVGo,z2VbpFCZ0Uw9ABsnjT4DvWlHGhr = {},{}
	ifTOXc6U2l90Np7au = [wAcHkmPB8a.SITESURLS[MlTVLBZ92kzorIq1Yw(u"ࠬࡘࡅࡑࡑࡖࠫኹ")][xn867tCVlscY4qbWZfh]]
	if h4ETRzHBcxIbW>Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠼࠴࠹࠺ᜭ"): ifTOXc6U2l90Np7au.append(wAcHkmPB8a.SITESURLS[tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡒࡆࡒࡒࡗࠬኺ")][jxCVeKSLb9rGDOl0Qtw6])
	if nqkybtoMBH: ifTOXc6U2l90Np7au.append(wAcHkmPB8a.SITESURLS[MlTVLBZ92kzorIq1Yw(u"ࠧࡓࡇࡓࡓࡘ࠭ኻ")][dNx9DVCtafk4r])
	for VdouaYHtcPGCywrfTS in ifTOXc6U2l90Np7au:
		tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡉࡈࡘࠬኼ"),VdouaYHtcPGCywrfTS,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,ggtuNcvTn3HQ7SpE2(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ኽ"))
		if tKObfFRod18ZU.succeeded:
			cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
			Y9WyenZN2HSmzAPt = VdouaYHtcPGCywrfTS.rsplit(FAwWlRJg0UkN1(u"ࠪ࠳ࠬኾ"),iiLyoNwGbH03DIXhAkZn(u"࠶ᜮ"))[xn867tCVlscY4qbWZfh]
			P0sRYW2xBhZzfbS8gjcI9TU7GqVmOH = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iI7tuF0nEQoR(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ኿"),cHuIdQiPshK8mwFUlkADGLv42fpeR,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
			for Ym0kMIiBp4dFarGHxs6Svle,KIHvzdeaRimp in P0sRYW2xBhZzfbS8gjcI9TU7GqVmOH:
				dd6hWHrPDLicXtmBFUC5 = Y9WyenZN2HSmzAPt+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬ࠵ࠧዀ")+Ym0kMIiBp4dFarGHxs6Svle+uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭࠯ࠨ዁")+Ym0kMIiBp4dFarGHxs6Svle+YZXtBgvUPoM5sb(u"ࠧ࠮ࠩዂ")+KIHvzdeaRimp+OUFxZPuXDoGAbRz(u"ࠨ࠰ࡽ࡭ࡵ࠭ዃ")
				if Ym0kMIiBp4dFarGHxs6Svle not in list(wvrjPdXcWh7Auie1spJEVGo.keys()):
					wvrjPdXcWh7Auie1spJEVGo[Ym0kMIiBp4dFarGHxs6Svle] = []
					z2VbpFCZ0Uw9ABsnjT4DvWlHGhr[Ym0kMIiBp4dFarGHxs6Svle] = []
				r6WRkS2uhTa = NNLyWfbPqkGF5jBxp46oJ(KIHvzdeaRimp)
				wvrjPdXcWh7Auie1spJEVGo[Ym0kMIiBp4dFarGHxs6Svle].append((KIHvzdeaRimp,r6WRkS2uhTa,dd6hWHrPDLicXtmBFUC5))
	for Ym0kMIiBp4dFarGHxs6Svle in list(wvrjPdXcWh7Auie1spJEVGo.keys()):
		z2VbpFCZ0Uw9ABsnjT4DvWlHGhr[Ym0kMIiBp4dFarGHxs6Svle] = sorted(wvrjPdXcWh7Auie1spJEVGo[Ym0kMIiBp4dFarGHxs6Svle],reverse=w8Ui6RsVhSPrqHfO4,key=lambda key: key[jxCVeKSLb9rGDOl0Qtw6])
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧዄ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫዅ"),z2VbpFCZ0Uw9ABsnjT4DvWlHGhr,DNh1dgpa4BK)
	return z2VbpFCZ0Uw9ABsnjT4DvWlHGhr
def NNLyWfbPqkGF5jBxp46oJ(KIHvzdeaRimp):
	r6WRkS2uhTa = []
	jNrhlbkCtJ6sMLn4 = KIHvzdeaRimp.split(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫ࠳࠭዆"))
	for PXuS52YInRqws0kt9L4KaJ in jNrhlbkCtJ6sMLn4:
		fygK3musnrWLvadzkl9wbZT07OX = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iiLyoNwGbH03DIXhAkZn(u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ዇"),PXuS52YInRqws0kt9L4KaJ,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		sYcpLozv5StGuDUfaAxE = []
		for a5w6quChgWOoQIX in fygK3musnrWLvadzkl9wbZT07OX:
			if a5w6quChgWOoQIX.isdigit(): a5w6quChgWOoQIX = int(a5w6quChgWOoQIX)
			sYcpLozv5StGuDUfaAxE.append(a5w6quChgWOoQIX)
		r6WRkS2uhTa.append(sYcpLozv5StGuDUfaAxE)
	return r6WRkS2uhTa
def OvE9CuhWKwfNmnI(r6WRkS2uhTa):
	KIHvzdeaRimp = gby0BnUuTNFk
	for PXuS52YInRqws0kt9L4KaJ in r6WRkS2uhTa:
		for a5w6quChgWOoQIX in PXuS52YInRqws0kt9L4KaJ: KIHvzdeaRimp += str(a5w6quChgWOoQIX)
		KIHvzdeaRimp += i80mE7lHUwVk(u"࠭࠮ࠨወ")
	KIHvzdeaRimp = KIHvzdeaRimp.strip(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧ࠯ࠩዉ"))
	return KIHvzdeaRimp
def zkOFlha1KsAoNrVCwPSRt4c(DLP5BmAOa4):
	CCLxuVfgQ54G7tXe = {}
	wvrjPdXcWh7Auie1spJEVGo = GOqi5wrzF6nBV2yAkQtEp()
	FrHyJNvZzDpdRkojgQx4CseUV597 = FG7MISaqyKQ1o83fjw4e6VmB29W5Ul(DLP5BmAOa4)
	for Ym0kMIiBp4dFarGHxs6Svle in DLP5BmAOa4:
		if Ym0kMIiBp4dFarGHxs6Svle not in list(wvrjPdXcWh7Auie1spJEVGo.keys()): continue
		z2VbpFCZ0Uw9ABsnjT4DvWlHGhr = wvrjPdXcWh7Auie1spJEVGo[Ym0kMIiBp4dFarGHxs6Svle]
		kg9qm6iLTDBo,N8r9P3izbTv,AOXWQxNpyfsz7kcbMYTdGwIl = z2VbpFCZ0Uw9ABsnjT4DvWlHGhr[xn867tCVlscY4qbWZfh]
		TsXNzW6OARoHj0BeYJC,vmXNf1pAdiK9qlCBHJus5QV7wGEhT = Iq4w9SWca8g5vhsTXdU(Ym0kMIiBp4dFarGHxs6Svle)
		ooZYDsfChl,xrvfhDVnp6XYaus5b = FrHyJNvZzDpdRkojgQx4CseUV597[Ym0kMIiBp4dFarGHxs6Svle]
		IVLu3N6U8SWxijAOwFKehPCZzY9 = N8r9P3izbTv>vmXNf1pAdiK9qlCBHJus5QV7wGEhT and ooZYDsfChl
		zRpWtZeDEKClrd = w8Ui6RsVhSPrqHfO4
		if not ooZYDsfChl: q6BgXtG5xOoANVM1HFTu = ggtuNcvTn3HQ7SpE2(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩዊ")
		elif not xrvfhDVnp6XYaus5b: q6BgXtG5xOoANVM1HFTu = iiauUxMktNW5X(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫዋ")
		elif IVLu3N6U8SWxijAOwFKehPCZzY9: q6BgXtG5xOoANVM1HFTu = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡳࡱࡪࠧዌ")
		else:
			q6BgXtG5xOoANVM1HFTu = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫ࡬ࡵ࡯ࡥࠩው")
			zRpWtZeDEKClrd = yrcbRSFswvAfEdIWVj
		CCLxuVfgQ54G7tXe[Ym0kMIiBp4dFarGHxs6Svle] = zRpWtZeDEKClrd,TsXNzW6OARoHj0BeYJC,vmXNf1pAdiK9qlCBHJus5QV7wGEhT,kg9qm6iLTDBo,N8r9P3izbTv,q6BgXtG5xOoANVM1HFTu,AOXWQxNpyfsz7kcbMYTdGwIl
	return CCLxuVfgQ54G7tXe
def OCdLHyt7V58QGMokw(XAbSTLwjmJDs8WgraYFn,cBnvm5ergfEUd2YPjiOKwNtzLk8M7,uZEgaUkjpwSB23fHiDXG54d1JemRL0=gby0BnUuTNFk,rZszBy9Dxq3kmhSNboJUl=gby0BnUuTNFk,kVSrf6wvgbxU70MXTpACIZW9H15e=gby0BnUuTNFk):
	if cAIRPFK6boejVU549WzqBGCaJ0r: XAbSTLwjmJDs8WgraYFn.update(cBnvm5ergfEUd2YPjiOKwNtzLk8M7,uZEgaUkjpwSB23fHiDXG54d1JemRL0,rZszBy9Dxq3kmhSNboJUl,kVSrf6wvgbxU70MXTpACIZW9H15e)
	else: XAbSTLwjmJDs8WgraYFn.update(cBnvm5ergfEUd2YPjiOKwNtzLk8M7,uZEgaUkjpwSB23fHiDXG54d1JemRL0+okfdjS4RmM+rZszBy9Dxq3kmhSNboJUl+okfdjS4RmM+kVSrf6wvgbxU70MXTpACIZW9H15e)
	return
def Y6YlvV3gLE40RyAZPbptuQx8cmWkB(dRu0SpaOHYm4qZI3Gn7fE6XysKt9):
	def mDJCt1rKoWvab(OKE4G2Ln1ZM9lsFCPv73,zkesUwy3MSYPpu2,zkt7dJquXI1MfpEZKONGjh6ar20W=lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧዎ")):
		return ((OKE4G2Ln1ZM9lsFCPv73 == xn867tCVlscY4qbWZfh) and zkt7dJquXI1MfpEZKONGjh6ar20W[xn867tCVlscY4qbWZfh]) or (mDJCt1rKoWvab(OKE4G2Ln1ZM9lsFCPv73 // zkesUwy3MSYPpu2, zkesUwy3MSYPpu2, zkt7dJquXI1MfpEZKONGjh6ar20W).lstrip(zkt7dJquXI1MfpEZKONGjh6ar20W[xn867tCVlscY4qbWZfh]) + zkt7dJquXI1MfpEZKONGjh6ar20W[OKE4G2Ln1ZM9lsFCPv73 % zkesUwy3MSYPpu2])
	def eSdmqgZECkW2uR(zv9mXksqex7832iRVIj5HMwTgWhNYl, f096WzClEin3Jpvbm4Z5dIjtBuy, FyTHmCkslS7Y5UvdRLEnGD, LOCWmtqd0IAbgDQXw, ppXw2svzuI0nQg=D0DRCGqknfT2tKPY6N, P6VbyziFnqGxjNwAEhf7=D0DRCGqknfT2tKPY6N, ckKh9MFRuqfJTbHp=D0DRCGqknfT2tKPY6N):
		while (FyTHmCkslS7Y5UvdRLEnGD):
			FyTHmCkslS7Y5UvdRLEnGD-=uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠷ᜯ")
			if (LOCWmtqd0IAbgDQXw[FyTHmCkslS7Y5UvdRLEnGD]): zv9mXksqex7832iRVIj5HMwTgWhNYl = ERgVvYA0TMIdUCa2KzFQDcZOPNin.sub(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ࡜࡝ࡤࠥዏ") + mDJCt1rKoWvab(FyTHmCkslS7Y5UvdRLEnGD, f096WzClEin3Jpvbm4Z5dIjtBuy) + KJLkQsqSHMR1Np2(u"ࠢ࡝࡞ࡥࠦዐ"),  LOCWmtqd0IAbgDQXw[FyTHmCkslS7Y5UvdRLEnGD], zv9mXksqex7832iRVIj5HMwTgWhNYl)
		return zv9mXksqex7832iRVIj5HMwTgWhNYl
	dRu0SpaOHYm4qZI3Gn7fE6XysKt9 = dRu0SpaOHYm4qZI3Gn7fE6XysKt9.split(n6JjFHfmydIaLut(u"ࠨࡿࠫࠫዑ"))[jxCVeKSLb9rGDOl0Qtw6]
	dRu0SpaOHYm4qZI3Gn7fE6XysKt9 = dRu0SpaOHYm4qZI3Gn7fE6XysKt9.rsplit(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡶࡴࡱ࡯ࡴࠨዒ"))[xn867tCVlscY4qbWZfh]+zDSw8LCxMQyraeXhojIWKmU(u"ࠥࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠩࠣዓ")
	j4hvHwLtT3 = eval(OUFxZPuXDoGAbRz(u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬዔ")+dRu0SpaOHYm4qZI3Gn7fE6XysKt9,{iiauUxMktNW5X(u"ࠬࡨࡡࡴࡧࡑࠫዕ"):mDJCt1rKoWvab,iiauUxMktNW5X(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭ዖ"):eSdmqgZECkW2uR})
	return j4hvHwLtT3
def ua5b3f7lEA(code):
	_GoxdXrqwVZcKpY=VzO1gCHmjZ2ebRIL(u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠫ࠰ࠤ዗")
	def HJVb0mdGC91Pc7gEvyNAeIihZk3aX(P6VbyziFnqGxjNwAEhf7,ppXw2svzuI0nQg,xEtoGpzgCHuLs2jKb):
		kKFjzbROC4E5xglNIDZJonB76GQ1HS = list(_GoxdXrqwVZcKpY)
		mnsuMxbFva6T4jKlJX7C38oBzQ5 = kKFjzbROC4E5xglNIDZJonB76GQ1HS[Ducd5PRjQXaB9SIN7VrJ1G(u"࠰ᜰ"):ppXw2svzuI0nQg]
		xuX6UN0WRQbHArDV = kKFjzbROC4E5xglNIDZJonB76GQ1HS[GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠱ᜱ"):xEtoGpzgCHuLs2jKb]
		P6VbyziFnqGxjNwAEhf7 = list(P6VbyziFnqGxjNwAEhf7)[::-nJF7oflOk6cLGSAey(u"࠳ᜲ")]
		aA0yGgzrdjoENpWKS = VzO1gCHmjZ2ebRIL(u"࠳ᜳ")
		for FyTHmCkslS7Y5UvdRLEnGD,zkesUwy3MSYPpu2 in enumerate(P6VbyziFnqGxjNwAEhf7):
			if zkesUwy3MSYPpu2 in mnsuMxbFva6T4jKlJX7C38oBzQ5: aA0yGgzrdjoENpWKS = aA0yGgzrdjoENpWKS + mnsuMxbFva6T4jKlJX7C38oBzQ5.index(zkesUwy3MSYPpu2)*ppXw2svzuI0nQg**FyTHmCkslS7Y5UvdRLEnGD
		LOCWmtqd0IAbgDQXw = n6JjFHfmydIaLut(u"ࠣࠤዘ")
		while aA0yGgzrdjoENpWKS > YZXtBgvUPoM5sb(u"࠴᜴"):
			LOCWmtqd0IAbgDQXw = xuX6UN0WRQbHArDV[aA0yGgzrdjoENpWKS%xEtoGpzgCHuLs2jKb] + LOCWmtqd0IAbgDQXw
			aA0yGgzrdjoENpWKS = (aA0yGgzrdjoENpWKS - (aA0yGgzrdjoENpWKS%xEtoGpzgCHuLs2jKb))//xEtoGpzgCHuLs2jKb
		return int(LOCWmtqd0IAbgDQXw) or tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠵᜵")
	def zzcL6vpVYXSl(mnsuMxbFva6T4jKlJX7C38oBzQ5,u,V5307fsKxWXEniF,uEMLwzNe2qmGF,ppXw2svzuI0nQg,ckKh9MFRuqfJTbHp):
		ckKh9MFRuqfJTbHp = YZXtBgvUPoM5sb(u"ࠤࠥዙ");
		xuX6UN0WRQbHArDV = FAwWlRJg0UkN1(u"࠶᜶")
		while xuX6UN0WRQbHArDV < len(mnsuMxbFva6T4jKlJX7C38oBzQ5):
			aA0yGgzrdjoENpWKS = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠰᜷")
			saQHKXhJtUSPo6GRcmAYuw = DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠥࠦዚ")
			while mnsuMxbFva6T4jKlJX7C38oBzQ5[xuX6UN0WRQbHArDV] is not V5307fsKxWXEniF[ppXw2svzuI0nQg]:
				saQHKXhJtUSPo6GRcmAYuw = gby0BnUuTNFk.join([saQHKXhJtUSPo6GRcmAYuw,mnsuMxbFva6T4jKlJX7C38oBzQ5[xuX6UN0WRQbHArDV]])
				xuX6UN0WRQbHArDV = xuX6UN0WRQbHArDV + BarIC3eR9bS(u"࠲᜸")
			while aA0yGgzrdjoENpWKS < len(V5307fsKxWXEniF):
				saQHKXhJtUSPo6GRcmAYuw = saQHKXhJtUSPo6GRcmAYuw.replace(V5307fsKxWXEniF[aA0yGgzrdjoENpWKS],str(aA0yGgzrdjoENpWKS))
				aA0yGgzrdjoENpWKS = aA0yGgzrdjoENpWKS + tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠳᜹")
			ckKh9MFRuqfJTbHp = gby0BnUuTNFk.join([ckKh9MFRuqfJTbHp,gby0BnUuTNFk.join(map(chr, [HJVb0mdGC91Pc7gEvyNAeIihZk3aX(saQHKXhJtUSPo6GRcmAYuw,ppXw2svzuI0nQg,FAwWlRJg0UkN1(u"࠴࠴᜺")) - uEMLwzNe2qmGF]))])
			xuX6UN0WRQbHArDV = xuX6UN0WRQbHArDV + iiLyoNwGbH03DIXhAkZn(u"࠵᜻")
		return ckKh9MFRuqfJTbHp
	code = code.replace(MlTVLBZ92kzorIq1Yw(u"ࠫࡡࡴࠧዛ"),gby0BnUuTNFk).replace(uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬࡢࡲࠨዜ"),gby0BnUuTNFk)
	H40UnkjTpY8 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(IXE6voNmrb182AyQ(u"࠭࡜ࡾ࡞ࠫࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࡝ࠫ࡟࠭ࠬዝ"),code,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if H40UnkjTpY8:
		H40UnkjTpY8 = list(H40UnkjTpY8[nJF7oflOk6cLGSAey(u"࠵᜼")])
		for qOSWdi9yobA0GEFU,code in enumerate(H40UnkjTpY8):
			if code.isdigit(): H40UnkjTpY8[qOSWdi9yobA0GEFU] = int(code)
			else: H40UnkjTpY8[qOSWdi9yobA0GEFU] = code.replace(q2qPkMFpR1G86dEAKXHivor9N(u"ࠧ࡝ࠤࠪዞ"),gby0BnUuTNFk)
		QvZYFsp8o0H1kSEefjb2 = zzcL6vpVYXSl(*H40UnkjTpY8)
		return QvZYFsp8o0H1kSEefjb2
	return gby0BnUuTNFk
def gbkNcH9vfoVYiahX(KKFPNRzufO,tvD1fbTAJLBNpjkMS9nwqgeF83Vlur=gby0BnUuTNFk):
	if tvD1fbTAJLBNpjkMS9nwqgeF83Vlur==IXE6voNmrb182AyQ(u"ࠨ࡮ࡲࡻࡪࡸࠧዟ"): KKFPNRzufO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.sub(KJLkQsqSHMR1Np2(u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩዠ"),lambda c1OiW439hIQasdTwxPNjRU27XfbD6l: c1OiW439hIQasdTwxPNjRU27XfbD6l.group(xn867tCVlscY4qbWZfh).lower(),KKFPNRzufO)
	elif tvD1fbTAJLBNpjkMS9nwqgeF83Vlur==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡹࡵࡶࡥࡳࠩዡ"): KKFPNRzufO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.sub(NupI74tJCzYXmles9SbR6(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫዢ"),lambda c1OiW439hIQasdTwxPNjRU27XfbD6l: c1OiW439hIQasdTwxPNjRU27XfbD6l.group(xn867tCVlscY4qbWZfh).upper(),KKFPNRzufO)
	return KKFPNRzufO
def FG7MISaqyKQ1o83fjw4e6VmB29W5Ul(DLP5BmAOa4):
	WRMaG5Ii7zTnfBDqkxhL48OF9E1,LLwVRgidmetPb = yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj
	DEOf7aYR4rZXubkAHBUMzhlmCgK = H6JBPsvmfLRhZI4YzUnebWdXKV8ig.connect(OOcgTBrf9EC32tlhwQPa)
	DEOf7aYR4rZXubkAHBUMzhlmCgK.text_factory = str
	MnOPIpuYDZFJ = DEOf7aYR4rZXubkAHBUMzhlmCgK.cursor()
	if len(DLP5BmAOa4)==jxCVeKSLb9rGDOl0Qtw6: Ty37fMRJrts = zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࠮ࠢࠨዣ")+DLP5BmAOa4[xn867tCVlscY4qbWZfh]+NupI74tJCzYXmles9SbR6(u"࠭ࠢࠪࠩዤ")
	else: Ty37fMRJrts = str(tuple(DLP5BmAOa4))
	MnOPIpuYDZFJ.execute(mmbcsf2pd7gyjzreB(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧዥ")+Ty37fMRJrts+n6JjFHfmydIaLut(u"ࠨࠢ࠾ࠫዦ"))
	npRAlrWYXkFuDwga9K031eiho5 = MnOPIpuYDZFJ.fetchall()
	DEOf7aYR4rZXubkAHBUMzhlmCgK.close()
	FrHyJNvZzDpdRkojgQx4CseUV597 = {}
	for Ym0kMIiBp4dFarGHxs6Svle in DLP5BmAOa4: FrHyJNvZzDpdRkojgQx4CseUV597[Ym0kMIiBp4dFarGHxs6Svle] = (yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	for Ym0kMIiBp4dFarGHxs6Svle,LLwVRgidmetPb in npRAlrWYXkFuDwga9K031eiho5:
		WRMaG5Ii7zTnfBDqkxhL48OF9E1 = w8Ui6RsVhSPrqHfO4
		LLwVRgidmetPb = LLwVRgidmetPb==jxCVeKSLb9rGDOl0Qtw6
		FrHyJNvZzDpdRkojgQx4CseUV597[Ym0kMIiBp4dFarGHxs6Svle] = (WRMaG5Ii7zTnfBDqkxhL48OF9E1,LLwVRgidmetPb)
	return FrHyJNvZzDpdRkojgQx4CseUV597
def nLva0Z9oCXSR2bc4WmspwGEO(APkujXVWbdt6p98Y):
	WjryKiBebavP = gby0BnUuTNFk
	if bCoOHfPdMryRgauz0IVpth.path.exists(APkujXVWbdt6p98Y):
		zdXhftGwka4WTRjsc6p3E8LgAm5v = open(APkujXVWbdt6p98Y,zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡵࡦࠬዧ")).read()
		if nqkybtoMBH: zdXhftGwka4WTRjsc6p3E8LgAm5v = zdXhftGwka4WTRjsc6p3E8LgAm5v.decode(JJQFjSIlALchiMzG9)
		PMf3hB2Sc7vIb = TqNUy3Z4SFWvplGwXC82A(TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡨ࡮ࡩࡴࠨየ"),zdXhftGwka4WTRjsc6p3E8LgAm5v)
		if PMf3hB2Sc7vIb:
			WjryKiBebavP = {}
			for YYtF0fR1d8ThnNaHXBCDwmz9uEZK in PMf3hB2Sc7vIb.keys():
				WjryKiBebavP[YYtF0fR1d8ThnNaHXBCDwmz9uEZK] = []
				for Bqx5Lh4NIGKjE in PMf3hB2Sc7vIb[YYtF0fR1d8ThnNaHXBCDwmz9uEZK]:
					OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
					OORugdCwcD9UrzXtT7vML1FWasP = Bqx5Lh4NIGKjE[xn867tCVlscY4qbWZfh]
					I72DXzjFMdCBOZv = Bqx5Lh4NIGKjE[jxCVeKSLb9rGDOl0Qtw6]
					I72DXzjFMdCBOZv = A8aFK3BwGne5LIziU(I72DXzjFMdCBOZv)
					KKFPNRzufO = Bqx5Lh4NIGKjE[dNx9DVCtafk4r]
					KIwAPk6E3vN4iUqf1n8HrJLQb = Bqx5Lh4NIGKjE[jJ4LEcdl5w7BPMbQ]
					gQmur3iRSZ9IAOX = Bqx5Lh4NIGKjE[z5RruqXvsLaTf7e9c]
					kdwXYDMQOjz51Z08W = Bqx5Lh4NIGKjE[n6JjFHfmydIaLut(u"࠻᜽")]
					if len(Bqx5Lh4NIGKjE)>kreQUwJis7YmC2yqWtIF09pgjbD(u"࠶᜾"): czrd0xT7BIl6noGC29w = Bqx5Lh4NIGKjE[kreQUwJis7YmC2yqWtIF09pgjbD(u"࠶᜾")]
					if len(Bqx5Lh4NIGKjE)>q2qPkMFpR1G86dEAKXHivor9N(u"࠸᜿"): wH1a6KyFuLn = Bqx5Lh4NIGKjE[q2qPkMFpR1G86dEAKXHivor9N(u"࠸᜿")]
					if len(Bqx5Lh4NIGKjE)>n6JjFHfmydIaLut(u"࠺ᝀ"): ZgSKTRL2DlPprjU57W93zf4EF = Bqx5Lh4NIGKjE[n6JjFHfmydIaLut(u"࠺ᝀ")]
					if APkujXVWbdt6p98Y==U24naHzCgdv7wWF: ESiYWON8Ld724Csel9 = OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,gby0BnUuTNFk,ZgSKTRL2DlPprjU57W93zf4EF
					else: ESiYWON8Ld724Csel9 = OORugdCwcD9UrzXtT7vML1FWasP,I72DXzjFMdCBOZv,KKFPNRzufO,KIwAPk6E3vN4iUqf1n8HrJLQb,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,czrd0xT7BIl6noGC29w,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF
					WjryKiBebavP[YYtF0fR1d8ThnNaHXBCDwmz9uEZK].append(ESiYWON8Ld724Csel9)
		j6wCIHqUA2nOSF = str(WjryKiBebavP)
		if nqkybtoMBH: j6wCIHqUA2nOSF = j6wCIHqUA2nOSF.encode(JJQFjSIlALchiMzG9)
		open(APkujXVWbdt6p98Y,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡼࡨࠧዩ")).write(j6wCIHqUA2nOSF)
	return WjryKiBebavP
def Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1):
	wM0bsUyh6NaAtZ = gwiQ59eNbhY2SlLZB7aOpTDdsk1.split(zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࠳ࠧዪ"),jxCVeKSLb9rGDOl0Qtw6)[xn867tCVlscY4qbWZfh]
	DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	if   wM0bsUyh6NaAtZ==YZXtBgvUPoM5sb(u"࠭ࡁࡉ࡙ࡄࡏࠬያ")		:	from zVULyY5Alq			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡂࡍࡒࡅࡒ࠭ዬ")		:	from yZ3odbeBP2			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==n6JjFHfmydIaLut(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪይ")	:	from UTIWbzrVEB		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==nJF7oflOk6cLGSAey(u"ࠩࡄࡏ࡜ࡇࡍࠨዮ")		:	from sQFHBNpE3k			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==BarIC3eR9bS(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ዯ")	:	from uQjPCUfkGh		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ggtuNcvTn3HQ7SpE2(u"ࠫࡆࡒࡁࡓࡃࡅࠫደ")	:	from Fgyi5EkYLO			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧዱ")	:	from St1MqEUPnv		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==YZXtBgvUPoM5sb(u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩዲ")	: 	from HUDnwlIaPQ		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ggtuNcvTn3HQ7SpE2(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩዳ")	:	from qSKV1NHRc7		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==BarIC3eR9bS(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩዴ")	:	from Q5cydCUtFX		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ggtuNcvTn3HQ7SpE2(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫድ")	:	from yymkpiw5Yf		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨዶ"):	from sST5CQRHEM	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ዷ")	:	from Gjewh9gsli		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==n6JjFHfmydIaLut(u"ࠬࡇ࡙ࡍࡑࡏࠫዸ")		:	from nDBJTIktvP			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==MlTVLBZ92kzorIq1Yw(u"࠭ࡂࡐࡍࡕࡅࠬዹ")		:	from HjBhWEfNbI			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠧࡃࡔࡖࡘࡊࡐࠧዺ")	:	from KKZ4xVmJXg			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩዻ")	:	from ho23HRmg5S		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==n6JjFHfmydIaLut(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩዼ")	:	from jzqQIXgmd1			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ggtuNcvTn3HQ7SpE2(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪዽ")	:	from AFR65LhJKv			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ዾ")	:	from TpY0AKdWbz		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==VzO1gCHmjZ2ebRIL(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧዿ")	:	from jl860IQmCb		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==TeYukOUW7i5NBM926DCjaAn0(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬጀ"):	from wBKRL8zdrO	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩጁ")	:	from J05BY1cXV9		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiauUxMktNW5X(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪጂ")	:	from iP1pgWelvz		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡆࡍࡒࡇࡆࡓࡇࡈࠫጃ")	:	from idbVe0R4GH		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==nJF7oflOk6cLGSAey(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ጄ")	:	from jqmSxV4kKl		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==n6JjFHfmydIaLut(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬጅ")	:	from Ob8caZHjQU		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ne7wF4gSTRZo(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧጆ")	:	from W7F4lGEdAB		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫጇ"):	from KDPmQVOUk3	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪገ")	:	from BhAF7KNcbm		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiauUxMktNW5X(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩጉ")	:	from IQlUohNcVG		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪጊ")	:	from q0TmeJzy1R		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬጋ")	:	from V21ihYpjMw		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==nJF7oflOk6cLGSAey(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ጌ")	:	from cq8kAlBLeR		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧግ")	:	from s2soyZkrN0		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨጎ")	:	from j9sfhOZTca		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨጏ")	:	from SJqEDhgV6N		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨጐ")	:	from nnlUST7ZuP			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ne7wF4gSTRZo(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ጑")	:	from S80daQfARz		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ጒ")	:	from HUqPNzhnWL		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬጓ")	:	from xku5DMLcaP		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==KJLkQsqSHMR1Np2(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨጔ")	:	from QpFwbVeWN1		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiLyoNwGbH03DIXhAkZn(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧጕ")	:	from UM04cxY1QH		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ጖")	:	from S1pUBER4Tz		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iI7tuF0nEQoR(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ጗")	:	from FLrzivyZw6		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==FAwWlRJg0UkN1(u"ࠩࡉࡓࡘ࡚ࡁࠨጘ")		:	from Z4LHVeXGJP			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫጙ")	:	from hzqfb1Q6vK		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ጚ")	:	from Lsr7QzBFcd		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==BarIC3eR9bS(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪጛ"):	from nnOVNo9hFc	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ggtuNcvTn3HQ7SpE2(u"࠭ࡇࡐࡑࡊࡐࡊ࡙ࡅࡂࡔࡆࡌࠬጜ"):	from rDo7jHvOGS	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiLyoNwGbH03DIXhAkZn(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩጝ")	:	from yf9tQsEG7N		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iI7tuF0nEQoR(u"ࠨࡋࡉࡍࡑࡓࠧጞ")		:	from ROWuY7rHxN			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡌࡔ࡙࡜ࠧጟ")		:	from BBhJgplbfL			import NZihe4G13VvS2WTXY9HLk07A as DeScCQAb5ti1ZxUPE,H7l4URTtJj2ksaBQwb as A52cxoCyGIJdvbTLNnSFtlj70,IvnA0yjpu5HDFS9UOawMqcVW as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==FAwWlRJg0UkN1(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ጠ")	:	from JJWfqoihzk		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==MlTVLBZ92kzorIq1Yw(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ጡ")	:	from tdwvF30EXx		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==YZXtBgvUPoM5sb(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧጢ")	:	from ppc0KrN9B7		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==IXE6voNmrb182AyQ(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧጣ")	:	from aXyNB8Gfr5		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==RRbvqditj184m3(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧጤ")	:	from yyveqRm9YI			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==BarIC3eR9bS(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩጥ")	:	from MeyAmGJKpB		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩࡐ࠷࡚࠭ጦ")		:	from yYCGB8hzwT			import NZihe4G13VvS2WTXY9HLk07A as DeScCQAb5ti1ZxUPE,H7l4URTtJj2ksaBQwb as A52cxoCyGIJdvbTLNnSFtlj70,IvnA0yjpu5HDFS9UOawMqcVW as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==YZXtBgvUPoM5sb(u"ࠪࡑࡆ࡙ࡁࡗࡋࡇࡉࡔ࠭ጧ")	:	from nXENOCgx1i		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫጨ")	:	from mmtZUAJhyW			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==i80mE7lHUwVk(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬጩ")	:	from pVo4yuG7nC			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡐࡂࡐࡈࡘࠬጪ")		:	from K6eF8ZUavp			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==n6JjFHfmydIaLut(u"ࠧࡒࡈࡌࡐࡒ࠭ጫ")		:	from DMFrjW2Bng			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==OUFxZPuXDoGAbRz(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬጬ"):	from JBwS3VlWq5		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬጭ")	:	from NT9osdBqV1		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==FAwWlRJg0UkN1(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬጮ")	:	from BPm0MsDGh7		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠸ࠧጯ")	:	from AJ4nDPx5ml		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==i80mE7lHUwVk(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩጰ"):	from MMsuB10OkI		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩጱ")	:	from f8lNOGRoPy		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠧࡔࡊࡒࡊࡍࡇࠧጲ")	:	from XnVuIb8y3Z			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪጳ")	:	from quHldBg7PM		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==ne7wF4gSTRZo(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫጴ")	:	from SGv29xNEm8		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==mmbcsf2pd7gyjzreB(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬጵ")	:	from aGnCcPuZi5		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==VzO1gCHmjZ2ebRIL(u"࡙ࠫࡏࡋࡂࡃࡗࠫጶ")	:	from VV85Hu2evh			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiLyoNwGbH03DIXhAkZn(u"࡚ࠬࡖࡇࡗࡑࠫጷ")		:	from ff7hypPcjD			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iiLyoNwGbH03DIXhAkZn(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ጸ")	:	from cZ5SdaxsCK			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iI7tuF0nEQoR(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫጹ"):	from Cy9tIYmOMT		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==iI7tuF0nEQoR(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩጺ")	:	from ok2cW8NBKl		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==FAwWlRJg0UkN1(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪጻ")	:	from JzI6BG2ckT		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==KJLkQsqSHMR1Np2(u"ࠪ࡝ࡆࡗࡏࡕࠩጼ")		:	from xKktOEQXsT			import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬጽ")	:	from cxgnfe941F		import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	elif wM0bsUyh6NaAtZ==Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫጾ"):	from KjPqGXZdNx	import x3xMQCnNkl9vPuDiBdV0UswS as DeScCQAb5ti1ZxUPE,a3NI0EopMZw as A52cxoCyGIJdvbTLNnSFtlj70,JB9fyoHr05QOtPjp as bcBlK1vyM5VaC2e
	return DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e
def EckxoYzjdgLH0r(sodfwxQDVXyIkJ6,D6eSPULGzKbwjIV9Ao1lc,showDialogs):
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,mmbcsf2pd7gyjzreB(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫጿ")+oHSEYlfpLzQrC1(sodfwxQDVXyIkJ6)+NupI74tJCzYXmles9SbR6(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪፀ")+str(D6eSPULGzKbwjIV9Ao1lc)+RRbvqditj184m3(u"ࠨࠢࡠࠫፁ"))
	XAbSTLwjmJDs8WgraYFn = gX5UxB8Sce7tuvjkNaoIAHDq4()
	XAbSTLwjmJDs8WgraYFn.create(e1nNXbPrBVDZw,iI7tuF0nEQoR(u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫፂ"))
	XfoEk6pQmbLA = uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠴࠴࠷࠺ᝁ")*uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠴࠴࠷࠺ᝁ")
	UFz73jEX8a = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠵ᝂ")*XfoEk6pQmbLA
	import requests as NGcESCFxok0
	tKObfFRod18ZU = NGcESCFxok0.get(sodfwxQDVXyIkJ6,stream=w8Ui6RsVhSPrqHfO4,headers=D6eSPULGzKbwjIV9Ao1lc)
	ZatiGPL0lXs1 = tKObfFRod18ZU.headers
	tKObfFRod18ZU.close()
	oBcJm1ZKb4ifkXxtzIMDGAdq3vNj = bytes()
	if not ZatiGPL0lXs1:
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭ፃ"))
		XAbSTLwjmJDs8WgraYFn.close()
	else:
		if FAwWlRJg0UkN1(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬፄ") not in list(ZatiGPL0lXs1.keys()): pXGclhjnWmUwM = xn867tCVlscY4qbWZfh
		else: pXGclhjnWmUwM = int(ZatiGPL0lXs1[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ፅ")])
		iQV7sZJfuqLpjme6F93POrIRz = str(int(mmbcsf2pd7gyjzreB(u"࠷࠰࠱࠲ᝄ")*pXGclhjnWmUwM/XfoEk6pQmbLA)/n6JjFHfmydIaLut(u"࠶࠶࠰࠱࠰࠳ᝃ"))
		fV2wJh8mB5d = int(pXGclhjnWmUwM/UFz73jEX8a)+jxCVeKSLb9rGDOl0Qtw6
		if mmbcsf2pd7gyjzreB(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭ፆ") in list(ZatiGPL0lXs1.keys()) and pXGclhjnWmUwM>XfoEk6pQmbLA:
			ccYm6y1M4bRqO7SlWv2A = w8Ui6RsVhSPrqHfO4
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC = []
			oQ130CIAzdJ64lLjBYOEyPHD = uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠱࠱ᝅ")
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(xn867tCVlscY4qbWZfh*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+TeYukOUW7i5NBM926DCjaAn0(u"ࠧ࠮ࠩፇ")+str(jxCVeKSLb9rGDOl0Qtw6*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(jxCVeKSLb9rGDOl0Qtw6*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+FAwWlRJg0UkN1(u"ࠨ࠯ࠪፈ")+str(dNx9DVCtafk4r*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(dNx9DVCtafk4r*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠩ࠰ࠫፉ")+str(jJ4LEcdl5w7BPMbQ*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(jJ4LEcdl5w7BPMbQ*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+RRbvqditj184m3(u"ࠪ࠱ࠬፊ")+str(z5RruqXvsLaTf7e9c*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(z5RruqXvsLaTf7e9c*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࠲࠭ፋ")+str(RRbvqditj184m3(u"࠶ᝆ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(VzO1gCHmjZ2ebRIL(u"࠷ᝇ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࠳ࠧፌ")+str(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠹ᝈ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(DWgX6JfF3SnlsQwtN1cvGk8L(u"࠻ᝊ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+IXE6voNmrb182AyQ(u"࠭࠭ࠨፍ")+str(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠻ᝉ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(ne7wF4gSTRZo(u"࠷ᝌ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧ࠮ࠩፎ")+str(NupI74tJCzYXmles9SbR6(u"࠾ᝋ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(BarIC3eR9bS(u"࠺ᝎ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࠯ࠪፏ")+str(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠺ᝍ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD-jxCVeKSLb9rGDOl0Qtw6))
			aU9QcP3KjHWGR7XkhDdbvMzwgiEC.append(str(MlTVLBZ92kzorIq1Yw(u"࠼ᝏ")*pXGclhjnWmUwM//oQ130CIAzdJ64lLjBYOEyPHD)+OUFxZPuXDoGAbRz(u"ࠩ࠰ࠫፐ"))
			LLzulRsPbOnJeKdyi7hT9tQ = float(fV2wJh8mB5d)/oQ130CIAzdJ64lLjBYOEyPHD
			CIM59KLUFq1tWX4f3bPlcDZ = LLzulRsPbOnJeKdyi7hT9tQ/int(jxCVeKSLb9rGDOl0Qtw6+LLzulRsPbOnJeKdyi7hT9tQ)
		else:
			ccYm6y1M4bRqO7SlWv2A = yrcbRSFswvAfEdIWVj
			oQ130CIAzdJ64lLjBYOEyPHD = jxCVeKSLb9rGDOl0Qtw6
			CIM59KLUFq1tWX4f3bPlcDZ = jxCVeKSLb9rGDOl0Qtw6
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡳࡣࡱ࡫ࡪࡹ࠺ࠡ࡝ࠣࠫፑ")+str(ccYm6y1M4bRqO7SlWv2A)+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࠥࡣࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ፒ")+str(pXGclhjnWmUwM)+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࠦ࡝ࠨፓ"))
		t3t986iTduqY,LAZHPhtuI3 = xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
		for W09UxYnrV5Jk3wfM84DzaC6PFIOKy in range(oQ130CIAzdJ64lLjBYOEyPHD):
			IciL6hoO5F1MDSVPjypWZs8kKx = D6eSPULGzKbwjIV9Ao1lc.copy()
			if ccYm6y1M4bRqO7SlWv2A: IciL6hoO5F1MDSVPjypWZs8kKx[iiLyoNwGbH03DIXhAkZn(u"࠭ࡒࡢࡰࡪࡩࠬፔ")] = YZXtBgvUPoM5sb(u"ࠧࡣࡻࡷࡩࡸࡃࠧፕ")+aU9QcP3KjHWGR7XkhDdbvMzwgiEC[W09UxYnrV5Jk3wfM84DzaC6PFIOKy]
			tKObfFRod18ZU = NGcESCFxok0.get(sodfwxQDVXyIkJ6,stream=w8Ui6RsVhSPrqHfO4,headers=IciL6hoO5F1MDSVPjypWZs8kKx,timeout=tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠷࠵࠶ᝐ"))
			for WJUfceuZdwCkvQmEgGti7Ar4jDL9O in tKObfFRod18ZU.iter_content(chunk_size=UFz73jEX8a):
				if XAbSTLwjmJDs8WgraYFn.iscanceled():
					SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,i80mE7lHUwVk(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠨፖ"))
					break
				t3t986iTduqY += CIM59KLUFq1tWX4f3bPlcDZ
				oBcJm1ZKb4ifkXxtzIMDGAdq3vNj += WJUfceuZdwCkvQmEgGti7Ar4jDL9O
				if not LAZHPhtuI3: LAZHPhtuI3 = len(WJUfceuZdwCkvQmEgGti7Ar4jDL9O)
				if pXGclhjnWmUwM: OCdLHyt7V58QGMokw(XAbSTLwjmJDs8WgraYFn,iiauUxMktNW5X(u"࠶࠶࠰ᝑ")*t3t986iTduqY//fV2wJh8mB5d,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠠศๆฯึฦࠦัใ็ࠪፗ"),str(q2qPkMFpR1G86dEAKXHivor9N(u"࠷࠰࠱࠰࠳ᝒ")*LAZHPhtuI3*t3t986iTduqY//UFz73jEX8a//q2qPkMFpR1G86dEAKXHivor9N(u"࠷࠰࠱࠰࠳ᝒ"))+ne7wF4gSTRZo(u"ࠪࠤ࠴ࠦࠧፘ")+iQV7sZJfuqLpjme6F93POrIRz+n6JjFHfmydIaLut(u"ࠫࠥࡓࡂࠨፙ"))
				else: OCdLHyt7V58QGMokw(XAbSTLwjmJDs8WgraYFn,LAZHPhtuI3*t3t986iTduqY//UFz73jEX8a,KJLkQsqSHMR1Np2(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠪፚ"),str(mmbcsf2pd7gyjzreB(u"࠱࠱࠲࠱࠴ᝓ")*LAZHPhtuI3*t3t986iTduqY//UFz73jEX8a//mmbcsf2pd7gyjzreB(u"࠱࠱࠲࠱࠴ᝓ"))+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࠠࡎࡄࠪ፛"))
			tKObfFRod18ZU.close()
		XAbSTLwjmJDs8WgraYFn.close()
		if len(oBcJm1ZKb4ifkXxtzIMDGAdq3vNj)<pXGclhjnWmUwM and pXGclhjnWmUwM>xn867tCVlscY4qbWZfh:
			SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,mmbcsf2pd7gyjzreB(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡵࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡥࡹࡀࠠ࡜ࠢࠪ፜")+str(len(oBcJm1ZKb4ifkXxtzIMDGAdq3vNj)//XfoEk6pQmbLA)+mmbcsf2pd7gyjzreB(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉࡶࡴࡳࠠࡵࡱࡷࡥࡱࠦ࡯ࡧ࠼ࠣ࡟ࠥ࠭፝")+iQV7sZJfuqLpjme6F93POrIRz+TeYukOUW7i5NBM926DCjaAn0(u"ࠩࠣࡑࡇࠦ࡝ࠨ፞"))
			QA7oZDp3bUzwFde5ymVf = yc8Ph4rFsCIvQbOA(gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"ࠪษ้เวย๋ࠢาึ๎ฬࠨ፟"),YZXtBgvUPoM5sb(u"ࠫฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠫ፠"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬหูศัฬࠤั๊ศࠡษ็้้็ࠧ፡"),e1nNXbPrBVDZw,YZXtBgvUPoM5sb(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪ።")+str(len(oBcJm1ZKb4ifkXxtzIMDGAdq3vNj)//XfoEk6pQmbLA)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭፣")+iQV7sZJfuqLpjme6F93POrIRz+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪ፤"))
			if QA7oZDp3bUzwFde5ymVf==dNx9DVCtafk4r: oBcJm1ZKb4ifkXxtzIMDGAdq3vNj = EckxoYzjdgLH0r(sodfwxQDVXyIkJ6,D6eSPULGzKbwjIV9Ao1lc,showDialogs)
			elif QA7oZDp3bUzwFde5ymVf==jxCVeKSLb9rGDOl0Qtw6: SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,iiLyoNwGbH03DIXhAkZn(u"ࠩ࠱ࡠࡹࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ፥"))
			else: return gby0BnUuTNFk
			if not oBcJm1ZKb4ifkXxtzIMDGAdq3vNj: return gby0BnUuTNFk
		else: SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧ፦")+iQV7sZJfuqLpjme6F93POrIRz+OUFxZPuXDoGAbRz(u"ࠫࠥࡓࡂࠡ࡟ࠪ፧"))
	return oBcJm1ZKb4ifkXxtzIMDGAdq3vNj
def m6dqbyG8MTRKVtDH3xJYAOnujCo(CC3nOPFMovd72u):
	return tKObfFRod18ZU
def mJNpiuFnh2GqT(mpJ0w5ZMqU83TuOoxdXbv=gby0BnUuTNFk):
	if wAcHkmPB8a.GEOLOCATION_DATA: return wAcHkmPB8a.GEOLOCATION_DATA
	AjUSIColdvhFyDQWuJ,qqXs9KORkeyc,hmAJWybSwzx,pBCg5MLUW8,IKP5JUobFnhM,FFu3JvBdTPGbUCEH = gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	KKFPNRzufO = i80mE7lHUwVk(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ፨")+mpJ0w5ZMqU83TuOoxdXbv+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ፩")
	D6eSPULGzKbwjIV9Ao1lc = {i80mE7lHUwVk(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ፪"):gby0BnUuTNFk}
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,iI7tuF0nEQoR(u"ࠨࡉࡈࡘࠬ፫"),KKFPNRzufO,gby0BnUuTNFk,D6eSPULGzKbwjIV9Ao1lc,gby0BnUuTNFk,gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ፬"))
	if not tKObfFRod18ZU.succeeded:
		KKFPNRzufO = iI7tuF0nEQoR(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵ࠳ࡡࡱ࡫࠱ࡧࡴࡳ࠯࡫ࡵࡲࡲ࠴࠭፭")+mpJ0w5ZMqU83TuOoxdXbv+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡄ࡬ࡩࡦ࡮ࡧࡷࡂࡷࡵࡦࡴࡼ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧ࠯ࡧ࡮ࡺࡹ࠭ࡱࡩࡪࡸ࡫ࡴࠨ፮")
		tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡍࡅࡕࠩ፯"),KKFPNRzufO,gby0BnUuTNFk,D6eSPULGzKbwjIV9Ao1lc,gby0BnUuTNFk,gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠸࡮ࡥࠩ፰"))
	if tKObfFRod18ZU.succeeded:
		jS6fQGXeouTB7xKd32ZMy = tKObfFRod18ZU.content
		try: DyXnIeAfxqmwCThk6O = FoCsyPaNjhWf.loads(jS6fQGXeouTB7xKd32ZMy)
		except: DyXnIeAfxqmwCThk6O = FoCsyPaNjhWf.loads(jS6fQGXeouTB7xKd32ZMy.decode(i80mE7lHUwVk(u"ࠧࡶࡶࡩ࠱࠽࠳ࡳࡪࡩࠪ፱")))
		vh3OMZpf5jiCWuQJ8m = list(DyXnIeAfxqmwCThk6O.keys())
		if mmbcsf2pd7gyjzreB(u"ࠨ࡫ࡳࠫ፲") in vh3OMZpf5jiCWuQJ8m: mpJ0w5ZMqU83TuOoxdXbv = DyXnIeAfxqmwCThk6O[ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩ࡬ࡴࠬ፳")]
		if MlTVLBZ92kzorIq1Yw(u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭፴") in vh3OMZpf5jiCWuQJ8m: AjUSIColdvhFyDQWuJ = DyXnIeAfxqmwCThk6O[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ፵")]
		if RRbvqditj184m3(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭፶") in vh3OMZpf5jiCWuQJ8m: qqXs9KORkeyc = DyXnIeAfxqmwCThk6O[oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ፷")]
		if mmbcsf2pd7gyjzreB(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭፸") in vh3OMZpf5jiCWuQJ8m: hmAJWybSwzx = DyXnIeAfxqmwCThk6O[BarIC3eR9bS(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧ፹")]
		if n6JjFHfmydIaLut(u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ፺") in vh3OMZpf5jiCWuQJ8m: pBCg5MLUW8 = DyXnIeAfxqmwCThk6O[nJF7oflOk6cLGSAey(u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ፻")]
		if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠫࡨ࡯ࡴࡺࠩ፼") in vh3OMZpf5jiCWuQJ8m: IKP5JUobFnhM = DyXnIeAfxqmwCThk6O[iI7tuF0nEQoR(u"ࠬࡩࡩࡵࡻࠪ፽")]
		if zDSw8LCxMQyraeXhojIWKmU(u"࠭ࡱࡶࡧࡵࡽࠬ፾") in vh3OMZpf5jiCWuQJ8m: mpJ0w5ZMqU83TuOoxdXbv = DyXnIeAfxqmwCThk6O[n6JjFHfmydIaLut(u"ࠧࡲࡷࡨࡶࡾ࠭፿")]
		if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠭ᎀ") in vh3OMZpf5jiCWuQJ8m: hmAJWybSwzx = DyXnIeAfxqmwCThk6O[iiauUxMktNW5X(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡆࡳࡩ࡫ࠧᎁ")]
		if uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠧᎂ") in vh3OMZpf5jiCWuQJ8m: pBCg5MLUW8 = DyXnIeAfxqmwCThk6O[mmbcsf2pd7gyjzreB(u"ࠫࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥࠨᎃ")]
		if BarIC3eR9bS(u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᎄ") in vh3OMZpf5jiCWuQJ8m:
			FFu3JvBdTPGbUCEH = DyXnIeAfxqmwCThk6O[TeYukOUW7i5NBM926DCjaAn0(u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨᎅ")][KJLkQsqSHMR1Np2(u"ࠧࡶࡶࡦࠫᎆ")]
			if FFu3JvBdTPGbUCEH[xn867tCVlscY4qbWZfh] not in [ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨ࠯ࠪᎇ"),nJF7oflOk6cLGSAey(u"ࠩ࠮ࠫᎈ")]: FFu3JvBdTPGbUCEH = q2qPkMFpR1G86dEAKXHivor9N(u"ࠪ࠯ࠬᎉ")+FFu3JvBdTPGbUCEH
		if oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡴ࡬ࡦࡴࡧࡷࠫᎊ") in vh3OMZpf5jiCWuQJ8m:
			FFu3JvBdTPGbUCEH = DyXnIeAfxqmwCThk6O[zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡵࡦࡧࡵࡨࡸࠬᎋ")]
			if FFu3JvBdTPGbUCEH>=sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠱᝔"): FFu3JvBdTPGbUCEH = nJF7oflOk6cLGSAey(u"࠭ࠫࠨᎌ")+RyfYSek61do5OnQMc.strftime(zDSw8LCxMQyraeXhojIWKmU(u"ࠢࠦࡊ࠽ࠩࡒࠨᎍ"),RyfYSek61do5OnQMc.gmtime(FFu3JvBdTPGbUCEH))
			else: FFu3JvBdTPGbUCEH = VzO1gCHmjZ2ebRIL(u"ࠨ࠯ࠪᎎ")+RyfYSek61do5OnQMc.strftime(ggtuNcvTn3HQ7SpE2(u"ࠤࠨࡌ࠿ࠫࡍࠣᎏ"),RyfYSek61do5OnQMc.gmtime(-FFu3JvBdTPGbUCEH))
	PbTnHF8jfmL9YkagJl3QGixKVEM = mpJ0w5ZMqU83TuOoxdXbv+n6JjFHfmydIaLut(u"ࠪ࠰࠱࠭᎐")+AjUSIColdvhFyDQWuJ+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫ࠱࠲ࠧ᎑")+qqXs9KORkeyc+zDSw8LCxMQyraeXhojIWKmU(u"ࠬ࠲ࠬࠨ᎒")+pBCg5MLUW8+iiauUxMktNW5X(u"࠭ࠬ࠭ࠩ᎓")+IKP5JUobFnhM+IXE6voNmrb182AyQ(u"ࠧ࠭࠮ࠪ᎔")+FFu3JvBdTPGbUCEH
	PbTnHF8jfmL9YkagJl3QGixKVEM = PbTnHF8jfmL9YkagJl3QGixKVEM.encode(JJQFjSIlALchiMzG9)
	if nqkybtoMBH: PbTnHF8jfmL9YkagJl3QGixKVEM = PbTnHF8jfmL9YkagJl3QGixKVEM.decode(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ᎕"))
	wAcHkmPB8a.GEOLOCATION_DATA = biVjhGCg0v5eEzkHwTrK9FIAtPU2(PbTnHF8jfmL9YkagJl3QGixKVEM)
	return wAcHkmPB8a.GEOLOCATION_DATA
def ZZV4kLG1nmbIjt(CN1viZryLhMdKRQFqXPOJ):
	ZIC4pA8Haj7WJ6rdRv2YNQ0,showDialogs = gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4
	if CN1viZryLhMdKRQFqXPOJ.count(IXE6voNmrb182AyQ(u"ࠩࡢࠫ᎖"))>=dNx9DVCtafk4r:
		CN1viZryLhMdKRQFqXPOJ,ZIC4pA8Haj7WJ6rdRv2YNQ0 = CN1viZryLhMdKRQFqXPOJ.split(RRbvqditj184m3(u"ࠪࡣࠬ᎗"),jxCVeKSLb9rGDOl0Qtw6)
		ZIC4pA8Haj7WJ6rdRv2YNQ0 = RRbvqditj184m3(u"ࠫࡤ࠭᎘")+ZIC4pA8Haj7WJ6rdRv2YNQ0
		if OUFxZPuXDoGAbRz(u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ᎙") in ZIC4pA8Haj7WJ6rdRv2YNQ0: showDialogs = yrcbRSFswvAfEdIWVj
		else: showDialogs = w8Ui6RsVhSPrqHfO4
	return CN1viZryLhMdKRQFqXPOJ,ZIC4pA8Haj7WJ6rdRv2YNQ0,showDialogs
def zwDxtdB8C3LA():
	o0WAEei5KqwlRpPHZfmYUDyj6h = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,NupI74tJCzYXmles9SbR6(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ᎚"))
	CU3fjutQVEg7eavn9r5kWD0NB46GSp = xn867tCVlscY4qbWZfh
	if bCoOHfPdMryRgauz0IVpth.path.exists(o0WAEei5KqwlRpPHZfmYUDyj6h):
		for eGqj6NWXtO8Mogcu3yrwlRUbS9kh in bCoOHfPdMryRgauz0IVpth.listdir(o0WAEei5KqwlRpPHZfmYUDyj6h):
			if IXE6voNmrb182AyQ(u"ࠧ࠯ࡲࡼࡳࠬ᎛") in eGqj6NWXtO8Mogcu3yrwlRUbS9kh: continue
			if tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡡࡢࡴࡾࡩࡡࡤࡪࡨࡣࡤ࠭᎜") in eGqj6NWXtO8Mogcu3yrwlRUbS9kh: continue
			jWgYyKu57Gr9ARzLMs = bCoOHfPdMryRgauz0IVpth.path.join(o0WAEei5KqwlRpPHZfmYUDyj6h,eGqj6NWXtO8Mogcu3yrwlRUbS9kh)
			zpIA5HVDERf3K,ZZYB0cKL9nkA1dxaovh58HztwS = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(jWgYyKu57Gr9ARzLMs)
			CU3fjutQVEg7eavn9r5kWD0NB46GSp += zpIA5HVDERf3K
	return CU3fjutQVEg7eavn9r5kWD0NB46GSp
def xnKMIOTmSWPqENY(showDialogs):
	mxdMOnctBi96S3ENF2 = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ᎝"))
	htPCO9oBJHqgE28Dbw4aFKyUn7X = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡷࡹࡸࠧ᎞"),mmbcsf2pd7gyjzreB(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩ᎟"),FAwWlRJg0UkN1(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᎠ"))
	XC0NqAosyDb7YQWfHeFSGBVdRrhct,U07OSRcykazPvQiFBH8GxljfKN = mxdMOnctBi96S3ENF2,htPCO9oBJHqgE28Dbw4aFKyUn7X
	bvlxi43nkw1tjBJ6So7RPHQcGW,NVAYMji16LD9 = gby0BnUuTNFk,gby0BnUuTNFk
	if RRbvqditj184m3(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᎡ") not in str(wAcHkmPB8a.SEND_THESE_EVENTS):
		KKFPNRzufO = wAcHkmPB8a.SITESURLS[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᎢ")][jJ4LEcdl5w7BPMbQ]
		JKTRUIfhmnSApPD5cr = mJNpiuFnh2GqT()
		qqXs9KORkeyc = JKTRUIfhmnSApPD5cr.split(MlTVLBZ92kzorIq1Yw(u"ࠨ࠮࠯ࠫᎣ"))[dNx9DVCtafk4r]
		CU3fjutQVEg7eavn9r5kWD0NB46GSp = zwDxtdB8C3LA()
		DI1M026yiGjnZXhTc58 = {NupI74tJCzYXmles9SbR6(u"ࠩࡸࡷࡪࡸࠧᎤ"):wAcHkmPB8a.AV_CLIENT_IDS,iI7tuF0nEQoR(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᎥ"):eQNGiXdboqPt57O,mmbcsf2pd7gyjzreB(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᎦ"):qqXs9KORkeyc,i80mE7lHUwVk(u"ࠬ࡯ࡤࡴࠩᎧ"):DhxNVwJ7EQULzCK8acfiPZkM20sYg(CU3fjutQVEg7eavn9r5kWD0NB46GSp)}
		tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,MlTVLBZ92kzorIq1Yw(u"࠭ࡐࡐࡕࡗࠫᎨ"),KKFPNRzufO,DI1M026yiGjnZXhTc58,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫᎩ"))
		if not tKObfFRod18ZU.succeeded:
			if mxdMOnctBi96S3ENF2 in [gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"ࠨࡐࡈ࡛ࠬᎪ")]: XC0NqAosyDb7YQWfHeFSGBVdRrhct = iiauUxMktNW5X(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᎫ")
			elif mxdMOnctBi96S3ENF2==n6JjFHfmydIaLut(u"ࠪࡓࡑࡊࠧᎬ"): XC0NqAosyDb7YQWfHeFSGBVdRrhct = VzO1gCHmjZ2ebRIL(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᎭ")
		else:
			dpYRZ74zheOrxVEXW = tKObfFRod18ZU.content
			dpYRZ74zheOrxVEXW = TqNUy3Z4SFWvplGwXC82A(ne7wF4gSTRZo(u"ࠬࡲࡩࡴࡶࠪᎮ"),dpYRZ74zheOrxVEXW)
			dpYRZ74zheOrxVEXW = sorted(dpYRZ74zheOrxVEXW,reverse=w8Ui6RsVhSPrqHfO4,key=lambda key: int(key[xn867tCVlscY4qbWZfh]))
			NVAYMji16LD9,U07OSRcykazPvQiFBH8GxljfKN = gby0BnUuTNFk,gby0BnUuTNFk
			for reiQfNsbjvx2GqmJuW30T9k4,oQ2KrSVCjpDnvw8hg3aGcW,yl4wARgr1beKpxXCfVZkNTJGDnhz in dpYRZ74zheOrxVEXW:
				if reiQfNsbjvx2GqmJuW30T9k4==tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭࠰ࠨᎯ"):
					NVAYMji16LD9 += yl4wARgr1beKpxXCfVZkNTJGDnhz+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧ࠻࠼ࠪᎰ")
					continue
				if U07OSRcykazPvQiFBH8GxljfKN: U07OSRcykazPvQiFBH8GxljfKN += okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+ggtuNcvTn3HQ7SpE2(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᎱ")+GGy0cQe765nPYZ9E8Th+ggtuNcvTn3HQ7SpE2(u"ࠩ࡟ࡲࡡࡴࠧᎲ")
				brfa52mTeJoPhBFHptkdZuc1S7yl3D = yl4wARgr1beKpxXCfVZkNTJGDnhz.split(okfdjS4RmM)[xn867tCVlscY4qbWZfh]
				ncdIJGErqKHl29NwVCP6uRy0 = KJLkQsqSHMR1Np2(u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧᎳ") if oQ2KrSVCjpDnvw8hg3aGcW else gby0BnUuTNFk
				U07OSRcykazPvQiFBH8GxljfKN += yl4wARgr1beKpxXCfVZkNTJGDnhz.replace(brfa52mTeJoPhBFHptkdZuc1S7yl3D,bKN9diGf8nmgecQPEqUzHRpoDuaO+brfa52mTeJoPhBFHptkdZuc1S7yl3D+ncdIJGErqKHl29NwVCP6uRy0+GGy0cQe765nPYZ9E8Th)+okfdjS4RmM
			U07OSRcykazPvQiFBH8GxljfKN = okfdjS4RmM+U07OSRcykazPvQiFBH8GxljfKN+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡡࡴ࡜࡯ࠩᎴ")
			NVAYMji16LD9 = NVAYMji16LD9.strip(ggtuNcvTn3HQ7SpE2(u"ࠬࡀ࠺ࠨᎵ"))
			bvlxi43nkw1tjBJ6So7RPHQcGW = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(OUFxZPuXDoGAbRz(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩᎶ"))
			if U07OSRcykazPvQiFBH8GxljfKN==htPCO9oBJHqgE28Dbw4aFKyUn7X and mxdMOnctBi96S3ENF2 in [zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡐࡎࡇࠫᎷ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᎸ")]: XC0NqAosyDb7YQWfHeFSGBVdRrhct = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡒࡐࡉ࠭Ꮉ")
			else: XC0NqAosyDb7YQWfHeFSGBVdRrhct = FAwWlRJg0UkN1(u"ࠪࡒࡊ࡝ࠧᎺ")
			CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,nJF7oflOk6cLGSAey(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩᎻ"),RRbvqditj184m3(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᎼ"),U07OSRcykazPvQiFBH8GxljfKN,Z83rChqtg1oXUjI4YL)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᎽ"),DhxNVwJ7EQULzCK8acfiPZkM20sYg(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪᎾ"),NVAYMji16LD9)
			y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(NupI74tJCzYXmles9SbR6(u"࠷᝕")*NVAYMji16LD9.encode(JJQFjSIlALchiMzG9)).hexdigest()
			y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(FAwWlRJg0UkN1(u"࠴࠸᝖")*y0HETYJ4Crxi6RKvOMgGzBIeZ.encode(JJQFjSIlALchiMzG9)).hexdigest()
			y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(kreQUwJis7YmC2yqWtIF09pgjbD(u"࠵࠾᝗")*y0HETYJ4Crxi6RKvOMgGzBIeZ.encode(JJQFjSIlALchiMzG9)).hexdigest()
			DEOf7aYR4rZXubkAHBUMzhlmCgK,MnOPIpuYDZFJ = d7avUpQLRnJM(la983tXRDchGbrdIFQJf7kHeE)
			oYuwtBRKxPD1yl(la983tXRDchGbrdIFQJf7kHeE,DEOf7aYR4rZXubkAHBUMzhlmCgK,MnOPIpuYDZFJ,yrcbRSFswvAfEdIWVj,BarIC3eR9bS(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠪᎿ")+str(int(y0HETYJ4Crxi6RKvOMgGzBIeZ[FAwWlRJg0UkN1(u"࠹᝙"):tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠱࠳᝚")],zDSw8LCxMQyraeXhojIWKmU(u"࠲࠸᝛")))[:i80mE7lHUwVk(u"࠾᝘")]+ne7wF4gSTRZo(u"ࠩࠣ࠿ࠬᏀ"))
			DEOf7aYR4rZXubkAHBUMzhlmCgK.close()
		YYCbX4UkizGclntjdTgH = w8Ui6RsVhSPrqHfO4 if NVAYMji16LD9!=bvlxi43nkw1tjBJ6So7RPHQcGW else yrcbRSFswvAfEdIWVj
		if YYCbX4UkizGclntjdTgH:
			nqUosdE12cK5eFP3vNbaL4IH = wAcHkmPB8a.NiXZIL0GzwCV
			wAcHkmPB8a.D9ZNeIiFunAftqWhB8Q,wAcHkmPB8a.NiXZIL0GzwCV,wAcHkmPB8a.UdPmqCi4yVlQaf,wAcHkmPB8a.ekiYyQnB4E2W830DC,wAcHkmPB8a.avprivsnorestrict,wAcHkmPB8a.avprivslongperiod = ayxBPWM2QHfTS3E8GbZl([mmbcsf2pd7gyjzreB(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫᏁ"),IXE6voNmrb182AyQ(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬᏂ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪᏃ"),ggtuNcvTn3HQ7SpE2(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧᏄ"),i80mE7lHUwVk(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡬࡮ࡇ࡚ࡊ࡜ࡅ࡙ࠩᏅ"),RRbvqditj184m3(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧᏆ")])
			iJK3TOuVAHXBkbonUE8lwSNzCp = wAcHkmPB8a.NiXZIL0GzwCV
			if not nqUosdE12cK5eFP3vNbaL4IH and iJK3TOuVAHXBkbonUE8lwSNzCp and q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧᏇ") in wAcHkmPB8a.SEND_THESE_EVENTS:
				wAcHkmPB8a.SEND_THESE_EVENTS.remove(n6JjFHfmydIaLut(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᏈ"))
				wAcHkmPB8a.SEND_THESE_EVENTS.append(RRbvqditj184m3(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭Ꮙ"))
			elif nqUosdE12cK5eFP3vNbaL4IH and not iJK3TOuVAHXBkbonUE8lwSNzCp and tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᏊ") in wAcHkmPB8a.SEND_THESE_EVENTS:
				wAcHkmPB8a.SEND_THESE_EVENTS.remove(nJF7oflOk6cLGSAey(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᏋ"))
				wAcHkmPB8a.SEND_THESE_EVENTS.append(BarIC3eR9bS(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᏌ"))
			nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	if showDialogs:
		if XC0NqAosyDb7YQWfHeFSGBVdRrhct in [iiLyoNwGbH03DIXhAkZn(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᏍ"),iiLyoNwGbH03DIXhAkZn(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᏎ")]:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,VzO1gCHmjZ2ebRIL(u"๋๋ࠪอใࠡ็ื็้ฯࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํะ่ࠢสฺ่๊ใๅหࠣๆิ๊ࠦไ๊้ࠤุฮศ่ษࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣห้ืว้ฬิࠤฬ๊ฮศืࠣฬ่ࠦรุ้่่๊ࠢษࠡใํࠤฬ๊ริๆส็ࠥ฿ๆะๅࠪᏏ"))
		else:
			sbqP27kMUtTxS0dyYO(n6JjFHfmydIaLut(u"ࠫࡷ࡯ࡧࡩࡶࠪᏐ"),mmbcsf2pd7gyjzreB(u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨᏑ"),U07OSRcykazPvQiFBH8GxljfKN,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧᏒ"))
			XC0NqAosyDb7YQWfHeFSGBVdRrhct = YZXtBgvUPoM5sb(u"ࠧࡐࡎࡇࠫᏓ")
	if XC0NqAosyDb7YQWfHeFSGBVdRrhct!=mxdMOnctBi96S3ENF2:
		SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(VzO1gCHmjZ2ebRIL(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭Ꮤ"),XC0NqAosyDb7YQWfHeFSGBVdRrhct)
		nR4jOE8geFDJhKIuisTc2ZPa(yrcbRSFswvAfEdIWVj)
	return
def Xa2nju83yQLEKgMhC65PbcqzIRJ(Xnv4AQJeLGuZOMpDx72oH,gg6BsId5tceL):
	import socket as RLP7vbMuqwBJNgK0aeIGks65
	ppo8escbBr4nJF70QSvlEzyYHADK = RLP7vbMuqwBJNgK0aeIGks65.socket(RLP7vbMuqwBJNgK0aeIGks65.AF_INET,RLP7vbMuqwBJNgK0aeIGks65.SOCK_STREAM)
	ppo8escbBr4nJF70QSvlEzyYHADK.settimeout(jJ4LEcdl5w7BPMbQ)
	try:
		LjWyqBVS3gE = RyfYSek61do5OnQMc.time()
		ppo8escbBr4nJF70QSvlEzyYHADK.connect((Xnv4AQJeLGuZOMpDx72oH,gg6BsId5tceL))
		exsMgRLzThpqD1FfIQVPXl9n0a73B = RyfYSek61do5OnQMc.time()
		DpIwf4n7XOuL8xE1dPvYWFsi3 = round((exsMgRLzThpqD1FfIQVPXl9n0a73B-LjWyqBVS3gE)*q2qPkMFpR1G86dEAKXHivor9N(u"࠳࠳࠴࠵᝜"))
	except: DpIwf4n7XOuL8xE1dPvYWFsi3 = -jxCVeKSLb9rGDOl0Qtw6
	ppo8escbBr4nJF70QSvlEzyYHADK.close()
	return DpIwf4n7XOuL8xE1dPvYWFsi3
def Cjio8VzFbEgRfTNH3UrDJMZ(showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨᏕ"))
	else: PpQu9EkGTxa = w8Ui6RsVhSPrqHfO4
	if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
		for eGqj6NWXtO8Mogcu3yrwlRUbS9kh in bCoOHfPdMryRgauz0IVpth.listdir(jjzt6rqdQKM):
			if eGqj6NWXtO8Mogcu3yrwlRUbS9kh.endswith(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪ࠲ࡩࡨࠧᏖ")) and ggtuNcvTn3HQ7SpE2(u"ࠫࡩࡧࡴࡢࠩᏗ") in eGqj6NWXtO8Mogcu3yrwlRUbS9kh:
				BBvciMA6ZPbzna = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,eGqj6NWXtO8Mogcu3yrwlRUbS9kh)
				DEOf7aYR4rZXubkAHBUMzhlmCgK,MnOPIpuYDZFJ = d7avUpQLRnJM(BBvciMA6ZPbzna)
				MnOPIpuYDZFJ.execute(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡬࡯ࡳࡧ࡬࡫ࡳࡥ࡫ࡦࡻࡶࡁࡳࡵ࠻ࠨᏘ"))
				MnOPIpuYDZFJ.execute(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫᏙ"))
				MnOPIpuYDZFJ.execute(n6JjFHfmydIaLut(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪᏚ"))
				MnOPIpuYDZFJ.execute(iI7tuF0nEQoR(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫᏛ"))
				MnOPIpuYDZFJ.execute(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪᏜ"))
				DEOf7aYR4rZXubkAHBUMzhlmCgK.commit()
				DEOf7aYR4rZXubkAHBUMzhlmCgK.close()
		if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫᏝ"))
	return
def zyZYjwM8GFn(efjl9KD7hs0B8otHvidLInwW,lm1e9S8Yt0r7DXKzpdh4CcEbu2GNZ5,showDialogs):
	if efjl9KD7hs0B8otHvidLInwW!=MjwcelItRYVzaPG9QFs1yvSrD74A:
		if efjl9KD7hs0B8otHvidLInwW==ygrt5mUZHAdjkfb1: wAcHkmPB8a.ALLOW_DNS_FIX = w8Ui6RsVhSPrqHfO4
		elif efjl9KD7hs0B8otHvidLInwW==qrejGtHg2Z: wAcHkmPB8a.ALLOW_DNS_FIX = yrcbRSFswvAfEdIWVj
		elif efjl9KD7hs0B8otHvidLInwW==H14j5s97qxM: wAcHkmPB8a.ALLOW_DNS_FIX = w8Ui6RsVhSPrqHfO4
	if lm1e9S8Yt0r7DXKzpdh4CcEbu2GNZ5!=MjwcelItRYVzaPG9QFs1yvSrD74A:
		if lm1e9S8Yt0r7DXKzpdh4CcEbu2GNZ5==ygrt5mUZHAdjkfb1: wAcHkmPB8a.ALLOW_PROXY_FIX = w8Ui6RsVhSPrqHfO4
		elif lm1e9S8Yt0r7DXKzpdh4CcEbu2GNZ5==qrejGtHg2Z: wAcHkmPB8a.ALLOW_PROXY_FIX = yrcbRSFswvAfEdIWVj
		elif lm1e9S8Yt0r7DXKzpdh4CcEbu2GNZ5==H14j5s97qxM: wAcHkmPB8a.ALLOW_PROXY_FIX = w8Ui6RsVhSPrqHfO4
	if showDialogs!=MjwcelItRYVzaPG9QFs1yvSrD74A:
		if showDialogs==ygrt5mUZHAdjkfb1: wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX = w8Ui6RsVhSPrqHfO4
		elif showDialogs==qrejGtHg2Z: wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX = yrcbRSFswvAfEdIWVj
		elif showDialogs==H14j5s97qxM: wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX = w8Ui6RsVhSPrqHfO4
	return
def YVRgrlZeFUDfkxXnshjP(yPo2zE8c7SekvbiNLqRJ9jUZ,CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,args):
	ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc = args
	s1sOl7vNWHP3rqT6unZ = bTh6JaVi1mOoCEeKZ4kS8AWsnl.split(NupI74tJCzYXmles9SbR6(u"ࠫ࠲࠭Ꮮ"))[xn867tCVlscY4qbWZfh]
	OFisAducwGY8L0XJKV = VzO1gCHmjZ2ebRIL(u"ู๊ࠬาใิࠤึ่ๅࠡࠩᏟ")+str(yPo2zE8c7SekvbiNLqRJ9jUZ)
	uxfIeVwzarRngd7y = oHSEYlfpLzQrC1(Tf5ueYGZIFl1hraoEOVKi,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
	SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+ggtuNcvTn3HQ7SpE2(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᏠ")+str(yPo2zE8c7SekvbiNLqRJ9jUZ)+RRbvqditj184m3(u"ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᏡ")+str(g8E2PLGXKpYsZnAHjtol)+nJF7oflOk6cLGSAey(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᏢ")+PJnMHzOorxmLAwc+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᏣ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+mmbcsf2pd7gyjzreB(u"ࠪࠤࡢࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᏤ")+uxfIeVwzarRngd7y+iiLyoNwGbH03DIXhAkZn(u"ࠫࠥࡣࠧᏥ"))
	update = w8Ui6RsVhSPrqHfO4
	if yPo2zE8c7SekvbiNLqRJ9jUZ==xn867tCVlscY4qbWZfh:
		scraperserver = mmbcsf2pd7gyjzreB(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠲ࠩᏦ")
		ooygizROP0KNZVAl = MlTVLBZ92kzorIq1Yw(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠵࠺࠶ࡤ࠳࠴ࡩ࠵࠲ࡩ࠵࠹ࡣ࠰࠸࠵࠸࠱࠮ࡣࡤ࠼࠹࠳ࡥ࠺࠴࠶ࡧࡦ࡬࠸࠶࠺࠶࠸ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᏧ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+i80mE7lHUwVk(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᏨ")+ooygizROP0KNZVAl+ne7wF4gSTRZo(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᏩ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==jxCVeKSLb9rGDOl0Qtw6:
		scraperserver = OUFxZPuXDoGAbRz(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠷࠭Ꮺ")
		ooygizROP0KNZVAl = ggtuNcvTn3HQ7SpE2(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠱ࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲ࠺࠴࠻࠼࠵ࡪ࠿ࡣ࠶࠯࠺ࡩࡪ࠹࠭࠵ࡧࡨ࠶࠲࠾࠴ࡤ࠲࠰ࡪࡩ࠽࠹࠳ࡤࡤࡨࡩ࠹ࡤ࠶ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠺࠶࠵࠸࠷ࠬᏫ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+YZXtBgvUPoM5sb(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᏬ")+ooygizROP0KNZVAl+q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᏭ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==dNx9DVCtafk4r:
		scraperserver = RRbvqditj184m3(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪᏮ")
		ooygizROP0KNZVAl = zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭Ꮿ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+MlTVLBZ92kzorIq1Yw(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᏰ")+ooygizROP0KNZVAl+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᏱ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==jJ4LEcdl5w7BPMbQ:
		scraperserver = i80mE7lHUwVk(u"ࠪࡷࡨࡸࡡࡱࡧࡸࡴࠬᏲ")
		mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi.replace(VzO1gCHmjZ2ebRIL(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭Ᏻ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭Ᏼ"))
		gAomMHK9Z3OWsv8ciEpGFqIb = VzO1gCHmjZ2ebRIL(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡨࡸࡡࡱࡧࡸࡴ࠳ࡩ࡯࡮࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁ࠶࡜ࡎࡴࡏࡷࡐ࠶ࡵࡂࡓ࡚࡮ࡗࡓࡉࡢࡄࡏࡍ࠵ࡐ࡞࡙ࡋ࡬࡭࠴ࡩࡰ࡚ࡸࠨ࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡈࡤࡰࡸ࡫ࠦࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᏵ")+IcChbXakUDFLszgpSG2jqem9(mm7pzl3HMi0R8fGu)
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧࡈࡇࡗࠫ᏶"),gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==z5RruqXvsLaTf7e9c:
		scraperserver = zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴࠨ᏷")
		gAomMHK9Z3OWsv8ciEpGFqIb = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠴ࡣࡰ࡯࠲ࡃࡹࡵ࡫ࡦࡰࡀࡥ࠹࡬࠷ࡧࡤ࠴࠸࠲࠸ࡤࡦࡨ࠰࠸࠵࠽࠱࠮࠺࠹࠸ࡧ࠳࠲࠳ࡧ࠶࠶࠻࠺ࡤ࠵ࡦࡧࡧࠫࡶࡲࡰࡺࡼࡇࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡶࡴ࡯ࡁࠬᏸ")+IcChbXakUDFLszgpSG2jqem9(Tf5ueYGZIFl1hraoEOVKi)
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(VzO1gCHmjZ2ebRIL(u"ࠪࡋࡊ࡚ࠧᏹ"),gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
		try:
			gWw6GZvoB9xXs5KPk = FoCsyPaNjhWf.loads(ucIWpqewQgsGBC9bNP0JKF.content)
			ucIWpqewQgsGBC9bNP0JKF.content = gWw6GZvoB9xXs5KPk.get(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᏺ"),gby0BnUuTNFk)
			suLhCvx6Iw = sum(KNPgC0FwqTL7SyiE8JH5WzsO3uZDV < oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࠦࠧᏻ") and KNPgC0FwqTL7SyiE8JH5WzsO3uZDV not in oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭࡜ࡳ࡞ࡱࡠࡹ࠭ᏼ") for KNPgC0FwqTL7SyiE8JH5WzsO3uZDV in ucIWpqewQgsGBC9bNP0JKF.content[:iiLyoNwGbH03DIXhAkZn(u"࠴࠴࠵࠶᝝")])
			if suLhCvx6Iw > OUFxZPuXDoGAbRz(u"࠵࠵᝞"):
				ucIWpqewQgsGBC9bNP0JKF = PKSnHM3QkOgGUyABi12slV()
				ucIWpqewQgsGBC9bNP0JKF.succeeded = yrcbRSFswvAfEdIWVj
				ucIWpqewQgsGBC9bNP0JKF.content = gby0BnUuTNFk
		except: pass
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==DVbaycS5iITnPMRsdueXqg1wQx6ltr:
		scraperserver = RRbvqditj184m3(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠶࠭ᏽ")
		ooygizROP0KNZVAl = IXE6voNmrb182AyQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡥࡶࡴࡽࡳࡦࡴࡀࡊࡦࡲࡳࡦࠨࡩࡳࡷࡽࡡࡳࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠼࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠲ࡨࡵ࡭࠻࠺࠳࠼࠵࠭᏾")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+NupI74tJCzYXmles9SbR6(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ᏿")+ooygizROP0KNZVAl+zDSw8LCxMQyraeXhojIWKmU(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ᐀")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==VzO1gCHmjZ2ebRIL(u"࠻᝟"):
		scraperserver = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠱ࠨᐁ")
		ooygizROP0KNZVAl = n6JjFHfmydIaLut(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡣ࠳࠸࠶ࡥࡧ࠷ࡥ࠶࠲࠷࠸ࡩ࠸ࡣࡢ࠷ࡧ࠹ࡩ࠹ࡦ࠺ࡧ࠶ࡧ࠸࠾࠶ࡦࡥࡤ࠵࠶࠶࠸࠴࠺࠼ࡥ࠼࠹࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩࠫ࡭ࡥࡰࡅࡲࡨࡪࡃࡩ࡭ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩᐂ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+iI7tuF0nEQoR(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᐃ")+ooygizROP0KNZVAl+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᐄ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==YZXtBgvUPoM5sb(u"࠽ᝠ"):
		scraperserver = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬᐅ")
		ooygizROP0KNZVAl = YZXtBgvUPoM5sb(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦࠨࡪࡩࡴࡉ࡯ࡥࡧࡀ࡭ࡱࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ᐆ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᐇ")+ooygizROP0KNZVAl+BarIC3eR9bS(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᐈ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==mmbcsf2pd7gyjzreB(u"࠸ᝡ"):
		scraperserver = n6JjFHfmydIaLut(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩᐉ")
		gAomMHK9Z3OWsv8ciEpGFqIb = RRbvqditj184m3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᐊ")+IcChbXakUDFLszgpSG2jqem9(Tf5ueYGZIFl1hraoEOVKi)
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(iiauUxMktNW5X(u"ࠧࡈࡇࡗࠫᐋ"),gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==iiauUxMktNW5X(u"࠺ᝢ"):
		scraperserver = iiauUxMktNW5X(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠸ࠧᐌ")
		ooygizROP0KNZVAl = iiLyoNwGbH03DIXhAkZn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡶࡪࡺࡵࡳࡰࡢࡴࡦ࡭ࡥࡠࡵࡲࡹࡷࡩࡥ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪᐍ")
		gAomMHK9Z3OWsv8ciEpGFqIb = Tf5ueYGZIFl1hraoEOVKi+mmbcsf2pd7gyjzreB(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᐎ")+ooygizROP0KNZVAl+MlTVLBZ92kzorIq1Yw(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᐏ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,gAomMHK9Z3OWsv8ciEpGFqIb,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==n6JjFHfmydIaLut(u"࠳࠳ᝣ"):
		scraperserver = zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡹࡣࡳࡣࡳࡴࡪࡿࠧᐐ")
		xmN8TMoaUAjwHGpQ = IciL6hoO5F1MDSVPjypWZs8kKx.copy()
		xmN8TMoaUAjwHGpQ.update({VzO1gCHmjZ2ebRIL(u"࠭ࡘ࠮ࡔࡤࡴ࡮ࡪࡡࡱ࡫࠰ࡌࡴࡹࡴࠨᐑ"):iiauUxMktNW5X(u"ࠧࡴࡥࡵࡥࡵࡶࡥࡺ࠯ࡦࡳࡲ࠴ࡰ࠯ࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧᐒ"),iI7tuF0nEQoR(u"ࠨ࡚࠰ࡖࡦࡶࡩࡥࡣࡳ࡭࠲ࡑࡥࡺࠩᐓ"):GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩ࠷࠸࡫࠺࠰࠹ࡦ࠷ࡥ࠷ࡳࡳࡩ࠳ࡥ࠷ࡧࡪ࠴࠺ࡣ࠹࠸࠽࠷࠷ࡧ࠷ࡳ࠵࠵࠷࠰࠴ࡨ࡭ࡷࡳ࠺ࡡ࠵࠳࠺ࡪࡨ࠻࠳࠱࠶࠵ࠫᐔ"),iI7tuF0nEQoR(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᐕ"):oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧᐖ")})
		XrZ4CFAnRta5oSET9Vwe02lKGh = uWIUplrbFd.copy()
		XrZ4CFAnRta5oSET9Vwe02lKGh.update({q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡩ࡭ࡥࠩᐗ"):tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡲࡦࡳࡸࡩࡸࡺ࠮ࠨᐘ")+ozVQbncL9s8rw5DHa.lower(),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡶࡴ࡯ࠫᐙ"):IcChbXakUDFLszgpSG2jqem9(Tf5ueYGZIFl1hraoEOVKi)})
		YVarCXSDdNL5 = FoCsyPaNjhWf.dumps(XrZ4CFAnRta5oSET9Vwe02lKGh)
		gAomMHK9Z3OWsv8ciEpGFqIb = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡧࡷࡧࡰࡱࡧࡼ࠱ࡨࡵ࡭࠯ࡲ࠱ࡶࡦࡶࡩࡥࡣࡳ࡭࠳ࡩ࡯࡮࠱ࡤࡴ࡮࠵ࡶ࠲ࠩᐚ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠩࡓࡓࡘ࡚ࠧᐛ"),gAomMHK9Z3OWsv8ciEpGFqIb,YVarCXSDdNL5,xmN8TMoaUAjwHGpQ,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
		try:
			gWw6GZvoB9xXs5KPk = FoCsyPaNjhWf.loads(ucIWpqewQgsGBC9bNP0JKF.content)
			ucIWpqewQgsGBC9bNP0JKF.content = gWw6GZvoB9xXs5KPk[nJF7oflOk6cLGSAey(u"ࠪࡷࡴࡲࡵࡵ࡫ࡲࡲࠬᐜ")][zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭ᐝ")]
		except: pass
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==iI7tuF0nEQoR(u"࠴࠵ᝤ"):
		scraperserver = IXE6voNmrb182AyQ(u"ࠬࡸࡥࡱ࡮࡬ࡸ࠵࠷ࠧᐞ")
		xmN8TMoaUAjwHGpQ = IciL6hoO5F1MDSVPjypWZs8kKx.copy()
		xmN8TMoaUAjwHGpQ.update({VzO1gCHmjZ2ebRIL(u"࠭ࡁࡗ࠯ࡈࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ᐟ"):TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠴࠱࠴ࠬᐠ")})
		xmN8TMoaUAjwHGpQ.update({BarIC3eR9bS(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᐡ"):DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬᐢ")})
		XrZ4CFAnRta5oSET9Vwe02lKGh = {MlTVLBZ92kzorIq1Yw(u"ࠪࡳࡺࡺࡰࡶࡶࠪᐣ"):MlTVLBZ92kzorIq1Yw(u"ࠫ࡭ࡺ࡭࡭ࠩᐤ"),n6JjFHfmydIaLut(u"ࠬࡻࡲ࡭ࠩᐥ"):Tf5ueYGZIFl1hraoEOVKi}
		XrZ4CFAnRta5oSET9Vwe02lKGh = FoCsyPaNjhWf.dumps(XrZ4CFAnRta5oSET9Vwe02lKGh)
		XrZ4CFAnRta5oSET9Vwe02lKGh = ffj0JO9pQZW5TAncSDgirsm(XrZ4CFAnRta5oSET9Vwe02lKGh)
		gAomMHK9Z3OWsv8ciEpGFqIb = VzO1gCHmjZ2ebRIL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࠻ࡩ࠼࠶࠽࠷࠵࠯ࡤࡦ࠾࠾࠭࠵࠳ࡧ࠶࠲࠾࠷࠱ࡦ࠰࠺࠷࠻ࡢ࠹࠶࠹࠹࠷࠻࠳࠲࠯࠳࠴࠲࠷࡭ࡪࡥ࠷ࡨࡪࡲ࡬ࡨࡥࡥࡶ࠳ࡰࡡ࡯ࡧࡺࡥࡾ࠴ࡲࡦࡲ࡯࡭ࡹ࠴ࡤࡦࡸ࠲ࡪࡪࡺࡣࡩࠩᐦ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡑࡑࡖࡘࠬᐧ"),gAomMHK9Z3OWsv8ciEpGFqIb,XrZ4CFAnRta5oSET9Vwe02lKGh,xmN8TMoaUAjwHGpQ,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	elif yPo2zE8c7SekvbiNLqRJ9jUZ==iiauUxMktNW5X(u"࠵࠷ᝥ"):
		scraperserver = BarIC3eR9bS(u"ࠨࡴࡤࡧࡰࡴࡥࡳࡦ࠳࠵ࠬᐨ")
		xmN8TMoaUAjwHGpQ = IciL6hoO5F1MDSVPjypWZs8kKx.copy()
		xmN8TMoaUAjwHGpQ.update({tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᐩ"):MlTVLBZ92kzorIq1Yw(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡱࡦࡸࡪࡺ࠭ࡴࡶࡵࡩࡦࡳࠧᐪ")})
		xmN8TMoaUAjwHGpQ.update({nJF7oflOk6cLGSAey(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ᐫ"):i80mE7lHUwVk(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩ࠱ࠦࡢࡳࠩᐬ")})
		xmN8TMoaUAjwHGpQ.update({nJF7oflOk6cLGSAey(u"࠭ࡁࡗ࠯ࡈࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ᐭ"):n6JjFHfmydIaLut(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠴࠱࠴ࠬᐮ")})
		XrZ4CFAnRta5oSET9Vwe02lKGh = {tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࡷࡵࡰࠬᐯ"):Tf5ueYGZIFl1hraoEOVKi,ne7wF4gSTRZo(u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪᐰ"):IciL6hoO5F1MDSVPjypWZs8kKx}
		XrZ4CFAnRta5oSET9Vwe02lKGh = FoCsyPaNjhWf.dumps(XrZ4CFAnRta5oSET9Vwe02lKGh)
		XrZ4CFAnRta5oSET9Vwe02lKGh = ffj0JO9pQZW5TAncSDgirsm(XrZ4CFAnRta5oSET9Vwe02lKGh)
		gAomMHK9Z3OWsv8ciEpGFqIb = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠵࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠿࠷࠸࠲࠷࠲ࡪࡪࡺࡣࡩࠩᐱ")
		ucIWpqewQgsGBC9bNP0JKF = ttzmG8FdPLBD(ggtuNcvTn3HQ7SpE2(u"ࠫࡕࡕࡓࡕࠩᐲ"),gAomMHK9Z3OWsv8ciEpGFqIb,XrZ4CFAnRta5oSET9Vwe02lKGh,xmN8TMoaUAjwHGpQ,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
		update = yrcbRSFswvAfEdIWVj
	else:
		scraperserver,gAomMHK9Z3OWsv8ciEpGFqIb = gby0BnUuTNFk,gby0BnUuTNFk
		ucIWpqewQgsGBC9bNP0JKF = PKSnHM3QkOgGUyABi12slV()
		ucIWpqewQgsGBC9bNP0JKF.succeeded = yrcbRSFswvAfEdIWVj
		update = yrcbRSFswvAfEdIWVj
	if not ucIWpqewQgsGBC9bNP0JKF.content or DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡼࡥࡳ࡫ࡩࡽ࠳࡮ࡴ࡮࡮ࡂࡶࡪࡪࡩࡳࡧࡦࡸࡂ࠭ᐳ") in Tf5ueYGZIFl1hraoEOVKi: ucIWpqewQgsGBC9bNP0JKF.succeeded = yrcbRSFswvAfEdIWVj
	ucIWpqewQgsGBC9bNP0JKF.scrapernumber = str(yPo2zE8c7SekvbiNLqRJ9jUZ)
	scraperserver = scraperserver+i80mE7lHUwVk(u"࠭ࠠ࠻ࠢࠪᐴ")+str(yPo2zE8c7SekvbiNLqRJ9jUZ)
	ucIWpqewQgsGBC9bNP0JKF.scraperserver = scraperserver
	ucIWpqewQgsGBC9bNP0JKF.scraperurl = gAomMHK9Z3OWsv8ciEpGFqIb
	if ucIWpqewQgsGBC9bNP0JKF.succeeded:
		if not wAcHkmPB8a.scrapers_succeeded:
			RLfOB3nsqaWXTugJvY(mmbcsf2pd7gyjzreB(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᐵ"),OFisAducwGY8L0XJKV,RyfYSek61do5OnQMc=ne7wF4gSTRZo(u"࠶࠶࠰ᝦ"))
			SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+TeYukOUW7i5NBM926DCjaAn0(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨᐶ")+scraperserver+n6JjFHfmydIaLut(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᐷ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+RRbvqditj184m3(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᐸ")+uxfIeVwzarRngd7y+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࠥࡣࠧᐹ"))
	else:
		if not wAcHkmPB8a.scrapers_succeeded:
			RLfOB3nsqaWXTugJvY(KJLkQsqSHMR1Np2(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᐺ"),OFisAducwGY8L0XJKV,RyfYSek61do5OnQMc=KJLkQsqSHMR1Np2(u"࠷࠰࠱ᝧ"))
			SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+VzO1gCHmjZ2ebRIL(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᐻ")+scraperserver+YZXtBgvUPoM5sb(u"ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᐼ")+str(ucIWpqewQgsGBC9bNP0JKF.code)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᐽ")+ucIWpqewQgsGBC9bNP0JKF.reason+q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᐾ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᐿ")+uxfIeVwzarRngd7y+ggtuNcvTn3HQ7SpE2(u"ࠫࠥࡣࠧᑀ"))
		if update:
			jyRgUc5FL0wWJHKCEbnYDlBmAG2sz(CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,s1sOl7vNWHP3rqT6unZ,[],yPo2zE8c7SekvbiNLqRJ9jUZ)
	global lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW,Wu9GMLkKDCFlePxNABYa7
	lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW[yPo2zE8c7SekvbiNLqRJ9jUZ] = ucIWpqewQgsGBC9bNP0JKF.succeeded
	Wu9GMLkKDCFlePxNABYa7[yPo2zE8c7SekvbiNLqRJ9jUZ] = ucIWpqewQgsGBC9bNP0JKF
	return ucIWpqewQgsGBC9bNP0JKF
def jyRgUc5FL0wWJHKCEbnYDlBmAG2sz(CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,s1sOl7vNWHP3rqT6unZ,AuDf4TUMrdJiXIE8epyW62qjxkF=[],Q1oGDPZ0s8jI5XFiUfkRp79aV4hyOM=D0DRCGqknfT2tKPY6N):
	LyYCMeRaji6Eb3Zv5dpKGlWDVBJ = n6JjFHfmydIaLut(u"࠵ᝨ")
	v4htpw7i9SW6rxKeZfTDmdOn2VM = nJF7oflOk6cLGSAey(u"࠶ᝩ")
	n6uDJHzbtL = []
	p0p3sfHRzFKSwIebjLN7mZAVD = [xn867tCVlscY4qbWZfh]+[xn867tCVlscY4qbWZfh]*CCjEKFo7RlLVqu1NGTsPr
	YrUxWOKj7QPuanXhSdR1Mp0c6lq = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡪࡩࡤࡶࠪᑁ"),OUFxZPuXDoGAbRz(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨᑂ"))
	for m9fBg2RZXcLSQMw7 in list(YrUxWOKj7QPuanXhSdR1Mp0c6lq.keys()):
		if s1sOl7vNWHP3rqT6unZ not in m9fBg2RZXcLSQMw7: continue
		gwiQ59eNbhY2SlLZB7aOpTDdsk1,OujW4HXxvRi5tyN8b2Qq0Dw = m9fBg2RZXcLSQMw7.split(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡠࡡࠪᑃ"))
		p0p3sfHRzFKSwIebjLN7mZAVD[int(OujW4HXxvRi5tyN8b2Qq0Dw)] = YrUxWOKj7QPuanXhSdR1Mp0c6lq[m9fBg2RZXcLSQMw7]
	for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr):
		if efOHGqlisRIytAvdKuS3Lc in wAcHkmPB8a.BADSCRAPERS+AuDf4TUMrdJiXIE8epyW62qjxkF: continue
		if efOHGqlisRIytAvdKuS3Lc==Q1oGDPZ0s8jI5XFiUfkRp79aV4hyOM: p0p3sfHRzFKSwIebjLN7mZAVD[efOHGqlisRIytAvdKuS3Lc] = p0p3sfHRzFKSwIebjLN7mZAVD[efOHGqlisRIytAvdKuS3Lc]+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠳ᝪ")
		if p0p3sfHRzFKSwIebjLN7mZAVD[efOHGqlisRIytAvdKuS3Lc]<LyYCMeRaji6Eb3Zv5dpKGlWDVBJ: n6uDJHzbtL += [efOHGqlisRIytAvdKuS3Lc]*L27fbarpqtSI[efOHGqlisRIytAvdKuS3Lc]
	if not n6uDJHzbtL:
		for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr):
			p0p3sfHRzFKSwIebjLN7mZAVD[efOHGqlisRIytAvdKuS3Lc] = xn867tCVlscY4qbWZfh
			if efOHGqlisRIytAvdKuS3Lc in wAcHkmPB8a.BADSCRAPERS+AuDf4TUMrdJiXIE8epyW62qjxkF: continue
			n6uDJHzbtL += [efOHGqlisRIytAvdKuS3Lc]*L27fbarpqtSI[efOHGqlisRIytAvdKuS3Lc]
	for efOHGqlisRIytAvdKuS3Lc in wAcHkmPB8a.BADSCRAPERS:
		if efOHGqlisRIytAvdKuS3Lc<CCjEKFo7RlLVqu1NGTsPr: p0p3sfHRzFKSwIebjLN7mZAVD[efOHGqlisRIytAvdKuS3Lc] = ne7wF4gSTRZo(u"࠼࠽࠾࠿ᝫ")
	jh8ZBAVfHDItqviT3cGSm5QlgL = []
	for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr): jh8ZBAVfHDItqviT3cGSm5QlgL.append(s1sOl7vNWHP3rqT6unZ+ne7wF4gSTRZo(u"ࠨࡡࡢࠫᑄ")+str(efOHGqlisRIytAvdKuS3Lc))
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,nJF7oflOk6cLGSAey(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖࠫᑅ"),jh8ZBAVfHDItqviT3cGSm5QlgL,p0p3sfHRzFKSwIebjLN7mZAVD,ykiUw6rCdx2074YH8Zcn*v4htpw7i9SW6rxKeZfTDmdOn2VM,w8Ui6RsVhSPrqHfO4)
	return n6uDJHzbtL
def MIFwij6WB4lEfepoGusVtZS75(rTKtsRwzXgnWBymUE285Mel,ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,g8E2PLGXKpYsZnAHjtol=gby0BnUuTNFk,PJnMHzOorxmLAwc=gby0BnUuTNFk,AuDf4TUMrdJiXIE8epyW62qjxkF=[]):
	CCjEKFo7RlLVqu1NGTsPr = BarIC3eR9bS(u"࠵࠸ᝬ")
	L27fbarpqtSI = [IXE6voNmrb182AyQ(u"࠶᝭"),IXE6voNmrb182AyQ(u"࠶᝭"),IXE6voNmrb182AyQ(u"࠶᝭"),FAwWlRJg0UkN1(u"࠷࠰ᝮ"),BarIC3eR9bS(u"࠵ᝯ"),FAwWlRJg0UkN1(u"࠷࠰ᝮ"),IXE6voNmrb182AyQ(u"࠶᝭"),IXE6voNmrb182AyQ(u"࠶᝭"),IXE6voNmrb182AyQ(u"࠶᝭"),BarIC3eR9bS(u"࠵ᝯ"),IXE6voNmrb182AyQ(u"࠶᝭"),BarIC3eR9bS(u"࠲᝱"),GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠶࠲ᝰ")]
	s1sOl7vNWHP3rqT6unZ = bTh6JaVi1mOoCEeKZ4kS8AWsnl.split(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪ࠱ࠬᑆ"))[xn867tCVlscY4qbWZfh]
	cWqV0lmb2thzgdUX97y38D = jyRgUc5FL0wWJHKCEbnYDlBmAG2sz(CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,s1sOl7vNWHP3rqT6unZ)
	args = ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc
	global lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW,Wu9GMLkKDCFlePxNABYa7
	lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW,Wu9GMLkKDCFlePxNABYa7 = [],[]
	for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr):
		lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW.append(yrcbRSFswvAfEdIWVj)
		Wu9GMLkKDCFlePxNABYa7.append(PKSnHM3QkOgGUyABi12slV())
	Fzt0uUbkiIpXAg2T3eH = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(mmbcsf2pd7gyjzreB(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡢࡷࡷࡳࡸࡩࡲࡢࡲࡨࡶࡸ࠭ᑇ"))
	if Fzt0uUbkiIpXAg2T3eH!=YZXtBgvUPoM5sb(u"࡙ࠬࡔࡐࡒࠪᑈ"):
		QnYrJfB1Cw49PDL8 = [GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠴࠶ᝲ")]
		V6kUErDNRgqZMsywWd5u = [rr3eJpwA4Incuof7lSKhsYgUWi for rr3eJpwA4Incuof7lSKhsYgUWi in QnYrJfB1Cw49PDL8 if rr3eJpwA4Incuof7lSKhsYgUWi in cWqV0lmb2thzgdUX97y38D]
		if V6kUErDNRgqZMsywWd5u:
			yPo2zE8c7SekvbiNLqRJ9jUZ = l8YH46ObxQJTk1.choice(V6kUErDNRgqZMsywWd5u)
			ucIWpqewQgsGBC9bNP0JKF = YVRgrlZeFUDfkxXnshjP(yPo2zE8c7SekvbiNLqRJ9jUZ,CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,args)
			if ucIWpqewQgsGBC9bNP0JKF.succeeded: return ucIWpqewQgsGBC9bNP0JKF
			L27fbarpqtSI[yPo2zE8c7SekvbiNLqRJ9jUZ] = xn867tCVlscY4qbWZfh
	ffLC6tdJcmlOFn4wY = mDCPiXNdQMov2F1rpRfxzBcn03L4ga()
	if rTKtsRwzXgnWBymUE285Mel==xn867tCVlscY4qbWZfh: PpQu9EkGTxa = w8Ui6RsVhSPrqHfO4
	elif rTKtsRwzXgnWBymUE285Mel==jxCVeKSLb9rGDOl0Qtw6:
		ffLC6tdJcmlOFn4wY.code = -jJ4LEcdl5w7BPMbQ
		ZK6tMYORAy2dgxokhfuT9HnEaBJrzL = NupI74tJCzYXmles9SbR6(u"࠭็ั้ࠣห้฻แฮห่ࠣฬ๊ࠦๆๅ้ࠤั๊ศ่ษ้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅ่ࠣศ์ฺࠠๆํ๋ฬࠦออสࠣ๎๊์ูࠡฮ่๎฾ࠦศาษ่ะࠥอไไ๊่ฬ๏๎สา่๊ࠢࠥาไษ๋ࠢๅฯำ้ࠠษึฮำีวๆ๊ࠢิ์ࠦวๅืไัฬะࠠ࠯࠰ࠣฬึ์วๆฮࠣ฽๊อฯࠡ์ึฮ฼๐ูࠡล้ࠤ๏าัษࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆๆ๊๊ࠥวࠡ์๋ะิࠦึๆษ้ࠤออไ็ฮสัࡡࡴࠧᑉ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡆࡴࡵࡳࡷࠦࡃࡰࡦࡨ࠾ࠥࠦࠧᑊ")+str(ffLC6tdJcmlOFn4wY.code)+GGy0cQe765nPYZ9E8Th+okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨ้็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆอะฬ๎าࠡษ็ััฮࠠภࠣࠤࡠࡳ࠮โะࠢอัฯอฬࠡ࠸࠳ࠤะอๆ๋หࠬࠫᑋ")+GGy0cQe765nPYZ9E8Th
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZK6tMYORAy2dgxokhfuT9HnEaBJrzL)
	elif rTKtsRwzXgnWBymUE285Mel==dNx9DVCtafk4r:
		ffLC6tdJcmlOFn4wY.code = -z5RruqXvsLaTf7e9c
		ZK6tMYORAy2dgxokhfuT9HnEaBJrzL = FAwWlRJg0UkN1(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฯ๋ๆฺࠢไฮาࠦศฺุูࠣๆำวหࠢส่ส์สา่อࠤฬ๊ึา๊ิ๎ฮࠦ࠮࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣฮ่๎ๆࠡ็้ࠤฬ๊ัศ๊อีࠥ฿ๆะๅࠣวํࠦๅ็ࠢหี๋อๅอࠢ฼๊ิ้ࠠฤ๊้๋ࠣࠦฬ่ษีࠤ฾์ฯไ๋ࠢ฼๏็ส่ࠢส่า๋ว๋หฺࠣิࠦวๅใํีํูวหࠢฦ์ࠥ฼ฯࠡษ็ฮัูำࠡล๋ࠤ฻ีࠠศๆหีฬ๋ฬࠡษ็้ษึ๊สࠢ࠱࠲๊ࠥอๅࠢสฺ่๊ใๅหࠣ๎ัฮࠠฦ์ๅหๆࠦ็ั้ࠣห้ำๅศ์ฬࠤฬ๊ฮศูษอࡡࡴࠧᑌ")+bKN9diGf8nmgecQPEqUzHRpoDuaO+mmbcsf2pd7gyjzreB(u"ࠪࡉࡷࡸ࡯ࡳࠢࡆࡳࡩ࡫࠺ࠡࠢࠪᑍ")+str(ffLC6tdJcmlOFn4wY.code)+GGy0cQe765nPYZ9E8Th+okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+OUFxZPuXDoGAbRz(u"ࠫ์๊ࠠหำํำ๋ࠥอศ๊็อࠥอำหะาห๊ࠦล็ฬิ๊ฯࠦรฯำ์ࠤ้ะฬศ๊ีࠤฬ๊ๅ็฻ࠣรࠦࠧ࡜࡯ࠪๅำࠥะอหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠯ࠧᑎ")+GGy0cQe765nPYZ9E8Th
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZK6tMYORAy2dgxokhfuT9HnEaBJrzL)
	if not PpQu9EkGTxa:
		ffLC6tdJcmlOFn4wY.succeeded = yrcbRSFswvAfEdIWVj
		return ffLC6tdJcmlOFn4wY
	RtyLH4lgN2U = []
	def LSfJcYeCU32oX():
		if any(lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW): return w8Ui6RsVhSPrqHfO4
		return yrcbRSFswvAfEdIWVj
	for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr):
		if efOHGqlisRIytAvdKuS3Lc in cWqV0lmb2thzgdUX97y38D:
			s4u3wDlrJEcSoV7x9kT8MW1 = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=YVRgrlZeFUDfkxXnshjP,args=(efOHGqlisRIytAvdKuS3Lc,CCjEKFo7RlLVqu1NGTsPr,L27fbarpqtSI,args))
			RtyLH4lgN2U.append(s4u3wDlrJEcSoV7x9kT8MW1)
	fEtlbKXnrTMG52c01QANRh4CZB(RtyLH4lgN2U,q2qPkMFpR1G86dEAKXHivor9N(u"࠺࠵ᝳ"),jxCVeKSLb9rGDOl0Qtw6,jxCVeKSLb9rGDOl0Qtw6,LSfJcYeCU32oX)
	for efOHGqlisRIytAvdKuS3Lc in range(CCjEKFo7RlLVqu1NGTsPr):
		if lpMdAi0DrJt3zxN6YCKeVfIU9vOjoW[efOHGqlisRIytAvdKuS3Lc]:
			for vxAn50lmdP6gM72yWu in RtyLH4lgN2U:
				try: vxAn50lmdP6gM72yWu.daemon = yrcbRSFswvAfEdIWVj
				except: pass
				try: vxAn50lmdP6gM72yWu.setDaemon(yrcbRSFswvAfEdIWVj)
				except: pass
			wAcHkmPB8a.scrapers_succeeded = w8Ui6RsVhSPrqHfO4
			return Wu9GMLkKDCFlePxNABYa7[efOHGqlisRIytAvdKuS3Lc]
	return Wu9GMLkKDCFlePxNABYa7[xn867tCVlscY4qbWZfh]
def sAwdJINXi7Vxe4zHFuD8Bonc2MT(s1sOl7vNWHP3rqT6unZ):
	LEOj8h9mzT2bcrRNAuoU = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡲࡩࡴࡶࠪᑏ"),oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠭ࡂࡍࡑࡆࡏࡊࡊ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔࠩᑐ"))
	if s1sOl7vNWHP3rqT6unZ in LEOj8h9mzT2bcrRNAuoU: return
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,i80mE7lHUwVk(u"ࠧࡃࡎࡒࡇࡐࡋࡄࡠ࡙ࡈࡆࡘࡏࡔࡆࡕࠪᑑ"),s1sOl7vNWHP3rqT6unZ,w8Ui6RsVhSPrqHfO4,Z83rChqtg1oXUjI4YL)
	LEOj8h9mzT2bcrRNAuoU = LEOj8h9mzT2bcrRNAuoU+[s1sOl7vNWHP3rqT6unZ]
	JKTRUIfhmnSApPD5cr = mJNpiuFnh2GqT()
	qqXs9KORkeyc = JKTRUIfhmnSApPD5cr.split(IXE6voNmrb182AyQ(u"ࠨ࠮࠯ࠫᑒ"))[dNx9DVCtafk4r]
	DI1M026yiGjnZXhTc58 = {n6JjFHfmydIaLut(u"ࠩࡸࡷࡪࡸࠧᑓ"):DpqPQYGB7mt,KJLkQsqSHMR1Np2(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᑔ"):eQNGiXdboqPt57O,mmbcsf2pd7gyjzreB(u"ࠫࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠧᑕ"):gby0BnUuTNFk,NupI74tJCzYXmles9SbR6(u"ࠬ࡯ࡴࡦ࡯ࠪᑖ"):gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡶࡢ࡮ࡸࡩࠬᑗ"):gby0BnUuTNFk,zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᑘ"):qqXs9KORkeyc,YZXtBgvUPoM5sb(u"ࠨࡲࡤࡶࡦࡳࡳࡠࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫᑙ"):i80mE7lHUwVk(u"ࠩ࠱࠲ࡇࡒࡏࡄࡍࡈࡈࡤ࡛ࡓࡆࡔࡖࠫᑚ"),ne7wF4gSTRZo(u"ࠪࡴࡦࡸࡡ࡮ࡵࠪᑛ"):LEOj8h9mzT2bcrRNAuoU}
	aqKWl53RBwigVxSQZCoUskIjJcnL = wAcHkmPB8a.SITESURLS[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᑜ")][YZXtBgvUPoM5sb(u"࠶࠷᝴")]
	WDxo5FVQtNn7UaTlq6 = ciEYbW4BFgSQdNIJ8VRovmKGAnhDf0(Z83rChqtg1oXUjI4YL,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡖࡏࡔࡖࠪᑝ"),aqKWl53RBwigVxSQZCoUskIjJcnL,DI1M026yiGjnZXhTc58,gby0BnUuTNFk,ne7wF4gSTRZo(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡈࡌࡐࡅࡎࡉࡉࡥࡗࡆࡄࡖࡍ࡙ࡋࡓࡠࡎࡌࡗ࡙ࡥࡔࡐࡡ࡚ࡉࡇࡉࡁࡄࡊࡈ࠱࠶ࡹࡴࠨᑞ"))
	return
def OpLFUdaX4JRMcoV2Gqn098rgmtf(WsqHDu9AgOMaToeBEYhQb,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl):
	if not jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk or isinstance(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,dict): ozVQbncL9s8rw5DHa = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࡈࡇࡗࠫᑟ")
	else:
		ozVQbncL9s8rw5DHa = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡒࡒࡗ࡙࠭ᑠ")
		jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = pFnO2T7r16k(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk)
		TjuadYeqDJCElhg5oB9z6pAFrvWLsM,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk = avXHrARzQuBW4s(jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk)
	tKObfFRod18ZU = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,w8Ui6RsVhSPrqHfO4,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
	cHuIdQiPshK8mwFUlkADGLv42fpeR = tKObfFRod18ZU.content
	cHuIdQiPshK8mwFUlkADGLv42fpeR = str(cHuIdQiPshK8mwFUlkADGLv42fpeR)
	return cHuIdQiPshK8mwFUlkADGLv42fpeR
def l5lOpSiDHhYnLoge1t3b6awkmxT(KKFPNRzufO):
	OOdCEvZ50W = KKFPNRzufO.split(i80mE7lHUwVk(u"ࠩࡿࢀࠬᑡ"))
	Tf5ueYGZIFl1hraoEOVKi,agKbMorQYsZ6y8pqOUjhNk3J4iVGA,AkXgI1l3bC2v5rOeNw6H74PfadK,f42bSj1zmowOKVg3PNna = OOdCEvZ50W[xn867tCVlscY4qbWZfh],D0DRCGqknfT2tKPY6N,D0DRCGqknfT2tKPY6N,w8Ui6RsVhSPrqHfO4
	for AvDtLJr2PUKNG0uanEMI in OOdCEvZ50W:
		if kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᑢ") in AvDtLJr2PUKNG0uanEMI: agKbMorQYsZ6y8pqOUjhNk3J4iVGA = AvDtLJr2PUKNG0uanEMI[ggtuNcvTn3HQ7SpE2(u"࠷࠱᝵"):]
		elif tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᑣ") in AvDtLJr2PUKNG0uanEMI: AkXgI1l3bC2v5rOeNw6H74PfadK = AvDtLJr2PUKNG0uanEMI[IXE6voNmrb182AyQ(u"࠹᝶"):]
		elif zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᑤ") in AvDtLJr2PUKNG0uanEMI: f42bSj1zmowOKVg3PNna = yrcbRSFswvAfEdIWVj
	return Tf5ueYGZIFl1hraoEOVKi,agKbMorQYsZ6y8pqOUjhNk3J4iVGA,AkXgI1l3bC2v5rOeNw6H74PfadK,f42bSj1zmowOKVg3PNna
def ckPK3uqiAN529g0(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,KKFPNRzufO,mZnhHIRWF4vlPyMVqAfi,c5WUCfkleqALO6YT0w,dzNeWB7IlATn3DXbH8pUEgwt,D6eSPULGzKbwjIV9Ao1lc=gby0BnUuTNFk):
	XYMi2n4luBbkqaR6fP7w8hAGtF = mDR9euKnv4jMSdbEpwcktJz5W6Cf(KKFPNRzufO,nJF7oflOk6cLGSAey(u"࠭ࡵࡳ࡮ࠪᑥ"))
	gipVDLXZQ24C = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(i80mE7lHUwVk(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᑦ")+mZnhHIRWF4vlPyMVqAfi)
	if XYMi2n4luBbkqaR6fP7w8hAGtF==gipVDLXZQ24C: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᑧ")+mZnhHIRWF4vlPyMVqAfi,gby0BnUuTNFk)
	if gipVDLXZQ24C: mm7pzl3HMi0R8fGu = KKFPNRzufO.replace(XYMi2n4luBbkqaR6fP7w8hAGtF,gipVDLXZQ24C)
	else:
		mm7pzl3HMi0R8fGu = KKFPNRzufO
		gipVDLXZQ24C = XYMi2n4luBbkqaR6fP7w8hAGtF
	VV0LwSPxJKDrgMHkGIpUBf4mAsO9 = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,mm7pzl3HMi0R8fGu,gby0BnUuTNFk,D6eSPULGzKbwjIV9Ao1lc,gby0BnUuTNFk,gby0BnUuTNFk,iiauUxMktNW5X(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭ᑨ"))
	cHuIdQiPshK8mwFUlkADGLv42fpeR = VV0LwSPxJKDrgMHkGIpUBf4mAsO9.content
	if nqkybtoMBH:
		try: cHuIdQiPshK8mwFUlkADGLv42fpeR = cHuIdQiPshK8mwFUlkADGLv42fpeR.decode(JJQFjSIlALchiMzG9,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᑩ"))
		except: pass
	if not VV0LwSPxJKDrgMHkGIpUBf4mAsO9.succeeded or dzNeWB7IlATn3DXbH8pUEgwt not in cHuIdQiPshK8mwFUlkADGLv42fpeR:
		c5WUCfkleqALO6YT0w = c5WUCfkleqALO6YT0w.replace(UpN1CezytPO9XoduhxZSD,FAwWlRJg0UkN1(u"ࠫ࠰࠭ᑪ"))
		Tf5ueYGZIFl1hraoEOVKi = i80mE7lHUwVk(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪᑫ")+c5WUCfkleqALO6YT0w
		IciL6hoO5F1MDSVPjypWZs8kKx = {FAwWlRJg0UkN1(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᑬ"):gby0BnUuTNFk}
		ffLC6tdJcmlOFn4wY = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫᑭ"))
		if ffLC6tdJcmlOFn4wY.succeeded:
			cHuIdQiPshK8mwFUlkADGLv42fpeR = ffLC6tdJcmlOFn4wY.content
			if nqkybtoMBH:
				try: cHuIdQiPshK8mwFUlkADGLv42fpeR = cHuIdQiPshK8mwFUlkADGLv42fpeR.decode(JJQFjSIlALchiMzG9,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᑮ"))
				except: pass
			vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᑯ"),cHuIdQiPshK8mwFUlkADGLv42fpeR,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			Z5y0bMcH2A19na8UtugkOPhQr3sL = [gipVDLXZQ24C]
			euSIpVQFRdvfLN7jkmC2Tr05o6EOg4 = [i80mE7lHUwVk(u"ࠪࡥࡵࡱࠧᑰ"),VzO1gCHmjZ2ebRIL(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᑱ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭ᑲ"),n6JjFHfmydIaLut(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᑳ"),RRbvqditj184m3(u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩᑴ"),YZXtBgvUPoM5sb(u"ࠨࡲ࡫ࡴࠬᑵ"),BarIC3eR9bS(u"ࠩࡤࡸࡱࡧࡱࠨᑶ"),n6JjFHfmydIaLut(u"ࠪࡷ࡮ࡺࡥࡪࡰࡧ࡭ࡨ࡫ࡳࠨᑷ"),ggtuNcvTn3HQ7SpE2(u"ࠫࡸࡻࡲ࠯࡮ࡼࠫᑸ"),IXE6voNmrb182AyQ(u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᑹ"),ggtuNcvTn3HQ7SpE2(u"࠭ࡩ࡯ࡨࡲࡶࡲ࡫ࡲࠨᑺ"),NupI74tJCzYXmles9SbR6(u"ࠧࡴ࡫ࡷࡩࡱ࡯࡫ࡦࠩᑻ"),RRbvqditj184m3(u"ࠨ࡫ࡱࡷࡹࡧࡧࡳࡣࡰࠫᑼ"),OUFxZPuXDoGAbRz(u"ࠩࡶࡲࡦࡶࡣࡩࡣࡷࠫᑽ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪ࡬ࡹࡺࡰ࠮ࡧࡴࡹ࡮ࡼࠧᑾ"),KJLkQsqSHMR1Np2(u"ࠫ࡫ࡧࡳࡦ࡮ࡳࡰࡺࡹࠧᑿ")]
			for SSQHn7pvhlREIWXaOTz in vx14CNdbsZTz:
				if any(value in SSQHn7pvhlREIWXaOTz for value in euSIpVQFRdvfLN7jkmC2Tr05o6EOg4): continue
				gipVDLXZQ24C = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSQHn7pvhlREIWXaOTz,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠬࡻࡲ࡭ࠩᒀ"))
				if gipVDLXZQ24C in Z5y0bMcH2A19na8UtugkOPhQr3sL: continue
				if len(Z5y0bMcH2A19na8UtugkOPhQr3sL)==nJF7oflOk6cLGSAey(u"࠺᝷"):
					SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+ne7wF4gSTRZo(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ᒁ")+mZnhHIRWF4vlPyMVqAfi+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᒂ")+XYMi2n4luBbkqaR6fP7w8hAGtF+q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࠢࡠࠫᒃ"))
					SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(BarIC3eR9bS(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᒄ")+mZnhHIRWF4vlPyMVqAfi,gby0BnUuTNFk)
					break
				Z5y0bMcH2A19na8UtugkOPhQr3sL.append(gipVDLXZQ24C)
				mm7pzl3HMi0R8fGu = KKFPNRzufO.replace(XYMi2n4luBbkqaR6fP7w8hAGtF,gipVDLXZQ24C)
				VV0LwSPxJKDrgMHkGIpUBf4mAsO9 = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,mm7pzl3HMi0R8fGu,gby0BnUuTNFk,D6eSPULGzKbwjIV9Ao1lc,gby0BnUuTNFk,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧᒅ"))
				cHuIdQiPshK8mwFUlkADGLv42fpeR = VV0LwSPxJKDrgMHkGIpUBf4mAsO9.content
				if VV0LwSPxJKDrgMHkGIpUBf4mAsO9.succeeded and dzNeWB7IlATn3DXbH8pUEgwt in cHuIdQiPshK8mwFUlkADGLv42fpeR:
					SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+mmbcsf2pd7gyjzreB(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫᒆ")+mZnhHIRWF4vlPyMVqAfi+TeYukOUW7i5NBM926DCjaAn0(u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫᒇ")+gipVDLXZQ24C+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫᒈ")+XYMi2n4luBbkqaR6fP7w8hAGtF+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࠡ࡟ࠪᒉ"))
					SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᒊ")+mZnhHIRWF4vlPyMVqAfi,gipVDLXZQ24C)
					break
	return gipVDLXZQ24C,mm7pzl3HMi0R8fGu,VV0LwSPxJKDrgMHkGIpUBf4mAsO9
def hjtyidLuHrs3(czrd0xT7BIl6noGC29w):
	h1pjAPbSmQUq7WcuZ = {
	 kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᒋ")				:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᒌ")
	,mmbcsf2pd7gyjzreB(u"ࠫࡦࡱ࡯ࡢ࡯ࠪᒍ")				:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩᒎ")
	,OUFxZPuXDoGAbRz(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᒏ")				:BarIC3eR9bS(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᒐ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡣ࡮ࡻࡦࡳࠧᒑ")				:nJF7oflOk6cLGSAey(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᒒ")
	,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡥࡰࡽࡡ࡮ࡶࡸࡦࡪ࠭ᒓ")			:iiauUxMktNW5X(u"๊ࠫ๎โฺࠢส็ํอๅࠡฬํ์อ࠭ᒔ")
	,i80mE7lHUwVk(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᒕ")				:FAwWlRJg0UkN1(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᒖ")
	,mmbcsf2pd7gyjzreB(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᒗ")				:iiLyoNwGbH03DIXhAkZn(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᒘ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᒙ")			:RRbvqditj184m3(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭ᒚ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭ᒛ")				:RRbvqditj184m3(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩᒜ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡡ࡭࡯ࡶࡸࡧࡧࠧᒝ")				:IXE6voNmrb182AyQ(u"ࠧๆ๊ๅ฽ࠥอไๆืฺฬฮ࠭ᒞ")
	,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪᒟ")				:kreQUwJis7YmC2yqWtIF09pgjbD(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨᒠ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨᒡ")			:uebroqCELQSJIcVPRz16x2Mv0DmB(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ᒢ")
	,KJLkQsqSHMR1Np2(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧᒣ")				:IXE6voNmrb182AyQ(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ᒤ")
	,ne7wF4gSTRZo(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩᒥ")				:n6JjFHfmydIaLut(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩᒦ")
	,ggtuNcvTn3HQ7SpE2(u"ࠩࡤࡽࡱࡵ࡬ࠨᒧ")				:MlTVLBZ92kzorIq1Yw(u"้ࠪํู่ࠡลํ่ํ๊ࠧᒨ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡧࡵ࡫ࡳࡣࠪᒩ")				:oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"๋่ࠬใ฻ࠣฬ่ืวࠨᒪ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡢࡳࡵࡷࡩ࡯࠭ᒫ")				:zDSw8LCxMQyraeXhojIWKmU(u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬᒬ")
	,MlTVLBZ92kzorIq1Yw(u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩᒭ")				:KJLkQsqSHMR1Np2(u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩᒮ")
	,OUFxZPuXDoGAbRz(u"ࠪࡧ࡮ࡳࡡ࠵ࡲࠪᒯ")				:RRbvqditj184m3(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิࠤอ๐ࠧᒰ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬᒱ")				:iI7tuF0nEQoR(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨᒲ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩᒳ")				:NupI74tJCzYXmles9SbR6(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩᒴ")
	,ggtuNcvTn3HQ7SpE2(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫᒵ")				:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫᒶ")
	,KJLkQsqSHMR1Np2(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪᒷ")			:iI7tuF0nEQoR(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪᒸ")
	,BarIC3eR9bS(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨᒹ")				:tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᒺ")
	,iI7tuF0nEQoR(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪᒻ")				:RRbvqditj184m3(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪᒼ")
	,iI7tuF0nEQoR(u"ࠪࡧ࡮ࡳࡡࡧࡴࡨࡩࠬᒽ")				:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๊ࠫ๎โฺࠢึ๎๊อࠠโำํࠫᒾ")
	,i80mE7lHUwVk(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨᒿ")			:IXE6voNmrb182AyQ(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧᓀ")
	,FAwWlRJg0UkN1(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᓁ")				:lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨᓂ")
	,mmbcsf2pd7gyjzreB(u"ࠩࡦ࡭ࡲࡧࡷࡣࡣࡶࠫᓃ")				:MlTVLBZ92kzorIq1Yw(u"้ࠪํู่ࠡีํ้ฬ่ࠦษีࠪᓄ")
	,RRbvqditj184m3(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᓅ")			:KJLkQsqSHMR1Np2(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠧᓆ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᓇ")	:lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢืฯิฯๆ์้ࠫᓈ")
	,mmbcsf2pd7gyjzreB(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡨࡢࡵ࡫ࡸࡦ࡭ࡳࠨᓉ")	:oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫᓊ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮࡮࡬ࡺࡪࡹࠧᓋ")	:iI7tuF0nEQoR(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅษษืีࠬᓌ")
	,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ᓍ"):MlTVLBZ92kzorIq1Yw(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧᓎ")
	,nJF7oflOk6cLGSAey(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬᓏ")	:lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪᓐ")
	,iiLyoNwGbH03DIXhAkZn(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧᓑ")	:Ducd5PRjQXaB9SIN7VrJ1G(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧᓒ")
	,n6JjFHfmydIaLut(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ᓓ")				:kreQUwJis7YmC2yqWtIF09pgjbD(u"๋ࠬส้ไไࠫᓔ")
	,iiLyoNwGbH03DIXhAkZn(u"࠭ࡤࡳࡣࡰࡥࡨࡧࡦࡦࠩᓕ")			:n6JjFHfmydIaLut(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤ่อแ๋้ࠪᓖ")
	,iiLyoNwGbH03DIXhAkZn(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩᓗ")				:ne7wF4gSTRZo(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩᓘ")
	,VzO1gCHmjZ2ebRIL(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫᓙ")				:iiLyoNwGbH03DIXhAkZn(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬᓚ")
	,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧᓛ")				:iiLyoNwGbH03DIXhAkZn(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩᓜ")
	,iiLyoNwGbH03DIXhAkZn(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩᓝ")				:NupI74tJCzYXmles9SbR6(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫᓞ")
	,zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫᓟ")				:iiLyoNwGbH03DIXhAkZn(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭ᓠ")
	,RRbvqditj184m3(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭ᓡ")				:BarIC3eR9bS(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨᓢ")
	,KJLkQsqSHMR1Np2(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪᓣ")			:KJLkQsqSHMR1Np2(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬᓤ")
	,nJF7oflOk6cLGSAey(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩᓥ")				:tZNGLJza5I9pkvChbg2yoPuXOHDB(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩᓦ")
	,OUFxZPuXDoGAbRz(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪᓧ")				:nJF7oflOk6cLGSAey(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫᓨ")
	,KJLkQsqSHMR1Np2(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧᓩ")				:KJLkQsqSHMR1Np2(u"࠭ๅ้ไ฼ࠤ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬᓪ")
	,ne7wF4gSTRZo(u"ࠧࡦ࡮࡬ࡪࡻ࡯ࡤࡦࡱࠪᓫ")			:VzO1gCHmjZ2ebRIL(u"ࠨ็๋ๆ฾ࠦรๅ์ไࠤๆ๐ฯ๋๊ࠪᓬ")
	,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪᓭ")				:iiLyoNwGbH03DIXhAkZn(u"้ࠪํู่ࠡใหี่ฯࠧᓮ")
	,VzO1gCHmjZ2ebRIL(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᓯ")				:YZXtBgvUPoM5sb(u"ࠬ็ิๅࠩᓰ")
	,n6JjFHfmydIaLut(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩᓱ")			:YZXtBgvUPoM5sb(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬᓲ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡨࡤࡶࡪࡹ࡫ࡰࠩᓳ")				:NupI74tJCzYXmles9SbR6(u"่ࠩ์็฿ࠠโษิื่๎ࠧᓴ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬᓵ")				:ne7wF4gSTRZo(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭ᓶ")
	,iiauUxMktNW5X(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧᓷ")				:i80mE7lHUwVk(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩᓸ")
	,TeYukOUW7i5NBM926DCjaAn0(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓹ")				:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨ็ฯ่ิ࠭ᓺ")
	,YZXtBgvUPoM5sb(u"ࠩࡩࡳࡸࡺࡡࠨᓻ")				:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"้ࠪํู่ࠡใ๋ืฯอࠧᓼ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫ࡫ࡻ࡮ࡰࡰࡷࡺࠬᓽ")				:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"๋่ࠬใ฻ࠣๅ๋๎ๆࠡฬํๅ๏࠭ᓾ")
	,OUFxZPuXDoGAbRz(u"࠭ࡦࡶࡵ࡫ࡥࡷࡺࡶࠨᓿ")				:iiauUxMktNW5X(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤฯ๐แ๋ࠩᔀ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ᔁ")			:ggtuNcvTn3HQ7SpE2(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬᔂ")
	,FAwWlRJg0UkN1(u"ࠪ࡫ࡴࡵࡤࠨᔃ")					:zDSw8LCxMQyraeXhojIWKmU(u"ࠫั๐ฯࠨᔄ")
	,i80mE7lHUwVk(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧᔅ")				:FAwWlRJg0UkN1(u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ᔆ")
	,i80mE7lHUwVk(u"ࠧࡩࡧ࡯ࡥࡱ࠭ᔇ")				:mmbcsf2pd7gyjzreB(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫᔈ")
	,n6JjFHfmydIaLut(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨᔉ")				:IXE6voNmrb182AyQ(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧᔊ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪᔋ")			:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧᔌ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭ᔍ")		:KJLkQsqSHMR1Np2(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬᔎ")
	,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨ࡫ࡳࡸࡻ࠭ᔏ")					:i80mE7lHUwVk(u"ࠩࡌࡔ࡙࡜ࠧᔐ")
	,iI7tuF0nEQoR(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ᔑ")			:MlTVLBZ92kzorIq1Yw(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨᔒ")
	,nJF7oflOk6cLGSAey(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪᔓ")			:OUFxZPuXDoGAbRz(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪᔔ")
	,NupI74tJCzYXmles9SbR6(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬᔕ")			:KJLkQsqSHMR1Np2(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧᔖ")
	,iiauUxMktNW5X(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬᔗ")			:tOGIuBnSMVj3XFaCgEqlKwH7oh(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭ᔘ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ᔙ")				:YZXtBgvUPoM5sb(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧᔚ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨᔛ")				:iiLyoNwGbH03DIXhAkZn(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫᔜ")
	,VzO1gCHmjZ2ebRIL(u"ࠨ࡭࡬ࡶࡲࡧ࡬࡬ࠩᔝ")				:iiLyoNwGbH03DIXhAkZn(u"่ࠩ์็฿ࠠไำ่ห้้ࠧᔞ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠪࡰࡦࡸ࡯ࡻࡣࠪᔟ")				:kreQUwJis7YmC2yqWtIF09pgjbD(u"๊ࠫ๎โฺࠢ็หึ๎าศࠩᔠ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭ᔡ")				:zDSw8LCxMQyraeXhojIWKmU(u"࠭ๅๅใࠪᔢ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧ࡭࡫ࡹࡩࠬᔣ")					:uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨไ้หฮ࠭ᔤ")
	,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩᔥ")				:ggtuNcvTn3HQ7SpE2(u"้้ࠪ็ࠧᔦ")
	,ggtuNcvTn3HQ7SpE2(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬᔧ")				:RRbvqditj184m3(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫᔨ")
	,YZXtBgvUPoM5sb(u"࠭࡭࠴ࡷࠪᔩ")					:uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡎ࠵ࡘࠫᔪ")
	,MlTVLBZ92kzorIq1Yw(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪᔫ")				:iI7tuF0nEQoR(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬᔬ")
	,NupI74tJCzYXmles9SbR6(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧᔭ")			:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧᔮ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩᔯ")			:nJF7oflOk6cLGSAey(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫᔰ")
	,OUFxZPuXDoGAbRz(u"ࠧ࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱࠪᔱ")			:NupI74tJCzYXmles9SbR6(u"ࠨ็๋ๆ฾ࠦๅศีสࠤๆ๐ฯ๋๊ࠪᔲ")
	,NupI74tJCzYXmles9SbR6(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᔳ")				:n6JjFHfmydIaLut(u"้ࠪๆ่่ะࠩᔴ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫᔵ")				:TeYukOUW7i5NBM926DCjaAn0(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧᔶ")
	,BarIC3eR9bS(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᔷ")				:zDSw8LCxMQyraeXhojIWKmU(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧᔸ")
	,ggtuNcvTn3HQ7SpE2(u"ࠨࡱ࡯ࡨࠬᔹ")					:oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩๅำ๏๋ࠧᔺ")
	,KJLkQsqSHMR1Np2(u"ࠪࡴࡦࡴࡥࡵࠩᔻ")				:GHYl6rZXD83JbQsCuMmL907t5FyfK(u"๊ࠫ๎โฺࠢหห๋๐สࠨᔼ")
	,OUFxZPuXDoGAbRz(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫᔽ")			:MlTVLBZ92kzorIq1Yw(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩᔾ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᔿ")			:i80mE7lHUwVk(u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ᕀ")
	,MlTVLBZ92kzorIq1Yw(u"ࠩࡴࡪ࡮ࡲ࡭ࠨᕁ")				:nJF7oflOk6cLGSAey(u"้ࠪํู่ࠡๅํ์ࠥ็๊ๅ็ࠪᕂ")
	,VzO1gCHmjZ2ebRIL(u"ࠫࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥࠨᕃ")			:VzO1gCHmjZ2ebRIL(u"๋่ࠬใ฻ࠣื๏ื๊ิࠢอห๏๋ࠧᕄ")
	,RRbvqditj184m3(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩᕅ")			:Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫᕆ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᕇ")				:mmbcsf2pd7gyjzreB(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫᕈ")
	,KJLkQsqSHMR1Np2(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠷࠭ᕉ")			:iiauUxMktNW5X(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํࠦ࠲ࠨᕊ")
	,nJF7oflOk6cLGSAey(u"ࠬࡹࡨࡢࡪ࡬ࡨࡳ࡫ࡷࡴࠩᕋ")			:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧᕌ")
	,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧࠪᕍ")			:IXE6voNmrb182AyQ(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪᕎ")
	,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧ࡬ࡣࡷࡰࡷࠬᕏ")		:iiauUxMktNW5X(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥอไษ๊่ࠫᕐ")
	,iI7tuF0nEQoR(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢࡷࡧ࡭ࡴࡹࠧᕑ")		:nJF7oflOk6cLGSAey(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧᕒ")
	,OUFxZPuXDoGAbRz(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪᕓ")	:tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧᕔ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨᕕ")				:TeYukOUW7i5NBM926DCjaAn0(u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫᕖ")
	,n6JjFHfmydIaLut(u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬᕗ")				:YZXtBgvUPoM5sb(u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫᕘ")
	,KJLkQsqSHMR1Np2(u"ࠬࡹࡨࡰࡱࡩࡲࡪࡺࠧᕙ")				:zDSw8LCxMQyraeXhojIWKmU(u"࠭ๅ้ไ฼ࠤู๎แ่ࠡอࠫᕚ")
	,OUFxZPuXDoGAbRz(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᕛ")				:oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧᕜ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡷ࡭ࡰࡧࡡࡵࠩᕝ")				:sqcK91hDCiHbPG52vfdLFaMy83nA(u"้ࠪํู่ࠡฬๆหฯ࠭ᕞ")
	,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࡹࡼࡦࡶࡰࠪᕟ")				:iiauUxMktNW5X(u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬᕠ")
	,ggtuNcvTn3HQ7SpE2(u"࠭ࡶࡢࡴࡥࡳࡳ࠭ᕡ")				:iiLyoNwGbH03DIXhAkZn(u"ࠧๆ๊ๅ฽ࠥ็วาส๋๊ࠬᕢ")
	,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡸ࡬ࡨࡪࡵࠧᕣ")				:NupI74tJCzYXmles9SbR6(u"ࠩไ๎ิ๐่ࠨᕤ")
	,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡺ࡮ࡪࡥࡰࡰࡶࡥࡪࡳࠧᕥ")			:ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"๊ࠫ๎โฺࠢไ๎ิ๐่่ࠡึหห๋ࠧᕦ")
	,TeYukOUW7i5NBM926DCjaAn0(u"ࠬࡽࡥࡤ࡫ࡰࡥ࠶࠭ᕧ")				:RRbvqditj184m3(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠥ࠷ࠧᕨ")
	,BarIC3eR9bS(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠲ࠨᕩ")				:TeYukOUW7i5NBM926DCjaAn0(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠳ࠩᕪ")
	,iI7tuF0nEQoR(u"ࠩࡼࡥࡶࡵࡴࠨᕫ")				:sqcK91hDCiHbPG52vfdLFaMy83nA(u"้ࠪํู่ࠡ์สๆํะࠧᕬ")
	,KJLkQsqSHMR1Np2(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᕭ")				:i80mE7lHUwVk(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪᕮ")
	,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩᕯ")		:VzO1gCHmjZ2ebRIL(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫᕰ")
	,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᕱ")	:iiLyoNwGbH03DIXhAkZn(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ᕲ")
	,i80mE7lHUwVk(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠫᕳ")		:n6JjFHfmydIaLut(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫᕴ")
	,iiauUxMktNW5X(u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᕵ")			:Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ๅ้ษๅ฽๋ࠥๆࠡ์๋ฮ๏๎ศࠨᕶ")
	}
	kkqjAWC6XiDlapTYnRU3zHNLE = czrd0xT7BIl6noGC29w.lower()
	for key in list(h1pjAPbSmQUq7WcuZ.keys()):
		rVNx6ah87kwRJCHboXpOqFvUPe = key.lower()
		if kkqjAWC6XiDlapTYnRU3zHNLE==rVNx6ah87kwRJCHboXpOqFvUPe:
			czrd0xT7BIl6noGC29w = h1pjAPbSmQUq7WcuZ[key]
			break
	return czrd0xT7BIl6noGC29w
def nR4jOE8geFDJhKIuisTc2ZPa(ZKRE9Savih,q3Vc7i1bjewxzA6JGFNL2Hm=gby0BnUuTNFk):
	wAcHkmPB8a.Uzo7FMNr5YDA2q13d6 = w8Ui6RsVhSPrqHfO4
	if not q3Vc7i1bjewxzA6JGFNL2Hm and ZKRE9Savih: q3Vc7i1bjewxzA6JGFNL2Hm = KJLkQsqSHMR1Np2(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨᕷ")
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᕸ"),q3Vc7i1bjewxzA6JGFNL2Hm)
	return
def IcChbXakUDFLszgpSG2jqem9(KKFPNRzufO,rniTRkflBcyNXu2LQ3djCmVG=oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩ࠽࠳ࠬᕹ")):
	return _0sL2twdoICPy7q(KKFPNRzufO,rniTRkflBcyNXu2LQ3djCmVG)
def MwQlRpaso5Li3SkPr6bEO(VV2izgqFs4dprlcE0ThJBAXGH):
	if VV2izgqFs4dprlcE0ThJBAXGH in [gby0BnUuTNFk,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪ࠴ࠬᕺ"),xn867tCVlscY4qbWZfh]: return gby0BnUuTNFk
	VV2izgqFs4dprlcE0ThJBAXGH = int(VV2izgqFs4dprlcE0ThJBAXGH)
	tnAK2UxpoWhqsNuTOId6ibCDMzRjHe = VV2izgqFs4dprlcE0ThJBAXGH^Q3J7xTKDuAUoaPlB
	esLI2ngZXr3851kBNVpGq = VV2izgqFs4dprlcE0ThJBAXGH^DNh1dgpa4BK
	dI92Ttsie1yMKZYNbHXlxUw0aR = VV2izgqFs4dprlcE0ThJBAXGH^cjSzHQn9N4BuIZO0xJ
	BdSKW76Q9y1 = str(tnAK2UxpoWhqsNuTOId6ibCDMzRjHe)+str(esLI2ngZXr3851kBNVpGq)+str(dI92Ttsie1yMKZYNbHXlxUw0aR)
	return BdSKW76Q9y1
def FFpiZIx1LmAuQdcEVrB(VV2izgqFs4dprlcE0ThJBAXGH):
	if VV2izgqFs4dprlcE0ThJBAXGH in [gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"ࠫ࠵࠭ᕻ"),xn867tCVlscY4qbWZfh]: return gby0BnUuTNFk
	VV2izgqFs4dprlcE0ThJBAXGH = str(VV2izgqFs4dprlcE0ThJBAXGH)
	BdSKW76Q9y1 = gby0BnUuTNFk
	if len(VV2izgqFs4dprlcE0ThJBAXGH)==q2qPkMFpR1G86dEAKXHivor9N(u"࠳࠸᝸"):
		tnAK2UxpoWhqsNuTOId6ibCDMzRjHe,esLI2ngZXr3851kBNVpGq,dI92Ttsie1yMKZYNbHXlxUw0aR = VV2izgqFs4dprlcE0ThJBAXGH[xn867tCVlscY4qbWZfh:z5RruqXvsLaTf7e9c],VV2izgqFs4dprlcE0ThJBAXGH[z5RruqXvsLaTf7e9c:lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠼᝹")],VV2izgqFs4dprlcE0ThJBAXGH[lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠼᝹"):]
		tnAK2UxpoWhqsNuTOId6ibCDMzRjHe = int(tnAK2UxpoWhqsNuTOId6ibCDMzRjHe)^cjSzHQn9N4BuIZO0xJ
		esLI2ngZXr3851kBNVpGq = int(esLI2ngZXr3851kBNVpGq)^DNh1dgpa4BK
		dI92Ttsie1yMKZYNbHXlxUw0aR = int(dI92Ttsie1yMKZYNbHXlxUw0aR)^Q3J7xTKDuAUoaPlB
		if tnAK2UxpoWhqsNuTOId6ibCDMzRjHe==esLI2ngZXr3851kBNVpGq==dI92Ttsie1yMKZYNbHXlxUw0aR: BdSKW76Q9y1 = str(tnAK2UxpoWhqsNuTOId6ibCDMzRjHe*ggtuNcvTn3HQ7SpE2(u"࠺࠵᝺"))
	return BdSKW76Q9y1
def DhxNVwJ7EQULzCK8acfiPZkM20sYg(VV2izgqFs4dprlcE0ThJBAXGH,GGIusSMHlghmw3tkBZ=iiLyoNwGbH03DIXhAkZn(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧᕼ")):
	if VV2izgqFs4dprlcE0ThJBAXGH==gby0BnUuTNFk: return gby0BnUuTNFk
	VV2izgqFs4dprlcE0ThJBAXGH = int(VV2izgqFs4dprlcE0ThJBAXGH)+int(GGIusSMHlghmw3tkBZ)
	tnAK2UxpoWhqsNuTOId6ibCDMzRjHe = VV2izgqFs4dprlcE0ThJBAXGH^Q3J7xTKDuAUoaPlB
	esLI2ngZXr3851kBNVpGq = VV2izgqFs4dprlcE0ThJBAXGH^DNh1dgpa4BK
	dI92Ttsie1yMKZYNbHXlxUw0aR = VV2izgqFs4dprlcE0ThJBAXGH^cjSzHQn9N4BuIZO0xJ
	BdSKW76Q9y1 = str(tnAK2UxpoWhqsNuTOId6ibCDMzRjHe)+str(esLI2ngZXr3851kBNVpGq)+str(dI92Ttsie1yMKZYNbHXlxUw0aR)
	return BdSKW76Q9y1
def jh4de7rmHqSsJNk9Zp(VV2izgqFs4dprlcE0ThJBAXGH,GGIusSMHlghmw3tkBZ=NupI74tJCzYXmles9SbR6(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᕽ")):
	if VV2izgqFs4dprlcE0ThJBAXGH==gby0BnUuTNFk: return gby0BnUuTNFk
	VV2izgqFs4dprlcE0ThJBAXGH = str(VV2izgqFs4dprlcE0ThJBAXGH)
	PzNA3VDQuXH750IYjtskaeT6oMclv = int(len(VV2izgqFs4dprlcE0ThJBAXGH)/jJ4LEcdl5w7BPMbQ)
	tnAK2UxpoWhqsNuTOId6ibCDMzRjHe = int(VV2izgqFs4dprlcE0ThJBAXGH[xn867tCVlscY4qbWZfh:PzNA3VDQuXH750IYjtskaeT6oMclv])^Q3J7xTKDuAUoaPlB
	esLI2ngZXr3851kBNVpGq = int(VV2izgqFs4dprlcE0ThJBAXGH[PzNA3VDQuXH750IYjtskaeT6oMclv:dNx9DVCtafk4r*PzNA3VDQuXH750IYjtskaeT6oMclv])^DNh1dgpa4BK
	dI92Ttsie1yMKZYNbHXlxUw0aR = int(VV2izgqFs4dprlcE0ThJBAXGH[dNx9DVCtafk4r*PzNA3VDQuXH750IYjtskaeT6oMclv:jJ4LEcdl5w7BPMbQ*PzNA3VDQuXH750IYjtskaeT6oMclv])^cjSzHQn9N4BuIZO0xJ
	BdSKW76Q9y1 = gby0BnUuTNFk
	if tnAK2UxpoWhqsNuTOId6ibCDMzRjHe==esLI2ngZXr3851kBNVpGq==dI92Ttsie1yMKZYNbHXlxUw0aR: BdSKW76Q9y1 = str(int(tnAK2UxpoWhqsNuTOId6ibCDMzRjHe)-int(GGIusSMHlghmw3tkBZ))
	return BdSKW76Q9y1
def g2AGeq4uKE(oxjEvs3yDZC4wamr5t1RfWcAeG):
	ttq1B6ZDCdOFRlfGUyPgA5 = wAcHkmPB8a.SITESURLS[KJLkQsqSHMR1Np2(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᕾ")][mmbcsf2pd7gyjzreB(u"࠽᝻")]
	JL6Nr0Vzk39YmSqnf5TpGF = bCoOHfPdMryRgauz0IVpth.path.join(Obkt3DeiTmRGEIM,Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫᕿ"),IXE6voNmrb182AyQ(u"ࠩࡶ࡯࡮ࡴࡳࠨᖀ"),FAwWlRJg0UkN1(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫᖁ"),IXE6voNmrb182AyQ(u"ࠫ࠼࠸࠰ࡱࠩᖂ"),iiauUxMktNW5X(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧᖃ"))
	qYtTXixp4HcbCBUkJQG6a9Klmr,Dj7SBW5R3eOTtMA90rNnxu = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(JL6Nr0Vzk39YmSqnf5TpGF)
	qYtTXixp4HcbCBUkJQG6a9Klmr = DhxNVwJ7EQULzCK8acfiPZkM20sYg(qYtTXixp4HcbCBUkJQG6a9Klmr,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᖄ"))
	E1E4hmwxiyToLZSYtlj7nM5kA = {IXE6voNmrb182AyQ(u"ࠧࡪࡦࡶࠫᖅ"):iiLyoNwGbH03DIXhAkZn(u"ࠨࡆࡌࡅࡑࡕࡇࠨᖆ"),ggtuNcvTn3HQ7SpE2(u"ࠩࡸࡷࡷ࠭ᖇ"):wAcHkmPB8a.AV_CLIENT_IDS,VzO1gCHmjZ2ebRIL(u"ࠪࡺࡪࡸࠧᖈ"):eQNGiXdboqPt57O,iiLyoNwGbH03DIXhAkZn(u"ࠫࡸࡩࡲࠨᖉ"):oxjEvs3yDZC4wamr5t1RfWcAeG,ne7wF4gSTRZo(u"ࠬࡹࡩࡻࠩᖊ"):qYtTXixp4HcbCBUkJQG6a9Klmr}
	Esyli9bZXhJ6QPg = {VzO1gCHmjZ2ebRIL(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᖋ"):oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ᖌ")}
	kit27mVIjK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,FAwWlRJg0UkN1(u"ࠨࡒࡒࡗ࡙࠭ᖍ"),ttq1B6ZDCdOFRlfGUyPgA5,E1E4hmwxiyToLZSYtlj7nM5kA,Esyli9bZXhJ6QPg,gby0BnUuTNFk,gby0BnUuTNFk,YZXtBgvUPoM5sb(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪᖎ"))
	Mgu3O5FNW96dR4Cckrv0ajsTy7pxG = kit27mVIjK.content
	try:
		if not Mgu3O5FNW96dR4Cckrv0ajsTy7pxG: b0pJFozWAl7UQ
		lUStMqTZCoV9r02nGyswDP5ek1cY = TqNUy3Z4SFWvplGwXC82A(q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡨ࡮ࡩࡴࠨᖏ"),Mgu3O5FNW96dR4Cckrv0ajsTy7pxG)
		XFiT1welqEBfCvGP7ZV58Qz = lUStMqTZCoV9r02nGyswDP5ek1cY[iiauUxMktNW5X(u"ࠫࡲࡹࡧࠨᖐ")]
		YYXg4wzG0FQE8cULAW = lUStMqTZCoV9r02nGyswDP5ek1cY[iI7tuF0nEQoR(u"ࠬࡹࡥࡤࠩᖑ")]
		mJ3a9dDxubEFBNCpKywjs = lUStMqTZCoV9r02nGyswDP5ek1cY[MlTVLBZ92kzorIq1Yw(u"࠭ࡳࡵࡲࠪᖒ")]
		YYXg4wzG0FQE8cULAW = int(jh4de7rmHqSsJNk9Zp(YYXg4wzG0FQE8cULAW,MlTVLBZ92kzorIq1Yw(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᖓ")))
		mJ3a9dDxubEFBNCpKywjs = int(jh4de7rmHqSsJNk9Zp(mJ3a9dDxubEFBNCpKywjs,i80mE7lHUwVk(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᖔ")))
		for aMfo13zI589Dj in range(YYXg4wzG0FQE8cULAW,xn867tCVlscY4qbWZfh,-mJ3a9dDxubEFBNCpKywjs):
			if not eval(NupI74tJCzYXmles9SbR6(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧᖕ"),{ggtuNcvTn3HQ7SpE2(u"ࠪࡼࡧࡳࡣࠨᖖ"):oKew16fsvuV8}): b0pJFozWAl7UQ
			RLfOB3nsqaWXTugJvY(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪᖗ"),str(aMfo13zI589Dj)+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࠦࠠฬษ้๎ฮ࠭ᖘ"),RyfYSek61do5OnQMc=lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠷࠰࠱᝼")*mJ3a9dDxubEFBNCpKywjs)
			oKew16fsvuV8.sleep(KJLkQsqSHMR1Np2(u"࠱࠱࠲࠳᝽")*mJ3a9dDxubEFBNCpKywjs)
		if eval(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫᖙ"),{lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡹࡤࡰࡧࠬᖚ"):oKew16fsvuV8}):
			XFiT1welqEBfCvGP7ZV58Qz = XFiT1welqEBfCvGP7ZV58Qz.replace(okfdjS4RmM,RRbvqditj184m3(u"ࠨ࡞࡟ࡲࠬᖛ")).replace(Hd14YjcWpvPhN8sZXK3,mmbcsf2pd7gyjzreB(u"ࠩ࡟ࡠࡷ࠭ᖜ"))
			tt3DVu1TU8dLAi(gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪาึ๎ฬࠨᖝ"),e1nNXbPrBVDZw,XFiT1welqEBfCvGP7ZV58Qz)
		b0pJFozWAl7UQ
	except: exec(n6JjFHfmydIaLut(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫᖞ"),{tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡾࡢ࡮ࡥࠪᖟ"):oKew16fsvuV8})
	return
def kkpdOLfmFHZt2bR1sxMn9ucPj():
	exec(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫᖠ"),{zDSw8LCxMQyraeXhojIWKmU(u"ࠧࡹࡤࡰࡧ࡬ࡻࡩࠨᖡ"):SxtK1ciEvLXRAWFVfQDOMgBYC,nJF7oflOk6cLGSAey(u"ࠨࡺࡥࡱࡨ࠭ᖢ"):oKew16fsvuV8})
	return
def Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(APkujXVWbdt6p98Y):
	zpIA5HVDERf3K,ZZYB0cKL9nkA1dxaovh58HztwS = xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
	if bCoOHfPdMryRgauz0IVpth.path.exists(APkujXVWbdt6p98Y):
		try: zpIA5HVDERf3K = bCoOHfPdMryRgauz0IVpth.path.getsize(APkujXVWbdt6p98Y)
		except: pass
		if not zpIA5HVDERf3K:
			try: zpIA5HVDERf3K = bCoOHfPdMryRgauz0IVpth.stat(APkujXVWbdt6p98Y).st_size
			except: pass
		if not zpIA5HVDERf3K:
			try:
				from pathlib import Path as K0ochgwfDq5WEib
				zpIA5HVDERf3K = K0ochgwfDq5WEib(APkujXVWbdt6p98Y).stat().st_size
			except: pass
		if zpIA5HVDERf3K: ZZYB0cKL9nkA1dxaovh58HztwS = jxCVeKSLb9rGDOl0Qtw6
	return zpIA5HVDERf3K,ZZYB0cKL9nkA1dxaovh58HztwS
def eWtDTvwY3XLnlo4H5(xErm8XTsfdyIQl,showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,xErm8XTsfdyIQl+TeYukOUW7i5NBM926DCjaAn0(u"ࠩ࡟ࡲࡡࡴࠧᖣ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+mmbcsf2pd7gyjzreB(u"๋้ࠪࠦสา์าࠤู๊อ้ࠡำหࠥอไๆๆไࠤฤࠧࠧᖤ")+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=TeYukOUW7i5NBM926DCjaAn0(u"࠲᝾"): return yrcbRSFswvAfEdIWVj
	succeeded = w8Ui6RsVhSPrqHfO4
	if bCoOHfPdMryRgauz0IVpth.path.exists(xErm8XTsfdyIQl):
		try: bCoOHfPdMryRgauz0IVpth.remove(xErm8XTsfdyIQl.decode(JJQFjSIlALchiMzG9))
		except:
			try: bCoOHfPdMryRgauz0IVpth.remove(uYrHUoesmkX4)
			except Exception as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
				succeeded = yrcbRSFswvAfEdIWVj
				if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb))
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠫๆฺไหࠢ฼้้๐ษࠡ็ึัࠥอไๆๆไࠫᖥ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MlTVLBZ92kzorIq1Yw(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᖦ"))
	return succeeded
def LamxwbXfkZ6JDoCRlgBIehsEc(wrJ1QUjLXgNpDim2aE,KBUlRebsgPVj5GAuqrYJFp9n8D,showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,wrJ1QUjLXgNpDim2aE+n6JjFHfmydIaLut(u"࠭࡜࡯࡞ࡱࠫᖧ")+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+kreQUwJis7YmC2yqWtIF09pgjbD(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࠬᖨ")+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return yrcbRSFswvAfEdIWVj
	succeeded = w8Ui6RsVhSPrqHfO4
	if bCoOHfPdMryRgauz0IVpth.path.exists(wrJ1QUjLXgNpDim2aE):
		for xdglB7UuAnL83tI0fVzQr,C9D5oe8jaIdGxN,k3Vt7bYx64IXQRDKp1vMqJOUBL8 in bCoOHfPdMryRgauz0IVpth.walk(wrJ1QUjLXgNpDim2aE,topdown=yrcbRSFswvAfEdIWVj):
			for APkujXVWbdt6p98Y in k3Vt7bYx64IXQRDKp1vMqJOUBL8:
				DlBXgmHAu0T9ydiajxqZnG64PS = bCoOHfPdMryRgauz0IVpth.path.join(xdglB7UuAnL83tI0fVzQr,APkujXVWbdt6p98Y)
				try: bCoOHfPdMryRgauz0IVpth.remove(DlBXgmHAu0T9ydiajxqZnG64PS)
				except Exception as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
					succeeded = yrcbRSFswvAfEdIWVj
					if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb))
			if KBUlRebsgPVj5GAuqrYJFp9n8D:
				for dir in C9D5oe8jaIdGxN:
					m8EyHDqsn4Br = bCoOHfPdMryRgauz0IVpth.path.join(xdglB7UuAnL83tI0fVzQr,dir)
					try: bCoOHfPdMryRgauz0IVpth.rmdir(m8EyHDqsn4Br)
					except: pass
		if KBUlRebsgPVj5GAuqrYJFp9n8D:
			try: bCoOHfPdMryRgauz0IVpth.rmdir(xdglB7UuAnL83tI0fVzQr)
			except: pass
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᖩ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,TeYukOUW7i5NBM926DCjaAn0(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫᖪ"))
	return succeeded
def ciEYbW4BFgSQdNIJ8VRovmKGAnhDf0(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,bTh6JaVi1mOoCEeKZ4kS8AWsnl):
	Tf5ueYGZIFl1hraoEOVKi,agKbMorQYsZ6y8pqOUjhNk3J4iVGA,AkXgI1l3bC2v5rOeNw6H74PfadK,f42bSj1zmowOKVg3PNna = l5lOpSiDHhYnLoge1t3b6awkmxT(KKFPNRzufO)
	GlChquk75v0bXU1DHxo = ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc
	if nJF7oflOk6cLGSAey(u"ࠪࡑࡆࡏࡎࡠࡆࡌࡗࡕࡇࡔࡄࡊࡈࡖࡤࡉࡁࡄࡊࡈࡈࠬᖫ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl:
		qkElOYv2aF = jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk.get(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡻࡧ࡬ࡶࡧࠪᖬ"))
		if qkElOYv2aF:
			T1n4mCBLh28H0zR6bwpaK7Fki9P = qkElOYv2aF.split(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡥ࡟ࡔࡇࡓࡣࡤ࠭ᖭ"),BarIC3eR9bS(u"࠳᝿"))[BarIC3eR9bS(u"࠳᝿")]
			hzBmXNRcn6f9boUdSFyjHrOglKksJ = jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk.copy()
			hzBmXNRcn6f9boUdSFyjHrOglKksJ[iI7tuF0nEQoR(u"࠭ࡶࡢ࡮ࡸࡩࠬᖮ")] = T1n4mCBLh28H0zR6bwpaK7Fki9P
			GlChquk75v0bXU1DHxo = ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,hzBmXNRcn6f9boUdSFyjHrOglKksJ,D6eSPULGzKbwjIV9Ao1lc
	if WsqHDu9AgOMaToeBEYhQb<ggtuNcvTn3HQ7SpE2(u"࠳ក"):
		dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᖯ"),GlChquk75v0bXU1DHxo)
		WsqHDu9AgOMaToeBEYhQb = -WsqHDu9AgOMaToeBEYhQb
	if WsqHDu9AgOMaToeBEYhQb>q2qPkMFpR1G86dEAKXHivor9N(u"࠴ខ"):
		cHuIdQiPshK8mwFUlkADGLv42fpeR = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࡵࡷࡶࠬᖰ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᖱ"),GlChquk75v0bXU1DHxo)
		if cHuIdQiPshK8mwFUlkADGLv42fpeR:
			laeTCpY1R4wQDf7LOBVqXhsoSJ96EU(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᖲ"),KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,bTh6JaVi1mOoCEeKZ4kS8AWsnl,ozVQbncL9s8rw5DHa)
			return cHuIdQiPshK8mwFUlkADGLv42fpeR[z5RruqXvsLaTf7e9c:]
	cHuIdQiPshK8mwFUlkADGLv42fpeR = mma7hVpzo3Mfc5SO(ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
	cHuIdQiPshK8mwFUlkADGLv42fpeR = TFAVlh4ONfuyivg+cHuIdQiPshK8mwFUlkADGLv42fpeR
	if WsqHDu9AgOMaToeBEYhQb: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,iiauUxMktNW5X(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᖳ"),GlChquk75v0bXU1DHxo,cHuIdQiPshK8mwFUlkADGLv42fpeR,WsqHDu9AgOMaToeBEYhQb)
	return cHuIdQiPshK8mwFUlkADGLv42fpeR[z5RruqXvsLaTf7e9c:]
def evjaBmTwVQ(CC3nOPFMovd72u,jqKpHz6D82J,dopeRQMO42JljFsrHxIB5SN8fXq=xn867tCVlscY4qbWZfh):
	X3rEUBodm8qu = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(FAwWlRJg0UkN1(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩᖴ"))
	if X3rEUBodm8qu and YZXtBgvUPoM5sb(u"࠭࠭ࠨᖵ") not in X3rEUBodm8qu: ZtKQh02YIoDfuFxUXz9,jlxVtSi0nkXYMroRsc = int(X3rEUBodm8qu),w8Ui6RsVhSPrqHfO4
	elif dopeRQMO42JljFsrHxIB5SN8fXq: ZtKQh02YIoDfuFxUXz9,jlxVtSi0nkXYMroRsc = dopeRQMO42JljFsrHxIB5SN8fXq,yrcbRSFswvAfEdIWVj
	else: return []
	feIYbyKRLF,zmx6BOPfvrwd4p = [],gby0BnUuTNFk
	Pd8HbwoRDmxGNk0U7,A7FaTvB3oZNV4jhYR0,eKFxj1hNORvBqwDlAEIVtmXfbWL,QTGmYiVHElUj0agM = gby0BnUuTNFk,gby0BnUuTNFk,xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
	jqKpHz6D82J = sorted(jqKpHz6D82J,reverse=w8Ui6RsVhSPrqHfO4,key=lambda key: (key[jxCVeKSLb9rGDOl0Qtw6],key[dNx9DVCtafk4r]))
	for stream,azI6UxXgiFGfES5wB0Q1WlkN,H43svmuKOrRD2APk6w51hVGjabxiTt in jqKpHz6D82J+[[gby0BnUuTNFk,gby0BnUuTNFk,xn867tCVlscY4qbWZfh]]:
		if azI6UxXgiFGfES5wB0Q1WlkN==zmx6BOPfvrwd4p:
			if H43svmuKOrRD2APk6w51hVGjabxiTt>ZtKQh02YIoDfuFxUXz9: A7FaTvB3oZNV4jhYR0,QTGmYiVHElUj0agM = stream,H43svmuKOrRD2APk6w51hVGjabxiTt
			elif not Pd8HbwoRDmxGNk0U7: Pd8HbwoRDmxGNk0U7,eKFxj1hNORvBqwDlAEIVtmXfbWL = stream,H43svmuKOrRD2APk6w51hVGjabxiTt
		else:
			if A7FaTvB3oZNV4jhYR0 or Pd8HbwoRDmxGNk0U7:
				if Pd8HbwoRDmxGNk0U7: feIYbyKRLF.append([Pd8HbwoRDmxGNk0U7,zmx6BOPfvrwd4p,eKFxj1hNORvBqwDlAEIVtmXfbWL])
				elif A7FaTvB3oZNV4jhYR0: feIYbyKRLF.append([A7FaTvB3oZNV4jhYR0,zmx6BOPfvrwd4p,QTGmYiVHElUj0agM])
			if H43svmuKOrRD2APk6w51hVGjabxiTt>ZtKQh02YIoDfuFxUXz9:
				A7FaTvB3oZNV4jhYR0,QTGmYiVHElUj0agM = stream,H43svmuKOrRD2APk6w51hVGjabxiTt
				Pd8HbwoRDmxGNk0U7,eKFxj1hNORvBqwDlAEIVtmXfbWL = gby0BnUuTNFk,xn867tCVlscY4qbWZfh
			else:
				A7FaTvB3oZNV4jhYR0,QTGmYiVHElUj0agM = gby0BnUuTNFk,xn867tCVlscY4qbWZfh
				Pd8HbwoRDmxGNk0U7,eKFxj1hNORvBqwDlAEIVtmXfbWL = stream,H43svmuKOrRD2APk6w51hVGjabxiTt
		zmx6BOPfvrwd4p = azI6UxXgiFGfES5wB0Q1WlkN
	if jlxVtSi0nkXYMroRsc:
		hh8BPgYUy0HAbRf1,TntQecvjOlXh47IbrzR8D6iCm,Kjit9wkgxQrIPCyaz1DU7 = zip(*feIYbyKRLF)
		ziuGHMyqTj7peQ = [sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧ࡮ࡲ࠷ࠫᖶ"),n6JjFHfmydIaLut(u"ࠨ࡯ࡳࡨࠬᖷ"),kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡷࡷࠬᖸ"),zDSw8LCxMQyraeXhojIWKmU(u"ࠪࡱ࠸ࡻࠧᖹ")]
		for azI6UxXgiFGfES5wB0Q1WlkN in ziuGHMyqTj7peQ:
			if azI6UxXgiFGfES5wB0Q1WlkN in TntQecvjOlXh47IbrzR8D6iCm:
				index = TntQecvjOlXh47IbrzR8D6iCm.index(azI6UxXgiFGfES5wB0Q1WlkN)
				feIYbyKRLF = [[hh8BPgYUy0HAbRf1[index],TntQecvjOlXh47IbrzR8D6iCm[index],Kjit9wkgxQrIPCyaz1DU7[index]]]
				break
	return feIYbyKRLF
def ynLAZbiodSG3QtgIJu2(iarqh36w9VM):
	BGFSCc6fXDjPtyniZp,GMVe5zIYFmLPw21ZkvEBo4y3cOd = [],D0DRCGqknfT2tKPY6N
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in QQMChIwdeVvs3NbaA8xHpi5P:
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1==OUFxZPuXDoGAbRz(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᖺ"): GMVe5zIYFmLPw21ZkvEBo4y3cOd = (RRbvqditj184m3(u"ࠬࡲࡩ࡯࡭ࠪᖻ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+MlTVLBZ92kzorIq1Yw(u"࠭ๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้࠭ᖼ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,IXE6voNmrb182AyQ(u"࠶࠻࠷គ"),gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk)
		elif gwiQ59eNbhY2SlLZB7aOpTDdsk1==nJF7oflOk6cLGSAey(u"ࠧࡎࡋ࡛ࡉࡉ࠭ᖽ"): GMVe5zIYFmLPw21ZkvEBo4y3cOd = (iiauUxMktNW5X(u"ࠨ࡮࡬ࡲࡰ࠭ᖾ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+sqcK91hDCiHbPG52vfdLFaMy83nA(u"่ࠩ์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไࠨᖿ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠷࠵࠸ឃ"),gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk)
		elif gwiQ59eNbhY2SlLZB7aOpTDdsk1==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪᗀ"): GMVe5zIYFmLPw21ZkvEBo4y3cOd = (DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡱ࡯࡮࡬ࠩᗁ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+ne7wF4gSTRZo(u"๋่ࠬศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࠬᗂ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,ggtuNcvTn3HQ7SpE2(u"࠱࠶࠹ង"),gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk)
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in iarqh36w9VM: continue
		if GMVe5zIYFmLPw21ZkvEBo4y3cOd:
			BGFSCc6fXDjPtyniZp.append(GMVe5zIYFmLPw21ZkvEBo4y3cOd)
			GMVe5zIYFmLPw21ZkvEBo4y3cOd = D0DRCGqknfT2tKPY6N
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in [tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧᗃ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡎࡋ࡛ࡉࡉ࠭ᗄ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡒࡘࡆࡑࡏࡃࠨᗅ")]: BGFSCc6fXDjPtyniZp.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	return BGFSCc6fXDjPtyniZp
def x9g2PQh3F6NRiJTMI0zELj8Hs(KhltLuwAV4Q,args=[]):
	Esyli9bZXhJ6QPg = {TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᗆ"):OUFxZPuXDoGAbRz(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ᗇ")}
	bQ25Y9vA8XPHS,MmAQa5zotvJdZEi4x9f8RuYIHpCbn,fLmkJsWhtqwdbVAS14Nag6FjHOBr = n6JjFHfmydIaLut(u"ࠫࡻࡩࡢࡤ࠸࠸࠷࠹࠼ࡧࡧࡪࡥࡲࡾࡳࡵ࡫࡭ࠪᗈ"),KJLkQsqSHMR1Np2(u"ࠬ࠺࠳ࡷࡥࡹ࠷ࡩ࡬ࡧ࡫࡭ࡲ࠻࠽ࡹࡸࡻࡦ࠵ࠫᗉ"),int(RyfYSek61do5OnQMc.time())
	pdif6gnSDtmMkI = bQ25Y9vA8XPHS+DpqPQYGB7mt+str(fLmkJsWhtqwdbVAS14Nag6FjHOBr)+eQNGiXdboqPt57O+MmAQa5zotvJdZEi4x9f8RuYIHpCbn
	y0HETYJ4Crxi6RKvOMgGzBIeZ = DwaiOMhZBR8eP4.md5(pdif6gnSDtmMkI.encode(DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࡵࡵࡨ࠻ࠫᗊ"))).hexdigest()[:MlTVLBZ92kzorIq1Yw(u"࠴࠴ច")]
	E1E4hmwxiyToLZSYtlj7nM5kA = {uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧ࡫ࡵࡦࡳࡩ࡫ࠧᗋ"):KhltLuwAV4Q,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡣࡵ࡫ࡸ࠭ᗌ"):args,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡸࡷࡪࡸࠧᗍ"):DpqPQYGB7mt,n6JjFHfmydIaLut(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᗎ"):eQNGiXdboqPt57O,NupI74tJCzYXmles9SbR6(u"ࠫ࡮ࡪࡳࠨᗏ"):y0HETYJ4Crxi6RKvOMgGzBIeZ}
	W6WqX3mpaJ95BK = wAcHkmPB8a.SITESURLS[FAwWlRJg0UkN1(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᗐ")][sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠳࠳ឆ")]
	kit27mVIjK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,YZXtBgvUPoM5sb(u"࠭ࡐࡐࡕࡗࠫᗑ"),W6WqX3mpaJ95BK,E1E4hmwxiyToLZSYtlj7nM5kA,Esyli9bZXhJ6QPg,gby0BnUuTNFk,gby0BnUuTNFk,i80mE7lHUwVk(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡉࡈ࡛ࡔࡆࡡࡍࡗ࠲࠷ࡳࡵࠩᗒ"))
	Mgu3O5FNW96dR4Cckrv0ajsTy7pxG = kit27mVIjK.content
	return Mgu3O5FNW96dR4Cckrv0ajsTy7pxG
def fEtlbKXnrTMG52c01QANRh4CZB(FrVa2SKqeG0,SOHdhzwUg6buPsj1W4QBv,lZ3HdU1c0okgyY62R,bIoeDnmHR6GAUdfhJaySvBqY,USCPoFhYXZ7Opb025Qfn9e):
	Yx2ahobNmPZ5I76OLR89kvCr = yrcbRSFswvAfEdIWVj
	IShoALRaNnvqsVcxg8 = SOHdhzwUg6buPsj1W4QBv
	for z1DfoBJ3rs in FrVa2SKqeG0:
		z1DfoBJ3rs.start()
		RyfYSek61do5OnQMc.sleep(lZ3HdU1c0okgyY62R)
		IShoALRaNnvqsVcxg8 -= lZ3HdU1c0okgyY62R
		Yx2ahobNmPZ5I76OLR89kvCr = USCPoFhYXZ7Opb025Qfn9e()
		if Yx2ahobNmPZ5I76OLR89kvCr: break
	while not Yx2ahobNmPZ5I76OLR89kvCr and IShoALRaNnvqsVcxg8>xn867tCVlscY4qbWZfh:
		RyfYSek61do5OnQMc.sleep(bIoeDnmHR6GAUdfhJaySvBqY)
		IShoALRaNnvqsVcxg8 -= bIoeDnmHR6GAUdfhJaySvBqY
		Yx2ahobNmPZ5I76OLR89kvCr = USCPoFhYXZ7Opb025Qfn9e()
	return Yx2ahobNmPZ5I76OLR89kvCr
def UcWYT0gz7mALe(NE1IpTQkbALh6Fj7gSYzMfZXlmtx=oBGb51EeFWRkUD4alK0XgQviIZqTP):
	KVmChDFopJyn93RxqiuYXZr = VzO1gCHmjZ2ebRIL(u"࠴࠴࠷࠺ជ")
	DT1Wxrk628ZByldChqISa = xn867tCVlscY4qbWZfh
	if not DT1Wxrk628ZByldChqISa:
		try:
			import shutil as hbe4YGSBI6ZfjAJ3KwlNVUc
			DT1Wxrk628ZByldChqISa = hbe4YGSBI6ZfjAJ3KwlNVUc.disk_usage(NE1IpTQkbALh6Fj7gSYzMfZXlmtx).free
		except: pass
	if not DT1Wxrk628ZByldChqISa and hasattr(bCoOHfPdMryRgauz0IVpth,iiLyoNwGbH03DIXhAkZn(u"ࠨࡵࡷࡥࡹࡼࡦࡴࠩᗓ")):
		try:
			dPpkHvQ4yICwRbj8 = bCoOHfPdMryRgauz0IVpth.statvfs(NE1IpTQkbALh6Fj7gSYzMfZXlmtx)
			DT1Wxrk628ZByldChqISa = dPpkHvQ4yICwRbj8.f_frsize * dPpkHvQ4yICwRbj8.f_bavail
		except: pass
	if not DT1Wxrk628ZByldChqISa and hasattr(bCoOHfPdMryRgauz0IVpth,TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡩࡷࡹࡧࡴࡷࡨࡶࠫᗔ")):
		try:
			dPpkHvQ4yICwRbj8 = bCoOHfPdMryRgauz0IVpth.fstatvfs(NE1IpTQkbALh6Fj7gSYzMfZXlmtx)
			DT1Wxrk628ZByldChqISa = dPpkHvQ4yICwRbj8.f_frsize * dPpkHvQ4yICwRbj8.f_bavail
		except: pass
	if not DT1Wxrk628ZByldChqISa and Pt41K3suxDF9nE0wLvU7dGq2ceNT.platform == BarIC3eR9bS(u"ࠪࡻ࡮ࡴ࠳࠳ࠩᗕ"):
		try:
			import ctypes as LL64OUTuExXMZQChlPoan
			Gp6ihMOegqyCuvKQswYE9cFRTk2l1X = LL64OUTuExXMZQChlPoan.c_ulonglong(xn867tCVlscY4qbWZfh)
			LL64OUTuExXMZQChlPoan.windll.kernel32.GetDiskFreeSpaceExW(LL64OUTuExXMZQChlPoan.c_wchar_p(NE1IpTQkbALh6Fj7gSYzMfZXlmtx),None,None,LL64OUTuExXMZQChlPoan.pointer(Gp6ihMOegqyCuvKQswYE9cFRTk2l1X))
			DT1Wxrk628ZByldChqISa = Gp6ihMOegqyCuvKQswYE9cFRTk2l1X.value
		except: pass
	if not DT1Wxrk628ZByldChqISa:
		try:
			tJnbzGqcdx7QCfFevi9AuVTDNXh = oKew16fsvuV8.getInfoLabel(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡥࡦࡕࡳࡥࡨ࡫ࠧᗖ"))
			u9D2fVCFUOc1 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡢࡤࠬࠪࡂ࠾ࡡ࠴࡜ࡥ࠭ࠬࡃࠬᗗ"),tJnbzGqcdx7QCfFevi9AuVTDNXh,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if u9D2fVCFUOc1:
				u9D2fVCFUOc1 = float(u9D2fVCFUOc1[BarIC3eR9bS(u"࠴ឈ")])
				if   iI7tuF0nEQoR(u"࠭ࡔࠨᗘ") in tJnbzGqcdx7QCfFevi9AuVTDNXh: DT1Wxrk628ZByldChqISa = u9D2fVCFUOc1*KVmChDFopJyn93RxqiuYXZr**z5RruqXvsLaTf7e9c
				elif KJLkQsqSHMR1Np2(u"ࠧࡈࠩᗙ") in tJnbzGqcdx7QCfFevi9AuVTDNXh: DT1Wxrk628ZByldChqISa = u9D2fVCFUOc1*KVmChDFopJyn93RxqiuYXZr**jJ4LEcdl5w7BPMbQ
				elif i80mE7lHUwVk(u"ࠨࡏࠪᗚ") in tJnbzGqcdx7QCfFevi9AuVTDNXh: DT1Wxrk628ZByldChqISa = u9D2fVCFUOc1*KVmChDFopJyn93RxqiuYXZr**dNx9DVCtafk4r
				elif zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡎࠫᗛ") in tJnbzGqcdx7QCfFevi9AuVTDNXh: DT1Wxrk628ZByldChqISa = u9D2fVCFUOc1*KVmChDFopJyn93RxqiuYXZr
				else: DT1Wxrk628ZByldChqISa = u9D2fVCFUOc1
		except: pass
	if not DT1Wxrk628ZByldChqISa: DT1Wxrk628ZByldChqISa = RRbvqditj184m3(u"࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾ញ")
	return int(DT1Wxrk628ZByldChqISa)
def EWdkJfTB1xOsb(EyaNdiZUtzq2rMulW9JL1ITHP3fgC):
	if EyaNdiZUtzq2rMulW9JL1ITHP3fgC:
		lEqUXbmuvc3M = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪࡰ࡮ࡹࡴࠨᗜ"),iI7tuF0nEQoR(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩᗝ"),KJLkQsqSHMR1Np2(u"࡙ࠬࡉࡕࡇࡖࡣ࡚࡙ࡁࡈࡇࠪᗞ"))
		if lEqUXbmuvc3M: return lEqUXbmuvc3M
	pjBAh5E2XWYmHx = {Ducd5PRjQXaB9SIN7VrJ1G(u"࠭ࡡࠨᗟ"):tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࡢࠩᗠ")}
	url = wAcHkmPB8a.SITESURLS[iI7tuF0nEQoR(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᗡ")][jxCVeKSLb9rGDOl0Qtw6]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,BarIC3eR9bS(u"ࠩࡓࡓࡘ࡚ࠧᗢ"),url,pjBAh5E2XWYmHx,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡍࡅࡕࡡࡖࡍ࡙ࡋࡓࡠࡗࡖࡅࡌࡋ࠭࠲ࡵࡷࠫᗣ"))
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫᗤ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࡛ࠬࡓࡂࠩᗥ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡋࡪࡰࡪࡨࡴࡳࠧᗦ"),Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡖࡍࠪᗧ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(iI7tuF0nEQoR(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨᗨ"),iiLyoNwGbH03DIXhAkZn(u"ࠩࡘࡅࡊ࠭ᗩ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(i80mE7lHUwVk(u"ࠪࡗࡦࡻࡤࡪࠢࡄࡶࡦࡨࡩࡢࠩᗪ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡐ࡙ࡁࠨᗫ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(BarIC3eR9bS(u"ࠬࡔ࡯ࡳࡶ࡫ࠤࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧᗬ"),FAwWlRJg0UkN1(u"࠭ࡎ࠯ࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫᗭ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨᗮ"),ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨ࡙࠱ࡗࡦ࡮ࡡࡳࡣࠪᗯ"))
	jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace(OUFxZPuXDoGAbRz(u"ࠩࡢࡣࡤ࠭ᗰ"),rBcdwYZInhgO29jtkFAfGxi7)
	try: yeAYHl6TokLtp = TqNUy3Z4SFWvplGwXC82A(iI7tuF0nEQoR(u"ࠪࡰ࡮ࡹࡴࠨᗱ"),jS6fQGXeouTB7xKd32ZMy)
	except:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫᗲ"))
		return
	PPqQKi3NLtoR,okQJCyRB8Nxrpq6nHmf,cAJum6KfMUlnZq0F = yeAYHl6TokLtp
	aNzq5td91wvbHCPeh3kWUSQIniRGM,pBzQb0rePEJ4T62iLDsdWtwFIOxcl = [],[]
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1,mihCYbzk2BDv7xULnue1E8VtaF95MA,xWJX0pYFSHq8zjKoDlPhUVNiab in okQJCyRB8Nxrpq6nHmf:
		if mihCYbzk2BDv7xULnue1E8VtaF95MA.isdigit(): mihCYbzk2BDv7xULnue1E8VtaF95MA = YZXtBgvUPoM5sb(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᗳ") if int(mihCYbzk2BDv7xULnue1E8VtaF95MA)>IXE6voNmrb182AyQ(u"࠻࠰ដ") else RRbvqditj184m3(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᗴ")
		if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in wAcHkmPB8a.non_videos_actions:
			if   mihCYbzk2BDv7xULnue1E8VtaF95MA==ne7wF4gSTRZo(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪᗵ"): aNzq5td91wvbHCPeh3kWUSQIniRGM.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			elif mihCYbzk2BDv7xULnue1E8VtaF95MA==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪᗶ"): pBzQb0rePEJ4T62iLDsdWtwFIOxcl.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᗷ"),OUFxZPuXDoGAbRz(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨᗸ"),[yeAYHl6TokLtp,aNzq5td91wvbHCPeh3kWUSQIniRGM,pBzQb0rePEJ4T62iLDsdWtwFIOxcl],DNh1dgpa4BK)
	return yeAYHl6TokLtp,aNzq5td91wvbHCPeh3kWUSQIniRGM,pBzQb0rePEJ4T62iLDsdWtwFIOxcl
def JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(WsqHDu9AgOMaToeBEYhQb,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4=gby0BnUuTNFk,cIO1sJZ5mTV94jpnl=gby0BnUuTNFk):
	if q2qPkMFpR1G86dEAKXHivor9N(u"ࠫ࠿ࡀࠧᗹ") in ozVQbncL9s8rw5DHa: ozVQbncL9s8rw5DHa,OORugdCwcD9UrzXtT7vML1FWasP = ozVQbncL9s8rw5DHa.split(TeYukOUW7i5NBM926DCjaAn0(u"ࠬࡀ࠺ࠨᗺ"))
	else: ozVQbncL9s8rw5DHa,OORugdCwcD9UrzXtT7vML1FWasP = ozVQbncL9s8rw5DHa,VzO1gCHmjZ2ebRIL(u"࠭ࠧᗻ")
	Tf5ueYGZIFl1hraoEOVKi,agKbMorQYsZ6y8pqOUjhNk3J4iVGA,AkXgI1l3bC2v5rOeNw6H74PfadK,f42bSj1zmowOKVg3PNna = l5lOpSiDHhYnLoge1t3b6awkmxT(KKFPNRzufO)
	ccqLuty2YZ8xTwmN4 = D6eSPULGzKbwjIV9Ao1lc.copy() if isinstance(D6eSPULGzKbwjIV9Ao1lc,dict) else D6eSPULGzKbwjIV9Ao1lc
	AvDtLJr2PUKNG0uanEMI = ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,ccqLuty2YZ8xTwmN4,c37Wbnk2A8Zx
	if WsqHDu9AgOMaToeBEYhQb<xn867tCVlscY4qbWZfh:
		dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,YZXtBgvUPoM5sb(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᗼ"),AvDtLJr2PUKNG0uanEMI)
		WsqHDu9AgOMaToeBEYhQb = -WsqHDu9AgOMaToeBEYhQb
	if WsqHDu9AgOMaToeBEYhQb>xn867tCVlscY4qbWZfh:
		tKObfFRod18ZU = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,YZXtBgvUPoM5sb(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪᗽ"),KJLkQsqSHMR1Np2(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬᗾ"),AvDtLJr2PUKNG0uanEMI)
		if tKObfFRod18ZU.succeeded:
			laeTCpY1R4wQDf7LOBVqXhsoSJ96EU(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᗿ"),Tf5ueYGZIFl1hraoEOVKi,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,bTh6JaVi1mOoCEeKZ4kS8AWsnl,ozVQbncL9s8rw5DHa)
			return tKObfFRod18ZU
	if OORugdCwcD9UrzXtT7vML1FWasP==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘ࠭ᘀ"): tKObfFRod18ZU = MIFwij6WB4lEfepoGusVtZS75(xn867tCVlscY4qbWZfh,ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
	else: tKObfFRod18ZU = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4,cIO1sJZ5mTV94jpnl)
	if tKObfFRod18ZU.succeeded:
		if mmbcsf2pd7gyjzreB(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᘁ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: tKObfFRod18ZU.content = aCrkVzGIFeXRPvc401sf(tKObfFRod18ZU.content,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽ࡟ࡉࡖࡐࡐࡤ࡫࡮ࡤࡱࡧࡩࡷ࠭ᘂ"))
		if tKObfFRod18ZU.scrape: WsqHDu9AgOMaToeBEYhQb = Q3J7xTKDuAUoaPlB
		if WsqHDu9AgOMaToeBEYhQb and tKObfFRod18ZU.content: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᘃ"),AvDtLJr2PUKNG0uanEMI,tKObfFRod18ZU,WsqHDu9AgOMaToeBEYhQb)
	return tKObfFRod18ZU
def QKTr6npsGvEUkai(ozVQbncL9s8rw5DHa,KKFPNRzufO,data,headers,allow_redirects,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4,cIO1sJZ5mTV94jpnl):
	if data==gby0BnUuTNFk: data = {}
	if headers==gby0BnUuTNFk: headers = {}
	pMjyCGcfHoJ8akULEdDKeXPYzmW0 = w8Ui6RsVhSPrqHfO4 if allow_redirects in [gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4] else yrcbRSFswvAfEdIWVj
	PPoNs5gLd86 = w8Ui6RsVhSPrqHfO4 if showDialogs in [gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4] else yrcbRSFswvAfEdIWVj
	SIJiYLXn7KGzP = w8Ui6RsVhSPrqHfO4 if Go0BTVDEfnrsliS4 in [gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4] else yrcbRSFswvAfEdIWVj
	Iu53qUzjC8cyEV9D1ThbWFBLJP76mn = w8Ui6RsVhSPrqHfO4 if cIO1sJZ5mTV94jpnl in [gby0BnUuTNFk,w8Ui6RsVhSPrqHfO4] else yrcbRSFswvAfEdIWVj
	uWIUplrbFd = data
	IciL6hoO5F1MDSVPjypWZs8kKx = headers
	PPoNs5gLd86 = PPoNs5gLd86 if wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX==D0DRCGqknfT2tKPY6N else wAcHkmPB8a.ALLOW_SHOWDIALOGS_FIX
	SIJiYLXn7KGzP = SIJiYLXn7KGzP if wAcHkmPB8a.ALLOW_DNS_FIX==D0DRCGqknfT2tKPY6N else wAcHkmPB8a.ALLOW_DNS_FIX
	Iu53qUzjC8cyEV9D1ThbWFBLJP76mn = Iu53qUzjC8cyEV9D1ThbWFBLJP76mn if wAcHkmPB8a.ALLOW_PROXY_FIX==D0DRCGqknfT2tKPY6N else wAcHkmPB8a.ALLOW_PROXY_FIX
	if bTh6JaVi1mOoCEeKZ4kS8AWsnl==OUFxZPuXDoGAbRz(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭ᘄ"): IciL6hoO5F1MDSVPjypWZs8kKx = {}
	else:
		pp9meA7YClvoQ4O2 = list(IciL6hoO5F1MDSVPjypWZs8kKx.keys())
		if q2qPkMFpR1G86dEAKXHivor9N(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᘅ") not in pp9meA7YClvoQ4O2: IciL6hoO5F1MDSVPjypWZs8kKx[KJLkQsqSHMR1Np2(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᘆ")] = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫ࡭ࡺࡴࡱࠩᘇ")
		if Ducd5PRjQXaB9SIN7VrJ1G(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᘈ") not in pp9meA7YClvoQ4O2: IciL6hoO5F1MDSVPjypWZs8kKx[mmbcsf2pd7gyjzreB(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᘉ")] = Zc6lYG3a02XVPA1WLr(w8Ui6RsVhSPrqHfO4)
	return ozVQbncL9s8rw5DHa,KKFPNRzufO,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,SIJiYLXn7KGzP,Iu53qUzjC8cyEV9D1ThbWFBLJP76mn
def ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4=gby0BnUuTNFk,cIO1sJZ5mTV94jpnl=gby0BnUuTNFk):
	S9IunMKjOdY0 = QKTr6npsGvEUkai(ozVQbncL9s8rw5DHa,KKFPNRzufO,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,showDialogs,bTh6JaVi1mOoCEeKZ4kS8AWsnl,Go0BTVDEfnrsliS4,cIO1sJZ5mTV94jpnl)
	ozVQbncL9s8rw5DHa,KKFPNRzufO,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,SIJiYLXn7KGzP,Iu53qUzjC8cyEV9D1ThbWFBLJP76mn = S9IunMKjOdY0
	Tf5ueYGZIFl1hraoEOVKi,agKbMorQYsZ6y8pqOUjhNk3J4iVGA,AkXgI1l3bC2v5rOeNw6H74PfadK,f42bSj1zmowOKVg3PNna = l5lOpSiDHhYnLoge1t3b6awkmxT(KKFPNRzufO)
	o742nplw96aA = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(ne7wF4gSTRZo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧᘊ"))
	VVRYrMqftdmjBAEQoXkcewuI2JTD0 = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(OUFxZPuXDoGAbRz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᘋ"))
	wR71aegTz8IfilEUDKCx2OY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᘌ"))
	QhLKyjVkO20Gdg8Y6NMpxT = w8Ui6RsVhSPrqHfO4 if any(value in KKFPNRzufO for value in OOnM4rmxZK3D2fV) else yrcbRSFswvAfEdIWVj
	if NupI74tJCzYXmles9SbR6(u"ࠪࠪࡺࡸ࡬࠾ࠩᘍ") in Tf5ueYGZIFl1hraoEOVKi and QhLKyjVkO20Gdg8Y6NMpxT: gsDHhlRerNi = Tf5ueYGZIFl1hraoEOVKi.rsplit(TeYukOUW7i5NBM926DCjaAn0(u"ࠫࠫࡻࡲ࡭࠿ࠪᘎ"),jxCVeKSLb9rGDOl0Qtw6)[jxCVeKSLb9rGDOl0Qtw6]
	else: gsDHhlRerNi = gby0BnUuTNFk
	UUXDd9wcunGk12ZP = wAcHkmPB8a.SITESURLS[IXE6voNmrb182AyQ(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᘏ")]
	MRKloy6qtkczFZwIGOgjdE = Tf5ueYGZIFl1hraoEOVKi in UUXDd9wcunGk12ZP or gsDHhlRerNi in UUXDd9wcunGk12ZP
	k56JR1aqK8QGuyF4ViWcIlfgN3E = wAcHkmPB8a.SITESURLS[iiLyoNwGbH03DIXhAkZn(u"࠭ࡒࡆࡒࡒࡗࠬᘐ")]
	iWLv2HeZpnaMj3UdwR7G = Tf5ueYGZIFl1hraoEOVKi in k56JR1aqK8QGuyF4ViWcIlfgN3E or gsDHhlRerNi in k56JR1aqK8QGuyF4ViWcIlfgN3E
	vK8Lc3JFp1CMgBqd5aRortk7fE = MRKloy6qtkczFZwIGOgjdE or iWLv2HeZpnaMj3UdwR7G
	GgOPqmJX63cyixzED7rRCZVSA = yrcbRSFswvAfEdIWVj
	TTUogDs9ckwlCjiEXWPSdbY3xJQZ = w8Ui6RsVhSPrqHfO4
	JWYDAuUfCcmdnajiV7Mysq = agKbMorQYsZ6y8pqOUjhNk3J4iVGA==None and AkXgI1l3bC2v5rOeNw6H74PfadK==None and not QhLKyjVkO20Gdg8Y6NMpxT
	if JWYDAuUfCcmdnajiV7Mysq and vK8Lc3JFp1CMgBqd5aRortk7fE:
		if MRKloy6qtkczFZwIGOgjdE:
			tLpTKQhAzugflk0nveIo8aVj7 = UUXDd9wcunGk12ZP.index(Tf5ueYGZIFl1hraoEOVKi)
			M98yRNIfdup12oFji = wAcHkmPB8a.SITESURLS[iiLyoNwGbH03DIXhAkZn(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬᘑ")][tLpTKQhAzugflk0nveIo8aVj7]
			BYNn3XdGrv4UwfJc1lksZbMPgo = wAcHkmPB8a.SITESURLS[n6JjFHfmydIaLut(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠷࠭ᘒ")][tLpTKQhAzugflk0nveIo8aVj7]
			I0K9B8VwPz2npeWTqg73vOALlHxo = wAcHkmPB8a.SITESURLS[zDSw8LCxMQyraeXhojIWKmU(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧᘓ")][tLpTKQhAzugflk0nveIo8aVj7]
			NTsBLdcbGjH2vla3yV7 = wAcHkmPB8a.api_python_actions[tLpTKQhAzugflk0nveIo8aVj7]
			if NTsBLdcbGjH2vla3yV7==VzO1gCHmjZ2ebRIL(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬᘔ"): SIJiYLXn7KGzP,Iu53qUzjC8cyEV9D1ThbWFBLJP76mn,TTUogDs9ckwlCjiEXWPSdbY3xJQZ = yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj
			elif NTsBLdcbGjH2vla3yV7==kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬᘕ"): GgOPqmJX63cyixzED7rRCZVSA = w8Ui6RsVhSPrqHfO4
		elif iWLv2HeZpnaMj3UdwR7G:
			tLpTKQhAzugflk0nveIo8aVj7 = k56JR1aqK8QGuyF4ViWcIlfgN3E.index(Tf5ueYGZIFl1hraoEOVKi)
			M98yRNIfdup12oFji = wAcHkmPB8a.SITESURLS[Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠲ࠩᘖ")][tLpTKQhAzugflk0nveIo8aVj7]
			BYNn3XdGrv4UwfJc1lksZbMPgo = wAcHkmPB8a.SITESURLS[tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠴ࠪᘗ")][tLpTKQhAzugflk0nveIo8aVj7]
			I0K9B8VwPz2npeWTqg73vOALlHxo = wAcHkmPB8a.SITESURLS[iiLyoNwGbH03DIXhAkZn(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫᘘ")][tLpTKQhAzugflk0nveIo8aVj7]
			NTsBLdcbGjH2vla3yV7 = wAcHkmPB8a.api_repos_actions[tLpTKQhAzugflk0nveIo8aVj7]
	if AkXgI1l3bC2v5rOeNw6H74PfadK==gby0BnUuTNFk: AkXgI1l3bC2v5rOeNw6H74PfadK = o742nplw96aA
	elif AkXgI1l3bC2v5rOeNw6H74PfadK==None and VVRYrMqftdmjBAEQoXkcewuI2JTD0 in [sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡃࡘࡘࡔ࠭ᘙ"),FAwWlRJg0UkN1(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᘚ")] and SIJiYLXn7KGzP: AkXgI1l3bC2v5rOeNw6H74PfadK = o742nplw96aA
	if MRKloy6qtkczFZwIGOgjdE or iWLv2HeZpnaMj3UdwR7G: BImTkcn8Lh1gOACeHiwob = zDSw8LCxMQyraeXhojIWKmU(u"࠲࠱ឋ")
	elif QhLKyjVkO20Gdg8Y6NMpxT: BImTkcn8Lh1gOACeHiwob = nJF7oflOk6cLGSAey(u"࠷࠲ឌ")
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl in cQtJGSiEvRdY1r04L3VklZfDFP8: BImTkcn8Lh1gOACeHiwob = nJF7oflOk6cLGSAey(u"࠳࠳ឍ")
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬᘛ"): BImTkcn8Lh1gOACeHiwob = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠵࠴ណ")
	elif bTh6JaVi1mOoCEeKZ4kS8AWsnl==VzO1gCHmjZ2ebRIL(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬᘜ"): BImTkcn8Lh1gOACeHiwob = q2qPkMFpR1G86dEAKXHivor9N(u"࠶࠵ត")
	elif kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓࠧᘝ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = q2qPkMFpR1G86dEAKXHivor9N(u"࠼࠶ថ")
	elif RRbvqditj184m3(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ᘞ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠽࠵ទ")
	elif ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᘟ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠲࠶ធ")
	elif TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡃࡋ࡛ࡆࡑࠧᘠ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = IXE6voNmrb182AyQ(u"࠳࠲ន")
	elif i80mE7lHUwVk(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬᘡ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = DWgX6JfF3SnlsQwtN1cvGk8L(u"࠴࠳ប")
	elif uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᘢ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠶࠴ផ")
	elif YZXtBgvUPoM5sb(u"ࠫࡆࡑࡏࡂࡏࠪᘣ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = YZXtBgvUPoM5sb(u"࠶࠺ព")
	elif kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡇࡋࡘࡃࡐࠫᘤ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠸࠶ភ")
	elif YZXtBgvUPoM5sb(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᘥ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = ggtuNcvTn3HQ7SpE2(u"࠸࠰ម")
	elif ne7wF4gSTRZo(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩᘦ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = i80mE7lHUwVk(u"࠶࠱យ")
	elif oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪᘧ") in bTh6JaVi1mOoCEeKZ4kS8AWsnl: BImTkcn8Lh1gOACeHiwob = RRbvqditj184m3(u"࠵࠲រ")
	else: BImTkcn8Lh1gOACeHiwob = n6JjFHfmydIaLut(u"࠳࠸ល")
	HyZlj61720ELzR = (agKbMorQYsZ6y8pqOUjhNk3J4iVGA!=None)
	a2uOQWKR8vwfz0AJCYEmIFy1GHr7p4 = (AkXgI1l3bC2v5rOeNw6H74PfadK!=None and VVRYrMqftdmjBAEQoXkcewuI2JTD0!=uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࡖࡘࡔࡖࠧᘨ"))
	if HyZlj61720ELzR and not QhLKyjVkO20Gdg8Y6NMpxT: RLfOB3nsqaWXTugJvY(IXE6voNmrb182AyQ(u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭ᘩ"),agKbMorQYsZ6y8pqOUjhNk3J4iVGA)
	elif a2uOQWKR8vwfz0AJCYEmIFy1GHr7p4: RLfOB3nsqaWXTugJvY(nJF7oflOk6cLGSAey(u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫᘪ"),AkXgI1l3bC2v5rOeNw6H74PfadK)
	if HyZlj61720ELzR:
		RoMUgG4lAyZ2ExSimCpqz = {TeYukOUW7i5NBM926DCjaAn0(u"ࠧ࡮ࡴࡵࡲࠥᘫ"):agKbMorQYsZ6y8pqOUjhNk3J4iVGA,RRbvqditj184m3(u"ࠨࡨࡵࡶࡳࡷࠧᘬ"):agKbMorQYsZ6y8pqOUjhNk3J4iVGA}
		XSfAcYmZ83e4 = agKbMorQYsZ6y8pqOUjhNk3J4iVGA
	else: RoMUgG4lAyZ2ExSimCpqz,XSfAcYmZ83e4 = {},gby0BnUuTNFk
	if a2uOQWKR8vwfz0AJCYEmIFy1GHr7p4:
		import urllib3.util.connection as jaG5xMmILXvegsAphnTK
		arhl1O0zEt2gDPqQBn5mfFJ7IbCTv = CUswqTPGY5okFjxzZnvyrV6IBAWb(jaG5xMmILXvegsAphnTK,o742nplw96aA,w8Ui6RsVhSPrqHfO4)
	VsrxfDgSq3F,EzcSMyRpkv,OOXCxHcokSPhK316WJ,ttsjmCFyUlgSAuQcVP,AGLrtdmvik4Np0Beq3H6gXy57OEwF,lBbkz4vToImZh7JSVq,verify = pMjyCGcfHoJ8akULEdDKeXPYzmW0,bTh6JaVi1mOoCEeKZ4kS8AWsnl,ozVQbncL9s8rw5DHa,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj,f42bSj1zmowOKVg3PNna
	if GgOPqmJX63cyixzED7rRCZVSA: AGLrtdmvik4Np0Beq3H6gXy57OEwF = w8Ui6RsVhSPrqHfO4
	if vK8Lc3JFp1CMgBqd5aRortk7fE or pMjyCGcfHoJ8akULEdDKeXPYzmW0: VsrxfDgSq3F = yrcbRSFswvAfEdIWVj
	g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc = -jxCVeKSLb9rGDOl0Qtw6,OUFxZPuXDoGAbRz(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸࠧᘭ")
	yJwkugDG4AsejXPMvQ2IKc5 = yrcbRSFswvAfEdIWVj
	if not wAcHkmPB8a.FORWARDS_HOSTNAMES: wAcHkmPB8a.FORWARDS_HOSTNAMES = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,IXE6voNmrb182AyQ(u"ࠨࡦ࡬ࡧࡹ࠭ᘮ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠸ࠧᘯ"),KJLkQsqSHMR1Np2(u"ࠪࡊࡔࡘࡗࡂࡔࡇࡗࠬᘰ"))
	B9sEoSvw4qAY56KdTGVei8M7R = []
	while Tf5ueYGZIFl1hraoEOVKi not in B9sEoSvw4qAY56KdTGVei8M7R and Tf5ueYGZIFl1hraoEOVKi in list(wAcHkmPB8a.FORWARDS_HOSTNAMES.keys()):
		B9sEoSvw4qAY56KdTGVei8M7R.append(Tf5ueYGZIFl1hraoEOVKi)
		Tf5ueYGZIFl1hraoEOVKi = wAcHkmPB8a.FORWARDS_HOSTNAMES[Tf5ueYGZIFl1hraoEOVKi]
	ttnPORNcv7gM81XFAUJe = uWIUplrbFd
	if MRKloy6qtkczFZwIGOgjdE:
		OOXCxHcokSPhK316WJ = q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡕࡕࡓࡕࠩᘱ")
		IciL6hoO5F1MDSVPjypWZs8kKx[kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡇࡖ࠮ࡇࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬᘲ")] = BarIC3eR9bS(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫᘳ")
		k9kNo4bMeiQ0uE = FoCsyPaNjhWf.dumps(uWIUplrbFd)
		ttnPORNcv7gM81XFAUJe = gMxpOG8fEI1i0(k9kNo4bMeiQ0uE,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠻࠵࠷࠽࠴࠺࠵࠸࠺វ"))
		Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧࡀࡷࡶࡩࡷࡃࠧᘴ")+DpqPQYGB7mt
	import requests as NGcESCFxok0
	for t3t986iTduqY in range(iiLyoNwGbH03DIXhAkZn(u"࠽ឝ")):
		GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
		if t3t986iTduqY:
			EzcSMyRpkv = iI7tuF0nEQoR(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩᘵ")
			try: tKObfFRod18ZU.close()
			except: pass
		if QhLKyjVkO20Gdg8Y6NMpxT or not HyZlj61720ELzR: laeTCpY1R4wQDf7LOBVqXhsoSJ96EU(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧᘶ"),Tf5ueYGZIFl1hraoEOVKi,ttnPORNcv7gM81XFAUJe,IciL6hoO5F1MDSVPjypWZs8kKx,EzcSMyRpkv,OOXCxHcokSPhK316WJ)
		mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi
		try:
			tKObfFRod18ZU = NGcESCFxok0.request(OOXCxHcokSPhK316WJ,Tf5ueYGZIFl1hraoEOVKi,data=ttnPORNcv7gM81XFAUJe,headers=IciL6hoO5F1MDSVPjypWZs8kKx,verify=verify,allow_redirects=VsrxfDgSq3F,timeout=BImTkcn8Lh1gOACeHiwob,proxies=RoMUgG4lAyZ2ExSimCpqz)
			if tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠸࠶࠰ឞ")<=tKObfFRod18ZU.status_code<=iiauUxMktNW5X(u"࠹࠹࠺ស"):
				if not ttsjmCFyUlgSAuQcVP:
					SSqweDUBYv4bkO = tKObfFRod18ZU.headers.get(IXE6voNmrb182AyQ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᘷ")) or tKObfFRod18ZU.headers.get(YZXtBgvUPoM5sb(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᘸ")) or gby0BnUuTNFk
					if SSqweDUBYv4bkO.startswith(iI7tuF0nEQoR(u"ࠬࡀࠧᘹ")): SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi+SSqweDUBYv4bkO
					if SSqweDUBYv4bkO: Tf5ueYGZIFl1hraoEOVKi = SSqweDUBYv4bkO
					else: ttsjmCFyUlgSAuQcVP = w8Ui6RsVhSPrqHfO4
					if not ttsjmCFyUlgSAuQcVP: Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi.encode(MlTVLBZ92kzorIq1Yw(u"࠭࡬ࡢࡶ࡬ࡲ࠶࠭ᘺ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᘻ")).decode(JJQFjSIlALchiMzG9,TeYukOUW7i5NBM926DCjaAn0(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᘼ"))
					if vK8Lc3JFp1CMgBqd5aRortk7fE and tKObfFRod18ZU.status_code==OUFxZPuXDoGAbRz(u"࠳࠱࠹ហ"):
						VsrxfDgSq3F = pMjyCGcfHoJ8akULEdDKeXPYzmW0
						OOXCxHcokSPhK316WJ = ozVQbncL9s8rw5DHa
						ttsjmCFyUlgSAuQcVP = w8Ui6RsVhSPrqHfO4
						jog5ItWUr0
				if not ttsjmCFyUlgSAuQcVP or pMjyCGcfHoJ8akULEdDKeXPYzmW0:
					if OUFxZPuXDoGAbRz(u"ࠩ࡫ࡸࡹࡶࠧᘽ") not in Tf5ueYGZIFl1hraoEOVKi:
						f7QwWAlNGsyqgUa0e3 = mDR9euKnv4jMSdbEpwcktJz5W6Cf(mm7pzl3HMi0R8fGu,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪࡹࡷࡲࠧᘾ"))
						Tf5ueYGZIFl1hraoEOVKi = f7QwWAlNGsyqgUa0e3+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫ࠴࠭ᘿ")+Tf5ueYGZIFl1hraoEOVKi.lstrip(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬ࠵ࠧᙀ"))
				if Tf5ueYGZIFl1hraoEOVKi!=mm7pzl3HMi0R8fGu:
					wAcHkmPB8a.FORWARDS_HOSTNAMES[mm7pzl3HMi0R8fGu] = Tf5ueYGZIFl1hraoEOVKi
					yJwkugDG4AsejXPMvQ2IKc5 = w8Ui6RsVhSPrqHfO4
				if not ttsjmCFyUlgSAuQcVP:
					QshmVTR0vyCEMk34f8J5Ypd = tKObfFRod18ZU
					if ymlrSBXjxRaY5kcKtU7MTVpAfeJL(Tf5ueYGZIFl1hraoEOVKi): ttsjmCFyUlgSAuQcVP = w8Ui6RsVhSPrqHfO4
			elif q2qPkMFpR1G86dEAKXHivor9N(u"࠷࠸࠴អ")<=tKObfFRod18ZU.status_code<=kreQUwJis7YmC2yqWtIF09pgjbD(u"࠶࠻࠼ឡ"): AGLrtdmvik4Np0Beq3H6gXy57OEwF = w8Ui6RsVhSPrqHfO4
			else: ttsjmCFyUlgSAuQcVP = w8Ui6RsVhSPrqHfO4
			if not ttsjmCFyUlgSAuQcVP and not pMjyCGcfHoJ8akULEdDKeXPYzmW0 and QshmVTR0vyCEMk34f8J5Ypd.headers: tKObfFRod18ZU = QshmVTR0vyCEMk34f8J5Ypd
			mm7pzl3HMi0R8fGu = tKObfFRod18ZU.url
			g8E2PLGXKpYsZnAHjtol = tKObfFRod18ZU.status_code
			PJnMHzOorxmLAwc = tKObfFRod18ZU.reason
			tKObfFRod18ZU.raise_for_status()
			GGinQY9gb7uy8VeIrxH5 = w8Ui6RsVhSPrqHfO4
		except NGcESCFxok0.exceptions.HTTPError as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			pass
		except NGcESCFxok0.exceptions.Timeout as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			if cAIRPFK6boejVU549WzqBGCaJ0r: PJnMHzOorxmLAwc = str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb.message).split(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࠺ࠡࠩᙁ"))[jxCVeKSLb9rGDOl0Qtw6]
			else: PJnMHzOorxmLAwc = str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb).split(FAwWlRJg0UkN1(u"ࠧ࠻ࠢࠪᙂ"))[jxCVeKSLb9rGDOl0Qtw6]
		except NGcESCFxok0.exceptions.ConnectionError as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			try: xNE4SpiDJq6Cw8l = QdjB4N09zlKLRJ52gHvPZo7nqtCrb.message[xn867tCVlscY4qbWZfh]
			except: xNE4SpiDJq6Cw8l = str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb)
			PPklWtXdvsGCc6e9D = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᙃ"),xNE4SpiDJq6Cw8l)
			if not PPklWtXdvsGCc6e9D: PPklWtXdvsGCc6e9D = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(ggtuNcvTn3HQ7SpE2(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧᙄ"),xNE4SpiDJq6Cw8l)
			if not PPklWtXdvsGCc6e9D:
				hTmqNbMLlD4365aesR0FEK8 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(q2qPkMFpR1G86dEAKXHivor9N(u"ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮ࡀࠢᙅ"),xNE4SpiDJq6Cw8l)
				if hTmqNbMLlD4365aesR0FEK8: PPklWtXdvsGCc6e9D = [hTmqNbMLlD4365aesR0FEK8[xn867tCVlscY4qbWZfh][jxCVeKSLb9rGDOl0Qtw6],hTmqNbMLlD4365aesR0FEK8[xn867tCVlscY4qbWZfh][xn867tCVlscY4qbWZfh]]
			if not PPklWtXdvsGCc6e9D: PPklWtXdvsGCc6e9D = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(iI7tuF0nEQoR(u"ࠦ࠿࠮࡜ࡥ࠭ࠬ࠾ࠥ࠮࠮ࠫࡁࠬࠫࠧᙆ"),xNE4SpiDJq6Cw8l)
			if not PPklWtXdvsGCc6e9D: PPklWtXdvsGCc6e9D = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(mmbcsf2pd7gyjzreB(u"ࠧࠦࠨ࡝ࡦ࠮࠭ࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᙇ"),xNE4SpiDJq6Cw8l)
			try: g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc = PPklWtXdvsGCc6e9D[xn867tCVlscY4qbWZfh]
			except: g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc = -dNx9DVCtafk4r,xNE4SpiDJq6Cw8l
		except NGcESCFxok0.exceptions.RequestException as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			if cAIRPFK6boejVU549WzqBGCaJ0r: PJnMHzOorxmLAwc = QdjB4N09zlKLRJ52gHvPZo7nqtCrb.message
			else: PJnMHzOorxmLAwc = str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb)
		except:
			try: g8E2PLGXKpYsZnAHjtol = tKObfFRod18ZU.status_code
			except: pass
			try: PJnMHzOorxmLAwc = tKObfFRod18ZU.reason
			except: pass
		PJnMHzOorxmLAwc = str(PJnMHzOorxmLAwc)
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,n6JjFHfmydIaLut(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᙈ")+str(g8E2PLGXKpYsZnAHjtol)+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᙉ")+PJnMHzOorxmLAwc+iI7tuF0nEQoR(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᙊ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+TeYukOUW7i5NBM926DCjaAn0(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᙋ")+oHSEYlfpLzQrC1(KKFPNRzufO,bTh6JaVi1mOoCEeKZ4kS8AWsnl)+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࠤࡢ࠭ᙌ"))
		if JWYDAuUfCcmdnajiV7Mysq and vK8Lc3JFp1CMgBqd5aRortk7fE and not AGLrtdmvik4Np0Beq3H6gXy57OEwF and g8E2PLGXKpYsZnAHjtol!=nJF7oflOk6cLGSAey(u"࠵࠴࠵ឣ") and YZXtBgvUPoM5sb(u"ࠫ࠶࠸࠷࠯࠲࠱࠴࠳࠷ࠧᙍ") not in Tf5ueYGZIFl1hraoEOVKi:
			if Tf5ueYGZIFl1hraoEOVKi not in [M98yRNIfdup12oFji,BYNn3XdGrv4UwfJc1lksZbMPgo,I0K9B8VwPz2npeWTqg73vOALlHxo]: Tf5ueYGZIFl1hraoEOVKi,AGLrtdmvik4Np0Beq3H6gXy57OEwF = M98yRNIfdup12oFji,yrcbRSFswvAfEdIWVj
			elif Tf5ueYGZIFl1hraoEOVKi==M98yRNIfdup12oFji: Tf5ueYGZIFl1hraoEOVKi,AGLrtdmvik4Np0Beq3H6gXy57OEwF = BYNn3XdGrv4UwfJc1lksZbMPgo,yrcbRSFswvAfEdIWVj
			elif Tf5ueYGZIFl1hraoEOVKi==BYNn3XdGrv4UwfJc1lksZbMPgo: Tf5ueYGZIFl1hraoEOVKi,AGLrtdmvik4Np0Beq3H6gXy57OEwF = I0K9B8VwPz2npeWTqg73vOALlHxo,w8Ui6RsVhSPrqHfO4
			continue
		if not ttsjmCFyUlgSAuQcVP and GGinQY9gb7uy8VeIrxH5: continue
		break
	g8E2PLGXKpYsZnAHjtol = int(g8E2PLGXKpYsZnAHjtol)
	if not GGinQY9gb7uy8VeIrxH5:
		DpIwf4n7XOuL8xE1dPvYWFsi3 = Xa2nju83yQLEKgMhC65PbcqzIRJ(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭ᙎ"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠼࠵ឤ"))
		if DpIwf4n7XOuL8xE1dPvYWFsi3==-jxCVeKSLb9rGDOl0Qtw6:
			SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,q2qPkMFpR1G86dEAKXHivor9N(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࠤࡉࡏࡓࡄࡑࡑࡒࡊࡉࡔࡆࡆࠣࠤ࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡺ࡯ࠡࡶ࡫ࡩࠥ࡯࡮ࡵࡧࡵࡲࡪࡺࠠࠢࠣࠪᙏ"))
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,i80mE7lHUwVk(u"ࠧๅๆฦืๆࠦฬ่ษี็ࠥเ๊า่ࠢีอ๎ืࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣ฾๏ืࠠใษาีࠥษๆࠡ์ึฮำีๅࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฽ิอฯศฬࠣะ์อาไࠢ฽๎ึࠦีฮ์ะอࠥࡢ࡮࡝ࡰ่ࠣา๊ࠠศๆุ่่๊ษࠡฬฦ็ิࠦร็ࠢฯ๋ฬุใࠡ็ิฬํ฽ࠠษูิ๎็ฯࠠึฯํัฮࠦศศๆศ๊ฯืๆห๋ࠢๅ๏ํࠠศๆศ๊ฯืๆหࠢอ฽๊๊ࠠษื๋ีฮࠦฬ๋ัฬࠫᙐ"))
			cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
			return tKObfFRod18ZU
	if not GGinQY9gb7uy8VeIrxH5 and B9sEoSvw4qAY56KdTGVei8M7R:
		for url in B9sEoSvw4qAY56KdTGVei8M7R:
			if url in list(wAcHkmPB8a.FORWARDS_HOSTNAMES.keys()):
				del wAcHkmPB8a.FORWARDS_HOSTNAMES[url]
				yJwkugDG4AsejXPMvQ2IKc5 = w8Ui6RsVhSPrqHfO4
	if yJwkugDG4AsejXPMvQ2IKc5:
		CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭ᙑ"),iiLyoNwGbH03DIXhAkZn(u"ࠩࡉࡓࡗ࡝ࡁࡓࡆࡖࠫᙒ"),wAcHkmPB8a.FORWARDS_HOSTNAMES,Q3J7xTKDuAUoaPlB)
		wAcHkmPB8a.FORWARDS_HOSTNAMES = {}
	if AkXgI1l3bC2v5rOeNw6H74PfadK!=None and VVRYrMqftdmjBAEQoXkcewuI2JTD0!=NupI74tJCzYXmles9SbR6(u"ࠪࡗ࡙ࡕࡐࠨᙓ"): jaG5xMmILXvegsAphnTK.create_connection = arhl1O0zEt2gDPqQBn5mfFJ7IbCTv
	if VVRYrMqftdmjBAEQoXkcewuI2JTD0==BarIC3eR9bS(u"ࠫࡆࡒࡗࡂ࡛ࡖࠫᙔ") and SIJiYLXn7KGzP: AkXgI1l3bC2v5rOeNw6H74PfadK = None
	if not GGinQY9gb7uy8VeIrxH5 and agKbMorQYsZ6y8pqOUjhNk3J4iVGA==None and bTh6JaVi1mOoCEeKZ4kS8AWsnl not in cQtJGSiEvRdY1r04L3VklZfDFP8:
		fSqpV0sUvcr153IYbT9lKezQRE7 = WhjmDeqacBg.format_exc()
		if fSqpV0sUvcr153IYbT9lKezQRE7!=RRbvqditj184m3(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨᙕ"): Pt41K3suxDF9nE0wLvU7dGq2ceNT.stderr.write(fSqpV0sUvcr153IYbT9lKezQRE7)
	ffLC6tdJcmlOFn4wY = PKSnHM3QkOgGUyABi12slV()
	if QhLKyjVkO20Gdg8Y6NMpxT: mm7pzl3HMi0R8fGu = gsDHhlRerNi
	if not mm7pzl3HMi0R8fGu: mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi
	ffLC6tdJcmlOFn4wY.url = mm7pzl3HMi0R8fGu
	ffLC6tdJcmlOFn4wY.scrape = QhLKyjVkO20Gdg8Y6NMpxT
	try:
		xmN8TMoaUAjwHGpQ = tKObfFRod18ZU.headers
		if not xmN8TMoaUAjwHGpQ.get(n6JjFHfmydIaLut(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᙖ")) and not xmN8TMoaUAjwHGpQ.get(NupI74tJCzYXmles9SbR6(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᙗ")): xmN8TMoaUAjwHGpQ.headers[FAwWlRJg0UkN1(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᙘ")] = mm7pzl3HMi0R8fGu
	except: xmN8TMoaUAjwHGpQ = {}
	try:
		yEkAVSoXrnqhRieDguj = tKObfFRod18ZU.content
		if MRKloy6qtkczFZwIGOgjdE and yEkAVSoXrnqhRieDguj:
			c3pxEPyjVhsr6JTtOwndU = {LOCWmtqd0IAbgDQXw.lower(): TmCuWUtvES for LOCWmtqd0IAbgDQXw, TmCuWUtvES in tKObfFRod18ZU.headers.items()}
			if c3pxEPyjVhsr6JTtOwndU.get(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࡤࡺ࠲࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᙙ"))==BarIC3eR9bS(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᙚ"):
				yEkAVSoXrnqhRieDguj,PNizo6k4prVR5UYDmMS = CgLW92DUsmaqtjrGFod6(yEkAVSoXrnqhRieDguj,VzO1gCHmjZ2ebRIL(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ឥ"))
				if PNizo6k4prVR5UYDmMS==MlTVLBZ92kzorIq1Yw(u"ࠫࡎࡔࡖࡂࡎࡌࡈࡤ࡚ࡉࡎࡇࡖࡘࡆࡓࡐࠨᙛ"):
					PJnMHzOorxmLAwc,g8E2PLGXKpYsZnAHjtol = zDSw8LCxMQyraeXhojIWKmU(u"ࠬࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡁࡑࡋࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࠭ᙜ"),-DVbaycS5iITnPMRsdueXqg1wQx6ltr
					GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
					yEkAVSoXrnqhRieDguj = PJnMHzOorxmLAwc
	except: yEkAVSoXrnqhRieDguj = gby0BnUuTNFk
	if nqkybtoMBH and isinstance(yEkAVSoXrnqhRieDguj,bytes):
		try: yEkAVSoXrnqhRieDguj = yEkAVSoXrnqhRieDguj.decode(JJQFjSIlALchiMzG9)
		except: yEkAVSoXrnqhRieDguj = yEkAVSoXrnqhRieDguj.decode(LmIPKScVGEs)
	if QhLKyjVkO20Gdg8Y6NMpxT:
		if kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡉࡅࡎࡒࠢࠨᙝ") in yEkAVSoXrnqhRieDguj and sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠧࠣࡪࡷࡸࡵࡉ࡯ࡥࡧࠥ࠾࠷࠶࠰ࠨᙞ") in yEkAVSoXrnqhRieDguj: g8E2PLGXKpYsZnAHjtol,GGinQY9gb7uy8VeIrxH5 = -jJ4LEcdl5w7BPMbQ,yrcbRSFswvAfEdIWVj
	if MRKloy6qtkczFZwIGOgjdE and yEkAVSoXrnqhRieDguj and q2qPkMFpR1G86dEAKXHivor9N(u"࠵࠶࠲ឧ")<=g8E2PLGXKpYsZnAHjtol<=q2qPkMFpR1G86dEAKXHivor9N(u"࠻࠹࠺ឦ"): PJnMHzOorxmLAwc = yEkAVSoXrnqhRieDguj
	try: i7ChDdMF80ycYaLI = tKObfFRod18ZU.cookies.get_dict()
	except: i7ChDdMF80ycYaLI = {}
	try: tKObfFRod18ZU.close()
	except: pass
	ffLC6tdJcmlOFn4wY.code = g8E2PLGXKpYsZnAHjtol
	ffLC6tdJcmlOFn4wY.reason = PJnMHzOorxmLAwc
	ffLC6tdJcmlOFn4wY.content = yEkAVSoXrnqhRieDguj
	ffLC6tdJcmlOFn4wY.headers = xmN8TMoaUAjwHGpQ
	ffLC6tdJcmlOFn4wY.cookies = i7ChDdMF80ycYaLI
	ffLC6tdJcmlOFn4wY.succeeded = GGinQY9gb7uy8VeIrxH5
	ffLC6tdJcmlOFn4wY.scrapernumber = gby0BnUuTNFk
	ffLC6tdJcmlOFn4wY.scraperserver = gby0BnUuTNFk
	ffLC6tdJcmlOFn4wY.scraperurl = gby0BnUuTNFk
	MsBPlWUgFeOCAodtLNZScKh7ji4f = ffLC6tdJcmlOFn4wY.content.lower() if cAIRPFK6boejVU549WzqBGCaJ0r or isinstance(ffLC6tdJcmlOFn4wY.content,str) else gby0BnUuTNFk
	XxDqV6Qa2JhTiFBIcPWrLypts93 = (zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᙟ") in MsBPlWUgFeOCAodtLNZScKh7ji4f or nJF7oflOk6cLGSAey(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩᙠ") in MsBPlWUgFeOCAodtLNZScKh7ji4f) and MsBPlWUgFeOCAodtLNZScKh7ji4f.count(q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᙡ"))>dNx9DVCtafk4r and YZXtBgvUPoM5sb(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᙢ") not in bTh6JaVi1mOoCEeKZ4kS8AWsnl and lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪᙣ") not in bTh6JaVi1mOoCEeKZ4kS8AWsnl and KJLkQsqSHMR1Np2(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨᙤ") not in MsBPlWUgFeOCAodtLNZScKh7ji4f
	DItaA3JplQm408OW5evz6MLU = (IXE6voNmrb182AyQ(u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫᙥ") in MsBPlWUgFeOCAodtLNZScKh7ji4f and oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡴࡤࡽࠥ࡯ࡤ࠻ࠢࠪᙦ") in MsBPlWUgFeOCAodtLNZScKh7ji4f)
	dxYLelftX748uUOsrpBTJ30NiRDvZ9 = (DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠩ࠸ࠤࡸ࡫ࡣࠡࠩᙧ") in MsBPlWUgFeOCAodtLNZScKh7ji4f or tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࠤ࠺ࠦࡳࡦࡥࠪᙨ") in MsBPlWUgFeOCAodtLNZScKh7ji4f) and RRbvqditj184m3(u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬᙩ") in MsBPlWUgFeOCAodtLNZScKh7ji4f
	PpmRC54OBzwgQ3tEMUdT = (g8E2PLGXKpYsZnAHjtol in [DWgX6JfF3SnlsQwtN1cvGk8L(u"࠵࠲࠶ឨ")] and uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠬ࡫ࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣ࠵࠵࠸࠰ࠨᙪ") in MsBPlWUgFeOCAodtLNZScKh7ji4f)
	Kzty5GMPcbQRapT4NIrAV = (TeYukOUW7i5NBM926DCjaAn0(u"࠭࡟ࡤࡨࡢࡧ࡭ࡲ࡟ࠨᙫ") in MsBPlWUgFeOCAodtLNZScKh7ji4f and iiauUxMktNW5X(u"ࠧࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࠫᙬ") in MsBPlWUgFeOCAodtLNZScKh7ji4f)
	GOsgi9XcBvRlT81DqZreNtVSa6noj = (tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࡸࡨࡶ࡮࡬ࡹ࠯ࡪࡷࡱࡱࡅࡲࡦࡦ࡬ࡶࡪࡩࡴ࠾ࠩ᙭") in mm7pzl3HMi0R8fGu)
	FoAE5DwOk71Gr03pQUKHc2 = (YZXtBgvUPoM5sb(u"࡚ࠩࡖࡔࡔࡇࡠࡘࡈࡖࡘࡏࡏࡏࡡࡑ࡙ࡒࡈࡅࡓࠩ᙮") in PJnMHzOorxmLAwc or iiLyoNwGbH03DIXhAkZn(u"ࠪࡻࡷࡵ࡮ࡨࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࠪᙯ") in PJnMHzOorxmLAwc)
	if g8E2PLGXKpYsZnAHjtol==OUFxZPuXDoGAbRz(u"࠴࠳࠴ឩ") and any([XxDqV6Qa2JhTiFBIcPWrLypts93,DItaA3JplQm408OW5evz6MLU,dxYLelftX748uUOsrpBTJ30NiRDvZ9,PpmRC54OBzwgQ3tEMUdT,Kzty5GMPcbQRapT4NIrAV,GOsgi9XcBvRlT81DqZreNtVSa6noj,FoAE5DwOk71Gr03pQUKHc2]):
		ffLC6tdJcmlOFn4wY.succeeded = yrcbRSFswvAfEdIWVj
	if ffLC6tdJcmlOFn4wY.succeeded and JWYDAuUfCcmdnajiV7Mysq and vK8Lc3JFp1CMgBqd5aRortk7fE:
		cAtWCV6Y8koO2wL1z7TS0H4QE = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬᙰ")+uWIUplrbFd[NupI74tJCzYXmles9SbR6(u"ࠬࡰ࡯ࡣࠩᙱ")].upper().replace(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭ࡇࡆࡖࠪᙲ"),gby0BnUuTNFk) if GgOPqmJX63cyixzED7rRCZVSA else NTsBLdcbGjH2vla3yV7
		XTWNueqE1H(cAtWCV6Y8koO2wL1z7TS0H4QE)
	if not ffLC6tdJcmlOFn4wY.succeeded and JWYDAuUfCcmdnajiV7Mysq:
		if   XxDqV6Qa2JhTiFBIcPWrLypts93: PJnMHzOorxmLAwc = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧᙳ")
		elif DItaA3JplQm408OW5evz6MLU: PJnMHzOorxmLAwc = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩᙴ")
		elif dxYLelftX748uUOsrpBTJ30NiRDvZ9: PJnMHzOorxmLAwc = NupI74tJCzYXmles9SbR6(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩᙵ")
		elif PpmRC54OBzwgQ3tEMUdT: PJnMHzOorxmLAwc = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶࠤࡩ࡫࡮ࡪࡧࡧࠫᙶ")
		elif Kzty5GMPcbQRapT4NIrAV: PJnMHzOorxmLAwc = iiLyoNwGbH03DIXhAkZn(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭ᙷ")
		elif GOsgi9XcBvRlT81DqZreNtVSa6noj: PJnMHzOorxmLAwc = sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡰ࡭ࡸࡹࡩ࡯ࡩࠣ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠠࡤࡪࡨࡧࡰ࠭ᙸ")
		elif FoAE5DwOk71Gr03pQUKHc2: PJnMHzOorxmLAwc = RRbvqditj184m3(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡽࡴࡻࡲࠡࡰࡨࡸࡼࡵࡲ࡬ࠢࡧࡩࡻ࡯ࡣࡦࡵࠪᙹ")
		else: PJnMHzOorxmLAwc = str(PJnMHzOorxmLAwc)
		uxfIeVwzarRngd7y = oHSEYlfpLzQrC1(Tf5ueYGZIFl1hraoEOVKi,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
		if bTh6JaVi1mOoCEeKZ4kS8AWsnl in rrJsCLhN4SjQUv7OMBTEgeVPl6: pass
		elif bTh6JaVi1mOoCEeKZ4kS8AWsnl in cQtJGSiEvRdY1r04L3VklZfDFP8:
			SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᙺ")+str(g8E2PLGXKpYsZnAHjtol)+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᙻ")+PJnMHzOorxmLAwc+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᙼ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+iiauUxMktNW5X(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᙽ")+uxfIeVwzarRngd7y+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࠥࡣࠧᙾ"))
		else: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᙿ")+str(g8E2PLGXKpYsZnAHjtol)+FAwWlRJg0UkN1(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ ")+PJnMHzOorxmLAwc+RRbvqditj184m3(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᚁ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᚂ")+uxfIeVwzarRngd7y+zDSw8LCxMQyraeXhojIWKmU(u"ࠩࠣࡡࠬᚃ"))
		WMxR8KcuLq62ty = gsDHhlRerNi if QhLKyjVkO20Gdg8Y6NMpxT else pFnO2T7r16k(uxfIeVwzarRngd7y)
		if cAIRPFK6boejVU549WzqBGCaJ0r and isinstance(WMxR8KcuLq62ty,unicode): WMxR8KcuLq62ty = WMxR8KcuLq62ty.encode(JJQFjSIlALchiMzG9)
		if vK8Lc3JFp1CMgBqd5aRortk7fE: WMxR8KcuLq62ty = WMxR8KcuLq62ty.split(i80mE7lHUwVk(u"ࠪ࠳ࠬᚄ"))[-jxCVeKSLb9rGDOl0Qtw6]
		WHYVedO4zKCNhSrxyL6 = str(PJnMHzOorxmLAwc)+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࡡࡴࠨࠨᚅ")+WMxR8KcuLq62ty+iiLyoNwGbH03DIXhAkZn(u"ࠬ࠯ࠧᚆ")
		if any([XxDqV6Qa2JhTiFBIcPWrLypts93,DItaA3JplQm408OW5evz6MLU,dxYLelftX748uUOsrpBTJ30NiRDvZ9,PpmRC54OBzwgQ3tEMUdT,Kzty5GMPcbQRapT4NIrAV,GOsgi9XcBvRlT81DqZreNtVSa6noj,FoAE5DwOk71Gr03pQUKHc2]):
			if JWYDAuUfCcmdnajiV7Mysq:
				s1sOl7vNWHP3rqT6unZ = bTh6JaVi1mOoCEeKZ4kS8AWsnl.split(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"࠭࠭ࠨᚇ"),RRbvqditj184m3(u"࠴ឪ"))[Ducd5PRjQXaB9SIN7VrJ1G(u"࠴ឫ")]
				sAwdJINXi7Vxe4zHFuD8Bonc2MT(s1sOl7vNWHP3rqT6unZ)
			if Iu53qUzjC8cyEV9D1ThbWFBLJP76mn:
				rTKtsRwzXgnWBymUE285Mel = dNx9DVCtafk4r if FoAE5DwOk71Gr03pQUKHc2 else jxCVeKSLb9rGDOl0Qtw6
				ucIWpqewQgsGBC9bNP0JKF = MIFwij6WB4lEfepoGusVtZS75(rTKtsRwzXgnWBymUE285Mel,ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,ttnPORNcv7gM81XFAUJe,IciL6hoO5F1MDSVPjypWZs8kKx,pMjyCGcfHoJ8akULEdDKeXPYzmW0,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl,g8E2PLGXKpYsZnAHjtol,PJnMHzOorxmLAwc)
				ffLC6tdJcmlOFn4wY.__dict__.update(ucIWpqewQgsGBC9bNP0JKF.__dict__)
				if ffLC6tdJcmlOFn4wY.succeeded: return ffLC6tdJcmlOFn4wY
		PpQu9EkGTxa = w8Ui6RsVhSPrqHfO4
		if (VVRYrMqftdmjBAEQoXkcewuI2JTD0==Ducd5PRjQXaB9SIN7VrJ1G(u"ࠧࡂࡕࡎࠫᚈ") or wR71aegTz8IfilEUDKCx2OY==DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨࡃࡖࡏࠬᚉ")) and (SIJiYLXn7KGzP or Iu53qUzjC8cyEV9D1ThbWFBLJP76mn):
			PpQu9EkGTxa = QQD6EVK5kJU1rWSfz(g8E2PLGXKpYsZnAHjtol,WHYVedO4zKCNhSrxyL6,bTh6JaVi1mOoCEeKZ4kS8AWsnl,PPoNs5gLd86)
			if PpQu9EkGTxa and VVRYrMqftdmjBAEQoXkcewuI2JTD0==mmbcsf2pd7gyjzreB(u"ࠩࡄࡗࡐ࠭ᚊ"): VVRYrMqftdmjBAEQoXkcewuI2JTD0 = TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᚋ")
			else: VVRYrMqftdmjBAEQoXkcewuI2JTD0 = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ᚌ")
			if PpQu9EkGTxa and wR71aegTz8IfilEUDKCx2OY==mmbcsf2pd7gyjzreB(u"ࠬࡇࡓࡌࠩᚍ"): wR71aegTz8IfilEUDKCx2OY = sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᚎ")
			else: wR71aegTz8IfilEUDKCx2OY = iiauUxMktNW5X(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᚏ")
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(zDSw8LCxMQyraeXhojIWKmU(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᚐ"),VVRYrMqftdmjBAEQoXkcewuI2JTD0)
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᚑ"),wR71aegTz8IfilEUDKCx2OY)
		if PpQu9EkGTxa:
			if g8E2PLGXKpYsZnAHjtol==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠽ឬ") and oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪ࡬ࡹࡺࡰࡴࠩᚒ") in Tf5ueYGZIFl1hraoEOVKi and TTUogDs9ckwlCjiEXWPSdbY3xJQZ:
				if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(BarIC3eR9bS(u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫᚓ"),n6JjFHfmydIaLut(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᚔ"),RyfYSek61do5OnQMc=ggtuNcvTn3HQ7SpE2(u"࠸࠰࠱࠲ឭ"))
				mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi+kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᚕ")
				VV0LwSPxJKDrgMHkGIpUBf4mAsO9 = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,mm7pzl3HMi0R8fGu,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,PPoNs5gLd86,ne7wF4gSTRZo(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠷ࡴࡤࠨᚖ"))
				if VV0LwSPxJKDrgMHkGIpUBf4mAsO9.succeeded:
					ffLC6tdJcmlOFn4wY = VV0LwSPxJKDrgMHkGIpUBf4mAsO9
					SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᚗ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+n6JjFHfmydIaLut(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᚘ")+uxfIeVwzarRngd7y+DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠪࠤࡢ࠭ᚙ"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(iI7tuF0nEQoR(u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨᚚ"),RRbvqditj184m3(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ᚛"),RyfYSek61do5OnQMc=iiLyoNwGbH03DIXhAkZn(u"࠲࠱࠲࠳ឮ"))
				else:
					SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+OUFxZPuXDoGAbRz(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ᚜")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+OUFxZPuXDoGAbRz(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭᚝")+uxfIeVwzarRngd7y+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨࠢࡠࠫ᚞"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(KJLkQsqSHMR1Np2(u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬ᚟"),KJLkQsqSHMR1Np2(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚠ"),RyfYSek61do5OnQMc=zDSw8LCxMQyraeXhojIWKmU(u"࠳࠲࠳࠴ឯ"))
			if not ffLC6tdJcmlOFn4wY.succeeded and wR71aegTz8IfilEUDKCx2OY in [kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠫࡆ࡛ࡔࡐࠩᚡ"),mmbcsf2pd7gyjzreB(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᚢ")] and Iu53qUzjC8cyEV9D1ThbWFBLJP76mn:
				if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(IXE6voNmrb182AyQ(u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᚣ"),DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᚤ"),RyfYSek61do5OnQMc=nJF7oflOk6cLGSAey(u"࠴࠳࠴࠵ឰ"))
				VV0LwSPxJKDrgMHkGIpUBf4mAsO9 = vUzhT0KMgXLsxB6GJat2pWA(ozVQbncL9s8rw5DHa,Tf5ueYGZIFl1hraoEOVKi,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,PPoNs5gLd86,bTh6JaVi1mOoCEeKZ4kS8AWsnl)
				if VV0LwSPxJKDrgMHkGIpUBf4mAsO9.succeeded:
					ffLC6tdJcmlOFn4wY = VV0LwSPxJKDrgMHkGIpUBf4mAsO9
					SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+OUFxZPuXDoGAbRz(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᚥ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+NupI74tJCzYXmles9SbR6(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᚦ")+uxfIeVwzarRngd7y+mmbcsf2pd7gyjzreB(u"ࠪࠤࡢ࠭ᚧ"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(IXE6voNmrb182AyQ(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪᚨ"),VzO1gCHmjZ2ebRIL(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᚩ"),RyfYSek61do5OnQMc=RRbvqditj184m3(u"࠵࠴࠵࠶ឱ"))
				else:
					SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᚪ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᚫ")+uxfIeVwzarRngd7y+BarIC3eR9bS(u"ࠨࠢࡠࠫᚬ"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(YZXtBgvUPoM5sb(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᚭ"),YZXtBgvUPoM5sb(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚮ"),RyfYSek61do5OnQMc=i80mE7lHUwVk(u"࠶࠵࠶࠰ឲ"))
			if not ffLC6tdJcmlOFn4wY.succeeded and VVRYrMqftdmjBAEQoXkcewuI2JTD0 in [tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠫࡆ࡛ࡔࡐࠩᚯ"),iiLyoNwGbH03DIXhAkZn(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᚰ")] and SIJiYLXn7KGzP:
				if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨᚱ"),TeYukOUW7i5NBM926DCjaAn0(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᚲ"),RyfYSek61do5OnQMc=mmbcsf2pd7gyjzreB(u"࠷࠶࠰࠱ឳ"))
				mm7pzl3HMi0R8fGu = Tf5ueYGZIFl1hraoEOVKi+MlTVLBZ92kzorIq1Yw(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᚳ")
				VV0LwSPxJKDrgMHkGIpUBf4mAsO9 = ttzmG8FdPLBD(ozVQbncL9s8rw5DHa,mm7pzl3HMi0R8fGu,jMlazYZ3qx1H7cQ5eIL6o0AbmWtXk,D6eSPULGzKbwjIV9Ao1lc,c37Wbnk2A8Zx,PPoNs5gLd86,NupI74tJCzYXmles9SbR6(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠴ࡵࡪࠪᚴ"))
				if VV0LwSPxJKDrgMHkGIpUBf4mAsO9.succeeded:
					ffLC6tdJcmlOFn4wY = VV0LwSPxJKDrgMHkGIpUBf4mAsO9
					SSMhXBxZtO7l0nVq9wde2i(lSzTMvWknXwgsyardOVLE9h6uQPt,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪᚵ")+o742nplw96aA+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᚶ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+TeYukOUW7i5NBM926DCjaAn0(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᚷ")+uxfIeVwzarRngd7y+kreQUwJis7YmC2yqWtIF09pgjbD(u"࠭ࠠ࡞ࠩᚸ"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(RRbvqditj184m3(u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨᚹ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᚺ"),RyfYSek61do5OnQMc=MlTVLBZ92kzorIq1Yw(u"࠸࠰࠱࠲឴"))
				else:
					SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+n6JjFHfmydIaLut(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ᚻ")+o742nplw96aA+i80mE7lHUwVk(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᚼ")+bTh6JaVi1mOoCEeKZ4kS8AWsnl+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᚽ")+uxfIeVwzarRngd7y+iiauUxMktNW5X(u"ࠬࠦ࡝ࠨᚾ"))
					if PPoNs5gLd86: RLfOB3nsqaWXTugJvY(zDSw8LCxMQyraeXhojIWKmU(u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᚿ"),OUFxZPuXDoGAbRz(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᛀ"),RyfYSek61do5OnQMc=NupI74tJCzYXmles9SbR6(u"࠲࠱࠲࠳឵"))
		if wR71aegTz8IfilEUDKCx2OY==ne7wF4gSTRZo(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᛁ") or VVRYrMqftdmjBAEQoXkcewuI2JTD0==sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᛂ"): PPoNs5gLd86 = yrcbRSFswvAfEdIWVj
		if not ffLC6tdJcmlOFn4wY.succeeded:
			if PPoNs5gLd86: PNS2WCYDafK6qmjvo7wpsgL4z05t = QQD6EVK5kJU1rWSfz(g8E2PLGXKpYsZnAHjtol,WHYVedO4zKCNhSrxyL6,bTh6JaVi1mOoCEeKZ4kS8AWsnl,PPoNs5gLd86)
			if ffLC6tdJcmlOFn4wY.code!=BarIC3eR9bS(u"࠳࠲࠳ា") and bTh6JaVi1mOoCEeKZ4kS8AWsnl not in ttxcaynV6eCp and IXE6voNmrb182AyQ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧᛃ") not in bTh6JaVi1mOoCEeKZ4kS8AWsnl: cnsQb3Kk7jpPtlm5VSoTz2NIqFih()
	if SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᛄ")) not in [lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠬࡇࡕࡕࡑࠪᛅ"),lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ࡓࡕࡑࡓࠫᛆ"),ne7wF4gSTRZo(u"ࠧࡂࡕࡎࠫᛇ")]: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(KJLkQsqSHMR1Np2(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᛈ"),sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠩࡄࡗࡐ࠭ᛉ"))
	if SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᛊ")) not in [mmbcsf2pd7gyjzreB(u"ࠫࡆ࡛ࡔࡐࠩᛋ"),IXE6voNmrb182AyQ(u"࡙ࠬࡔࡐࡒࠪᛌ"),IXE6voNmrb182AyQ(u"࠭ࡁࡔࡍࠪᛍ")]: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting(ggtuNcvTn3HQ7SpE2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᛎ"),MlTVLBZ92kzorIq1Yw(u"ࠨࡃࡖࡏࠬᛏ"))
	return ffLC6tdJcmlOFn4wY
def lt5BSgkYaHNwixL3IfTMDr(XrZ4CFAnRta5oSET9Vwe02lKGh, bmjsUqw6LGA28BHlW0d):
	PP3MHFWJzNDYjkKQhRyo, bmjsUqw6LGA28BHlW0d = list(XrZ4CFAnRta5oSET9Vwe02lKGh), bmjsUqw6LGA28BHlW0d & 0xFFFFFFFF
	for xuX6UN0WRQbHArDV in range(len(PP3MHFWJzNDYjkKQhRyo)-jxCVeKSLb9rGDOl0Qtw6, xn867tCVlscY4qbWZfh, -jxCVeKSLb9rGDOl0Qtw6):
		bmjsUqw6LGA28BHlW0d = (bmjsUqw6LGA28BHlW0d * OUFxZPuXDoGAbRz(u"࠴࠺࠻࠺࠵࠳࠷ី") + kreQUwJis7YmC2yqWtIF09pgjbD(u"࠳࠳࠵࠸࠿࠰࠵࠴࠵࠷ិ")) & 0xFFFFFFFF
		PP3MHFWJzNDYjkKQhRyo[xuX6UN0WRQbHArDV], PP3MHFWJzNDYjkKQhRyo[bmjsUqw6LGA28BHlW0d % (xuX6UN0WRQbHArDV + jxCVeKSLb9rGDOl0Qtw6)] = PP3MHFWJzNDYjkKQhRyo[bmjsUqw6LGA28BHlW0d % (xuX6UN0WRQbHArDV + jxCVeKSLb9rGDOl0Qtw6)], PP3MHFWJzNDYjkKQhRyo[xuX6UN0WRQbHArDV]
	return n6JjFHfmydIaLut(u"ࠩࠪᛐ").join(PP3MHFWJzNDYjkKQhRyo)
def nkdbmFQ7vC0w32px1(XrZ4CFAnRta5oSET9Vwe02lKGh, VyXBC8wqAYRToMvzj9PN1Wk7scG, g4iIWZXsmP361faMcKerQ):
	g5Lvb9WljRPC = BarIC3eR9bS(u"ࠪࠫᛑ").join(chr(xuX6UN0WRQbHArDV) for xuX6UN0WRQbHArDV in range(TeYukOUW7i5NBM926DCjaAn0(u"࠶࠺࠼ឹ")))
	if not nqkybtoMBH: g5Lvb9WljRPC = g5Lvb9WljRPC.decode(GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫࡱࡧࡴࡪࡰ࠴ࠫᛒ"))
	helSUQMI24GxOs = lt5BSgkYaHNwixL3IfTMDr(g5Lvb9WljRPC, VyXBC8wqAYRToMvzj9PN1Wk7scG)
	zTafYOtigIx2KFbG9q4jov1AePED = lt5BSgkYaHNwixL3IfTMDr(helSUQMI24GxOs, VyXBC8wqAYRToMvzj9PN1Wk7scG)
	T6tkZICaLRleWjY2qQDJf9m5Ey = dict(zip(helSUQMI24GxOs,zTafYOtigIx2KFbG9q4jov1AePED)) if not g4iIWZXsmP361faMcKerQ else dict(zip(zTafYOtigIx2KFbG9q4jov1AePED,helSUQMI24GxOs))
	XrZ4CFAnRta5oSET9Vwe02lKGh = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬ࠭ᛓ").join(T6tkZICaLRleWjY2qQDJf9m5Ey.get(FyTHmCkslS7Y5UvdRLEnGD,FyTHmCkslS7Y5UvdRLEnGD) for FyTHmCkslS7Y5UvdRLEnGD in XrZ4CFAnRta5oSET9Vwe02lKGh)
	return XrZ4CFAnRta5oSET9Vwe02lKGh
def nbiDLAg6WkyZ9UeMImh5oalRdq(XrZ4CFAnRta5oSET9Vwe02lKGh, VyXBC8wqAYRToMvzj9PN1Wk7scG):
	bV0XGurMKTotw26qY1JWeEm9CZdfa, vpNhKR1aAelsdt3, tE3pMHKCQkunIyxclS0DRZ = [], xn867tCVlscY4qbWZfh, xn867tCVlscY4qbWZfh
	e2sO7P4d8Gk = [Ducd5PRjQXaB9SIN7VrJ1G(u"࠶࠶ឺ")-int(P6VbyziFnqGxjNwAEhf7) for P6VbyziFnqGxjNwAEhf7 in str(VyXBC8wqAYRToMvzj9PN1Wk7scG)[::-jxCVeKSLb9rGDOl0Qtw6]]
	SSQBXfVaOEjeAkHpwtC7 = int(q2qPkMFpR1G86dEAKXHivor9N(u"࠭࠹ࠨᛔ")*len(str(VyXBC8wqAYRToMvzj9PN1Wk7scG)))//jJ4LEcdl5w7BPMbQ-VyXBC8wqAYRToMvzj9PN1Wk7scG
	VyXBC8wqAYRToMvzj9PN1Wk7scG, SSQBXfVaOEjeAkHpwtC7 = VyXBC8wqAYRToMvzj9PN1Wk7scG % Ducd5PRjQXaB9SIN7VrJ1G(u"࠸࠵࠷ុ"), SSQBXfVaOEjeAkHpwtC7 % Ducd5PRjQXaB9SIN7VrJ1G(u"࠸࠵࠷ុ")
	while vpNhKR1aAelsdt3 < len(XrZ4CFAnRta5oSET9Vwe02lKGh):
		nGvlQATLWZS4eIR5amhkw1u6g = e2sO7P4d8Gk[tE3pMHKCQkunIyxclS0DRZ%len(e2sO7P4d8Gk)]
		AxiBv1cQueOs0 = XrZ4CFAnRta5oSET9Vwe02lKGh[vpNhKR1aAelsdt3 : vpNhKR1aAelsdt3 + nGvlQATLWZS4eIR5amhkw1u6g]
		bV0XGurMKTotw26qY1JWeEm9CZdfa += [(ord(FyTHmCkslS7Y5UvdRLEnGD)^VyXBC8wqAYRToMvzj9PN1Wk7scG)^SSQBXfVaOEjeAkHpwtC7 for FyTHmCkslS7Y5UvdRLEnGD in AxiBv1cQueOs0][::-jxCVeKSLb9rGDOl0Qtw6]
		vpNhKR1aAelsdt3 += nGvlQATLWZS4eIR5amhkw1u6g
		tE3pMHKCQkunIyxclS0DRZ += jxCVeKSLb9rGDOl0Qtw6
	ssfWU13nzqcOLxYuE8aeg = chr if nqkybtoMBH else unichr
	XrZ4CFAnRta5oSET9Vwe02lKGh = iiauUxMktNW5X(u"ࠧࠨᛕ").join([ssfWU13nzqcOLxYuE8aeg(FyTHmCkslS7Y5UvdRLEnGD) for FyTHmCkslS7Y5UvdRLEnGD in bV0XGurMKTotw26qY1JWeEm9CZdfa])
	return XrZ4CFAnRta5oSET9Vwe02lKGh
def gMxpOG8fEI1i0(XrZ4CFAnRta5oSET9Vwe02lKGh,bmjsUqw6LGA28BHlW0d,eeq5ku4xpL0=xn867tCVlscY4qbWZfh):
	if jxCVeKSLb9rGDOl0Qtw6:
		if isinstance(XrZ4CFAnRta5oSET9Vwe02lKGh, bytes): XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.decode(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࡷࡷࡪ࠽࠭ᛖ"))
		X5IQTqbau1k7lzvAWxi = RyfYSek61do5OnQMc.time()+eeq5ku4xpL0 if eeq5ku4xpL0>xn867tCVlscY4qbWZfh else RyfYSek61do5OnQMc.time()
		XrZ4CFAnRta5oSET9Vwe02lKGh = YZXtBgvUPoM5sb(u"ࡷࠥࡿࢂࢂࡼࡽࡽࢀࠦᛗ").format(int(X5IQTqbau1k7lzvAWxi), XrZ4CFAnRta5oSET9Vwe02lKGh)
		XrZ4CFAnRta5oSET9Vwe02lKGh = nbiDLAg6WkyZ9UeMImh5oalRdq(XrZ4CFAnRta5oSET9Vwe02lKGh, bmjsUqw6LGA28BHlW0d)
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.encode(KJLkQsqSHMR1Np2(u"ࠪࡹࡹ࡬࠸ࠨᛘ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = VjvOwLtso6AIH7ClEWUdmSkPyM5.compress(XrZ4CFAnRta5oSET9Vwe02lKGh)
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.decode(iI7tuF0nEQoR(u"ࠫࡱࡧࡴࡪࡰ࠴ࠫᛙ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = nkdbmFQ7vC0w32px1(XrZ4CFAnRta5oSET9Vwe02lKGh, bmjsUqw6LGA28BHlW0d, ggtuNcvTn3HQ7SpE2(u"ࡆࡢ࡮ࡶࡩូ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.encode(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࡻࡴࡧ࠺ࠪᛚ"))
	return XrZ4CFAnRta5oSET9Vwe02lKGh
def CgLW92DUsmaqtjrGFod6(XrZ4CFAnRta5oSET9Vwe02lKGh,bmjsUqw6LGA28BHlW0d,eeq5ku4xpL0=xn867tCVlscY4qbWZfh):
	PNizo6k4prVR5UYDmMS = YZXtBgvUPoM5sb(u"࠭ࡆࡂࡋࡏࡉࡉ࠭ᛛ")
	if jxCVeKSLb9rGDOl0Qtw6:
		if isinstance(XrZ4CFAnRta5oSET9Vwe02lKGh, bytes): XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.decode(VzO1gCHmjZ2ebRIL(u"ࠧࡶࡶࡩ࠼ࠬᛜ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = nkdbmFQ7vC0w32px1(XrZ4CFAnRta5oSET9Vwe02lKGh, bmjsUqw6LGA28BHlW0d, iiLyoNwGbH03DIXhAkZn(u"ࡕࡴࡸࡩួ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.encode(iiLyoNwGbH03DIXhAkZn(u"ࠨ࡮ࡤࡸ࡮ࡴ࠱ࠨᛝ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = VjvOwLtso6AIH7ClEWUdmSkPyM5.decompress(XrZ4CFAnRta5oSET9Vwe02lKGh)
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.decode(ne7wF4gSTRZo(u"ࠩࡸࡸ࡫࠾ࠧᛞ"))
		XrZ4CFAnRta5oSET9Vwe02lKGh = nbiDLAg6WkyZ9UeMImh5oalRdq(XrZ4CFAnRta5oSET9Vwe02lKGh, bmjsUqw6LGA28BHlW0d)
		X5IQTqbau1k7lzvAWxi, XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.split(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࢀࢁࢂࠧᛟ"), jxCVeKSLb9rGDOl0Qtw6)
		PNizo6k4prVR5UYDmMS = NupI74tJCzYXmles9SbR6(u"ࠫࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧᛠ")
		if eeq5ku4xpL0>xn867tCVlscY4qbWZfh:
			KzJpd8m3IB = RyfYSek61do5OnQMc.time()-int(X5IQTqbau1k7lzvAWxi)
			if abs(KzJpd8m3IB)>eeq5ku4xpL0: PNizo6k4prVR5UYDmMS = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡏࡎࡗࡃࡏࡍࡉࡥࡔࡊࡏࡈࡗ࡙ࡇࡍࡑࠩᛡ")
		XrZ4CFAnRta5oSET9Vwe02lKGh = XrZ4CFAnRta5oSET9Vwe02lKGh.encode(MlTVLBZ92kzorIq1Yw(u"࠭ࡵࡵࡨ࠻ࠫᛢ"))
	return XrZ4CFAnRta5oSET9Vwe02lKGh,PNizo6k4prVR5UYDmMS
def ffj0JO9pQZW5TAncSDgirsm(Yr7gUev0cDTtmua1CHMh5XV3n, key=BarIC3eR9bS(u"ࠧࡉࡧ࡯ࡰࡴࠦࡆ࡭ࡣࡶ࡯ࠥࡔࡥࡸࠢࡘࡲ࡮ࡼࡥࡳࡵࡨࠫᛣ")):
    def _rks8MXE6VmIxcj4WQKo3AwuBH(aZGH4TnOcb8FW): return aZGH4TnOcb8FW if isinstance(aZGH4TnOcb8FW,bytes) else aZGH4TnOcb8FW.encode(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࡷࡷࡪ࠲࠾ࠧᛤ"))
    import hmac as GekP6BuIX70URANSd,base64 as dY1hxU8QXz7vD2Cj5ZtlJg64
    LOCWmtqd0IAbgDQXw=_rks8MXE6VmIxcj4WQKo3AwuBH(key)
    aA0yGgzrdjoENpWKS=_rks8MXE6VmIxcj4WQKo3AwuBH(FoCsyPaNjhWf.dumps(Yr7gUev0cDTtmua1CHMh5XV3n,separators=(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ࠯ࠫᛥ"),ggtuNcvTn3HQ7SpE2(u"ࠪ࠾ࠬᛦ"))))
    uEMLwzNe2qmGF=str(int(RyfYSek61do5OnQMc.time())).encode()
    Jst4bNDka6rHmFhGwqYZ=uEMLwzNe2qmGF+iiLyoNwGbH03DIXhAkZn(u"ࡦࠬ࠴ࠧᛧ")+VjvOwLtso6AIH7ClEWUdmSkPyM5.compress(aA0yGgzrdjoENpWKS)
    saQHKXhJtUSPo6GRcmAYuw=GekP6BuIX70URANSd.new(LOCWmtqd0IAbgDQXw,Jst4bNDka6rHmFhGwqYZ,DwaiOMhZBR8eP4.sha256).digest()
    return dY1hxU8QXz7vD2Cj5ZtlJg64.b64encode(Jst4bNDka6rHmFhGwqYZ)+mmbcsf2pd7gyjzreB(u"ࡧ࠭࠮ࠨᛨ")+dY1hxU8QXz7vD2Cj5ZtlJg64.b64encode(saQHKXhJtUSPo6GRcmAYuw)
from DzAjkuQ7ld import *