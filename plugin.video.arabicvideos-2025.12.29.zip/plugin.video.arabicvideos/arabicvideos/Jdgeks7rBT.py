# -*- coding: utf-8 -*-
import sys as Pt41K3suxDF9nE0wLvU7dGq2ceNT
XxyVRTqZnopE3uaCw7Qksb = Pt41K3suxDF9nE0wLvU7dGq2ceNT.version_info [0] == 2
PVpoIwNHnCRMdistq547 = 2048
Xev3KsLBfS6Dbz4Ix0uawP8W792q = 7
def PPnOMs2AYQHd9p76BxTwDVLJE80 (ggQzxZf5jY):
	global MME0pHOURLxYvyWTgzfqJrcZ3Sl
	VSarHDv21K984tfQGjBUoNRqy6d = ord (ggQzxZf5jY [-1])
	bwjrg482hkUnqSLBMtx31Z = ggQzxZf5jY [:-1]
	D6fkjdtw8K2ysczhE = VSarHDv21K984tfQGjBUoNRqy6d % len (bwjrg482hkUnqSLBMtx31Z)
	g9RMPHTSDtk = bwjrg482hkUnqSLBMtx31Z [:D6fkjdtw8K2ysczhE] + bwjrg482hkUnqSLBMtx31Z [D6fkjdtw8K2ysczhE:]
	if XxyVRTqZnopE3uaCw7Qksb:
		k4kXLBMqPDC = unicode () .join ([unichr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	else:
		k4kXLBMqPDC = str () .join ([chr (ord (ObrvTH2JfX4P35Gd) - PVpoIwNHnCRMdistq547 - (YXQiSMPbeRgnjhF2sKz + VSarHDv21K984tfQGjBUoNRqy6d) % Xev3KsLBfS6Dbz4Ix0uawP8W792q) for YXQiSMPbeRgnjhF2sKz, ObrvTH2JfX4P35Gd in enumerate (g9RMPHTSDtk)])
	return eval (k4kXLBMqPDC)
lQ1MKPXOoAw7FygzvpkNR84Id3bq,q2qPkMFpR1G86dEAKXHivor9N,ne7wF4gSTRZo=PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80,PPnOMs2AYQHd9p76BxTwDVLJE80
uebroqCELQSJIcVPRz16x2Mv0DmB,ggtuNcvTn3HQ7SpE2,sqcK91hDCiHbPG52vfdLFaMy83nA=ne7wF4gSTRZo,q2qPkMFpR1G86dEAKXHivor9N,lQ1MKPXOoAw7FygzvpkNR84Id3bq
iI7tuF0nEQoR,IXE6voNmrb182AyQ,NupI74tJCzYXmles9SbR6=sqcK91hDCiHbPG52vfdLFaMy83nA,ggtuNcvTn3HQ7SpE2,uebroqCELQSJIcVPRz16x2Mv0DmB
DWgX6JfF3SnlsQwtN1cvGk8L,nJF7oflOk6cLGSAey,GHYl6rZXD83JbQsCuMmL907t5FyfK=NupI74tJCzYXmles9SbR6,IXE6voNmrb182AyQ,iI7tuF0nEQoR
FAwWlRJg0UkN1,mmbcsf2pd7gyjzreB,n6JjFHfmydIaLut=GHYl6rZXD83JbQsCuMmL907t5FyfK,nJF7oflOk6cLGSAey,DWgX6JfF3SnlsQwtN1cvGk8L
oI0U2KJvX87ie4ktfRs1nNpEYVdT,zDSw8LCxMQyraeXhojIWKmU,TeYukOUW7i5NBM926DCjaAn0=n6JjFHfmydIaLut,mmbcsf2pd7gyjzreB,FAwWlRJg0UkN1
iiLyoNwGbH03DIXhAkZn,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,kreQUwJis7YmC2yqWtIF09pgjbD=TeYukOUW7i5NBM926DCjaAn0,zDSw8LCxMQyraeXhojIWKmU,oI0U2KJvX87ie4ktfRs1nNpEYVdT
KJLkQsqSHMR1Np2,YZXtBgvUPoM5sb,MlTVLBZ92kzorIq1Yw=kreQUwJis7YmC2yqWtIF09pgjbD,ZSo0TOaxIMCDjR91iX4nJ3qs5yw,iiLyoNwGbH03DIXhAkZn
OUFxZPuXDoGAbRz,BarIC3eR9bS,iiauUxMktNW5X=MlTVLBZ92kzorIq1Yw,YZXtBgvUPoM5sb,KJLkQsqSHMR1Np2
RRbvqditj184m3,Ducd5PRjQXaB9SIN7VrJ1G,VzO1gCHmjZ2ebRIL=iiauUxMktNW5X,BarIC3eR9bS,OUFxZPuXDoGAbRz
tOGIuBnSMVj3XFaCgEqlKwH7oh,tZNGLJza5I9pkvChbg2yoPuXOHDB,i80mE7lHUwVk=VzO1gCHmjZ2ebRIL,Ducd5PRjQXaB9SIN7VrJ1G,RRbvqditj184m3
from V4OX6PRG0U import *
CC3nOPFMovd72u = nJF7oflOk6cLGSAey(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
JB9fyoHr05QOtPjp = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
m56bzZHnc4wxYfSQl = bCoOHfPdMryRgauz0IVpth.path.join(J2J0PpyrD4IMnwadv6YThZeBuqQ5sR,VzO1gCHmjZ2ebRIL(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ds9ECAQLkV8BKaHOYWe3T = bCoOHfPdMryRgauz0IVpth.path.join(J2J0PpyrD4IMnwadv6YThZeBuqQ5sR,uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
LbJdjOWawFXu3PzTmYIr4 = bCoOHfPdMryRgauz0IVpth.path.join(ddvbjM1HF8X,TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),n6JjFHfmydIaLut(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
US14t2jw9zH8XLZm = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X = YZXtBgvUPoM5sb(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
FGgCtUX1mB4 = IXE6voNmrb182AyQ(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
tSGzx8HUrMgJZ = iI7tuF0nEQoR(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
RaEFU7rXhyzovMSpWlN = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
VFntZ32YNwR = YZXtBgvUPoM5sb(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
Bfo9zdZt7b25FnXHLM6pvme = Qbw6RD7GBut
FAL6qhpOwx7ban09GXPJS = jjzt6rqdQKM
h45HKSVWZTsgmjqQONpf2 = B5BloRSAtILFqCTdO
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠹࠷࠴ࣉ"): WjryKiBebavP = Xx68jGH40m5FrL()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠺࠸࠶࣊"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(m56bzZHnc4wxYfSQl,w8Ui6RsVhSPrqHfO4,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==ne7wF4gSTRZo(u"࠻࠹࠸࣋"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(ds9ECAQLkV8BKaHOYWe3T,w8Ui6RsVhSPrqHfO4,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠼࠺࠳࣌"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(LbJdjOWawFXu3PzTmYIr4,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠽࠴࠵࣍"): WjryKiBebavP = NeSGE1RbcM8Xo0hyALg3(w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠷࠵࠷࣎"): WjryKiBebavP = BBFpbOfS4qC3IJnlN(w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iI7tuF0nEQoR(u"࠸࠶࠹࣏"): WjryKiBebavP = mTfYa4eONHPUBFwh0(w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==MlTVLBZ92kzorIq1Yw(u"࠹࠸࠴࣐"): WjryKiBebavP = EwNd7qBXFD8r()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==FAwWlRJg0UkN1(u"࠺࠹࠶࣑"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(US14t2jw9zH8XLZm,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠻࠺࠸࣒"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==TeYukOUW7i5NBM926DCjaAn0(u"࠼࠻࠳࣓"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(FGgCtUX1mB4,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠽࠵࠵ࣔ"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(tSGzx8HUrMgJZ,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==mmbcsf2pd7gyjzreB(u"࠷࠶࠷ࣕ"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(RaEFU7rXhyzovMSpWlN,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠸࠷࠹ࣖ"): WjryKiBebavP = LamxwbXfkZ6JDoCRlgBIehsEc(VFntZ32YNwR,yrcbRSFswvAfEdIWVj,w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠹࠸࠻ࣗ"): WjryKiBebavP = CXzaSfMn2Ypmu53gcd9LjTh4Ier8(w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==OUFxZPuXDoGAbRz(u"࠺࠹࠽ࣘ"): WjryKiBebavP = meRFLJjXOIiMaNSUDd82yACoTZcl();JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==BarIC3eR9bS(u"࠵࠵࠾࠰ࣙ"): WjryKiBebavP = dNXw7icGlB4yfpn2u3MWRZx0()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==i80mE7lHUwVk(u"࠶࠶࠸࠲ࣚ"): WjryKiBebavP = ccwrlRHjWPXC(w8Ui6RsVhSPrqHfO4);JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiLyoNwGbH03DIXhAkZn(u"࠷࠰࠹࠴ࣛ"): WjryKiBebavP = omip47wXYsSkzh1UrgKb();JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==Ducd5PRjQXaB9SIN7VrJ1G(u"࠱࠱࠺࠶ࣜ"): WjryKiBebavP = UhFdtrAI1wLmY4Tn();JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==NupI74tJCzYXmles9SbR6(u"࠲࠲࠻࠸ࣝ"): WjryKiBebavP = KKFbTqXvpV4HZBS53ysRk1UjfGY();JOMtUsr7n1DS3czNHyT(WjryKiBebavP)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==IXE6voNmrb182AyQ(u"࠳࠳࠼࠺ࣞ"): WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==iiauUxMktNW5X(u"࠴࠴࠽࠼ࣟ"): WjryKiBebavP = XpgGWmEJUurAlMdKTNfakO3xb1tVq()
	else: WjryKiBebavP = yrcbRSFswvAfEdIWVj
	return WjryKiBebavP
def XpgGWmEJUurAlMdKTNfakO3xb1tVq():
	XfoEk6pQmbLA = Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠵࠸࠴࣠")*Ducd5PRjQXaB9SIN7VrJ1G(u"࠵࠵࠸࠴࣠")
	YnFZhcd1G2tbom9HCpzTJ8irQwegSW = UcWYT0gz7mALe()//XfoEk6pQmbLA
	EEi4ZWUAdCQeOmkwcMVJyBsFulvShg = YnFZhcd1G2tbom9HCpzTJ8irQwegSW<Ducd5PRjQXaB9SIN7VrJ1G(u"࠺࠶࣡")
	size = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+TeYukOUW7i5NBM926DCjaAn0(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+GGy0cQe765nPYZ9E8Th
	if EEi4ZWUAdCQeOmkwcMVJyBsFulvShg:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,iiLyoNwGbH03DIXhAkZn(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(YnFZhcd1G2tbom9HCpzTJ8irQwegSW)+nJF7oflOk6cLGSAey(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,nJF7oflOk6cLGSAey(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return EEi4ZWUAdCQeOmkwcMVJyBsFulvShg
def JOMtUsr7n1DS3czNHyT(YIt52RTEZ1uoKewhMDBJcOr0z):
	if YIt52RTEZ1uoKewhMDBJcOr0z: nR4jOE8geFDJhKIuisTc2ZPa(w8Ui6RsVhSPrqHfO4)
	return
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp(BarIC3eR9bS(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"࠷࠰࠹࠸࣢"))
	ygWIQGf25qwVxLkXrYDjp(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),NupI74tJCzYXmles9SbR6(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠷࠶࠲ࣣ"))
	ygWIQGf25qwVxLkXrYDjp(FAwWlRJg0UkN1(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),gby0BnUuTNFk,iiauUxMktNW5X(u"࠸࠶࠳ࣤ"))
	ygWIQGf25qwVxLkXrYDjp(DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),gby0BnUuTNFk,ne7wF4gSTRZo(u"࠳࠳࠼࠵ࣥ"))
	return
def dNXw7icGlB4yfpn2u3MWRZx0():
	bO6gB48yvMYKJSdzUa1h2,qtTHIYlrJLF12KndxDjcBoSNPXi5 = LxkC6fsXqdFNYR(Bfo9zdZt7b25FnXHLM6pvme)
	wnH0qr7teWyiuM982hCNOvz,VHiT7ZGQuIrFJBa30pMtP = LxkC6fsXqdFNYR(FAL6qhpOwx7ban09GXPJS)
	fq1SOWI0s2eGni3,Bz4AdMhOJWPF7Iye5igrQjcDpuH9 = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(h45HKSVWZTsgmjqQONpf2)
	VvZFJKmXijadpeg1xtlO2yh3L4uSw,oojQItlVH4G5m2NUPpK3Zu61z = bO6gB48yvMYKJSdzUa1h2+wnH0qr7teWyiuM982hCNOvz+fq1SOWI0s2eGni3,qtTHIYlrJLF12KndxDjcBoSNPXi5+VHiT7ZGQuIrFJBa30pMtP+Bz4AdMhOJWPF7Iye5igrQjcDpuH9
	CHycMebI24Bi6l3WKwP = OUFxZPuXDoGAbRz(u"ࠩࠣࠬࠬࠚ")+FBgfOLCsDRctbKl6mpAv9VP(bO6gB48yvMYKJSdzUa1h2)+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࠤ࠲ࠦࠧࠛ")+str(qtTHIYlrJLF12KndxDjcBoSNPXi5)+q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	FFrmNLTeVf5HnKwgcIXqa = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࠦࠨࠨࠝ")+FBgfOLCsDRctbKl6mpAv9VP(wnH0qr7teWyiuM982hCNOvz)+DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ࠠ࠮ࠢࠪࠞ")+str(VHiT7ZGQuIrFJBa30pMtP)+IXE6voNmrb182AyQ(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	Fl8ShODyiRL = oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠨࠢࠫࠫࠠ")+FBgfOLCsDRctbKl6mpAv9VP(fq1SOWI0s2eGni3)+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(Bz4AdMhOJWPF7Iye5igrQjcDpuH9)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F = mmbcsf2pd7gyjzreB(u"ࠫࠥ࠮ࠧࠣ")+FBgfOLCsDRctbKl6mpAv9VP(VvZFJKmXijadpeg1xtlO2yh3L4uSw)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠬࠦ࠭ࠡࠩࠤ")+str(oojQItlVH4G5m2NUPpK3Zu61z)+KJLkQsqSHMR1Np2(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	ygWIQGf25qwVxLkXrYDjp(IXE6voNmrb182AyQ(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),JB9fyoHr05QOtPjp+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,ne7wF4gSTRZo(u"࠴࠴࠽࠺ࣦ"))
	ygWIQGf25qwVxLkXrYDjp(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+iiauUxMktNW5X(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,KJLkQsqSHMR1Np2(u"࠽࠾࠿࠹ࣧ"))
	ygWIQGf25qwVxLkXrYDjp(MlTVLBZ92kzorIq1Yw(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),JB9fyoHr05QOtPjp+i80mE7lHUwVk(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+CHycMebI24Bi6l3WKwP,gby0BnUuTNFk,NupI74tJCzYXmles9SbR6(u"࠶࠶࠸࠲ࣨ"))
	ygWIQGf25qwVxLkXrYDjp(VzO1gCHmjZ2ebRIL(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),JB9fyoHr05QOtPjp+BarIC3eR9bS(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+FFrmNLTeVf5HnKwgcIXqa,gby0BnUuTNFk,tOGIuBnSMVj3XFaCgEqlKwH7oh(u"࠷࠰࠹࠴ࣩ"))
	ygWIQGf25qwVxLkXrYDjp(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),JB9fyoHr05QOtPjp+ggtuNcvTn3HQ7SpE2(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+Fl8ShODyiRL,gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠱࠱࠺࠶࣪"))
	ygWIQGf25qwVxLkXrYDjp(TeYukOUW7i5NBM926DCjaAn0(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),JB9fyoHr05QOtPjp+q2qPkMFpR1G86dEAKXHivor9N(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠲࠲࠻࠸࣫"))
	return
def KKFbTqXvpV4HZBS53ysRk1UjfGY():
	YIt52RTEZ1uoKewhMDBJcOr0z = yrcbRSFswvAfEdIWVj
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if PpQu9EkGTxa:
		FDdtiH09heufqvEgOnI2S6xPTo = UhFdtrAI1wLmY4Tn()
		WTL2N3mGOURpV1oA4uFSltw = LamxwbXfkZ6JDoCRlgBIehsEc(jjzt6rqdQKM,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
		YIt52RTEZ1uoKewhMDBJcOr0z = FDdtiH09heufqvEgOnI2S6xPTo and WTL2N3mGOURpV1oA4uFSltw
		if YIt52RTEZ1uoKewhMDBJcOr0z: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,zDSw8LCxMQyraeXhojIWKmU(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,iI7tuF0nEQoR(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return YIt52RTEZ1uoKewhMDBJcOr0z
def omip47wXYsSkzh1UrgKb():
	import BktdqIvga8
	BktdqIvga8.KszlZctk8SWyf()
	GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),gby0BnUuTNFk,gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
		GGinQY9gb7uy8VeIrxH5 = LamxwbXfkZ6JDoCRlgBIehsEc(jjzt6rqdQKM,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
		if GGinQY9gb7uy8VeIrxH5: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiLyoNwGbH03DIXhAkZn(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,iiLyoNwGbH03DIXhAkZn(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return GGinQY9gb7uy8VeIrxH5
def UhFdtrAI1wLmY4Tn():
	GGinQY9gb7uy8VeIrxH5 = yrcbRSFswvAfEdIWVj
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(NupI74tJCzYXmles9SbR6(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),gby0BnUuTNFk,gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"ࠧิฦส่ࠬ࠻"),iI7tuF0nEQoR(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
		try:
			bCoOHfPdMryRgauz0IVpth.remove(B5BloRSAtILFqCTdO)
			GGinQY9gb7uy8VeIrxH5 = w8Ui6RsVhSPrqHfO4
		except: pass
		if GGinQY9gb7uy8VeIrxH5: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,MlTVLBZ92kzorIq1Yw(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,q2qPkMFpR1G86dEAKXHivor9N(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return GGinQY9gb7uy8VeIrxH5
def dNXw7icGlB4yfpn2u3MWRZx0():
	bO6gB48yvMYKJSdzUa1h2,qtTHIYlrJLF12KndxDjcBoSNPXi5 = LxkC6fsXqdFNYR(Bfo9zdZt7b25FnXHLM6pvme)
	wnH0qr7teWyiuM982hCNOvz,VHiT7ZGQuIrFJBa30pMtP = LxkC6fsXqdFNYR(FAL6qhpOwx7ban09GXPJS)
	fq1SOWI0s2eGni3,Bz4AdMhOJWPF7Iye5igrQjcDpuH9 = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(h45HKSVWZTsgmjqQONpf2)
	VvZFJKmXijadpeg1xtlO2yh3L4uSw,oojQItlVH4G5m2NUPpK3Zu61z = bO6gB48yvMYKJSdzUa1h2+wnH0qr7teWyiuM982hCNOvz+fq1SOWI0s2eGni3,qtTHIYlrJLF12KndxDjcBoSNPXi5+VHiT7ZGQuIrFJBa30pMtP+Bz4AdMhOJWPF7Iye5igrQjcDpuH9
	CHycMebI24Bi6l3WKwP = BarIC3eR9bS(u"ࠫࠥ࠮ࠧ࠿")+FBgfOLCsDRctbKl6mpAv9VP(bO6gB48yvMYKJSdzUa1h2)+TeYukOUW7i5NBM926DCjaAn0(u"ࠬࠦ࠭ࠡࠩࡀ")+str(qtTHIYlrJLF12KndxDjcBoSNPXi5)+zDSw8LCxMQyraeXhojIWKmU(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	FFrmNLTeVf5HnKwgcIXqa = NupI74tJCzYXmles9SbR6(u"ࠧࠡࠪࠪࡂ")+FBgfOLCsDRctbKl6mpAv9VP(wnH0qr7teWyiuM982hCNOvz)+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨࠢ࠰ࠤࠬࡃ")+str(VHiT7ZGQuIrFJBa30pMtP)+NupI74tJCzYXmles9SbR6(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	Fl8ShODyiRL = iiauUxMktNW5X(u"ࠪࠤ࠭࠭ࡅ")+FBgfOLCsDRctbKl6mpAv9VP(fq1SOWI0s2eGni3)+VzO1gCHmjZ2ebRIL(u"ࠫࠥ࠳ࠠࠨࡆ")+str(Bz4AdMhOJWPF7Iye5igrQjcDpuH9)+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F = BarIC3eR9bS(u"࠭ࠠࠩࠩࡈ")+FBgfOLCsDRctbKl6mpAv9VP(VvZFJKmXijadpeg1xtlO2yh3L4uSw)+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠧࠡ࠯ࠣࠫࡉ")+str(oojQItlVH4G5m2NUPpK3Zu61z)+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	ygWIQGf25qwVxLkXrYDjp(NupI74tJCzYXmles9SbR6(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),JB9fyoHr05QOtPjp+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠳࠳࠼࠹࣬"))
	ygWIQGf25qwVxLkXrYDjp(IXE6voNmrb182AyQ(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+TeYukOUW7i5NBM926DCjaAn0(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"࠼࠽࠾࠿࣭"))
	ygWIQGf25qwVxLkXrYDjp(YZXtBgvUPoM5sb(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),JB9fyoHr05QOtPjp+RRbvqditj184m3(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+CHycMebI24Bi6l3WKwP,gby0BnUuTNFk,VzO1gCHmjZ2ebRIL(u"࠵࠵࠾࠱࣮"))
	ygWIQGf25qwVxLkXrYDjp(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),JB9fyoHr05QOtPjp+q2qPkMFpR1G86dEAKXHivor9N(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+FFrmNLTeVf5HnKwgcIXqa,gby0BnUuTNFk,i80mE7lHUwVk(u"࠶࠶࠸࠳࣯"))
	ygWIQGf25qwVxLkXrYDjp(oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),JB9fyoHr05QOtPjp+sqcK91hDCiHbPG52vfdLFaMy83nA(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+Fl8ShODyiRL,gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠷࠰࠹࠵ࣰ"))
	ygWIQGf25qwVxLkXrYDjp(tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),JB9fyoHr05QOtPjp+sqcK91hDCiHbPG52vfdLFaMy83nA(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,BarIC3eR9bS(u"࠱࠱࠺࠷ࣱ"))
	return
def Xx68jGH40m5FrL():
	bO6gB48yvMYKJSdzUa1h2,qtTHIYlrJLF12KndxDjcBoSNPXi5 = LxkC6fsXqdFNYR(m56bzZHnc4wxYfSQl)
	wnH0qr7teWyiuM982hCNOvz,VHiT7ZGQuIrFJBa30pMtP = LxkC6fsXqdFNYR(ds9ECAQLkV8BKaHOYWe3T)
	fq1SOWI0s2eGni3,Bz4AdMhOJWPF7Iye5igrQjcDpuH9 = LxkC6fsXqdFNYR(LbJdjOWawFXu3PzTmYIr4)
	VvZFJKmXijadpeg1xtlO2yh3L4uSw,oojQItlVH4G5m2NUPpK3Zu61z = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(fANHCcB7ysluYd4Z0iTF1e)
	VvZFJKmXijadpeg1xtlO2yh3L4uSw -= q2qPkMFpR1G86dEAKXHivor9N(u"࠴࠸࠻࠺࠹ࣲ")
	oojQItlVH4G5m2NUPpK3Zu61z -= jxCVeKSLb9rGDOl0Qtw6
	k3Vt7bYx64IXQRDKp1vMqJOUBL8 = str(bCoOHfPdMryRgauz0IVpth.listdir(V8AUXlPnuQ1OZTc5rkRBw))
	rqbT0V4eQiKw9Co17naR5HyBfP8 = k3Vt7bYx64IXQRDKp1vMqJOUBL8.count(mmbcsf2pd7gyjzreB(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+k3Vt7bYx64IXQRDKp1vMqJOUBL8.count(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	CHycMebI24Bi6l3WKwP = n6JjFHfmydIaLut(u"࡙ࠩࠣࠬࠬ")+FBgfOLCsDRctbKl6mpAv9VP(bO6gB48yvMYKJSdzUa1h2)+tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠪࠤ࠲࡚ࠦࠧ")+str(qtTHIYlrJLF12KndxDjcBoSNPXi5)+ggtuNcvTn3HQ7SpE2(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	FFrmNLTeVf5HnKwgcIXqa = ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࠦࠨࠨ࡜")+FBgfOLCsDRctbKl6mpAv9VP(wnH0qr7teWyiuM982hCNOvz)+iiauUxMktNW5X(u"࠭ࠠ࠮ࠢࠪ࡝")+str(VHiT7ZGQuIrFJBa30pMtP)+OUFxZPuXDoGAbRz(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	Fl8ShODyiRL = q2qPkMFpR1G86dEAKXHivor9N(u"ࠨࠢࠫࠫ࡟")+FBgfOLCsDRctbKl6mpAv9VP(fq1SOWI0s2eGni3)+i80mE7lHUwVk(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(Bz4AdMhOJWPF7Iye5igrQjcDpuH9)+BarIC3eR9bS(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F = TeYukOUW7i5NBM926DCjaAn0(u"ࠫࠥ࠮ࠧࡢ")+FBgfOLCsDRctbKl6mpAv9VP(VvZFJKmXijadpeg1xtlO2yh3L4uSw)+nJF7oflOk6cLGSAey(u"ࠬ࠯ࠧࡣ")
	Z8bKjD7U0sGpBEVqC9 = KJLkQsqSHMR1Np2(u"࠭ࠠࠩࠩࡤ")+str(rqbT0V4eQiKw9Co17naR5HyBfP8)+TeYukOUW7i5NBM926DCjaAn0(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	ZThc7IsAKtk3lXCgj4 = bO6gB48yvMYKJSdzUa1h2+wnH0qr7teWyiuM982hCNOvz+fq1SOWI0s2eGni3+VvZFJKmXijadpeg1xtlO2yh3L4uSw
	aGmyTsKY0IECMSN = qtTHIYlrJLF12KndxDjcBoSNPXi5+VHiT7ZGQuIrFJBa30pMtP+Bz4AdMhOJWPF7Iye5igrQjcDpuH9+oojQItlVH4G5m2NUPpK3Zu61z+rqbT0V4eQiKw9Co17naR5HyBfP8
	fbmZ9V58PCTz = iI7tuF0nEQoR(u"ࠨࠢࠫࠫࡦ")+FBgfOLCsDRctbKl6mpAv9VP(ZThc7IsAKtk3lXCgj4)+iI7tuF0nEQoR(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(aGmyTsKY0IECMSN)+iiLyoNwGbH03DIXhAkZn(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	ygWIQGf25qwVxLkXrYDjp(i80mE7lHUwVk(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),JB9fyoHr05QOtPjp+zDSw8LCxMQyraeXhojIWKmU(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+fbmZ9V58PCTz,gby0BnUuTNFk,OUFxZPuXDoGAbRz(u"࠹࠷࠹ࣳ"))
	ygWIQGf25qwVxLkXrYDjp(iiauUxMktNW5X(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+BarIC3eR9bS(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,DWgX6JfF3SnlsQwtN1cvGk8L(u"࠼࠽࠾࠿ࣴ"))
	ygWIQGf25qwVxLkXrYDjp(iiLyoNwGbH03DIXhAkZn(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),JB9fyoHr05QOtPjp+ne7wF4gSTRZo(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+CHycMebI24Bi6l3WKwP,gby0BnUuTNFk,TeYukOUW7i5NBM926DCjaAn0(u"࠻࠹࠷ࣵ"))
	ygWIQGf25qwVxLkXrYDjp(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),JB9fyoHr05QOtPjp+n6JjFHfmydIaLut(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+FFrmNLTeVf5HnKwgcIXqa,gby0BnUuTNFk,tZNGLJza5I9pkvChbg2yoPuXOHDB(u"࠼࠺࠲ࣶ"))
	ygWIQGf25qwVxLkXrYDjp(OUFxZPuXDoGAbRz(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),JB9fyoHr05QOtPjp+DWgX6JfF3SnlsQwtN1cvGk8L(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+Fl8ShODyiRL,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠽࠴࠴ࣷ"))
	ygWIQGf25qwVxLkXrYDjp(tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),JB9fyoHr05QOtPjp+ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,iiLyoNwGbH03DIXhAkZn(u"࠷࠵࠶ࣸ"))
	ygWIQGf25qwVxLkXrYDjp(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),JB9fyoHr05QOtPjp+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+Z8bKjD7U0sGpBEVqC9,gby0BnUuTNFk,mmbcsf2pd7gyjzreB(u"࠸࠶࠹ࣹ"))
	return
def EwNd7qBXFD8r():
	qYjxGgUos8J6ukN = w8Ui6RsVhSPrqHfO4 if ggtuNcvTn3HQ7SpE2(u"ࠫ࠴࠭ࡷ") in ddvbjM1HF8X else yrcbRSFswvAfEdIWVj
	if not qYjxGgUos8J6ukN:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,i80mE7lHUwVk(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	XXnW8EheSJumUP = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting(i80mE7lHUwVk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not XXnW8EheSJumUP: meRFLJjXOIiMaNSUDd82yACoTZcl()
	bO6gB48yvMYKJSdzUa1h2,qtTHIYlrJLF12KndxDjcBoSNPXi5 = LxkC6fsXqdFNYR(US14t2jw9zH8XLZm)
	wnH0qr7teWyiuM982hCNOvz,VHiT7ZGQuIrFJBa30pMtP = LxkC6fsXqdFNYR(x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X)
	fq1SOWI0s2eGni3,Bz4AdMhOJWPF7Iye5igrQjcDpuH9 = LxkC6fsXqdFNYR(FGgCtUX1mB4)
	VvZFJKmXijadpeg1xtlO2yh3L4uSw,oojQItlVH4G5m2NUPpK3Zu61z = LxkC6fsXqdFNYR(tSGzx8HUrMgJZ)
	m9mlMW3ydN0AYw8zrRqxQBTD,rqbT0V4eQiKw9Co17naR5HyBfP8 = LxkC6fsXqdFNYR(RaEFU7rXhyzovMSpWlN)
	W9akCZ6lgTYiLbvSBs5XxIMJc,K12zWOQSuUwx97aGIhYdeon = LxkC6fsXqdFNYR(VFntZ32YNwR)
	CHycMebI24Bi6l3WKwP = YZXtBgvUPoM5sb(u"ࠧࠡࠪࠪࡺ")+FBgfOLCsDRctbKl6mpAv9VP(bO6gB48yvMYKJSdzUa1h2)+FAwWlRJg0UkN1(u"ࠨࠢ࠰ࠤࠬࡻ")+str(qtTHIYlrJLF12KndxDjcBoSNPXi5)+oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	FFrmNLTeVf5HnKwgcIXqa = Ducd5PRjQXaB9SIN7VrJ1G(u"ࠪࠤ࠭࠭ࡽ")+FBgfOLCsDRctbKl6mpAv9VP(wnH0qr7teWyiuM982hCNOvz)+MlTVLBZ92kzorIq1Yw(u"ࠫࠥ࠳ࠠࠨࡾ")+str(VHiT7ZGQuIrFJBa30pMtP)+BarIC3eR9bS(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	Fl8ShODyiRL = BarIC3eR9bS(u"࠭ࠠࠩࠩࢀ")+FBgfOLCsDRctbKl6mpAv9VP(fq1SOWI0s2eGni3)+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠧࠡ࠯ࠣࠫࢁ")+str(Bz4AdMhOJWPF7Iye5igrQjcDpuH9)+MlTVLBZ92kzorIq1Yw(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F = tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠩࠣࠬࠬࢃ")+FBgfOLCsDRctbKl6mpAv9VP(VvZFJKmXijadpeg1xtlO2yh3L4uSw)+tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࠤ࠲ࠦࠧࢄ")+str(oojQItlVH4G5m2NUPpK3Zu61z)+lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	Z8bKjD7U0sGpBEVqC9 = i80mE7lHUwVk(u"ࠬࠦࠨࠨࢆ")+FBgfOLCsDRctbKl6mpAv9VP(m9mlMW3ydN0AYw8zrRqxQBTD)+uebroqCELQSJIcVPRz16x2Mv0DmB(u"࠭ࠠ࠮ࠢࠪࢇ")+str(rqbT0V4eQiKw9Co17naR5HyBfP8)+iiauUxMktNW5X(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	iclN6P2G3IEv5Jra9Hwmkbq0djQ4Ft = RRbvqditj184m3(u"ࠨࠢࠫࠫࢉ")+FBgfOLCsDRctbKl6mpAv9VP(W9akCZ6lgTYiLbvSBs5XxIMJc)+uebroqCELQSJIcVPRz16x2Mv0DmB(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(K12zWOQSuUwx97aGIhYdeon)+NupI74tJCzYXmles9SbR6(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	ZThc7IsAKtk3lXCgj4 = bO6gB48yvMYKJSdzUa1h2+wnH0qr7teWyiuM982hCNOvz+fq1SOWI0s2eGni3+VvZFJKmXijadpeg1xtlO2yh3L4uSw+m9mlMW3ydN0AYw8zrRqxQBTD+W9akCZ6lgTYiLbvSBs5XxIMJc
	aGmyTsKY0IECMSN = qtTHIYlrJLF12KndxDjcBoSNPXi5+VHiT7ZGQuIrFJBa30pMtP+Bz4AdMhOJWPF7Iye5igrQjcDpuH9+oojQItlVH4G5m2NUPpK3Zu61z+rqbT0V4eQiKw9Co17naR5HyBfP8+K12zWOQSuUwx97aGIhYdeon
	fbmZ9V58PCTz = mmbcsf2pd7gyjzreB(u"ࠫࠥ࠮ࠧࢌ")+FBgfOLCsDRctbKl6mpAv9VP(ZThc7IsAKtk3lXCgj4)+KJLkQsqSHMR1Np2(u"ࠬࠦ࠭ࠡࠩࢍ")+str(aGmyTsKY0IECMSN)+BarIC3eR9bS(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	ygWIQGf25qwVxLkXrYDjp(kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),JB9fyoHr05QOtPjp+n6JjFHfmydIaLut(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),gby0BnUuTNFk,iiLyoNwGbH03DIXhAkZn(u"࠹࠸࠼ࣺ"))
	ygWIQGf25qwVxLkXrYDjp(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),JB9fyoHr05QOtPjp+TeYukOUW7i5NBM926DCjaAn0(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+fbmZ9V58PCTz,gby0BnUuTNFk,FAwWlRJg0UkN1(u"࠺࠹࠼ࣻ"))
	ygWIQGf25qwVxLkXrYDjp(BarIC3eR9bS(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+KJLkQsqSHMR1Np2(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,GHYl6rZXD83JbQsCuMmL907t5FyfK(u"࠽࠾࠿࠹ࣼ"))
	ygWIQGf25qwVxLkXrYDjp(KJLkQsqSHMR1Np2(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),JB9fyoHr05QOtPjp+TeYukOUW7i5NBM926DCjaAn0(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+CHycMebI24Bi6l3WKwP,gby0BnUuTNFk,oI0U2KJvX87ie4ktfRs1nNpEYVdT(u"࠼࠻࠱ࣽ"))
	ygWIQGf25qwVxLkXrYDjp(mmbcsf2pd7gyjzreB(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),JB9fyoHr05QOtPjp+Ducd5PRjQXaB9SIN7VrJ1G(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+FFrmNLTeVf5HnKwgcIXqa,gby0BnUuTNFk,BarIC3eR9bS(u"࠽࠵࠳ࣾ"))
	ygWIQGf25qwVxLkXrYDjp(iI7tuF0nEQoR(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),JB9fyoHr05QOtPjp+FAwWlRJg0UkN1(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+Fl8ShODyiRL,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠷࠶࠵ࣿ"))
	ygWIQGf25qwVxLkXrYDjp(NupI74tJCzYXmles9SbR6(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),JB9fyoHr05QOtPjp+mmbcsf2pd7gyjzreB(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+Je2K0Eb91jGDsmh5SkWZnxvUBqPC3F,gby0BnUuTNFk,NupI74tJCzYXmles9SbR6(u"࠸࠷࠷ऀ"))
	ygWIQGf25qwVxLkXrYDjp(nJF7oflOk6cLGSAey(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),JB9fyoHr05QOtPjp+Ducd5PRjQXaB9SIN7VrJ1G(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+Z8bKjD7U0sGpBEVqC9,gby0BnUuTNFk,iI7tuF0nEQoR(u"࠹࠸࠹ँ"))
	ygWIQGf25qwVxLkXrYDjp(Ducd5PRjQXaB9SIN7VrJ1G(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),JB9fyoHr05QOtPjp+mmbcsf2pd7gyjzreB(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+iclN6P2G3IEv5Jra9Hwmkbq0djQ4Ft,gby0BnUuTNFk,Ducd5PRjQXaB9SIN7VrJ1G(u"࠺࠹࠻ं"))
	return
def ccwrlRHjWPXC(showDialogs):
	if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,NupI74tJCzYXmles9SbR6(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	Y4NBvOQqEf8651Znc9k2WRm,AF43YifIh0LRbvrn1w5cdluN2saWy = [],xn867tCVlscY4qbWZfh
	for xdglB7UuAnL83tI0fVzQr,DDJNlYXF1dBCzaEsw95H0x,NNWRtdzxfVgka0oZ6P in bCoOHfPdMryRgauz0IVpth.walk(Qbw6RD7GBut,topdown=yrcbRSFswvAfEdIWVj):
		cuGBAfCUhxNg40msvoV = len(NNWRtdzxfVgka0oZ6P)
		if cuGBAfCUhxNg40msvoV>FAwWlRJg0UkN1(u"࠹࠵࠶ः"): Y4NBvOQqEf8651Znc9k2WRm.append(DDJNlYXF1dBCzaEsw95H0x)
		AF43YifIh0LRbvrn1w5cdluN2saWy += cuGBAfCUhxNg40msvoV
	EDrtjSQCIOl18YGAX5FzumaW = AF43YifIh0LRbvrn1w5cdluN2saWy>iI7tuF0nEQoR(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+TeYukOUW7i5NBM926DCjaAn0(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(AF43YifIh0LRbvrn1w5cdluN2saWy)+ggtuNcvTn3HQ7SpE2(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+GGy0cQe765nPYZ9E8Th
		if not Y4NBvOQqEf8651Znc9k2WRm and not EDrtjSQCIOl18YGAX5FzumaW: PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,iiLyoNwGbH03DIXhAkZn(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MlTVLBZ92kzorIq1Yw(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: PpQu9EkGTxa = jxCVeKSLb9rGDOl0Qtw6
	if PpQu9EkGTxa==jxCVeKSLb9rGDOl0Qtw6:
		if EDrtjSQCIOl18YGAX5FzumaW: LamxwbXfkZ6JDoCRlgBIehsEc(xdglB7UuAnL83tI0fVzQr,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
		elif Y4NBvOQqEf8651Znc9k2WRm:
			for DDJNlYXF1dBCzaEsw95H0x in Y4NBvOQqEf8651Znc9k2WRm: LamxwbXfkZ6JDoCRlgBIehsEc(DDJNlYXF1dBCzaEsw95H0x,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	return
def meRFLJjXOIiMaNSUDd82yACoTZcl():
	YIt52RTEZ1uoKewhMDBJcOr0z = yrcbRSFswvAfEdIWVj
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,BarIC3eR9bS(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if PpQu9EkGTxa==-YZXtBgvUPoM5sb(u"࠷अ"): return
	if PpQu9EkGTxa:
		import subprocess as xo3GWOewzyCq0J
		try:
			xo3GWOewzyCq0J.Popen(lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠪࡷࡺ࠭ࢧ"))
			YIt52RTEZ1uoKewhMDBJcOr0z = w8Ui6RsVhSPrqHfO4
		except: pass
		if YIt52RTEZ1uoKewhMDBJcOr0z:
			q3FJkBi7X4UIWyp1aMEgPut = US14t2jw9zH8XLZm+UpN1CezytPO9XoduhxZSD+x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X+UpN1CezytPO9XoduhxZSD+FGgCtUX1mB4+UpN1CezytPO9XoduhxZSD+tSGzx8HUrMgJZ+UpN1CezytPO9XoduhxZSD+RaEFU7rXhyzovMSpWlN+UpN1CezytPO9XoduhxZSD+VFntZ32YNwR
			HNlzc2Vr8GmvJnxU = xo3GWOewzyCq0J.Popen(zDSw8LCxMQyraeXhojIWKmU(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+q3FJkBi7X4UIWyp1aMEgPut+kreQUwJis7YmC2yqWtIF09pgjbD(u"ࠬࠨࠧࢩ"),shell=w8Ui6RsVhSPrqHfO4,stdin=xo3GWOewzyCq0J.PIPE,stdout=xo3GWOewzyCq0J.PIPE,stderr=xo3GWOewzyCq0J.PIPE)
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,n6JjFHfmydIaLut(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return YIt52RTEZ1uoKewhMDBJcOr0z
def FBgfOLCsDRctbKl6mpAv9VP(ZThc7IsAKtk3lXCgj4):
	for aZGH4TnOcb8FW in [ne7wF4gSTRZo(u"ࠨࡄࠪࢬ"),VzO1gCHmjZ2ebRIL(u"ࠩࡎࡆࠬࢭ"),tOGIuBnSMVj3XFaCgEqlKwH7oh(u"ࠪࡑࡇ࠭ࢮ"),q2qPkMFpR1G86dEAKXHivor9N(u"ࠫࡌࡈࠧࢯ"),zDSw8LCxMQyraeXhojIWKmU(u"࡚ࠬࡂࠨࢰ")]:
		if ZThc7IsAKtk3lXCgj4<iI7tuF0nEQoR(u"࠱࠱࠴࠷आ"): break
		else: ZThc7IsAKtk3lXCgj4 /= ggtuNcvTn3HQ7SpE2(u"࠲࠲࠵࠸࠳࠶इ")
	fbmZ9V58PCTz = lQ1MKPXOoAw7FygzvpkNR84Id3bq(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(ZThc7IsAKtk3lXCgj4,aZGH4TnOcb8FW)
	return fbmZ9V58PCTz
def LxkC6fsXqdFNYR(IGwVp4TNefAPjrOi8QCYJn=iiauUxMktNW5X(u"ࠧ࠯ࠩࢲ")):
	global R6RWS4oJQKcMZ0Y7ngsk92fmxhP,EfiA2VM3SbaxHUhRI6pksK
	R6RWS4oJQKcMZ0Y7ngsk92fmxhP,EfiA2VM3SbaxHUhRI6pksK = xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
	def vzJ24y6kPciVYQELTIAOhUloH(IGwVp4TNefAPjrOi8QCYJn):
		global R6RWS4oJQKcMZ0Y7ngsk92fmxhP,EfiA2VM3SbaxHUhRI6pksK
		if bCoOHfPdMryRgauz0IVpth.path.exists(IGwVp4TNefAPjrOi8QCYJn):
			if xn867tCVlscY4qbWZfh and TeYukOUW7i5NBM926DCjaAn0(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(bCoOHfPdMryRgauz0IVpth):
				for BXdrl7Zs8OImLokg1J in bCoOHfPdMryRgauz0IVpth.scandir(IGwVp4TNefAPjrOi8QCYJn):
					if BXdrl7Zs8OImLokg1J.is_dir(follow_symlinks=yrcbRSFswvAfEdIWVj):
						vzJ24y6kPciVYQELTIAOhUloH(BXdrl7Zs8OImLokg1J.path)
					elif BXdrl7Zs8OImLokg1J.is_file(follow_symlinks=yrcbRSFswvAfEdIWVj):
						R6RWS4oJQKcMZ0Y7ngsk92fmxhP += BXdrl7Zs8OImLokg1J.stat().st_size
						EfiA2VM3SbaxHUhRI6pksK += jxCVeKSLb9rGDOl0Qtw6
			else:
				for BXdrl7Zs8OImLokg1J in bCoOHfPdMryRgauz0IVpth.listdir(IGwVp4TNefAPjrOi8QCYJn):
					jWgYyKu57Gr9ARzLMs = bCoOHfPdMryRgauz0IVpth.path.abspath(bCoOHfPdMryRgauz0IVpth.path.join(IGwVp4TNefAPjrOi8QCYJn,BXdrl7Zs8OImLokg1J))
					if bCoOHfPdMryRgauz0IVpth.path.isdir(jWgYyKu57Gr9ARzLMs):
						vzJ24y6kPciVYQELTIAOhUloH(jWgYyKu57Gr9ARzLMs)
					elif bCoOHfPdMryRgauz0IVpth.path.isfile(jWgYyKu57Gr9ARzLMs):
						ZThc7IsAKtk3lXCgj4,aGmyTsKY0IECMSN = Fjh7CdYBJgl2VuSkPXR9Avc6Gw41UM(jWgYyKu57Gr9ARzLMs)
						R6RWS4oJQKcMZ0Y7ngsk92fmxhP += ZThc7IsAKtk3lXCgj4
						EfiA2VM3SbaxHUhRI6pksK += aGmyTsKY0IECMSN
		return
	try: vzJ24y6kPciVYQELTIAOhUloH(IGwVp4TNefAPjrOi8QCYJn)
	except: pass
	return R6RWS4oJQKcMZ0Y7ngsk92fmxhP,EfiA2VM3SbaxHUhRI6pksK
def BBFpbOfS4qC3IJnlN(showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+BarIC3eR9bS(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+okfdjS4RmM+sqcK91hDCiHbPG52vfdLFaMy83nA(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+okfdjS4RmM+GHYl6rZXD83JbQsCuMmL907t5FyfK(u"ࠫฤࠧࠡࠨࢶ")+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return
	AdphLnQVWrPZ8EtKvwkqRYl = LamxwbXfkZ6JDoCRlgBIehsEc(m56bzZHnc4wxYfSQl,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
	MKF6qGh5uj = LamxwbXfkZ6JDoCRlgBIehsEc(ds9ECAQLkV8BKaHOYWe3T,w8Ui6RsVhSPrqHfO4,yrcbRSFswvAfEdIWVj)
	yPG4czXkLDNKh1mV0oAJYgfqWQueI = LamxwbXfkZ6JDoCRlgBIehsEc(LbJdjOWawFXu3PzTmYIr4,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	IJzeKubAUH0ERLT9hSc = NeSGE1RbcM8Xo0hyALg3(yrcbRSFswvAfEdIWVj)
	PlfS8uoX1QvtRjxZaygGCcV = mTfYa4eONHPUBFwh0(yrcbRSFswvAfEdIWVj)
	succeeded = all([AdphLnQVWrPZ8EtKvwkqRYl,MKF6qGh5uj,yPG4czXkLDNKh1mV0oAJYgfqWQueI,IJzeKubAUH0ERLT9hSc,PlfS8uoX1QvtRjxZaygGCcV])
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,KJLkQsqSHMR1Np2(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,BarIC3eR9bS(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def CXzaSfMn2Ypmu53gcd9LjTh4Ier8(showDialogs):
	if showDialogs:
		q3FJkBi7X4UIWyp1aMEgPut = US14t2jw9zH8XLZm+okfdjS4RmM+x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X+okfdjS4RmM+FGgCtUX1mB4+okfdjS4RmM+tSGzx8HUrMgJZ+okfdjS4RmM+RaEFU7rXhyzovMSpWlN+okfdjS4RmM+VFntZ32YNwR
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+iiLyoNwGbH03DIXhAkZn(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+q3FJkBi7X4UIWyp1aMEgPut+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return
	AdphLnQVWrPZ8EtKvwkqRYl = LamxwbXfkZ6JDoCRlgBIehsEc(US14t2jw9zH8XLZm,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	MKF6qGh5uj = LamxwbXfkZ6JDoCRlgBIehsEc(x5MSZgCU7Hdclf6RFsn0b4P8VyJL3X,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	yPG4czXkLDNKh1mV0oAJYgfqWQueI = LamxwbXfkZ6JDoCRlgBIehsEc(FGgCtUX1mB4,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	IJzeKubAUH0ERLT9hSc = LamxwbXfkZ6JDoCRlgBIehsEc(tSGzx8HUrMgJZ,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	PlfS8uoX1QvtRjxZaygGCcV = LamxwbXfkZ6JDoCRlgBIehsEc(RaEFU7rXhyzovMSpWlN,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	uy2QUXxpDs3Lk5mV4eodAtJMPi = LamxwbXfkZ6JDoCRlgBIehsEc(VFntZ32YNwR,yrcbRSFswvAfEdIWVj,yrcbRSFswvAfEdIWVj)
	succeeded = all([AdphLnQVWrPZ8EtKvwkqRYl,MKF6qGh5uj,yPG4czXkLDNKh1mV0oAJYgfqWQueI,IJzeKubAUH0ERLT9hSc,PlfS8uoX1QvtRjxZaygGCcV,uy2QUXxpDs3Lk5mV4eodAtJMPi])
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MlTVLBZ92kzorIq1Yw(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def NeSGE1RbcM8Xo0hyALg3(showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+BarIC3eR9bS(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=iiLyoNwGbH03DIXhAkZn(u"࠳ई"): return tZNGLJza5I9pkvChbg2yoPuXOHDB(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = kreQUwJis7YmC2yqWtIF09pgjbD(u"ࡘࡷࡻࡥऊ")
		DEOf7aYR4rZXubkAHBUMzhlmCgK = H6JBPsvmfLRhZI4YzUnebWdXKV8ig.connect(fANHCcB7ysluYd4Z0iTF1e)
		DEOf7aYR4rZXubkAHBUMzhlmCgK.text_factory = str
		MnOPIpuYDZFJ = DEOf7aYR4rZXubkAHBUMzhlmCgK.cursor()
		MnOPIpuYDZFJ.execute(ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		MnOPIpuYDZFJ.execute(q2qPkMFpR1G86dEAKXHivor9N(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		MnOPIpuYDZFJ.execute(ne7wF4gSTRZo(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		DEOf7aYR4rZXubkAHBUMzhlmCgK.commit()
		MnOPIpuYDZFJ.execute(KJLkQsqSHMR1Np2(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		DEOf7aYR4rZXubkAHBUMzhlmCgK.close()
	except: succeeded = iiauUxMktNW5X(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,RRbvqditj184m3(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,ne7wF4gSTRZo(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def mTfYa4eONHPUBFwh0(showDialogs):
	if showDialogs:
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,OUFxZPuXDoGAbRz(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+okfdjS4RmM+okfdjS4RmM+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+zDSw8LCxMQyraeXhojIWKmU(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+GGy0cQe765nPYZ9E8Th)
		if PpQu9EkGTxa!=jxCVeKSLb9rGDOl0Qtw6: return KJLkQsqSHMR1Np2(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = ggtuNcvTn3HQ7SpE2(u"ࡔࡳࡷࡨऍ")
	for file in bCoOHfPdMryRgauz0IVpth.listdir(V8AUXlPnuQ1OZTc5rkRBw):
		if ZSo0TOaxIMCDjR91iX4nJ3qs5yw(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and KJLkQsqSHMR1Np2(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		DlBXgmHAu0T9ydiajxqZnG64PS = bCoOHfPdMryRgauz0IVpth.path.join(V8AUXlPnuQ1OZTc5rkRBw,file)
		try: bCoOHfPdMryRgauz0IVpth.remove(DlBXgmHAu0T9ydiajxqZnG64PS)
		except Exception as QdjB4N09zlKLRJ52gHvPZo7nqtCrb:
			succeeded = OUFxZPuXDoGAbRz(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,str(QdjB4N09zlKLRJ52gHvPZo7nqtCrb))
	if showDialogs:
		if succeeded: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,IXE6voNmrb182AyQ(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,DWgX6JfF3SnlsQwtN1cvGk8L(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded