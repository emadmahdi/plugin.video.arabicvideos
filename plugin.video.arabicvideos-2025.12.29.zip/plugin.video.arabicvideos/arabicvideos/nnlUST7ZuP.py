# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'EGYNOW'
JB9fyoHr05QOtPjp = '_EGN_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==430: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==431: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==432: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==433: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==434: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==437: WjryKiBebavP = FRLd7wnhea92QVuy(url)
	elif mode==439: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc+'/films',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"canonical" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd[0].strip('/')
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,'url')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,439,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,435)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,434)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المضاف حديثا',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,431)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'افلام اون لاين',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/films1',436)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات اون لاين',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/series-all1',436)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'قائمة تفصيلية',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,437)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SiteNavigation"(.*?)"Search"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,431)
	return
def FRLd7wnhea92QVuy(website=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',website+'/films',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"canonical" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd[0].strip('/')
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,'url')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"ListDroped"(.*?)"SearchingMaster"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for zTFlfH8DhAVryqUjX,value,title in items:
		if title in d2gCoAnYPG89O: continue
		SSqweDUBYv4bkO = website+'/explore/?'+zTFlfH8DhAVryqUjX+'='+value
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,431)
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-SUBMENU-1st')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',url,431)
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"titleSectionCon"(.*?)</div></div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-key="(.*?)".*?<em>(.*?)</em>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for xxGw3Q5hHDkP8WfVe7m,title in items:
		if title in d2gCoAnYPG89O: continue
		Tf5ueYGZIFl1hraoEOVKi = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+xxGw3Q5hHDkP8WfVe7m
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,Tf5ueYGZIFl1hraoEOVKi,431)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd = avXHrARzQuBW4s(url)
		IciL6hoO5F1MDSVPjypWZs8kKx = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-TITLES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
	elif Z05rTiu6LwakteK8VfY=='featured':
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"MainSlider"(.*?)"MatchesTable"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-TITLES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"BlocksList"(.*?)"Paginate"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"BlocksList"(.*?)"titleSectionCon"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		title = Y7BxKQdU84R(title)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,432,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,433,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movseries/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,431,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,433,T6TRUSbecYGWIq29KF)
	if Z05rTiu6LwakteK8VfY!='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Paginate"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
				SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
				title = Y7BxKQdU84R(title)
				if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,431)
		fhW8oRx6TUJiuFK5GXQH9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('showmore" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if fhW8oRx6TUJiuFK5GXQH9:
			SSqweDUBYv4bkO = fhW8oRx6TUJiuFK5GXQH9[0]
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مشاهدة المزيد',SSqweDUBYv4bkO,431)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	l2Np9PfFqv4RcW7Y,qsQxHTa4e0JYLUSKF7 = [],[]
	if 'Episodes.php' in url:
		Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd = avXHrARzQuBW4s(url)
		IciL6hoO5F1MDSVPjypWZs8kKx = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,uWIUplrbFd,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-EPISODES-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		qsQxHTa4e0JYLUSKF7 = [jS6fQGXeouTB7xKd32ZMy]
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-EPISODES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsList"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"EpisodesList"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y:
		T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"og:image" content="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for y6yAgrGq2LNQYBUzsZcCW0xfPO,foL6mCMSDlOIa9VEhuJ1ANTwt,title in items:
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+foL6mCMSDlOIa9VEhuJ1ANTwt+'&post_id='+y6yAgrGq2LNQYBUzsZcCW0xfPO
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,433,T6TRUSbecYGWIq29KF)
	elif qsQxHTa4e0JYLUSKF7:
		T6TRUSbecYGWIq29KF = oKew16fsvuV8.getInfoLabel('ListItem.Thumb')
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,Cso7iV0ZOw2UW5Ez in items:
			title = title+UpN1CezytPO9XoduhxZSD+Cso7iV0ZOw2UW5Ez
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,432,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	Tf5ueYGZIFl1hraoEOVKi = url+'/watch/'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Tf5ueYGZIFl1hraoEOVKi,'url')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container-servers"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		m84exy3GSjnMc9RdJC = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-id="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if m84exy3GSjnMc9RdJC:
			m84exy3GSjnMc9RdJC = m84exy3GSjnMc9RdJC[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-server="(.*?)".*?<span>(.*?)</span>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for TfYmiUDcZOCgQ86rENjVG1zaqXbWk,title in items:
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'&post_id='+m84exy3GSjnMc9RdJC+'?named='+title+'__watch'
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	SVNqroJ4Rfn = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container-iframe"><iframe src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SVNqroJ4Rfn:
		SVNqroJ4Rfn = SVNqroJ4Rfn[0].replace(okfdjS4RmM,gby0BnUuTNFk)
		title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SVNqroJ4Rfn,'name')
		SSqweDUBYv4bkO = SVNqroJ4Rfn+'?named='+title+'__embed'
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"container-download"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,DYNVS1Bbgs7 in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace(okfdjS4RmM,gby0BnUuTNFk)
			if DYNVS1Bbgs7!=gby0BnUuTNFk: DYNVS1Bbgs7 = '____'+DYNVS1Bbgs7
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'+DYNVS1Bbgs7
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url)
	return
def G2dUpHgXKM1Nzu4w9(url):
	url = url.split('/smartemadfilter?')[0]
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('("dropdown-button".*?)"SearchingMaster"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return tpQ9UZ8rIuhvW3box21X6iqsz
def Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0):
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-term="(\d+)" data-name="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return items
def XI6uxNML5haHVWrm0p8U(url):
	c7oIqRywsVUpZ8rdTu6LNm20Y = url.split('/smartemadfilter?')[0]
	q53fXShJmaD0iWrz7KbnlAFBoR = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace(c7oIqRywsVUpZ8rdTu6LNm20Y,q53fXShJmaD0iWrz7KbnlAFBoR)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def smglfMvJ4a9piKR3(vyD9F1UMQe,url):
	zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'modified_filters')
	mm7pzl3HMi0R8fGu = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	mm7pzl3HMi0R8fGu = XI6uxNML5haHVWrm0p8U(mm7pzl3HMi0R8fGu)
	return mm7pzl3HMi0R8fGu
FFCXkHm5TYPUbBp = ['category','country','genre','release-year']
ZfNKXALGqzaCsM68gw0d7lD = ['quality','release-year','genre','category','language','country']
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if FFCXkHm5TYPUbBp[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[0]
		for xuX6UN0WRQbHArDV in range(len(FFCXkHm5TYPUbBp[0:-1])):
			if FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='ALL_ITEMS_FILTER':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+QfoFHUnpEi4W2OuT8DBg3
		Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها ',Tf5ueYGZIFl1hraoEOVKi,431)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',Tf5ueYGZIFl1hraoEOVKi,431)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	tpQ9UZ8rIuhvW3box21X6iqsz = G2dUpHgXKM1Nzu4w9(url)
	dict = {}
	for name,AxiBv1cQueOs0,CCRe1gOK8Dtca0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		name = name.replace('--',gby0BnUuTNFk)
		items = Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='SPECIFIED_FILTER':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<2:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]:
					url = XI6uxNML5haHVWrm0p8U(url)
					Xw3tTz8UD4LK26C(url)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'SPECIFIED_FILTER___'+J21ulLnwtByA4XvcC)
				return
			else:
				Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع ',Tf5ueYGZIFl1hraoEOVKi,431)
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع ',Tf5ueYGZIFl1hraoEOVKi,435,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='ALL_ITEMS_FILTER':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع :'+name,Tf5ueYGZIFl1hraoEOVKi,434,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if value=='196533': w7su60daQz13VIplrfxJk = 'أفلام نيتفلكس'
			elif value=='196531': w7su60daQz13VIplrfxJk = 'مسلسلات نيتفلكس'
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' :'#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' :'+name
			if type=='ALL_ITEMS_FILTER': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,434,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='SPECIFIED_FILTER' and FFCXkHm5TYPUbBp[-2]+'=' in mW9DK3tVFwd:
				mm7pzl3HMi0R8fGu = smglfMvJ4a9piKR3(vyD9F1UMQe,url)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,431)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,435,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.replace('=&','=0&')
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	for key in ZfNKXALGqzaCsM68gw0d7lD:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if '%' not in value: value = IcChbXakUDFLszgpSG2jqem9(value)
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all_filters': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	d28pn3tAz4V = d28pn3tAz4V.replace('=0','=')
	return d28pn3tAz4V