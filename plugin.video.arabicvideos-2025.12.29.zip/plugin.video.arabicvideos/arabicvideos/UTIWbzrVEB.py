# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
headers = { 'User-Agent' : gby0BnUuTNFk }
CC3nOPFMovd72u = 'AKOAMCAM'
JB9fyoHr05QOtPjp = '_AKC_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['مصارعة']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==350: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==351: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==352: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==353: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==354: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'FILTERS___'+text)
	elif mode==355: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'CATEGORIES___'+text)
	elif mode==356: WjryKiBebavP = hh5HSUm6L7gBs4KIzEGRVZu(url)
	elif mode==357: WjryKiBebavP = y8yIxWS9DZKPtEMrfpc1RmnkbN4o(url)
	elif mode==359: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+bKN9diGf8nmgecQPEqUzHRpoDuaO+'هذا الموقع مغلق'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,8)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,359,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',LhFnEIuPHdoNc,356)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',LhFnEIuPHdoNc,357)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKOAMCAM-MENU-1st')
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('recently-container.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]
	else: Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'اضيف حديثا',Tf5ueYGZIFl1hraoEOVKi,351)
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('@id":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]
	else: Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المميزة',Tf5ueYGZIFl1hraoEOVKi,351,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('main-categories-list(.*?)main-categories-list',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?class="font.*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,351)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="categories-box(.*?)<footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
			if title not in d2gCoAnYPG89O: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,351)
	return jS6fQGXeouTB7xKd32ZMy
def hh5HSUm6L7gBs4KIzEGRVZu(website=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKOAMCAM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu(.*?)<nav',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?text">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O:
				title = title+' مصنفة'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,355)
		if website==gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	return jS6fQGXeouTB7xKd32ZMy
def y8yIxWS9DZKPtEMrfpc1RmnkbN4o(website=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKOAMCAM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu(.*?)<nav',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?text">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O:
				title = title+' مفلترة'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,354)
		if website==gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(rraWHLSwQvPlVROcM5YAJfF7ojh,url,gby0BnUuTNFk,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('swiper-container(.*?)swiper-button-prev',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="container"(.*?)main-footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		NGcX5a4OifEhZKrY7C0QVyjRA = []
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|الحلقه) \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if Cso7iV0ZOw2UW5Ez:
					title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
					if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
						ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,352,T6TRUSbecYGWIq29KF)
						NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			elif 'مسلسل' in title:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,352,T6TRUSbecYGWIq29KF)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,353,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href=["\'](.*?)["\'].*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,351)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + '/?s='+apTFWBhb175nwjvKtmJ2
	WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'AKOAMCAM-EPISODES-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('text-white">الحلقات(.*?)<header',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		JsAt0zywiZXQM3YKvnG6ClDq7N8L = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in JsAt0zywiZXQM3YKvnG6ClDq7N8L:
			if 'الحلقة' in title or 'الحلقه' in title: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,353,T6TRUSbecYGWIq29KF)
	else:
		T6TRUSbecYGWIq29KF = oKew16fsvuV8.getInfoLabel('ListItem.Icon')
		if jS6fQGXeouTB7xKd32ZMy.count('<title>')>1: title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<title>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[1]
		else: title = 'رابط التشغيل'
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,url,353,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R,uufJivSZQyj45ql3 = [],[]
	a0awyeEzOMDZv = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'AKOAMCAM-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = a0awyeEzOMDZv.content
	rtdPCiNqKeO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('post_id=(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if rtdPCiNqKeO:
		rtdPCiNqKeO = rtdPCiNqKeO[0]
		headers = {'User-Agent':gby0BnUuTNFk,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':rtdPCiNqKeO}
		Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		QOl8o2rqjV = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'POST',Tf5ueYGZIFl1hraoEOVKi,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'AKOAMCAM-PLAY-1st')
		N84Yo7V9qS = QOl8o2rqjV.content
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-server="(.*?)".*?class="text">(.*?)<',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for n1vgldiHDYL8zhS,name in items:
			SSqweDUBYv4bkO = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?postid='+rtdPCiNqKeO+'&serverid='+n1vgldiHDYL8zhS+'?named='+name+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
			uufJivSZQyj45ql3.append(name)
		Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		QOl8o2rqjV = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'POST',Tf5ueYGZIFl1hraoEOVKi,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'AKOAMCAM-PLAY-1st')
		N84Yo7V9qS = QOl8o2rqjV.content
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?class="text">(.*?)<',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
			uufJivSZQyj45ql3.append(title)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	FFCXkHm5TYPUbBp = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='CATEGORIES':
		if FFCXkHm5TYPUbBp[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[0]
		for xuX6UN0WRQbHArDV in range(len(FFCXkHm5TYPUbBp[0:-1])):
			if FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'all')
		Tf5ueYGZIFl1hraoEOVKi = url+'?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='FILTERS':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'all')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'?'+QfoFHUnpEi4W2OuT8DBg3
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها',Tf5ueYGZIFl1hraoEOVKi,351,gby0BnUuTNFk,'1')
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',Tf5ueYGZIFl1hraoEOVKi,351,gby0BnUuTNFk,'1')
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<form id(.*?)</form>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	dict = {}
	for CCRe1gOK8Dtca0,name,AxiBv1cQueOs0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<option(.*?)>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='CATEGORIES':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<=1:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: Xw3tTz8UD4LK26C(Tf5ueYGZIFl1hraoEOVKi)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'CATEGORIES___'+J21ulLnwtByA4XvcC)
				return
			else:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,351,gby0BnUuTNFk,'1')
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,355,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='FILTERS':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع : '+name,Tf5ueYGZIFl1hraoEOVKi,354,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			if 'value' not in value: value = w7su60daQz13VIplrfxJk
			else: value = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(.*?)"',value,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' : '#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' : '+name
			if type=='FILTERS': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,354,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='CATEGORIES' and FFCXkHm5TYPUbBp[-2]+'=' in mW9DK3tVFwd:
				zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'all')
				mm7pzl3HMi0R8fGu = url+'?'+zfRG7q8BlLZ9cATPNk6Od
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,351,gby0BnUuTNFk,'1')
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,355,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	ZfNKXALGqzaCsM68gw0d7lD = ['cat','genre','release-year','quality','orderby']
	for key in ZfNKXALGqzaCsM68gw0d7lD:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	return d28pn3tAz4V