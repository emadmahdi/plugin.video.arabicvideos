# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMACLUP'
JB9fyoHr05QOtPjp = '_CMC_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['موقع نتفليكس']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==490: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==491: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==492: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==493: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==494: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==499: WjryKiBebavP = a3NI0EopMZw(text,url)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd[0].strip('/')
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,'url')
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"filter AjaxifyFilter"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-filter="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/wp-content/themes/old/filter/'+SSqweDUBYv4bkO+'.php'
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,491)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أفلام',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/category/مسلسلات/مسلسلات-اجنبى',494,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="navigation-menu"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if SSqweDUBYv4bkO=='/': continue
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
		if title in d2gCoAnYPG89O: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,491)
	return jS6fQGXeouTB7xKd32ZMy
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"filter"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,491)
	return
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk):
	items = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	AxiBv1cQueOs0 = gby0BnUuTNFk
	if '.php' in url: AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
	elif '?s=' in url:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"blocks(.*?)"manifest"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Blocks(.*?)"manifest"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not AxiBv1cQueOs0: return
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		title = Y7BxKQdU84R(title)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) حلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not Cso7iV0ZOw2UW5Ez: Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not Cso7iV0ZOw2UW5Ez or any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,492,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'حلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,493,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,493,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li><a href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			title = title.replace('الصفحة ',gby0BnUuTNFk)
			if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,491)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"ButtonsBarCo".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Tf5ueYGZIFl1hraoEOVKi:
		Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-EPISODES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"img-responsive" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if T6TRUSbecYGWIq29KF: T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
	else: T6TRUSbecYGWIq29KF = oKew16fsvuV8.getInfoLabel('ListItem.Thumb')
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"filter"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Blocks(.*?)class="pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y and '/series/' not in url:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,493,T6TRUSbecYGWIq29KF)
	elif qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,492,T6TRUSbecYGWIq29KF)
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = Y7BxKQdU84R(title)
				title = title.replace('الصفحة ',gby0BnUuTNFk)
				if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,491)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	Tf5ueYGZIFl1hraoEOVKi = url.strip('/')+'/?view=1'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMACLUP-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	m84exy3GSjnMc9RdJC = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("data: 'q=(.*?)&",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	m84exy3GSjnMc9RdJC = m84exy3GSjnMc9RdJC[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"serversList"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-server="(.*?)">(.*?)</li>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for KXauH7EwCn2Y6IsdUGrOMZvgqBzT,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/wp-content/themes/old/servers/server.php?q='+m84exy3GSjnMc9RdJC+'&i='+KXauH7EwCn2Y6IsdUGrOMZvgqBzT+'?named='+title+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embedServer".*?SRC="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		title = 'مفضل'
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]+'?named=__embed__'+title
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"downloadsList"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<td>(.*?)</td>.*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,SSqweDUBYv4bkO in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if 'anavidz' in SSqweDUBYv4bkO: T3Yrx4yZCRqcH = '__خاص'
			else: T3Yrx4yZCRqcH = gby0BnUuTNFk
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'+T3Yrx4yZCRqcH
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search,Hr3FCpiuRKaB0NSQ1M47sfygXvoxd=gby0BnUuTNFk):
	if not Hr3FCpiuRKaB0NSQ1M47sfygXvoxd: Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = LhFnEIuPHdoNc
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/index.php?s='+search
	Xw3tTz8UD4LK26C(url)
	return