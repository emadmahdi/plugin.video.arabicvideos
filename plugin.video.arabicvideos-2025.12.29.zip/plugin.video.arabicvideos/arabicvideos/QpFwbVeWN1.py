# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'FAJERSHOW'
JB9fyoHr05QOtPjp = '_FJS_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==390: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==391: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==392: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==393: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==399: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,399,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FAJERSHOW-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<header>.*?<h2>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for KQydxfMmoJERw in range(len(items)):
		title = items[KQydxfMmoJERw]
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,LhFnEIuPHdoNc,391,gby0BnUuTNFk,gby0BnUuTNFk,'latest'+str(KQydxfMmoJERw))
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مختارات عشوائية',LhFnEIuPHdoNc,391,gby0BnUuTNFk,gby0BnUuTNFk,'randoms')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أعلى الأفلام تقييماً',LhFnEIuPHdoNc,391,gby0BnUuTNFk,gby0BnUuTNFk,'top_imdb_movies')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أعلى المسلسلات تقييماً',LhFnEIuPHdoNc,391,gby0BnUuTNFk,gby0BnUuTNFk,'top_imdb_series')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أفلام مميزة',LhFnEIuPHdoNc+'/movies',391,gby0BnUuTNFk,gby0BnUuTNFk,'featured_movies')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات مميزة',LhFnEIuPHdoNc+'/tvshows',391,gby0BnUuTNFk,gby0BnUuTNFk,'featured_tvshows')
	AxiBv1cQueOs0 = gby0BnUuTNFk
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu"(.*?)id="contenedor"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 += QKqM0CwXDk8APOoJFpyntRb[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="releases"(.*?)aside',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 += QKqM0CwXDk8APOoJFpyntRb[0]
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	FzlcxgOGN3VoikMnbTW = True
	for SSqweDUBYv4bkO,title in items:
		title = Y7BxKQdU84R(title)
		if title=='الأعلى مشاهدة':
			if FzlcxgOGN3VoikMnbTW:
				title = 'الافلام '+title
				FzlcxgOGN3VoikMnbTW = False
			else: title = 'المسلسلات '+title
		if title not in d2gCoAnYPG89O:
			if title=='أفلام': ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,LhFnEIuPHdoNc+'/movies',391,gby0BnUuTNFk,gby0BnUuTNFk,'all_movies_tvshows')
			elif title=='مسلسلات': ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,LhFnEIuPHdoNc+'/tvshows',391,gby0BnUuTNFk,gby0BnUuTNFk,'all_movies_tvshows')
			else: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,391)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,type):
	AxiBv1cQueOs0,items = [],[]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FAJERSHOW-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if type in ['featured_movies','featured_tvshows']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="content"(.*?)id="archive-content"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif type=='all_movies_tvshows':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="archive-content"(.*?)class="pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif type=='top_imdb_movies':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='top_imdb_series':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='top-imdb-list tright(.*?)footer",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='search':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="search-page"(.*?)class="sidebar',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='sider':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="widget(.*?)class="widget',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		kiSZOPl4rBqWcby7H = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		eE9BXgNu4MPKIbw2aLDl1AY3R,JNw6vYHP2bgARlQjCyTE,uufJivSZQyj45ql3 = zip(*kiSZOPl4rBqWcby7H)
		items = zip(JNw6vYHP2bgARlQjCyTE,eE9BXgNu4MPKIbw2aLDl1AY3R,uufJivSZQyj45ql3)
	elif type=='randoms':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="slider-movies-tvshows"(.*?)<header>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif 'latest' in type:
		KQydxfMmoJERw = int(type[-1:])
		jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('<header>','<end><start>')
		jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('</div></div></div>','</div></div></div><end>')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<start>(.*?)<end>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[KQydxfMmoJERw]
		if KQydxfMmoJERw==6:
			kiSZOPl4rBqWcby7H = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			JNw6vYHP2bgARlQjCyTE,uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R = zip(*kiSZOPl4rBqWcby7H)
			items = zip(JNw6vYHP2bgARlQjCyTE,eE9BXgNu4MPKIbw2aLDl1AY3R,uufJivSZQyj45ql3)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="content"(.*?)class="(pagination|sidebar)',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0][0]
			if '/collection/' in url:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			elif '/quality/' in url:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items and AxiBv1cQueOs0:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)<.*?serie">(.*?)<',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			title = title[0][1]
			if title in NGcX5a4OifEhZKrY7C0QVyjRA: continue
			NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			title = '_MOD_'+title
		T3Yrx4yZCRqcH = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)<',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if T3Yrx4yZCRqcH: title = T3Yrx4yZCRqcH[0]
		title = Y7BxKQdU84R(title)
		if '/tvshows/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,393,T6TRUSbecYGWIq29KF)
		elif '/episodes/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,393,T6TRUSbecYGWIq29KF)
		elif '/seasons/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,393,T6TRUSbecYGWIq29KF)
		elif '/collection/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,391,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,392,T6TRUSbecYGWIq29KF)
	if type not in ['featured_movies','featured_tvshows']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,391,gby0BnUuTNFk,gby0BnUuTNFk,type)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace(TfYmiUDcZOCgQ86rENjVG1zaqXbWk,LhFnEIuPHdoNc)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FAJERSHOW-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="C rated".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,392,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FAJERSHOW-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if nqkybtoMBH:
		try: jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.decode(JJQFjSIlALchiMzG9,'ignore')
		except: pass
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="C rated".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''id=["']player-option(.*?)class=["'](sheader|pag_episodes)["']''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0][0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for type,y6yAgrGq2LNQYBUzsZcCW0xfPO,b8I69BCpxUaKZsX2N,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+y6yAgrGq2LNQYBUzsZcCW0xfPO+'&nume='+b8I69BCpxUaKZsX2N+'&type='+type
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,DYNVS1Bbgs7,CMrTzQdR72uh9t8Yb4S in items:
			if '=' in T6TRUSbecYGWIq29KF:
				uGVS62KrdwQLylijOUDsIxEBFckoeb = T6TRUSbecYGWIq29KF.split('=')[1]
				title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(uGVS62KrdwQLylijOUDsIxEBFckoeb,'host')
			else: title = gby0BnUuTNFk
			title = CMrTzQdR72uh9t8Yb4S+UpN1CezytPO9XoduhxZSD+title
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download____'+DYNVS1Bbgs7
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return