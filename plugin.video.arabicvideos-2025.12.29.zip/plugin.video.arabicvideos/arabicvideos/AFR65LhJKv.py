# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'CIMA4U'
headers = {'User-Agent':gby0BnUuTNFk}
JB9fyoHr05QOtPjp = '_C4U_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==420: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==421: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==422: WjryKiBebavP = KZhF4Vljtk5Gcp8M7Wf0JmYa(url)
	elif mode==423: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==424: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==427: WjryKiBebavP = FRLd7wnhea92QVuy(url)
	elif mode==429: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd[0].strip('/')
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,'url')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,429,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,425)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,424)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الرئيسية',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,421)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('NavigationMenu(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="*(.*?)"*>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		if '/actors' in SSqweDUBYv4bkO: title = 'أفلام النجوم'
		elif '/netflix' in SSqweDUBYv4bkO: title = 'أفلام ومسلسلات نيتفلكس'
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,421)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'قائمة تفصيلية',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,427)
	return
def FRLd7wnhea92QVuy(website=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('FilteringTitle(.*?)PageTitle',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for zTFlfH8DhAVryqUjX,id,SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		if 'netflix-movies' in SSqweDUBYv4bkO: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in SSqweDUBYv4bkO: title = 'مسلسلات نيتفلكس'
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,421,gby0BnUuTNFk,gby0BnUuTNFk,zTFlfH8DhAVryqUjX+'|'+id)
	return
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if not xxGw3Q5hHDkP8WfVe7m or '|' in xxGw3Q5hHDkP8WfVe7m:
		if '|' not in xxGw3Q5hHDkP8WfVe7m: HOvi3jGdT7gyWfEz1lk2oQhqLKtJY = gby0BnUuTNFk
		else: HOvi3jGdT7gyWfEz1lk2oQhqLKtJY = '/archive/'+xxGw3Q5hHDkP8WfVe7m
		hvoMKNipYI16GgRlOQ3ZEA8UTWek = False
		if 'PinSlider' in jS6fQGXeouTB7xKd32ZMy:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'المميزة',url,421,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
			hvoMKNipYI16GgRlOQ3ZEA8UTWek = True
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('PageTitle(.*?)PageContent',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			xki4Q3jNVZzFAsaWOPCge = QKqM0CwXDk8APOoJFpyntRb[0]
			vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-tab="(.*?)".*?<span>(.*?)<',xki4Q3jNVZzFAsaWOPCge,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for tvFgkPZGAnxDuTbCH3fldE40m,T3Yrx4yZCRqcH in vv7qYWmFwzBPofI5e2ls:
				RkntpA1UJDV4vNgyaex6GPWK9YQIcC = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/ajaxcenter/action/HomepageLoader/tab/'+tvFgkPZGAnxDuTbCH3fldE40m+HOvi3jGdT7gyWfEz1lk2oQhqLKtJY+'/'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+T3Yrx4yZCRqcH,RkntpA1UJDV4vNgyaex6GPWK9YQIcC,421)
				hvoMKNipYI16GgRlOQ3ZEA8UTWek = True
		if hvoMKNipYI16GgRlOQ3ZEA8UTWek: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	if xxGw3Q5hHDkP8WfVe7m=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('PinSlider(.*?)MultiFilter',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('PinSlider(.*?)PageTitle',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		else: AxiBv1cQueOs0 = gby0BnUuTNFk
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
	elif '/filter/' in url:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('PageContent(.*?)class="*pagination"*',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif '/actors' in url:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('PageContent(.*?)class="*pagination"*',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('Cima4uBlocks(.*?)</li></ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		else: AxiBv1cQueOs0 = gby0BnUuTNFk
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		if not title: continue
		if '?news=' in SSqweDUBYv4bkO: continue
		title = title.replace('مشاهدة ',gby0BnUuTNFk)
		title = Y7BxKQdU84R(title)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) حلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if Cso7iV0ZOw2UW5Ez and 'حلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,422,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/actor/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,421,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,422,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb and xxGw3Q5hHDkP8WfVe7m!='featured':
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			title = title.replace('الصفحة ',gby0BnUuTNFk)
			if title!=gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,421)
	fhW8oRx6TUJiuFK5GXQH9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('</li><a href="(.*?)".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if fhW8oRx6TUJiuFK5GXQH9:
		SSqweDUBYv4bkO,title = fhW8oRx6TUJiuFK5GXQH9[0]
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,421)
	return
def KZhF4Vljtk5Gcp8M7Wf0JmYa(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-SEASONS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="WatchNow".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		url = QKqM0CwXDk8APOoJFpyntRb[0]
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-SEASONS-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('SeasonsSections(.*?)</div></div></div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if '/tag/' in url or '/actor' in url:
		Xw3tTz8UD4LK26C(url)
	elif QKqM0CwXDk8APOoJFpyntRb:
		T6TRUSbecYGWIq29KF = oKew16fsvuV8.getInfoLabel('ListItem.Thumb')
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("href='(.*?)'>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		NEY1RUFghGLoW7Pev28HrSuXiB9t6 = ['مسلسل','موسم','برنامج','حلقة']
		for SSqweDUBYv4bkO,title in items:
			if any(value in title for value in NEY1RUFghGLoW7Pev28HrSuXiB9t6):
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,423,T6TRUSbecYGWIq29KF)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,426,T6TRUSbecYGWIq29KF)
	else: Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	T6TRUSbecYGWIq29KF = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"background-image:url\((.*?)\)',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if T6TRUSbecYGWIq29KF: T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF[0]
	else: T6TRUSbecYGWIq29KF = gby0BnUuTNFk
	sbXtWkYlVJ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('EpisodesSection(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if sbXtWkYlVJ:
		AxiBv1cQueOs0 = sbXtWkYlVJ[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,Cso7iV0ZOw2UW5Ez in items:
			title = title+UpN1CezytPO9XoduhxZSD+Cso7iV0ZOw2UW5Ez
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,426,T6TRUSbecYGWIq29KF)
	else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+'رابط التشغيل',url,426,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ZZGMQ7m0dTsJfkn = ccV0NKHwQpMun6FtZvAi.url
	if cAIRPFK6boejVU549WzqBGCaJ0r: ZZGMQ7m0dTsJfkn = ZZGMQ7m0dTsJfkn.encode(JJQFjSIlALchiMzG9)
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(ZZGMQ7m0dTsJfkn,'url')
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('WatchSection(.*?)</div></div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-link="(.*?)".*? />(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for n1vgldiHDYL8zhS,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if 'myvid' in title.lower(): title = 'خاص '+title
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/structure/server.php?id='+n1vgldiHDYL8zhS+'?named='+title+'__watch'
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk)
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('DownloadServers(.*?)</div></div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*? />(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if 'myvid' in title.lower(): T3Yrx4yZCRqcH = '__خاص'
			else: T3Yrx4yZCRqcH = gby0BnUuTNFk
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'+T3Yrx4yZCRqcH
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk)
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/Search?q='+search
	Xw3tTz8UD4LK26C(url,'search')
	return
def G2dUpHgXKM1Nzu4w9(url):
	if 'smartemadfilter' not in url: url = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('MultiFilter(.*?)PageTitle',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return tpQ9UZ8rIuhvW3box21X6iqsz
def Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0):
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-id="(.*?)".*?</div>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return items
def XI6uxNML5haHVWrm0p8U(url):
	c7oIqRywsVUpZ8rdTu6LNm20Y = url.split('/smartemadfilter?')[0]
	q53fXShJmaD0iWrz7KbnlAFBoR = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace(c7oIqRywsVUpZ8rdTu6LNm20Y,q53fXShJmaD0iWrz7KbnlAFBoR)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
FFCXkHm5TYPUbBp = ['category','types','release-year']
ZfNKXALGqzaCsM68gw0d7lD = ['Quality','release-year','types','category']
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global FFCXkHm5TYPUbBp
			FFCXkHm5TYPUbBp = FFCXkHm5TYPUbBp[1:]
		if FFCXkHm5TYPUbBp[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[0]
		for xuX6UN0WRQbHArDV in range(len(FFCXkHm5TYPUbBp[0:-1])):
			if FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='ALL_ITEMS_FILTER':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+QfoFHUnpEi4W2OuT8DBg3
		Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها ',Tf5ueYGZIFl1hraoEOVKi,421,gby0BnUuTNFk,gby0BnUuTNFk,'filter')
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',Tf5ueYGZIFl1hraoEOVKi,421,gby0BnUuTNFk,gby0BnUuTNFk,'filter')
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	tpQ9UZ8rIuhvW3box21X6iqsz = G2dUpHgXKM1Nzu4w9(url)
	dict = {}
	for name,AxiBv1cQueOs0,CCRe1gOK8Dtca0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		if '/category/' in url and CCRe1gOK8Dtca0=='category': continue
		name = name.replace('--',gby0BnUuTNFk)
		items = Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='SPECIFIED_FILTER':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<2:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]:
					url = XI6uxNML5haHVWrm0p8U(url)
					Xw3tTz8UD4LK26C(url)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'SPECIFIED_FILTER___'+J21ulLnwtByA4XvcC)
				return
			else:
				Tf5ueYGZIFl1hraoEOVKi = XI6uxNML5haHVWrm0p8U(Tf5ueYGZIFl1hraoEOVKi)
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,421,gby0BnUuTNFk,gby0BnUuTNFk,'filter')
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,425,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='ALL_ITEMS_FILTER':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع :'+name,Tf5ueYGZIFl1hraoEOVKi,424,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if value=='196533': w7su60daQz13VIplrfxJk = 'أفلام نيتفلكس'
			elif value=='196531': w7su60daQz13VIplrfxJk = 'مسلسلات نيتفلكس'
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' :'#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' :'+name
			if type=='ALL_ITEMS_FILTER': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,424,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='SPECIFIED_FILTER' and FFCXkHm5TYPUbBp[-2]+'=' in mW9DK3tVFwd:
				zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'modified_filters')
				mm7pzl3HMi0R8fGu = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
				mm7pzl3HMi0R8fGu = XI6uxNML5haHVWrm0p8U(mm7pzl3HMi0R8fGu)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,421,gby0BnUuTNFk,gby0BnUuTNFk,'filter')
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,425,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.replace('=&','=0&')
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	for key in ZfNKXALGqzaCsM68gw0d7lD:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if '%' not in value: value = IcChbXakUDFLszgpSG2jqem9(value)
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	d28pn3tAz4V = d28pn3tAz4V.replace('=0','=')
	return d28pn3tAz4V