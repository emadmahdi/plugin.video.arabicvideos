# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'ALARAB'
headers = {'User-Agent':gby0BnUuTNFk}
JB9fyoHr05QOtPjp = '_KLA_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==10: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==11: WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	elif mode==12: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==13: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==14: WjryKiBebavP = rjyJx1X2wZN()
	elif mode==15: WjryKiBebavP = t8Yc7p4oKPMVIhAHgLB5JxSNrsE()
	elif mode==16: WjryKiBebavP = TqoQ3npgBuNcK()
	elif mode==19: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,19,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'آخر الإضافات',gby0BnUuTNFk,14)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات رمضان',gby0BnUuTNFk,15)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'ALARAB-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="nav-slider"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	ohOj6lwbJqHu0sT = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',ohOj6lwbJqHu0sT,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,11)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="navbar"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	xki4Q3jNVZzFAsaWOPCge = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',xki4Q3jNVZzFAsaWOPCge,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,11)
	return jS6fQGXeouTB7xKd32ZMy
def t8Yc7p4oKPMVIhAHgLB5JxSNrsE():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'جميع المسلسلات العربية',LhFnEIuPHdoNc+'/view-8/مسلسلات-عربية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات السنة الأخيرة',gby0BnUuTNFk,16)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان الأخيرة 1',LhFnEIuPHdoNc+'/view-8/مسلسلات-رمضان-2022',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان الأخيرة 2',LhFnEIuPHdoNc+'/view-8/مسلسلات-رمضان-2023',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2023',LhFnEIuPHdoNc+'/ramadan2023/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2022',LhFnEIuPHdoNc+'/ramadan2022/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2021',LhFnEIuPHdoNc+'/ramadan2021/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2020',LhFnEIuPHdoNc+'/ramadan2020/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2019',LhFnEIuPHdoNc+'/ramadan2019/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2018',LhFnEIuPHdoNc+'/ramadan2018/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2017',LhFnEIuPHdoNc+'/ramadan2017/مصرية',11)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مسلسلات رمضان 2016',LhFnEIuPHdoNc+'/ramadan2016/مصرية',11)
	return
def rjyJx1X2wZN():
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,True,'ALARAB-LATEST-1st')
	QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('heading-top(.*?)div class=',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]+QKqM0CwXDk8APOoJFpyntRb[1]
	items=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		url = LhFnEIuPHdoNc + SSqweDUBYv4bkO
		if 'series' in url: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,11,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,url,12,T6TRUSbecYGWIq29KF)
	return
def Xw3tTz8UD4LK26C(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,True,True,'ALARAB-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('video-category(.*?)right_content',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	znBDIy3fxKUPoTGJR6SCp5 = False
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA,MFyUAIPhQNR85i9X0DlsYZcvq67 = [],[]
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		if title==gby0BnUuTNFk: title = SSqweDUBYv4bkO.split('/')[-1].replace('-',UpN1CezytPO9XoduhxZSD)
		VUIYkcERzXphNiuwvxJybGT = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(\d+)',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if VUIYkcERzXphNiuwvxJybGT: VUIYkcERzXphNiuwvxJybGT = int(VUIYkcERzXphNiuwvxJybGT[0])
		else: VUIYkcERzXphNiuwvxJybGT = 0
		MFyUAIPhQNR85i9X0DlsYZcvq67.append([T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title,VUIYkcERzXphNiuwvxJybGT])
	MFyUAIPhQNR85i9X0DlsYZcvq67 = sorted(MFyUAIPhQNR85i9X0DlsYZcvq67, reverse=True, key=lambda key: key[3])
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title,VUIYkcERzXphNiuwvxJybGT in MFyUAIPhQNR85i9X0DlsYZcvq67:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc + SSqweDUBYv4bkO
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',gby0BnUuTNFk)
		title = title.replace('عالية على العرب',gby0BnUuTNFk)
		title = title.replace('مشاهدة مباشرة',gby0BnUuTNFk)
		title = title.replace('اون لاين',gby0BnUuTNFk)
		title = title.replace('اونلاين',gby0BnUuTNFk)
		title = title.replace('بجودة عالية',gby0BnUuTNFk)
		title = title.replace('جودة عالية',gby0BnUuTNFk)
		title = title.replace('بدون تحميل',gby0BnUuTNFk)
		title = title.replace('على العرب',gby0BnUuTNFk)
		title = title.replace('مباشرة',gby0BnUuTNFk)
		title = title.strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		title = '_MOD_'+title
		T3Yrx4yZCRqcH = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if Cso7iV0ZOw2UW5Ez: T3Yrx4yZCRqcH = Cso7iV0ZOw2UW5Ez[0]
		if T3Yrx4yZCRqcH not in NGcX5a4OifEhZKrY7C0QVyjRA:
			NGcX5a4OifEhZKrY7C0QVyjRA.append(T3Yrx4yZCRqcH)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+T3Yrx4yZCRqcH,SSqweDUBYv4bkO,13,T6TRUSbecYGWIq29KF)
				znBDIy3fxKUPoTGJR6SCp5 = True
			elif 'series' in SSqweDUBYv4bkO:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,11,T6TRUSbecYGWIq29KF)
				znBDIy3fxKUPoTGJR6SCp5 = True
			else:
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,12,T6TRUSbecYGWIq29KF)
				znBDIy3fxKUPoTGJR6SCp5 = True
	if znBDIy3fxKUPoTGJR6SCp5:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,kdwXYDMQOjz51Z08W in items:
			url = LhFnEIuPHdoNc + SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+kdwXYDMQOjz51Z08W,url,11)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'ALARAB-EPISODES-1st')
	jpoe3KZUgTv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(/series.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	Tf5ueYGZIFl1hraoEOVKi = LhFnEIuPHdoNc+jpoe3KZUgTv[0]
	WjryKiBebavP = Xw3tTz8UD4LK26C(Tf5ueYGZIFl1hraoEOVKi)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(cjSzHQn9N4BuIZO0xJ,url,gby0BnUuTNFk,headers,True,'ALARAB-PLAY-1st')
	Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="resp-iframe" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Tf5ueYGZIFl1hraoEOVKi:
		Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(http.*?)(http.*?)$',Tf5ueYGZIFl1hraoEOVKi,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if vx14CNdbsZTz:
			FzlcxgOGN3VoikMnbTW = vx14CNdbsZTz[0][0]
			AA4HQmS5qI1ifP,dI92Ttsie1yMKZYNbHXlxUw0aR = vx14CNdbsZTz[0][1].rsplit('/',1)
			mm7pzl3HMi0R8fGu = AA4HQmS5qI1ifP+'?named=__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(mm7pzl3HMi0R8fGu)
			gAomMHK9Z3OWsv8ciEpGFqIb = FzlcxgOGN3VoikMnbTW+dI92Ttsie1yMKZYNbHXlxUw0aR
		else:
			N84Yo7V9qS = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,False,'ALARAB-PLAY-2nd')
			Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"src": "(.*?)"',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if Tf5ueYGZIFl1hraoEOVKi:
				Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]+'?named=__watch__m3u8'
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(Tf5ueYGZIFl1hraoEOVKi)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('searchBox(.*?)<style>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if Tf5ueYGZIFl1hraoEOVKi:
			Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[0]+'?named=__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(Tf5ueYGZIFl1hraoEOVKi)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def TqoQ3npgBuNcK():
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,True,'ALARAB-RAMADAN-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="content_sec"(.*?)id="left_content"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	p4bOGqKrdTB = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('/ramadan([0-9]+)/',str(items),ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	p4bOGqKrdTB = p4bOGqKrdTB[0]
	for SSqweDUBYv4bkO,title in items:
		url = LhFnEIuPHdoNc+SSqweDUBYv4bkO
		title = title.strip(UpN1CezytPO9XoduhxZSD)+UpN1CezytPO9XoduhxZSD+p4bOGqKrdTB
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,11)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc + "/q/" + apTFWBhb175nwjvKtmJ2
	WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	return