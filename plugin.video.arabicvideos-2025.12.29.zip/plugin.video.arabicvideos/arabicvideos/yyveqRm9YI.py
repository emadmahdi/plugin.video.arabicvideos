# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'LAROZA'
JB9fyoHr05QOtPjp = '_LRZ_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==700: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==701: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==702: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==703: WjryKiBebavP = tHWd5iUKp0uBRESTL1FCAOGabsV(url,text)
	elif mode==704: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==709: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = LhFnEIuPHdoNc
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,709,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المسلسلات',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/moslslat.php',701)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pm-top-nav"(.*?)class="hidden',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		title = title.replace('<b>',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
		if title in d2gCoAnYPG89O: continue
		if 'javascrip' in SSqweDUBYv4bkO: continue
		if 'class=' in SSqweDUBYv4bkO: continue
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,704)
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	znBDIy3fxKUPoTGJR6SCp5 = False
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('role="menu"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('"presentation"','</ul>')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = [(gby0BnUuTNFk,AxiBv1cQueOs0)]
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' فرز أو فلتر أو ترتيب '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		for U4LRgsfMau2nr3Ay6WXqhkledw,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if U4LRgsfMau2nr3Ay6WXqhkledw: U4LRgsfMau2nr3Ay6WXqhkledw = U4LRgsfMau2nr3Ay6WXqhkledw+': '
			for SSqweDUBYv4bkO,title in items:
				title = U4LRgsfMau2nr3Ay6WXqhkledw+title
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,701)
				znBDIy3fxKUPoTGJR6SCp5 = True
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-category-subcats"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)<30:
			if znBDIy3fxKUPoTGJR6SCp5: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			for SSqweDUBYv4bkO,title in items:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,701)
				znBDIy3fxKUPoTGJR6SCp5 = True
	sbXtWkYlVJ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="catfootr"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if 0 and sbXtWkYlVJ:
		AxiBv1cQueOs0 = sbXtWkYlVJ[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if 1:
			if znBDIy3fxKUPoTGJR6SCp5: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			for SSqweDUBYv4bkO,title in items:
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,701)
				znBDIy3fxKUPoTGJR6SCp5 = True
	if not znBDIy3fxKUPoTGJR6SCp5: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',url,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-TITLES-1st')
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-TITLES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	AxiBv1cQueOs0,items = gby0BnUuTNFk,[]
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((gby0BnUuTNFk,SSqweDUBYv4bkO,title))
	elif Z05rTiu6LwakteK8VfY=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="content"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_episodes':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_movies':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(QKqM0CwXDk8APOoJFpyntRb)>1: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[1]
	elif Z05rTiu6LwakteK8VfY=='featured_series':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"ba mgb table full"(.*?)"clearfix"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)" title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((gby0BnUuTNFk,SSqweDUBYv4bkO,title))
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('("thumbnail".*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if AxiBv1cQueOs0 and not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: return
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		title = Y7BxKQdU84R(title)
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,702,T6TRUSbecYGWIq29KF)
		elif Z05rTiu6LwakteK8VfY=='new_episodes':
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,702,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,703,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,703,T6TRUSbecYGWIq29KF)
	if 1:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if '?' in url: url,kdwXYDMQOjz51Z08W = url.split('?',1)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=='#': continue
				SSqweDUBYv4bkO = url+SSqweDUBYv4bkO
				title = Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,701)
	return
def tHWd5iUKp0uBRESTL1FCAOGabsV(url,YYOman4GEXScVfjg89bRkDq):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-EPISODES_SEASONS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	gQmur3iRSZ9IAOX = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"series-header".*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if gQmur3iRSZ9IAOX: T6TRUSbecYGWIq29KF = gQmur3iRSZ9IAOX[0]
	else: T6TRUSbecYGWIq29KF = gby0BnUuTNFk
	items = []
	RTvjVPxz2QtwD7el9iy = False
	if l2Np9PfFqv4RcW7Y and not YYOman4GEXScVfjg89bRkDq:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-serie="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for YYOman4GEXScVfjg89bRkDq,title in items:
			YYOman4GEXScVfjg89bRkDq = YYOman4GEXScVfjg89bRkDq.strip('#')
			if len(items)>1: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,703,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,YYOman4GEXScVfjg89bRkDq)
			else: RTvjVPxz2QtwD7el9iy = True
	else: RTvjVPxz2QtwD7el9iy = True
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsEpisodesMain(.*?)<script>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb and RTvjVPxz2QtwD7el9iy:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("`season_slug` = '"+YYOman4GEXScVfjg89bRkDq+"'(.*?)</div>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if qsQxHTa4e0JYLUSKF7: AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		else:
			Tf5ueYGZIFl1hraoEOVKi = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/fetch_episodes.php'
			data = 'seasonId='+IcChbXakUDFLszgpSG2jqem9(YYOman4GEXScVfjg89bRkDq)
			headers = {'Content-Type':'application/x-www-form-urlencoded'}
			ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',Tf5ueYGZIFl1hraoEOVKi,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-EPISODES_SEASONS-2nd')
			AxiBv1cQueOs0 = ccV0NKHwQpMun6FtZvAi.content
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''href=['"](.*?)['"]><em>(.*?)</span>''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not vv7qYWmFwzBPofI5e2ls: vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"><em>(.*?)</span>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		items = []
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF))
		if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip('./')
			SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
			title = title.replace('</em><span>',UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,702,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q,kNhgPmawJlXd3R0yov = [],[]
	jS6fQGXeouTB7xKd32ZMy = ''
	if 'post=' in jS6fQGXeouTB7xKd32ZMy:
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="player".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		y6yAgrGq2LNQYBUzsZcCW0xfPO = SSqweDUBYv4bkO.split('post=')[1]
		y6yAgrGq2LNQYBUzsZcCW0xfPO = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(y6yAgrGq2LNQYBUzsZcCW0xfPO)
		if nqkybtoMBH: y6yAgrGq2LNQYBUzsZcCW0xfPO = y6yAgrGq2LNQYBUzsZcCW0xfPO.decode(JJQFjSIlALchiMzG9)
		y6yAgrGq2LNQYBUzsZcCW0xfPO = TqNUy3Z4SFWvplGwXC82A('dict',y6yAgrGq2LNQYBUzsZcCW0xfPO)
		vx14CNdbsZTz = y6yAgrGq2LNQYBUzsZcCW0xfPO['servers']
		K6ucHgjCtqf9wBZxXAUh3Db5EMJW = list(vx14CNdbsZTz.keys())
		vx14CNdbsZTz = list(vx14CNdbsZTz.values())
		kiSZOPl4rBqWcby7H = zip(K6ucHgjCtqf9wBZxXAUh3Db5EMJW,vx14CNdbsZTz)
		for title,SSqweDUBYv4bkO in kiSZOPl4rBqWcby7H:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	else:
		Tf5ueYGZIFl1hraoEOVKi = url.replace('video.php','play.php')
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'LAROZA-PLAY-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embedded" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if SSqweDUBYv4bkO:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
			if SSqweDUBYv4bkO not in kNhgPmawJlXd3R0yov:
				kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
				title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__embed'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-servers"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<script(.*?)</script',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if QKqM0CwXDk8APOoJFpyntRb:
				AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
				if 'function(h,u,n,t,e,r)' in AxiBv1cQueOs0:
					AxiBv1cQueOs0 = ua5b3f7lEA(AxiBv1cQueOs0)
					AxiBv1cQueOs0 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("encodedHtml = '(.*?)'",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					if AxiBv1cQueOs0:
						AxiBv1cQueOs0 = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(AxiBv1cQueOs0[0])
						if nqkybtoMBH: AxiBv1cQueOs0 = AxiBv1cQueOs0.decode(JJQFjSIlALchiMzG9)
						items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-name="(.*?)".*?data-embed="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
						for title,SSqweDUBYv4bkO in items:
							if SSqweDUBYv4bkO not in kNhgPmawJlXd3R0yov:
								kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
								SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
								ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
		if 'pm-download' not in jS6fQGXeouTB7xKd32ZMy:
			Tf5ueYGZIFl1hraoEOVKi = url.replace('video.php','download.php')
			ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,False,'LAROZA-PLAY-2nd')
			jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pm-download(.*?)"content"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<script(.*?)</script',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if QKqM0CwXDk8APOoJFpyntRb:
				AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
				if 'function(h,u,n,t,e,r)' in AxiBv1cQueOs0:
					AxiBv1cQueOs0 = ua5b3f7lEA(AxiBv1cQueOs0)
					SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(http.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
					if SSqweDUBYv4bkO:
						SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
						if SSqweDUBYv4bkO not in kNhgPmawJlXd3R0yov:
							kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
							title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
							SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'
							ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/search.php?keywords='+search
	Xw3tTz8UD4LK26C(url,'search')
	return