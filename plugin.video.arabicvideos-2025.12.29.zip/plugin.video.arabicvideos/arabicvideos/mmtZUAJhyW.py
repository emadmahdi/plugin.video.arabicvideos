# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'MOVS4U'
JB9fyoHr05QOtPjp = '_M4U_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['انواع افلام','جودات افلام']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==380: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==381: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==382: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==383: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==389: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,389,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المميزة',LhFnEIuPHdoNc,381,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'الجانبية',LhFnEIuPHdoNc,381,gby0BnUuTNFk,gby0BnUuTNFk,'sider')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'MOVS4U-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<header>.*?<h2>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for KQydxfMmoJERw in range(len(items)):
		title = items[KQydxfMmoJERw]
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,LhFnEIuPHdoNc,381,gby0BnUuTNFk,gby0BnUuTNFk,'latest'+str(KQydxfMmoJERw))
	AxiBv1cQueOs0 = gby0BnUuTNFk
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu"(.*?)id="contenedor"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 += QKqM0CwXDk8APOoJFpyntRb[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="sidebar(.*?)aside',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 += QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	FzlcxgOGN3VoikMnbTW = True
	for SSqweDUBYv4bkO,title in items:
		title = Y7BxKQdU84R(title)
		if title=='الأعلى مشاهدة':
			if FzlcxgOGN3VoikMnbTW:
				title = 'الافلام '+title
				FzlcxgOGN3VoikMnbTW = False
			else: title = 'المسلسلات '+title
		if title not in d2gCoAnYPG89O:
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,381)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,type):
	AxiBv1cQueOs0,items = [],[]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'MOVS4U-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	if type=='search':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="search-page"(.*?)class="sidebar',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif type=='sider':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="widget(.*?)class="widget',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		ffOenalT0vU = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		eE9BXgNu4MPKIbw2aLDl1AY3R,JNw6vYHP2bgARlQjCyTE,uufJivSZQyj45ql3 = zip(*ffOenalT0vU)
		items = zip(JNw6vYHP2bgARlQjCyTE,eE9BXgNu4MPKIbw2aLDl1AY3R,uufJivSZQyj45ql3)
	elif type=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="slider-movies-tvshows"(.*?)<header>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	elif 'latest' in type:
		KQydxfMmoJERw = int(type[-1:])
		jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('<header>','<end><start>')
		jS6fQGXeouTB7xKd32ZMy = jS6fQGXeouTB7xKd32ZMy.replace('<div class="sidebar','<end><div class="sidebar')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<start>(.*?)<end>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[KQydxfMmoJERw]
		if KQydxfMmoJERw==2: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="content"(.*?)class="(pagination|sidebar)',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0][0]
			if '/collection/' in url:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			elif '/quality/' in url:
				items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items and AxiBv1cQueOs0:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		if 'serie' in title:
			title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)<.*?serie">(.*?)<',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			title = title[0][1]
			if title in NGcX5a4OifEhZKrY7C0QVyjRA: continue
			NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			title = '_MOD_'+title
		T3Yrx4yZCRqcH = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)<',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if T3Yrx4yZCRqcH: title = T3Yrx4yZCRqcH[0]
		title = Y7BxKQdU84R(title)
		if '/tvshows/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,383,T6TRUSbecYGWIq29KF)
		elif '/episodes/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,383,T6TRUSbecYGWIq29KF)
		elif '/seasons/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,383,T6TRUSbecYGWIq29KF)
		elif '/collection/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,381,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,382,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		omnDQlJzjSKqNTthIZuedU4ipb = QKqM0CwXDk8APOoJFpyntRb[0][0]
		DXkGgo0d8UNRApLf1nW = QKqM0CwXDk8APOoJFpyntRb[0][1]
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0][2]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("href='(.*?)'.*?>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title==gby0BnUuTNFk or title==DXkGgo0d8UNRApLf1nW: continue
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,381,gby0BnUuTNFk,gby0BnUuTNFk,type)
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('/page/'+title+'/','/page/'+DXkGgo0d8UNRApLf1nW+'/')
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'اخر صفحة '+DXkGgo0d8UNRApLf1nW,SSqweDUBYv4bkO,381,gby0BnUuTNFk,gby0BnUuTNFk,type)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'MOVS4U-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="C rated".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY,False):
		ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+'المسلسل للكبار والمبرمج منعه',gby0BnUuTNFk,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		Tf5ueYGZIFl1hraoEOVKi = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''class='item'><a href="(.*?)"''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if Tf5ueYGZIFl1hraoEOVKi:
			Tf5ueYGZIFl1hraoEOVKi = Tf5ueYGZIFl1hraoEOVKi[1]
			Ra4XAK1tDxc3kfOrIdsjLpzmGN0(Tf5ueYGZIFl1hraoEOVKi)
			return
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''class='episodios'(.*?)id="cast"''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for T6TRUSbecYGWIq29KF,Cso7iV0ZOw2UW5Ez,SSqweDUBYv4bkO,name in items:
			title = Cso7iV0ZOw2UW5Ez+' : '+name+' الحلقة'
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,382)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'MOVS4U-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="C rated".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0][0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("data-url='(.*?)'.*?class='server'>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="remodal"(.*?)class="remodal-close"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return