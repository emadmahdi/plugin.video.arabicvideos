# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
headers = { 'User-Agent' : gby0BnUuTNFk }
CC3nOPFMovd72u = 'AKWAM'
JB9fyoHr05QOtPjp = '_AKW_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
ldqmUp2YDAR7TPjrCGBe5Z8ogfW1 = gby0BnUuTNFk
d2gCoAnYPG89O = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==240: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==241: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==242: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==243: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==244: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'FILTERS___'+text)
	elif mode==245: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'CATEGORIES___'+text)
	elif mode==246: WjryKiBebavP = hh5HSUm6L7gBs4KIzEGRVZu(url)
	elif mode==247: WjryKiBebavP = y8yIxWS9DZKPtEMrfpc1RmnkbN4o(url)
	elif mode==248: WjryKiBebavP = LseiaWBJfPHYqoxI67Edp8MzlOtgS()
	elif mode==249: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def LseiaWBJfPHYqoxI67Edp8MzlOtgS():
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAM-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	BBUcuAEHX4 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('home-site-btn-container.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if BBUcuAEHX4: BBUcuAEHX4 = BBUcuAEHX4[0]
	else: BBUcuAEHX4 = LhFnEIuPHdoNc
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',BBUcuAEHX4,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'AKWAM-MENU-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,249,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',LhFnEIuPHdoNc,246)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',LhFnEIuPHdoNc,247)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'المميزة',BBUcuAEHX4,241,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	PGoDwe37JU = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('recently-container.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	SSqweDUBYv4bkO = PGoDwe37JU[0]
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أضيف حديثا',SSqweDUBYv4bkO,241)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,name,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
		if name in d2gCoAnYPG89O: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+name,SSqweDUBYv4bkO,241)
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			title = name+UpN1CezytPO9XoduhxZSD+title
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,241)
	return
def hh5HSUm6L7gBs4KIzEGRVZu(website=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKWAM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu(.*?)<nav',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?text">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O:
				title = title+' مصنفة'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,245)
		if website==gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	return jS6fQGXeouTB7xKd32ZMy
def y8yIxWS9DZKPtEMrfpc1RmnkbN4o(website=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,'AKWAM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="menu(.*?)<nav',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?text">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title not in d2gCoAnYPG89O:
				title = title+' مفلترة'
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,244)
		if website==gby0BnUuTNFk: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('swiper-container(.*?)swiper-button-prev',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="widget"(.*?)main-footer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not items:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
			if '/series/' in SSqweDUBYv4bkO or '/shows/' in SSqweDUBYv4bkO:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,242,T6TRUSbecYGWIq29KF)
			elif '/movies/' in SSqweDUBYv4bkO:
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,243,T6TRUSbecYGWIq29KF)
			elif '/games/' not in SSqweDUBYv4bkO:
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,243,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,241)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	url = LhFnEIuPHdoNc + '/search?q='+apTFWBhb175nwjvKtmJ2
	WjryKiBebavP = Xw3tTz8UD4LK26C(url)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in jS6fQGXeouTB7xKd32ZMy:
		T6TRUSbecYGWIq29KF = oKew16fsvuV8.getInfoLabel('ListItem.Icon')
		ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+'رابط التشغيل',url,243,T6TRUSbecYGWIq29KF)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('-episodes">(.*?)<div class="widget-4',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		JsAt0zywiZXQM3YKvnG6ClDq7N8L = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in JsAt0zywiZXQM3YKvnG6ClDq7N8L:
			title = title.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,242,T6TRUSbecYGWIq29KF)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,243,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,True,'AKWAM-PLAY-1st')
	Zu5IqlPBEWfSHY = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('badge-danger.*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Zu5IqlPBEWfSHY and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,Zu5IqlPBEWfSHY): return
	LCbazZhTH3tOypqo5cF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('li><a href="#(.*?)".*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	eE9BXgNu4MPKIbw2aLDl1AY3R,uufJivSZQyj45ql3,bXMpofzj7h,OjldQN08u3 = [],[],[],[]
	if LCbazZhTH3tOypqo5cF7:
		byqNDIa3HSpucQLm = 'mp4'
		for yBk6nWlMr9,DYNVS1Bbgs7 in LCbazZhTH3tOypqo5cF7:
			QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('tab-content quality" id="'+yBk6nWlMr9+'".*?</div>.\s*</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			bXMpofzj7h.append(AxiBv1cQueOs0)
			OjldQN08u3.append(DYNVS1Bbgs7)
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="qualities(.*?)<h3.*?>(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			AxiBv1cQueOs0,filename = QKqM0CwXDk8APOoJFpyntRb[0]
			LOXvepkjWod6GFJ4Z2g03mt7I = ['zip','rar','txt','pdf','htm','tar','iso','html']
			byqNDIa3HSpucQLm = filename.rsplit('.',1)[1].strip(UpN1CezytPO9XoduhxZSD)
			if byqNDIa3HSpucQLm in LOXvepkjWod6GFJ4Z2g03mt7I:
				tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'الملف ليس فيديو ولا صوت')
				return
		bXMpofzj7h.append(AxiBv1cQueOs0)
		OjldQN08u3.append(gby0BnUuTNFk)
	for xuX6UN0WRQbHArDV in range(len(bXMpofzj7h)):
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?icon-(.*?)"',bXMpofzj7h[xuX6UN0WRQbHArDV],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,VoG0JydntC3qwxg6 in vx14CNdbsZTz:
			if 'torrent' in VoG0JydntC3qwxg6: continue
			elif 'download' in VoG0JydntC3qwxg6: type = 'download'
			elif 'play' in VoG0JydntC3qwxg6: type = 'watch'
			else: type = 'unknown'
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named=__'+type+'____'+OjldQN08u3[xuX6UN0WRQbHArDV]+'__akwam'
			eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	FFCXkHm5TYPUbBp = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='CATEGORIES':
		if FFCXkHm5TYPUbBp[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[0]
		for xuX6UN0WRQbHArDV in range(len(FFCXkHm5TYPUbBp[0:-1])):
			if FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = FFCXkHm5TYPUbBp[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'all')
		Tf5ueYGZIFl1hraoEOVKi = url+'?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='FILTERS':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'all')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'?'+QfoFHUnpEi4W2OuT8DBg3
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها',Tf5ueYGZIFl1hraoEOVKi,241,gby0BnUuTNFk,'1')
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',Tf5ueYGZIFl1hraoEOVKi,241,gby0BnUuTNFk,'1')
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,headers,True,'AKWAM-FILTERS_MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<form id(.*?)</form>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	dict = {}
	for CCRe1gOK8Dtca0,name,AxiBv1cQueOs0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<option(.*?)>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='CATEGORIES':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<=1:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: Xw3tTz8UD4LK26C(Tf5ueYGZIFl1hraoEOVKi)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'CATEGORIES___'+J21ulLnwtByA4XvcC)
				return
			else:
				if CCRe1gOK8Dtca0==FFCXkHm5TYPUbBp[-1]: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,241,gby0BnUuTNFk,'1')
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,245,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='FILTERS':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع : '+name,Tf5ueYGZIFl1hraoEOVKi,244,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			if 'value' not in value: value = w7su60daQz13VIplrfxJk
			else: value = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"(.*?)"',value,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' : '#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' : '+name
			if type=='FILTERS': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,244,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='CATEGORIES' and FFCXkHm5TYPUbBp[-2]+'=' in mW9DK3tVFwd:
				zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'all')
				mm7pzl3HMi0R8fGu = url+'?'+zfRG7q8BlLZ9cATPNk6Od
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,241,gby0BnUuTNFk,'1')
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,245,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	ZfNKXALGqzaCsM68gw0d7lD = ['section','category','rating','year','language','formats','quality']
	for key in ZfNKXALGqzaCsM68gw0d7lD:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	return d28pn3tAz4V