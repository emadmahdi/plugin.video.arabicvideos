# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'GLOBALSEARCH'
JB9fyoHr05QOtPjp = '_GLS_'
def b2IhmMiR7W3VnPa581GEl6Nu(mi63FgbZoVerXaTGNhsUkuR0ILQW,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,kdwXYDMQOjz51Z08W):
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==540: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==541: WjryKiBebavP = CdzvFDU3hAekyxi5RSu0B8EbGqjIrf(fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==542: WjryKiBebavP = V8R3ZQEmy2dPn0jokFJDCN(fbmZ9V58PCTz,UJeuWoLKP7ZI15O4ypTVs8caj,kdwXYDMQOjz51Z08W)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==543: WjryKiBebavP = TVzJKmEdUj3s()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==548: WjryKiBebavP = kSDvJhmuOrIny(UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==549: WjryKiBebavP = a3NI0EopMZw(fbmZ9V58PCTz)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder','بحث جديد لجميع المواقع',gby0BnUuTNFk,549)
	ygWIQGf25qwVxLkXrYDjp('link','كيف يعمل بحث جميع المواقع','',543)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'==== كلمات البحث المخزنة ===='+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	CMJFpEZB6xcdYOmewVUbuiRjz = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if CMJFpEZB6xcdYOmewVUbuiRjz:
		CMJFpEZB6xcdYOmewVUbuiRjz = CMJFpEZB6xcdYOmewVUbuiRjz['__SEQUENCED_COLUMNS__']
		for JmMO69oYEwIj in reversed(CMJFpEZB6xcdYOmewVUbuiRjz):
			ygWIQGf25qwVxLkXrYDjp('folder',JmMO69oYEwIj,gby0BnUuTNFk,549,gby0BnUuTNFk,gby0BnUuTNFk,JmMO69oYEwIj)
	return
def a3NI0EopMZw(JmMO69oYEwIj):
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
		JmMO69oYEwIj = JmMO69oYEwIj.lower()
	dKZiTbEUxecXgBCD = JmMO69oYEwIj.replace(JB9fyoHr05QOtPjp,gby0BnUuTNFk)
	JJBxCjHYuZ6ifgasN70(dKZiTbEUxecXgBCD,'_ALL',True)
	ygWIQGf25qwVxLkXrYDjp('link','بحث جماعي للمواقع - '+dKZiTbEUxecXgBCD,'search_sites_all',542,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('folder','بحث منفرد للمواقع - '+dKZiTbEUxecXgBCD,gby0BnUuTNFk,541,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder','نتائج البحث مفصلة - '+dKZiTbEUxecXgBCD,'opened_sites_all',542,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	ygWIQGf25qwVxLkXrYDjp('folder','نتائج البحث مقسمة - '+dKZiTbEUxecXgBCD,'listed_sites_all',542,gby0BnUuTNFk,gby0BnUuTNFk,dKZiTbEUxecXgBCD)
	return
def JJBxCjHYuZ6ifgasN70(LSUrfDctHTCZw7qV4xWlRNEu6Qa,UrdXvmfG2V37nJkEBuQ1,iaTUJYnuW4Pj):
	if UrdXvmfG2V37nJkEBuQ1=='_ALL': YuVOHt97z08oLnD = '_GLS_'
	elif UrdXvmfG2V37nJkEBuQ1=='_GOOGLE': YuVOHt97z08oLnD = '_GOS_'
	zAy3NB6w0If8tGcXDr5LoT = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,LSUrfDctHTCZw7qV4xWlRNEu6Qa)
	u2kospaOCg3qFDXVG87hKAznQ1cNIP = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,YuVOHt97z08oLnD+LSUrfDctHTCZw7qV4xWlRNEu6Qa)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,LSUrfDctHTCZw7qV4xWlRNEu6Qa)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,YuVOHt97z08oLnD+LSUrfDctHTCZw7qV4xWlRNEu6Qa)
	pBn0Rqv5ZiAcQ9EaTUD8jPus = zAy3NB6w0If8tGcXDr5LoT+u2kospaOCg3qFDXVG87hKAznQ1cNIP
	if pBn0Rqv5ZiAcQ9EaTUD8jPus and iaTUJYnuW4Pj: LSUrfDctHTCZw7qV4xWlRNEu6Qa = YuVOHt97z08oLnD+LSUrfDctHTCZw7qV4xWlRNEu6Qa
	CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,LSUrfDctHTCZw7qV4xWlRNEu6Qa,pBn0Rqv5ZiAcQ9EaTUD8jPus,oHkZjQME4V1vhcUFtCPJ)
	return
def TvG3S2WbUjnpgZ7JA0rDc1zBVPmRo8(UrdXvmfG2V37nJkEBuQ1):
	PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if PpQu9EkGTxa!=1: return
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DETAILED'+UrdXvmfG2V37nJkEBuQ1)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DIVIDED'+UrdXvmfG2V37nJkEBuQ1)
	if UrdXvmfG2V37nJkEBuQ1=='_GOOGLE': dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GOOGLESEARCH_RESULTS')
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def V8R3ZQEmy2dPn0jokFJDCN(v3xy0D2PNYrX,gCNfhq2Pvdr,K6zNfZhw7njTIcgl1Q4YDp5Hqb=gby0BnUuTNFk,Gltzs1gB2kyuPWRSEQmw=cWH9rw1MqQ,JAi5kCfSWU9FXj1wqYLIPh6bQl={}):
	QJvajCsWY9SwmELIPGXiBzgbqZrhkO,oduLzG3HOAIsD0blB8Uk4TFnfm,oRLWyAlEHmgi8XNGjSTDhk,AXLUWnOPscpdF0l,QQAPWB1Gs3xdF5 = [],{},{},{},{}
	if '_all' in gCNfhq2Pvdr: UrdXvmfG2V37nJkEBuQ1,OwdMnetIWPCHxajY,YuVOHt97z08oLnD = '_ALL','_all','_GLS_'
	elif '_google' in gCNfhq2Pvdr: UrdXvmfG2V37nJkEBuQ1,OwdMnetIWPCHxajY,YuVOHt97z08oLnD = '_GOOGLE','_google','_GOS_'
	if gCNfhq2Pvdr in ['listed_sites'+OwdMnetIWPCHxajY,'opened_sites'+OwdMnetIWPCHxajY,'closed_sites'+OwdMnetIWPCHxajY]:
		if gCNfhq2Pvdr=='listed_sites'+OwdMnetIWPCHxajY: QJvajCsWY9SwmELIPGXiBzgbqZrhkO = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,YuVOHt97z08oLnD+v3xy0D2PNYrX)
		elif gCNfhq2Pvdr=='opened_sites'+OwdMnetIWPCHxajY: QJvajCsWY9SwmELIPGXiBzgbqZrhkO = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GLOBALSEARCH_DETAILED'+UrdXvmfG2V37nJkEBuQ1,v3xy0D2PNYrX)
		elif gCNfhq2Pvdr=='closed_sites'+OwdMnetIWPCHxajY: QJvajCsWY9SwmELIPGXiBzgbqZrhkO = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','GLOBALSEARCH_DIVIDED'+UrdXvmfG2V37nJkEBuQ1,(K6zNfZhw7njTIcgl1Q4YDp5Hqb,v3xy0D2PNYrX))
	if not QJvajCsWY9SwmELIPGXiBzgbqZrhkO:
		GThjqYb326ip1LcsD = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		fkAEpsvyhbeHlMtgr1nXNauO07CKZm = 'هل تريد الآن البحث في جميع المواقع عن \n "'+bKN9diGf8nmgecQPEqUzHRpoDuaO+UpN1CezytPO9XoduhxZSD+v3xy0D2PNYrX+UpN1CezytPO9XoduhxZSD+GGy0cQe765nPYZ9E8Th+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if gCNfhq2Pvdr=='search_sites'+OwdMnetIWPCHxajY: H7fCeh95oEyapvUl4itZDm2Njdx6z = fkAEpsvyhbeHlMtgr1nXNauO07CKZm
		else: H7fCeh95oEyapvUl4itZDm2Njdx6z = GThjqYb326ip1LcsD+fkAEpsvyhbeHlMtgr1nXNauO07CKZm
		PpQu9EkGTxa = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if PpQu9EkGTxa!=1: return
		zyZYjwM8GFn(qrejGtHg2Z,qrejGtHg2Z,qrejGtHg2Z)
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+'   Search For: [ '+v3xy0D2PNYrX+' ]')
		f18kpJFsxGhPCVlg4Ri5zdL3Eq = 1
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in Gltzs1gB2kyuPWRSEQmw:
			ooImkWy62CJafE = JAi5kCfSWU9FXj1wqYLIPh6bQl[gwiQ59eNbhY2SlLZB7aOpTDdsk1] if JAi5kCfSWU9FXj1wqYLIPh6bQl else v3xy0D2PNYrX
			try: DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			except: continue
			oduLzG3HOAIsD0blB8Uk4TFnfm[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = []
			N1FbhV4lx6QcWOo = '_NODIALOGS_'
			if '-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1: N1FbhV4lx6QcWOo = N1FbhV4lx6QcWOo+'_REMEMBERRESULTS__'+gwiQ59eNbhY2SlLZB7aOpTDdsk1+'_'
			if f18kpJFsxGhPCVlg4Ri5zdL3Eq:
				RyfYSek61do5OnQMc.sleep(0.75)
				QQAPWB1Gs3xdF5[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=A52cxoCyGIJdvbTLNnSFtlj70,args=(ooImkWy62CJafE+N1FbhV4lx6QcWOo,))
				QQAPWB1Gs3xdF5[gwiQ59eNbhY2SlLZB7aOpTDdsk1].start()
			else: A52cxoCyGIJdvbTLNnSFtlj70(ooImkWy62CJafE+N1FbhV4lx6QcWOo)
			RLfOB3nsqaWXTugJvY(hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1),gby0BnUuTNFk,RyfYSek61do5OnQMc=1000)
		if f18kpJFsxGhPCVlg4Ri5zdL3Eq:
			RyfYSek61do5OnQMc.sleep(2)
			for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in Gltzs1gB2kyuPWRSEQmw: QQAPWB1Gs3xdF5[gwiQ59eNbhY2SlLZB7aOpTDdsk1].join(10)
			RyfYSek61do5OnQMc.sleep(2)
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in Gltzs1gB2kyuPWRSEQmw:
			try: DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			except: continue
			for RqgVQfdsaDkCL in wAcHkmPB8a.menuItemsLIST:
				ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF = RqgVQfdsaDkCL
				if bcBlK1vyM5VaC2e in DPkEMfnRe82d:
					if 'IPTV-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and (239>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=230 or 289>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=280):
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['IPTV-LIVE']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['IPTV-MOVIES']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['IPTV-SERIES']: continue
						if 'صفحة' not in DPkEMfnRe82d:
							if   ZZrjMgRGiY2IDN7q=='live': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-LIVE'
							elif ZZrjMgRGiY2IDN7q=='video': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-MOVIES'
							elif ZZrjMgRGiY2IDN7q=='folder': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-SERIES'
						else:
							if   'LIVE' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-LIVE'
							elif 'MOVIES' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-MOVIES'
							elif 'SERIES' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IPTV-SERIES'
					elif 'M3U-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and 729>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=710:
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['M3U-LIVE']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['M3U-MOVIES']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['M3U-SERIES']: continue
						if 'صفحة' not in DPkEMfnRe82d:
							if   ZZrjMgRGiY2IDN7q=='live': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-LIVE'
							elif ZZrjMgRGiY2IDN7q=='video': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-MOVIES'
							elif ZZrjMgRGiY2IDN7q=='folder': gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-SERIES'
						else:
							if   'LIVE' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-LIVE'
							elif 'MOVIES' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-MOVIES'
							elif 'SERIES' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'M3U-SERIES'
					elif 'YOUTUBE-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and 149>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=140:
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['YOUTUBE-CHANNELS']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['YOUTUBE-PLAYLISTS']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in DPkEMfnRe82d or ':: ' in DPkEMfnRe82d:
							continue
						else:
							if   mi63FgbZoVerXaTGNhsUkuR0ILQW==144 and 'USER' in DPkEMfnRe82d: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'YOUTUBE-CHANNELS'
							elif mi63FgbZoVerXaTGNhsUkuR0ILQW==144 and 'CHNL' in DPkEMfnRe82d: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'YOUTUBE-CHANNELS'
							elif mi63FgbZoVerXaTGNhsUkuR0ILQW==144 and 'LIST' in DPkEMfnRe82d: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'YOUTUBE-PLAYLISTS'
							elif mi63FgbZoVerXaTGNhsUkuR0ILQW==143: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and 419>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=400:
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['DAILYMOTION-PLAYLISTS']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['DAILYMOTION-CHANNELS']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['DAILYMOTION-VIDEOS']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['DAILYMOTION-LIVES']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['DAILYMOTION-HASHTAGS']: continue
						if   mi63FgbZoVerXaTGNhsUkuR0ILQW in [401,405]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'DAILYMOTION-PLAYLISTS'
						elif mi63FgbZoVerXaTGNhsUkuR0ILQW in [402,406]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'DAILYMOTION-CHANNELS'
						elif mi63FgbZoVerXaTGNhsUkuR0ILQW in [404]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'DAILYMOTION-VIDEOS'
						elif mi63FgbZoVerXaTGNhsUkuR0ILQW in [415]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'DAILYMOTION-LIVES'
						elif mi63FgbZoVerXaTGNhsUkuR0ILQW in [416]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and 39>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=30:
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['PANET-SERIES']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['PANET-MOVIES']: continue
						if   mi63FgbZoVerXaTGNhsUkuR0ILQW in [32,39]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'PANET-SERIES'
						elif mi63FgbZoVerXaTGNhsUkuR0ILQW in [33,39]: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'PANET-MOVIES'
					elif 'IFILM-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1 and 29>=mi63FgbZoVerXaTGNhsUkuR0ILQW>=20:
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['IFILM-ARABIC']: continue
						if RqgVQfdsaDkCL in oduLzG3HOAIsD0blB8Uk4TFnfm['IFILM-ENGLISH']: continue
						if   '/ar.' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IFILM-ARABIC'
						elif '/en.' in UJeuWoLKP7ZI15O4ypTVs8caj: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = 'IFILM-ENGLISH'
					oduLzG3HOAIsD0blB8Uk4TFnfm[gwiQ59eNbhY2SlLZB7aOpTDdsk1].append(RqgVQfdsaDkCL)
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in list(oduLzG3HOAIsD0blB8Uk4TFnfm.keys()):
			oRLWyAlEHmgi8XNGjSTDhk[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = []
			AXLUWnOPscpdF0l[gwiQ59eNbhY2SlLZB7aOpTDdsk1] = []
			for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in oduLzG3HOAIsD0blB8Uk4TFnfm[gwiQ59eNbhY2SlLZB7aOpTDdsk1]:
				RqgVQfdsaDkCL = (ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
				if 'صفحة' in DPkEMfnRe82d and ZZrjMgRGiY2IDN7q=='folder': AXLUWnOPscpdF0l[gwiQ59eNbhY2SlLZB7aOpTDdsk1].append(RqgVQfdsaDkCL)
				else: oRLWyAlEHmgi8XNGjSTDhk[gwiQ59eNbhY2SlLZB7aOpTDdsk1].append(RqgVQfdsaDkCL)
		NNlVrYWSXMLPb,KULE98fh2YRHcdG04ZklVaXzv1iy = [],[]
		iarqh36w9VM = list(oRLWyAlEHmgi8XNGjSTDhk.keys())
		BGFSCc6fXDjPtyniZp = ynLAZbiodSG3QtgIJu2(iarqh36w9VM)
		GMVe5zIYFmLPw21ZkvEBo4y3cOd = []
		for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in BGFSCc6fXDjPtyniZp:
			if isinstance(gwiQ59eNbhY2SlLZB7aOpTDdsk1,tuple):
				GMVe5zIYFmLPw21ZkvEBo4y3cOd = [gwiQ59eNbhY2SlLZB7aOpTDdsk1]
				continue
			if gwiQ59eNbhY2SlLZB7aOpTDdsk1 not in Gltzs1gB2kyuPWRSEQmw: continue
			if oRLWyAlEHmgi8XNGjSTDhk[gwiQ59eNbhY2SlLZB7aOpTDdsk1]:
				fnptU3rOgWAMePzBGhCTiV = hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
				DwyJnCkAtZj7e1FLTHS36uoK = [('link',bKN9diGf8nmgecQPEqUzHRpoDuaO+'===== '+fnptU3rOgWAMePzBGhCTiV+' ====='+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk)]
				if 0: wt3Wrz57lYiQeOV4v = v3xy0D2PNYrX+' - '+'بحث'+UpN1CezytPO9XoduhxZSD+fnptU3rOgWAMePzBGhCTiV
				else: wt3Wrz57lYiQeOV4v = 'بحث'+UpN1CezytPO9XoduhxZSD+fnptU3rOgWAMePzBGhCTiV+' - '+v3xy0D2PNYrX
				if len(oRLWyAlEHmgi8XNGjSTDhk[gwiQ59eNbhY2SlLZB7aOpTDdsk1])<8: AmxohnHX7VERiu3JCYtz5 = []
				else:
					JZYs68AH20Uum5WDbLSrw = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+wt3Wrz57lYiQeOV4v+GGy0cQe765nPYZ9E8Th
					AmxohnHX7VERiu3JCYtz5 = [('folder',YuVOHt97z08oLnD+JZYs68AH20Uum5WDbLSrw,'closed_sites'+OwdMnetIWPCHxajY,542,gby0BnUuTNFk,gwiQ59eNbhY2SlLZB7aOpTDdsk1,v3xy0D2PNYrX,gby0BnUuTNFk,gby0BnUuTNFk)]
				jwBzTpIxgFZb7i = oRLWyAlEHmgi8XNGjSTDhk[gwiQ59eNbhY2SlLZB7aOpTDdsk1]+AXLUWnOPscpdF0l[gwiQ59eNbhY2SlLZB7aOpTDdsk1]
				HHMFsGXY3dV7xhPok = GMVe5zIYFmLPw21ZkvEBo4y3cOd+DwyJnCkAtZj7e1FLTHS36uoK+jwBzTpIxgFZb7i[:7]+AmxohnHX7VERiu3JCYtz5
				NNlVrYWSXMLPb += HHMFsGXY3dV7xhPok
				gglYQVJdBnKzIbmCNfy9Mp4 = [('folder',YuVOHt97z08oLnD+wt3Wrz57lYiQeOV4v,'closed_sites'+OwdMnetIWPCHxajY,542,gby0BnUuTNFk,gwiQ59eNbhY2SlLZB7aOpTDdsk1,v3xy0D2PNYrX,gby0BnUuTNFk,gby0BnUuTNFk)]
				W05rKpThjfMw6sJAxc2obSXG = GMVe5zIYFmLPw21ZkvEBo4y3cOd+gglYQVJdBnKzIbmCNfy9Mp4
				KULE98fh2YRHcdG04ZklVaXzv1iy += W05rKpThjfMw6sJAxc2obSXG
				CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DIVIDED'+UrdXvmfG2V37nJkEBuQ1,(gwiQ59eNbhY2SlLZB7aOpTDdsk1,v3xy0D2PNYrX),jwBzTpIxgFZb7i,oHkZjQME4V1vhcUFtCPJ)
				GMVe5zIYFmLPw21ZkvEBo4y3cOd = []
		CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_DETAILED'+UrdXvmfG2V37nJkEBuQ1,v3xy0D2PNYrX,NNlVrYWSXMLPb,oHkZjQME4V1vhcUFtCPJ)
		dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,v3xy0D2PNYrX)
		CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'GLOBALSEARCH_SPLITTED'+UrdXvmfG2V37nJkEBuQ1,YuVOHt97z08oLnD+v3xy0D2PNYrX,KULE98fh2YRHcdG04ZklVaXzv1iy,oHkZjQME4V1vhcUFtCPJ)
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		QJvajCsWY9SwmELIPGXiBzgbqZrhkO = KULE98fh2YRHcdG04ZklVaXzv1iy if gCNfhq2Pvdr=='listed_sites'+OwdMnetIWPCHxajY and KULE98fh2YRHcdG04ZklVaXzv1iy else NNlVrYWSXMLPb
	if gCNfhq2Pvdr in ['listed_sites'+OwdMnetIWPCHxajY,'opened_sites'+OwdMnetIWPCHxajY,'closed_sites'+OwdMnetIWPCHxajY]:
		for ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF in QJvajCsWY9SwmELIPGXiBzgbqZrhkO:
			if gCNfhq2Pvdr in ['listed_sites'+OwdMnetIWPCHxajY,'opened_sites'+OwdMnetIWPCHxajY] and 'صفحة' in DPkEMfnRe82d and ZZrjMgRGiY2IDN7q=='folder': continue
			ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,DPkEMfnRe82d,UJeuWoLKP7ZI15O4ypTVs8caj,mi63FgbZoVerXaTGNhsUkuR0ILQW,gQmur3iRSZ9IAOX,kdwXYDMQOjz51Z08W,fbmZ9V58PCTz,wH1a6KyFuLn,ZgSKTRL2DlPprjU57W93zf4EF)
	zyZYjwM8GFn(H14j5s97qxM,H14j5s97qxM,H14j5s97qxM)
	return
def CdzvFDU3hAekyxi5RSu0B8EbGqjIrf(search):
	BGFSCc6fXDjPtyniZp = ynLAZbiodSG3QtgIJu2(mVkdN4u5U7fSnF6z8TDI3q)
	for gwiQ59eNbhY2SlLZB7aOpTDdsk1 in BGFSCc6fXDjPtyniZp:
		if '-' in gwiQ59eNbhY2SlLZB7aOpTDdsk1: continue
		if isinstance(gwiQ59eNbhY2SlLZB7aOpTDdsk1,tuple):
			wAcHkmPB8a.menuItemsLIST.append(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
			continue
		DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
		name = hjtyidLuHrs3(gwiQ59eNbhY2SlLZB7aOpTDdsk1)+' - '+search
		ygWIQGf25qwVxLkXrYDjp('folder',bcBlK1vyM5VaC2e+name,gwiQ59eNbhY2SlLZB7aOpTDdsk1,548,'','',search)
	return
def kSDvJhmuOrIny(gwiQ59eNbhY2SlLZB7aOpTDdsk1,search):
	DeScCQAb5ti1ZxUPE,A52cxoCyGIJdvbTLNnSFtlj70,bcBlK1vyM5VaC2e = Lyqd0iExts5v6e7awzQuWM(gwiQ59eNbhY2SlLZB7aOpTDdsk1)
	A52cxoCyGIJdvbTLNnSFtlj70(search)
	return
def TVzJKmEdUj3s():
	tt3DVu1TU8dLAi('','',e1nNXbPrBVDZw,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def kDCWv2xtLFyTfM(v3xy0D2PNYrX=gby0BnUuTNFk):
	JmMO69oYEwIj,N1FbhV4lx6QcWOo,showDialogs = ZZV4kLG1nmbIjt(v3xy0D2PNYrX)
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
		JmMO69oYEwIj = JmMO69oYEwIj.lower()
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,FtPpevkmnBisyz1ouLTShElA7w(CC3nOPFMovd72u)+'   Search For: [ '+JmMO69oYEwIj+' ]')
	apTFWBhb175nwjvKtmJ2 = JmMO69oYEwIj+N1FbhV4lx6QcWOo
	if 0: I5fE04lszNgGrc9jOkXCmBixA8,dKZiTbEUxecXgBCD = JmMO69oYEwIj+' - ',gby0BnUuTNFk
	else: I5fE04lszNgGrc9jOkXCmBixA8,dKZiTbEUxecXgBCD = gby0BnUuTNFk,' - '+JmMO69oYEwIj
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'مواقع سيرفرات خاصة - قليلة المشاكل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,157)
	ygWIQGf25qwVxLkXrYDjp('folder','_M3U_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث M3U'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,719,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_IPT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث IPTV'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,239,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_BKR_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع بكرا'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,379,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_ART_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع تونز عربية'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,739,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_KRB_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع قناة كربلاء'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,329,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FH2_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فاصل الثاني'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,599,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_KTV_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع كتكوت تيفي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,819,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_EB1_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع ايجي بيست 1'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,779,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_EB2_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع ايجي بيست 2'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,789,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_IFL_'+I5fE04lszNgGrc9jOkXCmBixA8+'  بحث موقع قناة آي فيلم'+dKZiTbEUxecXgBCD+rBcdwYZInhgO29jtkFAfGxi7,gby0BnUuTNFk,29,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_AKO_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع أكوام القديم'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,79,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_AKW_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع أكوام الجديد'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,249,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_MRF_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع قناة المعارف'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,49,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SHM_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شوف ماكس'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,59,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,157)
	ygWIQGf25qwVxLkXrYDjp('folder','_LRZ_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع لاروزا'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,709,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FJS_'+I5fE04lszNgGrc9jOkXCmBixA8+' بحث موقع فجر شو'+dKZiTbEUxecXgBCD+UpN1CezytPO9XoduhxZSD,gby0BnUuTNFk,399,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_TVF_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع تيفي فان'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,469,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_LDN_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع لودي نت'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,459,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CMN_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما ناو'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,309,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SHN_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شاهد نيوز'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,589,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2+'_NODIALOGS_')
	ygWIQGf25qwVxLkXrYDjp('folder','_ARS_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع عرب سييد'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,259,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CCB_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما كلوب'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,829,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SH4_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شاهد فوريو'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,119,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2+'_NODIALOGS_')
	ygWIQGf25qwVxLkXrYDjp('folder','_SHT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شوفها تيفي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,649,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_WC1_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع وي سيما 1'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,569,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_WC2_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع وي سيما 2'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,1009,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'مواقع سيرفرات عامة - كثيرة المشاكل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,157)
	ygWIQGf25qwVxLkXrYDjp('folder','_TKT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع تكات'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,949,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FST_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فوستا'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,609,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FBK_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فبركة'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,629,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_YQT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع ياقوت'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,669,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SHB_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شبكتي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,969,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_VRB_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فاربون'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,879,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_BRS_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع برستيج'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,659,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_KRM_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع كرمالك'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,929,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_ANZ_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع انمي زد'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,979,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FSK_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فارسكو'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,999,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_HLC_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع هلا سيما'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,89,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_MST_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع المصطبة'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,869,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SNT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع شوف نت'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,849,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_DR7_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع دراما صح'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,689,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CFR_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما فري'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,839,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CMF_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما فانز'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,99,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CML_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما لايت'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,479,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_C4H_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما 400'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,699,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_ABD_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما عبدو'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,559,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_AKT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع اكوام تيوب'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,859,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_DCF_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع دراما كافيه'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,939,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FTV_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فوشار تيفي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,919,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_CWB_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما وبس'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,989,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_AHK_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع أهواك تيفي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,619,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_SRT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيريس تايم'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,899,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_FVD_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع فوشار فيديو'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,909,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_C4P_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع سيما فور بي'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,889,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_EB4_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع ايجي بيست 4'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,809,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'مواقع سيرفرات خاصة - قليلة المشاكل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,157)
	ygWIQGf25qwVxLkXrYDjp('folder','_YUT_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع يوتيوب'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,149,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	ygWIQGf25qwVxLkXrYDjp('folder','_DLM_'+I5fE04lszNgGrc9jOkXCmBixA8+'بحث موقع دايلي موشن'+dKZiTbEUxecXgBCD,gby0BnUuTNFk,409,gby0BnUuTNFk,gby0BnUuTNFk,apTFWBhb175nwjvKtmJ2)
	return