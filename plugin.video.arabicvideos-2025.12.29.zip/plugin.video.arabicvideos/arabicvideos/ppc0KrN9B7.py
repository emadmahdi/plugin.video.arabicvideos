# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'KATKOUTE'
JB9fyoHr05QOtPjp = '_KTK_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['الصفحة الرئيسية','Sign in','الأقسام']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==670: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==671: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==672: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==673: WjryKiBebavP = tHWd5iUKp0uBRESTL1FCAOGabsV(url,text)
	elif mode==674: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==679: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,679,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"navslide-divider"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,mode)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	items = BJeTzN8vSh(LhFnEIuPHdoNc+'/watch/browse.html')
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,674,T6TRUSbecYGWIq29KF)
	return
def BJeTzN8vSh(url):
	joAn4ETVPG81bXNRyHfBFiaxZgLs = hak2AysNmEcZ5xuKOptV(la983tXRDchGbrdIFQJf7kHeE,'list','KATKOUTE','CATEGORIES')
	if joAn4ETVPG81bXNRyHfBFiaxZgLs: return joAn4ETVPG81bXNRyHfBFiaxZgLs
	joAn4ETVPG81bXNRyHfBFiaxZgLs = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-CATEGORIES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"category-header"(.*?)<footer>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		joAn4ETVPG81bXNRyHfBFiaxZgLs = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if joAn4ETVPG81bXNRyHfBFiaxZgLs: CExrgJh48PYI2(la983tXRDchGbrdIFQJf7kHeE,'KATKOUTE','CATEGORIES',joAn4ETVPG81bXNRyHfBFiaxZgLs,Q3J7xTKDuAUoaPlB)
	return joAn4ETVPG81bXNRyHfBFiaxZgLs
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"caret"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('"presentation"','</ul>')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = [(gby0BnUuTNFk,AxiBv1cQueOs0)]
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' فرز أو فلتر أو ترتيب '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		for U4LRgsfMau2nr3Ay6WXqhkledw,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if U4LRgsfMau2nr3Ay6WXqhkledw: U4LRgsfMau2nr3Ay6WXqhkledw = U4LRgsfMau2nr3Ay6WXqhkledw+': '
			for SSqweDUBYv4bkO,title in items:
				title = U4LRgsfMau2nr3Ay6WXqhkledw+title
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,671)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-category-subcats"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)<30:
			ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			for SSqweDUBYv4bkO,title in items:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,671)
	if not l2Np9PfFqv4RcW7Y and not qsQxHTa4e0JYLUSKF7: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',url,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-TITLES-1st')
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-TITLES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	AxiBv1cQueOs0,items = gby0BnUuTNFk,[]
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((gby0BnUuTNFk,SSqweDUBYv4bkO,title))
	elif Z05rTiu6LwakteK8VfY=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-video-watch-featured"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_episodes':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_movies':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(QKqM0CwXDk8APOoJFpyntRb)>1: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[1]
	elif Z05rTiu6LwakteK8VfY=='featured_series':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((gby0BnUuTNFk,SSqweDUBYv4bkO,title))
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(data-echo=".*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if AxiBv1cQueOs0 and not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: return
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,672,T6TRUSbecYGWIq29KF)
		elif Z05rTiu6LwakteK8VfY=='new_episodes':
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,672,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,673,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movseries/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,671,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,673,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if SSqweDUBYv4bkO=='#': continue
			if 'http' not in SSqweDUBYv4bkO:
				Tf5ueYGZIFl1hraoEOVKi = url.rsplit('/',1)[0]
				SSqweDUBYv4bkO = Tf5ueYGZIFl1hraoEOVKi+'/'+SSqweDUBYv4bkO.strip('/')
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,671,gby0BnUuTNFk,gby0BnUuTNFk,Z05rTiu6LwakteK8VfY)
	return
def tHWd5iUKp0uBRESTL1FCAOGabsV(url,YYOman4GEXScVfjg89bRkDq):
	ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+'تشغيل الفيديو',url,672)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	joAn4ETVPG81bXNRyHfBFiaxZgLs = BJeTzN8vSh(LhFnEIuPHdoNc+'/watch/browse.html')
	TXNHlCWKd7Y,CZASUMs0Xt7WTGePqDaY5KlrRk3,c8SvDkfWdbJmMUa = zip(*joAn4ETVPG81bXNRyHfBFiaxZgLs)
	jjvrPu2xIqZ3OlD754TcXMQakNStE = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-EPISODES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-video-heading"(.*?)id="player"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vx14CNdbsZTz:
			if SSqweDUBYv4bkO not in TXNHlCWKd7Y:
				BoRk2n4aEtT3cKL08HPhUO = (SSqweDUBYv4bkO,title)
				jjvrPu2xIqZ3OlD754TcXMQakNStE.append(BoRk2n4aEtT3cKL08HPhUO)
		if len(jjvrPu2xIqZ3OlD754TcXMQakNStE)==1:
			SSqweDUBYv4bkO,title = jjvrPu2xIqZ3OlD754TcXMQakNStE[0]
			Xw3tTz8UD4LK26C(SSqweDUBYv4bkO,'new_episodes')
			return
		else:
			for SSqweDUBYv4bkO,title in jjvrPu2xIqZ3OlD754TcXMQakNStE:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,671,gby0BnUuTNFk,gby0BnUuTNFk,'new_episodes')
	if not jjvrPu2xIqZ3OlD754TcXMQakNStE: Xw3tTz8UD4LK26C(url,'new_episodes')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOUTE-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('sources:(.*?)flashplayer',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('file: "(.*?)".*?label: "(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,DYNVS1Bbgs7 in vx14CNdbsZTz:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named=__watch__'+DYNVS1Bbgs7
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embedded-video".*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not vx14CNdbsZTz: vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("file: '(.*?)'",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if vx14CNdbsZTz:
		SSqweDUBYv4bkO = vx14CNdbsZTz[0]
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=__embed')
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/watch/search.php?keywords='+search
	Xw3tTz8UD4LK26C(url,'search')
	return