# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
BZqfNTuc7nKbG1lh = 'IPTV'
IvnA0yjpu5HDFS9UOawMqcVW = '_IPT_'
JVs3roSjn5u = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def CHyR2EGvqzpWZB9cAU4jibkPo(mi63FgbZoVerXaTGNhsUkuR0ILQW,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,ZZrjMgRGiY2IDN7q,LL4W9eHQmsxZ,lFYCHgrx5oeBMkD):
	global IvnA0yjpu5HDFS9UOawMqcVW
	try:
		Z27widCyESA = str(lFYCHgrx5oeBMkD['folder'])
		IvnA0yjpu5HDFS9UOawMqcVW = '_IP'+Z27widCyESA+'_'
	except: Z27widCyESA = gby0BnUuTNFk
	if   mi63FgbZoVerXaTGNhsUkuR0ILQW==230: PgTIFSCwRY3haxjiok = VDtxLSPUFz0I5()
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==231: PgTIFSCwRY3haxjiok = BYRb8ALrn41jh7owmOH(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==232: PgTIFSCwRY3haxjiok = uj7O46p1qPsiHlyTKRtwe8N2(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==233: PgTIFSCwRY3haxjiok = MM6Qabwn2ecXOA3GK8pt5H(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==234: PgTIFSCwRY3haxjiok = O5XxuEh689Mvoq1Rnesl(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==235: PgTIFSCwRY3haxjiok = HthKAzX6MnLDiIF4aEC5sukp8WfJST(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,ZZrjMgRGiY2IDN7q)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==236: PgTIFSCwRY3haxjiok = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==237: PgTIFSCwRY3haxjiok = kewG0Bi9gt31hPAFJYoKHDznW(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==238: PgTIFSCwRY3haxjiok = v9vmA6lnP4kCywrZX(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==239: PgTIFSCwRY3haxjiok = H7l4URTtJj2ksaBQwb(fbmZ9V58PCTz,Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,LL4W9eHQmsxZ)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==280: PgTIFSCwRY3haxjiok = NZihe4G13VvS2WTXY9HLk07A(Z27widCyESA,True)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==281: PgTIFSCwRY3haxjiok = U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==282: PgTIFSCwRY3haxjiok = yuDs1JYf8vNxPawg3FOL(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==283: PgTIFSCwRY3haxjiok = KKVfL5U4qplP8Nh0Q(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==285: PgTIFSCwRY3haxjiok = LLkMBuX17Dgil2Oxw0fSY(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,fbmZ9V58PCTz)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==286: PgTIFSCwRY3haxjiok = ndHSJiu89yjKoQbgzWM4DG1BwCFE(Z27widCyESA)
	elif mi63FgbZoVerXaTGNhsUkuR0ILQW==289: PgTIFSCwRY3haxjiok = zzVD2aYBrXNtmGqwxcJ3eLTnIps(fbmZ9V58PCTz,Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,LL4W9eHQmsxZ)
	else: PgTIFSCwRY3haxjiok = False
	return PgTIFSCwRY3haxjiok
def VDtxLSPUFz0I5():
	for Z27widCyESA in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
		IvnA0yjpu5HDFS9UOawMqcVW = '_IP'+str(Z27widCyESA)+'_'
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قائمة مجلد '+XVANElz3tLn5pFPQUWi[Z27widCyESA],gby0BnUuTNFk,280,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	return
def NZihe4G13VvS2WTXY9HLk07A(Z27widCyESA=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=gby0BnUuTNFk):
	if Z27widCyESA:
		TTpnMa9HmbjORSl0qhZ5V68x1YJA7c = {'folder':Z27widCyESA}
		jyPnJKCVoqRL3b1hE2Zwdt5Q = gby0BnUuTNFk
	else:
		TTpnMa9HmbjORSl0qhZ5V68x1YJA7c = gby0BnUuTNFk
		jyPnJKCVoqRL3b1hE2Zwdt5Q = gby0BnUuTNFk
	FkcA2PCJuvWn = hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u)
	if not FkcA2PCJuvWn:
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+bKN9diGf8nmgecQPEqUzHRpoDuaO+' إضافة أو تغيير اشتراك'+jyPnJKCVoqRL3b1hE2Zwdt5Q+' '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,231,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+bKN9diGf8nmgecQPEqUzHRpoDuaO+' جلب ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q+' '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,232,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	else:
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'بحث في الملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,289,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_',gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة من القسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_FROM_GROUP_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة من الاسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_FROM_NAME_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مصنفة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_ORIGINAL_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مجهولة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_UNKNOWN_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'قنوات مجهولة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_UNKNOWN_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أفلام مصنفة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_MOVIES_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أفلام مصنفة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_MOVIES_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'مسلسلات مصنفة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_SERIES_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'مسلسلات مصنفة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_SERIES_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_ORIGINAL_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مصنفة من القسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_FROM_GROUP_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مصنفة من الاسم'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_FROM_NAME_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مجهولة بلا ترتيب'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_UNKNOWN_GROUPED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'فيديوهات مجهولة مرتبة'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'VOD_UNKNOWN_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'برامج القنوات (جدول فقط)'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_EPG_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أرشيف القنوات للأيام الماضية'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_TIMESHIFT_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أرشيف برامج القنوات للأيام الماضية'+jyPnJKCVoqRL3b1hE2Zwdt5Q,'LIVE_ARCHIVED_GROUPED_SORTED',233,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'إضافة أو تغيير اشتراك'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,231,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'جلب ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,232,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'مسح ملفات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,237,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'فحص اشتراك'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,236,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'عدد فيديوهات'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,281,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'Referer تغيير'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,286,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'User-Agent تغيير'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,283,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+'استخدم السيرفر الأسرع'+jyPnJKCVoqRL3b1hE2Zwdt5Q,gby0BnUuTNFk,282,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,TTpnMa9HmbjORSl0qhZ5V68x1YJA7c)
	return
def k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,N9bXKIfsDVPjctLM5u=True):
	vISfBo3dLZO5aX1Wbr8pQAyK9wuq,Ke4zLZ0qNpGcnmSg = False,gby0BnUuTNFk
	pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = gby0BnUuTNFk,gby0BnUuTNFk
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if h5iRdFc13nsYS2MjPLgfNyGCtx==gby0BnUuTNFk: return False,gby0BnUuTNFk,gby0BnUuTNFk
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	if QLsvCVdeuE:
		WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(rraWHLSwQvPlVROcM5YAJfF7ojh,'GET',QLsvCVdeuE,gby0BnUuTNFk,vO65KkJHupCrocdLe,False,gby0BnUuTNFk,'IPTV-CHECK_ACCOUNT-1st')
		LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
		if WeCU3qEsGrDNfh1tmXHVOZgPalK.succeeded:
			zJuHlOwIAR6vdQ1XaGVh2t8iE,aKy0b6OGmEjBX,KJRAebTL4ycph,qh329pGFD6zICYygSOxrb8QJ7vlTZ,o3RpjnUrFJ1 = 0,0,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
			try:
				daiRt93NpKI0hP8yTjcmYAMJlr6E = TqNUy3Z4SFWvplGwXC82A('dict',LviwW2t5HRmCMpxOqhDFo4d)
				Ke4zLZ0qNpGcnmSg = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['status']
				vISfBo3dLZO5aX1Wbr8pQAyK9wuq = True
				KJRAebTL4ycph = daiRt93NpKI0hP8yTjcmYAMJlr6E['server_info']['time_now']
			except: pass
			if KJRAebTL4ycph:
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.strptime(KJRAebTL4ycph,'%Y.%m.%d %H:%M:%S')
					zJuHlOwIAR6vdQ1XaGVh2t8iE = int(RyfYSek61do5OnQMc.mktime(pc31hyj70EoWbqH))
					aKy0b6OGmEjBX = int(X1X59MWmb8oBPDFCJARwcjONihTdeZ-zJuHlOwIAR6vdQ1XaGVh2t8iE)
					aKy0b6OGmEjBX = int((aKy0b6OGmEjBX+900)/1800)*1800
				except: pass
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['created_at']))
					qh329pGFD6zICYygSOxrb8QJ7vlTZ = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				except: pass
				try:
					pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['exp_date']))
					o3RpjnUrFJ1 = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				except: pass
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.timestamp_'+Z27widCyESA,str(X1X59MWmb8oBPDFCJARwcjONihTdeZ))
			SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.timediff_'+Z27widCyESA,str(aKy0b6OGmEjBX))
			try:
				TbwogIEGRSiB = '"server_info":'+LviwW2t5HRmCMpxOqhDFo4d.split('"server_info":')[1]
				TbwogIEGRSiB = TbwogIEGRSiB.replace(':',': ').replace(',',', ').replace('}}','}')
				rrgxdszNbZP = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"url": "(.*?)", "port": "(.*?)"',TbwogIEGRSiB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = rrgxdszNbZP[0]
			except: vISfBo3dLZO5aX1Wbr8pQAyK9wuq = False
			if vISfBo3dLZO5aX1Wbr8pQAyK9wuq and N9bXKIfsDVPjctLM5u:
				max = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['max_connections']
				pUoWcN32m5lxQSBfTRvV7EsGn = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['active_cons']
				HUFhC3cWSMBQxvrymno = daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['is_trial']
				ZZU08dwLBRN3VKEJk4eip9 = QLsvCVdeuE.split('?',1)
				H7fCeh95oEyapvUl4itZDm2Njdx6z = 'URL:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+QLsvCVdeuE+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\nStatus:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+Ke4zLZ0qNpGcnmSg+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nTrial:    '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+str(HUFhC3cWSMBQxvrymno=='1')+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nCreated  At:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+qh329pGFD6zICYygSOxrb8QJ7vlTZ+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nExpiry Date:  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+o3RpjnUrFJ1+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nConnections   ( Active / Maximum ) :  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+pUoWcN32m5lxQSBfTRvV7EsGn+' / '+max+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\nAllowed Outputs:   '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+" , ".join(daiRt93NpKI0hP8yTjcmYAMJlr6E['user_info']['allowed_output_formats'])+GGy0cQe765nPYZ9E8Th
				H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+TbwogIEGRSiB
				if Ke4zLZ0qNpGcnmSg=='Active': YNX5nvi2VegTUu('الاشتراك يعمل بدون مشاكل',H7fCeh95oEyapvUl4itZDm2Njdx6z)
				else: YNX5nvi2VegTUu('يبدو أن هناك مشكلة في الاشتراك',H7fCeh95oEyapvUl4itZDm2Njdx6z)
	if QLsvCVdeuE and vISfBo3dLZO5aX1Wbr8pQAyK9wuq and Ke4zLZ0qNpGcnmSg=='Active':
		SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+QLsvCVdeuE+' ]')
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV = True
	else:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,'Checking IPTV URL   [ Does not work ]   [ '+QLsvCVdeuE+' ]')
		if N9bXKIfsDVPjctLM5u: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV = False
	return ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs
def O5XxuEh689Mvoq1Rnesl(Z27widCyESA,kVGU1uhays3EWfH,THmdqUzOsy,UwrnXuFkvEh9xRs5Z1,N9bXKIfsDVPjctLM5u=True):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',kVGU1uhays3EWfH,THmdqUzOsy)
	AH7qJLzK53xXvyC = int(UwrnXuFkvEh9xRs5Z1)*100
	NqOeKYDRCJX8rgaQLzA3FZ = AH7qJLzK53xXvyC-100
	for EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in T7hyMuvVz9EqkOasZDSJ[NqOeKYDRCJX8rgaQLzA3FZ:AH7qJLzK53xXvyC]:
		S3NTGxMIWYUHb68Ojy = ('GROUPED' in kVGU1uhays3EWfH or kVGU1uhays3EWfH=='ALL')
		JDhbLFOd9xEkpWjzcsC = ('GROUPED' not in kVGU1uhays3EWfH and kVGU1uhays3EWfH!='ALL')
		if S3NTGxMIWYUHb68Ojy or JDhbLFOd9xEkpWjzcsC:
			if   'ARCHIVED'  in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,238,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'ARCHIVED',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'EPG' 		 in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,238,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'FULL_EPG',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'TIMESHIFT' in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,238,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,'TIMESHIFT',gby0BnUuTNFk,{'folder':Z27widCyESA}])
			elif 'LIVE' 	 in kVGU1uhays3EWfH: wAcHkmPB8a.menuItemsLIST.append(['live',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,235,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,EyvQhYU4jZoGuwtW7M9JXb,{'folder':Z27widCyESA}])
			else: wAcHkmPB8a.menuItemsLIST.append(['video',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,235,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA}])
	LbeM6usxzdNjYTXJ7iOoKEDgAkHf = len(T7hyMuvVz9EqkOasZDSJ)
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,234,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,THmdqUzOsy)
	return
def DCPtLSv0hURE4(pRajc0eY57W9HhZlfBNQOgwsyGC):
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'هذه القائمة إما فارغة أو غير موجودة',gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'أو الخدمة غير موجودة في اشتراكك',gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('link',pRajc0eY57W9HhZlfBNQOgwsyGC+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',gby0BnUuTNFk,9999)
	return
def MM6Qabwn2ecXOA3GK8pt5H(Z27widCyESA,kVGU1uhays3EWfH,THmdqUzOsy,UwrnXuFkvEh9xRs5Z1,XPmvhy6V1DcY5FQ=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=True):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	pRajc0eY57W9HhZlfBNQOgwsyGC = IvnA0yjpu5HDFS9UOawMqcVW
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return False
	if '__SERIES__' in THmdqUzOsy: ByvjFKdQ7orCEhqxpleRb5zU64aO,mJzQDOXswYUAR4o9Ce2g = THmdqUzOsy.split('__SERIES__')
	else: ByvjFKdQ7orCEhqxpleRb5zU64aO,mJzQDOXswYUAR4o9Ce2g = THmdqUzOsy,gby0BnUuTNFk
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	wrRZTAy34jL7h0oeVlN1zx = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',kVGU1uhays3EWfH,'__GROUPS__')
	if not wrRZTAy34jL7h0oeVlN1zx: return False
	g1NebzFUpmEhjDRyB56cvHAKV = []
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in wrRZTAy34jL7h0oeVlN1zx:
		if XPmvhy6V1DcY5FQ:
			if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: pRajc0eY57W9HhZlfBNQOgwsyGC = 'SERIES'
			elif '!!__UNKNOWN__!!' in r9rIzYVD0ceyC1uUofpPJF45tWbR: pRajc0eY57W9HhZlfBNQOgwsyGC = 'UNKNOWN'
			elif 'LIVE' in kVGU1uhays3EWfH: pRajc0eY57W9HhZlfBNQOgwsyGC = 'LIVE'
			else: pRajc0eY57W9HhZlfBNQOgwsyGC = 'VIDEOS'
			pRajc0eY57W9HhZlfBNQOgwsyGC = ','+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+pRajc0eY57W9HhZlfBNQOgwsyGC+': '+GGy0cQe765nPYZ9E8Th
		if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')
		else: KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk
		if not THmdqUzOsy:
			if KVxLWm5201GJnaIElF8ASUi in g1NebzFUpmEhjDRyB56cvHAKV: continue
			g1NebzFUpmEhjDRyB56cvHAKV.append(KVxLWm5201GJnaIElF8ASUi)
			if 'RANDOM' in XPmvhy6V1DcY5FQ: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,167,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			elif '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,233,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+KVxLWm5201GJnaIElF8ASUi,kVGU1uhays3EWfH,234,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
		elif '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR and KVxLWm5201GJnaIElF8ASUi==ByvjFKdQ7orCEhqxpleRb5zU64aO:
			if Nd0fkcwTIV2JhMLxKbD7Go1e9A in g1NebzFUpmEhjDRyB56cvHAKV: continue
			g1NebzFUpmEhjDRyB56cvHAKV.append(Nd0fkcwTIV2JhMLxKbD7Go1e9A)
			if 'RANDOM' in XPmvhy6V1DcY5FQ: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+Nd0fkcwTIV2JhMLxKbD7Go1e9A,kVGU1uhays3EWfH,167,gby0BnUuTNFk,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('folder',pRajc0eY57W9HhZlfBNQOgwsyGC+Nd0fkcwTIV2JhMLxKbD7Go1e9A,kVGU1uhays3EWfH,234,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
	wAcHkmPB8a.menuItemsLIST[:] = sorted(wAcHkmPB8a.menuItemsLIST,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1].lower())
	if not XPmvhy6V1DcY5FQ:
		AH7qJLzK53xXvyC = int(UwrnXuFkvEh9xRs5Z1)*100
		NqOeKYDRCJX8rgaQLzA3FZ = AH7qJLzK53xXvyC-100
		LbeM6usxzdNjYTXJ7iOoKEDgAkHf = len(wAcHkmPB8a.menuItemsLIST)
		wAcHkmPB8a.menuItemsLIST[:] = wAcHkmPB8a.menuItemsLIST[NqOeKYDRCJX8rgaQLzA3FZ:AH7qJLzK53xXvyC]
		mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,233,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,THmdqUzOsy)
	return True
def v9vmA6lnP4kCywrZX(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,lg6ihPJLUQc9zDw2M47f):
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,True): return
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	zJuHlOwIAR6vdQ1XaGVh2t8iE = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.timestamp_'+Z27widCyESA)
	if not zJuHlOwIAR6vdQ1XaGVh2t8iE or X1X59MWmb8oBPDFCJARwcjONihTdeZ-int(zJuHlOwIAR6vdQ1XaGVh2t8iE)>24*InYGW7Ad2QRM9rUblmh6:
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,False)
		if not ww8aEQ9UGz1ms3qOeXvDkfFMTdV: return
	aKy0b6OGmEjBX = int(SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.timediff_'+Z27widCyESA))
	OTl0DRFHNiA = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.server_'+Z27widCyESA)
	h5iRdFc13nsYS2MjPLgfNyGCtx = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.username_'+Z27widCyESA)
	CKTBLx2pOZDrzXqj3Qcea = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.password_'+Z27widCyESA)
	tSfK8LmoT1zq6N = UJeuWoLKP7ZI15O4ypTVs8caj.split('/')
	j05Lq8fUVz9kuJEh4 = tSfK8LmoT1zq6N[-1].replace('.ts',gby0BnUuTNFk).replace('.m3u8',gby0BnUuTNFk)
	if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG': uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5 = 'get_short_epg'
	else: uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5 = 'get_simple_data_table'
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx: return
	l5hvSZxnX8JK1DE9d = QLsvCVdeuE+'&action='+uEpkVnqUhi0ctRjWaP1L9yl3ZIwCY5+'&stream_id='+j05Lq8fUVz9kuJEh4
	LviwW2t5HRmCMpxOqhDFo4d = mmQHlVdqUY8w9uEIfBhyaNRW6At(rraWHLSwQvPlVROcM5YAJfF7ojh,l5hvSZxnX8JK1DE9d,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,'IPTV-EPG_ITEMS-2nd')
	IsXSAK45YWg = TqNUy3Z4SFWvplGwXC82A('dict',LviwW2t5HRmCMpxOqhDFo4d)
	SsDvZrLyicd5g9B = IsXSAK45YWg['epg_listings']
	R1OdQ7V9q6fNbl0piLKXhjyBmY = []
	if lg6ihPJLUQc9zDw2M47f in ['ARCHIVED','TIMESHIFT']:
		for daiRt93NpKI0hP8yTjcmYAMJlr6E in SsDvZrLyicd5g9B:
			if daiRt93NpKI0hP8yTjcmYAMJlr6E['has_archive']==1:
				R1OdQ7V9q6fNbl0piLKXhjyBmY.append(daiRt93NpKI0hP8yTjcmYAMJlr6E)
				if lg6ihPJLUQc9zDw2M47f in ['TIMESHIFT']: break
		if not R1OdQ7V9q6fNbl0piLKXhjyBmY: return
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'الملفات الأولي بهذه القائمة قد لا تعمل'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		if lg6ihPJLUQc9zDw2M47f in ['TIMESHIFT']:
			rrwkvIfat8 = 2
			fJVzyHRjtD3GEZWaKF = rrwkvIfat8*InYGW7Ad2QRM9rUblmh6
			R1OdQ7V9q6fNbl0piLKXhjyBmY = []
			aZhJstwokBcRT = int(int(daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'])/fJVzyHRjtD3GEZWaKF)*fJVzyHRjtD3GEZWaKF
			B5Pq1nguoCSdRUHYDEikIht2cX = X1X59MWmb8oBPDFCJARwcjONihTdeZ+fJVzyHRjtD3GEZWaKF
			Gw6TXC0pbjHx8tD7FknVgIqN12O3Ur = int((B5Pq1nguoCSdRUHYDEikIht2cX-aZhJstwokBcRT)/InYGW7Ad2QRM9rUblmh6)
			for aGmyTsKY0IECMSN in range(Gw6TXC0pbjHx8tD7FknVgIqN12O3Ur):
				if aGmyTsKY0IECMSN>=6:
					if aGmyTsKY0IECMSN%rrwkvIfat8!=0: continue
					wb1hXv8tps32eNGdgmTHqLUCVuZ = fJVzyHRjtD3GEZWaKF
				else: wb1hXv8tps32eNGdgmTHqLUCVuZ = fJVzyHRjtD3GEZWaKF//2
				Yhg8svjWFpuzoI7mxHEn = aZhJstwokBcRT+aGmyTsKY0IECMSN*InYGW7Ad2QRM9rUblmh6
				daiRt93NpKI0hP8yTjcmYAMJlr6E = {}
				daiRt93NpKI0hP8yTjcmYAMJlr6E['title'] = gby0BnUuTNFk
				pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(Yhg8svjWFpuzoI7mxHEn-aKy0b6OGmEjBX-InYGW7Ad2QRM9rUblmh6)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['start'] = RyfYSek61do5OnQMc.strftime('%Y.%m.%d %H:%M:%S',pc31hyj70EoWbqH)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'] = str(Yhg8svjWFpuzoI7mxHEn)
				daiRt93NpKI0hP8yTjcmYAMJlr6E['stop_timestamp'] = str(Yhg8svjWFpuzoI7mxHEn+wb1hXv8tps32eNGdgmTHqLUCVuZ)
				R1OdQ7V9q6fNbl0piLKXhjyBmY.append(daiRt93NpKI0hP8yTjcmYAMJlr6E)
	elif lg6ihPJLUQc9zDw2M47f in ['SHORT_EPG','FULL_EPG']: R1OdQ7V9q6fNbl0piLKXhjyBmY = SsDvZrLyicd5g9B
	if lg6ihPJLUQc9zDw2M47f=='FULL_EPG' and len(R1OdQ7V9q6fNbl0piLKXhjyBmY)>0:
		ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'هذه قائمة برامج القنوات (جدول فقط)ـ'+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	OXjlDar5kLY30EuvUehgcGJW = []
	Eoyrc5lpZQdsfbq3jtzSWhxKUGM = oKew16fsvuV8.getInfoLabel('ListItem.Icon')
	for daiRt93NpKI0hP8yTjcmYAMJlr6E in R1OdQ7V9q6fNbl0piLKXhjyBmY:
		oGVqE4JR3DIcTNtAghW9 = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(daiRt93NpKI0hP8yTjcmYAMJlr6E['title'])
		if nqkybtoMBH: oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.decode(JJQFjSIlALchiMzG9)
		Yhg8svjWFpuzoI7mxHEn = int(daiRt93NpKI0hP8yTjcmYAMJlr6E['start_timestamp'])
		PtLb1QyIas7kjTr2fUDuVCB = int(daiRt93NpKI0hP8yTjcmYAMJlr6E['stop_timestamp'])
		RRiY2n6EfZJUbhlQ = str(int((PtLb1QyIas7kjTr2fUDuVCB-Yhg8svjWFpuzoI7mxHEn+59)/60))
		YtG8N1esIZ4V9ajHcm = daiRt93NpKI0hP8yTjcmYAMJlr6E['start'].replace(UpN1CezytPO9XoduhxZSD,':')
		pc31hyj70EoWbqH = RyfYSek61do5OnQMc.localtime(Yhg8svjWFpuzoI7mxHEn-InYGW7Ad2QRM9rUblmh6)
		dSlYHKcVCaWJyGfFIriDQx4Mt1gz = RyfYSek61do5OnQMc.strftime('%H:%M',pc31hyj70EoWbqH)
		YSvhQcmiRJXp7za5y = RyfYSek61do5OnQMc.strftime('%a',pc31hyj70EoWbqH)
		if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG': oGVqE4JR3DIcTNtAghW9 = bKN9diGf8nmgecQPEqUzHRpoDuaO+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ـ '+oGVqE4JR3DIcTNtAghW9+GGy0cQe765nPYZ9E8Th
		elif lg6ihPJLUQc9zDw2M47f=='TIMESHIFT': oGVqE4JR3DIcTNtAghW9 = YSvhQcmiRJXp7za5y+UpN1CezytPO9XoduhxZSD+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ('+RRiY2n6EfZJUbhlQ+'min)'
		else: oGVqE4JR3DIcTNtAghW9 = YSvhQcmiRJXp7za5y+UpN1CezytPO9XoduhxZSD+dSlYHKcVCaWJyGfFIriDQx4Mt1gz+' ('+RRiY2n6EfZJUbhlQ+'min)   '+oGVqE4JR3DIcTNtAghW9+' ـ'
		if lg6ihPJLUQc9zDw2M47f in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			xar2BQHqiEIGc = OTl0DRFHNiA+'/timeshift/'+h5iRdFc13nsYS2MjPLgfNyGCtx+'/'+CKTBLx2pOZDrzXqj3Qcea+'/'+RRiY2n6EfZJUbhlQ+'/'+YtG8N1esIZ4V9ajHcm+'/'+j05Lq8fUVz9kuJEh4+'.m3u8'
			if lg6ihPJLUQc9zDw2M47f=='FULL_EPG': ygWIQGf25qwVxLkXrYDjp('link',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,xar2BQHqiEIGc,9999,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
			else: ygWIQGf25qwVxLkXrYDjp('video',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,xar2BQHqiEIGc,235,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
		OXjlDar5kLY30EuvUehgcGJW.append(oGVqE4JR3DIcTNtAghW9)
	if lg6ihPJLUQc9zDw2M47f=='SHORT_EPG' and OXjlDar5kLY30EuvUehgcGJW: YnUKjTgtHOaGZvkhD = MMgdej0E4XIrLa1bhxPQZJlB2Um(OXjlDar5kLY30EuvUehgcGJW)
	return OXjlDar5kLY30EuvUehgcGJW
def yuDs1JYf8vNxPawg3FOL(Z27widCyESA):
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,True): return
	OTl0DRFHNiA,zUGXJsLTlVpfF5EW,VjnOqSAvDyT = gby0BnUuTNFk,0,0
	ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,False)
	if ww8aEQ9UGz1ms3qOeXvDkfFMTdV:
		Y26Vib51mSIuMR0EAN8n = ElRUG8zKHm(pEdJtk92IBfq80N)
		zUGXJsLTlVpfF5EW = Xa2nju83yQLEKgMhC65PbcqzIRJ(Y26Vib51mSIuMR0EAN8n[0],int(Lt5J47xrFw9KRulCoVs))
		WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'LIVE_GROUPED')
		qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','LIVE_GROUPED')
		T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','LIVE_GROUPED',qleCEa50kOYvVNSJuDP1R4FdhtoIxw[1])
		UJeuWoLKP7ZI15O4ypTVs8caj = T7hyMuvVz9EqkOasZDSJ[0][2]
		msk1z4hY6ELvtP0H9jIfrW5JV = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('://(.*?)/',UJeuWoLKP7ZI15O4ypTVs8caj,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		msk1z4hY6ELvtP0H9jIfrW5JV = msk1z4hY6ELvtP0H9jIfrW5JV[0]
		if ':' in msk1z4hY6ELvtP0H9jIfrW5JV: vKXUiA1H2MgFla,OOaoAqWUK0h8xsIzu = msk1z4hY6ELvtP0H9jIfrW5JV.split(':')
		else: vKXUiA1H2MgFla,OOaoAqWUK0h8xsIzu = msk1z4hY6ELvtP0H9jIfrW5JV,'80'
		ntxkEmo013pWOe8r7QdKY2XjUARVbZ = ElRUG8zKHm(vKXUiA1H2MgFla)
		VjnOqSAvDyT = Xa2nju83yQLEKgMhC65PbcqzIRJ(ntxkEmo013pWOe8r7QdKY2XjUARVbZ[0],int(OOaoAqWUK0h8xsIzu))
	if zUGXJsLTlVpfF5EW and VjnOqSAvDyT:
		H7fCeh95oEyapvUl4itZDm2Njdx6z = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+'وقت ضائع في السيرفر الأصلي'+okfdjS4RmM+str(int(VjnOqSAvDyT*1000))+' ملي ثانية'
		H7fCeh95oEyapvUl4itZDm2Njdx6z += '\n\n'+'وقت ضائع في السيرفر البديل'+okfdjS4RmM+str(int(zUGXJsLTlVpfF5EW*1000))+' ملي ثانية'
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center','السيرفر الأصلي','السيرفر الأسرع',e1nNXbPrBVDZw,H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if BeU98noROVkGhHqN15fumPCvyWQcxJ==1 and zUGXJsLTlVpfF5EW<VjnOqSAvDyT: OTl0DRFHNiA = pEdJtk92IBfq80N+':'+Lt5J47xrFw9KRulCoVs
	else: tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'البرنامج لم يجد السيرفر البديل')
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.server_'+Z27widCyESA,OTl0DRFHNiA)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(Z27widCyESA,UJeuWoLKP7ZI15O4ypTVs8caj,ZZrjMgRGiY2IDN7q):
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.useragent_'+Z27widCyESA)
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.referer_'+Z27widCyESA)
	if Z38Zes0IBSDYCLPGJfM6j or vBJn6DgVPG7sqoprY:
		UJeuWoLKP7ZI15O4ypTVs8caj += '|'
		if Z38Zes0IBSDYCLPGJfM6j: UJeuWoLKP7ZI15O4ypTVs8caj += '&User-Agent='+Z38Zes0IBSDYCLPGJfM6j
		if vBJn6DgVPG7sqoprY: UJeuWoLKP7ZI15O4ypTVs8caj += '&Referer='+vBJn6DgVPG7sqoprY
		UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace('|&','|')
	cqmvx2AlHfWEwDgVbd = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.server_'+Z27widCyESA)
	if cqmvx2AlHfWEwDgVbd:
		wwb2Q5GDrRpOCTxVZFN41UntzL = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('://(.*?)/',UJeuWoLKP7ZI15O4ypTVs8caj,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace(wwb2Q5GDrRpOCTxVZFN41UntzL[0],cqmvx2AlHfWEwDgVbd)
	YAQOL1eVvqMjsEfIFc(UJeuWoLKP7ZI15O4ypTVs8caj,BZqfNTuc7nKbG1lh,ZZrjMgRGiY2IDN7q)
	return
def KKVfL5U4qplP8Nh0Q(Z27widCyESA):
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.useragent_'+Z27widCyESA)
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center','استخدام الأصلي','تعديل القديم',Z38Zes0IBSDYCLPGJfM6j,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if U6aeROxVWpCbY18==1: Z38Zes0IBSDYCLPGJfM6j = vRoGedUjt2Ac6pIbufBX8sKy('أكتب ـIPTV User-Agent جديد',Z38Zes0IBSDYCLPGJfM6j,True)
	else: Z38Zes0IBSDYCLPGJfM6j = 'Unknown'
	if Z38Zes0IBSDYCLPGJfM6j==UpN1CezytPO9XoduhxZSD:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,Z38Zes0IBSDYCLPGJfM6j,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if U6aeROxVWpCbY18!=1:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
		return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.useragent_'+Z27widCyESA,Z38Zes0IBSDYCLPGJfM6j)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def ndHSJiu89yjKoQbgzWM4DG1BwCFE(Z27widCyESA):
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.referer_'+Z27widCyESA)
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center','استخدام الأصلي','تعديل القديم',vBJn6DgVPG7sqoprY,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if U6aeROxVWpCbY18==1: vBJn6DgVPG7sqoprY = vRoGedUjt2Ac6pIbufBX8sKy('أكتب ـIPTV Referer جديد',vBJn6DgVPG7sqoprY,True)
	else: vBJn6DgVPG7sqoprY = gby0BnUuTNFk
	if vBJn6DgVPG7sqoprY==UpN1CezytPO9XoduhxZSD:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,vBJn6DgVPG7sqoprY,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if U6aeROxVWpCbY18!=1:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
		return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.referer_'+Z27widCyESA,vBJn6DgVPG7sqoprY)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def beDTGt1QHSI7Pul9BfOcC(Z27widCyESA,ofdxgFDnIXulGr8KO=gby0BnUuTNFk):
	if not ofdxgFDnIXulGr8KO: ofdxgFDnIXulGr8KO = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.url_'+Z27widCyESA)
	OTl0DRFHNiA = mDR9euKnv4jMSdbEpwcktJz5W6Cf(ofdxgFDnIXulGr8KO,'url')
	h5iRdFc13nsYS2MjPLgfNyGCtx = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('username=(.*?)&',ofdxgFDnIXulGr8KO+'&',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	CKTBLx2pOZDrzXqj3Qcea = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('password=(.*?)&',ofdxgFDnIXulGr8KO+'&',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx or not CKTBLx2pOZDrzXqj3Qcea:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk
	h5iRdFc13nsYS2MjPLgfNyGCtx = h5iRdFc13nsYS2MjPLgfNyGCtx[0]
	CKTBLx2pOZDrzXqj3Qcea = CKTBLx2pOZDrzXqj3Qcea[0]
	QLsvCVdeuE = OTl0DRFHNiA+'/player_api.php?username='+h5iRdFc13nsYS2MjPLgfNyGCtx+'&password='+CKTBLx2pOZDrzXqj3Qcea
	y5Cv1XOeJmLa4zDr = OTl0DRFHNiA+'/get.php?username='+h5iRdFc13nsYS2MjPLgfNyGCtx+'&password='+CKTBLx2pOZDrzXqj3Qcea+'&type=m3u_plus'
	return QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea
def BX9HfPAtyJcwC7noM5uphFa2l(Z27widCyESA,Ugkved5DSE8ZpLVrA4GXoRN=gby0BnUuTNFk):
	P9PI1QNFzMEDk = Ugkved5DSE8ZpLVrA4GXoRN.replace('/','_').replace(':','_').replace('.','_')
	P9PI1QNFzMEDk = P9PI1QNFzMEDk.replace('?','_').replace('=','_').replace('&','_')
	P9PI1QNFzMEDk = bCoOHfPdMryRgauz0IVpth.path.join(jjzt6rqdQKM,P9PI1QNFzMEDk).strip('.m3u')+'.m3u'
	return P9PI1QNFzMEDk
def BYRb8ALrn41jh7owmOH(Z27widCyESA):
	Y8Ap23QdsDbG = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.url_'+Z27widCyESA)
	vvRr5jB1A4oqhYwd3HILWCQbF = True
	if Y8Ap23QdsDbG:
		U6aeROxVWpCbY18 = yc8Ph4rFsCIvQbOA('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+Y8Ap23QdsDbG+GGy0cQe765nPYZ9E8Th+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if U6aeROxVWpCbY18==-1: return
		elif U6aeROxVWpCbY18==0: Y8Ap23QdsDbG = gby0BnUuTNFk
		elif U6aeROxVWpCbY18==2:
			U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if U6aeROxVWpCbY18 in [-1,0]: return
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح الرابط')
			vvRr5jB1A4oqhYwd3HILWCQbF = False
			UFrX7jqQmYZlMv8zdPbpNSV = gby0BnUuTNFk
	if vvRr5jB1A4oqhYwd3HILWCQbF:
		UFrX7jqQmYZlMv8zdPbpNSV = vRoGedUjt2Ac6pIbufBX8sKy('اكتب رابط ـIPTV كاملا',Y8Ap23QdsDbG)
		UFrX7jqQmYZlMv8zdPbpNSV = UFrX7jqQmYZlMv8zdPbpNSV.strip(UpN1CezytPO9XoduhxZSD)
		if not UFrX7jqQmYZlMv8zdPbpNSV:
			U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if U6aeROxVWpCbY18 in [-1,0]: return
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح الرابط')
	else:
		QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA,UFrX7jqQmYZlMv8zdPbpNSV)
		if not h5iRdFc13nsYS2MjPLgfNyGCtx: return
		H7fCeh95oEyapvUl4itZDm2Njdx6z = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+OTl0DRFHNiA+GGy0cQe765nPYZ9E8Th+'عنوان السيرفر: '
		H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+h5iRdFc13nsYS2MjPLgfNyGCtx+GGy0cQe765nPYZ9E8Th+'اسم المستخدم: '
		H7fCeh95oEyapvUl4itZDm2Njdx6z += okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+y1qVOPURM9g++'كلمة السر: '
		U6aeROxVWpCbY18 = c3iHohf1zAFQjtTV20pPlS('right',gby0BnUuTNFk,gby0BnUuTNFk,'الرابط الجديد هو:',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+UFrX7jqQmYZlMv8zdPbpNSV+GGy0cQe765nPYZ9E8Th+'\n\n'+H7fCeh95oEyapvUl4itZDm2Njdx6z)
		if U6aeROxVWpCbY18!=1:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم الإلغاء')
			return
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.url_'+Z27widCyESA,UFrX7jqQmYZlMv8zdPbpNSV)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.timestamp_'+Z27widCyESA,gby0BnUuTNFk)
	SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.timediff_'+Z27widCyESA,gby0BnUuTNFk)
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.useragent_'+Z27widCyESA)
	if not Z38Zes0IBSDYCLPGJfM6j: SF3Htydw7Y5sgjIE0OrLTKoQ.setSetting('av.iptv.useragent_'+Z27widCyESA,'Unknown')
	jzt2ChYkVdlWS76MZNXp3ayU = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,UFrX7jqQmYZlMv8zdPbpNSV+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if jzt2ChYkVdlWS76MZNXp3ayU==1: ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,True)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	return
def T5tyHdWREw2kJ(uA0Ja8qPSW9,BAVbEI0J5XxG,jjLJvOMTAEy5Gczn4bH,SGubLHYpURo5Dt63asfPM9eW,SQfeyZdsPa72rv9kLwcnDUFjhlWT,HTm1lXjkbF0UJCnpZOYERaG,y5Cv1XOeJmLa4zDr):
	T7hyMuvVz9EqkOasZDSJ,DmTNIZjxUY9HEd1 = [],[]
	ssW7FnU0o5Y39btBL = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
		if HTm1lXjkbF0UJCnpZOYERaG%473==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,40+int(10*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'قراءة الفيديوهات','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+str(SQfeyZdsPa72rv9kLwcnDUFjhlWT))
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None,None
		UJeuWoLKP7ZI15O4ypTVs8caj = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^(.*?)\n+((http|https|rtmp).*?)$',dlb6TgxSrm0eHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if UJeuWoLKP7ZI15O4ypTVs8caj:
			dlb6TgxSrm0eHB,UJeuWoLKP7ZI15O4ypTVs8caj,G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = UJeuWoLKP7ZI15O4ypTVs8caj[0]
			UJeuWoLKP7ZI15O4ypTVs8caj = UJeuWoLKP7ZI15O4ypTVs8caj.replace(okfdjS4RmM,gby0BnUuTNFk)
			dlb6TgxSrm0eHB = dlb6TgxSrm0eHB.replace(okfdjS4RmM,gby0BnUuTNFk)
		else:
			DmTNIZjxUY9HEd1.append({'line':dlb6TgxSrm0eHB})
			continue
		L2kZzbT7r5DjfishylqR61QOu,EyvQhYU4jZoGuwtW7M9JXb,r9rIzYVD0ceyC1uUofpPJF45tWbR,oGVqE4JR3DIcTNtAghW9,ZZrjMgRGiY2IDN7q,aaOKNe8gwz592oSGj1yrBnduH = {},gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,False
		try:
			dlb6TgxSrm0eHB,oGVqE4JR3DIcTNtAghW9 = dlb6TgxSrm0eHB.rsplit('",',1)
			dlb6TgxSrm0eHB = dlb6TgxSrm0eHB+'"'
		except:
			try: dlb6TgxSrm0eHB,oGVqE4JR3DIcTNtAghW9 = dlb6TgxSrm0eHB.rsplit('1,',1)
			except: oGVqE4JR3DIcTNtAghW9 = gby0BnUuTNFk
		L2kZzbT7r5DjfishylqR61QOu['url'] = UJeuWoLKP7ZI15O4ypTVs8caj
		jEJgDiVnmcqzRahbtySUs4AdI9HBp = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(' (.*?)="(.*?)"',dlb6TgxSrm0eHB,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for VVPgcXqOTRbEUBmk2ao,sspW29TnCh1 in jEJgDiVnmcqzRahbtySUs4AdI9HBp:
			VVPgcXqOTRbEUBmk2ao = VVPgcXqOTRbEUBmk2ao.replace('"',gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			L2kZzbT7r5DjfishylqR61QOu[VVPgcXqOTRbEUBmk2ao] = sspW29TnCh1.strip(UpN1CezytPO9XoduhxZSD)
		DXxRozgLGqn3TC5vVsdh1j8P0Be = list(L2kZzbT7r5DjfishylqR61QOu.keys())
		if not oGVqE4JR3DIcTNtAghW9:
			if 'name' in DXxRozgLGqn3TC5vVsdh1j8P0Be and L2kZzbT7r5DjfishylqR61QOu['name']: oGVqE4JR3DIcTNtAghW9 = L2kZzbT7r5DjfishylqR61QOu['name']
		L2kZzbT7r5DjfishylqR61QOu['title'] = oGVqE4JR3DIcTNtAghW9.strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if 'logo' in DXxRozgLGqn3TC5vVsdh1j8P0Be:
			L2kZzbT7r5DjfishylqR61QOu['img'] = L2kZzbT7r5DjfishylqR61QOu['logo']
			del L2kZzbT7r5DjfishylqR61QOu['logo']
		else: L2kZzbT7r5DjfishylqR61QOu['img'] = gby0BnUuTNFk
		if 'group' in DXxRozgLGqn3TC5vVsdh1j8P0Be and L2kZzbT7r5DjfishylqR61QOu['group']: r9rIzYVD0ceyC1uUofpPJF45tWbR = L2kZzbT7r5DjfishylqR61QOu['group']
		if any(value in UJeuWoLKP7ZI15O4ypTVs8caj.lower() for value in ssW7FnU0o5Y39btBL):
			aaOKNe8gwz592oSGj1yrBnduH = True if 'm3u' not in UJeuWoLKP7ZI15O4ypTVs8caj else False
		if aaOKNe8gwz592oSGj1yrBnduH or '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR or '__MOVIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR:
			ZZrjMgRGiY2IDN7q = 'VOD'
			if '__SERIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_SERIES'
			elif '__MOVIES__' in r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_MOVIES'
			else: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_UNKNOWN'
			r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.replace('__SERIES__',gby0BnUuTNFk).replace('__MOVIES__',gby0BnUuTNFk)
		else:
			ZZrjMgRGiY2IDN7q = 'LIVE'
			if oGVqE4JR3DIcTNtAghW9 in BAVbEI0J5XxG: EyvQhYU4jZoGuwtW7M9JXb = EyvQhYU4jZoGuwtW7M9JXb+'_EPG'
			if oGVqE4JR3DIcTNtAghW9 in jjLJvOMTAEy5Gczn4bH: EyvQhYU4jZoGuwtW7M9JXb = EyvQhYU4jZoGuwtW7M9JXb+'_ARCHIVED'
			if not r9rIzYVD0ceyC1uUofpPJF45tWbR: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+'_UNKNOWN'
			else: ZZrjMgRGiY2IDN7q = ZZrjMgRGiY2IDN7q+EyvQhYU4jZoGuwtW7M9JXb
		r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.strip(UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
		if 'LIVE_UNKNOWN' in ZZrjMgRGiY2IDN7q: r9rIzYVD0ceyC1uUofpPJF45tWbR = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ZZrjMgRGiY2IDN7q: r9rIzYVD0ceyC1uUofpPJF45tWbR = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ZZrjMgRGiY2IDN7q:
			BSW4piKu1cvol2MZbwtR5yk = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) [Ss]\d+ +[Ee]\d+',L2kZzbT7r5DjfishylqR61QOu['title'],ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if BSW4piKu1cvol2MZbwtR5yk: BSW4piKu1cvol2MZbwtR5yk = BSW4piKu1cvol2MZbwtR5yk[0]
			else: BSW4piKu1cvol2MZbwtR5yk = '!!__UNKNOWN_SERIES__!!'
			r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR+'__SERIES__'+BSW4piKu1cvol2MZbwtR5yk
		if 'id' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['id']
		if 'ID' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['ID']
		if 'name' in DXxRozgLGqn3TC5vVsdh1j8P0Be: del L2kZzbT7r5DjfishylqR61QOu['name']
		oGVqE4JR3DIcTNtAghW9 = L2kZzbT7r5DjfishylqR61QOu['title']
		oGVqE4JR3DIcTNtAghW9 = biVjhGCg0v5eEzkHwTrK9FIAtPU2(oGVqE4JR3DIcTNtAghW9)
		oGVqE4JR3DIcTNtAghW9 = kkTuFIfJsSM6Q(oGVqE4JR3DIcTNtAghW9)
		ZszECJvNng3TF,r9rIzYVD0ceyC1uUofpPJF45tWbR = ANoYGmuWy8w3FISMcxJ2B(r9rIzYVD0ceyC1uUofpPJF45tWbR)
		Wel7UCTIciR6pxYm8hzk1,oGVqE4JR3DIcTNtAghW9 = ANoYGmuWy8w3FISMcxJ2B(oGVqE4JR3DIcTNtAghW9)
		L2kZzbT7r5DjfishylqR61QOu['type'] = ZZrjMgRGiY2IDN7q
		L2kZzbT7r5DjfishylqR61QOu['context'] = EyvQhYU4jZoGuwtW7M9JXb
		L2kZzbT7r5DjfishylqR61QOu['group'] = r9rIzYVD0ceyC1uUofpPJF45tWbR.upper()
		L2kZzbT7r5DjfishylqR61QOu['title'] = oGVqE4JR3DIcTNtAghW9.upper()
		L2kZzbT7r5DjfishylqR61QOu['country'] = Wel7UCTIciR6pxYm8hzk1.upper()
		L2kZzbT7r5DjfishylqR61QOu['language'] = ZszECJvNng3TF.upper()
		T7hyMuvVz9EqkOasZDSJ.append(L2kZzbT7r5DjfishylqR61QOu)
		HTm1lXjkbF0UJCnpZOYERaG += 1
	return T7hyMuvVz9EqkOasZDSJ,HTm1lXjkbF0UJCnpZOYERaG,DmTNIZjxUY9HEd1
def kkTuFIfJsSM6Q(oGVqE4JR3DIcTNtAghW9):
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('||','|').replace('___',':').replace('--','-')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('[[','[').replace(']]',']')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('((','(').replace('))',')')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.replace('<<','<').replace('>>','>')
	oGVqE4JR3DIcTNtAghW9 = oGVqE4JR3DIcTNtAghW9.strip(UpN1CezytPO9XoduhxZSD)
	return oGVqE4JR3DIcTNtAghW9
def BwXOlFxGUdNjyW(pa4dtfsv23hgT0YK6cqCPDNlob,SGubLHYpURo5Dt63asfPM9eW):
	zjtcCHiX5rJ9TkVW = {}
	for Qw87uAPEDiOabR31 in JVs3roSjn5u: zjtcCHiX5rJ9TkVW[Qw87uAPEDiOabR31] = []
	SQfeyZdsPa72rv9kLwcnDUFjhlWT = len(pa4dtfsv23hgT0YK6cqCPDNlob)
	YYtTsJaAfEx3VcGlmpoQzrw = str(SQfeyZdsPa72rv9kLwcnDUFjhlWT)
	HTm1lXjkbF0UJCnpZOYERaG = 0
	DmTNIZjxUY9HEd1 = []
	for L2kZzbT7r5DjfishylqR61QOu in pa4dtfsv23hgT0YK6cqCPDNlob:
		if HTm1lXjkbF0UJCnpZOYERaG%873==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,50+int(5*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+YYtTsJaAfEx3VcGlmpoQzrw)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None
		r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = L2kZzbT7r5DjfishylqR61QOu['group'],L2kZzbT7r5DjfishylqR61QOu['context'],L2kZzbT7r5DjfishylqR61QOu['title'],L2kZzbT7r5DjfishylqR61QOu['url'],L2kZzbT7r5DjfishylqR61QOu['img']
		Wel7UCTIciR6pxYm8hzk1,ZszECJvNng3TF,Qw87uAPEDiOabR31 = L2kZzbT7r5DjfishylqR61QOu['country'],L2kZzbT7r5DjfishylqR61QOu['language'],L2kZzbT7r5DjfishylqR61QOu['type']
		u2O8xRJtfD = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		yTr9NcszeEp4hMubAfDdij5lBStHR = False
		if 'LIVE' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_UNKNOWN_GROUPED'].append(u2O8xRJtfD)
			elif 'LIVE' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_GROUPED'].append(u2O8xRJtfD)
			else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
			zjtcCHiX5rJ9TkVW['LIVE_ORIGINAL_GROUPED'].append(u2O8xRJtfD)
		elif 'VOD' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_UNKNOWN_GROUPED'].append(u2O8xRJtfD)
			elif 'MOVIES' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_MOVIES_GROUPED'].append(u2O8xRJtfD)
			elif 'SERIES' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_SERIES_GROUPED'].append(u2O8xRJtfD)
			else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
			zjtcCHiX5rJ9TkVW['VOD_ORIGINAL_GROUPED'].append(u2O8xRJtfD)
		else: yTr9NcszeEp4hMubAfDdij5lBStHR = True
		if yTr9NcszeEp4hMubAfDdij5lBStHR: DmTNIZjxUY9HEd1.append(L2kZzbT7r5DjfishylqR61QOu)
		HTm1lXjkbF0UJCnpZOYERaG += 1
	MO7F532BTYQLnl0 = sorted(pa4dtfsv23hgT0YK6cqCPDNlob,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao['title'].lower())
	del pa4dtfsv23hgT0YK6cqCPDNlob
	YYtTsJaAfEx3VcGlmpoQzrw = str(SQfeyZdsPa72rv9kLwcnDUFjhlWT)
	HTm1lXjkbF0UJCnpZOYERaG = 0
	for L2kZzbT7r5DjfishylqR61QOu in MO7F532BTYQLnl0:
		HTm1lXjkbF0UJCnpZOYERaG += 1
		if HTm1lXjkbF0UJCnpZOYERaG%873==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,55+int(5*HTm1lXjkbF0UJCnpZOYERaG/SQfeyZdsPa72rv9kLwcnDUFjhlWT),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(HTm1lXjkbF0UJCnpZOYERaG)+' / '+YYtTsJaAfEx3VcGlmpoQzrw)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return None,None
		Qw87uAPEDiOabR31 = L2kZzbT7r5DjfishylqR61QOu['type']
		r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = L2kZzbT7r5DjfishylqR61QOu['group'],L2kZzbT7r5DjfishylqR61QOu['context'],L2kZzbT7r5DjfishylqR61QOu['title'],L2kZzbT7r5DjfishylqR61QOu['url'],L2kZzbT7r5DjfishylqR61QOu['img']
		Wel7UCTIciR6pxYm8hzk1,ZszECJvNng3TF = L2kZzbT7r5DjfishylqR61QOu['country'],L2kZzbT7r5DjfishylqR61QOu['language']
		TEsoblmKGP1aBIYc30uRw = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb+'_TIMESHIFT',oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		u2O8xRJtfD = (r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		IIWRQcw15hV = (Wel7UCTIciR6pxYm8hzk1,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		a3aGkSQUh0VzCov = (ZszECJvNng3TF,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM)
		if 'LIVE' in Qw87uAPEDiOabR31:
			if 'UNKNOWN' in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_UNKNOWN_GROUPED_SORTED'].append(u2O8xRJtfD)
			else: zjtcCHiX5rJ9TkVW['LIVE_GROUPED_SORTED'].append(u2O8xRJtfD)
			if 'EPG'		in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_EPG_GROUPED_SORTED'].append(u2O8xRJtfD)
			if 'ARCHIVED'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_ARCHIVED_GROUPED_SORTED'].append(u2O8xRJtfD)
			if 'ARCHIVED'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['LIVE_TIMESHIFT_GROUPED_SORTED'].append(TEsoblmKGP1aBIYc30uRw)
			zjtcCHiX5rJ9TkVW['LIVE_FROM_NAME_SORTED'].append(IIWRQcw15hV)
			zjtcCHiX5rJ9TkVW['LIVE_FROM_GROUP_SORTED'].append(a3aGkSQUh0VzCov)
		elif 'VOD' in Qw87uAPEDiOabR31:
			if   'UNKNOWN'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_UNKNOWN_GROUPED_SORTED'].append(u2O8xRJtfD)
			elif 'MOVIES'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_MOVIES_GROUPED_SORTED'].append(u2O8xRJtfD)
			elif 'SERIES'	in Qw87uAPEDiOabR31: zjtcCHiX5rJ9TkVW['VOD_SERIES_GROUPED_SORTED'].append(u2O8xRJtfD)
			zjtcCHiX5rJ9TkVW['VOD_FROM_NAME_SORTED'].append(IIWRQcw15hV)
			zjtcCHiX5rJ9TkVW['VOD_FROM_GROUP_SORTED'].append(a3aGkSQUh0VzCov)
	return zjtcCHiX5rJ9TkVW,DmTNIZjxUY9HEd1
def ANoYGmuWy8w3FISMcxJ2B(oGVqE4JR3DIcTNtAghW9):
	if len(oGVqE4JR3DIcTNtAghW9)<3: return oGVqE4JR3DIcTNtAghW9,oGVqE4JR3DIcTNtAghW9
	wdKVTULEc7BlX62J,seH2r3E7MIu6nc = gby0BnUuTNFk,gby0BnUuTNFk
	mSILAkdsGBCpx = oGVqE4JR3DIcTNtAghW9
	dGa2sRtqhwrvUT6HIeJC9c = oGVqE4JR3DIcTNtAghW9[:1]
	MNbGEJ84v7okqsOaIZenuy2hlXFWt = oGVqE4JR3DIcTNtAghW9[1:]
	if   dGa2sRtqhwrvUT6HIeJC9c=='(': seH2r3E7MIu6nc = ')'
	elif dGa2sRtqhwrvUT6HIeJC9c=='[': seH2r3E7MIu6nc = ']'
	elif dGa2sRtqhwrvUT6HIeJC9c=='<': seH2r3E7MIu6nc = '>'
	elif dGa2sRtqhwrvUT6HIeJC9c=='|': seH2r3E7MIu6nc = '|'
	if seH2r3E7MIu6nc and (seH2r3E7MIu6nc in MNbGEJ84v7okqsOaIZenuy2hlXFWt):
		CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = MNbGEJ84v7okqsOaIZenuy2hlXFWt.split(seH2r3E7MIu6nc,1)
		wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
		mSILAkdsGBCpx = dGa2sRtqhwrvUT6HIeJC9c+CQE8ZILpTt7wYyhciVe4fUdo3nA+seH2r3E7MIu6nc+UpN1CezytPO9XoduhxZSD+dcCoDw5B9K8HftYG
	elif oGVqE4JR3DIcTNtAghW9.count('|')>=2:
		CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = oGVqE4JR3DIcTNtAghW9.split('|',1)
		wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
		mSILAkdsGBCpx = CQE8ZILpTt7wYyhciVe4fUdo3nA+' |'+dcCoDw5B9K8HftYG
	else:
		seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not seH2r3E7MIu6nc: seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not seH2r3E7MIu6nc: seH2r3E7MIu6nc = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if seH2r3E7MIu6nc:
			CQE8ZILpTt7wYyhciVe4fUdo3nA,dcCoDw5B9K8HftYG = oGVqE4JR3DIcTNtAghW9.split(seH2r3E7MIu6nc[0],1)
			wdKVTULEc7BlX62J = CQE8ZILpTt7wYyhciVe4fUdo3nA
			mSILAkdsGBCpx = CQE8ZILpTt7wYyhciVe4fUdo3nA+UpN1CezytPO9XoduhxZSD+seH2r3E7MIu6nc[0]+UpN1CezytPO9XoduhxZSD+dcCoDw5B9K8HftYG
	mSILAkdsGBCpx = mSILAkdsGBCpx.replace(AXmnlSGOyNfW7PxEdv,UpN1CezytPO9XoduhxZSD).replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	wdKVTULEc7BlX62J = wdKVTULEc7BlX62J.replace(rBcdwYZInhgO29jtkFAfGxi7,UpN1CezytPO9XoduhxZSD)
	if not wdKVTULEc7BlX62J: wdKVTULEc7BlX62J = '!!__UNKNOWN__!!'
	wdKVTULEc7BlX62J = wdKVTULEc7BlX62J.strip(UpN1CezytPO9XoduhxZSD)
	mSILAkdsGBCpx = mSILAkdsGBCpx.strip(UpN1CezytPO9XoduhxZSD)
	return wdKVTULEc7BlX62J,mSILAkdsGBCpx
def dWxL30fTGqPpl1z8Bo(Z27widCyESA):
	vO65KkJHupCrocdLe = {}
	Z38Zes0IBSDYCLPGJfM6j = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.useragent_'+Z27widCyESA)
	if Z38Zes0IBSDYCLPGJfM6j: vO65KkJHupCrocdLe['User-Agent'] = Z38Zes0IBSDYCLPGJfM6j
	vBJn6DgVPG7sqoprY = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.iptv.referer_'+Z27widCyESA)
	if vBJn6DgVPG7sqoprY: vO65KkJHupCrocdLe['Referer'] = vBJn6DgVPG7sqoprY
	return vO65KkJHupCrocdLe
def uj7O46p1qPsiHlyTKRtwe8N2(Z27widCyESA):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx: return
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return
	P9PI1QNFzMEDk = uczY4EiMm1.replace('___','_'+Z27widCyESA)
	if 1:
		ww8aEQ9UGz1ms3qOeXvDkfFMTdV,pEdJtk92IBfq80N,Lt5J47xrFw9KRulCoVs = k3hMGFeOxXSqWIYHv5ygDPTdzcs29(Z27widCyESA,False)
		if not ww8aEQ9UGz1ms3qOeXvDkfFMTdV:
			tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not y5Cv1XOeJmLa4zDr: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(BZqfNTuc7nKbG1lh)+'   No IPTV URL found to download IPTV files')
			else: SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(BZqfNTuc7nKbG1lh)+'   Failed to download IPTV files')
			return
		U8U4QPpgIaovkiCuc30mBEd9yNLXsO = EckxoYzjdgLH0r(y5Cv1XOeJmLa4zDr,vO65KkJHupCrocdLe,True)
		if not U8U4QPpgIaovkiCuc30mBEd9yNLXsO: return
		open(P9PI1QNFzMEDk,'wb').write(U8U4QPpgIaovkiCuc30mBEd9yNLXsO)
	else: U8U4QPpgIaovkiCuc30mBEd9yNLXsO = open(P9PI1QNFzMEDk,'rb').read()
	if nqkybtoMBH and U8U4QPpgIaovkiCuc30mBEd9yNLXsO: U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.decode(JJQFjSIlALchiMzG9)
	SGubLHYpURo5Dt63asfPM9eW = gX5UxB8Sce7tuvjkNaoIAHDq4()
	SGubLHYpURo5Dt63asfPM9eW.create('جلب ملفات ـIPTV جديدة',gby0BnUuTNFk)
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,15,'تنظيف الملف الرئيسي',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('"tvg-','" tvg-')
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('َ',gby0BnUuTNFk).replace('ً',gby0BnUuTNFk).replace('ُ',gby0BnUuTNFk).replace('ٌ',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('ّ',gby0BnUuTNFk).replace('ِ',gby0BnUuTNFk).replace('ٍ',gby0BnUuTNFk).replace('ْ',gby0BnUuTNFk)
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('group-title=','group=').replace('tvg-',gby0BnUuTNFk)
	jjLJvOMTAEy5Gczn4bH,BAVbEI0J5XxG = [],[]
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_series_categories'
	WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',UJeuWoLKP7ZI15O4ypTVs8caj,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,gby0BnUuTNFk,'IPTV-CREATE_STREAMS-1st')
	LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
	LviwW2t5HRmCMpxOqhDFo4d = biVjhGCg0v5eEzkHwTrK9FIAtPU2(LviwW2t5HRmCMpxOqhDFo4d)
	f4lFpMS8sq6A9gxNLG5U = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('category_name":"(.*?)"',LviwW2t5HRmCMpxOqhDFo4d,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	del LviwW2t5HRmCMpxOqhDFo4d
	for r9rIzYVD0ceyC1uUofpPJF45tWbR in f4lFpMS8sq6A9gxNLG5U:
		r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.replace('\/','/')
		if cAIRPFK6boejVU549WzqBGCaJ0r: r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.decode(JJQFjSIlALchiMzG9).encode(JJQFjSIlALchiMzG9)
		U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('group="'+r9rIzYVD0ceyC1uUofpPJF45tWbR+'"','group="__SERIES__'+r9rIzYVD0ceyC1uUofpPJF45tWbR+'"')
	del f4lFpMS8sq6A9gxNLG5U
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_vod_categories'
	WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',UJeuWoLKP7ZI15O4ypTVs8caj,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,gby0BnUuTNFk,'IPTV-CREATE_STREAMS-2nd')
	LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
	LviwW2t5HRmCMpxOqhDFo4d = biVjhGCg0v5eEzkHwTrK9FIAtPU2(LviwW2t5HRmCMpxOqhDFo4d)
	Yo64T5yLwGp0maCbleXg3NZ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('category_name":"(.*?)"',LviwW2t5HRmCMpxOqhDFo4d,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	del LviwW2t5HRmCMpxOqhDFo4d
	for r9rIzYVD0ceyC1uUofpPJF45tWbR in Yo64T5yLwGp0maCbleXg3NZ:
		r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.replace('\/','/')
		if cAIRPFK6boejVU549WzqBGCaJ0r: r9rIzYVD0ceyC1uUofpPJF45tWbR = r9rIzYVD0ceyC1uUofpPJF45tWbR.decode(JJQFjSIlALchiMzG9).encode(JJQFjSIlALchiMzG9)
		U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace('group="'+r9rIzYVD0ceyC1uUofpPJF45tWbR+'"','group="__MOVIES__'+r9rIzYVD0ceyC1uUofpPJF45tWbR+'"')
	del Yo64T5yLwGp0maCbleXg3NZ
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_live_streams'
	WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',UJeuWoLKP7ZI15O4ypTVs8caj,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,gby0BnUuTNFk,'IPTV-CREATE_STREAMS-3rd')
	LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
	LviwW2t5HRmCMpxOqhDFo4d = biVjhGCg0v5eEzkHwTrK9FIAtPU2(LviwW2t5HRmCMpxOqhDFo4d)
	vviERncoYwg3OZKr94k2My15Sxz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"name":"(.*?)".*?"tv_archive":(.*?),',LviwW2t5HRmCMpxOqhDFo4d,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for DPkEMfnRe82d,LLdGsCKDAxk in vviERncoYwg3OZKr94k2My15Sxz:
		if LLdGsCKDAxk=='1': jjLJvOMTAEy5Gczn4bH.append(DPkEMfnRe82d)
	del vviERncoYwg3OZKr94k2My15Sxz
	UHCdXOQv0h7ubFDzrtfj4 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',LviwW2t5HRmCMpxOqhDFo4d,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	del LviwW2t5HRmCMpxOqhDFo4d
	for DPkEMfnRe82d,wHnbMWCLeD3fi in UHCdXOQv0h7ubFDzrtfj4:
		if wHnbMWCLeD3fi!='null': BAVbEI0J5XxG.append(DPkEMfnRe82d)
	del UHCdXOQv0h7ubFDzrtfj4
	U8U4QPpgIaovkiCuc30mBEd9yNLXsO = U8U4QPpgIaovkiCuc30mBEd9yNLXsO.replace(Hd14YjcWpvPhN8sZXK3,okfdjS4RmM)
	uA0Ja8qPSW9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('NF:(.+?)'+'#'+'EXTI',U8U4QPpgIaovkiCuc30mBEd9yNLXsO+'\n+'+'#'+'EXTINF:',ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not uA0Ja8qPSW9:
		SSMhXBxZtO7l0nVq9wde2i(hDXl7UZPovbmC6kQL912Icr30qwBMn,FtPpevkmnBisyz1ouLTShElA7w(BZqfNTuc7nKbG1lh)+'   Folder:'+Z27widCyESA+'   No video links found in IPTV file')
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+okfdjS4RmM+bKN9diGf8nmgecQPEqUzHRpoDuaO+'مجلد رقم '+Z27widCyESA)
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	hjufnKU5rGEgRD4H8 = []
	for dlb6TgxSrm0eHB in uA0Ja8qPSW9:
		HranyDdf74SG1JQq6oXkmc = dlb6TgxSrm0eHB.lower()
		if 'adult' in HranyDdf74SG1JQq6oXkmc: continue
		if 'xxx' in HranyDdf74SG1JQq6oXkmc: continue
		hjufnKU5rGEgRD4H8.append(dlb6TgxSrm0eHB)
	uA0Ja8qPSW9 = hjufnKU5rGEgRD4H8
	del hjufnKU5rGEgRD4H8
	fMY5WCpDr7XGTzUv1qZHd = 1024*1024
	Lnd4Juz7KaNUXy6Cop = 1+len(U8U4QPpgIaovkiCuc30mBEd9yNLXsO)//fMY5WCpDr7XGTzUv1qZHd//10
	del U8U4QPpgIaovkiCuc30mBEd9yNLXsO
	NIERLMmxdG = len(uA0Ja8qPSW9)
	CZOBcqyYQhTdkV2EMveXb0R3ULN8D7 = Zdw6qDQULYRG(uA0Ja8qPSW9,Lnd4Juz7KaNUXy6Cop)
	del uA0Ja8qPSW9
	for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(Lnd4Juz7KaNUXy6Cop):
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,35+int(5*ZOfCnxmPUWEpvBVtYj5RSDMrcd/Lnd4Juz7KaNUXy6Cop),'تقطيع الملف الرئيسي','الجزء رقم:-',str(ZOfCnxmPUWEpvBVtYj5RSDMrcd+1)+' / '+str(Lnd4Juz7KaNUXy6Cop))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		W8WyuMC9mTN5c = str(CZOBcqyYQhTdkV2EMveXb0R3ULN8D7[ZOfCnxmPUWEpvBVtYj5RSDMrcd])
		if nqkybtoMBH: W8WyuMC9mTN5c = W8WyuMC9mTN5c.encode(JJQFjSIlALchiMzG9)
		open(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd),'wb').write(W8WyuMC9mTN5c)
	del CZOBcqyYQhTdkV2EMveXb0R3ULN8D7,W8WyuMC9mTN5c
	G3LX0b8akfYvWPh7zm2tqU,pa4dtfsv23hgT0YK6cqCPDNlob,HTm1lXjkbF0UJCnpZOYERaG = [],[],0
	for ZOfCnxmPUWEpvBVtYj5RSDMrcd in range(Lnd4Juz7KaNUXy6Cop):
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		W8WyuMC9mTN5c = open(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd),'rb').read()
		RyfYSek61do5OnQMc.sleep(1)
		try: bCoOHfPdMryRgauz0IVpth.remove(P9PI1QNFzMEDk+'.00'+str(ZOfCnxmPUWEpvBVtYj5RSDMrcd))
		except: pass
		if nqkybtoMBH: W8WyuMC9mTN5c = W8WyuMC9mTN5c.decode(JJQFjSIlALchiMzG9)
		mwJHTsvSGF3hP90 = TqNUy3Z4SFWvplGwXC82A('list',W8WyuMC9mTN5c)
		del W8WyuMC9mTN5c
		T7hyMuvVz9EqkOasZDSJ,HTm1lXjkbF0UJCnpZOYERaG,DmTNIZjxUY9HEd1 = T5tyHdWREw2kJ(mwJHTsvSGF3hP90,BAVbEI0J5XxG,jjLJvOMTAEy5Gczn4bH,SGubLHYpURo5Dt63asfPM9eW,NIERLMmxdG,HTm1lXjkbF0UJCnpZOYERaG,y5Cv1XOeJmLa4zDr)
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		if not T7hyMuvVz9EqkOasZDSJ:
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
		pa4dtfsv23hgT0YK6cqCPDNlob += T7hyMuvVz9EqkOasZDSJ
		G3LX0b8akfYvWPh7zm2tqU += DmTNIZjxUY9HEd1
	del mwJHTsvSGF3hP90,T7hyMuvVz9EqkOasZDSJ
	zjtcCHiX5rJ9TkVW,DmTNIZjxUY9HEd1 = BwXOlFxGUdNjyW(pa4dtfsv23hgT0YK6cqCPDNlob,SGubLHYpURo5Dt63asfPM9eW)
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
		SGubLHYpURo5Dt63asfPM9eW.close()
		return
	G3LX0b8akfYvWPh7zm2tqU += DmTNIZjxUY9HEd1
	del pa4dtfsv23hgT0YK6cqCPDNlob,DmTNIZjxUY9HEd1
	PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE = {},{},{},0,0
	KSPsvbM056hiYzuHVTJDEtdAxl = list(zjtcCHiX5rJ9TkVW.keys())
	oYJIFdRbM8y9HpcrNPaz2 = len(KSPsvbM056hiYzuHVTJDEtdAxl)*3
	if 1:
		QQAPWB1Gs3xdF5 = {}
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=HLl9n75QpKU,args=(kVGU1uhays3EWfH,))
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].start()
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].join()
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
	else:
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			HLl9n75QpKU(kVGU1uhays3EWfH)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
	kewG0Bi9gt31hPAFJYoKHDznW(Z27widCyESA,False)
	KSPsvbM056hiYzuHVTJDEtdAxl = list(PuIwj1QHal3U2c.keys())
	QDZz9UxbmYgBlfjEW45hyrsCdw76 = 0
	if 1:
		QQAPWB1Gs3xdF5 = {}
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH] = YaLldqOCj5M8oWzkKXuEb14JS(daemon=w8Ui6RsVhSPrqHfO4,target=pKUDsgqGoOZ1CvSyaPTrW4m0c6,args=(Z27widCyESA,kVGU1uhays3EWfH))
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].start()
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			QQAPWB1Gs3xdF5[kVGU1uhays3EWfH].join()
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
			SGubLHYpURo5Dt63asfPM9eW.close()
			return
	else:
		for kVGU1uhays3EWfH in KSPsvbM056hiYzuHVTJDEtdAxl:
			pKUDsgqGoOZ1CvSyaPTrW4m0c6(Z27widCyESA,kVGU1uhays3EWfH)
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
	ZOfCnxmPUWEpvBVtYj5RSDMrcd = 0
	NxgpIr8GPm = len(G3LX0b8akfYvWPh7zm2tqU)
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'IGNORED')
	for vGAHiWjyCMoz in G3LX0b8akfYvWPh7zm2tqU:
		if ZOfCnxmPUWEpvBVtYj5RSDMrcd%27==0:
			OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,95+int(5*ZOfCnxmPUWEpvBVtYj5RSDMrcd//NxgpIr8GPm),'تخزين المهملة','الفيديو رقم:-',str(ZOfCnxmPUWEpvBVtYj5RSDMrcd)+' / '+str(NxgpIr8GPm))
			if SGubLHYpURo5Dt63asfPM9eW.iscanceled():
				SGubLHYpURo5Dt63asfPM9eW.close()
				return
		CExrgJh48PYI2(WXZRrenmT8v,'IGNORED',str(vGAHiWjyCMoz),gby0BnUuTNFk,Z83rChqtg1oXUjI4YL)
		ZOfCnxmPUWEpvBVtYj5RSDMrcd += 1
	CExrgJh48PYI2(WXZRrenmT8v,'IGNORED','__COUNT__',str(NxgpIr8GPm),Z83rChqtg1oXUjI4YL)
	CExrgJh48PYI2(WXZRrenmT8v,'DUMMY','__DUMMY__','1',Z83rChqtg1oXUjI4YL)
	SGubLHYpURo5Dt63asfPM9eW.close()
	RyfYSek61do5OnQMc.sleep(1)
	XgSmd7DqBQhbcKj3GaZW = U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA,False)
	tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,bKN9diGf8nmgecQPEqUzHRpoDuaO+'تم جلب ملفات ـIPTV جديدة'+GGy0cQe765nPYZ9E8Th+'\n\n'+XgSmd7DqBQhbcKj3GaZW)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	Cjio8VzFbEgRfTNH3UrDJMZ(False)
	nR4jOE8geFDJhKIuisTc2ZPa(False)
	return
def HLl9n75QpKU(kVGU1uhays3EWfH):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	PuIwj1QHal3U2c[kVGU1uhays3EWfH] = {}
	lS861QGjDwFJHqcC,G0pBESAFe8XRxgO3IUC9oVJkblfQ = {},[]
	CNxVvOGKPJ41gTkt = len(zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH])
	PuIwj1QHal3U2c[kVGU1uhays3EWfH]['__COUNT__'] = CNxVvOGKPJ41gTkt
	if CNxVvOGKPJ41gTkt>0:
		OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,qNPtwrdCkyVWQUYoiES0,P5kgKvGWa9RCDA8c4fmV0,WI8aunoi406OY1hRpB7,P37Ptlixv2AeSLnY5BWXq = zip(*zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH])
		del qNPtwrdCkyVWQUYoiES0,P5kgKvGWa9RCDA8c4fmV0,WI8aunoi406OY1hRpB7
		YYriFXHUaqeKEjbT98PRzSNukgQ = list(set(OIG9wLUcAxDp6mQNzJYHekPSqW5XZV))
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in YYriFXHUaqeKEjbT98PRzSNukgQ:
			lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] = gby0BnUuTNFk
			PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR] = []
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		GibLO06T1KCmdjNXE += 1
		J56yUgZ3FPm87 = len(YYriFXHUaqeKEjbT98PRzSNukgQ)
		del YYriFXHUaqeKEjbT98PRzSNukgQ
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = list(set(zip(OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,P37Ptlixv2AeSLnY5BWXq)))
		del OIG9wLUcAxDp6mQNzJYHekPSqW5XZV,P37Ptlixv2AeSLnY5BWXq
		for r9rIzYVD0ceyC1uUofpPJF45tWbR,bxTDyYw3SV82Pt in G0pBESAFe8XRxgO3IUC9oVJkblfQ:
			if not lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] and bxTDyYw3SV82Pt: lS861QGjDwFJHqcC[r9rIzYVD0ceyC1uUofpPJF45tWbR] = bxTDyYw3SV82Pt
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		GibLO06T1KCmdjNXE += 1
		VVzGqXedovr0kjHwWIxJR = list(lS861QGjDwFJHqcC.keys())
		YH6tTUMIa8vJOy0d1s7zAbiCr = list(lS861QGjDwFJHqcC.values())
		del lS861QGjDwFJHqcC
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = list(zip(VVzGqXedovr0kjHwWIxJR,YH6tTUMIa8vJOy0d1s7zAbiCr))
		del VVzGqXedovr0kjHwWIxJR,YH6tTUMIa8vJOy0d1s7zAbiCr
		G0pBESAFe8XRxgO3IUC9oVJkblfQ = sorted(G0pBESAFe8XRxgO3IUC9oVJkblfQ)
	else: GibLO06T1KCmdjNXE += 2
	PuIwj1QHal3U2c[kVGU1uhays3EWfH]['__GROUPS__'] = G0pBESAFe8XRxgO3IUC9oVJkblfQ
	del G0pBESAFe8XRxgO3IUC9oVJkblfQ
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH]:
		PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR].append((EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
	OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,60+int(15*GibLO06T1KCmdjNXE//oYJIFdRbM8y9HpcrNPaz2),'تصنيع القوائم','الجزء رقم:-',str(GibLO06T1KCmdjNXE)+' / '+str(oYJIFdRbM8y9HpcrNPaz2))
	if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
	GibLO06T1KCmdjNXE += 1
	del zjtcCHiX5rJ9TkVW[kVGU1uhays3EWfH]
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH] = list(PuIwj1QHal3U2c[kVGU1uhays3EWfH].keys())
	R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH] = len(qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH])
	uUyTZEwvm5 += R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]
	return
def pKUDsgqGoOZ1CvSyaPTrW4m0c6(Z27widCyESA,kVGU1uhays3EWfH):
	global SGubLHYpURo5Dt63asfPM9eW,zjtcCHiX5rJ9TkVW,QDZz9UxbmYgBlfjEW45hyrsCdw76,PuIwj1QHal3U2c,R0SXYdmKUf294WtiucAP,qleCEa50kOYvVNSJuDP1R4FdhtoIxw,uUyTZEwvm5,GibLO06T1KCmdjNXE,oYJIFdRbM8y9HpcrNPaz2
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH)
	for HTm1lXjkbF0UJCnpZOYERaG in range(1+R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]//273):
		zzHkOcQNLo = []
		cIgxGlNm9jwQXF = qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH][0:273]
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in cIgxGlNm9jwQXF:
			zzHkOcQNLo.append(PuIwj1QHal3U2c[kVGU1uhays3EWfH][r9rIzYVD0ceyC1uUofpPJF45tWbR])
		CExrgJh48PYI2(WXZRrenmT8v,kVGU1uhays3EWfH,cIgxGlNm9jwQXF,zzHkOcQNLo,Z83rChqtg1oXUjI4YL,True)
		QDZz9UxbmYgBlfjEW45hyrsCdw76 += len(cIgxGlNm9jwQXF)
		OCdLHyt7V58QGMokw(SGubLHYpURo5Dt63asfPM9eW,75+int(20*QDZz9UxbmYgBlfjEW45hyrsCdw76//uUyTZEwvm5),'تخزين القوائم','القائمة رقم:-',str(QDZz9UxbmYgBlfjEW45hyrsCdw76)+' / '+str(uUyTZEwvm5))
		if SGubLHYpURo5Dt63asfPM9eW.iscanceled(): return
		del qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH][0:273]
	del PuIwj1QHal3U2c[kVGU1uhays3EWfH],qleCEa50kOYvVNSJuDP1R4FdhtoIxw[kVGU1uhays3EWfH],R0SXYdmKUf294WtiucAP[kVGU1uhays3EWfH]
	return
def U5hDy0KuLnGstjYQHdCxAWmori7fTz(Z27widCyESA,N9bXKIfsDVPjctLM5u=True):
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	hmSXQ5yx8F4TCLMPpwB1DkY = e1nNXbPrBVDZw
	qCsgKhSfyce7NFZb2kAVIGm = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'LIVE_ORIGINAL_GROUPED')
	HAz5YEkZLQscingdRpX71yeFOmWv = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'VOD_ORIGINAL_GROUPED')
	NxgpIr8GPm = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','IGNORED','__COUNT__')
	boDu2swfFIp = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	UOKaoQbxiZcP6IBRTW3uD0zFHkSyg = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	CCn71Ta3VmBIjc9sEUbopYAtZQG = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_GROUPED','__COUNT__')
	nh3wDaGEs81ZWAomckugNdFte = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	IIS7m2LvHghPKrABR = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','VOD_MOVIES_GROUPED','__COUNT__')
	dB2chsoPHL6fmZEO9I7AMC30UK = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'int','VOD_SERIES_GROUPED','__COUNT__')
	vly38JEpOTiSrKf4D19w = hak2AysNmEcZ5xuKOptV(qCsgKhSfyce7NFZb2kAVIGm,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(HAz5YEkZLQscingdRpX71yeFOmWv,'list','VOD_SERIES_GROUPED','__GROUPS__')
	Xeb0kM6wo9qYQxrSnsNvLiHfEhVP = []
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
		YodFENhiTUXJtr = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')[1]
		Xeb0kM6wo9qYQxrSnsNvLiHfEhVP.append(YodFENhiTUXJtr)
	pYslW6Ph8OxaFQVuA14f5zSELB3Ui7 = len(Xeb0kM6wo9qYQxrSnsNvLiHfEhVP)
	LbeM6usxzdNjYTXJ7iOoKEDgAkHf = int(IIS7m2LvHghPKrABR)+int(dB2chsoPHL6fmZEO9I7AMC30UK)+int(vly38JEpOTiSrKf4D19w)+int(nh3wDaGEs81ZWAomckugNdFte)+int(CCn71Ta3VmBIjc9sEUbopYAtZQG)
	XgSmd7DqBQhbcKj3GaZW = gby0BnUuTNFk
	XgSmd7DqBQhbcKj3GaZW += 'قنوات: '+str(CCn71Ta3VmBIjc9sEUbopYAtZQG)
	XgSmd7DqBQhbcKj3GaZW += '   .   أفلام: '+str(IIS7m2LvHghPKrABR)
	XgSmd7DqBQhbcKj3GaZW += '\nمسلسلات: '+str(pYslW6Ph8OxaFQVuA14f5zSELB3Ui7)
	XgSmd7DqBQhbcKj3GaZW += '   .   حلقات: '+str(dB2chsoPHL6fmZEO9I7AMC30UK)
	XgSmd7DqBQhbcKj3GaZW += '\nقنوات مجهولة: '+str(nh3wDaGEs81ZWAomckugNdFte)
	XgSmd7DqBQhbcKj3GaZW += '   .   فيدوهات مجهولة: '+str(vly38JEpOTiSrKf4D19w)
	XgSmd7DqBQhbcKj3GaZW += '\nمجموع القنوات: '+str(boDu2swfFIp)
	XgSmd7DqBQhbcKj3GaZW += '   .   مجموع الفيديوهات: '+str(UOKaoQbxiZcP6IBRTW3uD0zFHkSyg)
	XgSmd7DqBQhbcKj3GaZW += '\n\nمجموع المضافة: '+str(LbeM6usxzdNjYTXJ7iOoKEDgAkHf)
	XgSmd7DqBQhbcKj3GaZW += '   .   مجموع المهملة: '+str(NxgpIr8GPm)
	if N9bXKIfsDVPjctLM5u: tt3DVu1TU8dLAi('center',gby0BnUuTNFk,hmSXQ5yx8F4TCLMPpwB1DkY,XgSmd7DqBQhbcKj3GaZW)
	SSTV7KAnNCQPUvhL = XgSmd7DqBQhbcKj3GaZW.replace('\n\n',okfdjS4RmM)
	SSMhXBxZtO7l0nVq9wde2i(Z4h3BfbPzS,'.\tCounts of IPTV videos   Folder: '+Z27widCyESA+okfdjS4RmM+SSTV7KAnNCQPUvhL)
	return XgSmd7DqBQhbcKj3GaZW
def kewG0Bi9gt31hPAFJYoKHDznW(Z27widCyESA,N9bXKIfsDVPjctLM5u=True):
	if N9bXKIfsDVPjctLM5u:
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS('center',gby0BnUuTNFk,gby0BnUuTNFk,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if BeU98noROVkGhHqN15fumPCvyWQcxJ!=1: return
		oP4hs5zHkY2 = uczY4EiMm1.replace('___','_'+Z27widCyESA)
		try: bCoOHfPdMryRgauz0IVpth.remove(oP4hs5zHkY2)
		except: pass
	oP4hs5zHkY2 = bGZat8TIQDBiAwWYOn.replace('___','_'+Z27widCyESA)
	try: bCoOHfPdMryRgauz0IVpth.remove(oP4hs5zHkY2)
	except: pass
	oP4hs5zHkY2 = I0oFsWqUfGcDdlx.replace('___','_'+Z27widCyESA)
	try: bCoOHfPdMryRgauz0IVpth.remove(oP4hs5zHkY2)
	except: pass
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_IPTV','SECTIONS_IPTV_'+Z27widCyESA)
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	Cjio8VzFbEgRfTNH3UrDJMZ(False)
	N3NqxCYlUkuSAGb4meh(Z27widCyESA)
	if N9bXKIfsDVPjctLM5u:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'تم مسح جميع ملفات ـIPTV')
		nR4jOE8geFDJhKIuisTc2ZPa(False)
	return
def hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA=gby0BnUuTNFk,N9bXKIfsDVPjctLM5u=True):
	if Z27widCyESA:
		WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(str(Z27widCyESA),'DUMMY')
		G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'str','DUMMY','__DUMMY__')
		if G2A1zJCal59LbeSXhnPpcYqN8OD7Zw: return True
	else:
		Z27widCyESA = '1'
		for jyPnJKCVoqRL3b1hE2Zwdt5Q in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
			WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(str(jyPnJKCVoqRL3b1hE2Zwdt5Q),'DUMMY')
			G2A1zJCal59LbeSXhnPpcYqN8OD7Zw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'str','DUMMY','__DUMMY__')
			if G2A1zJCal59LbeSXhnPpcYqN8OD7Zw: return True
	if N9bXKIfsDVPjctLM5u:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,e1nNXbPrBVDZw,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+GGy0cQe765nPYZ9E8Th)
		hmSXQ5yx8F4TCLMPpwB1DkY = 'إضافة وتغيير رابط '+XVANElz3tLn5pFPQUWi[1]+' (مجلد '+XVANElz3tLn5pFPQUWi[int(Z27widCyESA)]+')'
		BeU98noROVkGhHqN15fumPCvyWQcxJ = c3iHohf1zAFQjtTV20pPlS(gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,hmSXQ5yx8F4TCLMPpwB1DkY,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if BeU98noROVkGhHqN15fumPCvyWQcxJ==1: BYRb8ALrn41jh7owmOH(Z27widCyESA)
	return False
def H7l4URTtJj2ksaBQwb(Dak6tVP8I7zdT5329ijCLFwGsgMo,Z27widCyESA=gby0BnUuTNFk,kVGU1uhays3EWfH=gby0BnUuTNFk,UwrnXuFkvEh9xRs5Z1=gby0BnUuTNFk):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	JmMO69oYEwIj,N1FbhV4lx6QcWOo,N9bXKIfsDVPjctLM5u = ZZV4kLG1nmbIjt(Dak6tVP8I7zdT5329ijCLFwGsgMo)
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
	OFlhCn7jy3vTA9VSesDx = [gby0BnUuTNFk,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not kVGU1uhays3EWfH:
		if not N9bXKIfsDVPjctLM5u:
			if   '_IPTV-LIVE_' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[1]
			elif '_IPTV-MOVIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[2]
			elif '_IPTV-SERIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[3]
			else: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[0]
		else:
			k4T65Vrzap3sL7Z9ybW = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			JlbGIYdQZkvtqjmR5r7 = i4r2OdGLlMhDEWfCVU0TKe3('أختر البحث المناسب', k4T65Vrzap3sL7Z9ybW)
			if JlbGIYdQZkvtqjmR5r7==-1: return
			kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[JlbGIYdQZkvtqjmR5r7]
	JmMO69oYEwIj = JmMO69oYEwIj+'_NODIALOGS_'
	if Z27widCyESA: zzVD2aYBrXNtmGqwxcJ3eLTnIps(JmMO69oYEwIj,Z27widCyESA,kVGU1uhays3EWfH,UwrnXuFkvEh9xRs5Z1)
	else:
		for Z27widCyESA in range(1,kkpzPXS6F1ylG3WibMZTjwxR7UQtdH+1):
			zzVD2aYBrXNtmGqwxcJ3eLTnIps(JmMO69oYEwIj,str(Z27widCyESA),kVGU1uhays3EWfH,UwrnXuFkvEh9xRs5Z1)
		wAcHkmPB8a.menuItemsLIST[:] = sorted(wAcHkmPB8a.menuItemsLIST,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1].lower())
	return
def zzVD2aYBrXNtmGqwxcJ3eLTnIps(Dak6tVP8I7zdT5329ijCLFwGsgMo,Z27widCyESA,kVGU1uhays3EWfH=gby0BnUuTNFk,UwrnXuFkvEh9xRs5Z1=gby0BnUuTNFk):
	if not UwrnXuFkvEh9xRs5Z1: UwrnXuFkvEh9xRs5Z1 = '1'
	JmMO69oYEwIj,N1FbhV4lx6QcWOo,N9bXKIfsDVPjctLM5u = ZZV4kLG1nmbIjt(Dak6tVP8I7zdT5329ijCLFwGsgMo)
	if not Z27widCyESA: return
	if not hyIp9v5HJfP0nX8gZtF7Ti23UKGCak(Z27widCyESA,N9bXKIfsDVPjctLM5u): return
	if not JmMO69oYEwIj:
		JmMO69oYEwIj = vRoGedUjt2Ac6pIbufBX8sKy()
		if not JmMO69oYEwIj: return
	OFlhCn7jy3vTA9VSesDx = [gby0BnUuTNFk,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not kVGU1uhays3EWfH:
		if not N9bXKIfsDVPjctLM5u:
			if   '_IPTV-LIVE_' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[1]
			elif '_IPTV-MOVIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[2]
			elif '_IPTV-SERIES' in N1FbhV4lx6QcWOo: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[3]
			else: kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[0]
		else:
			k4T65Vrzap3sL7Z9ybW = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			JlbGIYdQZkvtqjmR5r7 = i4r2OdGLlMhDEWfCVU0TKe3('أختر البحث المناسب', k4T65Vrzap3sL7Z9ybW)
			if JlbGIYdQZkvtqjmR5r7==-1: return
			kVGU1uhays3EWfH = OFlhCn7jy3vTA9VSesDx[JlbGIYdQZkvtqjmR5r7]
	HRcCyi6sX0tZNjBwDKlrGmk = JmMO69oYEwIj.lower()
	WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,'SEARCH')
	PgTIFSCwRY3haxjiok = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list','SEARCH',(kVGU1uhays3EWfH,HRcCyi6sX0tZNjBwDKlrGmk))
	if not PgTIFSCwRY3haxjiok:
		RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ = [],[]
		if not kVGU1uhays3EWfH: g87gzmJhBN5kSHrQwEf = [1,2,3,4,5]
		else: g87gzmJhBN5kSHrQwEf = [OFlhCn7jy3vTA9VSesDx.index(kVGU1uhays3EWfH)]
		for ZOfCnxmPUWEpvBVtYj5RSDMrcd in g87gzmJhBN5kSHrQwEf:
			WXZRrenmT8v = VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd])
			if ZOfCnxmPUWEpvBVtYj5RSDMrcd!=3:
				T7hyMuvVz9EqkOasZDSJ = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'dict',OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd])
				del T7hyMuvVz9EqkOasZDSJ['__COUNT__']
				del T7hyMuvVz9EqkOasZDSJ['__GROUPS__']
				del T7hyMuvVz9EqkOasZDSJ['__SEQUENCED_COLUMNS__']
				qleCEa50kOYvVNSJuDP1R4FdhtoIxw = list(T7hyMuvVz9EqkOasZDSJ.keys())
				for r9rIzYVD0ceyC1uUofpPJF45tWbR in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
					for EyvQhYU4jZoGuwtW7M9JXb,oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in T7hyMuvVz9EqkOasZDSJ[r9rIzYVD0ceyC1uUofpPJF45tWbR]:
						if HRcCyi6sX0tZNjBwDKlrGmk in oGVqE4JR3DIcTNtAghW9.lower(): ffgipIRaySJeEPmQ.append((oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
					del T7hyMuvVz9EqkOasZDSJ[r9rIzYVD0ceyC1uUofpPJF45tWbR]
				del T7hyMuvVz9EqkOasZDSJ
			else: qleCEa50kOYvVNSJuDP1R4FdhtoIxw = hak2AysNmEcZ5xuKOptV(WXZRrenmT8v,'list',OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd],'__GROUPS__')
			for r9rIzYVD0ceyC1uUofpPJF45tWbR in qleCEa50kOYvVNSJuDP1R4FdhtoIxw:
				try: r9rIzYVD0ceyC1uUofpPJF45tWbR,Eoyrc5lpZQdsfbq3jtzSWhxKUGM = r9rIzYVD0ceyC1uUofpPJF45tWbR
				except: Eoyrc5lpZQdsfbq3jtzSWhxKUGM = gby0BnUuTNFk
				if HRcCyi6sX0tZNjBwDKlrGmk in r9rIzYVD0ceyC1uUofpPJF45tWbR.lower():
					if ZOfCnxmPUWEpvBVtYj5RSDMrcd!=3: h2ixLA9FTfVW15QpBjZtID0arN3y7 = r9rIzYVD0ceyC1uUofpPJF45tWbR
					else:
						KVxLWm5201GJnaIElF8ASUi,Nd0fkcwTIV2JhMLxKbD7Go1e9A = r9rIzYVD0ceyC1uUofpPJF45tWbR.split('__SERIES__')
						if HRcCyi6sX0tZNjBwDKlrGmk in KVxLWm5201GJnaIElF8ASUi.lower(): h2ixLA9FTfVW15QpBjZtID0arN3y7 = KVxLWm5201GJnaIElF8ASUi
						else: h2ixLA9FTfVW15QpBjZtID0arN3y7 = Nd0fkcwTIV2JhMLxKbD7Go1e9A
					RRjw4NMhdxlQoFiO1fZCuKc.append((r9rIzYVD0ceyC1uUofpPJF45tWbR,h2ixLA9FTfVW15QpBjZtID0arN3y7,OFlhCn7jy3vTA9VSesDx[ZOfCnxmPUWEpvBVtYj5RSDMrcd],Eoyrc5lpZQdsfbq3jtzSWhxKUGM))
			del qleCEa50kOYvVNSJuDP1R4FdhtoIxw
		RRjw4NMhdxlQoFiO1fZCuKc = set(RRjw4NMhdxlQoFiO1fZCuKc)
		ffgipIRaySJeEPmQ = set(ffgipIRaySJeEPmQ)
		RRjw4NMhdxlQoFiO1fZCuKc = sorted(RRjw4NMhdxlQoFiO1fZCuKc,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[1])
		ffgipIRaySJeEPmQ = sorted(ffgipIRaySJeEPmQ,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao[0])
		CExrgJh48PYI2(WXZRrenmT8v,'SEARCH',(kVGU1uhays3EWfH,HRcCyi6sX0tZNjBwDKlrGmk),(RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ),Z83rChqtg1oXUjI4YL)
	else: RRjw4NMhdxlQoFiO1fZCuKc,ffgipIRaySJeEPmQ = PgTIFSCwRY3haxjiok
	qleCEa50kOYvVNSJuDP1R4FdhtoIxw = len(RRjw4NMhdxlQoFiO1fZCuKc)
	SjFdfrleWyqA9QIB = len(ffgipIRaySJeEPmQ)
	LL4W9eHQmsxZ = int(UwrnXuFkvEh9xRs5Z1)
	UhIg7pn4wxLXPJG3VH6M0oWzEjvO = max(0,(LL4W9eHQmsxZ-1)*100)
	jEYe1imyKQOcgBhM4X = max(0,LL4W9eHQmsxZ*100)
	XKBi93PeRLzw0NjZSYVmf = max(0,UhIg7pn4wxLXPJG3VH6M0oWzEjvO-qleCEa50kOYvVNSJuDP1R4FdhtoIxw)
	l8iSjTnkEzf3Be4M9 = max(0,jEYe1imyKQOcgBhM4X-qleCEa50kOYvVNSJuDP1R4FdhtoIxw)
	for r9rIzYVD0ceyC1uUofpPJF45tWbR,h2ixLA9FTfVW15QpBjZtID0arN3y7,dsMGf6S2kKcFOBHAuhjq83EoY,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in RRjw4NMhdxlQoFiO1fZCuKc[UhIg7pn4wxLXPJG3VH6M0oWzEjvO:jEYe1imyKQOcgBhM4X]:
		ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+h2ixLA9FTfVW15QpBjZtID0arN3y7,dsMGf6S2kKcFOBHAuhjq83EoY,234,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,'1',r9rIzYVD0ceyC1uUofpPJF45tWbR,gby0BnUuTNFk,{'folder':Z27widCyESA})
	del RRjw4NMhdxlQoFiO1fZCuKc
	for oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,Eoyrc5lpZQdsfbq3jtzSWhxKUGM in ffgipIRaySJeEPmQ[XKBi93PeRLzw0NjZSYVmf:l8iSjTnkEzf3Be4M9]:
		t6GiBhlvwIjD0RY = ymlrSBXjxRaY5kcKtU7MTVpAfeJL(UJeuWoLKP7ZI15O4ypTVs8caj)
		ZZrjMgRGiY2IDN7q = 'live'
		if '.mkv' in t6GiBhlvwIjD0RY or 'VOD' in kVGU1uhays3EWfH: ZZrjMgRGiY2IDN7q = 'video'
		ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,235,Eoyrc5lpZQdsfbq3jtzSWhxKUGM,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	del ffgipIRaySJeEPmQ
	mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,239,qleCEa50kOYvVNSJuDP1R4FdhtoIxw+SjFdfrleWyqA9QIB,JmMO69oYEwIj+'_NODIALOGS_')
	return
def mXreMsKFhIB1PqT0OQ8uLdGvi3w(Z27widCyESA,UwrnXuFkvEh9xRs5Z1,kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,LbeM6usxzdNjYTXJ7iOoKEDgAkHf,fbmZ9V58PCTz):
	if UwrnXuFkvEh9xRs5Z1!='1': ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'صفحة '+str(1),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(1),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	if not LbeM6usxzdNjYTXJ7iOoKEDgAkHf: LbeM6usxzdNjYTXJ7iOoKEDgAkHf = 0
	J7JD2UFyElmsMQdwIZc0rP = int(LbeM6usxzdNjYTXJ7iOoKEDgAkHf/100)+1
	for LL4W9eHQmsxZ in range(2,J7JD2UFyElmsMQdwIZc0rP):
		S3NTGxMIWYUHb68Ojy = (LL4W9eHQmsxZ%10==0 or int(UwrnXuFkvEh9xRs5Z1)-4<LL4W9eHQmsxZ<int(UwrnXuFkvEh9xRs5Z1)+4)
		JDhbLFOd9xEkpWjzcsC = (S3NTGxMIWYUHb68Ojy and int(UwrnXuFkvEh9xRs5Z1)-40<LL4W9eHQmsxZ<int(UwrnXuFkvEh9xRs5Z1)+40)
		if str(LL4W9eHQmsxZ)!=UwrnXuFkvEh9xRs5Z1 and (LL4W9eHQmsxZ%100==0 or JDhbLFOd9xEkpWjzcsC):
			ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'صفحة '+str(LL4W9eHQmsxZ),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(LL4W9eHQmsxZ),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	if str(J7JD2UFyElmsMQdwIZc0rP)!=UwrnXuFkvEh9xRs5Z1: ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+'أخر صفحة '+str(J7JD2UFyElmsMQdwIZc0rP),kVGU1uhays3EWfH,mi63FgbZoVerXaTGNhsUkuR0ILQW,gby0BnUuTNFk,str(J7JD2UFyElmsMQdwIZc0rP),fbmZ9V58PCTz,gby0BnUuTNFk,{'folder':Z27widCyESA})
	return
def VuxAhGZF9bNyr02QEpHjn7XPYlSTz(Z27widCyESA,kVGU1uhays3EWfH):
	if 'SERIES' in kVGU1uhays3EWfH or 'VOD_ORIGINAL' in kVGU1uhays3EWfH: WXZRrenmT8v = I0oFsWqUfGcDdlx
	else: WXZRrenmT8v = bGZat8TIQDBiAwWYOn
	WXZRrenmT8v = WXZRrenmT8v.replace('___','_'+Z27widCyESA)
	return WXZRrenmT8v
def LLkMBuX17Dgil2Oxw0fSY(Z27widCyESA,kVGU1uhays3EWfH,THmdqUzOsy):
	QLsvCVdeuE,y5Cv1XOeJmLa4zDr,OTl0DRFHNiA,h5iRdFc13nsYS2MjPLgfNyGCtx,CKTBLx2pOZDrzXqj3Qcea = beDTGt1QHSI7Pul9BfOcC(Z27widCyESA)
	if not h5iRdFc13nsYS2MjPLgfNyGCtx: return
	vO65KkJHupCrocdLe = dWxL30fTGqPpl1z8Bo(Z27widCyESA)
	if   kVGU1uhays3EWfH=='XTREAM_LIVE_GROUPS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_live_categories'
	elif kVGU1uhays3EWfH=='XTREAM_VOD_GROUPS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_vod_categories'
	elif kVGU1uhays3EWfH=='XTREAM_SERIES_GROUPS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_series_categories'
	elif kVGU1uhays3EWfH=='XTREAM_LIVE_ITEMS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_live_streams&category_id='+THmdqUzOsy
	elif kVGU1uhays3EWfH=='XTREAM_VOD_ITEMS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_vod_streams&category_id='+THmdqUzOsy
	elif kVGU1uhays3EWfH=='XTREAM_SERIES_ITEMS': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_series&category_id='+THmdqUzOsy
	elif kVGU1uhays3EWfH=='XTREAM_EPISODES': UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE+'&action=get_series_info&series_id='+THmdqUzOsy
	else: return
	WeCU3qEsGrDNfh1tmXHVOZgPalK = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',UJeuWoLKP7ZI15O4ypTVs8caj,gby0BnUuTNFk,vO65KkJHupCrocdLe,gby0BnUuTNFk,gby0BnUuTNFk,'IPTV-XTREAM_MENUS-1st')
	LviwW2t5HRmCMpxOqhDFo4d = WeCU3qEsGrDNfh1tmXHVOZgPalK.content
	if cAIRPFK6boejVU549WzqBGCaJ0r: LviwW2t5HRmCMpxOqhDFo4d = LviwW2t5HRmCMpxOqhDFo4d.decode(JJQFjSIlALchiMzG9).encode(JJQFjSIlALchiMzG9)
	aL9Gf2scU4Wbp6xl = TqNUy3Z4SFWvplGwXC82A('list',LviwW2t5HRmCMpxOqhDFo4d)
	if 'GROUPS' in kVGU1uhays3EWfH:
		kVGU1uhays3EWfH = kVGU1uhays3EWfH.replace('_GROUPS','_ITEMS')
		aL9Gf2scU4Wbp6xl = sorted(aL9Gf2scU4Wbp6xl,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao['category_name'].lower())
		for r9rIzYVD0ceyC1uUofpPJF45tWbR in aL9Gf2scU4Wbp6xl:
			Mc6lb5QCgYi = r9rIzYVD0ceyC1uUofpPJF45tWbR['category_id']
			oGVqE4JR3DIcTNtAghW9 = r9rIzYVD0ceyC1uUofpPJF45tWbR['category_name']
			ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,kVGU1uhays3EWfH,285,gby0BnUuTNFk,gby0BnUuTNFk,str(Mc6lb5QCgYi),gby0BnUuTNFk,{'folder':Z27widCyESA})
	elif kVGU1uhays3EWfH=='XTREAM_SERIES_ITEMS':
		aL9Gf2scU4Wbp6xl = sorted(aL9Gf2scU4Wbp6xl,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao['name'].lower())
		for CdvLfB5YOIHaQkUoGnZ6tXWJs in aL9Gf2scU4Wbp6xl:
			oGVqE4JR3DIcTNtAghW9 = CdvLfB5YOIHaQkUoGnZ6tXWJs['name']
			bxTDyYw3SV82Pt = CdvLfB5YOIHaQkUoGnZ6tXWJs['cover']
			Mc6lb5QCgYi = CdvLfB5YOIHaQkUoGnZ6tXWJs['series_id']
			ygWIQGf25qwVxLkXrYDjp('folder',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,'XTREAM_EPISODES',285,bxTDyYw3SV82Pt,gby0BnUuTNFk,str(Mc6lb5QCgYi),gby0BnUuTNFk,{'folder':Z27widCyESA})
	elif kVGU1uhays3EWfH=='XTREAM_EPISODES':
		bxTDyYw3SV82Pt = aL9Gf2scU4Wbp6xl['info']['cover']
		DPkEMfnRe82d = aL9Gf2scU4Wbp6xl['info']['name']
		yg4JelLRU5CQtI637FA = aL9Gf2scU4Wbp6xl['episodes']
		for toN50BX8dUinAegbhMq73GrpQy6V in yg4JelLRU5CQtI637FA:
			LLq1IUFacyB5VXCdx = yg4JelLRU5CQtI637FA[toN50BX8dUinAegbhMq73GrpQy6V]
			for m1GszFAbYWRtZe in LLq1IUFacyB5VXCdx:
				oGVqE4JR3DIcTNtAghW9 = m1GszFAbYWRtZe['title']
				SRGJLIAcaVNFomyeDZbXi4Ut = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('\d+.(S\d+E\d+)',oGVqE4JR3DIcTNtAghW9,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
				if SRGJLIAcaVNFomyeDZbXi4Ut: oGVqE4JR3DIcTNtAghW9 = DPkEMfnRe82d+UpN1CezytPO9XoduhxZSD+SRGJLIAcaVNFomyeDZbXi4Ut[0]
				Mc6lb5QCgYi = m1GszFAbYWRtZe['id']
				P2P1XfYIdBOoWyGMrvScZmzh6lu = m1GszFAbYWRtZe['container_extension']
				UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE.split('/player_api.php')[0]+'/series/'+h5iRdFc13nsYS2MjPLgfNyGCtx+'/'+CKTBLx2pOZDrzXqj3Qcea+'/'+str(Mc6lb5QCgYi)+'.'+P2P1XfYIdBOoWyGMrvScZmzh6lu
				ygWIQGf25qwVxLkXrYDjp('video',IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,235,bxTDyYw3SV82Pt,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	elif 'ITEMS' in kVGU1uhays3EWfH:
		ZZrjMgRGiY2IDN7q = 'live' if 'LIVE' in kVGU1uhays3EWfH else 'video'
		aL9Gf2scU4Wbp6xl = sorted(aL9Gf2scU4Wbp6xl,reverse=False,key=lambda VVPgcXqOTRbEUBmk2ao: VVPgcXqOTRbEUBmk2ao['name'].lower())
		for QIVLlH4KNGCySWepz1wsMPER2bt9f in aL9Gf2scU4Wbp6xl:
			oGVqE4JR3DIcTNtAghW9 = QIVLlH4KNGCySWepz1wsMPER2bt9f['name']
			bxTDyYw3SV82Pt = QIVLlH4KNGCySWepz1wsMPER2bt9f['stream_icon']
			Mc6lb5QCgYi = QIVLlH4KNGCySWepz1wsMPER2bt9f['stream_id']
			try:
				P2P1XfYIdBOoWyGMrvScZmzh6lu = QIVLlH4KNGCySWepz1wsMPER2bt9f['container_extension']
				if P2P1XfYIdBOoWyGMrvScZmzh6lu: P2P1XfYIdBOoWyGMrvScZmzh6lu = '.'+P2P1XfYIdBOoWyGMrvScZmzh6lu
			except: P2P1XfYIdBOoWyGMrvScZmzh6lu = gby0BnUuTNFk
			if QIVLlH4KNGCySWepz1wsMPER2bt9f['stream_type']=='live': Qw87uAPEDiOabR31,VcJ3oy4jdr2p8OXzYM = gby0BnUuTNFk,'live'
			elif QIVLlH4KNGCySWepz1wsMPER2bt9f['stream_type']=='movie': Qw87uAPEDiOabR31,VcJ3oy4jdr2p8OXzYM = 'movie/','video'
			UJeuWoLKP7ZI15O4ypTVs8caj = QLsvCVdeuE.split('/player_api.php')[0]+'/'+Qw87uAPEDiOabR31+h5iRdFc13nsYS2MjPLgfNyGCtx+'/'+CKTBLx2pOZDrzXqj3Qcea+'/'+str(Mc6lb5QCgYi)+P2P1XfYIdBOoWyGMrvScZmzh6lu
			ygWIQGf25qwVxLkXrYDjp(ZZrjMgRGiY2IDN7q,IvnA0yjpu5HDFS9UOawMqcVW+oGVqE4JR3DIcTNtAghW9,UJeuWoLKP7ZI15O4ypTVs8caj,235,bxTDyYw3SV82Pt,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,{'folder':Z27widCyESA})
	return
def N3NqxCYlUkuSAGb4meh(Z27widCyESA):
	LjRQAE38xSeub = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.language.provider')
	JugE9FAshRvzo4lXYPfiCZqSjpeIH = SF3Htydw7Y5sgjIE0OrLTKoQ.getSetting('av.language.code')
	dNqGfAEk0iXLwFU(la983tXRDchGbrdIFQJf7kHeE,'MENUS_CACHE_'+LjRQAE38xSeub+'_'+JugE9FAshRvzo4lXYPfiCZqSjpeIH,'%_IP'+Z27widCyESA+'_%')
	return