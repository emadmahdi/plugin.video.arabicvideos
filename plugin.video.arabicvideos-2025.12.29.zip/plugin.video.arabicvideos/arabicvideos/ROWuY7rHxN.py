# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'IFILM'
JB9fyoHr05QOtPjp = '_IFL_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
o5lILcsXUd9 = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][1]
pdHZtCkK1x = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][2]
Zj7IqcUXv8DETfB0 = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][3]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,kdwXYDMQOjz51Z08W,text):
	if   mode==20: WjryKiBebavP = T9QpxRXWveSUjMs()
	elif mode==21: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS(url)
	elif mode==22: WjryKiBebavP = Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W)
	elif mode==23: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,kdwXYDMQOjz51Z08W)
	elif mode==24: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,text)
	elif mode==25: WjryKiBebavP = qNV7Un5DsBKF6G9RgkZyIeLMjwxh8(url)
	elif mode==27: WjryKiBebavP = fZiYAJH1PcQI2O6LyX4rgT9au8l(url)
	elif mode==28: WjryKiBebavP = jGKWuTIdt9z750cleyAYhC()
	elif mode==29: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def T9QpxRXWveSUjMs():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'عربي',LhFnEIuPHdoNc,21,gby0BnUuTNFk,'101')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'English',o5lILcsXUd9,21,gby0BnUuTNFk,'101')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فارسى',pdHZtCkK1x,21,gby0BnUuTNFk,'101')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فارسى 2',Zj7IqcUXv8DETfB0,21,gby0BnUuTNFk,'101')
	return
def jGKWuTIdt9z750cleyAYhC():
	ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'عربي',LhFnEIuPHdoNc,27)
	ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'English',o5lILcsXUd9,27)
	ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'فارسى',pdHZtCkK1x,27)
	ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'فارسى 2',Zj7IqcUXv8DETfB0,27)
	return
def x3xMQCnNkl9vPuDiBdV0UswS(LzFyqHVx5Ed):
	CC3nOPFMovd72u = LzFyqHVx5Ed
	if LzFyqHVx5Ed=='IFILM-ARABIC': LzFyqHVx5Ed = LhFnEIuPHdoNc
	elif LzFyqHVx5Ed=='IFILM-ENGLISH': LzFyqHVx5Ed = o5lILcsXUd9
	else: CC3nOPFMovd72u = gby0BnUuTNFk
	CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(LzFyqHVx5Ed)
	if CMrTzQdR72uh9t8Yb4S=='ar' or CC3nOPFMovd72u=='IFILM-ARABIC':
		wCqLWtb40GAIK9EUe1ikSrFdh = 'بحث في الموقع'
		zBsWAhdqRc0NMjfkVPmvt4rKG215T = 'مسلسلات - حالية'
		sMiRfjzPx90H8mEpD = 'مسلسلات - أحدث'
		zKQj0YUiT7Fl4Os9BAt = 'مسلسلات - أبجدي'
		X6FDAPntmC4 = 'بث حي آي فيلم'
		qYXK69ZsDxhN = 'أفلام'
		Ny5ETL0Kqu3O6XisCrv = 'موسيقى'
		mmXZErdCPWtoqvkb = 'برامج'
	elif CMrTzQdR72uh9t8Yb4S=='en' or CC3nOPFMovd72u=='IFILM-ENGLISH':
		wCqLWtb40GAIK9EUe1ikSrFdh = 'Search in site'
		zBsWAhdqRc0NMjfkVPmvt4rKG215T = 'Series - Current'
		sMiRfjzPx90H8mEpD = 'Series - Latest'
		zKQj0YUiT7Fl4Os9BAt = 'Series - Alphabet'
		X6FDAPntmC4 = 'Live iFilm channel'
		qYXK69ZsDxhN = 'Movies'
		Ny5ETL0Kqu3O6XisCrv = 'Music'
		mmXZErdCPWtoqvkb = 'Shows'
	elif CMrTzQdR72uh9t8Yb4S in ['fa','fa2']:
		wCqLWtb40GAIK9EUe1ikSrFdh = 'جستجو در سایت'
		zBsWAhdqRc0NMjfkVPmvt4rKG215T = 'سريال - جاری'
		sMiRfjzPx90H8mEpD = 'سريال - آخرین'
		zKQj0YUiT7Fl4Os9BAt = 'سريال - الفبا'
		X6FDAPntmC4 = 'پخش زنده اي فيلم'
		qYXK69ZsDxhN = 'فيلم'
		Ny5ETL0Kqu3O6XisCrv = 'موسيقى'
		mmXZErdCPWtoqvkb = 'برنامه ها'
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+wCqLWtb40GAIK9EUe1ikSrFdh,LzFyqHVx5Ed,29,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('live',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+X6FDAPntmC4,LzFyqHVx5Ed,27)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	vDOcF6sdlBTWr3 = ['Series','Program','Music']
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,LzFyqHVx5Ed+'/home',gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb=ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('button-menu(.*?)/Contact',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if any(value in SSqweDUBYv4bkO for value in vDOcF6sdlBTWr3):
				url = LzFyqHVx5Ed+SSqweDUBYv4bkO
				if 'Series' in SSqweDUBYv4bkO:
					ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,url,22,gby0BnUuTNFk,'100')
					ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+sMiRfjzPx90H8mEpD,url,22,gby0BnUuTNFk,'101')
					ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+zKQj0YUiT7Fl4Os9BAt,url,22,gby0BnUuTNFk,'201')
				elif 'Film' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+qYXK69ZsDxhN,url,22,gby0BnUuTNFk,'100')
				elif 'Music' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+Ny5ETL0Kqu3O6XisCrv,url,25,gby0BnUuTNFk,'101')
				elif 'Program' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+mmXZErdCPWtoqvkb,url,22,gby0BnUuTNFk,'101')
	return jS6fQGXeouTB7xKd32ZMy
def qNV7Un5DsBKF6G9RgkZyIeLMjwxh8(url):
	LzFyqHVx5Ed = ue3ZwKgy2CE0YFGQJ5(url)
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(Q3J7xTKDuAUoaPlB,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-MUSIC_MENU-1st')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('Music-tools-header(.*?)Music-body',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	title = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<p>(.*?)</p>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)[0]
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,22,gby0BnUuTNFk,'101')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LzFyqHVx5Ed + SSqweDUBYv4bkO
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,23,gby0BnUuTNFk,'101')
	return
def Xw3tTz8UD4LK26C(url,kdwXYDMQOjz51Z08W):
	LzFyqHVx5Ed = ue3ZwKgy2CE0YFGQJ5(url)
	CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url)
	type = url.split('/')[-1]
	eV2sIbZxgYDMTkEiyz0omS53j = str(int(kdwXYDMQOjz51Z08W)//100)
	kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)%100)
	if type=='Series' and kdwXYDMQOjz51Z08W=='0':
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-TITLES-1st')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('serial-body(.*?)class="row',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			title = Y7BxKQdU84R(title)
			SSqweDUBYv4bkO = LzFyqHVx5Ed + SSqweDUBYv4bkO
			T6TRUSbecYGWIq29KF = LzFyqHVx5Ed + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,23,T6TRUSbecYGWIq29KF,eV2sIbZxgYDMTkEiyz0omS53j+'01')
	tRuqCwDg0er=0
	if type=='Series': zTFlfH8DhAVryqUjX='3'
	if type=='Film': zTFlfH8DhAVryqUjX='5'
	if type=='Program': zTFlfH8DhAVryqUjX='7'
	if type in ['Series','Program','Film'] and kdwXYDMQOjz51Z08W!='0':
		Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Home/PageingItem?category='+zTFlfH8DhAVryqUjX+'&page='+kdwXYDMQOjz51Z08W+'&size=30&orderby='+eV2sIbZxgYDMTkEiyz0omS53j
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-TITLES-2nd')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,title,T6TRUSbecYGWIq29KF in items:
			title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
			title = title.replace('\\',gby0BnUuTNFk)
			title = title.replace('"',gby0BnUuTNFk)
			tRuqCwDg0er += 1
			SSqweDUBYv4bkO = LzFyqHVx5Ed + '/' + type + '/Content/' + id
			T6TRUSbecYGWIq29KF = LzFyqHVx5Ed + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
			if type=='Film': ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,24,T6TRUSbecYGWIq29KF,eV2sIbZxgYDMTkEiyz0omS53j+'01')
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,23,T6TRUSbecYGWIq29KF,eV2sIbZxgYDMTkEiyz0omS53j+'01')
	if type=='Music':
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,LzFyqHVx5Ed+'/Music/Index?page='+kdwXYDMQOjz51Z08W,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-TITLES-3rd')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pagination-demo(.*?)pagination-demo',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
			tRuqCwDg0er += 1
			T6TRUSbecYGWIq29KF = LzFyqHVx5Ed + T6TRUSbecYGWIq29KF
			SSqweDUBYv4bkO = LzFyqHVx5Ed + SSqweDUBYv4bkO
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,23,T6TRUSbecYGWIq29KF,'101')
	if tRuqCwDg0er>20:
		title='صفحة '
		if CMrTzQdR72uh9t8Yb4S=='en': title = 'Page '
		if CMrTzQdR72uh9t8Yb4S=='fa': title = 'صفحه '
		if CMrTzQdR72uh9t8Yb4S=='fa2': title = 'صفحه '
		for jzr3gwSik2yORxcoWGMq84QumvZV in range(1,11) :
			if not kdwXYDMQOjz51Z08W==str(jzr3gwSik2yORxcoWGMq84QumvZV):
				UCZlywinR9b1jruF = '0'+str(jzr3gwSik2yORxcoWGMq84QumvZV)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title+str(jzr3gwSik2yORxcoWGMq84QumvZV),url,22,gby0BnUuTNFk,eV2sIbZxgYDMTkEiyz0omS53j+UCZlywinR9b1jruF[-2:])
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,kdwXYDMQOjz51Z08W):
	if not kdwXYDMQOjz51Z08W: kdwXYDMQOjz51Z08W = 0
	LzFyqHVx5Ed = ue3ZwKgy2CE0YFGQJ5(url)
	CEuKjPawITk = ue3ZwKgy2CE0YFGQJ5(url)
	CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url)
	rO9QBRygx3sqJcH5kZTM1uS74D = url.split('/')
	id,type = rO9QBRygx3sqJcH5kZTM1uS74D[-1],rO9QBRygx3sqJcH5kZTM1uS74D[3]
	eV2sIbZxgYDMTkEiyz0omS53j = str(int(kdwXYDMQOjz51Z08W)//100)
	kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)%100)
	tRuqCwDg0er = 0
	if type=='Series':
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-1st')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		title = ' - الحلقة '
		if CMrTzQdR72uh9t8Yb4S=='en': title = ' - Episode '
		if CMrTzQdR72uh9t8Yb4S=='fa': title = ' - قسمت '
		if CMrTzQdR72uh9t8Yb4S=='fa2': title = ' - قسمت '
		if CMrTzQdR72uh9t8Yb4S=='fa': bNuTZMAfBiVx1K2e = gby0BnUuTNFk
		else: bNuTZMAfBiVx1K2e = CMrTzQdR72uh9t8Yb4S
		WFel0nxSc9A2zC = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for name,count,T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO in items:
			for Cso7iV0ZOw2UW5Ez in range(int(count),0,-1):
				tAylnT8ZLfoMB5idOGqms4KkSa37 = T6TRUSbecYGWIq29KF + bNuTZMAfBiVx1K2e + id + '/' + str(Cso7iV0ZOw2UW5Ez) + '.png'
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = name + title + str(Cso7iV0ZOw2UW5Ez)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = Y7BxKQdU84R(zBsWAhdqRc0NMjfkVPmvt4rKG215T)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,url,24,tAylnT8ZLfoMB5idOGqms4KkSa37,gby0BnUuTNFk,str(Cso7iV0ZOw2UW5Ez))
	elif type=='Program':
		Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+kdwXYDMQOjz51Z08W+'&size=30&orderby=1'
		jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-2nd')
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		title = ' - الحلقة '
		if CMrTzQdR72uh9t8Yb4S=='en': title = ' - Episode '
		if CMrTzQdR72uh9t8Yb4S=='fa': title = ' - قسمت '
		if CMrTzQdR72uh9t8Yb4S=='fa2': title = ' - قسمت '
		for Cso7iV0ZOw2UW5Ez,T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,ggq2yeDHsR,name in items:
			tRuqCwDg0er += 1
			tAylnT8ZLfoMB5idOGqms4KkSa37 = CEuKjPawITk + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
			name = biVjhGCg0v5eEzkHwTrK9FIAtPU2(name)
			zBsWAhdqRc0NMjfkVPmvt4rKG215T = name + title + str(Cso7iV0ZOw2UW5Ez)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,Tf5ueYGZIFl1hraoEOVKi,24,tAylnT8ZLfoMB5idOGqms4KkSa37,gby0BnUuTNFk,str(tRuqCwDg0er))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Music/GetTracksBy?id='+str(id)+'&page='+kdwXYDMQOjz51Z08W+'&size=30&type=0'
			jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-3rd')
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,name,title in items:
				tRuqCwDg0er += 1
				tAylnT8ZLfoMB5idOGqms4KkSa37 = CEuKjPawITk + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = name + ' - ' + title
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = zBsWAhdqRc0NMjfkVPmvt4rKG215T.strip(UpN1CezytPO9XoduhxZSD)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = biVjhGCg0v5eEzkHwTrK9FIAtPU2(zBsWAhdqRc0NMjfkVPmvt4rKG215T)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,Tf5ueYGZIFl1hraoEOVKi,24,tAylnT8ZLfoMB5idOGqms4KkSa37,gby0BnUuTNFk,str(tRuqCwDg0er))
		elif 'Clips' in url:
			Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Music/GetTracksBy?id=0&page='+kdwXYDMQOjz51Z08W+'&size=30&type=15'
			jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-4th')
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for T6TRUSbecYGWIq29KF,title,SSqweDUBYv4bkO in items:
				tRuqCwDg0er += 1
				tAylnT8ZLfoMB5idOGqms4KkSa37 = CEuKjPawITk + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = title.strip(UpN1CezytPO9XoduhxZSD)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = biVjhGCg0v5eEzkHwTrK9FIAtPU2(zBsWAhdqRc0NMjfkVPmvt4rKG215T)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,Tf5ueYGZIFl1hraoEOVKi,24,tAylnT8ZLfoMB5idOGqms4KkSa37,gby0BnUuTNFk,str(tRuqCwDg0er))
		elif 'category' in url:
			if 'category=6' in url:
				Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Music/GetTracksBy?id=0&page='+kdwXYDMQOjz51Z08W+'&size=30&type=6'
				jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				Tf5ueYGZIFl1hraoEOVKi = LzFyqHVx5Ed+'/Music/GetTracksBy?id=0&page='+kdwXYDMQOjz51Z08W+'&size=30&type=4'
				jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-EPISODES-6th')
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,name,title in items:
				tRuqCwDg0er += 1
				tAylnT8ZLfoMB5idOGqms4KkSa37 = CEuKjPawITk + IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = name + ' - ' + title
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = zBsWAhdqRc0NMjfkVPmvt4rKG215T.strip(UpN1CezytPO9XoduhxZSD)
				zBsWAhdqRc0NMjfkVPmvt4rKG215T = biVjhGCg0v5eEzkHwTrK9FIAtPU2(zBsWAhdqRc0NMjfkVPmvt4rKG215T)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+zBsWAhdqRc0NMjfkVPmvt4rKG215T,Tf5ueYGZIFl1hraoEOVKi,24,tAylnT8ZLfoMB5idOGqms4KkSa37,gby0BnUuTNFk,str(tRuqCwDg0er))
	if type=='Music' or type=='Program':
		if tRuqCwDg0er>25:
			title='صفحة '
			if CMrTzQdR72uh9t8Yb4S=='en': title = ' Page '
			if CMrTzQdR72uh9t8Yb4S=='fa': title = ' صفحه '
			if CMrTzQdR72uh9t8Yb4S=='fa2': title = ' صفحه '
			for jzr3gwSik2yORxcoWGMq84QumvZV in range(1,11):
				if not kdwXYDMQOjz51Z08W==str(jzr3gwSik2yORxcoWGMq84QumvZV):
					UCZlywinR9b1jruF = '0'+str(jzr3gwSik2yORxcoWGMq84QumvZV)
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title+str(jzr3gwSik2yORxcoWGMq84QumvZV),url,23,gby0BnUuTNFk,eV2sIbZxgYDMTkEiyz0omS53j+UCZlywinR9b1jruF[-2:])
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,Cso7iV0ZOw2UW5Ez):
	CEuKjPawITk = ue3ZwKgy2CE0YFGQJ5(url)
	uufJivSZQyj45ql3,eE9BXgNu4MPKIbw2aLDl1AY3R = [],[]
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-PLAY-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url)
		rO9QBRygx3sqJcH5kZTM1uS74D = url.split('/')
		id,type = rO9QBRygx3sqJcH5kZTM1uS74D[-1],rO9QBRygx3sqJcH5kZTM1uS74D[3]
		SSqweDUBYv4bkO = items[0][0]+CMrTzQdR72uh9t8Yb4S+id+'/,'+Cso7iV0ZOw2UW5Ez+','+Cso7iV0ZOw2UW5Ez+'_'+items[0][2]
		uufJivSZQyj45ql3.append('m3u8')
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url)
		rO9QBRygx3sqJcH5kZTM1uS74D = url.split('/')
		id,type = rO9QBRygx3sqJcH5kZTM1uS74D[-1],rO9QBRygx3sqJcH5kZTM1uS74D[3]
		SSqweDUBYv4bkO = items[0][0]+CMrTzQdR72uh9t8Yb4S+id+'/'+Cso7iV0ZOw2UW5Ez+items[0][2]
		uufJivSZQyj45ql3.append('mp4 url')
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('source src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO in items:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('//','/')
		uufJivSZQyj45ql3.append('mp4 src')
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('VideoAddress":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		SSqweDUBYv4bkO = items[int(Cso7iV0ZOw2UW5Ez)-1]
		SSqweDUBYv4bkO = CEuKjPawITk+IcChbXakUDFLszgpSG2jqem9(SSqweDUBYv4bkO)
		uufJivSZQyj45ql3.append('mp4 address')
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('VoiceAddress":"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		SSqweDUBYv4bkO = items[int(Cso7iV0ZOw2UW5Ez)-1]
		SSqweDUBYv4bkO = CEuKjPawITk+IcChbXakUDFLszgpSG2jqem9(SSqweDUBYv4bkO)
		uufJivSZQyj45ql3.append('mp3 address')
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	if len(eE9BXgNu4MPKIbw2aLDl1AY3R)==1: SSqweDUBYv4bkO = eE9BXgNu4MPKIbw2aLDl1AY3R[0]
	else:
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('اختر الفيديو المناسب:', uufJivSZQyj45ql3)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1 : return
		SSqweDUBYv4bkO = eE9BXgNu4MPKIbw2aLDl1AY3R[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	YAQOL1eVvqMjsEfIFc(SSqweDUBYv4bkO,CC3nOPFMovd72u,'video')
	return
def ue3ZwKgy2CE0YFGQJ5(url):
	if LhFnEIuPHdoNc in url: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = LhFnEIuPHdoNc
	elif o5lILcsXUd9 in url: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = o5lILcsXUd9
	elif pdHZtCkK1x in url: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = pdHZtCkK1x
	elif Zj7IqcUXv8DETfB0 in url: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = Zj7IqcUXv8DETfB0
	else: gwiQ59eNbhY2SlLZB7aOpTDdsk1 = gby0BnUuTNFk
	return gwiQ59eNbhY2SlLZB7aOpTDdsk1
def kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url):
	if   LhFnEIuPHdoNc in url: CMrTzQdR72uh9t8Yb4S = 'ar'
	elif o5lILcsXUd9 in url: CMrTzQdR72uh9t8Yb4S = 'en'
	elif pdHZtCkK1x in url: CMrTzQdR72uh9t8Yb4S = 'fa'
	elif Zj7IqcUXv8DETfB0 in url: CMrTzQdR72uh9t8Yb4S = 'fa2'
	else: CMrTzQdR72uh9t8Yb4S = gby0BnUuTNFk
	return CMrTzQdR72uh9t8Yb4S
def fZiYAJH1PcQI2O6LyX4rgT9au8l(url):
	CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(url)
	Tf5ueYGZIFl1hraoEOVKi = url + '/Home/Live'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-LIVE-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('source src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	mm7pzl3HMi0R8fGu = items[0]
	YAQOL1eVvqMjsEfIFc(mm7pzl3HMi0R8fGu,CC3nOPFMovd72u,'live')
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	apTFWBhb175nwjvKtmJ2 = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	if showDialogs:
		z3tZ0MvXgEOa19l5mS = [ LhFnEIuPHdoNc , o5lILcsXUd9 , pdHZtCkK1x , Zj7IqcUXv8DETfB0 ]
		PYXSjrGHwWdz65ckR = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('اختر اللغة المناسبة:', PYXSjrGHwWdz65ckR)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc == -1 : return
		website = z3tZ0MvXgEOa19l5mS[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	else:
		if '_IFILM-ARABIC_' in K7ETgQ2pb4ylWIB3vDHjJ: website = LhFnEIuPHdoNc
		elif '_IFILM-ENGLISH_' in K7ETgQ2pb4ylWIB3vDHjJ: website = o5lILcsXUd9
		else: website = gby0BnUuTNFk
	if not website: return
	CMrTzQdR72uh9t8Yb4S = kaCqtx9e5uvVMTIK8ZwF3HdofPiWNb(website)
	Tf5ueYGZIFl1hraoEOVKi = website + "/Home/Search?searchstring=" + apTFWBhb175nwjvKtmJ2
	jS6fQGXeouTB7xKd32ZMy = OpLFUdaX4JRMcoV2Gqn098rgmtf(DNh1dgpa4BK,Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'IFILM-SEARCH-1st')
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if items:
		for T6TRUSbecYGWIq29KF,zTFlfH8DhAVryqUjX,id,title in items:
			if zTFlfH8DhAVryqUjX in ['3','7']:
				title = title.replace('\\',gby0BnUuTNFk)
				title = title.replace('"',gby0BnUuTNFk)
				if zTFlfH8DhAVryqUjX=='3':
					type = 'Series'
					if CMrTzQdR72uh9t8Yb4S=='ar': name = 'مسلسل : '
					elif CMrTzQdR72uh9t8Yb4S=='en': name = 'Series : '
					elif CMrTzQdR72uh9t8Yb4S=='fa': name = 'سريال ها : '
					elif CMrTzQdR72uh9t8Yb4S=='fa2': name = 'سريال ها : '
				elif zTFlfH8DhAVryqUjX=='5':
					type = 'Film'
					if CMrTzQdR72uh9t8Yb4S=='ar': name = 'فيلم : '
					elif CMrTzQdR72uh9t8Yb4S=='en': name = 'Movie : '
					elif CMrTzQdR72uh9t8Yb4S=='fa': name = 'فيلم : '
					elif CMrTzQdR72uh9t8Yb4S=='fa2': name = 'فلم ها : '
				elif zTFlfH8DhAVryqUjX=='7':
					type = 'Program'
					if CMrTzQdR72uh9t8Yb4S=='ar': name = 'برنامج : '
					elif CMrTzQdR72uh9t8Yb4S=='en': name = 'Program : '
					elif CMrTzQdR72uh9t8Yb4S=='fa': name = 'برنامه ها : '
					elif CMrTzQdR72uh9t8Yb4S=='fa2': name = 'برنامه ها : '
				title = name + title
				SSqweDUBYv4bkO = website + '/' + type + '/Content/' + id
				T6TRUSbecYGWIq29KF = IcChbXakUDFLszgpSG2jqem9(T6TRUSbecYGWIq29KF)
				T6TRUSbecYGWIq29KF = website+T6TRUSbecYGWIq29KF
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,23,T6TRUSbecYGWIq29KF,'101')
	return