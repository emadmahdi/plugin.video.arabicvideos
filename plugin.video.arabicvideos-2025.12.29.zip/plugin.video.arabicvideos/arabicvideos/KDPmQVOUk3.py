# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'DAILYMOTION'
JB9fyoHr05QOtPjp = '_DLM_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
o5lILcsXUd9 = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][1]
pdHZtCkK1x = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][2]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text,type,kdwXYDMQOjz51Z08W):
	if	 mode==400: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==401: WjryKiBebavP = BViyKj4YNJkh1LMP7t69vS8(url,text)
	elif mode==402: WjryKiBebavP = eilcGZWKuaApF0ITnN7Ozy15Sf(url,text)
	elif mode==403: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,text)
	elif mode==404: WjryKiBebavP = KDV3wNLCY1HSqWe2fMnd7FEhz(text,kdwXYDMQOjz51Z08W)
	elif mode==405: WjryKiBebavP = ZukgaXMETHJz0is3Ct(text,kdwXYDMQOjz51Z08W)
	elif mode==406: WjryKiBebavP = aa8nFgwy3KT(text,kdwXYDMQOjz51Z08W)
	elif mode==407: WjryKiBebavP = HNS3nQIDwReTakZ(url,kdwXYDMQOjz51Z08W)
	elif mode==408: WjryKiBebavP = q76ezsh9okyrcDOdnpJ0tFmiWfS(url,kdwXYDMQOjz51Z08W)
	elif mode==409: WjryKiBebavP = a3NI0EopMZw(text,kdwXYDMQOjz51Z08W)
	elif mode==411: WjryKiBebavP = eonTP1m5f7Z8iBO(url,text)
	elif mode==414: WjryKiBebavP = sCZ0VhGF9n2c5OwaYHEr(text)
	elif mode==415: WjryKiBebavP = nn37JOpGYIVcMBUrCgxfd(text,kdwXYDMQOjz51Z08W)
	elif mode==416: WjryKiBebavP = dWKvtyesakjZo7qF(text,kdwXYDMQOjz51Z08W)
	elif mode==417: WjryKiBebavP = nayTlm9uU5Wk(url,kdwXYDMQOjz51Z08W)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الرئيسية',gby0BnUuTNFk,414)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,409,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن فيديوهات',gby0BnUuTNFk,409,gby0BnUuTNFk,'videos?sortBy=','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن آخر الفيديوهات',gby0BnUuTNFk,409,gby0BnUuTNFk,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن الفيديوهات الأكثر مشاهدة',gby0BnUuTNFk,409,gby0BnUuTNFk,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن قوائم التشغيل',gby0BnUuTNFk,409,gby0BnUuTNFk,'playlists','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن مستخدم',gby0BnUuTNFk,409,gby0BnUuTNFk,'channels','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن بث حي',gby0BnUuTNFk,409,gby0BnUuTNFk,'lives','_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث عن هاشتاك',gby0BnUuTNFk,409,gby0BnUuTNFk,'hashtags','_REMEMBERRESULTS_')
	return
def eilcGZWKuaApF0ITnN7Ozy15Sf(url,m459Jn3iAuEZOpRBHsUcrW1lvth):
	if '/dm_' in url:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,False,gby0BnUuTNFk,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = ccV0NKHwQpMun6FtZvAi.headers
		if 'Location' in list(headers.keys()): url = LhFnEIuPHdoNc+headers['Location']
	m459Jn3iAuEZOpRBHsUcrW1lvth = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+m459Jn3iAuEZOpRBHsUcrW1lvth+GGy0cQe765nPYZ9E8Th
	m459Jn3iAuEZOpRBHsUcrW1lvth = PRdAbBICNtMDvfwqlWJH(m459Jn3iAuEZOpRBHsUcrW1lvth)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: بث حي',url,411,gby0BnUuTNFk,gby0BnUuTNFk,'channel_lives_now')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: آخر الفيديوهات',url+'/videos',408)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: المميزة',url,411,gby0BnUuTNFk,gby0BnUuTNFk,'channel_featured_videos')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: قوائم التشغيل',url+'/playlists',407)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+':: قنوات ذات صلة',url,411,gby0BnUuTNFk,gby0BnUuTNFk,'channel_related_channel')
	return
def PRdAbBICNtMDvfwqlWJH(title):
	title = title.rstrip('\\').strip(UpN1CezytPO9XoduhxZSD).replace('\\\\','\\')
	title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(title)
	return title
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url,kcZH1dOl3xQEnYjsMwmvb):
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb([url],CC3nOPFMovd72u,'video',url)
	return
def KDV3wNLCY1HSqWe2fMnd7FEhz(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = gby0BnUuTNFk
	search = search.split('/videos')[0]
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	if sort==gby0BnUuTNFk: Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysortmethod',gby0BnUuTNFk)
	else: Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = LhFnEIuPHdoNc+'/search/'+search+'/videos'
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"videos"(.*?)"VideoConnection"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,title,eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth,a8tFl4fNpx2Ou65q,T6TRUSbecYGWIq29KF in items:
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+id
			title = PRdAbBICNtMDvfwqlWJH(title)
			kcZH1dOl3xQEnYjsMwmvb = eTPzQ97OIwtE2mj+'::'+m459Jn3iAuEZOpRBHsUcrW1lvth
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q,kcZH1dOl3xQEnYjsMwmvb)
		if '"hasNextPage":true' in jS6fQGXeouTB7xKd32ZMy:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,404,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def ZukgaXMETHJz0is3Ct(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	url = LhFnEIuPHdoNc+'/search/'+search+'/playlists'
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for id,name,EY7wsRferi6PjkSpItolM8cUKa0,eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth,T6TRUSbecYGWIq29KF,count in items:
		T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = PRdAbBICNtMDvfwqlWJH(title)
		kcZH1dOl3xQEnYjsMwmvb = eTPzQ97OIwtE2mj+'::'+m459Jn3iAuEZOpRBHsUcrW1lvth
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,401,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,kcZH1dOl3xQEnYjsMwmvb)
	if '"hasNextPage":true' in jS6fQGXeouTB7xKd32ZMy:
		kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,405,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def aa8nFgwy3KT(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	url = LhFnEIuPHdoNc+'/search/'+search+'/channels'
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"channels"(.*?)"ChannelConnection"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,name,T6TRUSbecYGWIq29KF in items:
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+id
			title = 'USER:  '+name
			title = PRdAbBICNtMDvfwqlWJH(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,402,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,name)
		if '"hasNextPage":true' in jS6fQGXeouTB7xKd32ZMy:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,406,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def sCZ0VhGF9n2c5OwaYHEr(IIp9ngKElqCOGPTkJBzHt2bQx6sVN):
	Z05rTiu6LwakteK8VfY = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['home']['neon']['sections']['edges']
		if not IIp9ngKElqCOGPTkJBzHt2bQx6sVN:
			qIfVaBJm7OUlXyHFQsjdR9NZ1 = []
			for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
				PXuS52YInRqws0kt9L4KaJ = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['title']
				if PXuS52YInRqws0kt9L4KaJ not in qIfVaBJm7OUlXyHFQsjdR9NZ1: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+PXuS52YInRqws0kt9L4KaJ,gby0BnUuTNFk,414,gby0BnUuTNFk,gby0BnUuTNFk,PXuS52YInRqws0kt9L4KaJ)
				qIfVaBJm7OUlXyHFQsjdR9NZ1.append(PXuS52YInRqws0kt9L4KaJ)
		else:
			for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
				PXuS52YInRqws0kt9L4KaJ = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['title']
				if PXuS52YInRqws0kt9L4KaJ==IIp9ngKElqCOGPTkJBzHt2bQx6sVN:
					igq1pLoFnjaJ7K9TmkSPtQI6 = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['components']['edges']
					for h8hEVqMYWzvl4pDgQGBJCRZ9FT in igq1pLoFnjaJ7K9TmkSPtQI6:
						a8tFl4fNpx2Ou65q = str(h8hEVqMYWzvl4pDgQGBJCRZ9FT['node']['duration'])
						title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(h8hEVqMYWzvl4pDgQGBJCRZ9FT['node']['title'])
						title = title.replace('\/','/')
						nbeh8JY5UyuZMHNj9tD = h8hEVqMYWzvl4pDgQGBJCRZ9FT['node']['xid']
						T6TRUSbecYGWIq29KF = h8hEVqMYWzvl4pDgQGBJCRZ9FT['node']['thumbnailx480']
						T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
						SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+nbeh8JY5UyuZMHNj9tD
						ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
	return
def nn37JOpGYIVcMBUrCgxfd(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	url = LhFnEIuPHdoNc+'/search/'+search+'/lives'
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		try: Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['search']['lives']['edges']
		except: Iera3VwFMQbRSCUGuK = []
		for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
			name = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['title']
			name = biVjhGCg0v5eEzkHwTrK9FIAtPU2(name)
			nbeh8JY5UyuZMHNj9tD = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['xid']
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+nbeh8JY5UyuZMHNj9tD
			ygWIQGf25qwVxLkXrYDjp('live',JB9fyoHr05QOtPjp+'LIVE: '+name,SSqweDUBYv4bkO,403)
		if '"hasNextPage":true' in f9uiQLrO2C4xGDMKldYkU5phJo:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,415,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def q3P8oeCMUx7B1WfyAVK(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	url = LhFnEIuPHdoNc+'/search/'+search+'/topics'
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		try: Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['search']['topics']['edges']
		except: Iera3VwFMQbRSCUGuK = []
		for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
			name = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['name']
			nbeh8JY5UyuZMHNj9tD = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['xid']
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/topic/'+nbeh8JY5UyuZMHNj9tD
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'TOPIC: '+name,SSqweDUBYv4bkO,413)
		if '"hasNextPage":true' in f9uiQLrO2C4xGDMKldYkU5phJo:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,412,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def yyWs4mqPZ7xTj(url,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	nbeh8JY5UyuZMHNj9tD = url.split('/')[-1]
	Z05rTiu6LwakteK8VfY = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mytopicid',nbeh8JY5UyuZMHNj9tD)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['topic']['videos']['edges']
		for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
			a8tFl4fNpx2Ou65q = str(H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['duration'])
			title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['title'])
			title = title.replace('\/','/')
			nbeh8JY5UyuZMHNj9tD = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['xid']
			T6TRUSbecYGWIq29KF = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['thumbnailx480']
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+nbeh8JY5UyuZMHNj9tD
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
		if '"hasNextPage":true' in f9uiQLrO2C4xGDMKldYkU5phJo:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,413,gby0BnUuTNFk,kdwXYDMQOjz51Z08W)
	return
def BViyKj4YNJkh1LMP7t69vS8(url,kcZH1dOl3xQEnYjsMwmvb):
	id = url.split('/')[-1]
	eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth = kcZH1dOl3xQEnYjsMwmvb.split('::',1)
	SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+eTPzQ97OIwtE2mj
	m459Jn3iAuEZOpRBHsUcrW1lvth = PRdAbBICNtMDvfwqlWJH(m459Jn3iAuEZOpRBHsUcrW1lvth)
	title = MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+'OWNER:  '+m459Jn3iAuEZOpRBHsUcrW1lvth+GGy0cQe765nPYZ9E8Th
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,402,gby0BnUuTNFk,gby0BnUuTNFk,m459Jn3iAuEZOpRBHsUcrW1lvth)
	Z05rTiu6LwakteK8VfY = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('myplaylistid',id)
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"collection_videos"(.*?)"SectionEdge"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,title,a8tFl4fNpx2Ou65q,T6TRUSbecYGWIq29KF,eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth in items:
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+id
			title = PRdAbBICNtMDvfwqlWJH(title)
			kcZH1dOl3xQEnYjsMwmvb = eTPzQ97OIwtE2mj+'::'+m459Jn3iAuEZOpRBHsUcrW1lvth
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q,kcZH1dOl3xQEnYjsMwmvb)
	return
def q76ezsh9okyrcDOdnpJ0tFmiWfS(url,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	oH4W1v6egkntP8FXIORqj2 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mychannelid',oH4W1v6egkntP8FXIORqj2)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysortmethod',sort)
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,title,a8tFl4fNpx2Ou65q,eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth,T6TRUSbecYGWIq29KF in items:
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+id
			title = PRdAbBICNtMDvfwqlWJH(title)
			kcZH1dOl3xQEnYjsMwmvb = eTPzQ97OIwtE2mj+'::'+m459Jn3iAuEZOpRBHsUcrW1lvth
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q,kcZH1dOl3xQEnYjsMwmvb)
		if '"hasNextPage":true' in jS6fQGXeouTB7xKd32ZMy:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,408,gby0BnUuTNFk,kdwXYDMQOjz51Z08W)
	return
def HNS3nQIDwReTakZ(url,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	oH4W1v6egkntP8FXIORqj2 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mychannelid',oH4W1v6egkntP8FXIORqj2)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysortmethod',sort)
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for id,name,T6TRUSbecYGWIq29KF,count,EY7wsRferi6PjkSpItolM8cUKa0,eTPzQ97OIwtE2mj,m459Jn3iAuEZOpRBHsUcrW1lvth in items:
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = PRdAbBICNtMDvfwqlWJH(title)
			kcZH1dOl3xQEnYjsMwmvb = eTPzQ97OIwtE2mj+'::'+m459Jn3iAuEZOpRBHsUcrW1lvth
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,401,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,kcZH1dOl3xQEnYjsMwmvb)
		if '"hasNextPage":true' in jS6fQGXeouTB7xKd32ZMy:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,407,gby0BnUuTNFk,kdwXYDMQOjz51Z08W)
	return
def eonTP1m5f7Z8iBO(url,fx876jQHz3LCuOFcops1ESMgDI5ya):
	oH4W1v6egkntP8FXIORqj2 = url.split('/')[3]
	Z05rTiu6LwakteK8VfY = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mychannelid',oH4W1v6egkntP8FXIORqj2)
	jS6fQGXeouTB7xKd32ZMy = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	twnlqRfcULYOs8SIrmbi = FoCsyPaNjhWf.loads(jS6fQGXeouTB7xKd32ZMy)
	try: items = twnlqRfcULYOs8SIrmbi['data']['channel'][fx876jQHz3LCuOFcops1ESMgDI5ya]['edges']
	except: items = []
	if not items: ygWIQGf25qwVxLkXrYDjp('link',JB9fyoHr05QOtPjp+'لا توجد نتائج',gby0BnUuTNFk,9999)
	else:
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wqDAFH1cC0LYSdzit = BoRk2n4aEtT3cKL08HPhUO['node']
			nbeh8JY5UyuZMHNj9tD = wqDAFH1cC0LYSdzit['xid']
			keys = list(wqDAFH1cC0LYSdzit.keys())
			rwf7SEpoXnjJZu = wqDAFH1cC0LYSdzit['__typename'].lower()
			if rwf7SEpoXnjJZu=='channel':
				name = wqDAFH1cC0LYSdzit['name']
				YY7VKCGTrOtmyJSAd8p6hoRN = wqDAFH1cC0LYSdzit['displayName']
				title = 'USER:  '+YY7VKCGTrOtmyJSAd8p6hoRN
				T6TRUSbecYGWIq29KF = wqDAFH1cC0LYSdzit['coverURLx375']
			else:
				name = wqDAFH1cC0LYSdzit['channel']['name']
				YY7VKCGTrOtmyJSAd8p6hoRN = wqDAFH1cC0LYSdzit['channel']['displayName']
				title = wqDAFH1cC0LYSdzit['title']
				T6TRUSbecYGWIq29KF = wqDAFH1cC0LYSdzit['thumbnailx360']
				if rwf7SEpoXnjJZu=='live': title = 'LIVE:  '+title
			title = PRdAbBICNtMDvfwqlWJH(title)
			kcZH1dOl3xQEnYjsMwmvb = name+'::'+YY7VKCGTrOtmyJSAd8p6hoRN
			if cAIRPFK6boejVU549WzqBGCaJ0r:
				title = title.encode(JJQFjSIlALchiMzG9)
				kcZH1dOl3xQEnYjsMwmvb = kcZH1dOl3xQEnYjsMwmvb.encode(JJQFjSIlALchiMzG9)
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			if rwf7SEpoXnjJZu=='channel':
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+nbeh8JY5UyuZMHNj9tD
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,402,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,kcZH1dOl3xQEnYjsMwmvb)
			else:
				if rwf7SEpoXnjJZu=='video': a8tFl4fNpx2Ou65q = str(wqDAFH1cC0LYSdzit['duration'])
				else: a8tFl4fNpx2Ou65q = gby0BnUuTNFk
				SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+nbeh8JY5UyuZMHNj9tD
				ygWIQGf25qwVxLkXrYDjp(rwf7SEpoXnjJZu,JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q,kcZH1dOl3xQEnYjsMwmvb)
	return
def dWKvtyesakjZo7qF(search,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	Z05rTiu6LwakteK8VfY = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mysearchwords',search)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagelimit','40')
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	url = LhFnEIuPHdoNc+'/search/'+search+'/hashtags'
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		try: Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['search']['hashtags']['edges']
		except: Iera3VwFMQbRSCUGuK = []
		for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
			name = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['name']
			name = biVjhGCg0v5eEzkHwTrK9FIAtPU2(name)
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/hashtag/'+name[1:]
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'HSHTG: '+name,SSqweDUBYv4bkO,417)
		if '"hasNextPage":true' in f9uiQLrO2C4xGDMKldYkU5phJo:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,416,gby0BnUuTNFk,kdwXYDMQOjz51Z08W,search)
	return
def nayTlm9uU5Wk(url,kdwXYDMQOjz51Z08W=gby0BnUuTNFk):
	if kdwXYDMQOjz51Z08W==gby0BnUuTNFk: kdwXYDMQOjz51Z08W = '1'
	name = url.split('/')[-1]
	Z05rTiu6LwakteK8VfY = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('myhashtagname',name)
	Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.replace('mypagenumber',kdwXYDMQOjz51Z08W)
	f9uiQLrO2C4xGDMKldYkU5phJo = nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY)
	if f9uiQLrO2C4xGDMKldYkU5phJo:
		tdwAivuEMhUDWBxf0HpeG = TqNUy3Z4SFWvplGwXC82A('dict',f9uiQLrO2C4xGDMKldYkU5phJo)
		Iera3VwFMQbRSCUGuK = tdwAivuEMhUDWBxf0HpeG['data']['contentFeed']['edges']
		for H0lj34Fdk8q1aOP5n9rLIypSJCDGR in Iera3VwFMQbRSCUGuK:
			a8tFl4fNpx2Ou65q = str(H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['post']['duration'])
			title = biVjhGCg0v5eEzkHwTrK9FIAtPU2(H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['post']['title'])
			title = title.replace('\/','/')
			nbeh8JY5UyuZMHNj9tD = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['post']['xid']
			T6TRUSbecYGWIq29KF = H0lj34Fdk8q1aOP5n9rLIypSJCDGR['node']['post']['thumbnailx480']
			T6TRUSbecYGWIq29KF = T6TRUSbecYGWIq29KF.replace('\/','/')
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/video/'+nbeh8JY5UyuZMHNj9tD
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,403,T6TRUSbecYGWIq29KF,a8tFl4fNpx2Ou65q)
		if '"hasNextPage":true' in f9uiQLrO2C4xGDMKldYkU5phJo:
			kdwXYDMQOjz51Z08W = str(int(kdwXYDMQOjz51Z08W)+1)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+kdwXYDMQOjz51Z08W,url,416,gby0BnUuTNFk,kdwXYDMQOjz51Z08W)
	return
def nnQzaOPFqdgj(Z05rTiu6LwakteK8VfY,search=gby0BnUuTNFk):
	if nqkybtoMBH: Z05rTiu6LwakteK8VfY = Z05rTiu6LwakteK8VfY.encode(JJQFjSIlALchiMzG9)
	N0D6wQZAt1mXyYG9KR = Yazsy8PtSFwVLE1hmdqM24()
	headers = {"Authorization":N0D6wQZAt1mXyYG9KR,"Origin":LhFnEIuPHdoNc}
	if search:
		Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = pdHZtCkK1x
		headers.update({'Content-Type':'application/json','Referer':LhFnEIuPHdoNc+'/','X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = o5lILcsXUd9
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',o5lILcsXUd9,Z05rTiu6LwakteK8VfY,headers,gby0BnUuTNFk,gby0BnUuTNFk,'DAILYMOTION-GET_PAGEDATA-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	return jS6fQGXeouTB7xKd32ZMy
def Yazsy8PtSFwVLE1hmdqM24():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'DAILYMOTION-GET_AUTHINTICATION-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	mspCD4Jfnkowh3xAUVRTjrq = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('apiClientId.*?return"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	mspCD4Jfnkowh3xAUVRTjrq = mspCD4Jfnkowh3xAUVRTjrq[xn867tCVlscY4qbWZfh]
	jrOdnLuRFYxN2iV = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('apiClientSecret.*?return"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	jrOdnLuRFYxN2iV = jrOdnLuRFYxN2iV[xn867tCVlscY4qbWZfh]
	gF1vtp47CjcGyBRn = 'https://graphql.api.dailymotion.com/oauth/token'
	dd3Fnyjo8AL67tYKgN2 = 'client_credentials'
	data = {'client_id':mspCD4Jfnkowh3xAUVRTjrq,'client_secret':jrOdnLuRFYxN2iV,'grant_type':dd3Fnyjo8AL67tYKgN2}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'POST',gF1vtp47CjcGyBRn,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	AMDW1Vhoclt4O9XISPkGbHLiemZEQz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	UL1cuw0lD4kta6g7,gBqKdieSM6tanJFG = AMDW1Vhoclt4O9XISPkGbHLiemZEQz[0]
	N0D6wQZAt1mXyYG9KR = gBqKdieSM6tanJFG+" "+UL1cuw0lD4kta6g7
	return N0D6wQZAt1mXyYG9KR
def a3NI0EopMZw(search,mKXQ5VxyYE81ZhAB2bCLduocF=gby0BnUuTNFk):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not mKXQ5VxyYE81ZhAB2bCLduocF and showDialogs:
		Cl3qxUr1MWV6joBpzn2 = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('موقع ديلي موشن - اختر البحث',Cl3qxUr1MWV6joBpzn2)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==-1: return
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==0: mKXQ5VxyYE81ZhAB2bCLduocF = 'videos?sortBy='
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==1: mKXQ5VxyYE81ZhAB2bCLduocF = 'videos?sortBy=RECENT'
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==2: mKXQ5VxyYE81ZhAB2bCLduocF = 'videos?sortBy=VIEW_COUNT'
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==3: mKXQ5VxyYE81ZhAB2bCLduocF = 'playlists'
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==4: mKXQ5VxyYE81ZhAB2bCLduocF = 'channels'
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==5: mKXQ5VxyYE81ZhAB2bCLduocF = 'lives'
		elif EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==6: mKXQ5VxyYE81ZhAB2bCLduocF = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in K7ETgQ2pb4ylWIB3vDHjJ: mKXQ5VxyYE81ZhAB2bCLduocF = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in K7ETgQ2pb4ylWIB3vDHjJ: mKXQ5VxyYE81ZhAB2bCLduocF = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in K7ETgQ2pb4ylWIB3vDHjJ: mKXQ5VxyYE81ZhAB2bCLduocF = 'channels'
	elif '_DAILYMOTION-LIVES_' in K7ETgQ2pb4ylWIB3vDHjJ: mKXQ5VxyYE81ZhAB2bCLduocF = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in K7ETgQ2pb4ylWIB3vDHjJ: mKXQ5VxyYE81ZhAB2bCLduocF = 'hashtags'
	elif not mKXQ5VxyYE81ZhAB2bCLduocF: mKXQ5VxyYE81ZhAB2bCLduocF = 'videos?sortBy='
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	if 'videos' in mKXQ5VxyYE81ZhAB2bCLduocF: KDV3wNLCY1HSqWe2fMnd7FEhz(search+'/'+mKXQ5VxyYE81ZhAB2bCLduocF)
	elif 'playlists' in mKXQ5VxyYE81ZhAB2bCLduocF: ZukgaXMETHJz0is3Ct(search)
	elif 'channels' in mKXQ5VxyYE81ZhAB2bCLduocF: aa8nFgwy3KT(search)
	elif 'lives' in mKXQ5VxyYE81ZhAB2bCLduocF: nn37JOpGYIVcMBUrCgxfd(search)
	elif 'hashtags' in mKXQ5VxyYE81ZhAB2bCLduocF: dWKvtyesakjZo7qF(search)
	return