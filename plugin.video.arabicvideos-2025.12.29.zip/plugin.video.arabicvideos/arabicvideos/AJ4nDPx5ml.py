# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SHAHID4U2'
JB9fyoHr05QOtPjp = '_SH2_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
headers = {'User-Agent':Zc6lYG3a02XVPA1WLr(True)}
d2gCoAnYPG89O = []
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==1090: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==1091: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==1092: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==1093: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,text)
	elif mode==1094: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'FULL_FILTER___'+text)
	elif mode==1095: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'DEFINED_FILTER___'+text)
	elif mode==1099: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(ccV0NKHwQpMun6FtZvAi.url,'url')
	if cAIRPFK6boejVU549WzqBGCaJ0r: Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd.encode(JJQFjSIlALchiMzG9)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,1099,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,1095)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,1094)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'المميزة',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,1091,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"main-menu"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			if title in d2gCoAnYPG89O: continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
			if 'netflix' in SSqweDUBYv4bkO: title = 'نيتفلكس'
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1091)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk,ccV0NKHwQpMun6FtZvAi=gby0BnUuTNFk):
	if not ccV0NKHwQpMun6FtZvAi: ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb,items,NGcX5a4OifEhZKrY7C0QVyjRA = [],[],[]
	if xxGw3Q5hHDkP8WfVe7m=='featured': QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Slides--Main"(.*?)"filterTabs"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"BlocksHolder"(.*?)"pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?data-src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		if 'WWE' in title: continue
		if 'javascript' in SSqweDUBYv4bkO: continue
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
		title = Y7BxKQdU84R(title)
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '/film/' in SSqweDUBYv4bkO or 'فيلم' in SSqweDUBYv4bkO or any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1092,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1093,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/actor/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1091,T6TRUSbecYGWIq29KF)
		elif '/series/' in SSqweDUBYv4bkO and '/list' not in url:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'/list'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1091,T6TRUSbecYGWIq29KF)
		elif '/list' in url and 'حلقة' in title:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1092,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1093,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb and not xxGw3Q5hHDkP8WfVe7m:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li>.*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			if title: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,1091,gby0BnUuTNFk,gby0BnUuTNFk,xxGw3Q5hHDkP8WfVe7m)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,evBNDQ3xJgVSo):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="w-100(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="EpisodesList"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		T6mIdhgVoO = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
		E3Km6hlMy72IaVT0od5z1 = T6mIdhgVoO.count('/season/')+T6mIdhgVoO.count('/series/')
		QhcEyZFxvn7fsPYGlgidVANWLUo80w = T6mIdhgVoO.count('href')-E3Km6hlMy72IaVT0od5z1
		if len(QKqM0CwXDk8APOoJFpyntRb)==dNx9DVCtafk4r:
			wjBSKDQIHyAO3uiWxEM = QKqM0CwXDk8APOoJFpyntRb[jxCVeKSLb9rGDOl0Qtw6]
			bo7YnsWGk1KEwNuUClgXR = wjBSKDQIHyAO3uiWxEM.count('/season/')+wjBSKDQIHyAO3uiWxEM.count('/series/')
			a6n0STJ3HLDtkm1vr5oY = wjBSKDQIHyAO3uiWxEM.count('href=')-bo7YnsWGk1KEwNuUClgXR
		else: wjBSKDQIHyAO3uiWxEM,bo7YnsWGk1KEwNuUClgXR,a6n0STJ3HLDtkm1vr5oY = gby0BnUuTNFk,xn867tCVlscY4qbWZfh,xn867tCVlscY4qbWZfh
		AxiBv1cQueOs0 = gby0BnUuTNFk
		if not evBNDQ3xJgVSo:
			if E3Km6hlMy72IaVT0od5z1>jxCVeKSLb9rGDOl0Qtw6: AxiBv1cQueOs0 = T6mIdhgVoO
			elif bo7YnsWGk1KEwNuUClgXR>jxCVeKSLb9rGDOl0Qtw6: AxiBv1cQueOs0 = wjBSKDQIHyAO3uiWxEM
		if not AxiBv1cQueOs0:
			if QhcEyZFxvn7fsPYGlgidVANWLUo80w: AxiBv1cQueOs0 = T6mIdhgVoO
			elif a6n0STJ3HLDtkm1vr5oY: AxiBv1cQueOs0 = wjBSKDQIHyAO3uiWxEM
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<.*?<em>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,FBqu9a3mZsYd8G7M,T3Yrx4yZCRqcH in items:
			title = FBqu9a3mZsYd8G7M+UpN1CezytPO9XoduhxZSD+T3Yrx4yZCRqcH
			if '/season/' not in SSqweDUBYv4bkO and '/series/' not in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1092)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1093,gby0BnUuTNFk,gby0BnUuTNFk,'season')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ytc3dVjPkMHCSmlzvBuO820Q,LAzpDv0RCZE9yWIk3BXql1HuUjh = [],[]
	J1pEkG86fe3nwKxC9y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="watch" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	yxYSAR03oqwzI2HraZue7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="download" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if J1pEkG86fe3nwKxC9y:
		J1pEkG86fe3nwKxC9y = J1pEkG86fe3nwKxC9y[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',J1pEkG86fe3nwKxC9y,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-PLAY-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"watch"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-watch="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO in LAzpDv0RCZE9yWIk3BXql1HuUjh: continue
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
				LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
	if yxYSAR03oqwzI2HraZue7:
		yxYSAR03oqwzI2HraZue7 = yxYSAR03oqwzI2HraZue7[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',yxYSAR03oqwzI2HraZue7,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-PLAY-3rd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"DownList"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<quality>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO in LAzpDv0RCZE9yWIk3BXql1HuUjh: continue
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
				LAzpDv0RCZE9yWIk3BXql1HuUjh.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return
def G2dUpHgXKM1Nzu4w9(url):
	url = url.split('/smartemadfilter?')[0]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U2-GET_FILTERS_BLOCKS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	tpQ9UZ8rIuhvW3box21X6iqsz = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('adv-filter(.*?)shows-container',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		ODUdHoNbZmpeE1w,PDCFEVTazt6,bXMpofzj7h = zip(*tpQ9UZ8rIuhvW3box21X6iqsz)
		tpQ9UZ8rIuhvW3box21X6iqsz = zip(PDCFEVTazt6,ODUdHoNbZmpeE1w,bXMpofzj7h)
	return tpQ9UZ8rIuhvW3box21X6iqsz
def Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0):
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('value="(.*?)".*?>\s*(.*?)\s*<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return items
def cVf0JZ75BjR2xHSTWNian(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	c7oIqRywsVUpZ8rdTu6LNm20Y = url.split('/smartemadfilter?')[0]
	q53fXShJmaD0iWrz7KbnlAFBoR = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace(c7oIqRywsVUpZ8rdTu6LNm20Y,q53fXShJmaD0iWrz7KbnlAFBoR)
	url = url.replace('/smartemadfilter?','/?')
	return url
L4vWYpJ2b83gI7cDFGhZMwXOroad = ['quality','year','genre','category']
VV5CEDntMjb = ['category','genre','year']
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='DEFINED_FILTER':
		if VV5CEDntMjb[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = VV5CEDntMjb[0]
		for xuX6UN0WRQbHArDV in range(len(VV5CEDntMjb[0:-1])):
			if VV5CEDntMjb[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = VV5CEDntMjb[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='FULL_FILTER':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+QfoFHUnpEi4W2OuT8DBg3
		mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها ',mm7pzl3HMi0R8fGu,1091)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',mm7pzl3HMi0R8fGu,1091)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	tpQ9UZ8rIuhvW3box21X6iqsz = G2dUpHgXKM1Nzu4w9(url)
	dict = {}
	for name,CCRe1gOK8Dtca0,AxiBv1cQueOs0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		name = name.replace('كل ',gby0BnUuTNFk)
		items = Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='DEFINED_FILTER':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<2:
				if CCRe1gOK8Dtca0==VV5CEDntMjb[-1]:
					mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
					Xw3tTz8UD4LK26C(mm7pzl3HMi0R8fGu)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'DEFINED_FILTER___'+J21ulLnwtByA4XvcC)
				return
			else:
				if CCRe1gOK8Dtca0==VV5CEDntMjb[-1]:
					mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',mm7pzl3HMi0R8fGu,1091)
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,1095,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='FULL_FILTER':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع :'+name,Tf5ueYGZIFl1hraoEOVKi,1094,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if value=='196533': w7su60daQz13VIplrfxJk = 'أفلام نيتفلكس'
			elif value=='196531': w7su60daQz13VIplrfxJk = 'مسلسلات نيتفلكس'
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' :'#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' :'+name
			if type=='FULL_FILTER': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,1094,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='DEFINED_FILTER' and VV5CEDntMjb[-2]+'=' in mW9DK3tVFwd:
				zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'modified_filters')
				Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
				mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,1091)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,1095,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.replace('=&','=0&')
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	for key in L4vWYpJ2b83gI7cDFGhZMwXOroad:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if '%' not in value: value = IcChbXakUDFLszgpSG2jqem9(value)
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	d28pn3tAz4V = d28pn3tAz4V.replace('=0','=')
	return d28pn3tAz4V