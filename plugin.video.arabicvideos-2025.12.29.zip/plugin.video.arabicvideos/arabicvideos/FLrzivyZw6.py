# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'FASELHD2'
headers = {'User-Agent':gby0BnUuTNFk}
JB9fyoHr05QOtPjp = '_FH2_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][xn867tCVlscY4qbWZfh]
d2gCoAnYPG89O = ['FaselHD']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==590: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==591: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==592: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==593: WjryKiBebavP = KKUF2Xzv518hY(url,text)
	elif mode==599: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = LhFnEIuPHdoNc
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD2-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,599,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<h3>(.*?)<.*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	KQydxfMmoJERw = xn867tCVlscY4qbWZfh
	for title,SSqweDUBYv4bkO in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if any(value in title for value in d2gCoAnYPG89O): continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,591,gby0BnUuTNFk,gby0BnUuTNFk,'featured'+str(KQydxfMmoJERw))
		KQydxfMmoJERw += jxCVeKSLb9rGDOl0Qtw6
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"main-menu"(.*?)</nav>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
		mFWJ8ZAsqkK = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li (.*?)</li>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for vDOcF6sdlBTWr3 in mFWJ8ZAsqkK:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',vDOcF6sdlBTWr3,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
				ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,591)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,mKXQ5VxyYE81ZhAB2bCLduocF=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD2-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = []
	if 'featured' in mKXQ5VxyYE81ZhAB2bCLduocF:
		KQydxfMmoJERw = mKXQ5VxyYE81ZhAB2bCLduocF[-jxCVeKSLb9rGDOl0Qtw6]
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"boxes--holder"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[int(KQydxfMmoJERw)]
	elif mKXQ5VxyYE81ZhAB2bCLduocF=='filters':
		QKqM0CwXDk8APOoJFpyntRb = [jS6fQGXeouTB7xKd32ZMy.replace('\\/','/').replace('\\"','"')]
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"boxes--holder"(.*?)"pagination"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		try: title = title.encode(LmIPKScVGEs).decode(JJQFjSIlALchiMzG9)
		except: pass
		title = Y7BxKQdU84R(title)
		if any(value in title.lower() for value in d2gCoAnYPG89O): continue
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '/movseries/' in SSqweDUBYv4bkO: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,591,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez:
			title = '_MOD_'+Cso7iV0ZOw2UW5Ez[0][0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,593,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb): ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,592,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,593,T6TRUSbecYGWIq29KF)
	if mKXQ5VxyYE81ZhAB2bCLduocF=='filters':
		BBOEKWQ1ueVhnrZ3dJxv = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"more_button_page":(.*?),',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if BBOEKWQ1ueVhnrZ3dJxv:
			count = BBOEKWQ1ueVhnrZ3dJxv[0]
			SSqweDUBYv4bkO = url+'/offset/'+count
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة أخرى',SSqweDUBYv4bkO,591,gby0BnUuTNFk,gby0BnUuTNFk,'filters')
	elif 'featured' not in mKXQ5VxyYE81ZhAB2bCLduocF:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="pagination(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				title = Y7BxKQdU84R(title)
				SSqweDUBYv4bkO = Y7BxKQdU84R(SSqweDUBYv4bkO)
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = LhFnEIuPHdoNc+SSqweDUBYv4bkO
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,591,gby0BnUuTNFk,gby0BnUuTNFk,'details4')
	return
def KKUF2Xzv518hY(url,data=gby0BnUuTNFk):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',url,data,headers,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD2-SEASONS_EPISODES-1st')
		jS6fQGXeouTB7xKd32ZMy = '"EpisodesList"'+ccV0NKHwQpMun6FtZvAi.content+'</div>'
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD2-SEASONS_EPISODES-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	gQmur3iRSZ9IAOX = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"inner--image"><img src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	T6TRUSbecYGWIq29KF = gQmur3iRSZ9IAOX[xn867tCVlscY4qbWZfh] if gQmur3iRSZ9IAOX else gby0BnUuTNFk
	items = []
	if not data:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsList"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if len(items)>1:
				for m84exy3GSjnMc9RdJC,YYOman4GEXScVfjg89bRkDq,title in items:
					SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					uWIUplrbFd = 'season='+YYOman4GEXScVfjg89bRkDq+'&post_id='+m84exy3GSjnMc9RdJC
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,593,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,uWIUplrbFd)
		data = w8Ui6RsVhSPrqHfO4
	if data and len(items)<dNx9DVCtafk4r:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"EpisodesList"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[xn867tCVlscY4qbWZfh]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<em>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,FBqu9a3mZsYd8G7M,T3Yrx4yZCRqcH in items:
				title = FBqu9a3mZsYd8G7M+UpN1CezytPO9XoduhxZSD+T3Yrx4yZCRqcH
				title = title.strip(UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,592,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	url = url.strip('/')+'/watch/'
	ytc3dVjPkMHCSmlzvBuO820Q,SCJrDKXILuhW25QUlBV1iT,xqKNBIhz8Wf = [],[],[]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(cjSzHQn9N4BuIZO0xJ,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'FASELHD2-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	cEMC0VKHF64RhfGsSBLnTgYQDwN9lp = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('العمر :.*?<strong">(.*?)</strong>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if cEMC0VKHF64RhfGsSBLnTgYQDwN9lp and OAfn469BaprdwGYVkvyE2F0x(CC3nOPFMovd72u,url,cEMC0VKHF64RhfGsSBLnTgYQDwN9lp): return
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<iframe src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=__embed')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"main--contents"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for KXauH7EwCn2Y6IsdUGrOMZvgqBzT,m84exy3GSjnMc9RdJC,title in items:
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+m84exy3GSjnMc9RdJC+'&i='+KXauH7EwCn2Y6IsdUGrOMZvgqBzT
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+title+'__watch')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"downloads"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,name in items:
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named='+name+'__download')
	for NSkqQWjPpEJDHstxrKBb2vFIYnaOX in ytc3dVjPkMHCSmlzvBuO820Q:
		SSqweDUBYv4bkO,name = NSkqQWjPpEJDHstxrKBb2vFIYnaOX.split('?named')
		if SSqweDUBYv4bkO not in SCJrDKXILuhW25QUlBV1iT:
			SCJrDKXILuhW25QUlBV1iT.append(SSqweDUBYv4bkO)
			xqKNBIhz8Wf.append(NSkqQWjPpEJDHstxrKBb2vFIYnaOX)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(xqKNBIhz8Wf,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = LhFnEIuPHdoNc
	url = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/?s='+search
	Xw3tTz8UD4LK26C(url,'details5')
	return