# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SHAHIDNEWS'
JB9fyoHr05QOtPjp = '_SHN_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['قنوات فضائية','فارسكو','Show more']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==580: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==581: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==582: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==583: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,text)
	elif mode==584: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==589: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHIDNEWS-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,589,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('/category.php">(.*?)"navslide-divider"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("'dropdown-menu'(.*?)</ul>",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for xki4Q3jNVZzFAsaWOPCge in QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = AxiBv1cQueOs0.replace(xki4Q3jNVZzFAsaWOPCge,gby0BnUuTNFk)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,584)
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHIDNEWS-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"caret"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('"presentation"','</ul>')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = [(gby0BnUuTNFk,AxiBv1cQueOs0)]
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' فرز أو فلتر أو ترتيب '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		for U4LRgsfMau2nr3Ay6WXqhkledw,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if U4LRgsfMau2nr3Ay6WXqhkledw: U4LRgsfMau2nr3Ay6WXqhkledw = U4LRgsfMau2nr3Ay6WXqhkledw+': '
			for SSqweDUBYv4bkO,title in items:
				title = U4LRgsfMau2nr3Ay6WXqhkledw+title
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,581)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-category-subcats"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(items)<30:
			ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			for SSqweDUBYv4bkO,title in items:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,581)
	if not l2Np9PfFqv4RcW7Y and not qsQxHTa4e0JYLUSKF7: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHIDNEWS-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(data-echo=".*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"BlocksList"(.*?)"titleSectionCon"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="pm-grid"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="pm-related"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
		if 'http' not in T6TRUSbecYGWIq29KF: T6TRUSbecYGWIq29KF = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+T6TRUSbecYGWIq29KF.strip('/')
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,582,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,583,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/movseries/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,581,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,583,T6TRUSbecYGWIq29KF)
	if Z05rTiu6LwakteK8VfY not in ['featured_movies','featured_series']:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=='#': continue
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				title = Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,581)
		fhW8oRx6TUJiuFK5GXQH9 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('showmore" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if fhW8oRx6TUJiuFK5GXQH9:
			SSqweDUBYv4bkO = fhW8oRx6TUJiuFK5GXQH9[0]
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'مشاهدة المزيد',SSqweDUBYv4bkO,581)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,YYOman4GEXScVfjg89bRkDq):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHIDNEWS-EPISODES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('nav-seasons"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	items = []
	RTvjVPxz2QtwD7el9iy = False
	if l2Np9PfFqv4RcW7Y and not YYOman4GEXScVfjg89bRkDq:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for YYOman4GEXScVfjg89bRkDq,title in items:
			YYOman4GEXScVfjg89bRkDq = YYOman4GEXScVfjg89bRkDq.strip('#')
			if len(items)>1: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,583,gby0BnUuTNFk,gby0BnUuTNFk,YYOman4GEXScVfjg89bRkDq)
			else: RTvjVPxz2QtwD7el9iy = True
	else: RTvjVPxz2QtwD7el9iy = True
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="'+YYOman4GEXScVfjg89bRkDq+'"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7 and RTvjVPxz2QtwD7el9iy:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if items:
			for SSqweDUBYv4bkO,title in items:
				SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,582)
		else:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,582)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHIDNEWS-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"Playerholder".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
	if SSqweDUBYv4bkO and 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = 'http:'+SSqweDUBYv4bkO
	BonmE34yGer = SSqweDUBYv4bkO.split('hash=')[1]
	rO9QBRygx3sqJcH5kZTM1uS74D = BonmE34yGer.split('__')
	r4Kx5fdAQ1ZFJlvucWC,vx14CNdbsZTz,title = gby0BnUuTNFk,[],gby0BnUuTNFk
	for ZZ6otChQWuiUvPTFmlXz2JI in rO9QBRygx3sqJcH5kZTM1uS74D:
		gb2LvMiDIahXjJwcUY = ((4-len(ZZ6otChQWuiUvPTFmlXz2JI)%4)%4)*'='
		try:
			ZZ6otChQWuiUvPTFmlXz2JI = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(ZZ6otChQWuiUvPTFmlXz2JI+gb2LvMiDIahXjJwcUY)
			if nqkybtoMBH: ZZ6otChQWuiUvPTFmlXz2JI = ZZ6otChQWuiUvPTFmlXz2JI.decode(JJQFjSIlALchiMzG9,'ignore')
		except: pass
		r4Kx5fdAQ1ZFJlvucWC += ZZ6otChQWuiUvPTFmlXz2JI
	r4Kx5fdAQ1ZFJlvucWC = r4Kx5fdAQ1ZFJlvucWC.replace(' = ',' => ')
	UoqtD8waXePnWGk = r4Kx5fdAQ1ZFJlvucWC.splitlines()
	for SSqweDUBYv4bkO in UoqtD8waXePnWGk:
		if '://' in SSqweDUBYv4bkO: vx14CNdbsZTz.append(SSqweDUBYv4bkO)
	for SSqweDUBYv4bkO in vx14CNdbsZTz:
		if ' => ' in SSqweDUBYv4bkO: title,SSqweDUBYv4bkO = SSqweDUBYv4bkO.split(' => ')
		elif 'http' in SSqweDUBYv4bkO:
			title,SSqweDUBYv4bkO = SSqweDUBYv4bkO.split('http')
			SSqweDUBYv4bkO = 'http'+SSqweDUBYv4bkO
		else: continue
		SSqweDUBYv4bkO = SSqweDUBYv4bkO.strip(' ')
		if not title: title = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
		SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
		eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/search.php?keywords='+search
	Xw3tTz8UD4LK26C(url)
	return