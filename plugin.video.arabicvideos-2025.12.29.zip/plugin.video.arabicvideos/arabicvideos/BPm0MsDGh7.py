# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'SHAHID4U'
JB9fyoHr05QOtPjp = '_SH4_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
headers = {'User-Agent':Zc6lYG3a02XVPA1WLr(True)}
d2gCoAnYPG89O = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==110: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==111: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==112: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==113: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,True)
	elif mode==114: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'FULL_FILTER___'+text)
	elif mode==115: WjryKiBebavP = PsoEh3mOJub72VQl1crzW5n(url,'DEFINED_FILTER___'+text)
	elif mode==116: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,False)
	elif mode==119: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(ccV0NKHwQpMun6FtZvAi.url,'url')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,119,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر محدد',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,115)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'فلتر كامل',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,114)
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'المميزة',Hr3FCpiuRKaB0NSQ1M47sfygXvoxd,111,gby0BnUuTNFk,gby0BnUuTNFk,'featured')
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('simple-filter(.*?)adv-filter',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb:
		tt3DVu1TU8dLAi(gby0BnUuTNFk,gby0BnUuTNFk,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for filter,T6TRUSbecYGWIq29KF,title in items:
			url = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+filter
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,url,111,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,filter)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="dropdown"(.*?)<script>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk).strip(UpN1CezytPO9XoduhxZSD)
			if title in d2gCoAnYPG89O: continue
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+SSqweDUBYv4bkO
			if 'netflix' in SSqweDUBYv4bkO: title = 'نيتفلكس'
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,111)
	return jS6fQGXeouTB7xKd32ZMy
def Xw3tTz8UD4LK26C(url,xxGw3Q5hHDkP8WfVe7m=gby0BnUuTNFk,ccV0NKHwQpMun6FtZvAi=gby0BnUuTNFk):
	if not ccV0NKHwQpMun6FtZvAi: ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb,items,NGcX5a4OifEhZKrY7C0QVyjRA = [],[],[]
	if xxGw3Q5hHDkP8WfVe7m=='featured': QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('glide__slides(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	else: QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('shows-container(.*?)pagination',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		if 'WWE' in title: continue
		if 'javascript' in SSqweDUBYv4bkO: continue
		SSqweDUBYv4bkO = pFnO2T7r16k(SSqweDUBYv4bkO).strip('/')
		title = Y7BxKQdU84R(title)
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) الحلقة \d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if '/film/' in SSqweDUBYv4bkO or 'فيلم' in SSqweDUBYv4bkO or any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,112,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,113,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		elif '/actor/' in SSqweDUBYv4bkO:
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,111,T6TRUSbecYGWIq29KF)
		elif '/series/' in SSqweDUBYv4bkO and '/list' not in url:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'/list'
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,111,T6TRUSbecYGWIq29KF)
		elif '/list' in url and 'حلقة' in title:
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,112,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,113,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb and xxGw3Q5hHDkP8WfVe7m!='featured':
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		if xxGw3Q5hHDkP8WfVe7m!='search': items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(updateQuery).*?>(.+?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		else: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('<li>.*?href="(.*?)">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for SSqweDUBYv4bkO,title in items:
			title = title.replace(okfdjS4RmM,gby0BnUuTNFk).replace(Hd14YjcWpvPhN8sZXK3,gby0BnUuTNFk)
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			if xxGw3Q5hHDkP8WfVe7m!='search':
				SSqweDUBYv4bkO = url+'&page='+title if '?' in url else url+'?page='+title
			title = Y7BxKQdU84R(title)
			if title: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,111,gby0BnUuTNFk,gby0BnUuTNFk,xxGw3Q5hHDkP8WfVe7m)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url,ONisj3LEBn254avl9qtAXc7RVozPp):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('items d-flex(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if len(QKqM0CwXDk8APOoJFpyntRb)>1:
		if '/season/' in QKqM0CwXDk8APOoJFpyntRb[0]: QYjhVM3NwTm5l,JsAt0zywiZXQM3YKvnG6ClDq7N8L = QKqM0CwXDk8APOoJFpyntRb[0],QKqM0CwXDk8APOoJFpyntRb[1]
		else: QYjhVM3NwTm5l,JsAt0zywiZXQM3YKvnG6ClDq7N8L = QKqM0CwXDk8APOoJFpyntRb[1],QKqM0CwXDk8APOoJFpyntRb[0]
	else: QYjhVM3NwTm5l,JsAt0zywiZXQM3YKvnG6ClDq7N8L = QKqM0CwXDk8APOoJFpyntRb[0],QKqM0CwXDk8APOoJFpyntRb[0]
	for t3t986iTduqY in range(2):
		if ONisj3LEBn254avl9qtAXc7RVozPp: mode,type,AxiBv1cQueOs0 = 116,'folder',QYjhVM3NwTm5l
		else: mode,type,AxiBv1cQueOs0 = 112,'video',JsAt0zywiZXQM3YKvnG6ClDq7N8L
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if ONisj3LEBn254avl9qtAXc7RVozPp and len(items)<2:
			ONisj3LEBn254avl9qtAXc7RVozPp = False
			continue
		for SSqweDUBYv4bkO,FBqu9a3mZsYd8G7M,T3Yrx4yZCRqcH in items:
			title = FBqu9a3mZsYd8G7M+UpN1CezytPO9XoduhxZSD+T3Yrx4yZCRqcH
			ygWIQGf25qwVxLkXrYDjp(type,JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,mode)
		break
	if not items and '/episodes' in jS6fQGXeouTB7xKd32ZMy:
		sbXtWkYlVJ = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="breadcrumb"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if sbXtWkYlVJ:
			AxiBv1cQueOs0 = sbXtWkYlVJ[0]
			vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if len(vx14CNdbsZTz)>2:
				SSqweDUBYv4bkO = vx14CNdbsZTz[2]+'list'
				Xw3tTz8UD4LK26C(SSqweDUBYv4bkO)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="actions(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not QKqM0CwXDk8APOoJFpyntRb: return
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	eyqCmnko3rYB8AXGFOT2diKtfLD = '/watch/' in AxiBv1cQueOs0
	download = '/download/' in AxiBv1cQueOs0
	if   eyqCmnko3rYB8AXGFOT2diKtfLD and not download: J1pEkG86fe3nwKxC9y,yxYSAR03oqwzI2HraZue7 = vx14CNdbsZTz[0],gby0BnUuTNFk
	elif not eyqCmnko3rYB8AXGFOT2diKtfLD and download: J1pEkG86fe3nwKxC9y,yxYSAR03oqwzI2HraZue7 = gby0BnUuTNFk,vx14CNdbsZTz[0]
	elif eyqCmnko3rYB8AXGFOT2diKtfLD and download: J1pEkG86fe3nwKxC9y,yxYSAR03oqwzI2HraZue7 = vx14CNdbsZTz[0],vx14CNdbsZTz[1]
	else: J1pEkG86fe3nwKxC9y,yxYSAR03oqwzI2HraZue7 = gby0BnUuTNFk,gby0BnUuTNFk
	eE9BXgNu4MPKIbw2aLDl1AY3R = []
	if eyqCmnko3rYB8AXGFOT2diKtfLD:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',J1pEkG86fe3nwKxC9y,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-PLAY-2nd')
		N84Yo7V9qS = ccV0NKHwQpMun6FtZvAi.content
		qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('let servers(.*?)player',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL|ERgVvYA0TMIdUCa2KzFQDcZOPNin.IGNORECASE)
		if qsQxHTa4e0JYLUSKF7:
			xki4Q3jNVZzFAsaWOPCge = qsQxHTa4e0JYLUSKF7[0]
			vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"name":"(.*?)".*?"url":"(.*?)"',xki4Q3jNVZzFAsaWOPCge,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for title,SSqweDUBYv4bkO in vv7qYWmFwzBPofI5e2ls:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO.replace('\\/','/')
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	if download:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',yxYSAR03oqwzI2HraZue7,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-PLAY-3rd')
		N84Yo7V9qS = ccV0NKHwQpMun6FtZvAi.content
		qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"servers"(.*?)info-container',N84Yo7V9qS,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if qsQxHTa4e0JYLUSKF7:
			xki4Q3jNVZzFAsaWOPCge = qsQxHTa4e0JYLUSKF7[0]
			vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',xki4Q3jNVZzFAsaWOPCge,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title,DYNVS1Bbgs7 in vv7qYWmFwzBPofI5e2ls:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__download'+'____'+DYNVS1Bbgs7
				eE9BXgNu4MPKIbw2aLDl1AY3R.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(eE9BXgNu4MPKIbw2aLDl1AY3R,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if not search:
		search = vRoGedUjt2Ac6pIbufBX8sKy()
		if not search: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/search?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return
def G2dUpHgXKM1Nzu4w9(url):
	url = url.split('/smartemadfilter?')[0]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(Q3J7xTKDuAUoaPlB,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	tpQ9UZ8rIuhvW3box21X6iqsz = []
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('adv-filter(.*?)shows-container',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		tpQ9UZ8rIuhvW3box21X6iqsz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		ODUdHoNbZmpeE1w,PDCFEVTazt6,bXMpofzj7h = zip(*tpQ9UZ8rIuhvW3box21X6iqsz)
		tpQ9UZ8rIuhvW3box21X6iqsz = zip(PDCFEVTazt6,ODUdHoNbZmpeE1w,bXMpofzj7h)
	return tpQ9UZ8rIuhvW3box21X6iqsz
def Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0):
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('value="(.*?)".*?>\s*(.*?)\s*<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	return items
def cVf0JZ75BjR2xHSTWNian(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	c7oIqRywsVUpZ8rdTu6LNm20Y = url.split('/smartemadfilter?')[0]
	q53fXShJmaD0iWrz7KbnlAFBoR = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	url = url.replace(c7oIqRywsVUpZ8rdTu6LNm20Y,q53fXShJmaD0iWrz7KbnlAFBoR)
	url = url.replace('/smartemadfilter?','/?')
	return url
L4vWYpJ2b83gI7cDFGhZMwXOroad = ['quality','year','genre','category']
VV5CEDntMjb = ['category','genre','year']
def PsoEh3mOJub72VQl1crzW5n(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==gby0BnUuTNFk: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = gby0BnUuTNFk,gby0BnUuTNFk
	else: mW9DK3tVFwd,QfoFHUnpEi4W2OuT8DBg3 = filter.split('___')
	if type=='DEFINED_FILTER':
		if VV5CEDntMjb[0]+'=' not in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = VV5CEDntMjb[0]
		for xuX6UN0WRQbHArDV in range(len(VV5CEDntMjb[0:-1])):
			if VV5CEDntMjb[xuX6UN0WRQbHArDV]+'=' in mW9DK3tVFwd: zTFlfH8DhAVryqUjX = VV5CEDntMjb[xuX6UN0WRQbHArDV+1]
		uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+zTFlfH8DhAVryqUjX+'=0'
		vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+zTFlfH8DhAVryqUjX+'=0'
		J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf.strip('&')+'___'+vyD9F1UMQe.strip('&')
		zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
	elif type=='FULL_FILTER':
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = LTwOeFg82f(mW9DK3tVFwd,'modified_values')
		IT1y5ADx0OFJlSGQ8tCghEiZNjwr = pFnO2T7r16k(IT1y5ADx0OFJlSGQ8tCghEiZNjwr)
		if QfoFHUnpEi4W2OuT8DBg3!=gby0BnUuTNFk: QfoFHUnpEi4W2OuT8DBg3 = LTwOeFg82f(QfoFHUnpEi4W2OuT8DBg3,'modified_filters')
		if QfoFHUnpEi4W2OuT8DBg3==gby0BnUuTNFk: Tf5ueYGZIFl1hraoEOVKi = url
		else: Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+QfoFHUnpEi4W2OuT8DBg3
		mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'أظهار قائمة الفيديو التي تم اختيارها ',mm7pzl3HMi0R8fGu,111)
		ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+' [[   '+IT1y5ADx0OFJlSGQ8tCghEiZNjwr+'   ]]',mm7pzl3HMi0R8fGu,111)
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	tpQ9UZ8rIuhvW3box21X6iqsz = G2dUpHgXKM1Nzu4w9(url)
	dict = {}
	for name,CCRe1gOK8Dtca0,AxiBv1cQueOs0 in tpQ9UZ8rIuhvW3box21X6iqsz:
		name = name.replace('كل ',gby0BnUuTNFk)
		items = Jc2nV0jAOoslCwq5dEZifIT9yQg(AxiBv1cQueOs0)
		if '=' not in Tf5ueYGZIFl1hraoEOVKi: Tf5ueYGZIFl1hraoEOVKi = url
		if type=='DEFINED_FILTER':
			if zTFlfH8DhAVryqUjX!=CCRe1gOK8Dtca0: continue
			elif len(items)<2:
				if CCRe1gOK8Dtca0==VV5CEDntMjb[-1]:
					mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
					Xw3tTz8UD4LK26C(mm7pzl3HMi0R8fGu)
				else: PsoEh3mOJub72VQl1crzW5n(Tf5ueYGZIFl1hraoEOVKi,'DEFINED_FILTER___'+J21ulLnwtByA4XvcC)
				return
			else:
				if CCRe1gOK8Dtca0==VV5CEDntMjb[-1]:
					mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',mm7pzl3HMi0R8fGu,111)
				else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع',Tf5ueYGZIFl1hraoEOVKi,115,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		elif type=='FULL_FILTER':
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'=0'
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'=0'
			J21ulLnwtByA4XvcC = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الجميع :'+name,Tf5ueYGZIFl1hraoEOVKi,114,gby0BnUuTNFk,gby0BnUuTNFk,J21ulLnwtByA4XvcC)
		dict[CCRe1gOK8Dtca0] = {}
		for value,w7su60daQz13VIplrfxJk in items:
			if value=='196533': w7su60daQz13VIplrfxJk = 'أفلام نيتفلكس'
			elif value=='196531': w7su60daQz13VIplrfxJk = 'مسلسلات نيتفلكس'
			if w7su60daQz13VIplrfxJk in d2gCoAnYPG89O: continue
			dict[CCRe1gOK8Dtca0][value] = w7su60daQz13VIplrfxJk
			uubpzTyPUhMZ45eka7gNK9IlRVCYf = mW9DK3tVFwd+'&'+CCRe1gOK8Dtca0+'='+w7su60daQz13VIplrfxJk
			vyD9F1UMQe = QfoFHUnpEi4W2OuT8DBg3+'&'+CCRe1gOK8Dtca0+'='+value
			ffOl4IH2RiqW = uubpzTyPUhMZ45eka7gNK9IlRVCYf+'___'+vyD9F1UMQe
			title = w7su60daQz13VIplrfxJk+' :'#+dict[CCRe1gOK8Dtca0]['0']
			title = w7su60daQz13VIplrfxJk+' :'+name
			if type=='FULL_FILTER': ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,114,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
			elif type=='DEFINED_FILTER' and VV5CEDntMjb[-2]+'=' in mW9DK3tVFwd:
				zfRG7q8BlLZ9cATPNk6Od = LTwOeFg82f(vyD9F1UMQe,'modified_filters')
				Tf5ueYGZIFl1hraoEOVKi = url+'/smartemadfilter?'+zfRG7q8BlLZ9cATPNk6Od
				mm7pzl3HMi0R8fGu = cVf0JZ75BjR2xHSTWNian(Tf5ueYGZIFl1hraoEOVKi)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,mm7pzl3HMi0R8fGu,111)
			else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,115,gby0BnUuTNFk,gby0BnUuTNFk,ffOl4IH2RiqW)
	return
def LTwOeFg82f(AiG7kxETBYMw15,mode):
	AiG7kxETBYMw15 = AiG7kxETBYMw15.replace('=&','=0&')
	AiG7kxETBYMw15 = AiG7kxETBYMw15.strip('&')
	cXykKWGSQwZOempA5LRrNUID = {}
	if '=' in AiG7kxETBYMw15:
		items = AiG7kxETBYMw15.split('&')
		for BoRk2n4aEtT3cKL08HPhUO in items:
			wwazx8RA0V6J,value = BoRk2n4aEtT3cKL08HPhUO.split('=')
			cXykKWGSQwZOempA5LRrNUID[wwazx8RA0V6J] = value
	d28pn3tAz4V = gby0BnUuTNFk
	for key in L4vWYpJ2b83gI7cDFGhZMwXOroad:
		if key in list(cXykKWGSQwZOempA5LRrNUID.keys()): value = cXykKWGSQwZOempA5LRrNUID[key]
		else: value = '0'
		if '%' not in value: value = IcChbXakUDFLszgpSG2jqem9(value)
		if mode=='modified_values' and value!='0': d28pn3tAz4V = d28pn3tAz4V+' + '+value
		elif mode=='modified_filters' and value!='0': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
		elif mode=='all': d28pn3tAz4V = d28pn3tAz4V+'&'+key+'='+value
	d28pn3tAz4V = d28pn3tAz4V.strip(' + ')
	d28pn3tAz4V = d28pn3tAz4V.strip('&')
	d28pn3tAz4V = d28pn3tAz4V.replace('=0','=')
	return d28pn3tAz4V