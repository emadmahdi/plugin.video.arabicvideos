# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'ARABICTOONS'
JB9fyoHr05QOtPjp = '_ART_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==730: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==731: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==732: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==733: WjryKiBebavP = Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url)
	elif mode==734: WjryKiBebavP = jDvroaB5RyEP9(url)
	elif mode==735: WjryKiBebavP = XaOuRkxFtPzQ(url)
	elif mode==739: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,739,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'افلام',LhFnEIuPHdoNc+'/movies.php',731)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات',LhFnEIuPHdoNc+'/cartoon.php',734)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'مسلسلات مميزة',LhFnEIuPHdoNc+'/top.php',735)
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أحدث الأفلام المضافة',LhFnEIuPHdoNc,731,'','','LATEST_MOVIES')
	ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+'أحدث المسلسلات المضافة',LhFnEIuPHdoNc,731,'','','LATEST_SERIES')
	return
def jDvroaB5RyEP9(url):
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'الكل',url,731)
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-SERIES_SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('label="navigation"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("href='(.*?)'>(.*?)</a>",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = 'حرف '+title
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,731)
	return
def XaOuRkxFtPzQ(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-SERIES_FEATURED-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="slider"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,733,T6TRUSbecYGWIq29KF)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='moviesBlocks(.*?)list-group",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if Z05rTiu6LwakteK8VfY=='LATEST_SERIES': AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[1]
	else: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
		T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if 'movies.php' in url or Z05rTiu6LwakteK8VfY=='LATEST_MOVIES':
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,732,T6TRUSbecYGWIq29KF)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,733,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[-1]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,731)
	return
def Ra4XAK1tDxc3kfOrIdsjLpzmGN0(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-EPISODES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("class='moviesBlocks(.*?)script",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for title,SSqweDUBYv4bkO,T6TRUSbecYGWIq29KF,VV2izgqFs4dprlcE0ThJBAXGH in items:
			SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
			T6TRUSbecYGWIq29KF = LhFnEIuPHdoNc+'/'+T6TRUSbecYGWIq29KF
			title = title.strip(UpN1CezytPO9XoduhxZSD)
			title = title+UpN1CezytPO9XoduhxZSD+VV2izgqFs4dprlcE0ThJBAXGH.strip(UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,732,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q = []
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	vx14CNdbsZTz = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('source src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if vx14CNdbsZTz:
		SSqweDUBYv4bkO = vx14CNdbsZTz[0]
		if 'Referer=' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = SSqweDUBYv4bkO+'|Referer=https://www.arabic-toons.com'
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=__embed')
	else:
		ttTUG1rHxVqvESARk7o9l = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(r'dynamique.*?}\);', jS6fQGXeouTB7xKd32ZMy, ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not ttTUG1rHxVqvESARk7o9l: ttTUG1rHxVqvESARk7o9l = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(r'dynamique.*?}\)', jS6fQGXeouTB7xKd32ZMy, ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if ttTUG1rHxVqvESARk7o9l:
			x6ObtLdV3mX1Ja8lDuGC = ttTUG1rHxVqvESARk7o9l[0]
			EEFmbv9NL1xR = dict(ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(r'(\w+):\s*"([^"]+)"', x6ObtLdV3mX1Ja8lDuGC))
			NvJ0TdQIu8t6hoabWpe = ERgVvYA0TMIdUCa2KzFQDcZOPNin.search(r'const\s+(\w+)', x6ObtLdV3mX1Ja8lDuGC)
			wwazx8RA0V6J = NvJ0TdQIu8t6hoabWpe.group(1) if NvJ0TdQIu8t6hoabWpe else ""
			keys = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall(r'\$\{' + wwazx8RA0V6J + r'\.(\w+)\}', x6ObtLdV3mX1Ja8lDuGC)
			if EEFmbv9NL1xR and keys:
				SSqweDUBYv4bkO = "%s://%s/%s?%s" % (EEFmbv9NL1xR[keys[0]], EEFmbv9NL1xR[keys[1]], EEFmbv9NL1xR[keys[2]], EEFmbv9NL1xR[keys[3]])
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO+'?named=__embed')
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'%20')
	eE9BXgNu4MPKIbw2aLDl1AY3R = [gby0BnUuTNFk,'m']
	PYXSjrGHwWdz65ckR = ['مسلسلات','افلام']
	if showDialogs:
		EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = i4r2OdGLlMhDEWfCVU0TKe3('اختر النوع المطلوب:', PYXSjrGHwWdz65ckR)
		if EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc==-1: return
	else: EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc = 0
	type = eE9BXgNu4MPKIbw2aLDl1AY3R[EX8rHDwYCt9AGz4gqfJ6ZQFVMe0Oc]
	url = LhFnEIuPHdoNc+'/livesearch.php?'+type+'&q='+search
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'ARABICTOONS-SEARCH-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)<',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		SSqweDUBYv4bkO = LhFnEIuPHdoNc+'/'+SSqweDUBYv4bkO
		title = title.strip(UpN1CezytPO9XoduhxZSD)
		if type=='m': ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,732)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,733)
	return