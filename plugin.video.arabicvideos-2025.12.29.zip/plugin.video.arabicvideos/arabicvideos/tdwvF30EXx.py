# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'KATKOTTV'
JB9fyoHr05QOtPjp = '_KTV_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = []
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==810: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==811: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==812: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==813: WjryKiBebavP = S2urBMEk9V4v3sjeK(url)
	elif mode==819: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOTTV-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,819,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"primary-links"(.*?)"most-viewed"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if title in d2gCoAnYPG89O: continue
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,811)
	return
def Xw3tTz8UD4LK26C(url,type=gby0BnUuTNFk):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOTTV-TITLES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"home-content"(.*?)"footer"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		NGcX5a4OifEhZKrY7C0QVyjRA = []
		for T6TRUSbecYGWIq29KF,SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if 'episodes' not in type and Cso7iV0ZOw2UW5Ez:
				title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
				title = title.replace('اون لاين',gby0BnUuTNFk)
				if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
					ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,813,T6TRUSbecYGWIq29KF)
					NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
			else: ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,812,T6TRUSbecYGWIq29KF)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("'pagination'(.*?)footer",jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			title = Y7BxKQdU84R(title)
			ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,811,gby0BnUuTNFk,gby0BnUuTNFk,type)
	return
def S2urBMEk9V4v3sjeK(url):
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOTTV-SERIES-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"category".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO: Xw3tTz8UD4LK26C(SSqweDUBYv4bkO[0],'episodes')
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q = []
	Tf5ueYGZIFl1hraoEOVKi = url+'?do=watch'
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOTTV-PLAY-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('" src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if SSqweDUBYv4bkO:
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,gby0BnUuTNFk,'KATKOTTV-PLAY-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		y6yAgrGq2LNQYBUzsZcCW0xfPO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('post=(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if y6yAgrGq2LNQYBUzsZcCW0xfPO:
			y6yAgrGq2LNQYBUzsZcCW0xfPO = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(y6yAgrGq2LNQYBUzsZcCW0xfPO[0])
			if nqkybtoMBH: y6yAgrGq2LNQYBUzsZcCW0xfPO = y6yAgrGq2LNQYBUzsZcCW0xfPO.decode(JJQFjSIlALchiMzG9)
			y6yAgrGq2LNQYBUzsZcCW0xfPO = TqNUy3Z4SFWvplGwXC82A('dict',y6yAgrGq2LNQYBUzsZcCW0xfPO)
			vx14CNdbsZTz = y6yAgrGq2LNQYBUzsZcCW0xfPO['servers']
			K6ucHgjCtqf9wBZxXAUh3Db5EMJW = list(vx14CNdbsZTz.keys())
			vx14CNdbsZTz = list(vx14CNdbsZTz.values())
			kiSZOPl4rBqWcby7H = zip(K6ucHgjCtqf9wBZxXAUh3Db5EMJW,vx14CNdbsZTz)
			for title,SSqweDUBYv4bkO in kiSZOPl4rBqWcby7H:
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/?s='+search
	Xw3tTz8UD4LK26C(url,'search')
	return