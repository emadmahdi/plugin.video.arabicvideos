# -*- coding: utf-8 -*-
from V4OX6PRG0U import *
CC3nOPFMovd72u = 'MASAVIDEO'
JB9fyoHr05QOtPjp = '_MSV_'
LhFnEIuPHdoNc = wAcHkmPB8a.SITESURLS[CC3nOPFMovd72u][0]
d2gCoAnYPG89O = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = ''
def b2IhmMiR7W3VnPa581GEl6Nu(mode,url,text):
	if   mode==1040: WjryKiBebavP = x3xMQCnNkl9vPuDiBdV0UswS()
	elif mode==1041: WjryKiBebavP = Xw3tTz8UD4LK26C(url,text)
	elif mode==1042: WjryKiBebavP = HthKAzX6MnLDiIF4aEC5sukp8WfJST(url)
	elif mode==1043: WjryKiBebavP = tHWd5iUKp0uBRESTL1FCAOGabsV(url,text)
	elif mode==1044: WjryKiBebavP = Ce5f6gUsbyKJ12TDnVOB7WLAhG(url)
	elif mode==1049: WjryKiBebavP = a3NI0EopMZw(text)
	else: WjryKiBebavP = False
	return WjryKiBebavP
def x3xMQCnNkl9vPuDiBdV0UswS():
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',LhFnEIuPHdoNc,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-MENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'بحث في الموقع',gby0BnUuTNFk,1049,gby0BnUuTNFk,gby0BnUuTNFk,'_REMEMBERRESULTS_')
	ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''["']navslide-wrap["'](.*?)</ul>''',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if QKqM0CwXDk8APOoJFpyntRb:
		AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?</i>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in items:
			if title in d2gCoAnYPG89O: continue
			ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1044)
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('/category.php">(.*?)"navslide-divider"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''["']dropdown-menu["'](.*?)</ul>''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for xki4Q3jNVZzFAsaWOPCge in QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = AxiBv1cQueOs0.replace(xki4Q3jNVZzFAsaWOPCge,gby0BnUuTNFk)
	items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	for SSqweDUBYv4bkO,title in items:
		if not title: continue
		if title in d2gCoAnYPG89O: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		ygWIQGf25qwVxLkXrYDjp('folder',CC3nOPFMovd72u+'_SCRIPT_'+JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1044)
	return
def Ce5f6gUsbyKJ12TDnVOB7WLAhG(url):
	Svaq1ZRIpQNWCH0m2lr37diUyeLnh,vv7qYWmFwzBPofI5e2ls = [],[]
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-SUBMENU-1st')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"caret"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if l2Np9PfFqv4RcW7Y and '.php' in str(l2Np9PfFqv4RcW7Y):
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		AxiBv1cQueOs0 = AxiBv1cQueOs0.replace('"presentation"','</ul>')
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if not QKqM0CwXDk8APOoJFpyntRb: QKqM0CwXDk8APOoJFpyntRb = [(gby0BnUuTNFk,AxiBv1cQueOs0)]
		ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' فرز أو فلتر أو ترتيب '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
		for U4LRgsfMau2nr3Ay6WXqhkledw,AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			Svaq1ZRIpQNWCH0m2lr37diUyeLnh = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if U4LRgsfMau2nr3Ay6WXqhkledw: U4LRgsfMau2nr3Ay6WXqhkledw = U4LRgsfMau2nr3Ay6WXqhkledw+': '
			for SSqweDUBYv4bkO,title in Svaq1ZRIpQNWCH0m2lr37diUyeLnh:
				title = U4LRgsfMau2nr3Ay6WXqhkledw+title
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1041)
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-category-subcats"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if qsQxHTa4e0JYLUSKF7:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if 1 or len(vv7qYWmFwzBPofI5e2ls)<30:
			if Svaq1ZRIpQNWCH0m2lr37diUyeLnh: ygWIQGf25qwVxLkXrYDjp('link',MMDuRFyAGhOpnq4YmXa9Jc7dNfSx+' ===== ===== ===== '+GGy0cQe765nPYZ9E8Th,gby0BnUuTNFk,9999)
			for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls:
				if title in d2gCoAnYPG89O: continue
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1041)
	if not l2Np9PfFqv4RcW7Y and not qsQxHTa4e0JYLUSKF7: Xw3tTz8UD4LK26C(url)
	return
def Xw3tTz8UD4LK26C(url,Z05rTiu6LwakteK8VfY=gby0BnUuTNFk):
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		IciL6hoO5F1MDSVPjypWZs8kKx = headers.copy()
		IciL6hoO5F1MDSVPjypWZs8kKx['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'POST',url,data,IciL6hoO5F1MDSVPjypWZs8kKx,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-TITLES-1st')
	else:
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-TITLES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	AxiBv1cQueOs0,items = gby0BnUuTNFk,[]
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	if Z05rTiu6LwakteK8VfY=='ajax-search':
		AxiBv1cQueOs0 = jS6fQGXeouTB7xKd32ZMy
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)">(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title in vv7qYWmFwzBPofI5e2ls: items.append((gby0BnUuTNFk,SSqweDUBYv4bkO,title))
	elif Z05rTiu6LwakteK8VfY=='featured':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-carousel_featured"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_episodes':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	elif Z05rTiu6LwakteK8VfY=='new_movies':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"row pm-ul-browse-videos(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if len(QKqM0CwXDk8APOoJFpyntRb)>1: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[1]
	elif Z05rTiu6LwakteK8VfY=='featured_series':
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	else:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-grid"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb: AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
	if AxiBv1cQueOs0 and not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not items: return
	NGcX5a4OifEhZKrY7C0QVyjRA = []
	rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
		T6TRUSbecYGWIq29KF += '|Referer='+LhFnEIuPHdoNc
		if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
		title = Y7BxKQdU84R(title)
		Cso7iV0ZOw2UW5Ez = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('(.*?) (الحلقة|حلقة).\d+',title,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if any(value in title for value in rgo9XlJfTqj2KmP3ZGpL5CeUi1SMb):
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1042,T6TRUSbecYGWIq29KF)
		elif Z05rTiu6LwakteK8VfY=='new_episodes':
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1042,T6TRUSbecYGWIq29KF)
		elif Cso7iV0ZOw2UW5Ez:
			title = '_MOD_' + Cso7iV0ZOw2UW5Ez[0][0]
			if title not in NGcX5a4OifEhZKrY7C0QVyjRA:
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1043,T6TRUSbecYGWIq29KF)
				NGcX5a4OifEhZKrY7C0QVyjRA.append(title)
		else: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1043,T6TRUSbecYGWIq29KF)
	if 1:
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pagination(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)</a>',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO=='#': continue
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				title = Y7BxKQdU84R(title)
				ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+'صفحة '+title,SSqweDUBYv4bkO,1041)
	return
def tHWd5iUKp0uBRESTL1FCAOGabsV(url,YYOman4GEXScVfjg89bRkDq):
	Hr3FCpiuRKaB0NSQ1M47sfygXvoxd = mDR9euKnv4jMSdbEpwcktJz5W6Cf(url,'url')
	ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',url,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-EPISODES-2nd')
	jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
	l2Np9PfFqv4RcW7Y = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	gQmur3iRSZ9IAOX = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('pm-poster-img.*?src="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	T6TRUSbecYGWIq29KF = gQmur3iRSZ9IAOX[0] if gQmur3iRSZ9IAOX else gby0BnUuTNFk
	T6TRUSbecYGWIq29KF += '|Referer='+LhFnEIuPHdoNc
	items = []
	RTvjVPxz2QtwD7el9iy = False
	if l2Np9PfFqv4RcW7Y and not YYOman4GEXScVfjg89bRkDq:
		AxiBv1cQueOs0 = l2Np9PfFqv4RcW7Y[0]
		items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for YYOman4GEXScVfjg89bRkDq,title in items:
			YYOman4GEXScVfjg89bRkDq = YYOman4GEXScVfjg89bRkDq.strip('#')
			if len(items)>1: ygWIQGf25qwVxLkXrYDjp('folder',JB9fyoHr05QOtPjp+title,url,1043,T6TRUSbecYGWIq29KF,gby0BnUuTNFk,YYOman4GEXScVfjg89bRkDq)
			else: RTvjVPxz2QtwD7el9iy = True
	else: RTvjVPxz2QtwD7el9iy = True
	qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="'+YYOman4GEXScVfjg89bRkDq+'"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
	if not qsQxHTa4e0JYLUSKF7:
		qsQxHTa4e0JYLUSKF7 = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"AiredEPS"(.*?)</div>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if qsQxHTa4e0JYLUSKF7:
			AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
				title = title.replace('</em><span>',UpN1CezytPO9XoduhxZSD)
				ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1042,T6TRUSbecYGWIq29KF)
	elif qsQxHTa4e0JYLUSKF7 and RTvjVPxz2QtwD7el9iy:
		AxiBv1cQueOs0 = qsQxHTa4e0JYLUSKF7[0]
		vv7qYWmFwzBPofI5e2ls = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if vv7qYWmFwzBPofI5e2ls:
			ViXb7ZKAU9dvqNDLjnTeh,ggi0l2fDL1ysmpn6VWtxrhXSBIM3w = zip(*vv7qYWmFwzBPofI5e2ls)
			ggJYzprsBheH7jV = [T6TRUSbecYGWIq29KF]*len(vv7qYWmFwzBPofI5e2ls)
			items = zip(ggi0l2fDL1ysmpn6VWtxrhXSBIM3w,ViXb7ZKAU9dvqNDLjnTeh,ggJYzprsBheH7jV)
		if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for SSqweDUBYv4bkO,title,T6TRUSbecYGWIq29KF in items:
			T6TRUSbecYGWIq29KF += '|Referer='+LhFnEIuPHdoNc
			if 'http' not in SSqweDUBYv4bkO: SSqweDUBYv4bkO = Hr3FCpiuRKaB0NSQ1M47sfygXvoxd+'/'+SSqweDUBYv4bkO.strip('/')
			title = title.replace('</em><span>',UpN1CezytPO9XoduhxZSD)
			ygWIQGf25qwVxLkXrYDjp('video',JB9fyoHr05QOtPjp+title,SSqweDUBYv4bkO,1042,T6TRUSbecYGWIq29KF)
	return
def HthKAzX6MnLDiIF4aEC5sukp8WfJST(url):
	ytc3dVjPkMHCSmlzvBuO820Q,kNhgPmawJlXd3R0yov = [],[]
	jS6fQGXeouTB7xKd32ZMy = ''
	if 'post=' in jS6fQGXeouTB7xKd32ZMy:
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('id="player".*?href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
		y6yAgrGq2LNQYBUzsZcCW0xfPO = SSqweDUBYv4bkO.split('post=')[1]
		y6yAgrGq2LNQYBUzsZcCW0xfPO = dY1hxU8QXz7vD2Cj5ZtlJg64.b64decode(y6yAgrGq2LNQYBUzsZcCW0xfPO)
		if nqkybtoMBH: y6yAgrGq2LNQYBUzsZcCW0xfPO = y6yAgrGq2LNQYBUzsZcCW0xfPO.decode(JJQFjSIlALchiMzG9)
		y6yAgrGq2LNQYBUzsZcCW0xfPO = TqNUy3Z4SFWvplGwXC82A('dict',y6yAgrGq2LNQYBUzsZcCW0xfPO)
		vx14CNdbsZTz = y6yAgrGq2LNQYBUzsZcCW0xfPO['servers']
		K6ucHgjCtqf9wBZxXAUh3Db5EMJW = list(vx14CNdbsZTz.keys())
		vx14CNdbsZTz = list(vx14CNdbsZTz.values())
		kiSZOPl4rBqWcby7H = zip(K6ucHgjCtqf9wBZxXAUh3Db5EMJW,vx14CNdbsZTz)
		for title,SSqweDUBYv4bkO in kiSZOPl4rBqWcby7H:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+title+'__watch'
			ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	else:
		Tf5ueYGZIFl1hraoEOVKi = url.replace('watch.php','play.php')
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,gby0BnUuTNFk,'MASAVIDEO-PLAY2-1st')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		SSqweDUBYv4bkO = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"embedURL" href="(.*?)"',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if 0 and SSqweDUBYv4bkO:
			SSqweDUBYv4bkO = SSqweDUBYv4bkO[0]
			if SSqweDUBYv4bkO not in kNhgPmawJlXd3R0yov:
				kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__embed'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('list_server(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		if QKqM0CwXDk8APOoJFpyntRb:
			AxiBv1cQueOs0 = QKqM0CwXDk8APOoJFpyntRb[0]
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall("<iframe src='(.*?)'.*?<strong>(.*?)<",AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO in kNhgPmawJlXd3R0yov: continue
				kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__watch'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
		Tf5ueYGZIFl1hraoEOVKi = url.replace('watch.php','downloads.php')
		ccV0NKHwQpMun6FtZvAi = JuxPH6nwYtWMvFXjVSChA71Z3GcKgl(DNh1dgpa4BK,'GET',Tf5ueYGZIFl1hraoEOVKi,gby0BnUuTNFk,headers,gby0BnUuTNFk,False,'MASAVIDEO-PLAY-2nd')
		jS6fQGXeouTB7xKd32ZMy = ccV0NKHwQpMun6FtZvAi.content
		QKqM0CwXDk8APOoJFpyntRb = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('"pm-download"(.*?)</ul>',jS6fQGXeouTB7xKd32ZMy,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
		for AxiBv1cQueOs0 in QKqM0CwXDk8APOoJFpyntRb:
			items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<strong>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			if not items: items = ERgVvYA0TMIdUCa2KzFQDcZOPNin.findall('href="(.*?)".*?<span>(.*?)<',AxiBv1cQueOs0,ERgVvYA0TMIdUCa2KzFQDcZOPNin.DOTALL)
			for SSqweDUBYv4bkO,title in items:
				if SSqweDUBYv4bkO in kNhgPmawJlXd3R0yov: continue
				kNhgPmawJlXd3R0yov.append(SSqweDUBYv4bkO)
				TfYmiUDcZOCgQ86rENjVG1zaqXbWk = mDR9euKnv4jMSdbEpwcktJz5W6Cf(SSqweDUBYv4bkO,'name')
				SSqweDUBYv4bkO = SSqweDUBYv4bkO+'?named='+TfYmiUDcZOCgQ86rENjVG1zaqXbWk+'__download'
				ytc3dVjPkMHCSmlzvBuO820Q.append(SSqweDUBYv4bkO)
	import Wlc38MqyKf
	Wlc38MqyKf.x83jiSFgvZfKBnNzP4ErJclwb(ytc3dVjPkMHCSmlzvBuO820Q,CC3nOPFMovd72u,'video',url)
	return
def a3NI0EopMZw(search):
	search,K7ETgQ2pb4ylWIB3vDHjJ,showDialogs = ZZV4kLG1nmbIjt(search)
	if search==gby0BnUuTNFk: search = vRoGedUjt2Ac6pIbufBX8sKy()
	if search==gby0BnUuTNFk: return
	search = search.replace(UpN1CezytPO9XoduhxZSD,'+')
	url = LhFnEIuPHdoNc+'/search.php?keywords='+search
	Xw3tTz8UD4LK26C(url,'search')
	return