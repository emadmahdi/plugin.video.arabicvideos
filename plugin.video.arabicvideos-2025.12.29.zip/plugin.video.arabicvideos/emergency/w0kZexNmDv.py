# -*- coding: utf-8 -*-
import sys as CCGPNbhjumpKOnITkl
GdFTjAvrelfBgPSuihtnN1XkD = CCGPNbhjumpKOnITkl.version_info [0] == 2
jr3SJdpuKADmRionPaeZ = 2048
pDn48XoY1av = 7
def dhgmDepwaoLAxVEP0uZJyW98kfNG (WnjHDGKXm2uUTPyt5E46pzaqFi8):
	global H6fd1IVibehL2W
	opX1msPvyZ7QxjwdScFJ = ord (WnjHDGKXm2uUTPyt5E46pzaqFi8 [-1])
	qRZUwOr1c5uGbHNkt6SiyfTWA0mhX = WnjHDGKXm2uUTPyt5E46pzaqFi8 [:-1]
	zTQi7okpNrmYMd1j0vSKPn = opX1msPvyZ7QxjwdScFJ % len (qRZUwOr1c5uGbHNkt6SiyfTWA0mhX)
	PyOxJWphGnuLCN = qRZUwOr1c5uGbHNkt6SiyfTWA0mhX [:zTQi7okpNrmYMd1j0vSKPn] + qRZUwOr1c5uGbHNkt6SiyfTWA0mhX [zTQi7okpNrmYMd1j0vSKPn:]
	if GdFTjAvrelfBgPSuihtnN1XkD:
		Ogdp7CsZ4HIeAlLztU = unicode () .join ([unichr (ord (FupGTdWMbSzY9CEQqy3aLsrj) - jr3SJdpuKADmRionPaeZ - (JwkGLy2vXD5WdY4r6naRg0 + opX1msPvyZ7QxjwdScFJ) % pDn48XoY1av) for JwkGLy2vXD5WdY4r6naRg0, FupGTdWMbSzY9CEQqy3aLsrj in enumerate (PyOxJWphGnuLCN)])
	else:
		Ogdp7CsZ4HIeAlLztU = str () .join ([chr (ord (FupGTdWMbSzY9CEQqy3aLsrj) - jr3SJdpuKADmRionPaeZ - (JwkGLy2vXD5WdY4r6naRg0 + opX1msPvyZ7QxjwdScFJ) % pDn48XoY1av) for JwkGLy2vXD5WdY4r6naRg0, FupGTdWMbSzY9CEQqy3aLsrj in enumerate (PyOxJWphGnuLCN)])
	return eval (Ogdp7CsZ4HIeAlLztU)
bbEuLsmKwAfBXUMJTOSy078,OORVmA7kUxi,VonaFTMWqOY3kEf6x74=dhgmDepwaoLAxVEP0uZJyW98kfNG,dhgmDepwaoLAxVEP0uZJyW98kfNG,dhgmDepwaoLAxVEP0uZJyW98kfNG
z84RrHgBOdE7G,HL1nuBXmqAbIzDdiP6Og,knchpjDCtFqUISbAX=VonaFTMWqOY3kEf6x74,OORVmA7kUxi,bbEuLsmKwAfBXUMJTOSy078
Hz8Sy7XKfGvbr6xUjcDCph,J0GeukxI4Y78gWdMCUjq3HA,knRDviFYqSGbx4ypK0Tj=knchpjDCtFqUISbAX,HL1nuBXmqAbIzDdiP6Og,z84RrHgBOdE7G
ZaRwNKvUsQyFH,ffbs7EaxngdlCRKrV,TtNiC1HRD07IQXml9ABd5FszapbLgJ=knRDviFYqSGbx4ypK0Tj,J0GeukxI4Y78gWdMCUjq3HA,Hz8Sy7XKfGvbr6xUjcDCph
wwbtB8nGlFuvhd,jVGHxE19CKtNZhi7,PkfF5sen8MyTEGh0xJmSNc34l=TtNiC1HRD07IQXml9ABd5FszapbLgJ,ffbs7EaxngdlCRKrV,ZaRwNKvUsQyFH
tvFMhBlCdi2IOEpYUzso4Txeku6,ZijeaFX3osW6HEbtr4l2Vm1AfvQJ,SAlQIxLcaGBHbvTo57UjDsgudNWefJ=PkfF5sen8MyTEGh0xJmSNc34l,jVGHxE19CKtNZhi7,wwbtB8nGlFuvhd
zAfyOe6doFhND2M5C4w83LJsi,lWj0XFHn8PseEgRzqYDv,ld6RIc8GSbT9=SAlQIxLcaGBHbvTo57UjDsgudNWefJ,ZijeaFX3osW6HEbtr4l2Vm1AfvQJ,tvFMhBlCdi2IOEpYUzso4Txeku6
dlDz7E9jR6ir48LyTQsNp1c,ZZuoLUcXRyCv7Sd,WzwFO24ca9sIxDSBJvq5und=ld6RIc8GSbT9,lWj0XFHn8PseEgRzqYDv,zAfyOe6doFhND2M5C4w83LJsi
uRhUBDNLwF6980rs,UWiBnRorm2Zxd,wtc3HAPLoxvSCIzRbiOYUjM=WzwFO24ca9sIxDSBJvq5und,ZZuoLUcXRyCv7Sd,dlDz7E9jR6ir48LyTQsNp1c
eCrE6zyDq94p8J,KzmnWewxCcupB3FYL,IHt6zqyRUvQNnK2k8fBG9=wtc3HAPLoxvSCIzRbiOYUjM,UWiBnRorm2Zxd,uRhUBDNLwF6980rs
Ejotk5R8MIJbmD90PZ1ArQG,LGVsJHFnE0mpkSWR,vm20kMiF86bYaPjgSBpn5lEKRJc=IHt6zqyRUvQNnK2k8fBG9,KzmnWewxCcupB3FYL,eCrE6zyDq94p8J
import xbmc as ohgwBeZy6U73M9kvRPNtCjxO8If,xbmcgui as iVnuv64QGHTw2YqF,sys as CCGPNbhjumpKOnITkl,os as Z8pnhKf7Do5BQ,requests as nnfAEja5Fh8Q7s,re as NCZ6P9r52xoGqUbAD,xbmcvfs as bIozQ2smu3Sr8g9acqxe1jiPBRvC,base64 as v5lkE2agnefmoZhF,time as y4Cj6uRaoLer
rDT6g1JCsOHVpZe = J0GeukxI4Y78gWdMCUjq3HA(u"ࠫࠬࠀ")
def Bg3ntjrdFPJVDSKq2owuEcW6NQ(request):
	rLqy6O9UZGQeMv4cl5KSdAsXh = TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==uRhUBDNLwF6980rs(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): ohgwBeZy6U73M9kvRPNtCjxO8If.executebuiltin(lWj0XFHn8PseEgRzqYDv(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+rLqy6O9UZGQeMv4cl5KSdAsXh+J0GeukxI4Y78gWdMCUjq3HA(u"ࠨࠫࠪࠄ"))
	elif request==J0GeukxI4Y78gWdMCUjq3HA(u"ࠩࡶࡸࡴࡶࠧࠅ"): ohgwBeZy6U73M9kvRPNtCjxO8If.executebuiltin(wtc3HAPLoxvSCIzRbiOYUjM(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+rLqy6O9UZGQeMv4cl5KSdAsXh+ZZuoLUcXRyCv7Sd(u"ࠫ࠮࠭ࠇ"))
	return
def JZYE9scLarjDfWx4(iiVHW3uYq57ovOKS,oYDJa6Hj9M3uGr,eec1o5VgfFZlSXQbY4yr0,ajgZFYlWTSJ3mwLkeKtG,text):
	if not oYDJa6Hj9M3uGr: oYDJa6Hj9M3uGr = bbEuLsmKwAfBXUMJTOSy078(u"้ࠬไศࠩࠈ")
	if not eec1o5VgfFZlSXQbY4yr0: eec1o5VgfFZlSXQbY4yr0 = Ejotk5R8MIJbmD90PZ1ArQG(u"࠭ๆฺ็ࠪࠉ")
	if not ajgZFYlWTSJ3mwLkeKtG: ajgZFYlWTSJ3mwLkeKtG = ZijeaFX3osW6HEbtr4l2Vm1AfvQJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW: H5wurUbezk8pZDIEoGhgl7xcFm1C3X = iVnuv64QGHTw2YqF.Dialog().yesno(ajgZFYlWTSJ3mwLkeKtG,text,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,oYDJa6Hj9M3uGr,eec1o5VgfFZlSXQbY4yr0)
	else: H5wurUbezk8pZDIEoGhgl7xcFm1C3X = iVnuv64QGHTw2YqF.Dialog().yesno(ajgZFYlWTSJ3mwLkeKtG,text,oYDJa6Hj9M3uGr,eec1o5VgfFZlSXQbY4yr0)
	return H5wurUbezk8pZDIEoGhgl7xcFm1C3X
def mEz1b9CGTkaVoKv4SBr(iiVHW3uYq57ovOKS,Wxh7dIabwrEz9yF2AMiYS8cOq4t,ajgZFYlWTSJ3mwLkeKtG,text):
	if not ajgZFYlWTSJ3mwLkeKtG: ajgZFYlWTSJ3mwLkeKtG = bbEuLsmKwAfBXUMJTOSy078(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return iVnuv64QGHTw2YqF.Dialog().ok(ajgZFYlWTSJ3mwLkeKtG,text)
def naVb3u810tyAgdG(ajgZFYlWTSJ3mwLkeKtG=TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),jES89UAGeOm2agHrihkoP=rDT6g1JCsOHVpZe):
	jjPnt3NVwukgEFWU12xvceXyRrZKQ = iVnuv64QGHTw2YqF.Dialog().input(ajgZFYlWTSJ3mwLkeKtG,jES89UAGeOm2agHrihkoP,type=iVnuv64QGHTw2YqF.INPUT_ALPHANUM)
	jjPnt3NVwukgEFWU12xvceXyRrZKQ = jjPnt3NVwukgEFWU12xvceXyRrZKQ.strip(knchpjDCtFqUISbAX(u"ࠪࠤࠬࠍ")).replace(wtc3HAPLoxvSCIzRbiOYUjM(u"ࠫࠥࠦࠠࠡࠩࠎ"),eCrE6zyDq94p8J(u"ࠬࠦࠧࠏ")).replace(zAfyOe6doFhND2M5C4w83LJsi(u"࠭ࠠࠡࠢࠪࠐ"),SAlQIxLcaGBHbvTo57UjDsgudNWefJ(u"ࠧࠡࠩࠑ")).replace(PkfF5sen8MyTEGh0xJmSNc34l(u"ࠨࠢࠣࠫࠒ"),VonaFTMWqOY3kEf6x74(u"ࠩࠣࠫࠓ"))
	return jjPnt3NVwukgEFWU12xvceXyRrZKQ
def EEipc6A2zJF(uZUmPdTWsAzvQJjSixkBKqyefwL):
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,vm20kMiF86bYaPjgSBpn5lEKRJc(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=J0GeukxI4Y78gWdMCUjq3HA(u"࠱ࢫ"): return
	if not Z8pnhKf7Do5BQ.path.exists(uZUmPdTWsAzvQJjSixkBKqyefwL):
		mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = naVb3u810tyAgdG(OORVmA7kUxi(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	zxD0sai87XmIKd1bqWw2Jv = ohgwBeZy6U73M9kvRPNtCjxO8If.getInfoLabel(vm20kMiF86bYaPjgSBpn5lEKRJc(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࠧࠪࠩ࠘"))
	file = open(uZUmPdTWsAzvQJjSixkBKqyefwL,ld6RIc8GSbT9(u"ࠨࡴࡥࠫ࠙"))
	zauLkbgFyfs = Z8pnhKf7Do5BQ.path.getsize(uZUmPdTWsAzvQJjSixkBKqyefwL)
	if zauLkbgFyfs>Hz8Sy7XKfGvbr6xUjcDCph(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-Hz8Sy7XKfGvbr6xUjcDCph(u"࠴࠲࠴࠴࠵࠶ࢬ"),Z8pnhKf7Do5BQ.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(J0GeukxI4Y78gWdMCUjq3HA(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	HSXTop9NfV = NCZ6P9r52xoGqUbAD.findall(wwbtB8nGlFuvhd(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,NCZ6P9r52xoGqUbAD.DOTALL)
	if not HSXTop9NfV: HSXTop9NfV = NCZ6P9r52xoGqUbAD.findall(wwbtB8nGlFuvhd(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,NCZ6P9r52xoGqUbAD.DOTALL)
	if not HSXTop9NfV: HSXTop9NfV = NCZ6P9r52xoGqUbAD.findall(WzwFO24ca9sIxDSBJvq5und(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,NCZ6P9r52xoGqUbAD.DOTALL)
	HSXTop9NfV = HSXTop9NfV[bbEuLsmKwAfBXUMJTOSy078(u"࠲ࢭ")] if HSXTop9NfV else dlDz7E9jR6ir48LyTQsNp1c(u"࠭࠰࠱࠲࠳ࠫࠞ")
	HSXTop9NfV = HSXTop9NfV.split(LGVsJHFnE0mpkSWR(u"ࠧ࡝ࡰࠪࠟ"),z84RrHgBOdE7G(u"࠴ࢮ"))[VonaFTMWqOY3kEf6x74(u"࠴ࢯ")]
	if AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW: HSXTop9NfV = HSXTop9NfV.encode(tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	Hn2wqUDgN8fZdjKmYQOo0zBGeJM = Ejotk5R8MIJbmD90PZ1ArQG(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+HSXTop9NfV+PkfF5sen8MyTEGh0xJmSNc34l(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += ffbs7EaxngdlCRKrV(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+HSXTop9NfV+Ejotk5R8MIJbmD90PZ1ArQG(u"ࠬࠦ࠺ࠨࠤ")+UWiBnRorm2Zxd(u"࠭࡜࡯ࠩࠥ")+uRhUBDNLwF6980rs(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+zxD0sai87XmIKd1bqWw2Jv+J0GeukxI4Y78gWdMCUjq3HA(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(OORVmA7kUxi(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	JJhfpkHjQdWFBVKRt9SYXL5nu = v5lkE2agnefmoZhF.b64encode(data)
	OHW17BsljTU3IJYzGg = {VonaFTMWqOY3kEf6x74(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):Hn2wqUDgN8fZdjKmYQOo0zBGeJM,ffbs7EaxngdlCRKrV(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,wwbtB8nGlFuvhd(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):JJhfpkHjQdWFBVKRt9SYXL5nu}
	AwN5r9sRYOIBSptvb = SAlQIxLcaGBHbvTo57UjDsgudNWefJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	BfTanQ7GJ8NDO = nnfAEja5Fh8Q7s.request(LGVsJHFnE0mpkSWR(u"ࠧࡑࡑࡖࡘࠬ࠭"),AwN5r9sRYOIBSptvb,data=OHW17BsljTU3IJYzGg)
	if BfTanQ7GJ8NDO.status_code==wwbtB8nGlFuvhd(u"࠷࠶࠰ࢰ"): mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,J0GeukxI4Y78gWdMCUjq3HA(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,z84RrHgBOdE7G(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def zmlfuhMKbGN4Xc():
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,wwbtB8nGlFuvhd(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=z84RrHgBOdE7G(u"࠷ࢱ"): return
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = exnqpfPkzj2TQ5V1l(AsTu7wGJt5Yf8jPeODoHq4pN,HL1nuBXmqAbIzDdiP6Og(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,UWiBnRorm2Zxd(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def SnZaxdLQg4M():
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,uRhUBDNLwF6980rs(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=knRDviFYqSGbx4ypK0Tj(u"࠱ࢲ"): return
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = XCQvSLufKmdVj2AM(PewMdORJT67HA8ELlU2zsD,ZaRwNKvUsQyFH(u"ࡕࡴࡸࡩࣈ"),ZaRwNKvUsQyFH(u"ࡕࡴࡸࡩࣈ"),knRDviFYqSGbx4ypK0Tj(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,z84RrHgBOdE7G(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def exnqpfPkzj2TQ5V1l(Y3aB2cjLGROHFu,Gdb1UJ2lHTuB5sYx):
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࡖࡵࡹࡪࣉ")
	if Gdb1UJ2lHTuB5sYx:
		H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=eCrE6zyDq94p8J(u"࠲ࢳ"): return
	if Z8pnhKf7Do5BQ.path.exists(Y3aB2cjLGROHFu):
		try: Z8pnhKf7Do5BQ.remove(Y3aB2cjLGROHFu)
		except Exception as FbuZIWahoS2RPwGq:
			ssZWyFaDp4lJA732mbjQN5IYeRO0 = Hz8Sy7XKfGvbr6xUjcDCph(u"ࡉࡥࡱࡹࡥ࣊")
			if Gdb1UJ2lHTuB5sYx: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,str(FbuZIWahoS2RPwGq))
	if Gdb1UJ2lHTuB5sYx:
		if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,knchpjDCtFqUISbAX(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,ZaRwNKvUsQyFH(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return ssZWyFaDp4lJA732mbjQN5IYeRO0
def XCQvSLufKmdVj2AM(EawBUSNgWJ16GX2xrDjtQIoh4f3L,ZJmaVlgtCWL6hvx9iKPqI0cUd,Bla5PsXbJv70DEhVt,Gdb1UJ2lHTuB5sYx):
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = ZijeaFX3osW6HEbtr4l2Vm1AfvQJ(u"ࡘࡷࡻࡥ࣋")
	if Gdb1UJ2lHTuB5sYx:
		H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,EawBUSNgWJ16GX2xrDjtQIoh4f3L+OORVmA7kUxi(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=PkfF5sen8MyTEGh0xJmSNc34l(u"࠳ࢴ"): return
	if Z8pnhKf7Do5BQ.path.exists(EawBUSNgWJ16GX2xrDjtQIoh4f3L):
		for jQidFVDMoKCgU2,JxAZ3Ll5DPq,NaJ9CTmo4ELrzlj7dYD6nIqM0Q in Z8pnhKf7Do5BQ.walk(EawBUSNgWJ16GX2xrDjtQIoh4f3L,topdown=UWiBnRorm2Zxd(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for iru7wF0HD1kG4vhf5YP in NaJ9CTmo4ELrzlj7dYD6nIqM0Q:
				HGLrCtouydZMmhlOP = Z8pnhKf7Do5BQ.path.join(jQidFVDMoKCgU2,iru7wF0HD1kG4vhf5YP)
				try: Z8pnhKf7Do5BQ.remove(HGLrCtouydZMmhlOP)
				except Exception as FbuZIWahoS2RPwGq:
					ssZWyFaDp4lJA732mbjQN5IYeRO0 = OORVmA7kUxi(u"ࡌࡡ࡭ࡵࡨ࣍")
					if Gdb1UJ2lHTuB5sYx: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,str(FbuZIWahoS2RPwGq))
			if ZJmaVlgtCWL6hvx9iKPqI0cUd:
				for jHT1Psf0EpkOm39La7gX in JxAZ3Ll5DPq:
					dQZ6ClUKALGub9WshP = Z8pnhKf7Do5BQ.path.join(jQidFVDMoKCgU2,jHT1Psf0EpkOm39La7gX)
					try: Z8pnhKf7Do5BQ.rmdir(dQZ6ClUKALGub9WshP)
					except: pass
		if Bla5PsXbJv70DEhVt:
			try: Z8pnhKf7Do5BQ.rmdir(jQidFVDMoKCgU2)
			except: pass
	if Gdb1UJ2lHTuB5sYx:
		if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,knchpjDCtFqUISbAX(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,ZZuoLUcXRyCv7Sd(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return ssZWyFaDp4lJA732mbjQN5IYeRO0
def XVfiUP9gG8():
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,bbEuLsmKwAfBXUMJTOSy078(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=bbEuLsmKwAfBXUMJTOSy078(u"࠴ࢵ"): return
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = XCQvSLufKmdVj2AM(VxmatFAGNk05p3K,z84RrHgBOdE7G(u"ࡕࡴࡸࡩ࣏"),wwbtB8nGlFuvhd(u"ࡆࡢ࡮ࡶࡩ࣎"),z84RrHgBOdE7G(u"ࡕࡴࡸࡩ࣏"))
	if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,Hz8Sy7XKfGvbr6xUjcDCph(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,SAlQIxLcaGBHbvTo57UjDsgudNWefJ(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def UGD7rSWtCH24szMx6ZEbN3yXO():
	AwN5r9sRYOIBSptvb = lWj0XFHn8PseEgRzqYDv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	BfTanQ7GJ8NDO = nnfAEja5Fh8Q7s.request(eCrE6zyDq94p8J(u"ࠬࡍࡅࡕࠩࡀ"),AwN5r9sRYOIBSptvb)
	jYDrvW8BoLzsKQcbft0lmXNOFh6G = BfTanQ7GJ8NDO.content
	jYDrvW8BoLzsKQcbft0lmXNOFh6G = jYDrvW8BoLzsKQcbft0lmXNOFh6G.decode(PkfF5sen8MyTEGh0xJmSNc34l(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	NaJ9CTmo4ELrzlj7dYD6nIqM0Q = NCZ6P9r52xoGqUbAD.findall(PkfF5sen8MyTEGh0xJmSNc34l(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),jYDrvW8BoLzsKQcbft0lmXNOFh6G,NCZ6P9r52xoGqUbAD.DOTALL)
	NaJ9CTmo4ELrzlj7dYD6nIqM0Q = sorted(NaJ9CTmo4ELrzlj7dYD6nIqM0Q,reverse=lWj0XFHn8PseEgRzqYDv(u"ࡖࡵࡹࡪ࣐"))
	z0oUeTKaMf3vFpn47VBkOI = iVnuv64QGHTw2YqF.Dialog().select(LGVsJHFnE0mpkSWR(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),NaJ9CTmo4ELrzlj7dYD6nIqM0Q)
	if z0oUeTKaMf3vFpn47VBkOI==-ZZuoLUcXRyCv7Sd(u"࠵ࢶ"): return
	filename = NaJ9CTmo4ELrzlj7dYD6nIqM0Q[z0oUeTKaMf3vFpn47VBkOI]
	if AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW: filename = filename.encode(jVGHxE19CKtNZhi7(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	T1WLxR7m6HcCQF9SuGjDJ = AwN5r9sRYOIBSptvb.rsplit(wtc3HAPLoxvSCIzRbiOYUjM(u"ࠪ࠳ࠬࡅ"),eCrE6zyDq94p8J(u"࠶ࢷ"))[eCrE6zyDq94p8J(u"࠶ࢸ")]+knchpjDCtFqUISbAX(u"ࠫ࠴࠭ࡆ")+lWj0XFHn8PseEgRzqYDv(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+VonaFTMWqOY3kEf6x74(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = knRDviFYqSGbx4ypK0Tj(u"ࡉࡥࡱࡹࡥ࣑")
	BfTanQ7GJ8NDO = nnfAEja5Fh8Q7s.request(tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࠧࡈࡇࡗࠫࡉ"),T1WLxR7m6HcCQF9SuGjDJ)
	if BfTanQ7GJ8NDO.status_code==tvFMhBlCdi2IOEpYUzso4Txeku6(u"࠲࠱࠲ࢹ"):
		QXt6fFrPAZaxq51OkjlbR8EWcJg = BfTanQ7GJ8NDO.content
		import zipfile as efDQRGA7tNpnVYqlsoa10k3gO,io as aa39Y2ISCREMtBdbFApKs
		jQV0LO8zaUW29Rh61iHFbDEZ5XuT = aa39Y2ISCREMtBdbFApKs.BytesIO(QXt6fFrPAZaxq51OkjlbR8EWcJg)
		XCQvSLufKmdVj2AM(MJBt62bD9f7la,zAfyOe6doFhND2M5C4w83LJsi(u"࡙ࡸࡵࡦ࣓"),zAfyOe6doFhND2M5C4w83LJsi(u"࡙ࡸࡵࡦ࣓"),KzmnWewxCcupB3FYL(u"ࡊࡦࡲࡳࡦ࣒"))
		RONg2dVw0l6MP1BLufnvsYZ58Cj7 = efDQRGA7tNpnVYqlsoa10k3gO.ZipFile(jQV0LO8zaUW29Rh61iHFbDEZ5XuT)
		RONg2dVw0l6MP1BLufnvsYZ58Cj7.extractall(j8gxf3dUYTZzM)
		y4Cj6uRaoLer.sleep(jVGHxE19CKtNZhi7(u"࠲ࢺ"))
		ohgwBeZy6U73M9kvRPNtCjxO8If.executebuiltin(VonaFTMWqOY3kEf6x74(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		y4Cj6uRaoLer.sleep(ld6RIc8GSbT9(u"࠳ࢻ"))
		zTNu70UMOaKpiAdfmXkCV2BtYJsE4 = ohgwBeZy6U73M9kvRPNtCjxO8If.executeJSONRPC(UWiBnRorm2Zxd(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if WzwFO24ca9sIxDSBJvq5und(u"ࠫࡔࡑࠧࡍ") in zTNu70UMOaKpiAdfmXkCV2BtYJsE4: ssZWyFaDp4lJA732mbjQN5IYeRO0 = LGVsJHFnE0mpkSWR(u"࡚ࡲࡶࡧࣔ")
	if ssZWyFaDp4lJA732mbjQN5IYeRO0:
		mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,VonaFTMWqOY3kEf6x74(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = ld6RIc8GSbT9(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		eunWh5zSZVtLwsMHX6liAp(msg)
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,KzmnWewxCcupB3FYL(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def eunWh5zSZVtLwsMHX6liAp(msg=z84RrHgBOdE7G(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),WzwFO24ca9sIxDSBJvq5und(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),rDT6g1JCsOHVpZe,msg)
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X==-TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"࠴ࢼ"): return
	n6Wjzpm0yNlTMUk1LowrPYqVid = LGVsJHFnE0mpkSWR(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if H5wurUbezk8pZDIEoGhgl7xcFm1C3X else LGVsJHFnE0mpkSWR(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = KzmnWewxCcupB3FYL(u"ࡆࡢ࡮ࡶࡩࣕ")
	mFsJtSNIL21R8aHr = ffbs7EaxngdlCRKrV(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	VV9IJToSpkgEBMevOz2NH6QjiKq07 = ld6RIc8GSbT9(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW else eCrE6zyDq94p8J(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as RRm16azkwF
		sM8ENDFfBShQTUrH9J0vi1Y = RRm16azkwF.connect(YfuxVemzrGJ3A51W9SIEjt)
		sM8ENDFfBShQTUrH9J0vi1Y.text_factory = str
		Le57GowbJIFj = sM8ENDFfBShQTUrH9J0vi1Y.cursor()
		Le57GowbJIFj.execute(zAfyOe6doFhND2M5C4w83LJsi(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+lWj0XFHn8PseEgRzqYDv(u"ࠪࠦࠥࡁ࡚ࠧ"))
		U3S8rPesLtyo1ckw9pdKEgIfCObGu4 = Le57GowbJIFj.fetchall()
		if U3S8rPesLtyo1ckw9pdKEgIfCObGu4 and mFsJtSNIL21R8aHr not in str(U3S8rPesLtyo1ckw9pdKEgIfCObGu4): Le57GowbJIFj.execute(wwbtB8nGlFuvhd(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+mFsJtSNIL21R8aHr+z84RrHgBOdE7G(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+J0GeukxI4Y78gWdMCUjq3HA(u"࠭ࠢࠡ࠽ࠪ࡝"))
		Le57GowbJIFj.execute(jVGHxE19CKtNZhi7(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+VV9IJToSpkgEBMevOz2NH6QjiKq07+LGVsJHFnE0mpkSWR(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+VonaFTMWqOY3kEf6x74(u"ࠩࠥࠤࡀ࠭ࡠ"))
		U3S8rPesLtyo1ckw9pdKEgIfCObGu4 = Le57GowbJIFj.fetchall()
		bnavLcVMCFHJidum2AxRsrOew7KpEQ = J0GeukxI4Y78gWdMCUjq3HA(u"ࡈࡤࡰࡸ࡫ࣗ") if U3S8rPesLtyo1ckw9pdKEgIfCObGu4 else WzwFO24ca9sIxDSBJvq5und(u"ࡕࡴࡸࡩࣖ")
		if not bnavLcVMCFHJidum2AxRsrOew7KpEQ and lWj0XFHn8PseEgRzqYDv(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in n6Wjzpm0yNlTMUk1LowrPYqVid: Le57GowbJIFj.execute(wtc3HAPLoxvSCIzRbiOYUjM(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+VV9IJToSpkgEBMevOz2NH6QjiKq07+tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+zAfyOe6doFhND2M5C4w83LJsi(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif bnavLcVMCFHJidum2AxRsrOew7KpEQ and LGVsJHFnE0mpkSWR(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in n6Wjzpm0yNlTMUk1LowrPYqVid:
			if AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW: Le57GowbJIFj.execute(ffbs7EaxngdlCRKrV(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+VV9IJToSpkgEBMevOz2NH6QjiKq07+KzmnWewxCcupB3FYL(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+knRDviFYqSGbx4ypK0Tj(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: Le57GowbJIFj.execute(UWiBnRorm2Zxd(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+VV9IJToSpkgEBMevOz2NH6QjiKq07+PkfF5sen8MyTEGh0xJmSNc34l(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt+LGVsJHFnE0mpkSWR(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		sM8ENDFfBShQTUrH9J0vi1Y.commit()
		sM8ENDFfBShQTUrH9J0vi1Y.close()
		ssZWyFaDp4lJA732mbjQN5IYeRO0 = lWj0XFHn8PseEgRzqYDv(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if ssZWyFaDp4lJA732mbjQN5IYeRO0:
		y4Cj6uRaoLer.sleep(knRDviFYqSGbx4ypK0Tj(u"࠵ࢽ"))
		ohgwBeZy6U73M9kvRPNtCjxO8If.executebuiltin(wtc3HAPLoxvSCIzRbiOYUjM(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		y4Cj6uRaoLer.sleep(ZijeaFX3osW6HEbtr4l2Vm1AfvQJ(u"࠶ࢾ"))
		mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,VonaFTMWqOY3kEf6x74(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def Z2X1jdJY4UTVNBRsnqr8DalH5Lgf06():
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,VonaFTMWqOY3kEf6x74(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=dlDz7E9jR6ir48LyTQsNp1c(u"࠷ࢿ"): return
	iT9wUudC6rZFoaKOV = XCQvSLufKmdVj2AM(JEXn8aqkIRBdzwy0urtWUPT9ZjLSc,lWj0XFHn8PseEgRzqYDv(u"࡙ࡸࡵࡦࣚ"),vm20kMiF86bYaPjgSBpn5lEKRJc(u"ࡊࡦࡲࡳࡦࣙ"),vm20kMiF86bYaPjgSBpn5lEKRJc(u"ࡊࡦࡲࡳࡦࣙ"))
	fa0QWhCs4wmPG3v = XCQvSLufKmdVj2AM(TTA2jpxyXQHfBr3K4s,IHt6zqyRUvQNnK2k8fBG9(u"ࡔࡳࡷࡨࣜ"),eCrE6zyDq94p8J(u"ࡌࡡ࡭ࡵࡨࣛ"),eCrE6zyDq94p8J(u"ࡌࡡ࡭ࡵࡨࣛ"))
	btRmg68r5IoKhQNZMafWk2dU79 = XCQvSLufKmdVj2AM(khwGuJVQlmjRTCp,ZZuoLUcXRyCv7Sd(u"ࡖࡵࡹࡪࣞ"),knRDviFYqSGbx4ypK0Tj(u"ࡇࡣ࡯ࡷࡪࣝ"),knRDviFYqSGbx4ypK0Tj(u"ࡇࡣ࡯ࡷࡪࣝ"))
	js0Yw2upbMQrDHo3mNWAhfPxB = Te30nliDbkHAO7(KzmnWewxCcupB3FYL(u"ࡗࡶࡺ࡫ࣟ"))
	RLVQkrPs1iDU4K0Y3 = MYD8usNaJ7AZb13FTOUI4zV()
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = all([iT9wUudC6rZFoaKOV,fa0QWhCs4wmPG3v,btRmg68r5IoKhQNZMafWk2dU79,js0Yw2upbMQrDHo3mNWAhfPxB,RLVQkrPs1iDU4K0Y3])
	if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,ld6RIc8GSbT9(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,knRDviFYqSGbx4ypK0Tj(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def AWURoTPk6KjV785():
	H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,Hz8Sy7XKfGvbr6xUjcDCph(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=bbEuLsmKwAfBXUMJTOSy078(u"࠱ࣀ"): return
	eUMSZmaoi7pL9cknDX = wwbtB8nGlFuvhd(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	WF7DyKZGbYR49XV2fti5 = uRhUBDNLwF6980rs(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	M6RrOj8swo = knchpjDCtFqUISbAX(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	f9LIbVAx3p = ld6RIc8GSbT9(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	MVvyUuIbx6oqCZ9zJ2rDpenwT1tL = wtc3HAPLoxvSCIzRbiOYUjM(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	Ryui5lkZz3sY8nqNpJ = WzwFO24ca9sIxDSBJvq5und(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	iT9wUudC6rZFoaKOV = XCQvSLufKmdVj2AM(eUMSZmaoi7pL9cknDX,PkfF5sen8MyTEGh0xJmSNc34l(u"࡙ࡸࡵࡦ࣡"),z84RrHgBOdE7G(u"ࡊࡦࡲࡳࡦ࣠"),z84RrHgBOdE7G(u"ࡊࡦࡲࡳࡦ࣠"))
	fa0QWhCs4wmPG3v = XCQvSLufKmdVj2AM(WF7DyKZGbYR49XV2fti5,ZZuoLUcXRyCv7Sd(u"ࡔࡳࡷࡨࣣ"),UWiBnRorm2Zxd(u"ࡌࡡ࡭ࡵࡨ࣢"),UWiBnRorm2Zxd(u"ࡌࡡ࡭ࡵࡨ࣢"))
	btRmg68r5IoKhQNZMafWk2dU79 = XCQvSLufKmdVj2AM(M6RrOj8swo,PkfF5sen8MyTEGh0xJmSNc34l(u"ࡖࡵࡹࡪࣥ"),UWiBnRorm2Zxd(u"ࡇࡣ࡯ࡷࡪࣤ"),UWiBnRorm2Zxd(u"ࡇࡣ࡯ࡷࡪࣤ"))
	js0Yw2upbMQrDHo3mNWAhfPxB = XCQvSLufKmdVj2AM(f9LIbVAx3p,z84RrHgBOdE7G(u"ࡘࡷࡻࡥࣧ"),tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࡉࡥࡱࡹࡥࣦ"),tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࡉࡥࡱࡹࡥࣦ"))
	RLVQkrPs1iDU4K0Y3 = XCQvSLufKmdVj2AM(MVvyUuIbx6oqCZ9zJ2rDpenwT1tL,wwbtB8nGlFuvhd(u"࡚ࡲࡶࡧࣩ"),Hz8Sy7XKfGvbr6xUjcDCph(u"ࡋࡧ࡬ࡴࡧࣨ"),Hz8Sy7XKfGvbr6xUjcDCph(u"ࡋࡧ࡬ࡴࡧࣨ"))
	TSEVXByOcC = XCQvSLufKmdVj2AM(Ryui5lkZz3sY8nqNpJ,tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࡕࡴࡸࡩ࣫"),TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࡆࡢ࡮ࡶࡩ࣪"),TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࡆࡢ࡮ࡶࡩ࣪"))
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = all([iT9wUudC6rZFoaKOV,fa0QWhCs4wmPG3v,btRmg68r5IoKhQNZMafWk2dU79,js0Yw2upbMQrDHo3mNWAhfPxB,RLVQkrPs1iDU4K0Y3,TSEVXByOcC])
	if ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,ld6RIc8GSbT9(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def Te30nliDbkHAO7(Gdb1UJ2lHTuB5sYx):
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = UWiBnRorm2Zxd(u"ࡖࡵࡹࡪ࣬")
	if Gdb1UJ2lHTuB5sYx:
		H5wurUbezk8pZDIEoGhgl7xcFm1C3X = JZYE9scLarjDfWx4(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,zAfyOe6doFhND2M5C4w83LJsi(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if H5wurUbezk8pZDIEoGhgl7xcFm1C3X!=KzmnWewxCcupB3FYL(u"࠲ࣁ"): return
	try:
		import sqlite3 as RRm16azkwF
		pf2Fg4EC6ochsuRaeY = RRm16azkwF.connect(EcoRQXIiYarvsFHkhy)
		pf2Fg4EC6ochsuRaeY.text_factory = str
		Le57GowbJIFj = pf2Fg4EC6ochsuRaeY.cursor()
		Le57GowbJIFj.execute(Ejotk5R8MIJbmD90PZ1ArQG(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		Le57GowbJIFj.execute(J0GeukxI4Y78gWdMCUjq3HA(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		Le57GowbJIFj.execute(jVGHxE19CKtNZhi7(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		pf2Fg4EC6ochsuRaeY.commit()
		Le57GowbJIFj.execute(eCrE6zyDq94p8J(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		pf2Fg4EC6ochsuRaeY.close()
	except: ssZWyFaDp4lJA732mbjQN5IYeRO0 = vm20kMiF86bYaPjgSBpn5lEKRJc(u"ࡉࡥࡱࡹࡥ࣭")
	if Gdb1UJ2lHTuB5sYx and ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,knchpjDCtFqUISbAX(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return ssZWyFaDp4lJA732mbjQN5IYeRO0
def MYD8usNaJ7AZb13FTOUI4zV():
	ssZWyFaDp4lJA732mbjQN5IYeRO0 = Hz8Sy7XKfGvbr6xUjcDCph(u"ࡘࡷࡻࡥ࣮")
	for file in Z8pnhKf7Do5BQ.listdir(SauQIDw0YdPXxfcOW3Fy2vk):
		if ZaRwNKvUsQyFH(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or HL1nuBXmqAbIzDdiP6Og(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		HGLrCtouydZMmhlOP = Z8pnhKf7Do5BQ.path.join(SauQIDw0YdPXxfcOW3Fy2vk,file)
		try:
			Z8pnhKf7Do5BQ.remove(HGLrCtouydZMmhlOP)
		except Exception as FbuZIWahoS2RPwGq:
			ssZWyFaDp4lJA732mbjQN5IYeRO0 = TtNiC1HRD07IQXml9ABd5FszapbLgJ(u"ࡋࡧ࡬ࡴࡧ࣯")
			if Gdb1UJ2lHTuB5sYx and ssZWyFaDp4lJA732mbjQN5IYeRO0: mEz1b9CGTkaVoKv4SBr(rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,rDT6g1JCsOHVpZe,str(FbuZIWahoS2RPwGq))
	return ssZWyFaDp4lJA732mbjQN5IYeRO0
Bg3ntjrdFPJVDSKq2owuEcW6NQ(uRhUBDNLwF6980rs(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
alsXoeWN46 = CCGPNbhjumpKOnITkl.argv[WzwFO24ca9sIxDSBJvq5und(u"࠳ࣂ")]
ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt = wwbtB8nGlFuvhd(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
gUj78MYx5N04wpeLi = ohgwBeZy6U73M9kvRPNtCjxO8If.getInfoLabel(LGVsJHFnE0mpkSWR(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
uwjSc8LalXvqysBbUV = NCZ6P9r52xoGqUbAD.findall(zAfyOe6doFhND2M5C4w83LJsi(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),gUj78MYx5N04wpeLi,NCZ6P9r52xoGqUbAD.DOTALL)
uwjSc8LalXvqysBbUV = float(uwjSc8LalXvqysBbUV[VonaFTMWqOY3kEf6x74(u"࠳ࣃ")])
AAZpSiP7HbnjKqsVQNYyuB9eD4lTrW = uwjSc8LalXvqysBbUV<tvFMhBlCdi2IOEpYUzso4Txeku6(u"࠵࠾ࣄ")
lm4DjU2qB3rxKZA61PCJTVd = uwjSc8LalXvqysBbUV>tvFMhBlCdi2IOEpYUzso4Txeku6(u"࠶࠾࠮࠺࠻ࣅ")
if lm4DjU2qB3rxKZA61PCJTVd:
	SauQIDw0YdPXxfcOW3Fy2vk = bIozQ2smu3Sr8g9acqxe1jiPBRvC.translatePath(zAfyOe6doFhND2M5C4w83LJsi(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	WydKNDLv0k5Tug = bIozQ2smu3Sr8g9acqxe1jiPBRvC.translatePath(dlDz7E9jR6ir48LyTQsNp1c(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	nnRyc4d7WYbOMBi3HTZGX0jKV6DwrN = bIozQ2smu3Sr8g9acqxe1jiPBRvC.translatePath(ZijeaFX3osW6HEbtr4l2Vm1AfvQJ(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	YfuxVemzrGJ3A51W9SIEjt = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,IHt6zqyRUvQNnK2k8fBG9(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),Ejotk5R8MIJbmD90PZ1ArQG(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),IHt6zqyRUvQNnK2k8fBG9(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	SauQIDw0YdPXxfcOW3Fy2vk = ohgwBeZy6U73M9kvRPNtCjxO8If.translatePath(HL1nuBXmqAbIzDdiP6Og(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	WydKNDLv0k5Tug = ohgwBeZy6U73M9kvRPNtCjxO8If.translatePath(eCrE6zyDq94p8J(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	nnRyc4d7WYbOMBi3HTZGX0jKV6DwrN = ohgwBeZy6U73M9kvRPNtCjxO8If.translatePath(z84RrHgBOdE7G(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	YfuxVemzrGJ3A51W9SIEjt = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,z84RrHgBOdE7G(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),J0GeukxI4Y78gWdMCUjq3HA(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),uRhUBDNLwF6980rs(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
m5jqEYgUfSpPN = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,KzmnWewxCcupB3FYL(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),HL1nuBXmqAbIzDdiP6Og(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt)
AsTu7wGJt5Yf8jPeODoHq4pN = Z8pnhKf7Do5BQ.path.join(m5jqEYgUfSpPN,bbEuLsmKwAfBXUMJTOSy078(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
PewMdORJT67HA8ELlU2zsD = Z8pnhKf7Do5BQ.path.join(nnRyc4d7WYbOMBi3HTZGX0jKV6DwrN,ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt)
khwGuJVQlmjRTCp = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,jVGHxE19CKtNZhi7(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),ffbs7EaxngdlCRKrV(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
j8gxf3dUYTZzM = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,OORVmA7kUxi(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
MJBt62bD9f7la = Z8pnhKf7Do5BQ.path.join(j8gxf3dUYTZzM,ZEqj4SWdi6KAeG59IwfpR8xUFDLcHt)
JEXn8aqkIRBdzwy0urtWUPT9ZjLSc = Z8pnhKf7Do5BQ.path.join(j8gxf3dUYTZzM,ZaRwNKvUsQyFH(u"ࠪࡸࡪࡳࡰࠨ࢙"))
TTA2jpxyXQHfBr3K4s = Z8pnhKf7Do5BQ.path.join(j8gxf3dUYTZzM,zAfyOe6doFhND2M5C4w83LJsi(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
EcoRQXIiYarvsFHkhy = Z8pnhKf7Do5BQ.path.join(WydKNDLv0k5Tug,LGVsJHFnE0mpkSWR(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),IHt6zqyRUvQNnK2k8fBG9(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),tvFMhBlCdi2IOEpYUzso4Txeku6(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
VxmatFAGNk05p3K = Z8pnhKf7Do5BQ.path.join(PewMdORJT67HA8ELlU2zsD,wtc3HAPLoxvSCIzRbiOYUjM(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
ptjxyvNaiX = Z8pnhKf7Do5BQ.path.join(SauQIDw0YdPXxfcOW3Fy2vk,HL1nuBXmqAbIzDdiP6Og(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
Hy524t1i3PoC8e9I6U = Z8pnhKf7Do5BQ.path.join(SauQIDw0YdPXxfcOW3Fy2vk,wwbtB8nGlFuvhd(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   alsXoeWN46==uRhUBDNLwF6980rs(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: EEipc6A2zJF(ptjxyvNaiX)
elif alsXoeWN46==bbEuLsmKwAfBXUMJTOSy078(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: EEipc6A2zJF(Hy524t1i3PoC8e9I6U)
elif alsXoeWN46==knRDviFYqSGbx4ypK0Tj(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: zmlfuhMKbGN4Xc()
elif alsXoeWN46==KzmnWewxCcupB3FYL(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: SnZaxdLQg4M()
elif alsXoeWN46==wwbtB8nGlFuvhd(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: Z2X1jdJY4UTVNBRsnqr8DalH5Lgf06()
elif alsXoeWN46==vm20kMiF86bYaPjgSBpn5lEKRJc(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: AWURoTPk6KjV785()
elif alsXoeWN46==lWj0XFHn8PseEgRzqYDv(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: UGD7rSWtCH24szMx6ZEbN3yXO()
elif alsXoeWN46==ffbs7EaxngdlCRKrV(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: eunWh5zSZVtLwsMHX6liAp()
elif alsXoeWN46==KzmnWewxCcupB3FYL(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: XVfiUP9gG8()
Bg3ntjrdFPJVDSKq2owuEcW6NQ(SAlQIxLcaGBHbvTo57UjDsgudNWefJ(u"࠭ࡳࡵࡱࡳࠫࢪ"))