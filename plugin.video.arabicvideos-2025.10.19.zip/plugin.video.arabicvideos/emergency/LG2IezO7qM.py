# -*- coding: utf-8 -*-
import sys as B7UfAHlPZsdYqiCy61nJV
PkOHdBZbX91lpasVNRAjgIYxG8 = B7UfAHlPZsdYqiCy61nJV.version_info [0] == 2
Z0m6nVBgjaKG = 2048
k3k4yHOvx6095UuTIjgVG = 7
def tSqJ4jdFpQKWefiz3Pr0U7 (JD1I67ZCbKtOw45mN):
	global ssFTmeQbY2GDXNCPHM
	ucjWDoFefO8iKBam6x02 = ord (JD1I67ZCbKtOw45mN [-1])
	cgQEIjB2SG8WJN6D7T = JD1I67ZCbKtOw45mN [:-1]
	GixNOeFjywmabQt = ucjWDoFefO8iKBam6x02 % len (cgQEIjB2SG8WJN6D7T)
	DHlGrIVTkK2hAnSQx6vYF = cgQEIjB2SG8WJN6D7T [:GixNOeFjywmabQt] + cgQEIjB2SG8WJN6D7T [GixNOeFjywmabQt:]
	if PkOHdBZbX91lpasVNRAjgIYxG8:
		Z9jOHNflzW3gSB = unicode () .join ([unichr (ord (wyW5LlPnk4FEzfedSa6To) - Z0m6nVBgjaKG - (MI4gl1Nt2C5cBAVmdzHLxkJOoXF9a + ucjWDoFefO8iKBam6x02) % k3k4yHOvx6095UuTIjgVG) for MI4gl1Nt2C5cBAVmdzHLxkJOoXF9a, wyW5LlPnk4FEzfedSa6To in enumerate (DHlGrIVTkK2hAnSQx6vYF)])
	else:
		Z9jOHNflzW3gSB = str () .join ([chr (ord (wyW5LlPnk4FEzfedSa6To) - Z0m6nVBgjaKG - (MI4gl1Nt2C5cBAVmdzHLxkJOoXF9a + ucjWDoFefO8iKBam6x02) % k3k4yHOvx6095UuTIjgVG) for MI4gl1Nt2C5cBAVmdzHLxkJOoXF9a, wyW5LlPnk4FEzfedSa6To in enumerate (DHlGrIVTkK2hAnSQx6vYF)])
	return eval (Z9jOHNflzW3gSB)
UcN63jgqbCpOSK,dOsjwA8uPMD3g,U3fJTNyc5LdRX7wpEOGi=tSqJ4jdFpQKWefiz3Pr0U7,tSqJ4jdFpQKWefiz3Pr0U7,tSqJ4jdFpQKWefiz3Pr0U7
tnsyF7cGpvfMU6PWExDlTm,RnfqY1GQOV0Dt4Mo,KYSeNzuJj7gdHkh3O1nMGsQT2R=U3fJTNyc5LdRX7wpEOGi,dOsjwA8uPMD3g,UcN63jgqbCpOSK
p1ACZOuLHGlTV,tGKki4Md81V,wwn2EOKguWIX6Vh=KYSeNzuJj7gdHkh3O1nMGsQT2R,RnfqY1GQOV0Dt4Mo,tnsyF7cGpvfMU6PWExDlTm
KkW57zZaIriq1MXfyLTu3Rjc9tHd,J1JzIfjYZCtP6VDOa,QmF6wRC18znBAUcTX0=wwn2EOKguWIX6Vh,tGKki4Md81V,p1ACZOuLHGlTV
zV9HjXTOaWobt10,oWK2ODnb5GClt8ihMFTSdE1Lzyjuas,GAsCI7iuPzkqKJ=QmF6wRC18znBAUcTX0,J1JzIfjYZCtP6VDOa,KkW57zZaIriq1MXfyLTu3Rjc9tHd
s9eJrTCLjqnKSEGF5,uWvAH4t31idqCx7QT,N1wsWVO9RkJnZHr7oeid=GAsCI7iuPzkqKJ,oWK2ODnb5GClt8ihMFTSdE1Lzyjuas,zV9HjXTOaWobt10
zrpD4JqTkHcF,G7HbXfTm1yIvr0e9xlgOd,jRdTiQ15qtwJp=N1wsWVO9RkJnZHr7oeid,uWvAH4t31idqCx7QT,s9eJrTCLjqnKSEGF5
VQkwE5DcUqoGFWxndghjPpMH18,FFjBQYIzC0RUr6tydMfPNb,oop4LMFBy7m6R=jRdTiQ15qtwJp,G7HbXfTm1yIvr0e9xlgOd,zrpD4JqTkHcF
mykjdWEMa4R,WtwnfblgkB5UoVPzNCp2c9YyZa7TOK,Ncye4k27hPvTMV=oop4LMFBy7m6R,FFjBQYIzC0RUr6tydMfPNb,VQkwE5DcUqoGFWxndghjPpMH18
vKx2h9ZEpNLeTDt5,EEguFL8BIYadlHtrAR3TVb,ulWJXhH7pa2QPDfcT=Ncye4k27hPvTMV,WtwnfblgkB5UoVPzNCp2c9YyZa7TOK,mykjdWEMa4R
Kt8X5cpY71bs2UDmgdq,D7TagiClLMFIu3x9t,Np7g0o5lJk68diFqMY2Ua9nTZBezmG=ulWJXhH7pa2QPDfcT,EEguFL8BIYadlHtrAR3TVb,vKx2h9ZEpNLeTDt5
import xbmc as vRKcmALsHPpGoaxCQ1,xbmcgui as WXNCSbIKA2ylTBZ3LsRJx5n,sys as B7UfAHlPZsdYqiCy61nJV,os as TPm4UrcFLRCt0E,requests as A1jDsmOvr9NKQw6GlHZk0ho25e,re as ooGSBE8Fgp2amqROZuXAdU4jrHf,xbmcvfs as fD3210YKwbrL,base64 as xRbq3tISJABf1jwsHnuvkgYmh7Vy9,time as Cq0MdIADKZG87jYrLRgnXH
wmXvszfa7RIT3Z = s9eJrTCLjqnKSEGF5(u"ࠫࠬࠀ")
def XXz4Ki37yROgCkElNoUVnb(request):
	u1yGIxvHJ3RzhFLOjAc = Ncye4k27hPvTMV(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==tnsyF7cGpvfMU6PWExDlTm(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): vRKcmALsHPpGoaxCQ1.executebuiltin(zrpD4JqTkHcF(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+u1yGIxvHJ3RzhFLOjAc+zV9HjXTOaWobt10(u"ࠨࠫࠪࠄ"))
	elif request==tGKki4Md81V(u"ࠩࡶࡸࡴࡶࠧࠅ"): vRKcmALsHPpGoaxCQ1.executebuiltin(J1JzIfjYZCtP6VDOa(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+u1yGIxvHJ3RzhFLOjAc+QmF6wRC18znBAUcTX0(u"ࠫ࠮࠭ࠇ"))
	return
def LGUQFq2tCSkhcz017jO(RRCqYMhiAyQOSoUwLmsVaD,LcgdUYjpe8NV0n9wxi5,hEoQJL8FjdycAnPp3GsiBDXwZ6It,IQFMgaGbBV9uwYhT5d2pRtv,text):
	if not LcgdUYjpe8NV0n9wxi5: LcgdUYjpe8NV0n9wxi5 = zV9HjXTOaWobt10(u"้ࠬไศࠩࠈ")
	if not hEoQJL8FjdycAnPp3GsiBDXwZ6It: hEoQJL8FjdycAnPp3GsiBDXwZ6It = p1ACZOuLHGlTV(u"࠭ๆฺ็ࠪࠉ")
	if not IQFMgaGbBV9uwYhT5d2pRtv: IQFMgaGbBV9uwYhT5d2pRtv = D7TagiClLMFIu3x9t(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if fdvYRQr2xJOkiyW4quH0KXDPc: rSKwYDzBRZvsOi2Me4fHFy = WXNCSbIKA2ylTBZ3LsRJx5n.Dialog().yesno(IQFMgaGbBV9uwYhT5d2pRtv,text,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,LcgdUYjpe8NV0n9wxi5,hEoQJL8FjdycAnPp3GsiBDXwZ6It)
	else: rSKwYDzBRZvsOi2Me4fHFy = WXNCSbIKA2ylTBZ3LsRJx5n.Dialog().yesno(IQFMgaGbBV9uwYhT5d2pRtv,text,LcgdUYjpe8NV0n9wxi5,hEoQJL8FjdycAnPp3GsiBDXwZ6It)
	return rSKwYDzBRZvsOi2Me4fHFy
def mYa6dibEnO8SXcZR9(RRCqYMhiAyQOSoUwLmsVaD,MhirHAf7Pcnmtobz45puQ8WFGK,IQFMgaGbBV9uwYhT5d2pRtv,text):
	if not IQFMgaGbBV9uwYhT5d2pRtv: IQFMgaGbBV9uwYhT5d2pRtv = vKx2h9ZEpNLeTDt5(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return WXNCSbIKA2ylTBZ3LsRJx5n.Dialog().ok(IQFMgaGbBV9uwYhT5d2pRtv,text)
def mtWYJAFdvgiqGDELj7xKnI2Uy4(IQFMgaGbBV9uwYhT5d2pRtv=Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),bOQdmk2RT3=wmXvszfa7RIT3Z):
	UUSQLFrdG5fbl1HB4uVk6yaIxZCm = WXNCSbIKA2ylTBZ3LsRJx5n.Dialog().input(IQFMgaGbBV9uwYhT5d2pRtv,bOQdmk2RT3,type=WXNCSbIKA2ylTBZ3LsRJx5n.INPUT_ALPHANUM)
	UUSQLFrdG5fbl1HB4uVk6yaIxZCm = UUSQLFrdG5fbl1HB4uVk6yaIxZCm.strip(jRdTiQ15qtwJp(u"ࠪࠤࠬࠍ")).replace(U3fJTNyc5LdRX7wpEOGi(u"ࠫࠥࠦࠠࠡࠩࠎ"),uWvAH4t31idqCx7QT(u"ࠬࠦࠧࠏ")).replace(KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"࠭ࠠࠡࠢࠪࠐ"),tGKki4Md81V(u"ࠧࠡࠩࠑ")).replace(oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࠨࠢࠣࠫࠒ"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࠩࠣࠫࠓ"))
	return UUSQLFrdG5fbl1HB4uVk6yaIxZCm
def zrptQ2B5sUemXVfuL3jTaO4G(zgOHRxqj1nYp):
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,oop4LMFBy7m6R(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if rSKwYDzBRZvsOi2Me4fHFy!=vKx2h9ZEpNLeTDt5(u"࠱ࢫ"): return
	if not TPm4UrcFLRCt0E.path.exists(zgOHRxqj1nYp):
		mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,EEguFL8BIYadlHtrAR3TVb(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = mtWYJAFdvgiqGDELj7xKnI2Uy4(Ncye4k27hPvTMV(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	cmAz9khdpR15Zr = vRKcmALsHPpGoaxCQ1.getInfoLabel(D7TagiClLMFIu3x9t(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+pk1i64j37dLha0+mykjdWEMa4R(u"ࠧࠪࠩ࠘"))
	file = open(zgOHRxqj1nYp,ulWJXhH7pa2QPDfcT(u"ࠨࡴࡥࠫ࠙"))
	S51ja2ftLRmXzDk = TPm4UrcFLRCt0E.path.getsize(zgOHRxqj1nYp)
	if S51ja2ftLRmXzDk>FFjBQYIzC0RUr6tydMfPNb(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-FFjBQYIzC0RUr6tydMfPNb(u"࠴࠲࠴࠴࠵࠶ࢬ"),TPm4UrcFLRCt0E.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(N1wsWVO9RkJnZHr7oeid(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	ya3oEmXYicAn12O0 = ooGSBE8Fgp2amqROZuXAdU4jrHf.findall(zV9HjXTOaWobt10(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,ooGSBE8Fgp2amqROZuXAdU4jrHf.DOTALL)
	if not ya3oEmXYicAn12O0: ya3oEmXYicAn12O0 = ooGSBE8Fgp2amqROZuXAdU4jrHf.findall(QmF6wRC18znBAUcTX0(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,ooGSBE8Fgp2amqROZuXAdU4jrHf.DOTALL)
	if not ya3oEmXYicAn12O0: ya3oEmXYicAn12O0 = ooGSBE8Fgp2amqROZuXAdU4jrHf.findall(oop4LMFBy7m6R(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,ooGSBE8Fgp2amqROZuXAdU4jrHf.DOTALL)
	ya3oEmXYicAn12O0 = ya3oEmXYicAn12O0[Ncye4k27hPvTMV(u"࠲ࢭ")] if ya3oEmXYicAn12O0 else oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"࠭࠰࠱࠲࠳ࠫࠞ")
	ya3oEmXYicAn12O0 = ya3oEmXYicAn12O0.split(UcN63jgqbCpOSK(u"ࠧ࡝ࡰࠪࠟ"),Ncye4k27hPvTMV(u"࠴ࢮ"))[wwn2EOKguWIX6Vh(u"࠴ࢯ")]
	if fdvYRQr2xJOkiyW4quH0KXDPc: ya3oEmXYicAn12O0 = ya3oEmXYicAn12O0.encode(zV9HjXTOaWobt10(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	qqTKyujnc9Jf8eAF5NWt = p1ACZOuLHGlTV(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+ya3oEmXYicAn12O0+Ncye4k27hPvTMV(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += Kt8X5cpY71bs2UDmgdq(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+ya3oEmXYicAn12O0+wwn2EOKguWIX6Vh(u"ࠬࠦ࠺ࠨࠤ")+oop4LMFBy7m6R(u"࠭࡜࡯ࠩࠥ")+uWvAH4t31idqCx7QT(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+cmAz9khdpR15Zr+J1JzIfjYZCtP6VDOa(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(J1JzIfjYZCtP6VDOa(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	RtFosuVSzU6rA = xRbq3tISJABf1jwsHnuvkgYmh7Vy9.b64encode(data)
	LjYw9UOxQGs1pacVKZdouhkWEq = {Kt8X5cpY71bs2UDmgdq(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):qqTKyujnc9Jf8eAF5NWt,KYSeNzuJj7gdHkh3O1nMGsQT2R(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,GAsCI7iuPzkqKJ(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):RtFosuVSzU6rA}
	ggob95Uxn6WK4wCkGZrOYAcLpTis = wwn2EOKguWIX6Vh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	q6qyp9JtYI8ON7sRg1u = A1jDsmOvr9NKQw6GlHZk0ho25e.request(zrpD4JqTkHcF(u"ࠧࡑࡑࡖࡘࠬ࠭"),ggob95Uxn6WK4wCkGZrOYAcLpTis,data=LjYw9UOxQGs1pacVKZdouhkWEq)
	if q6qyp9JtYI8ON7sRg1u.status_code==Ncye4k27hPvTMV(u"࠷࠶࠰ࢰ"): mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,GAsCI7iuPzkqKJ(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,G7HbXfTm1yIvr0e9xlgOd(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def y0MnQ8pulDzG3hrAsoLPNgcXUF():
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if rSKwYDzBRZvsOi2Me4fHFy!=KYSeNzuJj7gdHkh3O1nMGsQT2R(u"࠷ࢱ"): return
	IIyNwVqWSOCsZoMHnD0Q = LhVa0dtO1sJ(tKhTRqAxHmv5nkQ7,D7TagiClLMFIu3x9t(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,Ncye4k27hPvTMV(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,tnsyF7cGpvfMU6PWExDlTm(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def Nog1FDr2qpZI():
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if rSKwYDzBRZvsOi2Me4fHFy!=vKx2h9ZEpNLeTDt5(u"࠱ࢲ"): return
	IIyNwVqWSOCsZoMHnD0Q = vvLwfJtlZaMsGbgIEqzDK8dxhX(C9hk1G5juvJwaA2mq,G7HbXfTm1yIvr0e9xlgOd(u"ࡕࡴࡸࡩࣈ"),G7HbXfTm1yIvr0e9xlgOd(u"ࡕࡴࡸࡩࣈ"),p1ACZOuLHGlTV(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,UcN63jgqbCpOSK(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,RnfqY1GQOV0Dt4Mo(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def LhVa0dtO1sJ(K6cgpEzwGodMjF,dgZUbfJeVhK6X45ap):
	IIyNwVqWSOCsZoMHnD0Q = ulWJXhH7pa2QPDfcT(u"ࡖࡵࡹࡪࣉ")
	if dgZUbfJeVhK6X45ap:
		rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,G7HbXfTm1yIvr0e9xlgOd(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if rSKwYDzBRZvsOi2Me4fHFy!=KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"࠲ࢳ"): return
	if TPm4UrcFLRCt0E.path.exists(K6cgpEzwGodMjF):
		try: TPm4UrcFLRCt0E.remove(K6cgpEzwGodMjF)
		except Exception as JOoyj1URxP5:
			IIyNwVqWSOCsZoMHnD0Q = wwn2EOKguWIX6Vh(u"ࡉࡥࡱࡹࡥ࣊")
			if dgZUbfJeVhK6X45ap: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,str(JOoyj1URxP5))
	if dgZUbfJeVhK6X45ap:
		if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,s9eJrTCLjqnKSEGF5(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,UcN63jgqbCpOSK(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return IIyNwVqWSOCsZoMHnD0Q
def vvLwfJtlZaMsGbgIEqzDK8dxhX(YEDf6shrFNcT5CGUOaVI7,w30wj68oWKUCsZqXRTVz,H4Wwk5A1VPjREXJUQgBmIMq,dgZUbfJeVhK6X45ap):
	IIyNwVqWSOCsZoMHnD0Q = oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࡘࡷࡻࡥ࣋")
	if dgZUbfJeVhK6X45ap:
		rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,YEDf6shrFNcT5CGUOaVI7+wwn2EOKguWIX6Vh(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if rSKwYDzBRZvsOi2Me4fHFy!=J1JzIfjYZCtP6VDOa(u"࠳ࢴ"): return
	if TPm4UrcFLRCt0E.path.exists(YEDf6shrFNcT5CGUOaVI7):
		for Pp0NKV5ykzc3I9,Egs0Xwa6CBYy9QF4hlOPx,m6MAed7DwcByv2Hno4k in TPm4UrcFLRCt0E.walk(YEDf6shrFNcT5CGUOaVI7,topdown=tGKki4Md81V(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for WWO5asHnP4qhk7vMdjmIBgpA in m6MAed7DwcByv2Hno4k:
				Tt2jwSxuHi4mzR = TPm4UrcFLRCt0E.path.join(Pp0NKV5ykzc3I9,WWO5asHnP4qhk7vMdjmIBgpA)
				try: TPm4UrcFLRCt0E.remove(Tt2jwSxuHi4mzR)
				except Exception as JOoyj1URxP5:
					IIyNwVqWSOCsZoMHnD0Q = KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡌࡡ࡭ࡵࡨ࣍")
					if dgZUbfJeVhK6X45ap: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,str(JOoyj1URxP5))
			if w30wj68oWKUCsZqXRTVz:
				for x6xydsKmHw in Egs0Xwa6CBYy9QF4hlOPx:
					KMZG2Iq4CRdt7x56zQ9aJAvy = TPm4UrcFLRCt0E.path.join(Pp0NKV5ykzc3I9,x6xydsKmHw)
					try: TPm4UrcFLRCt0E.rmdir(KMZG2Iq4CRdt7x56zQ9aJAvy)
					except: pass
		if H4Wwk5A1VPjREXJUQgBmIMq:
			try: TPm4UrcFLRCt0E.rmdir(Pp0NKV5ykzc3I9)
			except: pass
	if dgZUbfJeVhK6X45ap:
		if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,Kt8X5cpY71bs2UDmgdq(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,N1wsWVO9RkJnZHr7oeid(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return IIyNwVqWSOCsZoMHnD0Q
def vsYGQT976d5glLeNjDAb():
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,jRdTiQ15qtwJp(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if rSKwYDzBRZvsOi2Me4fHFy!=tnsyF7cGpvfMU6PWExDlTm(u"࠴ࢵ"): return
	IIyNwVqWSOCsZoMHnD0Q = vvLwfJtlZaMsGbgIEqzDK8dxhX(g5czaQFSRe2mifNs9x,QmF6wRC18znBAUcTX0(u"ࡕࡴࡸࡩ࣏"),D7TagiClLMFIu3x9t(u"ࡆࡢ࡮ࡶࡩ࣎"),QmF6wRC18znBAUcTX0(u"ࡕࡴࡸࡩ࣏"))
	if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,U3fJTNyc5LdRX7wpEOGi(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,UcN63jgqbCpOSK(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def uI7w5S0TjnJoQqr8A():
	ggob95Uxn6WK4wCkGZrOYAcLpTis = D7TagiClLMFIu3x9t(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	q6qyp9JtYI8ON7sRg1u = A1jDsmOvr9NKQw6GlHZk0ho25e.request(tGKki4Md81V(u"ࠬࡍࡅࡕࠩࡀ"),ggob95Uxn6WK4wCkGZrOYAcLpTis)
	w6aWXqytNS437nCY = q6qyp9JtYI8ON7sRg1u.content
	w6aWXqytNS437nCY = w6aWXqytNS437nCY.decode(J1JzIfjYZCtP6VDOa(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	m6MAed7DwcByv2Hno4k = ooGSBE8Fgp2amqROZuXAdU4jrHf.findall(J1JzIfjYZCtP6VDOa(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),w6aWXqytNS437nCY,ooGSBE8Fgp2amqROZuXAdU4jrHf.DOTALL)
	m6MAed7DwcByv2Hno4k = sorted(m6MAed7DwcByv2Hno4k,reverse=J1JzIfjYZCtP6VDOa(u"ࡖࡵࡹࡪ࣐"))
	TLHP1CjeQUg7WEGxDB = WXNCSbIKA2ylTBZ3LsRJx5n.Dialog().select(N1wsWVO9RkJnZHr7oeid(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),m6MAed7DwcByv2Hno4k)
	if TLHP1CjeQUg7WEGxDB==-oop4LMFBy7m6R(u"࠵ࢶ"): return
	filename = m6MAed7DwcByv2Hno4k[TLHP1CjeQUg7WEGxDB]
	if fdvYRQr2xJOkiyW4quH0KXDPc: filename = filename.encode(N1wsWVO9RkJnZHr7oeid(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	L0LQjK8wl5CuNJARkS = ggob95Uxn6WK4wCkGZrOYAcLpTis.rsplit(tGKki4Md81V(u"ࠪ࠳ࠬࡅ"),G7HbXfTm1yIvr0e9xlgOd(u"࠶ࢷ"))[RnfqY1GQOV0Dt4Mo(u"࠶ࢸ")]+J1JzIfjYZCtP6VDOa(u"ࠫ࠴࠭ࡆ")+dOsjwA8uPMD3g(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+J1JzIfjYZCtP6VDOa(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	IIyNwVqWSOCsZoMHnD0Q = U3fJTNyc5LdRX7wpEOGi(u"ࡉࡥࡱࡹࡥ࣑")
	q6qyp9JtYI8ON7sRg1u = A1jDsmOvr9NKQw6GlHZk0ho25e.request(Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࠧࡈࡇࡗࠫࡉ"),L0LQjK8wl5CuNJARkS)
	if q6qyp9JtYI8ON7sRg1u.status_code==vKx2h9ZEpNLeTDt5(u"࠲࠱࠲ࢹ"):
		bMuxhSed3o6f5aytcsClri418IA9zV = q6qyp9JtYI8ON7sRg1u.content
		import zipfile as ff21Lm8Fiv,io as AFr2oiaPGu6WH
		lmfiFYtnbyQM = AFr2oiaPGu6WH.BytesIO(bMuxhSed3o6f5aytcsClri418IA9zV)
		vvLwfJtlZaMsGbgIEqzDK8dxhX(bRlWfF2MoQ9m,KYSeNzuJj7gdHkh3O1nMGsQT2R(u"࡙ࡸࡵࡦ࣓"),KYSeNzuJj7gdHkh3O1nMGsQT2R(u"࡙ࡸࡵࡦ࣓"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡊࡦࡲࡳࡦ࣒"))
		am7MdA1hsPYBwe0ZCnV8cq4vKzN = ff21Lm8Fiv.ZipFile(lmfiFYtnbyQM)
		am7MdA1hsPYBwe0ZCnV8cq4vKzN.extractall(lKxps2hB5XnZWLMd4Ymr)
		Cq0MdIADKZG87jYrLRgnXH.sleep(GAsCI7iuPzkqKJ(u"࠲ࢺ"))
		vRKcmALsHPpGoaxCQ1.executebuiltin(Ncye4k27hPvTMV(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		Cq0MdIADKZG87jYrLRgnXH.sleep(s9eJrTCLjqnKSEGF5(u"࠳ࢻ"))
		JQ9mW2hos76CG3vwL = vRKcmALsHPpGoaxCQ1.executeJSONRPC(ulWJXhH7pa2QPDfcT(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+pk1i64j37dLha0+KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if oop4LMFBy7m6R(u"ࠫࡔࡑࠧࡍ") in JQ9mW2hos76CG3vwL: IIyNwVqWSOCsZoMHnD0Q = WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"࡚ࡲࡶࡧࣔ")
	if IIyNwVqWSOCsZoMHnD0Q:
		mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,KYSeNzuJj7gdHkh3O1nMGsQT2R(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = GAsCI7iuPzkqKJ(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		DldHnbxL2GQOa1rk(msg)
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wwn2EOKguWIX6Vh(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def DldHnbxL2GQOa1rk(msg=G7HbXfTm1yIvr0e9xlgOd(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,J1JzIfjYZCtP6VDOa(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),D7TagiClLMFIu3x9t(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),wmXvszfa7RIT3Z,msg)
	if rSKwYDzBRZvsOi2Me4fHFy==-ulWJXhH7pa2QPDfcT(u"࠴ࢼ"): return
	TvB1cnOVioEKmL = GAsCI7iuPzkqKJ(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if rSKwYDzBRZvsOi2Me4fHFy else WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	IIyNwVqWSOCsZoMHnD0Q = oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࡆࡢ࡮ࡶࡩࣕ")
	LxprcVQn1R = D7TagiClLMFIu3x9t(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	usPgCkirVA9SWFmyN1Q2 = tnsyF7cGpvfMU6PWExDlTm(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if fdvYRQr2xJOkiyW4quH0KXDPc else oop4LMFBy7m6R(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as iEjr0b8q2aFJsk1C3MlApRvXcKSVNQ
		t5tWxoZXJQB398qG = iEjr0b8q2aFJsk1C3MlApRvXcKSVNQ.connect(puDvl0mwx2LaMZjfk1BX)
		t5tWxoZXJQB398qG.text_factory = str
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh = t5tWxoZXJQB398qG.cursor()
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(uWvAH4t31idqCx7QT(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+pk1i64j37dLha0+KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࠪࠦࠥࡁ࡚ࠧ"))
		ZEOeukPaBHpfXyC16WrbMUiDJG = c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.fetchall()
		if ZEOeukPaBHpfXyC16WrbMUiDJG and LxprcVQn1R not in str(ZEOeukPaBHpfXyC16WrbMUiDJG): c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(RnfqY1GQOV0Dt4Mo(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+LxprcVQn1R+Ncye4k27hPvTMV(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+pk1i64j37dLha0+tGKki4Md81V(u"࠭ࠢࠡ࠽ࠪ࡝"))
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(zV9HjXTOaWobt10(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+usPgCkirVA9SWFmyN1Q2+tnsyF7cGpvfMU6PWExDlTm(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+pk1i64j37dLha0+vKx2h9ZEpNLeTDt5(u"ࠩࠥࠤࡀ࠭ࡠ"))
		ZEOeukPaBHpfXyC16WrbMUiDJG = c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.fetchall()
		BBolS0U7eguGfpm2 = ulWJXhH7pa2QPDfcT(u"ࡈࡤࡰࡸ࡫ࣗ") if ZEOeukPaBHpfXyC16WrbMUiDJG else Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࡕࡴࡸࡩࣖ")
		if not BBolS0U7eguGfpm2 and dOsjwA8uPMD3g(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in TvB1cnOVioEKmL: c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(N1wsWVO9RkJnZHr7oeid(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+usPgCkirVA9SWFmyN1Q2+EEguFL8BIYadlHtrAR3TVb(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+pk1i64j37dLha0+QmF6wRC18znBAUcTX0(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif BBolS0U7eguGfpm2 and WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in TvB1cnOVioEKmL:
			if fdvYRQr2xJOkiyW4quH0KXDPc: c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(GAsCI7iuPzkqKJ(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+usPgCkirVA9SWFmyN1Q2+dOsjwA8uPMD3g(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+pk1i64j37dLha0+EEguFL8BIYadlHtrAR3TVb(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(Kt8X5cpY71bs2UDmgdq(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+usPgCkirVA9SWFmyN1Q2+EEguFL8BIYadlHtrAR3TVb(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+pk1i64j37dLha0+ulWJXhH7pa2QPDfcT(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		t5tWxoZXJQB398qG.commit()
		t5tWxoZXJQB398qG.close()
		IIyNwVqWSOCsZoMHnD0Q = J1JzIfjYZCtP6VDOa(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if IIyNwVqWSOCsZoMHnD0Q:
		Cq0MdIADKZG87jYrLRgnXH.sleep(WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"࠵ࢽ"))
		vRKcmALsHPpGoaxCQ1.executebuiltin(tnsyF7cGpvfMU6PWExDlTm(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		Cq0MdIADKZG87jYrLRgnXH.sleep(J1JzIfjYZCtP6VDOa(u"࠶ࢾ"))
		mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,G7HbXfTm1yIvr0e9xlgOd(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def mH4Ny8tarXMcxlb91DO6o():
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,oop4LMFBy7m6R(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if rSKwYDzBRZvsOi2Me4fHFy!=D7TagiClLMFIu3x9t(u"࠷ࢿ"): return
	RRPHbZKGperTq2UiJNV8QMntd5Y = vvLwfJtlZaMsGbgIEqzDK8dxhX(pOcIQRho4qPYJW3kFsf0,oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"࡙ࡸࡵࡦࣚ"),RnfqY1GQOV0Dt4Mo(u"ࡊࡦࡲࡳࡦࣙ"),RnfqY1GQOV0Dt4Mo(u"ࡊࡦࡲࡳࡦࣙ"))
	qp3wuvxCKdHN1eEMaS = vvLwfJtlZaMsGbgIEqzDK8dxhX(u1rMVfDQtWPAhLy7q0JxNknz,vKx2h9ZEpNLeTDt5(u"ࡔࡳࡷࡨࣜ"),uWvAH4t31idqCx7QT(u"ࡌࡡ࡭ࡵࡨࣛ"),uWvAH4t31idqCx7QT(u"ࡌࡡ࡭ࡵࡨࣛ"))
	AD2cn5oWQu = vvLwfJtlZaMsGbgIEqzDK8dxhX(QX5oYmecWPAnSvtBK6dOi7qlEpCbk,uWvAH4t31idqCx7QT(u"ࡖࡵࡹࡪࣞ"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡇࡣ࡯ࡷࡪࣝ"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡇࡣ࡯ࡷࡪࣝ"))
	lM3NDHkgIoGvVECd6Q2nOfaJ = DDM9JCQVt70asG3cpgSRb1IXfAYlwy(D7TagiClLMFIu3x9t(u"ࡗࡶࡺ࡫ࣟ"))
	HUJXChAFN2ySWue8YOp316i = P7BvDl9X1p5JY6CUjTfwSEVao()
	IIyNwVqWSOCsZoMHnD0Q = all([RRPHbZKGperTq2UiJNV8QMntd5Y,qp3wuvxCKdHN1eEMaS,AD2cn5oWQu,lM3NDHkgIoGvVECd6Q2nOfaJ,HUJXChAFN2ySWue8YOp316i])
	if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,jRdTiQ15qtwJp(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,U3fJTNyc5LdRX7wpEOGi(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def aoclGkHj9pB3WT7ifRwum8KSU6():
	rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if rSKwYDzBRZvsOi2Me4fHFy!=tnsyF7cGpvfMU6PWExDlTm(u"࠱ࣀ"): return
	EginyhZ8JperKUYRsIwLv = WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	A3BSyFmZRJjgdU = RnfqY1GQOV0Dt4Mo(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	ggtDmz82TYa3cUrq6BHX = N1wsWVO9RkJnZHr7oeid(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	h0h4vofuaDMA2CBGt7d6UJ = zV9HjXTOaWobt10(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	zSyfIklpeg4GmQ = D7TagiClLMFIu3x9t(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	wBsvrMOu3Z7jqX = jRdTiQ15qtwJp(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	RRPHbZKGperTq2UiJNV8QMntd5Y = vvLwfJtlZaMsGbgIEqzDK8dxhX(EginyhZ8JperKUYRsIwLv,WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"࡙ࡸࡵࡦ࣡"),dOsjwA8uPMD3g(u"ࡊࡦࡲࡳࡦ࣠"),dOsjwA8uPMD3g(u"ࡊࡦࡲࡳࡦ࣠"))
	qp3wuvxCKdHN1eEMaS = vvLwfJtlZaMsGbgIEqzDK8dxhX(A3BSyFmZRJjgdU,ulWJXhH7pa2QPDfcT(u"ࡔࡳࡷࡨࣣ"),Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࡌࡡ࡭ࡵࡨ࣢"),Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࡌࡡ࡭ࡵࡨ࣢"))
	AD2cn5oWQu = vvLwfJtlZaMsGbgIEqzDK8dxhX(ggtDmz82TYa3cUrq6BHX,jRdTiQ15qtwJp(u"ࡖࡵࡹࡪࣥ"),Ncye4k27hPvTMV(u"ࡇࡣ࡯ࡷࡪࣤ"),Ncye4k27hPvTMV(u"ࡇࡣ࡯ࡷࡪࣤ"))
	lM3NDHkgIoGvVECd6Q2nOfaJ = vvLwfJtlZaMsGbgIEqzDK8dxhX(h0h4vofuaDMA2CBGt7d6UJ,wwn2EOKguWIX6Vh(u"ࡘࡷࡻࡥࣧ"),tnsyF7cGpvfMU6PWExDlTm(u"ࡉࡥࡱࡹࡥࣦ"),tnsyF7cGpvfMU6PWExDlTm(u"ࡉࡥࡱࡹࡥࣦ"))
	HUJXChAFN2ySWue8YOp316i = vvLwfJtlZaMsGbgIEqzDK8dxhX(zSyfIklpeg4GmQ,mykjdWEMa4R(u"࡚ࡲࡶࡧࣩ"),QmF6wRC18znBAUcTX0(u"ࡋࡧ࡬ࡴࡧࣨ"),QmF6wRC18znBAUcTX0(u"ࡋࡧ࡬ࡴࡧࣨ"))
	odleS7af52E1UCiG = vvLwfJtlZaMsGbgIEqzDK8dxhX(wBsvrMOu3Z7jqX,Ncye4k27hPvTMV(u"ࡕࡴࡸࡩ࣫"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡆࡢ࡮ࡶࡩ࣪"),KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࡆࡢ࡮ࡶࡩ࣪"))
	IIyNwVqWSOCsZoMHnD0Q = all([RRPHbZKGperTq2UiJNV8QMntd5Y,qp3wuvxCKdHN1eEMaS,AD2cn5oWQu,lM3NDHkgIoGvVECd6Q2nOfaJ,HUJXChAFN2ySWue8YOp316i,odleS7af52E1UCiG])
	if IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,vKx2h9ZEpNLeTDt5(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,zV9HjXTOaWobt10(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def DDM9JCQVt70asG3cpgSRb1IXfAYlwy(dgZUbfJeVhK6X45ap):
	IIyNwVqWSOCsZoMHnD0Q = zV9HjXTOaWobt10(u"ࡖࡵࡹࡪ࣬")
	if dgZUbfJeVhK6X45ap:
		rSKwYDzBRZvsOi2Me4fHFy = LGUQFq2tCSkhcz017jO(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,tnsyF7cGpvfMU6PWExDlTm(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if rSKwYDzBRZvsOi2Me4fHFy!=oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"࠲ࣁ"): return
	try:
		import sqlite3 as iEjr0b8q2aFJsk1C3MlApRvXcKSVNQ
		nnHzrcLyTNPv6SupUwB = iEjr0b8q2aFJsk1C3MlApRvXcKSVNQ.connect(QnXZcJ3OmSdNEyBiHo75A)
		nnHzrcLyTNPv6SupUwB.text_factory = str
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh = nnHzrcLyTNPv6SupUwB.cursor()
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(FFjBQYIzC0RUr6tydMfPNb(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(ulWJXhH7pa2QPDfcT(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(UcN63jgqbCpOSK(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		nnHzrcLyTNPv6SupUwB.commit()
		c3ASbKt9RTaJwsm7BVMCkiIDQyZLUh.execute(dOsjwA8uPMD3g(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		nnHzrcLyTNPv6SupUwB.close()
	except: IIyNwVqWSOCsZoMHnD0Q = D7TagiClLMFIu3x9t(u"ࡉࡥࡱࡹࡥ࣭")
	if dgZUbfJeVhK6X45ap and IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,VQkwE5DcUqoGFWxndghjPpMH18(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return IIyNwVqWSOCsZoMHnD0Q
def P7BvDl9X1p5JY6CUjTfwSEVao():
	IIyNwVqWSOCsZoMHnD0Q = vKx2h9ZEpNLeTDt5(u"ࡘࡷࡻࡥ࣮")
	for file in TPm4UrcFLRCt0E.listdir(C7iOP5fqdxJQKlEWUs):
		if EEguFL8BIYadlHtrAR3TVb(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or s9eJrTCLjqnKSEGF5(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		Tt2jwSxuHi4mzR = TPm4UrcFLRCt0E.path.join(C7iOP5fqdxJQKlEWUs,file)
		try:
			TPm4UrcFLRCt0E.remove(Tt2jwSxuHi4mzR)
		except Exception as JOoyj1URxP5:
			IIyNwVqWSOCsZoMHnD0Q = oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࡋࡧ࡬ࡴࡧ࣯")
			if dgZUbfJeVhK6X45ap and IIyNwVqWSOCsZoMHnD0Q: mYa6dibEnO8SXcZR9(wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,wmXvszfa7RIT3Z,str(JOoyj1URxP5))
	return IIyNwVqWSOCsZoMHnD0Q
XXz4Ki37yROgCkElNoUVnb(Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
jXfbMs15Lrl8dVanKNQqCZg = B7UfAHlPZsdYqiCy61nJV.argv[wwn2EOKguWIX6Vh(u"࠳ࣂ")]
pk1i64j37dLha0 = FFjBQYIzC0RUr6tydMfPNb(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
fi4Pyt6UW9AJscY5habZxQjDE = vRKcmALsHPpGoaxCQ1.getInfoLabel(tGKki4Md81V(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
yCnSIBE1ti5 = ooGSBE8Fgp2amqROZuXAdU4jrHf.findall(zrpD4JqTkHcF(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),fi4Pyt6UW9AJscY5habZxQjDE,ooGSBE8Fgp2amqROZuXAdU4jrHf.DOTALL)
yCnSIBE1ti5 = float(yCnSIBE1ti5[U3fJTNyc5LdRX7wpEOGi(u"࠳ࣃ")])
fdvYRQr2xJOkiyW4quH0KXDPc = yCnSIBE1ti5<zrpD4JqTkHcF(u"࠵࠾ࣄ")
JJUosZcWxLFgRuq60Y = yCnSIBE1ti5>U3fJTNyc5LdRX7wpEOGi(u"࠶࠾࠮࠺࠻ࣅ")
if JJUosZcWxLFgRuq60Y:
	C7iOP5fqdxJQKlEWUs = fD3210YKwbrL.translatePath(QmF6wRC18znBAUcTX0(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	jY98eol1GFxd0uWSKV4Ayicr = fD3210YKwbrL.translatePath(oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	D1g5yvIekfrp = fD3210YKwbrL.translatePath(vKx2h9ZEpNLeTDt5(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	puDvl0mwx2LaMZjfk1BX = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,RnfqY1GQOV0Dt4Mo(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),RnfqY1GQOV0Dt4Mo(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),wwn2EOKguWIX6Vh(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	C7iOP5fqdxJQKlEWUs = vRKcmALsHPpGoaxCQ1.translatePath(ulWJXhH7pa2QPDfcT(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	jY98eol1GFxd0uWSKV4Ayicr = vRKcmALsHPpGoaxCQ1.translatePath(tnsyF7cGpvfMU6PWExDlTm(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	D1g5yvIekfrp = vRKcmALsHPpGoaxCQ1.translatePath(WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	puDvl0mwx2LaMZjfk1BX = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,KkW57zZaIriq1MXfyLTu3Rjc9tHd(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),RnfqY1GQOV0Dt4Mo(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),G7HbXfTm1yIvr0e9xlgOd(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
WklV2fDU6OqPpC = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,VQkwE5DcUqoGFWxndghjPpMH18(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),zrpD4JqTkHcF(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),pk1i64j37dLha0)
tKhTRqAxHmv5nkQ7 = TPm4UrcFLRCt0E.path.join(WklV2fDU6OqPpC,RnfqY1GQOV0Dt4Mo(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
C9hk1G5juvJwaA2mq = TPm4UrcFLRCt0E.path.join(D1g5yvIekfrp,pk1i64j37dLha0)
QX5oYmecWPAnSvtBK6dOi7qlEpCbk = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,KYSeNzuJj7gdHkh3O1nMGsQT2R(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),ulWJXhH7pa2QPDfcT(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
lKxps2hB5XnZWLMd4Ymr = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,mykjdWEMa4R(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
bRlWfF2MoQ9m = TPm4UrcFLRCt0E.path.join(lKxps2hB5XnZWLMd4Ymr,pk1i64j37dLha0)
pOcIQRho4qPYJW3kFsf0 = TPm4UrcFLRCt0E.path.join(lKxps2hB5XnZWLMd4Ymr,p1ACZOuLHGlTV(u"ࠪࡸࡪࡳࡰࠨ࢙"))
u1rMVfDQtWPAhLy7q0JxNknz = TPm4UrcFLRCt0E.path.join(lKxps2hB5XnZWLMd4Ymr,tnsyF7cGpvfMU6PWExDlTm(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
QnXZcJ3OmSdNEyBiHo75A = TPm4UrcFLRCt0E.path.join(jY98eol1GFxd0uWSKV4Ayicr,J1JzIfjYZCtP6VDOa(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),UcN63jgqbCpOSK(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),QmF6wRC18znBAUcTX0(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
g5czaQFSRe2mifNs9x = TPm4UrcFLRCt0E.path.join(C9hk1G5juvJwaA2mq,EEguFL8BIYadlHtrAR3TVb(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
QU8TEjidVxPqR3rp1SD6IZFAWv = TPm4UrcFLRCt0E.path.join(C7iOP5fqdxJQKlEWUs,EEguFL8BIYadlHtrAR3TVb(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
SR0ICYysBfTMcUAzpGWi42Emnw = TPm4UrcFLRCt0E.path.join(C7iOP5fqdxJQKlEWUs,WtwnfblgkB5UoVPzNCp2c9YyZa7TOK(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   jXfbMs15Lrl8dVanKNQqCZg==zV9HjXTOaWobt10(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: zrptQ2B5sUemXVfuL3jTaO4G(QU8TEjidVxPqR3rp1SD6IZFAWv)
elif jXfbMs15Lrl8dVanKNQqCZg==KYSeNzuJj7gdHkh3O1nMGsQT2R(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: zrptQ2B5sUemXVfuL3jTaO4G(SR0ICYysBfTMcUAzpGWi42Emnw)
elif jXfbMs15Lrl8dVanKNQqCZg==zrpD4JqTkHcF(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: y0MnQ8pulDzG3hrAsoLPNgcXUF()
elif jXfbMs15Lrl8dVanKNQqCZg==GAsCI7iuPzkqKJ(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: Nog1FDr2qpZI()
elif jXfbMs15Lrl8dVanKNQqCZg==VQkwE5DcUqoGFWxndghjPpMH18(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: mH4Ny8tarXMcxlb91DO6o()
elif jXfbMs15Lrl8dVanKNQqCZg==Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: aoclGkHj9pB3WT7ifRwum8KSU6()
elif jXfbMs15Lrl8dVanKNQqCZg==vKx2h9ZEpNLeTDt5(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: uI7w5S0TjnJoQqr8A()
elif jXfbMs15Lrl8dVanKNQqCZg==oWK2ODnb5GClt8ihMFTSdE1Lzyjuas(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: DldHnbxL2GQOa1rk()
elif jXfbMs15Lrl8dVanKNQqCZg==Kt8X5cpY71bs2UDmgdq(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: vsYGQT976d5glLeNjDAb()
XXz4Ki37yROgCkElNoUVnb(Np7g0o5lJk68diFqMY2Ua9nTZBezmG(u"࠭ࡳࡵࡱࡳࠫࢪ"))