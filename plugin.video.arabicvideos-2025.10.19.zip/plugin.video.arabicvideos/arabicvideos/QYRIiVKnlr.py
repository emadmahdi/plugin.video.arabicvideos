# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
j0jEZgiKdxFpMLHcU7kQr8v1lyX4 = wwWzyF4ZpSQXKOgk569(u"࠵৤")
wnaWTQM7VJPkZzO9eoSyFU4 = pp7FcjEe6g(u"࠷৥")
XURrDCfOS9Mbhpv2Pmjos56TeW = wnaWTQM7VJPkZzO9eoSyFU4+wnaWTQM7VJPkZzO9eoSyFU4
vXIdY7TwFKso40gVBq5 = XURrDCfOS9Mbhpv2Pmjos56TeW+wnaWTQM7VJPkZzO9eoSyFU4
yGLl1nSBrJPmi2adko9O = vXIdY7TwFKso40gVBq5+wnaWTQM7VJPkZzO9eoSyFU4
EEowc8rs5gUZTVjdOzmb0nu = yGLl1nSBrJPmi2adko9O+wnaWTQM7VJPkZzO9eoSyFU4
WnNGfosHr5STAq8j7miwyRZ6eOUbV = ZLr5gRSkFewKdUos90bM(u"ࠩࠪए")
kcXMWrwiLDKeBHRsJ = ZLr5gRSkFewKdUos90bM(u"ࠪࠤࠬऐ")
tTChquY7XSRg4e = kcXMWrwiLDKeBHRsJ*XURrDCfOS9Mbhpv2Pmjos56TeW
jrD65cZUQ8uGR0IHNCkF = kcXMWrwiLDKeBHRsJ*vXIdY7TwFKso40gVBq5
EVdNGw3APQXTfhxaHW1nRpiFkcotg = kcXMWrwiLDKeBHRsJ*yGLl1nSBrJPmi2adko9O
OHohTgj06taKzsG = None
r0D4C3z7Onqpa = eUYX1LQCSJyNZtMsukTBhA4cfj(u"࡙ࡸࡵࡦਇ")
KiryBCvngZzF85UN6xSDlOVweL4I9 = gPE1XB87fQl(u"ࡌࡡ࡭ࡵࡨਈ")
ZZQ6sJcqClADoV9iNa0rK = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡹࡸࡵࡦࠩऑ")
z8WclmVQpLo1Hw2beGYjC4griSd = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
nrfM1GhFckwzAY9Q = VP70ytiFNMBl6vHDaW(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
xsHjBKXaVkMJoRP83 = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
e6HEdvUcaq8Gx = yobpaW7sBqtKRrv(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
RNWqL0gBbKOie1DxjUpzQPh9aZyHX = tzZ6PhyDOUnwLM3pdK(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
ZTQ27jBMEeutsrSXalyb = A6iX18qgyOFlZxz7sc(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
x8xkFP9mq4EHpcfWCoLduhKG150 = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
wpChqrHyRE1 = ZLr5gRSkFewKdUos90bM(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
YVr6St5P4xsFC0aARQGKfiegD = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
e87cIA5vwOQLDEP1 = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡶࡶࡩ࠼ࠬछ")
fFnsCZYWeuh89D = iySORMYxWXszEH18(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
CRLStQiqxb6Y3Eh7G4UVF = YYQS36fyPvtuzcEmRL(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
nsQAcj8eJHEw3xZ = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
W2AGj9rwD0dviCE5Q7BtO = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
U3Us1pqh6TY = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡋࡒࡓࡑࡕࠫठ")
FK6PHeEpSvXsqt83WflBYQ = yobpaW7sBqtKRrv(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
WBDnh75CaLEvkcN6p4ez2KXrV3M = bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࡝ࡰࠪढ")
TTLxlKI0gNfh7FP = A6iX18qgyOFlZxz7sc(u"ࠨ࡞ࡵࠫण")
Ew26Hg4SIj = A41nqbj3wYt(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
QUtMNs40G5YLzv8b3 = A6iX18qgyOFlZxz7sc(u"࠱০")
kWE5274r1n = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠱࠰࠸১")
oJOHPhU8M7DyrYQGbfLVelsvW9X4q = pp7FcjEe6g(u"࠳࠸২")
u0TCgbwroymt = CyHU86ZeYT5BWRcitSm2I(u"࠶࠴৩")
V6YmKcirsSBOvkEX5 = A41nqbj3wYt(u"࠵࠵৪")
JI0HOPTBW23K9VdACvMcjYrX = pp7FcjEe6g(u"࠶࠸࠰৫")
Km2gVSNzXhsfMDYRdupqP0kUr8 = [
						 CyHU86ZeYT5BWRcitSm2I(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,tzZ6PhyDOUnwLM3pdK(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,rVy3Ops0mohYkT(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,Z9FPQvwlbjLTh(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,mq5t9JXSdHT8yfDVF(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,pp7FcjEe6g(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,CyHU86ZeYT5BWRcitSm2I(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,CyHU86ZeYT5BWRcitSm2I(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,iySORMYxWXszEH18(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
r2nhXKbk6Rv5sZCet7diBYOpqFIa8P = Km2gVSNzXhsfMDYRdupqP0kUr8+[
				 yobpaW7sBqtKRrv(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,A41nqbj3wYt(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,IMjqygdfYSKpHlWu5Aa(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,gPE1XB87fQl(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,IMjqygdfYSKpHlWu5Aa(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,iySORMYxWXszEH18(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,pp7FcjEe6g(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,A6iX18qgyOFlZxz7sc(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,gPE1XB87fQl(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,iySORMYxWXszEH18(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,VP70ytiFNMBl6vHDaW(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
KTbHtcdjkuC0ve5DUnzLS2OXFmyxV9 = [
						 SI7eBdND4lx8pt5Qk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,GHg28TBchiyn6l(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
ekgSRBGHWzUI5MqNDQV190ay8LonOp = EEowc8rs5gUZTVjdOzmb0nu
ww07SKUt2HgnRG = [GHg28TBchiyn6l(u"ุࠩๅึ࠭े"),IMjqygdfYSKpHlWu5Aa(u"ࠪวํ๊ࠧै"),rVy3Ops0mohYkT(u"ࠫะอๆ๋ࠩॉ"),kdRO82AImh0LFw(u"ࠬัวๅอࠪॊ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ัศส฼ࠫो"),iySORMYxWXszEH18(u"ࠧฯษ่ืࠬौ"),A41nqbj3wYt(u"ࠨีสำ्ุ࠭"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩึหอ฿ࠧॎ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪฯฬ๋ๆࠨॏ"),CyHU86ZeYT5BWRcitSm2I(u"ࠫฯอำฺࠩॐ"),iySORMYxWXszEH18(u"ࠬ฿วีำࠪ॑")]
OFvxlPW79z0Kifa = VP70ytiFNMBl6vHDaW(u"࠼࠰৬")
Ax4cp5PzJ0IuBknC = SI7eBdND4lx8pt5Qk(u"࠶࠱৭")*OFvxlPW79z0Kifa
d9sTRDNU6v5XWhtknQSmAz8joZCK = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠳࠶৮")*Ax4cp5PzJ0IuBknC
VGRotQYPM4J = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠵࠳৯")*d9sTRDNU6v5XWhtknQSmAz8joZCK
XAGWNdKH4qOPU1YEVQp6 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
A8MWZixP2YtOJ1no53mw = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠶࠴ৰ")*OFvxlPW79z0Kifa
OQaHUGCW62hp8tFbgM = XURrDCfOS9Mbhpv2Pmjos56TeW*Ax4cp5PzJ0IuBknC
nsFAzS2wvjyTYLOdDhfIiC0KGHE = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠵࠻ৱ")*Ax4cp5PzJ0IuBknC
oldym5kX8IqLSVDtpNMw = vXIdY7TwFKso40gVBq5*d9sTRDNU6v5XWhtknQSmAz8joZCK
T0le9tWJd7IAfKH1rNGB = CyHU86ZeYT5BWRcitSm2I(u"࠸࠶৲")*d9sTRDNU6v5XWhtknQSmAz8joZCK
iXBqSkDU3mRCZf4Ib = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠷࠲৳")*VGRotQYPM4J
OsSFncJAtVW3CqLbx74RiZjPY2yU = Ax4cp5PzJ0IuBknC
zJLPCHtq3eK5NRQaiMWj4VuybvcF = [pp7FcjEe6g(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),gPE1XB87fQl(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),rVy3Ops0mohYkT(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),A6iX18qgyOFlZxz7sc(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),pp7FcjEe6g(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
zJLPCHtq3eK5NRQaiMWj4VuybvcF += [tzZ6PhyDOUnwLM3pdK(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),IMjqygdfYSKpHlWu5Aa(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),GHg28TBchiyn6l(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),Z9FPQvwlbjLTh(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
UUFsgqIcYiuza3Hf = [beV5l2D8HznyJI0(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),GHg28TBchiyn6l(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),iySORMYxWXszEH18(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
UUFsgqIcYiuza3Hf += [CyHU86ZeYT5BWRcitSm2I(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),mq5t9JXSdHT8yfDVF(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
VVz5D7uqd93JjS1PcUksQv = [wwWzyF4ZpSQXKOgk569(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),A41nqbj3wYt(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),Z9FPQvwlbjLTh(u"ࠫࡋࡕࡓࡕࡃࠪ६"),bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࡙࠭ࡂࡓࡒࡘࠬ८"),yobpaW7sBqtKRrv(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),CyHU86ZeYT5BWRcitSm2I(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
VVz5D7uqd93JjS1PcUksQv += [kdRO82AImh0LFw(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),A41nqbj3wYt(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),gPE1XB87fQl(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),pp7FcjEe6g(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),VP70ytiFNMBl6vHDaW(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
VVz5D7uqd93JjS1PcUksQv += [CyHU86ZeYT5BWRcitSm2I(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),ZLr5gRSkFewKdUos90bM(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),yobpaW7sBqtKRrv(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),rVy3Ops0mohYkT(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),ZLr5gRSkFewKdUos90bM(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
VVz5D7uqd93JjS1PcUksQv += [mq5t9JXSdHT8yfDVF(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),IMjqygdfYSKpHlWu5Aa(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),mq5t9JXSdHT8yfDVF(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),ZLr5gRSkFewKdUos90bM(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),rVy3Ops0mohYkT(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),CyHU86ZeYT5BWRcitSm2I(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
VVz5D7uqd93JjS1PcUksQv += [VP70ytiFNMBl6vHDaW(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),wwWzyF4ZpSQXKOgk569(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),beV5l2D8HznyJI0(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),SI7eBdND4lx8pt5Qk(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),gPE1XB87fQl(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
kdmDMIFZvcgi6lOWjQ2 = [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),CyHU86ZeYT5BWRcitSm2I(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
kdmDMIFZvcgi6lOWjQ2 += [kdRO82AImh0LFw(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),gPE1XB87fQl(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),KLX7hW0nBAEgy6m4SvH(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),gPE1XB87fQl(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),A6iX18qgyOFlZxz7sc(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),yobpaW7sBqtKRrv(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
bcuvN3jdY2gWDy09HAnf = [tzZ6PhyDOUnwLM3pdK(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+zJLPCHtq3eK5NRQaiMWj4VuybvcF+[kdRO82AImh0LFw(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+UUFsgqIcYiuza3Hf+[CyHU86ZeYT5BWRcitSm2I(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+VVz5D7uqd93JjS1PcUksQv+[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+kdmDMIFZvcgi6lOWjQ2
LTRxXz06kyoU = [yobpaW7sBqtKRrv(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
w2o1rA5ERctCBSflQHJYXdgL = [eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),SI7eBdND4lx8pt5Qk(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
GzulHvyFsQragB7WtPDwUVON8Ei3Z = [pp7FcjEe6g(u"ࠩࡐ࠷࡚࠭ঢ"),SI7eBdND4lx8pt5Qk(u"ࠪࡍࡕ࡚ࡖࠨণ"),yobpaW7sBqtKRrv(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),KLX7hW0nBAEgy6m4SvH(u"ࠬࡏࡆࡊࡎࡐࠫথ"),oiWNFYzcIUeh(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
VV83sDFqZdClGXrOvhKif2WuNmEnSR  = [beV5l2D8HznyJI0(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),yobpaW7sBqtKRrv(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),rVy3Ops0mohYkT(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
VV83sDFqZdClGXrOvhKif2WuNmEnSR += [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),GHg28TBchiyn6l(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
VV83sDFqZdClGXrOvhKif2WuNmEnSR += [jhDZ0BAFoEGUcw5QrJkaxXL(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),tzZ6PhyDOUnwLM3pdK(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
VV83sDFqZdClGXrOvhKif2WuNmEnSR += [KLX7hW0nBAEgy6m4SvH(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),tzZ6PhyDOUnwLM3pdK(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),YYQS36fyPvtuzcEmRL(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
VV83sDFqZdClGXrOvhKif2WuNmEnSR += [rVy3Ops0mohYkT(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),VP70ytiFNMBl6vHDaW(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),kdRO82AImh0LFw(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
q01bkuSIW5FJa6mYv82tnBEiMf9RGp = list(filter(lambda OU8cbKwe1gXj5hsoW0LJYrAQf2: OU8cbKwe1gXj5hsoW0LJYrAQf2 not in VV83sDFqZdClGXrOvhKif2WuNmEnSR+LTRxXz06kyoU+w2o1rA5ERctCBSflQHJYXdgL+GzulHvyFsQragB7WtPDwUVON8Ei3Z,bcuvN3jdY2gWDy09HAnf))
JphriA3aDH61YFCbXsBvTmdx = q01bkuSIW5FJa6mYv82tnBEiMf9RGp+GzulHvyFsQragB7WtPDwUVON8Ei3Z
FFonu8kDwYm2vHdAgfjS7zyMb5q = q01bkuSIW5FJa6mYv82tnBEiMf9RGp+VV83sDFqZdClGXrOvhKif2WuNmEnSR
m06yjkDU4wEipZ7QWrsLdfKbn = FFonu8kDwYm2vHdAgfjS7zyMb5q+LTRxXz06kyoU
zeqfF87Dt1U0VcNvslxnX4CTIkh9Mr = JphriA3aDH61YFCbXsBvTmdx+LTRxXz06kyoU
oonlxDf39ark = [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡄࡏࡔࡇࡍࠨষ"),A6iX18qgyOFlZxz7sc(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),KLX7hW0nBAEgy6m4SvH(u"ࠫࡎࡌࡉࡍࡏࠪহ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),mq5t9JXSdHT8yfDVF(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),A6iX18qgyOFlZxz7sc(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),mq5t9JXSdHT8yfDVF(u"ࠫࡒ࠹ࡕࠨী"),Z9FPQvwlbjLTh(u"ࠬࡏࡐࡕࡘࠪু"),bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡂࡐࡍࡕࡅࠬূ"),Z9FPQvwlbjLTh(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),SI7eBdND4lx8pt5Qk(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [IMjqygdfYSKpHlWu5Aa(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),YYQS36fyPvtuzcEmRL(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡤࡏࡆࡍࡡࠪে"),Z9FPQvwlbjLTh(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),GHg28TBchiyn6l(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),IMjqygdfYSKpHlWu5Aa(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),YYQS36fyPvtuzcEmRL(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),wwWzyF4ZpSQXKOgk569(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),pp7FcjEe6g(u"ࠫࡤࡓࡕࠨৎ"),beV5l2D8HznyJI0(u"ࠬࡥࡉࡑࠩ৏"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),Z9FPQvwlbjLTh(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),YYQS36fyPvtuzcEmRL(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
ffYFH1jX8B24iv6RGrQc = [Z9FPQvwlbjLTh(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),Z9FPQvwlbjLTh(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),pp7FcjEe6g(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),GHg28TBchiyn6l(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),gPE1XB87fQl(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),A6iX18qgyOFlZxz7sc(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),SI7eBdND4lx8pt5Qk(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
KfE5mTdHZRaLnU = [j0jEZgiKdxFpMLHcU7kQr8v1lyX4,pp7FcjEe6g(u"࠱࠶࠲৴"),pp7FcjEe6g(u"࠲࠸࠳ਃ"),IMjqygdfYSKpHlWu5Aa(u"࠵࠼࠶ਆ"),iySORMYxWXszEH18(u"࠱࠺࠲৻"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠵࠺࠵৾"),yobpaW7sBqtKRrv(u"࠲࠹࠲ਂ"),iySORMYxWXszEH18(u"࠴࠵࠳ৼ"),oiWNFYzcIUeh(u"࠷࠹࠶৿"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠵࠳࠳৵"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠸࠴࠵ਅ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠻࠲࠱৺"),VP70ytiFNMBl6vHDaW(u"࠻࠳࠱ਁ"),A41nqbj3wYt(u"࠷࠷࠴৽"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠹࠹࠴਄"),bawK2j7T81Nrc4GWs05xzDg(u"࠶࠶࠱࠱৹"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠽࠾࠿࠰৸"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠳࠳࠶࠵৶"),yobpaW7sBqtKRrv(u"࠴࠴࠽࠶৷"),iySORMYxWXszEH18(u"࠶࠷࠰࠱਀")]
hrKYDu7fpc9V618FMnviALZtP = [IMjqygdfYSKpHlWu5Aa(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),iySORMYxWXszEH18(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),rVy3Ops0mohYkT(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),yobpaW7sBqtKRrv(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),iySORMYxWXszEH18(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),pp7FcjEe6g(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),IMjqygdfYSKpHlWu5Aa(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ")]