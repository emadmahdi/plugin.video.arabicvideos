# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SHIAVOICE'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SHV_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
headers = {'User-Agent':None}
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==310: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==311: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==312: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==313: APpdhB1Fk58MmJH7CjVntowyaY = kYMn56ebTh7rIVysBzvUtS8JdPG(url)
	elif mode==314: APpdhB1Fk58MmJH7CjVntowyaY = B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT(text)
	elif mode==319: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,319,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="menulinks"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	items = p7dwlH1PRStBgyMUW.findall('<h5>(.*?)</h5>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	for L3LoVh5B7OZMbHJlPXQ6EjnaUks in range(len(items)):
		title = items[L3LoVh5B7OZMbHJlPXQ6EjnaUks].strip(kcXMWrwiLDKeBHRsJ)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,pcE6DxaoHBm41WKXjwnk,314,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(L3LoVh5B7OZMbHJlPXQ6EjnaUks+1))
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مقاطع شهر',pcE6DxaoHBm41WKXjwnk,314,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'0')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<B>(.*?)</B>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,311)
	return piN9Qlah4S
def B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT(L3LoVh5B7OZMbHJlPXQ6EjnaUks):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-LATEST-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if L3LoVh5B7OZMbHJlPXQ6EjnaUks=='0':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="tab-content"(.*?)</table>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			name = name.strip(kcXMWrwiLDKeBHRsJ)
			title = title+' ('+name+')'
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312)
	elif L3LoVh5B7OZMbHJlPXQ6EjnaUks in ['1','2','3']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(<h5>.*?)<div class="col-lg',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		Y5orRb7su6UmA = int(L3LoVh5B7OZMbHJlPXQ6EjnaUks)-1
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[Y5orRb7su6UmA]
		if L3LoVh5B7OZMbHJlPXQ6EjnaUks=='1': items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		else: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title,name in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			name = name.strip(kcXMWrwiLDKeBHRsJ)
			title = title+' ('+name+')'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,311,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif L3LoVh5B7OZMbHJlPXQ6EjnaUks in ['4','5','6']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(<h5>.*?)</table>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = int(L3LoVh5B7OZMbHJlPXQ6EjnaUks)-4
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
		items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,h1Pf2qE7ap,title,Zf06rvhWgN3OPj2YTdeqU in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			h1Pf2qE7ap = h1Pf2qE7ap.strip(kcXMWrwiLDKeBHRsJ)
			Zf06rvhWgN3OPj2YTdeqU = Zf06rvhWgN3OPj2YTdeqU.strip(kcXMWrwiLDKeBHRsJ)
			if h1Pf2qE7ap: name = h1Pf2qE7ap
			else: name = Zf06rvhWgN3OPj2YTdeqU
			title = title+' ('+name+')'
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def ctDj2OVRyaUPXCrITmJG(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('ibox-heading"(.*?)class="float-right',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if 'catsum-mobile' in KDCdHQmgxPE21tYz4VUowSv:
		items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title,count in items:
				J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
				SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
				count = count.replace(' الصوتية: ',':')
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				title = title+' ('+count+')'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,311,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		items = p7dwlH1PRStBgyMUW.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,indGDceg0rJ2P6yY1E,gJVpmQ1oYbrkHaKnS4N3v2z in items:
			if title==WnNGfosHr5STAq8j7miwyRZ6eOUbV or indGDceg0rJ2P6yY1E==WnNGfosHr5STAq8j7miwyRZ6eOUbV: continue
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = title+' ('+gJVpmQ1oYbrkHaKnS4N3v2z+')'
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312)
	if not items: d4TS7lOXiRVe0s3tg5JwIoz2Mh(piN9Qlah4S)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(piN9Qlah4S):
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="ibox-content"(.*?)class="pagination',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title,name,count,gJVpmQ1oYbrkHaKnS4N3v2z in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		name = name.strip(kcXMWrwiLDKeBHRsJ)
		title = title+' ('+name+')'
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gJVpmQ1oYbrkHaKnS4N3v2z)
	return
def kYMn56ebTh7rIVysBzvUtS8JdPG(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-SEARCH_ITEMS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="ibox-content p-1"(.*?)class="ibox-content"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY:
		ctDj2OVRyaUPXCrITmJG(url)
		return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<strong>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if '/play-' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,311)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('<audio.*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('<video.*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k[0]
	YsRk6pAS7rdcn(SOw5EUxC9k,NTWE764hmOgUtScp2e8r,'video')
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	XyEwBPYDa9N = ['&t=a','&t=c','&t=s']
	if showDialogs:
		ggKi1tTlqnuUIYbFacyRHo = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('موقع صوت الشيعة - أختر البحث', ggKi1tTlqnuUIYbFacyRHo)
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1: return
	elif '_SHIAVOICE-PERSONS_' in xCONTFizaKbJS1: XFaM94cPUCOWQZNIEe8gdJpny1 = 0
	elif '_SHIAVOICE-ALBUMS_' in xCONTFizaKbJS1: XFaM94cPUCOWQZNIEe8gdJpny1 = 1
	elif '_SHIAVOICE-AUDIOS_' in xCONTFizaKbJS1: XFaM94cPUCOWQZNIEe8gdJpny1 = 2
	else: return
	type = XyEwBPYDa9N[XFaM94cPUCOWQZNIEe8gdJpny1]
	url = pcE6DxaoHBm41WKXjwnk+'/search.php?q='+search+type
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHIAVOICE-SEARCH-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="ibox-content"(.*?)class="ibox-content"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		if XFaM94cPUCOWQZNIEe8gdJpny1 in [0,1]:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title,name in items:
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				name = name.strip(kcXMWrwiLDKeBHRsJ)
				title = title+' ('+name+')'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,313,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif XFaM94cPUCOWQZNIEe8gdJpny1==2:
			items = p7dwlH1PRStBgyMUW.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title,name in items:
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				name = name.strip(kcXMWrwiLDKeBHRsJ)
				title = title+' ('+name+')'
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,312)
	return