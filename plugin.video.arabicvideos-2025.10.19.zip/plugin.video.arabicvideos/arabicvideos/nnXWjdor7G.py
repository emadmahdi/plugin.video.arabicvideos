# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'CIMAABDO'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_ABD_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الرئيسية','افلام للكبار فقط +18']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==550: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==551: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==552: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==553: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==559: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk+'/home',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(pcE6DxaoHBm41WKXjwnk,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,559,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'اخترنا لك',VVDAncSMUjeu8Ii+'/home',551,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('main-content(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-name="(.*?)".*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SUm0TCBiv7ck8sDMhOp,title in items:
		SOw5EUxC9k = VVDAncSMUjeu8Ii+'/ajax/getItem?item='+SUm0TCBiv7ck8sDMhOp+'&Ajax=1'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,551)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"nav-main"(.*?)</nav>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if SOw5EUxC9k=='#': continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,551)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	for SOw5EUxC9k,title in items:
		if SOw5EUxC9k=='#': continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,551)
	return
def ctDj2OVRyaUPXCrITmJG(url,SUm0TCBiv7ck8sDMhOp=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-TITLES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = [piN9Qlah4S]
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-TITLES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if SUm0TCBiv7ck8sDMhOp=='featured':
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"container"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		elif '"section-post mb-10"' in piN9Qlah4S:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"section-post mb-10"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		else:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<article(.*?)"pagination"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items:
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not items: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,552,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,553,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movies/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,551,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,553,J4tO21KYAVdSr67W5NmiD0XhRP)
	if SUm0TCBiv7ck8sDMhOp==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)<footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=="": continue
				if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'هناك المزيد',url,551)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"getSeasonsBySeries(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"list-episodes"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv and '/series/' not in url:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,553,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif ZAIyluJa1EWhdB7OHV5CRGSrk:
		J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"image" src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0]
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,552,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url.replace('/movies/','/watch_movies/')
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = QQTfhlZEDnu4wVcOeHGNyCBo5t2.replace('/episodes/','/watch_episodes/')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(QQTfhlZEDnu4wVcOeHGNyCBo5t2,'url')
	wxT9bCdumN = []
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('''<iframe.*?src=["'](.*?)["']''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[0]
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'url')
		wxT9bCdumN.append(SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__embed')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"servers"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		YQU9rmMqC0LWkcxaFpZos7VdRg = p7dwlH1PRStBgyMUW.findall('postID = "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		YQU9rmMqC0LWkcxaFpZos7VdRg = YQU9rmMqC0LWkcxaFpZos7VdRg[0]
		items = p7dwlH1PRStBgyMUW.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for VVpQfHc7IZamxweON3WXKU6Fg,title in items:
				title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/ajax/getPlayer?server='+VVpQfHc7IZamxweON3WXKU6Fg+'&postID='+YQU9rmMqC0LWkcxaFpZos7VdRg+'&Ajax=1'
				SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
				wxT9bCdumN.append(SOw5EUxC9k)
		else:
			items = p7dwlH1PRStBgyMUW.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if items:
				VVpQfHc7IZamxweON3WXKU6Fg,svrKgGlMD5bhouxj3,title = items[0]
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/ajax/getPlayerByName?server='+VVpQfHc7IZamxweON3WXKU6Fg+'&multipleServers='+svrKgGlMD5bhouxj3+'&postID='+YQU9rmMqC0LWkcxaFpZos7VdRg+'&Ajax=1'
				vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(SOw5EUxC9k)
				W67hPCcaOek094 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-PLAY-2nd')
				piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
				tKf5NLDXilz9MFGa3YJmUWwsu = p7dwlH1PRStBgyMUW.findall('''<iframe src=["'](.*?)["']''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
				ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = tKf5NLDXilz9MFGa3YJmUWwsu[0] if tKf5NLDXilz9MFGa3YJmUWwsu else WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if '/iframe/' in ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr:
					WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-PLAY-3rd')
					piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
					wY5R4sBW6xK8mqhCVEfrF = p7dwlH1PRStBgyMUW.findall('version&quot;:&quot;(.*?)&',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
					wY5R4sBW6xK8mqhCVEfrF = wY5R4sBW6xK8mqhCVEfrF[0]
					W67hPCcaOek094 = {}
					W67hPCcaOek094['X-Inertia-Partial-Component'] = 'files/mirror/video'
					W67hPCcaOek094['X-Inertia'] = 'true'
					W67hPCcaOek094['X-Inertia-Partial-Data'] = 'streams'
					W67hPCcaOek094['X-Inertia-Version'] = wY5R4sBW6xK8mqhCVEfrF
					WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAABDO-PLAY-4th')
					piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
					D6Q7eslKINSAuW0 = IXZpzK7ShaRsAN('dict',piN9Qlah4S)
					groups = D6Q7eslKINSAuW0['props']['streams']['data']
					for group in groups:
						DIBw28Qfje76bTMzVNYhxrgWmO = group['label'].replace(' (source)',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						z6idxHbBFkVAUR4CfY0w = group['mirrors']
						for YBsmCXWJGMSf0 in z6idxHbBFkVAUR4CfY0w:
							VVpQfHc7IZamxweON3WXKU6Fg = YBsmCXWJGMSf0['driver']
							SOw5EUxC9k = 'http:'+YBsmCXWJGMSf0['link']+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__watch____'+DIBw28Qfje76bTMzVNYhxrgWmO
							wxT9bCdumN.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"downs"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name in items:
			SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__download'
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
			wxT9bCdumN.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'-')
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'.html'
	ctDj2OVRyaUPXCrITmJG(url)
	return