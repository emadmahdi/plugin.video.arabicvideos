# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = beV5l2D8HznyJI0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫἑ")
BBabkpX9Y5wPSdQ2cz3ODelWCxGr = []
headers = {Z9FPQvwlbjLTh(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ἒ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
def BQtqoisPwCI0rcFnLjuTYkNH(url,zgNqFEmh9axkto7HK2ZpMXnbOdl4,MqXTicjeEC09zbKvdLxoWpm7aD):
	url = url.replace(YYQS36fyPvtuzcEmRL(u"ࠪ࠳ࡲ࡯ࡲࡳࡱࡵ࠳ࠬἓ"),SI7eBdND4lx8pt5Qk(u"ࠫ࠴࡯ࡦࡳࡣࡰࡩ࠴࠭ἔ")).replace(wwWzyF4ZpSQXKOgk569(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩἕ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࠯ࡪࡨࡵࡥࡲ࡫࠯ࠨ἖"))
	url = url.replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧ࠰ࡹ࠱ࡱࡪ࡭ࡡ࡮ࡣࡻ࠲ࡲ࡫࠯ࠨ἗"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠱ࡰࡩ࡬ࡧ࡭ࡢࡺ࠱ࡱࡪ࠵ࠧἘ"))
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,CyHU86ZeYT5BWRcitSm2I(u"ࠩࡊࡉ࡙࠭Ἑ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,rVy3Ops0mohYkT(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎࡇࡊࡅࡒࡇࡘ࠮࠳ࡶࡸࠬἚ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	wY5R4sBW6xK8mqhCVEfrF = p7dwlH1PRStBgyMUW.findall(kdRO82AImh0LFw(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠫࡷࡵࡰࡶ࠾࠾ࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻ࠨἛ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	headers = {gPE1XB87fQl(u"ࠬ࡞࠭ࡊࡰࡨࡶࡹ࡯ࡡࠨἜ"):I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡴࡳࡷࡨࠫἝ"),rVy3Ops0mohYkT(u"࡙ࠧ࠯ࡌࡲࡪࡸࡴࡪࡣ࠰ࡔࡦࡸࡴࡪࡣ࡯࠱ࡉࡧࡴࡢࠩ἞"):YYQS36fyPvtuzcEmRL(u"ࠨࡵࡷࡶࡪࡧ࡭ࡴࠩ἟"),GHg28TBchiyn6l(u"࡛ࠩ࠱ࡎࡴࡥࡳࡶ࡬ࡥ࠲ࡖࡡࡳࡶ࡬ࡥࡱ࠳ࡃࡰ࡯ࡳࡳࡳ࡫࡮ࡵࠩἠ"):Z9FPQvwlbjLTh(u"ࠪࡪ࡮ࡲࡥࡴ࠱ࡰ࡭ࡷࡸ࡯ࡳ࠱ࡹ࡭ࡩ࡫࡯ࠨἡ")}
	headers[gPE1XB87fQl(u"ࠫ࡝࠳ࡉ࡯ࡧࡵࡸ࡮ࡧ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨἢ")] = wY5R4sBW6xK8mqhCVEfrF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡍࡅࡕࠩἣ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑࡊࡍࡁࡎࡃ࡛࠱࠷ࡴࡤࠨἤ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	J04SdXFQLncCoazt8YfW = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(piN9Qlah4S)
	HFl2IcRSfr3zwu97mNdZTM60DyiAb = J04SdXFQLncCoazt8YfW[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡱࡴࡲࡴࡸ࠭ἥ")][tzZ6PhyDOUnwLM3pdK(u"ࠨࡵࡷࡶࡪࡧ࡭ࡴࠩἦ")][SI7eBdND4lx8pt5Qk(u"ࠩࡧࡥࡹࡧࠧἧ")]
	wxT9bCdumN = []
	for VV60kArCYGvUWNOLymTJze in range(len(HFl2IcRSfr3zwu97mNdZTM60DyiAb)):
		DIBw28Qfje76bTMzVNYhxrgWmO = HFl2IcRSfr3zwu97mNdZTM60DyiAb[VV60kArCYGvUWNOLymTJze][pp7FcjEe6g(u"ࠪࡰࡦࡨࡥ࡭ࠩἨ")]
		laAHpo1bzyM0q = HFl2IcRSfr3zwu97mNdZTM60DyiAb[VV60kArCYGvUWNOLymTJze][mq5t9JXSdHT8yfDVF(u"ࠫࡲ࡯ࡲࡳࡱࡵࡷࠬἩ")]
		for QhpsjbEyOTrMFY4Lw2RWUnJI58Z6X in range(len(laAHpo1bzyM0q)):
			title = laAHpo1bzyM0q[QhpsjbEyOTrMFY4Lw2RWUnJI58Z6X][IMjqygdfYSKpHlWu5Aa(u"ࠬࡪࡲࡪࡸࡨࡶࠬἪ")]
			SOw5EUxC9k = GHg28TBchiyn6l(u"࠭ࡨࡵࡶࡳࡷ࠿࠭Ἣ")+laAHpo1bzyM0q[QhpsjbEyOTrMFY4Lw2RWUnJI58Z6X][A41nqbj3wYt(u"ࠧ࡭࡫ࡱ࡯ࠬἬ")]+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩἭ")+title+beV5l2D8HznyJI0(u"ࠩࡢࡣࠬἮ")+zgNqFEmh9axkto7HK2ZpMXnbOdl4+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡣࡤ࠭Ἧ")+DIBw28Qfje76bTMzVNYhxrgWmO
			wxT9bCdumN.append(SOw5EUxC9k)
	return wxT9bCdumN
def RRcaqDwHJOvGYAeL7n38(url,zgNqFEmh9axkto7HK2ZpMXnbOdl4,MqXTicjeEC09zbKvdLxoWpm7aD):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,kdRO82AImh0LFw(u"ࠫࡌࡋࡔࠨἰ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗ࠳࠱ࡴࡶࠪἱ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if rJ2oTLqabRtA and isinstance(piN9Qlah4S,bytes): piN9Qlah4S = piN9Qlah4S.decode(e87cIA5vwOQLDEP1,pp7FcjEe6g(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ἲ"))
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠧࠣࡣࡳࡰࡷ࠳࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨἳ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡦࡶ࡬ࡳ࠯࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬἴ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		wxT9bCdumN = []
		for SOw5EUxC9k,title in items:
			wxT9bCdumN.append(SOw5EUxC9k+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪἵ")+title+pp7FcjEe6g(u"ࠪࡣࡤ࠭ἶ")+zgNqFEmh9axkto7HK2ZpMXnbOdl4)
	return wxT9bCdumN
def EOxNP3gXGeWhscM2CY45rBSZjR0FH(url,zgNqFEmh9axkto7HK2ZpMXnbOdl4,MqXTicjeEC09zbKvdLxoWpm7aD):
	RN5dE6GKqgJaVzmobikh0fLpBDYr7n = url.split(iySORMYxWXszEH18(u"ࠫ࠴࠭ἷ"))[beV5l2D8HznyJI0(u"࠸ໝ")]
	QkgzytZRFhp0HsTAeo72xSKC9GwV1 = uvGCPpFwVmTQ36.b64decode(RN5dE6GKqgJaVzmobikh0fLpBDYr7n)
	if rJ2oTLqabRtA: QkgzytZRFhp0HsTAeo72xSKC9GwV1 = QkgzytZRFhp0HsTAeo72xSKC9GwV1.decode(e87cIA5vwOQLDEP1)
	tJUgVF0c3bOw8j69KHezE = EZk136aeLoNqPvlDcTQpyM9Wm(QkgzytZRFhp0HsTAeo72xSKC9GwV1)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ἰ")+MqXTicjeEC09zbKvdLxoWpm7aD
	return [tJUgVF0c3bOw8j69KHezE]
def gvyUqSYlGMJQPXKHWDsx40(hYnL7WHKFs8uryNqk193wXjC4AM,source):
	kKibU78Vp1CHjft3I,kx5n2MH0TyoXKEesv3QVSa = [],[]
	for KEIxy6oPrvg5abj3 in hYnL7WHKFs8uryNqk193wXjC4AM:
		O7OfPtkgBD42QoeqIUHKJMm9R53bjN = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"࠭࡮ࡢ࡯ࡨࡨࡂ࠴ࠪࡀࡡࡢࠬ࠳࠰࠿ࠪࡡࡢࠫἹ"),KEIxy6oPrvg5abj3+A41nqbj3wYt(u"ࠧࡠࡡࠪἺ"),p7dwlH1PRStBgyMUW.DOTALL)
		kwzjvcuIgAONrYH = O7OfPtkgBD42QoeqIUHKJMm9R53bjN[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if O7OfPtkgBD42QoeqIUHKJMm9R53bjN else WnNGfosHr5STAq8j7miwyRZ6eOUbV
		tvsxEcqz7MN9JYOT,Xc1fo6iKLvQSEy5IPZU,cNmp4onf9T1FlKs6yreGQvCudP0 = KEIxy6oPrvg5abj3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
		if IMjqygdfYSKpHlWu5Aa(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩἻ") in KEIxy6oPrvg5abj3: tvsxEcqz7MN9JYOT,Xc1fo6iKLvQSEy5IPZU = KEIxy6oPrvg5abj3.split(oiWNFYzcIUeh(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪἼ"),wnaWTQM7VJPkZzO9eoSyFU4)
		try:
			if GHg28TBchiyn6l(u"ࠪࡥࡱࡨࡡࡱ࡮ࡤࡽࡪࡸࠧἽ") in tvsxEcqz7MN9JYOT: cNmp4onf9T1FlKs6yreGQvCudP0 = RRcaqDwHJOvGYAeL7n38(tvsxEcqz7MN9JYOT,kwzjvcuIgAONrYH,Xc1fo6iKLvQSEy5IPZU)
			elif ZLr5gRSkFewKdUos90bM(u"ࠫࡲ࡫ࡧࡢ࡯ࡤࡼࠬἾ") in tvsxEcqz7MN9JYOT: cNmp4onf9T1FlKs6yreGQvCudP0 = BQtqoisPwCI0rcFnLjuTYkNH(tvsxEcqz7MN9JYOT,kwzjvcuIgAONrYH,Xc1fo6iKLvQSEy5IPZU)
			elif QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࠵࡬࠰ࡣࡋࡖ࠵ࡩࡈࡎ࠸ࡏࡽ࠾࠭Ἷ") in tvsxEcqz7MN9JYOT: cNmp4onf9T1FlKs6yreGQvCudP0 = EOxNP3gXGeWhscM2CY45rBSZjR0FH(tvsxEcqz7MN9JYOT,kwzjvcuIgAONrYH,Xc1fo6iKLvQSEy5IPZU)
		except: pass
		if cNmp4onf9T1FlKs6yreGQvCudP0:
			for ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr in cNmp4onf9T1FlKs6yreGQvCudP0:
				NykoMPwBgT4zSQmGWYOrlcRU,dr9LHzvjo0SMVU = ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if mq5t9JXSdHT8yfDVF(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧὀ") in ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr: NykoMPwBgT4zSQmGWYOrlcRU,dr9LHzvjo0SMVU = ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr.split(oiWNFYzcIUeh(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨὁ"),wnaWTQM7VJPkZzO9eoSyFU4)
				if NykoMPwBgT4zSQmGWYOrlcRU not in kKibU78Vp1CHjft3I:
					kKibU78Vp1CHjft3I.append(NykoMPwBgT4zSQmGWYOrlcRU)
					kx5n2MH0TyoXKEesv3QVSa.append(ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr)
		elif tvsxEcqz7MN9JYOT not in kKibU78Vp1CHjft3I:
			kKibU78Vp1CHjft3I.append(tvsxEcqz7MN9JYOT)
			kx5n2MH0TyoXKEesv3QVSa.append(KEIxy6oPrvg5abj3)
	return kx5n2MH0TyoXKEesv3QVSa
def GpWKDYw3y5SVjJXO169BvzfR(source,G3Xh0YWACHFuvQLx5sVEfPjzq7,url):
	SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+pp7FcjEe6g(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࡵࠣࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨὂ")+source+A41nqbj3wYt(u"ࠩࠣࡡࠥࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪὃ")+G3Xh0YWACHFuvQLx5sVEfPjzq7+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࠤࡢ࠭ὄ"))
	y8BbYo26SWcALJgV = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,beV5l2D8HznyJI0(u"ࠫࡩ࡯ࡣࡵࠩὅ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ὆"),gPE1XB87fQl(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ὇"))
	y7anobAOsGxB2 = x54xSdnCFHZ8yliofzOBK.strftime(beV5l2D8HznyJI0(u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍࠨὈ"),x54xSdnCFHZ8yliofzOBK.gmtime(jDuxzCtBH7aihsSL9))
	AuNfQI1cKXGdWoU = y7anobAOsGxB2,url
	key = source+EVdNGw3APQXTfhxaHW1nRpiFkcotg+mbvW9By35UDO+EVdNGw3APQXTfhxaHW1nRpiFkcotg+str(CCPXJ7wnNLOg0ZoekcmpdSKI)
	eJU6bsndE1mI0F = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if key not in list(y8BbYo26SWcALJgV.keys()): y8BbYo26SWcALJgV[key] = [AuNfQI1cKXGdWoU]
	else:
		if url not in str(y8BbYo26SWcALJgV[key]): y8BbYo26SWcALJgV[key].append(AuNfQI1cKXGdWoU)
		else: eJU6bsndE1mI0F = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭Ὁ")
	fgrb9yOoWNlHqV0jePQvi7L = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	for key in list(y8BbYo26SWcALJgV.keys()):
		y8BbYo26SWcALJgV[key] = list(set(y8BbYo26SWcALJgV[key]))
		fgrb9yOoWNlHqV0jePQvi7L += len(y8BbYo26SWcALJgV[key])
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪὊ")+eJU6bsndE1mI0F+ZLr5gRSkFewKdUos90bM(u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩὋ")+IMjqygdfYSKpHlWu5Aa(u"ࠫࡡࡴ࡜࡯ࠩὌ")+bawK2j7T81Nrc4GWs05xzDg(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨὍ")+str(fgrb9yOoWNlHqV0jePQvi7L))
	if fgrb9yOoWNlHqV0jePQvi7L>=EEowc8rs5gUZTVjdOzmb0nu:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧ὎"))
		if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
			Ilw0KAOfLh3vi2 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			for key in list(y8BbYo26SWcALJgV.keys()):
				Ilw0KAOfLh3vi2 += WBDnh75CaLEvkcN6p4ez2KXrV3M+key
				Ic0D82h5yMOzwi1F79ZGKgkoNCVBed = sorted(y8BbYo26SWcALJgV[key],reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda hpFjkJ6z3VQMXrU4R0: hpFjkJ6z3VQMXrU4R0[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
				for y7anobAOsGxB2,url in Ic0D82h5yMOzwi1F79ZGKgkoNCVBed:
					Ilw0KAOfLh3vi2 += WBDnh75CaLEvkcN6p4ez2KXrV3M+y7anobAOsGxB2+EVdNGw3APQXTfhxaHW1nRpiFkcotg+EZk136aeLoNqPvlDcTQpyM9Wm(url)
				Ilw0KAOfLh3vi2 += gPE1XB87fQl(u"ࠧ࡝ࡰ࡟ࡲࠬ὏")
			import GkCs6wbiQP
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = GkCs6wbiQP.JbaHBRQsVkIGZ7(SI7eBdND4lx8pt5Qk(u"ࠨࡘ࡬ࡨࡪࡵࡳࠨὐ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ὑ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ilw0KAOfLh3vi2)
			if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭ὒ"))
			else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,kdRO82AImh0LFw(u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩὓ"))
		if kkLdeyJUsSiK9YwFZr4lPbVE!=-wnaWTQM7VJPkZzO9eoSyFU4:
			y8BbYo26SWcALJgV = {}
			sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,kdRO82AImh0LFw(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨὔ"),beV5l2D8HznyJI0(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬὕ"))
	if y8BbYo26SWcALJgV: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,IMjqygdfYSKpHlWu5Aa(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪὖ"),GHg28TBchiyn6l(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧὗ"),y8BbYo26SWcALJgV,iXBqSkDU3mRCZf4Ib)
	return
def iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,source,G3Xh0YWACHFuvQLx5sVEfPjzq7,url):
	if not wxT9bCdumN:
		GpWKDYw3y5SVjJXO169BvzfR(source,G3Xh0YWACHFuvQLx5sVEfPjzq7,url)
		return
	IISWAzUg18xVsPiNykMh2ce4JXEKZY = G3yDpvxOiSWdAeL.getSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭὘"))
	BX2wKl6eGj8cNZtrHJSYDEfWObo0 = A41nqbj3wYt(u"ࠪ࠱ࠬὙ") not in IISWAzUg18xVsPiNykMh2ce4JXEKZY
	cNmp4onf9T1FlKs6yreGQvCudP0 = gvyUqSYlGMJQPXKHWDsx40(wxT9bCdumN[:],source)
	if cNmp4onf9T1FlKs6yreGQvCudP0!=wxT9bCdumN and not BX2wKl6eGj8cNZtrHJSYDEfWObo0:
		llytgx3fSRkaKzhIuZA = []
		for KEIxy6oPrvg5abj3 in wxT9bCdumN:
			fLICWDGphJoRa2br94AiSkvn5N,MqXTicjeEC09zbKvdLxoWpm7aD = KEIxy6oPrvg5abj3,WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ὚") in KEIxy6oPrvg5abj3: fLICWDGphJoRa2br94AiSkvn5N,MqXTicjeEC09zbKvdLxoWpm7aD = KEIxy6oPrvg5abj3.split(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ὓ"),wnaWTQM7VJPkZzO9eoSyFU4)
			MqXTicjeEC09zbKvdLxoWpm7aD = MqXTicjeEC09zbKvdLxoWpm7aD.replace(tzZ6PhyDOUnwLM3pdK(u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ὜"),wwWzyF4ZpSQXKOgk569(u"ࠧࠨὝ")).replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ὞"),Z9FPQvwlbjLTh(u"ࠩࠪὟ")).replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫὠ"),IMjqygdfYSKpHlWu5Aa(u"ࠫࠬὡ"))
			llytgx3fSRkaKzhIuZA.append(MqXTicjeEC09zbKvdLxoWpm7aD)
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(kdRO82AImh0LFw(u"ࠬหุ่ษิࠤ็๎วว็ࠣห้า่ะหࠪὢ"),llytgx3fSRkaKzhIuZA)
	wxT9bCdumN = list(set(cNmp4onf9T1FlKs6yreGQvCudP0))
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UrwYehOQZVG4koguAaJzW10lC(wxT9bCdumN,source)
	if A3pXVFdyP1.resolveonly:
		YagP2DMHFWcXkdS4GC5e = lMBHPb4DCtkxRmevi2qW35(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,source,KiryBCvngZzF85UN6xSDlOVweL4I9)
		return
	nh5qWPeIsZ6,QXqRvTME9DBPsVYmyecrxlI,yhcPrjwxDtkYsniEKO,YagP2DMHFWcXkdS4GC5e,ffi1NVEwDLT6QdpxKRgtIMjA5szv,N6NV3h4fel = KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	fGUpWlKy8acLjBoQVeXt1wiZ35MFT7 = KiryBCvngZzF85UN6xSDlOVweL4I9 if source in oonlxDf39ark else r0D4C3z7Onqpa
	if fGUpWlKy8acLjBoQVeXt1wiZ35MFT7:
		ddKlyivhnXgYmp0ZeQVL8w7 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		AOce4mK97GL5PXyujzg3kv = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭࡬ࡪࡵࡷࠫὣ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬὤ"))
		VjhZxa1KlIzMoq502 = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡮࡬ࡷࡹ࠭ὥ"),mq5t9JXSdHT8yfDVF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬὦ"))
		OQ68TDodLKMBZvXmRIrqb5Az4 = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,CyHU86ZeYT5BWRcitSm2I(u"ࠪࡰ࡮ࡹࡴࠨὧ"),ZLr5gRSkFewKdUos90bM(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭Ὠ"))
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		for title,SOw5EUxC9k in list(zip(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u)):
			SOw5EUxC9k = SOw5EUxC9k.split(A41nqbj3wYt(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ὡ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			if SOw5EUxC9k in AOce4mK97GL5PXyujzg3kv:
				ddKlyivhnXgYmp0ZeQVL8w7 += wnaWTQM7VJPkZzO9eoSyFU4
				ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = ZTQ27jBMEeutsrSXalyb+title+YVr6St5P4xsFC0aARQGKfiegD
			elif SOw5EUxC9k in OQ68TDodLKMBZvXmRIrqb5Az4:
				ddKlyivhnXgYmp0ZeQVL8w7 += wnaWTQM7VJPkZzO9eoSyFU4
				ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = e6HEdvUcaq8Gx+title+YVr6St5P4xsFC0aARQGKfiegD
			elif SOw5EUxC9k in VjhZxa1KlIzMoq502:
				ddKlyivhnXgYmp0ZeQVL8w7 += wnaWTQM7VJPkZzO9eoSyFU4
				ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = title
			else:
				ddKlyivhnXgYmp0ZeQVL8w7 += wnaWTQM7VJPkZzO9eoSyFU4
				ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = title
			L3LoVh5B7OZMbHJlPXQ6EjnaUks += wnaWTQM7VJPkZzO9eoSyFU4
		N6NV3h4fel = [RNWqL0gBbKOie1DxjUpzQPh9aZyHX+tzZ6PhyDOUnwLM3pdK(u"࠭แฮืࠣะ๊๐ูࠡษ็ื๏ืแาษอࠫὪ")+YVr6St5P4xsFC0aARQGKfiegD]
	else: ffi1NVEwDLT6QdpxKRgtIMjA5szv = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧฤะอีࠥอไิ์ิๅึࠦวๅ็้หุฮࠧὫ")+YVr6St5P4xsFC0aARQGKfiegD
	while r0D4C3z7Onqpa:
		exr2BzN0RGh59TM8J4uXbkWQcV6gL1 = r0D4C3z7Onqpa
		if fGUpWlKy8acLjBoQVeXt1wiZ35MFT7:
			if BX2wKl6eGj8cNZtrHJSYDEfWObo0 and len(ZD0qItXg31HmC7KGEFn)==wnaWTQM7VJPkZzO9eoSyFU4: XFaM94cPUCOWQZNIEe8gdJpny1 = wnaWTQM7VJPkZzO9eoSyFU4
			else:
				rf1BMWIJowVH5bjP0tGSk = str(ZD0qItXg31HmC7KGEFn).count(ZTQ27jBMEeutsrSXalyb)
				AOvTdseMogLw7zu8IhB = str(ZD0qItXg31HmC7KGEFn).count(e6HEdvUcaq8Gx)
				w9wYGoihmbMO = len(ZD0qItXg31HmC7KGEFn)-rf1BMWIJowVH5bjP0tGSk-AOvTdseMogLw7zu8IhB
				if YVzokG2yZqrh3w8bU: ffi1NVEwDLT6QdpxKRgtIMjA5szv = e6HEdvUcaq8Gx+CyHU86ZeYT5BWRcitSm2I(u"ࠨࠢࠣࠤุ๐ฦส࠼ࠪὬ")+str(AOvTdseMogLw7zu8IhB)+YVr6St5P4xsFC0aARQGKfiegD+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭Ὥ")+str(w9wYGoihmbMO)+ZTQ27jBMEeutsrSXalyb+oiWNFYzcIUeh(u"ࠪะ๏ีษ࠻ࠩὮ")+str(rf1BMWIJowVH5bjP0tGSk)+YVr6St5P4xsFC0aARQGKfiegD
				else: ffi1NVEwDLT6QdpxKRgtIMjA5szv = ZTQ27jBMEeutsrSXalyb+gPE1XB87fQl(u"ࠫั๐ฯส࠼ࠪὯ")+str(rf1BMWIJowVH5bjP0tGSk)+YVr6St5P4xsFC0aARQGKfiegD+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࠦࠠࠡ็ฯ๋ํ๊ษ࠻ࠩὰ")+str(w9wYGoihmbMO)+e6HEdvUcaq8Gx+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨά")+str(AOvTdseMogLw7zu8IhB)+YVr6St5P4xsFC0aARQGKfiegD
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(ffi1NVEwDLT6QdpxKRgtIMjA5szv,N6NV3h4fel+ZD0qItXg31HmC7KGEFn)
			if XFaM94cPUCOWQZNIEe8gdJpny1==j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
				exr2BzN0RGh59TM8J4uXbkWQcV6gL1 = KiryBCvngZzF85UN6xSDlOVweL4I9
				start,end = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,len(ZD0qItXg31HmC7KGEFn)-wnaWTQM7VJPkZzO9eoSyFU4
				YagP2DMHFWcXkdS4GC5e = lMBHPb4DCtkxRmevi2qW35(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,source,r0D4C3z7Onqpa)
				yhcPrjwxDtkYsniEKO = tzZ6PhyDOUnwLM3pdK(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡤࡰࡱ࠭ὲ") if YagP2DMHFWcXkdS4GC5e else CyHU86ZeYT5BWRcitSm2I(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩέ")
			elif XFaM94cPUCOWQZNIEe8gdJpny1>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: start,end = XFaM94cPUCOWQZNIEe8gdJpny1-wnaWTQM7VJPkZzO9eoSyFU4,XFaM94cPUCOWQZNIEe8gdJpny1-wnaWTQM7VJPkZzO9eoSyFU4
		else:
			if BX2wKl6eGj8cNZtrHJSYDEfWObo0 and len(ZD0qItXg31HmC7KGEFn)==wnaWTQM7VJPkZzO9eoSyFU4: XFaM94cPUCOWQZNIEe8gdJpny1 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
			else: XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(ffi1NVEwDLT6QdpxKRgtIMjA5szv,ZD0qItXg31HmC7KGEFn)
			start,end = XFaM94cPUCOWQZNIEe8gdJpny1,XFaM94cPUCOWQZNIEe8gdJpny1
		if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4:
			yhcPrjwxDtkYsniEKO = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫὴ")
			break
		if exr2BzN0RGh59TM8J4uXbkWQcV6gL1:
			yhcPrjwxDtkYsniEKO = SI7eBdND4lx8pt5Qk(u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࡤࡵ࡮ࡦࠩή")
			YagP2DMHFWcXkdS4GC5e = lMBHPb4DCtkxRmevi2qW35([ZD0qItXg31HmC7KGEFn[start]],[M0MFkiKqJDv1aZ4NA396u[start]],source,r0D4C3z7Onqpa)
			title,SOw5EUxC9k,QXqRvTME9DBPsVYmyecrxlI,trNPCKLEgm,laAHpo1bzyM0q,X7tOEalyVv6e4zGhu8LJnR9PcSA = YagP2DMHFWcXkdS4GC5e[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			zKhToMgRHePwBtVr1da9vn2iX,AZ7pl9no6UVfvhTOdbPig3q = qL3lK8IMV5YFoG14C0ESx7drDbRmHN(title,SOw5EUxC9k,trNPCKLEgm,laAHpo1bzyM0q,source,G3Xh0YWACHFuvQLx5sVEfPjzq7)
			if zKhToMgRHePwBtVr1da9vn2iX in [ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩὶ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭ί"),pp7FcjEe6g(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧὸ")]:
				nh5qWPeIsZ6 = r0D4C3z7Onqpa
				break
			else:
				if not QXqRvTME9DBPsVYmyecrxlI: QXqRvTME9DBPsVYmyecrxlI = wwWzyF4ZpSQXKOgk569(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤ࡫ࡧࡩ࡭ࡧࡧࠫό")
				title = e6HEdvUcaq8Gx+title+YVr6St5P4xsFC0aARQGKfiegD
				YagP2DMHFWcXkdS4GC5e[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] = title,SOw5EUxC9k,QXqRvTME9DBPsVYmyecrxlI,trNPCKLEgm,laAHpo1bzyM0q,X7tOEalyVv6e4zGhu8LJnR9PcSA
				vvj8onATK3Vk1 = SOw5EUxC9k.split(SI7eBdND4lx8pt5Qk(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩὺ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,beV5l2D8HznyJI0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧύ"),vvj8onATK3Vk1)
				w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,gPE1XB87fQl(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬὼ"),vvj8onATK3Vk1,[QXqRvTME9DBPsVYmyecrxlI,title,SOw5EUxC9k],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
			if QXqRvTME9DBPsVYmyecrxlI==mq5t9JXSdHT8yfDVF(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩώ"): break
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧ὾")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࡜࡯࡝ࡏࡉࡋ࡚࡝ࠡࠢࠪ὿")) if QXqRvTME9DBPsVYmyecrxlI.count(WBDnh75CaLEvkcN6p4ez2KXrV3M)>I872Vum45fMNe1BRngTZLoQiqvkt(u"࠸ໞ") else WBDnh75CaLEvkcN6p4ez2KXrV3M+QXqRvTME9DBPsVYmyecrxlI
			if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᾀ") not in source: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,kdRO82AImh0LFw(u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࡠࡳ࠭ᾁ")+SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,profile=A6iX18qgyOFlZxz7sc(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧᾂ"))
			if len(M0MFkiKqJDv1aZ4NA396u)==wnaWTQM7VJPkZzO9eoSyFU4 and QXqRvTME9DBPsVYmyecrxlI: break
		for L3LoVh5B7OZMbHJlPXQ6EjnaUks in range(start,end+wnaWTQM7VJPkZzO9eoSyFU4):
			DZlJC0onrFLsXRdpSc6Uz5 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if exr2BzN0RGh59TM8J4uXbkWQcV6gL1 else L3LoVh5B7OZMbHJlPXQ6EjnaUks
			title,SOw5EUxC9k,QXqRvTME9DBPsVYmyecrxlI,trNPCKLEgm,laAHpo1bzyM0q,X7tOEalyVv6e4zGhu8LJnR9PcSA = YagP2DMHFWcXkdS4GC5e[DZlJC0onrFLsXRdpSc6Uz5]
			ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks].replace(e6HEdvUcaq8Gx,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(ZTQ27jBMEeutsrSXalyb,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(wpChqrHyRE1,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if X7tOEalyVv6e4zGhu8LJnR9PcSA==mq5t9JXSdHT8yfDVF(u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫᾃ"): ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = ZTQ27jBMEeutsrSXalyb+ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks]+YVr6St5P4xsFC0aARQGKfiegD
			elif X7tOEalyVv6e4zGhu8LJnR9PcSA==KLX7hW0nBAEgy6m4SvH(u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᾄ"): ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = e6HEdvUcaq8Gx+ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks]+YVr6St5P4xsFC0aARQGKfiegD
			else: ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks] = ZD0qItXg31HmC7KGEFn[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
	if yhcPrjwxDtkYsniEKO==kdRO82AImh0LFw(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭ᾅ"): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"࠭ไๅลึๅ๊ࠥวࠡ์๋ะิࠦำ๋ำไีฬะࠠอ์าอࠥ็๊้ࠡำหࠥอไโ์า๎ํࠦ࠮࠯ࠢะหํ๊ࠠฤ่ࠣฮอำหࠡ฻้ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎๋่ࠥศไ฼ࠤศิั๊ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠫᾆ"))
	if not nh5qWPeIsZ6 or yhcPrjwxDtkYsniEKO in [IMjqygdfYSKpHlWu5Aa(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩᾇ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩᾈ")] or QXqRvTME9DBPsVYmyecrxlI:
		HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩᾉ"))
	return
def lMBHPb4DCtkxRmevi2qW35(pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN,source,showDialogs):
	global p13pZTvCUm54cMjslubxBgy2,x2FDvJWULC1I8fwszGZ6btYlMoRKNX,wPdYgCc6RaqTQmABOS,PhNonirF9pDJ,QZ24pVBJkqu1HDdh0Ez6ly3eI,MjCf2o6On3mKRAab7JcdkzGTvDqx
	p13pZTvCUm54cMjslubxBgy2,x2FDvJWULC1I8fwszGZ6btYlMoRKNX,wPdYgCc6RaqTQmABOS,PhNonirF9pDJ = [],[],[],[]
	QZ24pVBJkqu1HDdh0Ez6ly3eI,MjCf2o6On3mKRAab7JcdkzGTvDqx = [],[]
	APpdhB1Fk58MmJH7CjVntowyaY,R8sJ0qLfhKkPU,new = [],[],[]
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd)
	count = len(wxT9bCdumN)
	for VV60kArCYGvUWNOLymTJze in range(count):
		p13pZTvCUm54cMjslubxBgy2.append(OHohTgj06taKzsG)
		x2FDvJWULC1I8fwszGZ6btYlMoRKNX.append(OHohTgj06taKzsG)
		wPdYgCc6RaqTQmABOS.append(OHohTgj06taKzsG)
		PhNonirF9pDJ.append(OHohTgj06taKzsG)
		QZ24pVBJkqu1HDdh0Ez6ly3eI.append(OHohTgj06taKzsG)
		MjCf2o6On3mKRAab7JcdkzGTvDqx.append(j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		title = pixfvyGY1aJPowKZer34TcNblL7k2[VV60kArCYGvUWNOLymTJze]
		SOw5EUxC9k = wxT9bCdumN[VV60kArCYGvUWNOLymTJze].strip(kcXMWrwiLDKeBHRsJ).strip(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࠪࠬᾊ")).strip(yobpaW7sBqtKRrv(u"ࠫࡄ࠭ᾋ")).strip(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬ࠵ࠧᾌ"))
		if count>wnaWTQM7VJPkZzO9eoSyFU4 and showDialogs: uTaiRMI8eYmN(beV5l2D8HznyJI0(u"࠭แฮืࠣื๏ืแาࠢิๆ๊ࠦࠠࠨᾍ")+str(VV60kArCYGvUWNOLymTJze+gPE1XB87fQl(u"࠷ໟ")),title)
		mXyLtjS7aWIp4Q3l1BNg0RxAEo = [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᾎ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ᾏ"),GHg28TBchiyn6l(u"ࠩࡄࡏ࡜ࡇࡍࠨᾐ")]
		if source in mXyLtjS7aWIp4Q3l1BNg0RxAEo: QZ24pVBJkqu1HDdh0Ez6ly3eI[VV60kArCYGvUWNOLymTJze] = UXoCzg4kaO3GySrid21wNqKWpAFtJP(title,SOw5EUxC9k,source,VV60kArCYGvUWNOLymTJze,r0D4C3z7Onqpa)
		else:
			if wnaWTQM7VJPkZzO9eoSyFU4:
				C0ObFANpGKnEm = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=UXoCzg4kaO3GySrid21wNqKWpAFtJP,args=(title,SOw5EUxC9k,source,VV60kArCYGvUWNOLymTJze,count==mq5t9JXSdHT8yfDVF(u"࠱໠")))
				R8sJ0qLfhKkPU.append(C0ObFANpGKnEm)
				new.append(VV60kArCYGvUWNOLymTJze)
	def YwoDWEq93VbFASGgTcZeKjH1zUsIlp():
		NU1y0Bce2G7S = KiryBCvngZzF85UN6xSDlOVweL4I9
		for SOw5EUxC9k in QZ24pVBJkqu1HDdh0Ez6ly3eI:
			if not SOw5EUxC9k: break
		else: NU1y0Bce2G7S = r0D4C3z7Onqpa
		iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying() if A3pXVFdyP1.resolveonly else r0D4C3z7Onqpa
		return NU1y0Bce2G7S or not iH7pE9rXVqy5k1Uu
	vGFdXD2x8ORu6aj(R8sJ0qLfhKkPU,u0TCgbwroymt,kWE5274r1n,wnaWTQM7VJPkZzO9eoSyFU4,YwoDWEq93VbFASGgTcZeKjH1zUsIlp)
	for VV60kArCYGvUWNOLymTJze in range(count):
		title = pixfvyGY1aJPowKZer34TcNblL7k2[VV60kArCYGvUWNOLymTJze]
		SOw5EUxC9k = wxT9bCdumN[VV60kArCYGvUWNOLymTJze].strip(kcXMWrwiLDKeBHRsJ).strip(mq5t9JXSdHT8yfDVF(u"ࠪࠪࠬᾑ")).strip(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡄ࠭ᾒ")).strip(kdRO82AImh0LFw(u"ࠬ࠵ࠧᾓ"))
		vvj8onATK3Vk1 = SOw5EUxC9k.split(A41nqbj3wYt(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᾔ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if VV60kArCYGvUWNOLymTJze in new else KiryBCvngZzF85UN6xSDlOVweL4I9
		stream = QZ24pVBJkqu1HDdh0Ez6ly3eI[VV60kArCYGvUWNOLymTJze]
		if stream and not stream[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] and stream[XURrDCfOS9Mbhpv2Pmjos56TeW]:
			X7tOEalyVv6e4zGhu8LJnR9PcSA = iySORMYxWXszEH18(u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨᾕ")
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = stream
			if vvj8onATK3Vk1: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,mq5t9JXSdHT8yfDVF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ᾖ"),vvj8onATK3Vk1,[SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
		elif stream and stream[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] and not stream[wnaWTQM7VJPkZzO9eoSyFU4] and not stream[XURrDCfOS9Mbhpv2Pmjos56TeW]:
			X7tOEalyVv6e4zGhu8LJnR9PcSA = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪᾗ")
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = beV5l2D8HznyJI0(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤ࡝ࡰࠪᾘ")+stream[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],[],[]
			if vvj8onATK3Vk1: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭ᾙ"),vvj8onATK3Vk1,[SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
		elif MjCf2o6On3mKRAab7JcdkzGTvDqx[VV60kArCYGvUWNOLymTJze]+wnaWTQM7VJPkZzO9eoSyFU4>oJOHPhU8M7DyrYQGbfLVelsvW9X4q:
			X7tOEalyVv6e4zGhu8LJnR9PcSA = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ᾚ")
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = Z9FPQvwlbjLTh(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡹ࡯࡭ࡦࡦࠣࡳࡺࡺࠠࠩࠩᾛ")+str(MjCf2o6On3mKRAab7JcdkzGTvDqx[VV60kArCYGvUWNOLymTJze])+wwWzyF4ZpSQXKOgk569(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪᾜ"),[],[]
			if vvj8onATK3Vk1: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,VP70ytiFNMBl6vHDaW(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫᾝ"),vvj8onATK3Vk1,[SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
		elif not stream:
			X7tOEalyVv6e4zGhu8LJnR9PcSA = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡦࡥࡳࡩࡥ࡭ࠩᾞ")
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = rVy3Ops0mohYkT(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᾟ"),[],[]
			if vvj8onATK3Vk1: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧᾠ"),vvj8onATK3Vk1,[SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
		else:
			X7tOEalyVv6e4zGhu8LJnR9PcSA = beV5l2D8HznyJI0(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ᾡ")
			SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = yobpaW7sBqtKRrv(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡵࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ᾢ"),[],[]
			if vvj8onATK3Vk1: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,GHg28TBchiyn6l(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪᾣ"),vvj8onATK3Vk1,[SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
		APpdhB1Fk58MmJH7CjVntowyaY.append([title,SOw5EUxC9k,SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,X7tOEalyVv6e4zGhu8LJnR9PcSA])
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83)
	return APpdhB1Fk58MmJH7CjVntowyaY
def UXoCzg4kaO3GySrid21wNqKWpAFtJP(VVpQfHc7IZamxweON3WXKU6Fg,url,source,vdRg23DAaJe8,WICxADzO2nkrJe51a):
	global QZ24pVBJkqu1HDdh0Ez6ly3eI,MjCf2o6On3mKRAab7JcdkzGTvDqx
	MjCf2o6On3mKRAab7JcdkzGTvDqx[vdRg23DAaJe8] = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	CIeL32XZ57bpg6WFyKB = x54xSdnCFHZ8yliofzOBK.time()
	SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+rVy3Ops0mohYkT(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩᾤ")+VVpQfHc7IZamxweON3WXKU6Fg+wwWzyF4ZpSQXKOgk569(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭ᾥ")+url+kdRO82AImh0LFw(u"ࠪࠤࡢ࠭ᾦ"))
	SOw5EUxC9k,xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs = url,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	rrXW3bUcnOYAlCi8J4uBH = A41nqbj3wYt(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨᾧ")
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = ScKEj1mN3ukRdTnJAXHvIYs9i8QG(url,source)
	if QXqRvTME9DBPsVYmyecrxlI==rVy3Ops0mohYkT(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᾨ"):
		QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᾩ"),[],[]
		MjCf2o6On3mKRAab7JcdkzGTvDqx[vdRg23DAaJe8] = x54xSdnCFHZ8yliofzOBK.time()-CIeL32XZ57bpg6WFyKB
		return QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8]
	elif VP70ytiFNMBl6vHDaW(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᾪ") in QXqRvTME9DBPsVYmyecrxlI:
		xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs = KLX7hW0nBAEgy6m4SvH(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥ࠮࠲࠮࠷ࠬࠫᾫ")
		SOw5EUxC9k = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		rrXW3bUcnOYAlCi8J4uBH,xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = ftj4JUeMASTO6m1RbL2GNPWQzpV(xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,SOw5EUxC9k,source,vdRg23DAaJe8)
		if xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs==KLX7hW0nBAEgy6m4SvH(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᾬ"):
			QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
			MjCf2o6On3mKRAab7JcdkzGTvDqx[vdRg23DAaJe8] = x54xSdnCFHZ8yliofzOBK.time()-CIeL32XZ57bpg6WFyKB
			return xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	elif QXqRvTME9DBPsVYmyecrxlI: xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪᾭ")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[:Z9FPQvwlbjLTh(u"࠹࠲໡")]
	if M0MFkiKqJDv1aZ4NA396u:
		M0MFkiKqJDv1aZ4NA396u = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)
		SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧᾮ")+VVpQfHc7IZamxweON3WXKU6Fg+rVy3Ops0mohYkT(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩᾯ")+rrXW3bUcnOYAlCi8J4uBH+wwWzyF4ZpSQXKOgk569(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᾰ")+url+mq5t9JXSdHT8yfDVF(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧᾱ")+SOw5EUxC9k+SI7eBdND4lx8pt5Qk(u"ࠨࠢࡠࠤ࡙ࠥࠦࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭ᾲ")+str(M0MFkiKqJDv1aZ4NA396u)+wwWzyF4ZpSQXKOgk569(u"ࠩࠣࡡࠬᾳ"))
	else:
		zARn7gGbNPSQhvrX = GHg28TBchiyn6l(u"ࠪࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪᾴ")+xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࠥࡣࠧ᾵") if WICxADzO2nkrJe51a else WnNGfosHr5STAq8j7miwyRZ6eOUbV
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+IMjqygdfYSKpHlWu5Aa(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬᾶ")+VVpQfHc7IZamxweON3WXKU6Fg+jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᾷ")+url+Z9FPQvwlbjLTh(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧᾸ")+SOw5EUxC9k+oiWNFYzcIUeh(u"ࠨࠢࡠࠫᾹ")+zARn7gGbNPSQhvrX)
	xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs = EZk136aeLoNqPvlDcTQpyM9Wm(xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs)
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	MjCf2o6On3mKRAab7JcdkzGTvDqx[vdRg23DAaJe8] = x54xSdnCFHZ8yliofzOBK.time()-CIeL32XZ57bpg6WFyKB
	return xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def qL3lK8IMV5YFoG14C0ESx7drDbRmHN(title,SOw5EUxC9k,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,source,G3Xh0YWACHFuvQLx5sVEfPjzq7=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if M0MFkiKqJDv1aZ4NA396u:
		if not ZD0qItXg31HmC7KGEFn[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]: ZD0qItXg31HmC7KGEFn = M0MFkiKqJDv1aZ4NA396u
		IISWAzUg18xVsPiNykMh2ce4JXEKZY = G3yDpvxOiSWdAeL.getSetting(tzZ6PhyDOUnwLM3pdK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭Ὰ"))
		BX2wKl6eGj8cNZtrHJSYDEfWObo0 = Z9FPQvwlbjLTh(u"ࠪ࠱ࠬΆ") not in IISWAzUg18xVsPiNykMh2ce4JXEKZY
		while r0D4C3z7Onqpa:
			if BX2wKl6eGj8cNZtrHJSYDEfWObo0 and len(M0MFkiKqJDv1aZ4NA396u)==wnaWTQM7VJPkZzO9eoSyFU4: XFaM94cPUCOWQZNIEe8gdJpny1 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
			else: XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪᾼ"),ZD0qItXg31HmC7KGEFn)
			if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: U2vri4t3a8S = gPE1XB87fQl(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧ᾽")
			else:
				fygGEL2RaWur6QKqB = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
				SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+KLX7hW0nBAEgy6m4SvH(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬι")+title+kdRO82AImh0LFw(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ᾿")+SOw5EUxC9k+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ῀")+str(fygGEL2RaWur6QKqB)+ZLr5gRSkFewKdUos90bM(u"ࠩࠣࡡࠬ῁"))
				if eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭ῂ") in fygGEL2RaWur6QKqB and wwWzyF4ZpSQXKOgk569(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫῃ") in fygGEL2RaWur6QKqB:
					SPUR1kNlxX6bTgiQh7sYnKCo8Wvqu,OL7ND5xIzt36lV4oAyrkQJqUR,CZ3H7wEGYM9uDFl5JIm4dgP0Tx = F4FYl2H3Op(fygGEL2RaWur6QKqB)
					if CZ3H7wEGYM9uDFl5JIm4dgP0Tx: fygGEL2RaWur6QKqB = CZ3H7wEGYM9uDFl5JIm4dgP0Tx[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					else: fygGEL2RaWur6QKqB = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if not fygGEL2RaWur6QKqB: U2vri4t3a8S = rVy3Ops0mohYkT(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩῄ")
				else: U2vri4t3a8S = YsRk6pAS7rdcn(fygGEL2RaWur6QKqB,source,G3Xh0YWACHFuvQLx5sVEfPjzq7)
			if U2vri4t3a8S in [IMjqygdfYSKpHlWu5Aa(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ῅"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨῆ"),yobpaW7sBqtKRrv(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ῇ"),tzZ6PhyDOUnwLM3pdK(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫῈ")] or len(M0MFkiKqJDv1aZ4NA396u)==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠳໢"): break
			elif U2vri4t3a8S in [IMjqygdfYSKpHlWu5Aa(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪΈ"),VP70ytiFNMBl6vHDaW(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬῊ"),pp7FcjEe6g(u"ࠬࡺࡲࡪࡧࡧࠫΉ")]: break
			else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,VP70ytiFNMBl6vHDaW(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬῌ"))
	else:
		U2vri4t3a8S = A41nqbj3wYt(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ῍")
		if mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k): U2vri4t3a8S = YsRk6pAS7rdcn(SOw5EUxC9k,source,G3Xh0YWACHFuvQLx5sVEfPjzq7)
	return U2vri4t3a8S,M0MFkiKqJDv1aZ4NA396u
def yyWdhEaDkfZm(url,source):
	vcQbFfCk6T1,dr9LHzvjo0SMVU,VVpQfHc7IZamxweON3WXKU6Fg,i0UCZG1a23QNItMVsz5dryFvDunoT,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL = url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if IMjqygdfYSKpHlWu5Aa(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ῎") in url:
		vcQbFfCk6T1,dr9LHzvjo0SMVU = url.split(A6iX18qgyOFlZxz7sc(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ῏"),wnaWTQM7VJPkZzO9eoSyFU4)
		dr9LHzvjo0SMVU = dr9LHzvjo0SMVU+IMjqygdfYSKpHlWu5Aa(u"ࠪࡣࡤ࠭ῐ")+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡤࡥࠧῑ")+A6iX18qgyOFlZxz7sc(u"ࠬࡥ࡟ࠨῒ")+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭࡟ࡠࠩΐ")+VP70ytiFNMBl6vHDaW(u"ࠧࡠࡡࠪ῔")
		fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL,rOYi4sNpFBlAvtC6LK = dr9LHzvjo0SMVU.split(kdRO82AImh0LFw(u"ࠨࡡࡢࠫ῕"))[:kdRO82AImh0LFw(u"࠹໣")]
	if not DIBw28Qfje76bTMzVNYhxrgWmO: DIBw28Qfje76bTMzVNYhxrgWmO = gPE1XB87fQl(u"ࠩ࠳ࠫῖ")
	else: DIBw28Qfje76bTMzVNYhxrgWmO = DIBw28Qfje76bTMzVNYhxrgWmO.replace(VP70ytiFNMBl6vHDaW(u"ࠪࡴࠬῗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(kcXMWrwiLDKeBHRsJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	vcQbFfCk6T1 = vcQbFfCk6T1.strip(IMjqygdfYSKpHlWu5Aa(u"ࠫࡄ࠭Ῐ")).strip(tzZ6PhyDOUnwLM3pdK(u"ࠬ࠵ࠧῙ")).strip(GHg28TBchiyn6l(u"࠭ࠦࠨῚ"))
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡩࡱࡶࡸࠬΊ"))
	if fzu7Got0FgiyshTlJK: i0UCZG1a23QNItMVsz5dryFvDunoT = fzu7Got0FgiyshTlJK
	else: i0UCZG1a23QNItMVsz5dryFvDunoT = VVpQfHc7IZamxweON3WXKU6Fg
	i0UCZG1a23QNItMVsz5dryFvDunoT = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(i0UCZG1a23QNItMVsz5dryFvDunoT,pp7FcjEe6g(u"ࠨࡰࡤࡱࡪ࠭῜"))
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"่ࠩฬฬฺัࠨ῝"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪื๏ืแาࠩ῞"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(mq5t9JXSdHT8yfDVF(u"ࠫฬ๊ࠠࠨ῟"),kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	dr9LHzvjo0SMVU = dr9LHzvjo0SMVU.replace(yobpaW7sBqtKRrv(u"๋ࠬศศึิࠫῠ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ำ๋ำไีࠬῡ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧศๆࠣࠫῢ"),kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	i0UCZG1a23QNItMVsz5dryFvDunoT = i0UCZG1a23QNItMVsz5dryFvDunoT.replace(wwWzyF4ZpSQXKOgk569(u"ࠨ็หหูืࠧΰ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(bawK2j7T81Nrc4GWs05xzDg(u"ࠩึ๎ึ็ัࠨῤ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(iySORMYxWXszEH18(u"ࠪห้ࠦࠧῥ"),kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	return vcQbFfCk6T1,dr9LHzvjo0SMVU,VVpQfHc7IZamxweON3WXKU6Fg,i0UCZG1a23QNItMVsz5dryFvDunoT,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL
def nFtwAhVXdHOKZsuk(url,source):
	u9d3IanPEV4f,fzu7Got0FgiyshTlJK,Ju5KPR6wlImNo1,EvGLjRAxclJzB5p9kSrVKHfM2gm,ttJd5c38Toiwxj,MqXTicjeEC09zbKvdLxoWpm7aD,rrXW3bUcnOYAlCi8J4uBH = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OHohTgj06taKzsG,OHohTgj06taKzsG,OHohTgj06taKzsG,OHohTgj06taKzsG,OHohTgj06taKzsG
	vcQbFfCk6T1,dr9LHzvjo0SMVU,VVpQfHc7IZamxweON3WXKU6Fg,i0UCZG1a23QNItMVsz5dryFvDunoT,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL = yyWdhEaDkfZm(url,source)
	if CyHU86ZeYT5BWRcitSm2I(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬῦ") in url:
		if   G3Xh0YWACHFuvQLx5sVEfPjzq7==GHg28TBchiyn6l(u"ࠬ࡫࡭ࡣࡧࡧࠫῧ"): G3Xh0YWACHFuvQLx5sVEfPjzq7 = kcXMWrwiLDKeBHRsJ+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ๅโุ็ࠫῨ")
		elif G3Xh0YWACHFuvQLx5sVEfPjzq7==Z9FPQvwlbjLTh(u"ࠧࡸࡣࡷࡧ࡭࠭Ῡ"): G3Xh0YWACHFuvQLx5sVEfPjzq7 = kcXMWrwiLDKeBHRsJ+beV5l2D8HznyJI0(u"ࠨุ่ࠧฬํฯสࠩῪ")
		elif G3Xh0YWACHFuvQLx5sVEfPjzq7==mq5t9JXSdHT8yfDVF(u"ࠩࡥࡳࡹ࡮ࠧΎ"): G3Xh0YWACHFuvQLx5sVEfPjzq7 = kcXMWrwiLDKeBHRsJ+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬῬ")
		elif G3Xh0YWACHFuvQLx5sVEfPjzq7==wwWzyF4ZpSQXKOgk569(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭῭"): G3Xh0YWACHFuvQLx5sVEfPjzq7 = kcXMWrwiLDKeBHRsJ+SI7eBdND4lx8pt5Qk(u"ࠬࠫࠥࠦฬะ้๏๊ࠧ΅")
		elif G3Xh0YWACHFuvQLx5sVEfPjzq7==WnNGfosHr5STAq8j7miwyRZ6eOUbV: G3Xh0YWACHFuvQLx5sVEfPjzq7 = kcXMWrwiLDKeBHRsJ+KLX7hW0nBAEgy6m4SvH(u"࠭ࠥࠦࠧࠨࠫ`")
		if P4cqC2X0dpeHbg3KW!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧ࡮ࡲ࠷ࠫ῰") not in P4cqC2X0dpeHbg3KW: P4cqC2X0dpeHbg3KW = SI7eBdND4lx8pt5Qk(u"ࠨࠧࠪ῱")+P4cqC2X0dpeHbg3KW
			P4cqC2X0dpeHbg3KW = kcXMWrwiLDKeBHRsJ+P4cqC2X0dpeHbg3KW
		if DIBw28Qfje76bTMzVNYhxrgWmO!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			DIBw28Qfje76bTMzVNYhxrgWmO = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬῲ")+DIBw28Qfje76bTMzVNYhxrgWmO
			DIBw28Qfje76bTMzVNYhxrgWmO = kcXMWrwiLDKeBHRsJ+DIBw28Qfje76bTMzVNYhxrgWmO[-n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠽໤"):]
	if   gPE1XB87fQl(u"ࠪࡅࡐࡕࡁࡎࠩῳ")		in source: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif gPE1XB87fQl(u"ࠫࡆࡑࡗࡂࡏࠪῴ")		in source and XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࡚ࠬࡕࡃࡇࠪ῵") not in source: Ju5KPR6wlImNo1	= iySORMYxWXszEH18(u"࠭ࡡ࡬ࡹࡤࡱࠬῶ")
	elif kdRO82AImh0LFw(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩῷ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧῸ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif ZLr5gRSkFewKdUos90bM(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫΌ")		in source: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif kdRO82AImh0LFw(u"ࠪࡥࡱࡧࡲࡢࡤࠪῺ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif Z9FPQvwlbjLTh(u"ࠫ࡫ࡧࡳࡦ࡮ࠪΏ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif tzZ6PhyDOUnwLM3pdK(u"ࠬࡺ࠷࡮ࡧࡨࡰࠬῼ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif SI7eBdND4lx8pt5Qk(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭´")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif iySORMYxWXszEH18(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ῾")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif iySORMYxWXszEH18(u"ࠨࡨࡤ࡮ࡪࡸࠧ῿")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif Z9FPQvwlbjLTh(u"ࠫๆาัࠨࠀ")			in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= pp7FcjEe6g(u"ࠬ࡬ࡡ࡫ࡧࡵࠫࠁ")
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭แๅีฺ๎๋࠭ࠂ")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪࠃ")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡩࡧࡶ࡮ࡼࡥࠨࠄ")		in vcQbFfCk6T1:   Ju5KPR6wlImNo1	= Z9FPQvwlbjLTh(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩࠅ")
	elif gPE1XB87fQl(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪࠆ")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫࠇ")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ࠈ")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif tzZ6PhyDOUnwLM3pdK(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧࠉ")		in fzu7Got0FgiyshTlJK:   Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬࠊ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif pp7FcjEe6g(u"ࠨࡤࡲ࡯ࡷࡧࠧࠋ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif pp7FcjEe6g(u"ࠩࡷࡺ࡫ࡻ࡮ࠨࠌ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡸࡻࡱࡳࡢࠩࠍ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif CyHU86ZeYT5BWRcitSm2I(u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬࠎ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧࠏ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif GHg28TBchiyn6l(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨࠐ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩࠑ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif ZLr5gRSkFewKdUos90bM(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨࠒ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩࠓ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬࠔ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭ࠕ")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif tzZ6PhyDOUnwLM3pdK(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭ࠖ")	 	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡲࡦࡦࡰࡳࡩࡾࠧࠗ")
	elif yobpaW7sBqtKRrv(u"ࠧࡺࡱࡸࡸࡺ࠭࠘")	 	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= tzZ6PhyDOUnwLM3pdK(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ࠙")
	elif VP70ytiFNMBl6vHDaW(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩࠚ")	 	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= IMjqygdfYSKpHlWu5Aa(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫࠛ")
	elif A6iX18qgyOFlZxz7sc(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪࠜ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪࠝ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= KLX7hW0nBAEgy6m4SvH(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪࠞ")
	elif mq5t9JXSdHT8yfDVF(u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩࠟ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= oiWNFYzcIUeh(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪࠠ")
	elif YYQS36fyPvtuzcEmRL(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪࠡ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= beV5l2D8HznyJI0(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬࠢ")
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭ࠣ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧࠤ")
	elif wwWzyF4ZpSQXKOgk569(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬࠥ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= wwWzyF4ZpSQXKOgk569(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ࠦ")
	elif yobpaW7sBqtKRrv(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫࠧ")	in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩࠨ")
	elif tzZ6PhyDOUnwLM3pdK(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫࠩ")		in VVpQfHc7IZamxweON3WXKU6Fg: Ju5KPR6wlImNo1	= lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬࠪ")
	elif GHg28TBchiyn6l(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨࠫ")	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩࠬ")
	elif Z9FPQvwlbjLTh(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ࠭")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= kdRO82AImh0LFw(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ࠮")
	elif kdRO82AImh0LFw(u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ࠯")	 	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡧࡦࡺࡣࡩࠩ࠰")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ࠱")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= IMjqygdfYSKpHlWu5Aa(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭࠲")
	elif wwWzyF4ZpSQXKOgk569(u"࠭ࡶࡪࡦࡥࡱࠬ࠳")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= Z9FPQvwlbjLTh(u"ࠧࡷ࡫ࡧࡦࡲ࠭࠴")
	elif tzZ6PhyDOUnwLM3pdK(u"ࠨࡸ࡬ࡨ࡭ࡪࠧ࠵")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif CyHU86ZeYT5BWRcitSm2I(u"ࠩࡰࡽࡻ࡯ࡤࠨ࠶")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif YYQS36fyPvtuzcEmRL(u"ࠪࡱࡾࡼࡩࡪࡦࠪ࠷")		in VVpQfHc7IZamxweON3WXKU6Fg: MqXTicjeEC09zbKvdLxoWpm7aD	= i0UCZG1a23QNItMVsz5dryFvDunoT
	elif KLX7hW0nBAEgy6m4SvH(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭࠸")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= rVy3Ops0mohYkT(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ࠹")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡧࡰࡸ࡬ࡨࠬ࠺")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= oiWNFYzcIUeh(u"ࠧࡨࡱࡹ࡭ࡩ࠭࠻")
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ࠼") 	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= yobpaW7sBqtKRrv(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ࠽")
	elif tzZ6PhyDOUnwLM3pdK(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭࠾")	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ࠿")
	elif gPE1XB87fQl(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪࡀ")	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫࡁ")
	elif kdRO82AImh0LFw(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫࡂ") 	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= ZLr5gRSkFewKdUos90bM(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬࡃ")
	elif beV5l2D8HznyJI0(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪࡄ")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= Z9FPQvwlbjLTh(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫࡅ")
	elif YYQS36fyPvtuzcEmRL(u"ࠫࡺࡶࡰࠨࡆ") 			in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= GHg28TBchiyn6l(u"ࠬࡻࡰࡣࡱࡰࠫࡇ")
	elif n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡵࡱࡤࠪࡈ") 			in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= wwWzyF4ZpSQXKOgk569(u"ࠧࡶࡲࡥࡳࡲ࠭ࡉ")
	elif A41nqbj3wYt(u"ࠨࡷࡴࡰࡴࡧࡤࠨࡊ") 		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= beV5l2D8HznyJI0(u"ࠩࡸࡵࡱࡵࡡࡥࠩࡋ")
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡺࡰ࠭ࡌ") 			in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡻࡱࠧࡍ")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧࡎ") 	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= CyHU86ZeYT5BWRcitSm2I(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨࡏ")
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧࡐ")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= SI7eBdND4lx8pt5Qk(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨࡑ")
	elif YYQS36fyPvtuzcEmRL(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩࡒ") 		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= A6iX18qgyOFlZxz7sc(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪࡓ")
	elif A6iX18qgyOFlZxz7sc(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨࡔ") 	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩࡕ")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪࡖ")	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫࡗ")
	elif yobpaW7sBqtKRrv(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬࡘ")	in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= kdRO82AImh0LFw(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࡙࠭")
	elif tzZ6PhyDOUnwLM3pdK(u"ࠪ࡬ࡩ࠳ࡣࡥࡰ࡚ࠪ")		in VVpQfHc7IZamxweON3WXKU6Fg: EvGLjRAxclJzB5p9kSrVKHfM2gm	= yobpaW7sBqtKRrv(u"ࠫ࡭ࡪ࠭ࡤࡦࡱ࡛ࠫ")
	if   Ju5KPR6wlImNo1:	u9d3IanPEV4f,fzu7Got0FgiyshTlJK = A41nqbj3wYt(u"ࠬิวึࠩ࡜"),Ju5KPR6wlImNo1
	elif MqXTicjeEC09zbKvdLxoWpm7aD:		u9d3IanPEV4f,fzu7Got0FgiyshTlJK = beV5l2D8HznyJI0(u"࠭ࠥๆฯาำࠬ࡝"),MqXTicjeEC09zbKvdLxoWpm7aD
	elif EvGLjRAxclJzB5p9kSrVKHfM2gm:		u9d3IanPEV4f,fzu7Got0FgiyshTlJK = bawK2j7T81Nrc4GWs05xzDg(u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ࡞"),EvGLjRAxclJzB5p9kSrVKHfM2gm
	elif ttJd5c38Toiwxj:	u9d3IanPEV4f,fzu7Got0FgiyshTlJK = A41nqbj3wYt(u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ࡟"),ttJd5c38Toiwxj
	elif rrXW3bUcnOYAlCi8J4uBH:	u9d3IanPEV4f,fzu7Got0FgiyshTlJK = YYQS36fyPvtuzcEmRL(u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩࡠ"),i0UCZG1a23QNItMVsz5dryFvDunoT
	else:			u9d3IanPEV4f,fzu7Got0FgiyshTlJK = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫࡡ"),i0UCZG1a23QNItMVsz5dryFvDunoT
	return u9d3IanPEV4f,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO
def NNB9MxC3PXp5WFT(QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u):
	trNPCKLEgm,laAHpo1bzyM0q = [],[]
	for title,SOw5EUxC9k in list(zip(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u)):
		if mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k):
			trNPCKLEgm.append(title)
			laAHpo1bzyM0q.append(SOw5EUxC9k)
	if not laAHpo1bzyM0q and not QXqRvTME9DBPsVYmyecrxlI: QXqRvTME9DBPsVYmyecrxlI = pp7FcjEe6g(u"ࠫࡋࡧࡩ࡭ࡧࡧࠫࡢ")
	return QXqRvTME9DBPsVYmyecrxlI,trNPCKLEgm,laAHpo1bzyM0q
def ScKEj1mN3ukRdTnJAXHvIYs9i8QG(url,source):
	vcQbFfCk6T1,MqXTicjeEC09zbKvdLxoWpm7aD,VVpQfHc7IZamxweON3WXKU6Fg,i0UCZG1a23QNItMVsz5dryFvDunoT,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL = yyWdhEaDkfZm(url,source)
	if   kdRO82AImh0LFw(u"ࠬࡿ࡯ࡶࡶࡸࠫࡣ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = VP70ytiFNMBl6vHDaW(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࡤ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧࡥ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = IMjqygdfYSKpHlWu5Aa(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡦ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	elif mq5t9JXSdHT8yfDVF(u"ࠩࡤࡰࡧࡧࡰ࡭ࡣࡼࡩࡷ࠭ࡧ")	in vcQbFfCk6T1  : QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = wQI87W2sU1ckAEYi(vcQbFfCk6T1)
	elif beV5l2D8HznyJI0(u"ࠪࡅࡐࡕࡁࡎࠩࡨ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = IsHuZ0qpPT(vcQbFfCk6T1,fzu7Got0FgiyshTlJK)
	elif VP70ytiFNMBl6vHDaW(u"ࠫࡆࡑࡗࡂࡏࠪࡩ")		in source and pp7FcjEe6g(u"࡚ࠬࡕࡃࡇࠪࡪ") not in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = iiy8cVF7db(vcQbFfCk6T1,G3Xh0YWACHFuvQLx5sVEfPjzq7,DIBw28Qfje76bTMzVNYhxrgWmO)
	elif A41nqbj3wYt(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ࡫")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = HvVudtEb6R(vcQbFfCk6T1)
	elif mq5t9JXSdHT8yfDVF(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ࡬")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = RDEvoJlsUX(vcQbFfCk6T1)
	elif jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ࡭")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = A41nqbj3wYt(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࡮"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	elif eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ࡯")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = dqwV0sDIuE(vcQbFfCk6T1)
	elif KLX7hW0nBAEgy6m4SvH(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ࡰ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = nMWqebA3wf(vcQbFfCk6T1)
	elif yobpaW7sBqtKRrv(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧࡱ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = nrd8U1RKu6(vcQbFfCk6T1)
	elif beV5l2D8HznyJI0(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨࡲ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = nnXWjdor7G(vcQbFfCk6T1)
	elif GHg28TBchiyn6l(u"ࠧࡔࡊࡒࡊࡍࡇࠧࡳ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = M6w2Wug34l(vcQbFfCk6T1,G3Xh0YWACHFuvQLx5sVEfPjzq7,MqXTicjeEC09zbKvdLxoWpm7aD)
	elif YYQS36fyPvtuzcEmRL(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪࡴ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = JdUBjazqsO(vcQbFfCk6T1,a8ViDmKTjhIEs4bnykRL)
	elif A6iX18qgyOFlZxz7sc(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩࡵ")		in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = b5GlsiO6d2(vcQbFfCk6T1)
	elif QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧࡶ")	in source: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = kpBgcTzUjY(vcQbFfCk6T1)
	elif QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ࡷ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = CJvZbAdIpH(vcQbFfCk6T1)
	elif KLX7hW0nBAEgy6m4SvH(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨࡸ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = HhTRf43jBE(vcQbFfCk6T1)
	elif YYQS36fyPvtuzcEmRL(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ࡹ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = fsI73o681PxA(vcQbFfCk6T1)
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩࡺ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = Ym6QVM1qai(vcQbFfCk6T1)
	elif rVy3Ops0mohYkT(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪࡻ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = Ym6QVM1qai(vcQbFfCk6T1)
	elif GHg28TBchiyn6l(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩࡼ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = KSvkoWfe9l(vcQbFfCk6T1)
	elif Z9FPQvwlbjLTh(u"ࠪࡸࡻ࡬ࡵ࡯ࠩࡽ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = akm7Olewy1(vcQbFfCk6T1)
	elif A41nqbj3wYt(u"ࠫࡹࡼ࡫ࡴࡣࠪࡾ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = akm7Olewy1(vcQbFfCk6T1)
	elif CyHU86ZeYT5BWRcitSm2I(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧࡿ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = akm7Olewy1(vcQbFfCk6T1)
	elif A6iX18qgyOFlZxz7sc(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨࢀ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = PnGsJw3SFB(vcQbFfCk6T1)
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩࢁ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = ifod8xX7ma(vcQbFfCk6T1)
	elif iySORMYxWXszEH18(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪࢂ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = ttcCbI5Sf0mDXdlOiKVFGeyZQ(vcQbFfCk6T1)
	elif YYQS36fyPvtuzcEmRL(u"ࠩࡹࡷ࠹ࡻࠧࢃ")			in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = G8EoMZwSa0(vcQbFfCk6T1)
	elif IMjqygdfYSKpHlWu5Aa(u"ࠪࡪࡦࡰࡥࡳࠩࢄ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = Y6gzSMvWmk(vcQbFfCk6T1)
	elif oiWNFYzcIUeh(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬࢅ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UhA459zcSm(vcQbFfCk6T1)
	elif lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ࢆ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UhA459zcSm(vcQbFfCk6T1)
	elif jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪࢇ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = w9rdylLDsa(vcQbFfCk6T1)
	elif beV5l2D8HznyJI0(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ࢈")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = w9rdylLDsa(vcQbFfCk6T1)
	elif VP70ytiFNMBl6vHDaW(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨࢉ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = NNaWlnOxMy(vcQbFfCk6T1)
	elif pp7FcjEe6g(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩࢊ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = qMdu6gXCnzcp9WhEUAJZ(vcQbFfCk6T1)
	elif yobpaW7sBqtKRrv(u"ࠪࡦࡴࡱࡲࡢࠩࢋ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = rqvKs7u3yN(vcQbFfCk6T1)
	elif KLX7hW0nBAEgy6m4SvH(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩࢌ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = tHfKLiFmz4(vcQbFfCk6T1)
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧࢍ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = DvjdSTt7qW(vcQbFfCk6T1)
	elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬࢎ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = CduqENMtf8(vcQbFfCk6T1)
	elif oiWNFYzcIUeh(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ࢏")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	elif eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ࢐")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = U7XDKi5njM(vcQbFfCk6T1)
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ࢑")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = vTi9bK5rJc(vcQbFfCk6T1)
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡹࡵࡨࡡ࡮ࠩ࢒") 		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	else: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = tzZ6PhyDOUnwLM3pdK(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࢓"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	if not QXqRvTME9DBPsVYmyecrxlI and not M0MFkiKqJDv1aZ4NA396u: QXqRvTME9DBPsVYmyecrxlI = SI7eBdND4lx8pt5Qk(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵ࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭࢔")
	elif QXqRvTME9DBPsVYmyecrxlI not in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࢕"),oiWNFYzcIUeh(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࢖")]: QXqRvTME9DBPsVYmyecrxlI = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫࢗ")+QXqRvTME9DBPsVYmyecrxlI
	return QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def ftj4JUeMASTO6m1RbL2GNPWQzpV(xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,url,source,vdRg23DAaJe8):
	global QZ24pVBJkqu1HDdh0Ez6ly3eI,p13pZTvCUm54cMjslubxBgy2,x2FDvJWULC1I8fwszGZ6btYlMoRKNX,wPdYgCc6RaqTQmABOS,PhNonirF9pDJ
	CbaPdVZcoQKeTvXtjW7 = []
	for rrXW3bUcnOYAlCi8J4uBH in [p13pZTvCUm54cMjslubxBgy2,x2FDvJWULC1I8fwszGZ6btYlMoRKNX,wPdYgCc6RaqTQmABOS,PhNonirF9pDJ]: rrXW3bUcnOYAlCi8J4uBH[vdRg23DAaJe8] = tzZ6PhyDOUnwLM3pdK(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ࢘"),[],[]
	DWpYqAXwGzeH,hh47rGRcXYVDp = [N4ZFei8pu7qaLyO,DH6IuCfKbX0hlnwL,qqaJnPodicfIMF6yU1tl,hP4Ikv0ola8iAM31u],[]
	if pp7FcjEe6g(u"ࠪࡪࡷࡪ࡬ࠨ࢙") in url: DWpYqAXwGzeH,hh47rGRcXYVDp = [N4ZFei8pu7qaLyO,DH6IuCfKbX0hlnwL,hP4Ikv0ola8iAM31u],[wPdYgCc6RaqTQmABOS]
	if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࢚ࠬ") in url: DWpYqAXwGzeH,hh47rGRcXYVDp = [N4ZFei8pu7qaLyO],[x2FDvJWULC1I8fwszGZ6btYlMoRKNX,wPdYgCc6RaqTQmABOS,PhNonirF9pDJ]
	for rrXW3bUcnOYAlCi8J4uBH in hh47rGRcXYVDp: rrXW3bUcnOYAlCi8J4uBH[vdRg23DAaJe8] = kdRO82AImh0LFw(u"࡙ࠬ࡫ࡪࡲࡳࡩࡩ࢛࠭"),[],[]
	for rrXW3bUcnOYAlCi8J4uBH in DWpYqAXwGzeH:
		wuNrDtFJqI74A61SbpkHehiP = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=rrXW3bUcnOYAlCi8J4uBH,args=(url,source,vdRg23DAaJe8))
		CbaPdVZcoQKeTvXtjW7.append(wuNrDtFJqI74A61SbpkHehiP)
	def KoCEJsLpjv5Hb6nPr4IyUD():
		XXmQ9VzZNOdG6Fh4r,pmUXZjOduFSIYRGsEh0ioJDkB,uvUbdzQR5GgTl,q5funQ21bL3BHIA = KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9
		bIM3AVgz6iB1Wcrfaj0D,title,SOw5EUxC9k = p13pZTvCUm54cMjslubxBgy2[vdRg23DAaJe8]
		if (SOw5EUxC9k and not bIM3AVgz6iB1Wcrfaj0D) or (bIM3AVgz6iB1Wcrfaj0D and bIM3AVgz6iB1Wcrfaj0D!=gPE1XB87fQl(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧ࢜")): XXmQ9VzZNOdG6Fh4r = r0D4C3z7Onqpa
		bIM3AVgz6iB1Wcrfaj0D,title,SOw5EUxC9k = x2FDvJWULC1I8fwszGZ6btYlMoRKNX[vdRg23DAaJe8]
		if (SOw5EUxC9k and not bIM3AVgz6iB1Wcrfaj0D) or (bIM3AVgz6iB1Wcrfaj0D and bIM3AVgz6iB1Wcrfaj0D!=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨ࢝")): pmUXZjOduFSIYRGsEh0ioJDkB = r0D4C3z7Onqpa
		bIM3AVgz6iB1Wcrfaj0D,title,SOw5EUxC9k = wPdYgCc6RaqTQmABOS[vdRg23DAaJe8]
		if (SOw5EUxC9k and not bIM3AVgz6iB1Wcrfaj0D) or (bIM3AVgz6iB1Wcrfaj0D and bIM3AVgz6iB1Wcrfaj0D!=GHg28TBchiyn6l(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ࢞")): uvUbdzQR5GgTl = r0D4C3z7Onqpa
		bIM3AVgz6iB1Wcrfaj0D,title,SOw5EUxC9k = PhNonirF9pDJ[vdRg23DAaJe8]
		if (SOw5EUxC9k and not bIM3AVgz6iB1Wcrfaj0D) or (bIM3AVgz6iB1Wcrfaj0D and bIM3AVgz6iB1Wcrfaj0D!=oiWNFYzcIUeh(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ࢟")): q5funQ21bL3BHIA = r0D4C3z7Onqpa
		NU1y0Bce2G7S = all([XXmQ9VzZNOdG6Fh4r,pmUXZjOduFSIYRGsEh0ioJDkB,uvUbdzQR5GgTl,q5funQ21bL3BHIA])
		iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying() if A3pXVFdyP1.resolveonly else r0D4C3z7Onqpa
		return NU1y0Bce2G7S or not iH7pE9rXVqy5k1Uu
	vGFdXD2x8ORu6aj(CbaPdVZcoQKeTvXtjW7,oJOHPhU8M7DyrYQGbfLVelsvW9X4q,kWE5274r1n,wnaWTQM7VJPkZzO9eoSyFU4,KoCEJsLpjv5Hb6nPr4IyUD)
	succeeded = tzZ6PhyDOUnwLM3pdK(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩࢠ")
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = p13pZTvCUm54cMjslubxBgy2[vdRg23DAaJe8]
	M0MFkiKqJDv1aZ4NA396u = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	if QXqRvTME9DBPsVYmyecrxlI==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢡ") or M0MFkiKqJDv1aZ4NA396u: return succeeded,QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs += A6iX18qgyOFlZxz7sc(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧࢢ")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[:I872Vum45fMNe1BRngTZLoQiqvkt(u"࠽࠶໥")]
	succeeded = I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬࢣ")
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = x2FDvJWULC1I8fwszGZ6btYlMoRKNX[vdRg23DAaJe8]
	M0MFkiKqJDv1aZ4NA396u = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	if QXqRvTME9DBPsVYmyecrxlI==ZLr5gRSkFewKdUos90bM(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢤ") or M0MFkiKqJDv1aZ4NA396u: return succeeded,QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs += jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠹࠺ࠡࠢࠪࢥ")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[:A41nqbj3wYt(u"࠾࠰໦")]
	succeeded = Z9FPQvwlbjLTh(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠴ࠨࢦ")
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = wPdYgCc6RaqTQmABOS[vdRg23DAaJe8]
	M0MFkiKqJDv1aZ4NA396u = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	if QXqRvTME9DBPsVYmyecrxlI==Z9FPQvwlbjLTh(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࢧ") or M0MFkiKqJDv1aZ4NA396u: return succeeded,QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs += aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠶࠽ࠤࠥ࠭ࢨ")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠸࠱໧")]
	succeeded = A41nqbj3wYt(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫࢩ")
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = PhNonirF9pDJ[vdRg23DAaJe8]
	M0MFkiKqJDv1aZ4NA396u = GDA2dLkKwEWuinCfmtI(M0MFkiKqJDv1aZ4NA396u)
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	if QXqRvTME9DBPsVYmyecrxlI==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢪ") or M0MFkiKqJDv1aZ4NA396u: return succeeded,QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs += VP70ytiFNMBl6vHDaW(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠺ࡀࠠࠡࠩࢫ")+QXqRvTME9DBPsVYmyecrxlI.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[:A41nqbj3wYt(u"࠹࠲໨")]
	QZ24pVBJkqu1HDdh0Ez6ly3eI[vdRg23DAaJe8] = xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	return succeeded,xFU4OvmwWy2fGVPKzt6a0pAdYuBCRs,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def N4ZFei8pu7qaLyO(url,source,vdRg23DAaJe8):
	vcQbFfCk6T1,MqXTicjeEC09zbKvdLxoWpm7aD,VVpQfHc7IZamxweON3WXKU6Fg,i0UCZG1a23QNItMVsz5dryFvDunoT,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,a8ViDmKTjhIEs4bnykRL = yyWdhEaDkfZm(url,source)
	M0MFkiKqJDv1aZ4NA396u = []
	if kdRO82AImh0LFw(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ࢬ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = tHfKLiFmz4(url)
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨࢭ") in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = xfRyL3PFIiCvHe0mJ(url)
	elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡽࡴࡻࡴࡶࠩࢮ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = wt1ioc4DP2GHQkNjhRFZ(url)
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫࢯ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = wt1ioc4DP2GHQkNjhRFZ(url)
	elif Z9FPQvwlbjLTh(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫࢰ")	in url   : QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = XQ4zcbSJRymsi2(url)
	elif wwWzyF4ZpSQXKOgk569(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨࢱ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = F4FYl2H3Op(url)
	elif kdRO82AImh0LFw(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨࢲ")		in url   : QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = HvVudtEb6R(url)
	elif wwWzyF4ZpSQXKOgk569(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫࢳ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = Z1dYgENA4UKcp2DOTPaCRm78HJ35(url)
	elif pp7FcjEe6g(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪࢴ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = C0XuBqjF7mo3slfENptY6WP9yw(url)
	elif GHg28TBchiyn6l(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫࢵ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = JbmlH1P74zejvB(url)
	elif A6iX18qgyOFlZxz7sc(u"ࠫࡪ࠻ࡴࡴࡣࡵࠫࢶ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = E9ihJtvlVR1DP(url)
	elif VP70ytiFNMBl6vHDaW(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫࢷ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = t49oamAgUkJGKvI2Y(url)
	elif A41nqbj3wYt(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩࢸ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = t49oamAgUkJGKvI2Y(url)
	elif A41nqbj3wYt(u"ࠧࡶࡲࡥࡥࡲ࠭ࢹ") 		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	elif eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪࢺ") 	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = KT7sdi3LQnh56FIvlUbS(url)
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬࢻ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = rs5BfXwCFgGt17IdJ3EVlhaRp(url)
	elif iySORMYxWXszEH18(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧࢼ") 	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = ZkQeJBd7CFf(url)
	elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬࢽ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = jwGLCdfPAmn1EhBoOJUktl9vgS6xi(url)
	elif lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡻࡰࡣࠩࢾ") 			in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UefPNgnro8DbIjES(url)
	elif VP70ytiFNMBl6vHDaW(u"࠭ࡵࡱࡲࠪࢿ") 			in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UefPNgnro8DbIjES(url)
	elif oiWNFYzcIUeh(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧࣀ") 		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = nCBD8P510pXuZtV4I(url)
	elif KLX7hW0nBAEgy6m4SvH(u"ࠨࡸ࡮ࠫࣁ")	 		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = nCiMvWxNhKz9823XAgoU(vcQbFfCk6T1)
	elif bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫࣂ") 	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = avQr4qwgmhzibOentMj(url)
	elif ZLr5gRSkFewKdUos90bM(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪࣃ")		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = PME0cJ1hnz5dT(url)
	elif yobpaW7sBqtKRrv(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫࣄ") 		in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = bbpG2X5HlIyYuj4DdZMNiQrtJn(url)
	elif Z9FPQvwlbjLTh(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩࣅ") 	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = JJ4vVR2mzbLj(url)
	elif Z9FPQvwlbjLTh(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪࣆ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = HIZORMPdctxfzj8i20G7(url)
	elif oiWNFYzcIUeh(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫࣇ")	in VVpQfHc7IZamxweON3WXKU6Fg: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = gWDR5iyrvY6tk173VAXFIuTZ(url)
	else: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	global p13pZTvCUm54cMjslubxBgy2
	if not QXqRvTME9DBPsVYmyecrxlI and not M0MFkiKqJDv1aZ4NA396u: QXqRvTME9DBPsVYmyecrxlI = beV5l2D8HznyJI0(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲ࠡࡈࡤ࡭ࡱࡻࡲࡦࠩࣈ")
	elif QXqRvTME9DBPsVYmyecrxlI not in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣉ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࣊")]: QXqRvTME9DBPsVYmyecrxlI = oiWNFYzcIUeh(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ࣋")+QXqRvTME9DBPsVYmyecrxlI
	p13pZTvCUm54cMjslubxBgy2[vdRg23DAaJe8] = QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	return
def DH6IuCfKbX0hlnwL(url,source,vdRg23DAaJe8):
	global x2FDvJWULC1I8fwszGZ6btYlMoRKNX
	if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭࣌") in url:
		x2FDvJWULC1I8fwszGZ6btYlMoRKNX[vdRg23DAaJe8] = pp7FcjEe6g(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡕ࡮࡭ࡵࡶࡥࡥࠩ࣍"),[],[]
		return
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	if mm19wY7OfIvCxb8AFZEHJ(url):
		QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	if not M0MFkiKqJDv1aZ4NA396u:
		QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = z7tnp45QC0RwmqGVBkfUWb8YSvo(url)
	if not M0MFkiKqJDv1aZ4NA396u:
		QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = LLKjeCGcyAMHwdgokbZ2l6qfvYU(url)
	if not M0MFkiKqJDv1aZ4NA396u:
		if QXqRvTME9DBPsVYmyecrxlI==YYQS36fyPvtuzcEmRL(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࣎"): QXqRvTME9DBPsVYmyecrxlI = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		QXqRvTME9DBPsVYmyecrxlI = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻࣏ࠢࠣࠫ")+QXqRvTME9DBPsVYmyecrxlI if QXqRvTME9DBPsVYmyecrxlI else eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴ࠢࡉࡥ࡮ࡲࡵࡳࡧ࣐ࠪ")
	x2FDvJWULC1I8fwszGZ6btYlMoRKNX[vdRg23DAaJe8] = QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	return
def qqaJnPodicfIMF6yU1tl(url,source,vdRg23DAaJe8):
	C2nN35DILUFzEKqv0BPl4eZjH6 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	APpdhB1Fk58MmJH7CjVntowyaY = KiryBCvngZzF85UN6xSDlOVweL4I9
	try:
		import resolveurl as An4x23HlIEU86
		APpdhB1Fk58MmJH7CjVntowyaY = An4x23HlIEU86.resolve(url)
	except Exception as bIM3AVgz6iB1Wcrfaj0D: C2nN35DILUFzEKqv0BPl4eZjH6 = str(bIM3AVgz6iB1Wcrfaj0D)
	global wPdYgCc6RaqTQmABOS
	if not APpdhB1Fk58MmJH7CjVntowyaY:
		if C2nN35DILUFzEKqv0BPl4eZjH6==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
			if C2nN35DILUFzEKqv0BPl4eZjH6!=yobpaW7sBqtKRrv(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࣑࠭"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
		QXqRvTME9DBPsVYmyecrxlI = C2nN35DILUFzEKqv0BPl4eZjH6.splitlines()[-wnaWTQM7VJPkZzO9eoSyFU4]
		wPdYgCc6RaqTQmABOS[vdRg23DAaJe8] = tzZ6PhyDOUnwLM3pdK(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾࣒ࠥࠦࠧ")+QXqRvTME9DBPsVYmyecrxlI,[],[]
		return
	wPdYgCc6RaqTQmABOS[vdRg23DAaJe8] = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[APpdhB1Fk58MmJH7CjVntowyaY]
	return
def hP4Ikv0ola8iAM31u(url,source,vdRg23DAaJe8):
	C2nN35DILUFzEKqv0BPl4eZjH6 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	APpdhB1Fk58MmJH7CjVntowyaY = KiryBCvngZzF85UN6xSDlOVweL4I9
	try:
		import yt_dlp as wZg1BjlKfc90
		PgRrL6dn89pmjU1TGINS4XtAcQBvkV = wZg1BjlKfc90.YoutubeDL({QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸ࣓ࠧ"): r0D4C3z7Onqpa})
		APpdhB1Fk58MmJH7CjVntowyaY = PgRrL6dn89pmjU1TGINS4XtAcQBvkV.extract_info(url,download=KiryBCvngZzF85UN6xSDlOVweL4I9)
	except Exception as bIM3AVgz6iB1Wcrfaj0D: C2nN35DILUFzEKqv0BPl4eZjH6 = str(bIM3AVgz6iB1Wcrfaj0D)
	global PhNonirF9pDJ
	if not APpdhB1Fk58MmJH7CjVntowyaY or eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧࣔ") not in list(APpdhB1Fk58MmJH7CjVntowyaY.keys()):
		if C2nN35DILUFzEKqv0BPl4eZjH6==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
			if C2nN35DILUFzEKqv0BPl4eZjH6!=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪࣕ"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
		QXqRvTME9DBPsVYmyecrxlI = C2nN35DILUFzEKqv0BPl4eZjH6.splitlines()[-wnaWTQM7VJPkZzO9eoSyFU4]
		PhNonirF9pDJ[vdRg23DAaJe8] = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫࣖ")+QXqRvTME9DBPsVYmyecrxlI,[],[]
	else:
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
		for SOw5EUxC9k in APpdhB1Fk58MmJH7CjVntowyaY[yobpaW7sBqtKRrv(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪࣗ")]:
			ZD0qItXg31HmC7KGEFn.append(SOw5EUxC9k[yobpaW7sBqtKRrv(u"ࠪࡪࡴࡸ࡭ࡢࡶࠪࣘ")])
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k[A41nqbj3wYt(u"ࠫࡺࡸ࡬ࠨࣙ")])
		PhNonirF9pDJ[vdRg23DAaJe8] = WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	return
def z7tnp45QC0RwmqGVBkfUWb8YSvo(url,headers=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not headers:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,beV5l2D8HznyJI0(u"ࠬࡍࡅࡕࠩࣚ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡉࡉࡏࡒࡆࡅࡗࡣ࡚ࡘࡌ࠮࠳ࡶࡸࠬࣛ"))
		headers = WadGEeh1MBIXkpfP38qAv7ryslY.headers
	SOw5EUxC9k = headers.get(pp7FcjEe6g(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࣜ")) or headers.get(A6iX18qgyOFlZxz7sc(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪࣝ")) or WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if SOw5EUxC9k and mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k): return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return VP70ytiFNMBl6vHDaW(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬࣞ"),[],[]
def GDA2dLkKwEWuinCfmtI(EHhzCdkcwuvfWP):
	if isinstance(EHhzCdkcwuvfWP,list):
		laAHpo1bzyM0q = []
		for SOw5EUxC9k in EHhzCdkcwuvfWP:
			if isinstance(SOw5EUxC9k,str): SOw5EUxC9k = SOw5EUxC9k.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			laAHpo1bzyM0q.append(SOw5EUxC9k)
	else: laAHpo1bzyM0q = EHhzCdkcwuvfWP.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
	return laAHpo1bzyM0q
def UrwYehOQZVG4koguAaJzW10lC(CZ3H7wEGYM9uDFl5JIm4dgP0Tx,source):
	data = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡰ࡮ࡹࡴࠨࣟ"),gPE1XB87fQl(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ࣠"),CZ3H7wEGYM9uDFl5JIm4dgP0Tx)
	if data:
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = zip(*data)
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = list(ZD0qItXg31HmC7KGEFn),list(M0MFkiKqJDv1aZ4NA396u)
		return ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,exP4lO3qkGhDJ2V = [],[],[]
	for SOw5EUxC9k in CZ3H7wEGYM9uDFl5JIm4dgP0Tx:
		if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࠵࠯ࠨ࣡") not in SOw5EUxC9k: continue
		u9d3IanPEV4f,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO = nFtwAhVXdHOKZsuk(SOw5EUxC9k,source)
		DIBw28Qfje76bTMzVNYhxrgWmO = p7dwlH1PRStBgyMUW.findall(A6iX18qgyOFlZxz7sc(u"࠭࡜ࡥ࠭ࠪ࣢"),DIBw28Qfje76bTMzVNYhxrgWmO,p7dwlH1PRStBgyMUW.DOTALL)
		if DIBw28Qfje76bTMzVNYhxrgWmO: DIBw28Qfje76bTMzVNYhxrgWmO = int(DIBw28Qfje76bTMzVNYhxrgWmO[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		else: DIBw28Qfje76bTMzVNYhxrgWmO = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,A41nqbj3wYt(u"ࠧ࡯ࡣࡰࡩࣣࠬ"))
		exP4lO3qkGhDJ2V.append([u9d3IanPEV4f,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,SOw5EUxC9k,VVpQfHc7IZamxweON3WXKU6Fg])
	if exP4lO3qkGhDJ2V:
		UC5GbrkYBeIv9gmw = sorted(exP4lO3qkGhDJ2V,reverse=r0D4C3z7Onqpa,key=lambda key: (key[yGLl1nSBrJPmi2adko9O],key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],key[vXIdY7TwFKso40gVBq5],key[XURrDCfOS9Mbhpv2Pmjos56TeW],key[wnaWTQM7VJPkZzO9eoSyFU4],key[I872Vum45fMNe1BRngTZLoQiqvkt(u"࠷໩")],key[iySORMYxWXszEH18(u"࠹໪")]))
		kKibU78Vp1CHjft3I,GJnrKUuZkemlBg7v1qMpYcFah9 = [],[]
		for AuNfQI1cKXGdWoU in UC5GbrkYBeIv9gmw:
			u9d3IanPEV4f,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,SOw5EUxC9k,VVpQfHc7IZamxweON3WXKU6Fg = AuNfQI1cKXGdWoU
			if oiWNFYzcIUeh(u"ࠨ็ไฺ้࠭ࣤ") in G3Xh0YWACHFuvQLx5sVEfPjzq7:
				GJnrKUuZkemlBg7v1qMpYcFah9.append(AuNfQI1cKXGdWoU)
				continue
			if AuNfQI1cKXGdWoU not in kKibU78Vp1CHjft3I: kKibU78Vp1CHjft3I.append(AuNfQI1cKXGdWoU)
		kKibU78Vp1CHjft3I = GJnrKUuZkemlBg7v1qMpYcFah9+kKibU78Vp1CHjft3I
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		for u9d3IanPEV4f,fzu7Got0FgiyshTlJK,G3Xh0YWACHFuvQLx5sVEfPjzq7,P4cqC2X0dpeHbg3KW,DIBw28Qfje76bTMzVNYhxrgWmO,SOw5EUxC9k,VVpQfHc7IZamxweON3WXKU6Fg in kKibU78Vp1CHjft3I:
			DIBw28Qfje76bTMzVNYhxrgWmO = str(DIBw28Qfje76bTMzVNYhxrgWmO) if DIBw28Qfje76bTMzVNYhxrgWmO else WnNGfosHr5STAq8j7miwyRZ6eOUbV
			title = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩึ๎ึ็ัࠨࣥ")+kcXMWrwiLDKeBHRsJ+G3Xh0YWACHFuvQLx5sVEfPjzq7+kcXMWrwiLDKeBHRsJ+u9d3IanPEV4f+kcXMWrwiLDKeBHRsJ+DIBw28Qfje76bTMzVNYhxrgWmO+kcXMWrwiLDKeBHRsJ+P4cqC2X0dpeHbg3KW+kcXMWrwiLDKeBHRsJ+fzu7Got0FgiyshTlJK
			if VVpQfHc7IZamxweON3WXKU6Fg.lower() not in title.lower(): title = title+kcXMWrwiLDKeBHRsJ+VVpQfHc7IZamxweON3WXKU6Fg
			title = title.replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࣦࠪࠩࠬ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
			L3LoVh5B7OZMbHJlPXQ6EjnaUks += wnaWTQM7VJPkZzO9eoSyFU4
			title = str(L3LoVh5B7OZMbHJlPXQ6EjnaUks)+oiWNFYzcIUeh(u"ࠫ࠳ࠦࠧࣧ")+title
			if SOw5EUxC9k not in M0MFkiKqJDv1aZ4NA396u:
				ZD0qItXg31HmC7KGEFn.append(title)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		if M0MFkiKqJDv1aZ4NA396u:
			data = list(zip(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u))
			if data: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,bawK2j7T81Nrc4GWs05xzDg(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭ࣨ"),CZ3H7wEGYM9uDFl5JIm4dgP0Tx,data,oldym5kX8IqLSVDtpNMw)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = list(ZD0qItXg31HmC7KGEFn),list(M0MFkiKqJDv1aZ4NA396u)
	return ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def wQI87W2sU1ckAEYi(url):
	QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	if beV5l2D8HznyJI0(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࣩࠪ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,pp7FcjEe6g(u"ࠧࡈࡇࡗࠫ࣪"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡒࡂࡂࡒࡏࡅ࡞ࡋࡒ࠮࠳ࡶࡸࠬ࣫"))
		SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.url
		if SOw5EUxC9k: QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡶࡩࡷࡼ࠽ࠨ࣬") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,IMjqygdfYSKpHlWu5Aa(u"ࠪࡋࡊ࡚࣭ࠧ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡎࡅࡅࡕࡒࡁ࡚ࡇࡕ࠱࠷ࡴࡤࠨ࣮"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ࣯ࠫࠥࠫ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k: url = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else:
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡁ࡭ࡤࡤࡔࡱࡧࡹࡦࡴࡆࡳࡳࡺࡲࡰ࡮࡟ࠬࠬ࠮࠮ࠫࡁࣰࠬࠫࠧ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k:
				url = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				url = uvGCPpFwVmTQ36.b64decode(url)
				if rJ2oTLqabRtA: url = url.decode(e87cIA5vwOQLDEP1)
			else: return I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗࣱ࠭"),[],[]
		QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = rVy3Ops0mohYkT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࣲࠫ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	return QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN
def vA4LkIGtNE(url,G3Xh0YWACHFuvQLx5sVEfPjzq7,MqXTicjeEC09zbKvdLxoWpm7aD):
	if YYQS36fyPvtuzcEmRL(u"ࠩࡴࡺ࡮ࡪࠧࣳ") in url:
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = RRcaqDwHJOvGYAeL7n38(url,G3Xh0YWACHFuvQLx5sVEfPjzq7,MqXTicjeEC09zbKvdLxoWpm7aD)
		if M0MFkiKqJDv1aZ4NA396u: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
		return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡌࡎࡕࡗࡆࡆ࠭ࣴ"),[],[]
	return SI7eBdND4lx8pt5Qk(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣵ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def fsI73o681PxA(url):
	if yobpaW7sBqtKRrv(u"ࠬ࠴࡭࠴ࡷ࠻ࣶࠫ") in url:
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,url)
		if M0MFkiKqJDv1aZ4NA396u: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
		return XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࠶࡙࠽࠭ࣷ"),[],[]
	return I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣸ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def CJvZbAdIpH(url):
	wxT9bCdumN,pixfvyGY1aJPowKZer34TcNblL7k2 = [],[]
	if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴ࠰ࡰࡴ࠹ࡅࡶࡪࡦࡀࣹࠫ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡊࡉ࡙ࣺ࠭"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠳ࡶࡸࠬࣻ"))
		if YYQS36fyPvtuzcEmRL(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࣼ") in WadGEeh1MBIXkpfP38qAv7ryslY.headers:
			SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[rVy3Ops0mohYkT(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࣽ")]
			wxT9bCdumN.append(SOw5EUxC9k)
			VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,A41nqbj3wYt(u"࠭࡮ࡢ࡯ࡨࠫࣾ"))
			pixfvyGY1aJPowKZer34TcNblL7k2.append(VVpQfHc7IZamxweON3WXKU6Fg)
	elif beV5l2D8HznyJI0(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦ࠰ࡦࡳࡲ࠭ࣿ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,CyHU86ZeYT5BWRcitSm2I(u"ࠨࡉࡈࡘࠬऀ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠳ࡰࡧࠫँ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		llrcXE8g1yqbvQ = p7dwlH1PRStBgyMUW.findall(oiWNFYzcIUeh(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࡧࡠ࠮࠴ࠪࡀ࡞ࠬࡠ࠮࠯࠮࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪं"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if llrcXE8g1yqbvQ:
			llrcXE8g1yqbvQ = llrcXE8g1yqbvQ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			cNhzkJn693rIOf51WvDBAyZVEoR = A1FcQEJDZe9zub2MCtfY4XnLo(llrcXE8g1yqbvQ)
			mINB6gjDpFxM4OPE3057Tu91zqSa = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࡜࡜࠰࠭ࡃࡡࡣࠩ࠭ࠩः"),cNhzkJn693rIOf51WvDBAyZVEoR,p7dwlH1PRStBgyMUW.DOTALL)
			if mINB6gjDpFxM4OPE3057Tu91zqSa:
				mINB6gjDpFxM4OPE3057Tu91zqSa = mINB6gjDpFxM4OPE3057Tu91zqSa[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				mINB6gjDpFxM4OPE3057Tu91zqSa = IXZpzK7ShaRsAN(Z9FPQvwlbjLTh(u"ࠬࡲࡩࡴࡶࠪऄ"),mINB6gjDpFxM4OPE3057Tu91zqSa)
				for dict in mINB6gjDpFxM4OPE3057Tu91zqSa:
					SOw5EUxC9k = dict[YYQS36fyPvtuzcEmRL(u"࠭ࡦࡪ࡮ࡨࠫअ")]
					DIBw28Qfje76bTMzVNYhxrgWmO = dict[gPE1XB87fQl(u"ࠧ࡭ࡣࡥࡩࡱ࠭आ")]
					wxT9bCdumN.append(SOw5EUxC9k)
					VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡰࡤࡱࡪ࠭इ"))
					pixfvyGY1aJPowKZer34TcNblL7k2.append(DIBw28Qfje76bTMzVNYhxrgWmO+kcXMWrwiLDKeBHRsJ+VVpQfHc7IZamxweON3WXKU6Fg)
		elif rVy3Ops0mohYkT(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫई") in WadGEeh1MBIXkpfP38qAv7ryslY.headers:
			SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[pp7FcjEe6g(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬउ")]
			wxT9bCdumN.append(SOw5EUxC9k)
			VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡳࡧ࡭ࡦࠩऊ"))
			pixfvyGY1aJPowKZer34TcNblL7k2.append(VVpQfHc7IZamxweON3WXKU6Fg)
		if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡅࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࡲࡳࠬऋ") in url:
			SOw5EUxC9k = url.split(KLX7hW0nBAEgy6m4SvH(u"࠭࠿ࡶࡴ࡯ࡁࠬऌ"))[wnaWTQM7VJPkZzO9eoSyFU4]
			SOw5EUxC9k = SOw5EUxC9k.split(SI7eBdND4lx8pt5Qk(u"ࠧࠧࠩऍ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			if SOw5EUxC9k:
				wxT9bCdumN.append(SOw5EUxC9k)
				pixfvyGY1aJPowKZer34TcNblL7k2.append(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡲ࡫ࡳࡹࡵࡳࠡࡩࡲࡳ࡬ࡲࡥࠨऎ"))
	else:
		wxT9bCdumN.append(url)
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡱࡥࡲ࡫ࠧए"))
		pixfvyGY1aJPowKZer34TcNblL7k2.append(VVpQfHc7IZamxweON3WXKU6Fg)
	if not wxT9bCdumN: return CyHU86ZeYT5BWRcitSm2I(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡑࡁࡕࡍࡒ࡙࡙ࡋࠧऐ"),[],[]
	elif len(wxT9bCdumN)==wnaWTQM7VJPkZzO9eoSyFU4: SOw5EUxC9k = wxT9bCdumN[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else:
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩऑ"),pixfvyGY1aJPowKZer34TcNblL7k2)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪऒ"),[],[]
		SOw5EUxC9k = wxT9bCdumN[XFaM94cPUCOWQZNIEe8gdJpny1]
	return iySORMYxWXszEH18(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩओ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def xfRyL3PFIiCvHe0mJ(url):
	headers = {wwWzyF4ZpSQXKOgk569(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫऔ"):XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡍࡲࡨ࡮࠵ࠧक")+str(CCPXJ7wnNLOg0ZoekcmpdSKI)}
	for zuEo6GDeAR5Z in range(mq5t9JXSdHT8yfDVF(u"࠹࠵໫")):
		x54xSdnCFHZ8yliofzOBK.sleep(kWE5274r1n)
		WadGEeh1MBIXkpfP38qAv7ryslY = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(kdRO82AImh0LFw(u"ࠩࡊࡉ࡙࠭ख"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧग"))
		if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭घ") in list(WadGEeh1MBIXkpfP38qAv7ryslY.headers.keys()):
			SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[beV5l2D8HznyJI0(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧङ")]
			SOw5EUxC9k = SOw5EUxC9k+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬच")+headers[SI7eBdND4lx8pt5Qk(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫछ")]
			return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
		if WadGEeh1MBIXkpfP38qAv7ryslY.code!=n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠹࠸࠹໬"): break
	return jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚ࠧज"),[],[]
def XQ4zcbSJRymsi2(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,SI7eBdND4lx8pt5Qk(u"ࠩࡊࡉ࡙࠭झ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩञ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨट"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[DIBw28Qfje76bTMzVNYhxrgWmO],[SOw5EUxC9k]
	return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠭ठ"),[],[]
def ZieJc3z9E2(url):
	if bawK2j7T81Nrc4GWs05xzDg(u"࠭࠯ࡸࡧࡨࡴ࡮ࡹ࠯ࠨड") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡈࡇࡗࠫढ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠶࠲࠷ࡳࡵࠩण"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡶࡻࡡ࡭࡫ࡷࡽࡃ࠭त"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k: url = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡅࡄࡋࡐࡅ࠷࠭थ"),[],[]
	return tzZ6PhyDOUnwLM3pdK(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧद"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def HvVudtEb6R(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,iySORMYxWXszEH18(u"ࠬࡍࡅࡕࠩध"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨन"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	piN9Qlah4S = FXeb4fwkiRO9v63yNQ5du(piN9Qlah4S)
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऩ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	return tzZ6PhyDOUnwLM3pdK(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬप"),[],[]
def RDEvoJlsUX(url):
	if IMjqygdfYSKpHlWu5Aa(u"ࠩࡂ࡭ࡩࡃࠧफ") in url:
		headers = {IMjqygdfYSKpHlWu5Aa(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩब"):tzZ6PhyDOUnwLM3pdK(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫभ")}
		url,data = url.rsplit(iySORMYxWXszEH18(u"ࠬࡅࠧम"),IMjqygdfYSKpHlWu5Aa(u"࠷໭"))
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,Z9FPQvwlbjLTh(u"࠭ࡐࡐࡕࡗࠫय"),url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲࠷ࡳࡵࠩर"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧऱ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k: url = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: return I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠷࠭ल"),[],[]
	return gPE1XB87fQl(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ळ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def b5GlsiO6d2(url):
	if len(url)>bawK2j7T81Nrc4GWs05xzDg(u"࠲࠱࠲໮"):
		url = url.strip(mq5t9JXSdHT8yfDVF(u"ࠫ࠴࠭ऴ"))+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࠵ࠧव")
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,ZLr5gRSkFewKdUos90bM(u"࠭ࡇࡆࡖࠪश"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡆࡘࡏ࡛ࡃ࠰࠵ࡸࡺࠧष"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and ZLr5gRSkFewKdUos90bM(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩस") in piN9Qlah4S:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(gPE1XB87fQl(u"ࠩࠥࡰࡴࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨह"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if cKUQVwTMe9tZSY:
				KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠪࡀࡸࡩࡲࡪࡲࡷࡂࡻࡧࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺࠧऺ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				if cKUQVwTMe9tZSY:
					KDCdHQmgxPE21tYz4VUowSv = z3o4DEbwAJBUa(cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		elif len(piN9Qlah4S)<tzZ6PhyDOUnwLM3pdK(u"࠵࠲࠳໯"): SOw5EUxC9k = piN9Qlah4S
		else: return ZLr5gRSkFewKdUos90bM(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡂࡔࡒ࡞ࡆ࠭ऻ"),[],[]
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return pp7FcjEe6g(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ़"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def M6w2Wug34l(url,G3Xh0YWACHFuvQLx5sVEfPjzq7,MqXTicjeEC09zbKvdLxoWpm7aD):
	if Z9FPQvwlbjLTh(u"࠭࠯ࡥࡱࡺࡲ࠳ࡶࡨࡱࠩऽ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,A41nqbj3wYt(u"ࠧࡈࡇࡗࠫा"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡇࡊࡄ࠱࠶ࡹࡴࠨि"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡹࡵࡥࡵࡶࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪी"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		url = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return CyHU86ZeYT5BWRcitSm2I(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ु"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def dqwV0sDIuE(url):
	if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨू") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,SI7eBdND4lx8pt5Qk(u"ࠬࡍࡅࡕࠩृ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭ॄ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॅ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if mq5t9JXSdHT8yfDVF(u"ࠨࡪࡷࡸࡵ࠭ॆ") in SOw5EUxC9k: return beV5l2D8HznyJI0(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬे"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
		return aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙ࠬै"),[],[]
	return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧॉ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def KSvkoWfe9l(url):
	vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
	W67hPCcaOek094 = {ZLr5gRSkFewKdUos90bM(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨॊ"):mq5t9JXSdHT8yfDVF(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧो"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ौ"):SI7eBdND4lx8pt5Qk(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ्")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,A41nqbj3wYt(u"ࠩࡓࡓࡘ࡚ࠧॎ"),vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪॏ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॐ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: return A6iX18qgyOFlZxz7sc(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ॑"),[],[]
	SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return mq5t9JXSdHT8yfDVF(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ॒ࠩ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def ifod8xX7ma(url):
	headers = {gPE1XB87fQl(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ॓"):I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ॔")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,beV5l2D8HznyJI0(u"ࠩࡊࡉ࡙࠭ॕ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸࠬॖ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(pp7FcjEe6g(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॗ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	if not SOw5EUxC9k: return wwWzyF4ZpSQXKOgk569(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐࠩक़"),[],[]
	SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return YYQS36fyPvtuzcEmRL(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩख़"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def PnGsJw3SFB(url):
	vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
	W67hPCcaOek094 = {lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ग़"):KLX7hW0nBAEgy6m4SvH(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨज़")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,wwWzyF4ZpSQXKOgk569(u"ࠩࡓࡓࡘ࡚ࠧड़"),vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬढ़"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭फ़"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	if not SOw5EUxC9k: return A41nqbj3wYt(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩय़"),[],[]
	SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if pp7FcjEe6g(u"࠭ࡨࡵࡶࡳࠫॠ") not in SOw5EUxC9k: SOw5EUxC9k = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡩࡶࡷࡴ࠿࠭ॡ")+SOw5EUxC9k
	return rVy3Ops0mohYkT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫॢ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def nnXWjdor7G(url):
	ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = url,[],[]
	if iySORMYxWXszEH18(u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࠩॣ") in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ।"):bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ॥")}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,VP70ytiFNMBl6vHDaW(u"ࠬࡖࡏࡔࡖࠪ०"),vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨ१"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		tKf5NLDXilz9MFGa3YJmUWwsu = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫ२"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if tKf5NLDXilz9MFGa3YJmUWwsu: ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = tKf5NLDXilz9MFGa3YJmUWwsu[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ३"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr]
def akm7Olewy1(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,tzZ6PhyDOUnwLM3pdK(u"ࠩࡊࡉ࡙࠭४"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ५"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ZU85vflDYNAzWexn1tjXVrwORcbE = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ६"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	if ZU85vflDYNAzWexn1tjXVrwORcbE:
		ZU85vflDYNAzWexn1tjXVrwORcbE = ZU85vflDYNAzWexn1tjXVrwORcbE[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][YYQS36fyPvtuzcEmRL(u"࠴໰"):]
		ZU85vflDYNAzWexn1tjXVrwORcbE = uvGCPpFwVmTQ36.b64decode(ZU85vflDYNAzWexn1tjXVrwORcbE)
		if rJ2oTLqabRtA: ZU85vflDYNAzWexn1tjXVrwORcbE = ZU85vflDYNAzWexn1tjXVrwORcbE.decode(e87cIA5vwOQLDEP1)
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ७"),ZU85vflDYNAzWexn1tjXVrwORcbE,p7dwlH1PRStBgyMUW.DOTALL)
	else: SOw5EUxC9k = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if not SOw5EUxC9k: return jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ८"),[],[]
	SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡩࡶࡷࡴࠬ९") not in SOw5EUxC9k: SOw5EUxC9k = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡪࡷࡸࡵࡀࠧ॰")+SOw5EUxC9k
	return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॱ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def ttcCbI5Sf0mDXdlOiKVFGeyZQ(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡋࡊ࡚ࠧॲ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭ॳ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॴ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: return Z9FPQvwlbjLTh(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪॵ"),[],[]
	SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪॶ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def tHfKLiFmz4(url):
	id = url.split(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ࠱ࠪॷ"))[-CyHU86ZeYT5BWRcitSm2I(u"࠴໱")]
	if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩॸ") in url: url = url.replace(IMjqygdfYSKpHlWu5Aa(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪॹ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	url = url.replace(ZLr5gRSkFewKdUos90bM(u"ࠫ࠳ࡩ࡯࡮࠱ࠪॺ"),beV5l2D8HznyJI0(u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭ॻ"))
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,beV5l2D8HznyJI0(u"࠭ࡇࡆࡖࠪॼ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬॽ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	QXqRvTME9DBPsVYmyecrxlI = VP70ytiFNMBl6vHDaW(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨॾ")
	bIM3AVgz6iB1Wcrfaj0D = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪॿ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if bIM3AVgz6iB1Wcrfaj0D: QXqRvTME9DBPsVYmyecrxlI = bIM3AVgz6iB1Wcrfaj0D[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	url = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧঀ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not url and QXqRvTME9DBPsVYmyecrxlI:
		return QXqRvTME9DBPsVYmyecrxlI,[],[]
	SOw5EUxC9k = url[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡡࡢࠧঁ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	OL7ND5xIzt36lV4oAyrkQJqUR,CZ3H7wEGYM9uDFl5JIm4dgP0Tx = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,SOw5EUxC9k)
	IISWAzUg18xVsPiNykMh2ce4JXEKZY = G3yDpvxOiSWdAeL.getSetting(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩং"))
	if IISWAzUg18xVsPiNykMh2ce4JXEKZY and yobpaW7sBqtKRrv(u"࠭࠭ࠨঃ") not in IISWAzUg18xVsPiNykMh2ce4JXEKZY: title,SOw5EUxC9k = OL7ND5xIzt36lV4oAyrkQJqUR[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],CZ3H7wEGYM9uDFl5JIm4dgP0Tx[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else:
		vtU5aCzrXH6o0k21s = p7dwlH1PRStBgyMUW.findall(A6iX18qgyOFlZxz7sc(u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻࡞ࡾࠦ࡮ࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ঄"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if vtU5aCzrXH6o0k21s: OfxwEUhpW1ZngBMAsFPGrXNm,K1lPLX4fCOG,RiDsGTEw89ckYnbjF4N0QAXorBIPl = vtU5aCzrXH6o0k21s[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: OfxwEUhpW1ZngBMAsFPGrXNm,K1lPLX4fCOG,RiDsGTEw89ckYnbjF4N0QAXorBIPl = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		RiDsGTEw89ckYnbjF4N0QAXorBIPl = RiDsGTEw89ckYnbjF4N0QAXorBIPl.replace(oiWNFYzcIUeh(u"ࠨ࡞࠲ࠫঅ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩ࠲ࠫআ"))
		K1lPLX4fCOG = clFjTSgMODe7Nq0H3Vzs(K1lPLX4fCOG)
		ZD0qItXg31HmC7KGEFn = [e6HEdvUcaq8Gx+CyHU86ZeYT5BWRcitSm2I(u"ࠪࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬই")+K1lPLX4fCOG+YVr6St5P4xsFC0aARQGKfiegD]+OL7ND5xIzt36lV4oAyrkQJqUR
		M0MFkiKqJDv1aZ4NA396u = [RiDsGTEw89ckYnbjF4N0QAXorBIPl]+CZ3H7wEGYM9uDFl5JIm4dgP0Tx
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(SI7eBdND4lx8pt5Qk(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬঈ")+str(len(M0MFkiKqJDv1aZ4NA396u)-gPE1XB87fQl(u"࠵໲"))+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࠦๅๅใࠬࠫউ"),ZD0qItXg31HmC7KGEFn)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫঊ"),[],[]
		elif XFaM94cPUCOWQZNIEe8gdJpny1==j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			gPNnhGvjZe = SZ0YL6RpbX.argv[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+gPE1XB87fQl(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭ঋ")+RiDsGTEw89ckYnbjF4N0QAXorBIPl+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࠨࡷࡩࡽࡺࡴ࠾ࠩঌ")+K1lPLX4fCOG
			pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ঍")+gPNnhGvjZe+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠥ࠭ࠧ঎"))
			return GHg28TBchiyn6l(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩএ"),[],[]
		title,SOw5EUxC9k = ZD0qItXg31HmC7KGEFn[XFaM94cPUCOWQZNIEe8gdJpny1],M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[title],[SOw5EUxC9k]
def rqvKs7u3yN(SOw5EUxC9k):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,IMjqygdfYSKpHlWu5Aa(u"ࠬࡍࡅࡕࠩঐ"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅࡓࡐࡘࡁ࠮࠳ࡶࡸࠬ঑"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if KLX7hW0nBAEgy6m4SvH(u"ࠧ࠯࡬ࡶࡳࡳ࠭঒") in SOw5EUxC9k: url = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠨࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨও"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: url = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঔ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not url: return gPE1XB87fQl(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡏࡌࡔࡄࠫক"),[],[]
	url = url[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if KLX7hW0nBAEgy6m4SvH(u"ࠫ࡭ࡺࡴࡱࠩখ") not in url: url = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬ࡮ࡴࡵࡲ࠽ࠫগ")+url
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def F4FYl2H3Op(url):
	headers = { tzZ6PhyDOUnwLM3pdK(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪঘ") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	if VP70ytiFNMBl6vHDaW(u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪঙ") in url:
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪচ"))
		items = p7dwlH1PRStBgyMUW.findall(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨছ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if items: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
		else:
			eJU6bsndE1mI0F = p7dwlH1PRStBgyMUW.findall(gPE1XB87fQl(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡷࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨজ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if eJU6bsndE1mI0F:
				BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭ঝ"),eJU6bsndE1mI0F[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
				return A41nqbj3wYt(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭ঞ")+eJU6bsndE1mI0F[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],[],[]
	else:
		Zf06rvhWgN3OPj2YTdeqU = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠩট")
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩঠ"))
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(oiWNFYzcIUeh(u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪড"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: return aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭ঢ"),[],[]
		ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]
		if A6iX18qgyOFlZxz7sc(u"ࠪ࠲ࡷࡧࡲࠨণ") in KDCdHQmgxPE21tYz4VUowSv or A6iX18qgyOFlZxz7sc(u"ࠫ࠳ࢀࡩࡱࠩত") in KDCdHQmgxPE21tYz4VUowSv: return SI7eBdND4lx8pt5Qk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪথ"),[],[]
		items = p7dwlH1PRStBgyMUW.findall(kdRO82AImh0LFw(u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧদ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		rLqYZOtwMfBVs4k1TpE3X9aDy = {}
		for fzu7Got0FgiyshTlJK,value in items:
			rLqYZOtwMfBVs4k1TpE3X9aDy[fzu7Got0FgiyshTlJK] = value
		data = kkymMOX7TcjRVpY2K(rLqYZOtwMfBVs4k1TpE3X9aDy)
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩধ"))
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭ন"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭঩"),[],[]
		download = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]
		items = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪপ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		uuSPzLkIpg3xGY,ZD0qItXg31HmC7KGEFn,Slf7xhMejYsqON51QkwX6d9I,M0MFkiKqJDv1aZ4NA396u,J1OvzMfBwF94XCkasrb = [],[],[],[],[]
		for SOw5EUxC9k,title in items:
			if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪফ") in SOw5EUxC9k:
				uuSPzLkIpg3xGY,Slf7xhMejYsqON51QkwX6d9I = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,SOw5EUxC9k)
				M0MFkiKqJDv1aZ4NA396u = M0MFkiKqJDv1aZ4NA396u + Slf7xhMejYsqON51QkwX6d9I
				if uuSPzLkIpg3xGY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬ࠳࠱ࠨব"): ZD0qItXg31HmC7KGEFn.append(pp7FcjEe6g(u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫভ")+IMjqygdfYSKpHlWu5Aa(u"ࠧ࡮࠵ࡸ࠼ࠥ࠭ম")+Zf06rvhWgN3OPj2YTdeqU)
				else:
					for title in uuSPzLkIpg3xGY:
						ZD0qItXg31HmC7KGEFn.append(A41nqbj3wYt(u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭য")+oiWNFYzcIUeh(u"ࠩࡰ࠷ࡺ࠾ࠠࠨর")+Zf06rvhWgN3OPj2YTdeqU+kcXMWrwiLDKeBHRsJ+title)
			else:
				title = title.replace(CyHU86ZeYT5BWRcitSm2I(u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬ঱"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				title = title.strip(A41nqbj3wYt(u"ࠫࠧ࠭ল"))
				title = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࠦำ๋ำไีࠥࠦฮศืࠣࠫ঳")+A6iX18qgyOFlZxz7sc(u"࠭ࠠ࡮ࡲ࠷ࠤࠬ঴")+Zf06rvhWgN3OPj2YTdeqU+kcXMWrwiLDKeBHRsJ+title
				ZD0qItXg31HmC7KGEFn.append(title)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		SOw5EUxC9k = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦࠩ঵") + download
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪশ"))
		items = p7dwlH1PRStBgyMUW.findall(VP70ytiFNMBl6vHDaW(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨষ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for id,HOkAWvmZSP5c2t9Dq4NgELyps,hash,Q4Qf3IEBzPM08H in items:
			title = A6iX18qgyOFlZxz7sc(u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧস")+gPE1XB87fQl(u"ࠫࠥࡳࡰ࠵ࠢࠪহ")+Zf06rvhWgN3OPj2YTdeqU+kcXMWrwiLDKeBHRsJ+Q4Qf3IEBzPM08H.split(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡾࠧ঺"))[wnaWTQM7VJPkZzO9eoSyFU4]
			SOw5EUxC9k = VP70ytiFNMBl6vHDaW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ঻")+id+yobpaW7sBqtKRrv(u"ࠧࠧ࡯ࡲࡨࡪࡃ়ࠧ")+HOkAWvmZSP5c2t9Dq4NgELyps+wwWzyF4ZpSQXKOgk569(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨঽ")+hash
			J1OvzMfBwF94XCkasrb.append(Q4Qf3IEBzPM08H)
			ZD0qItXg31HmC7KGEFn.append(title)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		J1OvzMfBwF94XCkasrb = set(J1OvzMfBwF94XCkasrb)
		PcEx6J3BIgN4GX7MkA1npT,q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ = [],[]
		for title in ZD0qItXg31HmC7KGEFn:
			hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤা"),title+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࠪࠫ࠭ি"),p7dwlH1PRStBgyMUW.DOTALL)
			for Q4Qf3IEBzPM08H in J1OvzMfBwF94XCkasrb:
				if hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] in Q4Qf3IEBzPM08H:
					title = title.replace(hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],Q4Qf3IEBzPM08H.split(beV5l2D8HznyJI0(u"ࠫࡽ࠭ী"))[wnaWTQM7VJPkZzO9eoSyFU4])
			PcEx6J3BIgN4GX7MkA1npT.append(title)
		for JrM1DoSuQ5n8 in range(len(M0MFkiKqJDv1aZ4NA396u)):
			items = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨু"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠦࠧࠩূ")+PcEx6J3BIgN4GX7MkA1npT[JrM1DoSuQ5n8]+SI7eBdND4lx8pt5Qk(u"ࠧࠧࠨࠪৃ"),p7dwlH1PRStBgyMUW.DOTALL)
			q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ.append( [PcEx6J3BIgN4GX7MkA1npT[JrM1DoSuQ5n8],M0MFkiKqJDv1aZ4NA396u[JrM1DoSuQ5n8],items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4],items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]] )
		q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ = sorted(q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ, key=lambda OU8cbKwe1gXj5hsoW0LJYrAQf2: OU8cbKwe1gXj5hsoW0LJYrAQf2[vXIdY7TwFKso40gVBq5], reverse=r0D4C3z7Onqpa)
		q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ = sorted(q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ, key=lambda OU8cbKwe1gXj5hsoW0LJYrAQf2: OU8cbKwe1gXj5hsoW0LJYrAQf2[XURrDCfOS9Mbhpv2Pmjos56TeW], reverse=KiryBCvngZzF85UN6xSDlOVweL4I9)
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
		for JrM1DoSuQ5n8 in range(len(q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ)):
			ZD0qItXg31HmC7KGEFn.append(q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ[JrM1DoSuQ5n8][j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
			M0MFkiKqJDv1aZ4NA396u.append(q0L9RhQoOW1CAFZ3YDkxrsV87wEGBJ[JrM1DoSuQ5n8][wnaWTQM7VJPkZzO9eoSyFU4])
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return gPE1XB87fQl(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬৄ"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def E9ihJtvlVR1DP(url):
	ipdI4Kw1lMauxrtYoh = url.split(KLX7hW0nBAEgy6m4SvH(u"ࠩࡂࠫ৅"))
	vcQbFfCk6T1 = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	headers = { IMjqygdfYSKpHlWu5Aa(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৆") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫে"))
	items = p7dwlH1PRStBgyMUW.findall(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ৈ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	url = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৉"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def JbmlH1P74zejvB(url):
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	headers = { aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ৊") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧো"))
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠩࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡺࡸ࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩৌ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vcQbFfCk6T1: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	else: return beV5l2D8HznyJI0(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡕ࡛࡜࡙ࡖࡑ্࠭"),[],[]
def t49oamAgUkJGKvI2Y(url):
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	headers = { ZLr5gRSkFewKdUos90bM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨৎ") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ৏"))
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩ৐"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vcQbFfCk6T1: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	else: return kdRO82AImh0LFw(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨ৑"),[],[]
def Y6gzSMvWmk(url):
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,errno = [],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬ৒") in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {beV5l2D8HznyJI0(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ৓"):bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ৔")}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,beV5l2D8HznyJI0(u"ࠫࡕࡕࡓࡕࠩ৕"),vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨ৖"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if hFYoSTas7WOVnwN.startswith(mq5t9JXSdHT8yfDVF(u"࠭ࡨࡵࡶࡳࠫৗ")): vcQbFfCk6T1 = hFYoSTas7WOVnwN
		else:
			QQTfhlZEDnu4wVcOeHGNyCBo5t2 = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨ৘"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if QQTfhlZEDnu4wVcOeHGNyCBo5t2:
				vcQbFfCk6T1 = QQTfhlZEDnu4wVcOeHGNyCBo5t2[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯࡛ࠧࠦࡠࠫ৙"),vcQbFfCk6T1,p7dwlH1PRStBgyMUW.DOTALL)
				if QQTfhlZEDnu4wVcOeHGNyCBo5t2:
					vcQbFfCk6T1 = EZk136aeLoNqPvlDcTQpyM9Wm(QQTfhlZEDnu4wVcOeHGNyCBo5t2[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
					return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩ࠲ࡰ࡮ࡴ࡫ࡴ࠱ࠪ৚") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡋࡊ࡚ࠧ৛"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧড়"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if gPE1XB87fQl(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧঢ়") in list(WadGEeh1MBIXkpfP38qAv7ryslY.headers.keys()): vcQbFfCk6T1 = WadGEeh1MBIXkpfP38qAv7ryslY.headers[jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ৞")]
		else:
			vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫয়"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if vcQbFfCk6T1 else url
	if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠱ࡹ࠳ࠬৠ") in vcQbFfCk6T1 or ZLr5gRSkFewKdUos90bM(u"ࠩ࠲ࡪ࠴࠭ৡ") in vcQbFfCk6T1:
		vcQbFfCk6T1 = vcQbFfCk6T1.replace(A6iX18qgyOFlZxz7sc(u"ࠪ࠳࡫࠵ࠧৢ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪৣ"))
		vcQbFfCk6T1 = vcQbFfCk6T1.replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࠵ࡶ࠰ࠩ৤"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ৥"))
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,IMjqygdfYSKpHlWu5Aa(u"ࠧࡑࡑࡖࡘࠬ০"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ১"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		items = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ২"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,title in items:
				SOw5EUxC9k = SOw5EUxC9k.replace(tzZ6PhyDOUnwLM3pdK(u"ࠪࡠࡡ࠭৩"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				ZD0qItXg31HmC7KGEFn.append(title)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		else:
			items = p7dwlH1PRStBgyMUW.findall(VP70ytiFNMBl6vHDaW(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ৪"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if items:
				SOw5EUxC9k = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				SOw5EUxC9k = SOw5EUxC9k.replace(wwWzyF4ZpSQXKOgk569(u"ࠬࡢ࡜ࠨ৫"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				ZD0qItXg31HmC7KGEFn.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	else: return IMjqygdfYSKpHlWu5Aa(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৬"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ৭"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def G8EoMZwSa0(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,KLX7hW0nBAEgy6m4SvH(u"ࠨࡉࡈࡘࠬ৮"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ৯"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,errno = [],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if pp7FcjEe6g(u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭ৰ") in url or SI7eBdND4lx8pt5Qk(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬৱ") in url:
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ৲") in url:
			vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৳"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: vcQbFfCk6T1 = url
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ৴") not in vcQbFfCk6T1: return wwWzyF4ZpSQXKOgk569(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ৵"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,iySORMYxWXszEH18(u"ࠩࡊࡉ࡙࠭৶"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪ৷"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧ৸"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৹"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,z6PVkLf7Od in items:
				ZD0qItXg31HmC7KGEFn.append(z6PVkLf7Od)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨ৺") in url:
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫ৻"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,wwWzyF4ZpSQXKOgk569(u"ࠨࡉࡈࡘࠬৼ"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ৽"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ৾"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = QQTfhlZEDnu4wVcOeHGNyCBo5t2[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		ZD0qItXg31HmC7KGEFn.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		M0MFkiKqJDv1aZ4NA396u.append(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ৿") in url:
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਀"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if vcQbFfCk6T1:
			vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			return aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਁ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓ࡛࡙࠴ࡖࠩਂ"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def nMWqebA3wf(url):
	if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡁࡪࡩࡹࡃࠧਃ") in url:
		SOw5EUxC9k = url.split(Z9FPQvwlbjLTh(u"ࠩࡂ࡫ࡪࡺ࠽ࠨ਄"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
		SOw5EUxC9k = uvGCPpFwVmTQ36.b64decode(SOw5EUxC9k)
		if rJ2oTLqabRtA: SOw5EUxC9k = SOw5EUxC9k.decode(e87cIA5vwOQLDEP1,A41nqbj3wYt(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪਅ"))
		return yobpaW7sBqtKRrv(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਆ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	website = A3pXVFdyP1.SITESURLS[iySORMYxWXszEH18(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧਇ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	headers = {yobpaW7sBqtKRrv(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਈ"):website}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡈࡇࡗࠫਉ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠲࡯ࡦࠪਊ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,GHg28TBchiyn6l(u"ࠩࡸࡶࡱ࠭਋"))
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ਌"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(yobpaW7sBqtKRrv(u"ࠦࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠩࠫ࠲࠯ࡅࠩࠨࠤ਍"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(gPE1XB87fQl(u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦ਎"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩਏ")+website
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	if Z9FPQvwlbjLTh(u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧਐ") in piN9Qlah4S:
		uoqgnTfmeUPI = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ਑"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if uoqgnTfmeUPI:
			SOw5EUxC9k = uoqgnTfmeUPI[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			SOw5EUxC9k = uvGCPpFwVmTQ36.b64decode(SOw5EUxC9k)
			if rJ2oTLqabRtA: SOw5EUxC9k = SOw5EUxC9k.decode(e87cIA5vwOQLDEP1,A41nqbj3wYt(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ਒"))
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪ࡬ࡹࡺࡰ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠲ࠧਓ"),SOw5EUxC9k,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k:
				SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+bawK2j7T81Nrc4GWs05xzDg(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧਔ")+website
				return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return iySORMYxWXszEH18(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਕ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def JdUBjazqsO(url,a8ViDmKTjhIEs4bnykRL):
	pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = [],[]
	if aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࠯࠲࠱ࠪਖ") in url:
		SOw5EUxC9k = url.replace(Z9FPQvwlbjLTh(u"ࠧ࠰࠳࠲ࠫਗ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠱࠷࠳ࠬਘ"))
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,GHg28TBchiyn6l(u"ࠩࡊࡉ࡙࠭ਙ"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬਚ"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(yobpaW7sBqtKRrv(u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪਛ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			items = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਜ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO in items:
				if SOw5EUxC9k not in wxT9bCdumN:
					wxT9bCdumN.append(SOw5EUxC9k)
					VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,ZLr5gRSkFewKdUos90bM(u"࠭࡮ࡢ࡯ࡨࠫਝ"))
					pixfvyGY1aJPowKZer34TcNblL7k2.append(VVpQfHc7IZamxweON3WXKU6Fg+tTChquY7XSRg4e+DIBw28Qfje76bTMzVNYhxrgWmO)
			return WnNGfosHr5STAq8j7miwyRZ6eOUbV,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN
	elif oiWNFYzcIUeh(u"ࠧ࠰ࡦ࠲ࠫਞ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,beV5l2D8HznyJI0(u"ࠨࡉࡈࡘࠬਟ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫਠ"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਡ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k:
			SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(GHg28TBchiyn6l(u"ࠫ࠴࠷࠯ࠨਢ"),YYQS36fyPvtuzcEmRL(u"ࠬ࠵࠴࠰ࠩਣ"))
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡇࡆࡖࠪਤ"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠹ࡲࡥࠩਥ"))
			hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡥ࡯ࡥࡸࡹ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਦ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k: return SI7eBdND4lx8pt5Qk(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬਧ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	elif CyHU86ZeYT5BWRcitSm2I(u"ࠪ࠳ࡷࡵ࡬ࡦ࠱ࠪਨ") in url:
		headers = {jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ਩"):a8ViDmKTjhIEs4bnykRL}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡍࡅࡕࠩਪ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠹ࡺࡨࠨਫ"))
		SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩਬ")]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡉࡈࡘࠬਭ"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠶ࡶ࡫ࠫਮ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = vg9WcsehHx(SOw5EUxC9k,piN9Qlah4S)
		return QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN
	elif ZLr5gRSkFewKdUos90bM(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧਯ") in url:
		vcQbFfCk6T1 = url.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨਰ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࠵ࡳࡤࡴ࡬ࡴࡹ࠵ࠧ਱"))
		W67hPCcaOek094 = {bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਲ"):a8ViDmKTjhIEs4bnykRL}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,yobpaW7sBqtKRrv(u"ࠧࡈࡇࡗࠫਲ਼"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kdRO82AImh0LFw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠶ࡵࡪࠪ਴"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਵ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k:
			SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,iySORMYxWXszEH18(u"ࠪࡋࡊ࡚ࠧਸ਼"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠺ࡸ࡭࠭਷"))
			piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧਸ") in list(WadGEeh1MBIXkpfP38qAv7ryslY.headers.keys()):
				SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[yobpaW7sBqtKRrv(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨਹ")]
				WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡈࡇࡗࠫ਺"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠸ࡵࡪࠪ਻"))
				piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
				QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = vg9WcsehHx(SOw5EUxC9k,piN9Qlah4S)
				if wxT9bCdumN: return QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN
			elif iySORMYxWXszEH18(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵࡅࡩࡥ࠿਼ࠪ") in SOw5EUxC9k:
				SOw5EUxC9k = SOw5EUxC9k.replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ਽"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫ࠴ࡰࡷࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨਾ"))
				return gPE1XB87fQl(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਿ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	else: return yobpaW7sBqtKRrv(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩੀ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	return iySORMYxWXszEH18(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫੁ"),[],[]
def U7XDKi5njM(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,A41nqbj3wYt(u"ࠨࡉࡈࡘࠬੂ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫ੃"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	data = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ੄"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if data:
		wyjiS4Hl2OTrcomEQVBZpe9YhXfM6s,id,FNJmYfDUuQL7aRKlHO8PXEibCsq = data[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		data = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡴࡶ࠽ࠨ੅")+wyjiS4Hl2OTrcomEQVBZpe9YhXfM6s+mq5t9JXSdHT8yfDVF(u"ࠬࠬࡩࡥ࠿ࠪ੆")+id+I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧੇ")+FNJmYfDUuQL7aRKlHO8PXEibCsq
		headers = {CyHU86ZeYT5BWRcitSm2I(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ੈ"):gPE1XB87fQl(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ੉")}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,gPE1XB87fQl(u"ࠩࡓࡓࡘ࡚ࠧ੊"),url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠴ࡱࡨࠬੋ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࠧࡸࡥࡧࡧࡵࡩࡷࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧੌ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k: return wwWzyF4ZpSQXKOgk569(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ੍"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	return A6iX18qgyOFlZxz7sc(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ੎"),[],[]
def CduqENMtf8(url):
	headers = {IMjqygdfYSKpHlWu5Aa(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ੏"):YYQS36fyPvtuzcEmRL(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ੐")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,beV5l2D8HznyJI0(u"ࠩࡊࡉ࡙࠭ੑ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮࠳ࡶࡸࠬ੒"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੓"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ੔"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return YYQS36fyPvtuzcEmRL(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ੕"),[],[]
def aaRwAVNtIH(url):
	vcQbFfCk6T1 = url.split(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ੖"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].strip(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡁࠪ੗")).strip(GHg28TBchiyn6l(u"ࠩ࠲ࠫ੘")).strip(oiWNFYzcIUeh(u"ࠪࠪࠬਖ਼"))
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,items,QQTfhlZEDnu4wVcOeHGNyCBo5t2 = [],[],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	headers = { pp7FcjEe6g(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਗ਼"):Z9FPQvwlbjLTh(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬਜ਼") }
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,SI7eBdND4lx8pt5Qk(u"࠭ࡇࡆࡖࠪੜ"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠶ࡹࡴࠨ੝"))
	if SI7eBdND4lx8pt5Qk(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪਫ਼") in list(WadGEeh1MBIXkpfP38qAv7ryslY.headers.keys()): QQTfhlZEDnu4wVcOeHGNyCBo5t2 = WadGEeh1MBIXkpfP38qAv7ryslY.headers[beV5l2D8HznyJI0(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ੟")]
	if oiWNFYzcIUeh(u"ࠪ࡬ࡹࡺࡰࠨ੠") in QQTfhlZEDnu4wVcOeHGNyCBo5t2:
		if A41nqbj3wYt(u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ੡") in url: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = QQTfhlZEDnu4wVcOeHGNyCBo5t2.replace(A41nqbj3wYt(u"ࠬ࠵ࡦ࠰ࠩ੢"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࠯ࡷ࠱ࠪ੣"))
		FcXog5uj9DENn3dV2smS = vcQbFfCk6T1.split(IMjqygdfYSKpHlWu5Aa(u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ੤"))[wnaWTQM7VJPkZzO9eoSyFU4]
		headers = { CyHU86ZeYT5BWRcitSm2I(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ੥"):headers[oiWNFYzcIUeh(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭੦")] , bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ੧"):CyHU86ZeYT5BWRcitSm2I(u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ੨")+FcXog5uj9DENn3dV2smS }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡍࡅࡕࠩ੩"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ੪"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧ࠰ࡨ࠲ࠫ੫") in QQTfhlZEDnu4wVcOeHGNyCBo5t2: items = p7dwlH1PRStBgyMUW.findall(wwWzyF4ZpSQXKOgk569(u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੬"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		elif rVy3Ops0mohYkT(u"ࠩ࠲ࡺ࠴࠭੭") in QQTfhlZEDnu4wVcOeHGNyCBo5t2: items = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੮"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if items: return [],[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] ]
		elif beV5l2D8HznyJI0(u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪ੯") in piN9Qlah4S:
			return mq5t9JXSdHT8yfDVF(u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้หๆหำ้ฮࠥอไฯษุอࠥฮใࠨੰ"),[],[]
	else: return CyHU86ZeYT5BWRcitSm2I(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕࠩੱ"),[],[]
def vTi9bK5rJc(SOw5EUxC9k):
	ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(beV5l2D8HznyJI0(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩੲ"),SOw5EUxC9k+rVy3Ops0mohYkT(u"ࠨࠨࠩࠫੳ"),p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	YQU9rmMqC0LWkcxaFpZos7VdRg,cza2TRbvfOW8i5xoU = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	url = yobpaW7sBqtKRrv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪੴ")+YQU9rmMqC0LWkcxaFpZos7VdRg+IMjqygdfYSKpHlWu5Aa(u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧੵ")+cza2TRbvfOW8i5xoU
	headers = { wwWzyF4ZpSQXKOgk569(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੶"):WnNGfosHr5STAq8j7miwyRZ6eOUbV , tzZ6PhyDOUnwLM3pdK(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ੷"):CyHU86ZeYT5BWRcitSm2I(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ੸") }
	vcQbFfCk6T1 = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭੹"))
	return eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੺"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
def NNaWlnOxMy(url):
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,rVy3Ops0mohYkT(u"ࠩࡸࡶࡱ࠭੻"))
	W67hPCcaOek094 = {bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ੼"):VVpQfHc7IZamxweON3WXKU6Fg,SI7eBdND4lx8pt5Qk(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭੽"):wwWzyF4ZpSQXKOgk569(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ੾")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(A8MWZixP2YtOJ1no53mw,A41nqbj3wYt(u"࠭ࡇࡆࡖࠪ੿"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ઀"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩઁ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	vcQbFfCk6T1 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨં"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
		for title,SOw5EUxC9k in items:
			ZD0qItXg31HmC7KGEFn.append(title)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		if len(M0MFkiKqJDv1aZ4NA396u)==wnaWTQM7VJPkZzO9eoSyFU4: vcQbFfCk6T1 = M0MFkiKqJDv1aZ4NA396u[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		elif len(M0MFkiKqJDv1aZ4NA396u)>wnaWTQM7VJPkZzO9eoSyFU4:
			XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(kdRO82AImh0LFw(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨઃ"), ZD0qItXg31HmC7KGEFn)
			if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return pp7FcjEe6g(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ઄"),[],[]
			vcQbFfCk6T1 = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(oiWNFYzcIUeh(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪઅ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: vcQbFfCk6T1 = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if not vcQbFfCk6T1: return rVy3Ops0mohYkT(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨઆ"),[],[]
	return bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪઇ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
def qMdu6gXCnzcp9WhEUAJZ(url):
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,A41nqbj3wYt(u"ࠨࡷࡵࡰࠬઈ"))
	W67hPCcaOek094 = {CyHU86ZeYT5BWRcitSm2I(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪઉ"):VVpQfHc7IZamxweON3WXKU6Fg,rVy3Ops0mohYkT(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬઊ"):SI7eBdND4lx8pt5Qk(u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫઋ")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(A8MWZixP2YtOJ1no53mw,ZLr5gRSkFewKdUos90bM(u"ࠬࡍࡅࡕࠩઌ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡉࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ઍ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨ઎"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	vcQbFfCk6T1 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧએ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
		for title,SOw5EUxC9k in items:
			ZD0qItXg31HmC7KGEFn.append(title)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		if len(M0MFkiKqJDv1aZ4NA396u)==wnaWTQM7VJPkZzO9eoSyFU4: vcQbFfCk6T1 = M0MFkiKqJDv1aZ4NA396u[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		elif len(M0MFkiKqJDv1aZ4NA396u)>wnaWTQM7VJPkZzO9eoSyFU4:
			XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(gPE1XB87fQl(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧઐ"),ZD0qItXg31HmC7KGEFn)
			if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨઑ"),[],[]
			vcQbFfCk6T1 = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	if not vcQbFfCk6T1:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ઒"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: vcQbFfCk6T1 = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if not vcQbFfCk6T1: return tzZ6PhyDOUnwLM3pdK(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧઓ"),[],[]
	return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩઔ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
def HhTRf43jBE(SOw5EUxC9k):
	ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ક"),SOw5EUxC9k+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࠨࠩࠫખ"),p7dwlH1PRStBgyMUW.DOTALL)
	url,YQU9rmMqC0LWkcxaFpZos7VdRg,cza2TRbvfOW8i5xoU = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	data = {oiWNFYzcIUeh(u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪગ"):YQU9rmMqC0LWkcxaFpZos7VdRg,SI7eBdND4lx8pt5Qk(u"ࠪࡷࡪࡸࡶࡦࡴࠪઘ"):cza2TRbvfOW8i5xoU}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,ZLr5gRSkFewKdUos90bM(u"ࠫࡕࡕࡓࡕࠩઙ"),url,data,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧચ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(pp7FcjEe6g(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫછ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪજ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
def kpBgcTzUjY(url):
	SOw5EUxC9k = url
	if GHg28TBchiyn6l(u"ࠨࡁࡶࡩࡷࡼ࠽ࠨઝ") in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡊࡉ࡙࠭ઞ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰࠵ࡸࡺࠧટ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(mq5t9JXSdHT8yfDVF(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬઠ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k: SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: return IMjqygdfYSKpHlWu5Aa(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫડ"),[],[]
	return aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩઢ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def w9rdylLDsa(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡈࡇࡗࠫણ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫત"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪથ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if SOw5EUxC9k: return wwWzyF4ZpSQXKOgk569(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭દ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return beV5l2D8HznyJI0(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩધ"),[],[]
def REfPWC2K6J(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,gPE1XB87fQl(u"ࠬࡍࡅࡕࠩન"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ઩"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭પ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫફ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def UhA459zcSm(url):
	q16smZkWvE = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡸࡶࡱ࠭બ"))
	if rVy3Ops0mohYkT(u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪભ") in url:
		headers = {aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬમ"):q16smZkWvE}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,CyHU86ZeYT5BWRcitSm2I(u"ࠬࡍࡅࡕࠩય"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧર"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ઱"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if vcQbFfCk6T1:
			vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			if yobpaW7sBqtKRrv(u"ࠨࡪࡷࡸࡵ࠭લ") not in vcQbFfCk6T1: vcQbFfCk6T1 = Z9FPQvwlbjLTh(u"ࠩ࡫ࡸࡹࡶ࠺ࠨળ")+vcQbFfCk6T1
			if rVy3Ops0mohYkT(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ઴") in vcQbFfCk6T1:
				WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡌࡋࡔࠨવ"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rVy3Ops0mohYkT(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭શ"))
				hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
				items = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬષ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
				if not items:
					cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡ࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࡠ࠳࠭સ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
					if cKUQVwTMe9tZSY:
						s5ocIDd4WKuPrV = cKUQVwTMe9tZSY[beV5l2D8HznyJI0(u"࠵໳")]
						items = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࠤ࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠥ࠮࠮ࠫࡁࠬࠦࠬહ"),s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
						if items:
							g2L7XqtNVP,RRdNfJ0vrE3 = zip(*items)
							items = list(zip(RRdNfJ0vrE3,g2L7XqtNVP))
				ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
				HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,gPE1XB87fQl(u"ࠩࡸࡶࡱ࠭઺"))
				for SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO in reversed(items):
					SOw5EUxC9k = HM25TctPpBqSeNzx3fm714+SOw5EUxC9k+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭઻")+HM25TctPpBqSeNzx3fm714
					ZD0qItXg31HmC7KGEFn.append(DIBw28Qfje76bTMzVNYhxrgWmO)
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
				return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
			else: return YYQS36fyPvtuzcEmRL(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ઼࡙ࠧ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	vcQbFfCk6T1 = url+rVy3Ops0mohYkT(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨઽ")+q16smZkWvE
	if I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡨࡵࡶࡳࠫા") not in vcQbFfCk6T1: vcQbFfCk6T1 = KLX7hW0nBAEgy6m4SvH(u"ࠧࡩࡶࡷࡴ࠿࠭િ")+vcQbFfCk6T1
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
def JIQfO1Knw2j3L9kWsyNzTei(SOw5EUxC9k):
	q16smZkWvE = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,KLX7hW0nBAEgy6m4SvH(u"ࠨࡷࡵࡰࠬી"))
	if tzZ6PhyDOUnwLM3pdK(u"ࠩࡳࡳࡸࡺࡩࡥࠩુ") in SOw5EUxC9k:
		ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩૂ"),SOw5EUxC9k+gPE1XB87fQl(u"ࠫࠫࠬࠧૃ"),p7dwlH1PRStBgyMUW.DOTALL)
		url,YQU9rmMqC0LWkcxaFpZos7VdRg,cza2TRbvfOW8i5xoU = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		data = {tzZ6PhyDOUnwLM3pdK(u"ࠬ࡯ࡤࠨૄ"):YQU9rmMqC0LWkcxaFpZos7VdRg,A6iX18qgyOFlZxz7sc(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ૅ"):cza2TRbvfOW8i5xoU}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,tzZ6PhyDOUnwLM3pdK(u"ࠧࡑࡑࡖࡘࠬ૆"),url,data,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩે"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧૈ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if rVy3Ops0mohYkT(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫૉ") in vcQbFfCk6T1:
			headers = {mq5t9JXSdHT8yfDVF(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ૊"):q16smZkWvE,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩો"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,oiWNFYzcIUeh(u"࠭ࡇࡆࡖࠪૌ"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ્"))
			hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
			items = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૎"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
			HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡸࡶࡱ࠭૏"))
			for SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO in reversed(items):
				SOw5EUxC9k = HM25TctPpBqSeNzx3fm714+SOw5EUxC9k+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ૐ")+HM25TctPpBqSeNzx3fm714
				ZD0qItXg31HmC7KGEFn.append(DIBw28Qfje76bTMzVNYhxrgWmO)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
		else: return n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૑"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	else:
		SOw5EUxC9k = SOw5EUxC9k+KLX7hW0nBAEgy6m4SvH(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ૒")+q16smZkWvE
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
def DvjdSTt7qW(SOw5EUxC9k):
	if A41nqbj3wYt(u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭૓") in SOw5EUxC9k:
		ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(A6iX18qgyOFlZxz7sc(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ૔"),SOw5EUxC9k+beV5l2D8HznyJI0(u"ࠨࠨࠩࠫ૕"),p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		YQU9rmMqC0LWkcxaFpZos7VdRg,cza2TRbvfOW8i5xoU = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		kr2ca95zm3jKIZhL = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,CyHU86ZeYT5BWRcitSm2I(u"ࠩࡸࡶࡱ࠭૖"))
		url = kr2ca95zm3jKIZhL+beV5l2D8HznyJI0(u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ૗")+YQU9rmMqC0LWkcxaFpZos7VdRg+mq5t9JXSdHT8yfDVF(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ૘")+cza2TRbvfOW8i5xoU
		headers = { iySORMYxWXszEH18(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ૙"):WnNGfosHr5STAq8j7miwyRZ6eOUbV , lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ૚"):CyHU86ZeYT5BWRcitSm2I(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ૛") }
		vcQbFfCk6T1 = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ૜"))
		vcQbFfCk6T1 = vcQbFfCk6T1.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		return Z9FPQvwlbjLTh(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ૝"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ૞") in SOw5EUxC9k:
		qQOZvusy1Jx5VE = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		while XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ૟") in SOw5EUxC9k and qQOZvusy1Jx5VE<CyHU86ZeYT5BWRcitSm2I(u"࠻໴"):
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,A41nqbj3wYt(u"ࠬࡍࡅࡕࠩૠ"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨૡ"))
			if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩૢ") in list(WadGEeh1MBIXkpfP38qAv7ryslY.headers.keys()): SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers[gPE1XB87fQl(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪૣ")]
			qQOZvusy1Jx5VE += wnaWTQM7VJPkZzO9eoSyFU4
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	else: return aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡂࡍࡋࡒࡒ࡟࠭૤"),[],[]
def nrd8U1RKu6(url):
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,pp7FcjEe6g(u"ࠪࡹࡷࡲࠧ૥"))
	headers = {ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ૦"):VVpQfHc7IZamxweON3WXKU6Fg,rVy3Ops0mohYkT(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ૧"):E1ltCBVyML6PAUNY()}
	if GHg28TBchiyn6l(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ૨") in url:
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩ૩"))
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(mq5t9JXSdHT8yfDVF(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૪"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k:
			SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(CyHU86ZeYT5BWRcitSm2I(u"ࠩ࡫ࡸࡹࡶࡳࠨ૫"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ࡬ࡹࡺࡰࠨ૬"))
			return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	else:
		wwD3ZHgrJo1OQc8edhvtxqV = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,KLX7hW0nBAEgy6m4SvH(u"ࠫࡌࡋࡔࠨ૭"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠷ࡷࡪࠧ૮"))
		piN9Qlah4S = wwD3ZHgrJo1OQc8edhvtxqV.content
		W67hPCcaOek094 = headers.copy()
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭࡟࡭ࡰ࡮ࡣࠬ૯") in str(wwD3ZHgrJo1OQc8edhvtxqV.cookies):
			cookies = wwD3ZHgrJo1OQc8edhvtxqV.cookies
			W67hPCcaOek094[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ૰")] = EZk136aeLoNqPvlDcTQpyM9Wm(kkymMOX7TcjRVpY2K(cookies))
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ૱"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not SOw5EUxC9k: return tzZ6PhyDOUnwLM3pdK(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ૲"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
		else:
			SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])+wwWzyF4ZpSQXKOgk569(u"ࠪࠪࡩࡃ࠱ࠨ૳")
			VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,ZLr5gRSkFewKdUos90bM(u"ࠫࡌࡋࡔࠨ૴"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠸ࡹ࡮ࠧ૵"))
			piN9Qlah4S = VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(SI7eBdND4lx8pt5Qk(u"࠭ࡩࡥ࠿ࠥࡦࡹࡴࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૶"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k:
				SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
				if Z9FPQvwlbjLTh(u"ࠧ࡮ࡲ࠷ࠫ૷") in SOw5EUxC9k and oiWNFYzcIUeh(u"ࠨ࠱ࡧ࠳ࠬ૸") in SOw5EUxC9k: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
				else: return bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૹ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧૺ"),[],[]
def Ym6QVM1qai(SOw5EUxC9k):
	if eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠨૻ") in SOw5EUxC9k:
		headers = {A6iX18qgyOFlZxz7sc(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨૼ"):VP70ytiFNMBl6vHDaW(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ૽")}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,gPE1XB87fQl(u"ࠧࡈࡇࡗࠫ૾"),SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪ૿"))
		url = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if url: return bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ଀"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	else:
		ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫଁ"),SOw5EUxC9k,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if not ipdI4Kw1lMauxrtYoh: ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(mq5t9JXSdHT8yfDVF(u"ࠫࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧଂ"),SOw5EUxC9k,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		YQU9rmMqC0LWkcxaFpZos7VdRg,cza2TRbvfOW8i5xoU = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,kdRO82AImh0LFw(u"ࠬࡻࡲ࡭ࠩଃ"))
		url = VVpQfHc7IZamxweON3WXKU6Fg+tzZ6PhyDOUnwLM3pdK(u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ଄")
		data = {lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡪࡦࠪଅ"):YQU9rmMqC0LWkcxaFpZos7VdRg,IMjqygdfYSKpHlWu5Aa(u"ࠨ࡫ࠪଆ"):cza2TRbvfOW8i5xoU}
		headers = {yobpaW7sBqtKRrv(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬଇ"):pp7FcjEe6g(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫଈ"),CyHU86ZeYT5BWRcitSm2I(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬଉ"):SOw5EUxC9k}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,Z9FPQvwlbjLTh(u"ࠬࡖࡏࡔࡖࠪଊ"),url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠷ࡴࡤࠨଋ"))
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬଌ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if vcQbFfCk6T1:
			vcQbFfCk6T1 = vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			return mq5t9JXSdHT8yfDVF(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ଍"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	return mq5t9JXSdHT8yfDVF(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭଎"),[],[]
def YNp3IxdBhsRWAMm1XbEG6(wRVcBMCyHXUmkapYWsuJlfDEtANiFz):
	veFLDlXzC8bjfS = G3yDpvxOiSWdAeL.getSetting(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡥࡻ࠴ࡡ࡬ࡹࡤࡱ࠳ࡼࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫଏ"))
	headers = {iySORMYxWXszEH18(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫଐ"):veFLDlXzC8bjfS} if veFLDlXzC8bjfS else WnNGfosHr5STAq8j7miwyRZ6eOUbV
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,gPE1XB87fQl(u"ࠬࡍࡅࡕࠩ଑"),wRVcBMCyHXUmkapYWsuJlfDEtANiFz,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠴ࡷࡹ࠭଒"))
	D67S2smgCxbIdO1eULX89lq4 = WadGEeh1MBIXkpfP38qAv7ryslY.content
	CCraLifvx0dcuHwYPyTEo9k = str(WadGEeh1MBIXkpfP38qAv7ryslY.headers)
	ZuVyaGm1oi84CWPKYHtc9UnskOTx = CCraLifvx0dcuHwYPyTEo9k+D67S2smgCxbIdO1eULX89lq4
	if eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࠯࡯ࡳ࠸ࠬଓ") in ZuVyaGm1oi84CWPKYHtc9UnskOTx: QyG6a4ESNfC3RenMlD1Ttq8 = r0D4C3z7Onqpa
	else:
		MVKltEq1hzb6Sm,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H,WK9R8J2VhIObEquTzlx0SfYU3,X50X4rnVuAOlHK,QyG6a4ESNfC3RenMlD1Ttq8 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9
		captcha = p7dwlH1PRStBgyMUW.findall(SI7eBdND4lx8pt5Qk(u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଔ"),D67S2smgCxbIdO1eULX89lq4,p7dwlH1PRStBgyMUW.DOTALL)
		if captcha: WK9R8J2VhIObEquTzlx0SfYU3,X50X4rnVuAOlHK = captcha[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		AK90athefUWs7u5mPYpIgNvFzG = A3pXVFdyP1.SITESURLS[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩକ")][SI7eBdND4lx8pt5Qk(u"࠷໵")]
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			data = {CyHU86ZeYT5BWRcitSm2I(u"ࠪࡹࡸ࡫ࡲࠨଖ"):A3pXVFdyP1.AV_CLIENT_IDS,pp7FcjEe6g(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬଗ"):mbvW9By35UDO,pp7FcjEe6g(u"ࠬࡻࡲ࡭ࠩଘ"):wRVcBMCyHXUmkapYWsuJlfDEtANiFz,rVy3Ops0mohYkT(u"࠭࡫ࡦࡻࠪଙ"):X50X4rnVuAOlHK,A6iX18qgyOFlZxz7sc(u"ࠧࡪࡦࠪଚ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࡬ࡲࡦࠬଛ"):eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡪࡩࡹࡻࡲ࡭ࡵࠪଜ")}
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡔࡔ࡙ࡔࠨଝ"),AK90athefUWs7u5mPYpIgNvFzG,data,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠳ࡰࡧࠫଞ"))
			piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		piN9Qlah4S = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if piN9Qlah4S.startswith(yobpaW7sBqtKRrv(u"࡛ࠬࡒࡍࡕࡀࠫଟ")):
			EHhzCdkcwuvfWP = IXZpzK7ShaRsAN(GHg28TBchiyn6l(u"࠭࡬ࡪࡵࡷࠫଠ"),piN9Qlah4S.split(ZLr5gRSkFewKdUos90bM(u"ࠧࡖࡔࡏࡗࡂ࠭ଡ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4])
			for dlPQGb0aC5xmfFwy9ievKTqX in EHhzCdkcwuvfWP:
				url = dlPQGb0aC5xmfFwy9ievKTqX[beV5l2D8HznyJI0(u"ࠨࡷࡵࡰࠬଢ")]
				S5orefWm8D4k6bw1Ops = dlPQGb0aC5xmfFwy9ievKTqX[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡰࡩࡹ࡮࡯ࡥࠩଣ")]
				data = dlPQGb0aC5xmfFwy9ievKTqX[A6iX18qgyOFlZxz7sc(u"ࠪࡨࡦࡺࡡࠨତ")]
				headers = dlPQGb0aC5xmfFwy9ievKTqX[ZLr5gRSkFewKdUos90bM(u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬଥ")]
				WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,S5orefWm8D4k6bw1Ops,url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬଦ"))
				D67S2smgCxbIdO1eULX89lq4 = WadGEeh1MBIXkpfP38qAv7ryslY.content
				if bawK2j7T81Nrc4GWs05xzDg(u"࠭࠮࡮ࡲ࠷ࠫଧ") in D67S2smgCxbIdO1eULX89lq4:
					QyG6a4ESNfC3RenMlD1Ttq8 = r0D4C3z7Onqpa
					break
				CCraLifvx0dcuHwYPyTEo9k = str(WadGEeh1MBIXkpfP38qAv7ryslY.headers)
				ZuVyaGm1oi84CWPKYHtc9UnskOTx = CCraLifvx0dcuHwYPyTEo9k+D67S2smgCxbIdO1eULX89lq4
				MVKltEq1hzb6Sm = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡽࠫࠪ࠰࠭ࡃࠧ࠮ࡥࡺࡌ࠱࠮ࡄ࠯ࠢࠨନ"),ZuVyaGm1oi84CWPKYHtc9UnskOTx,p7dwlH1PRStBgyMUW.DOTALL)
				pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = p7dwlH1PRStBgyMUW.findall(beV5l2D8HznyJI0(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰ࠱࠮ࡄࠨࠨ࠱࠵ࡄ࠲࠯ࡅࠩࠣࠩ଩"),ZuVyaGm1oi84CWPKYHtc9UnskOTx,p7dwlH1PRStBgyMUW.DOTALL)
				if pwNzhAPx5kYU7MEvXR3siJtQ8jn0H: pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = pwNzhAPx5kYU7MEvXR3siJtQ8jn0H[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				if MVKltEq1hzb6Sm or pwNzhAPx5kYU7MEvXR3siJtQ8jn0H: break
		if not QyG6a4ESNfC3RenMlD1Ttq8:
			if not MVKltEq1hzb6Sm:
				if captcha and not pwNzhAPx5kYU7MEvXR3siJtQ8jn0H:
					if wnaWTQM7VJPkZzO9eoSyFU4: pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = oOqTixpjIEMWe5tRhf7ZL(X50X4rnVuAOlHK,yobpaW7sBqtKRrv(u"ࠩࡤࡶࠬପ"),wRVcBMCyHXUmkapYWsuJlfDEtANiFz)
					else:
						if not piN9Qlah4S.startswith(IMjqygdfYSKpHlWu5Aa(u"ࠪࡍࡉࡃࠧଫ")):
							data = {jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡺࡹࡥࡳࠩବ"):A3pXVFdyP1.AV_CLIENT_IDS,IMjqygdfYSKpHlWu5Aa(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ଭ"):mbvW9By35UDO,jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡵࡳ࡮ࠪମ"):wRVcBMCyHXUmkapYWsuJlfDEtANiFz,GHg28TBchiyn6l(u"ࠧ࡬ࡧࡼࠫଯ"):X50X4rnVuAOlHK,mq5t9JXSdHT8yfDVF(u"ࠨ࡫ࡧࠫର"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࡭ࡳࡧ࠭଱"):beV5l2D8HznyJI0(u"ࠪ࡫ࡪࡺࡩࡥࠩଲ")}
							WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,YYQS36fyPvtuzcEmRL(u"ࠫࡕࡕࡓࡕࠩଳ"),AK90athefUWs7u5mPYpIgNvFzG,data,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠶ࡷ࡬ࠬ଴"))
							piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
						else: piN9Qlah4S = SI7eBdND4lx8pt5Qk(u"࠭ࡉࡅ࠿࠴࠶࠸࠺࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠹࠻ࠧଵ")
						if piN9Qlah4S.startswith(CyHU86ZeYT5BWRcitSm2I(u"ࠧࡊࡆࡀࠫଶ")):
							ttksY4x9HEGWPecfFB = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡋࡇࡁ࠭࠴ࠪࡀࠫ࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽ࠩ࠰࠭ࡃ࠮ࠪࠧଷ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
							yiuTBJqQgR7904WzhfLEsH,QoZYSAMzNs5uHnGEdC7p = ttksY4x9HEGWPecfFB[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
							eJU6bsndE1mI0F = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"๊ࠩิ์ࠦวๅ฻่่๏ฯࠠหฯอหั่ࠦใฬ้๋ࠣࠦ࠱࠱ࠢศ่๎ࠦࠧସ")+QoZYSAMzNs5uHnGEdC7p+pp7FcjEe6g(u"ࠪࠤะอๆ๋หࠪହ")
							QEMTpcCe8tD1S6qbFvluRf = dpY7rMymk2W1Jo()
							QEMTpcCe8tD1S6qbFvluRf.create(pp7FcjEe6g(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ์ู้สࠡสิ๊ฬ๋ฬࠡๅ๋้อ๐่หำࠪ଺"),eJU6bsndE1mI0F)
							C1I3irFwMtY9JmPHEksXfznqvKj = x54xSdnCFHZ8yliofzOBK.time()
							ccS5hdpf04AJtWu2wgVM9,Aom7DscZlv9 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
							while ccS5hdpf04AJtWu2wgVM9<int(QoZYSAMzNs5uHnGEdC7p):
								tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,int(ccS5hdpf04AJtWu2wgVM9/int(QoZYSAMzNs5uHnGEdC7p)*oiWNFYzcIUeh(u"࠲࠲࠳໶")),eJU6bsndE1mI0F,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QoZYSAMzNs5uHnGEdC7p+IMjqygdfYSKpHlWu5Aa(u"ࠬࠦ࠯ࠡࠩ଻")+str(int(ccS5hdpf04AJtWu2wgVM9))+IMjqygdfYSKpHlWu5Aa(u"࠭ࠠࠡอส๊๏ฯ଼ࠧ"))
								if ccS5hdpf04AJtWu2wgVM9>Aom7DscZlv9+aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠳໷"):
									data = {mq5t9JXSdHT8yfDVF(u"ࠧࡶࡵࡨࡶࠬଽ"):A3pXVFdyP1.AV_CLIENT_IDS,VP70ytiFNMBl6vHDaW(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩା"):mbvW9By35UDO,SI7eBdND4lx8pt5Qk(u"ࠩࡸࡶࡱ࠭ି"):wRVcBMCyHXUmkapYWsuJlfDEtANiFz,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪ࡯ࡪࡿࠧୀ"):X50X4rnVuAOlHK,SI7eBdND4lx8pt5Qk(u"ࠫ࡮ࡪࠧୁ"):yiuTBJqQgR7904WzhfLEsH,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡰ࡯ࡣࠩୂ"):A41nqbj3wYt(u"࠭ࡧࡦࡶࡷࡳࡰ࡫࡮ࠨୃ")}
									WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡑࡑࡖࡘࠬୄ"),AK90athefUWs7u5mPYpIgNvFzG,data,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨ୅"))
									piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
									if piN9Qlah4S.startswith(tzZ6PhyDOUnwLM3pdK(u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ୆")):
										pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = piN9Qlah4S.split(KLX7hW0nBAEgy6m4SvH(u"ࠪࡘࡔࡑࡅࡏ࠿ࠪେ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠴໸"))[wnaWTQM7VJPkZzO9eoSyFU4]
										break
									Aom7DscZlv9 = ccS5hdpf04AJtWu2wgVM9
								else: x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
								ccS5hdpf04AJtWu2wgVM9 = x54xSdnCFHZ8yliofzOBK.time()-C1I3irFwMtY9JmPHEksXfznqvKj
							QEMTpcCe8tD1S6qbFvluRf.close()
				if pwNzhAPx5kYU7MEvXR3siJtQ8jn0H:
					bJ1QT3EiPkm2 = WadGEeh1MBIXkpfP38qAv7ryslY.cookies
					QBw1AmI80W5GSuyKe = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ࠭࠴ࠪࡀࠫ࠾ࠫୈ"),ZuVyaGm1oi84CWPKYHtc9UnskOTx,p7dwlH1PRStBgyMUW.DOTALL)
					if bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ୉") in list(bJ1QT3EiPkm2.keys()): QBw1AmI80W5GSuyKe = bJ1QT3EiPkm2[jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭୊")]
					elif QBw1AmI80W5GSuyKe: QBw1AmI80W5GSuyKe = QBw1AmI80W5GSuyKe[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					captcha = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬୋ"),D67S2smgCxbIdO1eULX89lq4,p7dwlH1PRStBgyMUW.DOTALL)
					if captcha: WK9R8J2VhIObEquTzlx0SfYU3,X50X4rnVuAOlHK = captcha[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					if QBw1AmI80W5GSuyKe and captcha:
						headers = {A41nqbj3wYt(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨୌ"):YYQS36fyPvtuzcEmRL(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿୍ࠪ")+QBw1AmI80W5GSuyKe,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ୎"):wRVcBMCyHXUmkapYWsuJlfDEtANiFz,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ୏"):oiWNFYzcIUeh(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ୐")}
						data = tzZ6PhyDOUnwLM3pdK(u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡃࠧ୑")+pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
						WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡑࡑࡖࡘࠬ୒"),WK9R8J2VhIObEquTzlx0SfYU3,data,headers,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠻ࡺࡨࠨ୓"))
						D67S2smgCxbIdO1eULX89lq4 = WadGEeh1MBIXkpfP38qAv7ryslY.content
						try: cookies = WadGEeh1MBIXkpfP38qAv7ryslY.cookies
						except: cookies = {}
						MVKltEq1hzb6Sm = p7dwlH1PRStBgyMUW.findall(beV5l2D8HznyJI0(u"ࠤࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࠯ࠬࡂ࠭ࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ୔"),str(cookies),p7dwlH1PRStBgyMUW.DOTALL)
			if MVKltEq1hzb6Sm:
				fzu7Got0FgiyshTlJK,MVKltEq1hzb6Sm = MVKltEq1hzb6Sm[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				veFLDlXzC8bjfS = fzu7Got0FgiyshTlJK+A41nqbj3wYt(u"ࠪࡁࠬ୕")+MVKltEq1hzb6Sm
				G3yDpvxOiSWdAeL.setSetting(mq5t9JXSdHT8yfDVF(u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬୖ"),veFLDlXzC8bjfS)
				BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢไัฺࠦร็ษࠣษู๋ว็ࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮฮำ่๊ࠣฯอฦอ๊ࠢิฬࠦวๅใะู๊ࠥใ๋ࠢํืฯิฯๆ้สࠤ้ออใษࠣ࠲࠳่ࠦๅษࠣฮําฯࠡฯสะฮࠦไฦ฻สำฮࠦ็ัษࠣห้็อึࠢ็฽ิฯࠠฤึ๊ีࠥࡢ࡮࡝ࡰࠣ฽้๋วࠡล้ࠤ์ึวࠡษ็ๅา฻ࠠิ๊ไࠤ๏ะใาำࠣๅ๏ࠦอศๆฬࠤฯเ๊าࠢิฬ฼ࠦวๅฮ๊หืࠦศศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡวฺๅฬวࠠาษ๋ฮึࠦวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠโื็ࠤุ๊ใࠡษ็ีฬ๎สาࠢ࠱࠲ࠥษ่ࠡษึฮำีวๆ࡙ࠢࡔࡓࠦร้ࠢหีํ้ำ๋ࠩୗ"))
				if beV5l2D8HznyJI0(u"࠭࠮࡮ࡲ࠷ࠫ୘") not in D67S2smgCxbIdO1eULX89lq4:
					headers = {rVy3Ops0mohYkT(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ୙"):veFLDlXzC8bjfS}
					WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,Z9FPQvwlbjLTh(u"ࠨࡉࡈࡘࠬ୚"),wRVcBMCyHXUmkapYWsuJlfDEtANiFz,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠽ࡴࡩࠩ୛"))
					D67S2smgCxbIdO1eULX89lq4 = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if captcha and not QyG6a4ESNfC3RenMlD1Ttq8 and not veFLDlXzC8bjfS: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪๅู๊สࠡ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠ࠯࠰ࠣัฬ๎ไࠡว฼หิฯࠠศๆ฼้้๐ษࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัส้ࠥ์แิࠢส่ๆ๐ฯ๋๊ࠣวํࠦแ๋ัํ์ࠥเ๊า้้๋ࠣࠦๆโีࠣห้๋่ใ฻ࠪଡ଼"))
	return D67S2smgCxbIdO1eULX89lq4
def iiy8cVF7db(url,G3Xh0YWACHFuvQLx5sVEfPjzq7,DIBw28Qfje76bTMzVNYhxrgWmO):
	wxT9bCdumN,pixfvyGY1aJPowKZer34TcNblL7k2 = [],[]
	wRVcBMCyHXUmkapYWsuJlfDEtANiFz = url
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,A6iX18qgyOFlZxz7sc(u"ࠫࡌࡋࡔࠨଢ଼"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ୞"))
	hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ufzIZVUPT4G3kKY8Ovs = []
	if mq5t9JXSdHT8yfDVF(u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧୟ") in hFYoSTas7WOVnwN or oiWNFYzcIUeh(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫୠ") in hFYoSTas7WOVnwN:
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠯ࠬࡂࡀ࠴ࡧ࠾ࠨୡ"),hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
				laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ୢ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for SOw5EUxC9k,title in laAHpo1bzyM0q:
					if SOw5EUxC9k in wxT9bCdumN: continue
					if mq5t9JXSdHT8yfDVF(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫୣ") not in SOw5EUxC9k and Z9FPQvwlbjLTh(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ୤") not in SOw5EUxC9k: continue
					if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬอࠧ୥") not in title:
						ufzIZVUPT4G3kKY8Ovs.append((title,SOw5EUxC9k))
						continue
					title = title.replace(A41nqbj3wYt(u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧ୦"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(KLX7hW0nBAEgy6m4SvH(u"ࠧࠡ࠯ࠣࠫ୧"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
					if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡵࡳࡥࡳ࠭୨") in title: continue
					wxT9bCdumN.append(SOw5EUxC9k)
					pixfvyGY1aJPowKZer34TcNblL7k2.append(title)
			for title,SOw5EUxC9k in ufzIZVUPT4G3kKY8Ovs:
				if SOw5EUxC9k not in wxT9bCdumN:
					wxT9bCdumN.append(SOw5EUxC9k)
					pixfvyGY1aJPowKZer34TcNblL7k2.append(title)
			XFaM94cPUCOWQZNIEe8gdJpny1 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
			if len(wxT9bCdumN)>wnaWTQM7VJPkZzO9eoSyFU4:
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩห฽฻ํวࠡ์ะฮฬาࠠ࠷࠲ࠣฯฬ์๊สࠩ୩"),pixfvyGY1aJPowKZer34TcNblL7k2)
				if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return CyHU86ZeYT5BWRcitSm2I(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୪"),[],[]
			if wxT9bCdumN and XFaM94cPUCOWQZNIEe8gdJpny1>=j0jEZgiKdxFpMLHcU7kQr8v1lyX4: wRVcBMCyHXUmkapYWsuJlfDEtANiFz = wxT9bCdumN[XFaM94cPUCOWQZNIEe8gdJpny1]
	D67S2smgCxbIdO1eULX89lq4 = YNp3IxdBhsRWAMm1XbEG6(wRVcBMCyHXUmkapYWsuJlfDEtANiFz)
	M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn = [],[]
	if G3Xh0YWACHFuvQLx5sVEfPjzq7==iySORMYxWXszEH18(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭୫"):
		VQP5yFM0BDdKoehtEgnXZxN46W = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡨࡴ࡯࠯࡯ࡳࡦࡪࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ୬"),D67S2smgCxbIdO1eULX89lq4,p7dwlH1PRStBgyMUW.DOTALL)
		if VQP5yFM0BDdKoehtEgnXZxN46W:
			SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(VQP5yFM0BDdKoehtEgnXZxN46W[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			ZD0qItXg31HmC7KGEFn.append(DIBw28Qfje76bTMzVNYhxrgWmO)
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==CyHU86ZeYT5BWRcitSm2I(u"࠭ࡷࡢࡶࡦ࡬ࠬ୭"):
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ୮"),D67S2smgCxbIdO1eULX89lq4,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,size in laAHpo1bzyM0q:
			if not SOw5EUxC9k: continue
			if DIBw28Qfje76bTMzVNYhxrgWmO in size:
				ZD0qItXg31HmC7KGEFn.append(size)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
				break
		if not M0MFkiKqJDv1aZ4NA396u:
			for SOw5EUxC9k,size in laAHpo1bzyM0q:
				if not SOw5EUxC9k: continue
				ZD0qItXg31HmC7KGEFn.append(size)
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if not M0MFkiKqJDv1aZ4NA396u: return oiWNFYzcIUeh(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ୯"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def IsHuZ0qpPT(url,fzu7Got0FgiyshTlJK):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,kdRO82AImh0LFw(u"ࠩࡊࡉ࡙࠭୰"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩୱ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cookies = WadGEeh1MBIXkpfP38qAv7ryslY.cookies
	if VP70ytiFNMBl6vHDaW(u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ୲") in list(cookies.keys()):
		veFLDlXzC8bjfS = cookies[iySORMYxWXszEH18(u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ୳")]
		veFLDlXzC8bjfS = EZk136aeLoNqPvlDcTQpyM9Wm(clFjTSgMODe7Nq0H3Vzs(veFLDlXzC8bjfS))
		items = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"࠭ࡲࡰࡷࡷࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୴"),veFLDlXzC8bjfS,p7dwlH1PRStBgyMUW.DOTALL)
		vcQbFfCk6T1 = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(iySORMYxWXszEH18(u"ࠧ࡝࠱ࠪ୵"),VP70ytiFNMBl6vHDaW(u"ࠨ࠱ࠪ୶"))
		vcQbFfCk6T1 = clFjTSgMODe7Nq0H3Vzs(vcQbFfCk6T1)
	else: vcQbFfCk6T1 = url
	if SI7eBdND4lx8pt5Qk(u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ୷") in vcQbFfCk6T1:
		FFJI12Sbzn9TslBfPhGDuCZgyQ = vcQbFfCk6T1.split(bawK2j7T81Nrc4GWs05xzDg(u"ࠪࠩ࠷ࡌࠧ୸"))[-wnaWTQM7VJPkZzO9eoSyFU4]
		vcQbFfCk6T1 = mq5t9JXSdHT8yfDVF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡧࡴࡤࡪ࠱࡭ࡸ࠵ࠧ୹")+FFJI12Sbzn9TslBfPhGDuCZgyQ
		return ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୺"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[vcQbFfCk6T1]
	else:
		website = A3pXVFdyP1.SITESURLS[pp7FcjEe6g(u"࠭ࡁࡌࡑࡄࡑࠬ୻")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡈࡇࡗࠫ୼"),website,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ୽"))
		UYHl04Qo2tpG8Neq = WadGEeh1MBIXkpfP38qAv7ryslY.url
		bxmi2XrK3wpJaC = vcQbFfCk6T1.split(CyHU86ZeYT5BWRcitSm2I(u"ࠩ࠲ࠫ୾"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
		WWOvHmkf0K9MhjY = UYHl04Qo2tpG8Neq.split(wwWzyF4ZpSQXKOgk569(u"ࠪ࠳ࠬ୿"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1.replace(bxmi2XrK3wpJaC,WWOvHmkf0K9MhjY)
		headers = { n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ஀"):WnNGfosHr5STAq8j7miwyRZ6eOUbV , bawK2j7T81Nrc4GWs05xzDg(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ஁"):YYQS36fyPvtuzcEmRL(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧஂ") , tzZ6PhyDOUnwLM3pdK(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨஃ"):QQTfhlZEDnu4wVcOeHGNyCBo5t2 }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,GHg28TBchiyn6l(u"ࠨࡒࡒࡗ࡙࠭஄"), QQTfhlZEDnu4wVcOeHGNyCBo5t2, WnNGfosHr5STAq8j7miwyRZ6eOUbV, headers, KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠸ࡸࡤࠨஅ"))
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		items = p7dwlH1PRStBgyMUW.findall(wwWzyF4ZpSQXKOgk569(u"ࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪஆ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if not items:
			items = p7dwlH1PRStBgyMUW.findall(gPE1XB87fQl(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬஇ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
			if not items:
				items = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠬࡂࡥ࡮ࡤࡨࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬஈ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if items:
			SOw5EUxC9k = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].replace(YYQS36fyPvtuzcEmRL(u"࠭࡜࠰ࠩஉ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࠰ࠩஊ"))
			SOw5EUxC9k = SOw5EUxC9k.rstrip(KLX7hW0nBAEgy6m4SvH(u"ࠨ࠱ࠪ஋"))
			if A6iX18qgyOFlZxz7sc(u"ࠩ࡫ࡸࡹࡶࠧ஌") not in SOw5EUxC9k: SOw5EUxC9k = gPE1XB87fQl(u"ࠪ࡬ࡹࡺࡰ࠻ࠩ஍") + SOw5EUxC9k
			SOw5EUxC9k = SOw5EUxC9k.replace(KLX7hW0nBAEgy6m4SvH(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬஎ"),gPE1XB87fQl(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧஏ"))
			if fzu7Got0FgiyshTlJK==WnNGfosHr5STAq8j7miwyRZ6eOUbV: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
			else: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = tzZ6PhyDOUnwLM3pdK(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩஐ"),[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
		else: QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = GHg28TBchiyn6l(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏࡔࡇࡍࠨ஑"),[],[]
		return QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def ZkQeJBd7CFf(url):
	headers = { KLX7hW0nBAEgy6m4SvH(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬஒ") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭ஓ"))
	items = p7dwlH1PRStBgyMUW.findall(yobpaW7sBqtKRrv(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫஔ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,errno = [],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if items:
		for SOw5EUxC9k,z6PVkLf7Od in items:
			ZD0qItXg31HmC7KGEFn.append(z6PVkLf7Od)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑࠪக"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def uaVKnPWLR5OSBEz(url):
	MXZvtCRTuhcs6VN1K0LOwWDF = url.split(ZLr5gRSkFewKdUos90bM(u"ࠬ࠵ࠧ஖"))[YYQS36fyPvtuzcEmRL(u"࠷໹")]
	data = A41nqbj3wYt(u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠫ࡯ࡤ࠾ࠩ஗")+MXZvtCRTuhcs6VN1K0LOwWDF
	headers = {ZLr5gRSkFewKdUos90bM(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭஘"):lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧங")}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡓࡓࡘ࡚ࠧச"),url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡓࡆࡏ࠱࠶ࡹࡴࠨ஛"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"ࠫࡦࡪࡢ࡭ࡱࡦ࡯ࡤࡪࡥࡵࡧࡦࡸࡪࡪ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨஜ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		url = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	return n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡔࡇࡐࠬ஝"),[],[]
def nCiMvWxNhKz9823XAgoU(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡇࡆࡖࠪஞ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡐ࠳࠱ࡴࡶࠪட"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	try: piN9Qlah4S = piN9Qlah4S.decode(tzZ6PhyDOUnwLM3pdK(u"ࠨࡷࡷࡪ࠽࠭஠"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ஡"))
	except: pass
	items = p7dwlH1PRStBgyMUW.findall(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡨࡴࡩࡳࡠࡰࡲࡣࡵࡸࡥࡷ࡫ࡨࡻࡤࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ஢"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		url = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	else:
		QXqRvTME9DBPsVYmyecrxlI = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࠫࠧࡼࡩࡥࡧࡲࡣࡪࡾࡴࡠ࡯ࡶ࡫ࠧࡄ࡜࡯࠭ࠫ࠲࠯ࡅࠩ࡝ࡰ࠮ࡀࠬண"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if QXqRvTME9DBPsVYmyecrxlI: return QXqRvTME9DBPsVYmyecrxlI[I872Vum45fMNe1BRngTZLoQiqvkt(u"࠵໺")][:mq5t9JXSdHT8yfDVF(u"࠽࠰໻")],[],[]
	return rVy3Ops0mohYkT(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡍࠪத"),[],[]
def nCBD8P510pXuZtV4I(url):
	headers = {jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ஥"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡖࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ஦"))
	items = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭஧"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		url = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬந")+url
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	return SI7eBdND4lx8pt5Qk(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡑࡍࡑࡄࡈࠬன"),[],[]
def avQr4qwgmhzibOentMj(url):
	url = url.strip(kdRO82AImh0LFw(u"ࠫ࠴࠭ப"))
	if A6iX18qgyOFlZxz7sc(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭஫") in url: FFJI12Sbzn9TslBfPhGDuCZgyQ = url.split(ZLr5gRSkFewKdUos90bM(u"࠭࠯ࠨ஬"))[yGLl1nSBrJPmi2adko9O]
	else: FFJI12Sbzn9TslBfPhGDuCZgyQ = url.split(iySORMYxWXszEH18(u"ࠧ࠰ࠩ஭"))[-wnaWTQM7VJPkZzO9eoSyFU4]
	url = A41nqbj3wYt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡧࡸࡺࡲࡦࡣࡰ࠲ࡹࡵ࠯ࡱ࡮ࡤࡽࡪࡸ࠿ࡧ࡫ࡧࡁࠬம") + FFJI12Sbzn9TslBfPhGDuCZgyQ
	headers = { gPE1XB87fQl(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ய") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡄࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬர"))
	piN9Qlah4S = piN9Qlah4S.replace(YYQS36fyPvtuzcEmRL(u"ࠫࡡࡢࠧற"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	items = p7dwlH1PRStBgyMUW.findall(ZLr5gRSkFewKdUos90bM(u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬல"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] ]
	return QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪள"),[],[]
def bbpG2X5HlIyYuj4DdZMNiQrtJn(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧழ"))
	items = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨவ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	for SOw5EUxC9k,z6PVkLf7Od,hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou in items:
		ZD0qItXg31HmC7KGEFn.append(z6PVkLf7Od+kcXMWrwiLDKeBHRsJ+hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou)
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡐ࡜ࡄࠫஶ"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def JJ4vVR2mzbLj(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧஷ"))
	items = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤஸ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	items = set(items)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	for FFJI12Sbzn9TslBfPhGDuCZgyQ,HOkAWvmZSP5c2t9Dq4NgELyps,k0MF7Ho26y9QYV4Rw,z6PVkLf7Od,hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou in items:
		url = ZLr5gRSkFewKdUos90bM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩஹ")+FFJI12Sbzn9TslBfPhGDuCZgyQ+ZLr5gRSkFewKdUos90bM(u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭஺")+HOkAWvmZSP5c2t9Dq4NgELyps+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ஻")+k0MF7Ho26y9QYV4Rw
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠴ࡱࡨࠬ஼"))
		items = p7dwlH1PRStBgyMUW.findall(oiWNFYzcIUeh(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ஽"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k in items:
			ZD0qItXg31HmC7KGEFn.append(z6PVkLf7Od+kcXMWrwiLDKeBHRsJ+hDiVPLW8Yyv3ZRaF4qUB1jSrxMf6ou)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if len(M0MFkiKqJDv1aZ4NA396u)==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: return KLX7hW0nBAEgy6m4SvH(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐࠩா"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def UefPNgnro8DbIjES(url):
	SOw5EUxC9k = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if tzZ6PhyDOUnwLM3pdK(u"ࠫࡐ࡫ࡹ࠾ࠩி") not in url:
		vcQbFfCk6T1 = url.replace(CyHU86ZeYT5BWRcitSm2I(u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩீ"),wwWzyF4ZpSQXKOgk569(u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪு"))
		vcQbFfCk6T1 = vcQbFfCk6T1.split(VP70ytiFNMBl6vHDaW(u"ࠧ࠰ࠩூ"))
		FFJI12Sbzn9TslBfPhGDuCZgyQ = vcQbFfCk6T1[vXIdY7TwFKso40gVBq5]
		vcQbFfCk6T1 = GHg28TBchiyn6l(u"ࠨ࠱ࠪ௃").join(vcQbFfCk6T1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:yGLl1nSBrJPmi2adko9O])
		rLqYZOtwMfBVs4k1TpE3X9aDy = {kdRO82AImh0LFw(u"ࠩ࡬ࡨࠬ௄"):FFJI12Sbzn9TslBfPhGDuCZgyQ,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡳࡵ࠭௅"):oiWNFYzcIUeh(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧெ"),ZLr5gRSkFewKdUos90bM(u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪே"):eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭ை")}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,A41nqbj3wYt(u"ࠧࡑࡑࡖࡘࠬ௉"),vcQbFfCk6T1,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠵ࡸࡺࠧொ"))
		SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers.get(A6iX18qgyOFlZxz7sc(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫோ")) or WadGEeh1MBIXkpfP38qAv7ryslY.headers.get(mq5t9JXSdHT8yfDVF(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬௌ")) or WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if not SOw5EUxC9k and WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࡮ࡪ࠽ࠣࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ்"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k: SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,VP70ytiFNMBl6vHDaW(u"ࠬࡍࡅࡕࠩ௎"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ௏"))
		SOw5EUxC9k = WadGEeh1MBIXkpfP38qAv7ryslY.headers.get(pp7FcjEe6g(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩௐ")) or WadGEeh1MBIXkpfP38qAv7ryslY.headers.get(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ௑")) or WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if SOw5EUxC9k: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	return rVy3Ops0mohYkT(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡖࡂࡐࡏࠪ௒"),[],[]
def KT7sdi3LQnh56FIvlUbS(url):
	headers = { Z9FPQvwlbjLTh(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ௓") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡋࡌ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭௔"))
	items = p7dwlH1PRStBgyMUW.findall(SI7eBdND4lx8pt5Qk(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦ࠭࠴ࠪࡀࠫࠥࠫ௕"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	if items:
		ZD0qItXg31HmC7KGEFn.append(wwWzyF4ZpSQXKOgk569(u"࠭࡭ࡱ࠶ࠪ௖"))
		M0MFkiKqJDv1aZ4NA396u.append(items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4])
		ZD0qItXg31HmC7KGEFn.append(CyHU86ZeYT5BWRcitSm2I(u"ࠧ࡮࠵ࡸ࠼ࠬௗ"))
		M0MFkiKqJDv1aZ4NA396u.append(items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
	else: return rVy3Ops0mohYkT(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡐࡎࡏࡖࡊࡆࡈࡓࠬ௘"),[],[]
def wt1ioc4DP2GHQkNjhRFZ(url):
	ccTkBdXWjqn0OlKbPE4Uo = url.split(bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࠲ࠫ௙"))[-wnaWTQM7VJPkZzO9eoSyFU4]
	ccTkBdXWjqn0OlKbPE4Uo = ccTkBdXWjqn0OlKbPE4Uo.split(KLX7hW0nBAEgy6m4SvH(u"ࠪࠪࠬ௚"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	ccTkBdXWjqn0OlKbPE4Uo = ccTkBdXWjqn0OlKbPE4Uo.replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭௛"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	llRGrMKUZay91WzY0AXIF = A3pXVFdyP1.SITESURLS[VP70ytiFNMBl6vHDaW(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭௜")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+A6iX18qgyOFlZxz7sc(u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ௝")+ccTkBdXWjqn0OlKbPE4Uo
	dmrEqRnX4VTBQZcAtJoa6f = pp7FcjEe6g(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ௞")+ccTkBdXWjqn0OlKbPE4Uo
	BBfE5nyUDhY1uHxVFgXr,wwdXlMFUWhLDexN1cG8zTQ = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	wMtyK9GSHVCpOscaAli8243v = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	Nwr2fez5g1iRWV9qc4MF6UYOsbZDt,q5aXr4KvC2tAxhGz3wJkUydBWonmV = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{}
	g0OjAHcySZL9UrElfGeV4tmxoaz,IqhkQAUWP7tbTC9 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{}
	headers = {beV5l2D8HznyJI0(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ௟"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	if j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
		AzFVxh3NpuQfrdobnjSmGE4OkIKBX = oiWNFYzcIUeh(u"࠱໼")
		for zuEo6GDeAR5Z in range(AzFVxh3NpuQfrdobnjSmGE4OkIKBX):
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,mq5t9JXSdHT8yfDVF(u"ࠩࡊࡉ࡙࠭௠"),llRGrMKUZay91WzY0AXIF,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ௡"))
			piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		wwLkBzRnF32Zse1VKCoQuX4htlHyb = p7dwlH1PRStBgyMUW.findall(ZLr5gRSkFewKdUos90bM(u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ௢"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		Nwr2fez5g1iRWV9qc4MF6UYOsbZDt = wwLkBzRnF32Zse1VKCoQuX4htlHyb[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if wwLkBzRnF32Zse1VKCoQuX4htlHyb else piN9Qlah4S
		q5aXr4KvC2tAxhGz3wJkUydBWonmV = IXZpzK7ShaRsAN(mq5t9JXSdHT8yfDVF(u"ࠬࡪࡩࡤࡶࠪ௣"),Nwr2fez5g1iRWV9qc4MF6UYOsbZDt)
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,IMjqygdfYSKpHlWu5Aa(u"࠭ࡇࡆࡖࠪ௤"),llRGrMKUZay91WzY0AXIF,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠻ࡺࡨࠨ௥"))
		wMtyK9GSHVCpOscaAli8243v = WadGEeh1MBIXkpfP38qAv7ryslY.content
		Hl2Y1sF4Zvapx,PfDlkWydu5ITbRqgtNCwSpLxVBa7cM = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		kaUQcRXVvozDAtb9GxulefL1rNm = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ௦"),wMtyK9GSHVCpOscaAli8243v,p7dwlH1PRStBgyMUW.DOTALL)
		if kaUQcRXVvozDAtb9GxulefL1rNm:
			kaUQcRXVvozDAtb9GxulefL1rNm = A3pXVFdyP1.SITESURLS[YYQS36fyPvtuzcEmRL(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ௧")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+kaUQcRXVvozDAtb9GxulefL1rNm[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,GHg28TBchiyn6l(u"ࠪࡋࡊ࡚ࠧ௨"),kaUQcRXVvozDAtb9GxulefL1rNm,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠺ࡷ࡬ࠬ௩"))
			Hl2Y1sF4Zvapx = WadGEeh1MBIXkpfP38qAv7ryslY.content
			UVdQPfFg8jbtMlwiu7ET = p7dwlH1PRStBgyMUW.search(bawK2j7T81Nrc4GWs05xzDg(u"ࡷ࠭ࠨࡀ࠼ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࡼࡴࡶࡶ࠭ࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡅࡐ࠽ࡵࡷࡷࡃࡡ࠰࠮࠻ࡠࡿ࠺ࢃࠩࠨ௪"), Hl2Y1sF4Zvapx)
			PfDlkWydu5ITbRqgtNCwSpLxVBa7cM = UVdQPfFg8jbtMlwiu7ET.group(kdRO82AImh0LFw(u"࠭ࡳࡵࡵࠪ௫"))
			PfDlkWydu5ITbRqgtNCwSpLxVBa7cM = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧ࠳࠲࠶࠸࠽࠭௬")
			kaUQcRXVvozDAtb9GxulefL1rNm = CyHU86ZeYT5BWRcitSm2I(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࠰࠱࠲࠷ࡨࡪ࠺࠲࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠࡗࡖ࠳ࡧࡧࡳࡦ࠰࡭ࡷࠬ௭")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,yobpaW7sBqtKRrv(u"ࠩࡊࡉ࡙࠭௮"),kaUQcRXVvozDAtb9GxulefL1rNm,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠺ࡶ࡫ࠫ௯"))
			Hl2Y1sF4Zvapx = WadGEeh1MBIXkpfP38qAv7ryslY.content
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = A3pXVFdyP1.SITESURLS[mq5t9JXSdHT8yfDVF(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ௰")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+wwWzyF4ZpSQXKOgk569(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡵࡲࡡࡺࡧࡵࡃࡵࡸࡥࡵࡶࡼࡔࡷ࡯࡮ࡵ࠿ࡩࡥࡱࡹࡥࠨ௱")
		Pm5ahXnkEMeN4K6tsFL = G3yDpvxOiSWdAeL.getSetting(ZLr5gRSkFewKdUos90bM(u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ௲"))
		if Pm5ahXnkEMeN4K6tsFL.count(KLX7hW0nBAEgy6m4SvH(u"ࠧ࠻࠼࠽ࠫ௳"))==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵໽"):
			bbtlZdiH7PUvNyFY2AjnMEh0,key,nASIK1shLvYcfNW,PUu3nbeYDvfHS,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = Pm5ahXnkEMeN4K6tsFL.split(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࠼࠽࠾ࠬ௴"))
			headers[kdRO82AImh0LFw(u"࡛ࠩ࠱ࡌࡵ࡯ࡨ࠯࡙࡭ࡸ࡯ࡴࡰࡴ࠰ࡍࡩ࠭௵")] = bbtlZdiH7PUvNyFY2AjnMEh0
		headers[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ௶")] = ZLr5gRSkFewKdUos90bM(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧ௷")
		if wnaWTQM7VJPkZzO9eoSyFU4:
			KnEazvPsXD8IGpThxi96Lfb = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࢁࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡗ࡚ࡍ࡚ࡍࡍ࠷ࠥ࠰ࠥࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠺࠲࠷࠶࠲࠶࠲࠼࠴࠷࠴࠰࠹࠰࠳࠴ࠧࢃࡽ࠭ࠢࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨ௸")+ccTkBdXWjqn0OlKbPE4Uo+bawK2j7T81Nrc4GWs05xzDg(u"࠭ࠢ࠭ࠢࠥࡴࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡳࡳࡺࡥ࡯ࡶࡓࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡘ࡮ࡳࡥࡴࡶࡤࡱࡵࠨ࠺ࠡࠩ௹")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡾࡿࢀࠫ௺")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,mq5t9JXSdHT8yfDVF(u"ࠨࡒࡒࡗ࡙࠭௻"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ௼"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ௽") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				Nwr2fez5g1iRWV9qc4MF6UYOsbZDt = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(IMjqygdfYSKpHlWu5Aa(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬ௾"),tzZ6PhyDOUnwLM3pdK(u"ࠬࠬࠧ௿"))
				q5aXr4KvC2tAxhGz3wJkUydBWonmV = IXZpzK7ShaRsAN(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡤࡪࡥࡷࠫఀ"),Nwr2fez5g1iRWV9qc4MF6UYOsbZDt)
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			KnEazvPsXD8IGpThxi96Lfb = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡼࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼࡙ࠣࠦ࡜ࡈࡕࡏࡏ࠹ࡤ࡙ࡉࡎࡒࡏ࡝ࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠶࠴࠰ࠣࡿࢀ࠰ࠥࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫఁ")+ccTkBdXWjqn0OlKbPE4Uo+rVy3Ops0mohYkT(u"ࠨࠤ࠯ࠤࠧࡶ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡵ࡮ࡵࡧࡱࡸࡕࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࠣ࠼ࠣࠫం")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+oiWNFYzcIUeh(u"ࠩࢀࢁࢂ࠭ః")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡔࡔ࡙ࡔࠨఄ"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬఅ"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if oiWNFYzcIUeh(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬఆ") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				Nwr2fez5g1iRWV9qc4MF6UYOsbZDt = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧఇ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠧࠧࠩఈ"))
				q5aXr4KvC2tAxhGz3wJkUydBWonmV = IXZpzK7ShaRsAN(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡦ࡬ࡧࡹ࠭ఉ"),Nwr2fez5g1iRWV9qc4MF6UYOsbZDt)
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			KnEazvPsXD8IGpThxi96Lfb = A41nqbj3wYt(u"ࠩࡾࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠥࠨࡉࡐࡕࠥ࠰ࠥࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠴࠳࠷࠰࠯࠶ࠥࢁࢂ࠲ࠠࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ఊ")+ccTkBdXWjqn0OlKbPE4Uo+A6iX18qgyOFlZxz7sc(u"ࠪࠦ࠱ࠦࠢࡱ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣࡰࡰࡷࡩࡳࡺࡐ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡹࡩࡨࡰࡤࡸࡺࡸࡥࡕ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠥ࠾ࠥ࠭ఋ")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+kdRO82AImh0LFw(u"ࠫࢂࢃࡽࠨఌ")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,CyHU86ZeYT5BWRcitSm2I(u"ࠬࡖࡏࡔࡖࠪ఍"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠷ࡷࡪࠧఎ"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if CyHU86ZeYT5BWRcitSm2I(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧఏ") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				g0OjAHcySZL9UrElfGeV4tmxoaz = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(iySORMYxWXszEH18(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩఐ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࠩࠫ఑"))
				IqhkQAUWP7tbTC9 = IXZpzK7ShaRsAN(yobpaW7sBqtKRrv(u"ࠪࡨ࡮ࡩࡴࠨఒ"),g0OjAHcySZL9UrElfGeV4tmxoaz)
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and wwWzyF4ZpSQXKOgk569(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫఓ") not in Nwr2fez5g1iRWV9qc4MF6UYOsbZDt:
			Nwr2fez5g1iRWV9qc4MF6UYOsbZDt,q5aXr4KvC2tAxhGz3wJkUydBWonmV,q5aXr4KvC2tAxhGz3wJkUydBWonmV = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{},{}
			KnEazvPsXD8IGpThxi96Lfb = A41nqbj3wYt(u"ࠬࢁࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡐ࡛ࡊࡈࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠲࠯࠴࠳࠶࠺࠶࠳࠲࠳࠱࠴࠸࠴࠰࠱ࠤࢀࢁ࠱ࠦࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬఔ")+ccTkBdXWjqn0OlKbPE4Uo+mq5t9JXSdHT8yfDVF(u"࠭ࠢ࠭ࠢࠥࡴࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡳࡳࡺࡥ࡯ࡶࡓࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡘ࡮ࡳࡥࡴࡶࡤࡱࡵࠨ࠺ࠡࠩక")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+tzZ6PhyDOUnwLM3pdK(u"ࠧࡾࡿࢀࠫఖ")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡒࡒࡗ࡙࠭గ"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠴ࡵࡪࠪఘ"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if rVy3Ops0mohYkT(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪఙ") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				Nwr2fez5g1iRWV9qc4MF6UYOsbZDt = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(IMjqygdfYSKpHlWu5Aa(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬచ"),A41nqbj3wYt(u"ࠬࠬࠧఛ"))
				q5aXr4KvC2tAxhGz3wJkUydBWonmV = IXZpzK7ShaRsAN(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡤࡪࡥࡷࠫజ"),Nwr2fez5g1iRWV9qc4MF6UYOsbZDt)
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧఝ") not in Nwr2fez5g1iRWV9qc4MF6UYOsbZDt:
			Nwr2fez5g1iRWV9qc4MF6UYOsbZDt,q5aXr4KvC2tAxhGz3wJkUydBWonmV,q5aXr4KvC2tAxhGz3wJkUydBWonmV = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{},{}
			KnEazvPsXD8IGpThxi96Lfb = A41nqbj3wYt(u"ࠨࡽࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧ࡝ࡅࡃࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠴࠱࠶࠵࠸࠵࠱࠻࠳࠷࠳࠶࠴࠯࠲࠳ࠦࢂࢃࠬࠡࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧఞ")+ccTkBdXWjqn0OlKbPE4Uo+beV5l2D8HznyJI0(u"ࠩࠥ࠰ࠥࠨࡰ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡯࡯ࡶࡨࡲࡹࡖ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠤ࠽ࠤࠬట")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+rVy3Ops0mohYkT(u"ࠪࢁࢂࢃࠧఠ")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡕࡕࡓࡕࠩడ"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠷ࡸ࡭࠭ఢ"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ణ") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				Nwr2fez5g1iRWV9qc4MF6UYOsbZDt = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(mq5t9JXSdHT8yfDVF(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨత"),tzZ6PhyDOUnwLM3pdK(u"ࠨࠨࠪథ"))
				q5aXr4KvC2tAxhGz3wJkUydBWonmV = IXZpzK7ShaRsAN(bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡧ࡭ࡨࡺࠧద"),Nwr2fez5g1iRWV9qc4MF6UYOsbZDt)
		if wnaWTQM7VJPkZzO9eoSyFU4 and jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪధ") not in g0OjAHcySZL9UrElfGeV4tmxoaz:
			g0OjAHcySZL9UrElfGeV4tmxoaz,IqhkQAUWP7tbTC9,IqhkQAUWP7tbTC9 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{},{}
			KnEazvPsXD8IGpThxi96Lfb = VP70ytiFNMBl6vHDaW(u"ࠫࢀࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡃࡑࡈࡗࡕࡉࡅࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠴࠳࠲࠶࠶࠮࠴࠺ࠥࢁࢂ࠲ࠠࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭న")+ccTkBdXWjqn0OlKbPE4Uo+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࠨࠬࠡࠤࡳࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥࡲࡲࡹ࡫࡮ࡵࡒ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡗ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠧࡀࠠࠨ఩")+PfDlkWydu5ITbRqgtNCwSpLxVBa7cM+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡽࡾࡿࠪప")
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,A6iX18qgyOFlZxz7sc(u"ࠧࡑࡑࡖࡘࠬఫ"),QQTfhlZEDnu4wVcOeHGNyCBo5t2,KnEazvPsXD8IGpThxi96Lfb,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠻ࡴࡩࠩబ"))
			wwLkBzRnF32Zse1VKCoQuX4htlHyb = WadGEeh1MBIXkpfP38qAv7ryslY.content
			if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩభ") in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
				g0OjAHcySZL9UrElfGeV4tmxoaz = wwLkBzRnF32Zse1VKCoQuX4htlHyb.replace(yobpaW7sBqtKRrv(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫమ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࠫ࠭య"))
				IqhkQAUWP7tbTC9 = IXZpzK7ShaRsAN(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡪࡩࡤࡶࠪర"),g0OjAHcySZL9UrElfGeV4tmxoaz)
	yBMI0J8cEgVp3kPZhoqQTOR9C,sCVSYBWKDeGfAiNOIUutgmQjLRJlb,qqZSMQwtl9LDC,gNXYcSiPB2Jn = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	QQGua3kUtXJWZdSjVngs,luLJBPNsyU2MZf1AV3wSjm8K6D7c,GTms0owuLcJdD4yeKq2vrtnlY,ee7oJUWGOTbhizpqcw5LPE = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	try: sCVSYBWKDeGfAiNOIUutgmQjLRJlb = q5aXr4KvC2tAxhGz3wJkUydBWonmV[aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ఱ")][YYQS36fyPvtuzcEmRL(u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨల")]
	except: pass
	try: luLJBPNsyU2MZf1AV3wSjm8K6D7c = IqhkQAUWP7tbTC9[wwWzyF4ZpSQXKOgk569(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨళ")][ZLr5gRSkFewKdUos90bM(u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪఴ")]
	except: pass
	try: yBMI0J8cEgVp3kPZhoqQTOR9C = q5aXr4KvC2tAxhGz3wJkUydBWonmV[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪవ")][n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭శ")]
	except: pass
	try: QQGua3kUtXJWZdSjVngs = IqhkQAUWP7tbTC9[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬష")][mq5t9JXSdHT8yfDVF(u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨస")]
	except: pass
	try: qqZSMQwtl9LDC = q5aXr4KvC2tAxhGz3wJkUydBWonmV[bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧహ")][ZLr5gRSkFewKdUos90bM(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ఺")]
	except: pass
	try: GTms0owuLcJdD4yeKq2vrtnlY = IqhkQAUWP7tbTC9[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ఻")][kdRO82AImh0LFw(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶ఼ࠫ")]
	except: pass
	try: gNXYcSiPB2Jn = q5aXr4KvC2tAxhGz3wJkUydBWonmV[A6iX18qgyOFlZxz7sc(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫఽ")][GHg28TBchiyn6l(u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧా")]
	except: pass
	try: ee7oJUWGOTbhizpqcw5LPE = IqhkQAUWP7tbTC9[pp7FcjEe6g(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ి")][bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩీ")]
	except: pass
	if not any([sCVSYBWKDeGfAiNOIUutgmQjLRJlb,luLJBPNsyU2MZf1AV3wSjm8K6D7c,yBMI0J8cEgVp3kPZhoqQTOR9C,QQGua3kUtXJWZdSjVngs,qqZSMQwtl9LDC,GTms0owuLcJdD4yeKq2vrtnlY,gNXYcSiPB2Jn,ee7oJUWGOTbhizpqcw5LPE]):
		hJaCboEre4Tc6AW8Uz = p7dwlH1PRStBgyMUW.findall(ZLr5gRSkFewKdUos90bM(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫు"),wMtyK9GSHVCpOscaAli8243v,p7dwlH1PRStBgyMUW.DOTALL)
		gEbImLX6aAO28D3Pxo5ehjnvu = p7dwlH1PRStBgyMUW.findall(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪూ"),wMtyK9GSHVCpOscaAli8243v,p7dwlH1PRStBgyMUW.DOTALL)
		WXZ4HTO7PSFmMp = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩృ"),wMtyK9GSHVCpOscaAli8243v,p7dwlH1PRStBgyMUW.DOTALL)
		Sf8YkqeAlUxWwMvyuiQGL = p7dwlH1PRStBgyMUW.findall(SI7eBdND4lx8pt5Qk(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ౄ"),wMtyK9GSHVCpOscaAli8243v,p7dwlH1PRStBgyMUW.DOTALL)
		Xr8UON3oicm9DQtz2gwphG,VV4R3JGFnLZyeXfS9vblBwdxPc,YJWqljp9Feu5chVnK1QOUG64wR8B = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		try: Xr8UON3oicm9DQtz2gwphG = q5aXr4KvC2tAxhGz3wJkUydBWonmV[A41nqbj3wYt(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ౅")][GHg28TBchiyn6l(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫె")][VP70ytiFNMBl6vHDaW(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨే")][A6iX18qgyOFlZxz7sc(u"ࠨࡶ࡬ࡸࡱ࡫ࠧై")][eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡵࡹࡳࡹࠧ౉")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][gPE1XB87fQl(u"ࠪࡸࡪࡾࡴࠨొ")]
		except:
			try: Xr8UON3oicm9DQtz2gwphG = IqhkQAUWP7tbTC9[beV5l2D8HznyJI0(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨో")][eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪౌ")][A6iX18qgyOFlZxz7sc(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸ్ࠧ")][kdRO82AImh0LFw(u"ࠧࡵ࡫ࡷࡰࡪ࠭౎")][wwWzyF4ZpSQXKOgk569(u"ࠨࡴࡸࡲࡸ࠭౏")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][tzZ6PhyDOUnwLM3pdK(u"ࠩࡷࡩࡽࡺࠧ౐")]
			except: pass
		try: VV4R3JGFnLZyeXfS9vblBwdxPc = q5aXr4KvC2tAxhGz3wJkUydBWonmV[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ౑")][gPE1XB87fQl(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ౒")][yobpaW7sBqtKRrv(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭౓")][aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ౔")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][KLX7hW0nBAEgy6m4SvH(u"ࠧࡳࡷࡱࡷౕࠬ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][kdRO82AImh0LFw(u"ࠨࡶࡨࡼࡹౖ࠭")]
		except:
			try: VV4R3JGFnLZyeXfS9vblBwdxPc = IqhkQAUWP7tbTC9[VP70ytiFNMBl6vHDaW(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭౗")][IMjqygdfYSKpHlWu5Aa(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨౘ")][gPE1XB87fQl(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬౙ")][n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭ౚ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][Z9FPQvwlbjLTh(u"࠭ࡲࡶࡰࡶࠫ౛")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][mq5t9JXSdHT8yfDVF(u"ࠧࡵࡧࡻࡸࠬ౜")]
			except: pass
		try: YJWqljp9Feu5chVnK1QOUG64wR8B = q5aXr4KvC2tAxhGz3wJkUydBWonmV[SI7eBdND4lx8pt5Qk(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬౝ")][IMjqygdfYSKpHlWu5Aa(u"ࠩࡵࡩࡦࡹ࡯࡯ࠩ౞")]
		except:
			try: YJWqljp9Feu5chVnK1QOUG64wR8B = IqhkQAUWP7tbTC9[Z9FPQvwlbjLTh(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ౟")][yobpaW7sBqtKRrv(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫౠ")]
			except: pass
		FsNzw4Y0MvnOrADE3 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		KAERLoJMu7rhvlbn5X0N = e6HEdvUcaq8Gx+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮࠦ࠮࠯ࠢฦ์ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣ࠲࠳ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢํัฯอฬࠡึํล๋ࠥอะัࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢ฽๎ึࠦโศัิࠤศ์๋ࠠึ฽่ࠥอไโ์า๎ํࠦวๅฤ้ࠫౡ")+YVr6St5P4xsFC0aARQGKfiegD
		if hJaCboEre4Tc6AW8Uz or gEbImLX6aAO28D3Pxo5ehjnvu or WXZ4HTO7PSFmMp or Sf8YkqeAlUxWwMvyuiQGL or Xr8UON3oicm9DQtz2gwphG or VV4R3JGFnLZyeXfS9vblBwdxPc or YJWqljp9Feu5chVnK1QOUG64wR8B:
			if   hJaCboEre4Tc6AW8Uz: eJU6bsndE1mI0F = hJaCboEre4Tc6AW8Uz[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			elif gEbImLX6aAO28D3Pxo5ehjnvu: eJU6bsndE1mI0F = gEbImLX6aAO28D3Pxo5ehjnvu[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			elif WXZ4HTO7PSFmMp: eJU6bsndE1mI0F = WXZ4HTO7PSFmMp[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			elif Sf8YkqeAlUxWwMvyuiQGL: eJU6bsndE1mI0F = Sf8YkqeAlUxWwMvyuiQGL[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			elif Xr8UON3oicm9DQtz2gwphG: eJU6bsndE1mI0F = Xr8UON3oicm9DQtz2gwphG
			elif VV4R3JGFnLZyeXfS9vblBwdxPc: eJU6bsndE1mI0F = VV4R3JGFnLZyeXfS9vblBwdxPc
			elif YJWqljp9Feu5chVnK1QOUG64wR8B: eJU6bsndE1mI0F = YJWqljp9Feu5chVnK1QOUG64wR8B
			FsNzw4Y0MvnOrADE3 = eJU6bsndE1mI0F.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			KAERLoJMu7rhvlbn5X0N += yobpaW7sBqtKRrv(u"࠭࡜࡯࡞ࡱࠫౢ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧาีส่ฮࠦๅ็ࠢํ์ฯ๐่ษࠩౣ")+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M+FsNzw4Y0MvnOrADE3
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ౤"),KAERLoJMu7rhvlbn5X0N)
		if FsNzw4Y0MvnOrADE3: FsNzw4Y0MvnOrADE3 = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࠽ࠤࠬ౥")+FsNzw4Y0MvnOrADE3
		return XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ౦")+FsNzw4Y0MvnOrADE3,[],[]
	rLPm5uR346Gjv1,MwV1codKPWNlj0RvCpmGIQt7his,yplXkNnjdvWA7MHBhsqIwegPO = [],[],[]
	AoTXcMnOym5ur7PlKGDsp = [sCVSYBWKDeGfAiNOIUutgmQjLRJlb,luLJBPNsyU2MZf1AV3wSjm8K6D7c]
	VD19ZeQIfgUWXl4jcvnM3K6C = [yBMI0J8cEgVp3kPZhoqQTOR9C,QQGua3kUtXJWZdSjVngs]
	kKibU78Vp1CHjft3I,BkSQwqO1Lb0iKM8ITV6e7HDh = [],[]
	for nWl9L4irPZkUt3eXN in qqZSMQwtl9LDC+GTms0owuLcJdD4yeKq2vrtnlY:
		if nWl9L4irPZkUt3eXN[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࡮ࡺࡡࡨࠩ౧")] not in kKibU78Vp1CHjft3I:
			kKibU78Vp1CHjft3I.append(nWl9L4irPZkUt3eXN[beV5l2D8HznyJI0(u"ࠬ࡯ࡴࡢࡩࠪ౨")])
			BkSQwqO1Lb0iKM8ITV6e7HDh.append(nWl9L4irPZkUt3eXN)
	kKibU78Vp1CHjft3I,lmH4GeFBac = [],[]
	for nWl9L4irPZkUt3eXN in gNXYcSiPB2Jn+ee7oJUWGOTbhizpqcw5LPE:
		if nWl9L4irPZkUt3eXN[yobpaW7sBqtKRrv(u"࠭ࡩࡵࡣࡪࠫ౩")] not in kKibU78Vp1CHjft3I:
			kKibU78Vp1CHjft3I.append(nWl9L4irPZkUt3eXN[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡪࡶࡤ࡫ࠬ౪")])
			lmH4GeFBac.append(nWl9L4irPZkUt3eXN)
	for dict in BkSQwqO1Lb0iKM8ITV6e7HDh+lmH4GeFBac:
		if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡷࡵࡰࠬ౫") not in list(dict.keys()): continue
		if pp7FcjEe6g(u"ࠩ࡬ࡸࡦ࡭ࠧ౬") in list(dict.keys()): dict[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࡭ࡹࡧࡧࠨ౭")] = str(dict[A6iX18qgyOFlZxz7sc(u"ࠫ࡮ࡺࡡࡨࠩ౮")])
		if wwWzyF4ZpSQXKOgk569(u"ࠬ࡬ࡰࡴࠩ౯") in list(dict.keys()): dict[ZLr5gRSkFewKdUos90bM(u"࠭ࡦࡱࡵࠪ౰")] = str(dict[wwWzyF4ZpSQXKOgk569(u"ࠧࡧࡲࡶࠫ౱")])
		if GHg28TBchiyn6l(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ౲") in list(dict.keys()): dict[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡷࡽࡵ࡫ࠧ౳")] = dict[A41nqbj3wYt(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ౴")]
		if rVy3Ops0mohYkT(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭౵") in list(dict.keys()): dict[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ౶")] = str(dict[SI7eBdND4lx8pt5Qk(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ౷")])
		if oiWNFYzcIUeh(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ౸") in list(dict.keys()): dict[ZLr5gRSkFewKdUos90bM(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ౹")] = str(dict[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ౺")])
		if bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡻ࡮ࡪࡴࡩࠩ౻") in list(dict.keys()): dict[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡸ࡯ࡺࡦࠩ౼")] = str(dict[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡽࡩࡥࡶ࡫ࠫ౽")])+GHg28TBchiyn6l(u"࠭ࡸࠨ౾")+str(dict[wwWzyF4ZpSQXKOgk569(u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ౿")])
		if GHg28TBchiyn6l(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫಀ") in list(dict.keys()): dict[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࡬ࡲ࡮ࡺࠧಁ")] = dict[oiWNFYzcIUeh(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭ಂ")][pp7FcjEe6g(u"ࠫࡸࡺࡡࡳࡶࠪಃ")]+ZLr5gRSkFewKdUos90bM(u"ࠬ࠳ࠧ಄")+dict[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩಅ")][YYQS36fyPvtuzcEmRL(u"ࠧࡦࡰࡧࠫಆ")]
		if gPE1XB87fQl(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬಇ") in list(dict.keys()): dict[beV5l2D8HznyJI0(u"ࠩ࡬ࡲࡩ࡫ࡸࠨಈ")] = dict[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧಉ")][A41nqbj3wYt(u"ࠫࡸࡺࡡࡳࡶࠪಊ")]+A41nqbj3wYt(u"ࠬ࠳ࠧಋ")+dict[ZLr5gRSkFewKdUos90bM(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪಌ")][CyHU86ZeYT5BWRcitSm2I(u"ࠧࡦࡰࡧࠫ಍")]
		if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩಎ") in list(dict.keys()): dict[A6iX18qgyOFlZxz7sc(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪಏ")] = dict[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫಐ")]
		if A41nqbj3wYt(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ಑") in list(dict.keys()) and int(dict[KLX7hW0nBAEgy6m4SvH(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ಒ")])>yobpaW7sBqtKRrv(u"࠳࠴࠵࠷࠸࠲࠴࠵࠶໾"): del dict[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧಓ")]
		if SI7eBdND4lx8pt5Qk(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩಔ") in list(dict.keys()):
			l8JSofyzOs = dict[wwWzyF4ZpSQXKOgk569(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪಕ")].split(beV5l2D8HznyJI0(u"ࠩࠩࠫಖ"))
			for N6NV3h4fel in l8JSofyzOs:
				key,value = N6NV3h4fel.split(CyHU86ZeYT5BWRcitSm2I(u"ࠪࡁࠬಗ"),kdRO82AImh0LFw(u"࠴໿"))
				dict[key] = EZk136aeLoNqPvlDcTQpyM9Wm(value)
		rLPm5uR346Gjv1.append(dict)
	if Hl2Y1sF4Zvapx:
		if A6iX18qgyOFlZxz7sc(u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫಘ") in Nwr2fez5g1iRWV9qc4MF6UYOsbZDt+g0OjAHcySZL9UrElfGeV4tmxoaz:
			try:
				import youtube_signature.cipher as Nsp6JmVB2ti4DRg3yYjP7z,youtube_signature.json_script_engine as k13LwOxhjle68Euf7naQN
				l8JSofyzOs = fZblnwz1UO.l8JSofyzOs.Cipher()
				l8JSofyzOs._object_cache = {}
				IgEjAWVTBfqxonbZH1tQFY82vLJ = l8JSofyzOs._load_javascript(Hl2Y1sF4Zvapx)
				msBzfNa8E7Yi0VpSxhv4r = IXZpzK7ShaRsAN(gPE1XB87fQl(u"ࠬࡹࡴࡳࠩಙ"),str(IgEjAWVTBfqxonbZH1tQFY82vLJ))
				SptW5xwf6T7qF4U1YRg9LlKdIvoP = fZblnwz1UO.ylmPCczM8JiqYUS70dR.JsonScriptEngine(msBzfNa8E7Yi0VpSxhv4r)
			except: pass
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			qJNvjYrwTebdh9IXunozRW8 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			o75XilFP8eDpAS30ZQuGdjOrynHqmx = p7dwlH1PRStBgyMUW.findall(
				XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࡸࠧࠨࠩࠫࡃࡽ࠯ࠊࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏ࡜࠯ࡩࡨࡸࡡ࠮ࠢ࡯ࠤ࡟࠭ࡡ࠯ࠦࠧ࡞ࠫࡦࡂࢂࠊࠊࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉࠊࡤࡀࡗࡹࡸࡩ࡯ࡩ࡟࠲࡫ࡸ࡯࡮ࡅ࡫ࡥࡷࡉ࡯ࡥࡧ࡟ࠬ࠶࠷࠰࡝ࠫࡿࠎࠎࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡴࡶࡵࡣ࡮ࡪࡸ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࠮࡞࠭ࠬࠪࠫࡢࠨࡣ࠿ࠥࡲࡳࠨ࡜࡜࡞࠮ࠬࡄࡖ࠽ࡴࡶࡵࡣ࡮ࡪࡸࠪ࡞ࡠࠎࠎࠏࠉࠊࠋࠬࠎࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎ࠲࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱࡜ࠩࡣ࡟࠭࠮ࡅࠬࡤ࠿ࡤࡠ࠳ࠐࠉࠊࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉࠊࠋࡪࡩࡹࡢࠨࡣ࡞ࠬࢀࠏࠏࠉࠊࠋࠌࠍࠎࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢ࡛ࡣ࡞ࡠࡠࢁࡢࡼ࡯ࡷ࡯ࡰࠏࠏࠉࠊࠋࠌࠍ࠮ࡢࠩࠧࠨ࡟ࠬࡨࡃࡼࠋࠋࠌࠍࠎࠏ࡜ࡣࠪࡂࡔࡁࡼࡡࡳࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࡁࠏࠏࠉࠊࠋࠬࠬࡄࡖ࠼࡯ࡨࡸࡲࡨࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩࠩࡁ࠽ࡠࡠ࠮࠿ࡑ࠾࡬ࡨࡽࡄ࡜ࡥ࠭ࠬࡠࡢ࠯࠿࡝ࠪ࡞ࡥ࠲ࢀࡁ࠮࡜ࡠࡠ࠮ࠐࠉࠊࠋࠌࠬࡄ࠮ࡶࡢࡴࠬ࠰ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠴ࡳࡦࡶ࡟ࠬ࠭ࡅ࠺ࠣࡰ࠮ࠦࢁࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜࠭ࠪࡂࡔࡂࡼࡡࡳࠫ࡟࠭࠮࠭ࠧࠨಚ"),Hl2Y1sF4Zvapx)
			if not o75XilFP8eDpAS30ZQuGdjOrynHqmx:
				o75XilFP8eDpAS30ZQuGdjOrynHqmx = p7dwlH1PRStBgyMUW.findall(
					wwWzyF4ZpSQXKOgk569(u"ࡲࠨࠩࠪࠬࡄࡾࡳࠪࠌࠌࠍࠎࠏࠉ࠼࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝ࡵ࠭ࡁࡡࡹࠪࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠮ࠐࠉࠊࠋࠌࠍࡡࡹࠪ࡝ࡽࠫࡃ࠿࠮࠿ࠢࡿ࠾࠭࠳࠯ࠫࡀࡴࡨࡸࡺࡸ࡮࡝ࡵ࠭ࠬࡄࡖ࠼ࡲࡀ࡞ࠦࠬࡣࠩ࡜࡞ࡺ࠱ࡢ࠱࡟ࡸ࠺ࡢࠬࡄࡖ࠽ࡲࠫ࡟ࡷ࠯ࡢࠫ࡝ࡵ࠭࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࠫࠬ࠭ಛ"),
					Hl2Y1sF4Zvapx)
			o75XilFP8eDpAS30ZQuGdjOrynHqmx = p7dwlH1PRStBgyMUW.findall(o75XilFP8eDpAS30ZQuGdjOrynHqmx[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][XURrDCfOS9Mbhpv2Pmjos56TeW]+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠿࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠬಜ"),Hl2Y1sF4Zvapx,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else:
			def _xysbOMtA9STFnVJEi(jmqi0QyHdYcVxJzuhUeOIZ83Nvsb):
				import ast as GioCbfsFlNUa8DkQA3hmdIc2ZrMtK
				sQJoz2AlpcfKMUIHbdn1ieaTEh = YYQS36fyPvtuzcEmRL(u"ࡴࠪࠫࠬ࠮࠿ࡹࠫࠍࠍࠎࠏࠉࠊࠪࡂࡔࡁࡷ࠱࠿࡝ࠥࡠࠬࡣࠩࡶࡵࡨࡠࡸ࠱ࡳࡵࡴ࡬ࡧࡹ࠮࠿ࡑ࠿ࡴ࠵࠮ࡁ࡜ࡴࠬࠍࠍࠎࠏࠉࠊࠪࡂࡔࡁࡩ࡯ࡥࡧࡁࠎࠎࠏࠉࠊࠋࠌࡺࡦࡸ࡜ࡴ࠭ࠫࡃࡕࡂ࡮ࡢ࡯ࡨࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡢࡳࠫ࠿࡟ࡷ࠯ࠐࠉࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡹࡥࡱࡻࡥ࠿ࠌࠌࠍࠎࠏࠉࠊࠋࠫࡃࡕࡂࡱ࠳ࡀ࡞ࠦࡡ࠭࡝ࠪࠪࡂ࠾࠭ࡅࠡࠩࡁࡓࡁࡶ࠸ࠩࠪ࠰ࡿࡠࡡ࠴ࠩࠬࠪࡂࡔࡂࡷ࠲ࠪࠌࠌࠍࠎࠏࠉࠊࠋ࡟࠲ࡸࡶ࡬ࡪࡶ࡟ࠬ࠭ࡅࡐ࠽ࡳ࠶ࡂࡠࠨࠧ࡞ࠫࠫࡃ࠿࠮࠿ࠢࠪࡂࡔࡂࡷ࠳ࠪࠫ࠱࠭࠰࠮࠿ࡑ࠿ࡴ࠷࠮ࡢࠩࠋࠋࠌࠍࠎࠏࠉࠊࡾࠍࠍࠎࠏࠉࠊࠋࠌࡠࡠࡢࡳࠫࠪࡂ࠾࠭ࡅࡐ࠽ࡳ࠷ࡂࡠࠨ࡜ࠨ࡟ࠬࠬࡄࡀࠨࡀࠣࠫࡃࡕࡃࡱ࠵ࠫࠬ࠲ࢁࡢ࡜࠯ࠫ࠭ࠬࡄࡖ࠽ࡲ࠶ࠬࡠࡸ࠰ࠬࡀ࡞ࡶ࠮࠮࠱࡜࡞ࠌࠌࠍࠎࠏࠉࠊࠫࠍࠍࠎࠏࠉࠊࠫ࡞࠿࠱ࡣࠊࠊࠋࠌࠍࠬ࠭ࠧಝ")
				UVdQPfFg8jbtMlwiu7ET = p7dwlH1PRStBgyMUW.search(sQJoz2AlpcfKMUIHbdn1ieaTEh, jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
				if not UVdQPfFg8jbtMlwiu7ET: return None, None
				HU3ZLmzvcIy2XjhSQ5 = UVdQPfFg8jbtMlwiu7ET.group(kdRO82AImh0LFw(u"ࠪࡲࡦࡳࡥࠨಞ"))
				fxSsIMtbamqu5zin9Zdj = UVdQPfFg8jbtMlwiu7ET.group(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡻࡧ࡬ࡶࡧࠪಟ")).strip()
				qev1RCEz7QV5kxPjrXZmMgDIi2StN = p7dwlH1PRStBgyMUW.match(YYQS36fyPvtuzcEmRL(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡳࡁ࡟ࠧ࠭࡝ࠪࠪࡂࡔࡁࡹࡴࡳ࡫ࡱ࡫ࡃ࠴ࠪࡀࠫࠫࡃࡕࡃࡱࠪ࡞࠱ࡷࡵࡲࡩࡵ࡞ࠫࠬࡄࡖ࠼ࡲ࠴ࡁ࡟ࠧ࠭࡝ࠪࠪࡂࡔࡁࡹࡥࡱࡀ࠱࠮ࡄ࠯ࠨࡀࡒࡀࡵ࠷࠯࡜ࠪࠌࠌࠍࠎࠏࠧࠨࠩಠ"), fxSsIMtbamqu5zin9Zdj)
				if qev1RCEz7QV5kxPjrXZmMgDIi2StN:
					vxXun4JkSLqNj1Z9GWoapMUE7 = qev1RCEz7QV5kxPjrXZmMgDIi2StN.group(SI7eBdND4lx8pt5Qk(u"࠭ࡳࡵࡴ࡬ࡲ࡬࠭ಡ"))
					S9d2ArcGLNxmH0v = qev1RCEz7QV5kxPjrXZmMgDIi2StN.group(Z9FPQvwlbjLTh(u"ࠧࡴࡧࡳࠫಢ"))
					return HU3ZLmzvcIy2XjhSQ5, vxXun4JkSLqNj1Z9GWoapMUE7.split(S9d2ArcGLNxmH0v)
				if fxSsIMtbamqu5zin9Zdj.startswith(iySORMYxWXszEH18(u"ࠣ࡝ࠥಣ")) and fxSsIMtbamqu5zin9Zdj.endswith(beV5l2D8HznyJI0(u"ࠤࡠࠦತ")):
					try:
						Dl5B2bLSwNW4PRsni7pXCgQkZ = GioCbfsFlNUa8DkQA3hmdIc2ZrMtK.literal_eval(fxSsIMtbamqu5zin9Zdj)
						return HU3ZLmzvcIy2XjhSQ5, Dl5B2bLSwNW4PRsni7pXCgQkZ
					except: return HU3ZLmzvcIy2XjhSQ5, None
				return HU3ZLmzvcIy2XjhSQ5, None
			def _cJivBYjlD2UKI(jmqi0QyHdYcVxJzuhUeOIZ83Nvsb):
				HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz = _xysbOMtA9STFnVJEi(jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
				SB6jHLKkUwsWEpFQe = None
				if cu8OyaeXvxAobC1gtI9nWqmJNpz:
					try: basestring
					except NameError: basestring = str
					for vv8iRSdbKX043aWglfhuUQq1pEok in cu8OyaeXvxAobC1gtI9nWqmJNpz:
						if isinstance(vv8iRSdbKX043aWglfhuUQq1pEok, basestring) and vv8iRSdbKX043aWglfhuUQq1pEok.endswith(VP70ytiFNMBl6vHDaW(u"ࠪ࠱ࡤࡽ࠸ࡠࠩಥ")):
							SB6jHLKkUwsWEpFQe = vv8iRSdbKX043aWglfhuUQq1pEok
							break
				if SB6jHLKkUwsWEpFQe:
					sQJoz2AlpcfKMUIHbdn1ieaTEh = A41nqbj3wYt(u"ࡶࠬ࠭ࠧࠩࡁࡻ࠭ࠏࠏࠉࠊࠋࠌࠍࡡࢁ࡜ࡴࠬࡵࡩࡹࡻࡲ࡯࡞ࡶ࠯ࠪࡹ࡜࡜ࠧࡧࡠࡢࡢࡳࠫ࡞࠮ࡠࡸ࠰ࠨࡀࡒ࠿ࡥࡷ࡭࡮ࡢ࡯ࡨࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡢࡳࠫ࡞ࢀࠎࠎࠏࠉࠊࠋࠪࠫࠬದ") % (p7dwlH1PRStBgyMUW.escape(HU3ZLmzvcIy2XjhSQ5), cu8OyaeXvxAobC1gtI9nWqmJNpz.index(SB6jHLKkUwsWEpFQe))
					match = p7dwlH1PRStBgyMUW.search(sQJoz2AlpcfKMUIHbdn1ieaTEh, jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
					if match:
						sQJoz2AlpcfKMUIHbdn1ieaTEh = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠌࠍࠎࠏ࡜ࡼ࡞ࡶ࠮ࡡ࠯ࠥࡴ࡞ࠫࡠࡸ࠰ࠊࠊࠋࠌࠍࠎࠏࠉࠩࡁ࠽ࠎࠎࠏࠉࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡩࡹࡳࡩ࡮ࡢ࡯ࡨࡣࡦࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝ࡵ࠭ࡲࡴ࡯ࡴࡤࡰࡸࡪࡡࡹࠪࠋࠋࠌࠍࠎࠏࠉࠊࠋࡿࡲࡴ࡯ࡴࡤࡰࡸࡪࡡࡹࠪ࠾࡞ࡶ࠮࠭ࡅࡐ࠽ࡨࡸࡲࡨࡴࡡ࡮ࡧࡢࡦࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯ࠨࡀ࠼࡟ࡷ࠰ࡸࡡࡷࠫࡂࠎࠎࠏࠉࠊࠋࠌࠍ࠮ࡡ࠻࡝ࡰࡠࠎࠎࠏࠉࠊࠋࠌࠫࠬ࠭ಧ") % p7dwlH1PRStBgyMUW.escape(match.group(pp7FcjEe6g(u"࠭ࡡࡳࡩࡱࡥࡲ࡫ࠧನ"))[::-wwWzyF4ZpSQXKOgk569(u"࠵ༀ")])
						ZvJsHbdyx2z7 = p7dwlH1PRStBgyMUW.search(sQJoz2AlpcfKMUIHbdn1ieaTEh, jmqi0QyHdYcVxJzuhUeOIZ83Nvsb[match.start()::-aiQwFE1TGx04vmLcsYkIW5jA(u"࠶༁")])
						if ZvJsHbdyx2z7:
							SsbduzmRPEIpN5xg1kZviGetJAO, d4mM7W5uXUF6oSgO = ZvJsHbdyx2z7.group(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡧࡷࡱࡧࡳࡧ࡭ࡦࡡࡤࠫ಩"), gPE1XB87fQl(u"ࠨࡨࡸࡲࡨࡴࡡ࡮ࡧࡢࡦࠬಪ"))
							return (SsbduzmRPEIpN5xg1kZviGetJAO or d4mM7W5uXUF6oSgO)[::-CyHU86ZeYT5BWRcitSm2I(u"࠷༂")], HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz
				a3bmCIcnz4 = p7dwlH1PRStBgyMUW.compile(iySORMYxWXszEH18(u"ࡴࠪࠫࠬ࠮࠿ࡹࠫࠍࠍࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࠍࡡ࠴ࡧࡦࡶ࡟ࠬࠧࡴࠢ࡝ࠫ࡟࠭ࠫࠬ࡜ࠩࡤࡀࢀࠏࠏࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉࠊࡤࡀࡗࡹࡸࡩ࡯ࡩ࡟࠲࡫ࡸ࡯࡮ࡅ࡫ࡥࡷࡉ࡯ࡥࡧ࡟ࠬ࠶࠷࠰࡝ࠫࡿࠎࠎࠏࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡵࡷࡶࡤ࡯ࡤࡹࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࠯࡟࠮࠭ࠫࠬ࡜ࠩࡤࡀࠦࡳࡴࠢ࡝࡝࡟࠯࠭ࡅࡐ࠾ࡵࡷࡶࡤ࡯ࡤࡹࠫ࡟ࡡࠏࠏࠉࠊࠋࠌࠍ࠮ࠐࠉࠊࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉࠊࠋ࠯࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠭ࡧ࡜ࠪࠫࡂ࠰ࡨࡃࡡ࡝࠰ࠍࠍࠎࠏࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࠏࠉࠊࡩࡨࡸࡡ࠮ࡢ࡝ࠫࡿࠎࠎࠏࠉࠊࠋࠌࠍࠎࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢ࡛ࡣ࡞ࡠࡠࢁࡢࡼ࡯ࡷ࡯ࡰࠏࠏࠉࠊࠋࠌࠍࠎ࠯࡜ࠪࠨࠩࡠ࠭ࡩ࠽ࡽࠌࠌࠍࠎࠏࠉࠊ࡞ࡥࠬࡄࡖ࠼ࡷࡣࡵࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡃࠊࠊࠋࠌࠍࠎ࠯ࠨࡀࡒ࠿ࡲ࡫ࡻ࡮ࡤࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࠬࡄࡀ࡜࡜ࠪࡂࡔࡁ࡯ࡤࡹࡀ࡟ࡨ࠰࠯࡜࡞ࠫࡂࡠ࠭ࡡࡡ࠮ࡼࡄ࠱࡟ࡣ࡜ࠪࠌࠌࠍࠎࠏࠉࠩࡁࠫࡺࡦࡸࠩ࠭࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬ࡞࠱ࡷࡪࡺ࡜ࠩࠪࡂ࠾ࠧࡴࠫࠣࡾ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࡠ࠱࠮࠿ࡑ࠿ࡹࡥࡷ࠯࡜ࠪࠫࠍࠍࠎࠏࠉࠨࠩࠪಫ"))
				match = a3bmCIcnz4.search(jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
				qmjW3sIgu48vKTVXw6Y, DvqS1xLF8Y = (None, None)
				if match:
					qmjW3sIgu48vKTVXw6Y = match.group(kdRO82AImh0LFw(u"ࠪࡲ࡫ࡻ࡮ࡤࠩಬ"))
					DvqS1xLF8Y = match.group(bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࡮ࡪࡸࠨಭ"))
				if not qmjW3sIgu48vKTVXw6Y:
					print(bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡌࡡ࡭࡮࡬ࡲ࡬ࠦࡢࡢࡥ࡮ࠤࡹࡵࠠࡨࡧࡱࡩࡷ࡯ࡣࠡࡰࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥࡹࡥࡢࡴࡦ࡬ࠬಮ"))
					rWbYIsg6Dp2n5eLF8vTdOa7NoUBqAu = p7dwlH1PRStBgyMUW.search(Z9FPQvwlbjLTh(u"ࡸࠧࠨࠩࠫࡃࡽࡹࠩࠋࠋࠌࠍࠎࠏࠉ࠼࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝ࡵ࠭ࡁࡡࡹࠪࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠮ࠐࠉࠊࠋࠌࠍࠎࡢࡳࠫ࡞ࡾࠬࡄࡀࠨࡀࠣࢀ࠿࠮࠴ࠩࠬࡁࡵࡩࡹࡻࡲ࡯࡞ࡶ࠮࠭ࡅࡐ࠽ࡳࡁ࡟ࠧ࠭࡝ࠪ࡝࡟ࡻ࠲ࡣࠫࡠࡹ࠻ࡣ࠭ࡅࡐ࠾ࡳࠬࡠࡸ࠰࡜ࠬ࡞ࡶ࠮ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࠏࠏࠉࠊࠋࠌࠫࠬ࠭ಯ"), jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
					if rWbYIsg6Dp2n5eLF8vTdOa7NoUBqAu: return rWbYIsg6Dp2n5eLF8vTdOa7NoUBqAu.group(A6iX18qgyOFlZxz7sc(u"ࠧ࡯ࡣࡰࡩࠬರ")), HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz
					return None,None,None
				elif not DvqS1xLF8Y: return qmjW3sIgu48vKTVXw6Y, HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz
				YGVhW2FINlseikOLEvc1j9X0t7fqu = p7dwlH1PRStBgyMUW.search(pp7FcjEe6g(u"ࡳࠩࡹࡥࡷࠦࡻࡾ࡞࡟ࡷ࠯ࡃ࡜࡝ࡵ࠭ࠬࡡࡢ࡛࠯࠭ࡂࡠࡡࡣࠩ࡝࡞ࡶ࠮ࡠ࠲࠻࡞ࠩಱ").format(p7dwlH1PRStBgyMUW.escape(qmjW3sIgu48vKTVXw6Y)), jmqi0QyHdYcVxJzuhUeOIZ83Nvsb)
				if YGVhW2FINlseikOLEvc1j9X0t7fqu: return qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(YmIUzpqaKfgSRNoic62V8QblEwsHv(YGVhW2FINlseikOLEvc1j9X0t7fqu.group(rVy3Ops0mohYkT(u"࠱༃"))))[int(DvqS1xLF8Y)], HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz
				return None, HU3ZLmzvcIy2XjhSQ5, cu8OyaeXvxAobC1gtI9nWqmJNpz
			o75XilFP8eDpAS30ZQuGdjOrynHqmx, qJNvjYrwTebdh9IXunozRW8, cu8OyaeXvxAobC1gtI9nWqmJNpz = _cJivBYjlD2UKI(Hl2Y1sF4Zvapx)
			if not o75XilFP8eDpAS30ZQuGdjOrynHqmx: BGQXvd2lsicjVTgnHYRo74qDI3z(kdRO82AImh0LFw(u"ࠩࠪಲ"),rVy3Ops0mohYkT(u"ࠪࠫಳ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫ࡞ࡵࡵࡵࡷࡥࡩࠥ๐่ห์๋ฬࠬ಴"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡪࡥࡤࡴࡼࡴࡹ࡯࡮ࡨࠢࡳࡰࡦࡿࠠ࡭࡫ࡱ࡯ࡸࠦ࡜࡯࡞ࡱࠤๆฺไࠡใํࠤๆะอࠡฬืๅ๏ืࠠา๊สฬ฼ࠦวๅใํำ๏๎ࠧವ"))
			else:
				HTIQLCoZi4PFjyY9 = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(cu8OyaeXvxAobC1gtI9nWqmJNpz)
				OLBhliu1HT498K5qe02dgnAfoNM = Hl2Y1sF4Zvapx.find(o75XilFP8eDpAS30ZQuGdjOrynHqmx+I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭࠽ࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࠪಶ"))
				U6H0GAX7JQ5OTtgzxB = Hl2Y1sF4Zvapx.find(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡾ࠽ࠪಷ"), OLBhliu1HT498K5qe02dgnAfoNM)
				G76xzJSgFLeEAa0DY1qfMrUbhV = Hl2Y1sF4Zvapx[OLBhliu1HT498K5qe02dgnAfoNM:U6H0GAX7JQ5OTtgzxB]+gPE1XB87fQl(u"ࠨࡿ࠾ࠫಸ")
				pV0CUKLrqTO = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࡴࠪ࡭࡫ࡢࠨࡵࡻࡳࡩࡴ࡬ࠠ࠯ࠬࡂࡁࡂࡃ࠮ࠫࡁ࡟࠭ࡷ࡫ࡴࡶࡴࡱࠤ࠳ࡁࠧಹ"), G76xzJSgFLeEAa0DY1qfMrUbhV, p7dwlH1PRStBgyMUW.DOTALL)
				if pV0CUKLrqTO: G76xzJSgFLeEAa0DY1qfMrUbhV = G76xzJSgFLeEAa0DY1qfMrUbhV.replace(pV0CUKLrqTO[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠱༄")],A6iX18qgyOFlZxz7sc(u"ࠪࠫ಺"))
				if not qJNvjYrwTebdh9IXunozRW8: qJNvjYrwTebdh9IXunozRW8 = p7dwlH1PRStBgyMUW.findall(beV5l2D8HznyJI0(u"ࠫࡻࡧࡲࠡ࠰࠭ࡃࡂ࠮࠮ࠫࡁࠬࡠ࠳࠭಻"),G76xzJSgFLeEAa0DY1qfMrUbhV,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				G76xzJSgFLeEAa0DY1qfMrUbhV = G76xzJSgFLeEAa0DY1qfMrUbhV.replace(YYQS36fyPvtuzcEmRL(u"ࠬࡢ࡮ࠨ಼"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				G76xzJSgFLeEAa0DY1qfMrUbhV = GHg28TBchiyn6l(u"ࠨࡶࡢࡴࠣࡿࢂࠦ࠽ࠡࡽࢀ࠿ࡡࡴࡻࡾࠤಽ").format(qJNvjYrwTebdh9IXunozRW8, HTIQLCoZi4PFjyY9, G76xzJSgFLeEAa0DY1qfMrUbhV)
				QzLHxtj9Viho8YlMP10avJ3rfp = {}
				TmdZLiDcGQ7SPUBzqIboV1nH = []
				for gnLv64MGN58ce2oECAqrQwWmSbHK3 in rLPm5uR346Gjv1:
					url = gnLv64MGN58ce2oECAqrQwWmSbHK3[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡶࡴ࡯ࠫಾ")]
					if SI7eBdND4lx8pt5Qk(u"ࠨࠨࡱࡁࠬಿ") in url:
						iyNp2WDKnI1Z60l9 = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࠩࡲࡂ࠮࠮ࠫࡁࠬࠪࠬೀ"),url,p7dwlH1PRStBgyMUW.DOTALL)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
						if iyNp2WDKnI1Z60l9 not in list(QzLHxtj9Viho8YlMP10avJ3rfp.keys()):
							SquIB3LmfjkH7EygJp2GzeKcZw = FfS4xlcw3aP8KqA(G76xzJSgFLeEAa0DY1qfMrUbhV,[o75XilFP8eDpAS30ZQuGdjOrynHqmx,iyNp2WDKnI1Z60l9])
							QzLHxtj9Viho8YlMP10avJ3rfp[iyNp2WDKnI1Z60l9] = SquIB3LmfjkH7EygJp2GzeKcZw
						else: SquIB3LmfjkH7EygJp2GzeKcZw = QzLHxtj9Viho8YlMP10avJ3rfp[iyNp2WDKnI1Z60l9]
						gnLv64MGN58ce2oECAqrQwWmSbHK3[Z9FPQvwlbjLTh(u"ࠪࡹࡷࡲࠧು")] = url.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࠫࡴ࠽ࠨೂ")+iyNp2WDKnI1Z60l9+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࠬࠧೃ"),GHg28TBchiyn6l(u"࠭ࠦ࡯࠿ࠪೄ")+SquIB3LmfjkH7EygJp2GzeKcZw+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࠧࠩ೅"))
					TmdZLiDcGQ7SPUBzqIboV1nH.append(gnLv64MGN58ce2oECAqrQwWmSbHK3)
				rLPm5uR346Gjv1 = TmdZLiDcGQ7SPUBzqIboV1nH.copy()
	for dict in rLPm5uR346Gjv1:
		url = dict[iySORMYxWXszEH18(u"ࠨࡷࡵࡰࠬೆ")]
		if bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭ೇ") in url or url.count(yobpaW7sBqtKRrv(u"ࠪࡷ࡮࡭࠽ࠨೈ"))>wnaWTQM7VJPkZzO9eoSyFU4:
			MwV1codKPWNlj0RvCpmGIQt7his.append(dict)
		elif Hl2Y1sF4Zvapx and VP70ytiFNMBl6vHDaW(u"ࠫࡸ࠭೉") in list(dict.keys()) and A6iX18qgyOFlZxz7sc(u"ࠬࡹࡰࠨೊ") in list(dict.keys()):
			IIc7YFLiqpeVtzxC = SptW5xwf6T7qF4U1YRg9LlKdIvoP.execute(dict[rVy3Ops0mohYkT(u"࠭ࡳࠨೋ")])
			if IIc7YFLiqpeVtzxC!=dict[gPE1XB87fQl(u"ࠧࡴࠩೌ")]:
				dict[KLX7hW0nBAEgy6m4SvH(u"ࠨࡷࡵࡰ್ࠬ")] = url+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࠩࠫ೎")+dict[kdRO82AImh0LFw(u"ࠪࡷࡵ࠭೏")]+rVy3Ops0mohYkT(u"ࠫࡂ࠭೐")+IIc7YFLiqpeVtzxC
				MwV1codKPWNlj0RvCpmGIQt7his.append(dict)
	for dict in MwV1codKPWNlj0RvCpmGIQt7his:
		P4cqC2X0dpeHbg3KW,s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE,mSUgXrb76sW1KwDC,nxeRBuVLTiHaSJEp30XN5P4dbG,OOcBU84aTADbok2pMtl,ufQ5elFnNp = yobpaW7sBqtKRrv(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭೑"),KLX7hW0nBAEgy6m4SvH(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ೒"),IMjqygdfYSKpHlWu5Aa(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ೓"),mq5t9JXSdHT8yfDVF(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ೔"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࠳ࠫೕ")
		try:
			ZzK7sFdX8Ckio3MEypYlB9N = dict[iySORMYxWXszEH18(u"ࠪࡸࡾࡶࡥࠨೖ")]
			ZzK7sFdX8Ckio3MEypYlB9N = ZzK7sFdX8Ckio3MEypYlB9N.replace(oiWNFYzcIUeh(u"ࠫ࠰࠭೗"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			items = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೘"),ZzK7sFdX8Ckio3MEypYlB9N,p7dwlH1PRStBgyMUW.DOTALL)
			nxeRBuVLTiHaSJEp30XN5P4dbG,P4cqC2X0dpeHbg3KW,OOcBU84aTADbok2pMtl = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			ZQs5Lp8xfVGX = OOcBU84aTADbok2pMtl.split(IMjqygdfYSKpHlWu5Aa(u"࠭ࠬࠨ೙"))
			s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			for N6NV3h4fel in ZQs5Lp8xfVGX: s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE += N6NV3h4fel.split(KLX7hW0nBAEgy6m4SvH(u"ࠧ࠯ࠩ೚"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+KLX7hW0nBAEgy6m4SvH(u"ࠨ࠮ࠪ೛")
			s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE = s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE.strip(gPE1XB87fQl(u"ࠩ࠯ࠫ೜"))
			if VP70ytiFNMBl6vHDaW(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫೝ") in list(dict.keys()): ufQ5elFnNp = str(int(dict[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬೞ")])//SI7eBdND4lx8pt5Qk(u"࠳࠳࠶࠹༅"))+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡱࡢࡱࡵࠣࠤࠬ೟")
			else: ufQ5elFnNp = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if nxeRBuVLTiHaSJEp30XN5P4dbG==mq5t9JXSdHT8yfDVF(u"࠭ࡴࡦࡺࡷࠫೠ"): continue
			elif mq5t9JXSdHT8yfDVF(u"ࠧ࠭ࠩೡ") in ZzK7sFdX8Ckio3MEypYlB9N:
				nxeRBuVLTiHaSJEp30XN5P4dbG = Z9FPQvwlbjLTh(u"ࠨࡃ࠮࡚ࠬೢ")
				mSUgXrb76sW1KwDC = P4cqC2X0dpeHbg3KW+tTChquY7XSRg4e+ufQ5elFnNp+dict[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡶ࡭ࡿ࡫ࠧೣ")].split(A41nqbj3wYt(u"ࠪࡼࠬ೤"))[wnaWTQM7VJPkZzO9eoSyFU4]
			elif nxeRBuVLTiHaSJEp30XN5P4dbG==kdRO82AImh0LFw(u"ࠫࡻ࡯ࡤࡦࡱࠪ೥"):
				nxeRBuVLTiHaSJEp30XN5P4dbG = bawK2j7T81Nrc4GWs05xzDg(u"ࠬ࡜ࡩࡥࡧࡲࠫ೦")
				mSUgXrb76sW1KwDC = ufQ5elFnNp+dict[mq5t9JXSdHT8yfDVF(u"࠭ࡳࡪࡼࡨࠫ೧")].split(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡹࠩ೨"))[wnaWTQM7VJPkZzO9eoSyFU4]+tTChquY7XSRg4e+dict[A41nqbj3wYt(u"ࠨࡨࡳࡷࠬ೩")]+yobpaW7sBqtKRrv(u"ࠩࡩࡴࡸ࠭೪")+tTChquY7XSRg4e+P4cqC2X0dpeHbg3KW
			elif nxeRBuVLTiHaSJEp30XN5P4dbG==wwWzyF4ZpSQXKOgk569(u"ࠪࡥࡺࡪࡩࡰࠩ೫"):
				nxeRBuVLTiHaSJEp30XN5P4dbG = kdRO82AImh0LFw(u"ࠫࡆࡻࡤࡪࡱࠪ೬")
				mSUgXrb76sW1KwDC = ufQ5elFnNp+str(int(dict[gPE1XB87fQl(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ೭")])/A6iX18qgyOFlZxz7sc(u"࠴࠴࠵࠶༆"))+Z9FPQvwlbjLTh(u"࠭࡫ࡩࡼࠣࠤࠬ೮")+dict[CyHU86ZeYT5BWRcitSm2I(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ೯")]+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡥ࡫ࠫ೰")+tTChquY7XSRg4e+P4cqC2X0dpeHbg3KW
		except:
			C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
			if C2nN35DILUFzEKqv0BPl4eZjH6!=aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬೱ"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
		if KLX7hW0nBAEgy6m4SvH(u"ࠪࡨࡺࡸ࠽ࠨೲ") in dict[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡺࡸ࡬ࠨೳ")]: gJVpmQ1oYbrkHaKnS4N3v2z = round(mq5t9JXSdHT8yfDVF(u"࠵࠴࠵༈")+float(dict[yobpaW7sBqtKRrv(u"ࠬࡻࡲ࡭ࠩ೴")].split(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡤࡶࡴࡀࠫ೵"),aiQwFE1TGx04vmLcsYkIW5jA(u"࠵༇"))[wnaWTQM7VJPkZzO9eoSyFU4].split(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠧࠩ೶"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]))
		elif VP70ytiFNMBl6vHDaW(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ೷") in list(dict.keys()): gJVpmQ1oYbrkHaKnS4N3v2z = round(rVy3Ops0mohYkT(u"࠶࠮࠶༉")+float(dict[YYQS36fyPvtuzcEmRL(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ೸")])/XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠱࠱࠲࠳༊"))
		else: gJVpmQ1oYbrkHaKnS4N3v2z = gPE1XB87fQl(u"ࠪ࠴ࠬ೹")
		if beV5l2D8HznyJI0(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ೺") not in list(dict.keys()): ufQ5elFnNp = dict[kdRO82AImh0LFw(u"ࠬࡹࡩࡻࡧࠪ೻")].split(iySORMYxWXszEH18(u"࠭ࡸࠨ೼"))[wnaWTQM7VJPkZzO9eoSyFU4]
		else: ufQ5elFnNp = str(int(dict[Z9FPQvwlbjLTh(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ೽")])//IMjqygdfYSKpHlWu5Aa(u"࠲࠲࠵࠸་"))
		if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࡫ࡱ࡭ࡹ࠭೾") not in list(dict.keys()): dict[kdRO82AImh0LFw(u"ࠩ࡬ࡲ࡮ࡺࠧ೿")] = bawK2j7T81Nrc4GWs05xzDg(u"ࠪ࠴࠲࠶ࠧഀ")
		dict[yobpaW7sBqtKRrv(u"ࠫࡹ࡯ࡴ࡭ࡧࠪഁ")] = nxeRBuVLTiHaSJEp30XN5P4dbG+yobpaW7sBqtKRrv(u"ࠬࡀࠠࠡࠩം")+mSUgXrb76sW1KwDC+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࠠࠡࠪࠪഃ")+s9sq2mfLKOIkQ7aRNPr8wGbXUH1oVE+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧ࠭ࠩഄ")+dict[oiWNFYzcIUeh(u"ࠨ࡫ࡷࡥ࡬࠭അ")]+ZLr5gRSkFewKdUos90bM(u"ࠩࠬࠫആ")
		dict[YYQS36fyPvtuzcEmRL(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫഇ")] = mSUgXrb76sW1KwDC.split(tTChquY7XSRg4e)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].split(kdRO82AImh0LFw(u"ࠫࡰࡨࡰࡴࠩഈ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		dict[gPE1XB87fQl(u"ࠬࡺࡹࡱࡧ࠵ࠫഉ")] = nxeRBuVLTiHaSJEp30XN5P4dbG
		dict[aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨഊ")] = P4cqC2X0dpeHbg3KW
		dict[oiWNFYzcIUeh(u"ࠧࡤࡱࡧࡩࡨࡹࠧഋ")] = OOcBU84aTADbok2pMtl
		dict[VP70ytiFNMBl6vHDaW(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪഌ")] = gJVpmQ1oYbrkHaKnS4N3v2z
		dict[CyHU86ZeYT5BWRcitSm2I(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ഍")] = ufQ5elFnNp
		yplXkNnjdvWA7MHBhsqIwegPO.append(dict)
	TgEt8m7SWJb,eeW8uCYJfMBHXqQ5GwUvdVmN0,PcRCZNh6V8Hq7UgMfjmYpoX,Chn5E1OsFvT9BfI,OcGkYahbMz9KuoZWSEd7NfyQAF3DH = [],[],[],[],[]
	c5rXNQeo7i,rr3TW6iR2YwIF,JeDn1Pu5gXzSGcYToQqKbml3,Tiu2jylP9Wz4,Q20QIcWykFtnTBh = [],[],[],[],[]
	for N4thkp6MUXbuWLQImVTYqexs3Kr in VD19ZeQIfgUWXl4jcvnM3K6C:
		if not N4thkp6MUXbuWLQImVTYqexs3Kr: continue
		dict = {}
		dict[YYQS36fyPvtuzcEmRL(u"ࠪࡸࡾࡶࡥ࠳ࠩഎ")] = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡆ࠱ࡖࠨഏ")
		dict[oiWNFYzcIUeh(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧഐ")] = mq5t9JXSdHT8yfDVF(u"࠭࡭ࡱࡦࠪ഑")
		dict[CyHU86ZeYT5BWRcitSm2I(u"ࠧࡵ࡫ࡷࡰࡪ࠭ഒ")] = dict[jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡶࡼࡴࡪ࠸ࠧഓ")]+ZLr5gRSkFewKdUos90bM(u"ࠩ࠽ࠤࠥ࠭ഔ")+dict[SI7eBdND4lx8pt5Qk(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬക")]+tTChquY7XSRg4e+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫั๎ฯสࠢำ็๏ฯࠧഖ")
		dict[kdRO82AImh0LFw(u"ࠬࡻࡲ࡭ࠩഗ")] = N4thkp6MUXbuWLQImVTYqexs3Kr
		dict[KLX7hW0nBAEgy6m4SvH(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧഘ")] = YYQS36fyPvtuzcEmRL(u"ࠧ࠱ࠩങ")
		dict[ZLr5gRSkFewKdUos90bM(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩച")] = ZLr5gRSkFewKdUos90bM(u"ࠩ࠴࠵࠶࠸࠲࠳࠵࠶࠷ࠬഛ")
		yplXkNnjdvWA7MHBhsqIwegPO.append(dict)
	for K79MElcsiwUrT43Ca in AoTXcMnOym5ur7PlKGDsp:
		if not K79MElcsiwUrT43Ca: continue
		uuSPzLkIpg3xGY,Slf7xhMejYsqON51QkwX6d9I = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,K79MElcsiwUrT43Ca)
		NsJMhUcb1fqAuCkRaQ2e = list(zip(uuSPzLkIpg3xGY,Slf7xhMejYsqON51QkwX6d9I))
		for title,SOw5EUxC9k in NsJMhUcb1fqAuCkRaQ2e:
			dict = {}
			dict[IMjqygdfYSKpHlWu5Aa(u"ࠪࡸࡾࡶࡥ࠳ࠩജ")] = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡆ࠱ࡖࠨഝ")
			dict[yobpaW7sBqtKRrv(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧഞ")] = KLX7hW0nBAEgy6m4SvH(u"࠭࡭࠴ࡷ࠻ࠫട")
			dict[rVy3Ops0mohYkT(u"ࠧࡶࡴ࡯ࠫഠ")] = SOw5EUxC9k
			if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࡭ࡥࡴࡸ࠭ഡ") in title: dict[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪഢ")] = title.split(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪ࡯ࡧࡶࡳࠨണ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].rsplit(tTChquY7XSRg4e)[-wnaWTQM7VJPkZzO9eoSyFU4]
			else: dict[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬത")] = YYQS36fyPvtuzcEmRL(u"ࠬ࠷࠰ࠨഥ")
			if title.count(tTChquY7XSRg4e)>wnaWTQM7VJPkZzO9eoSyFU4:
				DIBw28Qfje76bTMzVNYhxrgWmO = title.rsplit(tTChquY7XSRg4e)[-vXIdY7TwFKso40gVBq5]
				if DIBw28Qfje76bTMzVNYhxrgWmO.isdigit(): dict[YYQS36fyPvtuzcEmRL(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧദ")] = DIBw28Qfje76bTMzVNYhxrgWmO
				else: dict[A41nqbj3wYt(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨധ")] = wwWzyF4ZpSQXKOgk569(u"ࠨ࠲࠳࠴࠵࠭ന")
			if title==kdRO82AImh0LFw(u"ࠩ࠰࠵ࠬഩ"): dict[GHg28TBchiyn6l(u"ࠪࡸ࡮ࡺ࡬ࡦࠩപ")] = dict[wwWzyF4ZpSQXKOgk569(u"ࠫࡹࡿࡰࡦ࠴ࠪഫ")]+YYQS36fyPvtuzcEmRL(u"ࠬࡀࠠࠡࠩബ")+dict[pp7FcjEe6g(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨഭ")]+tTChquY7XSRg4e+YYQS36fyPvtuzcEmRL(u"ࠧอ๊าอࠥึใ๋หࠪമ")
			else: dict[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡶ࡬ࡸࡱ࡫ࠧയ")] = dict[GHg28TBchiyn6l(u"ࠩࡷࡽࡵ࡫࠲ࠨര")]+kdRO82AImh0LFw(u"ࠪ࠾ࠥࠦࠧറ")+dict[A41nqbj3wYt(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ല")]+tTChquY7XSRg4e+dict[mq5t9JXSdHT8yfDVF(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ള")]+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ഴ")+dict[rVy3Ops0mohYkT(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨവ")]
			yplXkNnjdvWA7MHBhsqIwegPO.append(dict)
	yplXkNnjdvWA7MHBhsqIwegPO = sorted(yplXkNnjdvWA7MHBhsqIwegPO,reverse=r0D4C3z7Onqpa,key=lambda key: int(key[CyHU86ZeYT5BWRcitSm2I(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩശ")]))
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [beV5l2D8HznyJI0(u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭ഷ")],[WnNGfosHr5STAq8j7miwyRZ6eOUbV]
	try: NGI7FiW2QbTkVLRESnoa5fpY4X = q5aXr4KvC2tAxhGz3wJkUydBWonmV[YYQS36fyPvtuzcEmRL(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬസ")][kdRO82AImh0LFw(u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨഹ")][lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬഺ")]
	except: NGI7FiW2QbTkVLRESnoa5fpY4X = []
	try: V7mdKCi2oE9AY4WZgc1Gb = q5aXr4KvC2tAxhGz3wJkUydBWonmV[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ഻")][I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵ഼ࠫ")][tzZ6PhyDOUnwLM3pdK(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨഽ")]
	except: V7mdKCi2oE9AY4WZgc1Gb = []
	for SSvKFhHrbUwi in NGI7FiW2QbTkVLRESnoa5fpY4X+V7mdKCi2oE9AY4WZgc1Gb:
		try:
			SOw5EUxC9k = SSvKFhHrbUwi[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪാ")]
			try: title = SSvKFhHrbUwi[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡲࡦࡳࡥࠨി")][XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨീ")]
			except: title = SSvKFhHrbUwi[jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡴࡡ࡮ࡧࠪു")][A6iX18qgyOFlZxz7sc(u"࠭ࡲࡶࡰࡶࠫൂ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡵࡧࡻࡸࠬൃ")]
		except: continue
		if title not in ZD0qItXg31HmC7KGEFn:
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			ZD0qItXg31HmC7KGEFn.append(title)
	if len(ZD0qItXg31HmC7KGEFn)>wnaWTQM7VJPkZzO9eoSyFU4:
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠࠩࠩൄ")+str(len(ZD0qItXg31HmC7KGEFn))+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"้้ࠩࠣ็ࠩࠨ൅"),ZD0qItXg31HmC7KGEFn)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return ZLr5gRSkFewKdUos90bM(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨെ"),[],[]
		elif XFaM94cPUCOWQZNIEe8gdJpny1!=j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			SOw5EUxC9k = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࠫ࠭േ")
			aaMiYfoXrQe625TAWt9SBmgsvcVFK = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࠬࠨࡧ࡯ࡷࡁ࠳࠰࠿ࠪࠨࠪൈ"),SOw5EUxC9k)
			if aaMiYfoXrQe625TAWt9SBmgsvcVFK: SOw5EUxC9k = SOw5EUxC9k.replace(aaMiYfoXrQe625TAWt9SBmgsvcVFK[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ൉"))
			else: SOw5EUxC9k = SOw5EUxC9k+GHg28TBchiyn6l(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨൊ")
			BBfE5nyUDhY1uHxVFgXr = SOw5EUxC9k.strip(IMjqygdfYSKpHlWu5Aa(u"ࠨࠨࠪോ"))
	KC0S9Xk2nGzqTPOau43I5mwYs = []
	for dict in yplXkNnjdvWA7MHBhsqIwegPO:
		if dict[rVy3Ops0mohYkT(u"ࠩࡷࡽࡵ࡫࠲ࠨൌ")]==rVy3Ops0mohYkT(u"࡚ࠪ࡮ࡪࡥࡰ്ࠩ"):
			TgEt8m7SWJb.append(dict[mq5t9JXSdHT8yfDVF(u"ࠫࡹ࡯ࡴ࡭ࡧࠪൎ")])
			c5rXNQeo7i.append(dict)
		elif dict[pp7FcjEe6g(u"ࠬࡺࡹࡱࡧ࠵ࠫ൏")]==KLX7hW0nBAEgy6m4SvH(u"࠭ࡁࡶࡦ࡬ࡳࠬ൐"):
			eeW8uCYJfMBHXqQ5GwUvdVmN0.append(dict[kdRO82AImh0LFw(u"ࠧࡵ࡫ࡷࡰࡪ࠭൑")])
			rr3TW6iR2YwIF.append(dict)
		elif dict[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ൒")]==bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡰࡴࡩ࠭൓"):
			title = dict[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡸ࡮ࡺ࡬ࡦࠩൔ")].replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫൕ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ൖ") not in list(dict.keys()): ufQ5elFnNp = rVy3Ops0mohYkT(u"࠭࠰ࠨൗ")
			else: ufQ5elFnNp = dict[iySORMYxWXszEH18(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ൘")]
			KC0S9Xk2nGzqTPOau43I5mwYs.append([dict,{},title,ufQ5elFnNp])
		else:
			title = dict[wwWzyF4ZpSQXKOgk569(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ൙")].replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ൚"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if pp7FcjEe6g(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ൛") not in list(dict.keys()): ufQ5elFnNp = gPE1XB87fQl(u"ࠫ࠵࠭൜")
			else: ufQ5elFnNp = dict[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭൝")]
			KC0S9Xk2nGzqTPOau43I5mwYs.append([dict,{},title,ufQ5elFnNp])
			PcRCZNh6V8Hq7UgMfjmYpoX.append(title)
			JeDn1Pu5gXzSGcYToQqKbml3.append(dict)
		s7xE4wJ0YbV = r0D4C3z7Onqpa
		if Z9FPQvwlbjLTh(u"࠭ࡣࡰࡦࡨࡧࡸ࠭൞") in list(dict.keys()):
			if beV5l2D8HznyJI0(u"ࠧࡢࡸ࠳ࠫൟ") in dict[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡥࡲࡨࡪࡩࡳࠨൠ")]: s7xE4wJ0YbV = KiryBCvngZzF85UN6xSDlOVweL4I9
			elif CCPXJ7wnNLOg0ZoekcmpdSKI<I872Vum45fMNe1BRngTZLoQiqvkt(u"࠳࠻༌") and aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡤࡺࡨ࠭ൡ") not in dict[bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡧࡴࡪࡥࡤࡵࠪൢ")] and oiWNFYzcIUeh(u"ࠫࡲࡶ࠴ࡢࠩൣ") not in dict[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ൤")]: s7xE4wJ0YbV = KiryBCvngZzF85UN6xSDlOVweL4I9
		if s7xE4wJ0YbV and dict[A6iX18qgyOFlZxz7sc(u"࠭ࡴࡺࡲࡨ࠶ࠬ൥")]==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡗ࡫ࡧࡩࡴ࠭൦") and dict[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࡫ࡱ࡭ࡹ࠭൧")]!=ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࠳࠱࠵࠭൨"):
			OcGkYahbMz9KuoZWSEd7NfyQAF3DH.append(dict[kdRO82AImh0LFw(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ൩")])
			Q20QIcWykFtnTBh.append(dict)
		elif s7xE4wJ0YbV and dict[iySORMYxWXszEH18(u"ࠫࡹࡿࡰࡦ࠴ࠪ൪")]==tzZ6PhyDOUnwLM3pdK(u"ࠬࡇࡵࡥ࡫ࡲࠫ൫") and dict[YYQS36fyPvtuzcEmRL(u"࠭ࡩ࡯࡫ࡷࠫ൬")]!=iySORMYxWXszEH18(u"ࠧ࠱࠯࠳ࠫ൭"):
			Chn5E1OsFvT9BfI.append(dict[A41nqbj3wYt(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ൮")])
			Tiu2jylP9Wz4.append(dict)
	for YqSFUPihAV in Tiu2jylP9Wz4:
		A7pKOwd5vCscXMWuPgI8ZJf = YqSFUPihAV[ZLr5gRSkFewKdUos90bM(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ൯")]
		for gW3erOMAf0EQ in Q20QIcWykFtnTBh:
			BUwYKi0WXEC8PJAj = gW3erOMAf0EQ[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ൰")]
			ufQ5elFnNp = int(BUwYKi0WXEC8PJAj)+int(A7pKOwd5vCscXMWuPgI8ZJf)
			title = gW3erOMAf0EQ[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ൱")].replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧ൲"),gPE1XB87fQl(u"࠭࡭ࡱࡦࠣࠤࠬ൳"))
			title = title.replace(gW3erOMAf0EQ[SI7eBdND4lx8pt5Qk(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ൴")]+tTChquY7XSRg4e,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			title = title.replace(BUwYKi0WXEC8PJAj+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࡭ࡥࡴࡸ࠭൵"),str(ufQ5elFnNp)+yobpaW7sBqtKRrv(u"ࠩ࡮ࡦࡵࡹࠧ൶"))
			title = title+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࠬࠬ൷")+YqSFUPihAV[KLX7hW0nBAEgy6m4SvH(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ൸")].split(Z9FPQvwlbjLTh(u"ࠬ࠮ࠧ൹"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
			KC0S9Xk2nGzqTPOau43I5mwYs.append([gW3erOMAf0EQ,YqSFUPihAV,title,ufQ5elFnNp])
	t5FkRbmHMxvgnzQqYIOidNf8ySJ = []
	for stream in KC0S9Xk2nGzqTPOau43I5mwYs:
		gW3erOMAf0EQ,YqSFUPihAV,title,ufQ5elFnNp = stream
		coNvfp4VIAlyBUK6DziPs0Swu = title[:vXIdY7TwFKso40gVBq5]
		if IMjqygdfYSKpHlWu5Aa(u"࠭ะไ์ฬࠫൺ") in title: coNvfp4VIAlyBUK6DziPs0Swu += oiWNFYzcIUeh(u"ࠧࠬࠩൻ")
		t5FkRbmHMxvgnzQqYIOidNf8ySJ.append([stream,coNvfp4VIAlyBUK6DziPs0Swu,int(ufQ5elFnNp)])
	xxbZwtDU1j2hTAz3e4LWRoKOP = KiryBCvngZzF85UN6xSDlOVweL4I9
	xVeMQ5mf9HLTl = YulwBtae3fh8DT0X64zd7(NTWE764hmOgUtScp2e8r,t5FkRbmHMxvgnzQqYIOidNf8ySJ)
	if xVeMQ5mf9HLTl:
		hMFBqSKDuHOfE59Pg36j8YaUk4RvL,sBjdeG1Pv7ufMhWLIa0bwQ,title,ufQ5elFnNp = xVeMQ5mf9HLTl[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		wwdXlMFUWhLDexN1cG8zTQ = hMFBqSKDuHOfE59Pg36j8YaUk4RvL[CyHU86ZeYT5BWRcitSm2I(u"ࠨࡷࡵࡰࠬർ")]
		if rVy3Ops0mohYkT(u"ࠩࡰࡴࡩ࠭ൽ") in title and wwdXlMFUWhLDexN1cG8zTQ!=N4thkp6MUXbuWLQImVTYqexs3Kr: xxbZwtDU1j2hTAz3e4LWRoKOP = r0D4C3z7Onqpa
		g4M0k6BxuWLAsaO = title
	else:
		FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1 = YulwBtae3fh8DT0X64zd7(NTWE764hmOgUtScp2e8r,t5FkRbmHMxvgnzQqYIOidNf8ySJ,GHg28TBchiyn6l(u"࠴࠹࠵࠶།"))
		FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1,TwfIJAF4XnVtL,ggJaYXQhbI5 = zip(*FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1)
		ra5B6JstxGEHhgRqky84FwWNIQpc2Y,nnvAB1at8XeIKdTkxoSQcPrVL0,Nzi5SIEcbo = [],[],j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		KC0S9Xk2nGzqTPOau43I5mwYs = sorted(KC0S9Xk2nGzqTPOau43I5mwYs, reverse=r0D4C3z7Onqpa, key=lambda key: float(key[vXIdY7TwFKso40gVBq5]))
		K1lPLX4fCOG,k2QyaXn1mbuedBpzYqDcx5R,jsdaiLEv74NrbWzA1Y = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		try: K1lPLX4fCOG = q5aXr4KvC2tAxhGz3wJkUydBWonmV[kdRO82AImh0LFw(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩൾ")][IMjqygdfYSKpHlWu5Aa(u"ࠫࡦࡻࡴࡩࡱࡵࠫൿ")]
		except:
			try: K1lPLX4fCOG = IqhkQAUWP7tbTC9[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ඀")][aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭ඁ")]
			except: pass
		try: k2QyaXn1mbuedBpzYqDcx5R = q5aXr4KvC2tAxhGz3wJkUydBWonmV[A41nqbj3wYt(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ං")][I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫඃ")]
		except:
			try: k2QyaXn1mbuedBpzYqDcx5R = IqhkQAUWP7tbTC9[mq5t9JXSdHT8yfDVF(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ඄")][gPE1XB87fQl(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭අ")]
			except: pass
		if K1lPLX4fCOG and k2QyaXn1mbuedBpzYqDcx5R:
			Nzi5SIEcbo += wnaWTQM7VJPkZzO9eoSyFU4
			title = e6HEdvUcaq8Gx+KLX7hW0nBAEgy6m4SvH(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ආ")+K1lPLX4fCOG+YVr6St5P4xsFC0aARQGKfiegD
			SOw5EUxC9k = A3pXVFdyP1.SITESURLS[gPE1XB87fQl(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ඇ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+SI7eBdND4lx8pt5Qk(u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩඈ")+k2QyaXn1mbuedBpzYqDcx5R
			ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(title)
			nnvAB1at8XeIKdTkxoSQcPrVL0.append(SOw5EUxC9k)
			try: jsdaiLEv74NrbWzA1Y = q5aXr4KvC2tAxhGz3wJkUydBWonmV[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ඉ")][CyHU86ZeYT5BWRcitSm2I(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫඊ")][gPE1XB87fQl(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭උ")][-wnaWTQM7VJPkZzO9eoSyFU4][I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡹࡷࡲࠧඌ")]
			except:
				try: jsdaiLEv74NrbWzA1Y = IqhkQAUWP7tbTC9[IMjqygdfYSKpHlWu5Aa(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪඍ")][VP70ytiFNMBl6vHDaW(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨඎ")][XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪඏ")][-wnaWTQM7VJPkZzO9eoSyFU4][beV5l2D8HznyJI0(u"ࠧࡶࡴ࡯ࠫඐ")]
				except: pass
		for gW3erOMAf0EQ,YqSFUPihAV,title,ufQ5elFnNp in FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1:
			ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(title) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(gPE1XB87fQl(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩඑ"))
		if PcRCZNh6V8Hq7UgMfjmYpoX: ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ุࠩ์ึฯ้ࠠื๋ฮ๋ࠥอะัฬࠫඒ")) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(iySORMYxWXszEH18(u"ࠪࡱࡺࡾࡥࡥࠩඓ"))
		if KC0S9Xk2nGzqTPOau43I5mwYs: ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(A6iX18qgyOFlZxz7sc(u"ฺࠫ๎ัสู๋ࠢํะࠠศๆ่ฮํ็ัࠨඔ")) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(CyHU86ZeYT5BWRcitSm2I(u"ࠬࡧ࡬࡭ࠩඕ"))
		if OcGkYahbMz9KuoZWSEd7NfyQAF3DH: ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(wwWzyF4ZpSQXKOgk569(u"࠭วฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫඖ")) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧ࡮ࡲࡧࠫ඗"))
		if TgEt8m7SWJb: ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(bawK2j7T81Nrc4GWs05xzDg(u"ࠨื๋ีฮࠦศะ๊้ࠤฺ๎สࠨ඘")) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(beV5l2D8HznyJI0(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ඙"))
		if eeW8uCYJfMBHXqQ5GwUvdVmN0: ra5B6JstxGEHhgRqky84FwWNIQpc2Y.append(tzZ6PhyDOUnwLM3pdK(u"ูࠪํะࠠษั๋๊ࠥ฻่าหࠪක")) ; nnvAB1at8XeIKdTkxoSQcPrVL0.append(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡦࡻࡤࡪࡱࠪඛ"))
		while r0D4C3z7Onqpa:
			XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(dmrEqRnX4VTBQZcAtJoa6f,ra5B6JstxGEHhgRqky84FwWNIQpc2Y)
			if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4: return aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪග"),[],[]
			elif XFaM94cPUCOWQZNIEe8gdJpny1==j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and K1lPLX4fCOG:
				SOw5EUxC9k = nnvAB1at8XeIKdTkxoSQcPrVL0[XFaM94cPUCOWQZNIEe8gdJpny1]
				gPNnhGvjZe = SZ0YL6RpbX.argv[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+iySORMYxWXszEH18(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠵࠹࠷ࠦ࡯ࡣࡰࡩࡂ࠭ඝ")+ZisgmEGCOJxVI9DcetNBPo6(K1lPLX4fCOG)+A41nqbj3wYt(u"ࠧࠧࡷࡵࡰࡂ࠭ඞ")+SOw5EUxC9k
				if jsdaiLEv74NrbWzA1Y: gPNnhGvjZe = gPNnhGvjZe+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࠨ࡬ࡱࡦ࡭ࡥ࠾ࠩඟ")+ZisgmEGCOJxVI9DcetNBPo6(jsdaiLEv74NrbWzA1Y)
				pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(rVy3Ops0mohYkT(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨච")+gPNnhGvjZe+rVy3Ops0mohYkT(u"ࠥ࠭ࠧඡ"))
				return aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩජ"),[],[]
			UqCAgBwjTuoVyn0evI = nnvAB1at8XeIKdTkxoSQcPrVL0[XFaM94cPUCOWQZNIEe8gdJpny1]
			g4M0k6BxuWLAsaO = ra5B6JstxGEHhgRqky84FwWNIQpc2Y[XFaM94cPUCOWQZNIEe8gdJpny1]
			if UqCAgBwjTuoVyn0evI==IMjqygdfYSKpHlWu5Aa(u"ࠬࡪࡡࡴࡪࠪඣ"):
				wwdXlMFUWhLDexN1cG8zTQ = N4thkp6MUXbuWLQImVTYqexs3Kr
				break
			elif UqCAgBwjTuoVyn0evI in [Z9FPQvwlbjLTh(u"࠭ࡡࡶࡦ࡬ࡳࠬඤ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡷ࡫ࡧࡩࡴ࠭ඥ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠨ࡯ࡸࡼࡪࡪࠧඦ")]:
				if UqCAgBwjTuoVyn0evI==ZLr5gRSkFewKdUos90bM(u"ࠩࡰࡹࡽ࡫ࡤࠨට"): ZD0qItXg31HmC7KGEFn,WcuEr9Sitq = PcRCZNh6V8Hq7UgMfjmYpoX,JeDn1Pu5gXzSGcYToQqKbml3
				elif UqCAgBwjTuoVyn0evI==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡺ࡮ࡪࡥࡰࠩඨ"): ZD0qItXg31HmC7KGEFn,WcuEr9Sitq = TgEt8m7SWJb,c5rXNQeo7i
				elif UqCAgBwjTuoVyn0evI==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡦࡻࡤࡪࡱࠪඩ"): ZD0qItXg31HmC7KGEFn,WcuEr9Sitq = eeW8uCYJfMBHXqQ5GwUvdVmN0,rr3TW6iR2YwIF
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(wwWzyF4ZpSQXKOgk569(u"ࠬอฮหำࠣห้๋ไโࠢࠫࠫඪ")+str(len(ZD0qItXg31HmC7KGEFn))+kdRO82AImh0LFw(u"࠭ࠠๆๆไ࠭ࠬණ"),ZD0qItXg31HmC7KGEFn)
				if XFaM94cPUCOWQZNIEe8gdJpny1!=-wnaWTQM7VJPkZzO9eoSyFU4:
					wwdXlMFUWhLDexN1cG8zTQ = WcuEr9Sitq[XFaM94cPUCOWQZNIEe8gdJpny1][CyHU86ZeYT5BWRcitSm2I(u"ࠧࡶࡴ࡯ࠫඬ")]
					g4M0k6BxuWLAsaO = ZD0qItXg31HmC7KGEFn[XFaM94cPUCOWQZNIEe8gdJpny1]
					break
			elif UqCAgBwjTuoVyn0evI==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࡯ࡳࡨࠬත"):
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(Z9FPQvwlbjLTh(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอࠥ࠮ࠧථ")+str(len(OcGkYahbMz9KuoZWSEd7NfyQAF3DH))+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠤ๊๊แࠪࠩද"),OcGkYahbMz9KuoZWSEd7NfyQAF3DH)
				if XFaM94cPUCOWQZNIEe8gdJpny1!=-wnaWTQM7VJPkZzO9eoSyFU4:
					g4M0k6BxuWLAsaO = OcGkYahbMz9KuoZWSEd7NfyQAF3DH[XFaM94cPUCOWQZNIEe8gdJpny1]
					hMFBqSKDuHOfE59Pg36j8YaUk4RvL = Q20QIcWykFtnTBh[XFaM94cPUCOWQZNIEe8gdJpny1]
					XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(mq5t9JXSdHT8yfDVF(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࠦࠨࠨධ")+str(len(Chn5E1OsFvT9BfI))+oiWNFYzcIUeh(u"ࠬࠦๅๅใࠬࠫන"),Chn5E1OsFvT9BfI)
					if XFaM94cPUCOWQZNIEe8gdJpny1!=-wnaWTQM7VJPkZzO9eoSyFU4:
						g4M0k6BxuWLAsaO += ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠠࠬࠢࠪ඲")+Chn5E1OsFvT9BfI[XFaM94cPUCOWQZNIEe8gdJpny1]
						sBjdeG1Pv7ufMhWLIa0bwQ = Tiu2jylP9Wz4[XFaM94cPUCOWQZNIEe8gdJpny1]
						xxbZwtDU1j2hTAz3e4LWRoKOP = r0D4C3z7Onqpa
						break
			elif UqCAgBwjTuoVyn0evI==gPE1XB87fQl(u"ࠧࡢ࡮࡯ࠫඳ"):
				IsmnJiZ0LNBx6p4HEfa9c,Jn0P2rzqtwjQ7CBevKYRfX,R1dvTK08ZNQ2Oh3Sbq,kLt4H0f1Qms7 = list(zip(*KC0S9Xk2nGzqTPOau43I5mwYs))
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(bawK2j7T81Nrc4GWs05xzDg(u"ࠨษัฮึࠦวๅ็็ๅࠥ࠮ࠧප")+str(len(R1dvTK08ZNQ2Oh3Sbq))+beV5l2D8HznyJI0(u"้้ࠩࠣ็ࠩࠨඵ"),R1dvTK08ZNQ2Oh3Sbq)
				if XFaM94cPUCOWQZNIEe8gdJpny1!=-wnaWTQM7VJPkZzO9eoSyFU4:
					g4M0k6BxuWLAsaO = R1dvTK08ZNQ2Oh3Sbq[XFaM94cPUCOWQZNIEe8gdJpny1]
					hMFBqSKDuHOfE59Pg36j8YaUk4RvL = IsmnJiZ0LNBx6p4HEfa9c[XFaM94cPUCOWQZNIEe8gdJpny1]
					if tzZ6PhyDOUnwLM3pdK(u"ࠪࡱࡵࡪࠧබ") in R1dvTK08ZNQ2Oh3Sbq[XFaM94cPUCOWQZNIEe8gdJpny1] and hMFBqSKDuHOfE59Pg36j8YaUk4RvL[yobpaW7sBqtKRrv(u"ࠫࡺࡸ࡬ࠨභ")]!=N4thkp6MUXbuWLQImVTYqexs3Kr:
						sBjdeG1Pv7ufMhWLIa0bwQ = Jn0P2rzqtwjQ7CBevKYRfX[XFaM94cPUCOWQZNIEe8gdJpny1]
						xxbZwtDU1j2hTAz3e4LWRoKOP = r0D4C3z7Onqpa
					else: wwdXlMFUWhLDexN1cG8zTQ = hMFBqSKDuHOfE59Pg36j8YaUk4RvL[iySORMYxWXszEH18(u"ࠬࡻࡲ࡭ࠩම")]
					break
			elif UqCAgBwjTuoVyn0evI==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧඹ"):
				IsmnJiZ0LNBx6p4HEfa9c,Jn0P2rzqtwjQ7CBevKYRfX,R1dvTK08ZNQ2Oh3Sbq,kLt4H0f1Qms7 = list(zip(*FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1))
				hMFBqSKDuHOfE59Pg36j8YaUk4RvL = IsmnJiZ0LNBx6p4HEfa9c[XFaM94cPUCOWQZNIEe8gdJpny1-Nzi5SIEcbo]
				if KLX7hW0nBAEgy6m4SvH(u"ࠧ࡮ࡲࡧࠫය") in R1dvTK08ZNQ2Oh3Sbq[XFaM94cPUCOWQZNIEe8gdJpny1-Nzi5SIEcbo] and hMFBqSKDuHOfE59Pg36j8YaUk4RvL[ZLr5gRSkFewKdUos90bM(u"ࠨࡷࡵࡰࠬර")]!=N4thkp6MUXbuWLQImVTYqexs3Kr:
					sBjdeG1Pv7ufMhWLIa0bwQ = Jn0P2rzqtwjQ7CBevKYRfX[XFaM94cPUCOWQZNIEe8gdJpny1-Nzi5SIEcbo]
					xxbZwtDU1j2hTAz3e4LWRoKOP = r0D4C3z7Onqpa
				else: wwdXlMFUWhLDexN1cG8zTQ = hMFBqSKDuHOfE59Pg36j8YaUk4RvL[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡸࡶࡱ࠭඼")]
				g4M0k6BxuWLAsaO = R1dvTK08ZNQ2Oh3Sbq[XFaM94cPUCOWQZNIEe8gdJpny1-Nzi5SIEcbo]
				break
	if xxbZwtDU1j2hTAz3e4LWRoKOP:
		VfcdDmZtIMNpELAT5kRHKuhX7CWz = int(hMFBqSKDuHOfE59Pg36j8YaUk4RvL[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬල")])
		u3uideNtAJ09nxaRSM = int(sBjdeG1Pv7ufMhWLIa0bwQ[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭඾")])
		gJVpmQ1oYbrkHaKnS4N3v2z = str(max(VfcdDmZtIMNpELAT5kRHKuhX7CWz,u3uideNtAJ09nxaRSM))
		llRGrMKUZay91WzY0AXIF = hMFBqSKDuHOfE59Pg36j8YaUk4RvL[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡻࡲ࡭ࠩ඿")].replace(oiWNFYzcIUeh(u"࠭ࠦࠨව"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࠧࡣࡰࡴࡀ࠭ශ"))
		llDRMZo8Bgb0pH1xFsSj5tP = sBjdeG1Pv7ufMhWLIa0bwQ[A41nqbj3wYt(u"ࠨࡷࡵࡰࠬෂ")].replace(SI7eBdND4lx8pt5Qk(u"ࠩࠩࠫස"),kdRO82AImh0LFw(u"ࠪࠪࡦࡳࡰ࠼ࠩහ"))
		mpd = rVy3Ops0mohYkT(u"ࠫࡁࡓࡐࡅࠢࡷࡽࡵ࡫࠽ࠣࡵࡷࡥࡹ࡯ࡣࠣࠢࡳࡶࡴ࡬ࡩ࡭ࡧࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡶࡲࡰࡨ࡬ࡰࡪࡀࡩࡴࡱࡩࡪ࠲ࡳࡡࡪࡰ࠽࠶࠵࠷࠱ࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫළ")+gJVpmQ1oYbrkHaKnS4N3v2z+gPE1XB87fQl(u"࡙ࠬࠢ࠿࡞ࡱࠫෆ")
		mpd += gPE1XB87fQl(u"࠭࠼ࡑࡧࡵ࡭ࡴࡪࠠࡪࡦࡀ࡛ࠦ࡯ࡤࡦࡱ࠮ࡅࡺࡪࡩࡰࠤࡁࡠࡳ࠭෇")
		mpd += SI7eBdND4lx8pt5Qk(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡻ࡯ࡤࡦࡱ࠲ࠫ෈")+hMFBqSKDuHOfE59Pg36j8YaUk4RvL[gPE1XB87fQl(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ෉")]+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁ්ࠧ࠭")+hMFBqSKDuHOfE59Pg36j8YaUk4RvL[YYQS36fyPvtuzcEmRL(u"ࠪࡧࡴࡪࡥࡤࡵࠪ෋")]+rVy3Ops0mohYkT(u"ࠫࠧࠦࡳࡵࡣࡵࡸ࡜࡯ࡴࡩࡕࡄࡔࡂࠨ࠱ࠣࠢࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ෌")
		mpd += iySORMYxWXszEH18(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࡻ࡯ࡤࡦࡱ࠴ࠦࡃࡢ࡮ࠨ෍")
		mpd += kdRO82AImh0LFw(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩ෎")+llRGrMKUZay91WzY0AXIF+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭ා")
		mpd += Z9FPQvwlbjLTh(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭ැ")+hMFBqSKDuHOfE59Pg36j8YaUk4RvL[gPE1XB87fQl(u"ࠩ࡬ࡲࡩ࡫ࡸࠨෑ")]+iySORMYxWXszEH18(u"ࠪࠦࡃࡢ࡮ࠨි")
		mpd += CyHU86ZeYT5BWRcitSm2I(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧී")+hMFBqSKDuHOfE59Pg36j8YaUk4RvL[VP70ytiFNMBl6vHDaW(u"ࠬ࡯࡮ࡪࡶࠪු")]+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭෕")
		mpd += jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪූ")
		mpd += A6iX18qgyOFlZxz7sc(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ෗")
		mpd += rVy3Ops0mohYkT(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧෘ")
		mpd += wwWzyF4ZpSQXKOgk569(u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧෙ")+sBjdeG1Pv7ufMhWLIa0bwQ[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ේ")]+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩෛ")+sBjdeG1Pv7ufMhWLIa0bwQ[mq5t9JXSdHT8yfDVF(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ො")]+Z9FPQvwlbjLTh(u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫෝ")
		mpd += IMjqygdfYSKpHlWu5Aa(u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࡢࡷࡧ࡭ࡴ࠷ࠢ࠿࡞ࡱࠫෞ")
		mpd += A6iX18qgyOFlZxz7sc(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬෟ")+llDRMZo8Bgb0pH1xFsSj5tP+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ෠")
		mpd += YYQS36fyPvtuzcEmRL(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ෡")+sBjdeG1Pv7ufMhWLIa0bwQ[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࡯࡮ࡥࡧࡻࠫ෢")]+GHg28TBchiyn6l(u"࠭ࠢ࠿࡞ࡱࠫ෣")
		mpd += IMjqygdfYSKpHlWu5Aa(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ෤")+sBjdeG1Pv7ufMhWLIa0bwQ[CyHU86ZeYT5BWRcitSm2I(u"ࠨ࡫ࡱ࡭ࡹ࠭෥")]+pp7FcjEe6g(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ෦")
		mpd += aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭෧")
		mpd += kdRO82AImh0LFw(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ෨")
		mpd += VP70ytiFNMBl6vHDaW(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ෩")
		mpd += pp7FcjEe6g(u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ෪")
		mpd += VP70ytiFNMBl6vHDaW(u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ෫")
		if rJ2oTLqabRtA:
			import http.server as esJCipn9wH4Fc0f21jyBWblDx8N
			import http.client as ooqMbDiEgF
		else:
			import BaseHTTPServer as esJCipn9wH4Fc0f21jyBWblDx8N
			import httplib as ooqMbDiEgF
		class cKhL4XCa2Ow(esJCipn9wH4Fc0f21jyBWblDx8N.HTTPServer):
			def __init__(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T,ip=SI7eBdND4lx8pt5Qk(u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ෬"),port=kdRO82AImh0LFw(u"࠹࠺࠶࠵࠶༎"),mpd=wwWzyF4ZpSQXKOgk569(u"ࠩ࠿ࡂࠬ෭")):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.ip = ip
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.port = port
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.mpd = mpd
				esJCipn9wH4Fc0f21jyBWblDx8N.HTTPServer.__init__(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T,(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.ip,Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.port),sslDLaUbHor)
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.mpdurl = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ෮")+ip+A6iX18qgyOFlZxz7sc(u"ࠫ࠿࠭෯")+str(port)+VP70ytiFNMBl6vHDaW(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ෰")
			def start(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.threads = ouEV7ZMghRakP24(KiryBCvngZzF85UN6xSDlOVweL4I9)
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.threads.b8nwpCGfrTHFm(wnaWTQM7VJPkZzO9eoSyFU4,Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.Amny47KeCFIVoq2lWB0EzZufSOLptH)
			def Amny47KeCFIVoq2lWB0EzZufSOLptH(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.keeprunning = r0D4C3z7Onqpa
				while Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.keeprunning:
					Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.handle_request()
			def stop(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.keeprunning = KiryBCvngZzF85UN6xSDlOVweL4I9
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.HHM0cE563ZamVogCODsWTLNJhGtquz()
			def HkVqKPiBdY2t0wf9reG(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.stop()
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.ccvQsgXNMH.close()
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.server_close()
			def Ydb3FwBZo9Vs6yOUhrvj4pn2EK(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T,mpd):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.mpd = mpd
			def HHM0cE563ZamVogCODsWTLNJhGtquz(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				OoE5HYUMwsrDWhx2gR7I3FuN = ooqMbDiEgF.HTTPConnection(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.ip+A6iX18qgyOFlZxz7sc(u"࠭࠺ࠨ෱")+str(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.port))
				OoE5HYUMwsrDWhx2gR7I3FuN.request(wwWzyF4ZpSQXKOgk569(u"ࠢࡉࡇࡄࡈࠧෲ"), CyHU86ZeYT5BWRcitSm2I(u"ࠣ࠱ࠥෳ"))
		class sslDLaUbHor(esJCipn9wH4Fc0f21jyBWblDx8N.BaseHTTPRequestHandler):
			def WGFL6N4yM2qhwRUe0r(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.send_response(kdRO82AImh0LFw(u"࠷࠶࠰༏"))
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.send_header(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ෴"),pp7FcjEe6g(u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ෵"))
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.end_headers()
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.wfile.write(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.VVpQfHc7IZamxweON3WXKU6Fg.mpd.encode(e87cIA5vwOQLDEP1))
				x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
				if Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.path==oiWNFYzcIUeh(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ෶"): Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.VVpQfHc7IZamxweON3WXKU6Fg.HkVqKPiBdY2t0wf9reG()
				if Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.path==gPE1XB87fQl(u"ࠬ࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ෷"): Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.VVpQfHc7IZamxweON3WXKU6Fg.HkVqKPiBdY2t0wf9reG()
			def qhCu8nfLmX6734FvcE(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.send_response(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠸࠰࠱༐"))
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.end_headers()
		fbhUs8IHk4BTFuaLK = cKhL4XCa2Ow(pp7FcjEe6g(u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ෸"),wwWzyF4ZpSQXKOgk569(u"࠵࠶࠲࠸࠹༑"),mpd)
		wwdXlMFUWhLDexN1cG8zTQ = fbhUs8IHk4BTFuaLK.mpdurl
		fbhUs8IHk4BTFuaLK.start()
	else: fbhUs8IHk4BTFuaLK = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if rJ2oTLqabRtA: LVqbOUmInWiM27j4f9ko,bqfLnQS54V7UOy6oa3 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࡝ࡶࠪ෹")
	else: LVqbOUmInWiM27j4f9ko,bqfLnQS54V7UOy6oa3 = CyHU86ZeYT5BWRcitSm2I(u"ࠨ࡞ࡷࠫ෺"),WnNGfosHr5STAq8j7miwyRZ6eOUbV
	onWb2EOgpY = LVqbOUmInWiM27j4f9ko+VP70ytiFNMBl6vHDaW(u"ࠩࡄࡹࡩ࡯࡯࠻ࠢ࡞ࠤࠬ෻")+sBjdeG1Pv7ufMhWLIa0bwQ[CyHU86ZeYT5BWRcitSm2I(u"ࠪࡹࡷࡲࠧ෼")]+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࠥࡣ࡜࡯࡞ࡷࡠࡹ࠭෽")+bqfLnQS54V7UOy6oa3+YYQS36fyPvtuzcEmRL(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ෾")+hMFBqSKDuHOfE59Pg36j8YaUk4RvL[bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡵࡳ࡮ࠪ෿")]+VP70ytiFNMBl6vHDaW(u"ࠧࠡ࡟ࠪ฀") if xxbZwtDU1j2hTAz3e4LWRoKOP else LVqbOUmInWiM27j4f9ko+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡃ࠮࡚࠿࡛ࠦࠡࠩก")+wwdXlMFUWhLDexN1cG8zTQ+yobpaW7sBqtKRrv(u"ࠩࠣࡡࠬข")
	SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+Z9FPQvwlbjLTh(u"ࠪࡠࡹࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡵࡴࡨࡥࡲࡀࠠ࡜ࠢࠪฃ")+g4M0k6BxuWLAsaO+A41nqbj3wYt(u"ࠫࠥࡣࠠࠡࠢࠪค")+onWb2EOgpY)
	if not wwdXlMFUWhLDexN1cG8zTQ: return bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬฅ"),[],[]
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[g4M0k6BxuWLAsaO],[[wwdXlMFUWhLDexN1cG8zTQ,BBfE5nyUDhY1uHxVFgXr,fbhUs8IHk4BTFuaLK]]
def PME0cJ1hnz5dT(url):
	headers = { wwWzyF4ZpSQXKOgk569(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪฆ") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧง"))
	items = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬจ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	items = set(items)
	items = sorted(items, reverse=r0D4C3z7Onqpa, key=lambda key: key[XURrDCfOS9Mbhpv2Pmjos56TeW])
	uuSPzLkIpg3xGY,ZD0qItXg31HmC7KGEFn,Slf7xhMejYsqON51QkwX6d9I,M0MFkiKqJDv1aZ4NA396u = [],[],[],[]
	if not items: return ZLr5gRSkFewKdUos90bM(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫฉ"),[],[]
	for SOw5EUxC9k,PN2AmVoTyks5xOR1Ib9BqSQ,z6PVkLf7Od in items:
		SOw5EUxC9k = SOw5EUxC9k.replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪช"),rVy3Ops0mohYkT(u"ࠫ࡭ࡺࡴࡱ࠼ࠪซ"))
		if oiWNFYzcIUeh(u"ࠬ࠴࡭࠴ࡷ࠻ࠫฌ") in SOw5EUxC9k:
			uuSPzLkIpg3xGY,Slf7xhMejYsqON51QkwX6d9I = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,SOw5EUxC9k)
			M0MFkiKqJDv1aZ4NA396u = M0MFkiKqJDv1aZ4NA396u + Slf7xhMejYsqON51QkwX6d9I
			if uuSPzLkIpg3xGY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]==CyHU86ZeYT5BWRcitSm2I(u"࠭࠭࠲ࠩญ"): ZD0qItXg31HmC7KGEFn.append(beV5l2D8HznyJI0(u"ࠧิ์ิๅึࠦฮศืࠪฎ")+ZLr5gRSkFewKdUos90bM(u"ࠨࠢࠣࠤࡲ࠹ࡵ࠹ࠩฏ"))
			else:
				for title in uuSPzLkIpg3xGY:
					ZD0qItXg31HmC7KGEFn.append(A41nqbj3wYt(u"ࠩึ๎ึ็ัࠡะสูࠬฐ")+jrD65cZUQ8uGR0IHNCkF+title)
		else:
			title = SI7eBdND4lx8pt5Qk(u"ࠪื๏ืแาࠢัหฺ࠭ฑ")+IMjqygdfYSKpHlWu5Aa(u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧฒ")+z6PVkLf7Od
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			ZD0qItXg31HmC7KGEFn.append(title)
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
def vg9WcsehHx(url,piN9Qlah4S):
	pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN,avJqWki71Bmel,cNmp4onf9T1FlKs6yreGQvCudP0,laAHpo1bzyM0q = [],[],[],[],[]
	if not isinstance(piN9Qlah4S,str): piN9Qlah4S = piN9Qlah4S.decode(e87cIA5vwOQLDEP1,mq5t9JXSdHT8yfDVF(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬณ"))
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(gPE1XB87fQl(u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧด"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k and not mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]): SOw5EUxC9k = []
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ต"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k and not mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]): SOw5EUxC9k = []
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧถ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k and not mm19wY7OfIvCxb8AFZEHJ(SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]): SOw5EUxC9k = []
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		title = SOw5EUxC9k.rsplit(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩ࠱ࠫท"),YYQS36fyPvtuzcEmRL(u"࠲༒"))[wnaWTQM7VJPkZzO9eoSyFU4]
		pixfvyGY1aJPowKZer34TcNblL7k2.append(title)
		wxT9bCdumN.append(SOw5EUxC9k)
	else:
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰ࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪࠩธ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not UOqp25uxcISGBPlAfbtzCNWXY4nvK: UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡻࡧࡲࠡࡵࡲࡹࡷࡩࡥࡴࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧน"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not UOqp25uxcISGBPlAfbtzCNWXY4nvK: UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡼࡡࡳࠢ࡭ࡻࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪบ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not UOqp25uxcISGBPlAfbtzCNWXY4nvK: UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall(KLX7hW0nBAEgy6m4SvH(u"࠭ࡶࡢࡴࠣࡴࡱࡧࡹࡦࡴࠣࡁࠥ࠴ࠪࡀ࡞ࠫࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮ࡢࠩࠨป"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			UOqp25uxcISGBPlAfbtzCNWXY4nvK = UOqp25uxcISGBPlAfbtzCNWXY4nvK[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.sub(bawK2j7T81Nrc4GWs05xzDg(u"ࡲࠨࠪ࡞ࡠࢀࡢࠬ࡞࡝࡟ࡸࡡࡹ࡜࡯࡞ࡵࡡ࠯࠯ࠨ࡝ࡹ࠮࡟ࡡࡺ࡜ࡴ࡟࠭࠭࠿࠭ผ"),gPE1XB87fQl(u"ࡳࠩ࡟࠵ࠧࡢ࠲ࠣ࠼ࠪฝ"),UOqp25uxcISGBPlAfbtzCNWXY4nvK)
			UOqp25uxcISGBPlAfbtzCNWXY4nvK = IXZpzK7ShaRsAN(CyHU86ZeYT5BWRcitSm2I(u"ࠩࡧ࡭ࡨࡺࠧพ"),UOqp25uxcISGBPlAfbtzCNWXY4nvK)
			if isinstance(UOqp25uxcISGBPlAfbtzCNWXY4nvK,dict): UOqp25uxcISGBPlAfbtzCNWXY4nvK = [UOqp25uxcISGBPlAfbtzCNWXY4nvK]
			for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
				rOL8VteszNH47v3FYnDRAlQEJ9w6,SOw5EUxC9k = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if isinstance(KDCdHQmgxPE21tYz4VUowSv,dict):
					keys = list(KDCdHQmgxPE21tYz4VUowSv.keys())
					if   beV5l2D8HznyJI0(u"ࠪࡸࡾࡶࡥࠨฟ") in keys: rOL8VteszNH47v3FYnDRAlQEJ9w6 = str(KDCdHQmgxPE21tYz4VUowSv[iySORMYxWXszEH18(u"ࠫࡹࡿࡰࡦࠩภ")])
					if   I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡬ࡩ࡭ࡧࠪม") in keys: SOw5EUxC9k = KDCdHQmgxPE21tYz4VUowSv[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡦࡪ࡮ࡨࠫย")]
					elif GHg28TBchiyn6l(u"ࠧࡩ࡮ࡶࠫร") in keys: SOw5EUxC9k = KDCdHQmgxPE21tYz4VUowSv[A41nqbj3wYt(u"ࠨࡪ࡯ࡷࠬฤ")]
					elif VP70ytiFNMBl6vHDaW(u"ࠩࡶࡶࡨ࠭ล") in keys: SOw5EUxC9k = KDCdHQmgxPE21tYz4VUowSv[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡷࡷࡩࠧฦ")]
					if   eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡱࡧࡢࡦ࡮ࠪว") in keys: title = str(KDCdHQmgxPE21tYz4VUowSv[A6iX18qgyOFlZxz7sc(u"ࠬࡲࡡࡣࡧ࡯ࠫศ")])
					elif KLX7hW0nBAEgy6m4SvH(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬษ") in keys: title = str(KDCdHQmgxPE21tYz4VUowSv[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ส")])
					elif mq5t9JXSdHT8yfDVF(u"ࠨ࠰ࠪห") in SOw5EUxC9k: title = SOw5EUxC9k.rsplit(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࠱ࠫฬ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
					else: title = SOw5EUxC9k
				elif isinstance(KDCdHQmgxPE21tYz4VUowSv,str):
					SOw5EUxC9k = KDCdHQmgxPE21tYz4VUowSv
					title = SOw5EUxC9k.rsplit(ZLr5gRSkFewKdUos90bM(u"ࠪ࠲ࠬอ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
				if wnaWTQM7VJPkZzO9eoSyFU4:
					pixfvyGY1aJPowKZer34TcNblL7k2.append(title+tTChquY7XSRg4e+rOL8VteszNH47v3FYnDRAlQEJ9w6)
					wxT9bCdumN.append(SOw5EUxC9k)
	for SOw5EUxC9k,title in list(zip(wxT9bCdumN,pixfvyGY1aJPowKZer34TcNblL7k2)):
		SOw5EUxC9k = SOw5EUxC9k.replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡡࡢ࠯ࠨฮ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬ࠵ࠧฯ"))
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,SI7eBdND4lx8pt5Qk(u"࠭ࡵࡳ࡮ࠪะ"))
		iHYO7Ic9kKUdPsgSCVyR = E1ltCBVyML6PAUNY()
		if ZLr5gRSkFewKdUos90bM(u"ࠧࡩࡶࡷࡴࠬั") not in SOw5EUxC9k: SOw5EUxC9k = VVpQfHc7IZamxweON3WXKU6Fg+SOw5EUxC9k
		if IMjqygdfYSKpHlWu5Aa(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧา") in SOw5EUxC9k:
			headers = {pp7FcjEe6g(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ำ"):iHYO7Ic9kKUdPsgSCVyR,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫิ"):VVpQfHc7IZamxweON3WXKU6Fg}
			hM6cTF7rOXNiAUDkJlY,kx5n2MH0TyoXKEesv3QVSa = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,SOw5EUxC9k,headers)
			cNmp4onf9T1FlKs6yreGQvCudP0 += kx5n2MH0TyoXKEesv3QVSa
			avJqWki71Bmel += hM6cTF7rOXNiAUDkJlY
		else:
			SOw5EUxC9k = SOw5EUxC9k+VP70ytiFNMBl6vHDaW(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪี")+iHYO7Ic9kKUdPsgSCVyR+A41nqbj3wYt(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨึ")+VVpQfHc7IZamxweON3WXKU6Fg
			cNmp4onf9T1FlKs6yreGQvCudP0.append(SOw5EUxC9k)
			avJqWki71Bmel.append(title)
	QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	if cNmp4onf9T1FlKs6yreGQvCudP0: QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN = WnNGfosHr5STAq8j7miwyRZ6eOUbV,avJqWki71Bmel,cNmp4onf9T1FlKs6yreGQvCudP0
	else:
		if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࠼ࠨื") not in piN9Qlah4S and len(piN9Qlah4S)<QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠳࠴༓") and piN9Qlah4S: QXqRvTME9DBPsVYmyecrxlI = piN9Qlah4S
		else:
			msg = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࠽ࡦ࡬ࡺࠥࡹࡴࡺ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬࡋ࡯࡬ࡦ࠰࠭ࡃ࠮ࡂุࠧ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if not msg: msg = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡱࡡࡹ࡭ࡩ࡫࡯ࡠࡵࡷࡹࡧࡥࡴࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ูࠫ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if not msg: msg = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠩ࠿࡬࠷ࡄࠨࡔࡱࡵࡶࡾ࠴ࠪࡀࠫ࠿ฺࠫ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if msg: QXqRvTME9DBPsVYmyecrxlI = msg[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	return QXqRvTME9DBPsVYmyecrxlI,pixfvyGY1aJPowKZer34TcNblL7k2,wxT9bCdumN
def K9KtYxGIUAdz6Ti0McBR(lIHoeG4Z9J2xba1gFPnfR8X3MwiO,url):
	global uLdj52csai1nIVp9Zqho6
	url = url.strip(YYQS36fyPvtuzcEmRL(u"ࠪ࠳ࠬ฻"))
	cNhzkJn693rIOf51WvDBAyZVEoR,rLqYZOtwMfBVs4k1TpE3X9aDy = WnNGfosHr5STAq8j7miwyRZ6eOUbV,{}
	headers = {beV5l2D8HznyJI0(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ฼"):E1ltCBVyML6PAUNY()}
	headers[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭฽")] = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,kdRO82AImh0LFw(u"࠭ࡵࡳ࡮ࠪ฾"))
	headers[A41nqbj3wYt(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ฿")] = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡧࡱ࠰ࡦࡸ࠻ࡲ࠿࠳࠲࠾࠭เ")
	headers[A6iX18qgyOFlZxz7sc(u"ࠩࡖࡩࡨ࠳ࡆࡦࡶࡦ࡬࠲ࡊࡥࡴࡶࠪแ")] = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪโ")
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡌࡋࡔࠨใ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧไ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	Gp6M78dwOUhrsaTzuxgXevYHyIW9D1 = WadGEeh1MBIXkpfP38qAv7ryslY.code
	if not isinstance(piN9Qlah4S,str): piN9Qlah4S = piN9Qlah4S.decode(e87cIA5vwOQLDEP1,YYQS36fyPvtuzcEmRL(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ๅ"))
	if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭ๆ") in piN9Qlah4S:
		llrcXE8g1yqbvQ = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ็"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if llrcXE8g1yqbvQ:
			try: cNhzkJn693rIOf51WvDBAyZVEoR = A1FcQEJDZe9zub2MCtfY4XnLo(llrcXE8g1yqbvQ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
			except: cNhzkJn693rIOf51WvDBAyZVEoR = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳ่ࠫࠪ") in piN9Qlah4S:
		llrcXE8g1yqbvQ = p7dwlH1PRStBgyMUW.findall(yobpaW7sBqtKRrv(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀ้ࠪ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if llrcXE8g1yqbvQ:
			try: cNhzkJn693rIOf51WvDBAyZVEoR = z3o4DEbwAJBUa(llrcXE8g1yqbvQ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
			except: cNhzkJn693rIOf51WvDBAyZVEoR = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	hFYoSTas7WOVnwN = piN9Qlah4S+cNhzkJn693rIOf51WvDBAyZVEoR
	if wwWzyF4ZpSQXKOgk569(u"ࠫࠧ࡯ࡤ࠳ࠤ๊ࠪ") in hFYoSTas7WOVnwN or rVy3Ops0mohYkT(u"ࠬࠨࡩࡥࠤ๋ࠪ") in hFYoSTas7WOVnwN:
		WpCK4v7kTz05iG6IlDsQhrF = url.split(yobpaW7sBqtKRrv(u"࠭࠯ࠨ์"))[vXIdY7TwFKso40gVBq5].replace(SI7eBdND4lx8pt5Qk(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧํ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(rVy3Ops0mohYkT(u"ࠨ࠰࡫ࡸࡲࡲࠧ๎"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if mq5t9JXSdHT8yfDVF(u"ࠩࠥ࡭ࡩ࠸ࠢࠨ๏") in hFYoSTas7WOVnwN: rLqYZOtwMfBVs4k1TpE3X9aDy = {tzZ6PhyDOUnwLM3pdK(u"ࠪ࡭ࡩ࠸ࠧ๐"):WpCK4v7kTz05iG6IlDsQhrF,KLX7hW0nBAEgy6m4SvH(u"ࠫࡴࡶࠧ๑"):eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨ๒")}
		elif ZLr5gRSkFewKdUos90bM(u"࠭ࠢࡪࡦࠥࠫ๓") in hFYoSTas7WOVnwN: rLqYZOtwMfBVs4k1TpE3X9aDy = {GHg28TBchiyn6l(u"ࠧࡪࡦࠪ๔"):WpCK4v7kTz05iG6IlDsQhrF,YYQS36fyPvtuzcEmRL(u"ࠨࡱࡳࠫ๕"):CyHU86ZeYT5BWRcitSm2I(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ๖")}
		W67hPCcaOek094 = headers.copy()
		W67hPCcaOek094[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ๗")] = SI7eBdND4lx8pt5Qk(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ๘")
		VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,mq5t9JXSdHT8yfDVF(u"ࠬࡖࡏࡔࡖࠪ๙"),url,rLqYZOtwMfBVs4k1TpE3X9aDy,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,SI7eBdND4lx8pt5Qk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨ๚"))
		hFYoSTas7WOVnwN = VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = vg9WcsehHx(url,hFYoSTas7WOVnwN)
	uLdj52csai1nIVp9Zqho6[lIHoeG4Z9J2xba1gFPnfR8X3MwiO] = QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,Gp6M78dwOUhrsaTzuxgXevYHyIW9D1
	return
uLdj52csai1nIVp9Zqho6,CnIAD9sxjiEpTrO = {},j0jEZgiKdxFpMLHcU7kQr8v1lyX4
def LLKjeCGcyAMHwdgokbZ2l6qfvYU(url):
	global uLdj52csai1nIVp9Zqho6,CnIAD9sxjiEpTrO
	CnIAD9sxjiEpTrO += beV5l2D8HznyJI0(u"࠴࠴࠵༔")
	mbeMQCF7BsLKrtx3If56WcXiH0 = CnIAD9sxjiEpTrO
	laAHpo1bzyM0q = [(wnaWTQM7VJPkZzO9eoSyFU4,url)]
	vcQbFfCk6T1 = url.replace(A6iX18qgyOFlZxz7sc(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ๛"),mq5t9JXSdHT8yfDVF(u"ࠨ࠱ࠪ๜"))
	ipdI4Kw1lMauxrtYoh = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧ๝"),vcQbFfCk6T1+A6iX18qgyOFlZxz7sc(u"ࠪ࠳ࠬ๞"),p7dwlH1PRStBgyMUW.DOTALL)
	try: start,YTydvQtj5Sfp3unBZXz7JcwC2oe,end = ipdI4Kw1lMauxrtYoh[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	except: return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡖࡎࡗࡍࡤ࡞ࡓࡉࡃࡕࡍࡓࡍࠧ๟"),[],[]
	end = end.strip(IMjqygdfYSKpHlWu5Aa(u"ࠬ࠵ࠧ๠"))
	WbKwgFdn4s6oMTtJ7S0aXucUx8 = len(YTydvQtj5Sfp3unBZXz7JcwC2oe)<yGLl1nSBrJPmi2adko9O or YTydvQtj5Sfp3unBZXz7JcwC2oe in [n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡦࡪ࡮ࡨࠫ๡"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡷ࡫ࡧࡩࡴ࠭๢"),rVy3Ops0mohYkT(u"ࠨࡸ࡬ࡨࡪࡵࡥ࡮ࡤࡨࡨࠬ๣"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡤ࡮ࡦࡾࠧ๤"),IMjqygdfYSKpHlWu5Aa(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪ๥"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡲ࡯ࡲࡳࡱࡵࠫ๦")]
	if not WbKwgFdn4s6oMTtJ7S0aXucUx8: laAHpo1bzyM0q.append([XURrDCfOS9Mbhpv2Pmjos56TeW,start+rVy3Ops0mohYkT(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭๧")+YTydvQtj5Sfp3unBZXz7JcwC2oe+tzZ6PhyDOUnwLM3pdK(u"࠭࠯ࠨ๨")+end])
	if end: laAHpo1bzyM0q.append([vXIdY7TwFKso40gVBq5,start+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧ࠰ࠩ๩")+YTydvQtj5Sfp3unBZXz7JcwC2oe+rVy3Ops0mohYkT(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ๪")+end])
	if GHg28TBchiyn6l(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ๫") in YTydvQtj5Sfp3unBZXz7JcwC2oe:
		f5fWKnsmFUlzoJ8ug7Eh = YTydvQtj5Sfp3unBZXz7JcwC2oe.replace(A41nqbj3wYt(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ๬"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		laAHpo1bzyM0q.append([yGLl1nSBrJPmi2adko9O,start+yobpaW7sBqtKRrv(u"ࠫ࠴࠭๭")+f5fWKnsmFUlzoJ8ug7Eh+A6iX18qgyOFlZxz7sc(u"ࠬ࠵ࠧ๮")+end])
		laAHpo1bzyM0q.append([eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠹༕"),start+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ๯")+f5fWKnsmFUlzoJ8ug7Eh+iySORMYxWXszEH18(u"ࠧ࠰ࠩ๰")+end])
		if end: laAHpo1bzyM0q.append([ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠻༖"),start+wwWzyF4ZpSQXKOgk569(u"ࠨ࠱ࠪ๱")+f5fWKnsmFUlzoJ8ug7Eh+iySORMYxWXszEH18(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ๲")+end])
	elif Z9FPQvwlbjLTh(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ๳") in end:
		POdozujksV4HWfK1JS = end.replace(wwWzyF4ZpSQXKOgk569(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ๴"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		laAHpo1bzyM0q.append([Z9FPQvwlbjLTh(u"࠽༗"),start+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬ࠵ࠧ๵")+YTydvQtj5Sfp3unBZXz7JcwC2oe+A41nqbj3wYt(u"࠭࠯ࠨ๶")+POdozujksV4HWfK1JS])
		if not WbKwgFdn4s6oMTtJ7S0aXucUx8: laAHpo1bzyM0q.append([jhDZ0BAFoEGUcw5QrJkaxXL(u"࠸༘"),start+yobpaW7sBqtKRrv(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ๷")+YTydvQtj5Sfp3unBZXz7JcwC2oe+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨ࠱ࠪ๸")+POdozujksV4HWfK1JS])
		laAHpo1bzyM0q.append([kdRO82AImh0LFw(u"࠺༙"),start+Z9FPQvwlbjLTh(u"ࠩ࠲ࠫ๹")+YTydvQtj5Sfp3unBZXz7JcwC2oe+pp7FcjEe6g(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ๺")+POdozujksV4HWfK1JS])
	else:
		if not WbKwgFdn4s6oMTtJ7S0aXucUx8: laAHpo1bzyM0q.append([lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠳࠳༚"),start+tzZ6PhyDOUnwLM3pdK(u"ࠫ࠴࠭๻")+YTydvQtj5Sfp3unBZXz7JcwC2oe+A41nqbj3wYt(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ๼")])
		if not WbKwgFdn4s6oMTtJ7S0aXucUx8: laAHpo1bzyM0q.append([jhDZ0BAFoEGUcw5QrJkaxXL(u"࠴࠵༛"),start+KLX7hW0nBAEgy6m4SvH(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ๽")+YTydvQtj5Sfp3unBZXz7JcwC2oe+gPE1XB87fQl(u"ࠧ࠯ࡪࡷࡱࡱ࠭๾")])
		if end: laAHpo1bzyM0q.append([A6iX18qgyOFlZxz7sc(u"࠵࠷༜"),start+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࠱ࠪ๿")+YTydvQtj5Sfp3unBZXz7JcwC2oe+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࠲ࠫ຀")+end+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠲࡭ࡺ࡭࡭ࠩກ")])
		if end: laAHpo1bzyM0q.append([YYQS36fyPvtuzcEmRL(u"࠶࠹༝"),start+Z9FPQvwlbjLTh(u"ࠫ࠴࠭ຂ")+YTydvQtj5Sfp3unBZXz7JcwC2oe+oiWNFYzcIUeh(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭຃")+end+A41nqbj3wYt(u"࠭࠮ࡩࡶࡰࡰࠬຄ")])
	if WbKwgFdn4s6oMTtJ7S0aXucUx8 and end:
		end = end.replace(bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ຅"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࠱ࠪຆ"))
		laAHpo1bzyM0q.append([Z9FPQvwlbjLTh(u"࠷࠴༞"),start+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩ࠲ࠫງ")+end])
		laAHpo1bzyM0q.append([oiWNFYzcIUeh(u"࠱࠶༟"),start+yobpaW7sBqtKRrv(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫຈ")+end])
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࠳࡮ࡴ࡮࡮ࠪຉ") in end:
			POdozujksV4HWfK1JS = end.replace(pp7FcjEe6g(u"ࠬ࠴ࡨࡵ࡯࡯ࠫຊ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			laAHpo1bzyM0q.append([VP70ytiFNMBl6vHDaW(u"࠲࠸༠"),start+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠯ࠨ຋")+POdozujksV4HWfK1JS])
			laAHpo1bzyM0q.append([I872Vum45fMNe1BRngTZLoQiqvkt(u"࠳࠺༡"),start+tzZ6PhyDOUnwLM3pdK(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨຌ")+POdozujksV4HWfK1JS])
		else:
			laAHpo1bzyM0q.append([YYQS36fyPvtuzcEmRL(u"࠴࠼༢"),start+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ࠱ࠪຍ")+end+ZLr5gRSkFewKdUos90bM(u"ࠩ࠱࡬ࡹࡳ࡬ࠨຎ")])
			laAHpo1bzyM0q.append([oiWNFYzcIUeh(u"࠵࠾༣"),start+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫຏ")+end+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࠳࡮ࡴ࡮࡮ࠪຐ")])
	hXDmRb7MkLjyi326o9TrtnP = []
	for MXZvtCRTuhcs6VN1K0LOwWDF,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr in laAHpo1bzyM0q:
		uLdj52csai1nIVp9Zqho6[mbeMQCF7BsLKrtx3If56WcXiH0+MXZvtCRTuhcs6VN1K0LOwWDF] = [OHohTgj06taKzsG,OHohTgj06taKzsG,OHohTgj06taKzsG,OHohTgj06taKzsG]
		I6MtZcjeAROnSxzDVNKm = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=K9KtYxGIUAdz6Ti0McBR,args=(mbeMQCF7BsLKrtx3If56WcXiH0+MXZvtCRTuhcs6VN1K0LOwWDF,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr))
		hXDmRb7MkLjyi326o9TrtnP.append(I6MtZcjeAROnSxzDVNKm)
	def YwoDWEq93VbFASGgTcZeKjH1zUsIlp():
		NU1y0Bce2G7S = KiryBCvngZzF85UN6xSDlOVweL4I9
		for U2vri4t3a8S in uLdj52csai1nIVp9Zqho6:
			if not U2vri4t3a8S: break
		else: NU1y0Bce2G7S = r0D4C3z7Onqpa
		iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying() if A3pXVFdyP1.resolveonly else r0D4C3z7Onqpa
		return NU1y0Bce2G7S or not iH7pE9rXVqy5k1Uu
	vGFdXD2x8ORu6aj(hXDmRb7MkLjyi326o9TrtnP,V6YmKcirsSBOvkEX5,QUtMNs40G5YLzv8b3,wnaWTQM7VJPkZzO9eoSyFU4,YwoDWEq93VbFASGgTcZeKjH1zUsIlp)
	QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[]
	GEWNyB7MUAp = []
	for MXZvtCRTuhcs6VN1K0LOwWDF,SOw5EUxC9k in laAHpo1bzyM0q:
		nd26rkRHFTNeIc,qJPR8md1Ntfv6BCS4,tJUgVF0c3bOw8j69KHezE,DkRfsNi5j74OVUp9MTA = uLdj52csai1nIVp9Zqho6[mbeMQCF7BsLKrtx3If56WcXiH0+MXZvtCRTuhcs6VN1K0LOwWDF]
		if not M0MFkiKqJDv1aZ4NA396u and tJUgVF0c3bOw8j69KHezE: ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = qJPR8md1Ntfv6BCS4,tJUgVF0c3bOw8j69KHezE
		if not QXqRvTME9DBPsVYmyecrxlI and nd26rkRHFTNeIc: QXqRvTME9DBPsVYmyecrxlI = nd26rkRHFTNeIc
		if DkRfsNi5j74OVUp9MTA: GEWNyB7MUAp.append(DkRfsNi5j74OVUp9MTA)
	GEWNyB7MUAp = list(set(GEWNyB7MUAp))
	if not QXqRvTME9DBPsVYmyecrxlI and len(GEWNyB7MUAp)==wnaWTQM7VJPkZzO9eoSyFU4:
		Gp6M78dwOUhrsaTzuxgXevYHyIW9D1 = GEWNyB7MUAp[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if Gp6M78dwOUhrsaTzuxgXevYHyIW9D1!=wwWzyF4ZpSQXKOgk569(u"࠷࠶࠰༤"):
			if Gp6M78dwOUhrsaTzuxgXevYHyIW9D1<j0jEZgiKdxFpMLHcU7kQr8v1lyX4: QXqRvTME9DBPsVYmyecrxlI = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡧࡧࡦ࠱ࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥࡰࡪ࠭ຑ")
			else:
				QXqRvTME9DBPsVYmyecrxlI = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡈࡕࡖࡓࠤࡊࡸࡲࡰࡴ࠽ࠤࠬຒ")+str(Gp6M78dwOUhrsaTzuxgXevYHyIW9D1)
				if rJ2oTLqabRtA: import http.client as ooqMbDiEgF
				else: import httplib as ooqMbDiEgF
				try: QXqRvTME9DBPsVYmyecrxlI += yobpaW7sBqtKRrv(u"ࠧࠡࠪࠣࠫຓ")+ooqMbDiEgF.responses[Gp6M78dwOUhrsaTzuxgXevYHyIW9D1]+A6iX18qgyOFlZxz7sc(u"ࠨࠢࠬࠫດ")
				except: pass
	x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
	return QXqRvTME9DBPsVYmyecrxlI,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u
class Hp28D5xftS(Zilvh2WQyb5.WindowDialog):
	def __init__(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T, *args, **CfYTkiPHgqX0rtcO):
		DroCj2wEi34zOpPBcb0xn9R78Vg5 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL, lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬຕ"), VP70ytiFNMBl6vHDaW(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧຖ"), XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡦ࡬࠴ࡰ࡯ࡩࠪທ"))
		t83VngNYbolpAZiqXOJ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL, iySORMYxWXszEH18(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨຘ"), I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪນ"), mq5t9JXSdHT8yfDVF(u"ࠧࡴࡧ࡯ࡩࡨࡺࡥࡥ࠰ࡳࡲ࡬࠭ບ"))
		ntNcIOGFCE3 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL, yobpaW7sBqtKRrv(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫປ"), iySORMYxWXszEH18(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭ຜ"), oiWNFYzcIUeh(u"ࠪࡦࡺࡺࡴࡰࡰࡩࡳ࠳ࡶ࡮ࡨࠩຝ"))
		mj3EGyTC9KvBzWb7w4fSXQJAD5Z2Pp = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL, Z9FPQvwlbjLTh(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧພ"), Z9FPQvwlbjLTh(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩຟ"), n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡢࡶࡶࡷࡳࡳࡴࡦ࠯ࡲࡱ࡫ࠬຠ"))
		SD26WLJOxwfpqPUzKb7Nc5AYvCXZ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL, eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪມ"), beV5l2D8HznyJI0(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬຢ"), tzZ6PhyDOUnwLM3pdK(u"ࠩࡥࡹࡹࡺ࡯࡯ࡤࡪ࠲ࡵࡴࡧࠨຣ"))
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelled = KiryBCvngZzF85UN6xSDlOVweL4I9
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chk = [j0jEZgiKdxFpMLHcU7kQr8v1lyX4] * beV5l2D8HznyJI0(u"࠿༥")
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton = [j0jEZgiKdxFpMLHcU7kQr8v1lyX4] * IMjqygdfYSKpHlWu5Aa(u"࠹༦")
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate = [KiryBCvngZzF85UN6xSDlOVweL4I9] * beV5l2D8HznyJI0(u"࠺༧")
		fJnPTjsCFprhwYMe1K2y7, rs8jJCxXzwN1y3l6cLdQFIUt, LanxCPv8hr24sXf, V2EP3unBAXrz4Tka8ciKxOspheSf6 = pp7FcjEe6g(u"࠴࠸࠴༨"), j0jEZgiKdxFpMLHcU7kQr8v1lyX4, eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠺࠴࠵༩"), IMjqygdfYSKpHlWu5Aa(u"࠻࠻࠶༪")
		HW1ZU5YsdnteP3Kc = fJnPTjsCFprhwYMe1K2y7+LanxCPv8hr24sXf//XURrDCfOS9Mbhpv2Pmjos56TeW
		xo64wsOXZtLceyr, yCobi9JL7kYtHrlNxBm6sv, X9fqBTD6Rco4xGM5p, OsSE2kHp7LalKiTZGN3o0zCDjPtU = IMjqygdfYSKpHlWu5Aa(u"࠹࠵࠶༬"), aiQwFE1TGx04vmLcsYkIW5jA(u"࠶࠸࠰༫"), tzZ6PhyDOUnwLM3pdK(u"࠵࠱࠲༭"), tzZ6PhyDOUnwLM3pdK(u"࠵࠱࠲༭")
		KSdXiCPyOQz6joNBRM80lw9HVguh = xo64wsOXZtLceyr+X9fqBTD6Rco4xGM5p//XURrDCfOS9Mbhpv2Pmjos56TeW
		WOr1flENPYI5suShUM2C7JpiGDje, ZxM5u1LGjUEqriJa3SCIefO, LTgCYSXFv53URmDW9IAGBqxJrhkM, ff37eovQTJs = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠳࠴༯"), kdRO82AImh0LFw(u"࠹࠹࠺༰"), tzZ6PhyDOUnwLM3pdK(u"࠲࠷࠳༮"), kdRO82AImh0LFw(u"࠹࠵༱")
		DnSmMQX81LANtUZlK3v5jspyzrR = HW1ZU5YsdnteP3Kc-LTgCYSXFv53URmDW9IAGBqxJrhkM-WOr1flENPYI5suShUM2C7JpiGDje//XURrDCfOS9Mbhpv2Pmjos56TeW
		eCcj6R0WtaSw7 = HW1ZU5YsdnteP3Kc+WOr1flENPYI5suShUM2C7JpiGDje//XURrDCfOS9Mbhpv2Pmjos56TeW
		VVzc2aWGvQ1, vW7M1ihD9GKqlgb, O7nNMDZ6X0Bu, pPCrcS6NaWzuK9Hd2X = A41nqbj3wYt(u"࠸࠻࠵༲"), oiWNFYzcIUeh(u"࠹࠰༳"), iySORMYxWXszEH18(u"࠶࠲࠳༵"), bawK2j7T81Nrc4GWs05xzDg(u"࠵࠱༴")
		LolkdWp61mZcUNTzXE, N3Aid0ut1zX, y1yzS0eG9TJC8NfBx6Fij, AAFqWLikdPTfhz6mMG3NgZQ2KrweV = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠵࠸࠹༶"), yobpaW7sBqtKRrv(u"࠼࠶༹"), ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠹࠵࠶༸"), oiWNFYzcIUeh(u"࠸࠴༷")
		Xpz2KbvcrunfEmAZCJ6hVQlwSqHa = yobpaW7sBqtKRrv(u"࠶࠮࠺༺")
		fJnPTjsCFprhwYMe1K2y7, rs8jJCxXzwN1y3l6cLdQFIUt, LanxCPv8hr24sXf, V2EP3unBAXrz4Tka8ciKxOspheSf6 = int(fJnPTjsCFprhwYMe1K2y7*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(rs8jJCxXzwN1y3l6cLdQFIUt*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(LanxCPv8hr24sXf*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(V2EP3unBAXrz4Tka8ciKxOspheSf6*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		xo64wsOXZtLceyr, yCobi9JL7kYtHrlNxBm6sv, X9fqBTD6Rco4xGM5p, OsSE2kHp7LalKiTZGN3o0zCDjPtU = int(xo64wsOXZtLceyr*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(yCobi9JL7kYtHrlNxBm6sv*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(X9fqBTD6Rco4xGM5p*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(OsSE2kHp7LalKiTZGN3o0zCDjPtU*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		DnSmMQX81LANtUZlK3v5jspyzrR, JrSc23hn1TXRuq7baHMyzkN, JeMfjxwnSP, E7kFw1Lvcyd = int(DnSmMQX81LANtUZlK3v5jspyzrR*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(ZxM5u1LGjUEqriJa3SCIefO*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(LTgCYSXFv53URmDW9IAGBqxJrhkM*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(ff37eovQTJs*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		eCcj6R0WtaSw7, BbW8A4fZk0QDhCcrv9J6yKXwdi13R, VtGHpceFSZXCx0JI2rBzAkNU, TpfZU96JzFu1H04DabPQk = int(eCcj6R0WtaSw7*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(ZxM5u1LGjUEqriJa3SCIefO*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(LTgCYSXFv53URmDW9IAGBqxJrhkM*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(ff37eovQTJs*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		VVzc2aWGvQ1, vW7M1ihD9GKqlgb, O7nNMDZ6X0Bu, pPCrcS6NaWzuK9Hd2X = int(VVzc2aWGvQ1*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(vW7M1ihD9GKqlgb*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(O7nNMDZ6X0Bu*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(pPCrcS6NaWzuK9Hd2X*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		LolkdWp61mZcUNTzXE, N3Aid0ut1zX, y1yzS0eG9TJC8NfBx6Fij, AAFqWLikdPTfhz6mMG3NgZQ2KrweV = int(LolkdWp61mZcUNTzXE*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(N3Aid0ut1zX*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(y1yzS0eG9TJC8NfBx6Fij*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa), int(AAFqWLikdPTfhz6mMG3NgZQ2KrweV*Xpz2KbvcrunfEmAZCJ6hVQlwSqHa)
		gGTeaZIkq6v9rVR = Zilvh2WQyb5.ControlImage(fJnPTjsCFprhwYMe1K2y7, rs8jJCxXzwN1y3l6cLdQFIUt, LanxCPv8hr24sXf, V2EP3unBAXrz4Tka8ciKxOspheSf6, DroCj2wEi34zOpPBcb0xn9R78Vg5)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(gGTeaZIkq6v9rVR)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.iteration = CfYTkiPHgqX0rtcO.get(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ࡭ࡹ࡫ࡲࡢࡶ࡬ࡳࡳ࠭຤"))
		gjS01nzA5K9qdDiGf4JL = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+ZLr5gRSkFewKdUos90bM(u"ࠫๆำีࠡล้หࠥหๆิษ้ࠤํ๊ำหࠢิ์อ๎สࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪລ")+KLX7hW0nBAEgy6m4SvH(u"ࠬอไๆฯส์้ฯࠠาไ่ࠤࠥ࠭຦")+str(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.iteration)+YVr6St5P4xsFC0aARQGKfiegD
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.strActionInfo = Zilvh2WQyb5.ControlLabel(VVzc2aWGvQ1, vW7M1ihD9GKqlgb, O7nNMDZ6X0Bu, pPCrcS6NaWzuK9Hd2X, gjS01nzA5K9qdDiGf4JL, rVy3Ops0mohYkT(u"࠭ࡦࡰࡰࡷ࠵࠸࠭ວ"))
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.strActionInfo)
		J4tO21KYAVdSr67W5NmiD0XhRP = Zilvh2WQyb5.ControlImage(xo64wsOXZtLceyr, yCobi9JL7kYtHrlNxBm6sv, X9fqBTD6Rco4xGM5p, OsSE2kHp7LalKiTZGN3o0zCDjPtU, CfYTkiPHgqX0rtcO.get(wwWzyF4ZpSQXKOgk569(u"ࠧࡤࡣࡳࡸࡨ࡮ࡡࠨຨ")))
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(J4tO21KYAVdSr67W5NmiD0XhRP)
		ptZ9GgjKLAlrWvkd2J7uC4a3bU = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+CfYTkiPHgqX0rtcO.get(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡯ࡶ࡫ࠬຩ"))+YVr6St5P4xsFC0aARQGKfiegD
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.strActionInfo = Zilvh2WQyb5.ControlLabel(LolkdWp61mZcUNTzXE, N3Aid0ut1zX, y1yzS0eG9TJC8NfBx6Fij, AAFqWLikdPTfhz6mMG3NgZQ2KrweV, ptZ9GgjKLAlrWvkd2J7uC4a3bU, oiWNFYzcIUeh(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩສ"))
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.strActionInfo)
		text = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+ZLr5gRSkFewKdUos90bM(u"ࠪาึ๎ฬࠨຫ")+YVr6St5P4xsFC0aARQGKfiegD
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton = Zilvh2WQyb5.ControlButton(DnSmMQX81LANtUZlK3v5jspyzrR, JrSc23hn1TXRuq7baHMyzkN, JeMfjxwnSP, E7kFw1Lvcyd, text, focusTexture=SD26WLJOxwfpqPUzKb7Nc5AYvCXZ, noFocusTexture=ntNcIOGFCE3, alignment=VP70ytiFNMBl6vHDaW(u"࠲༻"))
		text = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫฬูสๆำสีࠬຬ")+YVr6St5P4xsFC0aARQGKfiegD
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton = Zilvh2WQyb5.ControlButton(eCcj6R0WtaSw7, BbW8A4fZk0QDhCcrv9J6yKXwdi13R, VtGHpceFSZXCx0JI2rBzAkNU, TpfZU96JzFu1H04DabPQk, text, focusTexture=SD26WLJOxwfpqPUzKb7Nc5AYvCXZ, noFocusTexture=ntNcIOGFCE3, alignment=beV5l2D8HznyJI0(u"࠳༼"))
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton)
		e8LEoHwWRN5, YR8r3K4GndWXgBLi5elMSa0 = OsSE2kHp7LalKiTZGN3o0zCDjPtU//vXIdY7TwFKso40gVBq5, X9fqBTD6Rco4xGM5p//vXIdY7TwFKso40gVBq5
		for JrM1DoSuQ5n8 in range(SI7eBdND4lx8pt5Qk(u"࠻༽")):
			hKeEAwvM9tNl = JrM1DoSuQ5n8 // vXIdY7TwFKso40gVBq5
			JorWzf4IHvTnsMq13Fyi = JrM1DoSuQ5n8 % vXIdY7TwFKso40gVBq5
			BbXxoS62tp4aEjNPkuG1K7HCf5Iz = xo64wsOXZtLceyr + (YR8r3K4GndWXgBLi5elMSa0 * JorWzf4IHvTnsMq13Fyi)
			Dg1drNlBzqyi5paTX9t8kZf706 = yCobi9JL7kYtHrlNxBm6sv + (e8LEoHwWRN5 * hKeEAwvM9tNl)
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chk[JrM1DoSuQ5n8] = Zilvh2WQyb5.ControlImage(BbXxoS62tp4aEjNPkuG1K7HCf5Iz, Dg1drNlBzqyi5paTX9t8kZf706, YR8r3K4GndWXgBLi5elMSa0, e8LEoHwWRN5, t83VngNYbolpAZiqXOJ)
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chk[JrM1DoSuQ5n8])
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chk[JrM1DoSuQ5n8].setVisible(KiryBCvngZzF85UN6xSDlOVweL4I9)
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8] = Zilvh2WQyb5.ControlButton(BbXxoS62tp4aEjNPkuG1K7HCf5Iz, Dg1drNlBzqyi5paTX9t8kZf706, YR8r3K4GndWXgBLi5elMSa0, e8LEoHwWRN5, str(JrM1DoSuQ5n8 + wnaWTQM7VJPkZzO9eoSyFU4), font=mq5t9JXSdHT8yfDVF(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬອ"), focusTexture=ntNcIOGFCE3, noFocusTexture=mj3EGyTC9KvBzWb7w4fSXQJAD5Z2Pp)
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.addControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8])
		for JrM1DoSuQ5n8 in range(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠼༾")):
			XVOYt78PLj5SMK6niudoTB2vexFlyp = (JrM1DoSuQ5n8 // vXIdY7TwFKso40gVBq5) * vXIdY7TwFKso40gVBq5
			BnpSIGFyMkDceAXi9d2HEhwja = XVOYt78PLj5SMK6niudoTB2vexFlyp + (JrM1DoSuQ5n8 + wnaWTQM7VJPkZzO9eoSyFU4) % vXIdY7TwFKso40gVBq5
			eHYvDyQ5mZRFh96p8AWwIitbrGn = XVOYt78PLj5SMK6niudoTB2vexFlyp + (JrM1DoSuQ5n8 - wnaWTQM7VJPkZzO9eoSyFU4) % vXIdY7TwFKso40gVBq5
			hDkOpf4stR6XBYUl = (JrM1DoSuQ5n8 - vXIdY7TwFKso40gVBq5) % A41nqbj3wYt(u"࠽༿")
			mJFq36YrXUI7zS8BET4Pixunth = (JrM1DoSuQ5n8 + vXIdY7TwFKso40gVBq5) % n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠾ཀ")
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlRight(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[BnpSIGFyMkDceAXi9d2HEhwja])
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlLeft(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[eHYvDyQ5mZRFh96p8AWwIitbrGn])
			if JrM1DoSuQ5n8 <= XURrDCfOS9Mbhpv2Pmjos56TeW:
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlUp(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
			else:
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlUp(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[hDkOpf4stR6XBYUl])
			if JrM1DoSuQ5n8 >= pp7FcjEe6g(u"࠼ཁ"):
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlDown(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
			else:
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[JrM1DoSuQ5n8].controlDown(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[mJFq36YrXUI7zS8BET4Pixunth])
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton.controlLeft(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton.controlRight(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton.controlLeft(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton.controlRight(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton.controlDown(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[XURrDCfOS9Mbhpv2Pmjos56TeW])
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton.controlUp(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠸ག")])
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton.controlDown(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton.controlUp(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkbutton[yobpaW7sBqtKRrv(u"࠷གྷ")])
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.setFocus(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton)
	def get(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T):
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.doModal()
		Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.close()
		if not Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelled:
			return [JrM1DoSuQ5n8 for JrM1DoSuQ5n8 in range(wwWzyF4ZpSQXKOgk569(u"࠻ང")) if Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate[JrM1DoSuQ5n8]]
	def onControl(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T, FleHbt7G5acSJpq):
		if FleHbt7G5acSJpq.getId() == Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.okbutton.getId() and any(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate):
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.close()
		elif FleHbt7G5acSJpq.getId() == Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelbutton.getId():
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelled = r0D4C3z7Onqpa
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.close()
		else:
			z6PVkLf7Od = FleHbt7G5acSJpq.getLabel()
			if z6PVkLf7Od.isnumeric():
				index = int(z6PVkLf7Od) - wnaWTQM7VJPkZzO9eoSyFU4
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate[index] = not Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate[index]
				Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chk[index].setVisible(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.chkstate[index])
	def onAction(Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T, RAVgaEbSx8NZkzrewHJXhK6lC7):
		if RAVgaEbSx8NZkzrewHJXhK6lC7 == ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠴࠴ཅ"):
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.cancelled = r0D4C3z7Onqpa
			Wed9Nm2Vcyb0tQZDzKPUFLGMOH1T.close()
def oOqTixpjIEMWe5tRhf7ZL(key,wwurzsGRxpMfaCqc1J,url):
	headers = {rVy3Ops0mohYkT(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧຮ"):url,VP70ytiFNMBl6vHDaW(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩຯ"):wwurzsGRxpMfaCqc1J}
	Lr0Z4AyRSCkNztVYiscOH6WP5UvE = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠱ࡩࡥࡱࡲࡢࡢࡥ࡮ࡃࡰࡃࠧະ")+key
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,GHg28TBchiyn6l(u"ࠩࡊࡉ࡙࠭ັ"),Lr0Z4AyRSCkNztVYiscOH6WP5UvE,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠱ࡴࡶࠪາ"))
	pwNzhAPx5kYU7MEvXR3siJtQ8jn0H,iteration = WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	while r0D4C3z7Onqpa:
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		rLqYZOtwMfBVs4k1TpE3X9aDy = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࠧ࠮࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠲࠰ࡲࡤࡽࡱࡵࡡࡥ࡝ࡡࠦࡢ࠱ࠩࠨຳ"), piN9Qlah4S)
		iteration += wnaWTQM7VJPkZzO9eoSyFU4
		message = p7dwlH1PRStBgyMUW.findall(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡂ࡬ࡢࡤࡨࡰࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲ࡺࡥࡹࡶࠥ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯ࡥࡧ࡫࡬࠿ࠩິ"), piN9Qlah4S)
		if not message: message = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭࠼ࡥ࡫ࡹ࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡪࡸࡲࡰࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩີ"), piN9Qlah4S)
		if not message:
			pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = p7dwlH1PRStBgyMUW.findall(wwWzyF4ZpSQXKOgk569(u"ࠧࡳࡧࡤࡨࡴࡴ࡬ࡺࡀࠫ࠲࠯ࡅࠩ࠽ࠩຶ"), piN9Qlah4S)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			break
		else:
			message = message[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			rLqYZOtwMfBVs4k1TpE3X9aDy = rLqYZOtwMfBVs4k1TpE3X9aDy[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		ffIqS1hXbBJv2m3at97VNzxl0cKyur = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࡳࠩࡱࡥࡲ࡫࠽ࠣࡥࠥࡠࡸ࠱ࡶࡢ࡮ࡸࡩࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠧື"), piN9Qlah4S)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		i1aAU6tsVpC = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠩࡸຸ࠭") % (rLqYZOtwMfBVs4k1TpE3X9aDy.replace(IMjqygdfYSKpHlWu5Aa(u"ࠪࠪࡦࡳࡰ࠼ູࠩ"), A41nqbj3wYt(u"຺ࠫࠫ࠭")))
		message = p7dwlH1PRStBgyMUW.sub(GHg28TBchiyn6l(u"ࠬࡂ࠯ࡀࠪࡧ࡭ࡻࢂࡳࡵࡴࡲࡲ࡬࠯࡛࡟ࡀࡠ࠮ࡃ࠭ົ"), WnNGfosHr5STAq8j7miwyRZ6eOUbV, message)
		GbvgHpTcAZMNyCVRUqY1 = Hp28D5xftS(captcha=i1aAU6tsVpC, msg=message, iteration=iteration)
		Vn9rMWxbifBwUHcmXJLs46pCIhzv = GbvgHpTcAZMNyCVRUqY1.get()
		if not Vn9rMWxbifBwUHcmXJLs46pCIhzv: break
		data = {iySORMYxWXszEH18(u"࠭ࡣࠨຼ"): ffIqS1hXbBJv2m3at97VNzxl0cKyur, n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩຽ"): Vn9rMWxbifBwUHcmXJLs46pCIhzv}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,rVy3Ops0mohYkT(u"ࠨࡒࡒࡗ࡙࠭຾"),Lr0Z4AyRSCkNztVYiscOH6WP5UvE,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠸࡮ࡥࠩ຿"))
	return pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
def Z1dYgENA4UKcp2DOTPaCRm78HJ35(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭ເ"))
	items = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩແ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] ]
	else: return oiWNFYzcIUeh(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪໂ"),[],[]
def jwGLCdfPAmn1EhBoOJUktl9vgS6xi(url):
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
def gWDR5iyrvY6tk173VAXFIuTZ(url):
	VVpQfHc7IZamxweON3WXKU6Fg = url.split(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭࠯ࠨໃ"))
	AR8nlBzHQbCy7EejsOigoXv = bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࠰ࠩໄ").join(VVpQfHc7IZamxweON3WXKU6Fg[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:vXIdY7TwFKso40gVBq5])
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅ࠮࠳ࡶࡸࠬ໅"))
	items = p7dwlH1PRStBgyMUW.findall(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡧࡰࡧࡻࡴࡵࡱࡱࡠࠬࡢࠩ࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠢ࡟࠯ࠥࡢࠨࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩࠡ࡞࠮ࠤ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࡡ࠯ࠠ࡝࠭ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫໆ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN,Ps6p25Y9evV1iqgH,WMHqZYDAidl9mBjrFnGvUJR6h,pSE90osRQgNDmyL,PiNXktoRAQTfGuI4C6SYOms = items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		rIQWSTdngFy9ui6bHNREK = int(V6QAOWYLrf53bSFCnN) % int(Ps6p25Y9evV1iqgH) + int(WMHqZYDAidl9mBjrFnGvUJR6h) % int(pSE90osRQgNDmyL)
		url = AR8nlBzHQbCy7EejsOigoXv + xqK9cBVPiU05fNhdOZrpzsGDlTX + str(rIQWSTdngFy9ui6bHNREK) + PiNXktoRAQTfGuI4C6SYOms
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[url]
	else: return wwWzyF4ZpSQXKOgk569(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ໇"),[],[]
def rs5BfXwCFgGt17IdJ3EVlhaRp(url):
	id = url.split(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࠴່࠭"))[-wnaWTQM7VJPkZzO9eoSyFU4]
	headers = { QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨ້ࠫ") : gPE1XB87fQl(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨ໊ࠬ") }
	rLqYZOtwMfBVs4k1TpE3X9aDy = { I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠢࡪࡦ໋ࠥ"):id , A41nqbj3wYt(u"ࠣࡱࡳࠦ໌"):CyHU86ZeYT5BWRcitSm2I(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧໍ") }
	dlPQGb0aC5xmfFwy9ievKTqX = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,Z9FPQvwlbjLTh(u"ࠪࡔࡔ࡙ࡔࠨ໎"), url, rLqYZOtwMfBVs4k1TpE3X9aDy, headers, WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ໏"))
	if oiWNFYzcIUeh(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ໐") in list(dlPQGb0aC5xmfFwy9ievKTqX.headers.keys()): SOw5EUxC9k = dlPQGb0aC5xmfFwy9ievKTqX.headers[wwWzyF4ZpSQXKOgk569(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ໑")]
	else: SOw5EUxC9k = url
	if SOw5EUxC9k: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[SOw5EUxC9k]
	else: return iySORMYxWXszEH18(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬ໒"),[],[]
def HIZORMPdctxfzj8i20G7(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ໓"))
	items = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ໔"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] ]
	else: return A41nqbj3wYt(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨ໕"),[],[]
def C0XuBqjF7mo3slfENptY6WP9yw(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬ໖"))
	items = p7dwlH1PRStBgyMUW.findall(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ໗"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		url = url = eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬ໘") + items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ url ]
	else: return lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ໙"),[],[]
def evUCYmG8cpuWlZjHxqb6k5D1Xd(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ໚"))
	items = p7dwlH1PRStBgyMUW.findall(Z9FPQvwlbjLTh(u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ໛"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[WnNGfosHr5STAq8j7miwyRZ6eOUbV],[ items[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] ]
	else: return rVy3Ops0mohYkT(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡓࡕࡔࡈࡅࡒ࠭ໜ"),[],[]