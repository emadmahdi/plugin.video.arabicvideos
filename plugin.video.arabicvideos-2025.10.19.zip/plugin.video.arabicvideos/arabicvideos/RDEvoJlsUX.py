# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'FASELHD2'
headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_FH2_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['FaselHD']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==590: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==591: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==592: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==593: APpdhB1Fk58MmJH7CjVntowyaY = GWZnSU3af6H4mhzrElwA9(url,text)
	elif mode==599: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	VVDAncSMUjeu8Ii = pcE6DxaoHBm41WKXjwnk
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',VVDAncSMUjeu8Ii,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD2-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',VVDAncSMUjeu8Ii,599,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	items = p7dwlH1PRStBgyMUW.findall('<h3>(.*?)<.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	L3LoVh5B7OZMbHJlPXQ6EjnaUks = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	for title,SOw5EUxC9k in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,591,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured'+str(L3LoVh5B7OZMbHJlPXQ6EjnaUks))
		L3LoVh5B7OZMbHJlPXQ6EjnaUks += wnaWTQM7VJPkZzO9eoSyFU4
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"main-menu"(.*?)</nav>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		QQSoCIghku5DA = p7dwlH1PRStBgyMUW.findall('<li (.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for xolUtmyJWcC0eR7 in QQSoCIghku5DA:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',xolUtmyJWcC0eR7,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+SOw5EUxC9k
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,591)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,nxeRBuVLTiHaSJEp30XN5P4dbG=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD2-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = []
	if 'featured' in nxeRBuVLTiHaSJEp30XN5P4dbG:
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = nxeRBuVLTiHaSJEp30XN5P4dbG[-wnaWTQM7VJPkZzO9eoSyFU4]
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"boxes--holder"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[int(L3LoVh5B7OZMbHJlPXQ6EjnaUks)]
	elif nxeRBuVLTiHaSJEp30XN5P4dbG=='filters':
		cKUQVwTMe9tZSY = [piN9Qlah4S.replace('\\/','/').replace('\\"','"')]
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"boxes--holder"(.*?)"pagination"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if not items: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		try: title = title.encode(fFnsCZYWeuh89D).decode(e87cIA5vwOQLDEP1)
		except: pass
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if any(value in title.lower() for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if '/movseries/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,591,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz:
			title = '_MOD_'+er96jwp52cbvaV48mtylEYSRz[0][0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,593,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif any(value in title for value in gbtIyQYJ854dkEhXfaev): octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,592,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,593,J4tO21KYAVdSr67W5NmiD0XhRP)
	if nxeRBuVLTiHaSJEp30XN5P4dbG=='filters':
		qqeo9DwgEIuKJfdFvm8r63XO5anT = p7dwlH1PRStBgyMUW.findall('"more_button_page":(.*?),',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if qqeo9DwgEIuKJfdFvm8r63XO5anT:
			count = qqeo9DwgEIuKJfdFvm8r63XO5anT[0]
			SOw5EUxC9k = url+'/offset/'+count
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة أخرى',SOw5EUxC9k,591,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
	elif 'featured' not in nxeRBuVLTiHaSJEp30XN5P4dbG:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,591,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'details4')
	return
def GWZnSU3af6H4mhzrElwA9(url,data=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD2-SEASONS_EPISODES-1st')
		piN9Qlah4S = '"EpisodesList"'+WadGEeh1MBIXkpfP38qAv7ryslY.content+'</div>'
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD2-SEASONS_EPISODES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	bLhqw36zAp7uKxJIM4r502UGRT = p7dwlH1PRStBgyMUW.findall('"inner--image"><img src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	J4tO21KYAVdSr67W5NmiD0XhRP = bLhqw36zAp7uKxJIM4r502UGRT[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if bLhqw36zAp7uKxJIM4r502UGRT else WnNGfosHr5STAq8j7miwyRZ6eOUbV
	items = []
	if not data:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"SeasonsList"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			items = p7dwlH1PRStBgyMUW.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if len(items)>1:
				for sswWia2EuAo8ZQ4jPX,LW28MawRZDVkYCSjX,title in items:
					SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					bZ0VWjAHm1v2Csroh = 'season='+LW28MawRZDVkYCSjX+'&post_id='+sswWia2EuAo8ZQ4jPX
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,593,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bZ0VWjAHm1v2Csroh)
		data = r0D4C3z7Onqpa
	if data and len(items)<XURrDCfOS9Mbhpv2Pmjos56TeW:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"EpisodesList"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<em>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,DnBsO9opYvF7wmy8NEtCZVq5Slc6k,gPvxJw89S35R21zDIbpFYkq7A in items:
				title = DnBsO9opYvF7wmy8NEtCZVq5Slc6k+kcXMWrwiLDKeBHRsJ+gPvxJw89S35R21zDIbpFYkq7A
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,592,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	url = url.strip('/')+'/watch/'
	wxT9bCdumN,RRHs7TOLv3ENht8l6,cNmp4onf9T1FlKs6yreGQvCudP0 = [],[],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD2-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	XnSt7DH8vsEKmBFdMerGUTP9Oz564 = p7dwlH1PRStBgyMUW.findall('العمر :.*?<strong">(.*?)</strong>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if XnSt7DH8vsEKmBFdMerGUTP9Oz564 and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,XnSt7DH8vsEKmBFdMerGUTP9Oz564): return
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('<iframe src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[0]
		wxT9bCdumN.append(SOw5EUxC9k+'?named=__embed')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"main--contents"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for ENfq7iAbK5yDLu1YkFhoZen,sswWia2EuAo8ZQ4jPX,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+sswWia2EuAo8ZQ4jPX+'&i='+ENfq7iAbK5yDLu1YkFhoZen
			wxT9bCdumN.append(SOw5EUxC9k+'?named='+title+'__watch')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"downloads"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name in items:
			wxT9bCdumN.append(SOw5EUxC9k+'?named='+name+'__download')
	for fzCsdrHpZb4G6Q8aMNt in wxT9bCdumN:
		SOw5EUxC9k,name = fzCsdrHpZb4G6Q8aMNt.split('?named')
		if SOw5EUxC9k not in RRHs7TOLv3ENht8l6:
			RRHs7TOLv3ENht8l6.append(SOw5EUxC9k)
			cNmp4onf9T1FlKs6yreGQvCudP0.append(fzCsdrHpZb4G6Q8aMNt)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(cNmp4onf9T1FlKs6yreGQvCudP0,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	VVDAncSMUjeu8Ii = pcE6DxaoHBm41WKXjwnk
	url = VVDAncSMUjeu8Ii+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(url,'details5')
	return