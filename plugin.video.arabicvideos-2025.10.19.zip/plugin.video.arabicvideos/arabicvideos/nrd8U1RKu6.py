# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ARABSEED'
headers = {'User-Agent':E1ltCBVyML6PAUNY()}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_ARS_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==250: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==251: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==252: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==253: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==254: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'CATEGORIES___'+text)
	elif mode==255: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'FILTERS___'+text)
	elif mode==256: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url,text)
	elif mode==259: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/main',WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,259,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',pcE6DxaoHBm41WKXjwnk+'/category/اخرى',254)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',pcE6DxaoHBm41WKXjwnk+'/category/اخرى',255)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',pcE6DxaoHBm41WKXjwnk+'/main',251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured_main')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"menu__bar hide__md"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	s5ocIDd4WKuPrV = ZAIyluJa1EWhdB7OHV5CRGSrk[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)<',s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in YacIZtAGdEPsFhSe:
		if '/category/' not in SOw5EUxC9k: continue
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if title not in EViWBhSw3dea8pTUO9AFMKbGjks027 and title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,251)
	return piN9Qlah4S
def uJlhLk2Tbcd(url,type):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if 'class="SliderInSection' in piN9Qlah4S: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الأكثر مشاهدة',url,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'most')
	if 'class="MainSlides' in piN9Qlah4S: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',url,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	if 'class="LinksList' in piN9Qlah4S:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="LinksList(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			if len(cKUQVwTMe9tZSY)>1 and type=='new_episodes': KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[1]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				gPvxJw89S35R21zDIbpFYkq7A = p7dwlH1PRStBgyMUW.findall('</i>(.*?)<span>(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
				try: CIeL32XZ57bpg6WFyKB = gPvxJw89S35R21zDIbpFYkq7A[0][0].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				except: CIeL32XZ57bpg6WFyKB = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				try: eVcFjAaf7huW3rlQsJqBbDwkgT = gPvxJw89S35R21zDIbpFYkq7A[0][1].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				except: eVcFjAaf7huW3rlQsJqBbDwkgT = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				gPvxJw89S35R21zDIbpFYkq7A = CIeL32XZ57bpg6WFyKB+kcXMWrwiLDKeBHRsJ+eVcFjAaf7huW3rlQsJqBbDwkgT
				if '<strong>' in title:
					Hby7ceqmR2ENfak5391Lrd = p7dwlH1PRStBgyMUW.findall('</i>(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
					if Hby7ceqmR2ENfak5391Lrd: gPvxJw89S35R21zDIbpFYkq7A = Hby7ceqmR2ENfak5391Lrd[0]
				if not gPvxJw89S35R21zDIbpFYkq7A:
					Hby7ceqmR2ENfak5391Lrd = p7dwlH1PRStBgyMUW.findall('alt="(.*?)"',title,p7dwlH1PRStBgyMUW.DOTALL)
					if Hby7ceqmR2ENfak5391Lrd: gPvxJw89S35R21zDIbpFYkq7A = Hby7ceqmR2ENfak5391Lrd[0]
				if gPvxJw89S35R21zDIbpFYkq7A:
					if 'key=' in SOw5EUxC9k: type = SOw5EUxC9k.split('key=')[1]
					else: type = 'newest'
					gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.strip(kcXMWrwiLDKeBHRsJ)
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,SOw5EUxC9k,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
	return
def ctDj2OVRyaUPXCrITmJG(url,nxeRBuVLTiHaSJEp30XN5P4dbG):
	S5orefWm8D4k6bw1Ops,data,items = 'GET',WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	if nxeRBuVLTiHaSJEp30XN5P4dbG=='filters':
		if '?' in url:
			DGuNdjlcYQ9y8nUa4ZJ3z1V,bZ0VWjAHm1v2Csroh = 'POST',{}
			vcQbFfCk6T1,KnEazvPsXD8IGpThxi96Lfb = url.split('?')
			bbiBPLGW5cmhv = KnEazvPsXD8IGpThxi96Lfb.split('&')
			for AuNfQI1cKXGdWoU in bbiBPLGW5cmhv:
				key,value = AuNfQI1cKXGdWoU.split('=')
				bZ0VWjAHm1v2Csroh[key] = value
			if bbiBPLGW5cmhv: S5orefWm8D4k6bw1Ops,url,data = DGuNdjlcYQ9y8nUa4ZJ3z1V,vcQbFfCk6T1,bZ0VWjAHm1v2Csroh
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,S5orefWm8D4k6bw1Ops,url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if nxeRBuVLTiHaSJEp30XN5P4dbG=='filters': cKUQVwTMe9tZSY = [piN9Qlah4S]
	elif 'featured' in nxeRBuVLTiHaSJEp30XN5P4dbG: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="MainSlides(.*?)class="LinksList',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif nxeRBuVLTiHaSJEp30XN5P4dbG=='new_movies': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif nxeRBuVLTiHaSJEp30XN5P4dbG=='new_episodes': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif nxeRBuVLTiHaSJEp30XN5P4dbG=='most': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="SliderInSection(.*?)class="LinksList',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"blocks__section(.*?)"paginate"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if 'featured' in nxeRBuVLTiHaSJEp30XN5P4dbG:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		tSoDe0Mjmk = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if tSoDe0Mjmk:
			M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn,MoTAB3i4lZrjkgp17hV,Gs9lnhfSDkraTigzZ = zip(*tSoDe0Mjmk)
			items = zip(M0MFkiKqJDv1aZ4NA396u,Gs9lnhfSDkraTigzZ,ZD0qItXg31HmC7KGEFn)
	else:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		if 'WWE' in title: continue
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if 'الحلقة' in title:
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if er96jwp52cbvaV48mtylEYSRz:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,253,J4tO21KYAVdSr67W5NmiD0XhRP)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,252,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/selary/' in SOw5EUxC9k or 'مسلسل' in title:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,253,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,252,J4tO21KYAVdSr67W5NmiD0XhRP)
	if wnaWTQM7VJPkZzO9eoSyFU4:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"paginate"(.*?)</section>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,nxeRBuVLTiHaSJEp30XN5P4dbG)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('"poster__single".*?data-src="(.*?)".*?alt="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: return
	J4tO21KYAVdSr67W5NmiD0XhRP,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(kcXMWrwiLDKeBHRsJ)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(kcXMWrwiLDKeBHRsJ)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"episodes__list boxs__wrapper(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,er96jwp52cbvaV48mtylEYSRz in items:
			title = name+' - حلقة رقم '+er96jwp52cbvaV48mtylEYSRz
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,252,J4tO21KYAVdSr67W5NmiD0XhRP)
	else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+'ملف التشغيل',url,252,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def vvGga079tJlE1RS4BxfATKO(title,SOw5EUxC9k):
	gPvxJw89S35R21zDIbpFYkq7A = p7dwlH1PRStBgyMUW.findall('[a-zA-Z-]+',title,p7dwlH1PRStBgyMUW.DOTALL)
	if gPvxJw89S35R21zDIbpFYkq7A: title = gPvxJw89S35R21zDIbpFYkq7A[0]
	else: title = title+kcXMWrwiLDKeBHRsJ+OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
	title = title.replace('عرب سيد',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('مباشر',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('مشاهدة',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	title = title.replace('ٍ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	title = title.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	return title
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	headers = {'Referer':VVpQfHc7IZamxweON3WXKU6Fg}
	wxT9bCdumN = []
	zaqgpH3uobjwEnM7mYy6Vdsr = p7dwlH1PRStBgyMUW.findall('href="([^"]*)" class="btton download__btn"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if zaqgpH3uobjwEnM7mYy6Vdsr:
		zaqgpH3uobjwEnM7mYy6Vdsr = zaqgpH3uobjwEnM7mYy6Vdsr[0]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',zaqgpH3uobjwEnM7mYy6Vdsr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"tabs__holder(.*?)</section>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,DnBsO9opYvF7wmy8NEtCZVq5Slc6k,gPvxJw89S35R21zDIbpFYkq7A in items:
				DIBw28Qfje76bTMzVNYhxrgWmO = p7dwlH1PRStBgyMUW.findall('\d+',gPvxJw89S35R21zDIbpFYkq7A,p7dwlH1PRStBgyMUW.DOTALL)
				DIBw28Qfje76bTMzVNYhxrgWmO = '__'+DIBw28Qfje76bTMzVNYhxrgWmO[0] if DIBw28Qfje76bTMzVNYhxrgWmO else WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if '/l/' in SOw5EUxC9k:
					SOw5EUxC9k = SOw5EUxC9k.split('/l/')[1]
					SOw5EUxC9k = uvGCPpFwVmTQ36.b64decode(SOw5EUxC9k)
					if rJ2oTLqabRtA: SOw5EUxC9k = SOw5EUxC9k.decode(e87cIA5vwOQLDEP1)
				SOw5EUxC9k = SOw5EUxC9k+'?named='+DnBsO9opYvF7wmy8NEtCZVq5Slc6k+'__download'+DIBw28Qfje76bTMzVNYhxrgWmO
				wxT9bCdumN.append(SOw5EUxC9k)
	pvEZYbdxKhq1knCRgfJ5yOtojGQP = p7dwlH1PRStBgyMUW.findall('href="(.*?)" class="btton watch__btn"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and pvEZYbdxKhq1knCRgfJ5yOtojGQP:
		pvEZYbdxKhq1knCRgfJ5yOtojGQP = pvEZYbdxKhq1knCRgfJ5yOtojGQP[0]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pvEZYbdxKhq1knCRgfJ5yOtojGQP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"watch__area"(.*?)<section',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('href="(.*?)" class="btton download__btn"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def TK0NhovpfkCreB3UcqSXuJV8t(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	vcQbFfCk6T1 = WadGEeh1MBIXkpfP38qAv7ryslY.url
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,'url')
	headers['Referer'] = VVpQfHc7IZamxweON3WXKU6Fg+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	M0MFkiKqJDv1aZ4NA396u,xJpw3ZzlvrY9KS = [],[]
	HXbcgWp1CQ3ZkuxYiV5GTj,IksCuE7tGq1Q9w,F4Pz0lfUZ6thdpH = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	auiznBWPYG6dgsqb5RySXxh4Ct,Ph1bWOtz4LYmGCuVfxBqXlR,NgR4W6cEq7hzKDH518TUSIPmo = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	r06ENuXFTicjOBYtoVm = p7dwlH1PRStBgyMUW.findall('"WatchButtons"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if r06ENuXFTicjOBYtoVm:
		KDCdHQmgxPE21tYz4VUowSv = r06ENuXFTicjOBYtoVm[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if '<form' in KDCdHQmgxPE21tYz4VUowSv:
			xJpw3ZzlvrY9KS = p7dwlH1PRStBgyMUW.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if xJpw3ZzlvrY9KS:
				S5orefWm8D4k6bw1Ops = 'POST'
				for RAVgaEbSx8NZkzrewHJXhK6lC7,name,value in xJpw3ZzlvrY9KS:
					if 'wpost' in name: HXbcgWp1CQ3ZkuxYiV5GTj,IksCuE7tGq1Q9w,F4Pz0lfUZ6thdpH = RAVgaEbSx8NZkzrewHJXhK6lC7,name,value
					elif 'dpost' in name: auiznBWPYG6dgsqb5RySXxh4Ct,Ph1bWOtz4LYmGCuVfxBqXlR,NgR4W6cEq7hzKDH518TUSIPmo = RAVgaEbSx8NZkzrewHJXhK6lC7,name,value
				OCYzBlsvIDXenVZ4JF9UgQ7fTqS = IksCuE7tGq1Q9w+'='+F4Pz0lfUZ6thdpH
				v6zFkR5hwJmrS80OaTbtyjZWe7l1s = Ph1bWOtz4LYmGCuVfxBqXlR+'='+NgR4W6cEq7hzKDH518TUSIPmo
		else:
			xJpw3ZzlvrY9KS = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if xJpw3ZzlvrY9KS:
				S5orefWm8D4k6bw1Ops = 'GET'
				for SOw5EUxC9k in xJpw3ZzlvrY9KS:
					if 'wpost' in SOw5EUxC9k: HXbcgWp1CQ3ZkuxYiV5GTj = SOw5EUxC9k
					elif 'dpost' in SOw5EUxC9k: auiznBWPYG6dgsqb5RySXxh4Ct = SOw5EUxC9k
				OCYzBlsvIDXenVZ4JF9UgQ7fTqS = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				v6zFkR5hwJmrS80OaTbtyjZWe7l1s = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if HXbcgWp1CQ3ZkuxYiV5GTj:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,S5orefWm8D4k6bw1Ops,HXbcgWp1CQ3ZkuxYiV5GTj,OCYzBlsvIDXenVZ4JF9UgQ7fTqS,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="WatcherArea(.*?</ul>)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			m0nQzuids9NMHrbLkU3lJAVxFwg = cKUQVwTMe9tZSY[0]
			m0nQzuids9NMHrbLkU3lJAVxFwg = m0nQzuids9NMHrbLkU3lJAVxFwg.replace('</ul>','<h3>')
			m0nQzuids9NMHrbLkU3lJAVxFwg = m0nQzuids9NMHrbLkU3lJAVxFwg.replace('<h3>','<h3><h3>')
			UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('<h3>.*?(\d+)(.*?)<h3>',m0nQzuids9NMHrbLkU3lJAVxFwg,p7dwlH1PRStBgyMUW.DOTALL)
			if not UOqp25uxcISGBPlAfbtzCNWXY4nvK: UOqp25uxcISGBPlAfbtzCNWXY4nvK = [(WnNGfosHr5STAq8j7miwyRZ6eOUbV,m0nQzuids9NMHrbLkU3lJAVxFwg)]
			for DIBw28Qfje76bTMzVNYhxrgWmO,KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
				if DIBw28Qfje76bTMzVNYhxrgWmO: DIBw28Qfje76bTMzVNYhxrgWmO = '____'+DIBw28Qfje76bTMzVNYhxrgWmO
				items = p7dwlH1PRStBgyMUW.findall('data-link="(.*?)".*?<span>(.*?)</span>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for SOw5EUxC9k,name in items:
					if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
					SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__watch'+DIBw28Qfje76bTMzVNYhxrgWmO
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if laAHpo1bzyM0q:
			SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO = laAHpo1bzyM0q[0]
			name = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
			if '%' in DIBw28Qfje76bTMzVNYhxrgWmO: SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__embed__'
			else: SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__embed____'+DIBw28Qfje76bTMzVNYhxrgWmO
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if auiznBWPYG6dgsqb5RySXxh4Ct:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,S5orefWm8D4k6bw1Ops,auiznBWPYG6dgsqb5RySXxh4Ct,v6zFkR5hwJmrS80OaTbtyjZWe7l1s,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-PLAY-3rd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="DownloadArea(.*?)<script src=',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			m0nQzuids9NMHrbLkU3lJAVxFwg = cKUQVwTMe9tZSY[0]
			UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('class="DownloadServers(.*?)</ul>',m0nQzuids9NMHrbLkU3lJAVxFwg,p7dwlH1PRStBgyMUW.DOTALL)
			for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
				items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for SOw5EUxC9k,title,DIBw28Qfje76bTMzVNYhxrgWmO in items:
					if not SOw5EUxC9k: continue
					if 'reviewstation' in SOw5EUxC9k: continue
					SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k)
					SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download____'+DIBw28Qfje76bTMzVNYhxrgWmO
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	x2we5y6Lgm1C = str(M0MFkiKqJDv1aZ4NA396u)
	LZr6GwdxhyNIsJqb5R = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in x2we5y6Lgm1C for value in LZr6GwdxhyNIsJqb5R):
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if not search: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/find/?word='+search+'&type='
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='CATEGORIES':
		if dX79OeJYIP4phu[0]+'==' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = dX79OeJYIP4phu[0]
		for JrM1DoSuQ5n8 in range(len(dX79OeJYIP4phu[0:-1])):
			if dX79OeJYIP4phu[JrM1DoSuQ5n8]+'==' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = dX79OeJYIP4phu[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&&'+eukVjoW67vBiySNXrplDKIZLHU+'==0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&&'+eukVjoW67vBiySNXrplDKIZLHU+'==0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&&')+'___'+A5AHnwB1MJQ4O.strip('&&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'//getposts??'+CdZwuO45sE7UvlbM
	elif type=='FILTERS':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'//getposts??'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		Ak4FHQP7vfhd6bYU = ajw9qKvLQVO04TzBGmsUr(vcQbFfCk6T1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',Ak4FHQP7vfhd6bYU,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',Ak4FHQP7vfhd6bYU,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'POST',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABSEED-FILTERS_MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	eGSPjpBxQnT0dqAH9vMN4wcgRmL5hy = p7dwlH1PRStBgyMUW.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	VFdn2H9xZ8Ce = p7dwlH1PRStBgyMUW.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	ZudC8bDqo4mM5c7GfP96Qy2F = eGSPjpBxQnT0dqAH9vMN4wcgRmL5hy+VFdn2H9xZ8Ce
	dict = {}
	for name,LgJITEZU95fS2oi8K,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		items = p7dwlH1PRStBgyMUW.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('data-rate="(.*?)".*?<em>(.*?)</em>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			items = []
			for f4qbArVHeaCIiY5nzUR68dFBjsZ9,value in YacIZtAGdEPsFhSe: items.append([f4qbArVHeaCIiY5nzUR68dFBjsZ9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,value])
			LgJITEZU95fS2oi8K = 'rate'
			name = 'التقييم'
		else: LgJITEZU95fS2oi8K = items[0][1]
		if '==' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='CATEGORIES':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<=1:
				if LgJITEZU95fS2oi8K==dX79OeJYIP4phu[-1]: ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'CATEGORIES___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				Ak4FHQP7vfhd6bYU = ajw9qKvLQVO04TzBGmsUr(vcQbFfCk6T1)
				if LgJITEZU95fS2oi8K==dX79OeJYIP4phu[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',Ak4FHQP7vfhd6bYU,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',vcQbFfCk6T1,254,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='FILTERS':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&&'+LgJITEZU95fS2oi8K+'==0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&&'+LgJITEZU95fS2oi8K+'==0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع :'+name,vcQbFfCk6T1,255,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for f4qbArVHeaCIiY5nzUR68dFBjsZ9,PN2AmVoTyks5xOR1Ib9BqSQ,value in items:
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if 'الكل' in f4qbArVHeaCIiY5nzUR68dFBjsZ9: continue
			f4qbArVHeaCIiY5nzUR68dFBjsZ9 = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(f4qbArVHeaCIiY5nzUR68dFBjsZ9)
			DnBsO9opYvF7wmy8NEtCZVq5Slc6k,gPvxJw89S35R21zDIbpFYkq7A = f4qbArVHeaCIiY5nzUR68dFBjsZ9,f4qbArVHeaCIiY5nzUR68dFBjsZ9
			gPvxJw89S35R21zDIbpFYkq7A = name+': '+DnBsO9opYvF7wmy8NEtCZVq5Slc6k
			dict[LgJITEZU95fS2oi8K][value] = gPvxJw89S35R21zDIbpFYkq7A
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&&'+LgJITEZU95fS2oi8K+'=='+DnBsO9opYvF7wmy8NEtCZVq5Slc6k
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&&'+LgJITEZU95fS2oi8K+'=='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			if type=='FILTERS':
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,url,255,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='CATEGORIES' and dX79OeJYIP4phu[-2]+'==' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'modified_filters')
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'//getposts??'+CdZwuO45sE7UvlbM
				Ak4FHQP7vfhd6bYU = ajw9qKvLQVO04TzBGmsUr(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,Ak4FHQP7vfhd6bYU,251,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,url,254,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
dX79OeJYIP4phu = ['category','country','release-year']
HHJVSpu5najfWEYdkb2sT = ['category','country','genre','release-year','language','quality','rate']
def ajw9qKvLQVO04TzBGmsUr(url):
	kKIjiGH8wWtnR4N3qbvU6 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',kKIjiGH8wWtnR4N3qbvU6)
	url = url.replace('/category/اخرى',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if kKIjiGH8wWtnR4N3qbvU6 not in url: url = url+kKIjiGH8wWtnR4N3qbvU6
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4,CZewXSEQ3q = {},WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if '==' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('==')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	for key in HHJVSpu5najfWEYdkb2sT:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&&'+key+'=='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&&'+key+'=='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&&')
	return CZewXSEQ3q