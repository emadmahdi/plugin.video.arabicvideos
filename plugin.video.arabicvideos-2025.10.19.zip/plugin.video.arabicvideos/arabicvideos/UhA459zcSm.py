# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'CIMANOW'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_CMN_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['قائمتي']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==300: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==301: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==302: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==303: APpdhB1Fk58MmJH7CjVntowyaY = PPAxlvst3JmBy(url)
	elif mode==304: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==305: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==306: APpdhB1Fk58MmJH7CjVntowyaY = chIvjnxOm8MEiLgQD()
	elif mode==309: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,309,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/home',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<header(.*?)</header>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('<li><a href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if not any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,301)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	uJlhLk2Tbcd(pcE6DxaoHBm41WKXjwnk+'/home',piN9Qlah4S)
	return piN9Qlah4S
def chIvjnxOm8MEiLgQD():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def uJlhLk2Tbcd(url,piN9Qlah4S=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not piN9Qlah4S:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-SUBMENU-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	L3LoVh5B7OZMbHJlPXQ6EjnaUks = 0
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<section>.*?</section>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
		L3LoVh5B7OZMbHJlPXQ6EjnaUks += 1
		items = p7dwlH1PRStBgyMUW.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for title,lKZNU2Mti1PxY9IcmWz8bVDALoshE,SOw5EUxC9k in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if title==WnNGfosHr5STAq8j7miwyRZ6eOUbV: title = 'بووووو'
			if 'em><a' not in lKZNU2Mti1PxY9IcmWz8bVDALoshE:
				if KDCdHQmgxPE21tYz4VUowSv.count('/category/')>0:
					CwnFdurTY67y2L80A3KSGb = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
					for SOw5EUxC9k in CwnFdurTY67y2L80A3KSGb:
						title = SOw5EUxC9k.split('/')[-2]
						octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,301)
					continue
				else: SOw5EUxC9k = url+'?sequence='+str(L3LoVh5B7OZMbHJlPXQ6EjnaUks)
			if not any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027):
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,302)
	if not cKUQVwTMe9tZSY: ctDj2OVRyaUPXCrITmJG(url,piN9Qlah4S)
	return
def ctDj2OVRyaUPXCrITmJG(url,piN9Qlah4S=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if piN9Qlah4S==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-TITLES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if '?sequence=' in url:
		url,L3LoVh5B7OZMbHJlPXQ6EjnaUks = url.split('?sequence=')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(<section>.*?</section>)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[int(L3LoVh5B7OZMbHJlPXQ6EjnaUks)-1]
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"posts"(.*?)</body>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for SOw5EUxC9k,data,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		title = p7dwlH1PRStBgyMUW.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,p7dwlH1PRStBgyMUW.DOTALL)
		if title: title = title[0][2].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		if not title or title==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			title = p7dwlH1PRStBgyMUW.findall('title">.*?</em>(.*?)<',data,p7dwlH1PRStBgyMUW.DOTALL)
			if title: title = title[0].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			if not title or title==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
				title = p7dwlH1PRStBgyMUW.findall('title">(.*?)<',data,p7dwlH1PRStBgyMUW.DOTALL)
				title = title[0].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		title = title.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
			cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			s5ocIDd4WKuPrV = SOw5EUxC9k+data+J4tO21KYAVdSr67W5NmiD0XhRP
			if '/selary/' in s5ocIDd4WKuPrV or 'مسلسل' in s5ocIDd4WKuPrV or '"episode"' in s5ocIDd4WKuPrV:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,303,J4tO21KYAVdSr67W5NmiD0XhRP)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,305,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('<li><a href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,302)
	return
def PPAxlvst3JmBy(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-SEASONS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	name = p7dwlH1PRStBgyMUW.findall('<title>(.*?)</title>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('Cima Now',WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		name = name.split('الحلقة')[0].strip(kcXMWrwiLDKeBHRsJ)+' - '
	else: name = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<section(.*?)</section>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if len(items)>1:
			for SOw5EUxC9k,title in items:
				title = name+title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,304)
		elif len(items)==1:
			SOw5EUxC9k,title = items[0]
			d4TS7lOXiRVe0s3tg5JwIoz2Mh(SOw5EUxC9k)
		else: d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if '/selary/' not in url:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"episodes"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			title = 'الحلقة '+title
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,305)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"details"(.*?)"related"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,305,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ff4yLTv2eGCNYbpaUsqAordi81uO = p7dwlH1PRStBgyMUW.findall('class="shine" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ff4yLTv2eGCNYbpaUsqAordi81uO:
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(ff4yLTv2eGCNYbpaUsqAordi81uO[0],'url')
		headers = {'Referer':VVpQfHc7IZamxweON3WXKU6Fg}
	else: headers = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	vcQbFfCk6T1 = url+'watching/'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMANOW-PLAY-5th')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	M0MFkiKqJDv1aZ4NA396u = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"download"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			DIBw28Qfje76bTMzVNYhxrgWmO = p7dwlH1PRStBgyMUW.findall('\d\d\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if DIBw28Qfje76bTMzVNYhxrgWmO:
				DIBw28Qfje76bTMzVNYhxrgWmO = '____'+DIBw28Qfje76bTMzVNYhxrgWmO[0]
				title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
			else: DIBw28Qfje76bTMzVNYhxrgWmO = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = SOw5EUxC9k+'?named='+title+'__download'+DIBw28Qfje76bTMzVNYhxrgWmO
			M0MFkiKqJDv1aZ4NA396u.append(ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"watch"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('"embed".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k in laAHpo1bzyM0q:
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
			title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__embed'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
		laAHpo1bzyM0q = [pcE6DxaoHBm41WKXjwnk+'/wp-content/themes/Cima%20Now%20New/core.php']
		if laAHpo1bzyM0q:
			items = p7dwlH1PRStBgyMUW.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for veLqt1DZI6N8a,id,title in items:
				title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				SOw5EUxC9k = laAHpo1bzyM0q[0]+'?action=switch&index='+veLqt1DZI6N8a+'&id='+id+'?named='+title+'__watch'
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk + '/?s='+search
	ctDj2OVRyaUPXCrITmJG(url)
	return