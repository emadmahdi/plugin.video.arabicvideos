# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'VARBON'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_VRB_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الرئيسية','يلا شوت']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==870: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==871: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==872: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==873: APpdhB1Fk58MmJH7CjVntowyaY = MMHA2zYU1bIRBcZO(url)
	elif mode==879: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VARBON-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,879,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"primary-links"(.*?)</u',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,871)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"list-categories"(.*?)</div',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k.lstrip('/')
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,871)
	return
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VARBON-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"home-content"(.*?)"footer"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('"overlay"','"duration"><')
		items = p7dwlH1PRStBgyMUW.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
		for J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z,SOw5EUxC9k,title in items:
			title = title.strip(' ')
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if 'episodes' not in type and er96jwp52cbvaV48mtylEYSRz:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
				title = title.replace('اون لاين',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,873,J4tO21KYAVdSr67W5NmiD0XhRP)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,872,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''["']pagination["'](.*?)["']footer["']''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,871,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
	return
def MMHA2zYU1bIRBcZO(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VARBON-SERIES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="eplist"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		cTmHXhoJ60 = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in cTmHXhoJ60:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,872)
	else:
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('"category".*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if SOw5EUxC9k:
			SOw5EUxC9k = ZisgmEGCOJxVI9DcetNBPo6(SOw5EUxC9k[0])
			ctDj2OVRyaUPXCrITmJG(SOw5EUxC9k,'episodes')
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALMSTBA-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if 'hash=' in piN9Qlah4S:
		F7Yg3LliEBGZ6rVyozbS = p7dwlH1PRStBgyMUW.findall('hash=(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		F7Yg3LliEBGZ6rVyozbS = list(set(F7Yg3LliEBGZ6rVyozbS))
		for dHqBsvSieRxmbAPXVJ0o in F7Yg3LliEBGZ6rVyozbS:
			ffBUscdIljgLyknWCwSDOhq = []
			ipdI4Kw1lMauxrtYoh = dHqBsvSieRxmbAPXVJ0o.split('__')
			for iZrspzKymR7cBSxUV6XJtn in ipdI4Kw1lMauxrtYoh:
				try:
					iZrspzKymR7cBSxUV6XJtn = uvGCPpFwVmTQ36.b64decode(iZrspzKymR7cBSxUV6XJtn+'=')
					if rJ2oTLqabRtA: iZrspzKymR7cBSxUV6XJtn = iZrspzKymR7cBSxUV6XJtn.decode(e87cIA5vwOQLDEP1)
					ffBUscdIljgLyknWCwSDOhq.append(iZrspzKymR7cBSxUV6XJtn)
				except: pass
			laAHpo1bzyM0q = '>'.join(ffBUscdIljgLyknWCwSDOhq)
			laAHpo1bzyM0q = laAHpo1bzyM0q.splitlines()
			for SOw5EUxC9k in laAHpo1bzyM0q:
				if ' => ' in SOw5EUxC9k:
					title,SOw5EUxC9k = SOw5EUxC9k.split(' => ')
					SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
					wxT9bCdumN.append(SOw5EUxC9k)
	elif 'post_id' in piN9Qlah4S:
		YQU9rmMqC0LWkcxaFpZos7VdRg = p7dwlH1PRStBgyMUW.findall("post_id = '(.*?)'",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if YQU9rmMqC0LWkcxaFpZos7VdRg:
			YQU9rmMqC0LWkcxaFpZos7VdRg = YQU9rmMqC0LWkcxaFpZos7VdRg[0]
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/wp-admin/admin-ajax.php?action=video_info&post_id='+YQU9rmMqC0LWkcxaFpZos7VdRg
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALMSTBA-PLAY-2nd')
			piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
			laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('"name":"(.*?)","src":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if not laAHpo1bzyM0q: laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('"(src)":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			for name,SOw5EUxC9k in laAHpo1bzyM0q:
				SOw5EUxC9k = SOw5EUxC9k.replace('\\/','/')
				SOw5EUxC9k = ZisgmEGCOJxVI9DcetNBPo6(SOw5EUxC9k)
				if name=='src': name = ''
				wxT9bCdumN.append(SOw5EUxC9k+'?named='+name+'__watch')
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return