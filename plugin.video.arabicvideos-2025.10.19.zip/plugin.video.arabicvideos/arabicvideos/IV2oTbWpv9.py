# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'GLOBALSEARCH'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_GLS_'
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j,TB3DI4JWr0NYmik1xO8Kc2):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==540: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==541: APpdhB1Fk58MmJH7CjVntowyaY = gLCqF8UTGmDABRW(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==542: APpdhB1Fk58MmJH7CjVntowyaY = rIXAgwunRT3sQkjqfFcNop6z(ZVk6IphECKLzUceP15j,uuSU5Awl8FNrzkXHdQDiCWq3,TB3DI4JWr0NYmik1xO8Kc2)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==543: APpdhB1Fk58MmJH7CjVntowyaY = FBZsxGOhyX()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==548: APpdhB1Fk58MmJH7CjVntowyaY = ulCjLUWvtG0hw(uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==549: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(ZVk6IphECKLzUceP15j)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','بحث جديد لجميع المواقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,549)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link','كيف يعمل بحث جميع المواقع','',543)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'==== كلمات البحث المخزنة ===='+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	EVnDz2PKOwWkGo = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if EVnDz2PKOwWkGo:
		EVnDz2PKOwWkGo = EVnDz2PKOwWkGo['__SEQUENCED_COLUMNS__']
		for lU2oX9uKy8AGw60I4vzV7e in reversed(EVnDz2PKOwWkGo):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',lU2oX9uKy8AGw60I4vzV7e,WnNGfosHr5STAq8j7miwyRZ6eOUbV,549,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lU2oX9uKy8AGw60I4vzV7e)
	return
def WmxfGFqceOyUtLT(lU2oX9uKy8AGw60I4vzV7e):
	if not lU2oX9uKy8AGw60I4vzV7e:
		lU2oX9uKy8AGw60I4vzV7e = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not lU2oX9uKy8AGw60I4vzV7e: return
		lU2oX9uKy8AGw60I4vzV7e = lU2oX9uKy8AGw60I4vzV7e.lower()
	X8MZ2ylw71DxTsB4iqr3tg6 = lU2oX9uKy8AGw60I4vzV7e.replace(uBQ9txp0gDrEhZTcJOi74SKVw3k,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	zOFUERr2e4jWT3K7oqk6(X8MZ2ylw71DxTsB4iqr3tg6,'_ALL',True)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link','بحث جماعي للمواقع - '+X8MZ2ylw71DxTsB4iqr3tg6,'search_sites_all',542,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','بحث منفرد للمواقع - '+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,541,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','نتائج البحث مفصلة - '+X8MZ2ylw71DxTsB4iqr3tg6,'opened_sites_all',542,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','نتائج البحث مقسمة - '+X8MZ2ylw71DxTsB4iqr3tg6,'listed_sites_all',542,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	return
def zOFUERr2e4jWT3K7oqk6(PJtiuSme9sazlOUTVACRxWM1D,AcEiU1VYau9DmWe,ucnJlaYDrZTXpdBkiEFPy):
	if AcEiU1VYau9DmWe=='_ALL': fxJRMDCYik0K9jP8BVryAhE6 = '_GLS_'
	elif AcEiU1VYau9DmWe=='_GOOGLE': fxJRMDCYik0K9jP8BVryAhE6 = '_GOS_'
	l4JFvH0ZLE3V = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,PJtiuSme9sazlOUTVACRxWM1D)
	l2yx0Rb8BYmUSKjzqXwnQTpPtcCJu = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,fxJRMDCYik0K9jP8BVryAhE6+PJtiuSme9sazlOUTVACRxWM1D)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,PJtiuSme9sazlOUTVACRxWM1D)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,fxJRMDCYik0K9jP8BVryAhE6+PJtiuSme9sazlOUTVACRxWM1D)
	E7yzoBRbevmtwai8FGNH1LIfx6 = l4JFvH0ZLE3V+l2yx0Rb8BYmUSKjzqXwnQTpPtcCJu
	if E7yzoBRbevmtwai8FGNH1LIfx6 and ucnJlaYDrZTXpdBkiEFPy: PJtiuSme9sazlOUTVACRxWM1D = fxJRMDCYik0K9jP8BVryAhE6+PJtiuSme9sazlOUTVACRxWM1D
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,PJtiuSme9sazlOUTVACRxWM1D,E7yzoBRbevmtwai8FGNH1LIfx6,T0le9tWJd7IAfKH1rNGB)
	return
def fTBub10xG2M7W5qF8HtQov(AcEiU1VYau9DmWe):
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if kkLdeyJUsSiK9YwFZr4lPbVE!=1: return
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DETAILED'+AcEiU1VYau9DmWe)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DIVIDED'+AcEiU1VYau9DmWe)
	if AcEiU1VYau9DmWe=='_GOOGLE': sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GOOGLESEARCH_RESULTS')
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def rIXAgwunRT3sQkjqfFcNop6z(TxLm1ONw0qvKb2fcCZMuJIlo,RhFBXIsqQuGi1k95etngUwxlWNZ,ldVje6AwxCuN35sq10TOWahYz=WnNGfosHr5STAq8j7miwyRZ6eOUbV,eZwcs1Cop9q=FFonu8kDwYm2vHdAgfjS7zyMb5q,BrpoahTVNXnv4iulgsxFSD={}):
	iITpxG0Jkdu53a,NE6rP41F9n,bQPqp3C0Ji8AVdh4fuZ6,BWHTuyLfCYU,DXGtBIH8sVlzx6CrENfc7P3uT5Ov = [],{},{},{},{}
	if '_all' in RhFBXIsqQuGi1k95etngUwxlWNZ: AcEiU1VYau9DmWe,qPMYyhbEXuoJNUl3gfLHV0I,fxJRMDCYik0K9jP8BVryAhE6 = '_ALL','_all','_GLS_'
	elif '_google' in RhFBXIsqQuGi1k95etngUwxlWNZ: AcEiU1VYau9DmWe,qPMYyhbEXuoJNUl3gfLHV0I,fxJRMDCYik0K9jP8BVryAhE6 = '_GOOGLE','_google','_GOS_'
	if RhFBXIsqQuGi1k95etngUwxlWNZ in ['listed_sites'+qPMYyhbEXuoJNUl3gfLHV0I,'opened_sites'+qPMYyhbEXuoJNUl3gfLHV0I,'closed_sites'+qPMYyhbEXuoJNUl3gfLHV0I]:
		if RhFBXIsqQuGi1k95etngUwxlWNZ=='listed_sites'+qPMYyhbEXuoJNUl3gfLHV0I: iITpxG0Jkdu53a = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,fxJRMDCYik0K9jP8BVryAhE6+TxLm1ONw0qvKb2fcCZMuJIlo)
		elif RhFBXIsqQuGi1k95etngUwxlWNZ=='opened_sites'+qPMYyhbEXuoJNUl3gfLHV0I: iITpxG0Jkdu53a = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_DETAILED'+AcEiU1VYau9DmWe,TxLm1ONw0qvKb2fcCZMuJIlo)
		elif RhFBXIsqQuGi1k95etngUwxlWNZ=='closed_sites'+qPMYyhbEXuoJNUl3gfLHV0I: iITpxG0Jkdu53a = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_DIVIDED'+AcEiU1VYau9DmWe,(ldVje6AwxCuN35sq10TOWahYz,TxLm1ONw0qvKb2fcCZMuJIlo))
	if not iITpxG0Jkdu53a:
		hJaCboEre4Tc6AW8Uz = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		gEbImLX6aAO28D3Pxo5ehjnvu = 'هل تريد الآن البحث في جميع المواقع عن \n "'+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+kcXMWrwiLDKeBHRsJ+TxLm1ONw0qvKb2fcCZMuJIlo+kcXMWrwiLDKeBHRsJ+YVr6St5P4xsFC0aARQGKfiegD+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if RhFBXIsqQuGi1k95etngUwxlWNZ=='search_sites'+qPMYyhbEXuoJNUl3gfLHV0I: eJU6bsndE1mI0F = gEbImLX6aAO28D3Pxo5ehjnvu
		else: eJU6bsndE1mI0F = hJaCboEre4Tc6AW8Uz+gEbImLX6aAO28D3Pxo5ehjnvu
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=1: return
		OO7gEdhG2U3x6ucLvKoVJyfPRNrk(z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd)
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+'   Search For: [ '+TxLm1ONw0qvKb2fcCZMuJIlo+' ]')
		RJQw9x3EcngZjDPzadOf0FABb = 1
		for OOG1iPYhTKQ4 in eZwcs1Cop9q:
			oGvB7U9wbfAz4mFZ0r5XOeQMV = BrpoahTVNXnv4iulgsxFSD[OOG1iPYhTKQ4] if BrpoahTVNXnv4iulgsxFSD else TxLm1ONw0qvKb2fcCZMuJIlo
			try: PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
			except: continue
			NE6rP41F9n[OOG1iPYhTKQ4] = []
			aksIy7wNYp2W = '_NODIALOGS_'
			if '-' in OOG1iPYhTKQ4: aksIy7wNYp2W = aksIy7wNYp2W+'_REMEMBERRESULTS__'+OOG1iPYhTKQ4+'_'
			if RJQw9x3EcngZjDPzadOf0FABb:
				x54xSdnCFHZ8yliofzOBK.sleep(0.75)
				DXGtBIH8sVlzx6CrENfc7P3uT5Ov[OOG1iPYhTKQ4] = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=uTes0AS7pNHjbkawzy5mqLx4XP,args=(oGvB7U9wbfAz4mFZ0r5XOeQMV+aksIy7wNYp2W,))
				DXGtBIH8sVlzx6CrENfc7P3uT5Ov[OOG1iPYhTKQ4].start()
			else: uTes0AS7pNHjbkawzy5mqLx4XP(oGvB7U9wbfAz4mFZ0r5XOeQMV+aksIy7wNYp2W)
			uTaiRMI8eYmN(v2oRq5AhQzcx(OOG1iPYhTKQ4),WnNGfosHr5STAq8j7miwyRZ6eOUbV,x54xSdnCFHZ8yliofzOBK=1000)
		if RJQw9x3EcngZjDPzadOf0FABb:
			x54xSdnCFHZ8yliofzOBK.sleep(2)
			for OOG1iPYhTKQ4 in eZwcs1Cop9q: DXGtBIH8sVlzx6CrENfc7P3uT5Ov[OOG1iPYhTKQ4].join(10)
			x54xSdnCFHZ8yliofzOBK.sleep(2)
		for OOG1iPYhTKQ4 in eZwcs1Cop9q:
			try: PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
			except: continue
			for TQIX0VjldCJZ2BxrR8c in A3pXVFdyP1.menuItemsLIST:
				t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = TQIX0VjldCJZ2BxrR8c
				if qr61ZvHTdEjIShcBis in fzu7Got0FgiyshTlJK:
					if 'IPTV-' in OOG1iPYhTKQ4 and (239>=HOkAWvmZSP5c2t9Dq4NgELyps>=230 or 289>=HOkAWvmZSP5c2t9Dq4NgELyps>=280):
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['IPTV-LIVE']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['IPTV-MOVIES']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['IPTV-SERIES']: continue
						if 'صفحة' not in fzu7Got0FgiyshTlJK:
							if   t0xkM74rgEAFIepSWXilNOGDn=='live': OOG1iPYhTKQ4 = 'IPTV-LIVE'
							elif t0xkM74rgEAFIepSWXilNOGDn=='video': OOG1iPYhTKQ4 = 'IPTV-MOVIES'
							elif t0xkM74rgEAFIepSWXilNOGDn=='folder': OOG1iPYhTKQ4 = 'IPTV-SERIES'
						else:
							if   'LIVE' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'IPTV-LIVE'
							elif 'MOVIES' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'IPTV-MOVIES'
							elif 'SERIES' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'IPTV-SERIES'
					elif 'M3U-' in OOG1iPYhTKQ4 and 729>=HOkAWvmZSP5c2t9Dq4NgELyps>=710:
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['M3U-LIVE']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['M3U-MOVIES']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['M3U-SERIES']: continue
						if 'صفحة' not in fzu7Got0FgiyshTlJK:
							if   t0xkM74rgEAFIepSWXilNOGDn=='live': OOG1iPYhTKQ4 = 'M3U-LIVE'
							elif t0xkM74rgEAFIepSWXilNOGDn=='video': OOG1iPYhTKQ4 = 'M3U-MOVIES'
							elif t0xkM74rgEAFIepSWXilNOGDn=='folder': OOG1iPYhTKQ4 = 'M3U-SERIES'
						else:
							if   'LIVE' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'M3U-LIVE'
							elif 'MOVIES' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'M3U-MOVIES'
							elif 'SERIES' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'M3U-SERIES'
					elif 'YOUTUBE-' in OOG1iPYhTKQ4 and 149>=HOkAWvmZSP5c2t9Dq4NgELyps>=140:
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['YOUTUBE-CHANNELS']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['YOUTUBE-PLAYLISTS']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in fzu7Got0FgiyshTlJK or ':: ' in fzu7Got0FgiyshTlJK:
							continue
						else:
							if   HOkAWvmZSP5c2t9Dq4NgELyps==144 and 'USER' in fzu7Got0FgiyshTlJK: OOG1iPYhTKQ4 = 'YOUTUBE-CHANNELS'
							elif HOkAWvmZSP5c2t9Dq4NgELyps==144 and 'CHNL' in fzu7Got0FgiyshTlJK: OOG1iPYhTKQ4 = 'YOUTUBE-CHANNELS'
							elif HOkAWvmZSP5c2t9Dq4NgELyps==144 and 'LIST' in fzu7Got0FgiyshTlJK: OOG1iPYhTKQ4 = 'YOUTUBE-PLAYLISTS'
							elif HOkAWvmZSP5c2t9Dq4NgELyps==143: OOG1iPYhTKQ4 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in OOG1iPYhTKQ4 and 419>=HOkAWvmZSP5c2t9Dq4NgELyps>=400:
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['DAILYMOTION-PLAYLISTS']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['DAILYMOTION-CHANNELS']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['DAILYMOTION-VIDEOS']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['DAILYMOTION-LIVES']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['DAILYMOTION-HASHTAGS']: continue
						if   HOkAWvmZSP5c2t9Dq4NgELyps in [401,405]: OOG1iPYhTKQ4 = 'DAILYMOTION-PLAYLISTS'
						elif HOkAWvmZSP5c2t9Dq4NgELyps in [402,406]: OOG1iPYhTKQ4 = 'DAILYMOTION-CHANNELS'
						elif HOkAWvmZSP5c2t9Dq4NgELyps in [404]: OOG1iPYhTKQ4 = 'DAILYMOTION-VIDEOS'
						elif HOkAWvmZSP5c2t9Dq4NgELyps in [415]: OOG1iPYhTKQ4 = 'DAILYMOTION-LIVES'
						elif HOkAWvmZSP5c2t9Dq4NgELyps in [416]: OOG1iPYhTKQ4 = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in OOG1iPYhTKQ4 and 39>=HOkAWvmZSP5c2t9Dq4NgELyps>=30:
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['PANET-SERIES']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['PANET-MOVIES']: continue
						if   HOkAWvmZSP5c2t9Dq4NgELyps in [32,39]: OOG1iPYhTKQ4 = 'PANET-SERIES'
						elif HOkAWvmZSP5c2t9Dq4NgELyps in [33,39]: OOG1iPYhTKQ4 = 'PANET-MOVIES'
					elif 'IFILM-' in OOG1iPYhTKQ4 and 29>=HOkAWvmZSP5c2t9Dq4NgELyps>=20:
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['IFILM-ARABIC']: continue
						if TQIX0VjldCJZ2BxrR8c in NE6rP41F9n['IFILM-ENGLISH']: continue
						if   '/ar.' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'IFILM-ARABIC'
						elif '/en.' in uuSU5Awl8FNrzkXHdQDiCWq3: OOG1iPYhTKQ4 = 'IFILM-ENGLISH'
					NE6rP41F9n[OOG1iPYhTKQ4].append(TQIX0VjldCJZ2BxrR8c)
		for OOG1iPYhTKQ4 in list(NE6rP41F9n.keys()):
			bQPqp3C0Ji8AVdh4fuZ6[OOG1iPYhTKQ4] = []
			BWHTuyLfCYU[OOG1iPYhTKQ4] = []
			for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in NE6rP41F9n[OOG1iPYhTKQ4]:
				TQIX0VjldCJZ2BxrR8c = (t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
				if 'صفحة' in fzu7Got0FgiyshTlJK and t0xkM74rgEAFIepSWXilNOGDn=='folder': BWHTuyLfCYU[OOG1iPYhTKQ4].append(TQIX0VjldCJZ2BxrR8c)
				else: bQPqp3C0Ji8AVdh4fuZ6[OOG1iPYhTKQ4].append(TQIX0VjldCJZ2BxrR8c)
		cAVH5hLz7fyoT3qdrFP,ZQjMth86wblEa14gmSqJy = [],[]
		GoYAvNrxwJMTy = list(bQPqp3C0Ji8AVdh4fuZ6.keys())
		VJsfON9jQRL4uXD8z2tw3TKyZY = JFQSI5HUeNn7TOCsdzwPbpMrlx6Riu(GoYAvNrxwJMTy)
		qe6JTSdxVfXF59mzEUMpcC3lgju = []
		for OOG1iPYhTKQ4 in VJsfON9jQRL4uXD8z2tw3TKyZY:
			if isinstance(OOG1iPYhTKQ4,tuple):
				qe6JTSdxVfXF59mzEUMpcC3lgju = [OOG1iPYhTKQ4]
				continue
			if OOG1iPYhTKQ4 not in eZwcs1Cop9q: continue
			if bQPqp3C0Ji8AVdh4fuZ6[OOG1iPYhTKQ4]:
				voQCbrOyUxh3lHdjaGigZV5TEJ = v2oRq5AhQzcx(OOG1iPYhTKQ4)
				W9csFgKXiEe = [('link',RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'===== '+voQCbrOyUxh3lHdjaGigZV5TEJ+' ====='+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)]
				if 0: vZHc2KB4z9Dxt = TxLm1ONw0qvKb2fcCZMuJIlo+' - '+'بحث'+kcXMWrwiLDKeBHRsJ+voQCbrOyUxh3lHdjaGigZV5TEJ
				else: vZHc2KB4z9Dxt = 'بحث'+kcXMWrwiLDKeBHRsJ+voQCbrOyUxh3lHdjaGigZV5TEJ+' - '+TxLm1ONw0qvKb2fcCZMuJIlo
				if len(bQPqp3C0Ji8AVdh4fuZ6[OOG1iPYhTKQ4])<8: OXsxjIpfuJR0V5v46dWr3MiGH = []
				else:
					GGosuqQTwNeyt5ClvjFMKH78zbX = e6HEdvUcaq8Gx+vZHc2KB4z9Dxt+YVr6St5P4xsFC0aARQGKfiegD
					OXsxjIpfuJR0V5v46dWr3MiGH = [('folder',fxJRMDCYik0K9jP8BVryAhE6+GGosuqQTwNeyt5ClvjFMKH78zbX,'closed_sites'+qPMYyhbEXuoJNUl3gfLHV0I,542,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OOG1iPYhTKQ4,TxLm1ONw0qvKb2fcCZMuJIlo,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)]
				s0PCOhDX2Gunfw7TbpK5l = bQPqp3C0Ji8AVdh4fuZ6[OOG1iPYhTKQ4]+BWHTuyLfCYU[OOG1iPYhTKQ4]
				KeMjlcypV9gkG = qe6JTSdxVfXF59mzEUMpcC3lgju+W9csFgKXiEe+s0PCOhDX2Gunfw7TbpK5l[:7]+OXsxjIpfuJR0V5v46dWr3MiGH
				cAVH5hLz7fyoT3qdrFP += KeMjlcypV9gkG
				gsGhFj5Tm2Wc = [('folder',fxJRMDCYik0K9jP8BVryAhE6+vZHc2KB4z9Dxt,'closed_sites'+qPMYyhbEXuoJNUl3gfLHV0I,542,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OOG1iPYhTKQ4,TxLm1ONw0qvKb2fcCZMuJIlo,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)]
				Hn3GYWgfDe = qe6JTSdxVfXF59mzEUMpcC3lgju+gsGhFj5Tm2Wc
				ZQjMth86wblEa14gmSqJy += Hn3GYWgfDe
				w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DIVIDED'+AcEiU1VYau9DmWe,(OOG1iPYhTKQ4,TxLm1ONw0qvKb2fcCZMuJIlo),s0PCOhDX2Gunfw7TbpK5l,T0le9tWJd7IAfKH1rNGB)
				qe6JTSdxVfXF59mzEUMpcC3lgju = []
		w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DETAILED'+AcEiU1VYau9DmWe,TxLm1ONw0qvKb2fcCZMuJIlo,cAVH5hLz7fyoT3qdrFP,T0le9tWJd7IAfKH1rNGB)
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,TxLm1ONw0qvKb2fcCZMuJIlo)
		w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_SPLITTED'+AcEiU1VYau9DmWe,fxJRMDCYik0K9jP8BVryAhE6+TxLm1ONw0qvKb2fcCZMuJIlo,ZQjMth86wblEa14gmSqJy,T0le9tWJd7IAfKH1rNGB)
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		iITpxG0Jkdu53a = ZQjMth86wblEa14gmSqJy if RhFBXIsqQuGi1k95etngUwxlWNZ=='listed_sites'+qPMYyhbEXuoJNUl3gfLHV0I and ZQjMth86wblEa14gmSqJy else cAVH5hLz7fyoT3qdrFP
	if RhFBXIsqQuGi1k95etngUwxlWNZ in ['listed_sites'+qPMYyhbEXuoJNUl3gfLHV0I,'opened_sites'+qPMYyhbEXuoJNUl3gfLHV0I,'closed_sites'+qPMYyhbEXuoJNUl3gfLHV0I]:
		for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in iITpxG0Jkdu53a:
			if RhFBXIsqQuGi1k95etngUwxlWNZ in ['listed_sites'+qPMYyhbEXuoJNUl3gfLHV0I,'opened_sites'+qPMYyhbEXuoJNUl3gfLHV0I] and 'صفحة' in fzu7Got0FgiyshTlJK and t0xkM74rgEAFIepSWXilNOGDn=='folder': continue
			octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83)
	return
def gLCqF8UTGmDABRW(search):
	VJsfON9jQRL4uXD8z2tw3TKyZY = JFQSI5HUeNn7TOCsdzwPbpMrlx6Riu(JphriA3aDH61YFCbXsBvTmdx)
	for OOG1iPYhTKQ4 in VJsfON9jQRL4uXD8z2tw3TKyZY:
		if '-' in OOG1iPYhTKQ4: continue
		if isinstance(OOG1iPYhTKQ4,tuple):
			A3pXVFdyP1.menuItemsLIST.append(OOG1iPYhTKQ4)
			continue
		PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
		name = v2oRq5AhQzcx(OOG1iPYhTKQ4)+' - '+search
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qr61ZvHTdEjIShcBis+name,OOG1iPYhTKQ4,548,'','',search)
	return
def ulCjLUWvtG0hw(OOG1iPYhTKQ4,search):
	PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
	uTes0AS7pNHjbkawzy5mqLx4XP(search)
	return
def FBZsxGOhyX():
	BGQXvd2lsicjVTgnHYRo74qDI3z('','',Ew26Hg4SIj,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def dgQPp8oM3jXJ6ehR(TxLm1ONw0qvKb2fcCZMuJIlo=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	lU2oX9uKy8AGw60I4vzV7e,aksIy7wNYp2W,showDialogs = XgnSRzMaerBT(TxLm1ONw0qvKb2fcCZMuJIlo)
	if not lU2oX9uKy8AGw60I4vzV7e:
		lU2oX9uKy8AGw60I4vzV7e = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not lU2oX9uKy8AGw60I4vzV7e: return
		lU2oX9uKy8AGw60I4vzV7e = lU2oX9uKy8AGw60I4vzV7e.lower()
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+'   Search For: [ '+lU2oX9uKy8AGw60I4vzV7e+' ]')
	DqbrOGw4giHUvfuFtRXQ5lA0yN = lU2oX9uKy8AGw60I4vzV7e+aksIy7wNYp2W
	if 0: NzIM84dwvVex3T1tWDAqchKa9pQyJL,X8MZ2ylw71DxTsB4iqr3tg6 = lU2oX9uKy8AGw60I4vzV7e+' - ',WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: NzIM84dwvVex3T1tWDAqchKa9pQyJL,X8MZ2ylw71DxTsB4iqr3tg6 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,' - '+lU2oX9uKy8AGw60I4vzV7e
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'مواقع سيرفرات خاصة - قليلة المشاكل'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,157)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_M3U_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث M3U'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,719,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_IPT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث IPTV'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,239,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_BKR_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع بكرا'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,379,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_ART_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع تونز عربية'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,739,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_KRB_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع قناة كربلاء'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,329,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FH2_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فاصل الثاني'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,599,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_KTV_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع كتكوت تيفي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,819,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_EB1_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع ايجي بيست 1'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,779,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_EB2_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع ايجي بيست 2'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,789,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_IFL_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'  بحث موقع قناة آي فيلم'+X8MZ2ylw71DxTsB4iqr3tg6+tTChquY7XSRg4e,WnNGfosHr5STAq8j7miwyRZ6eOUbV,29,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_AKO_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع أكوام القديم'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,79,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_AKW_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع أكوام الجديد'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,249,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_MRF_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع قناة المعارف'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,49,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SHM_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شوف ماكس'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,59,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,157)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_LRZ_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع لاروزا'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,709,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FJS_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+' بحث موقع فجر شو'+X8MZ2ylw71DxTsB4iqr3tg6+kcXMWrwiLDKeBHRsJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV,399,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TVF_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع تيفي فان'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,469,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_LDN_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع لودي نت'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,459,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CMN_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما ناو'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,309,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SHN_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شاهد نيوز'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,589,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN+'_NODIALOGS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_ARS_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع عرب سييد'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,259,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CCB_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما كلوب'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,829,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SH4_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شاهد فوريو'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,119,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN+'_NODIALOGS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SHT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شوفها تيفي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,649,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_WC1_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع وي سيما 1'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,569,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_WC2_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع وي سيما 2'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,1009,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'مواقع سيرفرات عامة - كثيرة المشاكل'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,157)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TKT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع تكات'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,949,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FST_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فوستا'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,609,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FBK_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فبركة'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,629,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_YQT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع ياقوت'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,669,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SHB_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شبكتي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,969,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_VRB_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فاربون'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,879,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_BRS_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع برستيج'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,659,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_KRM_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع كرمالك'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,929,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_ANZ_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع انمي زد'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,979,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FSK_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فارسكو'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,999,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_HLC_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع هلا سيما'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,89,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_MST_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع المصطبة'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,869,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SNT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع شوف نت'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,849,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_DR7_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع دراما صح'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,689,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CFR_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما فري'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,839,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CMF_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما فانز'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,99,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CML_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما لايت'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,479,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_C4H_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما 400'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,699,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_ABD_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما عبدو'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,559,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_AKT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع اكوام تيوب'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,859,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_DCF_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع دراما كافيه'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,939,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FTV_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فوشار تيفي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,919,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_CWB_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما وبس'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,989,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_AHK_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع أهواك تيفي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,619,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_SRT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيريس تايم'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,899,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_FVD_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع فوشار فيديو'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,909,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_C4P_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع سيما فور بي'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,889,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_EB4_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع ايجي بيست 4'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,809,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'مواقع سيرفرات خاصة - قليلة المشاكل'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,157)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_YUT_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع يوتيوب'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,149,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_DLM_'+NzIM84dwvVex3T1tWDAqchKa9pQyJL+'بحث موقع دايلي موشن'+X8MZ2ylw71DxTsB4iqr3tg6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,DqbrOGw4giHUvfuFtRXQ5lA0yN)
	return