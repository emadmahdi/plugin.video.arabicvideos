# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SHAHIDNEWS'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SHN_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['قنوات فضائية','فارسكو','Show more']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==580: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==581: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==582: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==583: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,text)
	elif mode==584: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==589: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHIDNEWS-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,589,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('/category.php">(.*?)"navslide-divider"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("'dropdown-menu'(.*?)</ul>",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for s5ocIDd4WKuPrV in cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace(s5ocIDd4WKuPrV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,584)
	return
def uJlhLk2Tbcd(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHIDNEWS-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('"presentation"','</ul>')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = [(WnNGfosHr5STAq8j7miwyRZ6eOUbV,KDCdHQmgxPE21tYz4VUowSv)]
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' فرز أو فلتر أو ترتيب '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		for PiS4p2jAQN,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if PiS4p2jAQN: PiS4p2jAQN = PiS4p2jAQN+': '
			for SOw5EUxC9k,title in items:
				title = PiS4p2jAQN+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,581)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"pm-category-subcats"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if len(items)<30:
			octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
			for SOw5EUxC9k,title in items:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,581)
	if not gg4PIzkHEpv and not ZAIyluJa1EWhdB7OHV5CRGSrk: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHIDNEWS-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(data-echo=".*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"BlocksList"(.*?)"titleSectionCon"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="pm-grid"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="pm-related"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items: items = p7dwlH1PRStBgyMUW.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
		if 'http' not in J4tO21KYAVdSr67W5NmiD0XhRP: J4tO21KYAVdSr67W5NmiD0XhRP = VVDAncSMUjeu8Ii+'/'+J4tO21KYAVdSr67W5NmiD0XhRP.strip('/')
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,582,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,583,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movseries/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,581,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,583,J4tO21KYAVdSr67W5NmiD0XhRP)
	if dlPQGb0aC5xmfFwy9ievKTqX not in ['featured_movies','featured_series']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=='#': continue
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,581)
		uDi9v6xMaTs1SwcAl8PRGqCL = p7dwlH1PRStBgyMUW.findall('showmore" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if uDi9v6xMaTs1SwcAl8PRGqCL:
			SOw5EUxC9k = uDi9v6xMaTs1SwcAl8PRGqCL[0]
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مشاهدة المزيد',SOw5EUxC9k,581)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,LW28MawRZDVkYCSjX):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHIDNEWS-EPISODES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('nav-seasons"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	items = []
	H86WsicYNlU7Iurpy23ZAL5PxSnVhf = False
	if gg4PIzkHEpv and not LW28MawRZDVkYCSjX:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for LW28MawRZDVkYCSjX,title in items:
			LW28MawRZDVkYCSjX = LW28MawRZDVkYCSjX.strip('#')
			if len(items)>1: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,583,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,LW28MawRZDVkYCSjX)
			else: H86WsicYNlU7Iurpy23ZAL5PxSnVhf = True
	else: H86WsicYNlU7Iurpy23ZAL5PxSnVhf = True
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('id="'+LW28MawRZDVkYCSjX+'"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk and H86WsicYNlU7Iurpy23ZAL5PxSnVhf:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,title in items:
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,582)
		else:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,582)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	M0MFkiKqJDv1aZ4NA396u = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHIDNEWS-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('"Playerholder".*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	SOw5EUxC9k = SOw5EUxC9k[0]
	if SOw5EUxC9k and 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
	QjOHzAJCT50L8y6GVFhgrok = SOw5EUxC9k.split('hash=')[1]
	ipdI4Kw1lMauxrtYoh = QjOHzAJCT50L8y6GVFhgrok.split('__')
	orWw4B82pTHmyckxaPjCh0,laAHpo1bzyM0q,title = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for iZrspzKymR7cBSxUV6XJtn in ipdI4Kw1lMauxrtYoh:
		ly39wRQpfEesDtGxV = ((4-len(iZrspzKymR7cBSxUV6XJtn)%4)%4)*'='
		try:
			iZrspzKymR7cBSxUV6XJtn = uvGCPpFwVmTQ36.b64decode(iZrspzKymR7cBSxUV6XJtn+ly39wRQpfEesDtGxV)
			if rJ2oTLqabRtA: iZrspzKymR7cBSxUV6XJtn = iZrspzKymR7cBSxUV6XJtn.decode(e87cIA5vwOQLDEP1,'ignore')
		except: pass
		orWw4B82pTHmyckxaPjCh0 += iZrspzKymR7cBSxUV6XJtn
	orWw4B82pTHmyckxaPjCh0 = orWw4B82pTHmyckxaPjCh0.replace(' = ',' => ')
	xne1Sk0mflERdOHDyAIsV4 = orWw4B82pTHmyckxaPjCh0.splitlines()
	for SOw5EUxC9k in xne1Sk0mflERdOHDyAIsV4:
		if '://' in SOw5EUxC9k: laAHpo1bzyM0q.append(SOw5EUxC9k)
	for SOw5EUxC9k in laAHpo1bzyM0q:
		if ' => ' in SOw5EUxC9k: title,SOw5EUxC9k = SOw5EUxC9k.split(' => ')
		elif 'http' in SOw5EUxC9k:
			title,SOw5EUxC9k = SOw5EUxC9k.split('http')
			SOw5EUxC9k = 'http'+SOw5EUxC9k
		else: continue
		SOw5EUxC9k = SOw5EUxC9k.strip(' ')
		if not title: title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
		SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/search.php?keywords='+search
	ctDj2OVRyaUPXCrITmJG(url)
	return