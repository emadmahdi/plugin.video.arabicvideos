# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from tBopO810Wx import *
NTWE764hmOgUtScp2e8r = ZLr5gRSkFewKdUos90bM(u"ࠧࡊࡐࡌࡘࠬኻ")
d4EPa2O3bD7GphMJVZg = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨኼ")
G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
Dj0qYc573K2aQ = int(e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE)
z6PVkLf7Od = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪኽ"))
z6PVkLf7Od = z6PVkLf7Od.replace(w1gu8bCmYAvdjf5a,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(jedSoT7D2Qu,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
if Dj0qYc573K2aQ==rVy3Ops0mohYkT(u"࠷࠼࠰ዣ"): ABb3HfsMKPyeknNp7dq84EaClR = YYQS36fyPvtuzcEmRL(u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫኾ")+mbvW9By35UDO+rVy3Ops0mohYkT(u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ኿")+zmvCUWkdDfrHhoucgFX7T0JGipS+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࠦ࡝ࠨዀ")
else:
	WXipUyJwgsQCET3NRxz9dlZAOYLnqc = EZk136aeLoNqPvlDcTQpyM9Wm(oobgjl3xWaBeRZF8wdzKYAvtus).replace(e6HEdvUcaq8Gx,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	WXipUyJwgsQCET3NRxz9dlZAOYLnqc = WXipUyJwgsQCET3NRxz9dlZAOYLnqc.replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
	WXipUyJwgsQCET3NRxz9dlZAOYLnqc = WXipUyJwgsQCET3NRxz9dlZAOYLnqc.replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	ABb3HfsMKPyeknNp7dq84EaClR = KLX7hW0nBAEgy6m4SvH(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬ዁")+z6PVkLf7Od+wwWzyF4ZpSQXKOgk569(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧዂ")+e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE+rVy3Ops0mohYkT(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨዃ")+WXipUyJwgsQCET3NRxz9dlZAOYLnqc+rVy3Ops0mohYkT(u"ࠩࠣࡡࠬዄ")
SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,d4EPa2O3bD7GphMJVZg+WBDnh75CaLEvkcN6p4ez2KXrV3M+q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+ABb3HfsMKPyeknNp7dq84EaClR)
if bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡣࠬዅ") in SDUJm78sZBG: Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z = SDUJm78sZBG.split(wwWzyF4ZpSQXKOgk569(u"ࠫࡤ࠭዆"),wnaWTQM7VJPkZzO9eoSyFU4)
else: Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z = SDUJm78sZBG,WnNGfosHr5STAq8j7miwyRZ6eOUbV
A3pXVFdyP1.X0Xk5yAVJPfd,C2nN35DILUFzEKqv0BPl4eZjH6 = KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV
if Ak1C6Llhn5dKOFq in [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࠷ࠧ዇"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࠲ࠨወ"),SI7eBdND4lx8pt5Qk(u"ࠧ࠴ࠩዉ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠨ࠶ࠪዊ"),KLX7hW0nBAEgy6m4SvH(u"ࠩ࠸ࠫዋ"),pp7FcjEe6g(u"ࠪ࠵࠶࠭ዌ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠶࠸ࠧው"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࠷࠳ࠨዎ")] and (wwWzyF4ZpSQXKOgk569(u"࠭ࡁࡅࡆࠪዏ") in tyBbpM6uq7N2FdgksfT5z or jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧዐ") in tyBbpM6uq7N2FdgksfT5z or rVy3Ops0mohYkT(u"ࠨࡗࡓࠫዑ") in tyBbpM6uq7N2FdgksfT5z or aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡇࡓ࡜ࡔࠧዒ") in tyBbpM6uq7N2FdgksfT5z):
	from zQ1YjoMLiN import B5LHyWdY6Cu
	B5LHyWdY6Cu(SDUJm78sZBG,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z)
	G3yDpvxOiSWdAeL.setSetting(A6iX18qgyOFlZxz7sc(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧዓ"),oobgjl3xWaBeRZF8wdzKYAvtus)
	A3pXVFdyP1.X0Xk5yAVJPfd = r0D4C3z7Onqpa
elif not dJ3lKeg21CuqpwSEhQYPmDV and Dj0qYc573K2aQ in [gPE1XB87fQl(u"࠸࠳࠶ዤ"),SI7eBdND4lx8pt5Qk(u"࠷࠲࠷ዥ")]:
	A2N8BQZTY4p6XKygzOl7nD = str(AUBZYG84NbOKsRnxi6jgk2f[A6iX18qgyOFlZxz7sc(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዔ")])
	NTWE764hmOgUtScp2e8r = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡏࡐࡕࡘࠪዕ") if Dj0qYc573K2aQ==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳࠵࠸ዦ") else A6iX18qgyOFlZxz7sc(u"࠭ࡍ࠴ࡗࠪዖ")
	wwQ1HmBbdT = NTWE764hmOgUtScp2e8r.lower()
	iHYO7Ic9kKUdPsgSCVyR = G3yDpvxOiSWdAeL.getSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡢࡸ࠱ࠫ዗")+wwQ1HmBbdT+beV5l2D8HznyJI0(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ዘ")+A2N8BQZTY4p6XKygzOl7nD)
	a8ViDmKTjhIEs4bnykRL = G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠩࡤࡺ࠳࠭ዙ")+wwQ1HmBbdT+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ዚ")+A2N8BQZTY4p6XKygzOl7nD)
	if iHYO7Ic9kKUdPsgSCVyR or a8ViDmKTjhIEs4bnykRL:
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA += Z9FPQvwlbjLTh(u"ࠫࢁ࠭ዛ")
		if iHYO7Ic9kKUdPsgSCVyR: kdNn2Zqsj4wPi5ThuoUQvtcg6OA += bawK2j7T81Nrc4GWs05xzDg(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫዜ")+iHYO7Ic9kKUdPsgSCVyR
		if a8ViDmKTjhIEs4bnykRL: kdNn2Zqsj4wPi5ThuoUQvtcg6OA += ZLr5gRSkFewKdUos90bM(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩዝ")+a8ViDmKTjhIEs4bnykRL
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(KLX7hW0nBAEgy6m4SvH(u"ࠧࡽࠨࠪዞ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡾࠪዟ"))
	vsc8XiL4R1P0fIWj9a = G3yDpvxOiSWdAeL.getSetting(VP70ytiFNMBl6vHDaW(u"ࠩࡤࡺ࠳࠭ዠ")+wwQ1HmBbdT+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬዡ")+A2N8BQZTY4p6XKygzOl7nD)
	if vsc8XiL4R1P0fIWj9a:
		Ss5NbjIMxVlyKrGaP0X1v = p7dwlH1PRStBgyMUW.findall(CyHU86ZeYT5BWRcitSm2I(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧዢ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,p7dwlH1PRStBgyMUW.DOTALL)
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(Ss5NbjIMxVlyKrGaP0X1v[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],vsc8XiL4R1P0fIWj9a)
	YsRk6pAS7rdcn(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,NTWE764hmOgUtScp2e8r,G3Xh0YWACHFuvQLx5sVEfPjzq7)
else:
	import UdvL4wSQeI
	try: UdvL4wSQeI.PMZ8lwjHRh(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z,z6PVkLf7Od)
	except Exception as OxvlAjSprB8IiE5: C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
nnKlvfXN2Jqiaw6FxT(A3pXVFdyP1.X0Xk5yAVJPfd,C2nN35DILUFzEKqv0BPl4eZjH6)