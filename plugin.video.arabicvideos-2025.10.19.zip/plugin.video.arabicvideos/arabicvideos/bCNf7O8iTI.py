# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'IFILM'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_IFL_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
wwmXPdcfpo = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][1]
jFaJ2ULfqTCxWOz8gYZS = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][2]
gZDbesfQ4ou6y8IX209AiTc = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][3]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,TB3DI4JWr0NYmik1xO8Kc2,text):
	if   mode==20: APpdhB1Fk58MmJH7CjVntowyaY = gmyZR4Eeq2()
	elif mode==21: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D(url)
	elif mode==22: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==23: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==24: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,text)
	elif mode==25: APpdhB1Fk58MmJH7CjVntowyaY = uQ8YDiC6m94K7hSMs(url)
	elif mode==27: APpdhB1Fk58MmJH7CjVntowyaY = GhmfN2TgEXLD5CpAJeaY(url)
	elif mode==28: APpdhB1Fk58MmJH7CjVntowyaY = rwbu50jkmgJKQIi()
	elif mode==29: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def gmyZR4Eeq2():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'عربي',pcE6DxaoHBm41WKXjwnk,21,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'English',wwmXPdcfpo,21,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فارسى',jFaJ2ULfqTCxWOz8gYZS,21,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فارسى 2',gZDbesfQ4ou6y8IX209AiTc,21,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	return
def rwbu50jkmgJKQIi():
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'عربي',pcE6DxaoHBm41WKXjwnk,27)
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'English',wwmXPdcfpo,27)
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فارسى',jFaJ2ULfqTCxWOz8gYZS,27)
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فارسى 2',gZDbesfQ4ou6y8IX209AiTc,27)
	return
def bRaCHZtyd3qj7D(xkBfP8yWKTu7G32I9rREAcq):
	NTWE764hmOgUtScp2e8r = xkBfP8yWKTu7G32I9rREAcq
	if xkBfP8yWKTu7G32I9rREAcq=='IFILM-ARABIC': xkBfP8yWKTu7G32I9rREAcq = pcE6DxaoHBm41WKXjwnk
	elif xkBfP8yWKTu7G32I9rREAcq=='IFILM-ENGLISH': xkBfP8yWKTu7G32I9rREAcq = wwmXPdcfpo
	else: NTWE764hmOgUtScp2e8r = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(xkBfP8yWKTu7G32I9rREAcq)
	if wwurzsGRxpMfaCqc1J=='ar' or NTWE764hmOgUtScp2e8r=='IFILM-ARABIC':
		wt3enIlhFijC4vMZNHpEazo = 'بحث في الموقع'
		h1Pf2qE7ap = 'مسلسلات - حالية'
		Zf06rvhWgN3OPj2YTdeqU = 'مسلسلات - أحدث'
		q4MTWSoVeCKru7s5D = 'مسلسلات - أبجدي'
		I8fNX4pCHnLZD = 'بث حي آي فيلم'
		EEwt20Wd4FKQLxUgDfVu = 'أفلام'
		jzSZxroqhP9ynem2BHO = 'موسيقى'
		U5aZzkxQKLFioM = 'برامج'
	elif wwurzsGRxpMfaCqc1J=='en' or NTWE764hmOgUtScp2e8r=='IFILM-ENGLISH':
		wt3enIlhFijC4vMZNHpEazo = 'Search in site'
		h1Pf2qE7ap = 'Series - Current'
		Zf06rvhWgN3OPj2YTdeqU = 'Series - Latest'
		q4MTWSoVeCKru7s5D = 'Series - Alphabet'
		I8fNX4pCHnLZD = 'Live iFilm channel'
		EEwt20Wd4FKQLxUgDfVu = 'Movies'
		jzSZxroqhP9ynem2BHO = 'Music'
		U5aZzkxQKLFioM = 'Shows'
	elif wwurzsGRxpMfaCqc1J in ['fa','fa2']:
		wt3enIlhFijC4vMZNHpEazo = 'جستجو در سایت'
		h1Pf2qE7ap = 'سريال - جاری'
		Zf06rvhWgN3OPj2YTdeqU = 'سريال - آخرین'
		q4MTWSoVeCKru7s5D = 'سريال - الفبا'
		I8fNX4pCHnLZD = 'پخش زنده اي فيلم'
		EEwt20Wd4FKQLxUgDfVu = 'فيلم'
		jzSZxroqhP9ynem2BHO = 'موسيقى'
		U5aZzkxQKLFioM = 'برنامه ها'
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+wt3enIlhFijC4vMZNHpEazo,xkBfP8yWKTu7G32I9rREAcq,29,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+I8fNX4pCHnLZD,xkBfP8yWKTu7G32I9rREAcq,27)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	xolUtmyJWcC0eR7 = ['Series','Program','Music']
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,xkBfP8yWKTu7G32I9rREAcq+'/home',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-MENU-1st')
	cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('button-menu(.*?)/Contact',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if any(value in SOw5EUxC9k for value in xolUtmyJWcC0eR7):
				url = xkBfP8yWKTu7G32I9rREAcq+SOw5EUxC9k
				if 'Series' in SOw5EUxC9k:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'100')
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+Zf06rvhWgN3OPj2YTdeqU,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+q4MTWSoVeCKru7s5D,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'201')
				elif 'Film' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+EEwt20Wd4FKQLxUgDfVu,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'100')
				elif 'Music' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+jzSZxroqhP9ynem2BHO,url,25,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
				elif 'Program' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+U5aZzkxQKLFioM,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	return piN9Qlah4S
def uQ8YDiC6m94K7hSMs(url):
	xkBfP8yWKTu7G32I9rREAcq = mmowurezGQLfaMTxV6N5b2AOlg(url)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-MUSIC_MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('Music-tools-header(.*?)Music-body',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	title = p7dwlH1PRStBgyMUW.findall('<p>(.*?)</p>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)[0]
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = xkBfP8yWKTu7G32I9rREAcq + SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,23,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'101')
	return
def ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2):
	xkBfP8yWKTu7G32I9rREAcq = mmowurezGQLfaMTxV6N5b2AOlg(url)
	wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(url)
	type = url.split('/')[-1]
	XlH8DYMV9Zmp = str(int(TB3DI4JWr0NYmik1xO8Kc2)//100)
	TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)%100)
	if type=='Series' and TB3DI4JWr0NYmik1xO8Kc2=='0':
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-TITLES-1st')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('serial-body(.*?)class="row',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			title = clFjTSgMODe7Nq0H3Vzs(title)
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			SOw5EUxC9k = xkBfP8yWKTu7G32I9rREAcq + SOw5EUxC9k
			J4tO21KYAVdSr67W5NmiD0XhRP = xkBfP8yWKTu7G32I9rREAcq + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,23,J4tO21KYAVdSr67W5NmiD0XhRP,XlH8DYMV9Zmp+'01')
	G0WRE9w7is4TVPANyDgIJYjmOMZnLa=0
	if type=='Series': eukVjoW67vBiySNXrplDKIZLHU='3'
	if type=='Film': eukVjoW67vBiySNXrplDKIZLHU='5'
	if type=='Program': eukVjoW67vBiySNXrplDKIZLHU='7'
	if type in ['Series','Program','Film'] and TB3DI4JWr0NYmik1xO8Kc2!='0':
		vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Home/PageingItem?category='+eukVjoW67vBiySNXrplDKIZLHU+'&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&orderby='+XlH8DYMV9Zmp
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-TITLES-2nd')
		items = p7dwlH1PRStBgyMUW.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for id,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			title = clFjTSgMODe7Nq0H3Vzs(title)
			title = title.replace('\\',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			title = title.replace('"',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
			SOw5EUxC9k = xkBfP8yWKTu7G32I9rREAcq + '/' + type + '/Content/' + id
			J4tO21KYAVdSr67W5NmiD0XhRP = xkBfP8yWKTu7G32I9rREAcq + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
			if type=='Film': octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,24,J4tO21KYAVdSr67W5NmiD0XhRP,XlH8DYMV9Zmp+'01')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,23,J4tO21KYAVdSr67W5NmiD0XhRP,XlH8DYMV9Zmp+'01')
	if type=='Music':
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,xkBfP8yWKTu7G32I9rREAcq+'/Music/Index?page='+TB3DI4JWr0NYmik1xO8Kc2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-TITLES-3rd')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pagination-demo(.*?)pagination-demo',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
			J4tO21KYAVdSr67W5NmiD0XhRP = xkBfP8yWKTu7G32I9rREAcq + J4tO21KYAVdSr67W5NmiD0XhRP
			SOw5EUxC9k = xkBfP8yWKTu7G32I9rREAcq + SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,23,J4tO21KYAVdSr67W5NmiD0XhRP,'101')
	if G0WRE9w7is4TVPANyDgIJYjmOMZnLa>20:
		title='صفحة '
		if wwurzsGRxpMfaCqc1J=='en': title = 'Page '
		if wwurzsGRxpMfaCqc1J=='fa': title = 'صفحه '
		if wwurzsGRxpMfaCqc1J=='fa2': title = 'صفحه '
		for kwcTvZPuNd7 in range(1,11) :
			if not TB3DI4JWr0NYmik1xO8Kc2==str(kwcTvZPuNd7):
				G5ITRnprwkjdyfvt1s9oVhAgS = '0'+str(kwcTvZPuNd7)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title+str(kwcTvZPuNd7),url,22,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XlH8DYMV9Zmp+G5ITRnprwkjdyfvt1s9oVhAgS[-2:])
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,TB3DI4JWr0NYmik1xO8Kc2):
	if not TB3DI4JWr0NYmik1xO8Kc2: TB3DI4JWr0NYmik1xO8Kc2 = 0
	xkBfP8yWKTu7G32I9rREAcq = mmowurezGQLfaMTxV6N5b2AOlg(url)
	nzIvkRxy1XtfeDHPjq54pNVG6 = mmowurezGQLfaMTxV6N5b2AOlg(url)
	wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(url)
	ipdI4Kw1lMauxrtYoh = url.split('/')
	id,type = ipdI4Kw1lMauxrtYoh[-1],ipdI4Kw1lMauxrtYoh[3]
	XlH8DYMV9Zmp = str(int(TB3DI4JWr0NYmik1xO8Kc2)//100)
	TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)%100)
	G0WRE9w7is4TVPANyDgIJYjmOMZnLa = 0
	if type=='Series':
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-1st')
		items = p7dwlH1PRStBgyMUW.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		title = ' - الحلقة '
		if wwurzsGRxpMfaCqc1J=='en': title = ' - Episode '
		if wwurzsGRxpMfaCqc1J=='fa': title = ' - قسمت '
		if wwurzsGRxpMfaCqc1J=='fa2': title = ' - قسمت '
		if wwurzsGRxpMfaCqc1J=='fa': RkfFQ3DTzPuSCHWwZOKI = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		else: RkfFQ3DTzPuSCHWwZOKI = wwurzsGRxpMfaCqc1J
		MA2SH3DEt9PJjQW = p7dwlH1PRStBgyMUW.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for name,count,J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k in items:
			for er96jwp52cbvaV48mtylEYSRz in range(int(count),0,-1):
				MgyFJXAIwBjkqZlQ53x = J4tO21KYAVdSr67W5NmiD0XhRP + RkfFQ3DTzPuSCHWwZOKI + id + '/' + str(er96jwp52cbvaV48mtylEYSRz) + '.png'
				h1Pf2qE7ap = name + title + str(er96jwp52cbvaV48mtylEYSRz)
				h1Pf2qE7ap = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(h1Pf2qE7ap)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,url,24,MgyFJXAIwBjkqZlQ53x,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(er96jwp52cbvaV48mtylEYSRz))
	elif type=='Program':
		vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&orderby=1'
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-2nd')
		items = p7dwlH1PRStBgyMUW.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		title = ' - الحلقة '
		if wwurzsGRxpMfaCqc1J=='en': title = ' - Episode '
		if wwurzsGRxpMfaCqc1J=='fa': title = ' - قسمت '
		if wwurzsGRxpMfaCqc1J=='fa2': title = ' - قسمت '
		for er96jwp52cbvaV48mtylEYSRz,J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,plN92zA5jTVkb1IE3QKGS6yH,name in items:
			G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
			MgyFJXAIwBjkqZlQ53x = nzIvkRxy1XtfeDHPjq54pNVG6 + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
			name = clFjTSgMODe7Nq0H3Vzs(name)
			h1Pf2qE7ap = name + title + str(er96jwp52cbvaV48mtylEYSRz)
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,vcQbFfCk6T1,24,MgyFJXAIwBjkqZlQ53x,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(G0WRE9w7is4TVPANyDgIJYjmOMZnLa))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Music/GetTracksBy?id='+str(id)+'&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&type=0'
			piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-3rd')
			items = p7dwlH1PRStBgyMUW.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,name,title in items:
				G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
				MgyFJXAIwBjkqZlQ53x = nzIvkRxy1XtfeDHPjq54pNVG6 + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
				h1Pf2qE7ap = name + ' - ' + title
				h1Pf2qE7ap = h1Pf2qE7ap.strip(kcXMWrwiLDKeBHRsJ)
				h1Pf2qE7ap = clFjTSgMODe7Nq0H3Vzs(h1Pf2qE7ap)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,vcQbFfCk6T1,24,MgyFJXAIwBjkqZlQ53x,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(G0WRE9w7is4TVPANyDgIJYjmOMZnLa))
		elif 'Clips' in url:
			vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Music/GetTracksBy?id=0&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&type=15'
			piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-4th')
			items = p7dwlH1PRStBgyMUW.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			for J4tO21KYAVdSr67W5NmiD0XhRP,title,SOw5EUxC9k in items:
				G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
				MgyFJXAIwBjkqZlQ53x = nzIvkRxy1XtfeDHPjq54pNVG6 + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
				h1Pf2qE7ap = title.strip(kcXMWrwiLDKeBHRsJ)
				h1Pf2qE7ap = clFjTSgMODe7Nq0H3Vzs(h1Pf2qE7ap)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,vcQbFfCk6T1,24,MgyFJXAIwBjkqZlQ53x,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(G0WRE9w7is4TVPANyDgIJYjmOMZnLa))
		elif 'category' in url:
			if 'category=6' in url:
				vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Music/GetTracksBy?id=0&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&type=6'
				piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				vcQbFfCk6T1 = xkBfP8yWKTu7G32I9rREAcq+'/Music/GetTracksBy?id=0&page='+TB3DI4JWr0NYmik1xO8Kc2+'&size=30&type=4'
				piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-EPISODES-6th')
			items = p7dwlH1PRStBgyMUW.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,name,title in items:
				G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
				MgyFJXAIwBjkqZlQ53x = nzIvkRxy1XtfeDHPjq54pNVG6 + ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
				h1Pf2qE7ap = name + ' - ' + title
				h1Pf2qE7ap = h1Pf2qE7ap.strip(kcXMWrwiLDKeBHRsJ)
				h1Pf2qE7ap = clFjTSgMODe7Nq0H3Vzs(h1Pf2qE7ap)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+h1Pf2qE7ap,vcQbFfCk6T1,24,MgyFJXAIwBjkqZlQ53x,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(G0WRE9w7is4TVPANyDgIJYjmOMZnLa))
	if type=='Music' or type=='Program':
		if G0WRE9w7is4TVPANyDgIJYjmOMZnLa>25:
			title='صفحة '
			if wwurzsGRxpMfaCqc1J=='en': title = ' Page '
			if wwurzsGRxpMfaCqc1J=='fa': title = ' صفحه '
			if wwurzsGRxpMfaCqc1J=='fa2': title = ' صفحه '
			for kwcTvZPuNd7 in range(1,11):
				if not TB3DI4JWr0NYmik1xO8Kc2==str(kwcTvZPuNd7):
					G5ITRnprwkjdyfvt1s9oVhAgS = '0'+str(kwcTvZPuNd7)
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title+str(kwcTvZPuNd7),url,23,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XlH8DYMV9Zmp+G5ITRnprwkjdyfvt1s9oVhAgS[-2:])
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,er96jwp52cbvaV48mtylEYSRz):
	nzIvkRxy1XtfeDHPjq54pNVG6 = mmowurezGQLfaMTxV6N5b2AOlg(url)
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-PLAY-1st')
	items = p7dwlH1PRStBgyMUW.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(url)
		ipdI4Kw1lMauxrtYoh = url.split('/')
		id,type = ipdI4Kw1lMauxrtYoh[-1],ipdI4Kw1lMauxrtYoh[3]
		SOw5EUxC9k = items[0][0]+wwurzsGRxpMfaCqc1J+id+'/,'+er96jwp52cbvaV48mtylEYSRz+','+er96jwp52cbvaV48mtylEYSRz+'_'+items[0][2]
		ZD0qItXg31HmC7KGEFn.append('m3u8')
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	items = p7dwlH1PRStBgyMUW.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(url)
		ipdI4Kw1lMauxrtYoh = url.split('/')
		id,type = ipdI4Kw1lMauxrtYoh[-1],ipdI4Kw1lMauxrtYoh[3]
		SOw5EUxC9k = items[0][0]+wwurzsGRxpMfaCqc1J+id+'/'+er96jwp52cbvaV48mtylEYSRz+items[0][2]
		ZD0qItXg31HmC7KGEFn.append('mp4 url')
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	items = p7dwlH1PRStBgyMUW.findall('source src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k in items:
		SOw5EUxC9k = SOw5EUxC9k.replace('//','/')
		ZD0qItXg31HmC7KGEFn.append('mp4 src')
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	items = p7dwlH1PRStBgyMUW.findall('VideoAddress":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		SOw5EUxC9k = items[int(er96jwp52cbvaV48mtylEYSRz)-1]
		SOw5EUxC9k = nzIvkRxy1XtfeDHPjq54pNVG6+ZisgmEGCOJxVI9DcetNBPo6(SOw5EUxC9k)
		ZD0qItXg31HmC7KGEFn.append('mp4 address')
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	items = p7dwlH1PRStBgyMUW.findall('VoiceAddress":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		SOw5EUxC9k = items[int(er96jwp52cbvaV48mtylEYSRz)-1]
		SOw5EUxC9k = nzIvkRxy1XtfeDHPjq54pNVG6+ZisgmEGCOJxVI9DcetNBPo6(SOw5EUxC9k)
		ZD0qItXg31HmC7KGEFn.append('mp3 address')
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if len(M0MFkiKqJDv1aZ4NA396u)==1: SOw5EUxC9k = M0MFkiKqJDv1aZ4NA396u[0]
	else:
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر الفيديو المناسب:', ZD0qItXg31HmC7KGEFn)
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
		SOw5EUxC9k = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	YsRk6pAS7rdcn(SOw5EUxC9k,NTWE764hmOgUtScp2e8r,'video')
	return
def mmowurezGQLfaMTxV6N5b2AOlg(url):
	if pcE6DxaoHBm41WKXjwnk in url: OOG1iPYhTKQ4 = pcE6DxaoHBm41WKXjwnk
	elif wwmXPdcfpo in url: OOG1iPYhTKQ4 = wwmXPdcfpo
	elif jFaJ2ULfqTCxWOz8gYZS in url: OOG1iPYhTKQ4 = jFaJ2ULfqTCxWOz8gYZS
	elif gZDbesfQ4ou6y8IX209AiTc in url: OOG1iPYhTKQ4 = gZDbesfQ4ou6y8IX209AiTc
	else: OOG1iPYhTKQ4 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	return OOG1iPYhTKQ4
def bNmCZ3sk6DQWzJhFIuTfG951o(url):
	if   pcE6DxaoHBm41WKXjwnk in url: wwurzsGRxpMfaCqc1J = 'ar'
	elif wwmXPdcfpo in url: wwurzsGRxpMfaCqc1J = 'en'
	elif jFaJ2ULfqTCxWOz8gYZS in url: wwurzsGRxpMfaCqc1J = 'fa'
	elif gZDbesfQ4ou6y8IX209AiTc in url: wwurzsGRxpMfaCqc1J = 'fa2'
	else: wwurzsGRxpMfaCqc1J = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	return wwurzsGRxpMfaCqc1J
def GhmfN2TgEXLD5CpAJeaY(url):
	wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(url)
	vcQbFfCk6T1 = url + '/Home/Live'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-LIVE-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('source src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = items[0]
	YsRk6pAS7rdcn(QQTfhlZEDnu4wVcOeHGNyCBo5t2,NTWE764hmOgUtScp2e8r,'live')
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not search: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	if showDialogs:
		uSI8OUZRAxcYlXzV7qr5w29i = [ pcE6DxaoHBm41WKXjwnk , wwmXPdcfpo , jFaJ2ULfqTCxWOz8gYZS , gZDbesfQ4ou6y8IX209AiTc ]
		xAeVLRTDjGN9mOokK7r5hIpZ = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر اللغة المناسبة:', xAeVLRTDjGN9mOokK7r5hIpZ)
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
		website = uSI8OUZRAxcYlXzV7qr5w29i[XFaM94cPUCOWQZNIEe8gdJpny1]
	else:
		if '_IFILM-ARABIC_' in xCONTFizaKbJS1: website = pcE6DxaoHBm41WKXjwnk
		elif '_IFILM-ENGLISH_' in xCONTFizaKbJS1: website = wwmXPdcfpo
		else: website = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if not website: return
	wwurzsGRxpMfaCqc1J = bNmCZ3sk6DQWzJhFIuTfG951o(website)
	vcQbFfCk6T1 = website + "/Home/Search?searchstring=" + DqbrOGw4giHUvfuFtRXQ5lA0yN
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IFILM-SEARCH-1st')
	items = p7dwlH1PRStBgyMUW.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		for J4tO21KYAVdSr67W5NmiD0XhRP,eukVjoW67vBiySNXrplDKIZLHU,id,title in items:
			if eukVjoW67vBiySNXrplDKIZLHU in ['3','7']:
				title = title.replace('\\',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				title = title.replace('"',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				if eukVjoW67vBiySNXrplDKIZLHU=='3':
					type = 'Series'
					if wwurzsGRxpMfaCqc1J=='ar': name = 'مسلسل : '
					elif wwurzsGRxpMfaCqc1J=='en': name = 'Series : '
					elif wwurzsGRxpMfaCqc1J=='fa': name = 'سريال ها : '
					elif wwurzsGRxpMfaCqc1J=='fa2': name = 'سريال ها : '
				elif eukVjoW67vBiySNXrplDKIZLHU=='5':
					type = 'Film'
					if wwurzsGRxpMfaCqc1J=='ar': name = 'فيلم : '
					elif wwurzsGRxpMfaCqc1J=='en': name = 'Movie : '
					elif wwurzsGRxpMfaCqc1J=='fa': name = 'فيلم : '
					elif wwurzsGRxpMfaCqc1J=='fa2': name = 'فلم ها : '
				elif eukVjoW67vBiySNXrplDKIZLHU=='7':
					type = 'Program'
					if wwurzsGRxpMfaCqc1J=='ar': name = 'برنامج : '
					elif wwurzsGRxpMfaCqc1J=='en': name = 'Program : '
					elif wwurzsGRxpMfaCqc1J=='fa': name = 'برنامه ها : '
					elif wwurzsGRxpMfaCqc1J=='fa2': name = 'برنامه ها : '
				title = name + title
				SOw5EUxC9k = website + '/' + type + '/Content/' + id
				J4tO21KYAVdSr67W5NmiD0XhRP = ZisgmEGCOJxVI9DcetNBPo6(J4tO21KYAVdSr67W5NmiD0XhRP)
				J4tO21KYAVdSr67W5NmiD0XhRP = website+J4tO21KYAVdSr67W5NmiD0XhRP
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,23,J4tO21KYAVdSr67W5NmiD0XhRP,'101')
	return