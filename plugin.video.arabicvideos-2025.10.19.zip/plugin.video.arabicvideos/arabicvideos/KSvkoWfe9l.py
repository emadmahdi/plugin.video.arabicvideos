# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'EGYNOW'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_EGN_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==430: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==431: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==432: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==433: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==434: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==437: APpdhB1Fk58MmJH7CjVntowyaY = jKAYNko3tmEcpfzWn5F(url)
	elif mode==439: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk+'/films',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = p7dwlH1PRStBgyMUW.findall('"canonical" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	VVDAncSMUjeu8Ii = VVDAncSMUjeu8Ii[0].strip('/')
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(VVDAncSMUjeu8Ii,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,439,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',VVDAncSMUjeu8Ii,435)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',VVDAncSMUjeu8Ii,434)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المضاف حديثا',VVDAncSMUjeu8Ii,431)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'افلام اون لاين',VVDAncSMUjeu8Ii+'/films1',436)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات اون لاين',VVDAncSMUjeu8Ii+'/series-all1',436)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'قائمة تفصيلية',VVDAncSMUjeu8Ii,437)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"SiteNavigation"(.*?)"Search"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,431)
	return
def jKAYNko3tmEcpfzWn5F(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',website+'/films',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = p7dwlH1PRStBgyMUW.findall('"canonical" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	VVDAncSMUjeu8Ii = VVDAncSMUjeu8Ii[0].strip('/')
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(VVDAncSMUjeu8Ii,'url')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"ListDroped"(.*?)"SearchingMaster"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for eukVjoW67vBiySNXrplDKIZLHU,value,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		SOw5EUxC9k = website+'/explore/?'+eukVjoW67vBiySNXrplDKIZLHU+'='+value
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,431)
	return
def uJlhLk2Tbcd(url):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-SUBMENU-1st')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',url,431)
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"titleSectionCon"(.*?)</div></div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-key="(.*?)".*?<em>(.*?)</em>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SUm0TCBiv7ck8sDMhOp,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		vcQbFfCk6T1 = VVDAncSMUjeu8Ii+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+SUm0TCBiv7ck8sDMhOp
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,vcQbFfCk6T1,431)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-TITLES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured':
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-TITLES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"MainSlider"(.*?)"MatchesTable"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-TITLES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"BlocksList"(.*?)"Paginate"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"BlocksList"(.*?)"titleSectionCon"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items: items = p7dwlH1PRStBgyMUW.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,432,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,433,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movseries/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,431,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,433,J4tO21KYAVdSr67W5NmiD0XhRP)
	if dlPQGb0aC5xmfFwy9ievKTqX!='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"Paginate"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+SOw5EUxC9k
				SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,431)
		uDi9v6xMaTs1SwcAl8PRGqCL = p7dwlH1PRStBgyMUW.findall('showmore" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if uDi9v6xMaTs1SwcAl8PRGqCL:
			SOw5EUxC9k = uDi9v6xMaTs1SwcAl8PRGqCL[0]
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مشاهدة المزيد',SOw5EUxC9k,431)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	gg4PIzkHEpv,ZAIyluJa1EWhdB7OHV5CRGSrk = [],[]
	if 'Episodes.php' in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-EPISODES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		ZAIyluJa1EWhdB7OHV5CRGSrk = [piN9Qlah4S]
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-EPISODES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"SeasonsList"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"EpisodesList"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv:
		J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"og:image" content="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0]
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for dHqBsvSieRxmbAPXVJ0o,kkVyhIUtMBFNL9J5pCaXZg3xG,title in items:
			SOw5EUxC9k = VVDAncSMUjeu8Ii+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+kkVyhIUtMBFNL9J5pCaXZg3xG+'&post_id='+dHqBsvSieRxmbAPXVJ0o
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,433,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif ZAIyluJa1EWhdB7OHV5CRGSrk:
		J4tO21KYAVdSr67W5NmiD0XhRP = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Thumb')
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,er96jwp52cbvaV48mtylEYSRz in items:
			title = title+kcXMWrwiLDKeBHRsJ+er96jwp52cbvaV48mtylEYSRz
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,432,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	vcQbFfCk6T1 = url+'/watch/'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	M0MFkiKqJDv1aZ4NA396u = []
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,'url')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"container-servers"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		sswWia2EuAo8ZQ4jPX = p7dwlH1PRStBgyMUW.findall('data-id="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if sswWia2EuAo8ZQ4jPX:
			sswWia2EuAo8ZQ4jPX = sswWia2EuAo8ZQ4jPX[0]
			items = p7dwlH1PRStBgyMUW.findall('data-server="(.*?)".*?<span>(.*?)</span>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for VVpQfHc7IZamxweON3WXKU6Fg,title in items:
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+VVpQfHc7IZamxweON3WXKU6Fg+'&post_id='+sswWia2EuAo8ZQ4jPX+'?named='+title+'__watch'
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	GJnrKUuZkemlBg7v1qMpYcFah9 = p7dwlH1PRStBgyMUW.findall('"container-iframe"><iframe src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if GJnrKUuZkemlBg7v1qMpYcFah9:
		GJnrKUuZkemlBg7v1qMpYcFah9 = GJnrKUuZkemlBg7v1qMpYcFah9[0].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(GJnrKUuZkemlBg7v1qMpYcFah9,'name')
		SOw5EUxC9k = GJnrKUuZkemlBg7v1qMpYcFah9+'?named='+title+'__embed'
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"container-download"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,DIBw28Qfje76bTMzVNYhxrgWmO in items:
			SOw5EUxC9k = SOw5EUxC9k.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if DIBw28Qfje76bTMzVNYhxrgWmO!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: DIBw28Qfje76bTMzVNYhxrgWmO = '____'+DIBw28Qfje76bTMzVNYhxrgWmO
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'+DIBw28Qfje76bTMzVNYhxrgWmO
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	url = pcE6DxaoHBm41WKXjwnk+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(url)
	return
def J87GLvYrDtMFUo9R6OuEyhi1zC3(url):
	url = url.split('/smartemadfilter?')[0]
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',VVDAncSMUjeu8Ii,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('("dropdown-button".*?)"SearchingMaster"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return ZudC8bDqo4mM5c7GfP96Qy2F
def sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv):
	items = p7dwlH1PRStBgyMUW.findall('data-term="(\d+)" data-name="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return items
def tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url):
	q16smZkWvE = url.split('/smartemadfilter?')[0]
	HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	url = url.replace(q16smZkWvE,HM25TctPpBqSeNzx3fm714)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def ccvI5ehbQsqrPAL1UktT7(A5AHnwB1MJQ4O,url):
	CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'modified_filters')
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
	return QQTfhlZEDnu4wVcOeHGNyCBo5t2
tqgKeQMz5XNvBPZAE6DCxfaLbj = ['category','country','genre','release-year']
wQyTn0NR9VkaBSCrDzPsqMl = ['quality','release-year','genre','category','language','country']
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	elif type=='ALL_ITEMS_FILTER':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'/smartemadfilter?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',vcQbFfCk6T1,431)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,431)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ZudC8bDqo4mM5c7GfP96Qy2F = J87GLvYrDtMFUo9R6OuEyhi1zC3(url)
	dict = {}
	for name,KDCdHQmgxPE21tYz4VUowSv,LgJITEZU95fS2oi8K in ZudC8bDqo4mM5c7GfP96Qy2F:
		name = name.replace('--',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		items = sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='SPECIFIED_FILTER':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<2:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]:
					url = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url)
					ctDj2OVRyaUPXCrITmJG(url)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'SPECIFIED_FILTER___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',vcQbFfCk6T1,431)
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',vcQbFfCk6T1,435,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='ALL_ITEMS_FILTER':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع :'+name,vcQbFfCk6T1,434,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if value=='196533': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'أفلام نيتفلكس'
			elif value=='196531': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'مسلسلات نيتفلكس'
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'+name
			if type=='ALL_ITEMS_FILTER': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,434,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='SPECIFIED_FILTER' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = ccvI5ehbQsqrPAL1UktT7(A5AHnwB1MJQ4O,url)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,431)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,435,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.replace('=&','=0&')
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all_filters': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	CZewXSEQ3q = CZewXSEQ3q.replace('=0','=')
	return CZewXSEQ3q