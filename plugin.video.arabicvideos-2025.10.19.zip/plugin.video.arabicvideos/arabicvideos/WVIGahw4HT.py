# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
import bs4 as hLC3KQBHqskr4n
NTWE764hmOgUtScp2e8r = 'ELCINEMA'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_ELC_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
headers = {'Referer':pcE6DxaoHBm41WKXjwnk}
EViWBhSw3dea8pTUO9AFMKbGjks027 = []
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==510: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==511: APpdhB1Fk58MmJH7CjVntowyaY = IdQgfnmvXrlZV4LDqb(url)
	elif mode==512: APpdhB1Fk58MmJH7CjVntowyaY = Hbrwkox0p7jJu6XKlIAR3GCSs(url)
	elif mode==513: APpdhB1Fk58MmJH7CjVntowyaY = Zgy2ijr0oCSflAtT9P68aw(url)
	elif mode==514: APpdhB1Fk58MmJH7CjVntowyaY = iixL6ryhDO1X7Ke0gHnauGE(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: APpdhB1Fk58MmJH7CjVntowyaY = iixL6ryhDO1X7Ke0gHnauGE(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: APpdhB1Fk58MmJH7CjVntowyaY = ez6gxMiPw8A3k5Jcys1KrjaXHdlGO7(text)
	elif mode==517: APpdhB1Fk58MmJH7CjVntowyaY = gv9u8NlJfaZWkGHM0c3yxbmpTU7Iw(url)
	elif mode==518: APpdhB1Fk58MmJH7CjVntowyaY = GGvEsYTpCh23jmfabw1RDiFlruUkA(url)
	elif mode==519: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	elif mode==520: APpdhB1Fk58MmJH7CjVntowyaY = Zg3hFlUd46J8SKWOkMwv(url)
	elif mode==521: APpdhB1Fk58MmJH7CjVntowyaY = fft5robNav(url)
	elif mode==522: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==523: APpdhB1Fk58MmJH7CjVntowyaY = XERnz4IbBSNdHy6eYD2813c(text)
	elif mode==524: APpdhB1Fk58MmJH7CjVntowyaY = Us2rOk4PLR0YW8g3jIqZS5()
	elif mode==525: APpdhB1Fk58MmJH7CjVntowyaY = bEyTUl7GWoePL()
	elif mode==526: APpdhB1Fk58MmJH7CjVntowyaY = JNs8fKPTIQRuCUAz2d6()
	elif mode==527: APpdhB1Fk58MmJH7CjVntowyaY = biE3wnCmakBqOFG()
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث بموسوعة السينما',WnNGfosHr5STAq8j7miwyRZ6eOUbV,519)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'موسوعة الأعمال',WnNGfosHr5STAq8j7miwyRZ6eOUbV,525)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'موسوعة الأشخاص',WnNGfosHr5STAq8j7miwyRZ6eOUbV,526)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'موسوعة المصنفات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,527)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'موسوعة المنوعات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,524)
	return
def Us2rOk4PLR0YW8g3jIqZS5():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' فيديوهات - خاصة',pcE6DxaoHBm41WKXjwnk+'/video',520)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فيديوهات - أحدث',pcE6DxaoHBm41WKXjwnk+'/video/latest',521)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فيديوهات - أقدم',pcE6DxaoHBm41WKXjwnk+'/video/oldest',521)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فيديوهات - أكثر مشاهدة',pcE6DxaoHBm41WKXjwnk+'/video/views',521)
	return
def bEyTUl7GWoePL():
	MRoblsu4gDTV26cxtdjIf087PE3rh = pcE6DxaoHBm41WKXjwnk+'/lineup?utf8=%E2%9C%93'
	wOB2j0rmQZNq7zgkh5U34uSosl9bPt = MRoblsu4gDTV26cxtdjIf087PE3rh+'&type=2&category=1&foreign=false&tag='
	FgqNteIzw60OmVYLQxTpDX8hr2cv = MRoblsu4gDTV26cxtdjIf087PE3rh+'&type=2&category=3&foreign=false&tag='
	xxDji9hpStNs0v4mnqZ5uBez = MRoblsu4gDTV26cxtdjIf087PE3rh+'&type=2&category=1&foreign=true&tag='
	wMn5j1OhcgbJyRidmpTQW3HPC = MRoblsu4gDTV26cxtdjIf087PE3rh+'&type=2&category=3&foreign=true&tag='
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات أفلام عربي',wOB2j0rmQZNq7zgkh5U34uSosl9bPt,511)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات مسلسلات عربي',FgqNteIzw60OmVYLQxTpDX8hr2cv,511)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات أفلام اجنبي',xxDji9hpStNs0v4mnqZ5uBez,511)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات مسلسلات اجنبي',wMn5j1OhcgbJyRidmpTQW3HPC,511)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس أعمال أبجدي',pcE6DxaoHBm41WKXjwnk+'/index/work/alphabet',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس  بلد الإنتاج',pcE6DxaoHBm41WKXjwnk+'/index/work/country',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس اللغة',pcE6DxaoHBm41WKXjwnk+'/index/work/language',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس مصنفات العمل',pcE6DxaoHBm41WKXjwnk+'/index/work/genre',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس سنة الإصدار',pcE6DxaoHBm41WKXjwnk+'/index/work/release_year',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مواسم - فلتر محدد',pcE6DxaoHBm41WKXjwnk+'/seasonals',515)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مواسم - فلتر كامل',pcE6DxaoHBm41WKXjwnk+'/seasonals',514)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات - فلتر محدد',pcE6DxaoHBm41WKXjwnk+'/lineup',515)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات - فلتر كامل',pcE6DxaoHBm41WKXjwnk+'/lineup',514)
	return
def biE3wnCmakBqOFG():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/lineup',WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	KDCdHQmgxPE21tYz4VUowSv = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find('select',attrs={'name':'tag'})
	xCONTFizaKbJS1 = KDCdHQmgxPE21tYz4VUowSv.find_all('option')
	for f4qbArVHeaCIiY5nzUR68dFBjsZ9 in xCONTFizaKbJS1:
		value = f4qbArVHeaCIiY5nzUR68dFBjsZ9.get('value')
		if not value: continue
		title = f4qbArVHeaCIiY5nzUR68dFBjsZ9.text
		if YVzokG2yZqrh3w8bU:
			title = title.encode(e87cIA5vwOQLDEP1)
			value = value.encode(e87cIA5vwOQLDEP1)
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,511)
	return
def JNs8fKPTIQRuCUAz2d6():
	MRoblsu4gDTV26cxtdjIf087PE3rh = pcE6DxaoHBm41WKXjwnk+'/lineup?utf8=%E2%9C%93'
	KEIxy6oPrvg5abj3 = MRoblsu4gDTV26cxtdjIf087PE3rh+'&type=1&category=&foreign=&tag='
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات أشخاص',KEIxy6oPrvg5abj3,511)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس أشخاص أبجدي',pcE6DxaoHBm41WKXjwnk+'/index/person/alphabet',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس موطن',pcE6DxaoHBm41WKXjwnk+'/index/person/nationality',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس  تاريخ الميلاد',pcE6DxaoHBm41WKXjwnk+'/index/person/birth_year',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فهرس  تاريخ الوفاة',pcE6DxaoHBm41WKXjwnk+'/index/person/death_year',517)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات - فلتر محدد',pcE6DxaoHBm41WKXjwnk+'/lineup',515)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مصنفات - فلتر كامل',pcE6DxaoHBm41WKXjwnk+'/lineup',514)
	return
def IdQgfnmvXrlZV4LDqb(url):
	if '/seasonals' in url: veLqt1DZI6N8a = 0
	elif '/lineup' in url: veLqt1DZI6N8a = 1
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-LISTS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all(class_='jumbo-theater clearfix')
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		title = KDCdHQmgxPE21tYz4VUowSv.find_all('a')[veLqt1DZI6N8a].text
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+KDCdHQmgxPE21tYz4VUowSv.find_all('a')[veLqt1DZI6N8a].get('href')
		if YVzokG2yZqrh3w8bU:
			title = title.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
		if not UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			Hbrwkox0p7jJu6XKlIAR3GCSs(SOw5EUxC9k)
			return
		else:
			title = title.replace('قائمة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,512)
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(VQTw6C4vPUKWmFuGE75MdfpncNreYg,511)
	return
def xxNgPGLoIwkY9a7WKC6bMtVRmZF(VQTw6C4vPUKWmFuGE75MdfpncNreYg,mode):
	KDCdHQmgxPE21tYz4VUowSv = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find(class_='pagination')
	if KDCdHQmgxPE21tYz4VUowSv:
		pHKuzOD7dM40FZsPAv68Y1V = KDCdHQmgxPE21tYz4VUowSv.find_all('a')
		ql1jtPWnDkYZFEJRd3 = KDCdHQmgxPE21tYz4VUowSv.find_all('li')
		O7Pgw2eoqtyD93Uvns = list(zip(pHKuzOD7dM40FZsPAv68Y1V,ql1jtPWnDkYZFEJRd3))
		zuEo6GDeAR5Z = -1
		fhcKbWMxykEYqRjpHoCg906D2u1rm = len(O7Pgw2eoqtyD93Uvns)
		for c6sSHKew8MFqkh7fDuAC24aBjnRXGp,UUq8vknj6e1CtwA in O7Pgw2eoqtyD93Uvns:
			zuEo6GDeAR5Z += 1
			UUq8vknj6e1CtwA = UUq8vknj6e1CtwA['class']
			if 'unavailable' in UUq8vknj6e1CtwA or 'current' in UUq8vknj6e1CtwA: continue
			Zf06rvhWgN3OPj2YTdeqU = c6sSHKew8MFqkh7fDuAC24aBjnRXGp.text
			ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = pcE6DxaoHBm41WKXjwnk+c6sSHKew8MFqkh7fDuAC24aBjnRXGp.get('href')
			if YVzokG2yZqrh3w8bU:
				Zf06rvhWgN3OPj2YTdeqU = Zf06rvhWgN3OPj2YTdeqU.encode(e87cIA5vwOQLDEP1)
				ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr.encode(e87cIA5vwOQLDEP1)
			if   zuEo6GDeAR5Z==0: Zf06rvhWgN3OPj2YTdeqU = 'أولى'
			elif zuEo6GDeAR5Z==1: Zf06rvhWgN3OPj2YTdeqU = 'سابقة'
			elif zuEo6GDeAR5Z==fhcKbWMxykEYqRjpHoCg906D2u1rm-2: Zf06rvhWgN3OPj2YTdeqU = 'لاحقة'
			elif zuEo6GDeAR5Z==fhcKbWMxykEYqRjpHoCg906D2u1rm-1: Zf06rvhWgN3OPj2YTdeqU = 'أخيرة'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+Zf06rvhWgN3OPj2YTdeqU,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,mode)
	return
def Hbrwkox0p7jJu6XKlIAR3GCSs(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-TITLES1-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all(class_='row')
	items,UUdGCM6DFuzKJ1eTkNhcR3jon = [],True
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		if not KDCdHQmgxPE21tYz4VUowSv.find(class_='thumbnail-wrapper'): continue
		if UUdGCM6DFuzKJ1eTkNhcR3jon: UUdGCM6DFuzKJ1eTkNhcR3jon = False ; continue
		ko8Q3zWLgC = []
		Jsq2M5y4KxwTBLHp9UAj1fhr3X = KDCdHQmgxPE21tYz4VUowSv.find_all(class_=['censorship red','censorship purple'])
		for kDRwSnL3OXEQdfGh7zaC in Jsq2M5y4KxwTBLHp9UAj1fhr3X:
			EEM4BOIPpHkDg5fm8lJnrbzs = kDRwSnL3OXEQdfGh7zaC.find_all('li')[1].text
			if YVzokG2yZqrh3w8bU:
				EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.encode(e87cIA5vwOQLDEP1)
			ko8Q3zWLgC.append(EEM4BOIPpHkDg5fm8lJnrbzs)
		if not e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ko8Q3zWLgC,False):
			bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('data-src')
			title = KDCdHQmgxPE21tYz4VUowSv.find('h3')
			name = title.find('a').text
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+title.find('a').get('href')
			amAUQ41COTzE7YZveu56h = KDCdHQmgxPE21tYz4VUowSv.find(class_='no-margin')
			yyHmdGloP4CSrZpX9FwvT38AgNeufR = KDCdHQmgxPE21tYz4VUowSv.find(class_='legend')
			if amAUQ41COTzE7YZveu56h: amAUQ41COTzE7YZveu56h = amAUQ41COTzE7YZveu56h.text
			if yyHmdGloP4CSrZpX9FwvT38AgNeufR: yyHmdGloP4CSrZpX9FwvT38AgNeufR = yyHmdGloP4CSrZpX9FwvT38AgNeufR.text
			if YVzokG2yZqrh3w8bU:
				bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.encode(e87cIA5vwOQLDEP1)
				name = name.encode(e87cIA5vwOQLDEP1)
				SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
				if amAUQ41COTzE7YZveu56h: amAUQ41COTzE7YZveu56h = amAUQ41COTzE7YZveu56h.encode(e87cIA5vwOQLDEP1)
			AUBZYG84NbOKsRnxi6jgk2f = {}
			if yyHmdGloP4CSrZpX9FwvT38AgNeufR: AUBZYG84NbOKsRnxi6jgk2f['stars'] = yyHmdGloP4CSrZpX9FwvT38AgNeufR
			if amAUQ41COTzE7YZveu56h:
				amAUQ41COTzE7YZveu56h = amAUQ41COTzE7YZveu56h.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,' .. ')
				AUBZYG84NbOKsRnxi6jgk2f['plot'] = amAUQ41COTzE7YZveu56h.replace('...اقرأ المزيد',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if '/work/' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,516,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f)
			elif '/person/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,513,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f)
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(VQTw6C4vPUKWmFuGE75MdfpncNreYg,512)
	return
def Zgy2ijr0oCSflAtT9P68aw(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-TITLES2-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all('li')
	NThwsPqGdZ72XFraUBLovl3,items = [],[]
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		if not KDCdHQmgxPE21tYz4VUowSv.find(class_='thumbnail-wrapper'): continue
		if not KDCdHQmgxPE21tYz4VUowSv.find(class_=['unstyled','unstyled text-center']): continue
		if KDCdHQmgxPE21tYz4VUowSv.find(class_='hide'): continue
		title = KDCdHQmgxPE21tYz4VUowSv.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in NThwsPqGdZ72XFraUBLovl3: continue
		NThwsPqGdZ72XFraUBLovl3.append(name)
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+title.find('a').get('href')
		if '/search/work/' in url: bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('src')
		elif '/search/person/' in url: bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('data-src')
		elif '/search/video/' in url: bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('data-src')
		else: bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('src')
		if YVzokG2yZqrh3w8bU:
			name = name.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
			bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.encode(e87cIA5vwOQLDEP1)
		name = name.strip(kcXMWrwiLDKeBHRsJ)
		items.append((name,SOw5EUxC9k,bLhqw36zAp7uKxJIM4r502UGRT))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,SOw5EUxC9k,bLhqw36zAp7uKxJIM4r502UGRT in items:
		if '/search/video/' in url: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,522,bLhqw36zAp7uKxJIM4r502UGRT)
		elif '/search/person/' in url: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,513,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,516,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name)
	return
def ez6gxMiPw8A3k5Jcys1KrjaXHdlGO7(text):
	text = text.replace('الإعلان',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('لفيلم',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('الرسمي',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace('إعلان',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('فيلم',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('البرومو',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace('التشويقي',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('لمسلسل',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('مسلسل',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace(':',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(')',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('(',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(',',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace('_',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(';',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('-',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('.',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace('\'',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('\"',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	text = text.replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	text = text.strip(kcXMWrwiLDKeBHRsJ)
	HHvVDfUWnoLC97qTKB3JOrj4mNgG0S = text.count(kcXMWrwiLDKeBHRsJ)+1
	if HHvVDfUWnoLC97qTKB3JOrj4mNgG0S==1:
		XERnz4IbBSNdHy6eYD2813c(text)
		return
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+e6HEdvUcaq8Gx+'==== كلمات للبحث ===='+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	CCRIEG4BhXVvwbPolH9NDdgikqY3 = text.split(kcXMWrwiLDKeBHRsJ)
	EXuib8rmDtTAxUSan = pow(2,HHvVDfUWnoLC97qTKB3JOrj4mNgG0S)
	Ru1bX8NzfGUYxEtlZVk6rwLH7 = []
	def r58z2InmDA0hg6acRiNV3q9eJysx(SsbduzmRPEIpN5xg1kZviGetJAO,d4mM7W5uXUF6oSgO):
		if SsbduzmRPEIpN5xg1kZviGetJAO=='1': return d4mM7W5uXUF6oSgO
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for zuEo6GDeAR5Z in range(EXuib8rmDtTAxUSan,0,-1):
		pe0Q67VRIBvrg9cEL8nzTJqlYb5 = list(HHvVDfUWnoLC97qTKB3JOrj4mNgG0S*'0'+bin(zuEo6GDeAR5Z)[2:])[-HHvVDfUWnoLC97qTKB3JOrj4mNgG0S:]
		pe0Q67VRIBvrg9cEL8nzTJqlYb5 = reversed(pe0Q67VRIBvrg9cEL8nzTJqlYb5)
		U2vri4t3a8S = map(r58z2InmDA0hg6acRiNV3q9eJysx,pe0Q67VRIBvrg9cEL8nzTJqlYb5,CCRIEG4BhXVvwbPolH9NDdgikqY3)
		title = kcXMWrwiLDKeBHRsJ.join(filter(None,U2vri4t3a8S))
		if YVzokG2yZqrh3w8bU: gPvxJw89S35R21zDIbpFYkq7A = title.decode(e87cIA5vwOQLDEP1)
		else: gPvxJw89S35R21zDIbpFYkq7A = title
		if len(gPvxJw89S35R21zDIbpFYkq7A)>2 and title not in Ru1bX8NzfGUYxEtlZVk6rwLH7:
			Ru1bX8NzfGUYxEtlZVk6rwLH7.append(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,523,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,title)
	return
def XERnz4IbBSNdHy6eYD2813c(X8MZ2ylw71DxTsB4iqr3tg6):
	if YVzokG2yZqrh3w8bU:
		X8MZ2ylw71DxTsB4iqr3tg6 = X8MZ2ylw71DxTsB4iqr3tg6.decode(e87cIA5vwOQLDEP1)
		import arabic_reshaper as mf9tHy0bNnCIh3ZTOSeQiLvM2Ycp,bidi.algorithm as IaP1Ryqv2Z3x
		X8MZ2ylw71DxTsB4iqr3tg6 = mf9tHy0bNnCIh3ZTOSeQiLvM2Ycp.ArabicReshaper().reshape(X8MZ2ylw71DxTsB4iqr3tg6)
		X8MZ2ylw71DxTsB4iqr3tg6 = IaP1Ryqv2Z3x.get_display(X8MZ2ylw71DxTsB4iqr3tg6)
	import IV2oTbWpv9
	X8MZ2ylw71DxTsB4iqr3tg6 = x6S4MmiIE1hJ5bWUtdG02azC9Dgu(Y5OUcxSIr4gLBs=X8MZ2ylw71DxTsB4iqr3tg6)
	IV2oTbWpv9.WmxfGFqceOyUtLT(X8MZ2ylw71DxTsB4iqr3tg6)
	return
def gv9u8NlJfaZWkGHM0c3yxbmpTU7Iw(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-INDEXES_LISTS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	KDCdHQmgxPE21tYz4VUowSv = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find(class_='list-separator list-title')
	trNPCKLEgm = KDCdHQmgxPE21tYz4VUowSv.find_all('a')
	items = []
	for title in trNPCKLEgm:
		name = title.text
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+title.get('href')
		if YVzokG2yZqrh3w8bU:
			name = name.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
		if '#' not in SOw5EUxC9k: items.append((name,SOw5EUxC9k))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for N6NV3h4fel in items:
		name,SOw5EUxC9k = N6NV3h4fel
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,518)
	return
def GGvEsYTpCh23jmfabw1RDiFlruUkA(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-INDEXES_TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find(class_='expand').find_all('tr')
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		li62AbtOcYhN7JfU = KDCdHQmgxPE21tYz4VUowSv.find_all('a')
		if not li62AbtOcYhN7JfU: continue
		bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('data-src')
		name = li62AbtOcYhN7JfU[1].text
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+li62AbtOcYhN7JfU[1].get('href')
		yyHmdGloP4CSrZpX9FwvT38AgNeufR = KDCdHQmgxPE21tYz4VUowSv.find(class_='legend')
		if yyHmdGloP4CSrZpX9FwvT38AgNeufR: yyHmdGloP4CSrZpX9FwvT38AgNeufR = yyHmdGloP4CSrZpX9FwvT38AgNeufR.text
		if YVzokG2yZqrh3w8bU:
			name = name.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
			bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.encode(e87cIA5vwOQLDEP1)
		AUBZYG84NbOKsRnxi6jgk2f = {}
		if yyHmdGloP4CSrZpX9FwvT38AgNeufR: AUBZYG84NbOKsRnxi6jgk2f['stars'] = yyHmdGloP4CSrZpX9FwvT38AgNeufR
		if '/work/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,516,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f)
		elif '/person/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,513,bLhqw36zAp7uKxJIM4r502UGRT,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f)
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(VQTw6C4vPUKWmFuGE75MdfpncNreYg,518)
	return
def Zg3hFlUd46J8SKWOkMwv(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-VIDEOS_LISTS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	trNPCKLEgm = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all(class_='section-title inline')
	laAHpo1bzyM0q = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all(class_='button green small right')
	items = zip(trNPCKLEgm,laAHpo1bzyM0q)
	for title,SOw5EUxC9k in items:
		title = title.text
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k.get('href')
		if YVzokG2yZqrh3w8bU:
			title = title.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
		title = title.replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,521)
	return
def fft5robNav(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-VIDEOS_TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	r6MyELQeHIlOXiUwvn8x2JbPo = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = r6MyELQeHIlOXiUwvn8x2JbPo.find_all('li')
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		title = KDCdHQmgxPE21tYz4VUowSv.find(class_='title').text
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+KDCdHQmgxPE21tYz4VUowSv.find('a').get('href')
		bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv.find('img').get('data-src')
		gJVpmQ1oYbrkHaKnS4N3v2z = KDCdHQmgxPE21tYz4VUowSv.find(class_='duration').text
		if YVzokG2yZqrh3w8bU:
			title = title.encode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
			bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.encode(e87cIA5vwOQLDEP1)
			gJVpmQ1oYbrkHaKnS4N3v2z = gJVpmQ1oYbrkHaKnS4N3v2z.encode(e87cIA5vwOQLDEP1)
		gJVpmQ1oYbrkHaKnS4N3v2z = gJVpmQ1oYbrkHaKnS4N3v2z.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,522,bLhqw36zAp7uKxJIM4r502UGRT,gJVpmQ1oYbrkHaKnS4N3v2z)
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(VQTw6C4vPUKWmFuGE75MdfpncNreYg,521)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	SOw5EUxC9k = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find(class_='flex-video').find('iframe').get('src')
	if YVzokG2yZqrh3w8bU: SOw5EUxC9k = SOw5EUxC9k.encode(e87cIA5vwOQLDEP1)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L([SOw5EUxC9k],NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	url = pcE6DxaoHBm41WKXjwnk+'/search/?q='+search
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-SEARCH-1st')
	if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
		KEIxy6oPrvg5abj3 = pcE6DxaoHBm41WKXjwnk+'/search_entity/?q='+search+'&entity=work'
		ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = pcE6DxaoHBm41WKXjwnk+'/search_entity/?q='+search+'&entity=person'
		QkgzytZRFhp0HsTAeo72xSKC9GwV1 = pcE6DxaoHBm41WKXjwnk+'/search_entity/?q='+search+'&entity=video'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن أعمال',KEIxy6oPrvg5abj3,513,WnNGfosHr5STAq8j7miwyRZ6eOUbV,search)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن أشخاص',ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,513,WnNGfosHr5STAq8j7miwyRZ6eOUbV,search)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن فيديوهات',QkgzytZRFhp0HsTAeo72xSKC9GwV1,513,WnNGfosHr5STAq8j7miwyRZ6eOUbV,search)
		return
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VQTw6C4vPUKWmFuGE75MdfpncNreYg = hLC3KQBHqskr4n.BeautifulSoup(piN9Qlah4S,'html.parser',multi_valued_attributes=None)
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VQTw6C4vPUKWmFuGE75MdfpncNreYg.find_all(class_='section-title left')
	for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		title = KDCdHQmgxPE21tYz4VUowSv.text
		if YVzokG2yZqrh3w8bU:
			title = title.encode(e87cIA5vwOQLDEP1)
		title = title.split('(',1)[0].strip(kcXMWrwiLDKeBHRsJ)
		if   'أعمال' in title: SOw5EUxC9k = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: SOw5EUxC9k = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: SOw5EUxC9k = url.replace('/search/','/search/video/')
		else: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,513)
	return
def iixL6ryhDO1X7Ke0gHnauGE(url,text):
	global tqgKeQMz5XNvBPZAE6DCxfaLbj,wQyTn0NR9VkaBSCrDzPsqMl
	if '/seasonals' in url:
		tqgKeQMz5XNvBPZAE6DCxfaLbj = ['seasonal','year','category']
		wQyTn0NR9VkaBSCrDzPsqMl = ['seasonal','year','category']
	elif '/lineup' in url:
		tqgKeQMz5XNvBPZAE6DCxfaLbj = ['category','foreign','type']
		wQyTn0NR9VkaBSCrDzPsqMl = ['category','foreign','type']
	O40uMkKs5x6zmP9eFjnSbU(url,text)
	return
def J87GLvYrDtMFUo9R6OuEyhi1zC3(url):
	url = url.split('/smartemadfilter?')[0]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('form action="/(.*?)</form>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return ZudC8bDqo4mM5c7GfP96Qy2F
def sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv):
	items = p7dwlH1PRStBgyMUW.findall('<option value="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return items
def tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url):
	q16smZkWvE = url.split('/smartemadfilter?')[0]
	HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def wo5RC1KmfZFSB(A5AHnwB1MJQ4O,url):
	CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'all_filters')
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
	return QQTfhlZEDnu4wVcOeHGNyCBo5t2
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	elif type=='ALL_ITEMS_FILTER':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'/smartemadfilter?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',vcQbFfCk6T1,511)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,511)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ZudC8bDqo4mM5c7GfP96Qy2F = J87GLvYrDtMFUo9R6OuEyhi1zC3(url)
	dict = {}
	for name,LgJITEZU95fS2oi8K,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		name = name.replace('--',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		items = sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='SPECIFIED_FILTER':
			if LgJITEZU95fS2oi8K not in tqgKeQMz5XNvBPZAE6DCxfaLbj: continue
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<2:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]:
					url = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url)
					Hbrwkox0p7jJu6XKlIAR3GCSs(url)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'SPECIFIED_FILTER___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,511)
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,515,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='ALL_ITEMS_FILTER':
			if LgJITEZU95fS2oi8K not in wQyTn0NR9VkaBSCrDzPsqMl: continue
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع: '+name,vcQbFfCk6T1,514,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if 'مصنفات أخرى' in f4qbArVHeaCIiY5nzUR68dFBjsZ9: continue
			if 'الكل' in f4qbArVHeaCIiY5nzUR68dFBjsZ9: continue
			if 'اللغة' in f4qbArVHeaCIiY5nzUR68dFBjsZ9: continue
			f4qbArVHeaCIiY5nzUR68dFBjsZ9 = f4qbArVHeaCIiY5nzUR68dFBjsZ9.replace('قائمة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			if name: title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'+name
			else: title = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			if type=='ALL_ITEMS_FILTER': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,514,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='SPECIFIED_FILTER' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = wo5RC1KmfZFSB(A5AHnwB1MJQ4O,url)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,511)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,515,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.replace('=&','=0&')
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all_filters': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	CZewXSEQ3q = CZewXSEQ3q.replace('=0','=')
	return CZewXSEQ3q
tqgKeQMz5XNvBPZAE6DCxfaLbj = []
wQyTn0NR9VkaBSCrDzPsqMl = []