# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'GOOGLESEARCH'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_GOS_'
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==1010: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1011: APpdhB1Fk58MmJH7CjVntowyaY = oWg0Bj4Edbt(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1012: APpdhB1Fk58MmJH7CjVntowyaY = t346ZwVx59UWNvD(uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1013: APpdhB1Fk58MmJH7CjVntowyaY = FBZsxGOhyX()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1014: APpdhB1Fk58MmJH7CjVntowyaY = zDh1LT9YEn0VkKOslaoPW(uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1015: APpdhB1Fk58MmJH7CjVntowyaY = GbTs7zLkXnr4h2JWf6uodmx(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1016: APpdhB1Fk58MmJH7CjVntowyaY = SSgNHUcbwt(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1018: APpdhB1Fk58MmJH7CjVntowyaY = iopfTVAGKUNZWbF9JjR1mHL(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==1019: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(ZVk6IphECKLzUceP15j,False)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','بحث جوجل جديد',WnNGfosHr5STAq8j7miwyRZ6eOUbV,1019)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link','كيف يعمل بحث جوجل','',1013)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'==== كلمات البحث المخزنة ===='+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	EVnDz2PKOwWkGo = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if EVnDz2PKOwWkGo:
		EVnDz2PKOwWkGo = EVnDz2PKOwWkGo['__SEQUENCED_COLUMNS__']
		for lU2oX9uKy8AGw60I4vzV7e in reversed(EVnDz2PKOwWkGo):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',lU2oX9uKy8AGw60I4vzV7e,WnNGfosHr5STAq8j7miwyRZ6eOUbV,1019,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lU2oX9uKy8AGw60I4vzV7e)
	return
def iopfTVAGKUNZWbF9JjR1mHL(search):
	WmxfGFqceOyUtLT(search,True)
	YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def WmxfGFqceOyUtLT(search,rmVOdFBjl4a=False):
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	X8MZ2ylw71DxTsB4iqr3tg6 = search.replace(uBQ9txp0gDrEhZTcJOi74SKVw3k,WnNGfosHr5STAq8j7miwyRZ6eOUbV).lower()
	JXxsOk9tj1fcavQhFu3D,mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = [],[],[]
	if not rmVOdFBjl4a:
		JXxsOk9tj1fcavQhFu3D = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GOOGLESEARCH_RESULTS',X8MZ2ylw71DxTsB4iqr3tg6)
		if JXxsOk9tj1fcavQhFu3D: mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = JXxsOk9tj1fcavQhFu3D
	if rmVOdFBjl4a or not JXxsOk9tj1fcavQhFu3D:
		import IV2oTbWpv9
		IV2oTbWpv9.zOFUERr2e4jWT3K7oqk6(X8MZ2ylw71DxTsB4iqr3tg6,'_GOOGLE',True)
		EfH9ywRMoPOZFxI = WLkiYDwEbBX(X8MZ2ylw71DxTsB4iqr3tg6)
		for N6NV3h4fel in EfH9ywRMoPOZFxI:
			name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 = N6NV3h4fel
			if OOG1iPYhTKQ4 in bcuvN3jdY2gWDy09HAnf: mfsFQMqA64dWKBxtL1kwp7IRgj.append(N6NV3h4fel)
			else: aeCTjmf9D7bocFSWGykzRw4Md3n.append(N6NV3h4fel)
		mfsFQMqA64dWKBxtL1kwp7IRgj = sorted(mfsFQMqA64dWKBxtL1kwp7IRgj,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		aeCTjmf9D7bocFSWGykzRw4Md3n = sorted(aeCTjmf9D7bocFSWGykzRw4Md3n,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
		w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'GOOGLESEARCH_RESULTS',X8MZ2ylw71DxTsB4iqr3tg6,[mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n],T0le9tWJd7IAfKH1rNGB)
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DETAILED_GOOGLE',X8MZ2ylw71DxTsB4iqr3tg6)
		IV2oTbWpv9.zOFUERr2e4jWT3K7oqk6(X8MZ2ylw71DxTsB4iqr3tg6,'_GOOGLE',False)
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+X8MZ2ylw71DxTsB4iqr3tg6+"')")
		if mfsFQMqA64dWKBxtL1kwp7IRgj: BGQXvd2lsicjVTgnHYRo74qDI3z('','',Ew26Hg4SIj,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(mfsFQMqA64dWKBxtL1kwp7IRgj))+'  مواقع')
		else: mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = rDMFi0zZPXwTh7H1v(X8MZ2ylw71DxTsB4iqr3tg6,KiryBCvngZzF85UN6xSDlOVweL4I9)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','بحث منفرد لمواقع جوجل',WnNGfosHr5STAq8j7miwyRZ6eOUbV,1011,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','نتائج البحث مفصلة - '+X8MZ2ylw71DxTsB4iqr3tg6,'opened_sites_google',1012,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','نتائج البحث مقسمة - '+X8MZ2ylw71DxTsB4iqr3tg6,'listed_sites_google',1012,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','مواقع جوجل ('+str(len(mfsFQMqA64dWKBxtL1kwp7IRgj))+') - '+X8MZ2ylw71DxTsB4iqr3tg6,'',1016,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,X8MZ2ylw71DxTsB4iqr3tg6)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link','إعادة بحث جوجل - '+X8MZ2ylw71DxTsB4iqr3tg6,'',1018,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,search)
	return
def SSgNHUcbwt(X8MZ2ylw71DxTsB4iqr3tg6):
	mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = rDMFi0zZPXwTh7H1v(X8MZ2ylw71DxTsB4iqr3tg6)
	if not mfsFQMqA64dWKBxtL1kwp7IRgj and not aeCTjmf9D7bocFSWGykzRw4Md3n: return
	wEkeF4WDdQzn8m79JtrZAb0qPp = {}
	for name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 in mfsFQMqA64dWKBxtL1kwp7IRgj: wEkeF4WDdQzn8m79JtrZAb0qPp[OOG1iPYhTKQ4] = name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4
	GoYAvNrxwJMTy = list(wEkeF4WDdQzn8m79JtrZAb0qPp.keys())
	import IV2oTbWpv9
	VJsfON9jQRL4uXD8z2tw3TKyZY = IV2oTbWpv9.JFQSI5HUeNn7TOCsdzwPbpMrlx6Riu(GoYAvNrxwJMTy)
	for OOG1iPYhTKQ4 in VJsfON9jQRL4uXD8z2tw3TKyZY:
		if isinstance(OOG1iPYhTKQ4,tuple):
			A3pXVFdyP1.menuItemsLIST.append(OOG1iPYhTKQ4)
			continue
		name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 = wEkeF4WDdQzn8m79JtrZAb0qPp[OOG1iPYhTKQ4]
		PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qr61ZvHTdEjIShcBis+name,SOw5EUxC9k,1014,CCSTU4jJtm5VLfwFzn,'',OOG1iPYhTKQ4)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+'مواقع بجوجل غير موجودة بالبرنامج'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,1015)
	aeCTjmf9D7bocFSWGykzRw4Md3n = sorted(aeCTjmf9D7bocFSWGykzRw4Md3n,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
	for name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 in aeCTjmf9D7bocFSWGykzRw4Md3n:
		octplHnGwmE8bFqNdj7BiKvJ0VL('link','_GOS_'+name,SOw5EUxC9k,1015,CCSTU4jJtm5VLfwFzn,'',OOG1iPYhTKQ4)
	return
def rDMFi0zZPXwTh7H1v(X8MZ2ylw71DxTsB4iqr3tg6,UvEK9Nfrw8=r0D4C3z7Onqpa):
	mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = [],[]
	if UvEK9Nfrw8:
		JXxsOk9tj1fcavQhFu3D = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GOOGLESEARCH_RESULTS',X8MZ2ylw71DxTsB4iqr3tg6)
		if JXxsOk9tj1fcavQhFu3D: mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = JXxsOk9tj1fcavQhFu3D
	if not mfsFQMqA64dWKBxtL1kwp7IRgj and not aeCTjmf9D7bocFSWGykzRw4Md3n: BGQXvd2lsicjVTgnHYRo74qDI3z('','',Ew26Hg4SIj,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n
def t346ZwVx59UWNvD(qPMYyhbEXuoJNUl3gfLHV0I,X8MZ2ylw71DxTsB4iqr3tg6):
	mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = rDMFi0zZPXwTh7H1v(X8MZ2ylw71DxTsB4iqr3tg6)
	if not mfsFQMqA64dWKBxtL1kwp7IRgj and not aeCTjmf9D7bocFSWGykzRw4Md3n: return
	Z3YnB7Eij9z5Qg,U9H7devmxwDXScCZTnY5aW0j = [],{}
	for name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 in mfsFQMqA64dWKBxtL1kwp7IRgj:
		Z3YnB7Eij9z5Qg.append(OOG1iPYhTKQ4)
		U9H7devmxwDXScCZTnY5aW0j[OOG1iPYhTKQ4] = wWOfIxkaJt97FYdp(text)
	import IV2oTbWpv9
	IV2oTbWpv9.rIXAgwunRT3sQkjqfFcNop6z(X8MZ2ylw71DxTsB4iqr3tg6,qPMYyhbEXuoJNUl3gfLHV0I,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z3YnB7Eij9z5Qg,U9H7devmxwDXScCZTnY5aW0j)
	return
def oWg0Bj4Edbt(X8MZ2ylw71DxTsB4iqr3tg6):
	mfsFQMqA64dWKBxtL1kwp7IRgj,aeCTjmf9D7bocFSWGykzRw4Md3n = rDMFi0zZPXwTh7H1v(X8MZ2ylw71DxTsB4iqr3tg6)
	if not mfsFQMqA64dWKBxtL1kwp7IRgj and not aeCTjmf9D7bocFSWGykzRw4Md3n: return
	wEkeF4WDdQzn8m79JtrZAb0qPp = {}
	for name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 in mfsFQMqA64dWKBxtL1kwp7IRgj:
		wEkeF4WDdQzn8m79JtrZAb0qPp[OOG1iPYhTKQ4] = name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4
	GoYAvNrxwJMTy = list(wEkeF4WDdQzn8m79JtrZAb0qPp.keys())
	import IV2oTbWpv9
	VJsfON9jQRL4uXD8z2tw3TKyZY = IV2oTbWpv9.JFQSI5HUeNn7TOCsdzwPbpMrlx6Riu(GoYAvNrxwJMTy)
	for OOG1iPYhTKQ4 in VJsfON9jQRL4uXD8z2tw3TKyZY:
		if isinstance(OOG1iPYhTKQ4,tuple):
			A3pXVFdyP1.menuItemsLIST.append(OOG1iPYhTKQ4)
			continue
		name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4 = wEkeF4WDdQzn8m79JtrZAb0qPp[OOG1iPYhTKQ4]
		PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
		text = wWOfIxkaJt97FYdp(text)
		name = name+' - '+X8MZ2ylw71DxTsB4iqr3tg6
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qr61ZvHTdEjIShcBis+name,OOG1iPYhTKQ4,548,CCSTU4jJtm5VLfwFzn,'',text)
	return
def wWOfIxkaJt97FYdp(title):
	er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة)',title,p7dwlH1PRStBgyMUW.DOTALL)
	gPvxJw89S35R21zDIbpFYkq7A = er96jwp52cbvaV48mtylEYSRz[0][0] if er96jwp52cbvaV48mtylEYSRz else title
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return gPvxJw89S35R21zDIbpFYkq7A
def WLkiYDwEbBX(search):
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	vcQbFfCk6T1 = url+'&start=0&num=100&tbm=vid&udm=7'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'GOOGLESEARCH-SEARCH-1st')
	if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded: return []
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	yqaKbRTOJe = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(Hp7qgMcFCX46nO8Poy,'googlesearch')
	if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(yqaKbRTOJe):
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.makedirs(yqaKbRTOJe)
		except: pass
	items = []
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if UOqp25uxcISGBPlAfbtzCNWXY4nvK:
		for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			SOw5EUxC9k,title,text,bLhqw36zAp7uKxJIM4r502UGRT,name = KDCdHQmgxPE21tYz4VUowSv
			bLhqw36zAp7uKxJIM4r502UGRT = ''
			items.append([SOw5EUxC9k,title,text,name,bLhqw36zAp7uKxJIM4r502UGRT])
	else:
		vcQbFfCk6T1 = url+'&start=0&num=200'
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET::SCRAPERS',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'GOOGLESEARCH-SEARCH-2nd')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded: return []
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not UOqp25uxcISGBPlAfbtzCNWXY4nvK: UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			KDCdHQmgxPE21tYz4VUowSv = IXZpzK7ShaRsAN('list',KDCdHQmgxPE21tYz4VUowSv)
			if len(KDCdHQmgxPE21tYz4VUowSv)>17:
				SOw5EUxC9k = KDCdHQmgxPE21tYz4VUowSv[17]
				title,text,name,bLhqw36zAp7uKxJIM4r502UGRT = KDCdHQmgxPE21tYz4VUowSv[31][0:4]
				items.append([SOw5EUxC9k,title,text,name,bLhqw36zAp7uKxJIM4r502UGRT])
	ThPutWceQolJRngLI04VEj5,RGorg7q6bU4ckpX = [],[]
	for N6NV3h4fel in items:
		SOw5EUxC9k,title,text,name,bLhqw36zAp7uKxJIM4r502UGRT = N6NV3h4fel
		name = name.strip(' ')
		if not name: name = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
		name = WQzfBPt6sDuVw8N5xlcY(name)
		if 'http://' in bLhqw36zAp7uKxJIM4r502UGRT or 'https://' in bLhqw36zAp7uKxJIM4r502UGRT: CCSTU4jJtm5VLfwFzn = bLhqw36zAp7uKxJIM4r502UGRT
		elif 'data:image/' in bLhqw36zAp7uKxJIM4r502UGRT and ';base64,' in bLhqw36zAp7uKxJIM4r502UGRT:
			kkIRel2x0Wg = p7dwlH1PRStBgyMUW.findall('data:image/(\w+);base64,',bLhqw36zAp7uKxJIM4r502UGRT)
			kkIRel2x0Wg = kkIRel2x0Wg[0]
			CCSTU4jJtm5VLfwFzn = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(yqaKbRTOJe,name+'.'+kkIRel2x0Wg)
			if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(CCSTU4jJtm5VLfwFzn):
				bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.replace('\\u003d','=')
				bLhqw36zAp7uKxJIM4r502UGRT = bLhqw36zAp7uKxJIM4r502UGRT.replace('data:image/'+kkIRel2x0Wg+';base64,','')
				GjeFo5ZOwcRWtTmrL = uvGCPpFwVmTQ36.b64decode(bLhqw36zAp7uKxJIM4r502UGRT)
				open(CCSTU4jJtm5VLfwFzn,'wb').write(GjeFo5ZOwcRWtTmrL)
		else: CCSTU4jJtm5VLfwFzn = ''
		OOG1iPYhTKQ4 = enlFU5OfRKj1QzCGcYNWkPoXdhwgxb(name,SOw5EUxC9k)
		if OOG1iPYhTKQ4 not in RGorg7q6bU4ckpX:
			RGorg7q6bU4ckpX.append(OOG1iPYhTKQ4)
			name = v2oRq5AhQzcx(OOG1iPYhTKQ4)
			ThPutWceQolJRngLI04VEj5.append([name,SOw5EUxC9k,title,text,CCSTU4jJtm5VLfwFzn,OOG1iPYhTKQ4])
	return ThPutWceQolJRngLI04VEj5
def zDh1LT9YEn0VkKOslaoPW(SOw5EUxC9k,OOG1iPYhTKQ4):
	PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
	if qr61ZvHTdEjIShcBis: PVIqN8MGBf7DX3TjdA1Qh9gOU()
	else: GbTs7zLkXnr4h2JWf6uodmx()
	return
def FBZsxGOhyX():
	BGQXvd2lsicjVTgnHYRo74qDI3z('','',Ew26Hg4SIj,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def GbTs7zLkXnr4h2JWf6uodmx(OOG1iPYhTKQ4=''):
	BGQXvd2lsicjVTgnHYRo74qDI3z('','',OOG1iPYhTKQ4,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def enlFU5OfRKj1QzCGcYNWkPoXdhwgxb(name,SOw5EUxC9k):
	E1texm8FsVCLag0O3wd4jAB = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	Zf06rvhWgN3OPj2YTdeqU = name.lower()
	U2vri4t3a8S = ''
	for key in list(E1texm8FsVCLag0O3wd4jAB.keys()):
		if key.lower() in Zf06rvhWgN3OPj2YTdeqU: U2vri4t3a8S = E1texm8FsVCLag0O3wd4jAB[key]
	if not U2vri4t3a8S:
		ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'url')
		for OOG1iPYhTKQ4 in list(A3pXVFdyP1.SITESURLS.keys()):
			QkgzytZRFhp0HsTAeo72xSKC9GwV1 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(A3pXVFdyP1.SITESURLS[OOG1iPYhTKQ4][0],'url')
			if ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr==QkgzytZRFhp0HsTAeo72xSKC9GwV1: U2vri4t3a8S = OOG1iPYhTKQ4
	if not U2vri4t3a8S:
		Zf06rvhWgN3OPj2YTdeqU = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
		for OOG1iPYhTKQ4 in list(A3pXVFdyP1.SITESURLS.keys()):
			q4MTWSoVeCKru7s5D = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(A3pXVFdyP1.SITESURLS[OOG1iPYhTKQ4][0],'name')
			if Zf06rvhWgN3OPj2YTdeqU==q4MTWSoVeCKru7s5D: U2vri4t3a8S = OOG1iPYhTKQ4
	if not U2vri4t3a8S: U2vri4t3a8S = name
	U2vri4t3a8S = U2vri4t3a8S.upper()
	return U2vri4t3a8S