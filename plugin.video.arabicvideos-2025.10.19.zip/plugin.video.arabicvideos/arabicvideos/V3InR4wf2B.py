# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SHOOFMAX'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SHM_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
wwmXPdcfpo = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][1]
jFaJ2ULfqTCxWOz8gYZS = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][2]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==50: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==51: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==52: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==53: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==55: APpdhB1Fk58MmJH7CjVntowyaY = N3OJPpzFGw()
	elif mode==56: APpdhB1Fk58MmJH7CjVntowyaY = Yd9RQg72vSx()
	elif mode==57: APpdhB1Fk58MmJH7CjVntowyaY = IVudfRLF0xhc1kotSw65M(url,1)
	elif mode==58: APpdhB1Fk58MmJH7CjVntowyaY = IVudfRLF0xhc1kotSw65M(url,2)
	elif mode==59: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,59,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المسلسلات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,56)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الافلام',WnNGfosHr5STAq8j7miwyRZ6eOUbV,55)
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV
def N3OJPpzFGw():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أفلام مرتبة بسنة الإنتاج',pcE6DxaoHBm41WKXjwnk+'/movie/1/yop',57)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أفلام مرتبة بالأفضل تقييم',pcE6DxaoHBm41WKXjwnk+'/movie/1/review',57)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أفلام مرتبة بالأكثر مشاهدة',pcE6DxaoHBm41WKXjwnk+'/movie/1/views',57)
	return
def Yd9RQg72vSx():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مرتبة بسنة الإنتاج',pcE6DxaoHBm41WKXjwnk+'/series/1/yop',57)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مرتبة بالأفضل تقييم',pcE6DxaoHBm41WKXjwnk+'/series/1/review',57)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مرتبة بالأكثر مشاهدة',pcE6DxaoHBm41WKXjwnk+'/series/1/views',57)
	return
def ctDj2OVRyaUPXCrITmJG(url):
	if '?' in url:
		ipdI4Kw1lMauxrtYoh = url.split('?')
		url = ipdI4Kw1lMauxrtYoh[0]
		filter = '?' + ZisgmEGCOJxVI9DcetNBPo6(ipdI4Kw1lMauxrtYoh[1],'=&:/%')
	else: filter = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	type,TB3DI4JWr0NYmik1xO8Kc2,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': O7OfPtkgBD42QoeqIUHKJMm9R53bjN='فيلم'
		elif type=='series': O7OfPtkgBD42QoeqIUHKJMm9R53bjN='مسلسل'
		url = pcE6DxaoHBm41WKXjwnk + '/genre/filter/' + ZisgmEGCOJxVI9DcetNBPo6(O7OfPtkgBD42QoeqIUHKJMm9R53bjN) + '/' + TB3DI4JWr0NYmik1xO8Kc2 + '/' + sort + filter
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-TITLES-1st')
		items = p7dwlH1PRStBgyMUW.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		G0WRE9w7is4TVPANyDgIJYjmOMZnLa=0
		for id,title,X4M2OkeFQCz1s,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
			J4tO21KYAVdSr67W5NmiD0XhRP = jFaJ2ULfqTCxWOz8gYZS + '/v2/img/program/main/' + J4tO21KYAVdSr67W5NmiD0XhRP + '-2.jpg'
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk + '/program/' + id
			if type=='movie': octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,53,J4tO21KYAVdSr67W5NmiD0XhRP)
			if type=='series': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسل '+title,SOw5EUxC9k+'?ep='+X4M2OkeFQCz1s+'='+title+'='+J4tO21KYAVdSr67W5NmiD0XhRP,52,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		if type=='movie': O7OfPtkgBD42QoeqIUHKJMm9R53bjN='movies'
		elif type=='series': O7OfPtkgBD42QoeqIUHKJMm9R53bjN='series'
		url = wwmXPdcfpo + '/json/selected/' + sort + '-' + O7OfPtkgBD42QoeqIUHKJMm9R53bjN + '-WW.json'
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-TITLES-2nd')
		items = p7dwlH1PRStBgyMUW.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		G0WRE9w7is4TVPANyDgIJYjmOMZnLa=0
		for id,X4M2OkeFQCz1s,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			G0WRE9w7is4TVPANyDgIJYjmOMZnLa += 1
			J4tO21KYAVdSr67W5NmiD0XhRP = wwmXPdcfpo + '/img/program/' + J4tO21KYAVdSr67W5NmiD0XhRP + '-2.jpg'
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk + '/program/' + id
			if type=='movie': octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,53,J4tO21KYAVdSr67W5NmiD0XhRP)
			elif type=='series': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسل '+title,SOw5EUxC9k+'?ep='+X4M2OkeFQCz1s+'='+title+'='+J4tO21KYAVdSr67W5NmiD0XhRP,52,J4tO21KYAVdSr67W5NmiD0XhRP)
	title='صفحة '
	if G0WRE9w7is4TVPANyDgIJYjmOMZnLa==16:
		for kwcTvZPuNd7 in range(1,13) :
			if not TB3DI4JWr0NYmik1xO8Kc2==str(kwcTvZPuNd7):
				url = pcE6DxaoHBm41WKXjwnk+'/genre/filter/'+type+'/'+str(kwcTvZPuNd7)+'/'+sort+filter
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title+str(kwcTvZPuNd7),url,51)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	ipdI4Kw1lMauxrtYoh = url.split('=')
	X4M2OkeFQCz1s = int(ipdI4Kw1lMauxrtYoh[1])
	name = EZk136aeLoNqPvlDcTQpyM9Wm(ipdI4Kw1lMauxrtYoh[2])
	name = name.replace('_MOD_مسلسل ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	J4tO21KYAVdSr67W5NmiD0XhRP = ipdI4Kw1lMauxrtYoh[3]
	url = url.split('?')[0]
	if X4M2OkeFQCz1s==0:
		piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-EPISODES-1st')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<select(.*?)</select>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('option value="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		X4M2OkeFQCz1s = int(items[-1])
	for er96jwp52cbvaV48mtylEYSRz in range(X4M2OkeFQCz1s,0,-1):
		SOw5EUxC9k = url + '?ep=' + str(er96jwp52cbvaV48mtylEYSRz)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(er96jwp52cbvaV48mtylEYSRz)
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,53,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-PLAY-1st')
	gUybxJOPGCstZXi2 = p7dwlH1PRStBgyMUW.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gUybxJOPGCstZXi2:
		x54xSdnCFHZ8yliofzOBK = gUybxJOPGCstZXi2[1].replace('T',EVdNGw3APQXTfhxaHW1nRpiFkcotg)
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+WBDnh75CaLEvkcN6p4ez2KXrV3M+x54xSdnCFHZ8yliofzOBK)
		return
	yyEYGlLToJHDk9BhFrxgUn8,sHP25eZ8IWjKJt7DAkozU = [],[]
	jKaWz3ZYwm4lciSd1u7 = p7dwlH1PRStBgyMUW.findall('var origin_link = "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	OwG8dqbXxaD3uCjNYryTJWAQR = p7dwlH1PRStBgyMUW.findall('var backup_origin_link = "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('hls: (.*?)_link\+"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for VVpQfHc7IZamxweON3WXKU6Fg,SOw5EUxC9k in laAHpo1bzyM0q:
		if 'backup' in VVpQfHc7IZamxweON3WXKU6Fg:
			VVpQfHc7IZamxweON3WXKU6Fg = 'backup server'
			url = OwG8dqbXxaD3uCjNYryTJWAQR + SOw5EUxC9k
		else:
			VVpQfHc7IZamxweON3WXKU6Fg = 'main server'
			url = jKaWz3ZYwm4lciSd1u7 + SOw5EUxC9k
		if '.m3u8' in url:
			yyEYGlLToJHDk9BhFrxgUn8.append(url)
			sHP25eZ8IWjKJt7DAkozU.append('m3u8  '+VVpQfHc7IZamxweON3WXKU6Fg)
	laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	laAHpo1bzyM0q += p7dwlH1PRStBgyMUW.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for VVpQfHc7IZamxweON3WXKU6Fg,SOw5EUxC9k in laAHpo1bzyM0q:
		filename = SOw5EUxC9k.split('/')[-1]
		filename = filename.replace('fallback',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		filename = filename.replace('.mp4',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		filename = filename.replace('-',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if 'backup' in VVpQfHc7IZamxweON3WXKU6Fg:
			VVpQfHc7IZamxweON3WXKU6Fg = 'backup server'
			url = OwG8dqbXxaD3uCjNYryTJWAQR + SOw5EUxC9k
		else:
			VVpQfHc7IZamxweON3WXKU6Fg = 'main server'
			url = jKaWz3ZYwm4lciSd1u7 + SOw5EUxC9k
		yyEYGlLToJHDk9BhFrxgUn8.append(url)
		sHP25eZ8IWjKJt7DAkozU.append('mp4  '+VVpQfHc7IZamxweON3WXKU6Fg+tTChquY7XSRg4e+filename)
	XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('Select Video Quality:', sHP25eZ8IWjKJt7DAkozU)
	if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
	url = yyEYGlLToJHDk9BhFrxgUn8[XFaM94cPUCOWQZNIEe8gdJpny1]
	YsRk6pAS7rdcn(url,NTWE764hmOgUtScp2e8r,'video')
	return
def IVudfRLF0xhc1kotSw65M(url,type):
	if 'series' in url: vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk + '/genre/مسلسل'
	else: vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk + '/genre/فيلم'
	vcQbFfCk6T1 = ZisgmEGCOJxVI9DcetNBPo6(vcQbFfCk6T1)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-FILTERS-1st')
	if type==1: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('subgenre(.*?)div',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif type==2: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('country(.*?)div',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('option value="(.*?)">(.*?)</option',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if type==1:
		for hhF8GeHNyME1QwoJLktub,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url+'?subgenre='+hhF8GeHNyME1QwoJLktub,58)
	elif type==2:
		url,hhF8GeHNyME1QwoJLktub = url.split('?')
		for l7L3xtUSXrRAV6nwEMpBv4yimKc0H9,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url+'?country='+l7L3xtUSXrRAV6nwEMpBv4yimKc0H9+'&'+hhF8GeHNyME1QwoJLktub,51)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if not search: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	url = pcE6DxaoHBm41WKXjwnk+'/search?q='+DqbrOGw4giHUvfuFtRXQ5lA0yN
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFMAX-SEARCH-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('general-body(.*?)search-bottom-padding',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			url = pcE6DxaoHBm41WKXjwnk + SOw5EUxC9k
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+ZisgmEGCOJxVI9DcetNBPo6(title)+'='+J4tO21KYAVdSr67W5NmiD0XhRP
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,52,J4tO21KYAVdSr67W5NmiD0XhRP)
				else:
					title = '_MOD_فيلم '+title
					octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,53,J4tO21KYAVdSr67W5NmiD0XhRP)
	return