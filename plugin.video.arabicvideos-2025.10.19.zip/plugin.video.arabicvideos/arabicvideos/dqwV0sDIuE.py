# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'CIMA4U'
headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_C4U_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==420: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==421: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==422: APpdhB1Fk58MmJH7CjVntowyaY = PPAxlvst3JmBy(url)
	elif mode==423: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==424: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==427: APpdhB1Fk58MmJH7CjVntowyaY = jKAYNko3tmEcpfzWn5F(url)
	elif mode==429: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	VVDAncSMUjeu8Ii = VVDAncSMUjeu8Ii[0].strip('/')
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(VVDAncSMUjeu8Ii,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,429,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',VVDAncSMUjeu8Ii,425)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',VVDAncSMUjeu8Ii,424)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الرئيسية',VVDAncSMUjeu8Ii,421)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('NavigationMenu(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="*(.*?)"*>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if '/actors' in SOw5EUxC9k: title = 'أفلام النجوم'
		elif '/netflix' in SOw5EUxC9k: title = 'أفلام ومسلسلات نيتفلكس'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,421)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'قائمة تفصيلية',VVDAncSMUjeu8Ii,427)
	return
def jKAYNko3tmEcpfzWn5F(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('FilteringTitle(.*?)PageTitle',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for eukVjoW67vBiySNXrplDKIZLHU,id,SOw5EUxC9k,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if 'netflix-movies' in SOw5EUxC9k: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in SOw5EUxC9k: title = 'مسلسلات نيتفلكس'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eukVjoW67vBiySNXrplDKIZLHU+'|'+id)
	return
def ctDj2OVRyaUPXCrITmJG(url,SUm0TCBiv7ck8sDMhOp=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if not SUm0TCBiv7ck8sDMhOp or '|' in SUm0TCBiv7ck8sDMhOp:
		if '|' not in SUm0TCBiv7ck8sDMhOp: e2yPhWIFOYo7s1vm = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		else: e2yPhWIFOYo7s1vm = '/archive/'+SUm0TCBiv7ck8sDMhOp
		YzAtevgaKsZ0Vdbcr7xkw8E1S = False
		if 'PinSlider' in piN9Qlah4S:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',url,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
			YzAtevgaKsZ0Vdbcr7xkw8E1S = True
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('PageTitle(.*?)PageContent',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			s5ocIDd4WKuPrV = cKUQVwTMe9tZSY[0]
			YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('data-tab="(.*?)".*?<span>(.*?)<',s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
			for OomHf7UgvIYVsPNR6GqX05bJE,gPvxJw89S35R21zDIbpFYkq7A in YacIZtAGdEPsFhSe:
				ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = VVDAncSMUjeu8Ii+'/ajaxcenter/action/HomepageLoader/tab/'+OomHf7UgvIYVsPNR6GqX05bJE+e2yPhWIFOYo7s1vm+'/'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,421)
				YzAtevgaKsZ0Vdbcr7xkw8E1S = True
		if YzAtevgaKsZ0Vdbcr7xkw8E1S: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	if SUm0TCBiv7ck8sDMhOp=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('PinSlider(.*?)MultiFilter',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('PinSlider(.*?)PageTitle',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		else: KDCdHQmgxPE21tYz4VUowSv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
	elif '/filter/' in url:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('PageContent(.*?)class="*pagination"*',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif '/actors' in url:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('PageContent(.*?)class="*pagination"*',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('Cima4uBlocks(.*?)</li></ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		else: KDCdHQmgxPE21tYz4VUowSv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if not items: items = p7dwlH1PRStBgyMUW.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: items = p7dwlH1PRStBgyMUW.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		if not title: continue
		if '?news=' in SOw5EUxC9k: continue
		title = title.replace('مشاهدة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) حلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if er96jwp52cbvaV48mtylEYSRz and 'حلقة' in title:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,422,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/actor/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,421,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,422,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY and SUm0TCBiv7ck8sDMhOp!='featured':
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			title = title.replace('الصفحة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,421)
	uDi9v6xMaTs1SwcAl8PRGqCL = p7dwlH1PRStBgyMUW.findall('</li><a href="(.*?)".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if uDi9v6xMaTs1SwcAl8PRGqCL:
		SOw5EUxC9k,title = uDi9v6xMaTs1SwcAl8PRGqCL[0]
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,421)
	return
def PPAxlvst3JmBy(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-SEASONS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="WatchNow".*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		url = cKUQVwTMe9tZSY[0]
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-SEASONS-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('SeasonsSections(.*?)</div></div></div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if '/tag/' in url or '/actor' in url:
		ctDj2OVRyaUPXCrITmJG(url)
	elif cKUQVwTMe9tZSY:
		J4tO21KYAVdSr67W5NmiD0XhRP = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Thumb')
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall("href='(.*?)'>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		mQsn4tLT2MbW3HGiUNgR0IKv5lr = ['مسلسل','موسم','برنامج','حلقة']
		for SOw5EUxC9k,title in items:
			if any(value in title for value in mQsn4tLT2MbW3HGiUNgR0IKv5lr):
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,423,J4tO21KYAVdSr67W5NmiD0XhRP)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,426,J4tO21KYAVdSr67W5NmiD0XhRP)
	else: d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"background-image:url\((.*?)\)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if J4tO21KYAVdSr67W5NmiD0XhRP: J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0]
	else: J4tO21KYAVdSr67W5NmiD0XhRP = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	YhzDEKvmbfX = p7dwlH1PRStBgyMUW.findall('EpisodesSection(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if YhzDEKvmbfX:
		KDCdHQmgxPE21tYz4VUowSv = YhzDEKvmbfX[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,er96jwp52cbvaV48mtylEYSRz in items:
			title = title+kcXMWrwiLDKeBHRsJ+er96jwp52cbvaV48mtylEYSRz
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,426,J4tO21KYAVdSr67W5NmiD0XhRP)
	else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+'رابط التشغيل',url,426,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	voKES76fGXxnWcNsi = WadGEeh1MBIXkpfP38qAv7ryslY.url
	if YVzokG2yZqrh3w8bU: voKES76fGXxnWcNsi = voKES76fGXxnWcNsi.encode(e87cIA5vwOQLDEP1)
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(voKES76fGXxnWcNsi,'url')
	M0MFkiKqJDv1aZ4NA396u = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('WatchSection(.*?)</div></div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('data-link="(.*?)".*? />(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for cza2TRbvfOW8i5xoU,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if 'myvid' in title.lower(): title = 'خاص '+title
			SOw5EUxC9k = VVDAncSMUjeu8Ii+'/structure/server.php?id='+cza2TRbvfOW8i5xoU+'?named='+title+'__watch'
			SOw5EUxC9k = SOw5EUxC9k.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('DownloadServers(.*?)</div></div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*? />(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if 'myvid' in title.lower(): gPvxJw89S35R21zDIbpFYkq7A = '__خاص'
			else: gPvxJw89S35R21zDIbpFYkq7A = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'+gPvxJw89S35R21zDIbpFYkq7A
			SOw5EUxC9k = SOw5EUxC9k.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/Search?q='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return
def J87GLvYrDtMFUo9R6OuEyhi1zC3(url):
	if 'smartemadfilter' not in url: url = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('MultiFilter(.*?)PageTitle',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return ZudC8bDqo4mM5c7GfP96Qy2F
def sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv):
	items = p7dwlH1PRStBgyMUW.findall('data-id="(.*?)".*?</div>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return items
def tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url):
	q16smZkWvE = url.split('/smartemadfilter?')[0]
	HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	url = url.replace(q16smZkWvE,HM25TctPpBqSeNzx3fm714)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
tqgKeQMz5XNvBPZAE6DCxfaLbj = ['category','types','release-year']
wQyTn0NR9VkaBSCrDzPsqMl = ['Quality','release-year','types','category']
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global tqgKeQMz5XNvBPZAE6DCxfaLbj
			tqgKeQMz5XNvBPZAE6DCxfaLbj = tqgKeQMz5XNvBPZAE6DCxfaLbj[1:]
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	elif type=='ALL_ITEMS_FILTER':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'/smartemadfilter?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',vcQbFfCk6T1,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filter')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filter')
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ZudC8bDqo4mM5c7GfP96Qy2F = J87GLvYrDtMFUo9R6OuEyhi1zC3(url)
	dict = {}
	for name,KDCdHQmgxPE21tYz4VUowSv,LgJITEZU95fS2oi8K in ZudC8bDqo4mM5c7GfP96Qy2F:
		if '/category/' in url and LgJITEZU95fS2oi8K=='category': continue
		name = name.replace('--',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		items = sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='SPECIFIED_FILTER':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<2:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]:
					url = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(url)
					ctDj2OVRyaUPXCrITmJG(url)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'SPECIFIED_FILTER___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				vcQbFfCk6T1 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(vcQbFfCk6T1)
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filter')
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,425,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='ALL_ITEMS_FILTER':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع :'+name,vcQbFfCk6T1,424,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if value=='196533': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'أفلام نيتفلكس'
			elif value=='196531': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'مسلسلات نيتفلكس'
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'+name
			if type=='ALL_ITEMS_FILTER': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,424,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='SPECIFIED_FILTER' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'modified_filters')
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = tX5WQT9rIfsV18YoJwl67Hjpyd4ez(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,421,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filter')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,425,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.replace('=&','=0&')
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	CZewXSEQ3q = CZewXSEQ3q.replace('=0','=')
	return CZewXSEQ3q