# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'EGYBESTVIP'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_EGV_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,TB3DI4JWr0NYmik1xO8Kc2,text):
	if   mode==220: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==221: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==222: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==223: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==224: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url)
	elif mode==229: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,229,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="i i-home"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,222)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="ba(.*?)<script',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for title,SOw5EUxC9k in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,221)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if 'html' not in SOw5EUxC9k: continue
			if not SOw5EUxC9k.endswith('/'): octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,221)
	return piN9Qlah4S
def uJlhLk2Tbcd(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="rs_scroll"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,224)
	return
def O40uMkKs5x6zmP9eFjnSbU(url):
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',url,221)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-FILTERS_MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="sub_nav(.*?)id="movies',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".+?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if SOw5EUxC9k=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,221)
	else: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2='1'):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	if '/search' in url or '?' in url: vcQbFfCk6T1 = url + '&'
	else: vcQbFfCk6T1 = url + '?'
	vcQbFfCk6T1 = vcQbFfCk6T1 + 'page=' + TB3DI4JWr0NYmik1xO8Kc2
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('class="pda"(.*?)div',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[-1]
	elif '/series/' in url:
		cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('class="owl-carousel owl-carousel(.*?)div',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	else:
		cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('id="movies(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[-1]
	items = p7dwlH1PRStBgyMUW.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if '/movie/' in SOw5EUxC9k or '/episode' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k.rstrip('/'),223,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,221,J4tO21KYAVdSr67W5NmiD0XhRP)
	if len(items)>=16:
		G2rSmg1b3xJXlWpyNHAsOi6D7Rn = ['/movies','/tv','/search','/trending']
		TB3DI4JWr0NYmik1xO8Kc2 = int(TB3DI4JWr0NYmik1xO8Kc2)
		if any(value in url for value in G2rSmg1b3xJXlWpyNHAsOi6D7Rn):
			for z26ZPQu7CmYAcNxRfX4Da98heMt1B in range(0,1000,100):
				if int(TB3DI4JWr0NYmik1xO8Kc2/100)*100==z26ZPQu7CmYAcNxRfX4Da98heMt1B:
					for JrM1DoSuQ5n8 in range(z26ZPQu7CmYAcNxRfX4Da98heMt1B,z26ZPQu7CmYAcNxRfX4Da98heMt1B+100,10):
						if int(TB3DI4JWr0NYmik1xO8Kc2/10)*10==JrM1DoSuQ5n8:
							for OTEanYikpqHGRDJ8Qxmg5ohvlXL in range(JrM1DoSuQ5n8,JrM1DoSuQ5n8+10,1):
								if not TB3DI4JWr0NYmik1xO8Kc2==OTEanYikpqHGRDJ8Qxmg5ohvlXL and OTEanYikpqHGRDJ8Qxmg5ohvlXL!=0:
									octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+str(OTEanYikpqHGRDJ8Qxmg5ohvlXL),url,221,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(OTEanYikpqHGRDJ8Qxmg5ohvlXL))
						elif JrM1DoSuQ5n8!=0: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+str(JrM1DoSuQ5n8),url,221,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(JrM1DoSuQ5n8))
						else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+str(1),url,221,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(1))
				elif z26ZPQu7CmYAcNxRfX4Da98heMt1B!=0: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+str(z26ZPQu7CmYAcNxRfX4Da98heMt1B),url,221,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(z26ZPQu7CmYAcNxRfX4Da98heMt1B))
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+str(1),url,221)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = [],[]
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-PLAY-1st')
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('<td>التصنيف</td>.*?">(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	HXbcgWp1CQ3ZkuxYiV5GTj,auiznBWPYG6dgsqb5RySXxh4Ct = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	of4sxIHM2lGmnD,WxhP53NGfQCSc6Hm4AYjrgz = piN9Qlah4S,piN9Qlah4S
	vVypnILlaBhmz = p7dwlH1PRStBgyMUW.findall('show_dl api" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vVypnILlaBhmz:
		for SOw5EUxC9k in vVypnILlaBhmz:
			if '/watch/' in SOw5EUxC9k: HXbcgWp1CQ3ZkuxYiV5GTj = SOw5EUxC9k
			elif '/download/' in SOw5EUxC9k: auiznBWPYG6dgsqb5RySXxh4Ct = SOw5EUxC9k
		if HXbcgWp1CQ3ZkuxYiV5GTj!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: of4sxIHM2lGmnD = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,HXbcgWp1CQ3ZkuxYiV5GTj,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-PLAY-2nd')
		if auiznBWPYG6dgsqb5RySXxh4Ct!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: WxhP53NGfQCSc6Hm4AYjrgz = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,auiznBWPYG6dgsqb5RySXxh4Ct,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-PLAY-3rd')
	gg3uGWVdN9LXkCsa = p7dwlH1PRStBgyMUW.findall('id="video".*?data-src="(.*?)"',of4sxIHM2lGmnD,p7dwlH1PRStBgyMUW.DOTALL)
	if gg3uGWVdN9LXkCsa:
		vcQbFfCk6T1 = gg3uGWVdN9LXkCsa[0]
		if vcQbFfCk6T1!=WnNGfosHr5STAq8j7miwyRZ6eOUbV and 'uploaded.egybest.download' in vcQbFfCk6T1 and '/?id=_' not in vcQbFfCk6T1:
			hFYoSTas7WOVnwN = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-PLAY-4th')
			FHB6YhmaE3Dzl2wCqA504vud = p7dwlH1PRStBgyMUW.findall('source src="(.*?)" title="(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if FHB6YhmaE3Dzl2wCqA504vud:
				for SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO in FHB6YhmaE3Dzl2wCqA504vud:
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k+'?named=ed.egybest.do__watch__mp4__'+DIBw28Qfje76bTMzVNYhxrgWmO)
			else:
				VVpQfHc7IZamxweON3WXKU6Fg = vcQbFfCk6T1.split('/')[2]
				M0MFkiKqJDv1aZ4NA396u.append(vcQbFfCk6T1+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__watch')
		elif vcQbFfCk6T1!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			VVpQfHc7IZamxweON3WXKU6Fg = vcQbFfCk6T1.split('/')[2]
			M0MFkiKqJDv1aZ4NA396u.append(vcQbFfCk6T1+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__watch')
	HC1Dt7VN3dPvjZYgo = p7dwlH1PRStBgyMUW.findall('<table class="dls_table(.*?)</table>',WxhP53NGfQCSc6Hm4AYjrgz,p7dwlH1PRStBgyMUW.DOTALL)
	if HC1Dt7VN3dPvjZYgo:
		HC1Dt7VN3dPvjZYgo = HC1Dt7VN3dPvjZYgo[0]
		LnJU5xVPm4BrojaDiSf = p7dwlH1PRStBgyMUW.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',HC1Dt7VN3dPvjZYgo,p7dwlH1PRStBgyMUW.DOTALL)
		if LnJU5xVPm4BrojaDiSf:
			for DIBw28Qfje76bTMzVNYhxrgWmO,SOw5EUxC9k in LnJU5xVPm4BrojaDiSf:
				if 'myegyvip' not in SOw5EUxC9k: continue
				if SOw5EUxC9k.count('/')>=2:
					VVpQfHc7IZamxweON3WXKU6Fg = SOw5EUxC9k.split('/')[2]
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__download__mp4__'+DIBw28Qfje76bTMzVNYhxrgWmO)
	do9Jn4YIWwCH3bQtcR1V8ehgFK = []
	for SOw5EUxC9k in M0MFkiKqJDv1aZ4NA396u:
		do9Jn4YIWwCH3bQtcR1V8ehgFK.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(do9Jn4YIWwCH3bQtcR1V8ehgFK,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBESTVIP-SEARCH-1st')
	pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = p7dwlH1PRStBgyMUW.findall('name="_token" value="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if pwNzhAPx5kYU7MEvXR3siJtQ8jn0H:
		url = pcE6DxaoHBm41WKXjwnk+'/search?_token='+pwNzhAPx5kYU7MEvXR3siJtQ8jn0H[0]+'&q='+DqbrOGw4giHUvfuFtRXQ5lA0yN
		ctDj2OVRyaUPXCrITmJG(url)
	return