# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'KATKOUTE'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_KTK_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الصفحة الرئيسية','Sign in','الأقسام']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==670: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==671: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==672: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==673: APpdhB1Fk58MmJH7CjVntowyaY = WJhTg9iDoQwPK(url,text)
	elif mode==674: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==679: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,679,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"navslide-divider"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,mode)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	items = HWUgZ3N0f8dLY4RXEy9(pcE6DxaoHBm41WKXjwnk+'/watch/browse.html')
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,674,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def HWUgZ3N0f8dLY4RXEy9(url):
	CwnFdurTY67y2L80A3KSGb = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','KATKOUTE','CATEGORIES')
	if CwnFdurTY67y2L80A3KSGb: return CwnFdurTY67y2L80A3KSGb
	CwnFdurTY67y2L80A3KSGb = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-CATEGORIES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"category-header"(.*?)<footer>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		CwnFdurTY67y2L80A3KSGb = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if CwnFdurTY67y2L80A3KSGb: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'KATKOUTE','CATEGORIES',CwnFdurTY67y2L80A3KSGb,oldym5kX8IqLSVDtpNMw)
	return CwnFdurTY67y2L80A3KSGb
def uJlhLk2Tbcd(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('"presentation"','</ul>')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = [(WnNGfosHr5STAq8j7miwyRZ6eOUbV,KDCdHQmgxPE21tYz4VUowSv)]
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' فرز أو فلتر أو ترتيب '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		for PiS4p2jAQN,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if PiS4p2jAQN: PiS4p2jAQN = PiS4p2jAQN+': '
			for SOw5EUxC9k,title in items:
				title = PiS4p2jAQN+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,671)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"pm-category-subcats"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if len(items)<30:
			octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
			for SOw5EUxC9k,title in items:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,671)
	if not gg4PIzkHEpv and not ZAIyluJa1EWhdB7OHV5CRGSrk: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-TITLES-1st')
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-TITLES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	KDCdHQmgxPE21tYz4VUowSv,items = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in YacIZtAGdEPsFhSe: items.append((WnNGfosHr5STAq8j7miwyRZ6eOUbV,SOw5EUxC9k,title))
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-video-watch-featured"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if len(cKUQVwTMe9tZSY)>1: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[1]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in YacIZtAGdEPsFhSe: items.append((WnNGfosHr5STAq8j7miwyRZ6eOUbV,SOw5EUxC9k,title))
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(data-echo=".*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if KDCdHQmgxPE21tYz4VUowSv and not items: items = p7dwlH1PRStBgyMUW.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: return
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,672,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,672,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,673,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movseries/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,671,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,673,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if SOw5EUxC9k=='#': continue
			if 'http' not in SOw5EUxC9k:
				vcQbFfCk6T1 = url.rsplit('/',1)[0]
				SOw5EUxC9k = vcQbFfCk6T1+'/'+SOw5EUxC9k.strip('/')
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,671,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,dlPQGb0aC5xmfFwy9ievKTqX)
	return
def WJhTg9iDoQwPK(url,LW28MawRZDVkYCSjX):
	octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+'تشغيل الفيديو',url,672)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	CwnFdurTY67y2L80A3KSGb = HWUgZ3N0f8dLY4RXEy9(pcE6DxaoHBm41WKXjwnk+'/watch/browse.html')
	MYRTbmCK51fVlZ,RRozkEhZgeC8nYTlaN,bCGpqBPt4MWfVkl8yLnvw0UKo = zip(*CwnFdurTY67y2L80A3KSGb)
	JBFvHMX91SC7tcgmlhUEQPu4zK = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-EPISODES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-video-heading"(.*?)id="player"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in laAHpo1bzyM0q:
			if SOw5EUxC9k not in MYRTbmCK51fVlZ:
				N6NV3h4fel = (SOw5EUxC9k,title)
				JBFvHMX91SC7tcgmlhUEQPu4zK.append(N6NV3h4fel)
		if len(JBFvHMX91SC7tcgmlhUEQPu4zK)==1:
			SOw5EUxC9k,title = JBFvHMX91SC7tcgmlhUEQPu4zK[0]
			ctDj2OVRyaUPXCrITmJG(SOw5EUxC9k,'new_episodes')
			return
		else:
			for SOw5EUxC9k,title in JBFvHMX91SC7tcgmlhUEQPu4zK:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,671,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'new_episodes')
	if not JBFvHMX91SC7tcgmlhUEQPu4zK: ctDj2OVRyaUPXCrITmJG(url,'new_episodes')
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'KATKOUTE-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('sources:(.*?)flashplayer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('file: "(.*?)".*?label: "(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO in laAHpo1bzyM0q:
			SOw5EUxC9k = SOw5EUxC9k+'?named=__watch__'+DIBw28Qfje76bTMzVNYhxrgWmO
			wxT9bCdumN.append(SOw5EUxC9k)
	laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('"embedded-video".*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not laAHpo1bzyM0q: laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall("file: '(.*?)'",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if laAHpo1bzyM0q:
		SOw5EUxC9k = laAHpo1bzyM0q[0]
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
		wxT9bCdumN.append(SOw5EUxC9k+'?named=__embed')
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/watch/search.php?keywords='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return