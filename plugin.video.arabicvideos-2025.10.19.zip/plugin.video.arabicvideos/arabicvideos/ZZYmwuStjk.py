# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ଑")
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,uuSU5Awl8FNrzkXHdQDiCWq3):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==A41nqbj3wYt(u"࠳࠴࠲ட"): APpdhB1Fk58MmJH7CjVntowyaY = ddDfVIu8xbBgAvyLX6YOwsoUMhtz7()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==wwWzyF4ZpSQXKOgk569(u"࠴࠵࠴஠"): APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(uuSU5Awl8FNrzkXHdQDiCWq3)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aiQwFE1TGx04vmLcsYkIW5jA(u"࠵࠶࠶஡"): APpdhB1Fk58MmJH7CjVntowyaY = GbjuXrVTICciOln()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠶࠷࠸஢"): APpdhB1Fk58MmJH7CjVntowyaY = F4izDKsh0O1jdPSrZmp2xvGgefR()
	else: APpdhB1Fk58MmJH7CjVntowyaY = KiryBCvngZzF85UN6xSDlOVweL4I9
	return APpdhB1Fk58MmJH7CjVntowyaY
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(uuSU5Awl8FNrzkXHdQDiCWq3):
	YsRk6pAS7rdcn(uuSU5Awl8FNrzkXHdQDiCWq3,NTWE764hmOgUtScp2e8r,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡶࡪࡦࡨࡳࠬ଒"))
	return
def F4izDKsh0O1jdPSrZmp2xvGgefR():
	eJU6bsndE1mI0F = pp7FcjEe6g(u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ଓ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧଔ"),eJU6bsndE1mI0F)
	return
def ddDfVIu8xbBgAvyLX6YOwsoUMhtz7():
	octplHnGwmE8bFqNdj7BiKvJ0VL(beV5l2D8HznyJI0(u"ࠩ࡯࡭ࡳࡱࠧକ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨଖ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"࠷࠸࠹ண"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(CyHU86ZeYT5BWRcitSm2I(u"ࠫࡱ࡯࡮࡬ࠩଗ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬଘ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"࠸࠹࠲த"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(oiWNFYzcIUeh(u"࠭࡬ࡪࡰ࡮ࠫଙ"),e6HEdvUcaq8Gx+CyHU86ZeYT5BWRcitSm2I(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ଚ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠿࠹࠺࠻஥"))
	LL6DMawc1nPZWrXCgNJTHq3FEl8 = Yi3cgeCpj7Tn9()
	W1I3Lkyfg7 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.stat(LL6DMawc1nPZWrXCgNJTHq3FEl8).st_mtime
	a3kGPwFH65BCEhS = []
	if rJ2oTLqabRtA: kyJATUoY1shj6zlXKCSpIcNmrd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(LL6DMawc1nPZWrXCgNJTHq3FEl8.encode(e87cIA5vwOQLDEP1))
	else: kyJATUoY1shj6zlXKCSpIcNmrd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(LL6DMawc1nPZWrXCgNJTHq3FEl8.decode(e87cIA5vwOQLDEP1))
	for DKOJi9xGfeS3HVv in kyJATUoY1shj6zlXKCSpIcNmrd:
		if rJ2oTLqabRtA: DKOJi9xGfeS3HVv = DKOJi9xGfeS3HVv.decode(e87cIA5vwOQLDEP1)
		if not DKOJi9xGfeS3HVv.startswith(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡨ࡬ࡰࡪࡥࠧଛ")): continue
		fV9EUPF8mGBNo4atIni7g1vksj = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(LL6DMawc1nPZWrXCgNJTHq3FEl8,DKOJi9xGfeS3HVv)
		W1I3Lkyfg7 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.getmtime(fV9EUPF8mGBNo4atIni7g1vksj)
		a3kGPwFH65BCEhS.append([DKOJi9xGfeS3HVv,W1I3Lkyfg7])
	a3kGPwFH65BCEhS = sorted(a3kGPwFH65BCEhS,reverse=r0D4C3z7Onqpa,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4])
	for DKOJi9xGfeS3HVv,W1I3Lkyfg7 in a3kGPwFH65BCEhS:
		if YVzokG2yZqrh3w8bU:
			try: DKOJi9xGfeS3HVv = DKOJi9xGfeS3HVv.decode(e87cIA5vwOQLDEP1)
			except: pass
			DKOJi9xGfeS3HVv = DKOJi9xGfeS3HVv.encode(e87cIA5vwOQLDEP1)
		fV9EUPF8mGBNo4atIni7g1vksj = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(LL6DMawc1nPZWrXCgNJTHq3FEl8,DKOJi9xGfeS3HVv)
		octplHnGwmE8bFqNdj7BiKvJ0VL(Z9FPQvwlbjLTh(u"ࠩࡹ࡭ࡩ࡫࡯ࠨଜ"),DKOJi9xGfeS3HVv,fV9EUPF8mGBNo4atIni7g1vksj,oiWNFYzcIUeh(u"࠳࠴࠳஦"))
	return
def Yi3cgeCpj7Tn9():
	LL6DMawc1nPZWrXCgNJTHq3FEl8 = G3yDpvxOiSWdAeL.getSetting(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ଝ"))
	if LL6DMawc1nPZWrXCgNJTHq3FEl8: return LL6DMawc1nPZWrXCgNJTHq3FEl8
	G3yDpvxOiSWdAeL.setSetting(GHg28TBchiyn6l(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧଞ"),kcCgDi2EzhU5s413pAjSmu)
	return kcCgDi2EzhU5s413pAjSmu
def GbjuXrVTICciOln():
	LL6DMawc1nPZWrXCgNJTHq3FEl8 = Yi3cgeCpj7Tn9()
	DpryqAa8fRHGncKlXNYs0L9 = TPNsmjik1eh4Wc(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଟ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪଠ"),RNWqL0gBbKOie1DxjUpzQPh9aZyHX+LL6DMawc1nPZWrXCgNJTHq3FEl8+YVr6St5P4xsFC0aARQGKfiegD+A41nqbj3wYt(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨଡ"))
	if DpryqAa8fRHGncKlXNYs0L9==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠲஧"):
		phRuXdmcZx = TiBVQ7aWwAO6lzkxjDYFK5by49mh(aiQwFE1TGx04vmLcsYkIW5jA(u"࠵ந"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬଢ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩ࡯ࡳࡨࡧ࡬ࠨଣ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa,LL6DMawc1nPZWrXCgNJTHq3FEl8)
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡧࡪࡴࡴࡦࡴࠪତ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨଥ"),RNWqL0gBbKOie1DxjUpzQPh9aZyHX+LL6DMawc1nPZWrXCgNJTHq3FEl8+YVr6St5P4xsFC0aARQGKfiegD+beV5l2D8HznyJI0(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭ଦ"))
		if kkLdeyJUsSiK9YwFZr4lPbVE==A41nqbj3wYt(u"࠴ன"):
			G3yDpvxOiSWdAeL.setSetting(pp7FcjEe6g(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩଧ"),phRuXdmcZx)
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,A41nqbj3wYt(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨନ"))
	return
def PZTLpeBFUV4v(uuSU5Awl8FNrzkXHdQDiCWq3,VDbTGIpvEYSedh06oZrxgOCKu5HzjJ=WnNGfosHr5STAq8j7miwyRZ6eOUbV,website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+pp7FcjEe6g(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ଩")+uuSU5Awl8FNrzkXHdQDiCWq3+tzZ6PhyDOUnwLM3pdK(u"ࠩࠣࡡࠬପ"))
	if not VDbTGIpvEYSedh06oZrxgOCKu5HzjJ: VDbTGIpvEYSedh06oZrxgOCKu5HzjJ = mm19wY7OfIvCxb8AFZEHJ(uuSU5Awl8FNrzkXHdQDiCWq3)
	LL6DMawc1nPZWrXCgNJTHq3FEl8 = Yi3cgeCpj7Tn9()
	OCVUomhFsnctQJS8 = qjt73vfsNQZUw6(KiryBCvngZzF85UN6xSDlOVweL4I9)
	DKOJi9xGfeS3HVv = OCVUomhFsnctQJS8.replace(kcXMWrwiLDKeBHRsJ,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡣࠬଫ"))
	DKOJi9xGfeS3HVv = WQzfBPt6sDuVw8N5xlcY(DKOJi9xGfeS3HVv)
	DKOJi9xGfeS3HVv = pp7FcjEe6g(u"ࠫ࡫࡯࡬ࡦࡡࠪବ")+str(int(jDuxzCtBH7aihsSL9))[-I872Vum45fMNe1BRngTZLoQiqvkt(u"࠸ப"):]+kdRO82AImh0LFw(u"ࠬࡥࠧଭ")+DKOJi9xGfeS3HVv+VDbTGIpvEYSedh06oZrxgOCKu5HzjJ
	ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(LL6DMawc1nPZWrXCgNJTHq3FEl8,DKOJi9xGfeS3HVv)
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = {}
	d91ITp3ybeYCWjGBFHqkD7voru6Eg[rVy3Ops0mohYkT(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨମ")] = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	d91ITp3ybeYCWjGBFHqkD7voru6Eg[IMjqygdfYSKpHlWu5Aa(u"ࠧࡂࡥࡦࡩࡵࡺࠧଯ")] = A6iX18qgyOFlZxz7sc(u"ࠨࠬ࠲࠮ࠬର")
	uuSU5Awl8FNrzkXHdQDiCWq3 = uuSU5Awl8FNrzkXHdQDiCWq3.replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ଱"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if yobpaW7sBqtKRrv(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨଲ") in uuSU5Awl8FNrzkXHdQDiCWq3:
		vcQbFfCk6T1,iHYO7Ic9kKUdPsgSCVyR = uuSU5Awl8FNrzkXHdQDiCWq3.rsplit(mq5t9JXSdHT8yfDVF(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩଳ"),GHg28TBchiyn6l(u"࠶஫"))
		iHYO7Ic9kKUdPsgSCVyR = iHYO7Ic9kKUdPsgSCVyR.replace(ZLr5gRSkFewKdUos90bM(u"ࠬࢂࠧ଴"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(VP70ytiFNMBl6vHDaW(u"࠭ࠦࠨଵ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	else: vcQbFfCk6T1,iHYO7Ic9kKUdPsgSCVyR = uuSU5Awl8FNrzkXHdQDiCWq3,None
	if not iHYO7Ic9kKUdPsgSCVyR: iHYO7Ic9kKUdPsgSCVyR = E1ltCBVyML6PAUNY()
	if iHYO7Ic9kKUdPsgSCVyR: d91ITp3ybeYCWjGBFHqkD7voru6Eg[tzZ6PhyDOUnwLM3pdK(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଶ")] = iHYO7Ic9kKUdPsgSCVyR
	if Z9FPQvwlbjLTh(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪଷ") in vcQbFfCk6T1: vcQbFfCk6T1,a8ViDmKTjhIEs4bnykRL = vcQbFfCk6T1.rsplit(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫସ"),kdRO82AImh0LFw(u"࠷஬"))
	else: vcQbFfCk6T1,a8ViDmKTjhIEs4bnykRL = vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	vcQbFfCk6T1 = vcQbFfCk6T1.strip(bawK2j7T81Nrc4GWs05xzDg(u"ࠪࢀࠬହ")).strip(Z9FPQvwlbjLTh(u"ࠫࠫ࠭଺")).strip(IMjqygdfYSKpHlWu5Aa(u"ࠬࢂࠧ଻")).strip(rVy3Ops0mohYkT(u"࠭ࠦࠨ଼"))
	a8ViDmKTjhIEs4bnykRL = a8ViDmKTjhIEs4bnykRL.replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡽࠩଽ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(KLX7hW0nBAEgy6m4SvH(u"ࠨࠨࠪା"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if a8ViDmKTjhIEs4bnykRL:	d91ITp3ybeYCWjGBFHqkD7voru6Eg[SI7eBdND4lx8pt5Qk(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪି")] = a8ViDmKTjhIEs4bnykRL
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+rVy3Ops0mohYkT(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୀ")+vcQbFfCk6T1+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧୁ")+str(d91ITp3ybeYCWjGBFHqkD7voru6Eg)+gPE1XB87fQl(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬୂ")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+wwWzyF4ZpSQXKOgk569(u"࠭ࠠ࡞ࠩୃ"))
	L3EJrtxTWiUMGHylNFkCs5vdK8w2Q = tzZ6PhyDOUnwLM3pdK(u"࠱࠱࠴࠷஭")*tzZ6PhyDOUnwLM3pdK(u"࠱࠱࠴࠷஭")
	xPrTHD2dgMBLIwq7o6Na4JAjmOK = YvUPLVEzOe3g7tw8C4amxKSGrM()//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q
	if not xPrTHD2dgMBLIwq7o6Na4JAjmOK:
		Pgbtx1uwX52DEk7Jf(kdRO82AImh0LFw(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ୄ"),Z9FPQvwlbjLTh(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨ୅"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭୆"),yobpaW7sBqtKRrv(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭େ"))
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬୈ"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ==A6iX18qgyOFlZxz7sc(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ୉"):
		ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,vcQbFfCk6T1,d91ITp3ybeYCWjGBFHqkD7voru6Eg)
		if len(ZD0qItXg31HmC7KGEFn)==oiWNFYzcIUeh(u"࠱ம"):
			uTaiRMI8eYmN(A6iX18qgyOFlZxz7sc(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪ୊"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			return KiryBCvngZzF85UN6xSDlOVweL4I9
		elif len(ZD0qItXg31HmC7KGEFn)==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠳ய"): XFaM94cPUCOWQZNIEe8gdJpny1 = A41nqbj3wYt(u"࠳ர")
		elif len(ZD0qItXg31HmC7KGEFn)>tzZ6PhyDOUnwLM3pdK(u"࠵ற"):
			XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(gPE1XB87fQl(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬୋ"), ZD0qItXg31HmC7KGEFn)
			if XFaM94cPUCOWQZNIEe8gdJpny1 == -eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠶ல") :
				uTaiRMI8eYmN(GHg28TBchiyn6l(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫୌ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				return KiryBCvngZzF85UN6xSDlOVweL4I9
		vcQbFfCk6T1 = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	xxhfZWHE3Cw2oqY = eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠶ள")
	import requests as KnHmtUWv49wToIf
	if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ==IMjqygdfYSKpHlWu5Aa(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ୍"):
		ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV = ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV.rsplit(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ୎"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࠳ࡳࡰ࠵ࠩ୏")
		lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,oiWNFYzcIUeh(u"ࠬࡍࡅࡕࠩ୐"),vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭୑"))
		kkTNvHQsYLVG21iOwDy74R8EoPMch = lAJu8dmbEUPZjrIahBH.content
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ୒"),kkTNvHQsYLVG21iOwDy74R8EoPMch+Z9FPQvwlbjLTh(u"ࠨ࡞ࡱࡠࡷ࠭୓"),p7dwlH1PRStBgyMUW.DOTALL)
		if not laAHpo1bzyM0q:
			SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+bawK2j7T81Nrc4GWs05xzDg(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ୔")+vcQbFfCk6T1+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠤࡢ࠭୕"))
			return KiryBCvngZzF85UN6xSDlOVweL4I9
		SOw5EUxC9k = laAHpo1bzyM0q[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if not SOw5EUxC9k.startswith(VP70ytiFNMBl6vHDaW(u"ࠫ࡭ࡺࡴࡱࠩୖ")):
			if SOw5EUxC9k.startswith(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬ࠵࠯ࠨୗ")): SOw5EUxC9k = vcQbFfCk6T1.split(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࠺ࠨ୘"),rVy3Ops0mohYkT(u"࠱ழ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+Z9FPQvwlbjLTh(u"ࠧ࠻ࠩ୙")+SOw5EUxC9k
			elif SOw5EUxC9k.startswith(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠱ࠪ୚")): SOw5EUxC9k = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,KLX7hW0nBAEgy6m4SvH(u"ࠩࡸࡶࡱ࠭୛"))+SOw5EUxC9k
			else: SOw5EUxC9k = vcQbFfCk6T1.rsplit(tzZ6PhyDOUnwLM3pdK(u"ࠪ࠳ࠬଡ଼"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠲வ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠴࠭ଢ଼")+SOw5EUxC9k
		lAJu8dmbEUPZjrIahBH = KnHmtUWv49wToIf.request(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡍࡅࡕࠩ୞"),SOw5EUxC9k,headers=d91ITp3ybeYCWjGBFHqkD7voru6Eg,verify=KiryBCvngZzF85UN6xSDlOVweL4I9)
		Oc5ZzDNKxp8qIF = lAJu8dmbEUPZjrIahBH.content
		nbV95kyuzAtQKIpNrZOwx8h = len(Oc5ZzDNKxp8qIF)
		jHzsJtumaD8MSTKyhiLOqdf71I = len(laAHpo1bzyM0q)
		xxhfZWHE3Cw2oqY = nbV95kyuzAtQKIpNrZOwx8h*jHzsJtumaD8MSTKyhiLOqdf71I
	else:
		nbV95kyuzAtQKIpNrZOwx8h = KLX7hW0nBAEgy6m4SvH(u"࠳ஶ")*L3EJrtxTWiUMGHylNFkCs5vdK8w2Q
		lAJu8dmbEUPZjrIahBH = KnHmtUWv49wToIf.request(A6iX18qgyOFlZxz7sc(u"࠭ࡇࡆࡖࠪୟ"),vcQbFfCk6T1,headers=d91ITp3ybeYCWjGBFHqkD7voru6Eg,verify=KiryBCvngZzF85UN6xSDlOVweL4I9,stream=r0D4C3z7Onqpa)
		if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨୠ") in lAJu8dmbEUPZjrIahBH.headers: xxhfZWHE3Cw2oqY = int(lAJu8dmbEUPZjrIahBH.headers[oiWNFYzcIUeh(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩୡ")])
		jHzsJtumaD8MSTKyhiLOqdf71I = int(xxhfZWHE3Cw2oqY//nbV95kyuzAtQKIpNrZOwx8h)
	e1TipUhjZSfKbrP60BGVcmWkywRgAH = int(xxhfZWHE3Cw2oqY//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)+YYQS36fyPvtuzcEmRL(u"࠴ஷ")
	if xxhfZWHE3Cw2oqY<wwWzyF4ZpSQXKOgk569(u"࠶࠶࠶࠰࠱ஸ"):
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+beV5l2D8HznyJI0(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୢ")+vcQbFfCk6T1+GHg28TBchiyn6l(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧୣ")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ୤")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+gPE1XB87fQl(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୥")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+yobpaW7sBqtKRrv(u"࠭ࠠ࡞ࠩ୦"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,CyHU86ZeYT5BWRcitSm2I(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩ୧"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	VdITKAQamMwSBbto8h7C = GHg28TBchiyn6l(u"࠹࠶࠰ஹ")
	cMOaYglsqQ08vybCEj2uVoxrkdwB7D = xPrTHD2dgMBLIwq7o6Na4JAjmOK-e1TipUhjZSfKbrP60BGVcmWkywRgAH
	if cMOaYglsqQ08vybCEj2uVoxrkdwB7D<VdITKAQamMwSBbto8h7C:
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+gPE1XB87fQl(u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୨")+vcQbFfCk6T1+SI7eBdND4lx8pt5Qk(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭୩")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+kdRO82AImh0LFw(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ୪")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+YYQS36fyPvtuzcEmRL(u"ࠫࠥࡓࡂࠡ࠯ࠣࠫ୫")+str(VdITKAQamMwSBbto8h7C)+YYQS36fyPvtuzcEmRL(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୬")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+A41nqbj3wYt(u"࠭ࠠ࡞ࠩ୭"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧ୮"),SI7eBdND4lx8pt5Qk(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧ୯")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+tzZ6PhyDOUnwLM3pdK(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨ୰")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+iySORMYxWXszEH18(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪୱ")+str(VdITKAQamMwSBbto8h7C)+I872Vum45fMNe1BRngTZLoQiqvkt(u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭୲"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(gPE1XB87fQl(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ୳"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠭็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥลࠧ୴"),wwWzyF4ZpSQXKOgk569(u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠฮฮ่๋ࠥะโา์หหࠥ࠭୵")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦสใำํฬฬࠦࠧ୶")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+Z9FPQvwlbjLTh(u"้ࠩࠣ๏เวษษํฮࠥ๎็ัษࠣห้๋ไโࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠๅๆอั๊๐ไࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦลๅ๋ࠣะ์อาไࠢ࠱ࠤ์๊ࠠศ่อࠤ๊ะรไัࠣ์ฯื๊ะࠢส่ฬูสๆำสีࠥฮสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣรࠬ୷"))
	if kkLdeyJUsSiK9YwFZr4lPbVE!=yobpaW7sBqtKRrv(u"࠷஺"):
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ୸"))
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+kdRO82AImh0LFw(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭୹")+vcQbFfCk6T1+ZLr5gRSkFewKdUos90bM(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ୺")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+rVy3Ops0mohYkT(u"࠭ࠠ࡞ࠩ୻"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+A41nqbj3wYt(u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬ୼"))
	QEMTpcCe8tD1S6qbFvluRf = dpY7rMymk2W1Jo()
	QEMTpcCe8tD1S6qbFvluRf.create(ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ୽"))
	jadvuk0wqQexTp = r0D4C3z7Onqpa
	CIeL32XZ57bpg6WFyKB = x54xSdnCFHZ8yliofzOBK.time()
	if not A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,IMjqygdfYSKpHlWu5Aa(u"ࠩหือฮฺࠠั่ࠤฬ๊สษำ฼ࠤฯ๋ࠠฦๆ฽หฦࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ୾"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	if rJ2oTLqabRtA: uLIrdZa7NKqBsU = open(ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV,kdRO82AImh0LFw(u"ࠪࡻࡧ࠭୿"))
	else: uLIrdZa7NKqBsU = open(ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV.decode(e87cIA5vwOQLDEP1),mq5t9JXSdHT8yfDVF(u"ࠫࡼࡨࠧ஀"))
	if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ==VP70ytiFNMBl6vHDaW(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁"):
		for zuEo6GDeAR5Z in range(SI7eBdND4lx8pt5Qk(u"࠱஻"),jHzsJtumaD8MSTKyhiLOqdf71I+SI7eBdND4lx8pt5Qk(u"࠱஻")):
			SOw5EUxC9k = laAHpo1bzyM0q[zuEo6GDeAR5Z-CyHU86ZeYT5BWRcitSm2I(u"࠲஼")]
			if not SOw5EUxC9k.startswith(VP70ytiFNMBl6vHDaW(u"࠭ࡨࡵࡶࡳࠫஂ")):
				if SOw5EUxC9k.startswith(mq5t9JXSdHT8yfDVF(u"ࠧ࠰࠱ࠪஃ")): SOw5EUxC9k = vcQbFfCk6T1.split(IMjqygdfYSKpHlWu5Aa(u"ࠨ࠼ࠪ஄"),A6iX18qgyOFlZxz7sc(u"࠳஽"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+pp7FcjEe6g(u"ࠩ࠽ࠫஅ")+SOw5EUxC9k
				elif SOw5EUxC9k.startswith(VP70ytiFNMBl6vHDaW(u"ࠪ࠳ࠬஆ")): SOw5EUxC9k = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,wwWzyF4ZpSQXKOgk569(u"ࠫࡺࡸ࡬ࠨஇ"))+SOw5EUxC9k
				else: SOw5EUxC9k = vcQbFfCk6T1.rsplit(GHg28TBchiyn6l(u"ࠬ࠵ࠧஈ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠴ா"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࠯ࠨஉ")+SOw5EUxC9k
			lAJu8dmbEUPZjrIahBH = KnHmtUWv49wToIf.request(tzZ6PhyDOUnwLM3pdK(u"ࠧࡈࡇࡗࠫஊ"),SOw5EUxC9k,headers=d91ITp3ybeYCWjGBFHqkD7voru6Eg,verify=KiryBCvngZzF85UN6xSDlOVweL4I9)
			Oc5ZzDNKxp8qIF = lAJu8dmbEUPZjrIahBH.content
			lAJu8dmbEUPZjrIahBH.close()
			uLIrdZa7NKqBsU.write(Oc5ZzDNKxp8qIF)
			U6gROIqi8aXdnulKfsT1yZbpz = x54xSdnCFHZ8yliofzOBK.time()
			u4uJBhevc83VwyUnzp76q = U6gROIqi8aXdnulKfsT1yZbpz-CIeL32XZ57bpg6WFyKB
			Ypf31OGmeKDj5wbN4Vd7zySIRsQP = u4uJBhevc83VwyUnzp76q//zuEo6GDeAR5Z
			dgq6ZUI0KQ = Ypf31OGmeKDj5wbN4Vd7zySIRsQP*(jHzsJtumaD8MSTKyhiLOqdf71I+KLX7hW0nBAEgy6m4SvH(u"࠵ி"))
			t3A5M9dBswZO = dgq6ZUI0KQ-u4uJBhevc83VwyUnzp76q
			tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,int(kdRO82AImh0LFw(u"࠷࠰࠱ு")*zuEo6GDeAR5Z//(jHzsJtumaD8MSTKyhiLOqdf71I+YYQS36fyPvtuzcEmRL(u"࠶ீ"))),GHg28TBchiyn6l(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ஋"),kdRO82AImh0LFw(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ஌"),str(zuEo6GDeAR5Z*nbV95kyuzAtQKIpNrZOwx8h//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)+gPE1XB87fQl(u"ࠪ࠳ࠬ஍")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+mq5t9JXSdHT8yfDVF(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩஎ")+x54xSdnCFHZ8yliofzOBK.strftime(KLX7hW0nBAEgy6m4SvH(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢஏ"),x54xSdnCFHZ8yliofzOBK.gmtime(t3A5M9dBswZO))+ZLr5gRSkFewKdUos90bM(u"࠭ࠠแࠩஐ"))
			if QEMTpcCe8tD1S6qbFvluRf.iscanceled():
				jadvuk0wqQexTp = KiryBCvngZzF85UN6xSDlOVweL4I9
				break
	else:
		zuEo6GDeAR5Z = iySORMYxWXszEH18(u"࠰ூ")
		for Oc5ZzDNKxp8qIF in lAJu8dmbEUPZjrIahBH.iter_content(chunk_size=nbV95kyuzAtQKIpNrZOwx8h):
			uLIrdZa7NKqBsU.write(Oc5ZzDNKxp8qIF)
			zuEo6GDeAR5Z = zuEo6GDeAR5Z+rVy3Ops0mohYkT(u"࠲௃")
			U6gROIqi8aXdnulKfsT1yZbpz = x54xSdnCFHZ8yliofzOBK.time()
			u4uJBhevc83VwyUnzp76q = U6gROIqi8aXdnulKfsT1yZbpz-CIeL32XZ57bpg6WFyKB
			Ypf31OGmeKDj5wbN4Vd7zySIRsQP = u4uJBhevc83VwyUnzp76q/zuEo6GDeAR5Z
			dgq6ZUI0KQ = Ypf31OGmeKDj5wbN4Vd7zySIRsQP*(jHzsJtumaD8MSTKyhiLOqdf71I+tzZ6PhyDOUnwLM3pdK(u"࠳௄"))
			t3A5M9dBswZO = dgq6ZUI0KQ-u4uJBhevc83VwyUnzp76q
			tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,int(wwWzyF4ZpSQXKOgk569(u"࠵࠵࠶ெ")*zuEo6GDeAR5Z/(jHzsJtumaD8MSTKyhiLOqdf71I+eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠴௅"))),yobpaW7sBqtKRrv(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ஑"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨஒ"),str(zuEo6GDeAR5Z*nbV95kyuzAtQKIpNrZOwx8h//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩ࠲ࠫஓ")+str(e1TipUhjZSfKbrP60BGVcmWkywRgAH)+iySORMYxWXszEH18(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨஔ")+x54xSdnCFHZ8yliofzOBK.strftime(rVy3Ops0mohYkT(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨக"),x54xSdnCFHZ8yliofzOBK.gmtime(t3A5M9dBswZO))+tzZ6PhyDOUnwLM3pdK(u"ࠬࠦเࠨ஖"))
			if QEMTpcCe8tD1S6qbFvluRf.iscanceled():
				jadvuk0wqQexTp = KiryBCvngZzF85UN6xSDlOVweL4I9
				break
		lAJu8dmbEUPZjrIahBH.close()
	uLIrdZa7NKqBsU.close()
	QEMTpcCe8tD1S6qbFvluRf.close()
	if not jadvuk0wqQexTp:
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ஗")+vcQbFfCk6T1+beV5l2D8HznyJI0(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ஘")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+mq5t9JXSdHT8yfDVF(u"ࠨࠢࡠࠫங"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,IMjqygdfYSKpHlWu5Aa(u"ࠩหัุฮุࠠๆห็ࠥะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪச"))
		return r0D4C3z7Onqpa
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+VP70ytiFNMBl6vHDaW(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ஛")+vcQbFfCk6T1+SI7eBdND4lx8pt5Qk(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫஜ")+ajlf6Hiz7MGI8pbhuwXBN4d1At5WxV+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࠦ࡝ࠨ஝"))
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬஞ"))
	return r0D4C3z7Onqpa