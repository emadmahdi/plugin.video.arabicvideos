# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'HALACIMA'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_HLC_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==80: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==81: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==82: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==83: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==89: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'HALACIMA-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(pcE6DxaoHBm41WKXjwnk,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,89,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('main-content(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-name="(.*?)".*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SUm0TCBiv7ck8sDMhOp,title in items:
		SOw5EUxC9k = VVDAncSMUjeu8Ii+'/ajax/getItem?item='+SUm0TCBiv7ck8sDMhOp+'&Ajax=1'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,81)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"nav-main"(.*?)</nav>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if SOw5EUxC9k=='#': continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,81)
	return
def ctDj2OVRyaUPXCrITmJG(url,SUm0TCBiv7ck8sDMhOp=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = bJlfaY9rk80uXWZzV2oeNBcI(url)
		W67hPCcaOek094 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'HALACIMA-TITLES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = [piN9Qlah4S]
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'HALACIMA-TITLES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		if SUm0TCBiv7ck8sDMhOp=='featured':
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"container"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		elif '"section-post mb-10"' in piN9Qlah4S:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"section-post mb-10"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		else:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<article(.*?)"pagination"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items:
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not items: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if '/series/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,83,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif 'سلاسل' not in url and any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,82,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,83,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movies/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,81,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,83,J4tO21KYAVdSr67W5NmiD0XhRP)
	if SUm0TCBiv7ck8sDMhOp==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)<footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=="": continue
				if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'هناك المزيد',url,81)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'HALACIMA-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"getSeasonsBySeries(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"list-episodes"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv and '/series/' not in url:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,83,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif ZAIyluJa1EWhdB7OHV5CRGSrk:
		J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"image" src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0]
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,82,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	vcQbFfCk6T1 = url.replace('/movies/','/watch_movies/')
	vcQbFfCk6T1 = vcQbFfCk6T1.replace('/episodes/','/watch_episodes/')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'HALACIMA-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(vcQbFfCk6T1,'url')
	M0MFkiKqJDv1aZ4NA396u = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"servers"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		YQU9rmMqC0LWkcxaFpZos7VdRg = p7dwlH1PRStBgyMUW.findall('postID = "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		YQU9rmMqC0LWkcxaFpZos7VdRg = YQU9rmMqC0LWkcxaFpZos7VdRg[0]
		items = p7dwlH1PRStBgyMUW.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for VVpQfHc7IZamxweON3WXKU6Fg,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			SOw5EUxC9k = VVDAncSMUjeu8Ii+'/ajax/getPlayer?server='+VVpQfHc7IZamxweON3WXKU6Fg+'&postID='+YQU9rmMqC0LWkcxaFpZos7VdRg+'&Ajax=1'
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"downs"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name in items:
			SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__download'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'-')
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'.html'
	ctDj2OVRyaUPXCrITmJG(url)
	return