# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ARABICTOONS'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_ART_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==730: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==731: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==732: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==733: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==734: APpdhB1Fk58MmJH7CjVntowyaY = fUViqPMOamxJIQb(url)
	elif mode==735: APpdhB1Fk58MmJH7CjVntowyaY = dIHF3QEp12v7lXfAgm9jJCVLOSsNxZ(url)
	elif mode==739: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,739,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'افلام',pcE6DxaoHBm41WKXjwnk+'/movies.php',731)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات',pcE6DxaoHBm41WKXjwnk+'/cartoon.php',734)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مميزة',pcE6DxaoHBm41WKXjwnk+'/top.php',735)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أحدث الأفلام المضافة',pcE6DxaoHBm41WKXjwnk,731,'','','LATEST_MOVIES')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أحدث المسلسلات المضافة',pcE6DxaoHBm41WKXjwnk,731,'','','LATEST_SERIES')
	return
def fUViqPMOamxJIQb(url):
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الكل',url,731)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-SERIES_SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('label="navigation"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall("href='(.*?)'>(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = 'حرف '+title
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,731)
	return
def dIHF3QEp12v7lXfAgm9jJCVLOSsNxZ(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-SERIES_FEATURED-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="slider"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,733,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("class='moviesBlocks(.*?)list-group",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if dlPQGb0aC5xmfFwy9ievKTqX=='LATEST_SERIES': KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[1]
	else: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
		J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if 'movies.php' in url or dlPQGb0aC5xmfFwy9ievKTqX=='LATEST_MOVIES':
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,732,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,733,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[-1]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,731)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("class='moviesBlocks(.*?)script",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,VCDxBjPsRFtyv42KYo in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
			J4tO21KYAVdSr67W5NmiD0XhRP = pcE6DxaoHBm41WKXjwnk+'/'+J4tO21KYAVdSr67W5NmiD0XhRP
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			title = title+kcXMWrwiLDKeBHRsJ+VCDxBjPsRFtyv42KYo.strip(kcXMWrwiLDKeBHRsJ)
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,732,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('source src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if laAHpo1bzyM0q:
		SOw5EUxC9k = laAHpo1bzyM0q[0]
		if 'Referer=' not in SOw5EUxC9k: SOw5EUxC9k = SOw5EUxC9k+'|Referer=https://www.arabic-toons.com'
		wxT9bCdumN.append(SOw5EUxC9k+'?named=__embed')
	else:
		GzN0Ho3ZAUdC1 = p7dwlH1PRStBgyMUW.findall(r'dynamique.*?}\);', piN9Qlah4S, p7dwlH1PRStBgyMUW.DOTALL)
		if not GzN0Ho3ZAUdC1: GzN0Ho3ZAUdC1 = p7dwlH1PRStBgyMUW.findall(r'dynamique.*?}\)', piN9Qlah4S, p7dwlH1PRStBgyMUW.DOTALL)
		if GzN0Ho3ZAUdC1:
			JQZHVj57cqPIaDF = GzN0Ho3ZAUdC1[0]
			nwdcPT4JmVaLZoKSOfuGitW9qpkR3 = dict(p7dwlH1PRStBgyMUW.findall(r'(\w+):\s*"([^"]+)"', JQZHVj57cqPIaDF))
			XXUWYhsbmuKlxtSV5vwy9foQHMC1R4 = p7dwlH1PRStBgyMUW.search(r'const\s+(\w+)', JQZHVj57cqPIaDF)
			rIQWSTdngFy9ui6bHNREK = XXUWYhsbmuKlxtSV5vwy9foQHMC1R4.group(1) if XXUWYhsbmuKlxtSV5vwy9foQHMC1R4 else ""
			keys = p7dwlH1PRStBgyMUW.findall(r'\$\{' + rIQWSTdngFy9ui6bHNREK + r'\.(\w+)\}', JQZHVj57cqPIaDF)
			if nwdcPT4JmVaLZoKSOfuGitW9qpkR3 and keys:
				SOw5EUxC9k = "%s://%s/%s?%s" % (nwdcPT4JmVaLZoKSOfuGitW9qpkR3[keys[0]], nwdcPT4JmVaLZoKSOfuGitW9qpkR3[keys[1]], nwdcPT4JmVaLZoKSOfuGitW9qpkR3[keys[2]], nwdcPT4JmVaLZoKSOfuGitW9qpkR3[keys[3]])
				wxT9bCdumN.append(SOw5EUxC9k+'?named=__embed')
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	M0MFkiKqJDv1aZ4NA396u = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'m']
	xAeVLRTDjGN9mOokK7r5hIpZ = ['مسلسلات','افلام']
	if showDialogs:
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر النوع المطلوب:', xAeVLRTDjGN9mOokK7r5hIpZ)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-1: return
	else: XFaM94cPUCOWQZNIEe8gdJpny1 = 0
	type = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	url = pcE6DxaoHBm41WKXjwnk+'/livesearch.php?'+type+'&q='+search
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARABICTOONS-SEARCH-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if type=='m': octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,732)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,733)
	return