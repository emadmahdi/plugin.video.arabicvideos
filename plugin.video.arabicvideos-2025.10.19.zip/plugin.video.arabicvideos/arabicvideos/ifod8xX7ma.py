# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SHOOFPRO'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SHP_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['مصارعة','بث مباشر']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==480: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==481: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==482: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==483: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,text)
	elif mode==489: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text,url)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFPRO-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	VVDAncSMUjeu8Ii = VVDAncSMUjeu8Ii[0].strip('/')
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(VVDAncSMUjeu8Ii,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',VVDAncSMUjeu8Ii,489,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أحدث المواضيع',VVDAncSMUjeu8Ii,481)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"navigation"(.*?)"myAccount"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if SOw5EUxC9k=='#': continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,481)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,BBAlzM7r6Tpm):
	items = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFPRO-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"post(.*?)"footer"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	iiLBPoTIOh6tbV2MR = '/'.join(BBAlzM7r6Tpm.strip('/').split('/')[4:]).split('-')
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) حلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if BBAlzM7r6Tpm:
			ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = '/'.join(SOw5EUxC9k.strip('/').split('/')[4:]).split('-')
			xxvt0nQmS8OAwjpU = len([OU8cbKwe1gXj5hsoW0LJYrAQf2 for OU8cbKwe1gXj5hsoW0LJYrAQf2 in iiLBPoTIOh6tbV2MR if OU8cbKwe1gXj5hsoW0LJYrAQf2 in ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr])
			if xxvt0nQmS8OAwjpU>2 and '/episodes/' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,482,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			if not er96jwp52cbvaV48mtylEYSRz: er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if set(title.split()) & set(gbtIyQYJ854dkEhXfaev) and 'مسلسل' not in title:
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,482,J4tO21KYAVdSr67W5NmiD0XhRP)
			elif er96jwp52cbvaV48mtylEYSRz and 'حلقة' in title:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,483,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,url)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,483,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,url)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("'pagination'(.*?)</div>",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall("href='(.*?)'.*?>(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			title = title.replace('الصفحة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,481,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,BBAlzM7r6Tpm)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,vcQbFfCk6T1):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFPRO-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"img-responsive" src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if J4tO21KYAVdSr67W5NmiD0XhRP: J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0]
	else: J4tO21KYAVdSr67W5NmiD0XhRP = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Thumb')
	vMY951seGDFl8raS3kTmz246Z = True
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"listSeasons(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv and '/ajax/seasons' not in url:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		count = KDCdHQmgxPE21tYz4VUowSv.count('data-slug=')
		if count==0: count = KDCdHQmgxPE21tYz4VUowSv.count('data-season=')
		if count>1:
			vMY951seGDFl8raS3kTmz246Z = False
			if 'data-slug="' in KDCdHQmgxPE21tYz4VUowSv:
				items = p7dwlH1PRStBgyMUW.findall('data-slug="(.*?)">(.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for id,title in items:
					SOw5EUxC9k = VVDAncSMUjeu8Ii+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,483,J4tO21KYAVdSr67W5NmiD0XhRP)
			else:
				items = p7dwlH1PRStBgyMUW.findall('data-season="(.*?)">(.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for id,title in items:
					SOw5EUxC9k = VVDAncSMUjeu8Ii+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,483,J4tO21KYAVdSr67W5NmiD0XhRP)
	if vMY951seGDFl8raS3kTmz246Z:
		KDCdHQmgxPE21tYz4VUowSv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if '/ajax/seasons' in url: KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
		else:
			ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"eplist"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if ZAIyluJa1EWhdB7OHV5CRGSrk: KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,title in items:
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,482,J4tO21KYAVdSr67W5NmiD0XhRP)
	if not A3pXVFdyP1.menuItemsLIST: ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1,url)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	vcQbFfCk6T1 = url.strip('/')+'/?do=watch'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFPRO-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	M0MFkiKqJDv1aZ4NA396u = []
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	sswWia2EuAo8ZQ4jPX = p7dwlH1PRStBgyMUW.findall('vo_postID = "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not sswWia2EuAo8ZQ4jPX: sswWia2EuAo8ZQ4jPX = p7dwlH1PRStBgyMUW.findall('\(this\.id\,0\,(.*?)\)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	sswWia2EuAo8ZQ4jPX = sswWia2EuAo8ZQ4jPX[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"serversList"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('id="(.*?)".*?">(.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for ENfq7iAbK5yDLu1YkFhoZen,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			SOw5EUxC9k = VVDAncSMUjeu8Ii+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+sswWia2EuAo8ZQ4jPX+'&video='+ENfq7iAbK5yDLu1YkFhoZen[2:]+'?named='+title+'__watch'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('"getEmbed".*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k[0],'url')
		SOw5EUxC9k = SOw5EUxC9k[0]+'?named='+title+'__embed'
		M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	vcQbFfCk6T1 = url.strip('/')+'/?do=download'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHOOFPRO-PLAY-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"table-responsive"(.*?)</table>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('<td>(.*?)</td>.*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for title,SOw5EUxC9k in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if 'anavidz' in SOw5EUxC9k: gPvxJw89S35R21zDIbpFYkq7A = '__خاص'
			else: gPvxJw89S35R21zDIbpFYkq7A = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'+gPvxJw89S35R21zDIbpFYkq7A
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search,VVDAncSMUjeu8Ii=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	if VVDAncSMUjeu8Ii==WnNGfosHr5STAq8j7miwyRZ6eOUbV: VVDAncSMUjeu8Ii = pcE6DxaoHBm41WKXjwnk
	url = VVDAncSMUjeu8Ii+'/search/'+search+'/'
	ctDj2OVRyaUPXCrITmJG(url,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	return