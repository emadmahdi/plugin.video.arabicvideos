# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ARBLIONZ'
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_ARL_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==200: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==201: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==202: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==203: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==204: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'FILTERS___'+text)
	elif mode==205: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'CATEGORIES___'+text)
	elif mode==209: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,209,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',pcE6DxaoHBm41WKXjwnk,205)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',pcE6DxaoHBm41WKXjwnk,204)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مميزة',pcE6DxaoHBm41WKXjwnk+'??trending',201)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أفلام مميزة',pcE6DxaoHBm41WKXjwnk+'??trending_movies',201)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مميزة',pcE6DxaoHBm41WKXjwnk+'??trending_series',201)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الصفحة الرئيسية',pcE6DxaoHBm41WKXjwnk+'??mainpage',201)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('categories-tabs(.*?)MainRow',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('data-get="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for filter,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/ajax/home/more?filter='+filter
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,201)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('navigation-menu(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if not any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,201)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url):
	if '??' in url: url,type = url.split('??')
	else: type = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-TITLES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
	if 'getposts' in url: cKUQVwTMe9tZSY = [piN9Qlah4S]
	elif type=='trending':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='trending_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='trending_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='111mainpage':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="container page-content"(.*?)class="tabs"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('page-content(.*?)main-footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	SnBhkFA2Z3gNVWJlz1ypa = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = p7dwlH1PRStBgyMUW.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items:
		items = p7dwlH1PRStBgyMUW.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		laAHpo1bzyM0q,Db5GKmQEPvL6pZUWg91CqMrfRIj3Y,trNPCKLEgm = zip(*items)
		items = zip(Db5GKmQEPvL6pZUWg91CqMrfRIj3Y,laAHpo1bzyM0q,trNPCKLEgm)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		if '/series/' in SOw5EUxC9k: continue
		SOw5EUxC9k = SOw5EUxC9k.strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if '/film/' in SOw5EUxC9k or any(value in title for value in SnBhkFA2Z3gNVWJlz1ypa):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,202,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/episode/' in SOw5EUxC9k and 'الحلقة' in title:
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if er96jwp52cbvaV48mtylEYSRz:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,203,J4tO21KYAVdSr67W5NmiD0XhRP)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/pack/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k+'/films',201,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,203,J4tO21KYAVdSr67W5NmiD0XhRP)
	if type in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'mainpage']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href=["\'](http.*?)["\'].*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				title = title.replace('الصفحة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				if 'search?s=' in url:
					OSefcP6JzkIKrgQxRaDMi82dN75Vst = SOw5EUxC9k.split('page=')[1]
					DL8AUBtPpCOqw3Sa90v6RMxrYygQ = url.split('page=')[1]
					SOw5EUxC9k = url.replace('page='+DL8AUBtPpCOqw3Sa90v6RMxrYygQ,'page='+OSefcP6JzkIKrgQxRaDMi82dN75Vst)
				if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,201)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	rTxhwZLNYv3sKHIe6iVJ0bzURf,items,XXH8bCAt1NG = -1,[],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('ti-list-numbered(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		XXH8bCAt1NG = []
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = WnNGfosHr5STAq8j7miwyRZ6eOUbV.join(cKUQVwTMe9tZSY)
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',UOqp25uxcISGBPlAfbtzCNWXY4nvK,p7dwlH1PRStBgyMUW.DOTALL)
	items.append(url)
	items = set(items)
	for SOw5EUxC9k in items:
		SOw5EUxC9k = SOw5EUxC9k.strip('/')
		title = '_MOD_' + SOw5EUxC9k.split('/')[-1].replace('-',kcXMWrwiLDKeBHRsJ)
		uOFd6U75e4ZnqADYk8j9 = p7dwlH1PRStBgyMUW.findall('الحلقة-(\d+)',SOw5EUxC9k.split('/')[-1],p7dwlH1PRStBgyMUW.DOTALL)
		if uOFd6U75e4ZnqADYk8j9: uOFd6U75e4ZnqADYk8j9 = uOFd6U75e4ZnqADYk8j9[0]
		else: uOFd6U75e4ZnqADYk8j9 = '0'
		XXH8bCAt1NG.append([SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9])
	items = sorted(XXH8bCAt1NG, reverse=False, key=lambda key: int(key[2]))
	xsWGniMyCw9USZ4z1dVprIXRL = str(items).count('/season/')
	rTxhwZLNYv3sKHIe6iVJ0bzURf = str(items).count('/episode/')
	if xsWGniMyCw9USZ4z1dVprIXRL>1 and rTxhwZLNYv3sKHIe6iVJ0bzURf>0 and '/season/' not in url:
		for SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9 in items:
			if '/season/' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,203)
	else:
		for SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9 in items:
			if '/season/' not in SOw5EUxC9k:
				title = EZk136aeLoNqPvlDcTQpyM9Wm(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,202)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u = []
	ipdI4Kw1lMauxrtYoh = url.split('/')
	Sr3WVDE1jkbYUaz = pcE6DxaoHBm41WKXjwnk
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,True,'ARBLIONZ-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
	id = p7dwlH1PRStBgyMUW.findall('postId:"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not id: id = p7dwlH1PRStBgyMUW.findall('post_id=(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not id: id = p7dwlH1PRStBgyMUW.findall('post-id="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if id: id = id[0]
	if '/watch/' in piN9Qlah4S:
		vcQbFfCk6T1 = url.replace(ipdI4Kw1lMauxrtYoh[3],'watch')
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,True,'ARBLIONZ-PLAY-2nd')
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
		ddOhWH5Aj8lt0FZLxVG = p7dwlH1PRStBgyMUW.findall('data-embedd="(.*?)".*?alt="(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('data-embedd=".*?(http.*?)("|&quot;)',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		B5BGISlRygvdU6Kam1 = p7dwlH1PRStBgyMUW.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',hFYoSTas7WOVnwN)
		ZRdFxaH2V6IpbOKrAiLtT = p7dwlH1PRStBgyMUW.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		s4Ttzf3iIl2woFSeEGX8g = p7dwlH1PRStBgyMUW.findall('server="(.*?)".*?<span>(.*?)<',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		items = ddOhWH5Aj8lt0FZLxVG+YacIZtAGdEPsFhSe+B5BGISlRygvdU6Kam1+Gqnj5sEaUVxevOWlTrRK39oyc+ZRdFxaH2V6IpbOKrAiLtT+s4Ttzf3iIl2woFSeEGX8g
		if not items:
			items = p7dwlH1PRStBgyMUW.findall('<span>(.*?)</span>.*?src="(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
			items = [(d4mM7W5uXUF6oSgO,SsbduzmRPEIpN5xg1kZviGetJAO) for SsbduzmRPEIpN5xg1kZviGetJAO,d4mM7W5uXUF6oSgO in items]
		for VVpQfHc7IZamxweON3WXKU6Fg,title in items:
			if '.png' in VVpQfHc7IZamxweON3WXKU6Fg: continue
			if '.jpg' in VVpQfHc7IZamxweON3WXKU6Fg: continue
			if '&quot;' in VVpQfHc7IZamxweON3WXKU6Fg: continue
			DIBw28Qfje76bTMzVNYhxrgWmO = p7dwlH1PRStBgyMUW.findall('\d\d\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if DIBw28Qfje76bTMzVNYhxrgWmO:
				DIBw28Qfje76bTMzVNYhxrgWmO = DIBw28Qfje76bTMzVNYhxrgWmO[0]
				if DIBw28Qfje76bTMzVNYhxrgWmO in title: title = title.replace(DIBw28Qfje76bTMzVNYhxrgWmO+'p',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(DIBw28Qfje76bTMzVNYhxrgWmO,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				DIBw28Qfje76bTMzVNYhxrgWmO = '____'+DIBw28Qfje76bTMzVNYhxrgWmO
			else: DIBw28Qfje76bTMzVNYhxrgWmO = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if VVpQfHc7IZamxweON3WXKU6Fg.isdigit():
				SOw5EUxC9k = Sr3WVDE1jkbYUaz+'/?postid='+id+'&serverid='+VVpQfHc7IZamxweON3WXKU6Fg+'?named='+title+'__watch'+DIBw28Qfje76bTMzVNYhxrgWmO
			else:
				if 'http' not in VVpQfHc7IZamxweON3WXKU6Fg: VVpQfHc7IZamxweON3WXKU6Fg = 'http:'+VVpQfHc7IZamxweON3WXKU6Fg
				DIBw28Qfje76bTMzVNYhxrgWmO = p7dwlH1PRStBgyMUW.findall('\d\d\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
				if DIBw28Qfje76bTMzVNYhxrgWmO: DIBw28Qfje76bTMzVNYhxrgWmO = '____'+DIBw28Qfje76bTMzVNYhxrgWmO[0]
				else: DIBw28Qfje76bTMzVNYhxrgWmO = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				SOw5EUxC9k = VVpQfHc7IZamxweON3WXKU6Fg+'?named=__watch'+DIBw28Qfje76bTMzVNYhxrgWmO
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if 'DownloadNow' in piN9Qlah4S:
		W67hPCcaOek094 = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		vcQbFfCk6T1 = url+'/download'
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-PLAY-3rd')
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<ul class="download-items(.*?)</ul>',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		for KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			items = p7dwlH1PRStBgyMUW.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,name,DIBw28Qfje76bTMzVNYhxrgWmO in items:
				SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__download'+'____'+DIBw28Qfje76bTMzVNYhxrgWmO
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	elif '/download/' in piN9Qlah4S:
		W67hPCcaOek094 = { 'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV , 'X-Requested-With':'XMLHttpRequest' }
		vcQbFfCk6T1 = Sr3WVDE1jkbYUaz + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,True,True,'ARBLIONZ-PLAY-4th')
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
		if 'download-btns' in hFYoSTas7WOVnwN:
			B5BGISlRygvdU6Kam1 = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			for QQTfhlZEDnu4wVcOeHGNyCBo5t2 in B5BGISlRygvdU6Kam1:
				if '/page/' not in QQTfhlZEDnu4wVcOeHGNyCBo5t2 and 'http' in QQTfhlZEDnu4wVcOeHGNyCBo5t2:
					QQTfhlZEDnu4wVcOeHGNyCBo5t2 = QQTfhlZEDnu4wVcOeHGNyCBo5t2+'?named=__download'
					M0MFkiKqJDv1aZ4NA396u.append(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
				elif '/page/' in QQTfhlZEDnu4wVcOeHGNyCBo5t2:
					DIBw28Qfje76bTMzVNYhxrgWmO = WnNGfosHr5STAq8j7miwyRZ6eOUbV
					WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,True,'ARBLIONZ-PLAY-5th')
					xa5ysgfPWA2o = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
					UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('(<strong>.*?)-----',xa5ysgfPWA2o,p7dwlH1PRStBgyMUW.DOTALL)
					for FumClwDx46KgJRkpcesO8 in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
						xk1eziL5c0lEUjWPfyDQ = WnNGfosHr5STAq8j7miwyRZ6eOUbV
						Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('<strong>(.*?)</strong>',FumClwDx46KgJRkpcesO8,p7dwlH1PRStBgyMUW.DOTALL)
						for yyg7DZ8WoGkutANT in Gqnj5sEaUVxevOWlTrRK39oyc:
							N6NV3h4fel = p7dwlH1PRStBgyMUW.findall('\d\d\d+',yyg7DZ8WoGkutANT,p7dwlH1PRStBgyMUW.DOTALL)
							if N6NV3h4fel:
								DIBw28Qfje76bTMzVNYhxrgWmO = '____'+N6NV3h4fel[0]
								break
						for yyg7DZ8WoGkutANT in reversed(Gqnj5sEaUVxevOWlTrRK39oyc):
							N6NV3h4fel = p7dwlH1PRStBgyMUW.findall('\w\w+',yyg7DZ8WoGkutANT,p7dwlH1PRStBgyMUW.DOTALL)
							if N6NV3h4fel:
								xk1eziL5c0lEUjWPfyDQ = N6NV3h4fel[0]
								break
						ZRdFxaH2V6IpbOKrAiLtT = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',FumClwDx46KgJRkpcesO8,p7dwlH1PRStBgyMUW.DOTALL)
						for nnm0BQyagCfYFlHqsr76LbI in ZRdFxaH2V6IpbOKrAiLtT:
							nnm0BQyagCfYFlHqsr76LbI = nnm0BQyagCfYFlHqsr76LbI+'?named='+xk1eziL5c0lEUjWPfyDQ+'__download'+DIBw28Qfje76bTMzVNYhxrgWmO
							M0MFkiKqJDv1aZ4NA396u.append(nnm0BQyagCfYFlHqsr76LbI)
		elif 'slow-motion' in hFYoSTas7WOVnwN:
			hFYoSTas7WOVnwN = hFYoSTas7WOVnwN.replace('<h6 ','==END== ==START==')+'==END=='
			hFYoSTas7WOVnwN = hFYoSTas7WOVnwN.replace('<h3 ','==END== ==START==')+'==END=='
			Uenh1CoZdA = p7dwlH1PRStBgyMUW.findall('==START==(.*?)==END==',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if Uenh1CoZdA:
				for FumClwDx46KgJRkpcesO8 in Uenh1CoZdA:
					if 'href=' not in FumClwDx46KgJRkpcesO8: continue
					oo4WtNHLMORzuxcvVYkGlwKCejB6X = WnNGfosHr5STAq8j7miwyRZ6eOUbV
					Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('slow-motion">(.*?)<',FumClwDx46KgJRkpcesO8,p7dwlH1PRStBgyMUW.DOTALL)
					for yyg7DZ8WoGkutANT in Gqnj5sEaUVxevOWlTrRK39oyc:
						N6NV3h4fel = p7dwlH1PRStBgyMUW.findall('\d\d\d+',yyg7DZ8WoGkutANT,p7dwlH1PRStBgyMUW.DOTALL)
						if N6NV3h4fel:
							oo4WtNHLMORzuxcvVYkGlwKCejB6X = '____'+N6NV3h4fel[0]
							break
					Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('<td>(.*?)</td>.*?href="(http.*?)"',FumClwDx46KgJRkpcesO8,p7dwlH1PRStBgyMUW.DOTALL)
					if Gqnj5sEaUVxevOWlTrRK39oyc:
						for xk1eziL5c0lEUjWPfyDQ,tJUgVF0c3bOw8j69KHezE in Gqnj5sEaUVxevOWlTrRK39oyc:
							tJUgVF0c3bOw8j69KHezE = tJUgVF0c3bOw8j69KHezE+'?named='+xk1eziL5c0lEUjWPfyDQ+'__download'+oo4WtNHLMORzuxcvVYkGlwKCejB6X
							M0MFkiKqJDv1aZ4NA396u.append(tJUgVF0c3bOw8j69KHezE)
					else:
						Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('href="(.*?http.*?)".*?name">(.*?)<',FumClwDx46KgJRkpcesO8,p7dwlH1PRStBgyMUW.DOTALL)
						for tJUgVF0c3bOw8j69KHezE,xk1eziL5c0lEUjWPfyDQ in Gqnj5sEaUVxevOWlTrRK39oyc:
							tJUgVF0c3bOw8j69KHezE = tJUgVF0c3bOw8j69KHezE.strip(kcXMWrwiLDKeBHRsJ)+'?named='+xk1eziL5c0lEUjWPfyDQ+'__download'+oo4WtNHLMORzuxcvVYkGlwKCejB6X
							M0MFkiKqJDv1aZ4NA396u.append(tJUgVF0c3bOw8j69KHezE)
			else:
				Gqnj5sEaUVxevOWlTrRK39oyc = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(\w+)<',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
				for tJUgVF0c3bOw8j69KHezE,xk1eziL5c0lEUjWPfyDQ in Gqnj5sEaUVxevOWlTrRK39oyc:
					tJUgVF0c3bOw8j69KHezE = tJUgVF0c3bOw8j69KHezE.strip(kcXMWrwiLDKeBHRsJ)+'?named='+xk1eziL5c0lEUjWPfyDQ+'__download'
					M0MFkiKqJDv1aZ4NA396u.append(tJUgVF0c3bOw8j69KHezE)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/alz',WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-SEARCH-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content.encode(e87cIA5vwOQLDEP1)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('chevron-select(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if showDialogs and cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		AKrMlOaiGqNBbcuW5eh6y9xJ1Dp,JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb = [],[]
		for eukVjoW67vBiySNXrplDKIZLHU,title in items:
			AKrMlOaiGqNBbcuW5eh6y9xJ1Dp.append(eukVjoW67vBiySNXrplDKIZLHU)
			JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb.append(title)
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر الفلتر المناسب:', JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb)
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
		eukVjoW67vBiySNXrplDKIZLHU = AKrMlOaiGqNBbcuW5eh6y9xJ1Dp[XFaM94cPUCOWQZNIEe8gdJpny1]
	else: eukVjoW67vBiySNXrplDKIZLHU = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	url = pcE6DxaoHBm41WKXjwnk + '/search?s='+search+'&category='+eukVjoW67vBiySNXrplDKIZLHU+'&page=1'
	ctDj2OVRyaUPXCrITmJG(url)
	return
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	tqgKeQMz5XNvBPZAE6DCxfaLbj = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='CATEGORIES':
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'/getposts?'+CdZwuO45sE7UvlbM
	elif type=='FILTERS':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'/getposts?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',vcQbFfCk6T1,201)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,201)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url+'/alz',WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARBLIONZ-FILTERS_MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('AjaxFilteringData(.*?)FilterWord',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	dict = {}
	for name,LgJITEZU95fS2oi8K,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		name = name.replace('اختيار ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		name = name.replace('سنة الإنتاج','السنة')
		items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?</div>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='CATEGORIES':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<=1:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'CATEGORIES___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',vcQbFfCk6T1,201)
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع ',vcQbFfCk6T1,205,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='FILTERS':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع :'+name,vcQbFfCk6T1,204,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			f4qbArVHeaCIiY5nzUR68dFBjsZ9 = f4qbArVHeaCIiY5nzUR68dFBjsZ9.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'+name
			if type=='FILTERS': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,204,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='CATEGORIES' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'modified_filters')
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'/getposts?'+CdZwuO45sE7UvlbM
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,201)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,205,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.replace('=&','=0&')
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	wQyTn0NR9VkaBSCrDzPsqMl = ['category','release-year','genre','Quality']
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	CZewXSEQ3q = CZewXSEQ3q.replace('=0','=')
	CZewXSEQ3q = CZewXSEQ3q.replace('Quality','quality')
	return CZewXSEQ3q