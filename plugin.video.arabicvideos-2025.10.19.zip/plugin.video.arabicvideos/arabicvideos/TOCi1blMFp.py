﻿# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ALMAAREF'
headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_MRF_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text,TB3DI4JWr0NYmik1xO8Kc2):
	if   mode==40: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==41: APpdhB1Fk58MmJH7CjVntowyaY = GhmfN2TgEXLD5CpAJeaY()
	elif mode==42: APpdhB1Fk58MmJH7CjVntowyaY = hx9eaKU0zV1MH(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==43: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==44: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==49: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,49)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'البث الحي لقناة المعارف',WnNGfosHr5STAq8j7miwyRZ6eOUbV,41)
	hx9eaKU0zV1MH(WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
	return
def VWbrg6dnpsAyEejhHS(xCONTFizaKbJS1,Uh587iYLzd4XBGyKP):
	search,sort,PfoN0jKtAm6RVJebuGT,eukVjoW67vBiySNXrplDKIZLHU,rrDOosBtPREMmlSJ6pgik9K7HqazG = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[],[],[],[]
	PN2AmVoTyks5xOR1Ib9BqSQ,Re9dbDl8wiCt = bJlfaY9rk80uXWZzV2oeNBcI(xCONTFizaKbJS1)
	for f4qbArVHeaCIiY5nzUR68dFBjsZ9 in list(Re9dbDl8wiCt.keys()):
		value = Re9dbDl8wiCt[f4qbArVHeaCIiY5nzUR68dFBjsZ9]
		if not value: continue
		if   f4qbArVHeaCIiY5nzUR68dFBjsZ9=='sort': sort = [value]
		elif f4qbArVHeaCIiY5nzUR68dFBjsZ9=='series': PfoN0jKtAm6RVJebuGT = [value]
		elif f4qbArVHeaCIiY5nzUR68dFBjsZ9=='search': search = value
		elif f4qbArVHeaCIiY5nzUR68dFBjsZ9=='category': eukVjoW67vBiySNXrplDKIZLHU = [value]
		elif f4qbArVHeaCIiY5nzUR68dFBjsZ9=='specialist': rrDOosBtPREMmlSJ6pgik9K7HqazG = [value]
	rLqYZOtwMfBVs4k1TpE3X9aDy = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":eukVjoW67vBiySNXrplDKIZLHU,"specialist":rrDOosBtPREMmlSJ6pgik9K7HqazG,"series":PfoN0jKtAm6RVJebuGT,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(Uh587iYLzd4XBGyKP)}}
	rLqYZOtwMfBVs4k1TpE3X9aDy = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(rLqYZOtwMfBVs4k1TpE3X9aDy)
	SOw5EUxC9k = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',SOw5EUxC9k,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	data = IXZpzK7ShaRsAN('dict',piN9Qlah4S)
	return data
def hx9eaKU0zV1MH(xCONTFizaKbJS1,level):
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VWbrg6dnpsAyEejhHS(xCONTFizaKbJS1,'1')
	KDCdHQmgxPE21tYz4VUowSv = UOqp25uxcISGBPlAfbtzCNWXY4nvK['facets']
	if level=='1':
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv['video_categories']
		items = p7dwlH1PRStBgyMUW.findall('<div(.*?)/div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for N6NV3h4fel in items:
			TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',N6NV3h4fel+'<',p7dwlH1PRStBgyMUW.DOTALL)
			if not TAQfygRC4WoHu37SEeZ: TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall('data-value=\\"(.*?)\\">(.*?)<',N6NV3h4fel+'<',p7dwlH1PRStBgyMUW.DOTALL)
			eukVjoW67vBiySNXrplDKIZLHU,title = TAQfygRC4WoHu37SEeZ[0]
			if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
			if not xCONTFizaKbJS1: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,42,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'2','?category='+eukVjoW67vBiySNXrplDKIZLHU)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,42,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'2',xCONTFizaKbJS1+'&category='+eukVjoW67vBiySNXrplDKIZLHU)
	if level=='2':
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv['specialist']
		items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for rrDOosBtPREMmlSJ6pgik9K7HqazG,title in items:
			if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
			if not rrDOosBtPREMmlSJ6pgik9K7HqazG: title = title = 'الجميع'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,42,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'3',xCONTFizaKbJS1+'&specialist='+rrDOosBtPREMmlSJ6pgik9K7HqazG)
	elif level=='3':
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv['series']
		items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for PfoN0jKtAm6RVJebuGT,title in items:
			if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
			if not PfoN0jKtAm6RVJebuGT: title = title = 'الجميع'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,42,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'4',xCONTFizaKbJS1+'&series='+PfoN0jKtAm6RVJebuGT)
	elif level=='4':
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv['sort_video']
		items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for sort,title in items:
			if not sort: continue
			if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,44,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1',xCONTFizaKbJS1+'&sort='+sort)
	return
def ctDj2OVRyaUPXCrITmJG(xCONTFizaKbJS1,Uh587iYLzd4XBGyKP):
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = VWbrg6dnpsAyEejhHS(xCONTFizaKbJS1,Uh587iYLzd4XBGyKP)
	KDCdHQmgxPE21tYz4VUowSv = UOqp25uxcISGBPlAfbtzCNWXY4nvK['template']
	items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,43,J4tO21KYAVdSr67W5NmiD0XhRP)
	KDCdHQmgxPE21tYz4VUowSv = UOqp25uxcISGBPlAfbtzCNWXY4nvK['facets']['pagination']
	items = p7dwlH1PRStBgyMUW.findall('data-page="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for TB3DI4JWr0NYmik1xO8Kc2,title in items:
		if Uh587iYLzd4XBGyKP==TB3DI4JWr0NYmik1xO8Kc2: continue
		if YVzokG2yZqrh3w8bU: title = clFjTSgMODe7Nq0H3Vzs(title)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,44,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,xCONTFizaKbJS1)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALMAAREF-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('<video src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not SOw5EUxC9k: SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('youtube_url.*?(http.*?)&',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	wxT9bCdumN = []
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[0].replace('\/','/')
		wxT9bCdumN.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def GhmfN2TgEXLD5CpAJeaY():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/البث-المباشر-6',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALMAAREF-LIVE-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	url = p7dwlH1PRStBgyMUW.findall('data-item=.*?(http.*?)&',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	url = url[0].replace('\/','/')
	YsRk6pAS7rdcn(url,NTWE764hmOgUtScp2e8r,'live')
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	k9kdjGUZEfCioPaN73QcTxMpy2KHA4 = False
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		k9kdjGUZEfCioPaN73QcTxMpy2KHA4 = True
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	if not k9kdjGUZEfCioPaN73QcTxMpy2KHA4: ctDj2OVRyaUPXCrITmJG('?search='+search,'1')
	else: hx9eaKU0zV1MH('?search='+search,'1')
	return