# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'CIMAWBAS'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_CWB_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = {'Referer':pcE6DxaoHBm41WKXjwnk,'Cookie': 'verified=true'}
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==980: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==981: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==982: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==983: APpdhB1Fk58MmJH7CjVntowyaY = WJhTg9iDoQwPK(url,text)
	elif mode==984: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==989: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,989,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''["']navslide-wrap["'](.*?)</ul>''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,984)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"navslide-divider"(.*?)"navslide-divider"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''["']dropdown-menu["'](.*?)</ul>''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for s5ocIDd4WKuPrV in cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace(s5ocIDd4WKuPrV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if not title: continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,984)
	return
def uJlhLk2Tbcd(url):
	ddOhWH5Aj8lt0FZLxVG,YacIZtAGdEPsFhSe = [],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv and '.php' in str(gg4PIzkHEpv):
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('"presentation"','</ul>')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = [(WnNGfosHr5STAq8j7miwyRZ6eOUbV,KDCdHQmgxPE21tYz4VUowSv)]
		for PiS4p2jAQN,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			ddOhWH5Aj8lt0FZLxVG = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if PiS4p2jAQN: PiS4p2jAQN = PiS4p2jAQN+': '
			for SOw5EUxC9k,title in ddOhWH5Aj8lt0FZLxVG:
				title = PiS4p2jAQN+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,981)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"pm-category-subcats"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if 1 or len(YacIZtAGdEPsFhSe)<30:
			if ddOhWH5Aj8lt0FZLxVG: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
			for SOw5EUxC9k,title in YacIZtAGdEPsFhSe:
				if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,981)
	if not gg4PIzkHEpv and not ZAIyluJa1EWhdB7OHV5CRGSrk: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	global headers
	headers['Referer'] = VVDAncSMUjeu8Ii
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		W67hPCcaOek094 = headers.copy()
		W67hPCcaOek094['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',url,data,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-TITLES-1st')
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-TITLES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	KDCdHQmgxPE21tYz4VUowSv,items = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in YacIZtAGdEPsFhSe: items.append((WnNGfosHr5STAq8j7miwyRZ6eOUbV,SOw5EUxC9k,title))
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-carousel_featured"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if len(cKUQVwTMe9tZSY)>1: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[1]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-grid"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if KDCdHQmgxPE21tYz4VUowSv and not items: items = p7dwlH1PRStBgyMUW.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: return
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		J4tO21KYAVdSr67W5NmiD0XhRP += '|Referer='+VVDAncSMUjeu8Ii
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,982,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,982,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,983,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,983,J4tO21KYAVdSr67W5NmiD0XhRP)
	if 1:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=='#': continue
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,981)
	return
def WJhTg9iDoQwPK(url,LW28MawRZDVkYCSjX):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-EPISODES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	bLhqw36zAp7uKxJIM4r502UGRT = p7dwlH1PRStBgyMUW.findall('preview_image_url: "(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	J4tO21KYAVdSr67W5NmiD0XhRP = bLhqw36zAp7uKxJIM4r502UGRT[0] if bLhqw36zAp7uKxJIM4r502UGRT else WnNGfosHr5STAq8j7miwyRZ6eOUbV
	J4tO21KYAVdSr67W5NmiD0XhRP += '|Referer='+VVDAncSMUjeu8Ii
	items = []
	H86WsicYNlU7Iurpy23ZAL5PxSnVhf = False
	if gg4PIzkHEpv and not LW28MawRZDVkYCSjX:
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for LW28MawRZDVkYCSjX,title in items:
			LW28MawRZDVkYCSjX = LW28MawRZDVkYCSjX.strip('#')
			if len(items)>1: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,983,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,LW28MawRZDVkYCSjX)
			else: H86WsicYNlU7Iurpy23ZAL5PxSnVhf = True
	else: H86WsicYNlU7Iurpy23ZAL5PxSnVhf = True
	ZAIyluJa1EWhdB7OHV5CRGSrk = []
	if LW28MawRZDVkYCSjX: ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('id="'+LW28MawRZDVkYCSjX+'"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not ZAIyluJa1EWhdB7OHV5CRGSrk:
		ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"AiredEPS"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if ZAIyluJa1EWhdB7OHV5CRGSrk:
			KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				title = title.replace('</em><span>',kcXMWrwiLDKeBHRsJ)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,982,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif ZAIyluJa1EWhdB7OHV5CRGSrk and H86WsicYNlU7Iurpy23ZAL5PxSnVhf:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if YacIZtAGdEPsFhSe:
			yywmpF8z5X,g6gXnEvHNOo8jPeUqJf1zM = zip(*YacIZtAGdEPsFhSe)
			zbVOS4mL1R8 = [J4tO21KYAVdSr67W5NmiD0XhRP]*len(YacIZtAGdEPsFhSe)
			items = zip(g6gXnEvHNOo8jPeUqJf1zM,yywmpF8z5X,zbVOS4mL1R8)
		if not items: items = p7dwlH1PRStBgyMUW.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			J4tO21KYAVdSr67W5NmiD0XhRP += '|Referer='+VVDAncSMUjeu8Ii
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
			title = title.replace('</em><span>',kcXMWrwiLDKeBHRsJ)
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,982,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN,kKibU78Vp1CHjft3I = [],[]
	piN9Qlah4S = ''
	if 'post=' in piN9Qlah4S:
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('id="player".*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		SOw5EUxC9k = SOw5EUxC9k[0]
		dHqBsvSieRxmbAPXVJ0o = SOw5EUxC9k.split('post=')[1]
		dHqBsvSieRxmbAPXVJ0o = uvGCPpFwVmTQ36.b64decode(dHqBsvSieRxmbAPXVJ0o)
		if rJ2oTLqabRtA: dHqBsvSieRxmbAPXVJ0o = dHqBsvSieRxmbAPXVJ0o.decode(e87cIA5vwOQLDEP1)
		dHqBsvSieRxmbAPXVJ0o = IXZpzK7ShaRsAN('dict',dHqBsvSieRxmbAPXVJ0o)
		laAHpo1bzyM0q = dHqBsvSieRxmbAPXVJ0o['servers']
		trNPCKLEgm = list(laAHpo1bzyM0q.keys())
		laAHpo1bzyM0q = list(laAHpo1bzyM0q.values())
		bOl24a1PcFMgTZ0fzEoKN = zip(trNPCKLEgm,laAHpo1bzyM0q)
		for title,SOw5EUxC9k in bOl24a1PcFMgTZ0fzEoKN:
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
			wxT9bCdumN.append(SOw5EUxC9k)
	else:
		vcQbFfCk6T1 = url.replace('watch.php','see.php')
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMAWBAS-PLAY2-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('"embedURL" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if 0 and SOw5EUxC9k:
			SOw5EUxC9k = SOw5EUxC9k[0]
			if SOw5EUxC9k not in kKibU78Vp1CHjft3I:
				kKibU78Vp1CHjft3I.append(SOw5EUxC9k)
				VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
				SOw5EUxC9k = SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__embed'
				wxT9bCdumN.append(SOw5EUxC9k)
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('list_server(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall("<iframe src='(.*?)'.*?<strong>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k in kKibU78Vp1CHjft3I: continue
				kKibU78Vp1CHjft3I.append(SOw5EUxC9k)
				VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
				SOw5EUxC9k = SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__watch'
				wxT9bCdumN.append(SOw5EUxC9k)
		vcQbFfCk6T1 = url.replace('watch.php','downloads.php')
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,False,'CIMAWBAS-PLAY-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-download"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<strong>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if not items: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k in kKibU78Vp1CHjft3I: continue
				kKibU78Vp1CHjft3I.append(SOw5EUxC9k)
				VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
				SOw5EUxC9k = SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__download'
				wxT9bCdumN.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/search.php?keywords='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return