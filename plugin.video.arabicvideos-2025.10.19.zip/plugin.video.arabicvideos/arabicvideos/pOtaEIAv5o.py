# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'YOUTUBE'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_YUT_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
jguQzABb7ECNTSMJnPL03r = 0
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text,type,TB3DI4JWr0NYmik1xO8Kc2,name,bLhqw36zAp7uKxJIM4r502UGRT):
	if	 mode==140: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==141: APpdhB1Fk58MmJH7CjVntowyaY = ilzWPMZQ6CtHhcb(url,name,bLhqw36zAp7uKxJIM4r502UGRT)
	elif mode==143: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,type)
	elif mode==144: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2,text)
	elif mode==145: APpdhB1Fk58MmJH7CjVntowyaY = CCFzOVIEMflLT98hj3kH0174vrgt(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==147: APpdhB1Fk58MmJH7CjVntowyaY = uSG6Vp4LvUMDbcsJzN9m31ynjIT7ot()
	elif mode==148: APpdhB1Fk58MmJH7CjVntowyaY = FfUvSy5WOGbA()
	elif mode==149: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	if 0:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'قائمة 1',pcE6DxaoHBm41WKXjwnk+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'قائمة 2',pcE6DxaoHBm41WKXjwnk+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'شخص',pcE6DxaoHBm41WKXjwnk+'/user/TCNofficial',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'موقع',pcE6DxaoHBm41WKXjwnk+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'حساب',pcE6DxaoHBm41WKXjwnk+'/@TheSocialCTV',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'العاب',pcE6DxaoHBm41WKXjwnk+'/gaming',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'افلام',pcE6DxaoHBm41WKXjwnk+'/feed/storefront',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مختارات',pcE6DxaoHBm41WKXjwnk+'/feed/guide_builder',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'قصيرة',pcE6DxaoHBm41WKXjwnk+'/shorts',144,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'تصفح',pcE6DxaoHBm41WKXjwnk+'/youtubei/v1/guide?key=',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'رئيسية',pcE6DxaoHBm41WKXjwnk+WnNGfosHr5STAq8j7miwyRZ6eOUbV,144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'رائج',pcE6DxaoHBm41WKXjwnk+'/feed/trending?bp=',144)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,149,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الرائجة',pcE6DxaoHBm41WKXjwnk+'/feed/trending',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'التصفح',pcE6DxaoHBm41WKXjwnk+'/youtubei/v1/guide?key=',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'القصيرة',pcE6DxaoHBm41WKXjwnk+'/shorts',144,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مختارات يوتيوب',pcE6DxaoHBm41WKXjwnk+'/feed/guide_builder',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مختارات البرنامج',WnNGfosHr5STAq8j7miwyRZ6eOUbV,290)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: قنوات عربية',WnNGfosHr5STAq8j7miwyRZ6eOUbV,147)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: قنوات أجنبية',WnNGfosHr5STAq8j7miwyRZ6eOUbV,148)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: افلام عربية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=فيلم',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: افلام اجنبية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=movie',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: مسرحيات عربية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=مسرحية',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: مسلسلات عربية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: مسلسلات اجنبية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=series&sp=EgIQAw==',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: مسلسلات كارتون',pcE6DxaoHBm41WKXjwnk+'/results?search_query=كارتون&sp=EgIQAw==',144)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث: خطبة المرجعية',pcE6DxaoHBm41WKXjwnk+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def ilzWPMZQ6CtHhcb(url,name,bLhqw36zAp7uKxJIM4r502UGRT):
	name = Ye7QMduPDEiphaUy5R9OVSIgx(name)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'CHNL:  '+name,url,144,bLhqw36zAp7uKxJIM4r502UGRT)
	return
def uSG6Vp4LvUMDbcsJzN9m31ynjIT7ot():
	ctDj2OVRyaUPXCrITmJG(pcE6DxaoHBm41WKXjwnk+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def FfUvSy5WOGbA():
	ctDj2OVRyaUPXCrITmJG(pcE6DxaoHBm41WKXjwnk+'/results?search_query=tv&sp=EgJAAQ==')
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,type):
	url = url.split('&',1)[0]
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L([url],NTWE764hmOgUtScp2e8r,type,url)
	return
def HuEpjS6blTrdPwts2I7BMeRm50n(XNAE15HkvKGit,url,veLqt1DZI6N8a):
	level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = veLqt1DZI6N8a.split('::')
	TWpaht15Mc3sgVu84ZdveBmR6lxzI,oWBb4icAKHzj8Ef21XgQ = [],[]
	if '/youtubei/v1/browse' in url: TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['onResponseReceivedCommands']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['entries']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['items'][3]['guideSectionRenderer']['items']")
	A5Cbm84x0yqVfLrXwSBHnzl1FeUkE,qRyc60dEa9VD4pxIJnhBTGvOMrL1,pcLFPBzuxv4 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(XNAE15HkvKGit,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	if level=='1' and A5Cbm84x0yqVfLrXwSBHnzl1FeUkE:
		if len(qRyc60dEa9VD4pxIJnhBTGvOMrL1)>1 and 'search_query' not in url:
			for tSoDe0Mjmk in range(len(qRyc60dEa9VD4pxIJnhBTGvOMrL1)):
				gUsGNDuCK387y = str(tSoDe0Mjmk)
				TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['reloadContinuationItemsCommand']['continuationItems']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['command']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]")
				FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,N6NV3h4fel,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(qRyc60dEa9VD4pxIJnhBTGvOMrL1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
				if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: oWBb4icAKHzj8Ef21XgQ.append([N6NV3h4fel,url,'2::'+gUsGNDuCK387y+'::0::0'])
			TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yccc['continuationEndpoint']")
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,N6NV3h4fel,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(XNAE15HkvKGit,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
			if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy and oWBb4icAKHzj8Ef21XgQ and 'continuationCommand' in list(N6NV3h4fel.keys()):
				SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/my_main_page_shorts_link'
				oWBb4icAKHzj8Ef21XgQ.append([N6NV3h4fel,SOw5EUxC9k,'1::0::0::0'])
	return qRyc60dEa9VD4pxIJnhBTGvOMrL1,A5Cbm84x0yqVfLrXwSBHnzl1FeUkE,oWBb4icAKHzj8Ef21XgQ,pcLFPBzuxv4
def DDujdWvniOR(XNAE15HkvKGit,qRyc60dEa9VD4pxIJnhBTGvOMrL1,url,veLqt1DZI6N8a):
	level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = veLqt1DZI6N8a.split('::')
	TWpaht15Mc3sgVu84ZdveBmR6lxzI,AUCbGcgjMiyzw0nWrqdo = [],[]
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[0]['itemSectionRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['reloadContinuationItemsCommand']['continuationItems']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd["+gUsGNDuCK387y+"]")
	MbyOBwkU3GdWiP4vIEj9XV,DLzvN6u0TJP,EZycCSBTvr3lfmg4PKRku5za = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(qRyc60dEa9VD4pxIJnhBTGvOMrL1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	if level=='2' and MbyOBwkU3GdWiP4vIEj9XV:
		if len(DLzvN6u0TJP)>1:
			for tSoDe0Mjmk in range(len(DLzvN6u0TJP)):
				j9jfsKizR6NUx0Qlav = str(tSoDe0Mjmk)
				TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['richSectionRenderer']['content']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['richItemRenderer']['content']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]")
				FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,N6NV3h4fel,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(DLzvN6u0TJP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
				if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: AUCbGcgjMiyzw0nWrqdo.append([N6NV3h4fel,url,'3::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::0'])
			TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yddd[1]")
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,N6NV3h4fel,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(qRyc60dEa9VD4pxIJnhBTGvOMrL1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
			if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy and AUCbGcgjMiyzw0nWrqdo and 'continuationItemRenderer' in list(N6NV3h4fel.keys()):
				AUCbGcgjMiyzw0nWrqdo.append([N6NV3h4fel,url,'3::0::0::0'])
	return DLzvN6u0TJP,MbyOBwkU3GdWiP4vIEj9XV,AUCbGcgjMiyzw0nWrqdo,EZycCSBTvr3lfmg4PKRku5za
def Ve8m0vysnpkTqFIPZrWloB2A9(XNAE15HkvKGit,DLzvN6u0TJP,url,veLqt1DZI6N8a):
	level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = veLqt1DZI6N8a.split('::')
	TWpaht15Mc3sgVu84ZdveBmR6lxzI,So5rWmTqvdMKfLiQBcjJO4bV = [],[]
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['reelShelfRenderer']['items']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee["+j9jfsKizR6NUx0Qlav+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yeee")
	kTm0WeSlLh9jK3,VXu7jWlA45amzTIJskGpyLSxgtBR,BF9je4oE7DxYJ1nk5lXTa6 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(DLzvN6u0TJP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	if level=='3' and kTm0WeSlLh9jK3:
		if len(VXu7jWlA45amzTIJskGpyLSxgtBR)>0:
			for tSoDe0Mjmk in range(len(VXu7jWlA45amzTIJskGpyLSxgtBR)):
				kkuZ9oimbxSAhBdE3tJn = str(tSoDe0Mjmk)
				TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yfff["+kkuZ9oimbxSAhBdE3tJn+"]['richItemRenderer']['content']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yfff["+kkuZ9oimbxSAhBdE3tJn+"]['gameCardRenderer']['game']")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yfff["+kkuZ9oimbxSAhBdE3tJn+"]['itemSectionRenderer']['contents'][0]")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yfff["+kkuZ9oimbxSAhBdE3tJn+"]")
				TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yfff")
				FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,N6NV3h4fel,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(VXu7jWlA45amzTIJskGpyLSxgtBR,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
				if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: So5rWmTqvdMKfLiQBcjJO4bV.append([N6NV3h4fel,url,'4::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn])
	return VXu7jWlA45amzTIJskGpyLSxgtBR,kTm0WeSlLh9jK3,So5rWmTqvdMKfLiQBcjJO4bV,BF9je4oE7DxYJ1nk5lXTa6
def GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN,u3R7mtYHcLvn12aekDzjfJw065C):
	XNAE15HkvKGit,V6QAOWYLrf53bSFCnN = xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN
	qRyc60dEa9VD4pxIJnhBTGvOMrL1,V6QAOWYLrf53bSFCnN = xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN
	DLzvN6u0TJP,V6QAOWYLrf53bSFCnN = xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN
	VXu7jWlA45amzTIJskGpyLSxgtBR,V6QAOWYLrf53bSFCnN = xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN
	N6NV3h4fel,wZvJSLbIsqAmh6 = xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN
	count = len(u3R7mtYHcLvn12aekDzjfJw065C)
	for zuEo6GDeAR5Z in range(count):
		try:
			Bui7DzlJkPM0 = eval(u3R7mtYHcLvn12aekDzjfJw065C[zuEo6GDeAR5Z])
			return True,Bui7DzlJkPM0,zuEo6GDeAR5Z+1
		except: pass
	return False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,0
def ctDj2OVRyaUPXCrITmJG(url,veLqt1DZI6N8a=WnNGfosHr5STAq8j7miwyRZ6eOUbV,data=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	oWBb4icAKHzj8Ef21XgQ,AUCbGcgjMiyzw0nWrqdo,So5rWmTqvdMKfLiQBcjJO4bV = [],[],[]
	if '::' not in veLqt1DZI6N8a: veLqt1DZI6N8a = '1::0::0::0'
	level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = veLqt1DZI6N8a.split('::')
	if level=='4': level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = '1',gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn
	data = data.replace('_REMEMBERRESULTS_',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	piN9Qlah4S,XNAE15HkvKGit,bZ0VWjAHm1v2Csroh = H34SveQcGOzxfCd(url,data)
	veLqt1DZI6N8a = level+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
	if level in ['1','2','3']:
		qRyc60dEa9VD4pxIJnhBTGvOMrL1,A5Cbm84x0yqVfLrXwSBHnzl1FeUkE,oWBb4icAKHzj8Ef21XgQ,pcLFPBzuxv4 = HuEpjS6blTrdPwts2I7BMeRm50n(XNAE15HkvKGit,url,veLqt1DZI6N8a)
		if not A5Cbm84x0yqVfLrXwSBHnzl1FeUkE: return
		Y3GZTIN6HOu = len(oWBb4icAKHzj8Ef21XgQ)
		if Y3GZTIN6HOu<2:
			if level=='1': level = '2'
			oWBb4icAKHzj8Ef21XgQ = []
	veLqt1DZI6N8a = level+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
	if level in ['2','3']:
		DLzvN6u0TJP,MbyOBwkU3GdWiP4vIEj9XV,AUCbGcgjMiyzw0nWrqdo,EZycCSBTvr3lfmg4PKRku5za = DDujdWvniOR(XNAE15HkvKGit,qRyc60dEa9VD4pxIJnhBTGvOMrL1,url,veLqt1DZI6N8a)
		if not MbyOBwkU3GdWiP4vIEj9XV: return
		d5hO8WB9ipD03Z1CaFSwUVm4eXG = len(AUCbGcgjMiyzw0nWrqdo)
		if d5hO8WB9ipD03Z1CaFSwUVm4eXG<2:
			if level=='2': level = '3'
			AUCbGcgjMiyzw0nWrqdo = []
	veLqt1DZI6N8a = level+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
	if level in ['3']:
		VXu7jWlA45amzTIJskGpyLSxgtBR,kTm0WeSlLh9jK3,So5rWmTqvdMKfLiQBcjJO4bV,BF9je4oE7DxYJ1nk5lXTa6 = Ve8m0vysnpkTqFIPZrWloB2A9(XNAE15HkvKGit,DLzvN6u0TJP,url,veLqt1DZI6N8a)
		if not kTm0WeSlLh9jK3: return
		WuixHRAjlh6DKJks = len(So5rWmTqvdMKfLiQBcjJO4bV)
	for N6NV3h4fel,url,veLqt1DZI6N8a in oWBb4icAKHzj8Ef21XgQ+AUCbGcgjMiyzw0nWrqdo+So5rWmTqvdMKfLiQBcjJO4bV:
		AYNw6tITVipuHFjKqv3O = WnPBv0HZ4mgpMc26GKYEXFO(N6NV3h4fel,url,veLqt1DZI6N8a)
	return
def WnPBv0HZ4mgpMc26GKYEXFO(N6NV3h4fel,url=WnNGfosHr5STAq8j7miwyRZ6eOUbV,veLqt1DZI6N8a=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if '::' in veLqt1DZI6N8a: level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = veLqt1DZI6N8a.split('::')
	else: level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = '1','0','0','0'
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,count,gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy,O5OrgV2w9bahdtoZPA,ccaIOZYory7fd = cmeGRNZFv0j(N6NV3h4fel)
	dTftrq1upoYPkXwM = '/videos?' in SOw5EUxC9k or '/streams?' in SOw5EUxC9k or '/playlists?' in SOw5EUxC9k
	ICtGWoUnNKBmsrjOhzduRyEAc34l2T = '/channels?' in SOw5EUxC9k or '/shorts?' in SOw5EUxC9k
	if dTftrq1upoYPkXwM or ICtGWoUnNKBmsrjOhzduRyEAc34l2T: SOw5EUxC9k = url
	dTftrq1upoYPkXwM = 'watch?v=' not in SOw5EUxC9k and '/playlist?list=' not in SOw5EUxC9k
	ICtGWoUnNKBmsrjOhzduRyEAc34l2T = '/gaming' not in SOw5EUxC9k  and '/feed/storefront' not in SOw5EUxC9k
	if veLqt1DZI6N8a[0:5]=='3::0::' and dTftrq1upoYPkXwM and ICtGWoUnNKBmsrjOhzduRyEAc34l2T: SOw5EUxC9k = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in SOw5EUxC9k:
		level,gUsGNDuCK387y,j9jfsKizR6NUx0Qlav,kkuZ9oimbxSAhBdE3tJn = '1','0','0','0'
		veLqt1DZI6N8a = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	bZ0VWjAHm1v2Csroh = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if '/youtubei/v1/browse' in SOw5EUxC9k or '/youtubei/v1/search' in SOw5EUxC9k or '/my_main_page_shorts_link' in url:
		data = G3yDpvxOiSWdAeL.getSetting('av.youtube.data')
		if data.count(':::')==4:
			bbtlZdiH7PUvNyFY2AjnMEh0,key,nASIK1shLvYcfNW,PUu3nbeYDvfHS,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = data.split(':::')
			bZ0VWjAHm1v2Csroh = bbtlZdiH7PUvNyFY2AjnMEh0+':::'+key+':::'+nASIK1shLvYcfNW+':::'+PUu3nbeYDvfHS+':::'+ccaIOZYory7fd
			if '/my_main_page_shorts_link' in url and not SOw5EUxC9k: SOw5EUxC9k = url
			else: SOw5EUxC9k = SOw5EUxC9k+'?key='+key
	if not title:
		global jguQzABb7ECNTSMJnPL03r
		jguQzABb7ECNTSMJnPL03r += 1
		title = 'فيديوهات '+str(jguQzABb7ECNTSMJnPL03r)
		veLqt1DZI6N8a = '3'+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
	if not FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: return False
	elif 'searchPyvRenderer' in str(N6NV3h4fel): return False
	elif '/about' in SOw5EUxC9k: return False
	elif '/community' in SOw5EUxC9k: return False
	elif 'continuationItemRenderer' in list(N6NV3h4fel.keys()) or 'continuationCommand' in list(N6NV3h4fel.keys()):
		if int(level)>1: level = str(int(level)-1)
		veLqt1DZI6N8a = level+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: '+'صفحة أخرى',SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a,bZ0VWjAHm1v2Csroh)
	elif '/search' in SOw5EUxC9k:
		title = ':: '+title
		veLqt1DZI6N8a = '3'+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
		url = url.replace('/search',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,145,WnNGfosHr5STAq8j7miwyRZ6eOUbV,veLqt1DZI6N8a,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not SOw5EUxC9k:
		veLqt1DZI6N8a = '3'+'::'+gUsGNDuCK387y+'::'+j9jfsKizR6NUx0Qlav+'::'+kkuZ9oimbxSAhBdE3tJn
		title = ':: '+title
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a,bZ0VWjAHm1v2Csroh)
	elif '/browse' in SOw5EUxC9k and url==pcE6DxaoHBm41WKXjwnk:
		title = ':: '+title
		veLqt1DZI6N8a = '2::0::0::0'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a,bZ0VWjAHm1v2Csroh)
	elif not SOw5EUxC9k and 'horizontalMovieListRenderer' in str(N6NV3h4fel):
		title = ':: '+title
		veLqt1DZI6N8a = '3::0::0::0'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a)
	elif 'messageRenderer' in str(N6NV3h4fel):
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	elif EEukrF0h9dNfwzbmPcy:
		octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+EEukrF0h9dNfwzbmPcy+title,SOw5EUxC9k,143,J4tO21KYAVdSr67W5NmiD0XhRP)
	elif '/playlist?list=' in SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k.replace('&playnext=1',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'LIST'+count+':  '+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a)
	elif '/shorts/' in SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k.split('&list=',1)[0]
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,143,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
	elif '/watch?v=' in SOw5EUxC9k:
		if '&list=' in SOw5EUxC9k and count:
			jjdA0oi2OmxQu8qSvYFteZ = SOw5EUxC9k.split('&list=',1)[1]
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/playlist?list='+jjdA0oi2OmxQu8qSvYFteZ
			veLqt1DZI6N8a = '1::0::0::0'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'LIST'+count+':  '+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a)
		else:
			SOw5EUxC9k = SOw5EUxC9k.split('&list=',1)[0]
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,143,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
	elif '/channel/' in SOw5EUxC9k or '/c/' in SOw5EUxC9k or ('/@' in SOw5EUxC9k and SOw5EUxC9k.count('/')==3):
		if YVzokG2yZqrh3w8bU:
			title = title.decode(e87cIA5vwOQLDEP1).encode('raw_unicode_escape')
			title = clFjTSgMODe7Nq0H3Vzs(title)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'CHNL'+count+':  '+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a)
	elif '/user/' in SOw5EUxC9k:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'USER'+count+':  '+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a)
	else:
		if not SOw5EUxC9k: SOw5EUxC9k = url
		title = ':: '+title
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,144,J4tO21KYAVdSr67W5NmiD0XhRP,veLqt1DZI6N8a,bZ0VWjAHm1v2Csroh)
	return True
def cmeGRNZFv0j(N6NV3h4fel):
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,count,gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy,O5OrgV2w9bahdtoZPA,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if not isinstance(N6NV3h4fel,dict): return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,count,gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy,O5OrgV2w9bahdtoZPA,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
	for NTGxFOiCs73KBny in list(N6NV3h4fel.keys()):
		wZvJSLbIsqAmh6 = N6NV3h4fel[NTGxFOiCs73KBny]
		if isinstance(wZvJSLbIsqAmh6,dict): break
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['header']['richListHeaderRenderer']['title']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['headline']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['unplayableText']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['formattedTitle']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['title']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['title']['runs'][0]['text']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['text']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['text']['runs'][0]['text']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['title']['content']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['title']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("item['title']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("item['reelWatchEndpoint']['videoId']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,title,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("item['commandMetadata']['webCommandMetadata']['url']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,SOw5EUxC9k,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnail']['thumbnails'][0]['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,J4tO21KYAVdSr67W5NmiD0XhRP,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['videoCountShortText']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['videoCountText']['runs'][0]['text']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['videoCount']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,count,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['lengthText']['simpleText']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,gJVpmQ1oYbrkHaKnS4N3v2z,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	TWpaht15Mc3sgVu84ZdveBmR6lxzI = []
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	TWpaht15Mc3sgVu84ZdveBmR6lxzI.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H,uOFd6U75e4ZnqADYk8j9 = GaPlQ9q4xj8XuwmZLFbY6id1h2kfNT(N6NV3h4fel,wZvJSLbIsqAmh6,TWpaht15Mc3sgVu84ZdveBmR6lxzI)
	if 'LIVE' in gJVpmQ1oYbrkHaKnS4N3v2z: gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy = WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVE:  '
	if 'مباشر' in gJVpmQ1oYbrkHaKnS4N3v2z: gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy = WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVE:  '
	if 'badges' in list(wZvJSLbIsqAmh6.keys()):
		rS9gfQmny63NEUdowcLC2RzW = str(wZvJSLbIsqAmh6['badges'])
		if 'Free with Ads' in rS9gfQmny63NEUdowcLC2RzW: O5OrgV2w9bahdtoZPA = '$:  '
		if 'LIVE' in rS9gfQmny63NEUdowcLC2RzW: EEukrF0h9dNfwzbmPcy = 'LIVE:  '
		if 'Buy' in rS9gfQmny63NEUdowcLC2RzW or 'Rent' in rS9gfQmny63NEUdowcLC2RzW: O5OrgV2w9bahdtoZPA = '$$:  '
		if QPFJWebEqtKMgTy(u'مباشر') in rS9gfQmny63NEUdowcLC2RzW: EEukrF0h9dNfwzbmPcy = 'LIVE:  '
		if QPFJWebEqtKMgTy(u'شراء') in rS9gfQmny63NEUdowcLC2RzW: O5OrgV2w9bahdtoZPA = '$$:  '
		if QPFJWebEqtKMgTy(u'استئجار') in rS9gfQmny63NEUdowcLC2RzW: O5OrgV2w9bahdtoZPA = '$$:  '
		if QPFJWebEqtKMgTy(u'إعلانات') in rS9gfQmny63NEUdowcLC2RzW: O5OrgV2w9bahdtoZPA = '$:  '
	SOw5EUxC9k = clFjTSgMODe7Nq0H3Vzs(SOw5EUxC9k)
	if SOw5EUxC9k and 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
	J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.split('?')[0]
	if  J4tO21KYAVdSr67W5NmiD0XhRP and 'http' not in J4tO21KYAVdSr67W5NmiD0XhRP: J4tO21KYAVdSr67W5NmiD0XhRP = 'https:'+J4tO21KYAVdSr67W5NmiD0XhRP
	title = clFjTSgMODe7Nq0H3Vzs(title)
	if O5OrgV2w9bahdtoZPA: title = O5OrgV2w9bahdtoZPA+title
	gJVpmQ1oYbrkHaKnS4N3v2z = gJVpmQ1oYbrkHaKnS4N3v2z.replace(',',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	count = count.replace(',',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	count = p7dwlH1PRStBgyMUW.findall('\d+',count)
	if count: count = count[0]
	else: count = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	return True,title,SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,count,gJVpmQ1oYbrkHaKnS4N3v2z,EEukrF0h9dNfwzbmPcy,O5OrgV2w9bahdtoZPA,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
def H34SveQcGOzxfCd(url,data=WnNGfosHr5STAq8j7miwyRZ6eOUbV,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if dlPQGb0aC5xmfFwy9ievKTqX==WnNGfosHr5STAq8j7miwyRZ6eOUbV: dlPQGb0aC5xmfFwy9ievKTqX = 'ytInitialData'
	iHYO7Ic9kKUdPsgSCVyR = E1ltCBVyML6PAUNY()
	W67hPCcaOek094 = {'User-Agent':iHYO7Ic9kKUdPsgSCVyR,'Cookie':'PREF=hl=ar'}
	global G3yDpvxOiSWdAeL
	if not data: data = G3yDpvxOiSWdAeL.getSetting('av.youtube.data')
	if data.count(':::')==4: bbtlZdiH7PUvNyFY2AjnMEh0,key,nASIK1shLvYcfNW,PUu3nbeYDvfHS,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = data.split(':::')
	else: bbtlZdiH7PUvNyFY2AjnMEh0,key,nASIK1shLvYcfNW,PUu3nbeYDvfHS,pwNzhAPx5kYU7MEvXR3siJtQ8jn0H = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	bZ0VWjAHm1v2Csroh = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":nASIK1shLvYcfNW}}}
	if url==pcE6DxaoHBm41WKXjwnk+'/shorts' or '/my_main_page_shorts_link' in url:
		url = pcE6DxaoHBm41WKXjwnk+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		bZ0VWjAHm1v2Csroh['sequenceParams'] = bbtlZdiH7PUvNyFY2AjnMEh0
		bZ0VWjAHm1v2Csroh = str(bZ0VWjAHm1v2Csroh)
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',url,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = pcE6DxaoHBm41WKXjwnk+'/youtubei/v1/guide?key='+key
		bZ0VWjAHm1v2Csroh = str(bZ0VWjAHm1v2Csroh)
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',url,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and bbtlZdiH7PUvNyFY2AjnMEh0:
		bZ0VWjAHm1v2Csroh['continuation'] = pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
		bZ0VWjAHm1v2Csroh['context']['client']['visitorData'] = bbtlZdiH7PUvNyFY2AjnMEh0
		bZ0VWjAHm1v2Csroh = str(bZ0VWjAHm1v2Csroh)
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',url,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and PUu3nbeYDvfHS:
		W67hPCcaOek094.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':nASIK1shLvYcfNW})
		W67hPCcaOek094.update({'Cookie':'VISITOR_INFO1_LIVE='+PUu3nbeYDvfHS})
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'YOUTUBE-GET_PAGE_DATA-6th')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall('"innertubeApiKey".*?"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.I)
	if TAQfygRC4WoHu37SEeZ: key = TAQfygRC4WoHu37SEeZ[0]
	TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall('"cver".*?"value".*?"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.I)
	if TAQfygRC4WoHu37SEeZ: nASIK1shLvYcfNW = TAQfygRC4WoHu37SEeZ[0]
	TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall('"visitorData".*?"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.I)
	if TAQfygRC4WoHu37SEeZ: bbtlZdiH7PUvNyFY2AjnMEh0 = TAQfygRC4WoHu37SEeZ[0]
	cookies = WadGEeh1MBIXkpfP38qAv7ryslY.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): PUu3nbeYDvfHS = cookies['VISITOR_INFO1_LIVE']
	KnEazvPsXD8IGpThxi96Lfb = bbtlZdiH7PUvNyFY2AjnMEh0+':::'+key+':::'+nASIK1shLvYcfNW+':::'+PUu3nbeYDvfHS+':::'+pwNzhAPx5kYU7MEvXR3siJtQ8jn0H
	if dlPQGb0aC5xmfFwy9ievKTqX=='ytInitialData' and 'ytInitialData' in piN9Qlah4S:
		WQKngyGNxsi9bZk = p7dwlH1PRStBgyMUW.findall('window\["ytInitialData"\] = ({.*?});',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not WQKngyGNxsi9bZk: WQKngyGNxsi9bZk = p7dwlH1PRStBgyMUW.findall('var ytInitialData = ({.*?});',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		d2aYjx75lIm1ZGvACWy = IXZpzK7ShaRsAN('str',WQKngyGNxsi9bZk[0])
	elif dlPQGb0aC5xmfFwy9ievKTqX=='ytInitialGuideData' and 'ytInitialGuideData' in piN9Qlah4S:
		WQKngyGNxsi9bZk = p7dwlH1PRStBgyMUW.findall('var ytInitialGuideData = ({.*?});',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		d2aYjx75lIm1ZGvACWy = IXZpzK7ShaRsAN('str',WQKngyGNxsi9bZk[0])
	elif '</script>' not in piN9Qlah4S: d2aYjx75lIm1ZGvACWy = IXZpzK7ShaRsAN('str',piN9Qlah4S)
	else: d2aYjx75lIm1ZGvACWy = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if 0:
		XNAE15HkvKGit = str(d2aYjx75lIm1ZGvACWy)
		if rJ2oTLqabRtA: XNAE15HkvKGit = XNAE15HkvKGit.encode(e87cIA5vwOQLDEP1)
		open('S:\\0000emad.dat','wb').write(XNAE15HkvKGit)
	G3yDpvxOiSWdAeL.setSetting('av.youtube.data',KnEazvPsXD8IGpThxi96Lfb)
	return piN9Qlah4S,d2aYjx75lIm1ZGvACWy,KnEazvPsXD8IGpThxi96Lfb
def CCFzOVIEMflLT98hj3kH0174vrgt(url,veLqt1DZI6N8a):
	search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if not search: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	vcQbFfCk6T1 = url+'/search?query='+search
	ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1,veLqt1DZI6N8a)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not search: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in xCONTFizaKbJS1: vn3RCWDYGVePZKjuB1N = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in xCONTFizaKbJS1: vn3RCWDYGVePZKjuB1N = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in xCONTFizaKbJS1: vn3RCWDYGVePZKjuB1N = '&sp=EgIQAg%253D%253D'
		else: vn3RCWDYGVePZKjuB1N = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1+vn3RCWDYGVePZKjuB1N
	else:
		UtT57VI1Ck9EOadxX4QuPMDNqYFz2,ixQSsf1IyVkJnGYptm,gPvxJw89S35R21zDIbpFYkq7A = [],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV
		pF6lHqMZDxYOEmn9SLf = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		e8DJ9zOtYqf3 = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		kYEpcwGhVsN = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر البحث المناسب',pF6lHqMZDxYOEmn9SLf)
		if kYEpcwGhVsN == -1: return
		RmGTfVlHNCt = e8DJ9zOtYqf3[kYEpcwGhVsN]
		piN9Qlah4S,Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE,data = H34SveQcGOzxfCd(vcQbFfCk6T1+RmGTfVlHNCt)
		if Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE:
			try:
				keOU0L2JMmaH7T = Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for jhgS5mQZW4vCpaJqNwM0PbDktG in range(len(keOU0L2JMmaH7T)):
					group = keOU0L2JMmaH7T[jhgS5mQZW4vCpaJqNwM0PbDktG]['searchFilterGroupRenderer']['filters']
					for cujJ4oA58TIfMdPXELNDySmVxFleat in range(len(group)):
						wZvJSLbIsqAmh6 = group[cujJ4oA58TIfMdPXELNDySmVxFleat]['searchFilterRenderer']
						if 'navigationEndpoint' in list(wZvJSLbIsqAmh6.keys()):
							SOw5EUxC9k = wZvJSLbIsqAmh6['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							SOw5EUxC9k = SOw5EUxC9k.replace('\u0026','&')
							title = wZvJSLbIsqAmh6['tooltip']
							title = title.replace('البحث عن ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								gPvxJw89S35R21zDIbpFYkq7A = title
								ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = SOw5EUxC9k
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								gPvxJw89S35R21zDIbpFYkq7A = title
								ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = SOw5EUxC9k
							if 'Sort by' in title: continue
							UtT57VI1Ck9EOadxX4QuPMDNqYFz2.append(clFjTSgMODe7Nq0H3Vzs(title))
							ixQSsf1IyVkJnGYptm.append(SOw5EUxC9k)
			except: pass
		if not gPvxJw89S35R21zDIbpFYkq7A: KKu4PF7aDJwHzxCjhYZ8 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		else:
			UtT57VI1Ck9EOadxX4QuPMDNqYFz2 = ['بدون فلتر',gPvxJw89S35R21zDIbpFYkq7A]+UtT57VI1Ck9EOadxX4QuPMDNqYFz2
			ixQSsf1IyVkJnGYptm = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr]+ixQSsf1IyVkJnGYptm
			yEF2eXLgGd4tl6rH0kxR5PmUYCjAD = A3DjqpQcnvi6O0oXxGTlz19ytdKu('موقع يوتيوب - اختر الفلتر',UtT57VI1Ck9EOadxX4QuPMDNqYFz2)
			if yEF2eXLgGd4tl6rH0kxR5PmUYCjAD == -1: return
			KKu4PF7aDJwHzxCjhYZ8 = ixQSsf1IyVkJnGYptm[yEF2eXLgGd4tl6rH0kxR5PmUYCjAD]
		if KKu4PF7aDJwHzxCjhYZ8: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = pcE6DxaoHBm41WKXjwnk+KKu4PF7aDJwHzxCjhYZ8
		elif RmGTfVlHNCt: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1+RmGTfVlHNCt
		else: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1
	ctDj2OVRyaUPXCrITmJG(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
	return