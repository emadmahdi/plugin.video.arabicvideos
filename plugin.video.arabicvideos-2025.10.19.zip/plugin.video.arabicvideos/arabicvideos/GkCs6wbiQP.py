# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = YYQS36fyPvtuzcEmRL(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ཆ")
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,ZVk6IphECKLzUceP15j=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==GHg28TBchiyn6l(u"࠴ሞ"): cfU4oM5yYbaKj9Q1lRvrZ30HVSAu(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠶ሟ"): pass
	elif HOkAWvmZSP5c2t9Dq4NgELyps==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠸ሠ"): L6eh8YbJ0EaWDtAnOs(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aiQwFE1TGx04vmLcsYkIW5jA(u"࠳ሡ"): bb4g5LQEcvV7r3mMDfJUhwdFHt1zu()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==gPE1XB87fQl(u"࠵ሢ"): MauNXthKyLozTbvwY1EFf07l5m(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==oiWNFYzcIUeh(u"࠷ሣ"): DSbd8QuMmIEr0s4vBazGN()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠹ሤ"): PfG0vqasTbjuQ4iF2()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==kdRO82AImh0LFw(u"࠻ሥ"): uiHe5Sd8hrIa3YUnDBfLOtQJ1RWbzV()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==A6iX18qgyOFlZxz7sc(u"࠽ሦ"): myp2gWAkfscxU63CIaJNXB14SOoE()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠵࠱ሧ"): lLCqRSF2e1AvPOBIXwY3n0ycsz()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠱࠶࠳ረ"): AHEs8eQdDwK()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==wwWzyF4ZpSQXKOgk569(u"࠲࠷࠵ሩ"): ttS4ZBHmhAszy3()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳࠸࠷ሪ"): g5j7MicqRO18XhICV0nQ()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==mq5t9JXSdHT8yfDVF(u"࠴࠹࠹ራ"): WgqP8i2urSJavBm1()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==kdRO82AImh0LFw(u"࠵࠺࠻ሬ"): M2IB8vFWTfmDztRPqikUAC()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==GHg28TBchiyn6l(u"࠶࠻࠶ር"): UIHYgNczQhT5V61()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==KLX7hW0nBAEgy6m4SvH(u"࠷࠵࠸ሮ"): KrZieMvpBDN()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠱࠶࠺ሯ"): anguRTwBdfmGibW8DK()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==rVy3Ops0mohYkT(u"࠲࠷࠼ሰ"): TT2C9Sml3at(r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==KLX7hW0nBAEgy6m4SvH(u"࠳࠺࠴ሱ"): LL5P4jSOGqebuwTpt()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠴࠻࠶ሲ"): bbeCJKpzMj()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==SI7eBdND4lx8pt5Qk(u"࠵࠼࠸ሳ"): rreTLqOBJcdvh2yA([ZVk6IphECKLzUceP15j],r0D4C3z7Onqpa,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠶࠽࠳ሴ"): MuryTcfZxnmGwIFUSa104E(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬཇ"),r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠷࠷࠵ስ"): MuryTcfZxnmGwIFUSa104E(iySORMYxWXszEH18(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ཈"),r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==pp7FcjEe6g(u"࠱࠸࠷ሶ"): rZvnxKm2btU()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==GHg28TBchiyn6l(u"࠲࠹࠹ሷ"): hNF9z1s6YOuk()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳࠺࠻ሸ"): kbJxKBjfHo8hi73ILAaEdr(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫཉ"))
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠴࠻࠾ሹ"): kbJxKBjfHo8hi73ILAaEdr(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨཊ"))
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠾࠶ሺ"): pUon4NEmqs0JtSHAvCGrc()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠶࠿࠱ሻ"): F8ceQAagG07XiNbStTf()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==Z9FPQvwlbjLTh(u"࠷࠹࠳ሼ"): GbQLnF7HIaN3lpDWMk()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠱࠺࠵ሽ"): tunAJTNPs4wW3xkDIB1G()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==gPE1XB87fQl(u"࠲࠻࠷ሾ"): k18xRz2dML4DquamP3ZOFgev65()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==SI7eBdND4lx8pt5Qk(u"࠳࠼࠹ሿ"): aa9zoF7ghS6GmXrQsYKMuqb()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠴࠽࠻ቀ"): CVOTSWjIfQs6ha3E()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠵࠾࠽ቁ"): GrJLcYZpQxAb4Sz2IaMXNshOKV3y()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aiQwFE1TGx04vmLcsYkIW5jA(u"࠶࠿࠸ቂ"): KqDlQz2xa4cEV()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠷࠹࠺ቃ"): UovJzrY0ETgp9()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==A41nqbj3wYt(u"࠳࠵࠲ቄ"): yyuGOfSc1jMz3dQJPbTC97rYZvnpm(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠴࠶࠴ቅ"): tUbhlG5V9MqwWayB02o3JZADevm()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠵࠷࠶ቆ"): JUCMi86z5tq9wK()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠶࠸࠸ቇ"): KPnyBX0vo7sWwjL1mgzZ3()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==SI7eBdND4lx8pt5Qk(u"࠷࠹࠻ቈ"): DQ7XENnbgcfAm6iJkrKWSBu()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠸࠺࠶቉"): RyDfnmHVzB82J4(KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠹࠴࠸ቊ"): pBw9TxneIRC8(r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==mq5t9JXSdHT8yfDVF(u"࠳࠵࠺ቋ"): U96oTZmqDuV2GXFv1rshxp()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==bawK2j7T81Nrc4GWs05xzDg(u"࠴࠶࠼ቌ"): ubdUHN8VEmDjlRSXo5x(oiWNFYzcIUeh(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧཋ"),r0D4C3z7Onqpa,r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==yobpaW7sBqtKRrv(u"࠷࠳࠴ቍ"): OlCup7qWAPto3jcZT54XV2hKwyM8D()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==bawK2j7T81Nrc4GWs05xzDg(u"࠸࠴࠶቎"): jBWS4aYCRpTqNnd1()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠹࠵࠸቏"): gSP86BM5UWr()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠺࠶࠳ቐ"): HH7hGjplPz6s2CemU0aLuiXF3Zog(UUN4I9unSKWg7c3YizxEmq)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==CyHU86ZeYT5BWRcitSm2I(u"࠻࠰࠵ቑ"): HH7hGjplPz6s2CemU0aLuiXF3Zog(C6MhN2TeZ83GDFngway7EvBYom5i)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠱࠷ቒ"): EftrSmY2hZ0BU6inqFkOdgG74MasX3()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠶࠲࠹ቓ"): XJNduZp9YOfjAB2(r0D4C3z7Onqpa)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==gPE1XB87fQl(u"࠷࠳࠻ቔ"): CRzH4rUJtqkXwsiP()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠸࠴࠽ቕ"): wwcmO3diofI5a8AV()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠵࠵࠸࠰ቖ"): JqzWCRplG5juKeMdioDryZgI9UP()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠶࠶࠲࠲቗"): W7u821VfZksoN0KXD()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aiQwFE1TGx04vmLcsYkIW5jA(u"࠷࠰࠳࠴ቘ"): kbJxKBjfHo8hi73ILAaEdr(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨཌ"))
	elif HOkAWvmZSP5c2t9Dq4NgELyps==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠱࠱࠴࠶቙"): oEsuZ0Uhqv()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==pp7FcjEe6g(u"࠲࠲࠵࠸ቚ"): KXml86H1bJpk9TML3idjaRUzcot7(r0D4C3z7Onqpa)
	return
def KXml86H1bJpk9TML3idjaRUzcot7(showDialogs=KiryBCvngZzF85UN6xSDlOVweL4I9):
	G6etzB4pyPuZYdnMRJ8aw10V2 = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(VP70ytiFNMBl6vHDaW(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡧࡦࡲࡥ࠯࡭ࡨࡽࡧࡵࡡࡳࡦ࡯ࡥࡾࡵࡵࡵࡵࠥࢁࢂ࠭ཌྷ"))
	G6etzB4pyPuZYdnMRJ8aw10V2 = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(G6etzB4pyPuZYdnMRJ8aw10V2)[kdRO82AImh0LFw(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬཎ")][pp7FcjEe6g(u"࠭ࡶࡢ࡮ࡸࡩࠬཏ")]
	choice,LvDEjiM6BH = XURrDCfOS9Mbhpv2Pmjos56TeW,G6etzB4pyPuZYdnMRJ8aw10V2[:]
	if showDialogs:
		X7tOEalyVv6e4zGhu8LJnR9PcSA = KLX7hW0nBAEgy6m4SvH(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡ็ไ฽้ฯ้ࠠฬ฼้้࠭ཐ") if YYQS36fyPvtuzcEmRL(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨད") in G6etzB4pyPuZYdnMRJ8aw10V2 else pp7FcjEe6g(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣฯ๎โโหࠪདྷ")
		choice = tFVmMznSUR3XupZBN9kxcO0EHv(rVy3Ops0mohYkT(u"ࠪࡧࡪࡴࡴࡦࡴࠪན"),yobpaW7sBqtKRrv(u"ࠫำื่อࠩཔ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠬห๊ใษไࠫཕ"),mq5t9JXSdHT8yfDVF(u"࠭สี฼ํ่ࠬབ"),Ew26Hg4SIj,e6HEdvUcaq8Gx+X7tOEalyVv6e4zGhu8LJnR9PcSA+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M+WBDnh75CaLEvkcN6p4ez2KXrV3M+jhDZ0BAFoEGUcw5QrJkaxXL(u"่ࠧา๊ࠤฬู๊่์ไอࠥะำๆฯࠣฬฬูสฯัส้๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦวๅ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊ฯࠦสิฬฺ๎฾ࠦร็ࠢอ฽๊๊ࠠษฯฮࠤๆ๐ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦร้ࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะใหสࠣีุอไสࠢ็่๊ฮัๆฮࠣฬฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧབྷ"))
	if choice==XURrDCfOS9Mbhpv2Pmjos56TeW and Z9FPQvwlbjLTh(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨམ") not in G6etzB4pyPuZYdnMRJ8aw10V2: LvDEjiM6BH = [tzZ6PhyDOUnwLM3pdK(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩཙ")]+G6etzB4pyPuZYdnMRJ8aw10V2
	elif choice==wnaWTQM7VJPkZzO9eoSyFU4 and KLX7hW0nBAEgy6m4SvH(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪཚ") in G6etzB4pyPuZYdnMRJ8aw10V2:
		LvDEjiM6BH = G6etzB4pyPuZYdnMRJ8aw10V2[:]
		LvDEjiM6BH.remove(KLX7hW0nBAEgy6m4SvH(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫཛ"))
	if LvDEjiM6BH!=G6etzB4pyPuZYdnMRJ8aw10V2:
		LvDEjiM6BH = str(LvDEjiM6BH).replace(wwWzyF4ZpSQXKOgk569(u"ࠧ࠭ࠢཛྷ"),mq5t9JXSdHT8yfDVF(u"࠭ࠢࠨཝ"))
		APpdhB1Fk58MmJH7CjVntowyaY = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(A41nqbj3wYt(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠩཞ")+LvDEjiM6BH+CyHU86ZeYT5BWRcitSm2I(u"ࠨࡿࢀࠫཟ"))
		if showDialogs:
			if wwWzyF4ZpSQXKOgk569(u"ࠩࡷࡶࡺ࡫ࠧའ") in str(APpdhB1Fk58MmJH7CjVntowyaY): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,YYQS36fyPvtuzcEmRL(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧཡ"))
			else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,kdRO82AImh0LFw(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩར"))
	return
def oEsuZ0Uhqv():
	ufQ5elFnNp = G3yDpvxOiSWdAeL.getSetting(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩལ"))
	message = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭วๅำๅ้ࠥอไๆฯาำࠥำวๅ์สࠤ์๎ࠠ࠻ࠢࠣࠤࠬཤ")+str(ufQ5elFnNp)+IMjqygdfYSKpHlWu5Aa(u"ࠧࠡ࡭ࡥࡴࡸ࠭ཥ") if ufQ5elFnNp else A6iX18qgyOFlZxz7sc(u"ࠨษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡ็อ์็็ษࠡฯส่๏อࠧས")
	message = e6HEdvUcaq8Gx+message+Z9FPQvwlbjLTh(u"ࠩ࡟ࡲ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅࠢฦ์ࠥะฺ๋์ิࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠨཧ")+YVr6St5P4xsFC0aARQGKfiegD
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(rVy3Ops0mohYkT(u"ࠪࡧࡪࡴࡴࡦࡴࠪཨ"),CyHU86ZeYT5BWRcitSm2I(u"ࠫำื่อࠩཀྵ"),tzZ6PhyDOUnwLM3pdK(u"ࠬห๊ใษไࠫཪ"),ZLr5gRSkFewKdUos90bM(u"࠭สี฼ํ่ࠬཫ"),Ew26Hg4SIj,message+yobpaW7sBqtKRrv(u"ࠧ࡝ࡰ࡟ࡲฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤ์๐ฺࠠ็็๎ฮ๊ࠦใ๊่ࠤอํวࠡษ็ฬึ์วๆฮࠣฬฬิส๋ษิࠤศ฿ไ๊ࠢฯ์ิฯࠠๆฬ๋ๅึฯࠠๅำๅ้ࠥอไอ๊าอࠥอไั์ࠣห๋ะࠠหฯาำ์ࠦแ๋๊ࠢิ์ࠦวๅึสุฮࠦ࠮࠯๋๋ࠢีอࠠๆ฻้ห์ูࠦ็ั่หࠥะโ้็ࠣห๋ะࠠษฬื฾๏๊ࠠโ์า๎ํࠦแศ่ࠣห้ฮั็ษ่ะ๊ࠥๆࠡ์ึวฺ้้่ࠠࠣห้า่ะหࠣห้ะ๊ࠡฬิ๎ิํวࠡๆฦ๊ࠥอไษำ้ห๊าࠠิ๊ไࠤ๏ิสศำࠣห้า่ะหࠣวํะ่ๆษอ๎่๐วࠡ࠰࠱ࠤ฾๊ๅศࠢส๊์๊ࠦอสࠣหำะ๊ศำࠣี็๋ࠠอ๊าอࠥ฻ฺ๋ำࠣษีอࠠไษ้ฮࠥอไฦ่อี๋ะฺ่ࠠา็ࠥฮื๋ศฬࠤศ๎ࠠใๆํ่ฮ࠭ཬ"))
	if UqCAgBwjTuoVyn0evI in [-gPE1XB87fQl(u"࠳ቛ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳ቜ")]: return
	if UqCAgBwjTuoVyn0evI==CyHU86ZeYT5BWRcitSm2I(u"࠵ቝ"):
		ufQ5elFnNp = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊ใษไࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫ཭"))
	else:
		items = [lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫ཮"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪ࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ཯"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭཰"),IMjqygdfYSKpHlWu5Aa(u"ࠬ࠷࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཱ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠱࠳࠷࠳ࠤࡰࡨࡰࡴིࠩ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧ࠲࠷࠳࠴ࠥࡱࡢࡱࡵཱིࠪ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࠳࠺࠹࠵ࠦ࡫ࡣࡲࡶུࠫ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷཱུࠬ"),IMjqygdfYSKpHlWu5Aa(u"ࠪ࠶࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ྲྀ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࠸࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧཷ"),pp7FcjEe6g(u"ࠬ࠹࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨླྀ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࠴࠱࠲࠳ࠤࡰࡨࡰࡴࠩཹ"),kdRO82AImh0LFw(u"ࠧ࠵࠷࠳࠴ࠥࡱࡢࡱࡵེࠪ"),ZLr5gRSkFewKdUos90bM(u"ࠨ࠷࠳࠴࠵ࠦ࡫ࡣࡲࡶཻࠫ"),YYQS36fyPvtuzcEmRL(u"ࠩ࠹࠴࠵࠶ࠠ࡬ࡤࡳࡷོࠬ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠻࠵࠶࠰ࠡ࡭ࡥࡴࡸཽ࠭"),pp7FcjEe6g(u"ࠫ࠽࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧཾ"),GHg28TBchiyn6l(u"ࠬ࠿࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཿ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࠱࠱࠲࠳࠴ࠥࡱࡢࡱࡵྀࠪ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧ࠲࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶཱྀࠫ"),rVy3Ops0mohYkT(u"ࠨ࠳࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬྂ"),oiWNFYzcIUeh(u"ࠩ࠼࠽࠾࠿࠹ࠡ࡭ࡥࡴࡸ࠭ྃ")]
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(bawK2j7T81Nrc4GWs05xzDg(u"ࠪหำะัࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡษ็้๋อำษห྄ࠪ"),items)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-Z9FPQvwlbjLTh(u"࠶቞"): return
		ufQ5elFnNp = str(items[XFaM94cPUCOWQZNIEe8gdJpny1][:-CyHU86ZeYT5BWRcitSm2I(u"࠻቟")])
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"๋ࠫาอหࠢ฼้้๐ษࠡฬื฾๏๊้ࠠฬะำ๏ีࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࡠࡳࡢ࡮ࠨ྅")+e6HEdvUcaq8Gx+ufQ5elFnNp+kdRO82AImh0LFw(u"ࠬࠦ࡫ࡣࡲࡶࠫ྆")+YVr6St5P4xsFC0aARQGKfiegD)
	G3yDpvxOiSWdAeL.setSetting(YYQS36fyPvtuzcEmRL(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ྇"),ufQ5elFnNp)
	return
def W7u821VfZksoN0KXD(UvEK9Nfrw8=KiryBCvngZzF85UN6xSDlOVweL4I9):
	pxRyjXsvqCfbDlkgLFBU0YE = lLcJwOK2p7TvQyqbsdRFiI()
	X7tOEalyVv6e4zGhu8LJnR9PcSA = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ์฼้้࠭ྈ") if pxRyjXsvqCfbDlkgLFBU0YE else tzZ6PhyDOUnwLM3pdK(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใ่ࠢฮํ่แࠨྉ")
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡦࡩࡳࡺࡥࡳࠩྊ"),iySORMYxWXszEH18(u"ࠪาึ๎ฬࠨྋ"),rVy3Ops0mohYkT(u"ࠫส๐โศใࠪྌ"),YYQS36fyPvtuzcEmRL(u"ࠬะิ฻์็ࠫྍ"),Ew26Hg4SIj,e6HEdvUcaq8Gx+X7tOEalyVv6e4zGhu8LJnR9PcSA+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M+beV5l2D8HznyJI0(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭ྎ"))
	if UqCAgBwjTuoVyn0evI==wnaWTQM7VJPkZzO9eoSyFU4: HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬྏ"))
	elif UqCAgBwjTuoVyn0evI==XURrDCfOS9Mbhpv2Pmjos56TeW: HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(mq5t9JXSdHT8yfDVF(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧྐ"))
	if UqCAgBwjTuoVyn0evI in [wnaWTQM7VJPkZzO9eoSyFU4,XURrDCfOS9Mbhpv2Pmjos56TeW]:
		if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡷࡶࡺ࡫ࠧྑ") in str(HeAw9Xf6QCp0uJ1bRvlmi): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,yobpaW7sBqtKRrv(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧྒ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,jhDZ0BAFoEGUcw5QrJkaxXL(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩྒྷ"))
	return
def JqzWCRplG5juKeMdioDryZgI9UP():
	url = A3pXVFdyP1.SITESURLS[bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧྔ")][yobpaW7sBqtKRrv(u"࠰በ")]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,rVy3Ops0mohYkT(u"࠭ࡇࡆࡖࠪྕ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬྖ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	a3kGPwFH65BCEhS = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨྗ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	a3kGPwFH65BCEhS = sorted(a3kGPwFH65BCEhS,reverse=r0D4C3z7Onqpa)
	XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu(A41nqbj3wYt(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫ྘"),a3kGPwFH65BCEhS)
	if XFaM94cPUCOWQZNIEe8gdJpny1>=oiWNFYzcIUeh(u"࠱ቡ"):
		jHfRQTctWU7OCMA = url.rsplit(CyHU86ZeYT5BWRcitSm2I(u"ࠪ࠳ࠬྙ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳ቢ"))[iySORMYxWXszEH18(u"࠳ባ")]+Z9FPQvwlbjLTh(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬྚ")+a3kGPwFH65BCEhS[XFaM94cPUCOWQZNIEe8gdJpny1]+CyHU86ZeYT5BWRcitSm2I(u"ࠬ࠴ࡺࡪࡲࠪྛ")
		succeeded = KKnIuDShcQEovOH32R16rgV8(SI7eBdND4lx8pt5Qk(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫྜ"),jHfRQTctWU7OCMA,r0D4C3z7Onqpa)
		if succeeded:
			G3yDpvxOiSWdAeL.setSetting(VP70ytiFNMBl6vHDaW(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫྜྷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨฬ่ࠤฯัศ๋ฬࠣษฺีวาࠢๅำ๏๋ࠠๅๆหี๋อๅอࠢ࠱࠲๊ࠥใ็ࠢหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬฯำฯ๋อࠣะ๊๐ูࠡษ็ฬึอๅอࠢหหุะฮะษ่ࠤวิัࠡวุำฬืࠠๆฬ๋ๅึࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅ้ำหࠥอไษำ้ห๊าࠠภࠣࠤࠫྞ"))
			if kkLdeyJUsSiK9YwFZr4lPbVE: ubdUHN8VEmDjlRSXo5x(tzZ6PhyDOUnwLM3pdK(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧྟ"),r0D4C3z7Onqpa,r0D4C3z7Onqpa)
	return
def CRzH4rUJtqkXwsiP():
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,SI7eBdND4lx8pt5Qk(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭ྠ"))
	if kkLdeyJUsSiK9YwFZr4lPbVE:
		G3yDpvxOiSWdAeL.setSetting(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩྡ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		G3yDpvxOiSWdAeL.setSetting(Z9FPQvwlbjLTh(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬྡྷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪྣ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨྤ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		G3yDpvxOiSWdAeL.setSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪྥ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫྦ"))
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def EftrSmY2hZ0BU6inqFkOdgG74MasX3():
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,kdRO82AImh0LFw(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨྦྷ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧྨ"))
	oxIMPKyikLHUVdQNTzOWs5S813g = aaSudEO2gkDPeTi41ZMbYtKoNs70l(KiryBCvngZzF85UN6xSDlOVweL4I9)
	KB1ysVC68EeZoa = WBDnh75CaLEvkcN6p4ez2KXrV3M
	wA84aNzSgu2keBEtDR9O = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+pp7FcjEe6g(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩྩ")+YVr6St5P4xsFC0aARQGKfiegD
	nneOp8tCIFPdzlwEuV = WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪྪ")+YVr6St5P4xsFC0aARQGKfiegD+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࡝ࡰ࡟ࡲࠬྫ")
	for id,ofEcIgWvaQizr9uTq8LBApwH0,M9yafHSnNLJowPBFc7WXOgIekrbzE,V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm,reason in reversed(oxIMPKyikLHUVdQNTzOWs5S813g):
		if id==ZLr5gRSkFewKdUos90bM(u"ࠨ࠲ࠪྫྷ"):
			MCKSB1imbP08HdjAue,hhOXld4so9FJYnS3W0tmj = V6lUXTqHAjQv4wg.split(iySORMYxWXszEH18(u"ࠩ࡟ࡲࡀࡁࠧྭ"))
			continue
		if KB1ysVC68EeZoa!=WBDnh75CaLEvkcN6p4ez2KXrV3M: KB1ysVC68EeZoa += nneOp8tCIFPdzlwEuV
		hJaCboEre4Tc6AW8Uz = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩྮ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+id+VP70ytiFNMBl6vHDaW(u"ࠫࠥࡀࠠࠨྯ")+IMjqygdfYSKpHlWu5Aa(u"ࠬอไิฦส่ࠥࡀࠠࠨྰ")+YVr6St5P4xsFC0aARQGKfiegD+M9yafHSnNLJowPBFc7WXOgIekrbzE
		gEbImLX6aAO28D3Pxo5ehjnvu = oiWNFYzcIUeh(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧྱ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪྲ")+YVr6St5P4xsFC0aARQGKfiegD+V6lUXTqHAjQv4wg
		WXZ4HTO7PSFmMp = tzZ6PhyDOUnwLM3pdK(u"ࠨ࡝ࡕࡘࡑࡣࠧླ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩส่ำ฽รࠡ࠼ࠣࠫྴ")+YVr6St5P4xsFC0aARQGKfiegD+Sse7u20tJZbUkIP8Ncm
		Sf8YkqeAlUxWwMvyuiQGL = gPE1XB87fQl(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫྵ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+CyHU86ZeYT5BWRcitSm2I(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭ྶ")+YVr6St5P4xsFC0aARQGKfiegD+reason
		KB1ysVC68EeZoa += hJaCboEre4Tc6AW8Uz+gEbImLX6aAO28D3Pxo5ehjnvu+WBDnh75CaLEvkcN6p4ez2KXrV3M+wA84aNzSgu2keBEtDR9O+WBDnh75CaLEvkcN6p4ez2KXrV3M+WXZ4HTO7PSFmMp+Sf8YkqeAlUxWwMvyuiQGL+WBDnh75CaLEvkcN6p4ez2KXrV3M
	Pgbtx1uwX52DEk7Jf(iySORMYxWXszEH18(u"ࠬࡸࡩࡨࡪࡷࠫྷ"),hhOXld4so9FJYnS3W0tmj,KB1ysVC68EeZoa,YYQS36fyPvtuzcEmRL(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧྸ"))
	return
def HH7hGjplPz6s2CemU0aLuiXF3Zog(file):
	if file==C6MhN2TeZ83GDFngway7EvBYom5i: jhnV1PQ9HdURCDg0 = bawK2j7T81Nrc4GWs05xzDg(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧྐྵ")
	elif file==UUN4I9unSKWg7c3YizxEmq: jhnV1PQ9HdURCDg0 = mq5t9JXSdHT8yfDVF(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨྺ")
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡦࡩࡳࡺࡥࡳࠩྻ"),kdRO82AImh0LFw(u"ุ้ࠪำࠧྼ"),A41nqbj3wYt(u"ࠫส฻ไศฯࠪ྽"),IMjqygdfYSKpHlWu5Aa(u"ࠬิั้ฮࠪ྾"),Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ྿")+jhnV1PQ9HdURCDg0+pp7FcjEe6g(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ࿀"))
	if UqCAgBwjTuoVyn0evI==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠴ቤ"):
		if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(file):
			try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(file)
			except: pass
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭࿁")+jhnV1PQ9HdURCDg0)
	elif UqCAgBwjTuoVyn0evI==aiQwFE1TGx04vmLcsYkIW5jA(u"࠶ብ"):
		data = QSXjgqyaVxPL4(file)
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ࿂")+jhnV1PQ9HdURCDg0)
	return
def jBWS4aYCRpTqNnd1():
	if CCPXJ7wnNLOg0ZoekcmpdSKI<A41nqbj3wYt(u"࠷࠸ቦ"):
		eJU6bsndE1mI0F = beV5l2D8HznyJI0(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭࿃")+str(CCPXJ7wnNLOg0ZoekcmpdSKI)+iySORMYxWXszEH18(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ࿄")
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
		return
	NnA5Md0F2SvJQ = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(A6iX18qgyOFlZxz7sc(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ࿅"))
	jWylPFA81zQGdTDMJ5 = SBguW0zN9UInl([mq5t9JXSdHT8yfDVF(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࿆ࠬ")])
	RsLeaPcMIo23zQEZrv1F9,P23PSrQ8OtYn6CB9ZoGvdUphfNq,Us9LY6pozbwnVt7caQRvFm58k,fbu9osQ5CgNdW38AJnm21DEKiae,r0jgG7uDv1254wpJCFm,ONdp12q9ZyhLQ4DUMBJnV8E35lGiY,BBUyG5N2qRi = jWylPFA81zQGdTDMJ5[IMjqygdfYSKpHlWu5Aa(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿇")]
	if RsLeaPcMIo23zQEZrv1F9 or Z9FPQvwlbjLTh(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ࿈") not in str(NnA5Md0F2SvJQ):
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,IMjqygdfYSKpHlWu5Aa(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ࿉"))
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = gSP86BM5UWr()
		if not FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: return
	w61naW3ET4JCRK8YGHMZxVqbi9tzy(r0D4C3z7Onqpa)
	return
def w61naW3ET4JCRK8YGHMZxVqbi9tzy(showDialogs=r0D4C3z7Onqpa):
	NnA5Md0F2SvJQ = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(SI7eBdND4lx8pt5Qk(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭࿊"))
	if A41nqbj3wYt(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ࿋") not in str(NnA5Md0F2SvJQ):
		if showDialogs:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ࿌"))
		return
	nKh4moEH2YQP1Z = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,GHg28TBchiyn6l(u"࠭ࡡࡥࡦࡲࡲࡸ࠭࿍"),mq5t9JXSdHT8yfDVF(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿎"),beV5l2D8HznyJI0(u"ࠨ࠹࠵࠴ࡵ࠭࿏"),SI7eBdND4lx8pt5Qk(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪ࿐"))
	if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(nKh4moEH2YQP1Z): return
	N70NuMkcZHY = open(nKh4moEH2YQP1Z,wwWzyF4ZpSQXKOgk569(u"ࠪࡶࡧ࠭࿑")).read()
	if rJ2oTLqabRtA: N70NuMkcZHY = N70NuMkcZHY.decode(e87cIA5vwOQLDEP1)
	rliDFfh4XeUBY1kZ7Nj5csdS = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ࿒"),N70NuMkcZHY,p7dwlH1PRStBgyMUW.DOTALL)
	aqtEQO9MAyoHrB,NtvX0phe813 = rliDFfh4XeUBY1kZ7Nj5csdS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	x803xRcMjCqawpGgS = gPE1XB87fQl(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭࿓")+aqtEQO9MAyoHrB+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠬࠨ࿔")+NtvX0phe813+CyHU86ZeYT5BWRcitSm2I(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ࿕")
	if showDialogs:
		YqRr0BXf1p5zLm2usNte = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(gPE1XB87fQl(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭࿖"))
		if YqRr0BXf1p5zLm2usNte==SI7eBdND4lx8pt5Qk(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ࿗"): FoqnfCDW94506bec = IMjqygdfYSKpHlWu5Aa(u"ࠪๆํอฦๆࠢส่่ะวษหࠪ࿘")
		elif YqRr0BXf1p5zLm2usNte==bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ࿙"): FoqnfCDW94506bec = mq5t9JXSdHT8yfDVF(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ࿚")
		else: FoqnfCDW94506bec = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭โ้ษษ้ࠥษฮา๋ࠪ࿛")
		UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿜"),KLX7hW0nBAEgy6m4SvH(u"ࠨไ๋หห๋ࠠฤะิํࠬ࿝"),KLX7hW0nBAEgy6m4SvH(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ࿞"),VP70ytiFNMBl6vHDaW(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ࿟"),A41nqbj3wYt(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ࿠")+FoqnfCDW94506bec,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨ࿡")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+mq5t9JXSdHT8yfDVF(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪ࿢")+YVr6St5P4xsFC0aARQGKfiegD)
		if UqCAgBwjTuoVyn0evI==kdRO82AImh0LFw(u"࠱ቧ"): Im8LcHlNr1aC2DPwqUk = bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ࿣")
		elif UqCAgBwjTuoVyn0evI==pp7FcjEe6g(u"࠳ቨ"): Im8LcHlNr1aC2DPwqUk = mq5t9JXSdHT8yfDVF(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ࿤")
		else: Im8LcHlNr1aC2DPwqUk = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else:
		YqRr0BXf1p5zLm2usNte = G3yDpvxOiSWdAeL.getSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ࿥"))
		if   YqRr0BXf1p5zLm2usNte==WnNGfosHr5STAq8j7miwyRZ6eOUbV: UqCAgBwjTuoVyn0evI = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠲ቩ")
		elif YqRr0BXf1p5zLm2usNte==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭࿦"): UqCAgBwjTuoVyn0evI = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠴ቪ")
		elif YqRr0BXf1p5zLm2usNte==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ࿧"): UqCAgBwjTuoVyn0evI = oiWNFYzcIUeh(u"࠶ቫ")
		Im8LcHlNr1aC2DPwqUk = YqRr0BXf1p5zLm2usNte
	if   UqCAgBwjTuoVyn0evI==wwWzyF4ZpSQXKOgk569(u"࠵ቬ"): pbNr278LAIGvPmunezqkaj4 = wwWzyF4ZpSQXKOgk569(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩ࿨")
	elif UqCAgBwjTuoVyn0evI==Z9FPQvwlbjLTh(u"࠷ቭ"): pbNr278LAIGvPmunezqkaj4 = aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪ࿩")
	elif UqCAgBwjTuoVyn0evI==bawK2j7T81Nrc4GWs05xzDg(u"࠲ቮ"): pbNr278LAIGvPmunezqkaj4 = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫ࿪")
	else: return
	G3yDpvxOiSWdAeL.setSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭࿫"),Im8LcHlNr1aC2DPwqUk)
	dd7C6yXQOGMxmfY = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ࿬")+pbNr278LAIGvPmunezqkaj4+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠰ࠬ࿭")+NtvX0phe813+kdRO82AImh0LFw(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭࿮")
	bmK07sdk8FNynQ45HphU = N70NuMkcZHY.replace(x803xRcMjCqawpGgS,dd7C6yXQOGMxmfY)
	if rJ2oTLqabRtA: bmK07sdk8FNynQ45HphU = bmK07sdk8FNynQ45HphU.encode(e87cIA5vwOQLDEP1)
	open(nKh4moEH2YQP1Z,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡽࡢࠨ࿯")).write(bmK07sdk8FNynQ45HphU)
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ࿰")+pbNr278LAIGvPmunezqkaj4+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࠡ࡟ࠪ࿱"))
	if showDialogs: pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ࿲"))
	return
def OlCup7qWAPto3jcZT54XV2hKwyM8D():
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,kdRO82AImh0LFw(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ࿳"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==aiQwFE1TGx04vmLcsYkIW5jA(u"࠲ቯ"): uiHe5Sd8hrIa3YUnDBfLOtQJ1RWbzV()
	return
def myp2gWAkfscxU63CIaJNXB14SOoE():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭࿴"))
	return
def U96oTZmqDuV2GXFv1rshxp():
	hJaCboEre4Tc6AW8Uz = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+CyHU86ZeYT5BWRcitSm2I(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨ࿵")+YVr6St5P4xsFC0aARQGKfiegD
	hJaCboEre4Tc6AW8Uz += QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫ࿶")
	hJaCboEre4Tc6AW8Uz += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+VP70ytiFNMBl6vHDaW(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷࠫ࿷")+YVr6St5P4xsFC0aARQGKfiegD
	gEbImLX6aAO28D3Pxo5ehjnvu = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨ࿸")+YVr6St5P4xsFC0aARQGKfiegD
	gEbImLX6aAO28D3Pxo5ehjnvu += gPE1XB87fQl(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬ࿹")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+iySORMYxWXszEH18(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩ࿺")+YVr6St5P4xsFC0aARQGKfiegD
	eJU6bsndE1mI0F = wwWzyF4ZpSQXKOgk569(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ࿻")+hJaCboEre4Tc6AW8Uz+rVy3Ops0mohYkT(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ࿼")+gEbImLX6aAO28D3Pxo5ehjnvu
	Pgbtx1uwX52DEk7Jf(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡸࡩࡨࡪࡷࠫ࿽"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,eJU6bsndE1mI0F)
	return
def RyDfnmHVzB82J4(lgB7TOZqEJiMUFedrSHX8j6):
	PzLX0Jg7lIERk1WAeUKQNZV2Bwc(XAGWNdKH4qOPU1YEVQp6)
	oxIMPKyikLHUVdQNTzOWs5S813g = aaSudEO2gkDPeTi41ZMbYtKoNs70l(lgB7TOZqEJiMUFedrSHX8j6)
	for zE4XRrjSYK in [oiWNFYzcIUeh(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ࿾"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ࿿"),IMjqygdfYSKpHlWu5Aa(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭က"),mq5t9JXSdHT8yfDVF(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨခ")]:
		if zE4XRrjSYK in A3pXVFdyP1.SEND_THESE_EVENTS: A3pXVFdyP1.SEND_THESE_EVENTS.remove(zE4XRrjSYK)
	JIpyGT2ZQ9lqoDinAB(A6iX18qgyOFlZxz7sc(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ဂ"))
	id,ofEcIgWvaQizr9uTq8LBApwH0,M9yafHSnNLJowPBFc7WXOgIekrbzE,V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm,reason = oxIMPKyikLHUVdQNTzOWs5S813g[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	MCKSB1imbP08HdjAue,hhOXld4so9FJYnS3W0tmj = V6lUXTqHAjQv4wg.split(tzZ6PhyDOUnwLM3pdK(u"ࠫࡡࡴ࠻࠼ࠩဃ"))
	gEbImLX6aAO28D3Pxo5ehjnvu,WXZ4HTO7PSFmMp,Sf8YkqeAlUxWwMvyuiQGL = Sse7u20tJZbUkIP8Ncm.split(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡢ࡮࠼࠽ࠪင"))
	lmNTQxOIdqGs3 = r0D4C3z7Onqpa
	while lmNTQxOIdqGs3:
		J25pfUM7cPADsSFlxN8rCR0H = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"࠭ฮา๊ฯࠫစ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ဆ"),GHg28TBchiyn6l(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩဇ"),CyHU86ZeYT5BWRcitSm2I(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩဈ"),gEbImLX6aAO28D3Pxo5ehjnvu)
		if J25pfUM7cPADsSFlxN8rCR0H==Z9FPQvwlbjLTh(u"࠴ተ"): WG2t49z5mDiI = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠪ฽ํีษࠨဉ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫည"),WXZ4HTO7PSFmMp,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩဋ"))
		elif J25pfUM7cPADsSFlxN8rCR0H==bawK2j7T81Nrc4GWs05xzDg(u"࠴ቱ"): L6eh8YbJ0EaWDtAnOs()
		else: lmNTQxOIdqGs3 = KiryBCvngZzF85UN6xSDlOVweL4I9
	if lgB7TOZqEJiMUFedrSHX8j6: YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def DQ7XENnbgcfAm6iJkrKWSBu():
	pUon4NEmqs0JtSHAvCGrc()
	BvgXNQkUdxHOimtT0y = G3yDpvxOiSWdAeL.getSetting(SI7eBdND4lx8pt5Qk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬဌ"))
	eJU6bsndE1mI0F = {}
	eJU6bsndE1mI0F[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡂࡗࡗࡓࠬဍ")] = yobpaW7sBqtKRrv(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧဎ")
	eJU6bsndE1mI0F[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡖࡘࡔࡖࠧဏ")] = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩတ")
	eJU6bsndE1mI0F[gPE1XB87fQl(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬထ")] = GHg28TBchiyn6l(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ဒ")+str(OsSFncJAtVW3CqLbx74RiZjPY2yU/beV5l2D8HznyJI0(u"࠺࠵ቲ"))+A41nqbj3wYt(u"࠭ࠠะไํๆฮࠦแใูࠪဓ")
	dAwtexG6h3VB4M = eJU6bsndE1mI0F[BvgXNQkUdxHOimtT0y]
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠧไษืࠤࠬန")+str(OsSFncJAtVW3CqLbx74RiZjPY2yU/aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠻࠶ታ"))+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࠢาๆ๏่ษࠨပ"),rVy3Ops0mohYkT(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨဖ"),kdRO82AImh0LFw(u"ࠪษ๏่วโࠢๆห๊๊ࠧဗ"),dAwtexG6h3VB4M,CyHU86ZeYT5BWRcitSm2I(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧဘ"))
	if UqCAgBwjTuoVyn0evI==IMjqygdfYSKpHlWu5Aa(u"࠶ቴ"): PbuGIt2iRsUoTn4DzqSH76X = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭မ")
	elif UqCAgBwjTuoVyn0evI==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠱ት"): PbuGIt2iRsUoTn4DzqSH76X = VP70ytiFNMBl6vHDaW(u"࠭ࡁࡖࡖࡒࠫယ")
	elif UqCAgBwjTuoVyn0evI==bawK2j7T81Nrc4GWs05xzDg(u"࠳ቶ"): PbuGIt2iRsUoTn4DzqSH76X = KLX7hW0nBAEgy6m4SvH(u"ࠧࡔࡖࡒࡔࠬရ")
	else: PbuGIt2iRsUoTn4DzqSH76X = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if PbuGIt2iRsUoTn4DzqSH76X:
		G3yDpvxOiSWdAeL.setSetting(A41nqbj3wYt(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧလ"),PbuGIt2iRsUoTn4DzqSH76X)
		tqn4AMQTW5uPOh9Jivcle = eJU6bsndE1mI0F[PbuGIt2iRsUoTn4DzqSH76X]
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tqn4AMQTW5uPOh9Jivcle)
	return
def KPnyBX0vo7sWwjL1mgzZ3():
	eJU6bsndE1mI0F = {}
	eJU6bsndE1mI0F[beV5l2D8HznyJI0(u"ࠩࡄ࡙࡙ࡕࠧဝ")] = SI7eBdND4lx8pt5Qk(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨသ")
	eJU6bsndE1mI0F[SI7eBdND4lx8pt5Qk(u"ࠫࡆ࡙ࡋࠨဟ")] = aiQwFE1TGx04vmLcsYkIW5jA(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩဠ")
	eJU6bsndE1mI0F[oiWNFYzcIUeh(u"࠭ࡓࡕࡑࡓࠫအ")] = mq5t9JXSdHT8yfDVF(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪဢ")
	JJDCg8yfwMT = G3yDpvxOiSWdAeL.getSetting(pp7FcjEe6g(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨဣ"))
	BvgXNQkUdxHOimtT0y = G3yDpvxOiSWdAeL.getSetting(Z9FPQvwlbjLTh(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬဤ"))
	dAwtexG6h3VB4M = eJU6bsndE1mI0F[BvgXNQkUdxHOimtT0y]+JJDCg8yfwMT
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨဥ"),rVy3Ops0mohYkT(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪဦ"),wwWzyF4ZpSQXKOgk569(u"ࠬห๊ใษไࠤ่อๅๅࠩဧ"),dAwtexG6h3VB4M,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪဨ"))
	if UqCAgBwjTuoVyn0evI==oiWNFYzcIUeh(u"࠲ቷ"): PbuGIt2iRsUoTn4DzqSH76X = GHg28TBchiyn6l(u"ࠧࡂࡕࡎࠫဩ")
	elif UqCAgBwjTuoVyn0evI==KLX7hW0nBAEgy6m4SvH(u"࠴ቸ"): PbuGIt2iRsUoTn4DzqSH76X = gPE1XB87fQl(u"ࠨࡃࡘࡘࡔ࠭ဪ")
	elif UqCAgBwjTuoVyn0evI==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠶ቹ"): PbuGIt2iRsUoTn4DzqSH76X = beV5l2D8HznyJI0(u"ࠩࡖࡘࡔࡖࠧါ")
	if UqCAgBwjTuoVyn0evI in [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠶ቻ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠶ቺ")]:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(VP70ytiFNMBl6vHDaW(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ"),SI7eBdND4lx8pt5Qk(u"ุࠫ๐ัโำ࠽ࠤࠬိ")+A3pXVFdyP1.DNS_SERVERS[wnaWTQM7VJPkZzO9eoSyFU4],KLX7hW0nBAEgy6m4SvH(u"ู๊ࠬาใิ࠾ࠥ࠭ီ")+A3pXVFdyP1.DNS_SERVERS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬု"))
		if kkLdeyJUsSiK9YwFZr4lPbVE==A6iX18qgyOFlZxz7sc(u"࠱ቼ"): uIaG24zXrQJYpc = A3pXVFdyP1.DNS_SERVERS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		else: uIaG24zXrQJYpc = A3pXVFdyP1.DNS_SERVERS[wnaWTQM7VJPkZzO9eoSyFU4]
	elif UqCAgBwjTuoVyn0evI==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠳ች"): uIaG24zXrQJYpc = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: PbuGIt2iRsUoTn4DzqSH76X = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if PbuGIt2iRsUoTn4DzqSH76X:
		G3yDpvxOiSWdAeL.setSetting(wwWzyF4ZpSQXKOgk569(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪူ"),PbuGIt2iRsUoTn4DzqSH76X)
		G3yDpvxOiSWdAeL.setSetting(iySORMYxWXszEH18(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨေ"),uIaG24zXrQJYpc)
		tqn4AMQTW5uPOh9Jivcle = eJU6bsndE1mI0F[PbuGIt2iRsUoTn4DzqSH76X]+uIaG24zXrQJYpc
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tqn4AMQTW5uPOh9Jivcle)
	return
def JUCMi86z5tq9wK():
	BvgXNQkUdxHOimtT0y = G3yDpvxOiSWdAeL.getSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧဲ"))
	eJU6bsndE1mI0F = {}
	eJU6bsndE1mI0F[YYQS36fyPvtuzcEmRL(u"ࠪࡅ࡚࡚ࡏࠨဳ")] = Z9FPQvwlbjLTh(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬဴ")
	eJU6bsndE1mI0F[CyHU86ZeYT5BWRcitSm2I(u"ࠬࡇࡓࡌࠩဵ")] = aiQwFE1TGx04vmLcsYkIW5jA(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧံ")
	eJU6bsndE1mI0F[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡔࡖࡒࡔ့ࠬ")] = wwWzyF4ZpSQXKOgk569(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪး")
	dAwtexG6h3VB4M = eJU6bsndE1mI0F[BvgXNQkUdxHOimtT0y]
	UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯ္ࠧ"),wwWzyF4ZpSQXKOgk569(u"ࠪฮูเ๊ๅࠢอ่็อฦ်๋ࠩ"),SI7eBdND4lx8pt5Qk(u"ࠫส๐โศใࠣ็ฬ๋ไࠨျ"),dAwtexG6h3VB4M,GHg28TBchiyn6l(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨြ"))
	if UqCAgBwjTuoVyn0evI==A6iX18qgyOFlZxz7sc(u"࠲ቾ"): PbuGIt2iRsUoTn4DzqSH76X = ZLr5gRSkFewKdUos90bM(u"࠭ࡁࡔࡍࠪွ")
	elif UqCAgBwjTuoVyn0evI==A41nqbj3wYt(u"࠴ቿ"): PbuGIt2iRsUoTn4DzqSH76X = wwWzyF4ZpSQXKOgk569(u"ࠧࡂࡗࡗࡓࠬှ")
	elif UqCAgBwjTuoVyn0evI==kdRO82AImh0LFw(u"࠶ኀ"): PbuGIt2iRsUoTn4DzqSH76X = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡕࡗࡓࡕ࠭ဿ")
	else: PbuGIt2iRsUoTn4DzqSH76X = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if PbuGIt2iRsUoTn4DzqSH76X:
		G3yDpvxOiSWdAeL.setSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ၀"),PbuGIt2iRsUoTn4DzqSH76X)
		tqn4AMQTW5uPOh9Jivcle = eJU6bsndE1mI0F[PbuGIt2iRsUoTn4DzqSH76X]
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tqn4AMQTW5uPOh9Jivcle)
	return
def wwcmO3diofI5a8AV():
	DCauiOrxqK794Bfg1p2 = G3yDpvxOiSWdAeL.getSetting(GHg28TBchiyn6l(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ၁"))
	if DCauiOrxqK794Bfg1p2==eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡘ࡚ࡏࡑࠩ၂"): header = VP70ytiFNMBl6vHDaW(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ၃")
	else: header = SI7eBdND4lx8pt5Qk(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ၄")
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧฦ์ๅหๆ࠭၅"),A6iX18qgyOFlZxz7sc(u"ࠨฬไ฽๏๊ࠧ၆"),header,IMjqygdfYSKpHlWu5Aa(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭၇"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==-beV5l2D8HznyJI0(u"࠶ኁ"): return
	elif kkLdeyJUsSiK9YwFZr4lPbVE:
		G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ၈"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡆ࡛ࡔࡐࠩ၉"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,YYQS36fyPvtuzcEmRL(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ၊"))
	else:
		G3yDpvxOiSWdAeL.setSetting(KLX7hW0nBAEgy6m4SvH(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭။"),CyHU86ZeYT5BWRcitSm2I(u"ࠧࡔࡖࡒࡔࠬ၌"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,SI7eBdND4lx8pt5Qk(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ၍"))
	return
def cfU4oM5yYbaKj9Q1lRvrZ30HVSAu(ZVk6IphECKLzUceP15j):
	if ZVk6IphECKLzUceP15j!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		ZVk6IphECKLzUceP15j = P74g5BI92vDdJEQN(ZVk6IphECKLzUceP15j)
		ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.decode(e87cIA5vwOQLDEP1).encode(e87cIA5vwOQLDEP1)
		jbHBapXvlU1h3Sq89dMT = KLX7hW0nBAEgy6m4SvH(u"࠷࠰࠲࠲࠶ኂ")
		UUsWMSLcOtwiHZX8nbmrPh = Zilvh2WQyb5.Window(jbHBapXvlU1h3Sq89dMT)
		UUsWMSLcOtwiHZX8nbmrPh.getControl(aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠲࠳ኃ")).setLabel(ZVk6IphECKLzUceP15j)
	return
OOx2k9sy1Xh = [
			 YYQS36fyPvtuzcEmRL(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢ၎")
			,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭၏")
			,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ၐ")
			,A6iX18qgyOFlZxz7sc(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧၑ")
			,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧၒ")
			,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩၓ")
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧၔ")+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࠦࠫၕ")+iySORMYxWXszEH18(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩၖ")
			,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧၗ")
			,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨၘ")
			,beV5l2D8HznyJI0(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧၙ")
			,gPE1XB87fQl(u"ࠧ࡟ࡠࡡࡢࡣ࠭ၚ")
			,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ၛ")
			,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬၜ")
			,rVy3Ops0mohYkT(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨၝ")
			]
def qQKEYgABFaRbG(AuNfQI1cKXGdWoU):
	if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩၞ") in AuNfQI1cKXGdWoU and A41nqbj3wYt(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၟ") in AuNfQI1cKXGdWoU: return r0D4C3z7Onqpa
	for ZVk6IphECKLzUceP15j in OOx2k9sy1Xh:
		if ZVk6IphECKLzUceP15j in AuNfQI1cKXGdWoU: return r0D4C3z7Onqpa
	return KiryBCvngZzF85UN6xSDlOVweL4I9
def jtYgX5eSl3cCTPhbGBAHZ1a(data):
	NpTWXdatZ8qQMk3E9uVGh4jnUbz = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠹ኅ") if rJ2oTLqabRtA else IMjqygdfYSKpHlWu5Aa(u"࠲࠷ኄ")
	data = data.replace(VP70ytiFNMBl6vHDaW(u"࠶࠴ኆ")*kcXMWrwiLDKeBHRsJ,NpTWXdatZ8qQMk3E9uVGh4jnUbz*kcXMWrwiLDKeBHRsJ)
	data = data.replace(KLX7hW0nBAEgy6m4SvH(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬၠ"),Z9FPQvwlbjLTh(u"ࠧ࠻ࠢࠪၡ"))
	bZ0VWjAHm1v2Csroh = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for AuNfQI1cKXGdWoU in data.splitlines():
		qz15EUARLGH9IVxgiT = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧၢ"),AuNfQI1cKXGdWoU,p7dwlH1PRStBgyMUW.DOTALL)
		if qz15EUARLGH9IVxgiT: AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(qz15EUARLGH9IVxgiT[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		bZ0VWjAHm1v2Csroh += WBDnh75CaLEvkcN6p4ez2KXrV3M+AuNfQI1cKXGdWoU
	return bZ0VWjAHm1v2Csroh
def yyuGOfSc1jMz3dQJPbTC97rYZvnpm(bbh13cCLPBdYr74AumOTefgMF):
	if pp7FcjEe6g(u"ࠩࡒࡐࡉ࠭ၣ") in bbh13cCLPBdYr74AumOTefgMF:
		kkECV1sdW7jrpaqwcOohK2G0ex = WZhFwntTd5NULaqQpo
		header = A41nqbj3wYt(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪၤ")
	else:
		kkECV1sdW7jrpaqwcOohK2G0ex = QqA6tL3TolUrzJf05MkR
		header = SI7eBdND4lx8pt5Qk(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫၥ")
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,header,gPE1XB87fQl(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨၦ"))
	if kkLdeyJUsSiK9YwFZr4lPbVE!=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠵ኇ"): return
	A0QtIYr2TFvB8JcKl9Z7xRm,qQOZvusy1Jx5VE = [],QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠵ኈ")
	size,count = KIt6Jwe3Qyxp(kkECV1sdW7jrpaqwcOohK2G0ex)
	file = open(kkECV1sdW7jrpaqwcOohK2G0ex,ZLr5gRSkFewKdUos90bM(u"࠭ࡲࡣࠩၧ"))
	if size>A41nqbj3wYt(u"࠱࠱࠲࠵࠴࠵ኊ"): file.seek(-bawK2j7T81Nrc4GWs05xzDg(u"࠷࠰࠱࠳࠳࠴኉"),pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.SEEK_END)
	data = file.read()
	file.close()
	if rJ2oTLqabRtA: data = data.decode(e87cIA5vwOQLDEP1)
	data = jtYgX5eSl3cCTPhbGBAHZ1a(data)
	bbiBPLGW5cmhv = data.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)
	for AuNfQI1cKXGdWoU in reversed(bbiBPLGW5cmhv):
		m921m8MoO6wdcQb07jkVxqBzivEFeg = qQKEYgABFaRbG(AuNfQI1cKXGdWoU)
		if m921m8MoO6wdcQb07jkVxqBzivEFeg: continue
		AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩၨ"),RNWqL0gBbKOie1DxjUpzQPh9aZyHX+rVy3Ops0mohYkT(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫၩ")+YVr6St5P4xsFC0aARQGKfiegD)
		AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩၪ"),rVy3Ops0mohYkT(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ၫ")+beV5l2D8HznyJI0(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫၬ")+YVr6St5P4xsFC0aARQGKfiegD)
		RHDyq1mUf6ScznksXYAOp24CQb = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		JJRDsyiEHoQO8cTwkVKAqtIfp6BUF = p7dwlH1PRStBgyMUW.findall(pp7FcjEe6g(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬၭ"),AuNfQI1cKXGdWoU,p7dwlH1PRStBgyMUW.DOTALL)
		if JJRDsyiEHoQO8cTwkVKAqtIfp6BUF:
			AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4],JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]).replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][XURrDCfOS9Mbhpv2Pmjos56TeW],WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			RHDyq1mUf6ScznksXYAOp24CQb = JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]
		else:
			JJRDsyiEHoQO8cTwkVKAqtIfp6BUF = p7dwlH1PRStBgyMUW.findall(kdRO82AImh0LFw(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ၮ"),AuNfQI1cKXGdWoU,p7dwlH1PRStBgyMUW.DOTALL)
			if JJRDsyiEHoQO8cTwkVKAqtIfp6BUF:
				AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4],WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				RHDyq1mUf6ScznksXYAOp24CQb = JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if RHDyq1mUf6ScznksXYAOp24CQb: AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(RHDyq1mUf6ScznksXYAOp24CQb,e6HEdvUcaq8Gx+RHDyq1mUf6ScznksXYAOp24CQb+YVr6St5P4xsFC0aARQGKfiegD)
		A0QtIYr2TFvB8JcKl9Z7xRm.append(AuNfQI1cKXGdWoU)
		if len(str(A0QtIYr2TFvB8JcKl9Z7xRm))>bawK2j7T81Nrc4GWs05xzDg(u"࠶࠲࠴࠴࠵ኋ"): break
	A0QtIYr2TFvB8JcKl9Z7xRm = reversed(A0QtIYr2TFvB8JcKl9Z7xRm)
	SS1h3HTpJrknRwLeZCitz = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(A0QtIYr2TFvB8JcKl9Z7xRm)
	Pgbtx1uwX52DEk7Jf(mq5t9JXSdHT8yfDVF(u"ࠧ࡭ࡧࡩࡸࠬၯ"),Z9FPQvwlbjLTh(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬၰ"),SS1h3HTpJrknRwLeZCitz,YYQS36fyPvtuzcEmRL(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬၱ"))
	return
def UovJzrY0ETgp9():
	TbzQ3Ot8ZyGaYKURHh9BiS = open(O846ER20IJA9fQYyBTpokUvGwMjn,Z9FPQvwlbjLTh(u"ࠪࡶࡧ࠭ၲ")).read()
	if rJ2oTLqabRtA: TbzQ3Ot8ZyGaYKURHh9BiS = TbzQ3Ot8ZyGaYKURHh9BiS.decode(e87cIA5vwOQLDEP1)
	TbzQ3Ot8ZyGaYKURHh9BiS = TbzQ3Ot8ZyGaYKURHh9BiS.replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡡࡺࠧၳ"),GHg28TBchiyn6l(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧၴ"))
	jWylPFA81zQGdTDMJ5 = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧၵ"),TbzQ3Ot8ZyGaYKURHh9BiS,p7dwlH1PRStBgyMUW.DOTALL)
	for AuNfQI1cKXGdWoU in jWylPFA81zQGdTDMJ5:
		TbzQ3Ot8ZyGaYKURHh9BiS = TbzQ3Ot8ZyGaYKURHh9BiS.replace(AuNfQI1cKXGdWoU,RNWqL0gBbKOie1DxjUpzQPh9aZyHX+AuNfQI1cKXGdWoU+YVr6St5P4xsFC0aARQGKfiegD)
	oEncafdG6UxR50yCutSAjklYvD3T4(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨၶ"),TbzQ3Ot8ZyGaYKURHh9BiS)
	return
def KqDlQz2xa4cEV():
	hJaCboEre4Tc6AW8Uz = yobpaW7sBqtKRrv(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪၷ")
	gEbImLX6aAO28D3Pxo5ehjnvu = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ၸ")
	WXZ4HTO7PSFmMp = kdRO82AImh0LFw(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ၹ")
	eJU6bsndE1mI0F = hJaCboEre4Tc6AW8Uz+A41nqbj3wYt(u"ࠫ࠿ࠦࠧၺ")+gEbImLX6aAO28D3Pxo5ehjnvu+iySORMYxWXszEH18(u"ࠬࠦ࠮ࠡࠩၻ")+WXZ4HTO7PSFmMp
	Pgbtx1uwX52DEk7Jf(gPE1XB87fQl(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၼ"),Ew26Hg4SIj,eJU6bsndE1mI0F,YYQS36fyPvtuzcEmRL(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪၽ"))
	return
def JbaHBRQsVkIGZ7(type,eJU6bsndE1mI0F,showDialogs=r0D4C3z7Onqpa,url=WnNGfosHr5STAq8j7miwyRZ6eOUbV,ADN3XhW9ZpVmFK84j2roiy=WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZVk6IphECKLzUceP15j=WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ilw0KAOfLh3vi2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	aUZw4FNgQ5mJWE = r0D4C3z7Onqpa
	if not A3pXVFdyP1.bWV7czPeIaq:
		if showDialogs:
			oOFjVPBeq9Yu = (gPE1XB87fQl(u"ࠨษ็ื฼ื࠺ࠨၾ") in eJU6bsndE1mI0F and ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩส่๊้ว็࠼ࠪၿ") in eJU6bsndE1mI0F and oiWNFYzcIUeh(u"ࠪห้๋ไโ࠼ࠪႀ") in eJU6bsndE1mI0F and A6iX18qgyOFlZxz7sc(u"ࠫฬ๊ฮุลࠪႁ") in eJU6bsndE1mI0F and wwWzyF4ZpSQXKOgk569(u"ࠬอไๆืาี࠿࠭ႂ") in eJU6bsndE1mI0F)
			if not oOFjVPBeq9Yu: aUZw4FNgQ5mJWE = TPNsmjik1eh4Wc(mq5t9JXSdHT8yfDVF(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ႃ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫႄ"),eJU6bsndE1mI0F.replace(tzZ6PhyDOUnwLM3pdK(u"ࠨ࡞࡟ࡲࠬႅ"),WBDnh75CaLEvkcN6p4ez2KXrV3M))
	elif showDialogs:
		eJU6bsndE1mI0F = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩႆ")
		dw4yPWbjERH8hUIu = TPNsmjik1eh4Wc(SI7eBdND4lx8pt5Qk(u"ࠪࡧࡪࡴࡴࡦࡴࠪႇ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rVy3Ops0mohYkT(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫႈ")+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࠦࠠ࠲࠱࠸ࠫႉ"),GHg28TBchiyn6l(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫႊ"))
		OmfwlCkxzIGegTN8ZqMVvPaH = TPNsmjik1eh4Wc(ZLr5gRSkFewKdUos90bM(u"ࠧࡤࡧࡱࡸࡪࡸࠧႋ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨႌ")+rVy3Ops0mohYkT(u"ࠩࠣࠤ࠷࠵࠵ࠨႍ"),VP70ytiFNMBl6vHDaW(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨႎ"))
		OqxUA51YgTGLzIdQrKHb8 = TPNsmjik1eh4Wc(mq5t9JXSdHT8yfDVF(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႏ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ႐")+VP70ytiFNMBl6vHDaW(u"࠭ࠠࠡ࠵࠲࠹ࠬ႑"),bawK2j7T81Nrc4GWs05xzDg(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ႒"))
		LqRKcJbIrUDQHk6XB = TPNsmjik1eh4Wc(A6iX18qgyOFlZxz7sc(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ႓"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ႔")+bawK2j7T81Nrc4GWs05xzDg(u"ࠪࠤࠥ࠺࠯࠶ࠩ႕"),CyHU86ZeYT5BWRcitSm2I(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ႖"))
		aUZw4FNgQ5mJWE = TPNsmjik1eh4Wc(tzZ6PhyDOUnwLM3pdK(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ႗"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭႘")+iySORMYxWXszEH18(u"ࠧࠡࠢ࠸࠳࠺࠭႙"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ႚ"))
	ofEcIgWvaQizr9uTq8LBApwH0 = kNR9wHFiUYQntWAly(KiryBCvngZzF85UN6xSDlOVweL4I9)
	jZRucSxfUyh = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡄ࡚࠿ࠦࠧႛ")+ofEcIgWvaQizr9uTq8LBApwH0+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࠱ࠬႜ")+type
	UlaT09rIgR8CWpExstHDvVz6jyG1Km = r0D4C3z7Onqpa if A41nqbj3wYt(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧႝ") in ZVk6IphECKLzUceP15j else KiryBCvngZzF85UN6xSDlOVweL4I9
	if not aUZw4FNgQ5mJWE:
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ႞"))
		return KiryBCvngZzF85UN6xSDlOVweL4I9
	h19hWdNnLr6glmVxMjkKcyZb2ORFDf = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(SI7eBdND4lx8pt5Qk(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ႟"))
	eJU6bsndE1mI0F += wwWzyF4ZpSQXKOgk569(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭Ⴀ")+mbvW9By35UDO+pp7FcjEe6g(u"ࠨࠢ࠽ࡠࡡࡴࠧႡ")
	eJU6bsndE1mI0F += beV5l2D8HznyJI0(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪႢ")+ofEcIgWvaQizr9uTq8LBApwH0+beV5l2D8HznyJI0(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩႣ")+zmvCUWkdDfrHhoucgFX7T0JGipS+bawK2j7T81Nrc4GWs05xzDg(u"ࠫࠥࡀ࡜࡝ࡰࠪႤ")
	eJU6bsndE1mI0F += I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪႥ")+h19hWdNnLr6glmVxMjkKcyZb2ORFDf
	XCxufKnQs0SDkWY = UwIPdKQt4YDfoJM()
	XCxufKnQs0SDkWY = ZisgmEGCOJxVI9DcetNBPo6(XCxufKnQs0SDkWY)
	if XCxufKnQs0SDkWY: eJU6bsndE1mI0F += kdRO82AImh0LFw(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨႦ")+XCxufKnQs0SDkWY
	if url: eJU6bsndE1mI0F += beV5l2D8HznyJI0(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫႧ")+url
	if ADN3XhW9ZpVmFK84j2roiy: eJU6bsndE1mI0F += GHg28TBchiyn6l(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨႨ")+ADN3XhW9ZpVmFK84j2roiy
	eJU6bsndE1mI0F += lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࠣ࠾ࡡࡢ࡮ࠨႩ")
	if showDialogs: uTaiRMI8eYmN(iySORMYxWXszEH18(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩႪ"),gPE1XB87fQl(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭Ⴋ"))
	if UlaT09rIgR8CWpExstHDvVz6jyG1Km:
		if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬႬ") in ZVk6IphECKLzUceP15j: d6I2EqmjP8yWrkAL5z0sueR4aJ3Y = WZhFwntTd5NULaqQpo
		else: d6I2EqmjP8yWrkAL5z0sueR4aJ3Y = QqA6tL3TolUrzJf05MkR
		if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(d6I2EqmjP8yWrkAL5z0sueR4aJ3Y):
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,mq5t9JXSdHT8yfDVF(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫႭ"))
			return KiryBCvngZzF85UN6xSDlOVweL4I9
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬႮ"))
		A0QtIYr2TFvB8JcKl9Z7xRm,qQOZvusy1Jx5VE = [],beV5l2D8HznyJI0(u"࠲ኌ")
		file = open(d6I2EqmjP8yWrkAL5z0sueR4aJ3Y,mq5t9JXSdHT8yfDVF(u"ࠨࡴࡥࠫႯ"))
		size,count = KIt6Jwe3Qyxp(d6I2EqmjP8yWrkAL5z0sueR4aJ3Y)
		if size>eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠶࠴࠶࠶࠰࠱ኍ"): file.seek(-eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠶࠴࠶࠶࠰࠱ኍ"),pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(e87cIA5vwOQLDEP1)
		data = jtYgX5eSl3cCTPhbGBAHZ1a(data)
		bbiBPLGW5cmhv = data.splitlines()
		for AuNfQI1cKXGdWoU in reversed(bbiBPLGW5cmhv):
			m921m8MoO6wdcQb07jkVxqBzivEFeg = qQKEYgABFaRbG(AuNfQI1cKXGdWoU)
			if m921m8MoO6wdcQb07jkVxqBzivEFeg: continue
			JJRDsyiEHoQO8cTwkVKAqtIfp6BUF = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩႰ"),AuNfQI1cKXGdWoU,p7dwlH1PRStBgyMUW.DOTALL)
			if JJRDsyiEHoQO8cTwkVKAqtIfp6BUF:
				AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4],JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4]).replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][XURrDCfOS9Mbhpv2Pmjos56TeW],WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			else:
				JJRDsyiEHoQO8cTwkVKAqtIfp6BUF = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪႱ"),AuNfQI1cKXGdWoU,p7dwlH1PRStBgyMUW.DOTALL)
				if JJRDsyiEHoQO8cTwkVKAqtIfp6BUF: AuNfQI1cKXGdWoU = AuNfQI1cKXGdWoU.replace(JJRDsyiEHoQO8cTwkVKAqtIfp6BUF[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4],WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			A0QtIYr2TFvB8JcKl9Z7xRm.append(AuNfQI1cKXGdWoU)
			if len(str(A0QtIYr2TFvB8JcKl9Z7xRm))>ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠶࠺࠷࠰࠱࠲኎"): break
		A0QtIYr2TFvB8JcKl9Z7xRm = reversed(A0QtIYr2TFvB8JcKl9Z7xRm)
		SS1h3HTpJrknRwLeZCitz = GHg28TBchiyn6l(u"ࠫࡡࡸ࡜࡯ࠩႲ").join(A0QtIYr2TFvB8JcKl9Z7xRm)
	elif Ilw0KAOfLh3vi2: SS1h3HTpJrknRwLeZCitz = Ilw0KAOfLh3vi2
	else: SS1h3HTpJrknRwLeZCitz = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	url = A3pXVFdyP1.SITESURLS[IMjqygdfYSKpHlWu5Aa(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬႳ")][XURrDCfOS9Mbhpv2Pmjos56TeW]
	rLqYZOtwMfBVs4k1TpE3X9aDy = {rVy3Ops0mohYkT(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧႴ"):jZRucSxfUyh,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨႵ"):eJU6bsndE1mI0F,pp7FcjEe6g(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩႶ"):SS1h3HTpJrknRwLeZCitz}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,KLX7hW0nBAEgy6m4SvH(u"ࠩࡓࡓࡘ࡚ࠧႷ"),url,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭Ⴘ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if SI7eBdND4lx8pt5Qk(u"ࠫࡸ࡫࡮ࡥࡡࡶࡹࡨࡩࡥࡦࡦࡨࡨࠬႹ") in piN9Qlah4S: FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r0D4C3z7Onqpa
	else: FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	if showDialogs:
		if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy:
			uTaiRMI8eYmN(IMjqygdfYSKpHlWu5Aa(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨႺ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧႻ"))
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭Ⴜ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪႽ"))
		else:
			uTaiRMI8eYmN(IMjqygdfYSKpHlWu5Aa(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭Ⴞ"),wwWzyF4ZpSQXKOgk569(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫႿ"))
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩჀ"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def AHEs8eQdDwK():
	hJaCboEre4Tc6AW8Uz = yobpaW7sBqtKRrv(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡴࡳࡣࡱࡷࡱࡧࡴࡦࠢࡰࡩࡳࡻࠠࡪࡶࡨࡱࡸࠦࡴࡰࠢࡤࠤࡱࡧ࡮ࡨࡷࡤ࡫ࡪࠦ࡯ࡵࡪࡨࡶࠥࡺࡨࡢࡰࠣࡅࡷࡧࡢࡪࡥࠣ࠲࠳ࠦࡏࡳࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡡ࡯ࡦࠣࡸࡪࡾࡴࠡࡁࠤࠫჁ")
	gEbImLX6aAO28D3Pxo5ehjnvu = mq5t9JXSdHT8yfDVF(u"࠭็ๅࠢอี๏ีࠠหำฯ้ฮࠦโ้ษษ้ࠥอไษำ้ห๊าࠠฦๆ์ࠤ้เษࠡลัี๎ฺ๋ࠦำࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡว฻๋ฬืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠣรࠦ࠭Ⴢ")
	choice = tFVmMznSUR3XupZBN9kxcO0EHv(oiWNFYzcIUeh(u"ࠧࡤࡧࡱࡸࡪࡸࠧჃ"),A41nqbj3wYt(u"ࠨะิ์ัࠦࡅࡹ࡫ࡷࠫჄ"),YYQS36fyPvtuzcEmRL(u"ࠩࡗࡶࡦࡴࡳ࡭ࡣࡷࡩࠥะัอ็ฬࠫჅ"),iySORMYxWXszEH18(u"ࠪ฽ึฮ๊ࠡࡃࡵࡥࡧ࡯ࡣࠨ჆"),Ew26Hg4SIj,hJaCboEre4Tc6AW8Uz+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡡࡴ࡜࡯ࠩჇ")+gEbImLX6aAO28D3Pxo5ehjnvu)
	if choice in [-rVy3Ops0mohYkT(u"࠶኏"),KLX7hW0nBAEgy6m4SvH(u"࠶ነ")]: return
	elif choice==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠱ኑ"):
		import cl1aVJLDm2
		cl1aVJLDm2.BaGjcQpwY4ZqHFxmbM9f()
		return
	priSfyn0QP7Cg = r0D4C3z7Onqpa
	while priSfyn0QP7Cg:
		priSfyn0QP7Cg = KiryBCvngZzF85UN6xSDlOVweL4I9
		message = IMjqygdfYSKpHlWu5Aa(u"ࠬหะศࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦหๆࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใ฽๎ึࠦวๅฮ็ำࠥหไ๊ࠢฦ๎ࠥาไะࠢฮห๋๐ࠠโ์๊ࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦหๆࠢห฽ิํวࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤสึวࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢ็หࠥะุ่ำ่่ࠣࠦ࠮࠯ࠢสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤ࠳࠴ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้ํู่ࠡษ็ะ฿ืวโ์ࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠโฬะࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤฤࠧࠧ჈")
		choice = tFVmMznSUR3XupZBN9kxcO0EHv(A6iX18qgyOFlZxz7sc(u"࠭ࡣࡦࡰࡷࡩࡷ࠭჉"),wwWzyF4ZpSQXKOgk569(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪ჊"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩ჋"),beV5l2D8HznyJI0(u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠣษ๋าไ๋ิํࠫ჌"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ฽ิู๋้๋ࠠีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠨჍ"),message,profile=VP70ytiFNMBl6vHDaW(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ჎"))
		if choice==Z9FPQvwlbjLTh(u"࠳ኒ"):
			message = yobpaW7sBqtKRrv(u"ࠬࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡸ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡵࡱࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡳ࡬࡫ࡱࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠ࡝ࠤࡄࡶ࡮ࡧ࡬࡝ࠤࠣࡪࡴࡴࡴࠡ࠰࠱ࠤࡆࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡࡋࡩࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢ࠱࠲࡚ࠥࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡡࡴ࡜࡯ࠢࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠ࡯ࡱࡺࠤࡹࡵࠠࡰࡲࡨࡲࠥࡺࡨࡦࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡀࠣࠪ჏")
			choice = tFVmMznSUR3XupZBN9kxcO0EHv(CyHU86ZeYT5BWRcitSm2I(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ა"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪბ"),IMjqygdfYSKpHlWu5Aa(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩგ"),beV5l2D8HznyJI0(u"ࠩࡄࡶࡦࡨࡩࡤࠢ฼ีอ๐ࠧდ"),tzZ6PhyDOUnwLM3pdK(u"ࠪࡑ࡮ࡹࡳࡪࡰࡪࠤࡆࡸࡡࡣ࡫ࡦࠤࡋࡵ࡮ࡵࠢࠩࠤ࡙࡫ࡸࡵࠩე"),message,profile=A6iX18qgyOFlZxz7sc(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩვ"))
			if choice==wwWzyF4ZpSQXKOgk569(u"࠴ና"): priSfyn0QP7Cg = r0D4C3z7Onqpa
		if choice==A6iX18qgyOFlZxz7sc(u"࠴ኔ"): PfG0vqasTbjuQ4iF2()
	return
def g5j7MicqRO18XhICV0nQ():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫზ"))
	return
def WgqP8i2urSJavBm1():
	eJU6bsndE1mI0F = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭თ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
	return
def M2IB8vFWTfmDztRPqikUAC():
	eJU6bsndE1mI0F = gPE1XB87fQl(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫი")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
	return
def UIHYgNczQhT5V61():
	eJU6bsndE1mI0F = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬკ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫლ"),eJU6bsndE1mI0F)
	return
def KrZieMvpBDN():
	eJU6bsndE1mI0F = iySORMYxWXszEH18(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨმ")
	Pgbtx1uwX52DEk7Jf(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫნ"),Ew26Hg4SIj,eJU6bsndE1mI0F,A6iX18qgyOFlZxz7sc(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨო"))
	return
def anguRTwBdfmGibW8DK():
	hJaCboEre4Tc6AW8Uz = yobpaW7sBqtKRrv(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧპ")
	gEbImLX6aAO28D3Pxo5ehjnvu = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩჟ")
	WXZ4HTO7PSFmMp = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩრ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,hJaCboEre4Tc6AW8Uz,gEbImLX6aAO28D3Pxo5ehjnvu,WXZ4HTO7PSFmMp)
	return
def pUon4NEmqs0JtSHAvCGrc():
	gEbImLX6aAO28D3Pxo5ehjnvu = kdRO82AImh0LFw(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪს")
	gEbImLX6aAO28D3Pxo5ehjnvu += QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡠࡳࡢ࡮ࠨტ") + jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪუ") + str(iXBqSkDU3mRCZf4Ib/rVy3Ops0mohYkT(u"࠺࠵ን")/rVy3Ops0mohYkT(u"࠺࠵ን")/SI7eBdND4lx8pt5Qk(u"࠷࠺ኖ")/QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠹࠰ኗ")) + Z9FPQvwlbjLTh(u"ࠬࠦิ่ำࠪფ")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + oiWNFYzcIUeh(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬქ") + str(T0le9tWJd7IAfKH1rNGB/KLX7hW0nBAEgy6m4SvH(u"࠶࠱ኘ")/KLX7hW0nBAEgy6m4SvH(u"࠶࠱ኘ")/ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠳࠶ኙ")) + lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࠡ์๋้ࠬღ")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬყ") + str(oldym5kX8IqLSVDtpNMw/ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠸࠳ኚ")/ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠸࠳ኚ")/oiWNFYzcIUeh(u"࠵࠸ኛ")) + IMjqygdfYSKpHlWu5Aa(u"ࠩࠣ๎ํ๋ࠧშ")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬჩ") + str(nsFAzS2wvjyTYLOdDhfIiC0KGHE/pp7FcjEe6g(u"࠺࠵ኜ")/pp7FcjEe6g(u"࠺࠵ኜ")) + pp7FcjEe6g(u"ูࠫࠥวฺหࠪც")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩძ") + str(OQaHUGCW62hp8tFbgM/oiWNFYzcIUeh(u"࠻࠶ኝ")/oiWNFYzcIUeh(u"࠻࠶ኝ")) + n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࠠิษ฼อࠬწ")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + IMjqygdfYSKpHlWu5Aa(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨჭ") + str(A8MWZixP2YtOJ1no53mw/ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠼࠰ኞ")) + YYQS36fyPvtuzcEmRL(u"ࠨࠢาๆ๏่ษࠨხ")
	gEbImLX6aAO28D3Pxo5ehjnvu += WBDnh75CaLEvkcN6p4ez2KXrV3M + wwWzyF4ZpSQXKOgk569(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫჯ") + str(XAGWNdKH4qOPU1YEVQp6) + XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࠤิ่๊ใหࠪჰ")
	gEbImLX6aAO28D3Pxo5ehjnvu += A41nqbj3wYt(u"ࠫࡡࡴ࡜࡯ࠩჱ") + oiWNFYzcIUeh(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩჲ") + str(nsFAzS2wvjyTYLOdDhfIiC0KGHE/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")) + n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧჳ") + str(oldym5kX8IqLSVDtpNMw/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")/yobpaW7sBqtKRrv(u"࠳࠶አ")) + kdRO82AImh0LFw(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭ჴ") + str(OQaHUGCW62hp8tFbgM/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")) + yobpaW7sBqtKRrv(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬჵ") + str(A8MWZixP2YtOJ1no53mw/YYQS36fyPvtuzcEmRL(u"࠶࠱ኟ")) + beV5l2D8HznyJI0(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫჶ") + str(XAGWNdKH4qOPU1YEVQp6) + rVy3Ops0mohYkT(u"ࠪࠤิ่๊ใหࠪჷ")
	Pgbtx1uwX52DEk7Jf(kdRO82AImh0LFw(u"ࠫࡷ࡯ࡧࡩࡶࠪჸ"),KLX7hW0nBAEgy6m4SvH(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪჹ"),gEbImLX6aAO28D3Pxo5ehjnvu,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩჺ"))
	return
def F8ceQAagG07XiNbStTf():
	eJU6bsndE1mI0F = mq5t9JXSdHT8yfDVF(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ჻")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
	return
def GbQLnF7HIaN3lpDWMk():
	eJU6bsndE1mI0F = A41nqbj3wYt(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩჼ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
	return
def tunAJTNPs4wW3xkDIB1G():
	eJU6bsndE1mI0F = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭ჽ")
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eJU6bsndE1mI0F)
	return
def k18xRz2dML4DquamP3ZOFgev65():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨჾ"))
	MuryTcfZxnmGwIFUSa104E(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫჿ"),r0D4C3z7Onqpa)
	return
def aa9zoF7ghS6GmXrQsYKMuqb():
	eJU6bsndE1mI0F  = KLX7hW0nBAEgy6m4SvH(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧᄀ")
	eJU6bsndE1mI0F += tzZ6PhyDOUnwLM3pdK(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ᄁ")
	eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+A6iX18qgyOFlZxz7sc(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫᄂ")+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M
	eJU6bsndE1mI0F += aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨᄃ")
	Pgbtx1uwX52DEk7Jf(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡵ࡭࡬࡮ࡴࠨᄄ"),Ew26Hg4SIj,eJU6bsndE1mI0F,VP70ytiFNMBl6vHDaW(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᄅ"))
	eJU6bsndE1mI0F = CyHU86ZeYT5BWRcitSm2I(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧᄆ")
	eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+kdRO82AImh0LFw(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫᄇ")+YVr6St5P4xsFC0aARQGKfiegD
	eJU6bsndE1mI0F += oiWNFYzcIUeh(u"࠭࡜࡯࡞ࡱࠫᄈ")+Z9FPQvwlbjLTh(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨᄉ")
	eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+SI7eBdND4lx8pt5Qk(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪᄊ")+YVr6St5P4xsFC0aARQGKfiegD
	eJU6bsndE1mI0F += bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࡟ࡲࡡࡴࠧᄋ")+beV5l2D8HznyJI0(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫᄌ")
	eJU6bsndE1mI0F += e6HEdvUcaq8Gx+SI7eBdND4lx8pt5Qk(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭ᄍ")+YVr6St5P4xsFC0aARQGKfiegD
	Pgbtx1uwX52DEk7Jf(VP70ytiFNMBl6vHDaW(u"ࠬࡸࡩࡨࡪࡷࠫᄎ"),Ew26Hg4SIj,eJU6bsndE1mI0F,rVy3Ops0mohYkT(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄏ"))
	return
def CVOTSWjIfQs6ha3E():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧᄐ"),YYQS36fyPvtuzcEmRL(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢิืฬฬไ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫᄑ")+e6HEdvUcaq8Gx+A41nqbj3wYt(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫᄒ")+YVr6St5P4xsFC0aARQGKfiegD+bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪᄓ")+e6HEdvUcaq8Gx+SI7eBdND4lx8pt5Qk(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪᄔ")+YVr6St5P4xsFC0aARQGKfiegD)
	return
def MauNXthKyLozTbvwY1EFf07l5m(showDialogs=r0D4C3z7Onqpa):
	if not showDialogs: showDialogs = r0D4C3z7Onqpa
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡍࡅࡕࠩᄕ"),IMjqygdfYSKpHlWu5Aa(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬᄖ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᄗ"))
	if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
		TxW5XNyvK6ESeiHZP = KiryBCvngZzF85UN6xSDlOVweL4I9
		OCVUomhFsnctQJS8 = qjt73vfsNQZUw6(KiryBCvngZzF85UN6xSDlOVweL4I9)
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+oiWNFYzcIUeh(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭ᄘ")+OCVUomhFsnctQJS8+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡠࠫᄙ"))
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,SI7eBdND4lx8pt5Qk(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧᄚ"))
	else:
		TxW5XNyvK6ESeiHZP = r0D4C3z7Onqpa
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨᄛ"))
	if not TxW5XNyvK6ESeiHZP and showDialogs: ttS4ZBHmhAszy3()
	return TxW5XNyvK6ESeiHZP
def ttS4ZBHmhAszy3():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,CyHU86ZeYT5BWRcitSm2I(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫᄜ"))
	jPchH9LmAWKizFMDQxXNgOZ6ka3C5()
	return
def L6eh8YbJ0EaWDtAnOs(ZVk6IphECKLzUceP15j=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	UlaT09rIgR8CWpExstHDvVz6jyG1Km = r0D4C3z7Onqpa
	if jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩᄝ") not in ZVk6IphECKLzUceP15j:
		UlaT09rIgR8CWpExstHDvVz6jyG1Km = KiryBCvngZzF85UN6xSDlOVweL4I9
		UqCAgBwjTuoVyn0evI = tFVmMznSUR3XupZBN9kxcO0EHv(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄞ"),mq5t9JXSdHT8yfDVF(u"ࠨะิ์ั࠭ᄟ"),CyHU86ZeYT5BWRcitSm2I(u"ࠩศีุอไࠡ็ื็้ฯࠧᄠ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪษึูวๅࠢิืฬ๊ษࠨᄡ"),Ew26Hg4SIj,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧᄢ"))
		if UqCAgBwjTuoVyn0evI in [-iySORMYxWXszEH18(u"࠳ኡ"),kdRO82AImh0LFw(u"࠳ኢ")]: return
		elif UqCAgBwjTuoVyn0evI==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠵ኣ"):
			UlaT09rIgR8CWpExstHDvVz6jyG1Km = r0D4C3z7Onqpa
			ZVk6IphECKLzUceP15j = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨᄣ")
	if UlaT09rIgR8CWpExstHDvVz6jyG1Km:
		if pp7FcjEe6g(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭ᄤ") not in ZVk6IphECKLzUceP15j:
			kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(A41nqbj3wYt(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄥ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨᄦ"),tzZ6PhyDOUnwLM3pdK(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩᄧ"))
			if kkLdeyJUsSiK9YwFZr4lPbVE!=A41nqbj3wYt(u"࠶ኤ"):
				BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭ᄨ"),SI7eBdND4lx8pt5Qk(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧᄩ"))
				return
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,iySORMYxWXszEH18(u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้ห๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩᄪ"))
	eJU6bsndE1mI0F = x6S4MmiIE1hJ5bWUtdG02azC9Dgu(header=gPE1XB87fQl(u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧᄫ"),source=NTWE764hmOgUtScp2e8r)
	if not eJU6bsndE1mI0F: return
	if UlaT09rIgR8CWpExstHDvVz6jyG1Km: type = oiWNFYzcIUeh(u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨᄬ")
	else: type = mq5t9JXSdHT8yfDVF(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩᄭ")
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = JbaHBRQsVkIGZ7(type,eJU6bsndE1mI0F,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kdRO82AImh0LFw(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬᄮ"),ZVk6IphECKLzUceP15j)
	return
def bb4g5LQEcvV7r3mMDfJUhwdFHt1zu():
	ZVk6IphECKLzUceP15j = kdRO82AImh0LFw(u"๋ࠪีอࠠศๆหี๋อๅอࠢ็หࠥ๐่อั่ࠣ์ࠦร๋ࠢึ๎ึ็ัࠡ์ึฮ฻๐แࠡลํࠤ๊ำส้์สฮ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡำ๋หอ฽้ࠠฬู้๏์ࠠๅ็ะฮํ๐วห่ࠢีๆ๎ูสࠢ฼่๎ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ࠮ࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠๆีว์ู้ࠦ็ࠢฦ๎๋ࠥอห๊ํหฯࠦสๆࠢอั๊๐ไ่ษࠣ฽้๏ࠠิ์ิๅึอส๊่ࠡ์ฬู่ࠡะสีั๐ษࠡࠤ่์ฬูู่ࠡิๅࠥัวๅอࠥ࠲ࠥาๅ๋฻ࠣห้ษำๆษฤࠤํอไๆษิ็ฬะ้ࠠษ็ูํื้ࠠษ็ฺ้๋่าษอࠤ์๐ࠠฯษุอࠥฮวึฯสฬ์อ࠮ࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦ็ฬ๊็ࠥำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠥࡊࡍࡄࡃࠣษีอࠠไษ้ࠤ้ี๊ไࠢื็ํ๏ࠠฯษุอࠥฮวๅำ๋หอ฽้ࠠษ็ฮ฻อๅ๋่ࠣห้ิวาฮํอࠥ็วๅำฯหฦࠦวๅฬ๋หฺ๊ࠠๆ฻ࠣษิอัส๊ࠢิ์ࠦวๅีํีๆืวห๋ࠢห้๋่ศไ฼ࠤฬ๊ฮศำฯ๎ฮ࠴่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้ࠢหฬุอืส่ࠢฮฺ็อࠡๆ่์ฬู่ࠡษ็์๏ฮࠧᄯ")
	Pgbtx1uwX52DEk7Jf(tzZ6PhyDOUnwLM3pdK(u"ࠫࡷ࡯ࡧࡩࡶࠪᄰ"),pp7FcjEe6g(u"ࠬำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠬᄱ"),ZVk6IphECKLzUceP15j,oiWNFYzcIUeh(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄲ"))
	ZVk6IphECKLzUceP15j = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡪࡲࡷࡹࠦࡡ࡯ࡻࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴࡴࠠࡢࡰࡼࠤࡸ࡫ࡲࡷࡧࡵ࠲ࠥࡏࡴࠡࡱࡱࡰࡾࠦࡵࡴࡧࡶࠤࡱ࡯࡮࡬ࡵࠣࡸࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷ࡬ࡦࡺࠠࡸࡣࡶࠤࡺࡶ࡬ࡰࡣࡧࡩࡩࠦࡴࡰࠢࡳࡳࡵࡻ࡬ࡢࡴࠣࡳࡳࡲࡩ࡯ࡧࠣࡺ࡮ࡪࡥࡰࠢ࡫ࡳࡸࡺࡩ࡯ࡩࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡅࡱࡲࠠࡵࡴࡤࡨࡪࡳࡡࡳ࡭ࡶ࠰ࠥࡼࡩࡥࡧࡲࡷ࠱ࠦࡴࡳࡣࡧࡩࠥࡴࡡ࡮ࡧࡶ࠰ࠥࡹࡥࡳࡸ࡬ࡧࡪࠦ࡭ࡢࡴ࡮ࡷ࠱ࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࡧࡧࠤࡼࡵࡲ࡬࠮ࠣࡰࡴ࡭࡯ࡴࠢࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࡩࠦࡨࡦࡴࡨ࡭ࡳࠦࡢࡦ࡮ࡲࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪ࡯ࡲࠡࡴࡨࡷࡵ࡫ࡣࡵ࡫ࡹࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡤࡱࡰࡴࡦࡴࡩࡦࡵ࠱ࠤ࡙࡮ࡥࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡦࡱ࡫ࠠࡧࡱࡵࠤࡼ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡳࡵࡲࡥࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤ࠸ࡸࡤࠡࡲࡤࡶࡹࡿࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡘࡧࠣࡹࡷ࡭ࡥࠡࡣ࡯ࡰࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡱࡺࡲࡪࡸࡳ࠭ࠢࡷࡳࠥࡸࡥࡤࡱࡪࡲ࡮ࢀࡥࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫ࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥࡽࡩࡵࡪ࡬ࡲࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡸࡥࠡ࡮ࡲࡧࡦࡺࡥࡥࠢࡶࡳࡲ࡫ࡷࡩࡧࡵࡩࠥ࡫࡬ࡴࡧࠣࡳࡳࠦࡴࡩࡧࠣࡻࡪࡨࠠࡰࡴࠣࡺ࡮ࡪࡥࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡦࡸࡥࠡࡨࡵࡳࡲࠦ࡯ࡵࡪࡨࡶࠥࡼࡡࡳ࡫ࡲࡹࡸࠦࡳࡪࡶࡨࡷ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡦࡴࡹࠡ࡮ࡨ࡫ࡦࡲࠠࡪࡵࡶࡹࡪࡹࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡭ࡦࡦ࡬ࡥࠥ࡬ࡩ࡭ࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥ࡮࡯ࡴࡶࡨࡶࡸ࠴ࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡤࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳ࠰ࠪᄳ")
	Pgbtx1uwX52DEk7Jf(rVy3Ops0mohYkT(u"ࠨ࡮ࡨࡪࡹ࠭ᄴ"),kdRO82AImh0LFw(u"ࠩࡇ࡭࡬࡯ࡴࡢ࡮ࠣࡑ࡮ࡲ࡬ࡦࡰࡱ࡭ࡺࡳࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡅࡨࡺࠠࠩࡆࡐࡇࡆ࠯ࠧᄵ"),ZVk6IphECKLzUceP15j,IMjqygdfYSKpHlWu5Aa(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᄶ"))
	return
def bbeCJKpzMj():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,iySORMYxWXszEH18(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩᄷ"))
	tunAJTNPs4wW3xkDIB1G()
	return
def hNF9z1s6YOuk():
	x0MwvfUIz7 = {}
	UtwMYW1fopIvj0azdhAHBnS,uulwtzsxYainPV,ZfD2H8PQO4vbFS = y6AXTN1MJgrtC2uIvfhZVRYzx9aB8(KiryBCvngZzF85UN6xSDlOVweL4I9)
	hJaCboEre4Tc6AW8Uz,gEbImLX6aAO28D3Pxo5ehjnvu,WXZ4HTO7PSFmMp,Sf8YkqeAlUxWwMvyuiQGL,ZlQuIsKwUDnG2vNxXL1AoVjF,zFmA4bcXkZxeT1vN603nU9,SUR7dbEPGoZnNqrt = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	hJaCboEre4Tc6AW8Uz = tTChquY7XSRg4e.join(uulwtzsxYainPV)
	gEbImLX6aAO28D3Pxo5ehjnvu = tTChquY7XSRg4e.join(ZfD2H8PQO4vbFS)
	F7FDaijrlLQfJxhkmAW6wMVnu,YHajiT4VltmZ,O6hMZxndC1gWak3Re = UtwMYW1fopIvj0azdhAHBnS
	for OOG1iPYhTKQ4,Rrx6YsvjFQ2y,ipa9lmsneRCLZAXJyNO in YHajiT4VltmZ:
		ipa9lmsneRCLZAXJyNO = clFjTSgMODe7Nq0H3Vzs(ipa9lmsneRCLZAXJyNO)
		ipa9lmsneRCLZAXJyNO = ipa9lmsneRCLZAXJyNO.strip(kcXMWrwiLDKeBHRsJ).strip(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࠦ࠮ࠨᄸ"))
		V08cPX9tfM7gZxdvkuyBHhN = OOG1iPYhTKQ4.replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᄹ"),beV5l2D8HznyJI0(u"ࠧࡂࡒࡌࠫᄺ"))
		Sf8YkqeAlUxWwMvyuiQGL += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+V08cPX9tfM7gZxdvkuyBHhN+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠼ࠣࠫᄻ")+YVr6St5P4xsFC0aARQGKfiegD+ipa9lmsneRCLZAXJyNO+WBDnh75CaLEvkcN6p4ez2KXrV3M
		if Rrx6YsvjFQ2y.isdigit(): x0MwvfUIz7[OOG1iPYhTKQ4] = int(Rrx6YsvjFQ2y)
	fWImNyljoQReXa5,aPlzYJV6Imx19,rl0DdXHR9kS8OzKsi7yuGfIqM = list(zip(*YHajiT4VltmZ))
	for OOG1iPYhTKQ4 in sorted(zeqfF87Dt1U0VcNvslxnX4CTIkh9Mr):
		if OOG1iPYhTKQ4 not in fWImNyljoQReXa5:
			Sf8YkqeAlUxWwMvyuiQGL += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+OOG1iPYhTKQ4+A41nqbj3wYt(u"ࠩ࠽ࠤࠬᄼ")+YVr6St5P4xsFC0aARQGKfiegD+A41nqbj3wYt(u"่ࠪฬ๊้ࠦฮาࠫᄽ")+WBDnh75CaLEvkcN6p4ez2KXrV3M
			if OOG1iPYhTKQ4 not in A3pXVFdyP1.non_videos_actions: WXZ4HTO7PSFmMp += tTChquY7XSRg4e+OOG1iPYhTKQ4
	for ipa9lmsneRCLZAXJyNO,qQOZvusy1Jx5VE in F7FDaijrlLQfJxhkmAW6wMVnu:
		ipa9lmsneRCLZAXJyNO = clFjTSgMODe7Nq0H3Vzs(ipa9lmsneRCLZAXJyNO)
		ZlQuIsKwUDnG2vNxXL1AoVjF += ipa9lmsneRCLZAXJyNO+kdRO82AImh0LFw(u"ࠫ࠿ࠦࠧᄾ")+e6HEdvUcaq8Gx+str(qQOZvusy1Jx5VE)+YVr6St5P4xsFC0aARQGKfiegD+jrD65cZUQ8uGR0IHNCkF
	hJaCboEre4Tc6AW8Uz = hJaCboEre4Tc6AW8Uz.strip(kcXMWrwiLDKeBHRsJ)
	gEbImLX6aAO28D3Pxo5ehjnvu = gEbImLX6aAO28D3Pxo5ehjnvu.strip(kcXMWrwiLDKeBHRsJ)
	WXZ4HTO7PSFmMp = WXZ4HTO7PSFmMp.strip(kcXMWrwiLDKeBHRsJ)
	VV4R3JGFnLZyeXfS9vblBwdxPc = hJaCboEre4Tc6AW8Uz+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࠦࠠ࠯࠰ࠣࠤࠬᄿ")+gEbImLX6aAO28D3Pxo5ehjnvu
	Xr8UON3oicm9DQtz2gwphG  = A41nqbj3wYt(u"࠭ๅ้ษๅ฽ࠥา๊ะหุࠣ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦࠨๆ่ࠣห้ษใฬำࠣษ้๏ࠠศๆฦๆ้࠯ࠧᅀ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+beV5l2D8HznyJI0(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊่็ࠣๅ์๐ࠠๆ่ࠣ฽๋ีใ๊ࠡ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ๎ไศ่๊ࠢࠥอไๆ๊ๅ฽ࠬᅁ")+WBDnh75CaLEvkcN6p4ez2KXrV3M
	Xr8UON3oicm9DQtz2gwphG += e6HEdvUcaq8Gx+VV4R3JGFnLZyeXfS9vblBwdxPc+YVr6St5P4xsFC0aARQGKfiegD+Z9FPQvwlbjLTh(u"ࠨ࡞ࡱࡠࡳ࠭ᅂ")
	Xr8UON3oicm9DQtz2gwphG += oiWNFYzcIUeh(u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅ่๊ࠢ์อࠠศๆหี๋อๅอࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่ࠡࠪีฯฮษࠡลหะิ๐ࠩࠨᅃ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊้ࠠฮ๋ำ๋ࠥิไๆฬࠤ฾์ฯไࠢฦ์ࠥ็๊ࠡษ็้ํู่ࠡล๋ࠤๆ๐ࠠศๆหี๋อๅอࠩᅄ")+WBDnh75CaLEvkcN6p4ez2KXrV3M
	WXZ4HTO7PSFmMp = tTChquY7XSRg4e.join(sorted(WXZ4HTO7PSFmMp.split(tTChquY7XSRg4e)))
	Xr8UON3oicm9DQtz2gwphG += e6HEdvUcaq8Gx+WXZ4HTO7PSFmMp+YVr6St5P4xsFC0aARQGKfiegD
	oNnOAZt3YWvi81Ha5dTpcBPSlk,tkQV4PnGHMU2YLpD13Zrwgyjso,BaoTfkOwjdRKZb6AWXzQspFvhNSJ,WyfAVXqwsElBKJudQ = A41nqbj3wYt(u"࠶እ"),A41nqbj3wYt(u"࠶እ"),A41nqbj3wYt(u"࠶እ"),A41nqbj3wYt(u"࠶እ")
	all = x0MwvfUIz7[bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡆࡒࡌࠨᅅ")]
	if wwWzyF4ZpSQXKOgk569(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᅆ") in list(x0MwvfUIz7.keys()): oNnOAZt3YWvi81Ha5dTpcBPSlk = x0MwvfUIz7[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᅇ")]
	if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨᅈ") in list(x0MwvfUIz7.keys()): tkQV4PnGHMU2YLpD13Zrwgyjso = x0MwvfUIz7[KLX7hW0nBAEgy6m4SvH(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩᅉ")]
	if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ᅊ") in list(x0MwvfUIz7.keys()): BaoTfkOwjdRKZb6AWXzQspFvhNSJ = x0MwvfUIz7[wwWzyF4ZpSQXKOgk569(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧᅋ")]
	if SI7eBdND4lx8pt5Qk(u"ࠫࡗࡋࡐࡐࡕࠪᅌ") in list(x0MwvfUIz7.keys()): WyfAVXqwsElBKJudQ = x0MwvfUIz7[jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡘࡅࡑࡑࡖࠫᅍ")]
	nX1sz76lbRExVGOg4pfwj0qD = all-oNnOAZt3YWvi81Ha5dTpcBPSlk-tkQV4PnGHMU2YLpD13Zrwgyjso-BaoTfkOwjdRKZb6AWXzQspFvhNSJ-WyfAVXqwsElBKJudQ
	PN2AmVoTyks5xOR1Ib9BqSQ,uMnk61L9Nx8Rc = O6hMZxndC1gWak3Re[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	PN2AmVoTyks5xOR1Ib9BqSQ,Gxp6uUhytI3mfBFYO7ETLVXdZMo = O6hMZxndC1gWak3Re[wnaWTQM7VJPkZzO9eoSyFU4]
	bg3XtkRJ1dv5E = uMnk61L9Nx8Rc-Gxp6uUhytI3mfBFYO7ETLVXdZMo
	SUR7dbEPGoZnNqrt += RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(Gxp6uUhytI3mfBFYO7ETLVXdZMo)+YVr6St5P4xsFC0aARQGKfiegD+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪᅎ")
	SUR7dbEPGoZnNqrt += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(bg3XtkRJ1dv5E)+YVr6St5P4xsFC0aARQGKfiegD+bawK2j7T81Nrc4GWs05xzDg(u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫᅏ")
	SUR7dbEPGoZnNqrt += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(uMnk61L9Nx8Rc)+YVr6St5P4xsFC0aARQGKfiegD+IMjqygdfYSKpHlWu5Aa(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩᅐ")
	SUR7dbEPGoZnNqrt += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(len(O6hMZxndC1gWak3Re[rVy3Ops0mohYkT(u"࠲ኦ"):]))+YVr6St5P4xsFC0aARQGKfiegD+yobpaW7sBqtKRrv(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧᅑ")
	for l7L3xtUSXrRAV6nwEMpBv4yimKc0H9,ofEcIgWvaQizr9uTq8LBApwH0 in O6hMZxndC1gWak3Re[gPE1XB87fQl(u"࠳ኧ"):]:
		l7L3xtUSXrRAV6nwEMpBv4yimKc0H9 = clFjTSgMODe7Nq0H3Vzs(l7L3xtUSXrRAV6nwEMpBv4yimKc0H9)
		l7L3xtUSXrRAV6nwEMpBv4yimKc0H9 = l7L3xtUSXrRAV6nwEMpBv4yimKc0H9.strip(kcXMWrwiLDKeBHRsJ).strip(KLX7hW0nBAEgy6m4SvH(u"ࠪࠤ࠳࠭ᅒ"))
		SUR7dbEPGoZnNqrt += l7L3xtUSXrRAV6nwEMpBv4yimKc0H9+gPE1XB87fQl(u"ࠫ࠿ࠦࠧᅓ")+e6HEdvUcaq8Gx+str(ofEcIgWvaQizr9uTq8LBApwH0)+YVr6St5P4xsFC0aARQGKfiegD+gPE1XB87fQl(u"ࠬࠦࠠࠡࠩᅔ")
	zFmA4bcXkZxeT1vN603nU9 += RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(nX1sz76lbRExVGOg4pfwj0qD)+YVr6St5P4xsFC0aARQGKfiegD+VP70ytiFNMBl6vHDaW(u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫᅕ")
	zFmA4bcXkZxeT1vN603nU9 += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(oNnOAZt3YWvi81Ha5dTpcBPSlk)+YVr6St5P4xsFC0aARQGKfiegD+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ุࠧๆหหฯࠦำ๋ำไีࠥࡇࡐࡊࠢ࠽ࠤࠬᅖ")
	zFmA4bcXkZxeT1vN603nU9 += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(WyfAVXqwsElBKJudQ)+YVr6St5P4xsFC0aARQGKfiegD+gPE1XB87fQl(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫᅗ")
	zFmA4bcXkZxeT1vN603nU9 += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(tkQV4PnGHMU2YLpD13Zrwgyjso)+YVr6St5P4xsFC0aARQGKfiegD+gPE1XB87fQl(u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭ᅘ")
	zFmA4bcXkZxeT1vN603nU9 += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(BaoTfkOwjdRKZb6AWXzQspFvhNSJ)+YVr6St5P4xsFC0aARQGKfiegD+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩᅙ")
	zFmA4bcXkZxeT1vN603nU9 += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+str(len(F7FDaijrlLQfJxhkmAW6wMVnu))+YVr6St5P4xsFC0aARQGKfiegD+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫᅚ")
	zFmA4bcXkZxeT1vN603nU9 += tzZ6PhyDOUnwLM3pdK(u"ࠬࡢ࡮࡝ࡰࠪᅛ")+ZlQuIsKwUDnG2vNxXL1AoVjF
	Pgbtx1uwX52DEk7Jf(gPE1XB87fQl(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅜ"),SI7eBdND4lx8pt5Qk(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨᅝ"),zFmA4bcXkZxeT1vN603nU9,beV5l2D8HznyJI0(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᅞ"))
	Pgbtx1uwX52DEk7Jf(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡦࡩࡳࡺࡥࡳࠩᅟ"),VP70ytiFNMBl6vHDaW(u"้ࠪํอโฺࠢสุฯเไหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ᅠ"),Xr8UON3oicm9DQtz2gwphG,A6iX18qgyOFlZxz7sc(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᅡ"))
	Pgbtx1uwX52DEk7Jf(ZLr5gRSkFewKdUos90bM(u"ࠬࡲࡥࡧࡶࠪᅢ"),iySORMYxWXszEH18(u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡษึฮำีๅหࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨᅣ"),Sf8YkqeAlUxWwMvyuiQGL,tzZ6PhyDOUnwLM3pdK(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᅤ"))
	return
def GrJLcYZpQxAb4Sz2IaMXNshOKV3y():
	eJU6bsndE1mI0F = KLX7hW0nBAEgy6m4SvH(u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰࠪᅥ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+KLX7hW0nBAEgy6m4SvH(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᅦ")+YVr6St5P4xsFC0aARQGKfiegD+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࠬᅧ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࠬᅨ")+YVr6St5P4xsFC0aARQGKfiegD+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤ๊฿ไ้็สฮࠥอไษำ้ห๊าࠧᅩ")
	Pgbtx1uwX52DEk7Jf(rVy3Ops0mohYkT(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅪ"),Ew26Hg4SIj,eJU6bsndE1mI0F,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᅫ"))
	return
def tUbhlG5V9MqwWayB02o3JZADevm():
	eJU6bsndE1mI0F = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ᅬ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+A3pXVFdyP1.SITESURLS[ZLr5gRSkFewKdUos90bM(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨᅭ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+YVr6St5P4xsFC0aARQGKfiegD+A41nqbj3wYt(u"ࠪࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠧᅮ")+e6HEdvUcaq8Gx+A3pXVFdyP1.SITESURLS[wwWzyF4ZpSQXKOgk569(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪᅯ")][wnaWTQM7VJPkZzO9eoSyFU4]+YVr6St5P4xsFC0aARQGKfiegD
	eJU6bsndE1mI0F += pp7FcjEe6g(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬᅰ")+e6HEdvUcaq8Gx+A3pXVFdyP1.SITESURLS[eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬᅱ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+YVr6St5P4xsFC0aARQGKfiegD+oiWNFYzcIUeh(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫᅲ")+e6HEdvUcaq8Gx+A3pXVFdyP1.SITESURLS[mq5t9JXSdHT8yfDVF(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧᅳ")][wnaWTQM7VJPkZzO9eoSyFU4]+YVr6St5P4xsFC0aARQGKfiegD
	eJU6bsndE1mI0F += CyHU86ZeYT5BWRcitSm2I(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬᅴ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+A3pXVFdyP1.SITESURLS[YYQS36fyPvtuzcEmRL(u"ࠪࡊࡎࡒࡅࡔࡡࡖࡓ࡚ࡘࡃࡆࡕࠪᅵ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+YVr6St5P4xsFC0aARQGKfiegD
	Pgbtx1uwX52DEk7Jf(gPE1XB87fQl(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᅶ"),beV5l2D8HznyJI0(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫᅷ"),eJU6bsndE1mI0F,kdRO82AImh0LFw(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᅸ"))
	return
def kbJxKBjfHo8hi73ILAaEdr(Cko84dAj7Dzu9E6r):
	pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(A41nqbj3wYt(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ᅹ")+Cko84dAj7Dzu9E6r+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࠫࠪᅺ"), r0D4C3z7Onqpa)
	return
def PfG0vqasTbjuQ4iF2():
	EOMr9e5BFQToPJvnphc1Ii3Vf8KHl(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡶࡸࡴࡶࠧᅻ"))
	pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(IMjqygdfYSKpHlWu5Aa(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤᅼ"))
	return
def DSbd8QuMmIEr0s4vBazGN():
	pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪᅽ"), r0D4C3z7Onqpa)
	return
def LL5P4jSOGqebuwTpt():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,KLX7hW0nBAEgy6m4SvH(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬᅾ"))
	return
def lLCqRSF2e1AvPOBIXwY3n0ycsz():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩᅿ"))
	return
def gSP86BM5UWr(iHRy4QsrdAfI6mVENT8F=ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᆀ"),showDialogs=r0D4C3z7Onqpa):
	NnA5Md0F2SvJQ = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(A6iX18qgyOFlZxz7sc(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫᆁ"))
	data = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(NnA5Md0F2SvJQ)
	ZivNzHn02gkOqI73EQAe6c1K = data[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᆂ")][SI7eBdND4lx8pt5Qk(u"ࠪࡺࡦࡲࡵࡦࠩᆃ")]
	if YVzokG2yZqrh3w8bU: ZivNzHn02gkOqI73EQAe6c1K = ZivNzHn02gkOqI73EQAe6c1K.encode(e87cIA5vwOQLDEP1)
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩᆄ")+ZivNzHn02gkOqI73EQAe6c1K+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧᆅ")+iHRy4QsrdAfI6mVENT8F+CyHU86ZeYT5BWRcitSm2I(u"࠭ࠠภࠣࠪᆆ"))
		if kkLdeyJUsSiK9YwFZr4lPbVE!=eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠳ከ"): return KiryBCvngZzF85UN6xSDlOVweL4I9
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,v3CecxmgyLX0GSHqoPUj,wUPH6BFzvtni14yZX5 = a8cdmrqt10o6WfDj9B(iHRy4QsrdAfI6mVENT8F,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy:
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,Z9FPQvwlbjLTh(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩᆇ"))
		U2vri4t3a8S = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(Z9FPQvwlbjLTh(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬᆈ")+iHRy4QsrdAfI6mVENT8F+A6iX18qgyOFlZxz7sc(u"ࠩࠥࢁࢂ࠭ᆉ"))
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r0D4C3z7Onqpa if wwWzyF4ZpSQXKOgk569(u"ࠪࡓࡐ࠭ᆊ") in U2vri4t3a8S else KiryBCvngZzF85UN6xSDlOVweL4I9
		x54xSdnCFHZ8yliofzOBK.sleep(A41nqbj3wYt(u"࠴ኩ"))
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫᆋ"))
	elif showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,VP70ytiFNMBl6vHDaW(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧᆌ"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def jPchH9LmAWKizFMDQxXNgOZ6ka3C5():
	url = KLX7hW0nBAEgy6m4SvH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫᆍ")
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,A6iX18qgyOFlZxz7sc(u"ࠧࡈࡇࡗࠫᆎ"),url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫᆏ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	YVWDRoxQhZ9B13d = p7dwlH1PRStBgyMUW.findall(IMjqygdfYSKpHlWu5Aa(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨᆐ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	YVWDRoxQhZ9B13d = YVWDRoxQhZ9B13d[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].split(Z9FPQvwlbjLTh(u"ࠪ࠱ࠬᆑ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	zKgYxmh4iBaZ7cAR = str(CCPXJ7wnNLOg0ZoekcmpdSKI)
	Sf8YkqeAlUxWwMvyuiQGL = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᆒ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+YVWDRoxQhZ9B13d+YVr6St5P4xsFC0aARQGKfiegD
	Sf8YkqeAlUxWwMvyuiQGL += tzZ6PhyDOUnwLM3pdK(u"ࠬࡢ࡮࡝ࡰࠪᆓ")+VP70ytiFNMBl6vHDaW(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆔ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+zKgYxmh4iBaZ7cAR+YVr6St5P4xsFC0aARQGKfiegD
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,Sf8YkqeAlUxWwMvyuiQGL)
	return
def uOwQL2DbBNi4e5AjJkv7lIoh8d0arC():
	VhN4rzTdKqOMoFs0EHyw8vig6ef,YKSlNEL4DUpM3GcmWVn,SjNPUs5H12fBxTt3gulA4 = KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	ddnEB37A6ZMysoFe,KwGOZStW0Vzb2du46,nHBuWdtYVx5P4hfgocQ9C3EMwqJX = KiryBCvngZzF85UN6xSDlOVweL4I9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	USiR3rv2hup9j = [iySORMYxWXszEH18(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᆕ"),YYQS36fyPvtuzcEmRL(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪᆖ"),oiWNFYzcIUeh(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆗ")]
	jWylPFA81zQGdTDMJ5 = SBguW0zN9UInl(USiR3rv2hup9j)
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in USiR3rv2hup9j:
		if B40Qr5hlSgNm1kuXD3ZFpnyC9 not in list(jWylPFA81zQGdTDMJ5.keys()): continue
		RsLeaPcMIo23zQEZrv1F9,NkfLSl5eDxA8CB0,y3xiFBvfTXkmhP,mzwhtOrv8qu2YKZpT,hh8zrbVsYG3MNUC7HPp4vSxE,vvH0QznZxq2lPeGu8rLibFsc4jh,OYB617E9pCTzXLUsfwtKWu2x = jWylPFA81zQGdTDMJ5[B40Qr5hlSgNm1kuXD3ZFpnyC9]
		if B40Qr5hlSgNm1kuXD3ZFpnyC9==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᆘ"):
			ddnEB37A6ZMysoFe = RsLeaPcMIo23zQEZrv1F9
			KwGOZStW0Vzb2du46 = NkfLSl5eDxA8CB0+Z9FPQvwlbjLTh(u"ࠫࠥࠦࠠࠡࠪࠣࠫᆙ")+v2oRq5AhQzcx(vvH0QznZxq2lPeGu8rLibFsc4jh)+CyHU86ZeYT5BWRcitSm2I(u"ࠬࠦࠩࠨᆚ")
			nHBuWdtYVx5P4hfgocQ9C3EMwqJX = mzwhtOrv8qu2YKZpT
		elif B40Qr5hlSgNm1kuXD3ZFpnyC9==oiWNFYzcIUeh(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨᆛ"):
			VhN4rzTdKqOMoFs0EHyw8vig6ef = VhN4rzTdKqOMoFs0EHyw8vig6ef or RsLeaPcMIo23zQEZrv1F9
			YKSlNEL4DUpM3GcmWVn += CyHU86ZeYT5BWRcitSm2I(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᆜ")+NkfLSl5eDxA8CB0+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨᆝ")+v2oRq5AhQzcx(vvH0QznZxq2lPeGu8rLibFsc4jh)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠣ࠭ࠬᆞ")
			SjNPUs5H12fBxTt3gulA4 += n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࠤࠥ࠲ࠠࠡࠩᆟ")+mzwhtOrv8qu2YKZpT
		elif B40Qr5hlSgNm1kuXD3ZFpnyC9==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᆠ"):
			KfxnsP0kFEgtJG3r615 = RsLeaPcMIo23zQEZrv1F9
			K582vMX6HkgpaCtYoP7 = NkfLSl5eDxA8CB0+kdRO82AImh0LFw(u"ࠬࠦࠠࠡࠢࠫࠤࠬᆡ")+v2oRq5AhQzcx(vvH0QznZxq2lPeGu8rLibFsc4jh)+kdRO82AImh0LFw(u"࠭ࠠࠪࠩᆢ")
			cp0rwzKyYeW9GHBFM5P = mzwhtOrv8qu2YKZpT
	YKSlNEL4DUpM3GcmWVn = YKSlNEL4DUpM3GcmWVn.strip(CyHU86ZeYT5BWRcitSm2I(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᆣ"))
	SjNPUs5H12fBxTt3gulA4 = SjNPUs5H12fBxTt3gulA4.strip(IMjqygdfYSKpHlWu5Aa(u"ࠨࠢࠣ࠰ࠥࠦࠧᆤ"))
	Dp04tKTInv8xOdlC63fUuMeSEFXw1  = pp7FcjEe6g(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧᆥ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+nHBuWdtYVx5P4hfgocQ9C3EMwqJX+YVr6St5P4xsFC0aARQGKfiegD
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 += WBDnh75CaLEvkcN6p4ez2KXrV3M+rVy3Ops0mohYkT(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆦ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+KwGOZStW0Vzb2du46+YVr6St5P4xsFC0aARQGKfiegD
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 += pp7FcjEe6g(u"ࠫࡡࡴ࡜࡯ࠩᆧ")+A6iX18qgyOFlZxz7sc(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪᆨ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+SjNPUs5H12fBxTt3gulA4+YVr6St5P4xsFC0aARQGKfiegD
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 += WBDnh75CaLEvkcN6p4ez2KXrV3M+beV5l2D8HznyJI0(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨᆩ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+YKSlNEL4DUpM3GcmWVn+YVr6St5P4xsFC0aARQGKfiegD
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 += eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧ࡝ࡰ࡟ࡲࠬᆪ")+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆫ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+cp0rwzKyYeW9GHBFM5P+YVr6St5P4xsFC0aARQGKfiegD
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 += WBDnh75CaLEvkcN6p4ez2KXrV3M+A6iX18qgyOFlZxz7sc(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪᆬ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+K582vMX6HkgpaCtYoP7+YVr6St5P4xsFC0aARQGKfiegD
	RsLeaPcMIo23zQEZrv1F9 = ddnEB37A6ZMysoFe or VhN4rzTdKqOMoFs0EHyw8vig6ef
	if RsLeaPcMIo23zQEZrv1F9:
		header = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬᆭ")
		ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬᆮ")
	else:
		header = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ᆯ")
		ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = wwWzyF4ZpSQXKOgk569(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨᆰ")
	arCiPYjFpSc3 = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨᆱ")
	UFAyS7c6KM50n8JPeCzQfEa = Dp04tKTInv8xOdlC63fUuMeSEFXw1+gPE1XB87fQl(u"ࠨ࡞ࡱࡠࡳ࠭ᆲ")+ygGuahJtKfEDr1vVjNelbFZ4nB6oHI+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩ࡟ࡲࡡࡴࠧᆳ")+arCiPYjFpSc3
	Pgbtx1uwX52DEk7Jf(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡶ࡮࡭ࡨࡵࠩᆴ"),header,UFAyS7c6KM50n8JPeCzQfEa,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᆵ"))
	return RsLeaPcMIo23zQEZrv1F9
def KKnIuDShcQEovOH32R16rgV8(B40Qr5hlSgNm1kuXD3ZFpnyC9,OYB617E9pCTzXLUsfwtKWu2x,showDialogs):
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,pp7FcjEe6g(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨᆶ"))
		if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return KiryBCvngZzF85UN6xSDlOVweL4I9
	bMdY8Aqzc0 = zz3FACPKTpqWhEYsf1o9v(OYB617E9pCTzXLUsfwtKWu2x,{},showDialogs)
	if bMdY8Aqzc0:
		u9hxkFNBLfV2l = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(uxKbUolc0WrM57w,B40Qr5hlSgNm1kuXD3ZFpnyC9)
		r670fZQYnxlNOUoVBbMJa(u9hxkFNBLfV2l,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
		import zipfile as i6XnFBUMWsOgvxlYHmEA9I,io as OMGtHvJijkCIQ1K5P3Subm
		G8mS91IczwnUQ5py0oTeuvi = OMGtHvJijkCIQ1K5P3Subm.BytesIO(bMdY8Aqzc0)
		try:
			jJlQ3k0b6uE5oy1eAw = i6XnFBUMWsOgvxlYHmEA9I.ZipFile(G8mS91IczwnUQ5py0oTeuvi)
			jJlQ3k0b6uE5oy1eAw.extractall(uxKbUolc0WrM57w)
			x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
			pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(tzZ6PhyDOUnwLM3pdK(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᆷ"))
			x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = sVneRM86IEgYhA0lO1wdvj5DQo3(B40Qr5hlSgNm1kuXD3ZFpnyC9)
		except: FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	if showDialogs:
		if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,pp7FcjEe6g(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫᆸ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ᆹ"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def MuryTcfZxnmGwIFUSa104E(B40Qr5hlSgNm1kuXD3ZFpnyC9,showDialogs=r0D4C3z7Onqpa):
	if showDialogs==WnNGfosHr5STAq8j7miwyRZ6eOUbV: showDialogs = r0D4C3z7Onqpa
	nJywjNBbQzsU340XDLC1Yr6eM = s7sKbH9N5LGVliq6jR([B40Qr5hlSgNm1kuXD3ZFpnyC9])
	QQKjCzecMlDps7,sVpwjebI2U9PL0fQxG34ZMT = nJywjNBbQzsU340XDLC1Yr6eM[B40Qr5hlSgNm1kuXD3ZFpnyC9]
	if sVpwjebI2U9PL0fQxG34ZMT:
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r0D4C3z7Onqpa
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫᆺ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+ZLr5gRSkFewKdUos90bM(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ᆻ"))
	else:
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(YYQS36fyPvtuzcEmRL(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆼ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,WnNGfosHr5STAq8j7miwyRZ6eOUbV+B40Qr5hlSgNm1kuXD3ZFpnyC9+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࠦ࡜࡯࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ์ฬ๊ศา่ส้ัࠦศฮษฯอ๊ࠥ็ศࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩᆽ"))
		if kkLdeyJUsSiK9YwFZr4lPbVE==pp7FcjEe6g(u"࠵ኪ"):
			pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ᆾ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+A41nqbj3wYt(u"ࠧࠪࠩᆿ"))
			x54xSdnCFHZ8yliofzOBK.sleep(Z9FPQvwlbjLTh(u"࠶ካ"))
			pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(tzZ6PhyDOUnwLM3pdK(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨᇀ"))
			x54xSdnCFHZ8yliofzOBK.sleep(GHg28TBchiyn6l(u"࠷ኬ"))
			while pYDdXfVh5c0O1bMT6a78HKBiQw3.getCondVisibility(gPE1XB87fQl(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ᇁ")): x54xSdnCFHZ8yliofzOBK.sleep(iySORMYxWXszEH18(u"࠱ክ"))
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = sVneRM86IEgYhA0lO1wdvj5DQo3(B40Qr5hlSgNm1kuXD3ZFpnyC9)
			if showDialogs and FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪฮ๊ࠦแฮืࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪᇂ"))
			elif showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭ᇃ"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def TT2C9Sml3at(showDialogs):
	if not showDialogs: kkLdeyJUsSiK9YwFZr4lPbVE = r0D4C3z7Onqpa
	else: kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(kdRO82AImh0LFw(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᇄ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,ZLr5gRSkFewKdUos90bM(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢฦ๊ࠥะืๅส้๋ࠣࠦใ้ัํࠤๆำี๊ࠡอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡมࠪᇅ"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==GHg28TBchiyn6l(u"࠲ኮ"):
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪᇆ"))
		if showDialogs:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨᇇ"))
	return
def uiHe5Sd8hrIa3YUnDBfLOtQJ1RWbzV():
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,A6iX18qgyOFlZxz7sc(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᇈ"),tzZ6PhyDOUnwLM3pdK(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᇉ"))
	jPchH9LmAWKizFMDQxXNgOZ6ka3C5()
	RsLeaPcMIo23zQEZrv1F9 = uOwQL2DbBNi4e5AjJkv7lIoh8d0arC()
	if RsLeaPcMIo23zQEZrv1F9:
		pBw9TxneIRC8(r0D4C3z7Onqpa)
		TT2C9Sml3at(r0D4C3z7Onqpa)
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def sVneRM86IEgYhA0lO1wdvj5DQo3(B40Qr5hlSgNm1kuXD3ZFpnyC9):
	APpdhB1Fk58MmJH7CjVntowyaY = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧᇊ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+iySORMYxWXszEH18(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᇋ"))
	succeeded = r0D4C3z7Onqpa if jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡏࡌࠩᇌ") in APpdhB1Fk58MmJH7CjVntowyaY else KiryBCvngZzF85UN6xSDlOVweL4I9
	return succeeded
def A0pT7YLJNBsun1XrOh8kK6CaljHe(B40Qr5hlSgNm1kuXD3ZFpnyC9):
	APpdhB1Fk58MmJH7CjVntowyaY = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(IMjqygdfYSKpHlWu5Aa(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᇍ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+wwWzyF4ZpSQXKOgk569(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧᇎ"))
	succeeded = r0D4C3z7Onqpa if A41nqbj3wYt(u"ࠩࡒࡏࠬᇏ") in APpdhB1Fk58MmJH7CjVntowyaY else KiryBCvngZzF85UN6xSDlOVweL4I9
	return succeeded
def a8cdmrqt10o6WfDj9B(B40Qr5hlSgNm1kuXD3ZFpnyC9,showDialogs,IeViD196uMYv,jWylPFA81zQGdTDMJ5=None):
	kkLdeyJUsSiK9YwFZr4lPbVE,succeeded,v3CecxmgyLX0GSHqoPUj,NkfLSl5eDxA8CB0 = r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9,GHg28TBchiyn6l(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᇐ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if not jWylPFA81zQGdTDMJ5: jWylPFA81zQGdTDMJ5 = SBguW0zN9UInl([B40Qr5hlSgNm1kuXD3ZFpnyC9])
	if B40Qr5hlSgNm1kuXD3ZFpnyC9 in list(jWylPFA81zQGdTDMJ5.keys()):
		RsLeaPcMIo23zQEZrv1F9,NkfLSl5eDxA8CB0,y3xiFBvfTXkmhP,mzwhtOrv8qu2YKZpT,hh8zrbVsYG3MNUC7HPp4vSxE,vvH0QznZxq2lPeGu8rLibFsc4jh,OYB617E9pCTzXLUsfwtKWu2x = jWylPFA81zQGdTDMJ5[B40Qr5hlSgNm1kuXD3ZFpnyC9]
		if vvH0QznZxq2lPeGu8rLibFsc4jh==Z9FPQvwlbjLTh(u"ࠫ࡬ࡵ࡯ࡥࠩᇑ"):
			succeeded,v3CecxmgyLX0GSHqoPUj = r0D4C3z7Onqpa,ZLr5gRSkFewKdUos90bM(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭ᇒ")
			if IeViD196uMYv and showDialogs:
				kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,SI7eBdND4lx8pt5Qk(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ᇓ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+A6iX18qgyOFlZxz7sc(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา๋ࠪᇔ"))
				if kkLdeyJUsSiK9YwFZr4lPbVE:
					succeeded = KKnIuDShcQEovOH32R16rgV8(B40Qr5hlSgNm1kuXD3ZFpnyC9,OYB617E9pCTzXLUsfwtKWu2x,KiryBCvngZzF85UN6xSDlOVweL4I9)
					if succeeded:
						v3CecxmgyLX0GSHqoPUj = IMjqygdfYSKpHlWu5Aa(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᇕ")
						if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᇖ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
					else:
						v3CecxmgyLX0GSHqoPUj = A41nqbj3wYt(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᇗ")
						BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᇘ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
		else:
			if showDialogs:
				if vvH0QznZxq2lPeGu8rLibFsc4jh==bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᇙ"): eJU6bsndE1mI0F = YYQS36fyPvtuzcEmRL(u"࠭ๅห๊ๅๅฮ࠭ᇚ")
				elif vvH0QznZxq2lPeGu8rLibFsc4jh==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡰ࡮ࡧࠫᇛ"): eJU6bsndE1mI0F = KLX7hW0nBAEgy6m4SvH(u"ࠨไา๎๊ฯࠧᇜ")
				elif vvH0QznZxq2lPeGu8rLibFsc4jh==kdRO82AImh0LFw(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᇝ"): eJU6bsndE1mI0F = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ᇞ")
				kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫ์ึ็ࠡษ็ษ฻อแสࠢࠪᇟ")+eJU6bsndE1mI0F+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠภࠣ࡟ࡲࡡࡴࠧᇠ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
			if not kkLdeyJUsSiK9YwFZr4lPbVE: v3CecxmgyLX0GSHqoPUj = A41nqbj3wYt(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨᇡ")
			else:
				if vvH0QznZxq2lPeGu8rLibFsc4jh==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩᇢ"):
					succeeded = sVneRM86IEgYhA0lO1wdvj5DQo3(B40Qr5hlSgNm1kuXD3ZFpnyC9)
					if succeeded:
						v3CecxmgyLX0GSHqoPUj = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩᇣ")
						if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧᇤ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
					elif showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,IMjqygdfYSKpHlWu5Aa(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ᇥ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
				elif vvH0QznZxq2lPeGu8rLibFsc4jh in [Z9FPQvwlbjLTh(u"ࠫࡴࡲࡤࠨᇦ"),pp7FcjEe6g(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᇧ")]:
					succeeded = KKnIuDShcQEovOH32R16rgV8(B40Qr5hlSgNm1kuXD3ZFpnyC9,OYB617E9pCTzXLUsfwtKWu2x,KiryBCvngZzF85UN6xSDlOVweL4I9)
					if succeeded:
						if vvH0QznZxq2lPeGu8rLibFsc4jh==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࡯࡭ࡦࠪᇨ"): v3CecxmgyLX0GSHqoPUj = Z9FPQvwlbjLTh(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨᇩ")
						elif vvH0QznZxq2lPeGu8rLibFsc4jh==KLX7hW0nBAEgy6m4SvH(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩᇪ"): v3CecxmgyLX0GSHqoPUj = wwWzyF4ZpSQXKOgk569(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᇫ")
						NkfLSl5eDxA8CB0 = mzwhtOrv8qu2YKZpT
						if showDialogs:
							if v3CecxmgyLX0GSHqoPUj==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫᇬ"): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,A6iX18qgyOFlZxz7sc(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨᇭ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
							elif v3CecxmgyLX0GSHqoPUj==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨᇮ"): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧᇯ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
					elif showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,oiWNFYzcIUeh(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪᇰ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
	elif showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,CyHU86ZeYT5BWRcitSm2I(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ᇱ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
	return succeeded,v3CecxmgyLX0GSHqoPUj,NkfLSl5eDxA8CB0
def ubdUHN8VEmDjlRSXo5x(B40Qr5hlSgNm1kuXD3ZFpnyC9,showDialogs,haKjLDXqHPCkBQct2xM4A):
	INh7gd9zKasXk = x0p6hU1tkV4oBXnm2SDsNPlY7.connect(O3yquo9YEKRTF7LDWfAdpc1wshl6)
	INh7gd9zKasXk.text_factory = str
	GSB3DNKz9vFbaEo8 = INh7gd9zKasXk.cursor()
	succeeded,gvrN1eUGs2nmuT9D7M8hSow5pWR = r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9
	try:
		rv3lDF5SHt6W = Z9FPQvwlbjLTh(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᇲ")
		GSB3DNKz9vFbaEo8.execute(tzZ6PhyDOUnwLM3pdK(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᇳ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+A6iX18qgyOFlZxz7sc(u"ࠫࠧࠦ࠻ࠨᇴ"))
		n407uaQIPXEqUzwhLe8v3rSM6 = GSB3DNKz9vFbaEo8.fetchall()
		if n407uaQIPXEqUzwhLe8v3rSM6 and rv3lDF5SHt6W not in str(n407uaQIPXEqUzwhLe8v3rSM6): GSB3DNKz9vFbaEo8.execute(rVy3Ops0mohYkT(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩᇵ")+rv3lDF5SHt6W+SI7eBdND4lx8pt5Qk(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᇶ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+bawK2j7T81Nrc4GWs05xzDg(u"ࠧࠣࠢ࠾ࠫᇷ"))
		ss4Gm8xVNDAwMavR = iySORMYxWXszEH18(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫᇸ") if YVzokG2yZqrh3w8bU else pp7FcjEe6g(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨᇹ")
		GSB3DNKz9vFbaEo8.execute(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫᇺ")+ss4Gm8xVNDAwMavR+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᇻ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࠨࠠ࠼ࠩᇼ"))
		n407uaQIPXEqUzwhLe8v3rSM6 = GSB3DNKz9vFbaEo8.fetchall()
		if n407uaQIPXEqUzwhLe8v3rSM6:
			if showDialogs: kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪᇽ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧᇾ")+e6HEdvUcaq8Gx+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢࠪᇿ")+YVr6St5P4xsFC0aARQGKfiegD+oiWNFYzcIUeh(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧሀ"))
			else: kkLdeyJUsSiK9YwFZr4lPbVE = wnaWTQM7VJPkZzO9eoSyFU4
			if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
				gvrN1eUGs2nmuT9D7M8hSow5pWR = r0D4C3z7Onqpa
				GSB3DNKz9vFbaEo8.execute(CyHU86ZeYT5BWRcitSm2I(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩሁ")+ss4Gm8xVNDAwMavR+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩሂ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+YYQS36fyPvtuzcEmRL(u"ࠬࠨࠠ࠼ࠩሃ"))
		elif haKjLDXqHPCkBQct2xM4A:
			if showDialogs: kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,KLX7hW0nBAEgy6m4SvH(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪሄ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+oiWNFYzcIUeh(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧህ")+e6HEdvUcaq8Gx+kdRO82AImh0LFw(u"ࠨ่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ሆ")+YVr6St5P4xsFC0aARQGKfiegD+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧሇ"))
			else: kkLdeyJUsSiK9YwFZr4lPbVE = wnaWTQM7VJPkZzO9eoSyFU4
			if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
				gvrN1eUGs2nmuT9D7M8hSow5pWR = r0D4C3z7Onqpa
				if YVzokG2yZqrh3w8bU: GSB3DNKz9vFbaEo8.execute(A41nqbj3wYt(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩለ")+ss4Gm8xVNDAwMavR+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫሉ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࠨࠩࠡ࠽ࠪሊ"))
				else: GSB3DNKz9vFbaEo8.execute(IMjqygdfYSKpHlWu5Aa(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬላ")+ss4Gm8xVNDAwMavR+tzZ6PhyDOUnwLM3pdK(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫሌ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+A41nqbj3wYt(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨል"))
	except: succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
	INh7gd9zKasXk.commit()
	INh7gd9zKasXk.close()
	if gvrN1eUGs2nmuT9D7M8hSow5pWR:
		x54xSdnCFHZ8yliofzOBK.sleep(Z9FPQvwlbjLTh(u"࠳ኯ"))
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ሎ"))
		x54xSdnCFHZ8yliofzOBK.sleep(Z9FPQvwlbjLTh(u"࠴ኰ"))
		if showDialogs:
			if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,A6iX18qgyOFlZxz7sc(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫሏ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
			else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬሐ")+B40Qr5hlSgNm1kuXD3ZFpnyC9)
	return gvrN1eUGs2nmuT9D7M8hSow5pWR
def rreTLqOBJcdvh2yA(USiR3rv2hup9j,showDialogs,IeViD196uMYv,haKjLDXqHPCkBQct2xM4A):
	jWylPFA81zQGdTDMJ5 = SBguW0zN9UInl(USiR3rv2hup9j)
	hinHaDYo0fvVP6KZCBMlF5ew8SuR = KiryBCvngZzF85UN6xSDlOVweL4I9
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in USiR3rv2hup9j:
		succeeded,v3CecxmgyLX0GSHqoPUj,NkfLSl5eDxA8CB0 = a8cdmrqt10o6WfDj9B(B40Qr5hlSgNm1kuXD3ZFpnyC9,showDialogs,IeViD196uMYv,jWylPFA81zQGdTDMJ5)
		gvrN1eUGs2nmuT9D7M8hSow5pWR = ubdUHN8VEmDjlRSXo5x(B40Qr5hlSgNm1kuXD3ZFpnyC9,showDialogs,haKjLDXqHPCkBQct2xM4A)
		if gvrN1eUGs2nmuT9D7M8hSow5pWR: hinHaDYo0fvVP6KZCBMlF5ew8SuR = r0D4C3z7Onqpa
	if hinHaDYo0fvVP6KZCBMlF5ew8SuR:
		x54xSdnCFHZ8yliofzOBK.sleep(rVy3Ops0mohYkT(u"࠵኱"))
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(GHg28TBchiyn6l(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩሑ"))
		x54xSdnCFHZ8yliofzOBK.sleep(A41nqbj3wYt(u"࠶ኲ"))
	if showDialogs:
		if len(USiR3rv2hup9j)>Z9FPQvwlbjLTh(u"࠷ኳ"): BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬሒ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫሓ")+USiR3rv2hup9j[rVy3Ops0mohYkT(u"࠰ኴ")])
	return
def pBw9TxneIRC8(showDialogs):
	aW28oxZpcwqLfuOrHsmFz = [eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ሔ"),tzZ6PhyDOUnwLM3pdK(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫሕ"),kdRO82AImh0LFw(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧሖ"),SI7eBdND4lx8pt5Qk(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫሗ")]
	xJ2wlCFKHr90EfG6s = [wwWzyF4ZpSQXKOgk569(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧመ"),mq5t9JXSdHT8yfDVF(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧሙ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪሚ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪማ"),pp7FcjEe6g(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪሜ"),kdRO82AImh0LFw(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧም")]
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in xJ2wlCFKHr90EfG6s: A0pT7YLJNBsun1XrOh8kK6CaljHe(B40Qr5hlSgNm1kuXD3ZFpnyC9)
	rreTLqOBJcdvh2yA(aW28oxZpcwqLfuOrHsmFz,showDialogs,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	return