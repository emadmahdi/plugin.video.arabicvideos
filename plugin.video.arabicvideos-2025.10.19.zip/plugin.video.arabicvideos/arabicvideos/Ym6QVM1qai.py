# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SHAHID4U'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SH4_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
headers = {'User-Agent':E1ltCBVyML6PAUNY(True)}
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==110: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==111: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==112: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==113: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,True)
	elif mode==114: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'FULL_FILTER___'+text)
	elif mode==115: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'DEFINED_FILTER___'+text)
	elif mode==116: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,False)
	elif mode==119: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(WadGEeh1MBIXkpfP38qAv7ryslY.url,'url')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,119,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',VVDAncSMUjeu8Ii,115)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',VVDAncSMUjeu8Ii,114)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',VVDAncSMUjeu8Ii,111,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('simple-filter(.*?)adv-filter',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for filter,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			url = VVDAncSMUjeu8Ii+filter
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,111,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,filter)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="dropdown"(.*?)<script>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+SOw5EUxC9k
			if 'netflix' in SOw5EUxC9k: title = 'نيتفلكس'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,111)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,SUm0TCBiv7ck8sDMhOp=WnNGfosHr5STAq8j7miwyRZ6eOUbV,WadGEeh1MBIXkpfP38qAv7ryslY=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not WadGEeh1MBIXkpfP38qAv7ryslY: WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY,items,cIM3fQFnGYPxSV4eb9TvgWuokZA6H = [],[],[]
	if SUm0TCBiv7ck8sDMhOp=='featured': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('glide__slides(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('shows-container(.*?)pagination',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items: items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		if 'WWE' in title: continue
		if 'javascript' in SOw5EUxC9k: continue
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if '/film/' in SOw5EUxC9k or 'فيلم' in SOw5EUxC9k or any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,112,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,113,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/actor/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,111,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/series/' in SOw5EUxC9k and '/list' not in url:
			SOw5EUxC9k = SOw5EUxC9k+'/list'
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,111,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/list' in url and 'حلقة' in title:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,112,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,113,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY and SUm0TCBiv7ck8sDMhOp!='featured':
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		if SUm0TCBiv7ck8sDMhOp!='search': items = p7dwlH1PRStBgyMUW.findall('(updateQuery).*?>(.+?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		else: items = p7dwlH1PRStBgyMUW.findall('<li>.*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for SOw5EUxC9k,title in items:
			title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if SUm0TCBiv7ck8sDMhOp!='search':
				SOw5EUxC9k = url+'&page='+title if '?' in url else url+'?page='+title
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			if title: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,111,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SUm0TCBiv7ck8sDMhOp)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url,TXHuBYblEZKP18oNGD6fRpr2qAOzM):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('items d-flex(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if len(cKUQVwTMe9tZSY)>1:
		if '/season/' in cKUQVwTMe9tZSY[0]: EPtkQ9LnpUrjNsy,cTmHXhoJ60 = cKUQVwTMe9tZSY[0],cKUQVwTMe9tZSY[1]
		else: EPtkQ9LnpUrjNsy,cTmHXhoJ60 = cKUQVwTMe9tZSY[1],cKUQVwTMe9tZSY[0]
	else: EPtkQ9LnpUrjNsy,cTmHXhoJ60 = cKUQVwTMe9tZSY[0],cKUQVwTMe9tZSY[0]
	for zuEo6GDeAR5Z in range(2):
		if TXHuBYblEZKP18oNGD6fRpr2qAOzM: mode,type,KDCdHQmgxPE21tYz4VUowSv = 116,'folder',EPtkQ9LnpUrjNsy
		else: mode,type,KDCdHQmgxPE21tYz4VUowSv = 112,'video',cTmHXhoJ60
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if TXHuBYblEZKP18oNGD6fRpr2qAOzM and len(items)<2:
			TXHuBYblEZKP18oNGD6fRpr2qAOzM = False
			continue
		for SOw5EUxC9k,DnBsO9opYvF7wmy8NEtCZVq5Slc6k,gPvxJw89S35R21zDIbpFYkq7A in items:
			title = DnBsO9opYvF7wmy8NEtCZVq5Slc6k+kcXMWrwiLDKeBHRsJ+gPvxJw89S35R21zDIbpFYkq7A
			octplHnGwmE8bFqNdj7BiKvJ0VL(type,uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,mode)
		break
	if not items and '/episodes' in piN9Qlah4S:
		YhzDEKvmbfX = p7dwlH1PRStBgyMUW.findall('class="breadcrumb"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if YhzDEKvmbfX:
			KDCdHQmgxPE21tYz4VUowSv = YhzDEKvmbfX[0]
			laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if len(laAHpo1bzyM0q)>2:
				SOw5EUxC9k = laAHpo1bzyM0q[2]+'list'
				ctDj2OVRyaUPXCrITmJG(SOw5EUxC9k)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="actions(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	mmfaCLOWI5uxlGMUh = '/watch/' in KDCdHQmgxPE21tYz4VUowSv
	download = '/download/' in KDCdHQmgxPE21tYz4VUowSv
	if   mmfaCLOWI5uxlGMUh and not download: pvEZYbdxKhq1knCRgfJ5yOtojGQP,zaqgpH3uobjwEnM7mYy6Vdsr = laAHpo1bzyM0q[0],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	elif not mmfaCLOWI5uxlGMUh and download: pvEZYbdxKhq1knCRgfJ5yOtojGQP,zaqgpH3uobjwEnM7mYy6Vdsr = WnNGfosHr5STAq8j7miwyRZ6eOUbV,laAHpo1bzyM0q[0]
	elif mmfaCLOWI5uxlGMUh and download: pvEZYbdxKhq1knCRgfJ5yOtojGQP,zaqgpH3uobjwEnM7mYy6Vdsr = laAHpo1bzyM0q[0],laAHpo1bzyM0q[1]
	else: pvEZYbdxKhq1knCRgfJ5yOtojGQP,zaqgpH3uobjwEnM7mYy6Vdsr = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	M0MFkiKqJDv1aZ4NA396u = []
	if mmfaCLOWI5uxlGMUh:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pvEZYbdxKhq1knCRgfJ5yOtojGQP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-PLAY-2nd')
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('let servers(.*?)player',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
		if ZAIyluJa1EWhdB7OHV5CRGSrk:
			s5ocIDd4WKuPrV = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
			YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('"name":"(.*?)".*?"url":"(.*?)"',s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
			for title,SOw5EUxC9k in YacIZtAGdEPsFhSe:
				SOw5EUxC9k = SOw5EUxC9k.replace('\\/','/')
				SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if download:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',zaqgpH3uobjwEnM7mYy6Vdsr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-PLAY-3rd')
		hFYoSTas7WOVnwN = WadGEeh1MBIXkpfP38qAv7ryslY.content
		ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"servers"(.*?)info-container',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if ZAIyluJa1EWhdB7OHV5CRGSrk:
			s5ocIDd4WKuPrV = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
			YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title,DIBw28Qfje76bTMzVNYhxrgWmO in YacIZtAGdEPsFhSe:
				SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'+'____'+DIBw28Qfje76bTMzVNYhxrgWmO
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not search: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/search?s='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return
def J87GLvYrDtMFUo9R6OuEyhi1zC3(url):
	url = url.split('/smartemadfilter?')[0]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ZudC8bDqo4mM5c7GfP96Qy2F = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('adv-filter(.*?)shows-container',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		aI9U7rFE8uHNwOTiv0MP,NThwsPqGdZ72XFraUBLovl3,UOqp25uxcISGBPlAfbtzCNWXY4nvK = zip(*ZudC8bDqo4mM5c7GfP96Qy2F)
		ZudC8bDqo4mM5c7GfP96Qy2F = zip(NThwsPqGdZ72XFraUBLovl3,aI9U7rFE8uHNwOTiv0MP,UOqp25uxcISGBPlAfbtzCNWXY4nvK)
	return ZudC8bDqo4mM5c7GfP96Qy2F
def sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv):
	items = p7dwlH1PRStBgyMUW.findall('value="(.*?)".*?>\s*(.*?)\s*<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	return items
def Vk1IWKf6aJw72qNi8g3v4(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	q16smZkWvE = url.split('/smartemadfilter?')[0]
	HM25TctPpBqSeNzx3fm714 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	url = url.replace(q16smZkWvE,HM25TctPpBqSeNzx3fm714)
	url = url.replace('/smartemadfilter?','/?')
	return url
zUCAMxOIEi = ['quality','year','genre','category']
wZHWiC8sRk0G = ['category','genre','year']
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='DEFINED_FILTER':
		if wZHWiC8sRk0G[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = wZHWiC8sRk0G[0]
		for JrM1DoSuQ5n8 in range(len(wZHWiC8sRk0G[0:-1])):
			if wZHWiC8sRk0G[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = wZHWiC8sRk0G[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		vcQbFfCk6T1 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
	elif type=='FULL_FILTER':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'modified_filters')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'/smartemadfilter?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = Vk1IWKf6aJw72qNi8g3v4(vcQbFfCk6T1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها ',QQTfhlZEDnu4wVcOeHGNyCBo5t2,111)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',QQTfhlZEDnu4wVcOeHGNyCBo5t2,111)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ZudC8bDqo4mM5c7GfP96Qy2F = J87GLvYrDtMFUo9R6OuEyhi1zC3(url)
	dict = {}
	for name,LgJITEZU95fS2oi8K,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		name = name.replace('كل ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		items = sMW56Ilyd1Tj8wBLquzOEZ4Y(KDCdHQmgxPE21tYz4VUowSv)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='DEFINED_FILTER':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<2:
				if LgJITEZU95fS2oi8K==wZHWiC8sRk0G[-1]:
					QQTfhlZEDnu4wVcOeHGNyCBo5t2 = Vk1IWKf6aJw72qNi8g3v4(vcQbFfCk6T1)
					ctDj2OVRyaUPXCrITmJG(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'DEFINED_FILTER___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				if LgJITEZU95fS2oi8K==wZHWiC8sRk0G[-1]:
					QQTfhlZEDnu4wVcOeHGNyCBo5t2 = Vk1IWKf6aJw72qNi8g3v4(vcQbFfCk6T1)
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',QQTfhlZEDnu4wVcOeHGNyCBo5t2,111)
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,115,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='FULL_FILTER':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع :'+name,vcQbFfCk6T1,114,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if value=='196533': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'أفلام نيتفلكس'
			elif value=='196531': f4qbArVHeaCIiY5nzUR68dFBjsZ9 = 'مسلسلات نيتفلكس'
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' :'+name
			if type=='FULL_FILTER': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,114,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='DEFINED_FILTER' and wZHWiC8sRk0G[-2]+'=' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'modified_filters')
				vcQbFfCk6T1 = url+'/smartemadfilter?'+CdZwuO45sE7UvlbM
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = Vk1IWKf6aJw72qNi8g3v4(vcQbFfCk6T1)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,111)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,115,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.replace('=&','=0&')
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for key in zUCAMxOIEi:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if '%' not in value: value = ZisgmEGCOJxVI9DcetNBPo6(value)
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	CZewXSEQ3q = CZewXSEQ3q.replace('=0','=')
	return CZewXSEQ3q