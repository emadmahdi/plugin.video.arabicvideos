# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'CIMALIGHT'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_CML_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['قنوات فضائية']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==470: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==471: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==472: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==473: APpdhB1Fk58MmJH7CjVntowyaY = WJhTg9iDoQwPK(url,text)
	elif mode==474: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==479: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,479,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"content"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		title = title.replace(tTChquY7XSRg4e,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		SOw5EUxC9k = SOw5EUxC9k.replace('cat=online-movies1','cat=online-movies')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,474)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('/category.php">(.*?)"navslide-divider"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("'dropdown-menu'(.*?)</ul>",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,474)
	return
def uJlhLk2Tbcd(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if 'topvideos.php' in url: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)id="pm-grid"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if 'topvideos.php' in SOw5EUxC9k:
				if 'topvideos.php?c=english-movies' in SOw5EUxC9k: continue
				if 'topvideos.php?c=online-movies1' in SOw5EUxC9k: continue
				if 'topvideos.php?c=misc' in SOw5EUxC9k: continue
				if 'topvideos.php?c=tv-channel' in SOw5EUxC9k: continue
				if 'منذ البداية' in title and 'do=rating' not in SOw5EUxC9k: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,471)
	else: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = []
	if dlPQGb0aC5xmfFwy9ievKTqX=='featured_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"container-fluid"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		laAHpo1bzyM0q,trNPCKLEgm,RmtMQEgLejoO9 = zip(*items)
		items = zip(RmtMQEgLejoO9,laAHpo1bzyM0q,trNPCKLEgm)
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('المسلسلات المميزة(.*?)<style>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		laAHpo1bzyM0q,trNPCKLEgm,RmtMQEgLejoO9 = zip(*items)
		items = zip(RmtMQEgLejoO9,laAHpo1bzyM0q,trNPCKLEgm)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(data-echo=".*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"BlocksList"(.*?)"titleSectionCon"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="pm-grid"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="pm-related"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pm-ul-browse-videos(.*?)clearfix',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: return
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if not items: items = p7dwlH1PRStBgyMUW.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		title = title.replace('ماي سيما',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('مشاهدة',WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
		if 'http' not in J4tO21KYAVdSr67W5NmiD0XhRP: J4tO21KYAVdSr67W5NmiD0XhRP = VVDAncSMUjeu8Ii+'/'+J4tO21KYAVdSr67W5NmiD0XhRP.strip('/')
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة) \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if any(value in title for value in gbtIyQYJ854dkEhXfaev):
			title = '_MOD_'+title
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,472,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and 'حلقة' in title:
			title = '_MOD_'+er96jwp52cbvaV48mtylEYSRz[0][0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,473,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif '/movseries/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,471,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,473,J4tO21KYAVdSr67W5NmiD0XhRP)
	if dlPQGb0aC5xmfFwy9ievKTqX not in ['featured_movies','featured_series']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=='#': continue
				SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,471)
		uDi9v6xMaTs1SwcAl8PRGqCL = p7dwlH1PRStBgyMUW.findall('showmore" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if uDi9v6xMaTs1SwcAl8PRGqCL:
			SOw5EUxC9k = uDi9v6xMaTs1SwcAl8PRGqCL[0]
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مشاهدة المزيد',SOw5EUxC9k,471)
	return
def WJhTg9iDoQwPK(url,LW28MawRZDVkYCSjX):
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-EPISODES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"SeasonsBox"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	items = []
	if gg4PIzkHEpv and not LW28MawRZDVkYCSjX:
		J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"series-header".*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0] if J4tO21KYAVdSr67W5NmiD0XhRP else WnNGfosHr5STAq8j7miwyRZ6eOUbV
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		items = p7dwlH1PRStBgyMUW.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if len(items)==1: LW28MawRZDVkYCSjX = items[0][0]
		elif len(items)>1:
			for LW28MawRZDVkYCSjX,title in items: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,473,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,LW28MawRZDVkYCSjX)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('id="'+LW28MawRZDVkYCSjX+'"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk and len(items)<2:
		J4tO21KYAVdSr67W5NmiD0XhRP = p7dwlH1PRStBgyMUW.findall('"series-header".*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP[0] if J4tO21KYAVdSr67W5NmiD0XhRP else WnNGfosHr5STAq8j7miwyRZ6eOUbV
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,title in items:
				title = title.replace('ماي سيما',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('مسلسل',WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,472,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,472,J4tO21KYAVdSr67W5NmiD0XhRP)
	if 'id="pm-related"' in piN9Qlah4S:
		if items: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مواضيع ذات صلة',url,471)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<div itemprop="description">(.*?)href=',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('<p>(.*?)</p>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe,True): return
	vcQbFfCk6T1 = url.replace('/watch.php','/play.php')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-PLAY-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	DHWTR8seEGb = []
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('"embedURL" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[0]
		if SOw5EUxC9k and SOw5EUxC9k not in DHWTR8seEGb:
			DHWTR8seEGb.append(SOw5EUxC9k)
			SOw5EUxC9k = SOw5EUxC9k+'?named=__embed'
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	items = p7dwlH1PRStBgyMUW.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if SOw5EUxC9k not in DHWTR8seEGb:
			DHWTR8seEGb.append(SOw5EUxC9k)
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	vcQbFfCk6T1 = url.replace('/watch.php','/downloads.php')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'CIMALIGHT-PLAY-3rd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"downloadlist"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<strong>(.*?)</strong>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if SOw5EUxC9k not in DHWTR8seEGb:
				DHWTR8seEGb.append(SOw5EUxC9k)
				SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(pcE6DxaoHBm41WKXjwnk,'url')
	url = VVpQfHc7IZamxweON3WXKU6Fg+'/search.php?keywords='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return