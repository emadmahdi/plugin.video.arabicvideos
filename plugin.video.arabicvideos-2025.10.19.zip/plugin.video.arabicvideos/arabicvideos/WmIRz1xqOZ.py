﻿# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,P3PfXRDCpIBa1i4WeQ):
	if P3PfXRDCpIBa1i4WeQ==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	if HOkAWvmZSP5c2t9Dq4NgELyps==1:
		jbHBapXvlU1h3Sq89dMT = Zilvh2WQyb5.getCurrentWindowDialogId()
		UUsWMSLcOtwiHZX8nbmrPh = Zilvh2WQyb5.Window(jbHBapXvlU1h3Sq89dMT)
		P3PfXRDCpIBa1i4WeQ = P74g5BI92vDdJEQN(P3PfXRDCpIBa1i4WeQ)
		UUsWMSLcOtwiHZX8nbmrPh.getControl(311).setLabel(P3PfXRDCpIBa1i4WeQ)
	if HOkAWvmZSP5c2t9Dq4NgELyps==0:
		G3Xh0YWACHFuvQLx5sVEfPjzq7='X'
		if rJ2oTLqabRtA: iDAkwIpBuntSORTQ = isinstance(P3PfXRDCpIBa1i4WeQ,str)
		else: iDAkwIpBuntSORTQ = isinstance(P3PfXRDCpIBa1i4WeQ,unicode)
		if iDAkwIpBuntSORTQ==True: G3Xh0YWACHFuvQLx5sVEfPjzq7='U'
		ccFGiZLbOVuQYgzRMsH0E=str(type(P3PfXRDCpIBa1i4WeQ))+kcXMWrwiLDKeBHRsJ+P3PfXRDCpIBa1i4WeQ+kcXMWrwiLDKeBHRsJ+G3Xh0YWACHFuvQLx5sVEfPjzq7+kcXMWrwiLDKeBHRsJ
		for JrM1DoSuQ5n8 in range(0,len(P3PfXRDCpIBa1i4WeQ),1):
			ccFGiZLbOVuQYgzRMsH0E += hex(ord(P3PfXRDCpIBa1i4WeQ[JrM1DoSuQ5n8])).replace('0x',WnNGfosHr5STAq8j7miwyRZ6eOUbV)+kcXMWrwiLDKeBHRsJ
		P3PfXRDCpIBa1i4WeQ = P74g5BI92vDdJEQN(P3PfXRDCpIBa1i4WeQ)
		G3Xh0YWACHFuvQLx5sVEfPjzq7='X'
		if rJ2oTLqabRtA: iDAkwIpBuntSORTQ = isinstance(P3PfXRDCpIBa1i4WeQ, str)
		else: iDAkwIpBuntSORTQ = isinstance(P3PfXRDCpIBa1i4WeQ, unicode)
		if iDAkwIpBuntSORTQ==True: G3Xh0YWACHFuvQLx5sVEfPjzq7='U'
		qe0wDlQajN2XOCgx8B5hS=str(type(P3PfXRDCpIBa1i4WeQ))+kcXMWrwiLDKeBHRsJ+P3PfXRDCpIBa1i4WeQ+kcXMWrwiLDKeBHRsJ+G3Xh0YWACHFuvQLx5sVEfPjzq7+kcXMWrwiLDKeBHRsJ
		for JrM1DoSuQ5n8 in range(0,len(P3PfXRDCpIBa1i4WeQ),1):
			qe0wDlQajN2XOCgx8B5hS += hex(ord(P3PfXRDCpIBa1i4WeQ[JrM1DoSuQ5n8])).replace('0x',WnNGfosHr5STAq8j7miwyRZ6eOUbV)+kcXMWrwiLDKeBHRsJ
	return