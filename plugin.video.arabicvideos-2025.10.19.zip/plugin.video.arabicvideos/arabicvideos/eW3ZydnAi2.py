# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ALFATIMI'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_FTM_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
lPN1oLKSjtQyq4vaHp = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
ppSCmvqBeWo = ['3030','628']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==60: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==61: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==62: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==63: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==64: APpdhB1Fk58MmJH7CjVntowyaY = ftEDlQZbFW3cyi(text)
	elif mode==69: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,69,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'ما يتم مشاهدته الان',pcE6DxaoHBm41WKXjwnk,64,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'recent_viewed_vids')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الاكثر مشاهدة',pcE6DxaoHBm41WKXjwnk,64,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'most_viewed_vids')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'اضيفت مؤخرا',pcE6DxaoHBm41WKXjwnk,64,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'recently_added_vids')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'فيديو عشوائي',pcE6DxaoHBm41WKXjwnk,64,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'random_vids')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'افلام ومسلسلات',pcE6DxaoHBm41WKXjwnk,61,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'-1')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'البرامج الدينية',pcE6DxaoHBm41WKXjwnk,61,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'-2')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'English Videos',pcE6DxaoHBm41WKXjwnk,61,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'-3')
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV
def ctDj2OVRyaUPXCrITmJG(url,eukVjoW67vBiySNXrplDKIZLHU):
	fPn1m2pDOieCd = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if eukVjoW67vBiySNXrplDKIZLHU not in ['-1','-2','-3']: fPn1m2pDOieCd = '?cat='+eukVjoW67vBiySNXrplDKIZLHU
	vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+'/menu_level.php'+fPn1m2pDOieCd
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALFATIMI-TITLES-1st')
	items = p7dwlH1PRStBgyMUW.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	YM4otjLXbQZBF1zld87,QyG6a4ESNfC3RenMlD1Ttq8 = False,False
	for SOw5EUxC9k,title,count in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
		fPn1m2pDOieCd = p7dwlH1PRStBgyMUW.findall('cat=(.*?)&',SOw5EUxC9k,p7dwlH1PRStBgyMUW.DOTALL)[0]
		if eukVjoW67vBiySNXrplDKIZLHU==fPn1m2pDOieCd: YM4otjLXbQZBF1zld87 = True
		elif YM4otjLXbQZBF1zld87 	or (eukVjoW67vBiySNXrplDKIZLHU=='-1' and fPn1m2pDOieCd in lPN1oLKSjtQyq4vaHp)  						or (eukVjoW67vBiySNXrplDKIZLHU=='-2' and fPn1m2pDOieCd not in ppSCmvqBeWo and fPn1m2pDOieCd not in lPN1oLKSjtQyq4vaHp)  						or (eukVjoW67vBiySNXrplDKIZLHU=='-3' and fPn1m2pDOieCd in ppSCmvqBeWo):
							if count=='1': octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,63)
							else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,61,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fPn1m2pDOieCd)
							QyG6a4ESNfC3RenMlD1Ttq8 = True
	if not QyG6a4ESNfC3RenMlD1Ttq8: d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,True,'ALFATIMI-EPISODES-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pagination(.*?)id="footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	SOw5EUxC9k = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for J4tO21KYAVdSr67W5NmiD0XhRP,title,SOw5EUxC9k in items:
		title = title.replace('Add',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('to Quicklist',WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,63,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('(.*?)div',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv=cKUQVwTMe9tZSY[0]
	KDCdHQmgxPE21tYz4VUowSv=p7dwlH1PRStBgyMUW.findall('pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	items=p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	vcQbFfCk6T1 = url.split('?')[0]
	for SOw5EUxC9k,c6sSHKew8MFqkh7fDuAC24aBjnRXGp in items:
		SOw5EUxC9k = vcQbFfCk6T1 + SOw5EUxC9k
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(c6sSHKew8MFqkh7fDuAC24aBjnRXGp)
		title = 'صفحة ' + title
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,62)
	return SOw5EUxC9k
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	if 'videos.php' in url: url = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,True,'ALFATIMI-PLAY-1st')
	items = p7dwlH1PRStBgyMUW.findall('playlistfile:"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	YsRk6pAS7rdcn(url,NTWE764hmOgUtScp2e8r,'video')
	return
def ftEDlQZbFW3cyi(eukVjoW67vBiySNXrplDKIZLHU):
	rLqYZOtwMfBVs4k1TpE3X9aDy = { 'mode' : eukVjoW67vBiySNXrplDKIZLHU }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = kkymMOX7TcjRVpY2K(rLqYZOtwMfBVs4k1TpE3X9aDy)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,63,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk + '/search_result.php?query=' + DqbrOGw4giHUvfuFtRXQ5lA0yN
	d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	return