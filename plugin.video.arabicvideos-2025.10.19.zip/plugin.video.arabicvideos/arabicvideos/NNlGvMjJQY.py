# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'VIDEONSAEM'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_VNS_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','Show more','قصة عشق','عروض المصارعة الحرة مترجم']
headers = {'Referer':pcE6DxaoHBm41WKXjwnk}
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==1030: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==1031: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==1032: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==1033: APpdhB1Fk58MmJH7CjVntowyaY = WJhTg9iDoQwPK(url,text)
	elif mode==1034: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==1039: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,1039,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''["']navslide-wrap["'](.*?)</ul>''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1034)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('/category.php">(.*?)"navslide-divider"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''["']dropdown-menu["'](.*?)</ul>''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for s5ocIDd4WKuPrV in cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace(s5ocIDd4WKuPrV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		if not title: continue
		if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1034)
	return
def uJlhLk2Tbcd(url):
	ddOhWH5Aj8lt0FZLxVG,YacIZtAGdEPsFhSe = [],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-SUBMENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	gg4PIzkHEpv = p7dwlH1PRStBgyMUW.findall('"caret"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if gg4PIzkHEpv and '.php' in str(gg4PIzkHEpv):
		KDCdHQmgxPE21tYz4VUowSv = gg4PIzkHEpv[0]
		KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('"presentation"','</ul>')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = [(WnNGfosHr5STAq8j7miwyRZ6eOUbV,KDCdHQmgxPE21tYz4VUowSv)]
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' فرز أو فلتر أو ترتيب '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		for PiS4p2jAQN,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			ddOhWH5Aj8lt0FZLxVG = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if PiS4p2jAQN: PiS4p2jAQN = PiS4p2jAQN+': '
			for SOw5EUxC9k,title in ddOhWH5Aj8lt0FZLxVG:
				title = PiS4p2jAQN+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1031)
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('"pm-category-subcats"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if ZAIyluJa1EWhdB7OHV5CRGSrk:
		KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if 1 or len(YacIZtAGdEPsFhSe)<30:
			if ddOhWH5Aj8lt0FZLxVG: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
			for SOw5EUxC9k,title in YacIZtAGdEPsFhSe:
				if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1031)
	if not gg4PIzkHEpv and not ZAIyluJa1EWhdB7OHV5CRGSrk: ctDj2OVRyaUPXCrITmJG(url)
	return
def ctDj2OVRyaUPXCrITmJG(url,dlPQGb0aC5xmfFwy9ievKTqX=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		W67hPCcaOek094 = headers.copy()
		W67hPCcaOek094['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',url,data,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-TITLES-1st')
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-TITLES-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	KDCdHQmgxPE21tYz4VUowSv,items = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	if dlPQGb0aC5xmfFwy9ievKTqX=='ajax-search':
		KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
		YacIZtAGdEPsFhSe = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in YacIZtAGdEPsFhSe: items.append((WnNGfosHr5STAq8j7miwyRZ6eOUbV,SOw5EUxC9k,title))
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-carousel_featured"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='new_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"row pm-ul-browse-videos(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if len(cKUQVwTMe9tZSY)>1: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[1]
	elif dlPQGb0aC5xmfFwy9ievKTqX=='featured_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pm-grid"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	if KDCdHQmgxPE21tYz4VUowSv and not items: items = p7dwlH1PRStBgyMUW.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items: return
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in items:
		J4tO21KYAVdSr67W5NmiD0XhRP += '|Referer='+pcE6DxaoHBm41WKXjwnk
		if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if dlPQGb0aC5xmfFwy9ievKTqX=='episodes' or any(value in title for value in gbtIyQYJ854dkEhXfaev):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1032,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif dlPQGb0aC5xmfFwy9ievKTqX=='new_episodes':
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1032,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz:
			title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1033,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,1033,J4tO21KYAVdSr67W5NmiD0XhRP)
	if 1:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=='#': continue
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+'/'+SOw5EUxC9k.strip('/')
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,1031,'','',dlPQGb0aC5xmfFwy9ievKTqX)
	return
def WJhTg9iDoQwPK(url,LW28MawRZDVkYCSjX):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-EPISODES_SEASONS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="eplist"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		cTmHXhoJ60 = p7dwlH1PRStBgyMUW.findall('href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in cTmHXhoJ60:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,872)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<dt>(.*?)<dt>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if SOw5EUxC9k:
				ctDj2OVRyaUPXCrITmJG(SOw5EUxC9k[-1],'episodes')
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN,kKibU78Vp1CHjft3I = [],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'VIDEONSAEM-PLAY-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if 'hash=' in piN9Qlah4S:
		F7Yg3LliEBGZ6rVyozbS = p7dwlH1PRStBgyMUW.findall('hash=(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		F7Yg3LliEBGZ6rVyozbS = list(set(F7Yg3LliEBGZ6rVyozbS))
		for dHqBsvSieRxmbAPXVJ0o in F7Yg3LliEBGZ6rVyozbS:
			ffBUscdIljgLyknWCwSDOhq = []
			ipdI4Kw1lMauxrtYoh = dHqBsvSieRxmbAPXVJ0o.split('__')
			for iZrspzKymR7cBSxUV6XJtn in ipdI4Kw1lMauxrtYoh:
				try:
					iZrspzKymR7cBSxUV6XJtn = uvGCPpFwVmTQ36.b64decode(iZrspzKymR7cBSxUV6XJtn+'=')
					if rJ2oTLqabRtA: iZrspzKymR7cBSxUV6XJtn = iZrspzKymR7cBSxUV6XJtn.decode(e87cIA5vwOQLDEP1)
					ffBUscdIljgLyknWCwSDOhq.append(iZrspzKymR7cBSxUV6XJtn)
				except: pass
			laAHpo1bzyM0q = '>'.join(ffBUscdIljgLyknWCwSDOhq)
			laAHpo1bzyM0q = laAHpo1bzyM0q.splitlines()
			for SOw5EUxC9k in laAHpo1bzyM0q:
				if ' => ' in SOw5EUxC9k:
					title,SOw5EUxC9k = SOw5EUxC9k.split(' => ')
					SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
					wxT9bCdumN.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/search.php?keywords='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return