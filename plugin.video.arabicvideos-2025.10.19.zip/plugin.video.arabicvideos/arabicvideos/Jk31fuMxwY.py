# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
uTaiRMI8eYmN(IMjqygdfYSKpHlWu5Aa(u"ࠨࡖࡈࡗ࡙࠭ኵ"),tzZ6PhyDOUnwLM3pdK(u"ࠩࡗࡉࡘ࡚ࠧ኶"))
pp3sDoXdkc9V = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡼ࠴࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸ࡭࡯࡮࡬ࡤࡵࡳࡦࡪࡢࡢࡰࡧ࠲ࡨࡵ࡭࠰࠳࠳ࡑࡇ࠴ࡺࡪࡲࠪ኷")
pp3sDoXdkc9V = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶࡥࡦࡦࡷࡩࡸࡺ࠮ࡧࡶࡳ࠲ࡴࡺࡥ࡯ࡧࡷ࠲࡬ࡸ࠯ࡧ࡫࡯ࡩࡸ࠵ࡴࡦࡵࡷ࠵࠵࠶࡫࠯ࡦࡥࠫኸ")
zz3FACPKTpqWhEYsf1o9v(pp3sDoXdkc9V,{},r0D4C3z7Onqpa)
uuSU5Awl8FNrzkXHdQDiCWq3 = gPE1XB87fQl(u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜โฯุ࠲ࡲࡶ࠳ࠨኹ")
uuSU5Awl8FNrzkXHdQDiCWq3 = YYQS36fyPvtuzcEmRL(u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡨ࡬ࡰࡪࡥ࠴࠹࠵࠷ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫኺ")