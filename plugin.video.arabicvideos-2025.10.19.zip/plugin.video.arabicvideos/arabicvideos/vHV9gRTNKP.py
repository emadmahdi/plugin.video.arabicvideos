# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'ALARAB'
headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_KLA_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==10: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==11: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==12: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==13: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==14: APpdhB1Fk58MmJH7CjVntowyaY = B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT()
	elif mode==15: APpdhB1Fk58MmJH7CjVntowyaY = kCYRZ7nbpUOy86me4IFwWHNr0()
	elif mode==16: APpdhB1Fk58MmJH7CjVntowyaY = y7AsSMGt3Kk4lVOzJDpWRv()
	elif mode==19: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,19,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'آخر الإضافات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,14)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان',WnNGfosHr5STAq8j7miwyRZ6eOUbV,15)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ALARAB-MENU-1st')
	cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('id="nav-slider"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	UyJ7rmBcvtgQFCzn9 = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',UyJ7rmBcvtgQFCzn9,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="navbar"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	s5ocIDd4WKuPrV = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',s5ocIDd4WKuPrV,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,11)
	return piN9Qlah4S
def kCYRZ7nbpUOy86me4IFwWHNr0():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'جميع المسلسلات العربية',pcE6DxaoHBm41WKXjwnk+'/view-8/مسلسلات-عربية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات السنة الأخيرة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,16)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان الأخيرة 1',pcE6DxaoHBm41WKXjwnk+'/view-8/مسلسلات-رمضان-2022',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان الأخيرة 2',pcE6DxaoHBm41WKXjwnk+'/view-8/مسلسلات-رمضان-2023',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2023',pcE6DxaoHBm41WKXjwnk+'/ramadan2023/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2022',pcE6DxaoHBm41WKXjwnk+'/ramadan2022/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2021',pcE6DxaoHBm41WKXjwnk+'/ramadan2021/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2020',pcE6DxaoHBm41WKXjwnk+'/ramadan2020/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2019',pcE6DxaoHBm41WKXjwnk+'/ramadan2019/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2018',pcE6DxaoHBm41WKXjwnk+'/ramadan2018/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2017',pcE6DxaoHBm41WKXjwnk+'/ramadan2017/مصرية',11)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات رمضان 2016',pcE6DxaoHBm41WKXjwnk+'/ramadan2016/مصرية',11)
	return
def B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT():
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'ALARAB-LATEST-1st')
	cKUQVwTMe9tZSY=p7dwlH1PRStBgyMUW.findall('heading-top(.*?)div class=',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]+cKUQVwTMe9tZSY[1]
	items=p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		url = pcE6DxaoHBm41WKXjwnk + SOw5EUxC9k
		if 'series' in url: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,11,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,12,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def ctDj2OVRyaUPXCrITmJG(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,True,'ALARAB-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('video-category(.*?)right_content',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY: return
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	QyG6a4ESNfC3RenMlD1Ttq8 = False
	items = p7dwlH1PRStBgyMUW.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H,XXH8bCAt1NG = [],[]
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		if title==WnNGfosHr5STAq8j7miwyRZ6eOUbV: title = SOw5EUxC9k.split('/')[-1].replace('-',kcXMWrwiLDKeBHRsJ)
		uOFd6U75e4ZnqADYk8j9 = p7dwlH1PRStBgyMUW.findall('(\d+)',title,p7dwlH1PRStBgyMUW.DOTALL)
		if uOFd6U75e4ZnqADYk8j9: uOFd6U75e4ZnqADYk8j9 = int(uOFd6U75e4ZnqADYk8j9[0])
		else: uOFd6U75e4ZnqADYk8j9 = 0
		XXH8bCAt1NG.append([J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9])
	XXH8bCAt1NG = sorted(XXH8bCAt1NG, reverse=True, key=lambda key: key[3])
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9 in XXH8bCAt1NG:
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk + SOw5EUxC9k
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('عالية على العرب',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('مشاهدة مباشرة',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('اون لاين',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('اونلاين',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('بجودة عالية',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('جودة عالية',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('بدون تحميل',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('على العرب',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.replace('مباشرة',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		title = '_MOD_'+title
		gPvxJw89S35R21zDIbpFYkq7A = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if er96jwp52cbvaV48mtylEYSRz: gPvxJw89S35R21zDIbpFYkq7A = er96jwp52cbvaV48mtylEYSRz[0]
		if gPvxJw89S35R21zDIbpFYkq7A not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
			cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(gPvxJw89S35R21zDIbpFYkq7A)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+gPvxJw89S35R21zDIbpFYkq7A,SOw5EUxC9k,13,J4tO21KYAVdSr67W5NmiD0XhRP)
				QyG6a4ESNfC3RenMlD1Ttq8 = True
			elif 'series' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,11,J4tO21KYAVdSr67W5NmiD0XhRP)
				QyG6a4ESNfC3RenMlD1Ttq8 = True
			else:
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,12,J4tO21KYAVdSr67W5NmiD0XhRP)
				QyG6a4ESNfC3RenMlD1Ttq8 = True
	if QyG6a4ESNfC3RenMlD1Ttq8:
		items = p7dwlH1PRStBgyMUW.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,TB3DI4JWr0NYmik1xO8Kc2 in items:
			url = pcE6DxaoHBm41WKXjwnk + SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+TB3DI4JWr0NYmik1xO8Kc2,url,11)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'ALARAB-EPISODES-1st')
	PfoN0jKtAm6RVJebuGT = p7dwlH1PRStBgyMUW.findall('href="(/series.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+PfoN0jKtAm6RVJebuGT[0]
	APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u = []
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(OQaHUGCW62hp8tFbgM,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'ALARAB-PLAY-1st')
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('class="resp-iframe" src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vcQbFfCk6T1:
		vcQbFfCk6T1 = vcQbFfCk6T1[0]
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('^(http.*?)(http.*?)$',vcQbFfCk6T1,p7dwlH1PRStBgyMUW.DOTALL)
		if laAHpo1bzyM0q:
			UUdGCM6DFuzKJ1eTkNhcR3jon = laAHpo1bzyM0q[0][0]
			XkDfgGjbuaLoh,v15W83SzmyNchroDVqiMBRIZaf79 = laAHpo1bzyM0q[0][1].rsplit('/',1)
			QQTfhlZEDnu4wVcOeHGNyCBo5t2 = XkDfgGjbuaLoh+'?named=__watch'
			M0MFkiKqJDv1aZ4NA396u.append(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
			Ak4FHQP7vfhd6bYU = UUdGCM6DFuzKJ1eTkNhcR3jon+v15W83SzmyNchroDVqiMBRIZaf79
		else:
			hFYoSTas7WOVnwN = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,False,'ALARAB-PLAY-2nd')
			vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('"src": "(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if vcQbFfCk6T1:
				vcQbFfCk6T1 = vcQbFfCk6T1[0]+'?named=__watch__m3u8'
				M0MFkiKqJDv1aZ4NA396u.append(vcQbFfCk6T1)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('searchBox(.*?)<style>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if vcQbFfCk6T1:
			vcQbFfCk6T1 = vcQbFfCk6T1[0]+'?named=__watch'
			M0MFkiKqJDv1aZ4NA396u.append(vcQbFfCk6T1)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def y7AsSMGt3Kk4lVOzJDpWRv():
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'ALARAB-RAMADAN-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="content_sec"(.*?)id="left_content"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	UucnleIAw4pWM1t = p7dwlH1PRStBgyMUW.findall('/ramadan([0-9]+)/',str(items),p7dwlH1PRStBgyMUW.DOTALL)
	UucnleIAw4pWM1t = UucnleIAw4pWM1t[0]
	for SOw5EUxC9k,title in items:
		url = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
		title = title.strip(kcXMWrwiLDKeBHRsJ)+kcXMWrwiLDKeBHRsJ+UucnleIAw4pWM1t
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,11)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk + "/q/" + DqbrOGw4giHUvfuFtRXQ5lA0yN
	APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	return