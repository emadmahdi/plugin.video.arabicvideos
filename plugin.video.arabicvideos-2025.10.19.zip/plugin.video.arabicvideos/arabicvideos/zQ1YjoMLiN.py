# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
TTOAERW9IMB045fQt7wnjrymKZGHN = 'FAVORITES'
def uWyz2Omi3rGH9vsfTDg(HOkAWvmZSP5c2t9Dq4NgELyps,TdtQ0hKl6vVADqw):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==270: ww9PixygdMfDQJt = Hkr4wlnZ5Iobuf0ASYx(TdtQ0hKl6vVADqw)
	else: ww9PixygdMfDQJt = False
	return ww9PixygdMfDQJt
def B5LHyWdY6Cu(EaOw4PxtyQpZXM3,TdtQ0hKl6vVADqw,NzFqgclp2H):
	if not EaOw4PxtyQpZXM3: return
	if   NzFqgclp2H=='UP1'	: huEopSJy83bq4ZWmzIgwl5A(TdtQ0hKl6vVADqw,True,wnaWTQM7VJPkZzO9eoSyFU4)
	elif NzFqgclp2H=='DOWN1'	: huEopSJy83bq4ZWmzIgwl5A(TdtQ0hKl6vVADqw,False,wnaWTQM7VJPkZzO9eoSyFU4)
	elif NzFqgclp2H=='UP4'	: huEopSJy83bq4ZWmzIgwl5A(TdtQ0hKl6vVADqw,True,yGLl1nSBrJPmi2adko9O)
	elif NzFqgclp2H=='DOWN4'	: huEopSJy83bq4ZWmzIgwl5A(TdtQ0hKl6vVADqw,False,yGLl1nSBrJPmi2adko9O)
	elif NzFqgclp2H=='ADD1'	: RfTn68keYaUrvQCoq3PdG5w7jpIEW(TdtQ0hKl6vVADqw)
	elif NzFqgclp2H=='REMOVE1': H5CpZo43iEQ(TdtQ0hKl6vVADqw)
	elif NzFqgclp2H=='DELETELIST': OwHlg2bWdR6hxDC7AGqvfZ(TdtQ0hKl6vVADqw)
	return
def Hkr4wlnZ5Iobuf0ASYx(TdtQ0hKl6vVADqw):
	aIKz6yLUPcwi0HYSqf4Xm = yyQrnbKfzwMi()
	if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
		try:
			ttdjqbc4Ap9whlWKCmyXF2 = aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]
			if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and TdtQ0hKl6vVADqw in ['5','11','12','13']:
				for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq in ttdjqbc4Ap9whlWKCmyXF2:
					if t0xkM74rgEAFIepSWXilNOGDn=='video':
						octplHnGwmE8bFqNdj7BiKvJ0VL('video',e6HEdvUcaq8Gx+'تشغيل من الأعلى إلى الأسفل'+YVr6St5P4xsFC0aARQGKfiegD,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3)
						octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
						break
			for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq in ttdjqbc4Ap9whlWKCmyXF2:
				octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq)
		except:
			aIKz6yLUPcwi0HYSqf4Xm = QSXjgqyaVxPL4(C6MhN2TeZ83GDFngway7EvBYom5i)
			ttdjqbc4Ap9whlWKCmyXF2 = aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]
			for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq in ttdjqbc4Ap9whlWKCmyXF2:
				octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq)
	return
def RfTn68keYaUrvQCoq3PdG5w7jpIEW(TdtQ0hKl6vVADqw):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	if TdtQ0hKl6vVADqw in ['5','11','12','13'] and t0xkM74rgEAFIepSWXilNOGDn!='video':
		BGQXvd2lsicjVTgnHYRo74qDI3z('','',Ew26Hg4SIj,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	Z2CEnfA3yd = t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rBSIjX6x2FVTgOeG4CREKfUq
	aIKz6yLUPcwi0HYSqf4Xm = yyQrnbKfzwMi()
	ruio9WFZTj4VSbvO = {}
	for iesxcZAyS7lP5BaMLpdkWhGRK8UbV in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
		if iesxcZAyS7lP5BaMLpdkWhGRK8UbV!=TdtQ0hKl6vVADqw: ruio9WFZTj4VSbvO[iesxcZAyS7lP5BaMLpdkWhGRK8UbV] = aIKz6yLUPcwi0HYSqf4Xm[iesxcZAyS7lP5BaMLpdkWhGRK8UbV]
		else:
			if fzu7Got0FgiyshTlJK and fzu7Got0FgiyshTlJK!='..':
				iVuGUJqyx9Y0CIDhfWr4vK3zbpgem = aIKz6yLUPcwi0HYSqf4Xm[iesxcZAyS7lP5BaMLpdkWhGRK8UbV]
				if Z2CEnfA3yd in iVuGUJqyx9Y0CIDhfWr4vK3zbpgem:
					llC7KenB9kXGA = iVuGUJqyx9Y0CIDhfWr4vK3zbpgem.index(Z2CEnfA3yd)
					del iVuGUJqyx9Y0CIDhfWr4vK3zbpgem[llC7KenB9kXGA]
				Jd2Fcp8eMODEGQzab = iVuGUJqyx9Y0CIDhfWr4vK3zbpgem+[Z2CEnfA3yd]
				ruio9WFZTj4VSbvO[iesxcZAyS7lP5BaMLpdkWhGRK8UbV] = Jd2Fcp8eMODEGQzab
			else: ruio9WFZTj4VSbvO[iesxcZAyS7lP5BaMLpdkWhGRK8UbV] = aIKz6yLUPcwi0HYSqf4Xm[iesxcZAyS7lP5BaMLpdkWhGRK8UbV]
	if TdtQ0hKl6vVADqw not in list(ruio9WFZTj4VSbvO.keys()): ruio9WFZTj4VSbvO[TdtQ0hKl6vVADqw] = [Z2CEnfA3yd]
	ucCWSAUikgM8Oo9Y5xZfr = str(ruio9WFZTj4VSbvO)
	if rJ2oTLqabRtA: ucCWSAUikgM8Oo9Y5xZfr = ucCWSAUikgM8Oo9Y5xZfr.encode(e87cIA5vwOQLDEP1)
	open(C6MhN2TeZ83GDFngway7EvBYom5i,'wb').write(ucCWSAUikgM8Oo9Y5xZfr)
	return
def H5CpZo43iEQ(TdtQ0hKl6vVADqw):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	Z2CEnfA3yd = t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rBSIjX6x2FVTgOeG4CREKfUq
	aIKz6yLUPcwi0HYSqf4Xm = yyQrnbKfzwMi()
	if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()) and Z2CEnfA3yd in aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]:
		aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw].remove(Z2CEnfA3yd)
		if len(aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw])==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: del aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]
		ucCWSAUikgM8Oo9Y5xZfr = str(aIKz6yLUPcwi0HYSqf4Xm)
		if rJ2oTLqabRtA: ucCWSAUikgM8Oo9Y5xZfr = ucCWSAUikgM8Oo9Y5xZfr.encode(e87cIA5vwOQLDEP1)
		open(C6MhN2TeZ83GDFngway7EvBYom5i,'wb').write(ucCWSAUikgM8Oo9Y5xZfr)
	return
def huEopSJy83bq4ZWmzIgwl5A(TdtQ0hKl6vVADqw,UUr61NFiO9MbyDqumHl,YY9ON8tMKyfsDdazvcrq):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	Z2CEnfA3yd = t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rBSIjX6x2FVTgOeG4CREKfUq
	aIKz6yLUPcwi0HYSqf4Xm = yyQrnbKfzwMi()
	if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
		iVuGUJqyx9Y0CIDhfWr4vK3zbpgem = aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]
		if Z2CEnfA3yd not in iVuGUJqyx9Y0CIDhfWr4vK3zbpgem: return
		xxOkanprGDJTz6stRS9Zq = len(iVuGUJqyx9Y0CIDhfWr4vK3zbpgem)
		for pMiDdTC8LUE2wIV in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,YY9ON8tMKyfsDdazvcrq):
			oX2m50VZMde4Avyki8wsx6u1QlYLqg = iVuGUJqyx9Y0CIDhfWr4vK3zbpgem.index(Z2CEnfA3yd)
			if UUr61NFiO9MbyDqumHl: fCW2tGeJKPIxQ = oX2m50VZMde4Avyki8wsx6u1QlYLqg-wnaWTQM7VJPkZzO9eoSyFU4
			else: fCW2tGeJKPIxQ = oX2m50VZMde4Avyki8wsx6u1QlYLqg+wnaWTQM7VJPkZzO9eoSyFU4
			if fCW2tGeJKPIxQ>=xxOkanprGDJTz6stRS9Zq: fCW2tGeJKPIxQ = fCW2tGeJKPIxQ-xxOkanprGDJTz6stRS9Zq
			if fCW2tGeJKPIxQ<j0jEZgiKdxFpMLHcU7kQr8v1lyX4: fCW2tGeJKPIxQ = fCW2tGeJKPIxQ+xxOkanprGDJTz6stRS9Zq
			iVuGUJqyx9Y0CIDhfWr4vK3zbpgem.insert(fCW2tGeJKPIxQ, iVuGUJqyx9Y0CIDhfWr4vK3zbpgem.pop(oX2m50VZMde4Avyki8wsx6u1QlYLqg))
		aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw] = iVuGUJqyx9Y0CIDhfWr4vK3zbpgem
		ucCWSAUikgM8Oo9Y5xZfr = str(aIKz6yLUPcwi0HYSqf4Xm)
		if rJ2oTLqabRtA: ucCWSAUikgM8Oo9Y5xZfr = ucCWSAUikgM8Oo9Y5xZfr.encode(e87cIA5vwOQLDEP1)
		open(C6MhN2TeZ83GDFngway7EvBYom5i,'wb').write(ucCWSAUikgM8Oo9Y5xZfr)
	return
def kkAlpsqd0LI2JSnrUN8(TdtQ0hKl6vVADqw):
	if TdtQ0hKl6vVADqw in ['1','2','3','4']: Rs9o8vhPjdzyQJVWuCgw7q4kEBeT2,CdEA0jVifk1enDX6U2s = 'مفضلة',TdtQ0hKl6vVADqw
	elif TdtQ0hKl6vVADqw in ['5']: Rs9o8vhPjdzyQJVWuCgw7q4kEBeT2,CdEA0jVifk1enDX6U2s = 'تشغيل','1'
	elif TdtQ0hKl6vVADqw in ['11']: Rs9o8vhPjdzyQJVWuCgw7q4kEBeT2,CdEA0jVifk1enDX6U2s = 'تشغيل','2'
	else: Rs9o8vhPjdzyQJVWuCgw7q4kEBeT2,CdEA0jVifk1enDX6U2s = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	yaPs1zS8F7ufhKgGnTJv9iwNMYL = Rs9o8vhPjdzyQJVWuCgw7q4kEBeT2+kcXMWrwiLDKeBHRsJ+CdEA0jVifk1enDX6U2s
	return yaPs1zS8F7ufhKgGnTJv9iwNMYL
def OwHlg2bWdR6hxDC7AGqvfZ(TdtQ0hKl6vVADqw):
	yaPs1zS8F7ufhKgGnTJv9iwNMYL = kkAlpsqd0LI2JSnrUN8(TdtQ0hKl6vVADqw)
	PJtTMSG4ahksq = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هل تريد فعلا مسح جميع محتويات قائمة '+yaPs1zS8F7ufhKgGnTJv9iwNMYL+' ؟!')
	if PJtTMSG4ahksq!=1: return
	aIKz6yLUPcwi0HYSqf4Xm = yyQrnbKfzwMi()
	if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
		del aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]
		ucCWSAUikgM8Oo9Y5xZfr = str(aIKz6yLUPcwi0HYSqf4Xm)
		if rJ2oTLqabRtA: ucCWSAUikgM8Oo9Y5xZfr = ucCWSAUikgM8Oo9Y5xZfr.encode(e87cIA5vwOQLDEP1)
		open(C6MhN2TeZ83GDFngway7EvBYom5i,'wb').write(ucCWSAUikgM8Oo9Y5xZfr)
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم مسح جميع محتويات قائمة '+yaPs1zS8F7ufhKgGnTJv9iwNMYL)
	return
def yyQrnbKfzwMi():
	aIKz6yLUPcwi0HYSqf4Xm = {}
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(C6MhN2TeZ83GDFngway7EvBYom5i):
		jUg7rqHiZFEksG3yB1dRMDzano = open(C6MhN2TeZ83GDFngway7EvBYom5i,'rb').read()
		if rJ2oTLqabRtA: jUg7rqHiZFEksG3yB1dRMDzano = jUg7rqHiZFEksG3yB1dRMDzano.decode(e87cIA5vwOQLDEP1)
		aIKz6yLUPcwi0HYSqf4Xm = IXZpzK7ShaRsAN('dict',jUg7rqHiZFEksG3yB1dRMDzano)
	return aIKz6yLUPcwi0HYSqf4Xm
def Ut60yQZszi2cVO3geI4XdLjKRE7bG(aIKz6yLUPcwi0HYSqf4Xm,Z2CEnfA3yd,CvciS6q0ZnFb1lJNPahYB):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = Z2CEnfA3yd
	if not HOkAWvmZSP5c2t9Dq4NgELyps: t0xkM74rgEAFIepSWXilNOGDn,HOkAWvmZSP5c2t9Dq4NgELyps = 'folder','260'
	eRPXNZosDvHq90dk7i,TdtQ0hKl6vVADqw = [],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if 'context=' in oobgjl3xWaBeRZF8wdzKYAvtus:
		zP9lmkf3IU1w2vJpE46eFLyBVN = p7dwlH1PRStBgyMUW.findall('context=(\d+)',oobgjl3xWaBeRZF8wdzKYAvtus,p7dwlH1PRStBgyMUW.DOTALL)
		if zP9lmkf3IU1w2vJpE46eFLyBVN: TdtQ0hKl6vVADqw = str(zP9lmkf3IU1w2vJpE46eFLyBVN[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
	if HOkAWvmZSP5c2t9Dq4NgELyps=='270':
		TdtQ0hKl6vVADqw = EaOw4PxtyQpZXM3
		if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
			yaPs1zS8F7ufhKgGnTJv9iwNMYL = kkAlpsqd0LI2JSnrUN8(TdtQ0hKl6vVADqw)
			eRPXNZosDvHq90dk7i.append(('مسح قائمة '+yaPs1zS8F7ufhKgGnTJv9iwNMYL,'RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_DELETELIST'+')'))
	else:
		if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()):
			count = len(aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw])
			if count>wnaWTQM7VJPkZzO9eoSyFU4: eRPXNZosDvHq90dk7i.append(('تحريك 1 للأعلى','RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_UP1)'))
			if count>yGLl1nSBrJPmi2adko9O: eRPXNZosDvHq90dk7i.append(('تحريك 4 للأعلى','RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_UP4)'))
			if count>wnaWTQM7VJPkZzO9eoSyFU4: eRPXNZosDvHq90dk7i.append(('تحريك 1 للأسفل','RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_DOWN1)'))
			if count>yGLl1nSBrJPmi2adko9O: eRPXNZosDvHq90dk7i.append(('تحريك 4 للأسفل','RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_DOWN4)'))
		for TdtQ0hKl6vVADqw in ['1','2','3','4','5','11']:
			yaPs1zS8F7ufhKgGnTJv9iwNMYL = kkAlpsqd0LI2JSnrUN8(TdtQ0hKl6vVADqw)
			if TdtQ0hKl6vVADqw in list(aIKz6yLUPcwi0HYSqf4Xm.keys()) and Z2CEnfA3yd in aIKz6yLUPcwi0HYSqf4Xm[TdtQ0hKl6vVADqw]:
				eRPXNZosDvHq90dk7i.append(('مسح من '+yaPs1zS8F7ufhKgGnTJv9iwNMYL,'RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_REMOVE1)'))
			else: eRPXNZosDvHq90dk7i.append(('إضافة ل'+yaPs1zS8F7ufhKgGnTJv9iwNMYL,'RunPlugin('+CvciS6q0ZnFb1lJNPahYB+'&context='+TdtQ0hKl6vVADqw+'_ADD1)'))
	pF8vAGxnD9gCQO0sSe = []
	for g4E0KlXYBsZAfWH6n1aJmd,emWD67XZbMGdla8vNSVjOfUFQt in eRPXNZosDvHq90dk7i:
		g4E0KlXYBsZAfWH6n1aJmd = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+g4E0KlXYBsZAfWH6n1aJmd+YVr6St5P4xsFC0aARQGKfiegD
		pF8vAGxnD9gCQO0sSe.append((g4E0KlXYBsZAfWH6n1aJmd,emWD67XZbMGdla8vNSVjOfUFQt,))
	return pF8vAGxnD9gCQO0sSe