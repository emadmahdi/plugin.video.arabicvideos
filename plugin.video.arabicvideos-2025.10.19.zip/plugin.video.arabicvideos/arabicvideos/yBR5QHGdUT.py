# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from tBopO810Wx import *
class GkRq3JUxYKv9HXzidENsg0fn8I(NNSs1CeqntdLV8YD3):
	def __init__(EfRyYmGtnvCrDeI5iV4Hx9S3,*aargs,**kkwargs):
		EfRyYmGtnvCrDeI5iV4Hx9S3.choiceID = -wnaWTQM7VJPkZzO9eoSyFU4
	def onClick(EfRyYmGtnvCrDeI5iV4Hx9S3,BoPIhZC2n8KEH):
		if BoPIhZC2n8KEH>=A6iX18qgyOFlZxz7sc(u"࠺࠲࠴࠴ઝ"): EfRyYmGtnvCrDeI5iV4Hx9S3.choiceID = BoPIhZC2n8KEH-A6iX18qgyOFlZxz7sc(u"࠺࠲࠴࠴ઝ")
		EfRyYmGtnvCrDeI5iV4Hx9S3.qz15EUARLGH9IVxgiT()
	def mm25rYIeLFhxN0iCQ7zqtUASlT(EfRyYmGtnvCrDeI5iV4Hx9S3,*aargs):
		EfRyYmGtnvCrDeI5iV4Hx9S3.button0,EfRyYmGtnvCrDeI5iV4Hx9S3.button1,EfRyYmGtnvCrDeI5iV4Hx9S3.button2 = aargs[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],aargs[wnaWTQM7VJPkZzO9eoSyFU4],aargs[XURrDCfOS9Mbhpv2Pmjos56TeW]
		EfRyYmGtnvCrDeI5iV4Hx9S3.header,EfRyYmGtnvCrDeI5iV4Hx9S3.text = aargs[vXIdY7TwFKso40gVBq5],aargs[yGLl1nSBrJPmi2adko9O]
		EfRyYmGtnvCrDeI5iV4Hx9S3.profile,EfRyYmGtnvCrDeI5iV4Hx9S3.direction = aargs[wwWzyF4ZpSQXKOgk569(u"࠷ઞ")],aargs[YYQS36fyPvtuzcEmRL(u"࠹ટ")]
		EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout,EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout = aargs[YYQS36fyPvtuzcEmRL(u"࠼ડ")],aargs[mq5t9JXSdHT8yfDVF(u"࠼ઠ")]
		if EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout>j0jEZgiKdxFpMLHcU7kQr8v1lyX4 or EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout>mq5t9JXSdHT8yfDVF(u"࠶ઢ"): EfRyYmGtnvCrDeI5iV4Hx9S3.enable_progressbar = r0D4C3z7Onqpa
		else: EfRyYmGtnvCrDeI5iV4Hx9S3.enable_progressbar = KiryBCvngZzF85UN6xSDlOVweL4I9
		EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename = xx02M7uVUbkgIQpaA4fdYsGjhZNOJn.replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧਉ"),Z9FPQvwlbjLTh(u"ࠨࡡࠪਊ")+str(x54xSdnCFHZ8yliofzOBK.time())+beV5l2D8HznyJI0(u"ࠩࡢࠫ਋"))
		EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename = EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename.replace(oiWNFYzcIUeh(u"ࠪࡠࡡ࠭਌"),yobpaW7sBqtKRrv(u"ࠫࡡࡢ࡜࡝ࠩ਍")).replace(IMjqygdfYSKpHlWu5Aa(u"ࠬ࠵࠯ࠨ਎"),A41nqbj3wYt(u"࠭࠯࠰࠱࠲ࠫਏ"))
		EfRyYmGtnvCrDeI5iV4Hx9S3.image_height = XcIVdC7NZuatWvkKQhBw8F2LfUyAS6(EfRyYmGtnvCrDeI5iV4Hx9S3.button0,EfRyYmGtnvCrDeI5iV4Hx9S3.button1,EfRyYmGtnvCrDeI5iV4Hx9S3.button2,EfRyYmGtnvCrDeI5iV4Hx9S3.header,EfRyYmGtnvCrDeI5iV4Hx9S3.text,EfRyYmGtnvCrDeI5iV4Hx9S3.profile,EfRyYmGtnvCrDeI5iV4Hx9S3.direction,EfRyYmGtnvCrDeI5iV4Hx9S3.enable_progressbar,EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename)
		EfRyYmGtnvCrDeI5iV4Hx9S3.show()
		EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(iySORMYxWXszEH18(u"࠹࠱࠷࠳ણ")).setImage(EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename)
		EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠺࠲࠸࠴ત")).setHeight(EfRyYmGtnvCrDeI5iV4Hx9S3.image_height)
		if not EfRyYmGtnvCrDeI5iV4Hx9S3.button1 and EfRyYmGtnvCrDeI5iV4Hx9S3.button0 and EfRyYmGtnvCrDeI5iV4Hx9S3.button2: EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(tzZ6PhyDOUnwLM3pdK(u"࠼࠴࠶࠸દ")).setPosition(-eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠶࠷࠶ધ"),tzZ6PhyDOUnwLM3pdK(u"࠲થ"))
		return EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename,EfRyYmGtnvCrDeI5iV4Hx9S3.image_height
	def Y2bKunMi5pdA6mjI70vckfR(EfRyYmGtnvCrDeI5iV4Hx9S3):
		if EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout:
			EfRyYmGtnvCrDeI5iV4Hx9S3.th1 = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=EfRyYmGtnvCrDeI5iV4Hx9S3.EELIVCtmshfQXvux6Wz9AJYUbegNB)
			EfRyYmGtnvCrDeI5iV4Hx9S3.th1.start()
		else: EfRyYmGtnvCrDeI5iV4Hx9S3.nQYh3wMiayWLgT()
	def EELIVCtmshfQXvux6Wz9AJYUbegNB(EfRyYmGtnvCrDeI5iV4Hx9S3):
		EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(pp7FcjEe6g(u"࠾࠶࠲࠱ન")).setEnabled(r0D4C3z7Onqpa)
		for zuEo6GDeAR5Z in range(wnaWTQM7VJPkZzO9eoSyFU4,EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout+wnaWTQM7VJPkZzO9eoSyFU4):
			x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
			m8GpRysdh0YHwA41Tj9Lo7XeEJV2 = int(mq5t9JXSdHT8yfDVF(u"࠷࠰࠱઩")*zuEo6GDeAR5Z/EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout)
			EfRyYmGtnvCrDeI5iV4Hx9S3.CC7TwcGMUt9RpgWqeHoL(m8GpRysdh0YHwA41Tj9Lo7XeEJV2)
			if EfRyYmGtnvCrDeI5iV4Hx9S3.choiceID>bawK2j7T81Nrc4GWs05xzDg(u"࠰પ"): break
		EfRyYmGtnvCrDeI5iV4Hx9S3.nQYh3wMiayWLgT()
	def x2pztmLFB3OCb9kud0(EfRyYmGtnvCrDeI5iV4Hx9S3):
		if EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout:
			EfRyYmGtnvCrDeI5iV4Hx9S3.th2 = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=EfRyYmGtnvCrDeI5iV4Hx9S3.kou35PI9beErFOfmpSw7svNAt)
			EfRyYmGtnvCrDeI5iV4Hx9S3.th2.start()
		else: EfRyYmGtnvCrDeI5iV4Hx9S3.nQYh3wMiayWLgT()
	def kou35PI9beErFOfmpSw7svNAt(EfRyYmGtnvCrDeI5iV4Hx9S3):
		EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(rVy3Ops0mohYkT(u"࠺࠲࠵࠴ફ")).setEnabled(r0D4C3z7Onqpa)
		x54xSdnCFHZ8yliofzOBK.sleep(EfRyYmGtnvCrDeI5iV4Hx9S3.buttonstimeout)
		for zuEo6GDeAR5Z in range(EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout-wnaWTQM7VJPkZzO9eoSyFU4,-wnaWTQM7VJPkZzO9eoSyFU4,-wnaWTQM7VJPkZzO9eoSyFU4):
			x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
			m8GpRysdh0YHwA41Tj9Lo7XeEJV2 = int(CyHU86ZeYT5BWRcitSm2I(u"࠳࠳࠴બ")*zuEo6GDeAR5Z/EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout)
			EfRyYmGtnvCrDeI5iV4Hx9S3.CC7TwcGMUt9RpgWqeHoL(m8GpRysdh0YHwA41Tj9Lo7XeEJV2)
			if EfRyYmGtnvCrDeI5iV4Hx9S3.choiceID>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: break
		if EfRyYmGtnvCrDeI5iV4Hx9S3.closetimeout>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: EfRyYmGtnvCrDeI5iV4Hx9S3.choiceID = yobpaW7sBqtKRrv(u"࠴࠴ભ")
		EfRyYmGtnvCrDeI5iV4Hx9S3.qz15EUARLGH9IVxgiT()
	def CC7TwcGMUt9RpgWqeHoL(EfRyYmGtnvCrDeI5iV4Hx9S3,m8GpRysdh0YHwA41Tj9Lo7XeEJV2):
		EfRyYmGtnvCrDeI5iV4Hx9S3.precent = m8GpRysdh0YHwA41Tj9Lo7XeEJV2
		EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(IMjqygdfYSKpHlWu5Aa(u"࠽࠵࠸࠰મ")).setPercent(EfRyYmGtnvCrDeI5iV4Hx9S3.precent)
	def nQYh3wMiayWLgT(EfRyYmGtnvCrDeI5iV4Hx9S3):
		if EfRyYmGtnvCrDeI5iV4Hx9S3.button0: EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(GHg28TBchiyn6l(u"࠾࠶࠱࠱ય")).setEnabled(r0D4C3z7Onqpa)
		if EfRyYmGtnvCrDeI5iV4Hx9S3.button1: EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(yobpaW7sBqtKRrv(u"࠿࠰࠲࠳ર")).setEnabled(r0D4C3z7Onqpa)
		if EfRyYmGtnvCrDeI5iV4Hx9S3.button2: EfRyYmGtnvCrDeI5iV4Hx9S3.getControl(kdRO82AImh0LFw(u"࠹࠱࠳࠵઱")).setEnabled(r0D4C3z7Onqpa)
	def qz15EUARLGH9IVxgiT(EfRyYmGtnvCrDeI5iV4Hx9S3):
		EfRyYmGtnvCrDeI5iV4Hx9S3.close()
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(EfRyYmGtnvCrDeI5iV4Hx9S3.image_filename)
		except: pass
def BGQXvd2lsicjVTgnHYRo74qDI3z(*aargs,**kkwargs):
	if aargs:
		direction = aargs[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		MYPxvnhJ8sIiWw0f4t7LTX9GdaA = aargs[wnaWTQM7VJPkZzO9eoSyFU4]
		if not direction: direction = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡤࡧࡱࡸࡪࡸࠧਐ")
		if not MYPxvnhJ8sIiWw0f4t7LTX9GdaA: MYPxvnhJ8sIiWw0f4t7LTX9GdaA = YYQS36fyPvtuzcEmRL(u"ࠨษึฮ๊ืวาࠩ਑")
		fUQ2tkhneHwFLEC = aargs[XURrDCfOS9Mbhpv2Pmjos56TeW]
		HvzeZpTRrx9j1hMBV3 = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(aargs[eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠴લ"):])
	else: direction,MYPxvnhJ8sIiWw0f4t7LTX9GdaA,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠩࡒࡏࠬ਒"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	tFVmMznSUR3XupZBN9kxcO0EHv(direction,WnNGfosHr5STAq8j7miwyRZ6eOUbV,MYPxvnhJ8sIiWw0f4t7LTX9GdaA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,**kkwargs)
	return
def TPNsmjik1eh4Wc(*aargs,**kkwargs):
	direction = aargs[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	iH3BryxAGIjCp9VvcqeLs170Rf = aargs[wnaWTQM7VJPkZzO9eoSyFU4]
	WtUwV3nhQkPXaCmgKF = aargs[XURrDCfOS9Mbhpv2Pmjos56TeW]
	if WtUwV3nhQkPXaCmgKF or iH3BryxAGIjCp9VvcqeLs170Rf: MOIvQL4jxgnPEbD2ord = r0D4C3z7Onqpa
	else: MOIvQL4jxgnPEbD2ord = KiryBCvngZzF85UN6xSDlOVweL4I9
	fUQ2tkhneHwFLEC = aargs[vXIdY7TwFKso40gVBq5]
	HvzeZpTRrx9j1hMBV3 = aargs[yGLl1nSBrJPmi2adko9O]
	if not direction: direction = yobpaW7sBqtKRrv(u"ࠪࡧࡪࡴࡴࡦࡴࠪਓ")
	if not iH3BryxAGIjCp9VvcqeLs170Rf: iH3BryxAGIjCp9VvcqeLs170Rf = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"่๊ࠫวࠡࠢࡑࡳࠬਔ")
	if not WtUwV3nhQkPXaCmgKF: WtUwV3nhQkPXaCmgKF = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧਕ")
	if len(aargs)>=kdRO82AImh0LFw(u"࠹઴"): HvzeZpTRrx9j1hMBV3 += WBDnh75CaLEvkcN6p4ez2KXrV3M+aargs[beV5l2D8HznyJI0(u"࠷ળ")]
	if len(aargs)>=pp7FcjEe6g(u"࠻વ"): HvzeZpTRrx9j1hMBV3 += WBDnh75CaLEvkcN6p4ez2KXrV3M+aargs[CyHU86ZeYT5BWRcitSm2I(u"࠻શ")]
	tt2NkXu7HgTIAyj09OBlod3YDpz = tFVmMznSUR3XupZBN9kxcO0EHv(direction,iH3BryxAGIjCp9VvcqeLs170Rf,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WtUwV3nhQkPXaCmgKF,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,**kkwargs)
	if tt2NkXu7HgTIAyj09OBlod3YDpz==-YYQS36fyPvtuzcEmRL(u"࠷ષ") and MOIvQL4jxgnPEbD2ord: tt2NkXu7HgTIAyj09OBlod3YDpz = -wnaWTQM7VJPkZzO9eoSyFU4
	elif tt2NkXu7HgTIAyj09OBlod3YDpz==-wnaWTQM7VJPkZzO9eoSyFU4 and not MOIvQL4jxgnPEbD2ord: tt2NkXu7HgTIAyj09OBlod3YDpz = KiryBCvngZzF85UN6xSDlOVweL4I9
	elif tt2NkXu7HgTIAyj09OBlod3YDpz==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: tt2NkXu7HgTIAyj09OBlod3YDpz = KiryBCvngZzF85UN6xSDlOVweL4I9
	elif tt2NkXu7HgTIAyj09OBlod3YDpz==XURrDCfOS9Mbhpv2Pmjos56TeW: tt2NkXu7HgTIAyj09OBlod3YDpz = r0D4C3z7Onqpa
	return tt2NkXu7HgTIAyj09OBlod3YDpz
def A3DjqpQcnvi6O0oXxGTlz19ytdKu(*aargs,**kkwargs):
	return Zilvh2WQyb5.Dialog().select(*aargs,**kkwargs)
def uTaiRMI8eYmN(*aargs,**kkwargs):
	fUQ2tkhneHwFLEC = aargs[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	HvzeZpTRrx9j1hMBV3 = aargs[wnaWTQM7VJPkZzO9eoSyFU4]
	uAzZ6xk4T2EDho7iOn = kkwargs[tzZ6PhyDOUnwLM3pdK(u"࠭ࡴࡪ࡯ࡨࠫਖ")] if rVy3Ops0mohYkT(u"ࠧࡵ࡫ࡰࡩࠬਗ") in list(kkwargs.keys()) else tzZ6PhyDOUnwLM3pdK(u"࠱࠱࠲࠳સ")
	c7Zm4fzN0lboUykn6 = aargs[XURrDCfOS9Mbhpv2Pmjos56TeW] if len(aargs)>XURrDCfOS9Mbhpv2Pmjos56TeW and beV5l2D8HznyJI0(u"ࠨࡶ࡬ࡱࡪ࠭ਘ") not in aargs[XURrDCfOS9Mbhpv2Pmjos56TeW] else SI7eBdND4lx8pt5Qk(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩਙ")
	Qja7l4ygF8fmBruVW32bNRZIU = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=HMdFt62RehlTmy,args=(fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,c7Zm4fzN0lboUykn6,uAzZ6xk4T2EDho7iOn))
	Qja7l4ygF8fmBruVW32bNRZIU.start()
	return
def HMdFt62RehlTmy(fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,c7Zm4fzN0lboUykn6,uAzZ6xk4T2EDho7iOn):
	N874ypE1Vo2BfFtX6UrQWI = c7Zm4fzN0lboUykn6.replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪਚ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	import j6urgzFAt4
	name = j6urgzFAt4.qjt73vfsNQZUw6(r0D4C3z7Onqpa,N874ypE1Vo2BfFtX6UrQWI+VP70ytiFNMBl6vHDaW(u"ࠫࠥ࠳ࠠࠨਛ")+fUQ2tkhneHwFLEC+oiWNFYzcIUeh(u"ࠬࠦ࠭ࠡࠩਜ")+HvzeZpTRrx9j1hMBV3)
	name = j6urgzFAt4.WQzfBPt6sDuVw8N5xlcY(name)
	image_filename = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(TWoHRjiOcsKk70dDJu,name+CyHU86ZeYT5BWRcitSm2I(u"࠭࠮ࡱࡰࡪࠫਝ"))
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(image_filename):
		if c7Zm4fzN0lboUykn6==kdRO82AImh0LFw(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧਞ"): image_height = IMjqygdfYSKpHlWu5Aa(u"࠲࠳࠺હ")
		elif c7Zm4fzN0lboUykn6==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬਟ"): image_height = aiQwFE1TGx04vmLcsYkIW5jA(u"࠴࠴࠴઺")
	else: image_height = XcIVdC7NZuatWvkKQhBw8F2LfUyAS6(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,c7Zm4fzN0lboUykn6,beV5l2D8HznyJI0(u"ࠩ࡯ࡩ࡫ࡺࠧਠ"),KiryBCvngZzF85UN6xSDlOVweL4I9,image_filename)
	Fm06lEY1pweOb8GnH = NNSs1CeqntdLV8YD3(oiWNFYzcIUeh(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪਡ"),gH9Y3QcFUL,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬਢ"),oiWNFYzcIUeh(u"ࠬ࠽࠲࠱ࡲࠪਣ"))
	Fm06lEY1pweOb8GnH.show()
	if c7Zm4fzN0lboUykn6==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪਤ"):
		Fm06lEY1pweOb8GnH.getControl(yobpaW7sBqtKRrv(u"࠽࠵࠺࠰઼")).setHeight(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠵࠵࠺઻"))
		Fm06lEY1pweOb8GnH.getControl(tzZ6PhyDOUnwLM3pdK(u"࠹࠱࠶࠳િ")).setPosition(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠺࠻ઽ"),-aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠾࠰ા"))
		Fm06lEY1pweOb8GnH.getControl(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠺࠲࠸࠴ી")).setPosition(pp7FcjEe6g(u"࠳࠵࠴ુ"),-lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠹࠴ૂ"))
		Fm06lEY1pweOb8GnH.getControl(aiQwFE1TGx04vmLcsYkIW5jA(u"࠺࠰࠱ૅ")).setPosition(A6iX18qgyOFlZxz7sc(u"࠽࠵ૃ"),-pp7FcjEe6g(u"࠸࠻ૄ"))
	Fm06lEY1pweOb8GnH.getControl(iySORMYxWXszEH18(u"࠴࠱࠳૆")).setVisible(KiryBCvngZzF85UN6xSDlOVweL4I9)
	Fm06lEY1pweOb8GnH.getControl(bawK2j7T81Nrc4GWs05xzDg(u"࠵࠲࠵ે")).setVisible(KiryBCvngZzF85UN6xSDlOVweL4I9)
	Fm06lEY1pweOb8GnH.getControl(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠻࠳࠹࠵ૈ")).setImage(image_filename)
	Fm06lEY1pweOb8GnH.getControl(A41nqbj3wYt(u"࠼࠴࠺࠶ૉ")).setHeight(image_height)
	x54xSdnCFHZ8yliofzOBK.sleep(uAzZ6xk4T2EDho7iOn//IMjqygdfYSKpHlWu5Aa(u"࠵࠵࠶࠰࠯࠲૊"))
	return
def oEncafdG6UxR50yCutSAjklYvD3T4(*aargs,**kkwargs):
	fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,profile,direction = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਥ"),tzZ6PhyDOUnwLM3pdK(u"ࠨ࡮ࡨࡪࡹ࠭ਦ")
	if len(aargs)>=wnaWTQM7VJPkZzO9eoSyFU4: fUQ2tkhneHwFLEC = aargs[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if len(aargs)>=XURrDCfOS9Mbhpv2Pmjos56TeW: HvzeZpTRrx9j1hMBV3 = aargs[wnaWTQM7VJPkZzO9eoSyFU4]
	if len(aargs)>=vXIdY7TwFKso40gVBq5: profile = aargs[XURrDCfOS9Mbhpv2Pmjos56TeW]
	if len(aargs)>=yGLl1nSBrJPmi2adko9O: direction = aargs[vXIdY7TwFKso40gVBq5]
	return Pgbtx1uwX52DEk7Jf(direction,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,profile)
def zduIlbakFEhsDPM5JU8oR3ZC(*aargs,**kkwargs):
	return Zilvh2WQyb5.Dialog().contextmenu(*aargs,**kkwargs)
def TiBVQ7aWwAO6lzkxjDYFK5by49mh(*aargs,**kkwargs):
	return Zilvh2WQyb5.Dialog().browseSingle(*aargs,**kkwargs)
def PxtAoHE9sLngUWd7JjB8FVbZGa2T1(*aargs,**kkwargs):
	return Zilvh2WQyb5.Dialog().input(*aargs,**kkwargs)
def dpY7rMymk2W1Jo(*aargs,**kkwargs):
	return Zilvh2WQyb5.DialogProgress(*aargs,**kkwargs)
def tFVmMznSUR3XupZBN9kxcO0EHv(direction,button0=WnNGfosHr5STAq8j7miwyRZ6eOUbV,button1=WnNGfosHr5STAq8j7miwyRZ6eOUbV,button2=WnNGfosHr5STAq8j7miwyRZ6eOUbV,fUQ2tkhneHwFLEC=WnNGfosHr5STAq8j7miwyRZ6eOUbV,HvzeZpTRrx9j1hMBV3=WnNGfosHr5STAq8j7miwyRZ6eOUbV,profile=beV5l2D8HznyJI0(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫਧ"),f9267AlBT3RqpdHhVNu=j0jEZgiKdxFpMLHcU7kQr8v1lyX4,U2BTmHYJbwiyA5MuK74PWEQI8tZ=j0jEZgiKdxFpMLHcU7kQr8v1lyX4):
	if not direction: direction = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡧࡪࡴࡴࡦࡴࠪਨ")
	Fm06lEY1pweOb8GnH = GkRq3JUxYKv9HXzidENsg0fn8I(A41nqbj3wYt(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭਩"),gH9Y3QcFUL,KLX7hW0nBAEgy6m4SvH(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ਪ"),YYQS36fyPvtuzcEmRL(u"࠭࠷࠳࠲ࡳࠫਫ"))
	Fm06lEY1pweOb8GnH.mm25rYIeLFhxN0iCQ7zqtUASlT(button0,button1,button2,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,profile,direction,f9267AlBT3RqpdHhVNu,U2BTmHYJbwiyA5MuK74PWEQI8tZ)
	if f9267AlBT3RqpdHhVNu>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: Fm06lEY1pweOb8GnH.Y2bKunMi5pdA6mjI70vckfR()
	if U2BTmHYJbwiyA5MuK74PWEQI8tZ>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: Fm06lEY1pweOb8GnH.x2pztmLFB3OCb9kud0()
	if f9267AlBT3RqpdHhVNu==j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and U2BTmHYJbwiyA5MuK74PWEQI8tZ==j0jEZgiKdxFpMLHcU7kQr8v1lyX4: Fm06lEY1pweOb8GnH.nQYh3wMiayWLgT()
	Fm06lEY1pweOb8GnH.doModal()
	tt2NkXu7HgTIAyj09OBlod3YDpz = Fm06lEY1pweOb8GnH.choiceID
	return tt2NkXu7HgTIAyj09OBlod3YDpz
def Pgbtx1uwX52DEk7Jf(direction,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,profile=oiWNFYzcIUeh(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਬ")):
	if not direction: direction = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࡮ࡨࡪࡹ࠭ਭ")
	Fm06lEY1pweOb8GnH = NNSs1CeqntdLV8YD3(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬਮ"),gH9Y3QcFUL,wwWzyF4ZpSQXKOgk569(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫਯ"),rVy3Ops0mohYkT(u"ࠫ࠼࠸࠰ࡱࠩਰ"))
	image_filename = xx02M7uVUbkgIQpaA4fdYsGjhZNOJn.replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ਱"),gPE1XB87fQl(u"࠭࡟ࠨਲ")+str(x54xSdnCFHZ8yliofzOBK.time())+wwWzyF4ZpSQXKOgk569(u"ࠧࡠࠩਲ਼"))
	image_filename = image_filename.replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡞࡟ࠫ਴"),pp7FcjEe6g(u"ࠩ࡟ࡠࡡࡢࠧਵ")).replace(Z9FPQvwlbjLTh(u"ࠪ࠳࠴࠭ਸ਼"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࠴࠵࠯࠰ࠩ਷"))
	image_height = XcIVdC7NZuatWvkKQhBw8F2LfUyAS6(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fUQ2tkhneHwFLEC,HvzeZpTRrx9j1hMBV3,profile,direction,KiryBCvngZzF85UN6xSDlOVweL4I9,image_filename)
	Fm06lEY1pweOb8GnH.show()
	Fm06lEY1pweOb8GnH.getControl(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠾࠶࠵࠱ો")).setHeight(image_height)
	Fm06lEY1pweOb8GnH.getControl(gPE1XB87fQl(u"࠿࠰࠶࠲ૌ")).setImage(image_filename)
	ZPtB6f173cES8pAKomLWX0sHQbn = Fm06lEY1pweOb8GnH.doModal()
	try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(image_filename)
	except: pass
	return ZPtB6f173cES8pAKomLWX0sHQbn
def XcIVdC7NZuatWvkKQhBw8F2LfUyAS6(YY2DkFX6UuTJbR1MKCntGmeEI3,ZZ6fSIKWNRqPMdw3YHVyTxn0,FMYZjkxRgES8Da7VuN4,eK3RMqJEtvCUDwraFpydVAgsxl,ZVk6IphECKLzUceP15j,HdsCcby3KpzStR7kgW4Ja2,IvRa4nbp7qhLC3KzXZAFMe,cK96MAbW18QPzgJmpOEvk,PqBvJHRnL1WDVUk72bhZFtOf):
	UVN4cImj5ABkbgvp0GaoLSslHwuTn = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.dirname(PqBvJHRnL1WDVUk72bhZFtOf)
	if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(UVN4cImj5ABkbgvp0GaoLSslHwuTn):
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.makedirs(UVN4cImj5ABkbgvp0GaoLSslHwuTn)
		except: pass
	iC8XdZuEmITRNxQzPhH6KsjU7Ay2 = kMDPxyYf3UTB8Vmabt7cXAZ1sh92o0(HdsCcby3KpzStR7kgW4Ja2)
	w0eOlz5N6Cd74 = hDLSd2FPQZ(iC8XdZuEmITRNxQzPhH6KsjU7Ay2,YY2DkFX6UuTJbR1MKCntGmeEI3,ZZ6fSIKWNRqPMdw3YHVyTxn0,FMYZjkxRgES8Da7VuN4,eK3RMqJEtvCUDwraFpydVAgsxl,ZVk6IphECKLzUceP15j,HdsCcby3KpzStR7kgW4Ja2,IvRa4nbp7qhLC3KzXZAFMe,cK96MAbW18QPzgJmpOEvk,PqBvJHRnL1WDVUk72bhZFtOf)
	return w0eOlz5N6Cd74
def kMDPxyYf3UTB8Vmabt7cXAZ1sh92o0(HdsCcby3KpzStR7kgW4Ja2):
	Un1JjritCqTaOkfZPVW0eySH = EEowc8rs5gUZTVjdOzmb0nu
	pJdAmOFvG6wHcuCyZ9WTj3N51nUKM = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠲࠱્")
	fwiv9gjtcGCBmhaLu7rK6doqXJWz = pp7FcjEe6g(u"࠳࠲૎")
	zy8goGamE4 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	uTWBOLinG9slHUVDFrw = YYQS36fyPvtuzcEmRL(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬਸ")
	zOmYV5qaRtJokNBDn3s4Cc = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	VeJC1D2YLiqaBmugKkNZn5rh = CyHU86ZeYT5BWRcitSm2I(u"࠳࠼૏")
	TWpo1QC0fuwzx5IKSFLrBij2eGN4 = yobpaW7sBqtKRrv(u"࠶࠴ૐ")
	Ck1lYBMAcpX6xvogyiRNJFfdus = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠼૑")
	p0itCYMcdqI = r0D4C3z7Onqpa
	DTo7H9Fh2BUqZfX5iNQYbLuCevl = rVy3Ops0mohYkT(u"࠸࠽࠵૒")
	fIboejupDNgY8A = yobpaW7sBqtKRrv(u"࠺࠱࠱૓")
	A8eIDO4fag = kdRO82AImh0LFw(u"࠵࠱૔")
	S8S7wrZBzq0ecTPRdhCN9 = bawK2j7T81Nrc4GWs05xzDg(u"࠳࠺࠳૕")
	j7qYv6KfSr3is1W5bO = IMjqygdfYSKpHlWu5Aa(u"࠴࠻૖")
	sSlFyQIoVGbNzMXp = EEowc8rs5gUZTVjdOzmb0nu
	wucaO9pm2eIgRv61 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	KKZxfwe3X6C80dWFbGYiM = wwWzyF4ZpSQXKOgk569(u"࠶࠵૗")
	bPoxtnX7fap5Y4EQemq8U = [beV5l2D8HznyJI0(u"࠹࠶૚"),pp7FcjEe6g(u"࠷࠷૘"),yobpaW7sBqtKRrv(u"࠷࠾૙")]
	from PIL import ImageDraw as vvcQmIeC9qHzg87KlV3ZNAdBSFsof,ImageFont as bdfnch1pv3,Image as wvCcim4gHMhA6Sn8jPIoUF
	if bawK2j7T81Nrc4GWs05xzDg(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬਹ") in HdsCcby3KpzStR7kgW4Ja2:
		if HdsCcby3KpzStR7kgW4Ja2==A6iX18qgyOFlZxz7sc(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ਺"):
			BBVlaNvQRKg2OY = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠱࠲࠹૛")
			uTWBOLinG9slHUVDFrw = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ࡮ࡨࡪࡹ࠭਻")
			p0itCYMcdqI = KiryBCvngZzF85UN6xSDlOVweL4I9
		elif HdsCcby3KpzStR7kgW4Ja2==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ਼࠭"):
			BBVlaNvQRKg2OY = aiQwFE1TGx04vmLcsYkIW5jA(u"࡙ࠪࡕࡖࡅࡓࠩ਽")
			uTWBOLinG9slHUVDFrw = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡷ࡯ࡧࡩࡶࠪਾ")
			zy8goGamE4 = Z9FPQvwlbjLTh(u"࠲࠲૜")
		xxjd43nRbovgOcHD2sQL6 = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠹࠵࠴૝")
		bPoxtnX7fap5Y4EQemq8U = [tzZ6PhyDOUnwLM3pdK(u"࠶࠷૞"),tzZ6PhyDOUnwLM3pdK(u"࠶࠷૞"),tzZ6PhyDOUnwLM3pdK(u"࠶࠷૞")]
		fwiv9gjtcGCBmhaLu7rK6doqXJWz = GHg28TBchiyn6l(u"࠶࠵૟")
		pJdAmOFvG6wHcuCyZ9WTj3N51nUKM = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		TWpo1QC0fuwzx5IKSFLrBij2eGN4 = Z9FPQvwlbjLTh(u"࠷࠶ૠ")
		VeJC1D2YLiqaBmugKkNZn5rh = SI7eBdND4lx8pt5Qk(u"࠹࠵ૡ")
	elif HdsCcby3KpzStR7kgW4Ja2==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡳࡥ࡯ࡷࡢ࡭ࡹ࡫࡭ࠨਿ"):
		bPoxtnX7fap5Y4EQemq8U,xxjd43nRbovgOcHD2sQL6,BBVlaNvQRKg2OY = [lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠴࠻૤"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠴࠻૤"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠴࠻૤")],mq5t9JXSdHT8yfDVF(u"࠲࠱࠲ૢ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠳࠷࠳ૣ")
		zOmYV5qaRtJokNBDn3s4Cc,TWpo1QC0fuwzx5IKSFLrBij2eGN4,VeJC1D2YLiqaBmugKkNZn5rh, = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,-CyHU86ZeYT5BWRcitSm2I(u"࠴࠶૥"),-pp7FcjEe6g(u"࠷࠵૦")
		pJdAmOFvG6wHcuCyZ9WTj3N51nUKM = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		g1KACutdS2E3ye7Y6aPz9 = wvCcim4gHMhA6Sn8jPIoUF.open(ucAYIptK5bJE0DQ742NxrBfqLea)
		vcmYi7eQFhMXrKButG64IobkRO2Waf = wvCcim4gHMhA6Sn8jPIoUF.new(aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡒࡈࡄࡄࠫੀ"),(xxjd43nRbovgOcHD2sQL6,BBVlaNvQRKg2OY),(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠻࠵૧"),j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠻࠵૧")))
	elif HdsCcby3KpzStR7kgW4Ja2==A6iX18qgyOFlZxz7sc(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੁ"): bPoxtnX7fap5Y4EQemq8U,BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = [eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠴࠻૫"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠸࠴૨"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠲࠱૩")],SI7eBdND4lx8pt5Qk(u"࠸࠴࠵૬"),CyHU86ZeYT5BWRcitSm2I(u"࠺࠲࠳૪")
	elif HdsCcby3KpzStR7kgW4Ja2==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ੂ"): bPoxtnX7fap5Y4EQemq8U,BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = [mq5t9JXSdHT8yfDVF(u"࠸࠸૮"),rVy3Ops0mohYkT(u"࠲࠹૰"),Z9FPQvwlbjLTh(u"࠶࠹૭")],mq5t9JXSdHT8yfDVF(u"࠶࠲࠳૱"),wwWzyF4ZpSQXKOgk569(u"࠿࠰࠱૯")
	elif HdsCcby3KpzStR7kgW4Ja2==A41nqbj3wYt(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ੃"): bPoxtnX7fap5Y4EQemq8U,BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = [A6iX18qgyOFlZxz7sc(u"࠸࠼૵"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠵࠵૲"),beV5l2D8HznyJI0(u"࠶࠽૴")],pp7FcjEe6g(u"࠻࠰࠱૶"),CyHU86ZeYT5BWRcitSm2I(u"࠼࠴࠵૳")
	elif HdsCcby3KpzStR7kgW4Ja2==YYQS36fyPvtuzcEmRL(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭੄"): BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠷࠵࠲૷"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠲࠴࠺࠴૸")
	elif HdsCcby3KpzStR7kgW4Ja2==ZLr5gRSkFewKdUos90bM(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ੅"): BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = jhDZ0BAFoEGUcw5QrJkaxXL(u"࡛ࠬࡐࡑࡇࡕࠫ੆"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠵࠻࠵ૹ")
	elif HdsCcby3KpzStR7kgW4Ja2==mq5t9JXSdHT8yfDVF(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੇ"): bPoxtnX7fap5Y4EQemq8U,BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠸࠸૽"),aiQwFE1TGx04vmLcsYkIW5jA(u"࠲࠴૾"),VP70ytiFNMBl6vHDaW(u"࠵࠽ૻ")],XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠺࠸࠵ૺ"),A6iX18qgyOFlZxz7sc(u"࠶࠸࠷࠱ૼ")
	elif HdsCcby3KpzStR7kgW4Ja2==yobpaW7sBqtKRrv(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪੈ"): bPoxtnX7fap5Y4EQemq8U,BBVlaNvQRKg2OY,xxjd43nRbovgOcHD2sQL6 = [GHg28TBchiyn6l(u"࠵࠼ଁ"),pp7FcjEe6g(u"࠶࠸ଂ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠳࠻଀")],pp7FcjEe6g(u"ࠨࡗࡓࡔࡊࡘࠧ੉"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠲࠴࠺࠴૿")
	xxawyue97MNbqOSX4C,tMS8eYdCVIjT5,qdkFVpJT1QeS2BEizLmo5AK4U7s9jW = bPoxtnX7fap5Y4EQemq8U
	aas1MLmROG06 = bdfnch1pv3.truetype(VD2saKIdfOmxJr0,size=xxawyue97MNbqOSX4C)
	UUZJeH0cdFEf3wYL = bdfnch1pv3.truetype(VD2saKIdfOmxJr0,size=tMS8eYdCVIjT5)
	STiE29MNBmU7DhGswqPXfu = bdfnch1pv3.truetype(VD2saKIdfOmxJr0,size=qdkFVpJT1QeS2BEizLmo5AK4U7s9jW)
	MXqY2mfl4FczhAGHNnSwZRj1tgJ = xxjd43nRbovgOcHD2sQL6-TWpo1QC0fuwzx5IKSFLrBij2eGN4*XURrDCfOS9Mbhpv2Pmjos56TeW
	Ml1qJ6wdWyLbYN07AzOr = wvCcim4gHMhA6Sn8jPIoUF.new(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡕࡋࡇࡇࠧ੊"),(MXqY2mfl4FczhAGHNnSwZRj1tgJ,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠶࠶࠰ଃ")),(A41nqbj3wYt(u"࠸࠵࠶଄"),A41nqbj3wYt(u"࠸࠵࠶଄"),A41nqbj3wYt(u"࠸࠵࠶଄"),j0jEZgiKdxFpMLHcU7kQr8v1lyX4))
	PP8mEHuZw9OtkNDyXJe = vvcQmIeC9qHzg87KlV3ZNAdBSFsof.Draw(Ml1qJ6wdWyLbYN07AzOr)
	J7nVeb0FrQ,PciMa0swOYtqH1CyQ = PP8mEHuZw9OtkNDyXJe.textsize(yobpaW7sBqtKRrv(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬੋ"),font=aas1MLmROG06)
	NPAR9zfIjomO7VJaYuC1vdU,AxaNPZTq9EDYFl = PP8mEHuZw9OtkNDyXJe.textsize(gPE1XB87fQl(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ੌ"),font=UUZJeH0cdFEf3wYL)
	X7JFGWABqT = {Z9FPQvwlbjLTh(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡮ࡡࡳࡣ࡮ࡥࡹ੍࠭"):KiryBCvngZzF85UN6xSDlOVweL4I9,beV5l2D8HznyJI0(u"࠭ࡳࡶࡲࡳࡳࡷࡺ࡟࡭࡫ࡪࡥࡹࡻࡲࡦࡵࠪ੎"):r0D4C3z7Onqpa,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡂࡔࡄࡆࡎࡉࠠࡍࡋࡊࡅ࡙࡛ࡒࡆࠢࡄࡐࡑࡇࡈࠨ੏"):KiryBCvngZzF85UN6xSDlOVweL4I9}
	from arabic_reshaper import ArabicReshaper as yjgesEoHhwI7BMQ41xW6Un
	MoDSQyeJPwLFrOtZhgUj90H = yjgesEoHhwI7BMQ41xW6Un(configuration=X7JFGWABqT)
	iC8XdZuEmITRNxQzPhH6KsjU7Ay2 = {}
	PDOKS9T5jwvEYcm2R = locals()
	for LoeIfPVjrk in PDOKS9T5jwvEYcm2R: iC8XdZuEmITRNxQzPhH6KsjU7Ay2[LoeIfPVjrk] = PDOKS9T5jwvEYcm2R[LoeIfPVjrk]
	return iC8XdZuEmITRNxQzPhH6KsjU7Ay2
def hDLSd2FPQZ(iC8XdZuEmITRNxQzPhH6KsjU7Ay2,YY2DkFX6UuTJbR1MKCntGmeEI3,ZZ6fSIKWNRqPMdw3YHVyTxn0,FMYZjkxRgES8Da7VuN4,eK3RMqJEtvCUDwraFpydVAgsxl,ZVk6IphECKLzUceP15j,HdsCcby3KpzStR7kgW4Ja2,IvRa4nbp7qhLC3KzXZAFMe,cK96MAbW18QPzgJmpOEvk,PqBvJHRnL1WDVUk72bhZFtOf):
	for LoeIfPVjrk in iC8XdZuEmITRNxQzPhH6KsjU7Ay2: globals()[LoeIfPVjrk] = iC8XdZuEmITRNxQzPhH6KsjU7Ay2[LoeIfPVjrk]
	global j7qYv6KfSr3is1W5bO,sSlFyQIoVGbNzMXp
	if HdsCcby3KpzStR7kgW4Ja2!=jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ੐"):
		mNOMsGCeVpuZD = G3yDpvxOiSWdAeL.getSetting(tzZ6PhyDOUnwLM3pdK(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪੑ"))
		if mNOMsGCeVpuZD:
			if YY2DkFX6UuTJbR1MKCntGmeEI3==aiQwFE1TGx04vmLcsYkIW5jA(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬ੒"): YY2DkFX6UuTJbR1MKCntGmeEI3 = yobpaW7sBqtKRrv(u"ࠫ࡞࡫ࡳࠨ੓")
			elif YY2DkFX6UuTJbR1MKCntGmeEI3==yobpaW7sBqtKRrv(u"้ࠬไศࠢࠣࡒࡴ࠭੔"): YY2DkFX6UuTJbR1MKCntGmeEI3 = IMjqygdfYSKpHlWu5Aa(u"࠭ࡎࡰࠩ੕")
			if ZZ6fSIKWNRqPMdw3YHVyTxn0==YYQS36fyPvtuzcEmRL(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩ੖"): ZZ6fSIKWNRqPMdw3YHVyTxn0 = VP70ytiFNMBl6vHDaW(u"ࠨ࡛ࡨࡷࠬ੗")
			elif ZZ6fSIKWNRqPMdw3YHVyTxn0==bawK2j7T81Nrc4GWs05xzDg(u"ࠩๆ่ฬࠦࠠࡏࡱࠪ੘"): ZZ6fSIKWNRqPMdw3YHVyTxn0 = wwWzyF4ZpSQXKOgk569(u"ࠪࡒࡴ࠭ਖ਼")
			if FMYZjkxRgES8Da7VuN4==wwWzyF4ZpSQXKOgk569(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ਗ਼"): FMYZjkxRgES8Da7VuN4 = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡟ࡥࡴࠩਜ਼")
			elif FMYZjkxRgES8Da7VuN4==A41nqbj3wYt(u"࠭ใๅษࠣࠤࡓࡵࠧੜ"): FMYZjkxRgES8Da7VuN4 = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡏࡱࠪ੝")
			import j6urgzFAt4
			ww9PixygdMfDQJt = j6urgzFAt4.llBW3Jpg8MXA([YY2DkFX6UuTJbR1MKCntGmeEI3,ZZ6fSIKWNRqPMdw3YHVyTxn0,FMYZjkxRgES8Da7VuN4,eK3RMqJEtvCUDwraFpydVAgsxl,ZVk6IphECKLzUceP15j])
			if ww9PixygdMfDQJt: YY2DkFX6UuTJbR1MKCntGmeEI3,ZZ6fSIKWNRqPMdw3YHVyTxn0,FMYZjkxRgES8Da7VuN4,eK3RMqJEtvCUDwraFpydVAgsxl,ZVk6IphECKLzUceP15j = ww9PixygdMfDQJt
	if YVzokG2yZqrh3w8bU:
		ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.decode(e87cIA5vwOQLDEP1)
		eK3RMqJEtvCUDwraFpydVAgsxl = eK3RMqJEtvCUDwraFpydVAgsxl.decode(e87cIA5vwOQLDEP1)
		YY2DkFX6UuTJbR1MKCntGmeEI3 = YY2DkFX6UuTJbR1MKCntGmeEI3.decode(e87cIA5vwOQLDEP1)
		ZZ6fSIKWNRqPMdw3YHVyTxn0 = ZZ6fSIKWNRqPMdw3YHVyTxn0.decode(e87cIA5vwOQLDEP1)
		FMYZjkxRgES8Da7VuN4 = FMYZjkxRgES8Da7VuN4.decode(e87cIA5vwOQLDEP1)
	ppqda7JQLb = eK3RMqJEtvCUDwraFpydVAgsxl.count(WBDnh75CaLEvkcN6p4ez2KXrV3M)+wnaWTQM7VJPkZzO9eoSyFU4
	rfGHqoP8vKCt2baO913pwh6njBSem5 = pJdAmOFvG6wHcuCyZ9WTj3N51nUKM+ppqda7JQLb*(PciMa0swOYtqH1CyQ+zy8goGamE4)-zy8goGamE4
	if ZVk6IphECKLzUceP15j:
		MeDAS81EXf9dqcBbW = AxaNPZTq9EDYFl+Ck1lYBMAcpX6xvogyiRNJFfdus
		yeIXtapmS2NQOV9c = MoDSQyeJPwLFrOtZhgUj90H.reshape(ZVk6IphECKLzUceP15j)
		if p0itCYMcdqI:
			TMepvR0n1Juql5Q = STqLgaMZPDwtKHIvju04pdAUhfEsr(PP8mEHuZw9OtkNDyXJe,UUZJeH0cdFEf3wYL,yeIXtapmS2NQOV9c,tMS8eYdCVIjT5,MXqY2mfl4FczhAGHNnSwZRj1tgJ,MeDAS81EXf9dqcBbW)
			olNqAWRmYbyeHpgOr4Z = kve7y0iCMK8oHqdQOSJ9T(TMepvR0n1Juql5Q)
			byHtwBlY9OdepKfgqTNuL72SD0F = olNqAWRmYbyeHpgOr4Z.count(WBDnh75CaLEvkcN6p4ez2KXrV3M)+wnaWTQM7VJPkZzO9eoSyFU4
			pEIyP5vce7VdShsi9XMtA8xaGUz = VeJC1D2YLiqaBmugKkNZn5rh+byHtwBlY9OdepKfgqTNuL72SD0F*MeDAS81EXf9dqcBbW-Ck1lYBMAcpX6xvogyiRNJFfdus
		else:
			pEIyP5vce7VdShsi9XMtA8xaGUz = VeJC1D2YLiqaBmugKkNZn5rh+AxaNPZTq9EDYFl
			olNqAWRmYbyeHpgOr4Z = yeIXtapmS2NQOV9c.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			TMepvR0n1Juql5Q = yeIXtapmS2NQOV9c.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else: pEIyP5vce7VdShsi9XMtA8xaGUz = VeJC1D2YLiqaBmugKkNZn5rh
	I48IvsCPynWmT = wucaO9pm2eIgRv61+KKZxfwe3X6C80dWFbGYiM
	if cK96MAbW18QPzgJmpOEvk:
		E6F1eYBpsQLlvUT9kO4HM3bZSaI = fIboejupDNgY8A-DTo7H9Fh2BUqZfX5iNQYbLuCevl
		I48IvsCPynWmT += E6F1eYBpsQLlvUT9kO4HM3bZSaI
	else: E6F1eYBpsQLlvUT9kO4HM3bZSaI = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	if YY2DkFX6UuTJbR1MKCntGmeEI3 or ZZ6fSIKWNRqPMdw3YHVyTxn0 or FMYZjkxRgES8Da7VuN4: I48IvsCPynWmT += A8eIDO4fag
	w0eOlz5N6Cd74 = BBVlaNvQRKg2OY if BBVlaNvQRKg2OY!=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡗࡓࡔࡊࡘࠧਫ਼") else rfGHqoP8vKCt2baO913pwh6njBSem5+pEIyP5vce7VdShsi9XMtA8xaGUz+I48IvsCPynWmT
	Ml1qJ6wdWyLbYN07AzOr = wvCcim4gHMhA6Sn8jPIoUF.new(VP70ytiFNMBl6vHDaW(u"ࠩࡕࡋࡇࡇࠧ੟"),(xxjd43nRbovgOcHD2sQL6,w0eOlz5N6Cd74),(CyHU86ZeYT5BWRcitSm2I(u"࠲࠶࠷ଅ"),CyHU86ZeYT5BWRcitSm2I(u"࠲࠶࠷ଅ"),CyHU86ZeYT5BWRcitSm2I(u"࠲࠶࠷ଅ"),j0jEZgiKdxFpMLHcU7kQr8v1lyX4))
	dAQ7mZePD8wBIEOK6jhRng5prG = vvcQmIeC9qHzg87KlV3ZNAdBSFsof.Draw(Ml1qJ6wdWyLbYN07AzOr)
	OOnb7iIfgxZyBl = w0eOlz5N6Cd74-rfGHqoP8vKCt2baO913pwh6njBSem5-I48IvsCPynWmT-VeJC1D2YLiqaBmugKkNZn5rh
	if not ZZ6fSIKWNRqPMdw3YHVyTxn0 and YY2DkFX6UuTJbR1MKCntGmeEI3 and FMYZjkxRgES8Da7VuN4:
		j7qYv6KfSr3is1W5bO += aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠲࠲࠸ଆ")
		sSlFyQIoVGbNzMXp -= mq5t9JXSdHT8yfDVF(u"࠳࠴࠴ଇ")
	import bidi.algorithm as IaP1Ryqv2Z3x
	if eK3RMqJEtvCUDwraFpydVAgsxl:
		Rdicg3FH8sCt2oSw91vZyPVhfT = pJdAmOFvG6wHcuCyZ9WTj3N51nUKM
		eK3RMqJEtvCUDwraFpydVAgsxl = IaP1Ryqv2Z3x.get_display(MoDSQyeJPwLFrOtZhgUj90H.reshape(eK3RMqJEtvCUDwraFpydVAgsxl))
		t7TS2ruafMQ = eK3RMqJEtvCUDwraFpydVAgsxl.splitlines()
		for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
			if JHLkRVEQFA1WUwZPtD4Cyxr8:
				FM6uQWDAgjBsEdwCLzZitc83Vk,xPR6z8aqW3DQXTtv0IuynG5 = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(JHLkRVEQFA1WUwZPtD4Cyxr8,font=aas1MLmROG06)
				if uTWBOLinG9slHUVDFrw==pp7FcjEe6g(u"ࠪࡧࡪࡴࡴࡦࡴࠪ੠"): tf9IOYXDPF = Un1JjritCqTaOkfZPVW0eySH+(xxjd43nRbovgOcHD2sQL6-FM6uQWDAgjBsEdwCLzZitc83Vk)/XURrDCfOS9Mbhpv2Pmjos56TeW
				elif uTWBOLinG9slHUVDFrw==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡷ࡯ࡧࡩࡶࠪ੡"): tf9IOYXDPF = Un1JjritCqTaOkfZPVW0eySH+xxjd43nRbovgOcHD2sQL6-FM6uQWDAgjBsEdwCLzZitc83Vk-fwiv9gjtcGCBmhaLu7rK6doqXJWz
				elif uTWBOLinG9slHUVDFrw==pp7FcjEe6g(u"ࠬࡲࡥࡧࡶࠪ੢"): tf9IOYXDPF = Un1JjritCqTaOkfZPVW0eySH+fwiv9gjtcGCBmhaLu7rK6doqXJWz
				dAQ7mZePD8wBIEOK6jhRng5prG.text((tf9IOYXDPF,Rdicg3FH8sCt2oSw91vZyPVhfT),JHLkRVEQFA1WUwZPtD4Cyxr8,font=aas1MLmROG06,fill=CyHU86ZeYT5BWRcitSm2I(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭੣"))
			Rdicg3FH8sCt2oSw91vZyPVhfT += xxawyue97MNbqOSX4C+zy8goGamE4
	if YY2DkFX6UuTJbR1MKCntGmeEI3 or ZZ6fSIKWNRqPMdw3YHVyTxn0 or FMYZjkxRgES8Da7VuN4:
		dc1uGmDtSxqZ0F6gsJ = rfGHqoP8vKCt2baO913pwh6njBSem5+OOnb7iIfgxZyBl+VeJC1D2YLiqaBmugKkNZn5rh+E6F1eYBpsQLlvUT9kO4HM3bZSaI+wucaO9pm2eIgRv61
		if YY2DkFX6UuTJbR1MKCntGmeEI3:
			YY2DkFX6UuTJbR1MKCntGmeEI3 = IaP1Ryqv2Z3x.get_display(MoDSQyeJPwLFrOtZhgUj90H.reshape(YY2DkFX6UuTJbR1MKCntGmeEI3))
			FABMb8EPGR4uL09rcd3T,gz3W8shaQvj9iuG = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(YY2DkFX6UuTJbR1MKCntGmeEI3,font=STiE29MNBmU7DhGswqPXfu)
			tgIeqnYJ2jD0BFQaWbwLOhm = j7qYv6KfSr3is1W5bO+j0jEZgiKdxFpMLHcU7kQr8v1lyX4*(sSlFyQIoVGbNzMXp+S8S7wrZBzq0ecTPRdhCN9)+(S8S7wrZBzq0ecTPRdhCN9-FABMb8EPGR4uL09rcd3T)/XURrDCfOS9Mbhpv2Pmjos56TeW
			dAQ7mZePD8wBIEOK6jhRng5prG.text((tgIeqnYJ2jD0BFQaWbwLOhm,dc1uGmDtSxqZ0F6gsJ),YY2DkFX6UuTJbR1MKCntGmeEI3,font=STiE29MNBmU7DhGswqPXfu,fill=pp7FcjEe6g(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ੤"))
		if ZZ6fSIKWNRqPMdw3YHVyTxn0:
			ZZ6fSIKWNRqPMdw3YHVyTxn0 = IaP1Ryqv2Z3x.get_display(MoDSQyeJPwLFrOtZhgUj90H.reshape(ZZ6fSIKWNRqPMdw3YHVyTxn0))
			ZvqxHdDWA7bBI5gpeQySrNG,RUN1JivLT6Wz4sVhuofyrDbYa50GXM = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(ZZ6fSIKWNRqPMdw3YHVyTxn0,font=STiE29MNBmU7DhGswqPXfu)
			QwEq5onbzyZLkAPN2TR = j7qYv6KfSr3is1W5bO+wnaWTQM7VJPkZzO9eoSyFU4*(sSlFyQIoVGbNzMXp+S8S7wrZBzq0ecTPRdhCN9)+(S8S7wrZBzq0ecTPRdhCN9-ZvqxHdDWA7bBI5gpeQySrNG)/XURrDCfOS9Mbhpv2Pmjos56TeW
			dAQ7mZePD8wBIEOK6jhRng5prG.text((QwEq5onbzyZLkAPN2TR,dc1uGmDtSxqZ0F6gsJ),ZZ6fSIKWNRqPMdw3YHVyTxn0,font=STiE29MNBmU7DhGswqPXfu,fill=Z9FPQvwlbjLTh(u"ࠨࡻࡨࡰࡱࡵࡷࠨ੥"))
		if FMYZjkxRgES8Da7VuN4:
			FMYZjkxRgES8Da7VuN4 = IaP1Ryqv2Z3x.get_display(MoDSQyeJPwLFrOtZhgUj90H.reshape(FMYZjkxRgES8Da7VuN4))
			mm3UST56kJxXK,EYmCgb2sJjdDp = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(FMYZjkxRgES8Da7VuN4,font=STiE29MNBmU7DhGswqPXfu)
			mBsRF03bjQc2M4KonwSDprq6 = j7qYv6KfSr3is1W5bO+XURrDCfOS9Mbhpv2Pmjos56TeW*(sSlFyQIoVGbNzMXp+S8S7wrZBzq0ecTPRdhCN9)+(S8S7wrZBzq0ecTPRdhCN9-mm3UST56kJxXK)/XURrDCfOS9Mbhpv2Pmjos56TeW
			dAQ7mZePD8wBIEOK6jhRng5prG.text((mBsRF03bjQc2M4KonwSDprq6,dc1uGmDtSxqZ0F6gsJ),FMYZjkxRgES8Da7VuN4,font=STiE29MNBmU7DhGswqPXfu,fill=wwWzyF4ZpSQXKOgk569(u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ੦"))
	if ZVk6IphECKLzUceP15j:
		hzK4pCtDkXwZM,YJNIkhuMle3 = [],[]
		TMepvR0n1Juql5Q = i4BT3GAO8KpXQrPU70bdxavVnL(TMepvR0n1Juql5Q)
		DDHAO5Ny1gvaSxzVcdoKl = TMepvR0n1Juql5Q.split(yobpaW7sBqtKRrv(u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ੧"))
		for raXpZB1hC72RuqfK6F4S3yg in DDHAO5Ny1gvaSxzVcdoKl:
			Iy2GVKr6dv = IvRa4nbp7qhLC3KzXZAFMe
			if   jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭੨") in raXpZB1hC72RuqfK6F4S3yg: Iy2GVKr6dv = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡲࡥࡧࡶࠪ੩")
			elif SI7eBdND4lx8pt5Qk(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ੪") in raXpZB1hC72RuqfK6F4S3yg: Iy2GVKr6dv = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭੫")
			elif mq5t9JXSdHT8yfDVF(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ੬") in raXpZB1hC72RuqfK6F4S3yg: Iy2GVKr6dv = kdRO82AImh0LFw(u"ࠩࡦࡩࡳࡺࡥࡳࠩ੭")
			s3PHA0FNfxJiIBU = raXpZB1hC72RuqfK6F4S3yg
			L5z7u8ygrwpT = p7dwlH1PRStBgyMUW.findall(ZLr5gRSkFewKdUos90bM(u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ੮"),raXpZB1hC72RuqfK6F4S3yg,p7dwlH1PRStBgyMUW.DOTALL)
			for WBUefDkT0FzSVKZc in L5z7u8ygrwpT: s3PHA0FNfxJiIBU = s3PHA0FNfxJiIBU.replace(WBUefDkT0FzSVKZc,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if s3PHA0FNfxJiIBU==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FM6uQWDAgjBsEdwCLzZitc83Vk,xPR6z8aqW3DQXTtv0IuynG5 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,MeDAS81EXf9dqcBbW
			else: FM6uQWDAgjBsEdwCLzZitc83Vk,xPR6z8aqW3DQXTtv0IuynG5 = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(s3PHA0FNfxJiIBU,font=UUZJeH0cdFEf3wYL)
			if   Iy2GVKr6dv==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡱ࡫ࡦࡵࠩ੯"): wwjDf5VntNemCKPqhkMXcgOp8EzrHY = zOmYV5qaRtJokNBDn3s4Cc+TWpo1QC0fuwzx5IKSFLrBij2eGN4
			elif Iy2GVKr6dv==gPE1XB87fQl(u"ࠬࡸࡩࡨࡪࡷࠫੰ"): wwjDf5VntNemCKPqhkMXcgOp8EzrHY = zOmYV5qaRtJokNBDn3s4Cc+TWpo1QC0fuwzx5IKSFLrBij2eGN4+MXqY2mfl4FczhAGHNnSwZRj1tgJ-FM6uQWDAgjBsEdwCLzZitc83Vk
			elif Iy2GVKr6dv==wwWzyF4ZpSQXKOgk569(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ੱ"): wwjDf5VntNemCKPqhkMXcgOp8EzrHY = zOmYV5qaRtJokNBDn3s4Cc+TWpo1QC0fuwzx5IKSFLrBij2eGN4+(MXqY2mfl4FczhAGHNnSwZRj1tgJ-FM6uQWDAgjBsEdwCLzZitc83Vk)/XURrDCfOS9Mbhpv2Pmjos56TeW
			if wwjDf5VntNemCKPqhkMXcgOp8EzrHY<TWpo1QC0fuwzx5IKSFLrBij2eGN4: wwjDf5VntNemCKPqhkMXcgOp8EzrHY = zOmYV5qaRtJokNBDn3s4Cc+TWpo1QC0fuwzx5IKSFLrBij2eGN4
			hzK4pCtDkXwZM.append(wwjDf5VntNemCKPqhkMXcgOp8EzrHY)
			YJNIkhuMle3.append(FM6uQWDAgjBsEdwCLzZitc83Vk)
		wwjDf5VntNemCKPqhkMXcgOp8EzrHY = hzK4pCtDkXwZM[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		Sp9rGELAogNTBqMvV1mc2jIxJ = TMepvR0n1Juql5Q.split(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡠࡵࡶࡷࡤ࠭ੲ"))
		xxqJVQFP0reUXd2OotWlKTES9h = (eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠹࠺ଈ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠹࠺ଈ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠹࠺ଈ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠹࠺ଈ"))
		fexFWZs8GpgTNA = xxqJVQFP0reUXd2OotWlKTES9h
		NHhI5ScA2nVJy4E,mQZMV8Lk7HBgFhoYEKbSj5XzOfrPGa = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		eexQCmTqNFsMtgUGhDZ = KiryBCvngZzF85UN6xSDlOVweL4I9
		ae7SbrNickJDs830M = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		VxOiFkL8WJgY9 = rfGHqoP8vKCt2baO913pwh6njBSem5+VeJC1D2YLiqaBmugKkNZn5rh/XURrDCfOS9Mbhpv2Pmjos56TeW
		if pEIyP5vce7VdShsi9XMtA8xaGUz<(OOnb7iIfgxZyBl+VeJC1D2YLiqaBmugKkNZn5rh):
			drzLnePoRqjVw6a7WtKmDIY = (OOnb7iIfgxZyBl+VeJC1D2YLiqaBmugKkNZn5rh-pEIyP5vce7VdShsi9XMtA8xaGUz)/XURrDCfOS9Mbhpv2Pmjos56TeW
			VxOiFkL8WJgY9 = rfGHqoP8vKCt2baO913pwh6njBSem5+VeJC1D2YLiqaBmugKkNZn5rh+drzLnePoRqjVw6a7WtKmDIY-AxaNPZTq9EDYFl/XURrDCfOS9Mbhpv2Pmjos56TeW
		for JHLkRVEQFA1WUwZPtD4Cyxr8 in Sp9rGELAogNTBqMvV1mc2jIxJ:
			if not JHLkRVEQFA1WUwZPtD4Cyxr8 or (JHLkRVEQFA1WUwZPtD4Cyxr8 and ord(JHLkRVEQFA1WUwZPtD4Cyxr8[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠺࠺࠸࠷࠺ଉ")): continue
			T0TOzIKFsUm9qhbZg = JHLkRVEQFA1WUwZPtD4Cyxr8.split(pp7FcjEe6g(u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫੳ"),wnaWTQM7VJPkZzO9eoSyFU4)
			L5oleNStIbWPi4xuOAhyKwn98sFvaG = JHLkRVEQFA1WUwZPtD4Cyxr8.split(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬੴ"),wnaWTQM7VJPkZzO9eoSyFU4)
			CG9ZnRQlLMcSbqVY = JHLkRVEQFA1WUwZPtD4Cyxr8.split(iySORMYxWXszEH18(u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧੵ"),wnaWTQM7VJPkZzO9eoSyFU4)
			NYm347gTz0 = JHLkRVEQFA1WUwZPtD4Cyxr8.split(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ੶"),wnaWTQM7VJPkZzO9eoSyFU4)
			td1PW9zNwQrTbocBg3XDinKC = JHLkRVEQFA1WUwZPtD4Cyxr8.split(gPE1XB87fQl(u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ੷"),wnaWTQM7VJPkZzO9eoSyFU4)
			syGctHefji9Ob1FRw3DmEvV = JHLkRVEQFA1WUwZPtD4Cyxr8.split(ZLr5gRSkFewKdUos90bM(u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ੸"),wnaWTQM7VJPkZzO9eoSyFU4)
			sKFGHRv6mNnOIqpxy0 = JHLkRVEQFA1WUwZPtD4Cyxr8.split(oiWNFYzcIUeh(u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭੹"),wnaWTQM7VJPkZzO9eoSyFU4)
			if len(T0TOzIKFsUm9qhbZg)>wnaWTQM7VJPkZzO9eoSyFU4:
				ae7SbrNickJDs830M += wnaWTQM7VJPkZzO9eoSyFU4
				JHLkRVEQFA1WUwZPtD4Cyxr8 = T0TOzIKFsUm9qhbZg[wnaWTQM7VJPkZzO9eoSyFU4]
				NHhI5ScA2nVJy4E = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
				wwjDf5VntNemCKPqhkMXcgOp8EzrHY = hzK4pCtDkXwZM[ae7SbrNickJDs830M]
				mQZMV8Lk7HBgFhoYEKbSj5XzOfrPGa += MeDAS81EXf9dqcBbW
				eexQCmTqNFsMtgUGhDZ = KiryBCvngZzF85UN6xSDlOVweL4I9
			elif len(L5oleNStIbWPi4xuOAhyKwn98sFvaG)>wnaWTQM7VJPkZzO9eoSyFU4:
				JHLkRVEQFA1WUwZPtD4Cyxr8 = L5oleNStIbWPi4xuOAhyKwn98sFvaG[wnaWTQM7VJPkZzO9eoSyFU4]
				fexFWZs8GpgTNA = JHLkRVEQFA1WUwZPtD4Cyxr8[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:yobpaW7sBqtKRrv(u"࠽ଊ")]
				fexFWZs8GpgTNA = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࠥࠪ੺")+fexFWZs8GpgTNA[XURrDCfOS9Mbhpv2Pmjos56TeW:]
				JHLkRVEQFA1WUwZPtD4Cyxr8 = JHLkRVEQFA1WUwZPtD4Cyxr8[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠿ଋ"):]
			elif len(CG9ZnRQlLMcSbqVY)>wnaWTQM7VJPkZzO9eoSyFU4:
				JHLkRVEQFA1WUwZPtD4Cyxr8 = CG9ZnRQlLMcSbqVY[wnaWTQM7VJPkZzO9eoSyFU4]
				fexFWZs8GpgTNA = xxqJVQFP0reUXd2OotWlKTES9h
			elif len(NYm347gTz0)>wnaWTQM7VJPkZzO9eoSyFU4:
				JHLkRVEQFA1WUwZPtD4Cyxr8 = NYm347gTz0[wnaWTQM7VJPkZzO9eoSyFU4]
				eexQCmTqNFsMtgUGhDZ = r0D4C3z7Onqpa
				NHhI5ScA2nVJy4E = YJNIkhuMle3[ae7SbrNickJDs830M]
			elif len(td1PW9zNwQrTbocBg3XDinKC)>ZLr5gRSkFewKdUos90bM(u"࠱ଌ"): JHLkRVEQFA1WUwZPtD4Cyxr8 = td1PW9zNwQrTbocBg3XDinKC[wnaWTQM7VJPkZzO9eoSyFU4]
			elif len(syGctHefji9Ob1FRw3DmEvV)>A6iX18qgyOFlZxz7sc(u"࠲଍"): JHLkRVEQFA1WUwZPtD4Cyxr8 = syGctHefji9Ob1FRw3DmEvV[wnaWTQM7VJPkZzO9eoSyFU4]
			elif len(sKFGHRv6mNnOIqpxy0)>wwWzyF4ZpSQXKOgk569(u"࠳଎"): JHLkRVEQFA1WUwZPtD4Cyxr8 = sKFGHRv6mNnOIqpxy0[wnaWTQM7VJPkZzO9eoSyFU4]
			if JHLkRVEQFA1WUwZPtD4Cyxr8:
				eayb8F07uk5xr1VpcvgEfICABHs = VxOiFkL8WJgY9+mQZMV8Lk7HBgFhoYEKbSj5XzOfrPGa
				JHLkRVEQFA1WUwZPtD4Cyxr8 = IaP1Ryqv2Z3x.get_display(JHLkRVEQFA1WUwZPtD4Cyxr8)
				FM6uQWDAgjBsEdwCLzZitc83Vk,xPR6z8aqW3DQXTtv0IuynG5 = dAQ7mZePD8wBIEOK6jhRng5prG.textsize(JHLkRVEQFA1WUwZPtD4Cyxr8,font=UUZJeH0cdFEf3wYL)
				if eexQCmTqNFsMtgUGhDZ: NHhI5ScA2nVJy4E -= FM6uQWDAgjBsEdwCLzZitc83Vk
				BpbPWksZl1X659YOiILrANfJ = wwjDf5VntNemCKPqhkMXcgOp8EzrHY+NHhI5ScA2nVJy4E
				dAQ7mZePD8wBIEOK6jhRng5prG.text((BpbPWksZl1X659YOiILrANfJ,eayb8F07uk5xr1VpcvgEfICABHs),JHLkRVEQFA1WUwZPtD4Cyxr8,font=UUZJeH0cdFEf3wYL,fill=fexFWZs8GpgTNA)
				if HdsCcby3KpzStR7kgW4Ja2==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ੻"): dAQ7mZePD8wBIEOK6jhRng5prG.text((BpbPWksZl1X659YOiILrANfJ+wnaWTQM7VJPkZzO9eoSyFU4,eayb8F07uk5xr1VpcvgEfICABHs+wnaWTQM7VJPkZzO9eoSyFU4),JHLkRVEQFA1WUwZPtD4Cyxr8,font=UUZJeH0cdFEf3wYL,fill=fexFWZs8GpgTNA)
				if not eexQCmTqNFsMtgUGhDZ: NHhI5ScA2nVJy4E += FM6uQWDAgjBsEdwCLzZitc83Vk
				if eayb8F07uk5xr1VpcvgEfICABHs>OOnb7iIfgxZyBl+MeDAS81EXf9dqcBbW: break
	if HdsCcby3KpzStR7kgW4Ja2==IMjqygdfYSKpHlWu5Aa(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭੼"):
		Edvitzno2FfQNT8j3X1ybsPgSreY75 = g1KACutdS2E3ye7Y6aPz9.copy()
		x54xSdnCFHZ8yliofzOBK.sleep(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠳࠲࠵࠻ଏ"))
		Edvitzno2FfQNT8j3X1ybsPgSreY75.paste(vcmYi7eQFhMXrKButG64IobkRO2Waf,(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4),mask=Ml1qJ6wdWyLbYN07AzOr)
	else: Edvitzno2FfQNT8j3X1ybsPgSreY75 = Ml1qJ6wdWyLbYN07AzOr
	if YVzokG2yZqrh3w8bU: PqBvJHRnL1WDVUk72bhZFtOf = PqBvJHRnL1WDVUk72bhZFtOf.decode(e87cIA5vwOQLDEP1)
	try: Edvitzno2FfQNT8j3X1ybsPgSreY75.save(PqBvJHRnL1WDVUk72bhZFtOf)
	except UnicodeError:
		if YVzokG2yZqrh3w8bU:
			PqBvJHRnL1WDVUk72bhZFtOf = PqBvJHRnL1WDVUk72bhZFtOf.encode(e87cIA5vwOQLDEP1)
			Edvitzno2FfQNT8j3X1ybsPgSreY75.save(PqBvJHRnL1WDVUk72bhZFtOf)
	return w0eOlz5N6Cd74
def STqLgaMZPDwtKHIvju04pdAUhfEsr(PP8mEHuZw9OtkNDyXJe,UUZJeH0cdFEf3wYL,yDh3PlqVxB5ItwG,oQZJisuUROX7jI,MXqY2mfl4FczhAGHNnSwZRj1tgJ,htvGPw1AUCcHZkTxDNf):
	bL8Iy94RntscPK,s83qJU0yNEWcVMTuHdoFY5B,kk8ztnDlUR2qSpZrLgw9d45VH7Kh = WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4,iySORMYxWXszEH18(u"࠵࠺࠶࠰࠱ଐ")
	yDh3PlqVxB5ItwG = yDh3PlqVxB5ItwG.replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ੽"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ੾"))
	jxCN6qLRmatzU0ZGvcpOD7BAlPQ = MXqY2mfl4FczhAGHNnSwZRj1tgJ-oQZJisuUROX7jI*XURrDCfOS9Mbhpv2Pmjos56TeW
	for Bp1ZgVdMSejRhiGt in yDh3PlqVxB5ItwG.splitlines():
		s83qJU0yNEWcVMTuHdoFY5B += htvGPw1AUCcHZkTxDNf
		oo16cPFwSqG3enfIZXUMdJx,QQxhBRZjKyYoEFWvITen = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		for WNKF29qEvc5GHJ4YlR7dphM3ikBb8 in Bp1ZgVdMSejRhiGt.split(kcXMWrwiLDKeBHRsJ):
			kJdmt6buRc8Z4U2 = kve7y0iCMK8oHqdQOSJ9T(kcXMWrwiLDKeBHRsJ+WNKF29qEvc5GHJ4YlR7dphM3ikBb8)
			ouE4xhyb3pcs6NkreDwV0fLCM5,AcTvuZs4ri10YjzCX3 = PP8mEHuZw9OtkNDyXJe.textsize(kJdmt6buRc8Z4U2,font=UUZJeH0cdFEf3wYL)
			if oo16cPFwSqG3enfIZXUMdJx+ouE4xhyb3pcs6NkreDwV0fLCM5<jxCN6qLRmatzU0ZGvcpOD7BAlPQ:
				if not QQxhBRZjKyYoEFWvITen: QQxhBRZjKyYoEFWvITen += WNKF29qEvc5GHJ4YlR7dphM3ikBb8
				else: QQxhBRZjKyYoEFWvITen += kcXMWrwiLDKeBHRsJ+WNKF29qEvc5GHJ4YlR7dphM3ikBb8
				oo16cPFwSqG3enfIZXUMdJx += ouE4xhyb3pcs6NkreDwV0fLCM5
			else:
				if ouE4xhyb3pcs6NkreDwV0fLCM5<jxCN6qLRmatzU0ZGvcpOD7BAlPQ:
					QQxhBRZjKyYoEFWvITen += gPE1XB87fQl(u"࠭࡜࡯ࠢࠪ੿")+WNKF29qEvc5GHJ4YlR7dphM3ikBb8
					s83qJU0yNEWcVMTuHdoFY5B += htvGPw1AUCcHZkTxDNf
					oo16cPFwSqG3enfIZXUMdJx = ouE4xhyb3pcs6NkreDwV0fLCM5
				else:
					while ouE4xhyb3pcs6NkreDwV0fLCM5>jxCN6qLRmatzU0ZGvcpOD7BAlPQ:
						for pMiDdTC8LUE2wIV in range(wnaWTQM7VJPkZzO9eoSyFU4,len(kcXMWrwiLDKeBHRsJ+WNKF29qEvc5GHJ4YlR7dphM3ikBb8),wnaWTQM7VJPkZzO9eoSyFU4):
							NJBTYHFeAbZy = kcXMWrwiLDKeBHRsJ+WNKF29qEvc5GHJ4YlR7dphM3ikBb8[:pMiDdTC8LUE2wIV]
							OOrS40h9AbFWIdi86jtPXJDxUwf = WNKF29qEvc5GHJ4YlR7dphM3ikBb8[pMiDdTC8LUE2wIV:]
							UWeDRhlZQKonT = kve7y0iCMK8oHqdQOSJ9T(NJBTYHFeAbZy)
							x0FroAOgdELH6BpMKShQNlG2bIZJmt,PN1wVftrcsimBx3u2akJXhZ9 = PP8mEHuZw9OtkNDyXJe.textsize(UWeDRhlZQKonT,font=UUZJeH0cdFEf3wYL)
							if oo16cPFwSqG3enfIZXUMdJx+x0FroAOgdELH6BpMKShQNlG2bIZJmt>jxCN6qLRmatzU0ZGvcpOD7BAlPQ:
								zFGmiKse7V = ouE4xhyb3pcs6NkreDwV0fLCM5-x0FroAOgdELH6BpMKShQNlG2bIZJmt
								QQxhBRZjKyYoEFWvITen += NJBTYHFeAbZy+WBDnh75CaLEvkcN6p4ez2KXrV3M
								s83qJU0yNEWcVMTuHdoFY5B += htvGPw1AUCcHZkTxDNf
								ouE4xhyb3pcs6NkreDwV0fLCM5 = zFGmiKse7V
								if zFGmiKse7V>jxCN6qLRmatzU0ZGvcpOD7BAlPQ:
									oo16cPFwSqG3enfIZXUMdJx = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
									WNKF29qEvc5GHJ4YlR7dphM3ikBb8 = OOrS40h9AbFWIdi86jtPXJDxUwf
								else:
									oo16cPFwSqG3enfIZXUMdJx = zFGmiKse7V
									QQxhBRZjKyYoEFWvITen += OOrS40h9AbFWIdi86jtPXJDxUwf
								break
				if s83qJU0yNEWcVMTuHdoFY5B>kk8ztnDlUR2qSpZrLgw9d45VH7Kh: break
		bL8Iy94RntscPK += WBDnh75CaLEvkcN6p4ez2KXrV3M+QQxhBRZjKyYoEFWvITen
		if s83qJU0yNEWcVMTuHdoFY5B>kk8ztnDlUR2qSpZrLgw9d45VH7Kh: break
	bL8Iy94RntscPK = bL8Iy94RntscPK[wnaWTQM7VJPkZzO9eoSyFU4:]
	bL8Iy94RntscPK = bL8Iy94RntscPK.replace(rVy3Ops0mohYkT(u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ઀"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩઁ"))
	return bL8Iy94RntscPK
def kve7y0iCMK8oHqdQOSJ9T(WNKF29qEvc5GHJ4YlR7dphM3ikBb8):
	if GHg28TBchiyn6l(u"ࠩ࡞ࠫં") in WNKF29qEvc5GHJ4YlR7dphM3ikBb8 and lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡡࠬઃ") in WNKF29qEvc5GHJ4YlR7dphM3ikBb8:
		L5z7u8ygrwpT = [YVr6St5P4xsFC0aARQGKfiegD,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ઄"),YYQS36fyPvtuzcEmRL(u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭અ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨઆ"),mq5t9JXSdHT8yfDVF(u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪઇ"),A41nqbj3wYt(u"ࠨ࡝ࡕࡘࡑࡣࠧઈ"),A6iX18qgyOFlZxz7sc(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩઉ"),CyHU86ZeYT5BWRcitSm2I(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫઊ"),IMjqygdfYSKpHlWu5Aa(u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭ઋ")]
		imUhAFEjL63HRdl1J = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬઌ"),WNKF29qEvc5GHJ4YlR7dphM3ikBb8,p7dwlH1PRStBgyMUW.DOTALL)
		kGHKwPEDdnjrBQ2LegVqWzaNfCS98Y = p7dwlH1PRStBgyMUW.findall(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨઍ"),WNKF29qEvc5GHJ4YlR7dphM3ikBb8,p7dwlH1PRStBgyMUW.DOTALL)
		VJQzox2NXuMcjwTYpbFK69i4yl8Zms = L5z7u8ygrwpT+imUhAFEjL63HRdl1J+kGHKwPEDdnjrBQ2LegVqWzaNfCS98Y
		for WBUefDkT0FzSVKZc in VJQzox2NXuMcjwTYpbFK69i4yl8Zms: WNKF29qEvc5GHJ4YlR7dphM3ikBb8 = WNKF29qEvc5GHJ4YlR7dphM3ikBb8.replace(WBUefDkT0FzSVKZc,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	return WNKF29qEvc5GHJ4YlR7dphM3ikBb8
def i4BT3GAO8KpXQrPU70bdxavVnL(ZVk6IphECKLzUceP15j):
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ઎"))
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(CyHU86ZeYT5BWRcitSm2I(u"ࠨ࡝ࡕࡘࡑࡣࠧએ"),IMjqygdfYSKpHlWu5Aa(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪઐ"))
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪઑ"),A41nqbj3wYt(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭઒"))
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭ઓ"),IMjqygdfYSKpHlWu5Aa(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩઔ"))
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(pp7FcjEe6g(u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩક"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬખ"))
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(YVr6St5P4xsFC0aARQGKfiegD,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫગ"))
	Tu8KmXIO2W7sL = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬઘ"),ZVk6IphECKLzUceP15j,p7dwlH1PRStBgyMUW.DOTALL)
	for S6r0tc3WOCVpxfb8oYXUeImDvilAqy in Tu8KmXIO2W7sL: ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(mq5t9JXSdHT8yfDVF(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬઙ")+S6r0tc3WOCVpxfb8oYXUeImDvilAqy+SI7eBdND4lx8pt5Qk(u"ࠬࡣࠧચ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧછ")+S6r0tc3WOCVpxfb8oYXUeImDvilAqy+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡠࠩજ"))
	return ZVk6IphECKLzUceP15j