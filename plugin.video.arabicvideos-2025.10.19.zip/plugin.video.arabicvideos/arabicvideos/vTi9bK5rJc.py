# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'SERIES4WATCH'
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_SFW_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==210: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==211: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	elif mode==212: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==213: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==214: APpdhB1Fk58MmJH7CjVntowyaY = EZ9sFwt2lnRWif8p5JxXDNI(url)
	elif mode==215: APpdhB1Fk58MmJH7CjVntowyaY = m3Kfu2bTsMXN8Bxqz5DYeLWE(url)
	elif mode==218: APpdhB1Fk58MmJH7CjVntowyaY = Z3KNl01JFaAjT5nkbXfh()
	elif mode==219: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def Z3KNl01JFaAjT5nkbXfh():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'الموقع تغير بالكامل',message)
	return
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,219,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	url = pcE6DxaoHBm41WKXjwnk+'/getpostsPin?type=one&data=pin&limit=25'
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',url,211)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('FiltersButtons(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('data-get="(.*?)".*?</i>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		url = pcE6DxaoHBm41WKXjwnk+'/getposts?type=one&data='+SOw5EUxC9k
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,211)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('navigation-menu(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(http.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	EViWBhSw3dea8pTUO9AFMKbGjks027 = ['مسلسلات انمي','الرئيسية']
	for SOw5EUxC9k,title in items:
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if not any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,211)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('MediaGrid"(.*?)class="pagination"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		else: return
	items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	SnBhkFA2Z3gNVWJlz1ypa = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		if '/series/' in SOw5EUxC9k: continue
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k).strip('/')
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if '/film/' in SOw5EUxC9k or any(value in title for value in SnBhkFA2Z3gNVWJlz1ypa):
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,212,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/episode/' in SOw5EUxC9k and 'الحلقة' in title:
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if er96jwp52cbvaV48mtylEYSRz:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,213,J4tO21KYAVdSr67W5NmiD0XhRP)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,213,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			title = title.replace('الصفحة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,211)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	rTxhwZLNYv3sKHIe6iVJ0bzURf,items,XXH8bCAt1NG = -1,[],[]
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-EPISODES-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('ti-list-numbered(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = WnNGfosHr5STAq8j7miwyRZ6eOUbV.join(cKUQVwTMe9tZSY)
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',UOqp25uxcISGBPlAfbtzCNWXY4nvK,p7dwlH1PRStBgyMUW.DOTALL)
	items.append(url)
	items = set(items)
	for SOw5EUxC9k in items:
		SOw5EUxC9k = SOw5EUxC9k.strip('/')
		title = '_MOD_' + SOw5EUxC9k.split('/')[-1].replace('-',kcXMWrwiLDKeBHRsJ)
		uOFd6U75e4ZnqADYk8j9 = p7dwlH1PRStBgyMUW.findall('الحلقة-(\d+)',SOw5EUxC9k.split('/')[-1],p7dwlH1PRStBgyMUW.DOTALL)
		if uOFd6U75e4ZnqADYk8j9: uOFd6U75e4ZnqADYk8j9 = uOFd6U75e4ZnqADYk8j9[0]
		else: uOFd6U75e4ZnqADYk8j9 = '0'
		XXH8bCAt1NG.append([SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9])
	items = sorted(XXH8bCAt1NG, reverse=False, key=lambda key: int(key[2]))
	xsWGniMyCw9USZ4z1dVprIXRL = str(items).count('/season/')
	rTxhwZLNYv3sKHIe6iVJ0bzURf = str(items).count('/episode/')
	if xsWGniMyCw9USZ4z1dVprIXRL>1 and rTxhwZLNYv3sKHIe6iVJ0bzURf>0 and '/season/' not in url:
		for SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9 in items:
			if '/season/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,213)
	else:
		for SOw5EUxC9k,title,uOFd6U75e4ZnqADYk8j9 in items:
			if '/season/' not in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,212)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u = []
	ipdI4Kw1lMauxrtYoh = url.split('/')
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in piN9Qlah4S:
		vcQbFfCk6T1 = url.replace(ipdI4Kw1lMauxrtYoh[3],'watch')
		hFYoSTas7WOVnwN = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-PLAY-2nd')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="servers-list(.*?)</div>',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if items:
				id = p7dwlH1PRStBgyMUW.findall('post_id=(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
				if id:
					MXZvtCRTuhcs6VN1K0LOwWDF = id[0]
					for SOw5EUxC9k,title in items:
						SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/?postid='+MXZvtCRTuhcs6VN1K0LOwWDF+'&serverid='+SOw5EUxC9k+'?named='+title+'__watch'
						M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			else:
				items = p7dwlH1PRStBgyMUW.findall('data-embedd=".*?(http.*?)("|&quot;)',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for SOw5EUxC9k,PN2AmVoTyks5xOR1Ib9BqSQ in items:
					M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	if '/download/' in piN9Qlah4S:
		vcQbFfCk6T1 = url.replace(ipdI4Kw1lMauxrtYoh[3],'download')
		hFYoSTas7WOVnwN = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-PLAY-3rd')
		id = p7dwlH1PRStBgyMUW.findall('postId:"(.*?)"',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if id:
			MXZvtCRTuhcs6VN1K0LOwWDF = id[0]
			W67hPCcaOek094 = { 'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV , 'X-Requested-With':'XMLHttpRequest' }
			vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk + '/ajaxCenter?_action=getdownloadlinks&postId='+MXZvtCRTuhcs6VN1K0LOwWDF
			hFYoSTas7WOVnwN = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'SERIES4WATCH-PLAY-4th')
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<h3.*?(\d+)(.*?)</div>',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
			if cKUQVwTMe9tZSY:
				for Q4Qf3IEBzPM08H,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
					items = p7dwlH1PRStBgyMUW.findall('<td>(.*?)<.*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
					for name,SOw5EUxC9k in items:
						M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k+'?named='+name+'__download'+'____'+Q4Qf3IEBzPM08H)
			else:
				cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<h6(.*?)</table>',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
				if not cKUQVwTMe9tZSY: cKUQVwTMe9tZSY = [hFYoSTas7WOVnwN]
				for KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
					name = WnNGfosHr5STAq8j7miwyRZ6eOUbV
					items = p7dwlH1PRStBgyMUW.findall('href="(http.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
					for SOw5EUxC9k in items:
						VVpQfHc7IZamxweON3WXKU6Fg = '&&' + SOw5EUxC9k.split('/')[2].lower() + '&&'
						VVpQfHc7IZamxweON3WXKU6Fg = VVpQfHc7IZamxweON3WXKU6Fg.replace('.com&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('.co&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						VVpQfHc7IZamxweON3WXKU6Fg = VVpQfHc7IZamxweON3WXKU6Fg.replace('.net&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('.org&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						VVpQfHc7IZamxweON3WXKU6Fg = VVpQfHc7IZamxweON3WXKU6Fg.replace('.live&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('.online&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						VVpQfHc7IZamxweON3WXKU6Fg = VVpQfHc7IZamxweON3WXKU6Fg.replace('&&hd.',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('&&www.',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						VVpQfHc7IZamxweON3WXKU6Fg = VVpQfHc7IZamxweON3WXKU6Fg.replace('&&',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						SOw5EUxC9k = SOw5EUxC9k + '?named=' + name + VVpQfHc7IZamxweON3WXKU6Fg + '__download'
						M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk + '/search?s='+search
	ctDj2OVRyaUPXCrITmJG(url)
	return