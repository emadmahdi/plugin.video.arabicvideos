# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from tBopO810Wx import *
from yBR5QHGdUT import *
import base64 as uvGCPpFwVmTQ36
NTWE764hmOgUtScp2e8r = CyHU86ZeYT5BWRcitSm2I(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐ༵ࠩ")
if rJ2oTLqabRtA:
	sVeEnGfl8B = zdlKPScakxtwGuqZVAD8TmpW6Re.translatePath(ZLr5gRSkFewKdUos90bM(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ༶"))
	zZoDegnE91Nw = zdlKPScakxtwGuqZVAD8TmpW6Re.translatePath(gPE1XB87fQl(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮༷ࠧ"))
	O3yquo9YEKRTF7LDWfAdpc1wshl6 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,wwWzyF4ZpSQXKOgk569(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭༸"),YYQS36fyPvtuzcEmRL(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫༹ࠧ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ༺"))
	jlD4q9bI0xyJ1 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ༻"),beV5l2D8HznyJI0(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ༼"),pp7FcjEe6g(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ༽"))
	G0s8oq5pVu4ajzeEt7MbQ1CmOZIiJk = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,YYQS36fyPvtuzcEmRL(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ༾"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭༿"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬཀ"))
	from urllib.parse import quote as _ouW8XfBxY2U1OPipEynz5
else:
	sVeEnGfl8B = pYDdXfVh5c0O1bMT6a78HKBiQw3.translatePath(mq5t9JXSdHT8yfDVF(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧཁ"))
	zZoDegnE91Nw = pYDdXfVh5c0O1bMT6a78HKBiQw3.translatePath(Z9FPQvwlbjLTh(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫག"))
	O3yquo9YEKRTF7LDWfAdpc1wshl6 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,oiWNFYzcIUeh(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪགྷ"),beV5l2D8HznyJI0(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫང"),kdRO82AImh0LFw(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨཅ"))
	jlD4q9bI0xyJ1 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,pp7FcjEe6g(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ཆ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧཇ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭཈"))
	G0s8oq5pVu4ajzeEt7MbQ1CmOZIiJk = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,oiWNFYzcIUeh(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩཉ"),yobpaW7sBqtKRrv(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪཊ"),KLX7hW0nBAEgy6m4SvH(u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩཋ"))
	from urllib import quote as _ouW8XfBxY2U1OPipEynz5
QqA6tL3TolUrzJf05MkR = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(zZoDegnE91Nw,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬཌ"))
WZhFwntTd5NULaqQpo = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(zZoDegnE91Nw,kdRO82AImh0LFw(u"ࠫࡰࡵࡤࡪ࠰ࡲࡰࡩ࠴࡬ࡰࡩࠪཌྷ"))
IAz7jaYKpBx592rLDEZFlOgsST = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,SI7eBdND4lx8pt5Qk(u"ࠬ࡯ࡰࡵࡸ࠴ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧཎ"))
D7YNmfTjSnq1a0V2EvwAFp = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,iySORMYxWXszEH18(u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨཏ"))
llfHbydxvRQImu1LJSFUaZDCB = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,gPE1XB87fQl(u"ࠧ࡮࠵ࡸࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧཐ"))
C6MhN2TeZ83GDFngway7EvBYom5i = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,SI7eBdND4lx8pt5Qk(u"ࠨࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷ࠳ࡪࡡࡵࠩད"))
Q3QtWFwqHp0mAVkJXguPb7LZSKcNzO = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,GHg28TBchiyn6l(u"ࠩ࡬ࡴࡹࡼࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫདྷ"))
hGpEfVsnObLXd1CH = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡱ࠸ࡻࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫན"))
onqFZm4wtfK3irV = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭པ"))
TWPbCIFGD6wfBVULu = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,IMjqygdfYSKpHlWu5Aa(u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨཕ"))
wwb79qgFjrKyxWMP = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,wwWzyF4ZpSQXKOgk569(u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪབ"))
oxTWqaNpAi9PgKe = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,IMjqygdfYSKpHlWu5Aa(u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫབྷ"))
GT06ldJHMnz = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,beV5l2D8HznyJI0(u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨམ"))
LAkMnCdNWEQS8YzvUPKam = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,ZLr5gRSkFewKdUos90bM(u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭ཙ"))
EfO8MJ3I0dlpmckQhYaPq5 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,A6iX18qgyOFlZxz7sc(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪཚ"))
uXR5iKdvn7JA2a = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪཛ"))
O846ER20IJA9fQYyBTpokUvGwMjn = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,CyHU86ZeYT5BWRcitSm2I(u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬཛྷ"))
uxKbUolc0WrM57w = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,ZLr5gRSkFewKdUos90bM(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ཝ"))
KPD9xuyrERgaOFCVUAmWZo3IX = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,KLX7hW0nBAEgy6m4SvH(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩཞ"),CyHU86ZeYT5BWRcitSm2I(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬཟ"),B40Qr5hlSgNm1kuXD3ZFpnyC9)
MFlX6x0hzm = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(KPD9xuyrERgaOFCVUAmWZo3IX,pp7FcjEe6g(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨའ"))
LLisqvRTgbMS15NuQKJEU = set(A3pXVFdyP1.BADWEBSITES)
m06yjkDU4wEipZ7QWrsLdfKbn = [N6NV3h4fel for N6NV3h4fel in m06yjkDU4wEipZ7QWrsLdfKbn if N6NV3h4fel not in LLisqvRTgbMS15NuQKJEU]
FFonu8kDwYm2vHdAgfjS7zyMb5q = [N6NV3h4fel for N6NV3h4fel in FFonu8kDwYm2vHdAgfjS7zyMb5q if N6NV3h4fel not in LLisqvRTgbMS15NuQKJEU]
bcuvN3jdY2gWDy09HAnf = [N6NV3h4fel for N6NV3h4fel in bcuvN3jdY2gWDy09HAnf if N6NV3h4fel not in LLisqvRTgbMS15NuQKJEU]
JphriA3aDH61YFCbXsBvTmdx = [N6NV3h4fel for N6NV3h4fel in JphriA3aDH61YFCbXsBvTmdx if N6NV3h4fel not in LLisqvRTgbMS15NuQKJEU]
zeqfF87Dt1U0VcNvslxnX4CTIkh9Mr = [N6NV3h4fel for N6NV3h4fel in zeqfF87Dt1U0VcNvslxnX4CTIkh9Mr if N6NV3h4fel not in LLisqvRTgbMS15NuQKJEU]
class ouEV7ZMghRakP24():
	def __init__(EfRyYmGtnvCrDeI5iV4Hx9S3,showDialogs=KiryBCvngZzF85UN6xSDlOVweL4I9,logErrors=r0D4C3z7Onqpa):
		EfRyYmGtnvCrDeI5iV4Hx9S3.showDialogs = showDialogs
		EfRyYmGtnvCrDeI5iV4Hx9S3.logErrors = logErrors
		EfRyYmGtnvCrDeI5iV4Hx9S3.finishedLIST,EfRyYmGtnvCrDeI5iV4Hx9S3.failedLIST = [],[]
		EfRyYmGtnvCrDeI5iV4Hx9S3.statusDICT,EfRyYmGtnvCrDeI5iV4Hx9S3.resultsDICT = {},{}
		EfRyYmGtnvCrDeI5iV4Hx9S3.processesLIST = []
		EfRyYmGtnvCrDeI5iV4Hx9S3.starttimeDICT,EfRyYmGtnvCrDeI5iV4Hx9S3.finishtimeDICT,EfRyYmGtnvCrDeI5iV4Hx9S3.elpasedtimeDICT = {},{},{}
	def d7ViqDHmpxfQ3OFaJe(EfRyYmGtnvCrDeI5iV4Hx9S3,m5XtY37nVSIb2,aEr81v2kP5DnQAWsYgdptoizIcKLH,*aargs):
		m5XtY37nVSIb2 = str(m5XtY37nVSIb2)
		EfRyYmGtnvCrDeI5iV4Hx9S3.statusDICT[m5XtY37nVSIb2] = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫཡ")
		if EfRyYmGtnvCrDeI5iV4Hx9S3.showDialogs: uTaiRMI8eYmN(WnNGfosHr5STAq8j7miwyRZ6eOUbV,m5XtY37nVSIb2)
		Qja7l4ygF8fmBruVW32bNRZIU = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=EfRyYmGtnvCrDeI5iV4Hx9S3.d24qThgIE8kV,args=(m5XtY37nVSIb2,aEr81v2kP5DnQAWsYgdptoizIcKLH,aargs))
		EfRyYmGtnvCrDeI5iV4Hx9S3.processesLIST.append(Qja7l4ygF8fmBruVW32bNRZIU)
		return Qja7l4ygF8fmBruVW32bNRZIU
	def b8nwpCGfrTHFm(EfRyYmGtnvCrDeI5iV4Hx9S3,m5XtY37nVSIb2,aEr81v2kP5DnQAWsYgdptoizIcKLH,*aargs):
		Qja7l4ygF8fmBruVW32bNRZIU = EfRyYmGtnvCrDeI5iV4Hx9S3.d7ViqDHmpxfQ3OFaJe(m5XtY37nVSIb2,aEr81v2kP5DnQAWsYgdptoizIcKLH,*aargs)
		Qja7l4ygF8fmBruVW32bNRZIU.start()
	def d24qThgIE8kV(EfRyYmGtnvCrDeI5iV4Hx9S3,m5XtY37nVSIb2,aEr81v2kP5DnQAWsYgdptoizIcKLH,aargs):
		m5XtY37nVSIb2 = str(m5XtY37nVSIb2)
		EfRyYmGtnvCrDeI5iV4Hx9S3.starttimeDICT[m5XtY37nVSIb2] = x54xSdnCFHZ8yliofzOBK.time()
		try:
			EfRyYmGtnvCrDeI5iV4Hx9S3.resultsDICT[m5XtY37nVSIb2] = aEr81v2kP5DnQAWsYgdptoizIcKLH(*aargs)
			if A41nqbj3wYt(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬར") in str(aEr81v2kP5DnQAWsYgdptoizIcKLH) and not EfRyYmGtnvCrDeI5iV4Hx9S3.resultsDICT[m5XtY37nVSIb2].succeeded: sm0xF8WoGavE7iNjd()
			EfRyYmGtnvCrDeI5iV4Hx9S3.finishedLIST.append(m5XtY37nVSIb2)
			EfRyYmGtnvCrDeI5iV4Hx9S3.statusDICT[m5XtY37nVSIb2] = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧལ")
		except Exception as YIrltJES6aPjnm94qTuoMiORKpDA0:
			if EfRyYmGtnvCrDeI5iV4Hx9S3.logErrors:
				C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
				if C2nN35DILUFzEKqv0BPl4eZjH6!=A6iX18qgyOFlZxz7sc(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩཤ"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
			EfRyYmGtnvCrDeI5iV4Hx9S3.failedLIST.append(m5XtY37nVSIb2)
			EfRyYmGtnvCrDeI5iV4Hx9S3.statusDICT[m5XtY37nVSIb2] = oiWNFYzcIUeh(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧཥ")
		EfRyYmGtnvCrDeI5iV4Hx9S3.finishtimeDICT[m5XtY37nVSIb2] = x54xSdnCFHZ8yliofzOBK.time()
		EfRyYmGtnvCrDeI5iV4Hx9S3.elpasedtimeDICT[m5XtY37nVSIb2] = EfRyYmGtnvCrDeI5iV4Hx9S3.finishtimeDICT[m5XtY37nVSIb2] - EfRyYmGtnvCrDeI5iV4Hx9S3.starttimeDICT[m5XtY37nVSIb2]
	def vLyghNQioJMK(EfRyYmGtnvCrDeI5iV4Hx9S3):
		for XEvAtqN1iJ0erTjC65IcdBLm in EfRyYmGtnvCrDeI5iV4Hx9S3.processesLIST:
			XEvAtqN1iJ0erTjC65IcdBLm.start()
	def tTOlrFioz7KHs(EfRyYmGtnvCrDeI5iV4Hx9S3):
		while KLX7hW0nBAEgy6m4SvH(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩས") in list(EfRyYmGtnvCrDeI5iV4Hx9S3.statusDICT.values()): x54xSdnCFHZ8yliofzOBK.sleep(mq5t9JXSdHT8yfDVF(u"࠷ᕽ"))
def dSHkueh1iU6EtRQ5ADFr30sm():
	if not dJ3lKeg21CuqpwSEhQYPmDV: return pp7FcjEe6g(u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬཧ")
	v1SuhAKBGMnOsZJwECVjk = SI7eBdND4lx8pt5Qk(u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨཨ")
	RVgmnkvIlTdre9cLzKxW6H0CGS = [IMjqygdfYSKpHlWu5Aa(u"ࠫ࠽࠴࠵࠯࠲ࠪཀྵ"),tzZ6PhyDOUnwLM3pdK(u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩཪ"),mq5t9JXSdHT8yfDVF(u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫཫ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫཬ"),kdRO82AImh0LFw(u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ཭"),VP70ytiFNMBl6vHDaW(u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭཮"),pp7FcjEe6g(u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ཯"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ཰"),VP70ytiFNMBl6vHDaW(u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ཱࠩ"),SI7eBdND4lx8pt5Qk(u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ིࠪ"),VP70ytiFNMBl6vHDaW(u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ཱིࠫ"),ZLr5gRSkFewKdUos90bM(u"ࠨ࠴࠳࠶࠹࠴࠰࠸࠰࠵࠴ུࠬ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࠵࠴࠷࠻࠮࠱࠷࠱࠴࠺ཱུ࠭")]
	Dy40Ti3RvmEJoxwt6KacYPu1Uh = RVgmnkvIlTdre9cLzKxW6H0CGS[-wnaWTQM7VJPkZzO9eoSyFU4]
	j2x8o4LEVJ6ZT = ntRMkXUgfrBja(Dy40Ti3RvmEJoxwt6KacYPu1Uh)
	KQLwpC7MUmXxY4Tvs1lIdrgjq08iV = ntRMkXUgfrBja(mbvW9By35UDO)
	if KQLwpC7MUmXxY4Tvs1lIdrgjq08iV>j2x8o4LEVJ6ZT:
		v1SuhAKBGMnOsZJwECVjk = beV5l2D8HznyJI0(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪྲྀ")
	return v1SuhAKBGMnOsZJwECVjk
def yngExXLFuWw4(lgB7TOZqEJiMUFedrSHX8j6):
	QV7bdEIMWwT0lK5JZHGa,n2PbH9gJrm7I5SAOaRz3Q0eMXVD = WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9
	if lgB7TOZqEJiMUFedrSHX8j6: QV7bdEIMWwT0lK5JZHGa = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,yobpaW7sBqtKRrv(u"ࠫࡸࡺࡲࠨཷ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪླྀ"),iySORMYxWXszEH18(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨཹ"))
	if not QV7bdEIMWwT0lK5JZHGa:
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA = A3pXVFdyP1.SITESURLS[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡑ࡛ࡗࡌࡔࡔེࠧ")][XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠹ᕾ")]
		hBkVcq0AG3MJpaE58Q = {kdRO82AImh0LFw(u"ࠨࡷࡶࡩࡷཻ࠭"):A3pXVFdyP1.AV_CLIENT_IDS,pp7FcjEe6g(u"ࠩࡹࡩࡷࡹࡩࡰࡰོࠪ"):mbvW9By35UDO}
		QV7bdEIMWwT0lK5JZHGa = lCyIgTpZ8WJHdk9iPBLUD(beV5l2D8HznyJI0(u"ࠪࡔࡔ࡙ࡔࠨཽ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,hBkVcq0AG3MJpaE58Q,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡣࡕ࡟ࡔࡉࡑࡑࡣࡈࡕࡄࡆ࠯࠴ࡷࡹ࠭ཾ"))
		JIpyGT2ZQ9lqoDinAB(A3pXVFdyP1.api_python_actions[bawK2j7T81Nrc4GWs05xzDg(u"࠺ᕿ")])
		if QV7bdEIMWwT0lK5JZHGa: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,IMjqygdfYSKpHlWu5Aa(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪཿ"),VP70ytiFNMBl6vHDaW(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨྀ"),QV7bdEIMWwT0lK5JZHGa,iXBqSkDU3mRCZf4Ib)
		n2PbH9gJrm7I5SAOaRz3Q0eMXVD = r0D4C3z7Onqpa
	if QV7bdEIMWwT0lK5JZHGa:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
		exec(QV7bdEIMWwT0lK5JZHGa,globals(),locals())
		A3pXVFdyP1.SITESURLS.update(NEW_SITESURLS)
		A3pXVFdyP1.BADSCRAPERS = list(set(A3pXVFdyP1.BADSCRAPERS+NEW_BADSCRAPERS))
		A3pXVFdyP1.BADCOMMONIDS = list(set(A3pXVFdyP1.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if mbvW9By35UDO in list(NEW_BADWEBSITES.keys()): A3pXVFdyP1.BADWEBSITES += NEW_BADWEBSITES[mbvW9By35UDO]
	return n2PbH9gJrm7I5SAOaRz3Q0eMXVD
def oyQBDdCApsgqwT():
	try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.makedirs(kcCgDi2EzhU5s413pAjSmu)
	except: pass
	z6x4KvZQgNmIuFWbhly2UiCHE8O91J = dSHkueh1iU6EtRQ5ADFr30sm()
	if z6x4KvZQgNmIuFWbhly2UiCHE8O91J==oiWNFYzcIUeh(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋཱྀࠧ"): SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,KLX7hW0nBAEgy6m4SvH(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧྂ")+oobgjl3xWaBeRZF8wdzKYAvtus+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠣࡡࠬྃ"))
	else: SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,beV5l2D8HznyJI0(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤࠥࡌࡕࡍࡎ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠ྄ࠦࠧ")+oobgjl3xWaBeRZF8wdzKYAvtus+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࠥࡣࠧ྅"))
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬ྆")+mbvW9By35UDO)
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ྇"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬྈ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,CyHU86ZeYT5BWRcitSm2I(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭ྉ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬྊ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨྋ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,IMjqygdfYSKpHlWu5Aa(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧྌ"),CyHU86ZeYT5BWRcitSm2I(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪྍ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,KLX7hW0nBAEgy6m4SvH(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩྎ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭ྏ"))
	G3yDpvxOiSWdAeL.setSetting(yobpaW7sBqtKRrv(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨྐ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫྑ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(YYQS36fyPvtuzcEmRL(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ྒ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(mq5t9JXSdHT8yfDVF(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧྒྷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨྔ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(SI7eBdND4lx8pt5Qk(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨྕ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬྖ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(Z9FPQvwlbjLTh(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨྗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(rVy3Ops0mohYkT(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭྘"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫྙ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting(bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ྚ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,YYQS36fyPvtuzcEmRL(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ྛ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ྜ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,oiWNFYzcIUeh(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ྜྷ"))
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪྞ"))
	XJNduZp9YOfjAB2(KiryBCvngZzF85UN6xSDlOVweL4I9)
	PzLX0Jg7lIERk1WAeUKQNZV2Bwc(XAGWNdKH4qOPU1YEVQp6)
	import GkCs6wbiQP
	GkCs6wbiQP.MuryTcfZxnmGwIFUSa104E(iySORMYxWXszEH18(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩྟ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	GkCs6wbiQP.MuryTcfZxnmGwIFUSa104E(wwWzyF4ZpSQXKOgk569(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ྠ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	GkCs6wbiQP.MuryTcfZxnmGwIFUSa104E(GHg28TBchiyn6l(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡩࡪࡲࡶࡥࡨࡦ࡬ࡶࡪࡩࡴࠨྡ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	GkCs6wbiQP.pBw9TxneIRC8(r0D4C3z7Onqpa)
	GkCs6wbiQP.KXml86H1bJpk9TML3idjaRUzcot7(KiryBCvngZzF85UN6xSDlOVweL4I9)
	if z6x4KvZQgNmIuFWbhly2UiCHE8O91J==beV5l2D8HznyJI0(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬྡྷ"):
		bQpsh4PIEHVodD5kWj7mXaRFe(r0D4C3z7Onqpa,[p9DTgUZ1auwRYXoHld7v8MP])
	else:
		bQpsh4PIEHVodD5kWj7mXaRFe(KiryBCvngZzF85UN6xSDlOVweL4I9,[])
		GkCs6wbiQP.tUbhlG5V9MqwWayB02o3JZADevm()
		try:
			X2OVeWfmglkE5RZ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,yobpaW7sBqtKRrv(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྣ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྤ"),oiWNFYzcIUeh(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬྥ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྦ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ = EipS2x5YfXdk96whaUNj.Addon(id=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧྦྷ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ.setSetting(VP70ytiFNMBl6vHDaW(u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪྨ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡌࡡ࡭ࡵࡨࠫྩ"))
		except: pass
		try:
			X2OVeWfmglkE5RZ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,gPE1XB87fQl(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྪ"),beV5l2D8HznyJI0(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྫ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨྫྷ"),rVy3Ops0mohYkT(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྭ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ = EipS2x5YfXdk96whaUNj.Addon(id=n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪྮ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ.setSetting(YYQS36fyPvtuzcEmRL(u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧྯ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࠹ࠧྰ"))
		except: pass
		try:
			X2OVeWfmglkE5RZ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྱ"),KLX7hW0nBAEgy6m4SvH(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྲ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨླ"),CyHU86ZeYT5BWRcitSm2I(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྴ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ = EipS2x5YfXdk96whaUNj.Addon(id=SI7eBdND4lx8pt5Qk(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪྵ"))
			xXigF7CJLNrWUEHy4ZazSAcP51jQ.setSetting(CyHU86ZeYT5BWRcitSm2I(u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩྶ"),rVy3Ops0mohYkT(u"ࠬ࠸ࠧྷ"))
		except: pass
	N4HDrYcWePfI0yxjb2 = QSXjgqyaVxPL4(UUN4I9unSKWg7c3YizxEmq)
	N4HDrYcWePfI0yxjb2 = QSXjgqyaVxPL4(C6MhN2TeZ83GDFngway7EvBYom5i)
	GkCs6wbiQP.w61naW3ET4JCRK8YGHMZxVqbi9tzy(KiryBCvngZzF85UN6xSDlOVweL4I9)
	G3yDpvxOiSWdAeL.setSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪྸ"),mbvW9By35UDO)
	YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def sPcH8StFImxrQwk(Dj0qYc573K2aQ):
	n2PbH9gJrm7I5SAOaRz3Q0eMXVD = yngExXLFuWw4(r0D4C3z7Onqpa)
	if n2PbH9gJrm7I5SAOaRz3Q0eMXVD:
		return
	yyF7zq1u3CpVvgnXQ = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬྐྵ")))
	yyF7zq1u3CpVvgnXQ = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not yyF7zq1u3CpVvgnXQ else int(yyF7zq1u3CpVvgnXQ)
	if not yyF7zq1u3CpVvgnXQ or not j0jEZgiKdxFpMLHcU7kQr8v1lyX4<=jDuxzCtBH7aihsSL9-yyF7zq1u3CpVvgnXQ<=OQaHUGCW62hp8tFbgM:
		G3yDpvxOiSWdAeL.setSetting(Z9FPQvwlbjLTh(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭ྺ"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
		PzLX0Jg7lIERk1WAeUKQNZV2Bwc(XAGWNdKH4qOPU1YEVQp6)
		return
	pUL3DejE4W5K = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫྻ")))
	pUL3DejE4W5K = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not pUL3DejE4W5K else int(pUL3DejE4W5K)
	opraNyQcGsF = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(wwWzyF4ZpSQXKOgk569(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬྼ")))
	opraNyQcGsF = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not opraNyQcGsF else int(opraNyQcGsF)
	if not pUL3DejE4W5K or not opraNyQcGsF or not j0jEZgiKdxFpMLHcU7kQr8v1lyX4<=jDuxzCtBH7aihsSL9-opraNyQcGsF<=pUL3DejE4W5K:
		B4E2DFJzoY1LHbWSaKfGmQAOs7(r0D4C3z7Onqpa,pUL3DejE4W5K)
		return
	NXVbet3K1hFEMBfSLcZD2WrgmIwn = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(Z9FPQvwlbjLTh(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫ྽")))
	NXVbet3K1hFEMBfSLcZD2WrgmIwn = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not NXVbet3K1hFEMBfSLcZD2WrgmIwn else int(NXVbet3K1hFEMBfSLcZD2WrgmIwn)
	if not NXVbet3K1hFEMBfSLcZD2WrgmIwn or not j0jEZgiKdxFpMLHcU7kQr8v1lyX4<=jDuxzCtBH7aihsSL9-NXVbet3K1hFEMBfSLcZD2WrgmIwn<=nsFAzS2wvjyTYLOdDhfIiC0KGHE:
		G3yDpvxOiSWdAeL.setSetting(VP70ytiFNMBl6vHDaW(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬ྾"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
		yngExXLFuWw4(KiryBCvngZzF85UN6xSDlOVweL4I9)
		return
	if KiryBCvngZzF85UN6xSDlOVweL4I9:
		R4x71sj2ckY = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(VP70ytiFNMBl6vHDaW(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ྿")))
		R4x71sj2ckY = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not R4x71sj2ckY else int(R4x71sj2ckY)
		if not R4x71sj2ckY or not j0jEZgiKdxFpMLHcU7kQr8v1lyX4<=jDuxzCtBH7aihsSL9-R4x71sj2ckY<=oldym5kX8IqLSVDtpNMw:
			G3yDpvxOiSWdAeL.setSetting(GHg28TBchiyn6l(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ࿀"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
	return
def B4E2DFJzoY1LHbWSaKfGmQAOs7(lgB7TOZqEJiMUFedrSHX8j6,pUL3DejE4W5K):
	xVyEPTDtrSfAl6I35 = wnaWTQM7VJPkZzO9eoSyFU4
	yArKcBVp3YPCqHa = KiryBCvngZzF85UN6xSDlOVweL4I9 if A3pXVFdyP1.IMAvyqd5QL60a else r0D4C3z7Onqpa
	if yArKcBVp3YPCqHa:
		if not pUL3DejE4W5K: lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
		oxIMPKyikLHUVdQNTzOWs5S813g = aaSudEO2gkDPeTi41ZMbYtKoNs70l(lgB7TOZqEJiMUFedrSHX8j6)
		if len(oxIMPKyikLHUVdQNTzOWs5S813g)>wnaWTQM7VJPkZzO9eoSyFU4:
			SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,yobpaW7sBqtKRrv(u"ࠨ࠰࡟ࡸࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ࿁")+oobgjl3xWaBeRZF8wdzKYAvtus+Z9FPQvwlbjLTh(u"ࠩࠣࡡࠬ࿂"))
			m5XtY37nVSIb2,ofEcIgWvaQizr9uTq8LBApwH0,M9yafHSnNLJowPBFc7WXOgIekrbzE,V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm,PPSTwoZdRinA3YXtybaeVux9Om0E = oxIMPKyikLHUVdQNTzOWs5S813g[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			MCKSB1imbP08HdjAue,hhOXld4so9FJYnS3W0tmj = V6lUXTqHAjQv4wg.split(CyHU86ZeYT5BWRcitSm2I(u"ࠪࡠࡳࡁ࠻ࠨ࿃"))
			del oxIMPKyikLHUVdQNTzOWs5S813g[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			uOPRDSn1T9iLGzebU = FxEWL1w4gjr8mM.sample(oxIMPKyikLHUVdQNTzOWs5S813g,wnaWTQM7VJPkZzO9eoSyFU4)
			m5XtY37nVSIb2,ofEcIgWvaQizr9uTq8LBApwH0,M9yafHSnNLJowPBFc7WXOgIekrbzE,V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm,PPSTwoZdRinA3YXtybaeVux9Om0E = uOPRDSn1T9iLGzebU[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			M9yafHSnNLJowPBFc7WXOgIekrbzE = A6iX18qgyOFlZxz7sc(u"ࠫࡠࡘࡔࡍ࡟ࠪ࿄")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+mq5t9JXSdHT8yfDVF(u"ࠬࠦ࠺ࠡࠩ࿅")+m5XtY37nVSIb2+YVr6St5P4xsFC0aARQGKfiegD+M9yafHSnNLJowPBFc7WXOgIekrbzE
			Sse7u20tJZbUkIP8Ncm = tzZ6PhyDOUnwLM3pdK(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะ࿆ࠬ")
			zgZxM9fWCVm1htlqkyunjALoO0H82G = SI7eBdND4lx8pt5Qk(u"ࠧศๆอฬึ฿วหࠩ࿇")
			button0,button1 = V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm
			HHvCRdTkabZMeoEhlI9rKFqpsg71 = [button0,button1,zgZxM9fWCVm1htlqkyunjALoO0H82G]
			k3mA1XTeColhgfBs6IZ8HYNx = wnaWTQM7VJPkZzO9eoSyFU4 if A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI else beV5l2D8HznyJI0(u"࠳࠳ᖀ")
			tt2NkXu7HgTIAyj09OBlod3YDpz = -pp7FcjEe6g(u"࠼ᖁ")
			while tt2NkXu7HgTIAyj09OBlod3YDpz<j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
				hPTxascUYl1uCKwRpNiyE5Fj2W0 = FxEWL1w4gjr8mM.sample(HHvCRdTkabZMeoEhlI9rKFqpsg71,vXIdY7TwFKso40gVBq5)
				tt2NkXu7HgTIAyj09OBlod3YDpz = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,hPTxascUYl1uCKwRpNiyE5Fj2W0[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],hPTxascUYl1uCKwRpNiyE5Fj2W0[wnaWTQM7VJPkZzO9eoSyFU4],hPTxascUYl1uCKwRpNiyE5Fj2W0[XURrDCfOS9Mbhpv2Pmjos56TeW],MCKSB1imbP08HdjAue,M9yafHSnNLJowPBFc7WXOgIekrbzE,mq5t9JXSdHT8yfDVF(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿈"),k3mA1XTeColhgfBs6IZ8HYNx,SI7eBdND4lx8pt5Qk(u"࠺࠵ᖂ"))
				if tt2NkXu7HgTIAyj09OBlod3YDpz==wwWzyF4ZpSQXKOgk569(u"࠶࠶ᖃ"): break
				import GkCs6wbiQP
				if tt2NkXu7HgTIAyj09OBlod3YDpz>=j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and hPTxascUYl1uCKwRpNiyE5Fj2W0[tt2NkXu7HgTIAyj09OBlod3YDpz]==HHvCRdTkabZMeoEhlI9rKFqpsg71[wnaWTQM7VJPkZzO9eoSyFU4]:
					GkCs6wbiQP.L6eh8YbJ0EaWDtAnOs()
					if tt2NkXu7HgTIAyj09OBlod3YDpz>=j0jEZgiKdxFpMLHcU7kQr8v1lyX4: tt2NkXu7HgTIAyj09OBlod3YDpz = -GHg28TBchiyn6l(u"࠿ᖄ")
				elif tt2NkXu7HgTIAyj09OBlod3YDpz>=j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and hPTxascUYl1uCKwRpNiyE5Fj2W0[tt2NkXu7HgTIAyj09OBlod3YDpz]==HHvCRdTkabZMeoEhlI9rKFqpsg71[XURrDCfOS9Mbhpv2Pmjos56TeW]:
					GkCs6wbiQP.RyDfnmHVzB82J4(KiryBCvngZzF85UN6xSDlOVweL4I9)
				if tt2NkXu7HgTIAyj09OBlod3YDpz==-wnaWTQM7VJPkZzO9eoSyFU4: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,RNWqL0gBbKOie1DxjUpzQPh9aZyHX+beV5l2D8HznyJI0(u"ࠩัีําࠠฯูฦࠫ࿉")+YVr6St5P4xsFC0aARQGKfiegD+KLX7hW0nBAEgy6m4SvH(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ࿊"))
			xVyEPTDtrSfAl6I35 = wnaWTQM7VJPkZzO9eoSyFU4
		else: xVyEPTDtrSfAl6I35 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	G3yDpvxOiSWdAeL.setSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭࿋"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,CyHU86ZeYT5BWRcitSm2I(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ࿌"),rVy3Ops0mohYkT(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ࿍"),xVyEPTDtrSfAl6I35,iXBqSkDU3mRCZf4Ib)
	return
def cLTeilmKj6AMbyzFHR(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z):
	if Ak1C6Llhn5dKOFq in [A6iX18qgyOFlZxz7sc(u"ࠧ࠲ࠩ࿎"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠴ࠪ࿏"),YYQS36fyPvtuzcEmRL(u"ࠩ࠶ࠫ࿐"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠸ࠬ࿑"),GHg28TBchiyn6l(u"ࠫ࠺࠭࿒"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࠷࠱ࠨ࿓"),KLX7hW0nBAEgy6m4SvH(u"࠭࠱࠳ࠩ࿔"),tzZ6PhyDOUnwLM3pdK(u"ࠧ࠲࠵ࠪ࿕")] and tyBbpM6uq7N2FdgksfT5z:
		import zQ1YjoMLiN
		zQ1YjoMLiN.B5LHyWdY6Cu(SDUJm78sZBG,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z)
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9,oobgjl3xWaBeRZF8wdzKYAvtus)
	elif Ak1C6Llhn5dKOFq==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࠸ࠪ࿖"):
		import UdvL4wSQeI,yBR5QHGdUT
		if tyBbpM6uq7N2FdgksfT5z==GHg28TBchiyn6l(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ࿗"): yBR5QHGdUT.uTaiRMI8eYmN(SI7eBdND4lx8pt5Qk(u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪ࿘"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫ࿙"),x54xSdnCFHZ8yliofzOBK=SI7eBdND4lx8pt5Qk(u"࠲࠱࠲࠳ᖅ"))
		elif tyBbpM6uq7N2FdgksfT5z==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡊࡅࡍࡇࡗࡉࠬ࿚"): xwEQAOSry1FPR3itoU7BIg(uuSU5Awl8FNrzkXHdQDiCWq3,KiryBCvngZzF85UN6xSDlOVweL4I9)
		APpdhB1Fk58MmJH7CjVntowyaY = UdvL4wSQeI.NNFPsWDgoE(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,Dj0qYc573K2aQ,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
		if tyBbpM6uq7N2FdgksfT5z==A41nqbj3wYt(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ࿛"): sm0xF8WoGavE7iNjd()
	elif SDUJm78sZBG==ZLr5gRSkFewKdUos90bM(u"ࠧ࠸ࠩ࿜"):
		import IV2oTbWpv9
		IV2oTbWpv9.fTBub10xG2M7W5qF8HtQov(rVy3Ops0mohYkT(u"ࠨࡡࡄࡐࡑ࠭࿝"))
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif SDUJm78sZBG==VP70ytiFNMBl6vHDaW(u"ࠩ࠻ࠫ࿞"): pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࿟")+B40Qr5hlSgNm1kuXD3ZFpnyC9+iySORMYxWXszEH18(u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ࿠")+str(e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE)+wwWzyF4ZpSQXKOgk569(u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ࿡"))
	elif SDUJm78sZBG==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭࠹ࠨ࿢"):
		YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa)
	elif SDUJm78sZBG==CyHU86ZeYT5BWRcitSm2I(u"ࠧ࠲࠲ࠪ࿣"):
		import IV2oTbWpv9
		IV2oTbWpv9.fTBub10xG2M7W5qF8HtQov(YYQS36fyPvtuzcEmRL(u"ࠨࡡࡊࡓࡔࡍࡌࡆࠩ࿤"))
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif SDUJm78sZBG==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࠴࠸ࠬ࿥"): YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡘࡊࡓࡐࠨ࿦"))
	elif SDUJm78sZBG==A41nqbj3wYt(u"ࠫ࠶࠻ࠧ࿧"): YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa,GHg28TBchiyn6l(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪ࿨"))
	elif SDUJm78sZBG==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭࠱࠷ࠩ࿩"): YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa,SI7eBdND4lx8pt5Qk(u"ࠧࡎࡇࡑ࡙ࡤࡊࡅࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭࿪"))
	elif SDUJm78sZBG==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࠳࠺ࠫ࿫"): YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa,gPE1XB87fQl(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ࿬"))
	elif SDUJm78sZBG==SI7eBdND4lx8pt5Qk(u"ࠪ࠵࠽࠭࿭"):
		ufQ5elFnNp = G3yDpvxOiSWdAeL.getSetting(CyHU86ZeYT5BWRcitSm2I(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨ࿮"))
		G3yDpvxOiSWdAeL.setSetting(ZLr5gRSkFewKdUos90bM(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ࿯"),yobpaW7sBqtKRrv(u"࠭࠭ࠨ࿰")+ufQ5elFnNp)
	if SDUJm78sZBG in [A6iX18qgyOFlZxz7sc(u"ࠧ࠺ࠩ࿱"),wwWzyF4ZpSQXKOgk569(u"ࠨ࠳࠷ࠫ࿲"),IMjqygdfYSKpHlWu5Aa(u"ࠩ࠴࠹ࠬ࿳"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠵࠻࠭࿴"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫ࠶࠽ࠧ࿵")]: sm0xF8WoGavE7iNjd(r0D4C3z7Onqpa)
	return
def PMZ8lwjHRh(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z,z6PVkLf7Od):
	if dJ3lKeg21CuqpwSEhQYPmDV: oyQBDdCApsgqwT()
	if SDUJm78sZBG: cLTeilmKj6AMbyzFHR(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,Ak1C6Llhn5dKOFq,tyBbpM6uq7N2FdgksfT5z)
	sPcH8StFImxrQwk(Dj0qYc573K2aQ)
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe = r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9
	nnSoJ3zpOYcfx1KBUs6DEWtH = k48KRn0Q5mSWpjswGaeYAvHuLbP2(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,z6PVkLf7Od,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe)
	JnmTcpHY2vrQ16uG7CMsDFEOe8I,rLEuTzBs2HFXjeSyfvCZcQw4O,y6epqbJCBX,OCVUomhFsnctQJS8,TzjFJvgAZwrhHSln8b9i6u07NWym,rknaV25XxOA0,NBuT5Gto4H1j6zwyYaIim2,lKoR0NitVskuJc69Dm = nnSoJ3zpOYcfx1KBUs6DEWtH
	if JnmTcpHY2vrQ16uG7CMsDFEOe8I: return
	if rLEuTzBs2HFXjeSyfvCZcQw4O==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬ࿶"): PzLX0Jg7lIERk1WAeUKQNZV2Bwc(XAGWNdKH4qOPU1YEVQp6)
	EOMr9e5BFQToPJvnphc1Ii3Vf8KHl(Z9FPQvwlbjLTh(u"࠭ࡳࡵࡣࡵࡸࠬ࿷"))
	if G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭࿸")) not in [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡃࡘࡘࡔ࠭࿹"),bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡖࡘࡔࡖࠧ࿺"),Z9FPQvwlbjLTh(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ࿻")]:
		G3yDpvxOiSWdAeL.setSetting(ZLr5gRSkFewKdUos90bM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ࿼"),A41nqbj3wYt(u"ࠬࡇࡕࡕࡑࠪ࿽"))
	if not G3yDpvxOiSWdAeL.getSetting(A41nqbj3wYt(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭࿾")): G3yDpvxOiSWdAeL.setSetting(ZLr5gRSkFewKdUos90bM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧ࿿"),A3pXVFdyP1.DNS_SERVERS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
	APpdhB1Fk58MmJH7CjVntowyaY = NNFPsWDgoE(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
	if wwWzyF4ZpSQXKOgk569(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪက") in HvzeZpTRrx9j1hMBV3: apvSg9k5RKFxsXYzUOb = r0D4C3z7Onqpa
	if G3Xh0YWACHFuvQLx5sVEfPjzq7==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡩࡳࡱࡪࡥࡳࠩခ"):
		if OCVUomhFsnctQJS8!=oiWNFYzcIUeh(u"ࠪ࠲࠳࠭ဂ") and TzjFJvgAZwrhHSln8b9i6u07NWym: OE38lVnF9jRGUAXPzoLIecvMHp()
		if ZTaSobILWiO9ywfN64AVQPzUgKGHX>-wnaWTQM7VJPkZzO9eoSyFU4:
			N7vhB6RrdFT = [j0jEZgiKdxFpMLHcU7kQr8v1lyX4,KLX7hW0nBAEgy6m4SvH(u"࠳࠸ᖇ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠴࠻ᖈ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠵࠾ᖉ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳࠸ᖆ"),wwWzyF4ZpSQXKOgk569(u"࠳࠵ᖌ"),VP70ytiFNMBl6vHDaW(u"࠺࠶ᖊ"),Z9FPQvwlbjLTh(u"࠻࠳ᖋ"),bawK2j7T81Nrc4GWs05xzDg(u"࠲࠳࠳ᖍ")]
			if (VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,rVy3Ops0mohYkT(u"ࠫ࡮ࡴࡴࠨဃ"),pp7FcjEe6g(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨင"),mq5t9JXSdHT8yfDVF(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫစ")) or Dj0qYc573K2aQ not in N7vhB6RrdFT) and not A3pXVFdyP1.bWV7czPeIaq:
				from cl1aVJLDm2 import GkhP7zZpoFUDu
				h7keK5CIOgG2ZAE0VJTurFs,dHstN2gPLFWZ8yO5Mk = e7WYrJtuzF6CES(GkhP7zZpoFUDu)
				JnmTcpHY2vrQ16uG7CMsDFEOe8I = U1jrPe7mLiHwgaZn4GlJXp(y6epqbJCBX,h7keK5CIOgG2ZAE0VJTurFs,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe)
				if h7keK5CIOgG2ZAE0VJTurFs and rknaV25XxOA0:
					if dHstN2gPLFWZ8yO5Mk: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,Z9FPQvwlbjLTh(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ဆ")+NBuT5Gto4H1j6zwyYaIim2+iySORMYxWXszEH18(u"ࠨࡡࠪဇ")+lKoR0NitVskuJc69Dm,y6epqbJCBX,h7keK5CIOgG2ZAE0VJTurFs,nsFAzS2wvjyTYLOdDhfIiC0KGHE)
					else: sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨဈ")+NBuT5Gto4H1j6zwyYaIim2+ZLr5gRSkFewKdUos90bM(u"ࠪࡣࠬဉ")+lKoR0NitVskuJc69Dm,y6epqbJCBX)
			else:
				Ydimlc1rVsAnLIhkRyb6aK2.addDirectoryItem(ZTaSobILWiO9ywfN64AVQPzUgKGHX,GHg28TBchiyn6l(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧည")+B40Qr5hlSgNm1kuXD3ZFpnyC9+A41nqbj3wYt(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬဋ"),Zilvh2WQyb5.ListItem(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬဌ")))
				Ydimlc1rVsAnLIhkRyb6aK2.addDirectoryItem(ZTaSobILWiO9ywfN64AVQPzUgKGHX,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪဍ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+SI7eBdND4lx8pt5Qk(u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨဎ"),Zilvh2WQyb5.ListItem(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨဏ")))
			Ydimlc1rVsAnLIhkRyb6aK2.endOfDirectory(ZTaSobILWiO9ywfN64AVQPzUgKGHX,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe)
	return
def PzLX0Jg7lIERk1WAeUKQNZV2Bwc(BuOmZGCvIwDyVUeqNgKc):
	if Z9FPQvwlbjLTh(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬတ") in str(A3pXVFdyP1.SEND_THESE_EVENTS): return
	ELXIAcfThb7V69qtiPjdkZUsNBDw2l = KiryBCvngZzF85UN6xSDlOVweL4I9 if BuOmZGCvIwDyVUeqNgKc else r0D4C3z7Onqpa
	if not ELXIAcfThb7V69qtiPjdkZUsNBDw2l:
		rh7RKklDHbMpaX9FWygL10ECoVcN4 = bI32vYq51R4aney(G3yDpvxOiSWdAeL.getSetting(yobpaW7sBqtKRrv(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬထ")))
		rh7RKklDHbMpaX9FWygL10ECoVcN4 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4 if not rh7RKklDHbMpaX9FWygL10ECoVcN4 else int(rh7RKklDHbMpaX9FWygL10ECoVcN4)
		if not rh7RKklDHbMpaX9FWygL10ECoVcN4 or not j0jEZgiKdxFpMLHcU7kQr8v1lyX4<=jDuxzCtBH7aihsSL9-rh7RKklDHbMpaX9FWygL10ECoVcN4<=BuOmZGCvIwDyVUeqNgKc: ELXIAcfThb7V69qtiPjdkZUsNBDw2l = r0D4C3z7Onqpa
	if not ELXIAcfThb7V69qtiPjdkZUsNBDw2l:
		GlWHF25MqdrbEKQwsv817jYhSec = G3yDpvxOiSWdAeL.getSetting(rVy3Ops0mohYkT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪဒ"))
		if GlWHF25MqdrbEKQwsv817jYhSec in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬဓ"),iySORMYxWXszEH18(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭န")]: ELXIAcfThb7V69qtiPjdkZUsNBDw2l = r0D4C3z7Onqpa
	if not ELXIAcfThb7V69qtiPjdkZUsNBDw2l:
		VdZuD87hGeOoPILwFrqcMx4NBti = G3yDpvxOiSWdAeL.getSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫပ"))
		OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(p9DTgUZ1auwRYXoHld7v8MP)
		R7GYIQxT4v = PEZioFnTRIm3(p9DTgUZ1auwRYXoHld7v8MP,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡪࡦࠣ࠿ࠬဖ"))
		R7GYIQxT4v = R7GYIQxT4v[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠲ᖎ")][XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠲ᖎ")]
		OoE5HYUMwsrDWhx2gR7I3FuN.close()
		oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(beV5l2D8HznyJI0(u"࠸ᖏ")*VdZuD87hGeOoPILwFrqcMx4NBti.encode(e87cIA5vwOQLDEP1)).hexdigest()
		oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(CyHU86ZeYT5BWRcitSm2I(u"࠵࠹ᖐ")*oybVOQu7xUdwLzChmfnIYKvN.encode(e87cIA5vwOQLDEP1)).hexdigest()
		oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠶࠿ᖑ")*oybVOQu7xUdwLzChmfnIYKvN.encode(e87cIA5vwOQLDEP1)).hexdigest()
		oybVOQu7xUdwLzChmfnIYKvN = str(int(oybVOQu7xUdwLzChmfnIYKvN[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠳ᖓ"):aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠲࠴ᖔ")],QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠹ᖕ")))[:VP70ytiFNMBl6vHDaW(u"࠿ᖒ")]
		if oybVOQu7xUdwLzChmfnIYKvN!=R7GYIQxT4v: ELXIAcfThb7V69qtiPjdkZUsNBDw2l = r0D4C3z7Onqpa
	if ELXIAcfThb7V69qtiPjdkZUsNBDw2l: CptxmLUw0EaFr(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def WwrtYuXs0D9L1Ry5zZxINdVHa2l(cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E,ADN3XhW9ZpVmFK84j2roiy,showDialogs):
	OOG1iPYhTKQ4 = ADN3XhW9ZpVmFK84j2roiy.split(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠱ࠬဗ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] if pp7FcjEe6g(u"ࠫ࠲࠭ဘ") in ADN3XhW9ZpVmFK84j2roiy else ADN3XhW9ZpVmFK84j2roiy
	if not showDialogs or ADN3XhW9ZpVmFK84j2roiy in Km2gVSNzXhsfMDYRdupqP0kUr8: return KiryBCvngZzF85UN6xSDlOVweL4I9
	f7EY5yTIcRWlqj = G3yDpvxOiSWdAeL.getSetting(tzZ6PhyDOUnwLM3pdK(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭မ"))
	G3yDpvxOiSWdAeL.setSetting(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧယ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	oC5apNs2fUDdbFZEzJO7KhvHQ = cquGxZCOaDk3QJMNlXSeU in [n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠽ᖙ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠵࠶࠶࠰࠲ᖗ"),SI7eBdND4lx8pt5Qk(u"࠴࠵࠵࠶࠲ᖖ"),KLX7hW0nBAEgy6m4SvH(u"࠶࠶࠰࠶࠶ᖘ")]
	if eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡀࡷࡶࡩࡷࡃࠧရ") in PPSTwoZdRinA3YXtybaeVux9Om0E: PPSTwoZdRinA3YXtybaeVux9Om0E = PPSTwoZdRinA3YXtybaeVux9Om0E.split(mq5t9JXSdHT8yfDVF(u"ࠨࡁࡸࡷࡪࡸ࠽ࠨလ"),rVy3Ops0mohYkT(u"࠱ᖚ"))[aiQwFE1TGx04vmLcsYkIW5jA(u"࠱ᖛ")]+IMjqygdfYSKpHlWu5Aa(u"ࠩࠬࠫဝ")
	h5A3CsiH7Q = PPSTwoZdRinA3YXtybaeVux9Om0E.lower()
	z7GUqyEft6gliLwca = cquGxZCOaDk3QJMNlXSeU in [j0jEZgiKdxFpMLHcU7kQr8v1lyX4,A41nqbj3wYt(u"࠵࠵࠺ᖞ"),yobpaW7sBqtKRrv(u"࠳࠳࠴࠻࠷ᖜ"),oiWNFYzcIUeh(u"࠴࠵࠶ᖝ")]
	TEKt5gUwIJ3BfZMRL1b9ld = iySORMYxWXszEH18(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫသ") in h5A3CsiH7Q
	p7znEJuojc6ZODAHd9xPUKkWYevRF = IMjqygdfYSKpHlWu5Aa(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫဟ") in h5A3CsiH7Q
	ONjI67uM4Js = SI7eBdND4lx8pt5Qk(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬဠ") in h5A3CsiH7Q
	VaMR6QDngZkFEbB5JH = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨအ") in h5A3CsiH7Q
	smphBeIR3ZcLC9oxAbkr51yvYa = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡲ࡯ࡳࡴ࡫ࡱ࡫ࠥࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠢࡦ࡬ࡪࡩ࡫ࠨဢ") in h5A3CsiH7Q
	inYx4gBosC10 = mq5t9JXSdHT8yfDVF(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡿ࡯ࡶࡴࠣࡲࡪࡺࡷࡰࡴ࡮ࠤࡩ࡫ࡶࡪࡥࡨࡷࠬဣ") in h5A3CsiH7Q
	i1hNlPaAcTrg72Zd3QVqyw = G3yDpvxOiSWdAeL.getSetting(YYQS36fyPvtuzcEmRL(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧဤ"))
	QQFw9bKiAfmO7PrJD6UhBT = G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ဥ"))
	zFlMQb8XA32Bryc4wn0D = SI7eBdND4lx8pt5Qk(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭ဦ")
	pOciIjGoV37kdX4A2FU = oiWNFYzcIUeh(u"ࠬࡋࡲࡳࡱࡵࠤࠬဧ")+str(cquGxZCOaDk3QJMNlXSeU)+pp7FcjEe6g(u"࠭࠺ࠡࠩဨ")+PPSTwoZdRinA3YXtybaeVux9Om0E
	pOciIjGoV37kdX4A2FU = EZk136aeLoNqPvlDcTQpyM9Wm(pOciIjGoV37kdX4A2FU)
	if any([z7GUqyEft6gliLwca,TEKt5gUwIJ3BfZMRL1b9ld,p7znEJuojc6ZODAHd9xPUKkWYevRF,ONjI67uM4Js,VaMR6QDngZkFEbB5JH,smphBeIR3ZcLC9oxAbkr51yvYa,inYx4gBosC10]): zFlMQb8XA32Bryc4wn0D += jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧဩ")
	if oC5apNs2fUDdbFZEzJO7KhvHQ: zFlMQb8XA32Bryc4wn0D += XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨဪ")
	pOciIjGoV37kdX4A2FU = WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+pOciIjGoV37kdX4A2FU+YVr6St5P4xsFC0aARQGKfiegD
	if i1hNlPaAcTrg72Zd3QVqyw==SI7eBdND4lx8pt5Qk(u"ࠩࡄࡗࡐ࠭ါ") or QQFw9bKiAfmO7PrJD6UhBT==Z9FPQvwlbjLTh(u"ࠪࡅࡘࡑࠧာ"):
		zFlMQb8XA32Bryc4wn0D += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+GHg28TBchiyn6l(u"ࠫ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦ࠭ိ")+YVr6St5P4xsFC0aARQGKfiegD
	oHMhRFviaSOZqCe4jPEtk0N6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	if i1hNlPaAcTrg72Zd3QVqyw==mq5t9JXSdHT8yfDVF(u"ࠬࡇࡓࡌࠩီ") or QQFw9bKiAfmO7PrJD6UhBT==bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡁࡔࡍࠪု"):
		tt2NkXu7HgTIAyj09OBlod3YDpz = tFVmMznSUR3XupZBN9kxcO0EHv(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡤࡧࡱࡸࡪࡸࠧူ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨะิ์ั࠭ေ"),CyHU86ZeYT5BWRcitSm2I(u"ࠩศีุอไࠡๆ็้อืๅอࠩဲ"),IMjqygdfYSKpHlWu5Aa(u"ࠪฮฺ๊๊ฮࠢสฺ่๊ใๅหࠪဳ"),OOG1iPYhTKQ4+jrD65cZUQ8uGR0IHNCkF+v2oRq5AhQzcx(OOG1iPYhTKQ4),zFlMQb8XA32Bryc4wn0D+WBDnh75CaLEvkcN6p4ez2KXrV3M+pOciIjGoV37kdX4A2FU)
		if tt2NkXu7HgTIAyj09OBlod3YDpz==wnaWTQM7VJPkZzO9eoSyFU4:
			from GkCs6wbiQP import L6eh8YbJ0EaWDtAnOs
			L6eh8YbJ0EaWDtAnOs()
		elif tt2NkXu7HgTIAyj09OBlod3YDpz==XURrDCfOS9Mbhpv2Pmjos56TeW: oHMhRFviaSOZqCe4jPEtk0N6 = r0D4C3z7Onqpa
	else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OOG1iPYhTKQ4+jrD65cZUQ8uGR0IHNCkF+v2oRq5AhQzcx(OOG1iPYhTKQ4),zFlMQb8XA32Bryc4wn0D,pOciIjGoV37kdX4A2FU)
	G3yDpvxOiSWdAeL.setSetting(tzZ6PhyDOUnwLM3pdK(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬဴ"),f7EY5yTIcRWlqj)
	return oHMhRFviaSOZqCe4jPEtk0N6
def bQpsh4PIEHVodD5kWj7mXaRFe(mKoMflY5HC=KiryBCvngZzF85UN6xSDlOVweL4I9,F7FphMg5wykO=[]):
	XJEyD9QVZtWSFLl8H = [UUN4I9unSKWg7c3YizxEmq,C6MhN2TeZ83GDFngway7EvBYom5i]+F7FphMg5wykO
	for LLipmUFe3789Mc5Q6s0CBVznIbRXgh in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(kcCgDi2EzhU5s413pAjSmu):
		if mKoMflY5HC and (LLipmUFe3789Mc5Q6s0CBVznIbRXgh.startswith(VP70ytiFNMBl6vHDaW(u"ࠬ࡯ࡰࡵࡸࠪဵ")) or LLipmUFe3789Mc5Q6s0CBVznIbRXgh.startswith(IMjqygdfYSKpHlWu5Aa(u"࠭࡭࠴ࡷࠪံ"))): continue
		if LLipmUFe3789Mc5Q6s0CBVznIbRXgh.startswith(KLX7hW0nBAEgy6m4SvH(u"ࠧࡧ࡫࡯ࡩࡤ့࠭")): continue
		IHcfhwT97AoxMe6sXk = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,LLipmUFe3789Mc5Q6s0CBVznIbRXgh)
		if IHcfhwT97AoxMe6sXk in XJEyD9QVZtWSFLl8H: continue
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(IHcfhwT97AoxMe6sXk)
		except: pass
	if Hp7qgMcFCX46nO8Poy not in XJEyD9QVZtWSFLl8H: r670fZQYnxlNOUoVBbMJa(Hp7qgMcFCX46nO8Poy,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
	x54xSdnCFHZ8yliofzOBK.sleep(A6iX18qgyOFlZxz7sc(u"࠶ᖟ"))
	return
def fBpwYkJVnm8FcWEj1oKOSzTHrZtaxM(t9JNaXLm5cIkFeHjQ8R,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI=r0D4C3z7Onqpa,FX7dKayU9G1mTv=r0D4C3z7Onqpa):
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA+pp7FcjEe6g(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨး")+t9JNaXLm5cIkFeHjQ8R
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI,FX7dKayU9G1mTv)
	if kdNn2Zqsj4wPi5ThuoUQvtcg6OA in u4vhNT8C0k1tmrxX9F5gGWo7Z.content: u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
	if not u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		sm0xF8WoGavE7iNjd()
	return u4vhNT8C0k1tmrxX9F5gGWo7Z
def roHNB0Mb1cVdgS4FtCXsD(kdNn2Zqsj4wPi5ThuoUQvtcg6OA):
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,Z9FPQvwlbjLTh(u"ࠩࡊࡉ္࡙࠭"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷ်ࠫ"),r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
	bsAD92Vx7K4q53haXv0BMpnUQP = []
	if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
		xi30OyWvGNMlu6q4jozd8sgRrnYp5E = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧျ"),VbRFshPMjr2t3k)
		if xi30OyWvGNMlu6q4jozd8sgRrnYp5E: VbRFshPMjr2t3k = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(xi30OyWvGNMlu6q4jozd8sgRrnYp5E)
		ea9Tk4o1QhqDZbMfxC = VbRFshPMjr2t3k.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(WBDnh75CaLEvkcN6p4ez2KXrV3M).split(WBDnh75CaLEvkcN6p4ez2KXrV3M)
		bsAD92Vx7K4q53haXv0BMpnUQP = []
		for t9JNaXLm5cIkFeHjQ8R in ea9Tk4o1QhqDZbMfxC:
			if t9JNaXLm5cIkFeHjQ8R.count(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࠴ࠧြ"))==vXIdY7TwFKso40gVBq5: bsAD92Vx7K4q53haXv0BMpnUQP.append(t9JNaXLm5cIkFeHjQ8R)
	return bsAD92Vx7K4q53haXv0BMpnUQP
def cFyK6eYqTvdmPnIrk(*aargs):
	oXbsSvW3aeyB1kqnQMTjKV = SI7eBdND4lx8pt5Qk(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵ࡶ࠳࠱ࡂࡶࡪࡷࡵࡦࡵࡷࡁࡩ࡯ࡳࡱ࡮ࡤࡽࡵࡸ࡯ࡹ࡫ࡨࡷࠫࡶࡲࡰࡺࡼࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡴࡪ࡯ࡨࡳࡺࡺ࠽࠲࠲࠳࠴࠵ࠬࡳࡴ࡮ࡀࡽࡪࡹࠦ࡭࡫ࡰ࡭ࡹࡃ࠱࠱ࠨࡦࡳࡺࡴࡴࡳࡻࡀࡒࡑ࠲ࡂࡆ࠮ࡇࡉ࠱ࡌࡒ࠭ࡉࡅ࠰࡙ࡘࠧွ")
	RRmvnax96VLCTypFcqjMK0oUQ = bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡰࡱࡶࡸࡪࡸ࡫ࡪࡦ࠲ࡳࡵ࡫࡮ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡱࡦ࡯࡮࠰ࡊࡗࡘࡕ࡙࠮ࡵࡺࡷࠫှ")
	t1WDoi2UlEqH7rbZeN68BpkCYQyczR = roHNB0Mb1cVdgS4FtCXsD(RRmvnax96VLCTypFcqjMK0oUQ)
	bsAD92Vx7K4q53haXv0BMpnUQP = roHNB0Mb1cVdgS4FtCXsD(oXbsSvW3aeyB1kqnQMTjKV)
	md9hEpOKygnrY4XtzkvoqB3T = t1WDoi2UlEqH7rbZeN68BpkCYQyczR+bsAD92Vx7K4q53haXv0BMpnUQP
	SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+mq5t9JXSdHT8yfDVF(u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧဿ")+str(len(t1WDoi2UlEqH7rbZeN68BpkCYQyczR))+mq5t9JXSdHT8yfDVF(u"ࠩ࠮ࠫ၀")+str(len(bsAD92Vx7K4q53haXv0BMpnUQP))+oiWNFYzcIUeh(u"ࠪࠤࡢ࠭၁"))
	t9JNaXLm5cIkFeHjQ8R = G3yDpvxOiSWdAeL.getSetting(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ၂"))
	u4vhNT8C0k1tmrxX9F5gGWo7Z = OOLSaYvmWAiTPXfuM9y3x5zZJ()
	G3yDpvxOiSWdAeL.setSetting(SI7eBdND4lx8pt5Qk(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ၃"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if t9JNaXLm5cIkFeHjQ8R or md9hEpOKygnrY4XtzkvoqB3T:
		m5XtY37nVSIb2,QoZYSAMzNs5uHnGEdC7p = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,GHg28TBchiyn6l(u"࠷࠰ᖠ")
		nnaQ78bVRIu = len(md9hEpOKygnrY4XtzkvoqB3T)
		KCVSR5JtpWLgDiPj1cEZ7xIvqoF = QoZYSAMzNs5uHnGEdC7p
		if nnaQ78bVRIu>KCVSR5JtpWLgDiPj1cEZ7xIvqoF: f4djmi2ZoWPrYg3tAzEpTkLXqaHyG = KCVSR5JtpWLgDiPj1cEZ7xIvqoF
		else: f4djmi2ZoWPrYg3tAzEpTkLXqaHyG = nnaQ78bVRIu
		Gt8oBlYw9VXD6IL2ue = FxEWL1w4gjr8mM.sample(md9hEpOKygnrY4XtzkvoqB3T,f4djmi2ZoWPrYg3tAzEpTkLXqaHyG)
		if t9JNaXLm5cIkFeHjQ8R: Gt8oBlYw9VXD6IL2ue = [t9JNaXLm5cIkFeHjQ8R]+Gt8oBlYw9VXD6IL2ue
		gO4EfJH5hp13duvzF7DGnsZaAbLr2 = ouEV7ZMghRakP24(KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
		CIeL32XZ57bpg6WFyKB = x54xSdnCFHZ8yliofzOBK.time()
		while x54xSdnCFHZ8yliofzOBK.time()-CIeL32XZ57bpg6WFyKB<=QoZYSAMzNs5uHnGEdC7p and not gO4EfJH5hp13duvzF7DGnsZaAbLr2.finishedLIST:
			if m5XtY37nVSIb2<f4djmi2ZoWPrYg3tAzEpTkLXqaHyG:
				t9JNaXLm5cIkFeHjQ8R = Gt8oBlYw9VXD6IL2ue[m5XtY37nVSIb2]
				gO4EfJH5hp13duvzF7DGnsZaAbLr2.b8nwpCGfrTHFm(m5XtY37nVSIb2,fBpwYkJVnm8FcWEj1oKOSzTHrZtaxM,t9JNaXLm5cIkFeHjQ8R,*aargs)
			x54xSdnCFHZ8yliofzOBK.sleep(beV5l2D8HznyJI0(u"࠰࠯࠹࠸ᖡ"))
			m5XtY37nVSIb2 += wnaWTQM7VJPkZzO9eoSyFU4
			SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+beV5l2D8HznyJI0(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ၄")+t9JNaXLm5cIkFeHjQ8R+yobpaW7sBqtKRrv(u"ࠧࠡ࡟ࠪ၅"))
		finishedLIST = gO4EfJH5hp13duvzF7DGnsZaAbLr2.finishedLIST
		if finishedLIST:
			resultsDICT = gO4EfJH5hp13duvzF7DGnsZaAbLr2.resultsDICT
			VSJtW2x5y0hn = finishedLIST[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			u4vhNT8C0k1tmrxX9F5gGWo7Z = resultsDICT[VSJtW2x5y0hn]
			t9JNaXLm5cIkFeHjQ8R = Gt8oBlYw9VXD6IL2ue[int(VSJtW2x5y0hn)]
			G3yDpvxOiSWdAeL.setSetting(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ၆"),t9JNaXLm5cIkFeHjQ8R)
			if VSJtW2x5y0hn!=j0jEZgiKdxFpMLHcU7kQr8v1lyX4: SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+A6iX18qgyOFlZxz7sc(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ၇")+t9JNaXLm5cIkFeHjQ8R+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࠤࡢ࠭၈"))
			else: SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+oiWNFYzcIUeh(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭၉")+t9JNaXLm5cIkFeHjQ8R+yobpaW7sBqtKRrv(u"ࠬࠦ࡝ࠨ၊"))
	return u4vhNT8C0k1tmrxX9F5gGWo7Z
def r863jEeslqhwxcQ5oY7vN0nk4fWi2(HWJZNpmzGkTC8fvQiVox6nP0rM,Drx9ijtZIEezRk7mpVhlFL,wKoqBDL2utvP=r0D4C3z7Onqpa):
	Iciwj9Vdzb08pRatTHk7K5 = HWJZNpmzGkTC8fvQiVox6nP0rM.create_connection
	def JsKUpGn8y6bx3lRLdMOmfDY1C(b5U4Hjq90s3nauvIJd,*aargs,**kkwargs):
		MPBOrQ7eap0mYAI6cEsKSZTjVy,bTR3nzx6Ouv5KQoP7LiJUtMpH = b5U4Hjq90s3nauvIJd
		ip = ncBCmaR6ZUFADqfSlXuO(MPBOrQ7eap0mYAI6cEsKSZTjVy,Drx9ijtZIEezRk7mpVhlFL)
		if ip: MPBOrQ7eap0mYAI6cEsKSZTjVy = ip[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		elif wKoqBDL2utvP:
			if Drx9ijtZIEezRk7mpVhlFL in A3pXVFdyP1.DNS_SERVERS: A3pXVFdyP1.DNS_SERVERS.remove(Drx9ijtZIEezRk7mpVhlFL)
			if A3pXVFdyP1.DNS_SERVERS:
				w3MvqGpCQKL1s046 = A3pXVFdyP1.DNS_SERVERS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				ip = ncBCmaR6ZUFADqfSlXuO(MPBOrQ7eap0mYAI6cEsKSZTjVy,w3MvqGpCQKL1s046)
				if ip: MPBOrQ7eap0mYAI6cEsKSZTjVy = ip[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if ip: A3pXVFdyP1.dns_succeeded_urls.append(MPBOrQ7eap0mYAI6cEsKSZTjVy)
		b5U4Hjq90s3nauvIJd = (MPBOrQ7eap0mYAI6cEsKSZTjVy,bTR3nzx6Ouv5KQoP7LiJUtMpH)
		return Iciwj9Vdzb08pRatTHk7K5(b5U4Hjq90s3nauvIJd,*aargs,**kkwargs)
	HWJZNpmzGkTC8fvQiVox6nP0rM.create_connection = JsKUpGn8y6bx3lRLdMOmfDY1C
	return Iciwj9Vdzb08pRatTHk7K5
def oBriY0PjClAtRWgzme2McyNDhKwfa3(kdNn2Zqsj4wPi5ThuoUQvtcg6OA):
	bjnqvMiyX9570AZpdxNwHR4LztIT,JqbTPsfVRGL2z6OQc0Imhg = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭࠯ࠨ။"))[XURrDCfOS9Mbhpv2Pmjos56TeW],SI7eBdND4lx8pt5Qk(u"࠹࠲ᖢ")
	if yobpaW7sBqtKRrv(u"ࠧ࠻ࠩ၌") in bjnqvMiyX9570AZpdxNwHR4LztIT: bjnqvMiyX9570AZpdxNwHR4LztIT,JqbTPsfVRGL2z6OQc0Imhg = bjnqvMiyX9570AZpdxNwHR4LztIT.split(A41nqbj3wYt(u"ࠨ࠼ࠪ၍"))
	nsa1cZmYkeECLg56f7GoxK0B = A6iX18qgyOFlZxz7sc(u"ࠩ࠲ࠫ၎")+iySORMYxWXszEH18(u"ࠪ࠳ࠬ၏").join(kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(SI7eBdND4lx8pt5Qk(u"ࠫ࠴࠭ၐ"))[bawK2j7T81Nrc4GWs05xzDg(u"࠵ᖣ"):])
	dlPQGb0aC5xmfFwy9ievKTqX = mq5t9JXSdHT8yfDVF(u"ࠬࡍࡅࡕࠢࠪၑ")+nsa1cZmYkeECLg56f7GoxK0B+CyHU86ZeYT5BWRcitSm2I(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭ၒ")
	dlPQGb0aC5xmfFwy9ievKTqX += A6iX18qgyOFlZxz7sc(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧၓ")+bjnqvMiyX9570AZpdxNwHR4LztIT+YYQS36fyPvtuzcEmRL(u"ࠨ࡞ࡵࡠࡳ࠭ၔ")
	dlPQGb0aC5xmfFwy9ievKTqX += gPE1XB87fQl(u"ࠩ࡟ࡶࡡࡴࠧၕ")
	from socket import socket as ccvQsgXNMH,AF_INET as bdfnch1pv3,SOCK_STREAM as wvCcim4gHMhA6Sn8jPIoUF
	try:
		c158cgUzFbpRuEa9PNx3nLwjstIBi = ccvQsgXNMH(bdfnch1pv3,wvCcim4gHMhA6Sn8jPIoUF)
		c158cgUzFbpRuEa9PNx3nLwjstIBi.connect((bjnqvMiyX9570AZpdxNwHR4LztIT,JqbTPsfVRGL2z6OQc0Imhg))
		c158cgUzFbpRuEa9PNx3nLwjstIBi.send(dlPQGb0aC5xmfFwy9ievKTqX.encode(e87cIA5vwOQLDEP1))
		gyOe8MIsptDc9Fi7vzw3EA5fR4 = c158cgUzFbpRuEa9PNx3nLwjstIBi.recv(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠸࠵࠿࠶ᖥ")*IMjqygdfYSKpHlWu5Aa(u"࠴࠴࠷࠺ᖤ"))
		VbRFshPMjr2t3k = repr(gyOe8MIsptDc9Fi7vzw3EA5fR4)
	except: VbRFshPMjr2t3k = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	return VbRFshPMjr2t3k
def OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(WLJhgkxQ0PpazH8n4veoSBZM,G3Xh0YWACHFuvQLx5sVEfPjzq7):
	if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࠲ࠬၖ") not in WLJhgkxQ0PpazH8n4veoSBZM: return WLJhgkxQ0PpazH8n4veoSBZM
	WLJhgkxQ0PpazH8n4veoSBZM = WLJhgkxQ0PpazH8n4veoSBZM+wwWzyF4ZpSQXKOgk569(u"ࠫ࠴࠭ၗ")
	SmLeUo7lNqMBACEapv,edqrt03HPjs = WLJhgkxQ0PpazH8n4veoSBZM.split(Z9FPQvwlbjLTh(u"ࠬ࠴ࠧၘ"),bawK2j7T81Nrc4GWs05xzDg(u"࠶ᖦ"))
	xHUYCr6JOXfK7DoegAasR84GV,w2hcGmHFV4 = edqrt03HPjs.split(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠯ࠨၙ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠷ᖧ"))
	SPTqjsFBlCWXLgtoN = SmLeUo7lNqMBACEapv+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧ࠯ࠩၚ")+xHUYCr6JOXfK7DoegAasR84GV
	if G3Xh0YWACHFuvQLx5sVEfPjzq7 in [yobpaW7sBqtKRrv(u"ࠨࡪࡲࡷࡹ࠭ၛ"),beV5l2D8HznyJI0(u"ࠩࡱࡥࡲ࡫ࠧၜ")] and n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࠳ࠬၝ") in SPTqjsFBlCWXLgtoN: SPTqjsFBlCWXLgtoN = SPTqjsFBlCWXLgtoN.rsplit(beV5l2D8HznyJI0(u"ࠫ࠴࠭ၞ"),IMjqygdfYSKpHlWu5Aa(u"࠱ᖨ"))[wnaWTQM7VJPkZzO9eoSyFU4]
	if G3Xh0YWACHFuvQLx5sVEfPjzq7==tzZ6PhyDOUnwLM3pdK(u"ࠬࡴࡡ࡮ࡧࠪၟ") and oiWNFYzcIUeh(u"࠭࠮ࠨၠ") in SPTqjsFBlCWXLgtoN:
		UN8LxWZn5QOjRraDCu = SPTqjsFBlCWXLgtoN.split(pp7FcjEe6g(u"ࠧ࠯ࠩၡ"))
		s4sxCGQkfBI3jUm5 = len(UN8LxWZn5QOjRraDCu)
		if Z9FPQvwlbjLTh(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ၢ") in SPTqjsFBlCWXLgtoN: UN8LxWZn5QOjRraDCu = beV5l2D8HznyJI0(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧၣ")
		elif s4sxCGQkfBI3jUm5<=XURrDCfOS9Mbhpv2Pmjos56TeW: UN8LxWZn5QOjRraDCu = UN8LxWZn5QOjRraDCu[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		elif s4sxCGQkfBI3jUm5>=vXIdY7TwFKso40gVBq5: UN8LxWZn5QOjRraDCu = UN8LxWZn5QOjRraDCu[wnaWTQM7VJPkZzO9eoSyFU4]
		if len(UN8LxWZn5QOjRraDCu)>wnaWTQM7VJPkZzO9eoSyFU4: SPTqjsFBlCWXLgtoN = UN8LxWZn5QOjRraDCu
	return SPTqjsFBlCWXLgtoN
def QPFJWebEqtKMgTy(ZHr3lwOGBfPD):
	uuQIKSalH6kXFP4VD9dpZWO = repr(ZHr3lwOGBfPD.encode(e87cIA5vwOQLDEP1)).replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠥࠫࠧၤ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	return uuQIKSalH6kXFP4VD9dpZWO
def P74g5BI92vDdJEQN(c4meBr1jp8SvqP):
	vvxm8dwQfIMoiqHRrAslCcE5S1Ja = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if YVzokG2yZqrh3w8bU: c4meBr1jp8SvqP = c4meBr1jp8SvqP.decode(e87cIA5vwOQLDEP1)
	from unicodedata import decomposition as yjgesEoHhwI7BMQ41xW6Un
	for E2tJZz8bfO4YhgxQC16KliI7rapF in c4meBr1jp8SvqP:
		if   E2tJZz8bfO4YhgxQC16KliI7rapF==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࡹࠬศࠧၥ"): jjVJPTCGvew6aXurNSBRgFU5Qqd = kdRO82AImh0LFw(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭ၦ")
		elif E2tJZz8bfO4YhgxQC16KliI7rapF==aiQwFE1TGx04vmLcsYkIW5jA(u"ࡻࠧฤࠩၧ"): jjVJPTCGvew6aXurNSBRgFU5Qqd = mq5t9JXSdHT8yfDVF(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨၨ")
		elif E2tJZz8bfO4YhgxQC16KliI7rapF==ZLr5gRSkFewKdUos90bM(u"ࡶࠩวࠫၩ"): jjVJPTCGvew6aXurNSBRgFU5Qqd = mq5t9JXSdHT8yfDVF(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪၪ")
		elif E2tJZz8bfO4YhgxQC16KliI7rapF==ZLr5gRSkFewKdUos90bM(u"ࡸࠫส࠭ၫ"): jjVJPTCGvew6aXurNSBRgFU5Qqd = YYQS36fyPvtuzcEmRL(u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬၬ")
		elif E2tJZz8bfO4YhgxQC16KliI7rapF==IMjqygdfYSKpHlWu5Aa(u"ࡺ࠭ฦࠨၭ"): jjVJPTCGvew6aXurNSBRgFU5Qqd = VP70ytiFNMBl6vHDaW(u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧၮ")
		else:
			CvOSkRztTGQ4Bbx95qsDiyFZA = yjgesEoHhwI7BMQ41xW6Un(E2tJZz8bfO4YhgxQC16KliI7rapF)
			if kcXMWrwiLDKeBHRsJ in CvOSkRztTGQ4Bbx95qsDiyFZA: jjVJPTCGvew6aXurNSBRgFU5Qqd = iySORMYxWXszEH18(u"ࠧ࡝࡞ࡸࠫၯ")+CvOSkRztTGQ4Bbx95qsDiyFZA.split(kcXMWrwiLDKeBHRsJ,wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
			else:
				jjVJPTCGvew6aXurNSBRgFU5Qqd = kdRO82AImh0LFw(u"ࠨ࠲࠳࠴࠵࠭ၰ")+hex(ord(E2tJZz8bfO4YhgxQC16KliI7rapF)).replace(SI7eBdND4lx8pt5Qk(u"ࠩ࠳ࡼࠬၱ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				jjVJPTCGvew6aXurNSBRgFU5Qqd = gPE1XB87fQl(u"ࠪࡠࡡࡻࠧၲ")+jjVJPTCGvew6aXurNSBRgFU5Qqd[-yGLl1nSBrJPmi2adko9O:]
		vvxm8dwQfIMoiqHRrAslCcE5S1Ja += jjVJPTCGvew6aXurNSBRgFU5Qqd
	vvxm8dwQfIMoiqHRrAslCcE5S1Ja = vvxm8dwQfIMoiqHRrAslCcE5S1Ja.replace(rVy3Ops0mohYkT(u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬၳ"),Z9FPQvwlbjLTh(u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭ၴ"))
	if YVzokG2yZqrh3w8bU: vvxm8dwQfIMoiqHRrAslCcE5S1Ja = vvxm8dwQfIMoiqHRrAslCcE5S1Ja.decode(gPE1XB87fQl(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧၵ")).encode(e87cIA5vwOQLDEP1)
	else: vvxm8dwQfIMoiqHRrAslCcE5S1Ja = vvxm8dwQfIMoiqHRrAslCcE5S1Ja.encode(e87cIA5vwOQLDEP1).decode(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨၶ"))
	return vvxm8dwQfIMoiqHRrAslCcE5S1Ja
def x6S4MmiIE1hJ5bWUtdG02azC9Dgu(header=ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨၷ"),Y5OUcxSIr4gLBs=WnNGfosHr5STAq8j7miwyRZ6eOUbV,HkuRSa2lMPQmEcCx=KiryBCvngZzF85UN6xSDlOVweL4I9,source=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	HvzeZpTRrx9j1hMBV3 = PxtAoHE9sLngUWd7JjB8FVbZGa2T1(header,Y5OUcxSIr4gLBs,type=Zilvh2WQyb5.INPUT_ALPHANUM)
	HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3.strip(kcXMWrwiLDKeBHRsJ).replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	if not HvzeZpTRrx9j1hMBV3 and not HkuRSa2lMPQmEcCx:
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,KLX7hW0nBAEgy6m4SvH(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ၸ")+HvzeZpTRrx9j1hMBV3+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠦࠬၹ"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,bawK2j7T81Nrc4GWs05xzDg(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧၺ"))
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if HvzeZpTRrx9j1hMBV3 not in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,kcXMWrwiLDKeBHRsJ]:
		HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3.strip(kcXMWrwiLDKeBHRsJ)
		HvzeZpTRrx9j1hMBV3 = P74g5BI92vDdJEQN(HvzeZpTRrx9j1hMBV3)
	if source!=mq5t9JXSdHT8yfDVF(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧၻ") and e68y4a7LdjVsmIZDP51p3YQiqknBNA(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨၼ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,[HvzeZpTRrx9j1hMBV3],KiryBCvngZzF85UN6xSDlOVweL4I9):
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,tzZ6PhyDOUnwLM3pdK(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪၽ")+HvzeZpTRrx9j1hMBV3+tzZ6PhyDOUnwLM3pdK(u"ࠨࠤࠪၾ"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,tzZ6PhyDOUnwLM3pdK(u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫၿ"))
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,YYQS36fyPvtuzcEmRL(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ႀ")+HvzeZpTRrx9j1hMBV3+mq5t9JXSdHT8yfDVF(u"ࠫࠧ࠭ႁ"))
	return HvzeZpTRrx9j1hMBV3
def unQmLTC3MlKq(NTWE764hmOgUtScp2e8r,vcQbFfCk6T1,W67hPCcaOek094={}):
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA,ty7onT5Fj03vZCaMAJW8BPiI,CchrWkm9SGDuf8,fIxD8hvLH0wijaAnd1JS2mB3O = vcQbFfCk6T1,{},{},WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࢂࠧႂ") in vcQbFfCk6T1: kdNn2Zqsj4wPi5ThuoUQvtcg6OA,ty7onT5Fj03vZCaMAJW8BPiI = bJlfaY9rk80uXWZzV2oeNBcI(vcQbFfCk6T1,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡼࠨႃ"))
	Gltm03qa1fIOdN = list(set(list(W67hPCcaOek094.keys())+list(ty7onT5Fj03vZCaMAJW8BPiI.keys())))
	for lGdZS2mFX1PfHEr7Lt8I in Gltm03qa1fIOdN:
		if lGdZS2mFX1PfHEr7Lt8I in list(ty7onT5Fj03vZCaMAJW8BPiI.keys()): CchrWkm9SGDuf8[lGdZS2mFX1PfHEr7Lt8I] = ty7onT5Fj03vZCaMAJW8BPiI[lGdZS2mFX1PfHEr7Lt8I]
		else: CchrWkm9SGDuf8[lGdZS2mFX1PfHEr7Lt8I] = W67hPCcaOek094[lGdZS2mFX1PfHEr7Lt8I]
	if gPE1XB87fQl(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫႄ") not in Gltm03qa1fIOdN: CchrWkm9SGDuf8[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬႅ")] = E1ltCBVyML6PAUNY()
	if bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪႆ") not in Gltm03qa1fIOdN: CchrWkm9SGDuf8[gPE1XB87fQl(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫႇ")] = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡺࡸ࡬ࠨႈ"))
	if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧႉ") not in Gltm03qa1fIOdN: CchrWkm9SGDuf8[yobpaW7sBqtKRrv(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨႊ")] = YYQS36fyPvtuzcEmRL(u"ࠧࡦࡰ࠯ࡥࡷࡁࡱ࠾࠲࠱࠽ࠬႋ")
	for lGdZS2mFX1PfHEr7Lt8I in list(CchrWkm9SGDuf8.keys()): fIxD8hvLH0wijaAnd1JS2mB3O += A41nqbj3wYt(u"ࠨࠨࠪႌ")+lGdZS2mFX1PfHEr7Lt8I+YYQS36fyPvtuzcEmRL(u"ࠩࡀႍࠫ")+CchrWkm9SGDuf8[lGdZS2mFX1PfHEr7Lt8I]
	if fIxD8hvLH0wijaAnd1JS2mB3O: fIxD8hvLH0wijaAnd1JS2mB3O = A6iX18qgyOFlZxz7sc(u"ࠪࢀࠬႎ")+fIxD8hvLH0wijaAnd1JS2mB3O[wnaWTQM7VJPkZzO9eoSyFU4:]
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(A8MWZixP2YtOJ1no53mw,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡌࡋࡔࠨႏ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CchrWkm9SGDuf8,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ႐"),KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
	if VP70ytiFNMBl6vHDaW(u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ႑") not in VbRFshPMjr2t3k: return [ZLr5gRSkFewKdUos90bM(u"ࠧ࠮࠳ࠪ႒")],[kdNn2Zqsj4wPi5ThuoUQvtcg6OA+fIxD8hvLH0wijaAnd1JS2mB3O]
	if tzZ6PhyDOUnwLM3pdK(u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ႓") in VbRFshPMjr2t3k: return [mq5t9JXSdHT8yfDVF(u"ࠩ࠰࠵ࠬ႔")],[kdNn2Zqsj4wPi5ThuoUQvtcg6OA+fIxD8hvLH0wijaAnd1JS2mB3O]
	if VP70ytiFNMBl6vHDaW(u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ႕") in VbRFshPMjr2t3k: return [I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࠲࠷ࠧ႖")],[kdNn2Zqsj4wPi5ThuoUQvtcg6OA+fIxD8hvLH0wijaAnd1JS2mB3O]
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,uNPdgxCXYfraiJmRD25379h8zGEjyv,CCXF4kyfsijUbg = [],[],[],[]
	bbiBPLGW5cmhv = p7dwlH1PRStBgyMUW.findall(tzZ6PhyDOUnwLM3pdK(u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠲ࡏࡎࡇ࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭႗"),VbRFshPMjr2t3k+WBDnh75CaLEvkcN6p4ez2KXrV3M,p7dwlH1PRStBgyMUW.DOTALL)
	if not bbiBPLGW5cmhv: return [I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭࠭࠲ࠩ႘")],[kdNn2Zqsj4wPi5ThuoUQvtcg6OA+fIxD8hvLH0wijaAnd1JS2mB3O]
	for KiLwOk7QoMdJT8y6mf2hYBn1ActHXS,WLJhgkxQ0PpazH8n4veoSBZM in bbiBPLGW5cmhv:
		xW8qJR72ZGfskNjl9o1EFwHT,ufQ5elFnNp,DIBw28Qfje76bTMzVNYhxrgWmO = {},-jhDZ0BAFoEGUcw5QrJkaxXL(u"࠲ᖩ"),-jhDZ0BAFoEGUcw5QrJkaxXL(u"࠲ᖩ")
		ppVeJmYSox6g = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		rBXOyduTWGI = KiLwOk7QoMdJT8y6mf2hYBn1ActHXS.split(Z9FPQvwlbjLTh(u"ࠧ࠭ࠩ႙"))
		for o6r9VHUax2FMSKLRfCATb5k0n in rBXOyduTWGI:
			if tzZ6PhyDOUnwLM3pdK(u"ࠨ࠿ࠪႚ") in o6r9VHUax2FMSKLRfCATb5k0n:
				lGdZS2mFX1PfHEr7Lt8I,jSQ8Xqx9pBJIP5rCv2algzLb16 = o6r9VHUax2FMSKLRfCATb5k0n.split(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡀࠫႛ"),bawK2j7T81Nrc4GWs05xzDg(u"࠳ᖪ"))
				xW8qJR72ZGfskNjl9o1EFwHT[lGdZS2mFX1PfHEr7Lt8I.lower()] = jSQ8Xqx9pBJIP5rCv2algzLb16
		if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧႜ") in KiLwOk7QoMdJT8y6mf2hYBn1ActHXS.lower():
			ufQ5elFnNp = int(xW8qJR72ZGfskNjl9o1EFwHT[SI7eBdND4lx8pt5Qk(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨႝ")])//aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠴࠴࠷࠺ᖫ")
			ppVeJmYSox6g += str(ufQ5elFnNp)+SI7eBdND4lx8pt5Qk(u"ࠬࡱࡢࡱࡵࠣࠤࠬ႞")
		elif iySORMYxWXszEH18(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ႟") in KiLwOk7QoMdJT8y6mf2hYBn1ActHXS.lower():
			ufQ5elFnNp = int(xW8qJR72ZGfskNjl9o1EFwHT[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪႠ")])//A41nqbj3wYt(u"࠵࠵࠸࠴ᖬ")
			ppVeJmYSox6g += str(ufQ5elFnNp)+ZLr5gRSkFewKdUos90bM(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨႡ")
		if kdRO82AImh0LFw(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭Ⴂ") in KiLwOk7QoMdJT8y6mf2hYBn1ActHXS.lower():
			DIBw28Qfje76bTMzVNYhxrgWmO = int(xW8qJR72ZGfskNjl9o1EFwHT[YYQS36fyPvtuzcEmRL(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧႣ")].split(beV5l2D8HznyJI0(u"ࠫࡽ࠭Ⴄ"))[wnaWTQM7VJPkZzO9eoSyFU4])
			ppVeJmYSox6g += str(DIBw28Qfje76bTMzVNYhxrgWmO)+tTChquY7XSRg4e
		ppVeJmYSox6g = ppVeJmYSox6g.strip(tTChquY7XSRg4e)
		if not ppVeJmYSox6g: ppVeJmYSox6g = bawK2j7T81Nrc4GWs05xzDg(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭Ⴅ")
		if not WLJhgkxQ0PpazH8n4veoSBZM.startswith(mq5t9JXSdHT8yfDVF(u"࠭ࡨࡵࡶࡳࠫႦ")):
			if WLJhgkxQ0PpazH8n4veoSBZM.startswith(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧ࠰࠱ࠪႧ")): WLJhgkxQ0PpazH8n4veoSBZM = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࠼ࠪႨ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+gPE1XB87fQl(u"ࠩ࠽ࠫႩ")+WLJhgkxQ0PpazH8n4veoSBZM
			elif WLJhgkxQ0PpazH8n4veoSBZM.startswith(VP70ytiFNMBl6vHDaW(u"ࠪ࠳ࠬႪ")): WLJhgkxQ0PpazH8n4veoSBZM = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,pp7FcjEe6g(u"ࠫࡺࡸ࡬ࠨႫ"))+WLJhgkxQ0PpazH8n4veoSBZM
			else: WLJhgkxQ0PpazH8n4veoSBZM = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.rsplit(kdRO82AImh0LFw(u"ࠬ࠵ࠧႬ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+oiWNFYzcIUeh(u"࠭࠯ࠨႭ")+WLJhgkxQ0PpazH8n4veoSBZM
		if mq5t9JXSdHT8yfDVF(u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩႮ") in list(xW8qJR72ZGfskNjl9o1EFwHT.keys()):
			ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = xW8qJR72ZGfskNjl9o1EFwHT[wwWzyF4ZpSQXKOgk569(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪႯ")]
			ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr.replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠥࠫႰ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(rVy3Ops0mohYkT(u"ࠥࠫࠧႱ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).split(kdRO82AImh0LFw(u"ࠫࠨ࠭Ⴒ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			VDbTGIpvEYSedh06oZrxgOCKu5HzjJ = mm19wY7OfIvCxb8AFZEHJ(ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr)
			if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ: gPvxJw89S35R21zDIbpFYkq7A = ppVeJmYSox6g+tTChquY7XSRg4e+VDbTGIpvEYSedh06oZrxgOCKu5HzjJ
			else: gPvxJw89S35R21zDIbpFYkq7A = ppVeJmYSox6g
			gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A+VP70ytiFNMBl6vHDaW(u"ࠬࠦࠠࡑࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩࠬႳ")
			gPvxJw89S35R21zDIbpFYkq7A = gPvxJw89S35R21zDIbpFYkq7A+tTChquY7XSRg4e+OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,rVy3Ops0mohYkT(u"࠭࡮ࡢ࡯ࡨࠫႴ"))
			ZD0qItXg31HmC7KGEFn.append(gPvxJw89S35R21zDIbpFYkq7A)
			M0MFkiKqJDv1aZ4NA396u.append(ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr)
			uNPdgxCXYfraiJmRD25379h8zGEjyv.append(DIBw28Qfje76bTMzVNYhxrgWmO)
			CCXF4kyfsijUbg.append(ufQ5elFnNp)
		WLJhgkxQ0PpazH8n4veoSBZM = WLJhgkxQ0PpazH8n4veoSBZM.split(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࠤࠩႵ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		VDbTGIpvEYSedh06oZrxgOCKu5HzjJ = mm19wY7OfIvCxb8AFZEHJ(WLJhgkxQ0PpazH8n4veoSBZM)
		if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ: ppVeJmYSox6g = ppVeJmYSox6g+tTChquY7XSRg4e+VDbTGIpvEYSedh06oZrxgOCKu5HzjJ
		ppVeJmYSox6g = ppVeJmYSox6g+tTChquY7XSRg4e+OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(WLJhgkxQ0PpazH8n4veoSBZM,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡰࡤࡱࡪ࠭Ⴖ"))
		ZD0qItXg31HmC7KGEFn.append(ppVeJmYSox6g)
		M0MFkiKqJDv1aZ4NA396u.append(WLJhgkxQ0PpazH8n4veoSBZM)
		uNPdgxCXYfraiJmRD25379h8zGEjyv.append(DIBw28Qfje76bTMzVNYhxrgWmO)
		CCXF4kyfsijUbg.append(ufQ5elFnNp)
	bOl24a1PcFMgTZ0fzEoKN = list(zip(ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,uNPdgxCXYfraiJmRD25379h8zGEjyv,CCXF4kyfsijUbg))
	bOl24a1PcFMgTZ0fzEoKN = sorted(bOl24a1PcFMgTZ0fzEoKN, reverse=r0D4C3z7Onqpa, key=lambda key: key[vXIdY7TwFKso40gVBq5])
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u,uNPdgxCXYfraiJmRD25379h8zGEjyv,CCXF4kyfsijUbg = list(zip(*bOl24a1PcFMgTZ0fzEoKN))
	ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = list(ZD0qItXg31HmC7KGEFn),list(M0MFkiKqJDv1aZ4NA396u)
	CZ3H7wEGYM9uDFl5JIm4dgP0Tx = []
	for WLJhgkxQ0PpazH8n4veoSBZM in M0MFkiKqJDv1aZ4NA396u: CZ3H7wEGYM9uDFl5JIm4dgP0Tx.append(WLJhgkxQ0PpazH8n4veoSBZM+fIxD8hvLH0wijaAnd1JS2mB3O)
	t5FkRbmHMxvgnzQqYIOidNf8ySJ = list(zip(CZ3H7wEGYM9uDFl5JIm4dgP0Tx,[gPE1XB87fQl(u"ࠩࡧࡹࡲࡳࡹࠨႷ")]*len(CZ3H7wEGYM9uDFl5JIm4dgP0Tx),CCXF4kyfsijUbg))
	r8TjH9WNyRqnPflVEse31hcxi = YulwBtae3fh8DT0X64zd7(NTWE764hmOgUtScp2e8r,t5FkRbmHMxvgnzQqYIOidNf8ySJ)
	if r8TjH9WNyRqnPflVEse31hcxi:
		SOw5EUxC9k,PN2AmVoTyks5xOR1Ib9BqSQ,ufQ5elFnNp = r8TjH9WNyRqnPflVEse31hcxi[kdRO82AImh0LFw(u"࠵ᖭ")]
		index = CZ3H7wEGYM9uDFl5JIm4dgP0Tx.index(SOw5EUxC9k)
		title = ZD0qItXg31HmC7KGEFn[index]
		ZD0qItXg31HmC7KGEFn,CZ3H7wEGYM9uDFl5JIm4dgP0Tx = [title],[SOw5EUxC9k]
	return ZD0qItXg31HmC7KGEFn,CZ3H7wEGYM9uDFl5JIm4dgP0Tx
def ncBCmaR6ZUFADqfSlXuO(MPBOrQ7eap0mYAI6cEsKSZTjVy,Drx9ijtZIEezRk7mpVhlFL=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not Drx9ijtZIEezRk7mpVhlFL: Drx9ijtZIEezRk7mpVhlFL = A3pXVFdyP1.DNS_SERVERS[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if MPBOrQ7eap0mYAI6cEsKSZTjVy.replace(ZLr5gRSkFewKdUos90bM(u"ࠪ࠲ࠬႸ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).isdigit(): return [MPBOrQ7eap0mYAI6cEsKSZTjVy]
	from struct import pack as QQzYePA2bV6kBT5ocdEfm,unpack_from as YYbXs6R5hag08jQST1uCw2Gemv
	from socket import socket as ccvQsgXNMH,AF_INET as bdfnch1pv3,SOCK_DGRAM as M8MW3vEaF0pyLux74IqZgoPNKr
	try:
		mpgHwsZyiK89eTICNV0EO = QQzYePA2bV6kBT5ocdEfm(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠦࡃࡎࠢႹ"), n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠷࠲࠱࠶࠼ᖮ"))
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(pp7FcjEe6g(u"ࠧࡄࡈࠣႺ"), kdRO82AImh0LFw(u"࠲࠶࠸ᖯ"))
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(CyHU86ZeYT5BWRcitSm2I(u"ࠨ࠾ࡉࠤႻ"), wnaWTQM7VJPkZzO9eoSyFU4)
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠢ࠿ࡊࠥႼ"), j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(beV5l2D8HznyJI0(u"ࠣࡀࡋࠦႽ"), j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠤࡁࡌࠧႾ"), j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		if rJ2oTLqabRtA: krfEghd7KGLB2uZPqbI9 = MPBOrQ7eap0mYAI6cEsKSZTjVy.split(oiWNFYzcIUeh(u"ࠪ࠲ࠬႿ"))
		else: krfEghd7KGLB2uZPqbI9 = MPBOrQ7eap0mYAI6cEsKSZTjVy.decode(e87cIA5vwOQLDEP1).split(rVy3Ops0mohYkT(u"ࠫ࠳࠭Ⴠ"))
		for fSiB3TRArozEcG8q5IusVnNUWZP in krfEghd7KGLB2uZPqbI9:
			Mo7qeh64SGNfVdw = fSiB3TRArozEcG8q5IusVnNUWZP.encode(e87cIA5vwOQLDEP1)
			mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(kdRO82AImh0LFw(u"ࠧࡈࠢჁ"), len(fSiB3TRArozEcG8q5IusVnNUWZP))
			for ssG2489PndvhbKHAoZeyE in fSiB3TRArozEcG8q5IusVnNUWZP:
				mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡣࠣჂ"), ssG2489PndvhbKHAoZeyE.encode(e87cIA5vwOQLDEP1))
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(VP70ytiFNMBl6vHDaW(u"ࠢࡃࠤჃ"), j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠣࡀࡋࠦჄ"), wnaWTQM7VJPkZzO9eoSyFU4)
		mpgHwsZyiK89eTICNV0EO += QQzYePA2bV6kBT5ocdEfm(oiWNFYzcIUeh(u"ࠤࡁࡌࠧჅ"), wnaWTQM7VJPkZzO9eoSyFU4)
		xlHLGyPQZbwJu8nE49hitgMNF = ccvQsgXNMH(bdfnch1pv3,M8MW3vEaF0pyLux74IqZgoPNKr)
		xlHLGyPQZbwJu8nE49hitgMNF.sendto(bytes(mpgHwsZyiK89eTICNV0EO),(Drx9ijtZIEezRk7mpVhlFL,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠶࠵ᖰ")))
		xlHLGyPQZbwJu8nE49hitgMNF.settimeout(gPE1XB87fQl(u"࠸ᖱ"))
		N4HDrYcWePfI0yxjb2, xNyRKWw9UvsF = xlHLGyPQZbwJu8nE49hitgMNF.recvfrom(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠴࠴࠷࠺ᖲ"))
		xlHLGyPQZbwJu8nE49hitgMNF.close()
		ksiQPC8ZX9lJH4BbNzWrYLO = YYbXs6R5hag08jQST1uCw2Gemv(KLX7hW0nBAEgy6m4SvH(u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ჆"), N4HDrYcWePfI0yxjb2, j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
		DLj56pkCK2sHu3zIPRcYwUQiJFh = ksiQPC8ZX9lJH4BbNzWrYLO[vXIdY7TwFKso40gVBq5]
		rr2pIDLwSyczBCs3uoMgejWxqbi = len(MPBOrQ7eap0mYAI6cEsKSZTjVy)+YYQS36fyPvtuzcEmRL(u"࠵࠽ᖳ")
		V6lUXTqHAjQv4wg = []
		for _ViLuU78jtcWkpgT5n9M in range(DLj56pkCK2sHu3zIPRcYwUQiJFh):
			FFZq7EwoLgxsUdGSfm = rr2pIDLwSyczBCs3uoMgejWxqbi
			xpYsH45kelM02oTryhNXCB1dQ = wnaWTQM7VJPkZzO9eoSyFU4
			Sy20kpY8vlIaV4JXQAFRE3rf = KiryBCvngZzF85UN6xSDlOVweL4I9
			while r0D4C3z7Onqpa:
				ssG2489PndvhbKHAoZeyE = YYbXs6R5hag08jQST1uCw2Gemv(tzZ6PhyDOUnwLM3pdK(u"ࠦࡃࡈࠢჇ"), N4HDrYcWePfI0yxjb2, FFZq7EwoLgxsUdGSfm)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				if ssG2489PndvhbKHAoZeyE == j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
					FFZq7EwoLgxsUdGSfm += wnaWTQM7VJPkZzO9eoSyFU4
					break
				if ssG2489PndvhbKHAoZeyE >= pp7FcjEe6g(u"࠶࠿࠲ᖴ"):
					RyLqAXiVjBhY5Z2n = YYbXs6R5hag08jQST1uCw2Gemv(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡄࡂࠣ჈"), N4HDrYcWePfI0yxjb2, FFZq7EwoLgxsUdGSfm + wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					FFZq7EwoLgxsUdGSfm = ((ssG2489PndvhbKHAoZeyE << eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠾ᖵ")) + RyLqAXiVjBhY5Z2n - 0xc000) - wnaWTQM7VJPkZzO9eoSyFU4
					Sy20kpY8vlIaV4JXQAFRE3rf = r0D4C3z7Onqpa
				FFZq7EwoLgxsUdGSfm += wnaWTQM7VJPkZzO9eoSyFU4
				if Sy20kpY8vlIaV4JXQAFRE3rf == KiryBCvngZzF85UN6xSDlOVweL4I9: xpYsH45kelM02oTryhNXCB1dQ += wnaWTQM7VJPkZzO9eoSyFU4
			if Sy20kpY8vlIaV4JXQAFRE3rf == r0D4C3z7Onqpa: xpYsH45kelM02oTryhNXCB1dQ += wnaWTQM7VJPkZzO9eoSyFU4
			rr2pIDLwSyczBCs3uoMgejWxqbi = rr2pIDLwSyczBCs3uoMgejWxqbi + xpYsH45kelM02oTryhNXCB1dQ
			llTI0Qxrto5Z6n = YYbXs6R5hag08jQST1uCw2Gemv(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ࠾ࡉࡊࡌࡌࠧ჉"), N4HDrYcWePfI0yxjb2, rr2pIDLwSyczBCs3uoMgejWxqbi)
			rr2pIDLwSyczBCs3uoMgejWxqbi = rr2pIDLwSyczBCs3uoMgejWxqbi + ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠱࠱ᖶ")
			V0VWbdGfpLu = llTI0Qxrto5Z6n[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			HYj5wacVoDFE7lpORrI = llTI0Qxrto5Z6n[vXIdY7TwFKso40gVBq5]
			if V0VWbdGfpLu == wnaWTQM7VJPkZzO9eoSyFU4:
				fihsWJ6tBadAu = YYbXs6R5hag08jQST1uCw2Gemv(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠢ࠿ࠤ჊")+kdRO82AImh0LFw(u"ࠣࡄࠥ჋")*HYj5wacVoDFE7lpORrI, N4HDrYcWePfI0yxjb2, rr2pIDLwSyczBCs3uoMgejWxqbi)
				ip = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				for ssG2489PndvhbKHAoZeyE in fihsWJ6tBadAu: ip += str(ssG2489PndvhbKHAoZeyE) + jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ࠱ࠫ჌")
				ip = ip[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:-wnaWTQM7VJPkZzO9eoSyFU4]
				V6lUXTqHAjQv4wg.append(ip)
			if V0VWbdGfpLu in [wnaWTQM7VJPkZzO9eoSyFU4,XURrDCfOS9Mbhpv2Pmjos56TeW,SI7eBdND4lx8pt5Qk(u"࠸ᖹ"),A41nqbj3wYt(u"࠺ᖺ"),aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠸ᖸ"),GHg28TBchiyn6l(u"࠳࠺ᖷ")]: rr2pIDLwSyczBCs3uoMgejWxqbi = rr2pIDLwSyczBCs3uoMgejWxqbi + HYj5wacVoDFE7lpORrI
	except: V6lUXTqHAjQv4wg = []
	if not V6lUXTqHAjQv4wg: SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+gPE1XB87fQl(u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩჍ")+MPBOrQ7eap0mYAI6cEsKSZTjVy+gPE1XB87fQl(u"ࠫࠥࡣࠧ჎"))
	return V6lUXTqHAjQv4wg
def e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,oERLSh8HOe,showDialogs=r0D4C3z7Onqpa):
	if A3pXVFdyP1.avprivsnorestrict or not oERLSh8HOe: return KiryBCvngZzF85UN6xSDlOVweL4I9
	BQz3uIj85aqlVSYT = [aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡧࡤࡶ࡮ࡷࠫ჏"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠱࠹࠭ࠪა"),iySORMYxWXszEH18(u"ࠧࡹࡺࠪბ"),iySORMYxWXszEH18(u"ࠨࡲࡲࡶࡳ࠭გ"),oiWNFYzcIUeh(u"ࠩࡶࡩࡽ࠭დ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡲࡸ࡬ࡷࠨე"),YYQS36fyPvtuzcEmRL(u"ࠫࡲࡧࡴࡶࡴࡨࠫვ"),bawK2j7T81Nrc4GWs05xzDg(u"้ࠬศศำࠪზ"),beV5l2D8HznyJI0(u"࠭ศศๆ฽ࠫთ"),IMjqygdfYSKpHlWu5Aa(u"ࠧศสสั๏࠭ი"),mq5t9JXSdHT8yfDVF(u"ࠨฮ้ืࠬკ"),SI7eBdND4lx8pt5Qk(u"่้๋ࠩ๎ูࠨლ")]
	if NTWE764hmOgUtScp2e8r!=wwWzyF4ZpSQXKOgk569(u"ࠪࡆࡔࡑࡒࡂࠩმ"): BQz3uIj85aqlVSYT += [I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡷࡀࠧნ"),oiWNFYzcIUeh(u"ࠬࡀࡲࠨო"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡲ࠮ࠩპ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧ࠮ࡴࠪჟ"),A6iX18qgyOFlZxz7sc(u"ࠨ࠯ࡰࡥࠬრ"),Z9FPQvwlbjLTh(u"ࠩࡰࡥ࠲࠭ს")]
	for EEM4BOIPpHkDg5fm8lJnrbzs in oERLSh8HOe:
		EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.lower()
		if IMjqygdfYSKpHlWu5Aa(u"ࠪ࡫ࡪࡺ࠮ࡱࡪࡳࡃࠬტ") in EEM4BOIPpHkDg5fm8lJnrbzs: continue
		if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧუ") in EEM4BOIPpHkDg5fm8lJnrbzs: continue
		if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭ფ") in EEM4BOIPpHkDg5fm8lJnrbzs: continue
		if wwWzyF4ZpSQXKOgk569(u"࠭อๅไฬࠫქ") in EEM4BOIPpHkDg5fm8lJnrbzs: continue
		if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧ฻์ิࠤ๊฻ๆโࠩღ") in EEM4BOIPpHkDg5fm8lJnrbzs: continue
		EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.replace(rVy3Ops0mohYkT(u"ࠨลࠪყ"),gPE1XB87fQl(u"ࠩสࠫშ")).replace(oiWNFYzcIUeh(u"ࠪษࠬჩ"),kdRO82AImh0LFw(u"ࠫฬ࠭ც")).replace(IMjqygdfYSKpHlWu5Aa(u"ࠬศࠧძ"),pp7FcjEe6g(u"࠭วࠨწ")).replace(pp7FcjEe6g(u"ࠧ๏ࠩჭ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨํࠪხ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩ๒ࠫჯ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(VP70ytiFNMBl6vHDaW(u"ࠪ๔ࠬჰ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ๒࠭ჱ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬ๗ࠧჲ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.replace(pp7FcjEe6g(u"࠭เࠨჳ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(GHg28TBchiyn6l(u"ࠧ࠻ࠩჴ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if YVzokG2yZqrh3w8bU: EEM4BOIPpHkDg5fm8lJnrbzs = EEM4BOIPpHkDg5fm8lJnrbzs.decode(e87cIA5vwOQLDEP1).encode(e87cIA5vwOQLDEP1)
		jGnEVmPgtBrA8MufzTZqJxs6RFO = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮࠭ࠬჵ"),EEM4BOIPpHkDg5fm8lJnrbzs,p7dwlH1PRStBgyMUW.DOTALL)
		qRP01AoBWU = KiryBCvngZzF85UN6xSDlOVweL4I9
		for ZBcI5p6HWxGzgD1AYSUymhf in jGnEVmPgtBrA8MufzTZqJxs6RFO:
			if len(ZBcI5p6HWxGzgD1AYSUymhf)==XURrDCfOS9Mbhpv2Pmjos56TeW:
				qRP01AoBWU = r0D4C3z7Onqpa
				break
		if EEM4BOIPpHkDg5fm8lJnrbzs in [mq5t9JXSdHT8yfDVF(u"ࠩࡵࠫჶ")] or qRP01AoBWU or any(value in EEM4BOIPpHkDg5fm8lJnrbzs for value in BQz3uIj85aqlVSYT):
			SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+YYQS36fyPvtuzcEmRL(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩჷ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࠥࡣࠧჸ"))
			if showDialogs: uTaiRMI8eYmN(Ew26Hg4SIj,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧჹ"))
			return r0D4C3z7Onqpa
	return KiryBCvngZzF85UN6xSDlOVweL4I9
def E1ltCBVyML6PAUNY(FlTZD03hwasVYBGvxPA9zUfrcJd=r0D4C3z7Onqpa):
	if FlTZD03hwasVYBGvxPA9zUfrcJd:
		iHYO7Ic9kKUdPsgSCVyR = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,GHg28TBchiyn6l(u"࠭ࡳࡵࡴࠪჺ"),beV5l2D8HznyJI0(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬ჻"),bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫჼ"))
		if iHYO7Ic9kKUdPsgSCVyR: return iHYO7Ic9kKUdPsgSCVyR
	HvzeZpTRrx9j1hMBV3 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
		tJqAIFkchTU = VbRFshPMjr2t3k.count(beV5l2D8HznyJI0(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪჽ"))
		if tJqAIFkchTU>aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠽࠶ᖻ"):
			HvzeZpTRrx9j1hMBV3 = p7dwlH1PRStBgyMUW.findall(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬჾ"),VbRFshPMjr2t3k,p7dwlH1PRStBgyMUW.DOTALL)
			HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if not HvzeZpTRrx9j1hMBV3:
		Q1YIM2mOVB3Tac = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪჿ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭ᄀ"))
		HvzeZpTRrx9j1hMBV3 = open(Q1YIM2mOVB3Tac,oiWNFYzcIUeh(u"࠭ࡲࡣࠩᄁ")).read()
		if rJ2oTLqabRtA: HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3.decode(e87cIA5vwOQLDEP1)
		HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	WqpZsNgfBlYRAFb3467 = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨᄂ"),HvzeZpTRrx9j1hMBV3,p7dwlH1PRStBgyMUW.DOTALL)
	L7o0XEbWYZBHRJurPQOwyG = []
	for KiLwOk7QoMdJT8y6mf2hYBn1ActHXS in WqpZsNgfBlYRAFb3467:
		KpHRx7DuBw0Pz5lEdvTfJQ = KiLwOk7QoMdJT8y6mf2hYBn1ActHXS.lower()
		if rVy3Ops0mohYkT(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩᄃ") in KpHRx7DuBw0Pz5lEdvTfJQ: continue
		if IMjqygdfYSKpHlWu5Aa(u"ࠩࡸࡦࡺࡴࡴࡶࠩᄄ") in KpHRx7DuBw0Pz5lEdvTfJQ: continue
		if SI7eBdND4lx8pt5Qk(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪᄅ") in KpHRx7DuBw0Pz5lEdvTfJQ: continue
		if GHg28TBchiyn6l(u"ࠫࡨࡸ࡯ࡴࠩᄆ") in KpHRx7DuBw0Pz5lEdvTfJQ: continue
		L7o0XEbWYZBHRJurPQOwyG.append(KiLwOk7QoMdJT8y6mf2hYBn1ActHXS)
	iHYO7Ic9kKUdPsgSCVyR = FxEWL1w4gjr8mM.sample(L7o0XEbWYZBHRJurPQOwyG,wnaWTQM7VJPkZzO9eoSyFU4)
	iHYO7Ic9kKUdPsgSCVyR = iHYO7Ic9kKUdPsgSCVyR[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪᄇ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩᄈ"),iHYO7Ic9kKUdPsgSCVyR,nsFAzS2wvjyTYLOdDhfIiC0KGHE)
	return iHYO7Ic9kKUdPsgSCVyR
def JLyFwgKhoPdND9cMk(C2nN35DILUFzEKqv0BPl4eZjH6=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX==KiryBCvngZzF85UN6xSDlOVweL4I9: return
	if not C2nN35DILUFzEKqv0BPl4eZjH6: C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
	if CyHU86ZeYT5BWRcitSm2I(u"ࠧࡔࡻࡶࡸࡪࡳࡅࡹ࡫ࡷࠫᄉ") in C2nN35DILUFzEKqv0BPl4eZjH6 or oiWNFYzcIUeh(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫᄊ") in C2nN35DILUFzEKqv0BPl4eZjH6: return
	if C2nN35DILUFzEKqv0BPl4eZjH6!=QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᄋ"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
	bbiBPLGW5cmhv = C2nN35DILUFzEKqv0BPl4eZjH6.splitlines()
	OxvlAjSprB8IiE5 = bbiBPLGW5cmhv[-YYQS36fyPvtuzcEmRL(u"࠷ᖼ")]
	dlXhgTakfWJ3Lz2cDv5VOH = open(QqA6tL3TolUrzJf05MkR,gPE1XB87fQl(u"ࠪࡶࡧ࠭ᄌ")).read()
	if rJ2oTLqabRtA: dlXhgTakfWJ3Lz2cDv5VOH = dlXhgTakfWJ3Lz2cDv5VOH.decode(e87cIA5vwOQLDEP1)
	dlXhgTakfWJ3Lz2cDv5VOH = dlXhgTakfWJ3Lz2cDv5VOH[-wwWzyF4ZpSQXKOgk569(u"࠸࠱࠲࠳ᖽ"):]
	YzAtevgaKsZ0Vdbcr7xkw8E1S = ZLr5gRSkFewKdUos90bM(u"ࠫࡂ࠭ᄍ")*XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠲࠲࠳ᖾ")
	if YzAtevgaKsZ0Vdbcr7xkw8E1S in dlXhgTakfWJ3Lz2cDv5VOH: dlXhgTakfWJ3Lz2cDv5VOH = dlXhgTakfWJ3Lz2cDv5VOH.rsplit(YzAtevgaKsZ0Vdbcr7xkw8E1S,wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
	if OxvlAjSprB8IiE5 in dlXhgTakfWJ3Lz2cDv5VOH: dlXhgTakfWJ3Lz2cDv5VOH = dlXhgTakfWJ3Lz2cDv5VOH.rsplit(OxvlAjSprB8IiE5,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	mINB6gjDpFxM4OPE3057Tu91zqSa = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫᄎ"),dlXhgTakfWJ3Lz2cDv5VOH,p7dwlH1PRStBgyMUW.DOTALL)
	for CCpcXxBvdKrWHuIh6sJkltM5w0e1,ADN3XhW9ZpVmFK84j2roiy in reversed(mINB6gjDpFxM4OPE3057Tu91zqSa):
		if ADN3XhW9ZpVmFK84j2roiy: break
	else: ADN3XhW9ZpVmFK84j2roiy = pp7FcjEe6g(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ᄏ")
	a3aJE1T7OlBQDXCIi5SRYvo,KiLwOk7QoMdJT8y6mf2hYBn1ActHXS,aEr81v2kP5DnQAWsYgdptoizIcKLH = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	TyV1nzl5dp = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧ࡜ࡔࡗࡐࡢ࠭ᄐ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+ZLr5gRSkFewKdUos90bM(u"ࠨษ็า฼ษ࠺ࠡࠢࠪᄑ")+YVr6St5P4xsFC0aARQGKfiegD+OxvlAjSprB8IiE5
	rOYi4sNpFBlAvtC6LK = VP70ytiFNMBl6vHDaW(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᄒ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+beV5l2D8HznyJI0(u"ࠪห้๋ีะำ࠽ࠤࠥ࠭ᄓ")+YVr6St5P4xsFC0aARQGKfiegD+ADN3XhW9ZpVmFK84j2roiy
	for JJ9i76xytGNFZhrHVnDKSlpw0sA in reversed(bbiBPLGW5cmhv):
		if IMjqygdfYSKpHlWu5Aa(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫᄔ") in JJ9i76xytGNFZhrHVnDKSlpw0sA and bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᄕ") in JJ9i76xytGNFZhrHVnDKSlpw0sA: break
	JJ9i76xytGNFZhrHVnDKSlpw0sA = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩᄖ"),JJ9i76xytGNFZhrHVnDKSlpw0sA,p7dwlH1PRStBgyMUW.DOTALL)
	if JJ9i76xytGNFZhrHVnDKSlpw0sA:
		a3aJE1T7OlBQDXCIi5SRYvo,KiLwOk7QoMdJT8y6mf2hYBn1ActHXS,aEr81v2kP5DnQAWsYgdptoizIcKLH = JJ9i76xytGNFZhrHVnDKSlpw0sA[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if rVy3Ops0mohYkT(u"ࠧ࠰ࠩᄗ") in a3aJE1T7OlBQDXCIi5SRYvo: a3aJE1T7OlBQDXCIi5SRYvo = a3aJE1T7OlBQDXCIi5SRYvo.rsplit(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠱ࠪᄘ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
		else: a3aJE1T7OlBQDXCIi5SRYvo = a3aJE1T7OlBQDXCIi5SRYvo.rsplit(Z9FPQvwlbjLTh(u"ࠩ࡟ࡠࠬᄙ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
		GXb78DQ9Lm = wwWzyF4ZpSQXKOgk569(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩᄚ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+ZLr5gRSkFewKdUos90bM(u"ࠫฬ๊ๅๅใ࠽ࠤࠥ࠭ᄛ")+YVr6St5P4xsFC0aARQGKfiegD+a3aJE1T7OlBQDXCIi5SRYvo
		kXjv6JgQi3 = ZLr5gRSkFewKdUos90bM(u"ࠬࡡࡒࡕࡎࡠࠫᄜ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭วๅีฺี࠿ࠦࠠࠨᄝ")+YVr6St5P4xsFC0aARQGKfiegD+KiLwOk7QoMdJT8y6mf2hYBn1ActHXS
		XBFuERrIM1sfhaxS = yobpaW7sBqtKRrv(u"ࠧ࡜ࡔࡗࡐࡢ࠭ᄞ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+SI7eBdND4lx8pt5Qk(u"ࠨษ็้่อๆ࠻ࠢࠣࠫᄟ")+YVr6St5P4xsFC0aARQGKfiegD+aEr81v2kP5DnQAWsYgdptoizIcKLH
		MPyvt9SrHg6fIXwhQds = GXb78DQ9Lm+WBDnh75CaLEvkcN6p4ez2KXrV3M+kXjv6JgQi3+WBDnh75CaLEvkcN6p4ez2KXrV3M+XBFuERrIM1sfhaxS+WBDnh75CaLEvkcN6p4ez2KXrV3M+rOYi4sNpFBlAvtC6LK+WBDnh75CaLEvkcN6p4ez2KXrV3M+TyV1nzl5dp
		VL1Zd7NaYMh = kXjv6JgQi3+WBDnh75CaLEvkcN6p4ez2KXrV3M+rOYi4sNpFBlAvtC6LK+WBDnh75CaLEvkcN6p4ez2KXrV3M+TyV1nzl5dp+WBDnh75CaLEvkcN6p4ez2KXrV3M+GXb78DQ9Lm+WBDnh75CaLEvkcN6p4ez2KXrV3M+XBFuERrIM1sfhaxS
		x4U2Gv1dfPhCcnYEDOilFjVo0IzrM = kXjv6JgQi3+WBDnh75CaLEvkcN6p4ez2KXrV3M+TyV1nzl5dp+WBDnh75CaLEvkcN6p4ez2KXrV3M+GXb78DQ9Lm+WBDnh75CaLEvkcN6p4ez2KXrV3M+XBFuERrIM1sfhaxS
	else:
		GXb78DQ9Lm,kXjv6JgQi3,XBFuERrIM1sfhaxS = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		MPyvt9SrHg6fIXwhQds = rOYi4sNpFBlAvtC6LK+IMjqygdfYSKpHlWu5Aa(u"ࠩ࡟ࡲࡡࡴࠧᄠ")+TyV1nzl5dp
		VL1Zd7NaYMh = rOYi4sNpFBlAvtC6LK+iySORMYxWXszEH18(u"ࠪࡠࡳࡢ࡮ࠨᄡ")+TyV1nzl5dp
		x4U2Gv1dfPhCcnYEDOilFjVo0IzrM = TyV1nzl5dp
	X1jzM5Ywq9 = Z9FPQvwlbjLTh(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨᄢ")+WBDnh75CaLEvkcN6p4ez2KXrV3M
	qqUuljAhJT7vpEC0tg2OsXmFxo5Q6 = pk2vGe1ylfCsPMcSBRYJ960()
	BCR4K0TeZdMU = []
	APpdhB1Fk58MmJH7CjVntowyaY = qqUuljAhJT7vpEC0tg2OsXmFxo5Q6[yobpaW7sBqtKRrv(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᄣ")]
	KQLwpC7MUmXxY4Tvs1lIdrgjq08iV = ntRMkXUgfrBja(mbvW9By35UDO)
	if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᄤ") in list(qqUuljAhJT7vpEC0tg2OsXmFxo5Q6.keys()):
		for Yit5dk8Qm9EKvUDzb3,J7iQmjgcZnkadbxBC63O0Ee,IncgJuvPCxmw3aQOMYZVzoLk in APpdhB1Fk58MmJH7CjVntowyaY:
			BCR4K0TeZdMU = max(BCR4K0TeZdMU,J7iQmjgcZnkadbxBC63O0Ee)
		if KQLwpC7MUmXxY4Tvs1lIdrgjq08iV<BCR4K0TeZdMU:
			fUQ2tkhneHwFLEC = mq5t9JXSdHT8yfDVF(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪᄥ")
			tt2NkXu7HgTIAyj09OBlod3YDpz = tFVmMznSUR3XupZBN9kxcO0EHv(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡴ࡬࡫࡭ࡺࠧᄦ"),VP70ytiFNMBl6vHDaW(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ᄧ"),oiWNFYzcIUeh(u"ࠪฮาี๊ฬࠩᄨ"),Z9FPQvwlbjLTh(u"ࠫำื่อࠩᄩ"),X1jzM5Ywq9+fUQ2tkhneHwFLEC,MPyvt9SrHg6fIXwhQds)
			if tt2NkXu7HgTIAyj09OBlod3YDpz==wnaWTQM7VJPkZzO9eoSyFU4:
				import GkCs6wbiQP
				GkCs6wbiQP.pBw9TxneIRC8(r0D4C3z7Onqpa)
				sm0xF8WoGavE7iNjd()
			elif tt2NkXu7HgTIAyj09OBlod3YDpz==XURrDCfOS9Mbhpv2Pmjos56TeW: sm0xF8WoGavE7iNjd()
	jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,iySORMYxWXszEH18(u"ࠬࡲࡩࡴࡶࠪᄪ"),oiWNFYzcIUeh(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩᄫ"),ZLr5gRSkFewKdUos90bM(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩᄬ"))
	if not jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv: jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv = []
	VL1Zd7NaYMh = VL1Zd7NaYMh.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,oiWNFYzcIUeh(u"ࠨ࡞࡟ࡲࠬᄭ")).replace(A41nqbj3wYt(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᄮ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	x4U2Gv1dfPhCcnYEDOilFjVo0IzrM = x4U2Gv1dfPhCcnYEDOilFjVo0IzrM.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡠࡡࡴࠧᄯ")).replace(KLX7hW0nBAEgy6m4SvH(u"ࠫࡠࡘࡔࡍ࡟ࠪᄰ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	bdi1sM29zG = mbvW9By35UDO+yobpaW7sBqtKRrv(u"ࠬࡀ࠺ࠨᄱ")+x4U2Gv1dfPhCcnYEDOilFjVo0IzrM
	if bdi1sM29zG in jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv:
		fUQ2tkhneHwFLEC = CyHU86ZeYT5BWRcitSm2I(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫᄲ")
		BGQXvd2lsicjVTgnHYRo74qDI3z(yobpaW7sBqtKRrv(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᄳ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,X1jzM5Ywq9+fUQ2tkhneHwFLEC,MPyvt9SrHg6fIXwhQds)
		return
	MMVSpYUTyGbAxuR = str(CCPXJ7wnNLOg0ZoekcmpdSKI).split(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠰ࠪᄴ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = A3pXVFdyP1.SITESURLS[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᄵ")][YYQS36fyPvtuzcEmRL(u"࠸ᖿ")]
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,pp7FcjEe6g(u"ࠪࡔࡔ࡙ࡔࠨᄶ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬᄷ"),KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
	l29sVQ8ieaT53Dbku = p7dwlH1PRStBgyMUW.findall(aiQwFE1TGx04vmLcsYkIW5jA(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬᄸ"),VbRFshPMjr2t3k,p7dwlH1PRStBgyMUW.DOTALL)
	for O74g6wQAYSlXT1uvktI9DZi5f,kVP7TROJ2pa0UZAHLS,EO9dfQsR1M7nCcAeBoIrVzG,ERZpzMOkPySu8j9rhTUgolwDHVAvNX in l29sVQ8ieaT53Dbku:
		O74g6wQAYSlXT1uvktI9DZi5f = O74g6wQAYSlXT1uvktI9DZi5f.split(oiWNFYzcIUeh(u"࠭ࠫࠨᄹ"))
		EO9dfQsR1M7nCcAeBoIrVzG = EO9dfQsR1M7nCcAeBoIrVzG.split(CyHU86ZeYT5BWRcitSm2I(u"ࠧࠬࠩᄺ"))
		ERZpzMOkPySu8j9rhTUgolwDHVAvNX = ERZpzMOkPySu8j9rhTUgolwDHVAvNX.split(mq5t9JXSdHT8yfDVF(u"ࠨ࠭ࠪᄻ"))
		if KiLwOk7QoMdJT8y6mf2hYBn1ActHXS in O74g6wQAYSlXT1uvktI9DZi5f and OxvlAjSprB8IiE5==kVP7TROJ2pa0UZAHLS and mbvW9By35UDO in EO9dfQsR1M7nCcAeBoIrVzG and MMVSpYUTyGbAxuR in ERZpzMOkPySu8j9rhTUgolwDHVAvNX:
			fUQ2tkhneHwFLEC = A6iX18qgyOFlZxz7sc(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧᄼ")
			kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(beV5l2D8HznyJI0(u"ࠪࡶ࡮࡭ࡨࡵࠩᄽ"),gPE1XB87fQl(u"ࠫำื่อࠩᄾ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩᄿ"),X1jzM5Ywq9+fUQ2tkhneHwFLEC,MPyvt9SrHg6fIXwhQds)
			if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4: BGQXvd2lsicjVTgnHYRo74qDI3z(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅀ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fUQ2tkhneHwFLEC)
			return
	fUQ2tkhneHwFLEC = kdRO82AImh0LFw(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧᅁ")
	choice = tFVmMznSUR3XupZBN9kxcO0EHv(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡴ࡬࡫࡭ࡺࠧᅂ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ᅃ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪฮาี๊ฬࠢฯึห๐ࠧᅄ"),CyHU86ZeYT5BWRcitSm2I(u"ࠫฯำฯ๋อࠣห้ฮั็ษ่ะࠬᅅ"),X1jzM5Ywq9+fUQ2tkhneHwFLEC,MPyvt9SrHg6fIXwhQds)
	if choice==wnaWTQM7VJPkZzO9eoSyFU4:
		yngExXLFuWw4(KiryBCvngZzF85UN6xSDlOVweL4I9)
		uTaiRMI8eYmN(beV5l2D8HznyJI0(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠣห้าาว์ࠪᅆ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ํࡔࡷࡦࡧࡪࡹࡳࠨᅇ"),x54xSdnCFHZ8yliofzOBK=ZLr5gRSkFewKdUos90bM(u"࠺࠹࠵ᗀ"))
		sm0xF8WoGavE7iNjd()
	elif choice==XURrDCfOS9Mbhpv2Pmjos56TeW:
		import GkCs6wbiQP
		GkCs6wbiQP.pBw9TxneIRC8(r0D4C3z7Onqpa)
		sm0xF8WoGavE7iNjd()
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(Z9FPQvwlbjLTh(u"ࠧࡤࡧࡱࡸࡪࡸࠧᅈ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩᅉ"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4: UlaT09rIgR8CWpExstHDvVz6jyG1Km = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬᅊ")
	else:
		BGQXvd2lsicjVTgnHYRo74qDI3z(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡧࡪࡴࡴࡦࡴࠪᅋ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,RNWqL0gBbKOie1DxjUpzQPh9aZyHX+mq5t9JXSdHT8yfDVF(u"ࠫฯ๋ࠠฦๆ฽หฦࠦลาีส่ࠥอไฯูฦࠫᅌ")+YVr6St5P4xsFC0aARQGKfiegD+SI7eBdND4lx8pt5Qk(u"ࠬࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨᅍ"))
		return
	Wab7p2BCHfVhE34Q9mUO = VL1Zd7NaYMh
	import GkCs6wbiQP
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = GkCs6wbiQP.JbaHBRQsVkIGZ7(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡅࡳࡴࡲࡶࡸ࠭ᅎ"),Wab7p2BCHfVhE34Q9mUO,r0D4C3z7Onqpa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧᅏ"),UlaT09rIgR8CWpExstHDvVz6jyG1Km)
	if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy and UlaT09rIgR8CWpExstHDvVz6jyG1Km:
		jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv.append(bdi1sM29zG)
		w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,iySORMYxWXszEH18(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫᅐ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫᅑ"),jjQZ7LAFWwxXCORyalsSPtUq5nJ4cv,iXBqSkDU3mRCZf4Ib)
	return
def KOfFJEmMPD3bV(N4HDrYcWePfI0yxjb2,filename=OHohTgj06taKzsG):
	x54xSdnCFHZ8yliofzOBK.sleep(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠴࠳࠶࠲࠶ᗁ"))
	if rJ2oTLqabRtA: N4HDrYcWePfI0yxjb2 = N4HDrYcWePfI0yxjb2.encode(e87cIA5vwOQLDEP1)
	if not filename: LLipmUFe3789Mc5Q6s0CBVznIbRXgh = beV5l2D8HznyJI0(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪᅒ")+str(x54xSdnCFHZ8yliofzOBK.time())+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠳ࡪࡡࡵࠩᅓ")
	else: LLipmUFe3789Mc5Q6s0CBVznIbRXgh = pp7FcjEe6g(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬᅔ")+filename+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠮ࡥࡣࡷࠫᅕ")
	open(LLipmUFe3789Mc5Q6s0CBVznIbRXgh,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡸࡤࠪᅖ")).write(N4HDrYcWePfI0yxjb2)
	return
def aaSudEO2gkDPeTi41ZMbYtKoNs70l(lgB7TOZqEJiMUFedrSHX8j6):
	if lgB7TOZqEJiMUFedrSHX8j6:
		oxIMPKyikLHUVdQNTzOWs5S813g = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡮࡬ࡷࡹ࠭ᅗ"),A6iX18qgyOFlZxz7sc(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᅘ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ᅙ"))
		if oxIMPKyikLHUVdQNTzOWs5S813g: return oxIMPKyikLHUVdQNTzOWs5S813g
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = A3pXVFdyP1.SITESURLS[kdRO82AImh0LFw(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᅚ")][aiQwFE1TGx04vmLcsYkIW5jA(u"࠺ᗂ")]
	ofEcIgWvaQizr9uTq8LBApwH0 = kNR9wHFiUYQntWAly(KiryBCvngZzF85UN6xSDlOVweL4I9) if not lgB7TOZqEJiMUFedrSHX8j6 else A3pXVFdyP1.AV_CLIENT_IDS
	XCxufKnQs0SDkWY = UwIPdKQt4YDfoJM()
	l7L3xtUSXrRAV6nwEMpBv4yimKc0H9 = XCxufKnQs0SDkWY.split(rVy3Ops0mohYkT(u"ࠬ࠲ࠧᅛ"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
	oX9rUhfKAiQj1Sgt53 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,iySORMYxWXszEH18(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᅜ"))
	Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF = P03eVFBZQTxjOnLN6R()
	hBkVcq0AG3MJpaE58Q = {ZLr5gRSkFewKdUos90bM(u"ࠧࡶࡵࡨࡶࠬᅝ"):ofEcIgWvaQizr9uTq8LBApwH0,kdRO82AImh0LFw(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᅞ"):mbvW9By35UDO,tzZ6PhyDOUnwLM3pdK(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᅟ"):l7L3xtUSXrRAV6nwEMpBv4yimKc0H9,beV5l2D8HznyJI0(u"ࠪ࡭ࡩࡹࠧᅠ"):hhjzYAw9aeTWbu3KDJ5sy(Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF)}
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,YYQS36fyPvtuzcEmRL(u"ࠫࡕࡕࡓࡕࠩᅡ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,hBkVcq0AG3MJpaE58Q,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠳࠱ࡴࡶࠪᅢ"))
	oxIMPKyikLHUVdQNTzOWs5S813g = []
	if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
		oxIMPKyikLHUVdQNTzOWs5S813g = VbRFshPMjr2t3k.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭࡜࡝ࡴࠪᅣ"),WBDnh75CaLEvkcN6p4ez2KXrV3M).replace(A41nqbj3wYt(u"ࠧ࡝࡞ࡱࠫᅤ"),WBDnh75CaLEvkcN6p4ez2KXrV3M).replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡞ࡵࡠࡳ࠭ᅥ"),WBDnh75CaLEvkcN6p4ez2KXrV3M).replace(TTLxlKI0gNfh7FP,WBDnh75CaLEvkcN6p4ez2KXrV3M)
		oxIMPKyikLHUVdQNTzOWs5S813g = p7dwlH1PRStBgyMUW.findall(bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬᅦ"),oxIMPKyikLHUVdQNTzOWs5S813g,p7dwlH1PRStBgyMUW.DOTALL)
		if oxIMPKyikLHUVdQNTzOWs5S813g:
			oxIMPKyikLHUVdQNTzOWs5S813g = sorted(oxIMPKyikLHUVdQNTzOWs5S813g,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: int(key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]))
			m5XtY37nVSIb2,ofEcIgWvaQizr9uTq8LBApwH0,M9yafHSnNLJowPBFc7WXOgIekrbzE,V6lUXTqHAjQv4wg,Sse7u20tJZbUkIP8Ncm,PPSTwoZdRinA3YXtybaeVux9Om0E = oxIMPKyikLHUVdQNTzOWs5S813g[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			S5AkKRD2yU37ojw6alXEPseTpFigC = PPSTwoZdRinA3YXtybaeVux9Om0E if A3pXVFdyP1.avprivslongperiod else M9yafHSnNLJowPBFc7WXOgIekrbzE
			G3yDpvxOiSWdAeL.setSetting(ZLr5gRSkFewKdUos90bM(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬᅧ"),S5AkKRD2yU37ojw6alXEPseTpFigC)
			w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,YYQS36fyPvtuzcEmRL(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩᅨ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᅩ"),oxIMPKyikLHUVdQNTzOWs5S813g,nsFAzS2wvjyTYLOdDhfIiC0KGHE)
			G3yDpvxOiSWdAeL.setSetting(SI7eBdND4lx8pt5Qk(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨᅪ"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
	return oxIMPKyikLHUVdQNTzOWs5S813g
def WOtb70sz5v6CAg9FDof8HMTI(rBXOyduTWGI,uuAgFRkEpKibXhQy=j0jEZgiKdxFpMLHcU7kQr8v1lyX4,jaovdC6YIFQ50DRKfk=j0jEZgiKdxFpMLHcU7kQr8v1lyX4):
	if uuAgFRkEpKibXhQy and not jaovdC6YIFQ50DRKfk: jaovdC6YIFQ50DRKfk = len(rBXOyduTWGI)//uuAgFRkEpKibXhQy
	RygOEZ2kDoNAmt,zuEo6GDeAR5Z,f0Q5l2rT8DWHIFkauPL4So9X3vKiR = [],-wnaWTQM7VJPkZzO9eoSyFU4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	for o6r9VHUax2FMSKLRfCATb5k0n in rBXOyduTWGI:
		if f0Q5l2rT8DWHIFkauPL4So9X3vKiR%jaovdC6YIFQ50DRKfk==j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			zuEo6GDeAR5Z += wnaWTQM7VJPkZzO9eoSyFU4
			RygOEZ2kDoNAmt.append([])
		RygOEZ2kDoNAmt[zuEo6GDeAR5Z].append(o6r9VHUax2FMSKLRfCATb5k0n)
		f0Q5l2rT8DWHIFkauPL4So9X3vKiR += wnaWTQM7VJPkZzO9eoSyFU4
	return RygOEZ2kDoNAmt
def EVznjWeyNYvqHhbAakowxFmiJ94C8M(LLipmUFe3789Mc5Q6s0CBVznIbRXgh,N4HDrYcWePfI0yxjb2):
	CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,LLipmUFe3789Mc5Q6s0CBVznIbRXgh)
	if wnaWTQM7VJPkZzO9eoSyFU4 or kdRO82AImh0LFw(u"ࠧࡊࡒࡗ࡚ࡤ࠭ᅫ") not in LLipmUFe3789Mc5Q6s0CBVznIbRXgh or jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡏ࠶࡙ࡤ࠭ᅬ") not in LLipmUFe3789Mc5Q6s0CBVznIbRXgh: HvzeZpTRrx9j1hMBV3 = str(N4HDrYcWePfI0yxjb2)
	else:
		RygOEZ2kDoNAmt = WOtb70sz5v6CAg9FDof8HMTI(N4HDrYcWePfI0yxjb2,tzZ6PhyDOUnwLM3pdK(u"࠾ᗃ"))
		HvzeZpTRrx9j1hMBV3 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		for XOUmRox5ns4vMaj3Z in RygOEZ2kDoNAmt:
			HvzeZpTRrx9j1hMBV3 += str(XOUmRox5ns4vMaj3Z)+pp7FcjEe6g(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨᅭ")
		HvzeZpTRrx9j1hMBV3 = HvzeZpTRrx9j1hMBV3.strip(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᅮ"))
	h8gLfHAKGywXzBpq35vTa = eSQGo07L2IFWJRKYwV8s.compress(HvzeZpTRrx9j1hMBV3)
	open(CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡼࡨࠧᅯ")).write(h8gLfHAKGywXzBpq35vTa)
	return
def JUYtzcOu94C8a(OYsxCijpVEWowUIZLkJ9,LLipmUFe3789Mc5Q6s0CBVznIbRXgh):
	if OYsxCijpVEWowUIZLkJ9==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡪࡩࡤࡶࠪᅰ"): N4HDrYcWePfI0yxjb2 = {}
	elif OYsxCijpVEWowUIZLkJ9==kdRO82AImh0LFw(u"࠭࡬ࡪࡵࡷࠫᅱ"): N4HDrYcWePfI0yxjb2 = []
	elif OYsxCijpVEWowUIZLkJ9==wwWzyF4ZpSQXKOgk569(u"ࠧࡴࡶࡵࠫᅲ"): N4HDrYcWePfI0yxjb2 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	elif OYsxCijpVEWowUIZLkJ9==yobpaW7sBqtKRrv(u"ࠨ࡫ࡱࡸࠬᅳ"): N4HDrYcWePfI0yxjb2 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	else: N4HDrYcWePfI0yxjb2 = OHohTgj06taKzsG
	CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,LLipmUFe3789Mc5Q6s0CBVznIbRXgh)
	h8gLfHAKGywXzBpq35vTa = open(CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd,mq5t9JXSdHT8yfDVF(u"ࠩࡵࡦࠬᅴ")).read()
	HvzeZpTRrx9j1hMBV3 = eSQGo07L2IFWJRKYwV8s.decompress(h8gLfHAKGywXzBpq35vTa)
	if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᅵ") not in HvzeZpTRrx9j1hMBV3: N4HDrYcWePfI0yxjb2 = eval(HvzeZpTRrx9j1hMBV3)
	else:
		RygOEZ2kDoNAmt = HvzeZpTRrx9j1hMBV3.split(A41nqbj3wYt(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪᅶ"))
		del HvzeZpTRrx9j1hMBV3
		N4HDrYcWePfI0yxjb2 = []
		z1NgC5mPGXtABTDKp804MjwvFL = ouEV7ZMghRakP24()
		m5XtY37nVSIb2 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		for XOUmRox5ns4vMaj3Z in RygOEZ2kDoNAmt:
			z1NgC5mPGXtABTDKp804MjwvFL.d7ViqDHmpxfQ3OFaJe(str(m5XtY37nVSIb2),eval,XOUmRox5ns4vMaj3Z)
			m5XtY37nVSIb2 += wnaWTQM7VJPkZzO9eoSyFU4
		del RygOEZ2kDoNAmt
		z1NgC5mPGXtABTDKp804MjwvFL.vLyghNQioJMK()
		z1NgC5mPGXtABTDKp804MjwvFL.tTOlrFioz7KHs()
		TgulXjvWI1DFfeB98P = list(z1NgC5mPGXtABTDKp804MjwvFL.resultsDICT.keys())
		aP5vpm9enruFJDtO8 = sorted(TgulXjvWI1DFfeB98P,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: int(key))
		for m5XtY37nVSIb2 in aP5vpm9enruFJDtO8:
			N4HDrYcWePfI0yxjb2 += z1NgC5mPGXtABTDKp804MjwvFL.resultsDICT[m5XtY37nVSIb2]
	return N4HDrYcWePfI0yxjb2
def WZemINP9VnBlfDSu(B40Qr5hlSgNm1kuXD3ZFpnyC9):
	fxNRbi5IM91 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡧࡤࡥࡱࡱࡷࠬᅷ"),B40Qr5hlSgNm1kuXD3ZFpnyC9,SI7eBdND4lx8pt5Qk(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩᅸ"))
	try: nEV3ibGlT67U52RLMPJh8uY = open(fxNRbi5IM91,beV5l2D8HznyJI0(u"ࠧࡳࡤࠪᅹ")).read()
	except:
		jOAQTzDFbBlkNCLY1RWhd8KpM09aJZ = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(ONKoA9BL4tW5UX,iySORMYxWXszEH18(u"ࠨࡣࡧࡨࡴࡴࡳࠨᅺ"),B40Qr5hlSgNm1kuXD3ZFpnyC9,Z9FPQvwlbjLTh(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬᅻ"))
		try: nEV3ibGlT67U52RLMPJh8uY = open(jOAQTzDFbBlkNCLY1RWhd8KpM09aJZ,Z9FPQvwlbjLTh(u"ࠪࡶࡧ࠭ᅼ")).read()
		except: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	if rJ2oTLqabRtA: nEV3ibGlT67U52RLMPJh8uY = nEV3ibGlT67U52RLMPJh8uY.decode(e87cIA5vwOQLDEP1)
	BAywvQXbl4xR6ONMHFJ1ZTuU = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨᅽ"),nEV3ibGlT67U52RLMPJh8uY,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
	if not BAywvQXbl4xR6ONMHFJ1ZTuU: return WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	MYymqUE1tRQ2aD,WPRQMB9xuw53NLHSd2zTqFytgYEj = BAywvQXbl4xR6ONMHFJ1ZTuU[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],ntRMkXUgfrBja(BAywvQXbl4xR6ONMHFJ1ZTuU[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
	return MYymqUE1tRQ2aD,WPRQMB9xuw53NLHSd2zTqFytgYEj
def pk2vGe1ylfCsPMcSBRYJ960():
	cW7CrduEmznbV3pTXlqag2BFkUw = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,gPE1XB87fQl(u"ࠬࡪࡩࡤࡶࠪᅾ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫᅿ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨᆀ"))
	if cW7CrduEmznbV3pTXlqag2BFkUw: return cW7CrduEmznbV3pTXlqag2BFkUw
	qqUuljAhJT7vpEC0tg2OsXmFxo5Q6,cW7CrduEmznbV3pTXlqag2BFkUw = {},{}
	mINB6gjDpFxM4OPE3057Tu91zqSa = [A3pXVFdyP1.SITESURLS[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡔࡈࡔࡔ࡙ࠧᆁ")][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
	if CCPXJ7wnNLOg0ZoekcmpdSKI>jhDZ0BAFoEGUcw5QrJkaxXL(u"࠱࠸࠰࠼࠽ᗄ"): mINB6gjDpFxM4OPE3057Tu91zqSa.append(A3pXVFdyP1.SITESURLS[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡕࡉࡕࡕࡓࠨᆂ")][wnaWTQM7VJPkZzO9eoSyFU4])
	if rJ2oTLqabRtA: mINB6gjDpFxM4OPE3057Tu91zqSa.append(A3pXVFdyP1.SITESURLS[bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡖࡊࡖࡏࡔࠩᆃ")][XURrDCfOS9Mbhpv2Pmjos56TeW])
	for kRJbdNFKQwagY in mINB6gjDpFxM4OPE3057Tu91zqSa:
		u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,wwWzyF4ZpSQXKOgk569(u"ࠫࡌࡋࡔࠨᆄ"),kRJbdNFKQwagY,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩᆅ"))
		if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
			VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
			qqcJ1Vx8WSErz = kRJbdNFKQwagY.rsplit(GHg28TBchiyn6l(u"࠭࠯ࠨᆆ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠲ᗅ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			JjYwWvriNRS15 = p7dwlH1PRStBgyMUW.findall(A41nqbj3wYt(u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᆇ"),VbRFshPMjr2t3k,p7dwlH1PRStBgyMUW.DOTALL|p7dwlH1PRStBgyMUW.IGNORECASE)
			for B40Qr5hlSgNm1kuXD3ZFpnyC9,EwAZmIpjtyhDrF3Nf9 in JjYwWvriNRS15:
				EcTVd9QmoAGu4efig7h = qqcJ1Vx8WSErz+YYQS36fyPvtuzcEmRL(u"ࠨ࠱ࠪᆈ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+YYQS36fyPvtuzcEmRL(u"ࠩ࠲ࠫᆉ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+IMjqygdfYSKpHlWu5Aa(u"ࠪ࠱ࠬᆊ")+EwAZmIpjtyhDrF3Nf9+bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࠳ࢀࡩࡱࠩᆋ")
				if B40Qr5hlSgNm1kuXD3ZFpnyC9 not in list(qqUuljAhJT7vpEC0tg2OsXmFxo5Q6.keys()):
					qqUuljAhJT7vpEC0tg2OsXmFxo5Q6[B40Qr5hlSgNm1kuXD3ZFpnyC9] = []
					cW7CrduEmznbV3pTXlqag2BFkUw[B40Qr5hlSgNm1kuXD3ZFpnyC9] = []
				CUFjMdgsJXER3ObW = ntRMkXUgfrBja(EwAZmIpjtyhDrF3Nf9)
				qqUuljAhJT7vpEC0tg2OsXmFxo5Q6[B40Qr5hlSgNm1kuXD3ZFpnyC9].append((EwAZmIpjtyhDrF3Nf9,CUFjMdgsJXER3ObW,EcTVd9QmoAGu4efig7h))
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in list(qqUuljAhJT7vpEC0tg2OsXmFxo5Q6.keys()):
		cW7CrduEmznbV3pTXlqag2BFkUw[B40Qr5hlSgNm1kuXD3ZFpnyC9] = sorted(qqUuljAhJT7vpEC0tg2OsXmFxo5Q6[B40Qr5hlSgNm1kuXD3ZFpnyC9],reverse=r0D4C3z7Onqpa,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4])
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,wwWzyF4ZpSQXKOgk569(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪᆌ"),bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᆍ"),cW7CrduEmznbV3pTXlqag2BFkUw,nsFAzS2wvjyTYLOdDhfIiC0KGHE)
	return cW7CrduEmznbV3pTXlqag2BFkUw
def ntRMkXUgfrBja(EwAZmIpjtyhDrF3Nf9):
	CUFjMdgsJXER3ObW = []
	cGKdUpYvBhQRuDPNzE5snTHfM6J2jy = EwAZmIpjtyhDrF3Nf9.split(yobpaW7sBqtKRrv(u"ࠧ࠯ࠩᆎ"))
	for PujA1gZkTOh9emWXUsM0p87tV4oE in cGKdUpYvBhQRuDPNzE5snTHfM6J2jy:
		Mo7qeh64SGNfVdw = p7dwlH1PRStBgyMUW.findall(A6iX18qgyOFlZxz7sc(u"ࠨ࡞ࡧ࠯ࢁࡡ࡜ࠬ࡞࠰ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࠬᆏ"),PujA1gZkTOh9emWXUsM0p87tV4oE,p7dwlH1PRStBgyMUW.DOTALL)
		ffBUscdIljgLyknWCwSDOhq = []
		for fSiB3TRArozEcG8q5IusVnNUWZP in Mo7qeh64SGNfVdw:
			if fSiB3TRArozEcG8q5IusVnNUWZP.isdigit(): fSiB3TRArozEcG8q5IusVnNUWZP = int(fSiB3TRArozEcG8q5IusVnNUWZP)
			ffBUscdIljgLyknWCwSDOhq.append(fSiB3TRArozEcG8q5IusVnNUWZP)
		CUFjMdgsJXER3ObW.append(ffBUscdIljgLyknWCwSDOhq)
	return CUFjMdgsJXER3ObW
def WWDU0vVCf7gjq9z2PHyk5MtLBm(CUFjMdgsJXER3ObW):
	EwAZmIpjtyhDrF3Nf9 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for PujA1gZkTOh9emWXUsM0p87tV4oE in CUFjMdgsJXER3ObW:
		for fSiB3TRArozEcG8q5IusVnNUWZP in PujA1gZkTOh9emWXUsM0p87tV4oE: EwAZmIpjtyhDrF3Nf9 += str(fSiB3TRArozEcG8q5IusVnNUWZP)
		EwAZmIpjtyhDrF3Nf9 += ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࠱ࠫᆐ")
	EwAZmIpjtyhDrF3Nf9 = EwAZmIpjtyhDrF3Nf9.strip(yobpaW7sBqtKRrv(u"ࠪ࠲ࠬᆑ"))
	return EwAZmIpjtyhDrF3Nf9
def SBguW0zN9UInl(USiR3rv2hup9j):
	jWylPFA81zQGdTDMJ5 = {}
	qqUuljAhJT7vpEC0tg2OsXmFxo5Q6 = pk2vGe1ylfCsPMcSBRYJ960()
	nJywjNBbQzsU340XDLC1Yr6eM = s7sKbH9N5LGVliq6jR(USiR3rv2hup9j)
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in USiR3rv2hup9j:
		if B40Qr5hlSgNm1kuXD3ZFpnyC9 not in list(qqUuljAhJT7vpEC0tg2OsXmFxo5Q6.keys()): continue
		cW7CrduEmznbV3pTXlqag2BFkUw = qqUuljAhJT7vpEC0tg2OsXmFxo5Q6[B40Qr5hlSgNm1kuXD3ZFpnyC9]
		mzwhtOrv8qu2YKZpT,hh8zrbVsYG3MNUC7HPp4vSxE,OYB617E9pCTzXLUsfwtKWu2x = cW7CrduEmznbV3pTXlqag2BFkUw[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		NkfLSl5eDxA8CB0,y3xiFBvfTXkmhP = WZemINP9VnBlfDSu(B40Qr5hlSgNm1kuXD3ZFpnyC9)
		QQKjCzecMlDps7,sVpwjebI2U9PL0fQxG34ZMT = nJywjNBbQzsU340XDLC1Yr6eM[B40Qr5hlSgNm1kuXD3ZFpnyC9]
		dGhvUxJZkNiQHRIso1rScTtYz = hh8zrbVsYG3MNUC7HPp4vSxE>y3xiFBvfTXkmhP and QQKjCzecMlDps7
		RsLeaPcMIo23zQEZrv1F9 = r0D4C3z7Onqpa
		if not QQKjCzecMlDps7: G0fiCygT4MYlstwI1dLRFHeq = A6iX18qgyOFlZxz7sc(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᆒ")
		elif not sVpwjebI2U9PL0fQxG34ZMT: G0fiCygT4MYlstwI1dLRFHeq = wwWzyF4ZpSQXKOgk569(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᆓ")
		elif dGhvUxJZkNiQHRIso1rScTtYz: G0fiCygT4MYlstwI1dLRFHeq = YYQS36fyPvtuzcEmRL(u"࠭࡯࡭ࡦࠪᆔ")
		else:
			G0fiCygT4MYlstwI1dLRFHeq = YYQS36fyPvtuzcEmRL(u"ࠧࡨࡱࡲࡨࠬᆕ")
			RsLeaPcMIo23zQEZrv1F9 = KiryBCvngZzF85UN6xSDlOVweL4I9
		jWylPFA81zQGdTDMJ5[B40Qr5hlSgNm1kuXD3ZFpnyC9] = RsLeaPcMIo23zQEZrv1F9,NkfLSl5eDxA8CB0,y3xiFBvfTXkmhP,mzwhtOrv8qu2YKZpT,hh8zrbVsYG3MNUC7HPp4vSxE,G0fiCygT4MYlstwI1dLRFHeq,OYB617E9pCTzXLUsfwtKWu2x
	return jWylPFA81zQGdTDMJ5
def tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,Gc3S9K4yQ6iWk7nEOF1X,n0eMmDq9W6bBCH2gwk5FfAa3Ojpr=WnNGfosHr5STAq8j7miwyRZ6eOUbV,kXjv6JgQi3=WnNGfosHr5STAq8j7miwyRZ6eOUbV,O74g6wQAYSlXT1uvktI9DZi5f=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if YVzokG2yZqrh3w8bU: QEMTpcCe8tD1S6qbFvluRf.update(Gc3S9K4yQ6iWk7nEOF1X,n0eMmDq9W6bBCH2gwk5FfAa3Ojpr,kXjv6JgQi3,O74g6wQAYSlXT1uvktI9DZi5f)
	else: QEMTpcCe8tD1S6qbFvluRf.update(Gc3S9K4yQ6iWk7nEOF1X,n0eMmDq9W6bBCH2gwk5FfAa3Ojpr+WBDnh75CaLEvkcN6p4ez2KXrV3M+kXjv6JgQi3+WBDnh75CaLEvkcN6p4ez2KXrV3M+O74g6wQAYSlXT1uvktI9DZi5f)
	return
def A1FcQEJDZe9zub2MCtfY4XnLo(llrcXE8g1yqbvQ):
	def COAmvDakrhQ0tZK(pX8vsRMVkoWGjEq,d4mM7W5uXUF6oSgO,T2BkFi4KxleOfHqoSrW7Lvjm=aiQwFE1TGx04vmLcsYkIW5jA(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠣᆖ")):
		return ((pX8vsRMVkoWGjEq == j0jEZgiKdxFpMLHcU7kQr8v1lyX4) and T2BkFi4KxleOfHqoSrW7Lvjm[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]) or (COAmvDakrhQ0tZK(pX8vsRMVkoWGjEq // d4mM7W5uXUF6oSgO, d4mM7W5uXUF6oSgO, T2BkFi4KxleOfHqoSrW7Lvjm).lstrip(T2BkFi4KxleOfHqoSrW7Lvjm[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]) + T2BkFi4KxleOfHqoSrW7Lvjm[pX8vsRMVkoWGjEq % d4mM7W5uXUF6oSgO])
	def YGnyRp7eIHdODNZ3vmiuXt82sh(rnzy54IHPNCULdgquW0JmGkF, SsbduzmRPEIpN5xg1kZviGetJAO, Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE, QchoMN1dtDgAOaE, rMoBOstlRpe50GmbCzuK=OHohTgj06taKzsG, keOU0L2JMmaH7T=OHohTgj06taKzsG, YYMeW53IcS=OHohTgj06taKzsG):
		while (Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE):
			Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE-=CyHU86ZeYT5BWRcitSm2I(u"࠳ᗆ")
			if (QchoMN1dtDgAOaE[Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE]): rnzy54IHPNCULdgquW0JmGkF = p7dwlH1PRStBgyMUW.sub(ZLr5gRSkFewKdUos90bM(u"ࠤ࡟ࡠࡧࠨᆗ") + COAmvDakrhQ0tZK(Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE, SsbduzmRPEIpN5xg1kZviGetJAO) + Z9FPQvwlbjLTh(u"ࠥࡠࡡࡨࠢᆘ"),  QchoMN1dtDgAOaE[Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE], rnzy54IHPNCULdgquW0JmGkF)
		return rnzy54IHPNCULdgquW0JmGkF
	llrcXE8g1yqbvQ = llrcXE8g1yqbvQ.split(GHg28TBchiyn6l(u"ࠫࢂ࠮ࠧᆙ"))[wnaWTQM7VJPkZzO9eoSyFU4]
	llrcXE8g1yqbvQ = llrcXE8g1yqbvQ.rsplit(iySORMYxWXszEH18(u"ࠬࡹࡰ࡭࡫ࡷࠫᆚ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡳࡱ࡮࡬ࡸ࠭࠭ࡼࠨࠫࠬࠦᆛ")
	cNhzkJn693rIOf51WvDBAyZVEoR = eval(iySORMYxWXszEH18(u"ࠧࡶࡰࡳࡥࡨࡱࠨࠨᆜ")+llrcXE8g1yqbvQ,{rVy3Ops0mohYkT(u"ࠨࡤࡤࡷࡪࡔࠧᆝ"):COAmvDakrhQ0tZK,iySORMYxWXszEH18(u"ࠩࡸࡲࡵࡧࡣ࡬ࠩᆞ"):YGnyRp7eIHdODNZ3vmiuXt82sh})
	return cNhzkJn693rIOf51WvDBAyZVEoR
def z3o4DEbwAJBUa(code):
	_sY2LIOK69SqxQzy=kdRO82AImh0LFw(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜࠮࠳ࠧᆟ")
	def Vs7PDlvEgFL5pThyrRn(keOU0L2JMmaH7T,rMoBOstlRpe50GmbCzuK,sqbz0KgLF8U31fXDmTu):
		m2aqiBejrQXou54htZknvApfOG = list(_sY2LIOK69SqxQzy)
		WWuREpcNseJmdHnZhkrlFS5QC = m2aqiBejrQXou54htZknvApfOG[GHg28TBchiyn6l(u"࠳ᗇ"):rMoBOstlRpe50GmbCzuK]
		JrM1DoSuQ5n8 = m2aqiBejrQXou54htZknvApfOG[oiWNFYzcIUeh(u"࠴ᗈ"):sqbz0KgLF8U31fXDmTu]
		keOU0L2JMmaH7T = list(keOU0L2JMmaH7T)[::-aiQwFE1TGx04vmLcsYkIW5jA(u"࠶ᗉ")]
		OTEanYikpqHGRDJ8Qxmg5ohvlXL = KLX7hW0nBAEgy6m4SvH(u"࠶ᗊ")
		for Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE,d4mM7W5uXUF6oSgO in enumerate(keOU0L2JMmaH7T):
			if d4mM7W5uXUF6oSgO in WWuREpcNseJmdHnZhkrlFS5QC: OTEanYikpqHGRDJ8Qxmg5ohvlXL = OTEanYikpqHGRDJ8Qxmg5ohvlXL + WWuREpcNseJmdHnZhkrlFS5QC.index(d4mM7W5uXUF6oSgO)*rMoBOstlRpe50GmbCzuK**Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE
		QchoMN1dtDgAOaE = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠦࠧᆠ")
		while OTEanYikpqHGRDJ8Qxmg5ohvlXL > lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠰ᗋ"):
			QchoMN1dtDgAOaE = JrM1DoSuQ5n8[OTEanYikpqHGRDJ8Qxmg5ohvlXL%sqbz0KgLF8U31fXDmTu] + QchoMN1dtDgAOaE
			OTEanYikpqHGRDJ8Qxmg5ohvlXL = (OTEanYikpqHGRDJ8Qxmg5ohvlXL - (OTEanYikpqHGRDJ8Qxmg5ohvlXL%sqbz0KgLF8U31fXDmTu))//sqbz0KgLF8U31fXDmTu
		return int(QchoMN1dtDgAOaE) or IMjqygdfYSKpHlWu5Aa(u"࠱ᗌ")
	def SSWmbTo264rj5(WWuREpcNseJmdHnZhkrlFS5QC,u,z26ZPQu7CmYAcNxRfX4Da98heMt1B,B16OYkC3a4lWHIj,rMoBOstlRpe50GmbCzuK,YYMeW53IcS):
		YYMeW53IcS = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࠨᆡ");
		JrM1DoSuQ5n8 = mq5t9JXSdHT8yfDVF(u"࠲ᗍ")
		while JrM1DoSuQ5n8 < len(WWuREpcNseJmdHnZhkrlFS5QC):
			OTEanYikpqHGRDJ8Qxmg5ohvlXL = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠳ᗎ")
			uDb3UodKz4 = ZLr5gRSkFewKdUos90bM(u"ࠨࠢᆢ")
			while WWuREpcNseJmdHnZhkrlFS5QC[JrM1DoSuQ5n8] is not z26ZPQu7CmYAcNxRfX4Da98heMt1B[rMoBOstlRpe50GmbCzuK]:
				uDb3UodKz4 = WnNGfosHr5STAq8j7miwyRZ6eOUbV.join([uDb3UodKz4,WWuREpcNseJmdHnZhkrlFS5QC[JrM1DoSuQ5n8]])
				JrM1DoSuQ5n8 = JrM1DoSuQ5n8 + Z9FPQvwlbjLTh(u"࠵ᗏ")
			while OTEanYikpqHGRDJ8Qxmg5ohvlXL < len(z26ZPQu7CmYAcNxRfX4Da98heMt1B):
				uDb3UodKz4 = uDb3UodKz4.replace(z26ZPQu7CmYAcNxRfX4Da98heMt1B[OTEanYikpqHGRDJ8Qxmg5ohvlXL],str(OTEanYikpqHGRDJ8Qxmg5ohvlXL))
				OTEanYikpqHGRDJ8Qxmg5ohvlXL = OTEanYikpqHGRDJ8Qxmg5ohvlXL + bawK2j7T81Nrc4GWs05xzDg(u"࠶ᗐ")
			YYMeW53IcS = WnNGfosHr5STAq8j7miwyRZ6eOUbV.join([YYMeW53IcS,WnNGfosHr5STAq8j7miwyRZ6eOUbV.join(map(chr, [Vs7PDlvEgFL5pThyrRn(uDb3UodKz4,rMoBOstlRpe50GmbCzuK,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠰ᗑ")) - B16OYkC3a4lWHIj]))])
			JrM1DoSuQ5n8 = JrM1DoSuQ5n8 + ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠱ᗒ")
		return YYMeW53IcS
	code = code.replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧ࡝ࡰࠪᆣ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(GHg28TBchiyn6l(u"ࠨ࡞ࡵࠫᆤ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	pptLCWywkDVe8fmSc16KP = p7dwlH1PRStBgyMUW.findall(YYQS36fyPvtuzcEmRL(u"ࠩ࡟ࢁࡡ࠮ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭࠱࠮࡜ࡥ࠭ࠬࡠ࠮ࡢࠩࠨᆥ"),code,p7dwlH1PRStBgyMUW.DOTALL)
	if pptLCWywkDVe8fmSc16KP:
		pptLCWywkDVe8fmSc16KP = list(pptLCWywkDVe8fmSc16KP[beV5l2D8HznyJI0(u"࠱ᗓ")])
		for DvqS1xLF8Y,code in enumerate(pptLCWywkDVe8fmSc16KP):
			if code.isdigit(): pptLCWywkDVe8fmSc16KP[DvqS1xLF8Y] = int(code)
			else: pptLCWywkDVe8fmSc16KP[DvqS1xLF8Y] = code.replace(rVy3Ops0mohYkT(u"ࠪࡠࠧ࠭ᆦ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		dQS4Mextn6fWBz = SSWmbTo264rj5(*pptLCWywkDVe8fmSc16KP)
		return dQS4Mextn6fWBz
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV
def CKcTHIGm4P0fLDboNFZyzBU5eYJE7Q(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,T8mLQnhyux=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if T8mLQnhyux==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡱࡵࡷࡦࡴࠪᆧ"): kdNn2Zqsj4wPi5ThuoUQvtcg6OA = p7dwlH1PRStBgyMUW.sub(mq5t9JXSdHT8yfDVF(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡆ࠳࡚࡞ࡽ࠵ࢁࠬᆨ"),lambda OZKklo4MUPDb: OZKklo4MUPDb.group(j0jEZgiKdxFpMLHcU7kQr8v1lyX4).lower(),kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	elif T8mLQnhyux==gPE1XB87fQl(u"࠭ࡵࡱࡲࡨࡶࠬᆩ"): kdNn2Zqsj4wPi5ThuoUQvtcg6OA = p7dwlH1PRStBgyMUW.sub(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࡲࠨࠧ࡞࠴࠲࠿ࡡ࠮ࡼࡠࡿ࠷ࢃࠧᆪ"),lambda OZKklo4MUPDb: OZKklo4MUPDb.group(j0jEZgiKdxFpMLHcU7kQr8v1lyX4).upper(),kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	return kdNn2Zqsj4wPi5ThuoUQvtcg6OA
def s7sKbH9N5LGVliq6jR(USiR3rv2hup9j):
	SSZijJam8d9WR3KY6ECQt,pxRyjXsvqCfbDlkgLFBU0YE = KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9
	OoE5HYUMwsrDWhx2gR7I3FuN = x0p6hU1tkV4oBXnm2SDsNPlY7.connect(O3yquo9YEKRTF7LDWfAdpc1wshl6)
	OoE5HYUMwsrDWhx2gR7I3FuN.text_factory = str
	GSB3DNKz9vFbaEo8 = OoE5HYUMwsrDWhx2gR7I3FuN.cursor()
	if len(USiR3rv2hup9j)==wnaWTQM7VJPkZzO9eoSyFU4: kfDKdYoF20CgBbE6aXjxWZpuec = gPE1XB87fQl(u"ࠨࠪࠥࠫᆫ")+USiR3rv2hup9j[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࠥ࠭ࠬᆬ")
	else: kfDKdYoF20CgBbE6aXjxWZpuec = str(tuple(USiR3rv2hup9j))
	GSB3DNKz9vFbaEo8.execute(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡪࡴࡡࡣ࡮ࡨࡨࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦࡉࡏࠢࠪᆭ")+kfDKdYoF20CgBbE6aXjxWZpuec+yobpaW7sBqtKRrv(u"ࠫࠥࡁࠧᆮ"))
	n407uaQIPXEqUzwhLe8v3rSM6 = GSB3DNKz9vFbaEo8.fetchall()
	OoE5HYUMwsrDWhx2gR7I3FuN.close()
	nJywjNBbQzsU340XDLC1Yr6eM = {}
	for B40Qr5hlSgNm1kuXD3ZFpnyC9 in USiR3rv2hup9j: nJywjNBbQzsU340XDLC1Yr6eM[B40Qr5hlSgNm1kuXD3ZFpnyC9] = (KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	for B40Qr5hlSgNm1kuXD3ZFpnyC9,pxRyjXsvqCfbDlkgLFBU0YE in n407uaQIPXEqUzwhLe8v3rSM6:
		SSZijJam8d9WR3KY6ECQt = r0D4C3z7Onqpa
		pxRyjXsvqCfbDlkgLFBU0YE = pxRyjXsvqCfbDlkgLFBU0YE==wnaWTQM7VJPkZzO9eoSyFU4
		nJywjNBbQzsU340XDLC1Yr6eM[B40Qr5hlSgNm1kuXD3ZFpnyC9] = (SSZijJam8d9WR3KY6ECQt,pxRyjXsvqCfbDlkgLFBU0YE)
	return nJywjNBbQzsU340XDLC1Yr6eM
def QSXjgqyaVxPL4(a3aJE1T7OlBQDXCIi5SRYvo):
	APpdhB1Fk58MmJH7CjVntowyaY = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(a3aJE1T7OlBQDXCIi5SRYvo):
		N70NuMkcZHY = open(a3aJE1T7OlBQDXCIi5SRYvo,beV5l2D8HznyJI0(u"ࠬࡸࡢࠨᆯ")).read()
		if rJ2oTLqabRtA: N70NuMkcZHY = N70NuMkcZHY.decode(e87cIA5vwOQLDEP1)
		tZpzD9of3gIycY = IXZpzK7ShaRsAN(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡤࡪࡥࡷࠫᆰ"),N70NuMkcZHY)
		if tZpzD9of3gIycY:
			APpdhB1Fk58MmJH7CjVntowyaY = {}
			for lGdZS2mFX1PfHEr7Lt8I in tZpzD9of3gIycY.keys():
				APpdhB1Fk58MmJH7CjVntowyaY[lGdZS2mFX1PfHEr7Lt8I] = []
				for STKyn2NmBrb9d8LfhCM4H7zasO5 in tZpzD9of3gIycY[lGdZS2mFX1PfHEr7Lt8I]:
					G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
					G3Xh0YWACHFuvQLx5sVEfPjzq7 = STKyn2NmBrb9d8LfhCM4H7zasO5[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					VkEQdztnmeH = STKyn2NmBrb9d8LfhCM4H7zasO5[wnaWTQM7VJPkZzO9eoSyFU4]
					VkEQdztnmeH = Ye7QMduPDEiphaUy5R9OVSIgx(VkEQdztnmeH)
					kdNn2Zqsj4wPi5ThuoUQvtcg6OA = STKyn2NmBrb9d8LfhCM4H7zasO5[XURrDCfOS9Mbhpv2Pmjos56TeW]
					e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE = STKyn2NmBrb9d8LfhCM4H7zasO5[vXIdY7TwFKso40gVBq5]
					bLhqw36zAp7uKxJIM4r502UGRT = STKyn2NmBrb9d8LfhCM4H7zasO5[yGLl1nSBrJPmi2adko9O]
					TB3DI4JWr0NYmik1xO8Kc2 = STKyn2NmBrb9d8LfhCM4H7zasO5[kdRO82AImh0LFw(u"࠷ᗔ")]
					if len(STKyn2NmBrb9d8LfhCM4H7zasO5)>IMjqygdfYSKpHlWu5Aa(u"࠹ᗕ"): HvzeZpTRrx9j1hMBV3 = STKyn2NmBrb9d8LfhCM4H7zasO5[IMjqygdfYSKpHlWu5Aa(u"࠹ᗕ")]
					if len(STKyn2NmBrb9d8LfhCM4H7zasO5)>aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠻ᗖ"): SDUJm78sZBG = STKyn2NmBrb9d8LfhCM4H7zasO5[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠻ᗖ")]
					if len(STKyn2NmBrb9d8LfhCM4H7zasO5)>KLX7hW0nBAEgy6m4SvH(u"࠽ᗗ"): AUBZYG84NbOKsRnxi6jgk2f = STKyn2NmBrb9d8LfhCM4H7zasO5[KLX7hW0nBAEgy6m4SvH(u"࠽ᗗ")]
					if a3aJE1T7OlBQDXCIi5SRYvo==C6MhN2TeZ83GDFngway7EvBYom5i: T8SIzixfF6jg2GWLKqJhV9Y = G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f
					else: T8SIzixfF6jg2GWLKqJhV9Y = G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f
					APpdhB1Fk58MmJH7CjVntowyaY[lGdZS2mFX1PfHEr7Lt8I].append(T8SIzixfF6jg2GWLKqJhV9Y)
		bmK07sdk8FNynQ45HphU = str(APpdhB1Fk58MmJH7CjVntowyaY)
		if rJ2oTLqabRtA: bmK07sdk8FNynQ45HphU = bmK07sdk8FNynQ45HphU.encode(e87cIA5vwOQLDEP1)
		open(a3aJE1T7OlBQDXCIi5SRYvo,KLX7hW0nBAEgy6m4SvH(u"ࠧࡸࡤࠪᆱ")).write(bmK07sdk8FNynQ45HphU)
	return APpdhB1Fk58MmJH7CjVntowyaY
def b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4):
	V08cPX9tfM7gZxdvkuyBHhN = OOG1iPYhTKQ4.split(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࠯ࠪᆲ"),wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if   V08cPX9tfM7gZxdvkuyBHhN==bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡄࡌ࡜ࡇࡋࠨᆳ")		:	from epnqOQtVjL			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡅࡐࡕࡁࡎࠩᆴ")		:	from IsHuZ0qpPT			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==Z9FPQvwlbjLTh(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ᆵ")	:	from HhTRf43jBE		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==gPE1XB87fQl(u"ࠬࡇࡋࡘࡃࡐࠫᆶ")		:	from iiy8cVF7db			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==YYQS36fyPvtuzcEmRL(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩᆷ")	:	from f8gYzE63PQ		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==wwWzyF4ZpSQXKOgk569(u"ࠧࡂࡎࡄࡖࡆࡈࠧᆸ")	:	from vHV9gRTNKP			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪᆹ")	:	from eW3ZydnAi2		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬᆺ")	: 	from AiKLdU9Wky		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==SI7eBdND4lx8pt5Qk(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬᆻ")	:	from TOCi1blMFp		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==yobpaW7sBqtKRrv(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬᆼ")	:	from vA4LkIGtNE		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧᆽ")	:	from EV4cUrZked		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==pp7FcjEe6g(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫᆾ"):	from dc7hylBaM1	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩᆿ")	:	from nrd8U1RKu6		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡃ࡜ࡐࡔࡒࠧᇀ")		:	from OaX3K08oLW			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡅࡓࡐࡘࡁࠨᇁ")		:	from rqvKs7u3yN			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪᇂ")	:	from lr6NIiBsem			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==wwWzyF4ZpSQXKOgk569(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬᇃ")	:	from IYw85cPR4z		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==KLX7hW0nBAEgy6m4SvH(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬᇄ")	:	from pWqmnKDbuz			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==KLX7hW0nBAEgy6m4SvH(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᇅ")	:	from dqwV0sDIuE			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᇆ")	:	from nnXWjdor7G		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==mq5t9JXSdHT8yfDVF(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪᇇ")	:	from nMWqebA3wf		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==kdRO82AImh0LFw(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨᇈ"):	from gljKSUf8hu	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==mq5t9JXSdHT8yfDVF(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᇉ")	:	from REfPWC2K6J		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==wwWzyF4ZpSQXKOgk569(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᇊ")	:	from Hiza5DZJEr		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==VP70ytiFNMBl6vHDaW(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧᇋ")	:	from eOf1YMWBQo		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᇌ")	:	from w9rdylLDsa		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==IMjqygdfYSKpHlWu5Aa(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᇍ")	:	from UhA459zcSm		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==CyHU86ZeYT5BWRcitSm2I(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪᇎ")	:	from ehaZP4z6ck		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==rVy3Ops0mohYkT(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧᇏ"):	from tHfKLiFmz4	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==pp7FcjEe6g(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ᇐ")	:	from jjw7ER4tri		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==CyHU86ZeYT5BWRcitSm2I(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬᇑ")	:	from yubJEvNZCx		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭ᇒ")	:	from aaRwAVNtIH		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==pp7FcjEe6g(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᇓ")	:	from JdUBjazqsO		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==wwWzyF4ZpSQXKOgk569(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩᇔ")	:	from VUykxqsjMG		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==rVy3Ops0mohYkT(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪᇕ")	:	from U7XDKi5njM		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==pp7FcjEe6g(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫᇖ")	:	from CduqENMtf8		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫᇗ")	:	from Y1lb7kUoqW		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==pp7FcjEe6g(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫᇘ")	:	from KSvkoWfe9l			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==GHg28TBchiyn6l(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧᇙ")	:	from WVIGahw4HT		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩᇚ")	:	from e5RcmyiNnX		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==Z9FPQvwlbjLTh(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨᇛ")	:	from XxKOrN3Lvq		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫᇜ")	:	from Y6gzSMvWmk		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪᇝ")	:	from jKcEAqndg7		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==GHg28TBchiyn6l(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᇞ")	:	from HvVudtEb6R		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==A6iX18qgyOFlZxz7sc(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ᇟ")	:	from RDEvoJlsUX		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"ࠬࡌࡏࡔࡖࡄࠫᇠ")		:	from q0JxEBGdOc			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==yobpaW7sBqtKRrv(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧᇡ")	:	from WWtPR05mIN		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩᇢ")	:	from OLcMFtvCq5		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭ᇣ"):	from YZ9TFMPDvA	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==iySORMYxWXszEH18(u"ࠩࡊࡓࡔࡍࡌࡆࡕࡈࡅࡗࡉࡈࠨᇤ"):	from H2mc5EFGK0	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬᇥ")	:	from PnGsJw3SFB		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡎࡌࡉࡍࡏࠪᇦ")		:	from bCNf7O8iTI			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡏࡐࡕࡘࠪᇧ")		:	from e06e8au2ZV			import Hkr4wlnZ5Iobuf0ASYx as PVIqN8MGBf7DX3TjdA1Qh9gOU,pBzAsvx3aVgUWSnyrH0 as uTes0AS7pNHjbkawzy5mqLx4XP,utGmJTNWUpy9KnVf1hd as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩᇨ")	:	from XtYvZDPwQi		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==A6iX18qgyOFlZxz7sc(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩᇩ")	:	from ZZGlVNYbaT		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==iySORMYxWXszEH18(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪᇪ")	:	from CJvZbAdIpH		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪᇫ")	:	from ruPMYxFthg		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪᇬ")	:	from b5GlsiO6d2			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬᇭ")	:	from HFTS2bGIhV		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==ZLr5gRSkFewKdUos90bM(u"ࠬࡓ࠳ࡖࠩᇮ")		:	from aEzp4cq7nd			import Hkr4wlnZ5Iobuf0ASYx as PVIqN8MGBf7DX3TjdA1Qh9gOU,pBzAsvx3aVgUWSnyrH0 as uTes0AS7pNHjbkawzy5mqLx4XP,utGmJTNWUpy9KnVf1hd as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==IMjqygdfYSKpHlWu5Aa(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩᇯ")	:	from uumWPCkHtz		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧᇰ")	:	from G8EoMZwSa0			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==KLX7hW0nBAEgy6m4SvH(u"ࠨࡏ࡜ࡇࡎࡓࡁࠨᇱ")	:	from NNaWlnOxMy			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"ࠩࡓࡅࡓࡋࡔࠨᇲ")		:	from PjfoK5AGFZ			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==tzZ6PhyDOUnwLM3pdK(u"ࠪࡕࡋࡏࡌࡎࠩᇳ")		:	from vvblHILt7Q			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨᇴ"):	from eInYlC1HXO		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==GHg28TBchiyn6l(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨᇵ")	:	from lBkjWEAKMY		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==YYQS36fyPvtuzcEmRL(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᇶ")	:	from Ym6QVM1qai		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==ZLr5gRSkFewKdUos90bM(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪᇷ")	:	from e9WAyXqHsM		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==rVy3Ops0mohYkT(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬᇸ"):	from kpBgcTzUjY		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==mq5t9JXSdHT8yfDVF(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬᇹ")	:	from zzEgv8ewY3		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡗࡍࡕࡆࡉࡃࠪᇺ")	:	from M6w2Wug34l			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==yobpaW7sBqtKRrv(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ᇻ")	:	from V3InR4wf2B		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==oiWNFYzcIUeh(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧᇼ")	:	from MNzW38k2cb		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==yobpaW7sBqtKRrv(u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨᇽ")	:	from ifod8xX7ma		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==kdRO82AImh0LFw(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧᇾ")	:	from s93XE2Qmi6			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==A6iX18qgyOFlZxz7sc(u"ࠨࡖ࡙ࡊ࡚ࡔࠧᇿ")		:	from akm7Olewy1			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aiQwFE1TGx04vmLcsYkIW5jA(u"࡙ࠩࡅࡗࡈࡏࡏࠩሀ")	:	from EbgxYdLZWC			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==mq5t9JXSdHT8yfDVF(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧሁ"):	from NNlGvMjJQY		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬሂ")	:	from UA6tWv1J4F		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ሃ")	:	from ZieJc3z9E2		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==aiQwFE1TGx04vmLcsYkIW5jA(u"࡙࠭ࡂࡓࡒࡘࠬሄ")		:	from W3vrGLQYf2			import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨህ")	:	from pOtaEIAv5o		import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	elif V08cPX9tfM7gZxdvkuyBHhN==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧሆ"):	from BBGbk0UjSV	import bRaCHZtyd3qj7D as PVIqN8MGBf7DX3TjdA1Qh9gOU,WmxfGFqceOyUtLT as uTes0AS7pNHjbkawzy5mqLx4XP,uBQ9txp0gDrEhZTcJOi74SKVw3k as qr61ZvHTdEjIShcBis
	return PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis
def zz3FACPKTpqWhEYsf1o9v(pp3sDoXdkc9V,OLAqp2vxUf5rw79zdgQR1ZboEJ,showDialogs):
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧሇ")+pp3sDoXdkc9V+IMjqygdfYSKpHlWu5Aa(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ለ")+str(OLAqp2vxUf5rw79zdgQR1ZboEJ)+tzZ6PhyDOUnwLM3pdK(u"ࠫࠥࡣࠧሉ"))
	QEMTpcCe8tD1S6qbFvluRf = dpY7rMymk2W1Jo()
	QEMTpcCe8tD1S6qbFvluRf.create(Ew26Hg4SIj,oiWNFYzcIUeh(u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧሊ"))
	L3EJrtxTWiUMGHylNFkCs5vdK8w2Q = IMjqygdfYSKpHlWu5Aa(u"࠷࠰࠳࠶ᗘ")*IMjqygdfYSKpHlWu5Aa(u"࠷࠰࠳࠶ᗘ")
	phjmtHzTvFs8XYPJoKk5 = A41nqbj3wYt(u"࠱ᗙ")*L3EJrtxTWiUMGHylNFkCs5vdK8w2Q
	import requests as KnHmtUWv49wToIf
	u4vhNT8C0k1tmrxX9F5gGWo7Z = KnHmtUWv49wToIf.get(pp3sDoXdkc9V,stream=r0D4C3z7Onqpa,headers=OLAqp2vxUf5rw79zdgQR1ZboEJ)
	az2GRLgiNT6d3PWMfb = u4vhNT8C0k1tmrxX9F5gGWo7Z.headers
	u4vhNT8C0k1tmrxX9F5gGWo7Z.close()
	f6LHOwSg0U = bytes()
	if not az2GRLgiNT6d3PWMfb:
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩላ"))
		QEMTpcCe8tD1S6qbFvluRf.close()
	else:
		if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨሌ") not in list(az2GRLgiNT6d3PWMfb.keys()): BdsZRnrMSy58TLtQHFYcq = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		else: BdsZRnrMSy58TLtQHFYcq = int(az2GRLgiNT6d3PWMfb[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩል")])
		e1TipUhjZSfKbrP60BGVcmWkywRgAH = str(int(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠳࠳࠴࠵ᗛ")*BdsZRnrMSy58TLtQHFYcq/L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)/eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠲࠲࠳࠴࠳࠶ᗚ"))
		jHzsJtumaD8MSTKyhiLOqdf71I = int(BdsZRnrMSy58TLtQHFYcq/phjmtHzTvFs8XYPJoKk5)+wnaWTQM7VJPkZzO9eoSyFU4
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩሎ") in list(az2GRLgiNT6d3PWMfb.keys()) and BdsZRnrMSy58TLtQHFYcq>L3EJrtxTWiUMGHylNFkCs5vdK8w2Q:
			rBADlb705aI = r0D4C3z7Onqpa
			UdhLuM46Dm87 = []
			Ph0yAt3KEVecZnN = ZLr5gRSkFewKdUos90bM(u"࠴࠴ᗜ")
			UdhLuM46Dm87.append(str(j0jEZgiKdxFpMLHcU7kQr8v1lyX4*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+CyHU86ZeYT5BWRcitSm2I(u"ࠪ࠱ࠬሏ")+str(wnaWTQM7VJPkZzO9eoSyFU4*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(wnaWTQM7VJPkZzO9eoSyFU4*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫ࠲࠭ሐ")+str(XURrDCfOS9Mbhpv2Pmjos56TeW*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(XURrDCfOS9Mbhpv2Pmjos56TeW*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+kdRO82AImh0LFw(u"ࠬ࠳ࠧሑ")+str(vXIdY7TwFKso40gVBq5*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(vXIdY7TwFKso40gVBq5*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+kdRO82AImh0LFw(u"࠭࠭ࠨሒ")+str(yGLl1nSBrJPmi2adko9O*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(yGLl1nSBrJPmi2adko9O*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧ࠮ࠩሓ")+str(kdRO82AImh0LFw(u"࠹ᗝ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(YYQS36fyPvtuzcEmRL(u"࠺ᗞ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+CyHU86ZeYT5BWRcitSm2I(u"ࠨ࠯ࠪሔ")+str(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠼ᗟ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠷ᗡ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+gPE1XB87fQl(u"ࠩ࠰ࠫሕ")+str(yobpaW7sBqtKRrv(u"࠷ᗠ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(Z9FPQvwlbjLTh(u"࠺ᗣ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+A6iX18qgyOFlZxz7sc(u"ࠪ࠱ࠬሖ")+str(VP70ytiFNMBl6vHDaW(u"࠺ᗢ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(yobpaW7sBqtKRrv(u"࠽ᗥ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫ࠲࠭ሗ")+str(pp7FcjEe6g(u"࠽ᗤ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN-wnaWTQM7VJPkZzO9eoSyFU4))
			UdhLuM46Dm87.append(str(KLX7hW0nBAEgy6m4SvH(u"࠿ᗦ")*BdsZRnrMSy58TLtQHFYcq//Ph0yAt3KEVecZnN)+YYQS36fyPvtuzcEmRL(u"ࠬ࠳ࠧመ"))
			ypjUEGCqFc = float(jHzsJtumaD8MSTKyhiLOqdf71I)/Ph0yAt3KEVecZnN
			m3mHFhlj1Ucb0eqpgs = ypjUEGCqFc/int(wnaWTQM7VJPkZzO9eoSyFU4+ypjUEGCqFc)
		else:
			rBADlb705aI = KiryBCvngZzF85UN6xSDlOVweL4I9
			Ph0yAt3KEVecZnN = wnaWTQM7VJPkZzO9eoSyFU4
			m3mHFhlj1Ucb0eqpgs = wnaWTQM7VJPkZzO9eoSyFU4
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,YYQS36fyPvtuzcEmRL(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧሙ")+str(rBADlb705aI)+SI7eBdND4lx8pt5Qk(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩሚ")+str(BdsZRnrMSy58TLtQHFYcq)+mq5t9JXSdHT8yfDVF(u"ࠨࠢࡠࠫማ"))
		zuEo6GDeAR5Z,ootTYDmW8JVQXpvqKFPi73sw4E = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		for f0Q5l2rT8DWHIFkauPL4So9X3vKiR in range(Ph0yAt3KEVecZnN):
			W67hPCcaOek094 = OLAqp2vxUf5rw79zdgQR1ZboEJ.copy()
			if rBADlb705aI: W67hPCcaOek094[bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡕࡥࡳ࡭ࡥࠨሜ")] = bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪም")+UdhLuM46Dm87[f0Q5l2rT8DWHIFkauPL4So9X3vKiR]
			u4vhNT8C0k1tmrxX9F5gGWo7Z = KnHmtUWv49wToIf.get(pp3sDoXdkc9V,stream=r0D4C3z7Onqpa,headers=W67hPCcaOek094,timeout=aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠳࠱࠲ᗧ"))
			for INj0vaiqFd4SlUbtEDTKczJmLArf in u4vhNT8C0k1tmrxX9F5gGWo7Z.iter_content(chunk_size=phjmtHzTvFs8XYPJoKk5):
				if QEMTpcCe8tD1S6qbFvluRf.iscanceled():
					SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,A41nqbj3wYt(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫሞ"))
					break
				zuEo6GDeAR5Z += m3mHFhlj1Ucb0eqpgs
				f6LHOwSg0U += INj0vaiqFd4SlUbtEDTKczJmLArf
				if not ootTYDmW8JVQXpvqKFPi73sw4E: ootTYDmW8JVQXpvqKFPi73sw4E = len(INj0vaiqFd4SlUbtEDTKczJmLArf)
				if BdsZRnrMSy58TLtQHFYcq: tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,wwWzyF4ZpSQXKOgk569(u"࠲࠲࠳ᗨ")*zuEo6GDeAR5Z//jHzsJtumaD8MSTKyhiLOqdf71I,wwWzyF4ZpSQXKOgk569(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ሟ"),str(yobpaW7sBqtKRrv(u"࠳࠳࠴࠳࠶ᗩ")*ootTYDmW8JVQXpvqKFPi73sw4E*zuEo6GDeAR5Z//phjmtHzTvFs8XYPJoKk5//yobpaW7sBqtKRrv(u"࠳࠳࠴࠳࠶ᗩ"))+Z9FPQvwlbjLTh(u"࠭ࠠ࠰ࠢࠪሠ")+e1TipUhjZSfKbrP60BGVcmWkywRgAH+yobpaW7sBqtKRrv(u"ࠧࠡࡏࡅࠫሡ"))
				else: tcZLDKnrTPNVOBF62w1(QEMTpcCe8tD1S6qbFvluRf,ootTYDmW8JVQXpvqKFPi73sw4E*zuEo6GDeAR5Z//phjmtHzTvFs8XYPJoKk5,iySORMYxWXszEH18(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ሢ"),str(CyHU86ZeYT5BWRcitSm2I(u"࠴࠴࠵࠴࠰ᗪ")*ootTYDmW8JVQXpvqKFPi73sw4E*zuEo6GDeAR5Z//phjmtHzTvFs8XYPJoKk5//CyHU86ZeYT5BWRcitSm2I(u"࠴࠴࠵࠴࠰ᗪ"))+VP70ytiFNMBl6vHDaW(u"ࠩࠣࡑࡇ࠭ሣ"))
			u4vhNT8C0k1tmrxX9F5gGWo7Z.close()
		QEMTpcCe8tD1S6qbFvluRf.close()
		if len(f6LHOwSg0U)<BdsZRnrMSy58TLtQHFYcq and BdsZRnrMSy58TLtQHFYcq>j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭ሤ")+str(len(f6LHOwSg0U)//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)+tzZ6PhyDOUnwLM3pdK(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩሥ")+e1TipUhjZSfKbrP60BGVcmWkywRgAH+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࠦࡍࡃࠢࡠࠫሦ"))
			tt2NkXu7HgTIAyj09OBlod3YDpz = tFVmMznSUR3XupZBN9kxcO0EHv(WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫሧ"),yobpaW7sBqtKRrv(u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧረ"),IMjqygdfYSKpHlWu5Aa(u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪሩ"),Ew26Hg4SIj,ZLr5gRSkFewKdUos90bM(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭ሪ")+str(len(f6LHOwSg0U)//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q)+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩራ")+e1TipUhjZSfKbrP60BGVcmWkywRgAH+aiQwFE1TGx04vmLcsYkIW5jA(u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭ሬ"))
			if tt2NkXu7HgTIAyj09OBlod3YDpz==XURrDCfOS9Mbhpv2Pmjos56TeW: f6LHOwSg0U = zz3FACPKTpqWhEYsf1o9v(pp3sDoXdkc9V,OLAqp2vxUf5rw79zdgQR1ZboEJ,showDialogs)
			elif tt2NkXu7HgTIAyj09OBlod3YDpz==wnaWTQM7VJPkZzO9eoSyFU4: SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,iySORMYxWXszEH18(u"ࠬ࠴࡜ࡵࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫር"))
			else: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if not f6LHOwSg0U: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
		else: SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪሮ")+e1TipUhjZSfKbrP60BGVcmWkywRgAH+A6iX18qgyOFlZxz7sc(u"ࠧࠡࡏࡅࠤࡢ࠭ሯ"))
	return f6LHOwSg0U
def b70bjfqNzGhBsQeUcumwptH4CkK(NTWE764hmOgUtScp2e8r):
	return u4vhNT8C0k1tmrxX9F5gGWo7Z
def UwIPdKQt4YDfoJM(ip=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if A3pXVFdyP1.GEOLOCATION_DATA: return A3pXVFdyP1.GEOLOCATION_DATA
	KKtfxAbzoFlcG7wasMq36,l7L3xtUSXrRAV6nwEMpBv4yimKc0H9,mh7oVZtHp1Aq9CQ8df5FXJMuR,mYOBPUqV2k0et91Lw6RQ,KDuWdg73AY6aOZVqnf,Ht0yQIadhjOw8GKBvgi6EFUxMsL = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = tzZ6PhyDOUnwLM3pdK(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫሰ")+ip+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧሱ")
	OLAqp2vxUf5rw79zdgQR1ZboEJ = {rVy3Ops0mohYkT(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧሲ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,mq5t9JXSdHT8yfDVF(u"ࠫࡌࡋࡔࠨሳ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OLAqp2vxUf5rw79zdgQR1ZboEJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨሴ"))
	if not u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA = VP70ytiFNMBl6vHDaW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱ࠯ࡤࡴ࡮࠴ࡣࡰ࡯࠲࡮ࡸࡵ࡮࠰ࠩስ")+ip+mq5t9JXSdHT8yfDVF(u"ࠧࡀࡨ࡬ࡩࡱࡪࡳ࠾ࡳࡸࡩࡷࡿࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠲ࡣࡪࡶࡼ࠰ࡴ࡬ࡦࡴࡧࡷࠫሶ")
		u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,beV5l2D8HznyJI0(u"ࠨࡉࡈࡘࠬሷ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OLAqp2vxUf5rw79zdgQR1ZboEJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠴ࡱࡨࠬሸ"))
	if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		piN9Qlah4S = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
		L2ZGXvVtpjzFqDfhswxeKi = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(piN9Qlah4S)
		BBWqUHjdw3hiET = list(L2ZGXvVtpjzFqDfhswxeKi.keys())
		if VP70ytiFNMBl6vHDaW(u"ࠪ࡭ࡵ࠭ሹ") in BBWqUHjdw3hiET: ip = L2ZGXvVtpjzFqDfhswxeKi[oiWNFYzcIUeh(u"ࠫ࡮ࡶࠧሺ")]
		if mq5t9JXSdHT8yfDVF(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨሻ") in BBWqUHjdw3hiET: KKtfxAbzoFlcG7wasMq36 = L2ZGXvVtpjzFqDfhswxeKi[IMjqygdfYSKpHlWu5Aa(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩሼ")]
		if GHg28TBchiyn6l(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨሽ") in BBWqUHjdw3hiET: l7L3xtUSXrRAV6nwEMpBv4yimKc0H9 = L2ZGXvVtpjzFqDfhswxeKi[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩሾ")]
		if A6iX18qgyOFlZxz7sc(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨሿ") in BBWqUHjdw3hiET: mh7oVZtHp1Aq9CQ8df5FXJMuR = L2ZGXvVtpjzFqDfhswxeKi[eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩቀ")]
		if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫቁ") in BBWqUHjdw3hiET: mYOBPUqV2k0et91Lw6RQ = L2ZGXvVtpjzFqDfhswxeKi[IMjqygdfYSKpHlWu5Aa(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬቂ")]
		if wwWzyF4ZpSQXKOgk569(u"࠭ࡣࡪࡶࡼࠫቃ") in BBWqUHjdw3hiET: KDuWdg73AY6aOZVqnf = L2ZGXvVtpjzFqDfhswxeKi[wwWzyF4ZpSQXKOgk569(u"ࠧࡤ࡫ࡷࡽࠬቄ")]
		if VP70ytiFNMBl6vHDaW(u"ࠨࡳࡸࡩࡷࡿࠧቅ") in BBWqUHjdw3hiET: ip = L2ZGXvVtpjzFqDfhswxeKi[A41nqbj3wYt(u"ࠩࡴࡹࡪࡸࡹࠨቆ")]
		if Z9FPQvwlbjLTh(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨቇ") in BBWqUHjdw3hiET: mh7oVZtHp1Aq9CQ8df5FXJMuR = L2ZGXvVtpjzFqDfhswxeKi[KLX7hW0nBAEgy6m4SvH(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩቈ")]
		if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩ቉") in BBWqUHjdw3hiET: mYOBPUqV2k0et91Lw6RQ = L2ZGXvVtpjzFqDfhswxeKi[eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪቊ")]
		if CyHU86ZeYT5BWRcitSm2I(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩቋ") in BBWqUHjdw3hiET:
			Ht0yQIadhjOw8GKBvgi6EFUxMsL = L2ZGXvVtpjzFqDfhswxeKi[gPE1XB87fQl(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪቌ")][QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡸࡸࡨ࠭ቍ")]
			if Ht0yQIadhjOw8GKBvgi6EFUxMsL[j0jEZgiKdxFpMLHcU7kQr8v1lyX4] not in [oiWNFYzcIUeh(u"ࠪ࠱ࠬ቎"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࠰࠭቏")]: Ht0yQIadhjOw8GKBvgi6EFUxMsL = SI7eBdND4lx8pt5Qk(u"ࠬ࠱ࠧቐ")+Ht0yQIadhjOw8GKBvgi6EFUxMsL
		if A41nqbj3wYt(u"࠭࡯ࡧࡨࡶࡩࡹ࠭ቑ") in BBWqUHjdw3hiET:
			Ht0yQIadhjOw8GKBvgi6EFUxMsL = L2ZGXvVtpjzFqDfhswxeKi[CyHU86ZeYT5BWRcitSm2I(u"ࠧࡰࡨࡩࡷࡪࡺࠧቒ")]
			if Ht0yQIadhjOw8GKBvgi6EFUxMsL>=bawK2j7T81Nrc4GWs05xzDg(u"࠴ᗫ"): Ht0yQIadhjOw8GKBvgi6EFUxMsL = gPE1XB87fQl(u"ࠨ࠭ࠪቓ")+x54xSdnCFHZ8yliofzOBK.strftime(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠤࠨࡌ࠿ࠫࡍࠣቔ"),x54xSdnCFHZ8yliofzOBK.gmtime(Ht0yQIadhjOw8GKBvgi6EFUxMsL))
			else: Ht0yQIadhjOw8GKBvgi6EFUxMsL = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ࠱ࠬቕ")+x54xSdnCFHZ8yliofzOBK.strftime(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠦࠪࡎ࠺ࠦࡏࠥቖ"),x54xSdnCFHZ8yliofzOBK.gmtime(-Ht0yQIadhjOw8GKBvgi6EFUxMsL))
	a58wlnCLOQ2PgkjZzVxrbe = ip+VP70ytiFNMBl6vHDaW(u"ࠬ࠲ࠧ቗")+KKtfxAbzoFlcG7wasMq36+beV5l2D8HznyJI0(u"࠭ࠬࠨቘ")+l7L3xtUSXrRAV6nwEMpBv4yimKc0H9+CyHU86ZeYT5BWRcitSm2I(u"ࠧ࠭ࠩ቙")+mYOBPUqV2k0et91Lw6RQ+wwWzyF4ZpSQXKOgk569(u"ࠨ࠮ࠪቚ")+KDuWdg73AY6aOZVqnf+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࠯ࠫቛ")+Ht0yQIadhjOw8GKBvgi6EFUxMsL
	a58wlnCLOQ2PgkjZzVxrbe = a58wlnCLOQ2PgkjZzVxrbe.encode(e87cIA5vwOQLDEP1)
	if rJ2oTLqabRtA: a58wlnCLOQ2PgkjZzVxrbe = a58wlnCLOQ2PgkjZzVxrbe.decode(pp7FcjEe6g(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫቜ"))
	A3pXVFdyP1.GEOLOCATION_DATA = clFjTSgMODe7Nq0H3Vzs(a58wlnCLOQ2PgkjZzVxrbe)
	return A3pXVFdyP1.GEOLOCATION_DATA
def XgnSRzMaerBT(ucZifamCg1DJlw):
	v3BgZxYMCWfdzmk407GtTcS1XUr6J,showDialogs = WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa
	if ucZifamCg1DJlw.count(SI7eBdND4lx8pt5Qk(u"ࠫࡤ࠭ቝ"))>=XURrDCfOS9Mbhpv2Pmjos56TeW:
		ucZifamCg1DJlw,v3BgZxYMCWfdzmk407GtTcS1XUr6J = ucZifamCg1DJlw.split(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡥࠧ቞"),wnaWTQM7VJPkZzO9eoSyFU4)
		v3BgZxYMCWfdzmk407GtTcS1XUr6J = ZLr5gRSkFewKdUos90bM(u"࠭࡟ࠨ቟")+v3BgZxYMCWfdzmk407GtTcS1XUr6J
		if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬበ") in v3BgZxYMCWfdzmk407GtTcS1XUr6J: showDialogs = KiryBCvngZzF85UN6xSDlOVweL4I9
		else: showDialogs = r0D4C3z7Onqpa
	return ucZifamCg1DJlw,v3BgZxYMCWfdzmk407GtTcS1XUr6J,showDialogs
def P03eVFBZQTxjOnLN6R():
	oX9rUhfKAiQj1Sgt53 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,iySORMYxWXszEH18(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧቡ"))
	Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(oX9rUhfKAiQj1Sgt53):
		for LLipmUFe3789Mc5Q6s0CBVznIbRXgh in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(oX9rUhfKAiQj1Sgt53):
			if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࠱ࡴࡾࡵࠧቢ") in LLipmUFe3789Mc5Q6s0CBVznIbRXgh: continue
			if ZLr5gRSkFewKdUos90bM(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨባ") in LLipmUFe3789Mc5Q6s0CBVznIbRXgh: continue
			KK9ajP7dDEy3IZSOuAR0Xk = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(oX9rUhfKAiQj1Sgt53,LLipmUFe3789Mc5Q6s0CBVznIbRXgh)
			iXupeEwgFWDzaIxnUlfPhs43RbM6N7,tJqAIFkchTU = KIt6Jwe3Qyxp(KK9ajP7dDEy3IZSOuAR0Xk)
			Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF += iXupeEwgFWDzaIxnUlfPhs43RbM6N7
	return Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF
def CptxmLUw0EaFr(showDialogs):
	NjEBsLkFT7 = G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩቤ"))
	HHqYWtwfmhe3OrM9 = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡹࡴࡳࠩብ"),wwWzyF4ZpSQXKOgk569(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫቦ"),A6iX18qgyOFlZxz7sc(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩቧ"))
	BHJoi25qk3f780Or6pvZdKRNIFQG,VwKXAUmen87jlqJP9DL = NjEBsLkFT7,HHqYWtwfmhe3OrM9
	k6kxWZUAvgoRshKC39Oaed7nLp,Aku1inmcwCldz4Ph5VFrKJIYf89 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪቨ") not in str(A3pXVFdyP1.SEND_THESE_EVENTS):
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA = A3pXVFdyP1.SITESURLS[Z9FPQvwlbjLTh(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩቩ")][vXIdY7TwFKso40gVBq5]
		XCxufKnQs0SDkWY = UwIPdKQt4YDfoJM()
		l7L3xtUSXrRAV6nwEMpBv4yimKc0H9 = XCxufKnQs0SDkWY.split(Z9FPQvwlbjLTh(u"ࠪ࠰ࠬቪ"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
		Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF = P03eVFBZQTxjOnLN6R()
		hBkVcq0AG3MJpaE58Q = {aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡺࡹࡥࡳࠩቫ"):A3pXVFdyP1.AV_CLIENT_IDS,ZLr5gRSkFewKdUos90bM(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ቬ"):mbvW9By35UDO,yobpaW7sBqtKRrv(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧቭ"):l7L3xtUSXrRAV6nwEMpBv4yimKc0H9,oiWNFYzcIUeh(u"ࠧࡪࡦࡶࠫቮ"):hhjzYAw9aeTWbu3KDJ5sy(Vaj3ADEu0KNzZGLhegqwd1fYXlvRrF)}
		u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,A6iX18qgyOFlZxz7sc(u"ࠨࡒࡒࡗ࡙࠭ቯ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,hBkVcq0AG3MJpaE58Q,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ተ"))
		if not u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
			if NjEBsLkFT7 in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡒࡊ࡝ࠧቱ")]: BHJoi25qk3f780Or6pvZdKRNIFQG = beV5l2D8HznyJI0(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቲ")
			elif NjEBsLkFT7==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡕࡌࡅࠩታ"): BHJoi25qk3f780Or6pvZdKRNIFQG = A6iX18qgyOFlZxz7sc(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬቴ")
		else:
			nBxd4l6qjatFSN = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
			nBxd4l6qjatFSN = IXZpzK7ShaRsAN(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧ࡭࡫ࡶࡸࠬት"),nBxd4l6qjatFSN)
			nBxd4l6qjatFSN = sorted(nBxd4l6qjatFSN,reverse=r0D4C3z7Onqpa,key=lambda key: int(key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]))
			Aku1inmcwCldz4Ph5VFrKJIYf89,VwKXAUmen87jlqJP9DL = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
			for jj5bYW7Aws,hNDcxok9iFQs5bfYEUCypumOdjVS,Wab7p2BCHfVhE34Q9mUO in nBxd4l6qjatFSN:
				if jj5bYW7Aws==kdRO82AImh0LFw(u"ࠨ࠲ࠪቶ"):
					Aku1inmcwCldz4Ph5VFrKJIYf89 += Wab7p2BCHfVhE34Q9mUO+bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࠽࠾ࠬቷ")
					continue
				if VwKXAUmen87jlqJP9DL: VwKXAUmen87jlqJP9DL += WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩቸ")+YVr6St5P4xsFC0aARQGKfiegD+bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡡࡴ࡜࡯ࠩቹ")
				zzy3fiwkNlMhcPVKdURm5EYu8jFr = Wab7p2BCHfVhE34Q9mUO.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				Ju5KPR6wlImNo1 = pp7FcjEe6g(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩቺ") if hNDcxok9iFQs5bfYEUCypumOdjVS else WnNGfosHr5STAq8j7miwyRZ6eOUbV
				VwKXAUmen87jlqJP9DL += Wab7p2BCHfVhE34Q9mUO.replace(zzy3fiwkNlMhcPVKdURm5EYu8jFr,RNWqL0gBbKOie1DxjUpzQPh9aZyHX+zzy3fiwkNlMhcPVKdURm5EYu8jFr+Ju5KPR6wlImNo1+YVr6St5P4xsFC0aARQGKfiegD)+WBDnh75CaLEvkcN6p4ez2KXrV3M
			VwKXAUmen87jlqJP9DL = WBDnh75CaLEvkcN6p4ez2KXrV3M+VwKXAUmen87jlqJP9DL+KLX7hW0nBAEgy6m4SvH(u"࠭࡜࡯࡞ࡱࠫቻ")
			Aku1inmcwCldz4Ph5VFrKJIYf89 = Aku1inmcwCldz4Ph5VFrKJIYf89.strip(YYQS36fyPvtuzcEmRL(u"ࠧ࠻࠼ࠪቼ"))
			k6kxWZUAvgoRshKC39Oaed7nLp = G3yDpvxOiSWdAeL.getSetting(yobpaW7sBqtKRrv(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫች"))
			if VwKXAUmen87jlqJP9DL==HHqYWtwfmhe3OrM9 and NjEBsLkFT7 in [aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡒࡐࡉ࠭ቾ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩቿ")]: BHJoi25qk3f780Or6pvZdKRNIFQG = Z9FPQvwlbjLTh(u"ࠫࡔࡒࡄࠨኀ")
			else: BHJoi25qk3f780Or6pvZdKRNIFQG = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡔࡅࡘࠩኁ")
			w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫኂ"),mq5t9JXSdHT8yfDVF(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩኃ"),VwKXAUmen87jlqJP9DL,iXBqSkDU3mRCZf4Ib)
			G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩኄ"),hhjzYAw9aeTWbu3KDJ5sy(jDuxzCtBH7aihsSL9))
			G3yDpvxOiSWdAeL.setSetting(VP70ytiFNMBl6vHDaW(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬኅ"),Aku1inmcwCldz4Ph5VFrKJIYf89)
			oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(CyHU86ZeYT5BWRcitSm2I(u"࠺ᗬ")*Aku1inmcwCldz4Ph5VFrKJIYf89.encode(e87cIA5vwOQLDEP1)).hexdigest()
			oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(A6iX18qgyOFlZxz7sc(u"࠷࠴ᗭ")*oybVOQu7xUdwLzChmfnIYKvN.encode(e87cIA5vwOQLDEP1)).hexdigest()
			oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(aiQwFE1TGx04vmLcsYkIW5jA(u"࠱࠺ᗮ")*oybVOQu7xUdwLzChmfnIYKvN.encode(e87cIA5vwOQLDEP1)).hexdigest()
			OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(p9DTgUZ1auwRYXoHld7v8MP)
			PEZioFnTRIm3(p9DTgUZ1auwRYXoHld7v8MP,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠬኆ")+str(int(oybVOQu7xUdwLzChmfnIYKvN[jhDZ0BAFoEGUcw5QrJkaxXL(u"࠵ᗰ"):Z9FPQvwlbjLTh(u"࠴࠶ᗱ")],YYQS36fyPvtuzcEmRL(u"࠵࠻ᗲ")))[:A41nqbj3wYt(u"࠺ᗯ")]+yobpaW7sBqtKRrv(u"ࠫࠥࡁࠧኇ"))
			OoE5HYUMwsrDWhx2gR7I3FuN.close()
		Y4zeDjypdR0SxLT = r0D4C3z7Onqpa if Aku1inmcwCldz4Ph5VFrKJIYf89!=k6kxWZUAvgoRshKC39Oaed7nLp else KiryBCvngZzF85UN6xSDlOVweL4I9
		if Y4zeDjypdR0SxLT:
			LmSj6AbDzMep = A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI
			A3pXVFdyP1.bWV7czPeIaq,A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI,A3pXVFdyP1.IImTyNn2dP,A3pXVFdyP1.IMAvyqd5QL60a,A3pXVFdyP1.avprivsnorestrict,A3pXVFdyP1.avprivslongperiod = ttz1broY9LTy35uAh0wQPVDEca([pp7FcjEe6g(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ኈ"),KLX7hW0nBAEgy6m4SvH(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ኉"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬኊ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩኋ"),tzZ6PhyDOUnwLM3pdK(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡮ࡰࡉ࡜ࡅࡗࡇ࡛ࠫኌ"),wwWzyF4ZpSQXKOgk569(u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩኍ")])
			aIYnNQ2iT1efOqRuX6Vdks8 = A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI
			if not LmSj6AbDzMep and aIYnNQ2iT1efOqRuX6Vdks8 and beV5l2D8HznyJI0(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩ኎") in A3pXVFdyP1.SEND_THESE_EVENTS:
				A3pXVFdyP1.SEND_THESE_EVENTS.remove(wwWzyF4ZpSQXKOgk569(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪ኏"))
				A3pXVFdyP1.SEND_THESE_EVENTS.append(A6iX18qgyOFlZxz7sc(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨነ"))
			elif LmSj6AbDzMep and not aIYnNQ2iT1efOqRuX6Vdks8 and A6iX18qgyOFlZxz7sc(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩኑ") in A3pXVFdyP1.SEND_THESE_EVENTS:
				A3pXVFdyP1.SEND_THESE_EVENTS.remove(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪኒ"))
				A3pXVFdyP1.SEND_THESE_EVENTS.append(A41nqbj3wYt(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧና"))
			YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	if showDialogs:
		if BHJoi25qk3f780Or6pvZdKRNIFQG in [kdRO82AImh0LFw(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩኔ"),CyHU86ZeYT5BWRcitSm2I(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪን")]:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,Z9FPQvwlbjLTh(u"ࠬํๆศๅู้้ࠣไสࠢไ๎ࠥา็ศิๆࠤํํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅีๅ็อ่ࠥฯࠡ์ๆ์๋ࠦำษส๊หࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥอไาษ๋ฮึࠦวๅะสูࠥฮใࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅลึ่ฬฺ้่ࠠา็ࠬኖ"))
		else:
			Pgbtx1uwX52DEk7Jf(pp7FcjEe6g(u"࠭ࡲࡪࡩ࡫ࡸࠬኗ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪኘ"),VwKXAUmen87jlqJP9DL,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩኙ"))
			BHJoi25qk3f780Or6pvZdKRNIFQG = wwWzyF4ZpSQXKOgk569(u"ࠩࡒࡐࡉ࠭ኚ")
	if BHJoi25qk3f780Or6pvZdKRNIFQG!=NjEBsLkFT7:
		G3yDpvxOiSWdAeL.setSetting(VP70ytiFNMBl6vHDaW(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨኛ"),BHJoi25qk3f780Or6pvZdKRNIFQG)
		YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def IQZ0bGPovap6gWmc4LfY(MPBOrQ7eap0mYAI6cEsKSZTjVy,bTR3nzx6Ouv5KQoP7LiJUtMpH):
	import socket as ccvQsgXNMH
	xlHLGyPQZbwJu8nE49hitgMNF = ccvQsgXNMH.socket(ccvQsgXNMH.AF_INET,ccvQsgXNMH.SOCK_STREAM)
	xlHLGyPQZbwJu8nE49hitgMNF.settimeout(vXIdY7TwFKso40gVBq5)
	try:
		CIeL32XZ57bpg6WFyKB = x54xSdnCFHZ8yliofzOBK.time()
		xlHLGyPQZbwJu8nE49hitgMNF.connect((MPBOrQ7eap0mYAI6cEsKSZTjVy,bTR3nzx6Ouv5KQoP7LiJUtMpH))
		eVcFjAaf7huW3rlQsJqBbDwkgT = x54xSdnCFHZ8yliofzOBK.time()
		FqnIrzBxdAoaEwDy = round((eVcFjAaf7huW3rlQsJqBbDwkgT-CIeL32XZ57bpg6WFyKB)*n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠶࠶࠰࠱ᗳ"))
	except: FqnIrzBxdAoaEwDy = -wnaWTQM7VJPkZzO9eoSyFU4
	xlHLGyPQZbwJu8nE49hitgMNF.close()
	return FqnIrzBxdAoaEwDy
def XJNduZp9YOfjAB2(showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,Z9FPQvwlbjLTh(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪኜ"))
	else: kkLdeyJUsSiK9YwFZr4lPbVE = r0D4C3z7Onqpa
	if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
		for LLipmUFe3789Mc5Q6s0CBVznIbRXgh in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(kcCgDi2EzhU5s413pAjSmu):
			if LLipmUFe3789Mc5Q6s0CBVznIbRXgh.endswith(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬ࠴ࡤࡣࠩኝ")) and oiWNFYzcIUeh(u"࠭ࡤࡢࡶࡤࠫኞ") in LLipmUFe3789Mc5Q6s0CBVznIbRXgh:
				nJQVgbyzTW = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,LLipmUFe3789Mc5Q6s0CBVznIbRXgh)
				OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(nJQVgbyzTW)
				GSB3DNKz9vFbaEo8.execute(A41nqbj3wYt(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪኟ"))
				GSB3DNKz9vFbaEo8.execute(A41nqbj3wYt(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭አ"))
				GSB3DNKz9vFbaEo8.execute(yobpaW7sBqtKRrv(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬኡ"))
				GSB3DNKz9vFbaEo8.execute(A41nqbj3wYt(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ኢ"))
				GSB3DNKz9vFbaEo8.execute(aiQwFE1TGx04vmLcsYkIW5jA(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬኣ"))
				OoE5HYUMwsrDWhx2gR7I3FuN.commit()
				OoE5HYUMwsrDWhx2gR7I3FuN.close()
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,beV5l2D8HznyJI0(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ኤ"))
	return
def OO7gEdhG2U3x6ucLvKoVJyfPRNrk(VVc5mpbkqsLenZFTHfJ8y,NTPQGWXcVsUShi0poe,showDialogs):
	if VVc5mpbkqsLenZFTHfJ8y!=nrfM1GhFckwzAY9Q:
		if VVc5mpbkqsLenZFTHfJ8y==ZZQ6sJcqClADoV9iNa0rK: A3pXVFdyP1.ALLOW_DNS_FIX = r0D4C3z7Onqpa
		elif VVc5mpbkqsLenZFTHfJ8y==z8WclmVQpLo1Hw2beGYjC4griSd: A3pXVFdyP1.ALLOW_DNS_FIX = KiryBCvngZzF85UN6xSDlOVweL4I9
		elif VVc5mpbkqsLenZFTHfJ8y==xsHjBKXaVkMJoRP83: A3pXVFdyP1.ALLOW_DNS_FIX = r0D4C3z7Onqpa
	if NTPQGWXcVsUShi0poe!=nrfM1GhFckwzAY9Q:
		if NTPQGWXcVsUShi0poe==ZZQ6sJcqClADoV9iNa0rK: A3pXVFdyP1.ALLOW_PROXY_FIX = r0D4C3z7Onqpa
		elif NTPQGWXcVsUShi0poe==z8WclmVQpLo1Hw2beGYjC4griSd: A3pXVFdyP1.ALLOW_PROXY_FIX = KiryBCvngZzF85UN6xSDlOVweL4I9
		elif NTPQGWXcVsUShi0poe==xsHjBKXaVkMJoRP83: A3pXVFdyP1.ALLOW_PROXY_FIX = r0D4C3z7Onqpa
	if showDialogs!=nrfM1GhFckwzAY9Q:
		if showDialogs==ZZQ6sJcqClADoV9iNa0rK: A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX = r0D4C3z7Onqpa
		elif showDialogs==z8WclmVQpLo1Hw2beGYjC4griSd: A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX = KiryBCvngZzF85UN6xSDlOVweL4I9
		elif showDialogs==xsHjBKXaVkMJoRP83: A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX = r0D4C3z7Onqpa
	return
def cmMbydiFzsLK9N50C6GA(website,aF7CAm9lqQuKE6UjyN,FyGxXhkzOER4nNIJaf=OHohTgj06taKzsG):
	aO4lRoWnwSkPdD3qfhrA = bawK2j7T81Nrc4GWs05xzDg(u"࠷࠰ᗴ")
	xH6zJOhitPNoljXYbsKrkqyM0uQ8Uw = [mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),mq5t9JXSdHT8yfDVF(u"࠲࠲ᗶ"),ZLr5gRSkFewKdUos90bM(u"࠷ᗷ"),mq5t9JXSdHT8yfDVF(u"࠲࠲ᗶ"),mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),mq5t9JXSdHT8yfDVF(u"࠱ᗵ"),ZLr5gRSkFewKdUos90bM(u"࠷ᗷ")]
	EKbVsQOX25Nem = []
	l9lw1gAkECtKI0 = [wwWzyF4ZpSQXKOgk569(u"࠳ᗸ")]*aO4lRoWnwSkPdD3qfhrA
	llzgNOf4JHRnvoWjt = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,wwWzyF4ZpSQXKOgk569(u"࠭ࡤࡪࡥࡷࠫእ"),oiWNFYzcIUeh(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩኦ"))
	for mEBVc5JysfZHedMt4I2vg in list(llzgNOf4JHRnvoWjt.keys()):
		if website not in mEBVc5JysfZHedMt4I2vg: continue
		OOG1iPYhTKQ4,VwDQWpfU9HSvrL678 = mEBVc5JysfZHedMt4I2vg.split(VP70ytiFNMBl6vHDaW(u"ࠨࡡࡢࠫኧ"))
		l9lw1gAkECtKI0[int(VwDQWpfU9HSvrL678)] = llzgNOf4JHRnvoWjt[mEBVc5JysfZHedMt4I2vg]
	for VV60kArCYGvUWNOLymTJze in range(aO4lRoWnwSkPdD3qfhrA):
		if VV60kArCYGvUWNOLymTJze in A3pXVFdyP1.BADSCRAPERS+aF7CAm9lqQuKE6UjyN: continue
		if VV60kArCYGvUWNOLymTJze==FyGxXhkzOER4nNIJaf: l9lw1gAkECtKI0[VV60kArCYGvUWNOLymTJze] = l9lw1gAkECtKI0[VV60kArCYGvUWNOLymTJze]+yobpaW7sBqtKRrv(u"࠵ᗹ")
		if l9lw1gAkECtKI0[VV60kArCYGvUWNOLymTJze]<aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠸ᗺ"): EKbVsQOX25Nem += [VV60kArCYGvUWNOLymTJze]*xH6zJOhitPNoljXYbsKrkqyM0uQ8Uw[VV60kArCYGvUWNOLymTJze]
	if not EKbVsQOX25Nem:
		for VV60kArCYGvUWNOLymTJze in range(aO4lRoWnwSkPdD3qfhrA):
			l9lw1gAkECtKI0[VV60kArCYGvUWNOLymTJze] = CyHU86ZeYT5BWRcitSm2I(u"࠶ᗻ")
			if VV60kArCYGvUWNOLymTJze in A3pXVFdyP1.BADSCRAPERS+aF7CAm9lqQuKE6UjyN: continue
			EKbVsQOX25Nem += [VV60kArCYGvUWNOLymTJze]*xH6zJOhitPNoljXYbsKrkqyM0uQ8Uw[VV60kArCYGvUWNOLymTJze]
	for VV60kArCYGvUWNOLymTJze in A3pXVFdyP1.BADSCRAPERS: l9lw1gAkECtKI0[VV60kArCYGvUWNOLymTJze] = bawK2j7T81Nrc4GWs05xzDg(u"࠹࠺࠻࠼ᗼ")
	HTAdf8l1v7Up2wxN9gVDEMBSLs6 = []
	for VV60kArCYGvUWNOLymTJze in range(aO4lRoWnwSkPdD3qfhrA): HTAdf8l1v7Up2wxN9gVDEMBSLs6.append(website+ZLr5gRSkFewKdUos90bM(u"ࠩࡢࡣࠬከ")+str(VV60kArCYGvUWNOLymTJze))
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬኩ"),HTAdf8l1v7Up2wxN9gVDEMBSLs6,l9lw1gAkECtKI0,d9sTRDNU6v5XWhtknQSmAz8joZCK*VP70ytiFNMBl6vHDaW(u"࠶ᗽ"),r0D4C3z7Onqpa)
	return EKbVsQOX25Nem
def iaE3YPpKG4mtB7M5zXNRCd16TI8e0A(g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,cquGxZCOaDk3QJMNlXSeU=WnNGfosHr5STAq8j7miwyRZ6eOUbV,PPSTwoZdRinA3YXtybaeVux9Om0E=WnNGfosHr5STAq8j7miwyRZ6eOUbV,aF7CAm9lqQuKE6UjyN=[]):
	website = ADN3XhW9ZpVmFK84j2roiy.split(A41nqbj3wYt(u"ࠫ࠲࠭ኪ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	MyRtQPSCXDNnx461m = cmMbydiFzsLK9N50C6GA(website,aF7CAm9lqQuKE6UjyN)
	tKf5NLDXilz9MFGa3YJmUWwsu = []
	if website==A6iX18qgyOFlZxz7sc(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧካ"):
		if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if wnaWTQM7VJPkZzO9eoSyFU4 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [wnaWTQM7VJPkZzO9eoSyFU4]
		if XURrDCfOS9Mbhpv2Pmjos56TeW in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [XURrDCfOS9Mbhpv2Pmjos56TeW]
		if vXIdY7TwFKso40gVBq5 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [vXIdY7TwFKso40gVBq5]*wwWzyF4ZpSQXKOgk569(u"࠳࠳ᗾ")
		if yGLl1nSBrJPmi2adko9O in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [yGLl1nSBrJPmi2adko9O]*EEowc8rs5gUZTVjdOzmb0nu
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*bawK2j7T81Nrc4GWs05xzDg(u"࠴࠴ᗿ")
		if IMjqygdfYSKpHlWu5Aa(u"࠺ᘀ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [IMjqygdfYSKpHlWu5Aa(u"࠺ᘀ")]
		if yobpaW7sBqtKRrv(u"࠼ᘁ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [yobpaW7sBqtKRrv(u"࠼ᘁ")]
	elif website==beV5l2D8HznyJI0(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨኬ"):
		if vXIdY7TwFKso40gVBq5 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [vXIdY7TwFKso40gVBq5]*XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠷࠰ᘂ")
	elif website==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪክ"):
		if yGLl1nSBrJPmi2adko9O in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [yGLl1nSBrJPmi2adko9O]*EEowc8rs5gUZTVjdOzmb0nu
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*IMjqygdfYSKpHlWu5Aa(u"࠱࠱ᘃ")
	elif website==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩኮ"):
		if tzZ6PhyDOUnwLM3pdK(u"࠺ᘄ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [tzZ6PhyDOUnwLM3pdK(u"࠺ᘄ")]*Z9FPQvwlbjLTh(u"࠳࠳ᘅ")
	elif website==iySORMYxWXszEH18(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪኯ"):
		if wnaWTQM7VJPkZzO9eoSyFU4 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [wnaWTQM7VJPkZzO9eoSyFU4]
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*bawK2j7T81Nrc4GWs05xzDg(u"࠴࠴ᘆ")
	elif website==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡋࡔࡕࡇࡍࡇࡖࡉࡆࡘࡃࡉࠩኰ"):
		if yGLl1nSBrJPmi2adko9O in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [yGLl1nSBrJPmi2adko9O]*EEowc8rs5gUZTVjdOzmb0nu
	elif website==beV5l2D8HznyJI0(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ኱"):
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*IMjqygdfYSKpHlWu5Aa(u"࠵࠵ᘇ")
		if aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠻ᘈ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠻ᘈ")]
		if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠽ᘉ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠽ᘉ")]
		if I872Vum45fMNe1BRngTZLoQiqvkt(u"࠸ᘊ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [I872Vum45fMNe1BRngTZLoQiqvkt(u"࠸ᘊ")]
	elif website==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧኲ"):
		if pp7FcjEe6g(u"࠷ᘋ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [pp7FcjEe6g(u"࠷ᘋ")]
		if gPE1XB87fQl(u"࠹ᘌ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [gPE1XB87fQl(u"࠹ᘌ")]
	elif website==aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨኳ"):
		if wnaWTQM7VJPkZzO9eoSyFU4 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [wnaWTQM7VJPkZzO9eoSyFU4]
		if yGLl1nSBrJPmi2adko9O in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [yGLl1nSBrJPmi2adko9O]*EEowc8rs5gUZTVjdOzmb0nu
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*iySORMYxWXszEH18(u"࠴࠴ᘍ")
		if pp7FcjEe6g(u"࠺ᘎ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [pp7FcjEe6g(u"࠺ᘎ")]
		if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠼ᘏ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠼ᘏ")]
	elif website==VP70ytiFNMBl6vHDaW(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩኴ"):
		if wnaWTQM7VJPkZzO9eoSyFU4 in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [wnaWTQM7VJPkZzO9eoSyFU4]
		if EEowc8rs5gUZTVjdOzmb0nu in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [EEowc8rs5gUZTVjdOzmb0nu]*pp7FcjEe6g(u"࠷࠰ᘐ")
		if Z9FPQvwlbjLTh(u"࠸ᘑ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [Z9FPQvwlbjLTh(u"࠸ᘑ")]
		if YYQS36fyPvtuzcEmRL(u"࠺ᘒ") in MyRtQPSCXDNnx461m: tKf5NLDXilz9MFGa3YJmUWwsu += [YYQS36fyPvtuzcEmRL(u"࠺ᘒ")]*A41nqbj3wYt(u"࠳࠳ᘓ")
	if tKf5NLDXilz9MFGa3YJmUWwsu: MyRtQPSCXDNnx461m = tKf5NLDXilz9MFGa3YJmUWwsu
	if MyRtQPSCXDNnx461m:
		ko4qivEs7KyLB6h = FxEWL1w4gjr8mM.sample(MyRtQPSCXDNnx461m,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	else: ko4qivEs7KyLB6h = -wnaWTQM7VJPkZzO9eoSyFU4
	SSGMaodDRQwn = YYQS36fyPvtuzcEmRL(u"ࠨีํีๆืࠠาไ่ࠤࠬኵ")+str(ko4qivEs7KyLB6h)
	SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+YYQS36fyPvtuzcEmRL(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭኶")+str(ko4qivEs7KyLB6h)+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ኷")+str(cquGxZCOaDk3QJMNlXSeU)+oiWNFYzcIUeh(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬኸ")+PPSTwoZdRinA3YXtybaeVux9Om0E+beV5l2D8HznyJI0(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኹ")+ADN3XhW9ZpVmFK84j2roiy+ZLr5gRSkFewKdUos90bM(u"࠭ࠠ࡞࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫኺ")+vcQbFfCk6T1+kdRO82AImh0LFw(u"ࠧࠡ࡟ࠪኻ"))
	update = r0D4C3z7Onqpa
	if ko4qivEs7KyLB6h==j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
		scraperserver = tzZ6PhyDOUnwLM3pdK(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠵ࠬኼ")
		v0ikM3NKCOILGpgSr9 = GHg28TBchiyn6l(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠱࠶࠲ࡧ࠶࠷࡬࠱࠮ࡥ࠸࠼ࡦ࠳࠴࠱࠴࠴࠱ࡦࡧ࠸࠵࠯ࡨ࠽࠷࠹ࡣࡢࡨ࠻࠹࠽࠹࠴ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫኽ")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+wwWzyF4ZpSQXKOgk569(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኾ")+v0ikM3NKCOILGpgSr9+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ኿")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==wnaWTQM7VJPkZzO9eoSyFU4:
		scraperserver = mq5t9JXSdHT8yfDVF(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠳ࠩዀ")
		v0ikM3NKCOILGpgSr9 = aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨ዁")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+SI7eBdND4lx8pt5Qk(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧዂ")+v0ikM3NKCOILGpgSr9+Z9FPQvwlbjLTh(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዃ")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==XURrDCfOS9Mbhpv2Pmjos56TeW:
		scraperserver = rVy3Ops0mohYkT(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ዄ")
		v0ikM3NKCOILGpgSr9 = yobpaW7sBqtKRrv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࡀ࡭ࡱࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩዅ")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+CyHU86ZeYT5BWRcitSm2I(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ዆")+v0ikM3NKCOILGpgSr9+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ዇")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==vXIdY7TwFKso40gVBq5:
		scraperserver = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨወ")
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1.replace(rVy3Ops0mohYkT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩዉ"),mq5t9JXSdHT8yfDVF(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩዊ"))
		Ak4FHQP7vfhd6bYU = mq5t9JXSdHT8yfDVF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴࡪࡻࡰ࠯ࡥࡲࡱ࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠫࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡋࡧ࡬ࡴࡧࠩࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰࠫࡻࡲ࡭࠿ࠪዋ")+ZisgmEGCOJxVI9DcetNBPo6(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(gPE1XB87fQl(u"ࠪࡋࡊ࡚ࠧዌ"),Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==yGLl1nSBrJPmi2adko9O:
		scraperserver = rVy3Ops0mohYkT(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫው")
		Ak4FHQP7vfhd6bYU = YYQS36fyPvtuzcEmRL(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵ࠰ࡦࡳࡲ࠵࠿ࡵࡱ࡮ࡩࡳࡃࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠧࡲࡵࡳࡽࡿࡃࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡹࡷࡲ࠽ࠨዎ")+ZisgmEGCOJxVI9DcetNBPo6(vcQbFfCk6T1)
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡇࡆࡖࠪዏ"),Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
		try:
			RR92fJL81AZWhmzguqbSd6xKo.content = IXZpzK7ShaRsAN(yobpaW7sBqtKRrv(u"ࠧࡥ࡫ࡦࡸࠬዐ"),RR92fJL81AZWhmzguqbSd6xKo.content)
			RR92fJL81AZWhmzguqbSd6xKo.content = RR92fJL81AZWhmzguqbSd6xKo.content[kdRO82AImh0LFw(u"ࠨࡴࡨࡷࡺࡲࡴࠨዑ")]
		except: pass
	elif ko4qivEs7KyLB6h==EEowc8rs5gUZTVjdOzmb0nu:
		scraperserver = beV5l2D8HznyJI0(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠱ࠨዒ")
		v0ikM3NKCOILGpgSr9 = oiWNFYzcIUeh(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡋࡏࠪࡧࡸ࡯ࡸࡵࡨࡶࡂࡌࡡ࡭ࡵࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨዓ")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+bawK2j7T81Nrc4GWs05xzDg(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫዔ")+v0ikM3NKCOILGpgSr9+IMjqygdfYSKpHlWu5Aa(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዕ")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==mq5t9JXSdHT8yfDVF(u"࠹ᘔ"):
		scraperserver = yobpaW7sBqtKRrv(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠳ࠪዖ")
		v0ikM3NKCOILGpgSr9 = A41nqbj3wYt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫ዗")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+iySORMYxWXszEH18(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨዘ")+v0ikM3NKCOILGpgSr9+rVy3Ops0mohYkT(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩዙ")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==gPE1XB87fQl(u"࠻ᘕ"):
		scraperserver = VP70ytiFNMBl6vHDaW(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠸ࠧዚ")
		v0ikM3NKCOILGpgSr9 = A41nqbj3wYt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨዛ")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+oiWNFYzcIUeh(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዜ")+v0ikM3NKCOILGpgSr9+yobpaW7sBqtKRrv(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ዝ")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠽ᘖ"):
		scraperserver = gPE1XB87fQl(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠶ࠫዞ")
		Ak4FHQP7vfhd6bYU = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠯ࡷ࠳࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠦࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩዟ")+ZisgmEGCOJxVI9DcetNBPo6(vcQbFfCk6T1)
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(Z9FPQvwlbjLTh(u"ࠩࡊࡉ࡙࠭ዠ"),Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif ko4qivEs7KyLB6h==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠿ᘗ"):
		scraperserver = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠳ࠩዡ")
		v0ikM3NKCOILGpgSr9 = I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡸࡥࡵࡷࡵࡲࡤࡶࡡࡨࡧࡢࡷࡴࡻࡲࡤࡧࡀࡸࡷࡻࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬዢ")
		Ak4FHQP7vfhd6bYU = vcQbFfCk6T1+pp7FcjEe6g(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዣ")+v0ikM3NKCOILGpgSr9+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ዤ")
		RR92fJL81AZWhmzguqbSd6xKo = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,Ak4FHQP7vfhd6bYU,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	else:
		scraperserver,Ak4FHQP7vfhd6bYU = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		RR92fJL81AZWhmzguqbSd6xKo = OOLSaYvmWAiTPXfuM9y3x5zZJ()
		update = KiryBCvngZzF85UN6xSDlOVweL4I9
	W9OwnF7h0Ql5r6uyL = (ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡷࡧࡵ࡭࡫ࡿ࠮ࡩࡶࡰࡰࡄࡸࡥࡥ࡫ࡵࡩࡨࡺ࠽ࠨዥ") in vcQbFfCk6T1)
	if W9OwnF7h0Ql5r6uyL: RR92fJL81AZWhmzguqbSd6xKo.succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
	if update and not RR92fJL81AZWhmzguqbSd6xKo.succeeded:
		cmMbydiFzsLK9N50C6GA(website,[],ko4qivEs7KyLB6h)
		if len(list(set(MyRtQPSCXDNnx461m)))>wnaWTQM7VJPkZzO9eoSyFU4:
			kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨๆ็วุ็ࠠิ์ิๅึࠦๅฺษ็ะฮࠦวๅฯฯฬࠥืโๆࠢࠪዦ")+str(ko4qivEs7KyLB6h)+wwWzyF4ZpSQXKOgk569(u"ࠩࠣๅู๊ࠠโ์ࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠠ࠯࠰๋้ࠣࠦสา์าࠤ๊ำว้ๆฬࠤฯาว้ิࠣห้ำฬษ่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦำ๋ำไี๋ࠥฮหๆไࠤฤࠧࠧዧ"))
			if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
				aF7CAm9lqQuKE6UjyN.append(ko4qivEs7KyLB6h)
				RR92fJL81AZWhmzguqbSd6xKo = iaE3YPpKG4mtB7M5zXNRCd16TI8e0A(g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E,aF7CAm9lqQuKE6UjyN)
				return RR92fJL81AZWhmzguqbSd6xKo
	RR92fJL81AZWhmzguqbSd6xKo.scrapernumber = str(ko4qivEs7KyLB6h)
	scraperserver = scraperserver+iySORMYxWXszEH18(u"ࠪࠤ࠿ࠦࠧየ")+str(ko4qivEs7KyLB6h)
	RR92fJL81AZWhmzguqbSd6xKo.scraperserver = scraperserver
	RR92fJL81AZWhmzguqbSd6xKo.scraperurl = Ak4FHQP7vfhd6bYU
	if RR92fJL81AZWhmzguqbSd6xKo.succeeded:
		SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+pp7FcjEe6g(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫዩ")+scraperserver+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዪ")+ADN3XhW9ZpVmFK84j2roiy+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬያ")+vcQbFfCk6T1+rVy3Ops0mohYkT(u"ࠧࠡ࡟ࠪዬ"))
		uTaiRMI8eYmN(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪይ"),SSGMaodDRQwn,x54xSdnCFHZ8yliofzOBK=yobpaW7sBqtKRrv(u"࠱࠱࠲࠳ᘘ"))
	else:
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+YYQS36fyPvtuzcEmRL(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ዮ")+scraperserver+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪዯ")+str(RR92fJL81AZWhmzguqbSd6xKo.code)+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ደ")+RR92fJL81AZWhmzguqbSd6xKo.reason+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዱ")+ADN3XhW9ZpVmFK84j2roiy+oiWNFYzcIUeh(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬዲ")+vcQbFfCk6T1+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࠡ࡟ࠪዳ"))
		uTaiRMI8eYmN(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨใื่ฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪዴ"),SSGMaodDRQwn,x54xSdnCFHZ8yliofzOBK=A6iX18qgyOFlZxz7sc(u"࠲࠲࠳࠴ᘙ"))
	return RR92fJL81AZWhmzguqbSd6xKo
def RwK6BEzIXLl8oaWV94v2(XgfsEHex8hCzQY7vFNTBrW,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,showDialogs,ADN3XhW9ZpVmFK84j2roiy):
	if not N4HDrYcWePfI0yxjb2 or isinstance(N4HDrYcWePfI0yxjb2,dict): g0Sft2VkTxGD1pYobnsX76E = mq5t9JXSdHT8yfDVF(u"ࠩࡊࡉ࡙࠭ድ")
	else:
		g0Sft2VkTxGD1pYobnsX76E = wwWzyF4ZpSQXKOgk569(u"ࠪࡔࡔ࡙ࡔࠨዶ")
		N4HDrYcWePfI0yxjb2 = EZk136aeLoNqPvlDcTQpyM9Wm(N4HDrYcWePfI0yxjb2)
		I0AK61ilbOp8gQC,N4HDrYcWePfI0yxjb2 = bJlfaY9rk80uXWZzV2oeNBcI(N4HDrYcWePfI0yxjb2)
	u4vhNT8C0k1tmrxX9F5gGWo7Z = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,r0D4C3z7Onqpa,showDialogs,ADN3XhW9ZpVmFK84j2roiy)
	VbRFshPMjr2t3k = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
	VbRFshPMjr2t3k = str(VbRFshPMjr2t3k)
	return VbRFshPMjr2t3k
def CCeIOiGo7sNfQJTjSrnaYlw(kdNn2Zqsj4wPi5ThuoUQvtcg6OA):
	VDfuiTeGNbpKBqdPCAntaJFMgmQ3 = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࢁࢂࠧዷ"))
	vcQbFfCk6T1,j9jmDsfvq51,FzwtaeUBAmWNYT8P1KL7,aKjiD1o926NyV = VDfuiTeGNbpKBqdPCAntaJFMgmQ3[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],OHohTgj06taKzsG,OHohTgj06taKzsG,r0D4C3z7Onqpa
	for o6r9VHUax2FMSKLRfCATb5k0n in VDfuiTeGNbpKBqdPCAntaJFMgmQ3:
		if A41nqbj3wYt(u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪዸ") in o6r9VHUax2FMSKLRfCATb5k0n: j9jmDsfvq51 = o6r9VHUax2FMSKLRfCATb5k0n[yobpaW7sBqtKRrv(u"࠳࠴ᘚ"):]
		elif A6iX18qgyOFlZxz7sc(u"࠭ࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩዹ") in o6r9VHUax2FMSKLRfCATb5k0n: FzwtaeUBAmWNYT8P1KL7 = o6r9VHUax2FMSKLRfCATb5k0n[CyHU86ZeYT5BWRcitSm2I(u"࠼ᘛ"):]
		elif aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዺ") in o6r9VHUax2FMSKLRfCATb5k0n: aKjiD1o926NyV = KiryBCvngZzF85UN6xSDlOVweL4I9
	return vcQbFfCk6T1,j9jmDsfvq51,FzwtaeUBAmWNYT8P1KL7,aKjiD1o926NyV
def QLH9sOa0ISWxzhV31F4fBJltq62eb(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,tl3jn84oPaydK6kR0CJSx,fMR6dVkwKlaYFL,OFr6l2TKB3wApjqGLfPkWNdt0zi45,OLAqp2vxUf5rw79zdgQR1ZboEJ=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	wNPgTf3BGOM97xJSKAXzIimejQ = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,wwWzyF4ZpSQXKOgk569(u"ࠨࡷࡵࡰࠬዻ"))
	uIaG24zXrQJYpc = G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫዼ")+tl3jn84oPaydK6kR0CJSx)
	if wNPgTf3BGOM97xJSKAXzIimejQ==uIaG24zXrQJYpc: G3yDpvxOiSWdAeL.setSetting(gPE1XB87fQl(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬዽ")+tl3jn84oPaydK6kR0CJSx,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if uIaG24zXrQJYpc: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(wNPgTf3BGOM97xJSKAXzIimejQ,uIaG24zXrQJYpc)
	else:
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = kdNn2Zqsj4wPi5ThuoUQvtcg6OA
		uIaG24zXrQJYpc = wNPgTf3BGOM97xJSKAXzIimejQ
	jjWCduSz9lRnpNk7BmsI12 = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OLAqp2vxUf5rw79zdgQR1ZboEJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨዾ"))
	VbRFshPMjr2t3k = jjWCduSz9lRnpNk7BmsI12.content
	if rJ2oTLqabRtA:
		try: VbRFshPMjr2t3k = VbRFshPMjr2t3k.decode(e87cIA5vwOQLDEP1,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬዿ"))
		except: pass
	if not jjWCduSz9lRnpNk7BmsI12.succeeded or OFr6l2TKB3wApjqGLfPkWNdt0zi45 not in VbRFshPMjr2t3k:
		fMR6dVkwKlaYFL = fMR6dVkwKlaYFL.replace(kcXMWrwiLDKeBHRsJ,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࠫࠨጀ"))
		vcQbFfCk6T1 = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬጁ")+fMR6dVkwKlaYFL
		W67hPCcaOek094 = {n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬጂ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
		VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ጃ"))
		if VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded:
			VbRFshPMjr2t3k = VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content
			if rJ2oTLqabRtA:
				try: VbRFshPMjr2t3k = VbRFshPMjr2t3k.decode(e87cIA5vwOQLDEP1,SI7eBdND4lx8pt5Qk(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪጄ"))
				except: pass
			laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall(rVy3Ops0mohYkT(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬጅ"),VbRFshPMjr2t3k,p7dwlH1PRStBgyMUW.DOTALL)
			sSHGQAvayDXeM79OEC81qYdjIF6Nk = [uIaG24zXrQJYpc]
			CX4kv68nfQ9VseJZgRPubhT1ctwyx = [pp7FcjEe6g(u"ࠬࡧࡰ࡬ࠩጆ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ጇ"),A6iX18qgyOFlZxz7sc(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨገ"),SI7eBdND4lx8pt5Qk(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩጉ"),YYQS36fyPvtuzcEmRL(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫጊ"),VP70ytiFNMBl6vHDaW(u"ࠪࡴ࡭ࡶࠧጋ"),A41nqbj3wYt(u"ࠫࡦࡺ࡬ࡢࡳࠪጌ"),ZLr5gRSkFewKdUos90bM(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪግ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭ጎ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩጏ"),VP70ytiFNMBl6vHDaW(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪጐ"),A6iX18qgyOFlZxz7sc(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫ጑"),wwWzyF4ZpSQXKOgk569(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭ጒ"),Z9FPQvwlbjLTh(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭ጓ"),oiWNFYzcIUeh(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩጔ"),CyHU86ZeYT5BWRcitSm2I(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩጕ")]
			for WLJhgkxQ0PpazH8n4veoSBZM in laAHpo1bzyM0q:
				if any(value in WLJhgkxQ0PpazH8n4veoSBZM for value in CX4kv68nfQ9VseJZgRPubhT1ctwyx): continue
				uIaG24zXrQJYpc = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(WLJhgkxQ0PpazH8n4veoSBZM,pp7FcjEe6g(u"ࠧࡶࡴ࡯ࠫ጖"))
				if uIaG24zXrQJYpc in sSHGQAvayDXeM79OEC81qYdjIF6Nk: continue
				if len(sSHGQAvayDXeM79OEC81qYdjIF6Nk)==mq5t9JXSdHT8yfDVF(u"࠽ᘜ"):
					SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+A41nqbj3wYt(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ጗")+tl3jn84oPaydK6kR0CJSx+wwWzyF4ZpSQXKOgk569(u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧጘ")+wNPgTf3BGOM97xJSKAXzIimejQ+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࡢ࠭ጙ"))
					G3yDpvxOiSWdAeL.setSetting(IMjqygdfYSKpHlWu5Aa(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭ጚ")+tl3jn84oPaydK6kR0CJSx,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
					break
				sSHGQAvayDXeM79OEC81qYdjIF6Nk.append(uIaG24zXrQJYpc)
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(wNPgTf3BGOM97xJSKAXzIimejQ,uIaG24zXrQJYpc)
				jjWCduSz9lRnpNk7BmsI12 = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,OLAqp2vxUf5rw79zdgQR1ZboEJ,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩጛ"))
				VbRFshPMjr2t3k = jjWCduSz9lRnpNk7BmsI12.content
				if jjWCduSz9lRnpNk7BmsI12.succeeded and OFr6l2TKB3wApjqGLfPkWNdt0zi45 in VbRFshPMjr2t3k:
					SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+kdRO82AImh0LFw(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ጜ")+tl3jn84oPaydK6kR0CJSx+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭ጝ")+uIaG24zXrQJYpc+SI7eBdND4lx8pt5Qk(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ጞ")+wNPgTf3BGOM97xJSKAXzIimejQ+Z9FPQvwlbjLTh(u"ࠩࠣࡡࠬጟ"))
					G3yDpvxOiSWdAeL.setSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬጠ")+tl3jn84oPaydK6kR0CJSx,uIaG24zXrQJYpc)
					break
	return uIaG24zXrQJYpc,QQTfhlZEDnu4wVcOeHGNyCBo5t2,jjWCduSz9lRnpNk7BmsI12
def v2oRq5AhQzcx(HvzeZpTRrx9j1hMBV3):
	fXn20PaFubHryqZDxO = {
	 mq5t9JXSdHT8yfDVF(u"ࠫࡦ࡮ࡷࡢ࡭ࠪጡ")				:YYQS36fyPvtuzcEmRL(u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧጢ")
	,pp7FcjEe6g(u"࠭ࡡ࡬ࡱࡤࡱࠬጣ")				:Z9FPQvwlbjLTh(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫጤ")
	,iySORMYxWXszEH18(u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪጥ")				:lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪጦ")
	,kdRO82AImh0LFw(u"ࠪࡥࡰࡽࡡ࡮ࠩጧ")				:lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨጨ")
	,tzZ6PhyDOUnwLM3pdK(u"ࠬࡧ࡫ࡸࡣࡰࡸࡺࡨࡥࠨጩ")			:SI7eBdND4lx8pt5Qk(u"࠭ๅ้ไ฼ࠤฬ้่ศ็ࠣฮ๏๎ศࠨጪ")
	,YYQS36fyPvtuzcEmRL(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧጫ")				:bawK2j7T81Nrc4GWs05xzDg(u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨጬ")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫጭ")				:IMjqygdfYSKpHlWu5Aa(u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩጮ")
	,rVy3Ops0mohYkT(u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧጯ")			:A41nqbj3wYt(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨጰ")
	,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨጱ")				:Z9FPQvwlbjLTh(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫጲ")
	,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡣ࡯ࡱࡸࡺࡢࡢࠩጳ")				:iySORMYxWXszEH18(u"่ࠩ์็฿ࠠศๆู่฼ฮษࠨጴ")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡥࡳ࡯࡭ࡦࡼ࡬ࡨࠬጵ")				:eUYX1LQCSJyNZtMsukTBhA4cfj(u"๊ࠫ๎โฺࠢส๊๊๐ࠠำัࠪጶ")
	,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪጷ")			:beV5l2D8HznyJI0(u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨጸ")
	,oiWNFYzcIUeh(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩጹ")				:aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨጺ")
	,pp7FcjEe6g(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫጻ")				:tzZ6PhyDOUnwLM3pdK(u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫጼ")
	,gPE1XB87fQl(u"ࠫࡦࡿ࡬ࡰ࡮ࠪጽ")				:mq5t9JXSdHT8yfDVF(u"๋่ࠬใ฻ࠣว๏๊่ๅࠩጾ")
	,YYQS36fyPvtuzcEmRL(u"࠭ࡢࡰ࡭ࡵࡥࠬጿ")				:I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧๆ๊ๅ฽ࠥฮใาษࠪፀ")
	,wwWzyF4ZpSQXKOgk569(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨፁ")				:A6iX18qgyOFlZxz7sc(u"่ࠩ์็฿ࠠษำึฮ๏าࠧፂ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫፃ")				:oiWNFYzcIUeh(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫፄ")
	,yobpaW7sBqtKRrv(u"ࠬࡩࡩ࡮ࡣ࠷ࡴࠬፅ")				:beV5l2D8HznyJI0(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึࠦศ๋ࠩፆ")
	,rVy3Ops0mohYkT(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧፇ")				:wwWzyF4ZpSQXKOgk569(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪፈ")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫፉ")				:ZLr5gRSkFewKdUos90bM(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫፊ")
	,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ፋ")				:Z9FPQvwlbjLTh(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ፌ")
	,IMjqygdfYSKpHlWu5Aa(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬፍ")			:bawK2j7T81Nrc4GWs05xzDg(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬፎ")
	,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪፏ")				:oiWNFYzcIUeh(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪፐ")
	,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬፑ")				:eUYX1LQCSJyNZtMsukTBhA4cfj(u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬፒ")
	,tzZ6PhyDOUnwLM3pdK(u"ࠬࡩࡩ࡮ࡣࡩࡶࡪ࡫ࠧፓ")				:eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไี๏࠭ፔ")
	,iySORMYxWXszEH18(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪፕ")			:ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩፖ")
	,iySORMYxWXszEH18(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪፗ")				:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪፘ")
	,kdRO82AImh0LFw(u"ࠫࡨ࡯࡭ࡢࡹࡥࡥࡸ࠭ፙ")				:beV5l2D8HznyJI0(u"๋่ࠬใ฻ࠣื๏๋ว๊ࠡหืࠬፚ")
	,A41nqbj3wYt(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ፛")			:A41nqbj3wYt(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠩ፜")
	,IMjqygdfYSKpHlWu5Aa(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨ፝")	:wwWzyF4ZpSQXKOgk569(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤู๊สฯั่๎๋࠭፞")
	,Z9FPQvwlbjLTh(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡪࡤࡷ࡭ࡺࡡࡨࡵࠪ፟")	:kdRO82AImh0LFw(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦ็ศึอห่࠭፠")
	,oiWNFYzcIUeh(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡰ࡮ࡼࡥࡴࠩ፡")	:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็หหูืࠧ።")
	,iySORMYxWXszEH18(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ፣"):yobpaW7sBqtKRrv(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ፤")
	,oiWNFYzcIUeh(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡵࡱࡳ࡭ࡨࡹࠧ፥")	:GHg28TBchiyn6l(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬ፦")
	,ZLr5gRSkFewKdUos90bM(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩ፧")	:tzZ6PhyDOUnwLM3pdK(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ፨")
	,GHg28TBchiyn6l(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ፩")				:QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧๆฬ๋ๆๆ࠭፪")
	,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡦࡵࡥࡲࡧࡣࡢࡨࡨࠫ፫")			:beV5l2D8HznyJI0(u"่ࠩ์็฿ࠠะำส้ฬࠦใศใํ๋ࠬ፬")
	,IMjqygdfYSKpHlWu5Aa(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ፭")				:lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ፮")
	,Z9FPQvwlbjLTh(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭፯")				:iySORMYxWXszEH18(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ፰")
	,A41nqbj3wYt(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ፱")				:I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ፲")
	,VP70ytiFNMBl6vHDaW(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ፳")				:QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭፴")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭፵")				:I872Vum45fMNe1BRngTZLoQiqvkt(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨ፶")
	,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨ፷")				:QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪ፸")
	,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ፹")			:SI7eBdND4lx8pt5Qk(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ፺")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫ፻")				:kdRO82AImh0LFw(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫ፼")
	,rVy3Ops0mohYkT(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ፽")				:pp7FcjEe6g(u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭፾")
	,A6iX18qgyOFlZxz7sc(u"ࠧࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢࠩ፿")				:A41nqbj3wYt(u"ࠨ็๋ๆ฾ࠦๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧᎀ")
	,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡨࡰ࡮࡬ࡶࡪࡦࡨࡳࠬᎁ")			:iySORMYxWXszEH18(u"้ࠪํู่ࠡล็๎ๆࠦแ๋ัํ์ࠬᎂ")
	,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬᎃ")				:YYQS36fyPvtuzcEmRL(u"๋่ࠬใ฻ࠣๅอืใสࠩᎄ")
	,yobpaW7sBqtKRrv(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᎅ")				:bawK2j7T81Nrc4GWs05xzDg(u"ࠧโึ็ࠫᎆ")
	,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡨࡤ࡮ࡪࡸࡳࡩࡱࡺࠫᎇ")			:yobpaW7sBqtKRrv(u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧᎈ")
	,Z9FPQvwlbjLTh(u"ࠪࡪࡦࡸࡥࡴ࡭ࡲࠫᎉ")				:YYQS36fyPvtuzcEmRL(u"๊ࠫ๎โฺࠢไหึูใ้ࠩᎊ")
	,gPE1XB87fQl(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧᎋ")				:tzZ6PhyDOUnwLM3pdK(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨᎌ")
	,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩᎍ")				:IMjqygdfYSKpHlWu5Aa(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫᎎ")
	,VP70ytiFNMBl6vHDaW(u"ࠩࡩࡳࡱࡪࡥࡳࠩᎏ")				:oiWNFYzcIUeh(u"้ࠪั๊ฯࠨ᎐")
	,A41nqbj3wYt(u"ࠫ࡫ࡵࡳࡵࡣࠪ᎑")				:aiQwFE1TGx04vmLcsYkIW5jA(u"๋่ࠬใ฻ࠣๅํูสศࠩ᎒")
	,beV5l2D8HznyJI0(u"࠭ࡦࡶࡰࡲࡲࡹࡼࠧ᎓")				:Z9FPQvwlbjLTh(u"ࠧๆ๊ๅ฽ࠥ็ๆ้่ࠣฮ๏็๊ࠨ᎔")
	,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡨࡸࡷ࡭ࡧࡲࡵࡸࠪ᎕")				:QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"่ࠩ์็฿ࠠโ๊ืหึࠦส๋ใํࠫ᎖")
	,KLX7hW0nBAEgy6m4SvH(u"ࠪࡪࡺࡹࡨࡢࡴࡹ࡭ࡩ࡫࡯ࠨ᎗")			:XwYZoICi4pSQ0Ousm6JGtcdzVB(u"๊ࠫ๎โฺࠢไ์ูอัࠡใํำ๏๎ࠧ᎘")
	,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࡭࡯ࡰࡦࠪ᎙")					:YYQS36fyPvtuzcEmRL(u"࠭ฬ๋ัࠪ᎚")
	,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ᎛")				:eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ᎜")
	,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩ࡫ࡩࡱࡧ࡬ࠨ᎝")				:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭᎞")
	,GHg28TBchiyn6l(u"ࠫ࡮࡬ࡩ࡭࡯ࠪ᎟")				:I872Vum45fMNe1BRngTZLoQiqvkt(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩᎠ")
	,GHg28TBchiyn6l(u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬᎡ")			:YYQS36fyPvtuzcEmRL(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩᎢ")
	,kdRO82AImh0LFw(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨᎣ")		:eUYX1LQCSJyNZtMsukTBhA4cfj(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧᎤ")
	,KLX7hW0nBAEgy6m4SvH(u"ࠪ࡭ࡵࡺࡶࠨᎥ")					:rVy3Ops0mohYkT(u"ࠫࡎࡖࡔࡗࠩᎦ")
	,oiWNFYzcIUeh(u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨᎧ")			:rVy3Ops0mohYkT(u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪᎨ")
	,VP70ytiFNMBl6vHDaW(u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᎩ")			:kdRO82AImh0LFw(u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬᎪ")
	,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧᎫ")			:bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩᎬ")
	,pp7FcjEe6g(u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧᎭ")			:pp7FcjEe6g(u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨᎮ")
	,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨᎯ")				:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩᎰ")
	,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᎱ")				:Z9FPQvwlbjLTh(u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭Ꮂ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪ࡯࡮ࡸ࡭ࡢ࡮࡮ࠫᎳ")				:CyHU86ZeYT5BWRcitSm2I(u"๊ࠫ๎โฺࠢๆี๊อไไࠩᎴ")
	,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡲࡡࡳࡱࡽࡥࠬᎵ")				:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫᎶ")
	,wwWzyF4ZpSQXKOgk569(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨᎷ")				:A41nqbj3wYt(u"ࠨ็็ๅࠬᎸ")
	,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩ࡯࡭ࡻ࡫ࠧᎹ")					:SI7eBdND4lx8pt5Qk(u"ࠪๆ๋อษࠨᎺ")
	,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫᎻ")				:rVy3Ops0mohYkT(u"๋ࠬไโࠩᎼ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧᎽ")				:ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭Ꮎ")
	,Z9FPQvwlbjLTh(u"ࠨ࡯࠶ࡹࠬᎿ")					:pp7FcjEe6g(u"ࠩࡐ࠷࡚࠭Ꮐ")
	,VP70ytiFNMBl6vHDaW(u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬᏁ")				:QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧᏂ")
	,ZLr5gRSkFewKdUos90bM(u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩᏃ")			:pp7FcjEe6g(u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩᏄ")
	,gPE1XB87fQl(u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫᏅ")			:A6iX18qgyOFlZxz7sc(u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭Ꮖ")
	,wwWzyF4ZpSQXKOgk569(u"ࠩࡰࡥࡸࡧࡶࡪࡦࡨࡳࠬᏇ")			:gPE1XB87fQl(u"้ࠪํู่ࠡ็สืฬࠦแ๋ัํ์ࠬᏈ")
	,A41nqbj3wYt(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᏉ")				:gPE1XB87fQl(u"๋ࠬแใ๊าࠫᏊ")
	,A41nqbj3wYt(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭Ꮛ")				:IMjqygdfYSKpHlWu5Aa(u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩᏌ")
	,YYQS36fyPvtuzcEmRL(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨᏍ")				:IMjqygdfYSKpHlWu5Aa(u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩᏎ")
	,CyHU86ZeYT5BWRcitSm2I(u"ࠪࡳࡱࡪࠧᏏ")					:eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫ็ี๊ๆࠩᏐ")
	,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡶࡡ࡯ࡧࡷࠫᏑ")				:A41nqbj3wYt(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᏒ")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭Ꮣ")			:ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫᏔ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨᏕ")			:A6iX18qgyOFlZxz7sc(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨᏖ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡶ࡬ࡩ࡭࡯ࠪᏗ")				:XwYZoICi4pSQ0Ousm6JGtcdzVB(u"๋่ࠬใ฻ࠣ็๏๎ࠠโ์็้ࠬᏘ")
	,ZLr5gRSkFewKdUos90bM(u"࠭ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧࠪᏙ")			:tzZ6PhyDOUnwLM3pdK(u"ࠧๆ๊ๅ฽ู๊ࠥา์ึࠤฯอ๊ๆࠩᏚ")
	,VP70ytiFNMBl6vHDaW(u"ࠨࡵ࡫ࡥࡧࡧ࡫ࡢࡶࡼࠫᏛ")			:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"่ࠩ์็฿ࠠีสๆฮ๏࠭Ꮬ")
	,A41nqbj3wYt(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬᏝ")				:KLX7hW0nBAEgy6m4SvH(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭Ꮮ")
	,SI7eBdND4lx8pt5Qk(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠲ࠨᏟ")			:wwWzyF4ZpSQXKOgk569(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠡ࠴ࠪᏠ")
	,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫᏡ")			:oiWNFYzcIUeh(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩᏢ")
	,CyHU86ZeYT5BWRcitSm2I(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬᏣ")			:mq5t9JXSdHT8yfDVF(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬᏤ")
	,YYQS36fyPvtuzcEmRL(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧᏥ")		:aiQwFE1TGx04vmLcsYkIW5jA(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭Ꮶ")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩᏧ")		:I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩᏨ")
	,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬᏩ")	:jhDZ0BAFoEGUcw5QrJkaxXL(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩᏪ")
	,wwWzyF4ZpSQXKOgk569(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪᏫ")				:VP70ytiFNMBl6vHDaW(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭Ꮼ")
	,tzZ6PhyDOUnwLM3pdK(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧᏭ")				:I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭Ꮾ")
	,ZLr5gRSkFewKdUos90bM(u"ࠧࡴࡪࡲࡳ࡫ࡴࡥࡵࠩᏯ")				:jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ็๋ๆ฾ࠦิ้ใ๊ࠣฯ࠭Ᏸ")
	,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫᏱ")				:lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩᏲ")
	,bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡹ࡯࡫ࡢࡣࡷࠫᏳ")				:yobpaW7sBqtKRrv(u"๋่ࠬใ฻ࠣฮ่อสࠨᏴ")
	,iySORMYxWXszEH18(u"࠭ࡴࡷࡨࡸࡲࠬᏵ")				:SI7eBdND4lx8pt5Qk(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ᏶")
	,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡸࡤࡶࡧࡵ࡮ࠨ᏷")				:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"่ࠩ์็฿ࠠโษิฬํ์ࠧᏸ")
	,VP70ytiFNMBl6vHDaW(u"ࠪࡺ࡮ࡪࡥࡰࠩᏹ")				:XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫๆ๐ฯ๋๊ࠪᏺ")
	,YYQS36fyPvtuzcEmRL(u"ࠬࡼࡩࡥࡧࡲࡲࡸࡧࡥ࡮ࠩᏻ")			:KLX7hW0nBAEgy6m4SvH(u"࠭ๅ้ไ฼ࠤๆ๐ฯุ๋๊๊ࠣอฦๆࠩᏼ")
	,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠱ࠨᏽ")				:beV5l2D8HznyJI0(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠲ࠩ᏾")
	,A6iX18qgyOFlZxz7sc(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠴ࠪ᏿")				:yobpaW7sBqtKRrv(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠵ࠫ᐀")
	,Z9FPQvwlbjLTh(u"ࠫࡾࡧࡱࡰࡶࠪᐁ")				:aiQwFE1TGx04vmLcsYkIW5jA(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩᐂ")
	,KLX7hW0nBAEgy6m4SvH(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᐃ")				:wwWzyF4ZpSQXKOgk569(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬᐄ")
	,iySORMYxWXszEH18(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᐅ")		:bawK2j7T81Nrc4GWs05xzDg(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭ᐆ")
	,A41nqbj3wYt(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧᐇ")	:CyHU86ZeYT5BWRcitSm2I(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨᐈ")
	,iySORMYxWXszEH18(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ᐉ")		:eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ᐊ")
	,kdRO82AImh0LFw(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐋ")			:ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ็๋ห็฿ࠠๆ่ࠣ๎ํะ๊้สࠪᐌ")
	}
	CDVKWkGP2fOYsIAbX3FerS = HvzeZpTRrx9j1hMBV3.lower()
	for key in list(fXn20PaFubHryqZDxO.keys()):
		dasj7Qw5uRUJ20pO = key.lower()
		if CDVKWkGP2fOYsIAbX3FerS==dasj7Qw5uRUJ20pO:
			HvzeZpTRrx9j1hMBV3 = fXn20PaFubHryqZDxO[key]
			break
	return HvzeZpTRrx9j1hMBV3
def YINetiX57RwjFa4f1JBmS28Hx(N1m5OwDBhMsKktH7X,lLAHgJvCYBfa8O94tXkhZrqUQW=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	A3pXVFdyP1.X0Xk5yAVJPfd = r0D4C3z7Onqpa
	if not lLAHgJvCYBfa8O94tXkhZrqUQW and N1m5OwDBhMsKktH7X: lLAHgJvCYBfa8O94tXkhZrqUQW = wwWzyF4ZpSQXKOgk569(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪᐍ")
	G3yDpvxOiSWdAeL.setSetting(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᐎ"),lLAHgJvCYBfa8O94tXkhZrqUQW)
	return
def ZisgmEGCOJxVI9DcetNBPo6(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,QPkvb71Yzn4=beV5l2D8HznyJI0(u"ࠫ࠿࠵ࠧᐏ")):
	return _ouW8XfBxY2U1OPipEynz5(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,QPkvb71Yzn4)
def qrZfsVW9IAnzJ6SMl0Rea5uiFg7GyB(VCDxBjPsRFtyv42KYo):
	if VCDxBjPsRFtyv42KYo in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,kdRO82AImh0LFw(u"ࠬ࠶ࠧᐐ"),j0jEZgiKdxFpMLHcU7kQr8v1lyX4]: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VCDxBjPsRFtyv42KYo = int(VCDxBjPsRFtyv42KYo)
	xT9DP08ALcQ7JdGloaiW5h2X = VCDxBjPsRFtyv42KYo^oldym5kX8IqLSVDtpNMw
	VVscFnGO6ZzNJPH = VCDxBjPsRFtyv42KYo^nsFAzS2wvjyTYLOdDhfIiC0KGHE
	v15W83SzmyNchroDVqiMBRIZaf79 = VCDxBjPsRFtyv42KYo^OQaHUGCW62hp8tFbgM
	ZPtB6f173cES8pAKomLWX0sHQbn = str(xT9DP08ALcQ7JdGloaiW5h2X)+str(VVscFnGO6ZzNJPH)+str(v15W83SzmyNchroDVqiMBRIZaf79)
	return ZPtB6f173cES8pAKomLWX0sHQbn
def f5RrHOGm6kBg0oCsV(VCDxBjPsRFtyv42KYo):
	if VCDxBjPsRFtyv42KYo in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠭࠰ࠨᐑ"),j0jEZgiKdxFpMLHcU7kQr8v1lyX4]: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VCDxBjPsRFtyv42KYo = str(VCDxBjPsRFtyv42KYo)
	ZPtB6f173cES8pAKomLWX0sHQbn = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if len(VCDxBjPsRFtyv42KYo)==KLX7hW0nBAEgy6m4SvH(u"࠶࠻ᘝ"):
		xT9DP08ALcQ7JdGloaiW5h2X,VVscFnGO6ZzNJPH,v15W83SzmyNchroDVqiMBRIZaf79 = VCDxBjPsRFtyv42KYo[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:yGLl1nSBrJPmi2adko9O],VCDxBjPsRFtyv42KYo[yGLl1nSBrJPmi2adko9O:ZLr5gRSkFewKdUos90bM(u"࠿ᘞ")],VCDxBjPsRFtyv42KYo[ZLr5gRSkFewKdUos90bM(u"࠿ᘞ"):]
		xT9DP08ALcQ7JdGloaiW5h2X = int(xT9DP08ALcQ7JdGloaiW5h2X)^OQaHUGCW62hp8tFbgM
		VVscFnGO6ZzNJPH = int(VVscFnGO6ZzNJPH)^nsFAzS2wvjyTYLOdDhfIiC0KGHE
		v15W83SzmyNchroDVqiMBRIZaf79 = int(v15W83SzmyNchroDVqiMBRIZaf79)^oldym5kX8IqLSVDtpNMw
		if xT9DP08ALcQ7JdGloaiW5h2X==VVscFnGO6ZzNJPH==v15W83SzmyNchroDVqiMBRIZaf79: ZPtB6f173cES8pAKomLWX0sHQbn = str(xT9DP08ALcQ7JdGloaiW5h2X*GHg28TBchiyn6l(u"࠶࠱ᘟ"))
	return ZPtB6f173cES8pAKomLWX0sHQbn
def hhjzYAw9aeTWbu3KDJ5sy(VCDxBjPsRFtyv42KYo,mfTB1cUoaW7=GHg28TBchiyn6l(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᐒ")):
	if VCDxBjPsRFtyv42KYo==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VCDxBjPsRFtyv42KYo = int(VCDxBjPsRFtyv42KYo)+int(mfTB1cUoaW7)
	xT9DP08ALcQ7JdGloaiW5h2X = VCDxBjPsRFtyv42KYo^oldym5kX8IqLSVDtpNMw
	VVscFnGO6ZzNJPH = VCDxBjPsRFtyv42KYo^nsFAzS2wvjyTYLOdDhfIiC0KGHE
	v15W83SzmyNchroDVqiMBRIZaf79 = VCDxBjPsRFtyv42KYo^OQaHUGCW62hp8tFbgM
	ZPtB6f173cES8pAKomLWX0sHQbn = str(xT9DP08ALcQ7JdGloaiW5h2X)+str(VVscFnGO6ZzNJPH)+str(v15W83SzmyNchroDVqiMBRIZaf79)
	return ZPtB6f173cES8pAKomLWX0sHQbn
def bI32vYq51R4aney(VCDxBjPsRFtyv42KYo,mfTB1cUoaW7=KLX7hW0nBAEgy6m4SvH(u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪᐓ")):
	if VCDxBjPsRFtyv42KYo==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VCDxBjPsRFtyv42KYo = str(VCDxBjPsRFtyv42KYo)
	s4sxCGQkfBI3jUm5 = int(len(VCDxBjPsRFtyv42KYo)/vXIdY7TwFKso40gVBq5)
	xT9DP08ALcQ7JdGloaiW5h2X = int(VCDxBjPsRFtyv42KYo[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:s4sxCGQkfBI3jUm5])^oldym5kX8IqLSVDtpNMw
	VVscFnGO6ZzNJPH = int(VCDxBjPsRFtyv42KYo[s4sxCGQkfBI3jUm5:XURrDCfOS9Mbhpv2Pmjos56TeW*s4sxCGQkfBI3jUm5])^nsFAzS2wvjyTYLOdDhfIiC0KGHE
	v15W83SzmyNchroDVqiMBRIZaf79 = int(VCDxBjPsRFtyv42KYo[XURrDCfOS9Mbhpv2Pmjos56TeW*s4sxCGQkfBI3jUm5:vXIdY7TwFKso40gVBq5*s4sxCGQkfBI3jUm5])^OQaHUGCW62hp8tFbgM
	ZPtB6f173cES8pAKomLWX0sHQbn = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if xT9DP08ALcQ7JdGloaiW5h2X==VVscFnGO6ZzNJPH==v15W83SzmyNchroDVqiMBRIZaf79: ZPtB6f173cES8pAKomLWX0sHQbn = str(int(xT9DP08ALcQ7JdGloaiW5h2X)-int(mfTB1cUoaW7))
	return ZPtB6f173cES8pAKomLWX0sHQbn
def DPoKMX74WGfUm9Habip(fMvB4NbYJgO):
	OEUeS8IHM9 = A3pXVFdyP1.SITESURLS[beV5l2D8HznyJI0(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᐔ")][ZLr5gRSkFewKdUos90bM(u"࠹ᘠ")]
	Z86tnVvcXhyBCSfmHJbwYQU1i = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ᐕ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡸࡱࡩ࡯ࡵࠪᐖ"),KLX7hW0nBAEgy6m4SvH(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ᐗ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࠷࠳࠲ࡳࠫᐘ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩᐙ"))
	LdIyT0bxr36tvCzpgYNQEoKGn,oQNRxFO2BPujwI = KIt6Jwe3Qyxp(Z86tnVvcXhyBCSfmHJbwYQU1i)
	LdIyT0bxr36tvCzpgYNQEoKGn = hhjzYAw9aeTWbu3KDJ5sy(LdIyT0bxr36tvCzpgYNQEoKGn,gPE1XB87fQl(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᐚ"))
	xY2gHyupZXFz = {gPE1XB87fQl(u"ࠩ࡬ࡨࡸ࠭ᐛ"):tzZ6PhyDOUnwLM3pdK(u"ࠪࡈࡎࡇࡌࡐࡉࠪᐜ"),gPE1XB87fQl(u"ࠫࡺࡹࡲࠨᐝ"):A3pXVFdyP1.AV_CLIENT_IDS,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡼࡥࡳࠩᐞ"):mbvW9By35UDO,YYQS36fyPvtuzcEmRL(u"࠭ࡳࡤࡴࠪᐟ"):fMvB4NbYJgO,A6iX18qgyOFlZxz7sc(u"ࠧࡴ࡫ࡽࠫᐠ"):LdIyT0bxr36tvCzpgYNQEoKGn}
	llg1pX2dzHFr3mfqK = {QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᐡ"):CyHU86ZeYT5BWRcitSm2I(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᐢ")}
	G3AOoES0VLqUf5Yc = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,Z9FPQvwlbjLTh(u"ࠪࡔࡔ࡙ࡔࠨᐣ"),OEUeS8IHM9,xY2gHyupZXFz,llg1pX2dzHFr3mfqK,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬᐤ"))
	i4qlGM8nCS5O6kbgvwXeo = G3AOoES0VLqUf5Yc.content
	try:
		if not i4qlGM8nCS5O6kbgvwXeo: EnJ8cTSsBOxC5U
		H9qKcRm2kQ3yOTgto = IXZpzK7ShaRsAN(bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡪࡩࡤࡶࠪᐥ"),i4qlGM8nCS5O6kbgvwXeo)
		LvnGocCZl93N1VxFqU8w5BAhrQz0Ep = H9qKcRm2kQ3yOTgto[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡭ࡴࡩࠪᐦ")]
		GtPUyN29IOsX = H9qKcRm2kQ3yOTgto[A6iX18qgyOFlZxz7sc(u"ࠧࡴࡧࡦࠫᐧ")]
		u9vNnSJWY7l5RQaqg = H9qKcRm2kQ3yOTgto[VP70ytiFNMBl6vHDaW(u"ࠨࡵࡷࡴࠬᐨ")]
		GtPUyN29IOsX = int(bI32vYq51R4aney(GtPUyN29IOsX,wwWzyF4ZpSQXKOgk569(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᐩ")))
		u9vNnSJWY7l5RQaqg = int(bI32vYq51R4aney(u9vNnSJWY7l5RQaqg,IMjqygdfYSKpHlWu5Aa(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᐪ")))
		for aVudiQBpO5MNwkx7S2h8W9C4JR in range(GtPUyN29IOsX,j0jEZgiKdxFpMLHcU7kQr8v1lyX4,-u9vNnSJWY7l5RQaqg):
			if not eval(rVy3Ops0mohYkT(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩᐫ"),{KLX7hW0nBAEgy6m4SvH(u"ࠬࡾࡢ࡮ࡥࠪᐬ"):pYDdXfVh5c0O1bMT6a78HKBiQw3}): EnJ8cTSsBOxC5U
			uTaiRMI8eYmN(KLX7hW0nBAEgy6m4SvH(u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬᐭ"),str(aVudiQBpO5MNwkx7S2h8W9C4JR)+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࠡࠢฮห๋๐ษࠨᐮ"),x54xSdnCFHZ8yliofzOBK=QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠳࠴ᘡ")*u9vNnSJWY7l5RQaqg)
			pYDdXfVh5c0O1bMT6a78HKBiQw3.sleep(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠴࠴࠵࠶ᘢ")*u9vNnSJWY7l5RQaqg)
		if eval(gPE1XB87fQl(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ᐯ"),{yobpaW7sBqtKRrv(u"ࠩࡻࡦࡲࡩࠧᐰ"):pYDdXfVh5c0O1bMT6a78HKBiQw3}):
			LvnGocCZl93N1VxFqU8w5BAhrQz0Ep = LvnGocCZl93N1VxFqU8w5BAhrQz0Ep.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,A6iX18qgyOFlZxz7sc(u"ࠪࡠࡡࡴࠧᐱ")).replace(TTLxlKI0gNfh7FP,gPE1XB87fQl(u"ࠫࡡࡢࡲࠨᐲ"))
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬิั้ฮࠪᐳ"),Ew26Hg4SIj,LvnGocCZl93N1VxFqU8w5BAhrQz0Ep)
		EnJ8cTSsBOxC5U
	except: exec(SI7eBdND4lx8pt5Qk(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᐴ"),{mq5t9JXSdHT8yfDVF(u"ࠧࡹࡤࡰࡧࠬᐵ"):pYDdXfVh5c0O1bMT6a78HKBiQw3})
	return
def m5Di042yedpcblT():
	exec(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᐶ"),{KLX7hW0nBAEgy6m4SvH(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᐷ"):Zilvh2WQyb5,iySORMYxWXszEH18(u"ࠪࡼࡧࡳࡣࠨᐸ"):pYDdXfVh5c0O1bMT6a78HKBiQw3})
	return
def KIt6Jwe3Qyxp(a3aJE1T7OlBQDXCIi5SRYvo):
	iXupeEwgFWDzaIxnUlfPhs43RbM6N7,tJqAIFkchTU = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(a3aJE1T7OlBQDXCIi5SRYvo):
		try: iXupeEwgFWDzaIxnUlfPhs43RbM6N7 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.getsize(a3aJE1T7OlBQDXCIi5SRYvo)
		except: pass
		if not iXupeEwgFWDzaIxnUlfPhs43RbM6N7:
			try: iXupeEwgFWDzaIxnUlfPhs43RbM6N7 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.stat(a3aJE1T7OlBQDXCIi5SRYvo).st_size
			except: pass
		if not iXupeEwgFWDzaIxnUlfPhs43RbM6N7:
			try:
				from pathlib import Path as FZgC8GeSYM2hKEdHf3W
				iXupeEwgFWDzaIxnUlfPhs43RbM6N7 = FZgC8GeSYM2hKEdHf3W(a3aJE1T7OlBQDXCIi5SRYvo).stat().st_size
			except: pass
		if iXupeEwgFWDzaIxnUlfPhs43RbM6N7: tJqAIFkchTU = wnaWTQM7VJPkZzO9eoSyFU4
	return iXupeEwgFWDzaIxnUlfPhs43RbM6N7,tJqAIFkchTU
def xwEQAOSry1FPR3itoU7BIg(BD2KrWS94j1iOMGx5YvL6dtHVAXgpw,showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,BD2KrWS94j1iOMGx5YvL6dtHVAXgpw+bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡡࡴ࡜࡯ࠩᐹ")+e6HEdvUcaq8Gx+SI7eBdND4lx8pt5Qk(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩᐺ")+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=I872Vum45fMNe1BRngTZLoQiqvkt(u"࠵ᘣ"): return KiryBCvngZzF85UN6xSDlOVweL4I9
	succeeded = r0D4C3z7Onqpa
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(BD2KrWS94j1iOMGx5YvL6dtHVAXgpw):
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(BD2KrWS94j1iOMGx5YvL6dtHVAXgpw.decode(e87cIA5vwOQLDEP1))
		except:
			try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(xQTzcX6RoI18wfFVOprWEUgah2b)
			except Exception as YIrltJES6aPjnm94qTuoMiORKpDA0:
				succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
				if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,str(YIrltJES6aPjnm94qTuoMiORKpDA0))
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"࠭แีๆอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭ᐻ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,tzZ6PhyDOUnwLM3pdK(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᐼ"))
	return succeeded
def r670fZQYnxlNOUoVBbMJa(FRsZ14BTQru0Y,LWr3BijTbFYAgGkMUXCepE,showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,FRsZ14BTQru0Y+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࡞ࡱࡠࡳ࠭ᐽ")+e6HEdvUcaq8Gx+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧᐾ")+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return KiryBCvngZzF85UN6xSDlOVweL4I9
	succeeded = r0D4C3z7Onqpa
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(FRsZ14BTQru0Y):
		for RXqfStFVAlw6NK5a,XjDd8TogszB4verEZaVPyRY,a3kGPwFH65BCEhS in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.walk(FRsZ14BTQru0Y,topdown=KiryBCvngZzF85UN6xSDlOVweL4I9):
			for a3aJE1T7OlBQDXCIi5SRYvo in a3kGPwFH65BCEhS:
				CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(RXqfStFVAlw6NK5a,a3aJE1T7OlBQDXCIi5SRYvo)
				try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd)
				except Exception as YIrltJES6aPjnm94qTuoMiORKpDA0:
					succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
					if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,str(YIrltJES6aPjnm94qTuoMiORKpDA0))
			if LWr3BijTbFYAgGkMUXCepE:
				for dir in XjDd8TogszB4verEZaVPyRY:
					u9hxkFNBLfV2l = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(RXqfStFVAlw6NK5a,dir)
					try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.rmdir(u9hxkFNBLfV2l)
					except: pass
		if LWr3BijTbFYAgGkMUXCepE:
			try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.rmdir(RXqfStFVAlw6NK5a)
			except: pass
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,VP70ytiFNMBl6vHDaW(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᐿ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,VP70ytiFNMBl6vHDaW(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭ᑀ"))
	return succeeded
def x8FpPjoVmB5O(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy):
	vcQbFfCk6T1,j9jmDsfvq51,FzwtaeUBAmWNYT8P1KL7,aKjiD1o926NyV = CCeIOiGo7sNfQJTjSrnaYlw(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	o6r9VHUax2FMSKLRfCATb5k0n = g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ
	if XgfsEHex8hCzQY7vFNTBrW<I872Vum45fMNe1BRngTZLoQiqvkt(u"࠵ᘤ"):
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᑁ"),o6r9VHUax2FMSKLRfCATb5k0n)
		XgfsEHex8hCzQY7vFNTBrW = -XgfsEHex8hCzQY7vFNTBrW
	if XgfsEHex8hCzQY7vFNTBrW>CyHU86ZeYT5BWRcitSm2I(u"࠶ᘥ"):
		VbRFshPMjr2t3k = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,KLX7hW0nBAEgy6m4SvH(u"࠭ࡳࡵࡴࠪᑂ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᑃ"),o6r9VHUax2FMSKLRfCATb5k0n)
		if VbRFshPMjr2t3k:
			N0CQrbltd91Ywj7Zm5xJz43suchF(bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭ᑄ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy,g0Sft2VkTxGD1pYobnsX76E)
			return VbRFshPMjr2t3k
	VbRFshPMjr2t3k = lCyIgTpZ8WJHdk9iPBLUD(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy)
	if VbRFshPMjr2t3k and XgfsEHex8hCzQY7vFNTBrW: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,pp7FcjEe6g(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᑅ"),o6r9VHUax2FMSKLRfCATb5k0n,VbRFshPMjr2t3k,XgfsEHex8hCzQY7vFNTBrW)
	return VbRFshPMjr2t3k
def YulwBtae3fh8DT0X64zd7(NTWE764hmOgUtScp2e8r,KC0S9Xk2nGzqTPOau43I5mwYs,H9HkNEMovDVhly=j0jEZgiKdxFpMLHcU7kQr8v1lyX4):
	I1HbuKlOr7cf2sMp0iJF8WSv = G3yDpvxOiSWdAeL.getSetting(IMjqygdfYSKpHlWu5Aa(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧᑆ"))
	if I1HbuKlOr7cf2sMp0iJF8WSv and aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࠲࠭ᑇ") not in I1HbuKlOr7cf2sMp0iJF8WSv: IISWAzUg18xVsPiNykMh2ce4JXEKZY,tVlvj3d9PfeiK21kJZNWhRXY8Ia = int(I1HbuKlOr7cf2sMp0iJF8WSv),r0D4C3z7Onqpa
	elif H9HkNEMovDVhly: IISWAzUg18xVsPiNykMh2ce4JXEKZY,tVlvj3d9PfeiK21kJZNWhRXY8Ia = H9HkNEMovDVhly,KiryBCvngZzF85UN6xSDlOVweL4I9
	else: return []
	FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1,pLTm0tuPAk3HMraI = [],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	Y1Frq9XTygwB7dA,dpmi0hO6aFeKkb1952,dd3j60oSCV,MpCrcJXIwVidk = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	KC0S9Xk2nGzqTPOau43I5mwYs = sorted(KC0S9Xk2nGzqTPOau43I5mwYs,reverse=r0D4C3z7Onqpa,key=lambda key: (key[wnaWTQM7VJPkZzO9eoSyFU4],key[XURrDCfOS9Mbhpv2Pmjos56TeW]))
	for stream,coNvfp4VIAlyBUK6DziPs0Swu,ufQ5elFnNp in KC0S9Xk2nGzqTPOau43I5mwYs+[[WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]:
		if coNvfp4VIAlyBUK6DziPs0Swu==pLTm0tuPAk3HMraI:
			if ufQ5elFnNp>IISWAzUg18xVsPiNykMh2ce4JXEKZY: dpmi0hO6aFeKkb1952,MpCrcJXIwVidk = stream,ufQ5elFnNp
			elif not Y1Frq9XTygwB7dA: Y1Frq9XTygwB7dA,dd3j60oSCV = stream,ufQ5elFnNp
		else:
			if dpmi0hO6aFeKkb1952 or Y1Frq9XTygwB7dA:
				if Y1Frq9XTygwB7dA: FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1.append([Y1Frq9XTygwB7dA,pLTm0tuPAk3HMraI,dd3j60oSCV])
				elif dpmi0hO6aFeKkb1952: FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1.append([dpmi0hO6aFeKkb1952,pLTm0tuPAk3HMraI,MpCrcJXIwVidk])
			if ufQ5elFnNp>IISWAzUg18xVsPiNykMh2ce4JXEKZY:
				dpmi0hO6aFeKkb1952,MpCrcJXIwVidk = stream,ufQ5elFnNp
				Y1Frq9XTygwB7dA,dd3j60oSCV = WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
			else:
				dpmi0hO6aFeKkb1952,MpCrcJXIwVidk = WnNGfosHr5STAq8j7miwyRZ6eOUbV,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
				Y1Frq9XTygwB7dA,dd3j60oSCV = stream,ufQ5elFnNp
		pLTm0tuPAk3HMraI = coNvfp4VIAlyBUK6DziPs0Swu
	if tVlvj3d9PfeiK21kJZNWhRXY8Ia:
		HFl2IcRSfr3zwu97mNdZTM60DyiAb,TwfIJAF4XnVtL,ggJaYXQhbI5 = zip(*FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1)
		ffZ5BhSc0J = [beV5l2D8HznyJI0(u"ࠬࡳࡰ࠵ࠩᑈ"),IMjqygdfYSKpHlWu5Aa(u"࠭࡭ࡱࡦࠪᑉ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡵࡵࠪᑊ"),gPE1XB87fQl(u"ࠨ࡯࠶ࡹࠬᑋ")]
		for coNvfp4VIAlyBUK6DziPs0Swu in ffZ5BhSc0J:
			if coNvfp4VIAlyBUK6DziPs0Swu in TwfIJAF4XnVtL:
				index = TwfIJAF4XnVtL.index(coNvfp4VIAlyBUK6DziPs0Swu)
				FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1 = [[HFl2IcRSfr3zwu97mNdZTM60DyiAb[index],TwfIJAF4XnVtL[index],ggJaYXQhbI5[index]]]
				break
	return FzPV3WQmTBX6k9bYUG2HDh4KlZ57M1
def JFQSI5HUeNn7TOCsdzwPbpMrlx6Riu(GoYAvNrxwJMTy):
	VJsfON9jQRL4uXD8z2tw3TKyZY,qe6JTSdxVfXF59mzEUMpcC3lgju = [],OHohTgj06taKzsG
	for OOG1iPYhTKQ4 in bcuvN3jdY2gWDy09HAnf:
		if OOG1iPYhTKQ4==kdRO82AImh0LFw(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪᑌ"): qe6JTSdxVfXF59mzEUMpcC3lgju = (I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡰ࡮ࡴ࡫ࠨᑍ"),e6HEdvUcaq8Gx+GHg28TBchiyn6l(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫᑎ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"࠱࠶࠹ᘦ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		elif OOG1iPYhTKQ4==GHg28TBchiyn6l(u"ࠬࡓࡉ࡙ࡇࡇࠫᑏ"): qe6JTSdxVfXF59mzEUMpcC3lgju = (SI7eBdND4lx8pt5Qk(u"࠭࡬ࡪࡰ࡮ࠫᑐ"),e6HEdvUcaq8Gx+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭ᑑ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"࠲࠷࠺ᘧ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		elif OOG1iPYhTKQ4==beV5l2D8HznyJI0(u"ࠨࡒࡘࡆࡑࡏࡃࠨᑒ"): qe6JTSdxVfXF59mzEUMpcC3lgju = (iySORMYxWXszEH18(u"ࠩ࡯࡭ࡳࡱࠧᑓ"),e6HEdvUcaq8Gx+oiWNFYzcIUeh(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪᑔ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"࠳࠸࠻ᘨ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if OOG1iPYhTKQ4 not in GoYAvNrxwJMTy: continue
		if qe6JTSdxVfXF59mzEUMpcC3lgju:
			VJsfON9jQRL4uXD8z2tw3TKyZY.append(qe6JTSdxVfXF59mzEUMpcC3lgju)
			qe6JTSdxVfXF59mzEUMpcC3lgju = OHohTgj06taKzsG
		if OOG1iPYhTKQ4 not in [iySORMYxWXszEH18(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᑕ"),wwWzyF4ZpSQXKOgk569(u"ࠬࡓࡉ࡙ࡇࡇࠫᑖ"),ZLr5gRSkFewKdUos90bM(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ᑗ")]: VJsfON9jQRL4uXD8z2tw3TKyZY.append(OOG1iPYhTKQ4)
	return VJsfON9jQRL4uXD8z2tw3TKyZY
def FfS4xlcw3aP8KqA(jmqi0QyHdYcVxJzuhUeOIZ83Nvsb,args=[]):
	llg1pX2dzHFr3mfqK = {wwWzyF4ZpSQXKOgk569(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᑘ"):wwWzyF4ZpSQXKOgk569(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᑙ")}
	FzElOeTSsDktCwJhPXBxrvuyf,IB9jo5rEiW,AUImbdqjetZH = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨᑚ"),iySORMYxWXszEH18(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩᑛ"),int(x54xSdnCFHZ8yliofzOBK.time())
	pZw1AWroIaQUMYmLOdveF4KVjlbcP = FzElOeTSsDktCwJhPXBxrvuyf+WW3PiLNaxCY+str(AUImbdqjetZH)+mbvW9By35UDO+IB9jo5rEiW
	oybVOQu7xUdwLzChmfnIYKvN = xxiJ2wLnUdPYeGXNz18ECc.md5(pZw1AWroIaQUMYmLOdveF4KVjlbcP.encode(GHg28TBchiyn6l(u"ࠫࡺࡺࡦ࠹ࠩᑜ"))).hexdigest()[:A41nqbj3wYt(u"࠶࠶ᘩ")]
	xY2gHyupZXFz = {aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡰࡳࡤࡱࡧࡩࠬᑝ"):jmqi0QyHdYcVxJzuhUeOIZ83Nvsb,gPE1XB87fQl(u"࠭ࡡࡳࡩࡶࠫᑞ"):args,SI7eBdND4lx8pt5Qk(u"ࠧࡶࡵࡨࡶࠬᑟ"):WW3PiLNaxCY,mq5t9JXSdHT8yfDVF(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᑠ"):mbvW9By35UDO,ZLr5gRSkFewKdUos90bM(u"ࠩ࡬ࡨࡸ࠭ᑡ"):oybVOQu7xUdwLzChmfnIYKvN}
	YljgSpe8Rz = A3pXVFdyP1.SITESURLS[ZLr5gRSkFewKdUos90bM(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᑢ")][wwWzyF4ZpSQXKOgk569(u"࠵࠵ᘪ")]
	G3AOoES0VLqUf5Yc = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡕࡕࡓࡕࠩᑣ"),YljgSpe8Rz,xY2gHyupZXFz,llg1pX2dzHFr3mfqK,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rVy3Ops0mohYkT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧᑤ"))
	i4qlGM8nCS5O6kbgvwXeo = G3AOoES0VLqUf5Yc.content
	return i4qlGM8nCS5O6kbgvwXeo
def vGFdXD2x8ORu6aj(HHbv8GkQ0f,timeout,ZIOysmGvauUTg,bbWmDsuo4qjtKUJz8NFYfBra7MdCO,fp1x6nvVlEXw4PM0WGhuyZi2cTUmQL):
	jadvuk0wqQexTp = KiryBCvngZzF85UN6xSDlOVweL4I9
	for TnuymF81hCYHrNwRIEVWJAzDcf in HHbv8GkQ0f:
		TnuymF81hCYHrNwRIEVWJAzDcf.start()
		x54xSdnCFHZ8yliofzOBK.sleep(ZIOysmGvauUTg)
		jadvuk0wqQexTp = fp1x6nvVlEXw4PM0WGhuyZi2cTUmQL()
		if jadvuk0wqQexTp: break
	else:
		zcShJ97NgaZbXpFVL6MvHQr = int(timeout-len(HHbv8GkQ0f)*ZIOysmGvauUTg)
		if zcShJ97NgaZbXpFVL6MvHQr>j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			for PN2AmVoTyks5xOR1Ib9BqSQ in range(zcShJ97NgaZbXpFVL6MvHQr//bbWmDsuo4qjtKUJz8NFYfBra7MdCO):
				x54xSdnCFHZ8yliofzOBK.sleep(bbWmDsuo4qjtKUJz8NFYfBra7MdCO)
				jadvuk0wqQexTp = fp1x6nvVlEXw4PM0WGhuyZi2cTUmQL()
				if jadvuk0wqQexTp: break
	for TnuymF81hCYHrNwRIEVWJAzDcf in HHbv8GkQ0f:
		try: TnuymF81hCYHrNwRIEVWJAzDcf.join(ZIOysmGvauUTg)
		except: pass
	return jadvuk0wqQexTp
def YvUPLVEzOe3g7tw8C4amxKSGrM(rs7W1cvT2Md9Nh=eb8JPNOXL5oUCm3T):
	MKr38ykChiGzaARNxl9gLXjTuEQbt = oiWNFYzcIUeh(u"࠶࠶࠲࠵ᘫ")
	SpmqaKHnkEWGwFYe4V = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	if not SpmqaKHnkEWGwFYe4V:
		try:
			import shutil as SS4ULnkaQ2rpv9Pq0hxojGKVW3Y1
			SpmqaKHnkEWGwFYe4V = SS4ULnkaQ2rpv9Pq0hxojGKVW3Y1.disk_usage(rs7W1cvT2Md9Nh).free
		except: pass
	if not SpmqaKHnkEWGwFYe4V and hasattr(pNk4HfLdMBRYEQAzjyT0qaoe8cDPt,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡳࡵࡣࡷࡺ࡫ࡹࠧᑥ")):
		try:
			b7dafNGDIY3ZkKQS190mjuUO = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.statvfs(rs7W1cvT2Md9Nh)
			SpmqaKHnkEWGwFYe4V = b7dafNGDIY3ZkKQS190mjuUO.f_frsize * b7dafNGDIY3ZkKQS190mjuUO.f_bavail
		except: pass
	if not SpmqaKHnkEWGwFYe4V and hasattr(pNk4HfLdMBRYEQAzjyT0qaoe8cDPt,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡧࡵࡷࡥࡹࡼࡦࡴࠩᑦ")):
		try:
			b7dafNGDIY3ZkKQS190mjuUO = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.fstatvfs(rs7W1cvT2Md9Nh)
			SpmqaKHnkEWGwFYe4V = b7dafNGDIY3ZkKQS190mjuUO.f_frsize * b7dafNGDIY3ZkKQS190mjuUO.f_bavail
		except: pass
	if not SpmqaKHnkEWGwFYe4V and SZ0YL6RpbX.platform == mq5t9JXSdHT8yfDVF(u"ࠨࡹ࡬ࡲ࠸࠸ࠧᑧ"):
		try:
			import ctypes as aEQJFR46dZvX7O8xBiTC
			opzrO2AjbT = aEQJFR46dZvX7O8xBiTC.c_ulonglong(j0jEZgiKdxFpMLHcU7kQr8v1lyX4)
			aEQJFR46dZvX7O8xBiTC.windll.kernel32.GetDiskFreeSpaceExW(aEQJFR46dZvX7O8xBiTC.c_wchar_p(rs7W1cvT2Md9Nh),None,None,aEQJFR46dZvX7O8xBiTC.pointer(opzrO2AjbT))
			SpmqaKHnkEWGwFYe4V = opzrO2AjbT.value
		except: pass
	if not SpmqaKHnkEWGwFYe4V:
		try:
			yu0UKMwnEpSBIHro3bc = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(KLX7hW0nBAEgy6m4SvH(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬᑨ"))
			hAZileB5czmfUL4IHbXpsDjEJ = p7dwlH1PRStBgyMUW.findall(SI7eBdND4lx8pt5Qk(u"ࠪࡠࡩ࠱ࠨࡀ࠼࡟࠲ࡡࡪࠫࠪࡁࠪᑩ"),yu0UKMwnEpSBIHro3bc,p7dwlH1PRStBgyMUW.DOTALL)
			if hAZileB5czmfUL4IHbXpsDjEJ:
				hAZileB5czmfUL4IHbXpsDjEJ = float(hAZileB5czmfUL4IHbXpsDjEJ[rVy3Ops0mohYkT(u"࠶ᘬ")])
				if   VP70ytiFNMBl6vHDaW(u"࡙ࠫ࠭ᑪ") in yu0UKMwnEpSBIHro3bc: SpmqaKHnkEWGwFYe4V = hAZileB5czmfUL4IHbXpsDjEJ*MKr38ykChiGzaARNxl9gLXjTuEQbt**yGLl1nSBrJPmi2adko9O
				elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡍࠧᑫ") in yu0UKMwnEpSBIHro3bc: SpmqaKHnkEWGwFYe4V = hAZileB5czmfUL4IHbXpsDjEJ*MKr38ykChiGzaARNxl9gLXjTuEQbt**vXIdY7TwFKso40gVBq5
				elif iySORMYxWXszEH18(u"࠭ࡍࠨᑬ") in yu0UKMwnEpSBIHro3bc: SpmqaKHnkEWGwFYe4V = hAZileB5czmfUL4IHbXpsDjEJ*MKr38ykChiGzaARNxl9gLXjTuEQbt**XURrDCfOS9Mbhpv2Pmjos56TeW
				elif kdRO82AImh0LFw(u"ࠧࡌࠩᑭ") in yu0UKMwnEpSBIHro3bc: SpmqaKHnkEWGwFYe4V = hAZileB5czmfUL4IHbXpsDjEJ*MKr38ykChiGzaARNxl9gLXjTuEQbt
				else: SpmqaKHnkEWGwFYe4V = hAZileB5czmfUL4IHbXpsDjEJ
		except: pass
	if not SpmqaKHnkEWGwFYe4V: SpmqaKHnkEWGwFYe4V = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ᘭ")
	return int(SpmqaKHnkEWGwFYe4V)
def y6AXTN1MJgrtC2uIvfhZVRYzx9aB8(lgB7TOZqEJiMUFedrSHX8j6):
	if lgB7TOZqEJiMUFedrSHX8j6:
		stp5hnf3JmRCibOHQq7EMLdNjSlgWZ = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,pp7FcjEe6g(u"ࠨ࡮࡬ࡷࡹ࠭ᑮ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᑯ"),gPE1XB87fQl(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨᑰ"))
		if stp5hnf3JmRCibOHQq7EMLdNjSlgWZ: return stp5hnf3JmRCibOHQq7EMLdNjSlgWZ
	rLqYZOtwMfBVs4k1TpE3X9aDy = {beV5l2D8HznyJI0(u"ࠫࡦ࠭ᑱ"):KLX7hW0nBAEgy6m4SvH(u"ࠬࡧࠧᑲ")}
	url = A3pXVFdyP1.SITESURLS[iySORMYxWXszEH18(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᑳ")][wnaWTQM7VJPkZzO9eoSyFU4]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,oiWNFYzcIUeh(u"ࠧࡑࡑࡖࡘࠬᑴ"),url,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡋࡊ࡚࡟ࡔࡋࡗࡉࡘࡥࡕࡔࡃࡊࡉ࠲࠷ࡳࡵࠩᑵ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	piN9Qlah4S = piN9Qlah4S.replace(gPE1XB87fQl(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩᑶ"),A6iX18qgyOFlZxz7sc(u"࡙ࠪࡘࡇࠧᑷ"))
	piN9Qlah4S = piN9Qlah4S.replace(YYQS36fyPvtuzcEmRL(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬᑸ"),wwWzyF4ZpSQXKOgk569(u"࡛ࠬࡋࠨᑹ"))
	piN9Qlah4S = piN9Qlah4S.replace(Z9FPQvwlbjLTh(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ᑺ"),IMjqygdfYSKpHlWu5Aa(u"ࠧࡖࡃࡈࠫᑻ"))
	piN9Qlah4S = piN9Qlah4S.replace(bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧᑼ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡎࡗࡆ࠭ᑽ"))
	piN9Qlah4S = piN9Qlah4S.replace(iySORMYxWXszEH18(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᑾ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩᑿ"))
	piN9Qlah4S = piN9Qlah4S.replace(GHg28TBchiyn6l(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ᒀ"),VP70ytiFNMBl6vHDaW(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨᒁ"))
	piN9Qlah4S = piN9Qlah4S.replace(IMjqygdfYSKpHlWu5Aa(u"ࠧࡠࡡࡢࠫᒂ"),tTChquY7XSRg4e)
	try: UtwMYW1fopIvj0azdhAHBnS = IXZpzK7ShaRsAN(wwWzyF4ZpSQXKOgk569(u"ࠨ࡮࡬ࡷࡹ࠭ᒃ"),piN9Qlah4S)
	except:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,iySORMYxWXszEH18(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩᒄ"))
		return
	F7FDaijrlLQfJxhkmAW6wMVnu,YHajiT4VltmZ,O6hMZxndC1gWak3Re = UtwMYW1fopIvj0azdhAHBnS
	uulwtzsxYainPV,ZfD2H8PQO4vbFS = [],[]
	for OOG1iPYhTKQ4,Rrx6YsvjFQ2y,ipa9lmsneRCLZAXJyNO in YHajiT4VltmZ:
		if Rrx6YsvjFQ2y.isdigit(): Rrx6YsvjFQ2y = GHg28TBchiyn6l(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ᒅ") if int(Rrx6YsvjFQ2y)>ZLr5gRSkFewKdUos90bM(u"࠶࠲ᘮ") else aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭ᒆ")
		if OOG1iPYhTKQ4 not in A3pXVFdyP1.non_videos_actions:
			if   Rrx6YsvjFQ2y==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᒇ"): uulwtzsxYainPV.append(OOG1iPYhTKQ4)
			elif Rrx6YsvjFQ2y==bawK2j7T81Nrc4GWs05xzDg(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᒈ"): ZfD2H8PQO4vbFS.append(OOG1iPYhTKQ4)
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,tzZ6PhyDOUnwLM3pdK(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᒉ"),gPE1XB87fQl(u"ࠨࡕࡌࡘࡊ࡙࡟ࡖࡕࡄࡋࡊ࠭ᒊ"),[UtwMYW1fopIvj0azdhAHBnS,uulwtzsxYainPV,ZfD2H8PQO4vbFS],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
	return UtwMYW1fopIvj0azdhAHBnS,uulwtzsxYainPV,ZfD2H8PQO4vbFS
def o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XgfsEHex8hCzQY7vFNTBrW,g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI=WnNGfosHr5STAq8j7miwyRZ6eOUbV,FX7dKayU9G1mTv=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࠽࠾ࠬᒋ") in g0Sft2VkTxGD1pYobnsX76E: g0Sft2VkTxGD1pYobnsX76E,G3Xh0YWACHFuvQLx5sVEfPjzq7 = g0Sft2VkTxGD1pYobnsX76E.split(CyHU86ZeYT5BWRcitSm2I(u"ࠪ࠾࠿࠭ᒌ"))
	else: g0Sft2VkTxGD1pYobnsX76E,G3Xh0YWACHFuvQLx5sVEfPjzq7 = g0Sft2VkTxGD1pYobnsX76E,mq5t9JXSdHT8yfDVF(u"ࠫࠬᒍ")
	vcQbFfCk6T1,j9jmDsfvq51,FzwtaeUBAmWNYT8P1KL7,aKjiD1o926NyV = CCeIOiGo7sNfQJTjSrnaYlw(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	fikvMX4NcHLj = OLAqp2vxUf5rw79zdgQR1ZboEJ.copy() if isinstance(OLAqp2vxUf5rw79zdgQR1ZboEJ,dict) else OLAqp2vxUf5rw79zdgQR1ZboEJ
	o6r9VHUax2FMSKLRfCATb5k0n = g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,N4HDrYcWePfI0yxjb2,fikvMX4NcHLj,whtj1keM3OcTmuB9X
	if XgfsEHex8hCzQY7vFNTBrW<j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,oiWNFYzcIUeh(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᒎ"),o6r9VHUax2FMSKLRfCATb5k0n)
		XgfsEHex8hCzQY7vFNTBrW = -XgfsEHex8hCzQY7vFNTBrW
	if XgfsEHex8hCzQY7vFNTBrW>j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
		u4vhNT8C0k1tmrxX9F5gGWo7Z = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᒏ"),ZLr5gRSkFewKdUos90bM(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᒐ"),o6r9VHUax2FMSKLRfCATb5k0n)
		if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
			N0CQrbltd91Ywj7Zm5xJz43suchF(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᒑ"),vcQbFfCk6T1,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy,g0Sft2VkTxGD1pYobnsX76E)
			return u4vhNT8C0k1tmrxX9F5gGWo7Z
	if G3Xh0YWACHFuvQLx5sVEfPjzq7==mq5t9JXSdHT8yfDVF(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࠫᒒ"): u4vhNT8C0k1tmrxX9F5gGWo7Z = iaE3YPpKG4mtB7M5zXNRCd16TI8e0A(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy)
	else: u4vhNT8C0k1tmrxX9F5gGWo7Z = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI,FX7dKayU9G1mTv)
	if u4vhNT8C0k1tmrxX9F5gGWo7Z.succeeded:
		if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᒓ") in ADN3XhW9ZpVmFK84j2roiy: u4vhNT8C0k1tmrxX9F5gGWo7Z.content = FXeb4fwkiRO9v63yNQ5du(u4vhNT8C0k1tmrxX9F5gGWo7Z.content,pp7FcjEe6g(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࡤࡎࡔࡎࡎࡢࡩࡳࡩ࡯ࡥࡧࡵࠫᒔ"))
		if u4vhNT8C0k1tmrxX9F5gGWo7Z.scrape: XgfsEHex8hCzQY7vFNTBrW = oldym5kX8IqLSVDtpNMw
		if XgfsEHex8hCzQY7vFNTBrW and u4vhNT8C0k1tmrxX9F5gGWo7Z.content: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᒕ"),o6r9VHUax2FMSKLRfCATb5k0n,u4vhNT8C0k1tmrxX9F5gGWo7Z,XgfsEHex8hCzQY7vFNTBrW)
	return u4vhNT8C0k1tmrxX9F5gGWo7Z
def EEYpJtRZncrFePa3Qi0DlSuWo(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,data,headers,allow_redirects,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI,FX7dKayU9G1mTv):
	if data==WnNGfosHr5STAq8j7miwyRZ6eOUbV: data = {}
	if headers==WnNGfosHr5STAq8j7miwyRZ6eOUbV: headers = {}
	Xfeq2u54AGcLMKRpjZ7J = r0D4C3z7Onqpa if allow_redirects in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa] else KiryBCvngZzF85UN6xSDlOVweL4I9
	DgUZXnsQIbAYhoyacOvuFWSGp = r0D4C3z7Onqpa if showDialogs in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa] else KiryBCvngZzF85UN6xSDlOVweL4I9
	iLwsXm6HN3VYGRFxUCPKWqc = r0D4C3z7Onqpa if YzmKQPA7nEad15R2BGsT6N8qWCuiI in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa] else KiryBCvngZzF85UN6xSDlOVweL4I9
	fAbWextglFNyRZv4JiLrM3dp = r0D4C3z7Onqpa if FX7dKayU9G1mTv in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa] else KiryBCvngZzF85UN6xSDlOVweL4I9
	bZ0VWjAHm1v2Csroh = data
	W67hPCcaOek094 = headers
	DgUZXnsQIbAYhoyacOvuFWSGp = DgUZXnsQIbAYhoyacOvuFWSGp if A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX==OHohTgj06taKzsG else A3pXVFdyP1.ALLOW_SHOWDIALOGS_FIX
	iLwsXm6HN3VYGRFxUCPKWqc = iLwsXm6HN3VYGRFxUCPKWqc if A3pXVFdyP1.ALLOW_DNS_FIX==OHohTgj06taKzsG else A3pXVFdyP1.ALLOW_DNS_FIX
	fAbWextglFNyRZv4JiLrM3dp = fAbWextglFNyRZv4JiLrM3dp if A3pXVFdyP1.ALLOW_PROXY_FIX==OHohTgj06taKzsG else A3pXVFdyP1.ALLOW_PROXY_FIX
	if ADN3XhW9ZpVmFK84j2roiy==pp7FcjEe6g(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡋࡑࡗ࡙ࡇࡌࡍࡡࡒࡐࡉࡥࡒࡆࡎࡈࡅࡘࡋ࠭࠲ࡵࡷࠫᒖ"): W67hPCcaOek094 = {}
	else:
		BBS4olVgwTAex7fKFaObDWtmUp9Is = list(W67hPCcaOek094.keys())
		if kdRO82AImh0LFw(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᒗ") not in BBS4olVgwTAex7fKFaObDWtmUp9Is: W67hPCcaOek094[IMjqygdfYSKpHlWu5Aa(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᒘ")] = IMjqygdfYSKpHlWu5Aa(u"ࠩ࡫ࡸࡹࡶࠧᒙ")
		if A41nqbj3wYt(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᒚ") not in BBS4olVgwTAex7fKFaObDWtmUp9Is: W67hPCcaOek094[yobpaW7sBqtKRrv(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᒛ")] = E1ltCBVyML6PAUNY(r0D4C3z7Onqpa)
	return g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,iLwsXm6HN3VYGRFxUCPKWqc,fAbWextglFNyRZv4JiLrM3dp
def HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI=WnNGfosHr5STAq8j7miwyRZ6eOUbV,FX7dKayU9G1mTv=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	Vgy0Y3N6X8DOIxczQAl = EEYpJtRZncrFePa3Qi0DlSuWo(g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,showDialogs,ADN3XhW9ZpVmFK84j2roiy,YzmKQPA7nEad15R2BGsT6N8qWCuiI,FX7dKayU9G1mTv)
	g0Sft2VkTxGD1pYobnsX76E,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,iLwsXm6HN3VYGRFxUCPKWqc,fAbWextglFNyRZv4JiLrM3dp = Vgy0Y3N6X8DOIxczQAl
	vcQbFfCk6T1,j9jmDsfvq51,FzwtaeUBAmWNYT8P1KL7,aKjiD1o926NyV = CCeIOiGo7sNfQJTjSrnaYlw(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	Drx9ijtZIEezRk7mpVhlFL = G3yDpvxOiSWdAeL.getSetting(VP70ytiFNMBl6vHDaW(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬᒜ"))
	QQFw9bKiAfmO7PrJD6UhBT = G3yDpvxOiSWdAeL.getSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᒝ"))
	i1hNlPaAcTrg72Zd3QVqyw = G3yDpvxOiSWdAeL.getSetting(mq5t9JXSdHT8yfDVF(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᒞ"))
	MyRtQPSCXDNnx461m = [jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶࠫᒟ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᒠ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨᒡ"),yobpaW7sBqtKRrv(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫᒢ"),gPE1XB87fQl(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧᒣ"),gPE1XB87fQl(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰࠩᒤ")]
	DN491FYBZO = r0D4C3z7Onqpa if any(value in kdNn2Zqsj4wPi5ThuoUQvtcg6OA for value in MyRtQPSCXDNnx461m) else KiryBCvngZzF85UN6xSDlOVweL4I9
	if beV5l2D8HznyJI0(u"ࠧࠧࡷࡵࡰࡂ࠭ᒥ") in vcQbFfCk6T1 and DN491FYBZO: pSL4TDEo8z1R3aH = vcQbFfCk6T1.rsplit(A41nqbj3wYt(u"ࠨࠨࡸࡶࡱࡃࠧᒦ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
	else: pSL4TDEo8z1R3aH = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	ZyDd0WgoYSKrt1a98qi = A3pXVFdyP1.SITESURLS[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᒧ")]
	gFA1Cv2eXB3uwd09mRiLfn = vcQbFfCk6T1 in ZyDd0WgoYSKrt1a98qi or pSL4TDEo8z1R3aH in ZyDd0WgoYSKrt1a98qi
	wecazY5XTyKuPSG4VlE9Wm = A3pXVFdyP1.SITESURLS[ZLr5gRSkFewKdUos90bM(u"ࠪࡖࡊࡖࡏࡔࠩᒨ")]
	oepaR1vPmz9ZxAMUfJwLY = vcQbFfCk6T1 in wecazY5XTyKuPSG4VlE9Wm or pSL4TDEo8z1R3aH in wecazY5XTyKuPSG4VlE9Wm
	Cu7kOUlZeYRVEGPFM = gFA1Cv2eXB3uwd09mRiLfn or oepaR1vPmz9ZxAMUfJwLY
	coVFxGzgKdpMPAabEiI = KiryBCvngZzF85UN6xSDlOVweL4I9
	TG93gsPWKInEMFuar0vBUVtCwpq = r0D4C3z7Onqpa
	cZ1RG9xoTi = j9jmDsfvq51==None and FzwtaeUBAmWNYT8P1KL7==None and not DN491FYBZO
	if cZ1RG9xoTi and Cu7kOUlZeYRVEGPFM:
		if gFA1Cv2eXB3uwd09mRiLfn:
			FzM5eQZ7WEtnul8P41q9Sri6LXG0VH = ZyDd0WgoYSKrt1a98qi.index(vcQbFfCk6T1)
			RsIdLenMJ567QqpANClKg9T = A3pXVFdyP1.SITESURLS[GHg28TBchiyn6l(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩᒩ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			eFDHisShxptVPJbG1mZ7o = A3pXVFdyP1.SITESURLS[iySORMYxWXszEH18(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪᒪ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			VB2re1WUA9MGDXxcsyRthwQOdNF = A3pXVFdyP1.SITESURLS[Z9FPQvwlbjLTh(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫᒫ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			RAVgaEbSx8NZkzrewHJXhK6lC7 = A3pXVFdyP1.api_python_actions[FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			if RAVgaEbSx8NZkzrewHJXhK6lC7==GHg28TBchiyn6l(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩᒬ"): iLwsXm6HN3VYGRFxUCPKWqc,fAbWextglFNyRZv4JiLrM3dp,TG93gsPWKInEMFuar0vBUVtCwpq = KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9
			elif RAVgaEbSx8NZkzrewHJXhK6lC7==kdRO82AImh0LFw(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᒭ"): coVFxGzgKdpMPAabEiI = r0D4C3z7Onqpa
		elif oepaR1vPmz9ZxAMUfJwLY:
			FzM5eQZ7WEtnul8P41q9Sri6LXG0VH = wecazY5XTyKuPSG4VlE9Wm.index(vcQbFfCk6T1)
			RsIdLenMJ567QqpANClKg9T = A3pXVFdyP1.SITESURLS[rVy3Ops0mohYkT(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠶࠭ᒮ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			eFDHisShxptVPJbG1mZ7o = A3pXVFdyP1.SITESURLS[beV5l2D8HznyJI0(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧᒯ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			VB2re1WUA9MGDXxcsyRthwQOdNF = A3pXVFdyP1.SITESURLS[wwWzyF4ZpSQXKOgk569(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠳ࠨᒰ")][FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
			RAVgaEbSx8NZkzrewHJXhK6lC7 = A3pXVFdyP1.api_repos_actions[FzM5eQZ7WEtnul8P41q9Sri6LXG0VH]
	if FzwtaeUBAmWNYT8P1KL7==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FzwtaeUBAmWNYT8P1KL7 = Drx9ijtZIEezRk7mpVhlFL
	elif FzwtaeUBAmWNYT8P1KL7==None and QQFw9bKiAfmO7PrJD6UhBT in [wwWzyF4ZpSQXKOgk569(u"ࠬࡇࡕࡕࡑࠪᒱ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᒲ")] and iLwsXm6HN3VYGRFxUCPKWqc: FzwtaeUBAmWNYT8P1KL7 = Drx9ijtZIEezRk7mpVhlFL
	if gFA1Cv2eXB3uwd09mRiLfn or oepaR1vPmz9ZxAMUfJwLY: QoZYSAMzNs5uHnGEdC7p = Z9FPQvwlbjLTh(u"࠴࠳ᘯ")
	elif DN491FYBZO: QoZYSAMzNs5uHnGEdC7p = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠹࠴ᘰ")
	elif ADN3XhW9ZpVmFK84j2roiy in Km2gVSNzXhsfMDYRdupqP0kUr8: QoZYSAMzNs5uHnGEdC7p = eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠵࠵ᘱ")
	elif ADN3XhW9ZpVmFK84j2roiy==kdRO82AImh0LFw(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒳ"): QoZYSAMzNs5uHnGEdC7p = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠷࠶ᘲ")
	elif ADN3XhW9ZpVmFK84j2roiy==YYQS36fyPvtuzcEmRL(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒴ"): QoZYSAMzNs5uHnGEdC7p = KLX7hW0nBAEgy6m4SvH(u"࠸࠰ᘳ")
	elif tzZ6PhyDOUnwLM3pdK(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫᒵ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = wwWzyF4ZpSQXKOgk569(u"࠷࠱ᘴ")
	elif yobpaW7sBqtKRrv(u"ࠪࡗࡍࡕࡆࡉࡃࠪᒶ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = I872Vum45fMNe1BRngTZLoQiqvkt(u"࠸࠷ᘵ")
	elif IMjqygdfYSKpHlWu5Aa(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫᒷ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠴࠸ᘶ")
	elif SI7eBdND4lx8pt5Qk(u"ࠬࡇࡈࡘࡃࡎࠫᒸ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠵࠴ᘷ")
	elif A41nqbj3wYt(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᒹ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠶࠵ᘸ")
	elif pp7FcjEe6g(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ᒺ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠸࠶ᘹ")
	elif wwWzyF4ZpSQXKOgk569(u"ࠨࡃࡎࡓࡆࡓࠧᒻ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = aiQwFE1TGx04vmLcsYkIW5jA(u"࠸࠵ᘺ")
	elif jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡄࡏ࡜ࡇࡍࠨᒼ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠱ᘻ")
	elif ZLr5gRSkFewKdUos90bM(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᒽ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠳࠲ᘼ")
	elif I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ᒾ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = ZLr5gRSkFewKdUos90bM(u"࠸࠳ᘽ")
	elif yobpaW7sBqtKRrv(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧᒿ") in ADN3XhW9ZpVmFK84j2roiy: QoZYSAMzNs5uHnGEdC7p = A41nqbj3wYt(u"࠷࠴ᘾ")
	else: QoZYSAMzNs5uHnGEdC7p = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠵࠺ᘿ")
	OnVMRUchdv64Zlt2qPaj9poeNwH = (j9jmDsfvq51!=None)
	R9AbxUFJc2jT1EtBk = (FzwtaeUBAmWNYT8P1KL7!=None and QQFw9bKiAfmO7PrJD6UhBT!=wwWzyF4ZpSQXKOgk569(u"࠭ࡓࡕࡑࡓࠫᓀ"))
	if OnVMRUchdv64Zlt2qPaj9poeNwH and not DN491FYBZO: uTaiRMI8eYmN(wwWzyF4ZpSQXKOgk569(u"ࠧหใ฼๎้ࠦศา๊ๆื๏ࠦัใ็ࠪᓁ"),j9jmDsfvq51)
	elif R9AbxUFJc2jT1EtBk: uTaiRMI8eYmN(beV5l2D8HznyJI0(u"ࠨฬไ฽๏๊ࠠࡅࡐࡖࠤึ่ๅࠨᓂ"),FzwtaeUBAmWNYT8P1KL7)
	if OnVMRUchdv64Zlt2qPaj9poeNwH:
		ea9Tk4o1QhqDZbMfxC = {rVy3Ops0mohYkT(u"ࠤ࡫ࡸࡹࡶࠢᓃ"):j9jmDsfvq51,A41nqbj3wYt(u"ࠥ࡬ࡹࡺࡰࡴࠤᓄ"):j9jmDsfvq51}
		Zu7JQ45X8eP2L = j9jmDsfvq51
	else: ea9Tk4o1QhqDZbMfxC,Zu7JQ45X8eP2L = {},WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if R9AbxUFJc2jT1EtBk:
		import urllib3.util.connection as HWJZNpmzGkTC8fvQiVox6nP0rM
		Iciwj9Vdzb08pRatTHk7K5 = r863jEeslqhwxcQ5oY7vN0nk4fWi2(HWJZNpmzGkTC8fvQiVox6nP0rM,Drx9ijtZIEezRk7mpVhlFL,r0D4C3z7Onqpa)
	Dk1Jr6T5wePjocf,rOYi4sNpFBlAvtC6LK,DGuNdjlcYQ9y8nUa4ZJ3z1V,KxUsjRHguS8GDBh32iJc5w,jKQ9UbY0yWZrH1gFt3,eDI0FvmxW9jbUMGqEzY,verify = Xfeq2u54AGcLMKRpjZ7J,ADN3XhW9ZpVmFK84j2roiy,g0Sft2VkTxGD1pYobnsX76E,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,aKjiD1o926NyV
	if coVFxGzgKdpMPAabEiI: jKQ9UbY0yWZrH1gFt3 = r0D4C3z7Onqpa
	if Cu7kOUlZeYRVEGPFM or Xfeq2u54AGcLMKRpjZ7J: Dk1Jr6T5wePjocf = KiryBCvngZzF85UN6xSDlOVweL4I9
	cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E = -wnaWTQM7VJPkZzO9eoSyFU4,I872Vum45fMNe1BRngTZLoQiqvkt(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫᓅ")
	sWg5Mtp9GHf7oZl = KiryBCvngZzF85UN6xSDlOVweL4I9
	if not A3pXVFdyP1.FORWARDS_HOSTNAMES: A3pXVFdyP1.FORWARDS_HOSTNAMES = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡪࡩࡤࡶࠪᓆ"),pp7FcjEe6g(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠵ࠫᓇ"),ZLr5gRSkFewKdUos90bM(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᓈ"))
	rrbX4uUEBd6mGQVMf = []
	while vcQbFfCk6T1 not in rrbX4uUEBd6mGQVMf and vcQbFfCk6T1 in list(A3pXVFdyP1.FORWARDS_HOSTNAMES.keys()):
		rrbX4uUEBd6mGQVMf.append(vcQbFfCk6T1)
		vcQbFfCk6T1 = A3pXVFdyP1.FORWARDS_HOSTNAMES[vcQbFfCk6T1]
	Rf2UZ4AsuaXQcKJzPN1yHokECwGpO = bZ0VWjAHm1v2Csroh
	if gFA1Cv2eXB3uwd09mRiLfn:
		DGuNdjlcYQ9y8nUa4ZJ3z1V = IMjqygdfYSKpHlWu5Aa(u"ࠨࡒࡒࡗ࡙࠭ᓉ")
		W67hPCcaOek094[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡄ࡚࠲ࡋ࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᓊ")] = KLX7hW0nBAEgy6m4SvH(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᓋ")
		X9XHWRA17ZNfJysLkO5 = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(bZ0VWjAHm1v2Csroh)
		Rf2UZ4AsuaXQcKJzPN1yHokECwGpO = tyLbxATjI4GivOnUHcu(X9XHWRA17ZNfJysLkO5,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ᙀ"))
		vcQbFfCk6T1 = vcQbFfCk6T1+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡄࡻࡳࡦࡴࡀࠫᓌ")+WW3PiLNaxCY
	import requests as KnHmtUWv49wToIf
	for zuEo6GDeAR5Z in range(kdRO82AImh0LFw(u"࠿ᙁ")):
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
		if zuEo6GDeAR5Z:
			rOYi4sNpFBlAvtC6LK = mq5t9JXSdHT8yfDVF(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭ᓍ")
			try: u4vhNT8C0k1tmrxX9F5gGWo7Z.close()
			except: pass
		if DN491FYBZO or not OnVMRUchdv64Zlt2qPaj9poeNwH: N0CQrbltd91Ywj7Zm5xJz43suchF(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓ࡝ࡶࡒࡔࡊࡔ࡟ࡖࡔࡏࠫᓎ"),vcQbFfCk6T1,Rf2UZ4AsuaXQcKJzPN1yHokECwGpO,W67hPCcaOek094,rOYi4sNpFBlAvtC6LK,DGuNdjlcYQ9y8nUa4ZJ3z1V)
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1
		try:
			u4vhNT8C0k1tmrxX9F5gGWo7Z = KnHmtUWv49wToIf.request(DGuNdjlcYQ9y8nUa4ZJ3z1V,vcQbFfCk6T1,data=Rf2UZ4AsuaXQcKJzPN1yHokECwGpO,headers=W67hPCcaOek094,verify=verify,allow_redirects=Dk1Jr6T5wePjocf,timeout=QoZYSAMzNs5uHnGEdC7p,proxies=ea9Tk4o1QhqDZbMfxC)
			if iySORMYxWXszEH18(u"࠳࠱࠲ᙂ")<=u4vhNT8C0k1tmrxX9F5gGWo7Z.status_code<=bawK2j7T81Nrc4GWs05xzDg(u"࠴࠻࠼ᙃ"):
				if not KxUsjRHguS8GDBh32iJc5w:
					SOw5EUxC9k = u4vhNT8C0k1tmrxX9F5gGWo7Z.headers.get(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᓏ")) or u4vhNT8C0k1tmrxX9F5gGWo7Z.headers.get(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᓐ")) or WnNGfosHr5STAq8j7miwyRZ6eOUbV
					if SOw5EUxC9k.startswith(SI7eBdND4lx8pt5Qk(u"ࠩ࠽ࠫᓑ")): SOw5EUxC9k = vcQbFfCk6T1+SOw5EUxC9k
					if SOw5EUxC9k: vcQbFfCk6T1 = SOw5EUxC9k
					else: KxUsjRHguS8GDBh32iJc5w = r0D4C3z7Onqpa
					if not KxUsjRHguS8GDBh32iJc5w: vcQbFfCk6T1 = vcQbFfCk6T1.encode(kdRO82AImh0LFw(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᓒ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᓓ")).decode(e87cIA5vwOQLDEP1,A6iX18qgyOFlZxz7sc(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᓔ"))
					if Cu7kOUlZeYRVEGPFM and u4vhNT8C0k1tmrxX9F5gGWo7Z.status_code==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠵࠳࠻ᙄ"):
						Dk1Jr6T5wePjocf = Xfeq2u54AGcLMKRpjZ7J
						DGuNdjlcYQ9y8nUa4ZJ3z1V = g0Sft2VkTxGD1pYobnsX76E
						KxUsjRHguS8GDBh32iJc5w = r0D4C3z7Onqpa
						ggI3G7znXkbPQ5H
				if not KxUsjRHguS8GDBh32iJc5w or Xfeq2u54AGcLMKRpjZ7J:
					if I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡨࡵࡶࡳࠫᓕ") not in vcQbFfCk6T1:
						SPTqjsFBlCWXLgtoN = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(QQTfhlZEDnu4wVcOeHGNyCBo5t2,SI7eBdND4lx8pt5Qk(u"ࠧࡶࡴ࡯ࠫᓖ"))
						vcQbFfCk6T1 = SPTqjsFBlCWXLgtoN+KLX7hW0nBAEgy6m4SvH(u"ࠨ࠱ࠪᓗ")+vcQbFfCk6T1.lstrip(beV5l2D8HznyJI0(u"ࠩ࠲ࠫᓘ"))
				if vcQbFfCk6T1!=QQTfhlZEDnu4wVcOeHGNyCBo5t2:
					A3pXVFdyP1.FORWARDS_HOSTNAMES[QQTfhlZEDnu4wVcOeHGNyCBo5t2] = vcQbFfCk6T1
					sWg5Mtp9GHf7oZl = r0D4C3z7Onqpa
				if not KxUsjRHguS8GDBh32iJc5w:
					mcPxWovkfK9hFVQCi03BAE = u4vhNT8C0k1tmrxX9F5gGWo7Z
					if mm19wY7OfIvCxb8AFZEHJ(vcQbFfCk6T1): KxUsjRHguS8GDBh32iJc5w = r0D4C3z7Onqpa
			elif QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠹࠺࠶ᙆ")<=u4vhNT8C0k1tmrxX9F5gGWo7Z.status_code<=iySORMYxWXszEH18(u"࠸࠽࠾ᙅ"): jKQ9UbY0yWZrH1gFt3 = r0D4C3z7Onqpa
			else: KxUsjRHguS8GDBh32iJc5w = r0D4C3z7Onqpa
			if not KxUsjRHguS8GDBh32iJc5w and not Xfeq2u54AGcLMKRpjZ7J and mcPxWovkfK9hFVQCi03BAE.headers: u4vhNT8C0k1tmrxX9F5gGWo7Z = mcPxWovkfK9hFVQCi03BAE
			QQTfhlZEDnu4wVcOeHGNyCBo5t2 = u4vhNT8C0k1tmrxX9F5gGWo7Z.url
			cquGxZCOaDk3QJMNlXSeU = u4vhNT8C0k1tmrxX9F5gGWo7Z.status_code
			PPSTwoZdRinA3YXtybaeVux9Om0E = u4vhNT8C0k1tmrxX9F5gGWo7Z.reason
			u4vhNT8C0k1tmrxX9F5gGWo7Z.raise_for_status()
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r0D4C3z7Onqpa
		except KnHmtUWv49wToIf.exceptions.HTTPError as YIrltJES6aPjnm94qTuoMiORKpDA0:
			pass
		except KnHmtUWv49wToIf.exceptions.Timeout as YIrltJES6aPjnm94qTuoMiORKpDA0:
			if YVzokG2yZqrh3w8bU: PPSTwoZdRinA3YXtybaeVux9Om0E = str(YIrltJES6aPjnm94qTuoMiORKpDA0.message).split(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠾ࠥ࠭ᓙ"))[wnaWTQM7VJPkZzO9eoSyFU4]
			else: PPSTwoZdRinA3YXtybaeVux9Om0E = str(YIrltJES6aPjnm94qTuoMiORKpDA0).split(GHg28TBchiyn6l(u"ࠫ࠿ࠦࠧᓚ"))[wnaWTQM7VJPkZzO9eoSyFU4]
		except KnHmtUWv49wToIf.exceptions.ConnectionError as YIrltJES6aPjnm94qTuoMiORKpDA0:
			try: OxvlAjSprB8IiE5 = YIrltJES6aPjnm94qTuoMiORKpDA0.message[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			except: OxvlAjSprB8IiE5 = str(YIrltJES6aPjnm94qTuoMiORKpDA0)
			N870mDlEi64HB = p7dwlH1PRStBgyMUW.findall(ZLr5gRSkFewKdUos90bM(u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢᓛ"),OxvlAjSprB8IiE5)
			if not N870mDlEi64HB: N870mDlEi64HB = p7dwlH1PRStBgyMUW.findall(kdRO82AImh0LFw(u"ࠨࠬࠡࡧࡵࡶࡴࡸ࡜ࠩࠪ࡟ࡨ࠰࠯ࠬࠡࠩࠫ࠲࠯ࡅࠩࠨࠤᓜ"),OxvlAjSprB8IiE5)
			if not N870mDlEi64HB:
				TTRiNlzHO5VAja8h = p7dwlH1PRStBgyMUW.findall(iySORMYxWXszEH18(u"ࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠻࠰࠭ࡃ࠭ࡢࡤࠬࠫ࠽ࠦᓝ"),OxvlAjSprB8IiE5)
				if TTRiNlzHO5VAja8h: N870mDlEi64HB = [TTRiNlzHO5VAja8h[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4],TTRiNlzHO5VAja8h[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
			if not N870mDlEi64HB: N870mDlEi64HB = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠣ࠼ࠫࡠࡩ࠱ࠩ࠻ࠢࠫ࠲࠯ࡅࠩࠨࠤᓞ"),OxvlAjSprB8IiE5)
			if not N870mDlEi64HB: N870mDlEi64HB = p7dwlH1PRStBgyMUW.findall(VP70ytiFNMBl6vHDaW(u"ࠤࠣࠬࡡࡪࠫࠪ࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᓟ"),OxvlAjSprB8IiE5)
			try: cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E = N870mDlEi64HB[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			except: cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E = -XURrDCfOS9Mbhpv2Pmjos56TeW,OxvlAjSprB8IiE5
		except KnHmtUWv49wToIf.exceptions.RequestException as YIrltJES6aPjnm94qTuoMiORKpDA0:
			if YVzokG2yZqrh3w8bU: PPSTwoZdRinA3YXtybaeVux9Om0E = YIrltJES6aPjnm94qTuoMiORKpDA0.message
			else: PPSTwoZdRinA3YXtybaeVux9Om0E = str(YIrltJES6aPjnm94qTuoMiORKpDA0)
		except:
			try: cquGxZCOaDk3QJMNlXSeU = u4vhNT8C0k1tmrxX9F5gGWo7Z.status_code
			except: pass
			try: PPSTwoZdRinA3YXtybaeVux9Om0E = u4vhNT8C0k1tmrxX9F5gGWo7Z.reason
			except: pass
		PPSTwoZdRinA3YXtybaeVux9Om0E = str(PPSTwoZdRinA3YXtybaeVux9Om0E)
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,VP70ytiFNMBl6vHDaW(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡢࡴࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᓠ")+str(cquGxZCOaDk3QJMNlXSeU)+iySORMYxWXszEH18(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᓡ")+PPSTwoZdRinA3YXtybaeVux9Om0E+SI7eBdND4lx8pt5Qk(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᓢ")+ADN3XhW9ZpVmFK84j2roiy+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᓣ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠡ࡟ࠪᓤ"))
		if cZ1RG9xoTi and Cu7kOUlZeYRVEGPFM and not jKQ9UbY0yWZrH1gFt3 and cquGxZCOaDk3QJMNlXSeU!=GHg28TBchiyn6l(u"࠷࠶࠰ᙇ") and A41nqbj3wYt(u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫᓥ") not in vcQbFfCk6T1:
			if vcQbFfCk6T1 not in [RsIdLenMJ567QqpANClKg9T,eFDHisShxptVPJbG1mZ7o,VB2re1WUA9MGDXxcsyRthwQOdNF]: vcQbFfCk6T1,jKQ9UbY0yWZrH1gFt3 = RsIdLenMJ567QqpANClKg9T,KiryBCvngZzF85UN6xSDlOVweL4I9
			elif vcQbFfCk6T1==RsIdLenMJ567QqpANClKg9T: vcQbFfCk6T1,jKQ9UbY0yWZrH1gFt3 = eFDHisShxptVPJbG1mZ7o,KiryBCvngZzF85UN6xSDlOVweL4I9
			elif vcQbFfCk6T1==eFDHisShxptVPJbG1mZ7o: vcQbFfCk6T1,jKQ9UbY0yWZrH1gFt3 = VB2re1WUA9MGDXxcsyRthwQOdNF,r0D4C3z7Onqpa
			continue
		if not KxUsjRHguS8GDBh32iJc5w and FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: continue
		break
	cquGxZCOaDk3QJMNlXSeU = int(cquGxZCOaDk3QJMNlXSeU)
	if not FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy:
		FqnIrzBxdAoaEwDy = IQZ0bGPovap6gWmc4LfY(SI7eBdND4lx8pt5Qk(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪᓦ"),GHg28TBchiyn6l(u"࠾࠰ᙈ"))
		if FqnIrzBxdAoaEwDy==-wnaWTQM7VJPkZzO9eoSyFU4:
			SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࠡࡆࡌࡗࡈࡕࡎࡏࡇࡆࡘࡊࡊࠠࠡࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡷࡳࠥࡺࡨࡦࠢ࡬ࡲࡹ࡫ࡲ࡯ࡧࡷࠤࠦࠧࠧᓧ"))
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,GHg28TBchiyn6l(u"้๊ࠫริใࠣะ์อาไࠢ฽๎ึࠦๅาส๋฻ࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐ำหะา้ࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลฺัสำฬะࠠอ้สึฺ่๋ࠦำูࠣา๐อสࠢ࡟ࡲࡡࡴࠠๅฯ็ࠤฬ๊ๅีๅ็อࠥะรไัࠣว๋ࠦฬ่ษี็๋ࠥัษฺ๊ࠤอ฽ั๋ไฬࠤฺำ๊ฮหࠣฬฬ๊ล็ฬิ๊ฯ่ࠦโ์๊ࠤฬ๊ล็ฬิ๊ฯࠦสฺ็็ࠤอ฻่าหࠣะ๏ีษࠨᓨ"))
			sm0xF8WoGavE7iNjd()
			return u4vhNT8C0k1tmrxX9F5gGWo7Z
	if not FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy and rrbX4uUEBd6mGQVMf:
		for url in rrbX4uUEBd6mGQVMf:
			if url in list(A3pXVFdyP1.FORWARDS_HOSTNAMES.keys()):
				del A3pXVFdyP1.FORWARDS_HOSTNAMES[url]
				sWg5Mtp9GHf7oZl = r0D4C3z7Onqpa
	if sWg5Mtp9GHf7oZl:
		w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,SI7eBdND4lx8pt5Qk(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠴ࠪᓩ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᓪ"),A3pXVFdyP1.FORWARDS_HOSTNAMES,oldym5kX8IqLSVDtpNMw)
		A3pXVFdyP1.FORWARDS_HOSTNAMES = {}
	if FzwtaeUBAmWNYT8P1KL7!=None and QQFw9bKiAfmO7PrJD6UhBT!=yobpaW7sBqtKRrv(u"ࠧࡔࡖࡒࡔࠬᓫ"): HWJZNpmzGkTC8fvQiVox6nP0rM.create_connection = Iciwj9Vdzb08pRatTHk7K5
	if QQFw9bKiAfmO7PrJD6UhBT==wwWzyF4ZpSQXKOgk569(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨᓬ") and iLwsXm6HN3VYGRFxUCPKWqc: FzwtaeUBAmWNYT8P1KL7 = None
	if not FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy and j9jmDsfvq51==None and ADN3XhW9ZpVmFK84j2roiy not in Km2gVSNzXhsfMDYRdupqP0kUr8:
		C2nN35DILUFzEKqv0BPl4eZjH6 = YoBT71zcqe6RGIP.format_exc()
		if C2nN35DILUFzEKqv0BPl4eZjH6!=I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᓭ"): SZ0YL6RpbX.stderr.write(C2nN35DILUFzEKqv0BPl4eZjH6)
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = OOLSaYvmWAiTPXfuM9y3x5zZJ()
	if DN491FYBZO: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = pSL4TDEo8z1R3aH
	if not QQTfhlZEDnu4wVcOeHGNyCBo5t2: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.url = QQTfhlZEDnu4wVcOeHGNyCBo5t2
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.scrape = DN491FYBZO
	try:
		CchrWkm9SGDuf8 = u4vhNT8C0k1tmrxX9F5gGWo7Z.headers
		if not CchrWkm9SGDuf8.get(tzZ6PhyDOUnwLM3pdK(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᓮ")) and not CchrWkm9SGDuf8.get(iySORMYxWXszEH18(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᓯ")): CchrWkm9SGDuf8.headers[ZLr5gRSkFewKdUos90bM(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᓰ")] = QQTfhlZEDnu4wVcOeHGNyCBo5t2
	except: CchrWkm9SGDuf8 = {}
	try:
		SOnrWJBVCwHp4XExF9N5yoza3GjLil = u4vhNT8C0k1tmrxX9F5gGWo7Z.content
		if gFA1Cv2eXB3uwd09mRiLfn and SOnrWJBVCwHp4XExF9N5yoza3GjLil:
			ZlNDKah9mgCTeOycUIw5JAXPu2YvGb = {QchoMN1dtDgAOaE.lower(): vv8iRSdbKX043aWglfhuUQq1pEok for QchoMN1dtDgAOaE, vv8iRSdbKX043aWglfhuUQq1pEok in u4vhNT8C0k1tmrxX9F5gGWo7Z.headers.items()}
			if ZlNDKah9mgCTeOycUIw5JAXPu2YvGb.get(SI7eBdND4lx8pt5Qk(u"࠭ࡡࡷ࠯ࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ᓱ"))==eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠳࠱࠴ࠬᓲ"):
				SOnrWJBVCwHp4XExF9N5yoza3GjLil,A1njWC4ayFpYRi7S = FouSVWLdMTJgX(SOnrWJBVCwHp4XExF9N5yoza3GjLil,pp7FcjEe6g(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷ᙉ"))
				if A1njWC4ayFpYRi7S==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡋࡑ࡚ࡆࡒࡉࡅࡡࡗࡍࡒࡋࡓࡕࡃࡐࡔࠬᓳ"):
					PPSTwoZdRinA3YXtybaeVux9Om0E,cquGxZCOaDk3QJMNlXSeU = A41nqbj3wYt(u"ࠩࡌࡲࡻࡧ࡬ࡪࡦࠣࡅࡕࡏࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࠪᓴ"),-EEowc8rs5gUZTVjdOzmb0nu
					FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
					SOnrWJBVCwHp4XExF9N5yoza3GjLil = PPSTwoZdRinA3YXtybaeVux9Om0E
	except: SOnrWJBVCwHp4XExF9N5yoza3GjLil = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if rJ2oTLqabRtA and isinstance(SOnrWJBVCwHp4XExF9N5yoza3GjLil,bytes):
		try: SOnrWJBVCwHp4XExF9N5yoza3GjLil = SOnrWJBVCwHp4XExF9N5yoza3GjLil.decode(e87cIA5vwOQLDEP1)
		except: SOnrWJBVCwHp4XExF9N5yoza3GjLil = SOnrWJBVCwHp4XExF9N5yoza3GjLil.decode(fFnsCZYWeuh89D)
	if gFA1Cv2eXB3uwd09mRiLfn and SOnrWJBVCwHp4XExF9N5yoza3GjLil and A6iX18qgyOFlZxz7sc(u"࠷࠸࠴ᙋ")<=cquGxZCOaDk3QJMNlXSeU<=gPE1XB87fQl(u"࠶࠻࠼ᙊ"): PPSTwoZdRinA3YXtybaeVux9Om0E = SOnrWJBVCwHp4XExF9N5yoza3GjLil
	try: jiOoy1QexTBr = u4vhNT8C0k1tmrxX9F5gGWo7Z.cookies.get_dict()
	except: jiOoy1QexTBr = {}
	try: u4vhNT8C0k1tmrxX9F5gGWo7Z.close()
	except: pass
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code = cquGxZCOaDk3QJMNlXSeU
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.reason = PPSTwoZdRinA3YXtybaeVux9Om0E
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content = SOnrWJBVCwHp4XExF9N5yoza3GjLil
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.headers = CchrWkm9SGDuf8
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.cookies = jiOoy1QexTBr
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded = FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.scrapernumber = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.scraperserver = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.scraperurl = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if YVzokG2yZqrh3w8bU or isinstance(VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content,str): CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl = VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.content.lower()
	else: CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	dTftrq1upoYPkXwM = (tzZ6PhyDOUnwLM3pdK(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᓵ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl or yobpaW7sBqtKRrv(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᓶ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl) and CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl.count(mq5t9JXSdHT8yfDVF(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᓷ"))>XURrDCfOS9Mbhpv2Pmjos56TeW and A41nqbj3wYt(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᓸ") not in ADN3XhW9ZpVmFK84j2roiy and jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬᓹ") not in ADN3XhW9ZpVmFK84j2roiy and yobpaW7sBqtKRrv(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪᓺ") not in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl and not DN491FYBZO
	W9OwnF7h0Ql5r6uyL = (lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࡹࡩࡷ࡯ࡦࡺ࠰࡫ࡸࡲࡲ࠿ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠿ࠪᓻ") in QQTfhlZEDnu4wVcOeHGNyCBo5t2)
	if cquGxZCOaDk3QJMNlXSeU==rVy3Ops0mohYkT(u"࠵࠴࠵ᙌ") and (dTftrq1upoYPkXwM or W9OwnF7h0Ql5r6uyL):
		VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
	if VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded and cZ1RG9xoTi and Cu7kOUlZeYRVEGPFM:
		zE4XRrjSYK = bawK2j7T81Nrc4GWs05xzDg(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫᓼ")+bZ0VWjAHm1v2Csroh[ZLr5gRSkFewKdUos90bM(u"ࠫ࡯ࡵࡢࠨᓽ")].upper().replace(tzZ6PhyDOUnwLM3pdK(u"ࠬࡍࡅࡕࠩᓾ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV) if coVFxGzgKdpMPAabEiI else RAVgaEbSx8NZkzrewHJXhK6lC7
		JIpyGT2ZQ9lqoDinAB(zE4XRrjSYK)
	if not VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded and cZ1RG9xoTi:
		ICtGWoUnNKBmsrjOhzduRyEAc34l2T = (pp7FcjEe6g(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᓿ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl and beV5l2D8HznyJI0(u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩᔀ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl)
		g297zi5UqXxfldj = (aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࠷ࠣࡷࡪࡩࠧᔁ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl and GHg28TBchiyn6l(u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪᔂ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl)
		GIx4h1WCtJuRkXv9zBSciw = (cquGxZCOaDk3QJMNlXSeU in [tzZ6PhyDOUnwLM3pdK(u"࠸࠵࠹ᙍ")] and beV5l2D8HznyJI0(u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭ᔃ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl)
		cxXGsURyiq0mJ = (XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭ᔄ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl and rVy3Ops0mohYkT(u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩᔅ") in CO5K3hJ0qotWYkfFMBgN7dLUHPS6sl)
		WG0qPpwhn8Ng4oAslv9m1uUQdR3 = (aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࡗࡓࡑࡑࡋࡤ࡜ࡅࡓࡕࡌࡓࡓࡥࡎࡖࡏࡅࡉࡗ࠭ᔆ") in PPSTwoZdRinA3YXtybaeVux9Om0E or n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡸࡴࡲࡲ࡬ࠦࡶࡦࡴࡶ࡭ࡴࡴࠠ࡯ࡷࡰࡦࡪࡸࠧᔇ") in PPSTwoZdRinA3YXtybaeVux9Om0E)
		if   dTftrq1upoYPkXwM: PPSTwoZdRinA3YXtybaeVux9Om0E = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᔈ")
		elif ICtGWoUnNKBmsrjOhzduRyEAc34l2T: PPSTwoZdRinA3YXtybaeVux9Om0E = YYQS36fyPvtuzcEmRL(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᔉ")
		elif g297zi5UqXxfldj: PPSTwoZdRinA3YXtybaeVux9Om0E = pp7FcjEe6g(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪᔊ")
		elif GIx4h1WCtJuRkXv9zBSciw: PPSTwoZdRinA3YXtybaeVux9Om0E = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡧࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠬᔋ")
		elif cxXGsURyiq0mJ: PPSTwoZdRinA3YXtybaeVux9Om0E = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧᔌ")
		elif W9OwnF7h0Ql5r6uyL: PPSTwoZdRinA3YXtybaeVux9Om0E = gPE1XB87fQl(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡱ࡮ࡹࡳࡪࡰࡪࠤ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠡࡥ࡫ࡩࡨࡱࠧᔍ")
		elif WG0qPpwhn8Ng4oAslv9m1uUQdR3: PPSTwoZdRinA3YXtybaeVux9Om0E = yobpaW7sBqtKRrv(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡾࡵࡵࡳࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣࡨࡪࡼࡩࡤࡧࡶࠫᔎ")
		else: PPSTwoZdRinA3YXtybaeVux9Om0E = str(PPSTwoZdRinA3YXtybaeVux9Om0E)
		if ADN3XhW9ZpVmFK84j2roiy in KTbHtcdjkuC0ve5DUnzLS2OXFmyxV9: pass
		elif ADN3XhW9ZpVmFK84j2roiy in Km2gVSNzXhsfMDYRdupqP0kUr8:
			SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+bawK2j7T81Nrc4GWs05xzDg(u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᔏ")+str(cquGxZCOaDk3QJMNlXSeU)+kdRO82AImh0LFw(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᔐ")+PPSTwoZdRinA3YXtybaeVux9Om0E+kdRO82AImh0LFw(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᔑ")+ADN3XhW9ZpVmFK84j2roiy+tzZ6PhyDOUnwLM3pdK(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᔒ")+vcQbFfCk6T1+beV5l2D8HznyJI0(u"ࠬࠦ࡝ࠨᔓ"))
		else: SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᔔ")+str(cquGxZCOaDk3QJMNlXSeU)+YYQS36fyPvtuzcEmRL(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᔕ")+PPSTwoZdRinA3YXtybaeVux9Om0E+oiWNFYzcIUeh(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᔖ")+ADN3XhW9ZpVmFK84j2roiy+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᔗ")+vcQbFfCk6T1+bawK2j7T81Nrc4GWs05xzDg(u"ࠪࠤࡢ࠭ᔘ"))
		dd9ADjxUI4O = pSL4TDEo8z1R3aH if DN491FYBZO else EZk136aeLoNqPvlDcTQpyM9Wm(vcQbFfCk6T1)
		if YVzokG2yZqrh3w8bU and isinstance(dd9ADjxUI4O,unicode): dd9ADjxUI4O = dd9ADjxUI4O.encode(e87cIA5vwOQLDEP1)
		if Cu7kOUlZeYRVEGPFM: dd9ADjxUI4O = dd9ADjxUI4O.split(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࠴࠭ᔙ"))[-wnaWTQM7VJPkZzO9eoSyFU4]
		DDjUqR4tNp9kTvflPH = str(PPSTwoZdRinA3YXtybaeVux9Om0E)+YYQS36fyPvtuzcEmRL(u"ࠬࡢ࡮ࠩࠩᔚ")+dd9ADjxUI4O+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࠩࠨᔛ")
		if any([dTftrq1upoYPkXwM,ICtGWoUnNKBmsrjOhzduRyEAc34l2T,g297zi5UqXxfldj,GIx4h1WCtJuRkXv9zBSciw,cxXGsURyiq0mJ,W9OwnF7h0Ql5r6uyL,WG0qPpwhn8Ng4oAslv9m1uUQdR3]) and fAbWextglFNyRZv4JiLrM3dp:
			if not WG0qPpwhn8Ng4oAslv9m1uUQdR3:
				VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code = -vXIdY7TwFKso40gVBq5
				mreIFN2Y4XCoHyUM1uJpgELw = I872Vum45fMNe1BRngTZLoQiqvkt(u"่ࠧา๊ࠤฬ๊ีโฯฬࠤ้อ๋ࠠ็ๆ๊ࠥาไษ้สࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳࠴ࠠๅล้ࠤ฾๊๊่ษ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢํ้๋฿ࠠษำส้ัࠦวๅๅ๋้อ๐่หำ้๋ࠣࠦฬๅสࠣ์ๆะอ๊ࠡสืฯิฯศ็๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢสฺ่็อศฬࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤ๏ูสุ์฼ࠤศ์๋ࠠฯส์้ࠦวิฬัำฬ๋ࠠฦ่อี๋ะࠠฤะิํ๊ࠥสอษ๋ึࠥํะศࠢส่าาศࠡ࠰࠱ࠤ้้ๆࠡๆสࠤ๏๎ฬะู้ࠢฬ์ࠠฤ่๋ࠣีํࠠศๆ่ัฬ๎ไสࠢึ์ๆࠦส็ฮะࡠࡳ࠭ᔜ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+GHg28TBchiyn6l(u"ࠨࡇࡵࡶࡴࡸࠠࡄࡱࡧࡩ࠿ࠦࠠࠨᔝ")+str(VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code)+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+wwWzyF4ZpSQXKOgk569(u"๊่ࠩࠥะั๋ั้๋ࠣࠦศา่ส้ัูࠦๆษาࠤศ์๋ࠠฯส์้ࠦสอษ๋ึࠥํะศࠢส่าาศࠡมࠤࠫᔞ")+YVr6St5P4xsFC0aARQGKfiegD
			else:
				VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code = -yGLl1nSBrJPmi2adko9O
				mreIFN2Y4XCoHyUM1uJpgELw = KLX7hW0nBAEgy6m4SvH(u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥะๅ็฻ࠣๅฯำࠠษ฻ูࠤฺ็อศฬࠣห้หๆหำ้ฮࠥอไืำ๋ี๏ฯࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤฯ้่็่๊ࠢࠥอไาษ๋ฮึูࠦ็ัๆࠤศ๎ࠠๆ่ࠣฬึ์วๆฮࠣ฽๋ีใࠡล๋ࠤ๊์ࠠอ้สึࠥ฿ๆะๅࠣ࠲࠳ู่ࠦ์ไฮ์ࠦวๅฯ่ห๏ฯࠠืัࠣห้็๊า๊ึหฯࠦรู้ࠢำࠥอไหฮึืࠥษุ่ࠡาࠤฬ๊ศาษ่ะࠥอไๆฦำ๎ฮࠦ࠮࠯ࠢ็ั้ࠦวๅ็ื็้ฯ๋ࠠฮหࠤส๐โศใ๋ࠣีํࠠศๆะ้ฬ๐ษࠡษ็าฬ฽ฦส࡞ࡱࠫᔟ")+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+beV5l2D8HznyJI0(u"ࠫࡊࡸࡲࡰࡴࠣࡇࡴࡪࡥ࠻ࠢࠣࠫᔠ")+str(VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code)+YVr6St5P4xsFC0aARQGKfiegD+WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+A6iX18qgyOFlZxz7sc(u"ࠬํไࠡฬิ๎ิࠦๅ็ࠢหี๋อๅอࠢ฼้ฬีࠠฤ่ࠣ๎าอ่ๅࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆอะฬ๎า้ࠡำ๋ࠥอไฮ็ส๎ฮࠦฟࠢࠩᔡ")+YVr6St5P4xsFC0aARQGKfiegD
			kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,mreIFN2Y4XCoHyUM1uJpgELw)
			if kkLdeyJUsSiK9YwFZr4lPbVE:
				RR92fJL81AZWhmzguqbSd6xKo = iaE3YPpKG4mtB7M5zXNRCd16TI8e0A(g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,Rf2UZ4AsuaXQcKJzPN1yHokECwGpO,W67hPCcaOek094,Xfeq2u54AGcLMKRpjZ7J,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy,cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E)
				if RR92fJL81AZWhmzguqbSd6xKo.succeeded: return RR92fJL81AZWhmzguqbSd6xKo
		kkLdeyJUsSiK9YwFZr4lPbVE = r0D4C3z7Onqpa
		if (QQFw9bKiAfmO7PrJD6UhBT==wwWzyF4ZpSQXKOgk569(u"࠭ࡁࡔࡍࠪᔢ") or i1hNlPaAcTrg72Zd3QVqyw==beV5l2D8HznyJI0(u"ࠧࡂࡕࡎࠫᔣ")) and (iLwsXm6HN3VYGRFxUCPKWqc or fAbWextglFNyRZv4JiLrM3dp):
			kkLdeyJUsSiK9YwFZr4lPbVE = WwrtYuXs0D9L1Ry5zZxINdVHa2l(cquGxZCOaDk3QJMNlXSeU,DDjUqR4tNp9kTvflPH,ADN3XhW9ZpVmFK84j2roiy,DgUZXnsQIbAYhoyacOvuFWSGp)
			if kkLdeyJUsSiK9YwFZr4lPbVE and QQFw9bKiAfmO7PrJD6UhBT==kdRO82AImh0LFw(u"ࠨࡃࡖࡏࠬᔤ"): QQFw9bKiAfmO7PrJD6UhBT = beV5l2D8HznyJI0(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᔥ")
			else: QQFw9bKiAfmO7PrJD6UhBT = ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᔦ")
			if kkLdeyJUsSiK9YwFZr4lPbVE and i1hNlPaAcTrg72Zd3QVqyw==wwWzyF4ZpSQXKOgk569(u"ࠫࡆ࡙ࡋࠨᔧ"): i1hNlPaAcTrg72Zd3QVqyw = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᔨ")
			else: i1hNlPaAcTrg72Zd3QVqyw = SI7eBdND4lx8pt5Qk(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨᔩ")
			G3yDpvxOiSWdAeL.setSetting(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᔪ"),QQFw9bKiAfmO7PrJD6UhBT)
			G3yDpvxOiSWdAeL.setSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᔫ"),i1hNlPaAcTrg72Zd3QVqyw)
		if kkLdeyJUsSiK9YwFZr4lPbVE:
			if cquGxZCOaDk3QJMNlXSeU==CyHU86ZeYT5BWRcitSm2I(u"࠽ᙎ") and A41nqbj3wYt(u"ࠩ࡫ࡸࡹࡶࡳࠨᔬ") in vcQbFfCk6T1 and TG93gsPWKInEMFuar0vBUVtCwpq:
				if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(bawK2j7T81Nrc4GWs05xzDg(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪᔭ"),bawK2j7T81Nrc4GWs05xzDg(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᔮ"),x54xSdnCFHZ8yliofzOBK=Z9FPQvwlbjLTh(u"࠸࠰࠱࠲ᙏ"))
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᔯ")
				jjWCduSz9lRnpNk7BmsI12 = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,QQTfhlZEDnu4wVcOeHGNyCBo5t2,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,DgUZXnsQIbAYhoyacOvuFWSGp,wwWzyF4ZpSQXKOgk569(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧᔰ"))
				if jjWCduSz9lRnpNk7BmsI12.succeeded:
					VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = jjWCduSz9lRnpNk7BmsI12
					SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+SI7eBdND4lx8pt5Qk(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᔱ")+ADN3XhW9ZpVmFK84j2roiy+SI7eBdND4lx8pt5Qk(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᔲ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+yobpaW7sBqtKRrv(u"ࠩࠣࡡࠬᔳ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(tzZ6PhyDOUnwLM3pdK(u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧᔴ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᔵ"),x54xSdnCFHZ8yliofzOBK=gPE1XB87fQl(u"࠲࠱࠲࠳ᙐ"))
				else:
					SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᔶ")+ADN3XhW9ZpVmFK84j2roiy+GHg28TBchiyn6l(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᔷ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࠡ࡟ࠪᔸ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫᔹ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᔺ"),x54xSdnCFHZ8yliofzOBK=ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠳࠲࠳࠴ᙑ"))
			if not VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded and i1hNlPaAcTrg72Zd3QVqyw in [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡅ࡚࡚ࡏࠨᔻ"),tzZ6PhyDOUnwLM3pdK(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᔼ")] and fAbWextglFNyRZv4JiLrM3dp:
				if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(pp7FcjEe6g(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬᔽ"),CyHU86ZeYT5BWRcitSm2I(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᔾ"),x54xSdnCFHZ8yliofzOBK=bawK2j7T81Nrc4GWs05xzDg(u"࠴࠳࠴࠵ᙒ"))
				jjWCduSz9lRnpNk7BmsI12 = cFyK6eYqTvdmPnIrk(g0Sft2VkTxGD1pYobnsX76E,vcQbFfCk6T1,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,DgUZXnsQIbAYhoyacOvuFWSGp,ADN3XhW9ZpVmFK84j2roiy)
				if jjWCduSz9lRnpNk7BmsI12.succeeded:
					VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = jjWCduSz9lRnpNk7BmsI12
					SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+rVy3Ops0mohYkT(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᔿ")+ADN3XhW9ZpVmFK84j2roiy+SI7eBdND4lx8pt5Qk(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᕀ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+mq5t9JXSdHT8yfDVF(u"ࠩࠣࡡࠬᕁ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(iySORMYxWXszEH18(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩᕂ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᕃ"),x54xSdnCFHZ8yliofzOBK=tzZ6PhyDOUnwLM3pdK(u"࠵࠴࠵࠶ᙓ"))
				else:
					SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᕄ")+ADN3XhW9ZpVmFK84j2roiy+SI7eBdND4lx8pt5Qk(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᕅ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࠡ࡟ࠪᕆ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᕇ"),iySORMYxWXszEH18(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᕈ"),x54xSdnCFHZ8yliofzOBK=A6iX18qgyOFlZxz7sc(u"࠶࠵࠶࠰ᙔ"))
			if not VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded and QQFw9bKiAfmO7PrJD6UhBT in [IMjqygdfYSKpHlWu5Aa(u"ࠪࡅ࡚࡚ࡏࠨᕉ"),yobpaW7sBqtKRrv(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᕊ")] and iLwsXm6HN3VYGRFxUCPKWqc:
				if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(iySORMYxWXszEH18(u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᕋ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᕌ"),x54xSdnCFHZ8yliofzOBK=yobpaW7sBqtKRrv(u"࠷࠶࠰࠱ᙕ"))
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1+YYQS36fyPvtuzcEmRL(u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬᕍ")
				jjWCduSz9lRnpNk7BmsI12 = HwIaX0pBuN1Dh3ez945sJYRc7rVxkW(g0Sft2VkTxGD1pYobnsX76E,QQTfhlZEDnu4wVcOeHGNyCBo5t2,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,whtj1keM3OcTmuB9X,DgUZXnsQIbAYhoyacOvuFWSGp,bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠺ࡴࡩࠩᕎ"))
				if jjWCduSz9lRnpNk7BmsI12.succeeded:
					VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ = jjWCduSz9lRnpNk7BmsI12
					SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+pp7FcjEe6g(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩᕏ")+Drx9ijtZIEezRk7mpVhlFL+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᕐ")+ADN3XhW9ZpVmFK84j2roiy+iySORMYxWXszEH18(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᕑ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+SI7eBdND4lx8pt5Qk(u"ࠬࠦ࡝ࠨᕒ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧᕓ"),tzZ6PhyDOUnwLM3pdK(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᕔ"),x54xSdnCFHZ8yliofzOBK=rVy3Ops0mohYkT(u"࠸࠰࠱࠲ᙖ"))
				else:
					SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬᕕ")+Drx9ijtZIEezRk7mpVhlFL+ZLr5gRSkFewKdUos90bM(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᕖ")+ADN3XhW9ZpVmFK84j2roiy+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᕗ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+kdRO82AImh0LFw(u"ࠫࠥࡣࠧᕘ"))
					if DgUZXnsQIbAYhoyacOvuFWSGp: uTaiRMI8eYmN(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬᕙ"),iySORMYxWXszEH18(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᕚ"),x54xSdnCFHZ8yliofzOBK=IMjqygdfYSKpHlWu5Aa(u"࠲࠱࠲࠳ᙗ"))
		if i1hNlPaAcTrg72Zd3QVqyw==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᕛ") or QQFw9bKiAfmO7PrJD6UhBT==ZLr5gRSkFewKdUos90bM(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᕜ"): DgUZXnsQIbAYhoyacOvuFWSGp = KiryBCvngZzF85UN6xSDlOVweL4I9
		if not VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.succeeded:
			if DgUZXnsQIbAYhoyacOvuFWSGp: oHMhRFviaSOZqCe4jPEtk0N6 = WwrtYuXs0D9L1Ry5zZxINdVHa2l(cquGxZCOaDk3QJMNlXSeU,DDjUqR4tNp9kTvflPH,ADN3XhW9ZpVmFK84j2roiy,DgUZXnsQIbAYhoyacOvuFWSGp)
			if VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ.code!=lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠳࠲࠳ᙘ") and ADN3XhW9ZpVmFK84j2roiy not in r2nhXKbk6Rv5sZCet7diBYOpqFIa8P and A41nqbj3wYt(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭ᕝ") not in ADN3XhW9ZpVmFK84j2roiy: sm0xF8WoGavE7iNjd()
	if G3yDpvxOiSWdAeL.getSetting(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᕞ")) not in [aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡆ࡛ࡔࡐࠩᕟ"),tzZ6PhyDOUnwLM3pdK(u"࡙ࠬࡔࡐࡒࠪᕠ"),YYQS36fyPvtuzcEmRL(u"࠭ࡁࡔࡍࠪᕡ")]: G3yDpvxOiSWdAeL.setSetting(ZLr5gRSkFewKdUos90bM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᕢ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡃࡖࡏࠬᕣ"))
	if G3yDpvxOiSWdAeL.getSetting(oiWNFYzcIUeh(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᕤ")) not in [I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡅ࡚࡚ࡏࠨᕥ"),pp7FcjEe6g(u"ࠫࡘ࡚ࡏࡑࠩᕦ"),wwWzyF4ZpSQXKOgk569(u"ࠬࡇࡓࡌࠩᕧ")]: G3yDpvxOiSWdAeL.setSetting(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᕨ"),iySORMYxWXszEH18(u"ࠧࡂࡕࡎࠫᕩ"))
	return VtXF3yIG7q8mlwJgxebaQUd4YAjHDZ
def G1K2EatJhbxOkUMI7gSjHfZcoXe4(KnEazvPsXD8IGpThxi96Lfb, Eg1NDhXFYq2nzik43QBfm):
	Gk7MehvVWr, Eg1NDhXFYq2nzik43QBfm = list(KnEazvPsXD8IGpThxi96Lfb), Eg1NDhXFYq2nzik43QBfm & 0xFFFFFFFF
	for JrM1DoSuQ5n8 in range(len(Gk7MehvVWr)-wnaWTQM7VJPkZzO9eoSyFU4, j0jEZgiKdxFpMLHcU7kQr8v1lyX4, -wnaWTQM7VJPkZzO9eoSyFU4):
		Eg1NDhXFYq2nzik43QBfm = (Eg1NDhXFYq2nzik43QBfm * bawK2j7T81Nrc4GWs05xzDg(u"࠴࠺࠻࠺࠵࠳࠷ᙚ") + iySORMYxWXszEH18(u"࠳࠳࠵࠸࠿࠰࠵࠴࠵࠷ᙙ")) & 0xFFFFFFFF
		Gk7MehvVWr[JrM1DoSuQ5n8], Gk7MehvVWr[Eg1NDhXFYq2nzik43QBfm % (JrM1DoSuQ5n8 + wnaWTQM7VJPkZzO9eoSyFU4)] = Gk7MehvVWr[Eg1NDhXFYq2nzik43QBfm % (JrM1DoSuQ5n8 + wnaWTQM7VJPkZzO9eoSyFU4)], Gk7MehvVWr[JrM1DoSuQ5n8]
	return VP70ytiFNMBl6vHDaW(u"ࠨࠩᕪ").join(Gk7MehvVWr)
def fu7azBkFI9cEmv0gbsiSlq4MO5h(KnEazvPsXD8IGpThxi96Lfb, Q9njGzmxv3EcSIerlOg1TtLsJN, XX6E9DmNBCdQ):
	alnHTBrW0ydEc3M5V41ZuSf7QYo = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠪᕫ").join(chr(JrM1DoSuQ5n8) for JrM1DoSuQ5n8 in range(yobpaW7sBqtKRrv(u"࠶࠺࠼ᙛ")))
	if not rJ2oTLqabRtA: alnHTBrW0ydEc3M5V41ZuSf7QYo = alnHTBrW0ydEc3M5V41ZuSf7QYo.decode(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᕬ"))
	d1S9PLBquC0l7b4QRgIKGrsOF2aAtx = G1K2EatJhbxOkUMI7gSjHfZcoXe4(alnHTBrW0ydEc3M5V41ZuSf7QYo, Q9njGzmxv3EcSIerlOg1TtLsJN)
	bChSoMiXkGVtEsu3QYpJamK0flqWw7 = G1K2EatJhbxOkUMI7gSjHfZcoXe4(d1S9PLBquC0l7b4QRgIKGrsOF2aAtx, Q9njGzmxv3EcSIerlOg1TtLsJN)
	qLsbeofTlp = dict(zip(d1S9PLBquC0l7b4QRgIKGrsOF2aAtx,bChSoMiXkGVtEsu3QYpJamK0flqWw7)) if not XX6E9DmNBCdQ else dict(zip(bChSoMiXkGVtEsu3QYpJamK0flqWw7,d1S9PLBquC0l7b4QRgIKGrsOF2aAtx))
	KnEazvPsXD8IGpThxi96Lfb = iySORMYxWXszEH18(u"ࠫࠬᕭ").join(qLsbeofTlp.get(Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE,Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE) for Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE in KnEazvPsXD8IGpThxi96Lfb)
	return KnEazvPsXD8IGpThxi96Lfb
def Upkelw1OStZ5Vg426sAGjxmThoFW(KnEazvPsXD8IGpThxi96Lfb, Q9njGzmxv3EcSIerlOg1TtLsJN):
	U2vri4t3a8S, etCBPOrRGyElupiFjmK4, pzGCWsqnyrQwgFRXku2Jf4b = [], j0jEZgiKdxFpMLHcU7kQr8v1lyX4, j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	JlBORrQXFED = [iySORMYxWXszEH18(u"࠶࠶ᙜ")-int(keOU0L2JMmaH7T) for keOU0L2JMmaH7T in str(Q9njGzmxv3EcSIerlOg1TtLsJN)[::-wnaWTQM7VJPkZzO9eoSyFU4]]
	QQf5q4P32yDEGoZR1jrJaeiwvHMg = int(Z9FPQvwlbjLTh(u"ࠬ࠿ࠧᕮ")*len(str(Q9njGzmxv3EcSIerlOg1TtLsJN)))//vXIdY7TwFKso40gVBq5-Q9njGzmxv3EcSIerlOg1TtLsJN
	Q9njGzmxv3EcSIerlOg1TtLsJN, QQf5q4P32yDEGoZR1jrJaeiwvHMg = Q9njGzmxv3EcSIerlOg1TtLsJN % kdRO82AImh0LFw(u"࠸࠵࠷ᙝ"), QQf5q4P32yDEGoZR1jrJaeiwvHMg % kdRO82AImh0LFw(u"࠸࠵࠷ᙝ")
	while etCBPOrRGyElupiFjmK4 < len(KnEazvPsXD8IGpThxi96Lfb):
		ddr4xmUqYe = JlBORrQXFED[pzGCWsqnyrQwgFRXku2Jf4b%len(JlBORrQXFED)]
		KDCdHQmgxPE21tYz4VUowSv = KnEazvPsXD8IGpThxi96Lfb[etCBPOrRGyElupiFjmK4 : etCBPOrRGyElupiFjmK4 + ddr4xmUqYe]
		U2vri4t3a8S += [(ord(Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE)^Q9njGzmxv3EcSIerlOg1TtLsJN)^QQf5q4P32yDEGoZR1jrJaeiwvHMg for Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE in KDCdHQmgxPE21tYz4VUowSv][::-wnaWTQM7VJPkZzO9eoSyFU4]
		etCBPOrRGyElupiFjmK4 += ddr4xmUqYe
		pzGCWsqnyrQwgFRXku2Jf4b += wnaWTQM7VJPkZzO9eoSyFU4
	yrSzYui79p = chr if rJ2oTLqabRtA else unichr
	KnEazvPsXD8IGpThxi96Lfb = A41nqbj3wYt(u"࠭ࠧᕯ").join([yrSzYui79p(Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE) for Ou6iKQl0LpUx1Tk29JPYyXztrAfHdE in U2vri4t3a8S])
	return KnEazvPsXD8IGpThxi96Lfb
def tyLbxATjI4GivOnUHcu(KnEazvPsXD8IGpThxi96Lfb,Eg1NDhXFYq2nzik43QBfm,ksJGmaSlYyx8evjUdHXhWnK=j0jEZgiKdxFpMLHcU7kQr8v1lyX4):
	if wnaWTQM7VJPkZzO9eoSyFU4:
		if isinstance(KnEazvPsXD8IGpThxi96Lfb, bytes): KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.decode(gPE1XB87fQl(u"ࠧࡶࡶࡩ࠼ࠬᕰ"))
		xhJgVN5eMBkqLmut = x54xSdnCFHZ8yliofzOBK.time()+ksJGmaSlYyx8evjUdHXhWnK if ksJGmaSlYyx8evjUdHXhWnK>j0jEZgiKdxFpMLHcU7kQr8v1lyX4 else x54xSdnCFHZ8yliofzOBK.time()
		KnEazvPsXD8IGpThxi96Lfb = yobpaW7sBqtKRrv(u"ࡶࠤࡾࢁࢁࢂࡼࡼࡿࠥᕱ").format(int(xhJgVN5eMBkqLmut), KnEazvPsXD8IGpThxi96Lfb)
		KnEazvPsXD8IGpThxi96Lfb = Upkelw1OStZ5Vg426sAGjxmThoFW(KnEazvPsXD8IGpThxi96Lfb, Eg1NDhXFYq2nzik43QBfm)
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.encode(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡸࡸ࡫࠾ࠧᕲ"))
		KnEazvPsXD8IGpThxi96Lfb = eSQGo07L2IFWJRKYwV8s.compress(KnEazvPsXD8IGpThxi96Lfb)
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.decode(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᕳ"))
		KnEazvPsXD8IGpThxi96Lfb = fu7azBkFI9cEmv0gbsiSlq4MO5h(KnEazvPsXD8IGpThxi96Lfb, Eg1NDhXFYq2nzik43QBfm, VP70ytiFNMBl6vHDaW(u"ࡆࡢ࡮ࡶࡩᙞ"))
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.encode(A41nqbj3wYt(u"ࠫࡺࡺࡦ࠹ࠩᕴ"))
	return KnEazvPsXD8IGpThxi96Lfb
def FouSVWLdMTJgX(KnEazvPsXD8IGpThxi96Lfb,Eg1NDhXFYq2nzik43QBfm,ksJGmaSlYyx8evjUdHXhWnK=j0jEZgiKdxFpMLHcU7kQr8v1lyX4):
	A1njWC4ayFpYRi7S = Z9FPQvwlbjLTh(u"ࠬࡌࡁࡊࡎࡈࡈࠬᕵ")
	if wnaWTQM7VJPkZzO9eoSyFU4:
		if isinstance(KnEazvPsXD8IGpThxi96Lfb, bytes): KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.decode(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡵࡵࡨ࠻ࠫᕶ"))
		KnEazvPsXD8IGpThxi96Lfb = fu7azBkFI9cEmv0gbsiSlq4MO5h(KnEazvPsXD8IGpThxi96Lfb, Eg1NDhXFYq2nzik43QBfm, SI7eBdND4lx8pt5Qk(u"ࡕࡴࡸࡩᙟ"))
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.encode(SI7eBdND4lx8pt5Qk(u"ࠧ࡭ࡣࡷ࡭ࡳ࠷ࠧᕷ"))
		KnEazvPsXD8IGpThxi96Lfb = eSQGo07L2IFWJRKYwV8s.decompress(KnEazvPsXD8IGpThxi96Lfb)
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.decode(YYQS36fyPvtuzcEmRL(u"ࠨࡷࡷࡪ࠽࠭ᕸ"))
		KnEazvPsXD8IGpThxi96Lfb = Upkelw1OStZ5Vg426sAGjxmThoFW(KnEazvPsXD8IGpThxi96Lfb, Eg1NDhXFYq2nzik43QBfm)
		xhJgVN5eMBkqLmut, KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.split(A41nqbj3wYt(u"ࠩࡿࢀࢁ࠭ᕹ"), wnaWTQM7VJPkZzO9eoSyFU4)
		A1njWC4ayFpYRi7S = SI7eBdND4lx8pt5Qk(u"ࠪࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ᕺ")
		if ksJGmaSlYyx8evjUdHXhWnK>j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			L1BysWJFlnk9KCUM = x54xSdnCFHZ8yliofzOBK.time()-int(xhJgVN5eMBkqLmut)
			if abs(L1BysWJFlnk9KCUM)>ksJGmaSlYyx8evjUdHXhWnK: A1njWC4ayFpYRi7S = CyHU86ZeYT5BWRcitSm2I(u"ࠫࡎࡔࡖࡂࡎࡌࡈࡤ࡚ࡉࡎࡇࡖࡘࡆࡓࡐࠨᕻ")
		KnEazvPsXD8IGpThxi96Lfb = KnEazvPsXD8IGpThxi96Lfb.encode(A6iX18qgyOFlZxz7sc(u"ࠬࡻࡴࡧ࠺ࠪᕼ"))
	return KnEazvPsXD8IGpThxi96Lfb,A1njWC4ayFpYRi7S
from j6urgzFAt4 import *