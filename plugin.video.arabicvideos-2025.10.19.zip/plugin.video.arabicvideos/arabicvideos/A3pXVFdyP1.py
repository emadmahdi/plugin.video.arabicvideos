# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from QYRIiVKnlr import *
SITESURLS = {
			 VP70ytiFNMBl6vHDaW(u"ࠬࡇࡈࡘࡃࡎࠫே")		:[Z9FPQvwlbjLTh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨை")]
			,pp7FcjEe6g(u"ࠧࡂࡍࡒࡅࡒ࠭௉")		:[IMjqygdfYSKpHlWu5Aa(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬொ")]
			,iySORMYxWXszEH18(u"ࠩࡄࡏ࡜ࡇࡍࠨோ")		:[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸࠪௌ")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋ்ࠧ")	:[gPE1XB87fQl(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡯ࡼࡧ࡭࠯ࡶࡸࡦࡪ࠭௎")]
			,GHg28TBchiyn6l(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ௏")		:[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭ௐ")]
			,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩ௑")		:[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮ࡰࡷࡹࡨࡡ࠯ࡶࡹࠫ௒")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ௓")		:[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡪ࡯ࡨࡾ࡮ࡪ࠮ࡴࡪࡲࡻࠬ௔")]
			,VP70ytiFNMBl6vHDaW(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ௕")	:[ZLr5gRSkFewKdUos90bM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭௖")]
			,A41nqbj3wYt(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩௗ")		:[wwWzyF4ZpSQXKOgk569(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ௘")]
			,ZLr5gRSkFewKdUos90bM(u"ࠩࡄ࡝ࡑࡕࡌࠨ௙")		:[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫࠮ࡢࡻ࡯ࡳࡱ࠴࡮ࡦࡶࠪ௚")]
			,Z9FPQvwlbjLTh(u"ࠫࡇࡕࡋࡓࡃࠪ௛")		:[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩࡲࡩࡷࡧ࠱ࡧࡴ࠭௜")]
			,kdRO82AImh0LFw(u"࠭ࡂࡓࡕࡗࡉࡏ࠭௝")		:[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ௞")]
			,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ௟")		:[ZLr5gRSkFewKdUos90bM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ௠")]
			,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪ௡")		:[VP70ytiFNMBl6vHDaW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡤ࡫ࡰࡥ࠹ࡶ࠮ࡤࡱࡰࠫ௢")]
			,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ௣")		:[bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬ௤")]
			,kdRO82AImh0LFw(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ௥")		:[wwWzyF4ZpSQXKOgk569(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡱ࠳ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ௦")]
			,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ௧")		:[A41nqbj3wYt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯ࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡤ࡮ࡸࡦࠬ௨")]
			,YYQS36fyPvtuzcEmRL(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ௩")	:[tzZ6PhyDOUnwLM3pdK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡷࡸ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹࡨࡰࡲࠪ௪")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ௫")		:[A41nqbj3wYt(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࠪ௬")]
			,bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ௭")		:[GHg28TBchiyn6l(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨ௮")]
			,pp7FcjEe6g(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௯")	:[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪ௰")]
			,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭௱")		:[jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫ௲")]
			,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ௳")		:[VP70ytiFNMBl6vHDaW(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡽࡨ࡯࡭ࡢ࠰ࡦࡧࠬ௴")]
			,Z9FPQvwlbjLTh(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ௵")	:[Z9FPQvwlbjLTh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ௶"),SI7eBdND4lx8pt5Qk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ௷"),IMjqygdfYSKpHlWu5Aa(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡣࡵࡧ࡭࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ௸")]
			,bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩ௹")	:[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠹࠳ࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨ௺")]
			,pp7FcjEe6g(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ௻")		:[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡨࡷࡧ࡭ࡢࡵ࠺࠲ࡳ࡫ࡴࠨ௼")]
			,rVy3Ops0mohYkT(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ௽")		:[beV5l2D8HznyJI0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡦࡶࡰࠪ௾")]
			,gPE1XB87fQl(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ௿")		:[rVy3Ops0mohYkT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽ࠳ࡨࡥࡴࡶࠪఀ")]
			,kdRO82AImh0LFw(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩఁ")		:[tzZ6PhyDOUnwLM3pdK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨం")]
			,VP70ytiFNMBl6vHDaW(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫః")		:[SI7eBdND4lx8pt5Qk(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪఄ")]
			,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬఅ")		:[ZLr5gRSkFewKdUos90bM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬఆ")]
			,wwWzyF4ZpSQXKOgk569(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨఇ")		:[kdRO82AImh0LFw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧఈ")]
			,YYQS36fyPvtuzcEmRL(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫఉ")	:[jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠱ࡩࡱ࡯ࡦ࠯ࡰࡨࡻࡸ࠭ఊ")]
			,IMjqygdfYSKpHlWu5Aa(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫఋ")		:[yobpaW7sBqtKRrv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩఌ")]
			,wwWzyF4ZpSQXKOgk569(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ఍")	:[A6iX18qgyOFlZxz7sc(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫఎ")]
			,IMjqygdfYSKpHlWu5Aa(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨఏ")		:[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡵ࠴ࡦࡢࡴࡨࡷࡰࡵ࠮࡯ࡧࡷࠫఐ")]
			,beV5l2D8HznyJI0(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ఑")		:[yobpaW7sBqtKRrv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩఒ")]
			,iySORMYxWXszEH18(u"ࠫࡋࡕࡓࡕࡃࠪఓ")		:[IMjqygdfYSKpHlWu5Aa(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩఔ")]
			,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧక")		:[GHg28TBchiyn6l(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࠱ࡥࡱࡳࡥࡴࡪ࡮ࡥ࡭࠴࡮ࡦࡶࠪఖ")]
			,ZLr5gRSkFewKdUos90bM(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪగ")		:[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦ࠳࡬ࡵࡴࡪࡤࡶ࠲ࡺࡶ࠯ࡥࡲࡱࠬఘ")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨఙ")	:[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡧࡷࡶ࡬ࡦࡸ࠮ࡷ࡫ࡧࡩࡴ࠭చ")]
			,beV5l2D8HznyJI0(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧఛ")		:[GHg28TBchiyn6l(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡩࡣ࡯ࡥࡨ࡯࡭ࡢ࠰ࡰࡩࡩ࡯ࡡࠨజ")]
			,mq5t9JXSdHT8yfDVF(u"ࠧࡊࡈࡌࡐࡒ࠭ఝ")		:[IMjqygdfYSKpHlWu5Aa(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩఞ"),oiWNFYzcIUeh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪట"),mq5t9JXSdHT8yfDVF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫఠ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠳࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭డ"),wwWzyF4ZpSQXKOgk569(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠿࠳࠯࠳࠼࠴࠳࠸࠴࠯࠳࠵࠶ࠬఢ")]
			,yobpaW7sBqtKRrv(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩణ")	:[rVy3Ops0mohYkT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡤࡶࡧࡧ࡬ࡢ࠯ࡷࡺ࠳࡯ࡱࠨత")]
			,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪథ")		:[gPE1XB87fQl(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡺ࡫ࡰࡶ࠱ࡧࡦࡳࠧద")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫధ")		:[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡵ࠯࡭࡬ࡶࡲࡧ࡬࡬࠰ࡦࡳࡲ࠭న")]
			,YYQS36fyPvtuzcEmRL(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ఩")		:[ZLr5gRSkFewKdUos90bM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡣࡵࡳࡿࡧ࠮ࡪࡰ࡮ࠫప")]
			,jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨఫ")		:[mq5t9JXSdHT8yfDVF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡰ࡮ࡴ࡫ࠨబ")]
			,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬభ")	:[mq5t9JXSdHT8yfDVF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮࡮ࡣࡶࡥ࠳ࡴࡥࡸࡵࠪమ")]
			,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡕࡇࡎࡆࡖࠪయ")		:[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧర")]
			,ZLr5gRSkFewKdUos90bM(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨఱ")		:[SI7eBdND4lx8pt5Qk(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫࠲ࡩࡲࡧࡤࡠࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡰ࡮ࡧ࠳࡮ࡴࡤࡦࡺ࠱࡬ࡹࡳ࡬ࠨల")]
			,beV5l2D8HznyJI0(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬళ")	:[wwWzyF4ZpSQXKOgk569(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦ࠴ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧ࠱ࡧࡦࡳࠧఴ")]
			,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬవ")		:[ZLr5gRSkFewKdUos90bM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹࠺ࡵ࠯ࡦࡤࡽࠬశ")]
			,IMjqygdfYSKpHlWu5Aa(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠲ࠨష")	:[rVy3Ops0mohYkT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰ࡩࡳࡷࡻ࡭ࠨస")]
			,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫహ")	:[tzZ6PhyDOUnwLM3pdK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧ఺")]
			,Z9FPQvwlbjLTh(u"ࠩࡖࡌࡔࡌࡈࡂࠩ఻")		:[wwWzyF4ZpSQXKOgk569(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼ఼ࠧ")]
			,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ఽ")		:[yobpaW7sBqtKRrv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬా"),YYQS36fyPvtuzcEmRL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ి"),A41nqbj3wYt(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪీ")]
			,tzZ6PhyDOUnwLM3pdK(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪు")		:[beV5l2D8HznyJI0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡳࡩࡱࡲࡪࡳ࡫ࡴ࠯ࡱࡱࡰ࡮ࡴࡥࠨూ")]
			,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡘࡎࡑࡁࡂࡖࠪృ")		:[I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡬ࡣࡤࡸ࠳ࡴࡥࡵࠩౄ")]
			,YYQS36fyPvtuzcEmRL(u"࡚ࠬࡖࡇࡗࡑࠫ౅")		:[A41nqbj3wYt(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫె")]
			,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡗࡃࡕࡆࡔࡔࠧే")		:[pp7FcjEe6g(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰ࠲ࡻࡧࡲࡣࡱࡱ࠲ࡨࡧ࡭ࠨై")]
			,ZLr5gRSkFewKdUos90bM(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭౉")	:[yobpaW7sBqtKRrv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡲࡸࡧࡥ࡮࠰ࡱࡩࡹ࠭ొ")]
			,kdRO82AImh0LFw(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬో")		:[gPE1XB87fQl(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡳࡩࡱࡺࠫౌ")]
			,GHg28TBchiyn6l(u"࠭ࡗࡆࡅࡌࡑࡆ࠸్ࠧ")		:[GHg28TBchiyn6l(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡥ࡯࡭ࡨࡱࠧ౎")]
			,KLX7hW0nBAEgy6m4SvH(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ౏")		:[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ౐")]
			,pp7FcjEe6g(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ౑")		:[oiWNFYzcIUeh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ౒")]
			,KLX7hW0nBAEgy6m4SvH(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ౓")	:[CyHU86ZeYT5BWRcitSm2I(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩ౔")]
			,GHg28TBchiyn6l(u"ࠧࡊࡒࡗౕ࡚ࠬ")			:[WnNGfosHr5STAq8j7miwyRZ6eOUbV]
			,gPE1XB87fQl(u"ࠨࡏ࠶ౖ࡙ࠬ")			:[WnNGfosHr5STAq8j7miwyRZ6eOUbV]
			,IMjqygdfYSKpHlWu5Aa(u"ࠩࡕࡉࡕࡕࡓࠨ౗")		:[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪౘ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨౙ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩౚ")]
			,pp7FcjEe6g(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪ౛")	:[A6iX18qgyOFlZxz7sc(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ౜"),A6iX18qgyOFlZxz7sc(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩౝ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ౞")]
			,IMjqygdfYSKpHlWu5Aa(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧ౟")	:[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩౠ"),pp7FcjEe6g(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧౡ"),tzZ6PhyDOUnwLM3pdK(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨౢ")]
			,wwWzyF4ZpSQXKOgk569(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫౣ")	:[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ౤"),mq5t9JXSdHT8yfDVF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ౥"),A6iX18qgyOFlZxz7sc(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ౦")]
			,gPE1XB87fQl(u"ࠫࡐࡕࡄࡊࡡࡖࡓ࡚ࡘࡃࡆࡕࠪ౧")	:[CyHU86ZeYT5BWRcitSm2I(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯ࠧ౨"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡱ࡯ࡥ࡫ࠪ౩"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭౪")]
			,IMjqygdfYSKpHlWu5Aa(u"ࠨࡈࡌࡐࡊ࡙࡟ࡔࡑࡘࡖࡈࡋࡓࠨ౫"):[Z9FPQvwlbjLTh(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱࠩ౬")]
			,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ౭")	:[VP70ytiFNMBl6vHDaW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ౮"),beV5l2D8HznyJI0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࠯ࡨࡺࡷ࠳ࡹࡴࡰࡴࡨࠫ౯")]
			}
if wnaWTQM7VJPkZzO9eoSyFU4:
	SITESURLS[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭౰")]      = [bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ౱"),wwWzyF4ZpSQXKOgk569(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭౲"),yobpaW7sBqtKRrv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ౳"),kdRO82AImh0LFw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ౴"),bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ౵"),wwWzyF4ZpSQXKOgk569(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ౶"),oiWNFYzcIUeh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ౷"),beV5l2D8HznyJI0(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ౸"),ZLr5gRSkFewKdUos90bM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ౹"),A6iX18qgyOFlZxz7sc(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ౺"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭౻"),yobpaW7sBqtKRrv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡺࡱࡸࡸࡺࡨࡥ࡯ࡵ࡬࡫ࠬ౼")]
	SITESURLS[bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪ౽")] = [lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ౾"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ౿"),mq5t9JXSdHT8yfDVF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ಀ"),Z9FPQvwlbjLTh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩಁ"),A41nqbj3wYt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩಂ"),yobpaW7sBqtKRrv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬಃ"),VP70ytiFNMBl6vHDaW(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ಄"),YYQS36fyPvtuzcEmRL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩಅ"),A41nqbj3wYt(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪಆ"),SI7eBdND4lx8pt5Qk(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨಇ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧಈ"),IMjqygdfYSKpHlWu5Aa(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭ಉ")]
	SITESURLS[ZLr5gRSkFewKdUos90bM(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩಊ")] = [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨಋ"),ZLr5gRSkFewKdUos90bM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬಌ"),yobpaW7sBqtKRrv(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ಍"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧಎ"),A41nqbj3wYt(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧಏ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪಐ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭಑"),tzZ6PhyDOUnwLM3pdK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧಒ"),CyHU86ZeYT5BWRcitSm2I(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨಓ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ಔ"),kdRO82AImh0LFw(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬಕ"),GHg28TBchiyn6l(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡹࡰࡷࡷࡹࡧ࡫࡮ࡴ࡫ࡪࠫಖ")]
	SITESURLS[n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨಗ")] = [bawK2j7T81Nrc4GWs05xzDg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪಘ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧಙ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ಚ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩಛ"),gPE1XB87fQl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩಜ"),iySORMYxWXszEH18(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬಝ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨಞ"),YYQS36fyPvtuzcEmRL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩಟ"),iySORMYxWXszEH18(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪಠ"),CyHU86ZeYT5BWRcitSm2I(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨಡ"),Z9FPQvwlbjLTh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧಢ"),wwWzyF4ZpSQXKOgk569(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭ಣ")]
else:
	SITESURLS[SI7eBdND4lx8pt5Qk(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩತ")]      = [bawK2j7T81Nrc4GWs05xzDg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ಥ"),Z9FPQvwlbjLTh(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪದ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩಧ"),gPE1XB87fQl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬನ"),ZLr5gRSkFewKdUos90bM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ಩"),GHg28TBchiyn6l(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨಪ"),ZLr5gRSkFewKdUos90bM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫಫ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬಬ"),oiWNFYzcIUeh(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ಭ"),tzZ6PhyDOUnwLM3pdK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫಮ"),rVy3Ops0mohYkT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪಯ"),oiWNFYzcIUeh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡾࡵࡵࡵࡷࡥࡩࡳࡹࡩࡨࠩರ")]
	SITESURLS[A6iX18qgyOFlZxz7sc(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭ಱ")] = [A6iX18qgyOFlZxz7sc(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬಲ"),VP70ytiFNMBl6vHDaW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩಳ"),YYQS36fyPvtuzcEmRL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ಴"),tzZ6PhyDOUnwLM3pdK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫವ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫಶ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧಷ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪಸ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫಹ"),SI7eBdND4lx8pt5Qk(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ಺"),gPE1XB87fQl(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ಻"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴ಼ࠩ"),GHg28TBchiyn6l(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡽࡴࡻࡴࡶࡤࡨࡲࡸ࡯ࡧࠨಽ")]
	SITESURLS[KLX7hW0nBAEgy6m4SvH(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬಾ")] = [gPE1XB87fQl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫಿ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨೀ"),Z9FPQvwlbjLTh(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧು"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪೂ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪೃ"),wwWzyF4ZpSQXKOgk569(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ೄ"),gPE1XB87fQl(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ೅"),gPE1XB87fQl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪೆ"),YYQS36fyPvtuzcEmRL(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫೇ"),iySORMYxWXszEH18(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩೈ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ೉"),kdRO82AImh0LFw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡼࡳࡺࡺࡵࡣࡧࡱࡷ࡮࡭ࠧೊ")]
	SITESURLS[ZLr5gRSkFewKdUos90bM(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫೋ")] = [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪೌ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺ್ࠧ"),YYQS36fyPvtuzcEmRL(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭೎"),GHg28TBchiyn6l(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ೏"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ೐"),kdRO82AImh0LFw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ೑"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ೒"),ZLr5gRSkFewKdUos90bM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ೓"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ೔"),rVy3Ops0mohYkT(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨೕ"),SI7eBdND4lx8pt5Qk(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧೖ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭೗")]
api_python_actions = [ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ೘"),yobpaW7sBqtKRrv(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ೙"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ೚"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ೛"),pp7FcjEe6g(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ೜"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ೝ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩೞ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭೟"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧೠ"),Z9FPQvwlbjLTh(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩೡ"),YYQS36fyPvtuzcEmRL(u"ࠨࡇ࡛ࡉࡈ࡛ࡔࡆࡌࡖࠫೢ"),VP70ytiFNMBl6vHDaW(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࡑࡗࡎࡍࠧೣ")]
api_repos_actions = [tzZ6PhyDOUnwLM3pdK(u"ࠪࡅࡉࡊࡏࡏࡕࠪ೤"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭೥"),SI7eBdND4lx8pt5Qk(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ೦")]
non_videos_actions = [GHg28TBchiyn6l(u"࠭ࡁࡍࡎࠪ೧"),IMjqygdfYSKpHlWu5Aa(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ೨"),KLX7hW0nBAEgy6m4SvH(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ೩"),KLX7hW0nBAEgy6m4SvH(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭೪"),gPE1XB87fQl(u"ࠪࡖࡊࡖࡏࡔࠩ೫"),A41nqbj3wYt(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧ೬"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨ೭"),SI7eBdND4lx8pt5Qk(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬ೮"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡈࡇࡗࡍࡉ࠭೯"),wwWzyF4ZpSQXKOgk569(u"ࠨࡕࡌࡘࡊ࡙ࡕࡓࡎࡖࠫ೰")]+api_python_actions+api_repos_actions
IMAvyqd5QL60a = KiryBCvngZzF85UN6xSDlOVweL4I9
IImTyNn2dP = r0D4C3z7Onqpa
bWV7czPeIaq = KiryBCvngZzF85UN6xSDlOVweL4I9
vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI = KiryBCvngZzF85UN6xSDlOVweL4I9
avprivsnorestrict = KiryBCvngZzF85UN6xSDlOVweL4I9
avprivslongperiod = KiryBCvngZzF85UN6xSDlOVweL4I9
resolveonly = KiryBCvngZzF85UN6xSDlOVweL4I9
X0Xk5yAVJPfd = KiryBCvngZzF85UN6xSDlOVweL4I9
ALLOW_DNS_FIX = OHohTgj06taKzsG
ALLOW_PROXY_FIX = OHohTgj06taKzsG
ALLOW_SHOWDIALOGS_FIX = OHohTgj06taKzsG
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [oiWNFYzcIUeh(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫೱ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ೲ"),mq5t9JXSdHT8yfDVF(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬೳ"),wwWzyF4ZpSQXKOgk569(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ೴"),VP70ytiFNMBl6vHDaW(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭೵"),A41nqbj3wYt(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ೶"),Z9FPQvwlbjLTh(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ೷"),pp7FcjEe6g(u"࡙ࠩࡅࡗࡈࡏࡏࠩ೸"),rVy3Ops0mohYkT(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ೹"),VP70ytiFNMBl6vHDaW(u"ࠫࡕࡇࡎࡆࡖࠪ೺"),YYQS36fyPvtuzcEmRL(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ೻")]
BADWEBSITES += [ZLr5gRSkFewKdUos90bM(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ೼")]
BADCOMMONIDS = [KLX7hW0nBAEgy6m4SvH(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫ೽"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬ೾")]
GEOLOCATION_DATA = WnNGfosHr5STAq8j7miwyRZ6eOUbV
AV_CLIENT_IDS = WnNGfosHr5STAq8j7miwyRZ6eOUbV
DNS_SERVERS = [tzZ6PhyDOUnwLM3pdK(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ೿"),VP70ytiFNMBl6vHDaW(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫഀ"),beV5l2D8HznyJI0(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬഁ"),SI7eBdND4lx8pt5Qk(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ം"),GHg28TBchiyn6l(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧഃ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨഄ")]
busydialog_active = KiryBCvngZzF85UN6xSDlOVweL4I9
dns_succeeded_urls = []