# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
import xbmc as pYDdXfVh5c0O1bMT6a78HKBiQw3,re as p7dwlH1PRStBgyMUW,sys as SZ0YL6RpbX,xbmcaddon as EipS2x5YfXdk96whaUNj,random as FxEWL1w4gjr8mM,os as pNk4HfLdMBRYEQAzjyT0qaoe8cDPt,xbmcvfs as zdlKPScakxtwGuqZVAD8TmpW6Re,time as x54xSdnCFHZ8yliofzOBK,pickle as jKM9ThPInf4,zlib as eSQGo07L2IFWJRKYwV8s,xbmcgui as Zilvh2WQyb5,xbmcplugin as Ydimlc1rVsAnLIhkRyb6aK2,sqlite3 as x0p6hU1tkV4oBXnm2SDsNPlY7,traceback as YoBT71zcqe6RGIP,threading as IWpE1hYkGCBeH,hashlib as xxiJ2wLnUdPYeGXNz18ECc,json as qJRG1u4fHXAkF5PsEaBMWUDVtKij2z
from QYRIiVKnlr import *
import A3pXVFdyP1
NTWE764hmOgUtScp2e8r = tzZ6PhyDOUnwLM3pdK(u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩഅ")
gH9Y3QcFUL = EipS2x5YfXdk96whaUNj.Addon().getAddonInfo(mq5t9JXSdHT8yfDVF(u"ࠩࡳࡥࡹ࡮ࠧആ"))
AEXZPJSkOF = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,CyHU86ZeYT5BWRcitSm2I(u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬഇ"))
SZ0YL6RpbX.path.append(AEXZPJSkOF)
zmvCUWkdDfrHhoucgFX7T0JGipS = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(A6iX18qgyOFlZxz7sc(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥഈ"))
CCPXJ7wnNLOg0ZoekcmpdSKI = p7dwlH1PRStBgyMUW.findall(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩഉ"),zmvCUWkdDfrHhoucgFX7T0JGipS,p7dwlH1PRStBgyMUW.DOTALL)
CCPXJ7wnNLOg0ZoekcmpdSKI = float(CCPXJ7wnNLOg0ZoekcmpdSKI[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
hN0aOLCMy87IondiZUl46w2SxVm = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player
NNSs1CeqntdLV8YD3 = Zilvh2WQyb5.WindowXMLDialog
YVzokG2yZqrh3w8bU = CCPXJ7wnNLOg0ZoekcmpdSKI<mq5t9JXSdHT8yfDVF(u"࠷࠹༂")
rJ2oTLqabRtA = CCPXJ7wnNLOg0ZoekcmpdSKI>ZLr5gRSkFewKdUos90bM(u"࠱࠹࠰࠼࠽༃")
if rJ2oTLqabRtA:
	ONKoA9BL4tW5UX = zdlKPScakxtwGuqZVAD8TmpW6Re.translatePath(tzZ6PhyDOUnwLM3pdK(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧഊ"))
	llmE4WI7FsT6 = pYDdXfVh5c0O1bMT6a78HKBiQw3.LOGINFO
	w1gu8bCmYAvdjf5a,jedSoT7D2Qu = oiWNFYzcIUeh(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨഋ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩഌ")
	eb8JPNOXL5oUCm3T = zdlKPScakxtwGuqZVAD8TmpW6Re.translatePath(IMjqygdfYSKpHlWu5Aa(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ഍"))
	from urllib.parse import unquote as _d8Z9G4bYfVnOpBH
	BeAmoNljUgrbc = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫഎ")
else:
	ONKoA9BL4tW5UX = pYDdXfVh5c0O1bMT6a78HKBiQw3.translatePath(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬഏ"))
	llmE4WI7FsT6 = pYDdXfVh5c0O1bMT6a78HKBiQw3.LOGNOTICE
	w1gu8bCmYAvdjf5a,jedSoT7D2Qu = tzZ6PhyDOUnwLM3pdK(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ഐ").encode(e87cIA5vwOQLDEP1),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ഑").encode(e87cIA5vwOQLDEP1)
	eb8JPNOXL5oUCm3T = pYDdXfVh5c0O1bMT6a78HKBiQw3.translatePath(GHg28TBchiyn6l(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨഒ"))
	from urllib import unquote as _d8Z9G4bYfVnOpBH
	BeAmoNljUgrbc = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩഓ").encode(e87cIA5vwOQLDEP1)
B40Qr5hlSgNm1kuXD3ZFpnyC9 = SZ0YL6RpbX.argv[j0jEZgiKdxFpMLHcU7kQr8v1lyX4].split(IMjqygdfYSKpHlWu5Aa(u"ࠩ࠲ࠫഔ"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
ZTaSobILWiO9ywfN64AVQPzUgKGHX = int(SZ0YL6RpbX.argv[wnaWTQM7VJPkZzO9eoSyFU4])
oobgjl3xWaBeRZF8wdzKYAvtus = SZ0YL6RpbX.argv[XURrDCfOS9Mbhpv2Pmjos56TeW]
ff6apRhzGgdsL7DjOkxPeHX0iKI = B40Qr5hlSgNm1kuXD3ZFpnyC9.split(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࠲ࠬക"))[XURrDCfOS9Mbhpv2Pmjos56TeW]
mbvW9By35UDO = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫഖ")+B40Qr5hlSgNm1kuXD3ZFpnyC9+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬ࠯ࠧഗ"))
kcCgDi2EzhU5s413pAjSmu = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(eb8JPNOXL5oUCm3T,B40Qr5hlSgNm1kuXD3ZFpnyC9)
Hp7qgMcFCX46nO8Poy = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡩ࡮ࡣࡪࡩࡸ࠭ഘ"))
TWoHRjiOcsKk70dDJu = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(Hp7qgMcFCX46nO8Poy,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠧങ"))
vOSz3VgtMsuNG6e = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(Hp7qgMcFCX46nO8Poy,KLX7hW0nBAEgy6m4SvH(u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩച"))
xx02M7uVUbkgIQpaA4fdYsGjhZNOJn = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(vOSz3VgtMsuNG6e,SI7eBdND4lx8pt5Qk(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬഛ"))
VD2saKIdfOmxJr0 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(ONKoA9BL4tW5UX,A6iX18qgyOFlZxz7sc(u"ࠪࡱࡪࡪࡩࡢࠩജ"),tzZ6PhyDOUnwLM3pdK(u"ࠫࡋࡵ࡮ࡵࡵࠪഝ"),yobpaW7sBqtKRrv(u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨഞ"))
p9DTgUZ1auwRYXoHld7v8MP = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,beV5l2D8HznyJI0(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫട"))
UUN4I9unSKWg7c3YizxEmq = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨഠ"))
gH9Y3QcFUL = EipS2x5YfXdk96whaUNj.Addon().getAddonInfo(IMjqygdfYSKpHlWu5Aa(u"ࠨࡲࡤࡸ࡭࠭ഡ"))
ucAYIptK5bJE0DQ742NxrBfqLea = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(gH9Y3QcFUL,gPE1XB87fQl(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩഢ"))
jDuxzCtBH7aihsSL9 = int(x54xSdnCFHZ8yliofzOBK.time())
G3yDpvxOiSWdAeL = EipS2x5YfXdk96whaUNj.Addon(id=B40Qr5hlSgNm1kuXD3ZFpnyC9)
Yit5dk8Qm9EKvUDzb3 = G3yDpvxOiSWdAeL.getSetting(gPE1XB87fQl(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧണ"))
dJ3lKeg21CuqpwSEhQYPmDV = KiryBCvngZzF85UN6xSDlOVweL4I9 if Yit5dk8Qm9EKvUDzb3==mbvW9By35UDO else r0D4C3z7Onqpa
def bJlfaY9rk80uXWZzV2oeNBcI(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,YzAtevgaKsZ0Vdbcr7xkw8E1S=tzZ6PhyDOUnwLM3pdK(u"ࠫࡄ࠭ത")):
	if ZLr5gRSkFewKdUos90bM(u"ࠬࡃࠧഥ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA:
		if YzAtevgaKsZ0Vdbcr7xkw8E1S in kdNn2Zqsj4wPi5ThuoUQvtcg6OA: vcQbFfCk6T1,ggaAofYDSVwQZrITu = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(YzAtevgaKsZ0Vdbcr7xkw8E1S,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠲༄"))
		else: vcQbFfCk6T1,ggaAofYDSVwQZrITu = WnNGfosHr5STAq8j7miwyRZ6eOUbV,kdNn2Zqsj4wPi5ThuoUQvtcg6OA
		ggaAofYDSVwQZrITu = ggaAofYDSVwQZrITu.split(bawK2j7T81Nrc4GWs05xzDg(u"࠭ࠦࠨദ"))
		bZ0VWjAHm1v2Csroh = {}
		for j6bRfeOqyTnQJA2ao4V in ggaAofYDSVwQZrITu:
			lGdZS2mFX1PfHEr7Lt8I,jSQ8Xqx9pBJIP5rCv2algzLb16 = j6bRfeOqyTnQJA2ao4V.split(iySORMYxWXszEH18(u"ࠧ࠾ࠩധ"),CyHU86ZeYT5BWRcitSm2I(u"࠳༅"))
			bZ0VWjAHm1v2Csroh[lGdZS2mFX1PfHEr7Lt8I] = jSQ8Xqx9pBJIP5rCv2algzLb16
	else: vcQbFfCk6T1,bZ0VWjAHm1v2Csroh = kdNn2Zqsj4wPi5ThuoUQvtcg6OA,{}
	return vcQbFfCk6T1,bZ0VWjAHm1v2Csroh
def Ye7QMduPDEiphaUy5R9OVSIgx(VkEQdztnmeH):
	YN0tzSo1uQ84rkv6hJHafyncbZ,OOG1iPYhTKQ4,qIePBQGovXUy = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	VkEQdztnmeH = VkEQdztnmeH.replace(w1gu8bCmYAvdjf5a,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(jedSoT7D2Qu,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall(VP70ytiFNMBl6vHDaW(u"ࠨࠪ࠱࠭ࡡࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇ࠲࠻ࡇ࠶ࡌ࡜࡞ࠪ࡟ࡻࡡࡽ࡜ࡸࠫࠣ࠯ࡡࡡ࡜࠰ࡅࡒࡐࡔࡘ࡜࡞ࠪ࠱࠮ࡄ࠯ࠤࠨന"),VkEQdztnmeH,p7dwlH1PRStBgyMUW.DOTALL)
	if TAQfygRC4WoHu37SEeZ: YN0tzSo1uQ84rkv6hJHafyncbZ,OOG1iPYhTKQ4,VkEQdztnmeH = TAQfygRC4WoHu37SEeZ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if YN0tzSo1uQ84rkv6hJHafyncbZ not in [kcXMWrwiLDKeBHRsJ,VP70ytiFNMBl6vHDaW(u"ࠩ࠯ࠫഩ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV]: qIePBQGovXUy = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡣࡒࡕࡄࡠࠩപ")
	if OOG1iPYhTKQ4: OOG1iPYhTKQ4 = ZLr5gRSkFewKdUos90bM(u"ࠫࡤ࠭ഫ")+OOG1iPYhTKQ4+KLX7hW0nBAEgy6m4SvH(u"ࠬࡥࠧബ")
	VkEQdztnmeH = OOG1iPYhTKQ4+qIePBQGovXUy+VkEQdztnmeH
	return VkEQdztnmeH
def EZk136aeLoNqPvlDcTQpyM9Wm(kdNn2Zqsj4wPi5ThuoUQvtcg6OA):
	return _d8Z9G4bYfVnOpBH(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
def UbF7JxE84r2D(AbpFsJixDS1NcvjmB):
	n9TwhZlFjtIEL8or04iaYBzse = {beV5l2D8HznyJI0(u"࠭ࡴࡺࡲࡨࠫഭ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠧ࡮ࡱࡧࡩࠬമ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡷࡵࡰࠬയ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠩࡷࡩࡽࡺࠧര"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡴࡦ࡭ࡥࠨറ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡳࡧ࡭ࡦࠩല"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"ࠬ࡯࡭ࡢࡩࡨࠫള"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧഴ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩവ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	if mq5t9JXSdHT8yfDVF(u"ࠨࡁࠪശ") in AbpFsJixDS1NcvjmB: AbpFsJixDS1NcvjmB = AbpFsJixDS1NcvjmB.split(IMjqygdfYSKpHlWu5Aa(u"ࠩࡂࠫഷ"),wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
	vcQbFfCk6T1,UPylZvFWQoszT = bJlfaY9rk80uXWZzV2oeNBcI(AbpFsJixDS1NcvjmB)
	aargs = dict(list(n9TwhZlFjtIEL8or04iaYBzse.items())+list(UPylZvFWQoszT.items()))
	NGRWqTjxYXQ5 = aargs[aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡱࡴࡪࡥࠨസ")]
	E2R07n4wK1cLe = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[wwWzyF4ZpSQXKOgk569(u"ࠫࡺࡸ࡬ࠨഹ")])
	LaSWb2NcDAvsPqFXzt0 = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡺࡥࡹࡶࠪഺ")])
	mmL9ru6M7zh80DTnkiyKNaB = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡰࡢࡩࡨ഻ࠫ")])
	Qd2P0tYnV3ghvsKr5oAkeypZuiO7 = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[GHg28TBchiyn6l(u"ࠧࡵࡻࡳࡩ഼ࠬ")])
	S7ihvJkRsdMoxYOwHFIb = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[kdRO82AImh0LFw(u"ࠨࡰࡤࡱࡪ࠭ഽ")])
	mbDFTyaWzQOcxA36 = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[wwWzyF4ZpSQXKOgk569(u"ࠩ࡬ࡱࡦ࡭ࡥࠨാ")])
	aEJOC7rUle4pnHqFMv = aargs[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫി")]
	OPIutC5iGTDax = EZk136aeLoNqPvlDcTQpyM9Wm(aargs[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ീ")])
	if OPIutC5iGTDax: OPIutC5iGTDax = eval(OPIutC5iGTDax)
	else: OPIutC5iGTDax = {}
	if not NGRWqTjxYXQ5: Qd2P0tYnV3ghvsKr5oAkeypZuiO7 = wwWzyF4ZpSQXKOgk569(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬു") ; NGRWqTjxYXQ5 = kdRO82AImh0LFw(u"࠭࠲࠷࠲ࠪൂ")
	return Qd2P0tYnV3ghvsKr5oAkeypZuiO7,S7ihvJkRsdMoxYOwHFIb,E2R07n4wK1cLe,NGRWqTjxYXQ5,mbDFTyaWzQOcxA36,mmL9ru6M7zh80DTnkiyKNaB,LaSWb2NcDAvsPqFXzt0,aEJOC7rUle4pnHqFMv,OPIutC5iGTDax
def q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r):
	ZX0n7m3jaFpyrf6lw = SZ0YL6RpbX._getframe(wnaWTQM7VJPkZzO9eoSyFU4).f_code.co_name
	if not NTWE764hmOgUtScp2e8r or not ZX0n7m3jaFpyrf6lw or ZX0n7m3jaFpyrf6lw==rVy3Ops0mohYkT(u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩൃ"):
		return VP70ytiFNMBl6vHDaW(u"ࠨ࡝ࠣࠫൄ")+ff6apRhzGgdsL7DjOkxPeHX0iKI.upper()+wwWzyF4ZpSQXKOgk569(u"ࠩࡢࠫ൅")+mbvW9By35UDO+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡣࠬെ")+str(CCPXJ7wnNLOg0ZoekcmpdSKI)+wwWzyF4ZpSQXKOgk569(u"ࠫࠥࡣࠧേ")
	return ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࠴࡜ࡵࠩൈ")+ZX0n7m3jaFpyrf6lw
def SWPHEjbmMfZDpi(ppiJdMSxHgPIwmo6WsuLEktqaRcDQ,Wab7p2BCHfVhE34Q9mUO=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not Wab7p2BCHfVhE34Q9mUO: ppiJdMSxHgPIwmo6WsuLEktqaRcDQ,Wab7p2BCHfVhE34Q9mUO = WnNGfosHr5STAq8j7miwyRZ6eOUbV,ppiJdMSxHgPIwmo6WsuLEktqaRcDQ
	Wab7p2BCHfVhE34Q9mUO = Wab7p2BCHfVhE34Q9mUO.replace(CyHU86ZeYT5BWRcitSm2I(u"࠭࡜ࡹ࠲࠳ࠫ൉"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if YVzokG2yZqrh3w8bU:
		try: Wab7p2BCHfVhE34Q9mUO = Wab7p2BCHfVhE34Q9mUO.decode(e87cIA5vwOQLDEP1,kdRO82AImh0LFw(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧൊ")).encode(e87cIA5vwOQLDEP1,iySORMYxWXszEH18(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨോ"))
		except: Wab7p2BCHfVhE34Q9mUO = Wab7p2BCHfVhE34Q9mUO.encode(e87cIA5vwOQLDEP1,oiWNFYzcIUeh(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩൌ"))
	wdqmLfigv9T = llmE4WI7FsT6
	bbiBPLGW5cmhv = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV]
	if ppiJdMSxHgPIwmo6WsuLEktqaRcDQ: Wab7p2BCHfVhE34Q9mUO = Wab7p2BCHfVhE34Q9mUO.replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(e6HEdvUcaq8Gx,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	else: ppiJdMSxHgPIwmo6WsuLEktqaRcDQ = nsQAcj8eJHEw3xZ
	QZGgFbmxahcN,YzAtevgaKsZ0Vdbcr7xkw8E1S = VP70ytiFNMBl6vHDaW(u"ࠪࡠࡹ്࠭"),jrD65cZUQ8uGR0IHNCkF
	Nzi5SIEcbo = beV5l2D8HznyJI0(u"࠸࠷༇")*kcXMWrwiLDKeBHRsJ if rJ2oTLqabRtA else wwWzyF4ZpSQXKOgk569(u"࠶࠵༆")*kcXMWrwiLDKeBHRsJ
	gm4Kn0VJtBx9sh2ucN5kYozH = yGLl1nSBrJPmi2adko9O*QZGgFbmxahcN
	if Wab7p2BCHfVhE34Q9mUO.startswith(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬൎ")): Wab7p2BCHfVhE34Q9mUO = GHg28TBchiyn6l(u"ࠬ࠴࡜ࡵࠩ൏")+Wab7p2BCHfVhE34Q9mUO
	if U3Us1pqh6TY in ppiJdMSxHgPIwmo6WsuLEktqaRcDQ: wdqmLfigv9T = pYDdXfVh5c0O1bMT6a78HKBiQw3.LOGERROR
	if ppiJdMSxHgPIwmo6WsuLEktqaRcDQ in [nsQAcj8eJHEw3xZ,U3Us1pqh6TY]: bbiBPLGW5cmhv = [Wab7p2BCHfVhE34Q9mUO]
	elif ppiJdMSxHgPIwmo6WsuLEktqaRcDQ==FK6PHeEpSvXsqt83WflBYQ: bbiBPLGW5cmhv = Wab7p2BCHfVhE34Q9mUO.split(YzAtevgaKsZ0Vdbcr7xkw8E1S)
	elif ppiJdMSxHgPIwmo6WsuLEktqaRcDQ==W2AGj9rwD0dviCE5Q7BtO:
		tKf5NLDXilz9MFGa3YJmUWwsu = Wab7p2BCHfVhE34Q9mUO.split(YzAtevgaKsZ0Vdbcr7xkw8E1S)
		bbiBPLGW5cmhv = [tKf5NLDXilz9MFGa3YJmUWwsu[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]]
		for VV60kArCYGvUWNOLymTJze in range(wnaWTQM7VJPkZzO9eoSyFU4,len(tKf5NLDXilz9MFGa3YJmUWwsu),XURrDCfOS9Mbhpv2Pmjos56TeW):
			try: VERL0P1Obl6jqTpa9YNXZgFUdwDBnv = tKf5NLDXilz9MFGa3YJmUWwsu[VV60kArCYGvUWNOLymTJze]+YzAtevgaKsZ0Vdbcr7xkw8E1S+tKf5NLDXilz9MFGa3YJmUWwsu[VV60kArCYGvUWNOLymTJze+wwWzyF4ZpSQXKOgk569(u"࠶༈")]
			except: VERL0P1Obl6jqTpa9YNXZgFUdwDBnv = tKf5NLDXilz9MFGa3YJmUWwsu[VV60kArCYGvUWNOLymTJze]
			bbiBPLGW5cmhv.append(VERL0P1Obl6jqTpa9YNXZgFUdwDBnv)
	f5VOz24ivsY6y = bbiBPLGW5cmhv[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	for KiLwOk7QoMdJT8y6mf2hYBn1ActHXS in bbiBPLGW5cmhv[wnaWTQM7VJPkZzO9eoSyFU4:]:
		if ppiJdMSxHgPIwmo6WsuLEktqaRcDQ in [FK6PHeEpSvXsqt83WflBYQ,W2AGj9rwD0dviCE5Q7BtO]: gm4Kn0VJtBx9sh2ucN5kYozH += QZGgFbmxahcN
		f5VOz24ivsY6y += TTLxlKI0gNfh7FP+Nzi5SIEcbo+gm4Kn0VJtBx9sh2ucN5kYozH+KiLwOk7QoMdJT8y6mf2hYBn1ActHXS
	if ppiJdMSxHgPIwmo6WsuLEktqaRcDQ in [U3Us1pqh6TY,FK6PHeEpSvXsqt83WflBYQ]: f5VOz24ivsY6y += WBDnh75CaLEvkcN6p4ez2KXrV3M
	f5VOz24ivsY6y += mq5t9JXSdHT8yfDVF(u"࠭ࠠࡠࠩ൐")
	if KLX7hW0nBAEgy6m4SvH(u"ࠧࠦࠩ൑") in f5VOz24ivsY6y: f5VOz24ivsY6y = EZk136aeLoNqPvlDcTQpyM9Wm(f5VOz24ivsY6y)
	pYDdXfVh5c0O1bMT6a78HKBiQw3.log(f5VOz24ivsY6y,level=wdqmLfigv9T)
	return
def LLsY0NuzAxWOf8Hj(nJQVgbyzTW):
	try: OoE5HYUMwsrDWhx2gR7I3FuN = x0p6hU1tkV4oBXnm2SDsNPlY7.connect(nJQVgbyzTW,check_same_thread=KiryBCvngZzF85UN6xSDlOVweL4I9)
	except:
		if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(kcCgDi2EzhU5s413pAjSmu):
			pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.makedirs(kcCgDi2EzhU5s413pAjSmu)
			OoE5HYUMwsrDWhx2gR7I3FuN = x0p6hU1tkV4oBXnm2SDsNPlY7.connect(nJQVgbyzTW,check_same_thread=KiryBCvngZzF85UN6xSDlOVweL4I9)
	OoE5HYUMwsrDWhx2gR7I3FuN.text_factory = str
	GSB3DNKz9vFbaEo8 = OoE5HYUMwsrDWhx2gR7I3FuN.cursor()
	GSB3DNKz9vFbaEo8.execute(pp7FcjEe6g(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡣ࡮ࡴࡤࡦࡺࡀࡲࡴࠦ࠻ࠨ൒"))
	GSB3DNKz9vFbaEo8.execute(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬࡫ࡳࡵࡲࡦࡡࡦ࡬ࡪࡩ࡫ࡠࡥࡲࡲࡸࡺࡲࡢ࡫ࡱࡸࡸࡃࡹࡦࡵࠣ࠿ࠬ൓"))
	GSB3DNKz9vFbaEo8.execute(CyHU86ZeYT5BWRcitSm2I(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡮ࡴࡻࡲ࡯ࡣ࡯ࡣࡲࡵࡤࡦ࠿ࡒࡊࡋࠦ࠻ࠨൔ"))
	GSB3DNKz9vFbaEo8.execute(SI7eBdND4lx8pt5Qk(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡸࡿ࡮ࡤࡪࡵࡳࡳࡵࡵࡴ࠿ࡒࡊࡋࠦ࠻ࠨൕ"))
	OoE5HYUMwsrDWhx2gR7I3FuN.commit()
	return OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8
def PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,x4NdXHYe8QkphgbAzZ,PPeNmpZRVU6yGrEidxb,DhMJrSCE2ZN5yF9VRb8B4AH3Uciv=()):
	n407uaQIPXEqUzwhLe8v3rSM6 = OHohTgj06taKzsG
	timeout = SI7eBdND4lx8pt5Qk(u"࠷࠰༉")
	yywmpF8z5X = x54xSdnCFHZ8yliofzOBK.time()
	import yBR5QHGdUT
	while x54xSdnCFHZ8yliofzOBK.time()-yywmpF8z5X<timeout:
		try:
			if x4NdXHYe8QkphgbAzZ: n407uaQIPXEqUzwhLe8v3rSM6 = GSB3DNKz9vFbaEo8.executemany(PPeNmpZRVU6yGrEidxb,DhMJrSCE2ZN5yF9VRb8B4AH3Uciv).fetchall()
			else: n407uaQIPXEqUzwhLe8v3rSM6 = GSB3DNKz9vFbaEo8.execute(PPeNmpZRVU6yGrEidxb,DhMJrSCE2ZN5yF9VRb8B4AH3Uciv).fetchall()
			break
		except Exception as qqYcVWkPsKdvbw7FljT6B4eZ93L:
			if GHg28TBchiyn6l(u"ࠬࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡪࡵࠣࡰࡴࡩ࡫ࡦࡦࠪൖ") not in str(qqYcVWkPsKdvbw7FljT6B4eZ93L): break
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,yobpaW7sBqtKRrv(u"࠭࠮࡝ࡶࡇࡥࡹࡧࡢࡢࡵࡨࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࠨൗ")+nJQVgbyzTW+GHg28TBchiyn6l(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡻ࡭࡫࡮ࠡࡧࡻࡩࡨࡻࡴࡪࡰࡪࠤࡹ࡮ࡩࡴࠢࡶࡸࡦࡺࡥ࡮ࡧࡱࡸࠥࠦࠠࠨ൘")+PPeNmpZRVU6yGrEidxb)
		OoE5HYUMwsrDWhx2gR7I3FuN.commit()
		x54xSdnCFHZ8yliofzOBK.sleep(yobpaW7sBqtKRrv(u"࠰࠯࠴࠸༊"))
	OoE5HYUMwsrDWhx2gR7I3FuN.commit()
	return n407uaQIPXEqUzwhLe8v3rSM6
def VolBUXWI42N1CF6RiKd(nJQVgbyzTW,OYsxCijpVEWowUIZLkJ9,jdQVwYOzMHSpbuJ56mLZCiDBv3,GHYZxqn6krEVy2PA=OHohTgj06taKzsG):
	N4HDrYcWePfI0yxjb2 = BN0jT2uzd7pJ5ak1FWPqHKE4UL(OYsxCijpVEWowUIZLkJ9)
	XgfsEHex8hCzQY7vFNTBrW = G3yDpvxOiSWdAeL.getSetting(KLX7hW0nBAEgy6m4SvH(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ൙"))
	if jdQVwYOzMHSpbuJ56mLZCiDBv3 not in [rVy3Ops0mohYkT(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ൚"),kdRO82AImh0LFw(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡆࡒࡌࠨ൛"),kdRO82AImh0LFw(u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡕࡒࡉࡕࡖࡈࡈࡤࡍࡏࡐࡉࡏࡉࠬ൜")] and nJQVgbyzTW==p9DTgUZ1auwRYXoHld7v8MP and GHYZxqn6krEVy2PA!=KLX7hW0nBAEgy6m4SvH(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ൝"):
		if XgfsEHex8hCzQY7vFNTBrW==mq5t9JXSdHT8yfDVF(u"࠭ࡓࡕࡑࡓࠫ൞"): return N4HDrYcWePfI0yxjb2
		rLEuTzBs2HFXjeSyfvCZcQw4O = G3yDpvxOiSWdAeL.getSetting(yobpaW7sBqtKRrv(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫൟ"))
		if rLEuTzBs2HFXjeSyfvCZcQw4O==kdRO82AImh0LFw(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨൠ"):
			sA8uj5gVrSnWxNOKicToeHb3MY(nJQVgbyzTW,jdQVwYOzMHSpbuJ56mLZCiDBv3,GHYZxqn6krEVy2PA)
			return N4HDrYcWePfI0yxjb2
	qnRjNaE0pD8BSU9PXmIMcGdQ5Lg = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	if XgfsEHex8hCzQY7vFNTBrW==wwWzyF4ZpSQXKOgk569(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪൡ"): qnRjNaE0pD8BSU9PXmIMcGdQ5Lg = OsSFncJAtVW3CqLbx74RiZjPY2yU
	OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(nJQVgbyzTW)
	if qnRjNaE0pD8BSU9PXmIMcGdQ5Lg: n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪൢ")+jdQVwYOzMHSpbuJ56mLZCiDBv3+VP70ytiFNMBl6vHDaW(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭ൣ")+str(jDuxzCtBH7aihsSL9+qnRjNaE0pD8BSU9PXmIMcGdQ5Lg)+KLX7hW0nBAEgy6m4SvH(u"ࠬࠦ࠻ࠨ൤"))
	n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭൥")+jdQVwYOzMHSpbuJ56mLZCiDBv3+aiQwFE1TGx04vmLcsYkIW5jA(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩ൦")+str(jDuxzCtBH7aihsSL9)+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࠢ࠾ࠫ൧"))
	if GHYZxqn6krEVy2PA:
		n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,KLX7hW0nBAEgy6m4SvH(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ൨")+jdQVwYOzMHSpbuJ56mLZCiDBv3+beV5l2D8HznyJI0(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ൩"),(str(GHYZxqn6krEVy2PA),))
		if n407uaQIPXEqUzwhLe8v3rSM6:
			try:
				HvzeZpTRrx9j1hMBV3 = eSQGo07L2IFWJRKYwV8s.decompress(n407uaQIPXEqUzwhLe8v3rSM6[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
				N4HDrYcWePfI0yxjb2 = jKM9ThPInf4.loads(HvzeZpTRrx9j1hMBV3)
			except: pass
	else:
		n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,KLX7hW0nBAEgy6m4SvH(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ൪")+jdQVwYOzMHSpbuJ56mLZCiDBv3+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࠨࠠ࠼ࠩ൫"))
		if n407uaQIPXEqUzwhLe8v3rSM6:
			N4HDrYcWePfI0yxjb2,lu5fdrwt2J7Dhmq4 = {},[]
			for GumfgPMOvdj8xcq3tshaVEB,bZ0VWjAHm1v2Csroh in n407uaQIPXEqUzwhLe8v3rSM6:
				ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = eSQGo07L2IFWJRKYwV8s.decompress(bZ0VWjAHm1v2Csroh)
				bZ0VWjAHm1v2Csroh = jKM9ThPInf4.loads(ygGuahJtKfEDr1vVjNelbFZ4nB6oHI)
				N4HDrYcWePfI0yxjb2[GumfgPMOvdj8xcq3tshaVEB] = bZ0VWjAHm1v2Csroh
				lu5fdrwt2J7Dhmq4.append(GumfgPMOvdj8xcq3tshaVEB)
			if lu5fdrwt2J7Dhmq4:
				N4HDrYcWePfI0yxjb2[A41nqbj3wYt(u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ൬")] = lu5fdrwt2J7Dhmq4
				if OYsxCijpVEWowUIZLkJ9==jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧ࡭࡫ࡶࡸࠬ൭"): N4HDrYcWePfI0yxjb2 = lu5fdrwt2J7Dhmq4
	OoE5HYUMwsrDWhx2gR7I3FuN.close()
	return N4HDrYcWePfI0yxjb2
def w1srYvgBLWStpZ29(nJQVgbyzTW,jdQVwYOzMHSpbuJ56mLZCiDBv3,GHYZxqn6krEVy2PA,N4HDrYcWePfI0yxjb2,ui8sT5YM9RHh4PN,EMFJA8fIgV=KiryBCvngZzF85UN6xSDlOVweL4I9):
	XgfsEHex8hCzQY7vFNTBrW = G3yDpvxOiSWdAeL.getSetting(Z9FPQvwlbjLTh(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ൮"))
	if XgfsEHex8hCzQY7vFNTBrW==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ൯") and ui8sT5YM9RHh4PN>OsSFncJAtVW3CqLbx74RiZjPY2yU: ui8sT5YM9RHh4PN = OsSFncJAtVW3CqLbx74RiZjPY2yU
	if EMFJA8fIgV:
		CIeL32XZ57bpg6WFyKB,eVcFjAaf7huW3rlQsJqBbDwkgT = [],[]
		for zuEo6GDeAR5Z in range(len(GHYZxqn6krEVy2PA)):
			HvzeZpTRrx9j1hMBV3 = jKM9ThPInf4.dumps(N4HDrYcWePfI0yxjb2[zuEo6GDeAR5Z])
			FHRefn5OPBoXt = eSQGo07L2IFWJRKYwV8s.compress(HvzeZpTRrx9j1hMBV3)
			CIeL32XZ57bpg6WFyKB.append((GHYZxqn6krEVy2PA[zuEo6GDeAR5Z],))
			eVcFjAaf7huW3rlQsJqBbDwkgT.append((ui8sT5YM9RHh4PN+jDuxzCtBH7aihsSL9,str(GHYZxqn6krEVy2PA[zuEo6GDeAR5Z]),FHRefn5OPBoXt))
	else:
		HvzeZpTRrx9j1hMBV3 = jKM9ThPInf4.dumps(N4HDrYcWePfI0yxjb2)
		h8gLfHAKGywXzBpq35vTa = eSQGo07L2IFWJRKYwV8s.compress(HvzeZpTRrx9j1hMBV3)
	OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(nJQVgbyzTW)
	n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ൰")+jdQVwYOzMHSpbuJ56mLZCiDBv3+CyHU86ZeYT5BWRcitSm2I(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ൱"))
	if EMFJA8fIgV:
		n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,r0D4C3z7Onqpa,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ൲")+jdQVwYOzMHSpbuJ56mLZCiDBv3+I872Vum45fMNe1BRngTZLoQiqvkt(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭൳"),CIeL32XZ57bpg6WFyKB)
		n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,r0D4C3z7Onqpa,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ൴")+jdQVwYOzMHSpbuJ56mLZCiDBv3+gPE1XB87fQl(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭൵"),eVcFjAaf7huW3rlQsJqBbDwkgT)
	else:
		if ui8sT5YM9RHh4PN:
			n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,iySORMYxWXszEH18(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ൶")+jdQVwYOzMHSpbuJ56mLZCiDBv3+oiWNFYzcIUeh(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ൷"),(str(GHYZxqn6krEVy2PA),))
			n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,mq5t9JXSdHT8yfDVF(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ൸")+jdQVwYOzMHSpbuJ56mLZCiDBv3+beV5l2D8HznyJI0(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ൹"),(ui8sT5YM9RHh4PN+jDuxzCtBH7aihsSL9,str(GHYZxqn6krEVy2PA),h8gLfHAKGywXzBpq35vTa))
		else:
			n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,IMjqygdfYSKpHlWu5Aa(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨൺ")+jdQVwYOzMHSpbuJ56mLZCiDBv3+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭ൻ"),(h8gLfHAKGywXzBpq35vTa,str(GHYZxqn6krEVy2PA)))
	OoE5HYUMwsrDWhx2gR7I3FuN.close()
	return
def sA8uj5gVrSnWxNOKicToeHb3MY(nJQVgbyzTW,jdQVwYOzMHSpbuJ56mLZCiDBv3,GHYZxqn6krEVy2PA=OHohTgj06taKzsG):
	OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8 = LLsY0NuzAxWOf8Hj(nJQVgbyzTW)
	if GHYZxqn6krEVy2PA==OHohTgj06taKzsG: n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,KLX7hW0nBAEgy6m4SvH(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪർ")+jdQVwYOzMHSpbuJ56mLZCiDBv3+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࠥࠤࡀ࠭ൽ"))
	else:
		urb4jsaAoChldxLmy8SN7KEGYD = (str(GHYZxqn6krEVy2PA),)
		if wwWzyF4ZpSQXKOgk569(u"ࠪࠩࠬൾ") in GHYZxqn6krEVy2PA: n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,SI7eBdND4lx8pt5Qk(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫൿ")+jdQVwYOzMHSpbuJ56mLZCiDBv3+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ඀"),urb4jsaAoChldxLmy8SN7KEGYD)
		else: n407uaQIPXEqUzwhLe8v3rSM6 = PEZioFnTRIm3(nJQVgbyzTW,OoE5HYUMwsrDWhx2gR7I3FuN,GSB3DNKz9vFbaEo8,KiryBCvngZzF85UN6xSDlOVweL4I9,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ඁ")+jdQVwYOzMHSpbuJ56mLZCiDBv3+ZLr5gRSkFewKdUos90bM(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧං"),urb4jsaAoChldxLmy8SN7KEGYD)
	OoE5HYUMwsrDWhx2gR7I3FuN.close()
	return
class cpiZw7sJIyo5dXht(): pass
class OOLSaYvmWAiTPXfuM9y3x5zZJ(cpiZw7sJIyo5dXht):
	def __init__(EfRyYmGtnvCrDeI5iV4Hx9S3):
		EfRyYmGtnvCrDeI5iV4Hx9S3.url = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		EfRyYmGtnvCrDeI5iV4Hx9S3.code = -lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠺࠻་")
		EfRyYmGtnvCrDeI5iV4Hx9S3.reason = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		EfRyYmGtnvCrDeI5iV4Hx9S3.content = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		EfRyYmGtnvCrDeI5iV4Hx9S3.headers = {}
		EfRyYmGtnvCrDeI5iV4Hx9S3.cookies = {}
		EfRyYmGtnvCrDeI5iV4Hx9S3.succeeded = KiryBCvngZzF85UN6xSDlOVweL4I9
def BN0jT2uzd7pJ5ak1FWPqHKE4UL(G3Xh0YWACHFuvQLx5sVEfPjzq7):
	if G3Xh0YWACHFuvQLx5sVEfPjzq7==VP70ytiFNMBl6vHDaW(u"ࠨࡦ࡬ࡧࡹ࠭ඃ"): N4HDrYcWePfI0yxjb2 = {}
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==beV5l2D8HznyJI0(u"ࠩ࡯࡭ࡸࡺࠧ඄"): N4HDrYcWePfI0yxjb2 = []
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪࡸࡺࡶ࡬ࡦࠩඅ"): N4HDrYcWePfI0yxjb2 = ()
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==oiWNFYzcIUeh(u"ࠫࡸࡺࡲࠨආ"): N4HDrYcWePfI0yxjb2 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࡯࡮ࡵࠩඇ"): N4HDrYcWePfI0yxjb2 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨඈ"): N4HDrYcWePfI0yxjb2 = OOLSaYvmWAiTPXfuM9y3x5zZJ()
	elif not G3Xh0YWACHFuvQLx5sVEfPjzq7: N4HDrYcWePfI0yxjb2 = OHohTgj06taKzsG
	else: N4HDrYcWePfI0yxjb2 = OHohTgj06taKzsG
	return N4HDrYcWePfI0yxjb2
def ttz1broY9LTy35uAh0wQPVDEca(sL1rp6kDWtJxGBHK5c):
	UUIn4RDmH6iy0ScrqtwX = G3yDpvxOiSWdAeL.getSetting(mq5t9JXSdHT8yfDVF(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪඉ"))
	KnuJvBMTRVijF9r7AwDg1Gtl4 = A3pXVFdyP1.AV_CLIENT_IDS.splitlines()
	YbEW9N7kCPhUSrlxao6pK = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	fhcKbWMxykEYqRjpHoCg906D2u1rm = len(sL1rp6kDWtJxGBHK5c)
	Aku1inmcwCldz4Ph5VFrKJIYf89 = [KiryBCvngZzF85UN6xSDlOVweL4I9]*fhcKbWMxykEYqRjpHoCg906D2u1rm
	for olnu1fNjh5Zw9OPS4KTrUCs7dAcHxR in [jDuxzCtBH7aihsSL9,jDuxzCtBH7aihsSL9-OQaHUGCW62hp8tFbgM]:
		SiJIyl7QdUDzpk5h1fq8VseAxtGa = str(olnu1fNjh5Zw9OPS4KTrUCs7dAcHxR*A41nqbj3wYt(u"࠴࠴࠵࠶࠰࠱࠰࠳།")/oiWNFYzcIUeh(u"࠶࠶࠶࠵࠶࠰༌"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:YYQS36fyPvtuzcEmRL(u"࠸༎")]
		if SiJIyl7QdUDzpk5h1fq8VseAxtGa!=YbEW9N7kCPhUSrlxao6pK:
			for VV60kArCYGvUWNOLymTJze in range(fhcKbWMxykEYqRjpHoCg906D2u1rm):
				if not Aku1inmcwCldz4Ph5VFrKJIYf89[VV60kArCYGvUWNOLymTJze]:
					AYNw6tITVipuHFjKqv3O = KiryBCvngZzF85UN6xSDlOVweL4I9
					for Xc6N4Lb18CGfaxFT9hgYnmp5sZy3 in KnuJvBMTRVijF9r7AwDg1Gtl4:
						yN8ljaZmnx2GDtOe97skPR = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡚࠴࠽ࠬඊ")+sL1rp6kDWtJxGBHK5c[VV60kArCYGvUWNOLymTJze]+pp7FcjEe6g(u"ࠩ࠴࠼ࡂ࠭උ")+Xc6N4Lb18CGfaxFT9hgYnmp5sZy3[-QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠷࠺༏"):]+mbvW9By35UDO+SiJIyl7QdUDzpk5h1fq8VseAxtGa
						yN8ljaZmnx2GDtOe97skPR = xxiJ2wLnUdPYeGXNz18ECc.md5(yN8ljaZmnx2GDtOe97skPR.encode(e87cIA5vwOQLDEP1)).hexdigest()[:lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠹࠲༐")]
						if yN8ljaZmnx2GDtOe97skPR in UUIn4RDmH6iy0ScrqtwX:
							AYNw6tITVipuHFjKqv3O = r0D4C3z7Onqpa
							break
					Aku1inmcwCldz4Ph5VFrKJIYf89[VV60kArCYGvUWNOLymTJze] = AYNw6tITVipuHFjKqv3O
		YbEW9N7kCPhUSrlxao6pK = SiJIyl7QdUDzpk5h1fq8VseAxtGa
	return Aku1inmcwCldz4Ph5VFrKJIYf89
class ffzcAnsvhkOlpLoQwFSY8D4xMW(hN0aOLCMy87IondiZUl46w2SxVm):
	def __init__(EfRyYmGtnvCrDeI5iV4Hx9S3): pass
	def ppg8RQerABxnZVPyY3d(EfRyYmGtnvCrDeI5iV4Hx9S3,fMvB4NbYJgO):
		EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = SI7eBdND4lx8pt5Qk(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫඌ") if A3pXVFdyP1.bWV7czPeIaq else WnNGfosHr5STAq8j7miwyRZ6eOUbV
		EfRyYmGtnvCrDeI5iV4Hx9S3.fMvB4NbYJgO = fMvB4NbYJgO
		if not A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI:
			import UdvL4wSQeI
			UdvL4wSQeI.PzLX0Jg7lIERk1WAeUKQNZV2Bwc(A8MWZixP2YtOJ1no53mw)
	def onPlayBackStopped(EfRyYmGtnvCrDeI5iV4Hx9S3): EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = rVy3Ops0mohYkT(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫඍ")
	def onPlayBackError(EfRyYmGtnvCrDeI5iV4Hx9S3): EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = GHg28TBchiyn6l(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬඎ")
	def onPlayBackEnded(EfRyYmGtnvCrDeI5iV4Hx9S3): EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = SI7eBdND4lx8pt5Qk(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ඏ")
	def onPlayBackStarted(EfRyYmGtnvCrDeI5iV4Hx9S3):
		EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = kdRO82AImh0LFw(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨඐ")
		VXRS03qmwprfhl2QFJyZDBHL8 = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=EfRyYmGtnvCrDeI5iV4Hx9S3.LPa28TtBJp5SDn7YXgrAV9y6fOwQmb)
		VXRS03qmwprfhl2QFJyZDBHL8.start()
	def onAVStarted(EfRyYmGtnvCrDeI5iV4Hx9S3):
		if A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI: EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = wwWzyF4ZpSQXKOgk569(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩඑ")
		else: EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = SI7eBdND4lx8pt5Qk(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪඒ")
	def LPa28TtBJp5SDn7YXgrAV9y6fOwQmb(EfRyYmGtnvCrDeI5iV4Hx9S3):
		voiu5JAyEfltV8W2Znr9Fh0X = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		while not eval(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨඓ"),{oiWNFYzcIUeh(u"ࠫࡽࡨ࡭ࡤࠩඔ"):pYDdXfVh5c0O1bMT6a78HKBiQw3}) and EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭ඕ"):
			pYDdXfVh5c0O1bMT6a78HKBiQw3.sleep(mq5t9JXSdHT8yfDVF(u"࠱࠱࠲࠳༑"))
			voiu5JAyEfltV8W2Znr9Fh0X += wnaWTQM7VJPkZzO9eoSyFU4
			if voiu5JAyEfltV8W2Znr9Fh0X>CyHU86ZeYT5BWRcitSm2I(u"࠷࠲༒"): return
		if A3pXVFdyP1.bWV7czPeIaq: EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = VP70ytiFNMBl6vHDaW(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧඖ")
		elif A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI: EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = yobpaW7sBqtKRrv(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ඗")
		elif A3pXVFdyP1.IImTyNn2dP:
			import UdvL4wSQeI
			EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = CyHU86ZeYT5BWRcitSm2I(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ඘")
			EOMr9e5BFQToPJvnphc1Ii3Vf8KHl(oiWNFYzcIUeh(u"ࠩࡶࡸࡴࡶࠧ඙"),r0D4C3z7Onqpa)
			yU4iAMqLh03OE = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=UdvL4wSQeI.DPoKMX74WGfUm9Habip,args=(EfRyYmGtnvCrDeI5iV4Hx9S3.fMvB4NbYJgO,)).start()
			nNaEwR2y1vbsx = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=UdvL4wSQeI.m5Di042yedpcblT).start()
		else: EfRyYmGtnvCrDeI5iV4Hx9S3.gFk2xIPvn18W = kdRO82AImh0LFw(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫක")
def cMevf7tVzqNBQ6jws3G2mDC4bEHZSK():
	Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	JWOrg3HSPVbMjfRkGiKyA20uYqTF = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪඛ"))
	try:
		U2jTkyCnEqixt = open(yobpaW7sBqtKRrv(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬග"),tzZ6PhyDOUnwLM3pdK(u"࠭ࡲࡣࠩඝ")).read()
		if rJ2oTLqabRtA: U2jTkyCnEqixt = U2jTkyCnEqixt.decode(e87cIA5vwOQLDEP1)
		l78MA0Vi5C = p7dwlH1PRStBgyMUW.findall(GHg28TBchiyn6l(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫඞ"),U2jTkyCnEqixt,p7dwlH1PRStBgyMUW.IGNORECASE)
		if l78MA0Vi5C: Z4ZnVlTg891kSwib7XsLBf0zrxID = l78MA0Vi5C[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	except: pass
	try:
		import subprocess as GMCNFTlP7XDbW90Qdu6Vm
		XEvAtqN1iJ0erTjC65IcdBLm = GMCNFTlP7XDbW90Qdu6Vm.Popen(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭ඟ"),shell=r0D4C3z7Onqpa,stdin=GMCNFTlP7XDbW90Qdu6Vm.PIPE,stdout=GMCNFTlP7XDbW90Qdu6Vm.PIPE,stderr=GMCNFTlP7XDbW90Qdu6Vm.PIPE)
		gI1c6P2vaey9nEf7 = XEvAtqN1iJ0erTjC65IcdBLm.stdout.read()
		if gI1c6P2vaey9nEf7:
			if rJ2oTLqabRtA:
				gI1c6P2vaey9nEf7 = gI1c6P2vaey9nEf7.decode(e87cIA5vwOQLDEP1,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩච"))
			rVAM8uPakhwomTSOR2lbtqQXy3IE = p7dwlH1PRStBgyMUW.findall(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧඡ"),gI1c6P2vaey9nEf7,p7dwlH1PRStBgyMUW.IGNORECASE)
			if rVAM8uPakhwomTSOR2lbtqQXy3IE: DV7wJ5jbaPodE0c1NOyk8ZYHSLGU = min(rVAM8uPakhwomTSOR2lbtqQXy3IE)
	except: pass
	return JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU
def kNR9wHFiUYQntWAly(buXlW4AHsxQ=r0D4C3z7Onqpa,s4sxCGQkfBI3jUm5=A6iX18qgyOFlZxz7sc(u"࠵࠵༓")):
	fsK2G4I7TouMpDhZC5taLU0ywVcH = r0D4C3z7Onqpa
	if buXlW4AHsxQ:
		vBz1TOQL3eG = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,CyHU86ZeYT5BWRcitSm2I(u"ࠫࡱ࡯ࡳࡵࠩජ"),kdRO82AImh0LFw(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨඣ"),GHg28TBchiyn6l(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫඤ"))
		if vBz1TOQL3eG:
			aCOJgMGfijpx625IYB4,NCWt9oBJPkSl,biHxSjd9XzpC1c4P,JJfZAypur1CaNoqjd2w = vBz1TOQL3eG
			fsK2G4I7TouMpDhZC5taLU0ywVcH = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࡭࡫ࡶࡸࠬඥ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫඦ"),kdRO82AImh0LFw(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨට"))
			if fsK2G4I7TouMpDhZC5taLU0ywVcH: JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU = fsK2G4I7TouMpDhZC5taLU0ywVcH
			else: JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU = cMevf7tVzqNBQ6jws3G2mDC4bEHZSK()
			if (NCWt9oBJPkSl,biHxSjd9XzpC1c4P,JJfZAypur1CaNoqjd2w)==(JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU):
				bADzdkJPOoj2h1 = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(aCOJgMGfijpx625IYB4)
				return bADzdkJPOoj2h1
	if fsK2G4I7TouMpDhZC5taLU0ywVcH: JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU = cMevf7tVzqNBQ6jws3G2mDC4bEHZSK()
	global PlgzmBpwTnS43kMb9q,MCGTqxsZb8cRN7K25jm4QhWXvID3e
	PlgzmBpwTnS43kMb9q,MCGTqxsZb8cRN7K25jm4QhWXvID3e,Y710TUdqFGeQtMHXmxnfAb6Sa43kRV = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	s4sxCGQkfBI3jUm5 = s4sxCGQkfBI3jUm5//XURrDCfOS9Mbhpv2Pmjos56TeW
	vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=vNnPb13kA6).start()
	vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=e7ejTxGUZSp).start()
	for zuEo6GDeAR5Z in range(GHg28TBchiyn6l(u"࠴࠴༔")):
		x54xSdnCFHZ8yliofzOBK.sleep(beV5l2D8HznyJI0(u"࠴࠳࠻༕"))
		if not Y710TUdqFGeQtMHXmxnfAb6Sa43kRV:
			try:
				vgEmCj5eox3KXtqNikQRT9SOwAB0 = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel(yobpaW7sBqtKRrv(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨඨ"))
				if vgEmCj5eox3KXtqNikQRT9SOwAB0.count(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࠿࠭ඩ"))==EEowc8rs5gUZTVjdOzmb0nu and vgEmCj5eox3KXtqNikQRT9SOwAB0.count(iySORMYxWXszEH18(u"ࠬ࠶ࠧඪ"))<n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠾༖"):
					vgEmCj5eox3KXtqNikQRT9SOwAB0 = vgEmCj5eox3KXtqNikQRT9SOwAB0.lower().replace(SI7eBdND4lx8pt5Qk(u"࠭࠺ࠨණ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
					Y710TUdqFGeQtMHXmxnfAb6Sa43kRV = str(int(vgEmCj5eox3KXtqNikQRT9SOwAB0,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠷࠶༗")))
			except: pass
		if PlgzmBpwTnS43kMb9q and MCGTqxsZb8cRN7K25jm4QhWXvID3e and Y710TUdqFGeQtMHXmxnfAb6Sa43kRV: break
	mvZTJfEow1g37rFUGDt = [MCGTqxsZb8cRN7K25jm4QhWXvID3e,PlgzmBpwTnS43kMb9q,Y710TUdqFGeQtMHXmxnfAb6Sa43kRV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪඬ")]
	if Z4ZnVlTg891kSwib7XsLBf0zrxID or DV7wJ5jbaPodE0c1NOyk8ZYHSLGU:
		JjLGPOpHA2fBQb70TsNm9WFkMyxva8 = [(yGLl1nSBrJPmi2adko9O,Z4ZnVlTg891kSwib7XsLBf0zrxID),(EEowc8rs5gUZTVjdOzmb0nu,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU)]
		for lGdZS2mFX1PfHEr7Lt8I,jSQ8Xqx9pBJIP5rCv2algzLb16 in JjLGPOpHA2fBQb70TsNm9WFkMyxva8:
			jSQ8Xqx9pBJIP5rCv2algzLb16 = jSQ8Xqx9pBJIP5rCv2algzLb16.strip(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࠲ࠪත"))
			if jSQ8Xqx9pBJIP5rCv2algzLb16:
				if rJ2oTLqabRtA: jSQ8Xqx9pBJIP5rCv2algzLb16 = jSQ8Xqx9pBJIP5rCv2algzLb16.encode(e87cIA5vwOQLDEP1)
				jSQ8Xqx9pBJIP5rCv2algzLb16 = str(int(xxiJ2wLnUdPYeGXNz18ECc.md5(jSQ8Xqx9pBJIP5rCv2algzLb16).hexdigest(),kdRO82AImh0LFw(u"࠳࠷༘")))
				Vgvt2OeInkdWfiqFHl4TwQCA9 = [int(jSQ8Xqx9pBJIP5rCv2algzLb16[DHmResEtxq2a7UPbli31CWgXcJA5:DHmResEtxq2a7UPbli31CWgXcJA5+ZLr5gRSkFewKdUos90bM(u"࠲࠷༙")]) for DHmResEtxq2a7UPbli31CWgXcJA5 in range(len(jSQ8Xqx9pBJIP5rCv2algzLb16)) if DHmResEtxq2a7UPbli31CWgXcJA5%ZLr5gRSkFewKdUos90bM(u"࠲࠷༙")==j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				mvZTJfEow1g37rFUGDt[lGdZS2mFX1PfHEr7Lt8I-wnaWTQM7VJPkZzO9eoSyFU4] = str(sum(Vgvt2OeInkdWfiqFHl4TwQCA9))
	KnuJvBMTRVijF9r7AwDg1Gtl4,tVZEWAcxMXyNvq3CIO1lGBd4 = [],KiryBCvngZzF85UN6xSDlOVweL4I9
	for Mfwn1NeLXHJPbrpOYz7t6aREoDQml,Vgvt2OeInkdWfiqFHl4TwQCA9 in enumerate(mvZTJfEow1g37rFUGDt):
		if not Vgvt2OeInkdWfiqFHl4TwQCA9: continue
		if tVZEWAcxMXyNvq3CIO1lGBd4 and Vgvt2OeInkdWfiqFHl4TwQCA9==mvZTJfEow1g37rFUGDt[-wnaWTQM7VJPkZzO9eoSyFU4]: continue
		tVZEWAcxMXyNvq3CIO1lGBd4 = r0D4C3z7Onqpa
		Vgvt2OeInkdWfiqFHl4TwQCA9 = iySORMYxWXszEH18(u"ࠩ࠳ࠫථ")*s4sxCGQkfBI3jUm5+Vgvt2OeInkdWfiqFHl4TwQCA9
		Vgvt2OeInkdWfiqFHl4TwQCA9 = Vgvt2OeInkdWfiqFHl4TwQCA9[-s4sxCGQkfBI3jUm5:]
		TDrvxhbUZu,Vqw4YTljdDLI3pr8tFbgzO7 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		hhWYPixTKqDw = str(int(IMjqygdfYSKpHlWu5Aa(u"ࠪ࠽ࠬද")*(s4sxCGQkfBI3jUm5+wnaWTQM7VJPkZzO9eoSyFU4))-int(Vgvt2OeInkdWfiqFHl4TwQCA9))[-s4sxCGQkfBI3jUm5:]
		for VV60kArCYGvUWNOLymTJze in list(range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,s4sxCGQkfBI3jUm5,yGLl1nSBrJPmi2adko9O)):
			TDrvxhbUZu += hhWYPixTKqDw[VV60kArCYGvUWNOLymTJze:VV60kArCYGvUWNOLymTJze+yGLl1nSBrJPmi2adko9O]+iySORMYxWXszEH18(u"ࠫ࠲࠭ධ")
			Vqw4YTljdDLI3pr8tFbgzO7 += str(sum(map(int,Vgvt2OeInkdWfiqFHl4TwQCA9[VV60kArCYGvUWNOLymTJze:VV60kArCYGvUWNOLymTJze+yGLl1nSBrJPmi2adko9O]))%yobpaW7sBqtKRrv(u"࠳࠳༚"))
		Xc6N4Lb18CGfaxFT9hgYnmp5sZy3 = str(Mfwn1NeLXHJPbrpOYz7t6aREoDQml)+TDrvxhbUZu+Vqw4YTljdDLI3pr8tFbgzO7
		KnuJvBMTRVijF9r7AwDg1Gtl4.append(Xc6N4Lb18CGfaxFT9hgYnmp5sZy3)
	CDPmLpGdcBniRv0baT4Kofu,aCOJgMGfijpx625IYB4 = [],[]
	for user in KnuJvBMTRVijF9r7AwDg1Gtl4:
		count = str(str(KnuJvBMTRVijF9r7AwDg1Gtl4).count(user[yobpaW7sBqtKRrv(u"࠴༛"):]))
		CDPmLpGdcBniRv0baT4Kofu.append(count+user)
	CDPmLpGdcBniRv0baT4Kofu = sorted(CDPmLpGdcBniRv0baT4Kofu,reverse=r0D4C3z7Onqpa,key=lambda key: key[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
	for user in CDPmLpGdcBniRv0baT4Kofu: aCOJgMGfijpx625IYB4.append(user[wnaWTQM7VJPkZzO9eoSyFU4:])
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,ZLr5gRSkFewKdUos90bM(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨන"),pp7FcjEe6g(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ඲"),[JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,CyHU86ZeYT5BWRcitSm2I(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪඳ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ප"),[aCOJgMGfijpx625IYB4,JWOrg3HSPVbMjfRkGiKyA20uYqTF,Z4ZnVlTg891kSwib7XsLBf0zrxID,DV7wJ5jbaPodE0c1NOyk8ZYHSLGU],nsFAzS2wvjyTYLOdDhfIiC0KGHE)
	for user in A3pXVFdyP1.BADCOMMONIDS:
		if user in aCOJgMGfijpx625IYB4: aCOJgMGfijpx625IYB4.remove(user)
	bADzdkJPOoj2h1 = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(aCOJgMGfijpx625IYB4)
	return bADzdkJPOoj2h1
def vNnPb13kA6():
	global PlgzmBpwTnS43kMb9q
	try:
		import getmac82 as bb4Gv5ldW0JfKZjhHg
		utWZlroeAjFSLqnyEsv0 = bb4Gv5ldW0JfKZjhHg.get_mac_address()
		if utWZlroeAjFSLqnyEsv0.count(kdRO82AImh0LFw(u"ࠩ࠽ࠫඵ"))==EEowc8rs5gUZTVjdOzmb0nu and utWZlroeAjFSLqnyEsv0.count(tzZ6PhyDOUnwLM3pdK(u"ࠪ࠴ࠬබ"))<CyHU86ZeYT5BWRcitSm2I(u"࠽༜"):
			utWZlroeAjFSLqnyEsv0 = utWZlroeAjFSLqnyEsv0.lower().replace(yobpaW7sBqtKRrv(u"ࠫ࠿࠭භ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			PlgzmBpwTnS43kMb9q = str(int(utWZlroeAjFSLqnyEsv0,beV5l2D8HznyJI0(u"࠶࠼༝")))
	except: pass
	return
def e7ejTxGUZSp():
	global MCGTqxsZb8cRN7K25jm4QhWXvID3e
	try:
		import getmac95 as BICsAD704GajZPdOqFl52KoURLXeSN
		t3F4r0mwNxdpbfQqn = BICsAD704GajZPdOqFl52KoURLXeSN.get_mac_address()
		if t3F4r0mwNxdpbfQqn.count(iySORMYxWXszEH18(u"ࠬࡀࠧම"))==EEowc8rs5gUZTVjdOzmb0nu and t3F4r0mwNxdpbfQqn.count(rVy3Ops0mohYkT(u"࠭࠰ࠨඹ"))<IMjqygdfYSKpHlWu5Aa(u"࠿༞"):
			t3F4r0mwNxdpbfQqn = t3F4r0mwNxdpbfQqn.lower().replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧ࠻ࠩය"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			MCGTqxsZb8cRN7K25jm4QhWXvID3e = str(int(t3F4r0mwNxdpbfQqn,gPE1XB87fQl(u"࠱࠷༟")))
	except: pass
	return
def N0CQrbltd91Ywj7Zm5xJz43suchF(G3Xh0YWACHFuvQLx5sVEfPjzq7,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy,g0Sft2VkTxGD1pYobnsX76E):
	for vxXun4JkSLqNj1Z9GWoapMUE7 in hrKYDu7fpc9V618FMnviALZtP:
		if vxXun4JkSLqNj1Z9GWoapMUE7 in kdNn2Zqsj4wPi5ThuoUQvtcg6OA: kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(vxXun4JkSLqNj1Z9GWoapMUE7,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if vxXun4JkSLqNj1Z9GWoapMUE7 in OLAqp2vxUf5rw79zdgQR1ZboEJ: OLAqp2vxUf5rw79zdgQR1ZboEJ = OLAqp2vxUf5rw79zdgQR1ZboEJ.replace(vxXun4JkSLqNj1Z9GWoapMUE7,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	W67hPCcaOek094 = str(OLAqp2vxUf5rw79zdgQR1ZboEJ)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4:n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠳࠷࠳༠")].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,beV5l2D8HznyJI0(u"ࠨ࡞࡟ࡲࠬර")).replace(TTLxlKI0gNfh7FP,Z9FPQvwlbjLTh(u"ࠩ࡟ࡠࡷ࠭඼")).replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ)
	if len(str(OLAqp2vxUf5rw79zdgQR1ZboEJ))>tzZ6PhyDOUnwLM3pdK(u"࠴࠸࠴༡"): W67hPCcaOek094 = W67hPCcaOek094+pp7FcjEe6g(u"ࠪࠤ࠳࠴࠮ࠨල")
	bZ0VWjAHm1v2Csroh = CyHU86ZeYT5BWRcitSm2I(u"ࠫ࠳࠴࠮ࠨ඾")
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,VP70ytiFNMBl6vHDaW(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࠧ඿")+G3Xh0YWACHFuvQLx5sVEfPjzq7+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩව")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+tzZ6PhyDOUnwLM3pdK(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩශ")+ADN3XhW9ZpVmFK84j2roiy+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪෂ")+g0Sft2VkTxGD1pYobnsX76E+kdRO82AImh0LFw(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬස")+str(W67hPCcaOek094)+iySORMYxWXszEH18(u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪහ")+bZ0VWjAHm1v2Csroh+yobpaW7sBqtKRrv(u"ࠫࠥࡣࠧළ"))
	return
def lCyIgTpZ8WJHdk9iPBLUD(g0Sft2VkTxGD1pYobnsX76E,CigHOUsJIcMfNXAyqwL1z3enSrWR,N4HDrYcWePfI0yxjb2=WnNGfosHr5STAq8j7miwyRZ6eOUbV,OLAqp2vxUf5rw79zdgQR1ZboEJ=WnNGfosHr5STAq8j7miwyRZ6eOUbV,ADN3XhW9ZpVmFK84j2roiy=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if rJ2oTLqabRtA: import urllib.request as enqE7pPcLMSvgNDUQZdG
	else: import urllib2 as enqE7pPcLMSvgNDUQZdG
	if not OLAqp2vxUf5rw79zdgQR1ZboEJ: OLAqp2vxUf5rw79zdgQR1ZboEJ = {lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩෆ"):WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	if not N4HDrYcWePfI0yxjb2: N4HDrYcWePfI0yxjb2 = {}
	oxkugCerDO95MVNUn3mbSt = N4HDrYcWePfI0yxjb2
	gFA1Cv2eXB3uwd09mRiLfn = CigHOUsJIcMfNXAyqwL1z3enSrWR in A3pXVFdyP1.SITESURLS[SI7eBdND4lx8pt5Qk(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෇")]
	if gFA1Cv2eXB3uwd09mRiLfn:
		g0Sft2VkTxGD1pYobnsX76E = iySORMYxWXszEH18(u"ࠧࡑࡑࡖࡘࠬ෈")
		OLAqp2vxUf5rw79zdgQR1ZboEJ[lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨࡃ࡙࠱ࡊࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠨ෉")] = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࡙ࠩࡩࡷࡹࡩࡰࡰࠣ࠵࠳࠶්ࠧ")
		jSOGoIJCUs4FyE = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(N4HDrYcWePfI0yxjb2)
		import UdvL4wSQeI
		oxkugCerDO95MVNUn3mbSt = UdvL4wSQeI.tyLbxATjI4GivOnUHcu(jSOGoIJCUs4FyE,YYQS36fyPvtuzcEmRL(u"࠻࠵࠷࠽࠴࠺࠵࠸࠺༢"))
		CigHOUsJIcMfNXAyqwL1z3enSrWR = CigHOUsJIcMfNXAyqwL1z3enSrWR+SI7eBdND4lx8pt5Qk(u"ࠪࡃࡺࡹࡥࡳ࠿ࠪ෋")+WW3PiLNaxCY
	elif g0Sft2VkTxGD1pYobnsX76E==CyHU86ZeYT5BWRcitSm2I(u"ࠫࡌࡋࡔࠨ෌"):
		CigHOUsJIcMfNXAyqwL1z3enSrWR = kdNn2Zqsj4wPi5ThuoUQvtcg6OA+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡅࠧ෍")+kkymMOX7TcjRVpY2K(N4HDrYcWePfI0yxjb2)
		oxkugCerDO95MVNUn3mbSt = OHohTgj06taKzsG
	elif g0Sft2VkTxGD1pYobnsX76E==VP70ytiFNMBl6vHDaW(u"࠭ࡐࡐࡕࡗࠫ෎") and A6iX18qgyOFlZxz7sc(u"ࠧ࡫ࡵࡲࡲࠬා") in str(OLAqp2vxUf5rw79zdgQR1ZboEJ):
		N4HDrYcWePfI0yxjb2 = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(N4HDrYcWePfI0yxjb2)
		oxkugCerDO95MVNUn3mbSt = str(N4HDrYcWePfI0yxjb2).encode(e87cIA5vwOQLDEP1)
	elif g0Sft2VkTxGD1pYobnsX76E==CyHU86ZeYT5BWRcitSm2I(u"ࠨࡒࡒࡗ࡙࠭ැ"):
		N4HDrYcWePfI0yxjb2 = kkymMOX7TcjRVpY2K(N4HDrYcWePfI0yxjb2)
		oxkugCerDO95MVNUn3mbSt = N4HDrYcWePfI0yxjb2.encode(e87cIA5vwOQLDEP1)
	N0CQrbltd91Ywj7Zm5xJz43suchF(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧෑ"),CigHOUsJIcMfNXAyqwL1z3enSrWR,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ADN3XhW9ZpVmFK84j2roiy,g0Sft2VkTxGD1pYobnsX76E)
	try:
		XB3WQ2UPg1Ae = enqE7pPcLMSvgNDUQZdG.Request(CigHOUsJIcMfNXAyqwL1z3enSrWR,headers=OLAqp2vxUf5rw79zdgQR1ZboEJ,data=oxkugCerDO95MVNUn3mbSt)
		u4vhNT8C0k1tmrxX9F5gGWo7Z = enqE7pPcLMSvgNDUQZdG.urlopen(XB3WQ2UPg1Ae)
		SOnrWJBVCwHp4XExF9N5yoza3GjLil = u4vhNT8C0k1tmrxX9F5gGWo7Z.read()
		cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E = ZLr5gRSkFewKdUos90bM(u"࠶࠵࠶༣"),mq5t9JXSdHT8yfDVF(u"ࠪࡓࡐ࠭ි")
	except:
		SOnrWJBVCwHp4XExF9N5yoza3GjLil = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		cquGxZCOaDk3QJMNlXSeU,PPSTwoZdRinA3YXtybaeVux9Om0E = -wnaWTQM7VJPkZzO9eoSyFU4,iySORMYxWXszEH18(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫී")
	try:
		if gFA1Cv2eXB3uwd09mRiLfn and SOnrWJBVCwHp4XExF9N5yoza3GjLil:
			ZlNDKah9mgCTeOycUIw5JAXPu2YvGb = {QchoMN1dtDgAOaE.lower(): vv8iRSdbKX043aWglfhuUQq1pEok for QchoMN1dtDgAOaE, vv8iRSdbKX043aWglfhuUQq1pEok in u4vhNT8C0k1tmrxX9F5gGWo7Z.headers.items()}
			if ZlNDKah9mgCTeOycUIw5JAXPu2YvGb.get(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࡧࡶ࠮ࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬු"))==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫ෕"):
				SOnrWJBVCwHp4XExF9N5yoza3GjLil,A1njWC4ayFpYRi7S = UdvL4wSQeI.FouSVWLdMTJgX(SOnrWJBVCwHp4XExF9N5yoza3GjLil,iySORMYxWXszEH18(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼༤"))
				if A1njWC4ayFpYRi7S==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡊࡐ࡙ࡅࡑࡏࡄࡠࡖࡌࡑࡊ࡙ࡔࡂࡏࡓࠫූ"):
					PPSTwoZdRinA3YXtybaeVux9Om0E,cquGxZCOaDk3QJMNlXSeU = XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡄࡔࡎࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠩ෗"),-EEowc8rs5gUZTVjdOzmb0nu
					SOnrWJBVCwHp4XExF9N5yoza3GjLil = PPSTwoZdRinA3YXtybaeVux9Om0E
	except: SOnrWJBVCwHp4XExF9N5yoza3GjLil = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if rJ2oTLqabRtA and isinstance(SOnrWJBVCwHp4XExF9N5yoza3GjLil,bytes): SOnrWJBVCwHp4XExF9N5yoza3GjLil = SOnrWJBVCwHp4XExF9N5yoza3GjLil.decode(e87cIA5vwOQLDEP1)
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫෘ")+str(cquGxZCOaDk3QJMNlXSeU)+rVy3Ops0mohYkT(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬෙ")+PPSTwoZdRinA3YXtybaeVux9Om0E+SI7eBdND4lx8pt5Qk(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ේ")+ADN3XhW9ZpVmFK84j2roiy+ZLr5gRSkFewKdUos90bM(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫෛ")+CigHOUsJIcMfNXAyqwL1z3enSrWR+aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ࠠ࡞ࠩො"))
	return SOnrWJBVCwHp4XExF9N5yoza3GjLil
def P92i4pcKGaCYt0V6Sonw(LUVj6dZKFvawYl):
	sOkmVdPiqH9gl = str(FxEWL1w4gjr8mM.randrange(A41nqbj3wYt(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴༥"),tzZ6PhyDOUnwLM3pdK(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽༦")))
	MMVJsnotuDIUKdS8aW9eE = {
		eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣෝ"):WW3PiLNaxCY,
		YYQS36fyPvtuzcEmRL(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧෞ"):str(CCPXJ7wnNLOg0ZoekcmpdSKI),
		gPE1XB87fQl(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢෟ"):mbvW9By35UDO,
		rVy3Ops0mohYkT(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥ෠"):mbvW9By35UDO,
		QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ෡"): mbvW9By35UDO,
		wwWzyF4ZpSQXKOgk569(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨ෢"):aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨ෣"),
		ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠢࡪࡲࠥ෤"): gPE1XB87fQl(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ෥"),
		wwWzyF4ZpSQXKOgk569(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣ෦"):KiryBCvngZzF85UN6xSDlOVweL4I9
	}
	qPkuCYOoLQhv1ZMdRt4jfn23bxD = []
	for RAVgaEbSx8NZkzrewHJXhK6lC7 in LUVj6dZKFvawYl:
		zE4XRrjSYK = MMVJsnotuDIUKdS8aW9eE.copy()
		zE4XRrjSYK[yobpaW7sBqtKRrv(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ෧")] = RAVgaEbSx8NZkzrewHJXhK6lC7
		zE4XRrjSYK[ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ෨")] = {wwWzyF4ZpSQXKOgk569(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ෩"):RAVgaEbSx8NZkzrewHJXhK6lC7}
		zE4XRrjSYK[jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ෪")] = {n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ෫"):RAVgaEbSx8NZkzrewHJXhK6lC7}
		qPkuCYOoLQhv1ZMdRt4jfn23bxD.append(zE4XRrjSYK)
	N4HDrYcWePfI0yxjb2 = {
		SI7eBdND4lx8pt5Qk(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ෬"):bawK2j7T81Nrc4GWs05xzDg(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧ෭"),
		YYQS36fyPvtuzcEmRL(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ෮"):sOkmVdPiqH9gl,
		aiQwFE1TGx04vmLcsYkIW5jA(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ෯"): qPkuCYOoLQhv1ZMdRt4jfn23bxD
	}
	OLAqp2vxUf5rw79zdgQR1ZboEJ = {n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ෰"):SI7eBdND4lx8pt5Qk(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ෱")}
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = A6iX18qgyOFlZxz7sc(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩෲ")
	VbRFshPMjr2t3k = lCyIgTpZ8WJHdk9iPBLUD(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨࡒࡒࡗ࡙࠭ෳ"),kdNn2Zqsj4wPi5ThuoUQvtcg6OA,N4HDrYcWePfI0yxjb2,OLAqp2vxUf5rw79zdgQR1ZboEJ,ZLr5gRSkFewKdUos90bM(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ෴"))
	return VbRFshPMjr2t3k
def NR3Ss1Pvr9C4Jme(llArp7Tn3tOuGzwVBRkq):
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(yobpaW7sBqtKRrv(u"ࡵࠫ࠭ࡢࡳࠪࠤࠫࡠࡼ࠯ࠧ෵"), A6iX18qgyOFlZxz7sc(u"ࡶࠬࡢ࠱࡝࡞ࠥࡠ࠷࠭෶"), llArp7Tn3tOuGzwVBRkq)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(beV5l2D8HznyJI0(u"ࡷ࠭ࠨ࡝ࡹࠬࠦ࠭ࡢࡳࠪࠩ෷"), rVy3Ops0mohYkT(u"ࡸࠧ࡝࠳࡟ࡠࠧࡢ࠲ࠨ෸"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(KLX7hW0nBAEgy6m4SvH(u"ࡲࠨࠪ࡟ࡻ࠮ࠨࠨ࡝ࡹࠬࠫ෹"), pp7FcjEe6g(u"ࡳࠩ࡟࠵ࡡࡢࠢ࡝࠴ࠪ෺"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࡴࠪࠬࡡࡹࠩࠣࠪ࡟ࡷ࠮࠭෻"), jhDZ0BAFoEGUcw5QrJkaxXL(u"ࡵࠫࡡ࠷࡜࡝ࠤ࡟࠶ࠬ෼"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(pp7FcjEe6g(u"ࡶࠧ࠮࡜ࡴࠫࠪࠬࡡࡽࠩࠣ෽"), SI7eBdND4lx8pt5Qk(u"ࡷࠨ࡜࠲࡞࡟ࠫࡡ࠸ࠢ෾"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(tzZ6PhyDOUnwLM3pdK(u"ࡸࠢࠩ࡞ࡺ࠭ࠬ࠮࡜ࡴࠫࠥ෿"), ZLr5gRSkFewKdUos90bM(u"ࡲࠣ࡞࠴ࡠࡡ࠭࡜࠳ࠤ฀"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(rVy3Ops0mohYkT(u"ࡳࠤࠫࡠࡼ࠯ࠧࠩ࡞ࡺ࠭ࠧก"), CyHU86ZeYT5BWRcitSm2I(u"ࡴࠥࡠ࠶ࡢ࡜ࠨ࡞࠵ࠦข"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(ZLr5gRSkFewKdUos90bM(u"ࡵࠦ࠭ࡢࡳࠪࠩࠫࡠࡸ࠯ࠢฃ"), A6iX18qgyOFlZxz7sc(u"ࡶࠧࡢ࠱࡝࡞ࠪࡠ࠷ࠨค"), Hn20kEGKbCg)
	Zp3FhqmAQ6bzKV5N = GHg28TBchiyn6l(u"ࡷ࡛࠭࡝࡝࡟ࡡࢀࢃࠨࠪ࠼࠯ࡡࠬฅ")
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(A41nqbj3wYt(u"ࡸࠧࠩ࡞ࡺ࠭࠭࠭ฆ") + Zp3FhqmAQ6bzKV5N + ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࡲࠨࠫࠫࡠࡼ࠯ࠧง"), rVy3Ops0mohYkT(u"ࡳࠩ࡟࠵ࡡࡢ࡜࠳࡞࠶ࠫจ"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(gPE1XB87fQl(u"ࡴࠪࠬࡡࡹࠩࠩࠩฉ") + Zp3FhqmAQ6bzKV5N + oiWNFYzcIUeh(u"ࡵࠫ࠮࠮࡜ࡸࠫࠪช"), ZLr5gRSkFewKdUos90bM(u"ࡶࠬࡢ࠱࡝࡞࡟࠶ࡡ࠹ࠧซ"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࡷ࠭ࠨ࡝ࡹࠬࠬࠬฌ") + Zp3FhqmAQ6bzKV5N + CyHU86ZeYT5BWRcitSm2I(u"ࡸࠧࠪࠪ࡟ࡷ࠮࠭ญ"), rVy3Ops0mohYkT(u"ࡲࠨ࡞࠴ࡠࡡࡢ࠲࡝࠵ࠪฎ"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(Z9FPQvwlbjLTh(u"ࡳࠩࠫࡠࡸ࠯ࠨࠨฏ") + Zp3FhqmAQ6bzKV5N + A41nqbj3wYt(u"ࡴࠪ࠭࠭ࡢࡳࠪࠩฐ"), VP70ytiFNMBl6vHDaW(u"ࡵࠫࡡ࠷࡜࡝࡞࠵ࡠ࠸࠭ฑ"), Hn20kEGKbCg)
	Hn20kEGKbCg = p7dwlH1PRStBgyMUW.sub(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࡶࠬ࠮࡜ࡸࠫ࡟ࡠ࠭ࡢࡷࠪࠩฒ"), yobpaW7sBqtKRrv(u"ࡷ࠭࡜࠲࡞࡟ࡠࡡࡢ࠲ࠨณ"), Hn20kEGKbCg)
	return Hn20kEGKbCg
def IXZpzK7ShaRsAN(OYsxCijpVEWowUIZLkJ9,kjML6bB7N4302iefu8hFyH):
	kjML6bB7N4302iefu8hFyH = kjML6bB7N4302iefu8hFyH.replace(KLX7hW0nBAEgy6m4SvH(u"࠭࡮ࡶ࡮࡯ࠫด"),tzZ6PhyDOUnwLM3pdK(u"ࠧࡏࡱࡱࡩࠬต"))
	kjML6bB7N4302iefu8hFyH = kjML6bB7N4302iefu8hFyH.replace(pp7FcjEe6g(u"ࠨࡶࡵࡹࡪ࠭ถ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡗࡶࡺ࡫ࠧท"))
	kjML6bB7N4302iefu8hFyH = kjML6bB7N4302iefu8hFyH.replace(yobpaW7sBqtKRrv(u"ࠪࡪࡦࡲࡳࡦࠩธ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡋࡧ࡬ࡴࡧࠪน"))
	kjML6bB7N4302iefu8hFyH = kjML6bB7N4302iefu8hFyH.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡢ࠯ࠨบ"),mq5t9JXSdHT8yfDVF(u"࠭࠯ࠨป"))
	kjML6bB7N4302iefu8hFyH = kjML6bB7N4302iefu8hFyH.replace(wwWzyF4ZpSQXKOgk569(u"ࠧ࡝ࡴࠪผ"),gPE1XB87fQl(u"ࠨ࡞࡟ࡶࠬฝ")).replace(GHg28TBchiyn6l(u"ࠩ࡟ࡲࠬพ"),pp7FcjEe6g(u"ࠪࡠࡡࡴࠧฟ"))
	WdyBIKb6LlJ7UP5A2Mqnhtx1,O0wjlJq2ViGH4ZbW8R3T = [],[]
	import ast as GioCbfsFlNUa8DkQA3hmdIc2ZrMtK
	try: WdyBIKb6LlJ7UP5A2Mqnhtx1 = GioCbfsFlNUa8DkQA3hmdIc2ZrMtK.literal_eval(kjML6bB7N4302iefu8hFyH)
	except:
		try:
			kjML6bB7N4302iefu8hFyH = NR3Ss1Pvr9C4Jme(kjML6bB7N4302iefu8hFyH)
			WdyBIKb6LlJ7UP5A2Mqnhtx1 = GioCbfsFlNUa8DkQA3hmdIc2ZrMtK.literal_eval(kjML6bB7N4302iefu8hFyH)
		except:
			items = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࡶࠬࡢ࡛࡜ࡠ࡟ࡡࡢ࠰࡜࡞ࡾ࡟ࡿࡠࡤࡽ࡞ࠬ࡟ࢁࢁࡢࠨ࡜ࡠࠬࡡ࠯ࡢࠩࡽ࡝ࡡ࠰ࡡࡡ࡜࡞࡟࠮ࠫภ"),kjML6bB7N4302iefu8hFyH.strip(yobpaW7sBqtKRrv(u"ࠬࡡ࡝ࠨม")))
			if items:
				for N6NV3h4fel in items:
					try: WdyBIKb6LlJ7UP5A2Mqnhtx1.append(GioCbfsFlNUa8DkQA3hmdIc2ZrMtK.literal_eval(N6NV3h4fel))
					except: O0wjlJq2ViGH4ZbW8R3T.append(N6NV3h4fel)
			else: WdyBIKb6LlJ7UP5A2Mqnhtx1 = BN0jT2uzd7pJ5ak1FWPqHKE4UL(OYsxCijpVEWowUIZLkJ9)
	return WdyBIKb6LlJ7UP5A2Mqnhtx1
def OE38lVnF9jRGUAXPzoLIecvMHp():
	G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	TAQfygRC4WoHu37SEeZ = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭ย"),VkEQdztnmeH,p7dwlH1PRStBgyMUW.DOTALL)
	if TAQfygRC4WoHu37SEeZ: VkEQdztnmeH = VkEQdztnmeH.split(TAQfygRC4WoHu37SEeZ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
	y7anobAOsGxB2 = x54xSdnCFHZ8yliofzOBK.strftime(wwWzyF4ZpSQXKOgk569(u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧร"),x54xSdnCFHZ8yliofzOBK.localtime(jDuxzCtBH7aihsSL9))
	VkEQdztnmeH = VkEQdztnmeH+y7anobAOsGxB2
	TQIX0VjldCJZ2BxrR8c = G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f
	if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(UUN4I9unSKWg7c3YizxEmq):
		N70NuMkcZHY = open(UUN4I9unSKWg7c3YizxEmq,SI7eBdND4lx8pt5Qk(u"ࠨࡴࡥࠫฤ")).read()
		if rJ2oTLqabRtA: N70NuMkcZHY = N70NuMkcZHY.decode(e87cIA5vwOQLDEP1)
		N70NuMkcZHY = IXZpzK7ShaRsAN(gPE1XB87fQl(u"ࠩࡧ࡭ࡨࡺࠧล"),N70NuMkcZHY)
	else: N70NuMkcZHY = {}
	bmK07sdk8FNynQ45HphU = {}
	for bF6dyzW94JHGB in list(N70NuMkcZHY.keys()):
		if bF6dyzW94JHGB!=G3Xh0YWACHFuvQLx5sVEfPjzq7: bmK07sdk8FNynQ45HphU[bF6dyzW94JHGB] = N70NuMkcZHY[bF6dyzW94JHGB]
		else:
			if VkEQdztnmeH and VkEQdztnmeH!=bawK2j7T81Nrc4GWs05xzDg(u"ࠪ࠲࠳࠭ฦ"):
				bkoPzTjlwRudfXtIVn0pK1J2 = N70NuMkcZHY[bF6dyzW94JHGB]
				if TQIX0VjldCJZ2BxrR8c in bkoPzTjlwRudfXtIVn0pK1J2:
					veLqt1DZI6N8a = bkoPzTjlwRudfXtIVn0pK1J2.index(TQIX0VjldCJZ2BxrR8c)
					del bkoPzTjlwRudfXtIVn0pK1J2[veLqt1DZI6N8a]
				do9Jn4YIWwCH3bQtcR1V8ehgFK = [TQIX0VjldCJZ2BxrR8c]+bkoPzTjlwRudfXtIVn0pK1J2
				do9Jn4YIWwCH3bQtcR1V8ehgFK = do9Jn4YIWwCH3bQtcR1V8ehgFK[:jhDZ0BAFoEGUcw5QrJkaxXL(u"࠶࠲༧")]
				bmK07sdk8FNynQ45HphU[bF6dyzW94JHGB] = do9Jn4YIWwCH3bQtcR1V8ehgFK
			else: bmK07sdk8FNynQ45HphU[bF6dyzW94JHGB] = N70NuMkcZHY[bF6dyzW94JHGB]
	if G3Xh0YWACHFuvQLx5sVEfPjzq7 not in list(bmK07sdk8FNynQ45HphU.keys()): bmK07sdk8FNynQ45HphU[G3Xh0YWACHFuvQLx5sVEfPjzq7] = [TQIX0VjldCJZ2BxrR8c]
	bmK07sdk8FNynQ45HphU = str(bmK07sdk8FNynQ45HphU)
	if rJ2oTLqabRtA: bmK07sdk8FNynQ45HphU = bmK07sdk8FNynQ45HphU.encode(e87cIA5vwOQLDEP1)
	open(UUN4I9unSKWg7c3YizxEmq,YYQS36fyPvtuzcEmRL(u"ࠫࡼࡨࠧว")).write(bmK07sdk8FNynQ45HphU)
	return
def kkymMOX7TcjRVpY2K(N4HDrYcWePfI0yxjb2):
	if rJ2oTLqabRtA: import urllib.parse as hYOacg48ibsl1y0Z2LdnG5roFCEqm
	else: import urllib as hYOacg48ibsl1y0Z2LdnG5roFCEqm
	dYVSsCMOHiXIR0AxgJDq98tLmKB3 = hYOacg48ibsl1y0Z2LdnG5roFCEqm.urlencode(N4HDrYcWePfI0yxjb2)
	return dYVSsCMOHiXIR0AxgJDq98tLmKB3
def YsRk6pAS7rdcn(QQTfhlZEDnu4wVcOeHGNyCBo5t2,nzIvkRxy1XtfeDHPjq54pNVG6=WnNGfosHr5STAq8j7miwyRZ6eOUbV,Qd2P0tYnV3ghvsKr5oAkeypZuiO7=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	jiXoSurBHAe6xC7 = nzIvkRxy1XtfeDHPjq54pNVG6 not in [I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡓ࠳ࡖࠩศ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ࡉࡑࡖ࡙ࠫษ")]
	if not Qd2P0tYnV3ghvsKr5oAkeypZuiO7: Qd2P0tYnV3ghvsKr5oAkeypZuiO7 = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧࡷ࡫ࡧࡩࡴ࠭ส")
	zKhToMgRHePwBtVr1da9vn2iX,yyFX5QeiSTAL4K0MDPdtWmhNRgEj,fbhUs8IHk4BTFuaLK = bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪห"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if len(QQTfhlZEDnu4wVcOeHGNyCBo5t2)==vXIdY7TwFKso40gVBq5:
		kdNn2Zqsj4wPi5ThuoUQvtcg6OA,neVMkPcxCS,fbhUs8IHk4BTFuaLK = QQTfhlZEDnu4wVcOeHGNyCBo5t2
		if neVMkPcxCS: yyFX5QeiSTAL4K0MDPdtWmhNRgEj = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫฬ")+neVMkPcxCS+pp7FcjEe6g(u"ࠪࠤࡢ࠭อ")
	else: kdNn2Zqsj4wPi5ThuoUQvtcg6OA,neVMkPcxCS,fbhUs8IHk4BTFuaLK = QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(gPE1XB87fQl(u"ࠫࠪ࠸࠰ࠨฮ"),kcXMWrwiLDKeBHRsJ)
	VDbTGIpvEYSedh06oZrxgOCKu5HzjJ = mm19wY7OfIvCxb8AFZEHJ(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	if nzIvkRxy1XtfeDHPjq54pNVG6 not in [CyHU86ZeYT5BWRcitSm2I(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧฯ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡉࡑࡖ࡙ࠫะ")]:
		if nzIvkRxy1XtfeDHPjq54pNVG6!=n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩั"): kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.replace(kcXMWrwiLDKeBHRsJ,Z9FPQvwlbjLTh(u"ࠨࠧ࠵࠴ࠬา"))
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨำ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+KLX7hW0nBAEgy6m4SvH(u"ࠪࠤࡢ࠭ิ")+yyFX5QeiSTAL4K0MDPdtWmhNRgEj)
		if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ==Z9FPQvwlbjLTh(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪี") and nzIvkRxy1XtfeDHPjq54pNVG6 not in [eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࡏࡐࡕࡘࠪึ"),iySORMYxWXszEH18(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧื")]:
			import UdvL4wSQeI,yBR5QHGdUT
			ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = UdvL4wSQeI.unQmLTC3MlKq(nzIvkRxy1XtfeDHPjq54pNVG6,kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
			tJqAIFkchTU = len(M0MFkiKqJDv1aZ4NA396u)
			if tJqAIFkchTU>wnaWTQM7VJPkZzO9eoSyFU4:
				XFaM94cPUCOWQZNIEe8gdJpny1 = yBR5QHGdUT.A3DjqpQcnvi6O0oXxGTlz19ytdKu(kdRO82AImh0LFw(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨุ")+str(tJqAIFkchTU)+yobpaW7sBqtKRrv(u"ࠨ่่ࠢๆ࠯ูࠧ"), ZD0qItXg31HmC7KGEFn)
				if XFaM94cPUCOWQZNIEe8gdJpny1==-wnaWTQM7VJPkZzO9eoSyFU4:
					yBR5QHGdUT.uTaiRMI8eYmN(A41nqbj3wYt(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ฺࠧ"),kdRO82AImh0LFw(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪ฻"))
					return zKhToMgRHePwBtVr1da9vn2iX
			else: XFaM94cPUCOWQZNIEe8gdJpny1 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
			kdNn2Zqsj4wPi5ThuoUQvtcg6OA = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
			if ZD0qItXg31HmC7KGEFn[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]!=n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠲࠷ࠧ฼"):
				SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+rVy3Ops0mohYkT(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ฽")+ZD0qItXg31HmC7KGEFn[XFaM94cPUCOWQZNIEe8gdJpny1]+mq5t9JXSdHT8yfDVF(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ฾")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࠡ࡟ࠪ฿"))
		if VP70ytiFNMBl6vHDaW(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩเ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA: kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA+yobpaW7sBqtKRrv(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩแ")
		elif Z9FPQvwlbjLTh(u"ࠪ࡬ࡹࡺࡰࠨโ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA.lower() and ZLr5gRSkFewKdUos90bM(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫใ") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA and yobpaW7sBqtKRrv(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪไ") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA:
			kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA+wwWzyF4ZpSQXKOgk569(u"࠭ࡼࠨๅ") if ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡽࠩๆ") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA else kdNn2Zqsj4wPi5ThuoUQvtcg6OA+gPE1XB87fQl(u"ࠨࠨࠪ็")
			if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃ่ࠧ") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA and IMjqygdfYSKpHlWu5Aa(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳้ࠬ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA.lower(): kdNn2Zqsj4wPi5ThuoUQvtcg6OA += iySORMYxWXszEH18(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠦࠨ๊")
			if mq5t9JXSdHT8yfDVF(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿๋ࠪ") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA.lower() and nzIvkRxy1XtfeDHPjq54pNVG6 not in [bawK2j7T81Nrc4GWs05xzDg(u"࠭ࡉࡑࡖ࡙ࠫ์"),CyHU86ZeYT5BWRcitSm2I(u"ࠧࡎ࠵ࡘࠫํ")]: kdNn2Zqsj4wPi5ThuoUQvtcg6OA += aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ๎")
			if iySORMYxWXszEH18(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫ๏") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA.lower(): kdNn2Zqsj4wPi5ThuoUQvtcg6OA += ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪ๐")
			if yobpaW7sBqtKRrv(u"ࠫࡦࡩࡣࡦࡲࡷ࠱ࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡃࠧ๑") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA.lower(): kdNn2Zqsj4wPi5ThuoUQvtcg6OA += bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫࠽ࡦࡰ࠯ࡥࡷࡁࡱ࠾࠲࠱࠽ࠫ࠭๒")
	SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+beV5l2D8HznyJI0(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ๓")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+pp7FcjEe6g(u"ࠧࠡ࡟ࠪ๔"))
	Xts98ZpCdwDvUqFLghcOfYTAQnN = Zilvh2WQyb5.ListItem()
	Qd2P0tYnV3ghvsKr5oAkeypZuiO7,S7ihvJkRsdMoxYOwHFIb,E2R07n4wK1cLe,NGRWqTjxYXQ5,mbDFTyaWzQOcxA36,mmL9ru6M7zh80DTnkiyKNaB,LaSWb2NcDAvsPqFXzt0,aEJOC7rUle4pnHqFMv,OPIutC5iGTDax = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	if nzIvkRxy1XtfeDHPjq54pNVG6 not in [ZLr5gRSkFewKdUos90bM(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ๕"),yobpaW7sBqtKRrv(u"ࠩࡌࡔ࡙࡜ࠧ๖")]:
		if YVzokG2yZqrh3w8bU: pp8qoI2BAH = beV5l2D8HznyJI0(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭๗")
		else: pp8qoI2BAH = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ๘")
		Xts98ZpCdwDvUqFLghcOfYTAQnN.setProperty(pp8qoI2BAH, WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		Xts98ZpCdwDvUqFLghcOfYTAQnN.setMimeType(yobpaW7sBqtKRrv(u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪ๙"))
		if CCPXJ7wnNLOg0ZoekcmpdSKI<mq5t9JXSdHT8yfDVF(u"࠴࠳༨"): Xts98ZpCdwDvUqFLghcOfYTAQnN.setInfo(tzZ6PhyDOUnwLM3pdK(u"࠭ࡶࡪࡦࡨࡳࠬ๚"),{Z9FPQvwlbjLTh(u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ๛"):QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ࡯ࡲࡺ࡮࡫ࠧ๜")})
		else:
			qNamwd4fHp3xOZteCXYisUh = Xts98ZpCdwDvUqFLghcOfYTAQnN.getVideoInfoTag()
			qNamwd4fHp3xOZteCXYisUh.setMediaType(bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡰࡳࡻ࡯ࡥࠨ๝"))
		Xts98ZpCdwDvUqFLghcOfYTAQnN.setArt({iySORMYxWXszEH18(u"ࠪࡸ࡭ࡻ࡭ࡣࠩ๞"):mbDFTyaWzQOcxA36,SI7eBdND4lx8pt5Qk(u"ࠫࡵࡵࡳࡵࡧࡵࠫ๟"):mbDFTyaWzQOcxA36,Z9FPQvwlbjLTh(u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ๠"):mbDFTyaWzQOcxA36,A41nqbj3wYt(u"࠭ࡦࡢࡰࡤࡶࡹ࠭๡"):mbDFTyaWzQOcxA36,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ๢"):mbDFTyaWzQOcxA36,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ๣"):mbDFTyaWzQOcxA36,gPE1XB87fQl(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ๤"):mbDFTyaWzQOcxA36,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࡭ࡨࡵ࡮ࠨ๥"):mbDFTyaWzQOcxA36})
		if VDbTGIpvEYSedh06oZrxgOCKu5HzjJ in [KLX7hW0nBAEgy6m4SvH(u"ࠫ࠳ࡳࡰࡥࠩ๦"),yobpaW7sBqtKRrv(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ๧")]:
			Xts98ZpCdwDvUqFLghcOfYTAQnN.setContentLookup(r0D4C3z7Onqpa)
			kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA+iySORMYxWXszEH18(u"࠭ࡼࠨ๨") if iySORMYxWXszEH18(u"ࠧࡽࠩ๩") not in kdNn2Zqsj4wPi5ThuoUQvtcg6OA else kdNn2Zqsj4wPi5ThuoUQvtcg6OA.strip(ZLr5gRSkFewKdUos90bM(u"ࠨࠨࠪ๪"))+rVy3Ops0mohYkT(u"ࠩࠩࠫ๫")
			kdNn2Zqsj4wPi5ThuoUQvtcg6OA += aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡖࡦࡴࡧࡦ࠿ࠩࠫ๬")
		else: Xts98ZpCdwDvUqFLghcOfYTAQnN.setContentLookup(KiryBCvngZzF85UN6xSDlOVweL4I9)
		from GkCs6wbiQP import MuryTcfZxnmGwIFUSa104E
		if CyHU86ZeYT5BWRcitSm2I(u"ࠫࡷࡺ࡭ࡱࠩ๭") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA:
			MuryTcfZxnmGwIFUSa104E(mq5t9JXSdHT8yfDVF(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ๮"),KiryBCvngZzF85UN6xSDlOVweL4I9)
		elif VDbTGIpvEYSedh06oZrxgOCKu5HzjJ==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠮࡮ࡲࡧࠫ๯") or ZLr5gRSkFewKdUos90bM(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ๰") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA:
			MuryTcfZxnmGwIFUSa104E(KLX7hW0nBAEgy6m4SvH(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๱"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			Xts98ZpCdwDvUqFLghcOfYTAQnN.setProperty(pp8qoI2BAH,wwWzyF4ZpSQXKOgk569(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๲"))
			Xts98ZpCdwDvUqFLghcOfYTAQnN.setProperty(iySORMYxWXszEH18(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ๳"),VP70ytiFNMBl6vHDaW(u"ࠫࡲࡶࡤࠨ๴"))
		if neVMkPcxCS:
			Xts98ZpCdwDvUqFLghcOfYTAQnN.setSubtitles([neVMkPcxCS])
	if Qd2P0tYnV3ghvsKr5oAkeypZuiO7==tzZ6PhyDOUnwLM3pdK(u"ࠬࡼࡩࡥࡧࡲࠫ๵") and nzIvkRxy1XtfeDHPjq54pNVG6==gPE1XB87fQl(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ๶"):
		zKhToMgRHePwBtVr1da9vn2iX = GHg28TBchiyn6l(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ๷")
		nzIvkRxy1XtfeDHPjq54pNVG6 = A6iX18qgyOFlZxz7sc(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ๸")
	elif Qd2P0tYnV3ghvsKr5oAkeypZuiO7==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๹") and aEJOC7rUle4pnHqFMv.startswith(kdRO82AImh0LFw(u"ࠪ࠺ࠬ๺")):
		zKhToMgRHePwBtVr1da9vn2iX = yobpaW7sBqtKRrv(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ๻")
		nzIvkRxy1XtfeDHPjq54pNVG6 = nzIvkRxy1XtfeDHPjq54pNVG6+iySORMYxWXszEH18(u"ࠬࡥࡄࡍࠩ๼")
	if zKhToMgRHePwBtVr1da9vn2iX!=SI7eBdND4lx8pt5Qk(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫ๽"): OE38lVnF9jRGUAXPzoLIecvMHp()
	k762idONDZqhr4swEKSVaTj0YRIM.ppg8RQerABxnZVPyY3d(nzIvkRxy1XtfeDHPjq54pNVG6)
	if k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W: return jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ๾")
	if Qd2P0tYnV3ghvsKr5oAkeypZuiO7==tzZ6PhyDOUnwLM3pdK(u"ࠨࡸ࡬ࡨࡪࡵࠧ๿") and not aEJOC7rUle4pnHqFMv.startswith(ZLr5gRSkFewKdUos90bM(u"ࠩ࠹ࠫ຀")):
		Xts98ZpCdwDvUqFLghcOfYTAQnN.setPath(kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+iySORMYxWXszEH18(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪກ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࠥࡣࠧຂ"))
		Ydimlc1rVsAnLIhkRyb6aK2.setResolvedUrl(ZTaSobILWiO9ywfN64AVQPzUgKGHX,r0D4C3z7Onqpa,Xts98ZpCdwDvUqFLghcOfYTAQnN)
	elif Qd2P0tYnV3ghvsKr5oAkeypZuiO7==kdRO82AImh0LFw(u"ࠬࡲࡩࡷࡧࠪ຃"):
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩຄ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࠡ࡟ࠪ຅"))
		k762idONDZqhr4swEKSVaTj0YRIM.play(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,Xts98ZpCdwDvUqFLghcOfYTAQnN)
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	if zKhToMgRHePwBtVr1da9vn2iX==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ຆ"):
		from ZZYmwuStjk import PZTLpeBFUV4v
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = PZTLpeBFUV4v(kdNn2Zqsj4wPi5ThuoUQvtcg6OA,VDbTGIpvEYSedh06oZrxgOCKu5HzjJ,nzIvkRxy1XtfeDHPjq54pNVG6)
		if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: OE38lVnF9jRGUAXPzoLIecvMHp()
	else:
		QoZYSAMzNs5uHnGEdC7p,zKhToMgRHePwBtVr1da9vn2iX,NDlRzU8bweEr9,nBKDAsl6edYpfZtN1,SIXJCLts0aTHvPKDYmG4fcg9inxl = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,mq5t9JXSdHT8yfDVF(u"ࠩࡷࡶ࡮࡫ࡤࠨງ"),KiryBCvngZzF85UN6xSDlOVweL4I9,A41nqbj3wYt(u"࠵࠵࠶࠰༪"),A6iX18qgyOFlZxz7sc(u"࠷࠹࠵࠶࠰༩")
		if jiXoSurBHAe6xC7: import yBR5QHGdUT
		while QoZYSAMzNs5uHnGEdC7p<SIXJCLts0aTHvPKDYmG4fcg9inxl:
			pYDdXfVh5c0O1bMT6a78HKBiQw3.sleep(nBKDAsl6edYpfZtN1)
			QoZYSAMzNs5uHnGEdC7p += nBKDAsl6edYpfZtN1
			if k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W==yobpaW7sBqtKRrv(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫຈ") and not NDlRzU8bweEr9:
				if jiXoSurBHAe6xC7: yBR5QHGdUT.uTaiRMI8eYmN(iySORMYxWXszEH18(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨຉ"),pp7FcjEe6g(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ຊ"),x54xSdnCFHZ8yliofzOBK=oiWNFYzcIUeh(u"࠼࠻࠰༫"))
				SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+pp7FcjEe6g(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ຋")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+iySORMYxWXszEH18(u"ࠧࠡ࡟ࠪຌ")+yyFX5QeiSTAL4K0MDPdtWmhNRgEj)
				NDlRzU8bweEr9 = r0D4C3z7Onqpa
			elif k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W in [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩຍ"),A41nqbj3wYt(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪຎ")]:
				SWPHEjbmMfZDpi(W2AGj9rwD0dviCE5Q7BtO,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧຏ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࠥࡣࠧຐ")+yyFX5QeiSTAL4K0MDPdtWmhNRgEj)
				break
			elif k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W==yobpaW7sBqtKRrv(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬຑ"):
				SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+YYQS36fyPvtuzcEmRL(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧຒ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+rVy3Ops0mohYkT(u"ࠧࠡ࡟ࠪຓ")+yyFX5QeiSTAL4K0MDPdtWmhNRgEj)
				if jiXoSurBHAe6xC7: yBR5QHGdUT.uTaiRMI8eYmN(VP70ytiFNMBl6vHDaW(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬດ"),wwWzyF4ZpSQXKOgk569(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪຕ"),x54xSdnCFHZ8yliofzOBK=QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠽࠵࠱༬"))
				break
			elif k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W==oiWNFYzcIUeh(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫຖ"):
				SWPHEjbmMfZDpi(U3Us1pqh6TY,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+wwWzyF4ZpSQXKOgk569(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩທ")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࠦ࡝ࠨຘ"))
				break
		else: zKhToMgRHePwBtVr1da9vn2iX = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧນ")
	if zKhToMgRHePwBtVr1da9vn2iX in [A41nqbj3wYt(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧບ")] or k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W in [gPE1XB87fQl(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩປ"),VP70ytiFNMBl6vHDaW(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪຜ")] or FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: JIpyGT2ZQ9lqoDinAB(nzIvkRxy1XtfeDHPjq54pNVG6)
	else: exec(CyHU86ZeYT5BWRcitSm2I(u"ࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡼࡧࡳࡣ࠼ࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨຝ"))
	iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying()
	if not iH7pE9rXVqy5k1Uu and zKhToMgRHePwBtVr1da9vn2iX not in [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩພ")]:
		msg = I872Vum45fMNe1BRngTZLoQiqvkt(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ຟ") if zKhToMgRHePwBtVr1da9vn2iX==A6iX18qgyOFlZxz7sc(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧຠ") else lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨມ")
		if jiXoSurBHAe6xC7: yBR5QHGdUT.uTaiRMI8eYmN(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬຢ"),msg,x54xSdnCFHZ8yliofzOBK=beV5l2D8HznyJI0(u"࠷࠶࠲༭"))
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠣࠤࠥ࠭ຣ")+msg+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭຤")+kdNn2Zqsj4wPi5ThuoUQvtcg6OA+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࠥࡣࠧລ")+yyFX5QeiSTAL4K0MDPdtWmhNRgEj)
	return k762idONDZqhr4swEKSVaTj0YRIM.gFk2xIPvn18W
def mm19wY7OfIvCxb8AFZEHJ(kdNn2Zqsj4wPi5ThuoUQvtcg6OA):
	if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡅࠧ຦") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA: kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࠿ࠨວ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡽࠩຨ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA: kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(rVy3Ops0mohYkT(u"ࠨࡾࠪຩ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	path = yobpaW7sBqtKRrv(u"ࠩ࠲ࠫສ").join(kdNn2Zqsj4wPi5ThuoUQvtcg6OA.split(A41nqbj3wYt(u"ࠪ࠳ࠬຫ"))[yobpaW7sBqtKRrv(u"࠴༮"):]) if GHg28TBchiyn6l(u"ࠫ࠿࠵࠯ࠨຬ") in kdNn2Zqsj4wPi5ThuoUQvtcg6OA else kdNn2Zqsj4wPi5ThuoUQvtcg6OA
	YYwPoJRIvz1DWQKcUmd0HqFNG = p7dwlH1PRStBgyMUW.findall(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡢ࠮ࠩ࡝ࡤ࠱ࡿ࠶࠭࠺࡟ࡾ࠶࠱࠺ࡽࠪࠩອ"),path,p7dwlH1PRStBgyMUW.DOTALL)
	if YYwPoJRIvz1DWQKcUmd0HqFNG:
		YYwPoJRIvz1DWQKcUmd0HqFNG = YYwPoJRIvz1DWQKcUmd0HqFNG[-wnaWTQM7VJPkZzO9eoSyFU4]
		Vr8MAGhvCDFaiJEWYTBfc1Zw = [A6iX18qgyOFlZxz7sc(u"࠭࡭࠴ࡷ࠻ࠫຮ"),YYQS36fyPvtuzcEmRL(u"ࠧ࡮ࡲ࠷ࠫຯ"),KLX7hW0nBAEgy6m4SvH(u"ࠨ࡯ࡳࡨࠬະ"),YYQS36fyPvtuzcEmRL(u"ࠩࡺࡩࡧࡳࠧັ"),oiWNFYzcIUeh(u"ࠪࡥࡻ࡯ࠧາ"),SI7eBdND4lx8pt5Qk(u"ࠫࡦࡧࡣࠨຳ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡳ࠳ࡶࠩິ"),KLX7hW0nBAEgy6m4SvH(u"࠭࡭࡬ࡸࠪີ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠧࡧ࡮ࡹࠫຶ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࡯ࡳ࠷ࠬື"),oiWNFYzcIUeh(u"ࠩࡷࡷຸࠬ")]
		if YYwPoJRIvz1DWQKcUmd0HqFNG in Vr8MAGhvCDFaiJEWYTBfc1Zw: return ZLr5gRSkFewKdUos90bM(u"ࠪ࠲ູࠬ")+YYwPoJRIvz1DWQKcUmd0HqFNG
	return WnNGfosHr5STAq8j7miwyRZ6eOUbV
def JIpyGT2ZQ9lqoDinAB(zE4XRrjSYK):
	if not A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI: zE4XRrjSYK += ZLr5gRSkFewKdUos90bM(u"ࠫࡤ࡚ࡓࠨ຺")
	A3pXVFdyP1.SEND_THESE_EVENTS.append(zE4XRrjSYK)
	return
def sm0xF8WoGavE7iNjd(NCguSrdnXciRtFkUpv8Y12lMwAVW0=KiryBCvngZzF85UN6xSDlOVweL4I9):
	HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(IMjqygdfYSKpHlWu5Aa(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬົ"))
	nnKlvfXN2Jqiaw6FxT(NCguSrdnXciRtFkUpv8Y12lMwAVW0,KLX7hW0nBAEgy6m4SvH(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩຼ"))
	SZ0YL6RpbX.exit()
def nnKlvfXN2Jqiaw6FxT(NCguSrdnXciRtFkUpv8Y12lMwAVW0,C2nN35DILUFzEKqv0BPl4eZjH6):
	if C2nN35DILUFzEKqv0BPl4eZjH6:
		if pp7FcjEe6g(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪຽ") in C2nN35DILUFzEKqv0BPl4eZjH6: SWPHEjbmMfZDpi(WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫ຾"))
		else:
			f7EY5yTIcRWlqj = G3yDpvxOiSWdAeL.getSetting(wwWzyF4ZpSQXKOgk569(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ຿"))
			G3yDpvxOiSWdAeL.setSetting(YYQS36fyPvtuzcEmRL(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫເ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			import UdvL4wSQeI
			UdvL4wSQeI.JLyFwgKhoPdND9cMk(C2nN35DILUFzEKqv0BPl4eZjH6)
			G3yDpvxOiSWdAeL.setSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬແ"),f7EY5yTIcRWlqj)
	rLEuTzBs2HFXjeSyfvCZcQw4O = G3yDpvxOiSWdAeL.getSetting(iySORMYxWXszEH18(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩໂ"))
	if rLEuTzBs2HFXjeSyfvCZcQw4O==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧໃ"): G3yDpvxOiSWdAeL.setSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫໄ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ໅"))
	elif rLEuTzBs2HFXjeSyfvCZcQw4O==tzZ6PhyDOUnwLM3pdK(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩໆ"): G3yDpvxOiSWdAeL.setSetting(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ໇"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if G3yDpvxOiSWdAeL.getSetting(ZLr5gRSkFewKdUos90bM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹ່ࠧ")) not in [Z9FPQvwlbjLTh(u"ࠬࡇࡕࡕࡑ້ࠪ"),A41nqbj3wYt(u"࠭ࡓࡕࡑࡓ໊ࠫ"),VP70ytiFNMBl6vHDaW(u"ࠧࡂࡕࡎ໋ࠫ")]: G3yDpvxOiSWdAeL.setSetting(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ໌"),pp7FcjEe6g(u"ࠩࡄࡗࡐ࠭ໍ"))
	if G3yDpvxOiSWdAeL.getSetting(ZLr5gRSkFewKdUos90bM(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ໎")) not in [n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫࡆ࡛ࡔࡐࠩ໏"),CyHU86ZeYT5BWRcitSm2I(u"࡙ࠬࡔࡐࡒࠪ໐"),YYQS36fyPvtuzcEmRL(u"࠭ࡁࡔࡍࠪ໑")]: G3yDpvxOiSWdAeL.setSetting(wwWzyF4ZpSQXKOgk569(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ໒"),wwWzyF4ZpSQXKOgk569(u"ࠨࡃࡖࡏࠬ໓"))
	FoqnfCDW94506bec = G3yDpvxOiSWdAeL.getSetting(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ໔"))
	NnA5Md0F2SvJQ = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭໕"))
	if KLX7hW0nBAEgy6m4SvH(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ໖") in str(NnA5Md0F2SvJQ) and FoqnfCDW94506bec in [jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ໗"),ZLr5gRSkFewKdUos90bM(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ໘")]:
		x54xSdnCFHZ8yliofzOBK.sleep(rVy3Ops0mohYkT(u"࠲࠱࠵࠵࠶༯"))
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(wwWzyF4ZpSQXKOgk569(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡗࡪࡺࡖࡪࡧࡺࡑࡴࡪࡥࠩ࠲ࠬࠫ໙"))
	if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and ZTaSobILWiO9ywfN64AVQPzUgKGHX>-wnaWTQM7VJPkZzO9eoSyFU4:
		Ydimlc1rVsAnLIhkRyb6aK2.setResolvedUrl(ZTaSobILWiO9ywfN64AVQPzUgKGHX,KiryBCvngZzF85UN6xSDlOVweL4I9,Zilvh2WQyb5.ListItem())
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe = KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9
		Ydimlc1rVsAnLIhkRyb6aK2.endOfDirectory(ZTaSobILWiO9ywfN64AVQPzUgKGHX,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe)
	if A3pXVFdyP1.SEND_THESE_EVENTS: P92i4pcKGaCYt0V6Sonw(A3pXVFdyP1.SEND_THESE_EVENTS)
	jKhU0NZmytiQu45T12YFCoJWsc = lLcJwOK2p7TvQyqbsdRFiI()
	EOMr9e5BFQToPJvnphc1Ii3Vf8KHl(oiWNFYzcIUeh(u"ࠨࡵࡷࡳࡵ࠭໚"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	if jKhU0NZmytiQu45T12YFCoJWsc and not A3pXVFdyP1.resolveonly:
		A3pXVFdyP1.resolveonly = r0D4C3z7Onqpa
		iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying()
		if not iH7pE9rXVqy5k1Uu: HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩ໛"))
		else:
			Jb0lwDZx1tB = XcrfxTPnECkUdimbuAz()
			if Jb0lwDZx1tB:
				import UdvL4wSQeI,yBR5QHGdUT
				for VV60kArCYGvUWNOLymTJze in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,JI0HOPTBW23K9VdACvMcjYrX,vXIdY7TwFKso40gVBq5):
					x54xSdnCFHZ8yliofzOBK.sleep(vXIdY7TwFKso40gVBq5)
					iH7pE9rXVqy5k1Uu = pYDdXfVh5c0O1bMT6a78HKBiQw3.Player().isPlaying()
					if not iH7pE9rXVqy5k1Uu:
						yBR5QHGdUT.uTaiRMI8eYmN(ZLr5gRSkFewKdUos90bM(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫໜ"),yobpaW7sBqtKRrv(u"ࠫสฺ๊ศรࠣๅา฻ࠠศๆึ๎ึ็ัศฬࠪໝ"),x54xSdnCFHZ8yliofzOBK=ZLr5gRSkFewKdUos90bM(u"࠸࠴࠵༰"))
						break
				else:
					G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = UbF7JxE84r2D(Jb0lwDZx1tB)
					if not any(value in VkEQdztnmeH for value in UdvL4wSQeI.NOT_TO_TEST_ALL_SERVERS):
						yBR5QHGdUT.uTaiRMI8eYmN(ZLr5gRSkFewKdUos90bM(u"ࠬอไโ์า๎ํࠦวๅๆสั็࠭ໞ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭แฮืࠣะ๊๐ูࠡษ็ื๏ืแาษอࠫໟ"),x54xSdnCFHZ8yliofzOBK=CyHU86ZeYT5BWRcitSm2I(u"࠻࠺࠶༱"))
						x54xSdnCFHZ8yliofzOBK.sleep(XURrDCfOS9Mbhpv2Pmjos56TeW)
						if YVzokG2yZqrh3w8bU:
							kdNn2Zqsj4wPi5ThuoUQvtcg6OA = kdNn2Zqsj4wPi5ThuoUQvtcg6OA.encode(e87cIA5vwOQLDEP1)
						UdvL4wSQeI.OO7gEdhG2U3x6ucLvKoVJyfPRNrk(z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd)
						APpdhB1Fk58MmJH7CjVntowyaY = UdvL4wSQeI.NNFPsWDgoE(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
						UdvL4wSQeI.OO7gEdhG2U3x6ucLvKoVJyfPRNrk(xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83)
						yBR5QHGdUT.uTaiRMI8eYmN(CyHU86ZeYT5BWRcitSm2I(u"ࠧศๆไ๎ิ๐่ࠡษ็่ฬำโࠨ໠"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨษ้ฮ์๏ࠠโฯุࠤฬ๊ำ๋ำไีฬะࠧ໡"),x54xSdnCFHZ8yliofzOBK=rVy3Ops0mohYkT(u"࠼࠻࠰༲"))
						NCguSrdnXciRtFkUpv8Y12lMwAVW0 = KiryBCvngZzF85UN6xSDlOVweL4I9
	IISWAzUg18xVsPiNykMh2ce4JXEKZY = G3yDpvxOiSWdAeL.getSetting(KLX7hW0nBAEgy6m4SvH(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭໢"))
	if I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠱ࠬ໣") in IISWAzUg18xVsPiNykMh2ce4JXEKZY:
		IISWAzUg18xVsPiNykMh2ce4JXEKZY = IISWAzUg18xVsPiNykMh2ce4JXEKZY.replace(mq5t9JXSdHT8yfDVF(u"ࠫ࠲࠭໤"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		G3yDpvxOiSWdAeL.setSetting(YYQS36fyPvtuzcEmRL(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ໥"),IISWAzUg18xVsPiNykMh2ce4JXEKZY)
	if NCguSrdnXciRtFkUpv8Y12lMwAVW0: pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ໦"))
	return
def XcrfxTPnECkUdimbuAz():
	FSuEUQzYDed2xR8aChX = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡉࡨࡸࡎࡺࡥ࡮ࡵࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ࠺࡜ࠤࡷ࡭ࡹࡲࡥࠣ࠮ࠥࡪ࡮ࡲࡥࠣ࠮ࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࡝ࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪ໧"))
	APpdhB1Fk58MmJH7CjVntowyaY = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(FSuEUQzYDed2xR8aChX)[jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨࡴࡨࡷࡺࡲࡴࠨ໨")]
	Jb0lwDZx1tB = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	try: items = APpdhB1Fk58MmJH7CjVntowyaY[kdRO82AImh0LFw(u"ࠩ࡬ࡸࡪࡳࡳࠨ໩")]
	except: return WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if items:
		for L3LoVh5B7OZMbHJlPXQ6EjnaUks,file in enumerate(items):
			path = file[XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡪ࡮ࡲࡥࠨ໪")]
			if B40Qr5hlSgNm1kuXD3ZFpnyC9 not in path: continue
			path = path.split(B40Qr5hlSgNm1kuXD3ZFpnyC9)[wnaWTQM7VJPkZzO9eoSyFU4][wnaWTQM7VJPkZzO9eoSyFU4:]
			if path==oobgjl3xWaBeRZF8wdzKYAvtus: break
		count = APpdhB1Fk58MmJH7CjVntowyaY[beV5l2D8HznyJI0(u"ࠫࡱ࡯࡭ࡪࡶࡶࠫ໫")][ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡺ࡯ࡵࡣ࡯ࠫ໬")]
		if L3LoVh5B7OZMbHJlPXQ6EjnaUks+wnaWTQM7VJPkZzO9eoSyFU4<count: Jb0lwDZx1tB = items[L3LoVh5B7OZMbHJlPXQ6EjnaUks+wnaWTQM7VJPkZzO9eoSyFU4][mq5t9JXSdHT8yfDVF(u"࠭ࡦࡪ࡮ࡨࠫ໭")]
	return Jb0lwDZx1tB
def lLcJwOK2p7TvQyqbsdRFiI():
	HeAw9Xf6QCp0uJ1bRvlmi = pYDdXfVh5c0O1bMT6a78HKBiQw3.executeJSONRPC(mq5t9JXSdHT8yfDVF(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࡽࡾࠩ໮"))
	pxRyjXsvqCfbDlkgLFBU0YE = KiryBCvngZzF85UN6xSDlOVweL4I9 if n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࡝ࡠࠫ໯") in str(HeAw9Xf6QCp0uJ1bRvlmi) else r0D4C3z7Onqpa
	return pxRyjXsvqCfbDlkgLFBU0YE
def EOMr9e5BFQToPJvnphc1Ii3Vf8KHl(Scj89eR1gGky,sE3XkMiS1NJautgqLCevmF=KiryBCvngZzF85UN6xSDlOVweL4I9):
	if Scj89eR1gGky==aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡶࡸࡴࡶࠧ໰") and (sE3XkMiS1NJautgqLCevmF or A3pXVFdyP1.busydialog_active):
		if sE3XkMiS1NJautgqLCevmF: pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(YYQS36fyPvtuzcEmRL(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ໱"))
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(iySORMYxWXszEH18(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠪࠩ໲"))
		A3pXVFdyP1.busydialog_active = KiryBCvngZzF85UN6xSDlOVweL4I9
	if Scj89eR1gGky==gPE1XB87fQl(u"ࠬࡹࡴࡢࡴࡷࠫ໳") and (sE3XkMiS1NJautgqLCevmF or not A3pXVFdyP1.busydialog_active):
		Fm06lEY1pweOb8GnH = oiWNFYzcIUeh(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫ໴") if CCPXJ7wnNLOg0ZoekcmpdSKI>kdRO82AImh0LFw(u"࠷࠷࠯࠻࠼༳") else A6iX18qgyOFlZxz7sc(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫ໵")
		pYDdXfVh5c0O1bMT6a78HKBiQw3.executebuiltin(iySORMYxWXszEH18(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪ໶")+Fm06lEY1pweOb8GnH+beV5l2D8HznyJI0(u"ࠩࠬࠫ໷"))
		A3pXVFdyP1.busydialog_active = r0D4C3z7Onqpa
	return
def vpPaQ6ewzRTEK(*args,**CfYTkiPHgqX0rtcO):
	daemon = CfYTkiPHgqX0rtcO.pop(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪࡨࡦ࡫࡭ࡰࡰࠪ໸"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	Qja7l4ygF8fmBruVW32bNRZIU = IWpE1hYkGCBeH.Thread(*args,**CfYTkiPHgqX0rtcO)
	Qja7l4ygF8fmBruVW32bNRZIU.daemon = daemon
	return Qja7l4ygF8fmBruVW32bNRZIU
KnuJvBMTRVijF9r7AwDg1Gtl4 = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡱ࡯ࡳࡵࠩ໹"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ໺"),A6iX18qgyOFlZxz7sc(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫ໻"))
if KnuJvBMTRVijF9r7AwDg1Gtl4:
	aCOJgMGfijpx625IYB4,NCWt9oBJPkSl,biHxSjd9XzpC1c4P,JJfZAypur1CaNoqjd2w = KnuJvBMTRVijF9r7AwDg1Gtl4
	A3pXVFdyP1.AV_CLIENT_IDS = WBDnh75CaLEvkcN6p4ez2KXrV3M.join(aCOJgMGfijpx625IYB4)
if not A3pXVFdyP1.AV_CLIENT_IDS: A3pXVFdyP1.AV_CLIENT_IDS = kNR9wHFiUYQntWAly()
k762idONDZqhr4swEKSVaTj0YRIM = ffzcAnsvhkOlpLoQwFSY8D4xMW()
A3pXVFdyP1.bWV7czPeIaq,A3pXVFdyP1.vyjRrVMHQX7UNYcmC3ZFsGPlDu9AOI,A3pXVFdyP1.IImTyNn2dP,A3pXVFdyP1.IMAvyqd5QL60a,A3pXVFdyP1.avprivsnorestrict,A3pXVFdyP1.avprivslongperiod = ttz1broY9LTy35uAh0wQPVDEca([bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ໼"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩ໽"),pp7FcjEe6g(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ໾"),yobpaW7sBqtKRrv(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ໿"),Z9FPQvwlbjLTh(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡰࡲࡄࡗࡇ࡙ࡉ࡝࠭ༀ"),CyHU86ZeYT5BWRcitSm2I(u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ༁")])
WW3PiLNaxCY = A3pXVFdyP1.AV_CLIENT_IDS.splitlines()[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][-aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠲࠵༴"):]