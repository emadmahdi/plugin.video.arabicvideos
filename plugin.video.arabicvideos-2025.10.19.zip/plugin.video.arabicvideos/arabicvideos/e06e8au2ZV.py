# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
TTOAERW9IMB045fQt7wnjrymKZGHN = 'IPTV'
utGmJTNWUpy9KnVf1hd = '_IPT_'
yrl3fU0XCvk6q = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def uWyz2Omi3rGH9vsfTDg(HOkAWvmZSP5c2t9Dq4NgELyps,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j,t0xkM74rgEAFIepSWXilNOGDn,BfYlvNejqzRc2PDdFiAV9,rBSIjX6x2FVTgOeG4CREKfUq):
	global utGmJTNWUpy9KnVf1hd
	try:
		NLMU9xZPkX4t168usGzqSBfQCAJHg = str(rBSIjX6x2FVTgOeG4CREKfUq['folder'])
		utGmJTNWUpy9KnVf1hd = '_IP'+NLMU9xZPkX4t168usGzqSBfQCAJHg+'_'
	except: NLMU9xZPkX4t168usGzqSBfQCAJHg = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if   HOkAWvmZSP5c2t9Dq4NgELyps==230: ww9PixygdMfDQJt = Jhm7YwaZXc6sAu2Hf()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==231: ww9PixygdMfDQJt = qIKy9ReSwsDpNYtXiT5FbLVlMUEJgG(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==232: ww9PixygdMfDQJt = rowtemU0HSaObTYXf74D(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==233: ww9PixygdMfDQJt = T3TJbgU6X1PzdENmp(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j,BfYlvNejqzRc2PDdFiAV9)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==234: ww9PixygdMfDQJt = f28uNr4CYyMqT(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j,BfYlvNejqzRc2PDdFiAV9)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==235: ww9PixygdMfDQJt = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,t0xkM74rgEAFIepSWXilNOGDn)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==236: ww9PixygdMfDQJt = noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,True)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==237: ww9PixygdMfDQJt = KJTcA2MurdEBbz(NLMU9xZPkX4t168usGzqSBfQCAJHg,True)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==238: ww9PixygdMfDQJt = qBy4PZCz8piFhIQW1gK7Md03o(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==239: ww9PixygdMfDQJt = pBzAsvx3aVgUWSnyrH0(ZVk6IphECKLzUceP15j,NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,BfYlvNejqzRc2PDdFiAV9)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==280: ww9PixygdMfDQJt = Hkr4wlnZ5Iobuf0ASYx(NLMU9xZPkX4t168usGzqSBfQCAJHg,True)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==281: ww9PixygdMfDQJt = J3yzhQaVZgSseEtDqu1r2xlnoUP(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==282: ww9PixygdMfDQJt = GoOJD5FtqyeTZNLWhcP4kKa(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==283: ww9PixygdMfDQJt = npTzM8qfJEHjl3(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==285: ww9PixygdMfDQJt = S9FRyAWhGEpf8(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==286: ww9PixygdMfDQJt = WWrPGCYqv3VOEyJ9TSbHt(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==289: ww9PixygdMfDQJt = twlMRiYrqHQSmcZpKB2gfbD6(ZVk6IphECKLzUceP15j,NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,BfYlvNejqzRc2PDdFiAV9)
	else: ww9PixygdMfDQJt = False
	return ww9PixygdMfDQJt
def Jhm7YwaZXc6sAu2Hf():
	for NLMU9xZPkX4t168usGzqSBfQCAJHg in range(1,ekgSRBGHWzUI5MqNDQV190ay8LonOp+1):
		utGmJTNWUpy9KnVf1hd = '_IP'+str(NLMU9xZPkX4t168usGzqSBfQCAJHg)+'_'
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قائمة مجلد '+ww07SKUt2HgnRG[NLMU9xZPkX4t168usGzqSBfQCAJHg],WnNGfosHr5STAq8j7miwyRZ6eOUbV,280,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	return
def Hkr4wlnZ5Iobuf0ASYx(NLMU9xZPkX4t168usGzqSBfQCAJHg=WnNGfosHr5STAq8j7miwyRZ6eOUbV,P3MDcw5Ln182FoqAVpZ=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if NLMU9xZPkX4t168usGzqSBfQCAJHg:
		K9DzoIRs3AMBhYefLNxQbtH = {'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}
		iJ8kecmy3GgAv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else:
		K9DzoIRs3AMBhYefLNxQbtH = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		iJ8kecmy3GgAv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	CHcKtrzwm7WfL5gXEy8SRY9iMO = iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ)
	if not CHcKtrzwm7WfL5gXEy8SRY9iMO:
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+' إضافة أو تغيير اشتراك'+iJ8kecmy3GgAv+' '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,231,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+' جلب ملفات'+iJ8kecmy3GgAv+' '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,232,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	else:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'بحث في الملفات'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,289,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_',WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مصنفة مرتبة'+iJ8kecmy3GgAv,'LIVE_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مصنفة من القسم'+iJ8kecmy3GgAv,'LIVE_FROM_GROUP_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مصنفة من الاسم'+iJ8kecmy3GgAv,'LIVE_FROM_NAME_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مصنفة بلا ترتيب'+iJ8kecmy3GgAv,'LIVE_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات بلا ترتيب'+iJ8kecmy3GgAv,'LIVE_ORIGINAL_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مجهولة مرتبة'+iJ8kecmy3GgAv,'LIVE_UNKNOWN_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'قنوات مجهولة بلا ترتيب'+iJ8kecmy3GgAv,'LIVE_UNKNOWN_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أفلام مصنفة بلا ترتيب'+iJ8kecmy3GgAv,'VOD_MOVIES_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أفلام مصنفة مرتبة'+iJ8kecmy3GgAv,'VOD_MOVIES_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'مسلسلات مصنفة بلا ترتيب'+iJ8kecmy3GgAv,'VOD_SERIES_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'مسلسلات مصنفة مرتبة'+iJ8kecmy3GgAv,'VOD_SERIES_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'فيديوهات بلا ترتيب'+iJ8kecmy3GgAv,'VOD_ORIGINAL_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'فيديوهات مصنفة من القسم'+iJ8kecmy3GgAv,'VOD_FROM_GROUP_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'فيديوهات مصنفة من الاسم'+iJ8kecmy3GgAv,'VOD_FROM_NAME_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'فيديوهات مجهولة بلا ترتيب'+iJ8kecmy3GgAv,'VOD_UNKNOWN_GROUPED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'فيديوهات مجهولة مرتبة'+iJ8kecmy3GgAv,'VOD_UNKNOWN_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'برامج القنوات (جدول فقط)'+iJ8kecmy3GgAv,'LIVE_EPG_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أرشيف القنوات للأيام الماضية'+iJ8kecmy3GgAv,'LIVE_TIMESHIFT_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أرشيف برامج القنوات للأيام الماضية'+iJ8kecmy3GgAv,'LIVE_ARCHIVED_GROUPED_SORTED',233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'إضافة أو تغيير اشتراك'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,231,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'جلب ملفات'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,232,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'مسح ملفات'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,237,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'فحص اشتراك'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,236,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'عدد فيديوهات'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,281,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'Referer تغيير'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,286,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'User-Agent تغيير'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,283,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+'استخدم السيرفر الأسرع'+iJ8kecmy3GgAv,WnNGfosHr5STAq8j7miwyRZ6eOUbV,282,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,K9DzoIRs3AMBhYefLNxQbtH)
	return
def noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ=True):
	LrI0tlRwEBoc1KNHJq,quf4e29OzNGHU6FwdZlhr0KkRxyX = False,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3 = qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if HyYITOrjQqS6==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = sLZa8dgblSKP6WFMtYjrAw1(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if ZnFkGo4Jb0RC5z32WwdD89cQAjeSa:
		lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET',ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-CHECK_ACCOUNT-1st')
		lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
		if lAJu8dmbEUPZjrIahBH.succeeded:
			DB2dZPX0NOLv31Vw6TFUA57kzKI,atXzlbn4hYrQMRf9vPB50EeoZS,RACxvMH84JkP,Px1Zy9IVDMSWUumO5dcKYTjC,E7VwuFgc4QS8l3KjCAf6zJkipLe = 0,0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
			try:
				nWl9L4irPZkUt3eXN = IXZpzK7ShaRsAN('dict',lXqaJs1WkUZ9Rz0)
				quf4e29OzNGHU6FwdZlhr0KkRxyX = nWl9L4irPZkUt3eXN['user_info']['status']
				LrI0tlRwEBoc1KNHJq = True
				RACxvMH84JkP = nWl9L4irPZkUt3eXN['server_info']['time_now']
			except: pass
			if RACxvMH84JkP:
				try:
					CkcpouQ9b2sXqOxBUjVTKZiWJL = x54xSdnCFHZ8yliofzOBK.strptime(RACxvMH84JkP,'%Y.%m.%d %H:%M:%S')
					DB2dZPX0NOLv31Vw6TFUA57kzKI = int(x54xSdnCFHZ8yliofzOBK.mktime(CkcpouQ9b2sXqOxBUjVTKZiWJL))
					atXzlbn4hYrQMRf9vPB50EeoZS = int(jDuxzCtBH7aihsSL9-DB2dZPX0NOLv31Vw6TFUA57kzKI)
					atXzlbn4hYrQMRf9vPB50EeoZS = int((atXzlbn4hYrQMRf9vPB50EeoZS+900)/1800)*1800
				except: pass
				try:
					CkcpouQ9b2sXqOxBUjVTKZiWJL = x54xSdnCFHZ8yliofzOBK.localtime(int(nWl9L4irPZkUt3eXN['user_info']['created_at']))
					Px1Zy9IVDMSWUumO5dcKYTjC = x54xSdnCFHZ8yliofzOBK.strftime('%Y.%m.%d %H:%M:%S',CkcpouQ9b2sXqOxBUjVTKZiWJL)
				except: pass
				try:
					CkcpouQ9b2sXqOxBUjVTKZiWJL = x54xSdnCFHZ8yliofzOBK.localtime(int(nWl9L4irPZkUt3eXN['user_info']['exp_date']))
					E7VwuFgc4QS8l3KjCAf6zJkipLe = x54xSdnCFHZ8yliofzOBK.strftime('%Y.%m.%d %H:%M:%S',CkcpouQ9b2sXqOxBUjVTKZiWJL)
				except: pass
			G3yDpvxOiSWdAeL.setSetting('av.iptv.timestamp_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,str(jDuxzCtBH7aihsSL9))
			G3yDpvxOiSWdAeL.setSetting('av.iptv.timediff_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,str(atXzlbn4hYrQMRf9vPB50EeoZS))
			try:
				J6O2IsjKCRbiHqtmkBNU1 = '"server_info":'+lXqaJs1WkUZ9Rz0.split('"server_info":')[1]
				J6O2IsjKCRbiHqtmkBNU1 = J6O2IsjKCRbiHqtmkBNU1.replace(':',': ').replace(',',', ').replace('}}','}')
				JX27tBqhredubDF3VEvL8GiYZ = p7dwlH1PRStBgyMUW.findall('"url": "(.*?)", "port": "(.*?)"',J6O2IsjKCRbiHqtmkBNU1,p7dwlH1PRStBgyMUW.DOTALL)
				zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = JX27tBqhredubDF3VEvL8GiYZ[0]
			except: LrI0tlRwEBoc1KNHJq = False
			if LrI0tlRwEBoc1KNHJq and P3MDcw5Ln182FoqAVpZ:
				max = nWl9L4irPZkUt3eXN['user_info']['max_connections']
				cAHGVB7F039yO2DY4fTILjrK = nWl9L4irPZkUt3eXN['user_info']['active_cons']
				s5iuAvZ6BmlSXK18wR0hcoLNyFgpe = nWl9L4irPZkUt3eXN['user_info']['is_trial']
				iABmLXITuGpZ15lh = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa.split('?',1)
				eJU6bsndE1mI0F = 'URL:  '+e6HEdvUcaq8Gx+ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\n\nStatus:  '+e6HEdvUcaq8Gx+quf4e29OzNGHU6FwdZlhr0KkRxyX+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\nTrial:    '+e6HEdvUcaq8Gx+str(s5iuAvZ6BmlSXK18wR0hcoLNyFgpe=='1')+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\nCreated  At:  '+e6HEdvUcaq8Gx+Px1Zy9IVDMSWUumO5dcKYTjC+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\nExpiry Date:  '+e6HEdvUcaq8Gx+E7VwuFgc4QS8l3KjCAf6zJkipLe+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\nConnections   ( Active / Maximum ) :  '+e6HEdvUcaq8Gx+cAHGVB7F039yO2DY4fTILjrK+' / '+max+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\nAllowed Outputs:   '+e6HEdvUcaq8Gx+" , ".join(nWl9L4irPZkUt3eXN['user_info']['allowed_output_formats'])+YVr6St5P4xsFC0aARQGKfiegD
				eJU6bsndE1mI0F += '\n\n'+J6O2IsjKCRbiHqtmkBNU1
				if quf4e29OzNGHU6FwdZlhr0KkRxyX=='Active': oEncafdG6UxR50yCutSAjklYvD3T4('الاشتراك يعمل بدون مشاكل',eJU6bsndE1mI0F)
				else: oEncafdG6UxR50yCutSAjklYvD3T4('يبدو أن هناك مشكلة في الاشتراك',eJU6bsndE1mI0F)
	if ZnFkGo4Jb0RC5z32WwdD89cQAjeSa and LrI0tlRwEBoc1KNHJq and quf4e29OzNGHU6FwdZlhr0KkRxyX=='Active':
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+' ]')
		pw8aLc3HTqMVWQO21yt6zfub = True
	else:
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,'Checking IPTV URL   [ Does not work ]   [ '+ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+' ]')
		if P3MDcw5Ln182FoqAVpZ: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		pw8aLc3HTqMVWQO21yt6zfub = False
	return pw8aLc3HTqMVWQO21yt6zfub,zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1
def f28uNr4CYyMqT(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj,xCwozyfBtFKOSGqDYQIrRbPaiWv03,DHgfWI8yeZ6h1jq7xdwT2ABM,P3MDcw5Ln182FoqAVpZ=True):
	if not DHgfWI8yeZ6h1jq7xdwT2ABM: DHgfWI8yeZ6h1jq7xdwT2ABM = '1'
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ): return
	HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj)
	VbxSkQef8wj = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list',atXHKyxrnefOId1wj,xCwozyfBtFKOSGqDYQIrRbPaiWv03)
	WvMYcq13AOl = int(DHgfWI8yeZ6h1jq7xdwT2ABM)*100
	MpimvHudO63f1CTcSL5 = WvMYcq13AOl-100
	for EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 in VbxSkQef8wj[MpimvHudO63f1CTcSL5:WvMYcq13AOl]:
		LZVsiu43PBxwtWTQjN0K25pIh = ('GROUPED' in atXHKyxrnefOId1wj or atXHKyxrnefOId1wj=='ALL')
		h0A9UrLa7Xx4jJwSzgoOk = ('GROUPED' not in atXHKyxrnefOId1wj and atXHKyxrnefOId1wj!='ALL')
		if LZVsiu43PBxwtWTQjN0K25pIh or h0A9UrLa7Xx4jJwSzgoOk:
			if   'ARCHIVED'  in atXHKyxrnefOId1wj: A3pXVFdyP1.menuItemsLIST.append(['folder',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,238,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'ARCHIVED',WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}])
			elif 'EPG' 		 in atXHKyxrnefOId1wj: A3pXVFdyP1.menuItemsLIST.append(['folder',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,238,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FULL_EPG',WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}])
			elif 'TIMESHIFT' in atXHKyxrnefOId1wj: A3pXVFdyP1.menuItemsLIST.append(['folder',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,238,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TIMESHIFT',WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}])
			elif 'LIVE' 	 in atXHKyxrnefOId1wj: A3pXVFdyP1.menuItemsLIST.append(['live',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,235,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,EaOw4PxtyQpZXM3,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}])
			else: A3pXVFdyP1.menuItemsLIST.append(['video',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,235,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg}])
	aNLpvrRPQu0OJIB4fFt8h = len(VbxSkQef8wj)
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(NLMU9xZPkX4t168usGzqSBfQCAJHg,DHgfWI8yeZ6h1jq7xdwT2ABM,atXHKyxrnefOId1wj,234,aNLpvrRPQu0OJIB4fFt8h,xCwozyfBtFKOSGqDYQIrRbPaiWv03)
	return
def yuflGHBK76VXt2vosW(qM5pmijVdZtbIJr7YS9exD6OXozhKQ):
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+'هذه القائمة إما فارغة أو غير موجودة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+'أو الخدمة غير موجودة في اشتراكك',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return
def T3TJbgU6X1PzdENmp(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj,xCwozyfBtFKOSGqDYQIrRbPaiWv03,DHgfWI8yeZ6h1jq7xdwT2ABM,bF6Hmv7O3qTZpeDNCYuhRXLo1=WnNGfosHr5STAq8j7miwyRZ6eOUbV,P3MDcw5Ln182FoqAVpZ=True):
	if not DHgfWI8yeZ6h1jq7xdwT2ABM: DHgfWI8yeZ6h1jq7xdwT2ABM = '1'
	qM5pmijVdZtbIJr7YS9exD6OXozhKQ = utGmJTNWUpy9KnVf1hd
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ): return False
	if '__SERIES__' in xCwozyfBtFKOSGqDYQIrRbPaiWv03: Z26iY4nCLAJTlUby13rwMt7pFf,UMNHu2kGjcn1lF0LDSbqxYiZf = xCwozyfBtFKOSGqDYQIrRbPaiWv03.split('__SERIES__')
	else: Z26iY4nCLAJTlUby13rwMt7pFf,UMNHu2kGjcn1lF0LDSbqxYiZf = xCwozyfBtFKOSGqDYQIrRbPaiWv03,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj)
	S5rWFDuHQCPyl = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list',atXHKyxrnefOId1wj,'__GROUPS__')
	if not S5rWFDuHQCPyl: return False
	thISOacrewdU = []
	for zaeA2pkdbcqZgOvJxw9,BYia4zgVcvkm75w3S0 in S5rWFDuHQCPyl:
		if bF6Hmv7O3qTZpeDNCYuhRXLo1:
			if '__SERIES__' in zaeA2pkdbcqZgOvJxw9: qM5pmijVdZtbIJr7YS9exD6OXozhKQ = 'SERIES'
			elif '!!__UNKNOWN__!!' in zaeA2pkdbcqZgOvJxw9: qM5pmijVdZtbIJr7YS9exD6OXozhKQ = 'UNKNOWN'
			elif 'LIVE' in atXHKyxrnefOId1wj: qM5pmijVdZtbIJr7YS9exD6OXozhKQ = 'LIVE'
			else: qM5pmijVdZtbIJr7YS9exD6OXozhKQ = 'VIDEOS'
			qM5pmijVdZtbIJr7YS9exD6OXozhKQ = ','+e6HEdvUcaq8Gx+qM5pmijVdZtbIJr7YS9exD6OXozhKQ+': '+YVr6St5P4xsFC0aARQGKfiegD
		if '__SERIES__' in zaeA2pkdbcqZgOvJxw9: iV97NdAY6h8Oj,Hu2caRiQKSymFdIfqACEZPvpT93w = zaeA2pkdbcqZgOvJxw9.split('__SERIES__')
		else: iV97NdAY6h8Oj,Hu2caRiQKSymFdIfqACEZPvpT93w = zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if not xCwozyfBtFKOSGqDYQIrRbPaiWv03:
			if iV97NdAY6h8Oj in thISOacrewdU: continue
			thISOacrewdU.append(iV97NdAY6h8Oj)
			if 'RANDOM' in bF6Hmv7O3qTZpeDNCYuhRXLo1: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+iV97NdAY6h8Oj,atXHKyxrnefOId1wj,167,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
			elif '__SERIES__' in zaeA2pkdbcqZgOvJxw9: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+iV97NdAY6h8Oj,atXHKyxrnefOId1wj,233,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+iV97NdAY6h8Oj,atXHKyxrnefOId1wj,234,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
		elif '__SERIES__' in zaeA2pkdbcqZgOvJxw9 and iV97NdAY6h8Oj==Z26iY4nCLAJTlUby13rwMt7pFf:
			if Hu2caRiQKSymFdIfqACEZPvpT93w in thISOacrewdU: continue
			thISOacrewdU.append(Hu2caRiQKSymFdIfqACEZPvpT93w)
			if 'RANDOM' in bF6Hmv7O3qTZpeDNCYuhRXLo1: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+Hu2caRiQKSymFdIfqACEZPvpT93w,atXHKyxrnefOId1wj,167,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',qM5pmijVdZtbIJr7YS9exD6OXozhKQ+Hu2caRiQKSymFdIfqACEZPvpT93w,atXHKyxrnefOId1wj,234,BYia4zgVcvkm75w3S0,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	A3pXVFdyP1.menuItemsLIST[:] = sorted(A3pXVFdyP1.menuItemsLIST,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk[1].lower())
	if not bF6Hmv7O3qTZpeDNCYuhRXLo1:
		WvMYcq13AOl = int(DHgfWI8yeZ6h1jq7xdwT2ABM)*100
		MpimvHudO63f1CTcSL5 = WvMYcq13AOl-100
		aNLpvrRPQu0OJIB4fFt8h = len(A3pXVFdyP1.menuItemsLIST)
		A3pXVFdyP1.menuItemsLIST[:] = A3pXVFdyP1.menuItemsLIST[MpimvHudO63f1CTcSL5:WvMYcq13AOl]
		xxNgPGLoIwkY9a7WKC6bMtVRmZF(NLMU9xZPkX4t168usGzqSBfQCAJHg,DHgfWI8yeZ6h1jq7xdwT2ABM,atXHKyxrnefOId1wj,233,aNLpvrRPQu0OJIB4fFt8h,xCwozyfBtFKOSGqDYQIrRbPaiWv03)
	return True
def qBy4PZCz8piFhIQW1gK7Md03o(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,KV1BvglCujwWZ7daSFh2Q4qG):
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,True): return
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = sLZa8dgblSKP6WFMtYjrAw1(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	DB2dZPX0NOLv31Vw6TFUA57kzKI = G3yDpvxOiSWdAeL.getSetting('av.iptv.timestamp_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if not DB2dZPX0NOLv31Vw6TFUA57kzKI or jDuxzCtBH7aihsSL9-int(DB2dZPX0NOLv31Vw6TFUA57kzKI)>24*Ax4cp5PzJ0IuBknC:
		pw8aLc3HTqMVWQO21yt6zfub,zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,False)
		if not pw8aLc3HTqMVWQO21yt6zfub: return
	atXzlbn4hYrQMRf9vPB50EeoZS = int(G3yDpvxOiSWdAeL.getSetting('av.iptv.timediff_'+NLMU9xZPkX4t168usGzqSBfQCAJHg))
	ssdNJZO3mwnA8F4h0S9 = G3yDpvxOiSWdAeL.getSetting('av.iptv.server_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	HyYITOrjQqS6 = G3yDpvxOiSWdAeL.getSetting('av.iptv.username_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	RVnvEpPTX5Z0B72QHmWh3 = G3yDpvxOiSWdAeL.getSetting('av.iptv.password_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	A97A4uq6H1a05TmClKtDX = uuSU5Awl8FNrzkXHdQDiCWq3.split('/')
	hrBdCy3gJ8koajR = A97A4uq6H1a05TmClKtDX[-1].replace('.ts',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('.m3u8',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if KV1BvglCujwWZ7daSFh2Q4qG=='SHORT_EPG': k8TIDrRWfLijsXEQ3yVo62mSeUuHnC = 'get_short_epg'
	else: k8TIDrRWfLijsXEQ3yVo62mSeUuHnC = 'get_simple_data_table'
	ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3 = qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if not HyYITOrjQqS6: return
	ogapWk1Q79UuFrt5c2Ld6 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action='+k8TIDrRWfLijsXEQ3yVo62mSeUuHnC+'&stream_id='+hrBdCy3gJ8koajR
	lXqaJs1WkUZ9Rz0 = A43r7eiNlZhSkFfyQtTL2v(XAGWNdKH4qOPU1YEVQp6,ogapWk1Q79UuFrt5c2Ld6,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-EPG_ITEMS-2nd')
	wEF5nLHbeW3kvsmJ8g1QxD0qZcNrA = IXZpzK7ShaRsAN('dict',lXqaJs1WkUZ9Rz0)
	uaJO8CdBXr4zUs3TLb = wEF5nLHbeW3kvsmJ8g1QxD0qZcNrA['epg_listings']
	pEex7aKmVRL8Glvd3ZqM6sNDbwtB = []
	if KV1BvglCujwWZ7daSFh2Q4qG in ['ARCHIVED','TIMESHIFT']:
		for nWl9L4irPZkUt3eXN in uaJO8CdBXr4zUs3TLb:
			if nWl9L4irPZkUt3eXN['has_archive']==1:
				pEex7aKmVRL8Glvd3ZqM6sNDbwtB.append(nWl9L4irPZkUt3eXN)
				if KV1BvglCujwWZ7daSFh2Q4qG in ['TIMESHIFT']: break
		if not pEex7aKmVRL8Glvd3ZqM6sNDbwtB: return
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+e6HEdvUcaq8Gx+'الملفات الأولي بهذه القائمة قد لا تعمل'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		if KV1BvglCujwWZ7daSFh2Q4qG in ['TIMESHIFT']:
			bHtr2Eqp9TGlu6OBzZRUiNeg = 2
			xzdGQERYim9rqopWay = bHtr2Eqp9TGlu6OBzZRUiNeg*Ax4cp5PzJ0IuBknC
			pEex7aKmVRL8Glvd3ZqM6sNDbwtB = []
			ehJEs0Vgrl = int(int(nWl9L4irPZkUt3eXN['start_timestamp'])/xzdGQERYim9rqopWay)*xzdGQERYim9rqopWay
			u1Qj2NbgkCn = jDuxzCtBH7aihsSL9+xzdGQERYim9rqopWay
			u6rqWANFm5PbyEvRjKfwiY = int((u1Qj2NbgkCn-ehJEs0Vgrl)/Ax4cp5PzJ0IuBknC)
			for Zuy9OVX3dhlM4LsBTrIFn5qA in range(u6rqWANFm5PbyEvRjKfwiY):
				if Zuy9OVX3dhlM4LsBTrIFn5qA>=6:
					if Zuy9OVX3dhlM4LsBTrIFn5qA%bHtr2Eqp9TGlu6OBzZRUiNeg!=0: continue
					cia3ou2EStIb9wNzfFvHD1py456qP = xzdGQERYim9rqopWay
				else: cia3ou2EStIb9wNzfFvHD1py456qP = xzdGQERYim9rqopWay//2
				uum7H9PcEt0QNdjgIAbXO24DpW = ehJEs0Vgrl+Zuy9OVX3dhlM4LsBTrIFn5qA*Ax4cp5PzJ0IuBknC
				nWl9L4irPZkUt3eXN = {}
				nWl9L4irPZkUt3eXN['title'] = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				CkcpouQ9b2sXqOxBUjVTKZiWJL = x54xSdnCFHZ8yliofzOBK.localtime(uum7H9PcEt0QNdjgIAbXO24DpW-atXzlbn4hYrQMRf9vPB50EeoZS-Ax4cp5PzJ0IuBknC)
				nWl9L4irPZkUt3eXN['start'] = x54xSdnCFHZ8yliofzOBK.strftime('%Y.%m.%d %H:%M:%S',CkcpouQ9b2sXqOxBUjVTKZiWJL)
				nWl9L4irPZkUt3eXN['start_timestamp'] = str(uum7H9PcEt0QNdjgIAbXO24DpW)
				nWl9L4irPZkUt3eXN['stop_timestamp'] = str(uum7H9PcEt0QNdjgIAbXO24DpW+cia3ou2EStIb9wNzfFvHD1py456qP)
				pEex7aKmVRL8Glvd3ZqM6sNDbwtB.append(nWl9L4irPZkUt3eXN)
	elif KV1BvglCujwWZ7daSFh2Q4qG in ['SHORT_EPG','FULL_EPG']: pEex7aKmVRL8Glvd3ZqM6sNDbwtB = uaJO8CdBXr4zUs3TLb
	if KV1BvglCujwWZ7daSFh2Q4qG=='FULL_EPG' and len(pEex7aKmVRL8Glvd3ZqM6sNDbwtB)>0:
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+e6HEdvUcaq8Gx+'هذه قائمة برامج القنوات (جدول فقط)ـ'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	ziACHrgn692IDWajPNwU3 = []
	BYia4zgVcvkm75w3S0 = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Icon')
	for nWl9L4irPZkUt3eXN in pEex7aKmVRL8Glvd3ZqM6sNDbwtB:
		fdVN5r3jJlQXZ2yn1a6SesTWoK0 = uvGCPpFwVmTQ36.b64decode(nWl9L4irPZkUt3eXN['title'])
		if rJ2oTLqabRtA: fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.decode(e87cIA5vwOQLDEP1)
		uum7H9PcEt0QNdjgIAbXO24DpW = int(nWl9L4irPZkUt3eXN['start_timestamp'])
		PbfJ8i2qjgLOyZ0F5pSzCo = int(nWl9L4irPZkUt3eXN['stop_timestamp'])
		ls1o2ePY3dnF465u9OVQ7TKba = str(int((PbfJ8i2qjgLOyZ0F5pSzCo-uum7H9PcEt0QNdjgIAbXO24DpW+59)/60))
		FFuSZM2v9x1CVbfpT7 = nWl9L4irPZkUt3eXN['start'].replace(kcXMWrwiLDKeBHRsJ,':')
		CkcpouQ9b2sXqOxBUjVTKZiWJL = x54xSdnCFHZ8yliofzOBK.localtime(uum7H9PcEt0QNdjgIAbXO24DpW-Ax4cp5PzJ0IuBknC)
		C85EzlVAIb7Po = x54xSdnCFHZ8yliofzOBK.strftime('%H:%M',CkcpouQ9b2sXqOxBUjVTKZiWJL)
		bbu0RD3N9L8 = x54xSdnCFHZ8yliofzOBK.strftime('%a',CkcpouQ9b2sXqOxBUjVTKZiWJL)
		if KV1BvglCujwWZ7daSFh2Q4qG=='SHORT_EPG': fdVN5r3jJlQXZ2yn1a6SesTWoK0 = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+C85EzlVAIb7Po+' ـ '+fdVN5r3jJlQXZ2yn1a6SesTWoK0+YVr6St5P4xsFC0aARQGKfiegD
		elif KV1BvglCujwWZ7daSFh2Q4qG=='TIMESHIFT': fdVN5r3jJlQXZ2yn1a6SesTWoK0 = bbu0RD3N9L8+kcXMWrwiLDKeBHRsJ+C85EzlVAIb7Po+' ('+ls1o2ePY3dnF465u9OVQ7TKba+'min)'
		else: fdVN5r3jJlQXZ2yn1a6SesTWoK0 = bbu0RD3N9L8+kcXMWrwiLDKeBHRsJ+C85EzlVAIb7Po+' ('+ls1o2ePY3dnF465u9OVQ7TKba+'min)   '+fdVN5r3jJlQXZ2yn1a6SesTWoK0+' ـ'
		if KV1BvglCujwWZ7daSFh2Q4qG in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			xilE7TBWFNp = ssdNJZO3mwnA8F4h0S9+'/timeshift/'+HyYITOrjQqS6+'/'+RVnvEpPTX5Z0B72QHmWh3+'/'+ls1o2ePY3dnF465u9OVQ7TKba+'/'+FFuSZM2v9x1CVbfpT7+'/'+hrBdCy3gJ8koajR+'.m3u8'
			if KV1BvglCujwWZ7daSFh2Q4qG=='FULL_EPG': octplHnGwmE8bFqNdj7BiKvJ0VL('link',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,xilE7TBWFNp,9999,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,xilE7TBWFNp,235,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
		ziACHrgn692IDWajPNwU3.append(fdVN5r3jJlQXZ2yn1a6SesTWoK0)
	if KV1BvglCujwWZ7daSFh2Q4qG=='SHORT_EPG' and ziACHrgn692IDWajPNwU3: kcWiELAIuS2TRPph3tgjdKH8 = zduIlbakFEhsDPM5JU8oR3ZC(ziACHrgn692IDWajPNwU3)
	return ziACHrgn692IDWajPNwU3
def GoOJD5FtqyeTZNLWhcP4kKa(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,True): return
	ssdNJZO3mwnA8F4h0S9,vmEldqPTyiHXAWuBxL7e3s6IFrzw2,fuKcXtrVsk5 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,0,0
	pw8aLc3HTqMVWQO21yt6zfub,zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,False)
	if pw8aLc3HTqMVWQO21yt6zfub:
		IpDbXFvuGPw7dYagVhBQe = ncBCmaR6ZUFADqfSlXuO(zlKk8Cx2eOqAhS1Lr0Qmu)
		vmEldqPTyiHXAWuBxL7e3s6IFrzw2 = IQZ0bGPovap6gWmc4LfY(IpDbXFvuGPw7dYagVhBQe[0],int(slcE50yGaMLqTnh1))
		HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,'LIVE_GROUPED')
		oZez0pJwEGVTRQlXYk7dP3Mh = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list','LIVE_GROUPED')
		VbxSkQef8wj = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list','LIVE_GROUPED',oZez0pJwEGVTRQlXYk7dP3Mh[1])
		uuSU5Awl8FNrzkXHdQDiCWq3 = VbxSkQef8wj[0][2]
		N8YKfMe6i3cbCJzUav = p7dwlH1PRStBgyMUW.findall('://(.*?)/',uuSU5Awl8FNrzkXHdQDiCWq3,p7dwlH1PRStBgyMUW.DOTALL)
		N8YKfMe6i3cbCJzUav = N8YKfMe6i3cbCJzUav[0]
		if ':' in N8YKfMe6i3cbCJzUav: aJOwibkMmjDduXWp5VC1I263znrZ,ANKzgia8H0p1EZy2d4 = N8YKfMe6i3cbCJzUav.split(':')
		else: aJOwibkMmjDduXWp5VC1I263znrZ,ANKzgia8H0p1EZy2d4 = N8YKfMe6i3cbCJzUav,'80'
		g4xfZKbT1vhe6lOni = ncBCmaR6ZUFADqfSlXuO(aJOwibkMmjDduXWp5VC1I263znrZ)
		fuKcXtrVsk5 = IQZ0bGPovap6gWmc4LfY(g4xfZKbT1vhe6lOni[0],int(ANKzgia8H0p1EZy2d4))
	if vmEldqPTyiHXAWuBxL7e3s6IFrzw2 and fuKcXtrVsk5:
		eJU6bsndE1mI0F = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		eJU6bsndE1mI0F += '\n\n'+'وقت ضائع في السيرفر الأصلي'+WBDnh75CaLEvkcN6p4ez2KXrV3M+str(int(fuKcXtrVsk5*1000))+' ملي ثانية'
		eJU6bsndE1mI0F += '\n\n'+'وقت ضائع في السيرفر البديل'+WBDnh75CaLEvkcN6p4ez2KXrV3M+str(int(vmEldqPTyiHXAWuBxL7e3s6IFrzw2*1000))+' ملي ثانية'
		PJtTMSG4ahksq = TPNsmjik1eh4Wc('center','السيرفر الأصلي','السيرفر الأسرع',Ew26Hg4SIj,eJU6bsndE1mI0F)
		if PJtTMSG4ahksq==1 and vmEldqPTyiHXAWuBxL7e3s6IFrzw2<fuKcXtrVsk5: ssdNJZO3mwnA8F4h0S9 = zlKk8Cx2eOqAhS1Lr0Qmu+':'+slcE50yGaMLqTnh1
	else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'البرنامج لم يجد السيرفر البديل')
	G3yDpvxOiSWdAeL.setSetting('av.iptv.server_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,ssdNJZO3mwnA8F4h0S9)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(NLMU9xZPkX4t168usGzqSBfQCAJHg,uuSU5Awl8FNrzkXHdQDiCWq3,t0xkM74rgEAFIepSWXilNOGDn):
	BfcC5x12GntbXiakWs3AmESUIQ7Or = G3yDpvxOiSWdAeL.getSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	xoFbUB8NTH0ZQf7I = G3yDpvxOiSWdAeL.getSetting('av.iptv.referer_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if BfcC5x12GntbXiakWs3AmESUIQ7Or or xoFbUB8NTH0ZQf7I:
		uuSU5Awl8FNrzkXHdQDiCWq3 += '|'
		if BfcC5x12GntbXiakWs3AmESUIQ7Or: uuSU5Awl8FNrzkXHdQDiCWq3 += '&User-Agent='+BfcC5x12GntbXiakWs3AmESUIQ7Or
		if xoFbUB8NTH0ZQf7I: uuSU5Awl8FNrzkXHdQDiCWq3 += '&Referer='+xoFbUB8NTH0ZQf7I
		uuSU5Awl8FNrzkXHdQDiCWq3 = uuSU5Awl8FNrzkXHdQDiCWq3.replace('|&','|')
	Wgi5mx6kfdSh3GqXNbFMKpocZe7 = G3yDpvxOiSWdAeL.getSetting('av.iptv.server_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if Wgi5mx6kfdSh3GqXNbFMKpocZe7:
		CCaAgv4uIRNnoxsp = p7dwlH1PRStBgyMUW.findall('://(.*?)/',uuSU5Awl8FNrzkXHdQDiCWq3,p7dwlH1PRStBgyMUW.DOTALL)
		uuSU5Awl8FNrzkXHdQDiCWq3 = uuSU5Awl8FNrzkXHdQDiCWq3.replace(CCaAgv4uIRNnoxsp[0],Wgi5mx6kfdSh3GqXNbFMKpocZe7)
	YsRk6pAS7rdcn(uuSU5Awl8FNrzkXHdQDiCWq3,TTOAERW9IMB045fQt7wnjrymKZGHN,t0xkM74rgEAFIepSWXilNOGDn)
	return
def npTzM8qfJEHjl3(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	BfcC5x12GntbXiakWs3AmESUIQ7Or = G3yDpvxOiSWdAeL.getSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center','استخدام الأصلي','تعديل القديم',BfcC5x12GntbXiakWs3AmESUIQ7Or,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if rpe8xinNl2W4btf==1: BfcC5x12GntbXiakWs3AmESUIQ7Or = x6S4MmiIE1hJ5bWUtdG02azC9Dgu('أكتب ـIPTV User-Agent جديد',BfcC5x12GntbXiakWs3AmESUIQ7Or,True)
	else: BfcC5x12GntbXiakWs3AmESUIQ7Or = 'Unknown'
	if BfcC5x12GntbXiakWs3AmESUIQ7Or==kcXMWrwiLDKeBHRsJ:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,BfcC5x12GntbXiakWs3AmESUIQ7Or,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if rpe8xinNl2W4btf!=1:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم الإلغاء')
		return
	G3yDpvxOiSWdAeL.setSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,BfcC5x12GntbXiakWs3AmESUIQ7Or)
	jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	return
def WWrPGCYqv3VOEyJ9TSbHt(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	xoFbUB8NTH0ZQf7I = G3yDpvxOiSWdAeL.getSetting('av.iptv.referer_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center','استخدام الأصلي','تعديل القديم',xoFbUB8NTH0ZQf7I,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if rpe8xinNl2W4btf==1: xoFbUB8NTH0ZQf7I = x6S4MmiIE1hJ5bWUtdG02azC9Dgu('أكتب ـIPTV Referer جديد',xoFbUB8NTH0ZQf7I,True)
	else: xoFbUB8NTH0ZQf7I = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if xoFbUB8NTH0ZQf7I==kcXMWrwiLDKeBHRsJ:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,xoFbUB8NTH0ZQf7I,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if rpe8xinNl2W4btf!=1:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم الإلغاء')
		return
	G3yDpvxOiSWdAeL.setSetting('av.iptv.referer_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,xoFbUB8NTH0ZQf7I)
	jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	return
def qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg,bdrB7XqstiANMaYUGHPl6f=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not bdrB7XqstiANMaYUGHPl6f: bdrB7XqstiANMaYUGHPl6f = G3yDpvxOiSWdAeL.getSetting('av.iptv.url_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	ssdNJZO3mwnA8F4h0S9 = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(bdrB7XqstiANMaYUGHPl6f,'url')
	HyYITOrjQqS6 = p7dwlH1PRStBgyMUW.findall('username=(.*?)&',bdrB7XqstiANMaYUGHPl6f+'&',p7dwlH1PRStBgyMUW.DOTALL)
	RVnvEpPTX5Z0B72QHmWh3 = p7dwlH1PRStBgyMUW.findall('password=(.*?)&',bdrB7XqstiANMaYUGHPl6f+'&',p7dwlH1PRStBgyMUW.DOTALL)
	if not HyYITOrjQqS6 or not RVnvEpPTX5Z0B72QHmWh3:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	HyYITOrjQqS6 = HyYITOrjQqS6[0]
	RVnvEpPTX5Z0B72QHmWh3 = RVnvEpPTX5Z0B72QHmWh3[0]
	ZnFkGo4Jb0RC5z32WwdD89cQAjeSa = ssdNJZO3mwnA8F4h0S9+'/player_api.php?username='+HyYITOrjQqS6+'&password='+RVnvEpPTX5Z0B72QHmWh3
	lornYk4vh3qzcguy1i6Ibdj = ssdNJZO3mwnA8F4h0S9+'/get.php?username='+HyYITOrjQqS6+'&password='+RVnvEpPTX5Z0B72QHmWh3+'&type=m3u_plus'
	return ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3
def VQzogTZurywsb8jiSN9tm5xf2aKIB1(NLMU9xZPkX4t168usGzqSBfQCAJHg,ZTrGpMje4oOfC=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	u0Y8HiytVNqc7mP = ZTrGpMje4oOfC.replace('/','_').replace(':','_').replace('.','_')
	u0Y8HiytVNqc7mP = u0Y8HiytVNqc7mP.replace('?','_').replace('=','_').replace('&','_')
	u0Y8HiytVNqc7mP = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(kcCgDi2EzhU5s413pAjSmu,u0Y8HiytVNqc7mP).strip('.m3u')+'.m3u'
	return u0Y8HiytVNqc7mP
def qIKy9ReSwsDpNYtXiT5FbLVlMUEJgG(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	vFm78wBjEoydIr = G3yDpvxOiSWdAeL.getSetting('av.iptv.url_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	M8MNKqSWk0OBRIT = True
	if vFm78wBjEoydIr:
		rpe8xinNl2W4btf = tFVmMznSUR3XupZBN9kxcO0EHv('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',e6HEdvUcaq8Gx+vFm78wBjEoydIr+YVr6St5P4xsFC0aARQGKfiegD+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if rpe8xinNl2W4btf==-1: return
		elif rpe8xinNl2W4btf==0: vFm78wBjEoydIr = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		elif rpe8xinNl2W4btf==2:
			rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rpe8xinNl2W4btf in [-1,0]: return
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم مسح الرابط')
			M8MNKqSWk0OBRIT = False
			TwKWLmoEBIegFG = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if M8MNKqSWk0OBRIT:
		TwKWLmoEBIegFG = x6S4MmiIE1hJ5bWUtdG02azC9Dgu('اكتب رابط ـIPTV كاملا',vFm78wBjEoydIr)
		TwKWLmoEBIegFG = TwKWLmoEBIegFG.strip(kcXMWrwiLDKeBHRsJ)
		if not TwKWLmoEBIegFG:
			rpe8xinNl2W4btf = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rpe8xinNl2W4btf in [-1,0]: return
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم مسح الرابط')
	else:
		ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3 = qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg,TwKWLmoEBIegFG)
		if not HyYITOrjQqS6: return
		eJU6bsndE1mI0F = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+ssdNJZO3mwnA8F4h0S9+YVr6St5P4xsFC0aARQGKfiegD+'عنوان السيرفر: '
		eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+HyYITOrjQqS6+YVr6St5P4xsFC0aARQGKfiegD+'اسم المستخدم: '
		eJU6bsndE1mI0F += WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+xmjIO6AucZ7EJ9iflrHdwz12++'كلمة السر: '
		rpe8xinNl2W4btf = TPNsmjik1eh4Wc('right',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'الرابط الجديد هو:',e6HEdvUcaq8Gx+TwKWLmoEBIegFG+YVr6St5P4xsFC0aARQGKfiegD+'\n\n'+eJU6bsndE1mI0F)
		if rpe8xinNl2W4btf!=1:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم الإلغاء')
			return
	G3yDpvxOiSWdAeL.setSetting('av.iptv.url_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,TwKWLmoEBIegFG)
	G3yDpvxOiSWdAeL.setSetting('av.iptv.timestamp_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3yDpvxOiSWdAeL.setSetting('av.iptv.timediff_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	BfcC5x12GntbXiakWs3AmESUIQ7Or = G3yDpvxOiSWdAeL.getSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if not BfcC5x12GntbXiakWs3AmESUIQ7Or: G3yDpvxOiSWdAeL.setSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg,'Unknown')
	N3JA0XvRfU5cD = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TwKWLmoEBIegFG+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if N3JA0XvRfU5cD==1: pw8aLc3HTqMVWQO21yt6zfub,zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,True)
	jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	return
def m7mHORDqvGueozLchSjVsCpXNYAnW(t7TS2ruafMQ,ggCAyNbw6FDuBJQe,Gt6KHVDPcUdONbW4Y1RjrwZC,eyZpMs2rFO18wxR3mc,ZSVPe5Lr1igfpm,VRTAtMKBOzmL8jan9ydE5I,lornYk4vh3qzcguy1i6Ibdj):
	VbxSkQef8wj,r9rciRhQKVk8UuDN2ELXPFl = [],[]
	ZuT0ER8leN = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		if VRTAtMKBOzmL8jan9ydE5I%473==0:
			tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,40+int(10*VRTAtMKBOzmL8jan9ydE5I/ZSVPe5Lr1igfpm),'قراءة الفيديوهات','الفيديو رقم:-',str(VRTAtMKBOzmL8jan9ydE5I)+' / '+str(ZSVPe5Lr1igfpm))
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return None,None,None
		uuSU5Awl8FNrzkXHdQDiCWq3 = p7dwlH1PRStBgyMUW.findall('^(.*?)\n+((http|https|rtmp).*?)$',JHLkRVEQFA1WUwZPtD4Cyxr8,p7dwlH1PRStBgyMUW.DOTALL)
		if uuSU5Awl8FNrzkXHdQDiCWq3:
			JHLkRVEQFA1WUwZPtD4Cyxr8,uuSU5Awl8FNrzkXHdQDiCWq3,jAPL6vaKoNeCJx5QGEH2h9UVn1w = uuSU5Awl8FNrzkXHdQDiCWq3[0]
			uuSU5Awl8FNrzkXHdQDiCWq3 = uuSU5Awl8FNrzkXHdQDiCWq3.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			JHLkRVEQFA1WUwZPtD4Cyxr8 = JHLkRVEQFA1WUwZPtD4Cyxr8.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		else:
			r9rciRhQKVk8UuDN2ELXPFl.append({'line':JHLkRVEQFA1WUwZPtD4Cyxr8})
			continue
		BfIyue5dECL3N8sQ42ztxlMoD,EaOw4PxtyQpZXM3,zaeA2pkdbcqZgOvJxw9,fdVN5r3jJlQXZ2yn1a6SesTWoK0,t0xkM74rgEAFIepSWXilNOGDn,vveFSrLONq8oduPaE6mcbJlyQ23RK = {},WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,False
		try:
			JHLkRVEQFA1WUwZPtD4Cyxr8,fdVN5r3jJlQXZ2yn1a6SesTWoK0 = JHLkRVEQFA1WUwZPtD4Cyxr8.rsplit('",',1)
			JHLkRVEQFA1WUwZPtD4Cyxr8 = JHLkRVEQFA1WUwZPtD4Cyxr8+'"'
		except:
			try: JHLkRVEQFA1WUwZPtD4Cyxr8,fdVN5r3jJlQXZ2yn1a6SesTWoK0 = JHLkRVEQFA1WUwZPtD4Cyxr8.rsplit('1,',1)
			except: fdVN5r3jJlQXZ2yn1a6SesTWoK0 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		BfIyue5dECL3N8sQ42ztxlMoD['url'] = uuSU5Awl8FNrzkXHdQDiCWq3
		soW93DdGVxkui0SXU16Ll5rMyBC7tq = p7dwlH1PRStBgyMUW.findall(' (.*?)="(.*?)"',JHLkRVEQFA1WUwZPtD4Cyxr8,p7dwlH1PRStBgyMUW.DOTALL)
		for LoeIfPVjrk,iOtALfPUs0zJkY in soW93DdGVxkui0SXU16Ll5rMyBC7tq:
			LoeIfPVjrk = LoeIfPVjrk.replace('"',WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
			BfIyue5dECL3N8sQ42ztxlMoD[LoeIfPVjrk] = iOtALfPUs0zJkY.strip(kcXMWrwiLDKeBHRsJ)
		eesX6FJdxPghRz3aEHbZYA = list(BfIyue5dECL3N8sQ42ztxlMoD.keys())
		if not fdVN5r3jJlQXZ2yn1a6SesTWoK0:
			if 'name' in eesX6FJdxPghRz3aEHbZYA and BfIyue5dECL3N8sQ42ztxlMoD['name']: fdVN5r3jJlQXZ2yn1a6SesTWoK0 = BfIyue5dECL3N8sQ42ztxlMoD['name']
		BfIyue5dECL3N8sQ42ztxlMoD['title'] = fdVN5r3jJlQXZ2yn1a6SesTWoK0.strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		if 'logo' in eesX6FJdxPghRz3aEHbZYA:
			BfIyue5dECL3N8sQ42ztxlMoD['img'] = BfIyue5dECL3N8sQ42ztxlMoD['logo']
			del BfIyue5dECL3N8sQ42ztxlMoD['logo']
		else: BfIyue5dECL3N8sQ42ztxlMoD['img'] = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if 'group' in eesX6FJdxPghRz3aEHbZYA and BfIyue5dECL3N8sQ42ztxlMoD['group']: zaeA2pkdbcqZgOvJxw9 = BfIyue5dECL3N8sQ42ztxlMoD['group']
		if any(value in uuSU5Awl8FNrzkXHdQDiCWq3.lower() for value in ZuT0ER8leN):
			vveFSrLONq8oduPaE6mcbJlyQ23RK = True if 'm3u' not in uuSU5Awl8FNrzkXHdQDiCWq3 else False
		if vveFSrLONq8oduPaE6mcbJlyQ23RK or '__SERIES__' in zaeA2pkdbcqZgOvJxw9 or '__MOVIES__' in zaeA2pkdbcqZgOvJxw9:
			t0xkM74rgEAFIepSWXilNOGDn = 'VOD'
			if '__SERIES__' in zaeA2pkdbcqZgOvJxw9: t0xkM74rgEAFIepSWXilNOGDn = t0xkM74rgEAFIepSWXilNOGDn+'_SERIES'
			elif '__MOVIES__' in zaeA2pkdbcqZgOvJxw9: t0xkM74rgEAFIepSWXilNOGDn = t0xkM74rgEAFIepSWXilNOGDn+'_MOVIES'
			else: t0xkM74rgEAFIepSWXilNOGDn = t0xkM74rgEAFIepSWXilNOGDn+'_UNKNOWN'
			zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.replace('__SERIES__',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('__MOVIES__',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		else:
			t0xkM74rgEAFIepSWXilNOGDn = 'LIVE'
			if fdVN5r3jJlQXZ2yn1a6SesTWoK0 in ggCAyNbw6FDuBJQe: EaOw4PxtyQpZXM3 = EaOw4PxtyQpZXM3+'_EPG'
			if fdVN5r3jJlQXZ2yn1a6SesTWoK0 in Gt6KHVDPcUdONbW4Y1RjrwZC: EaOw4PxtyQpZXM3 = EaOw4PxtyQpZXM3+'_ARCHIVED'
			if not zaeA2pkdbcqZgOvJxw9: t0xkM74rgEAFIepSWXilNOGDn = t0xkM74rgEAFIepSWXilNOGDn+'_UNKNOWN'
			else: t0xkM74rgEAFIepSWXilNOGDn = t0xkM74rgEAFIepSWXilNOGDn+EaOw4PxtyQpZXM3
		zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.strip(kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
		if 'LIVE_UNKNOWN' in t0xkM74rgEAFIepSWXilNOGDn: zaeA2pkdbcqZgOvJxw9 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in t0xkM74rgEAFIepSWXilNOGDn: zaeA2pkdbcqZgOvJxw9 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in t0xkM74rgEAFIepSWXilNOGDn:
			Axe4ayTCY96 = p7dwlH1PRStBgyMUW.findall('(.*?) [Ss]\d+ +[Ee]\d+',BfIyue5dECL3N8sQ42ztxlMoD['title'],p7dwlH1PRStBgyMUW.DOTALL)
			if Axe4ayTCY96: Axe4ayTCY96 = Axe4ayTCY96[0]
			else: Axe4ayTCY96 = '!!__UNKNOWN_SERIES__!!'
			zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9+'__SERIES__'+Axe4ayTCY96
		if 'id' in eesX6FJdxPghRz3aEHbZYA: del BfIyue5dECL3N8sQ42ztxlMoD['id']
		if 'ID' in eesX6FJdxPghRz3aEHbZYA: del BfIyue5dECL3N8sQ42ztxlMoD['ID']
		if 'name' in eesX6FJdxPghRz3aEHbZYA: del BfIyue5dECL3N8sQ42ztxlMoD['name']
		fdVN5r3jJlQXZ2yn1a6SesTWoK0 = BfIyue5dECL3N8sQ42ztxlMoD['title']
		fdVN5r3jJlQXZ2yn1a6SesTWoK0 = clFjTSgMODe7Nq0H3Vzs(fdVN5r3jJlQXZ2yn1a6SesTWoK0)
		fdVN5r3jJlQXZ2yn1a6SesTWoK0 = Tfo9JwUIzrBakWK28QLqnbmDei(fdVN5r3jJlQXZ2yn1a6SesTWoK0)
		XjYysUHunNLFc7lGK2q,zaeA2pkdbcqZgOvJxw9 = SH5yYNQP6xdXW2cqkDwtJBKuei(zaeA2pkdbcqZgOvJxw9)
		lRNmZVrTDFJv,fdVN5r3jJlQXZ2yn1a6SesTWoK0 = SH5yYNQP6xdXW2cqkDwtJBKuei(fdVN5r3jJlQXZ2yn1a6SesTWoK0)
		BfIyue5dECL3N8sQ42ztxlMoD['type'] = t0xkM74rgEAFIepSWXilNOGDn
		BfIyue5dECL3N8sQ42ztxlMoD['context'] = EaOw4PxtyQpZXM3
		BfIyue5dECL3N8sQ42ztxlMoD['group'] = zaeA2pkdbcqZgOvJxw9.upper()
		BfIyue5dECL3N8sQ42ztxlMoD['title'] = fdVN5r3jJlQXZ2yn1a6SesTWoK0.upper()
		BfIyue5dECL3N8sQ42ztxlMoD['country'] = lRNmZVrTDFJv.upper()
		BfIyue5dECL3N8sQ42ztxlMoD['language'] = XjYysUHunNLFc7lGK2q.upper()
		VbxSkQef8wj.append(BfIyue5dECL3N8sQ42ztxlMoD)
		VRTAtMKBOzmL8jan9ydE5I += 1
	return VbxSkQef8wj,VRTAtMKBOzmL8jan9ydE5I,r9rciRhQKVk8UuDN2ELXPFl
def Tfo9JwUIzrBakWK28QLqnbmDei(fdVN5r3jJlQXZ2yn1a6SesTWoK0):
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.replace('||','|').replace('___',':').replace('--','-')
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.replace('[[','[').replace(']]',']')
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.replace('((','(').replace('))',')')
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.replace('<<','<').replace('>>','>')
	fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fdVN5r3jJlQXZ2yn1a6SesTWoK0.strip(kcXMWrwiLDKeBHRsJ)
	return fdVN5r3jJlQXZ2yn1a6SesTWoK0
def CJlHN6OxDUa7RrX8Y3dLo2k1PVmjA(BBmErNx6AoRZQGpLC,eyZpMs2rFO18wxR3mc):
	Pl4hLnxzpSvRJKIj5EO = {}
	for dFHDUo5Kk9ec in yrl3fU0XCvk6q: Pl4hLnxzpSvRJKIj5EO[dFHDUo5Kk9ec] = []
	ZSVPe5Lr1igfpm = len(BBmErNx6AoRZQGpLC)
	kysTfbHudhmYRlUnODxV2r = str(ZSVPe5Lr1igfpm)
	VRTAtMKBOzmL8jan9ydE5I = 0
	r9rciRhQKVk8UuDN2ELXPFl = []
	for BfIyue5dECL3N8sQ42ztxlMoD in BBmErNx6AoRZQGpLC:
		if VRTAtMKBOzmL8jan9ydE5I%873==0:
			tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,50+int(5*VRTAtMKBOzmL8jan9ydE5I/ZSVPe5Lr1igfpm),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(VRTAtMKBOzmL8jan9ydE5I)+' / '+kysTfbHudhmYRlUnODxV2r)
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return None,None
		zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 = BfIyue5dECL3N8sQ42ztxlMoD['group'],BfIyue5dECL3N8sQ42ztxlMoD['context'],BfIyue5dECL3N8sQ42ztxlMoD['title'],BfIyue5dECL3N8sQ42ztxlMoD['url'],BfIyue5dECL3N8sQ42ztxlMoD['img']
		lRNmZVrTDFJv,XjYysUHunNLFc7lGK2q,dFHDUo5Kk9ec = BfIyue5dECL3N8sQ42ztxlMoD['country'],BfIyue5dECL3N8sQ42ztxlMoD['language'],BfIyue5dECL3N8sQ42ztxlMoD['type']
		MiHsD5JmZIwUd3z6 = (zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0)
		xVCJLIalfvSj2swN0cyipOr = False
		if 'LIVE' in dFHDUo5Kk9ec:
			if 'UNKNOWN' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_UNKNOWN_GROUPED'].append(MiHsD5JmZIwUd3z6)
			elif 'LIVE' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_GROUPED'].append(MiHsD5JmZIwUd3z6)
			else: xVCJLIalfvSj2swN0cyipOr = True
			Pl4hLnxzpSvRJKIj5EO['LIVE_ORIGINAL_GROUPED'].append(MiHsD5JmZIwUd3z6)
		elif 'VOD' in dFHDUo5Kk9ec:
			if 'UNKNOWN' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_UNKNOWN_GROUPED'].append(MiHsD5JmZIwUd3z6)
			elif 'MOVIES' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_MOVIES_GROUPED'].append(MiHsD5JmZIwUd3z6)
			elif 'SERIES' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_SERIES_GROUPED'].append(MiHsD5JmZIwUd3z6)
			else: xVCJLIalfvSj2swN0cyipOr = True
			Pl4hLnxzpSvRJKIj5EO['VOD_ORIGINAL_GROUPED'].append(MiHsD5JmZIwUd3z6)
		else: xVCJLIalfvSj2swN0cyipOr = True
		if xVCJLIalfvSj2swN0cyipOr: r9rciRhQKVk8UuDN2ELXPFl.append(BfIyue5dECL3N8sQ42ztxlMoD)
		VRTAtMKBOzmL8jan9ydE5I += 1
	Gouc801jNewHT5km = sorted(BBmErNx6AoRZQGpLC,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk['title'].lower())
	del BBmErNx6AoRZQGpLC
	kysTfbHudhmYRlUnODxV2r = str(ZSVPe5Lr1igfpm)
	VRTAtMKBOzmL8jan9ydE5I = 0
	for BfIyue5dECL3N8sQ42ztxlMoD in Gouc801jNewHT5km:
		VRTAtMKBOzmL8jan9ydE5I += 1
		if VRTAtMKBOzmL8jan9ydE5I%873==0:
			tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,55+int(5*VRTAtMKBOzmL8jan9ydE5I/ZSVPe5Lr1igfpm),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(VRTAtMKBOzmL8jan9ydE5I)+' / '+kysTfbHudhmYRlUnODxV2r)
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return None,None
		dFHDUo5Kk9ec = BfIyue5dECL3N8sQ42ztxlMoD['type']
		zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 = BfIyue5dECL3N8sQ42ztxlMoD['group'],BfIyue5dECL3N8sQ42ztxlMoD['context'],BfIyue5dECL3N8sQ42ztxlMoD['title'],BfIyue5dECL3N8sQ42ztxlMoD['url'],BfIyue5dECL3N8sQ42ztxlMoD['img']
		lRNmZVrTDFJv,XjYysUHunNLFc7lGK2q = BfIyue5dECL3N8sQ42ztxlMoD['country'],BfIyue5dECL3N8sQ42ztxlMoD['language']
		KdtpTYIfOvhn6zFDPly = (zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3+'_TIMESHIFT',fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0)
		MiHsD5JmZIwUd3z6 = (zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0)
		vbYfip58g4 = (lRNmZVrTDFJv,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0)
		o06kw4Re79D = (XjYysUHunNLFc7lGK2q,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0)
		if 'LIVE' in dFHDUo5Kk9ec:
			if 'UNKNOWN' in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_UNKNOWN_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			else: Pl4hLnxzpSvRJKIj5EO['LIVE_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			if 'EPG'		in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_EPG_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			if 'ARCHIVED'	in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_ARCHIVED_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			if 'ARCHIVED'	in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['LIVE_TIMESHIFT_GROUPED_SORTED'].append(KdtpTYIfOvhn6zFDPly)
			Pl4hLnxzpSvRJKIj5EO['LIVE_FROM_NAME_SORTED'].append(vbYfip58g4)
			Pl4hLnxzpSvRJKIj5EO['LIVE_FROM_GROUP_SORTED'].append(o06kw4Re79D)
		elif 'VOD' in dFHDUo5Kk9ec:
			if   'UNKNOWN'	in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_UNKNOWN_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			elif 'MOVIES'	in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_MOVIES_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			elif 'SERIES'	in dFHDUo5Kk9ec: Pl4hLnxzpSvRJKIj5EO['VOD_SERIES_GROUPED_SORTED'].append(MiHsD5JmZIwUd3z6)
			Pl4hLnxzpSvRJKIj5EO['VOD_FROM_NAME_SORTED'].append(vbYfip58g4)
			Pl4hLnxzpSvRJKIj5EO['VOD_FROM_GROUP_SORTED'].append(o06kw4Re79D)
	return Pl4hLnxzpSvRJKIj5EO,r9rciRhQKVk8UuDN2ELXPFl
def SH5yYNQP6xdXW2cqkDwtJBKuei(fdVN5r3jJlQXZ2yn1a6SesTWoK0):
	if len(fdVN5r3jJlQXZ2yn1a6SesTWoK0)<3: return fdVN5r3jJlQXZ2yn1a6SesTWoK0,fdVN5r3jJlQXZ2yn1a6SesTWoK0
	rgYeBcO8n9ztk3GAMjZ4HQCWRsu,ZJh0knQpRsbEaK7eLwW42forAM6 = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	ddFYPHEcSRajhTnQNWUIuZAmkr7f = fdVN5r3jJlQXZ2yn1a6SesTWoK0
	EEzrADas9LjwR = fdVN5r3jJlQXZ2yn1a6SesTWoK0[:1]
	u36YoUqejABQ8ZtdcP4 = fdVN5r3jJlQXZ2yn1a6SesTWoK0[1:]
	if   EEzrADas9LjwR=='(': ZJh0knQpRsbEaK7eLwW42forAM6 = ')'
	elif EEzrADas9LjwR=='[': ZJh0knQpRsbEaK7eLwW42forAM6 = ']'
	elif EEzrADas9LjwR=='<': ZJh0knQpRsbEaK7eLwW42forAM6 = '>'
	elif EEzrADas9LjwR=='|': ZJh0knQpRsbEaK7eLwW42forAM6 = '|'
	if ZJh0knQpRsbEaK7eLwW42forAM6 and (ZJh0knQpRsbEaK7eLwW42forAM6 in u36YoUqejABQ8ZtdcP4):
		SSaTfmu7DlKH,mmic14IhxQLWrXGT7KF = u36YoUqejABQ8ZtdcP4.split(ZJh0knQpRsbEaK7eLwW42forAM6,1)
		rgYeBcO8n9ztk3GAMjZ4HQCWRsu = SSaTfmu7DlKH
		ddFYPHEcSRajhTnQNWUIuZAmkr7f = EEzrADas9LjwR+SSaTfmu7DlKH+ZJh0knQpRsbEaK7eLwW42forAM6+kcXMWrwiLDKeBHRsJ+mmic14IhxQLWrXGT7KF
	elif fdVN5r3jJlQXZ2yn1a6SesTWoK0.count('|')>=2:
		SSaTfmu7DlKH,mmic14IhxQLWrXGT7KF = fdVN5r3jJlQXZ2yn1a6SesTWoK0.split('|',1)
		rgYeBcO8n9ztk3GAMjZ4HQCWRsu = SSaTfmu7DlKH
		ddFYPHEcSRajhTnQNWUIuZAmkr7f = SSaTfmu7DlKH+' |'+mmic14IhxQLWrXGT7KF
	else:
		ZJh0knQpRsbEaK7eLwW42forAM6 = p7dwlH1PRStBgyMUW.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fdVN5r3jJlQXZ2yn1a6SesTWoK0,p7dwlH1PRStBgyMUW.DOTALL)
		if not ZJh0knQpRsbEaK7eLwW42forAM6: ZJh0knQpRsbEaK7eLwW42forAM6 = p7dwlH1PRStBgyMUW.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fdVN5r3jJlQXZ2yn1a6SesTWoK0,p7dwlH1PRStBgyMUW.DOTALL)
		if not ZJh0knQpRsbEaK7eLwW42forAM6: ZJh0knQpRsbEaK7eLwW42forAM6 = p7dwlH1PRStBgyMUW.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fdVN5r3jJlQXZ2yn1a6SesTWoK0,p7dwlH1PRStBgyMUW.DOTALL)
		if ZJh0knQpRsbEaK7eLwW42forAM6:
			SSaTfmu7DlKH,mmic14IhxQLWrXGT7KF = fdVN5r3jJlQXZ2yn1a6SesTWoK0.split(ZJh0knQpRsbEaK7eLwW42forAM6[0],1)
			rgYeBcO8n9ztk3GAMjZ4HQCWRsu = SSaTfmu7DlKH
			ddFYPHEcSRajhTnQNWUIuZAmkr7f = SSaTfmu7DlKH+kcXMWrwiLDKeBHRsJ+ZJh0knQpRsbEaK7eLwW42forAM6[0]+kcXMWrwiLDKeBHRsJ+mmic14IhxQLWrXGT7KF
	ddFYPHEcSRajhTnQNWUIuZAmkr7f = ddFYPHEcSRajhTnQNWUIuZAmkr7f.replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	rgYeBcO8n9ztk3GAMjZ4HQCWRsu = rgYeBcO8n9ztk3GAMjZ4HQCWRsu.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
	if not rgYeBcO8n9ztk3GAMjZ4HQCWRsu: rgYeBcO8n9ztk3GAMjZ4HQCWRsu = '!!__UNKNOWN__!!'
	rgYeBcO8n9ztk3GAMjZ4HQCWRsu = rgYeBcO8n9ztk3GAMjZ4HQCWRsu.strip(kcXMWrwiLDKeBHRsJ)
	ddFYPHEcSRajhTnQNWUIuZAmkr7f = ddFYPHEcSRajhTnQNWUIuZAmkr7f.strip(kcXMWrwiLDKeBHRsJ)
	return rgYeBcO8n9ztk3GAMjZ4HQCWRsu,ddFYPHEcSRajhTnQNWUIuZAmkr7f
def sLZa8dgblSKP6WFMtYjrAw1(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = {}
	BfcC5x12GntbXiakWs3AmESUIQ7Or = G3yDpvxOiSWdAeL.getSetting('av.iptv.useragent_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if BfcC5x12GntbXiakWs3AmESUIQ7Or: d91ITp3ybeYCWjGBFHqkD7voru6Eg['User-Agent'] = BfcC5x12GntbXiakWs3AmESUIQ7Or
	xoFbUB8NTH0ZQf7I = G3yDpvxOiSWdAeL.getSetting('av.iptv.referer_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if xoFbUB8NTH0ZQf7I: d91ITp3ybeYCWjGBFHqkD7voru6Eg['Referer'] = xoFbUB8NTH0ZQf7I
	return d91ITp3ybeYCWjGBFHqkD7voru6Eg
def rowtemU0HSaObTYXf74D(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	global eyZpMs2rFO18wxR3mc,Pl4hLnxzpSvRJKIj5EO,gHxcolaXRekf3bQ72BrA,rLVCFRJWH25nEyDj8OKebf,bXYPwNoE8df3FmlW5IQ,oZez0pJwEGVTRQlXYk7dP3Mh,KKuQomp80UG,WdMNhF6kga74ltPvozeLmZRxbQTuE,ZyJaq3GdOnjbeQgVC
	ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3 = qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if not HyYITOrjQqS6: return
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = sLZa8dgblSKP6WFMtYjrAw1(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	PJtTMSG4ahksq = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if PJtTMSG4ahksq!=1: return
	u0Y8HiytVNqc7mP = Q3QtWFwqHp0mAVkJXguPb7LZSKcNzO.replace('___','_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if 1:
		pw8aLc3HTqMVWQO21yt6zfub,zlKk8Cx2eOqAhS1Lr0Qmu,slcE50yGaMLqTnh1 = noOJuayKN7gCQ(NLMU9xZPkX4t168usGzqSBfQCAJHg,False)
		if not pw8aLc3HTqMVWQO21yt6zfub:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not lornYk4vh3qzcguy1i6Ibdj: SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(TTOAERW9IMB045fQt7wnjrymKZGHN)+'   No IPTV URL found to download IPTV files')
			else: SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(TTOAERW9IMB045fQt7wnjrymKZGHN)+'   Failed to download IPTV files')
			return
		XSD0ZrH3mWqBxkPYE1nhCfdl = zz3FACPKTpqWhEYsf1o9v(lornYk4vh3qzcguy1i6Ibdj,d91ITp3ybeYCWjGBFHqkD7voru6Eg,True)
		if not XSD0ZrH3mWqBxkPYE1nhCfdl: return
		open(u0Y8HiytVNqc7mP,'wb').write(XSD0ZrH3mWqBxkPYE1nhCfdl)
	else: XSD0ZrH3mWqBxkPYE1nhCfdl = open(u0Y8HiytVNqc7mP,'rb').read()
	if rJ2oTLqabRtA and XSD0ZrH3mWqBxkPYE1nhCfdl: XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.decode(e87cIA5vwOQLDEP1)
	eyZpMs2rFO18wxR3mc = dpY7rMymk2W1Jo()
	eyZpMs2rFO18wxR3mc.create('جلب ملفات ـIPTV جديدة',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,15,'تنظيف الملف الرئيسي',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('"tvg-','" tvg-')
	XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('َ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ً',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ُ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ٌ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('ّ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ِ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ٍ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('ْ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('group-title=','group=').replace('tvg-',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	Gt6KHVDPcUdONbW4Y1RjrwZC,ggCAyNbw6FDuBJQe = [],[]
	tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if eyZpMs2rFO18wxR3mc.iscanceled():
		eyZpMs2rFO18wxR3mc.close()
		return
	uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_series_categories'
	lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',uuSU5Awl8FNrzkXHdQDiCWq3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-CREATE_STREAMS-1st')
	lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
	lXqaJs1WkUZ9Rz0 = clFjTSgMODe7Nq0H3Vzs(lXqaJs1WkUZ9Rz0)
	fCyaA8zOHZjYJgeqbNFiIEl9cGhdt = p7dwlH1PRStBgyMUW.findall('category_name":"(.*?)"',lXqaJs1WkUZ9Rz0,p7dwlH1PRStBgyMUW.DOTALL)
	del lXqaJs1WkUZ9Rz0
	for zaeA2pkdbcqZgOvJxw9 in fCyaA8zOHZjYJgeqbNFiIEl9cGhdt:
		zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.replace('\/','/')
		if YVzokG2yZqrh3w8bU: zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.decode(e87cIA5vwOQLDEP1).encode(e87cIA5vwOQLDEP1)
		XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('group="'+zaeA2pkdbcqZgOvJxw9+'"','group="__SERIES__'+zaeA2pkdbcqZgOvJxw9+'"')
	del fCyaA8zOHZjYJgeqbNFiIEl9cGhdt
	tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if eyZpMs2rFO18wxR3mc.iscanceled():
		eyZpMs2rFO18wxR3mc.close()
		return
	uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_vod_categories'
	lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',uuSU5Awl8FNrzkXHdQDiCWq3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-CREATE_STREAMS-2nd')
	lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
	lXqaJs1WkUZ9Rz0 = clFjTSgMODe7Nq0H3Vzs(lXqaJs1WkUZ9Rz0)
	ZoqrnYudBhaH93mgXTv = p7dwlH1PRStBgyMUW.findall('category_name":"(.*?)"',lXqaJs1WkUZ9Rz0,p7dwlH1PRStBgyMUW.DOTALL)
	del lXqaJs1WkUZ9Rz0
	for zaeA2pkdbcqZgOvJxw9 in ZoqrnYudBhaH93mgXTv:
		zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.replace('\/','/')
		if YVzokG2yZqrh3w8bU: zaeA2pkdbcqZgOvJxw9 = zaeA2pkdbcqZgOvJxw9.decode(e87cIA5vwOQLDEP1).encode(e87cIA5vwOQLDEP1)
		XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace('group="'+zaeA2pkdbcqZgOvJxw9+'"','group="__MOVIES__'+zaeA2pkdbcqZgOvJxw9+'"')
	del ZoqrnYudBhaH93mgXTv
	tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if eyZpMs2rFO18wxR3mc.iscanceled():
		eyZpMs2rFO18wxR3mc.close()
		return
	uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_live_streams'
	lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',uuSU5Awl8FNrzkXHdQDiCWq3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-CREATE_STREAMS-3rd')
	lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
	lXqaJs1WkUZ9Rz0 = clFjTSgMODe7Nq0H3Vzs(lXqaJs1WkUZ9Rz0)
	ZIajhvbrNndUAJO7zseWYCkR = p7dwlH1PRStBgyMUW.findall('"name":"(.*?)".*?"tv_archive":(.*?),',lXqaJs1WkUZ9Rz0,p7dwlH1PRStBgyMUW.DOTALL)
	for fzu7Got0FgiyshTlJK,VXvRPDp5em3f9iy01JFWK6 in ZIajhvbrNndUAJO7zseWYCkR:
		if VXvRPDp5em3f9iy01JFWK6=='1': Gt6KHVDPcUdONbW4Y1RjrwZC.append(fzu7Got0FgiyshTlJK)
	del ZIajhvbrNndUAJO7zseWYCkR
	ErkCPjhSIMVJv68uy2lsGgUxwcmzL = p7dwlH1PRStBgyMUW.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',lXqaJs1WkUZ9Rz0,p7dwlH1PRStBgyMUW.DOTALL)
	del lXqaJs1WkUZ9Rz0
	for fzu7Got0FgiyshTlJK,AXTdHJKF1y4weUzS3ln5IV in ErkCPjhSIMVJv68uy2lsGgUxwcmzL:
		if AXTdHJKF1y4weUzS3ln5IV!='null': ggCAyNbw6FDuBJQe.append(fzu7Got0FgiyshTlJK)
	del ErkCPjhSIMVJv68uy2lsGgUxwcmzL
	XSD0ZrH3mWqBxkPYE1nhCfdl = XSD0ZrH3mWqBxkPYE1nhCfdl.replace(TTLxlKI0gNfh7FP,WBDnh75CaLEvkcN6p4ez2KXrV3M)
	t7TS2ruafMQ = p7dwlH1PRStBgyMUW.findall('NF:(.+?)'+'#'+'EXTI',XSD0ZrH3mWqBxkPYE1nhCfdl+'\n+'+'#'+'EXTINF:',p7dwlH1PRStBgyMUW.DOTALL)
	if not t7TS2ruafMQ:
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,q4qKXi5OPsFDoxlB7mkew(TTOAERW9IMB045fQt7wnjrymKZGHN)+'   Folder:'+NLMU9xZPkX4t168usGzqSBfQCAJHg+'   No video links found in IPTV file')
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+WBDnh75CaLEvkcN6p4ez2KXrV3M+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'مجلد رقم '+NLMU9xZPkX4t168usGzqSBfQCAJHg)
		eyZpMs2rFO18wxR3mc.close()
		return
	v2dSwZF30Ci = []
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		sNwRDV6x4rLk0iTgMdlaqFH9BZGJ = JHLkRVEQFA1WUwZPtD4Cyxr8.lower()
		if 'adult' in sNwRDV6x4rLk0iTgMdlaqFH9BZGJ: continue
		if 'xxx' in sNwRDV6x4rLk0iTgMdlaqFH9BZGJ: continue
		v2dSwZF30Ci.append(JHLkRVEQFA1WUwZPtD4Cyxr8)
	t7TS2ruafMQ = v2dSwZF30Ci
	del v2dSwZF30Ci
	eJ2MiYsLyAl = 1024*1024
	Yx4u7cDPpfMNhFKab2 = 1+len(XSD0ZrH3mWqBxkPYE1nhCfdl)//eJ2MiYsLyAl//10
	del XSD0ZrH3mWqBxkPYE1nhCfdl
	yrF5bEU9RHKv1YJN4cuW2GVtxwQ = len(t7TS2ruafMQ)
	WozLtyRMPJEwsAFcZ7ikxq = WOtb70sz5v6CAg9FDof8HMTI(t7TS2ruafMQ,Yx4u7cDPpfMNhFKab2)
	del t7TS2ruafMQ
	for pMiDdTC8LUE2wIV in range(Yx4u7cDPpfMNhFKab2):
		tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,35+int(5*pMiDdTC8LUE2wIV/Yx4u7cDPpfMNhFKab2),'تقطيع الملف الرئيسي','الجزء رقم:-',str(pMiDdTC8LUE2wIV+1)+' / '+str(Yx4u7cDPpfMNhFKab2))
		if eyZpMs2rFO18wxR3mc.iscanceled():
			eyZpMs2rFO18wxR3mc.close()
			return
		ppvIDhVoiGHBN9Jm3X0ndk5A4j = str(WozLtyRMPJEwsAFcZ7ikxq[pMiDdTC8LUE2wIV])
		if rJ2oTLqabRtA: ppvIDhVoiGHBN9Jm3X0ndk5A4j = ppvIDhVoiGHBN9Jm3X0ndk5A4j.encode(e87cIA5vwOQLDEP1)
		open(u0Y8HiytVNqc7mP+'.00'+str(pMiDdTC8LUE2wIV),'wb').write(ppvIDhVoiGHBN9Jm3X0ndk5A4j)
	del WozLtyRMPJEwsAFcZ7ikxq,ppvIDhVoiGHBN9Jm3X0ndk5A4j
	TPJe7wFd0tHIG9mQqsX5DoSR4MN,BBmErNx6AoRZQGpLC,VRTAtMKBOzmL8jan9ydE5I = [],[],0
	for pMiDdTC8LUE2wIV in range(Yx4u7cDPpfMNhFKab2):
		if eyZpMs2rFO18wxR3mc.iscanceled():
			eyZpMs2rFO18wxR3mc.close()
			return
		ppvIDhVoiGHBN9Jm3X0ndk5A4j = open(u0Y8HiytVNqc7mP+'.00'+str(pMiDdTC8LUE2wIV),'rb').read()
		x54xSdnCFHZ8yliofzOBK.sleep(1)
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(u0Y8HiytVNqc7mP+'.00'+str(pMiDdTC8LUE2wIV))
		except: pass
		if rJ2oTLqabRtA: ppvIDhVoiGHBN9Jm3X0ndk5A4j = ppvIDhVoiGHBN9Jm3X0ndk5A4j.decode(e87cIA5vwOQLDEP1)
		AZcqD1JHop2VujTysEewO = IXZpzK7ShaRsAN('list',ppvIDhVoiGHBN9Jm3X0ndk5A4j)
		del ppvIDhVoiGHBN9Jm3X0ndk5A4j
		VbxSkQef8wj,VRTAtMKBOzmL8jan9ydE5I,r9rciRhQKVk8UuDN2ELXPFl = m7mHORDqvGueozLchSjVsCpXNYAnW(AZcqD1JHop2VujTysEewO,ggCAyNbw6FDuBJQe,Gt6KHVDPcUdONbW4Y1RjrwZC,eyZpMs2rFO18wxR3mc,yrF5bEU9RHKv1YJN4cuW2GVtxwQ,VRTAtMKBOzmL8jan9ydE5I,lornYk4vh3qzcguy1i6Ibdj)
		if eyZpMs2rFO18wxR3mc.iscanceled():
			eyZpMs2rFO18wxR3mc.close()
			return
		if not VbxSkQef8wj:
			eyZpMs2rFO18wxR3mc.close()
			return
		BBmErNx6AoRZQGpLC += VbxSkQef8wj
		TPJe7wFd0tHIG9mQqsX5DoSR4MN += r9rciRhQKVk8UuDN2ELXPFl
	del AZcqD1JHop2VujTysEewO,VbxSkQef8wj
	Pl4hLnxzpSvRJKIj5EO,r9rciRhQKVk8UuDN2ELXPFl = CJlHN6OxDUa7RrX8Y3dLo2k1PVmjA(BBmErNx6AoRZQGpLC,eyZpMs2rFO18wxR3mc)
	if eyZpMs2rFO18wxR3mc.iscanceled():
		eyZpMs2rFO18wxR3mc.close()
		return
	TPJe7wFd0tHIG9mQqsX5DoSR4MN += r9rciRhQKVk8UuDN2ELXPFl
	del BBmErNx6AoRZQGpLC,r9rciRhQKVk8UuDN2ELXPFl
	rLVCFRJWH25nEyDj8OKebf,bXYPwNoE8df3FmlW5IQ,oZez0pJwEGVTRQlXYk7dP3Mh,KKuQomp80UG,WdMNhF6kga74ltPvozeLmZRxbQTuE = {},{},{},0,0
	vv8NWB0SJKnDmiI = list(Pl4hLnxzpSvRJKIj5EO.keys())
	ZyJaq3GdOnjbeQgVC = len(vv8NWB0SJKnDmiI)*3
	if 1:
		DXGtBIH8sVlzx6CrENfc7P3uT5Ov = {}
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj] = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=mhYgKiLrwkEt97c5jzyIP3upZSM1,args=(atXHKyxrnefOId1wj,))
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj].start()
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj].join()
		if eyZpMs2rFO18wxR3mc.iscanceled():
			eyZpMs2rFO18wxR3mc.close()
			return
	else:
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			mhYgKiLrwkEt97c5jzyIP3upZSM1(atXHKyxrnefOId1wj)
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return
	KJTcA2MurdEBbz(NLMU9xZPkX4t168usGzqSBfQCAJHg,False)
	vv8NWB0SJKnDmiI = list(rLVCFRJWH25nEyDj8OKebf.keys())
	gHxcolaXRekf3bQ72BrA = 0
	if 1:
		DXGtBIH8sVlzx6CrENfc7P3uT5Ov = {}
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj] = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=jiAx5HZdIF38WVkJ2MCfDaR1O,args=(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj))
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj].start()
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			DXGtBIH8sVlzx6CrENfc7P3uT5Ov[atXHKyxrnefOId1wj].join()
		if eyZpMs2rFO18wxR3mc.iscanceled():
			eyZpMs2rFO18wxR3mc.close()
			return
	else:
		for atXHKyxrnefOId1wj in vv8NWB0SJKnDmiI:
			jiAx5HZdIF38WVkJ2MCfDaR1O(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj)
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return
	pMiDdTC8LUE2wIV = 0
	KZM2FSPCJNnYg = len(TPJe7wFd0tHIG9mQqsX5DoSR4MN)
	HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,'IGNORED')
	for OHA1EuYXIWpNbs7w4CKMeVGBdJPZ in TPJe7wFd0tHIG9mQqsX5DoSR4MN:
		if pMiDdTC8LUE2wIV%27==0:
			tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,95+int(5*pMiDdTC8LUE2wIV//KZM2FSPCJNnYg),'تخزين المهملة','الفيديو رقم:-',str(pMiDdTC8LUE2wIV)+' / '+str(KZM2FSPCJNnYg))
			if eyZpMs2rFO18wxR3mc.iscanceled():
				eyZpMs2rFO18wxR3mc.close()
				return
		w1srYvgBLWStpZ29(HNpMfcnD0ZzK,'IGNORED',str(OHA1EuYXIWpNbs7w4CKMeVGBdJPZ),WnNGfosHr5STAq8j7miwyRZ6eOUbV,iXBqSkDU3mRCZf4Ib)
		pMiDdTC8LUE2wIV += 1
	w1srYvgBLWStpZ29(HNpMfcnD0ZzK,'IGNORED','__COUNT__',str(KZM2FSPCJNnYg),iXBqSkDU3mRCZf4Ib)
	w1srYvgBLWStpZ29(HNpMfcnD0ZzK,'DUMMY','__DUMMY__','1',iXBqSkDU3mRCZf4Ib)
	eyZpMs2rFO18wxR3mc.close()
	x54xSdnCFHZ8yliofzOBK.sleep(1)
	xA70hJbKyEGYnPoLlNTjMeDW = J3yzhQaVZgSseEtDqu1r2xlnoUP(NLMU9xZPkX4t168usGzqSBfQCAJHg,False)
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'تم جلب ملفات ـIPTV جديدة'+YVr6St5P4xsFC0aARQGKfiegD+'\n\n'+xA70hJbKyEGYnPoLlNTjMeDW)
	jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	XJNduZp9YOfjAB2(False)
	YINetiX57RwjFa4f1JBmS28Hx(False)
	return
def mhYgKiLrwkEt97c5jzyIP3upZSM1(atXHKyxrnefOId1wj):
	global eyZpMs2rFO18wxR3mc,Pl4hLnxzpSvRJKIj5EO,gHxcolaXRekf3bQ72BrA,rLVCFRJWH25nEyDj8OKebf,bXYPwNoE8df3FmlW5IQ,oZez0pJwEGVTRQlXYk7dP3Mh,KKuQomp80UG,WdMNhF6kga74ltPvozeLmZRxbQTuE,ZyJaq3GdOnjbeQgVC
	rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj] = {}
	JFns9Zo6mjMkpD12Cgqd48tAW,HtuBFSzXMfTe4npyQO = {},[]
	E1bOsJyYnaK7v4CkQ6Xcj8 = len(Pl4hLnxzpSvRJKIj5EO[atXHKyxrnefOId1wj])
	rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj]['__COUNT__'] = E1bOsJyYnaK7v4CkQ6Xcj8
	if E1bOsJyYnaK7v4CkQ6Xcj8>0:
		Ap517R2IKfmvo,d579dJFXfpL8QvlyP6,Riydz6Pj7BrvDMA5k2V4xQZKetGS8,jNPunKa1flVd,ZPoeGCSgHOmd8b1ViwMIKpFXrajAx = zip(*Pl4hLnxzpSvRJKIj5EO[atXHKyxrnefOId1wj])
		del d579dJFXfpL8QvlyP6,Riydz6Pj7BrvDMA5k2V4xQZKetGS8,jNPunKa1flVd
		ADru142VFyQs = list(set(Ap517R2IKfmvo))
		for zaeA2pkdbcqZgOvJxw9 in ADru142VFyQs:
			JFns9Zo6mjMkpD12Cgqd48tAW[zaeA2pkdbcqZgOvJxw9] = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj][zaeA2pkdbcqZgOvJxw9] = []
		tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,60+int(15*WdMNhF6kga74ltPvozeLmZRxbQTuE//ZyJaq3GdOnjbeQgVC),'تصنيع القوائم','الجزء رقم:-',str(WdMNhF6kga74ltPvozeLmZRxbQTuE)+' / '+str(ZyJaq3GdOnjbeQgVC))
		if eyZpMs2rFO18wxR3mc.iscanceled(): return
		WdMNhF6kga74ltPvozeLmZRxbQTuE += 1
		EFXRUSzyaBHgJVxPoYs75GkD = len(ADru142VFyQs)
		del ADru142VFyQs
		HtuBFSzXMfTe4npyQO = list(set(zip(Ap517R2IKfmvo,ZPoeGCSgHOmd8b1ViwMIKpFXrajAx)))
		del Ap517R2IKfmvo,ZPoeGCSgHOmd8b1ViwMIKpFXrajAx
		for zaeA2pkdbcqZgOvJxw9,dcsuVN65wyfR2EBqx8bXQMr in HtuBFSzXMfTe4npyQO:
			if not JFns9Zo6mjMkpD12Cgqd48tAW[zaeA2pkdbcqZgOvJxw9] and dcsuVN65wyfR2EBqx8bXQMr: JFns9Zo6mjMkpD12Cgqd48tAW[zaeA2pkdbcqZgOvJxw9] = dcsuVN65wyfR2EBqx8bXQMr
		tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,60+int(15*WdMNhF6kga74ltPvozeLmZRxbQTuE//ZyJaq3GdOnjbeQgVC),'تصنيع القوائم','الجزء رقم:-',str(WdMNhF6kga74ltPvozeLmZRxbQTuE)+' / '+str(ZyJaq3GdOnjbeQgVC))
		if eyZpMs2rFO18wxR3mc.iscanceled(): return
		WdMNhF6kga74ltPvozeLmZRxbQTuE += 1
		ExruZKyNsTBcLIaWSAb = list(JFns9Zo6mjMkpD12Cgqd48tAW.keys())
		eXC8AhnIc70QPKONHz6UR = list(JFns9Zo6mjMkpD12Cgqd48tAW.values())
		del JFns9Zo6mjMkpD12Cgqd48tAW
		HtuBFSzXMfTe4npyQO = list(zip(ExruZKyNsTBcLIaWSAb,eXC8AhnIc70QPKONHz6UR))
		del ExruZKyNsTBcLIaWSAb,eXC8AhnIc70QPKONHz6UR
		HtuBFSzXMfTe4npyQO = sorted(HtuBFSzXMfTe4npyQO)
	else: WdMNhF6kga74ltPvozeLmZRxbQTuE += 2
	rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj]['__GROUPS__'] = HtuBFSzXMfTe4npyQO
	del HtuBFSzXMfTe4npyQO
	for zaeA2pkdbcqZgOvJxw9,EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 in Pl4hLnxzpSvRJKIj5EO[atXHKyxrnefOId1wj]:
		rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj][zaeA2pkdbcqZgOvJxw9].append((EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0))
	tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,60+int(15*WdMNhF6kga74ltPvozeLmZRxbQTuE//ZyJaq3GdOnjbeQgVC),'تصنيع القوائم','الجزء رقم:-',str(WdMNhF6kga74ltPvozeLmZRxbQTuE)+' / '+str(ZyJaq3GdOnjbeQgVC))
	if eyZpMs2rFO18wxR3mc.iscanceled(): return
	WdMNhF6kga74ltPvozeLmZRxbQTuE += 1
	del Pl4hLnxzpSvRJKIj5EO[atXHKyxrnefOId1wj]
	oZez0pJwEGVTRQlXYk7dP3Mh[atXHKyxrnefOId1wj] = list(rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj].keys())
	bXYPwNoE8df3FmlW5IQ[atXHKyxrnefOId1wj] = len(oZez0pJwEGVTRQlXYk7dP3Mh[atXHKyxrnefOId1wj])
	KKuQomp80UG += bXYPwNoE8df3FmlW5IQ[atXHKyxrnefOId1wj]
	return
def jiAx5HZdIF38WVkJ2MCfDaR1O(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj):
	global eyZpMs2rFO18wxR3mc,Pl4hLnxzpSvRJKIj5EO,gHxcolaXRekf3bQ72BrA,rLVCFRJWH25nEyDj8OKebf,bXYPwNoE8df3FmlW5IQ,oZez0pJwEGVTRQlXYk7dP3Mh,KKuQomp80UG,WdMNhF6kga74ltPvozeLmZRxbQTuE,ZyJaq3GdOnjbeQgVC
	HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj)
	for VRTAtMKBOzmL8jan9ydE5I in range(1+bXYPwNoE8df3FmlW5IQ[atXHKyxrnefOId1wj]//273):
		QQiNvT8Xe7x = []
		hnwE40NOdJxq3lr9ZIb57UtRKCviyS = oZez0pJwEGVTRQlXYk7dP3Mh[atXHKyxrnefOId1wj][0:273]
		for zaeA2pkdbcqZgOvJxw9 in hnwE40NOdJxq3lr9ZIb57UtRKCviyS:
			QQiNvT8Xe7x.append(rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj][zaeA2pkdbcqZgOvJxw9])
		w1srYvgBLWStpZ29(HNpMfcnD0ZzK,atXHKyxrnefOId1wj,hnwE40NOdJxq3lr9ZIb57UtRKCviyS,QQiNvT8Xe7x,iXBqSkDU3mRCZf4Ib,True)
		gHxcolaXRekf3bQ72BrA += len(hnwE40NOdJxq3lr9ZIb57UtRKCviyS)
		tcZLDKnrTPNVOBF62w1(eyZpMs2rFO18wxR3mc,75+int(20*gHxcolaXRekf3bQ72BrA//KKuQomp80UG),'تخزين القوائم','القائمة رقم:-',str(gHxcolaXRekf3bQ72BrA)+' / '+str(KKuQomp80UG))
		if eyZpMs2rFO18wxR3mc.iscanceled(): return
		del oZez0pJwEGVTRQlXYk7dP3Mh[atXHKyxrnefOId1wj][0:273]
	del rLVCFRJWH25nEyDj8OKebf[atXHKyxrnefOId1wj],oZez0pJwEGVTRQlXYk7dP3Mh[atXHKyxrnefOId1wj],bXYPwNoE8df3FmlW5IQ[atXHKyxrnefOId1wj]
	return
def J3yzhQaVZgSseEtDqu1r2xlnoUP(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ=True):
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ): return
	RNgSJz1fOdPwb3GiA = Ew26Hg4SIj
	ffjXeCombvQSEY5hGpWcHtaRl2L3wU = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,'LIVE_ORIGINAL_GROUPED')
	tXlYoeEiaurLNq7f = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,'VOD_ORIGINAL_GROUPED')
	KZM2FSPCJNnYg = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','IGNORED','__COUNT__')
	KpmZOCAujW4zv = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	EEmwDlApqH6oBtrVdCkN3z8bxL = VolBUXWI42N1CF6RiKd(tXlYoeEiaurLNq7f,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	r1i8H42omBn6DRgtbEax75yMkzv = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','LIVE_GROUPED','__COUNT__')
	U52NHKzRISViFZnmgBWoYqe = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	F90WHChOVlRaUNPwIdko8EvKm2YZjJ = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','VOD_MOVIES_GROUPED','__COUNT__')
	sAdHOLrSkVGu9Z = VolBUXWI42N1CF6RiKd(tXlYoeEiaurLNq7f,'int','VOD_SERIES_GROUPED','__COUNT__')
	qq5kWHiTaOKIJ9lt = VolBUXWI42N1CF6RiKd(ffjXeCombvQSEY5hGpWcHtaRl2L3wU,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	oZez0pJwEGVTRQlXYk7dP3Mh = VolBUXWI42N1CF6RiKd(tXlYoeEiaurLNq7f,'list','VOD_SERIES_GROUPED','__GROUPS__')
	BNx9VzeQZ3ikImpaOqjvEuobPnWAMs = []
	for zaeA2pkdbcqZgOvJxw9,BYia4zgVcvkm75w3S0 in oZez0pJwEGVTRQlXYk7dP3Mh:
		ppQWwJgLojKthl2GxMb39DTIf7aOP = zaeA2pkdbcqZgOvJxw9.split('__SERIES__')[1]
		BNx9VzeQZ3ikImpaOqjvEuobPnWAMs.append(ppQWwJgLojKthl2GxMb39DTIf7aOP)
	N1R0uSXmvfwbspJBj8lZ6THroie = len(BNx9VzeQZ3ikImpaOqjvEuobPnWAMs)
	aNLpvrRPQu0OJIB4fFt8h = int(F90WHChOVlRaUNPwIdko8EvKm2YZjJ)+int(sAdHOLrSkVGu9Z)+int(qq5kWHiTaOKIJ9lt)+int(U52NHKzRISViFZnmgBWoYqe)+int(r1i8H42omBn6DRgtbEax75yMkzv)
	xA70hJbKyEGYnPoLlNTjMeDW = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	xA70hJbKyEGYnPoLlNTjMeDW += 'قنوات: '+str(r1i8H42omBn6DRgtbEax75yMkzv)
	xA70hJbKyEGYnPoLlNTjMeDW += '   .   أفلام: '+str(F90WHChOVlRaUNPwIdko8EvKm2YZjJ)
	xA70hJbKyEGYnPoLlNTjMeDW += '\nمسلسلات: '+str(N1R0uSXmvfwbspJBj8lZ6THroie)
	xA70hJbKyEGYnPoLlNTjMeDW += '   .   حلقات: '+str(sAdHOLrSkVGu9Z)
	xA70hJbKyEGYnPoLlNTjMeDW += '\nقنوات مجهولة: '+str(U52NHKzRISViFZnmgBWoYqe)
	xA70hJbKyEGYnPoLlNTjMeDW += '   .   فيدوهات مجهولة: '+str(qq5kWHiTaOKIJ9lt)
	xA70hJbKyEGYnPoLlNTjMeDW += '\nمجموع القنوات: '+str(KpmZOCAujW4zv)
	xA70hJbKyEGYnPoLlNTjMeDW += '   .   مجموع الفيديوهات: '+str(EEmwDlApqH6oBtrVdCkN3z8bxL)
	xA70hJbKyEGYnPoLlNTjMeDW += '\n\nمجموع المضافة: '+str(aNLpvrRPQu0OJIB4fFt8h)
	xA70hJbKyEGYnPoLlNTjMeDW += '   .   مجموع المهملة: '+str(KZM2FSPCJNnYg)
	if P3MDcw5Ln182FoqAVpZ: BGQXvd2lsicjVTgnHYRo74qDI3z('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,RNgSJz1fOdPwb3GiA,xA70hJbKyEGYnPoLlNTjMeDW)
	wTlN7y1qhk4BXv5eO = xA70hJbKyEGYnPoLlNTjMeDW.replace('\n\n',WBDnh75CaLEvkcN6p4ez2KXrV3M)
	SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,'.\tCounts of IPTV videos   Folder: '+NLMU9xZPkX4t168usGzqSBfQCAJHg+WBDnh75CaLEvkcN6p4ez2KXrV3M+wTlN7y1qhk4BXv5eO)
	return xA70hJbKyEGYnPoLlNTjMeDW
def KJTcA2MurdEBbz(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ=True):
	if P3MDcw5Ln182FoqAVpZ:
		PJtTMSG4ahksq = TPNsmjik1eh4Wc('center',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if PJtTMSG4ahksq!=1: return
		uLIrdZa7NKqBsU = Q3QtWFwqHp0mAVkJXguPb7LZSKcNzO.replace('___','_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(uLIrdZa7NKqBsU)
		except: pass
	uLIrdZa7NKqBsU = IAz7jaYKpBx592rLDEZFlOgsST.replace('___','_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(uLIrdZa7NKqBsU)
	except: pass
	uLIrdZa7NKqBsU = D7YNmfTjSnq1a0V2EvwAFp.replace('___','_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(uLIrdZa7NKqBsU)
	except: pass
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'SECTIONS_IPTV','SECTIONS_IPTV_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	XJNduZp9YOfjAB2(False)
	jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if P3MDcw5Ln182FoqAVpZ:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'تم مسح جميع ملفات ـIPTV')
		YINetiX57RwjFa4f1JBmS28Hx(False)
	return
def iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg=WnNGfosHr5STAq8j7miwyRZ6eOUbV,P3MDcw5Ln182FoqAVpZ=True):
	if NLMU9xZPkX4t168usGzqSBfQCAJHg:
		HNpMfcnD0ZzK = VOS8jrAvJLEa(str(NLMU9xZPkX4t168usGzqSBfQCAJHg),'DUMMY')
		jAPL6vaKoNeCJx5QGEH2h9UVn1w = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'str','DUMMY','__DUMMY__')
		if jAPL6vaKoNeCJx5QGEH2h9UVn1w: return True
	else:
		NLMU9xZPkX4t168usGzqSBfQCAJHg = '1'
		for iJ8kecmy3GgAv in range(1,ekgSRBGHWzUI5MqNDQV190ay8LonOp+1):
			HNpMfcnD0ZzK = VOS8jrAvJLEa(str(iJ8kecmy3GgAv),'DUMMY')
			jAPL6vaKoNeCJx5QGEH2h9UVn1w = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'str','DUMMY','__DUMMY__')
			if jAPL6vaKoNeCJx5QGEH2h9UVn1w: return True
	if P3MDcw5Ln182FoqAVpZ:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+e6HEdvUcaq8Gx+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+YVr6St5P4xsFC0aARQGKfiegD)
		RNgSJz1fOdPwb3GiA = 'إضافة وتغيير رابط '+ww07SKUt2HgnRG[1]+' (مجلد '+ww07SKUt2HgnRG[int(NLMU9xZPkX4t168usGzqSBfQCAJHg)]+')'
		PJtTMSG4ahksq = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,RNgSJz1fOdPwb3GiA,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if PJtTMSG4ahksq==1: qIKy9ReSwsDpNYtXiT5FbLVlMUEJgG(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	return False
def pBzAsvx3aVgUWSnyrH0(qpL93o1bJBxXRyFf846,NLMU9xZPkX4t168usGzqSBfQCAJHg=WnNGfosHr5STAq8j7miwyRZ6eOUbV,atXHKyxrnefOId1wj=WnNGfosHr5STAq8j7miwyRZ6eOUbV,DHgfWI8yeZ6h1jq7xdwT2ABM=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not DHgfWI8yeZ6h1jq7xdwT2ABM: DHgfWI8yeZ6h1jq7xdwT2ABM = '1'
	lU2oX9uKy8AGw60I4vzV7e,aksIy7wNYp2W,P3MDcw5Ln182FoqAVpZ = XgnSRzMaerBT(qpL93o1bJBxXRyFf846)
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ): return
	if not lU2oX9uKy8AGw60I4vzV7e:
		lU2oX9uKy8AGw60I4vzV7e = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not lU2oX9uKy8AGw60I4vzV7e: return
	ji3QtV0o6G7mX = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not atXHKyxrnefOId1wj:
		if not P3MDcw5Ln182FoqAVpZ:
			if   '_IPTV-LIVE_' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[1]
			elif '_IPTV-MOVIES' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[2]
			elif '_IPTV-SERIES' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[3]
			else: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[0]
		else:
			laVmM63ntpdWC5xcehyzG8 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			UqCAgBwjTuoVyn0evI = A3DjqpQcnvi6O0oXxGTlz19ytdKu('أختر البحث المناسب', laVmM63ntpdWC5xcehyzG8)
			if UqCAgBwjTuoVyn0evI==-1: return
			atXHKyxrnefOId1wj = ji3QtV0o6G7mX[UqCAgBwjTuoVyn0evI]
	lU2oX9uKy8AGw60I4vzV7e = lU2oX9uKy8AGw60I4vzV7e+'_NODIALOGS_'
	if NLMU9xZPkX4t168usGzqSBfQCAJHg: twlMRiYrqHQSmcZpKB2gfbD6(lU2oX9uKy8AGw60I4vzV7e,NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj,DHgfWI8yeZ6h1jq7xdwT2ABM)
	else:
		for NLMU9xZPkX4t168usGzqSBfQCAJHg in range(1,ekgSRBGHWzUI5MqNDQV190ay8LonOp+1):
			twlMRiYrqHQSmcZpKB2gfbD6(lU2oX9uKy8AGw60I4vzV7e,str(NLMU9xZPkX4t168usGzqSBfQCAJHg),atXHKyxrnefOId1wj,DHgfWI8yeZ6h1jq7xdwT2ABM)
		A3pXVFdyP1.menuItemsLIST[:] = sorted(A3pXVFdyP1.menuItemsLIST,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk[1].lower())
	return
def twlMRiYrqHQSmcZpKB2gfbD6(qpL93o1bJBxXRyFf846,NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj=WnNGfosHr5STAq8j7miwyRZ6eOUbV,DHgfWI8yeZ6h1jq7xdwT2ABM=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not DHgfWI8yeZ6h1jq7xdwT2ABM: DHgfWI8yeZ6h1jq7xdwT2ABM = '1'
	lU2oX9uKy8AGw60I4vzV7e,aksIy7wNYp2W,P3MDcw5Ln182FoqAVpZ = XgnSRzMaerBT(qpL93o1bJBxXRyFf846)
	if not NLMU9xZPkX4t168usGzqSBfQCAJHg: return
	if not iI5rl4JkL8Ks1go6fUxXN9w7tj(NLMU9xZPkX4t168usGzqSBfQCAJHg,P3MDcw5Ln182FoqAVpZ): return
	if not lU2oX9uKy8AGw60I4vzV7e:
		lU2oX9uKy8AGw60I4vzV7e = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not lU2oX9uKy8AGw60I4vzV7e: return
	ji3QtV0o6G7mX = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not atXHKyxrnefOId1wj:
		if not P3MDcw5Ln182FoqAVpZ:
			if   '_IPTV-LIVE_' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[1]
			elif '_IPTV-MOVIES' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[2]
			elif '_IPTV-SERIES' in aksIy7wNYp2W: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[3]
			else: atXHKyxrnefOId1wj = ji3QtV0o6G7mX[0]
		else:
			laVmM63ntpdWC5xcehyzG8 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			UqCAgBwjTuoVyn0evI = A3DjqpQcnvi6O0oXxGTlz19ytdKu('أختر البحث المناسب', laVmM63ntpdWC5xcehyzG8)
			if UqCAgBwjTuoVyn0evI==-1: return
			atXHKyxrnefOId1wj = ji3QtV0o6G7mX[UqCAgBwjTuoVyn0evI]
	JJQdmw0OonCLyfXZul = lU2oX9uKy8AGw60I4vzV7e.lower()
	HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,'SEARCH')
	ww9PixygdMfDQJt = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list','SEARCH',(atXHKyxrnefOId1wj,JJQdmw0OonCLyfXZul))
	if not ww9PixygdMfDQJt:
		gNvp9u6fGSJYF,kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or = [],[]
		if not atXHKyxrnefOId1wj: axIQvb7iphVLANw = [1,2,3,4,5]
		else: axIQvb7iphVLANw = [ji3QtV0o6G7mX.index(atXHKyxrnefOId1wj)]
		for pMiDdTC8LUE2wIV in axIQvb7iphVLANw:
			HNpMfcnD0ZzK = VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,ji3QtV0o6G7mX[pMiDdTC8LUE2wIV])
			if pMiDdTC8LUE2wIV!=3:
				VbxSkQef8wj = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'dict',ji3QtV0o6G7mX[pMiDdTC8LUE2wIV])
				del VbxSkQef8wj['__COUNT__']
				del VbxSkQef8wj['__GROUPS__']
				del VbxSkQef8wj['__SEQUENCED_COLUMNS__']
				oZez0pJwEGVTRQlXYk7dP3Mh = list(VbxSkQef8wj.keys())
				for zaeA2pkdbcqZgOvJxw9 in oZez0pJwEGVTRQlXYk7dP3Mh:
					for EaOw4PxtyQpZXM3,fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 in VbxSkQef8wj[zaeA2pkdbcqZgOvJxw9]:
						if JJQdmw0OonCLyfXZul in fdVN5r3jJlQXZ2yn1a6SesTWoK0.lower(): kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or.append((fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0))
					del VbxSkQef8wj[zaeA2pkdbcqZgOvJxw9]
				del VbxSkQef8wj
			else: oZez0pJwEGVTRQlXYk7dP3Mh = VolBUXWI42N1CF6RiKd(HNpMfcnD0ZzK,'list',ji3QtV0o6G7mX[pMiDdTC8LUE2wIV],'__GROUPS__')
			for zaeA2pkdbcqZgOvJxw9 in oZez0pJwEGVTRQlXYk7dP3Mh:
				try: zaeA2pkdbcqZgOvJxw9,BYia4zgVcvkm75w3S0 = zaeA2pkdbcqZgOvJxw9
				except: BYia4zgVcvkm75w3S0 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				if JJQdmw0OonCLyfXZul in zaeA2pkdbcqZgOvJxw9.lower():
					if pMiDdTC8LUE2wIV!=3: P49PukUFAayMs8pbGeDoYE = zaeA2pkdbcqZgOvJxw9
					else:
						iV97NdAY6h8Oj,Hu2caRiQKSymFdIfqACEZPvpT93w = zaeA2pkdbcqZgOvJxw9.split('__SERIES__')
						if JJQdmw0OonCLyfXZul in iV97NdAY6h8Oj.lower(): P49PukUFAayMs8pbGeDoYE = iV97NdAY6h8Oj
						else: P49PukUFAayMs8pbGeDoYE = Hu2caRiQKSymFdIfqACEZPvpT93w
					gNvp9u6fGSJYF.append((zaeA2pkdbcqZgOvJxw9,P49PukUFAayMs8pbGeDoYE,ji3QtV0o6G7mX[pMiDdTC8LUE2wIV],BYia4zgVcvkm75w3S0))
			del oZez0pJwEGVTRQlXYk7dP3Mh
		gNvp9u6fGSJYF = set(gNvp9u6fGSJYF)
		kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or = set(kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or)
		gNvp9u6fGSJYF = sorted(gNvp9u6fGSJYF,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk[1])
		kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or = sorted(kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk[0])
		w1srYvgBLWStpZ29(HNpMfcnD0ZzK,'SEARCH',(atXHKyxrnefOId1wj,JJQdmw0OonCLyfXZul),(gNvp9u6fGSJYF,kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or),iXBqSkDU3mRCZf4Ib)
	else: gNvp9u6fGSJYF,kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or = ww9PixygdMfDQJt
	oZez0pJwEGVTRQlXYk7dP3Mh = len(gNvp9u6fGSJYF)
	L48Pxkd07fHtgW9OCDoRsz2ei = len(kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or)
	BfYlvNejqzRc2PDdFiAV9 = int(DHgfWI8yeZ6h1jq7xdwT2ABM)
	xyBGOhkjbn7moYzqsg2MNVA54JF = max(0,(BfYlvNejqzRc2PDdFiAV9-1)*100)
	vIVlK0hMUpomJ58bFY2x7C = max(0,BfYlvNejqzRc2PDdFiAV9*100)
	FvDeObZT7Mi2SEKWypnkC = max(0,xyBGOhkjbn7moYzqsg2MNVA54JF-oZez0pJwEGVTRQlXYk7dP3Mh)
	MdXWkcUw1IR = max(0,vIVlK0hMUpomJ58bFY2x7C-oZez0pJwEGVTRQlXYk7dP3Mh)
	for zaeA2pkdbcqZgOvJxw9,P49PukUFAayMs8pbGeDoYE,RCjhJsXmYg,BYia4zgVcvkm75w3S0 in gNvp9u6fGSJYF[xyBGOhkjbn7moYzqsg2MNVA54JF:vIVlK0hMUpomJ58bFY2x7C]:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+P49PukUFAayMs8pbGeDoYE,RCjhJsXmYg,234,BYia4zgVcvkm75w3S0,'1',zaeA2pkdbcqZgOvJxw9,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	del gNvp9u6fGSJYF
	for fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,BYia4zgVcvkm75w3S0 in kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or[FvDeObZT7Mi2SEKWypnkC:MdXWkcUw1IR]:
		UUqoM3H56WvGV2kJymiY = mm19wY7OfIvCxb8AFZEHJ(uuSU5Awl8FNrzkXHdQDiCWq3)
		t0xkM74rgEAFIepSWXilNOGDn = 'live'
		if '.mkv' in UUqoM3H56WvGV2kJymiY or 'VOD' in atXHKyxrnefOId1wj: t0xkM74rgEAFIepSWXilNOGDn = 'video'
		octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,235,BYia4zgVcvkm75w3S0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	del kf4EPcKVBlC1pqhbsdFGxoX6LSI2Or
	xxNgPGLoIwkY9a7WKC6bMtVRmZF(NLMU9xZPkX4t168usGzqSBfQCAJHg,DHgfWI8yeZ6h1jq7xdwT2ABM,atXHKyxrnefOId1wj,239,oZez0pJwEGVTRQlXYk7dP3Mh+L48Pxkd07fHtgW9OCDoRsz2ei,lU2oX9uKy8AGw60I4vzV7e+'_NODIALOGS_')
	return
def xxNgPGLoIwkY9a7WKC6bMtVRmZF(NLMU9xZPkX4t168usGzqSBfQCAJHg,DHgfWI8yeZ6h1jq7xdwT2ABM,atXHKyxrnefOId1wj,HOkAWvmZSP5c2t9Dq4NgELyps,aNLpvrRPQu0OJIB4fFt8h,ZVk6IphECKLzUceP15j):
	if DHgfWI8yeZ6h1jq7xdwT2ABM!='1': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'صفحة '+str(1),atXHKyxrnefOId1wj,HOkAWvmZSP5c2t9Dq4NgELyps,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(1),ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	if not aNLpvrRPQu0OJIB4fFt8h: aNLpvrRPQu0OJIB4fFt8h = 0
	JYZmp9CWrqvu7H1G = int(aNLpvrRPQu0OJIB4fFt8h/100)+1
	for BfYlvNejqzRc2PDdFiAV9 in range(2,JYZmp9CWrqvu7H1G):
		LZVsiu43PBxwtWTQjN0K25pIh = (BfYlvNejqzRc2PDdFiAV9%10==0 or int(DHgfWI8yeZ6h1jq7xdwT2ABM)-4<BfYlvNejqzRc2PDdFiAV9<int(DHgfWI8yeZ6h1jq7xdwT2ABM)+4)
		h0A9UrLa7Xx4jJwSzgoOk = (LZVsiu43PBxwtWTQjN0K25pIh and int(DHgfWI8yeZ6h1jq7xdwT2ABM)-40<BfYlvNejqzRc2PDdFiAV9<int(DHgfWI8yeZ6h1jq7xdwT2ABM)+40)
		if str(BfYlvNejqzRc2PDdFiAV9)!=DHgfWI8yeZ6h1jq7xdwT2ABM and (BfYlvNejqzRc2PDdFiAV9%100==0 or h0A9UrLa7Xx4jJwSzgoOk):
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'صفحة '+str(BfYlvNejqzRc2PDdFiAV9),atXHKyxrnefOId1wj,HOkAWvmZSP5c2t9Dq4NgELyps,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(BfYlvNejqzRc2PDdFiAV9),ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	if str(JYZmp9CWrqvu7H1G)!=DHgfWI8yeZ6h1jq7xdwT2ABM: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+'أخر صفحة '+str(JYZmp9CWrqvu7H1G),atXHKyxrnefOId1wj,HOkAWvmZSP5c2t9Dq4NgELyps,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(JYZmp9CWrqvu7H1G),ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	return
def VOS8jrAvJLEa(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj):
	if 'SERIES' in atXHKyxrnefOId1wj or 'VOD_ORIGINAL' in atXHKyxrnefOId1wj: HNpMfcnD0ZzK = D7YNmfTjSnq1a0V2EvwAFp
	else: HNpMfcnD0ZzK = IAz7jaYKpBx592rLDEZFlOgsST
	HNpMfcnD0ZzK = HNpMfcnD0ZzK.replace('___','_'+NLMU9xZPkX4t168usGzqSBfQCAJHg)
	return HNpMfcnD0ZzK
def S9FRyAWhGEpf8(NLMU9xZPkX4t168usGzqSBfQCAJHg,atXHKyxrnefOId1wj,xCwozyfBtFKOSGqDYQIrRbPaiWv03):
	ZnFkGo4Jb0RC5z32WwdD89cQAjeSa,lornYk4vh3qzcguy1i6Ibdj,ssdNJZO3mwnA8F4h0S9,HyYITOrjQqS6,RVnvEpPTX5Z0B72QHmWh3 = qQdatloHk0v7MGi(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if not HyYITOrjQqS6: return
	d91ITp3ybeYCWjGBFHqkD7voru6Eg = sLZa8dgblSKP6WFMtYjrAw1(NLMU9xZPkX4t168usGzqSBfQCAJHg)
	if   atXHKyxrnefOId1wj=='XTREAM_LIVE_GROUPS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_live_categories'
	elif atXHKyxrnefOId1wj=='XTREAM_VOD_GROUPS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_vod_categories'
	elif atXHKyxrnefOId1wj=='XTREAM_SERIES_GROUPS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_series_categories'
	elif atXHKyxrnefOId1wj=='XTREAM_LIVE_ITEMS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_live_streams&category_id='+xCwozyfBtFKOSGqDYQIrRbPaiWv03
	elif atXHKyxrnefOId1wj=='XTREAM_VOD_ITEMS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_vod_streams&category_id='+xCwozyfBtFKOSGqDYQIrRbPaiWv03
	elif atXHKyxrnefOId1wj=='XTREAM_SERIES_ITEMS': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_series&category_id='+xCwozyfBtFKOSGqDYQIrRbPaiWv03
	elif atXHKyxrnefOId1wj=='XTREAM_EPISODES': uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa+'&action=get_series_info&series_id='+xCwozyfBtFKOSGqDYQIrRbPaiWv03
	else: return
	lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',uuSU5Awl8FNrzkXHdQDiCWq3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'IPTV-XTREAM_MENUS-1st')
	lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
	if YVzokG2yZqrh3w8bU: lXqaJs1WkUZ9Rz0 = lXqaJs1WkUZ9Rz0.decode(e87cIA5vwOQLDEP1).encode(e87cIA5vwOQLDEP1)
	G7yQw2xFLI9TbVngqD3MzOeW8r5klP = IXZpzK7ShaRsAN('list',lXqaJs1WkUZ9Rz0)
	if 'GROUPS' in atXHKyxrnefOId1wj:
		atXHKyxrnefOId1wj = atXHKyxrnefOId1wj.replace('_GROUPS','_ITEMS')
		G7yQw2xFLI9TbVngqD3MzOeW8r5klP = sorted(G7yQw2xFLI9TbVngqD3MzOeW8r5klP,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk['category_name'].lower())
		for zaeA2pkdbcqZgOvJxw9 in G7yQw2xFLI9TbVngqD3MzOeW8r5klP:
			FFJI12Sbzn9TslBfPhGDuCZgyQ = zaeA2pkdbcqZgOvJxw9['category_id']
			fdVN5r3jJlQXZ2yn1a6SesTWoK0 = zaeA2pkdbcqZgOvJxw9['category_name']
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,atXHKyxrnefOId1wj,285,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(FFJI12Sbzn9TslBfPhGDuCZgyQ),WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	elif atXHKyxrnefOId1wj=='XTREAM_SERIES_ITEMS':
		G7yQw2xFLI9TbVngqD3MzOeW8r5klP = sorted(G7yQw2xFLI9TbVngqD3MzOeW8r5klP,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk['name'].lower())
		for gs6qH9WXv7eU4I3fcOj in G7yQw2xFLI9TbVngqD3MzOeW8r5klP:
			fdVN5r3jJlQXZ2yn1a6SesTWoK0 = gs6qH9WXv7eU4I3fcOj['name']
			dcsuVN65wyfR2EBqx8bXQMr = gs6qH9WXv7eU4I3fcOj['cover']
			FFJI12Sbzn9TslBfPhGDuCZgyQ = gs6qH9WXv7eU4I3fcOj['series_id']
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,'XTREAM_EPISODES',285,dcsuVN65wyfR2EBqx8bXQMr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(FFJI12Sbzn9TslBfPhGDuCZgyQ),WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	elif atXHKyxrnefOId1wj=='XTREAM_EPISODES':
		dcsuVN65wyfR2EBqx8bXQMr = G7yQw2xFLI9TbVngqD3MzOeW8r5klP['info']['cover']
		fzu7Got0FgiyshTlJK = G7yQw2xFLI9TbVngqD3MzOeW8r5klP['info']['name']
		at1vFD8ZrwJ0ACMXfiRTkoxpGVgLIz = G7yQw2xFLI9TbVngqD3MzOeW8r5klP['episodes']
		for vThOenVo8caKwUsEY in at1vFD8ZrwJ0ACMXfiRTkoxpGVgLIz:
			H5HVFzu96TaKsgfEUOt1ZYkev = at1vFD8ZrwJ0ACMXfiRTkoxpGVgLIz[vThOenVo8caKwUsEY]
			for EEwgHlOfZi83520y in H5HVFzu96TaKsgfEUOt1ZYkev:
				fdVN5r3jJlQXZ2yn1a6SesTWoK0 = EEwgHlOfZi83520y['title']
				zP9lmkf3IU1w2vJpE46eFLyBVN = p7dwlH1PRStBgyMUW.findall('\d+.(S\d+E\d+)',fdVN5r3jJlQXZ2yn1a6SesTWoK0,p7dwlH1PRStBgyMUW.DOTALL)
				if zP9lmkf3IU1w2vJpE46eFLyBVN: fdVN5r3jJlQXZ2yn1a6SesTWoK0 = fzu7Got0FgiyshTlJK+kcXMWrwiLDKeBHRsJ+zP9lmkf3IU1w2vJpE46eFLyBVN[0]
				FFJI12Sbzn9TslBfPhGDuCZgyQ = EEwgHlOfZi83520y['id']
				lw6pxds2VL54vtOJbBZMyq9 = EEwgHlOfZi83520y['container_extension']
				uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa.split('/player_api.php')[0]+'/series/'+HyYITOrjQqS6+'/'+RVnvEpPTX5Z0B72QHmWh3+'/'+str(FFJI12Sbzn9TslBfPhGDuCZgyQ)+'.'+lw6pxds2VL54vtOJbBZMyq9
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,235,dcsuVN65wyfR2EBqx8bXQMr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	elif 'ITEMS' in atXHKyxrnefOId1wj:
		t0xkM74rgEAFIepSWXilNOGDn = 'live' if 'LIVE' in atXHKyxrnefOId1wj else 'video'
		G7yQw2xFLI9TbVngqD3MzOeW8r5klP = sorted(G7yQw2xFLI9TbVngqD3MzOeW8r5klP,reverse=False,key=lambda LoeIfPVjrk: LoeIfPVjrk['name'].lower())
		for e2uHcaqFOB7DThd in G7yQw2xFLI9TbVngqD3MzOeW8r5klP:
			fdVN5r3jJlQXZ2yn1a6SesTWoK0 = e2uHcaqFOB7DThd['name']
			dcsuVN65wyfR2EBqx8bXQMr = e2uHcaqFOB7DThd['stream_icon']
			FFJI12Sbzn9TslBfPhGDuCZgyQ = e2uHcaqFOB7DThd['stream_id']
			try:
				lw6pxds2VL54vtOJbBZMyq9 = e2uHcaqFOB7DThd['container_extension']
				if lw6pxds2VL54vtOJbBZMyq9: lw6pxds2VL54vtOJbBZMyq9 = '.'+lw6pxds2VL54vtOJbBZMyq9
			except: lw6pxds2VL54vtOJbBZMyq9 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if e2uHcaqFOB7DThd['stream_type']=='live': dFHDUo5Kk9ec,GW0nqChId6fuOTlYJpVb8BEaRXi = WnNGfosHr5STAq8j7miwyRZ6eOUbV,'live'
			elif e2uHcaqFOB7DThd['stream_type']=='movie': dFHDUo5Kk9ec,GW0nqChId6fuOTlYJpVb8BEaRXi = 'movie/','video'
			uuSU5Awl8FNrzkXHdQDiCWq3 = ZnFkGo4Jb0RC5z32WwdD89cQAjeSa.split('/player_api.php')[0]+'/'+dFHDUo5Kk9ec+HyYITOrjQqS6+'/'+RVnvEpPTX5Z0B72QHmWh3+'/'+str(FFJI12Sbzn9TslBfPhGDuCZgyQ)+lw6pxds2VL54vtOJbBZMyq9
			octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,utGmJTNWUpy9KnVf1hd+fdVN5r3jJlQXZ2yn1a6SesTWoK0,uuSU5Awl8FNrzkXHdQDiCWq3,235,dcsuVN65wyfR2EBqx8bXQMr,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{'folder':NLMU9xZPkX4t168usGzqSBfQCAJHg})
	return
def jdXzoQMHmTVB(NLMU9xZPkX4t168usGzqSBfQCAJHg):
	G1GKFlN08ua7PgdAspzfB94UkCow = G3yDpvxOiSWdAeL.getSetting('av.language.provider')
	h7kzQ0BeCjGXa3JWU9ry8d2 = G3yDpvxOiSWdAeL.getSetting('av.language.code')
	sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'MENUS_CACHE_'+G1GKFlN08ua7PgdAspzfB94UkCow+'_'+h7kzQ0BeCjGXa3JWU9ry8d2,'%_IP'+NLMU9xZPkX4t168usGzqSBfQCAJHg+'_%')
	return