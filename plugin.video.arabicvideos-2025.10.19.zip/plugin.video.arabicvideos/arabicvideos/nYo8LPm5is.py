# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = KLX7hW0nBAEgy6m4SvH(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
uBQ9txp0gDrEhZTcJOi74SKVw3k = pp7FcjEe6g(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
yFhL93qivu2zxUKjp6CD = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(uxKbUolc0WrM57w,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
wLeokD3gz78VXTjvEsxfimay = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(uxKbUolc0WrM57w,wwWzyF4ZpSQXKOgk569(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
uudSqMfmscOgJFlUanLT5 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(sVeEnGfl8B,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
TuU8lj6For = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
IN8yQCGZMhvzFWrBV9PYtf1RaD6k5 = gPE1XB87fQl(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
JUrguKsh8lix3dtkya759fX0WAHSF = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
aukK2mVLBSNTv1RlF9b = eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
lVJinQSoCfdLmv5KW4DrbFRG6sZA0 = mq5t9JXSdHT8yfDVF(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
Mo915Elfd8WcNyeC = oiWNFYzcIUeh(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
brMfeRh67zQ2YDEvx3sJtOB0yUPXV = Hp7qgMcFCX46nO8Poy
otGFedruwv5x8VablMHAOfDC4 = kcCgDi2EzhU5s413pAjSmu
CXv1WnOD6PEF0mhKcp7lQ = MFlX6x0hzm
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps):
	if   HOkAWvmZSP5c2t9Dq4NgELyps==KLX7hW0nBAEgy6m4SvH(u"࠹࠷࠴ࣉ"): APpdhB1Fk58MmJH7CjVntowyaY = x7CbFHTyXKtUdmlWriEsGBz3n()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠺࠸࠶࣊"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(yFhL93qivu2zxUKjp6CD,r0D4C3z7Onqpa,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==SI7eBdND4lx8pt5Qk(u"࠻࠹࠸࣋"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(wLeokD3gz78VXTjvEsxfimay,r0D4C3z7Onqpa,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==beV5l2D8HznyJI0(u"࠼࠺࠳࣌"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(uudSqMfmscOgJFlUanLT5,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠽࠴࠵࣍"): APpdhB1Fk58MmJH7CjVntowyaY = dXNLv3gHJ4bFE8TqQ5nGYlVO(r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==A6iX18qgyOFlZxz7sc(u"࠷࠵࠷࣎"): APpdhB1Fk58MmJH7CjVntowyaY = azdGBC51hPg8J6wR3H(r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==gPE1XB87fQl(u"࠸࠶࠹࣏"): APpdhB1Fk58MmJH7CjVntowyaY = pZB6wQNYUrEIMR5zmL9k(r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠹࠸࠴࣐"): APpdhB1Fk58MmJH7CjVntowyaY = OtfSqFzCivLgQreNbuU32HXsZ()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠺࠹࠶࣑"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(TuU8lj6For,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==KLX7hW0nBAEgy6m4SvH(u"࠻࠺࠸࣒"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(IN8yQCGZMhvzFWrBV9PYtf1RaD6k5,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠼࠻࠳࣓"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(JUrguKsh8lix3dtkya759fX0WAHSF,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==IMjqygdfYSKpHlWu5Aa(u"࠽࠵࠵ࣔ"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(aukK2mVLBSNTv1RlF9b,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==mq5t9JXSdHT8yfDVF(u"࠷࠶࠷ࣕ"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(lVJinQSoCfdLmv5KW4DrbFRG6sZA0,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==wwWzyF4ZpSQXKOgk569(u"࠸࠷࠹ࣖ"): APpdhB1Fk58MmJH7CjVntowyaY = r670fZQYnxlNOUoVBbMJa(Mo915Elfd8WcNyeC,KiryBCvngZzF85UN6xSDlOVweL4I9,r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠹࠸࠻ࣗ"): APpdhB1Fk58MmJH7CjVntowyaY = PWv3xqoF6pStz049(r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠺࠹࠽ࣘ"): APpdhB1Fk58MmJH7CjVntowyaY = NgIlELWr0U1uPwntF7jVmfOX9Yxvc();CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==oiWNFYzcIUeh(u"࠵࠵࠾࠰ࣙ"): APpdhB1Fk58MmJH7CjVntowyaY = Lghe7dJAfVtO09BmHi53oSQ()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==tzZ6PhyDOUnwLM3pdK(u"࠶࠶࠸࠲ࣚ"): APpdhB1Fk58MmJH7CjVntowyaY = eeCvhK0mSs2PTZxpG(r0D4C3z7Onqpa);CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==YYQS36fyPvtuzcEmRL(u"࠷࠰࠹࠴ࣛ"): APpdhB1Fk58MmJH7CjVntowyaY = P8IALOEd4DZUz2iqSRNTwm();CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==beV5l2D8HznyJI0(u"࠱࠱࠺࠶ࣜ"): APpdhB1Fk58MmJH7CjVntowyaY = u19E0QvcbTXKa();CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==IMjqygdfYSKpHlWu5Aa(u"࠲࠲࠻࠸ࣝ"): APpdhB1Fk58MmJH7CjVntowyaY = wF0hASkpizU();CGlWmDiBwzq2(APpdhB1Fk58MmJH7CjVntowyaY)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==oiWNFYzcIUeh(u"࠳࠳࠼࠺ࣞ"): APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠴࠴࠽࠼ࣟ"): APpdhB1Fk58MmJH7CjVntowyaY = SSoTe01EcipzAn5kq4DOjgfhW()
	else: APpdhB1Fk58MmJH7CjVntowyaY = KiryBCvngZzF85UN6xSDlOVweL4I9
	return APpdhB1Fk58MmJH7CjVntowyaY
def SSoTe01EcipzAn5kq4DOjgfhW():
	L3EJrtxTWiUMGHylNFkCs5vdK8w2Q = oiWNFYzcIUeh(u"࠵࠵࠸࠴࣠")*oiWNFYzcIUeh(u"࠵࠵࠸࠴࣠")
	xPrTHD2dgMBLIwq7o6Na4JAjmOK = YvUPLVEzOe3g7tw8C4amxKSGrM()//L3EJrtxTWiUMGHylNFkCs5vdK8w2Q
	Y2YPQJ9sRThIozu3ClHEBw0Dg = xPrTHD2dgMBLIwq7o6Na4JAjmOK<kdRO82AImh0LFw(u"࠺࠶࣡")
	size = e6HEdvUcaq8Gx+mq5t9JXSdHT8yfDVF(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+YVr6St5P4xsFC0aARQGKfiegD
	if Y2YPQJ9sRThIozu3ClHEBw0Dg:
		SWPHEjbmMfZDpi(FK6PHeEpSvXsqt83WflBYQ,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(xPrTHD2dgMBLIwq7o6Na4JAjmOK)+GHg28TBchiyn6l(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,YYQS36fyPvtuzcEmRL(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return Y2YPQJ9sRThIozu3ClHEBw0Dg
def CGlWmDiBwzq2(AYNw6tITVipuHFjKqv3O):
	if AYNw6tITVipuHFjKqv3O: YINetiX57RwjFa4f1JBmS28Hx(r0D4C3z7Onqpa)
	return
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL(GHg28TBchiyn6l(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),kdRO82AImh0LFw(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"࠷࠰࠹࠸࣢"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),oiWNFYzcIUeh(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠷࠶࠲ࣣ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(bawK2j7T81Nrc4GWs05xzDg(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),beV5l2D8HznyJI0(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"࠸࠶࠳ࣤ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(wwWzyF4ZpSQXKOgk569(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),CyHU86ZeYT5BWRcitSm2I(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠳࠳࠼࠵ࣥ"))
	return
def Lghe7dJAfVtO09BmHi53oSQ():
	RrIT1mFqHtgJa2,Y3GZTIN6HOu = Xxvo02YNyzKghHuGiBOD6splJQwj7f(brMfeRh67zQ2YDEvx3sJtOB0yUPXV)
	QwHBXfq9NjkU1SM72emKTYW,d5hO8WB9ipD03Z1CaFSwUVm4eXG = Xxvo02YNyzKghHuGiBOD6splJQwj7f(otGFedruwv5x8VablMHAOfDC4)
	OcJC9sp0NTwWD,WuixHRAjlh6DKJks = KIt6Jwe3Qyxp(CXv1WnOD6PEF0mhKcp7lQ)
	BYEONqrbQFngkImCsfz97JZpxcH5,rHGpuUK76WX5fM0TF = RrIT1mFqHtgJa2+QwHBXfq9NjkU1SM72emKTYW+OcJC9sp0NTwWD,Y3GZTIN6HOu+d5hO8WB9ipD03Z1CaFSwUVm4eXG+WuixHRAjlh6DKJks
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 = YYQS36fyPvtuzcEmRL(u"ࠩࠣࠬࠬࠚ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(RrIT1mFqHtgJa2)+mq5t9JXSdHT8yfDVF(u"ࠪࠤ࠲ࠦࠧࠛ")+str(Y3GZTIN6HOu)+yobpaW7sBqtKRrv(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = tzZ6PhyDOUnwLM3pdK(u"ࠬࠦࠨࠨࠝ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(QwHBXfq9NjkU1SM72emKTYW)+oiWNFYzcIUeh(u"࠭ࠠ࠮ࠢࠪࠞ")+str(d5hO8WB9ipD03Z1CaFSwUVm4eXG)+oiWNFYzcIUeh(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	arCiPYjFpSc3 = rVy3Ops0mohYkT(u"ࠨࠢࠫࠫࠠ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(OcJC9sp0NTwWD)+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(WuixHRAjlh6DKJks)+gPE1XB87fQl(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	UFAyS7c6KM50n8JPeCzQfEa = KLX7hW0nBAEgy6m4SvH(u"ࠫࠥ࠮ࠧࠣ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(BYEONqrbQFngkImCsfz97JZpxcH5)+KLX7hW0nBAEgy6m4SvH(u"ࠬࠦ࠭ࠡࠩࠤ")+str(rHGpuUK76WX5fM0TF)+IMjqygdfYSKpHlWu5Aa(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(yobpaW7sBqtKRrv(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠴࠴࠽࠺ࣦ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(IMjqygdfYSKpHlWu5Aa(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),e6HEdvUcaq8Gx+tzZ6PhyDOUnwLM3pdK(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"࠽࠾࠿࠹ࣧ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(yobpaW7sBqtKRrv(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+beV5l2D8HznyJI0(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+Dp04tKTInv8xOdlC63fUuMeSEFXw1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠶࠶࠸࠲ࣨ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(kdRO82AImh0LFw(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+ygGuahJtKfEDr1vVjNelbFZ4nB6oHI,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠷࠰࠹࠴ࣩ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),uBQ9txp0gDrEhZTcJOi74SKVw3k+GHg28TBchiyn6l(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+arCiPYjFpSc3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"࠱࠱࠺࠶࣪"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(YYQS36fyPvtuzcEmRL(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),uBQ9txp0gDrEhZTcJOi74SKVw3k+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,jhDZ0BAFoEGUcw5QrJkaxXL(u"࠲࠲࠻࠸࣫"))
	return
def wF0hASkpizU():
	AYNw6tITVipuHFjKqv3O = KiryBCvngZzF85UN6xSDlOVweL4I9
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,SI7eBdND4lx8pt5Qk(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if kkLdeyJUsSiK9YwFZr4lPbVE:
		wN5suD9md8kL3Wh0v2cyVnf = u19E0QvcbTXKa()
		RcASvDIweKC5rMgFxodn2O61uPBhq8 = r670fZQYnxlNOUoVBbMJa(kcCgDi2EzhU5s413pAjSmu,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
		AYNw6tITVipuHFjKqv3O = wN5suD9md8kL3Wh0v2cyVnf and RcASvDIweKC5rMgFxodn2O61uPBhq8
		if AYNw6tITVipuHFjKqv3O: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,VP70ytiFNMBl6vHDaW(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return AYNw6tITVipuHFjKqv3O
def P8IALOEd4DZUz2iqSRNTwm():
	import GkCs6wbiQP
	GkCs6wbiQP.pUon4NEmqs0JtSHAvCGrc()
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(kdRO82AImh0LFw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),VP70ytiFNMBl6vHDaW(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
		FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r670fZQYnxlNOUoVBbMJa(kcCgDi2EzhU5s413pAjSmu,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
		if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def u19E0QvcbTXKa():
	FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = KiryBCvngZzF85UN6xSDlOVweL4I9
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧิฦส่ࠬ࠻"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
		try:
			pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(MFlX6x0hzm)
			FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy = r0D4C3z7Onqpa
		except: pass
		if FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy
def Lghe7dJAfVtO09BmHi53oSQ():
	RrIT1mFqHtgJa2,Y3GZTIN6HOu = Xxvo02YNyzKghHuGiBOD6splJQwj7f(brMfeRh67zQ2YDEvx3sJtOB0yUPXV)
	QwHBXfq9NjkU1SM72emKTYW,d5hO8WB9ipD03Z1CaFSwUVm4eXG = Xxvo02YNyzKghHuGiBOD6splJQwj7f(otGFedruwv5x8VablMHAOfDC4)
	OcJC9sp0NTwWD,WuixHRAjlh6DKJks = KIt6Jwe3Qyxp(CXv1WnOD6PEF0mhKcp7lQ)
	BYEONqrbQFngkImCsfz97JZpxcH5,rHGpuUK76WX5fM0TF = RrIT1mFqHtgJa2+QwHBXfq9NjkU1SM72emKTYW+OcJC9sp0NTwWD,Y3GZTIN6HOu+d5hO8WB9ipD03Z1CaFSwUVm4eXG+WuixHRAjlh6DKJks
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 = A41nqbj3wYt(u"ࠫࠥ࠮ࠧ࠿")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(RrIT1mFqHtgJa2)+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࠦ࠭ࠡࠩࡀ")+str(Y3GZTIN6HOu)+mq5t9JXSdHT8yfDVF(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = pp7FcjEe6g(u"ࠧࠡࠪࠪࡂ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(QwHBXfq9NjkU1SM72emKTYW)+gPE1XB87fQl(u"ࠨࠢ࠰ࠤࠬࡃ")+str(d5hO8WB9ipD03Z1CaFSwUVm4eXG)+iySORMYxWXszEH18(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	arCiPYjFpSc3 = wwWzyF4ZpSQXKOgk569(u"ࠪࠤ࠭࠭ࡅ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(OcJC9sp0NTwWD)+IMjqygdfYSKpHlWu5Aa(u"ࠫࠥ࠳ࠠࠨࡆ")+str(WuixHRAjlh6DKJks)+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	UFAyS7c6KM50n8JPeCzQfEa = A41nqbj3wYt(u"࠭ࠠࠩࠩࡈ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(BYEONqrbQFngkImCsfz97JZpxcH5)+A41nqbj3wYt(u"ࠧࠡ࠯ࠣࠫࡉ")+str(rHGpuUK76WX5fM0TF)+GHg28TBchiyn6l(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠳࠼࠹࣬"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(yobpaW7sBqtKRrv(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),e6HEdvUcaq8Gx+gPE1XB87fQl(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"࠼࠽࠾࠿࣭"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+kdRO82AImh0LFw(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+Dp04tKTInv8xOdlC63fUuMeSEFXw1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"࠵࠵࠾࠱࣮"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(pp7FcjEe6g(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+wwWzyF4ZpSQXKOgk569(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+ygGuahJtKfEDr1vVjNelbFZ4nB6oHI,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠶࠶࠸࠳࣯"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(kdRO82AImh0LFw(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+CyHU86ZeYT5BWRcitSm2I(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+arCiPYjFpSc3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠷࠰࠹࠵ࣰ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(YYQS36fyPvtuzcEmRL(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠱࠱࠺࠷ࣱ"))
	return
def x7CbFHTyXKtUdmlWriEsGBz3n():
	RrIT1mFqHtgJa2,Y3GZTIN6HOu = Xxvo02YNyzKghHuGiBOD6splJQwj7f(yFhL93qivu2zxUKjp6CD)
	QwHBXfq9NjkU1SM72emKTYW,d5hO8WB9ipD03Z1CaFSwUVm4eXG = Xxvo02YNyzKghHuGiBOD6splJQwj7f(wLeokD3gz78VXTjvEsxfimay)
	OcJC9sp0NTwWD,WuixHRAjlh6DKJks = Xxvo02YNyzKghHuGiBOD6splJQwj7f(uudSqMfmscOgJFlUanLT5)
	BYEONqrbQFngkImCsfz97JZpxcH5,rHGpuUK76WX5fM0TF = KIt6Jwe3Qyxp(G0s8oq5pVu4ajzeEt7MbQ1CmOZIiJk)
	BYEONqrbQFngkImCsfz97JZpxcH5 -= QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠴࠸࠻࠺࠹ࣲ")
	rHGpuUK76WX5fM0TF -= wnaWTQM7VJPkZzO9eoSyFU4
	a3kGPwFH65BCEhS = str(pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(zZoDegnE91Nw))
	u2Bx6atfhRUIT8qDSw43dzQv0gpmP = a3kGPwFH65BCEhS.count(VP70ytiFNMBl6vHDaW(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+a3kGPwFH65BCEhS.count(tzZ6PhyDOUnwLM3pdK(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 = jhDZ0BAFoEGUcw5QrJkaxXL(u"࡙ࠩࠣࠬࠬ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(RrIT1mFqHtgJa2)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࠤ࠲࡚ࠦࠧ")+str(Y3GZTIN6HOu)+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬࠦࠨࠨ࡜")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(QwHBXfq9NjkU1SM72emKTYW)+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࠠ࠮ࠢࠪ࡝")+str(d5hO8WB9ipD03Z1CaFSwUVm4eXG)+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	arCiPYjFpSc3 = YYQS36fyPvtuzcEmRL(u"ࠨࠢࠫࠫ࡟")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(OcJC9sp0NTwWD)+ZLr5gRSkFewKdUos90bM(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(WuixHRAjlh6DKJks)+CyHU86ZeYT5BWRcitSm2I(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	UFAyS7c6KM50n8JPeCzQfEa = rVy3Ops0mohYkT(u"ࠫࠥ࠮ࠧࡢ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(BYEONqrbQFngkImCsfz97JZpxcH5)+A6iX18qgyOFlZxz7sc(u"ࠬ࠯ࠧࡣ")
	be4tPoTgv0351f2yDIiVGjx7YLC = wwWzyF4ZpSQXKOgk569(u"࠭ࠠࠩࠩࡤ")+str(u2Bx6atfhRUIT8qDSw43dzQv0gpmP)+Z9FPQvwlbjLTh(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	xxOkanprGDJTz6stRS9Zq = RrIT1mFqHtgJa2+QwHBXfq9NjkU1SM72emKTYW+OcJC9sp0NTwWD+BYEONqrbQFngkImCsfz97JZpxcH5
	Zuy9OVX3dhlM4LsBTrIFn5qA = Y3GZTIN6HOu+d5hO8WB9ipD03Z1CaFSwUVm4eXG+WuixHRAjlh6DKJks+rHGpuUK76WX5fM0TF+u2Bx6atfhRUIT8qDSw43dzQv0gpmP
	ZVk6IphECKLzUceP15j = QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࠢࠫࠫࡦ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(xxOkanprGDJTz6stRS9Zq)+mq5t9JXSdHT8yfDVF(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(Zuy9OVX3dhlM4LsBTrIFn5qA)+oiWNFYzcIUeh(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠹࠷࠹ࣳ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),e6HEdvUcaq8Gx+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠼࠽࠾࠿ࣴ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),uBQ9txp0gDrEhZTcJOi74SKVw3k+Z9FPQvwlbjLTh(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+Dp04tKTInv8xOdlC63fUuMeSEFXw1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"࠻࠹࠷ࣵ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(mq5t9JXSdHT8yfDVF(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),uBQ9txp0gDrEhZTcJOi74SKVw3k+wwWzyF4ZpSQXKOgk569(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+ygGuahJtKfEDr1vVjNelbFZ4nB6oHI,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠼࠺࠲ࣶ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+arCiPYjFpSc3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠽࠴࠴ࣷ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(A41nqbj3wYt(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+wwWzyF4ZpSQXKOgk569(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠵࠶ࣸ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+GHg28TBchiyn6l(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+be4tPoTgv0351f2yDIiVGjx7YLC,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠸࠶࠹ࣹ"))
	return
def OtfSqFzCivLgQreNbuU32HXsZ():
	B2QrIfaoW9DMEK3TGAh1P5vN = r0D4C3z7Onqpa if QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫ࠴࠭ࡷ") in sVeEnGfl8B else KiryBCvngZzF85UN6xSDlOVweL4I9
	if not B2QrIfaoW9DMEK3TGAh1P5vN:
		BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,gPE1XB87fQl(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	rLEuTzBs2HFXjeSyfvCZcQw4O = G3yDpvxOiSWdAeL.getSetting(jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not rLEuTzBs2HFXjeSyfvCZcQw4O: NgIlELWr0U1uPwntF7jVmfOX9Yxvc()
	RrIT1mFqHtgJa2,Y3GZTIN6HOu = Xxvo02YNyzKghHuGiBOD6splJQwj7f(TuU8lj6For)
	QwHBXfq9NjkU1SM72emKTYW,d5hO8WB9ipD03Z1CaFSwUVm4eXG = Xxvo02YNyzKghHuGiBOD6splJQwj7f(IN8yQCGZMhvzFWrBV9PYtf1RaD6k5)
	OcJC9sp0NTwWD,WuixHRAjlh6DKJks = Xxvo02YNyzKghHuGiBOD6splJQwj7f(JUrguKsh8lix3dtkya759fX0WAHSF)
	BYEONqrbQFngkImCsfz97JZpxcH5,rHGpuUK76WX5fM0TF = Xxvo02YNyzKghHuGiBOD6splJQwj7f(aukK2mVLBSNTv1RlF9b)
	h6Cav9qsZlB4xp3NQEziVKnF2kI,u2Bx6atfhRUIT8qDSw43dzQv0gpmP = Xxvo02YNyzKghHuGiBOD6splJQwj7f(lVJinQSoCfdLmv5KW4DrbFRG6sZA0)
	XXtPI26E3DgNK8,lQvWegGZ7fOb = Xxvo02YNyzKghHuGiBOD6splJQwj7f(Mo915Elfd8WcNyeC)
	Dp04tKTInv8xOdlC63fUuMeSEFXw1 = yobpaW7sBqtKRrv(u"ࠧࠡࠪࠪࡺ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(RrIT1mFqHtgJa2)+Z9FPQvwlbjLTh(u"ࠨࠢ࠰ࠤࠬࡻ")+str(Y3GZTIN6HOu)+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	ygGuahJtKfEDr1vVjNelbFZ4nB6oHI = ZLr5gRSkFewKdUos90bM(u"ࠪࠤ࠭࠭ࡽ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(QwHBXfq9NjkU1SM72emKTYW)+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࠥ࠳ࠠࠨࡾ")+str(d5hO8WB9ipD03Z1CaFSwUVm4eXG)+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	arCiPYjFpSc3 = SI7eBdND4lx8pt5Qk(u"࠭ࠠࠩࠩࢀ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(OcJC9sp0NTwWD)+CyHU86ZeYT5BWRcitSm2I(u"ࠧࠡ࠯ࠣࠫࢁ")+str(WuixHRAjlh6DKJks)+A6iX18qgyOFlZxz7sc(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	UFAyS7c6KM50n8JPeCzQfEa = oiWNFYzcIUeh(u"ࠩࠣࠬࠬࢃ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(BYEONqrbQFngkImCsfz97JZpxcH5)+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࠤ࠲ࠦࠧࢄ")+str(rHGpuUK76WX5fM0TF)+KLX7hW0nBAEgy6m4SvH(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	be4tPoTgv0351f2yDIiVGjx7YLC = YYQS36fyPvtuzcEmRL(u"ࠬࠦࠨࠨࢆ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(h6Cav9qsZlB4xp3NQEziVKnF2kI)+GHg28TBchiyn6l(u"࠭ࠠ࠮ࠢࠪࢇ")+str(u2Bx6atfhRUIT8qDSw43dzQv0gpmP)+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	Dy4AHTfzJ1I3sEcwdg2aQRYGu = YYQS36fyPvtuzcEmRL(u"ࠨࠢࠫࠫࢉ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(XXtPI26E3DgNK8)+CyHU86ZeYT5BWRcitSm2I(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(lQvWegGZ7fOb)+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	xxOkanprGDJTz6stRS9Zq = RrIT1mFqHtgJa2+QwHBXfq9NjkU1SM72emKTYW+OcJC9sp0NTwWD+BYEONqrbQFngkImCsfz97JZpxcH5+h6Cav9qsZlB4xp3NQEziVKnF2kI+XXtPI26E3DgNK8
	Zuy9OVX3dhlM4LsBTrIFn5qA = Y3GZTIN6HOu+d5hO8WB9ipD03Z1CaFSwUVm4eXG+WuixHRAjlh6DKJks+rHGpuUK76WX5fM0TF+u2Bx6atfhRUIT8qDSw43dzQv0gpmP+lQvWegGZ7fOb
	ZVk6IphECKLzUceP15j = IMjqygdfYSKpHlWu5Aa(u"ࠫࠥ࠮ࠧࢌ")+qeSPQImwydJU4HcOzL20x3aWgpnuK7(xxOkanprGDJTz6stRS9Zq)+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬࠦ࠭ࠡࠩࢍ")+str(Zuy9OVX3dhlM4LsBTrIFn5qA)+VP70ytiFNMBl6vHDaW(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),uBQ9txp0gDrEhZTcJOi74SKVw3k+A41nqbj3wYt(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠹࠸࠼ࣺ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(CyHU86ZeYT5BWRcitSm2I(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),uBQ9txp0gDrEhZTcJOi74SKVw3k+aiQwFE1TGx04vmLcsYkIW5jA(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠺࠹࠼ࣻ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),e6HEdvUcaq8Gx+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"࠽࠾࠿࠹ࣼ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(Z9FPQvwlbjLTh(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),uBQ9txp0gDrEhZTcJOi74SKVw3k+oiWNFYzcIUeh(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+Dp04tKTInv8xOdlC63fUuMeSEFXw1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠼࠻࠱ࣽ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+oiWNFYzcIUeh(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+ygGuahJtKfEDr1vVjNelbFZ4nB6oHI,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠽࠵࠳ࣾ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(IMjqygdfYSKpHlWu5Aa(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),uBQ9txp0gDrEhZTcJOi74SKVw3k+Z9FPQvwlbjLTh(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+arCiPYjFpSc3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"࠷࠶࠵ࣿ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(wwWzyF4ZpSQXKOgk569(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+VP70ytiFNMBl6vHDaW(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+UFAyS7c6KM50n8JPeCzQfEa,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠸࠷࠷ऀ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),uBQ9txp0gDrEhZTcJOi74SKVw3k+tzZ6PhyDOUnwLM3pdK(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+be4tPoTgv0351f2yDIiVGjx7YLC,WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"࠹࠸࠹ँ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),uBQ9txp0gDrEhZTcJOi74SKVw3k+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+Dy4AHTfzJ1I3sEcwdg2aQRYGu,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠺࠹࠻ं"))
	return
def eeCvhK0mSs2PTZxpG(showDialogs):
	if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,GHg28TBchiyn6l(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	Q8OJHAL6b4poKXqdk21,Pb4j7sWaQxiAY13nH5V = [],j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	for RXqfStFVAlw6NK5a,FVJeX8SKMzvbwA0Y9d,ddwJ2fMzVa3mtIrQbkoOp09yxD in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.walk(Hp7qgMcFCX46nO8Poy,topdown=KiryBCvngZzF85UN6xSDlOVweL4I9):
		yj2GKsbxPuv64fVl7hB0w1eqOTocN = len(ddwJ2fMzVa3mtIrQbkoOp09yxD)
		if yj2GKsbxPuv64fVl7hB0w1eqOTocN>bawK2j7T81Nrc4GWs05xzDg(u"࠹࠵࠶ः"): Q8OJHAL6b4poKXqdk21.append(FVJeX8SKMzvbwA0Y9d)
		Pb4j7sWaQxiAY13nH5V += yj2GKsbxPuv64fVl7hB0w1eqOTocN
	E7MZDflraXu = Pb4j7sWaQxiAY13nH5V>gPE1XB87fQl(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = e6HEdvUcaq8Gx+oiWNFYzcIUeh(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(Pb4j7sWaQxiAY13nH5V)+ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+YVr6St5P4xsFC0aARQGKfiegD
		if not Q8OJHAL6b4poKXqdk21 and not E7MZDflraXu: kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: kkLdeyJUsSiK9YwFZr4lPbVE = wnaWTQM7VJPkZzO9eoSyFU4
	if kkLdeyJUsSiK9YwFZr4lPbVE==wnaWTQM7VJPkZzO9eoSyFU4:
		if E7MZDflraXu: r670fZQYnxlNOUoVBbMJa(RXqfStFVAlw6NK5a,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
		elif Q8OJHAL6b4poKXqdk21:
			for FVJeX8SKMzvbwA0Y9d in Q8OJHAL6b4poKXqdk21: r670fZQYnxlNOUoVBbMJa(FVJeX8SKMzvbwA0Y9d,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def NgIlELWr0U1uPwntF7jVmfOX9Yxvc():
	AYNw6tITVipuHFjKqv3O = KiryBCvngZzF85UN6xSDlOVweL4I9
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,oiWNFYzcIUeh(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if kkLdeyJUsSiK9YwFZr4lPbVE==-ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠷अ"): return
	if kkLdeyJUsSiK9YwFZr4lPbVE:
		import subprocess as GMCNFTlP7XDbW90Qdu6Vm
		try:
			GMCNFTlP7XDbW90Qdu6Vm.Popen(A6iX18qgyOFlZxz7sc(u"ࠪࡷࡺ࠭ࢧ"))
			AYNw6tITVipuHFjKqv3O = r0D4C3z7Onqpa
		except: pass
		if AYNw6tITVipuHFjKqv3O:
			J4JEwXWh8H0rMoycVtGB = TuU8lj6For+kcXMWrwiLDKeBHRsJ+IN8yQCGZMhvzFWrBV9PYtf1RaD6k5+kcXMWrwiLDKeBHRsJ+JUrguKsh8lix3dtkya759fX0WAHSF+kcXMWrwiLDKeBHRsJ+aukK2mVLBSNTv1RlF9b+kcXMWrwiLDKeBHRsJ+lVJinQSoCfdLmv5KW4DrbFRG6sZA0+kcXMWrwiLDKeBHRsJ+Mo915Elfd8WcNyeC
			NqoLhvJHs5Iik4xtTl9XbWmB = GMCNFTlP7XDbW90Qdu6Vm.Popen(bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+J4JEwXWh8H0rMoycVtGB+oiWNFYzcIUeh(u"ࠬࠨࠧࢩ"),shell=r0D4C3z7Onqpa,stdin=GMCNFTlP7XDbW90Qdu6Vm.PIPE,stdout=GMCNFTlP7XDbW90Qdu6Vm.PIPE,stderr=GMCNFTlP7XDbW90Qdu6Vm.PIPE)
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return AYNw6tITVipuHFjKqv3O
def qeSPQImwydJU4HcOzL20x3aWgpnuK7(xxOkanprGDJTz6stRS9Zq):
	for OU8cbKwe1gXj5hsoW0LJYrAQf2 in [n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡄࠪࢬ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡎࡆࠬࢭ"),Z9FPQvwlbjLTh(u"ࠪࡑࡇ࠭ࢮ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡌࡈࠧࢯ"),GHg28TBchiyn6l(u"࡚ࠬࡂࠨࢰ")]:
		if xxOkanprGDJTz6stRS9Zq<A41nqbj3wYt(u"࠱࠱࠴࠷आ"): break
		else: xxOkanprGDJTz6stRS9Zq /= KLX7hW0nBAEgy6m4SvH(u"࠲࠲࠵࠸࠳࠶इ")
	ZVk6IphECKLzUceP15j = A41nqbj3wYt(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(xxOkanprGDJTz6stRS9Zq,OU8cbKwe1gXj5hsoW0LJYrAQf2)
	return ZVk6IphECKLzUceP15j
def Xxvo02YNyzKghHuGiBOD6splJQwj7f(EAq3zRKBJ7=mq5t9JXSdHT8yfDVF(u"ࠧ࠯ࠩࢲ")):
	global ZZB30d4av1cNfnFPhygjODexi,Xfk0HKx8Z5
	ZZB30d4av1cNfnFPhygjODexi,Xfk0HKx8Z5 = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	def jZXpDrnCFEGgU5kfmKx0J1wothuTLB(EAq3zRKBJ7):
		global ZZB30d4av1cNfnFPhygjODexi,Xfk0HKx8Z5
		if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(EAq3zRKBJ7):
			if j0jEZgiKdxFpMLHcU7kQr8v1lyX4 and oiWNFYzcIUeh(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(pNk4HfLdMBRYEQAzjyT0qaoe8cDPt):
				for wy0j7hSGWn2tvkXlCc in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.scandir(EAq3zRKBJ7):
					if wy0j7hSGWn2tvkXlCc.is_dir(follow_symlinks=KiryBCvngZzF85UN6xSDlOVweL4I9):
						jZXpDrnCFEGgU5kfmKx0J1wothuTLB(wy0j7hSGWn2tvkXlCc.path)
					elif wy0j7hSGWn2tvkXlCc.is_file(follow_symlinks=KiryBCvngZzF85UN6xSDlOVweL4I9):
						ZZB30d4av1cNfnFPhygjODexi += wy0j7hSGWn2tvkXlCc.stat().st_size
						Xfk0HKx8Z5 += wnaWTQM7VJPkZzO9eoSyFU4
			else:
				for wy0j7hSGWn2tvkXlCc in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(EAq3zRKBJ7):
					KK9ajP7dDEy3IZSOuAR0Xk = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.abspath(pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(EAq3zRKBJ7,wy0j7hSGWn2tvkXlCc))
					if pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.isdir(KK9ajP7dDEy3IZSOuAR0Xk):
						jZXpDrnCFEGgU5kfmKx0J1wothuTLB(KK9ajP7dDEy3IZSOuAR0Xk)
					elif pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.isfile(KK9ajP7dDEy3IZSOuAR0Xk):
						xxOkanprGDJTz6stRS9Zq,Zuy9OVX3dhlM4LsBTrIFn5qA = KIt6Jwe3Qyxp(KK9ajP7dDEy3IZSOuAR0Xk)
						ZZB30d4av1cNfnFPhygjODexi += xxOkanprGDJTz6stRS9Zq
						Xfk0HKx8Z5 += Zuy9OVX3dhlM4LsBTrIFn5qA
		return
	try: jZXpDrnCFEGgU5kfmKx0J1wothuTLB(EAq3zRKBJ7)
	except: pass
	return ZZB30d4av1cNfnFPhygjODexi,Xfk0HKx8Z5
def azdGBC51hPg8J6wR3H(showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,e6HEdvUcaq8Gx+yobpaW7sBqtKRrv(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+gPE1XB87fQl(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+gPE1XB87fQl(u"ࠫฤࠧࠡࠨࢶ")+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return
	A5Cbm84x0yqVfLrXwSBHnzl1FeUkE = r670fZQYnxlNOUoVBbMJa(yFhL93qivu2zxUKjp6CD,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
	MbyOBwkU3GdWiP4vIEj9XV = r670fZQYnxlNOUoVBbMJa(wLeokD3gz78VXTjvEsxfimay,r0D4C3z7Onqpa,KiryBCvngZzF85UN6xSDlOVweL4I9)
	kTm0WeSlLh9jK3 = r670fZQYnxlNOUoVBbMJa(uudSqMfmscOgJFlUanLT5,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	S93fwP4XitUFjDNsxaVvbT = dXNLv3gHJ4bFE8TqQ5nGYlVO(KiryBCvngZzF85UN6xSDlOVweL4I9)
	Lb7zauwyDmxUovR5slT = pZB6wQNYUrEIMR5zmL9k(KiryBCvngZzF85UN6xSDlOVweL4I9)
	succeeded = all([A5Cbm84x0yqVfLrXwSBHnzl1FeUkE,MbyOBwkU3GdWiP4vIEj9XV,kTm0WeSlLh9jK3,S93fwP4XitUFjDNsxaVvbT,Lb7zauwyDmxUovR5slT])
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,mq5t9JXSdHT8yfDVF(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,rVy3Ops0mohYkT(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def PWv3xqoF6pStz049(showDialogs):
	if showDialogs:
		J4JEwXWh8H0rMoycVtGB = TuU8lj6For+WBDnh75CaLEvkcN6p4ez2KXrV3M+IN8yQCGZMhvzFWrBV9PYtf1RaD6k5+WBDnh75CaLEvkcN6p4ez2KXrV3M+JUrguKsh8lix3dtkya759fX0WAHSF+WBDnh75CaLEvkcN6p4ez2KXrV3M+aukK2mVLBSNTv1RlF9b+WBDnh75CaLEvkcN6p4ez2KXrV3M+lVJinQSoCfdLmv5KW4DrbFRG6sZA0+WBDnh75CaLEvkcN6p4ez2KXrV3M+Mo915Elfd8WcNyeC
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,e6HEdvUcaq8Gx+aiQwFE1TGx04vmLcsYkIW5jA(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+J4JEwXWh8H0rMoycVtGB+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return
	A5Cbm84x0yqVfLrXwSBHnzl1FeUkE = r670fZQYnxlNOUoVBbMJa(TuU8lj6For,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	MbyOBwkU3GdWiP4vIEj9XV = r670fZQYnxlNOUoVBbMJa(IN8yQCGZMhvzFWrBV9PYtf1RaD6k5,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	kTm0WeSlLh9jK3 = r670fZQYnxlNOUoVBbMJa(JUrguKsh8lix3dtkya759fX0WAHSF,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	S93fwP4XitUFjDNsxaVvbT = r670fZQYnxlNOUoVBbMJa(aukK2mVLBSNTv1RlF9b,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	Lb7zauwyDmxUovR5slT = r670fZQYnxlNOUoVBbMJa(lVJinQSoCfdLmv5KW4DrbFRG6sZA0,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	hvnDHPqawXJSr70bsIotdUMzT6m2 = r670fZQYnxlNOUoVBbMJa(Mo915Elfd8WcNyeC,KiryBCvngZzF85UN6xSDlOVweL4I9,KiryBCvngZzF85UN6xSDlOVweL4I9)
	succeeded = all([A5Cbm84x0yqVfLrXwSBHnzl1FeUkE,MbyOBwkU3GdWiP4vIEj9XV,kTm0WeSlLh9jK3,S93fwP4XitUFjDNsxaVvbT,Lb7zauwyDmxUovR5slT,hvnDHPqawXJSr70bsIotdUMzT6m2])
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,wwWzyF4ZpSQXKOgk569(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def dXNLv3gHJ4bFE8TqQ5nGYlVO(showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,e6HEdvUcaq8Gx+beV5l2D8HznyJI0(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=SI7eBdND4lx8pt5Qk(u"࠳ई"): return XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࡘࡷࡻࡥऊ")
		OoE5HYUMwsrDWhx2gR7I3FuN = x0p6hU1tkV4oBXnm2SDsNPlY7.connect(G0s8oq5pVu4ajzeEt7MbQ1CmOZIiJk)
		OoE5HYUMwsrDWhx2gR7I3FuN.text_factory = str
		GSB3DNKz9vFbaEo8 = OoE5HYUMwsrDWhx2gR7I3FuN.cursor()
		GSB3DNKz9vFbaEo8.execute(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		GSB3DNKz9vFbaEo8.execute(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		GSB3DNKz9vFbaEo8.execute(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		OoE5HYUMwsrDWhx2gR7I3FuN.commit()
		GSB3DNKz9vFbaEo8.execute(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		OoE5HYUMwsrDWhx2gR7I3FuN.close()
	except: succeeded = A6iX18qgyOFlZxz7sc(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,bawK2j7T81Nrc4GWs05xzDg(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,beV5l2D8HznyJI0(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def pZB6wQNYUrEIMR5zmL9k(showDialogs):
	if showDialogs:
		kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,yobpaW7sBqtKRrv(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+WBDnh75CaLEvkcN6p4ez2KXrV3M+WBDnh75CaLEvkcN6p4ez2KXrV3M+e6HEdvUcaq8Gx+bawK2j7T81Nrc4GWs05xzDg(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+YVr6St5P4xsFC0aARQGKfiegD)
		if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return pp7FcjEe6g(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࡔࡳࡷࡨऍ")
	for file in pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(zZoDegnE91Nw):
		if A41nqbj3wYt(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(zZoDegnE91Nw,file)
		try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.remove(CEOcD4QZRsLPgeG5YoHjfA7nm9uzqd)
		except Exception as YIrltJES6aPjnm94qTuoMiORKpDA0:
			succeeded = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,str(YIrltJES6aPjnm94qTuoMiORKpDA0))
	if showDialogs:
		if succeeded: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,GHg28TBchiyn6l(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,IMjqygdfYSKpHlWu5Aa(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded