# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'LIVETV'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS['PYTHON'][0]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url):
	if   mode==100: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==101: APpdhB1Fk58MmJH7CjVntowyaY = f28uNr4CYyMqT('0',True)
	elif mode==102: APpdhB1Fk58MmJH7CjVntowyaY = f28uNr4CYyMqT('1',True)
	elif mode==103: APpdhB1Fk58MmJH7CjVntowyaY = f28uNr4CYyMqT('2',True)
	elif mode==104: APpdhB1Fk58MmJH7CjVntowyaY = f28uNr4CYyMqT('3',True)
	elif mode==105: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==106: APpdhB1Fk58MmJH7CjVntowyaY = f28uNr4CYyMqT('4',True)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_M3U_'+'قوائم فيديوهات M3U',WnNGfosHr5STAq8j7miwyRZ6eOUbV,762)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_IPT_'+'قوائم فيديوهات IPTV',WnNGfosHr5STAq8j7miwyRZ6eOUbV,761)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TV0_'+'قنوات من مواقعها الأصلية',WnNGfosHr5STAq8j7miwyRZ6eOUbV,101)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TV4_'+'قنوات مختارة من يوتيوب',WnNGfosHr5STAq8j7miwyRZ6eOUbV,106)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_YUT_'+'قنوات عربية من يوتيوب',WnNGfosHr5STAq8j7miwyRZ6eOUbV,147)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_YUT_'+'قنوات أجنبية من يوتيوب',WnNGfosHr5STAq8j7miwyRZ6eOUbV,148)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',WnNGfosHr5STAq8j7miwyRZ6eOUbV,28)
	octplHnGwmE8bFqNdj7BiKvJ0VL('live','_MRF_'+'قناة المعارف من موقعهم',WnNGfosHr5STAq8j7miwyRZ6eOUbV,41)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TV1_'+'قنوات تلفزيونية عامة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,102)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TV2_'+'قنوات تلفزيونية خاصة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,103)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder','_TV3_'+'قنوات تلفزيونية للفحص',WnNGfosHr5STAq8j7miwyRZ6eOUbV,104)
	return
def f28uNr4CYyMqT(xolUtmyJWcC0eR7,showDialogs=True):
	uBQ9txp0gDrEhZTcJOi74SKVw3k = '_TV'+xolUtmyJWcC0eR7+'_'
	rLqYZOtwMfBVs4k1TpE3X9aDy = {'id':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'user':A3pXVFdyP1.AV_CLIENT_IDS,'function':'list','menu':xolUtmyJWcC0eR7}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',pcE6DxaoHBm41WKXjwnk,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-ITEMS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		for JrM1DoSuQ5n8 in range(len(items)):
			name = items[JrM1DoSuQ5n8][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[JrM1DoSuQ5n8] = items[JrM1DoSuQ5n8][0],items[JrM1DoSuQ5n8][1],items[JrM1DoSuQ5n8][2],name,items[JrM1DoSuQ5n8][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for ADN3XhW9ZpVmFK84j2roiy,VVpQfHc7IZamxweON3WXKU6Fg,MXZvtCRTuhcs6VN1K0LOwWDF,name,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			if '#' in ADN3XhW9ZpVmFK84j2roiy: continue
			if ADN3XhW9ZpVmFK84j2roiy!='URL': name = name+e6HEdvUcaq8Gx+jrD65cZUQ8uGR0IHNCkF+ADN3XhW9ZpVmFK84j2roiy+YVr6St5P4xsFC0aARQGKfiegD
			url = ADN3XhW9ZpVmFK84j2roiy+';;'+VVpQfHc7IZamxweON3WXKU6Fg+';;'+MXZvtCRTuhcs6VN1K0LOwWDF+';;'+xolUtmyJWcC0eR7
			octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+WnNGfosHr5STAq8j7miwyRZ6eOUbV+name,url,105,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		if showDialogs: octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+'هذه الخدمة مخصصة للمبرمج فقط',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(id):
	ADN3XhW9ZpVmFK84j2roiy,VVpQfHc7IZamxweON3WXKU6Fg,MXZvtCRTuhcs6VN1K0LOwWDF,xolUtmyJWcC0eR7 = id.split(';;')
	url = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if ADN3XhW9ZpVmFK84j2roiy=='URL': url = MXZvtCRTuhcs6VN1K0LOwWDF
	elif ADN3XhW9ZpVmFK84j2roiy=='YOUTUBE':
		url = A3pXVFdyP1.SITESURLS['YOUTUBE'][0]+'/watch?v='+MXZvtCRTuhcs6VN1K0LOwWDF
		import ltcz1qSYiV
		ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L([url],NTWE764hmOgUtScp2e8r,'live',url)
		return
	elif ADN3XhW9ZpVmFK84j2roiy=='GA':
		rLqYZOtwMfBVs4k1TpE3X9aDy = { 'id' : WnNGfosHr5STAq8j7miwyRZ6eOUbV, 'user' : A3pXVFdyP1.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',pcE6DxaoHBm41WKXjwnk,rLqYZOtwMfBVs4k1TpE3X9aDy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-1st')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		cookies = WadGEeh1MBIXkpfP38qAv7ryslY.cookies
		QBw1AmI80W5GSuyKe = cookies['ASP.NET_SessionId']
		url = WadGEeh1MBIXkpfP38qAv7ryslY.headers['Location']
		rLqYZOtwMfBVs4k1TpE3X9aDy = { 'id' : MXZvtCRTuhcs6VN1K0LOwWDF , 'user' : A3pXVFdyP1.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+QBw1AmI80W5GSuyKe }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',pcE6DxaoHBm41WKXjwnk,rLqYZOtwMfBVs4k1TpE3X9aDy,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-2nd')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		url = p7dwlH1PRStBgyMUW.findall('resp":"(http.*?m3u8)(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		SOw5EUxC9k = url[0][0]
		Vgy0Y3N6X8DOIxczQAl = url[0][1]
		kUwsIGa7Hl1murzpjxtqcM0Ty3C = 'http://38.'+VVpQfHc7IZamxweON3WXKU6Fg+'777/'+MXZvtCRTuhcs6VN1K0LOwWDF+'_HD.m3u8'+Vgy0Y3N6X8DOIxczQAl
		ZXgbJokBpIq0sOcm6Y = kUwsIGa7Hl1murzpjxtqcM0Ty3C.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		HoJlGVDuEUresB2dv5A = kUwsIGa7Hl1murzpjxtqcM0Ty3C.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		ZD0qItXg31HmC7KGEFn = ['HD','SD1','SD2']
		M0MFkiKqJDv1aZ4NA396u = [kUwsIGa7Hl1murzpjxtqcM0Ty3C,ZXgbJokBpIq0sOcm6Y,HoJlGVDuEUresB2dv5A]
		XFaM94cPUCOWQZNIEe8gdJpny1 = 0
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1: return
		else: url = M0MFkiKqJDv1aZ4NA396u[XFaM94cPUCOWQZNIEe8gdJpny1]
	elif ADN3XhW9ZpVmFK84j2roiy=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		rLqYZOtwMfBVs4k1TpE3X9aDy = { 'id' : MXZvtCRTuhcs6VN1K0LOwWDF , 'user' : A3pXVFdyP1.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : xolUtmyJWcC0eR7 }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST', pcE6DxaoHBm41WKXjwnk, rLqYZOtwMfBVs4k1TpE3X9aDy, headers, False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-3rd')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		url = WadGEeh1MBIXkpfP38qAv7ryslY.headers['Location']
		url = url.replace('%20',kcXMWrwiLDKeBHRsJ)
		url = url.replace('%3D','=')
		if 'Learn' in MXZvtCRTuhcs6VN1K0LOwWDF:
			url = url.replace('NTNNile',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			url = url.replace('learning1','Learning')
	elif ADN3XhW9ZpVmFK84j2roiy=='PL':
		rLqYZOtwMfBVs4k1TpE3X9aDy = { 'id' : MXZvtCRTuhcs6VN1K0LOwWDF , 'user' : A3pXVFdyP1.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : xolUtmyJWcC0eR7 }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST', pcE6DxaoHBm41WKXjwnk, rLqYZOtwMfBVs4k1TpE3X9aDy, WnNGfosHr5STAq8j7miwyRZ6eOUbV,False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-4th')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		url = WadGEeh1MBIXkpfP38qAv7ryslY.headers['Location']
		headers = {'Referer':WadGEeh1MBIXkpfP38qAv7ryslY.headers['Referer']}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'POST',url, WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers , WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-5th')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		items = p7dwlH1PRStBgyMUW.findall('source src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		url = items[0]
	elif ADN3XhW9ZpVmFK84j2roiy in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if ADN3XhW9ZpVmFK84j2roiy=='TA': MXZvtCRTuhcs6VN1K0LOwWDF = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		rLqYZOtwMfBVs4k1TpE3X9aDy = { 'id' : MXZvtCRTuhcs6VN1K0LOwWDF , 'user' : A3pXVFdyP1.AV_CLIENT_IDS , 'function' : 'play'+ADN3XhW9ZpVmFK84j2roiy , 'menu' : xolUtmyJWcC0eR7 }
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',pcE6DxaoHBm41WKXjwnk,rLqYZOtwMfBVs4k1TpE3X9aDy,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-6th')
		if not WadGEeh1MBIXkpfP38qAv7ryslY.succeeded:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		url = WadGEeh1MBIXkpfP38qAv7ryslY.headers['Location']
		if ADN3XhW9ZpVmFK84j2roiy=='FM':
			WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET', url, WnNGfosHr5STAq8j7miwyRZ6eOUbV, WnNGfosHr5STAq8j7miwyRZ6eOUbV, False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIVETV-PLAY-7th')
			url = WadGEeh1MBIXkpfP38qAv7ryslY.headers['Location']
			url = url.replace('https','http')
	YsRk6pAS7rdcn(url,NTWE764hmOgUtScp2e8r,'live')
	return