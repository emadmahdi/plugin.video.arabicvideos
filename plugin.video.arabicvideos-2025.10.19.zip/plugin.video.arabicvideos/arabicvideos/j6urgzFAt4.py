# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
TTOAERW9IMB045fQt7wnjrymKZGHN = 'EXCLUDES'
def kTb69AueJDo3EH1ti0sVBOaz2XQf8F(fzu7Got0FgiyshTlJK,AEXO2m8Yq6npHlfyzhGJ):
	AEXO2m8Yq6npHlfyzhGJ = AEXO2m8Yq6npHlfyzhGJ.replace(e6HEdvUcaq8Gx,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(' '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)[wnaWTQM7VJPkZzO9eoSyFU4:]
	KKXobO3J1aG7jVxNC0 = p7dwlH1PRStBgyMUW.findall('[a-zA-Z]',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
	if 'بحث IPTV - ' in fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace('بحث IPTV - ',jedSoT7D2Qu+'بحث IPTV - '+jedSoT7D2Qu)
	elif ' IPTV' in fzu7Got0FgiyshTlJK and AEXO2m8Yq6npHlfyzhGJ=='IPT': fzu7Got0FgiyshTlJK = jedSoT7D2Qu+fzu7Got0FgiyshTlJK
	elif 'بحث M3U - ' in fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace('بحث M3U - ',jedSoT7D2Qu+'بحث M3U - '+jedSoT7D2Qu)
	elif ' M3U' in fzu7Got0FgiyshTlJK and AEXO2m8Yq6npHlfyzhGJ=='M3U': fzu7Got0FgiyshTlJK = jedSoT7D2Qu+fzu7Got0FgiyshTlJK
	elif 'بحث ' in fzu7Got0FgiyshTlJK and ' - ' in fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = jedSoT7D2Qu+fzu7Got0FgiyshTlJK
	elif not KKXobO3J1aG7jVxNC0:
		Qa3jpWBZOli0o2Ph8yYXEFgV9nkz = p7dwlH1PRStBgyMUW.findall('^( *?)(.*?)( *?)$',fzu7Got0FgiyshTlJK)
		LWd96r84TAKsj1bVIDZGfq7ezcu,e2xa8tMVIQjKXn4d1uS9lphwsO,t5wLe8mpJCrPD31ZK6W9RoSuYfHTz = Qa3jpWBZOli0o2Ph8yYXEFgV9nkz[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		wzdSg4YMP87HIVk9GFnCTZoK = p7dwlH1PRStBgyMUW.findall('^([!-~])',e2xa8tMVIQjKXn4d1uS9lphwsO)
		if wzdSg4YMP87HIVk9GFnCTZoK: fzu7Got0FgiyshTlJK = LWd96r84TAKsj1bVIDZGfq7ezcu+w1gu8bCmYAvdjf5a+e2xa8tMVIQjKXn4d1uS9lphwsO+t5wLe8mpJCrPD31ZK6W9RoSuYfHTz
		else: fzu7Got0FgiyshTlJK = t5wLe8mpJCrPD31ZK6W9RoSuYfHTz+jedSoT7D2Qu+e2xa8tMVIQjKXn4d1uS9lphwsO+LWd96r84TAKsj1bVIDZGfq7ezcu
	else:
		import bidi.algorithm as IaP1Ryqv2Z3x
		if wnaWTQM7VJPkZzO9eoSyFU4:
			LLtM96ihg4FB2 = fzu7Got0FgiyshTlJK
			if YVzokG2yZqrh3w8bU: LLtM96ihg4FB2 = LLtM96ihg4FB2.decode(e87cIA5vwOQLDEP1,'ignore')
			tj0TRWQK3swJ9x1zhlALEIimpP6y = IaP1Ryqv2Z3x.get_display(LLtM96ihg4FB2,base_dir='L')
			rr4NSDKQc6wMIgoJRj2 = LLtM96ihg4FB2.split(kcXMWrwiLDKeBHRsJ)
			zvRJ8oxk6NmeTfjZ3MXbD = tj0TRWQK3swJ9x1zhlALEIimpP6y.split(kcXMWrwiLDKeBHRsJ)
			ZT5Jvnr2hBiNjG3kbHE,ScDvkoK5gdlOj3UZ,QKF8fc0ml7G65,TW7HeJpn80EqMsL31i9C = [],[],WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
			ssy4zGQhiP96NfH = zip(rr4NSDKQc6wMIgoJRj2,zvRJ8oxk6NmeTfjZ3MXbD)
			for RDvhu6cOGt4yx2gXWrjZHeSLnK9p,r69rltDcRwULzVyF21ivO7EJueAnxH in ssy4zGQhiP96NfH:
				if RDvhu6cOGt4yx2gXWrjZHeSLnK9p==r69rltDcRwULzVyF21ivO7EJueAnxH==WnNGfosHr5STAq8j7miwyRZ6eOUbV and TW7HeJpn80EqMsL31i9C:
					QKF8fc0ml7G65 += kcXMWrwiLDKeBHRsJ
					continue
				if RDvhu6cOGt4yx2gXWrjZHeSLnK9p==r69rltDcRwULzVyF21ivO7EJueAnxH:
					rgYeBcO8n9ztk3GAMjZ4HQCWRsu = 'EN'
					if TW7HeJpn80EqMsL31i9C==rgYeBcO8n9ztk3GAMjZ4HQCWRsu: QKF8fc0ml7G65 += kcXMWrwiLDKeBHRsJ+RDvhu6cOGt4yx2gXWrjZHeSLnK9p
					elif RDvhu6cOGt4yx2gXWrjZHeSLnK9p:
						if QKF8fc0ml7G65:
							ScDvkoK5gdlOj3UZ.append(QKF8fc0ml7G65)
							ZT5Jvnr2hBiNjG3kbHE.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						QKF8fc0ml7G65 = RDvhu6cOGt4yx2gXWrjZHeSLnK9p
				else:
					rgYeBcO8n9ztk3GAMjZ4HQCWRsu = 'AR'
					if TW7HeJpn80EqMsL31i9C==rgYeBcO8n9ztk3GAMjZ4HQCWRsu: QKF8fc0ml7G65 += kcXMWrwiLDKeBHRsJ+RDvhu6cOGt4yx2gXWrjZHeSLnK9p
					elif RDvhu6cOGt4yx2gXWrjZHeSLnK9p:
						if QKF8fc0ml7G65:
							ZT5Jvnr2hBiNjG3kbHE.append(QKF8fc0ml7G65)
							ScDvkoK5gdlOj3UZ.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						QKF8fc0ml7G65 = RDvhu6cOGt4yx2gXWrjZHeSLnK9p
				TW7HeJpn80EqMsL31i9C = rgYeBcO8n9ztk3GAMjZ4HQCWRsu
			if rgYeBcO8n9ztk3GAMjZ4HQCWRsu=='EN':
				ZT5Jvnr2hBiNjG3kbHE.append(QKF8fc0ml7G65)
				ScDvkoK5gdlOj3UZ.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			else:
				ScDvkoK5gdlOj3UZ.append(QKF8fc0ml7G65)
				ZT5Jvnr2hBiNjG3kbHE.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			Oao3jhHTWsE4lbAz8d = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			ssy4zGQhiP96NfH = zip(ZT5Jvnr2hBiNjG3kbHE,ScDvkoK5gdlOj3UZ)
			import bidi.mirror as hblxEzDktp
			for fLQ2cmCMk3wxTEKg,ZIJx6prbzuSsdEMRcwl2n in ssy4zGQhiP96NfH:
				if fLQ2cmCMk3wxTEKg: Oao3jhHTWsE4lbAz8d += kcXMWrwiLDKeBHRsJ+fLQ2cmCMk3wxTEKg
				else:
					wzdSg4YMP87HIVk9GFnCTZoK = p7dwlH1PRStBgyMUW.findall('([!-~]) *$',ZIJx6prbzuSsdEMRcwl2n)
					if wzdSg4YMP87HIVk9GFnCTZoK:
						wzdSg4YMP87HIVk9GFnCTZoK = wzdSg4YMP87HIVk9GFnCTZoK[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
						try:
							iw82nKmeEhZSXdY6MA = hblxEzDktp.MIRRORED[wzdSg4YMP87HIVk9GFnCTZoK]
							Qa3jpWBZOli0o2Ph8yYXEFgV9nkz = p7dwlH1PRStBgyMUW.findall('^( *?)(.*?)( *?)$',ZIJx6prbzuSsdEMRcwl2n)
							if Qa3jpWBZOli0o2Ph8yYXEFgV9nkz: LWd96r84TAKsj1bVIDZGfq7ezcu,ZIJx6prbzuSsdEMRcwl2n,t5wLe8mpJCrPD31ZK6W9RoSuYfHTz = Qa3jpWBZOli0o2Ph8yYXEFgV9nkz[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
							ZIJx6prbzuSsdEMRcwl2n = LWd96r84TAKsj1bVIDZGfq7ezcu+iw82nKmeEhZSXdY6MA+ZIJx6prbzuSsdEMRcwl2n[:-wnaWTQM7VJPkZzO9eoSyFU4]+t5wLe8mpJCrPD31ZK6W9RoSuYfHTz
						except: pass
					Oao3jhHTWsE4lbAz8d += kcXMWrwiLDKeBHRsJ+ZIJx6prbzuSsdEMRcwl2n
			fzu7Got0FgiyshTlJK = Oao3jhHTWsE4lbAz8d[wnaWTQM7VJPkZzO9eoSyFU4:]
			if YVzokG2yZqrh3w8bU: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.encode(e87cIA5vwOQLDEP1)
		else:
			if YVzokG2yZqrh3w8bU: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.decode(e87cIA5vwOQLDEP1)
			fzu7Got0FgiyshTlJK = IaP1Ryqv2Z3x.get_display(fzu7Got0FgiyshTlJK)
			LLtM96ihg4FB2,tj0TRWQK3swJ9x1zhlALEIimpP6y = fzu7Got0FgiyshTlJK,fzu7Got0FgiyshTlJK
			if 1:
				TW7HeJpn80EqMsL31i9C,RRg7VscCWzMUvS6mwpFIaNnut = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
				fdILwxo3bv148lyHeUPODaNSgcYZ60 = fzu7Got0FgiyshTlJK.split(kcXMWrwiLDKeBHRsJ)
				for WNKF29qEvc5GHJ4YlR7dphM3ikBb8 in fdILwxo3bv148lyHeUPODaNSgcYZ60:
					if not WNKF29qEvc5GHJ4YlR7dphM3ikBb8:
						if RRg7VscCWzMUvS6mwpFIaNnut: RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4] += kcXMWrwiLDKeBHRsJ
						else: RRg7VscCWzMUvS6mwpFIaNnut.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
						continue
					iTt1ZdaEujgkP3NG2 = p7dwlH1PRStBgyMUW.findall('[!-~]',WNKF29qEvc5GHJ4YlR7dphM3ikBb8[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
					if iTt1ZdaEujgkP3NG2==TW7HeJpn80EqMsL31i9C and RRg7VscCWzMUvS6mwpFIaNnut: RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4] += kcXMWrwiLDKeBHRsJ+WNKF29qEvc5GHJ4YlR7dphM3ikBb8
					else:
						if RRg7VscCWzMUvS6mwpFIaNnut:
							caQiA1HgvTK = p7dwlH1PRStBgyMUW.findall('[^!-~]',RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4])
							if caQiA1HgvTK:
								RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4] = IaP1Ryqv2Z3x.get_display(RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4])
								rlAiJeyRvx7N1 = p7dwlH1PRStBgyMUW.findall('^ +',RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4])
								if rlAiJeyRvx7N1: RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4] = RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4].lstrip(kcXMWrwiLDKeBHRsJ)+rlAiJeyRvx7N1[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
						RRg7VscCWzMUvS6mwpFIaNnut.append(WNKF29qEvc5GHJ4YlR7dphM3ikBb8)
					TW7HeJpn80EqMsL31i9C = iTt1ZdaEujgkP3NG2
				if RRg7VscCWzMUvS6mwpFIaNnut: RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4] = IaP1Ryqv2Z3x.get_display(RRg7VscCWzMUvS6mwpFIaNnut[-wnaWTQM7VJPkZzO9eoSyFU4])
				fzu7Got0FgiyshTlJK = kcXMWrwiLDKeBHRsJ.join(RRg7VscCWzMUvS6mwpFIaNnut)
			if YVzokG2yZqrh3w8bU: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.encode(e87cIA5vwOQLDEP1)
	return fzu7Got0FgiyshTlJK
def KUC8lG5Yd0uRgj(Z2CEnfA3yd,l7nrJawpUzoNc,iqCc2wu3NdJHX7Foxf4nBUyzlSraOP):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,R8aw0V1gIy4CGseEif,RRwhvHtPELBW7dOUAl8qejQFg,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = Z2CEnfA3yd
	HOkAWvmZSP5c2t9Dq4NgELyps = int(HOkAWvmZSP5c2t9Dq4NgELyps)
	w3H0dv1QpIAJUGEoCf = p7dwlH1PRStBgyMUW.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
	if w3H0dv1QpIAJUGEoCf:
		w3H0dv1QpIAJUGEoCf,VV5AI7SuWcQhdzrBjxgMDvw1,GAx85m3OpTyJsH47jrbacf = w3H0dv1QpIAJUGEoCf[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(w3H0dv1QpIAJUGEoCf,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	mxIgVCZFWHv = fzu7Got0FgiyshTlJK
	AEXO2m8Yq6npHlfyzhGJ = p7dwlH1PRStBgyMUW.findall('^_(\w\w\w)_(.*?)$',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
	if AEXO2m8Yq6npHlfyzhGJ:
		AEXO2m8Yq6npHlfyzhGJ,fzu7Got0FgiyshTlJK = AEXO2m8Yq6npHlfyzhGJ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		owJUmfMzyRcKtCZxkuYVLejDnbQ = '_MOD_' in fzu7Got0FgiyshTlJK
		NLMU9xZPkX4t168usGzqSBfQCAJHg = t0xkM74rgEAFIepSWXilNOGDn=='folder'
		if owJUmfMzyRcKtCZxkuYVLejDnbQ and NLMU9xZPkX4t168usGzqSBfQCAJHg: MpimvHudO63f1CTcSL5 = ';'
		elif owJUmfMzyRcKtCZxkuYVLejDnbQ and not NLMU9xZPkX4t168usGzqSBfQCAJHg: MpimvHudO63f1CTcSL5 = BeAmoNljUgrbc
		elif not owJUmfMzyRcKtCZxkuYVLejDnbQ and NLMU9xZPkX4t168usGzqSBfQCAJHg: MpimvHudO63f1CTcSL5 = ','
		elif not owJUmfMzyRcKtCZxkuYVLejDnbQ and not NLMU9xZPkX4t168usGzqSBfQCAJHg: MpimvHudO63f1CTcSL5 = kcXMWrwiLDKeBHRsJ
		fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace('_MOD_',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		AEXO2m8Yq6npHlfyzhGJ = MpimvHudO63f1CTcSL5+e6HEdvUcaq8Gx+AEXO2m8Yq6npHlfyzhGJ+' '+YVr6St5P4xsFC0aARQGKfiegD
	else: AEXO2m8Yq6npHlfyzhGJ = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if w3H0dv1QpIAJUGEoCf:
		if YVzokG2yZqrh3w8bU:
			w3H0dv1QpIAJUGEoCf = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+VV5AI7SuWcQhdzrBjxgMDvw1+kcXMWrwiLDKeBHRsJ+GAx85m3OpTyJsH47jrbacf+YVr6St5P4xsFC0aARQGKfiegD
			if AEXO2m8Yq6npHlfyzhGJ: fzu7Got0FgiyshTlJK = w3H0dv1QpIAJUGEoCf+kcXMWrwiLDKeBHRsJ+jedSoT7D2Qu+AEXO2m8Yq6npHlfyzhGJ+fzu7Got0FgiyshTlJK
			else: fzu7Got0FgiyshTlJK = w3H0dv1QpIAJUGEoCf+jedSoT7D2Qu+fzu7Got0FgiyshTlJK+kcXMWrwiLDKeBHRsJ
		elif rJ2oTLqabRtA:
			if AEXO2m8Yq6npHlfyzhGJ:
				w3H0dv1QpIAJUGEoCf = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+VV5AI7SuWcQhdzrBjxgMDvw1+kcXMWrwiLDKeBHRsJ+GAx85m3OpTyJsH47jrbacf+YVr6St5P4xsFC0aARQGKfiegD
				fzu7Got0FgiyshTlJK = w3H0dv1QpIAJUGEoCf+kcXMWrwiLDKeBHRsJ+AEXO2m8Yq6npHlfyzhGJ+fzu7Got0FgiyshTlJK
			else:
				w3H0dv1QpIAJUGEoCf = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+GAx85m3OpTyJsH47jrbacf+kcXMWrwiLDKeBHRsJ+VV5AI7SuWcQhdzrBjxgMDvw1+YVr6St5P4xsFC0aARQGKfiegD
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK+kcXMWrwiLDKeBHRsJ+jedSoT7D2Qu+w3H0dv1QpIAJUGEoCf
	elif AEXO2m8Yq6npHlfyzhGJ:
		fzu7Got0FgiyshTlJK = kTb69AueJDo3EH1ti0sVBOaz2XQf8F(fzu7Got0FgiyshTlJK,AEXO2m8Yq6npHlfyzhGJ)
		fzu7Got0FgiyshTlJK = AEXO2m8Yq6npHlfyzhGJ+fzu7Got0FgiyshTlJK
	Z2CEnfA3yd = t0xkM74rgEAFIepSWXilNOGDn,mxIgVCZFWHv,uuSU5Awl8FNrzkXHdQDiCWq3,str(HOkAWvmZSP5c2t9Dq4NgELyps),dcsuVN65wyfR2EBqx8bXQMr,R8aw0V1gIy4CGseEif,RRwhvHtPELBW7dOUAl8qejQFg,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq
	ehdwgpryD3xc91V6HBYu2MGt = {'type':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'mode':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'url':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'text':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'page':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'name':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'image':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'context':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'infodict':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	if rJ2oTLqabRtA: mxIgVCZFWHv = mxIgVCZFWHv.encode(e87cIA5vwOQLDEP1,'ignore').decode(e87cIA5vwOQLDEP1)
	ehdwgpryD3xc91V6HBYu2MGt['name'] = ZisgmEGCOJxVI9DcetNBPo6(mxIgVCZFWHv)
	ehdwgpryD3xc91V6HBYu2MGt['type'] = t0xkM74rgEAFIepSWXilNOGDn.strip(kcXMWrwiLDKeBHRsJ)
	ehdwgpryD3xc91V6HBYu2MGt['mode'] = str(HOkAWvmZSP5c2t9Dq4NgELyps).strip(kcXMWrwiLDKeBHRsJ)
	if t0xkM74rgEAFIepSWXilNOGDn=='folder' and R8aw0V1gIy4CGseEif: ehdwgpryD3xc91V6HBYu2MGt['page'] = ZisgmEGCOJxVI9DcetNBPo6(R8aw0V1gIy4CGseEif.strip(kcXMWrwiLDKeBHRsJ))
	if EaOw4PxtyQpZXM3: ehdwgpryD3xc91V6HBYu2MGt['context'] = EaOw4PxtyQpZXM3.strip(kcXMWrwiLDKeBHRsJ)
	if RRwhvHtPELBW7dOUAl8qejQFg: ehdwgpryD3xc91V6HBYu2MGt['text'] = ZisgmEGCOJxVI9DcetNBPo6(RRwhvHtPELBW7dOUAl8qejQFg.strip(kcXMWrwiLDKeBHRsJ))
	if dcsuVN65wyfR2EBqx8bXQMr: ehdwgpryD3xc91V6HBYu2MGt['image'] = ZisgmEGCOJxVI9DcetNBPo6(dcsuVN65wyfR2EBqx8bXQMr.strip(kcXMWrwiLDKeBHRsJ))
	if rBSIjX6x2FVTgOeG4CREKfUq:
		rBSIjX6x2FVTgOeG4CREKfUq = str(rBSIjX6x2FVTgOeG4CREKfUq)
		ehdwgpryD3xc91V6HBYu2MGt['infodict'] = ZisgmEGCOJxVI9DcetNBPo6(rBSIjX6x2FVTgOeG4CREKfUq.strip(kcXMWrwiLDKeBHRsJ))
		rBSIjX6x2FVTgOeG4CREKfUq = eval(rBSIjX6x2FVTgOeG4CREKfUq)
	else: rBSIjX6x2FVTgOeG4CREKfUq = {}
	if uuSU5Awl8FNrzkXHdQDiCWq3: ehdwgpryD3xc91V6HBYu2MGt['url'] = ZisgmEGCOJxVI9DcetNBPo6(uuSU5Awl8FNrzkXHdQDiCWq3.strip(kcXMWrwiLDKeBHRsJ))
	GZycfH216mFdbsvQB8YK7W = {'name':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'context_menu':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'plot':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'stars':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'image':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'type':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'isFolder':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'newpath':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'duration':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
	TTnGv2axUeDd7lBqHEwJyNOFboR = []
	hDWyT9jdbIPmJs7XlGLFr1 = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'/?type='+ehdwgpryD3xc91V6HBYu2MGt['type']+'&mode='+ehdwgpryD3xc91V6HBYu2MGt['mode']
	if ehdwgpryD3xc91V6HBYu2MGt['page']: hDWyT9jdbIPmJs7XlGLFr1 += '&page='+ehdwgpryD3xc91V6HBYu2MGt['page']
	if ehdwgpryD3xc91V6HBYu2MGt['name']: hDWyT9jdbIPmJs7XlGLFr1 += '&name='+ehdwgpryD3xc91V6HBYu2MGt['name']
	if ehdwgpryD3xc91V6HBYu2MGt['text']: hDWyT9jdbIPmJs7XlGLFr1 += '&text='+ehdwgpryD3xc91V6HBYu2MGt['text']
	if ehdwgpryD3xc91V6HBYu2MGt['infodict']: hDWyT9jdbIPmJs7XlGLFr1 += '&infodict='+ehdwgpryD3xc91V6HBYu2MGt['infodict']
	if ehdwgpryD3xc91V6HBYu2MGt['image']: hDWyT9jdbIPmJs7XlGLFr1 += '&image='+ehdwgpryD3xc91V6HBYu2MGt['image']
	if ehdwgpryD3xc91V6HBYu2MGt['url']: hDWyT9jdbIPmJs7XlGLFr1 += '&url='+ehdwgpryD3xc91V6HBYu2MGt['url']
	if HOkAWvmZSP5c2t9Dq4NgELyps not in [265,533]: GZycfH216mFdbsvQB8YK7W['favorites'] = r0D4C3z7Onqpa
	else: GZycfH216mFdbsvQB8YK7W['favorites'] = KiryBCvngZzF85UN6xSDlOVweL4I9
	if ehdwgpryD3xc91V6HBYu2MGt['context']: hDWyT9jdbIPmJs7XlGLFr1 += '&context='+ehdwgpryD3xc91V6HBYu2MGt['context']
	if HOkAWvmZSP5c2t9Dq4NgELyps in [235,238] and t0xkM74rgEAFIepSWXilNOGDn=='live' and 'EPG' in EaOw4PxtyQpZXM3:
		ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?mode=238&text=SHORT_EPG&url='+uuSU5Awl8FNrzkXHdQDiCWq3
		T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'البرامج القادمة'+YVr6St5P4xsFC0aARQGKfiegD
		TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
		TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if HOkAWvmZSP5c2t9Dq4NgELyps==265:
		ZSVPe5Lr1igfpm = l7nrJawpUzoNc(RRwhvHtPELBW7dOUAl8qejQFg,r0D4C3z7Onqpa)
		if ZSVPe5Lr1igfpm>j0jEZgiKdxFpMLHcU7kQr8v1lyX4:
			ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?mode=266&text='+RRwhvHtPELBW7dOUAl8qejQFg
			T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'مسح قائمة آخر 50 '+v2oRq5AhQzcx(RRwhvHtPELBW7dOUAl8qejQFg)+YVr6St5P4xsFC0aARQGKfiegD
			TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
			TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if t0xkM74rgEAFIepSWXilNOGDn=='video' and HOkAWvmZSP5c2t9Dq4NgELyps!=331:
		ytaODLovfMm = hDWyT9jdbIPmJs7XlGLFr1+'&context=6_DOWNLOAD'
		T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'تحميل ملف الفيديو'+YVr6St5P4xsFC0aARQGKfiegD
		TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
		TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if HOkAWvmZSP5c2t9Dq4NgELyps==331:
		ytaODLovfMm = hDWyT9jdbIPmJs7XlGLFr1+'&context=6_DELETE'
		T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'حذف ملف الفيديو'+YVr6St5P4xsFC0aARQGKfiegD
		TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
		TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if t0xkM74rgEAFIepSWXilNOGDn=='folder' and HOkAWvmZSP5c2t9Dq4NgELyps==540:
		uBFmSoWqQdTP061NeUt32cZ4i5R = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_SPLITTED_ALL')
		if uBFmSoWqQdTP061NeUt32cZ4i5R:
			ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?context=7'
			T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'مسح كلمات بحث المواقع'+YVr6St5P4xsFC0aARQGKfiegD
			TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
			TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if t0xkM74rgEAFIepSWXilNOGDn=='folder' and HOkAWvmZSP5c2t9Dq4NgELyps==1010:
		uBFmSoWqQdTP061NeUt32cZ4i5R = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if uBFmSoWqQdTP061NeUt32cZ4i5R:
			ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?context=10'
			T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'مسح كلمات بحث جوجل'+YVr6St5P4xsFC0aARQGKfiegD
			TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
			TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	M7rQtn9vgUHh = [9990,9999,XURrDCfOS9Mbhpv2Pmjos56TeW,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,536,537,538,540,710,719,761,762,1010,1022,1101,1103]
	if HOkAWvmZSP5c2t9Dq4NgELyps not in M7rQtn9vgUHh:
		ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?context=8&mode=260'
		T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'القائمة الرئيسية'+YVr6St5P4xsFC0aARQGKfiegD
		TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
		TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	hLOv7y0z983ZpKPn5UVM1XA = HOkAWvmZSP5c2t9Dq4NgELyps-HOkAWvmZSP5c2t9Dq4NgELyps%10
	if HOkAWvmZSP5c2t9Dq4NgELyps%10:
		if hLOv7y0z983ZpKPn5UVM1XA==280: hLOv7y0z983ZpKPn5UVM1XA = 230
		if hLOv7y0z983ZpKPn5UVM1XA==410: hLOv7y0z983ZpKPn5UVM1XA = 400
		if hLOv7y0z983ZpKPn5UVM1XA==520: hLOv7y0z983ZpKPn5UVM1XA = 510
		if hLOv7y0z983ZpKPn5UVM1XA not in KfE5mTdHZRaLnU:
			ytaODLovfMm = 'plugin://'+B40Qr5hlSgNm1kuXD3ZFpnyC9+'?context=8&mode='+str(hLOv7y0z983ZpKPn5UVM1XA)
			T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'قائمة الموقع'+YVr6St5P4xsFC0aARQGKfiegD
			TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
			TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	ytaODLovfMm = hDWyT9jdbIPmJs7XlGLFr1+'&context=9'
	T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'تحديث القائمة'+YVr6St5P4xsFC0aARQGKfiegD
	TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
	TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if t0xkM74rgEAFIepSWXilNOGDn in ['video','live']:
		ytaODLovfMm = hDWyT9jdbIPmJs7XlGLFr1+'&context=18'
		T74H81GbMgDom = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'إظهار قوائم الجودة'+YVr6St5P4xsFC0aARQGKfiegD
		TtUrRG4OV1Cpsw65QLdb = (T74H81GbMgDom,'RunPlugin('+ytaODLovfMm+')')
		TTnGv2axUeDd7lBqHEwJyNOFboR.append(TtUrRG4OV1Cpsw65QLdb)
	if t0xkM74rgEAFIepSWXilNOGDn in ['link','video','live']: M9mOhdRk0p = KiryBCvngZzF85UN6xSDlOVweL4I9
	elif t0xkM74rgEAFIepSWXilNOGDn=='folder': M9mOhdRk0p = r0D4C3z7Onqpa
	GZycfH216mFdbsvQB8YK7W['name'] = fzu7Got0FgiyshTlJK
	GZycfH216mFdbsvQB8YK7W['context_menu'] = TTnGv2axUeDd7lBqHEwJyNOFboR
	if 'plot' in list(rBSIjX6x2FVTgOeG4CREKfUq.keys()): GZycfH216mFdbsvQB8YK7W['plot'] = rBSIjX6x2FVTgOeG4CREKfUq['plot']
	if 'stars' in list(rBSIjX6x2FVTgOeG4CREKfUq.keys()): GZycfH216mFdbsvQB8YK7W['stars'] = rBSIjX6x2FVTgOeG4CREKfUq['stars']
	if dcsuVN65wyfR2EBqx8bXQMr: GZycfH216mFdbsvQB8YK7W['image'] = dcsuVN65wyfR2EBqx8bXQMr
	if t0xkM74rgEAFIepSWXilNOGDn=='video' and R8aw0V1gIy4CGseEif:
		cia3ou2EStIb9wNzfFvHD1py456qP = p7dwlH1PRStBgyMUW.findall('[\d:]+',R8aw0V1gIy4CGseEif,p7dwlH1PRStBgyMUW.DOTALL)
		if cia3ou2EStIb9wNzfFvHD1py456qP:
			cia3ou2EStIb9wNzfFvHD1py456qP = '0:0:0:0:0:'+cia3ou2EStIb9wNzfFvHD1py456qP[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
			jAPL6vaKoNeCJx5QGEH2h9UVn1w,ZtRVEOpuqHaDYG8xIAUhiogeF,t5CMFhUfZL0D,ODfpr61mdCZASE9g,QjBLc2Jlodvke9ERm7CPxr8S = cia3ou2EStIb9wNzfFvHD1py456qP.rsplit(':',yGLl1nSBrJPmi2adko9O)
			uTn9AZR3rt = int(ZtRVEOpuqHaDYG8xIAUhiogeF)*24*Ax4cp5PzJ0IuBknC+int(t5CMFhUfZL0D)*Ax4cp5PzJ0IuBknC+int(ODfpr61mdCZASE9g)*60+int(QjBLc2Jlodvke9ERm7CPxr8S)
			GZycfH216mFdbsvQB8YK7W['duration'] = uTn9AZR3rt
	GZycfH216mFdbsvQB8YK7W['type'] = t0xkM74rgEAFIepSWXilNOGDn
	GZycfH216mFdbsvQB8YK7W['isFolder'] = M9mOhdRk0p
	GZycfH216mFdbsvQB8YK7W['newpath'] = hDWyT9jdbIPmJs7XlGLFr1
	GZycfH216mFdbsvQB8YK7W['menuItem'] = Z2CEnfA3yd
	GZycfH216mFdbsvQB8YK7W['mode'] = HOkAWvmZSP5c2t9Dq4NgELyps
	return GZycfH216mFdbsvQB8YK7W
def e7WYrJtuzF6CES(l7nrJawpUzoNc):
	tSzdNX4IKPvef891oBy,h1Pf2qE7ap = [],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	from zQ1YjoMLiN import yyQrnbKfzwMi,Ut60yQZszi2cVO3geI4XdLjKRE7bG
	iqCc2wu3NdJHX7Foxf4nBUyzlSraOP = yyQrnbKfzwMi()
	rLEuTzBs2HFXjeSyfvCZcQw4O = G3yDpvxOiSWdAeL.getSetting('av.status.refresh')
	if oobgjl3xWaBeRZF8wdzKYAvtus and (not rLEuTzBs2HFXjeSyfvCZcQw4O or rLEuTzBs2HFXjeSyfvCZcQw4O=='REFRESH_CACHE'): rLEuTzBs2HFXjeSyfvCZcQw4O = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'str','FOLDERS_SORT',oobgjl3xWaBeRZF8wdzKYAvtus)
	if rLEuTzBs2HFXjeSyfvCZcQw4O:
		if   '_PERM' in rLEuTzBs2HFXjeSyfvCZcQw4O: h1Pf2qE7ap = 'دائمي'
		elif '_TEMP' in rLEuTzBs2HFXjeSyfvCZcQw4O: h1Pf2qE7ap = 'مؤقت'
		if   '_REVERSED_' in rLEuTzBs2HFXjeSyfvCZcQw4O: Zf06rvhWgN3OPj2YTdeqU = 'عكسي' ; A3pXVFdyP1.menuItemsLIST[:] = reversed(A3pXVFdyP1.menuItemsLIST)
		elif '_ASCENDED_' in rLEuTzBs2HFXjeSyfvCZcQw4O: Zf06rvhWgN3OPj2YTdeqU = 'تصاعدي' ; A3pXVFdyP1.menuItemsLIST[:] = sorted(A3pXVFdyP1.menuItemsLIST,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key:key[wnaWTQM7VJPkZzO9eoSyFU4])
		elif '_DESCENDED_' in rLEuTzBs2HFXjeSyfvCZcQw4O: Zf06rvhWgN3OPj2YTdeqU = 'تنازلي' ; A3pXVFdyP1.menuItemsLIST[:] = sorted(A3pXVFdyP1.menuItemsLIST,reverse=r0D4C3z7Onqpa,key=lambda key:key[wnaWTQM7VJPkZzO9eoSyFU4])
		elif '_RANDOMIZED_' in rLEuTzBs2HFXjeSyfvCZcQw4O: Zf06rvhWgN3OPj2YTdeqU = 'عشوائي' ; FxEWL1w4gjr8mM.shuffle(A3pXVFdyP1.menuItemsLIST)
	name = 'ترتيب '+Zf06rvhWgN3OPj2YTdeqU+kcXMWrwiLDKeBHRsJ+h1Pf2qE7ap if h1Pf2qE7ap else 'بدون ترتيب (أصلي)'
	name = RNWqL0gBbKOie1DxjUpzQPh9aZyHX+name+YVr6St5P4xsFC0aARQGKfiegD
	if rLEuTzBs2HFXjeSyfvCZcQw4O in ffYFH1jX8B24iv6RGrQc: G3yDpvxOiSWdAeL.setSetting('av.status.refresh',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = UbF7JxE84r2D(oobgjl3xWaBeRZF8wdzKYAvtus)
	HOkAWvmZSP5c2t9Dq4NgELyps = int(e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE)
	hLOv7y0z983ZpKPn5UVM1XA = HOkAWvmZSP5c2t9Dq4NgELyps-HOkAWvmZSP5c2t9Dq4NgELyps%10
	if HOkAWvmZSP5c2t9Dq4NgELyps%10 and hLOv7y0z983ZpKPn5UVM1XA not in KfE5mTdHZRaLnU and len(A3pXVFdyP1.menuItemsLIST)>1:
		A3pXVFdyP1.menuItemsLIST[:] = [('link',name,'',533,'','',oobgjl3xWaBeRZF8wdzKYAvtus,'','')]+A3pXVFdyP1.menuItemsLIST
	for Z2CEnfA3yd in A3pXVFdyP1.menuItemsLIST:
		GZycfH216mFdbsvQB8YK7W = KUC8lG5Yd0uRgj(Z2CEnfA3yd,l7nrJawpUzoNc,iqCc2wu3NdJHX7Foxf4nBUyzlSraOP)
		if GZycfH216mFdbsvQB8YK7W['favorites']:
			QPRFje4ckNyoO9 = Ut60yQZszi2cVO3geI4XdLjKRE7bG(iqCc2wu3NdJHX7Foxf4nBUyzlSraOP,GZycfH216mFdbsvQB8YK7W['menuItem'],GZycfH216mFdbsvQB8YK7W['newpath'])
			GZycfH216mFdbsvQB8YK7W['context_menu'] = QPRFje4ckNyoO9+GZycfH216mFdbsvQB8YK7W['context_menu']
		tSzdNX4IKPvef891oBy.append(GZycfH216mFdbsvQB8YK7W)
	dHstN2gPLFWZ8yO5Mk = KiryBCvngZzF85UN6xSDlOVweL4I9 if '_TEMP' in rLEuTzBs2HFXjeSyfvCZcQw4O else r0D4C3z7Onqpa
	return tSzdNX4IKPvef891oBy,dHstN2gPLFWZ8yO5Mk
def b3bPX7ry09NYqITUEOaj(t7TS2ruafMQ):
	MpimvHudO63f1CTcSL5,yPlMzCbeGtdsN1IJg4VZQiOKv, = [],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		if not JHLkRVEQFA1WUwZPtD4Cyxr8: MpimvHudO63f1CTcSL5.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		else: break
	t7TS2ruafMQ = t7TS2ruafMQ[len(MpimvHudO63f1CTcSL5):]
	ZVk6IphECKLzUceP15j = '\n\n\n\n'.join(t7TS2ruafMQ)
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('===== ===== =====','000001')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(e6HEdvUcaq8Gx,'000002')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,'000003')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(YVr6St5P4xsFC0aARQGKfiegD,'000004')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[RIGHT]','000005')
	vdRg23DAaJe8 = 100000
	Radn89G2N1upM57evjfhixLFXz6CVy = {}
	gl9rEzoK0YeTZmkv6cRN8HAXOSI = p7dwlH1PRStBgyMUW.findall('http.*?[\r\n ]',ZVk6IphECKLzUceP15j,p7dwlH1PRStBgyMUW.DOTALL)
	for kWojy0CdpBiePQHcxz2wmKXI9 in gl9rEzoK0YeTZmkv6cRN8HAXOSI:
		vdRg23DAaJe8 += wnaWTQM7VJPkZzO9eoSyFU4
		ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(kWojy0CdpBiePQHcxz2wmKXI9,str(vdRg23DAaJe8))
		Radn89G2N1upM57evjfhixLFXz6CVy[str(vdRg23DAaJe8)] = kWojy0CdpBiePQHcxz2wmKXI9
	for pMiDdTC8LUE2wIV in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,len(ZVk6IphECKLzUceP15j),4800):
		aOW4kErUIyTHx5Pwp2 = ZVk6IphECKLzUceP15j[pMiDdTC8LUE2wIV:pMiDdTC8LUE2wIV+4800]
		h7kzQ0BeCjGXa3JWU9ry8d2 = G3yDpvxOiSWdAeL.getSetting('av.language.code')
		uuSU5Awl8FNrzkXHdQDiCWq3 = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+h7kzQ0BeCjGXa3JWU9ry8d2
		d91ITp3ybeYCWjGBFHqkD7voru6Eg = {'Content-Type':'text/plain'}
		YUWbDcRzAJL0 = aOW4kErUIyTHx5Pwp2.encode(e87cIA5vwOQLDEP1)
		lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'POST',uuSU5Awl8FNrzkXHdQDiCWq3,YUWbDcRzAJL0,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if lAJu8dmbEUPZjrIahBH.succeeded:
			lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
			Yo7r1wCesyZk95cVdUMOua4DJzT = IXZpzK7ShaRsAN('str',lXqaJs1WkUZ9Rz0)
			if Yo7r1wCesyZk95cVdUMOua4DJzT:
				Yo7r1wCesyZk95cVdUMOua4DJzT = Yo7r1wCesyZk95cVdUMOua4DJzT['translation']
				Yo7r1wCesyZk95cVdUMOua4DJzT = clFjTSgMODe7Nq0H3Vzs(Yo7r1wCesyZk95cVdUMOua4DJzT)
				for VRTAtMKBOzmL8jan9ydE5I in range(len(Yo7r1wCesyZk95cVdUMOua4DJzT)):
					yPlMzCbeGtdsN1IJg4VZQiOKv += Yo7r1wCesyZk95cVdUMOua4DJzT[VRTAtMKBOzmL8jan9ydE5I][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000001','===== ===== =====')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000002',e6HEdvUcaq8Gx)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000003',RNWqL0gBbKOie1DxjUpzQPh9aZyHX)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000004',YVr6St5P4xsFC0aARQGKfiegD)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000005','[RIGHT]')
	for vdRg23DAaJe8 in list(Radn89G2N1upM57evjfhixLFXz6CVy.keys()):
		kWojy0CdpBiePQHcxz2wmKXI9 = Radn89G2N1upM57evjfhixLFXz6CVy[vdRg23DAaJe8]
		yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace(vdRg23DAaJe8,kWojy0CdpBiePQHcxz2wmKXI9)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.split('\n\n\n\n')
	return MpimvHudO63f1CTcSL5+yPlMzCbeGtdsN1IJg4VZQiOKv
def lZtiIvEeO6qfGb(t7TS2ruafMQ):
	MpimvHudO63f1CTcSL5,yPlMzCbeGtdsN1IJg4VZQiOKv, = [],WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		if not JHLkRVEQFA1WUwZPtD4Cyxr8: MpimvHudO63f1CTcSL5.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		else: break
	t7TS2ruafMQ = t7TS2ruafMQ[len(MpimvHudO63f1CTcSL5):]
	ZVk6IphECKLzUceP15j = '\\n\\n\\n\\n'.join(t7TS2ruafMQ)
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('كلا','no')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('استمرار','continue')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('===== ===== =====','000001')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(e6HEdvUcaq8Gx,'000002')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,'000003')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(YVr6St5P4xsFC0aARQGKfiegD,'000004')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[RIGHT]','000005')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[CENTER]','000006')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[RTL]','000007')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace("'","\\\\\\'")
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('"','\\\\\\"')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,'\\n')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(TTLxlKI0gNfh7FP,'\\\\r')
	for pMiDdTC8LUE2wIV in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,len(ZVk6IphECKLzUceP15j),4800):
		aOW4kErUIyTHx5Pwp2 = ZVk6IphECKLzUceP15j[pMiDdTC8LUE2wIV:pMiDdTC8LUE2wIV+4800]
		uuSU5Awl8FNrzkXHdQDiCWq3 = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		d91ITp3ybeYCWjGBFHqkD7voru6Eg = {'Content-Type':'application/x-www-form-urlencoded'}
		h7kzQ0BeCjGXa3JWU9ry8d2 = G3yDpvxOiSWdAeL.getSetting('av.language.code')
		YUWbDcRzAJL0 = 'f.req='+ZisgmEGCOJxVI9DcetNBPo6('[[["MkEWBc","[[\\"'+aOW4kErUIyTHx5Pwp2+'\\",\\"ar\\",\\"'+h7kzQ0BeCjGXa3JWU9ry8d2+'\\",1],[]]",null,"generic"]]]',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		YUWbDcRzAJL0 = YUWbDcRzAJL0.replace('%5Cn','%5C%5Cn')
		lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'POST',uuSU5Awl8FNrzkXHdQDiCWq3,YUWbDcRzAJL0,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if lAJu8dmbEUPZjrIahBH.succeeded:
			lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
			lXqaJs1WkUZ9Rz0 = lXqaJs1WkUZ9Rz0.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)[-wnaWTQM7VJPkZzO9eoSyFU4]
			Yo7r1wCesyZk95cVdUMOua4DJzT = IXZpzK7ShaRsAN('str',lXqaJs1WkUZ9Rz0)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][XURrDCfOS9Mbhpv2Pmjos56TeW]
			if Yo7r1wCesyZk95cVdUMOua4DJzT:
				Yo7r1wCesyZk95cVdUMOua4DJzT = IXZpzK7ShaRsAN('str',Yo7r1wCesyZk95cVdUMOua4DJzT)[wnaWTQM7VJPkZzO9eoSyFU4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][j0jEZgiKdxFpMLHcU7kQr8v1lyX4][EEowc8rs5gUZTVjdOzmb0nu]
				Yo7r1wCesyZk95cVdUMOua4DJzT = clFjTSgMODe7Nq0H3Vzs(Yo7r1wCesyZk95cVdUMOua4DJzT)
				for VRTAtMKBOzmL8jan9ydE5I in range(len(Yo7r1wCesyZk95cVdUMOua4DJzT)):
					yPlMzCbeGtdsN1IJg4VZQiOKv += Yo7r1wCesyZk95cVdUMOua4DJzT[VRTAtMKBOzmL8jan9ydE5I][j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('00000','0000').replace('0000','000')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0001','===== ===== =====')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0002',e6HEdvUcaq8Gx)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0003',RNWqL0gBbKOie1DxjUpzQPh9aZyHX)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0004',YVr6St5P4xsFC0aARQGKfiegD)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0005','[RIGHT]')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0006','[CENTER]')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0007','[RTL]')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.split('\n\n\n\n')
	return MpimvHudO63f1CTcSL5+yPlMzCbeGtdsN1IJg4VZQiOKv
def IeLkloD8MhaP(t7TS2ruafMQ):
	MpimvHudO63f1CTcSL5,jjdPIbyh2mcnTi5 = [],[]
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		if not JHLkRVEQFA1WUwZPtD4Cyxr8: MpimvHudO63f1CTcSL5.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		else: break
	t7TS2ruafMQ = t7TS2ruafMQ[len(MpimvHudO63f1CTcSL5):]
	ZVk6IphECKLzUceP15j = '\n\n\n\n'.join(t7TS2ruafMQ)
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('كلا','no')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('استمرار','continue')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('أدناه','below')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(e6HEdvUcaq8Gx,'00001')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,'00002')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(YVr6St5P4xsFC0aARQGKfiegD,'00003')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('=====','00004')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(',','00005')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[RTL]','00009')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace('[CENTER]','0000A')
	ZVk6IphECKLzUceP15j = ZVk6IphECKLzUceP15j.replace(TTLxlKI0gNfh7FP,'0000B')
	t7TS2ruafMQ = ZVk6IphECKLzUceP15j.split(WBDnh75CaLEvkcN6p4ez2KXrV3M)
	ZVk6IphECKLzUceP15j,yPlMzCbeGtdsN1IJg4VZQiOKv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in t7TS2ruafMQ:
		if len(ZVk6IphECKLzUceP15j+JHLkRVEQFA1WUwZPtD4Cyxr8)<1800: ZVk6IphECKLzUceP15j += WBDnh75CaLEvkcN6p4ez2KXrV3M+JHLkRVEQFA1WUwZPtD4Cyxr8
		else:
			jjdPIbyh2mcnTi5.append(ZVk6IphECKLzUceP15j)
			ZVk6IphECKLzUceP15j = JHLkRVEQFA1WUwZPtD4Cyxr8
	jjdPIbyh2mcnTi5.append(ZVk6IphECKLzUceP15j)
	for JHLkRVEQFA1WUwZPtD4Cyxr8 in jjdPIbyh2mcnTi5:
		d91ITp3ybeYCWjGBFHqkD7voru6Eg = {'Content-Type':'application/json','User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
		uuSU5Awl8FNrzkXHdQDiCWq3 = 'https://api.reverso.net/translate/v1/translation'
		h7kzQ0BeCjGXa3JWU9ry8d2 = G3yDpvxOiSWdAeL.getSetting('av.language.code')
		YUWbDcRzAJL0 = {"format":"text","from":"ara","to":h7kzQ0BeCjGXa3JWU9ry8d2,"input":JHLkRVEQFA1WUwZPtD4Cyxr8,"options":{"sentenceSplitter":r0D4C3z7Onqpa,"origin":"translation.web","contextResults":KiryBCvngZzF85UN6xSDlOVweL4I9,"languageDetection":KiryBCvngZzF85UN6xSDlOVweL4I9}}
		YUWbDcRzAJL0 = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.dumps(YUWbDcRzAJL0)
		lAJu8dmbEUPZjrIahBH = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'POST',uuSU5Awl8FNrzkXHdQDiCWq3,YUWbDcRzAJL0,d91ITp3ybeYCWjGBFHqkD7voru6Eg,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'LIBRARY-REVERSO_TRANSLATE-1st')
		if lAJu8dmbEUPZjrIahBH.succeeded:
			lXqaJs1WkUZ9Rz0 = lAJu8dmbEUPZjrIahBH.content
			lXqaJs1WkUZ9Rz0 = IXZpzK7ShaRsAN('dict',lXqaJs1WkUZ9Rz0)
			yPlMzCbeGtdsN1IJg4VZQiOKv += WBDnh75CaLEvkcN6p4ez2KXrV3M+WnNGfosHr5STAq8j7miwyRZ6eOUbV.join(lXqaJs1WkUZ9Rz0['translation'])
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv[XURrDCfOS9Mbhpv2Pmjos56TeW:]
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000000','00000').replace('00000','0000').replace('0000','000')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0001',e6HEdvUcaq8Gx)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0002',RNWqL0gBbKOie1DxjUpzQPh9aZyHX)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0003',YVr6St5P4xsFC0aARQGKfiegD)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0004','=====')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0005',',')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('0009','[RTL]')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000A','[CENTER]')
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.replace('000B',TTLxlKI0gNfh7FP)
	yPlMzCbeGtdsN1IJg4VZQiOKv = yPlMzCbeGtdsN1IJg4VZQiOKv.split('\n\n\n\n')
	return MpimvHudO63f1CTcSL5+yPlMzCbeGtdsN1IJg4VZQiOKv
def llBW3Jpg8MXA(t7TS2ruafMQ):
	mNOMsGCeVpuZD = G3yDpvxOiSWdAeL.getSetting('av.language.translate')
	if not mNOMsGCeVpuZD or not t7TS2ruafMQ: return t7TS2ruafMQ
	G1GKFlN08ua7PgdAspzfB94UkCow = G3yDpvxOiSWdAeL.getSetting('av.language.provider')
	h7kzQ0BeCjGXa3JWU9ry8d2 = G3yDpvxOiSWdAeL.getSetting('av.language.code')
	oUr4s0pHA7Oue3bFYctDEa8Z6 = h7kzQ0BeCjGXa3JWU9ry8d2+'__'+str(t7TS2ruafMQ)
	G3yDpvxOiSWdAeL.setSetting('av.language.translate',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	yPlMzCbeGtdsN1IJg4VZQiOKv = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','TRANSLATE_'+G1GKFlN08ua7PgdAspzfB94UkCow,oUr4s0pHA7Oue3bFYctDEa8Z6)
	if not yPlMzCbeGtdsN1IJg4VZQiOKv:
		if G1GKFlN08ua7PgdAspzfB94UkCow=='GOOGLE': yPlMzCbeGtdsN1IJg4VZQiOKv = lZtiIvEeO6qfGb(t7TS2ruafMQ)
		elif G1GKFlN08ua7PgdAspzfB94UkCow=='REVERSO': yPlMzCbeGtdsN1IJg4VZQiOKv = IeLkloD8MhaP(t7TS2ruafMQ)
		elif G1GKFlN08ua7PgdAspzfB94UkCow=='GLOSBE': yPlMzCbeGtdsN1IJg4VZQiOKv = b3bPX7ry09NYqITUEOaj(t7TS2ruafMQ)
		if len(t7TS2ruafMQ)==len(yPlMzCbeGtdsN1IJg4VZQiOKv):
			w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'TRANSLATE_'+G1GKFlN08ua7PgdAspzfB94UkCow,oUr4s0pHA7Oue3bFYctDEa8Z6,yPlMzCbeGtdsN1IJg4VZQiOKv,T0le9tWJd7IAfKH1rNGB)
		else:
			yPlMzCbeGtdsN1IJg4VZQiOKv = t7TS2ruafMQ
			uTaiRMI8eYmN('الترجمة فشلت','Translation Failed')
	G3yDpvxOiSWdAeL.setSetting('av.language.translate','1')
	return yPlMzCbeGtdsN1IJg4VZQiOKv
def U1jrPe7mLiHwgaZn4GlJXp(Z2CEnfA3yd,tSzdNX4IKPvef891oBy,pw8aLc3HTqMVWQO21yt6zfub,wPkO1AtjbZaxKr0nF8J,Ykz60er8FQWpjfA72CX1NwgPu):
	t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq = Z2CEnfA3yd
	UXY7obyVnz2H4 = []
	mNOMsGCeVpuZD = G3yDpvxOiSWdAeL.getSetting('av.language.translate')
	if mNOMsGCeVpuZD:
		jjt3pnr9SPNazmXUkRG2FdZVL5evTq,OxV4reEv1kSaJhwd0IC,lKUEhgTMiJwz7cyA0C4NDexprVm2a = [],[],[]
		if not UXY7obyVnz2H4:
			for GZycfH216mFdbsvQB8YK7W in tSzdNX4IKPvef891oBy:
				fzu7Got0FgiyshTlJK = GZycfH216mFdbsvQB8YK7W['name'].replace(jedSoT7D2Qu,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(w1gu8bCmYAvdjf5a,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				w3H0dv1QpIAJUGEoCf = p7dwlH1PRStBgyMUW.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
				if w3H0dv1QpIAJUGEoCf:
					MpimvHudO63f1CTcSL5,VV5AI7SuWcQhdzrBjxgMDvw1,GAx85m3OpTyJsH47jrbacf,WvMYcq13AOl,fzu7Got0FgiyshTlJK = w3H0dv1QpIAJUGEoCf[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
					w3H0dv1QpIAJUGEoCf = MpimvHudO63f1CTcSL5+VV5AI7SuWcQhdzrBjxgMDvw1+kcXMWrwiLDKeBHRsJ+GAx85m3OpTyJsH47jrbacf+WvMYcq13AOl+kcXMWrwiLDKeBHRsJ
				else:
					w3H0dv1QpIAJUGEoCf = p7dwlH1PRStBgyMUW.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
					if w3H0dv1QpIAJUGEoCf:
						fzu7Got0FgiyshTlJK,MpimvHudO63f1CTcSL5,GAx85m3OpTyJsH47jrbacf,VV5AI7SuWcQhdzrBjxgMDvw1,WvMYcq13AOl = w3H0dv1QpIAJUGEoCf[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
						w3H0dv1QpIAJUGEoCf = MpimvHudO63f1CTcSL5+VV5AI7SuWcQhdzrBjxgMDvw1+kcXMWrwiLDKeBHRsJ+GAx85m3OpTyJsH47jrbacf+WvMYcq13AOl+kcXMWrwiLDKeBHRsJ
					else: w3H0dv1QpIAJUGEoCf = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				AEXO2m8Yq6npHlfyzhGJ = p7dwlH1PRStBgyMUW.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
				if AEXO2m8Yq6npHlfyzhGJ: AEXO2m8Yq6npHlfyzhGJ,fzu7Got0FgiyshTlJK = AEXO2m8Yq6npHlfyzhGJ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
				else: AEXO2m8Yq6npHlfyzhGJ = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				jjt3pnr9SPNazmXUkRG2FdZVL5evTq.append(w3H0dv1QpIAJUGEoCf+AEXO2m8Yq6npHlfyzhGJ)
				OxV4reEv1kSaJhwd0IC.append(fzu7Got0FgiyshTlJK)
			lKUEhgTMiJwz7cyA0C4NDexprVm2a = llBW3Jpg8MXA(OxV4reEv1kSaJhwd0IC)
			if lKUEhgTMiJwz7cyA0C4NDexprVm2a:
				for pMiDdTC8LUE2wIV in range(len(tSzdNX4IKPvef891oBy)):
					GZycfH216mFdbsvQB8YK7W = tSzdNX4IKPvef891oBy[pMiDdTC8LUE2wIV]
					GZycfH216mFdbsvQB8YK7W['name'] = jjt3pnr9SPNazmXUkRG2FdZVL5evTq[pMiDdTC8LUE2wIV]+lKUEhgTMiJwz7cyA0C4NDexprVm2a[pMiDdTC8LUE2wIV]
					UXY7obyVnz2H4.append(GZycfH216mFdbsvQB8YK7W)
	if UXY7obyVnz2H4: tSzdNX4IKPvef891oBy = UXY7obyVnz2H4
	qu4ZKC81tIkU,UGp1Ehy2maboXDejMHV6d705A,x9mNd81GoyfW37tDshXaL6QzjV4YJA = [],j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	H2doV8lbmyXBKT1 = G3yDpvxOiSWdAeL.getSetting('av.status.menusimages')
	emSfbYxWuXz = H2doV8lbmyXBKT1!='STOP'
	xcFrVly6OXu0eYs3qpZAkQ58aHbn = []
	if emSfbYxWuXz:
		BVs4rj32HNchWdUEbiQxwzaen01 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(Hp7qgMcFCX46nO8Poy,HOkAWvmZSP5c2t9Dq4NgELyps)
		try: xcFrVly6OXu0eYs3qpZAkQ58aHbn = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.listdir(BVs4rj32HNchWdUEbiQxwzaen01)
		except:
			if not pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.exists(BVs4rj32HNchWdUEbiQxwzaen01):
				try: pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.makedirs(BVs4rj32HNchWdUEbiQxwzaen01)
				except: pass
	G2SEARonKlCy = kMDPxyYf3UTB8Vmabt7cXAZ1sh92o0('menu_item')
	tUaG78opNehcE = xcFrVly6OXu0eYs3qpZAkQ58aHbn
	if YVzokG2yZqrh3w8bU and SZ0YL6RpbX.platform=='win32':
		tUaG78opNehcE = []
		for EEKqCAnzlo3ba7PGVckTJYXhSypFt5 in xcFrVly6OXu0eYs3qpZAkQ58aHbn:
			EEKqCAnzlo3ba7PGVckTJYXhSypFt5 = EEKqCAnzlo3ba7PGVckTJYXhSypFt5.decode(CRLStQiqxb6Y3Eh7G4UVF).encode(e87cIA5vwOQLDEP1)
			tUaG78opNehcE.append(EEKqCAnzlo3ba7PGVckTJYXhSypFt5)
	for GZycfH216mFdbsvQB8YK7W in tSzdNX4IKPvef891oBy:
		fzu7Got0FgiyshTlJK = GZycfH216mFdbsvQB8YK7W['name']
		if rJ2oTLqabRtA: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.encode(e87cIA5vwOQLDEP1,'ignore').decode(e87cIA5vwOQLDEP1)
		TTnGv2axUeDd7lBqHEwJyNOFboR = GZycfH216mFdbsvQB8YK7W['context_menu']
		EW36jUvRhiOHoeyuSrkZ = GZycfH216mFdbsvQB8YK7W['plot']
		f6l8WvYqTE1UgdJcmytCZo9iSF3a = GZycfH216mFdbsvQB8YK7W['stars']
		dcsuVN65wyfR2EBqx8bXQMr = GZycfH216mFdbsvQB8YK7W['image']
		t0xkM74rgEAFIepSWXilNOGDn = GZycfH216mFdbsvQB8YK7W['type']
		cia3ou2EStIb9wNzfFvHD1py456qP = GZycfH216mFdbsvQB8YK7W['duration']
		M9mOhdRk0p = GZycfH216mFdbsvQB8YK7W['isFolder']
		hDWyT9jdbIPmJs7XlGLFr1 = GZycfH216mFdbsvQB8YK7W['newpath']
		w0ZptDCYm2fVLkqE7oUn9yb = Zilvh2WQyb5.ListItem(fzu7Got0FgiyshTlJK)
		w0ZptDCYm2fVLkqE7oUn9yb.addContextMenuItems(TTnGv2axUeDd7lBqHEwJyNOFboR)
		OsD4YJAITC9bgqVdFKXWyaL = KiryBCvngZzF85UN6xSDlOVweL4I9 if emSfbYxWuXz else r0D4C3z7Onqpa
		if dcsuVN65wyfR2EBqx8bXQMr:
			w0ZptDCYm2fVLkqE7oUn9yb.setArt({'icon':dcsuVN65wyfR2EBqx8bXQMr,'thumb':dcsuVN65wyfR2EBqx8bXQMr,'fanart':dcsuVN65wyfR2EBqx8bXQMr,'banner':dcsuVN65wyfR2EBqx8bXQMr,'clearart':dcsuVN65wyfR2EBqx8bXQMr,'poster':dcsuVN65wyfR2EBqx8bXQMr,'clearlogo':dcsuVN65wyfR2EBqx8bXQMr,'landscape':dcsuVN65wyfR2EBqx8bXQMr})
			OsD4YJAITC9bgqVdFKXWyaL = KiryBCvngZzF85UN6xSDlOVweL4I9
		elif not OsD4YJAITC9bgqVdFKXWyaL:
			OsD4YJAITC9bgqVdFKXWyaL = r0D4C3z7Onqpa
			fzu7Got0FgiyshTlJK = qjt73vfsNQZUw6(KiryBCvngZzF85UN6xSDlOVweL4I9,fzu7Got0FgiyshTlJK)
			fzu7Got0FgiyshTlJK = WQzfBPt6sDuVw8N5xlcY(fzu7Got0FgiyshTlJK)
			GMepO17dyvFPrN5LHzwIYjKiB9aDS = fzu7Got0FgiyshTlJK+'.png'
			AKeuEvnp56kR0whTiXmUzsF8 = pNk4HfLdMBRYEQAzjyT0qaoe8cDPt.path.join(BVs4rj32HNchWdUEbiQxwzaen01,GMepO17dyvFPrN5LHzwIYjKiB9aDS)
			if GMepO17dyvFPrN5LHzwIYjKiB9aDS in tUaG78opNehcE:
				w0ZptDCYm2fVLkqE7oUn9yb.setArt({'icon':AKeuEvnp56kR0whTiXmUzsF8,'thumb':AKeuEvnp56kR0whTiXmUzsF8,'fanart':AKeuEvnp56kR0whTiXmUzsF8,'banner':AKeuEvnp56kR0whTiXmUzsF8,'clearart':AKeuEvnp56kR0whTiXmUzsF8,'poster':AKeuEvnp56kR0whTiXmUzsF8,'clearlogo':AKeuEvnp56kR0whTiXmUzsF8,'landscape':AKeuEvnp56kR0whTiXmUzsF8})
				OsD4YJAITC9bgqVdFKXWyaL = KiryBCvngZzF85UN6xSDlOVweL4I9
			elif UGp1Ehy2maboXDejMHV6d705A<40 and x9mNd81GoyfW37tDshXaL6QzjV4YJA<=vXIdY7TwFKso40gVBq5:
				try:
					w0eOlz5N6Cd74 = hDLSd2FPQZ(G2SEARonKlCy,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,fzu7Got0FgiyshTlJK,'menu_item','center',KiryBCvngZzF85UN6xSDlOVweL4I9,AKeuEvnp56kR0whTiXmUzsF8)
					w0ZptDCYm2fVLkqE7oUn9yb.setArt({'icon':AKeuEvnp56kR0whTiXmUzsF8,'thumb':AKeuEvnp56kR0whTiXmUzsF8,'fanart':AKeuEvnp56kR0whTiXmUzsF8,'banner':AKeuEvnp56kR0whTiXmUzsF8,'clearart':AKeuEvnp56kR0whTiXmUzsF8,'poster':AKeuEvnp56kR0whTiXmUzsF8,'clearlogo':AKeuEvnp56kR0whTiXmUzsF8,'landscape':AKeuEvnp56kR0whTiXmUzsF8})
					UGp1Ehy2maboXDejMHV6d705A += wnaWTQM7VJPkZzO9eoSyFU4
					OsD4YJAITC9bgqVdFKXWyaL = KiryBCvngZzF85UN6xSDlOVweL4I9
					tUaG78opNehcE.append(GMepO17dyvFPrN5LHzwIYjKiB9aDS)
					if UGp1Ehy2maboXDejMHV6d705A==EEowc8rs5gUZTVjdOzmb0nu: uTaiRMI8eYmN('إضافة الكتابة لصور القائمة','انتظار',x54xSdnCFHZ8yliofzOBK=500)
				except: x9mNd81GoyfW37tDshXaL6QzjV4YJA += wnaWTQM7VJPkZzO9eoSyFU4
		if OsD4YJAITC9bgqVdFKXWyaL:
			w0ZptDCYm2fVLkqE7oUn9yb.setArt({'icon':ucAYIptK5bJE0DQ742NxrBfqLea,'thumb':ucAYIptK5bJE0DQ742NxrBfqLea,'fanart':ucAYIptK5bJE0DQ742NxrBfqLea,'banner':ucAYIptK5bJE0DQ742NxrBfqLea,'clearart':ucAYIptK5bJE0DQ742NxrBfqLea,'poster':ucAYIptK5bJE0DQ742NxrBfqLea,'clearlogo':ucAYIptK5bJE0DQ742NxrBfqLea,'landscape':ucAYIptK5bJE0DQ742NxrBfqLea})
		if CCPXJ7wnNLOg0ZoekcmpdSKI<20:
			if EW36jUvRhiOHoeyuSrkZ: w0ZptDCYm2fVLkqE7oUn9yb.setInfo('video',{'Plot':EW36jUvRhiOHoeyuSrkZ,'PlotOutline':EW36jUvRhiOHoeyuSrkZ})
			if f6l8WvYqTE1UgdJcmytCZo9iSF3a: w0ZptDCYm2fVLkqE7oUn9yb.setInfo('video',{'Rating':f6l8WvYqTE1UgdJcmytCZo9iSF3a})
			if not dcsuVN65wyfR2EBqx8bXQMr:
				w0ZptDCYm2fVLkqE7oUn9yb.setInfo('video',{'Title':fzu7Got0FgiyshTlJK})
			if t0xkM74rgEAFIepSWXilNOGDn=='video':
				w0ZptDCYm2fVLkqE7oUn9yb.setInfo('video',{'mediatype':'tvshow'})
				if cia3ou2EStIb9wNzfFvHD1py456qP: w0ZptDCYm2fVLkqE7oUn9yb.setInfo('video',{'duration':cia3ou2EStIb9wNzfFvHD1py456qP})
				w0ZptDCYm2fVLkqE7oUn9yb.setProperty('IsPlayable','true')
		else:
			zzIuPnbKRmjeBoVtqaXg7UONGAS = w0ZptDCYm2fVLkqE7oUn9yb.getVideoInfoTag()
			if f6l8WvYqTE1UgdJcmytCZo9iSF3a: zzIuPnbKRmjeBoVtqaXg7UONGAS.setRating(float(f6l8WvYqTE1UgdJcmytCZo9iSF3a))
			if not dcsuVN65wyfR2EBqx8bXQMr:
				zzIuPnbKRmjeBoVtqaXg7UONGAS.setTitle(fzu7Got0FgiyshTlJK)
			if t0xkM74rgEAFIepSWXilNOGDn=='video':
				zzIuPnbKRmjeBoVtqaXg7UONGAS.setMediaType('tvshow')
				if cia3ou2EStIb9wNzfFvHD1py456qP: zzIuPnbKRmjeBoVtqaXg7UONGAS.setDuration(cia3ou2EStIb9wNzfFvHD1py456qP)
				w0ZptDCYm2fVLkqE7oUn9yb.setProperty('IsPlayable','true')
		qu4ZKC81tIkU.append((hDWyT9jdbIPmJs7XlGLFr1,w0ZptDCYm2fVLkqE7oUn9yb,M9mOhdRk0p))
	Ydimlc1rVsAnLIhkRyb6aK2.setContent(ZTaSobILWiO9ywfN64AVQPzUgKGHX,'tvshows')
	oQzxkrKeNf02 = Ydimlc1rVsAnLIhkRyb6aK2.addDirectoryItems(ZTaSobILWiO9ywfN64AVQPzUgKGHX,qu4ZKC81tIkU)
	Ydimlc1rVsAnLIhkRyb6aK2.endOfDirectory(ZTaSobILWiO9ywfN64AVQPzUgKGHX,pw8aLc3HTqMVWQO21yt6zfub,wPkO1AtjbZaxKr0nF8J,Ykz60er8FQWpjfA72CX1NwgPu)
	return oQzxkrKeNf02
def octplHnGwmE8bFqNdj7BiKvJ0VL(t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr=WnNGfosHr5STAq8j7miwyRZ6eOUbV,BfYlvNejqzRc2PDdFiAV9=WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZVk6IphECKLzUceP15j=WnNGfosHr5STAq8j7miwyRZ6eOUbV,EaOw4PxtyQpZXM3=WnNGfosHr5STAq8j7miwyRZ6eOUbV,rBSIjX6x2FVTgOeG4CREKfUq={}):
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('\t',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	uuSU5Awl8FNrzkXHdQDiCWq3 = uuSU5Awl8FNrzkXHdQDiCWq3.replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('\t',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if '_SCRIPT_' in fzu7Got0FgiyshTlJK:
		TTOAERW9IMB045fQt7wnjrymKZGHN,fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.split('_SCRIPT_',wnaWTQM7VJPkZzO9eoSyFU4)
		if TTOAERW9IMB045fQt7wnjrymKZGHN not in list(A3pXVFdyP1.menuItemsDICT.keys()): A3pXVFdyP1.menuItemsDICT[TTOAERW9IMB045fQt7wnjrymKZGHN] = []
		A3pXVFdyP1.menuItemsDICT[TTOAERW9IMB045fQt7wnjrymKZGHN].append([t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq])
	A3pXVFdyP1.menuItemsLIST.append([t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq])
	return
def VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(uLfP8kDpqn7KrGJYi0SEv2OIm):
	if rJ2oTLqabRtA: from html import unescape as _tgPj8ToqpJ0XlYBb
	else:
		from HTMLParser import HTMLParser as m4Z5b2slLNw0IThpJ
		_tgPj8ToqpJ0XlYBb = m4Z5b2slLNw0IThpJ().unescape
	if '&' in uLfP8kDpqn7KrGJYi0SEv2OIm and ';' in uLfP8kDpqn7KrGJYi0SEv2OIm:
		if YVzokG2yZqrh3w8bU: uLfP8kDpqn7KrGJYi0SEv2OIm = uLfP8kDpqn7KrGJYi0SEv2OIm.decode(e87cIA5vwOQLDEP1)
		uLfP8kDpqn7KrGJYi0SEv2OIm = _tgPj8ToqpJ0XlYBb(uLfP8kDpqn7KrGJYi0SEv2OIm)
		if YVzokG2yZqrh3w8bU: uLfP8kDpqn7KrGJYi0SEv2OIm = uLfP8kDpqn7KrGJYi0SEv2OIm.encode(e87cIA5vwOQLDEP1)
	return uLfP8kDpqn7KrGJYi0SEv2OIm
def clFjTSgMODe7Nq0H3Vzs(uLfP8kDpqn7KrGJYi0SEv2OIm):
	if '\\u' in uLfP8kDpqn7KrGJYi0SEv2OIm:
		if YVzokG2yZqrh3w8bU: uLfP8kDpqn7KrGJYi0SEv2OIm = uLfP8kDpqn7KrGJYi0SEv2OIm.decode('unicode_escape','ignore').encode(e87cIA5vwOQLDEP1)
		elif rJ2oTLqabRtA: uLfP8kDpqn7KrGJYi0SEv2OIm = uLfP8kDpqn7KrGJYi0SEv2OIm.encode(e87cIA5vwOQLDEP1).decode('unicode_escape','ignore')
	return uLfP8kDpqn7KrGJYi0SEv2OIm
def qjt73vfsNQZUw6(lG6bPq2fk1LKmDxcSAV7zRa4FOd,fzu7Got0FgiyshTlJK=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if not fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Label')
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(EVdNGw3APQXTfhxaHW1nRpiFkcotg,kcXMWrwiLDKeBHRsJ).replace(jrD65cZUQ8uGR0IHNCkF,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).strip(kcXMWrwiLDKeBHRsJ)
	if lG6bPq2fk1LKmDxcSAV7zRa4FOd: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace('[COLOR ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(']',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	else: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(RNWqL0gBbKOie1DxjUpzQPh9aZyHX,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(e6HEdvUcaq8Gx,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(ZTQ27jBMEeutsrSXalyb,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(x8xkFP9mq4EHpcfWCoLduhKG150,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(TTLxlKI0gNfh7FP,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(jedSoT7D2Qu,WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(w1gu8bCmYAvdjf5a,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	zP9lmkf3IU1w2vJpE46eFLyBVN = p7dwlH1PRStBgyMUW.findall('\d\d:\d\d ',fzu7Got0FgiyshTlJK,p7dwlH1PRStBgyMUW.DOTALL)
	if zP9lmkf3IU1w2vJpE46eFLyBVN: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.split(zP9lmkf3IU1w2vJpE46eFLyBVN[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],wnaWTQM7VJPkZzO9eoSyFU4)[wnaWTQM7VJPkZzO9eoSyFU4]
	if not fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = 'Main Menu'
	return fzu7Got0FgiyshTlJK
def WQzfBPt6sDuVw8N5xlcY(DKOJi9xGfeS3HVv):
	a7RsDhXiJylWGdjBEgAVPCcKOk1L = WnNGfosHr5STAq8j7miwyRZ6eOUbV.join(pMiDdTC8LUE2wIV for pMiDdTC8LUE2wIV in DKOJi9xGfeS3HVv if pMiDdTC8LUE2wIV not in '\/":*?<>|'+BeAmoNljUgrbc)
	return a7RsDhXiJylWGdjBEgAVPCcKOk1L
def FXeb4fwkiRO9v63yNQ5du(BfYlvNejqzRc2PDdFiAV9,fzu7Got0FgiyshTlJK='adilbo_HTML_encoder'):
	YUWbDcRzAJL0 = p7dwlH1PRStBgyMUW.findall(fzu7Got0FgiyshTlJK+"(.*?)/g.....(.*?)\)",BfYlvNejqzRc2PDdFiAV9,p7dwlH1PRStBgyMUW.S)
	if YUWbDcRzAJL0:
		iiXmSg2GZrEOUCsTbk9nje,whbz1Z27skPVQ0MfKuGg6mLd8A3 = YUWbDcRzAJL0[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		iiXmSg2GZrEOUCsTbk9nje = p7dwlH1PRStBgyMUW.findall("=[\r\n\s\t]+'(.*?)';", iiXmSg2GZrEOUCsTbk9nje, p7dwlH1PRStBgyMUW.S)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if iiXmSg2GZrEOUCsTbk9nje and whbz1Z27skPVQ0MfKuGg6mLd8A3:
			aUZxNrCj4sBqzfomDcWe = iiXmSg2GZrEOUCsTbk9nje.replace("'",WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace("+",WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace("\n",WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace("\r",WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			vKCqDRo2HSAFdaGm85O6u79xs = aUZxNrCj4sBqzfomDcWe.split('.')
			BfYlvNejqzRc2PDdFiAV9 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			for M1DskA64IZRerTci0 in vKCqDRo2HSAFdaGm85O6u79xs:
				U7UIA6qoaCmjNGcOu3s = uvGCPpFwVmTQ36.b64decode(M1DskA64IZRerTci0+'==').decode(e87cIA5vwOQLDEP1)
				JLUqrswB8SeTgP2 = p7dwlH1PRStBgyMUW.findall('\d+', U7UIA6qoaCmjNGcOu3s, p7dwlH1PRStBgyMUW.S)
				if JLUqrswB8SeTgP2:
					nwtZH4gymdWS9eTCjUcY = int(JLUqrswB8SeTgP2[j0jEZgiKdxFpMLHcU7kQr8v1lyX4])
					nwtZH4gymdWS9eTCjUcY += int(whbz1Z27skPVQ0MfKuGg6mLd8A3)
					BfYlvNejqzRc2PDdFiAV9 = BfYlvNejqzRc2PDdFiAV9 + chr(nwtZH4gymdWS9eTCjUcY)
			if rJ2oTLqabRtA: BfYlvNejqzRc2PDdFiAV9 = BfYlvNejqzRc2PDdFiAV9.encode('iso-8859-1').decode(e87cIA5vwOQLDEP1)
	return BfYlvNejqzRc2PDdFiAV9
def k48KRn0Q5mSWpjswGaeYAvHuLbP2(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f,Dj0qYc573K2aQ,z6PVkLf7Od,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe):
	TrRx8dUfFoWv = int(Dj0qYc573K2aQ%10)
	J5JYWPRlDouCt = int(Dj0qYc573K2aQ/10)
	y6epqbJCBX = G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,WnNGfosHr5STAq8j7miwyRZ6eOUbV,AUBZYG84NbOKsRnxi6jgk2f
	DCauiOrxqK794Bfg1p2 = G3yDpvxOiSWdAeL.getSetting('av.status.menuscache')
	if not DCauiOrxqK794Bfg1p2: G3yDpvxOiSWdAeL.setSetting('av.status.menuscache','AUTO')
	rLEuTzBs2HFXjeSyfvCZcQw4O = G3yDpvxOiSWdAeL.getSetting('av.status.refresh')
	OCVUomhFsnctQJS8 = Ye7QMduPDEiphaUy5R9OVSIgx(z6PVkLf7Od)
	ikDMcFQO47ea2Jr1PGBUSg = [j0jEZgiKdxFpMLHcU7kQr8v1lyX4,15,17,19,26,34,50,53]
	oqwvpDF0UXHV = J5JYWPRlDouCt not in ikDMcFQO47ea2Jr1PGBUSg
	fpUbDt5FQw1CAEGIq = J5JYWPRlDouCt in [23,28,71,72]
	w0PIWdzVuHKplm6yeF4kSG8MUbfRC = Dj0qYc573K2aQ in [265,270]
	TzjFJvgAZwrhHSln8b9i6u07NWym = (oqwvpDF0UXHV or fpUbDt5FQw1CAEGIq) and not w0PIWdzVuHKplm6yeF4kSG8MUbfRC
	vmn8q9WCMALIylTcYE40kxKgZXfG = (rLEuTzBs2HFXjeSyfvCZcQw4O or not SDUJm78sZBG) and rLEuTzBs2HFXjeSyfvCZcQw4O not in ['REFRESH_CACHE']+ffYFH1jX8B24iv6RGrQc
	pFiXLQCZfuwS1WKERaVvx = 'type=' in rLEuTzBs2HFXjeSyfvCZcQw4O
	jeQqkmgpz1 = Dj0qYc573K2aQ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	WmxfGFqceOyUtLT = TrRx8dUfFoWv==9 or Dj0qYc573K2aQ in [145,516,523,45]
	ulVFdQSn9H3NA1q7OMY = not jeQqkmgpz1
	cDbQhKvH9eWOBAV5UmR = not WmxfGFqceOyUtLT
	WWn7LdthoSDVEysO3BZM8jgUx = OCVUomhFsnctQJS8 in [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'..']
	J2cmvFnfK61l8GQRu73D0XE5YjO9 = WWn7LdthoSDVEysO3BZM8jgUx or ulVFdQSn9H3NA1q7OMY
	YF3d5ajQIosHP = WWn7LdthoSDVEysO3BZM8jgUx or cDbQhKvH9eWOBAV5UmR or pFiXLQCZfuwS1WKERaVvx
	TUsP39MSVqEG6kKdXA = Dj0qYc573K2aQ not in [260,261,265,270,330,536,537,538,540,1010,1101,1103]
	if DCauiOrxqK794Bfg1p2=='STOP': zrpNMlF0Ge = WmxfGFqceOyUtLT or jeQqkmgpz1
	else: zrpNMlF0Ge = r0D4C3z7Onqpa
	W8GENrdi3P50au = J5JYWPRlDouCt in [74,75,108]
	okZ8i3SWVlCAscXB6enEa2p1 = Dj0qYc573K2aQ in [280,720]
	n9R6Ppi8LzJqFcb4a7uIf1wQ2 = not W8GENrdi3P50au and not okZ8i3SWVlCAscXB6enEa2p1
	wj89Mb43RINuAg6 = J2cmvFnfK61l8GQRu73D0XE5YjO9 and YF3d5ajQIosHP and TUsP39MSVqEG6kKdXA and zrpNMlF0Ge and n9R6Ppi8LzJqFcb4a7uIf1wQ2
	HLOSzwfCPxmU4d98r = TUsP39MSVqEG6kKdXA and zrpNMlF0Ge and n9R6Ppi8LzJqFcb4a7uIf1wQ2
	rknaV25XxOA0 = HLOSzwfCPxmU4d98r
	NBuT5Gto4H1j6zwyYaIim2 = G3yDpvxOiSWdAeL.getSetting('av.language.provider')
	lKoR0NitVskuJc69Dm = G3yDpvxOiSWdAeL.getSetting('av.language.code')
	JnmTcpHY2vrQ16uG7CMsDFEOe8I = KiryBCvngZzF85UN6xSDlOVweL4I9
	if vmn8q9WCMALIylTcYE40kxKgZXfG and wj89Mb43RINuAg6:
		h7keK5CIOgG2ZAE0VJTurFs = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,'list','MENUS_CACHE_'+NBuT5Gto4H1j6zwyYaIim2+'_'+lKoR0NitVskuJc69Dm,y6epqbJCBX)
		if h7keK5CIOgG2ZAE0VJTurFs:
			SWPHEjbmMfZDpi(WnNGfosHr5STAq8j7miwyRZ6eOUbV,'.\tMENUS_CACHE_'+NBuT5Gto4H1j6zwyYaIim2+'_'+lKoR0NitVskuJc69Dm+'   Loading menu from cache')
			if pFiXLQCZfuwS1WKERaVvx:
				qDdLV87jSz = []
				from cl1aVJLDm2 import GkhP7zZpoFUDu
				from zQ1YjoMLiN import yyQrnbKfzwMi,Ut60yQZszi2cVO3geI4XdLjKRE7bG
				GujPZ1BacfgSLeI8kpX = GkhP7zZpoFUDu
				WaMbdyAw8z65C = yyQrnbKfzwMi()
				R2NeGlt8cqsQ5nrHo = rLEuTzBs2HFXjeSyfvCZcQw4O
				wsGmDEX0IcnoWdH1ApU8,ua0q6ZR8snhFdp,CyTapoeMLAZfR4zQkiO,wztyhTje91PNGLfsd3qOAJxa0,QaSrN63TchojA,d2oglemEBRbcVUGKTzZH,QS52otZBnqLfbXO9W1r6w0E,UzG3Q1Tqclj76FxfEaMNRX,f5UK0kejROLDzcg6w1 = UbF7JxE84r2D(R2NeGlt8cqsQ5nrHo)
				ku2ldf6yOCV8PZL1 = wsGmDEX0IcnoWdH1ApU8,ua0q6ZR8snhFdp,CyTapoeMLAZfR4zQkiO,wztyhTje91PNGLfsd3qOAJxa0,QaSrN63TchojA,d2oglemEBRbcVUGKTzZH,QS52otZBnqLfbXO9W1r6w0E,WnNGfosHr5STAq8j7miwyRZ6eOUbV,f5UK0kejROLDzcg6w1
				for i0MvNja5wzptA in h7keK5CIOgG2ZAE0VJTurFs:
					q14Uwnm65btk0P3O = i0MvNja5wzptA['menuItem']
					if q14Uwnm65btk0P3O==ku2ldf6yOCV8PZL1 or i0MvNja5wzptA['mode'] in [265,270]:
						i0MvNja5wzptA = KUC8lG5Yd0uRgj(q14Uwnm65btk0P3O,GujPZ1BacfgSLeI8kpX,WaMbdyAw8z65C)
						if i0MvNja5wzptA['favorites']:
							eJ4oCqQynXtD6KFl2Rk5VgG = Ut60yQZszi2cVO3geI4XdLjKRE7bG(WaMbdyAw8z65C,q14Uwnm65btk0P3O,i0MvNja5wzptA['newpath'])
							i0MvNja5wzptA['context_menu'] = eJ4oCqQynXtD6KFl2Rk5VgG+i0MvNja5wzptA['context_menu']
					qDdLV87jSz.append(i0MvNja5wzptA)
				G3yDpvxOiSWdAeL.setSetting('av.status.refresh',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				if G3Xh0YWACHFuvQLx5sVEfPjzq7=='folder': w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,'MENUS_CACHE_'+NBuT5Gto4H1j6zwyYaIim2+'_'+lKoR0NitVskuJc69Dm,y6epqbJCBX,qDdLV87jSz,nsFAzS2wvjyTYLOdDhfIiC0KGHE)
			else: qDdLV87jSz = h7keK5CIOgG2ZAE0VJTurFs
			if G3Xh0YWACHFuvQLx5sVEfPjzq7=='folder' and OCVUomhFsnctQJS8!='..' and TzjFJvgAZwrhHSln8b9i6u07NWym: OE38lVnF9jRGUAXPzoLIecvMHp()
			JnmTcpHY2vrQ16uG7CMsDFEOe8I = U1jrPe7mLiHwgaZn4GlJXp(y6epqbJCBX,qDdLV87jSz,FDZrNEmQSHB35W2VwAJ8Pt19CjLfYy,apvSg9k5RKFxsXYzUOb,CgpXU6iroPzSbJZe)
	elif G3Xh0YWACHFuvQLx5sVEfPjzq7=='folder' and rLEuTzBs2HFXjeSyfvCZcQw4O not in ['REFRESH_CACHE']+ffYFH1jX8B24iv6RGrQc and HLOSzwfCPxmU4d98r:
		sA8uj5gVrSnWxNOKicToeHb3MY(p9DTgUZ1auwRYXoHld7v8MP,'MENUS_CACHE_'+NBuT5Gto4H1j6zwyYaIim2+'_'+lKoR0NitVskuJc69Dm,y6epqbJCBX)
	return JnmTcpHY2vrQ16uG7CMsDFEOe8I,rLEuTzBs2HFXjeSyfvCZcQw4O,y6epqbJCBX,OCVUomhFsnctQJS8,TzjFJvgAZwrhHSln8b9i6u07NWym,rknaV25XxOA0,NBuT5Gto4H1j6zwyYaIim2,lKoR0NitVskuJc69Dm
def NNFPsWDgoE(G3Xh0YWACHFuvQLx5sVEfPjzq7,VkEQdztnmeH,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f):
	Dj0qYc573K2aQ = int(e8T0bmWuCBZ4D3xJnPdRt1HgNi9YE)
	J5JYWPRlDouCt = int(Dj0qYc573K2aQ//10)
	if   J5JYWPRlDouCt==j0jEZgiKdxFpMLHcU7kQr8v1lyX4:  from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==wnaWTQM7VJPkZzO9eoSyFU4:  from vHV9gRTNKP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==XURrDCfOS9Mbhpv2Pmjos56TeW:  from bCNf7O8iTI 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==vXIdY7TwFKso40gVBq5:  from PjfoK5AGFZ 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==yGLl1nSBrJPmi2adko9O:  from TOCi1blMFp 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,TB3DI4JWr0NYmik1xO8Kc2)
	elif J5JYWPRlDouCt==EEowc8rs5gUZTVjdOzmb0nu:  from V3InR4wf2B 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==6:  from eW3ZydnAi2 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==7:  from IsHuZ0qpPT 			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==8:  from PnGsJw3SFB 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==9:  from Hiza5DZJEr		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==10: from rvzPVNjLxS 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	elif J5JYWPRlDouCt==11: from Ym6QVM1qai 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==12: from aaRwAVNtIH 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==13: from AiKLdU9Wky		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==14: from pOtaEIAv5o 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2,VkEQdztnmeH,bLhqw36zAp7uKxJIM4r502UGRT)
	elif J5JYWPRlDouCt==15: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==16: from jeQqkmgpz1		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==17: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==18: from CdnBRtu2eE		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==19: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==20: from DvjdSTt7qW		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==21: from vTi9bK5rJc	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==22: from zaMV3OKgc0		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==23: from e06e8au2ZV			import uWyz2Omi3rGH9vsfTDg; APpdhB1Fk58MmJH7CjVntowyaY = uWyz2Omi3rGH9vsfTDg(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==24: from iiy8cVF7db 			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==25: from nrd8U1RKu6 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==26: from cl1aVJLDm2 			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==27: from zQ1YjoMLiN		import uWyz2Omi3rGH9vsfTDg; APpdhB1Fk58MmJH7CjVntowyaY = uWyz2Omi3rGH9vsfTDg(Dj0qYc573K2aQ,SDUJm78sZBG)
	elif J5JYWPRlDouCt==28: from e06e8au2ZV			import uWyz2Omi3rGH9vsfTDg; APpdhB1Fk58MmJH7CjVntowyaY = uWyz2Omi3rGH9vsfTDg(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==29: from BBGbk0UjSV	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==30: from UhA459zcSm		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==31: from zzEgv8ewY3		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==32: from XtYvZDPwQi		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==33: from ZZYmwuStjk		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA)
	elif J5JYWPRlDouCt==34: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==35: from HhTRf43jBE		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==36: from NNaWlnOxMy			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==37: from rqvKs7u3yN			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==38: from G8EoMZwSa0 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==39: from Y6gzSMvWmk		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==40: from tHfKLiFmz4	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2)
	elif J5JYWPRlDouCt==41: from tHfKLiFmz4	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2)
	elif J5JYWPRlDouCt==42: from dqwV0sDIuE			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==43: from KSvkoWfe9l			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==44: from Y1lb7kUoqW		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==45: from HFTS2bGIhV		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==46: from akm7Olewy1			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==47: from w9rdylLDsa		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==48: from ifod8xX7ma		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==49: from REfPWC2K6J		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==50: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==51: from WVIGahw4HT 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==52: from WVIGahw4HT 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==53: from cl1aVJLDm2 			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==54: from IV2oTbWpv9	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,TB3DI4JWr0NYmik1xO8Kc2)
	elif J5JYWPRlDouCt==55: from nnXWjdor7G 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==56: from UA6tWv1J4F		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==57: from HvVudtEb6R		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==58: from kpBgcTzUjY		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==59: from RDEvoJlsUX		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==60: from q0JxEBGdOc			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==61: from epnqOQtVjL			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==62: from XxKOrN3Lvq		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==63: from gljKSUf8hu	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==64: from M6w2Wug34l			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==65: from lr6NIiBsem			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==66: from W3vrGLQYf2			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==67: from CJvZbAdIpH		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==68: from yubJEvNZCx		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==69: from IYw85cPR4z		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==70: from b5GlsiO6d2			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==71: from aEzp4cq7nd			import uWyz2Omi3rGH9vsfTDg; APpdhB1Fk58MmJH7CjVntowyaY = uWyz2Omi3rGH9vsfTDg(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==72: from aEzp4cq7nd			import uWyz2Omi3rGH9vsfTDg; APpdhB1Fk58MmJH7CjVntowyaY = uWyz2Omi3rGH9vsfTDg(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,G3Xh0YWACHFuvQLx5sVEfPjzq7,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==73: from dc7hylBaM1	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==74: from nYo8LPm5is		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ)
	elif J5JYWPRlDouCt==75: from nYo8LPm5is		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ)
	elif J5JYWPRlDouCt==76: from jeQqkmgpz1		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f)
	elif J5JYWPRlDouCt==77: from JdUBjazqsO 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==78: from VUykxqsjMG 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==79: from U7XDKi5njM 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==80: from CduqENMtf8 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==81: from ZZGlVNYbaT 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==82: from nMWqebA3wf		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,TB3DI4JWr0NYmik1xO8Kc2,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==83: from eOf1YMWBQo		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==84: from MNzW38k2cb		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==85: from f8gYzE63PQ		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==86: from vA4LkIGtNE		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==87: from EbgxYdLZWC			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==88: from pWqmnKDbuz			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==89: from eInYlC1HXO		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==90: from YZ9TFMPDvA	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==91: from OLcMFtvCq5		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==92: from ruPMYxFthg		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==93: from jjw7ER4tri		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==94: from s93XE2Qmi6			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==95: from vvblHILt7Q			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==96: from lBkjWEAKMY		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==97: from EV4cUrZked		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==98: from ehaZP4z6ck		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==99: from jKcEAqndg7		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==100: from ZieJc3z9E2		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==101: from H2mc5EFGK0	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==102: from GkCs6wbiQP 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==103: from NNlGvMjJQY	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==104: from uumWPCkHtz		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==105: from OaX3K08oLW			import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==106: from e5RcmyiNnX		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==107: from WWtPR05mIN		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==108: from nYo8LPm5is		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ)
	elif J5JYWPRlDouCt==109: from e9WAyXqHsM 	import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	elif J5JYWPRlDouCt==110: from cl1aVJLDm2 		import CQdJAeGfyc6z9bnLDwXsu4mW	; APpdhB1Fk58MmJH7CjVntowyaY = CQdJAeGfyc6z9bnLDwXsu4mW(Dj0qYc573K2aQ,kdNn2Zqsj4wPi5ThuoUQvtcg6OA,HvzeZpTRrx9j1hMBV3)
	else: APpdhB1Fk58MmJH7CjVntowyaY = None
	return APpdhB1Fk58MmJH7CjVntowyaY