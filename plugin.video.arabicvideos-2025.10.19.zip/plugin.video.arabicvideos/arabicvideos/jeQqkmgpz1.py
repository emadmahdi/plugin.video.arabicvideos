# -*- coding: utf-8 -*-
import sys as SZ0YL6RpbX
ghR40GPlFEKcxsDMC = SZ0YL6RpbX.version_info [0] == 2
YYmRbSOy1TiH = 2048
vFhZTYJaykUxIOCodb7cB8NguwP = 7
def WNORxflXvAQEu8L (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3):
	global qCSVbtpf76Eunhy0jLs
	qcgxpt6musF93lXfWVP7NQSZHLDb = ord (bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [-1])
	PgSZ1cEaYAFo0s = bUXEFKnLB07PG9QjCkNaxTqvdpuVg3 [:-1]
	QZMPUYxqTmzwekRG2aHJX6pcstO8j = qcgxpt6musF93lXfWVP7NQSZHLDb % len (PgSZ1cEaYAFo0s)
	CRcZgfLIwQphSF8dN = PgSZ1cEaYAFo0s [:QZMPUYxqTmzwekRG2aHJX6pcstO8j] + PgSZ1cEaYAFo0s [QZMPUYxqTmzwekRG2aHJX6pcstO8j:]
	if ghR40GPlFEKcxsDMC:
		MmCfbKxkt0Oy = unicode () .join ([unichr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	else:
		MmCfbKxkt0Oy = str () .join ([chr (ord (hjFqB173eySIkGCY8Dncb6Ll) - YYmRbSOy1TiH - (alxzEjoT9BFgOVP + qcgxpt6musF93lXfWVP7NQSZHLDb) % vFhZTYJaykUxIOCodb7cB8NguwP) for alxzEjoT9BFgOVP, hjFqB173eySIkGCY8Dncb6Ll in enumerate (CRcZgfLIwQphSF8dN)])
	return eval (MmCfbKxkt0Oy)
GHg28TBchiyn6l,XwYZoICi4pSQ0Ousm6JGtcdzVB,yobpaW7sBqtKRrv=WNORxflXvAQEu8L,WNORxflXvAQEu8L,WNORxflXvAQEu8L
gPE1XB87fQl,QQH5IeP4UuCAp1VwKDLxEWrvjFc,aiQwFE1TGx04vmLcsYkIW5jA=yobpaW7sBqtKRrv,XwYZoICi4pSQ0Ousm6JGtcdzVB,GHg28TBchiyn6l
YYQS36fyPvtuzcEmRL,jhDZ0BAFoEGUcw5QrJkaxXL,beV5l2D8HznyJI0=aiQwFE1TGx04vmLcsYkIW5jA,QQH5IeP4UuCAp1VwKDLxEWrvjFc,gPE1XB87fQl
aPpWCJYFzeijsDN6Txl7Mqth3ry5,wwWzyF4ZpSQXKOgk569,IMjqygdfYSKpHlWu5Aa=beV5l2D8HznyJI0,jhDZ0BAFoEGUcw5QrJkaxXL,YYQS36fyPvtuzcEmRL
I872Vum45fMNe1BRngTZLoQiqvkt,KLX7hW0nBAEgy6m4SvH,n1JzUNV2FIKgpMvQo6hcA578uZqrX=IMjqygdfYSKpHlWu5Aa,wwWzyF4ZpSQXKOgk569,aPpWCJYFzeijsDN6Txl7Mqth3ry5
lzSXWkhtdnu5sr3U8AV42vwDJ7ip,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,oiWNFYzcIUeh=n1JzUNV2FIKgpMvQo6hcA578uZqrX,KLX7hW0nBAEgy6m4SvH,I872Vum45fMNe1BRngTZLoQiqvkt
mq5t9JXSdHT8yfDVF,bawK2j7T81Nrc4GWs05xzDg,iySORMYxWXszEH18=oiWNFYzcIUeh,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN,lzSXWkhtdnu5sr3U8AV42vwDJ7ip
rVy3Ops0mohYkT,A41nqbj3wYt,tzZ6PhyDOUnwLM3pdK=iySORMYxWXszEH18,bawK2j7T81Nrc4GWs05xzDg,mq5t9JXSdHT8yfDVF
pp7FcjEe6g,Z9FPQvwlbjLTh,CyHU86ZeYT5BWRcitSm2I=tzZ6PhyDOUnwLM3pdK,A41nqbj3wYt,rVy3Ops0mohYkT
kdRO82AImh0LFw,A6iX18qgyOFlZxz7sc,eUYX1LQCSJyNZtMsukTBhA4cfj=CyHU86ZeYT5BWRcitSm2I,Z9FPQvwlbjLTh,pp7FcjEe6g
VP70ytiFNMBl6vHDaW,ZLr5gRSkFewKdUos90bM,SI7eBdND4lx8pt5Qk=eUYX1LQCSJyNZtMsukTBhA4cfj,A6iX18qgyOFlZxz7sc,kdRO82AImh0LFw
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = tzZ6PhyDOUnwLM3pdK(u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ᱀")
uBQ9txp0gDrEhZTcJOi74SKVw3k = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡢࡐࡘ࡚࡟ࠨ᱁")
w7XRmZonrby = yGLl1nSBrJPmi2adko9O
G5FBKAhdbuEC = IMjqygdfYSKpHlWu5Aa(u"࠶࠶Ậ")
def CQdJAeGfyc6z9bnLDwXsu4mW(HOkAWvmZSP5c2t9Dq4NgELyps,url,ZVk6IphECKLzUceP15j,TB3DI4JWr0NYmik1xO8Kc2,AUBZYG84NbOKsRnxi6jgk2f):
	try: A2N8BQZTY4p6XKygzOl7nD = str(AUBZYG84NbOKsRnxi6jgk2f[QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱂")])
	except: A2N8BQZTY4p6XKygzOl7nD = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if   HOkAWvmZSP5c2t9Dq4NgELyps==jhDZ0BAFoEGUcw5QrJkaxXL(u"࠷࠶࠱ậ"): APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==wwWzyF4ZpSQXKOgk569(u"࠱࠷࠳Ắ"): APpdhB1Fk58MmJH7CjVntowyaY = HhMmwBAs5zV6D429cI7TE(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠲࠸࠵ắ"): APpdhB1Fk58MmJH7CjVntowyaY = lOZwj39W8eVGp7QsN5oShIMtU4X(ZVk6IphECKLzUceP15j,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠲࠸࠵ắ"))
	elif HOkAWvmZSP5c2t9Dq4NgELyps==CyHU86ZeYT5BWRcitSm2I(u"࠳࠹࠷Ằ"): APpdhB1Fk58MmJH7CjVntowyaY = lOZwj39W8eVGp7QsN5oShIMtU4X(ZVk6IphECKLzUceP15j,CyHU86ZeYT5BWRcitSm2I(u"࠳࠹࠷Ằ"))
	elif HOkAWvmZSP5c2t9Dq4NgELyps==tzZ6PhyDOUnwLM3pdK(u"࠴࠺࠹ằ"): APpdhB1Fk58MmJH7CjVntowyaY = KKjWJk8dUEhOn(ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==gPE1XB87fQl(u"࠵࠻࠻Ẳ"): APpdhB1Fk58MmJH7CjVntowyaY = mHMEFDYXfybhRdNnwO0SQTu(url,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠶࠼࠶ẳ"): APpdhB1Fk58MmJH7CjVntowyaY = x9dBRbVYnC(url,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==I872Vum45fMNe1BRngTZLoQiqvkt(u"࠷࠶࠸Ẵ"): APpdhB1Fk58MmJH7CjVntowyaY = Z3nbgCzLMXBm1yuGv5HQ9p(url,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠱࠷࠺ẵ"): APpdhB1Fk58MmJH7CjVntowyaY = EH0i2xfRJX4jeDUN18nGgCuBAWhMK(url,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==yobpaW7sBqtKRrv(u"࠸࠸࠴Ặ"): APpdhB1Fk58MmJH7CjVntowyaY = AS1itTD5jbKenw0()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==Z9FPQvwlbjLTh(u"࠹࠹࠶ặ"): APpdhB1Fk58MmJH7CjVntowyaY = XALY6d7MnUS1Nfjw()
	elif HOkAWvmZSP5c2t9Dq4NgELyps==n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠺࠺࠸Ẹ"): APpdhB1Fk58MmJH7CjVntowyaY = Fr4Dm0py79XjLSAlTvegkZQow(A2N8BQZTY4p6XKygzOl7nD,ZVk6IphECKLzUceP15j,TB3DI4JWr0NYmik1xO8Kc2)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==GHg28TBchiyn6l(u"࠻࠻࠺ẹ"): APpdhB1Fk58MmJH7CjVntowyaY = d3d6KCgxpBTZSHG1cvMWlVeky2(A2N8BQZTY4p6XKygzOl7nD,ZVk6IphECKLzUceP15j)
	elif HOkAWvmZSP5c2t9Dq4NgELyps==iySORMYxWXszEH18(u"࠼࠼࠵Ẻ"): APpdhB1Fk58MmJH7CjVntowyaY = Fy7ChzgQx1NAvK2DU0YLqerWpcE(A2N8BQZTY4p6XKygzOl7nD,ZVk6IphECKLzUceP15j)
	else: APpdhB1Fk58MmJH7CjVntowyaY = KiryBCvngZzF85UN6xSDlOVweL4I9
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL(SI7eBdND4lx8pt5Qk(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᱃"),iySORMYxWXszEH18(u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭᱄"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"࠷࠶࠲ẻ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᱅"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(A41nqbj3wYt(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᱆"),KLX7hW0nBAEgy6m4SvH(u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ᱇"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,Z9FPQvwlbjLTh(u"࠱࠷࠴Ẽ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱈"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱉"),YYQS36fyPvtuzcEmRL(u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ᱊"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠲࠸࠶ẽ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᱋"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᱌"),KLX7hW0nBAEgy6m4SvH(u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭ᱍ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠹࠸Ế"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱎ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(A41nqbj3wYt(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱏ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᱐"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠺࠺࠸ế"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭᱑"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(kdRO82AImh0LFw(u"ࠬࡲࡩ࡯࡭ࠪ᱒"),e6HEdvUcaq8Gx+wwWzyF4ZpSQXKOgk569(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᱓")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠽࠾࠿࠹Ề"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᱔"),mq5t9JXSdHT8yfDVF(u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ᱕"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠶࠼࠳ề"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᱖"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(kdRO82AImh0LFw(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱗"),Z9FPQvwlbjLTh(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ᱘"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠷࠶࠴Ể"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱙"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(GHg28TBchiyn6l(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱚ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧใี่ࠤ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧᱛ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,iySORMYxWXszEH18(u"࠱࠷࠴ể"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱜ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱝ"),wwWzyF4ZpSQXKOgk569(u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪᱞ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"࠲࠸࠵Ễ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱟ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(IMjqygdfYSKpHlWu5Aa(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱠ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩᱡ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"࠳࠹࠸ễ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱢ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱣ"),tzZ6PhyDOUnwLM3pdK(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᱤ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠺࠺࠺Ệ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱥ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(KLX7hW0nBAEgy6m4SvH(u"ࠫࡱ࡯࡮࡬ࠩᱦ"),e6HEdvUcaq8Gx+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᱧ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"࠽࠾࠿࠹ệ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(SI7eBdND4lx8pt5Qk(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱨ"),iySORMYxWXszEH18(u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬᱩ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"࠶࠼࠳Ỉ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱪ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱫ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᱬ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"࠷࠶࠴ỉ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱭ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱮ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧᱯ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"࠱࠷࠴Ị"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A6iX18qgyOFlZxz7sc(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱰ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(KLX7hW0nBAEgy6m4SvH(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱱ"),CyHU86ZeYT5BWRcitSm2I(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪᱲ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"࠲࠸࠵ị"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱳ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᱴ"),kdRO82AImh0LFw(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥฮอฬࠢ฼ุํอฦ๋ࠩᱵ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠳࠹࠸Ọ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱶ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(wwWzyF4ZpSQXKOgk569(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱷ"),ZLr5gRSkFewKdUos90bM(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᱸ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"࠺࠺࠹ọ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱹ"))
	return
def AS1itTD5jbKenw0():
	octplHnGwmE8bFqNdj7BiKvJ0VL(beV5l2D8HznyJI0(u"ࠪࡪࡴࡲࡤࡦࡴࠪᱺ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡤࡏࡐࡕࡡࠪᱻ")+mq5t9JXSdHT8yfDVF(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪᱼ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠻࠻࠺Ỏ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(aiQwFE1TGx04vmLcsYkIW5jA(u"࠭࡬ࡪࡰ࡮ࠫᱽ"),e6HEdvUcaq8Gx+aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᱾")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"࠾࠿࠹࠺ỏ"))
	for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
		uBQ9txp0gDrEhZTcJOi74SKVw3k = YYQS36fyPvtuzcEmRL(u"ࠨࡡࡌࡔࠬ᱿")+str(A2N8BQZTY4p6XKygzOl7nD)+bawK2j7T81Nrc4GWs05xzDg(u"ࠩࡢࠫᲀ")
		octplHnGwmE8bFqNdj7BiKvJ0VL(gPE1XB87fQl(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲁ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+wwWzyF4ZpSQXKOgk569(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᲂ")+ww07SKUt2HgnRG[A2N8BQZTY4p6XKygzOl7nD],WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"࠽࠶࠵Ố"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{A6iX18qgyOFlZxz7sc(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲃ"):A2N8BQZTY4p6XKygzOl7nD})
	return
def XALY6d7MnUS1Nfjw():
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᲄ"),iySORMYxWXszEH18(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᲅ")+A6iX18qgyOFlZxz7sc(u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬᲆ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,aiQwFE1TGx04vmLcsYkIW5jA(u"࠷࠷࠷ố"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(rVy3Ops0mohYkT(u"ࠩ࡯࡭ࡳࡱࠧᲇ"),e6HEdvUcaq8Gx+ZLr5gRSkFewKdUos90bM(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᲈ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"࠺࠻࠼࠽Ồ"))
	for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
		uBQ9txp0gDrEhZTcJOi74SKVw3k = eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡤࡓࡕࠨᲉ")+str(A2N8BQZTY4p6XKygzOl7nD)+A6iX18qgyOFlZxz7sc(u"ࠬࡥࠧᲊ")
		octplHnGwmE8bFqNdj7BiKvJ0VL(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲋"),uBQ9txp0gDrEhZTcJOi74SKVw3k+aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ᲌")+ww07SKUt2HgnRG[A2N8BQZTY4p6XKygzOl7nD],WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠹࠹࠹ồ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{rVy3Ops0mohYkT(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᲍"):A2N8BQZTY4p6XKygzOl7nD})
	return
def qIVZvpbTw1xkSHaFElXe3Pd(OOG1iPYhTKQ4):
	global jZyaRkNnXHD6dVw4eQzUWvP1,AIBc7QYUKp
	PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
	try:
		if pp7FcjEe6g(u"ࠩࡌࡊࡎࡒࡍࠨ᲎") in OOG1iPYhTKQ4: PVIqN8MGBf7DX3TjdA1Qh9gOU(OOG1iPYhTKQ4)
		else: PVIqN8MGBf7DX3TjdA1Qh9gOU()
		O0wjlJq2ViGH4ZbW8R3T = KiryBCvngZzF85UN6xSDlOVweL4I9
	except:
		JLyFwgKhoPdND9cMk()
		O0wjlJq2ViGH4ZbW8R3T = r0D4C3z7Onqpa
	OOG1iPYhTKQ4 = v2oRq5AhQzcx(OOG1iPYhTKQ4)
	if O0wjlJq2ViGH4ZbW8R3T:
		uTaiRMI8eYmN(OOG1iPYhTKQ4,pp7FcjEe6g(u"ࠪๅู๊ࠠๅๆฦืๆ࠭᲏"),x54xSdnCFHZ8yliofzOBK=Z9FPQvwlbjLTh(u"࠵࠴࠵࠶Ổ"))
		jZyaRkNnXHD6dVw4eQzUWvP1 += wnaWTQM7VJPkZzO9eoSyFU4
		AIBc7QYUKp += gPE1XB87fQl(u"ࠫࠥ࠴ࠠࠨᲐ")+OOG1iPYhTKQ4
	else: uTaiRMI8eYmN(OOG1iPYhTKQ4,WnNGfosHr5STAq8j7miwyRZ6eOUbV,x54xSdnCFHZ8yliofzOBK=bawK2j7T81Nrc4GWs05xzDg(u"࠵࠵࠶࠰ổ"))
	return
exHviu6hcwoQRqTS4BbyYM7 = {}
def TZxWMi4Ht7E3U(kPBM0cr7Q8lzHhODSR=r0D4C3z7Onqpa):
	global jZyaRkNnXHD6dVw4eQzUWvP1,AIBc7QYUKp,exHviu6hcwoQRqTS4BbyYM7
	if not kPBM0cr7Q8lzHhODSR:
		exHviu6hcwoQRqTS4BbyYM7 = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,pp7FcjEe6g(u"ࠬࡪࡩࡤࡶࠪᲑ"),KLX7hW0nBAEgy6m4SvH(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧᲒ"),mq5t9JXSdHT8yfDVF(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬᲓ"))
		if exHviu6hcwoQRqTS4BbyYM7: return
	kkLdeyJUsSiK9YwFZr4lPbVE = TPNsmjik1eh4Wc(mq5t9JXSdHT8yfDVF(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᲔ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,A6iX18qgyOFlZxz7sc(u"ࠩะฮ๎ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱࠲ู๊ࠥโฯุࠤฬ๊ศา่ส้ัࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰࠱ࠤ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࡝ࡰ࡟ࡲࠬᲕ")+e6HEdvUcaq8Gx+mq5t9JXSdHT8yfDVF(u"๋้ࠪࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬᲖ")+YVr6St5P4xsFC0aARQGKfiegD)
	if kkLdeyJUsSiK9YwFZr4lPbVE!=wnaWTQM7VJPkZzO9eoSyFU4: return
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd,z8WclmVQpLo1Hw2beGYjC4griSd)
	DPTi8LJGhjsxy4 = A3pXVFdyP1.menuItemsLIST
	jZyaRkNnXHD6dVw4eQzUWvP1,AIBc7QYUKp,threads = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{}
	for OOG1iPYhTKQ4 in m06yjkDU4wEipZ7QWrsLdfKbn:
		x54xSdnCFHZ8yliofzOBK.sleep(wnaWTQM7VJPkZzO9eoSyFU4)
		threads[OOG1iPYhTKQ4] = vpPaQ6ewzRTEK(daemon=r0D4C3z7Onqpa,target=qIVZvpbTw1xkSHaFElXe3Pd,args=(OOG1iPYhTKQ4,))
		threads[OOG1iPYhTKQ4].start()
	else:
		for OOG1iPYhTKQ4 in list(threads.keys()): threads[OOG1iPYhTKQ4].join()
	A3pXVFdyP1.menuItemsLIST[:] = DPTi8LJGhjsxy4
	exHviu6hcwoQRqTS4BbyYM7 = {}
	for OOG1iPYhTKQ4 in list(threads.keys()):
		try: t90LeAoHSCZz6 = A3pXVFdyP1.menuItemsDICT[OOG1iPYhTKQ4]
		except: continue
		OOG1iPYhTKQ4 = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡤࡒࡓࡕࡡࠪᲗ")+v2oRq5AhQzcx(OOG1iPYhTKQ4)
		for t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq in t90LeAoHSCZz6:
			if not fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = yobpaW7sBqtKRrv(u"ࠬ࠴࠮࠯࠰ࠪᲘ")
			else:
				if fzu7Got0FgiyshTlJK.count(wwWzyF4ZpSQXKOgk569(u"࠭࡟ࠨᲙ"))>wnaWTQM7VJPkZzO9eoSyFU4: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.split(SI7eBdND4lx8pt5Qk(u"ࠧࡠࠩᲚ"),XURrDCfOS9Mbhpv2Pmjos56TeW)[XURrDCfOS9Mbhpv2Pmjos56TeW]
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(wwWzyF4ZpSQXKOgk569(u"ࠨࢢࠪᲛ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࠣࡌࡉ࠭Ნ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(SI7eBdND4lx8pt5Qk(u"ࠪࡌࡉࠦࠧᲝ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫๅ࠭Პ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(oiWNFYzcIUeh(u"ࠬฯࠧᲟ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭็ࠨᲠ")).replace(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧลࠩᲡ"),Z9FPQvwlbjLTh(u"ࠨ๊ࠪᲢ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩฦࠫᲣ"),wwWzyF4ZpSQXKOgk569(u"ࠪหࠬᲤ")).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫส࠭Ქ"),oiWNFYzcIUeh(u"ࠬอࠧᲦ")).replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭ยࠨᲧ"),wwWzyF4ZpSQXKOgk569(u"ࠧศࠩᲨ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(ZLr5gRSkFewKdUos90bM(u"ࠨๆฦࠫᲩ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩ็หࠬᲪ")).replace(VP70ytiFNMBl6vHDaW(u"่ࠪส࠭Ძ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"้ࠫอࠧᲬ")).replace(bawK2j7T81Nrc4GWs05xzDg(u"๊ࠬยࠨᲭ"),ZLr5gRSkFewKdUos90bM(u"࠭ไศࠩᲮ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(iySORMYxWXszEH18(u"ࠧ๏ࠩᲯ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨํࠪᲰ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(VP70ytiFNMBl6vHDaW(u"ࠩ๒ࠫᲱ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(beV5l2D8HznyJI0(u"ࠪ๐ࠬᲲ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(beV5l2D8HznyJI0(u"ࠫ๕࠭Ჳ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(yobpaW7sBqtKRrv(u"ࠬ๓ࠧᲴ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(ZLr5gRSkFewKdUos90bM(u"࠭๒ࠨᲵ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(kdRO82AImh0LFw(u"ࠧ๒ࠩᲶ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(YYQS36fyPvtuzcEmRL(u"ࠨࡾࠪᲷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࢁࠫᲸ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪหํ์ࠠๅษํ๊ࠬᲹ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(gPE1XB87fQl(u"ุࠫ๐ๅศࠢ็ห๏ะࠧᲺ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				LLCdak89O3AKqyseSRn = [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠬอไฺษหࠫ᲻"),tzZ6PhyDOUnwLM3pdK(u"࠭ฮ๋ษ็ࠫ᲼"),pp7FcjEe6g(u"ࠧศๆห์๊࠭Ჽ"),pp7FcjEe6g(u"ࠨษ็ห๋࠭Ჾ"),A6iX18qgyOFlZxz7sc(u"ࠩส฻ๆอไࠨᲿ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪัฬ๊๊่ࠩ᳀"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫฬฺ๊ศิࠪ᳁"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬ฻วๅฯࠪ᳂"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭วๅัํ๊ࠬ᳃"),rVy3Ops0mohYkT(u"ࠧๆ๊ส่๏ีࠧ᳄"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨษ็฽ฬ๊ๅࠨ᳅"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩส฽๊อไࠨ᳆")]
				if not any(iOtALfPUs0zJkY in fzu7Got0FgiyshTlJK for iOtALfPUs0zJkY in LLCdak89O3AKqyseSRn): fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(Z9FPQvwlbjLTh(u"ࠪห้࠭᳇"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(VP70ytiFNMBl6vHDaW(u"ࠫฬิั๋ࠩ᳈"),gPE1XB87fQl(u"ࠬอฮา๋ࠪ᳉")).replace(YYQS36fyPvtuzcEmRL(u"࠭วอ่หํࠬ᳊"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠧศฮ้ฬ๏࠭᳋")).replace(A6iX18qgyOFlZxz7sc(u"ࠨ฻สส้๐็ࠨ᳌"),iySORMYxWXszEH18(u"ࠩ฼หห๊๊ࠨ᳍"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(KLX7hW0nBAEgy6m4SvH(u"ࠪหั์ศ๋้ࠪ᳎"),A6iX18qgyOFlZxz7sc(u"ࠫฬาๆษ์ࠪ᳏")).replace(gPE1XB87fQl(u"ࠬ฿ัษ์๊ࠫ᳐"),YYQS36fyPvtuzcEmRL(u"ู࠭าสํࠫ᳑")).replace(IMjqygdfYSKpHlWu5Aa(u"ࠧา๊่หู๋๊่ࠩ᳒"),mq5t9JXSdHT8yfDVF(u"ࠨำ๋้ฬ์ำ๋ࠩ᳓"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩ฽ีอ๐็ࠨ᳔"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪ฾ึฮ๊ࠨ᳕")).replace(yobpaW7sBqtKRrv(u"ࠫํࠦๅิๆึ่ฬะ᳖ࠧ"),pp7FcjEe6g(u"๋ࠬำๅี็หฯ᳗࠭")).replace(VP70ytiFNMBl6vHDaW(u"࠭ว฻ษ้ํ᳘ࠬ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠧศ฼ส๊๏᳙࠭"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(IMjqygdfYSKpHlWu5Aa(u"ࠨฬสี๏ิ๊ࠨ᳚"),rVy3Ops0mohYkT(u"ࠩอหึ๐ฮࠨ᳛")).replace(mq5t9JXSdHT8yfDVF(u"ࠪา๏อไࠡ฻็้๏᳜࠭"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠫำ๐วๅ᳝ࠩ")).replace(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"๋่ࠬิ์ๅ๎์᳞࠭"),aiQwFE1TGx04vmLcsYkIW5jA(u"࠭ๅ้ีํๆ๎᳟࠭"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(KLX7hW0nBAEgy6m4SvH(u"่่ࠧาํࠬ᳠"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ้้ำ๏࠭᳡")).replace(yobpaW7sBqtKRrv(u"๊๊ࠩิ๐็ࠨ᳢"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"๋๋ࠪี๊ࠨ᳣")).replace(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫํัววไํ᳤๋ࠬ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠬ๎หศศๅ๎᳥ࠬ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(yobpaW7sBqtKRrv(u"࠭สๅ์ไึ๏๎ๆ᳦๋้ࠪ"),pp7FcjEe6g(u"ࠧหๆไึ๏๎ๆࠨ᳧")).replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨฬ็ๅื๐่็์᳨๊ࠫ"),rVy3Ops0mohYkT(u"ࠩอ่ๆุ๊้่ࠪᳩ")).replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪ์้ࠥัห๊้ࠫᳪ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠫํ้ัห๊้ࠫᳫ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(CyHU86ZeYT5BWRcitSm2I(u"ࠬอไฮษ็๎์࠭ᳬ"),gPE1XB87fQl(u"࠭อศๆํ๋᳭ࠬ")).replace(Z9FPQvwlbjLTh(u"ࠧๆ๊ึ໐็๐ࠧᳮ"),A41nqbj3wYt(u"ࠨ็๋ื๏่้ࠨᳯ")).replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩส่ฬ์ๅ๋ࠩᳰ"),yobpaW7sBqtKRrv(u"ࠪห๋๋๊ࠨᳱ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(A6iX18qgyOFlZxz7sc(u"ࠫฬ๊ๅิๆึ่ฬะࠧᳲ"),kdRO82AImh0LFw(u"๋ࠬำๅี็หฯ࠭ᳳ")).replace(GHg28TBchiyn6l(u"࠭วๅสิห๊าࠧ᳴"),pp7FcjEe6g(u"ࠧษำส้ั࠭ᳵ")).replace(A6iX18qgyOFlZxz7sc(u"ࠨๅสีฯ๎ๆࠨᳶ"),pp7FcjEe6g(u"ࠩๆีฯ๎ๆࠨ᳷"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(gPE1XB87fQl(u"ࠪัึ๎ศࠨ᳸"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫาืศࠨ᳹")).replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠬอไศ่สุ๏ีࠧᳺ"),bawK2j7T81Nrc4GWs05xzDg(u"࠭ว็ษื๎ิ࠭᳻")).replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧศีํ์๏ํࠧ᳼"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠨษึ๎ํ๐ࠧ᳽"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠩ฼ีอ๏ࠧ᳾"),VP70ytiFNMBl6vHDaW(u"ࠪ฽ึฮ๊ࠨ᳿")).replace(wwWzyF4ZpSQXKOgk569(u"ࠫฯืใ๊ࠩᴀ"),Z9FPQvwlbjLTh(u"ࠬะัไ์ࠪᴁ")).replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭สาๅํ๋ࠬᴂ"),iySORMYxWXszEH18(u"ࠧหำๆ๎ࠬᴃ")).replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨษ็้฻อแࠨᴄ"),gPE1XB87fQl(u"ฺ่ࠩฬ็ࠧᴅ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(A41nqbj3wYt(u"ࠪี๏อึ๋ࠩᴆ"),gPE1XB87fQl(u"ࠫึ๐วืหࠪᴇ")).replace(wwWzyF4ZpSQXKOgk569(u"ࠬื๊ศุ๊ࠫᴈ"),A41nqbj3wYt(u"࠭ั๋ษูอࠬᴉ")).replace(ZLr5gRSkFewKdUos90bM(u"ࠧศีํ์๏ํࠧᴊ"),KLX7hW0nBAEgy6m4SvH(u"ࠨษึ๎ํ๐ࠧᴋ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(GHg28TBchiyn6l(u"ࠩๆ์๊๐ฯ๊ࠩᴌ"),mq5t9JXSdHT8yfDVF(u"ࠪ็ํ๋๊ะ์ࠪᴍ")).replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"่ࠫ๎ๅ๋ัํ๋ࠬᴎ"),yobpaW7sBqtKRrv(u"้่ࠬๆ์า๎ࠬᴏ")).replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ว็์่๎ࠬᴐ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧศ่่๎ࠬᴑ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(VP70ytiFNMBl6vHDaW(u"ࠨษ้๎๊๐ิ็ࠩᴒ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩส๊๊๐ิ็ࠩᴓ")).replace(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪห๋๋้ࠨᴔ"),Z9FPQvwlbjLTh(u"ࠫฬ์ๅ๋ึ้ࠫᴕ")).replace(gPE1XB87fQl(u"ࠬอๆๆ์ࠪᴖ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠭ว็็ํุ๋࠭ᴗ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(oiWNFYzcIUeh(u"ࠧศ่่๎ู์ิ็ࠩᴘ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨษ้้๏ฺๆࠨᴙ")).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩส่ฬ์ๅ๋ึ้ࠫᴚ"),ZLr5gRSkFewKdUos90bM(u"ࠪห๋๋๊ี่ࠪᴛ")).replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫᴜ"),VP70ytiFNMBl6vHDaW(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ᴝ"))
				fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).strip(YYQS36fyPvtuzcEmRL(u"࠭࠭ࠨᴞ")).strip(kcXMWrwiLDKeBHRsJ)
			if fzu7Got0FgiyshTlJK not in list(exHviu6hcwoQRqTS4BbyYM7.keys()): exHviu6hcwoQRqTS4BbyYM7[fzu7Got0FgiyshTlJK] = {}
			exHviu6hcwoQRqTS4BbyYM7[fzu7Got0FgiyshTlJK][OOG1iPYhTKQ4] = [t0xkM74rgEAFIepSWXilNOGDn,fzu7Got0FgiyshTlJK,uuSU5Awl8FNrzkXHdQDiCWq3,HOkAWvmZSP5c2t9Dq4NgELyps,dcsuVN65wyfR2EBqx8bXQMr,BfYlvNejqzRc2PDdFiAV9,ZVk6IphECKLzUceP15j,EaOw4PxtyQpZXM3,rBSIjX6x2FVTgOeG4CREKfUq]
	w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨᴟ"),KLX7hW0nBAEgy6m4SvH(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭ᴠ"),exHviu6hcwoQRqTS4BbyYM7,iXBqSkDU3mRCZf4Ib)
	if jZyaRkNnXHD6dVw4eQzUWvP1>=G5FBKAhdbuEC: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,bawK2j7T81Nrc4GWs05xzDg(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪᴡ")+str(jZyaRkNnXHD6dVw4eQzUWvP1)+beV5l2D8HznyJI0(u"ࠪࠤ๊๎โฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์์้ะศุ่่๊ࠢษࠡีหฬ์อฺࠠษาอ๋ࠥๆࠡษ็ษ๋ะั็์อࠤ฾์ฯไ๋ࠢห้๋่ศไ฼ࠤ์๐࠺ࠨᴢ")+AIBc7QYUKp)
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪᴣ"))
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83,xsHjBKXaVkMJoRP83)
	sm0xF8WoGavE7iNjd()
	return
def YYsNSiFgXuKbGI1zqU2(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W):
	lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	ayPo2rAct58buOZ = A3pXVFdyP1.menuItemsLIST
	A3pXVFdyP1.menuItemsLIST[:] = []
	if lgB7TOZqEJiMUFedrSHX8j6 and VP70ytiFNMBl6vHDaW(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᴤ") not in aksIy7wNYp2W:
		APpdhB1Fk58MmJH7CjVntowyaY = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭࡬ࡪࡵࡷࠫᴥ"),mq5t9JXSdHT8yfDVF(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᴦ"),tzZ6PhyDOUnwLM3pdK(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩᴧ")+A2N8BQZTY4p6XKygzOl7nD)
	elif oiWNFYzcIUeh(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᴨ") not in aksIy7wNYp2W or I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࡣ࡛ࡕࡄࡠࠩᴩ") not in aksIy7wNYp2W:
		import e06e8au2ZV
		eJU6bsndE1mI0F = Z9FPQvwlbjLTh(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡำึหห๊ࠠศๆหี๋อๅอࠩᴪ")
		if jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡥࡌࡊࡘࡈࡣࠬᴫ") not in aksIy7wNYp2W:
			try: e06e8au2ZV.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᴬ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴭ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᴮ"),eJU6bsndE1mI0F)
			try: e06e8au2ZV.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,KLX7hW0nBAEgy6m4SvH(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᴯ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+yobpaW7sBqtKRrv(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴰ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᴱ"),eJU6bsndE1mI0F)
			try: e06e8au2ZV.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,A41nqbj3wYt(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᴲ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴳ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᴴ"),eJU6bsndE1mI0F)
		if bawK2j7T81Nrc4GWs05xzDg(u"ࠨࡡ࡙ࡓࡉࡥࠧᴵ") not in aksIy7wNYp2W:
			try: e06e8au2ZV.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,ZLr5gRSkFewKdUos90bM(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᴶ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+SI7eBdND4lx8pt5Qk(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴷ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᴸ"),eJU6bsndE1mI0F)
			try: e06e8au2ZV.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᴹ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴺ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬᴻ"),eJU6bsndE1mI0F)
		APpdhB1Fk58MmJH7CjVntowyaY = A3pXVFdyP1.menuItemsLIST
		if lgB7TOZqEJiMUFedrSHX8j6: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,oiWNFYzcIUeh(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᴼ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪᴽ")+A2N8BQZTY4p6XKygzOl7nD,APpdhB1Fk58MmJH7CjVntowyaY,iXBqSkDU3mRCZf4Ib)
	A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ
	return APpdhB1Fk58MmJH7CjVntowyaY
def CFvMd59yPm(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W):
	lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	ayPo2rAct58buOZ = A3pXVFdyP1.menuItemsLIST
	A3pXVFdyP1.menuItemsLIST[:] = []
	if lgB7TOZqEJiMUFedrSHX8j6 and wwWzyF4ZpSQXKOgk569(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᴾ") not in aksIy7wNYp2W:
		APpdhB1Fk58MmJH7CjVntowyaY = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡱ࡯ࡳࡵࠩᴿ"),rVy3Ops0mohYkT(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᵀ"),ZLr5gRSkFewKdUos90bM(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᵁ")+A2N8BQZTY4p6XKygzOl7nD)
	elif ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᵂ") not in aksIy7wNYp2W or n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨࡡ࡙ࡓࡉࡥࠧᵃ") not in aksIy7wNYp2W:
		import aEzp4cq7nd
		eJU6bsndE1mI0F = aiQwFE1TGx04vmLcsYkIW5jA(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦัิษษ่ࠥอไษำ้ห๊าࠧᵄ")
		if iySORMYxWXszEH18(u"ࠪࡣࡑࡏࡖࡆࡡࠪᵅ") not in aksIy7wNYp2W:
			try: aEzp4cq7nd.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᵆ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+pp7FcjEe6g(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵇ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,A41nqbj3wYt(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᵈ"),eJU6bsndE1mI0F)
			try: aEzp4cq7nd.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᵉ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+CyHU86ZeYT5BWRcitSm2I(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵊ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᵋ"),eJU6bsndE1mI0F)
			try: aEzp4cq7nd.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,beV5l2D8HznyJI0(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᵌ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵍ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,GHg28TBchiyn6l(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᵎ"),eJU6bsndE1mI0F)
		if mq5t9JXSdHT8yfDVF(u"࠭࡟ࡗࡑࡇࡣࠬᵏ") not in aksIy7wNYp2W:
			try: aEzp4cq7nd.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,beV5l2D8HznyJI0(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᵐ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵑ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᵒ"),eJU6bsndE1mI0F)
			try: aEzp4cq7nd.T3TJbgU6X1PzdENmp(A2N8BQZTY4p6XKygzOl7nD,VP70ytiFNMBl6vHDaW(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᵓ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,aksIy7wNYp2W+tzZ6PhyDOUnwLM3pdK(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵔ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
			except: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩᵕ"),eJU6bsndE1mI0F)
		APpdhB1Fk58MmJH7CjVntowyaY = A3pXVFdyP1.menuItemsLIST
		if lgB7TOZqEJiMUFedrSHX8j6: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,A41nqbj3wYt(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᵖ"),mq5t9JXSdHT8yfDVF(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧᵗ")+A2N8BQZTY4p6XKygzOl7nD,APpdhB1Fk58MmJH7CjVntowyaY,iXBqSkDU3mRCZf4Ib)
	A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ
	return APpdhB1Fk58MmJH7CjVntowyaY
def Fr4Dm0py79XjLSAlTvegkZQow(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W,uS0IahQPjdsXozyEp5FVwUKcNL9eC):
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(nrfM1GhFckwzAY9Q,nrfM1GhFckwzAY9Q,z8WclmVQpLo1Hw2beGYjC4griSd)
	if uS0IahQPjdsXozyEp5FVwUKcNL9eC: TZxWMi4Ht7E3U(KiryBCvngZzF85UN6xSDlOVweL4I9)
	elif aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᵘ") in aksIy7wNYp2W and not uS0IahQPjdsXozyEp5FVwUKcNL9eC: TZxWMi4Ht7E3U(r0D4C3z7Onqpa)
	y0rOJx3ZWAVIR = aksIy7wNYp2W.replace(IMjqygdfYSKpHlWu5Aa(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᵙ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(kdRO82AImh0LFw(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵚ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(Z9FPQvwlbjLTh(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵛ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	if not uS0IahQPjdsXozyEp5FVwUKcNL9eC:
		octplHnGwmE8bFqNdj7BiKvJ0VL(Z9FPQvwlbjLTh(u"ࠬࡲࡩ࡯࡭ࠪᵜ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭สฮัํฯ่ࠥวว็ฬࠤฬ๊รใีส้ࠬᵝ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,YYQS36fyPvtuzcEmRL(u"࠼࠼࠳Ỗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᵞ")+y0rOJx3ZWAVIR,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵟ"):A2N8BQZTY4p6XKygzOl7nD})
		octplHnGwmE8bFqNdj7BiKvJ0VL(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩ࡯࡭ࡳࡱࠧᵠ"),e6HEdvUcaq8Gx+A41nqbj3wYt(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᵡ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠿࠹࠺࠻ỗ"))
		CwnFdurTY67y2L80A3KSGb = [kdRO82AImh0LFw(u"ࠫศ็ไศ็ࠪᵢ"),IMjqygdfYSKpHlWu5Aa(u"๋ࠬำๅี็หฯ࠭ᵣ"),wwWzyF4ZpSQXKOgk569(u"࠭ๅิำะ๎ฬะࠧᵤ"),YYQS36fyPvtuzcEmRL(u"ࠧษำส้ั࠭ᵥ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧᵦ"),iySORMYxWXszEH18(u"ࠩิ้฻อๆࠨᵧ"),wwWzyF4ZpSQXKOgk569(u"ࠪวาีห࠮ลัีࠬᵨ"),beV5l2D8HznyJI0(u"ุ๊ࠫวิๆࠪᵩ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"๋่ࠬิ์ๅํࠬᵪ"),VP70ytiFNMBl6vHDaW(u"࠭รี้ิ࠱ศ้หาࠩᵫ"),wwWzyF4ZpSQXKOgk569(u"ࠧศๆล๊ࠬᵬ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠨุะ็ࠬᵭ"),beV5l2D8HznyJI0(u"ࠩิ๎ฬ฼ษࠨᵮ"),tzZ6PhyDOUnwLM3pdK(u"๊ࠪ๏ะแๅๅึࠫᵯ"),tzZ6PhyDOUnwLM3pdK(u"๊๋ࠫหๅ์้ࠫᵰ"),oiWNFYzcIUeh(u"ࠬฮหࠡฯํࠫᵱ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ฯ๋่ํอࠬᵲ"),VP70ytiFNMBl6vHDaW(u"ࠧิ่๋หฯ࠭ᵳ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨลัี๎࠭ᵴ")]
		uS0IahQPjdsXozyEp5FVwUKcNL9eC = j0jEZgiKdxFpMLHcU7kQr8v1lyX4
		for z0I7qT3fOwVPeRCkMQxXc82d in CwnFdurTY67y2L80A3KSGb:
			uS0IahQPjdsXozyEp5FVwUKcNL9eC += wnaWTQM7VJPkZzO9eoSyFU4
			octplHnGwmE8bFqNdj7BiKvJ0VL(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡩࡳࡱࡪࡥࡳࠩᵵ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+z0I7qT3fOwVPeRCkMQxXc82d,WnNGfosHr5STAq8j7miwyRZ6eOUbV,eUYX1LQCSJyNZtMsukTBhA4cfj(u"࠷࠷࠵Ộ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,str(uS0IahQPjdsXozyEp5FVwUKcNL9eC),y0rOJx3ZWAVIR,WnNGfosHr5STAq8j7miwyRZ6eOUbV,{CyHU86ZeYT5BWRcitSm2I(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵶ"):A2N8BQZTY4p6XKygzOl7nD})
	else:
		nJVzgGKHx6owaBAu7M = [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫฬ็ไศ็ࠪᵷ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬࡳ࡯ࡷ࡫ࡨࠫᵸ"),IMjqygdfYSKpHlWu5Aa(u"࠭แ๋ๆ่ࠫᵹ"),rVy3Ops0mohYkT(u"ࠧโๆ่ࠫᵺ")]
		MMHA2zYU1bIRBcZO = [QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠨ็ึุ่๊ࠧᵻ"),yobpaW7sBqtKRrv(u"ࠩࡶࡩࡷ࡯ࡥࡴࠩᵼ")]
		KJBXUPGqvIbSxWuj = [I872Vum45fMNe1BRngTZLoQiqvkt(u"ุ้ࠪอัฮࠩᵽ"),kdRO82AImh0LFw(u"ู๊ࠫัฮ์สฮࠬᵾ")]
		MsS7tFQwUCXf0Ya1 = [ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬฮัศ็ฯࠫᵿ"),IMjqygdfYSKpHlWu5Aa(u"࠭ࡳࡩࡱࡺࠫᶀ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧหๆไึ๏๎ๆࠨᶁ"),YYQS36fyPvtuzcEmRL(u"ࠨฬ็๎ๆุ๊้่ࠪᶂ")]
		ut6qNSgLrWydhVm5IYJ9sik = [SI7eBdND4lx8pt5Qk(u"ࠩส๊๊๐ࠧᶃ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ็ึะ่็ࠩᶄ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"่ࠫอัห๊้ࠫᶅ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡱࡩࡥࡵࠪᶆ"),bawK2j7T81Nrc4GWs05xzDg(u"࠭ืโๆࠪᶇ"),ZLr5gRSkFewKdUos90bM(u"ࠧศูไห้࠭ᶈ")]
		y7AsSMGt3Kk4lVOzJDpWRv = [tzZ6PhyDOUnwLM3pdK(u"ࠨำฺ่ฬ์ࠧᶉ")]
		B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT = [kdRO82AImh0LFw(u"ࠩสัิัࠧᶊ"),ZLr5gRSkFewKdUos90bM(u"ࠪหำืࠧᶋ"),beV5l2D8HznyJI0(u"๊ࠫ๎ฮาࠩᶌ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬาฯ๋ัࠪᶍ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭ๅืษไࠫᶎ"),pp7FcjEe6g(u"ࠧฮัํฯࠬᶏ")]
		NybPCiX8HS1WsZ7Iqz = [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨี็หุ๊ࠧᶐ"),eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠩึุ่๊็ࠨᶑ")]
		MGTHObuB0pLXZ6Fx5YEhgkdmD9 = [mq5t9JXSdHT8yfDVF(u"ࠪห฿อๆ๋ࠩᶒ"),VP70ytiFNMBl6vHDaW(u"๊ࠫ๎ำ๋ไ์ࠫᶓ"),A41nqbj3wYt(u"้ࠬไ๋สࠪᶔ"),KLX7hW0nBAEgy6m4SvH(u"࠭อโๆࠪᶕ"),iySORMYxWXszEH18(u"ࠧ࡮ࡷࡶ࡭ࡨ࠭ᶖ")]
		c8dnZzkASpGNP7sYfliXFBO1WReDo3 = [A41nqbj3wYt(u"ࠨษๆฯึ࠭ᶗ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩสุ์ืࠧᶘ"),VP70ytiFNMBl6vHDaW(u"้๊ࠪ๐า่ࠩᶙ"),VP70ytiFNMBl6vHDaW(u"ࠫฬ฿ไ๊ࠩᶚ"),beV5l2D8HznyJI0(u"๋ࠬฮหษิ๋ࠬᶛ"),VP70ytiFNMBl6vHDaW(u"࠭ๅฯฬสีฬะࠧᶜ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧศไ๋ํࠬᶝ")]
		UIslVAMyFbg0wpjxRQc = [YYQS36fyPvtuzcEmRL(u"ࠨษ็ห๋࠭ᶞ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩะห้๐ࠧᶟ"),IMjqygdfYSKpHlWu5Aa(u"้ࠪะฮสࠨᶠ"),gPE1XB87fQl(u"ࠫึอฦอࠩᶡ")]
		jjvZVL2CG1NqJcFUudhTMI = [YYQS36fyPvtuzcEmRL(u"ࠬ฼อไࠩᶢ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ใ้็ํำ๏࠭ᶣ")]
		Du4pYvjwCWA35sdF = [tzZ6PhyDOUnwLM3pdK(u"ࠧา์สฺ์࠭ᶤ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨๅ๋ี์࠭ᶥ"),Z9FPQvwlbjLTh(u"ู่ࠩฬืู่ࠩᶦ"),XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ุࠪํะࠧᶧ"),A41nqbj3wYt(u"ࠫึ๐วืหࠪᶨ")]
		hGwaJTV3BmE8H = [rVy3Ops0mohYkT(u"ࠬ์๊หใ็็ุ࠭ᶩ"),oiWNFYzcIUeh(u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧᶪ"),KLX7hW0nBAEgy6m4SvH(u"ࠧ็์อๅ้๐ใิࠩᶫ")]
		gcI5lHF6fVi7ZSr9TtDjy0u = [aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ็่ฯ้๐ๆࠨᶬ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩสุำอีࠨᶭ"),rVy3Ops0mohYkT(u"๊ࠪั๎ๅࠨᶮ")]
		GhmfN2TgEXLD5CpAJeaY = [aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫอัࠠฮ์ࠪᶯ"),rVy3Ops0mohYkT(u"ࠬࡲࡩࡷࡧࠪᶰ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠭โ็ษ๊ࠫᶱ"),rVy3Ops0mohYkT(u"ࠧใ่๋หฯ࠭ᶲ")]
		nnHxLmYpQgD5bJ42VXeUFzC = [YYQS36fyPvtuzcEmRL(u"ࠨัํ๊ࠬᶳ"),yobpaW7sBqtKRrv(u"ࠩสำ฾๐็ࠨᶴ"),tzZ6PhyDOUnwLM3pdK(u"ࠪึ๏อัศฬࠪᶵ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"้ࠫ฽ๅ๋ษอࠫᶶ"),iySORMYxWXszEH18(u"ࠬีูศรࠪᶷ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭โาษ้ࠫᶸ"),mq5t9JXSdHT8yfDVF(u"ࠧใืสสิ࠭ᶹ"),mq5t9JXSdHT8yfDVF(u"ࠨำฮหฦ࠭ᶺ"),kdRO82AImh0LFw(u"่ࠩีั฿๊่ࠩᶻ"),mq5t9JXSdHT8yfDVF(u"ࠪหีอๆࠨᶼ"),KLX7hW0nBAEgy6m4SvH(u"ࠫฬูไศ็ࠪᶽ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬะ่ศึํัࠬᶾ"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ฮุสࠪᶿ"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧฮ๊ี์๏࠭᷀"),n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠨ฻อฬฬะࠧ᷁"),yobpaW7sBqtKRrv(u"่ࠩ์ฬ๊๊ะ᷂ࠩ"),tzZ6PhyDOUnwLM3pdK(u"๊ࠪํอู๋ࠩ᷃"),rVy3Ops0mohYkT(u"ࠫ฾่ววัࠪ᷄"),YYQS36fyPvtuzcEmRL(u"ࠬอๆศึํำࠬ᷅")]
		J9J48IQEZcOjRybDC3gNUhHoeLY = [yobpaW7sBqtKRrv(u"࠭࠲࠱࠳࠳ࠫ᷆"),lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧ࠳࠲࠴࠵ࠬ᷇"),A41nqbj3wYt(u"ࠨ࠴࠳࠵࠷࠭᷈"),wwWzyF4ZpSQXKOgk569(u"ࠩ࠵࠴࠶࠹ࠧ᷉"),bawK2j7T81Nrc4GWs05xzDg(u"ࠪ࠶࠵࠷࠴ࠨ᷊"),A6iX18qgyOFlZxz7sc(u"ࠫ࠷࠶࠱࠶ࠩ᷋"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠬ࠸࠰࠲࠸ࠪ᷌"),mq5t9JXSdHT8yfDVF(u"࠭࠲࠱࠳࠺ࠫ᷍"),ZLr5gRSkFewKdUos90bM(u"ࠧ࠳࠲࠴࠼᷎ࠬ"),SI7eBdND4lx8pt5Qk(u"ࠨ࠴࠳࠵࠾᷏࠭"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩ࠵࠴࠷࠶᷐ࠧ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪ࠶࠵࠸࠱ࠨ᷑"),mq5t9JXSdHT8yfDVF(u"ࠫ࠷࠶࠲࠳ࠩ᷒"),mq5t9JXSdHT8yfDVF(u"ࠬ࠸࠰࠳࠵ࠪᷓ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠭࠲࠱࠴࠷ࠫᷔ"),VP70ytiFNMBl6vHDaW(u"ࠧ࠳࠲࠵࠹ࠬᷕ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠨ࠴࠳࠶࠻࠭ᷖ"),ZLr5gRSkFewKdUos90bM(u"ࠩ࠵࠴࠷࠽ࠧᷗ"),aiQwFE1TGx04vmLcsYkIW5jA(u"ࠪ࠶࠵࠸࠸ࠨᷘ")]
		for fzu7Got0FgiyshTlJK in sorted(list(exHviu6hcwoQRqTS4BbyYM7.keys())):
			Zf06rvhWgN3OPj2YTdeqU = fzu7Got0FgiyshTlJK.lower()
			eukVjoW67vBiySNXrplDKIZLHU = []
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in nJVzgGKHx6owaBAu7M): eukVjoW67vBiySNXrplDKIZLHU.append(wnaWTQM7VJPkZzO9eoSyFU4)
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in MMHA2zYU1bIRBcZO): eukVjoW67vBiySNXrplDKIZLHU.append(XURrDCfOS9Mbhpv2Pmjos56TeW)
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in KJBXUPGqvIbSxWuj): eukVjoW67vBiySNXrplDKIZLHU.append(vXIdY7TwFKso40gVBq5)
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in MsS7tFQwUCXf0Ya1): eukVjoW67vBiySNXrplDKIZLHU.append(yGLl1nSBrJPmi2adko9O)
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in ut6qNSgLrWydhVm5IYJ9sik): eukVjoW67vBiySNXrplDKIZLHU.append(EEowc8rs5gUZTVjdOzmb0nu)
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in y7AsSMGt3Kk4lVOzJDpWRv): eukVjoW67vBiySNXrplDKIZLHU.append(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠷ộ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in B3aQg7Gu8cKsV9ixNjfRhvAzlUqrZT) and Zf06rvhWgN3OPj2YTdeqU not in [GHg28TBchiyn6l(u"ࠫฬิั๊ࠩᷙ")]: eukVjoW67vBiySNXrplDKIZLHU.append(Z9FPQvwlbjLTh(u"࠹Ớ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in NybPCiX8HS1WsZ7Iqz): eukVjoW67vBiySNXrplDKIZLHU.append(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠻ớ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in MGTHObuB0pLXZ6Fx5YEhgkdmD9): eukVjoW67vBiySNXrplDKIZLHU.append(bawK2j7T81Nrc4GWs05xzDg(u"࠽Ờ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in c8dnZzkASpGNP7sYfliXFBO1WReDo3): eukVjoW67vBiySNXrplDKIZLHU.append(yobpaW7sBqtKRrv(u"࠶࠶ờ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in UIslVAMyFbg0wpjxRQc): eukVjoW67vBiySNXrplDKIZLHU.append(VP70ytiFNMBl6vHDaW(u"࠷࠱Ở"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in jjvZVL2CG1NqJcFUudhTMI): eukVjoW67vBiySNXrplDKIZLHU.append(aiQwFE1TGx04vmLcsYkIW5jA(u"࠱࠳ở"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in Du4pYvjwCWA35sdF): eukVjoW67vBiySNXrplDKIZLHU.append(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠲࠵Ỡ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in hGwaJTV3BmE8H): eukVjoW67vBiySNXrplDKIZLHU.append(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠳࠷ỡ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in gcI5lHF6fVi7ZSr9TtDjy0u): eukVjoW67vBiySNXrplDKIZLHU.append(VP70ytiFNMBl6vHDaW(u"࠴࠹Ợ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in GhmfN2TgEXLD5CpAJeaY): eukVjoW67vBiySNXrplDKIZLHU.append(Z9FPQvwlbjLTh(u"࠵࠻ợ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in nnHxLmYpQgD5bJ42VXeUFzC): eukVjoW67vBiySNXrplDKIZLHU.append(beV5l2D8HznyJI0(u"࠶࠽Ụ"))
			if any(value in Zf06rvhWgN3OPj2YTdeqU for value in J9J48IQEZcOjRybDC3gNUhHoeLY): eukVjoW67vBiySNXrplDKIZLHU.append(aiQwFE1TGx04vmLcsYkIW5jA(u"࠷࠸ụ"))
			if not eukVjoW67vBiySNXrplDKIZLHU: eukVjoW67vBiySNXrplDKIZLHU = [gPE1XB87fQl(u"࠱࠺Ủ")]
			for fPn1m2pDOieCd in eukVjoW67vBiySNXrplDKIZLHU:
				if str(fPn1m2pDOieCd)==uS0IahQPjdsXozyEp5FVwUKcNL9eC:
					octplHnGwmE8bFqNdj7BiKvJ0VL(bawK2j7T81Nrc4GWs05xzDg(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷚ"),uBQ9txp0gDrEhZTcJOi74SKVw3k+fzu7Got0FgiyshTlJK,fzu7Got0FgiyshTlJK,pp7FcjEe6g(u"࠲࠸࠹ủ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,y0rOJx3ZWAVIR+SI7eBdND4lx8pt5Qk(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷛ"))
	OO7gEdhG2U3x6ucLvKoVJyfPRNrk(nrfM1GhFckwzAY9Q,nrfM1GhFckwzAY9Q,xsHjBKXaVkMJoRP83)
	return
def d3d6KCgxpBTZSHG1cvMWlVeky2(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W):
	lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	if lgB7TOZqEJiMUFedrSHX8j6:
		octplHnGwmE8bFqNdj7BiKvJ0VL(bawK2j7T81Nrc4GWs05xzDg(u"ࠧ࡭࡫ࡱ࡯ࠬᷜ"),IMjqygdfYSKpHlWu5Aa(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡏࡐࡕࡘࠪᷝ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"࠹࠹࠸Ứ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᷞ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,{jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠪࡪࡴࡲࡤࡦࡴࠪᷟ"):A2N8BQZTY4p6XKygzOl7nD})
		octplHnGwmE8bFqNdj7BiKvJ0VL(wwWzyF4ZpSQXKOgk569(u"ࠫࡱ࡯࡮࡬ࠩᷠ"),e6HEdvUcaq8Gx+bawK2j7T81Nrc4GWs05xzDg(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᷡ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,ZLr5gRSkFewKdUos90bM(u"࠼࠽࠾࠿ứ"))
	ayPo2rAct58buOZ = A3pXVFdyP1.menuItemsLIST[:]
	import e06e8au2ZV
	if A2N8BQZTY4p6XKygzOl7nD:
		if not e06e8au2ZV.iI5rl4JkL8Ks1go6fUxXN9w7tj(A2N8BQZTY4p6XKygzOl7nD,r0D4C3z7Onqpa): return
		o7cGEjQaYC = YYsNSiFgXuKbGI1zqU2(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W)
		do9Jn4YIWwCH3bQtcR1V8ehgFK = sorted(o7cGEjQaYC,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4].lower())
	else:
		if not e06e8au2ZV.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
		if lgB7TOZqEJiMUFedrSHX8j6 and kdRO82AImh0LFw(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᷢ") not in aksIy7wNYp2W:
			do9Jn4YIWwCH3bQtcR1V8ehgFK = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠧ࡭࡫ࡶࡸࠬᷣ"),aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᷤ"),beV5l2D8HznyJI0(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭ᷥ"))
		else:
			onktvHiNrMafY1sjUp,do9Jn4YIWwCH3bQtcR1V8ehgFK,o7cGEjQaYC = [],[],[]
			for fMRCPgcnwW95EykI1hiBXSupvzOqA in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
				do9Jn4YIWwCH3bQtcR1V8ehgFK += YYsNSiFgXuKbGI1zqU2(str(fMRCPgcnwW95EykI1hiBXSupvzOqA),aksIy7wNYp2W)
			for type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in do9Jn4YIWwCH3bQtcR1V8ehgFK:
				if ZVk6IphECKLzUceP15j not in onktvHiNrMafY1sjUp:
					onktvHiNrMafY1sjUp.append(ZVk6IphECKLzUceP15j)
					GOqCDsnKbdpyVuLvzPTgAtWQ = type,fzu7Got0FgiyshTlJK,ZVk6IphECKLzUceP15j,A41nqbj3wYt(u"࠵࠻࠻Ừ"),bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,aksIy7wNYp2W,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f
					o7cGEjQaYC.append(GOqCDsnKbdpyVuLvzPTgAtWQ)
			do9Jn4YIWwCH3bQtcR1V8ehgFK = sorted(o7cGEjQaYC,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4].lower())
			if lgB7TOZqEJiMUFedrSHX8j6: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,yobpaW7sBqtKRrv(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᷦ"),beV5l2D8HznyJI0(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᷧ"),do9Jn4YIWwCH3bQtcR1V8ehgFK,iXBqSkDU3mRCZf4Ib)
	A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK
	YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def Fy7ChzgQx1NAvK2DU0YLqerWpcE(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W):
	lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	if lgB7TOZqEJiMUFedrSHX8j6:
		octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠬࡲࡩ࡯࡭ࠪᷨ"),kdRO82AImh0LFw(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡑ࠸࡛ࠧᷩ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠼࠼࠵ừ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,CyHU86ZeYT5BWRcitSm2I(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᷪ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,{gPE1XB87fQl(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᷫ"):A2N8BQZTY4p6XKygzOl7nD})
		octplHnGwmE8bFqNdj7BiKvJ0VL(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠩ࡯࡭ࡳࡱࠧᷬ"),e6HEdvUcaq8Gx+YYQS36fyPvtuzcEmRL(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᷭ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,wwWzyF4ZpSQXKOgk569(u"࠿࠹࠺࠻Ử"))
	ayPo2rAct58buOZ = A3pXVFdyP1.menuItemsLIST[:]
	import aEzp4cq7nd
	if A2N8BQZTY4p6XKygzOl7nD:
		if not aEzp4cq7nd.iI5rl4JkL8Ks1go6fUxXN9w7tj(A2N8BQZTY4p6XKygzOl7nD,r0D4C3z7Onqpa): return
		o7cGEjQaYC = CFvMd59yPm(A2N8BQZTY4p6XKygzOl7nD,aksIy7wNYp2W)
		do9Jn4YIWwCH3bQtcR1V8ehgFK = sorted(o7cGEjQaYC,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4].lower())
	else:
		if not aEzp4cq7nd.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
		if lgB7TOZqEJiMUFedrSHX8j6 and A6iX18qgyOFlZxz7sc(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᷮ") not in aksIy7wNYp2W:
			do9Jn4YIWwCH3bQtcR1V8ehgFK = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,A6iX18qgyOFlZxz7sc(u"ࠬࡲࡩࡴࡶࠪᷯ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᷰ"),A6iX18qgyOFlZxz7sc(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᷱ"))
		else:
			onktvHiNrMafY1sjUp,do9Jn4YIWwCH3bQtcR1V8ehgFK,o7cGEjQaYC = [],[],[]
			for fMRCPgcnwW95EykI1hiBXSupvzOqA in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
				do9Jn4YIWwCH3bQtcR1V8ehgFK += CFvMd59yPm(str(fMRCPgcnwW95EykI1hiBXSupvzOqA),aksIy7wNYp2W)
			for type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in do9Jn4YIWwCH3bQtcR1V8ehgFK:
				if ZVk6IphECKLzUceP15j not in onktvHiNrMafY1sjUp:
					onktvHiNrMafY1sjUp.append(ZVk6IphECKLzUceP15j)
					GOqCDsnKbdpyVuLvzPTgAtWQ = type,fzu7Got0FgiyshTlJK,ZVk6IphECKLzUceP15j,VP70ytiFNMBl6vHDaW(u"࠱࠷࠷ử"),bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,aksIy7wNYp2W,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f
					o7cGEjQaYC.append(GOqCDsnKbdpyVuLvzPTgAtWQ)
			do9Jn4YIWwCH3bQtcR1V8ehgFK = sorted(o7cGEjQaYC,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4].lower())
			if lgB7TOZqEJiMUFedrSHX8j6: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,beV5l2D8HznyJI0(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᷲ"),IMjqygdfYSKpHlWu5Aa(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᷳ"),do9Jn4YIWwCH3bQtcR1V8ehgFK,iXBqSkDU3mRCZf4Ib)
	A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK
	YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def mHMEFDYXfybhRdNnwO0SQTu(group,aksIy7wNYp2W):
	lgB7TOZqEJiMUFedrSHX8j6 = KiryBCvngZzF85UN6xSDlOVweL4I9
	APpdhB1Fk58MmJH7CjVntowyaY = []
	O6ORBSFqrdZzHagEpPb0V7K2Nm8 = Z9FPQvwlbjLTh(u"ࠪࡣࡎࡖࡔࡗࡡࠪᷴ") if rVy3Ops0mohYkT(u"ࠫࡎࡖࡔࡗࠩ᷵") in aksIy7wNYp2W else tzZ6PhyDOUnwLM3pdK(u"ࠬࡥࡍ࠴ࡗࡢࠫ᷶")
	if lgB7TOZqEJiMUFedrSHX8j6: APpdhB1Fk58MmJH7CjVntowyaY = VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,Z9FPQvwlbjLTh(u"࠭࡬ࡪࡵࡷ᷷ࠫ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔ᷸ࠩ")+O6ORBSFqrdZzHagEpPb0V7K2Nm8[:-wnaWTQM7VJPkZzO9eoSyFU4],group)
	if not APpdhB1Fk58MmJH7CjVntowyaY:
		for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
			if lgB7TOZqEJiMUFedrSHX8j6: APpdhB1Fk58MmJH7CjVntowyaY += VolBUXWI42N1CF6RiKd(p9DTgUZ1auwRYXoHld7v8MP,rVy3Ops0mohYkT(u"ࠨ࡮࡬ࡷࡹ᷹࠭"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖ᷺ࠫ")+O6ORBSFqrdZzHagEpPb0V7K2Nm8[:-wnaWTQM7VJPkZzO9eoSyFU4],eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ᷻")+O6ORBSFqrdZzHagEpPb0V7K2Nm8+str(A2N8BQZTY4p6XKygzOl7nD))
			elif O6ORBSFqrdZzHagEpPb0V7K2Nm8==iySORMYxWXszEH18(u"ࠫࡤࡏࡐࡕࡘࡢࠫ᷼"): APpdhB1Fk58MmJH7CjVntowyaY += YYsNSiFgXuKbGI1zqU2(str(A2N8BQZTY4p6XKygzOl7nD),GHg28TBchiyn6l(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡ᷽ࠪ"))
			elif O6ORBSFqrdZzHagEpPb0V7K2Nm8==aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭࡟ࡎ࠵ࡘࡣࠬ᷾"): APpdhB1Fk58MmJH7CjVntowyaY += CFvMd59yPm(str(A2N8BQZTY4p6XKygzOl7nD),A41nqbj3wYt(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣ᷿ࠬ"))
		for type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in APpdhB1Fk58MmJH7CjVntowyaY:
			if ZVk6IphECKLzUceP15j==group: NNFPsWDgoE(type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
		items,YacIZtAGdEPsFhSe = [],[]
		for type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in A3pXVFdyP1.menuItemsLIST:
			DfRQbAWt3U4YLKjVNPr1 = type,fzu7Got0FgiyshTlJK[yGLl1nSBrJPmi2adko9O:],url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if DfRQbAWt3U4YLKjVNPr1 not in YacIZtAGdEPsFhSe:
				YacIZtAGdEPsFhSe.append(DfRQbAWt3U4YLKjVNPr1)
				N6NV3h4fel = type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f
				items.append(N6NV3h4fel)
		APpdhB1Fk58MmJH7CjVntowyaY = sorted(items,reverse=KiryBCvngZzF85UN6xSDlOVweL4I9,key=lambda key: key[wnaWTQM7VJPkZzO9eoSyFU4].lower()[CyHU86ZeYT5BWRcitSm2I(u"࠶Ữ"):])
		if lgB7TOZqEJiMUFedrSHX8j6: w1srYvgBLWStpZ29(p9DTgUZ1auwRYXoHld7v8MP,tzZ6PhyDOUnwLM3pdK(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪḀ")+O6ORBSFqrdZzHagEpPb0V7K2Nm8[:-wnaWTQM7VJPkZzO9eoSyFU4],group,APpdhB1Fk58MmJH7CjVntowyaY,iXBqSkDU3mRCZf4Ib)
	if IMjqygdfYSKpHlWu5Aa(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫḁ") in aksIy7wNYp2W and len(APpdhB1Fk58MmJH7CjVntowyaY)>w7XRmZonrby:
		A3pXVFdyP1.menuItemsLIST[:] = []
		octplHnGwmE8bFqNdj7BiKvJ0VL(iySORMYxWXszEH18(u"ࠪࡪࡴࡲࡤࡦࡴࠪḂ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠫࡠ࠭ḃ")+e6HEdvUcaq8Gx+group+YVr6St5P4xsFC0aARQGKfiegD+KLX7hW0nBAEgy6m4SvH(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧḄ"),group,aiQwFE1TGx04vmLcsYkIW5jA(u"࠳࠹࠹ữ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,O6ORBSFqrdZzHagEpPb0V7K2Nm8+KLX7hW0nBAEgy6m4SvH(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḅ"))
		octplHnGwmE8bFqNdj7BiKvJ0VL(gPE1XB87fQl(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḆ"),kdRO82AImh0LFw(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧḇ"),group,pp7FcjEe6g(u"࠴࠺࠺Ự"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,O6ORBSFqrdZzHagEpPb0V7K2Nm8+QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḈ"))
		octplHnGwmE8bFqNdj7BiKvJ0VL(rVy3Ops0mohYkT(u"ࠪࡰ࡮ࡴ࡫ࠨḉ"),e6HEdvUcaq8Gx+eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩḊ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠽࠾࠿࠹ự"))
		APpdhB1Fk58MmJH7CjVntowyaY = A3pXVFdyP1.menuItemsLIST+FxEWL1w4gjr8mM.sample(APpdhB1Fk58MmJH7CjVntowyaY,w7XRmZonrby)
	A3pXVFdyP1.menuItemsLIST[:] = APpdhB1Fk58MmJH7CjVntowyaY
	YINetiX57RwjFa4f1JBmS28Hx(KiryBCvngZzF85UN6xSDlOVweL4I9)
	return
def HhMmwBAs5zV6D429cI7TE(aksIy7wNYp2W):
	octplHnGwmE8bFqNdj7BiKvJ0VL(GHg28TBchiyn6l(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḋ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩḌ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠶࠼࠱Ỳ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧḍ"))
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"ࠨ࡮࡬ࡲࡰ࠭Ḏ"),e6HEdvUcaq8Gx+rVy3Ops0mohYkT(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḏ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,I872Vum45fMNe1BRngTZLoQiqvkt(u"࠿࠹࠺࠻ỳ"))
	Lc8JUbKXQnmHTrRZ3D1wC7u9lP4 = A3pXVFdyP1.menuItemsLIST[:]
	A3pXVFdyP1.menuItemsLIST[:] = []
	import rvzPVNjLxS
	rvzPVNjLxS.f28uNr4CYyMqT(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࠴ࠬḐ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	rvzPVNjLxS.f28uNr4CYyMqT(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠫ࠶࠭ḑ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	rvzPVNjLxS.f28uNr4CYyMqT(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬ࠸ࠧḒ"),KiryBCvngZzF85UN6xSDlOVweL4I9)
	if mq5t9JXSdHT8yfDVF(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨḓ") in aksIy7wNYp2W:
		A3pXVFdyP1.menuItemsLIST[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
		if len(A3pXVFdyP1.menuItemsLIST)>w7XRmZonrby: A3pXVFdyP1.menuItemsLIST[:] = FxEWL1w4gjr8mM.sample(A3pXVFdyP1.menuItemsLIST,w7XRmZonrby)
	A3pXVFdyP1.menuItemsLIST[:] = Lc8JUbKXQnmHTrRZ3D1wC7u9lP4+A3pXVFdyP1.menuItemsLIST
	return
def KKjWJk8dUEhOn(aksIy7wNYp2W):
	aksIy7wNYp2W = aksIy7wNYp2W.replace(oiWNFYzcIUeh(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḔ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(pp7FcjEe6g(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḕ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	headers = { A41nqbj3wYt(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ḗ") : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
	url = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩḗ")
	data = {XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭Ḙ"):aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠬ࠻࠰ࠨḙ")}
	data = kkymMOX7TcjRVpY2K(data)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(A8MWZixP2YtOJ1no53mw,ZLr5gRSkFewKdUos90bM(u"࠭ࡇࡆࡖࠪḚ"),url,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩḛ"))
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall(VP70ytiFNMBl6vHDaW(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪḜ"),piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	items = p7dwlH1PRStBgyMUW.findall(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧḝ"),KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	UAOpnxYdiLIQcSPb8oaENK,tYvbBAGg2lTQs = list(zip(*items))
	Wg2zKemM4Lv8XAECFpDOQrT7s = []
	F4yUqrSNaPcbxdoh7kAL = [kcXMWrwiLDKeBHRsJ,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࠦࠬḞ"),yobpaW7sBqtKRrv(u"ࠫࡥ࠭ḟ"),Z9FPQvwlbjLTh(u"ࠬ࠲ࠧḠ"),YYQS36fyPvtuzcEmRL(u"࠭࠮ࠨḡ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠧ࠻ࠩḢ"),IMjqygdfYSKpHlWu5Aa(u"ࠨ࠽ࠪḣ"),jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠤࠪࠦḤ"),A41nqbj3wYt(u"ࠪ࠱ࠬḥ")]
	M0Lc6YNtG2eA4y7xXDkw1SdJ = tYvbBAGg2lTQs+UAOpnxYdiLIQcSPb8oaENK
	for o6gahbz5RceJqBFuxNv in M0Lc6YNtG2eA4y7xXDkw1SdJ:
		if o6gahbz5RceJqBFuxNv in tYvbBAGg2lTQs: wxWo4lJZDqX2CRndm = XURrDCfOS9Mbhpv2Pmjos56TeW
		if o6gahbz5RceJqBFuxNv in UAOpnxYdiLIQcSPb8oaENK: wxWo4lJZDqX2CRndm = yGLl1nSBrJPmi2adko9O
		OPnL1T8or0M2mih = [JrM1DoSuQ5n8 in o6gahbz5RceJqBFuxNv for JrM1DoSuQ5n8 in F4yUqrSNaPcbxdoh7kAL]
		if any(OPnL1T8or0M2mih):
			veLqt1DZI6N8a = OPnL1T8or0M2mih.index(r0D4C3z7Onqpa)
			VxTwLN5EkJMKqc6r2gelUf9XBFpG = F4yUqrSNaPcbxdoh7kAL[veLqt1DZI6N8a]
			vUlfouqeLrODSPYJ7 = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			if o6gahbz5RceJqBFuxNv.count(VxTwLN5EkJMKqc6r2gelUf9XBFpG)>wnaWTQM7VJPkZzO9eoSyFU4: eUvCtKqwXBS56AlD3gLHInF,V6z7qZPR8UgbDi5a3xsokEr20S,vUlfouqeLrODSPYJ7 = o6gahbz5RceJqBFuxNv.split(VxTwLN5EkJMKqc6r2gelUf9XBFpG,XURrDCfOS9Mbhpv2Pmjos56TeW)
			else: eUvCtKqwXBS56AlD3gLHInF,V6z7qZPR8UgbDi5a3xsokEr20S = o6gahbz5RceJqBFuxNv.split(VxTwLN5EkJMKqc6r2gelUf9XBFpG,wnaWTQM7VJPkZzO9eoSyFU4)
			if len(eUvCtKqwXBS56AlD3gLHInF)>wxWo4lJZDqX2CRndm: Wg2zKemM4Lv8XAECFpDOQrT7s.append(eUvCtKqwXBS56AlD3gLHInF.lower())
			if len(V6z7qZPR8UgbDi5a3xsokEr20S)>wxWo4lJZDqX2CRndm: Wg2zKemM4Lv8XAECFpDOQrT7s.append(V6z7qZPR8UgbDi5a3xsokEr20S.lower())
			if len(vUlfouqeLrODSPYJ7)>wxWo4lJZDqX2CRndm: Wg2zKemM4Lv8XAECFpDOQrT7s.append(vUlfouqeLrODSPYJ7.lower())
		elif len(o6gahbz5RceJqBFuxNv)>wxWo4lJZDqX2CRndm: Wg2zKemM4Lv8XAECFpDOQrT7s.append(o6gahbz5RceJqBFuxNv.lower())
	for JrM1DoSuQ5n8 in range(YYQS36fyPvtuzcEmRL(u"࠹Ỵ")): FxEWL1w4gjr8mM.shuffle(Wg2zKemM4Lv8XAECFpDOQrT7s)
	if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬḦ") in aksIy7wNYp2W:
		bClMIzaL2cOBXZ3V8xRKoskA6 = JphriA3aDH61YFCbXsBvTmdx
	elif beV5l2D8HznyJI0(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬḧ") in aksIy7wNYp2W:
		bClMIzaL2cOBXZ3V8xRKoskA6 = [n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࠭ࡉࡑࡖ࡙ࠫḨ")]
		import e06e8au2ZV
		if not e06e8au2ZV.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
	elif rVy3Ops0mohYkT(u"ࠧࡠࡏ࠶࡙ࡤ࠭ḩ") in aksIy7wNYp2W:
		bClMIzaL2cOBXZ3V8xRKoskA6 = [rVy3Ops0mohYkT(u"ࠨࡏ࠶࡙ࠬḪ")]
		import aEzp4cq7nd
		if not aEzp4cq7nd.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
	count,CuS1hNDWTksXl = j0jEZgiKdxFpMLHcU7kQr8v1lyX4,j0jEZgiKdxFpMLHcU7kQr8v1lyX4
	octplHnGwmE8bFqNdj7BiKvJ0VL(VP70ytiFNMBl6vHDaW(u"ࠩࡩࡳࡱࡪࡥࡳࠩḫ"),QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫḬ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,oiWNFYzcIUeh(u"࠲࠸࠷ỵ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḭ")+aksIy7wNYp2W)
	octplHnGwmE8bFqNdj7BiKvJ0VL(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḮ"),I872Vum45fMNe1BRngTZLoQiqvkt(u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭ḯ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠳࠹࠸Ỷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḰ")+aksIy7wNYp2W)
	octplHnGwmE8bFqNdj7BiKvJ0VL(Z9FPQvwlbjLTh(u"ࠨ࡮࡬ࡲࡰ࠭ḱ"),e6HEdvUcaq8Gx+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḲ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,SI7eBdND4lx8pt5Qk(u"࠼࠽࠾࠿ỷ"))
	T0TzdO7xgfZaXlGnFNMq = A3pXVFdyP1.menuItemsLIST[:]
	A3pXVFdyP1.menuItemsLIST[:] = []
	P4jtYVal2FRgmB = []
	for o6gahbz5RceJqBFuxNv in Wg2zKemM4Lv8XAECFpDOQrT7s:
		V6z7qZPR8UgbDi5a3xsokEr20S = p7dwlH1PRStBgyMUW.findall(eUYX1LQCSJyNZtMsukTBhA4cfj(u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪḳ")+ZLr5gRSkFewKdUos90bM(u"ࠫࠨ࠭Ḵ")+A41nqbj3wYt(u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩḵ"),o6gahbz5RceJqBFuxNv,p7dwlH1PRStBgyMUW.DOTALL)
		if V6z7qZPR8UgbDi5a3xsokEr20S: o6gahbz5RceJqBFuxNv = o6gahbz5RceJqBFuxNv.split(V6z7qZPR8UgbDi5a3xsokEr20S[j0jEZgiKdxFpMLHcU7kQr8v1lyX4],wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		b4dO1J9kfyXFztP = o6gahbz5RceJqBFuxNv.replace(kdRO82AImh0LFw(u"࠭๑ࠨḶ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(gPE1XB87fQl(u"ࠧ๏ࠩḷ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(beV5l2D8HznyJI0(u"ࠨํࠪḸ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(wwWzyF4ZpSQXKOgk569(u"ࠩ๒ࠫḹ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(VP70ytiFNMBl6vHDaW(u"ࠪ๐ࠬḺ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		b4dO1J9kfyXFztP = b4dO1J9kfyXFztP.replace(YYQS36fyPvtuzcEmRL(u"ࠫ๕࠭ḻ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(CyHU86ZeYT5BWRcitSm2I(u"ࠬ๓ࠧḼ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(beV5l2D8HznyJI0(u"࠭๒ࠨḽ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠧญࠩḾ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(mq5t9JXSdHT8yfDVF(u"ࠨโࠪḿ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		if b4dO1J9kfyXFztP: P4jtYVal2FRgmB.append(b4dO1J9kfyXFztP)
	VTDoBmZPwdHqIagiebMOs = []
	for zuEo6GDeAR5Z in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,CyHU86ZeYT5BWRcitSm2I(u"࠶࠵Ỹ")):
		search = FxEWL1w4gjr8mM.sample(P4jtYVal2FRgmB,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		if search in VTDoBmZPwdHqIagiebMOs: continue
		VTDoBmZPwdHqIagiebMOs.append(search)
		OOG1iPYhTKQ4 = FxEWL1w4gjr8mM.sample(bClMIzaL2cOBXZ3V8xRKoskA6,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+CyHU86ZeYT5BWRcitSm2I(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬṀ")+str(OOG1iPYhTKQ4)+kdRO82AImh0LFw(u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭ṁ")+search)
		PVIqN8MGBf7DX3TjdA1Qh9gOU,uTes0AS7pNHjbkawzy5mqLx4XP,qr61ZvHTdEjIShcBis = b6thNQgW1BDiSaLqsc7OFwd3oX(OOG1iPYhTKQ4)
		uTes0AS7pNHjbkawzy5mqLx4XP(search+gPE1XB87fQl(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩṂ"))
		if len(A3pXVFdyP1.menuItemsLIST)>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: break
	search = search.replace(jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬࡥࡍࡐࡆࡢࠫṃ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	T0TzdO7xgfZaXlGnFNMq[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4] = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࡛࠭ࠨṄ")+e6HEdvUcaq8Gx+search+YVr6St5P4xsFC0aARQGKfiegD+A6iX18qgyOFlZxz7sc(u"ࠧࠡ࠼หัะูࠦ็࡟ࠪṅ")
	A3pXVFdyP1.menuItemsLIST[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
	if len(A3pXVFdyP1.menuItemsLIST)>w7XRmZonrby: A3pXVFdyP1.menuItemsLIST[:] = FxEWL1w4gjr8mM.sample(A3pXVFdyP1.menuItemsLIST,w7XRmZonrby)
	A3pXVFdyP1.menuItemsLIST[:] = T0TzdO7xgfZaXlGnFNMq+A3pXVFdyP1.menuItemsLIST
	return
def x9dBRbVYnC(yRvqpKWFks,aksIy7wNYp2W):
	yRvqpKWFks = yRvqpKWFks.replace(mq5t9JXSdHT8yfDVF(u"ࠨࡡࡐࡓࡉࡥࠧṆ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	aksIy7wNYp2W = aksIy7wNYp2W.replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṇ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(mq5t9JXSdHT8yfDVF(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṈ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	TZxWMi4Ht7E3U(KiryBCvngZzF85UN6xSDlOVweL4I9)
	if not exHviu6hcwoQRqTS4BbyYM7: return
	if yobpaW7sBqtKRrv(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ṉ") in aksIy7wNYp2W:
		octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṊ"),ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࡛࠭ࠨṋ")+e6HEdvUcaq8Gx+yRvqpKWFks+YVr6St5P4xsFC0aARQGKfiegD+iySORMYxWXszEH18(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩṌ"),yRvqpKWFks,Z9FPQvwlbjLTh(u"࠶࠼࠶ỹ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,tzZ6PhyDOUnwLM3pdK(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ṍ")+aksIy7wNYp2W)
		octplHnGwmE8bFqNdj7BiKvJ0VL(wwWzyF4ZpSQXKOgk569(u"ࠩࡩࡳࡱࡪࡥࡳࠩṎ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩṏ"),yRvqpKWFks,yobpaW7sBqtKRrv(u"࠷࠶࠷Ỻ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,mq5t9JXSdHT8yfDVF(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṐ")+aksIy7wNYp2W)
		octplHnGwmE8bFqNdj7BiKvJ0VL(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠬࡲࡩ࡯࡭ࠪṑ"),e6HEdvUcaq8Gx+yobpaW7sBqtKRrv(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫṒ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,bawK2j7T81Nrc4GWs05xzDg(u"࠹࠺࠻࠼ỻ"))
	for website in sorted(list(exHviu6hcwoQRqTS4BbyYM7[yRvqpKWFks].keys())):
		type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = exHviu6hcwoQRqTS4BbyYM7[yRvqpKWFks][website]
		if iySORMYxWXszEH18(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩṓ") in aksIy7wNYp2W or len(exHviu6hcwoQRqTS4BbyYM7[yRvqpKWFks])==wnaWTQM7VJPkZzO9eoSyFU4:
			NNFPsWDgoE(type,WnNGfosHr5STAq8j7miwyRZ6eOUbV,url,J5JYWPRlDouCt,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			A3pXVFdyP1.menuItemsLIST[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
			ayPo2rAct58buOZ,do9Jn4YIWwCH3bQtcR1V8ehgFK = A3pXVFdyP1.menuItemsLIST[:vXIdY7TwFKso40gVBq5],A3pXVFdyP1.menuItemsLIST[vXIdY7TwFKso40gVBq5:]
			if GHg28TBchiyn6l(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪṔ") in aksIy7wNYp2W:
				for JrM1DoSuQ5n8 in range(IMjqygdfYSKpHlWu5Aa(u"࠺Ỽ")): FxEWL1w4gjr8mM.shuffle(do9Jn4YIWwCH3bQtcR1V8ehgFK)
				A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK[:w7XRmZonrby]
			else: A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK
		elif XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪṕ") in aksIy7wNYp2W: octplHnGwmE8bFqNdj7BiKvJ0VL(oiWNFYzcIUeh(u"ࠪࡪࡴࡲࡤࡦࡴࠪṖ"),website,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
	return
def lOZwj39W8eVGp7QsN5oShIMtU4X(aksIy7wNYp2W,HOkAWvmZSP5c2t9Dq4NgELyps):
	aksIy7wNYp2W = aksIy7wNYp2W.replace(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ṗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(aiQwFE1TGx04vmLcsYkIW5jA(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṘ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	fzu7Got0FgiyshTlJK,do9Jn4YIWwCH3bQtcR1V8ehgFK = WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
	octplHnGwmE8bFqNdj7BiKvJ0VL(iySORMYxWXszEH18(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ṙ"),IMjqygdfYSKpHlWu5Aa(u"ࠧ࡜ࠩṚ")+e6HEdvUcaq8Gx+fzu7Got0FgiyshTlJK+YVr6St5P4xsFC0aARQGKfiegD+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪṛ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,HOkAWvmZSP5c2t9Dq4NgELyps,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,IMjqygdfYSKpHlWu5Aa(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṜ")+aksIy7wNYp2W)
	octplHnGwmE8bFqNdj7BiKvJ0VL(gPE1XB87fQl(u"ࠪࡪࡴࡲࡤࡦࡴࠪṝ"),bawK2j7T81Nrc4GWs05xzDg(u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫṞ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,HOkAWvmZSP5c2t9Dq4NgELyps,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,pp7FcjEe6g(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṟ")+aksIy7wNYp2W)
	octplHnGwmE8bFqNdj7BiKvJ0VL(oiWNFYzcIUeh(u"࠭࡬ࡪࡰ࡮ࠫṠ"),e6HEdvUcaq8Gx+mq5t9JXSdHT8yfDVF(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṡ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KLX7hW0nBAEgy6m4SvH(u"࠻࠼࠽࠾ỽ"))
	ayPo2rAct58buOZ = A3pXVFdyP1.menuItemsLIST[:]
	A3pXVFdyP1.menuItemsLIST[:] = []
	APpdhB1Fk58MmJH7CjVntowyaY = []
	if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩṢ") in aksIy7wNYp2W:
		TZxWMi4Ht7E3U(KiryBCvngZzF85UN6xSDlOVweL4I9)
		if not exHviu6hcwoQRqTS4BbyYM7: return
		lMV8bjPQqK0wOUotCdSgzkF1WRByvD = list(exHviu6hcwoQRqTS4BbyYM7.keys())
		yRvqpKWFks = FxEWL1w4gjr8mM.sample(lMV8bjPQqK0wOUotCdSgzkF1WRByvD,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		Wg2zKemM4Lv8XAECFpDOQrT7s = list(exHviu6hcwoQRqTS4BbyYM7[yRvqpKWFks].keys())
		website = FxEWL1w4gjr8mM.sample(Wg2zKemM4Lv8XAECFpDOQrT7s,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = exHviu6hcwoQRqTS4BbyYM7[yRvqpKWFks][website]
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤࠬṣ")+website+pp7FcjEe6g(u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ṥ")+fzu7Got0FgiyshTlJK+iySORMYxWXszEH18(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭ṥ")+url+beV5l2D8HznyJI0(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨṦ")+str(J5JYWPRlDouCt))
	elif yobpaW7sBqtKRrv(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭ṧ") in aksIy7wNYp2W:
		import e06e8au2ZV
		if not e06e8au2ZV.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
		for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
			APpdhB1Fk58MmJH7CjVntowyaY += YYsNSiFgXuKbGI1zqU2(str(A2N8BQZTY4p6XKygzOl7nD),aksIy7wNYp2W)
		if not APpdhB1Fk58MmJH7CjVntowyaY: return
		type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = FxEWL1w4gjr8mM.sample(APpdhB1Fk58MmJH7CjVntowyaY,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+wwWzyF4ZpSQXKOgk569(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧṨ")+fzu7Got0FgiyshTlJK+Z9FPQvwlbjLTh(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪṩ")+url+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬṪ")+str(J5JYWPRlDouCt))
	elif rVy3Ops0mohYkT(u"ࠪࡣࡒ࠹ࡕࡠࠩṫ") in aksIy7wNYp2W:
		import aEzp4cq7nd
		if not aEzp4cq7nd.iI5rl4JkL8Ks1go6fUxXN9w7tj(WnNGfosHr5STAq8j7miwyRZ6eOUbV,r0D4C3z7Onqpa): return
		for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
			APpdhB1Fk58MmJH7CjVntowyaY += CFvMd59yPm(str(A2N8BQZTY4p6XKygzOl7nD),aksIy7wNYp2W)
		if not APpdhB1Fk58MmJH7CjVntowyaY: return
		type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = FxEWL1w4gjr8mM.sample(APpdhB1Fk58MmJH7CjVntowyaY,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+KLX7hW0nBAEgy6m4SvH(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫṬ")+fzu7Got0FgiyshTlJK+rVy3Ops0mohYkT(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧṭ")+url+XwYZoICi4pSQ0Ousm6JGtcdzVB(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩṮ")+str(J5JYWPRlDouCt))
	PJ07v1lSNZafsjEtmkpwrC = fzu7Got0FgiyshTlJK
	MkxpRcEZzqjS = []
	for JrM1DoSuQ5n8 in range(j0jEZgiKdxFpMLHcU7kQr8v1lyX4,iySORMYxWXszEH18(u"࠴࠴Ỿ")):
		if JrM1DoSuQ5n8>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: SWPHEjbmMfZDpi(nsQAcj8eJHEw3xZ,q4qKXi5OPsFDoxlB7mkew(NTWE764hmOgUtScp2e8r)+yobpaW7sBqtKRrv(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧṯ")+fzu7Got0FgiyshTlJK+oiWNFYzcIUeh(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪṰ")+url+n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬṱ")+str(J5JYWPRlDouCt))
		A3pXVFdyP1.menuItemsLIST[:] = []
		if J5JYWPRlDouCt==VP70ytiFNMBl6vHDaW(u"࠶࠸࠺ỿ") and beV5l2D8HznyJI0(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫṲ") in ZVk6IphECKLzUceP15j: J5JYWPRlDouCt = jhDZ0BAFoEGUcw5QrJkaxXL(u"࠷࠹࠳ἀ")
		if J5JYWPRlDouCt==lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"࠽࠱࠵ἁ") and KLX7hW0nBAEgy6m4SvH(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫṳ") in ZVk6IphECKLzUceP15j: J5JYWPRlDouCt = I872Vum45fMNe1BRngTZLoQiqvkt(u"࠷࠲࠵ἂ")
		if J5JYWPRlDouCt==VP70ytiFNMBl6vHDaW(u"࠲࠶࠷ἃ"): J5JYWPRlDouCt = pp7FcjEe6g(u"࠴࠼࠵ἄ")
		PN2AmVoTyks5xOR1Ib9BqSQ = NNFPsWDgoE(type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f)
		if pp7FcjEe6g(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬṴ") in aksIy7wNYp2W and J5JYWPRlDouCt==YYQS36fyPvtuzcEmRL(u"࠴࠺࠼ἅ"): del A3pXVFdyP1.menuItemsLIST[:vXIdY7TwFKso40gVBq5]
		if mq5t9JXSdHT8yfDVF(u"࠭࡟ࡎ࠵ࡘࡣࠬṵ") in aksIy7wNYp2W and J5JYWPRlDouCt==pp7FcjEe6g(u"࠵࠻࠾ἆ"): del A3pXVFdyP1.menuItemsLIST[:vXIdY7TwFKso40gVBq5]
		do9Jn4YIWwCH3bQtcR1V8ehgFK[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
		if MkxpRcEZzqjS and QPFJWebEqtKMgTy(Z9FPQvwlbjLTh(u"ࡵࠨฯ็ๆฮ࠭Ṷ")) in str(do9Jn4YIWwCH3bQtcR1V8ehgFK) or QPFJWebEqtKMgTy(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࡶࠩะ่็ํࠧṷ")) in str(do9Jn4YIWwCH3bQtcR1V8ehgFK):
			fzu7Got0FgiyshTlJK = PJ07v1lSNZafsjEtmkpwrC
			do9Jn4YIWwCH3bQtcR1V8ehgFK[:] = MkxpRcEZzqjS
			break
		PJ07v1lSNZafsjEtmkpwrC = fzu7Got0FgiyshTlJK
		MkxpRcEZzqjS = do9Jn4YIWwCH3bQtcR1V8ehgFK
		if str(do9Jn4YIWwCH3bQtcR1V8ehgFK).count(gPE1XB87fQl(u"ࠩࡹ࡭ࡩ࡫࡯ࠨṸ"))>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: break
		if str(do9Jn4YIWwCH3bQtcR1V8ehgFK).count(XwYZoICi4pSQ0Ousm6JGtcdzVB(u"ࠪࡰ࡮ࡼࡥࠨṹ"))>j0jEZgiKdxFpMLHcU7kQr8v1lyX4: break
		if J5JYWPRlDouCt==ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"࠷࠹࠳ἇ"): break
		if J5JYWPRlDouCt==iySORMYxWXszEH18(u"࠽࠱࠴Ἀ"): break
		if J5JYWPRlDouCt==beV5l2D8HznyJI0(u"࠲࠺࠳Ἁ"): break
		if bawK2j7T81Nrc4GWs05xzDg(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ṻ") in aksIy7wNYp2W and do9Jn4YIWwCH3bQtcR1V8ehgFK: type,fzu7Got0FgiyshTlJK,url,J5JYWPRlDouCt,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f = FxEWL1w4gjr8mM.sample(do9Jn4YIWwCH3bQtcR1V8ehgFK,wnaWTQM7VJPkZzO9eoSyFU4)[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	if not fzu7Got0FgiyshTlJK: fzu7Got0FgiyshTlJK = jhDZ0BAFoEGUcw5QrJkaxXL(u"ࠬ࠴࠮࠯࠰ࠪṻ")
	elif fzu7Got0FgiyshTlJK.count(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"࠭࡟ࠨṼ"))>wnaWTQM7VJPkZzO9eoSyFU4: fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.split(lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ࠧࡠࠩṽ"),XURrDCfOS9Mbhpv2Pmjos56TeW)[XURrDCfOS9Mbhpv2Pmjos56TeW]
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(SI7eBdND4lx8pt5Qk(u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫṾ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	fzu7Got0FgiyshTlJK = fzu7Got0FgiyshTlJK.replace(ZXHmhwUT31CuOMgAsJbkQyLi6jGVeN(u"ࠩࡢࡑࡔࡊ࡟ࠨṿ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	ayPo2rAct58buOZ[j0jEZgiKdxFpMLHcU7kQr8v1lyX4][wnaWTQM7VJPkZzO9eoSyFU4] = iySORMYxWXszEH18(u"ࠪ࡟ࠬẀ")+e6HEdvUcaq8Gx+fzu7Got0FgiyshTlJK+YVr6St5P4xsFC0aARQGKfiegD+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠫࠥࡀวๅไึ้ࡢ࠭ẁ")
	if GHg28TBchiyn6l(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧẂ") in aksIy7wNYp2W:
		for JrM1DoSuQ5n8 in range(pp7FcjEe6g(u"࠺Ἂ")): FxEWL1w4gjr8mM.shuffle(do9Jn4YIWwCH3bQtcR1V8ehgFK)
		A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK[:w7XRmZonrby]
	else: A3pXVFdyP1.menuItemsLIST[:] = ayPo2rAct58buOZ+do9Jn4YIWwCH3bQtcR1V8ehgFK
	return
def Z3nbgCzLMXBm1yuGv5HQ9p(Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8):
	q0xFOEk24mYocja7P8 = q0xFOEk24mYocja7P8.replace(oiWNFYzcIUeh(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨẃ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(YYQS36fyPvtuzcEmRL(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẄ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	svRZ8iTtlWH1UdzJ = q0xFOEk24mYocja7P8
	if aiQwFE1TGx04vmLcsYkIW5jA(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩẅ") in q0xFOEk24mYocja7P8:
		svRZ8iTtlWH1UdzJ = q0xFOEk24mYocja7P8.split(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪẆ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		type = n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ẇ")
	elif gPE1XB87fQl(u"࡛ࠫࡕࡄࠨẈ") in Fg4t51OJWnaKTAdui: type = bawK2j7T81Nrc4GWs05xzDg(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨẉ")
	elif jhDZ0BAFoEGUcw5QrJkaxXL(u"࠭ࡌࡊࡘࡈࠫẊ") in Fg4t51OJWnaKTAdui: type = tzZ6PhyDOUnwLM3pdK(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨẋ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(ZLr5gRSkFewKdUos90bM(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẌ"),Z9FPQvwlbjLTh(u"ࠩ࡞ࠫẍ")+e6HEdvUcaq8Gx+type+svRZ8iTtlWH1UdzJ+YVr6St5P4xsFC0aARQGKfiegD+I872Vum45fMNe1BRngTZLoQiqvkt(u"ࠪࠤ࠿อไใี่ࡡࠬẎ"),Fg4t51OJWnaKTAdui,VP70ytiFNMBl6vHDaW(u"࠳࠹࠻Ἃ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,VP70ytiFNMBl6vHDaW(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẏ")+q0xFOEk24mYocja7P8)
	octplHnGwmE8bFqNdj7BiKvJ0VL(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẐ"),Z9FPQvwlbjLTh(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬẑ"),Fg4t51OJWnaKTAdui,SI7eBdND4lx8pt5Qk(u"࠴࠺࠼Ἄ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,yobpaW7sBqtKRrv(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬẒ")+q0xFOEk24mYocja7P8)
	octplHnGwmE8bFqNdj7BiKvJ0VL(aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠨ࡮࡬ࡲࡰ࠭ẓ"),e6HEdvUcaq8Gx+oiWNFYzcIUeh(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧẔ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"࠽࠾࠿࠹Ἅ"))
	import e06e8au2ZV
	for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
		if IMjqygdfYSKpHlWu5Aa(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫẕ") in q0xFOEk24mYocja7P8: e06e8au2ZV.T3TJbgU6X1PzdENmp(str(A2N8BQZTY4p6XKygzOl7nD),Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9)
		else: e06e8au2ZV.f28uNr4CYyMqT(str(A2N8BQZTY4p6XKygzOl7nD),Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9)
	A3pXVFdyP1.menuItemsLIST[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
	if len(A3pXVFdyP1.menuItemsLIST)>(w7XRmZonrby+vXIdY7TwFKso40gVBq5): A3pXVFdyP1.menuItemsLIST[:] = A3pXVFdyP1.menuItemsLIST[:vXIdY7TwFKso40gVBq5]+FxEWL1w4gjr8mM.sample(A3pXVFdyP1.menuItemsLIST[vXIdY7TwFKso40gVBq5:],w7XRmZonrby)
	return
def EH0i2xfRJX4jeDUN18nGgCuBAWhMK(Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8):
	q0xFOEk24mYocja7P8 = q0xFOEk24mYocja7P8.replace(CyHU86ZeYT5BWRcitSm2I(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẖ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace(n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẗ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	svRZ8iTtlWH1UdzJ = q0xFOEk24mYocja7P8
	if iySORMYxWXszEH18(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ẘ") in q0xFOEk24mYocja7P8:
		svRZ8iTtlWH1UdzJ = q0xFOEk24mYocja7P8.split(QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧẙ"))[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
		type = rVy3Ops0mohYkT(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫẚ")
	elif n1JzUNV2FIKgpMvQo6hcA578uZqrX(u"࡙ࠩࡓࡉ࠭ẛ") in Fg4t51OJWnaKTAdui: type = aPpWCJYFzeijsDN6Txl7Mqth3ry5(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭ẜ")
	elif QQH5IeP4UuCAp1VwKDLxEWrvjFc(u"ࠫࡑࡏࡖࡆࠩẝ") in Fg4t51OJWnaKTAdui: type = SI7eBdND4lx8pt5Qk(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭ẞ")
	octplHnGwmE8bFqNdj7BiKvJ0VL(gPE1XB87fQl(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẟ"),yobpaW7sBqtKRrv(u"ࠧ࡜ࠩẠ")+e6HEdvUcaq8Gx+type+svRZ8iTtlWH1UdzJ+YVr6St5P4xsFC0aARQGKfiegD+rVy3Ops0mohYkT(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪạ"),Fg4t51OJWnaKTAdui,bawK2j7T81Nrc4GWs05xzDg(u"࠶࠼࠸Ἆ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,beV5l2D8HznyJI0(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧẢ")+q0xFOEk24mYocja7P8)
	octplHnGwmE8bFqNdj7BiKvJ0VL(oiWNFYzcIUeh(u"ࠪࡪࡴࡲࡤࡦࡴࠪả"),gPE1XB87fQl(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪẤ"),Fg4t51OJWnaKTAdui,beV5l2D8HznyJI0(u"࠷࠶࠹Ἇ"),WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gPE1XB87fQl(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪấ")+q0xFOEk24mYocja7P8)
	octplHnGwmE8bFqNdj7BiKvJ0VL(CyHU86ZeYT5BWRcitSm2I(u"࠭࡬ࡪࡰ࡮ࠫẦ"),e6HEdvUcaq8Gx+wwWzyF4ZpSQXKOgk569(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬầ")+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,rVy3Ops0mohYkT(u"࠹࠺࠻࠼ἐ"))
	import aEzp4cq7nd
	for A2N8BQZTY4p6XKygzOl7nD in range(wnaWTQM7VJPkZzO9eoSyFU4,ekgSRBGHWzUI5MqNDQV190ay8LonOp+wnaWTQM7VJPkZzO9eoSyFU4):
		if CyHU86ZeYT5BWRcitSm2I(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨẨ") in q0xFOEk24mYocja7P8: aEzp4cq7nd.T3TJbgU6X1PzdENmp(str(A2N8BQZTY4p6XKygzOl7nD),Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9)
		else: aEzp4cq7nd.f28uNr4CYyMqT(str(A2N8BQZTY4p6XKygzOl7nD),Fg4t51OJWnaKTAdui,q0xFOEk24mYocja7P8,WnNGfosHr5STAq8j7miwyRZ6eOUbV,KiryBCvngZzF85UN6xSDlOVweL4I9)
	A3pXVFdyP1.menuItemsLIST[:] = GJo05mBZUnxy(A3pXVFdyP1.menuItemsLIST)
	if len(A3pXVFdyP1.menuItemsLIST)>(w7XRmZonrby+vXIdY7TwFKso40gVBq5): A3pXVFdyP1.menuItemsLIST[:] = A3pXVFdyP1.menuItemsLIST[:vXIdY7TwFKso40gVBq5]+FxEWL1w4gjr8mM.sample(A3pXVFdyP1.menuItemsLIST[vXIdY7TwFKso40gVBq5:],w7XRmZonrby)
	return
def GJo05mBZUnxy(wtC5Ny1preI9KoYusDk23xBmHQi):
	x3fSXBVI0OLGMt = []
	for type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f in wtC5Ny1preI9KoYusDk23xBmHQi:
		if lzSXWkhtdnu5sr3U8AV42vwDJ7ip(u"ุࠩๅาฯࠧẩ") in fzu7Got0FgiyshTlJK or kdRO82AImh0LFw(u"ูࠪๆำ็ࠨẪ") in fzu7Got0FgiyshTlJK or GHg28TBchiyn6l(u"ࠫࡵࡧࡧࡦࠩẫ") in fzu7Got0FgiyshTlJK.lower(): continue
		x3fSXBVI0OLGMt.append([type,fzu7Got0FgiyshTlJK,url,HOkAWvmZSP5c2t9Dq4NgELyps,bLhqw36zAp7uKxJIM4r502UGRT,TB3DI4JWr0NYmik1xO8Kc2,ZVk6IphECKLzUceP15j,SDUJm78sZBG,AUBZYG84NbOKsRnxi6jgk2f])
	return x3fSXBVI0OLGMt