# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'FASELHD1'
headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV}
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_FH1_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['جوائز الأوسكار','المراجعات','wwe']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==570: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==571: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==572: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==573: APpdhB1Fk58MmJH7CjVntowyaY = GWZnSU3af6H4mhzrElwA9(url,text)
	elif mode==576: APpdhB1Fk58MmJH7CjVntowyaY = chIvjnxOm8MEiLgQD()
	elif mode==579: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+'لماذا الموقع بطيء',WnNGfosHr5STAq8j7miwyRZ6eOUbV,576)
	VVDAncSMUjeu8Ii,url = pcE6DxaoHBm41WKXjwnk,pcE6DxaoHBm41WKXjwnk
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD1-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',VVDAncSMUjeu8Ii,579,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',VVDAncSMUjeu8Ii,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured1')
	items = p7dwlH1PRStBgyMUW.findall('class="h3">(.*?)<.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for title,SOw5EUxC9k in items:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'details1')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"menu-primary"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		QQSoCIghku5DA = p7dwlH1PRStBgyMUW.findall('<li (.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		cGKdUpYvBhQRuDPNzE5snTHfM6J2jy = [WnNGfosHr5STAq8j7miwyRZ6eOUbV,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		zuEo6GDeAR5Z = 0
		for xolUtmyJWcC0eR7 in QQSoCIghku5DA:
			if zuEo6GDeAR5Z>0: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',xolUtmyJWcC0eR7,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if SOw5EUxC9k=='#': continue
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+SOw5EUxC9k
				if title==WnNGfosHr5STAq8j7miwyRZ6eOUbV: continue
				if any(value in title.lower() for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
				title = cGKdUpYvBhQRuDPNzE5snTHfM6J2jy[zuEo6GDeAR5Z]+title
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'details2')
			zuEo6GDeAR5Z += 1
	return
def chIvjnxOm8MEiLgQD():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD1-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ZAIyluJa1EWhdB7OHV5CRGSrk = p7dwlH1PRStBgyMUW.findall('class="h4">(.*?)</div>(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not ZAIyluJa1EWhdB7OHV5CRGSrk: return
	if type=='filters':
		cKUQVwTMe9tZSY = [piN9Qlah4S.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"homeSlide"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		Db5GKmQEPvL6pZUWg91CqMrfRIj3Y,laAHpo1bzyM0q,trNPCKLEgm = zip(*items)
		items = zip(laAHpo1bzyM0q,Db5GKmQEPvL6pZUWg91CqMrfRIj3Y,trNPCKLEgm)
	elif type=='featured2':
		title,KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='details2' and len(ZAIyluJa1EWhdB7OHV5CRGSrk)>1:
		title = ZAIyluJa1EWhdB7OHV5CRGSrk[0][0]
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured2')
		title = ZAIyluJa1EWhdB7OHV5CRGSrk[1][0]
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'details3')
		return
	else:
		title,KDCdHQmgxPE21tYz4VUowSv = ZAIyluJa1EWhdB7OHV5CRGSrk[-1]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		if any(value in title.lower() for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
		J4tO21KYAVdSr67W5NmiD0XhRP = clFjTSgMODe7Nq0H3Vzs(J4tO21KYAVdSr67W5NmiD0XhRP)
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.split('?resize=')[0]
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|حلقة).\d+',title,p7dwlH1PRStBgyMUW.DOTALL)
		if '/collections/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,571,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif er96jwp52cbvaV48mtylEYSRz and type==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
			title = '_MOD_'+er96jwp52cbvaV48mtylEYSRz[0][0]
			title = title.strip(' –')
			if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,573,J4tO21KYAVdSr67W5NmiD0XhRP)
				cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif 'episodes/' in SOw5EUxC9k or 'movies/' in SOw5EUxC9k or 'hindi/' in SOw5EUxC9k:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,572,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,573,J4tO21KYAVdSr67W5NmiD0XhRP)
	if type=='filters':
		qqeo9DwgEIuKJfdFvm8r63XO5anT = p7dwlH1PRStBgyMUW.findall('"more_button_page":(.*?),',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if qqeo9DwgEIuKJfdFvm8r63XO5anT:
			count = qqeo9DwgEIuKJfdFvm8r63XO5anT[0]
			SOw5EUxC9k = url+'/offset/'+count
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة أخرى',SOw5EUxC9k,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filters')
	elif 'details' in type:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("class='pagination(.*?)</div>",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall("href='(.*?)'.*?>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				title = 'صفحة '+VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,571,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'details4')
	return
def GWZnSU3af6H4mhzrElwA9(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD1-SEASONS_EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	EPtkQ9LnpUrjNsy = False
	if not type:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"seasonList"(.*?)"container"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			if len(items)>1:
				VVDAncSMUjeu8Ii = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
				EPtkQ9LnpUrjNsy = True
				for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,name,title in items:
					name = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(name)
					if 'http' not in SOw5EUxC9k: SOw5EUxC9k = VVDAncSMUjeu8Ii+SOw5EUxC9k
					title = name+' - '+title
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,573,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'episodes')
	if type=='episodes' or not EPtkQ9LnpUrjNsy:
		bLhqw36zAp7uKxJIM4r502UGRT = p7dwlH1PRStBgyMUW.findall('"posterImg".*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if bLhqw36zAp7uKxJIM4r502UGRT: J4tO21KYAVdSr67W5NmiD0XhRP = bLhqw36zAp7uKxJIM4r502UGRT[0]
		else: J4tO21KYAVdSr67W5NmiD0XhRP = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"epAll"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,572,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	wxT9bCdumN,RRHs7TOLv3ENht8l6,cNmp4onf9T1FlKs6yreGQvCudP0 = [],[],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FASELHD1-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	XnSt7DH8vsEKmBFdMerGUTP9Oz564 = p7dwlH1PRStBgyMUW.findall('مستوى المشاهدة.*?">(.*?)</span>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if XnSt7DH8vsEKmBFdMerGUTP9Oz564:
		oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('"tag">(.*?)</a>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"videoRow"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k in items:
			SOw5EUxC9k = SOw5EUxC9k.split('&img=')[0]
			wxT9bCdumN.append(SOw5EUxC9k+'?named=__embed')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="streamHeader(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall("href = '(.*?)'.*?</i>(.*?)</a>",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name in items:
			SOw5EUxC9k = SOw5EUxC9k.split('&img=')[0]
			name = name.strip(kcXMWrwiLDKeBHRsJ)
			wxT9bCdumN.append(SOw5EUxC9k+'?named='+name+'__watch')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="downloadLinks(.*?)blackwindow',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</span>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,name in items:
			SOw5EUxC9k = SOw5EUxC9k.split('&img=')[0]
			wxT9bCdumN.append(SOw5EUxC9k+'?named='+name+'__download')
	for fzCsdrHpZb4G6Q8aMNt in wxT9bCdumN:
		SOw5EUxC9k,name = fzCsdrHpZb4G6Q8aMNt.split('?named')
		if SOw5EUxC9k not in RRHs7TOLv3ENht8l6:
			RRHs7TOLv3ENht8l6.append(SOw5EUxC9k)
			cNmp4onf9T1FlKs6yreGQvCudP0.append(fzCsdrHpZb4G6Q8aMNt)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(cNmp4onf9T1FlKs6yreGQvCudP0,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1,'details5')
	return