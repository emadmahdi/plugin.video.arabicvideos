# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
NTWE764hmOgUtScp2e8r = 'AKWAM'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_AKW_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
gifOZ8bLkIK64eEUTjyhJ1PdV = WnNGfosHr5STAq8j7miwyRZ6eOUbV
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==240: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==241: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==242: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==243: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==244: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'FILTERS___'+text)
	elif mode==245: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'CATEGORIES___'+text)
	elif mode==246: APpdhB1Fk58MmJH7CjVntowyaY = ttC6U7sZqg48azE5IlrFByfM(url)
	elif mode==247: APpdhB1Fk58MmJH7CjVntowyaY = rIoBxlFOHYUJhQS4c29wWC6sytb(url)
	elif mode==248: APpdhB1Fk58MmJH7CjVntowyaY = W43HnJzwXA8()
	elif mode==249: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def W43HnJzwXA8():
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKWAM-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	pptX0BYZ7AHhFJeEL = p7dwlH1PRStBgyMUW.findall('home-site-btn-container.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if pptX0BYZ7AHhFJeEL: pptX0BYZ7AHhFJeEL = pptX0BYZ7AHhFJeEL[0]
	else: pptX0BYZ7AHhFJeEL = pcE6DxaoHBm41WKXjwnk
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pptX0BYZ7AHhFJeEL,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKWAM-MENU-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,249,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',pcE6DxaoHBm41WKXjwnk,246)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',pcE6DxaoHBm41WKXjwnk,247)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',pptX0BYZ7AHhFJeEL,241,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	g8rFIfujTPn2m = p7dwlH1PRStBgyMUW.findall('recently-container.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	SOw5EUxC9k = g8rFIfujTPn2m[0]
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أضيف حديثا',SOw5EUxC9k,241)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,name,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
		if name in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+name,SOw5EUxC9k,241)
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			title = name+kcXMWrwiLDKeBHRsJ+title
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,241)
	return
def ttC6U7sZqg48azE5IlrFByfM(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKWAM-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu(.*?)<nav',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?text">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
				title = title+' مصنفة'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,245)
		if website==WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return piN9Qlah4S
def rIoBxlFOHYUJhQS4c29wWC6sytb(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKWAM-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu(.*?)<nav',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?text">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
				title = title+' مفلترة'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,244)
		if website==WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('swiper-container(.*?)swiper-button-prev',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="widget"(.*?)main-footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if not items:
			items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
			if '/series/' in SOw5EUxC9k or '/shows/' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,242,J4tO21KYAVdSr67W5NmiD0XhRP)
			elif '/movies/' in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,243,J4tO21KYAVdSr67W5NmiD0XhRP)
			elif '/games/' not in SOw5EUxC9k:
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,243,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,241)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	url = pcE6DxaoHBm41WKXjwnk + '/search?q='+DqbrOGw4giHUvfuFtRXQ5lA0yN
	APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in piN9Qlah4S:
		J4tO21KYAVdSr67W5NmiD0XhRP = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Icon')
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+'رابط التشغيل',url,243,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('-episodes">(.*?)<div class="widget-4',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		cTmHXhoJ60 = p7dwlH1PRStBgyMUW.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title,J4tO21KYAVdSr67W5NmiD0XhRP in cTmHXhoJ60:
			title = title.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,242,J4tO21KYAVdSr67W5NmiD0XhRP)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,243,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKWAM-PLAY-1st')
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('badge-danger.*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	HHvCRdTkabZMeoEhlI9rKFqpsg71 = p7dwlH1PRStBgyMUW.findall('li><a href="#(.*?)".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn,UOqp25uxcISGBPlAfbtzCNWXY4nvK,z2LHjAV8QpckJ3omZuaYGqX7 = [],[],[],[]
	if HHvCRdTkabZMeoEhlI9rKFqpsg71:
		P4cqC2X0dpeHbg3KW = 'mp4'
		for MYPxvnhJ8sIiWw0f4t7LTX9GdaA,DIBw28Qfje76bTMzVNYhxrgWmO in HHvCRdTkabZMeoEhlI9rKFqpsg71:
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('tab-content quality" id="'+MYPxvnhJ8sIiWw0f4t7LTX9GdaA+'".*?</div>.\s*</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			UOqp25uxcISGBPlAfbtzCNWXY4nvK.append(KDCdHQmgxPE21tYz4VUowSv)
			z2LHjAV8QpckJ3omZuaYGqX7.append(DIBw28Qfje76bTMzVNYhxrgWmO)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="qualities(.*?)<h3.*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if not cKUQVwTMe9tZSY:
			BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			KDCdHQmgxPE21tYz4VUowSv,filename = cKUQVwTMe9tZSY[0]
			LZr6GwdxhyNIsJqb5R = ['zip','rar','txt','pdf','htm','tar','iso','html']
			P4cqC2X0dpeHbg3KW = filename.rsplit('.',1)[1].strip(kcXMWrwiLDKeBHRsJ)
			if P4cqC2X0dpeHbg3KW in LZr6GwdxhyNIsJqb5R:
				BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,'الملف ليس فيديو ولا صوت')
				return
		UOqp25uxcISGBPlAfbtzCNWXY4nvK.append(KDCdHQmgxPE21tYz4VUowSv)
		z2LHjAV8QpckJ3omZuaYGqX7.append(WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	for JrM1DoSuQ5n8 in range(len(UOqp25uxcISGBPlAfbtzCNWXY4nvK)):
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?icon-(.*?)"',UOqp25uxcISGBPlAfbtzCNWXY4nvK[JrM1DoSuQ5n8],p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,g2uQYMKJpmzIaldPe7WkRGHt in laAHpo1bzyM0q:
			if 'torrent' in g2uQYMKJpmzIaldPe7WkRGHt: continue
			elif 'download' in g2uQYMKJpmzIaldPe7WkRGHt: type = 'download'
			elif 'play' in g2uQYMKJpmzIaldPe7WkRGHt: type = 'watch'
			else: type = 'unknown'
			SOw5EUxC9k = SOw5EUxC9k+'?named=__'+type+'____'+z2LHjAV8QpckJ3omZuaYGqX7[JrM1DoSuQ5n8]+'__akwam'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	tqgKeQMz5XNvBPZAE6DCxfaLbj = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='CATEGORIES':
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'all')
		vcQbFfCk6T1 = url+'?'+CdZwuO45sE7UvlbM
	elif type=='FILTERS':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'all')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها',vcQbFfCk6T1,241,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,241,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKWAM-FILTERS_MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<form id(.*?)</form>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	dict = {}
	for LgJITEZU95fS2oi8K,name,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		items = p7dwlH1PRStBgyMUW.findall('<option(.*?)>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='CATEGORIES':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<=1:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'CATEGORIES___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,241,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,245,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='FILTERS':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع : '+name,vcQbFfCk6T1,244,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if 'value' not in value: value = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			else: value = p7dwlH1PRStBgyMUW.findall('"(.*?)"',value,p7dwlH1PRStBgyMUW.DOTALL)[0]
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' : '#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' : '+name
			if type=='FILTERS': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,244,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='CATEGORIES' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'all')
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'?'+CdZwuO45sE7UvlbM
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,241,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,245,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	wQyTn0NR9VkaBSCrDzPsqMl = ['section','category','rating','year','language','formats','quality']
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	return CZewXSEQ3q