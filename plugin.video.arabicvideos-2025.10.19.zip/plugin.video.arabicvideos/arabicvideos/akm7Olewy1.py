# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'TVFUN'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_TVF_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['بث مباشر']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==460: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==461: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==462: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==463: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==469: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TVFUN-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,469,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"menu-btn"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?<span>(.*?)</span>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,461)
	return
def ctDj2OVRyaUPXCrITmJG(url,SUm0TCBiv7ck8sDMhOp=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	items = []
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TVFUN-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="head-title"(.*?)id="footer"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
		gbtIyQYJ854dkEhXfaev = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
			title = '_MOD_'+title.replace('<br>',kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).strip(kcXMWrwiLDKeBHRsJ)
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k)
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) الحلقة \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if any(value in title for value in gbtIyQYJ854dkEhXfaev):
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,462,J4tO21KYAVdSr67W5NmiD0XhRP)
			elif er96jwp52cbvaV48mtylEYSRz and 'الحلقة' in title:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,463,J4tO21KYAVdSr67W5NmiD0XhRP)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,463,J4tO21KYAVdSr67W5NmiD0XhRP)
	if SUm0TCBiv7ck8sDMhOp!='latest':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('<a href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				SOw5EUxC9k = SOw5EUxC9k.strip(kcXMWrwiLDKeBHRsJ)
				if SOw5EUxC9k=="": continue
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
				if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,461)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TVFUN-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="head-title"(.*?)id="footer"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if items:
			for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
				title = '_MOD_'+title.replace('<br>',kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).strip(kcXMWrwiLDKeBHRsJ)
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,462,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			items = p7dwlH1PRStBgyMUW.findall('class="episode.*?href="(.*?)" title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,462)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = SOw5EUxC9k.strip(kcXMWrwiLDKeBHRsJ)
			if SOw5EUxC9k=="": continue
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,463)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u = []
	vcQbFfCk6T1 = url.replace('/video/','/watch/')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TVFUN-PLAY-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('VideoServers"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		laAHpo1bzyM0q = p7dwlH1PRStBgyMUW.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for ZU85vflDYNAzWexn1tjXVrwORcbE,name in laAHpo1bzyM0q:
			ZU85vflDYNAzWexn1tjXVrwORcbE = ZU85vflDYNAzWexn1tjXVrwORcbE[2:]
			if YVzokG2yZqrh3w8bU: ZU85vflDYNAzWexn1tjXVrwORcbE = ZU85vflDYNAzWexn1tjXVrwORcbE.decode(e87cIA5vwOQLDEP1)
			ZU85vflDYNAzWexn1tjXVrwORcbE = uvGCPpFwVmTQ36.b64decode(ZU85vflDYNAzWexn1tjXVrwORcbE)
			if rJ2oTLqabRtA: ZU85vflDYNAzWexn1tjXVrwORcbE = ZU85vflDYNAzWexn1tjXVrwORcbE.decode(e87cIA5vwOQLDEP1)
			SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('src="(.*?)"',ZU85vflDYNAzWexn1tjXVrwORcbE,p7dwlH1PRStBgyMUW.DOTALL)
			SOw5EUxC9k = SOw5EUxC9k[0]
			if 'http' not in SOw5EUxC9k:
				if '//' in SOw5EUxC9k: SOw5EUxC9k = 'http:'+SOw5EUxC9k
				else: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			if SOw5EUxC9k not in M0MFkiKqJDv1aZ4NA396u:
				SOw5EUxC9k = SOw5EUxC9k+'?named='+name+'__watch'
				M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not search: return
	if kcXMWrwiLDKeBHRsJ in search:
		if showDialogs: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = pcE6DxaoHBm41WKXjwnk+'/q/'+search+'/'
	ctDj2OVRyaUPXCrITmJG(url)
	return