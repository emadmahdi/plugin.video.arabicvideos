# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'EGYBEST4'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_EB4_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,TB3DI4JWr0NYmik1xO8Kc2,text):
	if   mode==800: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==801: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==802: APpdhB1Fk58MmJH7CjVntowyaY = uJlhLk2Tbcd(url)
	elif mode==803: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==804: APpdhB1Fk58MmJH7CjVntowyaY = IVudfRLF0xhc1kotSw65M(url)
	elif mode==806: APpdhB1Fk58MmJH7CjVntowyaY = GWZnSU3af6H4mhzrElwA9(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==809: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,809,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر',pcE6DxaoHBm41WKXjwnk+'/trending',804,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('nav-categories(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('mainContent(.*?)<footer>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'mainmenu')
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('main-menu(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			if any(value in title for value in EViWBhSw3dea8pTUO9AFMKbGjks027): continue
			if 'http' not in SOw5EUxC9k: SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801)
	return piN9Qlah4S
def GWZnSU3af6H4mhzrElwA9(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-SEASONS_EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('mainTitle.*?>(.*?)<(.*?)pageContent',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		EPtkQ9LnpUrjNsy,cTmHXhoJ60,items = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,[]
		for name,KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
			if 'حلقات' in name: cTmHXhoJ60 = KDCdHQmgxPE21tYz4VUowSv
			if 'مواسم' in name: EPtkQ9LnpUrjNsy = KDCdHQmgxPE21tYz4VUowSv
		if EPtkQ9LnpUrjNsy and not type:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',EPtkQ9LnpUrjNsy,p7dwlH1PRStBgyMUW.DOTALL)
			if len(items)>1:
				for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,806,J4tO21KYAVdSr67W5NmiD0XhRP,'season')
		if cTmHXhoJ60 and len(items)<2:
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',cTmHXhoJ60,p7dwlH1PRStBgyMUW.DOTALL)
			if items:
				for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
					octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,803,J4tO21KYAVdSr67W5NmiD0XhRP)
			else:
				items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',cTmHXhoJ60,p7dwlH1PRStBgyMUW.DOTALL)
				for SOw5EUxC9k,title in items:
					octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,803)
	return
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	IISWAzUg18xVsPiNykMh2ce4JXEKZY,start,nxeRBuVLTiHaSJEp30XN5P4dbG,select,LCoIBVptlEeYZ9OTgG = 0,0,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	if 'pagination' in type:
		czVwBfq0NCDLFG8nW4lmahH5Z,bZ0VWjAHm1v2Csroh = url.split('?next=page&')
		W67hPCcaOek094 = {'Content-Type':'application/x-www-form-urlencoded'}
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'POST',czVwBfq0NCDLFG8nW4lmahH5Z,bZ0VWjAHm1v2Csroh,W67hPCcaOek094,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-TITLES-1st')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		hFYoSTas7WOVnwN = 'secContent'+piN9Qlah4S+'<footer>'
	else:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-TITLES-2nd')
		piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
		hFYoSTas7WOVnwN = piN9Qlah4S
	items,Np9dB7DzFAZjWXxTYUbIuG,KKpNlBa9cUqmk07 = [],False,False
	if not type and '/collections' not in url:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('mainContent(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?</i>(.*?)</a>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				title = title.strip(kcXMWrwiLDKeBHRsJ)
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'submenu')
				Np9dB7DzFAZjWXxTYUbIuG = True
	if not Np9dB7DzFAZjWXxTYUbIuG:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('secContent(.*?)mainContent',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
				SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k)
				J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.strip(WBDnh75CaLEvkcN6p4ez2KXrV3M)
				title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
				if '/series/' in SOw5EUxC9k and type=='season': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,806,J4tO21KYAVdSr67W5NmiD0XhRP,'season')
				elif '/series/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,806,J4tO21KYAVdSr67W5NmiD0XhRP)
				elif '/seasons/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801,J4tO21KYAVdSr67W5NmiD0XhRP,'season')
				elif '/collections' in url: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801,J4tO21KYAVdSr67W5NmiD0XhRP,'collections')
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,803,J4tO21KYAVdSr67W5NmiD0XhRP)
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('loadMoreParams = (.*?);',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			Vgy0Y3N6X8DOIxczQAl = IXZpzK7ShaRsAN('dict',KDCdHQmgxPE21tYz4VUowSv)
			LCoIBVptlEeYZ9OTgG = Vgy0Y3N6X8DOIxczQAl['ajaxurl']
			qqeo9DwgEIuKJfdFvm8r63XO5anT = int(Vgy0Y3N6X8DOIxczQAl['current_page'])+1
			GaHRZ1MnfcCsAYvozSL9u7D = int(Vgy0Y3N6X8DOIxczQAl['max_page'])
			fFnoc7M80GhruyYJRDASlkqb = Vgy0Y3N6X8DOIxczQAl['posts'].replace('False','false').replace('True','true').replace('None','null')
			if qqeo9DwgEIuKJfdFvm8r63XO5anT<GaHRZ1MnfcCsAYvozSL9u7D:
				bZ0VWjAHm1v2Csroh = 'action=loadmore&query='+ZisgmEGCOJxVI9DcetNBPo6(fFnoc7M80GhruyYJRDASlkqb,WnNGfosHr5STAq8j7miwyRZ6eOUbV)+'&page='+str(qqeo9DwgEIuKJfdFvm8r63XO5anT)
				vcQbFfCk6T1 = LCoIBVptlEeYZ9OTgG+'?next=page&'+bZ0VWjAHm1v2Csroh
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'جلب المزيد',vcQbFfCk6T1,801,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'pagination_'+type)
		elif '?next=page&' in url:
			bZ0VWjAHm1v2Csroh,c6sSHKew8MFqkh7fDuAC24aBjnRXGp = bZ0VWjAHm1v2Csroh.rsplit('=',1)
			c6sSHKew8MFqkh7fDuAC24aBjnRXGp = int(c6sSHKew8MFqkh7fDuAC24aBjnRXGp)+1
			vcQbFfCk6T1 = czVwBfq0NCDLFG8nW4lmahH5Z+'?next=page&'+bZ0VWjAHm1v2Csroh+'='+str(c6sSHKew8MFqkh7fDuAC24aBjnRXGp)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'جلب المزيد',vcQbFfCk6T1,801,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'pagination_'+type)
	return
def IVudfRLF0xhc1kotSw65M(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-FILTERS-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('sub_nav(.*?)secContent ',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('"current_opt">(.*?)<(.*?)</div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for name,KDCdHQmgxPE21tYz4VUowSv in UOqp25uxcISGBPlAfbtzCNWXY4nvK:
			if 'التصنيف' in name: continue
			name = name.strip(kcXMWrwiLDKeBHRsJ)
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,value in items:
				title = name+':  '+value
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,801,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'filter')
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(XAGWNdKH4qOPU1YEVQp6,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'EGYBEST4-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('<td>التصنيف</td>.*?">(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	wxT9bCdumN,kEWFnrhoHy5iXCjKzTegVmsclO = [],[]
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('postEmbed.*?src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if SOw5EUxC9k:
		SOw5EUxC9k = SOw5EUxC9k[0].replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		kEWFnrhoHy5iXCjKzTegVmsclO.append(SOw5EUxC9k)
		VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
		wxT9bCdumN.append(SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__embed')
	N47rkWAtRHPCX8wU1on6ed = p7dwlH1PRStBgyMUW.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if N47rkWAtRHPCX8wU1on6ed:
		LCoIBVptlEeYZ9OTgG,YQU9rmMqC0LWkcxaFpZos7VdRg = N47rkWAtRHPCX8wU1on6ed[0]
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('postPlayer(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			HFl2IcRSfr3zwu97mNdZTM60DyiAb = p7dwlH1PRStBgyMUW.findall('<li.*?id\,(.*?)\);">(.*?)</li>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for Z52mvLcB8Qr3WetXVApiHb,name in HFl2IcRSfr3zwu97mNdZTM60DyiAb:
				SOw5EUxC9k = LCoIBVptlEeYZ9OTgG+'/temp/ajax/iframe.php?id='+YQU9rmMqC0LWkcxaFpZos7VdRg+'&video='+Z52mvLcB8Qr3WetXVApiHb
				wxT9bCdumN.append(SOw5EUxC9k+'?named='+name+'__watch')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pageContentDown(.*?)</table>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for DIBw28Qfje76bTMzVNYhxrgWmO,SOw5EUxC9k in items:
			if SOw5EUxC9k not in kEWFnrhoHy5iXCjKzTegVmsclO:
				if '/?url=' in SOw5EUxC9k: SOw5EUxC9k = SOw5EUxC9k.split('/?url=')[1]
				kEWFnrhoHy5iXCjKzTegVmsclO.append(SOw5EUxC9k)
				VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(SOw5EUxC9k,'name')
				wxT9bCdumN.append(SOw5EUxC9k+'?named='+VVpQfHc7IZamxweON3WXKU6Fg+'__download____'+DIBw28Qfje76bTMzVNYhxrgWmO)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not search: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if not search: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/?s='+DqbrOGw4giHUvfuFtRXQ5lA0yN
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return