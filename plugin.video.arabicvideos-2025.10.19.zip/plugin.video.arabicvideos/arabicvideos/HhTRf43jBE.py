# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
NTWE764hmOgUtScp2e8r = 'AKOAMCAM'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_AKC_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['مصارعة']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==350: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==351: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==352: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==353: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==354: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'FILTERS___'+text)
	elif mode==355: APpdhB1Fk58MmJH7CjVntowyaY = O40uMkKs5x6zmP9eFjnSbU(url,'CATEGORIES___'+text)
	elif mode==356: APpdhB1Fk58MmJH7CjVntowyaY = ttC6U7sZqg48azE5IlrFByfM(url)
	elif mode==357: APpdhB1Fk58MmJH7CjVntowyaY = rIoBxlFOHYUJhQS4c29wWC6sytb(url)
	elif mode==359: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+RNWqL0gBbKOie1DxjUpzQPh9aZyHX+'هذا الموقع مغلق'+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,8)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,359,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر محدد',pcE6DxaoHBm41WKXjwnk,356)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'فلتر كامل',pcE6DxaoHBm41WKXjwnk,357)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-MENU-1st')
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('recently-container.*?href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vcQbFfCk6T1: vcQbFfCk6T1 = vcQbFfCk6T1[0]
	else: vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'اضيف حديثا',vcQbFfCk6T1,351)
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('@id":"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if vcQbFfCk6T1: vcQbFfCk6T1 = vcQbFfCk6T1[0]
	else: vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',vcQbFfCk6T1,351,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('main-categories-list(.*?)main-categories-list',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?class="font.*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,351)
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="categories-box(.*?)<footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,351)
	return piN9Qlah4S
def ttC6U7sZqg48azE5IlrFByfM(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu(.*?)<nav',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?text">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
				title = title+' مصنفة'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,355)
		if website==WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return piN9Qlah4S
def rIoBxlFOHYUJhQS4c29wWC6sytb(website=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu(.*?)<nav',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?text">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
				title = title+' مفلترة'
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,354)
		if website==WnNGfosHr5STAq8j7miwyRZ6eOUbV: octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(XAGWNdKH4qOPU1YEVQp6,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('swiper-container(.*?)swiper-button-prev',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else: cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="container"(.*?)main-footer',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
		for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|الحلقه) \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
				if er96jwp52cbvaV48mtylEYSRz:
					title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
					if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
						octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,352,J4tO21KYAVdSr67W5NmiD0XhRP)
						cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			elif 'مسلسل' in title:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,352,J4tO21KYAVdSr67W5NmiD0XhRP)
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,353,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('pagination(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href=["\'](.*?)["\'].*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(SOw5EUxC9k)
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,351)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk + '/?s='+DqbrOGw4giHUvfuFtRXQ5lA0yN
	APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAMCAM-EPISODES-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('text-white">الحلقات(.*?)<header',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		cTmHXhoJ60 = p7dwlH1PRStBgyMUW.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in cTmHXhoJ60:
			if 'الحلقة' in title or 'الحلقه' in title: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,353,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		J4tO21KYAVdSr67W5NmiD0XhRP = pYDdXfVh5c0O1bMT6a78HKBiQw3.getInfoLabel('ListItem.Icon')
		if piN9Qlah4S.count('<title>')>1: title = p7dwlH1PRStBgyMUW.findall('<title>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[1]
		else: title = 'رابط التشغيل'
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,353,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn = [],[]
	Ayjc2Ps7xE4vDqb6YCGZirQdUt = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-PLAY-1st')
	piN9Qlah4S = Ayjc2Ps7xE4vDqb6YCGZirQdUt.content
	YQU9rmMqC0LWkcxaFpZos7VdRg = p7dwlH1PRStBgyMUW.findall('post_id=(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if YQU9rmMqC0LWkcxaFpZos7VdRg:
		YQU9rmMqC0LWkcxaFpZos7VdRg = YQU9rmMqC0LWkcxaFpZos7VdRg[0]
		headers = {'User-Agent':WnNGfosHr5STAq8j7miwyRZ6eOUbV,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':YQU9rmMqC0LWkcxaFpZos7VdRg}
		vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		hs19Z27nKRM5rIjp0edEzv8kgoYL3 = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'POST',vcQbFfCk6T1,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-PLAY-1st')
		hFYoSTas7WOVnwN = hs19Z27nKRM5rIjp0edEzv8kgoYL3.content
		items = p7dwlH1PRStBgyMUW.findall('data-server="(.*?)".*?class="text">(.*?)<',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		for cza2TRbvfOW8i5xoU,name in items:
			SOw5EUxC9k = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			SOw5EUxC9k = SOw5EUxC9k+'?postid='+YQU9rmMqC0LWkcxaFpZos7VdRg+'&serverid='+cza2TRbvfOW8i5xoU+'?named='+name+'__watch'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			ZD0qItXg31HmC7KGEFn.append(name)
		vcQbFfCk6T1 = pcE6DxaoHBm41WKXjwnk+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		hs19Z27nKRM5rIjp0edEzv8kgoYL3 = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'POST',vcQbFfCk6T1,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAMCAM-PLAY-1st')
		hFYoSTas7WOVnwN = hs19Z27nKRM5rIjp0edEzv8kgoYL3.content
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?class="text">(.*?)<',hFYoSTas7WOVnwN,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = SOw5EUxC9k.strip(kcXMWrwiLDKeBHRsJ)
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
			ZD0qItXg31HmC7KGEFn.append(title)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def O40uMkKs5x6zmP9eFjnSbU(url,filter):
	tqgKeQMz5XNvBPZAE6DCxfaLbj = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==WnNGfosHr5STAq8j7miwyRZ6eOUbV: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV
	else: FyLJNPHuzoOS,CXsOYNhZbgQmSdf3Iec9n6uLMv = filter.split('___')
	if type=='CATEGORIES':
		if tqgKeQMz5XNvBPZAE6DCxfaLbj[0]+'=' not in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[0]
		for JrM1DoSuQ5n8 in range(len(tqgKeQMz5XNvBPZAE6DCxfaLbj[0:-1])):
			if tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8]+'=' in FyLJNPHuzoOS: eukVjoW67vBiySNXrplDKIZLHU = tqgKeQMz5XNvBPZAE6DCxfaLbj[JrM1DoSuQ5n8+1]
		OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+eukVjoW67vBiySNXrplDKIZLHU+'=0'
		gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK.strip('&')+'___'+A5AHnwB1MJQ4O.strip('&')
		CdZwuO45sE7UvlbM = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'all')
		vcQbFfCk6T1 = url+'?'+CdZwuO45sE7UvlbM
	elif type=='FILTERS':
		ApWrjZy1KsQt9lkH4C = ooAW13BkLw7q(FyLJNPHuzoOS,'modified_values')
		ApWrjZy1KsQt9lkH4C = EZk136aeLoNqPvlDcTQpyM9Wm(ApWrjZy1KsQt9lkH4C)
		if CXsOYNhZbgQmSdf3Iec9n6uLMv!=WnNGfosHr5STAq8j7miwyRZ6eOUbV: CXsOYNhZbgQmSdf3Iec9n6uLMv = ooAW13BkLw7q(CXsOYNhZbgQmSdf3Iec9n6uLMv,'all')
		if CXsOYNhZbgQmSdf3Iec9n6uLMv==WnNGfosHr5STAq8j7miwyRZ6eOUbV: vcQbFfCk6T1 = url
		else: vcQbFfCk6T1 = url+'?'+CXsOYNhZbgQmSdf3Iec9n6uLMv
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'أظهار قائمة الفيديو التي تم اختيارها',vcQbFfCk6T1,351,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+' [[   '+ApWrjZy1KsQt9lkH4C+'   ]]',vcQbFfCk6T1,351,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<form id(.*?)</form>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	ZudC8bDqo4mM5c7GfP96Qy2F = p7dwlH1PRStBgyMUW.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	dict = {}
	for LgJITEZU95fS2oi8K,name,KDCdHQmgxPE21tYz4VUowSv in ZudC8bDqo4mM5c7GfP96Qy2F:
		items = p7dwlH1PRStBgyMUW.findall('<option(.*?)>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if '=' not in vcQbFfCk6T1: vcQbFfCk6T1 = url
		if type=='CATEGORIES':
			if eukVjoW67vBiySNXrplDKIZLHU!=LgJITEZU95fS2oi8K: continue
			elif len(items)<=1:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: ctDj2OVRyaUPXCrITmJG(vcQbFfCk6T1)
				else: O40uMkKs5x6zmP9eFjnSbU(vcQbFfCk6T1,'CATEGORIES___'+gY7CmyWXbJ1TiHB3GRUIOveP2)
				return
			else:
				if LgJITEZU95fS2oi8K==tqgKeQMz5XNvBPZAE6DCxfaLbj[-1]: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,351,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
				else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع',vcQbFfCk6T1,355,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		elif type=='FILTERS':
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'=0'
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'=0'
			gY7CmyWXbJ1TiHB3GRUIOveP2 = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجميع : '+name,vcQbFfCk6T1,354,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,gY7CmyWXbJ1TiHB3GRUIOveP2)
		dict[LgJITEZU95fS2oi8K] = {}
		for value,f4qbArVHeaCIiY5nzUR68dFBjsZ9 in items:
			if f4qbArVHeaCIiY5nzUR68dFBjsZ9 in EViWBhSw3dea8pTUO9AFMKbGjks027: continue
			if 'value' not in value: value = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			else: value = p7dwlH1PRStBgyMUW.findall('"(.*?)"',value,p7dwlH1PRStBgyMUW.DOTALL)[0]
			dict[LgJITEZU95fS2oi8K][value] = f4qbArVHeaCIiY5nzUR68dFBjsZ9
			OtSDMvz7qWdmr0w4Y8Bc5RK = FyLJNPHuzoOS+'&'+LgJITEZU95fS2oi8K+'='+f4qbArVHeaCIiY5nzUR68dFBjsZ9
			A5AHnwB1MJQ4O = CXsOYNhZbgQmSdf3Iec9n6uLMv+'&'+LgJITEZU95fS2oi8K+'='+value
			kpQXsE03HG4vw5Utu9z = OtSDMvz7qWdmr0w4Y8Bc5RK+'___'+A5AHnwB1MJQ4O
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' : '#+dict[LgJITEZU95fS2oi8K]['0']
			title = f4qbArVHeaCIiY5nzUR68dFBjsZ9+' : '+name
			if type=='FILTERS': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,354,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
			elif type=='CATEGORIES' and tqgKeQMz5XNvBPZAE6DCxfaLbj[-2]+'=' in FyLJNPHuzoOS:
				CdZwuO45sE7UvlbM = ooAW13BkLw7q(A5AHnwB1MJQ4O,'all')
				QQTfhlZEDnu4wVcOeHGNyCBo5t2 = url+'?'+CdZwuO45sE7UvlbM
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,QQTfhlZEDnu4wVcOeHGNyCBo5t2,351,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'1')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,355,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,kpQXsE03HG4vw5Utu9z)
	return
def ooAW13BkLw7q(KKpNlBa9cUqmk07,mode):
	KKpNlBa9cUqmk07 = KKpNlBa9cUqmk07.strip('&')
	LR9NpUdcOm3zBl7XIyYsE0tqATZ4 = {}
	if '=' in KKpNlBa9cUqmk07:
		items = KKpNlBa9cUqmk07.split('&')
		for N6NV3h4fel in items:
			rIQWSTdngFy9ui6bHNREK,value = N6NV3h4fel.split('=')
			LR9NpUdcOm3zBl7XIyYsE0tqATZ4[rIQWSTdngFy9ui6bHNREK] = value
	CZewXSEQ3q = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	wQyTn0NR9VkaBSCrDzPsqMl = ['cat','genre','release-year','quality','orderby']
	for key in wQyTn0NR9VkaBSCrDzPsqMl:
		if key in list(LR9NpUdcOm3zBl7XIyYsE0tqATZ4.keys()): value = LR9NpUdcOm3zBl7XIyYsE0tqATZ4[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': CZewXSEQ3q = CZewXSEQ3q+' + '+value
		elif mode=='modified_filters' and value!='0': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
		elif mode=='all': CZewXSEQ3q = CZewXSEQ3q+'&'+key+'='+value
	CZewXSEQ3q = CZewXSEQ3q.strip(' + ')
	CZewXSEQ3q = CZewXSEQ3q.strip('&')
	return CZewXSEQ3q