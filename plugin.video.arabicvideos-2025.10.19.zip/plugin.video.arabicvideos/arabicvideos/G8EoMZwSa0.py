# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'MOVS4U'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_M4U_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['انواع افلام','جودات افلام']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==380: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==381: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==382: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==383: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==389: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,389,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'المميزة',pcE6DxaoHBm41WKXjwnk,381,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الجانبية',pcE6DxaoHBm41WKXjwnk,381,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'sider')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVS4U-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('<header>.*?<h2>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for L3LoVh5B7OZMbHJlPXQ6EjnaUks in range(len(items)):
		title = items[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,pcE6DxaoHBm41WKXjwnk,381,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'latest'+str(L3LoVh5B7OZMbHJlPXQ6EjnaUks))
	KDCdHQmgxPE21tYz4VUowSv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu"(.*?)id="contenedor"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv += cKUQVwTMe9tZSY[0]
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="sidebar(.*?)aside',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv += cKUQVwTMe9tZSY[0]
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	UUdGCM6DFuzKJ1eTkNhcR3jon = True
	for SOw5EUxC9k,title in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if title=='الأعلى مشاهدة':
			if UUdGCM6DFuzKJ1eTkNhcR3jon:
				title = 'الافلام '+title
				UUdGCM6DFuzKJ1eTkNhcR3jon = False
			else: title = 'المسلسلات '+title
		if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,381)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,type):
	KDCdHQmgxPE21tYz4VUowSv,items = [],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVS4U-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if type=='search':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="search-page"(.*?)class="sidebar',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='sider':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="widget(.*?)class="widget',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		wdkUGQDybIEPrpvon3Y = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		M0MFkiKqJDv1aZ4NA396u,Gs9lnhfSDkraTigzZ,ZD0qItXg31HmC7KGEFn = zip(*wdkUGQDybIEPrpvon3Y)
		items = zip(Gs9lnhfSDkraTigzZ,M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn)
	elif type=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="slider-movies-tvshows"(.*?)<header>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif 'latest' in type:
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = int(type[-1:])
		piN9Qlah4S = piN9Qlah4S.replace('<header>','<end><start>')
		piN9Qlah4S = piN9Qlah4S.replace('<div class="sidebar','<end><div class="sidebar')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<start>(.*?)<end>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
		if L3LoVh5B7OZMbHJlPXQ6EjnaUks==2: items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="content"(.*?)class="(pagination|sidebar)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0][0]
			if '/collection/' in url:
				items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			elif '/quality/' in url:
				items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items and KDCdHQmgxPE21tYz4VUowSv:
		items = p7dwlH1PRStBgyMUW.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		if 'serie' in title:
			title = p7dwlH1PRStBgyMUW.findall('^(.*?)<.*?serie">(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
			title = title[0][1]
			if title in cIM3fQFnGYPxSV4eb9TvgWuokZA6H: continue
			cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			title = '_MOD_'+title
		gPvxJw89S35R21zDIbpFYkq7A = p7dwlH1PRStBgyMUW.findall('^(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
		if gPvxJw89S35R21zDIbpFYkq7A: title = gPvxJw89S35R21zDIbpFYkq7A[0]
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if '/tvshows/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,383,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/episodes/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,383,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/seasons/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,383,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/collection/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,381,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,382,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		nBSK8QO2gD4 = cKUQVwTMe9tZSY[0][0]
		xk6pHKsYgqPBhOCy821J7 = cKUQVwTMe9tZSY[0][1]
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0][2]
		items = p7dwlH1PRStBgyMUW.findall("href='(.*?)'.*?>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title==WnNGfosHr5STAq8j7miwyRZ6eOUbV or title==xk6pHKsYgqPBhOCy821J7: continue
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,381,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
		SOw5EUxC9k = SOw5EUxC9k.replace('/page/'+title+'/','/page/'+xk6pHKsYgqPBhOCy821J7+'/')
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'اخر صفحة '+xk6pHKsYgqPBhOCy821J7,SOw5EUxC9k,381,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVS4U-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('class="C rated".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe,False):
		octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+'المسلسل للكبار والمبرمج منعه',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('''class='item'><a href="(.*?)"''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if vcQbFfCk6T1:
			vcQbFfCk6T1 = vcQbFfCk6T1[1]
			d4TS7lOXiRVe0s3tg5JwIoz2Mh(vcQbFfCk6T1)
			return
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''class='episodios'(.*?)id="cast"''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for J4tO21KYAVdSr67W5NmiD0XhRP,er96jwp52cbvaV48mtylEYSRz,SOw5EUxC9k,name in items:
			title = er96jwp52cbvaV48mtylEYSRz+' : '+name+' الحلقة'
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,382)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVS4U-PLAY-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('class="C rated".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	M0MFkiKqJDv1aZ4NA396u = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0][0]
		items = p7dwlH1PRStBgyMUW.findall("data-url='(.*?)'.*?class='server'>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="remodal"(.*?)class="remodal-close"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+SOw5EUxC9k
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return