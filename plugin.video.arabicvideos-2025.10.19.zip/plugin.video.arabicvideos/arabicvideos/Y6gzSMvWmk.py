# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'FAJERSHOW'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_FJS_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
EViWBhSw3dea8pTUO9AFMKbGjks027 = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==390: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==391: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==392: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==393: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==399: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,399,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FAJERSHOW-MENU-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	items = p7dwlH1PRStBgyMUW.findall('<header>.*?<h2>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for L3LoVh5B7OZMbHJlPXQ6EjnaUks in range(len(items)):
		title = items[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,pcE6DxaoHBm41WKXjwnk,391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'latest'+str(L3LoVh5B7OZMbHJlPXQ6EjnaUks))
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مختارات عشوائية',pcE6DxaoHBm41WKXjwnk,391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'randoms')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أعلى الأفلام تقييماً',pcE6DxaoHBm41WKXjwnk,391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'top_imdb_movies')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أعلى المسلسلات تقييماً',pcE6DxaoHBm41WKXjwnk,391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'top_imdb_series')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أفلام مميزة',pcE6DxaoHBm41WKXjwnk+'/movies',391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured_movies')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'مسلسلات مميزة',pcE6DxaoHBm41WKXjwnk+'/tvshows',391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'featured_tvshows')
	KDCdHQmgxPE21tYz4VUowSv = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="menu"(.*?)id="contenedor"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv += cKUQVwTMe9tZSY[0]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(oldym5kX8IqLSVDtpNMw,'GET',pcE6DxaoHBm41WKXjwnk+'/movies',WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FAJERSHOW-MENU-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="releases"(.*?)aside',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv += cKUQVwTMe9tZSY[0]
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	UUdGCM6DFuzKJ1eTkNhcR3jon = True
	for SOw5EUxC9k,title in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if title=='الأعلى مشاهدة':
			if UUdGCM6DFuzKJ1eTkNhcR3jon:
				title = 'الافلام '+title
				UUdGCM6DFuzKJ1eTkNhcR3jon = False
			else: title = 'المسلسلات '+title
		if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
			if title=='أفلام': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,pcE6DxaoHBm41WKXjwnk+'/movies',391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'all_movies_tvshows')
			elif title=='مسلسلات': octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,pcE6DxaoHBm41WKXjwnk+'/tvshows',391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'all_movies_tvshows')
			else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,391)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,type):
	KDCdHQmgxPE21tYz4VUowSv,items = [],[]
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FAJERSHOW-TITLES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	if type in ['featured_movies','featured_tvshows']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="content"(.*?)id="archive-content"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif type=='all_movies_tvshows':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="archive-content"(.*?)class="pagination"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY: KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	elif type=='top_imdb_movies':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='top_imdb_series':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall("class='top-imdb-list tright(.*?)footer",piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='search':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="search-page"(.*?)class="sidebar',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='sider':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="widget(.*?)class="widget',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		bOl24a1PcFMgTZ0fzEoKN = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		M0MFkiKqJDv1aZ4NA396u,Gs9lnhfSDkraTigzZ,ZD0qItXg31HmC7KGEFn = zip(*bOl24a1PcFMgTZ0fzEoKN)
		items = zip(Gs9lnhfSDkraTigzZ,M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn)
	elif type=='randoms':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="slider-movies-tvshows"(.*?)<header>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif 'latest' in type:
		L3LoVh5B7OZMbHJlPXQ6EjnaUks = int(type[-1:])
		piN9Qlah4S = piN9Qlah4S.replace('<header>','<end><start>')
		piN9Qlah4S = piN9Qlah4S.replace('</div></div></div>','</div></div></div><end>')
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('<start>(.*?)<end>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[L3LoVh5B7OZMbHJlPXQ6EjnaUks]
		if L3LoVh5B7OZMbHJlPXQ6EjnaUks==6:
			bOl24a1PcFMgTZ0fzEoKN = p7dwlH1PRStBgyMUW.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			Gs9lnhfSDkraTigzZ,ZD0qItXg31HmC7KGEFn,M0MFkiKqJDv1aZ4NA396u = zip(*bOl24a1PcFMgTZ0fzEoKN)
			items = zip(Gs9lnhfSDkraTigzZ,M0MFkiKqJDv1aZ4NA396u,ZD0qItXg31HmC7KGEFn)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="content"(.*?)class="(pagination|sidebar)',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0][0]
			if '/collection/' in url:
				items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			elif '/quality/' in url:
				items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	if not items and KDCdHQmgxPE21tYz4VUowSv:
		items = p7dwlH1PRStBgyMUW.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = p7dwlH1PRStBgyMUW.findall('^(.*?)<.*?serie">(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
			title = title[0][1]
			if title in cIM3fQFnGYPxSV4eb9TvgWuokZA6H: continue
			cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
			title = '_MOD_'+title
		gPvxJw89S35R21zDIbpFYkq7A = p7dwlH1PRStBgyMUW.findall('^(.*?)<',title,p7dwlH1PRStBgyMUW.DOTALL)
		if gPvxJw89S35R21zDIbpFYkq7A: title = gPvxJw89S35R21zDIbpFYkq7A[0]
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if '/tvshows/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,393,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/episodes/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,393,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/seasons/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,393,J4tO21KYAVdSr67W5NmiD0XhRP)
		elif '/collection/' in SOw5EUxC9k: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,391,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,392,J4tO21KYAVdSr67W5NmiD0XhRP)
	if type not in ['featured_movies','featured_tvshows']:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"pagination"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		if cKUQVwTMe9tZSY:
			KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
			items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
			for SOw5EUxC9k,title in items:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,391,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	VVpQfHc7IZamxweON3WXKU6Fg = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(url,'url')
	url = url.replace(VVpQfHc7IZamxweON3WXKU6Fg,pcE6DxaoHBm41WKXjwnk)
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FAJERSHOW-EPISODES-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('class="C rated".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,392,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	piN9Qlah4S = x8FpPjoVmB5O(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'FAJERSHOW-PLAY-1st')
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('class="C rated".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	M0MFkiKqJDv1aZ4NA396u = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0][0]
		items = p7dwlH1PRStBgyMUW.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for type,dHqBsvSieRxmbAPXVJ0o,HVJRqMdcDo3jy9ek,title in items:
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+dHqBsvSieRxmbAPXVJ0o+'&nume='+HVJRqMdcDo3jy9ek+'&type='+type
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__watch'
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,DIBw28Qfje76bTMzVNYhxrgWmO,wwurzsGRxpMfaCqc1J in items:
			if '=' in J4tO21KYAVdSr67W5NmiD0XhRP:
				kr2ca95zm3jKIZhL = J4tO21KYAVdSr67W5NmiD0XhRP.split('=')[1]
				title = OGCfd8Xuc7tET4JPVohAMBFw2bNKqS(kr2ca95zm3jKIZhL,'host')
			else: title = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			title = wwurzsGRxpMfaCqc1J+kcXMWrwiLDKeBHRsJ+title
			SOw5EUxC9k = SOw5EUxC9k+'?named='+title+'__download____'+DIBw28Qfje76bTMzVNYhxrgWmO
			M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	url = pcE6DxaoHBm41WKXjwnk+'/?s='+search
	ctDj2OVRyaUPXCrITmJG(url,'search')
	return