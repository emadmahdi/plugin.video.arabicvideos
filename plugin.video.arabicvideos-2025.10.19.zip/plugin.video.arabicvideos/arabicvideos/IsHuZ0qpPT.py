# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
NTWE764hmOgUtScp2e8r = 'AKOAM'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_AKO_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
xxgy5wMXE6am8qGArC3oZdeVt = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==70: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==71: APpdhB1Fk58MmJH7CjVntowyaY = HWUgZ3N0f8dLY4RXEy9(url)
	elif mode==72: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==73: APpdhB1Fk58MmJH7CjVntowyaY = at20UDjZ5GukEmRzpT8WihCxdy(url)
	elif mode==74: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==79: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,79,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'سلسلة افلام',WnNGfosHr5STAq8j7miwyRZ6eOUbV,79,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'سلسلة افلام')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'سلاسل منوعة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,79,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'سلسلة')
	octplHnGwmE8bFqNdj7BiKvJ0VL('link',e6HEdvUcaq8Gx+' ===== ===== ===== '+YVr6St5P4xsFC0aARQGKfiegD,WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	EViWBhSw3dea8pTUO9AFMKbGjks027 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAM-MENU-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="partions"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)">(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			if title not in EViWBhSw3dea8pTUO9AFMKbGjks027:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,71)
	return piN9Qlah4S
def HWUgZ3N0f8dLY4RXEy9(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAM-CATEGORIES-1st')
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('sect_parts(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = title.strip(kcXMWrwiLDKeBHRsJ)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,72)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'جميع الفروع',url,72)
	else: ctDj2OVRyaUPXCrITmJG(url,WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	return
def ctDj2OVRyaUPXCrITmJG(url,type):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('section_title featured_title(.*?)subjects-crousel',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='search':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('akoam_result(.*?)<script',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	elif type=='more':
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('section_title more_title(.*?)footer_bottom_services',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('navigation(.*?)<script',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not items and cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,J4tO21KYAVdSr67W5NmiD0XhRP,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if any(value in title for value in xxgy5wMXE6am8qGArC3oZdeVt): octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,73,J4tO21KYAVdSr67W5NmiD0XhRP)
		else: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,73,J4tO21KYAVdSr67W5NmiD0XhRP)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="pagination"(.*?)</ul>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall("</li><li >.*?href='(.*?)'>(.*?)<",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,72,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,type)
	return
def dnelMymPkvf(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAM-SECTIONS-2nd')
	vcQbFfCk6T1 = p7dwlH1PRStBgyMUW.findall('"href","(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	vcQbFfCk6T1 = vcQbFfCk6T1[1]
	return vcQbFfCk6T1
def at20UDjZ5GukEmRzpT8WihCxdy(url):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,'AKOAM-SECTIONS-1st')
	y0BwNbxQTsa3UEOuCi8qV4YKGj = p7dwlH1PRStBgyMUW.findall('"(https*://akwam.net/\w+.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	lCj18JSHU7ksXp = p7dwlH1PRStBgyMUW.findall('"(https*://underurl.com/\w+.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if y0BwNbxQTsa3UEOuCi8qV4YKGj or lCj18JSHU7ksXp:
		if y0BwNbxQTsa3UEOuCi8qV4YKGj: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = y0BwNbxQTsa3UEOuCi8qV4YKGj[0]
		elif lCj18JSHU7ksXp: QQTfhlZEDnu4wVcOeHGNyCBo5t2 = dnelMymPkvf(lCj18JSHU7ksXp[0])
		QQTfhlZEDnu4wVcOeHGNyCBo5t2 = EZk136aeLoNqPvlDcTQpyM9Wm(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
		import iiy8cVF7db
		if '/series/' in QQTfhlZEDnu4wVcOeHGNyCBo5t2 or '/shows/' in QQTfhlZEDnu4wVcOeHGNyCBo5t2: iiy8cVF7db.d4TS7lOXiRVe0s3tg5JwIoz2Mh(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
		else: iiy8cVF7db.VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(QQTfhlZEDnu4wVcOeHGNyCBo5t2)
		return
	oERLSh8HOe = p7dwlH1PRStBgyMUW.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if oERLSh8HOe and e68y4a7LdjVsmIZDP51p3YQiqknBNA(NTWE764hmOgUtScp2e8r,url,oERLSh8HOe): return
	items = p7dwlH1PRStBgyMUW.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,73)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if not cKUQVwTMe9tZSY:
		uTaiRMI8eYmN('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,J4tO21KYAVdSr67W5NmiD0XhRP,KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
	name = name.strip(kcXMWrwiLDKeBHRsJ)
	if 'sub_epsiode_title' in KDCdHQmgxPE21tYz4VUowSv:
		items = p7dwlH1PRStBgyMUW.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	else:
		zGwemtTsx7K4LaR0QopW = p7dwlH1PRStBgyMUW.findall('sub_file_title\'>(.*?) - <i>',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		items = []
		for filename in zGwemtTsx7K4LaR0QopW:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',WnNGfosHr5STAq8j7miwyRZ6eOUbV) ]
	count = 0
	ZD0qItXg31HmC7KGEFn,ApOlMQqrE7j314o2bkd = [],[]
	size = len(items)
	for title,filename in items:
		P4cqC2X0dpeHbg3KW = WnNGfosHr5STAq8j7miwyRZ6eOUbV
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: P4cqC2X0dpeHbg3KW = filename.split('.')[-1]
		title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
		ZD0qItXg31HmC7KGEFn.append(title)
		ApOlMQqrE7j314o2bkd.append(count)
		count += 1
	if size>0:
		if any(value in name for value in xxgy5wMXE6am8qGArC3oZdeVt):
			if size==1:
				XFaM94cPUCOWQZNIEe8gdJpny1 = 0
			else:
				XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر الفيديو المناسب:', ZD0qItXg31HmC7KGEFn)
				if XFaM94cPUCOWQZNIEe8gdJpny1 == -1: return
			VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url+'?section='+str(1+ApOlMQqrE7j314o2bkd[size-XFaM94cPUCOWQZNIEe8gdJpny1-1]))
		else:
			for JrM1DoSuQ5n8 in reversed(range(size)):
				title = name + ' - ' + ZD0qItXg31HmC7KGEFn[JrM1DoSuQ5n8]
				title = title.replace(WBDnh75CaLEvkcN6p4ez2KXrV3M,WnNGfosHr5STAq8j7miwyRZ6eOUbV).strip(kcXMWrwiLDKeBHRsJ)
				SOw5EUxC9k = url + '?section='+str(size-JrM1DoSuQ5n8)
				octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,74,J4tO21KYAVdSr67W5NmiD0XhRP)
	else:
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الرابط ليس فيديو',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	vcQbFfCk6T1,er96jwp52cbvaV48mtylEYSRz = url.split('?section=')
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(nsFAzS2wvjyTYLOdDhfIiC0KGHE,'GET',vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,True,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'AKOAM-PLAY_AKOAM-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	m0nQzuids9NMHrbLkU3lJAVxFwg = cKUQVwTMe9tZSY[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	m0nQzuids9NMHrbLkU3lJAVxFwg = m0nQzuids9NMHrbLkU3lJAVxFwg + 'direct_link_box'
	UOqp25uxcISGBPlAfbtzCNWXY4nvK = p7dwlH1PRStBgyMUW.findall('epsoide_box(.*?)direct_link_box',m0nQzuids9NMHrbLkU3lJAVxFwg,p7dwlH1PRStBgyMUW.DOTALL)
	er96jwp52cbvaV48mtylEYSRz = len(UOqp25uxcISGBPlAfbtzCNWXY4nvK)-int(er96jwp52cbvaV48mtylEYSRz)
	KDCdHQmgxPE21tYz4VUowSv = UOqp25uxcISGBPlAfbtzCNWXY4nvK[er96jwp52cbvaV48mtylEYSRz]
	wxT9bCdumN = []
	iikH7sP1Duq = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = p7dwlH1PRStBgyMUW.findall("class='download_btn.*?href='(.*?)'",KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k in items:
		wxT9bCdumN.append(SOw5EUxC9k+'?named=________akoam')
	items = p7dwlH1PRStBgyMUW.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	for wNUWj35dVnGqhy7,SOw5EUxC9k in items:
		wNUWj35dVnGqhy7 = wNUWj35dVnGqhy7.split('/')[-1]
		wNUWj35dVnGqhy7 = wNUWj35dVnGqhy7.split('.')[0]
		if wNUWj35dVnGqhy7 in iikH7sP1Duq:
			wxT9bCdumN.append(SOw5EUxC9k+'?named='+iikH7sP1Duq[wNUWj35dVnGqhy7]+'________akoam')
		else: wxT9bCdumN.append(SOw5EUxC9k+'?named='+wNUWj35dVnGqhy7+'________akoam')
	if not wxT9bCdumN:
		message = p7dwlH1PRStBgyMUW.findall('sub-no-file.*?\n(.*?)\n',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		if message: BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'رسالة من الموقع الاصلي',message[0])
	else:
		import ltcz1qSYiV
		ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(wxT9bCdumN,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	DqbrOGw4giHUvfuFtRXQ5lA0yN = search.replace(kcXMWrwiLDKeBHRsJ,'%20')
	url = pcE6DxaoHBm41WKXjwnk + '/search/'+DqbrOGw4giHUvfuFtRXQ5lA0yN
	APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,'search')
	return