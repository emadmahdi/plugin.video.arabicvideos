# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'DAILYMOTION'
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_DLM_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
wwmXPdcfpo = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][1]
jFaJ2ULfqTCxWOz8gYZS = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][2]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text,type,TB3DI4JWr0NYmik1xO8Kc2):
	if	 mode==400: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==401: APpdhB1Fk58MmJH7CjVntowyaY = mv59UVj47ZYuN(url,text)
	elif mode==402: APpdhB1Fk58MmJH7CjVntowyaY = NNJrweQXmFf(url,text)
	elif mode==403: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,text)
	elif mode==404: APpdhB1Fk58MmJH7CjVntowyaY = Kh2jI48tqrbRv(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==405: APpdhB1Fk58MmJH7CjVntowyaY = nhIU9b0pgZyDV(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==406: APpdhB1Fk58MmJH7CjVntowyaY = U6Rj5OFC2yotSQw8uxl3LBHk(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==407: APpdhB1Fk58MmJH7CjVntowyaY = BTpyxjZ8Fusd392GwAk(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==408: APpdhB1Fk58MmJH7CjVntowyaY = QQZgiBcAHWUx1T4Lm0Ko3be(url,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==409: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==411: APpdhB1Fk58MmJH7CjVntowyaY = YdA7STL3Z5JhzRHbvrunCtoU(url,text)
	elif mode==414: APpdhB1Fk58MmJH7CjVntowyaY = ll9jc4WkL65fTHei7Zo(text)
	elif mode==415: APpdhB1Fk58MmJH7CjVntowyaY = mTtcOJg1BIPLH49AN067XobxujWEia(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==416: APpdhB1Fk58MmJH7CjVntowyaY = yyRhKUParDMHZuFTOAs(text,TB3DI4JWr0NYmik1xO8Kc2)
	elif mode==417: APpdhB1Fk58MmJH7CjVntowyaY = bo2eJXQGMmZ7SV19vqyFNBjaO(url,TB3DI4JWr0NYmik1xO8Kc2)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'الرئيسية',WnNGfosHr5STAq8j7miwyRZ6eOUbV,414)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن فيديوهات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'videos?sortBy=','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن آخر الفيديوهات',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن الفيديوهات الأكثر مشاهدة',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن قوائم التشغيل',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'playlists','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن مستخدم',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'channels','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن بث حي',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'lives','_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث عن هاشتاك',WnNGfosHr5STAq8j7miwyRZ6eOUbV,409,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'hashtags','_REMEMBERRESULTS_')
	return
def NNJrweQXmFf(url,miL9KhB7WusPZdCbvzMXIeNy):
	if '/dm_' in url:
		WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,False,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = WadGEeh1MBIXkpfP38qAv7ryslY.headers
		if 'Location' in list(headers.keys()): url = pcE6DxaoHBm41WKXjwnk+headers['Location']
	miL9KhB7WusPZdCbvzMXIeNy = e6HEdvUcaq8Gx+miL9KhB7WusPZdCbvzMXIeNy+YVr6St5P4xsFC0aARQGKfiegD
	miL9KhB7WusPZdCbvzMXIeNy = uy8xDzWdKckhwC5bUBtl12GE(miL9KhB7WusPZdCbvzMXIeNy)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: بث حي',url,411,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'channel_lives_now')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: آخر الفيديوهات',url+'/videos',408)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: المميزة',url,411,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'channel_featured_videos')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: قوائم التشغيل',url+'/playlists',407)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+':: قنوات ذات صلة',url,411,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'channel_related_channel')
	return
def uy8xDzWdKckhwC5bUBtl12GE(title):
	title = title.rstrip('\\').strip(kcXMWrwiLDKeBHRsJ).replace('\\\\','\\')
	title = clFjTSgMODe7Nq0H3Vzs(title)
	return title
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url,vtU5aCzrXH6o0k21s):
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L([url],NTWE764hmOgUtScp2e8r,'video',url)
	return
def Kh2jI48tqrbRv(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	search = search.split('/videos')[0]
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	if sort==WnNGfosHr5STAq8j7miwyRZ6eOUbV: dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysortmethod',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
	else: dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/videos'
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"videos"(.*?)"VideoConnection"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for id,title,vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy,gJVpmQ1oYbrkHaKnS4N3v2z,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+id
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			vtU5aCzrXH6o0k21s = vTabNGQXoVmLEh14rDpgjS+'::'+miL9KhB7WusPZdCbvzMXIeNy
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z,vtU5aCzrXH6o0k21s)
		if '"hasNextPage":true' in piN9Qlah4S:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,404,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def nhIU9b0pgZyDV(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/playlists'
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	items = p7dwlH1PRStBgyMUW.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for id,name,My14egl6ZQaP7pSAhR8do5BO,vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy,J4tO21KYAVdSr67W5NmiD0XhRP,count in items:
		J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
		SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = uy8xDzWdKckhwC5bUBtl12GE(title)
		vtU5aCzrXH6o0k21s = vTabNGQXoVmLEh14rDpgjS+'::'+miL9KhB7WusPZdCbvzMXIeNy
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,401,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,vtU5aCzrXH6o0k21s)
	if '"hasNextPage":true' in piN9Qlah4S:
		TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,405,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def U6Rj5OFC2yotSQw8uxl3LBHk(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/channels'
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"channels"(.*?)"ChannelConnection"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for id,name,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+id
			title = 'USER:  '+name
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,402,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,name)
		if '"hasNextPage":true' in piN9Qlah4S:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,406,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def ll9jc4WkL65fTHei7Zo(CYQ5LhB78iel0DKuvZaJO6wANrVTx):
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['home']['neon']['sections']['edges']
		if not CYQ5LhB78iel0DKuvZaJO6wANrVTx:
			xETgseHZmz4SinF6vW = []
			for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
				PujA1gZkTOh9emWXUsM0p87tV4oE = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['title']
				if PujA1gZkTOh9emWXUsM0p87tV4oE not in xETgseHZmz4SinF6vW: octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+PujA1gZkTOh9emWXUsM0p87tV4oE,WnNGfosHr5STAq8j7miwyRZ6eOUbV,414,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,PujA1gZkTOh9emWXUsM0p87tV4oE)
				xETgseHZmz4SinF6vW.append(PujA1gZkTOh9emWXUsM0p87tV4oE)
		else:
			for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
				PujA1gZkTOh9emWXUsM0p87tV4oE = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['title']
				if PujA1gZkTOh9emWXUsM0p87tV4oE==CYQ5LhB78iel0DKuvZaJO6wANrVTx:
					HSgdC0BM2l4QejEiZ5 = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['components']['edges']
					for eeW9nEiPwGXvAY50R in HSgdC0BM2l4QejEiZ5:
						gJVpmQ1oYbrkHaKnS4N3v2z = str(eeW9nEiPwGXvAY50R['node']['duration'])
						title = clFjTSgMODe7Nq0H3Vzs(eeW9nEiPwGXvAY50R['node']['title'])
						title = title.replace('\/','/')
						XAUGhBu182wVSeaOnfxmRq = eeW9nEiPwGXvAY50R['node']['xid']
						J4tO21KYAVdSr67W5NmiD0XhRP = eeW9nEiPwGXvAY50R['node']['thumbnailx480']
						J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
						SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+XAUGhBu182wVSeaOnfxmRq
						octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
	return
def mTtcOJg1BIPLH49AN067XobxujWEia(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/lives'
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		try: S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['search']['lives']['edges']
		except: S0SFnOohCjVM2srwt5ZL1meKgGWEa = []
		for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
			name = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['title']
			name = clFjTSgMODe7Nq0H3Vzs(name)
			XAUGhBu182wVSeaOnfxmRq = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['xid']
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+XAUGhBu182wVSeaOnfxmRq
			octplHnGwmE8bFqNdj7BiKvJ0VL('live',uBQ9txp0gDrEhZTcJOi74SKVw3k+'LIVE: '+name,SOw5EUxC9k,403)
		if '"hasNextPage":true' in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,415,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def y7NxAQw3dGDFUgEh(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/topics'
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		try: S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['search']['topics']['edges']
		except: S0SFnOohCjVM2srwt5ZL1meKgGWEa = []
		for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
			name = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['name']
			XAUGhBu182wVSeaOnfxmRq = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['xid']
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/topic/'+XAUGhBu182wVSeaOnfxmRq
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'TOPIC: '+name,SOw5EUxC9k,413)
		if '"hasNextPage":true' in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,412,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def ceguzoHLGvryD8(url,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	XAUGhBu182wVSeaOnfxmRq = url.split('/')[-1]
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mytopicid',XAUGhBu182wVSeaOnfxmRq)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['topic']['videos']['edges']
		for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
			gJVpmQ1oYbrkHaKnS4N3v2z = str(UBo25xXAfHYhGQOtP8rCWIVsi61['node']['duration'])
			title = clFjTSgMODe7Nq0H3Vzs(UBo25xXAfHYhGQOtP8rCWIVsi61['node']['title'])
			title = title.replace('\/','/')
			XAUGhBu182wVSeaOnfxmRq = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['xid']
			J4tO21KYAVdSr67W5NmiD0XhRP = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['thumbnailx480']
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+XAUGhBu182wVSeaOnfxmRq
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
		if '"hasNextPage":true' in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,413,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2)
	return
def mv59UVj47ZYuN(url,vtU5aCzrXH6o0k21s):
	id = url.split('/')[-1]
	vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy = vtU5aCzrXH6o0k21s.split('::',1)
	SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+vTabNGQXoVmLEh14rDpgjS
	miL9KhB7WusPZdCbvzMXIeNy = uy8xDzWdKckhwC5bUBtl12GE(miL9KhB7WusPZdCbvzMXIeNy)
	title = e6HEdvUcaq8Gx+'OWNER:  '+miL9KhB7WusPZdCbvzMXIeNy+YVr6St5P4xsFC0aARQGKfiegD
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,402,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,miL9KhB7WusPZdCbvzMXIeNy)
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('myplaylistid',id)
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"collection_videos"(.*?)"SectionEdge"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for id,title,gJVpmQ1oYbrkHaKnS4N3v2z,J4tO21KYAVdSr67W5NmiD0XhRP,vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+id
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			vtU5aCzrXH6o0k21s = vTabNGQXoVmLEh14rDpgjS+'::'+miL9KhB7WusPZdCbvzMXIeNy
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z,vtU5aCzrXH6o0k21s)
	return
def QQZgiBcAHWUx1T4Lm0Ko3be(url,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	MXZvtCRTuhcs6VN1K0LOwWDF = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mychannelid',MXZvtCRTuhcs6VN1K0LOwWDF)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysortmethod',sort)
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for id,title,gJVpmQ1oYbrkHaKnS4N3v2z,vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy,J4tO21KYAVdSr67W5NmiD0XhRP in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+id
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			vtU5aCzrXH6o0k21s = vTabNGQXoVmLEh14rDpgjS+'::'+miL9KhB7WusPZdCbvzMXIeNy
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z,vtU5aCzrXH6o0k21s)
		if '"hasNextPage":true' in piN9Qlah4S:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,408,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2)
	return
def BTpyxjZ8Fusd392GwAk(url,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	MXZvtCRTuhcs6VN1K0LOwWDF = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mychannelid',MXZvtCRTuhcs6VN1K0LOwWDF)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysortmethod',sort)
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for id,name,J4tO21KYAVdSr67W5NmiD0XhRP,count,My14egl6ZQaP7pSAhR8do5BO,vTabNGQXoVmLEh14rDpgjS,miL9KhB7WusPZdCbvzMXIeNy in items:
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			vtU5aCzrXH6o0k21s = vTabNGQXoVmLEh14rDpgjS+'::'+miL9KhB7WusPZdCbvzMXIeNy
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,401,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,vtU5aCzrXH6o0k21s)
		if '"hasNextPage":true' in piN9Qlah4S:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,407,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2)
	return
def YdA7STL3Z5JhzRHbvrunCtoU(url,SNowOHnVUQuAtgZxTB3yWGk):
	MXZvtCRTuhcs6VN1K0LOwWDF = url.split('/')[3]
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mychannelid',MXZvtCRTuhcs6VN1K0LOwWDF)
	piN9Qlah4S = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	dd40ZVSHkJr2bFM9Dv = qJRG1u4fHXAkF5PsEaBMWUDVtKij2z.loads(piN9Qlah4S)
	try: items = dd40ZVSHkJr2bFM9Dv['data']['channel'][SNowOHnVUQuAtgZxTB3yWGk]['edges']
	except: items = []
	if not items: octplHnGwmE8bFqNdj7BiKvJ0VL('link',uBQ9txp0gDrEhZTcJOi74SKVw3k+'لا توجد نتائج',WnNGfosHr5STAq8j7miwyRZ6eOUbV,9999)
	else:
		for N6NV3h4fel in items:
			OTRFt3c9SdB280wDv76KfmNiIl = N6NV3h4fel['node']
			XAUGhBu182wVSeaOnfxmRq = OTRFt3c9SdB280wDv76KfmNiIl['xid']
			keys = list(OTRFt3c9SdB280wDv76KfmNiIl.keys())
			kPTwMcLHDbi1 = OTRFt3c9SdB280wDv76KfmNiIl['__typename'].lower()
			if kPTwMcLHDbi1=='channel':
				name = OTRFt3c9SdB280wDv76KfmNiIl['name']
				DDgA35XK47HYS0TV9LmO = OTRFt3c9SdB280wDv76KfmNiIl['displayName']
				title = 'USER:  '+DDgA35XK47HYS0TV9LmO
				J4tO21KYAVdSr67W5NmiD0XhRP = OTRFt3c9SdB280wDv76KfmNiIl['coverURLx375']
			else:
				name = OTRFt3c9SdB280wDv76KfmNiIl['channel']['name']
				DDgA35XK47HYS0TV9LmO = OTRFt3c9SdB280wDv76KfmNiIl['channel']['displayName']
				title = OTRFt3c9SdB280wDv76KfmNiIl['title']
				J4tO21KYAVdSr67W5NmiD0XhRP = OTRFt3c9SdB280wDv76KfmNiIl['thumbnailx360']
				if kPTwMcLHDbi1=='live': title = 'LIVE:  '+title
			title = uy8xDzWdKckhwC5bUBtl12GE(title)
			vtU5aCzrXH6o0k21s = name+'::'+DDgA35XK47HYS0TV9LmO
			if YVzokG2yZqrh3w8bU:
				title = title.encode(e87cIA5vwOQLDEP1)
				vtU5aCzrXH6o0k21s = vtU5aCzrXH6o0k21s.encode(e87cIA5vwOQLDEP1)
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			if kPTwMcLHDbi1=='channel':
				SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/'+XAUGhBu182wVSeaOnfxmRq
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,402,J4tO21KYAVdSr67W5NmiD0XhRP,WnNGfosHr5STAq8j7miwyRZ6eOUbV,vtU5aCzrXH6o0k21s)
			else:
				if kPTwMcLHDbi1=='video': gJVpmQ1oYbrkHaKnS4N3v2z = str(OTRFt3c9SdB280wDv76KfmNiIl['duration'])
				else: gJVpmQ1oYbrkHaKnS4N3v2z = WnNGfosHr5STAq8j7miwyRZ6eOUbV
				SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+XAUGhBu182wVSeaOnfxmRq
				octplHnGwmE8bFqNdj7BiKvJ0VL(kPTwMcLHDbi1,uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z,vtU5aCzrXH6o0k21s)
	return
def yyRhKUParDMHZuFTOAs(search,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mysearchwords',search)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagelimit','40')
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	url = pcE6DxaoHBm41WKXjwnk+'/search/'+search+'/hashtags'
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		try: S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['search']['hashtags']['edges']
		except: S0SFnOohCjVM2srwt5ZL1meKgGWEa = []
		for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
			name = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['name']
			name = clFjTSgMODe7Nq0H3Vzs(name)
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/hashtag/'+name[1:]
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'HSHTG: '+name,SOw5EUxC9k,417)
		if '"hasNextPage":true' in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,416,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2,search)
	return
def bo2eJXQGMmZ7SV19vqyFNBjaO(url,TB3DI4JWr0NYmik1xO8Kc2=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if TB3DI4JWr0NYmik1xO8Kc2==WnNGfosHr5STAq8j7miwyRZ6eOUbV: TB3DI4JWr0NYmik1xO8Kc2 = '1'
	name = url.split('/')[-1]
	dlPQGb0aC5xmfFwy9ievKTqX = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('myhashtagname',name)
	dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.replace('mypagenumber',TB3DI4JWr0NYmik1xO8Kc2)
	wwLkBzRnF32Zse1VKCoQuX4htlHyb = iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX)
	if wwLkBzRnF32Zse1VKCoQuX4htlHyb:
		aayzj5b0GiZB6eELYKRPfDvHtOhN1 = IXZpzK7ShaRsAN('dict',wwLkBzRnF32Zse1VKCoQuX4htlHyb)
		S0SFnOohCjVM2srwt5ZL1meKgGWEa = aayzj5b0GiZB6eELYKRPfDvHtOhN1['data']['contentFeed']['edges']
		for UBo25xXAfHYhGQOtP8rCWIVsi61 in S0SFnOohCjVM2srwt5ZL1meKgGWEa:
			gJVpmQ1oYbrkHaKnS4N3v2z = str(UBo25xXAfHYhGQOtP8rCWIVsi61['node']['post']['duration'])
			title = clFjTSgMODe7Nq0H3Vzs(UBo25xXAfHYhGQOtP8rCWIVsi61['node']['post']['title'])
			title = title.replace('\/','/')
			XAUGhBu182wVSeaOnfxmRq = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['post']['xid']
			J4tO21KYAVdSr67W5NmiD0XhRP = UBo25xXAfHYhGQOtP8rCWIVsi61['node']['post']['thumbnailx480']
			J4tO21KYAVdSr67W5NmiD0XhRP = J4tO21KYAVdSr67W5NmiD0XhRP.replace('\/','/')
			SOw5EUxC9k = pcE6DxaoHBm41WKXjwnk+'/video/'+XAUGhBu182wVSeaOnfxmRq
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,403,J4tO21KYAVdSr67W5NmiD0XhRP,gJVpmQ1oYbrkHaKnS4N3v2z)
		if '"hasNextPage":true' in wwLkBzRnF32Zse1VKCoQuX4htlHyb:
			TB3DI4JWr0NYmik1xO8Kc2 = str(int(TB3DI4JWr0NYmik1xO8Kc2)+1)
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+TB3DI4JWr0NYmik1xO8Kc2,url,416,WnNGfosHr5STAq8j7miwyRZ6eOUbV,TB3DI4JWr0NYmik1xO8Kc2)
	return
def iiWmYpZGERMd92wASyfXoV(dlPQGb0aC5xmfFwy9ievKTqX,search=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	if rJ2oTLqabRtA: dlPQGb0aC5xmfFwy9ievKTqX = dlPQGb0aC5xmfFwy9ievKTqX.encode(e87cIA5vwOQLDEP1)
	zXJBykNW3Fxu9c = eswaJH5tovyA4CLSU()
	headers = {"Authorization":zXJBykNW3Fxu9c,"Origin":pcE6DxaoHBm41WKXjwnk}
	if search:
		VVDAncSMUjeu8Ii = jFaJ2ULfqTCxWOz8gYZS
		headers.update({'Content-Type':'application/json','Referer':pcE6DxaoHBm41WKXjwnk+'/','X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		VVDAncSMUjeu8Ii = wwmXPdcfpo
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',wwmXPdcfpo,dlPQGb0aC5xmfFwy9ievKTqX,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'DAILYMOTION-GET_PAGEDATA-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	return piN9Qlah4S
def eswaJH5tovyA4CLSU():
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'GET',pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'DAILYMOTION-GET_AUTHINTICATION-1st')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	X4WsYDdxVowu = p7dwlH1PRStBgyMUW.findall('apiClientId.*?return"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	X4WsYDdxVowu = X4WsYDdxVowu[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	CQiNmA8Ygc7ZdHME = p7dwlH1PRStBgyMUW.findall('apiClientSecret.*?return"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	CQiNmA8Ygc7ZdHME = CQiNmA8Ygc7ZdHME[j0jEZgiKdxFpMLHcU7kQr8v1lyX4]
	YsUv2ry7Xu8MK5 = 'https://graphql.api.dailymotion.com/oauth/token'
	oC1j3zc6tbmKpOUiyxHa4fX = 'client_credentials'
	data = {'client_id':X4WsYDdxVowu,'client_secret':CQiNmA8Ygc7ZdHME,'grant_type':oC1j3zc6tbmKpOUiyxHa4fX}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	WadGEeh1MBIXkpfP38qAv7ryslY = o84PIukw7sFY0J1SLpXZrKbWQjTiOD(OQaHUGCW62hp8tFbgM,'POST',YsUv2ry7Xu8MK5,data,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	piN9Qlah4S = WadGEeh1MBIXkpfP38qAv7ryslY.content
	ESq96Tboaw7Ksj3tx2ZmY = p7dwlH1PRStBgyMUW.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	DRxN0L8hAYKi2nwEZ7C9,fAyCvDnkW4dm70YoK5Ex = ESq96Tboaw7Ksj3tx2ZmY[0]
	zXJBykNW3Fxu9c = fAyCvDnkW4dm70YoK5Ex+" "+DRxN0L8hAYKi2nwEZ7C9
	return zXJBykNW3Fxu9c
def WmxfGFqceOyUtLT(search,nxeRBuVLTiHaSJEp30XN5P4dbG=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if not nxeRBuVLTiHaSJEp30XN5P4dbG and showDialogs:
		kuDXB0mJcCFN6OgveW = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('موقع ديلي موشن - اختر البحث',kuDXB0mJcCFN6OgveW)
		if XFaM94cPUCOWQZNIEe8gdJpny1==-1: return
		elif XFaM94cPUCOWQZNIEe8gdJpny1==0: nxeRBuVLTiHaSJEp30XN5P4dbG = 'videos?sortBy='
		elif XFaM94cPUCOWQZNIEe8gdJpny1==1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'videos?sortBy=RECENT'
		elif XFaM94cPUCOWQZNIEe8gdJpny1==2: nxeRBuVLTiHaSJEp30XN5P4dbG = 'videos?sortBy=VIEW_COUNT'
		elif XFaM94cPUCOWQZNIEe8gdJpny1==3: nxeRBuVLTiHaSJEp30XN5P4dbG = 'playlists'
		elif XFaM94cPUCOWQZNIEe8gdJpny1==4: nxeRBuVLTiHaSJEp30XN5P4dbG = 'channels'
		elif XFaM94cPUCOWQZNIEe8gdJpny1==5: nxeRBuVLTiHaSJEp30XN5P4dbG = 'lives'
		elif XFaM94cPUCOWQZNIEe8gdJpny1==6: nxeRBuVLTiHaSJEp30XN5P4dbG = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in xCONTFizaKbJS1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in xCONTFizaKbJS1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in xCONTFizaKbJS1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'channels'
	elif '_DAILYMOTION-LIVES_' in xCONTFizaKbJS1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in xCONTFizaKbJS1: nxeRBuVLTiHaSJEp30XN5P4dbG = 'hashtags'
	elif not nxeRBuVLTiHaSJEp30XN5P4dbG: nxeRBuVLTiHaSJEp30XN5P4dbG = 'videos?sortBy='
	if not search:
		search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
		if not search: return
	if 'videos' in nxeRBuVLTiHaSJEp30XN5P4dbG: Kh2jI48tqrbRv(search+'/'+nxeRBuVLTiHaSJEp30XN5P4dbG)
	elif 'playlists' in nxeRBuVLTiHaSJEp30XN5P4dbG: nhIU9b0pgZyDV(search)
	elif 'channels' in nxeRBuVLTiHaSJEp30XN5P4dbG: U6Rj5OFC2yotSQw8uxl3LBHk(search)
	elif 'lives' in nxeRBuVLTiHaSJEp30XN5P4dbG: mTtcOJg1BIPLH49AN067XobxujWEia(search)
	elif 'hashtags' in nxeRBuVLTiHaSJEp30XN5P4dbG: yyRhKUParDMHZuFTOAs(search)
	return