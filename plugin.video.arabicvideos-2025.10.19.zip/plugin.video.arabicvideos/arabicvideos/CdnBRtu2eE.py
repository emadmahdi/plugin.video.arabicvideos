# -*- coding: utf-8 -*-
from UdvL4wSQeI import *
NTWE764hmOgUtScp2e8r = 'MOVIZLAND'
headers = { 'User-Agent' : WnNGfosHr5STAq8j7miwyRZ6eOUbV }
uBQ9txp0gDrEhZTcJOi74SKVw3k = '_MVZ_'
pcE6DxaoHBm41WKXjwnk = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][0]
wwmXPdcfpo = A3pXVFdyP1.SITESURLS[NTWE764hmOgUtScp2e8r][1]
def CQdJAeGfyc6z9bnLDwXsu4mW(mode,url,text):
	if   mode==180: APpdhB1Fk58MmJH7CjVntowyaY = bRaCHZtyd3qj7D()
	elif mode==181: APpdhB1Fk58MmJH7CjVntowyaY = ctDj2OVRyaUPXCrITmJG(url,text)
	elif mode==182: APpdhB1Fk58MmJH7CjVntowyaY = VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url)
	elif mode==183: APpdhB1Fk58MmJH7CjVntowyaY = d4TS7lOXiRVe0s3tg5JwIoz2Mh(url)
	elif mode==188: APpdhB1Fk58MmJH7CjVntowyaY = Z3KNl01JFaAjT5nkbXfh()
	elif mode==189: APpdhB1Fk58MmJH7CjVntowyaY = WmxfGFqceOyUtLT(text)
	else: APpdhB1Fk58MmJH7CjVntowyaY = False
	return APpdhB1Fk58MmJH7CjVntowyaY
def Z3KNl01JFaAjT5nkbXfh():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	BGQXvd2lsicjVTgnHYRo74qDI3z(WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,Ew26Hg4SIj,message)
	return
def bRaCHZtyd3qj7D():
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'بحث في الموقع',WnNGfosHr5STAq8j7miwyRZ6eOUbV,189,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'_REMEMBERRESULTS_')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'بوكس اوفيس موفيز لاند',pcE6DxaoHBm41WKXjwnk,181,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'box-office')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أحدث الافلام',pcE6DxaoHBm41WKXjwnk,181,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'latest-movies')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'تليفزيون موفيز لاند',pcE6DxaoHBm41WKXjwnk,181,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'tv')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'الاكثر مشاهدة',pcE6DxaoHBm41WKXjwnk,181,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'top-views')
	octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+'أقوى الافلام الحالية',pcE6DxaoHBm41WKXjwnk,181,WnNGfosHr5STAq8j7miwyRZ6eOUbV,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'top-movies')
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-MENU-1st')
	items = p7dwlH1PRStBgyMUW.findall('<h2><a href="(.*?)".*?">(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	for SOw5EUxC9k,title in items:
		octplHnGwmE8bFqNdj7BiKvJ0VL('folder',NTWE764hmOgUtScp2e8r+'_SCRIPT_'+uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,181)
	return piN9Qlah4S
def ctDj2OVRyaUPXCrITmJG(url,type=WnNGfosHr5STAq8j7miwyRZ6eOUbV):
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,url,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	elif type=='box-office': KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	elif type=='top-movies': KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('btn-2-overlay(.*?)<style>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	elif type=='top-views': KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	elif type=='tv': KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	else: KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
	if type in ['top-views','top-movies']:
		items = p7dwlH1PRStBgyMUW.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	else: items = p7dwlH1PRStBgyMUW.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
	cIM3fQFnGYPxSV4eb9TvgWuokZA6H = []
	SnBhkFA2Z3gNVWJlz1ypa = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for J4tO21KYAVdSr67W5NmiD0XhRP,xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN,Ps6p25Y9evV1iqgH in items:
		if type in ['top-views','top-movies']:
			J4tO21KYAVdSr67W5NmiD0XhRP,SOw5EUxC9k,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr,title = J4tO21KYAVdSr67W5NmiD0XhRP,xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN,Ps6p25Y9evV1iqgH
		else: J4tO21KYAVdSr67W5NmiD0XhRP,title,SOw5EUxC9k,ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr = J4tO21KYAVdSr67W5NmiD0XhRP,xqK9cBVPiU05fNhdOZrpzsGDlTX,V6QAOWYLrf53bSFCnN,Ps6p25Y9evV1iqgH
		SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k)
		SOw5EUxC9k = SOw5EUxC9k.replace('?view=true',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('بجوده ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		title = title.strip(kcXMWrwiLDKeBHRsJ)
		if 'الحلقة' in title or 'الحلقه' in title:
			er96jwp52cbvaV48mtylEYSRz = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|الحلقه) \d+',title,p7dwlH1PRStBgyMUW.DOTALL)
			if er96jwp52cbvaV48mtylEYSRz:
				title = '_MOD_' + er96jwp52cbvaV48mtylEYSRz[0][0]
				if title not in cIM3fQFnGYPxSV4eb9TvgWuokZA6H:
					octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,183,J4tO21KYAVdSr67W5NmiD0XhRP)
					cIM3fQFnGYPxSV4eb9TvgWuokZA6H.append(title)
		elif any(value in title for value in SnBhkFA2Z3gNVWJlz1ypa):
			SOw5EUxC9k = SOw5EUxC9k + '?servers=' + ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,182,J4tO21KYAVdSr67W5NmiD0XhRP)
		else:
			SOw5EUxC9k = SOw5EUxC9k + '?servers=' + ppLtsdzyvNCFgWJuZDjHlAIR0o7Xbr
			octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,183,J4tO21KYAVdSr67W5NmiD0XhRP)
	if type==WnNGfosHr5STAq8j7miwyRZ6eOUbV:
		items = p7dwlH1PRStBgyMUW.findall('\n<li><a href="(.*?)".*?>(.*?)<',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k,title in items:
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			title = title.replace('الصفحة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
			if title!=WnNGfosHr5STAq8j7miwyRZ6eOUbV:
				octplHnGwmE8bFqNdj7BiKvJ0VL('folder',uBQ9txp0gDrEhZTcJOi74SKVw3k+'صفحة '+title,SOw5EUxC9k,181)
	return
def d4TS7lOXiRVe0s3tg5JwIoz2Mh(url):
	vcQbFfCk6T1 = url.split('?servers=')[0]
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-EPISODES-1st')
	KDCdHQmgxPE21tYz4VUowSv = p7dwlH1PRStBgyMUW.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	title,PN2AmVoTyks5xOR1Ib9BqSQ,J4tO21KYAVdSr67W5NmiD0XhRP = KDCdHQmgxPE21tYz4VUowSv[0]
	name = p7dwlH1PRStBgyMUW.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,p7dwlH1PRStBgyMUW.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('class="episodesNumbers"(.*?)</div>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if cKUQVwTMe9tZSY:
		KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[0]
		items = p7dwlH1PRStBgyMUW.findall('href="(.*?)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
		for SOw5EUxC9k in items:
			SOw5EUxC9k = EZk136aeLoNqPvlDcTQpyM9Wm(SOw5EUxC9k)
			title = p7dwlH1PRStBgyMUW.findall('(الحلقة|الحلقه)-([0-9]+)',SOw5EUxC9k.split('/')[-2],p7dwlH1PRStBgyMUW.DOTALL)
			if not title: title = p7dwlH1PRStBgyMUW.findall('()-([0-9]+)',SOw5EUxC9k.split('/')[-2],p7dwlH1PRStBgyMUW.DOTALL)
			if title: title = kcXMWrwiLDKeBHRsJ + title[0][1]
			else: title = WnNGfosHr5STAq8j7miwyRZ6eOUbV
			title = name + ' - ' + 'الحلقة' + title
			title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
			octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,SOw5EUxC9k,182,J4tO21KYAVdSr67W5NmiD0XhRP)
	if not items:
		title = VfL8gR53PnAKwMiJ2vpUIWXSYt1bN(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',WnNGfosHr5STAq8j7miwyRZ6eOUbV).replace('بجوده ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
		octplHnGwmE8bFqNdj7BiKvJ0VL('video',uBQ9txp0gDrEhZTcJOi74SKVw3k+title,url,182,J4tO21KYAVdSr67W5NmiD0XhRP)
	return
def VUbtI0GRhPO2sg5C1DdNylMoYeKZkE(url):
	EHhzCdkcwuvfWP = url.split('?servers=')
	vcQbFfCk6T1 = EHhzCdkcwuvfWP[0]
	del EHhzCdkcwuvfWP[0]
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,vcQbFfCk6T1,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-PLAY-1st')
	SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('font-size: 25px;" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)[0]
	if SOw5EUxC9k not in EHhzCdkcwuvfWP: EHhzCdkcwuvfWP.append(SOw5EUxC9k)
	M0MFkiKqJDv1aZ4NA396u = []
	for SOw5EUxC9k in EHhzCdkcwuvfWP:
		if '://moshahda.' in SOw5EUxC9k:
			gqfGwv3Bm0V6SIlL1t5JNu = SOw5EUxC9k
			M0MFkiKqJDv1aZ4NA396u.append(gqfGwv3Bm0V6SIlL1t5JNu+'?named=Main')
	for SOw5EUxC9k in EHhzCdkcwuvfWP:
		if '://vb.movizland.' in SOw5EUxC9k:
			piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,SOw5EUxC9k,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-PLAY-2nd')
			piN9Qlah4S = piN9Qlah4S.decode(CRLStQiqxb6Y3Eh7G4UVF).encode(e87cIA5vwOQLDEP1)
			piN9Qlah4S = piN9Qlah4S.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			piN9Qlah4S = piN9Qlah4S.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			piN9Qlah4S = piN9Qlah4S.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			piN9Qlah4S = piN9Qlah4S.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			cKUQVwTMe9tZSY = p7dwlH1PRStBgyMUW.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
			if cKUQVwTMe9tZSY:
				OL7ND5xIzt36lV4oAyrkQJqUR,CZ3H7wEGYM9uDFl5JIm4dgP0Tx = [],[]
				if len(cKUQVwTMe9tZSY)==1:
					title = WnNGfosHr5STAq8j7miwyRZ6eOUbV
					KDCdHQmgxPE21tYz4VUowSv = piN9Qlah4S
				else:
					for KDCdHQmgxPE21tYz4VUowSv in cKUQVwTMe9tZSY:
						s5ocIDd4WKuPrV = p7dwlH1PRStBgyMUW.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
						if s5ocIDd4WKuPrV: KDCdHQmgxPE21tYz4VUowSv = 'src="/uploads/13721411411.png"  \n  ' + s5ocIDd4WKuPrV[0][1]
						s5ocIDd4WKuPrV = p7dwlH1PRStBgyMUW.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
						if s5ocIDd4WKuPrV: KDCdHQmgxPE21tYz4VUowSv = 'src="/uploads/13721411411.png"  \n  ' + s5ocIDd4WKuPrV[0]
						s5ocIDd4WKuPrV = p7dwlH1PRStBgyMUW.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
						if s5ocIDd4WKuPrV: KDCdHQmgxPE21tYz4VUowSv = s5ocIDd4WKuPrV[0] + '  \n  src="/uploads/13721411411.png"'
						a7HBdF0y2VOCmpXeztuWKwb = p7dwlH1PRStBgyMUW.findall('<(.*?)http://up.movizland.(online|com)/uploads/',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
						title = p7dwlH1PRStBgyMUW.findall('> *([^<>]+) *<',a7HBdF0y2VOCmpXeztuWKwb[0][0],p7dwlH1PRStBgyMUW.DOTALL)
						title = kcXMWrwiLDKeBHRsJ.join(title)
						title = title.strip(kcXMWrwiLDKeBHRsJ)
						title = title.replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ).replace(tTChquY7XSRg4e,kcXMWrwiLDKeBHRsJ)
						OL7ND5xIzt36lV4oAyrkQJqUR.append(title)
					XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('أختر الفيديو المطلوب:', OL7ND5xIzt36lV4oAyrkQJqUR)
					if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
					title = OL7ND5xIzt36lV4oAyrkQJqUR[XFaM94cPUCOWQZNIEe8gdJpny1]
					KDCdHQmgxPE21tYz4VUowSv = cKUQVwTMe9tZSY[XFaM94cPUCOWQZNIEe8gdJpny1]
				SOw5EUxC9k = p7dwlH1PRStBgyMUW.findall('href="(http://moshahda\..*?/\w+.html)"',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				iERedwJkHSDGrWgL7QaFhzT1pmyYB = SOw5EUxC9k[0]
				M0MFkiKqJDv1aZ4NA396u.append(iERedwJkHSDGrWgL7QaFhzT1pmyYB+'?named=Forum')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('ـ',WnNGfosHr5STAq8j7miwyRZ6eOUbV)
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				KDCdHQmgxPE21tYz4VUowSv = KDCdHQmgxPE21tYz4VUowSv.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				qIb6SnJ5irV97kT = p7dwlH1PRStBgyMUW.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',KDCdHQmgxPE21tYz4VUowSv,p7dwlH1PRStBgyMUW.DOTALL)
				for ZOIJh1C4vbAQY3e0B9DGl8 in qIb6SnJ5irV97kT:
					type = p7dwlH1PRStBgyMUW.findall(' typetype="(.*?)" ',ZOIJh1C4vbAQY3e0B9DGl8)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = WnNGfosHr5STAq8j7miwyRZ6eOUbV
					items = p7dwlH1PRStBgyMUW.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',ZOIJh1C4vbAQY3e0B9DGl8,p7dwlH1PRStBgyMUW.DOTALL)
					for khm6OfXFdRbeD5NljGxByaq4,SOw5EUxC9k in items:
						title = p7dwlH1PRStBgyMUW.findall('(\w+[ \w]*)<',khm6OfXFdRbeD5NljGxByaq4)
						title = title[-1]
						SOw5EUxC9k = SOw5EUxC9k + '?named=' + title + type
						M0MFkiKqJDv1aZ4NA396u.append(SOw5EUxC9k)
	QQTfhlZEDnu4wVcOeHGNyCBo5t2 = vcQbFfCk6T1.replace(pcE6DxaoHBm41WKXjwnk,wwmXPdcfpo)
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(oldym5kX8IqLSVDtpNMw,QQTfhlZEDnu4wVcOeHGNyCBo5t2,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-PLAY-3rd')
	items = p7dwlH1PRStBgyMUW.findall('" href="(.*?)"',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	if items:
		Mdv1JKAmDBHe5CxREj7wTty9OfZg = items[-1]
		M0MFkiKqJDv1aZ4NA396u.append(Mdv1JKAmDBHe5CxREj7wTty9OfZg+'?named=Mobile')
	import ltcz1qSYiV
	ltcz1qSYiV.iPbz0Vs8Q4khtA3IqCmUJj1HGpxK2L(M0MFkiKqJDv1aZ4NA396u,NTWE764hmOgUtScp2e8r,'video',url)
	return
def WmxfGFqceOyUtLT(search):
	search,xCONTFizaKbJS1,showDialogs = XgnSRzMaerBT(search)
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: search = x6S4MmiIE1hJ5bWUtdG02azC9Dgu()
	if search==WnNGfosHr5STAq8j7miwyRZ6eOUbV: return
	search = search.replace(kcXMWrwiLDKeBHRsJ,'+')
	piN9Qlah4S = RwK6BEzIXLl8oaWV94v2(nsFAzS2wvjyTYLOdDhfIiC0KGHE,pcE6DxaoHBm41WKXjwnk,WnNGfosHr5STAq8j7miwyRZ6eOUbV,headers,WnNGfosHr5STAq8j7miwyRZ6eOUbV,'MOVIZLAND-SEARCH-1st')
	items = p7dwlH1PRStBgyMUW.findall('<option value="(.*?)">(.*?)</option>',piN9Qlah4S,p7dwlH1PRStBgyMUW.DOTALL)
	AKrMlOaiGqNBbcuW5eh6y9xJ1Dp = [ WnNGfosHr5STAq8j7miwyRZ6eOUbV ]
	JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb = [ 'الكل وبدون فلتر' ]
	for eukVjoW67vBiySNXrplDKIZLHU,title in items:
		AKrMlOaiGqNBbcuW5eh6y9xJ1Dp.append(eukVjoW67vBiySNXrplDKIZLHU)
		JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb.append(title)
	if eukVjoW67vBiySNXrplDKIZLHU:
		XFaM94cPUCOWQZNIEe8gdJpny1 = A3DjqpQcnvi6O0oXxGTlz19ytdKu('اختر الفلتر المناسب:', JmzcTCHtxvef3AXQj2wRV1Ol6uK5gb)
		if XFaM94cPUCOWQZNIEe8gdJpny1 == -1 : return
		eukVjoW67vBiySNXrplDKIZLHU = AKrMlOaiGqNBbcuW5eh6y9xJ1Dp[XFaM94cPUCOWQZNIEe8gdJpny1]
	else: eukVjoW67vBiySNXrplDKIZLHU = WnNGfosHr5STAq8j7miwyRZ6eOUbV
	url = pcE6DxaoHBm41WKXjwnk + '/?s='+search+'&mcat='+eukVjoW67vBiySNXrplDKIZLHU
	ctDj2OVRyaUPXCrITmJG(url)
	return