# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
UdbRGoKhcDeI4lVfns5 = 'AKOAM'
UT69hgqoKsWNIwM5zkAYb = '_AKO_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
BpZLTxzthcK4f3RH7qY = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==70: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==71: RCmHBOKtejQ8lu4L = PMUWbuAce6qaXfkjKH38iYhz(url)
	elif mode==72: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==73: RCmHBOKtejQ8lu4L = fAg4xzTIY3Z9qdpFJsDGNvX5(url)
	elif mode==74: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==79: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,79,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'سلسلة افلام',wUvcPrYDfISbZolAm83GKEqMyXkn5,79,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'سلسلة افلام')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'سلاسل منوعة',wUvcPrYDfISbZolAm83GKEqMyXkn5,79,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'سلسلة')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	i6TIRax9v0EDFJs2gVtfzp = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAM-MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="partions"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title not in i6TIRax9v0EDFJs2gVtfzp:
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,71)
	return II64TLxj3mbqEyh9pHQ8oAv
def PMUWbuAce6qaXfkjKH38iYhz(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAM-CATEGORIES-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('sect_parts(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,72)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'جميع الفروع',url,72)
	else: HPdaS7kenW0m(url,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	return
def HPdaS7kenW0m(url,type):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('section_title featured_title(.*?)subjects-crousel',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='search':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('akoam_result(.*?)<script',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='more':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('section_title more_title(.*?)footer_bottom_services',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('navigation(.*?)<script',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not items and pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if any(value in title for value in BpZLTxzthcK4f3RH7qY): mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,73,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,73,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall("</li><li >.*?href='(.*?)'>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,72,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def eqbKRfH5WyJApZUFaSku08h4EjwI(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAM-SECTIONS-2nd')
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('"href","(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[1]
	return ZD5n0eJivzWOMxY98dgrumkwRG
def fAg4xzTIY3Z9qdpFJsDGNvX5(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAM-SECTIONS-1st')
	MQdvrPomVWcpq1l8k = jj0dZrgiKb.findall('"(https*://akwam.net/\w+.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	Wpqk8DM54dV6SC2s = jj0dZrgiKb.findall('"(https*://underurl.com/\w+.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if MQdvrPomVWcpq1l8k or Wpqk8DM54dV6SC2s:
		if MQdvrPomVWcpq1l8k: qaLFXuDExl8w = MQdvrPomVWcpq1l8k[0]
		elif Wpqk8DM54dV6SC2s: qaLFXuDExl8w = eqbKRfH5WyJApZUFaSku08h4EjwI(Wpqk8DM54dV6SC2s[0])
		qaLFXuDExl8w = Z6bUG0kDQuFqgzdAa1r(qaLFXuDExl8w)
		import myIlApe52K
		if '/series/' in qaLFXuDExl8w or '/shows/' in qaLFXuDExl8w: myIlApe52K.mCwqRg7HpivAQ6S(qaLFXuDExl8w)
		else: myIlApe52K.lHcaGxFV0wy9UrN7Cv6o5dInLQ(qaLFXuDExl8w)
		return
	bxiMUQmPRvu = jj0dZrgiKb.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	items = jj0dZrgiKb.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,73)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70:
		hg79cQmoVfMCukiU8ERpT6JqywSrN3('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	if 'sub_epsiode_title' in IJE2xcV7OWauUKhfik56gXBwltCb:
		items = jj0dZrgiKb.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	else:
		M2CpYyvKVArfiQZOnm7hDGJszTE = jj0dZrgiKb.findall('sub_file_title\'>(.*?) - <i>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		items = []
		for filename in M2CpYyvKVArfiQZOnm7hDGJszTE:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',wUvcPrYDfISbZolAm83GKEqMyXkn5) ]
	count = 0
	Eu8LWnSt3fyJzIC,mS9VE8GuR3k2o6MO = [],[]
	size = len(items)
	for title,filename in items:
		t3oe4rjuvpMQKwRnbkTaqYsAI6i5 = wUvcPrYDfISbZolAm83GKEqMyXkn5
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: t3oe4rjuvpMQKwRnbkTaqYsAI6i5 = filename.split('.')[-1]
		title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		Eu8LWnSt3fyJzIC.append(title)
		mS9VE8GuR3k2o6MO.append(count)
		count += 1
	if size>0:
		if any(value in name for value in BpZLTxzthcK4f3RH7qY):
			if size==1:
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 0
			else:
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر الفيديو المناسب:', Eu8LWnSt3fyJzIC)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1: return
			lHcaGxFV0wy9UrN7Cv6o5dInLQ(url+'?section='+str(1+mS9VE8GuR3k2o6MO[size-EcQws7L35GvtIpl0k1gJZWTNPDbmMq-1]))
		else:
			for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in reversed(range(size)):
				title = name + ' - ' + Eu8LWnSt3fyJzIC[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]
				title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				hhEH1rcSP0z6Bkqy8OD = url + '?section='+str(size-kkLhJCU4MQSx7s6gyeOHrRYKtnP3)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,74,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+'الرابط ليس فيديو',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	ZD5n0eJivzWOMxY98dgrumkwRG,xNVKL75nEZstg4wfXBkySQ = url.split('?section=')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAM-PLAY_AKOAM-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	L9UXvbuQsnEYDjgteThBmadk = pLHIPUY3TWAeE70[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	L9UXvbuQsnEYDjgteThBmadk = L9UXvbuQsnEYDjgteThBmadk + 'direct_link_box'
	qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('epsoide_box(.*?)direct_link_box',L9UXvbuQsnEYDjgteThBmadk,jj0dZrgiKb.DOTALL)
	xNVKL75nEZstg4wfXBkySQ = len(qqtR56dgVLh3Tr2)-int(xNVKL75nEZstg4wfXBkySQ)
	IJE2xcV7OWauUKhfik56gXBwltCb = qqtR56dgVLh3Tr2[xNVKL75nEZstg4wfXBkySQ]
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	zeEbT0PfRBcwVSu = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = jj0dZrgiKb.findall("class='download_btn.*?href='(.*?)'",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD in items:
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=________akoam')
	items = jj0dZrgiKb.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for OG91QeNz4rbHKcu6tLxDyFgRX,hhEH1rcSP0z6Bkqy8OD in items:
		OG91QeNz4rbHKcu6tLxDyFgRX = OG91QeNz4rbHKcu6tLxDyFgRX.split('/')[-1]
		OG91QeNz4rbHKcu6tLxDyFgRX = OG91QeNz4rbHKcu6tLxDyFgRX.split('.')[0]
		if OG91QeNz4rbHKcu6tLxDyFgRX in zeEbT0PfRBcwVSu:
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+zeEbT0PfRBcwVSu[OG91QeNz4rbHKcu6tLxDyFgRX]+'________akoam')
		else: jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+OG91QeNz4rbHKcu6tLxDyFgRX+'________akoam')
	if not jcInvNf98TZ5gRUDFp40li2uzVPrO:
		message = jj0dZrgiKb.findall('sub-no-file.*?\n(.*?)\n',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if message: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'رسالة من الموقع الاصلي',message[0])
	else:
		import oo6FYcUjud
		oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/search/'+LBqdVs9ioWwpMbCm1A
	RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,'search')
	return