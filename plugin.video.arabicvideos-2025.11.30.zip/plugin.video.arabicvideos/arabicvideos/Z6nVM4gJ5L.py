# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = vWNRusF46D7Mi8GpZ(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
UT69hgqoKsWNIwM5zkAYb = DpRJnas65uVcO0S17dYG(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
HHfpVrRkEwacs6vS71qjx23mCQIdBn = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(Rj3VsmvbuAdWhUg7ETykSLw,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
CKJo1lzpE7Nih8XMAV4SkbLtswW2UO = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(Rj3VsmvbuAdWhUg7ETykSLw,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
YNzq76X410d8n5GxyLuaMrE = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),Gj3rMP1Cb8wHdp49la0(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
VIm9uLgZ3qjrb2G = D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
kZVIBmNJEuahs48oXCtGFWP = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
DDJjkxT4QY = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
iMARn95Tg0 = lCT8hfYUBX4OQMmL(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
xr2OL5EhU3g6 = fmkZtbRj3ux(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
QV2lC71hDuxpjwY4T = VhqD3zp7mUieI8sMQlETH(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
Qh3zJjmgD7xvuWFSZ = CCrtv6o3mySp
Nz3hOgdJacSsLE = kAXGQe4sH7o3dfLUKv2zlZDM8r09
BtTXwLWkPNyzRarf5Mp9o = EEB78CMKb0SOQrGgN9
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==D2PpKMeZFWrmfxTSs4L1tz(u"࠹࠷࠴ࣉ"): RCmHBOKtejQ8lu4L = PRHimxeqy2CZgIKWp1uLh6XUk()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xdSThjYnuHXAU6M(u"࠺࠸࠶࣊"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(HHfpVrRkEwacs6vS71qjx23mCQIdBn,y0yvdNOZkiKEg5RLMhoDVQAB9F2,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==llkFwuCyhaP3sK76qO4T(u"࠻࠹࠸࣋"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(CKJo1lzpE7Nih8XMAV4SkbLtswW2UO,y0yvdNOZkiKEg5RLMhoDVQAB9F2,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠼࠺࠳࣌"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(YNzq76X410d8n5GxyLuaMrE,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠽࠴࠵࣍"): RCmHBOKtejQ8lu4L = zEdV2Itnhmya8cxvDG(y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷࠵࠷࣎"): RCmHBOKtejQ8lu4L = qQ2BKeYxTa6XFdfbH(y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠸࠶࠹࣏"): RCmHBOKtejQ8lu4L = tj95SCFkQ8W3ye0h(y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==s149dk8uh2p7oFzaLxZeI3Or(u"࠹࠸࠴࣐"): RCmHBOKtejQ8lu4L = ZEB1dWfx4QCy5()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠺࠹࠶࣑"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(VIm9uLgZ3qjrb2G,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==MFhbWia58mP3su0fk2d(u"࠻࠺࠸࣒"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(kZVIBmNJEuahs48oXCtGFWP,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xm6jK1ZMuWq5(u"࠼࠻࠳࣓"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(DDJjkxT4QY,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==erqDsJmL3BQHuGtPkcf0X9(u"࠽࠵࠵ࣔ"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(iMARn95Tg0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠷࠶࠷ࣕ"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(xr2OL5EhU3g6,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠸࠷࠹ࣖ"): RCmHBOKtejQ8lu4L = THqDmj0Frnf38wX7MkVZ1u9NaGi(QV2lC71hDuxpjwY4T,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==fmkZtbRj3ux(u"࠹࠸࠻ࣗ"): RCmHBOKtejQ8lu4L = WWJMU4sjpb2rY(y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==rDG9dZoXRhCJcieUSF0KB(u"࠺࠹࠽ࣘ"): RCmHBOKtejQ8lu4L = KNn5uve7PMBI();awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠵࠾࠰ࣙ"): RCmHBOKtejQ8lu4L = gan0qVPWRrvC2d9KQTleykbL67()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==JHMxIE4fs1mvQtKW7R(u"࠶࠶࠸࠲ࣚ"): RCmHBOKtejQ8lu4L = hEdwOHJvMWtL72Z6opxBTYel(y0yvdNOZkiKEg5RLMhoDVQAB9F2);awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==vWNRusF46D7Mi8GpZ(u"࠷࠰࠹࠴ࣛ"): RCmHBOKtejQ8lu4L = J2CZbO0Pxc5pTRY();awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==MFhbWia58mP3su0fk2d(u"࠱࠱࠺࠶ࣜ"): RCmHBOKtejQ8lu4L = YYASLIvKz3tpPb1uCiQ47NMFxoal();awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==s149dk8uh2p7oFzaLxZeI3Or(u"࠲࠲࠻࠸ࣝ"): RCmHBOKtejQ8lu4L = gZwVuShGK4AlOYnysLFH2i9();awIvSbXPkY9NDziT6O4loCd5FBem(RCmHBOKtejQ8lu4L)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠳࠳࠼࠺ࣞ"): RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠴࠴࠽࠼ࣟ"): RCmHBOKtejQ8lu4L = WsIPLAlh65zifDqp9gCmb8cYG0V()
	else: RCmHBOKtejQ8lu4L = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return RCmHBOKtejQ8lu4L
def WsIPLAlh65zifDqp9gCmb8cYG0V():
	TWOUKC3StPv6AQrXMJ9N5kipF8YVZ = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵࠵࠸࠴࣠")*jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵࠵࠸࠴࣠")
	oiLVm4fSj5hYsdXNaFATU = NpzKdEgZiV4efDOCRqUwIWBTXA2()//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ
	NHgkvdC0K176aEGsjo4ze = oiLVm4fSj5hYsdXNaFATU<llkFwuCyhaP3sK76qO4T(u"࠺࠶࣡")
	size = JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(oiLVm4fSj5hYsdXNaFATU)+fmkZtbRj3ux(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+AAByQSLgaZwCsKnvc5eWNmY
	if NHgkvdC0K176aEGsjo4ze:
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,A6Sg45ChDR3BJLYfFH(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(oiLVm4fSj5hYsdXNaFATU)+xdSThjYnuHXAU6M(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return NHgkvdC0K176aEGsjo4ze
def awIvSbXPkY9NDziT6O4loCd5FBem(DvyB3Hri17aCIO84YtkQ):
	if DvyB3Hri17aCIO84YtkQ: ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B(yRWQMHxZEz0(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"࠷࠰࠹࠸࣢"))
	mwOxEyYAg63B(jQv0du1iVxTgAXCM(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),kPCxIUZb1V(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷࠶࠲ࣣ"))
	mwOxEyYAg63B(fmkZtbRj3ux(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"࠸࠶࠳ࣤ"))
	mwOxEyYAg63B(jQv0du1iVxTgAXCM(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),xdSThjYnuHXAU6M(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"࠳࠳࠼࠵ࣥ"))
	return
def gan0qVPWRrvC2d9KQTleykbL67():
	llDbHLzRr6vsA7gkwh8,s9nZmJaMpD = FFhBAMutCwR(Qh3zJjmgD7xvuWFSZ)
	CfO6yjYMhWgecNE9ib3ndzlmvaP,j0UKftS9kcuD = FFhBAMutCwR(Nz3hOgdJacSsLE)
	AlPFeZrjxu30gLv1OCU5JXiD,wCSec7fGsL4N0Ok = xDXC5AF31hBZ2gRGJafuK6zENQMO(BtTXwLWkPNyzRarf5Mp9o)
	RclWs23jK8N5wf4VvnS,JVpZ8hbOUlFjNyaqLXY = llDbHLzRr6vsA7gkwh8+CfO6yjYMhWgecNE9ib3ndzlmvaP+AlPFeZrjxu30gLv1OCU5JXiD,s9nZmJaMpD+j0UKftS9kcuD+wCSec7fGsL4N0Ok
	h3Jgd6TZ2S = xdSThjYnuHXAU6M(u"ࠩࠣࠬࠬࠚ")+b6esHxdrB7WI4lkuZG(llDbHLzRr6vsA7gkwh8)+xdSThjYnuHXAU6M(u"ࠪࠤ࠲ࠦࠧࠛ")+str(s9nZmJaMpD)+yRWQMHxZEz0(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	Z9e2VLl7DY0 = jQv0du1iVxTgAXCM(u"ࠬࠦࠨࠨࠝ")+b6esHxdrB7WI4lkuZG(CfO6yjYMhWgecNE9ib3ndzlmvaP)+Gj3rMP1Cb8wHdp49la0(u"࠭ࠠ࠮ࠢࠪࠞ")+str(j0UKftS9kcuD)+xdSThjYnuHXAU6M(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	oAPbpfTJBFyvOxUN07qGXInw = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࠢࠫࠫࠠ")+b6esHxdrB7WI4lkuZG(AlPFeZrjxu30gLv1OCU5JXiD)+w8JC1y7Lp3(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(wCSec7fGsL4N0Ok)+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	nv09Z1uGJDl = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࠥ࠮ࠧࠣ")+b6esHxdrB7WI4lkuZG(RclWs23jK8N5wf4VvnS)+w8JC1y7Lp3(u"ࠬࠦ࠭ࠡࠩࠤ")+str(JVpZ8hbOUlFjNyaqLXY)+TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	mwOxEyYAg63B(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),UT69hgqoKsWNIwM5zkAYb+TNw1pBHb8CtSZe0EFxuJqI(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠴࠴࠽࠺ࣦ"))
	mwOxEyYAg63B(s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),JegF7SlMawI03+vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"࠽࠾࠿࠹ࣧ"))
	mwOxEyYAg63B(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),UT69hgqoKsWNIwM5zkAYb+bQGafNLXyFgsZP6ut(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+h3Jgd6TZ2S,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠶࠶࠸࠲ࣨ"))
	mwOxEyYAg63B(jQv0du1iVxTgAXCM(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),UT69hgqoKsWNIwM5zkAYb+VhqD3zp7mUieI8sMQlETH(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+Z9e2VLl7DY0,wUvcPrYDfISbZolAm83GKEqMyXkn5,kPCxIUZb1V(u"࠷࠰࠹࠴ࣩ"))
	mwOxEyYAg63B(bQGafNLXyFgsZP6ut(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),UT69hgqoKsWNIwM5zkAYb+kPCxIUZb1V(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+oAPbpfTJBFyvOxUN07qGXInw,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"࠱࠱࠺࠶࣪"))
	mwOxEyYAg63B(w8JC1y7Lp3(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),UT69hgqoKsWNIwM5zkAYb+w8JC1y7Lp3(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"࠲࠲࠻࠸࣫"))
	return
def gZwVuShGK4AlOYnysLFH2i9():
	DvyB3Hri17aCIO84YtkQ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if ug0EmiKYnRT1qeH9MFyr3pO:
		VR6DBe2yC41h5HPxz9gpFnGmkio = YYASLIvKz3tpPb1uCiQ47NMFxoal()
		PBqxmJwpMu5FZeQgfNd1C0R6a = THqDmj0Frnf38wX7MkVZ1u9NaGi(kAXGQe4sH7o3dfLUKv2zlZDM8r09,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		DvyB3Hri17aCIO84YtkQ = VR6DBe2yC41h5HPxz9gpFnGmkio and PBqxmJwpMu5FZeQgfNd1C0R6a
		if DvyB3Hri17aCIO84YtkQ: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return DvyB3Hri17aCIO84YtkQ
def J2CZbO0Pxc5pTRY():
	import tdeCZlJnBw
	tdeCZlJnBw.wXuabJjLsQBfVE()
	n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),jQv0du1iVxTgAXCM(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
		n453i9Fwpc6bGMuUa2l = THqDmj0Frnf38wX7MkVZ1u9NaGi(kAXGQe4sH7o3dfLUKv2zlZDM8r09,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		if n453i9Fwpc6bGMuUa2l: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,xdSThjYnuHXAU6M(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return n453i9Fwpc6bGMuUa2l
def YYASLIvKz3tpPb1uCiQ47NMFxoal():
	n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(A6Sg45ChDR3BJLYfFH(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"ࠧิฦส่ࠬ࠻"),VhqD3zp7mUieI8sMQlETH(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
		try:
			b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(EEB78CMKb0SOQrGgN9)
			n453i9Fwpc6bGMuUa2l = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		except: pass
		if n453i9Fwpc6bGMuUa2l: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return n453i9Fwpc6bGMuUa2l
def gan0qVPWRrvC2d9KQTleykbL67():
	llDbHLzRr6vsA7gkwh8,s9nZmJaMpD = FFhBAMutCwR(Qh3zJjmgD7xvuWFSZ)
	CfO6yjYMhWgecNE9ib3ndzlmvaP,j0UKftS9kcuD = FFhBAMutCwR(Nz3hOgdJacSsLE)
	AlPFeZrjxu30gLv1OCU5JXiD,wCSec7fGsL4N0Ok = xDXC5AF31hBZ2gRGJafuK6zENQMO(BtTXwLWkPNyzRarf5Mp9o)
	RclWs23jK8N5wf4VvnS,JVpZ8hbOUlFjNyaqLXY = llDbHLzRr6vsA7gkwh8+CfO6yjYMhWgecNE9ib3ndzlmvaP+AlPFeZrjxu30gLv1OCU5JXiD,s9nZmJaMpD+j0UKftS9kcuD+wCSec7fGsL4N0Ok
	h3Jgd6TZ2S = vWNRusF46D7Mi8GpZ(u"ࠫࠥ࠮ࠧ࠿")+b6esHxdrB7WI4lkuZG(llDbHLzRr6vsA7gkwh8)+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦ࠭ࠡࠩࡀ")+str(s9nZmJaMpD)+JHMxIE4fs1mvQtKW7R(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	Z9e2VLl7DY0 = weh7SGmuTgXOVRcMo1rlLq(u"ࠧࠡࠪࠪࡂ")+b6esHxdrB7WI4lkuZG(CfO6yjYMhWgecNE9ib3ndzlmvaP)+vWNRusF46D7Mi8GpZ(u"ࠨࠢ࠰ࠤࠬࡃ")+str(j0UKftS9kcuD)+jQv0du1iVxTgAXCM(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	oAPbpfTJBFyvOxUN07qGXInw = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࠤ࠭࠭ࡅ")+b6esHxdrB7WI4lkuZG(AlPFeZrjxu30gLv1OCU5JXiD)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࠥ࠳ࠠࠨࡆ")+str(wCSec7fGsL4N0Ok)+vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	nv09Z1uGJDl = DpRJnas65uVcO0S17dYG(u"࠭ࠠࠩࠩࡈ")+b6esHxdrB7WI4lkuZG(RclWs23jK8N5wf4VvnS)+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࠡ࠯ࠣࠫࡉ")+str(JVpZ8hbOUlFjNyaqLXY)+kPCxIUZb1V(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	mwOxEyYAg63B(MFhbWia58mP3su0fk2d(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),UT69hgqoKsWNIwM5zkAYb+A6Sg45ChDR3BJLYfFH(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"࠳࠳࠼࠹࣬"))
	mwOxEyYAg63B(A6Sg45ChDR3BJLYfFH(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),JegF7SlMawI03+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"࠼࠽࠾࠿࣭"))
	mwOxEyYAg63B(lCT8hfYUBX4OQMmL(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),UT69hgqoKsWNIwM5zkAYb+kPCxIUZb1V(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+h3Jgd6TZ2S,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵࠵࠾࠱࣮"))
	mwOxEyYAg63B(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),UT69hgqoKsWNIwM5zkAYb+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+Z9e2VLl7DY0,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠶࠶࠸࠳࣯"))
	mwOxEyYAg63B(kPCxIUZb1V(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),UT69hgqoKsWNIwM5zkAYb+rDG9dZoXRhCJcieUSF0KB(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+oAPbpfTJBFyvOxUN07qGXInw,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠷࠰࠹࠵ࣰ"))
	mwOxEyYAg63B(yRWQMHxZEz0(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),UT69hgqoKsWNIwM5zkAYb+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠱࠱࠺࠷ࣱ"))
	return
def PRHimxeqy2CZgIKWp1uLh6XUk():
	llDbHLzRr6vsA7gkwh8,s9nZmJaMpD = FFhBAMutCwR(HHfpVrRkEwacs6vS71qjx23mCQIdBn)
	CfO6yjYMhWgecNE9ib3ndzlmvaP,j0UKftS9kcuD = FFhBAMutCwR(CKJo1lzpE7Nih8XMAV4SkbLtswW2UO)
	AlPFeZrjxu30gLv1OCU5JXiD,wCSec7fGsL4N0Ok = FFhBAMutCwR(YNzq76X410d8n5GxyLuaMrE)
	RclWs23jK8N5wf4VvnS,JVpZ8hbOUlFjNyaqLXY = xDXC5AF31hBZ2gRGJafuK6zENQMO(AZ7XwOdthHi)
	RclWs23jK8N5wf4VvnS -= D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠸࠻࠺࠹ࣲ")
	JVpZ8hbOUlFjNyaqLXY -= UD4N8MjVTd
	dOCgFmA6NUr4ols7ufiGJ = str(b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(JMVGrgf2Qj69HKpu))
	OOpyfGKHDCSLjmInE = dOCgFmA6NUr4ols7ufiGJ.count(vWNRusF46D7Mi8GpZ(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+dOCgFmA6NUr4ols7ufiGJ.count(rDG9dZoXRhCJcieUSF0KB(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	h3Jgd6TZ2S = w8JC1y7Lp3(u"࡙ࠩࠣࠬࠬ")+b6esHxdrB7WI4lkuZG(llDbHLzRr6vsA7gkwh8)+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࠤ࠲࡚ࠦࠧ")+str(s9nZmJaMpD)+s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	Z9e2VLl7DY0 = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦࠨࠨ࡜")+b6esHxdrB7WI4lkuZG(CfO6yjYMhWgecNE9ib3ndzlmvaP)+xdSThjYnuHXAU6M(u"࠭ࠠ࠮ࠢࠪ࡝")+str(j0UKftS9kcuD)+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	oAPbpfTJBFyvOxUN07qGXInw = vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࠢࠫࠫ࡟")+b6esHxdrB7WI4lkuZG(AlPFeZrjxu30gLv1OCU5JXiD)+s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(wCSec7fGsL4N0Ok)+JHMxIE4fs1mvQtKW7R(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	nv09Z1uGJDl = w8JC1y7Lp3(u"ࠫࠥ࠮ࠧࡢ")+b6esHxdrB7WI4lkuZG(RclWs23jK8N5wf4VvnS)+MFhbWia58mP3su0fk2d(u"ࠬ࠯ࠧࡣ")
	SKE4p9hZL8dywzGvWJ5 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࠠࠩࠩࡤ")+str(OOpyfGKHDCSLjmInE)+fmkZtbRj3ux(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	zWYxbrfRlyUCiAcL68ZG = llDbHLzRr6vsA7gkwh8+CfO6yjYMhWgecNE9ib3ndzlmvaP+AlPFeZrjxu30gLv1OCU5JXiD+RclWs23jK8N5wf4VvnS
	mnDKBYwZl8SM0zk6 = s9nZmJaMpD+j0UKftS9kcuD+wCSec7fGsL4N0Ok+JVpZ8hbOUlFjNyaqLXY+OOpyfGKHDCSLjmInE
	eIRJAgj25bzvNik48puZl3OPUq = bQGafNLXyFgsZP6ut(u"ࠨࠢࠫࠫࡦ")+b6esHxdrB7WI4lkuZG(zWYxbrfRlyUCiAcL68ZG)+DpRJnas65uVcO0S17dYG(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(mnDKBYwZl8SM0zk6)+xdSThjYnuHXAU6M(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	mwOxEyYAg63B(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),UT69hgqoKsWNIwM5zkAYb+xm6jK1ZMuWq5(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"࠹࠷࠹ࣳ"))
	mwOxEyYAg63B(DpRJnas65uVcO0S17dYG(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠼࠽࠾࠿ࣴ"))
	mwOxEyYAg63B(fmkZtbRj3ux(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),UT69hgqoKsWNIwM5zkAYb+D2PpKMeZFWrmfxTSs4L1tz(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+h3Jgd6TZ2S,wUvcPrYDfISbZolAm83GKEqMyXkn5,kPCxIUZb1V(u"࠻࠹࠷ࣵ"))
	mwOxEyYAg63B(fmkZtbRj3ux(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),UT69hgqoKsWNIwM5zkAYb+fmkZtbRj3ux(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+Z9e2VLl7DY0,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"࠼࠺࠲ࣶ"))
	mwOxEyYAg63B(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),UT69hgqoKsWNIwM5zkAYb+MFhbWia58mP3su0fk2d(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+oAPbpfTJBFyvOxUN07qGXInw,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠽࠴࠴ࣷ"))
	mwOxEyYAg63B(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),UT69hgqoKsWNIwM5zkAYb+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷࠵࠶ࣸ"))
	mwOxEyYAg63B(VhqD3zp7mUieI8sMQlETH(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),UT69hgqoKsWNIwM5zkAYb+w8JC1y7Lp3(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+SKE4p9hZL8dywzGvWJ5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"࠸࠶࠹ࣹ"))
	return
def ZEB1dWfx4QCy5():
	CLERmhwFg5fpr = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if A6Sg45ChDR3BJLYfFH(u"ࠫ࠴࠭ࡷ") in KXekl8MiCfjSYDHdWqw else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if not CLERmhwFg5fpr:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	vvbRDXmZEyYa = OOnvcPQy85HYA.getSetting(lCT8hfYUBX4OQMmL(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not vvbRDXmZEyYa: KNn5uve7PMBI()
	llDbHLzRr6vsA7gkwh8,s9nZmJaMpD = FFhBAMutCwR(VIm9uLgZ3qjrb2G)
	CfO6yjYMhWgecNE9ib3ndzlmvaP,j0UKftS9kcuD = FFhBAMutCwR(kZVIBmNJEuahs48oXCtGFWP)
	AlPFeZrjxu30gLv1OCU5JXiD,wCSec7fGsL4N0Ok = FFhBAMutCwR(DDJjkxT4QY)
	RclWs23jK8N5wf4VvnS,JVpZ8hbOUlFjNyaqLXY = FFhBAMutCwR(iMARn95Tg0)
	MCh1Dj5gpY3RleBGx8tZPvXEVs,OOpyfGKHDCSLjmInE = FFhBAMutCwR(xr2OL5EhU3g6)
	oB7MIcxJpHQYNG1mFPnKhOt,HHwPFs6CAoTZ = FFhBAMutCwR(QV2lC71hDuxpjwY4T)
	h3Jgd6TZ2S = Gj3rMP1Cb8wHdp49la0(u"ࠧࠡࠪࠪࡺ")+b6esHxdrB7WI4lkuZG(llDbHLzRr6vsA7gkwh8)+DpRJnas65uVcO0S17dYG(u"ࠨࠢ࠰ࠤࠬࡻ")+str(s9nZmJaMpD)+yRWQMHxZEz0(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	Z9e2VLl7DY0 = erqDsJmL3BQHuGtPkcf0X9(u"ࠪࠤ࠭࠭ࡽ")+b6esHxdrB7WI4lkuZG(CfO6yjYMhWgecNE9ib3ndzlmvaP)+kPCxIUZb1V(u"ࠫࠥ࠳ࠠࠨࡾ")+str(j0UKftS9kcuD)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	oAPbpfTJBFyvOxUN07qGXInw = s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࠠࠩࠩࢀ")+b6esHxdrB7WI4lkuZG(AlPFeZrjxu30gLv1OCU5JXiD)+xm6jK1ZMuWq5(u"ࠧࠡ࠯ࠣࠫࢁ")+str(wCSec7fGsL4N0Ok)+xm6jK1ZMuWq5(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	nv09Z1uGJDl = lCT8hfYUBX4OQMmL(u"ࠩࠣࠬࠬࢃ")+b6esHxdrB7WI4lkuZG(RclWs23jK8N5wf4VvnS)+MFhbWia58mP3su0fk2d(u"ࠪࠤ࠲ࠦࠧࢄ")+str(JVpZ8hbOUlFjNyaqLXY)+JHMxIE4fs1mvQtKW7R(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	SKE4p9hZL8dywzGvWJ5 = kPCxIUZb1V(u"ࠬࠦࠨࠨࢆ")+b6esHxdrB7WI4lkuZG(MCh1Dj5gpY3RleBGx8tZPvXEVs)+DpRJnas65uVcO0S17dYG(u"࠭ࠠ࠮ࠢࠪࢇ")+str(OOpyfGKHDCSLjmInE)+MFhbWia58mP3su0fk2d(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	BzKefb9WJ6GS = DpRJnas65uVcO0S17dYG(u"ࠨࠢࠫࠫࢉ")+b6esHxdrB7WI4lkuZG(oB7MIcxJpHQYNG1mFPnKhOt)+Gj3rMP1Cb8wHdp49la0(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(HHwPFs6CAoTZ)+fmkZtbRj3ux(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	zWYxbrfRlyUCiAcL68ZG = llDbHLzRr6vsA7gkwh8+CfO6yjYMhWgecNE9ib3ndzlmvaP+AlPFeZrjxu30gLv1OCU5JXiD+RclWs23jK8N5wf4VvnS+MCh1Dj5gpY3RleBGx8tZPvXEVs+oB7MIcxJpHQYNG1mFPnKhOt
	mnDKBYwZl8SM0zk6 = s9nZmJaMpD+j0UKftS9kcuD+wCSec7fGsL4N0Ok+JVpZ8hbOUlFjNyaqLXY+OOpyfGKHDCSLjmInE+HHwPFs6CAoTZ
	eIRJAgj25bzvNik48puZl3OPUq = Gj3rMP1Cb8wHdp49la0(u"ࠫࠥ࠮ࠧࢌ")+b6esHxdrB7WI4lkuZG(zWYxbrfRlyUCiAcL68ZG)+it4DKnryZlx(u"ࠬࠦ࠭ࠡࠩࢍ")+str(mnDKBYwZl8SM0zk6)+kPCxIUZb1V(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	mwOxEyYAg63B(fmkZtbRj3ux(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),UT69hgqoKsWNIwM5zkAYb+jQv0du1iVxTgAXCM(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠹࠸࠼ࣺ"))
	mwOxEyYAg63B(kPCxIUZb1V(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),UT69hgqoKsWNIwM5zkAYb+Gj3rMP1Cb8wHdp49la0(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠺࠹࠼ࣻ"))
	mwOxEyYAg63B(weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),JegF7SlMawI03+bQGafNLXyFgsZP6ut(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠽࠾࠿࠹ࣼ"))
	mwOxEyYAg63B(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),UT69hgqoKsWNIwM5zkAYb+it4DKnryZlx(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+h3Jgd6TZ2S,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠼࠻࠱ࣽ"))
	mwOxEyYAg63B(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),UT69hgqoKsWNIwM5zkAYb+lCT8hfYUBX4OQMmL(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+Z9e2VLl7DY0,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠽࠵࠳ࣾ"))
	mwOxEyYAg63B(xm6jK1ZMuWq5(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),UT69hgqoKsWNIwM5zkAYb+MFhbWia58mP3su0fk2d(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+oAPbpfTJBFyvOxUN07qGXInw,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"࠷࠶࠵ࣿ"))
	mwOxEyYAg63B(w8JC1y7Lp3(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),UT69hgqoKsWNIwM5zkAYb+jQv0du1iVxTgAXCM(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+nv09Z1uGJDl,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"࠸࠷࠷ऀ"))
	mwOxEyYAg63B(DpRJnas65uVcO0S17dYG(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),UT69hgqoKsWNIwM5zkAYb+fmkZtbRj3ux(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+SKE4p9hZL8dywzGvWJ5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠹࠸࠹ँ"))
	mwOxEyYAg63B(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),UT69hgqoKsWNIwM5zkAYb+D2PpKMeZFWrmfxTSs4L1tz(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+BzKefb9WJ6GS,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"࠺࠹࠻ं"))
	return
def hEdwOHJvMWtL72Z6opxBTYel(showDialogs):
	if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	D8CmWJfpZUnLTF,K2HSI6syC3Fo4d01MtcmRPONp8qGAa = [],wTLFCOcM26fmYlW7U
	for sVvmAZyqw0F5UT4t6BKJaprEQ,aCle1prw9vOVEDsH,SQ061b3qWjItgJXBn8GFxkA5 in b7i1PgC8Z4e5BFoHNd9E2UVvfc.walk(CCrtv6o3mySp,topdown=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
		CCwFhi3yksq17gDUP9jZ = len(SQ061b3qWjItgJXBn8GFxkA5)
		if CCwFhi3yksq17gDUP9jZ>vvhR5ozeiJpANyl8fFO3GBw(u"࠹࠵࠶ः"): D8CmWJfpZUnLTF.append(aCle1prw9vOVEDsH)
		K2HSI6syC3Fo4d01MtcmRPONp8qGAa += CCwFhi3yksq17gDUP9jZ
	pdWPFcLmQ80kgqYO3Gji = K2HSI6syC3Fo4d01MtcmRPONp8qGAa>llkFwuCyhaP3sK76qO4T(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = JegF7SlMawI03+jQv0du1iVxTgAXCM(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(K2HSI6syC3Fo4d01MtcmRPONp8qGAa)+fmkZtbRj3ux(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+AAByQSLgaZwCsKnvc5eWNmY
		if not D8CmWJfpZUnLTF and not pdWPFcLmQ80kgqYO3Gji: ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,rDG9dZoXRhCJcieUSF0KB(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: ug0EmiKYnRT1qeH9MFyr3pO = UD4N8MjVTd
	if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
		if pdWPFcLmQ80kgqYO3Gji: THqDmj0Frnf38wX7MkVZ1u9NaGi(sVvmAZyqw0F5UT4t6BKJaprEQ,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		elif D8CmWJfpZUnLTF:
			for aCle1prw9vOVEDsH in D8CmWJfpZUnLTF: THqDmj0Frnf38wX7MkVZ1u9NaGi(aCle1prw9vOVEDsH,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def KNn5uve7PMBI():
	DvyB3Hri17aCIO84YtkQ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==-it4DKnryZlx(u"࠷अ"): return
	if ug0EmiKYnRT1qeH9MFyr3pO:
		import subprocess as h2m70uBJUrjN9RxFqIYkdPc341Dao
		try:
			h2m70uBJUrjN9RxFqIYkdPc341Dao.Popen(fmkZtbRj3ux(u"ࠪࡷࡺ࠭ࢧ"))
			DvyB3Hri17aCIO84YtkQ = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		except: pass
		if DvyB3Hri17aCIO84YtkQ:
			RSXy3qCfOAhJwHdLPKgs = VIm9uLgZ3qjrb2G+UKFZBQAVXHI5s17LyvuRpCY2+kZVIBmNJEuahs48oXCtGFWP+UKFZBQAVXHI5s17LyvuRpCY2+DDJjkxT4QY+UKFZBQAVXHI5s17LyvuRpCY2+iMARn95Tg0+UKFZBQAVXHI5s17LyvuRpCY2+xr2OL5EhU3g6+UKFZBQAVXHI5s17LyvuRpCY2+QV2lC71hDuxpjwY4T
			SXTcoeY89nEDmy6iu = h2m70uBJUrjN9RxFqIYkdPc341Dao.Popen(DpRJnas65uVcO0S17dYG(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+RSXy3qCfOAhJwHdLPKgs+lCT8hfYUBX4OQMmL(u"ࠬࠨࠧࢩ"),shell=y0yvdNOZkiKEg5RLMhoDVQAB9F2,stdin=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE,stdout=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE,stderr=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE)
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JHMxIE4fs1mvQtKW7R(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return DvyB3Hri17aCIO84YtkQ
def b6esHxdrB7WI4lkuZG(zWYxbrfRlyUCiAcL68ZG):
	for E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ in [jQv0du1iVxTgAXCM(u"ࠨࡄࠪࢬ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡎࡆࠬࢭ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡑࡇ࠭ࢮ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡌࡈࠧࢯ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡚ࠬࡂࠨࢰ")]:
		if zWYxbrfRlyUCiAcL68ZG<jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠱࠱࠴࠷आ"): break
		else: zWYxbrfRlyUCiAcL68ZG /= MFhbWia58mP3su0fk2d(u"࠲࠲࠵࠸࠳࠶इ")
	eIRJAgj25bzvNik48puZl3OPUq = rDG9dZoXRhCJcieUSF0KB(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(zWYxbrfRlyUCiAcL68ZG,E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ)
	return eIRJAgj25bzvNik48puZl3OPUq
def FFhBAMutCwR(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ=xm6jK1ZMuWq5(u"ࠧ࠯ࠩࢲ")):
	global xT6g8EaSwq,YamkdOBK3vIT1EnM76NDSA4Jowpqg
	xT6g8EaSwq,YamkdOBK3vIT1EnM76NDSA4Jowpqg = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
	def P3QDHJ1r8kalKNvV(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ):
		global xT6g8EaSwq,YamkdOBK3vIT1EnM76NDSA4Jowpqg
		if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ):
			if wTLFCOcM26fmYlW7U and w8JC1y7Lp3(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(b7i1PgC8Z4e5BFoHNd9E2UVvfc):
				for i4wA9sdU3vW7tQhCkTD1L6RZJo in b7i1PgC8Z4e5BFoHNd9E2UVvfc.scandir(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ):
					if i4wA9sdU3vW7tQhCkTD1L6RZJo.is_dir(follow_symlinks=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
						P3QDHJ1r8kalKNvV(i4wA9sdU3vW7tQhCkTD1L6RZJo.path)
					elif i4wA9sdU3vW7tQhCkTD1L6RZJo.is_file(follow_symlinks=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
						xT6g8EaSwq += i4wA9sdU3vW7tQhCkTD1L6RZJo.stat().st_size
						YamkdOBK3vIT1EnM76NDSA4Jowpqg += UD4N8MjVTd
			else:
				for i4wA9sdU3vW7tQhCkTD1L6RZJo in b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ):
					YS4MVthWxR = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.abspath(b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ,i4wA9sdU3vW7tQhCkTD1L6RZJo))
					if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.isdir(YS4MVthWxR):
						P3QDHJ1r8kalKNvV(YS4MVthWxR)
					elif b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.isfile(YS4MVthWxR):
						zWYxbrfRlyUCiAcL68ZG,mnDKBYwZl8SM0zk6 = xDXC5AF31hBZ2gRGJafuK6zENQMO(YS4MVthWxR)
						xT6g8EaSwq += zWYxbrfRlyUCiAcL68ZG
						YamkdOBK3vIT1EnM76NDSA4Jowpqg += mnDKBYwZl8SM0zk6
		return
	try: P3QDHJ1r8kalKNvV(l0RtsDp2fPaJOroncmWSjq1Fxd6VZ)
	except: pass
	return xT6g8EaSwq,YamkdOBK3vIT1EnM76NDSA4Jowpqg
def qQ2BKeYxTa6XFdfbH(showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JegF7SlMawI03+jQv0du1iVxTgAXCM(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+QWLr8ABjev+ZiCLpR1Tc5vUlPXDWgmhM6j(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+QWLr8ABjev+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫฤࠧࠡࠨࢶ")+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return
	U8HzP60hbJpt5awNdZ3fxeVI9ovi = THqDmj0Frnf38wX7MkVZ1u9NaGi(HHfpVrRkEwacs6vS71qjx23mCQIdBn,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	S7KL8ukNwh = THqDmj0Frnf38wX7MkVZ1u9NaGi(CKJo1lzpE7Nih8XMAV4SkbLtswW2UO,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	mJbSQAd40HiE8T2oZpKCWg = THqDmj0Frnf38wX7MkVZ1u9NaGi(YNzq76X410d8n5GxyLuaMrE,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	ZZeEkD3RV8TfANm0G9WCbO = zEdV2Itnhmya8cxvDG(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	EEvwx21nkIozJA97RtbNqCsc0 = tj95SCFkQ8W3ye0h(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	succeeded = all([U8HzP60hbJpt5awNdZ3fxeVI9ovi,S7KL8ukNwh,mJbSQAd40HiE8T2oZpKCWg,ZZeEkD3RV8TfANm0G9WCbO,EEvwx21nkIozJA97RtbNqCsc0])
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JHMxIE4fs1mvQtKW7R(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def WWJMU4sjpb2rY(showDialogs):
	if showDialogs:
		RSXy3qCfOAhJwHdLPKgs = VIm9uLgZ3qjrb2G+QWLr8ABjev+kZVIBmNJEuahs48oXCtGFWP+QWLr8ABjev+DDJjkxT4QY+QWLr8ABjev+iMARn95Tg0+QWLr8ABjev+xr2OL5EhU3g6+QWLr8ABjev+QV2lC71hDuxpjwY4T
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JegF7SlMawI03+Gj3rMP1Cb8wHdp49la0(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+RSXy3qCfOAhJwHdLPKgs+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return
	U8HzP60hbJpt5awNdZ3fxeVI9ovi = THqDmj0Frnf38wX7MkVZ1u9NaGi(VIm9uLgZ3qjrb2G,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	S7KL8ukNwh = THqDmj0Frnf38wX7MkVZ1u9NaGi(kZVIBmNJEuahs48oXCtGFWP,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	mJbSQAd40HiE8T2oZpKCWg = THqDmj0Frnf38wX7MkVZ1u9NaGi(DDJjkxT4QY,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	ZZeEkD3RV8TfANm0G9WCbO = THqDmj0Frnf38wX7MkVZ1u9NaGi(iMARn95Tg0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	EEvwx21nkIozJA97RtbNqCsc0 = THqDmj0Frnf38wX7MkVZ1u9NaGi(xr2OL5EhU3g6,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	ITC7HgxBrfuh50 = THqDmj0Frnf38wX7MkVZ1u9NaGi(QV2lC71hDuxpjwY4T,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	succeeded = all([U8HzP60hbJpt5awNdZ3fxeVI9ovi,S7KL8ukNwh,mJbSQAd40HiE8T2oZpKCWg,ZZeEkD3RV8TfANm0G9WCbO,EEvwx21nkIozJA97RtbNqCsc0,ITC7HgxBrfuh50])
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,fmkZtbRj3ux(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def zEdV2Itnhmya8cxvDG(showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JegF7SlMawI03+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳ई"): return xdSThjYnuHXAU6M(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = xm6jK1ZMuWq5(u"ࡘࡷࡻࡥऊ")
		rC0YJ4awbU2H3LOGt5DIF = plTxfrOsuV4McaF2HPg1BiZ396GXI5.connect(AZ7XwOdthHi)
		rC0YJ4awbU2H3LOGt5DIF.text_factory = str
		sXeobuj186Q = rC0YJ4awbU2H3LOGt5DIF.cursor()
		sXeobuj186Q.execute(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		sXeobuj186Q.execute(rDG9dZoXRhCJcieUSF0KB(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		sXeobuj186Q.execute(llkFwuCyhaP3sK76qO4T(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		rC0YJ4awbU2H3LOGt5DIF.commit()
		sXeobuj186Q.execute(llkFwuCyhaP3sK76qO4T(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		rC0YJ4awbU2H3LOGt5DIF.close()
	except: succeeded = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,kPCxIUZb1V(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def tj95SCFkQ8W3ye0h(showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+QWLr8ABjev+QWLr8ABjev+JegF7SlMawI03+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return xdSThjYnuHXAU6M(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࡔࡳࡷࡨऍ")
	for file in b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(JMVGrgf2Qj69HKpu):
		if it4DKnryZlx(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and it4DKnryZlx(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		akhbe8SYLMdfHmg3Dsl5A2KjEp = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(JMVGrgf2Qj69HKpu,file)
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(akhbe8SYLMdfHmg3Dsl5A2KjEp)
		except Exception as CPhVH47v1X83tgA62wMWirdG:
			succeeded = erqDsJmL3BQHuGtPkcf0X9(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,str(CPhVH47v1X83tgA62wMWirdG))
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,Gj3rMP1Cb8wHdp49la0(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded