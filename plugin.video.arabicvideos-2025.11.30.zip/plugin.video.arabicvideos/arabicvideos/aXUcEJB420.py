# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SHOOFMAX'
UT69hgqoKsWNIwM5zkAYb = '_SHM_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
wkbMLZA1UPQtRnDcmri7qyHz = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][1]
AaDNk2mVEBhCvQH = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][2]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==50: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==51: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	elif mode==52: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==53: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==55: RCmHBOKtejQ8lu4L = IWnUgjSXaJBHY4s1RzQyD()
	elif mode==56: RCmHBOKtejQ8lu4L = AXRF5L9orYK2qWb7DZOxklCcv()
	elif mode==57: RCmHBOKtejQ8lu4L = RnzODrJ87P(url,1)
	elif mode==58: RCmHBOKtejQ8lu4L = RnzODrJ87P(url,2)
	elif mode==59: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,59,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المسلسلات',wUvcPrYDfISbZolAm83GKEqMyXkn5,56)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الافلام',wUvcPrYDfISbZolAm83GKEqMyXkn5,55)
	return wUvcPrYDfISbZolAm83GKEqMyXkn5
def IWnUgjSXaJBHY4s1RzQyD():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أفلام مرتبة بسنة الإنتاج',hhD7r1VvaPt3TC06SJjqKRfEid+'/movie/1/yop',57)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أفلام مرتبة بالأفضل تقييم',hhD7r1VvaPt3TC06SJjqKRfEid+'/movie/1/review',57)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أفلام مرتبة بالأكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid+'/movie/1/views',57)
	return
def AXRF5L9orYK2qWb7DZOxklCcv():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات مرتبة بسنة الإنتاج',hhD7r1VvaPt3TC06SJjqKRfEid+'/series/1/yop',57)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات مرتبة بالأفضل تقييم',hhD7r1VvaPt3TC06SJjqKRfEid+'/series/1/review',57)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات مرتبة بالأكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid+'/series/1/views',57)
	return
def HPdaS7kenW0m(url):
	if '?' in url:
		deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('?')
		url = deg2JDUOioWfbC8NcswK1RFAlk4M[0]
		filter = '?' + vvLTYxVfrbDza(deg2JDUOioWfbC8NcswK1RFAlk4M[1],'=&:/%')
	else: filter = wUvcPrYDfISbZolAm83GKEqMyXkn5
	type,sbNukjOf4chz,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': D2eQ8jwIuaGZUoW41HbtKi63L9x='فيلم'
		elif type=='series': D2eQ8jwIuaGZUoW41HbtKi63L9x='مسلسل'
		url = hhD7r1VvaPt3TC06SJjqKRfEid + '/genre/filter/' + vvLTYxVfrbDza(D2eQ8jwIuaGZUoW41HbtKi63L9x) + '/' + sbNukjOf4chz + '/' + sort + filter
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-TITLES-1st')
		items = jj0dZrgiKb.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		knOoiVS6h5IvmwfPspFX3Eb8a7LKGD=0
		for id,title,kHOsg5xJL1bC9Efw3iBaWFGeNUuY,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = AaDNk2mVEBhCvQH + '/v2/img/program/main/' + cPzpeLXs3jMCltW4ZN9BaYdfQvwS + '-2.jpg'
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid + '/program/' + id
			if type=='movie': mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,53,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			if type=='series': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسل '+title,hhEH1rcSP0z6Bkqy8OD+'?ep='+kHOsg5xJL1bC9Efw3iBaWFGeNUuY+'='+title+'='+cPzpeLXs3jMCltW4ZN9BaYdfQvwS,52,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		if type=='movie': D2eQ8jwIuaGZUoW41HbtKi63L9x='movies'
		elif type=='series': D2eQ8jwIuaGZUoW41HbtKi63L9x='series'
		url = wkbMLZA1UPQtRnDcmri7qyHz + '/json/selected/' + sort + '-' + D2eQ8jwIuaGZUoW41HbtKi63L9x + '-WW.json'
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-TITLES-2nd')
		items = jj0dZrgiKb.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		knOoiVS6h5IvmwfPspFX3Eb8a7LKGD=0
		for id,kHOsg5xJL1bC9Efw3iBaWFGeNUuY,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = wkbMLZA1UPQtRnDcmri7qyHz + '/img/program/' + cPzpeLXs3jMCltW4ZN9BaYdfQvwS + '-2.jpg'
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid + '/program/' + id
			if type=='movie': mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,53,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			elif type=='series': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسل '+title,hhEH1rcSP0z6Bkqy8OD+'?ep='+kHOsg5xJL1bC9Efw3iBaWFGeNUuY+'='+title+'='+cPzpeLXs3jMCltW4ZN9BaYdfQvwS,52,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	title='صفحة '
	if knOoiVS6h5IvmwfPspFX3Eb8a7LKGD==16:
		for nPoKZDVqwOX7 in range(1,13) :
			if not sbNukjOf4chz==str(nPoKZDVqwOX7):
				url = hhD7r1VvaPt3TC06SJjqKRfEid+'/genre/filter/'+type+'/'+str(nPoKZDVqwOX7)+'/'+sort+filter
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title+str(nPoKZDVqwOX7),url,51)
	return
def mCwqRg7HpivAQ6S(url):
	deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('=')
	kHOsg5xJL1bC9Efw3iBaWFGeNUuY = int(deg2JDUOioWfbC8NcswK1RFAlk4M[1])
	name = Z6bUG0kDQuFqgzdAa1r(deg2JDUOioWfbC8NcswK1RFAlk4M[2])
	name = name.replace('_MOD_مسلسل ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = deg2JDUOioWfbC8NcswK1RFAlk4M[3]
	url = url.split('?')[0]
	if kHOsg5xJL1bC9Efw3iBaWFGeNUuY==0:
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-EPISODES-1st')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<select(.*?)</select>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('option value="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		kHOsg5xJL1bC9Efw3iBaWFGeNUuY = int(items[-1])
	for xNVKL75nEZstg4wfXBkySQ in range(kHOsg5xJL1bC9Efw3iBaWFGeNUuY,0,-1):
		hhEH1rcSP0z6Bkqy8OD = url + '?ep=' + str(xNVKL75nEZstg4wfXBkySQ)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(xNVKL75nEZstg4wfXBkySQ)
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,53,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-PLAY-1st')
	OoMp23hHJQf8NYxBiaerwCLst0Ac = jj0dZrgiKb.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if OoMp23hHJQf8NYxBiaerwCLst0Ac:
		L5jXH0fZ8TvsESR = OoMp23hHJQf8NYxBiaerwCLst0Ac[1].replace('T',fy2aLFcjDnoxIzGi1gp7)
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+QWLr8ABjev+L5jXH0fZ8TvsESR)
		return
	N6NLAiWkylKQuU2h,hLbSe5UrZEvi = [],[]
	BIJcVs9e37GPkyrgW = jj0dZrgiKb.findall('var origin_link = "(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	OZ5XWd0IwR32r6vc = jj0dZrgiKb.findall('var backup_origin_link = "(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('hls: (.*?)_link\+"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for xG6n4Wq2Ib7YgpiarHUNLQJM0,hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
		if 'backup' in xG6n4Wq2Ib7YgpiarHUNLQJM0:
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = 'backup server'
			url = OZ5XWd0IwR32r6vc + hhEH1rcSP0z6Bkqy8OD
		else:
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = 'main server'
			url = BIJcVs9e37GPkyrgW + hhEH1rcSP0z6Bkqy8OD
		if '.m3u8' in url:
			N6NLAiWkylKQuU2h.append(url)
			hLbSe5UrZEvi.append('m3u8  '+xG6n4Wq2Ib7YgpiarHUNLQJM0)
	ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	ppAJI9kDbz5MXa76UEF += jj0dZrgiKb.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for xG6n4Wq2Ib7YgpiarHUNLQJM0,hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
		filename = hhEH1rcSP0z6Bkqy8OD.split('/')[-1]
		filename = filename.replace('fallback',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		filename = filename.replace('.mp4',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		filename = filename.replace('-',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		if 'backup' in xG6n4Wq2Ib7YgpiarHUNLQJM0:
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = 'backup server'
			url = OZ5XWd0IwR32r6vc + hhEH1rcSP0z6Bkqy8OD
		else:
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = 'main server'
			url = BIJcVs9e37GPkyrgW + hhEH1rcSP0z6Bkqy8OD
		N6NLAiWkylKQuU2h.append(url)
		hLbSe5UrZEvi.append('mp4  '+xG6n4Wq2Ib7YgpiarHUNLQJM0+lB8tuyg6sxkDVYAaS95K3GI+filename)
	EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('Select Video Quality:', hLbSe5UrZEvi)
	if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1 : return
	url = N6NLAiWkylKQuU2h[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	yyYuosJmc3QDUGSA(url,UdbRGoKhcDeI4lVfns5,'video')
	return
def RnzODrJ87P(url,type):
	if 'series' in url: ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid + '/genre/مسلسل'
	else: ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid + '/genre/فيلم'
	ZD5n0eJivzWOMxY98dgrumkwRG = vvLTYxVfrbDza(ZD5n0eJivzWOMxY98dgrumkwRG)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-FILTERS-1st')
	if type==1: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('subgenre(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	elif type==2: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('country(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('option value="(.*?)">(.*?)</option',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if type==1:
		for Bv5SwzbRFu6oCjGlXq,title in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url+'?subgenre='+Bv5SwzbRFu6oCjGlXq,58)
	elif type==2:
		url,Bv5SwzbRFu6oCjGlXq = url.split('?')
		for XMiAvt4q9HhfwbPNsCnVk8o7RIW,title in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url+'?country='+XMiAvt4q9HhfwbPNsCnVk8o7RIW+'&'+Bv5SwzbRFu6oCjGlXq,51)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if not search: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search?q='+LBqdVs9ioWwpMbCm1A
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,True,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFMAX-SEARCH-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('general-body(.*?)search-bottom-padding',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if items:
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			url = hhD7r1VvaPt3TC06SJjqKRfEid + hhEH1rcSP0z6Bkqy8OD
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+vvLTYxVfrbDza(title)+'='+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,52,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				else:
					title = '_MOD_فيلم '+title
					mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,url,53,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return