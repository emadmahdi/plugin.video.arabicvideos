# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'FARESKO'
UT69hgqoKsWNIwM5zkAYb = '_FSK_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['الرئيسية','يلا شوت']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==990: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==991: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==992: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==993: RCmHBOKtejQ8lu4L = ymR58kPWbDiQ(url)
	elif mode==999: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,999,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"primary-links"(.*?)</u',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,991)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"list-categories"(.*?)</u',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD.lstrip('/')
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,991)
	return
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"home-content"(.*?)"footer"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('"overlay"','"duration"><')
		items = jj0dZrgiKb.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(' ')
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
			if 'episodes' not in type and xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
				title = title.replace('اون لاين',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,993,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,992,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''["']pagination["'](.*?)["']footer["']''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,991,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	else:
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('load-next-button" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة جديدة',hhEH1rcSP0z6Bkqy8OD[0],991,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def ymR58kPWbDiQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-SERIES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="eplist"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		rNmzwKLcvbTquoFB6 = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in rNmzwKLcvbTquoFB6:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,992)
	else:
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"category".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
			HPdaS7kenW0m(hhEH1rcSP0z6Bkqy8OD,'episodes')
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,lCtvKHMzLJVo8fERq9N5 = [],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if 'hash=' in II64TLxj3mbqEyh9pHQ8oAv:
		yTpIdftPmx9qV0J3niwHKOM = jj0dZrgiKb.findall('hash=(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		yTpIdftPmx9qV0J3niwHKOM = list(set(yTpIdftPmx9qV0J3niwHKOM))
		for dHRIVxWSDFQOajpZ7mflrsToY in yTpIdftPmx9qV0J3niwHKOM:
			Tq1Op48kwS3 = []
			deg2JDUOioWfbC8NcswK1RFAlk4M = dHRIVxWSDFQOajpZ7mflrsToY.split('__')
			for jF8LiqsKNQYJen in deg2JDUOioWfbC8NcswK1RFAlk4M:
				try:
					jF8LiqsKNQYJen = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(jF8LiqsKNQYJen+'=')
					if wwMdFkWvcRYiXHB7yDrCqnKb98o: jF8LiqsKNQYJen = jF8LiqsKNQYJen.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
					Tq1Op48kwS3.append(jF8LiqsKNQYJen)
				except: pass
			ppAJI9kDbz5MXa76UEF = '>'.join(Tq1Op48kwS3)
			ppAJI9kDbz5MXa76UEF = ppAJI9kDbz5MXa76UEF.splitlines()
			for hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
				if ' => ' in hhEH1rcSP0z6Bkqy8OD:
					title,hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split(' => ')
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch')
	elif 'post_id' in II64TLxj3mbqEyh9pHQ8oAv:
		E2Y7y4Av63tqhSVQ50iTmN = jj0dZrgiKb.findall("post_id = '(.*?)'",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if E2Y7y4Av63tqhSVQ50iTmN:
			E2Y7y4Av63tqhSVQ50iTmN = E2Y7y4Av63tqhSVQ50iTmN[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			mNf0VWq3Fw = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-admin/admin-ajax.php?action=video_info&post_id='+E2Y7y4Av63tqhSVQ50iTmN
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',mNf0VWq3Fw,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-PLAY-2nd')
			gn3TFZQNYR4 = QM9sJ7tk0oplqEwHU3DjL64d.content
			zwx0WYOsASNDPf5R = jj0dZrgiKb.findall('"name":"(.*?)","src":"(.*?)"',gn3TFZQNYR4,jj0dZrgiKb.DOTALL)
			if not zwx0WYOsASNDPf5R:
				zwx0WYOsASNDPf5R = jj0dZrgiKb.findall('"src":"(.*?)"',gn3TFZQNYR4,jj0dZrgiKb.DOTALL)
				if zwx0WYOsASNDPf5R:
					FMokrdVaPn0p21AxbgEYKv5 = ['']*len(zwx0WYOsASNDPf5R)
					zwx0WYOsASNDPf5R = list(zip(FMokrdVaPn0p21AxbgEYKv5,zwx0WYOsASNDPf5R))
			for name,hhEH1rcSP0z6Bkqy8OD in zwx0WYOsASNDPf5R:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('\\/','/')
				hhEH1rcSP0z6Bkqy8OD = vvLTYxVfrbDza(hhEH1rcSP0z6Bkqy8OD)
				if hhEH1rcSP0z6Bkqy8OD in lCtvKHMzLJVo8fERq9N5: continue
				else: lCtvKHMzLJVo8fERq9N5.append(hhEH1rcSP0z6Bkqy8OD)
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__watch')
			q4zyW5Bpx6Y2O = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+E2Y7y4Av63tqhSVQ50iTmN+'&video_id=null&video_url=null&video_source=custom'
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',q4zyW5Bpx6Y2O,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FARESKO-PLAY-3rd')
			xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
			Ip3wDG5RX2dWFcxMjm = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if Ip3wDG5RX2dWFcxMjm:
				LBcJV1zDQS0iG6hms,qqrLFa0ZvJl9jkXOw7fbpAdmu = zip(*Ip3wDG5RX2dWFcxMjm)
				Ip3wDG5RX2dWFcxMjm = list(zip(qqrLFa0ZvJl9jkXOw7fbpAdmu,LBcJV1zDQS0iG6hms))
			for name,hhEH1rcSP0z6Bkqy8OD in Ip3wDG5RX2dWFcxMjm:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('\\/','/')
				hhEH1rcSP0z6Bkqy8OD = vvLTYxVfrbDza(hhEH1rcSP0z6Bkqy8OD)
				if hhEH1rcSP0z6Bkqy8OD in lCtvKHMzLJVo8fERq9N5: continue
				else: lCtvKHMzLJVo8fERq9N5.append(hhEH1rcSP0z6Bkqy8OD)
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__download')
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(url,'search')
	return