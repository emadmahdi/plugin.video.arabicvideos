# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'CIMACLUP'
UT69hgqoKsWNIwM5zkAYb = '_CMC_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['موقع نتفليكس']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==490: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==491: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==492: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==493: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==494: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==499: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text,url)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	FFwVakdM8NvjeJRK3oyQI9ti24 = jj0dZrgiKb.findall('href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	FFwVakdM8NvjeJRK3oyQI9ti24 = FFwVakdM8NvjeJRK3oyQI9ti24[0].strip('/')
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(FFwVakdM8NvjeJRK3oyQI9ti24,'url')
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"filter AjaxifyFilter"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if m4z08qk6gJ5lK:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('data-filter="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/wp-content/themes/old/filter/'+hhEH1rcSP0z6Bkqy8OD+'.php'
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,491)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أفلام',FFwVakdM8NvjeJRK3oyQI9ti24+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مسلسلات',FFwVakdM8NvjeJRK3oyQI9ti24+'/category/مسلسلات/مسلسلات-اجنبى',494,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="navigation-menu"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if hhEH1rcSP0z6Bkqy8OD=='/': continue
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+hhEH1rcSP0z6Bkqy8OD
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,491)
	return II64TLxj3mbqEyh9pHQ8oAv
def FFJX0sguE92DxYGmoQAeV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"filter"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if i7swfV8rtlpOd3K6SUDk9yn0P:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,491)
	return
def HPdaS7kenW0m(url,DT402mRilruat3EeIoM6=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	items = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if '.php' in url: IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
	elif '?s=' in url:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"blocks(.*?)"manifest"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"Blocks(.*?)"manifest"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if not IJE2xcV7OWauUKhfik56gXBwltCb: return
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) حلقة \d+',title,jj0dZrgiKb.DOTALL)
		if not xNVKL75nEZstg4wfXBkySQ: xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
		if not xNVKL75nEZstg4wfXBkySQ or any(value in title for value in SSthyczaHP7fAIoi5):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,492,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and 'حلقة' in title:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,493,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,493,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('<li><a href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,491)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('"ButtonsBarCo".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG:
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-EPISODES-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('"img-responsive" src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if cPzpeLXs3jMCltW4ZN9BaYdfQvwS: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0]
	else: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel('ListItem.Thumb')
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"filter"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"Blocks(.*?)class="pagination"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if i7swfV8rtlpOd3K6SUDk9yn0P and '/series/' not in url:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,493,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	elif m4z08qk6gJ5lK:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,492,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,491)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	ZD5n0eJivzWOMxY98dgrumkwRG = url.strip('/')+'/?view=1'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMACLUP-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	UOQ7lSWTauRPv = jj0dZrgiKb.findall("data: 'q=(.*?)&",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	UOQ7lSWTauRPv = UOQ7lSWTauRPv[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"serversList"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('data-server="(.*?)">(.*?)</li>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for FXJlEeYKmni,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/wp-content/themes/old/servers/server.php?q='+UOQ7lSWTauRPv+'&i='+FXJlEeYKmni+'?named='+title+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"embedServer".*?SRC="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		title = 'مفضل'
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]+'?named=__embed__'+title
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"downloadsList"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('<td>(.*?)</td>.*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if 'anavidz' in hhEH1rcSP0z6Bkqy8OD: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = '__خاص'
			else: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = wUvcPrYDfISbZolAm83GKEqMyXkn5
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search,FFwVakdM8NvjeJRK3oyQI9ti24=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not FFwVakdM8NvjeJRK3oyQI9ti24: FFwVakdM8NvjeJRK3oyQI9ti24 = hhD7r1VvaPt3TC06SJjqKRfEid
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = FFwVakdM8NvjeJRK3oyQI9ti24+'/index.php?s='+search
	HPdaS7kenW0m(url)
	return