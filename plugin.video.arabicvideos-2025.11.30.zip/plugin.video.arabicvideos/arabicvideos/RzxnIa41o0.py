# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'GOOGLESEARCH'
UT69hgqoKsWNIwM5zkAYb = '_GOS_'
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==1010: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1011: RCmHBOKtejQ8lu4L = diEfI5lxTtWYomq0VOwgyKJe(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1012: RCmHBOKtejQ8lu4L = Ck81Ov7lhnYH5rcJwzVebIX2PsKm(iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1013: RCmHBOKtejQ8lu4L = rv3oCcNAnMhmVx8eSQ0dYDB5()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1014: RCmHBOKtejQ8lu4L = t9vza7lI8Ohid(iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1015: RCmHBOKtejQ8lu4L = UQ2z56Vh9pWmELAYx81yra7Z(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1016: RCmHBOKtejQ8lu4L = UFqi6hVsaDEZeYlHA(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1018: RCmHBOKtejQ8lu4L = KKXbQ9VuoL82mwhDjftg(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==1019: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(eIRJAgj25bzvNik48puZl3OPUq,False)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder','بحث جوجل جديد',wUvcPrYDfISbZolAm83GKEqMyXkn5,1019)
	mwOxEyYAg63B('link','كيف يعمل بحث جوجل','',1013)
	mwOxEyYAg63B('link',JegF7SlMawI03+'==== كلمات البحث المخزنة ===='+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4 = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4:
		ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4 = ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4['__SEQUENCED_COLUMNS__']
		for vli6AtMjqfwmKnP0z1E in reversed(ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4):
			mwOxEyYAg63B('folder',vli6AtMjqfwmKnP0z1E,wUvcPrYDfISbZolAm83GKEqMyXkn5,1019,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vli6AtMjqfwmKnP0z1E)
	return
def KKXbQ9VuoL82mwhDjftg(search):
	LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search,True)
	ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search,H1HanUOhKRC=False):
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	WXLft9mQVHqp = search.replace(UT69hgqoKsWNIwM5zkAYb,wUvcPrYDfISbZolAm83GKEqMyXkn5).lower()
	nkyNQipLS5D1RKOdjMtXvxAhJumeCg,R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = [],[],[]
	if not H1HanUOhKRC:
		nkyNQipLS5D1RKOdjMtXvxAhJumeCg = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GOOGLESEARCH_RESULTS',WXLft9mQVHqp)
		if nkyNQipLS5D1RKOdjMtXvxAhJumeCg: R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = nkyNQipLS5D1RKOdjMtXvxAhJumeCg
	if H1HanUOhKRC or not nkyNQipLS5D1RKOdjMtXvxAhJumeCg:
		import ffKsyZnaOw
		ffKsyZnaOw.M1PYzHIgEf6qQL3(WXLft9mQVHqp,'_GOOGLE',True)
		sWYKlciqTHE0bB6m1D4xvn9u = b3Jr1x6PoHU(WXLft9mQVHqp)
		for o4oW9wDcsrpHQS816yfIvg in sWYKlciqTHE0bB6m1D4xvn9u:
			name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt = o4oW9wDcsrpHQS816yfIvg
			if g40I3ZXaeJ8qVywt in W1bszKqEjom: R0CztF9PB4KEWYSJ8qApZU.append(o4oW9wDcsrpHQS816yfIvg)
			else: iHVTxe9YObZSmn5P7Q1lGt.append(o4oW9wDcsrpHQS816yfIvg)
		R0CztF9PB4KEWYSJ8qApZU = sorted(R0CztF9PB4KEWYSJ8qApZU,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[wTLFCOcM26fmYlW7U])
		iHVTxe9YObZSmn5P7Q1lGt = sorted(iHVTxe9YObZSmn5P7Q1lGt,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[wTLFCOcM26fmYlW7U])
		SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,'GOOGLESEARCH_RESULTS',WXLft9mQVHqp,[R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt],CCuNYswqArnRpift4)
		P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DETAILED_GOOGLE',WXLft9mQVHqp)
		ffKsyZnaOw.M1PYzHIgEf6qQL3(WXLft9mQVHqp,'_GOOGLE',False)
		P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+WXLft9mQVHqp+"')")
		if R0CztF9PB4KEWYSJ8qApZU: IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(R0CztF9PB4KEWYSJ8qApZU))+'  مواقع')
		else: R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = v5pGrCqm7UE0J(WXLft9mQVHqp,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	mwOxEyYAg63B('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('folder','بحث منفرد لمواقع جوجل',wUvcPrYDfISbZolAm83GKEqMyXkn5,1011,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('link',JegF7SlMawI03+'===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder','نتائج البحث مفصلة - '+WXLft9mQVHqp,'opened_sites_google',1012,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('folder','نتائج البحث مقسمة - '+WXLft9mQVHqp,'listed_sites_google',1012,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('link',JegF7SlMawI03+'===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder','مواقع جوجل ('+str(len(R0CztF9PB4KEWYSJ8qApZU))+') - '+WXLft9mQVHqp,'',1016,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('link','إعادة بحث جوجل - '+WXLft9mQVHqp,'',1018,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,search)
	return
def UFqi6hVsaDEZeYlHA(WXLft9mQVHqp):
	R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = v5pGrCqm7UE0J(WXLft9mQVHqp)
	if not R0CztF9PB4KEWYSJ8qApZU and not iHVTxe9YObZSmn5P7Q1lGt: return
	cSDfhKTnZ1baAsl7tGRCO5FH0 = {}
	for name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt in R0CztF9PB4KEWYSJ8qApZU: cSDfhKTnZ1baAsl7tGRCO5FH0[g40I3ZXaeJ8qVywt] = name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt
	GMPtN6d5F74XaDfUg = list(cSDfhKTnZ1baAsl7tGRCO5FH0.keys())
	import ffKsyZnaOw
	kMim89NBdyrx = ffKsyZnaOw.EJKdexG6Syr902gUkPlsoRNhM1H(GMPtN6d5F74XaDfUg)
	for g40I3ZXaeJ8qVywt in kMim89NBdyrx:
		if isinstance(g40I3ZXaeJ8qVywt,tuple):
			TTuO14NzmB.menuItemsLIST.append(g40I3ZXaeJ8qVywt)
			continue
		name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt = cSDfhKTnZ1baAsl7tGRCO5FH0[g40I3ZXaeJ8qVywt]
		iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
		mwOxEyYAg63B('folder',RULru39aExTFy0tzIOGk1ivSM8Xw+name,hhEH1rcSP0z6Bkqy8OD,1014,QQxJPoNTGFWE8MfRkKguyhADCLc9,'',g40I3ZXaeJ8qVywt)
	mwOxEyYAg63B('link',JegF7SlMawI03+'===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('link',JegF7SlMawI03+'مواقع بجوجل غير موجودة بالبرنامج'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,1015)
	iHVTxe9YObZSmn5P7Q1lGt = sorted(iHVTxe9YObZSmn5P7Q1lGt,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[wTLFCOcM26fmYlW7U])
	for name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt in iHVTxe9YObZSmn5P7Q1lGt:
		mwOxEyYAg63B('link','_GOS_'+name,hhEH1rcSP0z6Bkqy8OD,1015,QQxJPoNTGFWE8MfRkKguyhADCLc9,'',g40I3ZXaeJ8qVywt)
	return
def v5pGrCqm7UE0J(WXLft9mQVHqp,fsbBk6uneVmac5jwS=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = [],[]
	if fsbBk6uneVmac5jwS:
		nkyNQipLS5D1RKOdjMtXvxAhJumeCg = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GOOGLESEARCH_RESULTS',WXLft9mQVHqp)
		if nkyNQipLS5D1RKOdjMtXvxAhJumeCg: R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = nkyNQipLS5D1RKOdjMtXvxAhJumeCg
	if not R0CztF9PB4KEWYSJ8qApZU and not iHVTxe9YObZSmn5P7Q1lGt: IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',mvVFtPw8JKpaUdXq06YrEeR7bAk2,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt
def Ck81Ov7lhnYH5rcJwzVebIX2PsKm(BC38zNdiIMQe,WXLft9mQVHqp):
	R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = v5pGrCqm7UE0J(WXLft9mQVHqp)
	if not R0CztF9PB4KEWYSJ8qApZU and not iHVTxe9YObZSmn5P7Q1lGt: return
	CBi36AM8NVKEz,NCOyxVMlqgY6zQwXI39Bt0do = [],{}
	for name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt in R0CztF9PB4KEWYSJ8qApZU:
		CBi36AM8NVKEz.append(g40I3ZXaeJ8qVywt)
		NCOyxVMlqgY6zQwXI39Bt0do[g40I3ZXaeJ8qVywt] = C2C7GzoeYX1PhnpORNdkrvAM(text)
	import ffKsyZnaOw
	ffKsyZnaOw.NSUCecEOlj(WXLft9mQVHqp,BC38zNdiIMQe,wUvcPrYDfISbZolAm83GKEqMyXkn5,CBi36AM8NVKEz,NCOyxVMlqgY6zQwXI39Bt0do)
	return
def diEfI5lxTtWYomq0VOwgyKJe(WXLft9mQVHqp):
	R0CztF9PB4KEWYSJ8qApZU,iHVTxe9YObZSmn5P7Q1lGt = v5pGrCqm7UE0J(WXLft9mQVHqp)
	if not R0CztF9PB4KEWYSJ8qApZU and not iHVTxe9YObZSmn5P7Q1lGt: return
	cSDfhKTnZ1baAsl7tGRCO5FH0 = {}
	for name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt in R0CztF9PB4KEWYSJ8qApZU:
		cSDfhKTnZ1baAsl7tGRCO5FH0[g40I3ZXaeJ8qVywt] = name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt
	GMPtN6d5F74XaDfUg = list(cSDfhKTnZ1baAsl7tGRCO5FH0.keys())
	import ffKsyZnaOw
	kMim89NBdyrx = ffKsyZnaOw.EJKdexG6Syr902gUkPlsoRNhM1H(GMPtN6d5F74XaDfUg)
	for g40I3ZXaeJ8qVywt in kMim89NBdyrx:
		if isinstance(g40I3ZXaeJ8qVywt,tuple):
			TTuO14NzmB.menuItemsLIST.append(g40I3ZXaeJ8qVywt)
			continue
		name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt = cSDfhKTnZ1baAsl7tGRCO5FH0[g40I3ZXaeJ8qVywt]
		iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
		text = C2C7GzoeYX1PhnpORNdkrvAM(text)
		name = name+' - '+WXLft9mQVHqp
		mwOxEyYAg63B('folder',RULru39aExTFy0tzIOGk1ivSM8Xw+name,g40I3ZXaeJ8qVywt,548,QQxJPoNTGFWE8MfRkKguyhADCLc9,'',text)
	return
def C2C7GzoeYX1PhnpORNdkrvAM(title):
	xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة)',title,jj0dZrgiKb.DOTALL)
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = xNVKL75nEZstg4wfXBkySQ[0][0] if xNVKL75nEZstg4wfXBkySQ else title
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
def b3Jr1x6PoHU(search):
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	ZD5n0eJivzWOMxY98dgrumkwRG = url+'&start=0&num=100&tbm=vid&udm=7'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'GOOGLESEARCH-SEARCH-1st')
	if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded: return []
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	JJ5DL2oN7ITsUgiFaOrb6 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(CCrtv6o3mySp,'googlesearch')
	if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(JJ5DL2oN7ITsUgiFaOrb6):
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.makedirs(JJ5DL2oN7ITsUgiFaOrb6)
		except: pass
	items = []
	qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if qqtR56dgVLh3Tr2:
		for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
			hhEH1rcSP0z6Bkqy8OD,title,text,mnWZN7g50M,name = IJE2xcV7OWauUKhfik56gXBwltCb
			mnWZN7g50M = ''
			items.append([hhEH1rcSP0z6Bkqy8OD,title,text,name,mnWZN7g50M])
	else:
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'&start=0&num=200'
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'GET::SCRAPERS',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'GOOGLESEARCH-SEARCH-2nd')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded: return []
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not qqtR56dgVLh3Tr2: qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
			IJE2xcV7OWauUKhfik56gXBwltCb = dm7KA8MukvxF3iH9CW2ZNc('list',IJE2xcV7OWauUKhfik56gXBwltCb)
			if len(IJE2xcV7OWauUKhfik56gXBwltCb)>17:
				hhEH1rcSP0z6Bkqy8OD = IJE2xcV7OWauUKhfik56gXBwltCb[17]
				title,text,name,mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb[31][0:4]
				items.append([hhEH1rcSP0z6Bkqy8OD,title,text,name,mnWZN7g50M])
	RQz2qD0tAsgJeKwkmnxE6FI,r5G60Wf8zBgmAJpokMed = [],[]
	for o4oW9wDcsrpHQS816yfIvg in items:
		hhEH1rcSP0z6Bkqy8OD,title,text,name,mnWZN7g50M = o4oW9wDcsrpHQS816yfIvg
		name = name.strip(' ')
		if not name: name = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
		name = wYjpROZ8HU92X(name)
		if 'http://' in mnWZN7g50M or 'https://' in mnWZN7g50M: QQxJPoNTGFWE8MfRkKguyhADCLc9 = mnWZN7g50M
		elif 'data:image/' in mnWZN7g50M and ';base64,' in mnWZN7g50M:
			sEpaKeDVLB0xbPmRfk9UjG57H8tM = jj0dZrgiKb.findall('data:image/(\w+);base64,',mnWZN7g50M)
			sEpaKeDVLB0xbPmRfk9UjG57H8tM = sEpaKeDVLB0xbPmRfk9UjG57H8tM[0]
			QQxJPoNTGFWE8MfRkKguyhADCLc9 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(JJ5DL2oN7ITsUgiFaOrb6,name+'.'+sEpaKeDVLB0xbPmRfk9UjG57H8tM)
			if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(QQxJPoNTGFWE8MfRkKguyhADCLc9):
				mnWZN7g50M = mnWZN7g50M.replace('\\u003d','=')
				mnWZN7g50M = mnWZN7g50M.replace('data:image/'+sEpaKeDVLB0xbPmRfk9UjG57H8tM+';base64,','')
				YYUSiILmTcF = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(mnWZN7g50M)
				open(QQxJPoNTGFWE8MfRkKguyhADCLc9,'wb').write(YYUSiILmTcF)
		else: QQxJPoNTGFWE8MfRkKguyhADCLc9 = ''
		g40I3ZXaeJ8qVywt = X0tbrZwuGOnydUPkYCMVvmxB68(name,hhEH1rcSP0z6Bkqy8OD)
		if g40I3ZXaeJ8qVywt not in r5G60Wf8zBgmAJpokMed:
			r5G60Wf8zBgmAJpokMed.append(g40I3ZXaeJ8qVywt)
			name = c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt)
			RQz2qD0tAsgJeKwkmnxE6FI.append([name,hhEH1rcSP0z6Bkqy8OD,title,text,QQxJPoNTGFWE8MfRkKguyhADCLc9,g40I3ZXaeJ8qVywt])
	return RQz2qD0tAsgJeKwkmnxE6FI
def t9vza7lI8Ohid(hhEH1rcSP0z6Bkqy8OD,g40I3ZXaeJ8qVywt):
	iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
	if RULru39aExTFy0tzIOGk1ivSM8Xw: iKL7Z0wdopbjRXM()
	else: UQ2z56Vh9pWmELAYx81yra7Z()
	return
def rv3oCcNAnMhmVx8eSQ0dYDB5():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def UQ2z56Vh9pWmELAYx81yra7Z(g40I3ZXaeJ8qVywt=''):
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',g40I3ZXaeJ8qVywt,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def X0tbrZwuGOnydUPkYCMVvmxB68(name,hhEH1rcSP0z6Bkqy8OD):
	vvVorX7DZHg0G4nOjxkPI2aRSfW = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	QSuoms9tfxPZwgEea = name.lower()
	a1j30LvDQOi7GV8YhKsm = ''
	for key in list(vvVorX7DZHg0G4nOjxkPI2aRSfW.keys()):
		if key.lower() in QSuoms9tfxPZwgEea: a1j30LvDQOi7GV8YhKsm = vvVorX7DZHg0G4nOjxkPI2aRSfW[key]
	if not a1j30LvDQOi7GV8YhKsm:
		q4zyW5Bpx6Y2O = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'url')
		for g40I3ZXaeJ8qVywt in list(TTuO14NzmB.SITESURLS.keys()):
			o6lhI3gZLYS5m9VTNHwpxv1M = TO3vi2rSZ0LRhKlwgG4qkYFIC(TTuO14NzmB.SITESURLS[g40I3ZXaeJ8qVywt][0],'url')
			if q4zyW5Bpx6Y2O==o6lhI3gZLYS5m9VTNHwpxv1M: a1j30LvDQOi7GV8YhKsm = g40I3ZXaeJ8qVywt
	if not a1j30LvDQOi7GV8YhKsm:
		QSuoms9tfxPZwgEea = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
		for g40I3ZXaeJ8qVywt in list(TTuO14NzmB.SITESURLS.keys()):
			DjKRFulGIxvqtfJm07NeV = TO3vi2rSZ0LRhKlwgG4qkYFIC(TTuO14NzmB.SITESURLS[g40I3ZXaeJ8qVywt][0],'name')
			if QSuoms9tfxPZwgEea==DjKRFulGIxvqtfJm07NeV: a1j30LvDQOi7GV8YhKsm = g40I3ZXaeJ8qVywt
	if not a1j30LvDQOi7GV8YhKsm: a1j30LvDQOi7GV8YhKsm = name
	a1j30LvDQOi7GV8YhKsm = a1j30LvDQOi7GV8YhKsm.upper()
	return a1j30LvDQOi7GV8YhKsm