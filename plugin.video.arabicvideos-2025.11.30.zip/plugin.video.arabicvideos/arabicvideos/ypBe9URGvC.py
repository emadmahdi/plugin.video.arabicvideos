# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'HALACIMA'
UT69hgqoKsWNIwM5zkAYb = '_HLC_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==80: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==81: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==82: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==83: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==89: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'HALACIMA-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhD7r1VvaPt3TC06SJjqKRfEid,'url')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,89,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-content(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('data-name="(.*?)".*?</i>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for DT402mRilruat3EeIoM6,title in items:
		hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/ajax/getItem?item='+DT402mRilruat3EeIoM6+'&Ajax=1'
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,81)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"nav-main"(.*?)</nav>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if hhEH1rcSP0z6Bkqy8OD=='#': continue
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,81)
	return
def HPdaS7kenW0m(url,DT402mRilruat3EeIoM6=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = ibEuGXOqxHp(url)
		XubVRNO48BsjJASlmeKwdTCr = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'POST',ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'HALACIMA-TITLES-1st')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = [II64TLxj3mbqEyh9pHQ8oAv]
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'HALACIMA-TITLES-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		if DT402mRilruat3EeIoM6=='featured':
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"container"(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		elif '"section-post mb-10"' in II64TLxj3mbqEyh9pHQ8oAv:
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"section-post mb-10"(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		else:
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<article(.*?)"pagination"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if not items:
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if not items: items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD).strip('/')
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
		if '/series/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,83,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif 'سلاسل' not in url and any(value in title for value in SSthyczaHP7fAIoi5):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,82,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and 'الحلقة' in title:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,83,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/movies/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,81,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,83,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if DT402mRilruat3EeIoM6==wUvcPrYDfISbZolAm83GKEqMyXkn5:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)<footer',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD=="": continue
				if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'هناك المزيد',url,81)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'HALACIMA-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"getSeasonsBySeries(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"list-episodes"(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if i7swfV8rtlpOd3K6SUDk9yn0P and '/series/' not in url:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,83,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	elif m4z08qk6gJ5lK:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('"image" src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0]
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,82,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('/movies/','/watch_movies/')
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.replace('/episodes/','/watch_episodes/')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'HALACIMA-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,'url')
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"servers"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		E2Y7y4Av63tqhSVQ50iTmN = jj0dZrgiKb.findall('postID = "(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		E2Y7y4Av63tqhSVQ50iTmN = E2Y7y4Av63tqhSVQ50iTmN[0]
		items = jj0dZrgiKb.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for xG6n4Wq2Ib7YgpiarHUNLQJM0,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/ajax/getPlayer?server='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'&postID='+E2Y7y4Av63tqhSVQ50iTmN+'&Ajax=1'
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"downs"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,name in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__download'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'-')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'.html'
	HPdaS7kenW0m(url)
	return