# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'FASELHD2'
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
UT69hgqoKsWNIwM5zkAYb = '_FH2_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][wTLFCOcM26fmYlW7U]
i6TIRax9v0EDFJs2gVtfzp = ['FaselHD']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==590: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==591: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==592: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==593: RCmHBOKtejQ8lu4L = IOW06nd9b4vDaBoc5rQHiUFZ(url,text)
	elif mode==599: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	FFwVakdM8NvjeJRK3oyQI9ti24 = hhD7r1VvaPt3TC06SJjqKRfEid
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',FFwVakdM8NvjeJRK3oyQI9ti24,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD2-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',FFwVakdM8NvjeJRK3oyQI9ti24,599,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	items = jj0dZrgiKb.findall('<h3>(.*?)<.*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = wTLFCOcM26fmYlW7U
	for title,hhEH1rcSP0z6Bkqy8OD in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if any(value in title for value in i6TIRax9v0EDFJs2gVtfzp): continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,591,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured'+str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4))
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 += UD4N8MjVTd
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"main-menu"(.*?)</nav>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		gaGFLpWtJi5rw8EbNjx9KRZ3X = jj0dZrgiKb.findall('<li (.*?)</li>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for U6OhDV7N1y9c3r4woKE2dW in gaGFLpWtJi5rw8EbNjx9KRZ3X:
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',U6OhDV7N1y9c3r4woKE2dW,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+hhEH1rcSP0z6Bkqy8OD
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,591)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,mmZUvVcxAqEg0FN=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD2-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = []
	if 'featured' in mmZUvVcxAqEg0FN:
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = mmZUvVcxAqEg0FN[-UD4N8MjVTd]
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"boxes--holder"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[int(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)]
	elif mmZUvVcxAqEg0FN=='filters':
		pLHIPUY3TWAeE70 = [II64TLxj3mbqEyh9pHQ8oAv.replace('\\/','/').replace('\\"','"')]
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"boxes--holder"(.*?)"pagination"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
	if not items: items = jj0dZrgiKb.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		try: title = title.encode(QMZ3cLnaCrFR1Aq).decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		except: pass
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if any(value in title.lower() for value in i6TIRax9v0EDFJs2gVtfzp): continue
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
		if '/movseries/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,591,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ:
			title = '_MOD_'+xNVKL75nEZstg4wfXBkySQ[0][0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,593,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif any(value in title for value in SSthyczaHP7fAIoi5): mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,592,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,593,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if mmZUvVcxAqEg0FN=='filters':
		vvZkF1d6onpJ3uswMW7t2YjXr0AH = jj0dZrgiKb.findall('"more_button_page":(.*?),',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if vvZkF1d6onpJ3uswMW7t2YjXr0AH:
			count = vvZkF1d6onpJ3uswMW7t2YjXr0AH[0]
			hhEH1rcSP0z6Bkqy8OD = url+'/offset/'+count
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة أخرى',hhEH1rcSP0z6Bkqy8OD,591,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
	elif 'featured' not in mmZUvVcxAqEg0FN:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				hhEH1rcSP0z6Bkqy8OD = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(hhEH1rcSP0z6Bkqy8OD)
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,591,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'details4')
	return
def IOW06nd9b4vDaBoc5rQHiUFZ(url,data=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'POST',url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD2-SEASONS_EPISODES-1st')
		II64TLxj3mbqEyh9pHQ8oAv = '"EpisodesList"'+QM9sJ7tk0oplqEwHU3DjL64d.content+'</div>'
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD2-SEASONS_EPISODES-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mnWZN7g50M = jj0dZrgiKb.findall('"inner--image"><img src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = mnWZN7g50M[wTLFCOcM26fmYlW7U] if mnWZN7g50M else wUvcPrYDfISbZolAm83GKEqMyXkn5
	items = []
	if not data:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"SeasonsList"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
			items = jj0dZrgiKb.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if len(items)>1:
				for UOQ7lSWTauRPv,ajCL4NVXu0K5,title in items:
					hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					FjUcS938pAH5sZ = 'season='+ajCL4NVXu0K5+'&post_id='+UOQ7lSWTauRPv
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,593,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,FjUcS938pAH5sZ)
		data = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if data and len(items)<Tb7oymMnpflsSv3eu4Pz2:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"EpisodesList"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
			items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<em>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,aBd52O7QsZGbvhngJ1TcI,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ in items:
				title = aBd52O7QsZGbvhngJ1TcI+UKFZBQAVXHI5s17LyvuRpCY2+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,592,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	url = url.strip('/')+'/watch/'
	jcInvNf98TZ5gRUDFp40li2uzVPrO,mmKyGIgPQ1A2637Twqd,s7s0wmIdLNrB9Vl5n = [],[],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD2-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	DmLwHpYuOURyf = jj0dZrgiKb.findall('العمر :.*?<strong">(.*?)</strong>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if DmLwHpYuOURyf and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,DmLwHpYuOURyf): return
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('<iframe src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=__embed')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"main--contents"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for FXJlEeYKmni,UOQ7lSWTauRPv,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+UOQ7lSWTauRPv+'&i='+FXJlEeYKmni
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"downloads"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,name in items:
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__download')
	for A0ZDwrfRx1vOyed7aUETublQ in jcInvNf98TZ5gRUDFp40li2uzVPrO:
		hhEH1rcSP0z6Bkqy8OD,name = A0ZDwrfRx1vOyed7aUETublQ.split('?named')
		if hhEH1rcSP0z6Bkqy8OD not in mmKyGIgPQ1A2637Twqd:
			mmKyGIgPQ1A2637Twqd.append(hhEH1rcSP0z6Bkqy8OD)
			s7s0wmIdLNrB9Vl5n.append(A0ZDwrfRx1vOyed7aUETublQ)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(s7s0wmIdLNrB9Vl5n,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	FFwVakdM8NvjeJRK3oyQI9ti24 = hhD7r1VvaPt3TC06SJjqKRfEid
	url = FFwVakdM8NvjeJRK3oyQI9ti24+'/?s='+search
	HPdaS7kenW0m(url,'details5')
	return