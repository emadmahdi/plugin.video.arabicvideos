# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ௸")
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,iE0GxkBnVRO4NPwleT):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==JHMxIE4fs1mvQtKW7R(u"࠳࠴࠲ಆ"): RCmHBOKtejQ8lu4L = NkLpXuHt4sKvbWPz3JhwGyMVed5fiA()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠵࠴ಇ"): RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(iE0GxkBnVRO4NPwleT)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==llkFwuCyhaP3sK76qO4T(u"࠵࠶࠶ಈ"): RCmHBOKtejQ8lu4L = EEZXkFYyurSDg93WalK2eG()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==w8JC1y7Lp3(u"࠶࠷࠸ಉ"): RCmHBOKtejQ8lu4L = XkNMjs5EfipnQGSARUFtaqZ61D()
	else: RCmHBOKtejQ8lu4L = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return RCmHBOKtejQ8lu4L
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(iE0GxkBnVRO4NPwleT):
	yyYuosJmc3QDUGSA(iE0GxkBnVRO4NPwleT,UdbRGoKhcDeI4lVfns5,fmkZtbRj3ux(u"࠭ࡶࡪࡦࡨࡳࠬ௹"))
	return
def XkNMjs5EfipnQGSARUFtaqZ61D():
	SLAiUwpDRoZIQfvB7 = yRWQMHxZEz0(u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭௺")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧ௻"),SLAiUwpDRoZIQfvB7)
	return
def NkLpXuHt4sKvbWPz3JhwGyMVed5fiA():
	mwOxEyYAg63B(weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࡯࡭ࡳࡱࠧ௼"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ௽"),wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠷࠸࠹ಊ"))
	mwOxEyYAg63B(yRWQMHxZEz0(u"ࠫࡱ࡯࡮࡬ࠩ௾"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬ௿"),wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠹࠲ಋ"))
	mwOxEyYAg63B(weh7SGmuTgXOVRcMo1rlLq(u"࠭࡬ࡪࡰ࡮ࠫఀ"),JegF7SlMawI03+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ఁ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"࠿࠹࠺࠻ಌ"))
	TkfPux68rqd2jhFVyXeRKaZ0oID = SS9IlqVGXUPyjzERNsf851Bi2ag()
	Zml0rbfODtBwzapM8xLvKujiAeR = b7i1PgC8Z4e5BFoHNd9E2UVvfc.stat(TkfPux68rqd2jhFVyXeRKaZ0oID).st_mtime
	dOCgFmA6NUr4ols7ufiGJ = []
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: g41AbqruEx2hfRJXsNajYLtTli = b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(TkfPux68rqd2jhFVyXeRKaZ0oID.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq))
	else: g41AbqruEx2hfRJXsNajYLtTli = b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(TkfPux68rqd2jhFVyXeRKaZ0oID.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq))
	for HHBepATkVUyGPYhxm0uOK73ds in g41AbqruEx2hfRJXsNajYLtTli:
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: HHBepATkVUyGPYhxm0uOK73ds = HHBepATkVUyGPYhxm0uOK73ds.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		if not HHBepATkVUyGPYhxm0uOK73ds.startswith(weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡨ࡬ࡰࡪࡥࠧం")): continue
		oTu9SdPVR4mvt8KlgA60xWHnI = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(TkfPux68rqd2jhFVyXeRKaZ0oID,HHBepATkVUyGPYhxm0uOK73ds)
		Zml0rbfODtBwzapM8xLvKujiAeR = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.getmtime(oTu9SdPVR4mvt8KlgA60xWHnI)
		dOCgFmA6NUr4ols7ufiGJ.append([HHBepATkVUyGPYhxm0uOK73ds,Zml0rbfODtBwzapM8xLvKujiAeR])
	dOCgFmA6NUr4ols7ufiGJ = sorted(dOCgFmA6NUr4ols7ufiGJ,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: key[UD4N8MjVTd])
	for HHBepATkVUyGPYhxm0uOK73ds,Zml0rbfODtBwzapM8xLvKujiAeR in dOCgFmA6NUr4ols7ufiGJ:
		if ndib93Ol6UojCrEV:
			try: HHBepATkVUyGPYhxm0uOK73ds = HHBepATkVUyGPYhxm0uOK73ds.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			except: pass
			HHBepATkVUyGPYhxm0uOK73ds = HHBepATkVUyGPYhxm0uOK73ds.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		oTu9SdPVR4mvt8KlgA60xWHnI = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(TkfPux68rqd2jhFVyXeRKaZ0oID,HHBepATkVUyGPYhxm0uOK73ds)
		mwOxEyYAg63B(VhqD3zp7mUieI8sMQlETH(u"ࠩࡹ࡭ࡩ࡫࡯ࠨః"),HHBepATkVUyGPYhxm0uOK73ds,oTu9SdPVR4mvt8KlgA60xWHnI,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠳࠴࠳಍"))
	return
def SS9IlqVGXUPyjzERNsf851Bi2ag():
	TkfPux68rqd2jhFVyXeRKaZ0oID = OOnvcPQy85HYA.getSetting(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ఄ"))
	if TkfPux68rqd2jhFVyXeRKaZ0oID: return TkfPux68rqd2jhFVyXeRKaZ0oID
	OOnvcPQy85HYA.setSetting(xdSThjYnuHXAU6M(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧఅ"),kAXGQe4sH7o3dfLUKv2zlZDM8r09)
	return kAXGQe4sH7o3dfLUKv2zlZDM8r09
def EEZXkFYyurSDg93WalK2eG():
	TkfPux68rqd2jhFVyXeRKaZ0oID = SS9IlqVGXUPyjzERNsf851Bi2ag()
	GgIJWYpQPinVct = T4dIruOctCl2qwYNE0SDyU(kPCxIUZb1V(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬఆ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪఇ"),QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+TkfPux68rqd2jhFVyXeRKaZ0oID+AAByQSLgaZwCsKnvc5eWNmY+llkFwuCyhaP3sK76qO4T(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨఈ"))
	if GgIJWYpQPinVct==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠲ಎ"):
		SIhUfsY1lDxid = CUa57rbLZxwmhkcSDvT2PBWKRq(rDG9dZoXRhCJcieUSF0KB(u"࠵ಏ"),rDG9dZoXRhCJcieUSF0KB(u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬఉ"),jQv0du1iVxTgAXCM(u"ࠩ࡯ࡳࡨࡧ࡬ࠨఊ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,y0yvdNOZkiKEg5RLMhoDVQAB9F2,TkfPux68rqd2jhFVyXeRKaZ0oID)
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(vWNRusF46D7Mi8GpZ(u"ࠪࡧࡪࡴࡴࡦࡴࠪఋ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨఌ"),QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+TkfPux68rqd2jhFVyXeRKaZ0oID+AAByQSLgaZwCsKnvc5eWNmY+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭఍"))
		if ug0EmiKYnRT1qeH9MFyr3pO==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠴ಐ"):
			OOnvcPQy85HYA.setSetting(xdSThjYnuHXAU6M(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩఎ"),SIhUfsY1lDxid)
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,VhqD3zp7mUieI8sMQlETH(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨఏ"))
	return
def svhR97HQm3(iE0GxkBnVRO4NPwleT,cUCwLQ3jTsKrNOyR1=wUvcPrYDfISbZolAm83GKEqMyXkn5,website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+A6Sg45ChDR3BJLYfFH(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨఐ")+iE0GxkBnVRO4NPwleT+JHMxIE4fs1mvQtKW7R(u"ࠩࠣࡡࠬ఑"))
	if not cUCwLQ3jTsKrNOyR1: cUCwLQ3jTsKrNOyR1 = rjZFa0VMBuPRHg1cIYJpd52oxl4(iE0GxkBnVRO4NPwleT)
	TkfPux68rqd2jhFVyXeRKaZ0oID = SS9IlqVGXUPyjzERNsf851Bi2ag()
	FbwGmC5HsIKyPlTnNueD = kJOzn1CFwXUpVTudGqIm6SvHtjQW2Z(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	HHBepATkVUyGPYhxm0uOK73ds = FbwGmC5HsIKyPlTnNueD.replace(UKFZBQAVXHI5s17LyvuRpCY2,DpRJnas65uVcO0S17dYG(u"ࠪࡣࠬఒ"))
	HHBepATkVUyGPYhxm0uOK73ds = wYjpROZ8HU92X(HHBepATkVUyGPYhxm0uOK73ds)
	HHBepATkVUyGPYhxm0uOK73ds = jQv0du1iVxTgAXCM(u"ࠫ࡫࡯࡬ࡦࡡࠪఓ")+str(int(yoJ7t3WpjPkrCmTq))[-weh7SGmuTgXOVRcMo1rlLq(u"࠸಑"):]+w8JC1y7Lp3(u"ࠬࡥࠧఔ")+HHBepATkVUyGPYhxm0uOK73ds+cUCwLQ3jTsKrNOyR1
	zFWUgklaqYEnv5Bdw = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(TkfPux68rqd2jhFVyXeRKaZ0oID,HHBepATkVUyGPYhxm0uOK73ds)
	DDPMgjZIuk = {}
	DDPMgjZIuk[yRWQMHxZEz0(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨక")] = wUvcPrYDfISbZolAm83GKEqMyXkn5
	DDPMgjZIuk[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡂࡥࡦࡩࡵࡺࠧఖ")] = JHMxIE4fs1mvQtKW7R(u"ࠨࠬ࠲࠮ࠬగ")
	iE0GxkBnVRO4NPwleT = iE0GxkBnVRO4NPwleT.replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬఘ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if erqDsJmL3BQHuGtPkcf0X9(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨఙ") in iE0GxkBnVRO4NPwleT:
		ZD5n0eJivzWOMxY98dgrumkwRG,vpHXP3E6Kt = iE0GxkBnVRO4NPwleT.rsplit(erqDsJmL3BQHuGtPkcf0X9(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩచ"),rDG9dZoXRhCJcieUSF0KB(u"࠶ಒ"))
		vpHXP3E6Kt = vpHXP3E6Kt.replace(jQv0du1iVxTgAXCM(u"ࠬࢂࠧఛ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(erqDsJmL3BQHuGtPkcf0X9(u"࠭ࠦࠨజ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	else: ZD5n0eJivzWOMxY98dgrumkwRG,vpHXP3E6Kt = iE0GxkBnVRO4NPwleT,None
	if not vpHXP3E6Kt: vpHXP3E6Kt = ZZIDf1A9vE0g86RMq7tpKUrzaij()
	if vpHXP3E6Kt: DDPMgjZIuk[yRWQMHxZEz0(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫఝ")] = vpHXP3E6Kt
	if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪఞ") in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG,oQbdyTekSgKa = ZD5n0eJivzWOMxY98dgrumkwRG.rsplit(yRWQMHxZEz0(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫట"),w8JC1y7Lp3(u"࠷ಓ"))
	else: ZD5n0eJivzWOMxY98dgrumkwRG,oQbdyTekSgKa = ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.strip(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࢀࠬఠ")).strip(lCT8hfYUBX4OQMmL(u"ࠫࠫ࠭డ")).strip(kPCxIUZb1V(u"ࠬࢂࠧఢ")).strip(rDG9dZoXRhCJcieUSF0KB(u"࠭ࠦࠨణ"))
	oQbdyTekSgKa = oQbdyTekSgKa.replace(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡽࠩత"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࠨࠪథ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if oQbdyTekSgKa:	DDPMgjZIuk[kPCxIUZb1V(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪద")] = oQbdyTekSgKa
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫధ")+ZD5n0eJivzWOMxY98dgrumkwRG+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧన")+str(DDPMgjZIuk)+jQv0du1iVxTgAXCM(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ఩")+zFWUgklaqYEnv5Bdw+yRWQMHxZEz0(u"࠭ࠠ࡞ࠩప"))
	TWOUKC3StPv6AQrXMJ9N5kipF8YVZ = it4DKnryZlx(u"࠱࠱࠴࠷ಔ")*it4DKnryZlx(u"࠱࠱࠴࠷ಔ")
	oiLVm4fSj5hYsdXNaFATU = NpzKdEgZiV4efDOCRqUwIWBTXA2()//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ
	if not oiLVm4fSj5hYsdXNaFATU:
		sNQlowOJdgWBt2cyV18ZI6Ye(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ఫ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨబ"),w8JC1y7Lp3(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭భ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭మ"))
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jQv0du1iVxTgAXCM(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬయ"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if cUCwLQ3jTsKrNOyR1==llkFwuCyhaP3sK76qO4T(u"ࠬ࠴࡭࠴ࡷ࠻ࠫర"):
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,ZD5n0eJivzWOMxY98dgrumkwRG,DDPMgjZIuk)
		if len(Eu8LWnSt3fyJzIC)==MFhbWia58mP3su0fk2d(u"࠱ಕ"):
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(jQv0du1iVxTgAXCM(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪఱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			return Z19pUxa2gfGMNKoDsEuytn85SjFvA
		elif len(Eu8LWnSt3fyJzIC)==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠳ಖ"): EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠳ಗ")
		elif len(Eu8LWnSt3fyJzIC)>jQv0du1iVxTgAXCM(u"࠵ಘ"):
			EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(JHMxIE4fs1mvQtKW7R(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬల"), Eu8LWnSt3fyJzIC)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -vWNRusF46D7Mi8GpZ(u"࠶ಙ") :
				hg79cQmoVfMCukiU8ERpT6JqywSrN3(vvhR5ozeiJpANyl8fFO3GBw(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫళ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				return Z19pUxa2gfGMNKoDsEuytn85SjFvA
		ZD5n0eJivzWOMxY98dgrumkwRG = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	o2hMIdJvr54ip8PjT = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠶ಚ")
	import requests as sfS7a5R14zxlLBM9y0cEUmNV
	if cUCwLQ3jTsKrNOyR1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨఴ"):
		zFWUgklaqYEnv5Bdw = zFWUgklaqYEnv5Bdw.rsplit(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩవ"))[wTLFCOcM26fmYlW7U]+erqDsJmL3BQHuGtPkcf0X9(u"ࠫ࠳ࡳࡰ࠵ࠩశ")
		yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,kPCxIUZb1V(u"ࠬࡍࡅࡕࠩష"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭స"))
		d5XELnHuz7cCeK9At1wOjgis8UfW = yBn638aQbxUdpCSA.content
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨహ"),d5XELnHuz7cCeK9At1wOjgis8UfW+D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ࡞ࡱࡠࡷ࠭఺"),jj0dZrgiKb.DOTALL)
		if not ppAJI9kDbz5MXa76UEF:
			KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jQv0du1iVxTgAXCM(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ఻")+ZD5n0eJivzWOMxY98dgrumkwRG+vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࠤࡢ఼࠭"))
			return Z19pUxa2gfGMNKoDsEuytn85SjFvA
		hhEH1rcSP0z6Bkqy8OD = ppAJI9kDbz5MXa76UEF[wTLFCOcM26fmYlW7U]
		if not hhEH1rcSP0z6Bkqy8OD.startswith(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࡭ࡺࡴࡱࠩఽ")):
			if hhEH1rcSP0z6Bkqy8OD.startswith(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠵࠯ࠨా")): hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG.split(llkFwuCyhaP3sK76qO4T(u"࠭࠺ࠨి"),A6Sg45ChDR3BJLYfFH(u"࠱ಛ"))[wTLFCOcM26fmYlW7U]+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠻ࠩీ")+hhEH1rcSP0z6Bkqy8OD
			elif hhEH1rcSP0z6Bkqy8OD.startswith(yRWQMHxZEz0(u"ࠨ࠱ࠪు")): hhEH1rcSP0z6Bkqy8OD = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡸࡶࡱ࠭ూ"))+hhEH1rcSP0z6Bkqy8OD
			else: hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG.rsplit(A6Sg45ChDR3BJLYfFH(u"ࠪ࠳ࠬృ"),xdSThjYnuHXAU6M(u"࠲ಜ"))[wTLFCOcM26fmYlW7U]+vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ࠴࠭ౄ")+hhEH1rcSP0z6Bkqy8OD
		yBn638aQbxUdpCSA = sfS7a5R14zxlLBM9y0cEUmNV.request(bQGafNLXyFgsZP6ut(u"ࠬࡍࡅࡕࠩ౅"),hhEH1rcSP0z6Bkqy8OD,headers=DDPMgjZIuk,verify=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		OtUhBWZQrDq0sLETN4g = yBn638aQbxUdpCSA.content
		Uj9aWleXTxBA5crhm = len(OtUhBWZQrDq0sLETN4g)
		QoqZg8RaB15FxPYmG0bcO6tAl7U3J = len(ppAJI9kDbz5MXa76UEF)
		o2hMIdJvr54ip8PjT = Uj9aWleXTxBA5crhm*QoqZg8RaB15FxPYmG0bcO6tAl7U3J
	else:
		Uj9aWleXTxBA5crhm = jQv0du1iVxTgAXCM(u"࠳ಝ")*TWOUKC3StPv6AQrXMJ9N5kipF8YVZ
		yBn638aQbxUdpCSA = sfS7a5R14zxlLBM9y0cEUmNV.request(it4DKnryZlx(u"࠭ࡇࡆࡖࠪె"),ZD5n0eJivzWOMxY98dgrumkwRG,headers=DDPMgjZIuk,verify=Z19pUxa2gfGMNKoDsEuytn85SjFvA,stream=y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		if it4DKnryZlx(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨే") in yBn638aQbxUdpCSA.headers: o2hMIdJvr54ip8PjT = int(yBn638aQbxUdpCSA.headers[s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩై")])
		QoqZg8RaB15FxPYmG0bcO6tAl7U3J = int(o2hMIdJvr54ip8PjT//Uj9aWleXTxBA5crhm)
	DUjEy2f3kZAQveqlNHWFtYRVTbo0pg = int(o2hMIdJvr54ip8PjT//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)+jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠴ಞ")
	if o2hMIdJvr54ip8PjT<it4DKnryZlx(u"࠶࠶࠶࠰࠱ಟ"):
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+w8JC1y7Lp3(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ౉")+ZD5n0eJivzWOMxY98dgrumkwRG+A6Sg45ChDR3BJLYfFH(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧొ")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪో")+str(oiLVm4fSj5hYsdXNaFATU)+rDG9dZoXRhCJcieUSF0KB(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨౌ")+zFWUgklaqYEnv5Bdw+Gj3rMP1Cb8wHdp49la0(u"࠭ࠠ࡞్ࠩ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩ౎"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	GPIhXVuneN4ocZm5D6YaCWT = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠹࠶࠰ಠ")
	EamK3CNwe2BvqOl8Ykn4WG0iXyHfUR = oiLVm4fSj5hYsdXNaFATU-DUjEy2f3kZAQveqlNHWFtYRVTbo0pg
	if EamK3CNwe2BvqOl8Ykn4WG0iXyHfUR<GPIhXVuneN4ocZm5D6YaCWT:
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+w8JC1y7Lp3(u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ౏")+ZD5n0eJivzWOMxY98dgrumkwRG+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭౐")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ౑")+str(oiLVm4fSj5hYsdXNaFATU)+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࠥࡓࡂࠡ࠯ࠣࠫ౒")+str(GPIhXVuneN4ocZm5D6YaCWT)+DpRJnas65uVcO0S17dYG(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ౓")+zFWUgklaqYEnv5Bdw+A6Sg45ChDR3BJLYfFH(u"࠭ࠠ࡞ࠩ౔"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏ౕ๊ࠧ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ౖࠦࠧ")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+rDG9dZoXRhCJcieUSF0KB(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨ౗")+str(oiLVm4fSj5hYsdXNaFATU)+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪౘ")+str(GPIhXVuneN4ocZm5D6YaCWT)+JHMxIE4fs1mvQtKW7R(u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭ౙ"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(Gj3rMP1Cb8wHdp49la0(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬౚ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"࠭็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥลࠧ౛"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠฮฮ่๋ࠥะโา์หหࠥ࠭౜")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+weh7SGmuTgXOVRcMo1rlLq(u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦสใำํฬฬࠦࠧౝ")+str(oiLVm4fSj5hYsdXNaFATU)+DpRJnas65uVcO0S17dYG(u"้ࠩࠣ๏เวษษํฮࠥ๎็ัษࠣห้๋ไโࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠๅๆอั๊๐ไࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦลๅ๋ࠣะ์อาไࠢ࠱ࠤ์๊ࠠศ่อࠤ๊ะรไัࠣ์ฯื๊ะࠢส่ฬูสๆำสีࠥฮสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣรࠬ౞"))
	if ug0EmiKYnRT1qeH9MFyr3pO!=llkFwuCyhaP3sK76qO4T(u"࠷ಡ"):
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ౟"))
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ౠ")+ZD5n0eJivzWOMxY98dgrumkwRG+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬౡ")+zFWUgklaqYEnv5Bdw+yRWQMHxZEz0(u"࠭ࠠ࡞ࠩౢ"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+w8JC1y7Lp3(u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬౣ"))
	OO9xQWZnuTNMf1SDFE43JPeV = tt4jsl3YLKexr()
	OO9xQWZnuTNMf1SDFE43JPeV.create(zFWUgklaqYEnv5Bdw,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ౤"))
	qLYSG1ZAkFe = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	V1VfMqTkXdYulSwF75JPhDgZ = L5jXH0fZ8TvsESR.time()
	if not TTuO14NzmB.W1haXcb7tVZ6K:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,s149dk8uh2p7oFzaLxZeI3Or(u"ࠩหือฮฺࠠั่ࠤฬ๊สษำ฼ࠤฯ๋ࠠฦๆ฽หฦࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ౥"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: ZDTgGOuUiW0R = open(zFWUgklaqYEnv5Bdw,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡻࡧ࠭౦"))
	else: ZDTgGOuUiW0R = open(zFWUgklaqYEnv5Bdw.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡼࡨࠧ౧"))
	if cUCwLQ3jTsKrNOyR1==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ౨"):
		for qbRmVByrJv18 in range(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠱ಢ"),QoqZg8RaB15FxPYmG0bcO6tAl7U3J+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠱ಢ")):
			hhEH1rcSP0z6Bkqy8OD = ppAJI9kDbz5MXa76UEF[qbRmVByrJv18-ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠲ಣ")]
			if not hhEH1rcSP0z6Bkqy8OD.startswith(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡨࡵࡶࡳࠫ౩")):
				if hhEH1rcSP0z6Bkqy8OD.startswith(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࠰࠱ࠪ౪")): hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG.split(erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࠼ࠪ౫"),lCT8hfYUBX4OQMmL(u"࠳ತ"))[wTLFCOcM26fmYlW7U]+yRWQMHxZEz0(u"ࠩ࠽ࠫ౬")+hhEH1rcSP0z6Bkqy8OD
				elif hhEH1rcSP0z6Bkqy8OD.startswith(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࠳ࠬ౭")): hhEH1rcSP0z6Bkqy8OD = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,Gj3rMP1Cb8wHdp49la0(u"ࠫࡺࡸ࡬ࠨ౮"))+hhEH1rcSP0z6Bkqy8OD
				else: hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG.rsplit(erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࠵ࠧ౯"),weh7SGmuTgXOVRcMo1rlLq(u"࠴ಥ"))[wTLFCOcM26fmYlW7U]+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭࠯ࠨ౰")+hhEH1rcSP0z6Bkqy8OD
			yBn638aQbxUdpCSA = sfS7a5R14zxlLBM9y0cEUmNV.request(rDG9dZoXRhCJcieUSF0KB(u"ࠧࡈࡇࡗࠫ౱"),hhEH1rcSP0z6Bkqy8OD,headers=DDPMgjZIuk,verify=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			OtUhBWZQrDq0sLETN4g = yBn638aQbxUdpCSA.content
			yBn638aQbxUdpCSA.close()
			ZDTgGOuUiW0R.write(OtUhBWZQrDq0sLETN4g)
			G56F4w2OaJqZPWRlH = L5jXH0fZ8TvsESR.time()
			CpH64QeZ5xYS2NTzg78aJPcfBb = G56F4w2OaJqZPWRlH-V1VfMqTkXdYulSwF75JPhDgZ
			qMPi9XwQECu1Z3SDtm8IGvNBOrV = CpH64QeZ5xYS2NTzg78aJPcfBb//qbRmVByrJv18
			Vz2dZsOoMkmKJjuqHY8 = qMPi9XwQECu1Z3SDtm8IGvNBOrV*(QoqZg8RaB15FxPYmG0bcO6tAl7U3J+weh7SGmuTgXOVRcMo1rlLq(u"࠵ದ"))
			VjbpkTRudXKS8nIJ75rU = Vz2dZsOoMkmKJjuqHY8-CpH64QeZ5xYS2NTzg78aJPcfBb
			snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,int(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠷࠰࠱ನ")*qbRmVByrJv18//(QoqZg8RaB15FxPYmG0bcO6tAl7U3J+MFhbWia58mP3su0fk2d(u"࠶ಧ"))),MFhbWia58mP3su0fk2d(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ౲"),Gj3rMP1Cb8wHdp49la0(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ౳"),str(qbRmVByrJv18*Uj9aWleXTxBA5crhm//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)+bQGafNLXyFgsZP6ut(u"ࠪ࠳ࠬ౴")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+JHMxIE4fs1mvQtKW7R(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ౵")+L5jXH0fZ8TvsESR.strftime(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ౶"),L5jXH0fZ8TvsESR.gmtime(VjbpkTRudXKS8nIJ75rU))+DpRJnas65uVcO0S17dYG(u"࠭ࠠแࠩ౷"))
			if OO9xQWZnuTNMf1SDFE43JPeV.iscanceled():
				qLYSG1ZAkFe = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				break
	else:
		qbRmVByrJv18 = weh7SGmuTgXOVRcMo1rlLq(u"࠰಩")
		for OtUhBWZQrDq0sLETN4g in yBn638aQbxUdpCSA.iter_content(chunk_size=Uj9aWleXTxBA5crhm):
			ZDTgGOuUiW0R.write(OtUhBWZQrDq0sLETN4g)
			qbRmVByrJv18 = qbRmVByrJv18+DpRJnas65uVcO0S17dYG(u"࠲ಪ")
			G56F4w2OaJqZPWRlH = L5jXH0fZ8TvsESR.time()
			CpH64QeZ5xYS2NTzg78aJPcfBb = G56F4w2OaJqZPWRlH-V1VfMqTkXdYulSwF75JPhDgZ
			qMPi9XwQECu1Z3SDtm8IGvNBOrV = CpH64QeZ5xYS2NTzg78aJPcfBb/qbRmVByrJv18
			Vz2dZsOoMkmKJjuqHY8 = qMPi9XwQECu1Z3SDtm8IGvNBOrV*(QoqZg8RaB15FxPYmG0bcO6tAl7U3J+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳ಫ"))
			VjbpkTRudXKS8nIJ75rU = Vz2dZsOoMkmKJjuqHY8-CpH64QeZ5xYS2NTzg78aJPcfBb
			snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,int(jQv0du1iVxTgAXCM(u"࠵࠵࠶ಭ")*qbRmVByrJv18/(QoqZg8RaB15FxPYmG0bcO6tAl7U3J+lCT8hfYUBX4OQMmL(u"࠴ಬ"))),D2PpKMeZFWrmfxTSs4L1tz(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ౸"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨ౹"),str(qbRmVByrJv18*Uj9aWleXTxBA5crhm//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)+VhqD3zp7mUieI8sMQlETH(u"ࠩ࠲ࠫ౺")+str(DUjEy2f3kZAQveqlNHWFtYRVTbo0pg)+xm6jK1ZMuWq5(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ౻")+L5jXH0fZ8TvsESR.strftime(xm6jK1ZMuWq5(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ౼"),L5jXH0fZ8TvsESR.gmtime(VjbpkTRudXKS8nIJ75rU))+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࠦเࠨ౽"))
			if OO9xQWZnuTNMf1SDFE43JPeV.iscanceled():
				qLYSG1ZAkFe = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				break
		yBn638aQbxUdpCSA.close()
	ZDTgGOuUiW0R.close()
	OO9xQWZnuTNMf1SDFE43JPeV.close()
	if not qLYSG1ZAkFe:
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jQv0du1iVxTgAXCM(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ౾")+ZD5n0eJivzWOMxY98dgrumkwRG+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ౿")+zFWUgklaqYEnv5Bdw+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࠢࡠࠫಀ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩหัุฮุࠠๆห็ࠥะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪಁ"))
		return y0yvdNOZkiKEg5RLMhoDVQAB9F2
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jQv0du1iVxTgAXCM(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩಂ")+ZD5n0eJivzWOMxY98dgrumkwRG+s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫಃ")+zFWUgklaqYEnv5Bdw+DpRJnas65uVcO0S17dYG(u"ࠬࠦ࡝ࠨ಄"))
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬಅ"))
	return y0yvdNOZkiKEg5RLMhoDVQAB9F2