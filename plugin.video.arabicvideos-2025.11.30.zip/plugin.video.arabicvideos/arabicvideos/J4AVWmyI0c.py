# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'BOKRA'
UT69hgqoKsWNIwM5zkAYb = '_BKR_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
i6TIRax9v0EDFJs2gVtfzp = ['افلام للكبار','بكرا TV']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==370: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==371: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==372: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==374: RCmHBOKtejQ8lu4L = f6TusSGZMIEzr3wN(url)
	elif mode==375: RCmHBOKtejQ8lu4L = mK9fWYM7uJ60cSLqjokT1Z(url)
	elif mode==376: RCmHBOKtejQ8lu4L = TTHa8JkyVDUARFpYzhCfxBuZo6dMb(0,url)
	elif mode==377: RCmHBOKtejQ8lu4L = TTHa8JkyVDUARFpYzhCfxBuZo6dMb(1,url)
	elif mode==379: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-MENU-1st')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,379,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('right-side(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المميزة',hhD7r1VvaPt3TC06SJjqKRfEid,375)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الأحدث',hhD7r1VvaPt3TC06SJjqKRfEid,376)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'قائمة الممثلين',hhD7r1VvaPt3TC06SJjqKRfEid,374)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="container"(.*?)top-menu',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items[7:]:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371)
		for hhEH1rcSP0z6Bkqy8OD,title in items[0:7]:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371)
	return
def f6TusSGZMIEzr3wN(website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-ACTORSMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="row cat Tags"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if 'http' in hhEH1rcSP0z6Bkqy8OD: continue
			else: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371)
	return
def mK9fWYM7uJ60cSLqjokT1Z(website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-FEATURED-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"MainContent"(.*?)main-title2',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('://',':///').replace('//','/').replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
				mwOxEyYAg63B('video',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,372,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def TTHa8JkyVDUARFpYzhCfxBuZo6dMb(id,website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-WATCHINGNOW-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-title2(.*?)class="row',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[id]
		items = jj0dZrgiKb.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('://',':///').replace('//','/').replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
				mwOxEyYAg63B('video',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,372,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def HPdaS7kenW0m(url,D2eQ8jwIuaGZUoW41HbtKi63L9x=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if 'vidpage_' in url:
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('href="(/Album-.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD[0]
			HPdaS7kenW0m(hhEH1rcSP0z6Bkqy8OD)
			return
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class=" subcats"(.*?)class="col-md-3',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if D2eQ8jwIuaGZUoW41HbtKi63L9x==wUvcPrYDfISbZolAm83GKEqMyXkn5 and pLHIPUY3TWAeE70 and pLHIPUY3TWAeE70[0].count('href')>1:
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',url,371,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'titles')
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371)
	else:
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="col-md-3(.*?)col-xs-12',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="col-sm-8"(.*?)col-xs-12',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('://',':///').replace('//','/').replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
				if '/al_' in hhEH1rcSP0z6Bkqy8OD:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) - +الحلقة +\d+',title,jj0dZrgiKb.DOTALL)
					if xNVKL75nEZstg4wfXBkySQ: title = '_MOD_مسلسل '+xNVKL75nEZstg4wfXBkySQ[0]
					if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
						v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
						mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,372,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('class="".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				title = 'صفحة '+mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,371,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'titles')
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	bxiMUQmPRvu = jj0dZrgiKb.findall('label-success mrg-btm-5 ">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	qaLFXuDExl8w = wUvcPrYDfISbZolAm83GKEqMyXkn5
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('var url = "(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]
	else: ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('/vidpage_','/Play/')
	if 'http' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+ZD5n0eJivzWOMxY98dgrumkwRG
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.strip('-')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'BOKRA-PLAY-2nd')
	xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
	qaLFXuDExl8w = jj0dZrgiKb.findall('src="(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
	if qaLFXuDExl8w:
		qaLFXuDExl8w = qaLFXuDExl8w[-1]
		if 'http' not in qaLFXuDExl8w: qaLFXuDExl8w = 'http:'+qaLFXuDExl8w
		if '/PLAY/' not in ZD5n0eJivzWOMxY98dgrumkwRG:
			if 'embed.min.js' in qaLFXuDExl8w:
				ZCxQFRd0kDbNjcfYgX5O9I2r = jj0dZrgiKb.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
				if ZCxQFRd0kDbNjcfYgX5O9I2r:
					gPMZypA87kvrfFzmBw, kt4vL7gyrbI = ZCxQFRd0kDbNjcfYgX5O9I2r[0]
					qaLFXuDExl8w = TO3vi2rSZ0LRhKlwgG4qkYFIC(qaLFXuDExl8w,'url')+'/v2/'+gPMZypA87kvrfFzmBw+'/config/'+kt4vL7gyrbI+'.json'
		import oo6FYcUjud
		oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy([qaLFXuDExl8w],UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/Search/'+search
	HPdaS7kenW0m(url)
	return