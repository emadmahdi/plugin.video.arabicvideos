# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'ALARAB'
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
UT69hgqoKsWNIwM5zkAYb = '_KLA_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==10: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==11: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	elif mode==12: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==13: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==14: RCmHBOKtejQ8lu4L = FEkrl38NI7HGMiB9uCye1hjJU()
	elif mode==15: RCmHBOKtejQ8lu4L = q6ba9QC8PMIx7SRY43Lvzh()
	elif mode==16: RCmHBOKtejQ8lu4L = y2u3FGPWw8jx()
	elif mode==19: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,19,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'آخر الإضافات',wUvcPrYDfISbZolAm83GKEqMyXkn5,14)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان',wUvcPrYDfISbZolAm83GKEqMyXkn5,15)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ALARAB-MENU-1st')
	pLHIPUY3TWAeE70=jj0dZrgiKb.findall('id="nav-slider"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	qMNnK06oExYpyAtblzBVd82HC73 = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',qMNnK06oExYpyAtblzBVd82HC73,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,11)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="navbar"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	i9eu0gvptXjKMAczZyE = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,11)
	return II64TLxj3mbqEyh9pHQ8oAv
def q6ba9QC8PMIx7SRY43Lvzh():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'جميع المسلسلات العربية',hhD7r1VvaPt3TC06SJjqKRfEid+'/view-8/مسلسلات-عربية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات السنة الأخيرة',wUvcPrYDfISbZolAm83GKEqMyXkn5,16)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان الأخيرة 1',hhD7r1VvaPt3TC06SJjqKRfEid+'/view-8/مسلسلات-رمضان-2022',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان الأخيرة 2',hhD7r1VvaPt3TC06SJjqKRfEid+'/view-8/مسلسلات-رمضان-2023',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2023',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2023/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2022',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2022/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2021',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2021/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2020',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2020/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2019',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2019/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2018',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2018/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2017',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2017/مصرية',11)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مسلسلات رمضان 2016',hhD7r1VvaPt3TC06SJjqKRfEid+'/ramadan2016/مصرية',11)
	return
def FEkrl38NI7HGMiB9uCye1hjJU():
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'ALARAB-LATEST-1st')
	pLHIPUY3TWAeE70=jj0dZrgiKb.findall('heading-top(.*?)div class=',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]+pLHIPUY3TWAeE70[1]
	items=jj0dZrgiKb.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		url = hhD7r1VvaPt3TC06SJjqKRfEid + hhEH1rcSP0z6Bkqy8OD
		if 'series' in url: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,11,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,url,12,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def HPdaS7kenW0m(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,True,'ALARAB-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('video-category(.*?)right_content',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	DJQIGSCHUMdvxo4 = False
	items = jj0dZrgiKb.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi,OxZMrt2u7N5YP0vigj = [],[]
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		if title==wUvcPrYDfISbZolAm83GKEqMyXkn5: title = hhEH1rcSP0z6Bkqy8OD.split('/')[-1].replace('-',UKFZBQAVXHI5s17LyvuRpCY2)
		eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = jj0dZrgiKb.findall('(\d+)',title,jj0dZrgiKb.DOTALL)
		if eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP: eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = int(eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP[0])
		else: eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = 0
		OxZMrt2u7N5YP0vigj.append([cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP])
	OxZMrt2u7N5YP0vigj = sorted(OxZMrt2u7N5YP0vigj, reverse=True, key=lambda key: key[3])
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP in OxZMrt2u7N5YP0vigj:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid + hhEH1rcSP0z6Bkqy8OD
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('عالية على العرب',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('مشاهدة مباشرة',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('اون لاين',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('اونلاين',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('بجودة عالية',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('جودة عالية',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('بدون تحميل',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('على العرب',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.replace('مباشرة',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		title = '_MOD_'+title
		HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
			if xNVKL75nEZstg4wfXBkySQ: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = xNVKL75nEZstg4wfXBkySQ[0]
		if HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ not in v2v3ase4WBgVjbOnu96PCzlDKi:
			v2v3ase4WBgVjbOnu96PCzlDKi.append(HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,hhEH1rcSP0z6Bkqy8OD,13,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				DJQIGSCHUMdvxo4 = True
			elif 'series' in hhEH1rcSP0z6Bkqy8OD:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,11,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				DJQIGSCHUMdvxo4 = True
			else:
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,12,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				DJQIGSCHUMdvxo4 = True
	if DJQIGSCHUMdvxo4:
		items = jj0dZrgiKb.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,sbNukjOf4chz in items:
			url = hhD7r1VvaPt3TC06SJjqKRfEid + hhEH1rcSP0z6Bkqy8OD
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+sbNukjOf4chz,url,11)
	return
def mCwqRg7HpivAQ6S(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'ALARAB-EPISODES-1st')
	DPEAV2jq8xQO79IGyeLC = jj0dZrgiKb.findall('href="(/series.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+DPEAV2jq8xQO79IGyeLC[0]
	RCmHBOKtejQ8lu4L = HPdaS7kenW0m(ZD5n0eJivzWOMxY98dgrumkwRG)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'ALARAB-PLAY-1st')
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('class="resp-iframe" src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG:
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('^(http.*?)(http.*?)$',ZD5n0eJivzWOMxY98dgrumkwRG,jj0dZrgiKb.DOTALL)
		if ppAJI9kDbz5MXa76UEF:
			ooZGMlYybF8aNfAOwps = ppAJI9kDbz5MXa76UEF[0][0]
			QIih0tfeVyBX2WTMGAR8L36,VtGfrqbRudK = ppAJI9kDbz5MXa76UEF[0][1].rsplit('/',1)
			qaLFXuDExl8w = QIih0tfeVyBX2WTMGAR8L36+'?named=__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(qaLFXuDExl8w)
			XXup0CJWslMOqymaKthfb84 = ooZGMlYybF8aNfAOwps+VtGfrqbRudK
		else:
			xnGN2vER8iQqJkcFt4KWup = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,False,'ALARAB-PLAY-2nd')
			ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('"src": "(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if ZD5n0eJivzWOMxY98dgrumkwRG:
				ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]+'?named=__watch__m3u8'
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(ZD5n0eJivzWOMxY98dgrumkwRG)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('searchBox(.*?)<style>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if ZD5n0eJivzWOMxY98dgrumkwRG:
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]+'?named=__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(ZD5n0eJivzWOMxY98dgrumkwRG)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def y2u3FGPWw8jx():
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'ALARAB-RAMADAN-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="content_sec"(.*?)id="left_content"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	t5yED3dvMGs2YIZkLUAFRcQC1TBPS6 = jj0dZrgiKb.findall('/ramadan([0-9]+)/',str(items),jj0dZrgiKb.DOTALL)
	t5yED3dvMGs2YIZkLUAFRcQC1TBPS6 = t5yED3dvMGs2YIZkLUAFRcQC1TBPS6[0]
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		url = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)+UKFZBQAVXHI5s17LyvuRpCY2+t5yED3dvMGs2YIZkLUAFRcQC1TBPS6
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,11)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + "/q/" + LBqdVs9ioWwpMbCm1A
	RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	return