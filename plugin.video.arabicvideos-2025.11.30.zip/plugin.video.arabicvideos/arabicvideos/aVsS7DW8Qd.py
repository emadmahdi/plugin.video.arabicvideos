# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
wTLFCOcM26fmYlW7U = xm6jK1ZMuWq5(u"࠱ਫ਼")
UD4N8MjVTd = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠳੟")
Tb7oymMnpflsSv3eu4Pz2 = UD4N8MjVTd+UD4N8MjVTd
MMRBkhnWVJCQwU = Tb7oymMnpflsSv3eu4Pz2+UD4N8MjVTd
R9RNUT6WAPEYjHqtIokxuXs = MMRBkhnWVJCQwU+UD4N8MjVTd
ewJ9sTMmXtWH0ANVShQ2 = R9RNUT6WAPEYjHqtIokxuXs+UD4N8MjVTd
wUvcPrYDfISbZolAm83GKEqMyXkn5 = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࠪए")
UKFZBQAVXHI5s17LyvuRpCY2 = bQGafNLXyFgsZP6ut(u"ࠪࠤࠬऐ")
lB8tuyg6sxkDVYAaS95K3GI = UKFZBQAVXHI5s17LyvuRpCY2*Tb7oymMnpflsSv3eu4Pz2
DQCpAXVq6LHJ0aEFR = UKFZBQAVXHI5s17LyvuRpCY2*MMRBkhnWVJCQwU
fy2aLFcjDnoxIzGi1gp7 = UKFZBQAVXHI5s17LyvuRpCY2*R9RNUT6WAPEYjHqtIokxuXs
b02zsRFX8MweUniGfyPHEZcv7p5WK3 = None
y0yvdNOZkiKEg5RLMhoDVQAB9F2 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࡙ࡸࡵࡦ૮")
Z19pUxa2gfGMNKoDsEuytn85SjFvA = kPCxIUZb1V(u"ࡌࡡ࡭ࡵࡨ૯")
wekzmfMuLYaTUdVljQX6oB9IG = D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡹࡸࡵࡦࠩऑ")
uxig7mJanAYQ20 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
hbdwEgkQ6DLYV1TKuioHxyvj = TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
cc2JaqoYp8m = jQv0du1iVxTgAXCM(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
JegF7SlMawI03 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM = MFhbWia58mP3su0fk2d(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
FFzTCtAXg8jpl = MFhbWia58mP3su0fk2d(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
a31EWsDzRrIePGudLyJp4ZfYS = yRWQMHxZEz0(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
PtUz7CDanXZT = weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
AAByQSLgaZwCsKnvc5eWNmY = JHMxIE4fs1mvQtKW7R(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡶࡶࡩ࠼ࠬछ")
QMZ3cLnaCrFR1Aq = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
iYJabyEm07Fu15xqSWUhV = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
zWVDcOSsdJMU = yRWQMHxZEz0(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
SjUOalsknhyeYqI6Tf = TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
GZR3XQMO5J4N7tqEkSwFr6l9L1eb = erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡋࡒࡓࡑࡕࠫठ")
WW0AeIrS1dQyvqlnTzO8kaYFc = llkFwuCyhaP3sK76qO4T(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
QWLr8ABjev = MFhbWia58mP3su0fk2d(u"ࠧ࡝ࡰࠪढ")
o46hdHaXLqyFwzD = D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ࡞ࡵࠫण")
mvVFtPw8JKpaUdXq06YrEeR7bAk2 = xm6jK1ZMuWq5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
E1jhRWY8SLk = jQv0du1iVxTgAXCM(u"࠴੠")
xx1Qbw9ABV6IYrmHd0vptjElzPf = kPCxIUZb1V(u"࠴࠳࠻੡")
ggrwtFZBzDPHT26L1lu45x = erqDsJmL3BQHuGtPkcf0X9(u"࠶࠻੢")
MKTOd2VfL57 = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠹࠰੣")
fwvSley9oD1HsrjcPLZWYt4gTG = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠱࠱੤")
AxrKk7902DsRe4Vv3fWdwOYI = erqDsJmL3BQHuGtPkcf0X9(u"࠲࠴࠳੥")
wVd80JnRO7lLx421szgYiZtj = [
						 llkFwuCyhaP3sK76qO4T(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,jQv0du1iVxTgAXCM(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,jQv0du1iVxTgAXCM(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,Gj3rMP1Cb8wHdp49la0(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,JHMxIE4fs1mvQtKW7R(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,A6Sg45ChDR3BJLYfFH(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,jQv0du1iVxTgAXCM(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,jQv0du1iVxTgAXCM(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,w8JC1y7Lp3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
jGzLYDpMr2b = wVd80JnRO7lLx421szgYiZtj+[
				 D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,kPCxIUZb1V(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,kPCxIUZb1V(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,xdSThjYnuHXAU6M(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,jQv0du1iVxTgAXCM(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,JHMxIE4fs1mvQtKW7R(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,w8JC1y7Lp3(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
OS3ikB5hIzYw17 = [
						 D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,lCT8hfYUBX4OQMmL(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
ZwUoEtfGv7J6 = ewJ9sTMmXtWH0ANVShQ2
HiqZ1R8GXDtUzSu = [llkFwuCyhaP3sK76qO4T(u"ุࠩๅึ࠭े"),yRWQMHxZEz0(u"ࠪวํ๊ࠧै"),fmkZtbRj3ux(u"ࠫะอๆ๋ࠩॉ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬัวๅอࠪॊ"),xm6jK1ZMuWq5(u"࠭ัศส฼ࠫो"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠧฯษ่ืࠬौ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨีสำ्ุ࠭"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩึหอ฿ࠧॎ"),xm6jK1ZMuWq5(u"ࠪฯฬ๋ๆࠨॏ"),lCT8hfYUBX4OQMmL(u"ࠫฯอำฺࠩॐ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ฿วีำࠪ॑")]
ttUIgqH3Auk0R = xdSThjYnuHXAU6M(u"࠸࠳੦")
lEzbFoG5rDUpTHXWn0vkdBYAscPa1N = JHMxIE4fs1mvQtKW7R(u"࠹࠴੧")*ttUIgqH3Auk0R
X72TknicLshwJO8 = vvhR5ozeiJpANyl8fFO3GBw(u"࠶࠹੨")*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
oobqdEvDKn68SQ3XcCLjBfrOVU = w8JC1y7Lp3(u"࠸࠶੩")*X72TknicLshwJO8
CSjWJNDFL0Hl2IA9fYPtoB643TbZ = wTLFCOcM26fmYlW7U
BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X = D2PpKMeZFWrmfxTSs4L1tz(u"࠹࠰੪")*ttUIgqH3Auk0R
D0tF2C71Kej5zrAgB6uMJZsI = Tb7oymMnpflsSv3eu4Pz2*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
d2priEnu57KztRsm8wCHZ = TNw1pBHb8CtSZe0EFxuJqI(u"࠱࠷੫")*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
sBTeylAtiQXpFW9wjM5C1m = MMRBkhnWVJCQwU*X72TknicLshwJO8
CCuNYswqArnRpift4 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠴࠲੬")*X72TknicLshwJO8
pHC2Aj4kbc3KDN0aZWBey6QV = VhqD3zp7mUieI8sMQlETH(u"࠳࠵੭")*oobqdEvDKn68SQ3XcCLjBfrOVU
GAXY3gMCpfPZty2cnxUuQ = lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
IHZ5eQborO = [lCT8hfYUBX4OQMmL(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),xdSThjYnuHXAU6M(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),yRWQMHxZEz0(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),DpRJnas65uVcO0S17dYG(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
IHZ5eQborO += [lCT8hfYUBX4OQMmL(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),Gj3rMP1Cb8wHdp49la0(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),Gj3rMP1Cb8wHdp49la0(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
kjnif2XacmLr = [jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),yRWQMHxZEz0(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),Gj3rMP1Cb8wHdp49la0(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),lCT8hfYUBX4OQMmL(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
kjnif2XacmLr += [gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),rDG9dZoXRhCJcieUSF0KB(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),weh7SGmuTgXOVRcMo1rlLq(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
SguNQjdcrohbW5A7PRX0OVq6eiY3L = [JHMxIE4fs1mvQtKW7R(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),DpRJnas65uVcO0S17dYG(u"ࠫࡋࡕࡓࡕࡃࠪ६"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),Gj3rMP1Cb8wHdp49la0(u"࡙࠭ࡂࡓࡒࡘࠬ८"),Gj3rMP1Cb8wHdp49la0(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
SguNQjdcrohbW5A7PRX0OVq6eiY3L += [gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),xm6jK1ZMuWq5(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),A6Sg45ChDR3BJLYfFH(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),llkFwuCyhaP3sK76qO4T(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
SguNQjdcrohbW5A7PRX0OVq6eiY3L += [MFhbWia58mP3su0fk2d(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),rDG9dZoXRhCJcieUSF0KB(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),yRWQMHxZEz0(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),w8JC1y7Lp3(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
SguNQjdcrohbW5A7PRX0OVq6eiY3L += [rDG9dZoXRhCJcieUSF0KB(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),lCT8hfYUBX4OQMmL(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),kPCxIUZb1V(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),it4DKnryZlx(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),TNw1pBHb8CtSZe0EFxuJqI(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
SguNQjdcrohbW5A7PRX0OVq6eiY3L += [jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),llkFwuCyhaP3sK76qO4T(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),w8JC1y7Lp3(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),VhqD3zp7mUieI8sMQlETH(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),JHMxIE4fs1mvQtKW7R(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
vaOXiZlcKjhMW8 = [erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),Gj3rMP1Cb8wHdp49la0(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),yRWQMHxZEz0(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),JHMxIE4fs1mvQtKW7R(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
vaOXiZlcKjhMW8 += [kPCxIUZb1V(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),DpRJnas65uVcO0S17dYG(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),Gj3rMP1Cb8wHdp49la0(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),llkFwuCyhaP3sK76qO4T(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
W1bszKqEjom = [llkFwuCyhaP3sK76qO4T(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+IHZ5eQborO+[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+kjnif2XacmLr+[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+SguNQjdcrohbW5A7PRX0OVq6eiY3L+[fmkZtbRj3ux(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+vaOXiZlcKjhMW8
r7YJjh2EbIxu85PAl = [xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
LLR1FMdBpfEhmAbeuQo = [MFhbWia58mP3su0fk2d(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),jQv0du1iVxTgAXCM(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),VhqD3zp7mUieI8sMQlETH(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
XXtnS47x2AJlK1cjfRTsp6iOVwdL = [bQGafNLXyFgsZP6ut(u"ࠩࡐ࠷࡚࠭ঢ"),JHMxIE4fs1mvQtKW7R(u"ࠪࡍࡕ࡚ࡖࠨণ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡏࡆࡊࡎࡐࠫথ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
hRv5qzG9dNgbTxYo  = [pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),A6Sg45ChDR3BJLYfFH(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),it4DKnryZlx(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
hRv5qzG9dNgbTxYo += [ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
hRv5qzG9dNgbTxYo += [jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),DpRJnas65uVcO0S17dYG(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),A6Sg45ChDR3BJLYfFH(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
hRv5qzG9dNgbTxYo += [vWNRusF46D7Mi8GpZ(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),xm6jK1ZMuWq5(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),w8JC1y7Lp3(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
hRv5qzG9dNgbTxYo += [vWNRusF46D7Mi8GpZ(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),llkFwuCyhaP3sK76qO4T(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),xdSThjYnuHXAU6M(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
nBTf1QsFZh8eRJrGugqKkN2 = list(filter(lambda E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ: E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ not in hRv5qzG9dNgbTxYo+r7YJjh2EbIxu85PAl+LLR1FMdBpfEhmAbeuQo+XXtnS47x2AJlK1cjfRTsp6iOVwdL,W1bszKqEjom))
VVSuXlFIYdLxpCHJ54m = nBTf1QsFZh8eRJrGugqKkN2+XXtnS47x2AJlK1cjfRTsp6iOVwdL
CF1Ye02AfwbLgM48Vta = nBTf1QsFZh8eRJrGugqKkN2+hRv5qzG9dNgbTxYo
emNlqsvPnQAjwGHVyx2EXgaWMI7 = CF1Ye02AfwbLgM48Vta+r7YJjh2EbIxu85PAl
XIuPSfCzic = VVSuXlFIYdLxpCHJ54m+r7YJjh2EbIxu85PAl
T9YiNsnuHzr = [erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡄࡏࡔࡇࡍࠨষ"),w8JC1y7Lp3(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡎࡌࡉࡍࡏࠪহ"),A6Sg45ChDR3BJLYfFH(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),JHMxIE4fs1mvQtKW7R(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),kPCxIUZb1V(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),llkFwuCyhaP3sK76qO4T(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),kPCxIUZb1V(u"ࠫࡒ࠹ࡕࠨী"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡏࡐࡕࡘࠪু"),jQv0du1iVxTgAXCM(u"࠭ࡂࡐࡍࡕࡅࠬূ"),DpRJnas65uVcO0S17dYG(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [fmkZtbRj3ux(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),vWNRusF46D7Mi8GpZ(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),VhqD3zp7mUieI8sMQlETH(u"ࠫࡤࡏࡆࡍࡡࠪে"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),weh7SGmuTgXOVRcMo1rlLq(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),yRWQMHxZEz0(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),jQv0du1iVxTgAXCM(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),lCT8hfYUBX4OQMmL(u"ࠫࡤࡓࡕࠨৎ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡥࡉࡑࠩ৏"),jQv0du1iVxTgAXCM(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),xdSThjYnuHXAU6M(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
TLUyRm0JCaQBS7AFPp5qZM1r = [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),rDG9dZoXRhCJcieUSF0KB(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),DpRJnas65uVcO0S17dYG(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),Gj3rMP1Cb8wHdp49la0(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),xm6jK1ZMuWq5(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),DpRJnas65uVcO0S17dYG(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),MFhbWia58mP3su0fk2d(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
Ygqz6cREjpa = [wTLFCOcM26fmYlW7U,D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠹࠵੮"),vWNRusF46D7Mi8GpZ(u"࠵࠻࠶੽"),yRWQMHxZEz0(u"࠱࠸࠲઀"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠽࠵ੵ"),yRWQMHxZEz0(u"࠸࠶࠱੸"),rDG9dZoXRhCJcieUSF0KB(u"࠵࠼࠵੼"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠷࠸࠶੶"),w8JC1y7Lp3(u"࠳࠵࠲੹"),VhqD3zp7mUieI8sMQlETH(u"࠸࠶࠶੯"),MFhbWia58mP3su0fk2d(u"࠻࠰࠱੿"),erqDsJmL3BQHuGtPkcf0X9(u"࠷࠵࠴ੴ"),yRWQMHxZEz0(u"࠷࠶࠴੻"),erqDsJmL3BQHuGtPkcf0X9(u"࠺࠺࠰੷"),MFhbWia58mP3su0fk2d(u"࠼࠼࠰੾"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠲࠲࠴࠴ੳ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠹࠺࠻࠳ੲ"),Gj3rMP1Cb8wHdp49la0(u"࠶࠶࠲࠱ੰ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠷࠰࠹࠲ੱ"),fmkZtbRj3ux(u"࠲࠳࠳࠴੺")]
rmE8zBp0Zwc6hTY1DFKMiPfGVNuoRX = [fmkZtbRj3ux(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),vWNRusF46D7Mi8GpZ(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),llkFwuCyhaP3sK76qO4T(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),erqDsJmL3BQHuGtPkcf0X9(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),w8JC1y7Lp3(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),yRWQMHxZEz0(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ"),A6Sg45ChDR3BJLYfFH(u"ࠬ࠺࠴ࡧ࠶࠳࠼ࡩ࠺ࡡ࠳࡯ࡶ࡬࠶ࡨ࠳ࡣࡦ࠷࠽ࡦ࠼࠴࠹࠳࠺ࡪ࠺ࡶ࠱࠱࠳࠳࠷࡫ࡰࡳ࡯࠶ࡤ࠸࠶࠽ࡦࡤ࠷࠶࠴࠹࠸ࠧ৤"),Gj3rMP1Cb8wHdp49la0(u"࠭ࡢࡣ࠷࠶࠼࠶࠾࠰࠮࠷ࡧ࠵ࡦ࠳࠴ࡤ࠴࠹࠱ࡦࡨ࠶ࡣ࠯࠴࠺ࡧࡨ࠲࠵ࡤ࠹࠽ࡨ࠾ࡡ࠮࠲࠳࠱࠶ࡼ࠵࠺ࡣ࡫࠶࠺ࡷ࠱ࡢ࠸࠳ࠫ৥"),Gj3rMP1Cb8wHdp49la0(u"ࠧࡧ࠻ࡩ࠼࠶࠽࠷࠵࠯ࡤࡦ࠾࠾࠭࠵࠳ࡧ࠶࠲࠾࠷࠱ࡦ࠰࠺࠷࠻ࡢ࠹࠶࠹࠹࠷࠻࠳࠲࠯࠳࠴࠲࠷࡭ࡪࡥ࠷ࡨࡪࡲ࡬ࡨࡥࡥࡶࠬ০")]
u2DKCR1va3 = [yRWQMHxZEz0(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶࠫ১"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭২"),bQGafNLXyFgsZP6ut(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨ৩"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫ৪"),xm6jK1ZMuWq5(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧ৫"),kPCxIUZb1V(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰࠩ৬"),MFhbWia58mP3su0fk2d(u"ࠧࡳࡣࡳ࡭ࡩࡧࡰࡪ࠰ࡦࡳࡲ࠭৭"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡴࡨࡴࡱ࡯ࡴ࠯ࡦࡨࡺࠬ৮"),weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ৯")]
BILmjNSu4a60 = {
	 lCT8hfYUBX4OQMmL(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠶ࠧৰ")	: wTLFCOcM26fmYlW7U
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡆࡒࡁࡓࡃࡅࠫৱ")		: Gj3rMP1Cb8wHdp49la0(u"࠲࠲ઁ")
	,DpRJnas65uVcO0S17dYG(u"ࠬࡏࡆࡊࡎࡐࠫ৲")		: jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠴࠳ં")
	,fmkZtbRj3ux(u"࠭ࡐࡂࡐࡈࡘࠬ৳")		: pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠶࠴ઃ")
	,rDG9dZoXRhCJcieUSF0KB(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ৴")		: kPCxIUZb1V(u"࠸࠵઄")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ৵")		: weh7SGmuTgXOVRcMo1rlLq(u"࠺࠶અ")
	,w8JC1y7Lp3(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ৶")		: TNw1pBHb8CtSZe0EFxuJqI(u"࠼࠰આ")
	,weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡅࡐࡕࡁࡎࠩ৷")		: bQGafNLXyFgsZP6ut(u"࠷࠱ઇ")
	,A6Sg45ChDR3BJLYfFH(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭৸")		: bQGafNLXyFgsZP6ut(u"࠹࠲ઈ")
	,it4DKnryZlx(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ৹")		: it4DKnryZlx(u"࠻࠳ઉ")
	,yRWQMHxZEz0(u"࠭ࡌࡊࡘࡈࡘ࡛࠭৺")		: DpRJnas65uVcO0S17dYG(u"࠴࠴࠵ઊ")
	,vWNRusF46D7Mi8GpZ(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ৻")		: pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠵࠶࠶ઋ")
	,fmkZtbRj3ux(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩৼ")		: jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠶࠸࠰ઌ")
	,fmkZtbRj3ux(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ৽")	: s149dk8uh2p7oFzaLxZeI3Or(u"࠷࠳࠱ઍ")
	,kPCxIUZb1V(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ৾")		: vvhR5ozeiJpANyl8fFO3GBw(u"࠱࠵࠲઎")
	,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠱ࠨ৿")	: jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠲࠷࠳એ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡘࡁࡏࡆࡒࡑࡘࡥ࠰ࠨ਀")	: A6Sg45ChDR3BJLYfFH(u"࠳࠹࠴ઐ")
	,DpRJnas65uVcO0S17dYG(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠴ࠪਁ")	: Gj3rMP1Cb8wHdp49la0(u"࠴࠻࠵ઑ")
	,xm6jK1ZMuWq5(u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪਂ")	: xm6jK1ZMuWq5(u"࠵࠽࠶઒")
	,MFhbWia58mP3su0fk2d(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠷ࠬਃ")	: erqDsJmL3BQHuGtPkcf0X9(u"࠶࠿࠰ઓ")
	,DpRJnas65uVcO0S17dYG(u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ਄")		: VhqD3zp7mUieI8sMQlETH(u"࠸࠰࠱ઔ")
	,vWNRusF46D7Mi8GpZ(u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩਅ")	: vWNRusF46D7Mi8GpZ(u"࠲࠲࠲ક")
	,xm6jK1ZMuWq5(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨਆ")	: jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠳࠴࠳ખ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡏࡐࡕࡘࡢ࠴ࠬਇ")		: weh7SGmuTgXOVRcMo1rlLq(u"࠴࠶࠴ગ")
	,VhqD3zp7mUieI8sMQlETH(u"࠭ࡁࡌ࡙ࡄࡑࠬਈ")		: lCT8hfYUBX4OQMmL(u"࠵࠸࠵ઘ")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩਉ")		: vWNRusF46D7Mi8GpZ(u"࠶࠺࠶ઙ")
	,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡏࡈࡒ࡚࡙࡟࠱ࠩਊ")		: yRWQMHxZEz0(u"࠷࠼࠰ચ")
	,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡉࡅ࡛ࡕࡒࡊࡖࡈࡗࠬ਋")	: xdSThjYnuHXAU6M(u"࠸࠷࠱છ")
	,yRWQMHxZEz0(u"ࠪࡍࡕ࡚ࡖࡠ࠳ࠪ਌")		: TNw1pBHb8CtSZe0EFxuJqI(u"࠲࠹࠲જ")
	,vWNRusF46D7Mi8GpZ(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪ਍")	: gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠳࠻࠳ઝ")
	,JHMxIE4fs1mvQtKW7R(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭਎")		: rDG9dZoXRhCJcieUSF0KB(u"࠵࠳࠴ઞ")
	,rDG9dZoXRhCJcieUSF0KB(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩਏ")	: s149dk8uh2p7oFzaLxZeI3Or(u"࠶࠵࠵ટ")
	,w8JC1y7Lp3(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪਐ")	: xm6jK1ZMuWq5(u"࠷࠷࠶ઠ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ਑")		: erqDsJmL3BQHuGtPkcf0X9(u"࠸࠹࠰ડ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠹࠭਒")	: w8JC1y7Lp3(u"࠹࠴࠱ઢ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬਓ")		: jQv0du1iVxTgAXCM(u"࠳࠶࠲ણ")
	,lCT8hfYUBX4OQMmL(u"ࠫࡒ࡟ࡃࡊࡏࡄࠫਔ")		: SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠴࠸࠳ત")
	,DpRJnas65uVcO0S17dYG(u"ࠬࡈࡏࡌࡔࡄࠫਕ")		: rDG9dZoXRhCJcieUSF0KB(u"࠵࠺࠴થ")
	,kPCxIUZb1V(u"࠭ࡍࡐࡘࡖ࠸࡚࠭ਖ")		: SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠼࠵દ")
	,kPCxIUZb1V(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪਗ")	: weh7SGmuTgXOVRcMo1rlLq(u"࠷࠾࠶ધ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓࡥ࠰ࠨਘ"): it4DKnryZlx(u"࠹࠶࠰ન")
	,MFhbWia58mP3su0fk2d(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࡟࠲ࠩਙ"): kPCxIUZb1V(u"࠺࠱࠱઩")
	,xdSThjYnuHXAU6M(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪਚ")		: vWNRusF46D7Mi8GpZ(u"࠴࠳࠲પ")
	,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫਛ")		: SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵࠵࠳ફ")
	,fmkZtbRj3ux(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭ਜ")		: erqDsJmL3BQHuGtPkcf0X9(u"࠶࠷࠴બ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧਝ")		: pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠷࠹࠵ભ")
	,xm6jK1ZMuWq5(u"ࠧࡕࡘࡉ࡙ࡓ࠭ਞ")		: w8JC1y7Lp3(u"࠸࠻࠶મ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫਟ")	: erqDsJmL3BQHuGtPkcf0X9(u"࠹࠽࠰ય")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫਠ")		: jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠺࠸࠱ર")
	,MFhbWia58mP3su0fk2d(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬਡ")		: pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠴࠺࠲઱")
	,llkFwuCyhaP3sK76qO4T(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠵ࠨਢ")	: vvhR5ozeiJpANyl8fFO3GBw(u"࠶࠲࠳લ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࡟࠱ࠩਣ")	: erqDsJmL3BQHuGtPkcf0X9(u"࠷࠴࠴ળ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࡠ࠳ࠪਤ")	: dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠸࠶࠵઴")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡎࡇࡑ࡙ࡘࡥ࠱ࠨਥ")		: xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠹࠸࠶વ")
	,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎࠧਦ")	: MFhbWia58mP3su0fk2d(u"࠺࠺࠰શ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫਧ")		: vWNRusF46D7Mi8GpZ(u"࠻࠵࠱ષ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫਨ")		: ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠷࠲સ")
	,lCT8hfYUBX4OQMmL(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭਩")		: kPCxIUZb1V(u"࠶࠹࠳હ")
	,D2PpKMeZFWrmfxTSs4L1tz(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩਪ")	: VhqD3zp7mUieI8sMQlETH(u"࠷࠻࠴઺")
	,w8JC1y7Lp3(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨਫ")		: TNw1pBHb8CtSZe0EFxuJqI(u"࠸࠽࠵઻")
	,bQGafNLXyFgsZP6ut(u"ࠧࡇࡑࡖࡘࡆ࠭ਬ")		: Gj3rMP1Cb8wHdp49la0(u"࠺࠵࠶઼")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡃࡋ࡛ࡆࡑࠧਭ")		: jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠻࠷࠰ઽ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪਮ")		: lCT8hfYUBX4OQMmL(u"࠼࠲࠱ા")
	,A6Sg45ChDR3BJLYfFH(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩਯ")	: rDG9dZoXRhCJcieUSF0KB(u"࠶࠴࠲િ")
	,VhqD3zp7mUieI8sMQlETH(u"ࠫࡘࡎࡏࡇࡊࡄࠫਰ")		: ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠷࠶࠳ી")
	,yRWQMHxZEz0(u"ࠬࡈࡒࡔࡖࡈࡎࠬ਱")		: VhqD3zp7mUieI8sMQlETH(u"࠸࠸࠴ુ")
	,it4DKnryZlx(u"࡙࠭ࡂࡓࡒࡘࠬਲ")		: DpRJnas65uVcO0S17dYG(u"࠹࠺࠵ૂ")
	,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩਲ਼")		: lCT8hfYUBX4OQMmL(u"࠺࠼࠶ૃ")
	,llkFwuCyhaP3sK76qO4T(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ਴")		: ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠻࠾࠰ૄ")
	,Gj3rMP1Cb8wHdp49la0(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪਵ")		: SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠼࠹࠱ૅ")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪਸ਼")		: Gj3rMP1Cb8wHdp49la0(u"࠷࠱࠲૆")
	,A6Sg45ChDR3BJLYfFH(u"ࠫࡒ࠹ࡕࡠ࠲ࠪ਷")		: weh7SGmuTgXOVRcMo1rlLq(u"࠸࠳࠳ે")
	,xm6jK1ZMuWq5(u"ࠬࡓ࠳ࡖࡡ࠴ࠫਸ")		: xdSThjYnuHXAU6M(u"࠹࠵࠴ૈ")
	,D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫਹ")	: it4DKnryZlx(u"࠺࠷࠵ૉ")
	,lCT8hfYUBX4OQMmL(u"ࠧࡄࡎࡈࡅࡓࡋࡒࡠ࠲ࠪ਺")	: xm6jK1ZMuWq5(u"࠻࠹࠶૊")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠴ࠫ਻")	: llkFwuCyhaP3sK76qO4T(u"࠼࠻࠰ો")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡕࡅࡓࡊࡏࡎࡕࡢ࠵਼ࠬ")	: vWNRusF46D7Mi8GpZ(u"࠽࠶࠱ૌ")
	,it4DKnryZlx(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ਽")		: VhqD3zp7mUieI8sMQlETH(u"࠷࠸࠲્")
	,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ਾ")		: xm6jK1ZMuWq5(u"࠸࠺࠳૎")
	,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧਿ")		: erqDsJmL3BQHuGtPkcf0X9(u"࠹࠼࠴૏")
	,D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨੀ")		: llkFwuCyhaP3sK76qO4T(u"࠻࠴࠵ૐ")
	,xm6jK1ZMuWq5(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩੁ")		: lCT8hfYUBX4OQMmL(u"࠼࠶࠶૑")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪੂ")		: jQv0du1iVxTgAXCM(u"࠽࠸࠰૒")
	,A6Sg45ChDR3BJLYfFH(u"ࠩࡆࡍࡒࡇࡆࡓࡇࡈࠫ੃")		: A6Sg45ChDR3BJLYfFH(u"࠾࠳࠱૓")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬ੄")		: jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠸࠵࠲૔")
	,jQv0du1iVxTgAXCM(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧ੅")	: gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠹࠷࠳૕")
	,Gj3rMP1Cb8wHdp49la0(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭੆")		: jQv0du1iVxTgAXCM(u"࠺࠹࠴૖")
	,yRWQMHxZEz0(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ੇ")		: erqDsJmL3BQHuGtPkcf0X9(u"࠻࠻࠵૗")
	,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧੈ")		: pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠼࠽࠶૘")
	,VhqD3zp7mUieI8sMQlETH(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬ੉")	: rDG9dZoXRhCJcieUSF0KB(u"࠽࠿࠰૙")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧ੊")	: xm6jK1ZMuWq5(u"࠿࠰࠱૚")
	,A6Sg45ChDR3BJLYfFH(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬੋ")		: rDG9dZoXRhCJcieUSF0KB(u"࠹࠲࠲૛")
	,xdSThjYnuHXAU6M(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬੌ")		: vWNRusF46D7Mi8GpZ(u"࠺࠴࠳૜")
	,it4DKnryZlx(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨ੍")	: dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠻࠶࠴૝")
	,Gj3rMP1Cb8wHdp49la0(u"࠭ࡔࡊࡍࡄࡅ࡙࠭੎")		: xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠼࠸࠵૞")
	,xdSThjYnuHXAU6M(u"ࠧࡒࡈࡌࡐࡒ࠭੏")		: fmkZtbRj3ux(u"࠽࠺࠶૟")
	,fmkZtbRj3ux(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ੐")	: gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠾࠼࠰ૠ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫੑ")		: yRWQMHxZEz0(u"࠿࠷࠱ૡ")
	,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬ੒")		: llkFwuCyhaP3sK76qO4T(u"࠹࠹࠲ૢ")
	,A6Sg45ChDR3BJLYfFH(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬ੓")		: ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠺࠻࠳ૣ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭੔")		: xdSThjYnuHXAU6M(u"࠳࠳࠴࠵૤")
	,A6Sg45ChDR3BJLYfFH(u"࠭ࡇࡐࡑࡊࡐࡊ࡙ࡅࡂࡔࡆࡌࠬ੕")	: fmkZtbRj3ux(u"࠴࠴࠶࠶૥")
	,MFhbWia58mP3su0fk2d(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࡡ࠹ࠫ੖")	: dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠵࠵࠸࠰૦")
	,Gj3rMP1Cb8wHdp49la0(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬ੗")	: s149dk8uh2p7oFzaLxZeI3Or(u"࠶࠶࠳࠱૧")
	,jQv0du1iVxTgAXCM(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬ੘")	: xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠷࠰࠵࠲૨")
	,kPCxIUZb1V(u"ࠪࡅ࡞ࡒࡏࡍࠩਖ਼")		: weh7SGmuTgXOVRcMo1rlLq(u"࠱࠱࠷࠳૩")
	,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧਗ਼")	: lCT8hfYUBX4OQMmL(u"࠲࠲࠹࠴૪")
	,vWNRusF46D7Mi8GpZ(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭ਜ਼")		: DpRJnas65uVcO0S17dYG(u"࠳࠳࠻࠵૫")
	,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡃࡍࡇࡄࡒࡊࡘ࡟࠳ࠩੜ")	: D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠴࠽࠶૬")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪ੝")	: gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠵࠵࠿࠰૭")
}