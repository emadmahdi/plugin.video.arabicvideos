# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'YOUTUBE'
UT69hgqoKsWNIwM5zkAYb = '_YUT_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
BcpM5hSNtXTsvAOf8bL = 0
def DDIqhZaAit8Ed9(mode,url,text,type,sbNukjOf4chz,name,mnWZN7g50M):
	if	 mode==140: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==141: RCmHBOKtejQ8lu4L = U4naxGTBpduLJg(url,name,mnWZN7g50M)
	elif mode==143: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,type)
	elif mode==144: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,sbNukjOf4chz,text)
	elif mode==145: RCmHBOKtejQ8lu4L = bN4rRtByzUjaO(url,sbNukjOf4chz)
	elif mode==147: RCmHBOKtejQ8lu4L = vMpSfX6sBHuT0CeK41()
	elif mode==148: RCmHBOKtejQ8lu4L = wEFYfr1HgRNTZc3()
	elif mode==149: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	if 0:
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'قائمة 1',hhD7r1VvaPt3TC06SJjqKRfEid+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'قائمة 2',hhD7r1VvaPt3TC06SJjqKRfEid+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'شخص',hhD7r1VvaPt3TC06SJjqKRfEid+'/user/TCNofficial',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'موقع',hhD7r1VvaPt3TC06SJjqKRfEid+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'حساب',hhD7r1VvaPt3TC06SJjqKRfEid+'/@TheSocialCTV',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'العاب',hhD7r1VvaPt3TC06SJjqKRfEid+'/gaming',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'افلام',hhD7r1VvaPt3TC06SJjqKRfEid+'/feed/storefront',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مختارات',hhD7r1VvaPt3TC06SJjqKRfEid+'/feed/guide_builder',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'قصيرة',hhD7r1VvaPt3TC06SJjqKRfEid+'/shorts',144,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'تصفح',hhD7r1VvaPt3TC06SJjqKRfEid+'/youtubei/v1/guide?key=',144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'رئيسية',hhD7r1VvaPt3TC06SJjqKRfEid+wUvcPrYDfISbZolAm83GKEqMyXkn5,144)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'رائج',hhD7r1VvaPt3TC06SJjqKRfEid+'/feed/trending?bp=',144)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,149,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الرائجة',hhD7r1VvaPt3TC06SJjqKRfEid+'/feed/trending',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'التصفح',hhD7r1VvaPt3TC06SJjqKRfEid+'/youtubei/v1/guide?key=',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'القصيرة',hhD7r1VvaPt3TC06SJjqKRfEid+'/shorts',144,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مختارات يوتيوب',hhD7r1VvaPt3TC06SJjqKRfEid+'/feed/guide_builder',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مختارات البرنامج',wUvcPrYDfISbZolAm83GKEqMyXkn5,290)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: قنوات عربية',wUvcPrYDfISbZolAm83GKEqMyXkn5,147)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: قنوات أجنبية',wUvcPrYDfISbZolAm83GKEqMyXkn5,148)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: افلام عربية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=فيلم',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: افلام اجنبية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=movie',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: مسرحيات عربية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=مسرحية',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: مسلسلات عربية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: مسلسلات اجنبية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=series&sp=EgIQAw==',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: مسلسلات كارتون',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=كارتون&sp=EgIQAw==',144)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث: خطبة المرجعية',hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def U4naxGTBpduLJg(url,name,mnWZN7g50M):
	name = LPtVaw9ZF8ureCo(name)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'CHNL:  '+name,url,144,mnWZN7g50M)
	return
def vMpSfX6sBHuT0CeK41():
	HPdaS7kenW0m(hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def wEFYfr1HgRNTZc3():
	HPdaS7kenW0m(hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query=tv&sp=EgJAAQ==')
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,type):
	url = url.split('&',1)[0]
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy([url],UdbRGoKhcDeI4lVfns5,type,url)
	return
def aq4LNfRwkg1u0Fto8eijO3(r1o0R3jnX2Yvch8B,url,Q1OIedulYvrCpsfG3gLTbj6ci):
	level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = Q1OIedulYvrCpsfG3gLTbj6ci.split('::')
	BGNTEhDMLCZPyYRb5onJ,pM8DQa7zjvwE9nuV = [],[]
	if '/youtubei/v1/browse' in url: BGNTEhDMLCZPyYRb5onJ.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: BGNTEhDMLCZPyYRb5onJ.append("yccc['onResponseReceivedCommands']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': BGNTEhDMLCZPyYRb5onJ.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['entries']")
	BGNTEhDMLCZPyYRb5onJ.append("yccc['items'][3]['guideSectionRenderer']['items']")
	U8HzP60hbJpt5awNdZ3fxeVI9ovi,FBx4d8fc3wVPby0QNgSMm,XR7mcyxawef6QdzPkF02ogAuBY = PxSOpNw4WmcMn2fdQ(r1o0R3jnX2Yvch8B,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
	if level=='1' and U8HzP60hbJpt5awNdZ3fxeVI9ovi:
		if len(FBx4d8fc3wVPby0QNgSMm)>1 and 'search_query' not in url:
			for pC9k5livs2EWNqwFjReYbQZtuVI in range(len(FBx4d8fc3wVPby0QNgSMm)):
				KK6ngTQlewfJ9VEpA = str(pC9k5livs2EWNqwFjReYbQZtuVI)
				BGNTEhDMLCZPyYRb5onJ = []
				BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['reloadContinuationItemsCommand']['continuationItems']")
				BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['command']")
				BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]")
				n453i9Fwpc6bGMuUa2l,o4oW9wDcsrpHQS816yfIvg,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(FBx4d8fc3wVPby0QNgSMm,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
				if n453i9Fwpc6bGMuUa2l: pM8DQa7zjvwE9nuV.append([o4oW9wDcsrpHQS816yfIvg,url,'2::'+KK6ngTQlewfJ9VEpA+'::0::0'])
			BGNTEhDMLCZPyYRb5onJ.append("yccc['continuationEndpoint']")
			n453i9Fwpc6bGMuUa2l,o4oW9wDcsrpHQS816yfIvg,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(r1o0R3jnX2Yvch8B,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
			if n453i9Fwpc6bGMuUa2l and pM8DQa7zjvwE9nuV and 'continuationCommand' in list(o4oW9wDcsrpHQS816yfIvg.keys()):
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/my_main_page_shorts_link'
				pM8DQa7zjvwE9nuV.append([o4oW9wDcsrpHQS816yfIvg,hhEH1rcSP0z6Bkqy8OD,'1::0::0::0'])
	return FBx4d8fc3wVPby0QNgSMm,U8HzP60hbJpt5awNdZ3fxeVI9ovi,pM8DQa7zjvwE9nuV,XR7mcyxawef6QdzPkF02ogAuBY
def cSDgEvRaeFUKCIxoB(r1o0R3jnX2Yvch8B,FBx4d8fc3wVPby0QNgSMm,url,Q1OIedulYvrCpsfG3gLTbj6ci):
	level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = Q1OIedulYvrCpsfG3gLTbj6ci.split('::')
	BGNTEhDMLCZPyYRb5onJ,ucKkR1BfXg0zIixwFNUGjsvt = [],[]
	BGNTEhDMLCZPyYRb5onJ.append("yddd[0]['itemSectionRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['reloadContinuationItemsCommand']['continuationItems']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: BGNTEhDMLCZPyYRb5onJ.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: BGNTEhDMLCZPyYRb5onJ.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yddd["+KK6ngTQlewfJ9VEpA+"]")
	S7KL8ukNwh,ZkqFgJoVl0zdLAnQtDjUN3CE4b,iVcZ8Ps5QkRarbBI3gwAdjyTvfJqO = PxSOpNw4WmcMn2fdQ(FBx4d8fc3wVPby0QNgSMm,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
	if level=='2' and S7KL8ukNwh:
		if len(ZkqFgJoVl0zdLAnQtDjUN3CE4b)>1:
			for pC9k5livs2EWNqwFjReYbQZtuVI in range(len(ZkqFgJoVl0zdLAnQtDjUN3CE4b)):
				v2AM8Q9mrockG0tFJgKUXueRi = str(pC9k5livs2EWNqwFjReYbQZtuVI)
				BGNTEhDMLCZPyYRb5onJ = []
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['richSectionRenderer']['content']")
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]")
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['richItemRenderer']['content']")
				BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]")
				n453i9Fwpc6bGMuUa2l,o4oW9wDcsrpHQS816yfIvg,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(ZkqFgJoVl0zdLAnQtDjUN3CE4b,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
				if n453i9Fwpc6bGMuUa2l: ucKkR1BfXg0zIixwFNUGjsvt.append([o4oW9wDcsrpHQS816yfIvg,url,'3::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::0'])
			BGNTEhDMLCZPyYRb5onJ.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			BGNTEhDMLCZPyYRb5onJ.append("yddd[1]")
			n453i9Fwpc6bGMuUa2l,o4oW9wDcsrpHQS816yfIvg,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(FBx4d8fc3wVPby0QNgSMm,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
			if n453i9Fwpc6bGMuUa2l and ucKkR1BfXg0zIixwFNUGjsvt and 'continuationItemRenderer' in list(o4oW9wDcsrpHQS816yfIvg.keys()):
				ucKkR1BfXg0zIixwFNUGjsvt.append([o4oW9wDcsrpHQS816yfIvg,url,'3::0::0::0'])
	return ZkqFgJoVl0zdLAnQtDjUN3CE4b,S7KL8ukNwh,ucKkR1BfXg0zIixwFNUGjsvt,iVcZ8Ps5QkRarbBI3gwAdjyTvfJqO
def cCWLn2TgBbSZXUIiM9zopKhHQr(r1o0R3jnX2Yvch8B,ZkqFgJoVl0zdLAnQtDjUN3CE4b,url,Q1OIedulYvrCpsfG3gLTbj6ci):
	level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = Q1OIedulYvrCpsfG3gLTbj6ci.split('::')
	BGNTEhDMLCZPyYRb5onJ,H3HBSQEDeYMpIz8fsWaKFrRZw = [],[]
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['reelShelfRenderer']['items']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee["+v2AM8Q9mrockG0tFJgKUXueRi+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	BGNTEhDMLCZPyYRb5onJ.append("yeee")
	mJbSQAd40HiE8T2oZpKCWg,NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X,ppEoV4fMDL35nbtHCw7qRj1892TJ = PxSOpNw4WmcMn2fdQ(ZkqFgJoVl0zdLAnQtDjUN3CE4b,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
	if level=='3' and mJbSQAd40HiE8T2oZpKCWg:
		if len(NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X)>0:
			for pC9k5livs2EWNqwFjReYbQZtuVI in range(len(NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X)):
				Hx6tlRWVgdSUfYeEDn = str(pC9k5livs2EWNqwFjReYbQZtuVI)
				BGNTEhDMLCZPyYRb5onJ = []
				BGNTEhDMLCZPyYRb5onJ.append("yfff["+Hx6tlRWVgdSUfYeEDn+"]['richItemRenderer']['content']")
				BGNTEhDMLCZPyYRb5onJ.append("yfff["+Hx6tlRWVgdSUfYeEDn+"]['gameCardRenderer']['game']")
				BGNTEhDMLCZPyYRb5onJ.append("yfff["+Hx6tlRWVgdSUfYeEDn+"]['itemSectionRenderer']['contents'][0]")
				BGNTEhDMLCZPyYRb5onJ.append("yfff["+Hx6tlRWVgdSUfYeEDn+"]")
				BGNTEhDMLCZPyYRb5onJ.append("yfff")
				n453i9Fwpc6bGMuUa2l,o4oW9wDcsrpHQS816yfIvg,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X,wUvcPrYDfISbZolAm83GKEqMyXkn5,BGNTEhDMLCZPyYRb5onJ)
				if n453i9Fwpc6bGMuUa2l: H3HBSQEDeYMpIz8fsWaKFrRZw.append([o4oW9wDcsrpHQS816yfIvg,url,'4::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn])
	return NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X,mJbSQAd40HiE8T2oZpKCWg,H3HBSQEDeYMpIz8fsWaKFrRZw,ppEoV4fMDL35nbtHCw7qRj1892TJ
def PxSOpNw4WmcMn2fdQ(Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C,SSsdoaGIm2Z7WgVK):
	r1o0R3jnX2Yvch8B,oZkUpQhtGPKDNJdlImW9C = Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C
	FBx4d8fc3wVPby0QNgSMm,oZkUpQhtGPKDNJdlImW9C = Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C
	ZkqFgJoVl0zdLAnQtDjUN3CE4b,oZkUpQhtGPKDNJdlImW9C = Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C
	NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X,oZkUpQhtGPKDNJdlImW9C = Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C
	o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb = Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C
	count = len(SSsdoaGIm2Z7WgVK)
	for qbRmVByrJv18 in range(count):
		try:
			e18JKsfFclnNABQgiLMCP9qky0Sv = eval(SSsdoaGIm2Z7WgVK[qbRmVByrJv18])
			return True,e18JKsfFclnNABQgiLMCP9qky0Sv,qbRmVByrJv18+1
		except: pass
	return False,wUvcPrYDfISbZolAm83GKEqMyXkn5,0
def HPdaS7kenW0m(url,Q1OIedulYvrCpsfG3gLTbj6ci=wUvcPrYDfISbZolAm83GKEqMyXkn5,data=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	pM8DQa7zjvwE9nuV,ucKkR1BfXg0zIixwFNUGjsvt,H3HBSQEDeYMpIz8fsWaKFrRZw = [],[],[]
	if '::' not in Q1OIedulYvrCpsfG3gLTbj6ci: Q1OIedulYvrCpsfG3gLTbj6ci = '1::0::0::0'
	level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = Q1OIedulYvrCpsfG3gLTbj6ci.split('::')
	if level=='4': level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = '1',KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn
	data = data.replace('_REMEMBERRESULTS_',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	II64TLxj3mbqEyh9pHQ8oAv,r1o0R3jnX2Yvch8B,FjUcS938pAH5sZ = S6SDINXaQYjRT4GlytUA(url,data)
	Q1OIedulYvrCpsfG3gLTbj6ci = level+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
	if level in ['1','2','3']:
		FBx4d8fc3wVPby0QNgSMm,U8HzP60hbJpt5awNdZ3fxeVI9ovi,pM8DQa7zjvwE9nuV,XR7mcyxawef6QdzPkF02ogAuBY = aq4LNfRwkg1u0Fto8eijO3(r1o0R3jnX2Yvch8B,url,Q1OIedulYvrCpsfG3gLTbj6ci)
		if not U8HzP60hbJpt5awNdZ3fxeVI9ovi: return
		s9nZmJaMpD = len(pM8DQa7zjvwE9nuV)
		if s9nZmJaMpD<2:
			if level=='1': level = '2'
			pM8DQa7zjvwE9nuV = []
	Q1OIedulYvrCpsfG3gLTbj6ci = level+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
	if level in ['2','3']:
		ZkqFgJoVl0zdLAnQtDjUN3CE4b,S7KL8ukNwh,ucKkR1BfXg0zIixwFNUGjsvt,iVcZ8Ps5QkRarbBI3gwAdjyTvfJqO = cSDgEvRaeFUKCIxoB(r1o0R3jnX2Yvch8B,FBx4d8fc3wVPby0QNgSMm,url,Q1OIedulYvrCpsfG3gLTbj6ci)
		if not S7KL8ukNwh: return
		j0UKftS9kcuD = len(ucKkR1BfXg0zIixwFNUGjsvt)
		if j0UKftS9kcuD<2:
			if level=='2': level = '3'
			ucKkR1BfXg0zIixwFNUGjsvt = []
	Q1OIedulYvrCpsfG3gLTbj6ci = level+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
	if level in ['3']:
		NUJ5iex2zDCGW6Ipjuw0LAcYHnV7X,mJbSQAd40HiE8T2oZpKCWg,H3HBSQEDeYMpIz8fsWaKFrRZw,ppEoV4fMDL35nbtHCw7qRj1892TJ = cCWLn2TgBbSZXUIiM9zopKhHQr(r1o0R3jnX2Yvch8B,ZkqFgJoVl0zdLAnQtDjUN3CE4b,url,Q1OIedulYvrCpsfG3gLTbj6ci)
		if not mJbSQAd40HiE8T2oZpKCWg: return
		wCSec7fGsL4N0Ok = len(H3HBSQEDeYMpIz8fsWaKFrRZw)
	for o4oW9wDcsrpHQS816yfIvg,url,Q1OIedulYvrCpsfG3gLTbj6ci in pM8DQa7zjvwE9nuV+ucKkR1BfXg0zIixwFNUGjsvt+H3HBSQEDeYMpIz8fsWaKFrRZw:
		DvyB3Hri17aCIO84YtkQ = jjFiVm76dLgIK(o4oW9wDcsrpHQS816yfIvg,url,Q1OIedulYvrCpsfG3gLTbj6ci)
	return
def jjFiVm76dLgIK(o4oW9wDcsrpHQS816yfIvg,url=wUvcPrYDfISbZolAm83GKEqMyXkn5,Q1OIedulYvrCpsfG3gLTbj6ci=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if '::' in Q1OIedulYvrCpsfG3gLTbj6ci: level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = Q1OIedulYvrCpsfG3gLTbj6ci.split('::')
	else: level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = '1','0','0','0'
	n453i9Fwpc6bGMuUa2l,title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count,KS5UPc7G4x38Lp,t0CmgyHRATXnP,Mf4IYxtn0hSuZP2o17UKeVbTa,DZt0jKUERi = wNUVrP62imOzoQDfd30(o4oW9wDcsrpHQS816yfIvg)
	np1Yc4DiO8bwr = '/videos?' in hhEH1rcSP0z6Bkqy8OD or '/streams?' in hhEH1rcSP0z6Bkqy8OD or '/playlists?' in hhEH1rcSP0z6Bkqy8OD
	Z0p1FUhfAr2SQGJk7ae = '/channels?' in hhEH1rcSP0z6Bkqy8OD or '/shorts?' in hhEH1rcSP0z6Bkqy8OD
	if np1Yc4DiO8bwr or Z0p1FUhfAr2SQGJk7ae: hhEH1rcSP0z6Bkqy8OD = url
	np1Yc4DiO8bwr = 'watch?v=' not in hhEH1rcSP0z6Bkqy8OD and '/playlist?list=' not in hhEH1rcSP0z6Bkqy8OD
	Z0p1FUhfAr2SQGJk7ae = '/gaming' not in hhEH1rcSP0z6Bkqy8OD  and '/feed/storefront' not in hhEH1rcSP0z6Bkqy8OD
	if Q1OIedulYvrCpsfG3gLTbj6ci[0:5]=='3::0::' and np1Yc4DiO8bwr and Z0p1FUhfAr2SQGJk7ae: hhEH1rcSP0z6Bkqy8OD = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in hhEH1rcSP0z6Bkqy8OD:
		level,KK6ngTQlewfJ9VEpA,v2AM8Q9mrockG0tFJgKUXueRi,Hx6tlRWVgdSUfYeEDn = '1','0','0','0'
		Q1OIedulYvrCpsfG3gLTbj6ci = wUvcPrYDfISbZolAm83GKEqMyXkn5
	FjUcS938pAH5sZ = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if '/youtubei/v1/browse' in hhEH1rcSP0z6Bkqy8OD or '/youtubei/v1/search' in hhEH1rcSP0z6Bkqy8OD or '/my_main_page_shorts_link' in url:
		data = OOnvcPQy85HYA.getSetting('av.youtube.data')
		if data.count(':::')==4:
			ooQ8KIyXSPtEra,key,ggVKTQ2sm4JiuCle07xHprZtUhn,BBZOMVgFC0ioTsJEnI6ykNmd8Hw,wkKMJqu0VaeWm = data.split(':::')
			FjUcS938pAH5sZ = ooQ8KIyXSPtEra+':::'+key+':::'+ggVKTQ2sm4JiuCle07xHprZtUhn+':::'+BBZOMVgFC0ioTsJEnI6ykNmd8Hw+':::'+DZt0jKUERi
			if '/my_main_page_shorts_link' in url and not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = url
			else: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?key='+key
	if not title:
		global BcpM5hSNtXTsvAOf8bL
		BcpM5hSNtXTsvAOf8bL += 1
		title = 'فيديوهات '+str(BcpM5hSNtXTsvAOf8bL)
		Q1OIedulYvrCpsfG3gLTbj6ci = '3'+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
	if not n453i9Fwpc6bGMuUa2l: return False
	elif 'searchPyvRenderer' in str(o4oW9wDcsrpHQS816yfIvg): return False
	elif '/about' in hhEH1rcSP0z6Bkqy8OD: return False
	elif '/community' in hhEH1rcSP0z6Bkqy8OD: return False
	elif 'continuationItemRenderer' in list(o4oW9wDcsrpHQS816yfIvg.keys()) or 'continuationCommand' in list(o4oW9wDcsrpHQS816yfIvg.keys()):
		if int(level)>1: level = str(int(level)-1)
		Q1OIedulYvrCpsfG3gLTbj6ci = level+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: '+'صفحة أخرى',hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci,FjUcS938pAH5sZ)
	elif '/search' in hhEH1rcSP0z6Bkqy8OD:
		title = ':: '+title
		Q1OIedulYvrCpsfG3gLTbj6ci = '3'+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
		url = url.replace('/search',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,145,wUvcPrYDfISbZolAm83GKEqMyXkn5,Q1OIedulYvrCpsfG3gLTbj6ci,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not hhEH1rcSP0z6Bkqy8OD:
		Q1OIedulYvrCpsfG3gLTbj6ci = '3'+'::'+KK6ngTQlewfJ9VEpA+'::'+v2AM8Q9mrockG0tFJgKUXueRi+'::'+Hx6tlRWVgdSUfYeEDn
		title = ':: '+title
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci,FjUcS938pAH5sZ)
	elif '/browse' in hhEH1rcSP0z6Bkqy8OD and url==hhD7r1VvaPt3TC06SJjqKRfEid:
		title = ':: '+title
		Q1OIedulYvrCpsfG3gLTbj6ci = '2::0::0::0'
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci,FjUcS938pAH5sZ)
	elif not hhEH1rcSP0z6Bkqy8OD and 'horizontalMovieListRenderer' in str(o4oW9wDcsrpHQS816yfIvg):
		title = ':: '+title
		Q1OIedulYvrCpsfG3gLTbj6ci = '3::0::0::0'
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci)
	elif 'messageRenderer' in str(o4oW9wDcsrpHQS816yfIvg):
		mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	elif t0CmgyHRATXnP:
		mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+t0CmgyHRATXnP+title,hhEH1rcSP0z6Bkqy8OD,143,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	elif '/playlist?list=' in hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('&playnext=1',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'LIST'+count+':  '+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci)
	elif '/shorts/' in hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('&list=',1)[0]
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,143,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
	elif '/watch?v=' in hhEH1rcSP0z6Bkqy8OD:
		if '&list=' in hhEH1rcSP0z6Bkqy8OD and count:
			vvZpe8F2YhmTKkGAPQJzHj1S4 = hhEH1rcSP0z6Bkqy8OD.split('&list=',1)[1]
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/playlist?list='+vvZpe8F2YhmTKkGAPQJzHj1S4
			Q1OIedulYvrCpsfG3gLTbj6ci = '1::0::0::0'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'LIST'+count+':  '+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci)
		else:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('&list=',1)[0]
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,143,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
	elif '/channel/' in hhEH1rcSP0z6Bkqy8OD or '/c/' in hhEH1rcSP0z6Bkqy8OD or ('/@' in hhEH1rcSP0z6Bkqy8OD and hhEH1rcSP0z6Bkqy8OD.count('/')==3):
		if ndib93Ol6UojCrEV:
			title = title.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode('raw_unicode_escape')
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'CHNL'+count+':  '+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci)
	elif '/user/' in hhEH1rcSP0z6Bkqy8OD:
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'USER'+count+':  '+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci)
	else:
		if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = url
		title = ':: '+title
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,144,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Q1OIedulYvrCpsfG3gLTbj6ci,FjUcS938pAH5sZ)
	return True
def wNUVrP62imOzoQDfd30(o4oW9wDcsrpHQS816yfIvg):
	n453i9Fwpc6bGMuUa2l,title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count,KS5UPc7G4x38Lp,t0CmgyHRATXnP,Mf4IYxtn0hSuZP2o17UKeVbTa,wkKMJqu0VaeWm = False,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not isinstance(o4oW9wDcsrpHQS816yfIvg,dict): return n453i9Fwpc6bGMuUa2l,title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count,KS5UPc7G4x38Lp,t0CmgyHRATXnP,Mf4IYxtn0hSuZP2o17UKeVbTa,wkKMJqu0VaeWm
	for xrbwQuv9hUkCWiY6IA in list(o4oW9wDcsrpHQS816yfIvg.keys()):
		dhuKOzEoHByw1J75A9LWlNSVpkjb = o4oW9wDcsrpHQS816yfIvg[xrbwQuv9hUkCWiY6IA]
		if isinstance(dhuKOzEoHByw1J75A9LWlNSVpkjb,dict): break
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['header']['richListHeaderRenderer']['title']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['headline']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['unplayableText']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['formattedTitle']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['title']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['title']['runs'][0]['text']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['text']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['text']['runs'][0]['text']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['title']['content']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['title']")
	BGNTEhDMLCZPyYRb5onJ.append("item['title']")
	BGNTEhDMLCZPyYRb5onJ.append("item['reelWatchEndpoint']['videoId']")
	n453i9Fwpc6bGMuUa2l,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	BGNTEhDMLCZPyYRb5onJ.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	BGNTEhDMLCZPyYRb5onJ.append("item['commandMetadata']['webCommandMetadata']['url']")
	n453i9Fwpc6bGMuUa2l,hhEH1rcSP0z6Bkqy8OD,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnail']['thumbnails'][0]['url']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	BGNTEhDMLCZPyYRb5onJ.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	n453i9Fwpc6bGMuUa2l,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['videoCountShortText']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['videoCountText']['runs'][0]['text']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['videoCount']")
	n453i9Fwpc6bGMuUa2l,count,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['lengthText']['simpleText']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	n453i9Fwpc6bGMuUa2l,KS5UPc7G4x38Lp,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	BGNTEhDMLCZPyYRb5onJ = []
	BGNTEhDMLCZPyYRb5onJ.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	BGNTEhDMLCZPyYRb5onJ.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	n453i9Fwpc6bGMuUa2l,wkKMJqu0VaeWm,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = PxSOpNw4WmcMn2fdQ(o4oW9wDcsrpHQS816yfIvg,dhuKOzEoHByw1J75A9LWlNSVpkjb,BGNTEhDMLCZPyYRb5onJ)
	if 'LIVE' in KS5UPc7G4x38Lp: KS5UPc7G4x38Lp,t0CmgyHRATXnP = wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVE:  '
	if 'مباشر' in KS5UPc7G4x38Lp: KS5UPc7G4x38Lp,t0CmgyHRATXnP = wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVE:  '
	if 'badges' in list(dhuKOzEoHByw1J75A9LWlNSVpkjb.keys()):
		U2xeja0TZqMQ4 = str(dhuKOzEoHByw1J75A9LWlNSVpkjb['badges'])
		if 'Free with Ads' in U2xeja0TZqMQ4: Mf4IYxtn0hSuZP2o17UKeVbTa = '$:  '
		if 'LIVE' in U2xeja0TZqMQ4: t0CmgyHRATXnP = 'LIVE:  '
		if 'Buy' in U2xeja0TZqMQ4 or 'Rent' in U2xeja0TZqMQ4: Mf4IYxtn0hSuZP2o17UKeVbTa = '$$:  '
		if rg5W67jZQdSPH0(u'مباشر') in U2xeja0TZqMQ4: t0CmgyHRATXnP = 'LIVE:  '
		if rg5W67jZQdSPH0(u'شراء') in U2xeja0TZqMQ4: Mf4IYxtn0hSuZP2o17UKeVbTa = '$$:  '
		if rg5W67jZQdSPH0(u'استئجار') in U2xeja0TZqMQ4: Mf4IYxtn0hSuZP2o17UKeVbTa = '$$:  '
		if rg5W67jZQdSPH0(u'إعلانات') in U2xeja0TZqMQ4: Mf4IYxtn0hSuZP2o17UKeVbTa = '$:  '
	hhEH1rcSP0z6Bkqy8OD = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(hhEH1rcSP0z6Bkqy8OD)
	if hhEH1rcSP0z6Bkqy8OD and 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.split('?')[0]
	if  cPzpeLXs3jMCltW4ZN9BaYdfQvwS and 'http' not in cPzpeLXs3jMCltW4ZN9BaYdfQvwS: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = 'https:'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
	title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
	if Mf4IYxtn0hSuZP2o17UKeVbTa: title = Mf4IYxtn0hSuZP2o17UKeVbTa+title
	KS5UPc7G4x38Lp = KS5UPc7G4x38Lp.replace(',',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	count = count.replace(',',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	count = jj0dZrgiKb.findall('\d+',count)
	if count: count = count[0]
	else: count = wUvcPrYDfISbZolAm83GKEqMyXkn5
	return True,title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count,KS5UPc7G4x38Lp,t0CmgyHRATXnP,Mf4IYxtn0hSuZP2o17UKeVbTa,wkKMJqu0VaeWm
def S6SDINXaQYjRT4GlytUA(url,data=wUvcPrYDfISbZolAm83GKEqMyXkn5,ySY5NxERP6jeVG=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if ySY5NxERP6jeVG==wUvcPrYDfISbZolAm83GKEqMyXkn5: ySY5NxERP6jeVG = 'ytInitialData'
	vpHXP3E6Kt = ZZIDf1A9vE0g86RMq7tpKUrzaij()
	XubVRNO48BsjJASlmeKwdTCr = {'User-Agent':vpHXP3E6Kt,'Cookie':'PREF=hl=ar'}
	global OOnvcPQy85HYA
	if not data: data = OOnvcPQy85HYA.getSetting('av.youtube.data')
	if data.count(':::')==4: ooQ8KIyXSPtEra,key,ggVKTQ2sm4JiuCle07xHprZtUhn,BBZOMVgFC0ioTsJEnI6ykNmd8Hw,wkKMJqu0VaeWm = data.split(':::')
	else: ooQ8KIyXSPtEra,key,ggVKTQ2sm4JiuCle07xHprZtUhn,BBZOMVgFC0ioTsJEnI6ykNmd8Hw,wkKMJqu0VaeWm = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	FjUcS938pAH5sZ = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":ggVKTQ2sm4JiuCle07xHprZtUhn}}}
	if url==hhD7r1VvaPt3TC06SJjqKRfEid+'/shorts' or '/my_main_page_shorts_link' in url:
		url = hhD7r1VvaPt3TC06SJjqKRfEid+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		FjUcS938pAH5sZ['sequenceParams'] = ooQ8KIyXSPtEra
		FjUcS938pAH5sZ = str(FjUcS938pAH5sZ)
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',url,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = hhD7r1VvaPt3TC06SJjqKRfEid+'/youtubei/v1/guide?key='+key
		FjUcS938pAH5sZ = str(FjUcS938pAH5sZ)
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',url,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and ooQ8KIyXSPtEra:
		FjUcS938pAH5sZ['continuation'] = wkKMJqu0VaeWm
		FjUcS938pAH5sZ['context']['client']['visitorData'] = ooQ8KIyXSPtEra
		FjUcS938pAH5sZ = str(FjUcS938pAH5sZ)
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',url,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and BBZOMVgFC0ioTsJEnI6ykNmd8Hw:
		XubVRNO48BsjJASlmeKwdTCr.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':ggVKTQ2sm4JiuCle07xHprZtUhn})
		XubVRNO48BsjJASlmeKwdTCr.update({'Cookie':'VISITOR_INFO1_LIVE='+BBZOMVgFC0ioTsJEnI6ykNmd8Hw})
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'YOUTUBE-GET_PAGE_DATA-6th')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('"innertubeApiKey".*?"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.I)
	if kdJDcbM5FWUAgBs: key = kdJDcbM5FWUAgBs[0]
	kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('"cver".*?"value".*?"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.I)
	if kdJDcbM5FWUAgBs: ggVKTQ2sm4JiuCle07xHprZtUhn = kdJDcbM5FWUAgBs[0]
	kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('"visitorData".*?"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.I)
	if kdJDcbM5FWUAgBs: ooQ8KIyXSPtEra = kdJDcbM5FWUAgBs[0]
	cookies = QM9sJ7tk0oplqEwHU3DjL64d.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): BBZOMVgFC0ioTsJEnI6ykNmd8Hw = cookies['VISITOR_INFO1_LIVE']
	F148a7xNcp9C = ooQ8KIyXSPtEra+':::'+key+':::'+ggVKTQ2sm4JiuCle07xHprZtUhn+':::'+BBZOMVgFC0ioTsJEnI6ykNmd8Hw+':::'+wkKMJqu0VaeWm
	if ySY5NxERP6jeVG=='ytInitialData' and 'ytInitialData' in II64TLxj3mbqEyh9pHQ8oAv:
		DX0eijvnRQxBH = jj0dZrgiKb.findall('window\["ytInitialData"\] = ({.*?});',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not DX0eijvnRQxBH: DX0eijvnRQxBH = jj0dZrgiKb.findall('var ytInitialData = ({.*?});',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		pXVtZu672lFHAGPvcTMJ3ryU9z = dm7KA8MukvxF3iH9CW2ZNc('str',DX0eijvnRQxBH[0])
	elif ySY5NxERP6jeVG=='ytInitialGuideData' and 'ytInitialGuideData' in II64TLxj3mbqEyh9pHQ8oAv:
		DX0eijvnRQxBH = jj0dZrgiKb.findall('var ytInitialGuideData = ({.*?});',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		pXVtZu672lFHAGPvcTMJ3ryU9z = dm7KA8MukvxF3iH9CW2ZNc('str',DX0eijvnRQxBH[0])
	elif '</script>' not in II64TLxj3mbqEyh9pHQ8oAv: pXVtZu672lFHAGPvcTMJ3ryU9z = dm7KA8MukvxF3iH9CW2ZNc('str',II64TLxj3mbqEyh9pHQ8oAv)
	else: pXVtZu672lFHAGPvcTMJ3ryU9z = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if 0:
		r1o0R3jnX2Yvch8B = str(pXVtZu672lFHAGPvcTMJ3ryU9z)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: r1o0R3jnX2Yvch8B = r1o0R3jnX2Yvch8B.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open('S:\\0000emad.dat','wb').write(r1o0R3jnX2Yvch8B)
	OOnvcPQy85HYA.setSetting('av.youtube.data',F148a7xNcp9C)
	return II64TLxj3mbqEyh9pHQ8oAv,pXVtZu672lFHAGPvcTMJ3ryU9z,F148a7xNcp9C
def bN4rRtByzUjaO(url,Q1OIedulYvrCpsfG3gLTbj6ci):
	search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if not search: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	ZD5n0eJivzWOMxY98dgrumkwRG = url+'/search?query='+search
	HPdaS7kenW0m(ZD5n0eJivzWOMxY98dgrumkwRG,Q1OIedulYvrCpsfG3gLTbj6ci)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in plQAPdho26aj: fjIqC0kcyKSQbJeRDOhaEX = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in plQAPdho26aj: fjIqC0kcyKSQbJeRDOhaEX = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in plQAPdho26aj: fjIqC0kcyKSQbJeRDOhaEX = '&sp=EgIQAg%253D%253D'
		else: fjIqC0kcyKSQbJeRDOhaEX = wUvcPrYDfISbZolAm83GKEqMyXkn5
		qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG+fjIqC0kcyKSQbJeRDOhaEX
	else:
		MI3biNoVlGd0qk,sKgQ4UkEBliMRSePv9,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = [],[],wUvcPrYDfISbZolAm83GKEqMyXkn5
		BdL5JEWw4ig0AHmDszvanQ9fCqFoY = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		M713rCLAkSj5vmQRsw = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		NoTAdq7fG8PWBsYxlzvXEbQDjpia2 = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر البحث المناسب',BdL5JEWw4ig0AHmDszvanQ9fCqFoY)
		if NoTAdq7fG8PWBsYxlzvXEbQDjpia2 == -1: return
		mSMpI4GckPuTfydEqlj3bWA = M713rCLAkSj5vmQRsw[NoTAdq7fG8PWBsYxlzvXEbQDjpia2]
		II64TLxj3mbqEyh9pHQ8oAv,frEPWnbh7SMacU4z5Y,data = S6SDINXaQYjRT4GlytUA(ZD5n0eJivzWOMxY98dgrumkwRG+mSMpI4GckPuTfydEqlj3bWA)
		if frEPWnbh7SMacU4z5Y:
			try:
				aKY2A9PnoFg4usizU5QhCD = frEPWnbh7SMacU4z5Y['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for YbusDqrVN9S3B4FeLTP8O in range(len(aKY2A9PnoFg4usizU5QhCD)):
					group = aKY2A9PnoFg4usizU5QhCD[YbusDqrVN9S3B4FeLTP8O]['searchFilterGroupRenderer']['filters']
					for MmEBfaTlPZkqgx63NsV2 in range(len(group)):
						dhuKOzEoHByw1J75A9LWlNSVpkjb = group[MmEBfaTlPZkqgx63NsV2]['searchFilterRenderer']
						if 'navigationEndpoint' in list(dhuKOzEoHByw1J75A9LWlNSVpkjb.keys()):
							hhEH1rcSP0z6Bkqy8OD = dhuKOzEoHByw1J75A9LWlNSVpkjb['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('\u0026','&')
							title = dhuKOzEoHByw1J75A9LWlNSVpkjb['tooltip']
							title = title.replace('البحث عن ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = title
								q4zyW5Bpx6Y2O = hhEH1rcSP0z6Bkqy8OD
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = title
								q4zyW5Bpx6Y2O = hhEH1rcSP0z6Bkqy8OD
							if 'Sort by' in title: continue
							MI3biNoVlGd0qk.append(aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title))
							sKgQ4UkEBliMRSePv9.append(hhEH1rcSP0z6Bkqy8OD)
			except: pass
		if not HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ: ARez3w9M1pvL0PY65fHT = wUvcPrYDfISbZolAm83GKEqMyXkn5
		else:
			MI3biNoVlGd0qk = ['بدون فلتر',HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ]+MI3biNoVlGd0qk
			sKgQ4UkEBliMRSePv9 = [wUvcPrYDfISbZolAm83GKEqMyXkn5,q4zyW5Bpx6Y2O]+sKgQ4UkEBliMRSePv9
			BlvSYOzqNiHZF = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('موقع يوتيوب - اختر الفلتر',MI3biNoVlGd0qk)
			if BlvSYOzqNiHZF == -1: return
			ARez3w9M1pvL0PY65fHT = sKgQ4UkEBliMRSePv9[BlvSYOzqNiHZF]
		if ARez3w9M1pvL0PY65fHT: qaLFXuDExl8w = hhD7r1VvaPt3TC06SJjqKRfEid+ARez3w9M1pvL0PY65fHT
		elif mSMpI4GckPuTfydEqlj3bWA: qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG+mSMpI4GckPuTfydEqlj3bWA
		else: qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG
	HPdaS7kenW0m(qaLFXuDExl8w)
	return