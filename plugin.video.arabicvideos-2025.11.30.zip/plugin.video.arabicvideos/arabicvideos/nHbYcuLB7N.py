# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'CIMANOW'
UT69hgqoKsWNIwM5zkAYb = '_CMN_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['قائمتي']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==300: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==301: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==302: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	elif mode==303: RCmHBOKtejQ8lu4L = g06Afm3rzVEbdBPvDnSkQq(url)
	elif mode==304: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==305: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==306: RCmHBOKtejQ8lu4L = Hp2NzF754Mxb1LhBJ()
	elif mode==309: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,309,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid+'/home',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<header(.*?)</header>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('<li><a href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,301)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	FFJX0sguE92DxYGmoQAeV(hhD7r1VvaPt3TC06SJjqKRfEid+'/home',II64TLxj3mbqEyh9pHQ8oAv)
	return II64TLxj3mbqEyh9pHQ8oAv
def Hp2NzF754Mxb1LhBJ():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def FFJX0sguE92DxYGmoQAeV(url,II64TLxj3mbqEyh9pHQ8oAv=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not II64TLxj3mbqEyh9pHQ8oAv:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-SUBMENU-1st')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = 0
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<section>.*?</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 += 1
		items = jj0dZrgiKb.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for title,hIQiXzjbsRUgO6qawvxCA,hhEH1rcSP0z6Bkqy8OD in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if title==wUvcPrYDfISbZolAm83GKEqMyXkn5: title = 'بووووو'
			if 'em><a' not in hIQiXzjbsRUgO6qawvxCA:
				if IJE2xcV7OWauUKhfik56gXBwltCb.count('/category/')>0:
					jueS3k8RGHrMdIK = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
					for hhEH1rcSP0z6Bkqy8OD in jueS3k8RGHrMdIK:
						title = hhEH1rcSP0z6Bkqy8OD.split('/')[-2]
						mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,301)
					continue
				else: hhEH1rcSP0z6Bkqy8OD = url+'?sequence='+str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)
			if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,302)
	if not pLHIPUY3TWAeE70: HPdaS7kenW0m(url,II64TLxj3mbqEyh9pHQ8oAv)
	return
def HPdaS7kenW0m(url,II64TLxj3mbqEyh9pHQ8oAv=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if II64TLxj3mbqEyh9pHQ8oAv==wUvcPrYDfISbZolAm83GKEqMyXkn5:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-TITLES-1st')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if '?sequence=' in url:
		url,xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = url.split('?sequence=')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(<section>.*?</section>)',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[int(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)-1]
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"posts"(.*?)</body>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for hhEH1rcSP0z6Bkqy8OD,data,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
		title = jj0dZrgiKb.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,jj0dZrgiKb.DOTALL)
		if title: title = title[0][2].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not title or title==wUvcPrYDfISbZolAm83GKEqMyXkn5:
			title = jj0dZrgiKb.findall('title">.*?</em>(.*?)<',data,jj0dZrgiKb.DOTALL)
			if title: title = title[0].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if not title or title==wUvcPrYDfISbZolAm83GKEqMyXkn5:
				title = jj0dZrgiKb.findall('title">(.*?)<',data,jj0dZrgiKb.DOTALL)
				title = title[0].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		title = title.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
			v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			i9eu0gvptXjKMAczZyE = hhEH1rcSP0z6Bkqy8OD+data+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			if '/selary/' in i9eu0gvptXjKMAczZyE or 'مسلسل' in i9eu0gvptXjKMAczZyE or '"episode"' in i9eu0gvptXjKMAczZyE:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,303,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,305,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('<li><a href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,302)
	return
def g06Afm3rzVEbdBPvDnSkQq(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-SEASONS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	name = jj0dZrgiKb.findall('<title>(.*?)</title>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('Cima Now',wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		name = name.split('الحلقة')[0].strip(UKFZBQAVXHI5s17LyvuRpCY2)+' - '
	else: name = wUvcPrYDfISbZolAm83GKEqMyXkn5
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<section(.*?)</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if len(items)>1:
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = name+title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,304)
		elif len(items)==1:
			hhEH1rcSP0z6Bkqy8OD,title = items[0]
			mCwqRg7HpivAQ6S(hhEH1rcSP0z6Bkqy8OD)
		else: mCwqRg7HpivAQ6S(url)
	return
def mCwqRg7HpivAQ6S(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if '/selary/' not in url:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"episodes"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			title = 'الحلقة '+title
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,305)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"details"(.*?)"related"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,305,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	ichD94yVFEu = jj0dZrgiKb.findall('class="shine" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ichD94yVFEu:
		xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(ichD94yVFEu[0],'url')
		headers = {'Referer':xG6n4Wq2Ib7YgpiarHUNLQJM0}
	else: headers = wUvcPrYDfISbZolAm83GKEqMyXkn5
	ZD5n0eJivzWOMxY98dgrumkwRG = url+'watching/'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMANOW-PLAY-5th')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"download"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?</i>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			KwSdzRXT0M3VW = jj0dZrgiKb.findall('\d\d\d+',title,jj0dZrgiKb.DOTALL)
			if KwSdzRXT0M3VW:
				KwSdzRXT0M3VW = '____'+KwSdzRXT0M3VW[0]
				title = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
			else: KwSdzRXT0M3VW = wUvcPrYDfISbZolAm83GKEqMyXkn5
			q4zyW5Bpx6Y2O = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'+KwSdzRXT0M3VW
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(q4zyW5Bpx6Y2O)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"watch"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('"embed".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
			title = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__embed'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		ppAJI9kDbz5MXa76UEF = [hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-content/themes/Cima%20Now%20New/core.php']
		if ppAJI9kDbz5MXa76UEF:
			items = jj0dZrgiKb.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for Q1OIedulYvrCpsfG3gLTbj6ci,id,title in items:
				title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				hhEH1rcSP0z6Bkqy8OD = ppAJI9kDbz5MXa76UEF[0]+'?action=switch&index='+Q1OIedulYvrCpsfG3gLTbj6ci+'&id='+id+'?named='+title+'__watch'
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/?s='+search
	HPdaS7kenW0m(url)
	return