# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'KATKOTTV'
UT69hgqoKsWNIwM5zkAYb = '_KTV_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = []
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==810: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==811: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==812: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==813: RCmHBOKtejQ8lu4L = ymR58kPWbDiQ(url)
	elif mode==819: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'KATKOTTV-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,819,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"primary-links"(.*?)"most-viewed"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,811)
	return
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'KATKOTTV-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"home-content"(.*?)"footer"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
			if 'episodes' not in type and xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
				title = title.replace('اون لاين',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,813,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,812,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("'pagination'(.*?)footer",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,811,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def ymR58kPWbDiQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'KATKOTTV-SERIES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"category".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD: HPdaS7kenW0m(hhEH1rcSP0z6Bkqy8OD[0],'episodes')
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	ZD5n0eJivzWOMxY98dgrumkwRG = url+'?do=watch'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'KATKOTTV-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('" src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'KATKOTTV-PLAY-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		dHRIVxWSDFQOajpZ7mflrsToY = jj0dZrgiKb.findall('post=(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if dHRIVxWSDFQOajpZ7mflrsToY:
			dHRIVxWSDFQOajpZ7mflrsToY = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(dHRIVxWSDFQOajpZ7mflrsToY[0])
			if wwMdFkWvcRYiXHB7yDrCqnKb98o: dHRIVxWSDFQOajpZ7mflrsToY = dHRIVxWSDFQOajpZ7mflrsToY.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			dHRIVxWSDFQOajpZ7mflrsToY = dm7KA8MukvxF3iH9CW2ZNc('dict',dHRIVxWSDFQOajpZ7mflrsToY)
			ppAJI9kDbz5MXa76UEF = dHRIVxWSDFQOajpZ7mflrsToY['servers']
			kDp3Tb6EBW = list(ppAJI9kDbz5MXa76UEF.keys())
			ppAJI9kDbz5MXa76UEF = list(ppAJI9kDbz5MXa76UEF.values())
			JIO9qPGcfs76XSU0KCh1 = zip(kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF)
			for title,hhEH1rcSP0z6Bkqy8OD in JIO9qPGcfs76XSU0KCh1:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(url,'search')
	return