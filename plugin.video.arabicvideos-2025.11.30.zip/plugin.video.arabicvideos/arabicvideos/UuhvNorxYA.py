# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'ALFATIMI'
UT69hgqoKsWNIwM5zkAYb = '_FTM_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
MltBkX4rOI6iLZh = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
kIURJFzixdW = ['3030','628']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==60: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==61: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==62: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==63: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==64: RCmHBOKtejQ8lu4L = PK9aQ25YEiXDvh(text)
	elif mode==69: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,69,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'ما يتم مشاهدته الان',hhD7r1VvaPt3TC06SJjqKRfEid,64,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'recent_viewed_vids')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الاكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid,64,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'most_viewed_vids')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'اضيفت مؤخرا',hhD7r1VvaPt3TC06SJjqKRfEid,64,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'recently_added_vids')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'فيديو عشوائي',hhD7r1VvaPt3TC06SJjqKRfEid,64,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'random_vids')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'افلام ومسلسلات',hhD7r1VvaPt3TC06SJjqKRfEid,61,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'-1')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'البرامج الدينية',hhD7r1VvaPt3TC06SJjqKRfEid,61,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'-2')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'English Videos',hhD7r1VvaPt3TC06SJjqKRfEid,61,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'-3')
	return wUvcPrYDfISbZolAm83GKEqMyXkn5
def HPdaS7kenW0m(url,d5TLHSj39awfvFp):
	uNYcJXVSEtzBU1GlT7Hwm4MevaAP = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if d5TLHSj39awfvFp not in ['-1','-2','-3']: uNYcJXVSEtzBU1GlT7Hwm4MevaAP = '?cat='+d5TLHSj39awfvFp
	ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+'/menu_level.php'+uNYcJXVSEtzBU1GlT7Hwm4MevaAP
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ALFATIMI-TITLES-1st')
	items = jj0dZrgiKb.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	iCP4J8sAg9QthkB1IGdeco,DJQIGSCHUMdvxo4 = False,False
	for hhEH1rcSP0z6Bkqy8OD,title,count in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
		uNYcJXVSEtzBU1GlT7Hwm4MevaAP = jj0dZrgiKb.findall('cat=(.*?)&',hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL)[0]
		if d5TLHSj39awfvFp==uNYcJXVSEtzBU1GlT7Hwm4MevaAP: iCP4J8sAg9QthkB1IGdeco = True
		elif iCP4J8sAg9QthkB1IGdeco 	or (d5TLHSj39awfvFp=='-1' and uNYcJXVSEtzBU1GlT7Hwm4MevaAP in MltBkX4rOI6iLZh)  						or (d5TLHSj39awfvFp=='-2' and uNYcJXVSEtzBU1GlT7Hwm4MevaAP not in kIURJFzixdW and uNYcJXVSEtzBU1GlT7Hwm4MevaAP not in MltBkX4rOI6iLZh)  						or (d5TLHSj39awfvFp=='-3' and uNYcJXVSEtzBU1GlT7Hwm4MevaAP in kIURJFzixdW):
							if count=='1': mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,63)
							else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,61,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,uNYcJXVSEtzBU1GlT7Hwm4MevaAP)
							DJQIGSCHUMdvxo4 = True
	if not DJQIGSCHUMdvxo4: mCwqRg7HpivAQ6S(url)
	return
def mCwqRg7HpivAQ6S(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,True,'ALFATIMI-EPISODES-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('pagination(.*?)id="footer',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	hhEH1rcSP0z6Bkqy8OD = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title,hhEH1rcSP0z6Bkqy8OD in items:
		title = title.replace('Add',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('to Quicklist',wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,63,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70=jj0dZrgiKb.findall('(.*?)div',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb=pLHIPUY3TWAeE70[0]
	IJE2xcV7OWauUKhfik56gXBwltCb=jj0dZrgiKb.findall('pagination(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	items=jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	ZD5n0eJivzWOMxY98dgrumkwRG = url.split('?')[0]
	for hhEH1rcSP0z6Bkqy8OD,cSOpWVb7lXu9MBT in items:
		hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG + hhEH1rcSP0z6Bkqy8OD
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(cSOpWVb7lXu9MBT)
		title = 'صفحة ' + title
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,62)
	return hhEH1rcSP0z6Bkqy8OD
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	if 'videos.php' in url: url = mCwqRg7HpivAQ6S(url)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,True,'ALFATIMI-PLAY-1st')
	items = jj0dZrgiKb.findall('playlistfile:"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	yyYuosJmc3QDUGSA(url,UdbRGoKhcDeI4lVfns5,'video')
	return
def PK9aQ25YEiXDvh(d5TLHSj39awfvFp):
	COW137cpIhBMYTSiAR9s2Dlzw = { 'mode' : d5TLHSj39awfvFp }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = rqPJzRuUF2L(COW137cpIhBMYTSiAR9s2Dlzw)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,63,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/search_result.php?query=' + LBqdVs9ioWwpMbCm1A
	mCwqRg7HpivAQ6S(url)
	return