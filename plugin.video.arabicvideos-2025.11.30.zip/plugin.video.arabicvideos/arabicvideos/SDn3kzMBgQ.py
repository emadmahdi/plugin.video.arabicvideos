# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SERIES4WATCH'
headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
UT69hgqoKsWNIwM5zkAYb = '_SFW_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==210: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==211: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	elif mode==212: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==213: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==214: RCmHBOKtejQ8lu4L = tBJdfnrcq85ZgW4Ib2xaFKlo(url)
	elif mode==215: RCmHBOKtejQ8lu4L = KLX8Oe3VEJTcaGMldIUuw9m41(url)
	elif mode==218: RCmHBOKtejQ8lu4L = C1Lh7bWnItdwZ8()
	elif mode==219: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def C1Lh7bWnItdwZ8():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'الموقع تغير بالكامل',message)
	return
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,219,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/getpostsPin?type=one&data=pin&limit=25'
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المميزة',url,211)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('FiltersButtons(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('data-get="(.*?)".*?</i>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		url = hhD7r1VvaPt3TC06SJjqKRfEid+'/getposts?type=one&data='+hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,url,211)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('navigation-menu(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(http.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	i6TIRax9v0EDFJs2gVtfzp = ['مسلسلات انمي','الرئيسية']
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,211)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('MediaGrid"(.*?)class="pagination"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		else: return
	items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	F1wxEktW8Dpi5YbsAm = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if '/series/' in hhEH1rcSP0z6Bkqy8OD: continue
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD).strip('/')
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if '/film/' in hhEH1rcSP0z6Bkqy8OD or any(value in title for value in F1wxEktW8Dpi5YbsAm):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,212,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/episode/' in hhEH1rcSP0z6Bkqy8OD and 'الحلقة' in title:
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
			if xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,213,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,213,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(hhEH1rcSP0z6Bkqy8OD)
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,211)
	return
def mCwqRg7HpivAQ6S(url):
	HSrN4MfTtQVYxJmndspZ3oFL,items,OxZMrt2u7N5YP0vigj = -1,[],[]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-EPISODES-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('ti-list-numbered(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		qqtR56dgVLh3Tr2 = wUvcPrYDfISbZolAm83GKEqMyXkn5.join(pLHIPUY3TWAeE70)
		items = jj0dZrgiKb.findall('href="(.*?)"',qqtR56dgVLh3Tr2,jj0dZrgiKb.DOTALL)
	items.append(url)
	items = set(items)
	for hhEH1rcSP0z6Bkqy8OD in items:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.strip('/')
		title = '_MOD_' + hhEH1rcSP0z6Bkqy8OD.split('/')[-1].replace('-',UKFZBQAVXHI5s17LyvuRpCY2)
		eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = jj0dZrgiKb.findall('الحلقة-(\d+)',hhEH1rcSP0z6Bkqy8OD.split('/')[-1],jj0dZrgiKb.DOTALL)
		if eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP: eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP[0]
		else: eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP = '0'
		OxZMrt2u7N5YP0vigj.append([hhEH1rcSP0z6Bkqy8OD,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP])
	items = sorted(OxZMrt2u7N5YP0vigj, reverse=False, key=lambda key: int(key[2]))
	RBNPrmzMqJxniHgtAIpSy7D = str(items).count('/season/')
	HSrN4MfTtQVYxJmndspZ3oFL = str(items).count('/episode/')
	if RBNPrmzMqJxniHgtAIpSy7D>1 and HSrN4MfTtQVYxJmndspZ3oFL>0 and '/season/' not in url:
		for hhEH1rcSP0z6Bkqy8OD,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP in items:
			if '/season/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,213)
	else:
		for hhEH1rcSP0z6Bkqy8OD,title,eC7uv9HsMBhGK0t5lRiSwTVxfNDoAP in items:
			if '/season/' not in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,212)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('/')
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in II64TLxj3mbqEyh9pHQ8oAv:
		ZD5n0eJivzWOMxY98dgrumkwRG = url.replace(deg2JDUOioWfbC8NcswK1RFAlk4M[3],'watch')
		xnGN2vER8iQqJkcFt4KWup = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-PLAY-2nd')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="servers-list(.*?)</div>',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if items:
				id = jj0dZrgiKb.findall('post_id=(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
				if id:
					LTt0Peg4HUB8wSxEn9pZiMWmDc753G = id[0]
					for hhEH1rcSP0z6Bkqy8OD,title in items:
						hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/?postid='+LTt0Peg4HUB8wSxEn9pZiMWmDc753G+'&serverid='+hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
						j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			else:
				items = jj0dZrgiKb.findall('data-embedd=".*?(http.*?)("|&quot;)',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,vziHL4xVFSD81W7X9Noyrdjb in items:
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if '/download/' in II64TLxj3mbqEyh9pHQ8oAv:
		ZD5n0eJivzWOMxY98dgrumkwRG = url.replace(deg2JDUOioWfbC8NcswK1RFAlk4M[3],'download')
		xnGN2vER8iQqJkcFt4KWup = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-PLAY-3rd')
		id = jj0dZrgiKb.findall('postId:"(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if id:
			LTt0Peg4HUB8wSxEn9pZiMWmDc753G = id[0]
			XubVRNO48BsjJASlmeKwdTCr = { 'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5 , 'X-Requested-With':'XMLHttpRequest' }
			ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid + '/ajaxCenter?_action=getdownloadlinks&postId='+LTt0Peg4HUB8wSxEn9pZiMWmDc753G
			xnGN2vER8iQqJkcFt4KWup = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SERIES4WATCH-PLAY-4th')
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<h3.*?(\d+)(.*?)</div>',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if pLHIPUY3TWAeE70:
				for ttpAvDoOKGf,IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
					items = jj0dZrgiKb.findall('<td>(.*?)<.*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
					for name,hhEH1rcSP0z6Bkqy8OD in items:
						j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__download'+'____'+ttpAvDoOKGf)
			else:
				pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<h6(.*?)</table>',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
				if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = [xnGN2vER8iQqJkcFt4KWup]
				for IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
					name = wUvcPrYDfISbZolAm83GKEqMyXkn5
					items = jj0dZrgiKb.findall('href="(http.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
					for hhEH1rcSP0z6Bkqy8OD in items:
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = '&&' + hhEH1rcSP0z6Bkqy8OD.split('/')[2].lower() + '&&'
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = xG6n4Wq2Ib7YgpiarHUNLQJM0.replace('.com&&',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('.co&&',wUvcPrYDfISbZolAm83GKEqMyXkn5)
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = xG6n4Wq2Ib7YgpiarHUNLQJM0.replace('.net&&',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('.org&&',wUvcPrYDfISbZolAm83GKEqMyXkn5)
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = xG6n4Wq2Ib7YgpiarHUNLQJM0.replace('.live&&',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('.online&&',wUvcPrYDfISbZolAm83GKEqMyXkn5)
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = xG6n4Wq2Ib7YgpiarHUNLQJM0.replace('&&hd.',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('&&www.',wUvcPrYDfISbZolAm83GKEqMyXkn5)
						xG6n4Wq2Ib7YgpiarHUNLQJM0 = xG6n4Wq2Ib7YgpiarHUNLQJM0.replace('&&',wUvcPrYDfISbZolAm83GKEqMyXkn5)
						hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD + '?named=' + name + xG6n4Wq2Ib7YgpiarHUNLQJM0 + '__download'
						j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/search?s='+search
	HPdaS7kenW0m(url)
	return