# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'AYLOL'
UT69hgqoKsWNIwM5zkAYb = '_AYL_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','عرض المزيد','تسجيل الدخول']
headers = {'Referer':hhD7r1VvaPt3TC06SJjqKRfEid}
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==1050: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==1051: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==1052: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==1053: RCmHBOKtejQ8lu4L = pXt5zYr9H0C(url,text)
	elif mode==1054: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==1059: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,1059,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مميز',hhD7r1VvaPt3TC06SJjqKRfEid,1051,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''["']navslide-wrap["'](.*?)</ul>''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?</i>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1054)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('/category.php">(.*?)"navslide-divider"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('list-unstyled(.*?)navslide-divider',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for i9eu0gvptXjKMAczZyE in pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace(i9eu0gvptXjKMAczZyE,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.+?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		title = title.replace('<b>','').strip(' ')
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1054)
	return
def FFJX0sguE92DxYGmoQAeV(url):
	Sc0NQiA2pg8,VV7eQk5mj1dBNiHtrcP = [],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"dropdown-menu"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if i7swfV8rtlpOd3K6SUDk9yn0P and '.php' in str(i7swfV8rtlpOd3K6SUDk9yn0P):
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[-1]
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('"presentation"','</ul>')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = [(wUvcPrYDfISbZolAm83GKEqMyXkn5,IJE2xcV7OWauUKhfik56gXBwltCb)]
		mwOxEyYAg63B('link',JegF7SlMawI03+' فرز أو فلتر أو ترتيب '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		for pbnhKy8SN4P7tR0qCJuwaIHeGo,IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
			Sc0NQiA2pg8 = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if pbnhKy8SN4P7tR0qCJuwaIHeGo: pbnhKy8SN4P7tR0qCJuwaIHeGo = pbnhKy8SN4P7tR0qCJuwaIHeGo+': '
			for hhEH1rcSP0z6Bkqy8OD,title in Sc0NQiA2pg8:
				title = pbnhKy8SN4P7tR0qCJuwaIHeGo+title
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1051)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"pm-category-subcats"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if m4z08qk6gJ5lK:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if 1 or len(VV7eQk5mj1dBNiHtrcP)<30:
			if Sc0NQiA2pg8: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
			for hhEH1rcSP0z6Bkqy8OD,title in VV7eQk5mj1dBNiHtrcP:
				if title in i6TIRax9v0EDFJs2gVtfzp: continue
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1051)
	if not i7swfV8rtlpOd3K6SUDk9yn0P and not m4z08qk6gJ5lK: HPdaS7kenW0m(url)
	return
def HPdaS7kenW0m(url,ySY5NxERP6jeVG=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if ySY5NxERP6jeVG=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		XubVRNO48BsjJASlmeKwdTCr = headers.copy()
		XubVRNO48BsjJASlmeKwdTCr['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'POST',url,data,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-TITLES-1st')
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-TITLES-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	IJE2xcV7OWauUKhfik56gXBwltCb,items = wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	if ySY5NxERP6jeVG=='ajax-search':
		IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
		VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in VV7eQk5mj1dBNiHtrcP: items.append((wUvcPrYDfISbZolAm83GKEqMyXkn5,hhEH1rcSP0z6Bkqy8OD,title))
	elif ySY5NxERP6jeVG=='featured':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('carousel_featuredlist(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	elif ySY5NxERP6jeVG=='new_episodes':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"row pm-ul-browse-videos(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	elif ySY5NxERP6jeVG=='new_movies':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"row pm-ul-browse-videos(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if len(pLHIPUY3TWAeE70)>1: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[1]
	elif ySY5NxERP6jeVG=='featured_series':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pm-grid"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if IJE2xcV7OWauUKhfik56gXBwltCb and not items: items = jj0dZrgiKb.findall('"thumbnail.*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items: return
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS += '|Referer='+hhD7r1VvaPt3TC06SJjqKRfEid
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('./')
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
		if any(value in title for value in SSthyczaHP7fAIoi5):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1052,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif ySY5NxERP6jeVG=='new_episodes':
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1052,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1053,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1053,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if ySY5NxERP6jeVG not in ['featured']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD=='#': continue
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('./')
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,1051)
	return
def pXt5zYr9H0C(url,ajCL4NVXu0K5):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-EPISODES_SEASONS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	mnWZN7g50M = jj0dZrgiKb.findall('pm-poster-img.*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = mnWZN7g50M[0] if mnWZN7g50M else wUvcPrYDfISbZolAm83GKEqMyXkn5
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS += '|Referer='+hhD7r1VvaPt3TC06SJjqKRfEid
	items = []
	xomQEZ1u9fNDFc3l4vsjdIaVpYiS8 = False
	if i7swfV8rtlpOd3K6SUDk9yn0P and not ajCL4NVXu0K5:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('data-serie="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for ajCL4NVXu0K5,title in items:
			ajCL4NVXu0K5 = ajCL4NVXu0K5.strip('#')
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,1053,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,ajCL4NVXu0K5)
	else: xomQEZ1u9fNDFc3l4vsjdIaVpYiS8 = True
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"SeasonsEpisodes"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not m4z08qk6gJ5lK:
		m4z08qk6gJ5lK = jj0dZrgiKb.findall('data-serie="'+ajCL4NVXu0K5+'"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if m4z08qk6gJ5lK:
			IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
			items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('./')
				title = title.replace('</em><span>',UKFZBQAVXHI5s17LyvuRpCY2)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1052,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	elif m4z08qk6gJ5lK and xomQEZ1u9fNDFc3l4vsjdIaVpYiS8:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if VV7eQk5mj1dBNiHtrcP:
			vv6ITU0LMatNfYyqz,krOd5AIKgH6TUZwtzfxu = zip(*VV7eQk5mj1dBNiHtrcP)
			BOq01fmepwaQMb9nvGk = [cPzpeLXs3jMCltW4ZN9BaYdfQvwS]*len(VV7eQk5mj1dBNiHtrcP)
			items = zip(krOd5AIKgH6TUZwtzfxu,vv6ITU0LMatNfYyqz,BOq01fmepwaQMb9nvGk)
		if not items: items = jj0dZrgiKb.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS += '|Referer='+hhD7r1VvaPt3TC06SJjqKRfEid
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('./')
			title = title.replace('</em><span>',UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,1052,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,lCtvKHMzLJVo8fERq9N5 = [],[]
	II64TLxj3mbqEyh9pHQ8oAv = ''
	if 'post=' in II64TLxj3mbqEyh9pHQ8oAv:
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('id="player".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
		dHRIVxWSDFQOajpZ7mflrsToY = hhEH1rcSP0z6Bkqy8OD.split('post=')[1]
		dHRIVxWSDFQOajpZ7mflrsToY = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(dHRIVxWSDFQOajpZ7mflrsToY)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: dHRIVxWSDFQOajpZ7mflrsToY = dHRIVxWSDFQOajpZ7mflrsToY.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		dHRIVxWSDFQOajpZ7mflrsToY = dm7KA8MukvxF3iH9CW2ZNc('dict',dHRIVxWSDFQOajpZ7mflrsToY)
		ppAJI9kDbz5MXa76UEF = dHRIVxWSDFQOajpZ7mflrsToY['servers']
		kDp3Tb6EBW = list(ppAJI9kDbz5MXa76UEF.keys())
		ppAJI9kDbz5MXa76UEF = list(ppAJI9kDbz5MXa76UEF.values())
		JIO9qPGcfs76XSU0KCh1 = zip(kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF)
		for title,hhEH1rcSP0z6Bkqy8OD in JIO9qPGcfs76XSU0KCh1:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	else:
		ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('watch.php','view.php')
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AYLOL-PLAY-1st')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('iframe src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
			if hhEH1rcSP0z6Bkqy8OD not in lCtvKHMzLJVo8fERq9N5:
				lCtvKHMzLJVo8fERq9N5.append(hhEH1rcSP0z6Bkqy8OD)
				xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__embed'
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"WatchServers"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('data-embed="(.*?)".*?</span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD in lCtvKHMzLJVo8fERq9N5: continue
				lCtvKHMzLJVo8fERq9N5.append(hhEH1rcSP0z6Bkqy8OD)
				xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__watch'
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
		if 0:
			ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('watch.php','download.php')
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,False,'AYLOL-PLAY-2nd')
			II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pm-download"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			for IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
				items = jj0dZrgiKb.findall('href="(.*?)".*?<strong>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				if not items: items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,title in items:
					if hhEH1rcSP0z6Bkqy8OD in lCtvKHMzLJVo8fERq9N5: continue
					lCtvKHMzLJVo8fERq9N5.append(hhEH1rcSP0z6Bkqy8OD)
					xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
					hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__download'
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search.php?keywords='+search
	HPdaS7kenW0m(url,'search')
	return