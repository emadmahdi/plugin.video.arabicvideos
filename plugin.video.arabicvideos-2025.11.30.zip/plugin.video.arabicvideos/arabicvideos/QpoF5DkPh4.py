# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'EGYBEST1'
UT69hgqoKsWNIwM5zkAYb = '_EB1_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['مكتبتي','ايجي بست']
def DDIqhZaAit8Ed9(mode,url,sbNukjOf4chz,text):
	if   mode==770: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==771: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,sbNukjOf4chz)
	elif mode==772: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==773: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==774: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'FULL_FILTER___'+text)
	elif mode==775: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'DEFINED_FILTER___'+text)
	elif mode==776: RCmHBOKtejQ8lu4L = IOW06nd9b4vDaBoc5rQHiUFZ(url,sbNukjOf4chz)
	elif mode==779: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text,url)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,779,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST1-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('nav-list(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)</span>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if any(value in title for value in i6TIRax9v0EDFJs2gVtfzp): continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,771)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-article(.*?)social-box',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('main-title.*?">(.*?)<.*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'mainmenu')
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-menu(.*?)</div></div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,771)
	return II64TLxj3mbqEyh9pHQ8oAv
def IOW06nd9b4vDaBoc5rQHiUFZ(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST1-SEASONS_EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-article".*?">(.*?)<(.*?)article',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		xhzIjcYasLwUiFQOrVB3ldvqpng,rNmzwKLcvbTquoFB6,items = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
		for name,IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
			if 'حلقات' in name: rNmzwKLcvbTquoFB6 = IJE2xcV7OWauUKhfik56gXBwltCb
			if 'مواسم' in name: xhzIjcYasLwUiFQOrVB3ldvqpng = IJE2xcV7OWauUKhfik56gXBwltCb
		if xhzIjcYasLwUiFQOrVB3ldvqpng and not type:
			items = jj0dZrgiKb.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',xhzIjcYasLwUiFQOrVB3ldvqpng,jj0dZrgiKb.DOTALL)
			if len(items)>1:
				for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,776,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,'season')
		if rNmzwKLcvbTquoFB6 and len(items)<2:
			items = jj0dZrgiKb.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',rNmzwKLcvbTquoFB6,jj0dZrgiKb.DOTALL)
			if items:
				for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
					mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,773,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			else:
				items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',rNmzwKLcvbTquoFB6,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,title in items:
					mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,773)
	return
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST1-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items,dNqFjMvZ1sDKkx,EU4CrTg3z07fweGHRmZbA = [],False,False
	if not type:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-content(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?</i>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'submenu')
				dNqFjMvZ1sDKkx = True
	if not type and 'p=' not in url:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('searchform(.*?)</form>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			if dNqFjMvZ1sDKkx: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر محدد',url,775,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر كامل',url,774,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث',url,779)
			mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
			EU4CrTg3z07fweGHRmZbA = True
	if not dNqFjMvZ1sDKkx:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('blocks(.*?)article',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.strip(QWLr8ABjev)
				hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
				if '/serie/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,776,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,'season')
				else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,773,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			sbNukjOf4chz = '1'
			if 'p=' in url: url,sbNukjOf4chz = url.split('p=',1)
			rC0YJ4awbU2H3LOGt5DIF = '&' if '?' in url else '?'
			url = url+rC0YJ4awbU2H3LOGt5DIF
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(sbNukjOf4chz)+1)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الصفحة التالية',url,771)
			elif sbNukjOf4chz!='1':
				url = url+'p='+str(int(sbNukjOf4chz)-1)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الصفحة السابقة',url,771)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST1-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	bxiMUQmPRvu = jj0dZrgiKb.findall('<label>التصنيف</label>.*?">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO,EEH7kydublrU = [],[],[]
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('download-section.*?action="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
		if hhEH1rcSP0z6Bkqy8OD not in EEH7kydublrU:
			EEH7kydublrU.append(hhEH1rcSP0z6Bkqy8OD)
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=__embed______'+vvLTYxVfrbDza(url))
	qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('WatchServers(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall("url='(.*?)'.*?>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,xG6n4Wq2Ib7YgpiarHUNLQJM0 in ppAJI9kDbz5MXa76UEF:
			if hhEH1rcSP0z6Bkqy8OD not in EEH7kydublrU:
				EEH7kydublrU.append(hhEH1rcSP0z6Bkqy8OD)
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__both______'+vvLTYxVfrbDza(url))
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search,url=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if not search: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
	if not url: url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search?query='+LBqdVs9ioWwpMbCm1A
	else: url = url+'?title='+LBqdVs9ioWwpMbCm1A+'&genre=&year=&lang='
	HPdaS7kenW0m(url,'search')
	return
def fFLoASm2V96qUBCEHzGJjyc(url):
	url = url.split('/smartemadfilter?')[0]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('form-row(.*?)</form>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		Q9cBo8ysZbM3L4Ttvd7nF6Nk = jj0dZrgiKb.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		a2acYLTQVdt,wqHOWj2Y6mFI,qqtR56dgVLh3Tr2 = zip(*Q9cBo8ysZbM3L4Ttvd7nF6Nk)
		Q9cBo8ysZbM3L4Ttvd7nF6Nk = zip(wqHOWj2Y6mFI,a2acYLTQVdt,qqtR56dgVLh3Tr2)
	return Q9cBo8ysZbM3L4Ttvd7nF6Nk
def e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb):
	items = jj0dZrgiKb.findall('value="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return items
def HiX3TcPpe8(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
rBSDKlQitXZd59qgyJLC = ['year','lang','genre']
wqWcXlQsxgJNYpE5T3SRdhm8M = ['year','lang','genre']
def mmUxVlf7ZQMjeDE(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='DEFINED_FILTER':
		if wqWcXlQsxgJNYpE5T3SRdhm8M[0]+'=' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = wqWcXlQsxgJNYpE5T3SRdhm8M[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(wqWcXlQsxgJNYpE5T3SRdhm8M[0:-1])):
			if wqWcXlQsxgJNYpE5T3SRdhm8M[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'=' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = wqWcXlQsxgJNYpE5T3SRdhm8M[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+d5TLHSj39awfvFp+'=0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+d5TLHSj39awfvFp+'=0'
		qclt2BMvQu = M2MhYTzotC0.strip('&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'all')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
	elif type=='FULL_FILTER':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'all')
		if not mVhHg8LIlYR5cM9d7PfB: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+mVhHg8LIlYR5cM9d7PfB
		qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها ',qaLFXuDExl8w,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',qaLFXuDExl8w,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = fFLoASm2V96qUBCEHzGJjyc(url)
	dict = {}
	for name,VaqykB2YmTbCtUDl,IJE2xcV7OWauUKhfik56gXBwltCb in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		name = name.replace('كل ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		items = e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb)
		if '=' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='DEFINED_FILTER':
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<2:
				if VaqykB2YmTbCtUDl==wqWcXlQsxgJNYpE5T3SRdhm8M[-1]:
					qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
					HPdaS7kenW0m(qaLFXuDExl8w)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'DEFINED_FILTER___'+qclt2BMvQu)
				return
			else:
				if VaqykB2YmTbCtUDl==wqWcXlQsxgJNYpE5T3SRdhm8M[-1]:
					qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع ',qaLFXuDExl8w,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع ',ZD5n0eJivzWOMxY98dgrumkwRG,775,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='FULL_FILTER':
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'=0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'=0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع :'+name,ZD5n0eJivzWOMxY98dgrumkwRG,774,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for value,sslNS0zetni1HDbZRQOCMxJ4AfhaP in items:
			if not value: continue
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			dict[VaqykB2YmTbCtUDl][value] = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'='+sslNS0zetni1HDbZRQOCMxJ4AfhaP
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'#+dict[VaqykB2YmTbCtUDl]['0']
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'+name
			if type=='FULL_FILTER': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,774,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='DEFINED_FILTER' and wqWcXlQsxgJNYpE5T3SRdhm8M[-2]+'=' in yzamv2DUurjwolVq:
				NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'modified_filters')
				ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
				qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,qaLFXuDExl8w,771,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
			elif type=='DEFINED_FILTER': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,775,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.replace('=&','=0&')
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&')
	wHOxpbdkJBM0ZC7 = {}
	if '=' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('=')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for key in rBSDKlQitXZd59qgyJLC:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if '%' not in value: value = vvLTYxVfrbDza(value)
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
		elif mode=='all': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.replace('=0','=')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm