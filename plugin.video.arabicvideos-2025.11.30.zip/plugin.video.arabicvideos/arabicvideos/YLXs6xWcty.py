# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
beQiZS9WP3z6gdHy75FMvfpDr = 'FAVORITES'
def IaWOxy5cEw(ooPMZSnrRDG6xNpJHVmgw8IOA1,FjldYe6GsQMVUW1HwaK8gRpocx):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==270: lKT2nBXgyoJcN8m4 = AAMk21ZpiCQ7jImw0fzR5UuG(FjldYe6GsQMVUW1HwaK8gRpocx)
	else: lKT2nBXgyoJcN8m4 = False
	return lKT2nBXgyoJcN8m4
def VRmu6CZOUwlaK4zqk7ty2nc8We9(QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,FjldYe6GsQMVUW1HwaK8gRpocx,EIKPJQ0x5aMGWn):
	if not QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa: return
	if   EIKPJQ0x5aMGWn=='UP1'	: tapPzq4LDTr3iem1EjK9Sfvku(FjldYe6GsQMVUW1HwaK8gRpocx,True,UD4N8MjVTd)
	elif EIKPJQ0x5aMGWn=='DOWN1'	: tapPzq4LDTr3iem1EjK9Sfvku(FjldYe6GsQMVUW1HwaK8gRpocx,False,UD4N8MjVTd)
	elif EIKPJQ0x5aMGWn=='UP4'	: tapPzq4LDTr3iem1EjK9Sfvku(FjldYe6GsQMVUW1HwaK8gRpocx,True,R9RNUT6WAPEYjHqtIokxuXs)
	elif EIKPJQ0x5aMGWn=='DOWN4'	: tapPzq4LDTr3iem1EjK9Sfvku(FjldYe6GsQMVUW1HwaK8gRpocx,False,R9RNUT6WAPEYjHqtIokxuXs)
	elif EIKPJQ0x5aMGWn=='ADD1'	: Ai0eQFIq9uMtdfwBNJDjL(FjldYe6GsQMVUW1HwaK8gRpocx)
	elif EIKPJQ0x5aMGWn=='REMOVE1': IIXpD2fgZrviGCz893FenKjR7MTkS(FjldYe6GsQMVUW1HwaK8gRpocx)
	elif EIKPJQ0x5aMGWn=='DELETELIST': D6zCRonS8KAXlkV3QeJHrq7d(FjldYe6GsQMVUW1HwaK8gRpocx)
	return
def AAMk21ZpiCQ7jImw0fzR5UuG(FjldYe6GsQMVUW1HwaK8gRpocx):
	xVPGEzhonLwDIOiYKZs = IjhSY0PuBT81CpJZbW43LfGVrDgOl()
	if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()):
		try:
			r8FCutl9kUZB73iYP5fVQHLKgjw = xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]
			if wTLFCOcM26fmYlW7U and FjldYe6GsQMVUW1HwaK8gRpocx in ['5','11','12','13']:
				for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr in r8FCutl9kUZB73iYP5fVQHLKgjw:
					if TAlYNXgaM4qzdtVUZKiubvs=='video':
						mwOxEyYAg63B('video',JegF7SlMawI03+'تشغيل من الأعلى إلى الأسفل'+AAByQSLgaZwCsKnvc5eWNmY,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa)
						mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
						break
			for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr in r8FCutl9kUZB73iYP5fVQHLKgjw:
				mwOxEyYAg63B(TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr)
		except:
			xVPGEzhonLwDIOiYKZs = akK8V9HQng4mqSlvO01swx6RorY(eCcr5AqkmHOSU)
			r8FCutl9kUZB73iYP5fVQHLKgjw = xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]
			for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr in r8FCutl9kUZB73iYP5fVQHLKgjw:
				mwOxEyYAg63B(TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr)
	return
def Ai0eQFIq9uMtdfwBNJDjL(FjldYe6GsQMVUW1HwaK8gRpocx):
	TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
	if FjldYe6GsQMVUW1HwaK8gRpocx in ['5','11','12','13'] and TAlYNXgaM4qzdtVUZKiubvs!='video':
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	Gqh9C0tX6cwg2NQD8zbR5iL7yUJn = TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,RG73XpOfASe6WT25jsEQxPq4wLr
	xVPGEzhonLwDIOiYKZs = IjhSY0PuBT81CpJZbW43LfGVrDgOl()
	dKS8cZehIjPH = {}
	for TN468OqeBkFIwLuWrXPg27cmHYQj in list(xVPGEzhonLwDIOiYKZs.keys()):
		if TN468OqeBkFIwLuWrXPg27cmHYQj!=FjldYe6GsQMVUW1HwaK8gRpocx: dKS8cZehIjPH[TN468OqeBkFIwLuWrXPg27cmHYQj] = xVPGEzhonLwDIOiYKZs[TN468OqeBkFIwLuWrXPg27cmHYQj]
		else:
			if LcukPqj3x6f9WDZQh5YJzg and LcukPqj3x6f9WDZQh5YJzg!='..':
				YYiohsjR1tufPEeJblCrN = xVPGEzhonLwDIOiYKZs[TN468OqeBkFIwLuWrXPg27cmHYQj]
				if Gqh9C0tX6cwg2NQD8zbR5iL7yUJn in YYiohsjR1tufPEeJblCrN:
					OVJw5yE1cv6mbn4 = YYiohsjR1tufPEeJblCrN.index(Gqh9C0tX6cwg2NQD8zbR5iL7yUJn)
					del YYiohsjR1tufPEeJblCrN[OVJw5yE1cv6mbn4]
				RsTOvxjLMryGKPCU3HB = YYiohsjR1tufPEeJblCrN+[Gqh9C0tX6cwg2NQD8zbR5iL7yUJn]
				dKS8cZehIjPH[TN468OqeBkFIwLuWrXPg27cmHYQj] = RsTOvxjLMryGKPCU3HB
			else: dKS8cZehIjPH[TN468OqeBkFIwLuWrXPg27cmHYQj] = xVPGEzhonLwDIOiYKZs[TN468OqeBkFIwLuWrXPg27cmHYQj]
	if FjldYe6GsQMVUW1HwaK8gRpocx not in list(dKS8cZehIjPH.keys()): dKS8cZehIjPH[FjldYe6GsQMVUW1HwaK8gRpocx] = [Gqh9C0tX6cwg2NQD8zbR5iL7yUJn]
	y96Pni0ZF5e = str(dKS8cZehIjPH)
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: y96Pni0ZF5e = y96Pni0ZF5e.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	open(eCcr5AqkmHOSU,'wb').write(y96Pni0ZF5e)
	return
def IIXpD2fgZrviGCz893FenKjR7MTkS(FjldYe6GsQMVUW1HwaK8gRpocx):
	TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
	Gqh9C0tX6cwg2NQD8zbR5iL7yUJn = TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,RG73XpOfASe6WT25jsEQxPq4wLr
	xVPGEzhonLwDIOiYKZs = IjhSY0PuBT81CpJZbW43LfGVrDgOl()
	if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()) and Gqh9C0tX6cwg2NQD8zbR5iL7yUJn in xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]:
		xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx].remove(Gqh9C0tX6cwg2NQD8zbR5iL7yUJn)
		if len(xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx])==wTLFCOcM26fmYlW7U: del xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]
		y96Pni0ZF5e = str(xVPGEzhonLwDIOiYKZs)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: y96Pni0ZF5e = y96Pni0ZF5e.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(eCcr5AqkmHOSU,'wb').write(y96Pni0ZF5e)
	return
def tapPzq4LDTr3iem1EjK9Sfvku(FjldYe6GsQMVUW1HwaK8gRpocx,dBuOQRxN5slLPvMJcyop94aG,XiTQYPMR3x7ZyE5q):
	TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
	Gqh9C0tX6cwg2NQD8zbR5iL7yUJn = TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,RG73XpOfASe6WT25jsEQxPq4wLr
	xVPGEzhonLwDIOiYKZs = IjhSY0PuBT81CpJZbW43LfGVrDgOl()
	if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()):
		YYiohsjR1tufPEeJblCrN = xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]
		if Gqh9C0tX6cwg2NQD8zbR5iL7yUJn not in YYiohsjR1tufPEeJblCrN: return
		zWYxbrfRlyUCiAcL68ZG = len(YYiohsjR1tufPEeJblCrN)
		for TvkL6PzYlCNVfUXc2b7K9ZDxg in range(wTLFCOcM26fmYlW7U,XiTQYPMR3x7ZyE5q):
			c23FGlgMzO = YYiohsjR1tufPEeJblCrN.index(Gqh9C0tX6cwg2NQD8zbR5iL7yUJn)
			if dBuOQRxN5slLPvMJcyop94aG: LhVz9xpFoc8yu0PCUf = c23FGlgMzO-UD4N8MjVTd
			else: LhVz9xpFoc8yu0PCUf = c23FGlgMzO+UD4N8MjVTd
			if LhVz9xpFoc8yu0PCUf>=zWYxbrfRlyUCiAcL68ZG: LhVz9xpFoc8yu0PCUf = LhVz9xpFoc8yu0PCUf-zWYxbrfRlyUCiAcL68ZG
			if LhVz9xpFoc8yu0PCUf<wTLFCOcM26fmYlW7U: LhVz9xpFoc8yu0PCUf = LhVz9xpFoc8yu0PCUf+zWYxbrfRlyUCiAcL68ZG
			YYiohsjR1tufPEeJblCrN.insert(LhVz9xpFoc8yu0PCUf, YYiohsjR1tufPEeJblCrN.pop(c23FGlgMzO))
		xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx] = YYiohsjR1tufPEeJblCrN
		y96Pni0ZF5e = str(xVPGEzhonLwDIOiYKZs)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: y96Pni0ZF5e = y96Pni0ZF5e.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(eCcr5AqkmHOSU,'wb').write(y96Pni0ZF5e)
	return
def sWAtp4l0vZqXIRzjdnG(FjldYe6GsQMVUW1HwaK8gRpocx):
	if FjldYe6GsQMVUW1HwaK8gRpocx in ['1','2','3','4']: jNpeM4S9r02FgXTq3HWzyBQV7U1,CCh7D49xR3qrYJl2 = 'مفضلة',FjldYe6GsQMVUW1HwaK8gRpocx
	elif FjldYe6GsQMVUW1HwaK8gRpocx in ['5']: jNpeM4S9r02FgXTq3HWzyBQV7U1,CCh7D49xR3qrYJl2 = 'تشغيل','1'
	elif FjldYe6GsQMVUW1HwaK8gRpocx in ['11']: jNpeM4S9r02FgXTq3HWzyBQV7U1,CCh7D49xR3qrYJl2 = 'تشغيل','2'
	else: jNpeM4S9r02FgXTq3HWzyBQV7U1,CCh7D49xR3qrYJl2 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	q1PdUEwQ2nSbHipC = jNpeM4S9r02FgXTq3HWzyBQV7U1+UKFZBQAVXHI5s17LyvuRpCY2+CCh7D49xR3qrYJl2
	return q1PdUEwQ2nSbHipC
def D6zCRonS8KAXlkV3QeJHrq7d(FjldYe6GsQMVUW1HwaK8gRpocx):
	q1PdUEwQ2nSbHipC = sWAtp4l0vZqXIRzjdnG(FjldYe6GsQMVUW1HwaK8gRpocx)
	ckzdJmPICTwop = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هل تريد فعلا مسح جميع محتويات قائمة '+q1PdUEwQ2nSbHipC+' ؟!')
	if ckzdJmPICTwop!=1: return
	xVPGEzhonLwDIOiYKZs = IjhSY0PuBT81CpJZbW43LfGVrDgOl()
	if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()):
		del xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]
		y96Pni0ZF5e = str(xVPGEzhonLwDIOiYKZs)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: y96Pni0ZF5e = y96Pni0ZF5e.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(eCcr5AqkmHOSU,'wb').write(y96Pni0ZF5e)
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم مسح جميع محتويات قائمة '+q1PdUEwQ2nSbHipC)
	return
def IjhSY0PuBT81CpJZbW43LfGVrDgOl():
	xVPGEzhonLwDIOiYKZs = {}
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(eCcr5AqkmHOSU):
		Uw0E97TBCX6nYbdSWk2Qo1MN = open(eCcr5AqkmHOSU,'rb').read()
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: Uw0E97TBCX6nYbdSWk2Qo1MN = Uw0E97TBCX6nYbdSWk2Qo1MN.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		xVPGEzhonLwDIOiYKZs = dm7KA8MukvxF3iH9CW2ZNc('dict',Uw0E97TBCX6nYbdSWk2Qo1MN)
	return xVPGEzhonLwDIOiYKZs
def c9qALHGKdUSZ(xVPGEzhonLwDIOiYKZs,Gqh9C0tX6cwg2NQD8zbR5iL7yUJn,YXwvaFWzOIAQ0):
	TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr = Gqh9C0tX6cwg2NQD8zbR5iL7yUJn
	if not ooPMZSnrRDG6xNpJHVmgw8IOA1: TAlYNXgaM4qzdtVUZKiubvs,ooPMZSnrRDG6xNpJHVmgw8IOA1 = 'folder','260'
	jdl3p76TkOh,FjldYe6GsQMVUW1HwaK8gRpocx = [],wUvcPrYDfISbZolAm83GKEqMyXkn5
	if 'context=' in XhGSxvjRAZdU7rEt9JMweQC:
		YF5nqJ18Sftud = jj0dZrgiKb.findall('context=(\d+)',XhGSxvjRAZdU7rEt9JMweQC,jj0dZrgiKb.DOTALL)
		if YF5nqJ18Sftud: FjldYe6GsQMVUW1HwaK8gRpocx = str(YF5nqJ18Sftud[wTLFCOcM26fmYlW7U])
	if ooPMZSnrRDG6xNpJHVmgw8IOA1=='270':
		FjldYe6GsQMVUW1HwaK8gRpocx = QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa
		if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()):
			q1PdUEwQ2nSbHipC = sWAtp4l0vZqXIRzjdnG(FjldYe6GsQMVUW1HwaK8gRpocx)
			jdl3p76TkOh.append(('مسح قائمة '+q1PdUEwQ2nSbHipC,'RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_DELETELIST'+')'))
	else:
		if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()):
			count = len(xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx])
			if count>UD4N8MjVTd: jdl3p76TkOh.append(('تحريك 1 للأعلى','RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_UP1)'))
			if count>R9RNUT6WAPEYjHqtIokxuXs: jdl3p76TkOh.append(('تحريك 4 للأعلى','RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_UP4)'))
			if count>UD4N8MjVTd: jdl3p76TkOh.append(('تحريك 1 للأسفل','RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_DOWN1)'))
			if count>R9RNUT6WAPEYjHqtIokxuXs: jdl3p76TkOh.append(('تحريك 4 للأسفل','RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_DOWN4)'))
		for FjldYe6GsQMVUW1HwaK8gRpocx in ['1','2','3','4','5','11']:
			q1PdUEwQ2nSbHipC = sWAtp4l0vZqXIRzjdnG(FjldYe6GsQMVUW1HwaK8gRpocx)
			if FjldYe6GsQMVUW1HwaK8gRpocx in list(xVPGEzhonLwDIOiYKZs.keys()) and Gqh9C0tX6cwg2NQD8zbR5iL7yUJn in xVPGEzhonLwDIOiYKZs[FjldYe6GsQMVUW1HwaK8gRpocx]:
				jdl3p76TkOh.append(('مسح من '+q1PdUEwQ2nSbHipC,'RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_REMOVE1)'))
			else: jdl3p76TkOh.append(('إضافة ل'+q1PdUEwQ2nSbHipC,'RunPlugin('+YXwvaFWzOIAQ0+'&context='+FjldYe6GsQMVUW1HwaK8gRpocx+'_ADD1)'))
	rig4Z2D1cy8 = []
	for K4RBSNc0tIqpklZmUTu2,ZZ7DSOHg2Gr in jdl3p76TkOh:
		K4RBSNc0tIqpklZmUTu2 = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+K4RBSNc0tIqpklZmUTu2+AAByQSLgaZwCsKnvc5eWNmY
		rig4Z2D1cy8.append((K4RBSNc0tIqpklZmUTu2,ZZ7DSOHg2Gr,))
	return rig4Z2D1cy8