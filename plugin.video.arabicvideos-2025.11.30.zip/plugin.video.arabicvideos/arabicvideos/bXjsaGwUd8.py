# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'CIMAFANS'
headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
UT69hgqoKsWNIwM5zkAYb = '_CMF_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==90: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==91: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f(url)
	elif mode==92: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==94: RCmHBOKtejQ8lu4L = FEkrl38NI7HGMiB9uCye1hjJU()
	elif mode==95: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==99: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,99,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المضاف حديثا',wUvcPrYDfISbZolAm83GKEqMyXkn5,94)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الأحدث',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=latest',91)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الأعلى تقيماً',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=imdb',91)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الأكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=view',91)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المثبت',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=pin',91)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'جديد الأفلام',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=newMovies',91)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'جديد الحلقات',hhD7r1VvaPt3TC06SJjqKRfEid+'/?type=newEpisodes',91)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="mainmenu(.*?)nav',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('<li><a href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	i6TIRax9v0EDFJs2gVtfzp = ['افلام للكبار فقط']
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,91)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="f-cats"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('<li><a href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not any(value in title for value in i6TIRax9v0EDFJs2gVtfzp):
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,91)
	return II64TLxj3mbqEyh9pHQ8oAv
def UUOhG6SD19FL2AztHln3uT4Xg5d8f(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'POST',url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-ITEMS-1st')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	else:
		headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-ITEMS-2nd')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="movies-items(.*?)class="listfoot"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	else: IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	items = jj0dZrgiKb.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة [0-9]+',title,jj0dZrgiKb.DOTALL)
			if xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_'+xNVKL75nEZstg4wfXBkySQ[0]
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,95,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/video/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,92,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,91,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('<a href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,91)
	return
def mCwqRg7HpivAQ6S(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-EPISODES-1st')
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('img src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="episodes-panel(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		name = jj0dZrgiKb.findall('itemprop="title">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if name: name = name[1]
		else:
			name = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel('ListItem.Label')
			if AAByQSLgaZwCsKnvc5eWNmY in name: name = name.split(AAByQSLgaZwCsKnvc5eWNmY,1)[1]
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?name">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+name+' - '+title,hhEH1rcSP0z6Bkqy8OD,92,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('class="movietitle"><a href="(.*?)">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if kdJDcbM5FWUAgBs: hhEH1rcSP0z6Bkqy8OD,title = kdJDcbM5FWUAgBs[0]
		else: hhEH1rcSP0z6Bkqy8OD,title = url,name
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,92,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,ToSi6sw41e2AdN0 = [],[]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-PLAY-1st')
	bxiMUQmPRvu = jj0dZrgiKb.findall('text-shadow: none;">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="links-panel(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?__download'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('nav-tabs"(.*?)video-panel-more',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('id="(.*?)".*?embed src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,hhEH1rcSP0z6Bkqy8OD in items:
			title = 'سيرفر '+id
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		items = jj0dZrgiKb.findall('data-server-src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in items:
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
			hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def FEkrl38NI7HGMiB9uCye1hjJU():
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMAFANS-LATEST-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="index-last-movie(.*?)id="index-slider-movie',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if '/video/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,92,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,91,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/search.php?t='+search
	UUOhG6SD19FL2AztHln3uT4Xg5d8f(url)
	return