# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from toeJqf51QP import *
class bvWysX9tFgS5GkxoaMzjVBCilO3(dd9vHqKzXCB7Y):
	def __init__(xGBhIZ1EXiTudDJ5gwr8,*aargs,**kkwargs):
		xGBhIZ1EXiTudDJ5gwr8.choiceID = -UD4N8MjVTd
	def onClick(xGBhIZ1EXiTudDJ5gwr8,xSbdiD5sAyU41YkK8FIXLc23o):
		if xSbdiD5sAyU41YkK8FIXLc23o>=MFhbWia58mP3su0fk2d(u"࠺࠲࠴࠴஄"): xGBhIZ1EXiTudDJ5gwr8.choiceID = xSbdiD5sAyU41YkK8FIXLc23o-MFhbWia58mP3su0fk2d(u"࠺࠲࠴࠴஄")
		xGBhIZ1EXiTudDJ5gwr8.WLRACDUnPw824OedsIfoF5ySVYkx()
	def SqrPfCX8bzMgl0tDV6a1j(xGBhIZ1EXiTudDJ5gwr8,*aargs):
		xGBhIZ1EXiTudDJ5gwr8.button0,xGBhIZ1EXiTudDJ5gwr8.button1,xGBhIZ1EXiTudDJ5gwr8.button2 = aargs[wTLFCOcM26fmYlW7U],aargs[UD4N8MjVTd],aargs[Tb7oymMnpflsSv3eu4Pz2]
		xGBhIZ1EXiTudDJ5gwr8.header,xGBhIZ1EXiTudDJ5gwr8.text = aargs[MMRBkhnWVJCQwU],aargs[R9RNUT6WAPEYjHqtIokxuXs]
		xGBhIZ1EXiTudDJ5gwr8.profile,xGBhIZ1EXiTudDJ5gwr8.direction = aargs[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠷அ")],aargs[DpRJnas65uVcO0S17dYG(u"࠹ஆ")]
		xGBhIZ1EXiTudDJ5gwr8.buttonstimeout,xGBhIZ1EXiTudDJ5gwr8.closetimeout = aargs[xdSThjYnuHXAU6M(u"࠼ஈ")],aargs[DpRJnas65uVcO0S17dYG(u"࠼இ")]
		if xGBhIZ1EXiTudDJ5gwr8.buttonstimeout>wTLFCOcM26fmYlW7U or xGBhIZ1EXiTudDJ5gwr8.closetimeout>jQv0du1iVxTgAXCM(u"࠶உ"): xGBhIZ1EXiTudDJ5gwr8.enable_progressbar = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		else: xGBhIZ1EXiTudDJ5gwr8.enable_progressbar = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		xGBhIZ1EXiTudDJ5gwr8.image_filename = jiVY8KaspuyU.replace(fmkZtbRj3ux(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧ૰"),vWNRusF46D7Mi8GpZ(u"ࠨࡡࠪ૱")+str(L5jXH0fZ8TvsESR.time())+Gj3rMP1Cb8wHdp49la0(u"ࠩࡢࠫ૲"))
		xGBhIZ1EXiTudDJ5gwr8.image_filename = xGBhIZ1EXiTudDJ5gwr8.image_filename.replace(bQGafNLXyFgsZP6ut(u"ࠪࡠࡡ࠭૳"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡡࡢ࡜࡝ࠩ૴")).replace(bQGafNLXyFgsZP6ut(u"ࠬ࠵࠯ࠨ૵"),llkFwuCyhaP3sK76qO4T(u"࠭࠯࠰࠱࠲ࠫ૶"))
		xGBhIZ1EXiTudDJ5gwr8.image_height = NafZqglQjkYd05U2S(xGBhIZ1EXiTudDJ5gwr8.button0,xGBhIZ1EXiTudDJ5gwr8.button1,xGBhIZ1EXiTudDJ5gwr8.button2,xGBhIZ1EXiTudDJ5gwr8.header,xGBhIZ1EXiTudDJ5gwr8.text,xGBhIZ1EXiTudDJ5gwr8.profile,xGBhIZ1EXiTudDJ5gwr8.direction,xGBhIZ1EXiTudDJ5gwr8.enable_progressbar,xGBhIZ1EXiTudDJ5gwr8.image_filename)
		xGBhIZ1EXiTudDJ5gwr8.show()
		xGBhIZ1EXiTudDJ5gwr8.getControl(llkFwuCyhaP3sK76qO4T(u"࠹࠱࠷࠳ஊ")).setImage(xGBhIZ1EXiTudDJ5gwr8.image_filename)
		xGBhIZ1EXiTudDJ5gwr8.getControl(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠺࠲࠸࠴஋")).setHeight(xGBhIZ1EXiTudDJ5gwr8.image_height)
		if not xGBhIZ1EXiTudDJ5gwr8.button1 and xGBhIZ1EXiTudDJ5gwr8.button0 and xGBhIZ1EXiTudDJ5gwr8.button2: xGBhIZ1EXiTudDJ5gwr8.getControl(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠼࠴࠶࠸஍")).setPosition(-jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠶࠷࠶எ"),JHMxIE4fs1mvQtKW7R(u"࠲஌"))
		return xGBhIZ1EXiTudDJ5gwr8.image_filename,xGBhIZ1EXiTudDJ5gwr8.image_height
	def QNZl8rvMAKE2J97jYk5wPWBxdm3D0R(xGBhIZ1EXiTudDJ5gwr8):
		if xGBhIZ1EXiTudDJ5gwr8.buttonstimeout:
			xGBhIZ1EXiTudDJ5gwr8.th1 = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=xGBhIZ1EXiTudDJ5gwr8.oNeW1lKBdO9)
			xGBhIZ1EXiTudDJ5gwr8.th1.start()
		else: xGBhIZ1EXiTudDJ5gwr8.Ghvnba6FQ5T2jSNeRuHXE0Yrz()
	def oNeW1lKBdO9(xGBhIZ1EXiTudDJ5gwr8):
		xGBhIZ1EXiTudDJ5gwr8.getControl(lCT8hfYUBX4OQMmL(u"࠾࠶࠲࠱ஏ")).setEnabled(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		for qbRmVByrJv18 in range(UD4N8MjVTd,xGBhIZ1EXiTudDJ5gwr8.buttonstimeout+UD4N8MjVTd):
			L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
			P7DMHAaVgi54clOuT = int(Gj3rMP1Cb8wHdp49la0(u"࠷࠰࠱ஐ")*qbRmVByrJv18/xGBhIZ1EXiTudDJ5gwr8.buttonstimeout)
			xGBhIZ1EXiTudDJ5gwr8.DtsEmrUpgukb3fXTAQhS8znMHYwi(P7DMHAaVgi54clOuT)
			if xGBhIZ1EXiTudDJ5gwr8.choiceID>weh7SGmuTgXOVRcMo1rlLq(u"࠰஑"): break
		xGBhIZ1EXiTudDJ5gwr8.Ghvnba6FQ5T2jSNeRuHXE0Yrz()
	def PFyqexQpY87Ift(xGBhIZ1EXiTudDJ5gwr8):
		if xGBhIZ1EXiTudDJ5gwr8.closetimeout:
			xGBhIZ1EXiTudDJ5gwr8.th2 = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=xGBhIZ1EXiTudDJ5gwr8.krl8VbsjHSKGPtq0Mi)
			xGBhIZ1EXiTudDJ5gwr8.th2.start()
		else: xGBhIZ1EXiTudDJ5gwr8.Ghvnba6FQ5T2jSNeRuHXE0Yrz()
	def krl8VbsjHSKGPtq0Mi(xGBhIZ1EXiTudDJ5gwr8):
		xGBhIZ1EXiTudDJ5gwr8.getControl(kPCxIUZb1V(u"࠺࠲࠵࠴ஒ")).setEnabled(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		L5jXH0fZ8TvsESR.sleep(xGBhIZ1EXiTudDJ5gwr8.buttonstimeout)
		for qbRmVByrJv18 in range(xGBhIZ1EXiTudDJ5gwr8.closetimeout-UD4N8MjVTd,-UD4N8MjVTd,-UD4N8MjVTd):
			L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
			P7DMHAaVgi54clOuT = int(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠳࠳࠴ஓ")*qbRmVByrJv18/xGBhIZ1EXiTudDJ5gwr8.closetimeout)
			xGBhIZ1EXiTudDJ5gwr8.DtsEmrUpgukb3fXTAQhS8znMHYwi(P7DMHAaVgi54clOuT)
			if xGBhIZ1EXiTudDJ5gwr8.choiceID>wTLFCOcM26fmYlW7U: break
		if xGBhIZ1EXiTudDJ5gwr8.closetimeout>wTLFCOcM26fmYlW7U: xGBhIZ1EXiTudDJ5gwr8.choiceID = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠴࠴ஔ")
		xGBhIZ1EXiTudDJ5gwr8.WLRACDUnPw824OedsIfoF5ySVYkx()
	def DtsEmrUpgukb3fXTAQhS8znMHYwi(xGBhIZ1EXiTudDJ5gwr8,P7DMHAaVgi54clOuT):
		xGBhIZ1EXiTudDJ5gwr8.precent = P7DMHAaVgi54clOuT
		xGBhIZ1EXiTudDJ5gwr8.getControl(DpRJnas65uVcO0S17dYG(u"࠽࠵࠸࠰க")).setPercent(xGBhIZ1EXiTudDJ5gwr8.precent)
	def Ghvnba6FQ5T2jSNeRuHXE0Yrz(xGBhIZ1EXiTudDJ5gwr8):
		if xGBhIZ1EXiTudDJ5gwr8.button0: xGBhIZ1EXiTudDJ5gwr8.getControl(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠾࠶࠱࠱஖")).setEnabled(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		if xGBhIZ1EXiTudDJ5gwr8.button1: xGBhIZ1EXiTudDJ5gwr8.getControl(erqDsJmL3BQHuGtPkcf0X9(u"࠿࠰࠲࠳஗")).setEnabled(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		if xGBhIZ1EXiTudDJ5gwr8.button2: xGBhIZ1EXiTudDJ5gwr8.getControl(weh7SGmuTgXOVRcMo1rlLq(u"࠹࠱࠳࠵஘")).setEnabled(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	def WLRACDUnPw824OedsIfoF5ySVYkx(xGBhIZ1EXiTudDJ5gwr8):
		xGBhIZ1EXiTudDJ5gwr8.close()
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(xGBhIZ1EXiTudDJ5gwr8.image_filename)
		except: pass
def IUaTPEbvz0powmgNSFn4fQhLKRiZ6(*aargs,**kkwargs):
	if aargs:
		direction = aargs[wTLFCOcM26fmYlW7U]
		QMmoiF53RWP = aargs[UD4N8MjVTd]
		if not direction: direction = D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡤࡧࡱࡸࡪࡸࠧ૷")
		if not QMmoiF53RWP: QMmoiF53RWP = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨษึฮ๊ืวาࠩ૸")
		a0gtPERXB7392ecKFLdshfl = aargs[Tb7oymMnpflsSv3eu4Pz2]
		UWErGF2TqoQ = QWLr8ABjev.join(aargs[yRWQMHxZEz0(u"࠴ங"):])
	else: direction,QMmoiF53RWP,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ = wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠩࡒࡏࠬૹ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	E74G0qBSpwUPLO56fsReHCl(direction,wUvcPrYDfISbZolAm83GKEqMyXkn5,QMmoiF53RWP,wUvcPrYDfISbZolAm83GKEqMyXkn5,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,**kkwargs)
	return
def T4dIruOctCl2qwYNE0SDyU(*aargs,**kkwargs):
	direction = aargs[wTLFCOcM26fmYlW7U]
	rcljShB4VZvF6RUde3H2kgC9ytE = aargs[UD4N8MjVTd]
	SLTpuDkrvy3PzeG0oqZcsV68 = aargs[Tb7oymMnpflsSv3eu4Pz2]
	if SLTpuDkrvy3PzeG0oqZcsV68 or rcljShB4VZvF6RUde3H2kgC9ytE: BB74kOamG6lyR2bh = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	else: BB74kOamG6lyR2bh = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	a0gtPERXB7392ecKFLdshfl = aargs[MMRBkhnWVJCQwU]
	UWErGF2TqoQ = aargs[R9RNUT6WAPEYjHqtIokxuXs]
	if not direction: direction = yRWQMHxZEz0(u"ࠪࡧࡪࡴࡴࡦࡴࠪૺ")
	if not rcljShB4VZvF6RUde3H2kgC9ytE: rcljShB4VZvF6RUde3H2kgC9ytE = jnqzf9WihpUlxmcAEZ1vMLXNu(u"่๊ࠫวࠡࠢࡑࡳࠬૻ")
	if not SLTpuDkrvy3PzeG0oqZcsV68: SLTpuDkrvy3PzeG0oqZcsV68 = bQGafNLXyFgsZP6ut(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧૼ")
	if len(aargs)>=VhqD3zp7mUieI8sMQlETH(u"࠹஛"): UWErGF2TqoQ += QWLr8ABjev+aargs[DpRJnas65uVcO0S17dYG(u"࠷ச")]
	if len(aargs)>=xm6jK1ZMuWq5(u"࠻ஜ"): UWErGF2TqoQ += QWLr8ABjev+aargs[VhqD3zp7mUieI8sMQlETH(u"࠻஝")]
	nV02gQlNqjHvTX5eYJ8xfdkp1u = E74G0qBSpwUPLO56fsReHCl(direction,rcljShB4VZvF6RUde3H2kgC9ytE,wUvcPrYDfISbZolAm83GKEqMyXkn5,SLTpuDkrvy3PzeG0oqZcsV68,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,**kkwargs)
	if nV02gQlNqjHvTX5eYJ8xfdkp1u==-it4DKnryZlx(u"࠷ஞ") and BB74kOamG6lyR2bh: nV02gQlNqjHvTX5eYJ8xfdkp1u = -UD4N8MjVTd
	elif nV02gQlNqjHvTX5eYJ8xfdkp1u==-UD4N8MjVTd and not BB74kOamG6lyR2bh: nV02gQlNqjHvTX5eYJ8xfdkp1u = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	elif nV02gQlNqjHvTX5eYJ8xfdkp1u==wTLFCOcM26fmYlW7U: nV02gQlNqjHvTX5eYJ8xfdkp1u = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	elif nV02gQlNqjHvTX5eYJ8xfdkp1u==Tb7oymMnpflsSv3eu4Pz2: nV02gQlNqjHvTX5eYJ8xfdkp1u = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return nV02gQlNqjHvTX5eYJ8xfdkp1u
def ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(*aargs,**kkwargs):
	return llfAzdjaVLTbyZW7op9i.Dialog().select(*aargs,**kkwargs)
def hg79cQmoVfMCukiU8ERpT6JqywSrN3(*aargs,**kkwargs):
	a0gtPERXB7392ecKFLdshfl = aargs[wTLFCOcM26fmYlW7U]
	UWErGF2TqoQ = aargs[UD4N8MjVTd]
	GnQbsIeDMm9 = kkwargs[xdSThjYnuHXAU6M(u"࠭ࡴࡪ࡯ࡨࠫ૽")] if s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡵ࡫ࡰࡩࠬ૾") in list(kkwargs.keys()) else erqDsJmL3BQHuGtPkcf0X9(u"࠱࠱࠲࠳ட")
	gAypGTSYhuNx2P = aargs[Tb7oymMnpflsSv3eu4Pz2] if len(aargs)>Tb7oymMnpflsSv3eu4Pz2 and jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡶ࡬ࡱࡪ࠭૿") not in aargs[Tb7oymMnpflsSv3eu4Pz2] else gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ଀")
	PkSXAiJg9zIy6CW5VKvQ = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=VfLAh1gcdb5lW,args=(a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,gAypGTSYhuNx2P,GnQbsIeDMm9))
	PkSXAiJg9zIy6CW5VKvQ.start()
	return
def VfLAh1gcdb5lW(a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,gAypGTSYhuNx2P,GnQbsIeDMm9):
	nrXYWqpRhuZeOvVgKxbGTc523ojF0 = gAypGTSYhuNx2P.replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪଁ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	import td9O3TPvz2
	name = td9O3TPvz2.kJOzn1CFwXUpVTudGqIm6SvHtjQW2Z(y0yvdNOZkiKEg5RLMhoDVQAB9F2,nrXYWqpRhuZeOvVgKxbGTc523ojF0+xdSThjYnuHXAU6M(u"ࠫࠥ࠳ࠠࠨଂ")+a0gtPERXB7392ecKFLdshfl+VhqD3zp7mUieI8sMQlETH(u"ࠬࠦ࠭ࠡࠩଃ")+UWErGF2TqoQ)
	name = td9O3TPvz2.wYjpROZ8HU92X(name)
	image_filename = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(VYPjpbzMoqyd,name+ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࠮ࡱࡰࡪࠫ଄"))
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(image_filename):
		if gAypGTSYhuNx2P==weh7SGmuTgXOVRcMo1rlLq(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧଅ"): image_height = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠲࠳࠺஠")
		elif gAypGTSYhuNx2P==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬଆ"): image_height = yRWQMHxZEz0(u"࠴࠴࠴஡")
	else: image_height = NafZqglQjkYd05U2S(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,gAypGTSYhuNx2P,weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࡯ࡩ࡫ࡺࠧଇ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA,image_filename)
	t3IHWvcajpJAh7N5YVswe = dd9vHqKzXCB7Y(VhqD3zp7mUieI8sMQlETH(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪଈ"),ZwHiVtNa5qeP9YAJImX2s170QjK8xT,xm6jK1ZMuWq5(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬଉ"),jQv0du1iVxTgAXCM(u"ࠬ࠽࠲࠱ࡲࠪଊ"))
	t3IHWvcajpJAh7N5YVswe.show()
	if gAypGTSYhuNx2P==erqDsJmL3BQHuGtPkcf0X9(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪଋ"):
		t3IHWvcajpJAh7N5YVswe.getControl(xdSThjYnuHXAU6M(u"࠽࠵࠺࠰ண")).setHeight(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵࠵࠺஢"))
		t3IHWvcajpJAh7N5YVswe.getControl(w8JC1y7Lp3(u"࠹࠱࠶࠳஦")).setPosition(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠺࠻த"),-DpRJnas65uVcO0S17dYG(u"࠾࠰஥"))
		t3IHWvcajpJAh7N5YVswe.getControl(xm6jK1ZMuWq5(u"࠺࠲࠸࠴஧")).setPosition(DpRJnas65uVcO0S17dYG(u"࠳࠵࠴ந"),-vvhR5ozeiJpANyl8fFO3GBw(u"࠹࠴ன"))
		t3IHWvcajpJAh7N5YVswe.getControl(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠺࠰࠱஬")).setPosition(it4DKnryZlx(u"࠽࠵ப"),-jQv0du1iVxTgAXCM(u"࠸࠻஫"))
	t3IHWvcajpJAh7N5YVswe.getControl(A6Sg45ChDR3BJLYfFH(u"࠴࠱࠳஭")).setVisible(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	t3IHWvcajpJAh7N5YVswe.getControl(bQGafNLXyFgsZP6ut(u"࠵࠲࠵ம")).setVisible(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	t3IHWvcajpJAh7N5YVswe.getControl(Gj3rMP1Cb8wHdp49la0(u"࠻࠳࠹࠵ய")).setImage(image_filename)
	t3IHWvcajpJAh7N5YVswe.getControl(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠼࠴࠺࠶ர")).setHeight(image_height)
	L5jXH0fZ8TvsESR.sleep(GnQbsIeDMm9//vWNRusF46D7Mi8GpZ(u"࠵࠵࠶࠰࠯࠲ற"))
	return
def XODdc0rwio9amnFLuIkjRsZ(*aargs,**kkwargs):
	a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,profile,direction = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨଌ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ࡮ࡨࡪࡹ࠭଍")
	if len(aargs)>=UD4N8MjVTd: a0gtPERXB7392ecKFLdshfl = aargs[wTLFCOcM26fmYlW7U]
	if len(aargs)>=Tb7oymMnpflsSv3eu4Pz2: UWErGF2TqoQ = aargs[UD4N8MjVTd]
	if len(aargs)>=MMRBkhnWVJCQwU: profile = aargs[Tb7oymMnpflsSv3eu4Pz2]
	if len(aargs)>=R9RNUT6WAPEYjHqtIokxuXs: direction = aargs[MMRBkhnWVJCQwU]
	return sNQlowOJdgWBt2cyV18ZI6Ye(direction,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,profile)
def LXoJtpOd2e9ASTGRw8qQ(*aargs,**kkwargs):
	return llfAzdjaVLTbyZW7op9i.Dialog().contextmenu(*aargs,**kkwargs)
def CUa57rbLZxwmhkcSDvT2PBWKRq(*aargs,**kkwargs):
	return llfAzdjaVLTbyZW7op9i.Dialog().browseSingle(*aargs,**kkwargs)
def OmAdpxn2q3RFcv4JkTfoGM(*aargs,**kkwargs):
	return llfAzdjaVLTbyZW7op9i.Dialog().input(*aargs,**kkwargs)
def tt4jsl3YLKexr(*aargs,**kkwargs):
	return llfAzdjaVLTbyZW7op9i.DialogProgress(*aargs,**kkwargs)
def E74G0qBSpwUPLO56fsReHCl(direction,button0=wUvcPrYDfISbZolAm83GKEqMyXkn5,button1=wUvcPrYDfISbZolAm83GKEqMyXkn5,button2=wUvcPrYDfISbZolAm83GKEqMyXkn5,a0gtPERXB7392ecKFLdshfl=wUvcPrYDfISbZolAm83GKEqMyXkn5,UWErGF2TqoQ=wUvcPrYDfISbZolAm83GKEqMyXkn5,profile=MFhbWia58mP3su0fk2d(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ଎"),uNpVQCPmzR0s=wTLFCOcM26fmYlW7U,NZfEK4li8TbqCDdUXrFAJnuPW6g=wTLFCOcM26fmYlW7U):
	if not direction: direction = llkFwuCyhaP3sK76qO4T(u"ࠪࡧࡪࡴࡴࡦࡴࠪଏ")
	t3IHWvcajpJAh7N5YVswe = bvWysX9tFgS5GkxoaMzjVBCilO3(lCT8hfYUBX4OQMmL(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ଐ"),ZwHiVtNa5qeP9YAJImX2s170QjK8xT,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭଑"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠷࠳࠲ࡳࠫ଒"))
	t3IHWvcajpJAh7N5YVswe.SqrPfCX8bzMgl0tDV6a1j(button0,button1,button2,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,profile,direction,uNpVQCPmzR0s,NZfEK4li8TbqCDdUXrFAJnuPW6g)
	if uNpVQCPmzR0s>wTLFCOcM26fmYlW7U: t3IHWvcajpJAh7N5YVswe.QNZl8rvMAKE2J97jYk5wPWBxdm3D0R()
	if NZfEK4li8TbqCDdUXrFAJnuPW6g>wTLFCOcM26fmYlW7U: t3IHWvcajpJAh7N5YVswe.PFyqexQpY87Ift()
	if uNpVQCPmzR0s==wTLFCOcM26fmYlW7U and NZfEK4li8TbqCDdUXrFAJnuPW6g==wTLFCOcM26fmYlW7U: t3IHWvcajpJAh7N5YVswe.Ghvnba6FQ5T2jSNeRuHXE0Yrz()
	t3IHWvcajpJAh7N5YVswe.doModal()
	nV02gQlNqjHvTX5eYJ8xfdkp1u = t3IHWvcajpJAh7N5YVswe.choiceID
	return nV02gQlNqjHvTX5eYJ8xfdkp1u
def sNQlowOJdgWBt2cyV18ZI6Ye(direction,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,profile=VhqD3zp7mUieI8sMQlETH(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨଓ")):
	if not direction: direction = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࡮ࡨࡪࡹ࠭ଔ")
	t3IHWvcajpJAh7N5YVswe = dd9vHqKzXCB7Y(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬକ"),ZwHiVtNa5qeP9YAJImX2s170QjK8xT,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫଖ"),llkFwuCyhaP3sK76qO4T(u"ࠫ࠼࠸࠰ࡱࠩଗ"))
	image_filename = jiVY8KaspuyU.replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬଘ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭࡟ࠨଙ")+str(L5jXH0fZ8TvsESR.time())+w8JC1y7Lp3(u"ࠧࡠࠩଚ"))
	image_filename = image_filename.replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࡞࡟ࠫଛ"),yRWQMHxZEz0(u"ࠩ࡟ࡠࡡࡢࠧଜ")).replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪ࠳࠴࠭ଝ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫ࠴࠵࠯࠰ࠩଞ"))
	image_height = NafZqglQjkYd05U2S(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,a0gtPERXB7392ecKFLdshfl,UWErGF2TqoQ,profile,direction,Z19pUxa2gfGMNKoDsEuytn85SjFvA,image_filename)
	t3IHWvcajpJAh7N5YVswe.show()
	t3IHWvcajpJAh7N5YVswe.getControl(JHMxIE4fs1mvQtKW7R(u"࠾࠶࠵࠱ல")).setHeight(image_height)
	t3IHWvcajpJAh7N5YVswe.getControl(fmkZtbRj3ux(u"࠿࠰࠶࠲ள")).setImage(image_filename)
	Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = t3IHWvcajpJAh7N5YVswe.doModal()
	try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(image_filename)
	except: pass
	return Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS
def NafZqglQjkYd05U2S(jxgz5GIu1ULM3dsBne4RF8iX0,DHJUFN7lvz,jBqZanbQDEmXpsvhYu2KwGd9A,hGJ4ACLwx5I,eIRJAgj25bzvNik48puZl3OPUq,NNwOWj5ougPHme8yXG1R7,S1ztx8pZ26qyMvdiKQe,uBrfTS5k4691,pyeUiLGXzEPtsZ):
	neFTf7jtmd0Z63GUhsH = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.dirname(pyeUiLGXzEPtsZ)
	if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(neFTf7jtmd0Z63GUhsH):
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.makedirs(neFTf7jtmd0Z63GUhsH)
		except: pass
	oFMsU7bYwXB3GO2 = RyJa1KoLr6ZC2TwVSNdBPklg7f(NNwOWj5ougPHme8yXG1R7)
	mjic76Ubun5po3sMyTQSxEIZfRd = nS5v9m8CMXHAjwYVlJbE(oFMsU7bYwXB3GO2,jxgz5GIu1ULM3dsBne4RF8iX0,DHJUFN7lvz,jBqZanbQDEmXpsvhYu2KwGd9A,hGJ4ACLwx5I,eIRJAgj25bzvNik48puZl3OPUq,NNwOWj5ougPHme8yXG1R7,S1ztx8pZ26qyMvdiKQe,uBrfTS5k4691,pyeUiLGXzEPtsZ)
	return mjic76Ubun5po3sMyTQSxEIZfRd
def RyJa1KoLr6ZC2TwVSNdBPklg7f(NNwOWj5ougPHme8yXG1R7):
	FFmRkSltHTd52b1pLj = ewJ9sTMmXtWH0ANVShQ2
	QiZ7V0wUNHvPoqFgAEy8 = erqDsJmL3BQHuGtPkcf0X9(u"࠲࠱ழ")
	j3GHcsARSJC4OwPVQ = vWNRusF46D7Mi8GpZ(u"࠳࠲வ")
	BkFiCxp3l2tAPQqLYoVhcwEy1ZfIzU = wTLFCOcM26fmYlW7U
	RwS8n2ANl1KiVbyvpF = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଟ")
	Mut6PeKdT3rlvbj8Ekm5h2UB0czog = wTLFCOcM26fmYlW7U
	C3iKbdqMgPwF = JHMxIE4fs1mvQtKW7R(u"࠳࠼ஶ")
	qN7pau4isyPSMDmbtTwRBnV12 = llkFwuCyhaP3sK76qO4T(u"࠶࠴ஷ")
	sRpWaAlZQ4gt2uPJF = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠼ஸ")
	dP1RyO45bZTLX6elWnacvSKrj9uA8 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	uUd0xfj67BWicgMpv9AREXY = jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠸࠽࠵ஹ")
	P8bymZLsReVFn01HQr2wA = TNw1pBHb8CtSZe0EFxuJqI(u"࠺࠱࠱஺")
	BOXTaNZHDobP21k843utcdEQfl6w = it4DKnryZlx(u"࠵࠱஻")
	ZxjhN4obtT = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳࠺࠳஼")
	K8RVT3qfhyN1oeHFunDMzkj = erqDsJmL3BQHuGtPkcf0X9(u"࠴࠻஽")
	tMI4STV57fjiclsOmkXa0PLourKz = ewJ9sTMmXtWH0ANVShQ2
	FvGjbIxADV2iJTRNWMEBd = wTLFCOcM26fmYlW7U
	JmNUZGyzewCsIpVSn2QcvE5iDx8Kb = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠶࠵ா")
	ZwAtqYRMKSh1U = [xm6jK1ZMuWq5(u"࠹࠶ு"),jQv0du1iVxTgAXCM(u"࠷࠷ி"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠷࠾ீ")]
	from PIL import ImageDraw as D7jhmAFZBVYLJWeot1l2,ImageFont as EFJp4qZUo6cb3BDMzXOySgfT,Image as O7Ii4SVuMRZQCbmYt
	if fmkZtbRj3ux(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬଠ") in NNwOWj5ougPHme8yXG1R7:
		if NNwOWj5ougPHme8yXG1R7==VhqD3zp7mUieI8sMQlETH(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧଡ"):
			hkqipRNFP6r7vHlnJC3M = w8JC1y7Lp3(u"࠱࠲࠹ூ")
			RwS8n2ANl1KiVbyvpF = A6Sg45ChDR3BJLYfFH(u"ࠨ࡮ࡨࡪࡹ࠭ଢ")
			dP1RyO45bZTLX6elWnacvSKrj9uA8 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		elif NNwOWj5ougPHme8yXG1R7==xm6jK1ZMuWq5(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭ଣ"):
			hkqipRNFP6r7vHlnJC3M = vWNRusF46D7Mi8GpZ(u"࡙ࠪࡕࡖࡅࡓࠩତ")
			RwS8n2ANl1KiVbyvpF = w8JC1y7Lp3(u"ࠫࡷ࡯ࡧࡩࡶࠪଥ")
			BkFiCxp3l2tAPQqLYoVhcwEy1ZfIzU = DpRJnas65uVcO0S17dYG(u"࠲࠲௃")
		dHLQAeYlq1N0VCsoX9x = kPCxIUZb1V(u"࠹࠵࠴௄")
		ZwAtqYRMKSh1U = [lCT8hfYUBX4OQMmL(u"࠶࠷௅"),lCT8hfYUBX4OQMmL(u"࠶࠷௅"),lCT8hfYUBX4OQMmL(u"࠶࠷௅")]
		j3GHcsARSJC4OwPVQ = w8JC1y7Lp3(u"࠶࠵ெ")
		QiZ7V0wUNHvPoqFgAEy8 = wTLFCOcM26fmYlW7U
		qN7pau4isyPSMDmbtTwRBnV12 = erqDsJmL3BQHuGtPkcf0X9(u"࠷࠶ே")
		C3iKbdqMgPwF = jQv0du1iVxTgAXCM(u"࠹࠵ை")
	elif NNwOWj5ougPHme8yXG1R7==kPCxIUZb1V(u"ࠬࡳࡥ࡯ࡷࡢ࡭ࡹ࡫࡭ࠨଦ"):
		ZwAtqYRMKSh1U,dHLQAeYlq1N0VCsoX9x,hkqipRNFP6r7vHlnJC3M = [dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠻ோ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠻ோ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠻ோ")],weh7SGmuTgXOVRcMo1rlLq(u"࠲࠱࠲௉"),xdSThjYnuHXAU6M(u"࠳࠷࠳ொ")
		Mut6PeKdT3rlvbj8Ekm5h2UB0czog,qN7pau4isyPSMDmbtTwRBnV12,C3iKbdqMgPwF, = wTLFCOcM26fmYlW7U,-D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠶ௌ"),-w8JC1y7Lp3(u"࠷࠵்")
		QiZ7V0wUNHvPoqFgAEy8 = wTLFCOcM26fmYlW7U
		TTCJUcikyFZ3HgOlB7x = O7Ii4SVuMRZQCbmYt.open(sClMWK2Epu7ac)
		HjT7icm8WdYXl0Jko = O7Ii4SVuMRZQCbmYt.new(TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡒࡈࡄࡄࠫଧ"),(dHLQAeYlq1N0VCsoX9x,hkqipRNFP6r7vHlnJC3M),(llkFwuCyhaP3sK76qO4T(u"࠷࠻࠵௎"),wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U,llkFwuCyhaP3sK76qO4T(u"࠷࠻࠵௎")))
	elif NNwOWj5ougPHme8yXG1R7==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫନ"): ZwAtqYRMKSh1U,hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = [JHMxIE4fs1mvQtKW7R(u"࠴࠻௒"),yRWQMHxZEz0(u"࠸࠴௏"),TNw1pBHb8CtSZe0EFxuJqI(u"࠲࠱ௐ")],TNw1pBHb8CtSZe0EFxuJqI(u"࠸࠴࠵௓"),lCT8hfYUBX4OQMmL(u"࠺࠲࠳௑")
	elif NNwOWj5ougPHme8yXG1R7==jQv0du1iVxTgAXCM(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭଩"): ZwAtqYRMKSh1U,hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠸࠸௕"),xdSThjYnuHXAU6M(u"࠲࠹ௗ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠶࠹௔")],dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠶࠲࠳௘"),vWNRusF46D7Mi8GpZ(u"࠿࠰࠱௖")
	elif NNwOWj5ougPHme8yXG1R7==kPCxIUZb1V(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫପ"): ZwAtqYRMKSh1U,hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = [MFhbWia58mP3su0fk2d(u"࠸࠼௜"),vvhR5ozeiJpANyl8fFO3GBw(u"࠵࠵௙"),TNw1pBHb8CtSZe0EFxuJqI(u"࠶࠽௛")],xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠻࠰࠱௝"),xm6jK1ZMuWq5(u"࠼࠴࠵௚")
	elif NNwOWj5ougPHme8yXG1R7==xm6jK1ZMuWq5(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ଫ"): hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = JHMxIE4fs1mvQtKW7R(u"࠷࠵࠲௞"),it4DKnryZlx(u"࠲࠴࠺࠴௟")
	elif NNwOWj5ougPHme8yXG1R7==DpRJnas65uVcO0S17dYG(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬବ"): hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࡛ࠬࡐࡑࡇࡕࠫଭ"),jQv0du1iVxTgAXCM(u"࠳࠵࠻࠵௠")
	elif NNwOWj5ougPHme8yXG1R7==TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫମ"): ZwAtqYRMKSh1U,hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = [fmkZtbRj3ux(u"࠸࠸௤"),lCT8hfYUBX4OQMmL(u"࠲࠴௥"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠵࠽௢")],JHMxIE4fs1mvQtKW7R(u"࠺࠸࠵௡"),rDG9dZoXRhCJcieUSF0KB(u"࠶࠸࠷࠱௣")
	elif NNwOWj5ougPHme8yXG1R7==bQGafNLXyFgsZP6ut(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪଯ"): ZwAtqYRMKSh1U,hkqipRNFP6r7vHlnJC3M,dHLQAeYlq1N0VCsoX9x = [VhqD3zp7mUieI8sMQlETH(u"࠵࠼௨"),lCT8hfYUBX4OQMmL(u"࠶࠸௩"),rDG9dZoXRhCJcieUSF0KB(u"࠳࠻௧")],llkFwuCyhaP3sK76qO4T(u"ࠨࡗࡓࡔࡊࡘࠧର"),kPCxIUZb1V(u"࠲࠴࠺࠴௦")
	Clz05VYMcKDIy68,wRpVz7XMW8aHdKc5otFfCBj,wn7hOaTifC1yvcM = ZwAtqYRMKSh1U
	t57kZ2SOgmpEFz = EFJp4qZUo6cb3BDMzXOySgfT.truetype(TiszRA9jGVP8oQIyl3S,size=Clz05VYMcKDIy68)
	SLi5hHdTOvVxjyF3 = EFJp4qZUo6cb3BDMzXOySgfT.truetype(TiszRA9jGVP8oQIyl3S,size=wRpVz7XMW8aHdKc5otFfCBj)
	r1rIj6V2uxWnsiegHJTYOCh0t = EFJp4qZUo6cb3BDMzXOySgfT.truetype(TiszRA9jGVP8oQIyl3S,size=wn7hOaTifC1yvcM)
	DgxGL3HyFfrk05zvOw = dHLQAeYlq1N0VCsoX9x-qN7pau4isyPSMDmbtTwRBnV12*Tb7oymMnpflsSv3eu4Pz2
	SUKj3kMe7RaLvYHAZ = O7Ii4SVuMRZQCbmYt.new(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡕࡋࡇࡇࠧ଱"),(DgxGL3HyFfrk05zvOw,fmkZtbRj3ux(u"࠶࠶࠰௪")),(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠵࠶௫"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠵࠶௫"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠵࠶௫"),wTLFCOcM26fmYlW7U))
	tY5bkK8eXuIi2QjTEL = D7jhmAFZBVYLJWeot1l2.Draw(SUKj3kMe7RaLvYHAZ)
	qsKPkTw7YHEfF5NJem,EUOTGezino1Nl = tY5bkK8eXuIi2QjTEL.textsize(Gj3rMP1Cb8wHdp49la0(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬଲ"),font=t57kZ2SOgmpEFz)
	MMsAStEnd6bN5hgq4oj,aVpukldAL78nv5PSgoti4Neq = tY5bkK8eXuIi2QjTEL.textsize(lCT8hfYUBX4OQMmL(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ଳ"),font=SLi5hHdTOvVxjyF3)
	NY8E7sMVBW3j01XKHLrc = {jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡮ࡡࡳࡣ࡮ࡥࡹ࠭଴"):Z19pUxa2gfGMNKoDsEuytn85SjFvA,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡳࡶࡲࡳࡳࡷࡺ࡟࡭࡫ࡪࡥࡹࡻࡲࡦࡵࠪଵ"):y0yvdNOZkiKEg5RLMhoDVQAB9F2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡂࡔࡄࡆࡎࡉࠠࡍࡋࡊࡅ࡙࡛ࡒࡆࠢࡄࡐࡑࡇࡈࠨଶ"):Z19pUxa2gfGMNKoDsEuytn85SjFvA}
	from arabic_reshaper import ArabicReshaper as KCWwf7A4rbtUiY82I9ZvBmcp
	k3X6putOqczUDlxyhY2wQdA9VnJKEB = KCWwf7A4rbtUiY82I9ZvBmcp(configuration=NY8E7sMVBW3j01XKHLrc)
	oFMsU7bYwXB3GO2 = {}
	yFMcqNIHehz0 = locals()
	for j5eZi43FxprNKqGoQz1tV in yFMcqNIHehz0: oFMsU7bYwXB3GO2[j5eZi43FxprNKqGoQz1tV] = yFMcqNIHehz0[j5eZi43FxprNKqGoQz1tV]
	return oFMsU7bYwXB3GO2
def nS5v9m8CMXHAjwYVlJbE(oFMsU7bYwXB3GO2,jxgz5GIu1ULM3dsBne4RF8iX0,DHJUFN7lvz,jBqZanbQDEmXpsvhYu2KwGd9A,hGJ4ACLwx5I,eIRJAgj25bzvNik48puZl3OPUq,NNwOWj5ougPHme8yXG1R7,S1ztx8pZ26qyMvdiKQe,uBrfTS5k4691,pyeUiLGXzEPtsZ):
	for j5eZi43FxprNKqGoQz1tV in oFMsU7bYwXB3GO2: globals()[j5eZi43FxprNKqGoQz1tV] = oFMsU7bYwXB3GO2[j5eZi43FxprNKqGoQz1tV]
	global K8RVT3qfhyN1oeHFunDMzkj,tMI4STV57fjiclsOmkXa0PLourKz
	if NNwOWj5ougPHme8yXG1R7!=vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫଷ"):
		SKxLc7CqZV9gw = OOnvcPQy85HYA.getSetting(TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪସ"))
		if SKxLc7CqZV9gw:
			if jxgz5GIu1ULM3dsBne4RF8iX0==TNw1pBHb8CtSZe0EFxuJqI(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬହ"): jxgz5GIu1ULM3dsBne4RF8iX0 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࡞࡫ࡳࠨ଺")
			elif jxgz5GIu1ULM3dsBne4RF8iX0==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"้ࠬไศࠢࠣࡒࡴ࠭଻"): jxgz5GIu1ULM3dsBne4RF8iX0 = xm6jK1ZMuWq5(u"࠭ࡎࡰ଼ࠩ")
			if DHJUFN7lvz==w8JC1y7Lp3(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩଽ"): DHJUFN7lvz = Gj3rMP1Cb8wHdp49la0(u"ࠨ࡛ࡨࡷࠬା")
			elif DHJUFN7lvz==llkFwuCyhaP3sK76qO4T(u"ࠩๆ่ฬࠦࠠࡏࡱࠪି"): DHJUFN7lvz = it4DKnryZlx(u"ࠪࡒࡴ࠭ୀ")
			if jBqZanbQDEmXpsvhYu2KwGd9A==s149dk8uh2p7oFzaLxZeI3Or(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ୁ"): jBqZanbQDEmXpsvhYu2KwGd9A = fmkZtbRj3ux(u"ࠬ࡟ࡥࡴࠩୂ")
			elif jBqZanbQDEmXpsvhYu2KwGd9A==VhqD3zp7mUieI8sMQlETH(u"࠭ใๅษࠣࠤࡓࡵࠧୃ"): jBqZanbQDEmXpsvhYu2KwGd9A = erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡏࡱࠪୄ")
			import td9O3TPvz2
			lKT2nBXgyoJcN8m4 = td9O3TPvz2.H9lo1B3RAJDQSv7fOCUKzhsTLp0([jxgz5GIu1ULM3dsBne4RF8iX0,DHJUFN7lvz,jBqZanbQDEmXpsvhYu2KwGd9A,hGJ4ACLwx5I,eIRJAgj25bzvNik48puZl3OPUq])
			if lKT2nBXgyoJcN8m4: jxgz5GIu1ULM3dsBne4RF8iX0,DHJUFN7lvz,jBqZanbQDEmXpsvhYu2KwGd9A,hGJ4ACLwx5I,eIRJAgj25bzvNik48puZl3OPUq = lKT2nBXgyoJcN8m4
	if ndib93Ol6UojCrEV:
		eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		hGJ4ACLwx5I = hGJ4ACLwx5I.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		jxgz5GIu1ULM3dsBne4RF8iX0 = jxgz5GIu1ULM3dsBne4RF8iX0.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		DHJUFN7lvz = DHJUFN7lvz.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		jBqZanbQDEmXpsvhYu2KwGd9A = jBqZanbQDEmXpsvhYu2KwGd9A.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	VyYJHpPQ4Tv7CwzcXK9shi = hGJ4ACLwx5I.count(QWLr8ABjev)+UD4N8MjVTd
	NF7Cvnj8ri0XPqocML5B1KzwaTyJE = QiZ7V0wUNHvPoqFgAEy8+VyYJHpPQ4Tv7CwzcXK9shi*(EUOTGezino1Nl+BkFiCxp3l2tAPQqLYoVhcwEy1ZfIzU)-BkFiCxp3l2tAPQqLYoVhcwEy1ZfIzU
	if eIRJAgj25bzvNik48puZl3OPUq:
		bvQwaf0Pg3usBrh = aVpukldAL78nv5PSgoti4Neq+sRpWaAlZQ4gt2uPJF
		vv3pbWXqNE76DHK = k3X6putOqczUDlxyhY2wQdA9VnJKEB.reshape(eIRJAgj25bzvNik48puZl3OPUq)
		if dP1RyO45bZTLX6elWnacvSKrj9uA8:
			w0Ag8B1Qkulcdh3LaoiVtef = thgnJlXi5fIrmDNPUjBM8GuxeVAd(tY5bkK8eXuIi2QjTEL,SLi5hHdTOvVxjyF3,vv3pbWXqNE76DHK,wRpVz7XMW8aHdKc5otFfCBj,DgxGL3HyFfrk05zvOw,bvQwaf0Pg3usBrh)
			TZ5vsbdSj3nAphQJNBx9cXLKGiqRl = qA9IVWMQ3Kvsf4wHa(w0Ag8B1Qkulcdh3LaoiVtef)
			o2oe8wAlTRpzi3IKSMXd = TZ5vsbdSj3nAphQJNBx9cXLKGiqRl.count(QWLr8ABjev)+UD4N8MjVTd
			h7Lvr61KbFS9s5JfeolRpI4Ec = C3iKbdqMgPwF+o2oe8wAlTRpzi3IKSMXd*bvQwaf0Pg3usBrh-sRpWaAlZQ4gt2uPJF
		else:
			h7Lvr61KbFS9s5JfeolRpI4Ec = C3iKbdqMgPwF+aVpukldAL78nv5PSgoti4Neq
			TZ5vsbdSj3nAphQJNBx9cXLKGiqRl = vv3pbWXqNE76DHK.split(QWLr8ABjev)[wTLFCOcM26fmYlW7U]
			w0Ag8B1Qkulcdh3LaoiVtef = vv3pbWXqNE76DHK.split(QWLr8ABjev)[wTLFCOcM26fmYlW7U]
	else: h7Lvr61KbFS9s5JfeolRpI4Ec = C3iKbdqMgPwF
	gtc4ywRi8LuPMe = FvGjbIxADV2iJTRNWMEBd+JmNUZGyzewCsIpVSn2QcvE5iDx8Kb
	if uBrfTS5k4691:
		xxvqFPrQR4 = P8bymZLsReVFn01HQr2wA-uUd0xfj67BWicgMpv9AREXY
		gtc4ywRi8LuPMe += xxvqFPrQR4
	else: xxvqFPrQR4 = wTLFCOcM26fmYlW7U
	if jxgz5GIu1ULM3dsBne4RF8iX0 or DHJUFN7lvz or jBqZanbQDEmXpsvhYu2KwGd9A: gtc4ywRi8LuPMe += BOXTaNZHDobP21k843utcdEQfl6w
	mjic76Ubun5po3sMyTQSxEIZfRd = hkqipRNFP6r7vHlnJC3M if hkqipRNFP6r7vHlnJC3M!=yRWQMHxZEz0(u"ࠨࡗࡓࡔࡊࡘࠧ୅") else NF7Cvnj8ri0XPqocML5B1KzwaTyJE+h7Lvr61KbFS9s5JfeolRpI4Ec+gtc4ywRi8LuPMe
	SUKj3kMe7RaLvYHAZ = O7Ii4SVuMRZQCbmYt.new(bQGafNLXyFgsZP6ut(u"ࠩࡕࡋࡇࡇࠧ୆"),(dHLQAeYlq1N0VCsoX9x,mjic76Ubun5po3sMyTQSxEIZfRd),(bQGafNLXyFgsZP6ut(u"࠲࠶࠷௬"),bQGafNLXyFgsZP6ut(u"࠲࠶࠷௬"),bQGafNLXyFgsZP6ut(u"࠲࠶࠷௬"),wTLFCOcM26fmYlW7U))
	HH1FGl9MZh0Sdcr6DWYnKxJU4v = D7jhmAFZBVYLJWeot1l2.Draw(SUKj3kMe7RaLvYHAZ)
	GrcwBfEL5ZbOD7e08MI1qQyRF = mjic76Ubun5po3sMyTQSxEIZfRd-NF7Cvnj8ri0XPqocML5B1KzwaTyJE-gtc4ywRi8LuPMe-C3iKbdqMgPwF
	if not DHJUFN7lvz and jxgz5GIu1ULM3dsBne4RF8iX0 and jBqZanbQDEmXpsvhYu2KwGd9A:
		K8RVT3qfhyN1oeHFunDMzkj += it4DKnryZlx(u"࠲࠲࠸௭")
		tMI4STV57fjiclsOmkXa0PLourKz -= MFhbWia58mP3su0fk2d(u"࠳࠴࠴௮")
	import bidi.algorithm as HCtXsV0NOcph1Tzl5y7
	if hGJ4ACLwx5I:
		jmBywWQau10leh2 = QiZ7V0wUNHvPoqFgAEy8
		hGJ4ACLwx5I = HCtXsV0NOcph1Tzl5y7.get_display(k3X6putOqczUDlxyhY2wQdA9VnJKEB.reshape(hGJ4ACLwx5I))
		tSszk5Zhc4KwIiFLx2Ue1yv = hGJ4ACLwx5I.splitlines()
		for iKT4uUnJygfFlZtLQWVqbdH in tSszk5Zhc4KwIiFLx2Ue1yv:
			if iKT4uUnJygfFlZtLQWVqbdH:
				VwSlW3gI60ZMHFBo,nkPHfcWT0taRboUDMEG = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(iKT4uUnJygfFlZtLQWVqbdH,font=t57kZ2SOgmpEFz)
				if RwS8n2ANl1KiVbyvpF==A6Sg45ChDR3BJLYfFH(u"ࠪࡧࡪࡴࡴࡦࡴࠪେ"): WYJusUOyA5c6P4BfmvkZDtzoRI = FFmRkSltHTd52b1pLj+(dHLQAeYlq1N0VCsoX9x-VwSlW3gI60ZMHFBo)/Tb7oymMnpflsSv3eu4Pz2
				elif RwS8n2ANl1KiVbyvpF==MFhbWia58mP3su0fk2d(u"ࠫࡷ࡯ࡧࡩࡶࠪୈ"): WYJusUOyA5c6P4BfmvkZDtzoRI = FFmRkSltHTd52b1pLj+dHLQAeYlq1N0VCsoX9x-VwSlW3gI60ZMHFBo-j3GHcsARSJC4OwPVQ
				elif RwS8n2ANl1KiVbyvpF==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡲࡥࡧࡶࠪ୉"): WYJusUOyA5c6P4BfmvkZDtzoRI = FFmRkSltHTd52b1pLj+j3GHcsARSJC4OwPVQ
				HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((WYJusUOyA5c6P4BfmvkZDtzoRI,jmBywWQau10leh2),iKT4uUnJygfFlZtLQWVqbdH,font=t57kZ2SOgmpEFz,fill=dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭୊"))
			jmBywWQau10leh2 += Clz05VYMcKDIy68+BkFiCxp3l2tAPQqLYoVhcwEy1ZfIzU
	if jxgz5GIu1ULM3dsBne4RF8iX0 or DHJUFN7lvz or jBqZanbQDEmXpsvhYu2KwGd9A:
		ymbLTa4OBx = NF7Cvnj8ri0XPqocML5B1KzwaTyJE+GrcwBfEL5ZbOD7e08MI1qQyRF+C3iKbdqMgPwF+xxvqFPrQR4+FvGjbIxADV2iJTRNWMEBd
		if jxgz5GIu1ULM3dsBne4RF8iX0:
			jxgz5GIu1ULM3dsBne4RF8iX0 = HCtXsV0NOcph1Tzl5y7.get_display(k3X6putOqczUDlxyhY2wQdA9VnJKEB.reshape(jxgz5GIu1ULM3dsBne4RF8iX0))
			CCkIT7bZqvV8a,MrC4Jz9vec8fuOKlZ0F6pYaoG3 = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(jxgz5GIu1ULM3dsBne4RF8iX0,font=r1rIj6V2uxWnsiegHJTYOCh0t)
			DCh7P8VvwrOsx = K8RVT3qfhyN1oeHFunDMzkj+wTLFCOcM26fmYlW7U*(tMI4STV57fjiclsOmkXa0PLourKz+ZxjhN4obtT)+(ZxjhN4obtT-CCkIT7bZqvV8a)/Tb7oymMnpflsSv3eu4Pz2
			HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((DCh7P8VvwrOsx,ymbLTa4OBx),jxgz5GIu1ULM3dsBne4RF8iX0,font=r1rIj6V2uxWnsiegHJTYOCh0t,fill=Gj3rMP1Cb8wHdp49la0(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧୋ"))
		if DHJUFN7lvz:
			DHJUFN7lvz = HCtXsV0NOcph1Tzl5y7.get_display(k3X6putOqczUDlxyhY2wQdA9VnJKEB.reshape(DHJUFN7lvz))
			VIJWZN5ulOYSQ9yoAv,LLbCuNHamBfZPwshY = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(DHJUFN7lvz,font=r1rIj6V2uxWnsiegHJTYOCh0t)
			zkTOI3aVLR27ZnbNl = K8RVT3qfhyN1oeHFunDMzkj+UD4N8MjVTd*(tMI4STV57fjiclsOmkXa0PLourKz+ZxjhN4obtT)+(ZxjhN4obtT-VIJWZN5ulOYSQ9yoAv)/Tb7oymMnpflsSv3eu4Pz2
			HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((zkTOI3aVLR27ZnbNl,ymbLTa4OBx),DHJUFN7lvz,font=r1rIj6V2uxWnsiegHJTYOCh0t,fill=w8JC1y7Lp3(u"ࠨࡻࡨࡰࡱࡵࡷࠨୌ"))
		if jBqZanbQDEmXpsvhYu2KwGd9A:
			jBqZanbQDEmXpsvhYu2KwGd9A = HCtXsV0NOcph1Tzl5y7.get_display(k3X6putOqczUDlxyhY2wQdA9VnJKEB.reshape(jBqZanbQDEmXpsvhYu2KwGd9A))
			HtXYdwCAFIR,wMedytgfXOp8TYzUs0W9o3bvZHN6 = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(jBqZanbQDEmXpsvhYu2KwGd9A,font=r1rIj6V2uxWnsiegHJTYOCh0t)
			iuowYmz7jK9VE02PaeUghlQTASf = K8RVT3qfhyN1oeHFunDMzkj+Tb7oymMnpflsSv3eu4Pz2*(tMI4STV57fjiclsOmkXa0PLourKz+ZxjhN4obtT)+(ZxjhN4obtT-HtXYdwCAFIR)/Tb7oymMnpflsSv3eu4Pz2
			HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((iuowYmz7jK9VE02PaeUghlQTASf,ymbLTa4OBx),jBqZanbQDEmXpsvhYu2KwGd9A,font=r1rIj6V2uxWnsiegHJTYOCh0t,fill=jQv0du1iVxTgAXCM(u"ࠩࡼࡩࡱࡲ࡯ࡸ୍ࠩ"))
	if eIRJAgj25bzvNik48puZl3OPUq:
		kkgwZ6fot1sh,WWjrqpkGm7hLeAgX8EndMBxIf = [],[]
		w0Ag8B1Qkulcdh3LaoiVtef = QIaG5CAZq0Mp6FDbvfo9dlPSN(w0Ag8B1Qkulcdh3LaoiVtef)
		RIdqN5njlamFeWUVc = w0Ag8B1Qkulcdh3LaoiVtef.split(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ୎"))
		for jnFwYphLkbSGsIOreCKP2X in RIdqN5njlamFeWUVc:
			HnhvY3dK5N7LqfPXArEpG9w = S1ztx8pZ26qyMvdiKQe
			if   llkFwuCyhaP3sK76qO4T(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭୏") in jnFwYphLkbSGsIOreCKP2X: HnhvY3dK5N7LqfPXArEpG9w = kPCxIUZb1V(u"ࠬࡲࡥࡧࡶࠪ୐")
			elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ୑") in jnFwYphLkbSGsIOreCKP2X: HnhvY3dK5N7LqfPXArEpG9w = MFhbWia58mP3su0fk2d(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭୒")
			elif gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ୓") in jnFwYphLkbSGsIOreCKP2X: HnhvY3dK5N7LqfPXArEpG9w = yRWQMHxZEz0(u"ࠩࡦࡩࡳࡺࡥࡳࠩ୔")
			qq2CrHIuRNwVf5 = jnFwYphLkbSGsIOreCKP2X
			bTkIroLMutSECilp1O7WhyN = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ୕"),jnFwYphLkbSGsIOreCKP2X,jj0dZrgiKb.DOTALL)
			for k4Wc9DBZ68wsFe in bTkIroLMutSECilp1O7WhyN: qq2CrHIuRNwVf5 = qq2CrHIuRNwVf5.replace(k4Wc9DBZ68wsFe,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if qq2CrHIuRNwVf5==wUvcPrYDfISbZolAm83GKEqMyXkn5: VwSlW3gI60ZMHFBo,nkPHfcWT0taRboUDMEG = wTLFCOcM26fmYlW7U,bvQwaf0Pg3usBrh
			else: VwSlW3gI60ZMHFBo,nkPHfcWT0taRboUDMEG = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(qq2CrHIuRNwVf5,font=SLi5hHdTOvVxjyF3)
			if   HnhvY3dK5N7LqfPXArEpG9w==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡱ࡫ࡦࡵࠩୖ"): msTOuK1FEBXywgIzr2NkYDMp9cqlZ = Mut6PeKdT3rlvbj8Ekm5h2UB0czog+qN7pau4isyPSMDmbtTwRBnV12
			elif HnhvY3dK5N7LqfPXArEpG9w==DpRJnas65uVcO0S17dYG(u"ࠬࡸࡩࡨࡪࡷࠫୗ"): msTOuK1FEBXywgIzr2NkYDMp9cqlZ = Mut6PeKdT3rlvbj8Ekm5h2UB0czog+qN7pau4isyPSMDmbtTwRBnV12+DgxGL3HyFfrk05zvOw-VwSlW3gI60ZMHFBo
			elif HnhvY3dK5N7LqfPXArEpG9w==xdSThjYnuHXAU6M(u"࠭ࡣࡦࡰࡷࡩࡷ࠭୘"): msTOuK1FEBXywgIzr2NkYDMp9cqlZ = Mut6PeKdT3rlvbj8Ekm5h2UB0czog+qN7pau4isyPSMDmbtTwRBnV12+(DgxGL3HyFfrk05zvOw-VwSlW3gI60ZMHFBo)/Tb7oymMnpflsSv3eu4Pz2
			if msTOuK1FEBXywgIzr2NkYDMp9cqlZ<qN7pau4isyPSMDmbtTwRBnV12: msTOuK1FEBXywgIzr2NkYDMp9cqlZ = Mut6PeKdT3rlvbj8Ekm5h2UB0czog+qN7pau4isyPSMDmbtTwRBnV12
			kkgwZ6fot1sh.append(msTOuK1FEBXywgIzr2NkYDMp9cqlZ)
			WWjrqpkGm7hLeAgX8EndMBxIf.append(VwSlW3gI60ZMHFBo)
		msTOuK1FEBXywgIzr2NkYDMp9cqlZ = kkgwZ6fot1sh[wTLFCOcM26fmYlW7U]
		C9z5P7BTnZkMHu8d = w0Ag8B1Qkulcdh3LaoiVtef.split(weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡠࡵࡶࡷࡤ࠭୙"))
		GdnK6sVBOkHe9vgEQ1Nj0 = (w8JC1y7Lp3(u"࠵࠹࠺௯"),w8JC1y7Lp3(u"࠵࠹࠺௯"),w8JC1y7Lp3(u"࠵࠹࠺௯"),w8JC1y7Lp3(u"࠵࠹࠺௯"))
		AjmuRICldHZqhb = GdnK6sVBOkHe9vgEQ1Nj0
		S8IQnpDJwm4Cb9i,FQOVNXsG4qCBMEjP = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
		xzIr4vawfLbFlWBC2k5AoJsyXVue = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		PKtFuAImczJebdpMrX46wq1G283S = wTLFCOcM26fmYlW7U
		CDG6N9Brsi2OmYkIqLH347lS5 = NF7Cvnj8ri0XPqocML5B1KzwaTyJE+C3iKbdqMgPwF/Tb7oymMnpflsSv3eu4Pz2
		if h7Lvr61KbFS9s5JfeolRpI4Ec<(GrcwBfEL5ZbOD7e08MI1qQyRF+C3iKbdqMgPwF):
			DBCq5324gk = (GrcwBfEL5ZbOD7e08MI1qQyRF+C3iKbdqMgPwF-h7Lvr61KbFS9s5JfeolRpI4Ec)/Tb7oymMnpflsSv3eu4Pz2
			CDG6N9Brsi2OmYkIqLH347lS5 = NF7Cvnj8ri0XPqocML5B1KzwaTyJE+C3iKbdqMgPwF+DBCq5324gk-aVpukldAL78nv5PSgoti4Neq/Tb7oymMnpflsSv3eu4Pz2
		for iKT4uUnJygfFlZtLQWVqbdH in C9z5P7BTnZkMHu8d:
			if not iKT4uUnJygfFlZtLQWVqbdH or (iKT4uUnJygfFlZtLQWVqbdH and ord(iKT4uUnJygfFlZtLQWVqbdH[wTLFCOcM26fmYlW7U])==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠺࠺࠸࠷࠺௰")): continue
			t8gs9BbIUlDa5WRNiTQS41GmA = iKT4uUnJygfFlZtLQWVqbdH.split(vWNRusF46D7Mi8GpZ(u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ୚"),UD4N8MjVTd)
			G0BLNmt6xKu = iKT4uUnJygfFlZtLQWVqbdH.split(JHMxIE4fs1mvQtKW7R(u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ୛"),UD4N8MjVTd)
			fUy5Vm1doW92 = iKT4uUnJygfFlZtLQWVqbdH.split(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧଡ଼"),UD4N8MjVTd)
			YKShQpRMLrsVxkgbIuAn1CtD4yed = iKT4uUnJygfFlZtLQWVqbdH.split(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧଢ଼"),UD4N8MjVTd)
			zdXNGkCF1g2Jw8BWQ63bqIvr5OL = iKT4uUnJygfFlZtLQWVqbdH.split(vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ୞"),UD4N8MjVTd)
			IYaHF9XtOx2CcEqk = iKT4uUnJygfFlZtLQWVqbdH.split(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫୟ"),UD4N8MjVTd)
			EV7T4ZeOPi = iKT4uUnJygfFlZtLQWVqbdH.split(lCT8hfYUBX4OQMmL(u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭ୠ"),UD4N8MjVTd)
			if len(t8gs9BbIUlDa5WRNiTQS41GmA)>UD4N8MjVTd:
				PKtFuAImczJebdpMrX46wq1G283S += UD4N8MjVTd
				iKT4uUnJygfFlZtLQWVqbdH = t8gs9BbIUlDa5WRNiTQS41GmA[UD4N8MjVTd]
				S8IQnpDJwm4Cb9i = wTLFCOcM26fmYlW7U
				msTOuK1FEBXywgIzr2NkYDMp9cqlZ = kkgwZ6fot1sh[PKtFuAImczJebdpMrX46wq1G283S]
				FQOVNXsG4qCBMEjP += bvQwaf0Pg3usBrh
				xzIr4vawfLbFlWBC2k5AoJsyXVue = Z19pUxa2gfGMNKoDsEuytn85SjFvA
			elif len(G0BLNmt6xKu)>UD4N8MjVTd:
				iKT4uUnJygfFlZtLQWVqbdH = G0BLNmt6xKu[UD4N8MjVTd]
				AjmuRICldHZqhb = iKT4uUnJygfFlZtLQWVqbdH[wTLFCOcM26fmYlW7U:jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠽௱")]
				AjmuRICldHZqhb = vWNRusF46D7Mi8GpZ(u"ࠨࠥࠪୡ")+AjmuRICldHZqhb[Tb7oymMnpflsSv3eu4Pz2:]
				iKT4uUnJygfFlZtLQWVqbdH = iKT4uUnJygfFlZtLQWVqbdH[it4DKnryZlx(u"࠿௲"):]
			elif len(fUy5Vm1doW92)>UD4N8MjVTd:
				iKT4uUnJygfFlZtLQWVqbdH = fUy5Vm1doW92[UD4N8MjVTd]
				AjmuRICldHZqhb = GdnK6sVBOkHe9vgEQ1Nj0
			elif len(YKShQpRMLrsVxkgbIuAn1CtD4yed)>UD4N8MjVTd:
				iKT4uUnJygfFlZtLQWVqbdH = YKShQpRMLrsVxkgbIuAn1CtD4yed[UD4N8MjVTd]
				xzIr4vawfLbFlWBC2k5AoJsyXVue = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				S8IQnpDJwm4Cb9i = WWjrqpkGm7hLeAgX8EndMBxIf[PKtFuAImczJebdpMrX46wq1G283S]
			elif len(zdXNGkCF1g2Jw8BWQ63bqIvr5OL)>weh7SGmuTgXOVRcMo1rlLq(u"࠱௳"): iKT4uUnJygfFlZtLQWVqbdH = zdXNGkCF1g2Jw8BWQ63bqIvr5OL[UD4N8MjVTd]
			elif len(IYaHF9XtOx2CcEqk)>xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠲௴"): iKT4uUnJygfFlZtLQWVqbdH = IYaHF9XtOx2CcEqk[UD4N8MjVTd]
			elif len(EV7T4ZeOPi)>JHMxIE4fs1mvQtKW7R(u"࠳௵"): iKT4uUnJygfFlZtLQWVqbdH = EV7T4ZeOPi[UD4N8MjVTd]
			if iKT4uUnJygfFlZtLQWVqbdH:
				Lgx0CEMRBH1I9wSYl8jfTKyPr = CDG6N9Brsi2OmYkIqLH347lS5+FQOVNXsG4qCBMEjP
				iKT4uUnJygfFlZtLQWVqbdH = HCtXsV0NOcph1Tzl5y7.get_display(iKT4uUnJygfFlZtLQWVqbdH)
				VwSlW3gI60ZMHFBo,nkPHfcWT0taRboUDMEG = HH1FGl9MZh0Sdcr6DWYnKxJU4v.textsize(iKT4uUnJygfFlZtLQWVqbdH,font=SLi5hHdTOvVxjyF3)
				if xzIr4vawfLbFlWBC2k5AoJsyXVue: S8IQnpDJwm4Cb9i -= VwSlW3gI60ZMHFBo
				wat30JX7YvzTVcgOrPQG1SuHes = msTOuK1FEBXywgIzr2NkYDMp9cqlZ+S8IQnpDJwm4Cb9i
				HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((wat30JX7YvzTVcgOrPQG1SuHes,Lgx0CEMRBH1I9wSYl8jfTKyPr),iKT4uUnJygfFlZtLQWVqbdH,font=SLi5hHdTOvVxjyF3,fill=AjmuRICldHZqhb)
				if NNwOWj5ougPHme8yXG1R7==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬୢ"): HH1FGl9MZh0Sdcr6DWYnKxJU4v.text((wat30JX7YvzTVcgOrPQG1SuHes+UD4N8MjVTd,Lgx0CEMRBH1I9wSYl8jfTKyPr+UD4N8MjVTd),iKT4uUnJygfFlZtLQWVqbdH,font=SLi5hHdTOvVxjyF3,fill=AjmuRICldHZqhb)
				if not xzIr4vawfLbFlWBC2k5AoJsyXVue: S8IQnpDJwm4Cb9i += VwSlW3gI60ZMHFBo
				if Lgx0CEMRBH1I9wSYl8jfTKyPr>GrcwBfEL5ZbOD7e08MI1qQyRF+bvQwaf0Pg3usBrh: break
	if NNwOWj5ougPHme8yXG1R7==Gj3rMP1Cb8wHdp49la0(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭ୣ"):
		kdic5ImGsfL3n7PrwOeuJjh6W = TTCJUcikyFZ3HgOlB7x.copy()
		L5jXH0fZ8TvsESR.sleep(weh7SGmuTgXOVRcMo1rlLq(u"࠳࠲࠵࠻௶"))
		kdic5ImGsfL3n7PrwOeuJjh6W.paste(HjT7icm8WdYXl0Jko,(wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U),mask=SUKj3kMe7RaLvYHAZ)
	else: kdic5ImGsfL3n7PrwOeuJjh6W = SUKj3kMe7RaLvYHAZ
	if ndib93Ol6UojCrEV: pyeUiLGXzEPtsZ = pyeUiLGXzEPtsZ.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	try: kdic5ImGsfL3n7PrwOeuJjh6W.save(pyeUiLGXzEPtsZ)
	except UnicodeError:
		if ndib93Ol6UojCrEV:
			pyeUiLGXzEPtsZ = pyeUiLGXzEPtsZ.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			kdic5ImGsfL3n7PrwOeuJjh6W.save(pyeUiLGXzEPtsZ)
	return mjic76Ubun5po3sMyTQSxEIZfRd
def thgnJlXi5fIrmDNPUjBM8GuxeVAd(tY5bkK8eXuIi2QjTEL,SLi5hHdTOvVxjyF3,DD63xwY9CpsdXrS0W87flRQiakyhgG,ooHXb6EaA0zt8qIWYkDFV1cBx3wsu,DgxGL3HyFfrk05zvOw,f7bkMlCSLpEQzTnV8F6PagWHwv4X0):
	cJv5aWCBpDGo3hE,UVIbmcAYDh8CXJMPwi1yxEsB,NCF7sDKqhuHn2xjMgSYBpbEi6LW4 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠵࠺࠶࠰࠱௷")
	DD63xwY9CpsdXrS0W87flRQiakyhgG = DD63xwY9CpsdXrS0W87flRQiakyhgG.replace(jQv0du1iVxTgAXCM(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ୤"),xdSThjYnuHXAU6M(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ୥"))
	oo4zLDbGW5yQlR6jFrsO1gC = DgxGL3HyFfrk05zvOw-ooHXb6EaA0zt8qIWYkDFV1cBx3wsu*Tb7oymMnpflsSv3eu4Pz2
	for jPzxADW71rBEXcgiSpMfh6Za2dq in DD63xwY9CpsdXrS0W87flRQiakyhgG.splitlines():
		UVIbmcAYDh8CXJMPwi1yxEsB += f7bkMlCSLpEQzTnV8F6PagWHwv4X0
		ZZorNBFnKWmj4LCQM,VV3E5ByIzprxHnLqc0QiaXF = wTLFCOcM26fmYlW7U,wUvcPrYDfISbZolAm83GKEqMyXkn5
		for i1jQeRdFOLxA6f98TCp in jPzxADW71rBEXcgiSpMfh6Za2dq.split(UKFZBQAVXHI5s17LyvuRpCY2):
			vhyFNzx4nEZ6 = qA9IVWMQ3Kvsf4wHa(UKFZBQAVXHI5s17LyvuRpCY2+i1jQeRdFOLxA6f98TCp)
			FUgDasdBCz,gKYNVdLpcPlkMQJ6H1SImUx82 = tY5bkK8eXuIi2QjTEL.textsize(vhyFNzx4nEZ6,font=SLi5hHdTOvVxjyF3)
			if ZZorNBFnKWmj4LCQM+FUgDasdBCz<oo4zLDbGW5yQlR6jFrsO1gC:
				if not VV3E5ByIzprxHnLqc0QiaXF: VV3E5ByIzprxHnLqc0QiaXF += i1jQeRdFOLxA6f98TCp
				else: VV3E5ByIzprxHnLqc0QiaXF += UKFZBQAVXHI5s17LyvuRpCY2+i1jQeRdFOLxA6f98TCp
				ZZorNBFnKWmj4LCQM += FUgDasdBCz
			else:
				if FUgDasdBCz<oo4zLDbGW5yQlR6jFrsO1gC:
					VV3E5ByIzprxHnLqc0QiaXF += yRWQMHxZEz0(u"࠭࡜࡯ࠢࠪ୦")+i1jQeRdFOLxA6f98TCp
					UVIbmcAYDh8CXJMPwi1yxEsB += f7bkMlCSLpEQzTnV8F6PagWHwv4X0
					ZZorNBFnKWmj4LCQM = FUgDasdBCz
				else:
					while FUgDasdBCz>oo4zLDbGW5yQlR6jFrsO1gC:
						for TvkL6PzYlCNVfUXc2b7K9ZDxg in range(UD4N8MjVTd,len(UKFZBQAVXHI5s17LyvuRpCY2+i1jQeRdFOLxA6f98TCp),UD4N8MjVTd):
							fXzMPaV9AhD = UKFZBQAVXHI5s17LyvuRpCY2+i1jQeRdFOLxA6f98TCp[:TvkL6PzYlCNVfUXc2b7K9ZDxg]
							OrDLEUb12zsJxVCAB06Y4vteaMwlX = i1jQeRdFOLxA6f98TCp[TvkL6PzYlCNVfUXc2b7K9ZDxg:]
							nYPkG5bOjB7qhcJa = qA9IVWMQ3Kvsf4wHa(fXzMPaV9AhD)
							WSAdQa3Ffcx,bZ34h8a7M9qxmlQYHTEB5CDjVpWItd = tY5bkK8eXuIi2QjTEL.textsize(nYPkG5bOjB7qhcJa,font=SLi5hHdTOvVxjyF3)
							if ZZorNBFnKWmj4LCQM+WSAdQa3Ffcx>oo4zLDbGW5yQlR6jFrsO1gC:
								nrdBMK2qovI = FUgDasdBCz-WSAdQa3Ffcx
								VV3E5ByIzprxHnLqc0QiaXF += fXzMPaV9AhD+QWLr8ABjev
								UVIbmcAYDh8CXJMPwi1yxEsB += f7bkMlCSLpEQzTnV8F6PagWHwv4X0
								FUgDasdBCz = nrdBMK2qovI
								if nrdBMK2qovI>oo4zLDbGW5yQlR6jFrsO1gC:
									ZZorNBFnKWmj4LCQM = wTLFCOcM26fmYlW7U
									i1jQeRdFOLxA6f98TCp = OrDLEUb12zsJxVCAB06Y4vteaMwlX
								else:
									ZZorNBFnKWmj4LCQM = nrdBMK2qovI
									VV3E5ByIzprxHnLqc0QiaXF += OrDLEUb12zsJxVCAB06Y4vteaMwlX
								break
				if UVIbmcAYDh8CXJMPwi1yxEsB>NCF7sDKqhuHn2xjMgSYBpbEi6LW4: break
		cJv5aWCBpDGo3hE += QWLr8ABjev+VV3E5ByIzprxHnLqc0QiaXF
		if UVIbmcAYDh8CXJMPwi1yxEsB>NCF7sDKqhuHn2xjMgSYBpbEi6LW4: break
	cJv5aWCBpDGo3hE = cJv5aWCBpDGo3hE[UD4N8MjVTd:]
	cJv5aWCBpDGo3hE = cJv5aWCBpDGo3hE.replace(JHMxIE4fs1mvQtKW7R(u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ୧"),Gj3rMP1Cb8wHdp49la0(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ୨"))
	return cJv5aWCBpDGo3hE
def qA9IVWMQ3Kvsf4wHa(i1jQeRdFOLxA6f98TCp):
	if rDG9dZoXRhCJcieUSF0KB(u"ࠩ࡞ࠫ୩") in i1jQeRdFOLxA6f98TCp and DpRJnas65uVcO0S17dYG(u"ࠪࡡࠬ୪") in i1jQeRdFOLxA6f98TCp:
		bTkIroLMutSECilp1O7WhyN = [AAByQSLgaZwCsKnvc5eWNmY,xm6jK1ZMuWq5(u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ୫"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭୬"),w8JC1y7Lp3(u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨ୭"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ୮"),A6Sg45ChDR3BJLYfFH(u"ࠨ࡝ࡕࡘࡑࡣࠧ୯"),rDG9dZoXRhCJcieUSF0KB(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ୰"),xdSThjYnuHXAU6M(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫୱ"),jQv0du1iVxTgAXCM(u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭୲")]
		cBa7oFexREJGy1pKdi = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬ୳"),i1jQeRdFOLxA6f98TCp,jj0dZrgiKb.DOTALL)
		JK8Hdp5msNeU1hI0untBf = jj0dZrgiKb.findall(s149dk8uh2p7oFzaLxZeI3Or(u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨ୴"),i1jQeRdFOLxA6f98TCp,jj0dZrgiKb.DOTALL)
		OT4aM1pqB9Ji5WyVEumsoHxefwAN = bTkIroLMutSECilp1O7WhyN+cBa7oFexREJGy1pKdi+JK8Hdp5msNeU1hI0untBf
		for k4Wc9DBZ68wsFe in OT4aM1pqB9Ji5WyVEumsoHxefwAN: i1jQeRdFOLxA6f98TCp = i1jQeRdFOLxA6f98TCp.replace(k4Wc9DBZ68wsFe,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	return i1jQeRdFOLxA6f98TCp
def QIaG5CAZq0Mp6FDbvfo9dlPSN(eIRJAgj25bzvNik48puZl3OPUq):
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(QWLr8ABjev,lCT8hfYUBX4OQMmL(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ୵"))
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(w8JC1y7Lp3(u"ࠨ࡝ࡕࡘࡑࡣࠧ୶"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ୷"))
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪ୸"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭୹"))
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭୺"),kPCxIUZb1V(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ୻"))
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(xm6jK1ZMuWq5(u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ୼"),bQGafNLXyFgsZP6ut(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ୽"))
	eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(AAByQSLgaZwCsKnvc5eWNmY,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ୾"))
	pewUBjVLyc7q9hMW6vK0HunYDG3 = jj0dZrgiKb.findall(lCT8hfYUBX4OQMmL(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ୿"),eIRJAgj25bzvNik48puZl3OPUq,jj0dZrgiKb.DOTALL)
	for ffko1lngawciDHB7Qe52ZIFsOhUK3 in pewUBjVLyc7q9hMW6vK0HunYDG3: eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.replace(kPCxIUZb1V(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ஀")+ffko1lngawciDHB7Qe52ZIFsOhUK3+it4DKnryZlx(u"ࠬࡣࠧ஁"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧஂ")+ffko1lngawciDHB7Qe52ZIFsOhUK3+Gj3rMP1Cb8wHdp49la0(u"ࠧࡠࠩஃ"))
	return eIRJAgj25bzvNik48puZl3OPUq