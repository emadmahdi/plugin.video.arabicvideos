# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'ARABICTOONS'
UT69hgqoKsWNIwM5zkAYb = '_ART_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==730: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==731: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==732: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==733: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==734: RCmHBOKtejQ8lu4L = KWpbLJaRF06OsXC3IrTtgGDqBYl8(url)
	elif mode==735: RCmHBOKtejQ8lu4L = sUXcWG85oxZhgiQ(url)
	elif mode==739: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,739,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'افلام',hhD7r1VvaPt3TC06SJjqKRfEid+'/movies.php',731)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مسلسلات',hhD7r1VvaPt3TC06SJjqKRfEid+'/cartoon.php',734)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مسلسلات مميزة',hhD7r1VvaPt3TC06SJjqKRfEid+'/top.php',735)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أحدث الأفلام المضافة',hhD7r1VvaPt3TC06SJjqKRfEid,731,'','','LATEST_MOVIES')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أحدث المسلسلات المضافة',hhD7r1VvaPt3TC06SJjqKRfEid,731,'','','LATEST_SERIES')
	return
def KWpbLJaRF06OsXC3IrTtgGDqBYl8(url):
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الكل',url,731)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-SERIES_SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('label="navigation"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall("href='(.*?)'>(.*?)</a>",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = 'حرف '+title
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,731)
	return
def sUXcWG85oxZhgiQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-SERIES_FEATURED-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="slider"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,733,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def HPdaS7kenW0m(url,ySY5NxERP6jeVG):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("class='moviesBlocks(.*?)list-group",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ySY5NxERP6jeVG=='LATEST_SERIES': IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[1]
	else: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if 'movies.php' in url or ySY5NxERP6jeVG=='LATEST_MOVIES':
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,732,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,733,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[-1]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,731)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("class='moviesBlocks(.*?)script",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,u51lmKTqrnD4Spx in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			title = title+UKFZBQAVXHI5s17LyvuRpCY2+u51lmKTqrnD4Spx.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,732,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('source src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ppAJI9kDbz5MXa76UEF:
		hhEH1rcSP0z6Bkqy8OD = ppAJI9kDbz5MXa76UEF[0]
		if 'Referer=' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'|Referer=https://www.arabic-toons.com'
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=__embed')
	else:
		d2sKtfuYZyp5POGIb7DUzVTN0w1W98 = jj0dZrgiKb.findall(r'dynamique.*?}\);', II64TLxj3mbqEyh9pHQ8oAv, jj0dZrgiKb.DOTALL)
		if not d2sKtfuYZyp5POGIb7DUzVTN0w1W98: d2sKtfuYZyp5POGIb7DUzVTN0w1W98 = jj0dZrgiKb.findall(r'dynamique.*?}\)', II64TLxj3mbqEyh9pHQ8oAv, jj0dZrgiKb.DOTALL)
		if d2sKtfuYZyp5POGIb7DUzVTN0w1W98:
			AHCaNbEywTg3zUvkqeBiXpO5t6 = d2sKtfuYZyp5POGIb7DUzVTN0w1W98[0]
			kXFeuOmEVayd8 = dict(jj0dZrgiKb.findall(r'(\w+):\s*"([^"]+)"', AHCaNbEywTg3zUvkqeBiXpO5t6))
			cfH0ZUrdRFw79Qg = jj0dZrgiKb.search(r'const\s+(\w+)', AHCaNbEywTg3zUvkqeBiXpO5t6)
			f8fOVWAM0hig9ZeDJbHds = cfH0ZUrdRFw79Qg.group(1) if cfH0ZUrdRFw79Qg else ""
			keys = jj0dZrgiKb.findall(r'\$\{' + f8fOVWAM0hig9ZeDJbHds + r'\.(\w+)\}', AHCaNbEywTg3zUvkqeBiXpO5t6)
			if kXFeuOmEVayd8 and keys:
				hhEH1rcSP0z6Bkqy8OD = "%s://%s/%s?%s" % (kXFeuOmEVayd8[keys[0]], kXFeuOmEVayd8[keys[1]], kXFeuOmEVayd8[keys[2]], kXFeuOmEVayd8[keys[3]])
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=__embed')
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [wUvcPrYDfISbZolAm83GKEqMyXkn5,'m']
	wjqfDTdZiOUXgm = ['مسلسلات','افلام']
	if showDialogs:
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر النوع المطلوب:', wjqfDTdZiOUXgm)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-1: return
	else: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 0
	type = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/livesearch.php?'+type+'&q='+search
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABICTOONS-SEARCH-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if type=='m': mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,732)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,733)
	return