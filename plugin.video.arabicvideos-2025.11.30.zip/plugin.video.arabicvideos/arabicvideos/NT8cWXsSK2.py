# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SHOOFNET'
UT69hgqoKsWNIwM5zkAYb = '_SNT_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['الرئيسية','يلا شوت','دكتنا','فيديو نسائم']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==840: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==841: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==842: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==843: RCmHBOKtejQ8lu4L = ymR58kPWbDiQ(url)
	elif mode==849: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFNET-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,849,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"primary-links"(.*?)</u',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,841)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"list-categories"(.*?)</u',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,841)
	return
def HPdaS7kenW0m(url,KUOoYcT20iCLVgsw1ejzdkHp7XW=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFNET-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"home-content"(.*?)"footer"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('"overlay"','"duration"><')
		items = jj0dZrgiKb.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(' ')
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
			if 'episodes' not in KUOoYcT20iCLVgsw1ejzdkHp7XW and xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
				title = title.replace('اون لاين',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,843,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,842,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''["']pagination["'](.*?)["']footer["']''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		KUOoYcT20iCLVgsw1ejzdkHp7XW = 'episodes_pages' if 'episodes' in KUOoYcT20iCLVgsw1ejzdkHp7XW else 'pages'
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,841,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,KUOoYcT20iCLVgsw1ejzdkHp7XW)
	return
def ymR58kPWbDiQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFNET-SERIES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"category".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD: HPdaS7kenW0m(hhEH1rcSP0z6Bkqy8OD[0],'episodes')
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFNET-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	E2Y7y4Av63tqhSVQ50iTmN = jj0dZrgiKb.findall("var post_id	= '(.*?)'",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if E2Y7y4Av63tqhSVQ50iTmN:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-admin/admin-ajax.php?action=video_info&post_id='+E2Y7y4Av63tqhSVQ50iTmN[0]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHOOFNET-PLAY-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		items = jj0dZrgiKb.findall('"name":"(.*?)","src":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('\\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(url,'search')
	return