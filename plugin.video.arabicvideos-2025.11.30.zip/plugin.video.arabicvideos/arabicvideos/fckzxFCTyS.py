# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SHAHIDNEWS'
UT69hgqoKsWNIwM5zkAYb = '_SHN_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['قنوات فضائية','فارسكو','Show more']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==580: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==581: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==582: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==583: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url,text)
	elif mode==584: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==589: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHIDNEWS-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,589,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('/category.php">(.*?)"navslide-divider"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("'dropdown-menu'(.*?)</ul>",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for i9eu0gvptXjKMAczZyE in pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace(i9eu0gvptXjKMAczZyE,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,584)
	return
def FFJX0sguE92DxYGmoQAeV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHIDNEWS-SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"caret"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if i7swfV8rtlpOd3K6SUDk9yn0P:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('"presentation"','</ul>')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = [(wUvcPrYDfISbZolAm83GKEqMyXkn5,IJE2xcV7OWauUKhfik56gXBwltCb)]
		mwOxEyYAg63B('link',JegF7SlMawI03+' فرز أو فلتر أو ترتيب '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		for pbnhKy8SN4P7tR0qCJuwaIHeGo,IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if pbnhKy8SN4P7tR0qCJuwaIHeGo: pbnhKy8SN4P7tR0qCJuwaIHeGo = pbnhKy8SN4P7tR0qCJuwaIHeGo+': '
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = pbnhKy8SN4P7tR0qCJuwaIHeGo+title
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,581)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"pm-category-subcats"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if m4z08qk6gJ5lK:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if len(items)<30:
			mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,581)
	if not i7swfV8rtlpOd3K6SUDk9yn0P and not m4z08qk6gJ5lK: HPdaS7kenW0m(url)
	return
def HPdaS7kenW0m(url,ySY5NxERP6jeVG=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHIDNEWS-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(data-echo=".*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"BlocksList"(.*?)"titleSectionCon"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="pm-grid"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="pm-related"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if not items: items = jj0dZrgiKb.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items: items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD).strip('/')
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
		if 'http' not in cPzpeLXs3jMCltW4ZN9BaYdfQvwS: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS.strip('/')
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
		if any(value in title for value in SSthyczaHP7fAIoi5):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,582,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and 'الحلقة' in title:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,583,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/movseries/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,581,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,583,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if ySY5NxERP6jeVG not in ['featured_movies','featured_series']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD=='#': continue
				hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,581)
		EEqHD98QhfezKTg = jj0dZrgiKb.findall('showmore" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if EEqHD98QhfezKTg:
			hhEH1rcSP0z6Bkqy8OD = EEqHD98QhfezKTg[0]
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مشاهدة المزيد',hhEH1rcSP0z6Bkqy8OD,581)
	return
def mCwqRg7HpivAQ6S(url,ajCL4NVXu0K5):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHIDNEWS-EPISODES-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('nav-seasons"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	items = []
	xomQEZ1u9fNDFc3l4vsjdIaVpYiS8 = False
	if i7swfV8rtlpOd3K6SUDk9yn0P and not ajCL4NVXu0K5:
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for ajCL4NVXu0K5,title in items:
			ajCL4NVXu0K5 = ajCL4NVXu0K5.strip('#')
			if len(items)>1: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,583,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,ajCL4NVXu0K5)
			else: xomQEZ1u9fNDFc3l4vsjdIaVpYiS8 = True
	else: xomQEZ1u9fNDFc3l4vsjdIaVpYiS8 = True
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('id="'+ajCL4NVXu0K5+'"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if m4z08qk6gJ5lK and xomQEZ1u9fNDFc3l4vsjdIaVpYiS8:
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,582)
		else:
			items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,582)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHIDNEWS-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"Playerholder".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
	if hhEH1rcSP0z6Bkqy8OD and 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
	OuJw8rnmBQchMIsqjT2 = hhEH1rcSP0z6Bkqy8OD.split('hash=')[1]
	deg2JDUOioWfbC8NcswK1RFAlk4M = OuJw8rnmBQchMIsqjT2.split('__')
	EE1P3SFWybBduQvzjRcD,ppAJI9kDbz5MXa76UEF,title = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],wUvcPrYDfISbZolAm83GKEqMyXkn5
	for jF8LiqsKNQYJen in deg2JDUOioWfbC8NcswK1RFAlk4M:
		iym3U0t6TubDBvAwdK7cxCH = ((4-len(jF8LiqsKNQYJen)%4)%4)*'='
		try:
			jF8LiqsKNQYJen = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(jF8LiqsKNQYJen+iym3U0t6TubDBvAwdK7cxCH)
			if wwMdFkWvcRYiXHB7yDrCqnKb98o: jF8LiqsKNQYJen = jF8LiqsKNQYJen.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,'ignore')
		except: pass
		EE1P3SFWybBduQvzjRcD += jF8LiqsKNQYJen
	EE1P3SFWybBduQvzjRcD = EE1P3SFWybBduQvzjRcD.replace(' = ',' => ')
	kyEja2e7PrQ0zLhtMn9NbBH = EE1P3SFWybBduQvzjRcD.splitlines()
	for hhEH1rcSP0z6Bkqy8OD in kyEja2e7PrQ0zLhtMn9NbBH:
		if '://' in hhEH1rcSP0z6Bkqy8OD: ppAJI9kDbz5MXa76UEF.append(hhEH1rcSP0z6Bkqy8OD)
	for hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
		if ' => ' in hhEH1rcSP0z6Bkqy8OD: title,hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split(' => ')
		elif 'http' in hhEH1rcSP0z6Bkqy8OD:
			title,hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('http')
			hhEH1rcSP0z6Bkqy8OD = 'http'+hhEH1rcSP0z6Bkqy8OD
		else: continue
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.strip(' ')
		if not title: title = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search.php?keywords='+search
	HPdaS7kenW0m(url)
	return