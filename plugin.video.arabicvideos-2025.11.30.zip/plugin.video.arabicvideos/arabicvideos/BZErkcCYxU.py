# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'ARABSEED'
headers = {'User-Agent':ZZIDf1A9vE0g86RMq7tpKUrzaij()}
UT69hgqoKsWNIwM5zkAYb = '_ARS_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==250: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==251: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==252: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==253: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==254: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'CATEGORIES___'+text)
	elif mode==255: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'FILTERS___'+text)
	elif mode==259: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid+'/main',wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,259,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر محدد',hhD7r1VvaPt3TC06SJjqKRfEid+'/category/اخرى',254)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر كامل',hhD7r1VvaPt3TC06SJjqKRfEid+'/category/اخرى',255)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'المميزة',hhD7r1VvaPt3TC06SJjqKRfEid+'/main',251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured_main')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'احدث الافلام',hhD7r1VvaPt3TC06SJjqKRfEid+'/main',251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'new_movies')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'احدث الحلقات',hhD7r1VvaPt3TC06SJjqKRfEid+'/main',251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'new_episodes')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('"menu__bar hide__md"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	i9eu0gvptXjKMAczZyE = m4z08qk6gJ5lK[wTLFCOcM26fmYlW7U]
	VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<',i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in VV7eQk5mj1dBNiHtrcP:
		if '/category/' not in hhEH1rcSP0z6Bkqy8OD: continue
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if title not in i6TIRax9v0EDFJs2gVtfzp and title!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,251)
	return II64TLxj3mbqEyh9pHQ8oAv
def FFJX0sguE92DxYGmoQAeV(url,type):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if 'class="SliderInSection' in II64TLxj3mbqEyh9pHQ8oAv: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الأكثر مشاهدة',url,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'most')
	if 'class="MainSlides' in II64TLxj3mbqEyh9pHQ8oAv: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'المميزة',url,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
	if 'class="LinksList' in II64TLxj3mbqEyh9pHQ8oAv:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="LinksList(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			if len(pLHIPUY3TWAeE70)>1 and type=='new_episodes': IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[1]
			items = jj0dZrgiKb.findall('href="(.*?)"(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = jj0dZrgiKb.findall('</i>(.*?)<span>(.*?)<',title,jj0dZrgiKb.DOTALL)
				try: V1VfMqTkXdYulSwF75JPhDgZ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ[0][0].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				except: V1VfMqTkXdYulSwF75JPhDgZ = wUvcPrYDfISbZolAm83GKEqMyXkn5
				try: kUcE06vfzoKBLNMVX = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ[0][1].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				except: kUcE06vfzoKBLNMVX = wUvcPrYDfISbZolAm83GKEqMyXkn5
				HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = V1VfMqTkXdYulSwF75JPhDgZ+UKFZBQAVXHI5s17LyvuRpCY2+kUcE06vfzoKBLNMVX
				if '<strong>' in title:
					IJTsX9NzrLmQ3OiPG8Eywc7ot6b = jj0dZrgiKb.findall('</i>(.*?)<',title,jj0dZrgiKb.DOTALL)
					if IJTsX9NzrLmQ3OiPG8Eywc7ot6b: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = IJTsX9NzrLmQ3OiPG8Eywc7ot6b[0]
				if not HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ:
					IJTsX9NzrLmQ3OiPG8Eywc7ot6b = jj0dZrgiKb.findall('alt="(.*?)"',title,jj0dZrgiKb.DOTALL)
					if IJTsX9NzrLmQ3OiPG8Eywc7ot6b: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = IJTsX9NzrLmQ3OiPG8Eywc7ot6b[0]
				if HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ:
					if 'key=' in hhEH1rcSP0z6Bkqy8OD: type = hhEH1rcSP0z6Bkqy8OD.split('key=')[1]
					else: type = 'newest'
					HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ.strip(UKFZBQAVXHI5s17LyvuRpCY2)
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,hhEH1rcSP0z6Bkqy8OD,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def HPdaS7kenW0m(url,mmZUvVcxAqEg0FN):
	N2t8i1vLnORq4rhK9fwFXDWe,data,items = 'GET',wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	if mmZUvVcxAqEg0FN=='filters':
		if '?' in url:
			xQRHm9PfqikcSVF5,FjUcS938pAH5sZ = 'POST',{}
			ZD5n0eJivzWOMxY98dgrumkwRG,F148a7xNcp9C = url.split('?')
			sDMqyG0jAOK = F148a7xNcp9C.split('&')
			for yqH8GM4tr32YXobgA9ZkhsSj0B in sDMqyG0jAOK:
				key,value = yqH8GM4tr32YXobgA9ZkhsSj0B.split('=')
				FjUcS938pAH5sZ[key] = value
			if sDMqyG0jAOK: N2t8i1vLnORq4rhK9fwFXDWe,url,data = xQRHm9PfqikcSVF5,ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,N2t8i1vLnORq4rhK9fwFXDWe,url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if mmZUvVcxAqEg0FN=='filters': pLHIPUY3TWAeE70 = [II64TLxj3mbqEyh9pHQ8oAv]
	elif 'featured' in mmZUvVcxAqEg0FN: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"swiper-wrapper"(.*?)</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	elif mmZUvVcxAqEg0FN=='new_movies': pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<b>احدث الافلام</b>(.*?)</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	elif mmZUvVcxAqEg0FN=='new_episodes': pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<b>احدث الحلقات</b>(.*?)</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	elif mmZUvVcxAqEg0FN=='most': pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="SliderInSection(.*?)class="LinksList',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"blocks__section(.*?)"paginate"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if 'featured' in mmZUvVcxAqEg0FN:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	else: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items: items = jj0dZrgiKb.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
		if 'WWE' in title: continue
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if 'الحلقة' in title:
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
			if xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,253,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,252,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/selary/' in hhEH1rcSP0z6Bkqy8OD or 'مسلسل' in title:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,253,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,252,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if not mmZUvVcxAqEg0FN or mmZUvVcxAqEg0FN in ['search','filters']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"paginate"(.*?)</section>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mmZUvVcxAqEg0FN)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('"poster__single".*?data-src="(.*?)".*?alt="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not items: return
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(UKFZBQAVXHI5s17LyvuRpCY2)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(UKFZBQAVXHI5s17LyvuRpCY2)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"episodes__list boxs__wrapper(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,xNVKL75nEZstg4wfXBkySQ in items:
			title = name+' - حلقة رقم '+xNVKL75nEZstg4wfXBkySQ
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,252,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+'ملف التشغيل',url,252,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def B4SyVfZ2KOp7vzUIA5(title,hhEH1rcSP0z6Bkqy8OD):
	HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = jj0dZrgiKb.findall('[a-zA-Z-]+',title,jj0dZrgiKb.DOTALL)
	if HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ: title = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ[0]
	else: title = title+UKFZBQAVXHI5s17LyvuRpCY2+TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
	title = title.replace('عرب سيد',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('مباشر',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('مشاهدة',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	title = title.replace('ٍ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	title = title.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	return title
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	headers = {'Referer':xG6n4Wq2Ib7YgpiarHUNLQJM0}
	jcInvNf98TZ5gRUDFp40li2uzVPrO,r5G60Wf8zBgmAJpokMed = [],[]
	JOYWT2S6DMzwU5ej4R = jj0dZrgiKb.findall('href="([^"]*)" class="btton download__btn"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if JOYWT2S6DMzwU5ej4R:
		JOYWT2S6DMzwU5ej4R = JOYWT2S6DMzwU5ej4R[0]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',JOYWT2S6DMzwU5ej4R,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-2nd')
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"tabs__holder(.*?)</section>',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,aBd52O7QsZGbvhngJ1TcI,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ in items:
				KwSdzRXT0M3VW = jj0dZrgiKb.findall('\d+',HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,jj0dZrgiKb.DOTALL)
				KwSdzRXT0M3VW = '__'+KwSdzRXT0M3VW[0] if KwSdzRXT0M3VW else wUvcPrYDfISbZolAm83GKEqMyXkn5
				if '/l/' in hhEH1rcSP0z6Bkqy8OD:
					hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('/l/')[1]
					hhEH1rcSP0z6Bkqy8OD = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(hhEH1rcSP0z6Bkqy8OD)
					if wwMdFkWvcRYiXHB7yDrCqnKb98o: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				if hhEH1rcSP0z6Bkqy8OD in r5G60Wf8zBgmAJpokMed: continue
				r5G60Wf8zBgmAJpokMed.append(hhEH1rcSP0z6Bkqy8OD)
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+aBd52O7QsZGbvhngJ1TcI+'__download'+KwSdzRXT0M3VW
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	ZJCy8d5TGvi31Kh2o0lXV = jj0dZrgiKb.findall('href="([^"<>]+)" class="btton watch__btn"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZJCy8d5TGvi31Kh2o0lXV:
		ZJCy8d5TGvi31Kh2o0lXV = ZJCy8d5TGvi31Kh2o0lXV[0]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',ZJCy8d5TGvi31Kh2o0lXV,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-3rd')
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="servers__list(.*?)</ul>',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('data-qu="(.*?)".*?data-link="(.*?)".*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for KwSdzRXT0M3VW,hhEH1rcSP0z6Bkqy8OD,title in items:
				if 'aHR0' in hhEH1rcSP0z6Bkqy8OD:
					gHpwLvN3qVbn0G89oKtfJO1WkPaTu = jj0dZrgiKb.findall('=(aHR0.*?)"',hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL)
					if gHpwLvN3qVbn0G89oKtfJO1WkPaTu:
						hhEH1rcSP0z6Bkqy8OD = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(gHpwLvN3qVbn0G89oKtfJO1WkPaTu)
						hhEH1rcSP0z6Bkqy8OD = mLh8JBt075iUqNOSDCVFsPIM6KgzGc(hhEH1rcSP0z6Bkqy8OD)
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				if hhEH1rcSP0z6Bkqy8OD in r5G60Wf8zBgmAJpokMed: continue
				r5G60Wf8zBgmAJpokMed.append(hhEH1rcSP0z6Bkqy8OD)
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch__'+KwSdzRXT0M3VW
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
		o4oW9wDcsrpHQS816yfIvg = jj0dZrgiKb.findall('"video_frame" src="(.*?)".*?height="(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if o4oW9wDcsrpHQS816yfIvg:
			hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW = o4oW9wDcsrpHQS816yfIvg[0]
			if '=aHR0' in hhEH1rcSP0z6Bkqy8OD:
				gHpwLvN3qVbn0G89oKtfJO1WkPaTu = jj0dZrgiKb.findall('=(aHR0.*?)$',hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL)
				if gHpwLvN3qVbn0G89oKtfJO1WkPaTu:
					hhEH1rcSP0z6Bkqy8OD = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(gHpwLvN3qVbn0G89oKtfJO1WkPaTu[0]+'===').decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
					hhEH1rcSP0z6Bkqy8OD = mLh8JBt075iUqNOSDCVFsPIM6KgzGc(hhEH1rcSP0z6Bkqy8OD)
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			name = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
			if hhEH1rcSP0z6Bkqy8OD not in r5G60Wf8zBgmAJpokMed:
				r5G60Wf8zBgmAJpokMed.append(hhEH1rcSP0z6Bkqy8OD)
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__embed__'+KwSdzRXT0M3VW
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def ttpe0nuTb6y2x5BdlqJcKDfE(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	ZD5n0eJivzWOMxY98dgrumkwRG = QM9sJ7tk0oplqEwHU3DjL64d.url
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,'url')
	headers['Referer'] = xG6n4Wq2Ib7YgpiarHUNLQJM0+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,GVsDoleH0P5pIdu4mvWU1wkOthxy7A = [],[]
	rkwBQ0MDtLKWa,PGiAz5L7UNj41yZqQFRk9sg0vu,K5sxXqB0bMvRiOJr = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	PIaBHUc2CAvig5tTyfL6qGd4u3jN,M3iALdjzGPrTOvpHqs,Y3McUQdvZWjIlR8Ofmbqx = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	PqDEtFurAcXOm = jj0dZrgiKb.findall('"WatchButtons"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if PqDEtFurAcXOm:
		IJE2xcV7OWauUKhfik56gXBwltCb = PqDEtFurAcXOm[wTLFCOcM26fmYlW7U]
		if '<form' in IJE2xcV7OWauUKhfik56gXBwltCb:
			GVsDoleH0P5pIdu4mvWU1wkOthxy7A = jj0dZrgiKb.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if GVsDoleH0P5pIdu4mvWU1wkOthxy7A:
				N2t8i1vLnORq4rhK9fwFXDWe = 'POST'
				for Z7Qikucg083SpAzqwlDYKCyF,name,value in GVsDoleH0P5pIdu4mvWU1wkOthxy7A:
					if 'wpost' in name: rkwBQ0MDtLKWa,PGiAz5L7UNj41yZqQFRk9sg0vu,K5sxXqB0bMvRiOJr = Z7Qikucg083SpAzqwlDYKCyF,name,value
					elif 'dpost' in name: PIaBHUc2CAvig5tTyfL6qGd4u3jN,M3iALdjzGPrTOvpHqs,Y3McUQdvZWjIlR8Ofmbqx = Z7Qikucg083SpAzqwlDYKCyF,name,value
				HpFkCvbTy7Mz9uQSNG21JEjs = PGiAz5L7UNj41yZqQFRk9sg0vu+'='+K5sxXqB0bMvRiOJr
				LnqQWJS7bhDABxyI3FNefzTUGZoui = M3iALdjzGPrTOvpHqs+'='+Y3McUQdvZWjIlR8Ofmbqx
		else:
			GVsDoleH0P5pIdu4mvWU1wkOthxy7A = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if GVsDoleH0P5pIdu4mvWU1wkOthxy7A:
				N2t8i1vLnORq4rhK9fwFXDWe = 'GET'
				for hhEH1rcSP0z6Bkqy8OD in GVsDoleH0P5pIdu4mvWU1wkOthxy7A:
					if 'wpost' in hhEH1rcSP0z6Bkqy8OD: rkwBQ0MDtLKWa = hhEH1rcSP0z6Bkqy8OD
					elif 'dpost' in hhEH1rcSP0z6Bkqy8OD: PIaBHUc2CAvig5tTyfL6qGd4u3jN = hhEH1rcSP0z6Bkqy8OD
				HpFkCvbTy7Mz9uQSNG21JEjs = wUvcPrYDfISbZolAm83GKEqMyXkn5
				LnqQWJS7bhDABxyI3FNefzTUGZoui = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if rkwBQ0MDtLKWa:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,N2t8i1vLnORq4rhK9fwFXDWe,rkwBQ0MDtLKWa,HpFkCvbTy7Mz9uQSNG21JEjs,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="WatcherArea(.*?</ul>)',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			L9UXvbuQsnEYDjgteThBmadk = pLHIPUY3TWAeE70[0]
			L9UXvbuQsnEYDjgteThBmadk = L9UXvbuQsnEYDjgteThBmadk.replace('</ul>','<h3>')
			L9UXvbuQsnEYDjgteThBmadk = L9UXvbuQsnEYDjgteThBmadk.replace('<h3>','<h3><h3>')
			qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('<h3>.*?(\d+)(.*?)<h3>',L9UXvbuQsnEYDjgteThBmadk,jj0dZrgiKb.DOTALL)
			if not qqtR56dgVLh3Tr2: qqtR56dgVLh3Tr2 = [(wUvcPrYDfISbZolAm83GKEqMyXkn5,L9UXvbuQsnEYDjgteThBmadk)]
			for KwSdzRXT0M3VW,IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
				if KwSdzRXT0M3VW: KwSdzRXT0M3VW = '____'+KwSdzRXT0M3VW
				items = jj0dZrgiKb.findall('data-link="(.*?)".*?<span>(.*?)</span>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,name in items:
					if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
					hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__watch'+KwSdzRXT0M3VW
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if ppAJI9kDbz5MXa76UEF:
			hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW = ppAJI9kDbz5MXa76UEF[0]
			name = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,'name')
			if '%' in KwSdzRXT0M3VW: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__embed__'
			else: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__embed____'+KwSdzRXT0M3VW
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if PIaBHUc2CAvig5tTyfL6qGd4u3jN:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,N2t8i1vLnORq4rhK9fwFXDWe,PIaBHUc2CAvig5tTyfL6qGd4u3jN,LnqQWJS7bhDABxyI3FNefzTUGZoui,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-PLAY-3rd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="DownloadArea(.*?)<script src=',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			L9UXvbuQsnEYDjgteThBmadk = pLHIPUY3TWAeE70[0]
			qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall('class="DownloadServers(.*?)</ul>',L9UXvbuQsnEYDjgteThBmadk,jj0dZrgiKb.DOTALL)
			for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
				items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,title,KwSdzRXT0M3VW in items:
					if not hhEH1rcSP0z6Bkqy8OD: continue
					if 'reviewstation' in hhEH1rcSP0z6Bkqy8OD: continue
					hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
					hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download____'+KwSdzRXT0M3VW
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	hQ9TPjE8naHpkiUC35lqM2y = str(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	jjmdDLrWlzJVONaX7y = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in hQ9TPjE8naHpkiUC35lqM2y for value in jjmdDLrWlzJVONaX7y):
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if not search: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/find/?word='+search+'&type='
	HPdaS7kenW0m(url,'search')
	return
def mmUxVlf7ZQMjeDE(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='CATEGORIES':
		if MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[0]+'==' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[0:-1])):
			if MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'==' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&&'+d5TLHSj39awfvFp+'==0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&&'+d5TLHSj39awfvFp+'==0'
		qclt2BMvQu = M2MhYTzotC0.strip('&&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'//getposts??'+NGik0Ke4WwfT2
	elif type=='FILTERS':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		if mVhHg8LIlYR5cM9d7PfB==wUvcPrYDfISbZolAm83GKEqMyXkn5: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'//getposts??'+mVhHg8LIlYR5cM9d7PfB
		XXup0CJWslMOqymaKthfb84 = ZAg9I7pVX2J(ZD5n0eJivzWOMxY98dgrumkwRG)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها ',XXup0CJWslMOqymaKthfb84,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',XXup0CJWslMOqymaKthfb84,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'POST',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARABSEED-FILTERS_MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	iPDEVB8RL1A9Fmg7dhzNpfanO = jj0dZrgiKb.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	tPDuy8I4YRSFO5gihCwWLKBZv = jj0dZrgiKb.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = iPDEVB8RL1A9Fmg7dhzNpfanO+tPDuy8I4YRSFO5gihCwWLKBZv
	dict = {}
	for name,VaqykB2YmTbCtUDl,IJE2xcV7OWauUKhfik56gXBwltCb in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		items = jj0dZrgiKb.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('data-rate="(.*?)".*?<em>(.*?)</em>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			items = []
			for sslNS0zetni1HDbZRQOCMxJ4AfhaP,value in VV7eQk5mj1dBNiHtrcP: items.append([sslNS0zetni1HDbZRQOCMxJ4AfhaP,wUvcPrYDfISbZolAm83GKEqMyXkn5,value])
			VaqykB2YmTbCtUDl = 'rate'
			name = 'التقييم'
		else: VaqykB2YmTbCtUDl = items[0][1]
		if '==' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='CATEGORIES':
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<=1:
				if VaqykB2YmTbCtUDl==MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[-1]: HPdaS7kenW0m(ZD5n0eJivzWOMxY98dgrumkwRG)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'CATEGORIES___'+qclt2BMvQu)
				return
			else:
				XXup0CJWslMOqymaKthfb84 = ZAg9I7pVX2J(ZD5n0eJivzWOMxY98dgrumkwRG)
				if VaqykB2YmTbCtUDl==MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[-1]: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع ',XXup0CJWslMOqymaKthfb84,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع ',ZD5n0eJivzWOMxY98dgrumkwRG,254,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='FILTERS':
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&&'+VaqykB2YmTbCtUDl+'==0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&&'+VaqykB2YmTbCtUDl+'==0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع :'+name,ZD5n0eJivzWOMxY98dgrumkwRG,255,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for sslNS0zetni1HDbZRQOCMxJ4AfhaP,vziHL4xVFSD81W7X9Noyrdjb,value in items:
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			if 'الكل' in sslNS0zetni1HDbZRQOCMxJ4AfhaP: continue
			sslNS0zetni1HDbZRQOCMxJ4AfhaP = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(sslNS0zetni1HDbZRQOCMxJ4AfhaP)
			aBd52O7QsZGbvhngJ1TcI,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = sslNS0zetni1HDbZRQOCMxJ4AfhaP,sslNS0zetni1HDbZRQOCMxJ4AfhaP
			HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = name+': '+aBd52O7QsZGbvhngJ1TcI
			dict[VaqykB2YmTbCtUDl][value] = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&&'+VaqykB2YmTbCtUDl+'=='+aBd52O7QsZGbvhngJ1TcI
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&&'+VaqykB2YmTbCtUDl+'=='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			if type=='FILTERS':
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,url,255,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='CATEGORIES' and MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ[-2]+'==' in yzamv2DUurjwolVq:
				NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'modified_filters')
				qaLFXuDExl8w = url+'//getposts??'+NGik0Ke4WwfT2
				XXup0CJWslMOqymaKthfb84 = ZAg9I7pVX2J(qaLFXuDExl8w)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,XXup0CJWslMOqymaKthfb84,251,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,url,254,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
MmQPiy4Ag1LlGvz2IW0pOH5uDnbZ = ['category','country','release-year']
SqpQmhrzMtNF1H = ['category','country','genre','release-year','language','quality','rate']
def ZAg9I7pVX2J(url):
	q5zHOlyBRxcJTUaEWrkm6v = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',q5zHOlyBRxcJTUaEWrkm6v)
	url = url.replace('/category/اخرى',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if q5zHOlyBRxcJTUaEWrkm6v not in url: url = url+q5zHOlyBRxcJTUaEWrkm6v
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&&')
	wHOxpbdkJBM0ZC7,IIacxECW0M6lSRwGfpFbUJP9d2Lm = {},wUvcPrYDfISbZolAm83GKEqMyXkn5
	if '==' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('==')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	for key in SqpQmhrzMtNF1H:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if '%' not in value: value = vvLTYxVfrbDza(value)
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&&'+key+'=='+value
		elif mode=='all': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&&'+key+'=='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&&')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm