# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'FAJERSHOW'
UT69hgqoKsWNIwM5zkAYb = '_FJS_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==390: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==391: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==392: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==393: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==399: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,399,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FAJERSHOW-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('<header>.*?<h2>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in range(len(items)):
		title = items[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhD7r1VvaPt3TC06SJjqKRfEid,391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'latest'+str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4))
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مختارات عشوائية',hhD7r1VvaPt3TC06SJjqKRfEid,391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'randoms')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أعلى الأفلام تقييماً',hhD7r1VvaPt3TC06SJjqKRfEid,391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'top_imdb_movies')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أعلى المسلسلات تقييماً',hhD7r1VvaPt3TC06SJjqKRfEid,391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'top_imdb_series')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أفلام مميزة',hhD7r1VvaPt3TC06SJjqKRfEid+'/movies',391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured_movies')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مسلسلات مميزة',hhD7r1VvaPt3TC06SJjqKRfEid+'/tvshows',391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured_tvshows')
	IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="menu"(.*?)id="contenedor"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb += pLHIPUY3TWAeE70[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="releases"(.*?)aside',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb += pLHIPUY3TWAeE70[0]
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	ooZGMlYybF8aNfAOwps = True
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if title=='الأعلى مشاهدة':
			if ooZGMlYybF8aNfAOwps:
				title = 'الافلام '+title
				ooZGMlYybF8aNfAOwps = False
			else: title = 'المسلسلات '+title
		if title not in i6TIRax9v0EDFJs2gVtfzp:
			if title=='أفلام': mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhD7r1VvaPt3TC06SJjqKRfEid+'/movies',391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'all_movies_tvshows')
			elif title=='مسلسلات': mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhD7r1VvaPt3TC06SJjqKRfEid+'/tvshows',391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'all_movies_tvshows')
			else: mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,391)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,type):
	IJE2xcV7OWauUKhfik56gXBwltCb,items = [],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FAJERSHOW-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if type in ['featured_movies','featured_tvshows']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="content"(.*?)id="archive-content"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	elif type=='all_movies_tvshows':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="archive-content"(.*?)class="pagination"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	elif type=='top_imdb_movies':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='top_imdb_series':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("class='top-imdb-list tright(.*?)footer",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='search':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="search-page"(.*?)class="sidebar',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='sider':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="widget(.*?)class="widget',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		JIO9qPGcfs76XSU0KCh1 = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,DGEMLXJQUt3PoYgVCfT7lbk80ujx9,Eu8LWnSt3fyJzIC = zip(*JIO9qPGcfs76XSU0KCh1)
		items = zip(DGEMLXJQUt3PoYgVCfT7lbk80ujx9,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,Eu8LWnSt3fyJzIC)
	elif type=='randoms':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="slider-movies-tvshows"(.*?)<header>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif 'latest' in type:
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = int(type[-1:])
		II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('<header>','<end><start>')
		II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('</div></div></div>','</div></div></div><end>')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<start>(.*?)<end>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
		if xJAIOQKvfpEH5Mn0Z1yUBqVCWY4==6:
			JIO9qPGcfs76XSU0KCh1 = jj0dZrgiKb.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			DGEMLXJQUt3PoYgVCfT7lbk80ujx9,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = zip(*JIO9qPGcfs76XSU0KCh1)
			items = zip(DGEMLXJQUt3PoYgVCfT7lbk80ujx9,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,Eu8LWnSt3fyJzIC)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="content"(.*?)class="(pagination|sidebar)',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0][0]
			if '/collection/' in url:
				items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			elif '/quality/' in url:
				items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items and IJE2xcV7OWauUKhfik56gXBwltCb:
		items = jj0dZrgiKb.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = jj0dZrgiKb.findall('^(.*?)<.*?serie">(.*?)<',title,jj0dZrgiKb.DOTALL)
			title = title[0][1]
			if title in v2v3ase4WBgVjbOnu96PCzlDKi: continue
			v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			title = '_MOD_'+title
		HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = jj0dZrgiKb.findall('^(.*?)<',title,jj0dZrgiKb.DOTALL)
		if HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ: title = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ[0]
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if '/tvshows/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,393,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/episodes/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,393,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/seasons/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,393,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/collection/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,391,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,392,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if type not in ['featured_movies','featured_tvshows']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,391,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def mCwqRg7HpivAQ6S(url):
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	url = url.replace(xG6n4Wq2Ib7YgpiarHUNLQJM0,hhD7r1VvaPt3TC06SJjqKRfEid)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FAJERSHOW-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	bxiMUQmPRvu = jj0dZrgiKb.findall('class="C rated".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,392,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	II64TLxj3mbqEyh9pHQ8oAv = WTJA9qoLQXdPRIihy(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FAJERSHOW-PLAY-1st')
	bxiMUQmPRvu = jj0dZrgiKb.findall('class="C rated".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0][0]
		items = jj0dZrgiKb.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for type,dHRIVxWSDFQOajpZ7mflrsToY,DD02PLKZ6qlnXC1,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+dHRIVxWSDFQOajpZ7mflrsToY+'&nume='+DD02PLKZ6qlnXC1+'&type='+type
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW,jTd3VarcCvh4D70WXGI in items:
			if '=' in cPzpeLXs3jMCltW4ZN9BaYdfQvwS:
				c2K0TAgyHFLsX = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.split('=')[1]
				title = TO3vi2rSZ0LRhKlwgG4qkYFIC(c2K0TAgyHFLsX,'host')
			else: title = wUvcPrYDfISbZolAm83GKEqMyXkn5
			title = jTd3VarcCvh4D70WXGI+UKFZBQAVXHI5s17LyvuRpCY2+title
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download____'+KwSdzRXT0M3VW
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(url,'search')
	return