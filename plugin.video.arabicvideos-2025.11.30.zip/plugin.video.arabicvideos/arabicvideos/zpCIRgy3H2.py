# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from toeJqf51QP import *
from XXRNnfOH3e import *
import base64 as qXASkvFKaf6HojMIz578WxlVwnCpD9
UdbRGoKhcDeI4lVfns5 = weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫၲ")
if wwMdFkWvcRYiXHB7yDrCqnKb98o:
	KXekl8MiCfjSYDHdWqw = XgEUrSsa4QOz2CwDxvHkFeVjoc.translatePath(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬၳ"))
	JMVGrgf2Qj69HKpu = XgEUrSsa4QOz2CwDxvHkFeVjoc.translatePath(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩၴ"))
	cT4oLk7l9uSIbE35NjBV = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,VhqD3zp7mUieI8sMQlETH(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨၵ"),jQv0du1iVxTgAXCM(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩၶ"),kPCxIUZb1V(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭ၷ"))
	rcBU8Wg14IlZ2X90e3C6RMsthzwT = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫၸ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬၹ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫၺ"))
	AZ7XwOdthHi = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,kPCxIUZb1V(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧၻ"),yRWQMHxZEz0(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨၼ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧၽ"))
	from urllib.parse import quote as _KjVuG6Zwds9zQeWnhlyk4pMRm2v
else:
	KXekl8MiCfjSYDHdWqw = te28VJiPB7RXcm6brMUQyKAC3Z.translatePath(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩၾ"))
	JMVGrgf2Qj69HKpu = te28VJiPB7RXcm6brMUQyKAC3Z.translatePath(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ၿ"))
	cT4oLk7l9uSIbE35NjBV = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,Gj3rMP1Cb8wHdp49la0(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬႀ"),yRWQMHxZEz0(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ႁ"),fmkZtbRj3ux(u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪႂ"))
	rcBU8Wg14IlZ2X90e3C6RMsthzwT = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,lCT8hfYUBX4OQMmL(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨႃ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩႄ"),DpRJnas65uVcO0S17dYG(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨႅ"))
	AZ7XwOdthHi = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫႆ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬႇ"),llkFwuCyhaP3sK76qO4T(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫႈ"))
	from urllib import quote as _KjVuG6Zwds9zQeWnhlyk4pMRm2v
tiIwFLAE7eaJ3bCxGqumDPNZ2 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(JMVGrgf2Qj69HKpu,it4DKnryZlx(u"ࠬࡱ࡯ࡥ࡫࠱ࡰࡴ࡭ࠧႉ"))
bbnFV8pDuRGWkl2yMge9S = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(JMVGrgf2Qj69HKpu,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡫ࡰࡦ࡬࠲ࡴࡲࡤ࠯࡮ࡲ࡫ࠬႊ"))
IH5yWt0FUviS3LRjA2qxJZhQ = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩႋ"))
ALDNgiYC67Fw8nIMT = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,xm6jK1ZMuWq5(u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪႌ"))
oD6ZRHFcsAJ0xhY = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,DpRJnas65uVcO0S17dYG(u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣႍࠩ"))
eCcr5AqkmHOSU = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫႎ"))
WsgH5OuS41JkZFoRACamNI72jGepln = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,vWNRusF46D7Mi8GpZ(u"ࠫ࡮ࡶࡴࡷࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭ႏ"))
jO8iH0nWS2rgY3qGcuhXUJtx = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡳ࠳ࡶࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭႐"))
FdBCebm02RAPkX = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,yRWQMHxZEz0(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ႑"))
wsKRQEPzY0 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,xdSThjYnuHXAU6M(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ႒"))
vvfS6pR1olzWJ2xrea9IHhuQYUKNL = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ႓"))
efgpaHQE8WokSjsPtilGN61KJUMDF = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭႔"))
W1yC4jEOPg0NSMJBuUGv6w = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,fmkZtbRj3ux(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪ႕"))
WWGNDzvgU67Oj = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨ႖"))
T0Da9BbtEr1soL = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,xdSThjYnuHXAU6M(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬ႗"))
NCTgH3l9fBXuoL26M = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,bQGafNLXyFgsZP6ut(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬ႘"))
IIkEcaWTqldjmbYPD5OSXveNFs4 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,vWNRusF46D7Mi8GpZ(u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧ႙"))
Rj3VsmvbuAdWhUg7ETykSLw = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,jQv0du1iVxTgAXCM(u"ࠨࡣࡧࡨࡴࡴࡳࠨႚ"))
cbKCAy6vk3j1XDY0prlmMUe = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,bQGafNLXyFgsZP6ut(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫႛ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧႜ"),ggvQikMrmRXYdezZuUwj30WOc)
EEB78CMKb0SOQrGgN9 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(cbKCAy6vk3j1XDY0prlmMUe,xdSThjYnuHXAU6M(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪႝ"))
FvjiSG8Ob95dYotL2BsxJm3g4QHlk = set(TTuO14NzmB.BADWEBSITES)
emNlqsvPnQAjwGHVyx2EXgaWMI7 = [o4oW9wDcsrpHQS816yfIvg for o4oW9wDcsrpHQS816yfIvg in emNlqsvPnQAjwGHVyx2EXgaWMI7 if o4oW9wDcsrpHQS816yfIvg not in FvjiSG8Ob95dYotL2BsxJm3g4QHlk]
CF1Ye02AfwbLgM48Vta = [o4oW9wDcsrpHQS816yfIvg for o4oW9wDcsrpHQS816yfIvg in CF1Ye02AfwbLgM48Vta if o4oW9wDcsrpHQS816yfIvg not in FvjiSG8Ob95dYotL2BsxJm3g4QHlk]
W1bszKqEjom = [o4oW9wDcsrpHQS816yfIvg for o4oW9wDcsrpHQS816yfIvg in W1bszKqEjom if o4oW9wDcsrpHQS816yfIvg not in FvjiSG8Ob95dYotL2BsxJm3g4QHlk]
VVSuXlFIYdLxpCHJ54m = [o4oW9wDcsrpHQS816yfIvg for o4oW9wDcsrpHQS816yfIvg in VVSuXlFIYdLxpCHJ54m if o4oW9wDcsrpHQS816yfIvg not in FvjiSG8Ob95dYotL2BsxJm3g4QHlk]
XIuPSfCzic = [o4oW9wDcsrpHQS816yfIvg for o4oW9wDcsrpHQS816yfIvg in XIuPSfCzic if o4oW9wDcsrpHQS816yfIvg not in FvjiSG8Ob95dYotL2BsxJm3g4QHlk]
class ccihgnIMFa():
	def __init__(xGBhIZ1EXiTudDJ5gwr8,showDialogs=Z19pUxa2gfGMNKoDsEuytn85SjFvA,logErrors=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
		xGBhIZ1EXiTudDJ5gwr8.showDialogs = showDialogs
		xGBhIZ1EXiTudDJ5gwr8.logErrors = logErrors
		xGBhIZ1EXiTudDJ5gwr8.finishedLIST,xGBhIZ1EXiTudDJ5gwr8.failedLIST = [],[]
		xGBhIZ1EXiTudDJ5gwr8.statusDICT,xGBhIZ1EXiTudDJ5gwr8.resultsDICT = {},{}
		xGBhIZ1EXiTudDJ5gwr8.processesLIST = []
		xGBhIZ1EXiTudDJ5gwr8.starttimeDICT,xGBhIZ1EXiTudDJ5gwr8.finishtimeDICT,xGBhIZ1EXiTudDJ5gwr8.elpasedtimeDICT = {},{},{}
	def PPGgu8rsmyUDJkKdl6(xGBhIZ1EXiTudDJ5gwr8,MLfBSenJx7hP3mTsoQrb,JEY7pvqkyfrR8OzlmGg3t5SCuN,*aargs):
		MLfBSenJx7hP3mTsoQrb = str(MLfBSenJx7hP3mTsoQrb)
		xGBhIZ1EXiTudDJ5gwr8.statusDICT[MLfBSenJx7hP3mTsoQrb] = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭႞")
		if xGBhIZ1EXiTudDJ5gwr8.showDialogs: hg79cQmoVfMCukiU8ERpT6JqywSrN3(wUvcPrYDfISbZolAm83GKEqMyXkn5,MLfBSenJx7hP3mTsoQrb)
		PkSXAiJg9zIy6CW5VKvQ = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=xGBhIZ1EXiTudDJ5gwr8.uuokKgNJd07nwzEIPV3x4,args=(MLfBSenJx7hP3mTsoQrb,JEY7pvqkyfrR8OzlmGg3t5SCuN,aargs))
		xGBhIZ1EXiTudDJ5gwr8.processesLIST.append(PkSXAiJg9zIy6CW5VKvQ)
		return PkSXAiJg9zIy6CW5VKvQ
	def y5Fue37azCtRA1SQ9rNGwOgXb(xGBhIZ1EXiTudDJ5gwr8,MLfBSenJx7hP3mTsoQrb,JEY7pvqkyfrR8OzlmGg3t5SCuN,*aargs):
		PkSXAiJg9zIy6CW5VKvQ = xGBhIZ1EXiTudDJ5gwr8.PPGgu8rsmyUDJkKdl6(MLfBSenJx7hP3mTsoQrb,JEY7pvqkyfrR8OzlmGg3t5SCuN,*aargs)
		PkSXAiJg9zIy6CW5VKvQ.start()
	def uuokKgNJd07nwzEIPV3x4(xGBhIZ1EXiTudDJ5gwr8,MLfBSenJx7hP3mTsoQrb,JEY7pvqkyfrR8OzlmGg3t5SCuN,aargs):
		MLfBSenJx7hP3mTsoQrb = str(MLfBSenJx7hP3mTsoQrb)
		xGBhIZ1EXiTudDJ5gwr8.starttimeDICT[MLfBSenJx7hP3mTsoQrb] = L5jXH0fZ8TvsESR.time()
		try:
			xGBhIZ1EXiTudDJ5gwr8.resultsDICT[MLfBSenJx7hP3mTsoQrb] = JEY7pvqkyfrR8OzlmGg3t5SCuN(*aargs)
			if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧ႟") in str(JEY7pvqkyfrR8OzlmGg3t5SCuN) and not xGBhIZ1EXiTudDJ5gwr8.resultsDICT[MLfBSenJx7hP3mTsoQrb].succeeded: sKv7WVYzUI()
			xGBhIZ1EXiTudDJ5gwr8.finishedLIST.append(MLfBSenJx7hP3mTsoQrb)
			xGBhIZ1EXiTudDJ5gwr8.statusDICT[MLfBSenJx7hP3mTsoQrb] = erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩႠ")
		except Exception as CPhVH47v1X83tgA62wMWirdG:
			if xGBhIZ1EXiTudDJ5gwr8.logErrors:
				av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
				if av1f8x5yZ9rAsq!=xm6jK1ZMuWq5(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫႡ"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
			xGBhIZ1EXiTudDJ5gwr8.failedLIST.append(MLfBSenJx7hP3mTsoQrb)
			xGBhIZ1EXiTudDJ5gwr8.statusDICT[MLfBSenJx7hP3mTsoQrb] = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩႢ")
		xGBhIZ1EXiTudDJ5gwr8.finishtimeDICT[MLfBSenJx7hP3mTsoQrb] = L5jXH0fZ8TvsESR.time()
		xGBhIZ1EXiTudDJ5gwr8.elpasedtimeDICT[MLfBSenJx7hP3mTsoQrb] = xGBhIZ1EXiTudDJ5gwr8.finishtimeDICT[MLfBSenJx7hP3mTsoQrb] - xGBhIZ1EXiTudDJ5gwr8.starttimeDICT[MLfBSenJx7hP3mTsoQrb]
	def v48KLQF9NRdsjbBOzYna03c6Sx(xGBhIZ1EXiTudDJ5gwr8):
		for cXuqNYCZtLh2Pfsxz in xGBhIZ1EXiTudDJ5gwr8.processesLIST:
			cXuqNYCZtLh2Pfsxz.start()
	def qqNUrOjixgzYPKopnbZDlafCt(xGBhIZ1EXiTudDJ5gwr8):
		while xm6jK1ZMuWq5(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫႣ") in list(xGBhIZ1EXiTudDJ5gwr8.statusDICT.values()): L5jXH0fZ8TvsESR.sleep(JHMxIE4fs1mvQtKW7R(u"࠵ᛒ"))
def UMT4KYfGVuF():
	if not AAyuoe4wDPR2MgXacG7ZN8zI: return kPCxIUZb1V(u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧႤ")
	OwYUqaxrAm15Fjh79NliMctSkK3 = D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪႥ")
	KvBGHUFx19WCpR0kazwf5yQPSIdTL2 = [yRWQMHxZEz0(u"࠭࠸࠯࠷࠱࠴ࠬႦ"),lCT8hfYUBX4OQMmL(u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫႧ"),A6Sg45ChDR3BJLYfFH(u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭Ⴈ"),VhqD3zp7mUieI8sMQlETH(u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭Ⴉ"),bQGafNLXyFgsZP6ut(u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧႪ"),lCT8hfYUBX4OQMmL(u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨႫ"),lCT8hfYUBX4OQMmL(u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩႬ"),Gj3rMP1Cb8wHdp49la0(u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪႭ"),rDG9dZoXRhCJcieUSF0KB(u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫႮ"),A6Sg45ChDR3BJLYfFH(u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬႯ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࠵࠴࠷࠺࠮࠱࠳࠱࠵࠹࠭Ⴐ"),kPCxIUZb1V(u"ࠪ࠶࠵࠸࠴࠯࠲࠺࠲࠷࠶ࠧႱ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠫ࠷࠶࠲࠶࠰࠳࠹࠳࠶࠵ࠨႲ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࠸࠰࠳࠷࠱࠵࠶࠴࠳࠱ࠩႳ")]
	cSwM6XYjVs4G = KvBGHUFx19WCpR0kazwf5yQPSIdTL2[-UD4N8MjVTd]
	WcUGhqNsd4ROFT = UmOxLC9ayZ2fgM(cSwM6XYjVs4G)
	HWwiToK7CbIfQAOpZe6rxJ5jsG4M = UmOxLC9ayZ2fgM(D1DBSuO0lLGRbcfCyY)
	if HWwiToK7CbIfQAOpZe6rxJ5jsG4M>WcUGhqNsd4ROFT:
		OwYUqaxrAm15Fjh79NliMctSkK3 = lCT8hfYUBX4OQMmL(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭Ⴔ")
	return OwYUqaxrAm15Fjh79NliMctSkK3
def zd0StUlGcWbT(RCBXDnhK3jHYUvJ):
	c8iCAbQUY5sxmDOuZz19RgnVdpFk,W3EUbyRV9DBqxnLkTC = wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if RCBXDnhK3jHYUvJ: c8iCAbQUY5sxmDOuZz19RgnVdpFk = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,kPCxIUZb1V(u"ࠧࡴࡶࡵࠫႵ"),kPCxIUZb1V(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭Ⴖ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈࠫႷ"))
	if not c8iCAbQUY5sxmDOuZz19RgnVdpFk:
		xLDEnp9WdA = TTuO14NzmB.SITESURLS[D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪႸ")][vvhR5ozeiJpANyl8fFO3GBw(u"࠾ᛓ")]
		xxwBIFtsuXOJ5ki1 = {pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡺࡹࡥࡳࠩႹ"):TTuO14NzmB.AV_CLIENT_IDS,rDG9dZoXRhCJcieUSF0KB(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭Ⴚ"):D1DBSuO0lLGRbcfCyY}
		c8iCAbQUY5sxmDOuZz19RgnVdpFk = wBxAjV0NKzMhD2daHCU8TLRbu6lirO(MFhbWia58mP3su0fk2d(u"࠭ࡐࡐࡕࡗࠫႻ"),xLDEnp9WdA,xxwBIFtsuXOJ5ki1,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇ࡟ࡑ࡛ࡗࡌࡔࡔ࡟ࡄࡑࡇࡉ࠲࠷ࡳࡵࠩႼ"))
		SwkKZ8pMra5VFs9zbOnf2Gli0YI(TTuO14NzmB.api_python_actions[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠿ᛔ")])
		if c8iCAbQUY5sxmDOuZz19RgnVdpFk: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,Gj3rMP1Cb8wHdp49la0(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭Ⴝ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈࠫႾ"),c8iCAbQUY5sxmDOuZz19RgnVdpFk,pHC2Aj4kbc3KDN0aZWBey6QV)
		W3EUbyRV9DBqxnLkTC = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if c8iCAbQUY5sxmDOuZz19RgnVdpFk:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,t0Y5Pjs9ACl
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,t0Y5Pjs9ACl = {},[],{},[],{}
		exec(c8iCAbQUY5sxmDOuZz19RgnVdpFk,globals(),locals())
		TTuO14NzmB.SITESURLS.update(NEW_SITESURLS)
		TTuO14NzmB.WEBCACHEDATA.update(t0Y5Pjs9ACl)
		TTuO14NzmB.BADSCRAPERS = list(set(TTuO14NzmB.BADSCRAPERS+NEW_BADSCRAPERS))
		TTuO14NzmB.BADCOMMONIDS = list(set(TTuO14NzmB.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if D1DBSuO0lLGRbcfCyY in list(NEW_BADWEBSITES.keys()): TTuO14NzmB.BADWEBSITES += NEW_BADWEBSITES[D1DBSuO0lLGRbcfCyY]
	return W3EUbyRV9DBqxnLkTC
def cVQ7hlW9a2yn6viLp15():
	try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.makedirs(kAXGQe4sH7o3dfLUKv2zlZDM8r09)
	except: pass
	pNAf1wRImW8DcPOyYoa = UMT4KYfGVuF()
	if pNAf1wRImW8DcPOyYoa==s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪႿ"): KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪჀ")+XhGSxvjRAZdU7rEt9JMweQC+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࠦ࡝ࠨჁ"))
	else: KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,yRWQMHxZEz0(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪჂ")+XhGSxvjRAZdU7rEt9JMweQC+vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࠡ࡟ࠪჃ"))
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"ࠨฬ่ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ็๊ࠡฮ๊หื้࡜࡯ว็ํࠥอไฦืาหึࠦัใ็࠽ࡠࡳࡢ࡮ࠨჄ")+D1DBSuO0lLGRbcfCyY)
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,fmkZtbRj3ux(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬჅ"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,jQv0du1iVxTgAXCM(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ჆"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠳ࠩჇ"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,kPCxIUZb1V(u"ࠬࡈࡌࡐࡅࡎࡉࡉࡥࡗࡆࡄࡖࡍ࡙ࡋࡓࠨ჈"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ჉"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ჊"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,A6Sg45ChDR3BJLYfFH(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ჋"),yRWQMHxZEz0(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ჌"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,yRWQMHxZEz0(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭Ⴭ"),kPCxIUZb1V(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪ჎"))
	OOnvcPQy85HYA.setSetting(fmkZtbRj3ux(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬ჏"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(xdSThjYnuHXAU6M(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨა"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(yRWQMHxZEz0(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪბ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(Gj3rMP1Cb8wHdp49la0(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫგ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬდ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬე"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(lCT8hfYUBX4OQMmL(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩვ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(it4DKnryZlx(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬზ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(llkFwuCyhaP3sK76qO4T(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪთ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨი"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting(kPCxIUZb1V(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪკ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪლ"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪმ"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,vWNRusF46D7Mi8GpZ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪნ"))
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,JHMxIE4fs1mvQtKW7R(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙࡟ࡔࡖࡄࡘ࡚࡙ࠧო"))
	N2QCj84D9qInlHveBcf6(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	reWToLljkJG72aSDM0q4uVFwxO(CSjWJNDFL0Hl2IA9fYPtoB643TbZ)
	import tdeCZlJnBw
	tdeCZlJnBw.rrI7hTwM9qCzBF2kgHjSVRNE(w8JC1y7Lp3(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭პ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	tdeCZlJnBw.rrI7hTwM9qCzBF2kgHjSVRNE(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪჟ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	tdeCZlJnBw.rrI7hTwM9qCzBF2kgHjSVRNE(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡦࡧ࡯ࡳࡩ࡬ࡪࡩࡳࡧࡦࡸࠬრ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	tdeCZlJnBw.C7tGsABJHNMUxw85pmRKeI0O6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	tdeCZlJnBw.XgxMuBWUqJiDls4SFItVhpo5r9k(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	if pNAf1wRImW8DcPOyYoa==it4DKnryZlx(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩს"):
		y5o67NQuEHJqR(y0yvdNOZkiKEg5RLMhoDVQAB9F2,[bcP2jUx34tG51D6XSNnyWIes])
	else:
		y5o67NQuEHJqR(Z19pUxa2gfGMNKoDsEuytn85SjFvA,[])
		tdeCZlJnBw.Q6RIl4kCWLPrqONgs8()
		try:
			UmSo3vuektZ26YTCO = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,it4DKnryZlx(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬტ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨუ"),xm6jK1ZMuWq5(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩფ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬქ"))
			Q4QGk2bqdp6H = IuYcSnkRMVoxf4LvWht.Addon(id=s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫღ"))
			Q4QGk2bqdp6H.setSetting(JHMxIE4fs1mvQtKW7R(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧყ"),Gj3rMP1Cb8wHdp49la0(u"ࠩࡉࡥࡱࡹࡥࠨშ"))
		except: pass
		try:
			UmSo3vuektZ26YTCO = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬჩ"),llkFwuCyhaP3sK76qO4T(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨც"),jQv0du1iVxTgAXCM(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬძ"),erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬწ"))
			Q4QGk2bqdp6H = IuYcSnkRMVoxf4LvWht.Addon(id=xm6jK1ZMuWq5(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧჭ"))
			Q4QGk2bqdp6H.setSetting(DpRJnas65uVcO0S17dYG(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫხ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࠶ࠫჯ"))
		except: pass
		try:
			UmSo3vuektZ26YTCO = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬჰ"),kPCxIUZb1V(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨჱ"),vWNRusF46D7Mi8GpZ(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬჲ"),it4DKnryZlx(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬჳ"))
			Q4QGk2bqdp6H = IuYcSnkRMVoxf4LvWht.Addon(id=yRWQMHxZEz0(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧჴ"))
			Q4QGk2bqdp6H.setSetting(vWNRusF46D7Mi8GpZ(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭ჵ"),fmkZtbRj3ux(u"ࠩ࠵ࠫჶ"))
		except: pass
	ZtoUCFcjmabu = akK8V9HQng4mqSlvO01swx6RorY(C5VkX6NMYnT2A0PFL)
	ZtoUCFcjmabu = akK8V9HQng4mqSlvO01swx6RorY(eCcr5AqkmHOSU)
	tdeCZlJnBw.DzpFHEhJlwB7AU34GmNX(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	OOnvcPQy85HYA.setSetting(xdSThjYnuHXAU6M(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧჷ"),D1DBSuO0lLGRbcfCyY)
	ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def ZZFdyH2AmjheY6(MFTEUm2pj39R7oa14D8lXk):
	W3EUbyRV9DBqxnLkTC = zd0StUlGcWbT(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	if W3EUbyRV9DBqxnLkTC:
		return
	iOpTSFLCuz73RDN1cd = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩჸ")))
	iOpTSFLCuz73RDN1cd = wTLFCOcM26fmYlW7U if not iOpTSFLCuz73RDN1cd else int(iOpTSFLCuz73RDN1cd)
	if not iOpTSFLCuz73RDN1cd or not wTLFCOcM26fmYlW7U<=yoJ7t3WpjPkrCmTq-iOpTSFLCuz73RDN1cd<=D0tF2C71Kej5zrAgB6uMJZsI:
		OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪჹ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
		reWToLljkJG72aSDM0q4uVFwxO(CSjWJNDFL0Hl2IA9fYPtoB643TbZ)
		return
	iy4Z8d3t0useFAmULNGYKXx9kj = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(DpRJnas65uVcO0S17dYG(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨჺ")))
	iy4Z8d3t0useFAmULNGYKXx9kj = wTLFCOcM26fmYlW7U if not iy4Z8d3t0useFAmULNGYKXx9kj else int(iy4Z8d3t0useFAmULNGYKXx9kj)
	sbBn7cuxEZy1HmUfztAWKp0IDL = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(fmkZtbRj3ux(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ჻")))
	sbBn7cuxEZy1HmUfztAWKp0IDL = wTLFCOcM26fmYlW7U if not sbBn7cuxEZy1HmUfztAWKp0IDL else int(sbBn7cuxEZy1HmUfztAWKp0IDL)
	if not iy4Z8d3t0useFAmULNGYKXx9kj or not sbBn7cuxEZy1HmUfztAWKp0IDL or not wTLFCOcM26fmYlW7U<=yoJ7t3WpjPkrCmTq-sbBn7cuxEZy1HmUfztAWKp0IDL<=iy4Z8d3t0useFAmULNGYKXx9kj:
		B4bLVoliXpEe1sIxftvSD8JQg(y0yvdNOZkiKEg5RLMhoDVQAB9F2,iy4Z8d3t0useFAmULNGYKXx9kj)
		return
	lAjU0onG7wVsZRNgM6atQ = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨჼ")))
	lAjU0onG7wVsZRNgM6atQ = wTLFCOcM26fmYlW7U if not lAjU0onG7wVsZRNgM6atQ else int(lAjU0onG7wVsZRNgM6atQ)
	if not lAjU0onG7wVsZRNgM6atQ or not wTLFCOcM26fmYlW7U<=yoJ7t3WpjPkrCmTq-lAjU0onG7wVsZRNgM6atQ<=d2priEnu57KztRsm8wCHZ:
		OOnvcPQy85HYA.setSetting(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩჽ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
		zd0StUlGcWbT(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		return
	if Z19pUxa2gfGMNKoDsEuytn85SjFvA:
		zZflwX1F4UsYMWt2QvKmRnNae = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(MFhbWia58mP3su0fk2d(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧჾ")))
		zZflwX1F4UsYMWt2QvKmRnNae = wTLFCOcM26fmYlW7U if not zZflwX1F4UsYMWt2QvKmRnNae else int(zZflwX1F4UsYMWt2QvKmRnNae)
		if not zZflwX1F4UsYMWt2QvKmRnNae or not wTLFCOcM26fmYlW7U<=yoJ7t3WpjPkrCmTq-zZflwX1F4UsYMWt2QvKmRnNae<=sBTeylAtiQXpFW9wjM5C1m:
			OOnvcPQy85HYA.setSetting(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨჿ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
	return
def B4bLVoliXpEe1sIxftvSD8JQg(RCBXDnhK3jHYUvJ,iy4Z8d3t0useFAmULNGYKXx9kj):
	OOZHFIY93U8LAD7 = UD4N8MjVTd
	c9sLAG0RqvTzi = Z19pUxa2gfGMNKoDsEuytn85SjFvA if TTuO14NzmB.o4ZShCq8b53OYkUjrAwGDm1pT7PW else y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if c9sLAG0RqvTzi:
		if not iy4Z8d3t0useFAmULNGYKXx9kj: RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		jpToYkrQKD2eMzWsRLJmXhl = TNuvf0sHO35JtqPga8x(RCBXDnhK3jHYUvJ)
		if len(jpToYkrQKD2eMzWsRLJmXhl)>UD4N8MjVTd:
			KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,A6Sg45ChDR3BJLYfFH(u"ࠬ࠴࡜ࡵࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨᄀ")+XhGSxvjRAZdU7rEt9JMweQC+rDG9dZoXRhCJcieUSF0KB(u"࠭ࠠ࡞ࠩᄁ"))
			MLfBSenJx7hP3mTsoQrb,c3tEmP52oQXkU0eIpAjwyrY6G,IC6XSwYirspRHmM,SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR,Kw19luY7W2jGgsBa5n4hctLfFS = jpToYkrQKD2eMzWsRLJmXhl[wTLFCOcM26fmYlW7U]
			TLpifAHQXIa9EW,D0Rr29bEPUBdAaKMCXhvz75osS = SiLq2mwM5R1ZNXxs83T.split(DpRJnas65uVcO0S17dYG(u"ࠧ࡝ࡰ࠾࠿ࠬᄂ"))
			del jpToYkrQKD2eMzWsRLJmXhl[wTLFCOcM26fmYlW7U]
			zxJFnb5G1Yle6h0rasK = kItsbxAFUXc3.sample(jpToYkrQKD2eMzWsRLJmXhl,UD4N8MjVTd)
			MLfBSenJx7hP3mTsoQrb,c3tEmP52oQXkU0eIpAjwyrY6G,IC6XSwYirspRHmM,SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR,Kw19luY7W2jGgsBa5n4hctLfFS = zxJFnb5G1Yle6h0rasK[wTLFCOcM26fmYlW7U]
			IC6XSwYirspRHmM = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ࡝ࡕࡘࡑࡣࠧᄃ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+xdSThjYnuHXAU6M(u"ࠩࠣ࠾ࠥ࠭ᄄ")+MLfBSenJx7hP3mTsoQrb+AAByQSLgaZwCsKnvc5eWNmY+IC6XSwYirspRHmM
			fq4zHVKJne2uX9aAR = DpRJnas65uVcO0S17dYG(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩᄅ")
			pR42yY1jWXObdMzPcaxTk = jQv0du1iVxTgAXCM(u"ࠫฬ๊สษำ฼หฯ࠭ᄆ")
			button0,button1 = SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR
			sl1gZA0mcr4GTbv8FdXxo = [button0,button1,pR42yY1jWXObdMzPcaxTk]
			ZBtxsh8mePcXQkKNFfg6Idu2 = UD4N8MjVTd if TTuO14NzmB.W1haXcb7tVZ6K else jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠱࠱ᛕ")
			nV02gQlNqjHvTX5eYJ8xfdkp1u = -lCT8hfYUBX4OQMmL(u"࠺ᛖ")
			while nV02gQlNqjHvTX5eYJ8xfdkp1u<wTLFCOcM26fmYlW7U:
				VVElDRsniYQUM4AqfGFp = kItsbxAFUXc3.sample(sl1gZA0mcr4GTbv8FdXxo,MMRBkhnWVJCQwU)
				nV02gQlNqjHvTX5eYJ8xfdkp1u = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,VVElDRsniYQUM4AqfGFp[wTLFCOcM26fmYlW7U],VVElDRsniYQUM4AqfGFp[UD4N8MjVTd],VVElDRsniYQUM4AqfGFp[Tb7oymMnpflsSv3eu4Pz2],TLpifAHQXIa9EW,IC6XSwYirspRHmM,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧᄇ"),ZBtxsh8mePcXQkKNFfg6Idu2,D2PpKMeZFWrmfxTSs4L1tz(u"࠸࠳ᛗ"))
				if nV02gQlNqjHvTX5eYJ8xfdkp1u==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠴࠴ᛘ"): break
				import tdeCZlJnBw
				if nV02gQlNqjHvTX5eYJ8xfdkp1u>=wTLFCOcM26fmYlW7U and VVElDRsniYQUM4AqfGFp[nV02gQlNqjHvTX5eYJ8xfdkp1u]==sl1gZA0mcr4GTbv8FdXxo[UD4N8MjVTd]:
					tdeCZlJnBw.cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED()
					if nV02gQlNqjHvTX5eYJ8xfdkp1u>=wTLFCOcM26fmYlW7U: nV02gQlNqjHvTX5eYJ8xfdkp1u = -w8JC1y7Lp3(u"࠽ᛙ")
				elif nV02gQlNqjHvTX5eYJ8xfdkp1u>=wTLFCOcM26fmYlW7U and VVElDRsniYQUM4AqfGFp[nV02gQlNqjHvTX5eYJ8xfdkp1u]==sl1gZA0mcr4GTbv8FdXxo[Tb7oymMnpflsSv3eu4Pz2]:
					tdeCZlJnBw.sLytMYn4Jh0XcQbek39wVaEG5r16vq(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
				if nV02gQlNqjHvTX5eYJ8xfdkp1u==-UD4N8MjVTd: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+s149dk8uh2p7oFzaLxZeI3Or(u"࠭ฮา๊ฯࠤำ฽รࠨᄈ")+AAByQSLgaZwCsKnvc5eWNmY+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧ࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬᄉ"))
			OOZHFIY93U8LAD7 = UD4N8MjVTd
		else: OOZHFIY93U8LAD7 = wTLFCOcM26fmYlW7U
	OOnvcPQy85HYA.setSetting(weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪᄊ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,bQGafNLXyFgsZP6ut(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬᄋ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨᄌ"),OOZHFIY93U8LAD7,pHC2Aj4kbc3KDN0aZWBey6QV)
	return
def akVtNJ12ces6iZxDX(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ,MFTEUm2pj39R7oa14D8lXk,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk):
	if Zy2eBLfrukDI in [jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠶࠭ᄍ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࠸ࠧᄎ"),Gj3rMP1Cb8wHdp49la0(u"࠭࠳ࠨᄏ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ࠵ࠩᄐ"),fmkZtbRj3ux(u"ࠨ࠷ࠪᄑ"),w8JC1y7Lp3(u"ࠩ࠴࠵ࠬᄒ"),xdSThjYnuHXAU6M(u"ࠪ࠵࠷࠭ᄓ"),JHMxIE4fs1mvQtKW7R(u"ࠫ࠶࠹ࠧᄔ")] and FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk:
		import YLXs6xWcty
		YLXs6xWcty.VRmu6CZOUwlaK4zqk7ty2nc8We9(QFOD4Gei1zaImpk02q6vBNL3jwctbr,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk)
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA,XhGSxvjRAZdU7rEt9JMweQC)
	elif Zy2eBLfrukDI==vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ࠼ࠧᄕ"):
		import zpCIRgy3H2,XXRNnfOH3e
		if FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk==DpRJnas65uVcO0S17dYG(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨᄖ"): XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(xm6jK1ZMuWq5(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧᄗ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨᄘ"),L5jXH0fZ8TvsESR=rDG9dZoXRhCJcieUSF0KB(u"࠷࠶࠰࠱ᛚ"))
		elif FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk==w8JC1y7Lp3(u"ࠩࡇࡉࡑࡋࡔࡆࠩᄙ"): hVB0gciEDAjITnWCzOF8f4(iE0GxkBnVRO4NPwleT,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		RCmHBOKtejQ8lu4L = zpCIRgy3H2.DQ2dIilnTb4BVuMzgh(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,MFTEUm2pj39R7oa14D8lXk,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
		if FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk==jQv0du1iVxTgAXCM(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬᄚ"): sKv7WVYzUI()
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==rDG9dZoXRhCJcieUSF0KB(u"ࠫ࠼࠭ᄛ"):
		import ffKsyZnaOw
		ffKsyZnaOw.kfPj78TywSLnNgr9MHFxp3BZ(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡥࡁࡍࡎࠪᄜ"))
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==kPCxIUZb1V(u"࠭࠸ࠨᄝ"): te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ᄞ")+ggvQikMrmRXYdezZuUwj30WOc+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨᄟ")+str(XmaCeTontNPjwDBzyJIkKA9rRSHfb)+rDG9dZoXRhCJcieUSF0KB(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩᄠ"))
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==DpRJnas65uVcO0S17dYG(u"ࠪ࠽ࠬᄡ"):
		ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==MFhbWia58mP3su0fk2d(u"ࠫ࠶࠶ࠧᄢ"):
		import ffKsyZnaOw
		ffKsyZnaOw.kfPj78TywSLnNgr9MHFxp3BZ(it4DKnryZlx(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭ᄣ"))
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠱࠵ࠩᄤ"): ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬᄥ"))
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࠳࠸ࠫᄦ"): ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧᄧ"))
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==it4DKnryZlx(u"ࠪ࠵࠻࠭ᄨ"): ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2,JHMxIE4fs1mvQtKW7R(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪᄩ"))
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==MFhbWia58mP3su0fk2d(u"ࠬ࠷࠷ࠨᄪ"): ik374RHsnw0uAgmLBvGSecIPUo8(y0yvdNOZkiKEg5RLMhoDVQAB9F2,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭ᄫ"))
	elif QFOD4Gei1zaImpk02q6vBNL3jwctbr==VhqD3zp7mUieI8sMQlETH(u"ࠧ࠲࠺ࠪᄬ"):
		oqF5GjVvYXpBd1l2xmWL0n3kU = OOnvcPQy85HYA.getSetting(vWNRusF46D7Mi8GpZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬᄭ"))
		OOnvcPQy85HYA.setSetting(fmkZtbRj3ux(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ᄮ"),MFhbWia58mP3su0fk2d(u"ࠪ࠱ࠬᄯ")+oqF5GjVvYXpBd1l2xmWL0n3kU)
	if QFOD4Gei1zaImpk02q6vBNL3jwctbr in [Gj3rMP1Cb8wHdp49la0(u"ࠫ࠾࠭ᄰ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࠷࠴ࠨᄱ"),rDG9dZoXRhCJcieUSF0KB(u"࠭࠱࠶ࠩᄲ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࠲࠸ࠪᄳ"),Gj3rMP1Cb8wHdp49la0(u"ࠨ࠳࠺ࠫᄴ")]: sKv7WVYzUI(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def HISTqlOirzge9(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ,MFTEUm2pj39R7oa14D8lXk,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk,JrzealiFtp6):
	if AAyuoe4wDPR2MgXacG7ZN8zI: cVQ7hlW9a2yn6viLp15()
	if QFOD4Gei1zaImpk02q6vBNL3jwctbr: akVtNJ12ces6iZxDX(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ,MFTEUm2pj39R7oa14D8lXk,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk)
	ZZFdyH2AmjheY6(MFTEUm2pj39R7oa14D8lXk)
	n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a = y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	pyA5itRwxqHE = CW98euJE5QlOPnc1KBw(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ,MFTEUm2pj39R7oa14D8lXk,JrzealiFtp6,n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a)
	EFSgjwc57l30xQT2vpyYz,vvbRDXmZEyYa,lXKnBJ0MHULD2IkAPZq5dR9EOio,FbwGmC5HsIKyPlTnNueD,YOL2x59Ryfch3DquvJei6AgmW,a4azEqfoljwnArGZcR0,pfI30moLO2Sq,Rthwq7Dd1I = pyA5itRwxqHE
	if EFSgjwc57l30xQT2vpyYz: return
	if vvbRDXmZEyYa==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩᄵ"): reWToLljkJG72aSDM0q4uVFwxO(CSjWJNDFL0Hl2IA9fYPtoB643TbZ)
	ICwWPArNgl5tj38ZSYdX(Gj3rMP1Cb8wHdp49la0(u"ࠪࡷࡹࡧࡲࡵࠩᄶ"))
	if OOnvcPQy85HYA.getSetting(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡤࡣࡦ࡬ࡪ࠭ᄷ")) not in [gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡇࡕࡕࡑࠪᄸ"),lCT8hfYUBX4OQMmL(u"࠭ࡓࡕࡑࡓࠫᄹ"),vWNRusF46D7Mi8GpZ(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨᄺ")]: OOnvcPQy85HYA.setSetting(vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪᄻ"),jQv0du1iVxTgAXCM(u"ࠩࡄ࡙࡙ࡕࠧᄼ"))
	if not OOnvcPQy85HYA.getSetting(w8JC1y7Lp3(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᄽ")): OOnvcPQy85HYA.setSetting(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫᄾ"),TTuO14NzmB.DNS_SERVERS[wTLFCOcM26fmYlW7U])
	RCmHBOKtejQ8lu4L = DQ2dIilnTb4BVuMzgh(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
	if w8JC1y7Lp3(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᄿ") in UWErGF2TqoQ: VtnP3SszwLg9KuIm = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if KUOoYcT20iCLVgsw1ejzdkHp7XW==TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅀ"):
		if FbwGmC5HsIKyPlTnNueD!=lCT8hfYUBX4OQMmL(u"ࠧ࠯࠰ࠪᅁ") and YOL2x59Ryfch3DquvJei6AgmW: FIkaBmyEdxSzew3()
		if pe9KNyUQmRTj>-UD4N8MjVTd:
			MoYcESkaGHeDO4KUCjXbhJ = [wTLFCOcM26fmYlW7U,Gj3rMP1Cb8wHdp49la0(u"࠱࠶ᛜ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠲࠹ᛝ"),rDG9dZoXRhCJcieUSF0KB(u"࠳࠼ᛞ"),TNw1pBHb8CtSZe0EFxuJqI(u"࠸࠶ᛛ"),JHMxIE4fs1mvQtKW7R(u"࠸࠺ᛡ"),xdSThjYnuHXAU6M(u"࠸࠴ᛟ"),DpRJnas65uVcO0S17dYG(u"࠹࠸ᛠ"),kPCxIUZb1V(u"࠷࠱࠱ᛢ")]
			if (o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࡫ࡱࡸࠬᅂ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬᅃ"),jQv0du1iVxTgAXCM(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨᅄ")) or MFTEUm2pj39R7oa14D8lXk not in MoYcESkaGHeDO4KUCjXbhJ) and not TTuO14NzmB.lOuLW0pjdgS4zX:
				from wwvAS2EKIs import alx59hG1oewy2Lq4jv7
				WTxRhw0o3Ng1rLIX8GHPAea,npl5SLFGKRriesCx2PbwzZXOgQ7M4 = utn2A4oIJb6h(alx59hG1oewy2Lq4jv7)
				EFSgjwc57l30xQT2vpyYz = FWpsuc6MmULz4gZHGAr5l3k2RB9f0(lXKnBJ0MHULD2IkAPZq5dR9EOio,WTxRhw0o3Ng1rLIX8GHPAea,n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a)
				if WTxRhw0o3Ng1rLIX8GHPAea and a4azEqfoljwnArGZcR0:
					if npl5SLFGKRriesCx2PbwzZXOgQ7M4: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪᅅ")+pfI30moLO2Sq+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡥࠧᅆ")+Rthwq7Dd1I,lXKnBJ0MHULD2IkAPZq5dR9EOio,WTxRhw0o3Ng1rLIX8GHPAea,d2priEnu57KztRsm8wCHZ)
					else: P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬᅇ")+pfI30moLO2Sq+A6Sg45ChDR3BJLYfFH(u"ࠧࡠࠩᅈ")+Rthwq7Dd1I,lXKnBJ0MHULD2IkAPZq5dR9EOio)
			else:
				qsrzODKdEYyo.addDirectoryItem(pe9KNyUQmRTj,VhqD3zp7mUieI8sMQlETH(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫᅉ")+ggvQikMrmRXYdezZuUwj30WOc+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩᅊ"),llfAzdjaVLTbyZW7op9i.ListItem(yRWQMHxZEz0(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩᅋ")))
				qsrzODKdEYyo.addDirectoryItem(pe9KNyUQmRTj,TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧᅌ")+ggvQikMrmRXYdezZuUwj30WOc+rDG9dZoXRhCJcieUSF0KB(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬᅍ"),llfAzdjaVLTbyZW7op9i.ListItem(llkFwuCyhaP3sK76qO4T(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬᅎ")))
			qsrzODKdEYyo.endOfDirectory(pe9KNyUQmRTj,n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a)
	return
def reWToLljkJG72aSDM0q4uVFwxO(QIZf1Mm46RYVi0x7P8g9a):
	if MFhbWia58mP3su0fk2d(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᅏ") in str(TTuO14NzmB.SEND_THESE_EVENTS): return
	JoqDlTnHv4Z = Z19pUxa2gfGMNKoDsEuytn85SjFvA if QIZf1Mm46RYVi0x7P8g9a else y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if not JoqDlTnHv4Z:
		AASX8vx5UE3KQ46kmd7FNCg = jExXPonbZHfKa65syL8v47(OOnvcPQy85HYA.getSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᅐ")))
		AASX8vx5UE3KQ46kmd7FNCg = wTLFCOcM26fmYlW7U if not AASX8vx5UE3KQ46kmd7FNCg else int(AASX8vx5UE3KQ46kmd7FNCg)
		if not AASX8vx5UE3KQ46kmd7FNCg or not wTLFCOcM26fmYlW7U<=yoJ7t3WpjPkrCmTq-AASX8vx5UE3KQ46kmd7FNCg<=QIZf1Mm46RYVi0x7P8g9a: JoqDlTnHv4Z = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if not JoqDlTnHv4Z:
		g9dC62H1tQAmpJkhGMnLE3rY5zaWu = OOnvcPQy85HYA.getSetting(w8JC1y7Lp3(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᅑ"))
		if g9dC62H1tQAmpJkhGMnLE3rY5zaWu in [wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᅒ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᅓ")]: JoqDlTnHv4Z = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if not JoqDlTnHv4Z:
		BYaUi1qku0wc2rHeJ8t6Zl = OOnvcPQy85HYA.getSetting(yRWQMHxZEz0(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨᅔ"))
		rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(bcP2jUx34tG51D6XSNnyWIes)
		YYjNyu6sdB70Tc1 = lQ39XPxZLfupRTm(bcP2jUx34tG51D6XSNnyWIes,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡣ࡮ࡪࠠ࠼ࠩᅕ"))
		YYjNyu6sdB70Tc1 = YYjNyu6sdB70Tc1[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠰ᛣ")][dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠰ᛣ")]
		rC0YJ4awbU2H3LOGt5DIF.close()
		WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(lCT8hfYUBX4OQMmL(u"࠶ᛤ")*BYaUi1qku0wc2rHeJ8t6Zl.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
		WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳࠷ᛥ")*WxkZrDEM54oTl0gayus6BXmKz.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
		WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(vvhR5ozeiJpANyl8fFO3GBw(u"࠴࠽ᛦ")*WxkZrDEM54oTl0gayus6BXmKz.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
		WxkZrDEM54oTl0gayus6BXmKz = str(int(WxkZrDEM54oTl0gayus6BXmKz[rDG9dZoXRhCJcieUSF0KB(u"࠸ᛨ"):xm6jK1ZMuWq5(u"࠷࠲ᛩ")],erqDsJmL3BQHuGtPkcf0X9(u"࠱࠷ᛪ")))[:Gj3rMP1Cb8wHdp49la0(u"࠽ᛧ")]
		if WxkZrDEM54oTl0gayus6BXmKz!=YYjNyu6sdB70Tc1: JoqDlTnHv4Z = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if JoqDlTnHv4Z: xxEuXq3VfUIzivGHgh1FJNZQyYj(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def lZ9FucB5q2vaxjOYM3wPyEG0Q(TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS,xVwDZbA6EOjpgX0,showDialogs):
	for LAxSXYvhabdyR4zBs in rmE8zBp0Zwc6hTY1DFKMiPfGVNuoRX:
		if LAxSXYvhabdyR4zBs in Kw19luY7W2jGgsBa5n4hctLfFS: Kw19luY7W2jGgsBa5n4hctLfFS = Kw19luY7W2jGgsBa5n4hctLfFS.replace(LAxSXYvhabdyR4zBs,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	g40I3ZXaeJ8qVywt = xVwDZbA6EOjpgX0.split(vWNRusF46D7Mi8GpZ(u"ࠧ࠮ࠩᅖ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U] if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨ࠯ࠪᅗ") in xVwDZbA6EOjpgX0 else xVwDZbA6EOjpgX0
	if not showDialogs or xVwDZbA6EOjpgX0 in wVd80JnRO7lLx421szgYiZtj: return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	P3yugDKECHbG6p7Wnvq1SU = OOnvcPQy85HYA.getSetting(JHMxIE4fs1mvQtKW7R(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᅘ"))
	OOnvcPQy85HYA.setSetting(vWNRusF46D7Mi8GpZ(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᅙ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	UZQutfKrN1AIYg = TeuQd8DXNkc0zlYmKF2J in [vWNRusF46D7Mi8GpZ(u"࠻ᛮ"),it4DKnryZlx(u"࠳࠴࠴࠵࠷᛬"),JHMxIE4fs1mvQtKW7R(u"࠲࠳࠳࠴࠷᛫"),vWNRusF46D7Mi8GpZ(u"࠴࠴࠵࠻࠴᛭")]
	if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡄࡻࡳࡦࡴࡀࠫᅚ") in Kw19luY7W2jGgsBa5n4hctLfFS: Kw19luY7W2jGgsBa5n4hctLfFS = Kw19luY7W2jGgsBa5n4hctLfFS.split(erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡅࡵࡴࡧࡵࡁࠬᅛ"),D2PpKMeZFWrmfxTSs4L1tz(u"࠶ᛯ"))[w8JC1y7Lp3(u"࠶ᛰ")]+w8JC1y7Lp3(u"࠭ࠩࠨᅜ")
	tn3ZeYlVaT0rXMg = Kw19luY7W2jGgsBa5n4hctLfFS.lower()
	UugkK2rmXcVHo3FdQZaiOBCLpEe1z = TeuQd8DXNkc0zlYmKF2J in [wTLFCOcM26fmYlW7U,it4DKnryZlx(u"࠳࠳࠸ᛳ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠱࠱࠲࠹࠵ᛱ"),xm6jK1ZMuWq5(u"࠲࠳࠴ᛲ")]
	lkHiMjPt53N7wsKxIRWLa = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᅝ") in tn3ZeYlVaT0rXMg
	tsYdlAojkNz = A6Sg45ChDR3BJLYfFH(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨᅞ") in tn3ZeYlVaT0rXMg
	cICGBOj86izlLtro = VhqD3zp7mUieI8sMQlETH(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩᅟ") in tn3ZeYlVaT0rXMg
	fdL9MXzCphkQ = Gj3rMP1Cb8wHdp49la0(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬᅠ") in tn3ZeYlVaT0rXMg
	ZRmGunFEpOAlMW1dV43jLkDXT5 = llkFwuCyhaP3sK76qO4T(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠦࡣࡩࡧࡦ࡯ࠬᅡ") in tn3ZeYlVaT0rXMg
	X0XxIn3wCHAZ8kGJTpPm = yRWQMHxZEz0(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡼࡳࡺࡸࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡࡦࡨࡺ࡮ࡩࡥࡴࠩᅢ") in tn3ZeYlVaT0rXMg
	OBNsaX0kCqDZorFG4TePIjcldKQMRE = OOnvcPQy85HYA.getSetting(JHMxIE4fs1mvQtKW7R(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᅣ"))
	z1VijOELhCfHTgvsI5y7tdDomxY2F = OOnvcPQy85HYA.getSetting(vWNRusF46D7Mi8GpZ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᅤ"))
	ffQHRKxObrVidTIX3LvoMjz57 = xm6jK1ZMuWq5(u"ࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪᅥ")
	w4R8VjJrt1pZ = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡈࡶࡷࡵࡲࠡࠩᅦ")+str(TeuQd8DXNkc0zlYmKF2J)+Gj3rMP1Cb8wHdp49la0(u"ࠪ࠾ࠥ࠭ᅧ")+Kw19luY7W2jGgsBa5n4hctLfFS
	w4R8VjJrt1pZ = Z6bUG0kDQuFqgzdAa1r(w4R8VjJrt1pZ)
	if any([UugkK2rmXcVHo3FdQZaiOBCLpEe1z,lkHiMjPt53N7wsKxIRWLa,tsYdlAojkNz,cICGBOj86izlLtro,fdL9MXzCphkQ,ZRmGunFEpOAlMW1dV43jLkDXT5,X0XxIn3wCHAZ8kGJTpPm]): ffQHRKxObrVidTIX3LvoMjz57 += ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࠥ࠴ࠠศๆ่์็฿ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡสส่๊๎โฺ࡞ࡱࠫᅨ")
	if UZQutfKrN1AIYg: ffQHRKxObrVidTIX3LvoMjz57 += rDG9dZoXRhCJcieUSF0KB(u"ࠬࠦ࠮ࠡๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้࡟ࡲࠬᅩ")
	w4R8VjJrt1pZ = QWLr8ABjev+JegF7SlMawI03+w4R8VjJrt1pZ+AAByQSLgaZwCsKnvc5eWNmY
	if OBNsaX0kCqDZorFG4TePIjcldKQMRE==kPCxIUZb1V(u"࠭ࡁࡔࡍࠪᅪ") or z1VijOELhCfHTgvsI5y7tdDomxY2F==lCT8hfYUBX4OQMmL(u"ࠧࡂࡕࡎࠫᅫ"):
		ffQHRKxObrVidTIX3LvoMjz57 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+it4DKnryZlx(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠣࠪᅬ")+AAByQSLgaZwCsKnvc5eWNmY
	ZU5x6fKe4BFRISNDa9 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if OBNsaX0kCqDZorFG4TePIjcldKQMRE==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡄࡗࡐ࠭ᅭ") or z1VijOELhCfHTgvsI5y7tdDomxY2F==rDG9dZoXRhCJcieUSF0KB(u"ࠪࡅࡘࡑࠧᅮ"):
		nV02gQlNqjHvTX5eYJ8xfdkp1u = E74G0qBSpwUPLO56fsReHCl(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᅯ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠬิั้ฮࠪᅰ"),DpRJnas65uVcO0S17dYG(u"࠭ลาีส่๊ࠥไๆสิ้ั࠭ᅱ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧหื็๎าࠦวๅ็ื็้ฯࠧᅲ"),g40I3ZXaeJ8qVywt+DQCpAXVq6LHJ0aEFR+c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt),ffQHRKxObrVidTIX3LvoMjz57+QWLr8ABjev+w4R8VjJrt1pZ)
		if nV02gQlNqjHvTX5eYJ8xfdkp1u==UD4N8MjVTd:
			from tdeCZlJnBw import cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED
			cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED()
		elif nV02gQlNqjHvTX5eYJ8xfdkp1u==Tb7oymMnpflsSv3eu4Pz2: ZU5x6fKe4BFRISNDa9 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,g40I3ZXaeJ8qVywt+DQCpAXVq6LHJ0aEFR+c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt),ffQHRKxObrVidTIX3LvoMjz57,w4R8VjJrt1pZ)
	OOnvcPQy85HYA.setSetting(DpRJnas65uVcO0S17dYG(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᅳ"),P3yugDKECHbG6p7Wnvq1SU)
	return ZU5x6fKe4BFRISNDa9
def y5o67NQuEHJqR(G4B0g1rzYn9Hw7y2sPNZDo6m38=Z19pUxa2gfGMNKoDsEuytn85SjFvA,YrW2xD1QCaOZkt7uE4JNB0=[]):
	hiCs2xfG45qgBjKWQrYHP3E6 = [C5VkX6NMYnT2A0PFL,eCcr5AqkmHOSU]+YrW2xD1QCaOZkt7uE4JNB0
	for rgNkiToc6MRPtULJ8BG in b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(kAXGQe4sH7o3dfLUKv2zlZDM8r09):
		if G4B0g1rzYn9Hw7y2sPNZDo6m38 and (rgNkiToc6MRPtULJ8BG.startswith(VhqD3zp7mUieI8sMQlETH(u"ࠩ࡬ࡴࡹࡼࠧᅴ")) or rgNkiToc6MRPtULJ8BG.startswith(VhqD3zp7mUieI8sMQlETH(u"ࠪࡱ࠸ࡻࠧᅵ"))): continue
		if rgNkiToc6MRPtULJ8BG.startswith(erqDsJmL3BQHuGtPkcf0X9(u"ࠫ࡫࡯࡬ࡦࡡࠪᅶ")): continue
		ZZCKFOlovDAzbLXJg2tcVSnUEi = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,rgNkiToc6MRPtULJ8BG)
		if ZZCKFOlovDAzbLXJg2tcVSnUEi in hiCs2xfG45qgBjKWQrYHP3E6: continue
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(ZZCKFOlovDAzbLXJg2tcVSnUEi)
		except: pass
	if CCrtv6o3mySp not in hiCs2xfG45qgBjKWQrYHP3E6: THqDmj0Frnf38wX7MkVZ1u9NaGi(CCrtv6o3mySp,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	L5jXH0fZ8TvsESR.sleep(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠴ᛴ"))
	return
def zz0lgZbsI2uVJ384pPW16C(JfaBuyCRIx5YmW83zngDeqkhwFPp,xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW=y0yvdNOZkiKEg5RLMhoDVQAB9F2,iqfCFuT6RgtD0mL=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	xLDEnp9WdA = xLDEnp9WdA+jQv0du1iVxTgAXCM(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᅷ")+JfaBuyCRIx5YmW83zngDeqkhwFPp
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW,iqfCFuT6RgtD0mL)
	if xLDEnp9WdA in lGQxR39dqyUb1YFcCmjZN5EthrpJ.content: lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if not lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		sKv7WVYzUI()
	return lGQxR39dqyUb1YFcCmjZN5EthrpJ
def O8AxmCGXckPLQ6I0HTVjlYe4(xLDEnp9WdA):
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡇࡆࡖࠪᅸ"),xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨᅹ"),y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	ID6jVf2KCA8 = []
	if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
		ddGp1QtI8ZUMbeXkEoRclyaWP = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠨࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡧࡿ࠶࠲࠳ࡾ࡯ࡶࠫᅺ"),rTAHV8ktdmWCDfxP)
		if ddGp1QtI8ZUMbeXkEoRclyaWP: rTAHV8ktdmWCDfxP = QWLr8ABjev.join(ddGp1QtI8ZUMbeXkEoRclyaWP)
		PpQkYqWJCVwTgiH = rTAHV8ktdmWCDfxP.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(QWLr8ABjev).split(QWLr8ABjev)
		ID6jVf2KCA8 = []
		for JfaBuyCRIx5YmW83zngDeqkhwFPp in PpQkYqWJCVwTgiH:
			if JfaBuyCRIx5YmW83zngDeqkhwFPp.count(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࠱ࠫᅻ"))==MMRBkhnWVJCQwU: ID6jVf2KCA8.append(JfaBuyCRIx5YmW83zngDeqkhwFPp)
	return ID6jVf2KCA8
def u3u4vZH0wtYrBUGig7qn5L(*aargs):
	Ruejl6Nipo4wFCW25G7O0sd8y = bQGafNLXyFgsZP6ut(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫᅼ")
	e84U6DlqOEMA = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨᅽ")
	rruTkLf7bJY = O8AxmCGXckPLQ6I0HTVjlYe4(e84U6DlqOEMA)
	ID6jVf2KCA8 = O8AxmCGXckPLQ6I0HTVjlYe4(Ruejl6Nipo4wFCW25G7O0sd8y)
	pQYLtijmMxworDCKOZ3PyzdTecX = rruTkLf7bJY+ID6jVf2KCA8
	KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫᅾ")+str(len(rruTkLf7bJY))+kPCxIUZb1V(u"࠭ࠫࠨᅿ")+str(len(ID6jVf2KCA8))+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࠡ࡟ࠪᆀ"))
	JfaBuyCRIx5YmW83zngDeqkhwFPp = OOnvcPQy85HYA.getSetting(lCT8hfYUBX4OQMmL(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨᆁ"))
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = D8JlSY7NibwpLWxPXAfFgQsd()
	OOnvcPQy85HYA.setSetting(A6Sg45ChDR3BJLYfFH(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩᆂ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if JfaBuyCRIx5YmW83zngDeqkhwFPp or pQYLtijmMxworDCKOZ3PyzdTecX:
		MLfBSenJx7hP3mTsoQrb,CCOaZv7IcwLueUDFi9pWNBEylr5 = wTLFCOcM26fmYlW7U,Gj3rMP1Cb8wHdp49la0(u"࠵࠵ᛵ")
		JN6lx8fbBKCyDISmwUizV4ORha1uZM = len(pQYLtijmMxworDCKOZ3PyzdTecX)
		wwdXF5r72KRPqulpU = CCOaZv7IcwLueUDFi9pWNBEylr5
		if JN6lx8fbBKCyDISmwUizV4ORha1uZM>wwdXF5r72KRPqulpU: KH4G7jalqoJfhkbyZ0p3 = wwdXF5r72KRPqulpU
		else: KH4G7jalqoJfhkbyZ0p3 = JN6lx8fbBKCyDISmwUizV4ORha1uZM
		RZF1XYhW05erBg7jfV4LJoQliCUAsP = kItsbxAFUXc3.sample(pQYLtijmMxworDCKOZ3PyzdTecX,KH4G7jalqoJfhkbyZ0p3)
		if JfaBuyCRIx5YmW83zngDeqkhwFPp: RZF1XYhW05erBg7jfV4LJoQliCUAsP = [JfaBuyCRIx5YmW83zngDeqkhwFPp]+RZF1XYhW05erBg7jfV4LJoQliCUAsP
		l6TSLuHrc92g8JZMoFvW = ccihgnIMFa(Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		V1VfMqTkXdYulSwF75JPhDgZ = L5jXH0fZ8TvsESR.time()
		while L5jXH0fZ8TvsESR.time()-V1VfMqTkXdYulSwF75JPhDgZ<=CCOaZv7IcwLueUDFi9pWNBEylr5 and not l6TSLuHrc92g8JZMoFvW.finishedLIST:
			if MLfBSenJx7hP3mTsoQrb<KH4G7jalqoJfhkbyZ0p3:
				JfaBuyCRIx5YmW83zngDeqkhwFPp = RZF1XYhW05erBg7jfV4LJoQliCUAsP[MLfBSenJx7hP3mTsoQrb]
				l6TSLuHrc92g8JZMoFvW.y5Fue37azCtRA1SQ9rNGwOgXb(MLfBSenJx7hP3mTsoQrb,zz0lgZbsI2uVJ384pPW16C,JfaBuyCRIx5YmW83zngDeqkhwFPp,*aargs)
			L5jXH0fZ8TvsESR.sleep(JHMxIE4fs1mvQtKW7R(u"࠵࠴࠷࠶ᛶ"))
			MLfBSenJx7hP3mTsoQrb += UD4N8MjVTd
			KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+VhqD3zp7mUieI8sMQlETH(u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬᆃ")+JfaBuyCRIx5YmW83zngDeqkhwFPp+llkFwuCyhaP3sK76qO4T(u"ࠫࠥࡣࠧᆄ"))
		finishedLIST = l6TSLuHrc92g8JZMoFvW.finishedLIST
		if finishedLIST:
			resultsDICT = l6TSLuHrc92g8JZMoFvW.resultsDICT
			bFfw8SvDdhEq4mrBZk7Ny02Mxl = finishedLIST[wTLFCOcM26fmYlW7U]
			lGQxR39dqyUb1YFcCmjZN5EthrpJ = resultsDICT[bFfw8SvDdhEq4mrBZk7Ny02Mxl]
			JfaBuyCRIx5YmW83zngDeqkhwFPp = RZF1XYhW05erBg7jfV4LJoQliCUAsP[int(bFfw8SvDdhEq4mrBZk7Ny02Mxl)]
			OOnvcPQy85HYA.setSetting(bQGafNLXyFgsZP6ut(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬᆅ"),JfaBuyCRIx5YmW83zngDeqkhwFPp)
			if bFfw8SvDdhEq4mrBZk7Ny02Mxl!=wTLFCOcM26fmYlW7U: KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+fmkZtbRj3ux(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩᆆ")+JfaBuyCRIx5YmW83zngDeqkhwFPp+rDG9dZoXRhCJcieUSF0KB(u"ࠧࠡ࡟ࠪᆇ"))
			else: KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+llkFwuCyhaP3sK76qO4T(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡕࡤࡺࡪࡪࠠࡱࡴࡲࡼࡾࡀࠠ࡜ࠢࠪᆈ")+JfaBuyCRIx5YmW83zngDeqkhwFPp+rDG9dZoXRhCJcieUSF0KB(u"ࠩࠣࡡࠬᆉ"))
	return lGQxR39dqyUb1YFcCmjZN5EthrpJ
def ytMNceArC8LkEwJ1DX3oHIKbTQv(jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1,FVPlZImAtH,BaIAUmfzOqYNESLsvFgrWehu=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	IcLsMSzAoGfi0H = jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1.create_connection
	def e4fC9FyEnJRaDc6S7bmstrN(VO71HqvAY98walDU5SM3fCmcQpWnR,*aargs,**kkwargs):
		PFWjOnk54vq0fmEecwJrbpHoatlsVX,TdmwDr8SEt1F = VO71HqvAY98walDU5SM3fCmcQpWnR
		ooNetxzVOAy2GF6HYcurCfLi = QmwBLxaEjpHvU6PAY(PFWjOnk54vq0fmEecwJrbpHoatlsVX,FVPlZImAtH)
		if ooNetxzVOAy2GF6HYcurCfLi: PFWjOnk54vq0fmEecwJrbpHoatlsVX = ooNetxzVOAy2GF6HYcurCfLi[wTLFCOcM26fmYlW7U]
		elif BaIAUmfzOqYNESLsvFgrWehu:
			if FVPlZImAtH in TTuO14NzmB.DNS_SERVERS: TTuO14NzmB.DNS_SERVERS.remove(FVPlZImAtH)
			if TTuO14NzmB.DNS_SERVERS:
				KxNPfvbaXnm9gDTYZSzw1Q4o = TTuO14NzmB.DNS_SERVERS[wTLFCOcM26fmYlW7U]
				ooNetxzVOAy2GF6HYcurCfLi = QmwBLxaEjpHvU6PAY(PFWjOnk54vq0fmEecwJrbpHoatlsVX,KxNPfvbaXnm9gDTYZSzw1Q4o)
				if ooNetxzVOAy2GF6HYcurCfLi: PFWjOnk54vq0fmEecwJrbpHoatlsVX = ooNetxzVOAy2GF6HYcurCfLi[wTLFCOcM26fmYlW7U]
		if ooNetxzVOAy2GF6HYcurCfLi: TTuO14NzmB.dns_succeeded_urls.append(PFWjOnk54vq0fmEecwJrbpHoatlsVX)
		VO71HqvAY98walDU5SM3fCmcQpWnR = (PFWjOnk54vq0fmEecwJrbpHoatlsVX,TdmwDr8SEt1F)
		return IcLsMSzAoGfi0H(VO71HqvAY98walDU5SM3fCmcQpWnR,*aargs,**kkwargs)
	jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1.create_connection = e4fC9FyEnJRaDc6S7bmstrN
	return IcLsMSzAoGfi0H
def F3qNwpnPeXilWKtJrZBao(xLDEnp9WdA):
	ScVp6vTz1QsMe4Hnj58Db9A3,OtsRSGpYu8VZUW6rDza = xLDEnp9WdA.split(MFhbWia58mP3su0fk2d(u"ࠪ࠳ࠬᆊ"))[Tb7oymMnpflsSv3eu4Pz2],s149dk8uh2p7oFzaLxZeI3Or(u"࠾࠰ᛷ")
	if ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࠿࠭ᆋ") in ScVp6vTz1QsMe4Hnj58Db9A3: ScVp6vTz1QsMe4Hnj58Db9A3,OtsRSGpYu8VZUW6rDza = ScVp6vTz1QsMe4Hnj58Db9A3.split(VhqD3zp7mUieI8sMQlETH(u"ࠬࡀࠧᆌ"))
	hheqNGwkay57TIt3QpRDLsf1A9UBcZ = fmkZtbRj3ux(u"࠭࠯ࠨᆍ")+kPCxIUZb1V(u"ࠧ࠰ࠩᆎ").join(xLDEnp9WdA.split(xdSThjYnuHXAU6M(u"ࠨ࠱ࠪᆏ"))[vWNRusF46D7Mi8GpZ(u"࠳ᛸ"):])
	ySY5NxERP6jeVG = yRWQMHxZEz0(u"ࠩࡊࡉ࡙ࠦࠧᆐ")+hheqNGwkay57TIt3QpRDLsf1A9UBcZ+yRWQMHxZEz0(u"ࠪࠤࡍ࡚ࡔࡑ࠱࠴࠲࠶ࡢࡲ࡝ࡰࠪᆑ")
	ySY5NxERP6jeVG += SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡍࡵࡳࡵ࠼ࠣࠫᆒ")+ScVp6vTz1QsMe4Hnj58Db9A3+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡢࡲ࡝ࡰࠪᆓ")
	ySY5NxERP6jeVG += xm6jK1ZMuWq5(u"࠭࡜ࡳ࡞ࡱࠫᆔ")
	from socket import socket as kkTDvdS6LY24nsjJMp3ba5uQmiX,AF_INET as EFJp4qZUo6cb3BDMzXOySgfT,SOCK_STREAM as O7Ii4SVuMRZQCbmYt
	try:
		UGHMswWVrIJ46iv5Px3kcZb = kkTDvdS6LY24nsjJMp3ba5uQmiX(EFJp4qZUo6cb3BDMzXOySgfT,O7Ii4SVuMRZQCbmYt)
		UGHMswWVrIJ46iv5Px3kcZb.connect((ScVp6vTz1QsMe4Hnj58Db9A3,OtsRSGpYu8VZUW6rDza))
		UGHMswWVrIJ46iv5Px3kcZb.send(ySY5NxERP6jeVG.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq))
		HrmKqswEJiFzjxIDn8Q = UGHMswWVrIJ46iv5Px3kcZb.recv(kPCxIUZb1V(u"࠶࠳࠽࠻᛺")*rDG9dZoXRhCJcieUSF0KB(u"࠲࠲࠵࠸᛹"))
		rTAHV8ktdmWCDfxP = repr(HrmKqswEJiFzjxIDn8Q)
	except: rTAHV8ktdmWCDfxP = wUvcPrYDfISbZolAm83GKEqMyXkn5
	return rTAHV8ktdmWCDfxP
def rg5W67jZQdSPH0(eAnsgb5pScxO70ZPjRMiy):
	SnfOUQsJM5EvmAcGVpa = repr(eAnsgb5pScxO70ZPjRMiy.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).replace(vWNRusF46D7Mi8GpZ(u"ࠢࠨࠤᆕ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	return SnfOUQsJM5EvmAcGVpa
def ixCwD64eNn8zKkm2Jb(SgXOyrCEplP0MJfYvVi7mR8GwZLQtB):
	OUgW4renlLwyHb6 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if ndib93Ol6UojCrEV: SgXOyrCEplP0MJfYvVi7mR8GwZLQtB = SgXOyrCEplP0MJfYvVi7mR8GwZLQtB.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	from unicodedata import decomposition as KCWwf7A4rbtUiY82I9ZvBmcp
	for x83gDwnzUm4Aj in SgXOyrCEplP0MJfYvVi7mR8GwZLQtB:
		if   x83gDwnzUm4Aj==DpRJnas65uVcO0S17dYG(u"ࡶࠩลࠫᆖ"): edqYtTPBIh5kcEMC8ZK3FvzoUy7 = rDG9dZoXRhCJcieUSF0KB(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ࠪᆗ")
		elif x83gDwnzUm4Aj==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࡸࠫศ࠭ᆘ"): edqYtTPBIh5kcEMC8ZK3FvzoUy7 = xdSThjYnuHXAU6M(u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬᆙ")
		elif x83gDwnzUm4Aj==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࡺ࠭ฤࠨᆚ"): edqYtTPBIh5kcEMC8ZK3FvzoUy7 = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧᆛ")
		elif x83gDwnzUm4Aj==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࡵࠨวࠪᆜ"): edqYtTPBIh5kcEMC8ZK3FvzoUy7 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ࠩᆝ")
		elif x83gDwnzUm4Aj==TNw1pBHb8CtSZe0EFxuJqI(u"ࡷࠪสࠬᆞ"): edqYtTPBIh5kcEMC8ZK3FvzoUy7 = erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡠࡡࡻ࠰࠷࠴࠹ࠫᆟ")
		else:
			d9vqym0lfXrwITH6WigCK1SBk4 = KCWwf7A4rbtUiY82I9ZvBmcp(x83gDwnzUm4Aj)
			if UKFZBQAVXHI5s17LyvuRpCY2 in d9vqym0lfXrwITH6WigCK1SBk4: edqYtTPBIh5kcEMC8ZK3FvzoUy7 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡡࡢࡵࠨᆠ")+d9vqym0lfXrwITH6WigCK1SBk4.split(UKFZBQAVXHI5s17LyvuRpCY2,UD4N8MjVTd)[UD4N8MjVTd]
			else:
				edqYtTPBIh5kcEMC8ZK3FvzoUy7 = xdSThjYnuHXAU6M(u"ࠬ࠶࠰࠱࠲ࠪᆡ")+hex(ord(x83gDwnzUm4Aj)).replace(A6Sg45ChDR3BJLYfFH(u"࠭࠰ࡹࠩᆢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				edqYtTPBIh5kcEMC8ZK3FvzoUy7 = bQGafNLXyFgsZP6ut(u"ࠧ࡝࡞ࡸࠫᆣ")+edqYtTPBIh5kcEMC8ZK3FvzoUy7[-R9RNUT6WAPEYjHqtIokxuXs:]
		OUgW4renlLwyHb6 += edqYtTPBIh5kcEMC8ZK3FvzoUy7
	OUgW4renlLwyHb6 = OUgW4renlLwyHb6.replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࡞࡟ࡹ࠵࠼ࡃࡄࠩᆤ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ࡟ࡠࡺ࠶࠶࠵࠻ࠪᆥ"))
	if ndib93Ol6UojCrEV: OUgW4renlLwyHb6 = OUgW4renlLwyHb6.decode(w8JC1y7Lp3(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫᆦ")).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	else: OUgW4renlLwyHb6 = OUgW4renlLwyHb6.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).decode(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬᆧ"))
	return OUgW4renlLwyHb6
def BPqorNHKYQ7Lv5WTpcgXzld3kSwnA(header=xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"๊่ࠬฮหࠣห้๋แศฬํัࠬᆨ"),KKJDx34POf=wUvcPrYDfISbZolAm83GKEqMyXkn5,HsiqahOY2ZKujQE8n5UlSCGTmy=Z19pUxa2gfGMNKoDsEuytn85SjFvA,source=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	UWErGF2TqoQ = OmAdpxn2q3RFcv4JkTfoGM(header,KKJDx34POf,type=llfAzdjaVLTbyZW7op9i.INPUT_ALPHANUM)
	UWErGF2TqoQ = UWErGF2TqoQ.strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(fy2aLFcjDnoxIzGi1gp7,UKFZBQAVXHI5s17LyvuRpCY2).replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	if not UWErGF2TqoQ and not HsiqahOY2ZKujQE8n5UlSCGTmy:
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,llkFwuCyhaP3sK76qO4T(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪᆩ")+UWErGF2TqoQ+Gj3rMP1Cb8wHdp49la0(u"ࠧࠣࠩᆪ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫᆫ"))
		return wUvcPrYDfISbZolAm83GKEqMyXkn5
	if UWErGF2TqoQ not in [wUvcPrYDfISbZolAm83GKEqMyXkn5,UKFZBQAVXHI5s17LyvuRpCY2]:
		UWErGF2TqoQ = UWErGF2TqoQ.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		UWErGF2TqoQ = ixCwD64eNn8zKkm2Jb(UWErGF2TqoQ)
	if source!=vWNRusF46D7Mi8GpZ(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫᆬ") and BBXMogDz3d(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈࠬᆭ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,[UWErGF2TqoQ],Z19pUxa2gfGMNKoDsEuytn85SjFvA):
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,A6Sg45ChDR3BJLYfFH(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧᆮ")+UWErGF2TqoQ+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࠨࠧᆯ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨᆰ"))
		return wUvcPrYDfISbZolAm83GKEqMyXkn5
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡦࡲ࡬ࡰࡹࡨࡨ࠿ࠦࠠࠡࠤࠪᆱ")+UWErGF2TqoQ+llkFwuCyhaP3sK76qO4T(u"ࠨࠤࠪᆲ"))
	return UWErGF2TqoQ
def kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,ZD5n0eJivzWOMxY98dgrumkwRG,XubVRNO48BsjJASlmeKwdTCr={}):
	xLDEnp9WdA,FCv8DtAbaW2gsBhw5,RYA0WhcGHbCiajmluQ4Stz1spVK,s6mKNCtA1y7TR8Xl2pcLrV5IDB = ZD5n0eJivzWOMxY98dgrumkwRG,{},{},wUvcPrYDfISbZolAm83GKEqMyXkn5
	if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡿࠫᆳ") in ZD5n0eJivzWOMxY98dgrumkwRG: xLDEnp9WdA,FCv8DtAbaW2gsBhw5 = ibEuGXOqxHp(ZD5n0eJivzWOMxY98dgrumkwRG,lCT8hfYUBX4OQMmL(u"ࠪࢀࠬᆴ"))
	TLbwuvpjOMQN6C7z2ISBeAFfgt = list(set(list(XubVRNO48BsjJASlmeKwdTCr.keys())+list(FCv8DtAbaW2gsBhw5.keys())))
	for NH79yB8ocSkVP2IRdOeE6UrXuh in TLbwuvpjOMQN6C7z2ISBeAFfgt:
		if NH79yB8ocSkVP2IRdOeE6UrXuh in list(FCv8DtAbaW2gsBhw5.keys()): RYA0WhcGHbCiajmluQ4Stz1spVK[NH79yB8ocSkVP2IRdOeE6UrXuh] = FCv8DtAbaW2gsBhw5[NH79yB8ocSkVP2IRdOeE6UrXuh]
		else: RYA0WhcGHbCiajmluQ4Stz1spVK[NH79yB8ocSkVP2IRdOeE6UrXuh] = XubVRNO48BsjJASlmeKwdTCr[NH79yB8ocSkVP2IRdOeE6UrXuh]
	if kPCxIUZb1V(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᆵ") not in TLbwuvpjOMQN6C7z2ISBeAFfgt: RYA0WhcGHbCiajmluQ4Stz1spVK[llkFwuCyhaP3sK76qO4T(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᆶ")] = ZZIDf1A9vE0g86RMq7tpKUrzaij()
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᆷ") not in TLbwuvpjOMQN6C7z2ISBeAFfgt: RYA0WhcGHbCiajmluQ4Stz1spVK[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᆸ")] = TO3vi2rSZ0LRhKlwgG4qkYFIC(xLDEnp9WdA,it4DKnryZlx(u"ࠨࡷࡵࡰࠬᆹ"))
	if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫᆺ") not in TLbwuvpjOMQN6C7z2ISBeAFfgt: RYA0WhcGHbCiajmluQ4Stz1spVK[JHMxIE4fs1mvQtKW7R(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬᆻ")] = JHMxIE4fs1mvQtKW7R(u"ࠫࡪࡴࠬࡢࡴ࠾ࡵࡂ࠶࠮࠺ࠩᆼ")
	for NH79yB8ocSkVP2IRdOeE6UrXuh in list(RYA0WhcGHbCiajmluQ4Stz1spVK.keys()): s6mKNCtA1y7TR8Xl2pcLrV5IDB += jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࠬࠧᆽ")+NH79yB8ocSkVP2IRdOeE6UrXuh+TNw1pBHb8CtSZe0EFxuJqI(u"࠭࠽ࠨᆾ")+RYA0WhcGHbCiajmluQ4Stz1spVK[NH79yB8ocSkVP2IRdOeE6UrXuh]
	if s6mKNCtA1y7TR8Xl2pcLrV5IDB: s6mKNCtA1y7TR8Xl2pcLrV5IDB = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡽࠩᆿ")+s6mKNCtA1y7TR8Xl2pcLrV5IDB[UD4N8MjVTd:]
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X,fmkZtbRj3ux(u"ࠨࡉࡈࡘࠬᇀ"),xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5,RYA0WhcGHbCiajmluQ4Stz1spVK,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ᇁ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
	if bQGafNLXyFgsZP6ut(u"ࠪࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌࠧᇂ") not in rTAHV8ktdmWCDfxP: return [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫ࠲࠷ࠧᇃ")],[xLDEnp9WdA+s6mKNCtA1y7TR8Xl2pcLrV5IDB]
	if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࡚࡙ࠬࡑࡇࡀࡅ࡚ࡊࡉࡐࠩᇄ") in rTAHV8ktdmWCDfxP: return [w8JC1y7Lp3(u"࠭࠭࠲ࠩᇅ")],[xLDEnp9WdA+s6mKNCtA1y7TR8Xl2pcLrV5IDB]
	if lCT8hfYUBX4OQMmL(u"ࠧࡕ࡛ࡓࡉࡂ࡜ࡉࡅࡇࡒࠫᇆ") in rTAHV8ktdmWCDfxP: return [yRWQMHxZEz0(u"ࠨ࠯࠴ࠫᇇ")],[xLDEnp9WdA+s6mKNCtA1y7TR8Xl2pcLrV5IDB]
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,BxS15Fn7ANYW4aM6z,g9wZ6kxWXf3pth4 = [],[],[],[]
	sDMqyG0jAOK = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࠦࡉ࡝࡚࡙࠭࠯ࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠪᇈ"),rTAHV8ktdmWCDfxP+QWLr8ABjev,jj0dZrgiKb.DOTALL)
	if not sDMqyG0jAOK: return [jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪ࠱࠶࠭ᇉ")],[xLDEnp9WdA+s6mKNCtA1y7TR8Xl2pcLrV5IDB]
	for lltPTydzA5,Tor7SKmsCPZvL in sDMqyG0jAOK:
		y3yUoPk0ZnchMbtKFDNGef9,oqF5GjVvYXpBd1l2xmWL0n3kU,KwSdzRXT0M3VW = {},-yRWQMHxZEz0(u"࠴᛻"),-yRWQMHxZEz0(u"࠴᛻")
		iUJctfYkXpWswaFLrd28OuS0B = wUvcPrYDfISbZolAm83GKEqMyXkn5
		clSTVMAyhPBOv = lltPTydzA5.split(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࠱࠭ᇊ"))
		for Og15JMhL8ArokEY2G in clSTVMAyhPBOv:
			if JHMxIE4fs1mvQtKW7R(u"ࠬࡃࠧᇋ") in Og15JMhL8ArokEY2G:
				NH79yB8ocSkVP2IRdOeE6UrXuh,neGOw8MuxH5gCSk4 = Og15JMhL8ArokEY2G.split(xdSThjYnuHXAU6M(u"࠭࠽ࠨᇌ"),jQv0du1iVxTgAXCM(u"࠵᛼"))
				y3yUoPk0ZnchMbtKFDNGef9[NH79yB8ocSkVP2IRdOeE6UrXuh.lower()] = neGOw8MuxH5gCSk4
		if D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫᇍ") in lltPTydzA5.lower():
			oqF5GjVvYXpBd1l2xmWL0n3kU = int(y3yUoPk0ZnchMbtKFDNGef9[llkFwuCyhaP3sK76qO4T(u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬᇎ")])//DpRJnas65uVcO0S17dYG(u"࠶࠶࠲࠵᛽")
			iUJctfYkXpWswaFLrd28OuS0B += str(oqF5GjVvYXpBd1l2xmWL0n3kU)+fmkZtbRj3ux(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩᇏ")
		elif llkFwuCyhaP3sK76qO4T(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ᇐ") in lltPTydzA5.lower():
			oqF5GjVvYXpBd1l2xmWL0n3kU = int(y3yUoPk0ZnchMbtKFDNGef9[VhqD3zp7mUieI8sMQlETH(u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧᇑ")])//weh7SGmuTgXOVRcMo1rlLq(u"࠷࠰࠳࠶᛾")
			iUJctfYkXpWswaFLrd28OuS0B += str(oqF5GjVvYXpBd1l2xmWL0n3kU)+yRWQMHxZEz0(u"ࠬࡱࡢࡱࡵࠣࠤࠬᇒ")
		if MFhbWia58mP3su0fk2d(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪᇓ") in lltPTydzA5.lower():
			KwSdzRXT0M3VW = int(y3yUoPk0ZnchMbtKFDNGef9[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫᇔ")].split(yRWQMHxZEz0(u"ࠨࡺࠪᇕ"))[UD4N8MjVTd])
			iUJctfYkXpWswaFLrd28OuS0B += str(KwSdzRXT0M3VW)+lB8tuyg6sxkDVYAaS95K3GI
		iUJctfYkXpWswaFLrd28OuS0B = iUJctfYkXpWswaFLrd28OuS0B.strip(lB8tuyg6sxkDVYAaS95K3GI)
		if not iUJctfYkXpWswaFLrd28OuS0B: iUJctfYkXpWswaFLrd28OuS0B = TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪᇖ")
		if not Tor7SKmsCPZvL.startswith(xm6jK1ZMuWq5(u"ࠪ࡬ࡹࡺࡰࠨᇗ")):
			if Tor7SKmsCPZvL.startswith(it4DKnryZlx(u"ࠫ࠴࠵ࠧᇘ")): Tor7SKmsCPZvL = xLDEnp9WdA.split(xm6jK1ZMuWq5(u"ࠬࡀࠧᇙ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]+erqDsJmL3BQHuGtPkcf0X9(u"࠭࠺ࠨᇚ")+Tor7SKmsCPZvL
			elif Tor7SKmsCPZvL.startswith(llkFwuCyhaP3sK76qO4T(u"ࠧ࠰ࠩᇛ")): Tor7SKmsCPZvL = TO3vi2rSZ0LRhKlwgG4qkYFIC(xLDEnp9WdA,lCT8hfYUBX4OQMmL(u"ࠨࡷࡵࡰࠬᇜ"))+Tor7SKmsCPZvL
			else: Tor7SKmsCPZvL = xLDEnp9WdA.rsplit(lCT8hfYUBX4OQMmL(u"ࠩ࠲ࠫᇝ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]+erqDsJmL3BQHuGtPkcf0X9(u"ࠪ࠳ࠬᇞ")+Tor7SKmsCPZvL
		if vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ᇟ") in list(y3yUoPk0ZnchMbtKFDNGef9.keys()):
			q4zyW5Bpx6Y2O = y3yUoPk0ZnchMbtKFDNGef9[weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧᇠ")]
			q4zyW5Bpx6Y2O = q4zyW5Bpx6Y2O.replace(lCT8hfYUBX4OQMmL(u"࠭ࠢࠨᇡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠢࠨࠤᇢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).split(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࠥࠪᇣ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
			cUCwLQ3jTsKrNOyR1 = rjZFa0VMBuPRHg1cIYJpd52oxl4(q4zyW5Bpx6Y2O)
			if cUCwLQ3jTsKrNOyR1: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = iUJctfYkXpWswaFLrd28OuS0B+lB8tuyg6sxkDVYAaS95K3GI+cUCwLQ3jTsKrNOyR1
			else: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = iUJctfYkXpWswaFLrd28OuS0B
			HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ+MFhbWia58mP3su0fk2d(u"ࠩࠣࠤࡕࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦࠩᇤ")
			HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ+lB8tuyg6sxkDVYAaS95K3GI+TO3vi2rSZ0LRhKlwgG4qkYFIC(q4zyW5Bpx6Y2O,llkFwuCyhaP3sK76qO4T(u"ࠪࡲࡦࡳࡥࠨᇥ"))
			Eu8LWnSt3fyJzIC.append(HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(q4zyW5Bpx6Y2O)
			BxS15Fn7ANYW4aM6z.append(KwSdzRXT0M3VW)
			g9wZ6kxWXf3pth4.append(oqF5GjVvYXpBd1l2xmWL0n3kU)
		Tor7SKmsCPZvL = Tor7SKmsCPZvL.split(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࠨ࠭ᇦ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		cUCwLQ3jTsKrNOyR1 = rjZFa0VMBuPRHg1cIYJpd52oxl4(Tor7SKmsCPZvL)
		if cUCwLQ3jTsKrNOyR1: iUJctfYkXpWswaFLrd28OuS0B = iUJctfYkXpWswaFLrd28OuS0B+lB8tuyg6sxkDVYAaS95K3GI+cUCwLQ3jTsKrNOyR1
		iUJctfYkXpWswaFLrd28OuS0B = iUJctfYkXpWswaFLrd28OuS0B+lB8tuyg6sxkDVYAaS95K3GI+TO3vi2rSZ0LRhKlwgG4qkYFIC(Tor7SKmsCPZvL,vWNRusF46D7Mi8GpZ(u"ࠬࡴࡡ࡮ࡧࠪᇧ"))
		Eu8LWnSt3fyJzIC.append(iUJctfYkXpWswaFLrd28OuS0B)
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(Tor7SKmsCPZvL)
		BxS15Fn7ANYW4aM6z.append(KwSdzRXT0M3VW)
		g9wZ6kxWXf3pth4.append(oqF5GjVvYXpBd1l2xmWL0n3kU)
	JIO9qPGcfs76XSU0KCh1 = list(zip(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,BxS15Fn7ANYW4aM6z,g9wZ6kxWXf3pth4))
	JIO9qPGcfs76XSU0KCh1 = sorted(JIO9qPGcfs76XSU0KCh1, reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2, key=lambda key: key[MMRBkhnWVJCQwU])
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,BxS15Fn7ANYW4aM6z,g9wZ6kxWXf3pth4 = list(zip(*JIO9qPGcfs76XSU0KCh1))
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = list(Eu8LWnSt3fyJzIC),list(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	lI7nrTA6abMO = []
	for Tor7SKmsCPZvL in j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: lI7nrTA6abMO.append(Tor7SKmsCPZvL+s6mKNCtA1y7TR8Xl2pcLrV5IDB)
	o1o67KC0AmaJGuz2kbeLgr4d3RE = list(zip(lI7nrTA6abMO,[s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡤࡶ࡯ࡰࡽࠬᇨ")]*len(lI7nrTA6abMO),g9wZ6kxWXf3pth4))
	Xj7AVcg5pZTvYHMDayqEGtrzS = L9GcjSEeQJUZuCRrg(UdbRGoKhcDeI4lVfns5,o1o67KC0AmaJGuz2kbeLgr4d3RE)
	if Xj7AVcg5pZTvYHMDayqEGtrzS:
		hhEH1rcSP0z6Bkqy8OD,vziHL4xVFSD81W7X9Noyrdjb,oqF5GjVvYXpBd1l2xmWL0n3kU = Xj7AVcg5pZTvYHMDayqEGtrzS[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠰᛿")]
		index = lI7nrTA6abMO.index(hhEH1rcSP0z6Bkqy8OD)
		title = Eu8LWnSt3fyJzIC[index]
		Eu8LWnSt3fyJzIC,lI7nrTA6abMO = [title],[hhEH1rcSP0z6Bkqy8OD]
	return Eu8LWnSt3fyJzIC,lI7nrTA6abMO
def QmwBLxaEjpHvU6PAY(PFWjOnk54vq0fmEecwJrbpHoatlsVX,FVPlZImAtH=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not FVPlZImAtH: FVPlZImAtH = TTuO14NzmB.DNS_SERVERS[wTLFCOcM26fmYlW7U]
	if PFWjOnk54vq0fmEecwJrbpHoatlsVX.replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠯ࠩᇩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).isdigit(): return [PFWjOnk54vq0fmEecwJrbpHoatlsVX]
	from struct import pack as UVcxHk9nEqzo4pfDBl,unpack_from as whOl1i2Cd4NzQgA
	from socket import socket as kkTDvdS6LY24nsjJMp3ba5uQmiX,AF_INET as EFJp4qZUo6cb3BDMzXOySgfT,SOCK_DGRAM as cQFGlMswTI
	try:
		j28zIOHlPaL394fSvMdW = UVcxHk9nEqzo4pfDBl(llkFwuCyhaP3sK76qO4T(u"ࠣࡀࡋࠦᇪ"), A6Sg45ChDR3BJLYfFH(u"࠲࠴࠳࠸࠾ᜀ"))
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠤࡁࡌࠧᇫ"), weh7SGmuTgXOVRcMo1rlLq(u"࠴࠸࠺ᜁ"))
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠥࡂࡍࠨᇬ"), UD4N8MjVTd)
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(weh7SGmuTgXOVRcMo1rlLq(u"ࠦࡃࡎࠢᇭ"), wTLFCOcM26fmYlW7U)
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(DpRJnas65uVcO0S17dYG(u"ࠧࡄࡈࠣᇮ"), wTLFCOcM26fmYlW7U)
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(s149dk8uh2p7oFzaLxZeI3Or(u"ࠨ࠾ࡉࠤᇯ"), wTLFCOcM26fmYlW7U)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: S1JpA6OnvxH = PFWjOnk54vq0fmEecwJrbpHoatlsVX.split(VhqD3zp7mUieI8sMQlETH(u"ࠧ࠯ࠩᇰ"))
		else: S1JpA6OnvxH = PFWjOnk54vq0fmEecwJrbpHoatlsVX.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).split(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠰ࠪᇱ"))
		for p02p7SoZdwabDH1f6jFWYGLP in S1JpA6OnvxH:
			Y2wFk0J6aZjiU3Xqn458K = p02p7SoZdwabDH1f6jFWYGLP.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(JHMxIE4fs1mvQtKW7R(u"ࠤࡅࠦᇲ"), len(p02p7SoZdwabDH1f6jFWYGLP))
			for NNVx9M7ZfOUhLkDoR8d5m2JGQv in p02p7SoZdwabDH1f6jFWYGLP:
				j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(VhqD3zp7mUieI8sMQlETH(u"ࠥࡧࠧᇳ"), NNVx9M7ZfOUhLkDoR8d5m2JGQv.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq))
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠦࡇࠨᇴ"), wTLFCOcM26fmYlW7U)
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡄࡈࠣᇵ"), UD4N8MjVTd)
		j28zIOHlPaL394fSvMdW += UVcxHk9nEqzo4pfDBl(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠾ࡉࠤᇶ"), UD4N8MjVTd)
		NfJk4dxCjUmQ7gaOW = kkTDvdS6LY24nsjJMp3ba5uQmiX(EFJp4qZUo6cb3BDMzXOySgfT,cQFGlMswTI)
		NfJk4dxCjUmQ7gaOW.sendto(bytes(j28zIOHlPaL394fSvMdW),(FVPlZImAtH,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠷ᜂ")))
		NfJk4dxCjUmQ7gaOW.settimeout(VhqD3zp7mUieI8sMQlETH(u"࠺ᜃ"))
		ZtoUCFcjmabu, pruwnyAiWEIFfmt6 = NfJk4dxCjUmQ7gaOW.recvfrom(Gj3rMP1Cb8wHdp49la0(u"࠶࠶࠲࠵ᜄ"))
		NfJk4dxCjUmQ7gaOW.close()
		Q6BLfDxCt9ZUEkY = whOl1i2Cd4NzQgA(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠢ࠿ࡊࡋࡌࡍࡎࡈࠣᇷ"), ZtoUCFcjmabu, wTLFCOcM26fmYlW7U)
		qaKEFAyQjC6xfJe1LtT = Q6BLfDxCt9ZUEkY[MMRBkhnWVJCQwU]
		w7TgJmYbqa25Cf9StZGrRp0dXo = len(PFWjOnk54vq0fmEecwJrbpHoatlsVX)+s149dk8uh2p7oFzaLxZeI3Or(u"࠷࠸ᜅ")
		SiLq2mwM5R1ZNXxs83T = []
		for _oXjMfCa70kzFBspe8mgEV6un in range(qaKEFAyQjC6xfJe1LtT):
			U43DbmXtRKHWPE7aNF = w7TgJmYbqa25Cf9StZGrRp0dXo
			RkloGwPf3VuLOtQ1pi = UD4N8MjVTd
			SCXKBZ0jLAMxNctf = Z19pUxa2gfGMNKoDsEuytn85SjFvA
			while y0yvdNOZkiKEg5RLMhoDVQAB9F2:
				NNVx9M7ZfOUhLkDoR8d5m2JGQv = whOl1i2Cd4NzQgA(llkFwuCyhaP3sK76qO4T(u"ࠣࡀࡅࠦᇸ"), ZtoUCFcjmabu, U43DbmXtRKHWPE7aNF)[wTLFCOcM26fmYlW7U]
				if NNVx9M7ZfOUhLkDoR8d5m2JGQv == wTLFCOcM26fmYlW7U:
					U43DbmXtRKHWPE7aNF += UD4N8MjVTd
					break
				if NNVx9M7ZfOUhLkDoR8d5m2JGQv >= fmkZtbRj3ux(u"࠱࠺࠴ᜆ"):
					HbAL8pnidPOwoK5kZMXza = whOl1i2Cd4NzQgA(bQGafNLXyFgsZP6ut(u"ࠤࡁࡆࠧᇹ"), ZtoUCFcjmabu, U43DbmXtRKHWPE7aNF + UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
					U43DbmXtRKHWPE7aNF = ((NNVx9M7ZfOUhLkDoR8d5m2JGQv << yRWQMHxZEz0(u"࠹ᜇ")) + HbAL8pnidPOwoK5kZMXza - 0xc000) - UD4N8MjVTd
					SCXKBZ0jLAMxNctf = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				U43DbmXtRKHWPE7aNF += UD4N8MjVTd
				if SCXKBZ0jLAMxNctf == Z19pUxa2gfGMNKoDsEuytn85SjFvA: RkloGwPf3VuLOtQ1pi += UD4N8MjVTd
			if SCXKBZ0jLAMxNctf == y0yvdNOZkiKEg5RLMhoDVQAB9F2: RkloGwPf3VuLOtQ1pi += UD4N8MjVTd
			w7TgJmYbqa25Cf9StZGrRp0dXo = w7TgJmYbqa25Cf9StZGrRp0dXo + RkloGwPf3VuLOtQ1pi
			Lc4UZ08sp7VomlGad5 = whOl1i2Cd4NzQgA(llkFwuCyhaP3sK76qO4T(u"ࠥࡂࡍࡎࡉࡉࠤᇺ"), ZtoUCFcjmabu, w7TgJmYbqa25Cf9StZGrRp0dXo)
			w7TgJmYbqa25Cf9StZGrRp0dXo = w7TgJmYbqa25Cf9StZGrRp0dXo + yRWQMHxZEz0(u"࠳࠳ᜈ")
			zzL0dsJeu62pQKFrWbT8NyY5owA = Lc4UZ08sp7VomlGad5[wTLFCOcM26fmYlW7U]
			M7Nc8hQxgnDtkCOLe = Lc4UZ08sp7VomlGad5[MMRBkhnWVJCQwU]
			if zzL0dsJeu62pQKFrWbT8NyY5owA == UD4N8MjVTd:
				uraI2gWd4qBH5h1tfbcvVJyF7 = whOl1i2Cd4NzQgA(kPCxIUZb1V(u"ࠦࡃࠨᇻ")+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡈࠢᇼ")*M7Nc8hQxgnDtkCOLe, ZtoUCFcjmabu, w7TgJmYbqa25Cf9StZGrRp0dXo)
				ooNetxzVOAy2GF6HYcurCfLi = wUvcPrYDfISbZolAm83GKEqMyXkn5
				for NNVx9M7ZfOUhLkDoR8d5m2JGQv in uraI2gWd4qBH5h1tfbcvVJyF7: ooNetxzVOAy2GF6HYcurCfLi += str(NNVx9M7ZfOUhLkDoR8d5m2JGQv) + lCT8hfYUBX4OQMmL(u"࠭࠮ࠨᇽ")
				ooNetxzVOAy2GF6HYcurCfLi = ooNetxzVOAy2GF6HYcurCfLi[wTLFCOcM26fmYlW7U:-UD4N8MjVTd]
				SiLq2mwM5R1ZNXxs83T.append(ooNetxzVOAy2GF6HYcurCfLi)
			if zzL0dsJeu62pQKFrWbT8NyY5owA in [UD4N8MjVTd,Tb7oymMnpflsSv3eu4Pz2,vvhR5ozeiJpANyl8fFO3GBw(u"࠺ᜋ"),w8JC1y7Lp3(u"࠼ᜌ"),kPCxIUZb1V(u"࠵࠺ᜊ"),rDG9dZoXRhCJcieUSF0KB(u"࠵࠼ᜉ")]: w7TgJmYbqa25Cf9StZGrRp0dXo = w7TgJmYbqa25Cf9StZGrRp0dXo + M7Nc8hQxgnDtkCOLe
	except: SiLq2mwM5R1ZNXxs83T = []
	if not SiLq2mwM5R1ZNXxs83T: KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+llkFwuCyhaP3sK76qO4T(u"ࠧࠡࠢࠣࡈࡓ࡙࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡍࡵࡳࡵ࠼ࠣ࡟ࠥ࠭ᇾ")+PFWjOnk54vq0fmEecwJrbpHoatlsVX+vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࠢࡠࠫᇿ"))
	return SiLq2mwM5R1ZNXxs83T
def BBXMogDz3d(UdbRGoKhcDeI4lVfns5,xLDEnp9WdA,bxiMUQmPRvu,showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	if TTuO14NzmB.avprivsnorestrict or not bxiMUQmPRvu: return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	uqrSGBfWzQO9HtXYc = [rDG9dZoXRhCJcieUSF0KB(u"ࠩࡤࡨࡺࡲࡴࠨሀ"),VhqD3zp7mUieI8sMQlETH(u"ࠪ࠵࠽࠱ࠧሁ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡽࡾࠧሂ"),llkFwuCyhaP3sK76qO4T(u"ࠬࡶ࡯ࡳࡰࠪሃ"),MFhbWia58mP3su0fk2d(u"࠭ࡳࡦࡺࠪሄ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧ࡯ࡵࡩࡻࠬህ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠨ࡯ࡤࡸࡺࡸࡥࠨሆ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩๆฬฬืࠧሇ"),lCT8hfYUBX4OQMmL(u"ࠪฬฬฺ๊ࠨለ"),A6Sg45ChDR3BJLYfFH(u"ࠫฬฮวฮ์ࠪሉ"),Gj3rMP1Cb8wHdp49la0(u"ࠬาๆิࠩሊ"),Gj3rMP1Cb8wHdp49la0(u"࠭ๅๆ่๋฽ࠬላ")]
	if UdbRGoKhcDeI4lVfns5!=D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡃࡑࡎࡖࡆ࠭ሌ"): uqrSGBfWzQO9HtXYc += [pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡴ࠽ࠫል"),rDG9dZoXRhCJcieUSF0KB(u"ࠩ࠽ࡶࠬሎ"),lCT8hfYUBX4OQMmL(u"ࠪࡶ࠲࠭ሏ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࠲ࡸࠧሐ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࠳࡭ࡢࠩሑ"),Gj3rMP1Cb8wHdp49la0(u"࠭࡭ࡢ࠯ࠪሒ")]
	for si4QrCMy2ognmk9lVhztqH06IDjA in bxiMUQmPRvu:
		si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.lower()
		if MFhbWia58mP3su0fk2d(u"ࠧࡨࡧࡷ࠲ࡵ࡮ࡰࡀࠩሓ") in si4QrCMy2ognmk9lVhztqH06IDjA: continue
		if vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫሔ") in si4QrCMy2ognmk9lVhztqH06IDjA: continue
		if xdSThjYnuHXAU6M(u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪሕ") in si4QrCMy2ognmk9lVhztqH06IDjA: continue
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪั้่ษࠨሖ") in si4QrCMy2ognmk9lVhztqH06IDjA: continue
		if Gj3rMP1Cb8wHdp49la0(u"ࠫ฿๐ัࠡ็ุ๊ๆ࠭ሗ") in si4QrCMy2ognmk9lVhztqH06IDjA: continue
		si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬษࠧመ"),erqDsJmL3BQHuGtPkcf0X9(u"࠭วࠨሙ")).replace(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧฦࠩሚ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨษࠪማ")).replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠩลࠫሜ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠪหࠬም")).replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ๓࠭ሞ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(llkFwuCyhaP3sK76qO4T(u"ࠬ๑ࠧሟ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.replace(fmkZtbRj3ux(u"࠭๏ࠨሠ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠧ๑ࠩሡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨ๏ࠪሢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(it4DKnryZlx(u"ࠩ๔ࠫሣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠪไࠬሤ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࠿࠭ሥ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		if ndib93Ol6UojCrEV: si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		dRCFADWOiMBgcSw05omVz6lyK3 = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩሦ"),si4QrCMy2ognmk9lVhztqH06IDjA,jj0dZrgiKb.DOTALL)
		eehlnNG6taJBxqHSPURrTzwdEbZs4 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		for th6ycamPiVeTu4Y8MQ2LBWOkGDJ in dRCFADWOiMBgcSw05omVz6lyK3:
			if len(th6ycamPiVeTu4Y8MQ2LBWOkGDJ)==Tb7oymMnpflsSv3eu4Pz2:
				eehlnNG6taJBxqHSPURrTzwdEbZs4 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				break
		if si4QrCMy2ognmk9lVhztqH06IDjA in [xdSThjYnuHXAU6M(u"࠭ࡲࠨሧ")] or eehlnNG6taJBxqHSPURrTzwdEbZs4 or any(value in si4QrCMy2ognmk9lVhztqH06IDjA for value in uqrSGBfWzQO9HtXYc):
			KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+xdSThjYnuHXAU6M(u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠴࠮࠯࠰࠱ࠤࡢ࠭ረ"))
			if showDialogs: hg79cQmoVfMCukiU8ERpT6JqywSrN3(mvVFtPw8JKpaUdXq06YrEeR7bAk2,erqDsJmL3BQHuGtPkcf0X9(u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪሩ"))
			return y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return Z19pUxa2gfGMNKoDsEuytn85SjFvA
def ZZIDf1A9vE0g86RMq7tpKUrzaij(xPtRzFGKEvjBghTJ=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	if xPtRzFGKEvjBghTJ:
		vpHXP3E6Kt = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡶࡸࡷ࠭ሪ"),kPCxIUZb1V(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨራ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧሬ"))
		if vpHXP3E6Kt: return vpHXP3E6Kt
	UWErGF2TqoQ = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if wTLFCOcM26fmYlW7U and lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
		ygOUXKL0h28HawR = rTAHV8ktdmWCDfxP.count(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭ር"))
		if ygOUXKL0h28HawR>DpRJnas65uVcO0S17dYG(u"࠸࠱ᜍ"):
			UWErGF2TqoQ = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨሮ"),rTAHV8ktdmWCDfxP,jj0dZrgiKb.DOTALL)
			UWErGF2TqoQ = UWErGF2TqoQ[wTLFCOcM26fmYlW7U]
	if not UWErGF2TqoQ:
		JJDALTg7MbPFx92 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,A6Sg45ChDR3BJLYfFH(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ሯ"),A6Sg45ChDR3BJLYfFH(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩሰ"))
		UWErGF2TqoQ = open(JJDALTg7MbPFx92,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡵࡦࠬሱ")).read()
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: UWErGF2TqoQ = UWErGF2TqoQ.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		UWErGF2TqoQ = UWErGF2TqoQ.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	nj7CzHIEwa5UOiTG4lp6tmKsRPWDSr = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫሲ"),UWErGF2TqoQ,jj0dZrgiKb.DOTALL)
	mRSTzg3ZHpxvyQVY = []
	for lltPTydzA5 in nj7CzHIEwa5UOiTG4lp6tmKsRPWDSr:
		NJqbOiX97EkVIH14UFsMWjGhmTevB = lltPTydzA5.lower()
		if A6Sg45ChDR3BJLYfFH(u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬሳ") in NJqbOiX97EkVIH14UFsMWjGhmTevB: continue
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡻࡢࡶࡰࡷࡹࠬሴ") in NJqbOiX97EkVIH14UFsMWjGhmTevB: continue
		if jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡩࡱࡪࡲࡲࡪ࠭ስ") in NJqbOiX97EkVIH14UFsMWjGhmTevB: continue
		if kPCxIUZb1V(u"ࠧࡤࡴࡲࡷࠬሶ") in NJqbOiX97EkVIH14UFsMWjGhmTevB: continue
		mRSTzg3ZHpxvyQVY.append(lltPTydzA5)
	vpHXP3E6Kt = kItsbxAFUXc3.sample(mRSTzg3ZHpxvyQVY,UD4N8MjVTd)
	vpHXP3E6Kt = vpHXP3E6Kt[wTLFCOcM26fmYlW7U]
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,A6Sg45ChDR3BJLYfFH(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭ሷ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬሸ"),vpHXP3E6Kt,d2priEnu57KztRsm8wCHZ)
	return vpHXP3E6Kt
def XWcklrdEuQozqtaK1(av1f8x5yZ9rAsq=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX==Z19pUxa2gfGMNKoDsEuytn85SjFvA: return
	if not av1f8x5yZ9rAsq: av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
	if yRWQMHxZEz0(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧሹ") in av1f8x5yZ9rAsq or MFhbWia58mP3su0fk2d(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧሺ") in av1f8x5yZ9rAsq: return
	if av1f8x5yZ9rAsq!=TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨሻ"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
	sDMqyG0jAOK = av1f8x5yZ9rAsq.splitlines()
	rrXegNV0zTcR = sDMqyG0jAOK[-xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠲ᜎ")]
	DdMLEm4joNAROKsWxS5et8y = open(tiIwFLAE7eaJ3bCxGqumDPNZ2,vWNRusF46D7Mi8GpZ(u"࠭ࡲࡣࠩሼ")).read()
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: DdMLEm4joNAROKsWxS5et8y = DdMLEm4joNAROKsWxS5et8y.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	DdMLEm4joNAROKsWxS5et8y = DdMLEm4joNAROKsWxS5et8y[-xm6jK1ZMuWq5(u"࠺࠳࠴࠵ᜏ"):]
	E6EKdTRc4U = DpRJnas65uVcO0S17dYG(u"ࠧ࠾ࠩሽ")*vvhR5ozeiJpANyl8fFO3GBw(u"࠴࠴࠵ᜐ")
	if E6EKdTRc4U in DdMLEm4joNAROKsWxS5et8y: DdMLEm4joNAROKsWxS5et8y = DdMLEm4joNAROKsWxS5et8y.rsplit(E6EKdTRc4U,UD4N8MjVTd)[UD4N8MjVTd]
	if rrXegNV0zTcR in DdMLEm4joNAROKsWxS5et8y: DdMLEm4joNAROKsWxS5et8y = DdMLEm4joNAROKsWxS5et8y.rsplit(rrXegNV0zTcR,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
	tyo2D40bfYhqZ1Cvr9 = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧሾ"),DdMLEm4joNAROKsWxS5et8y,jj0dZrgiKb.DOTALL)
	for KWxtd60AQIysFfju2DBJhorvXP384m,xVwDZbA6EOjpgX0 in reversed(tyo2D40bfYhqZ1Cvr9):
		if xVwDZbA6EOjpgX0: break
	else: xVwDZbA6EOjpgX0 = kPCxIUZb1V(u"ࠩࡑࡓ࡙ࠦࡓࡑࡇࡆࡍࡋࡏࡅࡅࠩሿ")
	IIDzU1rRTl8s,lltPTydzA5,JEY7pvqkyfrR8OzlmGg3t5SCuN = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	Ui4Pa75Xksjf3 = MFhbWia58mP3su0fk2d(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩቀ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+erqDsJmL3BQHuGtPkcf0X9(u"ࠫฬ๊ฮุล࠽ࠤࠥ࠭ቁ")+AAByQSLgaZwCsKnvc5eWNmY+rrXegNV0zTcR
	vCQjPcifkn5YIDyme = vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡡࡒࡕࡎࡠࠫቂ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+vWNRusF46D7Mi8GpZ(u"࠭วๅ็ุำึࡀࠠࠡࠩቃ")+AAByQSLgaZwCsKnvc5eWNmY+xVwDZbA6EOjpgX0
	for t1V5UJEjLFZcqzMDyS0klWie2wp in reversed(sDMqyG0jAOK):
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧቄ") in t1V5UJEjLFZcqzMDyS0klWie2wp and D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧቅ") in t1V5UJEjLFZcqzMDyS0klWie2wp: break
	t1V5UJEjLFZcqzMDyS0klWie2wp = jj0dZrgiKb.findall(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬቆ"),t1V5UJEjLFZcqzMDyS0klWie2wp,jj0dZrgiKb.DOTALL)
	if t1V5UJEjLFZcqzMDyS0klWie2wp:
		IIDzU1rRTl8s,lltPTydzA5,JEY7pvqkyfrR8OzlmGg3t5SCuN = t1V5UJEjLFZcqzMDyS0klWie2wp[wTLFCOcM26fmYlW7U]
		if rDG9dZoXRhCJcieUSF0KB(u"ࠪ࠳ࠬቇ") in IIDzU1rRTl8s: IIDzU1rRTl8s = IIDzU1rRTl8s.rsplit(erqDsJmL3BQHuGtPkcf0X9(u"ࠫ࠴࠭ቈ"),UD4N8MjVTd)[UD4N8MjVTd]
		else: IIDzU1rRTl8s = IIDzU1rRTl8s.rsplit(fmkZtbRj3ux(u"ࠬࡢ࡜ࠨ቉"),UD4N8MjVTd)[UD4N8MjVTd]
		x3bBnkwS6mg8KAfy2UZT0CYJsrqQPM = fmkZtbRj3ux(u"࡛࠭ࡓࡖࡏࡡࠬቊ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+weh7SGmuTgXOVRcMo1rlLq(u"ࠧศๆ่่ๆࡀࠠࠡࠩቋ")+AAByQSLgaZwCsKnvc5eWNmY+IIDzU1rRTl8s
		hhwpFVz8l94muXJk = jQv0du1iVxTgAXCM(u"ࠨ࡝ࡕࡘࡑࡣࠧቌ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+weh7SGmuTgXOVRcMo1rlLq(u"ࠩสุ่฽ั࠻ࠢࠣࠫቍ")+AAByQSLgaZwCsKnvc5eWNmY+lltPTydzA5
		q81qyeisf7WxOmDS3C4Rour = TNw1pBHb8CtSZe0EFxuJqI(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ቎")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+weh7SGmuTgXOVRcMo1rlLq(u"ࠫฬ๊ๅไษ้࠾ࠥࠦࠧ቏")+AAByQSLgaZwCsKnvc5eWNmY+JEY7pvqkyfrR8OzlmGg3t5SCuN
		xbOVvodzGpkeClBK1fmDErh5YX = x3bBnkwS6mg8KAfy2UZT0CYJsrqQPM+QWLr8ABjev+hhwpFVz8l94muXJk+QWLr8ABjev+q81qyeisf7WxOmDS3C4Rour+QWLr8ABjev+vCQjPcifkn5YIDyme+QWLr8ABjev+Ui4Pa75Xksjf3
		HxUFDZnKWqvBpN30SJswYiyACM = hhwpFVz8l94muXJk+QWLr8ABjev+vCQjPcifkn5YIDyme+QWLr8ABjev+Ui4Pa75Xksjf3+QWLr8ABjev+x3bBnkwS6mg8KAfy2UZT0CYJsrqQPM+QWLr8ABjev+q81qyeisf7WxOmDS3C4Rour
		IHCa1SEicyvonXKldrYf5RNpuzWqMk = hhwpFVz8l94muXJk+QWLr8ABjev+Ui4Pa75Xksjf3+QWLr8ABjev+x3bBnkwS6mg8KAfy2UZT0CYJsrqQPM+QWLr8ABjev+q81qyeisf7WxOmDS3C4Rour
	else:
		x3bBnkwS6mg8KAfy2UZT0CYJsrqQPM,hhwpFVz8l94muXJk,q81qyeisf7WxOmDS3C4Rour = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		xbOVvodzGpkeClBK1fmDErh5YX = vCQjPcifkn5YIDyme+it4DKnryZlx(u"ࠬࡢ࡮࡝ࡰࠪቐ")+Ui4Pa75Xksjf3
		HxUFDZnKWqvBpN30SJswYiyACM = vCQjPcifkn5YIDyme+D2PpKMeZFWrmfxTSs4L1tz(u"࠭࡜࡯࡞ࡱࠫቑ")+Ui4Pa75Xksjf3
		IHCa1SEicyvonXKldrYf5RNpuzWqMk = Ui4Pa75Xksjf3
	had26xsAHLkgcr9uYv4mEfBZb0W1p = xm6jK1ZMuWq5(u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าࠫቒ")+QWLr8ABjev
	JJfb1TQjNWSdBGAM3YmFCr0zOnv = aai3r0JO5dupQUygfq1P7A()
	GVZ7LJQTy8sxu3PY6vHdKgWNf1tX = []
	RCmHBOKtejQ8lu4L = JJfb1TQjNWSdBGAM3YmFCr0zOnv[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ቓ")]
	HWwiToK7CbIfQAOpZe6rxJ5jsG4M = UmOxLC9ayZ2fgM(D1DBSuO0lLGRbcfCyY)
	if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧቔ") in list(JJfb1TQjNWSdBGAM3YmFCr0zOnv.keys()):
		for gxdpYvkIunQT,mVKUNGMoD20HLS8WQP69ylbnIhfwE,ykoNfvPOcMX in RCmHBOKtejQ8lu4L:
			GVZ7LJQTy8sxu3PY6vHdKgWNf1tX = max(GVZ7LJQTy8sxu3PY6vHdKgWNf1tX,mVKUNGMoD20HLS8WQP69ylbnIhfwE)
		if HWwiToK7CbIfQAOpZe6rxJ5jsG4M<GVZ7LJQTy8sxu3PY6vHdKgWNf1tX:
			a0gtPERXB7392ecKFLdshfl = Gj3rMP1Cb8wHdp49la0(u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ั࠭ቕ")
			nV02gQlNqjHvTX5eYJ8xfdkp1u = E74G0qBSpwUPLO56fsReHCl(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡷ࡯ࡧࡩࡶࠪቖ"),A6Sg45ChDR3BJLYfFH(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ቗"),erqDsJmL3BQHuGtPkcf0X9(u"࠭สฮัํฯࠬቘ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧฯำ๋ะࠬ቙"),had26xsAHLkgcr9uYv4mEfBZb0W1p+a0gtPERXB7392ecKFLdshfl,xbOVvodzGpkeClBK1fmDErh5YX)
			if nV02gQlNqjHvTX5eYJ8xfdkp1u==UD4N8MjVTd:
				import tdeCZlJnBw
				tdeCZlJnBw.C7tGsABJHNMUxw85pmRKeI0O6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
				sKv7WVYzUI()
			elif nV02gQlNqjHvTX5eYJ8xfdkp1u==Tb7oymMnpflsSv3eu4Pz2: sKv7WVYzUI()
	cLFtof1P9nlMm0 = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,MFhbWia58mP3su0fk2d(u"ࠨ࡮࡬ࡷࡹ࠭ቚ"),it4DKnryZlx(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬቛ"),lCT8hfYUBX4OQMmL(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬቜ"))
	if not cLFtof1P9nlMm0: cLFtof1P9nlMm0 = []
	HxUFDZnKWqvBpN30SJswYiyACM = HxUFDZnKWqvBpN30SJswYiyACM.replace(QWLr8ABjev,DpRJnas65uVcO0S17dYG(u"ࠫࡡࡢ࡮ࠨቝ")).replace(VhqD3zp7mUieI8sMQlETH(u"ࠬࡡࡒࡕࡎࡠࠫ቞"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	IHCa1SEicyvonXKldrYf5RNpuzWqMk = IHCa1SEicyvonXKldrYf5RNpuzWqMk.replace(QWLr8ABjev,yRWQMHxZEz0(u"࠭࡜࡝ࡰࠪ቟")).replace(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࡜ࡔࡗࡐࡢ࠭በ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	KBrYTHU89PStscE5Xl = D1DBSuO0lLGRbcfCyY+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ࠼࠽ࠫቡ")+IHCa1SEicyvonXKldrYf5RNpuzWqMk
	if KBrYTHU89PStscE5Xl in cLFtof1P9nlMm0:
		a0gtPERXB7392ecKFLdshfl = bQGafNLXyFgsZP6ut(u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧቢ")
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡶ࡮࡭ࡨࡵࠩባ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,had26xsAHLkgcr9uYv4mEfBZb0W1p+a0gtPERXB7392ecKFLdshfl,xbOVvodzGpkeClBK1fmDErh5YX)
		return
	ZzN0AVqnDXcpjEsWu = str(Uy6GWujQiBLhodP).split(llkFwuCyhaP3sK76qO4T(u"ࠫ࠳࠭ቤ"))[wTLFCOcM26fmYlW7U]
	xLDEnp9WdA = TTuO14NzmB.SITESURLS[xdSThjYnuHXAU6M(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬብ")][Gj3rMP1Cb8wHdp49la0(u"࠺ᜑ")]
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,MFhbWia58mP3su0fk2d(u"࠭ࡐࡐࡕࡗࠫቦ"),xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨቧ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
	qo5UmbhWdnFel9X2M = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠨࡕࡗࡅࡗ࡚࠺࠻ࡕࡗࡅࡗ࡚࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࡅࡏࡆ࠽࠾ࡊࡔࡄࠨቨ"),rTAHV8ktdmWCDfxP,jj0dZrgiKb.DOTALL)
	for xpaZLVbmjdcHNFw61U4JWrYT90ehK,Tnq3JGxmf8yNo6eOwPVCbKSku9ip,qZg2rl6LQzpVX0S3IOmwnJi1a,KdluXZCa2W1BGD in qo5UmbhWdnFel9X2M:
		xpaZLVbmjdcHNFw61U4JWrYT90ehK = xpaZLVbmjdcHNFw61U4JWrYT90ehK.split(fmkZtbRj3ux(u"ࠩ࠮ࠫቩ"))
		qZg2rl6LQzpVX0S3IOmwnJi1a = qZg2rl6LQzpVX0S3IOmwnJi1a.split(yRWQMHxZEz0(u"ࠪ࠯ࠬቪ"))
		KdluXZCa2W1BGD = KdluXZCa2W1BGD.split(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠰࠭ቫ"))
		if lltPTydzA5 in xpaZLVbmjdcHNFw61U4JWrYT90ehK and rrXegNV0zTcR==Tnq3JGxmf8yNo6eOwPVCbKSku9ip and D1DBSuO0lLGRbcfCyY in qZg2rl6LQzpVX0S3IOmwnJi1a and ZzN0AVqnDXcpjEsWu in KdluXZCa2W1BGD:
			a0gtPERXB7392ecKFLdshfl = yRWQMHxZEz0(u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪቬ")
			ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(it4DKnryZlx(u"࠭ࡲࡪࡩ࡫ࡸࠬቭ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧฯำ๋ะࠬቮ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬቯ"),had26xsAHLkgcr9uYv4mEfBZb0W1p+a0gtPERXB7392ecKFLdshfl,xbOVvodzGpkeClBK1fmDErh5YX)
			if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(yRWQMHxZEz0(u"ࠩࡦࡩࡳࡺࡥࡳࠩተ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,a0gtPERXB7392ecKFLdshfl)
			return
	a0gtPERXB7392ecKFLdshfl = JHMxIE4fs1mvQtKW7R(u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪቱ")
	choice = E74G0qBSpwUPLO56fsReHCl(yRWQMHxZEz0(u"ࠫࡷ࡯ࡧࡩࡶࠪቲ"),llkFwuCyhaP3sK76qO4T(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩታ"),VhqD3zp7mUieI8sMQlETH(u"࠭สฮัํฯࠥาาว์ࠪቴ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠨት"),had26xsAHLkgcr9uYv4mEfBZb0W1p+a0gtPERXB7392ecKFLdshfl,xbOVvodzGpkeClBK1fmDErh5YX)
	if choice==UD4N8MjVTd:
		zd0StUlGcWbT(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		hg79cQmoVfMCukiU8ERpT6JqywSrN3(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ่ฯัฯูࠦๆๆํอࠥอไหฯา๎ะࠦวๅฮีส๏࠭ቶ"),it4DKnryZlx(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪቷ"),L5jXH0fZ8TvsESR=MFhbWia58mP3su0fk2d(u"࠼࠻࠰ᜒ"))
		sKv7WVYzUI()
	elif choice==Tb7oymMnpflsSv3eu4Pz2:
		import tdeCZlJnBw
		tdeCZlJnBw.C7tGsABJHNMUxw85pmRKeI0O6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		sKv7WVYzUI()
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(VhqD3zp7mUieI8sMQlETH(u"ࠪࡧࡪࡴࡴࡦࡴࠪቸ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"ุࠫ๎แࠡ์อ้ࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์฼ีๆࠦวๅ็หี๊าࠠฤ์้ࠤํ๋ส๊๋ࠢ็๏็้ࠠๆ่หีอࠠฮื็ฮࠥํะ่ࠢสฺ่๊ใๅห่ࠣศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥอีๅษะࠤฺ๊ใๅหࠣ์์๎ࠠๅษࠣ๎฾ืแࠡๅํๅࠥ฾็าฬࠣ์้๋วัษࠣ฼์ืส๊่ࠡฮ๎ุ่ࠦำอࠤ์ึ็ࠡษ็ู้้ไสࠢ࠱ࠤ์๊ࠠหำํำࠥษัิษ็ࠤฬ๊ำอๆࠣรࠬቹ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd: GkOVdCM4JeXvb3gPFj = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨቺ")
	else:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(A6Sg45ChDR3BJLYfFH(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ቻ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษࠧቼ")+AAByQSLgaZwCsKnvc5eWNmY+llkFwuCyhaP3sK76qO4T(u"ࠨ࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫች"))
		return
	hU30beEvi6onzCMPS7Q = HxUFDZnKWqvBpN30SJswYiyACM
	import tdeCZlJnBw
	n453i9Fwpc6bGMuUa2l = tdeCZlJnBw.UJgqTYtFZ5l1EvzsfRI(s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡈࡶࡷࡵࡲࡴࠩቾ"),hU30beEvi6onzCMPS7Q,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪቿ"),GkOVdCM4JeXvb3gPFj)
	if n453i9Fwpc6bGMuUa2l and GkOVdCM4JeXvb3gPFj:
		cLFtof1P9nlMm0.append(KBrYTHU89PStscE5Xl)
		SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,rDG9dZoXRhCJcieUSF0KB(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧኀ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧኁ"),cLFtof1P9nlMm0,pHC2Aj4kbc3KDN0aZWBey6QV)
	return
def UCXWsunP31fwB72Y6mMVOjbgJ4vy(ZtoUCFcjmabu,filename=b02zsRFX8MweUniGfyPHEZcv7p5WK3):
	L5jXH0fZ8TvsESR.sleep(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠮࠱࠴࠸ᜓ"))
	ZtoUCFcjmabu = ZtoUCFcjmabu.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq) if (wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(ZtoUCFcjmabu, str)) or (not wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(ZtoUCFcjmabu, unicode)) else str(ZtoUCFcjmabu)
	if not filename: rgNkiToc6MRPtULJ8BG = A6Sg45ChDR3BJLYfFH(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ኂ")+str(L5jXH0fZ8TvsESR.time())+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠯ࡦࡤࡸࠬኃ")
	else: rgNkiToc6MRPtULJ8BG = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨኄ")+filename+JHMxIE4fs1mvQtKW7R(u"ࠩ࠱ࡨࡦࡺࠧኅ")
	open(rgNkiToc6MRPtULJ8BG,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡻࡧ࠭ኆ")).write(ZtoUCFcjmabu)
	return
def TNuvf0sHO35JtqPga8x(RCBXDnhK3jHYUvJ):
	if RCBXDnhK3jHYUvJ:
		jpToYkrQKD2eMzWsRLJmXhl = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡱ࡯ࡳࡵࠩኇ"),kPCxIUZb1V(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪኈ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ኉"))
		if jpToYkrQKD2eMzWsRLJmXhl: return jpToYkrQKD2eMzWsRLJmXhl
	xLDEnp9WdA = TTuO14NzmB.SITESURLS[JHMxIE4fs1mvQtKW7R(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧኊ")][dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠵᜔")]
	c3tEmP52oQXkU0eIpAjwyrY6G = pnhyIzwgbCTmxs(Z19pUxa2gfGMNKoDsEuytn85SjFvA) if not RCBXDnhK3jHYUvJ else TTuO14NzmB.AV_CLIENT_IDS
	TbLGvkW8jF3sdlBaCP65SzmV4i = uj5sWQJSqg9XZYy4Nahz0d6erxl()
	XMiAvt4q9HhfwbPNsCnVk8o7RIW = TbLGvkW8jF3sdlBaCP65SzmV4i.split(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࠮࠯ࠫኋ"))[Tb7oymMnpflsSv3eu4Pz2]
	wNRBQXDAup9tKrxhbSiPTGe4 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,vWNRusF46D7Mi8GpZ(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨኌ"))
	DFtim4NvblY9er6ROysq5 = Un5o8hVIErRW7()
	xxwBIFtsuXOJ5ki1 = {JHMxIE4fs1mvQtKW7R(u"ࠪࡹࡸ࡫ࡲࠨኍ"):c3tEmP52oQXkU0eIpAjwyrY6G,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ኎"):D1DBSuO0lLGRbcfCyY,bQGafNLXyFgsZP6ut(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭኏"):XMiAvt4q9HhfwbPNsCnVk8o7RIW,s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡩࡥࡵࠪነ"):tTQjzDHVo9NBasmRb(DFtim4NvblY9er6ROysq5)}
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,lCT8hfYUBX4OQMmL(u"ࠧࡑࡑࡖࡘࠬኑ"),xLDEnp9WdA,xxwBIFtsuXOJ5ki1,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭ኒ"))
	jpToYkrQKD2eMzWsRLJmXhl = []
	if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
		jpToYkrQKD2eMzWsRLJmXhl = rTAHV8ktdmWCDfxP.replace(bQGafNLXyFgsZP6ut(u"ࠩ࡟ࡠࡷ࠭ና"),QWLr8ABjev).replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡠࡡࡴࠧኔ"),QWLr8ABjev).replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡡࡸ࡜࡯ࠩን"),QWLr8ABjev).replace(o46hdHaXLqyFwzD,QWLr8ABjev)
		jpToYkrQKD2eMzWsRLJmXhl = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨኖ"),jpToYkrQKD2eMzWsRLJmXhl,jj0dZrgiKb.DOTALL)
		if jpToYkrQKD2eMzWsRLJmXhl:
			jpToYkrQKD2eMzWsRLJmXhl = sorted(jpToYkrQKD2eMzWsRLJmXhl,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: int(key[wTLFCOcM26fmYlW7U]))
			MLfBSenJx7hP3mTsoQrb,c3tEmP52oQXkU0eIpAjwyrY6G,IC6XSwYirspRHmM,SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR,Kw19luY7W2jGgsBa5n4hctLfFS = jpToYkrQKD2eMzWsRLJmXhl[wTLFCOcM26fmYlW7U]
			OFskTbgB4wGiKSZYlMehUH9I = Kw19luY7W2jGgsBa5n4hctLfFS if TTuO14NzmB.avprivslongperiod else IC6XSwYirspRHmM
			OOnvcPQy85HYA.setSetting(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨኗ"),OFskTbgB4wGiKSZYlMehUH9I)
			SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬኘ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫኙ"),jpToYkrQKD2eMzWsRLJmXhl,d2priEnu57KztRsm8wCHZ)
			OOnvcPQy85HYA.setSetting(bQGafNLXyFgsZP6ut(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫኚ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
	return jpToYkrQKD2eMzWsRLJmXhl
def eE1KCWTrVxhd(clSTVMAyhPBOv,om9XBz5vwS6O4k=wTLFCOcM26fmYlW7U,gAqzW8MRHhpEeVo9K7Ntw=wTLFCOcM26fmYlW7U):
	if om9XBz5vwS6O4k and not gAqzW8MRHhpEeVo9K7Ntw: gAqzW8MRHhpEeVo9K7Ntw = len(clSTVMAyhPBOv)//om9XBz5vwS6O4k
	KK1SjbL9RPAW,qbRmVByrJv18,yylJTxXLjV5zgwRYNEs2qmHdPh = [],-UD4N8MjVTd,wTLFCOcM26fmYlW7U
	for Og15JMhL8ArokEY2G in clSTVMAyhPBOv:
		if yylJTxXLjV5zgwRYNEs2qmHdPh%gAqzW8MRHhpEeVo9K7Ntw==wTLFCOcM26fmYlW7U:
			qbRmVByrJv18 += UD4N8MjVTd
			KK1SjbL9RPAW.append([])
		KK1SjbL9RPAW[qbRmVByrJv18].append(Og15JMhL8ArokEY2G)
		yylJTxXLjV5zgwRYNEs2qmHdPh += UD4N8MjVTd
	return KK1SjbL9RPAW
def apq1OI4wWHyc0F3KCodGi(rgNkiToc6MRPtULJ8BG,ZtoUCFcjmabu):
	akhbe8SYLMdfHmg3Dsl5A2KjEp = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,rgNkiToc6MRPtULJ8BG)
	if UD4N8MjVTd or fmkZtbRj3ux(u"ࠪࡍࡕ࡚ࡖࡠࠩኛ") not in rgNkiToc6MRPtULJ8BG or vWNRusF46D7Mi8GpZ(u"ࠫࡒ࠹ࡕࡠࠩኜ") not in rgNkiToc6MRPtULJ8BG: UWErGF2TqoQ = str(ZtoUCFcjmabu)
	else:
		KK1SjbL9RPAW = eE1KCWTrVxhd(ZtoUCFcjmabu,llkFwuCyhaP3sK76qO4T(u"࠹᜕"))
		UWErGF2TqoQ = wUvcPrYDfISbZolAm83GKEqMyXkn5
		for buR2Svx0MyZGtUf578jFd1ITp3 in KK1SjbL9RPAW:
			UWErGF2TqoQ += str(buR2Svx0MyZGtUf578jFd1ITp3)+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫኝ")
		UWErGF2TqoQ = UWErGF2TqoQ.strip(bQGafNLXyFgsZP6ut(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬኞ"))
	iwRF1dM8XTKpnY7OhBuvVE = FSaPuXqyvI24in8rhtEzOoe3.compress(UWErGF2TqoQ)
	open(akhbe8SYLMdfHmg3Dsl5A2KjEp,kPCxIUZb1V(u"ࠧࡸࡤࠪኟ")).write(iwRF1dM8XTKpnY7OhBuvVE)
	return
def mFgND0pv4WryfKJiMIuV(ZZDoCUyJ5B,rgNkiToc6MRPtULJ8BG):
	if ZZDoCUyJ5B==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡦ࡬ࡧࡹ࠭አ"): ZtoUCFcjmabu = {}
	elif ZZDoCUyJ5B==llkFwuCyhaP3sK76qO4T(u"ࠩ࡯࡭ࡸࡺࠧኡ"): ZtoUCFcjmabu = []
	elif ZZDoCUyJ5B==JHMxIE4fs1mvQtKW7R(u"ࠪࡷࡹࡸࠧኢ"): ZtoUCFcjmabu = wUvcPrYDfISbZolAm83GKEqMyXkn5
	elif ZZDoCUyJ5B==w8JC1y7Lp3(u"ࠫ࡮ࡴࡴࠨኣ"): ZtoUCFcjmabu = wTLFCOcM26fmYlW7U
	else: ZtoUCFcjmabu = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	akhbe8SYLMdfHmg3Dsl5A2KjEp = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,rgNkiToc6MRPtULJ8BG)
	iwRF1dM8XTKpnY7OhBuvVE = open(akhbe8SYLMdfHmg3Dsl5A2KjEp,vWNRusF46D7Mi8GpZ(u"ࠬࡸࡢࠨኤ")).read()
	UWErGF2TqoQ = FSaPuXqyvI24in8rhtEzOoe3.decompress(iwRF1dM8XTKpnY7OhBuvVE)
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬእ") not in UWErGF2TqoQ: ZtoUCFcjmabu = eval(UWErGF2TqoQ)
	else:
		KK1SjbL9RPAW = UWErGF2TqoQ.split(s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ኦ"))
		del UWErGF2TqoQ
		ZtoUCFcjmabu = []
		ClzFLuT3G2JoyHVbK7src = ccihgnIMFa()
		MLfBSenJx7hP3mTsoQrb = wTLFCOcM26fmYlW7U
		for buR2Svx0MyZGtUf578jFd1ITp3 in KK1SjbL9RPAW:
			ClzFLuT3G2JoyHVbK7src.PPGgu8rsmyUDJkKdl6(str(MLfBSenJx7hP3mTsoQrb),eval,buR2Svx0MyZGtUf578jFd1ITp3)
			MLfBSenJx7hP3mTsoQrb += UD4N8MjVTd
		del KK1SjbL9RPAW
		ClzFLuT3G2JoyHVbK7src.v48KLQF9NRdsjbBOzYna03c6Sx()
		ClzFLuT3G2JoyHVbK7src.qqNUrOjixgzYPKopnbZDlafCt()
		WnkqR5M4Ndlhste3uPAOI = list(ClzFLuT3G2JoyHVbK7src.resultsDICT.keys())
		QFEpT9qvhwPR1g4 = sorted(WnkqR5M4Ndlhste3uPAOI,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: int(key))
		for MLfBSenJx7hP3mTsoQrb in QFEpT9qvhwPR1g4:
			ZtoUCFcjmabu += ClzFLuT3G2JoyHVbK7src.resultsDICT[MLfBSenJx7hP3mTsoQrb]
	return ZtoUCFcjmabu
def KYP9NdUrxjiZ(ggvQikMrmRXYdezZuUwj30WOc):
	glrF8d5YkEQyp6NC12aDuhMiwWGsSb = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡣࡧࡨࡴࡴࡳࠨኧ"),ggvQikMrmRXYdezZuUwj30WOc,VhqD3zp7mUieI8sMQlETH(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬከ"))
	try: kkeP5CUyfK7j4ig2w1GAqWbh9oXcFZ = open(glrF8d5YkEQyp6NC12aDuhMiwWGsSb,yRWQMHxZEz0(u"ࠪࡶࡧ࠭ኩ")).read()
	except:
		dI0qaKWczB = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(QrW3v0cdJogNLkp8ub9VmYB5iDRa7E,Gj3rMP1Cb8wHdp49la0(u"ࠫࡦࡪࡤࡰࡰࡶࠫኪ"),ggvQikMrmRXYdezZuUwj30WOc,llkFwuCyhaP3sK76qO4T(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨካ"))
		try: kkeP5CUyfK7j4ig2w1GAqWbh9oXcFZ = open(dI0qaKWczB,VhqD3zp7mUieI8sMQlETH(u"࠭ࡲࡣࠩኬ")).read()
		except: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: kkeP5CUyfK7j4ig2w1GAqWbh9oXcFZ = kkeP5CUyfK7j4ig2w1GAqWbh9oXcFZ.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	F6nIEZwLdBqySf4gjQCUbJl = jj0dZrgiKb.findall(rDG9dZoXRhCJcieUSF0KB(u"ࠧࡪࡦࡀ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽࡜࡞ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠢ࡝ࠩࡠࠫክ"),kkeP5CUyfK7j4ig2w1GAqWbh9oXcFZ,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	if not F6nIEZwLdBqySf4gjQCUbJl: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	g1hHMK4UcQqTC3ONBPsE,vlDe1I6hsKVknimdr47tCwL9 = F6nIEZwLdBqySf4gjQCUbJl[wTLFCOcM26fmYlW7U],UmOxLC9ayZ2fgM(F6nIEZwLdBqySf4gjQCUbJl[wTLFCOcM26fmYlW7U])
	return g1hHMK4UcQqTC3ONBPsE,vlDe1I6hsKVknimdr47tCwL9
def aai3r0JO5dupQUygfq1P7A():
	mYkIXAsdT1564EWjD = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡦ࡬ࡧࡹ࠭ኮ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧኯ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫኰ"))
	if mYkIXAsdT1564EWjD: return mYkIXAsdT1564EWjD
	JJfb1TQjNWSdBGAM3YmFCr0zOnv,mYkIXAsdT1564EWjD = {},{}
	tyo2D40bfYhqZ1Cvr9 = [TTuO14NzmB.SITESURLS[fmkZtbRj3ux(u"ࠫࡗࡋࡐࡐࡕࠪ኱")][wTLFCOcM26fmYlW7U]]
	if Uy6GWujQiBLhodP>kPCxIUZb1V(u"࠳࠺࠲࠾࠿᜖"): tyo2D40bfYhqZ1Cvr9.append(TTuO14NzmB.SITESURLS[xm6jK1ZMuWq5(u"ࠬࡘࡅࡑࡑࡖࠫኲ")][UD4N8MjVTd])
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: tyo2D40bfYhqZ1Cvr9.append(TTuO14NzmB.SITESURLS[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡒࡆࡒࡒࡗࠬኳ")][Tb7oymMnpflsSv3eu4Pz2])
	for YYw8AuJWtyDnpoKC92MIkcmFl in tyo2D40bfYhqZ1Cvr9:
		lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,xm6jK1ZMuWq5(u"ࠧࡈࡇࡗࠫኴ"),YYw8AuJWtyDnpoKC92MIkcmFl,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬኵ"))
		if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
			rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
			RWAeygicdBtfkv3GFKj = YYw8AuJWtyDnpoKC92MIkcmFl.rsplit(yRWQMHxZEz0(u"ࠩ࠲ࠫ኶"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠴᜗"))[wTLFCOcM26fmYlW7U]
			fln4KvmyHq6iB1 = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ኷"),rTAHV8ktdmWCDfxP,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
			for ggvQikMrmRXYdezZuUwj30WOc,c7ZxbGeRYhfunmH8VUBMQX0aOip in fln4KvmyHq6iB1:
				ffgzKOhwZMFaXdrC06pBPA371JR = RWAeygicdBtfkv3GFKj+w8JC1y7Lp3(u"ࠫ࠴࠭ኸ")+ggvQikMrmRXYdezZuUwj30WOc+TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࠵ࠧኹ")+ggvQikMrmRXYdezZuUwj30WOc+jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭࠭ࠨኺ")+c7ZxbGeRYhfunmH8VUBMQX0aOip+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠯ࡼ࡬ࡴࠬኻ")
				if ggvQikMrmRXYdezZuUwj30WOc not in list(JJfb1TQjNWSdBGAM3YmFCr0zOnv.keys()):
					JJfb1TQjNWSdBGAM3YmFCr0zOnv[ggvQikMrmRXYdezZuUwj30WOc] = []
					mYkIXAsdT1564EWjD[ggvQikMrmRXYdezZuUwj30WOc] = []
				nevjUCmMAc5p9hWlrRNHVIxX7FqPa2 = UmOxLC9ayZ2fgM(c7ZxbGeRYhfunmH8VUBMQX0aOip)
				JJfb1TQjNWSdBGAM3YmFCr0zOnv[ggvQikMrmRXYdezZuUwj30WOc].append((c7ZxbGeRYhfunmH8VUBMQX0aOip,nevjUCmMAc5p9hWlrRNHVIxX7FqPa2,ffgzKOhwZMFaXdrC06pBPA371JR))
	for ggvQikMrmRXYdezZuUwj30WOc in list(JJfb1TQjNWSdBGAM3YmFCr0zOnv.keys()):
		mYkIXAsdT1564EWjD[ggvQikMrmRXYdezZuUwj30WOc] = sorted(JJfb1TQjNWSdBGAM3YmFCr0zOnv[ggvQikMrmRXYdezZuUwj30WOc],reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: key[UD4N8MjVTd])
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,it4DKnryZlx(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭ኼ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪኽ"),mYkIXAsdT1564EWjD,d2priEnu57KztRsm8wCHZ)
	return mYkIXAsdT1564EWjD
def UmOxLC9ayZ2fgM(c7ZxbGeRYhfunmH8VUBMQX0aOip):
	nevjUCmMAc5p9hWlrRNHVIxX7FqPa2 = []
	dvENZxS4K9LPoQytk0XsHMcrY6pnbO = c7ZxbGeRYhfunmH8VUBMQX0aOip.split(weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࠲ࠬኾ"))
	for mmMncF7sdDXBk3 in dvENZxS4K9LPoQytk0XsHMcrY6pnbO:
		Y2wFk0J6aZjiU3Xqn458K = jj0dZrgiKb.findall(it4DKnryZlx(u"ࠫࡡࡪࠫࡽ࡝࡟࠯ࡡ࠳ࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠨ኿"),mmMncF7sdDXBk3,jj0dZrgiKb.DOTALL)
		Tq1Op48kwS3 = []
		for p02p7SoZdwabDH1f6jFWYGLP in Y2wFk0J6aZjiU3Xqn458K:
			if p02p7SoZdwabDH1f6jFWYGLP.isdigit(): p02p7SoZdwabDH1f6jFWYGLP = int(p02p7SoZdwabDH1f6jFWYGLP)
			Tq1Op48kwS3.append(p02p7SoZdwabDH1f6jFWYGLP)
		nevjUCmMAc5p9hWlrRNHVIxX7FqPa2.append(Tq1Op48kwS3)
	return nevjUCmMAc5p9hWlrRNHVIxX7FqPa2
def efgL41RcYIBxhHPUSVi(nevjUCmMAc5p9hWlrRNHVIxX7FqPa2):
	c7ZxbGeRYhfunmH8VUBMQX0aOip = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for mmMncF7sdDXBk3 in nevjUCmMAc5p9hWlrRNHVIxX7FqPa2:
		for p02p7SoZdwabDH1f6jFWYGLP in mmMncF7sdDXBk3: c7ZxbGeRYhfunmH8VUBMQX0aOip += str(p02p7SoZdwabDH1f6jFWYGLP)
		c7ZxbGeRYhfunmH8VUBMQX0aOip += w8JC1y7Lp3(u"ࠬ࠴ࠧዀ")
	c7ZxbGeRYhfunmH8VUBMQX0aOip = c7ZxbGeRYhfunmH8VUBMQX0aOip.strip(bQGafNLXyFgsZP6ut(u"࠭࠮ࠨ዁"))
	return c7ZxbGeRYhfunmH8VUBMQX0aOip
def XFMSnPvjbgcRE9tf6z(FloXKDNzIGOJQHct):
	WzcgrtpJ9X6lYCD = {}
	JJfb1TQjNWSdBGAM3YmFCr0zOnv = aai3r0JO5dupQUygfq1P7A()
	JI5qAofxnt = Aq5Wm0ri2dNOQ3Bfs6ogCpyD(FloXKDNzIGOJQHct)
	for ggvQikMrmRXYdezZuUwj30WOc in FloXKDNzIGOJQHct:
		if ggvQikMrmRXYdezZuUwj30WOc not in list(JJfb1TQjNWSdBGAM3YmFCr0zOnv.keys()): continue
		mYkIXAsdT1564EWjD = JJfb1TQjNWSdBGAM3YmFCr0zOnv[ggvQikMrmRXYdezZuUwj30WOc]
		MIyxS2g7BDQrKu0,TDl7WLZnbvVkaCFhYX,OOAHkWVQpyiUD = mYkIXAsdT1564EWjD[wTLFCOcM26fmYlW7U]
		ipCGBvu1TIN4nVef20qPQOUWJ3,RmLdrUwX2lzSgDxTGnZ0qQ197Yit = KYP9NdUrxjiZ(ggvQikMrmRXYdezZuUwj30WOc)
		Bn71KM9Jdk,v9jWxUM5SQosbcJa43t7d = JI5qAofxnt[ggvQikMrmRXYdezZuUwj30WOc]
		w42w8RxnZWJMdfuFL = TDl7WLZnbvVkaCFhYX>RmLdrUwX2lzSgDxTGnZ0qQ197Yit and Bn71KM9Jdk
		wpkjW8nG0NXofze1daLyqIB5H = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if not Bn71KM9Jdk: HGeNjmUqstLzZ34 = it4DKnryZlx(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨዂ")
		elif not v9jWxUM5SQosbcJa43t7d: HGeNjmUqstLzZ34 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪዃ")
		elif w42w8RxnZWJMdfuFL: HGeNjmUqstLzZ34 = TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡲࡰࡩ࠭ዄ")
		else:
			HGeNjmUqstLzZ34 = A6Sg45ChDR3BJLYfFH(u"ࠪ࡫ࡴࡵࡤࠨዅ")
			wpkjW8nG0NXofze1daLyqIB5H = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		WzcgrtpJ9X6lYCD[ggvQikMrmRXYdezZuUwj30WOc] = wpkjW8nG0NXofze1daLyqIB5H,ipCGBvu1TIN4nVef20qPQOUWJ3,RmLdrUwX2lzSgDxTGnZ0qQ197Yit,MIyxS2g7BDQrKu0,TDl7WLZnbvVkaCFhYX,HGeNjmUqstLzZ34,OOAHkWVQpyiUD
	return WzcgrtpJ9X6lYCD
def snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,ke4mv32SUTYp5ynVQEu9PDqNFBg,uGCmFW9wzhMR6Vy1sf58qI=wUvcPrYDfISbZolAm83GKEqMyXkn5,hhwpFVz8l94muXJk=wUvcPrYDfISbZolAm83GKEqMyXkn5,xpaZLVbmjdcHNFw61U4JWrYT90ehK=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if ndib93Ol6UojCrEV: OO9xQWZnuTNMf1SDFE43JPeV.update(ke4mv32SUTYp5ynVQEu9PDqNFBg,uGCmFW9wzhMR6Vy1sf58qI,hhwpFVz8l94muXJk,xpaZLVbmjdcHNFw61U4JWrYT90ehK)
	else: OO9xQWZnuTNMf1SDFE43JPeV.update(ke4mv32SUTYp5ynVQEu9PDqNFBg,uGCmFW9wzhMR6Vy1sf58qI+QWLr8ABjev+hhwpFVz8l94muXJk+QWLr8ABjev+xpaZLVbmjdcHNFw61U4JWrYT90ehK)
	return
def z69zaGtMRNJrmihgjv25O1dUpYlVf(aa3thUFYxDiPv):
	def hORklFMDP37EjZYU462v0qI5KpgrSo(J4NG8dVXanIYL,zEx7ignuNDr0M6a5lBjAqZF1p34ot,uO8SR5HT4U6ksrCjKpIywZ=w8JC1y7Lp3(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦ዆")):
		return ((J4NG8dVXanIYL == wTLFCOcM26fmYlW7U) and uO8SR5HT4U6ksrCjKpIywZ[wTLFCOcM26fmYlW7U]) or (hORklFMDP37EjZYU462v0qI5KpgrSo(J4NG8dVXanIYL // zEx7ignuNDr0M6a5lBjAqZF1p34ot, zEx7ignuNDr0M6a5lBjAqZF1p34ot, uO8SR5HT4U6ksrCjKpIywZ).lstrip(uO8SR5HT4U6ksrCjKpIywZ[wTLFCOcM26fmYlW7U]) + uO8SR5HT4U6ksrCjKpIywZ[J4NG8dVXanIYL % zEx7ignuNDr0M6a5lBjAqZF1p34ot])
	def lrw1kTGEAhu06MasYNZdtIizgF8p4X(J7J81OkWpHnbiYBCXKx, XpKaY2xo6QmFcV3iN9kEqduhMR, frEPWnbh7SMacU4z5Y, YYaiweEBOS4tVKfQz7mT, llivhTM8qgc1pdOGnNLzYZPfECSFH=b02zsRFX8MweUniGfyPHEZcv7p5WK3, aKY2A9PnoFg4usizU5QhCD=b02zsRFX8MweUniGfyPHEZcv7p5WK3, vk5s1GO0gUW=b02zsRFX8MweUniGfyPHEZcv7p5WK3):
		while (frEPWnbh7SMacU4z5Y):
			frEPWnbh7SMacU4z5Y-=it4DKnryZlx(u"࠵᜘")
			if (YYaiweEBOS4tVKfQz7mT[frEPWnbh7SMacU4z5Y]): J7J81OkWpHnbiYBCXKx = jj0dZrgiKb.sub(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡢ࡜ࡣࠤ዇") + hORklFMDP37EjZYU462v0qI5KpgrSo(frEPWnbh7SMacU4z5Y, XpKaY2xo6QmFcV3iN9kEqduhMR) + rDG9dZoXRhCJcieUSF0KB(u"ࠨ࡜࡝ࡤࠥወ"),  YYaiweEBOS4tVKfQz7mT[frEPWnbh7SMacU4z5Y], J7J81OkWpHnbiYBCXKx)
		return J7J81OkWpHnbiYBCXKx
	aa3thUFYxDiPv = aa3thUFYxDiPv.split(it4DKnryZlx(u"ࠧࡾࠪࠪዉ"))[UD4N8MjVTd]
	aa3thUFYxDiPv = aa3thUFYxDiPv.rsplit(w8JC1y7Lp3(u"ࠨࡵࡳࡰ࡮ࡺࠧዊ"))[wTLFCOcM26fmYlW7U]+weh7SGmuTgXOVRcMo1rlLq(u"ࠤࡶࡴࡱ࡯ࡴࠩࠩࡿࠫ࠮࠯ࠢዋ")
	Qid14qxXSvtI0ayfKuboj = eval(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫዌ")+aa3thUFYxDiPv,{weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡧࡧࡳࡦࡐࠪው"):hORklFMDP37EjZYU462v0qI5KpgrSo,D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬዎ"):lrw1kTGEAhu06MasYNZdtIizgF8p4X})
	return Qid14qxXSvtI0ayfKuboj
def CCFGtogTOQY(code):
	_c4vdMs3YSXBZjyKHlmFWugDprAN=it4DKnryZlx(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟࠱࠯ࠣዏ")
	def fhjgo7M8zqDbYB6(aKY2A9PnoFg4usizU5QhCD,llivhTM8qgc1pdOGnNLzYZPfECSFH,FFMm9WorSJV8lOAPKBZns0EDL):
		hhyEaKeQg8Ymv = list(_c4vdMs3YSXBZjyKHlmFWugDprAN)
		Hicw3BaGtFUPMxLrsZf8D5Cz = hhyEaKeQg8Ymv[w8JC1y7Lp3(u"࠵᜙"):llivhTM8qgc1pdOGnNLzYZPfECSFH]
		kkLhJCU4MQSx7s6gyeOHrRYKtnP3 = hhyEaKeQg8Ymv[kPCxIUZb1V(u"࠶᜚"):FFMm9WorSJV8lOAPKBZns0EDL]
		aKY2A9PnoFg4usizU5QhCD = list(aKY2A9PnoFg4usizU5QhCD)[::-pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠱᜛")]
		baRB6e0DNoXZswMqYVfzL857W = weh7SGmuTgXOVRcMo1rlLq(u"࠱᜜")
		for frEPWnbh7SMacU4z5Y,zEx7ignuNDr0M6a5lBjAqZF1p34ot in enumerate(aKY2A9PnoFg4usizU5QhCD):
			if zEx7ignuNDr0M6a5lBjAqZF1p34ot in Hicw3BaGtFUPMxLrsZf8D5Cz: baRB6e0DNoXZswMqYVfzL857W = baRB6e0DNoXZswMqYVfzL857W + Hicw3BaGtFUPMxLrsZf8D5Cz.index(zEx7ignuNDr0M6a5lBjAqZF1p34ot)*llivhTM8qgc1pdOGnNLzYZPfECSFH**frEPWnbh7SMacU4z5Y
		YYaiweEBOS4tVKfQz7mT = lCT8hfYUBX4OQMmL(u"ࠢࠣዐ")
		while baRB6e0DNoXZswMqYVfzL857W > w8JC1y7Lp3(u"࠲᜝"):
			YYaiweEBOS4tVKfQz7mT = kkLhJCU4MQSx7s6gyeOHrRYKtnP3[baRB6e0DNoXZswMqYVfzL857W%FFMm9WorSJV8lOAPKBZns0EDL] + YYaiweEBOS4tVKfQz7mT
			baRB6e0DNoXZswMqYVfzL857W = (baRB6e0DNoXZswMqYVfzL857W - (baRB6e0DNoXZswMqYVfzL857W%FFMm9WorSJV8lOAPKBZns0EDL))//FFMm9WorSJV8lOAPKBZns0EDL
		return int(YYaiweEBOS4tVKfQz7mT) or TNw1pBHb8CtSZe0EFxuJqI(u"࠳᜞")
	def Ie8sO7NVJcBZSQ9T(Hicw3BaGtFUPMxLrsZf8D5Cz,u,NNSq6gCGnKv,MSvBphPCT8qnuzY9afRHsO1Ztg,llivhTM8qgc1pdOGnNLzYZPfECSFH,vk5s1GO0gUW):
		vk5s1GO0gUW = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠣࠤዑ");
		kkLhJCU4MQSx7s6gyeOHrRYKtnP3 = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠴ᜟ")
		while kkLhJCU4MQSx7s6gyeOHrRYKtnP3 < len(Hicw3BaGtFUPMxLrsZf8D5Cz):
			baRB6e0DNoXZswMqYVfzL857W = xm6jK1ZMuWq5(u"࠵ᜠ")
			ydHSGDhXMWYr83BRF5ZsV = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠤࠥዒ")
			while Hicw3BaGtFUPMxLrsZf8D5Cz[kkLhJCU4MQSx7s6gyeOHrRYKtnP3] is not NNSq6gCGnKv[llivhTM8qgc1pdOGnNLzYZPfECSFH]:
				ydHSGDhXMWYr83BRF5ZsV = wUvcPrYDfISbZolAm83GKEqMyXkn5.join([ydHSGDhXMWYr83BRF5ZsV,Hicw3BaGtFUPMxLrsZf8D5Cz[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]])
				kkLhJCU4MQSx7s6gyeOHrRYKtnP3 = kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + JHMxIE4fs1mvQtKW7R(u"࠷ᜡ")
			while baRB6e0DNoXZswMqYVfzL857W < len(NNSq6gCGnKv):
				ydHSGDhXMWYr83BRF5ZsV = ydHSGDhXMWYr83BRF5ZsV.replace(NNSq6gCGnKv[baRB6e0DNoXZswMqYVfzL857W],str(baRB6e0DNoXZswMqYVfzL857W))
				baRB6e0DNoXZswMqYVfzL857W = baRB6e0DNoXZswMqYVfzL857W + llkFwuCyhaP3sK76qO4T(u"࠱ᜢ")
			vk5s1GO0gUW = wUvcPrYDfISbZolAm83GKEqMyXkn5.join([vk5s1GO0gUW,wUvcPrYDfISbZolAm83GKEqMyXkn5.join(map(chr, [fhjgo7M8zqDbYB6(ydHSGDhXMWYr83BRF5ZsV,llivhTM8qgc1pdOGnNLzYZPfECSFH,xm6jK1ZMuWq5(u"࠲࠲ᜣ")) - MSvBphPCT8qnuzY9afRHsO1Ztg]))])
			kkLhJCU4MQSx7s6gyeOHrRYKtnP3 = kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + w8JC1y7Lp3(u"࠳ᜤ")
		return vk5s1GO0gUW
	code = code.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡠࡳ࠭ዓ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(fmkZtbRj3ux(u"ࠫࡡࡸࠧዔ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	GRMd504NgUVFaWATI7o = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠬࡢࡽ࡝ࠪࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯࡜ࠪ࡞ࠬࠫዕ"),code,jj0dZrgiKb.DOTALL)
	if GRMd504NgUVFaWATI7o:
		GRMd504NgUVFaWATI7o = list(GRMd504NgUVFaWATI7o[vvhR5ozeiJpANyl8fFO3GBw(u"࠳ᜥ")])
		for kYTfz6B4cXZt,code in enumerate(GRMd504NgUVFaWATI7o):
			if code.isdigit(): GRMd504NgUVFaWATI7o[kYTfz6B4cXZt] = int(code)
			else: GRMd504NgUVFaWATI7o[kYTfz6B4cXZt] = code.replace(vvhR5ozeiJpANyl8fFO3GBw(u"࠭࡜ࠣࠩዖ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		JxacqfhWjes1u8kPgHNYb5OUiT = Ie8sO7NVJcBZSQ9T(*GRMd504NgUVFaWATI7o)
		return JxacqfhWjes1u8kPgHNYb5OUiT
	return wUvcPrYDfISbZolAm83GKEqMyXkn5
def G6A9bnCLq8Z1z(xLDEnp9WdA,zeAuMJFY0KDUX3W=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if zeAuMJFY0KDUX3W==JHMxIE4fs1mvQtKW7R(u"ࠧ࡭ࡱࡺࡩࡷ࠭዗"): xLDEnp9WdA = jj0dZrgiKb.sub(xm6jK1ZMuWq5(u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨዘ"),lambda IWKTLfZSwpv2Argc: IWKTLfZSwpv2Argc.group(wTLFCOcM26fmYlW7U).lower(),xLDEnp9WdA)
	elif zeAuMJFY0KDUX3W==MFhbWia58mP3su0fk2d(u"ࠩࡸࡴࡵ࡫ࡲࠨዙ"): xLDEnp9WdA = jj0dZrgiKb.sub(jQv0du1iVxTgAXCM(u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪዚ"),lambda IWKTLfZSwpv2Argc: IWKTLfZSwpv2Argc.group(wTLFCOcM26fmYlW7U).upper(),xLDEnp9WdA)
	return xLDEnp9WdA
def Aq5Wm0ri2dNOQ3Bfs6ogCpyD(FloXKDNzIGOJQHct):
	ZbGBsvKfWOH9QxMeFidnTEk3,z21ptngLbm8wjPrFe3J0NvCAYVIy = Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	rC0YJ4awbU2H3LOGt5DIF = plTxfrOsuV4McaF2HPg1BiZ396GXI5.connect(cT4oLk7l9uSIbE35NjBV)
	rC0YJ4awbU2H3LOGt5DIF.text_factory = str
	sXeobuj186Q = rC0YJ4awbU2H3LOGt5DIF.cursor()
	if len(FloXKDNzIGOJQHct)==UD4N8MjVTd: zzucJWiVovtShYDHGlU = Gj3rMP1Cb8wHdp49la0(u"ࠫ࠭ࠨࠧዛ")+FloXKDNzIGOJQHct[wTLFCOcM26fmYlW7U]+JHMxIE4fs1mvQtKW7R(u"ࠬࠨࠩࠨዜ")
	else: zzucJWiVovtShYDHGlU = str(tuple(FloXKDNzIGOJQHct))
	sXeobuj186Q.execute(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭ዝ")+zzucJWiVovtShYDHGlU+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࠡ࠽ࠪዞ"))
	y7ZhGxrtSX2A4DPEWRj0 = sXeobuj186Q.fetchall()
	rC0YJ4awbU2H3LOGt5DIF.close()
	JI5qAofxnt = {}
	for ggvQikMrmRXYdezZuUwj30WOc in FloXKDNzIGOJQHct: JI5qAofxnt[ggvQikMrmRXYdezZuUwj30WOc] = (Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	for ggvQikMrmRXYdezZuUwj30WOc,z21ptngLbm8wjPrFe3J0NvCAYVIy in y7ZhGxrtSX2A4DPEWRj0:
		ZbGBsvKfWOH9QxMeFidnTEk3 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		z21ptngLbm8wjPrFe3J0NvCAYVIy = z21ptngLbm8wjPrFe3J0NvCAYVIy==UD4N8MjVTd
		JI5qAofxnt[ggvQikMrmRXYdezZuUwj30WOc] = (ZbGBsvKfWOH9QxMeFidnTEk3,z21ptngLbm8wjPrFe3J0NvCAYVIy)
	return JI5qAofxnt
def akK8V9HQng4mqSlvO01swx6RorY(IIDzU1rRTl8s):
	RCmHBOKtejQ8lu4L = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(IIDzU1rRTl8s):
		Ye2FIg9kj3d0QvM6y58KtERxuNV = open(IIDzU1rRTl8s,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡴࡥࠫዟ")).read()
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: Ye2FIg9kj3d0QvM6y58KtERxuNV = Ye2FIg9kj3d0QvM6y58KtERxuNV.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		qq7GnlEkOv = dm7KA8MukvxF3iH9CW2ZNc(jQv0du1iVxTgAXCM(u"ࠩࡧ࡭ࡨࡺࠧዠ"),Ye2FIg9kj3d0QvM6y58KtERxuNV)
		if qq7GnlEkOv:
			RCmHBOKtejQ8lu4L = {}
			for NH79yB8ocSkVP2IRdOeE6UrXuh in qq7GnlEkOv.keys():
				RCmHBOKtejQ8lu4L[NH79yB8ocSkVP2IRdOeE6UrXuh] = []
				for J6JklKduzFEBQyLDvS5 in qq7GnlEkOv[NH79yB8ocSkVP2IRdOeE6UrXuh]:
					KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
					KUOoYcT20iCLVgsw1ejzdkHp7XW = J6JklKduzFEBQyLDvS5[wTLFCOcM26fmYlW7U]
					PPV92olpby3x06D = J6JklKduzFEBQyLDvS5[UD4N8MjVTd]
					PPV92olpby3x06D = LPtVaw9ZF8ureCo(PPV92olpby3x06D)
					xLDEnp9WdA = J6JklKduzFEBQyLDvS5[Tb7oymMnpflsSv3eu4Pz2]
					XmaCeTontNPjwDBzyJIkKA9rRSHfb = J6JklKduzFEBQyLDvS5[MMRBkhnWVJCQwU]
					mnWZN7g50M = J6JklKduzFEBQyLDvS5[R9RNUT6WAPEYjHqtIokxuXs]
					sbNukjOf4chz = J6JklKduzFEBQyLDvS5[jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠹ᜦ")]
					if len(J6JklKduzFEBQyLDvS5)>dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠻ᜧ"): UWErGF2TqoQ = J6JklKduzFEBQyLDvS5[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠻ᜧ")]
					if len(J6JklKduzFEBQyLDvS5)>gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠽ᜨ"): QFOD4Gei1zaImpk02q6vBNL3jwctbr = J6JklKduzFEBQyLDvS5[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠽ᜨ")]
					if len(J6JklKduzFEBQyLDvS5)>TNw1pBHb8CtSZe0EFxuJqI(u"࠸ᜩ"): V9NmnGv2o0ZU5P8F4iqgX7CQJ = J6JklKduzFEBQyLDvS5[TNw1pBHb8CtSZe0EFxuJqI(u"࠸ᜩ")]
					if IIDzU1rRTl8s==eCcr5AqkmHOSU: j4EvHLSzl3RbI7w = KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,wUvcPrYDfISbZolAm83GKEqMyXkn5,V9NmnGv2o0ZU5P8F4iqgX7CQJ
					else: j4EvHLSzl3RbI7w = KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ
					RCmHBOKtejQ8lu4L[NH79yB8ocSkVP2IRdOeE6UrXuh].append(j4EvHLSzl3RbI7w)
		B24cf0uV1SMLNI6TwziZ = str(RCmHBOKtejQ8lu4L)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: B24cf0uV1SMLNI6TwziZ = B24cf0uV1SMLNI6TwziZ.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(IIDzU1rRTl8s,xdSThjYnuHXAU6M(u"ࠪࡻࡧ࠭ዡ")).write(B24cf0uV1SMLNI6TwziZ)
	return RCmHBOKtejQ8lu4L
def Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt):
	nL3SyhovzIm0URBZJ = g40I3ZXaeJ8qVywt.split(xm6jK1ZMuWq5(u"ࠫ࠲࠭ዢ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
	iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if   nL3SyhovzIm0URBZJ==fmkZtbRj3ux(u"ࠬࡇࡈࡘࡃࡎࠫዣ")		:	from xonDKgEG3c			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==lCT8hfYUBX4OQMmL(u"࠭ࡁࡌࡑࡄࡑࠬዤ")		:	from V78QvGpgDT			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xdSThjYnuHXAU6M(u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩዥ")	:	from Y0ZSpnAUJc		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==yRWQMHxZEz0(u"ࠨࡃࡎ࡛ࡆࡓࠧዦ")		:	from myIlApe52K			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==bQGafNLXyFgsZP6ut(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬዧ")	:	from TjJIaQfHZw		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡅࡑࡇࡒࡂࡄࠪየ")	:	from u6bhHT1c34			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭ዩ")	:	from UuhvNorxYA		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==A6Sg45ChDR3BJLYfFH(u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨዪ")	: 	from SSUqnesmk3		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨያ")	:	from SSXJ5pVHg0		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨዬ")	:	from eeOBvHCkgD		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==JHMxIE4fs1mvQtKW7R(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪይ")	:	from tLk2JihmK9		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==JHMxIE4fs1mvQtKW7R(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧዮ"):	from jjVqkSwmls	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==it4DKnryZlx(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬዯ")	:	from BZErkcCYxU		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xm6jK1ZMuWq5(u"ࠫࡆ࡟ࡌࡐࡎࠪደ")		:	from mmUHrvpo9g			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==fmkZtbRj3ux(u"ࠬࡈࡏࡌࡔࡄࠫዱ")		:	from J4AVWmyI0c			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ዲ")	:	from LoyA35BfYZ			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨዳ")	:	from BHy2SW5xYh		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==lCT8hfYUBX4OQMmL(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨዴ")	:	from Stn2cgKWRF			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==lCT8hfYUBX4OQMmL(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩድ")	:	from Kxr124C0uz			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬዶ")	:	from cMxuYB5kpT		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xm6jK1ZMuWq5(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ዷ")	:	from KavYIOMF5p		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==vWNRusF46D7Mi8GpZ(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫዸ"):	from zkKSIaPueL	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xm6jK1ZMuWq5(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨዹ")	:	from GeVUAOD0WX		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==bQGafNLXyFgsZP6ut(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩዺ")	:	from bXjsaGwUd8		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==bQGafNLXyFgsZP6ut(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪዻ")	:	from g0J37nTGQl		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬዼ")	:	from LUOwxAiIV7		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==MFhbWia58mP3su0fk2d(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫዽ")	:	from nHbYcuLB7N		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==vWNRusF46D7Mi8GpZ(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ዾ")	:	from ttJgk4Uw9n		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪዿ"):	from swVuG9qtXU	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==rDG9dZoXRhCJcieUSF0KB(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩጀ")	:	from S8JQjzuaFn		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==vWNRusF46D7Mi8GpZ(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨጁ")	:	from jGMlwzJTtv		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jQv0du1iVxTgAXCM(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩጂ")	:	from JnsR2T8B09		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫጃ")	:	from QpoF5DkPh4		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==lCT8hfYUBX4OQMmL(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬጄ")	:	from S6Se7WLuIl		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ጅ")	:	from v5vW02AcV8		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==A6Sg45ChDR3BJLYfFH(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧጆ")	:	from YLCDhAx5rF		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧጇ")	:	from bAjeMmndGX		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧገ")	:	from MratzORUN5			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==JHMxIE4fs1mvQtKW7R(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪጉ")	:	from wRVbtqLZf2		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xdSThjYnuHXAU6M(u"ࠩࡈࡐࡎࡌࡖࡊࡆࡈࡓࠬጊ")	:	from VGAs0ECPy5		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==DpRJnas65uVcO0S17dYG(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫጋ")	:	from uuXOPIpKac		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧጌ")	:	from VF8tB9Rrmv		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ግ")	:	from sWiE42MC9r		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨጎ")	:	from O6AvwjFPyc		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩጏ")	:	from KLjHmDNt67		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡈࡒࡗ࡙ࡇࠧጐ")		:	from trBSD8f1qs			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪ጑")	:	from ye0qspHNPG		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==yRWQMHxZEz0(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬጒ")	:	from bb3HwzD8uc		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==Gj3rMP1Cb8wHdp49la0(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩጓ"):	from k91BPyv6Co	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡍࡏࡐࡉࡏࡉࡘࡋࡁࡓࡅࡋࠫጔ"):	from RzxnIa41o0	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨጕ")	:	from ypBe9URGvC		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡊࡈࡌࡐࡒ࠭጖")		:	from DDkJMRovqe			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==yRWQMHxZEz0(u"ࠨࡋࡓࡘ࡛࠭጗")		:	from lFWVNcqCio			import AAMk21ZpiCQ7jImw0fzR5UuG as iKL7Z0wdopbjRXM,zxTXK1GQm2WUob7AcwCIB0tfS5jNPy as JSV3rnwasAZ,ANaRC3c914UdxDrFM as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==bQGafNLXyFgsZP6ut(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬጘ")	:	from q5q0iJbOoU		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬጙ")	:	from P8P9FZKBQA		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭ጚ")	:	from F1jKODep2E		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭ጛ")	:	from HUs3ICRGpA		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ጜ")	:	from uug6pCUxKH			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨጝ")	:	from KiofgBtErJ		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡏ࠶࡙ࠬጞ")		:	from L7lMpnYoUi			import AAMk21ZpiCQ7jImw0fzR5UuG as iKL7Z0wdopbjRXM,zxTXK1GQm2WUob7AcwCIB0tfS5jNPy as JSV3rnwasAZ,ANaRC3c914UdxDrFM as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xm6jK1ZMuWq5(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬጟ")	:	from Xbvn2aoINM		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==Gj3rMP1Cb8wHdp49la0(u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪጠ")	:	from oasyB3Y47C			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==yRWQMHxZEz0(u"ࠫࡒ࡟ࡃࡊࡏࡄࠫጡ")	:	from UMFnku9ZcV			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡖࡁࡏࡇࡗࠫጢ")		:	from mJhjNWtdpz			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==rDG9dZoXRhCJcieUSF0KB(u"࠭ࡑࡇࡋࡏࡑࠬጣ")		:	from kylz2TWhrf			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫጤ"):	from PwpR5yMFE9		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xdSThjYnuHXAU6M(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫጥ")	:	from aMzNHQ6SqT		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫጦ")	:	from y0tR1hI5BJ		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xm6jK1ZMuWq5(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭ጧ")	:	from jiBC0w251c		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨጨ"):	from fckzxFCTyS		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==rDG9dZoXRhCJcieUSF0KB(u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨጩ")	:	from NQ16RxwVkA		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==llkFwuCyhaP3sK76qO4T(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ጪ")	:	from QZCw3MIvEh			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==llkFwuCyhaP3sK76qO4T(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩጫ")	:	from aXUcEJB420		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪጬ")	:	from NT8cWXsSK2		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==VhqD3zp7mUieI8sMQlETH(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫጭ")	:	from PJgTNKZaBr		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡘࡎࡑࡁࡂࡖࠪጮ")	:	from NX4UzKw8Mg			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==w8JC1y7Lp3(u"࡙ࠫ࡜ࡆࡖࡐࠪጯ")		:	from CCmXVv3a6U			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==lCT8hfYUBX4OQMmL(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬጰ")	:	from qq7H5SJREj			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xdSThjYnuHXAU6M(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪጱ"):	from vBF7rmZwOf		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨጲ")	:	from ehHmGOQ6c3		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩጳ")	:	from CS0RsuDKV8		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩ࡜ࡅࡖࡕࡔࠨጴ")		:	from fMuyTt1d9p			import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫጵ")	:	from PmTDhaY7bB		import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	elif nL3SyhovzIm0URBZJ==jQv0du1iVxTgAXCM(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪጶ"):	from J7QCGdq6cx	import x6zs7UWPvmuecZOHqtgAVnbwCE as iKL7Z0wdopbjRXM,LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx as JSV3rnwasAZ,UT69hgqoKsWNIwM5zkAYb as RULru39aExTFy0tzIOGk1ivSM8Xw
	return iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw
def Yz9CGVI5S3N1mukQfvK0Z(mmtMvAUnBzDE6l7NOs,zQfGP7LOR8YrN04CwgaUvtpb9,showDialogs):
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,DpRJnas65uVcO0S17dYG(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪጷ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(mmtMvAUnBzDE6l7NOs)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩጸ")+str(zQfGP7LOR8YrN04CwgaUvtpb9)+kPCxIUZb1V(u"ࠧࠡ࡟ࠪጹ"))
	OO9xQWZnuTNMf1SDFE43JPeV = tt4jsl3YLKexr()
	OO9xQWZnuTNMf1SDFE43JPeV.create(mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪጺ"))
	TWOUKC3StPv6AQrXMJ9N5kipF8YVZ = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠲࠲࠵࠸ᜪ")*pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠲࠲࠵࠸ᜪ")
	f0hsr5ziqOb = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳ᜫ")*TWOUKC3StPv6AQrXMJ9N5kipF8YVZ
	import requests as sfS7a5R14zxlLBM9y0cEUmNV
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = sfS7a5R14zxlLBM9y0cEUmNV.get(mmtMvAUnBzDE6l7NOs,stream=y0yvdNOZkiKEg5RLMhoDVQAB9F2,headers=zQfGP7LOR8YrN04CwgaUvtpb9)
	oIG6hpe87FuJZ = lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers
	lGQxR39dqyUb1YFcCmjZN5EthrpJ.close()
	kdRw1jCtDJSUeBhHyiTq7 = bytes()
	if not oIG6hpe87FuJZ:
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฬ่็๋ࠦๅ็ࠢอั๊๐ไࠡษ็้้็ࠠศๆ่฻้๎ศ๊ࠡสุ่ฮศࠡไาࠤ๏้่็ࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮ࠡฮิฬࠥะอๆ์็ࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠬጻ"))
		OO9xQWZnuTNMf1SDFE43JPeV.close()
	else:
		if lCT8hfYUBX4OQMmL(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫጼ") not in list(oIG6hpe87FuJZ.keys()): puL4ve3Ttja9HIRBhXyQ7lsf8irSqb = wTLFCOcM26fmYlW7U
		else: puL4ve3Ttja9HIRBhXyQ7lsf8irSqb = int(oIG6hpe87FuJZ[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬጽ")])
		DUjEy2f3kZAQveqlNHWFtYRVTbo0pg = str(int(erqDsJmL3BQHuGtPkcf0X9(u"࠵࠵࠶࠰ᜭ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb/TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)/ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠴࠴࠵࠶࠮࠱ᜬ"))
		QoqZg8RaB15FxPYmG0bcO6tAl7U3J = int(puL4ve3Ttja9HIRBhXyQ7lsf8irSqb/f0hsr5ziqOb)+UD4N8MjVTd
		if JHMxIE4fs1mvQtKW7R(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬጾ") in list(oIG6hpe87FuJZ.keys()) and puL4ve3Ttja9HIRBhXyQ7lsf8irSqb>TWOUKC3StPv6AQrXMJ9N5kipF8YVZ:
			a7fzRZAQEcvdoCLNIhVkeWYj2 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			NiRkS4WyvYjcPmq0tTEH2aw = []
			pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠶࠶ᜮ")
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(wTLFCOcM26fmYlW7U*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+llkFwuCyhaP3sK76qO4T(u"࠭࠭ࠨጿ")+str(UD4N8MjVTd*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(UD4N8MjVTd*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+xdSThjYnuHXAU6M(u"ࠧ࠮ࠩፀ")+str(Tb7oymMnpflsSv3eu4Pz2*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(Tb7oymMnpflsSv3eu4Pz2*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+Gj3rMP1Cb8wHdp49la0(u"ࠨ࠯ࠪፁ")+str(MMRBkhnWVJCQwU*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(MMRBkhnWVJCQwU*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࠰ࠫፂ")+str(R9RNUT6WAPEYjHqtIokxuXs*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(R9RNUT6WAPEYjHqtIokxuXs*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+llkFwuCyhaP3sK76qO4T(u"ࠪ࠱ࠬፃ")+str(Gj3rMP1Cb8wHdp49la0(u"࠻ᜯ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(TNw1pBHb8CtSZe0EFxuJqI(u"࠵ᜰ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+bQGafNLXyFgsZP6ut(u"ࠫ࠲࠭ፄ")+str(weh7SGmuTgXOVRcMo1rlLq(u"࠷ᜱ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠹ᜳ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+Gj3rMP1Cb8wHdp49la0(u"ࠬ࠳ࠧፅ")+str(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠹ᜲ")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠼᜵")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭࠭ࠨፆ")+str(VhqD3zp7mUieI8sMQlETH(u"࠼᜴")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(w8JC1y7Lp3(u"࠸᜷")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ࠮ࠩፇ")+str(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠿᜶")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf-UD4N8MjVTd))
			NiRkS4WyvYjcPmq0tTEH2aw.append(str(it4DKnryZlx(u"࠺᜸")*puL4ve3Ttja9HIRBhXyQ7lsf8irSqb//pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf)+fmkZtbRj3ux(u"ࠨ࠯ࠪፈ"))
			llsBQVNe1ZEU0Tu4kjS3onhDfPOYm = float(QoqZg8RaB15FxPYmG0bcO6tAl7U3J)/pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf
			Gvy7JqbB1NQHtk = llsBQVNe1ZEU0Tu4kjS3onhDfPOYm/int(UD4N8MjVTd+llsBQVNe1ZEU0Tu4kjS3onhDfPOYm)
		else:
			a7fzRZAQEcvdoCLNIhVkeWYj2 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
			pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf = UD4N8MjVTd
			Gvy7JqbB1NQHtk = UD4N8MjVTd
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,w8JC1y7Lp3(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪፉ")+str(a7fzRZAQEcvdoCLNIhVkeWYj2)+MFhbWia58mP3su0fk2d(u"ࠪࠤࡢࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬፊ")+str(puL4ve3Ttja9HIRBhXyQ7lsf8irSqb)+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࠥࡣࠧፋ"))
		qbRmVByrJv18,qS5jdPO6Fi4MaBYIwhzAng = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
		for yylJTxXLjV5zgwRYNEs2qmHdPh in range(pthMcyzrXKvbWNV9nOD1Y7mwQsdHgf):
			XubVRNO48BsjJASlmeKwdTCr = zQfGP7LOR8YrN04CwgaUvtpb9.copy()
			if a7fzRZAQEcvdoCLNIhVkeWYj2: XubVRNO48BsjJASlmeKwdTCr[lCT8hfYUBX4OQMmL(u"ࠬࡘࡡ࡯ࡩࡨࠫፌ")] = it4DKnryZlx(u"࠭ࡢࡺࡶࡨࡷࡂ࠭ፍ")+NiRkS4WyvYjcPmq0tTEH2aw[yylJTxXLjV5zgwRYNEs2qmHdPh]
			lGQxR39dqyUb1YFcCmjZN5EthrpJ = sfS7a5R14zxlLBM9y0cEUmNV.get(mmtMvAUnBzDE6l7NOs,stream=y0yvdNOZkiKEg5RLMhoDVQAB9F2,headers=XubVRNO48BsjJASlmeKwdTCr,timeout=fmkZtbRj3ux(u"࠵࠳࠴᜹"))
			for nxPlEuNMWkraGoKQyfi3RS9X7gC in lGQxR39dqyUb1YFcCmjZN5EthrpJ.iter_content(chunk_size=f0hsr5ziqOb):
				if OO9xQWZnuTNMf1SDFE43JPeV.iscanceled():
					KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧፎ"))
					break
				qbRmVByrJv18 += Gvy7JqbB1NQHtk
				kdRw1jCtDJSUeBhHyiTq7 += nxPlEuNMWkraGoKQyfi3RS9X7gC
				if not qS5jdPO6Fi4MaBYIwhzAng: qS5jdPO6Fi4MaBYIwhzAng = len(nxPlEuNMWkraGoKQyfi3RS9X7gC)
				if puL4ve3Ttja9HIRBhXyQ7lsf8irSqb: snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠴࠴࠵᜺")*qbRmVByrJv18//QoqZg8RaB15FxPYmG0bcO6tAl7U3J,VhqD3zp7mUieI8sMQlETH(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩፏ"),str(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠵࠶࠮࠱᜻")*qS5jdPO6Fi4MaBYIwhzAng*qbRmVByrJv18//f0hsr5ziqOb//ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠵࠶࠮࠱᜻"))+MFhbWia58mP3su0fk2d(u"ࠩࠣ࠳ࠥ࠭ፐ")+DUjEy2f3kZAQveqlNHWFtYRVTbo0pg+vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࠤࡒࡈࠧፑ"))
				else: snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,qS5jdPO6Fi4MaBYIwhzAng*qbRmVByrJv18//f0hsr5ziqOb,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩፒ"),str(JHMxIE4fs1mvQtKW7R(u"࠶࠶࠰࠯࠲᜼")*qS5jdPO6Fi4MaBYIwhzAng*qbRmVByrJv18//f0hsr5ziqOb//JHMxIE4fs1mvQtKW7R(u"࠶࠶࠰࠯࠲᜼"))+A6Sg45ChDR3BJLYfFH(u"ࠬࠦࡍࡃࠩፓ"))
			lGQxR39dqyUb1YFcCmjZN5EthrpJ.close()
		OO9xQWZnuTNMf1SDFE43JPeV.close()
		if len(kdRw1jCtDJSUeBhHyiTq7)<puL4ve3Ttja9HIRBhXyQ7lsf8irSqb and puL4ve3Ttja9HIRBhXyQ7lsf8irSqb>wTLFCOcM26fmYlW7U:
			KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,rDG9dZoXRhCJcieUSF0KB(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩፔ")+str(len(kdRw1jCtDJSUeBhHyiTq7)//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)+DpRJnas65uVcO0S17dYG(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬፕ")+DUjEy2f3kZAQveqlNHWFtYRVTbo0pg+D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࠢࡐࡆࠥࡣࠧፖ"))
			nV02gQlNqjHvTX5eYJ8xfdkp1u = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠩศ่฿อม๊ࠡัีําࠧፗ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪፘ"),xm6jK1ZMuWq5(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭ፙ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,VhqD3zp7mUieI8sMQlETH(u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩፚ")+str(len(kdRw1jCtDJSUeBhHyiTq7)//TWOUKC3StPv6AQrXMJ9N5kipF8YVZ)+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ፛")+DUjEy2f3kZAQveqlNHWFtYRVTbo0pg+weh7SGmuTgXOVRcMo1rlLq(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ፜"))
			if nV02gQlNqjHvTX5eYJ8xfdkp1u==Tb7oymMnpflsSv3eu4Pz2: kdRw1jCtDJSUeBhHyiTq7 = Yz9CGVI5S3N1mukQfvK0Z(mmtMvAUnBzDE6l7NOs,zQfGP7LOR8YrN04CwgaUvtpb9,showDialogs)
			elif nV02gQlNqjHvTX5eYJ8xfdkp1u==UD4N8MjVTd: KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,vWNRusF46D7Mi8GpZ(u"ࠨ࠰࡟ࡸࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧ፝"))
			else: return wUvcPrYDfISbZolAm83GKEqMyXkn5
			if not kdRw1jCtDJSUeBhHyiTq7: return wUvcPrYDfISbZolAm83GKEqMyXkn5
		else: KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,JHMxIE4fs1mvQtKW7R(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦ࠱ࠤࠥࠦࡆࡪ࡮ࡨࠤࡘ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭፞")+DUjEy2f3kZAQveqlNHWFtYRVTbo0pg+MFhbWia58mP3su0fk2d(u"ࠪࠤࡒࡈࠠ࡞ࠩ፟"))
	return kdRw1jCtDJSUeBhHyiTq7
def p1plucWVfNhC5eoBxKMgr4(UdbRGoKhcDeI4lVfns5):
	return lGQxR39dqyUb1YFcCmjZN5EthrpJ
def uj5sWQJSqg9XZYy4Nahz0d6erxl(ooNetxzVOAy2GF6HYcurCfLi=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if TTuO14NzmB.GEOLOCATION_DATA: return TTuO14NzmB.GEOLOCATION_DATA
	VogIj4f3M7PHlhWLYU5z8rGK06p,XMiAvt4q9HhfwbPNsCnVk8o7RIW,xuvjiOlr0D6,BlinFG3NbYPC6TvVtymXfg51dcRe9,MMg6Fl1JiRvofSxNsKjXZWY0TAB,f4QRkewsmJPLSXoqYIVbBMTGh2j = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	xLDEnp9WdA = yRWQMHxZEz0(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡷࡩࡱ࠱࡭ࡸ࠵ࠧ፠")+ooNetxzVOAy2GF6HYcurCfLi+fmkZtbRj3ux(u"ࠬࡅ࡯ࡶࡶࡳࡹࡹࡃࡪࡴࡱࡱࠪ࡫࡯ࡥ࡭ࡦࡶࡁ࡮ࡶࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰ࠯ࡧ࡮ࡺࡹ࠭ࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ፡")
	zQfGP7LOR8YrN04CwgaUvtpb9 = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ።"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡈࡇࡗࠫ፣"),xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5,zQfGP7LOR8YrN04CwgaUvtpb9,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ፤"))
	if not lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		xLDEnp9WdA = llkFwuCyhaP3sK76qO4T(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴ࠲ࡧࡰࡪ࠰ࡦࡳࡲ࠵ࡪࡴࡱࡱ࠳ࠬ፥")+ooNetxzVOAy2GF6HYcurCfLi+rDG9dZoXRhCJcieUSF0KB(u"ࠪࡃ࡫࡯ࡥ࡭ࡦࡶࡁࡶࡻࡥࡳࡻ࠯ࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡤࡱࡸࡲࡹࡸࡹࡄࡱࡧࡩ࠱ࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦ࠮ࡦ࡭ࡹࡿࠬࡰࡨࡩࡷࡪࡺࠧ፦")
		lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,JHMxIE4fs1mvQtKW7R(u"ࠫࡌࡋࡔࠨ፧"),xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5,zQfGP7LOR8YrN04CwgaUvtpb9,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠷ࡴࡤࠨ፨"))
	if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		II64TLxj3mbqEyh9pHQ8oAv = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
		g5JSN8QcF36Xei1hys0pHwCGvo9 = bbeLsVCqouaSH53E0XmKh4AnFD.loads(II64TLxj3mbqEyh9pHQ8oAv)
		t9oC2mMwFAS4uLqzd = list(g5JSN8QcF36Xei1hys0pHwCGvo9.keys())
		if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡩࡱࠩ፩") in t9oC2mMwFAS4uLqzd: ooNetxzVOAy2GF6HYcurCfLi = g5JSN8QcF36Xei1hys0pHwCGvo9[llkFwuCyhaP3sK76qO4T(u"ࠧࡪࡲࠪ፪")]
		if A6Sg45ChDR3BJLYfFH(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ፫") in t9oC2mMwFAS4uLqzd: VogIj4f3M7PHlhWLYU5z8rGK06p = g5JSN8QcF36Xei1hys0pHwCGvo9[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ፬")]
		if xm6jK1ZMuWq5(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ፭") in t9oC2mMwFAS4uLqzd: XMiAvt4q9HhfwbPNsCnVk8o7RIW = g5JSN8QcF36Xei1hys0pHwCGvo9[llkFwuCyhaP3sK76qO4T(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ፮")]
		if rDG9dZoXRhCJcieUSF0KB(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ፯") in t9oC2mMwFAS4uLqzd: xuvjiOlr0D6 = g5JSN8QcF36Xei1hys0pHwCGvo9[JHMxIE4fs1mvQtKW7R(u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ፰")]
		if xdSThjYnuHXAU6M(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ፱") in t9oC2mMwFAS4uLqzd: BlinFG3NbYPC6TvVtymXfg51dcRe9 = g5JSN8QcF36Xei1hys0pHwCGvo9[Gj3rMP1Cb8wHdp49la0(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ፲")]
		if xdSThjYnuHXAU6M(u"ࠩࡦ࡭ࡹࡿࠧ፳") in t9oC2mMwFAS4uLqzd: MMg6Fl1JiRvofSxNsKjXZWY0TAB = g5JSN8QcF36Xei1hys0pHwCGvo9[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡧ࡮ࡺࡹࠨ፴")]
		if s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡶࡻࡥࡳࡻࠪ፵") in t9oC2mMwFAS4uLqzd: ooNetxzVOAy2GF6HYcurCfLi = g5JSN8QcF36Xei1hys0pHwCGvo9[bQGafNLXyFgsZP6ut(u"ࠬࡷࡵࡦࡴࡼࠫ፶")]
		if erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨࠫ፷") in t9oC2mMwFAS4uLqzd: xuvjiOlr0D6 = g5JSN8QcF36Xei1hys0pHwCGvo9[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡄࡱࡧࡩࠬ፸")]
		if xdSThjYnuHXAU6M(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡏࡣࡰࡩࠬ፹") in t9oC2mMwFAS4uLqzd: BlinFG3NbYPC6TvVtymXfg51dcRe9 = g5JSN8QcF36Xei1hys0pHwCGvo9[MFhbWia58mP3su0fk2d(u"ࠩࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠭፺")]
		if kPCxIUZb1V(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ፻") in t9oC2mMwFAS4uLqzd:
			f4QRkewsmJPLSXoqYIVbBMTGh2j = g5JSN8QcF36Xei1hys0pHwCGvo9[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭፼")][vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡻࡴࡤࠩ፽")]
			if f4QRkewsmJPLSXoqYIVbBMTGh2j[wTLFCOcM26fmYlW7U] not in [w8JC1y7Lp3(u"࠭࠭ࠨ፾"),vWNRusF46D7Mi8GpZ(u"ࠧࠬࠩ፿")]: f4QRkewsmJPLSXoqYIVbBMTGh2j = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠭ࠪᎀ")+f4QRkewsmJPLSXoqYIVbBMTGh2j
		if w8JC1y7Lp3(u"ࠩࡲࡪ࡫ࡹࡥࡵࠩᎁ") in t9oC2mMwFAS4uLqzd:
			f4QRkewsmJPLSXoqYIVbBMTGh2j = g5JSN8QcF36Xei1hys0pHwCGvo9[llkFwuCyhaP3sK76qO4T(u"ࠪࡳ࡫࡬ࡳࡦࡶࠪᎂ")]
			if f4QRkewsmJPLSXoqYIVbBMTGh2j>=fmkZtbRj3ux(u"࠶᜽"): f4QRkewsmJPLSXoqYIVbBMTGh2j = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠰࠭ᎃ")+L5jXH0fZ8TvsESR.strftime(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࠫࡈ࠻ࠧࡐࠦᎄ"),L5jXH0fZ8TvsESR.gmtime(f4QRkewsmJPLSXoqYIVbBMTGh2j))
			else: f4QRkewsmJPLSXoqYIVbBMTGh2j = jQv0du1iVxTgAXCM(u"࠭࠭ࠨᎅ")+L5jXH0fZ8TvsESR.strftime(DpRJnas65uVcO0S17dYG(u"ࠢࠦࡊ࠽ࠩࡒࠨᎆ"),L5jXH0fZ8TvsESR.gmtime(-f4QRkewsmJPLSXoqYIVbBMTGh2j))
	v3E1fIzbSWsBgcCxhiHuwTtZpG = ooNetxzVOAy2GF6HYcurCfLi+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ࠮࠯ࠫᎇ")+VogIj4f3M7PHlhWLYU5z8rGK06p+D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࠯࠰ࠬᎈ")+XMiAvt4q9HhfwbPNsCnVk8o7RIW+xdSThjYnuHXAU6M(u"ࠪ࠰࠱࠭ᎉ")+BlinFG3NbYPC6TvVtymXfg51dcRe9+fmkZtbRj3ux(u"ࠫ࠱࠲ࠧᎊ")+MMg6Fl1JiRvofSxNsKjXZWY0TAB+it4DKnryZlx(u"ࠬ࠲ࠬࠨᎋ")+f4QRkewsmJPLSXoqYIVbBMTGh2j
	v3E1fIzbSWsBgcCxhiHuwTtZpG = v3E1fIzbSWsBgcCxhiHuwTtZpG.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: v3E1fIzbSWsBgcCxhiHuwTtZpG = v3E1fIzbSWsBgcCxhiHuwTtZpG.decode(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧᎌ"))
	TTuO14NzmB.GEOLOCATION_DATA = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(v3E1fIzbSWsBgcCxhiHuwTtZpG)
	return TTuO14NzmB.GEOLOCATION_DATA
def PLaXN4KSfzcmyu3(zICSGHQBPcFJ6r9hpKDTy):
	rYJ0qaynz1MvWE8A,showDialogs = wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if zICSGHQBPcFJ6r9hpKDTy.count(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡠࠩᎍ"))>=Tb7oymMnpflsSv3eu4Pz2:
		zICSGHQBPcFJ6r9hpKDTy,rYJ0qaynz1MvWE8A = zICSGHQBPcFJ6r9hpKDTy.split(xdSThjYnuHXAU6M(u"ࠨࡡࠪᎎ"),UD4N8MjVTd)
		rYJ0qaynz1MvWE8A = rDG9dZoXRhCJcieUSF0KB(u"ࠩࡢࠫᎏ")+rYJ0qaynz1MvWE8A
		if rDG9dZoXRhCJcieUSF0KB(u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ᎐") in rYJ0qaynz1MvWE8A: showDialogs = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		else: showDialogs = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return zICSGHQBPcFJ6r9hpKDTy,rYJ0qaynz1MvWE8A,showDialogs
def Un5o8hVIErRW7():
	wNRBQXDAup9tKrxhbSiPTGe4 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ᎑"))
	DFtim4NvblY9er6ROysq5 = wTLFCOcM26fmYlW7U
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(wNRBQXDAup9tKrxhbSiPTGe4):
		for rgNkiToc6MRPtULJ8BG in b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(wNRBQXDAup9tKrxhbSiPTGe4):
			if xdSThjYnuHXAU6M(u"ࠬ࠴ࡰࡺࡱࠪ᎒") in rgNkiToc6MRPtULJ8BG: continue
			if xdSThjYnuHXAU6M(u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫ᎓") in rgNkiToc6MRPtULJ8BG: continue
			YS4MVthWxR = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(wNRBQXDAup9tKrxhbSiPTGe4,rgNkiToc6MRPtULJ8BG)
			RsyrhLGe8pKE6VOkUuWcMidDaYx,ygOUXKL0h28HawR = xDXC5AF31hBZ2gRGJafuK6zENQMO(YS4MVthWxR)
			DFtim4NvblY9er6ROysq5 += RsyrhLGe8pKE6VOkUuWcMidDaYx
	return DFtim4NvblY9er6ROysq5
def xxEuXq3VfUIzivGHgh1FJNZQyYj(showDialogs):
	T2MXEBenwrjINLAJpV0h5PSUK3 = OOnvcPQy85HYA.getSetting(kPCxIUZb1V(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ᎔"))
	z0IYRT8mlVysu6nZ2FSJ5OkWx4MHhv = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,xdSThjYnuHXAU6M(u"ࠨࡵࡷࡶࠬ᎕"),it4DKnryZlx(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧ᎖"),yRWQMHxZEz0(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ᎗"))
	uloKUf3c57aJzmhEYxMkt4WALe,gPZy5F7EBHrVWu1 = T2MXEBenwrjINLAJpV0h5PSUK3,z0IYRT8mlVysu6nZ2FSJ5OkWx4MHhv
	ADXln7vFtZguVsT9pfda,XJ53bUr4ZD = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭᎘") not in str(TTuO14NzmB.SEND_THESE_EVENTS):
		xLDEnp9WdA = TTuO14NzmB.SITESURLS[TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ᎙")][MMRBkhnWVJCQwU]
		TbLGvkW8jF3sdlBaCP65SzmV4i = uj5sWQJSqg9XZYy4Nahz0d6erxl()
		XMiAvt4q9HhfwbPNsCnVk8o7RIW = TbLGvkW8jF3sdlBaCP65SzmV4i.split(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࠬ࠭ࠩ᎚"))[Tb7oymMnpflsSv3eu4Pz2]
		DFtim4NvblY9er6ROysq5 = Un5o8hVIErRW7()
		xxwBIFtsuXOJ5ki1 = {jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡶࡵࡨࡶࠬ᎛"):TTuO14NzmB.AV_CLIENT_IDS,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ᎜"):D1DBSuO0lLGRbcfCyY,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ᎝"):XMiAvt4q9HhfwbPNsCnVk8o7RIW,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࡭ࡩࡹࠧ᎞"):tTQjzDHVo9NBasmRb(DFtim4NvblY9er6ROysq5)}
		lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,fmkZtbRj3ux(u"ࠫࡕࡕࡓࡕࠩ᎟"),xLDEnp9WdA,xxwBIFtsuXOJ5ki1,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩᎠ"))
		if not lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
			if T2MXEBenwrjINLAJpV0h5PSUK3 in [wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"࠭ࡎࡆ࡙ࠪᎡ")]: uloKUf3c57aJzmhEYxMkt4WALe = rDG9dZoXRhCJcieUSF0KB(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭Ꭲ")
			elif T2MXEBenwrjINLAJpV0h5PSUK3==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡑࡏࡈࠬᎣ"): uloKUf3c57aJzmhEYxMkt4WALe = kPCxIUZb1V(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᎤ")
		else:
			ORJQ978yYzTE = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
			ORJQ978yYzTE = dm7KA8MukvxF3iH9CW2ZNc(xdSThjYnuHXAU6M(u"ࠪࡰ࡮ࡹࡴࠨᎥ"),ORJQ978yYzTE)
			ORJQ978yYzTE = sorted(ORJQ978yYzTE,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: int(key[wTLFCOcM26fmYlW7U]))
			XJ53bUr4ZD,gPZy5F7EBHrVWu1 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
			for Jk7r2WvEwPxfHs6LUu9Zcq0doIMp,aaCbPB24ZRKEzFXgAMY0,hU30beEvi6onzCMPS7Q in ORJQ978yYzTE:
				if Jk7r2WvEwPxfHs6LUu9Zcq0doIMp==fmkZtbRj3ux(u"ࠫ࠵࠭Ꭶ"):
					XJ53bUr4ZD += hU30beEvi6onzCMPS7Q+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡀ࠺ࠨᎧ")
					continue
				if gPZy5F7EBHrVWu1: gPZy5F7EBHrVWu1 += QWLr8ABjev+JegF7SlMawI03+VhqD3zp7mUieI8sMQlETH(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᎨ")+AAByQSLgaZwCsKnvc5eWNmY+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࡝ࡰ࡟ࡲࠬᎩ")
				hkqPGU7BptIu = hU30beEvi6onzCMPS7Q.split(QWLr8ABjev)[wTLFCOcM26fmYlW7U]
				wzoUP874t0bDhlrvFpdNkOZ = vvhR5ozeiJpANyl8fFO3GBw(u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬᎪ") if aaCbPB24ZRKEzFXgAMY0 else wUvcPrYDfISbZolAm83GKEqMyXkn5
				gPZy5F7EBHrVWu1 += hU30beEvi6onzCMPS7Q.replace(hkqPGU7BptIu,QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+hkqPGU7BptIu+wzoUP874t0bDhlrvFpdNkOZ+AAByQSLgaZwCsKnvc5eWNmY)+QWLr8ABjev
			gPZy5F7EBHrVWu1 = QWLr8ABjev+gPZy5F7EBHrVWu1+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࡟ࡲࡡࡴࠧᎫ")
			XJ53bUr4ZD = XJ53bUr4ZD.strip(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࠾࠿࠭Ꭼ"))
			ADXln7vFtZguVsT9pfda = OOnvcPQy85HYA.getSetting(MFhbWia58mP3su0fk2d(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧᎭ"))
			if gPZy5F7EBHrVWu1==z0IYRT8mlVysu6nZ2FSJ5OkWx4MHhv and T2MXEBenwrjINLAJpV0h5PSUK3 in [DpRJnas65uVcO0S17dYG(u"ࠬࡕࡌࡅࠩᎮ"),xdSThjYnuHXAU6M(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᎯ")]: uloKUf3c57aJzmhEYxMkt4WALe = fmkZtbRj3ux(u"ࠧࡐࡎࡇࠫᎰ")
			else: uloKUf3c57aJzmhEYxMkt4WALe = vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡐࡈ࡛ࠬᎱ")
			SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,DpRJnas65uVcO0S17dYG(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᎲ"),llkFwuCyhaP3sK76qO4T(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᎳ"),gPZy5F7EBHrVWu1,pHC2Aj4kbc3KDN0aZWBey6QV)
			OOnvcPQy85HYA.setSetting(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬᎴ"),tTQjzDHVo9NBasmRb(yoJ7t3WpjPkrCmTq))
			OOnvcPQy85HYA.setSetting(bQGafNLXyFgsZP6ut(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨᎵ"),XJ53bUr4ZD)
			WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠵᜾")*XJ53bUr4ZD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
			WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(DpRJnas65uVcO0S17dYG(u"࠲࠶᜿")*WxkZrDEM54oTl0gayus6BXmKz.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
			WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(xdSThjYnuHXAU6M(u"࠳࠼ᝀ")*WxkZrDEM54oTl0gayus6BXmKz.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()
			rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(bcP2jUx34tG51D6XSNnyWIes)
			lQ39XPxZLfupRTm(bcP2jUx34tG51D6XSNnyWIes,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡣ࡮ࡪ࠽ࠨᎶ")+str(int(WxkZrDEM54oTl0gayus6BXmKz[JHMxIE4fs1mvQtKW7R(u"࠷ᝂ"):MFhbWia58mP3su0fk2d(u"࠶࠸ᝃ")],Gj3rMP1Cb8wHdp49la0(u"࠷࠶ᝄ")))[:jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠼ᝁ")]+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࠡ࠽ࠪᎷ"))
			rC0YJ4awbU2H3LOGt5DIF.close()
		CCUh3G2g0qHz4oRP = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if XJ53bUr4ZD!=ADXln7vFtZguVsT9pfda else Z19pUxa2gfGMNKoDsEuytn85SjFvA
		if CCUh3G2g0qHz4oRP:
			WTOCG9VKdauqwsiN = TTuO14NzmB.W1haXcb7tVZ6K
			TTuO14NzmB.lOuLW0pjdgS4zX,TTuO14NzmB.W1haXcb7tVZ6K,TTuO14NzmB.ijmTSzJ1l9Nutf3aoVEZk,TTuO14NzmB.o4ZShCq8b53OYkUjrAwGDm1pT7PW,TTuO14NzmB.avprivsnorestrict,TTuO14NzmB.avprivslongperiod = WtlCneczGPY2ODSUrAh5jdsf6m([SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩᎸ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪᎹ"),w8JC1y7Lp3(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽࡚ࡘࡖࡏࡗࡖ࡙࠺ࡎࡘࠨᎺ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬᎻ"),llkFwuCyhaP3sK76qO4T(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡱ࡬ࡅࡘࡈ࡚ࡊ࡞ࠧᎼ"),rDG9dZoXRhCJcieUSF0KB(u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬᎽ")])
			I4NzDJmyliKrsQhtcT8uvjZ7E = TTuO14NzmB.W1haXcb7tVZ6K
			if not WTOCG9VKdauqwsiN and I4NzDJmyliKrsQhtcT8uvjZ7E and lCT8hfYUBX4OQMmL(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᎾ") in TTuO14NzmB.SEND_THESE_EVENTS:
				TTuO14NzmB.SEND_THESE_EVENTS.remove(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭Ꮏ"))
				TTuO14NzmB.SEND_THESE_EVENTS.append(MFhbWia58mP3su0fk2d(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᏀ"))
			elif WTOCG9VKdauqwsiN and not I4NzDJmyliKrsQhtcT8uvjZ7E and TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᏁ") in TTuO14NzmB.SEND_THESE_EVENTS:
				TTuO14NzmB.SEND_THESE_EVENTS.remove(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭Ꮒ"))
				TTuO14NzmB.SEND_THESE_EVENTS.append(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪᏃ"))
			ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	if showDialogs:
		if uloKUf3c57aJzmhEYxMkt4WALe in [TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᏄ"),vWNRusF46D7Mi8GpZ(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭Ꮕ")]:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨᏆ"))
		else:
			sNQlowOJdgWBt2cyV18ZI6Ye(erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡵ࡭࡬࡮ࡴࠨᏇ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭Ꮘ"),gPZy5F7EBHrVWu1,JHMxIE4fs1mvQtKW7R(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᏉ"))
			uloKUf3c57aJzmhEYxMkt4WALe = jQv0du1iVxTgAXCM(u"ࠬࡕࡌࡅࠩᏊ")
	if uloKUf3c57aJzmhEYxMkt4WALe!=T2MXEBenwrjINLAJpV0h5PSUK3:
		OOnvcPQy85HYA.setSetting(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫᏋ"),uloKUf3c57aJzmhEYxMkt4WALe)
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def eva1dqCNwXh5lL3rkTfWSVp(PFWjOnk54vq0fmEecwJrbpHoatlsVX,TdmwDr8SEt1F):
	import socket as kkTDvdS6LY24nsjJMp3ba5uQmiX
	NfJk4dxCjUmQ7gaOW = kkTDvdS6LY24nsjJMp3ba5uQmiX.socket(kkTDvdS6LY24nsjJMp3ba5uQmiX.AF_INET,kkTDvdS6LY24nsjJMp3ba5uQmiX.SOCK_STREAM)
	NfJk4dxCjUmQ7gaOW.settimeout(MMRBkhnWVJCQwU)
	try:
		V1VfMqTkXdYulSwF75JPhDgZ = L5jXH0fZ8TvsESR.time()
		NfJk4dxCjUmQ7gaOW.connect((PFWjOnk54vq0fmEecwJrbpHoatlsVX,TdmwDr8SEt1F))
		kUcE06vfzoKBLNMVX = L5jXH0fZ8TvsESR.time()
		NNBbLrMpTYx5ioUuy74n = round((kUcE06vfzoKBLNMVX-V1VfMqTkXdYulSwF75JPhDgZ)*dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠱࠱࠲࠳ᝅ"))
	except: NNBbLrMpTYx5ioUuy74n = -UD4N8MjVTd
	NfJk4dxCjUmQ7gaOW.close()
	return NNBbLrMpTYx5ioUuy74n
def N2QCj84D9qInlHveBcf6(showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥ฿ๅๅ์ฬࠤฬ๊ส็ฺํๅࠥอไร่ࠣรࠦ࠭Ꮜ"))
	else: ug0EmiKYnRT1qeH9MFyr3pO = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
		for rgNkiToc6MRPtULJ8BG in b7i1PgC8Z4e5BFoHNd9E2UVvfc.listdir(kAXGQe4sH7o3dfLUKv2zlZDM8r09):
			if rgNkiToc6MRPtULJ8BG.endswith(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ࠰ࡧࡦࠬᏍ")) and A6Sg45ChDR3BJLYfFH(u"ࠩࡧࡥࡹࡧࠧᏎ") in rgNkiToc6MRPtULJ8BG:
				gAS9ocTOnZQ6slVWhJEKUF0yu = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,rgNkiToc6MRPtULJ8BG)
				rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(gAS9ocTOnZQ6slVWhJEKUF0yu)
				sXeobuj186Q.execute(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭Ꮟ"))
				sXeobuj186Q.execute(JHMxIE4fs1mvQtKW7R(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡹ࡫࡭ࡱࡡࡶࡸࡴࡸࡥ࠾ࡏࡈࡑࡔࡘ࡙࠼ࠩᏐ"))
				sXeobuj186Q.execute(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨᏑ"))
				sXeobuj186Q.execute(s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩᏒ"))
				sXeobuj186Q.execute(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨᏓ"))
				rC0YJ4awbU2H3LOGt5DIF.commit()
				rC0YJ4awbU2H3LOGt5DIF.close()
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩᏔ"))
	return
def vk2AWPdaQpzxMuht3ZNqfienVRwL7(MNner5YCpvoQFAgHwd1hylOuZJkGj,s0fJUB6zAg9n8MWb2G,showDialogs):
	if MNner5YCpvoQFAgHwd1hylOuZJkGj!=hbdwEgkQ6DLYV1TKuioHxyvj:
		if MNner5YCpvoQFAgHwd1hylOuZJkGj==wekzmfMuLYaTUdVljQX6oB9IG: TTuO14NzmB.ALLOW_DNS_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		elif MNner5YCpvoQFAgHwd1hylOuZJkGj==uxig7mJanAYQ20: TTuO14NzmB.ALLOW_DNS_FIX = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		elif MNner5YCpvoQFAgHwd1hylOuZJkGj==cc2JaqoYp8m: TTuO14NzmB.ALLOW_DNS_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if s0fJUB6zAg9n8MWb2G!=hbdwEgkQ6DLYV1TKuioHxyvj:
		if s0fJUB6zAg9n8MWb2G==wekzmfMuLYaTUdVljQX6oB9IG: TTuO14NzmB.ALLOW_PROXY_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		elif s0fJUB6zAg9n8MWb2G==uxig7mJanAYQ20: TTuO14NzmB.ALLOW_PROXY_FIX = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		elif s0fJUB6zAg9n8MWb2G==cc2JaqoYp8m: TTuO14NzmB.ALLOW_PROXY_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if showDialogs!=hbdwEgkQ6DLYV1TKuioHxyvj:
		if showDialogs==wekzmfMuLYaTUdVljQX6oB9IG: TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		elif showDialogs==uxig7mJanAYQ20: TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		elif showDialogs==cc2JaqoYp8m: TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return
def llKWkJNhGv7tyQXPIE04qMeogf8iVr(uMefvj4B7ELWokPxSiOzcFTVbU,zLkaD48V1CIdnhy,OO3HfuLko9eFmhnbvYV1tWRilxAcU,args):
	xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = args
	we7D2l4URB = xVwDZbA6EOjpgX0.split(DpRJnas65uVcO0S17dYG(u"ࠩ࠰ࠫᏕ"))[wTLFCOcM26fmYlW7U]
	qqQZBeivhj72yLTn = fmkZtbRj3ux(u"ࠪื๏ืแาࠢิๆ๊ࠦࠧᏖ")+str(uMefvj4B7ELWokPxSiOzcFTVbU)
	xLK3kz2aD5 = QEbx35yvreoT2sPDG4k9Fcfa8Z(ZD5n0eJivzWOMxY98dgrumkwRG,xVwDZbA6EOjpgX0)
	KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭ࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨᏗ")+str(uMefvj4B7ELWokPxSiOzcFTVbU)+xm6jK1ZMuWq5(u"ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᏘ")+str(TeuQd8DXNkc0zlYmKF2J)+xdSThjYnuHXAU6M(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧᏙ")+Kw19luY7W2jGgsBa5n4hctLfFS+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᏚ")+xVwDZbA6EOjpgX0+Gj3rMP1Cb8wHdp49la0(u"ࠨࠢࡠࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ꮫ")+xLK3kz2aD5+Gj3rMP1Cb8wHdp49la0(u"ࠩࠣࡡࠬᏜ"))
	update = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if uMefvj4B7ELWokPxSiOzcFTVbU==wTLFCOcM26fmYlW7U:
		scraperserver = jQv0du1iVxTgAXCM(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠷ࠧᏝ")
		HlhUjJPkzCEw9Y = llkFwuCyhaP3sK76qO4T(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠳࠸࠴ࡩ࠸࠲ࡧ࠳࠰ࡧ࠺࠾ࡡ࠮࠶࠳࠶࠶࠳ࡡࡢ࠺࠷࠱ࡪ࠿࠲࠴ࡥࡤࡪ࠽࠻࠸࠴࠶ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭Ꮮ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+Gj3rMP1Cb8wHdp49la0(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᏟ")+HlhUjJPkzCEw9Y+kPCxIUZb1V(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭Ꮰ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==UD4N8MjVTd:
		scraperserver = yRWQMHxZEz0(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠵ࠫᏡ")
		HlhUjJPkzCEw9Y = erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺ࠿࡬ࡰ࠿࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠿࠻࠳࠶࠵ࠪᏢ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᏣ")+HlhUjJPkzCEw9Y+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᏤ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==Tb7oymMnpflsSv3eu4Pz2:
		scraperserver = yRWQMHxZEz0(u"ࠫࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩࠨᏥ")
		HlhUjJPkzCEw9Y = MFhbWia58mP3su0fk2d(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࡂ࡯࡬࠻࠹࠹ࡦ࠹࡬ࡣ࠴࠶ࡩࡧࡩ࠷࠹ࡥ࠻ࡦ࠹࠺ࡧ࠱࠶ࡨ࠶࠺࠵࠺ࡣࡥ࠻࠴࠸ࡨࡆࡰࡳࡱࡻࡽ࠲ࡹࡥࡳࡸࡨࡶ࠳ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰ࡦࡳࡲࡀ࠸࠱࠲࠴ࠫᏦ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭Ꮷ")+HlhUjJPkzCEw9Y+bQGafNLXyFgsZP6ut(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᏨ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==MMRBkhnWVJCQwU:
		scraperserver = llkFwuCyhaP3sK76qO4T(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪᏩ")
		qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG.replace(jQv0du1iVxTgAXCM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫᏪ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫᏫ"))
		XXup0CJWslMOqymaKthfb84 = kPCxIUZb1V(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡥࡶࡲ࠱ࡧࡴࡳ࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠴࡚ࡓࡹࡍࡵࡎ࠴ࡳࡇࡘࡘ࡬ࡕࡑࡇࡧࡉࡍࡋ࠳ࡎ࡜࡞ࡐࡪ࡫࠲ࡧ࡮࡟ࡽࠦ࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡆࡢ࡮ࡶࡩࠫࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᏬ")+vvLTYxVfrbDza(qaLFXuDExl8w)
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(VhqD3zp7mUieI8sMQlETH(u"ࠬࡍࡅࡕࠩᏭ"),XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==R9RNUT6WAPEYjHqtIokxuXs:
		scraperserver = VhqD3zp7mUieI8sMQlETH(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠭Ꮾ")
		XXup0CJWslMOqymaKthfb84 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷ࠲ࡨࡵ࡭࠰ࡁࡷࡳࡰ࡫࡮࠾ࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠩࡴࡷࡵࡸࡺࡅࡲࡹࡳࡺࡲࡺ࠿ࡌࡐࠫࡻࡲ࡭࠿ࠪᏯ")+vvLTYxVfrbDza(ZD5n0eJivzWOMxY98dgrumkwRG)
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(rDG9dZoXRhCJcieUSF0KB(u"ࠨࡉࡈࡘࠬᏰ"),XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		try:
			CgbV8o2ImWEtxzBvlLcRJ = bbeLsVCqouaSH53E0XmKh4AnFD.loads(OFH84dcLtak31SUEuy.content)
			OFH84dcLtak31SUEuy.content = CgbV8o2ImWEtxzBvlLcRJ.get(Gj3rMP1Cb8wHdp49la0(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᏱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			pRV2KN7aFeM3BkEnOuxh06GZ = sum(x7gEebVpfrk < erqDsJmL3BQHuGtPkcf0X9(u"ࠪࠤࠬᏲ") and x7gEebVpfrk not in llkFwuCyhaP3sK76qO4T(u"ࠫࡡࡸ࡜࡯࡞ࡷࠫᏳ") for x7gEebVpfrk in OFH84dcLtak31SUEuy.content[:bQGafNLXyFgsZP6ut(u"࠲࠲࠳࠴ᝆ")])
			if pRV2KN7aFeM3BkEnOuxh06GZ > pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳࠳ᝇ"):
				OFH84dcLtak31SUEuy = D8JlSY7NibwpLWxPXAfFgQsd()
				OFH84dcLtak31SUEuy.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				OFH84dcLtak31SUEuy.content = wUvcPrYDfISbZolAm83GKEqMyXkn5
		except: pass
	elif uMefvj4B7ELWokPxSiOzcFTVbU==ewJ9sTMmXtWH0ANVShQ2:
		scraperserver = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠴ࠫᏴ")
		HlhUjJPkzCEw9Y = jQv0du1iVxTgAXCM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷࠪࡵࡸ࡯ࡹࡻࡢࡧࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡣࡴࡲࡻࡸ࡫ࡲ࠾ࡈࡤࡰࡸ࡫ࠦࡧࡱࡵࡻࡦࡸࡤࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠺࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵ࠰ࡦࡳࡲࡀ࠸࠱࠺࠳ࠫᏵ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ᏶")+HlhUjJPkzCEw9Y+xm6jK1ZMuWq5(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨ᏷")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==llkFwuCyhaP3sK76qO4T(u"࠹ᝈ"):
		scraperserver = vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠶࠭ᏸ")
		HlhUjJPkzCEw9Y = fmkZtbRj3ux(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧࠩ࡫ࡪࡵࡃࡰࡦࡨࡁ࡮ࡲࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧᏹ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+llkFwuCyhaP3sK76qO4T(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᏺ")+HlhUjJPkzCEw9Y+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᏻ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==lCT8hfYUBX4OQMmL(u"࠻ᝉ"):
		scraperserver = VhqD3zp7mUieI8sMQlETH(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠴ࠪᏼ")
		HlhUjJPkzCEw9Y = s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᏽ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ᏾")+HlhUjJPkzCEw9Y+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ᏿")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠽ᝊ"):
		scraperserver = DpRJnas65uVcO0S17dYG(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠹ࠧ᐀")
		XXup0CJWslMOqymaKthfb84 = xdSThjYnuHXAU6M(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠲ࡺ࠶࠵࠿ࡢࡲ࡬ࡣࡰ࡫ࡹ࠾࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᐁ")+vvLTYxVfrbDza(ZD5n0eJivzWOMxY98dgrumkwRG)
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡍࡅࡕࠩᐂ"),XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==kPCxIUZb1V(u"࠿ᝋ"):
		scraperserver = VhqD3zp7mUieI8sMQlETH(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠶ࠬᐃ")
		HlhUjJPkzCEw9Y = DpRJnas65uVcO0S17dYG(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡇࡅࠧࡴࡨࡸࡺࡸ࡮ࡠࡲࡤ࡫ࡪࡥࡳࡰࡷࡵࡧࡪࡃࡴࡳࡷࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡴࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨᐄ")
		XXup0CJWslMOqymaKthfb84 = ZD5n0eJivzWOMxY98dgrumkwRG+D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᐅ")+HlhUjJPkzCEw9Y+jQv0du1iVxTgAXCM(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᐆ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,XXup0CJWslMOqymaKthfb84,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif uMefvj4B7ELWokPxSiOzcFTVbU==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠱࠱ᝌ"):
		scraperserver = vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡷࡨࡸࡡࡱࡲࡨࡽࠬᐇ")
		RYA0WhcGHbCiajmluQ4Stz1spVK = XubVRNO48BsjJASlmeKwdTCr.copy()
		RYA0WhcGHbCiajmluQ4Stz1spVK.update({TNw1pBHb8CtSZe0EFxuJqI(u"ࠫ࡝࠳ࡒࡢࡲ࡬ࡨࡦࡶࡩ࠮ࡊࡲࡷࡹ࠭ᐈ"):erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡹࡣࡳࡣࡳࡴࡪࡿ࠭ࡤࡱࡰ࠲ࡵ࠴ࡲࡢࡲ࡬ࡨࡦࡶࡩ࠯ࡥࡲࡱࠬᐉ"),weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡘ࠮ࡔࡤࡴ࡮ࡪࡡࡱ࡫࠰ࡏࡪࡿࠧᐊ"):llkFwuCyhaP3sK76qO4T(u"ࠧ࠵࠶ࡩ࠸࠵࠾ࡤ࠵ࡣ࠵ࡱࡸ࡮࠱ࡣ࠵ࡥࡨ࠹࠿ࡡ࠷࠶࠻࠵࠼࡬࠵ࡱ࠳࠳࠵࠵࠹ࡦ࡫ࡵࡱ࠸ࡦ࠺࠱࠸ࡨࡦ࠹࠸࠶࠴࠳ࠩᐋ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᐌ"):kPCxIUZb1V(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬᐍ")})
		F148a7xNcp9C = FjUcS938pAH5sZ.copy()
		F148a7xNcp9C.update({bQGafNLXyFgsZP6ut(u"ࠪࡧࡲࡪࠧᐎ"):vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡷ࡫ࡱࡶࡧࡶࡸ࠳࠭ᐏ")+xRVnhbcSF5v1NBQI.lower(),llkFwuCyhaP3sK76qO4T(u"ࠬࡻࡲ࡭ࠩᐐ"):vvLTYxVfrbDza(ZD5n0eJivzWOMxY98dgrumkwRG)})
		UUu2LnoGibwdsJjQtr0h = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(F148a7xNcp9C)
		XXup0CJWslMOqymaKthfb84 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡥࡵࡥࡵࡶࡥࡺ࠯ࡦࡳࡲ࠴ࡰ࠯ࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳ࠯ࡢࡲ࡬࠳ࡻ࠷ࠧᐑ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(vWNRusF46D7Mi8GpZ(u"ࠧࡑࡑࡖࡘࠬᐒ"),XXup0CJWslMOqymaKthfb84,UUu2LnoGibwdsJjQtr0h,RYA0WhcGHbCiajmluQ4Stz1spVK,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		try:
			CgbV8o2ImWEtxzBvlLcRJ = bbeLsVCqouaSH53E0XmKh4AnFD.loads(OFH84dcLtak31SUEuy.content)
			OFH84dcLtak31SUEuy.content = CgbV8o2ImWEtxzBvlLcRJ[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡵࡲࡰࡺࡺࡩࡰࡰࠪᐓ")][Gj3rMP1Cb8wHdp49la0(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫᐔ")]
		except: pass
	elif uMefvj4B7ELWokPxSiOzcFTVbU==s149dk8uh2p7oFzaLxZeI3Or(u"࠲࠳ᝍ"):
		scraperserver = VhqD3zp7mUieI8sMQlETH(u"ࠪࡶࡪࡶ࡬ࡪࡶ࠴ࠫᐕ")
		RYA0WhcGHbCiajmluQ4Stz1spVK = XubVRNO48BsjJASlmeKwdTCr.copy()
		RYA0WhcGHbCiajmluQ4Stz1spVK.update({ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡆ࡜࠭ࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࠫᐖ"):xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠲࠯࠲ࠪᐗ")})
		RYA0WhcGHbCiajmluQ4Stz1spVK.update({weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᐘ"):erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪᐙ")})
		F148a7xNcp9C = {lCT8hfYUBX4OQMmL(u"ࠨࡱࡸࡸࡵࡻࡴࠨᐚ"):xm6jK1ZMuWq5(u"ࠩ࡫ࡸࡲࡲࠧᐛ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡹࡷࡲࠧᐜ"):ZD5n0eJivzWOMxY98dgrumkwRG}
		F148a7xNcp9C = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(F148a7xNcp9C)
		F148a7xNcp9C = iDbrpLzOJXF1kcg6AqtB0devCaUl(F148a7xNcp9C)
		XXup0CJWslMOqymaKthfb84 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࠹ࡧ࠺࠴࠻࠼࠺࠭ࡢࡤ࠼࠼࠲࠺࠱ࡥ࠴࠰࠼࠼࠶ࡤ࠮࠸࠵࠹ࡧ࠾࠴࠷࠷࠵࠹࠸࠷࠭࠱࠲࠰࠵ࡲ࡯ࡣ࠵ࡦࡨࡰࡱ࡭ࡣࡣࡴ࠱࡮ࡦࡴࡥࡸࡣࡼ࠲ࡷ࡫ࡰ࡭࡫ࡷ࠲ࡩ࡫ࡶ࠰ࡨࡨࡸࡨ࡮ࠧᐝ")
		OFH84dcLtak31SUEuy = zzJ1qB8RYw7jALnEKoWs(vWNRusF46D7Mi8GpZ(u"ࠬࡖࡏࡔࡖࠪᐞ"),XXup0CJWslMOqymaKthfb84,F148a7xNcp9C,RYA0WhcGHbCiajmluQ4Stz1spVK,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	else:
		scraperserver,XXup0CJWslMOqymaKthfb84 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		OFH84dcLtak31SUEuy = D8JlSY7NibwpLWxPXAfFgQsd()
		OFH84dcLtak31SUEuy.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		update = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if not OFH84dcLtak31SUEuy.content or dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡶࡦࡴ࡬ࡪࡾ࠴ࡨࡵ࡯࡯ࡃࡷ࡫ࡤࡪࡴࡨࡧࡹࡃࠧᐟ") in ZD5n0eJivzWOMxY98dgrumkwRG: OFH84dcLtak31SUEuy.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	OFH84dcLtak31SUEuy.scrapernumber = str(uMefvj4B7ELWokPxSiOzcFTVbU)
	scraperserver = scraperserver+xm6jK1ZMuWq5(u"ࠧࠡ࠼ࠣࠫᐠ")+str(uMefvj4B7ELWokPxSiOzcFTVbU)
	OFH84dcLtak31SUEuy.scraperserver = scraperserver
	OFH84dcLtak31SUEuy.scraperurl = XXup0CJWslMOqymaKthfb84
	if OFH84dcLtak31SUEuy.succeeded:
		if not TTuO14NzmB.scrapers_succeeded:
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(w8JC1y7Lp3(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪᐡ"),qqQZBeivhj72yLTn,L5jXH0fZ8TvsESR=rDG9dZoXRhCJcieUSF0KB(u"࠷࠳࠴ᝎ"))
			KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+xdSThjYnuHXAU6M(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᐢ")+scraperserver+xdSThjYnuHXAU6M(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᐣ")+xVwDZbA6EOjpgX0+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᐤ")+xLK3kz2aD5+lCT8hfYUBX4OQMmL(u"ࠬࠦ࡝ࠨᐥ"))
	else:
		if not TTuO14NzmB.scrapers_succeeded:
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(JHMxIE4fs1mvQtKW7R(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᐦ"),qqQZBeivhj72yLTn,L5jXH0fZ8TvsESR=weh7SGmuTgXOVRcMo1rlLq(u"࠸࠴࠵ᝏ"))
			KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+VhqD3zp7mUieI8sMQlETH(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫᐧ")+scraperserver+A6Sg45ChDR3BJLYfFH(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᐨ")+str(OFH84dcLtak31SUEuy.code)+Gj3rMP1Cb8wHdp49la0(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᐩ")+OFH84dcLtak31SUEuy.reason+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᐪ")+xVwDZbA6EOjpgX0+s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᐫ")+xLK3kz2aD5+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࠦ࡝ࠨᐬ"))
		if update:
			B3Bo0bMg8ynGe7p1H(zLkaD48V1CIdnhy,OO3HfuLko9eFmhnbvYV1tWRilxAcU,we7D2l4URB,[],uMefvj4B7ELWokPxSiOzcFTVbU)
	global Vl4z2BAMQUsNF,Go8veRxzq7VwukOEDZWbIYjPLH3
	Vl4z2BAMQUsNF[uMefvj4B7ELWokPxSiOzcFTVbU] = OFH84dcLtak31SUEuy.succeeded
	Go8veRxzq7VwukOEDZWbIYjPLH3[uMefvj4B7ELWokPxSiOzcFTVbU] = OFH84dcLtak31SUEuy
	return OFH84dcLtak31SUEuy
def B3Bo0bMg8ynGe7p1H(zLkaD48V1CIdnhy,OO3HfuLko9eFmhnbvYV1tWRilxAcU,we7D2l4URB,dt9pNYIoxm0F3QSJjUqWHflPOnueMw=[],VVyPUfhT0EFYkQ34sMHvmig59S=b02zsRFX8MweUniGfyPHEZcv7p5WK3):
	ieVOE5cfGUlAk4btLg7 = lCT8hfYUBX4OQMmL(u"࠷ᝐ")
	AeMNdnqUgHO1ow6smEfB4WR = jQv0du1iVxTgAXCM(u"࠼ᝑ")
	IC2yhvLYsHz5wVg6 = []
	A9AFbW8hgDR = [wTLFCOcM26fmYlW7U]*zLkaD48V1CIdnhy
	ttzJUksxlKfOhRdBcv4WC82GpX31ue = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,A6Sg45ChDR3BJLYfFH(u"࠭ࡤࡪࡥࡷࠫᐭ"),kPCxIUZb1V(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩᐮ"))
	for AenJf1H3vsaY0LdtTiGK9wOFmEpjM in list(ttzJUksxlKfOhRdBcv4WC82GpX31ue.keys()):
		if we7D2l4URB not in AenJf1H3vsaY0LdtTiGK9wOFmEpjM: continue
		g40I3ZXaeJ8qVywt,C1tvHSxV7NGm2iF8W = AenJf1H3vsaY0LdtTiGK9wOFmEpjM.split(JHMxIE4fs1mvQtKW7R(u"ࠨࡡࡢࠫᐯ"))
		A9AFbW8hgDR[int(C1tvHSxV7NGm2iF8W)] = ttzJUksxlKfOhRdBcv4WC82GpX31ue[AenJf1H3vsaY0LdtTiGK9wOFmEpjM]
	for aJQuONIydj in range(zLkaD48V1CIdnhy):
		if aJQuONIydj in TTuO14NzmB.BADSCRAPERS+dt9pNYIoxm0F3QSJjUqWHflPOnueMw: continue
		if aJQuONIydj==VVyPUfhT0EFYkQ34sMHvmig59S: A9AFbW8hgDR[aJQuONIydj] = A9AFbW8hgDR[aJQuONIydj]+JHMxIE4fs1mvQtKW7R(u"࠷ᝒ")
		if A9AFbW8hgDR[aJQuONIydj]<ieVOE5cfGUlAk4btLg7: IC2yhvLYsHz5wVg6 += [aJQuONIydj]*OO3HfuLko9eFmhnbvYV1tWRilxAcU[aJQuONIydj]
	if not IC2yhvLYsHz5wVg6:
		for aJQuONIydj in range(zLkaD48V1CIdnhy):
			A9AFbW8hgDR[aJQuONIydj] = lCT8hfYUBX4OQMmL(u"࠰ᝓ")
			if aJQuONIydj in TTuO14NzmB.BADSCRAPERS+dt9pNYIoxm0F3QSJjUqWHflPOnueMw: continue
			IC2yhvLYsHz5wVg6 += [aJQuONIydj]*OO3HfuLko9eFmhnbvYV1tWRilxAcU[aJQuONIydj]
	for aJQuONIydj in TTuO14NzmB.BADSCRAPERS: A9AFbW8hgDR[aJQuONIydj] = MFhbWia58mP3su0fk2d(u"࠺࠻࠼࠽᝔")
	oaYOG6vpXSe2sPfKmwr573c4 = []
	for aJQuONIydj in range(zLkaD48V1CIdnhy): oaYOG6vpXSe2sPfKmwr573c4.append(we7D2l4URB+vWNRusF46D7Mi8GpZ(u"ࠩࡢࡣࠬᐰ")+str(aJQuONIydj))
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,A6Sg45ChDR3BJLYfFH(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬᐱ"),oaYOG6vpXSe2sPfKmwr573c4,A9AFbW8hgDR,X72TknicLshwJO8*AeMNdnqUgHO1ow6smEfB4WR,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return IC2yhvLYsHz5wVg6
def ps1k8HfBVxbhQ4L2NESdzYFwJ(we7D2l4URB):
	FFxw3huXASEji8Yvc = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,A6Sg45ChDR3BJLYfFH(u"ࠫࡱ࡯ࡳࡵࠩᐲ"),w8JC1y7Lp3(u"ࠬࡈࡌࡐࡅࡎࡉࡉࡥࡗࡆࡄࡖࡍ࡙ࡋࡓࠨᐳ"))
	if we7D2l4URB in FFxw3huXASEji8Yvc: return
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,llkFwuCyhaP3sK76qO4T(u"࠭ࡂࡍࡑࡆࡏࡊࡊ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔࠩᐴ"),we7D2l4URB,y0yvdNOZkiKEg5RLMhoDVQAB9F2,pHC2Aj4kbc3KDN0aZWBey6QV)
	FFxw3huXASEji8Yvc = FFxw3huXASEji8Yvc+[we7D2l4URB]
	TbLGvkW8jF3sdlBaCP65SzmV4i = uj5sWQJSqg9XZYy4Nahz0d6erxl()
	XMiAvt4q9HhfwbPNsCnVk8o7RIW = TbLGvkW8jF3sdlBaCP65SzmV4i.split(A6Sg45ChDR3BJLYfFH(u"ࠧ࠭࠮ࠪᐵ"))[Tb7oymMnpflsSv3eu4Pz2]
	xxwBIFtsuXOJ5ki1 = {VhqD3zp7mUieI8sMQlETH(u"ࠨࡷࡶࡩࡷ࠭ᐶ"):wLpPS96U1IKRxFzjVtHZG,MFhbWia58mP3su0fk2d(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᐷ"):D1DBSuO0lLGRbcfCyY,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭ᐸ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠫ࡮ࡺࡥ࡮ࠩᐹ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠬࡼࡡ࡭ࡷࡨࠫᐺ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᐻ"):XMiAvt4q9HhfwbPNsCnVk8o7RIW,fmkZtbRj3ux(u"ࠧࡱࡣࡵࡥࡲࡹ࡟ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪᐼ"):gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠰࠱ࡆࡑࡕࡃࡌࡇࡇࡣ࡚࡙ࡅࡓࡕࠪᐽ"),MFhbWia58mP3su0fk2d(u"ࠩࡳࡥࡷࡧ࡭ࡴࠩᐾ"):FFxw3huXASEji8Yvc}
	VVjvcHKIUJN3WFCm = TTuO14NzmB.SITESURLS[MFhbWia58mP3su0fk2d(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐿ")][weh7SGmuTgXOVRcMo1rlLq(u"࠳࠴᝕")]
	vziHL4xVFSD81W7X9Noyrdjb = WTJA9qoLQXdPRIihy(pHC2Aj4kbc3KDN0aZWBey6QV,erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡕࡕࡓࡕࠩᑀ"),VVjvcHKIUJN3WFCm,xxwBIFtsuXOJ5ki1,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡇࡒࡏࡄࡍࡈࡈࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࡟ࡍࡋࡖࡘࡤ࡚ࡏࡠ࡙ࡈࡆࡈࡇࡃࡉࡇ࠰࠵ࡸࡺࠧᑁ"))
	return
def dbPKWOTuzeC9mIHJ(xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,TeuQd8DXNkc0zlYmKF2J=wUvcPrYDfISbZolAm83GKEqMyXkn5,Kw19luY7W2jGgsBa5n4hctLfFS=wUvcPrYDfISbZolAm83GKEqMyXkn5,dt9pNYIoxm0F3QSJjUqWHflPOnueMw=[]):
	we7D2l4URB = xVwDZbA6EOjpgX0.split(A6Sg45ChDR3BJLYfFH(u"࠭࠭ࠨᑂ"))[wTLFCOcM26fmYlW7U]
	zLkaD48V1CIdnhy = DpRJnas65uVcO0S17dYG(u"࠴࠶᝖")
	OO3HfuLko9eFmhnbvYV1tWRilxAcU = [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠶᝘"),rDG9dZoXRhCJcieUSF0KB(u"࠻᝙"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠶᝘"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),rDG9dZoXRhCJcieUSF0KB(u"࠻᝙"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵᝗"),A6Sg45ChDR3BJLYfFH(u"࠵࠱᝚")]
	BvtkTOiGml = B3Bo0bMg8ynGe7p1H(zLkaD48V1CIdnhy,OO3HfuLko9eFmhnbvYV1tWRilxAcU,we7D2l4URB)
	args = xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS
	global Vl4z2BAMQUsNF,Go8veRxzq7VwukOEDZWbIYjPLH3
	MspXSd8ujkcRoHWF6LAJ,Vl4z2BAMQUsNF,Go8veRxzq7VwukOEDZWbIYjPLH3 = [],[],[]
	def llnES2h9vQBX():
		if any(Vl4z2BAMQUsNF): return y0yvdNOZkiKEg5RLMhoDVQAB9F2
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	for aJQuONIydj in range(zLkaD48V1CIdnhy):
		Vl4z2BAMQUsNF.append(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		Go8veRxzq7VwukOEDZWbIYjPLH3.append(D8JlSY7NibwpLWxPXAfFgQsd())
		if aJQuONIydj in BvtkTOiGml:
			UiEgeP53aRrcW = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=llKWkJNhGv7tyQXPIE04qMeogf8iVr,args=(aJQuONIydj,zLkaD48V1CIdnhy,OO3HfuLko9eFmhnbvYV1tWRilxAcU,args))
			MspXSd8ujkcRoHWF6LAJ.append(UiEgeP53aRrcW)
	xxaHzT9pQj6SRDCGIfwydq(MspXSd8ujkcRoHWF6LAJ,bQGafNLXyFgsZP6ut(u"࠷࠲᝛"),UD4N8MjVTd,UD4N8MjVTd,llnES2h9vQBX)
	for aJQuONIydj in range(zLkaD48V1CIdnhy):
		if Vl4z2BAMQUsNF[aJQuONIydj]:
			for zYtMNiWJ8TU in MspXSd8ujkcRoHWF6LAJ:
				try: zYtMNiWJ8TU.daemon = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				except: pass
				try: zYtMNiWJ8TU.setDaemon(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
				except: pass
			TTuO14NzmB.scrapers_succeeded = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			return Go8veRxzq7VwukOEDZWbIYjPLH3[aJQuONIydj]
	return Go8veRxzq7VwukOEDZWbIYjPLH3[wTLFCOcM26fmYlW7U]
def KhrsqbGoiyLzXR3Et(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,showDialogs,xVwDZbA6EOjpgX0):
	if not ZtoUCFcjmabu or isinstance(ZtoUCFcjmabu,dict): xRVnhbcSF5v1NBQI = xm6jK1ZMuWq5(u"ࠧࡈࡇࡗࠫᑃ")
	else:
		xRVnhbcSF5v1NBQI = yRWQMHxZEz0(u"ࠨࡒࡒࡗ࡙࠭ᑄ")
		ZtoUCFcjmabu = Z6bUG0kDQuFqgzdAa1r(ZtoUCFcjmabu)
		gwij46SFoDVzlHPt,ZtoUCFcjmabu = ibEuGXOqxHp(ZtoUCFcjmabu)
	lGQxR39dqyUb1YFcCmjZN5EthrpJ = umVATL4QpG1RxtrvX7bNS2cYoB(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,y0yvdNOZkiKEg5RLMhoDVQAB9F2,showDialogs,xVwDZbA6EOjpgX0)
	rTAHV8ktdmWCDfxP = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
	rTAHV8ktdmWCDfxP = str(rTAHV8ktdmWCDfxP)
	return rTAHV8ktdmWCDfxP
def ljE2zF3GqBDrtWfi8yH(xLDEnp9WdA):
	Bx45zKPpfY2wWAkLvEu = xLDEnp9WdA.split(llkFwuCyhaP3sK76qO4T(u"ࠩࡿࢀࠬᑅ"))
	ZD5n0eJivzWOMxY98dgrumkwRG,TTBcDpHaIbsoP,MRxufqXZFLD1N8KszmhEniWAIk,mmxokSPVc6KgdpXQ1NRHvU = Bx45zKPpfY2wWAkLvEu[wTLFCOcM26fmYlW7U],b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,y0yvdNOZkiKEg5RLMhoDVQAB9F2
	for Og15JMhL8ArokEY2G in Bx45zKPpfY2wWAkLvEu:
		if vWNRusF46D7Mi8GpZ(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᑆ") in Og15JMhL8ArokEY2G: TTBcDpHaIbsoP = Og15JMhL8ArokEY2G[jQv0du1iVxTgAXCM(u"࠳࠴᝜"):]
		elif DpRJnas65uVcO0S17dYG(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᑇ") in Og15JMhL8ArokEY2G: MRxufqXZFLD1N8KszmhEniWAIk = Og15JMhL8ArokEY2G[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠼᝝"):]
		elif gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᑈ") in Og15JMhL8ArokEY2G: mmxokSPVc6KgdpXQ1NRHvU = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return ZD5n0eJivzWOMxY98dgrumkwRG,TTBcDpHaIbsoP,MRxufqXZFLD1N8KszmhEniWAIk,mmxokSPVc6KgdpXQ1NRHvU
def ztic3UPGmN5d0ElaWRokF(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,xLDEnp9WdA,PmbRIDkOvBwos0WtTdFKLaH6qX9rji,MXzlKevApNbjaHLyYqUdZG9fmIxiRW,AAynoEGF7LOa4KsvcUke,zQfGP7LOR8YrN04CwgaUvtpb9=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	FJnuScYqLt8EM4a0j5HxvA6o = TO3vi2rSZ0LRhKlwgG4qkYFIC(xLDEnp9WdA,s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡵࡳ࡮ࠪᑉ"))
	wpLgr9cfSKjUhlk6PHavRzMb = OOnvcPQy85HYA.getSetting(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᑊ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji)
	if FJnuScYqLt8EM4a0j5HxvA6o==wpLgr9cfSKjUhlk6PHavRzMb: OOnvcPQy85HYA.setSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᑋ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if wpLgr9cfSKjUhlk6PHavRzMb: qaLFXuDExl8w = xLDEnp9WdA.replace(FJnuScYqLt8EM4a0j5HxvA6o,wpLgr9cfSKjUhlk6PHavRzMb)
	else:
		qaLFXuDExl8w = xLDEnp9WdA
		wpLgr9cfSKjUhlk6PHavRzMb = FJnuScYqLt8EM4a0j5HxvA6o
	jPianuQJ6sLd4ReUANv8k = umVATL4QpG1RxtrvX7bNS2cYoB(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,qaLFXuDExl8w,wUvcPrYDfISbZolAm83GKEqMyXkn5,zQfGP7LOR8YrN04CwgaUvtpb9,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭ᑌ"))
	rTAHV8ktdmWCDfxP = jPianuQJ6sLd4ReUANv8k.content
	if wwMdFkWvcRYiXHB7yDrCqnKb98o:
		try: rTAHV8ktdmWCDfxP = rTAHV8ktdmWCDfxP.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᑍ"))
		except: pass
	if not jPianuQJ6sLd4ReUANv8k.succeeded or AAynoEGF7LOa4KsvcUke not in rTAHV8ktdmWCDfxP:
		MXzlKevApNbjaHLyYqUdZG9fmIxiRW = MXzlKevApNbjaHLyYqUdZG9fmIxiRW.replace(UKFZBQAVXHI5s17LyvuRpCY2,xdSThjYnuHXAU6M(u"ࠫ࠰࠭ᑎ"))
		ZD5n0eJivzWOMxY98dgrumkwRG = vWNRusF46D7Mi8GpZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪᑏ")+MXzlKevApNbjaHLyYqUdZG9fmIxiRW
		XubVRNO48BsjJASlmeKwdTCr = {A6Sg45ChDR3BJLYfFH(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᑐ"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
		toEMTSVjIO = umVATL4QpG1RxtrvX7bNS2cYoB(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫᑑ"))
		if toEMTSVjIO.succeeded:
			rTAHV8ktdmWCDfxP = toEMTSVjIO.content
			if wwMdFkWvcRYiXHB7yDrCqnKb98o:
				try: rTAHV8ktdmWCDfxP = rTAHV8ktdmWCDfxP.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᑒ"))
				except: pass
			ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᑓ"),rTAHV8ktdmWCDfxP,jj0dZrgiKb.DOTALL)
			GGp8UBqM4oyFvS1kx = [wpLgr9cfSKjUhlk6PHavRzMb]
			Gs29jcQwyCNX = [DpRJnas65uVcO0S17dYG(u"ࠪࡥࡵࡱࠧᑔ"),DpRJnas65uVcO0S17dYG(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᑕ"),it4DKnryZlx(u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭ᑖ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᑗ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩᑘ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡲ࡫ࡴࠬᑙ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡤࡸࡱࡧࡱࠨᑚ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡷ࡮ࡺࡥࡪࡰࡧ࡭ࡨ࡫ࡳࠨᑛ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡸࡻࡲ࠯࡮ࡼࠫᑜ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᑝ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡩ࡯ࡨࡲࡶࡲ࡫ࡲࠨᑞ"),rDG9dZoXRhCJcieUSF0KB(u"ࠧࡴ࡫ࡷࡩࡱ࡯࡫ࡦࠩᑟ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨ࡫ࡱࡷࡹࡧࡧࡳࡣࡰࠫᑠ"),fmkZtbRj3ux(u"ࠩࡶࡲࡦࡶࡣࡩࡣࡷࠫᑡ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ࡬ࡹࡺࡰ࠮ࡧࡴࡹ࡮ࡼࠧᑢ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࡫ࡧࡳࡦ࡮ࡳࡰࡺࡹࠧᑣ")]
			for Tor7SKmsCPZvL in ppAJI9kDbz5MXa76UEF:
				if any(value in Tor7SKmsCPZvL for value in Gs29jcQwyCNX): continue
				wpLgr9cfSKjUhlk6PHavRzMb = TO3vi2rSZ0LRhKlwgG4qkYFIC(Tor7SKmsCPZvL,JHMxIE4fs1mvQtKW7R(u"ࠬࡻࡲ࡭ࠩᑤ"))
				if wpLgr9cfSKjUhlk6PHavRzMb in GGp8UBqM4oyFvS1kx: continue
				if len(GGp8UBqM4oyFvS1kx)==s149dk8uh2p7oFzaLxZeI3Or(u"࠽᝞"):
					KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+A6Sg45ChDR3BJLYfFH(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ᑥ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᑦ")+FJnuScYqLt8EM4a0j5HxvA6o+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࠢࡠࠫᑧ"))
					OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᑨ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji,wUvcPrYDfISbZolAm83GKEqMyXkn5)
					break
				GGp8UBqM4oyFvS1kx.append(wpLgr9cfSKjUhlk6PHavRzMb)
				qaLFXuDExl8w = xLDEnp9WdA.replace(FJnuScYqLt8EM4a0j5HxvA6o,wpLgr9cfSKjUhlk6PHavRzMb)
				jPianuQJ6sLd4ReUANv8k = umVATL4QpG1RxtrvX7bNS2cYoB(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,qaLFXuDExl8w,wUvcPrYDfISbZolAm83GKEqMyXkn5,zQfGP7LOR8YrN04CwgaUvtpb9,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧᑩ"))
				rTAHV8ktdmWCDfxP = jPianuQJ6sLd4ReUANv8k.content
				if jPianuQJ6sLd4ReUANv8k.succeeded and AAynoEGF7LOa4KsvcUke in rTAHV8ktdmWCDfxP:
					KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+yRWQMHxZEz0(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫᑪ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji+rDG9dZoXRhCJcieUSF0KB(u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫᑫ")+wpLgr9cfSKjUhlk6PHavRzMb+vWNRusF46D7Mi8GpZ(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫᑬ")+FJnuScYqLt8EM4a0j5HxvA6o+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࠡ࡟ࠪᑭ"))
					OOnvcPQy85HYA.setSetting(fmkZtbRj3ux(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᑮ")+PmbRIDkOvBwos0WtTdFKLaH6qX9rji,wpLgr9cfSKjUhlk6PHavRzMb)
					break
	return wpLgr9cfSKjUhlk6PHavRzMb,qaLFXuDExl8w,jPianuQJ6sLd4ReUANv8k
def c3o9wjJyYsrzqx6kHVthmPOM4A8b(UWErGF2TqoQ):
	tdaWVrp5eqSw42U = {
	 dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᑯ")				:JHMxIE4fs1mvQtKW7R(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᑰ")
	,erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡦࡱ࡯ࡢ࡯ࠪᑱ")				:lCT8hfYUBX4OQMmL(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩᑲ")
	,JHMxIE4fs1mvQtKW7R(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᑳ")				:rDG9dZoXRhCJcieUSF0KB(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᑴ")
	,weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡣ࡮ࡻࡦࡳࠧᑵ")				:xm6jK1ZMuWq5(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᑶ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡥࡰࡽࡡ࡮ࡶࡸࡦࡪ࠭ᑷ")			:vvhR5ozeiJpANyl8fFO3GBw(u"๊ࠫ๎โฺࠢส็ํอๅࠡฬํ์อ࠭ᑸ")
	,xdSThjYnuHXAU6M(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᑹ")				:vvhR5ozeiJpANyl8fFO3GBw(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᑺ")
	,kPCxIUZb1V(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᑻ")				:kPCxIUZb1V(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᑼ")
	,kPCxIUZb1V(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᑽ")			:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭ᑾ")
	,xm6jK1ZMuWq5(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭ᑿ")				:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩᒀ")
	,jQv0du1iVxTgAXCM(u"࠭ࡡ࡭࡯ࡶࡸࡧࡧࠧᒁ")				:kPCxIUZb1V(u"ࠧๆ๊ๅ฽ࠥอไๆืฺฬฮ࠭ᒂ")
	,A6Sg45ChDR3BJLYfFH(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪᒃ")				:VhqD3zp7mUieI8sMQlETH(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨᒄ")
	,yRWQMHxZEz0(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨᒅ")			:gVpGcN7nxEWLri4DvyAZlU3BQM(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ᒆ")
	,fmkZtbRj3ux(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧᒇ")				:jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ᒈ")
	,fmkZtbRj3ux(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩᒉ")				:llkFwuCyhaP3sK76qO4T(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩᒊ")
	,Gj3rMP1Cb8wHdp49la0(u"ࠩࡤࡽࡱࡵ࡬ࠨᒋ")				:llkFwuCyhaP3sK76qO4T(u"้ࠪํู่ࠡลํ่ํ๊ࠧᒌ")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡧࡵ࡫ࡳࡣࠪᒍ")				:VhqD3zp7mUieI8sMQlETH(u"๋่ࠬใ฻ࠣฬ่ืวࠨᒎ")
	,MFhbWia58mP3su0fk2d(u"࠭ࡢࡳࡵࡷࡩ࡯࠭ᒏ")				:ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬᒐ")
	,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩᒑ")				:yRWQMHxZEz0(u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩᒒ")
	,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡧ࡮ࡳࡡ࠵ࡲࠪᒓ")				:A6Sg45ChDR3BJLYfFH(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิࠤอ๐ࠧᒔ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬᒕ")				:JHMxIE4fs1mvQtKW7R(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨᒖ")
	,MFhbWia58mP3su0fk2d(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩᒗ")				:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩᒘ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫᒙ")				:rDG9dZoXRhCJcieUSF0KB(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫᒚ")
	,JHMxIE4fs1mvQtKW7R(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪᒛ")			:xdSThjYnuHXAU6M(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪᒜ")
	,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨᒝ")				:MFhbWia58mP3su0fk2d(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᒞ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪᒟ")				:lCT8hfYUBX4OQMmL(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪᒠ")
	,bQGafNLXyFgsZP6ut(u"ࠪࡧ࡮ࡳࡡࡧࡴࡨࡩࠬᒡ")				:xdSThjYnuHXAU6M(u"๊ࠫ๎โฺࠢึ๎๊อࠠโำํࠫᒢ")
	,MFhbWia58mP3su0fk2d(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨᒣ")			:xdSThjYnuHXAU6M(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧᒤ")
	,yRWQMHxZEz0(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᒥ")				:it4DKnryZlx(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨᒦ")
	,lCT8hfYUBX4OQMmL(u"ࠩࡦ࡭ࡲࡧࡷࡣࡣࡶࠫᒧ")				:SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"้ࠪํู่ࠡีํ้ฬ่ࠦษีࠪᒨ")
	,erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᒩ")			:xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠧᒪ")
	,yRWQMHxZEz0(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᒫ")	:weh7SGmuTgXOVRcMo1rlLq(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢืฯิฯๆ์้ࠫᒬ")
	,fmkZtbRj3ux(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡨࡢࡵ࡫ࡸࡦ࡭ࡳࠨᒭ")	:vWNRusF46D7Mi8GpZ(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫᒮ")
	,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮࡮࡬ࡺࡪࡹࠧᒯ")	:ZiCLpR1Tc5vUlPXDWgmhM6j(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅษษืีࠬᒰ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ᒱ"):w8JC1y7Lp3(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧᒲ")
	,JHMxIE4fs1mvQtKW7R(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬᒳ")	:DpRJnas65uVcO0S17dYG(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪᒴ")
	,Gj3rMP1Cb8wHdp49la0(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧᒵ")	:D2PpKMeZFWrmfxTSs4L1tz(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧᒶ")
	,fmkZtbRj3ux(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ᒷ")				:xm6jK1ZMuWq5(u"๋ࠬส้ไไࠫᒸ")
	,lCT8hfYUBX4OQMmL(u"࠭ࡤࡳࡣࡰࡥࡨࡧࡦࡦࠩᒹ")			:ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤ่อแ๋้ࠪᒺ")
	,xdSThjYnuHXAU6M(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩᒻ")				:rDG9dZoXRhCJcieUSF0KB(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩᒼ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫᒽ")				:Gj3rMP1Cb8wHdp49la0(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬᒾ")
	,A6Sg45ChDR3BJLYfFH(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧᒿ")				:yRWQMHxZEz0(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩᓀ")
	,DpRJnas65uVcO0S17dYG(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩᓁ")				:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫᓂ")
	,llkFwuCyhaP3sK76qO4T(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫᓃ")				:MFhbWia58mP3su0fk2d(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭ᓄ")
	,w8JC1y7Lp3(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭ᓅ")				:SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨᓆ")
	,kPCxIUZb1V(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪᓇ")			:xdSThjYnuHXAU6M(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬᓈ")
	,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩᓉ")				:s149dk8uh2p7oFzaLxZeI3Or(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩᓊ")
	,erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪᓋ")				:vvhR5ozeiJpANyl8fFO3GBw(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫᓌ")
	,erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧᓍ")				:TNw1pBHb8CtSZe0EFxuJqI(u"࠭ๅ้ไ฼ࠤ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬᓎ")
	,fmkZtbRj3ux(u"ࠧࡦ࡮࡬ࡪࡻ࡯ࡤࡦࡱࠪᓏ")			:VhqD3zp7mUieI8sMQlETH(u"ࠨ็๋ๆ฾ࠦรๅ์ไࠤๆ๐ฯ๋๊ࠪᓐ")
	,xdSThjYnuHXAU6M(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪᓑ")				:SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"้ࠪํู่ࠡใหี่ฯࠧᓒ")
	,A6Sg45ChDR3BJLYfFH(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᓓ")				:xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ็ิๅࠩᓔ")
	,kPCxIUZb1V(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩᓕ")			:DpRJnas65uVcO0S17dYG(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬᓖ")
	,xm6jK1ZMuWq5(u"ࠨࡨࡤࡶࡪࡹ࡫ࡰࠩᓗ")				:llkFwuCyhaP3sK76qO4T(u"่ࠩ์็฿ࠠโษิื่๎ࠧᓘ")
	,llkFwuCyhaP3sK76qO4T(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬᓙ")				:dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭ᓚ")
	,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧᓛ")				:xm6jK1ZMuWq5(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩᓜ")
	,bQGafNLXyFgsZP6ut(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓝ")				:lCT8hfYUBX4OQMmL(u"ࠨ็ฯ่ิ࠭ᓞ")
	,it4DKnryZlx(u"ࠩࡩࡳࡸࡺࡡࠨᓟ")				:llkFwuCyhaP3sK76qO4T(u"้ࠪํู่ࠡใ๋ืฯอࠧᓠ")
	,fmkZtbRj3ux(u"ࠫ࡫ࡻ࡮ࡰࡰࡷࡺࠬᓡ")				:erqDsJmL3BQHuGtPkcf0X9(u"๋่ࠬใ฻ࠣๅ๋๎ๆࠡฬํๅ๏࠭ᓢ")
	,weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡦࡶࡵ࡫ࡥࡷࡺࡶࠨᓣ")				:weh7SGmuTgXOVRcMo1rlLq(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤฯ๐แ๋ࠩᓤ")
	,MFhbWia58mP3su0fk2d(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ᓥ")			:ZiCLpR1Tc5vUlPXDWgmhM6j(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬᓦ")
	,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪ࡫ࡴࡵࡤࠨᓧ")					:it4DKnryZlx(u"ࠫั๐ฯࠨᓨ")
	,w8JC1y7Lp3(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧᓩ")				:VhqD3zp7mUieI8sMQlETH(u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ᓪ")
	,Gj3rMP1Cb8wHdp49la0(u"ࠧࡩࡧ࡯ࡥࡱ࠭ᓫ")				:JHMxIE4fs1mvQtKW7R(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫᓬ")
	,DpRJnas65uVcO0S17dYG(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨᓭ")				:xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧᓮ")
	,Gj3rMP1Cb8wHdp49la0(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪᓯ")			:Gj3rMP1Cb8wHdp49la0(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧᓰ")
	,TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭ᓱ")		:A6Sg45ChDR3BJLYfFH(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬᓲ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠨ࡫ࡳࡸࡻ࠭ᓳ")					:fmkZtbRj3ux(u"ࠩࡌࡔ࡙࡜ࠧᓴ")
	,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ᓵ")			:kPCxIUZb1V(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨᓶ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪᓷ")			:bQGafNLXyFgsZP6ut(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪᓸ")
	,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬᓹ")			:s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧᓺ")
	,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬᓻ")			:MFhbWia58mP3su0fk2d(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭ᓼ")
	,bQGafNLXyFgsZP6ut(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ᓽ")				:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧᓾ")
	,yRWQMHxZEz0(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨᓿ")				:Gj3rMP1Cb8wHdp49la0(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫᔀ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࡭࡬ࡶࡲࡧ࡬࡬ࠩᔁ")				:lCT8hfYUBX4OQMmL(u"่ࠩ์็฿ࠠไำ่ห้้ࠧᔂ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡰࡦࡸ࡯ࡻࡣࠪᔃ")				:DpRJnas65uVcO0S17dYG(u"๊ࠫ๎โฺࠢ็หึ๎าศࠩᔄ")
	,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭ᔅ")				:jQv0du1iVxTgAXCM(u"࠭ๅๅใࠪᔆ")
	,bQGafNLXyFgsZP6ut(u"ࠧ࡭࡫ࡹࡩࠬᔇ")					:TNw1pBHb8CtSZe0EFxuJqI(u"ࠨไ้หฮ࠭ᔈ")
	,yRWQMHxZEz0(u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩᔉ")				:jnqzf9WihpUlxmcAEZ1vMLXNu(u"้้ࠪ็ࠧᔊ")
	,yRWQMHxZEz0(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬᔋ")				:erqDsJmL3BQHuGtPkcf0X9(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫᔌ")
	,kPCxIUZb1V(u"࠭࡭࠴ࡷࠪᔍ")					:weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡎ࠵ࡘࠫᔎ")
	,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪᔏ")				:ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬᔐ")
	,llkFwuCyhaP3sK76qO4T(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧᔑ")			:rDG9dZoXRhCJcieUSF0KB(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧᔒ")
	,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩᔓ")			:xm6jK1ZMuWq5(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫᔔ")
	,DpRJnas65uVcO0S17dYG(u"ࠧ࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱࠪᔕ")			:s149dk8uh2p7oFzaLxZeI3Or(u"ࠨ็๋ๆ฾ࠦๅศีสࠤๆ๐ฯ๋๊ࠪᔖ")
	,fmkZtbRj3ux(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᔗ")				:bQGafNLXyFgsZP6ut(u"้ࠪๆ่่ะࠩᔘ")
	,xdSThjYnuHXAU6M(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫᔙ")				:xm6jK1ZMuWq5(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧᔚ")
	,rDG9dZoXRhCJcieUSF0KB(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᔛ")				:it4DKnryZlx(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧᔜ")
	,weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡱ࡯ࡨࠬᔝ")					:llkFwuCyhaP3sK76qO4T(u"ࠩๅำ๏๋ࠧᔞ")
	,A6Sg45ChDR3BJLYfFH(u"ࠪࡴࡦࡴࡥࡵࠩᔟ")				:jnqzf9WihpUlxmcAEZ1vMLXNu(u"๊ࠫ๎โฺࠢหห๋๐สࠨᔠ")
	,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫᔡ")			:fmkZtbRj3ux(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩᔢ")
	,bQGafNLXyFgsZP6ut(u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᔣ")			:gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ᔤ")
	,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡴࡪ࡮ࡲ࡭ࠨᔥ")				:w8JC1y7Lp3(u"้ࠪํู่ࠡๅํ์ࠥ็๊ๅ็ࠪᔦ")
	,D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥࠨᔧ")			:A6Sg45ChDR3BJLYfFH(u"๋่ࠬใ฻ࠣื๏ื๊ิࠢอห๏๋ࠧᔨ")
	,VhqD3zp7mUieI8sMQlETH(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩᔩ")			:DpRJnas65uVcO0S17dYG(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫᔪ")
	,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᔫ")				:yRWQMHxZEz0(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫᔬ")
	,DpRJnas65uVcO0S17dYG(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠷࠭ᔭ")			:xm6jK1ZMuWq5(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํࠦ࠲ࠨᔮ")
	,vWNRusF46D7Mi8GpZ(u"ࠬࡹࡨࡢࡪ࡬ࡨࡳ࡫ࡷࡴࠩᔯ")			:jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧᔰ")
	,it4DKnryZlx(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧࠪᔱ")			:lCT8hfYUBX4OQMmL(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪᔲ")
	,yRWQMHxZEz0(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧ࡬ࡣࡷࡰࡷࠬᔳ")		:A6Sg45ChDR3BJLYfFH(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥอไษ๊่ࠫᔴ")
	,vWNRusF46D7Mi8GpZ(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢࡷࡧ࡭ࡴࡹࠧᔵ")		:gVpGcN7nxEWLri4DvyAZlU3BQM(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧᔶ")
	,xdSThjYnuHXAU6M(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪᔷ")	:MFhbWia58mP3su0fk2d(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧᔸ")
	,kPCxIUZb1V(u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨᔹ")				:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫᔺ")
	,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬᔻ")				:weh7SGmuTgXOVRcMo1rlLq(u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫᔼ")
	,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡹࡨࡰࡱࡩࡲࡪࡺࠧᔽ")				:weh7SGmuTgXOVRcMo1rlLq(u"࠭ๅ้ไ฼ࠤู๎แ่ࠡอࠫᔾ")
	,A6Sg45ChDR3BJLYfFH(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᔿ")				:jQv0du1iVxTgAXCM(u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧᕀ")
	,MFhbWia58mP3su0fk2d(u"ࠩࡷ࡭ࡰࡧࡡࡵࠩᕁ")				:jQv0du1iVxTgAXCM(u"้ࠪํู่ࠡฬๆหฯ࠭ᕂ")
	,lCT8hfYUBX4OQMmL(u"ࠫࡹࡼࡦࡶࡰࠪᕃ")				:vWNRusF46D7Mi8GpZ(u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬᕄ")
	,DpRJnas65uVcO0S17dYG(u"࠭ࡶࡢࡴࡥࡳࡳ࠭ᕅ")				:fmkZtbRj3ux(u"ࠧๆ๊ๅ฽ࠥ็วาส๋๊ࠬᕆ")
	,bQGafNLXyFgsZP6ut(u"ࠨࡸ࡬ࡨࡪࡵࠧᕇ")				:erqDsJmL3BQHuGtPkcf0X9(u"ࠩไ๎ิ๐่ࠨᕈ")
	,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡺ࡮ࡪࡥࡰࡰࡶࡥࡪࡳࠧᕉ")			:s149dk8uh2p7oFzaLxZeI3Or(u"๊ࠫ๎โฺࠢไ๎ิ๐่่ࠡึหห๋ࠧᕊ")
	,llkFwuCyhaP3sK76qO4T(u"ࠬࡽࡥࡤ࡫ࡰࡥ࠶࠭ᕋ")				:erqDsJmL3BQHuGtPkcf0X9(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠥ࠷ࠧᕌ")
	,VhqD3zp7mUieI8sMQlETH(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠲ࠨᕍ")				:kPCxIUZb1V(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠳ࠩᕎ")
	,MFhbWia58mP3su0fk2d(u"ࠩࡼࡥࡶࡵࡴࠨᕏ")				:gVpGcN7nxEWLri4DvyAZlU3BQM(u"้ࠪํู่ࠡ์สๆํะࠧᕐ")
	,DpRJnas65uVcO0S17dYG(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᕑ")				:lCT8hfYUBX4OQMmL(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪᕒ")
	,rDG9dZoXRhCJcieUSF0KB(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩᕓ")		:yRWQMHxZEz0(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫᕔ")
	,MFhbWia58mP3su0fk2d(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᕕ")	:D2PpKMeZFWrmfxTSs4L1tz(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ᕖ")
	,llkFwuCyhaP3sK76qO4T(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠫᕗ")		:weh7SGmuTgXOVRcMo1rlLq(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫᕘ")
	,w8JC1y7Lp3(u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᕙ")			:pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ๅ้ษๅ฽๋ࠥๆࠡ์๋ฮ๏๎ศࠨᕚ")
	}
	GZT81SYgEpxV = UWErGF2TqoQ.lower()
	for key in list(tdaWVrp5eqSw42U.keys()):
		o2tT0DhLFNre5aKQOR3vmSk8 = key.lower()
		if GZT81SYgEpxV==o2tT0DhLFNre5aKQOR3vmSk8:
			UWErGF2TqoQ = tdaWVrp5eqSw42U[key]
			break
	return UWErGF2TqoQ
def ik374RHsnw0uAgmLBvGSecIPUo8(WsrAOIk8pgjEd3Tw4Noi5fQ,hhePWQiCMDRBgL8xK64l5ZJcNtHdva=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	TTuO14NzmB.wvS5ocTIsy6n0dHiENWf2zUrQ7BjD = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if not hhePWQiCMDRBgL8xK64l5ZJcNtHdva and WsrAOIk8pgjEd3Tw4Noi5fQ: hhePWQiCMDRBgL8xK64l5ZJcNtHdva = llkFwuCyhaP3sK76qO4T(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨᕛ")
	OOnvcPQy85HYA.setSetting(s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᕜ"),hhePWQiCMDRBgL8xK64l5ZJcNtHdva)
	return
def vvLTYxVfrbDza(xLDEnp9WdA,g5WLQpVjsKbE9Y=VhqD3zp7mUieI8sMQlETH(u"ࠩ࠽࠳ࠬᕝ")):
	return _KjVuG6Zwds9zQeWnhlyk4pMRm2v(xLDEnp9WdA,g5WLQpVjsKbE9Y)
def EY9icnhZd2Plaf3VkmUSsH(u51lmKTqrnD4Spx):
	if u51lmKTqrnD4Spx in [wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪ࠴ࠬᕞ"),wTLFCOcM26fmYlW7U]: return wUvcPrYDfISbZolAm83GKEqMyXkn5
	u51lmKTqrnD4Spx = int(u51lmKTqrnD4Spx)
	MaTYioHSu6XhmEjwelVD85tKgZyP = u51lmKTqrnD4Spx^sBTeylAtiQXpFW9wjM5C1m
	OeylYHi4w12BSIVjKrJg9d3mNsz = u51lmKTqrnD4Spx^d2priEnu57KztRsm8wCHZ
	VtGfrqbRudK = u51lmKTqrnD4Spx^D0tF2C71Kej5zrAgB6uMJZsI
	Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = str(MaTYioHSu6XhmEjwelVD85tKgZyP)+str(OeylYHi4w12BSIVjKrJg9d3mNsz)+str(VtGfrqbRudK)
	return Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS
def eKJAcasGCxhY6vNl(u51lmKTqrnD4Spx):
	if u51lmKTqrnD4Spx in [wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠫ࠵࠭ᕟ"),wTLFCOcM26fmYlW7U]: return wUvcPrYDfISbZolAm83GKEqMyXkn5
	u51lmKTqrnD4Spx = str(u51lmKTqrnD4Spx)
	Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if len(u51lmKTqrnD4Spx)==JHMxIE4fs1mvQtKW7R(u"࠶࠻᝟"):
		MaTYioHSu6XhmEjwelVD85tKgZyP,OeylYHi4w12BSIVjKrJg9d3mNsz,VtGfrqbRudK = u51lmKTqrnD4Spx[wTLFCOcM26fmYlW7U:R9RNUT6WAPEYjHqtIokxuXs],u51lmKTqrnD4Spx[R9RNUT6WAPEYjHqtIokxuXs:jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠿ᝠ")],u51lmKTqrnD4Spx[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠿ᝠ"):]
		MaTYioHSu6XhmEjwelVD85tKgZyP = int(MaTYioHSu6XhmEjwelVD85tKgZyP)^D0tF2C71Kej5zrAgB6uMJZsI
		OeylYHi4w12BSIVjKrJg9d3mNsz = int(OeylYHi4w12BSIVjKrJg9d3mNsz)^d2priEnu57KztRsm8wCHZ
		VtGfrqbRudK = int(VtGfrqbRudK)^sBTeylAtiQXpFW9wjM5C1m
		if MaTYioHSu6XhmEjwelVD85tKgZyP==OeylYHi4w12BSIVjKrJg9d3mNsz==VtGfrqbRudK: Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = str(MaTYioHSu6XhmEjwelVD85tKgZyP*fmkZtbRj3ux(u"࠶࠱ᝡ"))
	return Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS
def tTQjzDHVo9NBasmRb(u51lmKTqrnD4Spx,n2WHFJ6xidUGkw3Ktsmh9b54T=fmkZtbRj3ux(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧᕠ")):
	if u51lmKTqrnD4Spx==wUvcPrYDfISbZolAm83GKEqMyXkn5: return wUvcPrYDfISbZolAm83GKEqMyXkn5
	u51lmKTqrnD4Spx = int(u51lmKTqrnD4Spx)+int(n2WHFJ6xidUGkw3Ktsmh9b54T)
	MaTYioHSu6XhmEjwelVD85tKgZyP = u51lmKTqrnD4Spx^sBTeylAtiQXpFW9wjM5C1m
	OeylYHi4w12BSIVjKrJg9d3mNsz = u51lmKTqrnD4Spx^d2priEnu57KztRsm8wCHZ
	VtGfrqbRudK = u51lmKTqrnD4Spx^D0tF2C71Kej5zrAgB6uMJZsI
	Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = str(MaTYioHSu6XhmEjwelVD85tKgZyP)+str(OeylYHi4w12BSIVjKrJg9d3mNsz)+str(VtGfrqbRudK)
	return Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS
def jExXPonbZHfKa65syL8v47(u51lmKTqrnD4Spx,n2WHFJ6xidUGkw3Ktsmh9b54T=TNw1pBHb8CtSZe0EFxuJqI(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᕡ")):
	if u51lmKTqrnD4Spx==wUvcPrYDfISbZolAm83GKEqMyXkn5: return wUvcPrYDfISbZolAm83GKEqMyXkn5
	u51lmKTqrnD4Spx = str(u51lmKTqrnD4Spx)
	YakLyiA3MO9dZCjwP7fxE2 = int(len(u51lmKTqrnD4Spx)/MMRBkhnWVJCQwU)
	MaTYioHSu6XhmEjwelVD85tKgZyP = int(u51lmKTqrnD4Spx[wTLFCOcM26fmYlW7U:YakLyiA3MO9dZCjwP7fxE2])^sBTeylAtiQXpFW9wjM5C1m
	OeylYHi4w12BSIVjKrJg9d3mNsz = int(u51lmKTqrnD4Spx[YakLyiA3MO9dZCjwP7fxE2:Tb7oymMnpflsSv3eu4Pz2*YakLyiA3MO9dZCjwP7fxE2])^d2priEnu57KztRsm8wCHZ
	VtGfrqbRudK = int(u51lmKTqrnD4Spx[Tb7oymMnpflsSv3eu4Pz2*YakLyiA3MO9dZCjwP7fxE2:MMRBkhnWVJCQwU*YakLyiA3MO9dZCjwP7fxE2])^D0tF2C71Kej5zrAgB6uMJZsI
	Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if MaTYioHSu6XhmEjwelVD85tKgZyP==OeylYHi4w12BSIVjKrJg9d3mNsz==VtGfrqbRudK: Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS = str(int(MaTYioHSu6XhmEjwelVD85tKgZyP)-int(n2WHFJ6xidUGkw3Ktsmh9b54T))
	return Y2vCdTzbVQPqLaXpE9FJoDB68g1ZS
def dXnTSyEAseij(QyYnhC05DJzdMWP8powG72Fgu):
	bKQSnyr9XEHGWavVe63ogi7xzF = TTuO14NzmB.SITESURLS[llkFwuCyhaP3sK76qO4T(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᕢ")][w8JC1y7Lp3(u"࠹ᝢ")]
	T59TxJYB71wGENXqF0D = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫᕣ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡶ࡯࡮ࡴࡳࠨᕤ"),kPCxIUZb1V(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫᕥ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠼࠸࠰ࡱࠩᕦ"),JHMxIE4fs1mvQtKW7R(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧᕧ"))
	jjI50qY1XbfB6MREANZzPy,IIferzFdU3bLRH6t9jc4nPoTGykV7 = xDXC5AF31hBZ2gRGJafuK6zENQMO(T59TxJYB71wGENXqF0D)
	jjI50qY1XbfB6MREANZzPy = tTQjzDHVo9NBasmRb(jjI50qY1XbfB6MREANZzPy,w8JC1y7Lp3(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᕨ"))
	DlgCYWndJ6mVuBv0PwHL5N = {rDG9dZoXRhCJcieUSF0KB(u"ࠧࡪࡦࡶࠫᕩ"):kPCxIUZb1V(u"ࠨࡆࡌࡅࡑࡕࡇࠨᕪ"),lCT8hfYUBX4OQMmL(u"ࠩࡸࡷࡷ࠭ᕫ"):TTuO14NzmB.AV_CLIENT_IDS,kPCxIUZb1V(u"ࠪࡺࡪࡸࠧᕬ"):D1DBSuO0lLGRbcfCyY,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡸࡩࡲࠨᕭ"):QyYnhC05DJzdMWP8powG72Fgu,it4DKnryZlx(u"ࠬࡹࡩࡻࠩᕮ"):jjI50qY1XbfB6MREANZzPy}
	QjHuS569ck = {vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᕯ"):weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ᕰ")}
	TvQiSLz4d3 = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,DpRJnas65uVcO0S17dYG(u"ࠨࡒࡒࡗ࡙࠭ᕱ"),bKQSnyr9XEHGWavVe63ogi7xzF,DlgCYWndJ6mVuBv0PwHL5N,QjHuS569ck,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪᕲ"))
	Ez07uxH4d1VBtS9ApTnY = TvQiSLz4d3.content
	try:
		if not Ez07uxH4d1VBtS9ApTnY: H5Z6PUk1uA9lOx0
		JlrtHg1RLj3BFze5Tu6UWNVvnXED = dm7KA8MukvxF3iH9CW2ZNc(Gj3rMP1Cb8wHdp49la0(u"ࠪࡨ࡮ࡩࡴࠨᕳ"),Ez07uxH4d1VBtS9ApTnY)
		XfgWJrvLRTojpxOH01SzUtIGNsA = JlrtHg1RLj3BFze5Tu6UWNVvnXED[xm6jK1ZMuWq5(u"ࠫࡲࡹࡧࠨᕴ")]
		h8XRIQ6uqtceiEBs7j = JlrtHg1RLj3BFze5Tu6UWNVvnXED[weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡹࡥࡤࠩᕵ")]
		nU8IXGVYKPNToWe = JlrtHg1RLj3BFze5Tu6UWNVvnXED[weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡳࡵࡲࠪᕶ")]
		h8XRIQ6uqtceiEBs7j = int(jExXPonbZHfKa65syL8v47(h8XRIQ6uqtceiEBs7j,kPCxIUZb1V(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᕷ")))
		nU8IXGVYKPNToWe = int(jExXPonbZHfKa65syL8v47(nU8IXGVYKPNToWe,TNw1pBHb8CtSZe0EFxuJqI(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᕸ")))
		for p3GPbLCqzr9Tj in range(h8XRIQ6uqtceiEBs7j,wTLFCOcM26fmYlW7U,-nU8IXGVYKPNToWe):
			if not eval(xdSThjYnuHXAU6M(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧᕹ"),{rDG9dZoXRhCJcieUSF0KB(u"ࠪࡼࡧࡳࡣࠨᕺ"):te28VJiPB7RXcm6brMUQyKAC3Z}): H5Z6PUk1uA9lOx0
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(fmkZtbRj3ux(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪᕻ"),str(p3GPbLCqzr9Tj)+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࠦࠠฬษ้๎ฮ࠭ᕼ"),L5jXH0fZ8TvsESR=DpRJnas65uVcO0S17dYG(u"࠳࠳࠴ᝣ")*nU8IXGVYKPNToWe)
			te28VJiPB7RXcm6brMUQyKAC3Z.sleep(rDG9dZoXRhCJcieUSF0KB(u"࠴࠴࠵࠶ᝤ")*nU8IXGVYKPNToWe)
		if eval(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫᕽ"),{w8JC1y7Lp3(u"ࠧࡹࡤࡰࡧࠬᕾ"):te28VJiPB7RXcm6brMUQyKAC3Z}):
			XfgWJrvLRTojpxOH01SzUtIGNsA = XfgWJrvLRTojpxOH01SzUtIGNsA.replace(QWLr8ABjev,kPCxIUZb1V(u"ࠨ࡞࡟ࡲࠬᕿ")).replace(o46hdHaXLqyFwzD,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࡟ࡠࡷ࠭ᖀ"))
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠪาึ๎ฬࠨᖁ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,XfgWJrvLRTojpxOH01SzUtIGNsA)
		H5Z6PUk1uA9lOx0
	except: exec(Gj3rMP1Cb8wHdp49la0(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫᖂ"),{gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡾࡢ࡮ࡥࠪᖃ"):te28VJiPB7RXcm6brMUQyKAC3Z})
	return
def iiGQEx4rS5vJM2te0F3Cl():
	exec(VhqD3zp7mUieI8sMQlETH(u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫᖄ"),{VhqD3zp7mUieI8sMQlETH(u"ࠧࡹࡤࡰࡧ࡬ࡻࡩࠨᖅ"):llfAzdjaVLTbyZW7op9i,fmkZtbRj3ux(u"ࠨࡺࡥࡱࡨ࠭ᖆ"):te28VJiPB7RXcm6brMUQyKAC3Z})
	return
def xDXC5AF31hBZ2gRGJafuK6zENQMO(IIDzU1rRTl8s):
	RsyrhLGe8pKE6VOkUuWcMidDaYx,ygOUXKL0h28HawR = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(IIDzU1rRTl8s):
		try: RsyrhLGe8pKE6VOkUuWcMidDaYx = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.getsize(IIDzU1rRTl8s)
		except: pass
		if not RsyrhLGe8pKE6VOkUuWcMidDaYx:
			try: RsyrhLGe8pKE6VOkUuWcMidDaYx = b7i1PgC8Z4e5BFoHNd9E2UVvfc.stat(IIDzU1rRTl8s).st_size
			except: pass
		if not RsyrhLGe8pKE6VOkUuWcMidDaYx:
			try:
				from pathlib import Path as RRzWS2F8s5NYxIJV0jABMyXfmiw
				RsyrhLGe8pKE6VOkUuWcMidDaYx = RRzWS2F8s5NYxIJV0jABMyXfmiw(IIDzU1rRTl8s).stat().st_size
			except: pass
		if RsyrhLGe8pKE6VOkUuWcMidDaYx: ygOUXKL0h28HawR = UD4N8MjVTd
	return RsyrhLGe8pKE6VOkUuWcMidDaYx,ygOUXKL0h28HawR
def hVB0gciEDAjITnWCzOF8f4(tnB6PaG8g7ueMKfRLEhJic5lT,showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,tnB6PaG8g7ueMKfRLEhJic5lT+weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࡟ࡲࡡࡴࠧᖇ")+JegF7SlMawI03+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"๋้ࠪࠦสา์าࠤู๊อ้ࠡำหࠥอไๆๆไࠤฤࠧࠧᖈ")+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=it4DKnryZlx(u"࠵ᝥ"): return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	succeeded = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(tnB6PaG8g7ueMKfRLEhJic5lT):
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(tnB6PaG8g7ueMKfRLEhJic5lT.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq))
		except:
			try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(N54JFsrpW6ytMDdwHEGz)
			except Exception as CPhVH47v1X83tgA62wMWirdG:
				succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,str(CPhVH47v1X83tgA62wMWirdG))
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"ࠫๆฺไหࠢ฼้้๐ษࠡ็ึัࠥอไๆๆไࠫᖉ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᖊ"))
	return succeeded
def THqDmj0Frnf38wX7MkVZ1u9NaGi(JM6qnS2OfEuQ9d,bHi7NDva0uqVhw9glsABImZ5nKpX3,showDialogs):
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JM6qnS2OfEuQ9d+ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡜࡯࡞ࡱࠫᖋ")+JegF7SlMawI03+Gj3rMP1Cb8wHdp49la0(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࠬᖌ")+AAByQSLgaZwCsKnvc5eWNmY)
		if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	succeeded = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(JM6qnS2OfEuQ9d):
		for sVvmAZyqw0F5UT4t6BKJaprEQ,YuLnihrxOUWVsTztq3bRo8dk,dOCgFmA6NUr4ols7ufiGJ in b7i1PgC8Z4e5BFoHNd9E2UVvfc.walk(JM6qnS2OfEuQ9d,topdown=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
			for IIDzU1rRTl8s in dOCgFmA6NUr4ols7ufiGJ:
				akhbe8SYLMdfHmg3Dsl5A2KjEp = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(sVvmAZyqw0F5UT4t6BKJaprEQ,IIDzU1rRTl8s)
				try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(akhbe8SYLMdfHmg3Dsl5A2KjEp)
				except Exception as CPhVH47v1X83tgA62wMWirdG:
					succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
					if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,str(CPhVH47v1X83tgA62wMWirdG))
			if bHi7NDva0uqVhw9glsABImZ5nKpX3:
				for dir in YuLnihrxOUWVsTztq3bRo8dk:
					wwJXPTWIG25M3tVm8Dj4kYOlp1eA = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(sVvmAZyqw0F5UT4t6BKJaprEQ,dir)
					try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.rmdir(wwJXPTWIG25M3tVm8Dj4kYOlp1eA)
					except: pass
		if bHi7NDva0uqVhw9glsABImZ5nKpX3:
			try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.rmdir(sVvmAZyqw0F5UT4t6BKJaprEQ)
			except: pass
	if showDialogs:
		if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᖍ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫᖎ"))
	return succeeded
def WTJA9qoLQXdPRIihy(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0):
	ZD5n0eJivzWOMxY98dgrumkwRG,TTBcDpHaIbsoP,MRxufqXZFLD1N8KszmhEniWAIk,mmxokSPVc6KgdpXQ1NRHvU = ljE2zF3GqBDrtWfi8yH(xLDEnp9WdA)
	TRgsmSP7aip = xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡑࡆࡏࡎࡠࡆࡌࡗࡕࡇࡔࡄࡊࡈࡖࡤࡉࡁࡄࡊࡈࡈࠬᖏ") in xVwDZbA6EOjpgX0:
		neGOw8MuxH5gCSk4 = ZtoUCFcjmabu.get(yRWQMHxZEz0(u"ࠫࡻࡧ࡬ࡶࡧࠪᖐ"))
		if neGOw8MuxH5gCSk4:
			AEW4mQXHkSZ9LuM6ejlBistKf8CGFr = neGOw8MuxH5gCSk4.split(lCT8hfYUBX4OQMmL(u"ࠬࡥ࡟ࡔࡇࡓࡣࡤ࠭ᖑ"),D2PpKMeZFWrmfxTSs4L1tz(u"࠶ᝦ"))[D2PpKMeZFWrmfxTSs4L1tz(u"࠶ᝦ")]
			frFiJmvacZH1 = ZtoUCFcjmabu.copy()
			frFiJmvacZH1[vWNRusF46D7Mi8GpZ(u"࠭ࡶࡢ࡮ࡸࡩࠬᖒ")] = AEW4mQXHkSZ9LuM6ejlBistKf8CGFr
			TRgsmSP7aip = xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,frFiJmvacZH1,zQfGP7LOR8YrN04CwgaUvtpb9
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna<it4DKnryZlx(u"࠶ᝧ"):
		P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᖓ"),TRgsmSP7aip)
		BS6lGOtXcQTLiCZb8oVxrkvmuPKpna = -BS6lGOtXcQTLiCZb8oVxrkvmuPKpna
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna>Gj3rMP1Cb8wHdp49la0(u"࠰ᝨ"):
		rTAHV8ktdmWCDfxP = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,w8JC1y7Lp3(u"ࠨࡵࡷࡶࠬᖔ"),kPCxIUZb1V(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᖕ"),TRgsmSP7aip)
		if rTAHV8ktdmWCDfxP:
			xtowQRgA89lOqs4GKv(it4DKnryZlx(u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᖖ"),xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0,xRVnhbcSF5v1NBQI)
			return rTAHV8ktdmWCDfxP[R9RNUT6WAPEYjHqtIokxuXs:]
	rTAHV8ktdmWCDfxP = wBxAjV0NKzMhD2daHCU8TLRbu6lirO(xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0)
	rTAHV8ktdmWCDfxP = fy2aLFcjDnoxIzGi1gp7+rTAHV8ktdmWCDfxP
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,xdSThjYnuHXAU6M(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᖗ"),TRgsmSP7aip,rTAHV8ktdmWCDfxP,BS6lGOtXcQTLiCZb8oVxrkvmuPKpna)
	return rTAHV8ktdmWCDfxP[R9RNUT6WAPEYjHqtIokxuXs:]
def L9GcjSEeQJUZuCRrg(UdbRGoKhcDeI4lVfns5,EZSHGdl2LjrPts1FKTcBhRxp,GGXEwdoT3ej8JqF=wTLFCOcM26fmYlW7U):
	QuKAX2FZd8tcD4jbeiClRBTnW = OOnvcPQy85HYA.getSetting(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩᖘ"))
	if QuKAX2FZd8tcD4jbeiClRBTnW and kPCxIUZb1V(u"࠭࠭ࠨᖙ") not in QuKAX2FZd8tcD4jbeiClRBTnW: AeNt1wShKYUqvMWs7P4CjLgm9f5dcb,ve2p0NnZgUAOcXfsCMLQFzGilwyh = int(QuKAX2FZd8tcD4jbeiClRBTnW),y0yvdNOZkiKEg5RLMhoDVQAB9F2
	elif GGXEwdoT3ej8JqF: AeNt1wShKYUqvMWs7P4CjLgm9f5dcb,ve2p0NnZgUAOcXfsCMLQFzGilwyh = GGXEwdoT3ej8JqF,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	else: return []
	J6OrVEP1vmlipSu4F,L4gZslVY3qF7zR = [],wUvcPrYDfISbZolAm83GKEqMyXkn5
	BVfsgNcUXW1ov5eZ9l2GEFSqQJa,NZ4slV5Ae3LPXUC,KKTryRADP2N6M318JqI7zO,tjT7r5OFxkiBAb = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
	EZSHGdl2LjrPts1FKTcBhRxp = sorted(EZSHGdl2LjrPts1FKTcBhRxp,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: (key[UD4N8MjVTd],key[Tb7oymMnpflsSv3eu4Pz2]))
	for stream,ZZJOIp1uFh7CQ2BdiwNSRa86,oqF5GjVvYXpBd1l2xmWL0n3kU in EZSHGdl2LjrPts1FKTcBhRxp+[[wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U]]:
		if ZZJOIp1uFh7CQ2BdiwNSRa86==L4gZslVY3qF7zR:
			if oqF5GjVvYXpBd1l2xmWL0n3kU>AeNt1wShKYUqvMWs7P4CjLgm9f5dcb: NZ4slV5Ae3LPXUC,tjT7r5OFxkiBAb = stream,oqF5GjVvYXpBd1l2xmWL0n3kU
			elif not BVfsgNcUXW1ov5eZ9l2GEFSqQJa: BVfsgNcUXW1ov5eZ9l2GEFSqQJa,KKTryRADP2N6M318JqI7zO = stream,oqF5GjVvYXpBd1l2xmWL0n3kU
		else:
			if NZ4slV5Ae3LPXUC or BVfsgNcUXW1ov5eZ9l2GEFSqQJa:
				if BVfsgNcUXW1ov5eZ9l2GEFSqQJa: J6OrVEP1vmlipSu4F.append([BVfsgNcUXW1ov5eZ9l2GEFSqQJa,L4gZslVY3qF7zR,KKTryRADP2N6M318JqI7zO])
				elif NZ4slV5Ae3LPXUC: J6OrVEP1vmlipSu4F.append([NZ4slV5Ae3LPXUC,L4gZslVY3qF7zR,tjT7r5OFxkiBAb])
			if oqF5GjVvYXpBd1l2xmWL0n3kU>AeNt1wShKYUqvMWs7P4CjLgm9f5dcb:
				NZ4slV5Ae3LPXUC,tjT7r5OFxkiBAb = stream,oqF5GjVvYXpBd1l2xmWL0n3kU
				BVfsgNcUXW1ov5eZ9l2GEFSqQJa,KKTryRADP2N6M318JqI7zO = wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U
			else:
				NZ4slV5Ae3LPXUC,tjT7r5OFxkiBAb = wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U
				BVfsgNcUXW1ov5eZ9l2GEFSqQJa,KKTryRADP2N6M318JqI7zO = stream,oqF5GjVvYXpBd1l2xmWL0n3kU
		L4gZslVY3qF7zR = ZZJOIp1uFh7CQ2BdiwNSRa86
	if ve2p0NnZgUAOcXfsCMLQFzGilwyh:
		qEXz2CTH8cwhQePfG6Ydsg,pprMKh6zf9dnbTyo,GzsEAr6VN5yYb8eI0d2qRKmT = zip(*J6OrVEP1vmlipSu4F)
		aXnY51hEyUPILT7VwFprtb = [weh7SGmuTgXOVRcMo1rlLq(u"ࠧ࡮ࡲ࠷ࠫᖚ"),vWNRusF46D7Mi8GpZ(u"ࠨ࡯ࡳࡨࠬᖛ"),lCT8hfYUBX4OQMmL(u"ࠩࡷࡷࠬᖜ"),lCT8hfYUBX4OQMmL(u"ࠪࡱ࠸ࡻࠧᖝ")]
		for ZZJOIp1uFh7CQ2BdiwNSRa86 in aXnY51hEyUPILT7VwFprtb:
			if ZZJOIp1uFh7CQ2BdiwNSRa86 in pprMKh6zf9dnbTyo:
				index = pprMKh6zf9dnbTyo.index(ZZJOIp1uFh7CQ2BdiwNSRa86)
				J6OrVEP1vmlipSu4F = [[qEXz2CTH8cwhQePfG6Ydsg[index],pprMKh6zf9dnbTyo[index],GzsEAr6VN5yYb8eI0d2qRKmT[index]]]
				break
	return J6OrVEP1vmlipSu4F
def EJKdexG6Syr902gUkPlsoRNhM1H(GMPtN6d5F74XaDfUg):
	kMim89NBdyrx,Npkw0Xclm973TWMjD5 = [],b02zsRFX8MweUniGfyPHEZcv7p5WK3
	for g40I3ZXaeJ8qVywt in W1bszKqEjom:
		if g40I3ZXaeJ8qVywt==vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᖞ"): Npkw0Xclm973TWMjD5 = (jQv0du1iVxTgAXCM(u"ࠬࡲࡩ࡯࡭ࠪᖟ"),JegF7SlMawI03+xm6jK1ZMuWq5(u"࠭ๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้࠭ᖠ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"࠲࠷࠺ᝩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		elif g40I3ZXaeJ8qVywt==rDG9dZoXRhCJcieUSF0KB(u"ࠧࡎࡋ࡛ࡉࡉ࠭ᖡ"): Npkw0Xclm973TWMjD5 = (xm6jK1ZMuWq5(u"ࠨ࡮࡬ࡲࡰ࠭ᖢ"),JegF7SlMawI03+weh7SGmuTgXOVRcMo1rlLq(u"่ࠩ์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไࠨᖣ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳࠸࠻ᝪ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		elif g40I3ZXaeJ8qVywt==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪᖤ"): Npkw0Xclm973TWMjD5 = (xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡱ࡯࡮࡬ࠩᖥ"),JegF7SlMawI03+fmkZtbRj3ux(u"๋่ࠬศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࠬᖦ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠹࠼ᝫ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		if g40I3ZXaeJ8qVywt not in GMPtN6d5F74XaDfUg: continue
		if Npkw0Xclm973TWMjD5:
			kMim89NBdyrx.append(Npkw0Xclm973TWMjD5)
			Npkw0Xclm973TWMjD5 = b02zsRFX8MweUniGfyPHEZcv7p5WK3
		if g40I3ZXaeJ8qVywt not in [xm6jK1ZMuWq5(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧᖧ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡎࡋ࡛ࡉࡉ࠭ᖨ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡒࡘࡆࡑࡏࡃࠨᖩ")]: kMim89NBdyrx.append(g40I3ZXaeJ8qVywt)
	return kMim89NBdyrx
def QQEPUv1XWm5zMFaiDgVGqI(BqVAWxegrZS2jmvH5ipOcYDTl,args=[]):
	QjHuS569ck = {kPCxIUZb1V(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᖪ"):TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ᖫ")}
	oKBIc4EwzUbpasL2v1,Uug5aQJOcPR8dfAvjzBZqCWT2mKphF,oKEsPctNVdjASC = D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡻࡩࡢࡤ࠸࠸࠷࠹࠼ࡧࡧࡪࡥࡲࡾࡳࡵ࡫࡭ࠪᖬ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠺࠳ࡷࡥࡹ࠷ࡩ࡬ࡧ࡫࡭ࡲ࠻࠽ࡹࡸࡻࡦ࠵ࠫᖭ"),int(L5jXH0fZ8TvsESR.time())
	bjLmUyxtEYkvdP3IV7lGchf = oKBIc4EwzUbpasL2v1+wLpPS96U1IKRxFzjVtHZG+str(oKEsPctNVdjASC)+D1DBSuO0lLGRbcfCyY+Uug5aQJOcPR8dfAvjzBZqCWT2mKphF
	WxkZrDEM54oTl0gayus6BXmKz = vlnTfwNrdtCPUWhcu8Ip.md5(bjLmUyxtEYkvdP3IV7lGchf.encode(JHMxIE4fs1mvQtKW7R(u"࠭ࡵࡵࡨ࠻ࠫᖮ"))).hexdigest()[:llkFwuCyhaP3sK76qO4T(u"࠷࠷ᝬ")]
	DlgCYWndJ6mVuBv0PwHL5N = {jQv0du1iVxTgAXCM(u"ࠧ࡫ࡵࡦࡳࡩ࡫ࠧᖯ"):BqVAWxegrZS2jmvH5ipOcYDTl,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡣࡵ࡫ࡸ࠭ᖰ"):args,A6Sg45ChDR3BJLYfFH(u"ࠩࡸࡷࡪࡸࠧᖱ"):wLpPS96U1IKRxFzjVtHZG,llkFwuCyhaP3sK76qO4T(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᖲ"):D1DBSuO0lLGRbcfCyY,Gj3rMP1Cb8wHdp49la0(u"ࠫ࡮ࡪࡳࠨᖳ"):WxkZrDEM54oTl0gayus6BXmKz}
	TFf7ZXuct5OIl369dkiW10Sz2 = TTuO14NzmB.SITESURLS[llkFwuCyhaP3sK76qO4T(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᖴ")][TNw1pBHb8CtSZe0EFxuJqI(u"࠶࠶᝭")]
	TvQiSLz4d3 = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,MFhbWia58mP3su0fk2d(u"࠭ࡐࡐࡕࡗࠫᖵ"),TFf7ZXuct5OIl369dkiW10Sz2,DlgCYWndJ6mVuBv0PwHL5N,QjHuS569ck,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡉࡈ࡛ࡔࡆࡡࡍࡗ࠲࠷ࡳࡵࠩᖶ"))
	Ez07uxH4d1VBtS9ApTnY = TvQiSLz4d3.content
	return Ez07uxH4d1VBtS9ApTnY
def xxaHzT9pQj6SRDCGIfwydq(TY5f6r2utj,oXLnF3SsQAOkyJCm6lEgVYMaKZt,jji5MVYXAZ4mzQ8IEUqscnJxg,aaKSb3hqXcyu,xVHrgQWC94fdJiZT5UXqS3AG1Iuv):
	qLYSG1ZAkFe = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	SwiWtkajFq0vgEc8PsBzUmbJLXp = oXLnF3SsQAOkyJCm6lEgVYMaKZt
	for bwNKg5Izo0a in TY5f6r2utj:
		bwNKg5Izo0a.start()
		L5jXH0fZ8TvsESR.sleep(jji5MVYXAZ4mzQ8IEUqscnJxg)
		SwiWtkajFq0vgEc8PsBzUmbJLXp -= jji5MVYXAZ4mzQ8IEUqscnJxg
		qLYSG1ZAkFe = xVHrgQWC94fdJiZT5UXqS3AG1Iuv()
		if qLYSG1ZAkFe: break
	while not qLYSG1ZAkFe and SwiWtkajFq0vgEc8PsBzUmbJLXp>wTLFCOcM26fmYlW7U:
		L5jXH0fZ8TvsESR.sleep(aaKSb3hqXcyu)
		SwiWtkajFq0vgEc8PsBzUmbJLXp -= aaKSb3hqXcyu
		qLYSG1ZAkFe = xVHrgQWC94fdJiZT5UXqS3AG1Iuv()
	return qLYSG1ZAkFe
def NpzKdEgZiV4efDOCRqUwIWBTXA2(BBa14lhEZQLg6OXd2mMv=tRA4gT7GOoCaXJQ):
	QGHF7mbLDoifhPWTsBnEOUckVra = llkFwuCyhaP3sK76qO4T(u"࠷࠰࠳࠶ᝮ")
	BRHWw0E5Mi36TcA7shm = wTLFCOcM26fmYlW7U
	if not BRHWw0E5Mi36TcA7shm:
		try:
			import shutil as Ae9lV6Zkp15UHn
			BRHWw0E5Mi36TcA7shm = Ae9lV6Zkp15UHn.disk_usage(BBa14lhEZQLg6OXd2mMv).free
		except: pass
	if not BRHWw0E5Mi36TcA7shm and hasattr(b7i1PgC8Z4e5BFoHNd9E2UVvfc,yRWQMHxZEz0(u"ࠨࡵࡷࡥࡹࡼࡦࡴࠩᖷ")):
		try:
			pdlxikurQWsbBTLROVIKS2Y = b7i1PgC8Z4e5BFoHNd9E2UVvfc.statvfs(BBa14lhEZQLg6OXd2mMv)
			BRHWw0E5Mi36TcA7shm = pdlxikurQWsbBTLROVIKS2Y.f_frsize * pdlxikurQWsbBTLROVIKS2Y.f_bavail
		except: pass
	if not BRHWw0E5Mi36TcA7shm and hasattr(b7i1PgC8Z4e5BFoHNd9E2UVvfc,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡩࡷࡹࡧࡴࡷࡨࡶࠫᖸ")):
		try:
			pdlxikurQWsbBTLROVIKS2Y = b7i1PgC8Z4e5BFoHNd9E2UVvfc.fstatvfs(BBa14lhEZQLg6OXd2mMv)
			BRHWw0E5Mi36TcA7shm = pdlxikurQWsbBTLROVIKS2Y.f_frsize * pdlxikurQWsbBTLROVIKS2Y.f_bavail
		except: pass
	if not BRHWw0E5Mi36TcA7shm and Sph0cr2ZWK1atAUw5CTuxoe.platform == TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡻ࡮ࡴ࠳࠳ࠩᖹ"):
		try:
			import ctypes as cFJNL8zqjovQ0
			X7YFRgbUtrJaK4zQ2S0Ee = cFJNL8zqjovQ0.c_ulonglong(wTLFCOcM26fmYlW7U)
			cFJNL8zqjovQ0.windll.kernel32.GetDiskFreeSpaceExW(cFJNL8zqjovQ0.c_wchar_p(BBa14lhEZQLg6OXd2mMv),None,None,cFJNL8zqjovQ0.pointer(X7YFRgbUtrJaK4zQ2S0Ee))
			BRHWw0E5Mi36TcA7shm = X7YFRgbUtrJaK4zQ2S0Ee.value
		except: pass
	if not BRHWw0E5Mi36TcA7shm:
		try:
			YdVf5xkeLoMi2Ir = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(MFhbWia58mP3su0fk2d(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡥࡦࡕࡳࡥࡨ࡫ࠧᖺ"))
			ffmyVYK7qk96T2SIMaDtjr = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡢࡤࠬࠪࡂ࠾ࡡ࠴࡜ࡥ࠭ࠬࡃࠬᖻ"),YdVf5xkeLoMi2Ir,jj0dZrgiKb.DOTALL)
			if ffmyVYK7qk96T2SIMaDtjr:
				ffmyVYK7qk96T2SIMaDtjr = float(ffmyVYK7qk96T2SIMaDtjr[jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠰ᝯ")])
				if   rDG9dZoXRhCJcieUSF0KB(u"࠭ࡔࠨᖼ") in YdVf5xkeLoMi2Ir: BRHWw0E5Mi36TcA7shm = ffmyVYK7qk96T2SIMaDtjr*QGHF7mbLDoifhPWTsBnEOUckVra**R9RNUT6WAPEYjHqtIokxuXs
				elif D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡈࠩᖽ") in YdVf5xkeLoMi2Ir: BRHWw0E5Mi36TcA7shm = ffmyVYK7qk96T2SIMaDtjr*QGHF7mbLDoifhPWTsBnEOUckVra**MMRBkhnWVJCQwU
				elif jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡏࠪᖾ") in YdVf5xkeLoMi2Ir: BRHWw0E5Mi36TcA7shm = ffmyVYK7qk96T2SIMaDtjr*QGHF7mbLDoifhPWTsBnEOUckVra**Tb7oymMnpflsSv3eu4Pz2
				elif VhqD3zp7mUieI8sMQlETH(u"ࠩࡎࠫᖿ") in YdVf5xkeLoMi2Ir: BRHWw0E5Mi36TcA7shm = ffmyVYK7qk96T2SIMaDtjr*QGHF7mbLDoifhPWTsBnEOUckVra
				else: BRHWw0E5Mi36TcA7shm = ffmyVYK7qk96T2SIMaDtjr
		except: pass
	if not BRHWw0E5Mi36TcA7shm: BRHWw0E5Mi36TcA7shm = TNw1pBHb8CtSZe0EFxuJqI(u"࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺ᝰ")
	return int(BRHWw0E5Mi36TcA7shm)
def EfFgNHdZ5VMniPRwz7ys(RCBXDnhK3jHYUvJ):
	if RCBXDnhK3jHYUvJ:
		prIfMxPHQ42EjXKe5 = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,kPCxIUZb1V(u"ࠪࡰ࡮ࡹࡴࠨᗀ"),kPCxIUZb1V(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩᗁ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࡙ࠬࡉࡕࡇࡖࡣ࡚࡙ࡁࡈࡇࠪᗂ"))
		if prIfMxPHQ42EjXKe5: return prIfMxPHQ42EjXKe5
	COW137cpIhBMYTSiAR9s2Dlzw = {VhqD3zp7mUieI8sMQlETH(u"࠭ࡡࠨᗃ"):erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡢࠩᗄ")}
	url = TTuO14NzmB.SITESURLS[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᗅ")][UD4N8MjVTd]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡓࡓࡘ࡚ࠧᗆ"),url,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡍࡅࡕࡡࡖࡍ࡙ࡋࡓࡠࡗࡖࡅࡌࡋ࠭࠲ࡵࡷࠫᗇ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(llkFwuCyhaP3sK76qO4T(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫᗈ"),erqDsJmL3BQHuGtPkcf0X9(u"࡛ࠬࡓࡂࠩᗉ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(DpRJnas65uVcO0S17dYG(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡋࡪࡰࡪࡨࡴࡳࠧᗊ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡖࡍࠪᗋ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨᗌ"),w8JC1y7Lp3(u"ࠩࡘࡅࡊ࠭ᗍ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(bQGafNLXyFgsZP6ut(u"ࠪࡗࡦࡻࡤࡪࠢࡄࡶࡦࡨࡩࡢࠩᗎ"),xdSThjYnuHXAU6M(u"ࠫࡐ࡙ࡁࠨᗏ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡔ࡯ࡳࡶ࡫ࠤࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧᗐ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡎ࠯ࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫᗑ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(lCT8hfYUBX4OQMmL(u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨᗒ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨ࡙࠱ࡗࡦ࡮ࡡࡳࡣࠪᗓ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡢࡣࡤ࠭ᗔ"),lB8tuyg6sxkDVYAaS95K3GI)
	try: rWXsctJGYH9hqufTb = dm7KA8MukvxF3iH9CW2ZNc(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡰ࡮ࡹࡴࠨᗕ"),II64TLxj3mbqEyh9pHQ8oAv)
	except:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫᗖ"))
		return
	ZnhcmtjVae6blFx,DDREWaO5Yz9sQfL3Mmlt6,M6MsgiVAYX8E9hRHF = rWXsctJGYH9hqufTb
	I2LgSi3MyaB7qnDzAVdRrxfPmQeN,O4qdiz9EnHMcRhK3 = [],[]
	for g40I3ZXaeJ8qVywt,Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo,yYkI0JOPZvD in DDREWaO5Yz9sQfL3Mmlt6:
		if Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo.isdigit(): Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo = yRWQMHxZEz0(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᗗ") if int(Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo)>rDG9dZoXRhCJcieUSF0KB(u"࠷࠳᝱") else xdSThjYnuHXAU6M(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᗘ")
		if g40I3ZXaeJ8qVywt not in TTuO14NzmB.non_videos_actions:
			if   Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo==s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪᗙ"): I2LgSi3MyaB7qnDzAVdRrxfPmQeN.append(g40I3ZXaeJ8qVywt)
			elif Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo==erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪᗚ"): O4qdiz9EnHMcRhK3.append(g40I3ZXaeJ8qVywt)
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᗛ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨᗜ"),[rWXsctJGYH9hqufTb,I2LgSi3MyaB7qnDzAVdRrxfPmQeN,O4qdiz9EnHMcRhK3],d2priEnu57KztRsm8wCHZ)
	return rWXsctJGYH9hqufTb,I2LgSi3MyaB7qnDzAVdRrxfPmQeN,O4qdiz9EnHMcRhK3
def umVATL4QpG1RxtrvX7bNS2cYoB(BS6lGOtXcQTLiCZb8oVxrkvmuPKpna,xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW=wUvcPrYDfISbZolAm83GKEqMyXkn5,iqfCFuT6RgtD0mL=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if vWNRusF46D7Mi8GpZ(u"ࠫ࠿ࡀࠧᗝ") in xRVnhbcSF5v1NBQI: xRVnhbcSF5v1NBQI,KUOoYcT20iCLVgsw1ejzdkHp7XW = xRVnhbcSF5v1NBQI.split(erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡀ࠺ࠨᗞ"))
	else: xRVnhbcSF5v1NBQI,KUOoYcT20iCLVgsw1ejzdkHp7XW = xRVnhbcSF5v1NBQI,vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࠧᗟ")
	ZD5n0eJivzWOMxY98dgrumkwRG,TTBcDpHaIbsoP,MRxufqXZFLD1N8KszmhEniWAIk,mmxokSPVc6KgdpXQ1NRHvU = ljE2zF3GqBDrtWfi8yH(xLDEnp9WdA)
	hhKsYiBufpmrqL8JPTGc = zQfGP7LOR8YrN04CwgaUvtpb9.copy() if isinstance(zQfGP7LOR8YrN04CwgaUvtpb9,dict) else zQfGP7LOR8YrN04CwgaUvtpb9
	Og15JMhL8ArokEY2G = xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,ZtoUCFcjmabu,hhKsYiBufpmrqL8JPTGc,iizDKErMwWy3VSCgmbu9N4Rs5X
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna<wTLFCOcM26fmYlW7U:
		P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,fmkZtbRj3ux(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᗠ"),Og15JMhL8ArokEY2G)
		BS6lGOtXcQTLiCZb8oVxrkvmuPKpna = -BS6lGOtXcQTLiCZb8oVxrkvmuPKpna
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna>wTLFCOcM26fmYlW7U:
		lGQxR39dqyUb1YFcCmjZN5EthrpJ = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪᗡ"),it4DKnryZlx(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬᗢ"),Og15JMhL8ArokEY2G)
		if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
			xtowQRgA89lOqs4GKv(A6Sg45ChDR3BJLYfFH(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᗣ"),ZD5n0eJivzWOMxY98dgrumkwRG,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0,xRVnhbcSF5v1NBQI)
			return lGQxR39dqyUb1YFcCmjZN5EthrpJ
	if KUOoYcT20iCLVgsw1ejzdkHp7XW==D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘ࠭ᗤ"): lGQxR39dqyUb1YFcCmjZN5EthrpJ = dbPKWOTuzeC9mIHJ(xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0)
	else: lGQxR39dqyUb1YFcCmjZN5EthrpJ = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW,iqfCFuT6RgtD0mL)
	if lGQxR39dqyUb1YFcCmjZN5EthrpJ.succeeded:
		if Gj3rMP1Cb8wHdp49la0(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᗥ") in xVwDZbA6EOjpgX0: lGQxR39dqyUb1YFcCmjZN5EthrpJ.content = ri31J4lpFKX(lGQxR39dqyUb1YFcCmjZN5EthrpJ.content,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽ࡟ࡉࡖࡐࡐࡤ࡫࡮ࡤࡱࡧࡩࡷ࠭ᗦ"))
		if lGQxR39dqyUb1YFcCmjZN5EthrpJ.scrape: BS6lGOtXcQTLiCZb8oVxrkvmuPKpna = sBTeylAtiQXpFW9wjM5C1m
		if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna and lGQxR39dqyUb1YFcCmjZN5EthrpJ.content: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᗧ"),Og15JMhL8ArokEY2G,lGQxR39dqyUb1YFcCmjZN5EthrpJ,BS6lGOtXcQTLiCZb8oVxrkvmuPKpna)
	return lGQxR39dqyUb1YFcCmjZN5EthrpJ
def EEYNT5iI8x0oUKwSJ6hezvWcjumGX(xRVnhbcSF5v1NBQI,xLDEnp9WdA,data,headers,allow_redirects,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW,iqfCFuT6RgtD0mL):
	if data==wUvcPrYDfISbZolAm83GKEqMyXkn5: data = {}
	if headers==wUvcPrYDfISbZolAm83GKEqMyXkn5: headers = {}
	RRWF8udv4bYSrKckeV0wp = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if allow_redirects in [wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2] else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	aHJKVu5hYB9mPWc0Z8 = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if showDialogs in [wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2] else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	kkvhwDf1VFRPEiZGWt = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if OUTyY92pQDdFA6abiW in [wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2] else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	sstykmLoTM86e3whaUDJn0Z1WxqGl = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if iqfCFuT6RgtD0mL in [wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2] else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	FjUcS938pAH5sZ = data
	XubVRNO48BsjJASlmeKwdTCr = headers
	aHJKVu5hYB9mPWc0Z8 = aHJKVu5hYB9mPWc0Z8 if TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX==b02zsRFX8MweUniGfyPHEZcv7p5WK3 else TTuO14NzmB.ALLOW_SHOWDIALOGS_FIX
	kkvhwDf1VFRPEiZGWt = kkvhwDf1VFRPEiZGWt if TTuO14NzmB.ALLOW_DNS_FIX==b02zsRFX8MweUniGfyPHEZcv7p5WK3 else TTuO14NzmB.ALLOW_DNS_FIX
	sstykmLoTM86e3whaUDJn0Z1WxqGl = sstykmLoTM86e3whaUDJn0Z1WxqGl if TTuO14NzmB.ALLOW_PROXY_FIX==b02zsRFX8MweUniGfyPHEZcv7p5WK3 else TTuO14NzmB.ALLOW_PROXY_FIX
	if xVwDZbA6EOjpgX0==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭ᗨ"): XubVRNO48BsjJASlmeKwdTCr = {}
	else:
		XwAPrupdnjL = list(XubVRNO48BsjJASlmeKwdTCr.keys())
		if erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᗩ") not in XwAPrupdnjL: XubVRNO48BsjJASlmeKwdTCr[llkFwuCyhaP3sK76qO4T(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᗪ")] = D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࡭ࡺࡴࡱࠩᗫ")
		if it4DKnryZlx(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᗬ") not in XwAPrupdnjL: XubVRNO48BsjJASlmeKwdTCr[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᗭ")] = ZZIDf1A9vE0g86RMq7tpKUrzaij(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return xRVnhbcSF5v1NBQI,xLDEnp9WdA,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,kkvhwDf1VFRPEiZGWt,sstykmLoTM86e3whaUDJn0Z1WxqGl
def zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW=wUvcPrYDfISbZolAm83GKEqMyXkn5,iqfCFuT6RgtD0mL=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	cKWuEGxtTfrBDj7I5 = EEYNT5iI8x0oUKwSJ6hezvWcjumGX(xRVnhbcSF5v1NBQI,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,showDialogs,xVwDZbA6EOjpgX0,OUTyY92pQDdFA6abiW,iqfCFuT6RgtD0mL)
	xRVnhbcSF5v1NBQI,xLDEnp9WdA,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,kkvhwDf1VFRPEiZGWt,sstykmLoTM86e3whaUDJn0Z1WxqGl = cKWuEGxtTfrBDj7I5
	ZD5n0eJivzWOMxY98dgrumkwRG,TTBcDpHaIbsoP,MRxufqXZFLD1N8KszmhEniWAIk,mmxokSPVc6KgdpXQ1NRHvU = ljE2zF3GqBDrtWfi8yH(xLDEnp9WdA)
	FVPlZImAtH = OOnvcPQy85HYA.getSetting(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧᗮ"))
	z1VijOELhCfHTgvsI5y7tdDomxY2F = OOnvcPQy85HYA.getSetting(D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᗯ"))
	OBNsaX0kCqDZorFG4TePIjcldKQMRE = OOnvcPQy85HYA.getSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᗰ"))
	SQsX2bqBRric9Plx = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if any(value in xLDEnp9WdA for value in u2DKCR1va3) else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if rDG9dZoXRhCJcieUSF0KB(u"ࠪࠪࡺࡸ࡬࠾ࠩᗱ") in ZD5n0eJivzWOMxY98dgrumkwRG and SQsX2bqBRric9Plx: sscIgjPTGO4Dldaui8CkSny5qhWpA = ZD5n0eJivzWOMxY98dgrumkwRG.rsplit(vWNRusF46D7Mi8GpZ(u"ࠫࠫࡻࡲ࡭࠿ࠪᗲ"),UD4N8MjVTd)[UD4N8MjVTd]
	else: sscIgjPTGO4Dldaui8CkSny5qhWpA = wUvcPrYDfISbZolAm83GKEqMyXkn5
	MHj9t6QSXCiTW = TTuO14NzmB.SITESURLS[it4DKnryZlx(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᗳ")]
	DNhXwGLOTi1vICJtuW9MpsF78K = ZD5n0eJivzWOMxY98dgrumkwRG in MHj9t6QSXCiTW or sscIgjPTGO4Dldaui8CkSny5qhWpA in MHj9t6QSXCiTW
	TQ5Erp2YjxliKbDzfZPetoh0 = TTuO14NzmB.SITESURLS[jQv0du1iVxTgAXCM(u"࠭ࡒࡆࡒࡒࡗࠬᗴ")]
	qvuDBAgThsZo = ZD5n0eJivzWOMxY98dgrumkwRG in TQ5Erp2YjxliKbDzfZPetoh0 or sscIgjPTGO4Dldaui8CkSny5qhWpA in TQ5Erp2YjxliKbDzfZPetoh0
	agjMmhW3nUsXoywOp = DNhXwGLOTi1vICJtuW9MpsF78K or qvuDBAgThsZo
	Rc4bCjIvaZVifKFeMt8YxuhT6z = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	snTM4Nyp30UevWi = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	H8HQ7qBslgzpfVRAMNev = TTBcDpHaIbsoP==None and MRxufqXZFLD1N8KszmhEniWAIk==None and not SQsX2bqBRric9Plx
	if H8HQ7qBslgzpfVRAMNev and agjMmhW3nUsXoywOp:
		if DNhXwGLOTi1vICJtuW9MpsF78K:
			VCrZ8htDuoMxySipgcsFaA0RX = MHj9t6QSXCiTW.index(ZD5n0eJivzWOMxY98dgrumkwRG)
			ClIv35AqpZEV = TTuO14NzmB.SITESURLS[erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬᗵ")][VCrZ8htDuoMxySipgcsFaA0RX]
			NNme4WIbS1guBhDcMHU3r = TTuO14NzmB.SITESURLS[w8JC1y7Lp3(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠷࠭ᗶ")][VCrZ8htDuoMxySipgcsFaA0RX]
			xuJB1YqVApd6U8GanRtzZPLTy = TTuO14NzmB.SITESURLS[vWNRusF46D7Mi8GpZ(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧᗷ")][VCrZ8htDuoMxySipgcsFaA0RX]
			Z7Qikucg083SpAzqwlDYKCyF = TTuO14NzmB.api_python_actions[VCrZ8htDuoMxySipgcsFaA0RX]
			if Z7Qikucg083SpAzqwlDYKCyF==erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬᗸ"): kkvhwDf1VFRPEiZGWt,sstykmLoTM86e3whaUDJn0Z1WxqGl,snTM4Nyp30UevWi = Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA
			elif Z7Qikucg083SpAzqwlDYKCyF==s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬᗹ"): Rc4bCjIvaZVifKFeMt8YxuhT6z = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		elif qvuDBAgThsZo:
			VCrZ8htDuoMxySipgcsFaA0RX = TQ5Erp2YjxliKbDzfZPetoh0.index(ZD5n0eJivzWOMxY98dgrumkwRG)
			ClIv35AqpZEV = TTuO14NzmB.SITESURLS[vWNRusF46D7Mi8GpZ(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠲ࠩᗺ")][VCrZ8htDuoMxySipgcsFaA0RX]
			NNme4WIbS1guBhDcMHU3r = TTuO14NzmB.SITESURLS[xdSThjYnuHXAU6M(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠴ࠪᗻ")][VCrZ8htDuoMxySipgcsFaA0RX]
			xuJB1YqVApd6U8GanRtzZPLTy = TTuO14NzmB.SITESURLS[llkFwuCyhaP3sK76qO4T(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫᗼ")][VCrZ8htDuoMxySipgcsFaA0RX]
			Z7Qikucg083SpAzqwlDYKCyF = TTuO14NzmB.api_repos_actions[VCrZ8htDuoMxySipgcsFaA0RX]
	if MRxufqXZFLD1N8KszmhEniWAIk==wUvcPrYDfISbZolAm83GKEqMyXkn5: MRxufqXZFLD1N8KszmhEniWAIk = FVPlZImAtH
	elif MRxufqXZFLD1N8KszmhEniWAIk==None and z1VijOELhCfHTgvsI5y7tdDomxY2F in [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡃࡘࡘࡔ࠭ᗽ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᗾ")] and kkvhwDf1VFRPEiZGWt: MRxufqXZFLD1N8KszmhEniWAIk = FVPlZImAtH
	if DNhXwGLOTi1vICJtuW9MpsF78K or qvuDBAgThsZo: CCOaZv7IcwLueUDFi9pWNBEylr5 = fmkZtbRj3ux(u"࠵࠴ᝲ")
	elif SQsX2bqBRric9Plx: CCOaZv7IcwLueUDFi9pWNBEylr5 = Gj3rMP1Cb8wHdp49la0(u"࠺࠵ᝳ")
	elif xVwDZbA6EOjpgX0 in wVd80JnRO7lLx421szgYiZtj: CCOaZv7IcwLueUDFi9pWNBEylr5 = vvhR5ozeiJpANyl8fFO3GBw(u"࠶࠶᝴")
	elif xVwDZbA6EOjpgX0==vWNRusF46D7Mi8GpZ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬᗿ"): CCOaZv7IcwLueUDFi9pWNBEylr5 = rDG9dZoXRhCJcieUSF0KB(u"࠸࠰᝵")
	elif xVwDZbA6EOjpgX0==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬᘀ"): CCOaZv7IcwLueUDFi9pWNBEylr5 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠲࠱᝶")
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓࠧᘁ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = s149dk8uh2p7oFzaLxZeI3Or(u"࠸࠲᝷")
	elif fmkZtbRj3ux(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ᘂ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = DpRJnas65uVcO0S17dYG(u"࠹࠸᝸")
	elif Gj3rMP1Cb8wHdp49la0(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᘃ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = xm6jK1ZMuWq5(u"࠵࠹᝹")
	elif gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡃࡋ࡛ࡆࡑࠧᘄ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = Gj3rMP1Cb8wHdp49la0(u"࠶࠵᝺")
	elif vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬᘅ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = D2PpKMeZFWrmfxTSs4L1tz(u"࠷࠶᝻")
	elif fmkZtbRj3ux(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᘆ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = w8JC1y7Lp3(u"࠹࠰᝼")
	elif vWNRusF46D7Mi8GpZ(u"ࠫࡆࡑࡏࡂࡏࠪᘇ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = jQv0du1iVxTgAXCM(u"࠲࠶᝽")
	elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡇࡋࡘࡃࡐࠫᘈ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = JHMxIE4fs1mvQtKW7R(u"࠴࠲᝾")
	elif s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᘉ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠴࠳᝿")
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩᘊ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = vvhR5ozeiJpANyl8fFO3GBw(u"࠹࠴ក")
	elif vWNRusF46D7Mi8GpZ(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪᘋ") in xVwDZbA6EOjpgX0: CCOaZv7IcwLueUDFi9pWNBEylr5 = lCT8hfYUBX4OQMmL(u"࠸࠵ខ")
	else: CCOaZv7IcwLueUDFi9pWNBEylr5 = MFhbWia58mP3su0fk2d(u"࠶࠻គ")
	LlPfUqdnQHeMob8cSswN = (TTBcDpHaIbsoP!=None)
	hYITG6gRkdjoa9Mb02CJBLWqQ5O3 = (MRxufqXZFLD1N8KszmhEniWAIk!=None and z1VijOELhCfHTgvsI5y7tdDomxY2F!=gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡖࡘࡔࡖࠧᘌ"))
	if LlPfUqdnQHeMob8cSswN and not SQsX2bqBRric9Plx: hg79cQmoVfMCukiU8ERpT6JqywSrN3(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭ᘍ"),TTBcDpHaIbsoP)
	elif hYITG6gRkdjoa9Mb02CJBLWqQ5O3: hg79cQmoVfMCukiU8ERpT6JqywSrN3(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫᘎ"),MRxufqXZFLD1N8KszmhEniWAIk)
	if LlPfUqdnQHeMob8cSswN:
		PpQkYqWJCVwTgiH = {bQGafNLXyFgsZP6ut(u"ࠧ࡮ࡴࡵࡲࠥᘏ"):TTBcDpHaIbsoP,A6Sg45ChDR3BJLYfFH(u"ࠨࡨࡵࡶࡳࡷࠧᘐ"):TTBcDpHaIbsoP}
		crzOv0KM5YDx1ZEkJly6fSu = TTBcDpHaIbsoP
	else: PpQkYqWJCVwTgiH,crzOv0KM5YDx1ZEkJly6fSu = {},wUvcPrYDfISbZolAm83GKEqMyXkn5
	if hYITG6gRkdjoa9Mb02CJBLWqQ5O3:
		import urllib3.util.connection as jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1
		IcLsMSzAoGfi0H = ytMNceArC8LkEwJ1DX3oHIKbTQv(jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1,FVPlZImAtH,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	RXVHJugpS34CePmvqax0Z1KOGch,vCQjPcifkn5YIDyme,xQRHm9PfqikcSVF5,WihAqlTkw8nP0,Z4Ewasde9F1bSBYKJUX52czp,yVzIZmDT8dvYWl4,verify = RRWF8udv4bYSrKckeV0wp,xVwDZbA6EOjpgX0,xRVnhbcSF5v1NBQI,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,mmxokSPVc6KgdpXQ1NRHvU
	if Rc4bCjIvaZVifKFeMt8YxuhT6z: Z4Ewasde9F1bSBYKJUX52czp = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if agjMmhW3nUsXoywOp or RRWF8udv4bYSrKckeV0wp: RXVHJugpS34CePmvqax0Z1KOGch = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = -UD4N8MjVTd,vWNRusF46D7Mi8GpZ(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸࠧᘑ")
	HHVEmbsOTfL3eg7DtwcG6ANXRBr = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if not TTuO14NzmB.FORWARDS_HOSTNAMES: TTuO14NzmB.FORWARDS_HOSTNAMES = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,kPCxIUZb1V(u"ࠨࡦ࡬ࡧࡹ࠭ᘒ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠸ࠧᘓ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡊࡔࡘࡗࡂࡔࡇࡗࠬᘔ"))
	gWb1BlvL7EOjdVrDuXMNC4FoIKa = []
	while ZD5n0eJivzWOMxY98dgrumkwRG not in gWb1BlvL7EOjdVrDuXMNC4FoIKa and ZD5n0eJivzWOMxY98dgrumkwRG in list(TTuO14NzmB.FORWARDS_HOSTNAMES.keys()):
		gWb1BlvL7EOjdVrDuXMNC4FoIKa.append(ZD5n0eJivzWOMxY98dgrumkwRG)
		ZD5n0eJivzWOMxY98dgrumkwRG = TTuO14NzmB.FORWARDS_HOSTNAMES[ZD5n0eJivzWOMxY98dgrumkwRG]
	j04xwUde7IbEgM2RK6yuPF = FjUcS938pAH5sZ
	if DNhXwGLOTi1vICJtuW9MpsF78K:
		xQRHm9PfqikcSVF5 = it4DKnryZlx(u"ࠫࡕࡕࡓࡕࠩᘕ")
		XubVRNO48BsjJASlmeKwdTCr[TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡇࡖ࠮ࡇࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬᘖ")] = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫᘗ")
		uCZxQU0WNAdSD4wm = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(FjUcS938pAH5sZ)
		j04xwUde7IbEgM2RK6yuPF = juhIT8SaBn9(uCZxQU0WNAdSD4wm,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠾࠱࠳࠹࠷࠽࠸࠻࠶ឃ"))
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG+vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡀࡷࡶࡩࡷࡃࠧᘘ")+wLpPS96U1IKRxFzjVtHZG
	import requests as sfS7a5R14zxlLBM9y0cEUmNV
	for qbRmVByrJv18 in range(bQGafNLXyFgsZP6ut(u"࠹ង")):
		n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		if qbRmVByrJv18:
			vCQjPcifkn5YIDyme = llkFwuCyhaP3sK76qO4T(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩᘙ")
			try: lGQxR39dqyUb1YFcCmjZN5EthrpJ.close()
			except: pass
		if SQsX2bqBRric9Plx or not LlPfUqdnQHeMob8cSswN: xtowQRgA89lOqs4GKv(weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧᘚ"),ZD5n0eJivzWOMxY98dgrumkwRG,j04xwUde7IbEgM2RK6yuPF,XubVRNO48BsjJASlmeKwdTCr,vCQjPcifkn5YIDyme,xQRHm9PfqikcSVF5)
		qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG
		try:
			lGQxR39dqyUb1YFcCmjZN5EthrpJ = sfS7a5R14zxlLBM9y0cEUmNV.request(xQRHm9PfqikcSVF5,ZD5n0eJivzWOMxY98dgrumkwRG,data=j04xwUde7IbEgM2RK6yuPF,headers=XubVRNO48BsjJASlmeKwdTCr,verify=verify,allow_redirects=RXVHJugpS34CePmvqax0Z1KOGch,timeout=CCOaZv7IcwLueUDFi9pWNBEylr5,proxies=PpQkYqWJCVwTgiH)
			if VhqD3zp7mUieI8sMQlETH(u"࠴࠲࠳ច")<=lGQxR39dqyUb1YFcCmjZN5EthrpJ.status_code<=kPCxIUZb1V(u"࠵࠼࠽ឆ"):
				if not WihAqlTkw8nP0:
					hhEH1rcSP0z6Bkqy8OD = lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers.get(kPCxIUZb1V(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᘛ")) or lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers.get(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᘜ")) or wUvcPrYDfISbZolAm83GKEqMyXkn5
					if hhEH1rcSP0z6Bkqy8OD.startswith(vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡀࠧᘝ")): hhEH1rcSP0z6Bkqy8OD = ZD5n0eJivzWOMxY98dgrumkwRG+hhEH1rcSP0z6Bkqy8OD
					if hhEH1rcSP0z6Bkqy8OD: ZD5n0eJivzWOMxY98dgrumkwRG = hhEH1rcSP0z6Bkqy8OD
					else: WihAqlTkw8nP0 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
					if not WihAqlTkw8nP0: ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.encode(TNw1pBHb8CtSZe0EFxuJqI(u"࠭࡬ࡢࡶ࡬ࡲ࠶࠭ᘞ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᘟ")).decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,yRWQMHxZEz0(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᘠ"))
					if agjMmhW3nUsXoywOp and lGQxR39dqyUb1YFcCmjZN5EthrpJ.status_code==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠶࠴࠼ជ"):
						RXVHJugpS34CePmvqax0Z1KOGch = RRWF8udv4bYSrKckeV0wp
						xQRHm9PfqikcSVF5 = xRVnhbcSF5v1NBQI
						WihAqlTkw8nP0 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
						XPFUQgcuIWTJ
				if not WihAqlTkw8nP0 or RRWF8udv4bYSrKckeV0wp:
					if erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡫ࡸࡹࡶࠧᘡ") not in ZD5n0eJivzWOMxY98dgrumkwRG:
						yeYP4jSHQzW3fgdMO5NT6V = TO3vi2rSZ0LRhKlwgG4qkYFIC(qaLFXuDExl8w,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡹࡷࡲࠧᘢ"))
						ZD5n0eJivzWOMxY98dgrumkwRG = yeYP4jSHQzW3fgdMO5NT6V+xm6jK1ZMuWq5(u"ࠫ࠴࠭ᘣ")+ZD5n0eJivzWOMxY98dgrumkwRG.lstrip(TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࠵ࠧᘤ"))
				if ZD5n0eJivzWOMxY98dgrumkwRG!=qaLFXuDExl8w:
					TTuO14NzmB.FORWARDS_HOSTNAMES[qaLFXuDExl8w] = ZD5n0eJivzWOMxY98dgrumkwRG
					HHVEmbsOTfL3eg7DtwcG6ANXRBr = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				if not WihAqlTkw8nP0:
					sdU2oDpHEZWfVwJTh = lGQxR39dqyUb1YFcCmjZN5EthrpJ
					if rjZFa0VMBuPRHg1cIYJpd52oxl4(ZD5n0eJivzWOMxY98dgrumkwRG): WihAqlTkw8nP0 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			elif D2PpKMeZFWrmfxTSs4L1tz(u"࠺࠻࠰ញ")<=lGQxR39dqyUb1YFcCmjZN5EthrpJ.status_code<=dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠹࠾࠿ឈ"): Z4Ewasde9F1bSBYKJUX52czp = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			else: WihAqlTkw8nP0 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			if not WihAqlTkw8nP0 and not RRWF8udv4bYSrKckeV0wp and sdU2oDpHEZWfVwJTh.headers: lGQxR39dqyUb1YFcCmjZN5EthrpJ = sdU2oDpHEZWfVwJTh
			qaLFXuDExl8w = lGQxR39dqyUb1YFcCmjZN5EthrpJ.url
			TeuQd8DXNkc0zlYmKF2J = lGQxR39dqyUb1YFcCmjZN5EthrpJ.status_code
			Kw19luY7W2jGgsBa5n4hctLfFS = lGQxR39dqyUb1YFcCmjZN5EthrpJ.reason
			lGQxR39dqyUb1YFcCmjZN5EthrpJ.raise_for_status()
			n453i9Fwpc6bGMuUa2l = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		except sfS7a5R14zxlLBM9y0cEUmNV.exceptions.HTTPError as CPhVH47v1X83tgA62wMWirdG:
			pass
		except sfS7a5R14zxlLBM9y0cEUmNV.exceptions.Timeout as CPhVH47v1X83tgA62wMWirdG:
			if ndib93Ol6UojCrEV: Kw19luY7W2jGgsBa5n4hctLfFS = str(CPhVH47v1X83tgA62wMWirdG.message).split(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭࠺ࠡࠩᘥ"))[UD4N8MjVTd]
			else: Kw19luY7W2jGgsBa5n4hctLfFS = str(CPhVH47v1X83tgA62wMWirdG).split(MFhbWia58mP3su0fk2d(u"ࠧ࠻ࠢࠪᘦ"))[UD4N8MjVTd]
		except sfS7a5R14zxlLBM9y0cEUmNV.exceptions.ConnectionError as CPhVH47v1X83tgA62wMWirdG:
			try: rrXegNV0zTcR = CPhVH47v1X83tgA62wMWirdG.message[wTLFCOcM26fmYlW7U]
			except: rrXegNV0zTcR = str(CPhVH47v1X83tgA62wMWirdG)
			WL8OHxuPKV57B = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᘧ"),rrXegNV0zTcR)
			if not WL8OHxuPKV57B: WL8OHxuPKV57B = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧᘨ"),rrXegNV0zTcR)
			if not WL8OHxuPKV57B:
				zCndmY9uxsVyDXWaJgAp3OqREe5Zhf = jj0dZrgiKb.findall(xm6jK1ZMuWq5(u"ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮ࡀࠢᘩ"),rrXegNV0zTcR)
				if zCndmY9uxsVyDXWaJgAp3OqREe5Zhf: WL8OHxuPKV57B = [zCndmY9uxsVyDXWaJgAp3OqREe5Zhf[wTLFCOcM26fmYlW7U][UD4N8MjVTd],zCndmY9uxsVyDXWaJgAp3OqREe5Zhf[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U]]
			if not WL8OHxuPKV57B: WL8OHxuPKV57B = jj0dZrgiKb.findall(vWNRusF46D7Mi8GpZ(u"ࠦ࠿࠮࡜ࡥ࠭ࠬ࠾ࠥ࠮࠮ࠫࡁࠬࠫࠧᘪ"),rrXegNV0zTcR)
			if not WL8OHxuPKV57B: WL8OHxuPKV57B = jj0dZrgiKb.findall(kPCxIUZb1V(u"ࠧࠦࠨ࡝ࡦ࠮࠭ࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᘫ"),rrXegNV0zTcR)
			try: TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = WL8OHxuPKV57B[wTLFCOcM26fmYlW7U]
			except: TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = -Tb7oymMnpflsSv3eu4Pz2,rrXegNV0zTcR
		except sfS7a5R14zxlLBM9y0cEUmNV.exceptions.RequestException as CPhVH47v1X83tgA62wMWirdG:
			if ndib93Ol6UojCrEV: Kw19luY7W2jGgsBa5n4hctLfFS = CPhVH47v1X83tgA62wMWirdG.message
			else: Kw19luY7W2jGgsBa5n4hctLfFS = str(CPhVH47v1X83tgA62wMWirdG)
		except:
			try: TeuQd8DXNkc0zlYmKF2J = lGQxR39dqyUb1YFcCmjZN5EthrpJ.status_code
			except: pass
			try: Kw19luY7W2jGgsBa5n4hctLfFS = lGQxR39dqyUb1YFcCmjZN5EthrpJ.reason
			except: pass
		Kw19luY7W2jGgsBa5n4hctLfFS = str(Kw19luY7W2jGgsBa5n4hctLfFS)
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᘬ")+str(TeuQd8DXNkc0zlYmKF2J)+vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᘭ")+Kw19luY7W2jGgsBa5n4hctLfFS+TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᘮ")+xVwDZbA6EOjpgX0+xm6jK1ZMuWq5(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᘯ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(xLDEnp9WdA,xVwDZbA6EOjpgX0)+vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࠤࡢ࠭ᘰ"))
		if H8HQ7qBslgzpfVRAMNev and agjMmhW3nUsXoywOp and not Z4Ewasde9F1bSBYKJUX52czp and TeuQd8DXNkc0zlYmKF2J!=s149dk8uh2p7oFzaLxZeI3Or(u"࠸࠰࠱ដ") and w8JC1y7Lp3(u"ࠫ࠶࠸࠷࠯࠲࠱࠴࠳࠷ࠧᘱ") not in ZD5n0eJivzWOMxY98dgrumkwRG:
			if ZD5n0eJivzWOMxY98dgrumkwRG not in [ClIv35AqpZEV,NNme4WIbS1guBhDcMHU3r,xuJB1YqVApd6U8GanRtzZPLTy]: ZD5n0eJivzWOMxY98dgrumkwRG,Z4Ewasde9F1bSBYKJUX52czp = ClIv35AqpZEV,Z19pUxa2gfGMNKoDsEuytn85SjFvA
			elif ZD5n0eJivzWOMxY98dgrumkwRG==ClIv35AqpZEV: ZD5n0eJivzWOMxY98dgrumkwRG,Z4Ewasde9F1bSBYKJUX52czp = NNme4WIbS1guBhDcMHU3r,Z19pUxa2gfGMNKoDsEuytn85SjFvA
			elif ZD5n0eJivzWOMxY98dgrumkwRG==NNme4WIbS1guBhDcMHU3r: ZD5n0eJivzWOMxY98dgrumkwRG,Z4Ewasde9F1bSBYKJUX52czp = xuJB1YqVApd6U8GanRtzZPLTy,y0yvdNOZkiKEg5RLMhoDVQAB9F2
			continue
		if not WihAqlTkw8nP0 and n453i9Fwpc6bGMuUa2l: continue
		break
	TeuQd8DXNkc0zlYmKF2J = int(TeuQd8DXNkc0zlYmKF2J)
	if not n453i9Fwpc6bGMuUa2l:
		NNBbLrMpTYx5ioUuy74n = eva1dqCNwXh5lL3rkTfWSVp(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭ᘲ"),fmkZtbRj3ux(u"࠸࠱ឋ"))
		if NNBbLrMpTYx5ioUuy74n==-UD4N8MjVTd:
			KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,yRWQMHxZEz0(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࠤࡉࡏࡓࡄࡑࡑࡒࡊࡉࡔࡆࡆࠣࠤ࡚ࠥࡨࡦࠢࡧࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡳࡳࡴࡥࡤࡶࡨࡨࠥࡺ࡯ࠡࡶ࡫ࡩࠥ࡯࡮ࡵࡧࡵࡲࡪࡺࠠࠢࠣࠪᘳ"))
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧๅๆฦืๆࠦฬ่ษี็ࠥเ๊า่ࠢีอ๎ืࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣ฾๏ืࠠใษาีࠥษๆࠡ์ึฮำีๅࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฽ิอฯศฬࠣะ์อาไࠢ฽๎ึࠦีฮ์ะอࠥࡢ࡮࡝ࡰ่ࠣา๊ࠠศๆุ่่๊ษࠡฬฦ็ิࠦร็ࠢฯ๋ฬุใࠡ็ิฬํ฽ࠠษูิ๎็ฯࠠึฯํัฮࠦศศๆศ๊ฯืๆห๋ࠢๅ๏ํࠠศๆศ๊ฯืๆหࠢอ฽๊๊ࠠษื๋ีฮࠦฬ๋ัฬࠫᘴ"))
			sKv7WVYzUI()
			return lGQxR39dqyUb1YFcCmjZN5EthrpJ
	if not n453i9Fwpc6bGMuUa2l and gWb1BlvL7EOjdVrDuXMNC4FoIKa:
		for url in gWb1BlvL7EOjdVrDuXMNC4FoIKa:
			if url in list(TTuO14NzmB.FORWARDS_HOSTNAMES.keys()):
				del TTuO14NzmB.FORWARDS_HOSTNAMES[url]
				HHVEmbsOTfL3eg7DtwcG6ANXRBr = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if HHVEmbsOTfL3eg7DtwcG6ANXRBr:
		SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,it4DKnryZlx(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭ᘵ"),Gj3rMP1Cb8wHdp49la0(u"ࠩࡉࡓࡗ࡝ࡁࡓࡆࡖࠫᘶ"),TTuO14NzmB.FORWARDS_HOSTNAMES,sBTeylAtiQXpFW9wjM5C1m)
		TTuO14NzmB.FORWARDS_HOSTNAMES = {}
	if MRxufqXZFLD1N8KszmhEniWAIk!=None and z1VijOELhCfHTgvsI5y7tdDomxY2F!=jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡗ࡙ࡕࡐࠨᘷ"): jop7Lw9iCX5ufDZtAOWcPaeN2rJ3g1.create_connection = IcLsMSzAoGfi0H
	if z1VijOELhCfHTgvsI5y7tdDomxY2F==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡆࡒࡗࡂ࡛ࡖࠫᘸ") and kkvhwDf1VFRPEiZGWt: MRxufqXZFLD1N8KszmhEniWAIk = None
	if not n453i9Fwpc6bGMuUa2l and TTBcDpHaIbsoP==None and xVwDZbA6EOjpgX0 not in wVd80JnRO7lLx421szgYiZtj:
		av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
		if av1f8x5yZ9rAsq!=xm6jK1ZMuWq5(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨᘹ"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
	toEMTSVjIO = D8JlSY7NibwpLWxPXAfFgQsd()
	if SQsX2bqBRric9Plx: qaLFXuDExl8w = sscIgjPTGO4Dldaui8CkSny5qhWpA
	if not qaLFXuDExl8w: qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG
	toEMTSVjIO.url = qaLFXuDExl8w
	toEMTSVjIO.scrape = SQsX2bqBRric9Plx
	try:
		RYA0WhcGHbCiajmluQ4Stz1spVK = lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers
		if not RYA0WhcGHbCiajmluQ4Stz1spVK.get(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᘺ")) and not RYA0WhcGHbCiajmluQ4Stz1spVK.get(lCT8hfYUBX4OQMmL(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᘻ")): RYA0WhcGHbCiajmluQ4Stz1spVK.headers[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᘼ")] = qaLFXuDExl8w
	except: RYA0WhcGHbCiajmluQ4Stz1spVK = {}
	try:
		OfFQYdjeBCg3or5W = lGQxR39dqyUb1YFcCmjZN5EthrpJ.content
		if DNhXwGLOTi1vICJtuW9MpsF78K and OfFQYdjeBCg3or5W:
			AwCeIGihEBXjvLtHDxa0KFblQ9T1m7 = {YYaiweEBOS4tVKfQz7mT.lower(): Uh9uHWxapqMCPbAmGngc for YYaiweEBOS4tVKfQz7mT, Uh9uHWxapqMCPbAmGngc in lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers.items()}
			if AwCeIGihEBXjvLtHDxa0KFblQ9T1m7.get(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡤࡺ࠲࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᘽ"))==xdSThjYnuHXAU6M(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᘾ"):
				OfFQYdjeBCg3or5W,TQXKiPhvRf3xjGJBdeCObVIrD2U60w = FSLKwjQivEZ80xpTarcoN92UXeO(OfFQYdjeBCg3or5W,erqDsJmL3BQHuGtPkcf0X9(u"࠹࠳࠵࠻࠹࠿࠳࠶࠸ឌ"))
				if TQXKiPhvRf3xjGJBdeCObVIrD2U60w==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡎࡔࡖࡂࡎࡌࡈࡤ࡚ࡉࡎࡇࡖࡘࡆࡓࡐࠨᘿ"):
					Kw19luY7W2jGgsBa5n4hctLfFS,TeuQd8DXNkc0zlYmKF2J = vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡁࡑࡋࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࠭ᙀ"),-ewJ9sTMmXtWH0ANVShQ2
					n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
					OfFQYdjeBCg3or5W = Kw19luY7W2jGgsBa5n4hctLfFS
	except: OfFQYdjeBCg3or5W = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(OfFQYdjeBCg3or5W,bytes):
		try: OfFQYdjeBCg3or5W = OfFQYdjeBCg3or5W.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		except: OfFQYdjeBCg3or5W = OfFQYdjeBCg3or5W.decode(QMZ3cLnaCrFR1Aq)
	if SQsX2bqBRric9Plx:
		if rDG9dZoXRhCJcieUSF0KB(u"࠭ࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡉࡅࡎࡒࠢࠨᙁ") in OfFQYdjeBCg3or5W and SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࠣࡪࡷࡸࡵࡉ࡯ࡥࡧࠥ࠾࠷࠶࠰ࠨᙂ") in OfFQYdjeBCg3or5W: TeuQd8DXNkc0zlYmKF2J,n453i9Fwpc6bGMuUa2l = -MMRBkhnWVJCQwU,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if DNhXwGLOTi1vICJtuW9MpsF78K and OfFQYdjeBCg3or5W and w8JC1y7Lp3(u"࠸࠹࠵ណ")<=TeuQd8DXNkc0zlYmKF2J<=s149dk8uh2p7oFzaLxZeI3Or(u"࠷࠼࠽ឍ"): Kw19luY7W2jGgsBa5n4hctLfFS = OfFQYdjeBCg3or5W
	try: zFC9PmN7IObvKxrYRSMcgej2ftl6 = lGQxR39dqyUb1YFcCmjZN5EthrpJ.cookies.get_dict()
	except: zFC9PmN7IObvKxrYRSMcgej2ftl6 = {}
	try: lGQxR39dqyUb1YFcCmjZN5EthrpJ.close()
	except: pass
	toEMTSVjIO.code = TeuQd8DXNkc0zlYmKF2J
	toEMTSVjIO.reason = Kw19luY7W2jGgsBa5n4hctLfFS
	toEMTSVjIO.content = OfFQYdjeBCg3or5W
	toEMTSVjIO.headers = RYA0WhcGHbCiajmluQ4Stz1spVK
	toEMTSVjIO.cookies = zFC9PmN7IObvKxrYRSMcgej2ftl6
	toEMTSVjIO.succeeded = n453i9Fwpc6bGMuUa2l
	toEMTSVjIO.scrapernumber = wUvcPrYDfISbZolAm83GKEqMyXkn5
	toEMTSVjIO.scraperserver = wUvcPrYDfISbZolAm83GKEqMyXkn5
	toEMTSVjIO.scraperurl = wUvcPrYDfISbZolAm83GKEqMyXkn5
	C5JhBn2SIUeu1OzV6oELQdqWG = toEMTSVjIO.content.lower() if ndib93Ol6UojCrEV or isinstance(toEMTSVjIO.content,str) else wUvcPrYDfISbZolAm83GKEqMyXkn5
	np1Yc4DiO8bwr = (pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᙃ") in C5JhBn2SIUeu1OzV6oELQdqWG or it4DKnryZlx(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩᙄ") in C5JhBn2SIUeu1OzV6oELQdqWG) and C5JhBn2SIUeu1OzV6oELQdqWG.count(it4DKnryZlx(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᙅ"))>Tb7oymMnpflsSv3eu4Pz2 and xm6jK1ZMuWq5(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᙆ") not in xVwDZbA6EOjpgX0 and JHMxIE4fs1mvQtKW7R(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪᙇ") not in xVwDZbA6EOjpgX0 and pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨᙈ") not in C5JhBn2SIUeu1OzV6oELQdqWG and not SQsX2bqBRric9Plx
	UUfSPRecCMzTLV2ZoaWOr8QuIG = (dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡷࡧࡵ࡭࡫ࡿ࠮ࡩࡶࡰࡰࡄࡸࡥࡥ࡫ࡵࡩࡨࡺ࠽ࠨᙉ") in qaLFXuDExl8w)
	if TeuQd8DXNkc0zlYmKF2J==bQGafNLXyFgsZP6ut(u"࠶࠵࠶ត") and (np1Yc4DiO8bwr or UUfSPRecCMzTLV2ZoaWOr8QuIG):
		toEMTSVjIO.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if toEMTSVjIO.succeeded and H8HQ7qBslgzpfVRAMNev and agjMmhW3nUsXoywOp:
		mmJANrSUfes5Rw8lyEpMY2HCg = bQGafNLXyFgsZP6ut(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᙊ")+FjUcS938pAH5sZ[D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࡭ࡳࡧ࠭ᙋ")].upper().replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡋࡊ࡚ࠧᙌ"),wUvcPrYDfISbZolAm83GKEqMyXkn5) if Rc4bCjIvaZVifKFeMt8YxuhT6z else Z7Qikucg083SpAzqwlDYKCyF
		SwkKZ8pMra5VFs9zbOnf2Gli0YI(mmJANrSUfes5Rw8lyEpMY2HCg)
	if not toEMTSVjIO.succeeded and H8HQ7qBslgzpfVRAMNev:
		Z0p1FUhfAr2SQGJk7ae = (DpRJnas65uVcO0S17dYG(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᙍ") in C5JhBn2SIUeu1OzV6oELQdqWG and gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧᙎ") in C5JhBn2SIUeu1OzV6oELQdqWG)
		YZQAnx7EWD9Msg3uHtBrp6KcIL5Vk = (dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭࠵ࠡࡵࡨࡧࠬᙏ") in C5JhBn2SIUeu1OzV6oELQdqWG and MFhbWia58mP3su0fk2d(u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨᙐ") in C5JhBn2SIUeu1OzV6oELQdqWG)
		P7Pgd3bXJ6cIeAjsERl = (TeuQd8DXNkc0zlYmKF2J in [rDG9dZoXRhCJcieUSF0KB(u"࠹࠶࠳ថ")] and VhqD3zp7mUieI8sMQlETH(u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫᙑ") in C5JhBn2SIUeu1OzV6oELQdqWG)
		KKYsjmaInVPZglpJ = (it4DKnryZlx(u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫᙒ") in C5JhBn2SIUeu1OzV6oELQdqWG and bQGafNLXyFgsZP6ut(u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧᙓ") in C5JhBn2SIUeu1OzV6oELQdqWG)
		rt8uifS4aYgIljcwDhnVkd1xQJ7FC = (fmkZtbRj3ux(u"ࠫ࡜ࡘࡏࡏࡉࡢ࡚ࡊࡘࡓࡊࡑࡑࡣࡓ࡛ࡍࡃࡇࡕࠫᙔ") in Kw19luY7W2jGgsBa5n4hctLfFS or dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡽࡲࡰࡰࡪࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡴࡵ࡮ࡤࡨࡶࠬᙕ") in Kw19luY7W2jGgsBa5n4hctLfFS)
		if   np1Yc4DiO8bwr: Kw19luY7W2jGgsBa5n4hctLfFS = erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᙖ")
		elif Z0p1FUhfAr2SQGJk7ae: Kw19luY7W2jGgsBa5n4hctLfFS = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᙗ")
		elif YZQAnx7EWD9Msg3uHtBrp6KcIL5Vk: Kw19luY7W2jGgsBa5n4hctLfFS = TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨᙘ")
		elif P7Pgd3bXJ6cIeAjsERl: Kw19luY7W2jGgsBa5n4hctLfFS = weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪᙙ")
		elif KKYsjmaInVPZglpJ: Kw19luY7W2jGgsBa5n4hctLfFS = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬᙚ")
		elif UUfSPRecCMzTLV2ZoaWOr8QuIG: Kw19luY7W2jGgsBa5n4hctLfFS = w8JC1y7Lp3(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠦࡣࡩࡧࡦ࡯ࠬᙛ")
		elif rt8uifS4aYgIljcwDhnVkd1xQJ7FC: Kw19luY7W2jGgsBa5n4hctLfFS = rDG9dZoXRhCJcieUSF0KB(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡼࡳࡺࡸࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡࡦࡨࡺ࡮ࡩࡥࡴࠩᙜ")
		else: Kw19luY7W2jGgsBa5n4hctLfFS = str(Kw19luY7W2jGgsBa5n4hctLfFS)
		xLK3kz2aD5 = QEbx35yvreoT2sPDG4k9Fcfa8Z(ZD5n0eJivzWOMxY98dgrumkwRG,xVwDZbA6EOjpgX0)
		if xVwDZbA6EOjpgX0 in OS3ikB5hIzYw17: pass
		elif xVwDZbA6EOjpgX0 in wVd80JnRO7lLx421szgYiZtj:
			KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+rDG9dZoXRhCJcieUSF0KB(u"࠭ࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᙝ")+str(TeuQd8DXNkc0zlYmKF2J)+MFhbWia58mP3su0fk2d(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᙞ")+Kw19luY7W2jGgsBa5n4hctLfFS+D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᙟ")+xVwDZbA6EOjpgX0+xdSThjYnuHXAU6M(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᙠ")+xLK3kz2aD5+it4DKnryZlx(u"ࠪࠤࡢ࠭ᙡ"))
		else: KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jQv0du1iVxTgAXCM(u"ࠫࠥࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᙢ")+str(TeuQd8DXNkc0zlYmKF2J)+MFhbWia58mP3su0fk2d(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧᙣ")+Kw19luY7W2jGgsBa5n4hctLfFS+llkFwuCyhaP3sK76qO4T(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᙤ")+xVwDZbA6EOjpgX0+JHMxIE4fs1mvQtKW7R(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᙥ")+xLK3kz2aD5+VhqD3zp7mUieI8sMQlETH(u"ࠨࠢࡠࠫᙦ"))
		GKbFQxHu4hPt1Rr8gToLfylpz = sscIgjPTGO4Dldaui8CkSny5qhWpA if SQsX2bqBRric9Plx else Z6bUG0kDQuFqgzdAa1r(xLK3kz2aD5)
		if ndib93Ol6UojCrEV and isinstance(GKbFQxHu4hPt1Rr8gToLfylpz,unicode): GKbFQxHu4hPt1Rr8gToLfylpz = GKbFQxHu4hPt1Rr8gToLfylpz.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		if agjMmhW3nUsXoywOp: GKbFQxHu4hPt1Rr8gToLfylpz = GKbFQxHu4hPt1Rr8gToLfylpz.split(bQGafNLXyFgsZP6ut(u"ࠩ࠲ࠫᙧ"))[-UD4N8MjVTd]
		U3UeyHfh5dRJDaisb = str(Kw19luY7W2jGgsBa5n4hctLfFS)+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡠࡳ࠮ࠧᙨ")+GKbFQxHu4hPt1Rr8gToLfylpz+DpRJnas65uVcO0S17dYG(u"ࠫ࠮࠭ᙩ")
		if any([np1Yc4DiO8bwr,Z0p1FUhfAr2SQGJk7ae,YZQAnx7EWD9Msg3uHtBrp6KcIL5Vk,P7Pgd3bXJ6cIeAjsERl,KKYsjmaInVPZglpJ,UUfSPRecCMzTLV2ZoaWOr8QuIG,rt8uifS4aYgIljcwDhnVkd1xQJ7FC]):
			if H8HQ7qBslgzpfVRAMNev:
				we7D2l4URB = xVwDZbA6EOjpgX0.split(A6Sg45ChDR3BJLYfFH(u"ࠬ࠳ࠧᙪ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠷ទ"))[s149dk8uh2p7oFzaLxZeI3Or(u"࠰ធ")]
				ps1k8HfBVxbhQ4L2NESdzYFwJ(we7D2l4URB)
			if sstykmLoTM86e3whaUDJn0Z1WxqGl:
				if not rt8uifS4aYgIljcwDhnVkd1xQJ7FC:
					toEMTSVjIO.code = -MMRBkhnWVJCQwU
					UY1Ej98ptVsvecxgCFJMIQqKa = JHMxIE4fs1mvQtKW7R(u"࠭็ั้ࠣห้฻แฮห่ࠣฬ๊ࠦๆๅ้ࠤั๊ศ่ษ้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅ่ࠣศ์ฺࠠๆํ๋ฬࠦออสࠣ๎๊์ูࠡฮ่๎฾ࠦศาษ่ะࠥอไไ๊่ฬ๏๎สา่๊ࠢࠥาไษ๋ࠢๅฯำ้ࠠษึฮำีวๆ๊ࠢิ์ࠦวๅืไัฬะࠠ࠯࠰ࠣฬึ์วๆฮࠣ฽๊อฯࠡ์ึฮ฼๐ูࠡล้ࠤ๏าัษࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆๆ๊๊ࠥวࠡ์๋ะิࠦึๆษ้ࠤออไ็ฮสัࡡࡴࠧᙫ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+VhqD3zp7mUieI8sMQlETH(u"ࠧࡆࡴࡵࡳࡷࠦࡃࡰࡦࡨ࠾ࠥࠦࠧᙬ")+str(toEMTSVjIO.code)+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev+JegF7SlMawI03+vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ้็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆอะฬ๎าࠡษ็ััฮࠠภࠣࠤࡠࡳ࠮โะࠢอัฯอฬࠡ࠸࠳ࠤะอๆ๋หࠬࠫ᙭")+AAByQSLgaZwCsKnvc5eWNmY
				else:
					toEMTSVjIO.code = -R9RNUT6WAPEYjHqtIokxuXs
					UY1Ej98ptVsvecxgCFJMIQqKa = llkFwuCyhaP3sK76qO4T(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฯ๋ๆฺࠢไฮาࠦศฺุูࠣๆำวหࠢส่ส์สา่อࠤฬ๊ึา๊ิ๎ฮࠦ࠮࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣฮ่๎ๆࠡ็้ࠤฬ๊ัศ๊อีࠥ฿ๆะๅࠣวํࠦๅ็ࠢหี๋อๅอࠢ฼๊ิ้ࠠฤ๊้๋ࠣࠦฬ่ษีࠤ฾์ฯไ๋ࠢ฼๏็ส่ࠢส่า๋ว๋หฺࠣิࠦวๅใํีํูวหࠢฦ์ࠥ฼ฯࠡษ็ฮัูำࠡล๋ࠤ฻ีࠠศๆหีฬ๋ฬࠡษ็้ษึ๊สࠢ࠱࠲๊ࠥอๅࠢสฺ่๊ใๅหࠣ๎ัฮࠠฦ์ๅหๆࠦ็ั้ࠣห้ำๅศ์ฬࠤฬ๊ฮศูษอࡡࡴࠧ᙮")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡉࡷࡸ࡯ࡳࠢࡆࡳࡩ࡫࠺ࠡࠢࠪᙯ")+str(toEMTSVjIO.code)+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev+JegF7SlMawI03+it4DKnryZlx(u"ࠫ์๊ࠠหำํำ๋ࠥอศ๊็อࠥอำหะาห๊ࠦล็ฬิ๊ฯࠦรฯำ์ࠤ้ะฬศ๊ีࠤฬ๊ๅ็฻ࠣรࠦࠧ࡜࡯ࠪๅำࠥะอหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠯ࠧᙰ")+AAByQSLgaZwCsKnvc5eWNmY
				ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,UY1Ej98ptVsvecxgCFJMIQqKa)
				if ug0EmiKYnRT1qeH9MFyr3pO:
					OFH84dcLtak31SUEuy = dbPKWOTuzeC9mIHJ(xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,j04xwUde7IbEgM2RK6yuPF,XubVRNO48BsjJASlmeKwdTCr,RRWF8udv4bYSrKckeV0wp,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0,TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS)
					if OFH84dcLtak31SUEuy.succeeded: return OFH84dcLtak31SUEuy
		ug0EmiKYnRT1qeH9MFyr3pO = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if (z1VijOELhCfHTgvsI5y7tdDomxY2F==xm6jK1ZMuWq5(u"ࠬࡇࡓࡌࠩᙱ") or OBNsaX0kCqDZorFG4TePIjcldKQMRE==Gj3rMP1Cb8wHdp49la0(u"࠭ࡁࡔࡍࠪᙲ")) and (kkvhwDf1VFRPEiZGWt or sstykmLoTM86e3whaUDJn0Z1WxqGl):
			ug0EmiKYnRT1qeH9MFyr3pO = lZ9FucB5q2vaxjOYM3wPyEG0Q(TeuQd8DXNkc0zlYmKF2J,U3UeyHfh5dRJDaisb,xVwDZbA6EOjpgX0,aHJKVu5hYB9mPWc0Z8)
			if ug0EmiKYnRT1qeH9MFyr3pO and z1VijOELhCfHTgvsI5y7tdDomxY2F==it4DKnryZlx(u"ࠧࡂࡕࡎࠫᙳ"): z1VijOELhCfHTgvsI5y7tdDomxY2F = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪᙴ")
			else: z1VijOELhCfHTgvsI5y7tdDomxY2F = kPCxIUZb1V(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᙵ")
			if ug0EmiKYnRT1qeH9MFyr3pO and OBNsaX0kCqDZorFG4TePIjcldKQMRE==jQv0du1iVxTgAXCM(u"ࠪࡅࡘࡑࠧᙶ"): OBNsaX0kCqDZorFG4TePIjcldKQMRE = w8JC1y7Lp3(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᙷ")
			else: OBNsaX0kCqDZorFG4TePIjcldKQMRE = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᙸ")
			OOnvcPQy85HYA.setSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᙹ"),z1VijOELhCfHTgvsI5y7tdDomxY2F)
			OOnvcPQy85HYA.setSetting(vWNRusF46D7Mi8GpZ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᙺ"),OBNsaX0kCqDZorFG4TePIjcldKQMRE)
		if ug0EmiKYnRT1qeH9MFyr3pO:
			if TeuQd8DXNkc0zlYmKF2J==kPCxIUZb1V(u"࠹ន") and SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡪࡷࡸࡵࡹࠧᙻ") in ZD5n0eJivzWOMxY98dgrumkwRG and snTM4Nyp30UevWi:
				if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(xm6jK1ZMuWq5(u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩᙼ"),JHMxIE4fs1mvQtKW7R(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᙽ"),L5jXH0fZ8TvsESR=D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠳࠴࠵ប"))
				qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG+Gj3rMP1Cb8wHdp49la0(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᙾ")
				jPianuQJ6sLd4ReUANv8k = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,qaLFXuDExl8w,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,aHJKVu5hYB9mPWc0Z8,kPCxIUZb1V(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠵ࡲࡩ࠭ᙿ"))
				if jPianuQJ6sLd4ReUANv8k.succeeded:
					toEMTSVjIO = jPianuQJ6sLd4ReUANv8k
					KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ ")+xVwDZbA6EOjpgX0+rDG9dZoXRhCJcieUSF0KB(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᚁ")+xLK3kz2aD5+bQGafNLXyFgsZP6ut(u"ࠨࠢࡠࠫᚂ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(jQv0du1iVxTgAXCM(u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ᚃ"),TNw1pBHb8CtSZe0EFxuJqI(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚄ"),L5jXH0fZ8TvsESR=ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠴࠵࠶ផ"))
				else:
					KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+vWNRusF46D7Mi8GpZ(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᚅ")+xVwDZbA6EOjpgX0+MFhbWia58mP3su0fk2d(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᚆ")+xLK3kz2aD5+MFhbWia58mP3su0fk2d(u"࠭ࠠ࡞ࠩᚇ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(llkFwuCyhaP3sK76qO4T(u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪᚈ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᚉ"),L5jXH0fZ8TvsESR=MFhbWia58mP3su0fk2d(u"࠶࠵࠶࠰ព"))
			if not toEMTSVjIO.succeeded and OBNsaX0kCqDZorFG4TePIjcldKQMRE in [s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡄ࡙࡙ࡕࠧᚊ"),Gj3rMP1Cb8wHdp49la0(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᚋ")] and sstykmLoTM86e3whaUDJn0Z1WxqGl:
				if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(rDG9dZoXRhCJcieUSF0KB(u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫᚌ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᚍ"),L5jXH0fZ8TvsESR=llkFwuCyhaP3sK76qO4T(u"࠷࠶࠰࠱ភ"))
				jPianuQJ6sLd4ReUANv8k = u3u4vZH0wtYrBUGig7qn5L(xRVnhbcSF5v1NBQI,ZD5n0eJivzWOMxY98dgrumkwRG,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,aHJKVu5hYB9mPWc0Z8,xVwDZbA6EOjpgX0)
				if jPianuQJ6sLd4ReUANv8k.succeeded:
					toEMTSVjIO = jPianuQJ6sLd4ReUANv8k
					KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+weh7SGmuTgXOVRcMo1rlLq(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᚎ")+xVwDZbA6EOjpgX0+llkFwuCyhaP3sK76qO4T(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᚏ")+xLK3kz2aD5+lCT8hfYUBX4OQMmL(u"ࠨࠢࡠࠫᚐ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(TNw1pBHb8CtSZe0EFxuJqI(u"้ࠩะฬำࠠิ์ิๅึอสࠡสิ์ู่๊ࠨᚑ"),jQv0du1iVxTgAXCM(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚒ"),L5jXH0fZ8TvsESR=ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠸࠰࠱࠲ម"))
				else:
					KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+weh7SGmuTgXOVRcMo1rlLq(u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᚓ")+xVwDZbA6EOjpgX0+vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᚔ")+xLK3kz2aD5+yRWQMHxZEz0(u"࠭ࠠ࡞ࠩᚕ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬᚖ"),kPCxIUZb1V(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᚗ"),L5jXH0fZ8TvsESR=weh7SGmuTgXOVRcMo1rlLq(u"࠲࠱࠲࠳យ"))
			if not toEMTSVjIO.succeeded and z1VijOELhCfHTgvsI5y7tdDomxY2F in [jQv0du1iVxTgAXCM(u"ࠩࡄ࡙࡙ࡕࠧᚘ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᚙ")] and kkvhwDf1VFRPEiZGWt:
				if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᚚ"),A6Sg45ChDR3BJLYfFH(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ᚛"),L5jXH0fZ8TvsESR=SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳࠲࠳࠴រ"))
				qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG+yRWQMHxZEz0(u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ᚜")
				jPianuQJ6sLd4ReUANv8k = zzJ1qB8RYw7jALnEKoWs(xRVnhbcSF5v1NBQI,qaLFXuDExl8w,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,iizDKErMwWy3VSCgmbu9N4Rs5X,aHJKVu5hYB9mPWc0Z8,lCT8hfYUBX4OQMmL(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠹ࡺࡨࠨ᚝"))
				if jPianuQJ6sLd4ReUANv8k.succeeded:
					toEMTSVjIO = jPianuQJ6sLd4ReUANv8k
					KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+JHMxIE4fs1mvQtKW7R(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ᚞")+FVPlZImAtH+VhqD3zp7mUieI8sMQlETH(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ᚟")+xVwDZbA6EOjpgX0+kPCxIUZb1V(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᚠ")+xLK3kz2aD5+bQGafNLXyFgsZP6ut(u"ࠫࠥࡣࠧᚡ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(jQv0du1iVxTgAXCM(u"ࠬ์ฬศฯࠣื๏ืแาࠢࡇࡒࡘ࠭ᚢ"),D2PpKMeZFWrmfxTSs4L1tz(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᚣ"),L5jXH0fZ8TvsESR=erqDsJmL3BQHuGtPkcf0X9(u"࠴࠳࠴࠵ល"))
				else:
					KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫᚤ")+FVPlZImAtH+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᚥ")+xVwDZbA6EOjpgX0+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᚦ")+xLK3kz2aD5+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࠤࡢ࠭ᚧ"))
					if aHJKVu5hYB9mPWc0Z8: hg79cQmoVfMCukiU8ERpT6JqywSrN3(fmkZtbRj3ux(u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫᚨ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᚩ"),L5jXH0fZ8TvsESR=MFhbWia58mP3su0fk2d(u"࠵࠴࠵࠶វ"))
		if OBNsaX0kCqDZorFG4TePIjcldKQMRE==it4DKnryZlx(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨᚪ") or z1VijOELhCfHTgvsI5y7tdDomxY2F==it4DKnryZlx(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᚫ"): aHJKVu5hYB9mPWc0Z8 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		if not toEMTSVjIO.succeeded:
			if aHJKVu5hYB9mPWc0Z8: ZU5x6fKe4BFRISNDa9 = lZ9FucB5q2vaxjOYM3wPyEG0Q(TeuQd8DXNkc0zlYmKF2J,U3UeyHfh5dRJDaisb,xVwDZbA6EOjpgX0,aHJKVu5hYB9mPWc0Z8)
			if toEMTSVjIO.code!=xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠶࠵࠶ឝ") and xVwDZbA6EOjpgX0 not in jGzLYDpMr2b and lCT8hfYUBX4OQMmL(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬᚬ") not in xVwDZbA6EOjpgX0: sKv7WVYzUI()
	if OOnvcPQy85HYA.getSetting(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᚭ")) not in [ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡅ࡚࡚ࡏࠨᚮ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡘ࡚ࡏࡑࠩᚯ"),VhqD3zp7mUieI8sMQlETH(u"ࠬࡇࡓࡌࠩᚰ")]: OOnvcPQy85HYA.setSetting(jQv0du1iVxTgAXCM(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᚱ"),bQGafNLXyFgsZP6ut(u"ࠧࡂࡕࡎࠫᚲ"))
	if OOnvcPQy85HYA.getSetting(bQGafNLXyFgsZP6ut(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᚳ")) not in [fmkZtbRj3ux(u"ࠩࡄ࡙࡙ࡕࠧᚴ"),yRWQMHxZEz0(u"ࠪࡗ࡙ࡕࡐࠨᚵ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡆ࡙ࡋࠨᚶ")]: OOnvcPQy85HYA.setSetting(yRWQMHxZEz0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᚷ"),DpRJnas65uVcO0S17dYG(u"࠭ࡁࡔࡍࠪᚸ"))
	return toEMTSVjIO
def TuNo7yGrU1FXOmjglV0(F148a7xNcp9C, av5ymG2Z4SMbxqUHu):
	i09JknOYQrtIyPUgR1jeSdCa5uBf, av5ymG2Z4SMbxqUHu = list(F148a7xNcp9C), av5ymG2Z4SMbxqUHu & 0xFFFFFFFF
	for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(i09JknOYQrtIyPUgR1jeSdCa5uBf)-UD4N8MjVTd, wTLFCOcM26fmYlW7U, -UD4N8MjVTd):
		av5ymG2Z4SMbxqUHu = (av5ymG2Z4SMbxqUHu * yRWQMHxZEz0(u"࠷࠶࠷࠶࠸࠶࠺ស") + rDG9dZoXRhCJcieUSF0KB(u"࠶࠶࠱࠴࠻࠳࠸࠷࠸࠳ឞ")) & 0xFFFFFFFF
		i09JknOYQrtIyPUgR1jeSdCa5uBf[kkLhJCU4MQSx7s6gyeOHrRYKtnP3], i09JknOYQrtIyPUgR1jeSdCa5uBf[av5ymG2Z4SMbxqUHu % (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + UD4N8MjVTd)] = i09JknOYQrtIyPUgR1jeSdCa5uBf[av5ymG2Z4SMbxqUHu % (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + UD4N8MjVTd)], i09JknOYQrtIyPUgR1jeSdCa5uBf[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]
	return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࠨᚹ").join(i09JknOYQrtIyPUgR1jeSdCa5uBf)
def l4CmnIi9Ev(F148a7xNcp9C, hp2t7vcFq0TZHSyKNfDJ, bSuO2Y17NrwH3MiU):
	FFeiSh8C7TH5BVbRgzMPuk = xm6jK1ZMuWq5(u"ࠨࠩᚺ").join(chr(kkLhJCU4MQSx7s6gyeOHrRYKtnP3) for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(xdSThjYnuHXAU6M(u"࠲࠶࠸ហ")))
	if not wwMdFkWvcRYiXHB7yDrCqnKb98o: FFeiSh8C7TH5BVbRgzMPuk = FFeiSh8C7TH5BVbRgzMPuk.decode(fmkZtbRj3ux(u"ࠩ࡯ࡥࡹ࡯࡮࠲ࠩᚻ"))
	Rf9CUYjsolEK2h17XacLzpmdn3 = TuNo7yGrU1FXOmjglV0(FFeiSh8C7TH5BVbRgzMPuk, hp2t7vcFq0TZHSyKNfDJ)
	CmxIOw6go3Vrej70S8zUZiYRuEL = TuNo7yGrU1FXOmjglV0(Rf9CUYjsolEK2h17XacLzpmdn3, hp2t7vcFq0TZHSyKNfDJ)
	iiOnsw3uHMS6UpzyKlFjWVh = dict(zip(Rf9CUYjsolEK2h17XacLzpmdn3,CmxIOw6go3Vrej70S8zUZiYRuEL)) if not bSuO2Y17NrwH3MiU else dict(zip(CmxIOw6go3Vrej70S8zUZiYRuEL,Rf9CUYjsolEK2h17XacLzpmdn3))
	F148a7xNcp9C = it4DKnryZlx(u"ࠪࠫᚼ").join(iiOnsw3uHMS6UpzyKlFjWVh.get(frEPWnbh7SMacU4z5Y,frEPWnbh7SMacU4z5Y) for frEPWnbh7SMacU4z5Y in F148a7xNcp9C)
	return F148a7xNcp9C
def K79nCmLMigGquRWS4e0psABxcY(F148a7xNcp9C, hp2t7vcFq0TZHSyKNfDJ):
	a1j30LvDQOi7GV8YhKsm, tNnxsMZAqPHLW5w6XfElG0mV1j, WW1BzhUlnT = [], wTLFCOcM26fmYlW7U, wTLFCOcM26fmYlW7U
	hdUgiuDpAX9lyVe5 = [bQGafNLXyFgsZP6ut(u"࠲࠲ឡ")-int(aKY2A9PnoFg4usizU5QhCD) for aKY2A9PnoFg4usizU5QhCD in str(hp2t7vcFq0TZHSyKNfDJ)[::-UD4N8MjVTd]]
	F4AXVInPu7cZwzqrGkN0 = int(D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࠾࠭ᚽ")*len(str(hp2t7vcFq0TZHSyKNfDJ)))//MMRBkhnWVJCQwU-hp2t7vcFq0TZHSyKNfDJ
	hp2t7vcFq0TZHSyKNfDJ, F4AXVInPu7cZwzqrGkN0 = hp2t7vcFq0TZHSyKNfDJ % rDG9dZoXRhCJcieUSF0KB(u"࠴࠸࠺អ"), F4AXVInPu7cZwzqrGkN0 % rDG9dZoXRhCJcieUSF0KB(u"࠴࠸࠺អ")
	while tNnxsMZAqPHLW5w6XfElG0mV1j < len(F148a7xNcp9C):
		h0IEkw9jQNftPKxXdVa1eRuqSHsn = hdUgiuDpAX9lyVe5[WW1BzhUlnT%len(hdUgiuDpAX9lyVe5)]
		IJE2xcV7OWauUKhfik56gXBwltCb = F148a7xNcp9C[tNnxsMZAqPHLW5w6XfElG0mV1j : tNnxsMZAqPHLW5w6XfElG0mV1j + h0IEkw9jQNftPKxXdVa1eRuqSHsn]
		a1j30LvDQOi7GV8YhKsm += [(ord(frEPWnbh7SMacU4z5Y)^hp2t7vcFq0TZHSyKNfDJ)^F4AXVInPu7cZwzqrGkN0 for frEPWnbh7SMacU4z5Y in IJE2xcV7OWauUKhfik56gXBwltCb][::-UD4N8MjVTd]
		tNnxsMZAqPHLW5w6XfElG0mV1j += h0IEkw9jQNftPKxXdVa1eRuqSHsn
		WW1BzhUlnT += UD4N8MjVTd
	smPXFBWMyovxc5AzK9i = chr if wwMdFkWvcRYiXHB7yDrCqnKb98o else unichr
	F148a7xNcp9C = lCT8hfYUBX4OQMmL(u"ࠬ࠭ᚾ").join([smPXFBWMyovxc5AzK9i(frEPWnbh7SMacU4z5Y) for frEPWnbh7SMacU4z5Y in a1j30LvDQOi7GV8YhKsm])
	return F148a7xNcp9C
def juhIT8SaBn9(F148a7xNcp9C,av5ymG2Z4SMbxqUHu,NNSViyk5ADdBeThPnm9f2XM=wTLFCOcM26fmYlW7U):
	if UD4N8MjVTd:
		if isinstance(F148a7xNcp9C, bytes): F148a7xNcp9C = F148a7xNcp9C.decode(JHMxIE4fs1mvQtKW7R(u"࠭ࡵࡵࡨ࠻ࠫᚿ"))
		yQO3IbT4SLJpHADVsiu15 = L5jXH0fZ8TvsESR.time()+NNSViyk5ADdBeThPnm9f2XM if NNSViyk5ADdBeThPnm9f2XM>wTLFCOcM26fmYlW7U else L5jXH0fZ8TvsESR.time()
		F148a7xNcp9C = TNw1pBHb8CtSZe0EFxuJqI(u"ࡵࠣࡽࢀࢀࢁࢂࡻࡾࠤᛀ").format(int(yQO3IbT4SLJpHADVsiu15), F148a7xNcp9C)
		F148a7xNcp9C = K79nCmLMigGquRWS4e0psABxcY(F148a7xNcp9C, av5ymG2Z4SMbxqUHu)
		F148a7xNcp9C = F148a7xNcp9C.encode(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡷࡷࡪ࠽࠭ᛁ"))
		F148a7xNcp9C = FSaPuXqyvI24in8rhtEzOoe3.compress(F148a7xNcp9C)
		F148a7xNcp9C = F148a7xNcp9C.decode(erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡯ࡥࡹ࡯࡮࠲ࠩᛂ"))
		F148a7xNcp9C = l4CmnIi9Ev(F148a7xNcp9C, av5ymG2Z4SMbxqUHu, vWNRusF46D7Mi8GpZ(u"ࡉࡥࡱࡹࡥឣ"))
		F148a7xNcp9C = F148a7xNcp9C.encode(rDG9dZoXRhCJcieUSF0KB(u"ࠪࡹࡹ࡬࠸ࠨᛃ"))
	return F148a7xNcp9C
def FSLKwjQivEZ80xpTarcoN92UXeO(F148a7xNcp9C,av5ymG2Z4SMbxqUHu,NNSViyk5ADdBeThPnm9f2XM=wTLFCOcM26fmYlW7U):
	TQXKiPhvRf3xjGJBdeCObVIrD2U60w = D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡋࡇࡉࡍࡇࡇࠫᛄ")
	if UD4N8MjVTd:
		if isinstance(F148a7xNcp9C, bytes): F148a7xNcp9C = F148a7xNcp9C.decode(rDG9dZoXRhCJcieUSF0KB(u"ࠬࡻࡴࡧ࠺ࠪᛅ"))
		F148a7xNcp9C = l4CmnIi9Ev(F148a7xNcp9C, av5ymG2Z4SMbxqUHu, A6Sg45ChDR3BJLYfFH(u"ࡘࡷࡻࡥឤ"))
		F148a7xNcp9C = F148a7xNcp9C.encode(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡬ࡢࡶ࡬ࡲ࠶࠭ᛆ"))
		F148a7xNcp9C = FSaPuXqyvI24in8rhtEzOoe3.decompress(F148a7xNcp9C)
		F148a7xNcp9C = F148a7xNcp9C.decode(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡶࡶࡩ࠼ࠬᛇ"))
		F148a7xNcp9C = K79nCmLMigGquRWS4e0psABxcY(F148a7xNcp9C, av5ymG2Z4SMbxqUHu)
		yQO3IbT4SLJpHADVsiu15, F148a7xNcp9C = F148a7xNcp9C.split(xm6jK1ZMuWq5(u"ࠨࡾࡿࢀࠬᛈ"), UD4N8MjVTd)
		TQXKiPhvRf3xjGJBdeCObVIrD2U60w = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬᛉ")
		if NNSViyk5ADdBeThPnm9f2XM>wTLFCOcM26fmYlW7U:
			EN6shTvHB79RYUFac0Gx = L5jXH0fZ8TvsESR.time()-int(yQO3IbT4SLJpHADVsiu15)
			if abs(EN6shTvHB79RYUFac0Gx)>NNSViyk5ADdBeThPnm9f2XM: TQXKiPhvRf3xjGJBdeCObVIrD2U60w = jQv0du1iVxTgAXCM(u"ࠪࡍࡓ࡜ࡁࡍࡋࡇࡣ࡙ࡏࡍࡆࡕࡗࡅࡒࡖࠧᛊ")
		F148a7xNcp9C = F148a7xNcp9C.encode(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡺࡺࡦ࠹ࠩᛋ"))
	return F148a7xNcp9C,TQXKiPhvRf3xjGJBdeCObVIrD2U60w
def iDbrpLzOJXF1kcg6AqtB0devCaUl(X9ApQVzjEOLbmH6NiPt, key=s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡎࡥ࡭࡮ࡲࠤࡕࡿࡴࡩࡱࡱࡊࡱࡧࡳ࡬࡚ࠢࡳࡷࡲࡤࠨᛌ")):
	def _WK3CgZ4voH(E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ): return E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ if isinstance(E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ,bytes) else E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ.encode(llkFwuCyhaP3sK76qO4T(u"࠭ࡵࡵࡨ࠰࠼ࠬᛍ"))
	import hmac as lHLj1RTCguSQ6nsKdErN3M5txkc,base64 as qXASkvFKaf6HojMIz578WxlVwnCpD9
	YYaiweEBOS4tVKfQz7mT=_WK3CgZ4voH(key)
	baRB6e0DNoXZswMqYVfzL857W=_WK3CgZ4voH(bbeLsVCqouaSH53E0XmKh4AnFD.dumps(X9ApQVzjEOLbmH6NiPt,separators=(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧ࠭ࠩᛎ"),Gj3rMP1Cb8wHdp49la0(u"ࠨ࠼ࠪᛏ"))))
	MSvBphPCT8qnuzY9afRHsO1Ztg=str(int(L5jXH0fZ8TvsESR.time())).encode()
	pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe=MSvBphPCT8qnuzY9afRHsO1Ztg+llkFwuCyhaP3sK76qO4T(u"ࡤࠪ࠲ࠬᛐ")+FSaPuXqyvI24in8rhtEzOoe3.compress(baRB6e0DNoXZswMqYVfzL857W)
	ydHSGDhXMWYr83BRF5ZsV=lHLj1RTCguSQ6nsKdErN3M5txkc.new(YYaiweEBOS4tVKfQz7mT,pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe,vlnTfwNrdtCPUWhcu8Ip.sha256).digest()
	return qXASkvFKaf6HojMIz578WxlVwnCpD9.b64encode(pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe)+erqDsJmL3BQHuGtPkcf0X9(u"ࡥࠫ࠳࠭ᛑ")+qXASkvFKaf6HojMIz578WxlVwnCpD9.b64encode(ydHSGDhXMWYr83BRF5ZsV)
from td9O3TPvz2 import *