# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'DAILYMOTION'
UT69hgqoKsWNIwM5zkAYb = '_DLM_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
wkbMLZA1UPQtRnDcmri7qyHz = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][1]
AaDNk2mVEBhCvQH = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][2]
def DDIqhZaAit8Ed9(mode,url,text,type,sbNukjOf4chz):
	if	 mode==400: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==401: RCmHBOKtejQ8lu4L = qqFQc2feCZEtKDSAroBXh51Ob(url,text)
	elif mode==402: RCmHBOKtejQ8lu4L = jjXD5LOAy0Knh8R(url,text)
	elif mode==403: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,text)
	elif mode==404: RCmHBOKtejQ8lu4L = DevtzP0yxIAi45QqwMVa68h(text,sbNukjOf4chz)
	elif mode==405: RCmHBOKtejQ8lu4L = AhRlajcPG29F0Q3tZrUS(text,sbNukjOf4chz)
	elif mode==406: RCmHBOKtejQ8lu4L = O5OBF0xKLZ(text,sbNukjOf4chz)
	elif mode==407: RCmHBOKtejQ8lu4L = cozy4kYNIJORZCaPKQGnpBd6Tmqb(url,sbNukjOf4chz)
	elif mode==408: RCmHBOKtejQ8lu4L = kPwXTednZ9SOuoz(url,sbNukjOf4chz)
	elif mode==409: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text,sbNukjOf4chz)
	elif mode==411: RCmHBOKtejQ8lu4L = Ee2ZVyWJKxbovgi(url,text)
	elif mode==414: RCmHBOKtejQ8lu4L = k0WOS5t4afVs2LbGYTHioxp1XB6mKA(text)
	elif mode==415: RCmHBOKtejQ8lu4L = kkQgS3I2TUAx1pKije(text,sbNukjOf4chz)
	elif mode==416: RCmHBOKtejQ8lu4L = vmuFcitxg23U(text,sbNukjOf4chz)
	elif mode==417: RCmHBOKtejQ8lu4L = Ytp71V2GanmHdJ6MbKeigRAxoDfS8(url,sbNukjOf4chz)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الرئيسية',wUvcPrYDfISbZolAm83GKEqMyXkn5,414)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن فيديوهات',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'videos?sortBy=','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن آخر الفيديوهات',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن الفيديوهات الأكثر مشاهدة',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن قوائم التشغيل',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'playlists','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن مستخدم',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'channels','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن بث حي',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'lives','_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن هاشتاك',wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,'hashtags','_REMEMBERRESULTS_')
	return
def jjXD5LOAy0Knh8R(url,aRtuvUB3NdsSV):
	if '/dm_' in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = QM9sJ7tk0oplqEwHU3DjL64d.headers
		if 'Location' in list(headers.keys()): url = hhD7r1VvaPt3TC06SJjqKRfEid+headers['Location']
	aRtuvUB3NdsSV = JegF7SlMawI03+aRtuvUB3NdsSV+AAByQSLgaZwCsKnvc5eWNmY
	aRtuvUB3NdsSV = iYmIVtlzsa0(aRtuvUB3NdsSV)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: بث حي',url,411,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'channel_lives_now')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: آخر الفيديوهات',url+'/videos',408)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: المميزة',url,411,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'channel_featured_videos')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: قوائم التشغيل',url+'/playlists',407)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+':: قنوات ذات صلة',url,411,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'channel_related_channel')
	return
def iYmIVtlzsa0(title):
	title = title.rstrip('\\').strip(UKFZBQAVXHI5s17LyvuRpCY2).replace('\\\\','\\')
	title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
	return title
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,A3ONzRr6gPkDdJVHTl7UhCeLxcK4):
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy([url],UdbRGoKhcDeI4lVfns5,'video',url)
	return
def DevtzP0yxIAi45QqwMVa68h(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = wUvcPrYDfISbZolAm83GKEqMyXkn5
	search = search.split('/videos')[0]
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	if sort==wUvcPrYDfISbZolAm83GKEqMyXkn5: ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysortmethod',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	else: ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/videos'
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"videos"(.*?)"VideoConnection"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,title,dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV,KS5UPc7G4x38Lp,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+id
			title = iYmIVtlzsa0(title)
			A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = dhHBnVFfKoJgDlXy+'::'+aRtuvUB3NdsSV
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
		if '"hasNextPage":true' in II64TLxj3mbqEyh9pHQ8oAv:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,404,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def AhRlajcPG29F0Q3tZrUS(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/playlists'
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	items = jj0dZrgiKb.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for id,name,axAdpjGCUV,dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count in items:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = iYmIVtlzsa0(title)
		A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = dhHBnVFfKoJgDlXy+'::'+aRtuvUB3NdsSV
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,401,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
	if '"hasNextPage":true' in II64TLxj3mbqEyh9pHQ8oAv:
		sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,405,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def O5OBF0xKLZ(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/channels'
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"channels"(.*?)"ChannelConnection"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,name,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+id
			title = 'USER:  '+name
			title = iYmIVtlzsa0(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,402,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,name)
		if '"hasNextPage":true' in II64TLxj3mbqEyh9pHQ8oAv:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,406,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def k0WOS5t4afVs2LbGYTHioxp1XB6mKA(zsTlNAUutF68gWDVJ3K7pi1f2eBX9):
	ySY5NxERP6jeVG = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['home']['neon']['sections']['edges']
		if not zsTlNAUutF68gWDVJ3K7pi1f2eBX9:
			k8D61UNfamLMbuR0w = []
			for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
				mmMncF7sdDXBk3 = a69exUYRF2LzksroI0iN5c8qOX['node']['title']
				if mmMncF7sdDXBk3 not in k8D61UNfamLMbuR0w: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+mmMncF7sdDXBk3,wUvcPrYDfISbZolAm83GKEqMyXkn5,414,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mmMncF7sdDXBk3)
				k8D61UNfamLMbuR0w.append(mmMncF7sdDXBk3)
		else:
			for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
				mmMncF7sdDXBk3 = a69exUYRF2LzksroI0iN5c8qOX['node']['title']
				if mmMncF7sdDXBk3==zsTlNAUutF68gWDVJ3K7pi1f2eBX9:
					lLXPn5dNxKkAzg = a69exUYRF2LzksroI0iN5c8qOX['node']['components']['edges']
					for yP30brtiuwDs51SJOl9FMo4 in lLXPn5dNxKkAzg:
						KS5UPc7G4x38Lp = str(yP30brtiuwDs51SJOl9FMo4['node']['duration'])
						title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(yP30brtiuwDs51SJOl9FMo4['node']['title'])
						title = title.replace('\/','/')
						zsdRxrTfwubng7DPQyKkmH6 = yP30brtiuwDs51SJOl9FMo4['node']['xid']
						cPzpeLXs3jMCltW4ZN9BaYdfQvwS = yP30brtiuwDs51SJOl9FMo4['node']['thumbnailx480']
						cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
						hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+zsdRxrTfwubng7DPQyKkmH6
						mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
	return
def kkQgS3I2TUAx1pKije(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/lives'
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		try: sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['search']['lives']['edges']
		except: sQaL1mM02pgbtPGkDJl35KEudjxc = []
		for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
			name = a69exUYRF2LzksroI0iN5c8qOX['node']['title']
			name = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(name)
			zsdRxrTfwubng7DPQyKkmH6 = a69exUYRF2LzksroI0iN5c8qOX['node']['xid']
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+zsdRxrTfwubng7DPQyKkmH6
			mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'LIVE: '+name,hhEH1rcSP0z6Bkqy8OD,403)
		if '"hasNextPage":true' in hnJgaVLlc6:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,415,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def KTVNAktI1r5O6QJbvhdpE(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/topics'
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		try: sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['search']['topics']['edges']
		except: sQaL1mM02pgbtPGkDJl35KEudjxc = []
		for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
			name = a69exUYRF2LzksroI0iN5c8qOX['node']['name']
			zsdRxrTfwubng7DPQyKkmH6 = a69exUYRF2LzksroI0iN5c8qOX['node']['xid']
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/topic/'+zsdRxrTfwubng7DPQyKkmH6
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'TOPIC: '+name,hhEH1rcSP0z6Bkqy8OD,413)
		if '"hasNextPage":true' in hnJgaVLlc6:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,412,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def oCHLciUYzIMgNqVR6wp31fQ(url,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	zsdRxrTfwubng7DPQyKkmH6 = url.split('/')[-1]
	ySY5NxERP6jeVG = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mytopicid',zsdRxrTfwubng7DPQyKkmH6)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['topic']['videos']['edges']
		for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
			KS5UPc7G4x38Lp = str(a69exUYRF2LzksroI0iN5c8qOX['node']['duration'])
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(a69exUYRF2LzksroI0iN5c8qOX['node']['title'])
			title = title.replace('\/','/')
			zsdRxrTfwubng7DPQyKkmH6 = a69exUYRF2LzksroI0iN5c8qOX['node']['xid']
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = a69exUYRF2LzksroI0iN5c8qOX['node']['thumbnailx480']
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+zsdRxrTfwubng7DPQyKkmH6
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
		if '"hasNextPage":true' in hnJgaVLlc6:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,413,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz)
	return
def qqFQc2feCZEtKDSAroBXh51Ob(url,A3ONzRr6gPkDdJVHTl7UhCeLxcK4):
	id = url.split('/')[-1]
	dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV = A3ONzRr6gPkDdJVHTl7UhCeLxcK4.split('::',1)
	hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+dhHBnVFfKoJgDlXy
	aRtuvUB3NdsSV = iYmIVtlzsa0(aRtuvUB3NdsSV)
	title = JegF7SlMawI03+'OWNER:  '+aRtuvUB3NdsSV+AAByQSLgaZwCsKnvc5eWNmY
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,402,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,aRtuvUB3NdsSV)
	ySY5NxERP6jeVG = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('myplaylistid',id)
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"collection_videos"(.*?)"SectionEdge"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,title,KS5UPc7G4x38Lp,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+id
			title = iYmIVtlzsa0(title)
			A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = dhHBnVFfKoJgDlXy+'::'+aRtuvUB3NdsSV
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
	return
def kPwXTednZ9SOuoz(url,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	LTt0Peg4HUB8wSxEn9pZiMWmDc753G = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	ySY5NxERP6jeVG = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mychannelid',LTt0Peg4HUB8wSxEn9pZiMWmDc753G)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysortmethod',sort)
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,title,KS5UPc7G4x38Lp,dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+id
			title = iYmIVtlzsa0(title)
			A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = dhHBnVFfKoJgDlXy+'::'+aRtuvUB3NdsSV
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
		if '"hasNextPage":true' in II64TLxj3mbqEyh9pHQ8oAv:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,408,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz)
	return
def cozy4kYNIJORZCaPKQGnpBd6Tmqb(url,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	LTt0Peg4HUB8wSxEn9pZiMWmDc753G = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	ySY5NxERP6jeVG = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mychannelid',LTt0Peg4HUB8wSxEn9pZiMWmDc753G)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysortmethod',sort)
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for id,name,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,count,axAdpjGCUV,dhHBnVFfKoJgDlXy,aRtuvUB3NdsSV in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = iYmIVtlzsa0(title)
			A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = dhHBnVFfKoJgDlXy+'::'+aRtuvUB3NdsSV
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,401,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
		if '"hasNextPage":true' in II64TLxj3mbqEyh9pHQ8oAv:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,407,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz)
	return
def Ee2ZVyWJKxbovgi(url,KYncqj1rdvAg5ZykOtwiGosJMuU):
	LTt0Peg4HUB8wSxEn9pZiMWmDc753G = url.split('/')[3]
	ySY5NxERP6jeVG = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mychannelid',LTt0Peg4HUB8wSxEn9pZiMWmDc753G)
	II64TLxj3mbqEyh9pHQ8oAv = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	fiZyakNvMIsw = bbeLsVCqouaSH53E0XmKh4AnFD.loads(II64TLxj3mbqEyh9pHQ8oAv)
	try: items = fiZyakNvMIsw['data']['channel'][KYncqj1rdvAg5ZykOtwiGosJMuU]['edges']
	except: items = []
	if not items: mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+'لا توجد نتائج',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	else:
		for o4oW9wDcsrpHQS816yfIvg in items:
			U5WwNZGJVe3jDx8dcv = o4oW9wDcsrpHQS816yfIvg['node']
			zsdRxrTfwubng7DPQyKkmH6 = U5WwNZGJVe3jDx8dcv['xid']
			keys = list(U5WwNZGJVe3jDx8dcv.keys())
			gcRjzVLAT210u6Z = U5WwNZGJVe3jDx8dcv['__typename'].lower()
			if gcRjzVLAT210u6Z=='channel':
				name = U5WwNZGJVe3jDx8dcv['name']
				gZr4ejwu1NMdoWKspCbhSxcnIRm = U5WwNZGJVe3jDx8dcv['displayName']
				title = 'USER:  '+gZr4ejwu1NMdoWKspCbhSxcnIRm
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = U5WwNZGJVe3jDx8dcv['coverURLx375']
			else:
				name = U5WwNZGJVe3jDx8dcv['channel']['name']
				gZr4ejwu1NMdoWKspCbhSxcnIRm = U5WwNZGJVe3jDx8dcv['channel']['displayName']
				title = U5WwNZGJVe3jDx8dcv['title']
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = U5WwNZGJVe3jDx8dcv['thumbnailx360']
				if gcRjzVLAT210u6Z=='live': title = 'LIVE:  '+title
			title = iYmIVtlzsa0(title)
			A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = name+'::'+gZr4ejwu1NMdoWKspCbhSxcnIRm
			if ndib93Ol6UojCrEV:
				title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = A3ONzRr6gPkDdJVHTl7UhCeLxcK4.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			if gcRjzVLAT210u6Z=='channel':
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+zsdRxrTfwubng7DPQyKkmH6
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,402,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
			else:
				if gcRjzVLAT210u6Z=='video': KS5UPc7G4x38Lp = str(U5WwNZGJVe3jDx8dcv['duration'])
				else: KS5UPc7G4x38Lp = wUvcPrYDfISbZolAm83GKEqMyXkn5
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+zsdRxrTfwubng7DPQyKkmH6
				mwOxEyYAg63B(gcRjzVLAT210u6Z,UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp,A3ONzRr6gPkDdJVHTl7UhCeLxcK4)
	return
def vmuFcitxg23U(search,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	ySY5NxERP6jeVG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mysearchwords',search)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagelimit','40')
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/'+search+'/hashtags'
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		try: sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['search']['hashtags']['edges']
		except: sQaL1mM02pgbtPGkDJl35KEudjxc = []
		for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
			name = a69exUYRF2LzksroI0iN5c8qOX['node']['name']
			name = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(name)
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/hashtag/'+name[1:]
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'HSHTG: '+name,hhEH1rcSP0z6Bkqy8OD,417)
		if '"hasNextPage":true' in hnJgaVLlc6:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,416,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,search)
	return
def Ytp71V2GanmHdJ6MbKeigRAxoDfS8(url,sbNukjOf4chz=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	name = url.split('/')[-1]
	ySY5NxERP6jeVG = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('myhashtagname',name)
	ySY5NxERP6jeVG = ySY5NxERP6jeVG.replace('mypagenumber',sbNukjOf4chz)
	hnJgaVLlc6 = Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG)
	if hnJgaVLlc6:
		KBOhIsF60aWxpUk8qwvcjiVHGXe = dm7KA8MukvxF3iH9CW2ZNc('dict',hnJgaVLlc6)
		sQaL1mM02pgbtPGkDJl35KEudjxc = KBOhIsF60aWxpUk8qwvcjiVHGXe['data']['contentFeed']['edges']
		for a69exUYRF2LzksroI0iN5c8qOX in sQaL1mM02pgbtPGkDJl35KEudjxc:
			KS5UPc7G4x38Lp = str(a69exUYRF2LzksroI0iN5c8qOX['node']['post']['duration'])
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(a69exUYRF2LzksroI0iN5c8qOX['node']['post']['title'])
			title = title.replace('\/','/')
			zsdRxrTfwubng7DPQyKkmH6 = a69exUYRF2LzksroI0iN5c8qOX['node']['post']['xid']
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = a69exUYRF2LzksroI0iN5c8qOX['node']['post']['thumbnailx480']
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.replace('\/','/')
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/video/'+zsdRxrTfwubng7DPQyKkmH6
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,403,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,KS5UPc7G4x38Lp)
		if '"hasNextPage":true' in hnJgaVLlc6:
			sbNukjOf4chz = str(int(sbNukjOf4chz)+1)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+sbNukjOf4chz,url,416,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz)
	return
def Qc3HnKCVPAixY8fozO2lwSRtv45Dh(ySY5NxERP6jeVG,search=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: ySY5NxERP6jeVG = ySY5NxERP6jeVG.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	hJmK4bEU382jvHrDNTuXR6xkqA1stV = vEC7k2l81MT4FdZB0YLVG5AKX()
	headers = {"Authorization":hJmK4bEU382jvHrDNTuXR6xkqA1stV,"Origin":hhD7r1VvaPt3TC06SJjqKRfEid}
	if search:
		FFwVakdM8NvjeJRK3oyQI9ti24 = AaDNk2mVEBhCvQH
		headers.update({'Content-Type':'application/json','Referer':hhD7r1VvaPt3TC06SJjqKRfEid+'/','X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		FFwVakdM8NvjeJRK3oyQI9ti24 = wkbMLZA1UPQtRnDcmri7qyHz
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',wkbMLZA1UPQtRnDcmri7qyHz,ySY5NxERP6jeVG,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'DAILYMOTION-GET_PAGEDATA-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	return II64TLxj3mbqEyh9pHQ8oAv
def vEC7k2l81MT4FdZB0YLVG5AKX():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'DAILYMOTION-GET_AUTHINTICATION-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	jxt5Vl7gsaJwrp4iMuPNTWv3y8edn = jj0dZrgiKb.findall('apiClientId.*?return"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	jxt5Vl7gsaJwrp4iMuPNTWv3y8edn = jxt5Vl7gsaJwrp4iMuPNTWv3y8edn[wTLFCOcM26fmYlW7U]
	qglasoYFHTxEWXu8eZyGbc5Op = jj0dZrgiKb.findall('apiClientSecret.*?return"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	qglasoYFHTxEWXu8eZyGbc5Op = qglasoYFHTxEWXu8eZyGbc5Op[wTLFCOcM26fmYlW7U]
	ziUDBwxMpN4QITmrsbKuS0W = 'https://graphql.api.dailymotion.com/oauth/token'
	EtPIW3GxrTiRY = 'client_credentials'
	data = {'client_id':jxt5Vl7gsaJwrp4iMuPNTWv3y8edn,'client_secret':qglasoYFHTxEWXu8eZyGbc5Op,'grant_type':EtPIW3GxrTiRY}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',ziUDBwxMpN4QITmrsbKuS0W,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pZcRkOClfyAST5UV8 = jj0dZrgiKb.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	H2HT0d3fpJYls8ZicDObQjC,mwLAulUFCh42rMkZ9XIR5o7fc6Dy = pZcRkOClfyAST5UV8[0]
	hJmK4bEU382jvHrDNTuXR6xkqA1stV = mwLAulUFCh42rMkZ9XIR5o7fc6Dy+" "+H2HT0d3fpJYls8ZicDObQjC
	return hJmK4bEU382jvHrDNTuXR6xkqA1stV
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search,mmZUvVcxAqEg0FN=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not mmZUvVcxAqEg0FN and showDialogs:
		C2Be47hdV3f = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('موقع ديلي موشن - اختر البحث',C2Be47hdV3f)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-1: return
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==0: mmZUvVcxAqEg0FN = 'videos?sortBy='
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==1: mmZUvVcxAqEg0FN = 'videos?sortBy=RECENT'
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==2: mmZUvVcxAqEg0FN = 'videos?sortBy=VIEW_COUNT'
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==3: mmZUvVcxAqEg0FN = 'playlists'
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==4: mmZUvVcxAqEg0FN = 'channels'
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==5: mmZUvVcxAqEg0FN = 'lives'
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==6: mmZUvVcxAqEg0FN = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in plQAPdho26aj: mmZUvVcxAqEg0FN = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in plQAPdho26aj: mmZUvVcxAqEg0FN = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in plQAPdho26aj: mmZUvVcxAqEg0FN = 'channels'
	elif '_DAILYMOTION-LIVES_' in plQAPdho26aj: mmZUvVcxAqEg0FN = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in plQAPdho26aj: mmZUvVcxAqEg0FN = 'hashtags'
	elif not mmZUvVcxAqEg0FN: mmZUvVcxAqEg0FN = 'videos?sortBy='
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	if 'videos' in mmZUvVcxAqEg0FN: DevtzP0yxIAi45QqwMVa68h(search+'/'+mmZUvVcxAqEg0FN)
	elif 'playlists' in mmZUvVcxAqEg0FN: AhRlajcPG29F0Q3tZrUS(search)
	elif 'channels' in mmZUvVcxAqEg0FN: O5OBF0xKLZ(search)
	elif 'lives' in mmZUvVcxAqEg0FN: kkQgS3I2TUAx1pKije(search)
	elif 'hashtags' in mmZUvVcxAqEg0FN: vmuFcitxg23U(search)
	return