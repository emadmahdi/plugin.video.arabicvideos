# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ὾")
fralhukYZXHyPzw4WL7mQ2MI1Oq = []
headers = {xm6jK1ZMuWq5(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ὿"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
def SSZRl9df4q2Bw6HyJYkbrNLFK(url,qBAaHk7YdDIecXOT,zeSr7gHnFV8MxW9vDOjmy3LacK):
	url = url.replace(xm6jK1ZMuWq5(u"ࠧ࠰࡯࡬ࡶࡷࡵࡲ࠰ࠩᾀ"),MFhbWia58mP3su0fk2d(u"ࠨ࠱࡬ࡪࡷࡧ࡭ࡦ࠱ࠪᾁ")).replace(VhqD3zp7mUieI8sMQlETH(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ᾂ"),w8JC1y7Lp3(u"ࠪ࠳࡮࡬ࡲࡢ࡯ࡨ࠳ࠬᾃ"))
	url = url.replace(DpRJnas65uVcO0S17dYG(u"ࠫ࠴ࡽ࠮࡮ࡧࡪࡥࡲࡧࡸ࠯࡯ࡨ࠳ࠬᾄ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠵࡭ࡦࡩࡤࡱࡦࡾ࠮࡮ࡧ࠲ࠫᾅ"))
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,jQv0du1iVxTgAXCM(u"࠭ࡇࡆࡖࠪᾆ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒࡋࡇࡂࡏࡄ࡜࠲࠷ࡳࡵࠩᾇ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	tXs9r8fAR6vBk1xVKOuUWcog = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠨࡴࡹࡴࡺ࠻࠻ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿ࠬᾈ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	headers = {w8JC1y7Lp3(u"࡛ࠩ࠱ࡎࡴࡥࡳࡶ࡬ࡥࠬᾉ"):weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡸࡷࡻࡥࠨᾊ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠫ࡝࠳ࡉ࡯ࡧࡵࡸ࡮ࡧ࠭ࡑࡣࡵࡸ࡮ࡧ࡬࠮ࡆࡤࡸࡦ࠭ᾋ"):kPCxIUZb1V(u"ࠬࡹࡴࡳࡧࡤࡱࡸ࠭ᾌ"),s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡘ࠮ࡋࡱࡩࡷࡺࡩࡢ࠯ࡓࡥࡷࡺࡩࡢ࡮࠰ࡇࡴࡳࡰࡰࡰࡨࡲࡹ࠭ᾍ"):D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡧ࡫࡯ࡩࡸ࠵࡭ࡪࡴࡵࡳࡷ࠵ࡶࡪࡦࡨࡳࠬᾎ")}
	headers[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨ࡚࠰ࡍࡳ࡫ࡲࡵ࡫ࡤ࠱࡛࡫ࡲࡴ࡫ࡲࡲࠬᾏ")] = tXs9r8fAR6vBk1xVKOuUWcog[wTLFCOcM26fmYlW7U]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,jQv0du1iVxTgAXCM(u"ࠩࡊࡉ࡙࠭ᾐ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎࡇࡊࡅࡒࡇࡘ࠮࠴ࡱࡨࠬᾑ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	OpcuQiFsn7MfAlz = bbeLsVCqouaSH53E0XmKh4AnFD.loads(II64TLxj3mbqEyh9pHQ8oAv)
	qEXz2CTH8cwhQePfG6Ydsg = OpcuQiFsn7MfAlz[vWNRusF46D7Mi8GpZ(u"ࠫࡵࡸ࡯ࡱࡵࠪᾒ")][rDG9dZoXRhCJcieUSF0KB(u"ࠬࡹࡴࡳࡧࡤࡱࡸ࠭ᾓ")][s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡤࡢࡶࡤࠫᾔ")]
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	for aJQuONIydj in range(len(qEXz2CTH8cwhQePfG6Ydsg)):
		KwSdzRXT0M3VW = qEXz2CTH8cwhQePfG6Ydsg[aJQuONIydj][JHMxIE4fs1mvQtKW7R(u"ࠧ࡭ࡣࡥࡩࡱ࠭ᾕ")]
		ppAJI9kDbz5MXa76UEF = qEXz2CTH8cwhQePfG6Ydsg[aJQuONIydj][DpRJnas65uVcO0S17dYG(u"ࠨ࡯࡬ࡶࡷࡵࡲࡴࠩᾖ")]
		for BHGtqrpXJ146YKovg in range(len(ppAJI9kDbz5MXa76UEF)):
			title = ppAJI9kDbz5MXa76UEF[BHGtqrpXJ146YKovg][A6Sg45ChDR3BJLYfFH(u"ࠩࡧࡶ࡮ࡼࡥࡳࠩᾗ")]
			hhEH1rcSP0z6Bkqy8OD = weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪᾘ")+ppAJI9kDbz5MXa76UEF[BHGtqrpXJ146YKovg][VhqD3zp7mUieI8sMQlETH(u"ࠫࡱ࡯࡮࡬ࠩᾙ")]+D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᾚ")+title+JHMxIE4fs1mvQtKW7R(u"࠭࡟ࡠࠩᾛ")+qBAaHk7YdDIecXOT+rDG9dZoXRhCJcieUSF0KB(u"ࠧࡠࡡࠪᾜ")+KwSdzRXT0M3VW
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	return jcInvNf98TZ5gRUDFp40li2uzVPrO
def pBRInuQfWwAC5TF1EoS76sgaV(url,qBAaHk7YdDIecXOT,zeSr7gHnFV8MxW9vDOjmy3LacK):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,MFhbWia58mP3su0fk2d(u"ࠨࡉࡈࡘࠬᾝ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,DpRJnas65uVcO0S17dYG(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡁࡍࡄࡄࡔࡑࡇ࡙ࡆࡔ࠰࠵ࡸࡺࠧᾞ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(II64TLxj3mbqEyh9pHQ8oAv,bytes): II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,Gj3rMP1Cb8wHdp49la0(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᾟ"))
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠫࠧࡧࡰ࡭ࡴ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᾠ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall(s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡳࡰࡷ࠳࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᾡ"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		jcInvNf98TZ5gRUDFp40li2uzVPrO = []
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+D2PpKMeZFWrmfxTSs4L1tz(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᾢ")+title+it4DKnryZlx(u"ࠧࡠࡡࠪᾣ")+qBAaHk7YdDIecXOT)
	return jcInvNf98TZ5gRUDFp40li2uzVPrO
def HDou8bLwq53Z0d(url,qBAaHk7YdDIecXOT,zeSr7gHnFV8MxW9vDOjmy3LacK):
	kEXm3DGNaRFdyw = url.split(bQGafNLXyFgsZP6ut(u"ࠨ࠱ࠪᾤ"))[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠸࿙")]
	o6lhI3gZLYS5m9VTNHwpxv1M = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(kEXm3DGNaRFdyw)
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: o6lhI3gZLYS5m9VTNHwpxv1M = o6lhI3gZLYS5m9VTNHwpxv1M.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	WCmwQY8LDyB5 = Z6bUG0kDQuFqgzdAa1r(o6lhI3gZLYS5m9VTNHwpxv1M)+erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᾥ")+zeSr7gHnFV8MxW9vDOjmy3LacK
	return [WCmwQY8LDyB5]
def J1iUIXLptg2TqMmf(Igc48GtTrWklyiNSPmV,source):
	lCtvKHMzLJVo8fERq9N5,rrljg86ox1nOHMbcyEp20kFvfZ = [],[]
	for mNf0VWq3Fw in Igc48GtTrWklyiNSPmV:
		D2eQ8jwIuaGZUoW41HbtKi63L9x = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠪࡲࡦࡳࡥࡥ࠿࠱࠮ࡄࡥ࡟ࠩ࠰࠭ࡃ࠮ࡥ࡟ࠨᾦ"),mNf0VWq3Fw+vWNRusF46D7Mi8GpZ(u"ࠫࡤࡥࠧᾧ"),jj0dZrgiKb.DOTALL)
		ItrEiBJkUgYnSwOARpeaQoc = D2eQ8jwIuaGZUoW41HbtKi63L9x[wTLFCOcM26fmYlW7U] if D2eQ8jwIuaGZUoW41HbtKi63L9x else wUvcPrYDfISbZolAm83GKEqMyXkn5
		wCknNHAGpaMsJUB1bY8gv,XCI2w85WPiH04g1KMmAYbGeaVvfD,s7s0wmIdLNrB9Vl5n = mNf0VWq3Fw,wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
		if fmkZtbRj3ux(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᾨ") in mNf0VWq3Fw: wCknNHAGpaMsJUB1bY8gv,XCI2w85WPiH04g1KMmAYbGeaVvfD = mNf0VWq3Fw.split(bQGafNLXyFgsZP6ut(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᾩ"),UD4N8MjVTd)
		try:
			if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡢ࡮ࡥࡥࡵࡲࡡࡺࡧࡵࠫᾪ") in wCknNHAGpaMsJUB1bY8gv: s7s0wmIdLNrB9Vl5n = pBRInuQfWwAC5TF1EoS76sgaV(wCknNHAGpaMsJUB1bY8gv,ItrEiBJkUgYnSwOARpeaQoc,XCI2w85WPiH04g1KMmAYbGeaVvfD)
			elif kPCxIUZb1V(u"ࠨ࡯ࡨ࡫ࡦࡳࡡࡹࠩᾫ") in wCknNHAGpaMsJUB1bY8gv: s7s0wmIdLNrB9Vl5n = SSZRl9df4q2Bw6HyJYkbrNLFK(wCknNHAGpaMsJUB1bY8gv,ItrEiBJkUgYnSwOARpeaQoc,XCI2w85WPiH04g1KMmAYbGeaVvfD)
			elif xdSThjYnuHXAU6M(u"ࠩ࠲ࡰ࠴ࡧࡈࡓ࠲ࡦࡌࡒ࠼ࡌࡺ࠻ࠪᾬ") in wCknNHAGpaMsJUB1bY8gv: s7s0wmIdLNrB9Vl5n = HDou8bLwq53Z0d(wCknNHAGpaMsJUB1bY8gv,ItrEiBJkUgYnSwOARpeaQoc,XCI2w85WPiH04g1KMmAYbGeaVvfD)
		except: pass
		if s7s0wmIdLNrB9Vl5n:
			for q4zyW5Bpx6Y2O in s7s0wmIdLNrB9Vl5n:
				NNtKIuX1mdv8aq,mwVoIdpJg0s4l3zMPU1Yj = q4zyW5Bpx6Y2O,wUvcPrYDfISbZolAm83GKEqMyXkn5
				if Gj3rMP1Cb8wHdp49la0(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᾭ") in q4zyW5Bpx6Y2O: NNtKIuX1mdv8aq,mwVoIdpJg0s4l3zMPU1Yj = q4zyW5Bpx6Y2O.split(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᾮ"),UD4N8MjVTd)
				if NNtKIuX1mdv8aq not in lCtvKHMzLJVo8fERq9N5:
					lCtvKHMzLJVo8fERq9N5.append(NNtKIuX1mdv8aq)
					rrljg86ox1nOHMbcyEp20kFvfZ.append(q4zyW5Bpx6Y2O)
		elif wCknNHAGpaMsJUB1bY8gv not in lCtvKHMzLJVo8fERq9N5:
			lCtvKHMzLJVo8fERq9N5.append(wCknNHAGpaMsJUB1bY8gv)
			rrljg86ox1nOHMbcyEp20kFvfZ.append(mNf0VWq3Fw)
	return rrljg86ox1nOHMbcyEp20kFvfZ
def KXwrlLNmueDxzR6q3djfv(source,KUOoYcT20iCLVgsw1ejzdkHp7XW,url):
	KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+bQGafNLXyFgsZP6ut(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬᾯ")+source+yRWQMHxZEz0(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧᾰ")+KUOoYcT20iCLVgsw1ejzdkHp7XW+fmkZtbRj3ux(u"ࠧࠡ࡟ࠪᾱ"))
	ccZreg3uG9VCj7qJfvaFkMysE6Q = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡦ࡬ࡧࡹ࠭ᾲ"),bQGafNLXyFgsZP6ut(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬᾳ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩᾴ"))
	Rl9VtN3vWZ8u = L5jXH0fZ8TvsESR.strftime(yRWQMHxZEz0(u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ᾵"),L5jXH0fZ8TvsESR.gmtime(yoJ7t3WpjPkrCmTq))
	yqH8GM4tr32YXobgA9ZkhsSj0B = Rl9VtN3vWZ8u,url
	key = source+fy2aLFcjDnoxIzGi1gp7+D1DBSuO0lLGRbcfCyY+fy2aLFcjDnoxIzGi1gp7+str(Uy6GWujQiBLhodP)
	SLAiUwpDRoZIQfvB7 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if key not in list(ccZreg3uG9VCj7qJfvaFkMysE6Q.keys()): ccZreg3uG9VCj7qJfvaFkMysE6Q[key] = [yqH8GM4tr32YXobgA9ZkhsSj0B]
	else:
		if url not in str(ccZreg3uG9VCj7qJfvaFkMysE6Q[key]): ccZreg3uG9VCj7qJfvaFkMysE6Q[key].append(yqH8GM4tr32YXobgA9ZkhsSj0B)
		else: SLAiUwpDRoZIQfvB7 = vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡢ࡮้ࠡำหࠥอไโ์า๎ํࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥะูๆๆࠪᾶ")
	xCo0h7D8lYiIu = wTLFCOcM26fmYlW7U
	for key in list(ccZreg3uG9VCj7qJfvaFkMysE6Q.keys()):
		ccZreg3uG9VCj7qJfvaFkMysE6Q[key] = list(set(ccZreg3uG9VCj7qJfvaFkMysE6Q[key]))
		xCo0h7D8lYiIu += len(ccZreg3uG9VCj7qJfvaFkMysE6Q[key])
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧᾷ")+SLAiUwpDRoZIQfvB7+rDG9dZoXRhCJcieUSF0KB(u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭Ᾰ")+xdSThjYnuHXAU6M(u"ࠨ࡞ࡱࡠࡳ࠭Ᾱ")+jQv0du1iVxTgAXCM(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬᾺ")+str(xCo0h7D8lYiIu))
	if xCo0h7D8lYiIu>=ewJ9sTMmXtWH0ANVShQ2:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,yRWQMHxZEz0(u"ࠪห้ฮั็ษ่ะࠥาๅฺࠢๅหห๋ษࠡใํ๋ฬࠦ࠵ࠡใํำ๏๎็ศฬ่๊๊ࠣࠦอัࠣห้ฮั็ษ่ะ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰ࠣืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮๅิฯ๋ࠣีํࠠศๆๅหห๋ษࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦำึห้ࠦ็ั้ࠣห้่วว็ฬࠤ็ฮไࠡ็ึั์อࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆ่ฬึ๋ฬࠡสไัฺࠦ็ั้ࠣห้็๊ะ์๋๋ฬะࠠภࠣࠤࠫΆ"))
		if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
			ddD6eo5yB9MSLA = wUvcPrYDfISbZolAm83GKEqMyXkn5
			for key in list(ccZreg3uG9VCj7qJfvaFkMysE6Q.keys()):
				ddD6eo5yB9MSLA += QWLr8ABjev+key
				g2thTAxRvSlHKZzLubEfPjcW7GOq = sorted(ccZreg3uG9VCj7qJfvaFkMysE6Q[key],reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda ygEvRHDnBFxTIoi51freNVps: ygEvRHDnBFxTIoi51freNVps[wTLFCOcM26fmYlW7U])
				for Rl9VtN3vWZ8u,url in g2thTAxRvSlHKZzLubEfPjcW7GOq:
					ddD6eo5yB9MSLA += QWLr8ABjev+Rl9VtN3vWZ8u+fy2aLFcjDnoxIzGi1gp7+Z6bUG0kDQuFqgzdAa1r(url)
				ddD6eo5yB9MSLA += erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡡࡴ࡜࡯ࠩᾼ")
			import tdeCZlJnBw
			n453i9Fwpc6bGMuUa2l = tdeCZlJnBw.UJgqTYtFZ5l1EvzsfRI(JHMxIE4fs1mvQtKW7R(u"ࠬ࡜ࡩࡥࡧࡲࡷࠬ᾽"),wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡉࡇࡔࡆࡡࡈࡑࡕ࡚࡙ࡠࡘࡌࡈࡊࡕࡓࡠࡎࡌࡗ࡙࠭ι"),wUvcPrYDfISbZolAm83GKEqMyXkn5,ddD6eo5yB9MSLA)
			if n453i9Fwpc6bGMuUa2l: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ᾿"))
			else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"ࠨใื่ฯูࠦๆๆํอࠥอไฦำึห้࠭῀"))
		if ug0EmiKYnRT1qeH9MFyr3pO!=-UD4N8MjVTd:
			ccZreg3uG9VCj7qJfvaFkMysE6Q = {}
			P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ῁"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩῂ"))
	if ccZreg3uG9VCj7qJfvaFkMysE6Q: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,jQv0du1iVxTgAXCM(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧῃ"),bQGafNLXyFgsZP6ut(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫῄ"),ccZreg3uG9VCj7qJfvaFkMysE6Q,pHC2Aj4kbc3KDN0aZWBey6QV)
	return
def cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,source,KUOoYcT20iCLVgsw1ejzdkHp7XW,url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,source,KUOoYcT20iCLVgsw1ejzdkHp7XW,url = mLh8JBt075iUqNOSDCVFsPIM6KgzGc(jcInvNf98TZ5gRUDFp40li2uzVPrO,source,KUOoYcT20iCLVgsw1ejzdkHp7XW,url)
	if not jcInvNf98TZ5gRUDFp40li2uzVPrO:
		KXwrlLNmueDxzR6q3djfv(source,KUOoYcT20iCLVgsw1ejzdkHp7XW,url)
		return
	AeNt1wShKYUqvMWs7P4CjLgm9f5dcb = OOnvcPQy85HYA.getSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ῅"))
	RTNBVpyXAkq05zEeU17OYjs9biZCa = Gj3rMP1Cb8wHdp49la0(u"ࠧ࠮ࠩῆ") not in AeNt1wShKYUqvMWs7P4CjLgm9f5dcb
	s7s0wmIdLNrB9Vl5n = J1iUIXLptg2TqMmf(jcInvNf98TZ5gRUDFp40li2uzVPrO[:],source)
	if s7s0wmIdLNrB9Vl5n!=jcInvNf98TZ5gRUDFp40li2uzVPrO and not RTNBVpyXAkq05zEeU17OYjs9biZCa:
		Y3EMdn7v4pDgXj9kiw = []
		for mNf0VWq3Fw in jcInvNf98TZ5gRUDFp40li2uzVPrO:
			jjbyxDMLGXego,zeSr7gHnFV8MxW9vDOjmy3LacK = mNf0VWq3Fw,wUvcPrYDfISbZolAm83GKEqMyXkn5
			if w8JC1y7Lp3(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩῇ") in mNf0VWq3Fw: jjbyxDMLGXego,zeSr7gHnFV8MxW9vDOjmy3LacK = mNf0VWq3Fw.split(D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪῈ"),UD4N8MjVTd)
			zeSr7gHnFV8MxW9vDOjmy3LacK = zeSr7gHnFV8MxW9vDOjmy3LacK.replace(TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫΈ"),xm6jK1ZMuWq5(u"ࠫࠬῊ")).replace(DpRJnas65uVcO0S17dYG(u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩΉ"),A6Sg45ChDR3BJLYfFH(u"࠭ࠧῌ")).replace(xm6jK1ZMuWq5(u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ῍"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࠩ῎"))
			Y3EMdn7v4pDgXj9kiw.append(zeSr7gHnFV8MxW9vDOjmy3LacK)
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩศ฼์อัࠡไ๋หห๋ࠠศๆฯ์ิฯࠧ῏"),Y3EMdn7v4pDgXj9kiw)
	jcInvNf98TZ5gRUDFp40li2uzVPrO = list(set(s7s0wmIdLNrB9Vl5n))
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = qP0pj67cFb3IkvyGHxAn8Z(jcInvNf98TZ5gRUDFp40li2uzVPrO,source)
	if TTuO14NzmB.resolveonly:
		UUuclLqGvpzHmrA = BXOg2YQb6tf1TMKEroLl(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,source,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		return
	zzdYS30xovW64UG,JCxwmazEp2i5eGIZt1,yxarqeUO7KJXfzd,UUuclLqGvpzHmrA,I4WxcCFHGspuKr8oMAqdw72hvZfUy,o4oW9wDcsrpHQS816yfIvg = Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,[],wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	wvq0GbpO4eQBjYL2Fo6V59kZ = Z19pUxa2gfGMNKoDsEuytn85SjFvA if source in T9YiNsnuHzr else y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if wvq0GbpO4eQBjYL2Fo6V59kZ:
		D654p9ATEQf0BKm7ge = wTLFCOcM26fmYlW7U
		VycGZq3oCT = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡰ࡮ࡹࡴࠨῐ"),w8JC1y7Lp3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡖࡅࡆࡉࡊࡊࡅࡅࠩῑ"))
		wuiMCfs0lDy = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,JHMxIE4fs1mvQtKW7R(u"ࠬࡲࡩࡴࡶࠪῒ"),jQv0du1iVxTgAXCM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡗࡑࡏࡓࡕࡗࡏࠩΐ"))
		FmO8Tkp0H1da = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,Gj3rMP1Cb8wHdp49la0(u"ࠧ࡭࡫ࡶࡸࠬ῔"),lCT8hfYUBX4OQMmL(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪ῕"))
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = wTLFCOcM26fmYlW7U
		for title,hhEH1rcSP0z6Bkqy8OD in list(zip(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)):
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split(xdSThjYnuHXAU6M(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪῖ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
			if hhEH1rcSP0z6Bkqy8OD in VycGZq3oCT:
				D654p9ATEQf0BKm7ge += UD4N8MjVTd
				Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = FFzTCtAXg8jpl+title+AAByQSLgaZwCsKnvc5eWNmY
			elif hhEH1rcSP0z6Bkqy8OD in FmO8Tkp0H1da:
				D654p9ATEQf0BKm7ge += UD4N8MjVTd
				Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = JegF7SlMawI03+title+AAByQSLgaZwCsKnvc5eWNmY
			elif hhEH1rcSP0z6Bkqy8OD in wuiMCfs0lDy:
				D654p9ATEQf0BKm7ge += UD4N8MjVTd
				Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = title
			else:
				D654p9ATEQf0BKm7ge += UD4N8MjVTd
				Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = title
			xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 += UD4N8MjVTd
		o4oW9wDcsrpHQS816yfIvg = [QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+llkFwuCyhaP3sK76qO4T(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨῗ")+AAByQSLgaZwCsKnvc5eWNmY]
	else: I4WxcCFHGspuKr8oMAqdw72hvZfUy = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+A6Sg45ChDR3BJLYfFH(u"ࠫศิสาࠢสุ่๐ัโำࠣห้๋ๆศีหࠫῘ")+AAByQSLgaZwCsKnvc5eWNmY
	while y0yvdNOZkiKEg5RLMhoDVQAB9F2:
		WWBvYzMJOH7Gkqd1LE2F = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if wvq0GbpO4eQBjYL2Fo6V59kZ:
			if RTNBVpyXAkq05zEeU17OYjs9biZCa and len(Eu8LWnSt3fyJzIC)==UD4N8MjVTd: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = UD4N8MjVTd
			else:
				RdjiXJgavslEGzhm6NIq3kT0xcwV = str(Eu8LWnSt3fyJzIC).count(FFzTCtAXg8jpl)
				QXxUzJAkGNVS8u6nWtsHDPrmCjq = str(Eu8LWnSt3fyJzIC).count(JegF7SlMawI03)
				LL2TUhRa1OJgYrm = len(Eu8LWnSt3fyJzIC)-RdjiXJgavslEGzhm6NIq3kT0xcwV-QXxUzJAkGNVS8u6nWtsHDPrmCjq
				if ndib93Ol6UojCrEV: I4WxcCFHGspuKr8oMAqdw72hvZfUy = JegF7SlMawI03+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦࠠࠡีํสฮࡀࠧῙ")+str(QXxUzJAkGNVS8u6nWtsHDPrmCjq)+AAByQSLgaZwCsKnvc5eWNmY+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"่࠭ࠠࠡࠢะ์๎ไส࠼ࠪῚ")+str(LL2TUhRa1OJgYrm)+FFzTCtAXg8jpl+fmkZtbRj3ux(u"ࠧอ์าอ࠿࠭Ί")+str(RdjiXJgavslEGzhm6NIq3kT0xcwV)+AAByQSLgaZwCsKnvc5eWNmY
				else: I4WxcCFHGspuKr8oMAqdw72hvZfUy = FFzTCtAXg8jpl+xdSThjYnuHXAU6M(u"ࠨฮํำฮࡀࠧ῜")+str(RdjiXJgavslEGzhm6NIq3kT0xcwV)+AAByQSLgaZwCsKnvc5eWNmY+it4DKnryZlx(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭῝")+str(LL2TUhRa1OJgYrm)+JegF7SlMawI03+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࠤࠥࠦำ๋ศฬ࠾ࠬ῞")+str(QXxUzJAkGNVS8u6nWtsHDPrmCjq)+AAByQSLgaZwCsKnvc5eWNmY
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(I4WxcCFHGspuKr8oMAqdw72hvZfUy,o4oW9wDcsrpHQS816yfIvg+Eu8LWnSt3fyJzIC)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==wTLFCOcM26fmYlW7U:
				WWBvYzMJOH7Gkqd1LE2F = Z19pUxa2gfGMNKoDsEuytn85SjFvA
				start,end = wTLFCOcM26fmYlW7U,len(Eu8LWnSt3fyJzIC)-UD4N8MjVTd
				UUuclLqGvpzHmrA = BXOg2YQb6tf1TMKEroLl(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,source,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
				yxarqeUO7KJXfzd = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩࡥࡡ࡭࡮ࠪ῟") if UUuclLqGvpzHmrA else bQGafNLXyFgsZP6ut(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭ῠ")
			elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq>wTLFCOcM26fmYlW7U: start,end = EcQws7L35GvtIpl0k1gJZWTNPDbmMq-UD4N8MjVTd,EcQws7L35GvtIpl0k1gJZWTNPDbmMq-UD4N8MjVTd
		else:
			if RTNBVpyXAkq05zEeU17OYjs9biZCa and len(Eu8LWnSt3fyJzIC)==UD4N8MjVTd: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = wTLFCOcM26fmYlW7U
			else: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(I4WxcCFHGspuKr8oMAqdw72hvZfUy,Eu8LWnSt3fyJzIC)
			start,end = EcQws7L35GvtIpl0k1gJZWTNPDbmMq,EcQws7L35GvtIpl0k1gJZWTNPDbmMq
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd:
			yxarqeUO7KJXfzd = A6Sg45ChDR3BJLYfFH(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨῡ")
			break
		if WWBvYzMJOH7Gkqd1LE2F:
			yxarqeUO7KJXfzd = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡲࡲࡪ࠭ῢ")
			UUuclLqGvpzHmrA = BXOg2YQb6tf1TMKEroLl([Eu8LWnSt3fyJzIC[start]],[j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[start]],source,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
			title,hhEH1rcSP0z6Bkqy8OD,JCxwmazEp2i5eGIZt1,kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF,ctCxK28a6Q = UUuclLqGvpzHmrA[wTLFCOcM26fmYlW7U]
			VLhKBFOXMf3yk19zPZHugW,hgXa8muV59DtnIGBElM1HO3P2fyrYb = q0Pzi5jnbHrIwBDys4UvZ(title,hhEH1rcSP0z6Bkqy8OD,kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF,source,KUOoYcT20iCLVgsw1ejzdkHp7XW)
			if VLhKBFOXMf3yk19zPZHugW in [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ΰ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪῤ"),DpRJnas65uVcO0S17dYG(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫῥ")]:
				zzdYS30xovW64UG = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				break
			else:
				if not JCxwmazEp2i5eGIZt1: JCxwmazEp2i5eGIZt1 = erqDsJmL3BQHuGtPkcf0X9(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠨῦ")
				title = JegF7SlMawI03+title+AAByQSLgaZwCsKnvc5eWNmY
				UUuclLqGvpzHmrA[wTLFCOcM26fmYlW7U] = title,hhEH1rcSP0z6Bkqy8OD,JCxwmazEp2i5eGIZt1,kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF,ctCxK28a6Q
				ozSFa51O3HWd6qJGTCPjEU7McBvVeX = hhEH1rcSP0z6Bkqy8OD.split(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ῧ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
				P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,Gj3rMP1Cb8wHdp49la0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇࠫῨ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX)
				if it4DKnryZlx(u"ࠧࡺࡱࡸࡸࡺ࠭Ῡ") not in url: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,xm6jK1ZMuWq5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪῪ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[JCxwmazEp2i5eGIZt1,title,hhEH1rcSP0z6Bkqy8OD],d2priEnu57KztRsm8wCHZ)
			if JCxwmazEp2i5eGIZt1==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΎ"): break
			ps0uGKYmexncl9hkQj6VLZrJ58Xf = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬῬ")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,Gj3rMP1Cb8wHdp49la0(u"ࠫࡡࡴ࡛ࡍࡇࡉࡘࡢࠦࠠࠨ῭")) if JCxwmazEp2i5eGIZt1.count(QWLr8ABjev)>fmkZtbRj3ux(u"࠸࿚") else QWLr8ABjev+JCxwmazEp2i5eGIZt1
			if ndib93Ol6UojCrEV: ps0uGKYmexncl9hkQj6VLZrJ58Xf = ps0uGKYmexncl9hkQj6VLZrJ58Xf.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭΅") not in source: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,lCT8hfYUBX4OQMmL(u"࠭วๅีํีๆืࠠๅ็ࠣ๎฾๋ไࠡฮิฬู๊ࠥาใิࠤ฿๐ั่࡞ࡱࠫ`")+ps0uGKYmexncl9hkQj6VLZrJ58Xf,profile=llkFwuCyhaP3sK76qO4T(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬ῰"))
			if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==UD4N8MjVTd and JCxwmazEp2i5eGIZt1: break
		for xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in range(start,end+UD4N8MjVTd):
			sQJ6xHcOpUha = wTLFCOcM26fmYlW7U if WWBvYzMJOH7Gkqd1LE2F else xJAIOQKvfpEH5Mn0Z1yUBqVCWY4
			title,hhEH1rcSP0z6Bkqy8OD,JCxwmazEp2i5eGIZt1,kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF,ctCxK28a6Q = UUuclLqGvpzHmrA[sQJ6xHcOpUha]
			Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4].replace(JegF7SlMawI03,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(FFzTCtAXg8jpl,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(PtUz7CDanXZT,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if ctCxK28a6Q==vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࠩ῱"): Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = FFzTCtAXg8jpl+Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]+AAByQSLgaZwCsKnvc5eWNmY
			elif ctCxK28a6Q==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪῲ"): Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = JegF7SlMawI03+Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]+AAByQSLgaZwCsKnvc5eWNmY
			else: Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4] = Eu8LWnSt3fyJzIC[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
	if yxarqeUO7KJXfzd==jQv0du1iVxTgAXCM(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨࠫῳ"): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"้๊ࠫริใ่ࠣฬ๊้ࠦฮาࠤุ๐ัโำสฮࠥา๊ะหࠣๅ๏ࠦ็ัษࠣห้็๊ะ์๋ࠤ࠳࠴ࠠฮษ๋่ࠥษๆࠡฬหัะูࠦ็๊ࠢิฬࠦวๅใํำ๏๎ࠠโ์้ࠣํอโฺࠢฦาึ๏ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠩῴ"))
	if not zzdYS30xovW64UG or yxarqeUO7KJXfzd in [MFhbWia58mP3su0fk2d(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧ῵"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧῶ")] or JCxwmazEp2i5eGIZt1:
		QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(lCT8hfYUBX4OQMmL(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡅ࡯ࡩࡦࡸࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵ࢂࢃࠧῷ"))
	return
def BXOg2YQb6tf1TMKEroLl(hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO,source,showDialogs):
	global fmlEU9aTCy0LIq,Bzd1jaotsQn40CYOW3lrPVAx,t9SPGT0jqag4,chFisl1EqLoprJwu,krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ,xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp
	fmlEU9aTCy0LIq,Bzd1jaotsQn40CYOW3lrPVAx,t9SPGT0jqag4,chFisl1EqLoprJwu = [],[],[],[]
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ,xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp = [],[]
	RCmHBOKtejQ8lu4L,MspXSd8ujkcRoHWF6LAJ,new = [],[],[]
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(uxig7mJanAYQ20,uxig7mJanAYQ20,uxig7mJanAYQ20)
	count = len(jcInvNf98TZ5gRUDFp40li2uzVPrO)
	for aJQuONIydj in range(count):
		fmlEU9aTCy0LIq.append(b02zsRFX8MweUniGfyPHEZcv7p5WK3)
		Bzd1jaotsQn40CYOW3lrPVAx.append(b02zsRFX8MweUniGfyPHEZcv7p5WK3)
		t9SPGT0jqag4.append(b02zsRFX8MweUniGfyPHEZcv7p5WK3)
		chFisl1EqLoprJwu.append(b02zsRFX8MweUniGfyPHEZcv7p5WK3)
		krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ.append(b02zsRFX8MweUniGfyPHEZcv7p5WK3)
		xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp.append(wTLFCOcM26fmYlW7U)
		title = hUXDz2SbBuqmKe6QJO[aJQuONIydj]
		hhEH1rcSP0z6Bkqy8OD = jcInvNf98TZ5gRUDFp40li2uzVPrO[aJQuONIydj].strip(UKFZBQAVXHI5s17LyvuRpCY2).strip(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࠨࠪῸ")).strip(MFhbWia58mP3su0fk2d(u"ࠩࡂࠫΌ")).strip(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࠳ࠬῺ"))
		if count>UD4N8MjVTd and showDialogs: hg79cQmoVfMCukiU8ERpT6JqywSrN3(DpRJnas65uVcO0S17dYG(u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭Ώ")+str(aJQuONIydj+lCT8hfYUBX4OQMmL(u"࠷࿛")),title)
		nVBfYN2o3DeL = [DpRJnas65uVcO0S17dYG(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ῼ"),it4DKnryZlx(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ´"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡂࡍ࡚ࡅࡒ࠭῾")]
		if source in nVBfYN2o3DeL: krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[aJQuONIydj] = G9GACX3bofvMhiKu1I2xq0Ny7L(title,hhEH1rcSP0z6Bkqy8OD,source,aJQuONIydj,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		else:
			if UD4N8MjVTd:
				UiEgeP53aRrcW = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=G9GACX3bofvMhiKu1I2xq0Ny7L,args=(title,hhEH1rcSP0z6Bkqy8OD,source,aJQuONIydj,count==kPCxIUZb1V(u"࠱࿜")))
				MspXSd8ujkcRoHWF6LAJ.append(UiEgeP53aRrcW)
				new.append(aJQuONIydj)
	def ItHUyBTj7Qo():
		ZG9d7oT8KChmVbcMWnXsLvj = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		for hhEH1rcSP0z6Bkqy8OD in krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ:
			if not hhEH1rcSP0z6Bkqy8OD: break
		else: ZG9d7oT8KChmVbcMWnXsLvj = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying() if TTuO14NzmB.resolveonly else y0yvdNOZkiKEg5RLMhoDVQAB9F2
		return ZG9d7oT8KChmVbcMWnXsLvj or not FBe2GQ7zwUmOia
	xxaHzT9pQj6SRDCGIfwydq(MspXSd8ujkcRoHWF6LAJ,MKTOd2VfL57,xx1Qbw9ABV6IYrmHd0vptjElzPf,UD4N8MjVTd,ItHUyBTj7Qo)
	for aJQuONIydj in range(count):
		title = hUXDz2SbBuqmKe6QJO[aJQuONIydj]
		hhEH1rcSP0z6Bkqy8OD = jcInvNf98TZ5gRUDFp40li2uzVPrO[aJQuONIydj].strip(UKFZBQAVXHI5s17LyvuRpCY2).strip(w8JC1y7Lp3(u"ࠨࠨࠪ῿")).strip(llkFwuCyhaP3sK76qO4T(u"ࠫࡄ࠭ࠀ")).strip(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࠵ࠧࠁ"))
		ozSFa51O3HWd6qJGTCPjEU7McBvVeX = hhEH1rcSP0z6Bkqy8OD.split(lCT8hfYUBX4OQMmL(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠂ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U] if aJQuONIydj in new else Z19pUxa2gfGMNKoDsEuytn85SjFvA
		stream = krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[aJQuONIydj]
		if stream and not stream[wTLFCOcM26fmYlW7U] and stream[Tb7oymMnpflsSv3eu4Pz2]:
			ctCxK28a6Q = yRWQMHxZEz0(u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨࠃ")
			ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O = stream
			if ozSFa51O3HWd6qJGTCPjEU7McBvVeX: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ࠄ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O],d2priEnu57KztRsm8wCHZ)
		elif stream and stream[wTLFCOcM26fmYlW7U] and not stream[UD4N8MjVTd] and not stream[Tb7oymMnpflsSv3eu4Pz2]:
			ctCxK28a6Q = w8JC1y7Lp3(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪࠅ")
			ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤ࡝ࡰࠪࠆ")+stream[wTLFCOcM26fmYlW7U],[],[]
			if ozSFa51O3HWd6qJGTCPjEU7McBvVeX: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,JHMxIE4fs1mvQtKW7R(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭ࠇ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O],d2priEnu57KztRsm8wCHZ)
		elif xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[aJQuONIydj]+UD4N8MjVTd>ggrwtFZBzDPHT26L1lu45x:
			ctCxK28a6Q = TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ࠈ")
			ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O = llkFwuCyhaP3sK76qO4T(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡹ࡯࡭ࡦࡦࠣࡳࡺࡺࠠࠩࠩࠉ")+str(xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[aJQuONIydj])+D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪࠊ"),[],[]
			if ozSFa51O3HWd6qJGTCPjEU7McBvVeX: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,xdSThjYnuHXAU6M(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫࠋ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O],d2priEnu57KztRsm8wCHZ)
		elif not stream:
			ctCxK28a6Q = D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡦࡥࡳࡩࡥ࡭ࠩࠌ")
			ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠪࠍ"),[],[]
			if ozSFa51O3HWd6qJGTCPjEU7McBvVeX: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧࠎ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O],d2priEnu57KztRsm8wCHZ)
		else:
			ctCxK28a6Q = MFhbWia58mP3su0fk2d(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ࠏ")
			ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O = erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡵࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ࠐ"),[],[]
			if ozSFa51O3HWd6qJGTCPjEU7McBvVeX: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,VhqD3zp7mUieI8sMQlETH(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪࠑ"),ozSFa51O3HWd6qJGTCPjEU7McBvVeX,[ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O],d2priEnu57KztRsm8wCHZ)
		RCmHBOKtejQ8lu4L.append([title,hhEH1rcSP0z6Bkqy8OD,ps0uGKYmexncl9hkQj6VLZrJ58Xf,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O,ctCxK28a6Q])
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(cc2JaqoYp8m,cc2JaqoYp8m,cc2JaqoYp8m)
	return RCmHBOKtejQ8lu4L
def G9GACX3bofvMhiKu1I2xq0Ny7L(xG6n4Wq2Ib7YgpiarHUNLQJM0,url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe,e6rQXC0BmMRPqno79Hu):
	global krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ,xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp
	xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = wTLFCOcM26fmYlW7U
	V1VfMqTkXdYulSwF75JPhDgZ = L5jXH0fZ8TvsESR.time()
	WxHAl8FOEtZcTS = QEbx35yvreoT2sPDG4k9Fcfa8Z(url)
	KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩࠒ")+xG6n4Wq2Ib7YgpiarHUNLQJM0+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭ࠓ")+WxHAl8FOEtZcTS+MFhbWia58mP3su0fk2d(u"ࠪࠤࡢ࠭ࠔ"))
	hhEH1rcSP0z6Bkqy8OD,glOmfke2LpTv8jWGZDSsboMq = url,wUvcPrYDfISbZolAm83GKEqMyXkn5
	dKtZRl5Wa3e = A6Sg45ChDR3BJLYfFH(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨࠕ")
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = BBE5GZn4KS7I(url,source)
	if JCxwmazEp2i5eGIZt1==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠖ"):
		krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = vWNRusF46D7Mi8GpZ(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠗ"),[],[]
		xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = L5jXH0fZ8TvsESR.time()-V1VfMqTkXdYulSwF75JPhDgZ
		return krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
	elif D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࠘") in JCxwmazEp2i5eGIZt1:
		glOmfke2LpTv8jWGZDSsboMq = Gj3rMP1Cb8wHdp49la0(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥ࠮࠲࠮࠷ࠬࠫ࠙")
		hhEH1rcSP0z6Bkqy8OD = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)[wTLFCOcM26fmYlW7U]
		dKtZRl5Wa3e,glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = kvjCF6tWeubXB0zUAHos3dQVYx(glOmfke2LpTv8jWGZDSsboMq,hhEH1rcSP0z6Bkqy8OD,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe)
		if glOmfke2LpTv8jWGZDSsboMq==A6Sg45ChDR3BJLYfFH(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࠚ"):
			krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
			xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = L5jXH0fZ8TvsESR.time()-V1VfMqTkXdYulSwF75JPhDgZ
			return glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	elif JCxwmazEp2i5eGIZt1: glOmfke2LpTv8jWGZDSsboMq = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪࠛ")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)[:rDG9dZoXRhCJcieUSF0KB(u"࠹࠲࿝")]
	T0WMELQpsqxy7UD6PkolrJNZRCbFu = QEbx35yvreoT2sPDG4k9Fcfa8Z(hhEH1rcSP0z6Bkqy8OD)
	if j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
		KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+DpRJnas65uVcO0S17dYG(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧࠜ")+xG6n4Wq2Ib7YgpiarHUNLQJM0+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩࠝ")+dKtZRl5Wa3e+vWNRusF46D7Mi8GpZ(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪࠞ")+WxHAl8FOEtZcTS+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧࠟ")+T0WMELQpsqxy7UD6PkolrJNZRCbFu+vWNRusF46D7Mi8GpZ(u"ࠨࠢࡠࠤ࡙ࠥࠦࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭ࠠ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠲࿞")])+fmkZtbRj3ux(u"ࠩࠣࡡࠬࠡ"))
	else:
		ccwn1rgp3AdiG97t6X = erqDsJmL3BQHuGtPkcf0X9(u"ࠪࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪࠢ")+glOmfke2LpTv8jWGZDSsboMq+TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࠥࡣࠧࠣ") if e6rQXC0BmMRPqno79Hu else wUvcPrYDfISbZolAm83GKEqMyXkn5
		if ndib93Ol6UojCrEV: ccwn1rgp3AdiG97t6X = ccwn1rgp3AdiG97t6X.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+VhqD3zp7mUieI8sMQlETH(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬࠤ")+xG6n4Wq2Ib7YgpiarHUNLQJM0+Gj3rMP1Cb8wHdp49la0(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪࠥ")+WxHAl8FOEtZcTS+DpRJnas65uVcO0S17dYG(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧࠦ")+T0WMELQpsqxy7UD6PkolrJNZRCbFu+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࠢࡠࠫࠧ")+ccwn1rgp3AdiG97t6X)
	glOmfke2LpTv8jWGZDSsboMq = Z6bUG0kDQuFqgzdAa1r(glOmfke2LpTv8jWGZDSsboMq)
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	xRX3NPL4uYwzo9Ai5MWCGmlrf6hjp[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = L5jXH0fZ8TvsESR.time()-V1VfMqTkXdYulSwF75JPhDgZ
	return glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def q0Pzi5jnbHrIwBDys4UvZ(title,hhEH1rcSP0z6Bkqy8OD,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,source,KUOoYcT20iCLVgsw1ejzdkHp7XW=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		if not Eu8LWnSt3fyJzIC[wTLFCOcM26fmYlW7U]: Eu8LWnSt3fyJzIC = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
		AeNt1wShKYUqvMWs7P4CjLgm9f5dcb = OOnvcPQy85HYA.getSetting(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ࠨ"))
		RTNBVpyXAkq05zEeU17OYjs9biZCa = vvhR5ozeiJpANyl8fFO3GBw(u"ࠪ࠱ࠬࠩ") not in AeNt1wShKYUqvMWs7P4CjLgm9f5dcb
		while y0yvdNOZkiKEg5RLMhoDVQAB9F2:
			if RTNBVpyXAkq05zEeU17OYjs9biZCa and len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==UD4N8MjVTd: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = wTLFCOcM26fmYlW7U
			else: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(erqDsJmL3BQHuGtPkcf0X9(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪࠪ"),Eu8LWnSt3fyJzIC)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: a1j30LvDQOi7GV8YhKsm = VhqD3zp7mUieI8sMQlETH(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧࠫ")
			else:
				V4QSvniBY71cbXWaH = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
				KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬࠬ")+title+bQGafNLXyFgsZP6ut(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ࠭")+QEbx35yvreoT2sPDG4k9Fcfa8Z(hhEH1rcSP0z6Bkqy8OD)+rDG9dZoXRhCJcieUSF0KB(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ࠮")+QEbx35yvreoT2sPDG4k9Fcfa8Z(V4QSvniBY71cbXWaH)+D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࠣࡡࠬ࠯"))
				if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭࠰") in V4QSvniBY71cbXWaH and lCT8hfYUBX4OQMmL(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ࠱") in V4QSvniBY71cbXWaH:
					ps0uGKYmexncl9hkQj6VLZrJ58Xf,AE7VM9Itbw2Be5hmXQSJW08LkrPy,lI7nrTA6abMO = ANhj1dxElfTuGgwLSPKeyaU(V4QSvniBY71cbXWaH)
					if lI7nrTA6abMO: V4QSvniBY71cbXWaH = lI7nrTA6abMO[wTLFCOcM26fmYlW7U]
					else: V4QSvniBY71cbXWaH = wUvcPrYDfISbZolAm83GKEqMyXkn5
				if not V4QSvniBY71cbXWaH: a1j30LvDQOi7GV8YhKsm = jQv0du1iVxTgAXCM(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ࠲")
				else: a1j30LvDQOi7GV8YhKsm = yyYuosJmc3QDUGSA(V4QSvniBY71cbXWaH,source,KUOoYcT20iCLVgsw1ejzdkHp7XW)
			if a1j30LvDQOi7GV8YhKsm in [TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ࠳"),llkFwuCyhaP3sK76qO4T(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ࠴"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭࠵"),bQGafNLXyFgsZP6ut(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ࠶")] or len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==TNw1pBHb8CtSZe0EFxuJqI(u"࠴࿟"): break
			elif a1j30LvDQOi7GV8YhKsm in [w8JC1y7Lp3(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ࠷"),MFhbWia58mP3su0fk2d(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ࠸"),w8JC1y7Lp3(u"ࠬࡺࡲࡪࡧࡧࠫ࠹")]: break
			else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ࠺"))
	else:
		a1j30LvDQOi7GV8YhKsm = A6Sg45ChDR3BJLYfFH(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ࠻")
		if rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD): a1j30LvDQOi7GV8YhKsm = yyYuosJmc3QDUGSA(hhEH1rcSP0z6Bkqy8OD,source,KUOoYcT20iCLVgsw1ejzdkHp7XW)
	return a1j30LvDQOi7GV8YhKsm,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def NMI5rpqu0xt4PZzi6O3F(url,source):
	ZD5n0eJivzWOMxY98dgrumkwRG,mwVoIdpJg0s4l3zMPU1Yj,xG6n4Wq2Ib7YgpiarHUNLQJM0,t4thSRgc1oMPUCrpwbAJKXjILZ,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa = url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if JHMxIE4fs1mvQtKW7R(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠼") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG,mwVoIdpJg0s4l3zMPU1Yj = url.split(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠽"),UD4N8MjVTd)
		mwVoIdpJg0s4l3zMPU1Yj = mwVoIdpJg0s4l3zMPU1Yj+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡣࡤ࠭࠾")+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡤࡥࠧ࠿")+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡥ࡟ࠨࡀ")+Gj3rMP1Cb8wHdp49la0(u"࠭࡟ࡠࠩࡁ")+JHMxIE4fs1mvQtKW7R(u"ࠧࡠࡡࠪࡂ")
		LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa,vCQjPcifkn5YIDyme = mwVoIdpJg0s4l3zMPU1Yj.split(xdSThjYnuHXAU6M(u"ࠨࡡࡢࠫࡃ"))[:ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠺࿠")]
	if not KwSdzRXT0M3VW: KwSdzRXT0M3VW = jQv0du1iVxTgAXCM(u"ࠩ࠳ࠫࡄ")
	else: KwSdzRXT0M3VW = KwSdzRXT0M3VW.replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡴࠬࡅ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(UKFZBQAVXHI5s17LyvuRpCY2,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.strip(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡄ࠭ࡆ")).strip(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࠵ࠧࡇ")).strip(D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࠦࠨࡈ"))
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡩࡱࡶࡸࠬࡉ"))
	if LcukPqj3x6f9WDZQh5YJzg: t4thSRgc1oMPUCrpwbAJKXjILZ = LcukPqj3x6f9WDZQh5YJzg
	else: t4thSRgc1oMPUCrpwbAJKXjILZ = xG6n4Wq2Ib7YgpiarHUNLQJM0
	t4thSRgc1oMPUCrpwbAJKXjILZ = TO3vi2rSZ0LRhKlwgG4qkYFIC(t4thSRgc1oMPUCrpwbAJKXjILZ,fmkZtbRj3ux(u"ࠨࡰࡤࡱࡪ࠭ࡊ"))
	LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(jQv0du1iVxTgAXCM(u"่ࠩฬฬฺัࠨࡋ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(xdSThjYnuHXAU6M(u"ࠪื๏ืแาࠩࡌ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫฬ๊ࠠࠨࡍ"),UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	mwVoIdpJg0s4l3zMPU1Yj = mwVoIdpJg0s4l3zMPU1Yj.replace(yRWQMHxZEz0(u"๋ࠬศศึิࠫࡎ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ำ๋ำไีࠬࡏ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(llkFwuCyhaP3sK76qO4T(u"ࠧศๆࠣࠫࡐ"),UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	t4thSRgc1oMPUCrpwbAJKXjILZ = t4thSRgc1oMPUCrpwbAJKXjILZ.replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠨ็หหูืࠧࡑ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(VhqD3zp7mUieI8sMQlETH(u"ࠩึ๎ึ็ัࠨࡒ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(yRWQMHxZEz0(u"ࠪห้ࠦࠧࡓ"),UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	return ZD5n0eJivzWOMxY98dgrumkwRG,mwVoIdpJg0s4l3zMPU1Yj,xG6n4Wq2Ib7YgpiarHUNLQJM0,t4thSRgc1oMPUCrpwbAJKXjILZ,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa
def XHIEeqnfyvlNkwZsjKp7AQ43d(url,source):
	N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,wzoUP874t0bDhlrvFpdNkOZ,MMGiTnupHsovJbSleIANYkC6hm,VHvo16QtYDdOCyJTBPqluX4izw9nk,zeSr7gHnFV8MxW9vDOjmy3LacK,dKtZRl5Wa3e = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3
	ZD5n0eJivzWOMxY98dgrumkwRG,mwVoIdpJg0s4l3zMPU1Yj,xG6n4Wq2Ib7YgpiarHUNLQJM0,t4thSRgc1oMPUCrpwbAJKXjILZ,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa = NMI5rpqu0xt4PZzi6O3F(url,source)
	if erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬࡔ") in url:
		if   KUOoYcT20iCLVgsw1ejzdkHp7XW==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࡫࡭ࡣࡧࡧࠫࡕ"): KUOoYcT20iCLVgsw1ejzdkHp7XW = UKFZBQAVXHI5s17LyvuRpCY2+s149dk8uh2p7oFzaLxZeI3Or(u"࠭ๅโุ็ࠫࡖ")
		elif KUOoYcT20iCLVgsw1ejzdkHp7XW==JHMxIE4fs1mvQtKW7R(u"ࠧࡸࡣࡷࡧ࡭࠭ࡗ"): KUOoYcT20iCLVgsw1ejzdkHp7XW = UKFZBQAVXHI5s17LyvuRpCY2+fmkZtbRj3ux(u"ࠨุ่ࠧฬํฯสࠩࡘ")
		elif KUOoYcT20iCLVgsw1ejzdkHp7XW==lCT8hfYUBX4OQMmL(u"ࠩࡥࡳࡹ࡮࡙ࠧ"): KUOoYcT20iCLVgsw1ejzdkHp7XW = UKFZBQAVXHI5s17LyvuRpCY2+s149dk8uh2p7oFzaLxZeI3Or(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่࡚ࠬ")
		elif KUOoYcT20iCLVgsw1ejzdkHp7XW==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡛࠭"): KUOoYcT20iCLVgsw1ejzdkHp7XW = UKFZBQAVXHI5s17LyvuRpCY2+DpRJnas65uVcO0S17dYG(u"ࠬࠫࠥࠦฬะ้๏๊ࠧ࡜")
		elif KUOoYcT20iCLVgsw1ejzdkHp7XW==wUvcPrYDfISbZolAm83GKEqMyXkn5: KUOoYcT20iCLVgsw1ejzdkHp7XW = UKFZBQAVXHI5s17LyvuRpCY2+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࠥࠦࠧࠨࠫ࡝")
		if t3oe4rjuvpMQKwRnbkTaqYsAI6i5!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
			if ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧ࡮ࡲ࠷ࠫ࡞") not in t3oe4rjuvpMQKwRnbkTaqYsAI6i5: t3oe4rjuvpMQKwRnbkTaqYsAI6i5 = xm6jK1ZMuWq5(u"ࠨࠧࠪ࡟")+t3oe4rjuvpMQKwRnbkTaqYsAI6i5
			t3oe4rjuvpMQKwRnbkTaqYsAI6i5 = UKFZBQAVXHI5s17LyvuRpCY2+t3oe4rjuvpMQKwRnbkTaqYsAI6i5
		if KwSdzRXT0M3VW!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
			KwSdzRXT0M3VW = TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬࡠ")+KwSdzRXT0M3VW
			KwSdzRXT0M3VW = UKFZBQAVXHI5s17LyvuRpCY2+KwSdzRXT0M3VW[-w8JC1y7Lp3(u"࠾࿡"):]
	if   Gj3rMP1Cb8wHdp49la0(u"ࠪࡅࡐࡕࡁࡎࠩࡡ")		in source: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡆࡑࡗࡂࡏࠪࡢ")		in source and jnqzf9WihpUlxmcAEZ1vMLXNu(u"࡚ࠬࡕࡃࡇࠪࡣ") not in source: wzoUP874t0bDhlrvFpdNkOZ	= w8JC1y7Lp3(u"࠭ࡡ࡬ࡹࡤࡱࠬࡤ")
	elif JHMxIE4fs1mvQtKW7R(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩࡥ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧࡦ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif w8JC1y7Lp3(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫࡧ")		in source: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif rDG9dZoXRhCJcieUSF0KB(u"ࠪࡥࡱࡧࡲࡢࡤࠪࡨ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡫ࡧࡳࡦ࡮ࠪࡩ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡺ࠷࡮ࡧࡨࡰࠬࡪ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif DpRJnas65uVcO0S17dYG(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭࡫")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif JHMxIE4fs1mvQtKW7R(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ࡬")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif jQv0du1iVxTgAXCM(u"ࠨ࡮ࡲࡨࡾࡴࡥࡵࠩ࡭")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡩࡥ࡯࡫ࡲࠨ࡮")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪๅัืࠧ࡯")			in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= DpRJnas65uVcO0S17dYG(u"ࠫ࡫ࡧࡪࡦࡴࠪࡰ")
	elif w8JC1y7Lp3(u"ࠬ็ไิูํ๊ࠬࡱ")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= MFhbWia58mP3su0fk2d(u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩࡲ")
	elif llkFwuCyhaP3sK76qO4T(u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧࡳ")		in ZD5n0eJivzWOMxY98dgrumkwRG:   wzoUP874t0bDhlrvFpdNkOZ	= ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨࡴ")
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩࡵ")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪࡶ")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif llkFwuCyhaP3sK76qO4T(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬࡷ")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ࡸ")		in LcukPqj3x6f9WDZQh5YJzg:   wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif vWNRusF46D7Mi8GpZ(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫࡹ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡣࡱ࡮ࡶࡦ࠭ࡺ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif jQv0du1iVxTgAXCM(u"ࠨࡶࡹࡪࡺࡴࠧࡻ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡷࡺࡰࡹࡡࠨࡼ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫࡽ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif DpRJnas65uVcO0S17dYG(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ࡾ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧࡿ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif fmkZtbRj3ux(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨࢀ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧࢁ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡧࡪࡽࡳࡵࡷࠨࢂ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif A6Sg45ChDR3BJLYfFH(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫࢃ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif yRWQMHxZEz0(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬࢄ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬࢅ")	 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭ࢆ")
	elif A6Sg45ChDR3BJLYfFH(u"࠭ࡹࡰࡷࡷࡹࠬࢇ")	 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ࢈")
	elif llkFwuCyhaP3sK76qO4T(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨࢉ")	 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= Gj3rMP1Cb8wHdp49la0(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪࢊ")
	elif xm6jK1ZMuWq5(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩࢋ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩࢌ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩࢍ")
	elif rDG9dZoXRhCJcieUSF0KB(u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨࢎ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= llkFwuCyhaP3sK76qO4T(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ࢏")
	elif s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ࢐")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= rDG9dZoXRhCJcieUSF0KB(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫ࢑")
	elif xdSThjYnuHXAU6M(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ࢒")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭࢓")
	elif MFhbWia58mP3su0fk2d(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ࢔")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= yRWQMHxZEz0(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ࢕")
	elif gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ࢖")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨࢗ")
	elif it4DKnryZlx(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ࢘")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: wzoUP874t0bDhlrvFpdNkOZ	= fmkZtbRj3ux(u"ࠪࡦࡺࢀࡺࡷࡴ࡯࢙ࠫ")
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹ࢚ࠧ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= fmkZtbRj3ux(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ࢛")
	elif Gj3rMP1Cb8wHdp49la0(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ࢜")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= lCT8hfYUBX4OQMmL(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ࢝")
	elif MFhbWia58mP3su0fk2d(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ࢞")	 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= xdSThjYnuHXAU6M(u"ࠩࡦࡥࡹࡩࡨࠨ࢟")
	elif it4DKnryZlx(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫࢠ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬࢡ")
	elif it4DKnryZlx(u"ࠬࡼࡩࡥࡤࡰࠫࢢ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= JHMxIE4fs1mvQtKW7R(u"࠭ࡶࡪࡦࡥࡱࠬࢣ")
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡷ࡫ࡧ࡬ࡩ࠭ࢤ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif fmkZtbRj3ux(u"ࠨ࡯ࡼࡺ࡮ࡪࠧࢥ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif JHMxIE4fs1mvQtKW7R(u"ࠩࡰࡽࡻ࡯ࡩࡥࠩࢦ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: zeSr7gHnFV8MxW9vDOjmy3LacK	= t4thSRgc1oMPUCrpwbAJKXjILZ
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬࢧ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= VhqD3zp7mUieI8sMQlETH(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭ࢨ")
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬ࡭࡯ࡷ࡫ࡧࠫࢩ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= DpRJnas65uVcO0S17dYG(u"࠭ࡧࡰࡸ࡬ࡨࠬࢪ")
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩࢫ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= lCT8hfYUBX4OQMmL(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪࢬ")
	elif yRWQMHxZEz0(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬࢭ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= it4DKnryZlx(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ࢮ")
	elif TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩࢯ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪࢰ")
	elif erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪࢱ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫࢲ")
	elif fmkZtbRj3ux(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩࢳ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= lCT8hfYUBX4OQMmL(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪࢴ")
	elif TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡹࡵࡶࠧࢵ") 			in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡺࡶࡢࡰ࡯ࠪࢶ")
	elif VhqD3zp7mUieI8sMQlETH(u"ࠬࡻࡰࡣࠩࢷ") 			in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡵࡱࡤࡲࡱࠬࢸ")
	elif bQGafNLXyFgsZP6ut(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧࢹ") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= xdSThjYnuHXAU6M(u"ࠨࡷࡴࡰࡴࡧࡤࠨࢺ")
	elif VhqD3zp7mUieI8sMQlETH(u"ࠩࡹ࡯ࠬࢻ") 			in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡺࡰ࠭ࢼ")
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ࢽ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧࢾ")
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ࢿ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= vWNRusF46D7Mi8GpZ(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧࣀ")
	elif JHMxIE4fs1mvQtKW7R(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨࣁ") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩࣂ")
	elif bQGafNLXyFgsZP6ut(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧࣃ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= VhqD3zp7mUieI8sMQlETH(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨࣄ")
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩࣅ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪࣆ")
	elif erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫࣇ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= fmkZtbRj3ux(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬࣈ")
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩࣉ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: MMGiTnupHsovJbSleIANYkC6hm	= D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪ࣊")
	if   wzoUP874t0bDhlrvFpdNkOZ:	N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫำอีࠨ࣋"),wzoUP874t0bDhlrvFpdNkOZ
	elif zeSr7gHnFV8MxW9vDOjmy3LacK:		N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = w8JC1y7Lp3(u"ࠬࠫๅฮัาࠫ࣌"),zeSr7gHnFV8MxW9vDOjmy3LacK
	elif MMGiTnupHsovJbSleIANYkC6hm:		N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = erqDsJmL3BQHuGtPkcf0X9(u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫ࣍"),MMGiTnupHsovJbSleIANYkC6hm
	elif VHvo16QtYDdOCyJTBPqluX4izw9nk:	N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭࣎"),VHvo16QtYDdOCyJTBPqluX4izw9nk
	elif dKtZRl5Wa3e:	N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = lCT8hfYUBX4OQMmL(u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨ࣏"),t4thSRgc1oMPUCrpwbAJKXjILZ
	else:			N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆ࣐ࠪ"),t4thSRgc1oMPUCrpwbAJKXjILZ
	return N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW
def uCGMoc847AsP(JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL):
	kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF = [],[]
	for title,hhEH1rcSP0z6Bkqy8OD in list(zip(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)):
		if rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD):
			kDp3Tb6EBW.append(title)
			ppAJI9kDbz5MXa76UEF.append(hhEH1rcSP0z6Bkqy8OD)
	if not ppAJI9kDbz5MXa76UEF and not JCxwmazEp2i5eGIZt1: JCxwmazEp2i5eGIZt1 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡊࡦ࡯࡬ࡦࡦ࣑ࠪ")
	return JCxwmazEp2i5eGIZt1,kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF
def BBE5GZn4KS7I(url,source):
	ZD5n0eJivzWOMxY98dgrumkwRG,zeSr7gHnFV8MxW9vDOjmy3LacK,xG6n4Wq2Ib7YgpiarHUNLQJM0,t4thSRgc1oMPUCrpwbAJKXjILZ,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa = NMI5rpqu0xt4PZzi6O3F(url,source)
	if   erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡾࡵࡵࡵࡷ࣒ࠪ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࣓"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	elif vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭ࣔ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = MFhbWia58mP3su0fk2d(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣕ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	elif bQGafNLXyFgsZP6ut(u"ࠨࡣ࡯ࡦࡦࡶ࡬ࡢࡻࡨࡶࠬࣖ")	in ZD5n0eJivzWOMxY98dgrumkwRG  : JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = tTs1D79URu83cnV5whWydXPKBkCvmQ(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif Gj3rMP1Cb8wHdp49la0(u"ࠩࡄࡏࡔࡇࡍࠨࣗ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = V78QvGpgDT(ZD5n0eJivzWOMxY98dgrumkwRG,LcukPqj3x6f9WDZQh5YJzg)
	elif kPCxIUZb1V(u"ࠪࡅࡐ࡝ࡁࡎࠩࣘ")		in source and vvhR5ozeiJpANyl8fFO3GBw(u"࡙࡛ࠫࡂࡆࠩࣙ") not in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = myIlApe52K(ZD5n0eJivzWOMxY98dgrumkwRG,KUOoYcT20iCLVgsw1ejzdkHp7XW,KwSdzRXT0M3VW)
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧࣚ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = O6AvwjFPyc(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif xm6jK1ZMuWq5(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨࣛ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = KLjHmDNt67(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif s149dk8uh2p7oFzaLxZeI3Or(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨࣜ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣝ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	elif xdSThjYnuHXAU6M(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩࣞ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = Kxr124C0uz(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬࣟ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = KavYIOMF5p(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭࣠")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = BZErkcCYxU(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ࣡")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = cMxuYB5kpT(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif VhqD3zp7mUieI8sMQlETH(u"࠭ࡓࡉࡑࡉࡌࡆ࠭࣢")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = QZCw3MIvEh(ZD5n0eJivzWOMxY98dgrumkwRG,KUOoYcT20iCLVgsw1ejzdkHp7XW,zeSr7gHnFV8MxW9vDOjmy3LacK)
	elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࣣࠩ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = QpoF5DkPh4(ZD5n0eJivzWOMxY98dgrumkwRG,oQbdyTekSgKa)
	elif erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡎࡄࡖࡔࡠࡁࠨࣤ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = uug6pCUxKH(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif lCT8hfYUBX4OQMmL(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪࣥ")		in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = KiofgBtErJ(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif w8JC1y7Lp3(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࣦࠧ")	in source: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = fckzxFCTyS(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif kPCxIUZb1V(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ࣧ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = F1jKODep2E(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif xdSThjYnuHXAU6M(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨࣨ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = Y0ZSpnAUJc(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡡ࡭ࡣࡵࡥࡧࣩ࠭")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = yWREdNcuY9PiS8qDoj2pGChxmf(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif xdSThjYnuHXAU6M(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ࣪")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = y0tR1hI5BJ(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ࣫")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = y0tR1hI5BJ(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ࣬")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = MratzORUN5(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡸࡻ࡬ࡵ࡯࣭ࠩ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = CCmXVv3a6U(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif lCT8hfYUBX4OQMmL(u"ࠫࡹࡼ࡫ࡴࡣ࣮ࠪ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = CCmXVv3a6U(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif vWNRusF46D7Mi8GpZ(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳ࣯ࠧ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = CCmXVv3a6U(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif yRWQMHxZEz0(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨࣰ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = ypBe9URGvC(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif rDG9dZoXRhCJcieUSF0KB(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࣱࠩ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = PJgTNKZaBr(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif A6Sg45ChDR3BJLYfFH(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࣲࠪ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = mRvjIWXdBwe(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡹࡷ࠹ࡻࠧࣳ")			in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = oasyB3Y47C(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif JHMxIE4fs1mvQtKW7R(u"ࠪࡪࡦࡰࡥࡳࠩࣴ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = VF8tB9Rrmv(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬࣵ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = nHbYcuLB7N(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif A6Sg45ChDR3BJLYfFH(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦࣶ࠭")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = nHbYcuLB7N(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪࣷ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = LUOwxAiIV7(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif kPCxIUZb1V(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪࣸ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = LUOwxAiIV7(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif vWNRusF46D7Mi8GpZ(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨࣹ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = UMFnku9ZcV(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡺࡩࡨ࡯࡭ࡢࣺࠩ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = LcZYu3IMdy(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif MFhbWia58mP3su0fk2d(u"ࠪࡦࡴࡱࡲࡢࠩࣻ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = J4AVWmyI0c(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif xm6jK1ZMuWq5(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩࣼ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = swVuG9qtXU(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif Gj3rMP1Cb8wHdp49la0(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧࣽ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = FiMGp0mqwW(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬࣾ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = YLCDhAx5rF(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif yRWQMHxZEz0(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬࣿ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	elif A6Sg45ChDR3BJLYfFH(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩऀ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = v5vW02AcV8(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨँ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = SDn3kzMBgQ(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif Gj3rMP1Cb8wHdp49la0(u"ࠪࡹࡵࡨࡡ࡮ࠩं") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	else: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧः"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	if not JCxwmazEp2i5eGIZt1 and not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: JCxwmazEp2i5eGIZt1 = xdSThjYnuHXAU6M(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵ࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭ऄ")
	elif JCxwmazEp2i5eGIZt1 not in [wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫअ"),A6Sg45ChDR3BJLYfFH(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪआ")]: JCxwmazEp2i5eGIZt1 = erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫइ")+JCxwmazEp2i5eGIZt1
	return JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def kvjCF6tWeubXB0zUAHos3dQVYx(glOmfke2LpTv8jWGZDSsboMq,url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe):
	global krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ,fmlEU9aTCy0LIq,Bzd1jaotsQn40CYOW3lrPVAx,t9SPGT0jqag4,chFisl1EqLoprJwu
	RuEo0hGiCVxND4 = []
	for dKtZRl5Wa3e in [fmlEU9aTCy0LIq,Bzd1jaotsQn40CYOW3lrPVAx,t9SPGT0jqag4,chFisl1EqLoprJwu]: dKtZRl5Wa3e[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = kPCxIUZb1V(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪई"),[],[]
	Ao2FfY8LPUr5k0smB1Qi,sRIXLWefqh69 = [I7K3qlXt90NZL,eFG7A58wtUgSlyT1jDpQ,uIYXqFp43UrAzec,MUh8BJH1nx75ERVl6DKQA],[]
	if xm6jK1ZMuWq5(u"ࠪࡪࡷࡪ࡬ࠨउ") in url: Ao2FfY8LPUr5k0smB1Qi,sRIXLWefqh69 = [I7K3qlXt90NZL,eFG7A58wtUgSlyT1jDpQ,MUh8BJH1nx75ERVl6DKQA],[t9SPGT0jqag4]
	if s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡾࡵࡵࡵࡷࠪऊ") in url or JHMxIE4fs1mvQtKW7R(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬऋ") in url: Ao2FfY8LPUr5k0smB1Qi,sRIXLWefqh69 = [I7K3qlXt90NZL],[Bzd1jaotsQn40CYOW3lrPVAx,t9SPGT0jqag4,chFisl1EqLoprJwu]
	for dKtZRl5Wa3e in sRIXLWefqh69: dKtZRl5Wa3e[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = JHMxIE4fs1mvQtKW7R(u"࠭ࡓ࡬࡫ࡳࡴࡪࡪࠧऌ"),[],[]
	for dKtZRl5Wa3e in Ao2FfY8LPUr5k0smB1Qi:
		jFiHrxNGSORWf = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=dKtZRl5Wa3e,args=(url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe))
		RuEo0hGiCVxND4.append(jFiHrxNGSORWf)
	def Cy92KYHGukJdqQot84veR():
		v10MGyaZIOJmlXL4THUF,pVLIaDET2r,OovSxG209YHUl,qQpFE7zmYbIZ5Wdj2MT9D60lsO3 = Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA
		ffscXeZCModaLjh62GuJIA,title,hhEH1rcSP0z6Bkqy8OD = fmlEU9aTCy0LIq[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
		if (hhEH1rcSP0z6Bkqy8OD and not ffscXeZCModaLjh62GuJIA) or (ffscXeZCModaLjh62GuJIA and ffscXeZCModaLjh62GuJIA!=yRWQMHxZEz0(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨऍ")): v10MGyaZIOJmlXL4THUF = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		ffscXeZCModaLjh62GuJIA,title,hhEH1rcSP0z6Bkqy8OD = Bzd1jaotsQn40CYOW3lrPVAx[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
		if (hhEH1rcSP0z6Bkqy8OD and not ffscXeZCModaLjh62GuJIA) or (ffscXeZCModaLjh62GuJIA and ffscXeZCModaLjh62GuJIA!=yRWQMHxZEz0(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩऎ")): pVLIaDET2r = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		ffscXeZCModaLjh62GuJIA,title,hhEH1rcSP0z6Bkqy8OD = t9SPGT0jqag4[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
		if (hhEH1rcSP0z6Bkqy8OD and not ffscXeZCModaLjh62GuJIA) or (ffscXeZCModaLjh62GuJIA and ffscXeZCModaLjh62GuJIA!=MFhbWia58mP3su0fk2d(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪए")): OovSxG209YHUl = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		ffscXeZCModaLjh62GuJIA,title,hhEH1rcSP0z6Bkqy8OD = chFisl1EqLoprJwu[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
		if (hhEH1rcSP0z6Bkqy8OD and not ffscXeZCModaLjh62GuJIA) or (ffscXeZCModaLjh62GuJIA and ffscXeZCModaLjh62GuJIA!=vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫऐ")): qQpFE7zmYbIZ5Wdj2MT9D60lsO3 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		ZG9d7oT8KChmVbcMWnXsLvj = all([v10MGyaZIOJmlXL4THUF,pVLIaDET2r,OovSxG209YHUl,qQpFE7zmYbIZ5Wdj2MT9D60lsO3])
		FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying() if TTuO14NzmB.resolveonly else y0yvdNOZkiKEg5RLMhoDVQAB9F2
		return ZG9d7oT8KChmVbcMWnXsLvj or not FBe2GQ7zwUmOia
	xxaHzT9pQj6SRDCGIfwydq(RuEo0hGiCVxND4,ggrwtFZBzDPHT26L1lu45x,xx1Qbw9ABV6IYrmHd0vptjElzPf,UD4N8MjVTd,Cy92KYHGukJdqQot84veR)
	succeeded = MFhbWia58mP3su0fk2d(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪऑ")
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = fmlEU9aTCy0LIq[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	if JCxwmazEp2i5eGIZt1==xm6jK1ZMuWq5(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪऒ") or j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return succeeded,JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	glOmfke2LpTv8jWGZDSsboMq += TNw1pBHb8CtSZe0EFxuJqI(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠠࠨओ")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)[:xm6jK1ZMuWq5(u"࠾࠰࿢")]
	succeeded = rDG9dZoXRhCJcieUSF0KB(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭औ")
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = Bzd1jaotsQn40CYOW3lrPVAx[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	if JCxwmazEp2i5eGIZt1==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭क") or j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return succeeded,JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	glOmfke2LpTv8jWGZDSsboMq += jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠳࠻ࠢࠣࠫख")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)[:lCT8hfYUBX4OQMmL(u"࠸࠱࿣")]
	succeeded = JHMxIE4fs1mvQtKW7R(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠵ࠩग")
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = t9SPGT0jqag4[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	if JCxwmazEp2i5eGIZt1==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩघ") or j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return succeeded,JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	glOmfke2LpTv8jWGZDSsboMq += D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠷࠾ࠥࠦࠧङ")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)[:A6Sg45ChDR3BJLYfFH(u"࠹࠲࿤")]
	succeeded = fmkZtbRj3ux(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠹ࠬच")
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = chFisl1EqLoprJwu[FF0VNPLRHtcAjs4J3kGDEUmB6fe]
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = STvFPVEHUtLMfrqJp9AKZl07R(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	if JCxwmazEp2i5eGIZt1==Gj3rMP1Cb8wHdp49la0(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬछ") or j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return succeeded,JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	glOmfke2LpTv8jWGZDSsboMq += erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠻࠺ࠡࠢࠪज")+JCxwmazEp2i5eGIZt1.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)[:bQGafNLXyFgsZP6ut(u"࠺࠳࿥")]
	krvlCW8AVsPJFzpnGgQLDN0BRqiOfZ[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	return succeeded,glOmfke2LpTv8jWGZDSsboMq,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def I7K3qlXt90NZL(url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe):
	ZD5n0eJivzWOMxY98dgrumkwRG,zeSr7gHnFV8MxW9vDOjmy3LacK,xG6n4Wq2Ib7YgpiarHUNLQJM0,t4thSRgc1oMPUCrpwbAJKXjILZ,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,oQbdyTekSgKa = NMI5rpqu0xt4PZzi6O3F(url,source)
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	if DpRJnas65uVcO0S17dYG(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧझ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = swVuG9qtXU(url)
	elif w8JC1y7Lp3(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࡸࡷࡪࡸࡣࡰࠩञ") in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = VDxTIe4BrMRlzpqb2a(url)
	elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡾࡵࡵࡵࡷࠪट")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = dKk6LcO0aJgBIUeb3Nmfoi2u4lXZE(url)
	elif rDG9dZoXRhCJcieUSF0KB(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬठ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = dKk6LcO0aJgBIUeb3Nmfoi2u4lXZE(url)
	elif bQGafNLXyFgsZP6ut(u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬड")	in url   : JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = nnat9XdBGYQbokzsmH7PC2MIvhLNV(url)
	elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩढ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = ANhj1dxElfTuGgwLSPKeyaU(url)
	elif yRWQMHxZEz0(u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩण")		in url   : JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = O6AvwjFPyc(url)
	elif yRWQMHxZEz0(u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬत")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = ca8vDO4NqZ01U9YePW(url)
	elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫथ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = oAkaex4dBQzPC7fLw(url)
	elif it4DKnryZlx(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬद")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = izHAo7gwfbsVn(url)
	elif vWNRusF46D7Mi8GpZ(u"ࠬ࡫࠵ࡵࡵࡤࡶࠬध")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = sPBSfXKGhr9JiYzVEyc7(url)
	elif w8JC1y7Lp3(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬन")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = rE1pnSHoU4hwZ(url)
	elif D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪऩ")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = rE1pnSHoU4hwZ(url)
	elif VhqD3zp7mUieI8sMQlETH(u"ࠨࡷࡳࡦࡦࡳࠧप") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	elif bQGafNLXyFgsZP6ut(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫफ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = BxfNv3uZhopaWDl(url)
	elif Gj3rMP1Cb8wHdp49la0(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ब")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = zCMnvPYBg4uOK(url)
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨभ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = ocemYixOR0lG5Hq(url)
	elif kPCxIUZb1V(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭म")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wA6uSXOcsbVF(url)
	elif w8JC1y7Lp3(u"࠭ࡵࡱࡤࠪय") 			in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = u7JgcOfvjhp4UbL0Fqsa(url)
	elif A6Sg45ChDR3BJLYfFH(u"ࠧࡶࡲࡳࠫर") 			in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = u7JgcOfvjhp4UbL0Fqsa(url)
	elif yRWQMHxZEz0(u"ࠨࡷࡴࡰࡴࡧࡤࠨऱ") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = cSrtbA1WNp(url)
	elif vWNRusF46D7Mi8GpZ(u"ࠩࡹ࡯ࠬल")	 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = eMCEGLFtTOS0msIqrgknz(ZD5n0eJivzWOMxY98dgrumkwRG)
	elif MFhbWia58mP3su0fk2d(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬळ") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = Pk7c09DLpRFOJiQ(url)
	elif dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡻ࡯ࡤࡣࡱࡥࠫऴ")		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = tdoP4CwKcAy75Jvl(url)
	elif DpRJnas65uVcO0S17dYG(u"ࠬࡼࡩࡥࡱࡽࡥࠬव") 		in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = kkJXDIoKjvSCa6POxpV1AQ(url)
	elif s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪश") 	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = B2BRHraT1ZPgJqXO9e(url)
	elif Gj3rMP1Cb8wHdp49la0(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫष")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = aA9uzTYLSfCDiqcOVQ5v(url)
	elif fmkZtbRj3ux(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬस")	in xG6n4Wq2Ib7YgpiarHUNLQJM0: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = a4awUhtW2YboQcuNmM7lZ(url)
	else: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	global fmlEU9aTCy0LIq
	if not JCxwmazEp2i5eGIZt1 and not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: JCxwmazEp2i5eGIZt1 = JHMxIE4fs1mvQtKW7R(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳ࠢࡉࡥ࡮ࡲࡵࡳࡧࠪह")
	elif JCxwmazEp2i5eGIZt1 not in [wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨऺ"),w8JC1y7Lp3(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧऻ")]: JCxwmazEp2i5eGIZt1 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ़")+JCxwmazEp2i5eGIZt1
	fmlEU9aTCy0LIq[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	return
def eFG7A58wtUgSlyT1jDpQ(url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe):
	global Bzd1jaotsQn40CYOW3lrPVAx
	if DpRJnas65uVcO0S17dYG(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧऽ") in url:
		Bzd1jaotsQn40CYOW3lrPVAx[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = kPCxIUZb1V(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡖ࡯࡮ࡶࡰࡦࡦࠪा"),[],[]
		return
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	if rjZFa0VMBuPRHg1cIYJpd52oxl4(url):
		JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = hJpdiwygGQ4Z7vSPK(url)
	if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = JJdgojui8K40Xfz(url)
	if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		if JCxwmazEp2i5eGIZt1==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ि"): JCxwmazEp2i5eGIZt1 = wUvcPrYDfISbZolAm83GKEqMyXkn5
		JCxwmazEp2i5eGIZt1 = it4DKnryZlx(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬी")+JCxwmazEp2i5eGIZt1 if JCxwmazEp2i5eGIZt1 else rDG9dZoXRhCJcieUSF0KB(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵ࠣࡊࡦ࡯࡬ࡶࡴࡨࠫु")
	Bzd1jaotsQn40CYOW3lrPVAx[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	return
def uIYXqFp43UrAzec(url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe):
	av1f8x5yZ9rAsq = wUvcPrYDfISbZolAm83GKEqMyXkn5
	RCmHBOKtejQ8lu4L = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	try:
		import resolveurl as DItNzSfm2YiJ
		RCmHBOKtejQ8lu4L = DItNzSfm2YiJ.resolve(url)
	except Exception as ffscXeZCModaLjh62GuJIA: av1f8x5yZ9rAsq = str(ffscXeZCModaLjh62GuJIA)
	global t9SPGT0jqag4
	if not RCmHBOKtejQ8lu4L:
		if av1f8x5yZ9rAsq==wUvcPrYDfISbZolAm83GKEqMyXkn5:
			av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
			if av1f8x5yZ9rAsq!=jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧू"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
		JCxwmazEp2i5eGIZt1 = av1f8x5yZ9rAsq.splitlines()[-UD4N8MjVTd]
		t9SPGT0jqag4[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = bQGafNLXyFgsZP6ut(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨृ")+JCxwmazEp2i5eGIZt1,[],[]
		return
	t9SPGT0jqag4[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[RCmHBOKtejQ8lu4L]
	return
def MUh8BJH1nx75ERVl6DKQA(url,source,FF0VNPLRHtcAjs4J3kGDEUmB6fe):
	av1f8x5yZ9rAsq = wUvcPrYDfISbZolAm83GKEqMyXkn5
	RCmHBOKtejQ8lu4L = {}
	try:
		import yt_dlp as q9D7HLaVpluQ40n2IFbB
		NRgIuX8FPwJq3pQB2AEKkTfDth = q9D7HLaVpluQ40n2IFbB.YoutubeDL({DpRJnas65uVcO0S17dYG(u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨॄ"): y0yvdNOZkiKEg5RLMhoDVQAB9F2})
		RCmHBOKtejQ8lu4L = NRgIuX8FPwJq3pQB2AEKkTfDth.extract_info(url,download=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	except Exception as ffscXeZCModaLjh62GuJIA: av1f8x5yZ9rAsq = str(ffscXeZCModaLjh62GuJIA)
	global chFisl1EqLoprJwu
	if D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨॅ") not in RCmHBOKtejQ8lu4L:
		if av1f8x5yZ9rAsq==wUvcPrYDfISbZolAm83GKEqMyXkn5:
			av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
			if av1f8x5yZ9rAsq!=VhqD3zp7mUieI8sMQlETH(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫॆ"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
		JCxwmazEp2i5eGIZt1 = av1f8x5yZ9rAsq.splitlines()[-UD4N8MjVTd]
		chFisl1EqLoprJwu[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = A6Sg45ChDR3BJLYfFH(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬे")+JCxwmazEp2i5eGIZt1,[],[]
	else:
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
		for hhEH1rcSP0z6Bkqy8OD in RCmHBOKtejQ8lu4L[kPCxIUZb1V(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫै")]:
			Eu8LWnSt3fyJzIC.append(hhEH1rcSP0z6Bkqy8OD[fmkZtbRj3ux(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫॉ")])
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡻࡲ࡭ࠩॊ")])
		chFisl1EqLoprJwu[FF0VNPLRHtcAjs4J3kGDEUmB6fe] = wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	return
def hJpdiwygGQ4Z7vSPK(url,headers=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not headers:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,MFhbWia58mP3su0fk2d(u"࠭ࡇࡆࡖࠪो"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊࡊࡉࡓࡇࡆࡘࡤ࡛ࡒࡍ࠯࠴ࡷࡹ࠭ौ"))
		headers = QM9sJ7tk0oplqEwHU3DjL64d.headers
	hhEH1rcSP0z6Bkqy8OD = headers.get(bQGafNLXyFgsZP6ut(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰ्ࠪ")) or headers.get(VhqD3zp7mUieI8sMQlETH(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫॎ")) or wUvcPrYDfISbZolAm83GKEqMyXkn5
	if hhEH1rcSP0z6Bkqy8OD and rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD): return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return w8JC1y7Lp3(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ॏ"),[],[]
def STvFPVEHUtLMfrqJp9AKZl07R(wwH9NWv8LbqMyo1IQElsXU):
	if isinstance(wwH9NWv8LbqMyo1IQElsXU,list):
		ppAJI9kDbz5MXa76UEF = []
		for hhEH1rcSP0z6Bkqy8OD in wwH9NWv8LbqMyo1IQElsXU:
			if isinstance(hhEH1rcSP0z6Bkqy8OD,str): hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			ppAJI9kDbz5MXa76UEF.append(hhEH1rcSP0z6Bkqy8OD)
	else: ppAJI9kDbz5MXa76UEF = wwH9NWv8LbqMyo1IQElsXU.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
	return ppAJI9kDbz5MXa76UEF
def qP0pj67cFb3IkvyGHxAn8Z(lI7nrTA6abMO,source):
	data = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡱ࡯ࡳࡵࠩॐ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭॑"),lI7nrTA6abMO)
	if data:
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = zip(*data)
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = list(Eu8LWnSt3fyJzIC),list(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
		return Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,VOZRCFHbEJ5jKyTpaMscw = [],[],[]
	for hhEH1rcSP0z6Bkqy8OD in lI7nrTA6abMO:
		if kPCxIUZb1V(u"࠭࠯࠰॒ࠩ") not in hhEH1rcSP0z6Bkqy8OD: continue
		N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW = XHIEeqnfyvlNkwZsjKp7AQ43d(hhEH1rcSP0z6Bkqy8OD,source)
		KwSdzRXT0M3VW = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠧ࡝ࡦ࠮ࠫ॓"),KwSdzRXT0M3VW,jj0dZrgiKb.DOTALL)
		if KwSdzRXT0M3VW: KwSdzRXT0M3VW = int(KwSdzRXT0M3VW[wTLFCOcM26fmYlW7U])
		else: KwSdzRXT0M3VW = wTLFCOcM26fmYlW7U
		xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,xm6jK1ZMuWq5(u"ࠨࡰࡤࡱࡪ࠭॔"))
		VOZRCFHbEJ5jKyTpaMscw.append([N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,hhEH1rcSP0z6Bkqy8OD,xG6n4Wq2Ib7YgpiarHUNLQJM0])
	if VOZRCFHbEJ5jKyTpaMscw:
		Zw0r8NpUsY4hXcaKvtVmd = sorted(VOZRCFHbEJ5jKyTpaMscw,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: (key[R9RNUT6WAPEYjHqtIokxuXs],key[wTLFCOcM26fmYlW7U],key[MMRBkhnWVJCQwU],key[Tb7oymMnpflsSv3eu4Pz2],key[UD4N8MjVTd],key[xdSThjYnuHXAU6M(u"࠸࿦")],key[rDG9dZoXRhCJcieUSF0KB(u"࠺࿧")]))
		lCtvKHMzLJVo8fERq9N5,ov9Kif32QmNZyH7ABcwnb10al5 = [],[]
		for yqH8GM4tr32YXobgA9ZkhsSj0B in Zw0r8NpUsY4hXcaKvtVmd:
			N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,hhEH1rcSP0z6Bkqy8OD,xG6n4Wq2Ib7YgpiarHUNLQJM0 = yqH8GM4tr32YXobgA9ZkhsSj0B
			if kPCxIUZb1V(u"่ࠩๅ฻๊ࠧॕ") in KUOoYcT20iCLVgsw1ejzdkHp7XW:
				ov9Kif32QmNZyH7ABcwnb10al5.append(yqH8GM4tr32YXobgA9ZkhsSj0B)
				continue
			if yqH8GM4tr32YXobgA9ZkhsSj0B not in lCtvKHMzLJVo8fERq9N5: lCtvKHMzLJVo8fERq9N5.append(yqH8GM4tr32YXobgA9ZkhsSj0B)
		lCtvKHMzLJVo8fERq9N5 = ov9Kif32QmNZyH7ABcwnb10al5+lCtvKHMzLJVo8fERq9N5
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = wTLFCOcM26fmYlW7U
		for N3hJXQ4vklxLbRCjGgn,LcukPqj3x6f9WDZQh5YJzg,KUOoYcT20iCLVgsw1ejzdkHp7XW,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,KwSdzRXT0M3VW,hhEH1rcSP0z6Bkqy8OD,xG6n4Wq2Ib7YgpiarHUNLQJM0 in lCtvKHMzLJVo8fERq9N5:
			KwSdzRXT0M3VW = str(KwSdzRXT0M3VW) if KwSdzRXT0M3VW else wUvcPrYDfISbZolAm83GKEqMyXkn5
			title = bQGafNLXyFgsZP6ut(u"ࠪื๏ืแาࠩॖ")+UKFZBQAVXHI5s17LyvuRpCY2+KUOoYcT20iCLVgsw1ejzdkHp7XW+UKFZBQAVXHI5s17LyvuRpCY2+N3hJXQ4vklxLbRCjGgn+UKFZBQAVXHI5s17LyvuRpCY2+KwSdzRXT0M3VW+UKFZBQAVXHI5s17LyvuRpCY2+t3oe4rjuvpMQKwRnbkTaqYsAI6i5+UKFZBQAVXHI5s17LyvuRpCY2+LcukPqj3x6f9WDZQh5YJzg
			if xG6n4Wq2Ib7YgpiarHUNLQJM0.lower() not in title.lower(): title = title+UKFZBQAVXHI5s17LyvuRpCY2+xG6n4Wq2Ib7YgpiarHUNLQJM0
			title = title.replace(rDG9dZoXRhCJcieUSF0KB(u"ࠫࠪ࠭ॗ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
			xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 += UD4N8MjVTd
			title = str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࠴ࠠࠨक़")+title
			if hhEH1rcSP0z6Bkqy8OD not in j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
				Eu8LWnSt3fyJzIC.append(title)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		if j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
			data = list(zip(Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL))
			if data and rDG9dZoXRhCJcieUSF0KB(u"࠭ࡹࡰࡷࡷࡹࠬख़") not in str(lI7nrTA6abMO): SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨग़"),lI7nrTA6abMO,data,sBTeylAtiQXpFW9wjM5C1m)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = list(Eu8LWnSt3fyJzIC),list(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
	return Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def tTs1D79URu83cnV5whWydXPKBkCvmQ(url):
	JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	if Gj3rMP1Cb8wHdp49la0(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬज़") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,jQv0du1iVxTgAXCM(u"ࠩࡊࡉ࡙࠭ड़"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡍࡄࡄࡔࡑࡇ࡙ࡆࡔ࠰࠵ࡸࡺࠧढ़"))
		hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.url
		if hhEH1rcSP0z6Bkqy8OD: JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	elif llkFwuCyhaP3sK76qO4T(u"ࠫࡸ࡫ࡲࡷ࠿ࠪफ़") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,kPCxIUZb1V(u"ࠬࡍࡅࡕࠩय़"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗ࠳࠲࡯ࡦࠪॠ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॡ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: url = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		else:
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠣࡃ࡯ࡦࡦࡖ࡬ࡢࡻࡨࡶࡈࡵ࡮ࡵࡴࡲࡰࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠢॢ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if hhEH1rcSP0z6Bkqy8OD:
				url = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
				url = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(url)
				if wwMdFkWvcRYiXHB7yDrCqnKb98o: url = url.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			else: return VhqD3zp7mUieI8sMQlETH(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡂࡂࡒࡏࡅ࡞ࡋࡒࠨॣ"),[],[]
		JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = MFhbWia58mP3su0fk2d(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭।"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	return JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO
def eeOBvHCkgD(url,KUOoYcT20iCLVgsw1ejzdkHp7XW,zeSr7gHnFV8MxW9vDOjmy3LacK):
	if w8JC1y7Lp3(u"ࠫࡶࡼࡩࡥࠩ॥") in url:
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = pBRInuQfWwAC5TF1EoS76sgaV(url,KUOoYcT20iCLVgsw1ejzdkHp7XW,zeSr7gHnFV8MxW9vDOjmy3LacK)
		if j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
		return xm6jK1ZMuWq5(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡐࡗ࡙ࡈࡁࠨ०"),[],[]
	return rDG9dZoXRhCJcieUSF0KB(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ१"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def yWREdNcuY9PiS8qDoj2pGChxmf(url):
	if llkFwuCyhaP3sK76qO4T(u"ࠧ࠯࡯࠶ࡹ࠽࠭२") in url:
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,url)
		if j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
		return jQv0du1iVxTgAXCM(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨ३"),[],[]
	return xm6jK1ZMuWq5(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ४"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def F1jKODep2E(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,hUXDz2SbBuqmKe6QJO = [],[]
	if weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭५") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡌࡋࡔࠨ६"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧ७"))
		if w8JC1y7Lp3(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ८") in QM9sJ7tk0oplqEwHU3DjL64d.headers:
			hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ९")]
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,fmkZtbRj3ux(u"ࠨࡰࡤࡱࡪ࠭॰"))
			hUXDz2SbBuqmKe6QJO.append(xG6n4Wq2Ib7YgpiarHUNLQJM0)
	elif it4DKnryZlx(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨॱ") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,xdSThjYnuHXAU6M(u"ࠪࡋࡊ࡚ࠧॲ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭ॳ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		aa3thUFYxDiPv = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬॴ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if aa3thUFYxDiPv:
			aa3thUFYxDiPv = aa3thUFYxDiPv[wTLFCOcM26fmYlW7U]
			Qid14qxXSvtI0ayfKuboj = z69zaGtMRNJrmihgjv25O1dUpYlVf(aa3thUFYxDiPv)
			tyo2D40bfYhqZ1Cvr9 = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫॵ"),Qid14qxXSvtI0ayfKuboj,jj0dZrgiKb.DOTALL)
			if tyo2D40bfYhqZ1Cvr9:
				tyo2D40bfYhqZ1Cvr9 = tyo2D40bfYhqZ1Cvr9[wTLFCOcM26fmYlW7U]
				tyo2D40bfYhqZ1Cvr9 = dm7KA8MukvxF3iH9CW2ZNc(lCT8hfYUBX4OQMmL(u"ࠧ࡭࡫ࡶࡸࠬॶ"),tyo2D40bfYhqZ1Cvr9)
				for dict in tyo2D40bfYhqZ1Cvr9:
					hhEH1rcSP0z6Bkqy8OD = dict[yRWQMHxZEz0(u"ࠨࡨ࡬ࡰࡪ࠭ॷ")]
					KwSdzRXT0M3VW = dict[VhqD3zp7mUieI8sMQlETH(u"ࠩ࡯ࡥࡧ࡫࡬ࠨॸ")]
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
					xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡲࡦࡳࡥࠨॹ"))
					hUXDz2SbBuqmKe6QJO.append(KwSdzRXT0M3VW+UKFZBQAVXHI5s17LyvuRpCY2+xG6n4Wq2Ib7YgpiarHUNLQJM0)
		elif D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ॺ") in QM9sJ7tk0oplqEwHU3DjL64d.headers:
			hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧॻ")]
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࡮ࡢ࡯ࡨࠫॼ"))
			hUXDz2SbBuqmKe6QJO.append(xG6n4Wq2Ib7YgpiarHUNLQJM0)
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧॽ") in url:
			hhEH1rcSP0z6Bkqy8OD = url.split(it4DKnryZlx(u"ࠨࡁࡸࡶࡱࡃࠧॾ"))[UD4N8MjVTd]
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split(yRWQMHxZEz0(u"ࠩࠩࠫॿ"))[wTLFCOcM26fmYlW7U]
			if hhEH1rcSP0z6Bkqy8OD:
				jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
				hUXDz2SbBuqmKe6QJO.append(JHMxIE4fs1mvQtKW7R(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪঀ"))
	else:
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(url)
		xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,llkFwuCyhaP3sK76qO4T(u"ࠫࡳࡧ࡭ࡦࠩঁ"))
		hUXDz2SbBuqmKe6QJO.append(xG6n4Wq2Ib7YgpiarHUNLQJM0)
	if not jcInvNf98TZ5gRUDFp40li2uzVPrO: return rDG9dZoXRhCJcieUSF0KB(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩং"),[],[]
	elif len(jcInvNf98TZ5gRUDFp40li2uzVPrO)==UD4N8MjVTd: hhEH1rcSP0z6Bkqy8OD = jcInvNf98TZ5gRUDFp40li2uzVPrO[wTLFCOcM26fmYlW7U]
	else:
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(bQGafNLXyFgsZP6ut(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫঃ"),hUXDz2SbBuqmKe6QJO)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ঄"),[],[]
		hhEH1rcSP0z6Bkqy8OD = jcInvNf98TZ5gRUDFp40li2uzVPrO[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	return jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫঅ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def VDxTIe4BrMRlzpqb2a(url):
	headers = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭আ"):w8JC1y7Lp3(u"ࠪࡏࡴࡪࡩ࠰ࠩই")+str(Uy6GWujQiBLhodP)}
	for qbRmVByrJv18 in range(DpRJnas65uVcO0S17dYG(u"࠺࠶࿨")):
		L5jXH0fZ8TvsESR.sleep(xx1Qbw9ABV6IYrmHd0vptjElzPf)
		QM9sJ7tk0oplqEwHU3DjL64d = zzJ1qB8RYw7jALnEKoWs(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡌࡋࡔࠨঈ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩউ"))
		if ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨঊ") in list(QM9sJ7tk0oplqEwHU3DjL64d.headers.keys()):
			hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[MFhbWia58mP3su0fk2d(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩঋ")]
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+lCT8hfYUBX4OQMmL(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧঌ")+headers[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭঍")]
			return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
		if QM9sJ7tk0oplqEwHU3DjL64d.code!=jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠺࠲࠺࿩"): break
	return it4DKnryZlx(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ঎"),[],[]
def nnat9XdBGYQbokzsmH7PC2MIvhLNV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,rDG9dZoXRhCJcieUSF0KB(u"ࠫࡌࡋࡔࠨএ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫঐ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ঑"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[KwSdzRXT0M3VW],[hhEH1rcSP0z6Bkqy8OD]
	return bQGafNLXyFgsZP6ut(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ঒"),[],[]
def CS0RsuDKV8(url):
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࠪও") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡊࡉ࡙࠭ঔ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫক"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨখ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: url = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		else: return VhqD3zp7mUieI8sMQlETH(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨগ"),[],[]
	return w8JC1y7Lp3(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩঘ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def O6AvwjFPyc(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,vWNRusF46D7Mi8GpZ(u"ࠧࡈࡇࡗࠫঙ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪচ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	II64TLxj3mbqEyh9pHQ8oAv = ri31J4lpFKX(II64TLxj3mbqEyh9pHQ8oAv)
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪছ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]]
	return llkFwuCyhaP3sK76qO4T(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧজ"),[],[]
def KLjHmDNt67(url):
	if s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡄ࡯ࡤ࠾ࠩঝ") in url:
		headers = {s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫঞ"):A6Sg45ChDR3BJLYfFH(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ট")}
		url,data = url.rsplit(yRWQMHxZEz0(u"ࠧࡀࠩঠ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠱࿪"))
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,MFhbWia58mP3su0fk2d(u"ࠨࡒࡒࡗ࡙࠭ড"),url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠸࠭࠲ࡵࡷࠫঢ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩণ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: url = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		else: return s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠲ࠨত"),[],[]
	return DpRJnas65uVcO0S17dYG(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨথ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def uug6pCUxKH(url):
	if len(url)>erqDsJmL3BQHuGtPkcf0X9(u"࠳࠲࠳࿫"):
		url = url.strip(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭࠯ࠨদ"))+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠰ࠩধ")
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,MFhbWia58mP3su0fk2d(u"ࠨࡉࡈࡘࠬন"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡁࡓࡑ࡝ࡅ࠲࠷ࡳࡵࠩ঩"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		if wTLFCOcM26fmYlW7U and pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴࠬࠫপ") in II64TLxj3mbqEyh9pHQ8oAv:
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠫࠧࡲ࡯ࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪফ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if pLHIPUY3TWAeE70:
				IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
				pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠬࡂࡳࡤࡴ࡬ࡴࡹࡄࡶࡢࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࠩব"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				if pLHIPUY3TWAeE70:
					IJE2xcV7OWauUKhfik56gXBwltCb = CCFGtogTOQY(pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U])
		elif len(II64TLxj3mbqEyh9pHQ8oAv)<D2PpKMeZFWrmfxTSs4L1tz(u"࠶࠳࠴࿬"): hhEH1rcSP0z6Bkqy8OD = II64TLxj3mbqEyh9pHQ8oAv
		else: return JHMxIE4fs1mvQtKW7R(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡄࡖࡔࡠࡁࠨভ"),[],[]
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return A6Sg45ChDR3BJLYfFH(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪম"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def QZCw3MIvEh(url,KUOoYcT20iCLVgsw1ejzdkHp7XW,zeSr7gHnFV8MxW9vDOjmy3LacK):
	if rDG9dZoXRhCJcieUSF0KB(u"ࠨ࠱ࡧࡳࡼࡴ࠮ࡱࡪࡳࠫয") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,kPCxIUZb1V(u"ࠩࡊࡉ࡙࠭র"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡉࡌࡆ࠳࠱ࡴࡶࠪ঱"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡻࡷࡧࡰࡱࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬল"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		url = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	return yRWQMHxZEz0(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ঳"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def Kxr124C0uz(url):
	if jQv0du1iVxTgAXCM(u"࠭ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ঴") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡈࡇࡗࠫ঵"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨশ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧষ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		if llkFwuCyhaP3sK76qO4T(u"ࠪ࡬ࡹࡺࡰࠨস") in hhEH1rcSP0z6Bkqy8OD: return vWNRusF46D7Mi8GpZ(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧহ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
		return DpRJnas65uVcO0S17dYG(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅ࠹࡛ࠧ঺"),[],[]
	return D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ঻"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def MratzORUN5(url):
	ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = ibEuGXOqxHp(url)
	XubVRNO48BsjJASlmeKwdTCr = {rDG9dZoXRhCJcieUSF0KB(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪ়ࠪ"):VhqD3zp7mUieI8sMQlETH(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩঽ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨা"):rDG9dZoXRhCJcieUSF0KB(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪি")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,DpRJnas65uVcO0S17dYG(u"ࠫࡕࡕࡓࡕࠩী"),ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡓࡕࡗ࠮࠳ࡶࡸࠬু"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(kPCxIUZb1V(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫূ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: return DpRJnas65uVcO0S17dYG(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡔࡏࡘࠩৃ"),[],[]
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	return A6Sg45ChDR3BJLYfFH(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫৄ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def PJgTNKZaBr(url):
	headers = {kPCxIUZb1V(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ৅"):xm6jK1ZMuWq5(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ৆")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,VhqD3zp7mUieI8sMQlETH(u"ࠫࡌࡋࡔࠨে"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡓࡔࡌࡐࡓࡑ࠰࠵ࡸࡺࠧৈ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৉"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	if not hhEH1rcSP0z6Bkqy8OD: return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡔࡕࡆࡑࡔࡒࠫ৊"),[],[]
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	return fmkZtbRj3ux(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫো"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def ypBe9URGvC(url):
	ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = ibEuGXOqxHp(url)
	XubVRNO48BsjJASlmeKwdTCr = {SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨৌ"):xdSThjYnuHXAU6M(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺্ࠪ")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,it4DKnryZlx(u"ࠫࡕࡕࡓࡕࠩৎ"),ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡊࡄࡐࡆࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ৏"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࠧࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠭ࠧࠨ৐"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	if not hhEH1rcSP0z6Bkqy8OD: return D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡋࡅࡑࡇࡃࡊࡏࡄࠫ৑"),[],[]
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	if weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡪࡷࡸࡵ࠭৒") not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = Gj3rMP1Cb8wHdp49la0(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ৓")+hhEH1rcSP0z6Bkqy8OD
	return MFhbWia58mP3su0fk2d(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৔"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def cMxuYB5kpT(url):
	q4zyW5Bpx6Y2O,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = url,[],[]
	if MFhbWia58mP3su0fk2d(u"ࠫ࠴ࡧࡪࡢࡺ࠲ࠫ৕") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = ibEuGXOqxHp(url)
		XubVRNO48BsjJASlmeKwdTCr = {kPCxIUZb1V(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ৖"):erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ৗ")}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡑࡑࡖࡘࠬ৘"),ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪ৙"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		xJv6NiWUR7DI = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"ࠩࠪࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭৚"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if xJv6NiWUR7DI: q4zyW5Bpx6Y2O = xJv6NiWUR7DI[wTLFCOcM26fmYlW7U]
	return vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৛"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[q4zyW5Bpx6Y2O]
def CCmXVv3a6U(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,jQv0du1iVxTgAXCM(u"ࠫࡌࡋࡔࠨড়"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫঢ়"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	rxKVPh4onpA5iqzW8G7NuXHIk = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢ৞"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	if rxKVPh4onpA5iqzW8G7NuXHIk:
		rxKVPh4onpA5iqzW8G7NuXHIk = rxKVPh4onpA5iqzW8G7NuXHIk[wTLFCOcM26fmYlW7U][gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠵࿭"):]
		rxKVPh4onpA5iqzW8G7NuXHIk = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(rxKVPh4onpA5iqzW8G7NuXHIk)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: rxKVPh4onpA5iqzW8G7NuXHIk = rxKVPh4onpA5iqzW8G7NuXHIk.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬয়"),rxKVPh4onpA5iqzW8G7NuXHIk,jj0dZrgiKb.DOTALL)
	else: hhEH1rcSP0z6Bkqy8OD = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not hhEH1rcSP0z6Bkqy8OD: return JHMxIE4fs1mvQtKW7R(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡘ࡛ࡌࡕࡏࠩৠ"),[],[]
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	if MFhbWia58mP3su0fk2d(u"ࠩ࡫ࡸࡹࡶࠧৡ") not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪ࡬ࡹࡺࡰ࠻ࠩৢ")+hhEH1rcSP0z6Bkqy8OD
	return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧৣ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def mRvjIWXdBwe(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡍࡅࡕࠩ৤"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨ৥"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ০"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: return fmkZtbRj3ux(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬ১"),[],[]
	hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	return TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ২"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def swVuG9qtXU(url):
	id = url.split(erqDsJmL3BQHuGtPkcf0X9(u"ࠪ࠳ࠬ৩"))[-s149dk8uh2p7oFzaLxZeI3Or(u"࠵࿮")]
	if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ৪") in url: url = url.replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ৫"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	url = url.replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠮ࡤࡱࡰ࠳ࠬ৬"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡳࡥࡵࡣࡧࡥࡹࡧ࠯ࠨ৭"))
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,xdSThjYnuHXAU6M(u"ࠨࡉࡈࡘࠬ৮"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ৯"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	JCxwmazEp2i5eGIZt1 = weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪৰ")
	ffscXeZCModaLjh62GuJIA = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬৱ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ffscXeZCModaLjh62GuJIA: JCxwmazEp2i5eGIZt1 = ffscXeZCModaLjh62GuJIA[wTLFCOcM26fmYlW7U]
	url = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ৲"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not url and JCxwmazEp2i5eGIZt1:
		return JCxwmazEp2i5eGIZt1,[],[]
	hhEH1rcSP0z6Bkqy8OD = url[wTLFCOcM26fmYlW7U].replace(vWNRusF46D7Mi8GpZ(u"࠭࡜࡝ࠩ৳"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	AE7VM9Itbw2Be5hmXQSJW08LkrPy,lI7nrTA6abMO = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,hhEH1rcSP0z6Bkqy8OD)
	AeNt1wShKYUqvMWs7P4CjLgm9f5dcb = OOnvcPQy85HYA.getSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫ৴"))
	if AeNt1wShKYUqvMWs7P4CjLgm9f5dcb and it4DKnryZlx(u"ࠨ࠯ࠪ৵") not in AeNt1wShKYUqvMWs7P4CjLgm9f5dcb: title,hhEH1rcSP0z6Bkqy8OD = AE7VM9Itbw2Be5hmXQSJW08LkrPy[wTLFCOcM26fmYlW7U],lI7nrTA6abMO[wTLFCOcM26fmYlW7U]
	else:
		A3ONzRr6gPkDdJVHTl7UhCeLxcK4 = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡠࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৶"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if A3ONzRr6gPkDdJVHTl7UhCeLxcK4: kr87ujw0S4h6iOJd9IvcKGqY1CNU,n8uSs0idgJzy6Fx,INvQ4tXeVUGOwkRgn3 = A3ONzRr6gPkDdJVHTl7UhCeLxcK4[wTLFCOcM26fmYlW7U]
		else: kr87ujw0S4h6iOJd9IvcKGqY1CNU,n8uSs0idgJzy6Fx,INvQ4tXeVUGOwkRgn3 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		INvQ4tXeVUGOwkRgn3 = INvQ4tXeVUGOwkRgn3.replace(A6Sg45ChDR3BJLYfFH(u"ࠪࡠ࠴࠭৷"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠴࠭৸"))
		n8uSs0idgJzy6Fx = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(n8uSs0idgJzy6Fx)
		Eu8LWnSt3fyJzIC = [JegF7SlMawI03+VhqD3zp7mUieI8sMQlETH(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ৹")+n8uSs0idgJzy6Fx+AAByQSLgaZwCsKnvc5eWNmY]+AE7VM9Itbw2Be5hmXQSJW08LkrPy
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [INvQ4tXeVUGOwkRgn3]+lI7nrTA6abMO
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ৺")+str(len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)-DpRJnas65uVcO0S17dYG(u"࠶࿯"))+VhqD3zp7mUieI8sMQlETH(u"ࠧࠡ็็ๅ࠮࠭৻"),Eu8LWnSt3fyJzIC)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ৼ"),[],[]
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==wTLFCOcM26fmYlW7U:
			Rce9KaHhLg73QAOPMVE = Sph0cr2ZWK1atAUw5CTuxoe.argv[wTLFCOcM26fmYlW7U]+llkFwuCyhaP3sK76qO4T(u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨ৽")+INvQ4tXeVUGOwkRgn3+s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࠪࡹ࡫ࡸࡵࡶࡀࠫ৾")+n8uSs0idgJzy6Fx
			te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(vWNRusF46D7Mi8GpZ(u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ৿")+Rce9KaHhLg73QAOPMVE+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠯ࠢ਀"))
			return D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਁ"),[],[]
		title,hhEH1rcSP0z6Bkqy8OD = Eu8LWnSt3fyJzIC[EcQws7L35GvtIpl0k1gJZWTNPDbmMq],j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,[title],[hhEH1rcSP0z6Bkqy8OD]
def J4AVWmyI0c(hhEH1rcSP0z6Bkqy8OD):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡈࡇࡗࠫਂ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,kPCxIUZb1V(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧਃ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if yRWQMHxZEz0(u"ࠩ࠱࡮ࡸࡵ࡮ࠨ਄") in hhEH1rcSP0z6Bkqy8OD: url = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪਅ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else: url = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਆ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not url: return xm6jK1ZMuWq5(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭ਇ"),[],[]
	url = url[wTLFCOcM26fmYlW7U]
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡨࡵࡶࡳࠫਈ") not in url: url = JHMxIE4fs1mvQtKW7R(u"ࠧࡩࡶࡷࡴ࠿࠭ਉ")+url
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def ANhj1dxElfTuGgwLSPKeyaU(url):
	headers = { llkFwuCyhaP3sK76qO4T(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਊ") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ਋") in url:
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ਌"))
		items = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ਍"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if items: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[items[wTLFCOcM26fmYlW7U]]
		else:
			SLAiUwpDRoZIQfvB7 = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ਎"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if SLAiUwpDRoZIQfvB7:
				IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨਏ"),SLAiUwpDRoZIQfvB7[wTLFCOcM26fmYlW7U])
				return D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡆࡴࡵࡳࡷࡀࠠࠨਐ")+SLAiUwpDRoZIQfvB7[wTLFCOcM26fmYlW7U],[],[]
	else:
		QSuoms9tfxPZwgEea = it4DKnryZlx(u"ࠨ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠫ਑")
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫ਒"))
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬਓ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: return dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨਔ"),[],[]
		q4zyW5Bpx6Y2O = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U]
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U][UD4N8MjVTd]
		if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠴ࡲࡢࡴࠪਕ") in IJE2xcV7OWauUKhfik56gXBwltCb or Gj3rMP1Cb8wHdp49la0(u"࠭࠮ࡻ࡫ࡳࠫਖ") in IJE2xcV7OWauUKhfik56gXBwltCb: return jQv0du1iVxTgAXCM(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬਗ"),[],[]
		items = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਘ"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		COW137cpIhBMYTSiAR9s2Dlzw = {}
		for LcukPqj3x6f9WDZQh5YJzg,value in items:
			COW137cpIhBMYTSiAR9s2Dlzw[LcukPqj3x6f9WDZQh5YJzg] = value
		data = rqPJzRuUF2L(COW137cpIhBMYTSiAR9s2Dlzw)
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,q4zyW5Bpx6Y2O,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫਙ"))
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨਚ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: return erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨਛ"),[],[]
		download = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U]
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U][UD4N8MjVTd]
		items = jj0dZrgiKb.findall(s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬਜ"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		VUsLcf1yqFrxn5HQM,Eu8LWnSt3fyJzIC,tbpP1Z9dNE,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,lJdCOMKWX1RaY53pErnhqg = [],[],[],[],[]
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if TNw1pBHb8CtSZe0EFxuJqI(u"࠭࠮࡮࠵ࡸ࠼ࠬਝ") in hhEH1rcSP0z6Bkqy8OD:
				VUsLcf1yqFrxn5HQM,tbpP1Z9dNE = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,hhEH1rcSP0z6Bkqy8OD)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL + tbpP1Z9dNE
				if VUsLcf1yqFrxn5HQM[wTLFCOcM26fmYlW7U]==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࠮࠳ࠪਞ"): Eu8LWnSt3fyJzIC.append(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭ਟ")+JHMxIE4fs1mvQtKW7R(u"ࠩࡰ࠷ࡺ࠾ࠠࠨਠ")+QSuoms9tfxPZwgEea)
				else:
					for title in VUsLcf1yqFrxn5HQM:
						Eu8LWnSt3fyJzIC.append(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨਡ")+s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡲ࠹ࡵ࠹ࠢࠪਢ")+QSuoms9tfxPZwgEea+UKFZBQAVXHI5s17LyvuRpCY2+title)
			else:
				title = title.replace(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧਣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				title = title.strip(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࠢࠨਤ"))
				title = TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭ਥ")+weh7SGmuTgXOVRcMo1rlLq(u"ࠨࠢࡰࡴ࠹ࠦࠧਦ")+QSuoms9tfxPZwgEea+UKFZBQAVXHI5s17LyvuRpCY2+title
				Eu8LWnSt3fyJzIC.append(title)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		hhEH1rcSP0z6Bkqy8OD = VhqD3zp7mUieI8sMQlETH(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫਧ") + download
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬਨ"))
		items = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣ਩"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for id,ooPMZSnrRDG6xNpJHVmgw8IOA1,hash,ttpAvDoOKGf in items:
			title = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩਪ")+ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࠠ࡮ࡲ࠷ࠤࠬਫ")+QSuoms9tfxPZwgEea+UKFZBQAVXHI5s17LyvuRpCY2+ttpAvDoOKGf.split(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡹࠩਬ"))[UD4N8MjVTd]
			hhEH1rcSP0z6Bkqy8OD = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭ਭ")+id+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩਮ")+ooPMZSnrRDG6xNpJHVmgw8IOA1+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪਯ")+hash
			lJdCOMKWX1RaY53pErnhqg.append(ttpAvDoOKGf)
			Eu8LWnSt3fyJzIC.append(title)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		lJdCOMKWX1RaY53pErnhqg = set(lJdCOMKWX1RaY53pErnhqg)
		EEerAD7SOC2M5NqGQWFXmYub,kxumfp2K3DOIR = [],[]
		for title in Eu8LWnSt3fyJzIC:
			SZwIybtTC9R2Wl1u = jj0dZrgiKb.findall(lCT8hfYUBX4OQMmL(u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦਰ"),title+Gj3rMP1Cb8wHdp49la0(u"ࠬࠬࠦࠨ਱"),jj0dZrgiKb.DOTALL)
			for ttpAvDoOKGf in lJdCOMKWX1RaY53pErnhqg:
				if SZwIybtTC9R2Wl1u[wTLFCOcM26fmYlW7U] in ttpAvDoOKGf:
					title = title.replace(SZwIybtTC9R2Wl1u[wTLFCOcM26fmYlW7U],ttpAvDoOKGf.split(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡸࠨਲ"))[UD4N8MjVTd])
			EEerAD7SOC2M5NqGQWFXmYub.append(title)
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)):
			items = jj0dZrgiKb.findall(w8JC1y7Lp3(u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣਲ਼"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࠨࠩࠫ਴")+EEerAD7SOC2M5NqGQWFXmYub[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠩࠪࠬਵ"),jj0dZrgiKb.DOTALL)
			kxumfp2K3DOIR.append( [EEerAD7SOC2M5NqGQWFXmYub[kkLhJCU4MQSx7s6gyeOHrRYKtnP3],j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[kkLhJCU4MQSx7s6gyeOHrRYKtnP3],items[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U],items[wTLFCOcM26fmYlW7U][UD4N8MjVTd]] )
		kxumfp2K3DOIR = sorted(kxumfp2K3DOIR, key=lambda E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ: E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ[MMRBkhnWVJCQwU], reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		kxumfp2K3DOIR = sorted(kxumfp2K3DOIR, key=lambda E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ: E4T7PDmjRNuCI2l9dfp6xbiO8BwaJ[Tb7oymMnpflsSv3eu4Pz2], reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(kxumfp2K3DOIR)):
			Eu8LWnSt3fyJzIC.append(kxumfp2K3DOIR[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][wTLFCOcM26fmYlW7U])
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(kxumfp2K3DOIR[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][UD4N8MjVTd])
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return VhqD3zp7mUieI8sMQlETH(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧਸ਼"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def sPBSfXKGhr9JiYzVEyc7(url):
	deg2JDUOioWfbC8NcswK1RFAlk4M = url.split(llkFwuCyhaP3sK76qO4T(u"ࠫࡄ࠭਷"))
	ZD5n0eJivzWOMxY98dgrumkwRG = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
	headers = { dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਸ") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭ਹ"))
	items = jj0dZrgiKb.findall(it4DKnryZlx(u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ਺"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	url = items[wTLFCOcM26fmYlW7U]
	return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ਻"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def izHAo7gwfbsVn(url):
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	headers = { it4DKnryZlx(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ਼࠭") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ਽"))
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਾ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]]
	else: return vWNRusF46D7Mi8GpZ(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨਿ"),[],[]
def rE1pnSHoU4hwZ(url):
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	headers = { Gj3rMP1Cb8wHdp49la0(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪੀ") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭ੁ"))
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫੂ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]]
	else: return Gj3rMP1Cb8wHdp49la0(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ੃"),[],[]
def VF8tB9Rrmv(url):
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,errno = [],[],wUvcPrYDfISbZolAm83GKEqMyXkn5
	if yRWQMHxZEz0(u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ੄") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = ibEuGXOqxHp(url)
		XubVRNO48BsjJASlmeKwdTCr = {kPCxIUZb1V(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ੅"):vWNRusF46D7Mi8GpZ(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ੆")}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,DpRJnas65uVcO0S17dYG(u"࠭ࡐࡐࡕࡗࠫੇ"),ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪੈ"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		if xnGN2vER8iQqJkcFt4KWup.startswith(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡪࡷࡸࡵ࠭੉")): ZD5n0eJivzWOMxY98dgrumkwRG = xnGN2vER8iQqJkcFt4KWup
		else:
			qaLFXuDExl8w = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨࠩࠪ੊"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if qaLFXuDExl8w:
				ZD5n0eJivzWOMxY98dgrumkwRG = qaLFXuDExl8w[wTLFCOcM26fmYlW7U]
				qaLFXuDExl8w = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪ࡝ࠩࠨࡢ࠭ੋ"),ZD5n0eJivzWOMxY98dgrumkwRG,jj0dZrgiKb.DOTALL)
				if qaLFXuDExl8w:
					ZD5n0eJivzWOMxY98dgrumkwRG = Z6bUG0kDQuFqgzdAa1r(qaLFXuDExl8w[wTLFCOcM26fmYlW7U])
					return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬੌ") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡍࡅࡕ੍ࠩ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ੎"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		if DpRJnas65uVcO0S17dYG(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ੏") in list(QM9sJ7tk0oplqEwHU3DjL64d.headers.keys()): ZD5n0eJivzWOMxY98dgrumkwRG = QM9sJ7tk0oplqEwHU3DjL64d.headers[JHMxIE4fs1mvQtKW7R(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ੐")]
		else:
			ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ੑ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U] if ZD5n0eJivzWOMxY98dgrumkwRG else url
	if kPCxIUZb1V(u"ࠪ࠳ࡻ࠵ࠧ੒") in ZD5n0eJivzWOMxY98dgrumkwRG or MFhbWia58mP3su0fk2d(u"ࠫ࠴࡬࠯ࠨ੓") in ZD5n0eJivzWOMxY98dgrumkwRG:
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.replace(xm6jK1ZMuWq5(u"ࠬ࠵ࡦ࠰ࠩ੔"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ੕"))
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.replace(lCT8hfYUBX4OQMmL(u"ࠧ࠰ࡸ࠲ࠫ੖"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ੗"))
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡓࡓࡘ࡚ࠧ੘"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭ਖ਼"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		items = jj0dZrgiKb.findall(lCT8hfYUBX4OQMmL(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧਗ਼"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(bQGafNLXyFgsZP6ut(u"ࠬࡢ࡜ࠨਜ਼"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				Eu8LWnSt3fyJzIC.append(title)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		else:
			items = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧੜ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if items:
				hhEH1rcSP0z6Bkqy8OD = items[wTLFCOcM26fmYlW7U]
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࡝࡞ࠪ੝"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				Eu8LWnSt3fyJzIC.append(wUvcPrYDfISbZolAm83GKEqMyXkn5)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	else: return Gj3rMP1Cb8wHdp49la0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਫ਼"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return VhqD3zp7mUieI8sMQlETH(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ੟"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def oasyB3Y47C(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,yRWQMHxZEz0(u"ࠪࡋࡊ࡚ࠧ੠"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠲ࡵࡷࠫ੡"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,errno = [],[],wUvcPrYDfISbZolAm83GKEqMyXkn5
	if it4DKnryZlx(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ੢") in url or gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ੣") in url:
		if kPCxIUZb1V(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ੤") in url:
			ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੥"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if bQGafNLXyFgsZP6ut(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ੦") not in ZD5n0eJivzWOMxY98dgrumkwRG: return VhqD3zp7mUieI8sMQlETH(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭੧"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,yRWQMHxZEz0(u"ࠫࡌࡋࡔࠨ੨"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ੩"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ੪"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੫"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,JrzealiFtp6 in items:
				Eu8LWnSt3fyJzIC.append(JrzealiFtp6)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	elif kPCxIUZb1V(u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ੬") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭੭"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡋࡊ࡚ࠧ੮"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ੯"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		qaLFXuDExl8w = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧੰ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		qaLFXuDExl8w = qaLFXuDExl8w[wTLFCOcM26fmYlW7U]
		Eu8LWnSt3fyJzIC.append(wUvcPrYDfISbZolAm83GKEqMyXkn5)
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(qaLFXuDExl8w)
	elif jQv0du1iVxTgAXCM(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠ࡮࡬ࡲࡰ࠭ੱ") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠧ࠽ࡥࡨࡲࡹ࡫ࡲ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪੲ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if ZD5n0eJivzWOMxY98dgrumkwRG:
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]
			return kPCxIUZb1V(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫੳ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫੴ"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def KavYIOMF5p(url):
	if weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡃ࡬࡫ࡴ࠾ࠩੵ") in url:
		hhEH1rcSP0z6Bkqy8OD = url.split(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡄ࡭ࡥࡵ࠿ࠪ੶"),UD4N8MjVTd)[UD4N8MjVTd]
		hhEH1rcSP0z6Bkqy8OD = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(hhEH1rcSP0z6Bkqy8OD)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ੷"))
		return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ੸"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	website = TTuO14NzmB.SITESURLS[xdSThjYnuHXAU6M(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ੹")][wTLFCOcM26fmYlW7U]
	headers = {VhqD3zp7mUieI8sMQlETH(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ੺"):website}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,fmkZtbRj3ux(u"ࠩࡊࡉ࡙࠭੻"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮࠴ࡱࡨࠬ੼"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡺࡸ࡬ࠨ੽"))
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੾"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(it4DKnryZlx(u"ࠨࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠫ࠭࠴ࠪࡀࠫࠪࠦ੿"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"ࠢࡧ࡫࡯ࡩ࠿࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ઀"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]+D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫઁ")+website
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠩં") in II64TLxj3mbqEyh9pHQ8oAv:
		FHVZCMi38GEK94Lp2r01akXuT = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬઃ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if FHVZCMi38GEK94Lp2r01akXuT:
			hhEH1rcSP0z6Bkqy8OD = FHVZCMi38GEK94Lp2r01akXuT[wTLFCOcM26fmYlW7U]
			hhEH1rcSP0z6Bkqy8OD = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(hhEH1rcSP0z6Bkqy8OD)
			if wwMdFkWvcRYiXHB7yDrCqnKb98o: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,lCT8hfYUBX4OQMmL(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ઄"))
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠬ࡮ࡴࡵࡲ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࠭ࠩઅ"),hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL)
			if hhEH1rcSP0z6Bkqy8OD:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]+DpRJnas65uVcO0S17dYG(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩઆ")+website
				return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪઇ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def QpoF5DkPh4(url,oQbdyTekSgKa):
	hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = [],[]
	if A6Sg45ChDR3BJLYfFH(u"ࠨ࠱࠴࠳ࠬઈ") in url:
		hhEH1rcSP0z6Bkqy8OD = url.replace(kPCxIUZb1V(u"ࠩ࠲࠵࠴࠭ઉ"),llkFwuCyhaP3sK76qO4T(u"ࠪ࠳࠹࠵ࠧઊ"))
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡌࡋࡔࠨઋ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠵ࡸࡺࠧઌ"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"࠭࠼ࡷ࡫ࡧࡩࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡥࡧࡲࡂࠬઍ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
			items = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭઎"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW in items:
				if hhEH1rcSP0z6Bkqy8OD not in jcInvNf98TZ5gRUDFp40li2uzVPrO:
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
					xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡰࡤࡱࡪ࠭એ"))
					hUXDz2SbBuqmKe6QJO.append(xG6n4Wq2Ib7YgpiarHUNLQJM0+lB8tuyg6sxkDVYAaS95K3GI+KwSdzRXT0M3VW)
			return wUvcPrYDfISbZolAm83GKEqMyXkn5,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO
	elif xdSThjYnuHXAU6M(u"ࠩ࠲ࡨ࠴࠭ઐ") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡋࡊ࡚ࠧઑ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭઒"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ઓ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U].replace(erqDsJmL3BQHuGtPkcf0X9(u"࠭࠯࠲࠱ࠪઔ"),fmkZtbRj3ux(u"ࠧ࠰࠶࠲ࠫક"))
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,yRWQMHxZEz0(u"ࠨࡉࡈࡘࠬખ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧࠫગ"))
			xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪઘ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if hhEH1rcSP0z6Bkqy8OD: return jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧઙ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]]
	elif s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࠵ࡲࡰ࡮ࡨ࠳ࠬચ") in url:
		headers = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧછ"):oQbdyTekSgKa}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡈࡇࡗࠫજ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠴ࡵࡪࠪઝ"))
		hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫઞ")]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,bQGafNLXyFgsZP6ut(u"ࠪࡋࡊ࡚ࠧટ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠸ࡸ࡭࠭ઠ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = M7vhoWYQOFSmD0GIycR(hhEH1rcSP0z6Bkqy8OD,II64TLxj3mbqEyh9pHQ8oAv)
		return JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO
	elif rDG9dZoXRhCJcieUSF0KB(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩડ") in url:
		ZD5n0eJivzWOMxY98dgrumkwRG = url.replace(s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪઢ"),w8JC1y7Lp3(u"ࠧ࠰ࡵࡦࡶ࡮ࡶࡴ࠰ࠩણ"))
		XubVRNO48BsjJASlmeKwdTCr = {kPCxIUZb1V(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩત"):oQbdyTekSgKa}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡊࡉ࡙࠭થ"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠸ࡷ࡬ࠬદ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬધ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,DpRJnas65uVcO0S17dYG(u"ࠬࡍࡅࡕࠩન"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠼ࡺࡨࠨ઩"))
			II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
			if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩપ") in list(QM9sJ7tk0oplqEwHU3DjL64d.headers.keys()):
				hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪફ")]
				QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡊࡉ࡙࠭બ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠺ࡷ࡬ࠬભ"))
				II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
				JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = M7vhoWYQOFSmD0GIycR(hhEH1rcSP0z6Bkqy8OD,II64TLxj3mbqEyh9pHQ8oAv)
				if jcInvNf98TZ5gRUDFp40li2uzVPrO: return JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO
			elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬમ") in hhEH1rcSP0z6Bkqy8OD:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(MFhbWia58mP3su0fk2d(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ય"),A6Sg45ChDR3BJLYfFH(u"࠭࠯࡫ࡹࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪર"))
				return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ઱"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	else: return weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫલ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	return DpRJnas65uVcO0S17dYG(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ળ"),[],[]
def v5vW02AcV8(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,xm6jK1ZMuWq5(u"ࠪࡋࡊ࡚ࠧ઴"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,kPCxIUZb1V(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭વ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	data = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭શ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if data:
		J4JzObTYPoR,id,XwIuWnDcHKvxQE07bPNh2kG8frZ = data[wTLFCOcM26fmYlW7U]
		data = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࡯ࡱ࠿ࠪષ")+J4JzObTYPoR+MFhbWia58mP3su0fk2d(u"ࠧࠧ࡫ࡧࡁࠬસ")+id+JHMxIE4fs1mvQtKW7R(u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩહ")+XwIuWnDcHKvxQE07bPNh2kG8frZ
		headers = {dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ઺"):bQGafNLXyFgsZP6ut(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ઻")}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,Gj3rMP1Cb8wHdp49la0(u"ࠫࡕࡕࡓࡕ઼ࠩ"),url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧઽ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩા"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: return it4DKnryZlx(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪિ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]]
	return jQv0du1iVxTgAXCM(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬી"),[],[]
def YLCDhAx5rF(url):
	headers = {weh7SGmuTgXOVRcMo1rlLq(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬુ"):dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫૂ")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡌࡋࡔࠨૃ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰࠵ࡸࡺࠧૄ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫૅ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U].replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		return llkFwuCyhaP3sK76qO4T(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ૆"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return bQGafNLXyFgsZP6ut(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬે"),[],[]
def JnsR2T8B09(url):
	ZD5n0eJivzWOMxY98dgrumkwRG = url.split(w8JC1y7Lp3(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪૈ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U].strip(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡃࠬૉ")).strip(D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࠴࠭૊")).strip(lCT8hfYUBX4OQMmL(u"ࠬࠬࠧો"))
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,items,qaLFXuDExl8w = [],[],[],wUvcPrYDfISbZolAm83GKEqMyXkn5
	headers = { ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪૌ"):xdSThjYnuHXAU6M(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯્ࠧ") }
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,it4DKnryZlx(u"ࠨࡉࡈࡘࠬ૎"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪ૏"))
	if JHMxIE4fs1mvQtKW7R(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬૐ") in list(QM9sJ7tk0oplqEwHU3DjL64d.headers.keys()): qaLFXuDExl8w = QM9sJ7tk0oplqEwHU3DjL64d.headers[lCT8hfYUBX4OQMmL(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭૑")]
	if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬ࡮ࡴࡵࡲࠪ૒") in qaLFXuDExl8w:
		if xdSThjYnuHXAU6M(u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ૓") in url: qaLFXuDExl8w = qaLFXuDExl8w.replace(bQGafNLXyFgsZP6ut(u"ࠧ࠰ࡨ࠲ࠫ૔"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࠱ࡹ࠳ࠬ૕"))
		J3lr0ekTXWYuNtIH = ZD5n0eJivzWOMxY98dgrumkwRG.split(Gj3rMP1Cb8wHdp49la0(u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ૖"))[UD4N8MjVTd]
		headers = { bQGafNLXyFgsZP6ut(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ૗"):headers[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૘")] , TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ૙"):jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ૚")+J3lr0ekTXWYuNtIH }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,it4DKnryZlx(u"ࠧࡈࡇࡗࠫ૛"),qaLFXuDExl8w,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ૜"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		if jQv0du1iVxTgAXCM(u"ࠩ࠲ࡪ࠴࠭૝") in qaLFXuDExl8w: items = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૞"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		elif xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࠴ࡼ࠯ࠨ૟") in qaLFXuDExl8w: items = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૠ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if items: return [],[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ items[wTLFCOcM26fmYlW7U] ]
		elif jQv0du1iVxTgAXCM(u"࠭࠼ࡩ࠳ࡁ࠸࠵࠺࠼࠰ࡪ࠴ࡂࠬૡ") in II64TLxj3mbqEyh9pHQ8oAv:
			return gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡆࡴࡵࡳࡷࡀࠠิ์ิๅึࠦวๅใํำ๏๎ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯฺ๋๋้ࠢีั่่๊ࠢࠥอไฦ่อี๋ะࠠศๆัหฺฯࠠษๅࠪૢ"),[],[]
	else: return MFhbWia58mP3su0fk2d(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗࠫૣ"),[],[]
def SDn3kzMBgQ(hhEH1rcSP0z6Bkqy8OD):
	deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ૤"),hhEH1rcSP0z6Bkqy8OD+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࠪࠫ࠭૥"),jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
	url = vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ૦")+E2Y7y4Av63tqhSVQ50iTmN+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ૧")+LoCyDnPKj2N7RsmcI0WwAZTE
	headers = { TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ૨"):wUvcPrYDfISbZolAm83GKEqMyXkn5 , TNw1pBHb8CtSZe0EFxuJqI(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ૩"):it4DKnryZlx(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ૪") }
	ZD5n0eJivzWOMxY98dgrumkwRG = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ૫"))
	return llkFwuCyhaP3sK76qO4T(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭૬"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
def UMFnku9ZcV(url):
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡺࡸ࡬ࠨ૭"))
	XubVRNO48BsjJASlmeKwdTCr = {s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭૮"):xG6n4Wq2Ib7YgpiarHUNLQJM0,erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ૯"):dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ૰")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡉࡈࡘࠬ૱"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ૲"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ૳"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	ZD5n0eJivzWOMxY98dgrumkwRG = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ૴"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			Eu8LWnSt3fyJzIC.append(title)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==UD4N8MjVTd: ZD5n0eJivzWOMxY98dgrumkwRG = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[wTLFCOcM26fmYlW7U]
		elif len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)>UD4N8MjVTd:
			EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(llkFwuCyhaP3sK76qO4T(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ૵"), Eu8LWnSt3fyJzIC)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ૶"),[],[]
			ZD5n0eJivzWOMxY98dgrumkwRG = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(kPCxIUZb1V(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૷"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: ZD5n0eJivzWOMxY98dgrumkwRG = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
	if not ZD5n0eJivzWOMxY98dgrumkwRG: return ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ૸"),[],[]
	return gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૹ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
def LcZYu3IMdy(url):
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,MFhbWia58mP3su0fk2d(u"ࠪࡹࡷࡲࠧૺ"))
	XubVRNO48BsjJASlmeKwdTCr = {erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬૻ"):xG6n4Wq2Ib7YgpiarHUNLQJM0,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧૼ"):weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭૽")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡈࡇࡗࠫ૾"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ૿"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(vWNRusF46D7Mi8GpZ(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ଀"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	ZD5n0eJivzWOMxY98dgrumkwRG = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
		items = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩଁ"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			Eu8LWnSt3fyJzIC.append(title)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
		if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==UD4N8MjVTd: ZD5n0eJivzWOMxY98dgrumkwRG = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[wTLFCOcM26fmYlW7U]
		elif len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)>UD4N8MjVTd:
			EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(it4DKnryZlx(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩଂ"),Eu8LWnSt3fyJzIC)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪଃ"),[],[]
			ZD5n0eJivzWOMxY98dgrumkwRG = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	if not ZD5n0eJivzWOMxY98dgrumkwRG:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ଄"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: ZD5n0eJivzWOMxY98dgrumkwRG = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
	if not ZD5n0eJivzWOMxY98dgrumkwRG: return D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩଅ"),[],[]
	return it4DKnryZlx(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫଆ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
def Y0ZSpnAUJc(hhEH1rcSP0z6Bkqy8OD):
	deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(erqDsJmL3BQHuGtPkcf0X9(u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨଇ"),hhEH1rcSP0z6Bkqy8OD+TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࠪࠫ࠭ଈ"),jj0dZrgiKb.DOTALL)
	url,E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
	data = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬଉ"):E2Y7y4Av63tqhSVQ50iTmN,w8JC1y7Lp3(u"ࠬࡹࡥࡳࡸࡨࡶࠬଊ"):LoCyDnPKj2N7RsmcI0WwAZTE}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,xm6jK1ZMuWq5(u"࠭ࡐࡐࡕࡗࠫଋ"),url,data,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩଌ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭଍"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
	return ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ଎"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
def fckzxFCTyS(url):
	hhEH1rcSP0z6Bkqy8OD = url
	if bQGafNLXyFgsZP6ut(u"ࠪࡃࡸ࡫ࡲࡷ࠿ࠪଏ") in url:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡌࡋࡔࠨଐ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࠷ࡳࡵࠩ଑"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ଒"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		else: return Gj3rMP1Cb8wHdp49la0(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ଓ"),[],[]
	return Gj3rMP1Cb8wHdp49la0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫଔ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def LUOwxAiIV7(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡊࡉ࡙࠭କ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭ଖ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬଗ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		if hhEH1rcSP0z6Bkqy8OD: return jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨଘ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return lCT8hfYUBX4OQMmL(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫଙ"),[],[]
def GeVUAOD0WX(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡈࡇࡗࠫଚ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪଛ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଜ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
	return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ଝ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def nHbYcuLB7N(url):
	lnpS3fLJa4GiNoctb = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡺࡸ࡬ࠨଞ"))
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬଟ") in url:
		headers = {weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧଠ"):lnpS3fLJa4GiNoctb}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡈࡇࡗࠫଡ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩଢ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧଣ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if ZD5n0eJivzWOMxY98dgrumkwRG:
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]
			if erqDsJmL3BQHuGtPkcf0X9(u"ࠪ࡬ࡹࡺࡰࠨତ") not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = w8JC1y7Lp3(u"ࠫ࡭ࡺࡴࡱ࠼ࠪଥ")+ZD5n0eJivzWOMxY98dgrumkwRG
			if w8JC1y7Lp3(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ଦ") in ZD5n0eJivzWOMxY98dgrumkwRG:
				QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,bQGafNLXyFgsZP6ut(u"࠭ࡇࡆࡖࠪଧ"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨନ"))
				xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
				items = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ଩"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
				if not items:
					pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࡠࡠ࠮࠮ࠫࡁࠬࡠࡢࡢ࠮ࠨପ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
					if pLHIPUY3TWAeE70:
						i9eu0gvptXjKMAczZyE = pLHIPUY3TWAeE70[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠶࿰")]
						items = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠪࠦࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮ࠨࠧଫ"),i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
						if items:
							X9n3NUMtawvxPp7kREZKgVmcY0We,Ip3wDG5RX2dWFcxMjm = zip(*items)
							items = list(zip(Ip3wDG5RX2dWFcxMjm,X9n3NUMtawvxPp7kREZKgVmcY0We))
				Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
				U62oVRpWuriEJAwedHOxStI9m8bCQ = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,A6Sg45ChDR3BJLYfFH(u"ࠫࡺࡸ࡬ࠨବ"))
				for hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW in reversed(items):
					hhEH1rcSP0z6Bkqy8OD = U62oVRpWuriEJAwedHOxStI9m8bCQ+hhEH1rcSP0z6Bkqy8OD+VhqD3zp7mUieI8sMQlETH(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨଭ")+U62oVRpWuriEJAwedHOxStI9m8bCQ
					Eu8LWnSt3fyJzIC.append(KwSdzRXT0M3VW)
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
				return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
			else: return VhqD3zp7mUieI8sMQlETH(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩମ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	ZD5n0eJivzWOMxY98dgrumkwRG = url+lCT8hfYUBX4OQMmL(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪଯ")+lnpS3fLJa4GiNoctb
	if xm6jK1ZMuWq5(u"ࠨࡪࡷࡸࡵ࠭ର") not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = jQv0du1iVxTgAXCM(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ଱")+ZD5n0eJivzWOMxY98dgrumkwRG
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
def TydMDgIOYXeqkF1o0hxJ8m(hhEH1rcSP0z6Bkqy8OD):
	lnpS3fLJa4GiNoctb = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,MFhbWia58mP3su0fk2d(u"ࠪࡹࡷࡲࠧଲ"))
	if it4DKnryZlx(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫଳ") in hhEH1rcSP0z6Bkqy8OD:
		deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ଴"),hhEH1rcSP0z6Bkqy8OD+D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࠦࠧࠩଵ"),jj0dZrgiKb.DOTALL)
		url,E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
		data = {gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡪࡦࠪଶ"):E2Y7y4Av63tqhSVQ50iTmN,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨଷ"):LoCyDnPKj2N7RsmcI0WwAZTE}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡓࡓࡘ࡚ࠧସ"),url,data,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫହ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ଺"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
		if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭଻") in ZD5n0eJivzWOMxY98dgrumkwRG:
			headers = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡒࡦࡨࡨࡶࡪࡸ଼ࠧ"):lnpS3fLJa4GiNoctb,rDG9dZoXRhCJcieUSF0KB(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଽ"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡉࡈࡘࠬା"),ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪି"))
			xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
			items = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩୀ"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
			U62oVRpWuriEJAwedHOxStI9m8bCQ = TO3vi2rSZ0LRhKlwgG4qkYFIC(ZD5n0eJivzWOMxY98dgrumkwRG,fmkZtbRj3ux(u"ࠫࡺࡸ࡬ࠨୁ"))
			for hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW in reversed(items):
				hhEH1rcSP0z6Bkqy8OD = U62oVRpWuriEJAwedHOxStI9m8bCQ+hhEH1rcSP0z6Bkqy8OD+DpRJnas65uVcO0S17dYG(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨୂ")+U62oVRpWuriEJAwedHOxStI9m8bCQ
				Eu8LWnSt3fyJzIC.append(KwSdzRXT0M3VW)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
		else: return gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩୃ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	else:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+MFhbWia58mP3su0fk2d(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪୄ")+lnpS3fLJa4GiNoctb
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
def KiofgBtErJ(url):
	if VhqD3zp7mUieI8sMQlETH(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ୅") in url:
		deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(JHMxIE4fs1mvQtKW7R(u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠳ࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭୆"),url,jj0dZrgiKb.DOTALL)
		if deg2JDUOioWfbC8NcswK1RFAlk4M:
			ZD5n0eJivzWOMxY98dgrumkwRG,E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
			import string as tf0VNjAMH7XCo8rbuy
			gA3dYfFxNtOGIMcKmu = wUvcPrYDfISbZolAm83GKEqMyXkn5.join(kItsbxAFUXc3.choice(tf0VNjAMH7XCo8rbuy.ascii_letters+tf0VNjAMH7XCo8rbuy.digits) for _oXjMfCa70kzFBspe8mgEV6un in range(jQv0du1iVxTgAXCM(u"࠱࠷࿱")))
			agU8idnP4CJS = w8JC1y7Lp3(u"ࠪ࠱࠲࠳࠭ࡘࡧࡥࡏ࡮ࡺࡆࡰࡴࡰࡆࡴࡻ࡮ࡥࡣࡵࡽࠬେ")+gA3dYfFxNtOGIMcKmu
			XubVRNO48BsjJASlmeKwdTCr = {lCT8hfYUBX4OQMmL(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪୈ"):vWNRusF46D7Mi8GpZ(u"ࠬࡳࡵ࡭ࡶ࡬ࡴࡦࡸࡴ࠰ࡨࡲࡶࡲ࠳ࡤࡢࡶࡤ࠿ࠥࡨ࡯ࡶࡰࡧࡥࡷࡿ࠽ࠨ୉")+agU8idnP4CJS}
			cKWuEGxtTfrBDj7I5 = {jQv0du1iVxTgAXCM(u"ࠨࡐࡰࡵࡷࡍࡉࠨ୊"):E2Y7y4Av63tqhSVQ50iTmN,bQGafNLXyFgsZP6ut(u"ࠢࡔࡧࡵࡺࡪࡸࡉࡅࠤୋ"):LoCyDnPKj2N7RsmcI0WwAZTE}
			deg2JDUOioWfbC8NcswK1RFAlk4M = []
			for key,value in cKWuEGxtTfrBDj7I5.items(): deg2JDUOioWfbC8NcswK1RFAlk4M.append(vWNRusF46D7Mi8GpZ(u"ࠨ࠯࠰ࠩࡸࡢࡲ࡝ࡰࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡈ࡮ࡹࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠻ࠢࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦ࡮ࡢ࡯ࡨࡁࠧࠫࡳࠣ࡞ࡵࡠࡳࡢࡲ࡝ࡰࠨࡷࠬୌ")%(agU8idnP4CJS,key,value))
			deg2JDUOioWfbC8NcswK1RFAlk4M.append(VhqD3zp7mUieI8sMQlETH(u"ࠩ࠰࠱ࠪࡹ࠭࠮୍ࠩ") % agU8idnP4CJS)
			FjUcS938pAH5sZ = JHMxIE4fs1mvQtKW7R(u"ࠪࡠࡷࡢ࡮ࠨ୎").join(deg2JDUOioWfbC8NcswK1RFAlk4M)
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡕࡕࡓࡕࠩ୏"),ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡒࡈ࡞ࡔࡅࡕ࠯࠴ࡷࡹ࠭୐"))
			url = QM9sJ7tk0oplqEwHU3DjL64d.content
			if kPCxIUZb1V(u"࠭ࡨࡵࡶࡳࠫ୑") not in url: return yRWQMHxZEz0(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡓࡉ࡟ࡎࡆࡖࠪ୒"),[],[]
	return DpRJnas65uVcO0S17dYG(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ୓"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def FiMGp0mqwW(hhEH1rcSP0z6Bkqy8OD):
	if TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡳࡳࡸࡺࡩࡥࠩ୔") in hhEH1rcSP0z6Bkqy8OD:
		deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ୕"),hhEH1rcSP0z6Bkqy8OD+bQGafNLXyFgsZP6ut(u"ࠫࠫࠬࠧୖ"),jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
		c2K0TAgyHFLsX = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡻࡲ࡭ࠩୗ"))
		url = c2K0TAgyHFLsX+TNw1pBHb8CtSZe0EFxuJqI(u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ୘")+E2Y7y4Av63tqhSVQ50iTmN+xdSThjYnuHXAU6M(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ୙")+LoCyDnPKj2N7RsmcI0WwAZTE
		headers = { JHMxIE4fs1mvQtKW7R(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ୚"):wUvcPrYDfISbZolAm83GKEqMyXkn5 , it4DKnryZlx(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ୛"):jQv0du1iVxTgAXCM(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫଡ଼") }
		ZD5n0eJivzWOMxY98dgrumkwRG = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭ଢ଼"))
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		return jQv0du1iVxTgAXCM(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୞"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	elif VhqD3zp7mUieI8sMQlETH(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪୟ") in hhEH1rcSP0z6Bkqy8OD:
		QHPnObBLYWmN6oZfag = wTLFCOcM26fmYlW7U
		while w8JC1y7Lp3(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫୠ") in hhEH1rcSP0z6Bkqy8OD and QHPnObBLYWmN6oZfag<gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠶࿲"):
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,it4DKnryZlx(u"ࠨࡉࡈࡘࠬୡ"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫୢ"))
			if xdSThjYnuHXAU6M(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬୣ") in list(QM9sJ7tk0oplqEwHU3DjL64d.headers.keys()): hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭୤")]
			QHPnObBLYWmN6oZfag += UD4N8MjVTd
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	else: return jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ୥"),[],[]
def BZErkcCYxU(url):
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,bQGafNLXyFgsZP6ut(u"࠭ࡵࡳ࡮ࠪ୦"))
	headers = {jQv0du1iVxTgAXCM(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ୧"):xG6n4Wq2Ib7YgpiarHUNLQJM0,llkFwuCyhaP3sK76qO4T(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ୨"):ZZIDf1A9vE0g86RMq7tpKUrzaij()}
	if it4DKnryZlx(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ୩") in url:
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ୪"))
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ୫"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if hhEH1rcSP0z6Bkqy8OD:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U].replace(rDG9dZoXRhCJcieUSF0KB(u"ࠬ࡮ࡴࡵࡲࡶࠫ୬"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡨࡵࡶࡳࠫ୭"))
			return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	else:
		QBirTEdhFKu = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡈࡇࡗࠫ୮"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪ୯"))
		II64TLxj3mbqEyh9pHQ8oAv = QBirTEdhFKu.content
		XubVRNO48BsjJASlmeKwdTCr = headers.copy()
		if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡢࡰࡳࡱ࡟ࠨ୰") in str(QBirTEdhFKu.cookies):
			cookies = QBirTEdhFKu.cookies
			XubVRNO48BsjJASlmeKwdTCr[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪୱ")] = Z6bUG0kDQuFqgzdAa1r(rqPJzRuUF2L(cookies))
		hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡱ࡯࡮࡬࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ୲"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not hhEH1rcSP0z6Bkqy8OD: return xdSThjYnuHXAU6M(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୳"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
		else:
			hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U])+bQGafNLXyFgsZP6ut(u"࠭ࠦࡥ࠿࠴ࠫ୴")
			toEMTSVjIO = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡈࡇࡗࠫ୵"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪ୶"))
			II64TLxj3mbqEyh9pHQ8oAv = toEMTSVjIO.content
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ୷"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if hhEH1rcSP0z6Bkqy8OD:
				hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U])
				if D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡱࡵ࠺ࠧ୸") in hhEH1rcSP0z6Bkqy8OD and xdSThjYnuHXAU6M(u"ࠫ࠴ࡪ࠯ࠨ୹") in hhEH1rcSP0z6Bkqy8OD: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
				else: return vWNRusF46D7Mi8GpZ(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୺"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return llkFwuCyhaP3sK76qO4T(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ୻"),[],[]
def y0tR1hI5BJ(hhEH1rcSP0z6Bkqy8OD):
	if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠫ୼") in hhEH1rcSP0z6Bkqy8OD:
		headers = {erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ୽"):D2PpKMeZFWrmfxTSs4L1tz(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ୾")}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡋࡊ࡚ࠧ୿"),hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭஀"))
		url = QM9sJ7tk0oplqEwHU3DjL64d.content
		if url: return VhqD3zp7mUieI8sMQlETH(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ஁"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	else:
		deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(vWNRusF46D7Mi8GpZ(u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧஂ"),hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if not deg2JDUOioWfbC8NcswK1RFAlk4M: deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(xm6jK1ZMuWq5(u"ࠧࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪஃ"),hhEH1rcSP0z6Bkqy8OD,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		E2Y7y4Av63tqhSVQ50iTmN,LoCyDnPKj2N7RsmcI0WwAZTE = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
		xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhEH1rcSP0z6Bkqy8OD,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡷࡵࡰࠬ஄"))
		url = xG6n4Wq2Ib7YgpiarHUNLQJM0+llkFwuCyhaP3sK76qO4T(u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪஅ")
		data = {llkFwuCyhaP3sK76qO4T(u"ࠪ࡭ࡩ࠭ஆ"):E2Y7y4Av63tqhSVQ50iTmN,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡮࠭இ"):LoCyDnPKj2N7RsmcI0WwAZTE}
		headers = {SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨஈ"):DpRJnas65uVcO0S17dYG(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧஉ"),A6Sg45ChDR3BJLYfFH(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨஊ"):hhEH1rcSP0z6Bkqy8OD}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡒࡒࡗ࡙࠭஋"),url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫ஌"))
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ஍"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if ZD5n0eJivzWOMxY98dgrumkwRG:
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U]
			return rDG9dZoXRhCJcieUSF0KB(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧஎ"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	return MFhbWia58mP3su0fk2d(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊ࠴ࡖࠩஏ"),[],[]
def voMinPzADhSQqsmGNXf0blw5(wkc1U6HFW29sCrmLuxVJG):
	m1tgQd7x035hH = OOnvcPQy85HYA.getSetting(xdSThjYnuHXAU6M(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧஐ"))
	headers = {jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ஑"):m1tgQd7x035hH} if m1tgQd7x035hH else wUvcPrYDfISbZolAm83GKEqMyXkn5
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,A6Sg45ChDR3BJLYfFH(u"ࠨࡉࡈࡘࠬஒ"),wkc1U6HFW29sCrmLuxVJG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠷ࡳࡵࠩஓ"))
	QjyqwaveorkSlGnRDx4JtUV9Pc = QM9sJ7tk0oplqEwHU3DjL64d.content
	ccPpRHuT8KLWdinfNo2wSzb = str(QM9sJ7tk0oplqEwHU3DjL64d.headers)
	NTd1DaVCQUh53P7vEqAy = ccPpRHuT8KLWdinfNo2wSzb+QjyqwaveorkSlGnRDx4JtUV9Pc
	if kPCxIUZb1V(u"ࠪ࠲ࡲࡶ࠴ࠨஔ") in NTd1DaVCQUh53P7vEqAy: DJQIGSCHUMdvxo4 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	else:
		WIONmeZRH8,wkKMJqu0VaeWm,F48FuSOpY7Z1xdAeVTvyBwj,rLNBMuq2iyCZUwfSaotWQ85GVpzj,DJQIGSCHUMdvxo4 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA
		captcha = jj0dZrgiKb.findall(s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩக"),QjyqwaveorkSlGnRDx4JtUV9Pc,jj0dZrgiKb.DOTALL)
		if captcha: F48FuSOpY7Z1xdAeVTvyBwj,rLNBMuq2iyCZUwfSaotWQ85GVpzj = captcha[wTLFCOcM26fmYlW7U]
		LsfGmE5wozPAJWu0kNclaOV8y9 = TTuO14NzmB.SITESURLS[weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ஖")][ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠹࿳")]
		if wTLFCOcM26fmYlW7U:
			data = {kPCxIUZb1V(u"࠭ࡵࡴࡧࡵࠫ஗"):TTuO14NzmB.AV_CLIENT_IDS,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ஘"):D1DBSuO0lLGRbcfCyY,bQGafNLXyFgsZP6ut(u"ࠨࡷࡵࡰࠬங"):wkc1U6HFW29sCrmLuxVJG,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࡮ࡩࡾ࠭ச"):rLNBMuq2iyCZUwfSaotWQ85GVpzj,kPCxIUZb1V(u"ࠪ࡭ࡩ࠭஛"):wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠫ࡯ࡵࡢࠨஜ"):weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭஝")}
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡐࡐࡕࡗࠫஞ"),LsfGmE5wozPAJWu0kNclaOV8y9,data,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧட"))
			II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		II64TLxj3mbqEyh9pHQ8oAv = wUvcPrYDfISbZolAm83GKEqMyXkn5
		if II64TLxj3mbqEyh9pHQ8oAv.startswith(VhqD3zp7mUieI8sMQlETH(u"ࠨࡗࡕࡐࡘࡃࠧ஠")):
			wwH9NWv8LbqMyo1IQElsXU = dm7KA8MukvxF3iH9CW2ZNc(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩ࡯࡭ࡸࡺࠧ஡"),II64TLxj3mbqEyh9pHQ8oAv.split(it4DKnryZlx(u"࡙ࠪࡗࡒࡓ࠾ࠩ஢"),UD4N8MjVTd)[UD4N8MjVTd])
			for ySY5NxERP6jeVG in wwH9NWv8LbqMyo1IQElsXU:
				url = ySY5NxERP6jeVG[w8JC1y7Lp3(u"ࠫࡺࡸ࡬ࠨண")]
				N2t8i1vLnORq4rhK9fwFXDWe = ySY5NxERP6jeVG[TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡳࡥࡵࡪࡲࡨࠬத")]
				data = ySY5NxERP6jeVG[MFhbWia58mP3su0fk2d(u"࠭ࡤࡢࡶࡤࠫ஥")]
				headers = ySY5NxERP6jeVG[jQv0du1iVxTgAXCM(u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨ஦")]
				QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,N2t8i1vLnORq4rhK9fwFXDWe,url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ஧"))
				QjyqwaveorkSlGnRDx4JtUV9Pc = QM9sJ7tk0oplqEwHU3DjL64d.content
				if JHMxIE4fs1mvQtKW7R(u"ࠩ࠱ࡱࡵ࠺ࠧந") in QjyqwaveorkSlGnRDx4JtUV9Pc:
					DJQIGSCHUMdvxo4 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
					break
				ccPpRHuT8KLWdinfNo2wSzb = str(QM9sJ7tk0oplqEwHU3DjL64d.headers)
				NTd1DaVCQUh53P7vEqAy = ccPpRHuT8KLWdinfNo2wSzb+QjyqwaveorkSlGnRDx4JtUV9Pc
				WIONmeZRH8 = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫன"),NTd1DaVCQUh53P7vEqAy,jj0dZrgiKb.DOTALL)
				wkKMJqu0VaeWm = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬப"),NTd1DaVCQUh53P7vEqAy,jj0dZrgiKb.DOTALL)
				if wkKMJqu0VaeWm: wkKMJqu0VaeWm = wkKMJqu0VaeWm[wTLFCOcM26fmYlW7U]
				if WIONmeZRH8 or wkKMJqu0VaeWm: break
		if not DJQIGSCHUMdvxo4:
			if not WIONmeZRH8:
				if captcha and not wkKMJqu0VaeWm:
					if UD4N8MjVTd: wkKMJqu0VaeWm = gHRQEzxamAwup3Xys0cBoP4FYG(rLNBMuq2iyCZUwfSaotWQ85GVpzj,erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡧࡲࠨ஫"),wkc1U6HFW29sCrmLuxVJG)
					else:
						if not II64TLxj3mbqEyh9pHQ8oAv.startswith(fmkZtbRj3ux(u"࠭ࡉࡅ࠿ࠪ஬")):
							data = {pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡶࡵࡨࡶࠬ஭"):TTuO14NzmB.AV_CLIENT_IDS,xm6jK1ZMuWq5(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩம"):D1DBSuO0lLGRbcfCyY,xdSThjYnuHXAU6M(u"ࠩࡸࡶࡱ࠭ய"):wkc1U6HFW29sCrmLuxVJG,kPCxIUZb1V(u"ࠪ࡯ࡪࡿࠧர"):rLNBMuq2iyCZUwfSaotWQ85GVpzj,lCT8hfYUBX4OQMmL(u"ࠫ࡮ࡪࠧற"):wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠬࡰ࡯ࡣࠩல"):dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡧࡦࡶ࡬ࡨࠬள")}
							QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡑࡑࡖࡘࠬழ"),LsfGmE5wozPAJWu0kNclaOV8y9,data,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨவ"))
							II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
						else: II64TLxj3mbqEyh9pHQ8oAv = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪஶ")
						if II64TLxj3mbqEyh9pHQ8oAv.startswith(VhqD3zp7mUieI8sMQlETH(u"ࠪࡍࡉࡃࠧஷ")):
							HFx9Z1e6mE2bQGg = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪஸ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
							s7FCywmeNbKoRTkcpX,CCOaZv7IcwLueUDFi9pWNBEylr5 = HFx9Z1e6mE2bQGg[wTLFCOcM26fmYlW7U]
							SLAiUwpDRoZIQfvB7 = jQv0du1iVxTgAXCM(u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪஹ")+CCOaZv7IcwLueUDFi9pWNBEylr5+vWNRusF46D7Mi8GpZ(u"࠭ࠠฬษ้๎ฮ࠭஺")
							OO9xQWZnuTNMf1SDFE43JPeV = tt4jsl3YLKexr()
							OO9xQWZnuTNMf1SDFE43JPeV.create(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭஻"),SLAiUwpDRoZIQfvB7)
							xY8mQbyJj5pDtNW6qh0iBd9e = L5jXH0fZ8TvsESR.time()
							HUAanSeNVBi,l3N12c6RbKuzf8OswV7pFToDEA = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
							while HUAanSeNVBi<int(CCOaZv7IcwLueUDFi9pWNBEylr5):
								snqyW34dKikc8eHXJIxDbuzSUtLf(OO9xQWZnuTNMf1SDFE43JPeV,int(HUAanSeNVBi/int(CCOaZv7IcwLueUDFi9pWNBEylr5)*rDG9dZoXRhCJcieUSF0KB(u"࠴࠴࠵࿴")),SLAiUwpDRoZIQfvB7,wUvcPrYDfISbZolAm83GKEqMyXkn5,CCOaZv7IcwLueUDFi9pWNBEylr5+it4DKnryZlx(u"ࠨࠢ࠲ࠤࠬ஼")+str(int(HUAanSeNVBi))+D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࠣࠤะอๆ๋หࠪ஽"))
								if HUAanSeNVBi>l3N12c6RbKuzf8OswV7pFToDEA+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵࠵࿵"):
									data = {xm6jK1ZMuWq5(u"ࠪࡹࡸ࡫ࡲࠨா"):TTuO14NzmB.AV_CLIENT_IDS,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬி"):D1DBSuO0lLGRbcfCyY,fmkZtbRj3ux(u"ࠬࡻࡲ࡭ࠩீ"):wkc1U6HFW29sCrmLuxVJG,rDG9dZoXRhCJcieUSF0KB(u"࠭࡫ࡦࡻࠪு"):rLNBMuq2iyCZUwfSaotWQ85GVpzj,VhqD3zp7mUieI8sMQlETH(u"ࠧࡪࡦࠪூ"):s7FCywmeNbKoRTkcpX,bQGafNLXyFgsZP6ut(u"ࠨ࡬ࡲࡦࠬ௃"):xm6jK1ZMuWq5(u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫ௄")}
									QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,xdSThjYnuHXAU6M(u"ࠪࡔࡔ࡙ࡔࠨ௅"),LsfGmE5wozPAJWu0kNclaOV8y9,data,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫெ"))
									II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
									if II64TLxj3mbqEyh9pHQ8oAv.startswith(weh7SGmuTgXOVRcMo1rlLq(u"࡚ࠬࡏࡌࡇࡑࡁࠬே")):
										wkKMJqu0VaeWm = II64TLxj3mbqEyh9pHQ8oAv.split(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡔࡐࡍࡈࡒࡂ࠭ை"),xm6jK1ZMuWq5(u"࠶࿶"))[UD4N8MjVTd]
										break
									l3N12c6RbKuzf8OswV7pFToDEA = HUAanSeNVBi
								else: L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
								HUAanSeNVBi = L5jXH0fZ8TvsESR.time()-xY8mQbyJj5pDtNW6qh0iBd9e
							OO9xQWZnuTNMf1SDFE43JPeV.close()
				if wkKMJqu0VaeWm:
					Ncm8OZI2FEPKdv5sT7nolbJXLDxiQ = QM9sJ7tk0oplqEwHU3DjL64d.cookies
					O3FDpqbfMGoKR4xiA9WBhLv1c = jj0dZrgiKb.findall(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧ௉"),NTd1DaVCQUh53P7vEqAy,jj0dZrgiKb.DOTALL)
					if ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨொ") in list(Ncm8OZI2FEPKdv5sT7nolbJXLDxiQ.keys()): O3FDpqbfMGoKR4xiA9WBhLv1c = Ncm8OZI2FEPKdv5sT7nolbJXLDxiQ[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩோ")]
					elif O3FDpqbfMGoKR4xiA9WBhLv1c: O3FDpqbfMGoKR4xiA9WBhLv1c = O3FDpqbfMGoKR4xiA9WBhLv1c[wTLFCOcM26fmYlW7U]
					captcha = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨௌ"),QjyqwaveorkSlGnRDx4JtUV9Pc,jj0dZrgiKb.DOTALL)
					if captcha: F48FuSOpY7Z1xdAeVTvyBwj,rLNBMuq2iyCZUwfSaotWQ85GVpzj = captcha[wTLFCOcM26fmYlW7U]
					if O3FDpqbfMGoKR4xiA9WBhLv1c and captcha:
						headers = {erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡈࡵ࡯࡬࡫ࡨ்ࠫ"):MFhbWia58mP3su0fk2d(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭௎")+O3FDpqbfMGoKR4xiA9WBhLv1c,kPCxIUZb1V(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ௏"):wkc1U6HFW29sCrmLuxVJG,weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ௐ"):SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ௑")}
						data = rDG9dZoXRhCJcieUSF0KB(u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠪ௒")+wkKMJqu0VaeWm
						QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡔࡔ࡙ࡔࠨ௓"),F48FuSOpY7Z1xdAeVTvyBwj,data,headers,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ௔"))
						QjyqwaveorkSlGnRDx4JtUV9Pc = QM9sJ7tk0oplqEwHU3DjL64d.content
						try: cookies = QM9sJ7tk0oplqEwHU3DjL64d.cookies
						except: cookies = {}
						WIONmeZRH8 = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ௕"),str(cookies),jj0dZrgiKb.DOTALL)
			if WIONmeZRH8:
				LcukPqj3x6f9WDZQh5YJzg,WIONmeZRH8 = WIONmeZRH8[wTLFCOcM26fmYlW7U]
				m1tgQd7x035hH = LcukPqj3x6f9WDZQh5YJzg+D2PpKMeZFWrmfxTSs4L1tz(u"࠭࠽ࠨ௖")+WIONmeZRH8
				OOnvcPQy85HYA.setSetting(MFhbWia58mP3su0fk2d(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨௗ"),m1tgQd7x035hH)
				IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,fmkZtbRj3ux(u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬ௘"))
				if vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࠱ࡱࡵ࠺ࠧ௙") not in QjyqwaveorkSlGnRDx4JtUV9Pc:
					headers = {xm6jK1ZMuWq5(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ௚"):m1tgQd7x035hH}
					QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,VhqD3zp7mUieI8sMQlETH(u"ࠫࡌࡋࡔࠨ௛"),wkc1U6HFW29sCrmLuxVJG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬ௜"))
					QjyqwaveorkSlGnRDx4JtUV9Pc = QM9sJ7tk0oplqEwHU3DjL64d.content
		if captcha and not DJQIGSCHUMdvxo4 and not m1tgQd7x035hH: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,yRWQMHxZEz0(u"࠭แีๆอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ࠲࠳ࠦอศ๊็ࠤส฿วะหࠣห้฿ๅๅ์ฬࠤ๊ืษࠡลัี๎ࠦศศีอาิอๅ่ࠡไืࠥอไโ์า๎ํࠦร้ࠢไ๎ิ๐่ࠡ฼ํี์ࠦๅ็้ࠢๅุࠦวๅ็๋ๆ฾࠭௝"))
	return QjyqwaveorkSlGnRDx4JtUV9Pc
def myIlApe52K(url,KUOoYcT20iCLVgsw1ejzdkHp7XW,KwSdzRXT0M3VW):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,hUXDz2SbBuqmKe6QJO = [],[]
	wkc1U6HFW29sCrmLuxVJG = url
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,A6Sg45ChDR3BJLYfFH(u"ࠧࡈࡇࡗࠫ௞"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ௟"))
	xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
	m7q9DgWLi3sQSuyYJ = []
	if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ௠") in xnGN2vER8iQqJkcFt4KWup or Gj3rMP1Cb8wHdp49la0(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ௡") in xnGN2vER8iQqJkcFt4KWup:
		qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall(kPCxIUZb1V(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠲࠯ࡅ࠼࠰ࡣࡁࠫ௢"),xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if qqtR56dgVLh3Tr2:
			for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
				ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ௣"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for hhEH1rcSP0z6Bkqy8OD,title in ppAJI9kDbz5MXa76UEF:
					if hhEH1rcSP0z6Bkqy8OD in jcInvNf98TZ5gRUDFp40li2uzVPrO: continue
					if VhqD3zp7mUieI8sMQlETH(u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ௤") not in hhEH1rcSP0z6Bkqy8OD and dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ௥") not in hhEH1rcSP0z6Bkqy8OD: continue
					if kPCxIUZb1V(u"ࠨษࠪ௦") not in title:
						m7q9DgWLi3sQSuyYJ.append((title,hhEH1rcSP0z6Bkqy8OD))
						continue
					title = title.replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪ௧"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࠤ࠲ࠦࠧ௨"),wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
					if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡸࡶࡡ࡯ࠩ௩") in title: continue
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
					hUXDz2SbBuqmKe6QJO.append(title)
			for title,hhEH1rcSP0z6Bkqy8OD in m7q9DgWLi3sQSuyYJ:
				if hhEH1rcSP0z6Bkqy8OD not in jcInvNf98TZ5gRUDFp40li2uzVPrO:
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
					hUXDz2SbBuqmKe6QJO.append(title)
			EcQws7L35GvtIpl0k1gJZWTNPDbmMq = wTLFCOcM26fmYlW7U
			if len(jcInvNf98TZ5gRUDFp40li2uzVPrO)>UD4N8MjVTd:
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(VhqD3zp7mUieI8sMQlETH(u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬ௪"),hUXDz2SbBuqmKe6QJO)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ௫"),[],[]
			if jcInvNf98TZ5gRUDFp40li2uzVPrO and EcQws7L35GvtIpl0k1gJZWTNPDbmMq>=wTLFCOcM26fmYlW7U: wkc1U6HFW29sCrmLuxVJG = jcInvNf98TZ5gRUDFp40li2uzVPrO[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	QjyqwaveorkSlGnRDx4JtUV9Pc = voMinPzADhSQqsmGNXf0blw5(wkc1U6HFW29sCrmLuxVJG)
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,Eu8LWnSt3fyJzIC = [],[]
	if KUOoYcT20iCLVgsw1ejzdkHp7XW==rDG9dZoXRhCJcieUSF0KB(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ௬"):
		o6GgYJqXlN2nf = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭௭"),QjyqwaveorkSlGnRDx4JtUV9Pc,jj0dZrgiKb.DOTALL)
		if o6GgYJqXlN2nf:
			hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(o6GgYJqXlN2nf[wTLFCOcM26fmYlW7U])
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			Eu8LWnSt3fyJzIC.append(KwSdzRXT0M3VW)
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==bQGafNLXyFgsZP6ut(u"ࠩࡺࡥࡹࡩࡨࠨ௮"):
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall(s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௯"),QjyqwaveorkSlGnRDx4JtUV9Pc,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,size in ppAJI9kDbz5MXa76UEF:
			if not hhEH1rcSP0z6Bkqy8OD: continue
			if KwSdzRXT0M3VW in size:
				Eu8LWnSt3fyJzIC.append(size)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
				break
		if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
			for hhEH1rcSP0z6Bkqy8OD,size in ppAJI9kDbz5MXa76UEF:
				if not hhEH1rcSP0z6Bkqy8OD: continue
				Eu8LWnSt3fyJzIC.append(size)
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL: return pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ௰"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def V78QvGpgDT(url,LcukPqj3x6f9WDZQh5YJzg):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,w8JC1y7Lp3(u"ࠬࡍࡅࡕࠩ௱"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ௲"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	cookies = QM9sJ7tk0oplqEwHU3DjL64d.cookies
	if JHMxIE4fs1mvQtKW7R(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ௳") in list(cookies.keys()):
		m1tgQd7x035hH = cookies[lCT8hfYUBX4OQMmL(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ௴")]
		m1tgQd7x035hH = Z6bUG0kDQuFqgzdAa1r(aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(m1tgQd7x035hH))
		items = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ௵"),m1tgQd7x035hH,jj0dZrgiKb.DOTALL)
		ZD5n0eJivzWOMxY98dgrumkwRG = items[wTLFCOcM26fmYlW7U].replace(TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡠ࠴࠭௶"),rDG9dZoXRhCJcieUSF0KB(u"ࠫ࠴࠭௷"))
		ZD5n0eJivzWOMxY98dgrumkwRG = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(ZD5n0eJivzWOMxY98dgrumkwRG)
	else: ZD5n0eJivzWOMxY98dgrumkwRG = url
	if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ௸") in ZD5n0eJivzWOMxY98dgrumkwRG:
		d0yrGP8JuBH = ZD5n0eJivzWOMxY98dgrumkwRG.split(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࠥ࠳ࡈࠪ௹"))[-UD4N8MjVTd]
		ZD5n0eJivzWOMxY98dgrumkwRG = fmkZtbRj3ux(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ௺")+d0yrGP8JuBH
		return xm6jK1ZMuWq5(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ௻"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ZD5n0eJivzWOMxY98dgrumkwRG]
	else:
		website = TTuO14NzmB.SITESURLS[vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡄࡏࡔࡇࡍࠨ௼")][wTLFCOcM26fmYlW7U]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡋࡊ࡚ࠧ௽"),website,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠲࡯ࡦࠪ௾"))
		Ml0bWwhGU6ASEYfFsDIBT7ujteXN8 = QM9sJ7tk0oplqEwHU3DjL64d.url
		oABGg9v4yr6jRx7CIqW = ZD5n0eJivzWOMxY98dgrumkwRG.split(TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࠵ࠧ௿"))[Tb7oymMnpflsSv3eu4Pz2]
		NiVqL2W6PoTlHn7 = Ml0bWwhGU6ASEYfFsDIBT7ujteXN8.split(s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠯ࠨఀ"))[Tb7oymMnpflsSv3eu4Pz2]
		qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG.replace(oABGg9v4yr6jRx7CIqW,NiVqL2W6PoTlHn7)
		headers = { D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫఁ"):wUvcPrYDfISbZolAm83GKEqMyXkn5 , VhqD3zp7mUieI8sMQlETH(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫం"):D2PpKMeZFWrmfxTSs4L1tz(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪః") , yRWQMHxZEz0(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫఄ"):qaLFXuDExl8w }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,rDG9dZoXRhCJcieUSF0KB(u"ࠫࡕࡕࡓࡕࠩఅ"), qaLFXuDExl8w, wUvcPrYDfISbZolAm83GKEqMyXkn5, headers, Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫఆ"))
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		items = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ఇ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if not items:
			items = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఈ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
			if not items:
				items = jj0dZrgiKb.findall(xm6jK1ZMuWq5(u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఉ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if items:
			hhEH1rcSP0z6Bkqy8OD = items[wTLFCOcM26fmYlW7U].replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡟࠳ࠬఊ"),w8JC1y7Lp3(u"ࠪ࠳ࠬఋ"))
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.rstrip(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫ࠴࠭ఌ"))
			if vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ࡮ࡴࡵࡲࠪ఍") not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = yRWQMHxZEz0(u"࠭ࡨࡵࡶࡳ࠾ࠬఎ") + hhEH1rcSP0z6Bkqy8OD
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨఏ"),jQv0du1iVxTgAXCM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪఐ"))
			if LcukPqj3x6f9WDZQh5YJzg==wUvcPrYDfISbZolAm83GKEqMyXkn5: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
			else: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = JHMxIE4fs1mvQtKW7R(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ఑"),[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
		else: JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡐࡃࡐࠫఒ"),[],[]
		return JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def ocemYixOR0lG5Hq(url):
	headers = { w8JC1y7Lp3(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨఓ") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩఔ"))
	items = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧక"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,errno = [],[],wUvcPrYDfISbZolAm83GKEqMyXkn5
	if items:
		for hhEH1rcSP0z6Bkqy8OD,JrzealiFtp6 in items:
			Eu8LWnSt3fyJzIC.append(JrzealiFtp6)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return MFhbWia58mP3su0fk2d(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭ఖ"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def s1dOTD49hwV0R(url):
	LTt0Peg4HUB8wSxEn9pZiMWmDc753G = url.split(rDG9dZoXRhCJcieUSF0KB(u"ࠨ࠱ࠪగ"))[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠹࿷")]
	data = bQGafNLXyFgsZP6ut(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠧ࡫ࡧࡁࠬఘ")+LTt0Peg4HUB8wSxEn9pZiMWmDc753G
	headers = {A6Sg45ChDR3BJLYfFH(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩఙ"):kPCxIUZb1V(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪచ")}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,fmkZtbRj3ux(u"ࠬࡖࡏࡔࡖࠪఛ"),url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡖࡉࡒ࠭࠲ࡵࡷࠫజ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall(A6Sg45ChDR3BJLYfFH(u"ࠧࡢࡦࡥࡰࡴࡩ࡫ࡠࡦࡨࡸࡪࡩࡴࡦࡦ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫఝ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		url = items[wTLFCOcM26fmYlW7U]
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	return bQGafNLXyFgsZP6ut(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡗࡊࡌࠨఞ"),[],[]
def eMCEGLFtTOS0msIqrgknz(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,vWNRusF46D7Mi8GpZ(u"ࠩࡊࡉ࡙࠭ట"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡌ࠯࠴ࡷࡹ࠭ఠ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	try: II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.decode(llkFwuCyhaP3sK76qO4T(u"ࠫࡺࡺࡦ࠹ࠩడ"),llkFwuCyhaP3sK76qO4T(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬఢ"))
	except: pass
	items = jj0dZrgiKb.findall(fmkZtbRj3ux(u"࠭ࡤࡰࡥࡶࡣࡳࡵ࡟ࡱࡴࡨࡺ࡮࡫ࡷࡠࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧణ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		url = items[wTLFCOcM26fmYlW7U]
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	else:
		JCxwmazEp2i5eGIZt1 = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠧࠣࡸ࡬ࡨࡪࡵ࡟ࡦࡺࡷࡣࡲࡹࡧࠣࡀ࡟ࡲ࠰࠮࠮ࠫࡁࠬࡠࡳ࠱࠼ࠨత"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if JCxwmazEp2i5eGIZt1: return JCxwmazEp2i5eGIZt1[yRWQMHxZEz0(u"࠰࿸")][:it4DKnryZlx(u"࠸࠲࿹")],[],[]
	return JHMxIE4fs1mvQtKW7R(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡐ࠭థ"),[],[]
def cSrtbA1WNp(url):
	headers = {xm6jK1ZMuWq5(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ద"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪధ"))
	items = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩన"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		url = items[wTLFCOcM26fmYlW7U]+it4DKnryZlx(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ఩")+url
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	return JHMxIE4fs1mvQtKW7R(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨప"),[],[]
def Pk7c09DLpRFOJiQ(url):
	url = url.strip(xm6jK1ZMuWq5(u"ࠧ࠰ࠩఫ"))
	if kPCxIUZb1V(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩబ") in url: d0yrGP8JuBH = url.split(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩ࠲ࠫభ"))[R9RNUT6WAPEYjHqtIokxuXs]
	else: d0yrGP8JuBH = url.split(VhqD3zp7mUieI8sMQlETH(u"ࠪ࠳ࠬమ"))[-UD4N8MjVTd]
	url = s149dk8uh2p7oFzaLxZeI3Or(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨయ") + d0yrGP8JuBH
	headers = { jnqzf9WihpUlxmcAEZ1vMLXNu(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩర") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨఱ"))
	II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࡝࡞ࠪల"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	items = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨళ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ items[wTLFCOcM26fmYlW7U] ]
	return rDG9dZoXRhCJcieUSF0KB(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭ఴ"),[],[]
def kkJXDIoKjvSCa6POxpV1AQ(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪవ"))
	items = jj0dZrgiKb.findall(xm6jK1ZMuWq5(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫశ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	for hhEH1rcSP0z6Bkqy8OD,JrzealiFtp6,SZwIybtTC9R2Wl1u in items:
		Eu8LWnSt3fyJzIC.append(JrzealiFtp6+UKFZBQAVXHI5s17LyvuRpCY2+SZwIybtTC9R2Wl1u)
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return MFhbWia58mP3su0fk2d(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧష"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def B2BRHraT1ZPgJqXO9e(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪస"))
	items = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧహ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	items = set(items)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	for d0yrGP8JuBH,ooPMZSnrRDG6xNpJHVmgw8IOA1,SScgGieqMldjy5Q4WhNE8D0XJwHtB,JrzealiFtp6,SZwIybtTC9R2Wl1u in items:
		url = w8JC1y7Lp3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ఺")+d0yrGP8JuBH+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ఻")+ooPMZSnrRDG6xNpJHVmgw8IOA1+VhqD3zp7mUieI8sMQlETH(u"ࠪࠪ࡭ࡧࡳࡩ࠿఼ࠪ")+SScgGieqMldjy5Q4WhNE8D0XJwHtB
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨఽ"))
		items = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫా"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in items:
			Eu8LWnSt3fyJzIC.append(JrzealiFtp6+UKFZBQAVXHI5s17LyvuRpCY2+SZwIybtTC9R2Wl1u)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==wTLFCOcM26fmYlW7U: return yRWQMHxZEz0(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬి"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def u7JgcOfvjhp4UbL0Fqsa(url):
	hhEH1rcSP0z6Bkqy8OD = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if llkFwuCyhaP3sK76qO4T(u"ࠧࡌࡧࡼࡁࠬీ") not in url:
		ZD5n0eJivzWOMxY98dgrumkwRG = url.replace(DpRJnas65uVcO0S17dYG(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬు"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭ూ"))
		ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG.split(lCT8hfYUBX4OQMmL(u"ࠪ࠳ࠬృ"))
		d0yrGP8JuBH = ZD5n0eJivzWOMxY98dgrumkwRG[MMRBkhnWVJCQwU]
		ZD5n0eJivzWOMxY98dgrumkwRG = xdSThjYnuHXAU6M(u"ࠫ࠴࠭ౄ").join(ZD5n0eJivzWOMxY98dgrumkwRG[wTLFCOcM26fmYlW7U:R9RNUT6WAPEYjHqtIokxuXs])
		COW137cpIhBMYTSiAR9s2Dlzw = {kPCxIUZb1V(u"ࠬ࡯ࡤࠨ౅"):d0yrGP8JuBH,Gj3rMP1Cb8wHdp49la0(u"࠭࡯ࡱࠩె"):DpRJnas65uVcO0S17dYG(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪే"),DpRJnas65uVcO0S17dYG(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭ై"):SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ౉")}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡔࡔ࡙ࡔࠨొ"),ZD5n0eJivzWOMxY98dgrumkwRG,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪో"))
		hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers.get(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧౌ")) or QM9sJ7tk0oplqEwHU3DjL64d.headers.get(llkFwuCyhaP3sK76qO4T(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ్")) or wUvcPrYDfISbZolAm83GKEqMyXkn5
		if not hhEH1rcSP0z6Bkqy8OD and QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ౎"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,vWNRusF46D7Mi8GpZ(u"ࠨࡉࡈࡘࠬ౏"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ౐"))
		hhEH1rcSP0z6Bkqy8OD = QM9sJ7tk0oplqEwHU3DjL64d.headers.get(vWNRusF46D7Mi8GpZ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ౑")) or QM9sJ7tk0oplqEwHU3DjL64d.headers.get(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭౒")) or wUvcPrYDfISbZolAm83GKEqMyXkn5
	if hhEH1rcSP0z6Bkqy8OD: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	return gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭౓"),[],[]
def BxfNv3uZhopaWDl(url):
	headers = { Gj3rMP1Cb8wHdp49la0(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ౔") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵౕࠩ"))
	items = jj0dZrgiKb.findall(w8JC1y7Lp3(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨౖࠧ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	if items:
		Eu8LWnSt3fyJzIC.append(llkFwuCyhaP3sK76qO4T(u"ࠩࡰࡴ࠹࠭౗"))
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(items[wTLFCOcM26fmYlW7U][UD4N8MjVTd])
		Eu8LWnSt3fyJzIC.append(xm6jK1ZMuWq5(u"ࠪࡱ࠸ࡻ࠸ࠨౘ"))
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(items[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U])
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
	else: return MFhbWia58mP3su0fk2d(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨౙ"),[],[]
def dKk6LcO0aJgBIUeb3Nmfoi2u4lXZE(url):
	kt4vL7gyrbI = url.split(jQv0du1iVxTgAXCM(u"ࠬ࠵ࠧౚ"))[-UD4N8MjVTd]
	kt4vL7gyrbI = kt4vL7gyrbI.split(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࠦࠨ౛"))[wTLFCOcM26fmYlW7U]
	kt4vL7gyrbI = kt4vL7gyrbI.replace(A6Sg45ChDR3BJLYfFH(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ౜"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	z2n3Nc6IVsQB9rPHJFU = TTuO14NzmB.SITESURLS[VhqD3zp7mUieI8sMQlETH(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩౝ")][wTLFCOcM26fmYlW7U]+rDG9dZoXRhCJcieUSF0KB(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ౞")+kt4vL7gyrbI
	BjJhnCpduR497sfKZ = Gj3rMP1Cb8wHdp49la0(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭౟")+kt4vL7gyrbI
	ddK3lsEzy4,u6bpM7e5qtQmwzISUVTXPyKnHYi2F = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	URduiq14czNJlBOkhZIC = wUvcPrYDfISbZolAm83GKEqMyXkn5
	uSasVYL1qQyev52,UQvXbgEDP3AsikM24l = wUvcPrYDfISbZolAm83GKEqMyXkn5,{}
	cIJuy6l9sVwo5PUQbG3vBApmTCirZL,wwjbdhgWlFA = wUvcPrYDfISbZolAm83GKEqMyXkn5,{}
	headers = {DpRJnas65uVcO0S17dYG(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨౠ"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
	FFLsJWfKjMC317bGHX = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if UD4N8MjVTd:
		iiI5GnLNWEORYa4,jIN7X42EWZsSxe6Ak9cLJGHrt5O,iu3Z9YQe2jDNPhvKgdzTas,GwfXxyAj1RV08sOoab7dCMrHphcPi = [],wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		if wTLFCOcM26fmYlW7U and not iiI5GnLNWEORYa4:
			aGcAQ2qmrZ4J = headers.copy()
			aGcAQ2qmrZ4J.update({erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࡞࠭ࡓࡣࡳ࡭ࡩࡧࡰࡪ࠯ࡋࡳࡸࡺࠧౡ"):rDG9dZoXRhCJcieUSF0KB(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥࡣࡷࡥࡧࡧࡳࡦ࠯ࡤࡲࡩ࠳ࡳࡢࡸࡨࡶ࠳ࡶ࠮ࡳࡣࡳ࡭ࡩࡧࡰࡪ࠰ࡦࡳࡲ࠭ౢ"),MFhbWia58mP3su0fk2d(u"࡙ࠧ࠯ࡕࡥࡵ࡯ࡤࡢࡲ࡬࠱ࡐ࡫ࡹࠨౣ"):gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠶࠷ࡪ࠹࠶࠸ࡥ࠶ࡤ࠶ࡲࡹࡨ࠲ࡤ࠶ࡦࡩ࠺࠹ࡢ࠸࠷࠼࠶࠽ࡦ࠶ࡲ࠴࠴࠶࠶࠳ࡧ࡬ࡶࡲ࠹ࡧ࠴࠲࠹ࡩࡧ࠺࠹࠰࠵࠴ࠪ౤")})
			XXup0CJWslMOqymaKthfb84 = D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡧࡴࡢࡤࡤࡷࡪ࠳ࡡ࡯ࡦ࠰ࡷࡦࡼࡥࡳ࠰ࡳ࠲ࡷࡧࡰࡪࡦࡤࡴ࡮࠴ࡣࡰ࡯࠲࡚࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴ࠮ࡱࡪࡳ࠳ࡄ࡯ࡤ࠾ࠩ౥")+kt4vL7gyrbI
			try:
				OFH84dcLtak31SUEuy = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡋࡊ࡚ࠧ౦"),XXup0CJWslMOqymaKthfb84,wUvcPrYDfISbZolAm83GKEqMyXkn5,aGcAQ2qmrZ4J,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠲ࡵࡨࠬ౧"))
				D4xmaAONbdwvofgi2ZJ30zQUps = OFH84dcLtak31SUEuy.content
				iiI5GnLNWEORYa4 = bbeLsVCqouaSH53E0XmKh4AnFD.loads(D4xmaAONbdwvofgi2ZJ30zQUps)
			except: iiI5GnLNWEORYa4 = []
			UQvXbgEDP3AsikM24l = iiI5GnLNWEORYa4
		if UD4N8MjVTd and not iiI5GnLNWEORYa4:
			XXup0CJWslMOqymaKthfb84 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡵࡦ࡯ࡴ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡹࡴࡳࡧࡤࡱࡄࡩ࡯࡮࡯ࡤࡲࡩࡃ࠭࠮ࡦࡸࡱࡵ࠳ࡪࡴࡱࡱࠤ࠲࠳࡮ࡰ࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ౨")+kt4vL7gyrbI
			try:
				OFH84dcLtak31SUEuy = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,rDG9dZoXRhCJcieUSF0KB(u"࠭ࡇࡆࡖࠪ౩"),XXup0CJWslMOqymaKthfb84,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ౪"))
				D4xmaAONbdwvofgi2ZJ30zQUps = OFH84dcLtak31SUEuy.content
				D4xmaAONbdwvofgi2ZJ30zQUps = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡽࠥࠫ౫")+D4xmaAONbdwvofgi2ZJ30zQUps.split(xdSThjYnuHXAU6M(u"ࠩࡧࡥࡹࡧ࠺ࠡࡽࠥࠫ౬"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠳࿺"))[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠳࿺")].split(xdSThjYnuHXAU6M(u"ࠪࡨࡦࡺࡡ࠻ࠢࡆࡳࡲࡳࠧ౭"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠳࿺"))[jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠳࿻")].strip()
				mVnScOfTx3 = bbeLsVCqouaSH53E0XmKh4AnFD.loads(D4xmaAONbdwvofgi2ZJ30zQUps)
				iiI5GnLNWEORYa4 = mVnScOfTx3.get(rDG9dZoXRhCJcieUSF0KB(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ౮"),[])
				iu3Z9YQe2jDNPhvKgdzTas = mVnScOfTx3.get(lCT8hfYUBX4OQMmL(u"ࠬࡩࡨࡢࡰࡱࡩࡱ࠭౯"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				jIN7X42EWZsSxe6Ak9cLJGHrt5O = mVnScOfTx3.get(yRWQMHxZEz0(u"࠭ࡣࡩࡣࡱࡲࡪࡲ࡟ࡪࡦࠪ౰"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				GwfXxyAj1RV08sOoab7dCMrHphcPi = mVnScOfTx3.get(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪ౱"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			except: iiI5GnLNWEORYa4 = []
		if UD4N8MjVTd and not iiI5GnLNWEORYa4:
			aGcAQ2qmrZ4J = headers.copy()
			aGcAQ2qmrZ4J.update({vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࡚࠰ࡖࡦࡶࡩࡥࡣࡳ࡭࠲ࡎ࡯ࡴࡶࠪ౲"):rDG9dZoXRhCJcieUSF0KB(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡷࡪࡧࡲࡤࡪ࠰ࡥࡳࡪ࠭ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࠲ࡷࡧࡰࡪࡦࡤࡴ࡮࠴ࡣࡰ࡯ࠪ౳"),kPCxIUZb1V(u"ࠪ࡜࠲ࡘࡡࡱ࡫ࡧࡥࡵ࡯࠭ࡌࡧࡼࠫ౴"):kPCxIUZb1V(u"ࠫ࠹࠺ࡦ࠵࠲࠻ࡨ࠹ࡧ࠲࡮ࡵ࡫࠵ࡧ࠹ࡢࡥ࠶࠼ࡥ࠻࠺࠸࠲࠹ࡩ࠹ࡵ࠷࠰࠲࠲࠶ࡪ࡯ࡹ࡮࠵ࡣ࠷࠵࠼࡬ࡣ࠶࠵࠳࠸࠷࠭౵"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ౶"):vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ౷")})
			XXup0CJWslMOqymaKthfb84 = TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡶࡩࡦࡸࡣࡩ࠯ࡤࡲࡩ࠳ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲ࠱ࡶࡦࡶࡩࡥࡣࡳ࡭࠳ࡩ࡯࡮࠱ࡹ࡭ࡩ࡫࡯࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡂ࡭ࡩࡃࠧ౸")+kt4vL7gyrbI
			try:
				OFH84dcLtak31SUEuy = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,DpRJnas65uVcO0S17dYG(u"ࠨࡉࡈࡘࠬ౹"),XXup0CJWslMOqymaKthfb84,wUvcPrYDfISbZolAm83GKEqMyXkn5,aGcAQ2qmrZ4J,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠳ࡳࡦࠪ౺"))
				D4xmaAONbdwvofgi2ZJ30zQUps = OFH84dcLtak31SUEuy.content
				mVnScOfTx3 = bbeLsVCqouaSH53E0XmKh4AnFD.loads(D4xmaAONbdwvofgi2ZJ30zQUps)
				iiI5GnLNWEORYa4 = mVnScOfTx3.get(TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡱࡪࡪࡩࡢࡵࠪ౻"),[])
				GwfXxyAj1RV08sOoab7dCMrHphcPi = mVnScOfTx3.get(fmkZtbRj3ux(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ౼"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			except: iiI5GnLNWEORYa4 = []
		if UD4N8MjVTd and not iiI5GnLNWEORYa4:
			aGcAQ2qmrZ4J = headers.copy()
			aGcAQ2qmrZ4J.update({vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ࡞࠭ࡓࡣࡳ࡭ࡩࡧࡰࡪ࠯ࡋࡳࡸࡺࠧ౽"):rDG9dZoXRhCJcieUSF0KB(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡧࡵ࠱ࡻ࡯ࡤࡦࡱ࠱ࡴ࠳ࡸࡡࡱ࡫ࡧࡥࡵ࡯࠮ࡤࡱࡰࠫ౾"),vWNRusF46D7Mi8GpZ(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭౿"):s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧಀ"),A6Sg45ChDR3BJLYfFH(u"࡛ࠩ࠱ࡗࡧࡰࡪࡦࡤࡴ࡮࠳ࡋࡦࡻࠪಁ"):Gj3rMP1Cb8wHdp49la0(u"ࠪ࠸࠹࡬࠴࠱࠺ࡧ࠸ࡦ࠸࡭ࡴࡪ࠴ࡦ࠸ࡨࡤ࠵࠻ࡤ࠺࠹࠾࠱࠸ࡨ࠸ࡴ࠶࠶࠱࠱࠵ࡩ࡮ࡸࡴ࠴ࡢ࠶࠴࠻࡫ࡩ࠵࠴࠲࠷࠶ࠬಂ")})
			kKDbHhom0pqMlwZNXeRQvIa3jE5F = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡻ࡯ࡤࡦࡱࡢࡹࡷࡲࠧಃ"):z2n3Nc6IVsQB9rPHJFU}
			XXup0CJWslMOqymaKthfb84 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡧࡵ࠱ࡻ࡯ࡤࡦࡱ࠱ࡴ࠳ࡸࡡࡱ࡫ࡧࡥࡵ࡯࠮ࡤࡱࡰ࠳ࡾࡺ࡟ࡴࡶࡵࡩࡦࡳࠧ಄")
			try:
				OFH84dcLtak31SUEuy = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,rDG9dZoXRhCJcieUSF0KB(u"࠭ࡐࡐࡕࡗࠫಅ"),XXup0CJWslMOqymaKthfb84,kKDbHhom0pqMlwZNXeRQvIa3jE5F,aGcAQ2qmrZ4J,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨಆ"))
				D4xmaAONbdwvofgi2ZJ30zQUps = OFH84dcLtak31SUEuy.content
				mVnScOfTx3 = bbeLsVCqouaSH53E0XmKh4AnFD.loads(D4xmaAONbdwvofgi2ZJ30zQUps)
				iiI5GnLNWEORYa4 = mVnScOfTx3.get(jQv0du1iVxTgAXCM(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩಇ"),[])
				iu3Z9YQe2jDNPhvKgdzTas = mVnScOfTx3.get(vWNRusF46D7Mi8GpZ(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪಈ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				jIN7X42EWZsSxe6Ak9cLJGHrt5O = mVnScOfTx3.get(A6Sg45ChDR3BJLYfFH(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪࠧಉ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				GwfXxyAj1RV08sOoab7dCMrHphcPi = mVnScOfTx3.get(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧಊ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			except: iiI5GnLNWEORYa4 = []
		if not iiI5GnLNWEORYa4: return Gj3rMP1Cb8wHdp49la0(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠥ࠳ࠠࡂࡒࡌࡷࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭ಋ"),[],[]
		if not UQvXbgEDP3AsikM24l:
			zmRtvY3LidDQsnrpuNkfg,G4Jt29r3LBPqlQaXoD = [],wUvcPrYDfISbZolAm83GKEqMyXkn5
			for YNa9V4WUOHqgoX in iiI5GnLNWEORYa4:
				dKS8cZehIjPH = YNa9V4WUOHqgoX.copy()
				if it4DKnryZlx(u"࠭ࡩࡵࡣࡪࠫಌ") not in dKS8cZehIjPH: dKS8cZehIjPH[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡪࡶࡤ࡫ࠬ಍")] = dKS8cZehIjPH.get(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡨࡲࡶࡲࡧࡴࡊࡦࠪಎ"),dKS8cZehIjPH.get(JHMxIE4fs1mvQtKW7R(u"ࠩࡩࡳࡷࡳࡡࡵࡡ࡬ࡨࠬಏ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠪ࠴ࠬಐ")))
				if xm6jK1ZMuWq5(u"ࠫࡸࡨࠧ಑") in str(dKS8cZehIjPH[bQGafNLXyFgsZP6ut(u"ࠬ࡯ࡴࡢࡩࠪಒ")]): continue
				if fmkZtbRj3ux(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧಓ") not in dKS8cZehIjPH: dKS8cZehIjPH[weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨಔ")] = dKS8cZehIjPH.get(MFhbWia58mP3su0fk2d(u"ࠨࡶࡥࡶࠬಕ"),wTLFCOcM26fmYlW7U)*SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵࠵࠶࠰࿼")
				if s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩಖ") not in dKS8cZehIjPH: dKS8cZehIjPH[JHMxIE4fs1mvQtKW7R(u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪಗ")] = dKS8cZehIjPH.get(lCT8hfYUBX4OQMmL(u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬಘ"),wTLFCOcM26fmYlW7U)
				if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧಙ") not in dKS8cZehIjPH: dKS8cZehIjPH[jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨಚ")] = dKS8cZehIjPH.get(erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡢࡵࡵࠫಛ"),wTLFCOcM26fmYlW7U)
				if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ࡫ࡱࡨࡪࡾࠧಜ") not in dKS8cZehIjPH: dKS8cZehIjPH[vWNRusF46D7Mi8GpZ(u"ࠩ࡬ࡲࡩ࡫ࡸࠨಝ")] = fmkZtbRj3ux(u"ࠪ࠴࠲࠶ࠧಞ")
				if kPCxIUZb1V(u"ࠫ࡮ࡴࡩࡵࠩಟ") not in dKS8cZehIjPH: dKS8cZehIjPH[xm6jK1ZMuWq5(u"ࠬ࡯࡮ࡥࡧࡻࠫಠ")] = xm6jK1ZMuWq5(u"࠭࠰࠮࠲ࠪಡ")
				if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡴ࡫ࡽࡩࠬಢ") not in dKS8cZehIjPH: dKS8cZehIjPH[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡵ࡬ࡾࡪ࠭ಣ")] = kPCxIUZb1V(u"ࠩ࠳ࡼ࠵࠭ತ")
				if Gj3rMP1Cb8wHdp49la0(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬಥ") not in dKS8cZehIjPH:
					pVxl803PmcaCHZq1 = dKS8cZehIjPH.get(w8JC1y7Lp3(u"ࠫࡻࡩ࡯ࡥࡧࡦࠫದ")) if dKS8cZehIjPH.get(xdSThjYnuHXAU6M(u"ࠬࡼࡣࡰࡦࡨࡧࠬಧ")) not in (lCT8hfYUBX4OQMmL(u"࠭࡮ࡰࡰࡨࠫನ"), None) else wUvcPrYDfISbZolAm83GKEqMyXkn5
					EU51jSor4tkRLQGeTby0cnq = dKS8cZehIjPH.get(llkFwuCyhaP3sK76qO4T(u"ࠧࡢࡥࡲࡨࡪࡩࠧ಩")) if dKS8cZehIjPH.get(MFhbWia58mP3su0fk2d(u"ࠨࡣࡦࡳࡩ࡫ࡣࠨಪ")) not in (lCT8hfYUBX4OQMmL(u"ࠩࡱࡳࡳ࡫ࠧಫ"), None) else wUvcPrYDfISbZolAm83GKEqMyXkn5
					dT7CBnc3EsMp = dKS8cZehIjPH.get(JHMxIE4fs1mvQtKW7R(u"ࠪࡺ࡮ࡪࡥࡰࡡࡨࡼࡹ࠭ಬ")) if dKS8cZehIjPH.get(jQv0du1iVxTgAXCM(u"ࠫࡻ࡯ࡤࡦࡱࡢࡩࡽࡺࠧಭ")) not in (it4DKnryZlx(u"ࠬࡴ࡯࡯ࡧࠪಮ"), None) else wUvcPrYDfISbZolAm83GKEqMyXkn5
					Kq2UYjgoLiu73NOIWnpCBHeX = dKS8cZehIjPH.get(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡡࡶࡦ࡬ࡳࡤ࡫ࡸࡵࠩಯ")) if dKS8cZehIjPH.get(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡢࡷࡧ࡭ࡴࡥࡥࡹࡶࠪರ")) not in (MFhbWia58mP3su0fk2d(u"ࠨࡰࡲࡲࡪ࠭ಱ"), None) else wUvcPrYDfISbZolAm83GKEqMyXkn5
					bvAx9j70sK = rjZFa0VMBuPRHg1cIYJpd52oxl4(dKS8cZehIjPH[MFhbWia58mP3su0fk2d(u"ࠩࡸࡶࡱ࠭ಲ")]).strip(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࠲ࠬಳ")) or dT7CBnc3EsMp or Kq2UYjgoLiu73NOIWnpCBHeX or dKS8cZehIjPH.get(jQv0du1iVxTgAXCM(u"ࠫࡪࡾࡴࠨ಴")) or SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡳࡰ࠵ࠩವ")
					VVFw2jiaU9mrfCpGEPWke = VhqD3zp7mUieI8sMQlETH(u"࠭ࠬࠡࠩಶ") if pVxl803PmcaCHZq1 and EU51jSor4tkRLQGeTby0cnq else wUvcPrYDfISbZolAm83GKEqMyXkn5
					if dKS8cZehIjPH[xm6jK1ZMuWq5(u"ࠧࡷ࡫ࡧࡩࡴࡥࡥࡹࡶࠪಷ")] != jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡰࡲࡲࡪ࠭ಸ"): cyUVLSn018Ezo = weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡹ࡭ࡩ࡫࡯࠰ࠧࡶࠫಹ") % bvAx9j70sK
					elif dKS8cZehIjPH[JHMxIE4fs1mvQtKW7R(u"ࠪࡥࡺࡪࡩࡰࡡࡨࡼࡹ࠭಺")] != jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡳࡵ࡮ࡦࠩ಻"): cyUVLSn018Ezo = jQv0du1iVxTgAXCM(u"ࠬࡧࡵࡥ࡫ࡲ࠳ࠪࡹ಼ࠧ") % bvAx9j70sK
					else: cyUVLSn018Ezo = vWNRusF46D7Mi8GpZ(u"࠭ࡶࡪࡦࡨࡳ࠴ࠫࡳࠨಽ") % bvAx9j70sK
					if not cyUVLSn018Ezo: BGLxKWToPwDtyblqpQkUjAz5idf = lCT8hfYUBX4OQMmL(u"ࠧࡷ࡫ࡧࡩࡴ࠵ࡵ࡯࡭ࡱࡳࡼࡴ࠻ࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࡸࡲࡰࡴ࡯ࡸࡰ࠯ࠤࡺࡴ࡫࡯ࡱࡺࡲࠧ࠭ಾ")
					elif not pVxl803PmcaCHZq1 and not EU51jSor4tkRLQGeTby0cnq: BGLxKWToPwDtyblqpQkUjAz5idf = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࠧࡶ࠿ࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠥࡴࠤࠪಿ")%(cyUVLSn018Ezo, weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰ࠯ࠤࡺࡴ࡫࡯ࡱࡺࡲࠬೀ") if VVFw2jiaU9mrfCpGEPWke else A6Sg45ChDR3BJLYfFH(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫು"))
					else: BGLxKWToPwDtyblqpQkUjAz5idf = llkFwuCyhaP3sK76qO4T(u"ࠫࠪࡹ࠻ࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠨࡷࠪࡹࠥࡴࠤࠪೂ") % (cyUVLSn018Ezo, pVxl803PmcaCHZq1, VVFw2jiaU9mrfCpGEPWke, EU51jSor4tkRLQGeTby0cnq)
					dKS8cZehIjPH[w8JC1y7Lp3(u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧೃ")] = BGLxKWToPwDtyblqpQkUjAz5idf
				if xm6jK1ZMuWq5(u"࠭࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡷࡵࡰࠬೄ") in dKS8cZehIjPH: G4Jt29r3LBPqlQaXoD = dKS8cZehIjPH[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧ࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡸࡶࡱ࠭೅")]
				zmRtvY3LidDQsnrpuNkfg.append(dKS8cZehIjPH)
			UQvXbgEDP3AsikM24l = {}
			UQvXbgEDP3AsikM24l[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨೆ")] = {xm6jK1ZMuWq5(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪೇ"):zmRtvY3LidDQsnrpuNkfg}
			UQvXbgEDP3AsikM24l[Gj3rMP1Cb8wHdp49la0(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩೈ")] = {fmkZtbRj3ux(u"ࠫࡦࡻࡴࡩࡱࡵࠫ೉"):iu3Z9YQe2jDNPhvKgdzTas,TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨೊ"):jIN7X42EWZsSxe6Ak9cLJGHrt5O}
			UQvXbgEDP3AsikM24l[jQv0du1iVxTgAXCM(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬೋ")] = {A6Sg45ChDR3BJLYfFH(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧೌ"):iu3Z9YQe2jDNPhvKgdzTas,llkFwuCyhaP3sK76qO4T(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧ್ࠫ"):jIN7X42EWZsSxe6Ak9cLJGHrt5O,s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ೎"):{lCT8hfYUBX4OQMmL(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ೏"):[{s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡺࡸ࡬ࠨ೐"):GwfXxyAj1RV08sOoab7dCMrHphcPi}]}}
			if G4Jt29r3LBPqlQaXoD:
				if rjZFa0VMBuPRHg1cIYJpd52oxl4(G4Jt29r3LBPqlQaXoD)==MFhbWia58mP3su0fk2d(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ೑"):
					UQvXbgEDP3AsikM24l[ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭೒")][TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ೓")] = G4Jt29r3LBPqlQaXoD
				else:
					UQvXbgEDP3AsikM24l[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ೔")][it4DKnryZlx(u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫೕ")] = G4Jt29r3LBPqlQaXoD
		if wTLFCOcM26fmYlW7U:
			BU3E9VYp7Dvxj0HcZiF2ls = erqDsJmL3BQHuGtPkcf0X9(u"࠶࿽")
			for qbRmVByrJv18 in range(BU3E9VYp7Dvxj0HcZiF2ls):
				QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,A6Sg45ChDR3BJLYfFH(u"ࠪࡋࡊ࡚ࠧೖ"),z2n3Nc6IVsQB9rPHJFU,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠶ࡷ࡬ࠬ೗"))
				II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
			hnJgaVLlc6 = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ೘"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			uSasVYL1qQyev52 = hnJgaVLlc6[wTLFCOcM26fmYlW7U] if hnJgaVLlc6 else II64TLxj3mbqEyh9pHQ8oAv
			UQvXbgEDP3AsikM24l = dm7KA8MukvxF3iH9CW2ZNc(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡤࡪࡥࡷࠫ೙"),uSasVYL1qQyev52)
	else:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,JHMxIE4fs1mvQtKW7R(u"ࠧࡈࡇࡗࠫ೚"),z2n3Nc6IVsQB9rPHJFU,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠻ࡴࡩࠩ೛"))
		URduiq14czNJlBOkhZIC = QM9sJ7tk0oplqEwHU3DjL64d.content
		xjqWKzA4DY25ZSQmEo83ngeI7U0yv = wUvcPrYDfISbZolAm83GKEqMyXkn5
		lFRhxaCiAv = jj0dZrgiKb.findall(erqDsJmL3BQHuGtPkcf0X9(u"ࠩࠥࠬ࠴ࡹ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡝ࡹ࠭ࡃ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࡯ࡡࡴ࠰ࡹࡪࡱࡹࡥࡵ࠱ࡨࡲࡤ࠴࠮࠰ࡤࡤࡷࡪ࠴ࡪࡴࠫࠥࠫ೜"),URduiq14czNJlBOkhZIC,jj0dZrgiKb.DOTALL)
		if lFRhxaCiAv:
			lFRhxaCiAv = TTuO14NzmB.SITESURLS[A6Sg45ChDR3BJLYfFH(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫೝ")][wTLFCOcM26fmYlW7U]+lFRhxaCiAv[wTLFCOcM26fmYlW7U]
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,rDG9dZoXRhCJcieUSF0KB(u"ࠫࡌࡋࡔࠨೞ"),lFRhxaCiAv,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠹ࡸ࡭࠭೟"))
			FFLsJWfKjMC317bGHX = QM9sJ7tk0oplqEwHU3DjL64d.content
			pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe = jj0dZrgiKb.search(xm6jK1ZMuWq5(u"ࡸࠧࠩࡁ࠽ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࡽࡵࡷࡷ࠮ࡢࡳࠫ࠼࡟ࡷ࠯࠮࠿ࡑ࠾ࡶࡸࡸࡄ࡛࠱࠯࠼ࡡࢀ࠻ࡽࠪࠩೠ"), FFLsJWfKjMC317bGHX)
			xjqWKzA4DY25ZSQmEo83ngeI7U0yv = pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe.group(lCT8hfYUBX4OQMmL(u"ࠧࡴࡶࡶࠫೡ"))
			xjqWKzA4DY25ZSQmEo83ngeI7U0yv = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨ࠴࠳࠷࠹࠾ࠧೢ")
			lFRhxaCiAv = yRWQMHxZEz0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡹ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࠱࠲࠳࠸ࡩ࡫࠴࠳࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡࡘࡗ࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠭ೣ")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡋࡊ࡚ࠧ೤"),lFRhxaCiAv,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠹ࡷ࡬ࠬ೥"))
			FFLsJWfKjMC317bGHX = QM9sJ7tk0oplqEwHU3DjL64d.content
		qaLFXuDExl8w = TTuO14NzmB.SITESURLS[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭೦")][wTLFCOcM26fmYlW7U]+DpRJnas65uVcO0S17dYG(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡶ࡬ࡢࡻࡨࡶࡄࡶࡲࡦࡶࡷࡽࡕࡸࡩ࡯ࡶࡀࡪࡦࡲࡳࡦࠩ೧")
		Y3YnrBSfAko8bjCtdK40MUsuRGlLFP = OOnvcPQy85HYA.getSetting(xdSThjYnuHXAU6M(u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ೨"))
		if Y3YnrBSfAko8bjCtdK40MUsuRGlLFP.count(it4DKnryZlx(u"ࠨ࠼࠽࠾ࠬ೩"))==A6Sg45ChDR3BJLYfFH(u"࠺࿾"):
			ooQ8KIyXSPtEra,key,ggVKTQ2sm4JiuCle07xHprZtUhn,BBZOMVgFC0ioTsJEnI6ykNmd8Hw,wkKMJqu0VaeWm = Y3YnrBSfAko8bjCtdK40MUsuRGlLFP.split(xm6jK1ZMuWq5(u"ࠩ࠽࠾࠿࠭೪"))
			headers[D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࡜࠲ࡍ࡯ࡰࡩ࠰࡚࡮ࡹࡩࡵࡱࡵ࠱ࡎࡪࠧ೫")] = ooQ8KIyXSPtEra
		headers[xdSThjYnuHXAU6M(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ೬")] = vWNRusF46D7Mi8GpZ(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ೭")
		if UD4N8MjVTd:
			F148a7xNcp9C = kPCxIUZb1V(u"࠭ࡻࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡘ࡛ࡎࡔࡎࡎ࠸ࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠻࠳࠸࠰࠳࠷࠳࠽࠵࠸࠮࠱࠺࠱࠴࠵ࠨࡽࡾ࠮ࠣࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩ೮")+kt4vL7gyrbI+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࠣ࠮ࠣࠦࡵࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡴࡴࡴࡦࡰࡷࡔࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࠢ࠻ࠢࠪ೯")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+Gj3rMP1Cb8wHdp49la0(u"ࠨࡿࢀࢁࠬ೰")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡓࡓࡘ࡚ࠧೱ"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠹ࡶ࡫ࠫೲ"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫೳ") in hnJgaVLlc6:
				uSasVYL1qQyev52 = hnJgaVLlc6.replace(MFhbWia58mP3su0fk2d(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭೴"),xdSThjYnuHXAU6M(u"࠭ࠦࠨ೵"))
				UQvXbgEDP3AsikM24l = dm7KA8MukvxF3iH9CW2ZNc(weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡥ࡫ࡦࡸࠬ೶"),uSasVYL1qQyev52)
		if wTLFCOcM26fmYlW7U:
			F148a7xNcp9C = D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡽࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤ࡚ࠧࡖࡉࡖࡐࡐ࠺ࡥࡓࡊࡏࡓࡐ࡞ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠮࠱ࠤࢀࢁ࠱ࠦࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬ೷")+kt4vL7gyrbI+Gj3rMP1Cb8wHdp49la0(u"ࠩࠥ࠰ࠥࠨࡰ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡯࡯ࡶࡨࡲࡹࡖ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠤ࠽ࠤࠬ೸")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+xdSThjYnuHXAU6M(u"ࠪࢁࢂࢃࠧ೹")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,it4DKnryZlx(u"ࠫࡕࡕࡓࡕࠩ೺"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠼ࡸ࡭࠭೻"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if rDG9dZoXRhCJcieUSF0KB(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭೼") in hnJgaVLlc6:
				uSasVYL1qQyev52 = hnJgaVLlc6.replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ೽"),it4DKnryZlx(u"ࠨࠨࠪ೾"))
				UQvXbgEDP3AsikM24l = dm7KA8MukvxF3iH9CW2ZNc(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡧ࡭ࡨࡺࠧ೿"),uSasVYL1qQyev52)
		if wTLFCOcM26fmYlW7U:
			F148a7xNcp9C = TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡿࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠦࠢࡊࡑࡖࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠶࠵࠴࠱࠱࠰࠷ࠦࢂࢃࠬࠡࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧഀ")+kt4vL7gyrbI+xm6jK1ZMuWq5(u"ࠫࠧ࠲ࠠࠣࡲ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤࡱࡱࡸࡪࡴࡴࡑ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡳࡪࡩࡱࡥࡹࡻࡲࡦࡖ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠦ࠿ࠦࠧഁ")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࢃࡽࡾࠩം")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡐࡐࡕࡗࠫഃ"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶࠶ࡴࡩࠩഄ"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨഅ") in hnJgaVLlc6:
				cIJuy6l9sVwo5PUQbG3vBApmTCirZL = hnJgaVLlc6.replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪആ"),jQv0du1iVxTgAXCM(u"ࠪࠪࠬഇ"))
				wwjbdhgWlFA = dm7KA8MukvxF3iH9CW2ZNc(jQv0du1iVxTgAXCM(u"ࠫࡩ࡯ࡣࡵࠩഈ"),cIJuy6l9sVwo5PUQbG3vBApmTCirZL)
		if wTLFCOcM26fmYlW7U and w8JC1y7Lp3(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬഉ") not in uSasVYL1qQyev52:
			uSasVYL1qQyev52,UQvXbgEDP3AsikM24l,UQvXbgEDP3AsikM24l = wUvcPrYDfISbZolAm83GKEqMyXkn5,{},{}
			F148a7xNcp9C = yRWQMHxZEz0(u"࠭ࡻࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡑ࡜ࡋࡂࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠳࠰࠵࠴࠷࠻࠰࠴࠳࠴࠲࠵࠹࠮࠱࠲ࠥࢁࢂ࠲ࠠࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ഊ")+kt4vL7gyrbI+llkFwuCyhaP3sK76qO4T(u"ࠧࠣ࠮ࠣࠦࡵࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡴࡴࡴࡦࡰࡷࡔࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࠢ࠻ࠢࠪഋ")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+MFhbWia58mP3su0fk2d(u"ࠨࡿࢀࢁࠬഌ")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,Gj3rMP1Cb8wHdp49la0(u"ࠩࡓࡓࡘ࡚ࠧ഍"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲࠳ࡷ࡬ࠬഎ"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if VhqD3zp7mUieI8sMQlETH(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫഏ") in hnJgaVLlc6:
				uSasVYL1qQyev52 = hnJgaVLlc6.replace(VhqD3zp7mUieI8sMQlETH(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ഐ"),llkFwuCyhaP3sK76qO4T(u"࠭ࠦࠨ഑"))
				UQvXbgEDP3AsikM24l = dm7KA8MukvxF3iH9CW2ZNc(JHMxIE4fs1mvQtKW7R(u"ࠧࡥ࡫ࡦࡸࠬഒ"),uSasVYL1qQyev52)
		if wTLFCOcM26fmYlW7U and llkFwuCyhaP3sK76qO4T(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨഓ") not in uSasVYL1qQyev52:
			uSasVYL1qQyev52,UQvXbgEDP3AsikM24l,UQvXbgEDP3AsikM24l = wUvcPrYDfISbZolAm83GKEqMyXkn5,{},{}
			F148a7xNcp9C = kPCxIUZb1V(u"ࠩࡾࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠥࠨࡗࡆࡄࠥ࠰ࠥࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠲࠷࠶࠲࠶࠲࠼࠴࠸࠴࠰࠵࠰࠳࠴ࠧࢃࡽ࠭ࠢࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨഔ")+kt4vL7gyrbI+VhqD3zp7mUieI8sMQlETH(u"ࠪࠦ࠱ࠦࠢࡱ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣࡰࡰࡷࡩࡳࡺࡐ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡹࡩࡨࡰࡤࡸࡺࡸࡥࡕ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠥ࠾ࠥ࠭ക")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࢂࢃࡽࠨഖ")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,bQGafNLXyFgsZP6ut(u"ࠬࡖࡏࡔࡖࠪഗ"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵࠷ࡺࡨࠨഘ"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧങ") in hnJgaVLlc6:
				uSasVYL1qQyev52 = hnJgaVLlc6.replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩച"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࠩࠫഛ"))
				UQvXbgEDP3AsikM24l = dm7KA8MukvxF3iH9CW2ZNc(Gj3rMP1Cb8wHdp49la0(u"ࠪࡨ࡮ࡩࡴࠨജ"),uSasVYL1qQyev52)
		if UD4N8MjVTd and TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫഝ") not in cIJuy6l9sVwo5PUQbG3vBApmTCirZL:
			cIJuy6l9sVwo5PUQbG3vBApmTCirZL,wwjbdhgWlFA,wwjbdhgWlFA = wUvcPrYDfISbZolAm83GKEqMyXkn5,{},{}
			F148a7xNcp9C = w8JC1y7Lp3(u"ࠬࢁࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡄࡒࡉࡘࡏࡊࡆࠥ࠰ࠥࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠴࠳࠷࠰࠯࠵࠻ࠦࢂࢃࠬࠡࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧഞ")+kt4vL7gyrbI+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࠢ࠭ࠢࠥࡴࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡳࡳࡺࡥ࡯ࡶࡓࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡘ࡮ࡳࡥࡴࡶࡤࡱࡵࠨ࠺ࠡࠩട")+xjqWKzA4DY25ZSQmEo83ngeI7U0yv+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡾࡿࢀࠫഠ")
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,fmkZtbRj3ux(u"ࠨࡒࡒࡗ࡙࠭ഡ"),qaLFXuDExl8w,F148a7xNcp9C,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱࠴ࡶ࡫ࠫഢ"))
			hnJgaVLlc6 = QM9sJ7tk0oplqEwHU3DjL64d.content
			if rDG9dZoXRhCJcieUSF0KB(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪണ") in hnJgaVLlc6:
				cIJuy6l9sVwo5PUQbG3vBApmTCirZL = hnJgaVLlc6.replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬത"),DpRJnas65uVcO0S17dYG(u"ࠬࠬࠧഥ"))
				wwjbdhgWlFA = dm7KA8MukvxF3iH9CW2ZNc(Gj3rMP1Cb8wHdp49la0(u"࠭ࡤࡪࡥࡷࠫദ"),cIJuy6l9sVwo5PUQbG3vBApmTCirZL)
	BnCsQd23hOHe7Yu5F8LRjXz,BQ3uzlaCMfPSX4KIWhJwbvV2qxYgco,BYn8quHW76oMiy,VIvx2RpmLu6J = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	eokcwgCA8FP3E,STKbPU3WlgZAR0GEI,qA0Sl2LGWoVy6ItfZewHTC8Q51hdE,vnSdtEB607mhOwK = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	try: BQ3uzlaCMfPSX4KIWhJwbvV2qxYgco = UQvXbgEDP3AsikM24l[A6Sg45ChDR3BJLYfFH(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧധ")][w8JC1y7Lp3(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩന")]
	except: pass
	try: STKbPU3WlgZAR0GEI = wwjbdhgWlFA[jQv0du1iVxTgAXCM(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩഩ")][vvhR5ozeiJpANyl8fFO3GBw(u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫപ")]
	except: pass
	try: BnCsQd23hOHe7Yu5F8LRjXz = UQvXbgEDP3AsikM24l[yRWQMHxZEz0(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫഫ")][s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧബ")]
	except: pass
	try: eokcwgCA8FP3E = wwjbdhgWlFA[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ഭ")][VhqD3zp7mUieI8sMQlETH(u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩമ")]
	except: pass
	try: BYn8quHW76oMiy = UQvXbgEDP3AsikM24l[erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨയ")][ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪര")]
	except: pass
	try: qA0Sl2LGWoVy6ItfZewHTC8Q51hdE = wwjbdhgWlFA[s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪറ")][weh7SGmuTgXOVRcMo1rlLq(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬല")]
	except: pass
	try: VIvx2RpmLu6J = UQvXbgEDP3AsikM24l[A6Sg45ChDR3BJLYfFH(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬള")][erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨഴ")]
	except: pass
	try: vnSdtEB607mhOwK = wwjbdhgWlFA[MFhbWia58mP3su0fk2d(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧവ")][vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪശ")]
	except: pass
	if not any([BQ3uzlaCMfPSX4KIWhJwbvV2qxYgco,STKbPU3WlgZAR0GEI,BnCsQd23hOHe7Yu5F8LRjXz,eokcwgCA8FP3E,BYn8quHW76oMiy,qA0Sl2LGWoVy6ItfZewHTC8Q51hdE,VIvx2RpmLu6J,vnSdtEB607mhOwK]):
		Kj04L1bcTNuOoUz3Yg = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬഷ"),URduiq14czNJlBOkhZIC,jj0dZrgiKb.DOTALL)
		OOZ9V4c5uT8gEl = jj0dZrgiKb.findall(yRWQMHxZEz0(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫസ"),URduiq14czNJlBOkhZIC,jj0dZrgiKb.DOTALL)
		mFtyk0Ph4GNuZ5pK = jj0dZrgiKb.findall(fmkZtbRj3ux(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪഹ"),URduiq14czNJlBOkhZIC,jj0dZrgiKb.DOTALL)
		xXQniIulZWFvDCEGR72aLTMH81 = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧഺ"),URduiq14czNJlBOkhZIC,jj0dZrgiKb.DOTALL)
		k2NT0tsmKLGc71HM85,v0bHm3PjcnZBNslK8Up9Odf,RaQzup3VwkimrhoMSD6xLKEW0 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		try: k2NT0tsmKLGc71HM85 = UQvXbgEDP3AsikM24l[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵ഻ࠪ")][fmkZtbRj3ux(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲ഼ࠬ")][bQGafNLXyFgsZP6ut(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩഽ")][SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡷ࡭ࡹࡲࡥࠨാ")][Gj3rMP1Cb8wHdp49la0(u"ࠪࡶࡺࡴࡳࠨി")][wTLFCOcM26fmYlW7U][gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡹ࡫ࡸࡵࠩീ")]
		except:
			try: k2NT0tsmKLGc71HM85 = wwjbdhgWlFA[lCT8hfYUBX4OQMmL(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩു")][ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫൂ")][rDG9dZoXRhCJcieUSF0KB(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨൃ")][it4DKnryZlx(u"ࠨࡶ࡬ࡸࡱ࡫ࠧൄ")][JHMxIE4fs1mvQtKW7R(u"ࠩࡵࡹࡳࡹࠧ൅")][wTLFCOcM26fmYlW7U][w8JC1y7Lp3(u"ࠪࡸࡪࡾࡴࠨെ")]
			except: pass
		try: v0bHm3PjcnZBNslK8Up9Odf = UQvXbgEDP3AsikM24l[TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨേ")][xm6jK1ZMuWq5(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪൈ")][yRWQMHxZEz0(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ൉")][yRWQMHxZEz0(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨൊ")][wTLFCOcM26fmYlW7U][MFhbWia58mP3su0fk2d(u"ࠨࡴࡸࡲࡸ࠭ോ")][wTLFCOcM26fmYlW7U][D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡷࡩࡽࡺࠧൌ")]
		except:
			try: v0bHm3PjcnZBNslK8Up9Odf = wwjbdhgWlFA[lCT8hfYUBX4OQMmL(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹ്ࠧ")][ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩൎ")][erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭൏")][llkFwuCyhaP3sK76qO4T(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ൐")][wTLFCOcM26fmYlW7U][s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡳࡷࡱࡷࠬ൑")][wTLFCOcM26fmYlW7U][s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡶࡨࡼࡹ࠭൒")]
			except: pass
		try: RaQzup3VwkimrhoMSD6xLKEW0 = UQvXbgEDP3AsikM24l[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭൓")][jQv0du1iVxTgAXCM(u"ࠪࡶࡪࡧࡳࡰࡰࠪൔ")]
		except:
			try: RaQzup3VwkimrhoMSD6xLKEW0 = wwjbdhgWlFA[TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨൕ")][xm6jK1ZMuWq5(u"ࠬࡸࡥࡢࡵࡲࡲࠬൖ")]
			except: pass
		G8G9qHjigC = wUvcPrYDfISbZolAm83GKEqMyXkn5
		nnq0wuVCgdWKSlRZpbAGQxJeDohIr9 = JegF7SlMawI03+xdSThjYnuHXAU6M(u"࠭็ัษࠣห้็๊ะ์๋ࠤๆ๐็ࠡ็ื็้ฯࠠ࠯࠰ࠣวํฺ๋ࠦำ้้ࠣอฦๆࠢ็ฬ฾฼ࠠศๆ่ืฯิฯๆ์้ࠤ࠳࠴ࠠฤ๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠤ࠳࠴ࠠฤ๊ࠣ๎ํะ๊้สࠣ๎าะวอࠢื๎ฦࠦๅฮัาࠤ࠳࠴ࠠฤ๊ࠣ๎ํะ๊้สࠣ฾๏ืࠠใษาีࠥษๆࠡ์ื฾้ࠦวๅใํำ๏๎ࠠศๆล๊ࠬൗ")+AAByQSLgaZwCsKnvc5eWNmY
		if Kj04L1bcTNuOoUz3Yg or OOZ9V4c5uT8gEl or mFtyk0Ph4GNuZ5pK or xXQniIulZWFvDCEGR72aLTMH81 or k2NT0tsmKLGc71HM85 or v0bHm3PjcnZBNslK8Up9Odf or RaQzup3VwkimrhoMSD6xLKEW0:
			if   Kj04L1bcTNuOoUz3Yg: SLAiUwpDRoZIQfvB7 = Kj04L1bcTNuOoUz3Yg[wTLFCOcM26fmYlW7U]
			elif OOZ9V4c5uT8gEl: SLAiUwpDRoZIQfvB7 = OOZ9V4c5uT8gEl[wTLFCOcM26fmYlW7U]
			elif mFtyk0Ph4GNuZ5pK: SLAiUwpDRoZIQfvB7 = mFtyk0Ph4GNuZ5pK[wTLFCOcM26fmYlW7U]
			elif xXQniIulZWFvDCEGR72aLTMH81: SLAiUwpDRoZIQfvB7 = xXQniIulZWFvDCEGR72aLTMH81[wTLFCOcM26fmYlW7U]
			elif k2NT0tsmKLGc71HM85: SLAiUwpDRoZIQfvB7 = k2NT0tsmKLGc71HM85
			elif v0bHm3PjcnZBNslK8Up9Odf: SLAiUwpDRoZIQfvB7 = v0bHm3PjcnZBNslK8Up9Odf
			elif RaQzup3VwkimrhoMSD6xLKEW0: SLAiUwpDRoZIQfvB7 = RaQzup3VwkimrhoMSD6xLKEW0
			G8G9qHjigC = SLAiUwpDRoZIQfvB7.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			nnq0wuVCgdWKSlRZpbAGQxJeDohIr9 += VhqD3zp7mUieI8sMQlETH(u"ࠧ࡝ࡰ࡟ࡲࠬ൘")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+lCT8hfYUBX4OQMmL(u"ࠨำึห้ฯࠠๆ่ࠣ๎ํะ๊้สࠪ൙")+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev+G8G9qHjigC
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭൚"),nnq0wuVCgdWKSlRZpbAGQxJeDohIr9)
		if G8G9qHjigC: G8G9qHjigC = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪ࠾ࠥ࠭൛")+G8G9qHjigC
		return jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ൜")+G8G9qHjigC,[],[]
	B5T3SAbWa78fQCOKpDnL,dvQ5gG3InTMVF0XeOjiE2bsaJyw7fA,jA9FtDVWyB2vifOoanJRlH5KLTZrEm = [],[],[]
	js1RAl3aBPfiSN2F = [BQ3uzlaCMfPSX4KIWhJwbvV2qxYgco,STKbPU3WlgZAR0GEI]
	KF3OuMi41ZY2E6tNQnCUV0evspLH = [BnCsQd23hOHe7Yu5F8LRjXz,eokcwgCA8FP3E]
	lCtvKHMzLJVo8fERq9N5,mVTySfzrMla = [],[]
	zmRtvY3LidDQsnrpuNkfg = BYn8quHW76oMiy+qA0Sl2LGWoVy6ItfZewHTC8Q51hdE
	for YNa9V4WUOHqgoX in zmRtvY3LidDQsnrpuNkfg:
		if YNa9V4WUOHqgoX[TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࡯ࡴࡢࡩࠪ൝")] not in lCtvKHMzLJVo8fERq9N5:
			lCtvKHMzLJVo8fERq9N5.append(YNa9V4WUOHqgoX[jQv0du1iVxTgAXCM(u"࠭ࡩࡵࡣࡪࠫ൞")])
			mVTySfzrMla.append(YNa9V4WUOHqgoX)
	lCtvKHMzLJVo8fERq9N5,I3I0HeVNc1Qivq4PJpl = [],[]
	for YNa9V4WUOHqgoX in VIvx2RpmLu6J+vnSdtEB607mhOwK:
		if YNa9V4WUOHqgoX[TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡪࡶࡤ࡫ࠬൟ")] not in lCtvKHMzLJVo8fERq9N5:
			lCtvKHMzLJVo8fERq9N5.append(YNa9V4WUOHqgoX[lCT8hfYUBX4OQMmL(u"ࠨ࡫ࡷࡥ࡬࠭ൠ")])
			I3I0HeVNc1Qivq4PJpl.append(YNa9V4WUOHqgoX)
	for dict in mVTySfzrMla+I3I0HeVNc1Qivq4PJpl:
		if yRWQMHxZEz0(u"ࠩࡸࡶࡱ࠭ൡ") not in dict: continue
		if rDG9dZoXRhCJcieUSF0KB(u"ࠪ࡭ࡹࡧࡧࠨൢ") in dict: dict[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡮ࡺࡡࡨࠩൣ")] = str(dict[xdSThjYnuHXAU6M(u"ࠬ࡯ࡴࡢࡩࠪ൤")])
		if pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡦࡱࡵࠪ൥") in dict: dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡧࡲࡶࠫ൦")] = str(dict[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡨࡳࡷࠬ൧")])
		if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ൨") in dict: dict[w8JC1y7Lp3(u"ࠪࡸࡾࡶࡥࠨ൩")] = dict[kPCxIUZb1V(u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭൪")]
		if TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ൫") in dict: dict[Gj3rMP1Cb8wHdp49la0(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ൬")] = str(dict[DpRJnas65uVcO0S17dYG(u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ൭")])
		if weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ൮") in dict: dict[xdSThjYnuHXAU6M(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ൯")] = str(dict[fmkZtbRj3ux(u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ൰")])
		if Gj3rMP1Cb8wHdp49la0(u"ࠫࡼ࡯ࡤࡵࡪࠪ൱") in dict: dict[jQv0du1iVxTgAXCM(u"ࠬࡹࡩࡻࡧࠪ൲")] = str(dict[kPCxIUZb1V(u"࠭ࡷࡪࡦࡷ࡬ࠬ൳")])+xdSThjYnuHXAU6M(u"ࠧࡹࠩ൴")+str(dict[kPCxIUZb1V(u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ൵")])
		if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ൶") in dict: dict[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪ࡭ࡳ࡯ࡴࠨ൷")] = dict[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ൸")][vWNRusF46D7Mi8GpZ(u"ࠬࡹࡴࡢࡴࡷࠫ൹")]+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠭ࠨൺ")+dict[weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪൻ")][yRWQMHxZEz0(u"ࠨࡧࡱࡨࠬർ")]
		if lCT8hfYUBX4OQMmL(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭ൽ") in dict: dict[yRWQMHxZEz0(u"ࠪ࡭ࡳࡪࡥࡹࠩൾ")] = dict[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨൿ")][w8JC1y7Lp3(u"ࠬࡹࡴࡢࡴࡷࠫ඀")]+jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭࠭ࠨඁ")+dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫං")][Gj3rMP1Cb8wHdp49la0(u"ࠨࡧࡱࡨࠬඃ")]
		if jQv0du1iVxTgAXCM(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ඄") in dict: dict[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫඅ")] = dict[jQv0du1iVxTgAXCM(u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬආ")]
		if yRWQMHxZEz0(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ඇ") in dict and int(dict[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧඈ")])>vvhR5ozeiJpANyl8fFO3GBw(u"࠱࠲࠳࠵࠶࠷࠹࠳࠴࿿"): del dict[it4DKnryZlx(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨඉ")]
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪඊ") in dict:
			cokgDJwzijLO1hCdumMaRWnAZEl = dict[TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫඋ")].split(xdSThjYnuHXAU6M(u"ࠪࠪࠬඌ"))
			for o4oW9wDcsrpHQS816yfIvg in cokgDJwzijLO1hCdumMaRWnAZEl:
				key,value = o4oW9wDcsrpHQS816yfIvg.split(kPCxIUZb1V(u"ࠫࡂ࠭ඍ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠲က"))
				dict[key] = Z6bUG0kDQuFqgzdAa1r(value)
		if s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡩ࡯ࡥࡧࡦࡷࡂ࠭ඎ") in dict[vWNRusF46D7Mi8GpZ(u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨඏ")]: dict[llkFwuCyhaP3sK76qO4T(u"ࠧࡤࡱࡧࡩࡨࡹࠧඐ")] = dict[bQGafNLXyFgsZP6ut(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪඑ")].split(w8JC1y7Lp3(u"ࠩࡦࡳࡩ࡫ࡣࡴ࠿ࠪඒ"))[UD4N8MjVTd].replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡠࠧ࠭ඓ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(bQGafNLXyFgsZP6ut(u"ࠫࠧ࠭ඔ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		B5T3SAbWa78fQCOKpDnL.append(dict)
	if FFLsJWfKjMC317bGHX:
		if s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬඕ") in uSasVYL1qQyev52+cIJuy6l9sVwo5PUQbG3vBApmTCirZL:
			try:
				import youtube_signature.cipher as JIqE81aLrsbZQSRFp5,youtube_signature.json_script_engine as oHX8BiYlzNDGM4IdpZmSn2L5UEf1Vw
				cokgDJwzijLO1hCdumMaRWnAZEl = CLPbQlrGu7ETh346f1q9IVAKNF.cokgDJwzijLO1hCdumMaRWnAZEl.Cipher()
				cokgDJwzijLO1hCdumMaRWnAZEl._object_cache = {}
				QkjwTv0tUH96rCga8MJuldsP5 = cokgDJwzijLO1hCdumMaRWnAZEl._load_javascript(FFLsJWfKjMC317bGHX)
				E43WZwNxLGH09 = dm7KA8MukvxF3iH9CW2ZNc(yRWQMHxZEz0(u"࠭ࡳࡵࡴࠪඖ"),str(QkjwTv0tUH96rCga8MJuldsP5))
				koQv3BtLhIfCaRTN = CLPbQlrGu7ETh346f1q9IVAKNF.zmkTvnPF23D9ef0LUNH5ujBZidx.JsonScriptEngine(E43WZwNxLGH09)
			except: pass
		if wTLFCOcM26fmYlW7U:
			ERgQJnkFe5K8ualtAy74d = wUvcPrYDfISbZolAm83GKEqMyXkn5
			qiLFPv6mIVbBHOA8MhrxNDRf7Jng = jj0dZrgiKb.findall(
				vvhR5ozeiJpANyl8fFO3GBw(u"ࡲࠨࠩࠪࠬࡄࡾࠩࠋࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉ࡝࠰ࡪࡩࡹࡢࠨࠣࡰࠥࡠ࠮ࡢࠩࠧࠨ࡟ࠬࡧࡃࡼࠋࠋࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊࠋࡥࡁࡘࡺࡲࡪࡰࡪࡠ࠳࡬ࡲࡰ࡯ࡆ࡬ࡦࡸࡃࡰࡦࡨࡠ࠭࠷࠱࠱࡞ࠬࢀࠏࠏࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡵࡷࡶࡤ࡯ࡤࡹࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࠯࡟࠮࠭ࠫࠬ࡜ࠩࡤࡀࠦࡳࡴࠢ࡝࡝࡟࠯࠭ࡅࡐ࠾ࡵࡷࡶࡤ࡯ࡤࡹࠫ࡟ࡡࠏࠏࠉࠊࠋࠌ࠭ࠏࠏࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࠏࠬ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝ࠪࡤࡠ࠮࠯࠿࠭ࡥࡀࡥࡡ࠴ࠊࠊࠋࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊࠋࠌ࡫ࡪࡺ࡜ࠩࡤ࡟࠭ࢁࠐࠉࠊࠋࠌࠍࠎࠏ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱࡜࡜ࡤ࡟ࡡࡡࢂ࡜ࡽࡰࡸࡰࡱࠐࠉࠊࠋࠌࠍࠎ࠯࡜ࠪࠨࠩࡠ࠭ࡩ࠽ࡽࠌࠌࠍࠎࠏࠉ࡝ࡤࠫࡃࡕࡂࡶࡢࡴࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡂࠐࠉࠊࠋࠌ࠭࠭ࡅࡐ࠽ࡰࡩࡹࡳࡩ࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪࠪࡂ࠾ࡡࡡࠨࡀࡒ࠿࡭ࡩࡾ࠾࡝ࡦ࠮࠭ࡡࡣࠩࡀ࡞ࠫ࡟ࡦ࠳ࡺࡂ࠯࡝ࡡࡡ࠯ࠊࠊࠋࠌࠍ࠭ࡅࠨࡷࡣࡵ࠭࠱ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢ࠮ࡴࡧࡷࡠ࠭࠮࠿࠻ࠤࡱ࠯ࠧࢂ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩ࡝࠮ࠫࡃࡕࡃࡶࡢࡴࠬࡠ࠮࠯ࠧࠨࠩ඗"),FFLsJWfKjMC317bGHX)
			if not qiLFPv6mIVbBHOA8MhrxNDRf7Jng:
				qiLFPv6mIVbBHOA8MhrxNDRf7Jng = jj0dZrgiKb.findall(
					yRWQMHxZEz0(u"ࡳࠩࠪࠫ࠭ࡅࡸࡴࠫࠍࠍࠎࠏࠉࠊ࠽࡟ࡷ࠯࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪ࡞ࡶ࠮ࡂࡢࡳࠫࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠯ࠊࠊࠋࠌࠍࠎࡢࡳࠫ࡞ࡾࠬࡄࡀࠨࡀࠣࢀ࠿࠮࠴ࠩࠬࡁࡵࡩࡹࡻࡲ࡯࡞ࡶ࠮࠭ࡅࡐ࠽ࡳࡁ࡟ࠧ࠭࡝ࠪ࡝࡟ࡻ࠲ࡣࠫࡠࡹ࠻ࡣ࠭ࡅࡐ࠾ࡳࠬࡠࡸ࠰࡜ࠬ࡞ࡶ࠮ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࠬ࠭ࠧ඘"),
					FFLsJWfKjMC317bGHX)
			qiLFPv6mIVbBHOA8MhrxNDRf7Jng = jj0dZrgiKb.findall(qiLFPv6mIVbBHOA8MhrxNDRf7Jng[wTLFCOcM26fmYlW7U][Tb7oymMnpflsSv3eu4Pz2]+A6Sg45ChDR3BJLYfFH(u"ࠩࡀࡠࡠ࠮࠮ࠫࡁࠬࡠࡢ࠭඙"),FFLsJWfKjMC317bGHX,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
		else:
			def _l4x7hcmeKVWrTs8zQNPn2gBy(BqVAWxegrZS2jmvH5ipOcYDTl):
				import ast as DDvqSbRUtK
				DipLjHIAzFG9kKclsVBf = xm6jK1ZMuWq5(u"ࡵࠫࠬ࠭ࠨࡀࡺࠬࠎࠎࠏࠉࠊࠋࠫࡃࡕࡂࡱ࠲ࡀ࡞ࠦࡡ࠭࡝ࠪࡷࡶࡩࡡࡹࠫࡴࡶࡵ࡭ࡨࡺࠨࡀࡒࡀࡵ࠶࠯࠻࡝ࡵ࠭ࠎࠎࠏࠉࠊࠋࠫࡃࡕࡂࡣࡰࡦࡨࡂࠏࠏࠉࠊࠋࠌࠍࡻࡧࡲ࡝ࡵ࠮ࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜ࡴࠬࡀࡠࡸ࠰ࠊࠊࠋࠌࠍࠎࠏࠨࡀࡒ࠿ࡺࡦࡲࡵࡦࡀࠍࠍࠎࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡲ࠴ࡁ࡟ࠧࡢࠧ࡞ࠫࠫࡃ࠿࠮࠿ࠢࠪࡂࡔࡂࡷ࠲ࠪࠫ࠱ࢀࡡࡢ࠮ࠪ࠭ࠫࡃࡕࡃࡱ࠳ࠫࠍࠍࠎࠏࠉࠊࠋࠌࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭࠮࠿ࡑ࠾ࡴ࠷ࡃࡡࠢࠨ࡟ࠬࠬࡄࡀࠨࡀࠣࠫࡃࡕࡃࡱ࠴ࠫࠬ࠲࠮࠱ࠨࡀࡒࡀࡵ࠸࠯࡜ࠪࠌࠌࠍࠎࠏࠉࠊࠋࡿࠎࠎࠏࠉࠊࠋࠌࠍࡡࡡ࡜ࡴࠬࠫࡃ࠿࠮࠿ࡑ࠾ࡴ࠸ࡃࡡࠢ࡝ࠩࡠ࠭࠭ࡅ࠺ࠩࡁࠤࠬࡄࡖ࠽ࡲ࠶ࠬ࠭࠳ࢂ࡜࡝࠰ࠬ࠮࠭ࡅࡐ࠾ࡳ࠷࠭ࡡࡹࠪ࠭ࡁ࡟ࡷ࠯࠯ࠫ࡝࡟ࠍࠍࠎࠏࠉࠊࠋࠬࠎࠎࠏࠉࠊࠋࠬ࡟ࡀ࠲࡝ࠋࠋࠌࠍࠎ࠭ࠧࠨක")
				pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe = jj0dZrgiKb.search(DipLjHIAzFG9kKclsVBf, BqVAWxegrZS2jmvH5ipOcYDTl)
				if not pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe: return None, None
				F6FLxOlWwdIoR8Q5BDqNperkyU = pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe.group(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡳࡧ࡭ࡦࠩඛ"))
				Q6ihns1zSjoLb3Ua = pvTcYxuJgwyFiL0nMl1H3QEVbq4aIe.group(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡼࡡ࡭ࡷࡨࠫග")).strip()
				AABCrtSkPMufjZQR = jj0dZrgiKb.match(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࡸࠧࠨࠩࠫࡃࡽ࠯ࠊࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡴࡂࡠࠨࠧ࡞ࠫࠫࡃࡕࡂࡳࡵࡴ࡬ࡲ࡬ࡄ࠮ࠫࡁࠬࠬࡄࡖ࠽ࡲࠫ࡟࠲ࡸࡶ࡬ࡪࡶ࡟ࠬ࠭ࡅࡐ࠽ࡳ࠵ࡂࡠࠨࠧ࡞ࠫࠫࡃࡕࡂࡳࡦࡲࡁ࠲࠯ࡅࠩࠩࡁࡓࡁࡶ࠸ࠩ࡝ࠫࠍࠍࠎࠏࠉࠨࠩࠪඝ"), Q6ihns1zSjoLb3Ua)
				if AABCrtSkPMufjZQR:
					tf0VNjAMH7XCo8rbuy = AABCrtSkPMufjZQR.group(A6Sg45ChDR3BJLYfFH(u"ࠧࡴࡶࡵ࡭ࡳ࡭ࠧඞ"))
					ttIckOTwvg = AABCrtSkPMufjZQR.group(xm6jK1ZMuWq5(u"ࠨࡵࡨࡴࠬඟ"))
					return F6FLxOlWwdIoR8Q5BDqNperkyU, tf0VNjAMH7XCo8rbuy.split(ttIckOTwvg)
				if Q6ihns1zSjoLb3Ua.startswith(vvhR5ozeiJpANyl8fFO3GBw(u"ࠤ࡞ࠦච")) and Q6ihns1zSjoLb3Ua.endswith(yRWQMHxZEz0(u"ࠥࡡࠧඡ")):
					try:
						gIwYqW8VdJ = DDvqSbRUtK.literal_eval(Q6ihns1zSjoLb3Ua)
						return F6FLxOlWwdIoR8Q5BDqNperkyU, gIwYqW8VdJ
					except: return F6FLxOlWwdIoR8Q5BDqNperkyU, None
				return F6FLxOlWwdIoR8Q5BDqNperkyU, None
			def _WnBzZrMcF9jkeP1u4g2DxUfEJVI8(BqVAWxegrZS2jmvH5ipOcYDTl):
				F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ = _l4x7hcmeKVWrTs8zQNPn2gBy(BqVAWxegrZS2jmvH5ipOcYDTl)
				BQIGaS7qrpugTF1KW06X = None
				if UtI30sBPq5cVkx7oXzCvG82lHfKaOZ:
					try: basestring
					except NameError: basestring = str
					for Uh9uHWxapqMCPbAmGngc in UtI30sBPq5cVkx7oXzCvG82lHfKaOZ:
						if isinstance(Uh9uHWxapqMCPbAmGngc, basestring) and Uh9uHWxapqMCPbAmGngc.endswith(xdSThjYnuHXAU6M(u"ࠫ࠲ࡥࡷ࠹ࡡࠪජ")):
							BQIGaS7qrpugTF1KW06X = Uh9uHWxapqMCPbAmGngc
							break
				if BQIGaS7qrpugTF1KW06X:
					DipLjHIAzFG9kKclsVBf = xdSThjYnuHXAU6M(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠌࠍࠎࡢࡻ࡝ࡵ࠭ࡶࡪࡺࡵࡳࡰ࡟ࡷ࠰ࠫࡳ࡝࡝ࠨࡨࡡࡣ࡜ࡴࠬ࡟࠯ࡡࡹࠪࠩࡁࡓࡀࡦࡸࡧ࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜ࡴࠬ࡟ࢁࠏࠏࠉࠊࠋࠌࠫࠬ࠭ඣ") % (jj0dZrgiKb.escape(F6FLxOlWwdIoR8Q5BDqNperkyU), UtI30sBPq5cVkx7oXzCvG82lHfKaOZ.index(BQIGaS7qrpugTF1KW06X))
					match = jj0dZrgiKb.search(DipLjHIAzFG9kKclsVBf, BqVAWxegrZS2jmvH5ipOcYDTl)
					if match:
						DipLjHIAzFG9kKclsVBf = TNw1pBHb8CtSZe0EFxuJqI(u"ࡸࠧࠨࠩࠫࡃࡽ࠯ࠊࠊࠋࠌࠍࠎࠏࠉ࡝ࡽ࡟ࡷ࠯ࡢࠩࠦࡵ࡟ࠬࡡࡹࠪࠋࠋࠌࠍࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࠍࠎࠏࠨࡀࡒ࠿ࡪࡺࡴࡣ࡯ࡣࡰࡩࡤࡧ࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪ࡞ࡶ࠮ࡳࡵࡩࡵࡥࡱࡹ࡫ࡢࡳࠫࠌࠌࠍࠎࠏࠉࠊࠋࠌࢀࡳࡵࡩࡵࡥࡱࡹ࡫ࡢࡳࠫ࠿࡟ࡷ࠯࠮࠿ࡑ࠾ࡩࡹࡳࡩ࡮ࡢ࡯ࡨࡣࡧࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱ࠩࠩࡁ࠽ࡠࡸ࠱ࡲࡢࡸࠬࡃࠏࠏࠉࠊࠋࠌࠍࠎ࠯࡛࠼࡞ࡱࡡࠏࠏࠉࠊࠋࠌࠍࠬ࠭ࠧඤ") % jj0dZrgiKb.escape(match.group(xm6jK1ZMuWq5(u"ࠧࡢࡴࡪࡲࡦࡳࡥࠨඥ"))[::-VhqD3zp7mUieI8sMQlETH(u"࠳ခ")])
						Ww2UTEhouBnpbjFi4CKQS = jj0dZrgiKb.search(DipLjHIAzFG9kKclsVBf, BqVAWxegrZS2jmvH5ipOcYDTl[match.start()::-erqDsJmL3BQHuGtPkcf0X9(u"࠴ဂ")])
						if Ww2UTEhouBnpbjFi4CKQS:
							XpKaY2xo6QmFcV3iN9kEqduhMR, zEx7ignuNDr0M6a5lBjAqZF1p34ot = Ww2UTEhouBnpbjFi4CKQS.group(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡨࡸࡲࡨࡴࡡ࡮ࡧࡢࡥࠬඦ"), lCT8hfYUBX4OQMmL(u"ࠩࡩࡹࡳࡩ࡮ࡢ࡯ࡨࡣࡧ࠭ට"))
							return (XpKaY2xo6QmFcV3iN9kEqduhMR or zEx7ignuNDr0M6a5lBjAqZF1p34ot)[::-yRWQMHxZEz0(u"࠵ဃ")], F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ
				J8JGT1gLnUxrKMiWaAt0bo6muE4q = jj0dZrgiKb.compile(VhqD3zp7mUieI8sMQlETH(u"ࡵࠫࠬ࠭ࠨࡀࡺࠬࠎࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎࡢ࠮ࡨࡧࡷࡠ࠭ࠨ࡮ࠣ࡞ࠬࡠ࠮ࠬࠦ࡝ࠪࡥࡁࢁࠐࠉࠊࠋࠌࠍࠎ࠮࠿࠻ࠌࠌࠍࠎࠏࠉࠊࠋࡥࡁࡘࡺࡲࡪࡰࡪࡠ࠳࡬ࡲࡰ࡯ࡆ࡬ࡦࡸࡃࡰࡦࡨࡠ࠭࠷࠱࠱࡞ࠬࢀࠏࠏࠉࠊࠋࠌࠍࠎ࠮࠿ࡑ࠾ࡶࡸࡷࡥࡩࡥࡺࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࠰ࡠ࠯࠮ࠬࠦ࡝ࠪࡥࡁࠧࡴ࡮ࠣ࡞࡞ࡠ࠰࠮࠿ࡑ࠿ࡶࡸࡷࡥࡩࡥࡺࠬࡠࡢࠐࠉࠊࠋࠌࠍࠎ࠯ࠊࠊࠋࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊࠋࠌ࠰ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠮ࡡ࡝ࠫࠬࡃ࠱ࡩ࠽ࡢ࡞࠱ࠎࠎࠏࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉࠊࠋࡪࡩࡹࡢࠨࡣ࡞ࠬࢀࠏࠏࠉࠊࠋࠌࠍࠎࠏ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡢࠨࡢ࠱࡜࡜ࡤ࡟ࡡࡡࢂ࡜ࡽࡰࡸࡰࡱࠐࠉࠊࠋࠌࠍࠎࠏࠩ࡝ࠫࠩࠪࡡ࠮ࡣ࠾ࡾࠍࠍࠎࠏࠉࠊࠋ࡟ࡦ࠭ࡅࡐ࠽ࡸࡤࡶࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࠽ࠋࠋࠌࠍࠎࠏࠩࠩࡁࡓࡀࡳ࡬ࡵ࡯ࡥࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭࠭ࡅ࠺࡝࡝ࠫࡃࡕࡂࡩࡥࡺࡁࡠࡩ࠱ࠩ࡝࡟ࠬࡃࡡ࠮࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝࡝ࠫࠍࠍࠎࠏࠉࠊࠪࡂࠬࡻࡧࡲࠪ࠮࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠲ࡸ࡫ࡴ࡝ࠪࠫࡃ࠿ࠨ࡮ࠬࠤࡿ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡ࠲ࠨࡀࡒࡀࡺࡦࡸࠩ࡝ࠫࠬࠎࠎࠏࠉࠊࠩࠪࠫඨ"))
				match = J8JGT1gLnUxrKMiWaAt0bo6muE4q.search(BqVAWxegrZS2jmvH5ipOcYDTl)
				TEsbNDKYoLwmM, kYTfz6B4cXZt = (None, None)
				if match:
					TEsbNDKYoLwmM = match.group(llkFwuCyhaP3sK76qO4T(u"ࠫࡳ࡬ࡵ࡯ࡥࠪඩ"))
					kYTfz6B4cXZt = match.group(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࡯ࡤࡹࠩඪ"))
				if not TEsbNDKYoLwmM:
					print(fmkZtbRj3ux(u"࠭ࡆࡢ࡮࡯࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࠥࡺ࡯ࠡࡩࡨࡲࡪࡸࡩࡤࠢࡱࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡳࡦࡣࡵࡧ࡭࠭ණ"))
					F4jQ6OJTUk9rBhaI5b1Ezim2NAfDVy = jj0dZrgiKb.search(jQv0du1iVxTgAXCM(u"ࡲࠨࠩࠪࠬࡄࡾࡳࠪࠌࠌࠍࠎࠏࠉࠊ࠽࡟ࡷ࠯࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫࠪ࡞ࡶ࠮ࡂࡢࡳࠫࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠯ࠊࠊࠋࠌࠍࠎࠏ࡜ࡴࠬ࡟ࡿ࠭ࡅ࠺ࠩࡁࠤࢁࡀ࠯࠮ࠪ࠭ࡂࡶࡪࡺࡵࡳࡰ࡟ࡷ࠯࠮࠿ࡑ࠾ࡴࡂࡠࠨࠧ࡞ࠫ࡞ࡠࡼ࠳࡝ࠬࡡࡺ࠼ࡤ࠮࠿ࡑ࠿ࡴ࠭ࡡࡹࠪ࡝࠭࡟ࡷ࠯ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࠐࠉࠊࠋࠌࠍࠬ࠭ࠧඬ"), BqVAWxegrZS2jmvH5ipOcYDTl)
					if F4jQ6OJTUk9rBhaI5b1Ezim2NAfDVy: return F4jQ6OJTUk9rBhaI5b1Ezim2NAfDVy.group(rDG9dZoXRhCJcieUSF0KB(u"ࠨࡰࡤࡱࡪ࠭ත")), F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ
					return None,None,None
				elif not kYTfz6B4cXZt: return TEsbNDKYoLwmM, F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ
				X9HERb4fiQuJG = jj0dZrgiKb.search(kPCxIUZb1V(u"ࡴࠪࡺࡦࡸࠠࡼࡿ࡟ࡠࡸ࠰࠽࡝࡞ࡶ࠮࠭ࡢ࡜࡜࠰࠮ࡃࡡࡢ࡝ࠪ࡞࡟ࡷ࠯ࡡࠬ࠼࡟ࠪථ").format(jj0dZrgiKb.escape(TEsbNDKYoLwmM)), BqVAWxegrZS2jmvH5ipOcYDTl)
				if X9HERb4fiQuJG: return bbeLsVCqouaSH53E0XmKh4AnFD.loads(yE7nuAxiaMqgpH3s1TOm2VLjP(X9HERb4fiQuJG.group(bQGafNLXyFgsZP6ut(u"࠶င"))))[int(kYTfz6B4cXZt)], F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ
				return None, F6FLxOlWwdIoR8Q5BDqNperkyU, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ
			qiLFPv6mIVbBHOA8MhrxNDRf7Jng, ERgQJnkFe5K8ualtAy74d, UtI30sBPq5cVkx7oXzCvG82lHfKaOZ = _WnBzZrMcF9jkeP1u4g2DxUfEJVI8(FFLsJWfKjMC317bGHX)
			if not qiLFPv6mIVbBHOA8MhrxNDRf7Jng: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(weh7SGmuTgXOVRcMo1rlLq(u"ࠪࠫද"),llkFwuCyhaP3sK76qO4T(u"ࠫࠬධ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࡟࡯ࡶࡶࡸࡦࡪ๊้ࠦฬํ์อ࠭න"),jQv0du1iVxTgAXCM(u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡤࡦࡥࡵࡽࡵࡺࡩ࡯ࡩࠣࡴࡱࡧࡹࠡ࡮࡬ࡲࡰࡹࠠ࡝ࡰ࡟ࡲࠥ็ิๅࠢไ๎ࠥ็สฮࠢอุๆ๐ัࠡำ๋หอ฽ࠠศๆไ๎ิ๐่ࠨ඲"))
			else:
				P6B9KChG2A3UT = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(UtI30sBPq5cVkx7oXzCvG82lHfKaOZ)
				Cdk3vmIRYg9cL15qMtzn86 = FFLsJWfKjMC317bGHX.find(qiLFPv6mIVbBHOA8MhrxNDRf7Jng+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧ࠾ࡨࡸࡲࡨࡺࡩࡰࡰࠫࠫඳ"))
				iKjQ0qv9ahgYE2OeDz = FFLsJWfKjMC317bGHX.find(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡿ࠾ࠫප"), Cdk3vmIRYg9cL15qMtzn86)
				uxHKBeTyfZFMLOYwVtc = FFLsJWfKjMC317bGHX[Cdk3vmIRYg9cL15qMtzn86:iKjQ0qv9ahgYE2OeDz]+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࢀ࠿ࠬඵ")
				lOIWen5APRmuV = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࡵࠫ࡮࡬࡜ࠩࡶࡼࡴࡪࡵࡦࠡ࠰࠭ࡃࡂࡃ࠽࠯ࠬࡂࡠ࠮ࡸࡥࡵࡷࡵࡲࠥ࠴࠻ࠨබ"), uxHKBeTyfZFMLOYwVtc, jj0dZrgiKb.DOTALL)
				if lOIWen5APRmuV: uxHKBeTyfZFMLOYwVtc = uxHKBeTyfZFMLOYwVtc.replace(lOIWen5APRmuV[vvhR5ozeiJpANyl8fFO3GBw(u"࠶စ")],pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࠬභ"))
				if not ERgQJnkFe5K8ualtAy74d: ERgQJnkFe5K8ualtAy74d = jj0dZrgiKb.findall(jQv0du1iVxTgAXCM(u"ࠬࡼࡡࡳࠢ࠱࠮ࡄࡃࠨ࠯ࠬࡂ࠭ࡡ࠴ࠧම"),uxHKBeTyfZFMLOYwVtc,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
				uxHKBeTyfZFMLOYwVtc = uxHKBeTyfZFMLOYwVtc.replace(TNw1pBHb8CtSZe0EFxuJqI(u"࠭࡜࡯ࠩඹ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				uxHKBeTyfZFMLOYwVtc = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠢࡷࡣࡵࠤࢀࢃࠠ࠾ࠢࡾࢁࡀࡢ࡮ࡼࡿࠥය").format(ERgQJnkFe5K8ualtAy74d, P6B9KChG2A3UT, uxHKBeTyfZFMLOYwVtc)
				KkdSE587tvIq6jLDcBgeX2 = {}
				Sv7qNkIifGYegw4uzTd = []
				for Yb6nDMHshgV2 in B5T3SAbWa78fQCOKpDnL:
					url = Yb6nDMHshgV2[kPCxIUZb1V(u"ࠨࡷࡵࡰࠬර")]
					if vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࠩࡲࡂ࠭඼") in url:
						jrlPIFwxq3RO048bvafe = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࠪࡳࡃࠨ࠯ࠬࡂ࠭ࠫ࠭ල"),url,jj0dZrgiKb.DOTALL)[wTLFCOcM26fmYlW7U]
						if jrlPIFwxq3RO048bvafe not in list(KkdSE587tvIq6jLDcBgeX2.keys()):
							AAJjEVBK0CLQD7xyOn2WftgZc3 = QQEPUv1XWm5zMFaiDgVGqI(uxHKBeTyfZFMLOYwVtc,[qiLFPv6mIVbBHOA8MhrxNDRf7Jng,jrlPIFwxq3RO048bvafe])
							KkdSE587tvIq6jLDcBgeX2[jrlPIFwxq3RO048bvafe] = AAJjEVBK0CLQD7xyOn2WftgZc3
						else: AAJjEVBK0CLQD7xyOn2WftgZc3 = KkdSE587tvIq6jLDcBgeX2[jrlPIFwxq3RO048bvafe]
						Yb6nDMHshgV2[w8JC1y7Lp3(u"ࠫࡺࡸ࡬ࠨ඾")] = url.replace(lCT8hfYUBX4OQMmL(u"ࠬࠬ࡮࠾ࠩ඿")+jrlPIFwxq3RO048bvafe+MFhbWia58mP3su0fk2d(u"࠭ࠦࠨව"),xdSThjYnuHXAU6M(u"ࠧࠧࡰࡀࠫශ")+AAJjEVBK0CLQD7xyOn2WftgZc3+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࠨࠪෂ"))
					Sv7qNkIifGYegw4uzTd.append(Yb6nDMHshgV2)
				B5T3SAbWa78fQCOKpDnL = Sv7qNkIifGYegw4uzTd.copy()
	for dict in B5T3SAbWa78fQCOKpDnL:
		url = dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡸࡶࡱ࠭ස")]
		if xm6jK1ZMuWq5(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧහ") in url or url.count(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡸ࡯ࡧ࠾ࠩළ"))>UD4N8MjVTd: dvQ5gG3InTMVF0XeOjiE2bsaJyw7fA.append(dict)
		elif FFLsJWfKjMC317bGHX and xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡹࠧෆ") in dict and xm6jK1ZMuWq5(u"࠭ࡳࡱࠩ෇") in dict:
			bbIiZqypJCP = koQv3BtLhIfCaRTN.execute(dict[s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡴࠩ෈")])
			if bbIiZqypJCP!=dict[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡵࠪ෉")]:
				dict[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡸࡶࡱ්࠭")] = url+JHMxIE4fs1mvQtKW7R(u"ࠪࠪࠬ෋")+dict[bQGafNLXyFgsZP6ut(u"ࠫࡸࡶࠧ෌")]+D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡃࠧ෍")+bbIiZqypJCP
				dvQ5gG3InTMVF0XeOjiE2bsaJyw7fA.append(dict)
		else: dvQ5gG3InTMVF0XeOjiE2bsaJyw7fA.append(dict)
	for dict in dvQ5gG3InTMVF0XeOjiE2bsaJyw7fA:
		t3oe4rjuvpMQKwRnbkTaqYsAI6i5,pS8dGeV7yP4r2NFoY9vE,UOtzBNY9uyFkIAC4iheGVv6g,mmZUvVcxAqEg0FN,u3glqAkt9OnfN,oqF5GjVvYXpBd1l2xmWL0n3kU = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ෎"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨා"),erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩැ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪෑ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠪ࠴ࠬි")
		try:
			xTpngNEFfWjJu3045lY = dict[xm6jK1ZMuWq5(u"ࠫࡹࡿࡰࡦࠩී")]
			xTpngNEFfWjJu3045lY = xTpngNEFfWjJu3045lY.replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠱ࠧු"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			items = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ෕"),xTpngNEFfWjJu3045lY,jj0dZrgiKb.DOTALL)
			mmZUvVcxAqEg0FN,t3oe4rjuvpMQKwRnbkTaqYsAI6i5,u3glqAkt9OnfN = items[wTLFCOcM26fmYlW7U]
			vnhLjycm4bia9EA7FwNqHMf1kUZur = u3glqAkt9OnfN.split(vvhR5ozeiJpANyl8fFO3GBw(u"ࠧ࠭ࠩූ"))
			pS8dGeV7yP4r2NFoY9vE = wUvcPrYDfISbZolAm83GKEqMyXkn5
			for o4oW9wDcsrpHQS816yfIvg in vnhLjycm4bia9EA7FwNqHMf1kUZur: pS8dGeV7yP4r2NFoY9vE += o4oW9wDcsrpHQS816yfIvg.split(xm6jK1ZMuWq5(u"ࠨ࠰ࠪ෗"))[wTLFCOcM26fmYlW7U]+erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࠯ࠫෘ")
			pS8dGeV7yP4r2NFoY9vE = pS8dGeV7yP4r2NFoY9vE.strip(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࠰ࠬෙ"))
			if weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬේ") in dict: oqF5GjVvYXpBd1l2xmWL0n3kU = str(int(dict[it4DKnryZlx(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ෛ")])//s149dk8uh2p7oFzaLxZeI3Or(u"࠱࠱࠴࠷ဆ"))+xm6jK1ZMuWq5(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ො")
			else: oqF5GjVvYXpBd1l2xmWL0n3kU = wUvcPrYDfISbZolAm83GKEqMyXkn5
			if mmZUvVcxAqEg0FN==vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡵࡧࡻࡸࠬෝ"): continue
			elif SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨ࠮ࠪෞ") in xTpngNEFfWjJu3045lY:
				mmZUvVcxAqEg0FN = weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡄ࠯࡛࠭ෟ")
				UOtzBNY9uyFkIAC4iheGVv6g = t3oe4rjuvpMQKwRnbkTaqYsAI6i5+lB8tuyg6sxkDVYAaS95K3GI+oqF5GjVvYXpBd1l2xmWL0n3kU+dict[w8JC1y7Lp3(u"ࠪࡷ࡮ࢀࡥࠨ෠")].split(w8JC1y7Lp3(u"ࠫࡽ࠭෡"))[UD4N8MjVTd]
			elif mmZUvVcxAqEg0FN==xm6jK1ZMuWq5(u"ࠬࡼࡩࡥࡧࡲࠫ෢"):
				mmZUvVcxAqEg0FN = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡖࡪࡦࡨࡳࠬ෣")
				UOtzBNY9uyFkIAC4iheGVv6g = oqF5GjVvYXpBd1l2xmWL0n3kU+dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡴ࡫ࡽࡩࠬ෤")].split(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡺࠪ෥"))[UD4N8MjVTd]+lB8tuyg6sxkDVYAaS95K3GI+dict[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡩࡴࡸ࠭෦")]+llkFwuCyhaP3sK76qO4T(u"ࠪࡪࡵࡹࠧ෧")+lB8tuyg6sxkDVYAaS95K3GI+t3oe4rjuvpMQKwRnbkTaqYsAI6i5
			elif mmZUvVcxAqEg0FN==fmkZtbRj3ux(u"ࠫࡦࡻࡤࡪࡱࠪ෨"):
				mmZUvVcxAqEg0FN = kPCxIUZb1V(u"ࠬࡇࡵࡥ࡫ࡲࠫ෩")
				UOtzBNY9uyFkIAC4iheGVv6g = oqF5GjVvYXpBd1l2xmWL0n3kU+str(int(dict[Gj3rMP1Cb8wHdp49la0(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ෪")])/gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠲࠲࠳࠴ဇ"))+A6Sg45ChDR3BJLYfFH(u"ࠧ࡬ࡪࡽࠤࠥ࠭෫")+dict[DpRJnas65uVcO0S17dYG(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ෬")]+yRWQMHxZEz0(u"ࠩࡦ࡬ࠬ෭")+lB8tuyg6sxkDVYAaS95K3GI+t3oe4rjuvpMQKwRnbkTaqYsAI6i5
		except:
			av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
			if av1f8x5yZ9rAsq!=kPCxIUZb1V(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭෮"): Sph0cr2ZWK1atAUw5CTuxoe.stderr.write(av1f8x5yZ9rAsq)
		url = Z6bUG0kDQuFqgzdAa1r(dict[weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡺࡸ࡬ࠨ෯")])
		if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࠬࡤࡶࡴࡀࠫ෰") in url: KS5UPc7G4x38Lp = round(DpRJnas65uVcO0S17dYG(u"࠲࠱࠹ဈ")+float(url.split(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࠦࡥࡷࡵࡁࠬ෱"),UD4N8MjVTd)[UD4N8MjVTd].split(weh7SGmuTgXOVRcMo1rlLq(u"ࠧࠧࠩෲ"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]))
		elif xm6jK1ZMuWq5(u"ࠨ࠽ࡧࡹࡷࡃࠧෳ") in url: KS5UPc7G4x38Lp = round(TNw1pBHb8CtSZe0EFxuJqI(u"࠳࠲࠺ဉ")+float(url.split(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࠾ࡨࡺࡸ࠽ࠨ෴"),UD4N8MjVTd)[UD4N8MjVTd].split(it4DKnryZlx(u"ࠪ࠿ࠬ෵"),UD4N8MjVTd)[wTLFCOcM26fmYlW7U]))
		elif rDG9dZoXRhCJcieUSF0KB(u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧ෶") in dict: KS5UPc7G4x38Lp = round(D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠳࠻ည")+float(dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ෷")])/xdSThjYnuHXAU6M(u"࠶࠶࠰࠱ဋ"))
		else: KS5UPc7G4x38Lp = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࠰ࠨ෸")
		if fmkZtbRj3ux(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ෹") not in dict: oqF5GjVvYXpBd1l2xmWL0n3kU = dict[fmkZtbRj3ux(u"ࠨࡵ࡬ࡾࡪ࠭෺")].split(kPCxIUZb1V(u"ࠩࡻࠫ෻"))[UD4N8MjVTd]
		else: oqF5GjVvYXpBd1l2xmWL0n3kU = str(int(dict[yRWQMHxZEz0(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ෼")])//weh7SGmuTgXOVRcMo1rlLq(u"࠷࠰࠳࠶ဌ"))
		if ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࡮ࡴࡩࡵࠩ෽") not in dict: dict[MFhbWia58mP3su0fk2d(u"ࠬ࡯࡮ࡪࡶࠪ෾")] = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠰࠮࠲ࠪ෿")
		dict[yRWQMHxZEz0(u"ࠧࡵ࡫ࡷࡰࡪ࠭฀")] = mmZUvVcxAqEg0FN+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࠼ࠣࠤࠬก")+UOtzBNY9uyFkIAC4iheGVv6g+MFhbWia58mP3su0fk2d(u"ࠩࠣࠤ࠭࠭ข")+pS8dGeV7yP4r2NFoY9vE+JHMxIE4fs1mvQtKW7R(u"ࠪ࠰ࠬฃ")+dict[yRWQMHxZEz0(u"ࠫ࡮ࡺࡡࡨࠩค")]+it4DKnryZlx(u"ࠬ࠯ࠧฅ")
		dict[s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧฆ")] = UOtzBNY9uyFkIAC4iheGVv6g.split(lB8tuyg6sxkDVYAaS95K3GI)[wTLFCOcM26fmYlW7U].split(DpRJnas65uVcO0S17dYG(u"ࠧ࡬ࡤࡳࡷࠬง"))[wTLFCOcM26fmYlW7U]
		dict[VhqD3zp7mUieI8sMQlETH(u"ࠨࡶࡼࡴࡪ࠸ࠧจ")] = mmZUvVcxAqEg0FN
		dict[MFhbWia58mP3su0fk2d(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫฉ")] = t3oe4rjuvpMQKwRnbkTaqYsAI6i5
		dict[MFhbWia58mP3su0fk2d(u"ࠪࡧࡴࡪࡥࡤࡵࠪช")] = u3glqAkt9OnfN
		dict[JHMxIE4fs1mvQtKW7R(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ซ")] = KS5UPc7G4x38Lp
		dict[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ฌ")] = oqF5GjVvYXpBd1l2xmWL0n3kU
		jA9FtDVWyB2vifOoanJRlH5KLTZrEm.append(dict)
	xL5DtO2ioeFYkIcTbAXVmB9pMZy1Qz,N2DybpPZUoXg1f54MaWGILntxuSF0,oopT15NyrwJEKhGVD4smeMcBb92,nbBXPW5p19qmfhD4i,j6j8K4zoaNWxBmERUFMP = [],[],[],[],[]
	zdFvhxE0Mt8bLA3qHsmI5PRkYpj,O6jayuSf5JDkRqI3FzXewGPBT1bY,GelWOrcPYkvTn2Azy9UN4jJt6S5,zRBawxWOYjrD,aAfcIX9eMrQpTRwysOdh58 = [],[],[],[],[]
	for cML3BySIYkrgsxi2a1TZv4j in KF3OuMi41ZY2E6tNQnCUV0evspLH:
		if not cML3BySIYkrgsxi2a1TZv4j: continue
		dict = {}
		dict[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡴࡺࡲࡨ࠶ࠬญ")] = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡂ࡙࠭ࠫฎ")
		dict[Gj3rMP1Cb8wHdp49la0(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪฏ")] = vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡰࡴࡩ࠭ฐ")
		dict[fmkZtbRj3ux(u"ࠪࡸ࡮ࡺ࡬ࡦࠩฑ")] = dict[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡹࡿࡰࡦ࠴ࠪฒ")]+vWNRusF46D7Mi8GpZ(u"ࠬࡀࠠࠡࠩณ")+dict[weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨด")]+lB8tuyg6sxkDVYAaS95K3GI+xdSThjYnuHXAU6M(u"ࠧอ๊าอࠥึใ๋หࠪต")
		dict[llkFwuCyhaP3sK76qO4T(u"ࠨࡷࡵࡰࠬถ")] = cML3BySIYkrgsxi2a1TZv4j
		dict[D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪท")] = weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࠴ࠬธ")
		dict[jQv0du1iVxTgAXCM(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬน")] = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࠷࠱࠲࠴࠵࠶࠸࠹࠳ࠨบ")
		jA9FtDVWyB2vifOoanJRlH5KLTZrEm.append(dict)
	for ITpDv0s54awxGgmV7Lht in js1RAl3aBPfiSN2F:
		if not ITpDv0s54awxGgmV7Lht: continue
		VUsLcf1yqFrxn5HQM,tbpP1Z9dNE = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,ITpDv0s54awxGgmV7Lht)
		G5oiXnYPF0NDOlgrE4Mwbm = list(zip(VUsLcf1yqFrxn5HQM,tbpP1Z9dNE))
		for title,hhEH1rcSP0z6Bkqy8OD in G5oiXnYPF0NDOlgrE4Mwbm:
			dict = {}
			dict[TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡴࡺࡲࡨ࠶ࠬป")] = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡂ࡙࠭ࠫผ")
			dict[jQv0du1iVxTgAXCM(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪฝ")] = fmkZtbRj3ux(u"ࠩࡰ࠷ࡺ࠾ࠧพ")
			dict[erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡹࡷࡲࠧฟ")] = hhEH1rcSP0z6Bkqy8OD
			if Gj3rMP1Cb8wHdp49la0(u"ࠫࡰࡨࡰࡴࠩภ") in title: dict[bQGafNLXyFgsZP6ut(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ม")] = title.split(vvhR5ozeiJpANyl8fFO3GBw(u"࠭࡫ࡣࡲࡶࠫย"))[wTLFCOcM26fmYlW7U].rsplit(lB8tuyg6sxkDVYAaS95K3GI)[-UD4N8MjVTd]
			else: dict[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨร")] = JHMxIE4fs1mvQtKW7R(u"ࠨ࠳࠳ࠫฤ")
			if title.count(lB8tuyg6sxkDVYAaS95K3GI)>UD4N8MjVTd:
				KwSdzRXT0M3VW = title.rsplit(lB8tuyg6sxkDVYAaS95K3GI)[-MMRBkhnWVJCQwU]
				if KwSdzRXT0M3VW.isdigit(): dict[vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪล")] = KwSdzRXT0M3VW
				else: dict[VhqD3zp7mUieI8sMQlETH(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫฦ")] = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫ࠵࠶࠰࠱ࠩว")
			if title==bQGafNLXyFgsZP6ut(u"ࠬ࠳࠱ࠨศ"): dict[MFhbWia58mP3su0fk2d(u"࠭ࡴࡪࡶ࡯ࡩࠬษ")] = dict[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡵࡻࡳࡩ࠷࠭ส")]+rDG9dZoXRhCJcieUSF0KB(u"ࠨ࠼ࠣࠤࠬห")+dict[it4DKnryZlx(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫฬ")]+lB8tuyg6sxkDVYAaS95K3GI+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪะํีษࠡาๆ๎ฮ࠭อ")
			else: dict[VhqD3zp7mUieI8sMQlETH(u"ࠫࡹ࡯ࡴ࡭ࡧࠪฮ")] = dict[fmkZtbRj3ux(u"ࠬࡺࡹࡱࡧ࠵ࠫฯ")]+jQv0du1iVxTgAXCM(u"࠭࠺ࠡࠢࠪะ")+dict[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩั")]+lB8tuyg6sxkDVYAaS95K3GI+dict[llkFwuCyhaP3sK76qO4T(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩา")]+Gj3rMP1Cb8wHdp49la0(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩำ")+dict[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫิ")]
			jA9FtDVWyB2vifOoanJRlH5KLTZrEm.append(dict)
	jA9FtDVWyB2vifOoanJRlH5KLTZrEm = sorted(jA9FtDVWyB2vifOoanJRlH5KLTZrEm,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: int(key[bQGafNLXyFgsZP6ut(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬี")]))
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [lCT8hfYUBX4OQMmL(u"ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩึ")],[wUvcPrYDfISbZolAm83GKEqMyXkn5]
	try: e6oWxs3lg9XO = UQvXbgEDP3AsikM24l[TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨื")][rDG9dZoXRhCJcieUSF0KB(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵุࠫ")][SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨู")]
	except: e6oWxs3lg9XO = []
	try: JKulNt2v9nZGeq48TQEWb5cUxa = UQvXbgEDP3AsikM24l[fmkZtbRj3ux(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡶฺࠫ")][pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ฻")][xm6jK1ZMuWq5(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲ࡙ࡸࡡࡤ࡭ࡶࠫ฼")]
	except: JKulNt2v9nZGeq48TQEWb5cUxa = []
	for fR0QIeryg14Xnxs5 in e6oWxs3lg9XO+JKulNt2v9nZGeq48TQEWb5cUxa:
		try:
			hhEH1rcSP0z6Bkqy8OD = fR0QIeryg14Xnxs5[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡨࡡࡴࡧࡘࡶࡱ࠭฽")]
			try: title = fR0QIeryg14Xnxs5[vWNRusF46D7Mi8GpZ(u"࠭࡮ࡢ࡯ࡨࠫ฾")][rDG9dZoXRhCJcieUSF0KB(u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫ฿")]
			except: title = fR0QIeryg14Xnxs5[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡰࡤࡱࡪ࠭เ")][dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡵࡹࡳࡹࠧแ")][wTLFCOcM26fmYlW7U][dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡸࡪࡾࡴࠨโ")]
		except: continue
		if title not in Eu8LWnSt3fyJzIC:
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			Eu8LWnSt3fyJzIC.append(title)
	if len(Eu8LWnSt3fyJzIC)>UD4N8MjVTd:
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫฬิสาࠢส่ฯืฬๆหࠣࠬࠬใ")+str(len(Eu8LWnSt3fyJzIC))+MFhbWia58mP3su0fk2d(u"ࠬࠦๅๅใࠬࠫไ"),Eu8LWnSt3fyJzIC)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return rDG9dZoXRhCJcieUSF0KB(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫๅ"),[],[]
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq!=wTLFCOcM26fmYlW7U:
			hhEH1rcSP0z6Bkqy8OD = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]+MFhbWia58mP3su0fk2d(u"ࠧࠧࠩๆ")
			Xhm4Solb3VU = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭็"),hhEH1rcSP0z6Bkqy8OD)
			if Xhm4Solb3VU: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(Xhm4Solb3VU[wTLFCOcM26fmYlW7U],xdSThjYnuHXAU6M(u"ࠩࡩࡱࡹࡃࡶࡵࡶ่ࠪ"))
			else: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+yRWQMHxZEz0(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷ้ࠫ")
			ddK3lsEzy4 = hhEH1rcSP0z6Bkqy8OD.strip(Gj3rMP1Cb8wHdp49la0(u"๊ࠫࠫ࠭"))
	EZSHGdl2LjrPts1FKTcBhRxp = []
	for dict in jA9FtDVWyB2vifOoanJRlH5KLTZrEm:
		if dict[lCT8hfYUBX4OQMmL(u"ࠬࡺࡹࡱࡧ࠵๋ࠫ")]==it4DKnryZlx(u"࠭ࡖࡪࡦࡨࡳࠬ์"):
			xL5DtO2ioeFYkIcTbAXVmB9pMZy1Qz.append(dict[vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡵ࡫ࡷࡰࡪ࠭ํ")])
			zdFvhxE0Mt8bLA3qHsmI5PRkYpj.append(dict)
		elif dict[TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡶࡼࡴࡪ࠸ࠧ๎")]==fmkZtbRj3ux(u"ࠩࡄࡹࡩ࡯࡯ࠨ๏"):
			N2DybpPZUoXg1f54MaWGILntxuSF0.append(dict[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ๐")])
			O6jayuSf5JDkRqI3FzXewGPBT1bY.append(dict)
		elif dict[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭๑")]==JHMxIE4fs1mvQtKW7R(u"ࠬࡳࡰࡥࠩ๒") or dict[TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ๓")]==vWNRusF46D7Mi8GpZ(u"ࠧ࡮࠵ࡸ࠼ࠬ๔"):
			title = dict[DpRJnas65uVcO0S17dYG(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ๕")].replace(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ๖"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ๗") not in dict: oqF5GjVvYXpBd1l2xmWL0n3kU = xm6jK1ZMuWq5(u"ࠫ࠵࠭๘")
			else: oqF5GjVvYXpBd1l2xmWL0n3kU = dict[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭๙")]
			EZSHGdl2LjrPts1FKTcBhRxp.append([dict,{},title,oqF5GjVvYXpBd1l2xmWL0n3kU])
		else:
			title = dict[it4DKnryZlx(u"࠭ࡴࡪࡶ࡯ࡩࠬ๚")].replace(lCT8hfYUBX4OQMmL(u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ๛"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ๜") not in dict: oqF5GjVvYXpBd1l2xmWL0n3kU = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩ࠳ࠫ๝")
			else: oqF5GjVvYXpBd1l2xmWL0n3kU = dict[A6Sg45ChDR3BJLYfFH(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ๞")]
			EZSHGdl2LjrPts1FKTcBhRxp.append([dict,{},title,oqF5GjVvYXpBd1l2xmWL0n3kU])
			oopT15NyrwJEKhGVD4smeMcBb92.append(title)
			GelWOrcPYkvTn2Azy9UN4jJt6S5.append(dict)
		gYpehcIWDtq3C = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡨࡵࡤࡦࡥࡶࠫ๟") in dict:
			if MFhbWia58mP3su0fk2d(u"ࠬࡧࡶ࠱ࠩ๠") in dict[rDG9dZoXRhCJcieUSF0KB(u"࠭ࡣࡰࡦࡨࡧࡸ࠭๡")]: gYpehcIWDtq3C = Z19pUxa2gfGMNKoDsEuytn85SjFvA
			elif Uy6GWujQiBLhodP<kPCxIUZb1V(u"࠱࠹ဍ") and jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡢࡸࡦࠫ๢") not in dict[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡥࡲࡨࡪࡩࡳࠨ๣")] and VhqD3zp7mUieI8sMQlETH(u"ࠩࡰࡴ࠹ࡧࠧ๤") not in dict[bQGafNLXyFgsZP6ut(u"ࠪࡧࡴࡪࡥࡤࡵࠪ๥")]: gYpehcIWDtq3C = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		if gYpehcIWDtq3C and dict[s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡹࡿࡰࡦ࠴ࠪ๦")]==weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࡜ࡩࡥࡧࡲࠫ๧"):
			j6j8K4zoaNWxBmERUFMP.append(dict[lCT8hfYUBX4OQMmL(u"࠭ࡴࡪࡶ࡯ࡩࠬ๨")])
			aAfcIX9eMrQpTRwysOdh58.append(dict)
		elif gYpehcIWDtq3C and dict[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡵࡻࡳࡩ࠷࠭๩")]==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡃࡸࡨ࡮ࡵࠧ๪"):
			nbBXPW5p19qmfhD4i.append(dict[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡷ࡭ࡹࡲࡥࠨ๫")])
			zRBawxWOYjrD.append(dict)
	for SVIUhc36CG5njDL in zRBawxWOYjrD:
		HknFaWYJCMUDfv = SVIUhc36CG5njDL[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ๬")]
		for lPw8LujCTi2WOmzp in aAfcIX9eMrQpTRwysOdh58:
			A1tc7szlTE5rkS4ZBLRguNy8 = lPw8LujCTi2WOmzp[MFhbWia58mP3su0fk2d(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ๭")]
			oqF5GjVvYXpBd1l2xmWL0n3kU = int(A1tc7szlTE5rkS4ZBLRguNy8)+int(HknFaWYJCMUDfv)
			title = lPw8LujCTi2WOmzp[VhqD3zp7mUieI8sMQlETH(u"ࠬࡺࡩࡵ࡮ࡨࠫ๮")].replace(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ๯"),VhqD3zp7mUieI8sMQlETH(u"ࠧࡣ࡫ࡱࡨࠥࠦࠧ๰"))
			title = title.replace(lPw8LujCTi2WOmzp[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ๱")]+lB8tuyg6sxkDVYAaS95K3GI,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			title = title.replace(A1tc7szlTE5rkS4ZBLRguNy8+fmkZtbRj3ux(u"ࠩ࡮ࡦࡵࡹࠧ๲"),str(oqF5GjVvYXpBd1l2xmWL0n3kU)+DpRJnas65uVcO0S17dYG(u"ࠪ࡯ࡧࡶࡳࠨ๳"))
			title = title+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫ࠭࠭๴")+SVIUhc36CG5njDL[xdSThjYnuHXAU6M(u"ࠬࡺࡩࡵ࡮ࡨࠫ๵")].split(s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࠨࠨ๶"),UD4N8MjVTd)[UD4N8MjVTd]
			EZSHGdl2LjrPts1FKTcBhRxp.append([lPw8LujCTi2WOmzp,SVIUhc36CG5njDL,title,oqF5GjVvYXpBd1l2xmWL0n3kU])
	o1o67KC0AmaJGuz2kbeLgr4d3RE = []
	for stream in EZSHGdl2LjrPts1FKTcBhRxp:
		lPw8LujCTi2WOmzp,SVIUhc36CG5njDL,title,oqF5GjVvYXpBd1l2xmWL0n3kU = stream
		ZZJOIp1uFh7CQ2BdiwNSRa86 = title[:MMRBkhnWVJCQwU]
		if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧัๅํอࠬ๷") in title: ZZJOIp1uFh7CQ2BdiwNSRa86 += xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨ࠭ࠪ๸")
		o1o67KC0AmaJGuz2kbeLgr4d3RE.append([stream,ZZJOIp1uFh7CQ2BdiwNSRa86,int(oqF5GjVvYXpBd1l2xmWL0n3kU)])
	JncmOQ8obj3q = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	HzW9rGPnT7u2Y34VmtfeIiE = L9GcjSEeQJUZuCRrg(UdbRGoKhcDeI4lVfns5,o1o67KC0AmaJGuz2kbeLgr4d3RE)
	g4pkhBVfRTnoD = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if HzW9rGPnT7u2Y34VmtfeIiE:
		G18Hmu5dLXEDl60,XPDyqAgQuUl4xNOrHm8BbcGLC,title,oqF5GjVvYXpBd1l2xmWL0n3kU = HzW9rGPnT7u2Y34VmtfeIiE[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U]
		u6bpM7e5qtQmwzISUVTXPyKnHYi2F = G18Hmu5dLXEDl60[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡸࡶࡱ࠭๹")]
		if s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡦ࡮ࡴࡤࠨ๺") in title and u6bpM7e5qtQmwzISUVTXPyKnHYi2F!=cML3BySIYkrgsxi2a1TZv4j: JncmOQ8obj3q = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		g4pkhBVfRTnoD = title
	else:
		J6OrVEP1vmlipSu4F = L9GcjSEeQJUZuCRrg(UdbRGoKhcDeI4lVfns5,o1o67KC0AmaJGuz2kbeLgr4d3RE,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠲࠷࠳࠴ဎ"))
		J6OrVEP1vmlipSu4F,pprMKh6zf9dnbTyo,GzsEAr6VN5yYb8eI0d2qRKmT = zip(*J6OrVEP1vmlipSu4F)
		P1euOgwZtcKn2MfAj38rs,HDLe9NtWfh14JujBsUiG,HZcKGP6yrvs7wBCYomXLVF3aq4fUQ = [],[],wTLFCOcM26fmYlW7U
		EZSHGdl2LjrPts1FKTcBhRxp = sorted(EZSHGdl2LjrPts1FKTcBhRxp, reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2, key=lambda key: float(key[MMRBkhnWVJCQwU]))
		n8uSs0idgJzy6Fx,tkK9BfZvrnQGi8pujA41RXL,iinhqBP3exTWlZzLwQyOGcafY0d1g = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		try: n8uSs0idgJzy6Fx = UQvXbgEDP3AsikM24l[xm6jK1ZMuWq5(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ๻")][jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡧࡵࡵࡪࡲࡶࠬ๼")]
		except:
			try: n8uSs0idgJzy6Fx = wwjbdhgWlFA[Gj3rMP1Cb8wHdp49la0(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ๽")][xm6jK1ZMuWq5(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧ๾")]
			except: pass
		try: tkK9BfZvrnQGi8pujA41RXL = UQvXbgEDP3AsikM24l[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ๿")][xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ຀")]
		except:
			try: tkK9BfZvrnQGi8pujA41RXL = wwjbdhgWlFA[s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩກ")][ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧຂ")]
			except: pass
		if n8uSs0idgJzy6Fx and tkK9BfZvrnQGi8pujA41RXL:
			HZcKGP6yrvs7wBCYomXLVF3aq4fUQ += UD4N8MjVTd
			title = JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ຃")+n8uSs0idgJzy6Fx+AAByQSLgaZwCsKnvc5eWNmY
			hhEH1rcSP0z6Bkqy8OD = TTuO14NzmB.SITESURLS[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧຄ")][wTLFCOcM26fmYlW7U]+lCT8hfYUBX4OQMmL(u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ຅")+tkK9BfZvrnQGi8pujA41RXL
			P1euOgwZtcKn2MfAj38rs.append(title)
			HDLe9NtWfh14JujBsUiG.append(hhEH1rcSP0z6Bkqy8OD)
			try: iinhqBP3exTWlZzLwQyOGcafY0d1g = UQvXbgEDP3AsikM24l[bQGafNLXyFgsZP6ut(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧຆ")][xdSThjYnuHXAU6M(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬງ")][JHMxIE4fs1mvQtKW7R(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧຈ")][-UD4N8MjVTd][xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡺࡸ࡬ࠨຉ")]
			except:
				try: iinhqBP3exTWlZzLwQyOGcafY0d1g = wwjbdhgWlFA[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫຊ")][fmkZtbRj3ux(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ຋")][DpRJnas65uVcO0S17dYG(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫຌ")][-UD4N8MjVTd][yRWQMHxZEz0(u"ࠨࡷࡵࡰࠬຍ")]
				except: pass
		for lPw8LujCTi2WOmzp,SVIUhc36CG5njDL,title,oqF5GjVvYXpBd1l2xmWL0n3kU in J6OrVEP1vmlipSu4F:
			P1euOgwZtcKn2MfAj38rs.append(title) ; HDLe9NtWfh14JujBsUiG.append(xdSThjYnuHXAU6M(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪຎ"))
		if oopT15NyrwJEKhGVD4smeMcBb92: P1euOgwZtcKn2MfAj38rs.append(kPCxIUZb1V(u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬຏ")) ; HDLe9NtWfh14JujBsUiG.append(kPCxIUZb1V(u"ࠫࡲࡻࡸࡦࡦࠪຐ"))
		if EZSHGdl2LjrPts1FKTcBhRxp: P1euOgwZtcKn2MfAj38rs.append(MFhbWia58mP3su0fk2d(u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩຑ")) ; HDLe9NtWfh14JujBsUiG.append(VhqD3zp7mUieI8sMQlETH(u"࠭ࡡ࡭࡮ࠪຒ"))
		if j6j8K4zoaNWxBmERUFMP: P1euOgwZtcKn2MfAj38rs.append(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬຓ")) ; HDLe9NtWfh14JujBsUiG.append(bQGafNLXyFgsZP6ut(u"ࠨࡤ࡬ࡲࡩ࠭ດ"))
		if xL5DtO2ioeFYkIcTbAXVmB9pMZy1Qz: P1euOgwZtcKn2MfAj38rs.append(yRWQMHxZEz0(u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩຕ")) ; HDLe9NtWfh14JujBsUiG.append(xdSThjYnuHXAU6M(u"ࠪࡺ࡮ࡪࡥࡰࠩຖ"))
		if N2DybpPZUoXg1f54MaWGILntxuSF0: P1euOgwZtcKn2MfAj38rs.append(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫທ")) ; HDLe9NtWfh14JujBsUiG.append(weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡧࡵࡥ࡫ࡲࠫຘ"))
		while y0yvdNOZkiKEg5RLMhoDVQAB9F2:
			EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(BjJhnCpduR497sfKZ,P1euOgwZtcKn2MfAj38rs)
			if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd: return VhqD3zp7mUieI8sMQlETH(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫນ"),[],[]
			elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==wTLFCOcM26fmYlW7U and n8uSs0idgJzy6Fx:
				hhEH1rcSP0z6Bkqy8OD = HDLe9NtWfh14JujBsUiG[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
				Rce9KaHhLg73QAOPMVE = Sph0cr2ZWK1atAUw5CTuxoe.argv[wTLFCOcM26fmYlW7U]+xm6jK1ZMuWq5(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧບ")+vvLTYxVfrbDza(n8uSs0idgJzy6Fx)+A6Sg45ChDR3BJLYfFH(u"ࠨࠨࡸࡶࡱࡃࠧປ")+hhEH1rcSP0z6Bkqy8OD
				if iinhqBP3exTWlZzLwQyOGcafY0d1g: Rce9KaHhLg73QAOPMVE = Rce9KaHhLg73QAOPMVE+DpRJnas65uVcO0S17dYG(u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪຜ")+vvLTYxVfrbDza(iinhqBP3exTWlZzLwQyOGcafY0d1g)
				te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(jQv0du1iVxTgAXCM(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢຝ")+Rce9KaHhLg73QAOPMVE+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠦ࠮ࠨພ"))
				return erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪຟ"),[],[]
			dcDaPVjr5uyEntR4HFqSb = HDLe9NtWfh14JujBsUiG[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
			g4pkhBVfRTnoD = P1euOgwZtcKn2MfAj38rs[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
			if dcDaPVjr5uyEntR4HFqSb==xdSThjYnuHXAU6M(u"࠭ࡤࡢࡵ࡫ࠫຠ"):
				u6bpM7e5qtQmwzISUVTXPyKnHYi2F = cML3BySIYkrgsxi2a1TZv4j
				break
			elif dcDaPVjr5uyEntR4HFqSb in [fmkZtbRj3ux(u"ࠧࡢࡷࡧ࡭ࡴ࠭ມ"),bQGafNLXyFgsZP6ut(u"ࠨࡸ࡬ࡨࡪࡵࠧຢ"),Gj3rMP1Cb8wHdp49la0(u"ࠩࡰࡹࡽ࡫ࡤࠨຣ")]:
				if dcDaPVjr5uyEntR4HFqSb==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡱࡺࡾࡥࡥࠩ຤"): Eu8LWnSt3fyJzIC,BZNRHamdYCuG0hO5ixJKtX4D7v = oopT15NyrwJEKhGVD4smeMcBb92,GelWOrcPYkvTn2Azy9UN4jJt6S5
				elif dcDaPVjr5uyEntR4HFqSb==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫࡻ࡯ࡤࡦࡱࠪລ"): Eu8LWnSt3fyJzIC,BZNRHamdYCuG0hO5ixJKtX4D7v = xL5DtO2ioeFYkIcTbAXVmB9pMZy1Qz,zdFvhxE0Mt8bLA3qHsmI5PRkYpj
				elif dcDaPVjr5uyEntR4HFqSb==vWNRusF46D7Mi8GpZ(u"ࠬࡧࡵࡥ࡫ࡲࠫ຦"): Eu8LWnSt3fyJzIC,BZNRHamdYCuG0hO5ixJKtX4D7v = N2DybpPZUoXg1f54MaWGILntxuSF0,O6jayuSf5JDkRqI3FzXewGPBT1bY
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(bQGafNLXyFgsZP6ut(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬວ")+str(len(Eu8LWnSt3fyJzIC))+A6Sg45ChDR3BJLYfFH(u"ࠧࠡ็็ๅ࠮࠭ຨ"),Eu8LWnSt3fyJzIC)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq!=-UD4N8MjVTd:
					u6bpM7e5qtQmwzISUVTXPyKnHYi2F = BZNRHamdYCuG0hO5ixJKtX4D7v[EcQws7L35GvtIpl0k1gJZWTNPDbmMq][xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡷࡵࡰࠬຩ")]
					g4pkhBVfRTnoD = Eu8LWnSt3fyJzIC[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					break
			elif dcDaPVjr5uyEntR4HFqSb==TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡥ࡭ࡳࡪࠧສ"):
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(xdSThjYnuHXAU6M(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࠦࠨࠨຫ")+str(len(j6j8K4zoaNWxBmERUFMP))+bQGafNLXyFgsZP6ut(u"๋ࠫࠥไโࠫࠪຬ"),j6j8K4zoaNWxBmERUFMP)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq!=-UD4N8MjVTd:
					g4pkhBVfRTnoD = j6j8K4zoaNWxBmERUFMP[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					G18Hmu5dLXEDl60 = aAfcIX9eMrQpTRwysOdh58[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(kPCxIUZb1V(u"ࠬอฮหำࠣะํีษࠡษ็ูํะࠠࠩࠩອ")+str(len(nbBXPW5p19qmfhD4i))+jQv0du1iVxTgAXCM(u"࠭ࠠๆๆไ࠭ࠬຮ"),nbBXPW5p19qmfhD4i)
					if EcQws7L35GvtIpl0k1gJZWTNPDbmMq!=-UD4N8MjVTd:
						g4pkhBVfRTnoD += rDG9dZoXRhCJcieUSF0KB(u"ࠧࠡ࠭ࠣࠫຯ")+nbBXPW5p19qmfhD4i[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
						XPDyqAgQuUl4xNOrHm8BbcGLC = zRBawxWOYjrD[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
						JncmOQ8obj3q = y0yvdNOZkiKEg5RLMhoDVQAB9F2
						break
			elif dcDaPVjr5uyEntR4HFqSb==s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡣ࡯ࡰࠬະ"):
				xGJy6wtMoUfQ5V4,CzS5a2hxVsbyIiLBHuDNKpA91kcO,A2heqkTxyLV5nRuF,vNXUzJr6tqyFDcTua5 = list(zip(*EZSHGdl2LjrPts1FKTcBhRxp))
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(Gj3rMP1Cb8wHdp49la0(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨັ")+str(len(A2heqkTxyLV5nRuF))+w8JC1y7Lp3(u"ࠪࠤ๊๊แࠪࠩາ"),A2heqkTxyLV5nRuF)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq!=-UD4N8MjVTd:
					g4pkhBVfRTnoD = A2heqkTxyLV5nRuF[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					G18Hmu5dLXEDl60 = xGJy6wtMoUfQ5V4[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					if kPCxIUZb1V(u"ࠫࡧ࡯࡮ࡥࠩຳ") in A2heqkTxyLV5nRuF[EcQws7L35GvtIpl0k1gJZWTNPDbmMq] and G18Hmu5dLXEDl60[lCT8hfYUBX4OQMmL(u"ࠬࡻࡲ࡭ࠩິ")]!=cML3BySIYkrgsxi2a1TZv4j:
						XPDyqAgQuUl4xNOrHm8BbcGLC = CzS5a2hxVsbyIiLBHuDNKpA91kcO[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
						JncmOQ8obj3q = y0yvdNOZkiKEg5RLMhoDVQAB9F2
					else: u6bpM7e5qtQmwzISUVTXPyKnHYi2F = G18Hmu5dLXEDl60[DpRJnas65uVcO0S17dYG(u"࠭ࡵࡳ࡮ࠪີ")]
					break
			elif dcDaPVjr5uyEntR4HFqSb==jQv0du1iVxTgAXCM(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨຶ"):
				xGJy6wtMoUfQ5V4,CzS5a2hxVsbyIiLBHuDNKpA91kcO,A2heqkTxyLV5nRuF,vNXUzJr6tqyFDcTua5 = list(zip(*J6OrVEP1vmlipSu4F))
				G18Hmu5dLXEDl60 = xGJy6wtMoUfQ5V4[EcQws7L35GvtIpl0k1gJZWTNPDbmMq-HZcKGP6yrvs7wBCYomXLVF3aq4fUQ]
				if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡤ࡬ࡲࡩ࠭ື") in A2heqkTxyLV5nRuF[EcQws7L35GvtIpl0k1gJZWTNPDbmMq-HZcKGP6yrvs7wBCYomXLVF3aq4fUQ] and G18Hmu5dLXEDl60[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡸࡶࡱຸ࠭")]!=cML3BySIYkrgsxi2a1TZv4j:
					XPDyqAgQuUl4xNOrHm8BbcGLC = CzS5a2hxVsbyIiLBHuDNKpA91kcO[EcQws7L35GvtIpl0k1gJZWTNPDbmMq-HZcKGP6yrvs7wBCYomXLVF3aq4fUQ]
					JncmOQ8obj3q = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				else: u6bpM7e5qtQmwzISUVTXPyKnHYi2F = G18Hmu5dLXEDl60[fmkZtbRj3ux(u"ࠪࡹࡷࡲູࠧ")]
				g4pkhBVfRTnoD = A2heqkTxyLV5nRuF[EcQws7L35GvtIpl0k1gJZWTNPDbmMq-HZcKGP6yrvs7wBCYomXLVF3aq4fUQ]
				break
	FFwVakdM8NvjeJRK3oyQI9ti24,nehcBg4qAl9mGNPZ2MbW7dr5,xoID8Nw0G9X = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if JncmOQ8obj3q:
		z2n3Nc6IVsQB9rPHJFU = G18Hmu5dLXEDl60[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡺࡸ࡬ࠨ຺")].replace(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࠬࠧົ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࠦࡢ࡯ࡳ࠿ࠬຼ"))
		jRpGu3QWHAnBasiZ = XPDyqAgQuUl4xNOrHm8BbcGLC[VhqD3zp7mUieI8sMQlETH(u"ࠧࡶࡴ࡯ࠫຽ")].replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࠨࠪ຾"),Gj3rMP1Cb8wHdp49la0(u"ࠩࠩࡥࡲࡶ࠻ࠨ຿"))
		cQRG2kmxj6ErvDw9yMliXLS5toaAT = G18Hmu5dLXEDl60[TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡧࡴࡪࡥࡤࡵࠪເ")]
		if G18Hmu5dLXEDl60[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ແ")]==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡳ࠳ࡶ࠺ࠪໂ") or XPDyqAgQuUl4xNOrHm8BbcGLC[w8JC1y7Lp3(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨໃ")]==erqDsJmL3BQHuGtPkcf0X9(u"ࠧ࡮࠵ࡸ࠼ࠬໄ"):
			rgNkiToc6MRPtULJ8BG = erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻ࠸ࠨ໅")
			xoID8Nw0G9X  = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࠦࠫໆ")+bQGafNLXyFgsZP6ut(u"ࠪࡉ࡝࡚ࡍ࠴ࡗ࡟ࡲࠬ໇")+llkFwuCyhaP3sK76qO4T(u"ࠫࠨ່࠭")+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡋࡘࡕ࠯࡛࠱࡛ࡋࡒࡔࡋࡒࡒ࠿࠹࡜࡯້ࠩ")
			xoID8Nw0G9X += A6Sg45ChDR3BJLYfFH(u"࠭ࠣࠨ໊")+VhqD3zp7mUieI8sMQlETH(u"ࠧࡆ࡚ࡗ࠱࡝࠳ࡍࡆࡆࡌࡅ࠿࡚࡙ࡑࡇࡀࡅ࡚ࡊࡉࡐ࠮ࡊࡖࡔ࡛ࡐ࠮ࡋࡇࡁࠧࡧࡡࠣ࠮ࡑࡅࡒࡋ࠽ࠣࡣࠥ࠰ࡉࡋࡆࡂࡗࡏࡘࡂ࡟ࡅࡔ࠮ࡄ࡙࡙ࡕࡓࡆࡎࡈࡇ࡙ࡃ࡙ࡆࡕ࠯࡙ࡗࡏ࠽ࠣࠧࡶࠦࡡࡴ໋ࠧ") % jRpGu3QWHAnBasiZ
			xoID8Nw0G9X += MFhbWia58mP3su0fk2d(u"ࠨࠥࠪ໌")+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿ࡈࡁࡏࡆ࡚ࡍࡉ࡚ࡈ࠾࠳࠯ࡅ࡚ࡊࡉࡐ࠿ࠥࡥࡦࠨ࡜࡯ࠧࡶࡠࡳ࠭ໍ") % z2n3Nc6IVsQB9rPHJFU
		else:
			hdiHtSL6eM1XE = int(G18Hmu5dLXEDl60[s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ໎")])
			stB3Z6Jx8zVWEH = int(XPDyqAgQuUl4xNOrHm8BbcGLC[bQGafNLXyFgsZP6ut(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭໏")])
			KS5UPc7G4x38Lp = str(max(hdiHtSL6eM1XE,stB3Z6Jx8zVWEH))
			rgNkiToc6MRPtULJ8BG = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠮࡮ࡲࡧࠫ໐")
			xoID8Nw0G9X  = vWNRusF46D7Mi8GpZ(u"࠭࠼ࡎࡒࡇࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࠤࡲ࡫ࡤࡪࡣࡓࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࡅࡷࡵࡥࡹ࡯࡯࡯࠿ࠥࡔ࡙ࠫࡳࡔࠤࡁࡠࡳ࠭໑") % KS5UPc7G4x38Lp
			xoID8Nw0G9X += llkFwuCyhaP3sK76qO4T(u"ࠧࠡࠢ࠿ࡔࡪࡸࡩࡰࡦࠣ࡭ࡩࡃࠢࡷ࠭ࡤࠦࡃࡢ࡮ࠨ໒")
			xoID8Nw0G9X += SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࠢࠣࠤࠥࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠧࡶࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠥࡴࠤࠣࡷࡹࡧࡲࡵ࡙࡬ࡸ࡭࡙ࡁࡑ࠿ࠥ࠵ࠧࠦࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ໓") % (G18Hmu5dLXEDl60[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ໔")], G18Hmu5dLXEDl60[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡧࡴࡪࡥࡤࡵࠪ໕")])
			xoID8Nw0G9X += gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࠥࠦࠠࠡࠢࠣࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࡹ࠵ࠧࡄ࡜࡯ࠩ໖")
			xoID8Nw0G9X += A6Sg45ChDR3BJLYfFH(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦ࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠧࡶࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ໗") % z2n3Nc6IVsQB9rPHJFU
			if Gj3rMP1Cb8wHdp49la0(u"࠭ࡩ࡯ࡦࡨࡼࠬ໘") in G18Hmu5dLXEDl60 and TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡪࡰ࡬ࡸࠬ໙") in G18Hmu5dLXEDl60:
				xoID8Nw0G9X += w8JC1y7Lp3(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠥࡴࠤࡁࡠࡳ࠭໚") % G18Hmu5dLXEDl60[kPCxIUZb1V(u"ࠩ࡬ࡲࡩ࡫ࡸࠨ໛")]
				xoID8Nw0G9X += lCT8hfYUBX4OQMmL(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠧࡶࠦ࠴ࡄ࡜࡯ࠩໜ") % G18Hmu5dLXEDl60[rDG9dZoXRhCJcieUSF0KB(u"ࠫ࡮ࡴࡩࡵࠩໝ")]
				xoID8Nw0G9X += Gj3rMP1Cb8wHdp49la0(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦ࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩໞ")
			else:
				xoID8Nw0G9X += VhqD3zp7mUieI8sMQlETH(u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦ࠵࠳࠰ࠣࡀ࡟ࡲࠬໟ")
				xoID8Nw0G9X += vWNRusF46D7Mi8GpZ(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠶࠭࠱ࠤ࠲ࡂࡡࡴࠧ໠")
				xoID8Nw0G9X += w8JC1y7Lp3(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ໡")
			xoID8Nw0G9X += vWNRusF46D7Mi8GpZ(u"ࠩࠣࠤࠥࠦࠠࠡ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ໢")
			xoID8Nw0G9X += w8JC1y7Lp3(u"ࠪࠤࠥࠦࠠ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ໣")
			xoID8Nw0G9X += DpRJnas65uVcO0S17dYG(u"ࠫࠥࠦࠠࠡ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡧࡵࡥ࡫ࡲ࠳ࠪࡹࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠨࡷࠧࠦࡳࡵࡣࡵࡸ࡜࡯ࡴࡩࡕࡄࡔࡂࠨ࠱ࠣࠢࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ໤") % (XPDyqAgQuUl4xNOrHm8BbcGLC[vWNRusF46D7Mi8GpZ(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ໥")], XPDyqAgQuUl4xNOrHm8BbcGLC[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡣࡰࡦࡨࡧࡸ࠭໦")])
			xoID8Nw0G9X += TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡࠢࠣࠤࠥࠦ࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧࡧ࠱ࠣࡀ࡟ࡲࠬ໧")
			xoID8Nw0G9X += jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠪࡹ࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ໨") % jRpGu3QWHAnBasiZ
			if it4DKnryZlx(u"ࠩ࡬ࡲࡩ࡫ࡸࠨ໩") in XPDyqAgQuUl4xNOrHm8BbcGLC and kPCxIUZb1V(u"ࠪ࡭ࡳ࡯ࡴࠨ໪") in XPDyqAgQuUl4xNOrHm8BbcGLC:
				xoID8Nw0G9X += rDG9dZoXRhCJcieUSF0KB(u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠨࡷࠧࡄ࡜࡯ࠩ໫") % XPDyqAgQuUl4xNOrHm8BbcGLC[weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࡯࡮ࡥࡧࡻࠫ໬")]
				xoID8Nw0G9X += pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠪࡹࠢ࠰ࡀ࡟ࡲࠬ໭") % XPDyqAgQuUl4xNOrHm8BbcGLC[A6Sg45ChDR3BJLYfFH(u"ࠧࡪࡰ࡬ࡸࠬ໮")]
				xoID8Nw0G9X += DpRJnas65uVcO0S17dYG(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ໯")
			else:
				xoID8Nw0G9X += jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࠣࠤࠥࠦࠠࠡࠢࠣࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢ࠱࠯࠳ࠦࡃࡢ࡮ࠨ໰")
				xoID8Nw0G9X += w8JC1y7Lp3(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣ࠲࠰࠴ࠧ࠵࠾࡝ࡰࠪ໱")
				xoID8Nw0G9X += MFhbWia58mP3su0fk2d(u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ໲")
			xoID8Nw0G9X += Gj3rMP1Cb8wHdp49la0(u"ࠬࠦࠠࠡࠢࠣࠤࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ໳")
			xoID8Nw0G9X += DpRJnas65uVcO0S17dYG(u"࠭ࠠࠡࠢࠣࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ໴")
			xoID8Nw0G9X += jQv0du1iVxTgAXCM(u"ࠧࠡࠢ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴ࠼࠰ࡏࡓࡈࡃࡢ࡮ࠨ໵")
		u6bpM7e5qtQmwzISUVTXPyKnHYi2F = A6Sg45ChDR3BJLYfFH(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠾࠿࠰࠺࠻࠲ࠫ໶")+rgNkiToc6MRPtULJ8BG
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: wIe7WOENZo6mXnHtCcLflBb,qsuvACN64bHSe = wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࡟ࡸࠬ໷")
	else: wIe7WOENZo6mXnHtCcLflBb,qsuvACN64bHSe = bQGafNLXyFgsZP6ut(u"ࠪࡠࡹ࠭໸"),wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not JncmOQ8obj3q: n6vPjWlsBgfAhTZiaqdIk = wIe7WOENZo6mXnHtCcLflBb+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡆ࠱ࡖ࠻ࠢ࡞ࠤࠬ໹")+QEbx35yvreoT2sPDG4k9Fcfa8Z(u6bpM7e5qtQmwzISUVTXPyKnHYi2F)+JHMxIE4fs1mvQtKW7R(u"ࠬࠦ࡝ࠨ໺")
	else: n6vPjWlsBgfAhTZiaqdIk = wIe7WOENZo6mXnHtCcLflBb+yRWQMHxZEz0(u"࠭ࡁࡶࡦ࡬ࡳ࠿࡛ࠦࠡࠩ໻")+QEbx35yvreoT2sPDG4k9Fcfa8Z(jRpGu3QWHAnBasiZ)+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡ࡟࡟ࡲࡡࡺ࡜ࡵࠩ໼")+qsuvACN64bHSe+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ໽")+QEbx35yvreoT2sPDG4k9Fcfa8Z(z2n3Nc6IVsQB9rPHJFU)+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࠣࡡࠬ໾")
	KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡠࡹࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡵࡴࡨࡥࡲࡀࠠ࡜ࠢࠪ໿")+g4pkhBVfRTnoD+TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࠥࡣࠠࠡࠢࠪༀ")+n6vPjWlsBgfAhTZiaqdIk)
	if not u6bpM7e5qtQmwzISUVTXPyKnHYi2F: return vWNRusF46D7Mi8GpZ(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ༁"),[],[]
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,[g4pkhBVfRTnoD],[[u6bpM7e5qtQmwzISUVTXPyKnHYi2F,ddK3lsEzy4,xoID8Nw0G9X]]
def tdoP4CwKcAy75Jvl(url):
	headers = { bQGafNLXyFgsZP6ut(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ༂") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ༃"))
	items = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ༄"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	items = set(items)
	items = sorted(items, reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2, key=lambda key: key[Tb7oymMnpflsSv3eu4Pz2])
	VUsLcf1yqFrxn5HQM,Eu8LWnSt3fyJzIC,tbpP1Z9dNE,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[],[],[]
	if not items: return it4DKnryZlx(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ༅"),[],[]
	for hhEH1rcSP0z6Bkqy8OD,vziHL4xVFSD81W7X9Noyrdjb,JrzealiFtp6 in items:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(llkFwuCyhaP3sK76qO4T(u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ༆"),kPCxIUZb1V(u"ࠫ࡭ࡺࡴࡱ࠼ࠪ༇"))
		if bQGafNLXyFgsZP6ut(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ༈") in hhEH1rcSP0z6Bkqy8OD:
			VUsLcf1yqFrxn5HQM,tbpP1Z9dNE = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,hhEH1rcSP0z6Bkqy8OD)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL + tbpP1Z9dNE
			if VUsLcf1yqFrxn5HQM[wTLFCOcM26fmYlW7U]==kPCxIUZb1V(u"࠭࠭࠲ࠩ༉"): Eu8LWnSt3fyJzIC.append(fmkZtbRj3ux(u"ࠧิ์ิๅึࠦฮศืࠪ༊")+it4DKnryZlx(u"ࠨࠢࠣࠤࡲ࠹ࡵ࠹ࠩ་"))
			else:
				for title in VUsLcf1yqFrxn5HQM:
					Eu8LWnSt3fyJzIC.append(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩึ๎ึ็ัࠡะสูࠬ༌")+DQCpAXVq6LHJ0aEFR+title)
		else:
			title = erqDsJmL3BQHuGtPkcf0X9(u"ࠪื๏ืแาࠢัหฺ࠭།")+vWNRusF46D7Mi8GpZ(u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ༎")+JrzealiFtp6
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			Eu8LWnSt3fyJzIC.append(title)
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
def M7vhoWYQOFSmD0GIycR(url,II64TLxj3mbqEyh9pHQ8oAv):
	hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO,m6b9gt5SuMoJxEAaFVW3zKO4iUc,s7s0wmIdLNrB9Vl5n,ppAJI9kDbz5MXa76UEF = [],[],[],[],[]
	if not isinstance(II64TLxj3mbqEyh9pHQ8oAv,str): II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ༏"))
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༐"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD and not rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]): hhEH1rcSP0z6Bkqy8OD = []
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(kPCxIUZb1V(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭༑"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD and not rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]): hhEH1rcSP0z6Bkqy8OD = []
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall(w8JC1y7Lp3(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༒"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD and not rjZFa0VMBuPRHg1cIYJpd52oxl4(hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]): hhEH1rcSP0z6Bkqy8OD = []
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[wTLFCOcM26fmYlW7U]
		title = hhEH1rcSP0z6Bkqy8OD.rsplit(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࠱ࠫ༓"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠳ဏ"))[UD4N8MjVTd]
		hUXDz2SbBuqmKe6QJO.append(title)
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	else:
		qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall(kPCxIUZb1V(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰ࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪࠩ༔"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not qqtR56dgVLh3Tr2: qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡻࡧࡲࠡࡵࡲࡹࡷࡩࡥࡴࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧ༕"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not qqtR56dgVLh3Tr2: qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall(weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡼࡡࡳࠢ࡭ࡻࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ༖"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not qqtR56dgVLh3Tr2: qqtR56dgVLh3Tr2 = jj0dZrgiKb.findall(yRWQMHxZEz0(u"࠭ࡶࡢࡴࠣࡴࡱࡧࡹࡦࡴࠣࡁࠥ࠴ࠪࡀ࡞ࠫࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮ࡢࠩࠨ༗"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if qqtR56dgVLh3Tr2:
			qqtR56dgVLh3Tr2 = qqtR56dgVLh3Tr2[wTLFCOcM26fmYlW7U]
			qqtR56dgVLh3Tr2 = jj0dZrgiKb.sub(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࡲࠨࠪ࡞ࡠࢀࡢࠬ࡞࡝࡟ࡸࡡࡹ࡜࡯࡞ࡵࡡ࠯࠯ࠨ࡝ࡹ࠮࡟ࡡࡺ࡜ࡴ࡟࠭࠭࠿༘࠭"),D2PpKMeZFWrmfxTSs4L1tz(u"ࡳࠩ࡟࠵ࠧࡢ࠲ࠣ࠼༙ࠪ"),qqtR56dgVLh3Tr2)
			qqtR56dgVLh3Tr2 = dm7KA8MukvxF3iH9CW2ZNc(s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡧ࡭ࡨࡺࠧ༚"),qqtR56dgVLh3Tr2)
			if isinstance(qqtR56dgVLh3Tr2,dict): qqtR56dgVLh3Tr2 = [qqtR56dgVLh3Tr2]
			for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
				ay7K4O0IN1h,hhEH1rcSP0z6Bkqy8OD = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
				if isinstance(IJE2xcV7OWauUKhfik56gXBwltCb,dict):
					if   TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡸࡾࡶࡥࠨ༛") in IJE2xcV7OWauUKhfik56gXBwltCb: ay7K4O0IN1h = str(IJE2xcV7OWauUKhfik56gXBwltCb[jQv0du1iVxTgAXCM(u"ࠫࡹࡿࡰࡦࠩ༜")])
					if   yRWQMHxZEz0(u"ࠬ࡬ࡩ࡭ࡧࠪ༝") in IJE2xcV7OWauUKhfik56gXBwltCb: hhEH1rcSP0z6Bkqy8OD = IJE2xcV7OWauUKhfik56gXBwltCb[VhqD3zp7mUieI8sMQlETH(u"࠭ࡦࡪ࡮ࡨࠫ༞")]
					elif jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡩ࡮ࡶࠫ༟") in IJE2xcV7OWauUKhfik56gXBwltCb: hhEH1rcSP0z6Bkqy8OD = IJE2xcV7OWauUKhfik56gXBwltCb[MFhbWia58mP3su0fk2d(u"ࠨࡪ࡯ࡷࠬ༠")]
					elif pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡶࡶࡨ࠭༡") in IJE2xcV7OWauUKhfik56gXBwltCb: hhEH1rcSP0z6Bkqy8OD = IJE2xcV7OWauUKhfik56gXBwltCb[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡷࡷࡩࠧ༢")]
					if   bQGafNLXyFgsZP6ut(u"ࠫࡱࡧࡢࡦ࡮ࠪ༣") in IJE2xcV7OWauUKhfik56gXBwltCb: title = str(IJE2xcV7OWauUKhfik56gXBwltCb[kPCxIUZb1V(u"ࠬࡲࡡࡣࡧ࡯ࠫ༤")])
					elif xdSThjYnuHXAU6M(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬ༥") in IJE2xcV7OWauUKhfik56gXBwltCb: title = str(IJE2xcV7OWauUKhfik56gXBwltCb[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭༦")])
					elif ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࠰ࠪ༧") in hhEH1rcSP0z6Bkqy8OD: title = hhEH1rcSP0z6Bkqy8OD.rsplit(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩ࠱ࠫ༨"),UD4N8MjVTd)[UD4N8MjVTd]
					else: title = hhEH1rcSP0z6Bkqy8OD
				elif isinstance(IJE2xcV7OWauUKhfik56gXBwltCb,str):
					hhEH1rcSP0z6Bkqy8OD = IJE2xcV7OWauUKhfik56gXBwltCb
					title = hhEH1rcSP0z6Bkqy8OD.rsplit(VhqD3zp7mUieI8sMQlETH(u"ࠪ࠲ࠬ༩"),UD4N8MjVTd)[UD4N8MjVTd]
				if UD4N8MjVTd:
					hUXDz2SbBuqmKe6QJO.append(title+lB8tuyg6sxkDVYAaS95K3GI+ay7K4O0IN1h)
					jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	for hhEH1rcSP0z6Bkqy8OD,title in list(zip(jcInvNf98TZ5gRUDFp40li2uzVPrO,hUXDz2SbBuqmKe6QJO)):
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(yRWQMHxZEz0(u"ࠫࡡࡢ࠯ࠨ༪"),llkFwuCyhaP3sK76qO4T(u"ࠬ࠵ࠧ༫"))
		xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,w8JC1y7Lp3(u"࠭ࡵࡳ࡮ࠪ༬"))
		vpHXP3E6Kt = ZZIDf1A9vE0g86RMq7tpKUrzaij()
		if xm6jK1ZMuWq5(u"ࠧࡩࡶࡷࡴࠬ༭") not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = xG6n4Wq2Ib7YgpiarHUNLQJM0+hhEH1rcSP0z6Bkqy8OD
		if JHMxIE4fs1mvQtKW7R(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ༮") in hhEH1rcSP0z6Bkqy8OD:
			headers = {Gj3rMP1Cb8wHdp49la0(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭༯"):vpHXP3E6Kt,vWNRusF46D7Mi8GpZ(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ༰"):xG6n4Wq2Ib7YgpiarHUNLQJM0}
			RqyCFAS28jL3zvHsgcJm,rrljg86ox1nOHMbcyEp20kFvfZ = kjJQbScq69aO4Ko(UdbRGoKhcDeI4lVfns5,hhEH1rcSP0z6Bkqy8OD,headers)
			s7s0wmIdLNrB9Vl5n += rrljg86ox1nOHMbcyEp20kFvfZ
			m6b9gt5SuMoJxEAaFVW3zKO4iUc += RqyCFAS28jL3zvHsgcJm
		else:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+yRWQMHxZEz0(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ༱")+vpHXP3E6Kt+Gj3rMP1Cb8wHdp49la0(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ༲")+xG6n4Wq2Ib7YgpiarHUNLQJM0
			s7s0wmIdLNrB9Vl5n.append(hhEH1rcSP0z6Bkqy8OD)
			m6b9gt5SuMoJxEAaFVW3zKO4iUc.append(title)
	JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	if s7s0wmIdLNrB9Vl5n: JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO = wUvcPrYDfISbZolAm83GKEqMyXkn5,m6b9gt5SuMoJxEAaFVW3zKO4iUc,s7s0wmIdLNrB9Vl5n
	else:
		if s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠼ࠨ༳") not in II64TLxj3mbqEyh9pHQ8oAv and len(II64TLxj3mbqEyh9pHQ8oAv)<yRWQMHxZEz0(u"࠴࠴࠵တ") and II64TLxj3mbqEyh9pHQ8oAv: JCxwmazEp2i5eGIZt1 = II64TLxj3mbqEyh9pHQ8oAv
		else:
			msg = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠧ࠽ࡦ࡬ࡺࠥࡹࡴࡺ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬࡋ࡯࡬ࡦ࠰࠭ࡃ࠮ࡂࠧ༴"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if not msg: msg = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡱࡡࡹ࡭ࡩ࡫࡯ࡠࡵࡷࡹࡧࡥࡴࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿༵ࠫ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if not msg: msg = jj0dZrgiKb.findall(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࠿࡬࠷ࡄࠨࡔࡱࡵࡶࡾ࠴ࠪࡀࠫ࠿ࠫ༶"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if msg: JCxwmazEp2i5eGIZt1 = msg[wTLFCOcM26fmYlW7U]
	return JCxwmazEp2i5eGIZt1,hUXDz2SbBuqmKe6QJO,jcInvNf98TZ5gRUDFp40li2uzVPrO
def RhbIqFn0aeOC(RY4pAuq5J1wDM7mZfadxtlNvXOL,url):
	global GS1YL8RzTv4ZsdE5Cel
	url = url.strip(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ࠳༷ࠬ"))
	Qid14qxXSvtI0ayfKuboj,COW137cpIhBMYTSiAR9s2Dlzw = wUvcPrYDfISbZolAm83GKEqMyXkn5,{}
	headers = {ZiCLpR1Tc5vUlPXDWgmhM6j(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ༸"):ZZIDf1A9vE0g86RMq7tpKUrzaij()}
	headers[s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡘࡥࡧࡧࡵࡩࡷ༹࠭")] = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,JHMxIE4fs1mvQtKW7R(u"࠭ࡵࡳ࡮ࠪ༺"))
	headers[DpRJnas65uVcO0S17dYG(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ༻")] = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡧࡱ࠰ࡦࡸ࠻ࡲ࠿࠳࠲࠾࠭༼")
	headers[jQv0du1iVxTgAXCM(u"ࠩࡖࡩࡨ࠳ࡆࡦࡶࡦ࡬࠲ࡊࡥࡴࡶࠪ༽")] = DpRJnas65uVcO0S17dYG(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪ༾")
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡌࡋࡔࠨ༿"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧཀ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	MWgcRfQz6ymptSxB = QM9sJ7tk0oplqEwHU3DjL64d.code
	if not isinstance(II64TLxj3mbqEyh9pHQ8oAv,str): II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,yRWQMHxZEz0(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ཁ"))
	if it4DKnryZlx(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭ག") in II64TLxj3mbqEyh9pHQ8oAv:
		aa3thUFYxDiPv = jj0dZrgiKb.findall(JHMxIE4fs1mvQtKW7R(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫགྷ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if aa3thUFYxDiPv:
			try: Qid14qxXSvtI0ayfKuboj = z69zaGtMRNJrmihgjv25O1dUpYlVf(aa3thUFYxDiPv[wTLFCOcM26fmYlW7U])
			except: Qid14qxXSvtI0ayfKuboj = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳࠫࠪང") in II64TLxj3mbqEyh9pHQ8oAv:
		aa3thUFYxDiPv = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪཅ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if aa3thUFYxDiPv:
			try: Qid14qxXSvtI0ayfKuboj = CCFGtogTOQY(aa3thUFYxDiPv[wTLFCOcM26fmYlW7U])
			except: Qid14qxXSvtI0ayfKuboj = wUvcPrYDfISbZolAm83GKEqMyXkn5
	xnGN2vER8iQqJkcFt4KWup = II64TLxj3mbqEyh9pHQ8oAv+Qid14qxXSvtI0ayfKuboj
	if D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࠧ࡯ࡤ࠳ࠤࠪཆ") in xnGN2vER8iQqJkcFt4KWup or JHMxIE4fs1mvQtKW7R(u"ࠬࠨࡩࡥࠤࠪཇ") in xnGN2vER8iQqJkcFt4KWup:
		tRlq8GP5mTd = url.split(weh7SGmuTgXOVRcMo1rlLq(u"࠭࠯ࠨ཈"))[MMRBkhnWVJCQwU].replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧཉ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(Gj3rMP1Cb8wHdp49la0(u"ࠨ࠰࡫ࡸࡲࡲࠧཊ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࠥ࡭ࡩ࠸ࠢࠨཋ") in xnGN2vER8iQqJkcFt4KWup: COW137cpIhBMYTSiAR9s2Dlzw = {xdSThjYnuHXAU6M(u"ࠪ࡭ࡩ࠸ࠧཌ"):tRlq8GP5mTd,Gj3rMP1Cb8wHdp49la0(u"ࠫࡴࡶࠧཌྷ"):fmkZtbRj3ux(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨཎ")}
		elif xdSThjYnuHXAU6M(u"࠭ࠢࡪࡦࠥࠫཏ") in xnGN2vER8iQqJkcFt4KWup: COW137cpIhBMYTSiAR9s2Dlzw = {SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡪࡦࠪཐ"):tRlq8GP5mTd,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡱࡳࠫད"):weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬདྷ")}
		XubVRNO48BsjJASlmeKwdTCr = headers.copy()
		XubVRNO48BsjJASlmeKwdTCr[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩན")] = s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪཔ")
		toEMTSVjIO = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡖࡏࡔࡖࠪཕ"),url,COW137cpIhBMYTSiAR9s2Dlzw,XubVRNO48BsjJASlmeKwdTCr,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Gj3rMP1Cb8wHdp49la0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨབ"))
		xnGN2vER8iQqJkcFt4KWup = toEMTSVjIO.content
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = M7vhoWYQOFSmD0GIycR(url,xnGN2vER8iQqJkcFt4KWup)
	GS1YL8RzTv4ZsdE5Cel[RY4pAuq5J1wDM7mZfadxtlNvXOL] = JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,MWgcRfQz6ymptSxB
	return
GS1YL8RzTv4ZsdE5Cel,sXCnxeLA6gVf7citp2FT = {},wTLFCOcM26fmYlW7U
def JJdgojui8K40Xfz(url):
	global GS1YL8RzTv4ZsdE5Cel,sXCnxeLA6gVf7citp2FT
	sXCnxeLA6gVf7citp2FT += MFhbWia58mP3su0fk2d(u"࠵࠵࠶ထ")
	hwRD1FrpuXao = sXCnxeLA6gVf7citp2FT
	ppAJI9kDbz5MXa76UEF = [(UD4N8MjVTd,url)]
	ZD5n0eJivzWOMxY98dgrumkwRG = url.replace(kPCxIUZb1V(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨབྷ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨ࠱ࠪམ"))
	deg2JDUOioWfbC8NcswK1RFAlk4M = jj0dZrgiKb.findall(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧཙ"),ZD5n0eJivzWOMxY98dgrumkwRG+lCT8hfYUBX4OQMmL(u"ࠪ࠳ࠬཚ"),jj0dZrgiKb.DOTALL)
	try: start,ODTLNIwAXSk7vjaZmt0UysC,end = deg2JDUOioWfbC8NcswK1RFAlk4M[wTLFCOcM26fmYlW7U]
	except: return pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡖࡎࡗࡍࡤ࡞ࡓࡉࡃࡕࡍࡓࡍࠧཛ"),[],[]
	end = end.strip(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠵ࠧཛྷ"))
	mGl4VUho3RXgrqdw0DMC5Ou = len(ODTLNIwAXSk7vjaZmt0UysC)<R9RNUT6WAPEYjHqtIokxuXs or ODTLNIwAXSk7vjaZmt0UysC in [yRWQMHxZEz0(u"࠭ࡦࡪ࡮ࡨࠫཝ"),lCT8hfYUBX4OQMmL(u"ࠧࡷ࡫ࡧࡩࡴ࠭ཞ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡸ࡬ࡨࡪࡵࡥ࡮ࡤࡨࡨࠬཟ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡤ࡮ࡦࡾࠧའ"),fmkZtbRj3ux(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪཡ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡲ࡯ࡲࡳࡱࡵࠫར")]
	if not mGl4VUho3RXgrqdw0DMC5Ou: ppAJI9kDbz5MXa76UEF.append([Tb7oymMnpflsSv3eu4Pz2,start+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ལ")+ODTLNIwAXSk7vjaZmt0UysC+vWNRusF46D7Mi8GpZ(u"࠭࠯ࠨཤ")+end])
	if end: ppAJI9kDbz5MXa76UEF.append([MMRBkhnWVJCQwU,start+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࠰ࠩཥ")+ODTLNIwAXSk7vjaZmt0UysC+yRWQMHxZEz0(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩས")+end])
	if llkFwuCyhaP3sK76qO4T(u"ࠩ࠱࡬ࡹࡳ࡬ࠨཧ") in ODTLNIwAXSk7vjaZmt0UysC:
		sGEY0hXbUKWQfaForucDHkpM84nRwO = ODTLNIwAXSk7vjaZmt0UysC.replace(rDG9dZoXRhCJcieUSF0KB(u"ࠪ࠲࡭ࡺ࡭࡭ࠩཨ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		ppAJI9kDbz5MXa76UEF.append([R9RNUT6WAPEYjHqtIokxuXs,start+TNw1pBHb8CtSZe0EFxuJqI(u"ࠫ࠴࠭ཀྵ")+sGEY0hXbUKWQfaForucDHkpM84nRwO+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࠵ࠧཪ")+end])
		ppAJI9kDbz5MXa76UEF.append([fmkZtbRj3ux(u"࠺ဒ"),start+w8JC1y7Lp3(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧཫ")+sGEY0hXbUKWQfaForucDHkpM84nRwO+vvhR5ozeiJpANyl8fFO3GBw(u"ࠧ࠰ࠩཬ")+end])
		if end: ppAJI9kDbz5MXa76UEF.append([fmkZtbRj3ux(u"࠼ဓ"),start+DpRJnas65uVcO0S17dYG(u"ࠨ࠱ࠪ཭")+sGEY0hXbUKWQfaForucDHkpM84nRwO+yRWQMHxZEz0(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ཮")+end])
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ཯") in end:
		P4iudsX9hLG70 = end.replace(llkFwuCyhaP3sK76qO4T(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ཰"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		ppAJI9kDbz5MXa76UEF.append([jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷န"),start+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠵ཱࠧ")+ODTLNIwAXSk7vjaZmt0UysC+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠯ࠨི")+P4iudsX9hLG70])
		if not mGl4VUho3RXgrqdw0DMC5Ou: ppAJI9kDbz5MXa76UEF.append([dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠹ပ"),start+fmkZtbRj3ux(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨཱི")+ODTLNIwAXSk7vjaZmt0UysC+TNw1pBHb8CtSZe0EFxuJqI(u"ࠨ࠱ུࠪ")+P4iudsX9hLG70])
		ppAJI9kDbz5MXa76UEF.append([DpRJnas65uVcO0S17dYG(u"࠻ဖ"),start+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࠲ཱུࠫ")+ODTLNIwAXSk7vjaZmt0UysC+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫྲྀ")+P4iudsX9hLG70])
	else:
		if not mGl4VUho3RXgrqdw0DMC5Ou: ppAJI9kDbz5MXa76UEF.append([A6Sg45ChDR3BJLYfFH(u"࠴࠴ဗ"),start+fmkZtbRj3ux(u"ࠫ࠴࠭ཷ")+ODTLNIwAXSk7vjaZmt0UysC+TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࠴ࡨࡵ࡯࡯ࠫླྀ")])
		if not mGl4VUho3RXgrqdw0DMC5Ou: ppAJI9kDbz5MXa76UEF.append([w8JC1y7Lp3(u"࠵࠶ဘ"),start+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧཹ")+ODTLNIwAXSk7vjaZmt0UysC+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࠯ࡪࡷࡱࡱེ࠭")])
		if end: ppAJI9kDbz5MXa76UEF.append([vvhR5ozeiJpANyl8fFO3GBw(u"࠶࠸မ"),start+Gj3rMP1Cb8wHdp49la0(u"ࠨ࠱ཻࠪ")+ODTLNIwAXSk7vjaZmt0UysC+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࠲ོࠫ")+end+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ࠲࡭ࡺ࡭࡭ཽࠩ")])
		if end: ppAJI9kDbz5MXa76UEF.append([SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠷࠳ယ"),start+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࠴࠭ཾ")+ODTLNIwAXSk7vjaZmt0UysC+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ཿ")+end+MFhbWia58mP3su0fk2d(u"࠭࠮ࡩࡶࡰࡰྀࠬ")])
	if mGl4VUho3RXgrqdw0DMC5Ou and end:
		end = end.replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨཱྀ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠨ࠱ࠪྂ"))
		ppAJI9kDbz5MXa76UEF.append([jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠱࠵ရ"),start+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࠲ࠫྃ")+end])
		ppAJI9kDbz5MXa76UEF.append([jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠲࠷လ"),start+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰྄ࠫ")+end])
		if lCT8hfYUBX4OQMmL(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ྅") in end:
			P4iudsX9hLG70 = end.replace(JHMxIE4fs1mvQtKW7R(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ྆"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			ppAJI9kDbz5MXa76UEF.append([D2PpKMeZFWrmfxTSs4L1tz(u"࠳࠹ဝ"),start+vvhR5ozeiJpANyl8fFO3GBw(u"࠭࠯ࠨ྇")+P4iudsX9hLG70])
			ppAJI9kDbz5MXa76UEF.append([A6Sg45ChDR3BJLYfFH(u"࠴࠻သ"),start+xm6jK1ZMuWq5(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨྈ")+P4iudsX9hLG70])
		else:
			ppAJI9kDbz5MXa76UEF.append([kPCxIUZb1V(u"࠵࠽ဟ"),start+jQv0du1iVxTgAXCM(u"ࠨ࠱ࠪྉ")+end+jQv0du1iVxTgAXCM(u"ࠩ࠱࡬ࡹࡳ࡬ࠨྊ")])
			ppAJI9kDbz5MXa76UEF.append([dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠶࠿ဠ"),start+llkFwuCyhaP3sK76qO4T(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫྋ")+end+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࠳࡮ࡴ࡮࡮ࠪྌ")])
	OD5HYKrfSXjouknVhNqlye4WAxtQ = []
	for LTt0Peg4HUB8wSxEn9pZiMWmDc753G,q4zyW5Bpx6Y2O in ppAJI9kDbz5MXa76UEF:
		GS1YL8RzTv4ZsdE5Cel[hwRD1FrpuXao+LTt0Peg4HUB8wSxEn9pZiMWmDc753G] = [b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3,b02zsRFX8MweUniGfyPHEZcv7p5WK3]
		j5E8yHNZPUqCg0vMp = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=RhbIqFn0aeOC,args=(hwRD1FrpuXao+LTt0Peg4HUB8wSxEn9pZiMWmDc753G,q4zyW5Bpx6Y2O))
		OD5HYKrfSXjouknVhNqlye4WAxtQ.append(j5E8yHNZPUqCg0vMp)
	def ItHUyBTj7Qo():
		ZG9d7oT8KChmVbcMWnXsLvj = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		for a1j30LvDQOi7GV8YhKsm in GS1YL8RzTv4ZsdE5Cel:
			if not a1j30LvDQOi7GV8YhKsm: break
		else: ZG9d7oT8KChmVbcMWnXsLvj = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying() if TTuO14NzmB.resolveonly else y0yvdNOZkiKEg5RLMhoDVQAB9F2
		return ZG9d7oT8KChmVbcMWnXsLvj or not FBe2GQ7zwUmOia
	xxaHzT9pQj6SRDCGIfwydq(OD5HYKrfSXjouknVhNqlye4WAxtQ,fwvSley9oD1HsrjcPLZWYt4gTG,E1jhRWY8SLk,UD4N8MjVTd,ItHUyBTj7Qo)
	JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[]
	b0AEWmiOQsLBjr = []
	for LTt0Peg4HUB8wSxEn9pZiMWmDc753G,hhEH1rcSP0z6Bkqy8OD in ppAJI9kDbz5MXa76UEF:
		w0phq1TDik3,fSDvqX4z5WERLwgbu,WCmwQY8LDyB5,NAq8tD1OToV5Q4M7G9uS = GS1YL8RzTv4ZsdE5Cel[hwRD1FrpuXao+LTt0Peg4HUB8wSxEn9pZiMWmDc753G]
		if not j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL and WCmwQY8LDyB5: Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = fSDvqX4z5WERLwgbu,WCmwQY8LDyB5
		if not JCxwmazEp2i5eGIZt1 and w0phq1TDik3: JCxwmazEp2i5eGIZt1 = w0phq1TDik3
		if NAq8tD1OToV5Q4M7G9uS: b0AEWmiOQsLBjr.append(NAq8tD1OToV5Q4M7G9uS)
	b0AEWmiOQsLBjr = list(set(b0AEWmiOQsLBjr))
	if not JCxwmazEp2i5eGIZt1 and len(b0AEWmiOQsLBjr)==UD4N8MjVTd:
		MWgcRfQz6ymptSxB = b0AEWmiOQsLBjr[wTLFCOcM26fmYlW7U]
		if MWgcRfQz6ymptSxB!=JHMxIE4fs1mvQtKW7R(u"࠸࠰࠱အ"):
			if MWgcRfQz6ymptSxB<wTLFCOcM26fmYlW7U: JCxwmazEp2i5eGIZt1 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡧࡧࡦ࠱ࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥࡰࡪ࠭ྍ")
			else:
				JCxwmazEp2i5eGIZt1 = Gj3rMP1Cb8wHdp49la0(u"࠭ࡈࡕࡖࡓࠤࡊࡸࡲࡰࡴ࠽ࠤࠬྎ")+str(MWgcRfQz6ymptSxB)
				if wwMdFkWvcRYiXHB7yDrCqnKb98o: import http.client as eXQnp9kaRH0uh3A
				else: import httplib as eXQnp9kaRH0uh3A
				try: JCxwmazEp2i5eGIZt1 += kPCxIUZb1V(u"ࠧࠡࠪࠣࠫྏ")+eXQnp9kaRH0uh3A.responses[MWgcRfQz6ymptSxB]+Gj3rMP1Cb8wHdp49la0(u"ࠨࠢࠬࠫྐ")
				except: pass
	L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
	return JCxwmazEp2i5eGIZt1,Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL
class N5vJaI3L2HjMFtC(llfAzdjaVLTbyZW7op9i.WindowDialog):
	def __init__(bEkFlihtL7jPn2IHZdsx, *args, **kwargs):
		vaUPWnJlexdMjm7Nq = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT, gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬྑ"), vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧྒ"), rDG9dZoXRhCJcieUSF0KB(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡦ࡬࠴ࡰ࡯ࡩࠪྒྷ"))
		vVD6sMHUX0qOdBZRg1G3lekfhE2FWb = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT, it4DKnryZlx(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨྔ"), kPCxIUZb1V(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪྕ"), gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡴࡧ࡯ࡩࡨࡺࡥࡥ࠰ࡳࡲ࡬࠭ྖ"))
		oJCpFLAmcd8ElZwVrRa2GYz9T = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT, vWNRusF46D7Mi8GpZ(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫྗ"), lCT8hfYUBX4OQMmL(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭྘"), erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡦࡺࡺࡴࡰࡰࡩࡳ࠳ࡶ࡮ࡨࠩྙ"))
		lM5JOq4HBc9vu = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT, rDG9dZoXRhCJcieUSF0KB(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧྚ"), weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩྛ"), s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡢࡶࡶࡷࡳࡳࡴࡦ࠯ࡲࡱ࡫ࠬྜ"))
		RRc6W3fzv2CVAJohS = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT, pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪྜྷ"), Gj3rMP1Cb8wHdp49la0(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬྞ"), yRWQMHxZEz0(u"ࠩࡥࡹࡹࡺ࡯࡯ࡤࡪ࠲ࡵࡴࡧࠨྟ"))
		bEkFlihtL7jPn2IHZdsx.cancelled = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		bEkFlihtL7jPn2IHZdsx.chk = [wTLFCOcM26fmYlW7U] * vvhR5ozeiJpANyl8fFO3GBw(u"࠹ဢ")
		bEkFlihtL7jPn2IHZdsx.chkbutton = [wTLFCOcM26fmYlW7U] * lCT8hfYUBX4OQMmL(u"࠺ဣ")
		bEkFlihtL7jPn2IHZdsx.chkstate = [Z19pUxa2gfGMNKoDsEuytn85SjFvA] * w8JC1y7Lp3(u"࠻ဤ")
		uuy5qsJeP3oi2jXVBaAT0ULMHhgrFE, OClg1wJoM4t0qLa7vPNXIn8, JaE475rT8woNgqWbXp2KnF9, usV5qhipwEbZrm8C2 = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠵࠹࠵ဥ"), wTLFCOcM26fmYlW7U, jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠻࠵࠶ဦ"), dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠼࠼࠰ဧ")
		nCKcAr7LOtDZ6f = uuy5qsJeP3oi2jXVBaAT0ULMHhgrFE+JaE475rT8woNgqWbXp2KnF9//Tb7oymMnpflsSv3eu4Pz2
		BGr2OAFNs5Lc, zxPN1uGA35gpYiLbE6MW8Jj7FSH, TmpQKV72bzx856y, ppKXzQOylUMe = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠳࠶࠷ဩ"), kPCxIUZb1V(u"࠷࠲࠱ဨ"), vWNRusF46D7Mi8GpZ(u"࠶࠲࠳ဪ"), vWNRusF46D7Mi8GpZ(u"࠶࠲࠳ဪ")
		C7IZ2GMzwtEAhdoy1cUsjmnba4PfY = BGr2OAFNs5Lc+TmpQKV72bzx856y//Tb7oymMnpflsSv3eu4Pz2
		cbqOj2mdaleMu8GCypTP1JSWg4Ax35, Aeb6yhlkxQaz2VY5mWdfr3Hw7FUtq, ss3pgUy8L0VMDJGQjwakehTOn4, SErjnHIqiWf9FPstkXo4uM2h = llkFwuCyhaP3sK76qO4T(u"࠴࠴࠵ာ"), xm6jK1ZMuWq5(u"࠺࠺࠻ိ"), VhqD3zp7mUieI8sMQlETH(u"࠳࠸࠴ါ"), kPCxIUZb1V(u"࠺࠶ီ")
		kcoSOX17Nw = nCKcAr7LOtDZ6f-ss3pgUy8L0VMDJGQjwakehTOn4-cbqOj2mdaleMu8GCypTP1JSWg4Ax35//Tb7oymMnpflsSv3eu4Pz2
		qLQKCHzl2YsOXSWgytmZ6G = nCKcAr7LOtDZ6f+cbqOj2mdaleMu8GCypTP1JSWg4Ax35//Tb7oymMnpflsSv3eu4Pz2
		JQ9bz72pFS4aC1lMEcgeKxIkTtfd3, qgfKP7hQdRXV6wNFzOvTG, T4HuZU8tc7e2PBid, xiDSEs7AbnuXGV5d = erqDsJmL3BQHuGtPkcf0X9(u"࠹࠵࠶ု"), lCT8hfYUBX4OQMmL(u"࠳࠱ူ"), xm6jK1ZMuWq5(u"࠷࠳࠴ဲ"), dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠶࠲ေ")
		qMGLnF5iQ46VyZ2, gDAVHJsq8f6WhdC3NKYuOQmtFlaiPv, xLKtYuaF81C9J, T1TzFt4qAo9WVgbcXksCh8I = D2PpKMeZFWrmfxTSs4L1tz(u"࠶࠹࠺ဳ"), vWNRusF46D7Mi8GpZ(u"࠽࠰ံ"), jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠺࠶࠰ဵ"), JHMxIE4fs1mvQtKW7R(u"࠹࠵ဴ")
		cZ50gUPwpboIKA2Gxu3Jk1XeR = w8JC1y7Lp3(u"࠰࠯࠻့")
		uuy5qsJeP3oi2jXVBaAT0ULMHhgrFE, OClg1wJoM4t0qLa7vPNXIn8, JaE475rT8woNgqWbXp2KnF9, usV5qhipwEbZrm8C2 = int(uuy5qsJeP3oi2jXVBaAT0ULMHhgrFE*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(OClg1wJoM4t0qLa7vPNXIn8*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(JaE475rT8woNgqWbXp2KnF9*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(usV5qhipwEbZrm8C2*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		BGr2OAFNs5Lc, zxPN1uGA35gpYiLbE6MW8Jj7FSH, TmpQKV72bzx856y, ppKXzQOylUMe = int(BGr2OAFNs5Lc*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(zxPN1uGA35gpYiLbE6MW8Jj7FSH*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(TmpQKV72bzx856y*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(ppKXzQOylUMe*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		kcoSOX17Nw, IgJ2Bs1CdtNkHOT9Snb, g3adtDM15vmyXFNCAuIRjc47Tl2GY, C2TsdAcUqLH9uOwFy0ZnfDKhS46kI = int(kcoSOX17Nw*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(Aeb6yhlkxQaz2VY5mWdfr3Hw7FUtq*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(ss3pgUy8L0VMDJGQjwakehTOn4*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(SErjnHIqiWf9FPstkXo4uM2h*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		qLQKCHzl2YsOXSWgytmZ6G, xGhtiBRfzboMwJ, nCZwb4p5vkSq1VGOBUu08fAoig, ZewB6o13RvUYN7kES = int(qLQKCHzl2YsOXSWgytmZ6G*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(Aeb6yhlkxQaz2VY5mWdfr3Hw7FUtq*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(ss3pgUy8L0VMDJGQjwakehTOn4*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(SErjnHIqiWf9FPstkXo4uM2h*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		JQ9bz72pFS4aC1lMEcgeKxIkTtfd3, qgfKP7hQdRXV6wNFzOvTG, T4HuZU8tc7e2PBid, xiDSEs7AbnuXGV5d = int(JQ9bz72pFS4aC1lMEcgeKxIkTtfd3*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(qgfKP7hQdRXV6wNFzOvTG*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(T4HuZU8tc7e2PBid*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(xiDSEs7AbnuXGV5d*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		qMGLnF5iQ46VyZ2, gDAVHJsq8f6WhdC3NKYuOQmtFlaiPv, xLKtYuaF81C9J, T1TzFt4qAo9WVgbcXksCh8I = int(qMGLnF5iQ46VyZ2*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(gDAVHJsq8f6WhdC3NKYuOQmtFlaiPv*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(xLKtYuaF81C9J*cZ50gUPwpboIKA2Gxu3Jk1XeR), int(T1TzFt4qAo9WVgbcXksCh8I*cZ50gUPwpboIKA2Gxu3Jk1XeR)
		o8wDTZ9UjMnudgLBAI = llfAzdjaVLTbyZW7op9i.ControlImage(uuy5qsJeP3oi2jXVBaAT0ULMHhgrFE, OClg1wJoM4t0qLa7vPNXIn8, JaE475rT8woNgqWbXp2KnF9, usV5qhipwEbZrm8C2, vaUPWnJlexdMjm7Nq)
		bEkFlihtL7jPn2IHZdsx.addControl(o8wDTZ9UjMnudgLBAI)
		bEkFlihtL7jPn2IHZdsx.iteration = kwargs.get(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪ࡭ࡹ࡫ࡲࡢࡶ࡬ࡳࡳ࠭ྠ"))
		viIhBTd7k1s9KV4MFe5qtx3yHnJ = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+vvhR5ozeiJpANyl8fFO3GBw(u"ࠫๆำีࠡล้หࠥหๆิษ้ࠤํ๊ำหࠢิ์อ๎สࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪྡ")+vvhR5ozeiJpANyl8fFO3GBw(u"ࠬอไๆฯส์้ฯࠠาไ่ࠤࠥ࠭ྡྷ")+str(bEkFlihtL7jPn2IHZdsx.iteration)+AAByQSLgaZwCsKnvc5eWNmY
		bEkFlihtL7jPn2IHZdsx.strActionInfo = llfAzdjaVLTbyZW7op9i.ControlLabel(JQ9bz72pFS4aC1lMEcgeKxIkTtfd3, qgfKP7hQdRXV6wNFzOvTG, T4HuZU8tc7e2PBid, xiDSEs7AbnuXGV5d, viIhBTd7k1s9KV4MFe5qtx3yHnJ, it4DKnryZlx(u"࠭ࡦࡰࡰࡷ࠵࠸࠭ྣ"))
		bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.strActionInfo)
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = llfAzdjaVLTbyZW7op9i.ControlImage(BGr2OAFNs5Lc, zxPN1uGA35gpYiLbE6MW8Jj7FSH, TmpQKV72bzx856y, ppKXzQOylUMe, kwargs.get(Gj3rMP1Cb8wHdp49la0(u"ࠧࡤࡣࡳࡸࡨ࡮ࡡࠨྤ")))
		bEkFlihtL7jPn2IHZdsx.addControl(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		cIASdoeH0zx7LGR = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+kwargs.get(rDG9dZoXRhCJcieUSF0KB(u"ࠨ࡯ࡶ࡫ࠬྥ"))+AAByQSLgaZwCsKnvc5eWNmY
		bEkFlihtL7jPn2IHZdsx.strActionInfo = llfAzdjaVLTbyZW7op9i.ControlLabel(qMGLnF5iQ46VyZ2, gDAVHJsq8f6WhdC3NKYuOQmtFlaiPv, xLKtYuaF81C9J, T1TzFt4qAo9WVgbcXksCh8I, cIASdoeH0zx7LGR, it4DKnryZlx(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩྦ"))
		bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.strActionInfo)
		text = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+jQv0du1iVxTgAXCM(u"ࠪาึ๎ฬࠨྦྷ")+AAByQSLgaZwCsKnvc5eWNmY
		bEkFlihtL7jPn2IHZdsx.cancelbutton = llfAzdjaVLTbyZW7op9i.ControlButton(kcoSOX17Nw, IgJ2Bs1CdtNkHOT9Snb, g3adtDM15vmyXFNCAuIRjc47Tl2GY, C2TsdAcUqLH9uOwFy0ZnfDKhS46kI, text, focusTexture=RRc6W3fzv2CVAJohS, noFocusTexture=oJCpFLAmcd8ElZwVrRa2GYz9T, alignment=yRWQMHxZEz0(u"࠳း"))
		text = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫฬูสๆำสีࠬྨ")+AAByQSLgaZwCsKnvc5eWNmY
		bEkFlihtL7jPn2IHZdsx.okbutton = llfAzdjaVLTbyZW7op9i.ControlButton(qLQKCHzl2YsOXSWgytmZ6G, xGhtiBRfzboMwJ, nCZwb4p5vkSq1VGOBUu08fAoig, ZewB6o13RvUYN7kES, text, focusTexture=RRc6W3fzv2CVAJohS, noFocusTexture=oJCpFLAmcd8ElZwVrRa2GYz9T, alignment=s149dk8uh2p7oFzaLxZeI3Or(u"࠴္"))
		bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.okbutton)
		bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.cancelbutton)
		kOM5leY6TcGs8pnHJ, AXE5JaQSRrfe8P7qiYTmntILxukswj = ppKXzQOylUMe//MMRBkhnWVJCQwU, TmpQKV72bzx856y//MMRBkhnWVJCQwU
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(bQGafNLXyFgsZP6ut(u"࠼်")):
			U29UfNGHPs = kkLhJCU4MQSx7s6gyeOHrRYKtnP3 // MMRBkhnWVJCQwU
			viHgVoNEwThY = kkLhJCU4MQSx7s6gyeOHrRYKtnP3 % MMRBkhnWVJCQwU
			M1iUZ2bF6GLR = BGr2OAFNs5Lc + (AXE5JaQSRrfe8P7qiYTmntILxukswj * viHgVoNEwThY)
			IXlLMozev9tryd52Gxc4 = zxPN1uGA35gpYiLbE6MW8Jj7FSH + (kOM5leY6TcGs8pnHJ * U29UfNGHPs)
			bEkFlihtL7jPn2IHZdsx.chk[kkLhJCU4MQSx7s6gyeOHrRYKtnP3] = llfAzdjaVLTbyZW7op9i.ControlImage(M1iUZ2bF6GLR, IXlLMozev9tryd52Gxc4, AXE5JaQSRrfe8P7qiYTmntILxukswj, kOM5leY6TcGs8pnHJ, vVD6sMHUX0qOdBZRg1G3lekfhE2FWb)
			bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.chk[kkLhJCU4MQSx7s6gyeOHrRYKtnP3])
			bEkFlihtL7jPn2IHZdsx.chk[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].setVisible(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3] = llfAzdjaVLTbyZW7op9i.ControlButton(M1iUZ2bF6GLR, IXlLMozev9tryd52Gxc4, AXE5JaQSRrfe8P7qiYTmntILxukswj, kOM5leY6TcGs8pnHJ, str(kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + UD4N8MjVTd), font=xm6jK1ZMuWq5(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬྩ"), focusTexture=oJCpFLAmcd8ElZwVrRa2GYz9T, noFocusTexture=lM5JOq4HBc9vu)
			bEkFlihtL7jPn2IHZdsx.addControl(bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3])
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(TNw1pBHb8CtSZe0EFxuJqI(u"࠽ျ")):
			vyTJncfWudIrZiF3 = (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 // MMRBkhnWVJCQwU) * MMRBkhnWVJCQwU
			fnAaQzCk5uxybJw = vyTJncfWudIrZiF3 + (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + UD4N8MjVTd) % MMRBkhnWVJCQwU
			hj9BH7o0wsQy3fu5F41WKZOpckJqN8 = vyTJncfWudIrZiF3 + (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 - UD4N8MjVTd) % MMRBkhnWVJCQwU
			Smz0NDnXWao = (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 - MMRBkhnWVJCQwU) % weh7SGmuTgXOVRcMo1rlLq(u"࠾ြ")
			R9hs3YOB4cI = (kkLhJCU4MQSx7s6gyeOHrRYKtnP3 + MMRBkhnWVJCQwU) % xdSThjYnuHXAU6M(u"࠿ွ")
			bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlRight(bEkFlihtL7jPn2IHZdsx.chkbutton[fnAaQzCk5uxybJw])
			bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlLeft(bEkFlihtL7jPn2IHZdsx.chkbutton[hj9BH7o0wsQy3fu5F41WKZOpckJqN8])
			if kkLhJCU4MQSx7s6gyeOHrRYKtnP3 <= Tb7oymMnpflsSv3eu4Pz2:
				bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlUp(bEkFlihtL7jPn2IHZdsx.okbutton)
			else:
				bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlUp(bEkFlihtL7jPn2IHZdsx.chkbutton[Smz0NDnXWao])
			if kkLhJCU4MQSx7s6gyeOHrRYKtnP3 >= pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠶ှ"):
				bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlDown(bEkFlihtL7jPn2IHZdsx.okbutton)
			else:
				bEkFlihtL7jPn2IHZdsx.chkbutton[kkLhJCU4MQSx7s6gyeOHrRYKtnP3].controlDown(bEkFlihtL7jPn2IHZdsx.chkbutton[R9hs3YOB4cI])
		bEkFlihtL7jPn2IHZdsx.okbutton.controlLeft(bEkFlihtL7jPn2IHZdsx.cancelbutton)
		bEkFlihtL7jPn2IHZdsx.okbutton.controlRight(bEkFlihtL7jPn2IHZdsx.cancelbutton)
		bEkFlihtL7jPn2IHZdsx.cancelbutton.controlLeft(bEkFlihtL7jPn2IHZdsx.okbutton)
		bEkFlihtL7jPn2IHZdsx.cancelbutton.controlRight(bEkFlihtL7jPn2IHZdsx.okbutton)
		bEkFlihtL7jPn2IHZdsx.okbutton.controlDown(bEkFlihtL7jPn2IHZdsx.chkbutton[Tb7oymMnpflsSv3eu4Pz2])
		bEkFlihtL7jPn2IHZdsx.okbutton.controlUp(bEkFlihtL7jPn2IHZdsx.chkbutton[vWNRusF46D7Mi8GpZ(u"࠹ဿ")])
		bEkFlihtL7jPn2IHZdsx.cancelbutton.controlDown(bEkFlihtL7jPn2IHZdsx.chkbutton[wTLFCOcM26fmYlW7U])
		bEkFlihtL7jPn2IHZdsx.cancelbutton.controlUp(bEkFlihtL7jPn2IHZdsx.chkbutton[xdSThjYnuHXAU6M(u"࠸၀")])
		bEkFlihtL7jPn2IHZdsx.setFocus(bEkFlihtL7jPn2IHZdsx.okbutton)
	def get(bEkFlihtL7jPn2IHZdsx):
		bEkFlihtL7jPn2IHZdsx.doModal()
		bEkFlihtL7jPn2IHZdsx.close()
		if not bEkFlihtL7jPn2IHZdsx.cancelled:
			return [kkLhJCU4MQSx7s6gyeOHrRYKtnP3 for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(vvhR5ozeiJpANyl8fFO3GBw(u"࠼၁")) if bEkFlihtL7jPn2IHZdsx.chkstate[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]]
	def onControl(bEkFlihtL7jPn2IHZdsx, vv5qCGgkBSzyPcMQY2L):
		if vv5qCGgkBSzyPcMQY2L.getId() == bEkFlihtL7jPn2IHZdsx.okbutton.getId() and any(bEkFlihtL7jPn2IHZdsx.chkstate):
			bEkFlihtL7jPn2IHZdsx.close()
		elif vv5qCGgkBSzyPcMQY2L.getId() == bEkFlihtL7jPn2IHZdsx.cancelbutton.getId():
			bEkFlihtL7jPn2IHZdsx.cancelled = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			bEkFlihtL7jPn2IHZdsx.close()
		else:
			JrzealiFtp6 = vv5qCGgkBSzyPcMQY2L.getLabel()
			if JrzealiFtp6.isnumeric():
				index = int(JrzealiFtp6) - UD4N8MjVTd
				bEkFlihtL7jPn2IHZdsx.chkstate[index] = not bEkFlihtL7jPn2IHZdsx.chkstate[index]
				bEkFlihtL7jPn2IHZdsx.chk[index].setVisible(bEkFlihtL7jPn2IHZdsx.chkstate[index])
	def onAction(bEkFlihtL7jPn2IHZdsx, Z7Qikucg083SpAzqwlDYKCyF):
		if Z7Qikucg083SpAzqwlDYKCyF == TNw1pBHb8CtSZe0EFxuJqI(u"࠵࠵၂"):
			bEkFlihtL7jPn2IHZdsx.cancelled = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			bEkFlihtL7jPn2IHZdsx.close()
def gHRQEzxamAwup3Xys0cBoP4FYG(key,jTd3VarcCvh4D70WXGI,url):
	headers = {bQGafNLXyFgsZP6ut(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧྪ"):url,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩྫ"):jTd3VarcCvh4D70WXGI}
	TLGkenJmNQrEPMtvYA0zg9coxS = TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠱ࡩࡥࡱࡲࡢࡢࡥ࡮ࡃࡰࡃࠧྫྷ")+key
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,vWNRusF46D7Mi8GpZ(u"ࠩࡊࡉ࡙࠭ྭ"),TLGkenJmNQrEPMtvYA0zg9coxS,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠱ࡴࡶࠪྮ"))
	wkKMJqu0VaeWm,iteration = wUvcPrYDfISbZolAm83GKEqMyXkn5,wTLFCOcM26fmYlW7U
	while y0yvdNOZkiKEg5RLMhoDVQAB9F2:
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		COW137cpIhBMYTSiAR9s2Dlzw = jj0dZrgiKb.findall(MFhbWia58mP3su0fk2d(u"ࠫࠧ࠮࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠲࠰ࡲࡤࡽࡱࡵࡡࡥ࡝ࡡࠦࡢ࠱ࠩࠨྯ"), II64TLxj3mbqEyh9pHQ8oAv)
		iteration += UD4N8MjVTd
		message = jj0dZrgiKb.findall(llkFwuCyhaP3sK76qO4T(u"ࠬࡂ࡬ࡢࡤࡨࡰࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲ࡺࡥࡹࡶࠥ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯ࡥࡧ࡫࡬࠿ࠩྰ"), II64TLxj3mbqEyh9pHQ8oAv)
		if not message: message = jj0dZrgiKb.findall(bQGafNLXyFgsZP6ut(u"࠭࠼ࡥ࡫ࡹ࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡪࡸࡲࡰࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩྱ"), II64TLxj3mbqEyh9pHQ8oAv)
		if not message:
			wkKMJqu0VaeWm = jj0dZrgiKb.findall(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡳࡧࡤࡨࡴࡴ࡬ࡺࡀࠫ࠲࠯ࡅࠩ࠽ࠩྲ"), II64TLxj3mbqEyh9pHQ8oAv)[wTLFCOcM26fmYlW7U]
			break
		else:
			message = message[wTLFCOcM26fmYlW7U]
			COW137cpIhBMYTSiAR9s2Dlzw = COW137cpIhBMYTSiAR9s2Dlzw[wTLFCOcM26fmYlW7U]
		RmnH2zaLW4x095pFkQuoEvi = jj0dZrgiKb.findall(lCT8hfYUBX4OQMmL(u"ࡳࠩࡱࡥࡲ࡫࠽ࠣࡥࠥࡠࡸ࠱ࡶࡢ࡮ࡸࡩࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠧླ"), II64TLxj3mbqEyh9pHQ8oAv)[wTLFCOcM26fmYlW7U]
		KsLuDOZxiQvhXnqe6 = A6Sg45ChDR3BJLYfFH(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠩࡸ࠭ྴ") % (COW137cpIhBMYTSiAR9s2Dlzw.replace(JHMxIE4fs1mvQtKW7R(u"ࠪࠪࡦࡳࡰ࠼ࠩྵ"), kPCxIUZb1V(u"ࠫࠫ࠭ྶ")))
		message = jj0dZrgiKb.sub(bQGafNLXyFgsZP6ut(u"ࠬࡂ࠯ࡀࠪࡧ࡭ࡻࢂࡳࡵࡴࡲࡲ࡬࠯࡛࡟ࡀࡠ࠮ࡃ࠭ྷ"), wUvcPrYDfISbZolAm83GKEqMyXkn5, message)
		tOEFBV2d7vjJlGe6qRDc5rHmXQsNy = N5vJaI3L2HjMFtC(captcha=KsLuDOZxiQvhXnqe6, msg=message, iteration=iteration)
		G3ulKabVwDzBxtv5p4N = tOEFBV2d7vjJlGe6qRDc5rHmXQsNy.get()
		if not G3ulKabVwDzBxtv5p4N: break
		data = {gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡣࠨྸ"): RmnH2zaLW4x095pFkQuoEvi, TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩྐྵ"): G3ulKabVwDzBxtv5p4N}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡒࡒࡗ࡙࠭ྺ"),TLGkenJmNQrEPMtvYA0zg9coxS,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠸࡮ࡥࠩྻ"))
	return wkKMJqu0VaeWm
def ca8vDO4NqZ01U9YePW(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭ྼ"))
	items = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ྽"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ items[wTLFCOcM26fmYlW7U] ]
	else: return s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪ྾"),[],[]
def wA6uSXOcsbVF(url):
	return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
def a4awUhtW2YboQcuNmM7lZ(url):
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = url.split(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠯ࠨ྿"))
	y7y6fZbqp9TDBjnW2mw = lCT8hfYUBX4OQMmL(u"ࠧ࠰ࠩ࿀").join(xG6n4Wq2Ib7YgpiarHUNLQJM0[wTLFCOcM26fmYlW7U:MMRBkhnWVJCQwU])
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅ࠮࠳ࡶࡸࠬ࿁"))
	items = jj0dZrgiKb.findall(xm6jK1ZMuWq5(u"ࠩࠪࠫࡩࡲࡢࡶࡶࡷࡳࡳ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧ࿂"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C,DxOAJGpP9gmy3WXVkTucdeiw4F,DEwP9bJ8HVI0nQSfaFlRmr6,fSjOyim7CRvYdJcBghn2lb1V,gxsC8diSOXnE3puzyqbvoBI = items[wTLFCOcM26fmYlW7U]
		f8fOVWAM0hig9ZeDJbHds = int(oZkUpQhtGPKDNJdlImW9C) % int(DxOAJGpP9gmy3WXVkTucdeiw4F) + int(DEwP9bJ8HVI0nQSfaFlRmr6) % int(fSjOyim7CRvYdJcBghn2lb1V)
		url = y7y6fZbqp9TDBjnW2mw + Px8NBrt4vuzDFLfcw + str(f8fOVWAM0hig9ZeDJbHds) + gxsC8diSOXnE3puzyqbvoBI
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[url]
	else: return dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ࿃"),[],[]
def zCMnvPYBg4uOK(url):
	id = url.split(bQGafNLXyFgsZP6ut(u"ࠫ࠴࠭࿄"))[-UD4N8MjVTd]
	headers = { Gj3rMP1Cb8wHdp49la0(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ࿅") : yRWQMHxZEz0(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨ࿆ࠬ") }
	COW137cpIhBMYTSiAR9s2Dlzw = { erqDsJmL3BQHuGtPkcf0X9(u"ࠢࡪࡦࠥ࿇"):id , Gj3rMP1Cb8wHdp49la0(u"ࠣࡱࡳࠦ࿈"):s149dk8uh2p7oFzaLxZeI3Or(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ࿉") }
	ySY5NxERP6jeVG = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡔࡔ࡙ࡔࠨ࿊"), url, COW137cpIhBMYTSiAR9s2Dlzw, headers, wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ࿋"))
	if A6Sg45ChDR3BJLYfFH(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ࿌") in list(ySY5NxERP6jeVG.headers.keys()): hhEH1rcSP0z6Bkqy8OD = ySY5NxERP6jeVG.headers[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ࿍")]
	else: hhEH1rcSP0z6Bkqy8OD = url
	if hhEH1rcSP0z6Bkqy8OD: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[hhEH1rcSP0z6Bkqy8OD]
	else: return MFhbWia58mP3su0fk2d(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬ࿎"),[],[]
def aA9uzTYLSfCDiqcOVQ5v(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ࿏"))
	items = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ࿐"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ items[wTLFCOcM26fmYlW7U] ]
	else: return xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨ࿑"),[],[]
def oAkaex4dBQzPC7fLw(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬ࿒"))
	items = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࿓"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		url = it4DKnryZlx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬ࿔") + items[wTLFCOcM26fmYlW7U]
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ url ]
	else: return VhqD3zp7mUieI8sMQlETH(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ࿕"),[],[]
def kYiU4h9Vym02bPL7Z(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ࿖"))
	items = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࿗"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items: return wUvcPrYDfISbZolAm83GKEqMyXkn5,[wUvcPrYDfISbZolAm83GKEqMyXkn5],[ items[wTLFCOcM26fmYlW7U] ]
	else: return Gj3rMP1Cb8wHdp49la0(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡓࡕࡔࡈࡅࡒ࠭࿘"),[],[]