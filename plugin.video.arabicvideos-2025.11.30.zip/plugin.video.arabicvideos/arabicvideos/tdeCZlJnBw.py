# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = llkFwuCyhaP3sK76qO4T(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ၃")
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,eIRJAgj25bzvNik48puZl3OPUq=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠶ጪ"): WFXLiSq0we7v1MtO2V4cNuZDpBm6a(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==A6Sg45ChDR3BJLYfFH(u"࠱ጫ"): pass
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==it4DKnryZlx(u"࠳ጬ"): cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==bQGafNLXyFgsZP6ut(u"࠵ጭ"): uiXb2JArCPt1IejlUWZ()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠷ጮ"): d2rZYufjkXmPQ7ahW3FVTBKUSp(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==JHMxIE4fs1mvQtKW7R(u"࠹ጯ"): fPTEApeZGS()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xm6jK1ZMuWq5(u"࠻ጰ"): kO2JhlovxiVMAtcZF9Gsa7C()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==s149dk8uh2p7oFzaLxZeI3Or(u"࠽ጱ"): tI6bUVpz9ZSYau()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==vvhR5ozeiJpANyl8fFO3GBw(u"࠸ጲ"): yCeIaX62zTjsYMNv7KcqkSoLd()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠲࠷࠳ጳ"): VvAnliH4YeIZCK3XSsx()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xm6jK1ZMuWq5(u"࠳࠸࠵ጴ"): WWSAe90v5NXxU6PCHOmazyTYK()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==yRWQMHxZEz0(u"࠴࠹࠷ጵ"): ccXG3kyK56DMhLsQvE1o()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==lCT8hfYUBX4OQMmL(u"࠵࠺࠹ጶ"): tzT0LF2YZAsKxEnQi()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠻࠴ጷ"): lCLUcg9Mv7b06T1a()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠷࠵࠶ጸ"): cVRvta3J0Op6b()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==MFhbWia58mP3su0fk2d(u"࠱࠶࠸ጹ"): ZxIhNA12noXG7vS9()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==weh7SGmuTgXOVRcMo1rlLq(u"࠲࠷࠺ጺ"): I1IfwGo4clgaOTJ3K2drsMPBDE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==rDG9dZoXRhCJcieUSF0KB(u"࠳࠸࠼ጻ"): OjXuQbJN7pxiR8BaDq()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠹࠾ጼ"): oo0Qh9vHrMpKzNyuUlAtmgka(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==yRWQMHxZEz0(u"࠵࠼࠶ጽ"): SXIf6EAFQu1Pc7mUagztTDsVbe3M4C()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠶࠽࠱ጾ"): XXfl6zEImSdsPa4QFcbOv()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==vWNRusF46D7Mi8GpZ(u"࠷࠷࠳ጿ"): L08CNwYIzOXKFhMRJlk([eIRJAgj25bzvNik48puZl3OPUq],y0yvdNOZkiKEg5RLMhoDVQAB9F2,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠱࠸࠵ፀ"): rrI7hTwM9qCzBF2kgHjSVRNE(xm6jK1ZMuWq5(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭၄"),y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==MFhbWia58mP3su0fk2d(u"࠲࠹࠷ፁ"): rrI7hTwM9qCzBF2kgHjSVRNE(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ၅"),y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==vWNRusF46D7Mi8GpZ(u"࠳࠺࠹ፂ"): nnMWUZs1oACq4lBiQv2I0mVhYryF()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==MFhbWia58mP3su0fk2d(u"࠴࠻࠻ፃ"): YUfPqoI6wt3WgiNRucQ2Z()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==TNw1pBHb8CtSZe0EFxuJqI(u"࠵࠼࠽ፄ"): XXU03kBat5dITH8Wh2LJqZn1(yRWQMHxZEz0(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ၆"))
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==Gj3rMP1Cb8wHdp49la0(u"࠶࠽࠹ፅ"): XXU03kBat5dITH8Wh2LJqZn1(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ၇"))
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠷࠹࠱ፆ"): wXuabJjLsQBfVE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==llkFwuCyhaP3sK76qO4T(u"࠱࠺࠳ፇ"): HkLQEFT6uGiCIxhAPazUdBYDjwJXb()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==w8JC1y7Lp3(u"࠲࠻࠵ፈ"): VMNlIgH5nqB9v1Ctrdc7pfu()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳࠼࠷ፉ"): YY2EWIP4nBx1lMZR0kQqa9pb3()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠽࠹ፊ"): vPJxLmRsKl0wWqc7hUN6Ya5yIGe()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠵࠾࠻ፋ"): jj8AKmt9oTCqb40uNpveaz7l()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==weh7SGmuTgXOVRcMo1rlLq(u"࠶࠿࠶ፌ"): eetMhJGy4kUjoLqHgY3miE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==Gj3rMP1Cb8wHdp49la0(u"࠷࠹࠸ፍ"): yzYLkJxo9lqIbFTw2BfKvPAua()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==weh7SGmuTgXOVRcMo1rlLq(u"࠱࠺࠺ፎ"): IR5JjYk0sDToNO3te2G4XM6Ubl()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xm6jK1ZMuWq5(u"࠲࠻࠼ፏ"): jusaGP7rYwp5ATMtQJ1x9XCUobR()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==JHMxIE4fs1mvQtKW7R(u"࠵࠷࠴ፐ"): eV4RNS5ogFY8v3idLhZkwbaUDf10K(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠶࠸࠶ፑ"): Q6RIl4kCWLPrqONgs8()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==erqDsJmL3BQHuGtPkcf0X9(u"࠷࠹࠸ፒ"): PGe3ZEOFkWzU54Xf06pnwVY8KgR()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==lCT8hfYUBX4OQMmL(u"࠸࠺࠳ፓ"): TzNLuxX5gYJOcK7oIBi931shFjnw()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠹࠴࠶ፔ"): ZZ6Em5ke17hKL0vCgzNJcW()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==vvhR5ozeiJpANyl8fFO3GBw(u"࠳࠵࠸ፕ"): sLytMYn4Jh0XcQbek39wVaEG5r16vq(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠴࠶࠺ፖ"): C7tGsABJHNMUxw85pmRKeI0O6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠵࠷࠼ፗ"): qSsgKM7ckJWzBP()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠶࠸࠾ፘ"): rG0MQfgtacDUbH384x7qlTeKzd(rDG9dZoXRhCJcieUSF0KB(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ၈"),y0yvdNOZkiKEg5RLMhoDVQAB9F2,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==DpRJnas65uVcO0S17dYG(u"࠹࠵࠶ፙ"): JwTaD9WOp4BeNX6h7R()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠺࠶࠱ፚ"): Wvc1GVQl50SXC7rAudaPEk()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==fmkZtbRj3ux(u"࠻࠰࠳፛"): SzC6YRBUM0Etc83Qb()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==Gj3rMP1Cb8wHdp49la0(u"࠵࠱࠵፜"): AUXqorfzD4HmJ9KdwZYBks2hyxv0et(C5VkX6NMYnT2A0PFL)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==rDG9dZoXRhCJcieUSF0KB(u"࠶࠲࠷፝"): AUXqorfzD4HmJ9KdwZYBks2hyxv0et(eCcr5AqkmHOSU)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xm6jK1ZMuWq5(u"࠷࠳࠹፞"): c82cPtTjLoaUSbkMXD9l7xIhwBNRu()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==rDG9dZoXRhCJcieUSF0KB(u"࠸࠴࠻፟"): N2QCj84D9qInlHveBcf6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠹࠵࠽፠"): Zl31kwvucIYaBD5h()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠺࠶࠸፡"): ZgP6MtUwIVNz1oBXiTK()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==weh7SGmuTgXOVRcMo1rlLq(u"࠷࠰࠳࠲።"): ncE5TQeHlbaXrgzufYOZMD()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==s149dk8uh2p7oFzaLxZeI3Or(u"࠱࠱࠴࠴፣"): ijohpkt6ZcKF5()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==rDG9dZoXRhCJcieUSF0KB(u"࠲࠲࠵࠶፤"): XXU03kBat5dITH8Wh2LJqZn1(kPCxIUZb1V(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ၉"))
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==yRWQMHxZEz0(u"࠳࠳࠶࠸፥"): NECFluX16GqSi5MJUpVOtgD8AW()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠴࠴࠷࠺፦"): XgxMuBWUqJiDls4SFItVhpo5r9k(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==llkFwuCyhaP3sK76qO4T(u"࠵࠵࠸࠵፧"): Puk5RwzYjAysBgbdShD6GroK()
	return
def XgxMuBWUqJiDls4SFItVhpo5r9k(showDialogs=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
	gnVfthzH9oW3MFTINJRdkyvAsPS = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(w8JC1y7Lp3(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡨࡧ࡬ࡦ࠰࡮ࡩࡾࡨ࡯ࡢࡴࡧࡰࡦࡿ࡯ࡶࡶࡶࠦࢂࢃࠧ၊"))
	gnVfthzH9oW3MFTINJRdkyvAsPS = bbeLsVCqouaSH53E0XmKh4AnFD.loads(gnVfthzH9oW3MFTINJRdkyvAsPS)[jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡲࡦࡵࡸࡰࡹ࠭။")][erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡷࡣ࡯ࡹࡪ࠭၌")]
	choice,VGKoY9ATBMb6HfE71UDvR5tLiazCk = Tb7oymMnpflsSv3eu4Pz2,gnVfthzH9oW3MFTINJRdkyvAsPS[:]
	if showDialogs:
		ctCxK28a6Q = jQv0du1iVxTgAXCM(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊ส่ࠢๅ฾๊ษ๊ࠡอ฽๊๊ࠧ၍") if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩ၎") in gnVfthzH9oW3MFTINJRdkyvAsPS else dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ๊ะ่ใใฬࠫ၏")
		choice = E74G0qBSpwUPLO56fsReHCl(JHMxIE4fs1mvQtKW7R(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၐ"),kPCxIUZb1V(u"ࠬิั้ฮࠪၑ"),kPCxIUZb1V(u"࠭ล๋ไสๅࠬၒ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧหึ฽๎้࠭ၓ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,JegF7SlMawI03+ctCxK28a6Q+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev+QWLr8ABjev+TNw1pBHb8CtSZe0EFxuJqI(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสิ็ะࠤออำหะาห๊ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠศๆ่์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋ะࠠหีอ฻๏฿ࠠฤ่ࠣฮ฾๋ไࠡสะฯࠥ็๊ࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢหหุะฮะษ่ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ๊ࠣฮุะื๋฻ࠣว๋ࠦสไฬหࠤึูวๅห่้๋ࠣศา็ฯࠤออไๅ฼ฬࠤฬู๊าสํอࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨၔ"))
	if choice==Tb7oymMnpflsSv3eu4Pz2 and llkFwuCyhaP3sK76qO4T(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩၕ") not in gnVfthzH9oW3MFTINJRdkyvAsPS: VGKoY9ATBMb6HfE71UDvR5tLiazCk = [jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪၖ")]+gnVfthzH9oW3MFTINJRdkyvAsPS
	elif choice==UD4N8MjVTd and pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫၗ") in gnVfthzH9oW3MFTINJRdkyvAsPS:
		VGKoY9ATBMb6HfE71UDvR5tLiazCk = gnVfthzH9oW3MFTINJRdkyvAsPS[:]
		VGKoY9ATBMb6HfE71UDvR5tLiazCk.remove(vWNRusF46D7Mi8GpZ(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬၘ"))
	if VGKoY9ATBMb6HfE71UDvR5tLiazCk!=gnVfthzH9oW3MFTINJRdkyvAsPS:
		VGKoY9ATBMb6HfE71UDvR5tLiazCk = str(VGKoY9ATBMb6HfE71UDvR5tLiazCk).replace(xm6jK1ZMuWq5(u"ࠨࠧࠣၙ"),DpRJnas65uVcO0S17dYG(u"ࠧࠣࠩၚ"))
		RCmHBOKtejQ8lu4L = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡤࡣ࡯ࡩ࠳ࡱࡥࡺࡤࡲࡥࡷࡪ࡬ࡢࡻࡲࡹࡹࡹࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠪၛ")+VGKoY9ATBMb6HfE71UDvR5tLiazCk+MFhbWia58mP3su0fk2d(u"ࠩࢀࢁࠬၜ"))
		if showDialogs:
			if jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡸࡷࡻࡥࠨၝ") in str(RCmHBOKtejQ8lu4L): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨၞ"))
			else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪၟ"))
	return
def NECFluX16GqSi5MJUpVOtgD8AW():
	oqF5GjVvYXpBd1l2xmWL0n3kU = OOnvcPQy85HYA.getSetting(kPCxIUZb1V(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪၠ"))
	message = Gj3rMP1Cb8wHdp49la0(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭ၡ")+str(oqF5GjVvYXpBd1l2xmWL0n3kU)+w8JC1y7Lp3(u"ࠨࠢ࡮ࡦࡵࡹࠧၢ") if oqF5GjVvYXpBd1l2xmWL0n3kU else vWNRusF46D7Mi8GpZ(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨၣ")
	message = JegF7SlMawI03+message+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩၤ")+AAByQSLgaZwCsKnvc5eWNmY
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(xdSThjYnuHXAU6M(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၥ"),DpRJnas65uVcO0S17dYG(u"ࠬิั้ฮࠪၦ"),bQGafNLXyFgsZP6ut(u"࠭ล๋ไสๅࠬၧ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧหึ฽๎้࠭ၨ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,message+llkFwuCyhaP3sK76qO4T(u"ࠨ࡞ࡱࡠࡳอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠥํ๊ࠡ฻่่๏ฯ๋ࠠไ๋้ࠥฮ็ศࠢส่อืๆศ็ฯࠤออฮห์สีࠥษูๅ๋ࠣะํีษࠡ็อ์ๆืษࠡๆิๆ๊ࠦวๅฮ๋ำฮࠦวๅาํࠤฬ์สࠡฬะำิํࠠโ์๋ࠣีํࠠศๆืหูฯࠠ࠯࠰ࠣ์์ึวࠡ็฼๊ฬํฺ่ࠠา้ฬࠦสใ๊่ࠤฬ์สࠡสอุ฿๐ไࠡใํำ๏๎ࠠโษ้ࠤฬ๊ศา่ส้ัࠦไ็ࠢํืศ๊ใࠡ฻้ࠤฬ๊ฬ้ัฬࠤฬ๊ส๋ࠢอี๏ี็ศࠢ็ว๋ࠦวๅสิ๊ฬ๋ฬࠡี๋ๅࠥ๐ฮหษิࠤฬ๊ฬ้ัฬࠤศ๎ส้็สฮ๏้๊ศࠢ࠱࠲ࠥ฿ไๆษࠣห๋ํ๋ࠠฮหࠤฬิส๋ษิࠤึ่ๅࠡฮ๋ำฮࠦี฻์ิࠤสึวࠡๅส๊ฯࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦศุ์ษอࠥษ่ࠡไ็๎้ฯࠧၩ"))
	if dcDaPVjr5uyEntR4HFqSb in [-gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠶፨"),llkFwuCyhaP3sK76qO4T(u"࠶፩")]: return
	if dcDaPVjr5uyEntR4HFqSb==vWNRusF46D7Mi8GpZ(u"࠱፪"):
		oqF5GjVvYXpBd1l2xmWL0n3kU = wUvcPrYDfISbZolAm83GKEqMyXkn5
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,TNw1pBHb8CtSZe0EFxuJqI(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ไสๅࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠬၪ"))
	else:
		items = [VhqD3zp7mUieI8sMQlETH(u"ࠪ࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬၫ"),fmkZtbRj3ux(u"ࠫ࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ၬ"),lCT8hfYUBX4OQMmL(u"ࠬ࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧၭ"),Gj3rMP1Cb8wHdp49la0(u"࠭࠱࠱࠲࠳ࠤࡰࡨࡰࡴࠩၮ"),yRWQMHxZEz0(u"ࠧ࠲࠴࠸࠴ࠥࡱࡢࡱࡵࠪၯ"),A6Sg45ChDR3BJLYfFH(u"ࠨ࠳࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫၰ"),VhqD3zp7mUieI8sMQlETH(u"ࠩ࠴࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬၱ"),rDG9dZoXRhCJcieUSF0KB(u"ࠪ࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ၲ"),bQGafNLXyFgsZP6ut(u"ࠫ࠷࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧၳ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬ࠹࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨၴ"),VhqD3zp7mUieI8sMQlETH(u"࠭࠳࠶࠲࠳ࠤࡰࡨࡰࡴࠩၵ"),JHMxIE4fs1mvQtKW7R(u"ࠧ࠵࠲࠳࠴ࠥࡱࡢࡱࡵࠪၶ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠨ࠶࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫၷ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࠸࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬၸ"),jQv0du1iVxTgAXCM(u"ࠪ࠺࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ၹ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࠼࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧၺ"),MFhbWia58mP3su0fk2d(u"ࠬ࠾࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨၻ"),weh7SGmuTgXOVRcMo1rlLq(u"࠭࠹࠱࠲࠳ࠤࡰࡨࡰࡴࠩၼ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࠲࠲࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫၽ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ࠳࠴࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬၾ"),vWNRusF46D7Mi8GpZ(u"ࠩ࠴࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ၿ"),llkFwuCyhaP3sK76qO4T(u"ࠪ࠽࠾࠿࠹࠺ࠢ࡮ࡦࡵࡹࠧႀ")]
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(w8JC1y7Lp3(u"ࠫฬิสาࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠢส่๊์วิสฬࠫႁ"),items)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-xdSThjYnuHXAU6M(u"࠲፫"): return
		oqF5GjVvYXpBd1l2xmWL0n3kU = str(items[EcQws7L35GvtIpl0k1gJZWTNPDbmMq][:-erqDsJmL3BQHuGtPkcf0X9(u"࠷፬")])
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอุ฿๐ไ๊ࠡอัิ๐ฯࠡำๅ้ࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࡡࡴ࡜࡯ࠩႂ")+JegF7SlMawI03+oqF5GjVvYXpBd1l2xmWL0n3kU+lCT8hfYUBX4OQMmL(u"࠭ࠠ࡬ࡤࡳࡷࠬႃ")+AAByQSLgaZwCsKnvc5eWNmY)
	OOnvcPQy85HYA.setSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫႄ"),oqF5GjVvYXpBd1l2xmWL0n3kU)
	return
def ijohpkt6ZcKF5(fsbBk6uneVmac5jwS=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
	z21ptngLbm8wjPrFe3J0NvCAYVIy = TTpQfNshcSo()
	ctCxK28a6Q = llkFwuCyhaP3sK76qO4T(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใࠢํ฽๊๊ࠧႅ") if z21ptngLbm8wjPrFe3J0NvCAYVIy else xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไ้ࠣฯ๎โโࠩႆ")
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(VhqD3zp7mUieI8sMQlETH(u"ࠪࡧࡪࡴࡴࡦࡴࠪႇ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫำื่อࠩႈ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠬห๊ใษไࠫႉ"),weh7SGmuTgXOVRcMo1rlLq(u"࠭สี฼ํ่ࠬႊ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,JegF7SlMawI03+ctCxK28a6Q+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev+JHMxIE4fs1mvQtKW7R(u"่ࠧา๊ࠤฬู๊่์ไอࠥะฬฺๆࠣ็ํี๊ࠡล๋ฮํ๋วห์ๆ๎ฬ๊ࠦใ๊่ࠤอะิ฻์็ࠤฬ๊แ๋ัํ์ࠥอไๅษะๆࠥ࠴࠮ࠡว่หࠥฮูะࠢส๊ฯํวยࠢส่ๆ๐ฯ๋๊ࠣห้ำวๅ์ࠣฬศ้ๅๅ้ࠣ࠲࠳ࠦร้ࠢห฽ิࠦวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨสอษ๋ึࠥหไ๊ࠢส่้ออใࠤࠣ࠲࠳่ࠦฤ์ูห๋ࠥๅไ่ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠣห้๊วฮไࠣฬฬ๊ๆใำࠣ฽้๏ࠠำำࠣࠦส๐โศใࠣห้็๊ะ์๋ࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥอไศีอๅฬีษࠡ็้ࠤฯเ๊๋ำࠣฮึะ๊ษ่ࠢัฯ๎๊ศฬࠣห้่่ศศ่ࠤ࠳࠴้ࠠะสูฮࠦสาฬํฬࠥำไใษอࠤฬ๊ๅิๆึ่ฬะࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไ้ࠡำ๋ࠥอไฺ้ํๅฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧႋ"))
	if dcDaPVjr5uyEntR4HFqSb==UD4N8MjVTd: QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝ࡠࢁࢂ࠭ႌ"))
	elif dcDaPVjr5uyEntR4HFqSb==Tb7oymMnpflsSv3eu4Pz2: QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(vWNRusF46D7Mi8GpZ(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞࠵ࡢࢃࡽࠨႍ"))
	if dcDaPVjr5uyEntR4HFqSb in [UD4N8MjVTd,Tb7oymMnpflsSv3eu4Pz2]:
		if lCT8hfYUBX4OQMmL(u"ࠪࡸࡷࡻࡥࠨႎ") in str(QZ0d7OmEhFDrfe): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,VhqD3zp7mUieI8sMQlETH(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨႏ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪ႐"))
	return
def ncE5TQeHlbaXrgzufYOZMD():
	url = TTuO14NzmB.SITESURLS[yRWQMHxZEz0(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨ႑")][s149dk8uh2p7oFzaLxZeI3Or(u"࠳፭")]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡈࡇࡗࠫ႒"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭႓"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	dOCgFmA6NUr4ols7ufiGJ = jj0dZrgiKb.findall(it4DKnryZlx(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࠩࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩ႔"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	dOCgFmA6NUr4ols7ufiGJ = sorted(dOCgFmA6NUr4ols7ufiGJ,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪหำะัࠡษ็ษฺีวาࠢส่ี๐ࠠหำํำࠥะหษ์อ๋ࠬ႕"),dOCgFmA6NUr4ols7ufiGJ)
	if EcQws7L35GvtIpl0k1gJZWTNPDbmMq>=xm6jK1ZMuWq5(u"࠴፮"):
		rrOAW87EPR9JpT3GtYLu4qNho = url.rsplit(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ࠴࠭႖"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠶፯"))[ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠶፰")]+weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠭႗")+dOCgFmA6NUr4ols7ufiGJ[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]+ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࠮ࡻ࡫ࡳࠫ႘")
		succeeded = sTM2uQCLkm59NdjSAphW(Gj3rMP1Cb8wHdp49la0(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ႙"),rrOAW87EPR9JpT3GtYLu4qNho,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		if succeeded:
			OOnvcPQy85HYA.setSetting(DpRJnas65uVcO0S17dYG(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬႚ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩอ้ࠥะหษ์อࠤส฻ฯศำࠣๆิ๐ๅࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦไไ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอะอะ์ฮࠤัฺ๋๊ࠢส่อืวๆฮࠣฬฬูสฯัส้ࠥศฮาࠢศูิอัࠡ็อ์ๆืࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ๊ิฬࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬႛ"))
			if ug0EmiKYnRT1qeH9MFyr3pO: rG0MQfgtacDUbH384x7qlTeKzd(s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨႜ"),y0yvdNOZkiKEg5RLMhoDVQAB9F2,y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def Zl31kwvucIYaBD5h():
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫ์๊ࠠหำํำࠥ็ูๅษุ้ࠣำࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣห้ิวึหࠣฬํ่สࠡฮ็ฬࠥอไหฯา๎ะอสࠡ࠰࠱ࠤ์ึวࠡษ็ุ้ำࠠิ๊ไࠤ๏ูศษࠢอัิ๐หࠡใ๋ี๏ࠦไอ็ํ฽ࠥ๎ุศศไࠤฬ๊ศา่ส้ัࠦวๅฬํࠤฯ฿สๆัࠣ฽้๏ࠠๆำ๋ีࠥ๎โห่ࠢ฽๏์ࠧႝ"))
	if ug0EmiKYnRT1qeH9MFyr3pO:
		OOnvcPQy85HYA.setSetting(fmkZtbRj3ux(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪ႞"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		OOnvcPQy85HYA.setSetting(JHMxIE4fs1mvQtKW7R(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭႟"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		OOnvcPQy85HYA.setSetting(Gj3rMP1Cb8wHdp49la0(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫႠ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		OOnvcPQy85HYA.setSetting(fmkZtbRj3ux(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩႡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫႢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,lCT8hfYUBX4OQMmL(u"ࠪฮ๊ࠦๅิฯࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦวๅะสูฮࠦศ้ไอࠤั๊ศࠡษ็ฮาี๊ฬษอࠤ࠳࠴้ࠠี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬฯำฯ๋อ๋ࠣีํࠠศๆศ฽ิอฯศฬࠣ࠲࠳่ࠦฤ์ูหࠥะอะ์ฮࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦวๅ๊ๅฮࠬႣ"))
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def c82cPtTjLoaUSbkMXD9l7xIhwBNRu():
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,VhqD3zp7mUieI8sMQlETH(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩႤ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨႥ"))
	jpToYkrQKD2eMzWsRLJmXhl = TNuvf0sHO35JtqPga8x(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	HkIhsFnLabxl02O1YwByZ = QWLr8ABjev
	YYi0mclH8D = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+DpRJnas65uVcO0S17dYG(u"࠭ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢࠪႦ")+AAByQSLgaZwCsKnvc5eWNmY
	i1nasohRjqI2PHGeU7fVJp6bC = QWLr8ABjev+JegF7SlMawI03+D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫႧ")+AAByQSLgaZwCsKnvc5eWNmY+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨ࡞ࡱࡠࡳ࠭Ⴈ")
	for id,c3tEmP52oQXkU0eIpAjwyrY6G,IC6XSwYirspRHmM,SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR,reason in reversed(jpToYkrQKD2eMzWsRLJmXhl):
		if id==vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࠳ࠫႩ"):
			TLpifAHQXIa9EW,D0Rr29bEPUBdAaKMCXhvz75osS = SiLq2mwM5R1ZNXxs83T.split(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡠࡳࡁ࠻ࠨႪ"))
			continue
		if HkIhsFnLabxl02O1YwByZ!=QWLr8ABjev: HkIhsFnLabxl02O1YwByZ += i1nasohRjqI2PHGeU7fVJp6bC
		Kj04L1bcTNuOoUz3Yg = TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡠࡘࡔࡍ࡟ࠪႫ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+id+jQv0du1iVxTgAXCM(u"ࠬࠦ࠺ࠡࠩႬ")+MFhbWia58mP3su0fk2d(u"࠭วๅีวห้ࠦ࠺ࠡࠩႭ")+AAByQSLgaZwCsKnvc5eWNmY+IC6XSwYirspRHmM
		OOZ9V4c5uT8gEl = VhqD3zp7mUieI8sMQlETH(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨႮ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+s149dk8uh2p7oFzaLxZeI3Or(u"ࠨษ็ะํอศࠡ࠼ࠣࠫႯ")+AAByQSLgaZwCsKnvc5eWNmY+SiLq2mwM5R1ZNXxs83T
		mFtyk0Ph4GNuZ5pK = TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨႰ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+rDG9dZoXRhCJcieUSF0KB(u"ࠪห้ิืฤࠢ࠽ࠤࠬႱ")+AAByQSLgaZwCsKnvc5eWNmY+fq4zHVKJne2uX9aAR
		xXQniIulZWFvDCEGR72aLTMH81 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬႲ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬอไิสหࠤ࠿ࠦࠧႳ")+AAByQSLgaZwCsKnvc5eWNmY+reason
		HkIhsFnLabxl02O1YwByZ += Kj04L1bcTNuOoUz3Yg+OOZ9V4c5uT8gEl+QWLr8ABjev+YYi0mclH8D+QWLr8ABjev+mFtyk0Ph4GNuZ5pK+xXQniIulZWFvDCEGR72aLTMH81+QWLr8ABjev
	sNQlowOJdgWBt2cyV18ZI6Ye(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡲࡪࡩ࡫ࡸࠬႴ"),D0Rr29bEPUBdAaKMCXhvz75osS,HkIhsFnLabxl02O1YwByZ,it4DKnryZlx(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨႵ"))
	return
def AUXqorfzD4HmJ9KdwZYBks2hyxv0et(file):
	if file==eCcr5AqkmHOSU: eYAT2h4JNvHCxt6jrkpcubzWGE = rDG9dZoXRhCJcieUSF0KB(u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨႶ")
	elif file==C5VkX6NMYnT2A0PFL: eYAT2h4JNvHCxt6jrkpcubzWGE = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩๅ์ฬฬๅࠡฤัีࠥอไโ์า๎ํํวหࠩႷ")
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡧࡪࡴࡴࡦࡴࠪႸ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ู๊ࠫอࠨႹ"),llkFwuCyhaP3sK76qO4T(u"ࠬหีๅษะࠫႺ"),bQGafNLXyFgsZP6ut(u"࠭ฮา๊ฯࠫႻ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬႼ")+eYAT2h4JNvHCxt6jrkpcubzWGE+bQGafNLXyFgsZP6ut(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨႽ"))
	if dcDaPVjr5uyEntR4HFqSb==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠰፱"):
		if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(file):
			try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(file)
			except: pass
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"ࠩอ้๋ࠥำฮ่่ࠢๆࠦࠧႾ")+eYAT2h4JNvHCxt6jrkpcubzWGE)
	elif dcDaPVjr5uyEntR4HFqSb==vWNRusF46D7Mi8GpZ(u"࠲፲"):
		data = akK8V9HQng4mqSlvO01swx6RorY(file)
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,DpRJnas65uVcO0S17dYG(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪႿ")+eYAT2h4JNvHCxt6jrkpcubzWGE)
	return
def Wvc1GVQl50SXC7rAudaPEk():
	if Uy6GWujQiBLhodP<SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳࠻፳"):
		SLAiUwpDRoZIQfvB7 = w8JC1y7Lp3(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧჀ")+str(Uy6GWujQiBLhodP)+it4DKnryZlx(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭Ⴡ")
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
		return
	Q0lCeRfj3P4BcbELFqhVaw7Ns = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(llkFwuCyhaP3sK76qO4T(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩჂ"))
	WzcgrtpJ9X6lYCD = XFMSnPvjbgcRE9tf6z([SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭Ⴣ")])
	wpkjW8nG0NXofze1daLyqIB5H,bBjKFNM3wq9mLEyOu,nITLJDrYXZuoil50xyMjkNQcO,ZhPL0Ktp2mwncgRDjO85N6XsY1VaE,O6UYblvfHFp,oZDI1sf2pi,bPzxsINGrCAKXRmQ8JpVT3 = WzcgrtpJ9X6lYCD[yRWQMHxZEz0(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧჄ")]
	if wpkjW8nG0NXofze1daLyqIB5H or it4DKnryZlx(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨჅ") not in str(Q0lCeRfj3P4BcbELFqhVaw7Ns):
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ჆"))
		n453i9Fwpc6bGMuUa2l = SzC6YRBUM0Etc83Qb()
		if not n453i9Fwpc6bGMuUa2l: return
	DzpFHEhJlwB7AU34GmNX(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def DzpFHEhJlwB7AU34GmNX(showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	Q0lCeRfj3P4BcbELFqhVaw7Ns = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(vWNRusF46D7Mi8GpZ(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧჇ"))
	if JHMxIE4fs1mvQtKW7R(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ჈") not in str(Q0lCeRfj3P4BcbELFqhVaw7Ns):
		if showDialogs:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ไๅลึๅࠥา็ศิๆࠤ้อ๋ࠠีอาิ๋ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫ჉"))
		return
	T839YC7rcEKsfevQDJU = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(KXekl8MiCfjSYDHdWqw,MFhbWia58mP3su0fk2d(u"ࠧࡢࡦࡧࡳࡳࡹࠧ჊"),xm6jK1ZMuWq5(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ჋"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࠺࠶࠵ࡶࠧ჌"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡑࡾ࡜ࡩࡥࡧࡲࡒࡦࡼ࠮ࡹ࡯࡯ࠫჍ"))
	if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(T839YC7rcEKsfevQDJU): return
	Ye2FIg9kj3d0QvM6y58KtERxuNV = open(T839YC7rcEKsfevQDJU,llkFwuCyhaP3sK76qO4T(u"ࠫࡷࡨࠧ჎")).read()
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: Ye2FIg9kj3d0QvM6y58KtERxuNV = Ye2FIg9kj3d0QvM6y58KtERxuNV.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	ywE69xjKpaS = jj0dZrgiKb.findall(it4DKnryZlx(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠮࡜ࡥ࠭࠯ࡠࡩ࠱ࠬ࡝ࡦ࠮࠭࠱࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ჏"),Ye2FIg9kj3d0QvM6y58KtERxuNV,jj0dZrgiKb.DOTALL)
	XOucFCoRpkafs1B3exbl0EV5m9YPv,GbVycT5MsuLhit630SDlamRJC8UY = ywE69xjKpaS[wTLFCOcM26fmYlW7U]
	UivYsJb4flEGFe8HpjDIT90h3tQ5Ng = xdSThjYnuHXAU6M(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧა")+XOucFCoRpkafs1B3exbl0EV5m9YPv+jQv0du1iVxTgAXCM(u"ࠧ࠭ࠩბ")+GbVycT5MsuLhit630SDlamRJC8UY+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪგ")
	if showDialogs:
		UzQ7PpSIcfyCZDFu8RNrwKJ4sv = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡜ࡩࡦࡹࡰࡳࡩ࡫ࠧდ"))
		if UzQ7PpSIcfyCZDFu8RNrwKJ4sv==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ე"): kHOncagIz8AB23MlF0 = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫ็๎วว็ࠣห้้สศสฬࠫვ")
		elif UzQ7PpSIcfyCZDFu8RNrwKJ4sv==jQv0du1iVxTgAXCM(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫზ"): kHOncagIz8AB23MlF0 = TNw1pBHb8CtSZe0EFxuJqI(u"࠭โ้ษษ้ࠥอไึ๊ิࠫთ")
		else: kHOncagIz8AB23MlF0 = rDG9dZoXRhCJcieUSF0KB(u"ࠧใ๊สส๊ࠦรฯำ์ࠫი")
		dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(jQv0du1iVxTgAXCM(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨკ"),rDG9dZoXRhCJcieUSF0KB(u"ࠩๅ์ฬฬๅࠡลัี๎࠭ლ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪๆํอฦๆࠢส่่ะวษหࠪმ"),vWNRusF46D7Mi8GpZ(u"ࠫ็๎วว็ࠣห้฻่าࠩნ"),it4DKnryZlx(u"ࠬอๆหࠢะห้๐วࠡฬึฮำีๅࠡࠩო")+kHOncagIz8AB23MlF0,D2PpKMeZFWrmfxTSs4L1tz(u"࠭ว็ฬࠣห้ศๆࠡฬึฮำีๅࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๋๋ࠢีอࠠๆ฻้ห์ࠦว็ๅࠣฮุะื๋฻ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦศะๆสࠤ๊์ࠠใ๊สส๊ࠦวๅๅอหอฯࠠ࠯๋ࠢว๏฼วࠡฬึฮ฼๐ูࠡวํๆฬ็็ศࠢไ๎ࠥษ๊๊ࠡๅฮࠥะิศรࠣࡠࡳࡢ࡮ࠡࠩპ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+DpRJnas65uVcO0S17dYG(u"ࠧࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤࠫჟ")+AAByQSLgaZwCsKnvc5eWNmY)
		if dcDaPVjr5uyEntR4HFqSb==it4DKnryZlx(u"࠴፴"): GMaTACrU9sRdm4XeBS1hfzQ7JNcqLi = Gj3rMP1Cb8wHdp49la0(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫრ")
		elif dcDaPVjr5uyEntR4HFqSb==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠶፵"): GMaTACrU9sRdm4XeBS1hfzQ7JNcqLi = jQv0du1iVxTgAXCM(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨს")
		else: GMaTACrU9sRdm4XeBS1hfzQ7JNcqLi = wUvcPrYDfISbZolAm83GKEqMyXkn5
	else:
		UzQ7PpSIcfyCZDFu8RNrwKJ4sv = OOnvcPQy85HYA.getSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨტ"))
		if   UzQ7PpSIcfyCZDFu8RNrwKJ4sv==wUvcPrYDfISbZolAm83GKEqMyXkn5: dcDaPVjr5uyEntR4HFqSb = Gj3rMP1Cb8wHdp49la0(u"࠵፶")
		elif UzQ7PpSIcfyCZDFu8RNrwKJ4sv==it4DKnryZlx(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧუ"): dcDaPVjr5uyEntR4HFqSb = jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷፷")
		elif UzQ7PpSIcfyCZDFu8RNrwKJ4sv==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫფ"): dcDaPVjr5uyEntR4HFqSb = erqDsJmL3BQHuGtPkcf0X9(u"࠲፸")
		GMaTACrU9sRdm4XeBS1hfzQ7JNcqLi = UzQ7PpSIcfyCZDFu8RNrwKJ4sv
	if   dcDaPVjr5uyEntR4HFqSb==jQv0du1iVxTgAXCM(u"࠱፹"): UU4JrCXNs8euAHLDkEgjQF36SV2Ra = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪქ")
	elif dcDaPVjr5uyEntR4HFqSb==vvhR5ozeiJpANyl8fFO3GBw(u"࠳፺"): UU4JrCXNs8euAHLDkEgjQF36SV2Ra = it4DKnryZlx(u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫღ")
	elif dcDaPVjr5uyEntR4HFqSb==rDG9dZoXRhCJcieUSF0KB(u"࠵፻"): UU4JrCXNs8euAHLDkEgjQF36SV2Ra = erqDsJmL3BQHuGtPkcf0X9(u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬყ")
	else: return
	OOnvcPQy85HYA.setSetting(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧშ"),GMaTACrU9sRdm4XeBS1hfzQ7JNcqLi)
	ufGSD6qe5EsFxK2IrwpvmBHzdULYyi = xdSThjYnuHXAU6M(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫჩ")+UU4JrCXNs8euAHLDkEgjQF36SV2Ra+D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࠱࠭ც")+GbVycT5MsuLhit630SDlamRJC8UY+D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧძ")
	B24cf0uV1SMLNI6TwziZ = Ye2FIg9kj3d0QvM6y58KtERxuNV.replace(UivYsJb4flEGFe8HpjDIT90h3tQ5Ng,ufGSD6qe5EsFxK2IrwpvmBHzdULYyi)
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: B24cf0uV1SMLNI6TwziZ = B24cf0uV1SMLNI6TwziZ.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	open(T839YC7rcEKsfevQDJU,yRWQMHxZEz0(u"࠭ࡷࡣࠩწ")).write(B24cf0uV1SMLNI6TwziZ)
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,yRWQMHxZEz0(u"ࠧ࠯࡞ࡷࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬჭ")+UU4JrCXNs8euAHLDkEgjQF36SV2Ra+jQv0du1iVxTgAXCM(u"ࠨࠢࡠࠫხ"))
	if showDialogs: te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨჯ"))
	return
def JwTaD9WOp4BeNX6h7R():
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨჰ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==llkFwuCyhaP3sK76qO4T(u"࠵፼"): tI6bUVpz9ZSYau()
	return
def yCeIaX62zTjsYMNv7KcqkSoLd():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧჱ"))
	return
def qSsgKM7ckJWzBP():
	Kj04L1bcTNuOoUz3Yg = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+jQv0du1iVxTgAXCM(u"ࠬะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡࠩჲ")+AAByQSLgaZwCsKnvc5eWNmY
	Kj04L1bcTNuOoUz3Yg += MFhbWia58mP3su0fk2d(u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬჳ")
	Kj04L1bcTNuOoUz3Yg += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࠬჴ")+AAByQSLgaZwCsKnvc5eWNmY
	OOZ9V4c5uT8gEl = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+llkFwuCyhaP3sK76qO4T(u"ࠨสิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡࠩჵ")+AAByQSLgaZwCsKnvc5eWNmY
	OOZ9V4c5uT8gEl += w8JC1y7Lp3(u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭ჶ")
	OOZ9V4c5uT8gEl += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴࠪჷ")+AAByQSLgaZwCsKnvc5eWNmY
	SLAiUwpDRoZIQfvB7 = TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡠࡘࡔࡍ࡟ࠪჸ")+Kj04L1bcTNuOoUz3Yg+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪჹ")+OOZ9V4c5uT8gEl
	sNQlowOJdgWBt2cyV18ZI6Ye(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡲࡪࡩ࡫ࡸࠬჺ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,SLAiUwpDRoZIQfvB7)
	return
def sLytMYn4Jh0XcQbek39wVaEG5r16vq(RCBXDnhK3jHYUvJ):
	reWToLljkJG72aSDM0q4uVFwxO(CSjWJNDFL0Hl2IA9fYPtoB643TbZ)
	jpToYkrQKD2eMzWsRLJmXhl = TNuvf0sHO35JtqPga8x(RCBXDnhK3jHYUvJ)
	for mmJANrSUfes5Rw8lyEpMY2HCg in [fmkZtbRj3ux(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ჻"),xm6jK1ZMuWq5(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫჼ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧჽ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘࡥࡔࡔࠩჾ")]:
		if mmJANrSUfes5Rw8lyEpMY2HCg in TTuO14NzmB.SEND_THESE_EVENTS: TTuO14NzmB.SEND_THESE_EVENTS.remove(mmJANrSUfes5Rw8lyEpMY2HCg)
	SwkKZ8pMra5VFs9zbOnf2Gli0YI(vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧჿ"))
	id,c3tEmP52oQXkU0eIpAjwyrY6G,IC6XSwYirspRHmM,SiLq2mwM5R1ZNXxs83T,fq4zHVKJne2uX9aAR,reason = jpToYkrQKD2eMzWsRLJmXhl[wTLFCOcM26fmYlW7U]
	TLpifAHQXIa9EW,D0Rr29bEPUBdAaKMCXhvz75osS = SiLq2mwM5R1ZNXxs83T.split(llkFwuCyhaP3sK76qO4T(u"ࠬࡢ࡮࠼࠽ࠪᄀ"))
	OOZ9V4c5uT8gEl,mFtyk0Ph4GNuZ5pK,xXQniIulZWFvDCEGR72aLTMH81 = fq4zHVKJne2uX9aAR.split(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭࡜࡯࠽࠾ࠫᄁ"))
	O3QDUsvSbzMPhupmJ8dxXw = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	while O3QDUsvSbzMPhupmJ8dxXw:
		THDJzbLVK2tsI5yiF6cfhM = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠧฯำ๋ะࠬᄂ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧᄃ"),jQv0du1iVxTgAXCM(u"ࠩๅหห๋ษࠡษ็ฮอืูศฬࠪᄄ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"่ࠪส๐โศใࠣห้หูๅษ้หฯࠦ࠺ࠡࠢอฬึ฿ࠠฤ๊ࠣหู๊อࠡษ็ฬึ์วๆฮࠪᄅ"),OOZ9V4c5uT8gEl)
		if THDJzbLVK2tsI5yiF6cfhM==bQGafNLXyFgsZP6ut(u"࠷፽"): HHX2k6Juw4BnGN3 = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠫ฾๎ฯสࠩᄆ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬᄇ"),mFtyk0Ph4GNuZ5pK,jQv0du1iVxTgAXCM(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪᄈ"))
		elif THDJzbLVK2tsI5yiF6cfhM==VhqD3zp7mUieI8sMQlETH(u"࠷፾"): cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED()
		else: O3QDUsvSbzMPhupmJ8dxXw = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if RCBXDnhK3jHYUvJ: ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def ZZ6Em5ke17hKL0vCgzNJcW():
	wXuabJjLsQBfVE()
	zXm9pNrVSwxE = OOnvcPQy85HYA.getSetting(fmkZtbRj3ux(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡧࡦࡩࡨࡦࠩᄉ"))
	SLAiUwpDRoZIQfvB7 = {}
	SLAiUwpDRoZIQfvB7[xdSThjYnuHXAU6M(u"ࠨࡃࡘࡘࡔ࠭ᄊ")] = erqDsJmL3BQHuGtPkcf0X9(u"ࠩส่่อิࠡษ็ฮ้่วว์ࠣ๎฾๋ไࠨᄋ")
	SLAiUwpDRoZIQfvB7[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡗ࡙ࡕࡐࠨᄌ")] = xm6jK1ZMuWq5(u"ࠫฬ๊ใศึ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪᄍ")
	SLAiUwpDRoZIQfvB7[A6Sg45ChDR3BJLYfFH(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ᄎ")] = VhqD3zp7mUieI8sMQlETH(u"࠭ใศึࠣะิอࠠใืํีࠥอไๆั์ࠤ࠳ࠦࠧᄏ")+str(GAXY3gMCpfPZty2cnxUuQ/erqDsJmL3BQHuGtPkcf0X9(u"࠶࠱፿"))+vWNRusF46D7Mi8GpZ(u"ࠧࠡัๅ๎็ฯࠠโไฺࠫᄐ")
	TT7GedWapPILHNj = SLAiUwpDRoZIQfvB7[zXm9pNrVSwxE]
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"ࠨๅสุࠥ࠭ᄑ")+str(GAXY3gMCpfPZty2cnxUuQ/xdSThjYnuHXAU6M(u"࠷࠲ᎀ"))+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࠣำ็๐โสࠩᄒ"),it4DKnryZlx(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩᄓ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫส๐โศใࠣ็ฬ๋ไࠨᄔ"),TT7GedWapPILHNj,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨᄕ"))
	if dcDaPVjr5uyEntR4HFqSb==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠲ᎁ"): TzLhpnkruA0y2Ko5B98 = jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧᄖ")
	elif dcDaPVjr5uyEntR4HFqSb==jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠴ᎂ"): TzLhpnkruA0y2Ko5B98 = jQv0du1iVxTgAXCM(u"ࠧࡂࡗࡗࡓࠬᄗ")
	elif dcDaPVjr5uyEntR4HFqSb==A6Sg45ChDR3BJLYfFH(u"࠶ᎃ"): TzLhpnkruA0y2Ko5B98 = kPCxIUZb1V(u"ࠨࡕࡗࡓࡕ࠭ᄘ")
	else: TzLhpnkruA0y2Ko5B98 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if TzLhpnkruA0y2Ko5B98:
		OOnvcPQy85HYA.setSetting(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡩࡡࡤࡪࡨࠫᄙ"),TzLhpnkruA0y2Ko5B98)
		dOvcn9eLPg6TR = SLAiUwpDRoZIQfvB7[TzLhpnkruA0y2Ko5B98]
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dOvcn9eLPg6TR)
	return
def TzNLuxX5gYJOcK7oIBi931shFjnw():
	SLAiUwpDRoZIQfvB7 = {}
	SLAiUwpDRoZIQfvB7[it4DKnryZlx(u"ࠪࡅ࡚࡚ࡏࠨᄚ")] = it4DKnryZlx(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩᄛ")
	SLAiUwpDRoZIQfvB7[rDG9dZoXRhCJcieUSF0KB(u"ࠬࡇࡓࡌࠩᄜ")] = weh7SGmuTgXOVRcMo1rlLq(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪᄝ")
	SLAiUwpDRoZIQfvB7[vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡔࡖࡒࡔࠬᄞ")] = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫᄟ")
	uyhLX3fbTtJs5AHZWRrc04kEgweQa = OOnvcPQy85HYA.getSetting(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩᄠ"))
	zXm9pNrVSwxE = OOnvcPQy85HYA.getSetting(rDG9dZoXRhCJcieUSF0KB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᄡ"))
	TT7GedWapPILHNj = SLAiUwpDRoZIQfvB7[zXm9pNrVSwxE]+uyhLX3fbTtJs5AHZWRrc04kEgweQa
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩᄢ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫᄣ"),erqDsJmL3BQHuGtPkcf0X9(u"࠭ล๋ไสๅ้ࠥวๆๆࠪᄤ"),TT7GedWapPILHNj,fmkZtbRj3ux(u"ࠧิ์ิๅึࠦࡄࡏࡕ๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎็๎ๅࠡสอัํ๐ไࠡลึ้ฬวࠠศๆ่์ฬู่๊ࠡสุ่๐ัโำสฮࠥหไ๊ࠢฦี็อๅ๊ࠡ฼๊ิࠦศฺุࠣห้์วิࠢํๆํ๋ࠠษฯฯฬࠥ๎ๅ็฻ࠣ์า฼ัࠡส฼ฺࠥอไๆ๊สๆ฾ࠦ࠮ࠡๆอุ฿๐ไࠡีํีๆืࠠࡅࡐࡖࠤ็๋ࠠษษัฮ๏อัࠡษ็ื๏ืแาࠢส่๊์วิสࠣวํࠦโๆࠢหษ๏่วโ้ࠣฬฬ๊ใศ็็ࠫᄥ"))
	if dcDaPVjr5uyEntR4HFqSb==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵ᎄ"): TzLhpnkruA0y2Ko5B98 = vWNRusF46D7Mi8GpZ(u"ࠨࡃࡖࡏࠬᄦ")
	elif dcDaPVjr5uyEntR4HFqSb==jQv0du1iVxTgAXCM(u"࠷ᎅ"): TzLhpnkruA0y2Ko5B98 = JHMxIE4fs1mvQtKW7R(u"ࠩࡄ࡙࡙ࡕࠧᄧ")
	elif dcDaPVjr5uyEntR4HFqSb==it4DKnryZlx(u"࠲ᎆ"): TzLhpnkruA0y2Ko5B98 = vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡗ࡙ࡕࡐࠨᄨ")
	if dcDaPVjr5uyEntR4HFqSb in [jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠲ᎈ"),jQv0du1iVxTgAXCM(u"࠲ᎇ")]:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(Gj3rMP1Cb8wHdp49la0(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᄩ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ู๊ࠬาใิ࠾ࠥ࠭ᄪ")+TTuO14NzmB.DNS_SERVERS[UD4N8MjVTd],fmkZtbRj3ux(u"࠭ำ๋ำไี࠿ࠦࠧᄫ")+TTuO14NzmB.DNS_SERVERS[wTLFCOcM26fmYlW7U],wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠧฤะอหึࠦำ๋ำไีࠥࡊࡎࡔࠢส่๊์วิส่่ࠣ࠭ᄬ"))
		if ug0EmiKYnRT1qeH9MFyr3pO==xdSThjYnuHXAU6M(u"࠴ᎉ"): wpLgr9cfSKjUhlk6PHavRzMb = TTuO14NzmB.DNS_SERVERS[wTLFCOcM26fmYlW7U]
		else: wpLgr9cfSKjUhlk6PHavRzMb = TTuO14NzmB.DNS_SERVERS[UD4N8MjVTd]
	elif dcDaPVjr5uyEntR4HFqSb==xdSThjYnuHXAU6M(u"࠶ᎊ"): wpLgr9cfSKjUhlk6PHavRzMb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: TzLhpnkruA0y2Ko5B98 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if TzLhpnkruA0y2Ko5B98:
		OOnvcPQy85HYA.setSetting(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᄭ"),TzLhpnkruA0y2Ko5B98)
		OOnvcPQy85HYA.setSetting(JHMxIE4fs1mvQtKW7R(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩᄮ"),wpLgr9cfSKjUhlk6PHavRzMb)
		dOvcn9eLPg6TR = SLAiUwpDRoZIQfvB7[TzLhpnkruA0y2Ko5B98]+wpLgr9cfSKjUhlk6PHavRzMb
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dOvcn9eLPg6TR)
	return
def PGe3ZEOFkWzU54Xf06pnwVY8KgR():
	zXm9pNrVSwxE = OOnvcPQy85HYA.getSetting(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᄯ"))
	SLAiUwpDRoZIQfvB7 = {}
	SLAiUwpDRoZIQfvB7[DpRJnas65uVcO0S17dYG(u"ࠫࡆ࡛ࡔࡐࠩᄰ")] = weh7SGmuTgXOVRcMo1rlLq(u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭ᄱ")
	SLAiUwpDRoZIQfvB7[erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡁࡔࡍࠪᄲ")] = it4DKnryZlx(u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨᄳ")
	SLAiUwpDRoZIQfvB7[yRWQMHxZEz0(u"ࠨࡕࡗࡓࡕ࠭ᄴ")] = kPCxIUZb1V(u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫᄵ")
	TT7GedWapPILHNj = SLAiUwpDRoZIQfvB7[zXm9pNrVSwxE]
	dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨᄶ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪᄷ"),w8JC1y7Lp3(u"ࠬห๊ใษไࠤ่อๅๅࠩᄸ"),TT7GedWapPILHNj,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭วๅสิ์ู่๊้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์฼้้่ࠦิ์ฺࠤอ๐ๆࠡฮ๊หื้้ࠠษ็ษ๋ะั็์อࠤ࠳ࠦ็้ࠢํืฯ๊ๅูࠡ็ฬฬะใ๊ࠡํๆํ๋ࠠษีะฬ์อࠠษั็ห๋ࠥๆไࠢฮ้ࠥ๐ศฺอ๊ห๊ࠥใࠡ࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣว๊ࠦล๋ไสๅࠥอไษำ๋็ุ๐ࠠภࠩᄹ"))
	if dcDaPVjr5uyEntR4HFqSb==lCT8hfYUBX4OQMmL(u"࠵ᎋ"): TzLhpnkruA0y2Ko5B98 = xdSThjYnuHXAU6M(u"ࠧࡂࡕࡎࠫᄺ")
	elif dcDaPVjr5uyEntR4HFqSb==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠷ᎌ"): TzLhpnkruA0y2Ko5B98 = JHMxIE4fs1mvQtKW7R(u"ࠨࡃࡘࡘࡔ࠭ᄻ")
	elif dcDaPVjr5uyEntR4HFqSb==fmkZtbRj3ux(u"࠲ᎍ"): TzLhpnkruA0y2Ko5B98 = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡖࡘࡔࡖࠧᄼ")
	else: TzLhpnkruA0y2Ko5B98 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if TzLhpnkruA0y2Ko5B98:
		OOnvcPQy85HYA.setSetting(D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᄽ"),TzLhpnkruA0y2Ko5B98)
		dOvcn9eLPg6TR = SLAiUwpDRoZIQfvB7[TzLhpnkruA0y2Ko5B98]
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dOvcn9eLPg6TR)
	return
def ZgP6MtUwIVNz1oBXiTK():
	HrdRpuMU2Ta5 = OOnvcPQy85HYA.getSetting(bQGafNLXyFgsZP6ut(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᄾ"))
	if HrdRpuMU2Ta5==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࡙ࠬࡔࡐࡒࠪᄿ"): header = gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅห๊ๅๅࠬᅀ")
	else: header = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆใ฼่ࠬᅁ")
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠨวํๆฬ็ࠧᅂ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠩอๅ฾๐ไࠨᅃ"),header,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧᅄ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==-VhqD3zp7mUieI8sMQlETH(u"࠲ᎎ"): return
	elif ug0EmiKYnRT1qeH9MFyr3pO:
		OOnvcPQy85HYA.setSetting(VhqD3zp7mUieI8sMQlETH(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᅅ"),Gj3rMP1Cb8wHdp49la0(u"ࠬࡇࡕࡕࡑࠪᅆ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨᅇ"))
	else:
		OOnvcPQy85HYA.setSetting(kPCxIUZb1V(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧᅈ"),A6Sg45ChDR3BJLYfFH(u"ࠨࡕࡗࡓࡕ࠭ᅉ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,xdSThjYnuHXAU6M(u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫᅊ"))
	return
def Puk5RwzYjAysBgbdShD6GroK():
	gg7qGaQhBKEfNt4w3Yvexk9Dj8br = OOnvcPQy85HYA.getSetting(kPCxIUZb1V(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᅋ"))
	if gg7qGaQhBKEfNt4w3Yvexk9Dj8br==fmkZtbRj3ux(u"ࠫࡘ࡚ࡏࡑࠩᅌ"): header = llkFwuCyhaP3sK76qO4T(u"ࠬาไษࠢส่็๎วว็้๋ࠣࠦวๅว้ฮึ์สࠡ็อ์็็ࠧᅍ")
	else: header = it4DKnryZlx(u"࠭ฬๅสࠣห้่่ศศ่ࠤ๊์ࠠศๆศ๊ฯืๆห่ࠢๅ฾๊ࠧᅎ")
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"ࠧฦ์ๅหๆ࠭ᅏ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨฬไ฽๏๊ࠧᅐ"),header,A6Sg45ChDR3BJLYfFH(u"ࠩๅ์ฬฬๅࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฯษุอࠥอไๆฯฯ์อฯࠠๆ็ๆ๊ࠥะฮำ์้๋ฬࠦแ๋ࠢส่ส์สา่อࠤๆ๐ࠠิ์ิๅึอสࠡๆสࠤ๏๎ฬะࠢไ๎์อࠠๆึๆ่ฮࠦออสࠣ࠲࠳ࠦ็ั้ࠣห้฽ั๋ไฬࠤฯูวฺัࠣๅ๏ࠦโาษฤอࠥ๎วิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็้าา่ษห่่ࠣ์ࠠๆ่้ࠣํู่ࠡสา๎้ࠦๅห๊ไีࠥ๎ฺ๋ำ้ࠣาา่ษࠢ࡟ࡲࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅࠢฦ้ࠥห๊ใษไࠤั๊ศࠡษ็ๆํอฦๆ่๊ࠢࠥอไฦ่อี๋ะࠠภࠣࠤࠫᅑ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==-Gj3rMP1Cb8wHdp49la0(u"࠳ᎏ"): return
	elif ug0EmiKYnRT1qeH9MFyr3pO:
		OOnvcPQy85HYA.setSetting(TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᅒ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡆ࡛ࡔࡐࠩᅓ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"ࠬะๅࠡฬไ฽๏๊ࠠอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็์๏ฮࠧᅔ"))
	else:
		OOnvcPQy85HYA.setSetting(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡸࡧࡥࡧࡦࡩࡨࡦࠩᅕ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡔࡖࡒࡔࠬᅖ"))
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨฬ่ࠤส๐โศใࠣะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊่๋สࠪᅗ"))
	return
def WFXLiSq0we7v1MtO2V4cNuZDpBm6a(eIRJAgj25bzvNik48puZl3OPUq):
	if eIRJAgj25bzvNik48puZl3OPUq!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
		eIRJAgj25bzvNik48puZl3OPUq = ixCwD64eNn8zKkm2Jb(eIRJAgj25bzvNik48puZl3OPUq)
		eIRJAgj25bzvNik48puZl3OPUq = eIRJAgj25bzvNik48puZl3OPUq.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		Z4fIB0elNwD3EnY = Gj3rMP1Cb8wHdp49la0(u"࠴࠴࠶࠶࠳᎐")
		mlwSDqc5fo7RpeUH8X = llfAzdjaVLTbyZW7op9i.Window(Z4fIB0elNwD3EnY)
		mlwSDqc5fo7RpeUH8X.getControl(kPCxIUZb1V(u"࠷࠶࠷᎑")).setLabel(eIRJAgj25bzvNik48puZl3OPUq)
	return
n8ZzIyeKEPAM1X3UN = [
			 D2PpKMeZFWrmfxTSs4L1tz(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢᅘ")
			,rDG9dZoXRhCJcieUSF0KB(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭ᅙ")
			,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ᅚ")
			,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧᅛ")
			,rDG9dZoXRhCJcieUSF0KB(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧᅜ")
			,it4DKnryZlx(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩᅝ")
			,rDG9dZoXRhCJcieUSF0KB(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧᅞ")+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࠦࠫᅟ")+A6Sg45ChDR3BJLYfFH(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩᅠ")
			,kPCxIUZb1V(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧᅡ")
			,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨᅢ")
			,DpRJnas65uVcO0S17dYG(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧᅣ")
			,yRWQMHxZEz0(u"ࠧ࡟ࡠࡡࡢࡣ࠭ᅤ")
			,weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ᅥ")
			,Gj3rMP1Cb8wHdp49la0(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬᅦ")
			,D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨᅧ")
			]
def C6CsYfe7OEcqpUtILWluVQJnb9oK(yqH8GM4tr32YXobgA9ZkhsSj0B):
	if JHMxIE4fs1mvQtKW7R(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩᅨ") in yqH8GM4tr32YXobgA9ZkhsSj0B and rDG9dZoXRhCJcieUSF0KB(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᅩ") in yqH8GM4tr32YXobgA9ZkhsSj0B: return y0yvdNOZkiKEg5RLMhoDVQAB9F2
	for eIRJAgj25bzvNik48puZl3OPUq in n8ZzIyeKEPAM1X3UN:
		if eIRJAgj25bzvNik48puZl3OPUq in yqH8GM4tr32YXobgA9ZkhsSj0B: return y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return Z19pUxa2gfGMNKoDsEuytn85SjFvA
def ZYzX5w3yorAq(data):
	lH80syLThOjuiUvPRDFW9pNfomt = rDG9dZoXRhCJcieUSF0KB(u"࠽᎓") if wwMdFkWvcRYiXHB7yDrCqnKb98o else bQGafNLXyFgsZP6ut(u"࠶࠻᎒")
	data = data.replace(lCT8hfYUBX4OQMmL(u"࠳࠱᎔")*UKFZBQAVXHI5s17LyvuRpCY2,lH80syLThOjuiUvPRDFW9pNfomt*UKFZBQAVXHI5s17LyvuRpCY2)
	data = data.replace(xm6jK1ZMuWq5(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬᅪ"),rDG9dZoXRhCJcieUSF0KB(u"ࠧ࠻ࠢࠪᅫ"))
	FjUcS938pAH5sZ = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for yqH8GM4tr32YXobgA9ZkhsSj0B in data.splitlines():
		WLRACDUnPw824OedsIfoF5ySVYkx = jj0dZrgiKb.findall(rDG9dZoXRhCJcieUSF0KB(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᅬ"),yqH8GM4tr32YXobgA9ZkhsSj0B,jj0dZrgiKb.DOTALL)
		if WLRACDUnPw824OedsIfoF5ySVYkx: yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(WLRACDUnPw824OedsIfoF5ySVYkx[wTLFCOcM26fmYlW7U],wUvcPrYDfISbZolAm83GKEqMyXkn5)
		FjUcS938pAH5sZ += QWLr8ABjev+yqH8GM4tr32YXobgA9ZkhsSj0B
	return FjUcS938pAH5sZ
def eV4RNS5ogFY8v3idLhZkwbaUDf10K(pWcSBk8l9n1jRE5rPi3gC):
	if DpRJnas65uVcO0S17dYG(u"ࠩࡒࡐࡉ࠭ᅭ") in pWcSBk8l9n1jRE5rPi3gC:
		AJxtZkgTHFdXsnBvC7PYIwcQL356 = bbnFV8pDuRGWkl2yMge9S
		header = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪᅮ")
	else:
		AJxtZkgTHFdXsnBvC7PYIwcQL356 = tiIwFLAE7eaJ3bCxGqumDPNZ2
		header = A6Sg45ChDR3BJLYfFH(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫᅯ")
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,header,fmkZtbRj3ux(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨᅰ"))
	if ug0EmiKYnRT1qeH9MFyr3pO!=DpRJnas65uVcO0S17dYG(u"࠲᎕"): return
	kmSzXphYlfL2K4cQj,QHPnObBLYWmN6oZfag = [],xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠲᎖")
	size,count = xDXC5AF31hBZ2gRGJafuK6zENQMO(AJxtZkgTHFdXsnBvC7PYIwcQL356)
	file = open(AJxtZkgTHFdXsnBvC7PYIwcQL356,s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡲࡣࠩᅱ"))
	if size>it4DKnryZlx(u"࠵࠵࠶࠲࠱࠲᎘"): file.seek(-ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠴࠴࠵࠷࠰࠱᎗"),b7i1PgC8Z4e5BFoHNd9E2UVvfc.SEEK_END)
	data = file.read()
	file.close()
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: data = data.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	data = ZYzX5w3yorAq(data)
	sDMqyG0jAOK = data.split(QWLr8ABjev)
	for yqH8GM4tr32YXobgA9ZkhsSj0B in reversed(sDMqyG0jAOK):
		nX0H72oCEQ4WpF1g = C6CsYfe7OEcqpUtILWluVQJnb9oK(yqH8GM4tr32YXobgA9ZkhsSj0B)
		if nX0H72oCEQ4WpF1g: continue
		yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩᅲ"),QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+kPCxIUZb1V(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᅳ")+AAByQSLgaZwCsKnvc5eWNmY)
		yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩᅴ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ᅵ")+fmkZtbRj3ux(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫᅶ")+AAByQSLgaZwCsKnvc5eWNmY)
		FMUZCP7HStnrc1hiq6mEpg5QxLIXd = wUvcPrYDfISbZolAm83GKEqMyXkn5
		F7y3xwnEsTAm9dPz16CRgqY2HioLj = jj0dZrgiKb.findall(DpRJnas65uVcO0S17dYG(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᅷ"),yqH8GM4tr32YXobgA9ZkhsSj0B,jj0dZrgiKb.DOTALL)
		if F7y3xwnEsTAm9dPz16CRgqY2HioLj:
			yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U],F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][UD4N8MjVTd]).replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][Tb7oymMnpflsSv3eu4Pz2],wUvcPrYDfISbZolAm83GKEqMyXkn5)
			FMUZCP7HStnrc1hiq6mEpg5QxLIXd = F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][UD4N8MjVTd]
		else:
			F7y3xwnEsTAm9dPz16CRgqY2HioLj = jj0dZrgiKb.findall(ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ᅸ"),yqH8GM4tr32YXobgA9ZkhsSj0B,jj0dZrgiKb.DOTALL)
			if F7y3xwnEsTAm9dPz16CRgqY2HioLj:
				yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][UD4N8MjVTd],wUvcPrYDfISbZolAm83GKEqMyXkn5)
				FMUZCP7HStnrc1hiq6mEpg5QxLIXd = F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U]
		if FMUZCP7HStnrc1hiq6mEpg5QxLIXd: yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(FMUZCP7HStnrc1hiq6mEpg5QxLIXd,JegF7SlMawI03+FMUZCP7HStnrc1hiq6mEpg5QxLIXd+AAByQSLgaZwCsKnvc5eWNmY)
		kmSzXphYlfL2K4cQj.append(yqH8GM4tr32YXobgA9ZkhsSj0B)
		if len(str(kmSzXphYlfL2K4cQj))>dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠺࠶࠱࠱࠲᎙"): break
	kmSzXphYlfL2K4cQj = reversed(kmSzXphYlfL2K4cQj)
	tt3lHyBTCrisJKfh = QWLr8ABjev.join(kmSzXphYlfL2K4cQj)
	sNQlowOJdgWBt2cyV18ZI6Ye(vvhR5ozeiJpANyl8fFO3GBw(u"ࠧ࡭ࡧࡩࡸࠬᅹ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬᅺ"),tt3lHyBTCrisJKfh,JHMxIE4fs1mvQtKW7R(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᅻ"))
	return
def jusaGP7rYwp5ATMtQJ1x9XCUobR():
	YRdSwOtshHoB = open(IIkEcaWTqldjmbYPD5OSXveNFs4,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡶࡧ࠭ᅼ")).read()
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: YRdSwOtshHoB = YRdSwOtshHoB.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	YRdSwOtshHoB = YRdSwOtshHoB.replace(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡡࡺࠧᅽ"),lCT8hfYUBX4OQMmL(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧᅾ"))
	WzcgrtpJ9X6lYCD = jj0dZrgiKb.findall(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧᅿ"),YRdSwOtshHoB,jj0dZrgiKb.DOTALL)
	for yqH8GM4tr32YXobgA9ZkhsSj0B in WzcgrtpJ9X6lYCD:
		YRdSwOtshHoB = YRdSwOtshHoB.replace(yqH8GM4tr32YXobgA9ZkhsSj0B,QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+yqH8GM4tr32YXobgA9ZkhsSj0B+AAByQSLgaZwCsKnvc5eWNmY)
	XODdc0rwio9amnFLuIkjRsZ(bQGafNLXyFgsZP6ut(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨᆀ"),YRdSwOtshHoB)
	return
def IR5JjYk0sDToNO3te2G4XM6Ubl():
	Kj04L1bcTNuOoUz3Yg = TNw1pBHb8CtSZe0EFxuJqI(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪᆁ")
	OOZ9V4c5uT8gEl = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ᆂ")
	mFtyk0Ph4GNuZ5pK = bQGafNLXyFgsZP6ut(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ᆃ")
	SLAiUwpDRoZIQfvB7 = Kj04L1bcTNuOoUz3Yg+llkFwuCyhaP3sK76qO4T(u"ࠫ࠿ࠦࠧᆄ")+OOZ9V4c5uT8gEl+VhqD3zp7mUieI8sMQlETH(u"ࠬࠦ࠮ࠡࠩᆅ")+mFtyk0Ph4GNuZ5pK
	sNQlowOJdgWBt2cyV18ZI6Ye(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆆ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7,kPCxIUZb1V(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᆇ"))
	return
def UJgqTYtFZ5l1EvzsfRI(type,SLAiUwpDRoZIQfvB7,showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2,url=wUvcPrYDfISbZolAm83GKEqMyXkn5,xVwDZbA6EOjpgX0=wUvcPrYDfISbZolAm83GKEqMyXkn5,eIRJAgj25bzvNik48puZl3OPUq=wUvcPrYDfISbZolAm83GKEqMyXkn5,ddD6eo5yB9MSLA=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	wixT3QUON67F = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if not TTuO14NzmB.lOuLW0pjdgS4zX:
		if showDialogs:
			GyoxQq9AuS1ItRND6maKf = (D2PpKMeZFWrmfxTSs4L1tz(u"ࠨษ็ื฼ื࠺ࠨᆈ") in SLAiUwpDRoZIQfvB7 and fmkZtbRj3ux(u"ࠩส่๊้ว็࠼ࠪᆉ") in SLAiUwpDRoZIQfvB7 and weh7SGmuTgXOVRcMo1rlLq(u"ࠪห้๋ไโ࠼ࠪᆊ") in SLAiUwpDRoZIQfvB7 and dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫฬ๊ฮุลࠪᆋ") in SLAiUwpDRoZIQfvB7 and xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬอไๆืาี࠿࠭ᆌ") in SLAiUwpDRoZIQfvB7)
			if not GyoxQq9AuS1ItRND6maKf: wixT3QUON67F = T4dIruOctCl2qwYNE0SDyU(jQv0du1iVxTgAXCM(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆍ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫᆎ"),SLAiUwpDRoZIQfvB7.replace(DpRJnas65uVcO0S17dYG(u"ࠨ࡞࡟ࡲࠬᆏ"),QWLr8ABjev))
	elif showDialogs:
		SLAiUwpDRoZIQfvB7 = DpRJnas65uVcO0S17dYG(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩᆐ")
		wwi7BpSqEFUcsxGuOtyRm = T4dIruOctCl2qwYNE0SDyU(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡧࡪࡴࡴࡦࡴࠪᆑ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᆒ")+yRWQMHxZEz0(u"ࠬࠦࠠ࠲࠱࠸ࠫᆓ"),kPCxIUZb1V(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᆔ"))
		sOmXvlBJVptG91 = T4dIruOctCl2qwYNE0SDyU(JHMxIE4fs1mvQtKW7R(u"ࠧࡤࡧࡱࡸࡪࡸࠧᆕ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᆖ")+erqDsJmL3BQHuGtPkcf0X9(u"ࠩࠣࠤ࠷࠵࠵ࠨᆗ"),bQGafNLXyFgsZP6ut(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᆘ"))
		cAEnUhy4xP9ebHr6VZ2igqa5wpd1 = T4dIruOctCl2qwYNE0SDyU(A6Sg45ChDR3BJLYfFH(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆙ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬᆚ")+erqDsJmL3BQHuGtPkcf0X9(u"࠭ࠠࠡ࠵࠲࠹ࠬᆛ"),jQv0du1iVxTgAXCM(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᆜ"))
		lcdgX9pZhj = T4dIruOctCl2qwYNE0SDyU(kPCxIUZb1V(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᆝ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᆞ")+JHMxIE4fs1mvQtKW7R(u"ࠪࠤࠥ࠺࠯࠶ࠩᆟ"),xdSThjYnuHXAU6M(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᆠ"))
		wixT3QUON67F = T4dIruOctCl2qwYNE0SDyU(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᆡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᆢ")+xm6jK1ZMuWq5(u"ࠧࠡࠢ࠸࠳࠺࠭ᆣ"),vWNRusF46D7Mi8GpZ(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᆤ"))
	c3tEmP52oQXkU0eIpAjwyrY6G = pnhyIzwgbCTmxs(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	OCZTF9UXGdwxVYRtg = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡄ࡚࠿ࠦࠧᆥ")+c3tEmP52oQXkU0eIpAjwyrY6G+s149dk8uh2p7oFzaLxZeI3Or(u"ࠪ࠱ࠬᆦ")+type
	GkOVdCM4JeXvb3gPFj = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if jQv0du1iVxTgAXCM(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧᆧ") in eIRJAgj25bzvNik48puZl3OPUq else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if not wixT3QUON67F:
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨᆨ"))
		return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	l8fHsgAWkIxt = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬᆩ"))
	SLAiUwpDRoZIQfvB7 += jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭ᆪ")+D1DBSuO0lLGRbcfCyY+s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࠢ࠽ࡠࡡࡴࠧᆫ")
	SLAiUwpDRoZIQfvB7 += ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪᆬ")+c3tEmP52oQXkU0eIpAjwyrY6G+D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩᆭ")+RyDst4Oxmaqb0U7vljKYI2V+rDG9dZoXRhCJcieUSF0KB(u"ࠫࠥࡀ࡜࡝ࡰࠪᆮ")
	SLAiUwpDRoZIQfvB7 += w8JC1y7Lp3(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪᆯ")+l8fHsgAWkIxt
	TbLGvkW8jF3sdlBaCP65SzmV4i = uj5sWQJSqg9XZYy4Nahz0d6erxl()
	TbLGvkW8jF3sdlBaCP65SzmV4i = TbLGvkW8jF3sdlBaCP65SzmV4i.replace(D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࠬ࠭ࠩᆰ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠭ࠩᆱ"))
	TbLGvkW8jF3sdlBaCP65SzmV4i = vvLTYxVfrbDza(TbLGvkW8jF3sdlBaCP65SzmV4i)
	if TbLGvkW8jF3sdlBaCP65SzmV4i: SLAiUwpDRoZIQfvB7 += jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪᆲ")+TbLGvkW8jF3sdlBaCP65SzmV4i
	if url: SLAiUwpDRoZIQfvB7 += Gj3rMP1Cb8wHdp49la0(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ᆳ")+url
	if xVwDZbA6EOjpgX0: SLAiUwpDRoZIQfvB7 += xdSThjYnuHXAU6M(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪᆴ")+xVwDZbA6EOjpgX0
	SLAiUwpDRoZIQfvB7 += TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࠥࡀ࡜࡝ࡰࠪᆵ")
	if showDialogs: hg79cQmoVfMCukiU8ERpT6JqywSrN3(JHMxIE4fs1mvQtKW7R(u"ࠬาวา์ࠣห้หัิษ็ࠫᆶ"),JHMxIE4fs1mvQtKW7R(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨᆷ"))
	if GkOVdCM4JeXvb3gPFj:
		if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧᆸ") in eIRJAgj25bzvNik48puZl3OPUq: rAhMoKxUWX6FLG1DEpeY2Q = bbnFV8pDuRGWkl2yMge9S
		else: rAhMoKxUWX6FLG1DEpeY2Q = tiIwFLAE7eaJ3bCxGqumDPNZ2
		if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(rAhMoKxUWX6FLG1DEpeY2Q):
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,DpRJnas65uVcO0S17dYG(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ᆹ"))
			return Z19pUxa2gfGMNKoDsEuytn85SjFvA
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࠱ࡠࡹࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡷ࡬ࡪࠦ࡬ࡰࡩࡩ࡭ࡱ࡫ࠧᆺ"))
		kmSzXphYlfL2K4cQj,QHPnObBLYWmN6oZfag = [],bQGafNLXyFgsZP6ut(u"࠶᎚")
		file = open(rAhMoKxUWX6FLG1DEpeY2Q,w8JC1y7Lp3(u"ࠪࡶࡧ࠭ᆻ"))
		size,count = xDXC5AF31hBZ2gRGJafuK6zENQMO(rAhMoKxUWX6FLG1DEpeY2Q)
		if size>s149dk8uh2p7oFzaLxZeI3Or(u"࠳࠱࠳࠳࠴࠵᎛"): file.seek(-s149dk8uh2p7oFzaLxZeI3Or(u"࠳࠱࠳࠳࠴࠵᎛"),b7i1PgC8Z4e5BFoHNd9E2UVvfc.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		data = ZYzX5w3yorAq(data)
		sDMqyG0jAOK = data.splitlines()
		for yqH8GM4tr32YXobgA9ZkhsSj0B in reversed(sDMqyG0jAOK):
			nX0H72oCEQ4WpF1g = C6CsYfe7OEcqpUtILWluVQJnb9oK(yqH8GM4tr32YXobgA9ZkhsSj0B)
			if nX0H72oCEQ4WpF1g: continue
			F7y3xwnEsTAm9dPz16CRgqY2HioLj = jj0dZrgiKb.findall(vWNRusF46D7Mi8GpZ(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫᆼ"),yqH8GM4tr32YXobgA9ZkhsSj0B,jj0dZrgiKb.DOTALL)
			if F7y3xwnEsTAm9dPz16CRgqY2HioLj:
				yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U],F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][UD4N8MjVTd]).replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][Tb7oymMnpflsSv3eu4Pz2],wUvcPrYDfISbZolAm83GKEqMyXkn5)
			else:
				F7y3xwnEsTAm9dPz16CRgqY2HioLj = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᆽ"),yqH8GM4tr32YXobgA9ZkhsSj0B,jj0dZrgiKb.DOTALL)
				if F7y3xwnEsTAm9dPz16CRgqY2HioLj: yqH8GM4tr32YXobgA9ZkhsSj0B = yqH8GM4tr32YXobgA9ZkhsSj0B.replace(F7y3xwnEsTAm9dPz16CRgqY2HioLj[wTLFCOcM26fmYlW7U][UD4N8MjVTd],wUvcPrYDfISbZolAm83GKEqMyXkn5)
			kmSzXphYlfL2K4cQj.append(yqH8GM4tr32YXobgA9ZkhsSj0B)
			if len(str(kmSzXphYlfL2K4cQj))>D2PpKMeZFWrmfxTSs4L1tz(u"࠳࠷࠴࠴࠵࠶᎜"): break
		kmSzXphYlfL2K4cQj = reversed(kmSzXphYlfL2K4cQj)
		tt3lHyBTCrisJKfh = D2PpKMeZFWrmfxTSs4L1tz(u"࠭࡜ࡳ࡞ࡱࠫᆾ").join(kmSzXphYlfL2K4cQj)
	elif ddD6eo5yB9MSLA: tt3lHyBTCrisJKfh = ddD6eo5yB9MSLA
	else: tt3lHyBTCrisJKfh = wUvcPrYDfISbZolAm83GKEqMyXkn5
	url = TTuO14NzmB.SITESURLS[it4DKnryZlx(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᆿ")][Tb7oymMnpflsSv3eu4Pz2]
	COW137cpIhBMYTSiAR9s2Dlzw = {kPCxIUZb1V(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩᇀ"):OCZTF9UXGdwxVYRtg,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᇁ"):SLAiUwpDRoZIQfvB7,fmkZtbRj3ux(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫᇂ"):tt3lHyBTCrisJKfh}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,xm6jK1ZMuWq5(u"ࠫࡕࡕࡓࡕࠩᇃ"),url,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨᇄ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if fmkZtbRj3ux(u"࠭ࡳࡦࡰࡧࡣࡸࡻࡣࡤࡧࡨࡨࡪࡪࠧᇅ") in II64TLxj3mbqEyh9pHQ8oAv: n453i9Fwpc6bGMuUa2l = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	else: n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if showDialogs:
		if n453i9Fwpc6bGMuUa2l:
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(w8JC1y7Lp3(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪᇆ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩᇇ"))
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨᇈ"),xm6jK1ZMuWq5(u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬᇉ"))
		else:
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(MFhbWia58mP3su0fk2d(u"้๊ࠫริใࠣๅู๊ࠠศๆศีุอไࠨᇊ"),yRWQMHxZEz0(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭ᇋ"))
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,rDG9dZoXRhCJcieUSF0KB(u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫᇌ"))
	return n453i9Fwpc6bGMuUa2l
def WWSAe90v5NXxU6PCHOmazyTYK():
	Kj04L1bcTNuOoUz3Yg = kPCxIUZb1V(u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠤࡲ࡫࡮ࡶࠢ࡬ࡸࡪࡳࡳࠡࡶࡲࠤࡦࠦ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠡࡱࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡇࡲࡢࡤ࡬ࡧࠥ࠴࠮ࠡࡑࡵࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡶ࡬ࡴࡽࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡺࡥࡹࡶࠣࡃࠦ࠭ᇍ")
	OOZ9V4c5uT8gEl = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ้็ࠤฯื๊ะࠢอีั๋ษࠡไ๋หห๋ࠠศๆหี๋อๅอࠢศ่๎ࠦไ฻หࠣวำื้ࠡ฼ํีࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษ฽ํวาࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอࠥลࠡࠨᇎ")
	choice = E74G0qBSpwUPLO56fsReHCl(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡦࡩࡳࡺࡥࡳࠩᇏ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪาึ๎ฬࠡࡇࡻ࡭ࡹ࠭ᇐ"),vWNRusF46D7Mi8GpZ(u"࡙ࠫࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠠหำฯ้ฮ࠭ᇑ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ฿ัษ์ࠣࡅࡷࡧࡢࡪࡥࠪᇒ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,Kj04L1bcTNuOoUz3Yg+Gj3rMP1Cb8wHdp49la0(u"࠭࡜࡯࡞ࡱࠫᇓ")+OOZ9V4c5uT8gEl)
	if choice in [-DpRJnas65uVcO0S17dYG(u"࠳᎝"),kPCxIUZb1V(u"࠳᎞")]: return
	elif choice==rDG9dZoXRhCJcieUSF0KB(u"࠵᎟"):
		import wwvAS2EKIs
		wwvAS2EKIs.cIaz6YjfVqDGkdWPmJnRre80ogO2()
		return
	XgETDUzbfAm5vR2eJp9 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	while XgETDUzbfAm5vR2eJp9:
		XgETDUzbfAm5vR2eJp9 = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		message = fmkZtbRj3ux(u"ࠧฦาสࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ฿๐ัࠡษ็ะ้ีࠠฦๆ์ࠤศ๐ࠠอๆาࠤะอๆ๋ࠢไ๎์ࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡอ่ࠤอ฿ฯ่ษࠣ฾๏ืࠠศๆั฻ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦลัษ่ࠣํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ้อࠠหฺ๊ี๊ࠥใࠡ࠰࠱ࠤฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦ࠮࠯ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋่ใ฻ࠣห้าฺาษไ๎ࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฬ๊ย็ࠢไฮาࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦฟࠢࠩᇔ")
		choice = E74G0qBSpwUPLO56fsReHCl(bQGafNLXyFgsZP6ut(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇕ"),rDG9dZoXRhCJcieUSF0KB(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬᇖ"),it4DKnryZlx(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫᇗ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠥหๆอๆํึ๏࠭ᇘ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬ฿ฯๆࠢ฻๋ํืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠪᇙ"),message,profile=dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫᇚ"))
		if choice==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠷Ꭰ"):
			message = lCT8hfYUBX4OQMmL(u"ࠧࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡱ࡫ࡴࡵࡧࡵࡷࠥࡺࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡷࡳࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡵ࡮࡭ࡳࠦࡴࡩࡣࡷࠤ࡭ࡧࡶࡦࠢ࡟ࠦࡆࡸࡩࡢ࡮࡟ࠦࠥ࡬࡯࡯ࡶࠣ࠲࠳ࠦࡁ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࡝ࡰࠣࡍ࡫ࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤ࠳࠴ࠠࡕࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦ࡜࡯࡞ࡱࠤࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡱࡳࡼࠦࡴࡰࠢࡲࡴࡪࡴࠠࡵࡪࡨࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡂࠥࠬᇛ")
			choice = E74G0qBSpwUPLO56fsReHCl(JHMxIE4fs1mvQtKW7R(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇜ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬᇝ"),jQv0du1iVxTgAXCM(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫᇞ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤ฾ืศ๋ࠩᇟ"),w8JC1y7Lp3(u"ࠬࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡁࡳࡣࡥ࡭ࡨࠦࡆࡰࡰࡷࠤࠫࠦࡔࡦࡺࡷࠫᇠ"),message,profile=gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫᇡ"))
			if choice==it4DKnryZlx(u"࠸Ꭱ"): XgETDUzbfAm5vR2eJp9 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if choice==erqDsJmL3BQHuGtPkcf0X9(u"࠱Ꭲ"): kO2JhlovxiVMAtcZF9Gsa7C()
	return
def tzT0LF2YZAsKxEnQi():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭ᇢ"))
	return
def lCLUcg9Mv7b06T1a():
	SLAiUwpDRoZIQfvB7 = vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨᇣ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
	return
def cVRvta3J0Op6b():
	SLAiUwpDRoZIQfvB7 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭ᇤ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
	return
def ZxIhNA12noXG7vS9():
	SLAiUwpDRoZIQfvB7 = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧᇥ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ᇦ"),SLAiUwpDRoZIQfvB7)
	return
def I1IfwGo4clgaOTJ3K2drsMPBDE():
	SLAiUwpDRoZIQfvB7 = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪᇧ")
	sNQlowOJdgWBt2cyV18ZI6Ye(weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇨ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7,A6Sg45ChDR3BJLYfFH(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᇩ"))
	return
def OjXuQbJN7pxiR8BaDq():
	Kj04L1bcTNuOoUz3Yg = fmkZtbRj3ux(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩᇪ")
	OOZ9V4c5uT8gEl = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫᇫ")
	mFtyk0Ph4GNuZ5pK = w8JC1y7Lp3(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᇬ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,Kj04L1bcTNuOoUz3Yg,OOZ9V4c5uT8gEl,mFtyk0Ph4GNuZ5pK)
	return
def wXuabJjLsQBfVE():
	OOZ9V4c5uT8gEl = xm6jK1ZMuWq5(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬᇭ")
	OOZ9V4c5uT8gEl += vWNRusF46D7Mi8GpZ(u"ࠬࡢ࡮࡝ࡰࠪᇮ") + A6Sg45ChDR3BJLYfFH(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬᇯ") + str(pHC2Aj4kbc3KDN0aZWBey6QV/kPCxIUZb1V(u"࠷࠲Ꭳ")/kPCxIUZb1V(u"࠷࠲Ꭳ")/pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠴࠷Ꭴ")/pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠶࠴Ꭵ")) + gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࠡึ๊ีࠬᇰ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + fmkZtbRj3ux(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᇱ") + str(CCuNYswqArnRpift4/vWNRusF46D7Mi8GpZ(u"࠺࠵Ꭶ")/vWNRusF46D7Mi8GpZ(u"࠺࠵Ꭶ")/A6Sg45ChDR3BJLYfFH(u"࠷࠺Ꭷ")) + vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࠣ๎ํ๋ࠧᇲ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᇳ") + str(sBTeylAtiQXpFW9wjM5C1m/ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠼࠰Ꭸ")/ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠼࠰Ꭸ")/xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠲࠵Ꭹ")) + jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࠥ๐่ๆࠩᇴ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᇵ") + str(d2priEnu57KztRsm8wCHZ/jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷࠲Ꭺ")/jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠷࠲Ꭺ")) + MFhbWia58mP3su0fk2d(u"࠭ࠠิษ฼อࠬᇶ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + xdSThjYnuHXAU6M(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫᇷ") + str(D0tF2C71Kej5zrAgB6uMJZsI/JHMxIE4fs1mvQtKW7R(u"࠸࠳Ꭻ")/JHMxIE4fs1mvQtKW7R(u"࠸࠳Ꭻ")) + A6Sg45ChDR3BJLYfFH(u"ࠨࠢึห฾ฯࠧᇸ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪᇹ") + str(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X/jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠹࠴Ꭼ")) + JHMxIE4fs1mvQtKW7R(u"ࠪࠤิ่๊ใหࠪᇺ")
	OOZ9V4c5uT8gEl += QWLr8ABjev + fmkZtbRj3ux(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭ᇻ") + str(CSjWJNDFL0Hl2IA9fYPtoB643TbZ) + A6Sg45ChDR3BJLYfFH(u"ࠬࠦฯใ์ๅอࠬᇼ")
	OOZ9V4c5uT8gEl += fmkZtbRj3ux(u"࠭࡜࡯࡞ࡱࠫᇽ") + it4DKnryZlx(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษࠣࠫᇾ") + str(d2priEnu57KztRsm8wCHZ/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")) + DpRJnas65uVcO0S17dYG(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩᇿ") + str(sBTeylAtiQXpFW9wjM5C1m/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")/it4DKnryZlx(u"࠷࠺Ꭾ")) + A6Sg45ChDR3BJLYfFH(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨሀ") + str(D0tF2C71Kej5zrAgB6uMJZsI/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")) + weh7SGmuTgXOVRcMo1rlLq(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์ࠦࠧሁ") + str(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X/xdSThjYnuHXAU6M(u"࠺࠵Ꭽ")) + fmkZtbRj3ux(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭ሂ") + str(CSjWJNDFL0Hl2IA9fYPtoB643TbZ) + Gj3rMP1Cb8wHdp49la0(u"ࠬࠦฯใ์ๅอࠬሃ")
	sNQlowOJdgWBt2cyV18ZI6Ye(llkFwuCyhaP3sK76qO4T(u"࠭ࡲࡪࡩ࡫ࡸࠬሄ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬህ"),OOZ9V4c5uT8gEl,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫሆ"))
	return
def HkLQEFT6uGiCIxhAPazUdBYDjwJXb():
	SLAiUwpDRoZIQfvB7 = it4DKnryZlx(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬሇ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
	return
def VMNlIgH5nqB9v1Ctrdc7pfu():
	SLAiUwpDRoZIQfvB7 = s149dk8uh2p7oFzaLxZeI3Or(u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫለ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
	return
def YY2EWIP4nBx1lMZR0kQqa9pb3():
	SLAiUwpDRoZIQfvB7 = DpRJnas65uVcO0S17dYG(u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨሉ")
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
	return
def vPJxLmRsKl0wWqc7hUN6Ya5yIGe():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪሊ"))
	rrI7hTwM9qCzBF2kgHjSVRNE(fmkZtbRj3ux(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ላ"),y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def jj8AKmt9oTCqb40uNpveaz7l():
	SLAiUwpDRoZIQfvB7  = yRWQMHxZEz0(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩሌ")
	SLAiUwpDRoZIQfvB7 += A6Sg45ChDR3BJLYfFH(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨል")
	SLAiUwpDRoZIQfvB7 += QWLr8ABjev+JegF7SlMawI03+fmkZtbRj3ux(u"ࠩใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึ࠭ሎ")+AAByQSLgaZwCsKnvc5eWNmY+QWLr8ABjev
	SLAiUwpDRoZIQfvB7 += pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪሏ")
	sNQlowOJdgWBt2cyV18ZI6Ye(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡷ࡯ࡧࡩࡶࠪሐ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7,weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨሑ"))
	SLAiUwpDRoZIQfvB7 = erqDsJmL3BQHuGtPkcf0X9(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩሒ")
	SLAiUwpDRoZIQfvB7 += QWLr8ABjev+JegF7SlMawI03+Gj3rMP1Cb8wHdp49la0(u"ࠧࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ሓ")+AAByQSLgaZwCsKnvc5eWNmY
	SLAiUwpDRoZIQfvB7 += jQv0du1iVxTgAXCM(u"ࠨ࡞ࡱࡠࡳ࠭ሔ")+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪሕ")
	SLAiUwpDRoZIQfvB7 += QWLr8ABjev+JegF7SlMawI03+TNw1pBHb8CtSZe0EFxuJqI(u"ฺ้ࠪืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࠬሖ")+AAByQSLgaZwCsKnvc5eWNmY
	SLAiUwpDRoZIQfvB7 += bQGafNLXyFgsZP6ut(u"ࠫࡡࡴ࡜࡯ࠩሗ")+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭መ")
	SLAiUwpDRoZIQfvB7 += JegF7SlMawI03+vWNRusF46D7Mi8GpZ(u"࠭วาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํวࠨሙ")+AAByQSLgaZwCsKnvc5eWNmY
	sNQlowOJdgWBt2cyV18ZI6Ye(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ሚ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7,vWNRusF46D7Mi8GpZ(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫማ"))
	return
def eetMhJGy4kUjoLqHgY3miE():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩሜ"),rDG9dZoXRhCJcieUSF0KB(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤึูววๆ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳ࠭ም")+JegF7SlMawI03+MFhbWia58mP3su0fk2d(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠭ሞ")+AAByQSLgaZwCsKnvc5eWNmY+xm6jK1ZMuWq5(u"ࠬࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࠬሟ")+JegF7SlMawI03+rDG9dZoXRhCJcieUSF0KB(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࠬሠ")+AAByQSLgaZwCsKnvc5eWNmY)
	return
def d2rZYufjkXmPQ7ahW3FVTBKUSp(showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	if not showDialogs: showDialogs = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,kPCxIUZb1V(u"ࠧࡈࡇࡗࠫሡ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧሢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬሣ"))
	if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
		PC5QdYaDyT9Gx4crEWJmOipzAfMR = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		FbwGmC5HsIKyPlTnNueD = kJOzn1CFwXUpVTudGqIm6SvHtjQW2Z(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+DpRJnas65uVcO0S17dYG(u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨሤ")+FbwGmC5HsIKyPlTnNueD+bQGafNLXyFgsZP6ut(u"ࠫࡢ࠭ሥ"))
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,Gj3rMP1Cb8wHdp49la0(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩሦ"))
	else:
		PC5QdYaDyT9Gx4crEWJmOipzAfMR = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪሧ"))
	if not PC5QdYaDyT9Gx4crEWJmOipzAfMR and showDialogs: ccXG3kyK56DMhLsQvE1o()
	return PC5QdYaDyT9Gx4crEWJmOipzAfMR
def ccXG3kyK56DMhLsQvE1o():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,it4DKnryZlx(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭ረ"))
	bN8trgd4AWPM5()
	return
def cdAU15LMjsBqI0PKTWXxVo9Qnvw8ED(eIRJAgj25bzvNik48puZl3OPUq=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	GkOVdCM4JeXvb3gPFj = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if bQGafNLXyFgsZP6ut(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫሩ") not in eIRJAgj25bzvNik48puZl3OPUq:
		GkOVdCM4JeXvb3gPFj = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		dcDaPVjr5uyEntR4HFqSb = E74G0qBSpwUPLO56fsReHCl(xdSThjYnuHXAU6M(u"ࠩࡦࡩࡳࡺࡥࡳࠩሪ"),it4DKnryZlx(u"ࠪาึ๎ฬࠨራ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫสืำศๆู้้ࠣไสࠩሬ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠬหัิษ็ࠤึูวๅหࠪር"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩሮ"))
		if dcDaPVjr5uyEntR4HFqSb in [-MFhbWia58mP3su0fk2d(u"࠷Ꭿ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠰Ꮀ")]: return
		elif dcDaPVjr5uyEntR4HFqSb==DpRJnas65uVcO0S17dYG(u"࠲Ꮁ"):
			GkOVdCM4JeXvb3gPFj = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			eIRJAgj25bzvNik48puZl3OPUq = kPCxIUZb1V(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪሯ")
	if GkOVdCM4JeXvb3gPFj:
		if Gj3rMP1Cb8wHdp49la0(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨሰ") not in eIRJAgj25bzvNik48puZl3OPUq:
			ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(DpRJnas65uVcO0S17dYG(u"ࠩࡦࡩࡳࡺࡥࡳࠩሱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪሲ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫሳ"))
			if ug0EmiKYnRT1qeH9MFyr3pO!=rDG9dZoXRhCJcieUSF0KB(u"࠳Ꮂ"):
				IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨሴ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩስ"))
				return
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไฦ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫሶ"))
	SLAiUwpDRoZIQfvB7 = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA(header=kPCxIUZb1V(u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩሷ"),source=UdbRGoKhcDeI4lVfns5)
	if not SLAiUwpDRoZIQfvB7: return
	if GkOVdCM4JeXvb3gPFj: type = JHMxIE4fs1mvQtKW7R(u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪሸ")
	else: type = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫሹ")
	n453i9Fwpc6bGMuUa2l = UJgqTYtFZ5l1EvzsfRI(type,SLAiUwpDRoZIQfvB7,y0yvdNOZkiKEg5RLMhoDVQAB9F2,wUvcPrYDfISbZolAm83GKEqMyXkn5,xdSThjYnuHXAU6M(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧሺ"),eIRJAgj25bzvNik48puZl3OPUq)
	return
def uiXb2JArCPt1IejlUWZ():
	eIRJAgj25bzvNik48puZl3OPUq = A6Sg45ChDR3BJLYfFH(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩሻ")
	sNQlowOJdgWBt2cyV18ZI6Ye(Gj3rMP1Cb8wHdp49la0(u"࠭ࡲࡪࡩ࡫ࡸࠬሼ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧሽ"),eIRJAgj25bzvNik48puZl3OPUq,yRWQMHxZEz0(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫሾ"))
	eIRJAgj25bzvNik48puZl3OPUq = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬሿ")
	sNQlowOJdgWBt2cyV18ZI6Ye(JHMxIE4fs1mvQtKW7R(u"ࠪࡰࡪ࡬ࡴࠨቀ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩቁ"),eIRJAgj25bzvNik48puZl3OPUq,llkFwuCyhaP3sK76qO4T(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨቂ"))
	return
def XXfl6zEImSdsPa4QFcbOv():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫቃ"))
	YY2EWIP4nBx1lMZR0kQqa9pb3()
	return
def YUfPqoI6wt3WgiNRucQ2Z():
	XeGFW0UC5EjDmQPqSTg9wbYzM = {}
	rWXsctJGYH9hqufTb,I2LgSi3MyaB7qnDzAVdRrxfPmQeN,O4qdiz9EnHMcRhK3 = EfFgNHdZ5VMniPRwz7ys(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	Kj04L1bcTNuOoUz3Yg,OOZ9V4c5uT8gEl,mFtyk0Ph4GNuZ5pK,xXQniIulZWFvDCEGR72aLTMH81,hTmNJuOdo6q,r2rZy9GKQdP,GePrRQzgiyc5thD1qW3NlBUOMXTLop = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	Kj04L1bcTNuOoUz3Yg = lB8tuyg6sxkDVYAaS95K3GI.join(I2LgSi3MyaB7qnDzAVdRrxfPmQeN)
	OOZ9V4c5uT8gEl = lB8tuyg6sxkDVYAaS95K3GI.join(O4qdiz9EnHMcRhK3)
	ZnhcmtjVae6blFx,DDREWaO5Yz9sQfL3Mmlt6,M6MsgiVAYX8E9hRHF = rWXsctJGYH9hqufTb
	for g40I3ZXaeJ8qVywt,Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo,yYkI0JOPZvD in DDREWaO5Yz9sQfL3Mmlt6:
		yYkI0JOPZvD = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(yYkI0JOPZvD)
		yYkI0JOPZvD = yYkI0JOPZvD.strip(UKFZBQAVXHI5s17LyvuRpCY2).strip(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࠡ࠰ࠪቄ"))
		nL3SyhovzIm0URBZJ = g40I3ZXaeJ8qVywt.replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨቅ"),w8JC1y7Lp3(u"ࠩࡄࡔࡎ࠭ቆ"))
		xXQniIulZWFvDCEGR72aLTMH81 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+nL3SyhovzIm0URBZJ+bQGafNLXyFgsZP6ut(u"ࠪ࠾ࠥ࠭ቇ")+AAByQSLgaZwCsKnvc5eWNmY+yYkI0JOPZvD+QWLr8ABjev
		if Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo.isdigit(): XeGFW0UC5EjDmQPqSTg9wbYzM[g40I3ZXaeJ8qVywt] = int(Rbv9GyHklx8UN7jAwZMX1u0JgEdCfo)
	TTsCWnSOeZBi64X2uRHD,K78MDzdb2vXZ,aij1WCX8uTfrURIlge = list(zip(*DDREWaO5Yz9sQfL3Mmlt6))
	for g40I3ZXaeJ8qVywt in sorted(XIuPSfCzic):
		if g40I3ZXaeJ8qVywt not in TTsCWnSOeZBi64X2uRHD:
			xXQniIulZWFvDCEGR72aLTMH81 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+g40I3ZXaeJ8qVywt+fmkZtbRj3ux(u"ࠫ࠿ࠦࠧቈ")+AAByQSLgaZwCsKnvc5eWNmY+lCT8hfYUBX4OQMmL(u"๊ࠬวࠡ์๋ะิ࠭቉")+QWLr8ABjev
			if g40I3ZXaeJ8qVywt not in TTuO14NzmB.non_videos_actions: mFtyk0Ph4GNuZ5pK += lB8tuyg6sxkDVYAaS95K3GI+g40I3ZXaeJ8qVywt
	for yYkI0JOPZvD,QHPnObBLYWmN6oZfag in ZnhcmtjVae6blFx:
		yYkI0JOPZvD = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(yYkI0JOPZvD)
		hTmNJuOdo6q += yYkI0JOPZvD+A6Sg45ChDR3BJLYfFH(u"࠭࠺ࠡࠩቊ")+JegF7SlMawI03+str(QHPnObBLYWmN6oZfag)+AAByQSLgaZwCsKnvc5eWNmY+DQCpAXVq6LHJ0aEFR
	Kj04L1bcTNuOoUz3Yg = Kj04L1bcTNuOoUz3Yg.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	OOZ9V4c5uT8gEl = OOZ9V4c5uT8gEl.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	mFtyk0Ph4GNuZ5pK = mFtyk0Ph4GNuZ5pK.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	v0bHm3PjcnZBNslK8Up9Odf = Kj04L1bcTNuOoUz3Yg+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࠡࠢ࠱࠲ࠥࠦࠧቋ")+OOZ9V4c5uT8gEl
	k2NT0tsmKLGc71HM85  = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ห็฿ࠠอ์าอฺฺࠥๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่๊ࠡࠪࠥอไฤๅฮีࠥหไ๊ࠢส่ศ่ไࠪࠩቌ")+QWLr8ABjev+bQGafNLXyFgsZP6ut(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๊้ࠥ็็๋่๊ࠢࠥ฿ๆะๅࠣ์้๐ำห่๊ࠢࠥอไษำ้ห๊า้ࠠๆสࠤ๊์ࠠศๆ่์็฿ࠧቍ")+QWLr8ABjev
	k2NT0tsmKLGc71HM85 += JegF7SlMawI03+v0bHm3PjcnZBNslK8Up9Odf+AAByQSLgaZwCsKnvc5eWNmY+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡠࡳࡢ࡮ࠨ቎")
	k2NT0tsmKLGc71HM85 += gVpGcN7nxEWLri4DvyAZlU3BQM(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤ๊์็ศࠢส่อืๆศ็ฯࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋ห๊ࠣࠬืสษหࠣวอาฯ๋ࠫࠪ቏")+QWLr8ABjev+xm6jK1ZMuWq5(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅ๋ࠢะํีࠠๆึๆ่ฮูࠦ็ัๆࠤศ๎ࠠโ์ࠣห้๋่ใ฻ࠣวํࠦแ๋ࠢส่อืๆศ็ฯࠫቐ")+QWLr8ABjev
	mFtyk0Ph4GNuZ5pK = lB8tuyg6sxkDVYAaS95K3GI.join(sorted(mFtyk0Ph4GNuZ5pK.split(lB8tuyg6sxkDVYAaS95K3GI)))
	k2NT0tsmKLGc71HM85 += JegF7SlMawI03+mFtyk0Ph4GNuZ5pK+AAByQSLgaZwCsKnvc5eWNmY
	gL65ZeK4lSYVq8nC,WL7Ch9yrUuAm3TQeRH,NuUlTCYoLgK,qpSPUHbIaXnZtB3k2jYvm = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳Ꮃ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳Ꮃ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳Ꮃ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳Ꮃ")
	all = XeGFW0UC5EjDmQPqSTg9wbYzM[it4DKnryZlx(u"࠭ࡁࡍࡎࠪቑ")]
	if D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧቒ") in list(XeGFW0UC5EjDmQPqSTg9wbYzM.keys()): gL65ZeK4lSYVq8nC = XeGFW0UC5EjDmQPqSTg9wbYzM[s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨቓ")]
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪቔ") in list(XeGFW0UC5EjDmQPqSTg9wbYzM.keys()): WL7Ch9yrUuAm3TQeRH = XeGFW0UC5EjDmQPqSTg9wbYzM[yRWQMHxZEz0(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫቕ")]
	if TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨቖ") in list(XeGFW0UC5EjDmQPqSTg9wbYzM.keys()): NuUlTCYoLgK = XeGFW0UC5EjDmQPqSTg9wbYzM[D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ቗")]
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡒࡆࡒࡒࡗࠬቘ") in list(XeGFW0UC5EjDmQPqSTg9wbYzM.keys()): qpSPUHbIaXnZtB3k2jYvm = XeGFW0UC5EjDmQPqSTg9wbYzM[llkFwuCyhaP3sK76qO4T(u"ࠧࡓࡇࡓࡓࡘ࠭቙")]
	ppWgZvKYfQHT85IP1L = all-gL65ZeK4lSYVq8nC-WL7Ch9yrUuAm3TQeRH-NuUlTCYoLgK-qpSPUHbIaXnZtB3k2jYvm
	vziHL4xVFSD81W7X9Noyrdjb,WGIQZeDJwBS1Hy = M6MsgiVAYX8E9hRHF[wTLFCOcM26fmYlW7U]
	vziHL4xVFSD81W7X9Noyrdjb,fKwG9itAgmZ = M6MsgiVAYX8E9hRHF[UD4N8MjVTd]
	JP02nrxdf7bG = WGIQZeDJwBS1Hy-fKwG9itAgmZ
	GePrRQzgiyc5thD1qW3NlBUOMXTLop += QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(fKwG9itAgmZ)+AAByQSLgaZwCsKnvc5eWNmY+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬቚ")
	GePrRQzgiyc5thD1qW3NlBUOMXTLop += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(JP02nrxdf7bG)+AAByQSLgaZwCsKnvc5eWNmY+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭ቛ")
	GePrRQzgiyc5thD1qW3NlBUOMXTLop += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(WGIQZeDJwBS1Hy)+AAByQSLgaZwCsKnvc5eWNmY+xdSThjYnuHXAU6M(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫቜ")
	GePrRQzgiyc5thD1qW3NlBUOMXTLop += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(len(M6MsgiVAYX8E9hRHF[llkFwuCyhaP3sK76qO4T(u"࠶Ꮄ"):]))+AAByQSLgaZwCsKnvc5eWNmY+vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩቝ")
	for XMiAvt4q9HhfwbPNsCnVk8o7RIW,c3tEmP52oQXkU0eIpAjwyrY6G in M6MsgiVAYX8E9hRHF[vWNRusF46D7Mi8GpZ(u"࠷Ꮅ"):]:
		XMiAvt4q9HhfwbPNsCnVk8o7RIW = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(XMiAvt4q9HhfwbPNsCnVk8o7RIW)
		XMiAvt4q9HhfwbPNsCnVk8o7RIW = XMiAvt4q9HhfwbPNsCnVk8o7RIW.strip(UKFZBQAVXHI5s17LyvuRpCY2).strip(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࠦ࠮ࠨ቞"))
		GePrRQzgiyc5thD1qW3NlBUOMXTLop += XMiAvt4q9HhfwbPNsCnVk8o7RIW+VhqD3zp7mUieI8sMQlETH(u"࠭࠺ࠡࠩ቟")+JegF7SlMawI03+str(c3tEmP52oQXkU0eIpAjwyrY6G)+AAByQSLgaZwCsKnvc5eWNmY+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࠡࠢࠣࠫበ")
	r2rZy9GKQdP += QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(ppWgZvKYfQHT85IP1L)+AAByQSLgaZwCsKnvc5eWNmY+xm6jK1ZMuWq5(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭ቡ")
	r2rZy9GKQdP += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(gL65ZeK4lSYVq8nC)+AAByQSLgaZwCsKnvc5eWNmY+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ฺ่ࠩออสࠡีํีๆืࠠࡂࡒࡌࠤ࠿ࠦࠧቢ")
	r2rZy9GKQdP += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(qpSPUHbIaXnZtB3k2jYvm)+AAByQSLgaZwCsKnvc5eWNmY+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ባ")
	r2rZy9GKQdP += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(WL7Ch9yrUuAm3TQeRH)+AAByQSLgaZwCsKnvc5eWNmY+it4DKnryZlx(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨቤ")
	r2rZy9GKQdP += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(NuUlTCYoLgK)+AAByQSLgaZwCsKnvc5eWNmY+w8JC1y7Lp3(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫብ")
	r2rZy9GKQdP += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+str(len(ZnhcmtjVae6blFx))+AAByQSLgaZwCsKnvc5eWNmY+fmkZtbRj3ux(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭ቦ")
	r2rZy9GKQdP += VhqD3zp7mUieI8sMQlETH(u"ࠧ࡝ࡰ࡟ࡲࠬቧ")+hTmNJuOdo6q
	sNQlowOJdgWBt2cyV18ZI6Ye(VhqD3zp7mUieI8sMQlETH(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨቨ"),jQv0du1iVxTgAXCM(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪቩ"),r2rZy9GKQdP,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ቪ"))
	sNQlowOJdgWBt2cyV18ZI6Ye(bQGafNLXyFgsZP6ut(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫቫ"),DpRJnas65uVcO0S17dYG(u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨቬ"),k2NT0tsmKLGc71HM85,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩቭ"))
	sNQlowOJdgWBt2cyV18ZI6Ye(A6Sg45ChDR3BJLYfFH(u"ࠧ࡭ࡧࡩࡸࠬቮ"),yRWQMHxZEz0(u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣหุะฮะ็อࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪቯ"),xXQniIulZWFvDCEGR72aLTMH81,erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪተ"))
	return
def yzYLkJxo9lqIbFTw2BfKvPAua():
	SLAiUwpDRoZIQfvB7 = MFhbWia58mP3su0fk2d(u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࠬቱ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+MFhbWia58mP3su0fk2d(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪቲ")+AAByQSLgaZwCsKnvc5eWNmY+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴࠧታ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+vWNRusF46D7Mi8GpZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵࠧቴ")+AAByQSLgaZwCsKnvc5eWNmY+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ่ࠠา๊ࠤฬ๊ัิษ็อࠥ๎ฺ๋ำ๊ห้ࠥห๋ำ้ࠣํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤฬ๊ศา่ส้ั่ࠦศๆ่ึ๏ีࠠฤ์ูห๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦๅฺๆ๋้ฬะࠠศๆหี๋อๅอࠩት")
	sNQlowOJdgWBt2cyV18ZI6Ye(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨቶ"),mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬቷ"))
	return
def Q6RIl4kCWLPrqONgs8():
	SLAiUwpDRoZIQfvB7 = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨቸ")+QWLr8ABjev+JegF7SlMawI03+TTuO14NzmB.SITESURLS[xdSThjYnuHXAU6M(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪቹ")][wTLFCOcM26fmYlW7U]+AAByQSLgaZwCsKnvc5eWNmY+it4DKnryZlx(u"ࠬࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠩቺ")+JegF7SlMawI03+TTuO14NzmB.SITESURLS[JHMxIE4fs1mvQtKW7R(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬቻ")][UD4N8MjVTd]+AAByQSLgaZwCsKnvc5eWNmY
	SLAiUwpDRoZIQfvB7 += w8JC1y7Lp3(u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼ࠦระ่ส๋ࠥํ่ࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴࠧቼ")+JegF7SlMawI03+TTuO14NzmB.SITESURLS[rDG9dZoXRhCJcieUSF0KB(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧች")][wTLFCOcM26fmYlW7U]+AAByQSLgaZwCsKnvc5eWNmY+xdSThjYnuHXAU6M(u"ࠩࠣࠤࠥࠦร้ࠢࠣࠤࠥ࠭ቾ")+JegF7SlMawI03+TTuO14NzmB.SITESURLS[D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩቿ")][UD4N8MjVTd]+AAByQSLgaZwCsKnvc5eWNmY
	SLAiUwpDRoZIQfvB7 += rDG9dZoXRhCJcieUSF0KB(u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํࠧኀ")+QWLr8ABjev+JegF7SlMawI03+TTuO14NzmB.SITESURLS[D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡌࡉࡍࡇࡖࡣࡘࡕࡕࡓࡅࡈࡗࠬኁ")][wTLFCOcM26fmYlW7U]+AAByQSLgaZwCsKnvc5eWNmY
	sNQlowOJdgWBt2cyV18ZI6Ye(s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ኂ"),bQGafNLXyFgsZP6ut(u"ࠧศๆ่์ฬู่ࠡษ็ีุ๋๊สࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭ኃ"),SLAiUwpDRoZIQfvB7,fmkZtbRj3ux(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫኄ"))
	return
def XXU03kBat5dITH8Wh2LJqZn1(u8QAdSF01m):
	te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(kPCxIUZb1V(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࠨኅ")+u8QAdSF01m+DpRJnas65uVcO0S17dYG(u"ࠪ࠭ࠬኆ"), y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def kO2JhlovxiVMAtcZF9Gsa7C():
	ICwWPArNgl5tj38ZSYdX(DpRJnas65uVcO0S17dYG(u"ࠫࡸࡺ࡯ࡱࠩኇ"))
	te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࡕࡨࡸࡹ࡯࡮ࡨࡵࠬࠦኈ"))
	return
def fPTEApeZGS():
	te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(lCT8hfYUBX4OQMmL(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠭ࠬ኉"), y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	return
def SXIf6EAFQu1Pc7mUagztTDsVbe3M4C():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,rDG9dZoXRhCJcieUSF0KB(u"ࠧๅ็ึั๋ࠥอห๊ํหฯࠦโศศ่อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่็อฦๆหࠣห้ะ๊ࠡฬิ๎ิࠦๅิฯ๊หࠥ๎ไศࠢอำำ๊ࠠฦๆํ๋ฬ่ࠦๅๅ้ࠤออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤศ๎ࠠศีอาิ๋ࠠࠣษ็็๏ฮ่าัࠥࠤํอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡษู฾฼ูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠧኊ"))
	return
def VvAnliH4YeIZCK3XSsx():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,it4DKnryZlx(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫኋ"))
	return
def SzC6YRBUM0Etc83Qb(gfMSuCaE6wvAOhd=yRWQMHxZEz0(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨኌ"),showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	Q0lCeRfj3P4BcbELFqhVaw7Ns = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(yRWQMHxZEz0(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ኍ"))
	data = bbeLsVCqouaSH53E0XmKh4AnFD.loads(Q0lCeRfj3P4BcbELFqhVaw7Ns)
	MNa8o0t7A3HQTJIsO = data[xdSThjYnuHXAU6M(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ኎")][jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡼࡡ࡭ࡷࡨࠫ኏")]
	if ndib93Ol6UojCrEV: MNa8o0t7A3HQTJIsO = MNa8o0t7A3HQTJIsO.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫነ")+MNa8o0t7A3HQTJIsO+DpRJnas65uVcO0S17dYG(u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩኑ")+gfMSuCaE6wvAOhd+A6Sg45ChDR3BJLYfFH(u"ࠨࠢยࠥࠬኒ"))
		if ug0EmiKYnRT1qeH9MFyr3pO!=jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠷Ꮆ"): return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	n453i9Fwpc6bGMuUa2l,K9FGwmWiA0dI,c3gYwz82C4nZeFruOkDT0Ny = DxwYZSObr9RdKk3L1Qs6gel(gfMSuCaE6wvAOhd,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	if n453i9Fwpc6bGMuUa2l:
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫና"))
		a1j30LvDQOi7GV8YhKsm = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(VhqD3zp7mUieI8sMQlETH(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧኔ")+gfMSuCaE6wvAOhd+xdSThjYnuHXAU6M(u"ࠫࠧࢃࡽࠨን"))
		n453i9Fwpc6bGMuUa2l = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡕࡋࠨኖ") in a1j30LvDQOi7GV8YhKsm else Z19pUxa2gfGMNKoDsEuytn85SjFvA
		L5jXH0fZ8TvsESR.sleep(Gj3rMP1Cb8wHdp49la0(u"࠱Ꮇ"))
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭ኗ"))
	elif showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,erqDsJmL3BQHuGtPkcf0X9(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩኘ"))
	return n453i9Fwpc6bGMuUa2l
def bN8trgd4AWPM5():
	url = it4DKnryZlx(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭ኙ")
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,A6Sg45ChDR3BJLYfFH(u"ࠩࡊࡉ࡙࠭ኚ"),url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭ኛ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	MCXK3DhcAg6LOvorpqifm7NU0t = jj0dZrgiKb.findall(erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪኜ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	MCXK3DhcAg6LOvorpqifm7NU0t = MCXK3DhcAg6LOvorpqifm7NU0t[wTLFCOcM26fmYlW7U].split(JHMxIE4fs1mvQtKW7R(u"ࠬ࠳ࠧኝ"))[wTLFCOcM26fmYlW7U]
	pgwPV8khO9HnlyLiRabQF0YAmxK5NU = str(Uy6GWujQiBLhodP)
	xXQniIulZWFvDCEGR72aLTMH81 = ZiCLpR1Tc5vUlPXDWgmhM6j(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็วำ๐ัࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨኞ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+MCXK3DhcAg6LOvorpqifm7NU0t+AAByQSLgaZwCsKnvc5eWNmY
	xXQniIulZWFvDCEGR72aLTMH81 += D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࡝ࡰ࡟ࡲࠬኟ")+xdSThjYnuHXAU6M(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧአ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+pgwPV8khO9HnlyLiRabQF0YAmxK5NU+AAByQSLgaZwCsKnvc5eWNmY
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,xXQniIulZWFvDCEGR72aLTMH81)
	return
def WbZ9iTA1tCq():
	J60JZwTGcW,VVvtWubH4Sn7,JHMc2w1Rkg0sQGyOXx65ezLSphE8 = Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	FQVYaXZDtLB,nKUcLvd7IYkDVPh,RRYUlEIVtgpjAiLBOsfoWa = Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	FloXKDNzIGOJQHct = [jQv0du1iVxTgAXCM(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧኡ"),llkFwuCyhaP3sK76qO4T(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬኢ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪኣ")]
	WzcgrtpJ9X6lYCD = XFMSnPvjbgcRE9tf6z(FloXKDNzIGOJQHct)
	for ggvQikMrmRXYdezZuUwj30WOc in FloXKDNzIGOJQHct:
		if ggvQikMrmRXYdezZuUwj30WOc not in list(WzcgrtpJ9X6lYCD.keys()): continue
		wpkjW8nG0NXofze1daLyqIB5H,ipCGBvu1TIN4nVef20qPQOUWJ3,RmLdrUwX2lzSgDxTGnZ0qQ197Yit,MIyxS2g7BDQrKu0,TDl7WLZnbvVkaCFhYX,FjehKb2kBaHIEg3CpruDRxLytsdJG1,OOAHkWVQpyiUD = WzcgrtpJ9X6lYCD[ggvQikMrmRXYdezZuUwj30WOc]
		if ggvQikMrmRXYdezZuUwj30WOc==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪኤ"):
			FQVYaXZDtLB = wpkjW8nG0NXofze1daLyqIB5H
			nKUcLvd7IYkDVPh = ipCGBvu1TIN4nVef20qPQOUWJ3+kPCxIUZb1V(u"࠭ࠠࠡࠢࠣࠬࠥ࠭እ")+c3o9wjJyYsrzqx6kHVthmPOM4A8b(FjehKb2kBaHIEg3CpruDRxLytsdJG1)+A6Sg45ChDR3BJLYfFH(u"ࠧࠡࠫࠪኦ")
			RRYUlEIVtgpjAiLBOsfoWa = MIyxS2g7BDQrKu0
		elif ggvQikMrmRXYdezZuUwj30WOc==Gj3rMP1Cb8wHdp49la0(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪኧ"):
			J60JZwTGcW = J60JZwTGcW or wpkjW8nG0NXofze1daLyqIB5H
			VVvtWubH4Sn7 += jQv0du1iVxTgAXCM(u"ࠩࠣࠤ࠱ࠦࠠࠨከ")+ipCGBvu1TIN4nVef20qPQOUWJ3+TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࠤࠥࠦࠠࠩࠢࠪኩ")+c3o9wjJyYsrzqx6kHVthmPOM4A8b(FjehKb2kBaHIEg3CpruDRxLytsdJG1)+A6Sg45ChDR3BJLYfFH(u"ࠫࠥ࠯ࠧኪ")
			JHMc2w1Rkg0sQGyOXx65ezLSphE8 += kPCxIUZb1V(u"ࠬࠦࠠ࠭ࠢࠣࠫካ")+MIyxS2g7BDQrKu0
		elif ggvQikMrmRXYdezZuUwj30WOc==D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬኬ"):
			yyG0BW1cPbYIVxdNqJjFnX5CTR6kou = wpkjW8nG0NXofze1daLyqIB5H
			eKmLXQ3nMpadO04kYojIBW2Hi7zvyr = ipCGBvu1TIN4nVef20qPQOUWJ3+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧክ")+c3o9wjJyYsrzqx6kHVthmPOM4A8b(FjehKb2kBaHIEg3CpruDRxLytsdJG1)+xm6jK1ZMuWq5(u"ࠨࠢࠬࠫኮ")
			qqsa4JPXfuEyDAv35pxmr9F = MIyxS2g7BDQrKu0
	VVvtWubH4Sn7 = VVvtWubH4Sn7.strip(xdSThjYnuHXAU6M(u"ࠩࠣࠤ࠱ࠦࠠࠨኯ"))
	JHMc2w1Rkg0sQGyOXx65ezLSphE8 = JHMc2w1Rkg0sQGyOXx65ezLSphE8.strip(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࠤࠥ࠲ࠠࠡࠩኰ"))
	h3Jgd6TZ2S  = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ኱")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+RRYUlEIVtgpjAiLBOsfoWa+AAByQSLgaZwCsKnvc5eWNmY
	h3Jgd6TZ2S += QWLr8ABjev+fmkZtbRj3ux(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧኲ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+nKUcLvd7IYkDVPh+AAByQSLgaZwCsKnvc5eWNmY
	h3Jgd6TZ2S += jQv0du1iVxTgAXCM(u"࠭࡜࡯࡞ࡱࠫኳ")+TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬኴ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+JHMc2w1Rkg0sQGyOXx65ezLSphE8+AAByQSLgaZwCsKnvc5eWNmY
	h3Jgd6TZ2S += QWLr8ABjev+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪኵ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+VVvtWubH4Sn7+AAByQSLgaZwCsKnvc5eWNmY
	h3Jgd6TZ2S += s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ࡟ࡲࡡࡴࠧ኶")+VhqD3zp7mUieI8sMQlETH(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧ኷")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+qqsa4JPXfuEyDAv35pxmr9F+AAByQSLgaZwCsKnvc5eWNmY
	h3Jgd6TZ2S += QWLr8ABjev+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬኸ")+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+eKmLXQ3nMpadO04kYojIBW2Hi7zvyr+AAByQSLgaZwCsKnvc5eWNmY
	wpkjW8nG0NXofze1daLyqIB5H = FQVYaXZDtLB or J60JZwTGcW
	if wpkjW8nG0NXofze1daLyqIB5H:
		header = D2PpKMeZFWrmfxTSs4L1tz(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧኹ")
		Z9e2VLl7DY0 = rDG9dZoXRhCJcieUSF0KB(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧኺ")
	else:
		header = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨኻ")
		Z9e2VLl7DY0 = MFhbWia58mP3su0fk2d(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪኼ")
	oAPbpfTJBFyvOxUN07qGXInw = weh7SGmuTgXOVRcMo1rlLq(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪኽ")
	nv09Z1uGJDl = h3Jgd6TZ2S+erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡠࡳࡢ࡮ࠨኾ")+Z9e2VLl7DY0+rDG9dZoXRhCJcieUSF0KB(u"ࠫࡡࡴ࡜࡯ࠩ኿")+oAPbpfTJBFyvOxUN07qGXInw
	sNQlowOJdgWBt2cyV18ZI6Ye(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡸࡩࡨࡪࡷࠫዀ"),header,nv09Z1uGJDl,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ዁"))
	return wpkjW8nG0NXofze1daLyqIB5H
def sTM2uQCLkm59NdjSAphW(ggvQikMrmRXYdezZuUwj30WOc,OOAHkWVQpyiUD,showDialogs):
	n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if showDialogs:
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,JHMxIE4fs1mvQtKW7R(u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฼ฺู้่้ࠣหึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦไไ์ࠣ๎ฯ๋ࠠหอห๎ฯํฺࠠๆ์ࠤ่๎ฯ๋ࠢ࠱ࠤฬ๊ๅๅใࠣๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢส่ว์ࠠภࠣࠪዂ"))
		if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return Z19pUxa2gfGMNKoDsEuytn85SjFvA
	P7f6uCIXFUnj8NW = Yz9CGVI5S3N1mukQfvK0Z(OOAHkWVQpyiUD,{},showDialogs)
	if P7f6uCIXFUnj8NW:
		wwJXPTWIG25M3tVm8Dj4kYOlp1eA = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(Rj3VsmvbuAdWhUg7ETykSLw,ggvQikMrmRXYdezZuUwj30WOc)
		THqDmj0Frnf38wX7MkVZ1u9NaGi(wwJXPTWIG25M3tVm8Dj4kYOlp1eA,y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		import zipfile as QfNtpKkcwMIHjm4OVzoWy,io as fKXJejsCzFm9TgqwVS0
		ppHZFxaCnIAYfz643LJlyvjOWV = fKXJejsCzFm9TgqwVS0.BytesIO(P7f6uCIXFUnj8NW)
		try:
			aaGbFRd768KE5l3tCzIAhTsBN = QfNtpKkcwMIHjm4OVzoWy.ZipFile(ppHZFxaCnIAYfz643LJlyvjOWV)
			aaGbFRd768KE5l3tCzIAhTsBN.extractall(Rj3VsmvbuAdWhUg7ETykSLw)
			L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
			te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(kPCxIUZb1V(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬዃ"))
			L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
			n453i9Fwpc6bGMuUa2l = FzZ9mBKANWCsY(ggvQikMrmRXYdezZuUwj30WOc)
		except: n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if showDialogs:
		if n453i9Fwpc6bGMuUa2l: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩอ้ࠥฮๆอษะࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ዄ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨዅ"))
	return n453i9Fwpc6bGMuUa2l
def rrI7hTwM9qCzBF2kgHjSVRNE(ggvQikMrmRXYdezZuUwj30WOc,showDialogs=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	if showDialogs==wUvcPrYDfISbZolAm83GKEqMyXkn5: showDialogs = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	JI5qAofxnt = Aq5Wm0ri2dNOQ3Bfs6ogCpyD([ggvQikMrmRXYdezZuUwj30WOc])
	Bn71KM9Jdk,v9jWxUM5SQosbcJa43t7d = JI5qAofxnt[ggvQikMrmRXYdezZuUwj30WOc]
	if v9jWxUM5SQosbcJa43t7d:
		n453i9Fwpc6bGMuUa2l = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭዆")+ggvQikMrmRXYdezZuUwj30WOc+s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨ዇"))
	else:
		n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(JHMxIE4fs1mvQtKW7R(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ወ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,wUvcPrYDfISbZolAm83GKEqMyXkn5+ggvQikMrmRXYdezZuUwj30WOc+D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࠡ࡞ࡱࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ๎วๅสิ๊ฬ๋ฬࠡสะหัฯࠠๅ้สࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫዉ"))
		if ug0EmiKYnRT1qeH9MFyr3pO==vWNRusF46D7Mi8GpZ(u"࠲Ꮈ"):
			te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨዊ")+ggvQikMrmRXYdezZuUwj30WOc+w8JC1y7Lp3(u"ࠩࠬࠫዋ"))
			L5jXH0fZ8TvsESR.sleep(kPCxIUZb1V(u"࠳Ꮉ"))
			te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪዌ"))
			L5jXH0fZ8TvsESR.sleep(VhqD3zp7mUieI8sMQlETH(u"࠴Ꮊ"))
			while te28VJiPB7RXcm6brMUQyKAC3Z.getCondVisibility(DpRJnas65uVcO0S17dYG(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨው")): L5jXH0fZ8TvsESR.sleep(VhqD3zp7mUieI8sMQlETH(u"࠵Ꮋ"))
			n453i9Fwpc6bGMuUa2l = FzZ9mBKANWCsY(ggvQikMrmRXYdezZuUwj30WOc)
			if showDialogs and n453i9Fwpc6bGMuUa2l: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,VhqD3zp7mUieI8sMQlETH(u"ࠬะๅࠡใะูࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬዎ"))
			elif showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,MFhbWia58mP3su0fk2d(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨዏ"))
	return n453i9Fwpc6bGMuUa2l
def oo0Qh9vHrMpKzNyuUlAtmgka(showDialogs):
	if not showDialogs: ug0EmiKYnRT1qeH9MFyr3pO = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	else: ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(it4DKnryZlx(u"ࠧࡤࡧࡱࡸࡪࡸࠧዐ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤศ์ࠠหู็ฬ๋ࠥๆࠡๅ๋ำ๏ࠦแฮืࠣ์ฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣรࠬዑ"))
	if ug0EmiKYnRT1qeH9MFyr3pO==lCT8hfYUBX4OQMmL(u"࠶Ꮌ"):
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(MFhbWia58mP3su0fk2d(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬዒ"))
		if showDialogs:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪዓ"))
	return
def tI6bUVpz9ZSYau():
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩዔ"),fmkZtbRj3ux(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ዕ"))
	bN8trgd4AWPM5()
	wpkjW8nG0NXofze1daLyqIB5H = WbZ9iTA1tCq()
	if wpkjW8nG0NXofze1daLyqIB5H:
		C7tGsABJHNMUxw85pmRKeI0O6(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		oo0Qh9vHrMpKzNyuUlAtmgka(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def FzZ9mBKANWCsY(ggvQikMrmRXYdezZuUwj30WOc):
	RCmHBOKtejQ8lu4L = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩዖ")+ggvQikMrmRXYdezZuUwj30WOc+w8JC1y7Lp3(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ዗"))
	succeeded = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if Gj3rMP1Cb8wHdp49la0(u"ࠨࡑࡎࠫዘ") in RCmHBOKtejQ8lu4L else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return succeeded
def ctG8p7nLWlms4xj(ggvQikMrmRXYdezZuUwj30WOc):
	RCmHBOKtejQ8lu4L = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬዙ")+ggvQikMrmRXYdezZuUwj30WOc+s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩዚ"))
	succeeded = y0yvdNOZkiKEg5RLMhoDVQAB9F2 if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡔࡑࠧዛ") in RCmHBOKtejQ8lu4L else Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return succeeded
def DxwYZSObr9RdKk3L1Qs6gel(ggvQikMrmRXYdezZuUwj30WOc,showDialogs,f5JeBXdUi36cnvIyblF,WzcgrtpJ9X6lYCD=None):
	ug0EmiKYnRT1qeH9MFyr3pO,succeeded,K9FGwmWiA0dI,ipCGBvu1TIN4nVef20qPQOUWJ3 = y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA,A6Sg45ChDR3BJLYfFH(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬዜ"),wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not WzcgrtpJ9X6lYCD: WzcgrtpJ9X6lYCD = XFMSnPvjbgcRE9tf6z([ggvQikMrmRXYdezZuUwj30WOc])
	if ggvQikMrmRXYdezZuUwj30WOc in list(WzcgrtpJ9X6lYCD.keys()):
		wpkjW8nG0NXofze1daLyqIB5H,ipCGBvu1TIN4nVef20qPQOUWJ3,RmLdrUwX2lzSgDxTGnZ0qQ197Yit,MIyxS2g7BDQrKu0,TDl7WLZnbvVkaCFhYX,FjehKb2kBaHIEg3CpruDRxLytsdJG1,OOAHkWVQpyiUD = WzcgrtpJ9X6lYCD[ggvQikMrmRXYdezZuUwj30WOc]
		if FjehKb2kBaHIEg3CpruDRxLytsdJG1==lCT8hfYUBX4OQMmL(u"࠭ࡧࡰࡱࡧࠫዝ"):
			succeeded,K9FGwmWiA0dI = y0yvdNOZkiKEg5RLMhoDVQAB9F2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧ࡯ࡱࡷ࡬࡮ࡴࡧࠨዞ")
			if f5JeBXdUi36cnvIyblF and showDialogs:
				ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,weh7SGmuTgXOVRcMo1rlLq(u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨዟ")+ggvQikMrmRXYdezZuUwj30WOc+xm6jK1ZMuWq5(u"ࠩ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห้ࠣึฯࠠฤะิํࠬዠ"))
				if ug0EmiKYnRT1qeH9MFyr3pO:
					succeeded = sTM2uQCLkm59NdjSAphW(ggvQikMrmRXYdezZuUwj30WOc,OOAHkWVQpyiUD,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
					if succeeded:
						K9FGwmWiA0dI = erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡶࡪ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨዡ")
						if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆ๊ฯ์ิฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬส฿วะหࠣฮะฮ๊ห้สࡠࡳࡢ࡮ࠨዢ")+ggvQikMrmRXYdezZuUwj30WOc)
					else:
						K9FGwmWiA0dI = fmkZtbRj3ux(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬዣ")
						IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ዤ")+ggvQikMrmRXYdezZuUwj30WOc)
		else:
			if showDialogs:
				if FjehKb2kBaHIEg3CpruDRxLytsdJG1==Gj3rMP1Cb8wHdp49la0(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩዥ"): SLAiUwpDRoZIQfvB7 = fmkZtbRj3ux(u"ࠨ็อ์็็ษࠨዦ")
				elif FjehKb2kBaHIEg3CpruDRxLytsdJG1==weh7SGmuTgXOVRcMo1rlLq(u"ࠩࡲࡰࡩ࠭ዧ"): SLAiUwpDRoZIQfvB7 = bQGafNLXyFgsZP6ut(u"ࠪๆิ๐ๅสࠩየ")
				elif FjehKb2kBaHIEg3CpruDRxLytsdJG1==weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬዩ"): SLAiUwpDRoZIQfvB7 = jQv0du1iVxTgAXCM(u"ࠬเ๊า่ࠢฯอะษࠨዪ")
				ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,A6Sg45ChDR3BJLYfFH(u"࠭็ั้ࠣห้หึศใฬࠤࠬያ")+SLAiUwpDRoZIQfvB7+JHMxIE4fs1mvQtKW7R(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩዬ")+ggvQikMrmRXYdezZuUwj30WOc)
			if not ug0EmiKYnRT1qeH9MFyr3pO: K9FGwmWiA0dI = D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪይ")
			else:
				if FjehKb2kBaHIEg3CpruDRxLytsdJG1==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫዮ"):
					succeeded = FzZ9mBKANWCsY(ggvQikMrmRXYdezZuUwj30WOc)
					if succeeded:
						K9FGwmWiA0dI = MFhbWia58mP3su0fk2d(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫዯ")
						if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,xm6jK1ZMuWq5(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩደ")+ggvQikMrmRXYdezZuUwj30WOc)
					elif showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆศฺฬ็ษࠡ็อ์็็ษࠡ࠰࠱ࠤํ๊ๅࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨዱ")+ggvQikMrmRXYdezZuUwj30WOc)
				elif FjehKb2kBaHIEg3CpruDRxLytsdJG1 in [weh7SGmuTgXOVRcMo1rlLq(u"࠭࡯࡭ࡦࠪዲ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨዳ")]:
					succeeded = sTM2uQCLkm59NdjSAphW(ggvQikMrmRXYdezZuUwj30WOc,OOAHkWVQpyiUD,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
					if succeeded:
						if FjehKb2kBaHIEg3CpruDRxLytsdJG1==TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡱ࡯ࡨࠬዴ"): K9FGwmWiA0dI = llkFwuCyhaP3sK76qO4T(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪድ")
						elif FjehKb2kBaHIEg3CpruDRxLytsdJG1==fmkZtbRj3ux(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫዶ"): K9FGwmWiA0dI = lCT8hfYUBX4OQMmL(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧዷ")
						ipCGBvu1TIN4nVef20qPQOUWJ3 = MIyxS2g7BDQrKu0
						if showDialogs:
							if K9FGwmWiA0dI==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ዸ"): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,MFhbWia58mP3su0fk2d(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪዹ")+ggvQikMrmRXYdezZuUwj30WOc)
							elif K9FGwmWiA0dI==bQGafNLXyFgsZP6ut(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪዺ"): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,it4DKnryZlx(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩዻ")+ggvQikMrmRXYdezZuUwj30WOc)
					elif showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,Gj3rMP1Cb8wHdp49la0(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬዼ")+ggvQikMrmRXYdezZuUwj30WOc)
	elif showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,llkFwuCyhaP3sK76qO4T(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨዽ")+ggvQikMrmRXYdezZuUwj30WOc)
	return succeeded,K9FGwmWiA0dI,ipCGBvu1TIN4nVef20qPQOUWJ3
def rG0MQfgtacDUbH384x7qlTeKzd(ggvQikMrmRXYdezZuUwj30WOc,showDialogs,S6nGDmu9UQpfB):
	ggqRntHK3z2cuEw6Cb8J5m = plTxfrOsuV4McaF2HPg1BiZ396GXI5.connect(cT4oLk7l9uSIbE35NjBV)
	ggqRntHK3z2cuEw6Cb8J5m.text_factory = str
	sXeobuj186Q = ggqRntHK3z2cuEw6Cb8J5m.cursor()
	succeeded,eK0hplwOEuPs9YvXZLIQ12 = y0yvdNOZkiKEg5RLMhoDVQAB9F2,Z19pUxa2gfGMNKoDsEuytn85SjFvA
	try:
		ntWm7dKfOvCj6au9G0rPHiqZh = w8JC1y7Lp3(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ዾ")
		sXeobuj186Q.execute(xdSThjYnuHXAU6M(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪዿ")+ggvQikMrmRXYdezZuUwj30WOc+it4DKnryZlx(u"࠭ࠢࠡ࠽ࠪጀ"))
		y7ZhGxrtSX2A4DPEWRj0 = sXeobuj186Q.fetchall()
		if y7ZhGxrtSX2A4DPEWRj0 and ntWm7dKfOvCj6au9G0rPHiqZh not in str(y7ZhGxrtSX2A4DPEWRj0): sXeobuj186Q.execute(yRWQMHxZEz0(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫጁ")+ntWm7dKfOvCj6au9G0rPHiqZh+MFhbWia58mP3su0fk2d(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧጂ")+ggvQikMrmRXYdezZuUwj30WOc+jQv0du1iVxTgAXCM(u"ࠩࠥࠤࡀ࠭ጃ"))
		zzC2pVfJFKcNHgw15ElbmLo9j40TY = lCT8hfYUBX4OQMmL(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ጄ") if ndib93Ol6UojCrEV else lCT8hfYUBX4OQMmL(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪጅ")
		sXeobuj186Q.execute(fmkZtbRj3ux(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ጆ")+zzC2pVfJFKcNHgw15ElbmLo9j40TY+TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫጇ")+ggvQikMrmRXYdezZuUwj30WOc+D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࠣࠢ࠾ࠫገ"))
		y7ZhGxrtSX2A4DPEWRj0 = sXeobuj186Q.fetchall()
		if y7ZhGxrtSX2A4DPEWRj0:
			if showDialogs: ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬጉ")+ggvQikMrmRXYdezZuUwj30WOc+rDG9dZoXRhCJcieUSF0KB(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩጊ")+JegF7SlMawI03+yRWQMHxZEz0(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬጋ")+AAByQSLgaZwCsKnvc5eWNmY+vWNRusF46D7Mi8GpZ(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩጌ"))
			else: ug0EmiKYnRT1qeH9MFyr3pO = UD4N8MjVTd
			if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
				eK0hplwOEuPs9YvXZLIQ12 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				sXeobuj186Q.execute(yRWQMHxZEz0(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫግ")+zzC2pVfJFKcNHgw15ElbmLo9j40TY+gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫጎ")+ggvQikMrmRXYdezZuUwj30WOc+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࠣࠢ࠾ࠫጏ"))
		elif S6nGDmu9UQpfB:
			if showDialogs: ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬጐ")+ggvQikMrmRXYdezZuUwj30WOc+JHMxIE4fs1mvQtKW7R(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩ጑")+JegF7SlMawI03+xm6jK1ZMuWq5(u"ࠪࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠࠨጒ")+AAByQSLgaZwCsKnvc5eWNmY+lCT8hfYUBX4OQMmL(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩጓ"))
			else: ug0EmiKYnRT1qeH9MFyr3pO = UD4N8MjVTd
			if ug0EmiKYnRT1qeH9MFyr3pO==UD4N8MjVTd:
				eK0hplwOEuPs9YvXZLIQ12 = y0yvdNOZkiKEg5RLMhoDVQAB9F2
				if ndib93Ol6UojCrEV: sXeobuj186Q.execute(llkFwuCyhaP3sK76qO4T(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫጔ")+zzC2pVfJFKcNHgw15ElbmLo9j40TY+s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ጕ")+ggvQikMrmRXYdezZuUwj30WOc+xdSThjYnuHXAU6M(u"ࠧࠣࠫࠣ࠿ࠬ጖"))
				else: sXeobuj186Q.execute(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧ጗")+zzC2pVfJFKcNHgw15ElbmLo9j40TY+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ጘ")+ggvQikMrmRXYdezZuUwj30WOc+vWNRusF46D7Mi8GpZ(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪጙ"))
	except: succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	ggqRntHK3z2cuEw6Cb8J5m.commit()
	ggqRntHK3z2cuEw6Cb8J5m.close()
	if eK0hplwOEuPs9YvXZLIQ12:
		L5jXH0fZ8TvsESR.sleep(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠷Ꮍ"))
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(Gj3rMP1Cb8wHdp49la0(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨጚ"))
		L5jXH0fZ8TvsESR.sleep(Gj3rMP1Cb8wHdp49la0(u"࠱Ꮎ"))
		if showDialogs:
			if succeeded: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,yRWQMHxZEz0(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ጛ")+ggvQikMrmRXYdezZuUwj30WOc)
			else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,Gj3rMP1Cb8wHdp49la0(u"࠭แีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢอัิ๐หࠡษ็ษ฻อแสࠢ࡟ࡲࡡࡴࠧጜ")+ggvQikMrmRXYdezZuUwj30WOc)
	return eK0hplwOEuPs9YvXZLIQ12
def L08CNwYIzOXKFhMRJlk(FloXKDNzIGOJQHct,showDialogs,f5JeBXdUi36cnvIyblF,S6nGDmu9UQpfB):
	WzcgrtpJ9X6lYCD = XFMSnPvjbgcRE9tf6z(FloXKDNzIGOJQHct)
	aaXwoegqPYprGSmFIQzOU2d0CBjt = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	for ggvQikMrmRXYdezZuUwj30WOc in FloXKDNzIGOJQHct:
		succeeded,K9FGwmWiA0dI,ipCGBvu1TIN4nVef20qPQOUWJ3 = DxwYZSObr9RdKk3L1Qs6gel(ggvQikMrmRXYdezZuUwj30WOc,showDialogs,f5JeBXdUi36cnvIyblF,WzcgrtpJ9X6lYCD)
		eK0hplwOEuPs9YvXZLIQ12 = rG0MQfgtacDUbH384x7qlTeKzd(ggvQikMrmRXYdezZuUwj30WOc,showDialogs,S6nGDmu9UQpfB)
		if eK0hplwOEuPs9YvXZLIQ12: aaXwoegqPYprGSmFIQzOU2d0CBjt = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if aaXwoegqPYprGSmFIQzOU2d0CBjt:
		L5jXH0fZ8TvsESR.sleep(VhqD3zp7mUieI8sMQlETH(u"࠲Ꮏ"))
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫጝ"))
		L5jXH0fZ8TvsESR.sleep(vWNRusF46D7Mi8GpZ(u"࠳Ꮐ"))
	if showDialogs:
		if len(FloXKDNzIGOJQHct)>xm6jK1ZMuWq5(u"࠴Ꮑ"): IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,erqDsJmL3BQHuGtPkcf0X9(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠอ็ํ฽ࠥอไฦุสๅฬะࠧጞ"))
		else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,MFhbWia58mP3su0fk2d(u"ࠩอ้ࠥฮๆอษะࠤๆำีࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ጟ")+FloXKDNzIGOJQHct[w8JC1y7Lp3(u"࠴Ꮒ")])
	return
def C7tGsABJHNMUxw85pmRKeI0O6(showDialogs):
	JJ8PEbrOnhxCmopMTYIdX = [kPCxIUZb1V(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨጠ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ጡ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩጢ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ጣ")]
	qIRbU2dN9p1W3w5LmMzAGlgeiVBHy = [kPCxIUZb1V(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩጤ"),lCT8hfYUBX4OQMmL(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩጥ"),JHMxIE4fs1mvQtKW7R(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࠬጦ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬጧ"),llkFwuCyhaP3sK76qO4T(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬጨ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩጩ")]
	for ggvQikMrmRXYdezZuUwj30WOc in qIRbU2dN9p1W3w5LmMzAGlgeiVBHy: ctG8p7nLWlms4xj(ggvQikMrmRXYdezZuUwj30WOc)
	L08CNwYIzOXKFhMRJlk(JJ8PEbrOnhxCmopMTYIdX,showDialogs,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return