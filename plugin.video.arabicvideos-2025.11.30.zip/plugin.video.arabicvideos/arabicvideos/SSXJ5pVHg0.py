﻿# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'ALMAAREF'
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
UT69hgqoKsWNIwM5zkAYb = '_MRF_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def DDIqhZaAit8Ed9(mode,url,text,sbNukjOf4chz):
	if   mode==40: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==41: RCmHBOKtejQ8lu4L = z2zkeZjJRb1Wx0SyLXGVlNq()
	elif mode==42: RCmHBOKtejQ8lu4L = EMuASNl46jQoJHCG1p(text,sbNukjOf4chz)
	elif mode==43: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==44: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(text,sbNukjOf4chz)
	elif mode==49: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,49)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'البث الحي لقناة المعارف',wUvcPrYDfISbZolAm83GKEqMyXkn5,41)
	EMuASNl46jQoJHCG1p(wUvcPrYDfISbZolAm83GKEqMyXkn5,'1')
	return
def SSDRlYe0oV1WdJkHGxrn9w(plQAPdho26aj,tCFWS8rVgciHTepj):
	search,sort,DPEAV2jq8xQO79IGyeLC,d5TLHSj39awfvFp,UNifBOoauQPFZ = wUvcPrYDfISbZolAm83GKEqMyXkn5,[],[],[],[]
	vziHL4xVFSD81W7X9Noyrdjb,Byp4TDVmGHdqC8SNoMXYEniOas = ibEuGXOqxHp(plQAPdho26aj)
	for sslNS0zetni1HDbZRQOCMxJ4AfhaP in list(Byp4TDVmGHdqC8SNoMXYEniOas.keys()):
		value = Byp4TDVmGHdqC8SNoMXYEniOas[sslNS0zetni1HDbZRQOCMxJ4AfhaP]
		if not value: continue
		if   sslNS0zetni1HDbZRQOCMxJ4AfhaP=='sort': sort = [value]
		elif sslNS0zetni1HDbZRQOCMxJ4AfhaP=='series': DPEAV2jq8xQO79IGyeLC = [value]
		elif sslNS0zetni1HDbZRQOCMxJ4AfhaP=='search': search = value
		elif sslNS0zetni1HDbZRQOCMxJ4AfhaP=='category': d5TLHSj39awfvFp = [value]
		elif sslNS0zetni1HDbZRQOCMxJ4AfhaP=='specialist': UNifBOoauQPFZ = [value]
	COW137cpIhBMYTSiAR9s2Dlzw = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":d5TLHSj39awfvFp,"specialist":UNifBOoauQPFZ,"series":DPEAV2jq8xQO79IGyeLC,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(tCFWS8rVgciHTepj)}}
	COW137cpIhBMYTSiAR9s2Dlzw = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(COW137cpIhBMYTSiAR9s2Dlzw)
	hhEH1rcSP0z6Bkqy8OD = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'POST',hhEH1rcSP0z6Bkqy8OD,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	data = dm7KA8MukvxF3iH9CW2ZNc('dict',II64TLxj3mbqEyh9pHQ8oAv)
	return data
def EMuASNl46jQoJHCG1p(plQAPdho26aj,level):
	qqtR56dgVLh3Tr2 = SSDRlYe0oV1WdJkHGxrn9w(plQAPdho26aj,'1')
	IJE2xcV7OWauUKhfik56gXBwltCb = qqtR56dgVLh3Tr2['facets']
	if level=='1':
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb['video_categories']
		items = jj0dZrgiKb.findall('<div(.*?)/div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for o4oW9wDcsrpHQS816yfIvg in items:
			kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',o4oW9wDcsrpHQS816yfIvg+'<',jj0dZrgiKb.DOTALL)
			if not kdJDcbM5FWUAgBs: kdJDcbM5FWUAgBs = jj0dZrgiKb.findall('data-value=\\"(.*?)\\">(.*?)<',o4oW9wDcsrpHQS816yfIvg+'<',jj0dZrgiKb.DOTALL)
			d5TLHSj39awfvFp,title = kdJDcbM5FWUAgBs[0]
			if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			if not plQAPdho26aj: mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,42,wUvcPrYDfISbZolAm83GKEqMyXkn5,'2','?category='+d5TLHSj39awfvFp)
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,42,wUvcPrYDfISbZolAm83GKEqMyXkn5,'2',plQAPdho26aj+'&category='+d5TLHSj39awfvFp)
	if level=='2':
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb['specialist']
		items = jj0dZrgiKb.findall('value="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for UNifBOoauQPFZ,title in items:
			if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			if not UNifBOoauQPFZ: title = title = 'الجميع'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,42,wUvcPrYDfISbZolAm83GKEqMyXkn5,'3',plQAPdho26aj+'&specialist='+UNifBOoauQPFZ)
	elif level=='3':
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb['series']
		items = jj0dZrgiKb.findall('value="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for DPEAV2jq8xQO79IGyeLC,title in items:
			if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			if not DPEAV2jq8xQO79IGyeLC: title = title = 'الجميع'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,42,wUvcPrYDfISbZolAm83GKEqMyXkn5,'4',plQAPdho26aj+'&series='+DPEAV2jq8xQO79IGyeLC)
	elif level=='4':
		IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb['sort_video']
		items = jj0dZrgiKb.findall('value="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for sort,title in items:
			if not sort: continue
			if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,44,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1',plQAPdho26aj+'&sort='+sort)
	return
def HPdaS7kenW0m(plQAPdho26aj,tCFWS8rVgciHTepj):
	qqtR56dgVLh3Tr2 = SSDRlYe0oV1WdJkHGxrn9w(plQAPdho26aj,tCFWS8rVgciHTepj)
	IJE2xcV7OWauUKhfik56gXBwltCb = qqtR56dgVLh3Tr2['template']
	items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,43,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	IJE2xcV7OWauUKhfik56gXBwltCb = qqtR56dgVLh3Tr2['facets']['pagination']
	items = jj0dZrgiKb.findall('data-page="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for sbNukjOf4chz,title in items:
		if tCFWS8rVgciHTepj==sbNukjOf4chz: continue
		if ndib93Ol6UojCrEV: title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,44,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,plQAPdho26aj)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ALMAAREF-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('<video src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('youtube_url.*?(http.*?)&',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	jcInvNf98TZ5gRUDFp40li2uzVPrO = []
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0].replace('\/','/')
		jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(jcInvNf98TZ5gRUDFp40li2uzVPrO,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def z2zkeZjJRb1Wx0SyLXGVlNq():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid+'/البث-المباشر-6',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ALMAAREF-LIVE-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	url = jj0dZrgiKb.findall('data-item=.*?(http.*?)&',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	url = url[0].replace('\/','/')
	yyYuosJmc3QDUGSA(url,UdbRGoKhcDeI4lVfns5,'live')
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	QQVqb3kdDINfmAJY8eKU4nhzGpR6Ba = False
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		QQVqb3kdDINfmAJY8eKU4nhzGpR6Ba = True
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	if not QQVqb3kdDINfmAJY8eKU4nhzGpR6Ba: HPdaS7kenW0m('?search='+search,'1')
	else: EMuASNl46jQoJHCG1p('?search='+search,'1')
	return