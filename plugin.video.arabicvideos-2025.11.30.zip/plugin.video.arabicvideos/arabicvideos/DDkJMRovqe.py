# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'IFILM'
UT69hgqoKsWNIwM5zkAYb = '_IFL_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
wkbMLZA1UPQtRnDcmri7qyHz = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][1]
AaDNk2mVEBhCvQH = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][2]
zvTANnBgVkybL4RZxsmFIaXYlKi = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][3]
def DDIqhZaAit8Ed9(mode,url,sbNukjOf4chz,text):
	if   mode==20: RCmHBOKtejQ8lu4L = uUR7bandtqkz1ic()
	elif mode==21: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE(url)
	elif mode==22: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,sbNukjOf4chz)
	elif mode==23: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url,sbNukjOf4chz)
	elif mode==24: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,text)
	elif mode==25: RCmHBOKtejQ8lu4L = tuvrk51KGs9i3FPU26(url)
	elif mode==27: RCmHBOKtejQ8lu4L = z2zkeZjJRb1Wx0SyLXGVlNq(url)
	elif mode==28: RCmHBOKtejQ8lu4L = CVY3nsNtbWLdKJ0hlG1()
	elif mode==29: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def uUR7bandtqkz1ic():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'عربي',hhD7r1VvaPt3TC06SJjqKRfEid,21,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'English',wkbMLZA1UPQtRnDcmri7qyHz,21,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فارسى',AaDNk2mVEBhCvQH,21,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فارسى 2',zvTANnBgVkybL4RZxsmFIaXYlKi,21,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	return
def CVY3nsNtbWLdKJ0hlG1():
	mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'عربي',hhD7r1VvaPt3TC06SJjqKRfEid,27)
	mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'English',wkbMLZA1UPQtRnDcmri7qyHz,27)
	mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'فارسى',AaDNk2mVEBhCvQH,27)
	mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+'فارسى 2',zvTANnBgVkybL4RZxsmFIaXYlKi,27)
	return
def x6zs7UWPvmuecZOHqtgAVnbwCE(A6auQYvO2z):
	UdbRGoKhcDeI4lVfns5 = A6auQYvO2z
	if A6auQYvO2z=='IFILM-ARABIC': A6auQYvO2z = hhD7r1VvaPt3TC06SJjqKRfEid
	elif A6auQYvO2z=='IFILM-ENGLISH': A6auQYvO2z = wkbMLZA1UPQtRnDcmri7qyHz
	else: UdbRGoKhcDeI4lVfns5 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(A6auQYvO2z)
	if jTd3VarcCvh4D70WXGI=='ar' or UdbRGoKhcDeI4lVfns5=='IFILM-ARABIC':
		MdFkwQ95L4JhRjDoxgcXWp8b = 'بحث في الموقع'
		hhX9f8bY1aIRxnWpvKlNquUVZ = 'مسلسلات - حالية'
		QSuoms9tfxPZwgEea = 'مسلسلات - أحدث'
		DjKRFulGIxvqtfJm07NeV = 'مسلسلات - أبجدي'
		sN2VHB7DhcjEivOoJKxdp5w = 'بث حي آي فيلم'
		b7GhqW98541NjUvdZ = 'أفلام'
		zBauVMIbtN6s0dlpfWkE = 'موسيقى'
		WfyEACuY8XV2mNOHsSBQ = 'برامج'
	elif jTd3VarcCvh4D70WXGI=='en' or UdbRGoKhcDeI4lVfns5=='IFILM-ENGLISH':
		MdFkwQ95L4JhRjDoxgcXWp8b = 'Search in site'
		hhX9f8bY1aIRxnWpvKlNquUVZ = 'Series - Current'
		QSuoms9tfxPZwgEea = 'Series - Latest'
		DjKRFulGIxvqtfJm07NeV = 'Series - Alphabet'
		sN2VHB7DhcjEivOoJKxdp5w = 'Live iFilm channel'
		b7GhqW98541NjUvdZ = 'Movies'
		zBauVMIbtN6s0dlpfWkE = 'Music'
		WfyEACuY8XV2mNOHsSBQ = 'Shows'
	elif jTd3VarcCvh4D70WXGI in ['fa','fa2']:
		MdFkwQ95L4JhRjDoxgcXWp8b = 'جستجو در سایت'
		hhX9f8bY1aIRxnWpvKlNquUVZ = 'سريال - جاری'
		QSuoms9tfxPZwgEea = 'سريال - آخرین'
		DjKRFulGIxvqtfJm07NeV = 'سريال - الفبا'
		sN2VHB7DhcjEivOoJKxdp5w = 'پخش زنده اي فيلم'
		b7GhqW98541NjUvdZ = 'فيلم'
		zBauVMIbtN6s0dlpfWkE = 'موسيقى'
		WfyEACuY8XV2mNOHsSBQ = 'برنامه ها'
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+MdFkwQ95L4JhRjDoxgcXWp8b,A6auQYvO2z,29,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('live',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+sN2VHB7DhcjEivOoJKxdp5w,A6auQYvO2z,27)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	U6OhDV7N1y9c3r4woKE2dW = ['Series','Program','Music']
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,A6auQYvO2z+'/home',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-MENU-1st')
	pLHIPUY3TWAeE70=jj0dZrgiKb.findall('button-menu(.*?)/Contact',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if any(value in hhEH1rcSP0z6Bkqy8OD for value in U6OhDV7N1y9c3r4woKE2dW):
				url = A6auQYvO2z+hhEH1rcSP0z6Bkqy8OD
				if 'Series' in hhEH1rcSP0z6Bkqy8OD:
					mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'100')
					mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+QSuoms9tfxPZwgEea,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
					mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+DjKRFulGIxvqtfJm07NeV,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'201')
				elif 'Film' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+b7GhqW98541NjUvdZ,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'100')
				elif 'Music' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+zBauVMIbtN6s0dlpfWkE,url,25,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
				elif 'Program' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+WfyEACuY8XV2mNOHsSBQ,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	return II64TLxj3mbqEyh9pHQ8oAv
def tuvrk51KGs9i3FPU26(url):
	A6auQYvO2z = wdfTVmGkRrH24(url)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-MUSIC_MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('Music-tools-header(.*?)Music-body',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	title = jj0dZrgiKb.findall('<p>(.*?)</p>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)[0]
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = A6auQYvO2z + hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,23,wUvcPrYDfISbZolAm83GKEqMyXkn5,'101')
	return
def HPdaS7kenW0m(url,sbNukjOf4chz):
	A6auQYvO2z = wdfTVmGkRrH24(url)
	jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(url)
	type = url.split('/')[-1]
	f4IJY5P7hdOLX = str(int(sbNukjOf4chz)//100)
	sbNukjOf4chz = str(int(sbNukjOf4chz)%100)
	if type=='Series' and sbNukjOf4chz=='0':
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-TITLES-1st')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('serial-body(.*?)class="row',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			hhEH1rcSP0z6Bkqy8OD = A6auQYvO2z + hhEH1rcSP0z6Bkqy8OD
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = A6auQYvO2z + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,23,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,f4IJY5P7hdOLX+'01')
	knOoiVS6h5IvmwfPspFX3Eb8a7LKGD=0
	if type=='Series': d5TLHSj39awfvFp='3'
	if type=='Film': d5TLHSj39awfvFp='5'
	if type=='Program': d5TLHSj39awfvFp='7'
	if type in ['Series','Program','Film'] and sbNukjOf4chz!='0':
		ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Home/PageingItem?category='+d5TLHSj39awfvFp+'&page='+sbNukjOf4chz+'&size=30&orderby='+f4IJY5P7hdOLX
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-TITLES-2nd')
		items = jj0dZrgiKb.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for id,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			title = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(title)
			title = title.replace('\\',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			title = title.replace('"',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
			hhEH1rcSP0z6Bkqy8OD = A6auQYvO2z + '/' + type + '/Content/' + id
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = A6auQYvO2z + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			if type=='Film': mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,24,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,f4IJY5P7hdOLX+'01')
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,23,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,f4IJY5P7hdOLX+'01')
	if type=='Music':
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,A6auQYvO2z+'/Music/Index?page='+sbNukjOf4chz,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-TITLES-3rd')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('pagination-demo(.*?)pagination-demo',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = A6auQYvO2z + cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			hhEH1rcSP0z6Bkqy8OD = A6auQYvO2z + hhEH1rcSP0z6Bkqy8OD
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,23,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,'101')
	if knOoiVS6h5IvmwfPspFX3Eb8a7LKGD>20:
		title='صفحة '
		if jTd3VarcCvh4D70WXGI=='en': title = 'Page '
		if jTd3VarcCvh4D70WXGI=='fa': title = 'صفحه '
		if jTd3VarcCvh4D70WXGI=='fa2': title = 'صفحه '
		for nPoKZDVqwOX7 in range(1,11) :
			if not sbNukjOf4chz==str(nPoKZDVqwOX7):
				H9HtAsQ2wN = '0'+str(nPoKZDVqwOX7)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title+str(nPoKZDVqwOX7),url,22,wUvcPrYDfISbZolAm83GKEqMyXkn5,f4IJY5P7hdOLX+H9HtAsQ2wN[-2:])
	return
def mCwqRg7HpivAQ6S(url,sbNukjOf4chz):
	if not sbNukjOf4chz: sbNukjOf4chz = 0
	A6auQYvO2z = wdfTVmGkRrH24(url)
	V83w0qv5UYT6peJjKbkL = wdfTVmGkRrH24(url)
	jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(url)
	deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('/')
	id,type = deg2JDUOioWfbC8NcswK1RFAlk4M[-1],deg2JDUOioWfbC8NcswK1RFAlk4M[3]
	f4IJY5P7hdOLX = str(int(sbNukjOf4chz)//100)
	sbNukjOf4chz = str(int(sbNukjOf4chz)%100)
	knOoiVS6h5IvmwfPspFX3Eb8a7LKGD = 0
	if type=='Series':
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-1st')
		items = jj0dZrgiKb.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		title = ' - الحلقة '
		if jTd3VarcCvh4D70WXGI=='en': title = ' - Episode '
		if jTd3VarcCvh4D70WXGI=='fa': title = ' - قسمت '
		if jTd3VarcCvh4D70WXGI=='fa2': title = ' - قسمت '
		if jTd3VarcCvh4D70WXGI=='fa': vkN7DMuIbUEKaP2L6 = wUvcPrYDfISbZolAm83GKEqMyXkn5
		else: vkN7DMuIbUEKaP2L6 = jTd3VarcCvh4D70WXGI
		jjiEJbKRI5o = jj0dZrgiKb.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for name,count,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD in items:
			for xNVKL75nEZstg4wfXBkySQ in range(int(count),0,-1):
				gU8alIyLvd3N7nBT = cPzpeLXs3jMCltW4ZN9BaYdfQvwS + vkN7DMuIbUEKaP2L6 + id + '/' + str(xNVKL75nEZstg4wfXBkySQ) + '.png'
				hhX9f8bY1aIRxnWpvKlNquUVZ = name + title + str(xNVKL75nEZstg4wfXBkySQ)
				hhX9f8bY1aIRxnWpvKlNquUVZ = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(hhX9f8bY1aIRxnWpvKlNquUVZ)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,url,24,gU8alIyLvd3N7nBT,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(xNVKL75nEZstg4wfXBkySQ))
	elif type=='Program':
		ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+sbNukjOf4chz+'&size=30&orderby=1'
		II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-2nd')
		items = jj0dZrgiKb.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		title = ' - الحلقة '
		if jTd3VarcCvh4D70WXGI=='en': title = ' - Episode '
		if jTd3VarcCvh4D70WXGI=='fa': title = ' - قسمت '
		if jTd3VarcCvh4D70WXGI=='fa2': title = ' - قسمت '
		for xNVKL75nEZstg4wfXBkySQ,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,kJvSWPuAMGH2d50qTohOb1my,name in items:
			knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
			gU8alIyLvd3N7nBT = V83w0qv5UYT6peJjKbkL + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			name = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(name)
			hhX9f8bY1aIRxnWpvKlNquUVZ = name + title + str(xNVKL75nEZstg4wfXBkySQ)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,ZD5n0eJivzWOMxY98dgrumkwRG,24,gU8alIyLvd3N7nBT,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(knOoiVS6h5IvmwfPspFX3Eb8a7LKGD))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Music/GetTracksBy?id='+str(id)+'&page='+sbNukjOf4chz+'&size=30&type=0'
			II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-3rd')
			items = jj0dZrgiKb.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,name,title in items:
				knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
				gU8alIyLvd3N7nBT = V83w0qv5UYT6peJjKbkL + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				hhX9f8bY1aIRxnWpvKlNquUVZ = name + ' - ' + title
				hhX9f8bY1aIRxnWpvKlNquUVZ = hhX9f8bY1aIRxnWpvKlNquUVZ.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				hhX9f8bY1aIRxnWpvKlNquUVZ = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(hhX9f8bY1aIRxnWpvKlNquUVZ)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,ZD5n0eJivzWOMxY98dgrumkwRG,24,gU8alIyLvd3N7nBT,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(knOoiVS6h5IvmwfPspFX3Eb8a7LKGD))
		elif 'Clips' in url:
			ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Music/GetTracksBy?id=0&page='+sbNukjOf4chz+'&size=30&type=15'
			II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-4th')
			items = jj0dZrgiKb.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title,hhEH1rcSP0z6Bkqy8OD in items:
				knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
				gU8alIyLvd3N7nBT = V83w0qv5UYT6peJjKbkL + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				hhX9f8bY1aIRxnWpvKlNquUVZ = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				hhX9f8bY1aIRxnWpvKlNquUVZ = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(hhX9f8bY1aIRxnWpvKlNquUVZ)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,ZD5n0eJivzWOMxY98dgrumkwRG,24,gU8alIyLvd3N7nBT,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(knOoiVS6h5IvmwfPspFX3Eb8a7LKGD))
		elif 'category' in url:
			if 'category=6' in url:
				ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Music/GetTracksBy?id=0&page='+sbNukjOf4chz+'&size=30&type=6'
				II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				ZD5n0eJivzWOMxY98dgrumkwRG = A6auQYvO2z+'/Music/GetTracksBy?id=0&page='+sbNukjOf4chz+'&size=30&type=4'
				II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-EPISODES-6th')
			items = jj0dZrgiKb.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,name,title in items:
				knOoiVS6h5IvmwfPspFX3Eb8a7LKGD += 1
				gU8alIyLvd3N7nBT = V83w0qv5UYT6peJjKbkL + vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				hhX9f8bY1aIRxnWpvKlNquUVZ = name + ' - ' + title
				hhX9f8bY1aIRxnWpvKlNquUVZ = hhX9f8bY1aIRxnWpvKlNquUVZ.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				hhX9f8bY1aIRxnWpvKlNquUVZ = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(hhX9f8bY1aIRxnWpvKlNquUVZ)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+hhX9f8bY1aIRxnWpvKlNquUVZ,ZD5n0eJivzWOMxY98dgrumkwRG,24,gU8alIyLvd3N7nBT,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(knOoiVS6h5IvmwfPspFX3Eb8a7LKGD))
	if type=='Music' or type=='Program':
		if knOoiVS6h5IvmwfPspFX3Eb8a7LKGD>25:
			title='صفحة '
			if jTd3VarcCvh4D70WXGI=='en': title = ' Page '
			if jTd3VarcCvh4D70WXGI=='fa': title = ' صفحه '
			if jTd3VarcCvh4D70WXGI=='fa2': title = ' صفحه '
			for nPoKZDVqwOX7 in range(1,11):
				if not sbNukjOf4chz==str(nPoKZDVqwOX7):
					H9HtAsQ2wN = '0'+str(nPoKZDVqwOX7)
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title+str(nPoKZDVqwOX7),url,23,wUvcPrYDfISbZolAm83GKEqMyXkn5,f4IJY5P7hdOLX+H9HtAsQ2wN[-2:])
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url,xNVKL75nEZstg4wfXBkySQ):
	V83w0qv5UYT6peJjKbkL = wdfTVmGkRrH24(url)
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-PLAY-1st')
	items = jj0dZrgiKb.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(url)
		deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('/')
		id,type = deg2JDUOioWfbC8NcswK1RFAlk4M[-1],deg2JDUOioWfbC8NcswK1RFAlk4M[3]
		hhEH1rcSP0z6Bkqy8OD = items[0][0]+jTd3VarcCvh4D70WXGI+id+'/,'+xNVKL75nEZstg4wfXBkySQ+','+xNVKL75nEZstg4wfXBkySQ+'_'+items[0][2]
		Eu8LWnSt3fyJzIC.append('m3u8')
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	items = jj0dZrgiKb.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(url)
		deg2JDUOioWfbC8NcswK1RFAlk4M = url.split('/')
		id,type = deg2JDUOioWfbC8NcswK1RFAlk4M[-1],deg2JDUOioWfbC8NcswK1RFAlk4M[3]
		hhEH1rcSP0z6Bkqy8OD = items[0][0]+jTd3VarcCvh4D70WXGI+id+'/'+xNVKL75nEZstg4wfXBkySQ+items[0][2]
		Eu8LWnSt3fyJzIC.append('mp4 url')
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	items = jj0dZrgiKb.findall('source src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD in items:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('//','/')
		Eu8LWnSt3fyJzIC.append('mp4 src')
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	items = jj0dZrgiKb.findall('VideoAddress":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		hhEH1rcSP0z6Bkqy8OD = items[int(xNVKL75nEZstg4wfXBkySQ)-1]
		hhEH1rcSP0z6Bkqy8OD = V83w0qv5UYT6peJjKbkL+vvLTYxVfrbDza(hhEH1rcSP0z6Bkqy8OD)
		Eu8LWnSt3fyJzIC.append('mp4 address')
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	items = jj0dZrgiKb.findall('VoiceAddress":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		hhEH1rcSP0z6Bkqy8OD = items[int(xNVKL75nEZstg4wfXBkySQ)-1]
		hhEH1rcSP0z6Bkqy8OD = V83w0qv5UYT6peJjKbkL+vvLTYxVfrbDza(hhEH1rcSP0z6Bkqy8OD)
		Eu8LWnSt3fyJzIC.append('mp3 address')
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)==1: hhEH1rcSP0z6Bkqy8OD = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[0]
	else:
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر الفيديو المناسب:', Eu8LWnSt3fyJzIC)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1 : return
		hhEH1rcSP0z6Bkqy8OD = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	yyYuosJmc3QDUGSA(hhEH1rcSP0z6Bkqy8OD,UdbRGoKhcDeI4lVfns5,'video')
	return
def wdfTVmGkRrH24(url):
	if hhD7r1VvaPt3TC06SJjqKRfEid in url: g40I3ZXaeJ8qVywt = hhD7r1VvaPt3TC06SJjqKRfEid
	elif wkbMLZA1UPQtRnDcmri7qyHz in url: g40I3ZXaeJ8qVywt = wkbMLZA1UPQtRnDcmri7qyHz
	elif AaDNk2mVEBhCvQH in url: g40I3ZXaeJ8qVywt = AaDNk2mVEBhCvQH
	elif zvTANnBgVkybL4RZxsmFIaXYlKi in url: g40I3ZXaeJ8qVywt = zvTANnBgVkybL4RZxsmFIaXYlKi
	else: g40I3ZXaeJ8qVywt = wUvcPrYDfISbZolAm83GKEqMyXkn5
	return g40I3ZXaeJ8qVywt
def HHFIZEP39gvlnM0(url):
	if   hhD7r1VvaPt3TC06SJjqKRfEid in url: jTd3VarcCvh4D70WXGI = 'ar'
	elif wkbMLZA1UPQtRnDcmri7qyHz in url: jTd3VarcCvh4D70WXGI = 'en'
	elif AaDNk2mVEBhCvQH in url: jTd3VarcCvh4D70WXGI = 'fa'
	elif zvTANnBgVkybL4RZxsmFIaXYlKi in url: jTd3VarcCvh4D70WXGI = 'fa2'
	else: jTd3VarcCvh4D70WXGI = wUvcPrYDfISbZolAm83GKEqMyXkn5
	return jTd3VarcCvh4D70WXGI
def z2zkeZjJRb1Wx0SyLXGVlNq(url):
	jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(url)
	ZD5n0eJivzWOMxY98dgrumkwRG = url + '/Home/Live'
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-LIVE-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('source src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	qaLFXuDExl8w = items[0]
	yyYuosJmc3QDUGSA(qaLFXuDExl8w,UdbRGoKhcDeI4lVfns5,'live')
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	if showDialogs:
		ToSi6sw41e2AdN0 = [ hhD7r1VvaPt3TC06SJjqKRfEid , wkbMLZA1UPQtRnDcmri7qyHz , AaDNk2mVEBhCvQH , zvTANnBgVkybL4RZxsmFIaXYlKi ]
		wjqfDTdZiOUXgm = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر اللغة المناسبة:', wjqfDTdZiOUXgm)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1 : return
		website = ToSi6sw41e2AdN0[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	else:
		if '_IFILM-ARABIC_' in plQAPdho26aj: website = hhD7r1VvaPt3TC06SJjqKRfEid
		elif '_IFILM-ENGLISH_' in plQAPdho26aj: website = wkbMLZA1UPQtRnDcmri7qyHz
		else: website = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not website: return
	jTd3VarcCvh4D70WXGI = HHFIZEP39gvlnM0(website)
	ZD5n0eJivzWOMxY98dgrumkwRG = website + "/Home/Search?searchstring=" + LBqdVs9ioWwpMbCm1A
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IFILM-SEARCH-1st')
	items = jj0dZrgiKb.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,d5TLHSj39awfvFp,id,title in items:
			if d5TLHSj39awfvFp in ['3','7']:
				title = title.replace('\\',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				title = title.replace('"',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				if d5TLHSj39awfvFp=='3':
					type = 'Series'
					if jTd3VarcCvh4D70WXGI=='ar': name = 'مسلسل : '
					elif jTd3VarcCvh4D70WXGI=='en': name = 'Series : '
					elif jTd3VarcCvh4D70WXGI=='fa': name = 'سريال ها : '
					elif jTd3VarcCvh4D70WXGI=='fa2': name = 'سريال ها : '
				elif d5TLHSj39awfvFp=='5':
					type = 'Film'
					if jTd3VarcCvh4D70WXGI=='ar': name = 'فيلم : '
					elif jTd3VarcCvh4D70WXGI=='en': name = 'Movie : '
					elif jTd3VarcCvh4D70WXGI=='fa': name = 'فيلم : '
					elif jTd3VarcCvh4D70WXGI=='fa2': name = 'فلم ها : '
				elif d5TLHSj39awfvFp=='7':
					type = 'Program'
					if jTd3VarcCvh4D70WXGI=='ar': name = 'برنامج : '
					elif jTd3VarcCvh4D70WXGI=='en': name = 'Program : '
					elif jTd3VarcCvh4D70WXGI=='fa': name = 'برنامه ها : '
					elif jTd3VarcCvh4D70WXGI=='fa2': name = 'برنامه ها : '
				title = name + title
				hhEH1rcSP0z6Bkqy8OD = website + '/' + type + '/Content/' + id
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = vvLTYxVfrbDza(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = website+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,23,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,'101')
	return