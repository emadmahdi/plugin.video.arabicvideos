# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'FASELHD1'
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
UT69hgqoKsWNIwM5zkAYb = '_FH1_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['جوائز الأوسكار','المراجعات','wwe']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==570: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==571: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==572: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==573: RCmHBOKtejQ8lu4L = IOW06nd9b4vDaBoc5rQHiUFZ(url,text)
	elif mode==576: RCmHBOKtejQ8lu4L = Hp2NzF754Mxb1LhBJ()
	elif mode==579: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+'لماذا الموقع بطيء',wUvcPrYDfISbZolAm83GKEqMyXkn5,576)
	FFwVakdM8NvjeJRK3oyQI9ti24,url = hhD7r1VvaPt3TC06SJjqKRfEid,hhD7r1VvaPt3TC06SJjqKRfEid
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD1-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',FFwVakdM8NvjeJRK3oyQI9ti24,579,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'المميزة',FFwVakdM8NvjeJRK3oyQI9ti24,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured1')
	items = jj0dZrgiKb.findall('class="h3">(.*?)<.*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for title,hhEH1rcSP0z6Bkqy8OD in items:
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'details1')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"menu-primary"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		gaGFLpWtJi5rw8EbNjx9KRZ3X = jj0dZrgiKb.findall('<li (.*?)</li>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		dvENZxS4K9LPoQytk0XsHMcrY6pnbO = [wUvcPrYDfISbZolAm83GKEqMyXkn5,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		qbRmVByrJv18 = 0
		for U6OhDV7N1y9c3r4woKE2dW in gaGFLpWtJi5rw8EbNjx9KRZ3X:
			if qbRmVByrJv18>0: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',U6OhDV7N1y9c3r4woKE2dW,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD=='#': continue
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+hhEH1rcSP0z6Bkqy8OD
				if title==wUvcPrYDfISbZolAm83GKEqMyXkn5: continue
				if any(value in title.lower() for value in i6TIRax9v0EDFJs2gVtfzp): continue
				title = dvENZxS4K9LPoQytk0XsHMcrY6pnbO[qbRmVByrJv18]+title
				mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'details2')
			qbRmVByrJv18 += 1
	return
def Hp2NzF754Mxb1LhBJ():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD1-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('class="h4">(.*?)</div>(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not m4z08qk6gJ5lK: return
	if type=='filters':
		pLHIPUY3TWAeE70 = [II64TLxj3mbqEyh9pHQ8oAv.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"homeSlide"(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		BFjXJPQ8VCEnpa4o7,ppAJI9kDbz5MXa76UEF,kDp3Tb6EBW = zip(*items)
		items = zip(ppAJI9kDbz5MXa76UEF,BFjXJPQ8VCEnpa4o7,kDp3Tb6EBW)
	elif type=='featured2':
		title,IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='details2' and len(m4z08qk6gJ5lK)>1:
		title = m4z08qk6gJ5lK[0][0]
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured2')
		title = m4z08qk6gJ5lK[1][0]
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'details3')
		return
	else:
		title,IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[-1]
		items = jj0dZrgiKb.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		if any(value in title.lower() for value in i6TIRax9v0EDFJs2gVtfzp): continue
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS.split('?resize=')[0]
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة).\d+',title,jj0dZrgiKb.DOTALL)
		if '/collections/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,571,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and type==wUvcPrYDfISbZolAm83GKEqMyXkn5:
			title = '_MOD_'+xNVKL75nEZstg4wfXBkySQ[0][0]
			title = title.strip(' –')
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,573,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif 'episodes/' in hhEH1rcSP0z6Bkqy8OD or 'movies/' in hhEH1rcSP0z6Bkqy8OD or 'hindi/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,572,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,573,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if type=='filters':
		vvZkF1d6onpJ3uswMW7t2YjXr0AH = jj0dZrgiKb.findall('"more_button_page":(.*?),',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if vvZkF1d6onpJ3uswMW7t2YjXr0AH:
			count = vvZkF1d6onpJ3uswMW7t2YjXr0AH[0]
			hhEH1rcSP0z6Bkqy8OD = url+'/offset/'+count
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة أخرى',hhEH1rcSP0z6Bkqy8OD,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filters')
	elif 'details' in type:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("class='pagination(.*?)</div>",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall("href='(.*?)'.*?>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = 'صفحة '+mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,571,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'details4')
	return
def IOW06nd9b4vDaBoc5rQHiUFZ(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD1-SEASONS_EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	xhzIjcYasLwUiFQOrVB3ldvqpng = False
	if not type:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"seasonList"(.*?)"container"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if len(items)>1:
				FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
				xhzIjcYasLwUiFQOrVB3ldvqpng = True
				for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,name,title in items:
					name = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(name)
					if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+hhEH1rcSP0z6Bkqy8OD
					title = name+' - '+title
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,573,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,'episodes')
	if type=='episodes' or not xhzIjcYasLwUiFQOrVB3ldvqpng:
		mnWZN7g50M = jj0dZrgiKb.findall('"posterImg".*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if mnWZN7g50M: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = mnWZN7g50M[0]
		else: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = wUvcPrYDfISbZolAm83GKEqMyXkn5
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"epAll"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,572,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	jcInvNf98TZ5gRUDFp40li2uzVPrO,mmKyGIgPQ1A2637Twqd,s7s0wmIdLNrB9Vl5n = [],[],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FASELHD1-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	DmLwHpYuOURyf = jj0dZrgiKb.findall('مستوى المشاهدة.*?">(.*?)</span>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if DmLwHpYuOURyf:
		bxiMUQmPRvu = jj0dZrgiKb.findall('"tag">(.*?)</a>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"videoRow"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('src="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('&img=')[0]
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named=__embed')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="streamHeader(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall("href = '(.*?)'.*?</i>(.*?)</a>",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,name in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('&img=')[0]
			name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__watch')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="downloadLinks(.*?)blackwindow',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?</span>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,name in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.split('&img=')[0]
			jcInvNf98TZ5gRUDFp40li2uzVPrO.append(hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__download')
	for A0ZDwrfRx1vOyed7aUETublQ in jcInvNf98TZ5gRUDFp40li2uzVPrO:
		hhEH1rcSP0z6Bkqy8OD,name = A0ZDwrfRx1vOyed7aUETublQ.split('?named')
		if hhEH1rcSP0z6Bkqy8OD not in mmKyGIgPQ1A2637Twqd:
			mmKyGIgPQ1A2637Twqd.append(hhEH1rcSP0z6Bkqy8OD)
			s7s0wmIdLNrB9Vl5n.append(A0ZDwrfRx1vOyed7aUETublQ)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(s7s0wmIdLNrB9Vl5n,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(ZD5n0eJivzWOMxY98dgrumkwRG,'details5')
	return