# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'TVFUN'
UT69hgqoKsWNIwM5zkAYb = '_TVF_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['بث مباشر']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==460: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==461: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==462: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==463: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==469: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TVFUN-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,469,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"menu-btn"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)</span>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,461)
	return
def HPdaS7kenW0m(url,DT402mRilruat3EeIoM6=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	items = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TVFUN-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="head-title"(.*?)id="footer"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			title = '_MOD_'+title.replace('<br>',UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
			if any(value in title for value in SSthyczaHP7fAIoi5):
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,462,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			elif xNVKL75nEZstg4wfXBkySQ and 'الحلقة' in title:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,463,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,463,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if DT402mRilruat3EeIoM6!='latest':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('<a href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				if hhEH1rcSP0z6Bkqy8OD=="": continue
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,461)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TVFUN-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="head-title"(.*?)id="footer"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
				title = '_MOD_'+title.replace('<br>',UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,462,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else:
			items = jj0dZrgiKb.findall('class="episode.*?href="(.*?)" title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,462)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if hhEH1rcSP0z6Bkqy8OD=="": continue
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,463)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('/video/','/watch/')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TVFUN-PLAY-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('VideoServers"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for rxKVPh4onpA5iqzW8G7NuXHIk,name in ppAJI9kDbz5MXa76UEF:
			rxKVPh4onpA5iqzW8G7NuXHIk = rxKVPh4onpA5iqzW8G7NuXHIk[2:]
			if ndib93Ol6UojCrEV: rxKVPh4onpA5iqzW8G7NuXHIk = rxKVPh4onpA5iqzW8G7NuXHIk.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			rxKVPh4onpA5iqzW8G7NuXHIk = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(rxKVPh4onpA5iqzW8G7NuXHIk)
			if wwMdFkWvcRYiXHB7yDrCqnKb98o: rxKVPh4onpA5iqzW8G7NuXHIk = rxKVPh4onpA5iqzW8G7NuXHIk.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('src="(.*?)"',rxKVPh4onpA5iqzW8G7NuXHIk,jj0dZrgiKb.DOTALL)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
			if 'http' not in hhEH1rcSP0z6Bkqy8OD:
				if '//' in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
				else: hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			if hhEH1rcSP0z6Bkqy8OD not in j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+name+'__watch'
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	if UKFZBQAVXHI5s17LyvuRpCY2 in search:
		if showDialogs: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/q/'+search+'/'
	HPdaS7kenW0m(url)
	return