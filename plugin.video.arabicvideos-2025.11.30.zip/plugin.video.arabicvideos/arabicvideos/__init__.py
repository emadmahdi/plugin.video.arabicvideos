# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from toeJqf51QP import *
UdbRGoKhcDeI4lVfns5 = xdSThjYnuHXAU6M(u"ࠫࡎࡔࡉࡕࠩᏉ")
Ak1FiIa0gpcxK36EbuHnVGR7NfLyW = A6Sg45ChDR3BJLYfFH(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠬᏊ")
KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
MFTEUm2pj39R7oa14D8lXk = int(XmaCeTontNPjwDBzyJIkKA9rRSHfb)
JrzealiFtp6 = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᏋ"))
JrzealiFtp6 = JrzealiFtp6.replace(LpYS3ndDvXHzwKP,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(u3UY8xgQZn4FLD6qWXRTyS79djo,wUvcPrYDfISbZolAm83GKEqMyXkn5)
if MFTEUm2pj39R7oa14D8lXk==Gj3rMP1Cb8wHdp49la0(u"࠷࠼࠰Ᏼ"): VVkuI2fOhTqtSdyvQsB0 = kPCxIUZb1V(u"࡚ࠧࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࡡࠠࠨᏌ")+D1DBSuO0lLGRbcfCyY+s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࠢࡠࠤࠥࠦࡋࡰࡦ࡬࠾ࠥࡡࠠࠨᏍ")+RyDst4Oxmaqb0U7vljKYI2V+DpRJnas65uVcO0S17dYG(u"ࠩࠣࡡࠬᏎ")
else:
	X47zO0kRdylJFBYsima6CPZf = Z6bUG0kDQuFqgzdAa1r(XhGSxvjRAZdU7rEt9JMweQC).replace(JegF7SlMawI03,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	X47zO0kRdylJFBYsima6CPZf = X47zO0kRdylJFBYsima6CPZf.replace(AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
	X47zO0kRdylJFBYsima6CPZf = X47zO0kRdylJFBYsima6CPZf.replace(fy2aLFcjDnoxIzGi1gp7,UKFZBQAVXHI5s17LyvuRpCY2).replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	if vWNRusF46D7Mi8GpZ(u"ࠪࠪࡺࡸ࡬࠾ࠩᏏ") in X47zO0kRdylJFBYsima6CPZf:
		X47zO0kRdylJFBYsima6CPZf,hVRT2gUyX5kcG9op = X47zO0kRdylJFBYsima6CPZf.rsplit(VhqD3zp7mUieI8sMQlETH(u"ࠫࠫࡻࡲ࡭࠿ࠪᏐ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠷Ᏽ"))
		X47zO0kRdylJFBYsima6CPZf += xm6jK1ZMuWq5(u"ࠬࠬࡵࡳ࡮ࡀࠫᏑ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(hVRT2gUyX5kcG9op,UdbRGoKhcDeI4lVfns5)
	VVkuI2fOhTqtSdyvQsB0 = DpRJnas65uVcO0S17dYG(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬᏒ")+JrzealiFtp6+xdSThjYnuHXAU6M(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧᏓ")+XmaCeTontNPjwDBzyJIkKA9rRSHfb+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨᏔ")+X47zO0kRdylJFBYsima6CPZf+lCT8hfYUBX4OQMmL(u"ࠩࠣࡡࠬᏕ")
KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Ak1FiIa0gpcxK36EbuHnVGR7NfLyW+QWLr8ABjev+Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+VVkuI2fOhTqtSdyvQsB0)
if DpRJnas65uVcO0S17dYG(u"ࠪࡣࠬᏖ") in QFOD4Gei1zaImpk02q6vBNL3jwctbr: Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk = QFOD4Gei1zaImpk02q6vBNL3jwctbr.split(A6Sg45ChDR3BJLYfFH(u"ࠫࡤ࠭Ꮧ"),UD4N8MjVTd)
else: Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk = QFOD4Gei1zaImpk02q6vBNL3jwctbr,wUvcPrYDfISbZolAm83GKEqMyXkn5
TTuO14NzmB.wvS5ocTIsy6n0dHiENWf2zUrQ7BjD,av1f8x5yZ9rAsq = Z19pUxa2gfGMNKoDsEuytn85SjFvA,wUvcPrYDfISbZolAm83GKEqMyXkn5
jjXDpagEkxQqWBVtwh9Fu1Gmb = Z19pUxa2gfGMNKoDsEuytn85SjFvA
if Zy2eBLfrukDI in [kPCxIUZb1V(u"ࠬ࠷ࠧᏘ"),w8JC1y7Lp3(u"࠭࠲ࠨᏙ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧ࠴ࠩᏚ"),xm6jK1ZMuWq5(u"ࠨ࠶ࠪᏛ"),JHMxIE4fs1mvQtKW7R(u"ࠩ࠸ࠫᏜ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠪ࠵࠶࠭Ꮭ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫ࠶࠸ࠧᏞ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠷࠳ࠨᏟ")] and (JHMxIE4fs1mvQtKW7R(u"࠭ࡁࡅࡆࠪᏠ") in FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk or pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧᏡ") in FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk or Gj3rMP1Cb8wHdp49la0(u"ࠨࡗࡓࠫᏢ") in FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk or ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡇࡓ࡜ࡔࠧᏣ") in FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk):
	from YLXs6xWcty import VRmu6CZOUwlaK4zqk7ty2nc8We9
	VRmu6CZOUwlaK4zqk7ty2nc8We9(QFOD4Gei1zaImpk02q6vBNL3jwctbr,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk)
	OOnvcPQy85HYA.setSetting(weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᏤ"),XhGSxvjRAZdU7rEt9JMweQC)
	TTuO14NzmB.wvS5ocTIsy6n0dHiENWf2zUrQ7BjD = y0yvdNOZkiKEg5RLMhoDVQAB9F2
elif not Zy2eBLfrukDI and not AAyuoe4wDPR2MgXacG7ZN8zI and MFTEUm2pj39R7oa14D8lXk in [w8JC1y7Lp3(u"࠲࠴࠷᏶"),erqDsJmL3BQHuGtPkcf0X9(u"࠸࠳࠸᏷")]:
	Be4AsSL71xyhHNQYV2wdvJ = str(V9NmnGv2o0ZU5P8F4iqgX7CQJ[w8JC1y7Lp3(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᏥ")])
	UdbRGoKhcDeI4lVfns5 = D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡏࡐࡕࡘࠪᏦ") if MFTEUm2pj39R7oa14D8lXk==gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠴࠶࠹ᏸ") else xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡍ࠴ࡗࠪᏧ")
	E0KyMHNxlcGXVQ2DWhOokU35nTB = UdbRGoKhcDeI4lVfns5.lower()
	vpHXP3E6Kt = OOnvcPQy85HYA.getSetting(JHMxIE4fs1mvQtKW7R(u"ࠧࡢࡸ࠱ࠫᏨ")+E0KyMHNxlcGXVQ2DWhOokU35nTB+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭Ꮹ")+Be4AsSL71xyhHNQYV2wdvJ)
	oQbdyTekSgKa = OOnvcPQy85HYA.getSetting(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡤࡺ࠳࠭Ꮺ")+E0KyMHNxlcGXVQ2DWhOokU35nTB+bQGafNLXyFgsZP6ut(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭Ꮻ")+Be4AsSL71xyhHNQYV2wdvJ)
	if vpHXP3E6Kt or oQbdyTekSgKa:
		xLDEnp9WdA += yRWQMHxZEz0(u"ࠫࢁ࠭Ꮼ")
		if vpHXP3E6Kt: xLDEnp9WdA += jQv0du1iVxTgAXCM(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᏭ")+vpHXP3E6Kt
		if oQbdyTekSgKa: xLDEnp9WdA += MFhbWia58mP3su0fk2d(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᏮ")+oQbdyTekSgKa
		xLDEnp9WdA = xLDEnp9WdA.replace(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡽࠨࠪᏯ"),rDG9dZoXRhCJcieUSF0KB(u"ࠨࡾࠪᏰ"))
	DXbn2AagmIGyfVJTqdl1hMtF8EpNKj = OOnvcPQy85HYA.getSetting(xdSThjYnuHXAU6M(u"ࠩࡤࡺ࠳࠭Ᏹ")+E0KyMHNxlcGXVQ2DWhOokU35nTB+it4DKnryZlx(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬᏲ")+Be4AsSL71xyhHNQYV2wdvJ)
	if DXbn2AagmIGyfVJTqdl1hMtF8EpNKj:
		KnSL8JTEvFIsZ = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧᏳ"),xLDEnp9WdA,jj0dZrgiKb.DOTALL)
		xLDEnp9WdA = xLDEnp9WdA.replace(KnSL8JTEvFIsZ[wTLFCOcM26fmYlW7U],DXbn2AagmIGyfVJTqdl1hMtF8EpNKj)
	yyYuosJmc3QDUGSA(xLDEnp9WdA,UdbRGoKhcDeI4lVfns5,KUOoYcT20iCLVgsw1ejzdkHp7XW)
	jjXDpagEkxQqWBVtwh9Fu1Gmb = y0yvdNOZkiKEg5RLMhoDVQAB9F2
else:
	import zpCIRgy3H2
	try: zpCIRgy3H2.HISTqlOirzge9(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ,MFTEUm2pj39R7oa14D8lXk,Zy2eBLfrukDI,FYewgcm2IAtNsSzDC5l6MHqBoZ8Rk,JrzealiFtp6)
	except Exception as rrXegNV0zTcR: av1f8x5yZ9rAsq = Zt8esTLkqKnNYI.format_exc()
uOtmC6RAsjxNoyUvDh1TrJVQ(TTuO14NzmB.wvS5ocTIsy6n0dHiENWf2zUrQ7BjD,av1f8x5yZ9rAsq,jjXDpagEkxQqWBVtwh9Fu1Gmb)