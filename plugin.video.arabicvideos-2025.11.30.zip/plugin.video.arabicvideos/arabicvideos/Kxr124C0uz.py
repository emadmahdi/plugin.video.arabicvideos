# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'CIMA4U'
headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5}
UT69hgqoKsWNIwM5zkAYb = '_C4U_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==420: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==421: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==422: RCmHBOKtejQ8lu4L = g06Afm3rzVEbdBPvDnSkQq(url)
	elif mode==423: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==424: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==427: RCmHBOKtejQ8lu4L = xxeypkbQhXvuP(url)
	elif mode==429: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	FFwVakdM8NvjeJRK3oyQI9ti24 = jj0dZrgiKb.findall('href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	FFwVakdM8NvjeJRK3oyQI9ti24 = FFwVakdM8NvjeJRK3oyQI9ti24[0].strip('/')
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(FFwVakdM8NvjeJRK3oyQI9ti24,'url')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,429,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر محدد',FFwVakdM8NvjeJRK3oyQI9ti24,425)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر كامل',FFwVakdM8NvjeJRK3oyQI9ti24,424)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الرئيسية',FFwVakdM8NvjeJRK3oyQI9ti24,421)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('NavigationMenu(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="*(.*?)"*>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		if '/actors' in hhEH1rcSP0z6Bkqy8OD: title = 'أفلام النجوم'
		elif '/netflix' in hhEH1rcSP0z6Bkqy8OD: title = 'أفلام ومسلسلات نيتفلكس'
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,421)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'قائمة تفصيلية',FFwVakdM8NvjeJRK3oyQI9ti24,427)
	return
def xxeypkbQhXvuP(website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('FilteringTitle(.*?)PageTitle',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for d5TLHSj39awfvFp,id,hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		if 'netflix-movies' in hhEH1rcSP0z6Bkqy8OD: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in hhEH1rcSP0z6Bkqy8OD: title = 'مسلسلات نيتفلكس'
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,d5TLHSj39awfvFp+'|'+id)
	return
def HPdaS7kenW0m(url,DT402mRilruat3EeIoM6=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if not DT402mRilruat3EeIoM6 or '|' in DT402mRilruat3EeIoM6:
		if '|' not in DT402mRilruat3EeIoM6: rvw27f5zAWgDOLnakEJhBxU6mse9IS = wUvcPrYDfISbZolAm83GKEqMyXkn5
		else: rvw27f5zAWgDOLnakEJhBxU6mse9IS = '/archive/'+DT402mRilruat3EeIoM6
		E6EKdTRc4U = False
		if 'PinSlider' in II64TLxj3mbqEyh9pHQ8oAv:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'المميزة',url,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
			E6EKdTRc4U = True
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('PageTitle(.*?)PageContent',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			i9eu0gvptXjKMAczZyE = pLHIPUY3TWAeE70[0]
			VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('data-tab="(.*?)".*?<span>(.*?)<',i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
			for Vx5J6zNYfGjZw812bQCkHPthDFlWI,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ in VV7eQk5mj1dBNiHtrcP:
				q4zyW5Bpx6Y2O = FFwVakdM8NvjeJRK3oyQI9ti24+'/ajaxcenter/action/HomepageLoader/tab/'+Vx5J6zNYfGjZw812bQCkHPthDFlWI+rvw27f5zAWgDOLnakEJhBxU6mse9IS+'/'
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ,q4zyW5Bpx6Y2O,421)
				E6EKdTRc4U = True
		if E6EKdTRc4U: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	if DT402mRilruat3EeIoM6=='featured':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('PinSlider(.*?)MultiFilter',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('PinSlider(.*?)PageTitle',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		else: IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
	elif '/filter/' in url:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('PageContent(.*?)class="*pagination"*',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	elif '/actors' in url:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('PageContent(.*?)class="*pagination"*',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('Cima4uBlocks(.*?)</li></ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		else: IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if not items: items = jj0dZrgiKb.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items: items = jj0dZrgiKb.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		if not title: continue
		if '?news=' in hhEH1rcSP0z6Bkqy8OD: continue
		title = title.replace('مشاهدة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) حلقة \d+',title,jj0dZrgiKb.DOTALL)
		if xNVKL75nEZstg4wfXBkySQ and 'حلقة' in title:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,422,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/actor/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,421,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,422,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('pagination(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70 and DT402mRilruat3EeIoM6!='featured':
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,421)
	EEqHD98QhfezKTg = jj0dZrgiKb.findall('</li><a href="(.*?)".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if EEqHD98QhfezKTg:
		hhEH1rcSP0z6Bkqy8OD,title = EEqHD98QhfezKTg[0]
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,421)
	return
def g06Afm3rzVEbdBPvDnSkQq(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-SEASONS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="WatchNow".*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		url = pLHIPUY3TWAeE70[0]
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-SEASONS-2nd')
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('SeasonsSections(.*?)</div></div></div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if '/tag/' in url or '/actor' in url:
		HPdaS7kenW0m(url)
	elif pLHIPUY3TWAeE70:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel('ListItem.Thumb')
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall("href='(.*?)'>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		jVaAMuiRYJkwe1Lx4QDq = ['مسلسل','موسم','برنامج','حلقة']
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if any(value in title for value in jVaAMuiRYJkwe1Lx4QDq):
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,423,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,426,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else: mCwqRg7HpivAQ6S(url)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('"background-image:url\((.*?)\)',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if cPzpeLXs3jMCltW4ZN9BaYdfQvwS: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0]
	else: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = wUvcPrYDfISbZolAm83GKEqMyXkn5
	wC6fc8LIxARe9yTuYptDqkrQW = jj0dZrgiKb.findall('EpisodesSection(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if wC6fc8LIxARe9yTuYptDqkrQW:
		IJE2xcV7OWauUKhfik56gXBwltCb = wC6fc8LIxARe9yTuYptDqkrQW[0]
		items = jj0dZrgiKb.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title,xNVKL75nEZstg4wfXBkySQ in items:
			title = title+UKFZBQAVXHI5s17LyvuRpCY2+xNVKL75nEZstg4wfXBkySQ
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,426,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+'رابط التشغيل',url,426,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	OK06ehqTx9F8JYcvViIHkzLuf7nR1N = QM9sJ7tk0oplqEwHU3DjL64d.url
	if ndib93Ol6UojCrEV: OK06ehqTx9F8JYcvViIHkzLuf7nR1N = OK06ehqTx9F8JYcvViIHkzLuf7nR1N.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(OK06ehqTx9F8JYcvViIHkzLuf7nR1N,'url')
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('WatchSection(.*?)</div></div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('data-link="(.*?)".*? />(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for LoCyDnPKj2N7RsmcI0WwAZTE,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if 'myvid' in title.lower(): title = 'خاص '+title
			hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/structure/server.php?id='+LoCyDnPKj2N7RsmcI0WwAZTE+'?named='+title+'__watch'
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('DownloadServers(.*?)</div></div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*? />(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if 'myvid' in title.lower(): HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = '__خاص'
			else: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = wUvcPrYDfISbZolAm83GKEqMyXkn5
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/Search?q='+search
	HPdaS7kenW0m(url,'search')
	return
def fFLoASm2V96qUBCEHzGJjyc(url):
	if 'smartemadfilter' not in url: url = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('MultiFilter(.*?)PageTitle',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = jj0dZrgiKb.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return Q9cBo8ysZbM3L4Ttvd7nF6Nk
def e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb):
	items = jj0dZrgiKb.findall('data-id="(.*?)".*?</div>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return items
def U0r9RGnOsXJ3fDdvepcCSjIt(url):
	lnpS3fLJa4GiNoctb = url.split('/smartemadfilter?')[0]
	U62oVRpWuriEJAwedHOxStI9m8bCQ = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	url = url.replace(lnpS3fLJa4GiNoctb,U62oVRpWuriEJAwedHOxStI9m8bCQ)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
tIU8BcnSMHNX6aFdzTJ0Y9KjoO = ['category','types','release-year']
l0pkODK9d5qmZXWcotGHrU = ['Quality','release-year','types','category']
def mmUxVlf7ZQMjeDE(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global tIU8BcnSMHNX6aFdzTJ0Y9KjoO
			tIU8BcnSMHNX6aFdzTJ0Y9KjoO = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[1:]
		if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]+'=' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0:-1])):
			if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'=' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+d5TLHSj39awfvFp+'=0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+d5TLHSj39awfvFp+'=0'
		qclt2BMvQu = M2MhYTzotC0.strip('&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
	elif type=='ALL_ITEMS_FILTER':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		if mVhHg8LIlYR5cM9d7PfB==wUvcPrYDfISbZolAm83GKEqMyXkn5: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+mVhHg8LIlYR5cM9d7PfB
		ZD5n0eJivzWOMxY98dgrumkwRG = U0r9RGnOsXJ3fDdvepcCSjIt(ZD5n0eJivzWOMxY98dgrumkwRG)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها ',ZD5n0eJivzWOMxY98dgrumkwRG,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',ZD5n0eJivzWOMxY98dgrumkwRG,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = fFLoASm2V96qUBCEHzGJjyc(url)
	dict = {}
	for name,IJE2xcV7OWauUKhfik56gXBwltCb,VaqykB2YmTbCtUDl in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		if '/category/' in url and VaqykB2YmTbCtUDl=='category': continue
		name = name.replace('--',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		items = e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb)
		if '=' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='SPECIFIED_FILTER':
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<2:
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]:
					url = U0r9RGnOsXJ3fDdvepcCSjIt(url)
					HPdaS7kenW0m(url)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'SPECIFIED_FILTER___'+qclt2BMvQu)
				return
			else:
				ZD5n0eJivzWOMxY98dgrumkwRG = U0r9RGnOsXJ3fDdvepcCSjIt(ZD5n0eJivzWOMxY98dgrumkwRG)
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,425,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='ALL_ITEMS_FILTER':
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'=0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'=0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع :'+name,ZD5n0eJivzWOMxY98dgrumkwRG,424,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for value,sslNS0zetni1HDbZRQOCMxJ4AfhaP in items:
			if value=='196533': sslNS0zetni1HDbZRQOCMxJ4AfhaP = 'أفلام نيتفلكس'
			elif value=='196531': sslNS0zetni1HDbZRQOCMxJ4AfhaP = 'مسلسلات نيتفلكس'
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			dict[VaqykB2YmTbCtUDl][value] = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'='+sslNS0zetni1HDbZRQOCMxJ4AfhaP
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'#+dict[VaqykB2YmTbCtUDl]['0']
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'+name
			if type=='ALL_ITEMS_FILTER': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,424,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='SPECIFIED_FILTER' and tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-2]+'=' in yzamv2DUurjwolVq:
				NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'modified_filters')
				qaLFXuDExl8w = url+'/smartemadfilter?'+NGik0Ke4WwfT2
				qaLFXuDExl8w = U0r9RGnOsXJ3fDdvepcCSjIt(qaLFXuDExl8w)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,qaLFXuDExl8w,421,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'filter')
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,425,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.replace('=&','=0&')
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&')
	wHOxpbdkJBM0ZC7 = {}
	if '=' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('=')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for key in l0pkODK9d5qmZXWcotGHrU:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if '%' not in value: value = vvLTYxVfrbDza(value)
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
		elif mode=='all': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.replace('=0','=')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm