# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
UdbRGoKhcDeI4lVfns5 = 'AKOAMCAM'
UT69hgqoKsWNIwM5zkAYb = '_AKC_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['مصارعة']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==350: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==351: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==352: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==353: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==354: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'FILTERS___'+text)
	elif mode==355: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'CATEGORIES___'+text)
	elif mode==356: RCmHBOKtejQ8lu4L = jjziYR0PoqyZf(url)
	elif mode==357: RCmHBOKtejQ8lu4L = EE7oeRk3UbLPK8iBzsyfIgaCj(url)
	elif mode==359: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+'هذا الموقع مغلق'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,8)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,359,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر محدد',hhD7r1VvaPt3TC06SJjqKRfEid,356)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر كامل',hhD7r1VvaPt3TC06SJjqKRfEid,357)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-MENU-1st')
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('recently-container.*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]
	else: ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'اضيف حديثا',ZD5n0eJivzWOMxY98dgrumkwRG,351)
	ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('@id":"(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[0]
	else: ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المميزة',ZD5n0eJivzWOMxY98dgrumkwRG,351,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('main-categories-list(.*?)main-categories-list',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?class="font.*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title not in i6TIRax9v0EDFJs2gVtfzp: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,351)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="categories-box(.*?)<footer',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(hhEH1rcSP0z6Bkqy8OD)
			if title not in i6TIRax9v0EDFJs2gVtfzp: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,351)
	return II64TLxj3mbqEyh9pHQ8oAv
def jjziYR0PoqyZf(website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="menu(.*?)<nav',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?text">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title not in i6TIRax9v0EDFJs2gVtfzp:
				title = title+' مصنفة'
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,355)
		if website==wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	return II64TLxj3mbqEyh9pHQ8oAv
def EE7oeRk3UbLPK8iBzsyfIgaCj(website=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="menu(.*?)<nav',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?text">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title not in i6TIRax9v0EDFJs2gVtfzp:
				title = title+' مفلترة'
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,354)
		if website==wUvcPrYDfISbZolAm83GKEqMyXkn5: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('swiper-container(.*?)swiper-button-prev',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="container"(.*?)main-footer',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		v2v3ase4WBgVjbOnu96PCzlDKi = []
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|الحلقه) \d+',title,jj0dZrgiKb.DOTALL)
				if xNVKL75nEZstg4wfXBkySQ:
					title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
					if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
						mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,352,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
						v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			elif 'مسلسل' in title:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,352,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
			else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,353,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('pagination(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href=["\'](.*?)["\'].*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(hhEH1rcSP0z6Bkqy8OD)
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,351)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/?s='+LBqdVs9ioWwpMbCm1A
	RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	return
def mCwqRg7HpivAQ6S(url):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAMCAM-EPISODES-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('text-white">الحلقات(.*?)<header',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		rNmzwKLcvbTquoFB6 = jj0dZrgiKb.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in rNmzwKLcvbTquoFB6:
			if 'الحلقة' in title or 'الحلقه' in title: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,353,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel('ListItem.Icon')
		if II64TLxj3mbqEyh9pHQ8oAv.count('<title>')>1: title = jj0dZrgiKb.findall('<title>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[1]
		else: title = 'رابط التشغيل'
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,url,353,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,Eu8LWnSt3fyJzIC = [],[]
	zCeDypBLAm1MhiW0q = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = zCeDypBLAm1MhiW0q.content
	E2Y7y4Av63tqhSVQ50iTmN = jj0dZrgiKb.findall('post_id=(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if E2Y7y4Av63tqhSVQ50iTmN:
		E2Y7y4Av63tqhSVQ50iTmN = E2Y7y4Av63tqhSVQ50iTmN[0]
		headers = {'User-Agent':wUvcPrYDfISbZolAm83GKEqMyXkn5,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':E2Y7y4Av63tqhSVQ50iTmN}
		ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		B3XEz8Oiwsuon = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'POST',ZD5n0eJivzWOMxY98dgrumkwRG,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-PLAY-1st')
		xnGN2vER8iQqJkcFt4KWup = B3XEz8Oiwsuon.content
		items = jj0dZrgiKb.findall('data-server="(.*?)".*?class="text">(.*?)<',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		for LoCyDnPKj2N7RsmcI0WwAZTE,name in items:
			hhEH1rcSP0z6Bkqy8OD = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?postid='+E2Y7y4Av63tqhSVQ50iTmN+'&serverid='+LoCyDnPKj2N7RsmcI0WwAZTE+'?named='+name+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			Eu8LWnSt3fyJzIC.append(name)
		ZD5n0eJivzWOMxY98dgrumkwRG = hhD7r1VvaPt3TC06SJjqKRfEid+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		B3XEz8Oiwsuon = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'POST',ZD5n0eJivzWOMxY98dgrumkwRG,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'AKOAMCAM-PLAY-1st')
		xnGN2vER8iQqJkcFt4KWup = B3XEz8Oiwsuon.content
		items = jj0dZrgiKb.findall('href="(.*?)".*?class="text">(.*?)<',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
			Eu8LWnSt3fyJzIC.append(title)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def mmUxVlf7ZQMjeDE(url,filter):
	tIU8BcnSMHNX6aFdzTJ0Y9KjoO = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='CATEGORIES':
		if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]+'=' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0:-1])):
			if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'=' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+d5TLHSj39awfvFp+'=0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+d5TLHSj39awfvFp+'=0'
		qclt2BMvQu = M2MhYTzotC0.strip('&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'all')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'?'+NGik0Ke4WwfT2
	elif type=='FILTERS':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'all')
		if mVhHg8LIlYR5cM9d7PfB==wUvcPrYDfISbZolAm83GKEqMyXkn5: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'?'+mVhHg8LIlYR5cM9d7PfB
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها',ZD5n0eJivzWOMxY98dgrumkwRG,351,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',ZD5n0eJivzWOMxY98dgrumkwRG,351,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1')
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<form id(.*?)</form>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = jj0dZrgiKb.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	dict = {}
	for VaqykB2YmTbCtUDl,name,IJE2xcV7OWauUKhfik56gXBwltCb in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		items = jj0dZrgiKb.findall('<option(.*?)>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if '=' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='CATEGORIES':
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<=1:
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]: HPdaS7kenW0m(ZD5n0eJivzWOMxY98dgrumkwRG)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'CATEGORIES___'+qclt2BMvQu)
				return
			else:
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,351,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1')
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,355,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='FILTERS':
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'=0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'=0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع : '+name,ZD5n0eJivzWOMxY98dgrumkwRG,354,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for value,sslNS0zetni1HDbZRQOCMxJ4AfhaP in items:
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			if 'value' not in value: value = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			else: value = jj0dZrgiKb.findall('"(.*?)"',value,jj0dZrgiKb.DOTALL)[0]
			dict[VaqykB2YmTbCtUDl][value] = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'='+sslNS0zetni1HDbZRQOCMxJ4AfhaP
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' : '#+dict[VaqykB2YmTbCtUDl]['0']
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' : '+name
			if type=='FILTERS': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,354,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='CATEGORIES' and tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-2]+'=' in yzamv2DUurjwolVq:
				NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'all')
				qaLFXuDExl8w = url+'?'+NGik0Ke4WwfT2
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,qaLFXuDExl8w,351,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1')
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,355,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&')
	wHOxpbdkJBM0ZC7 = {}
	if '=' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('=')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = wUvcPrYDfISbZolAm83GKEqMyXkn5
	l0pkODK9d5qmZXWcotGHrU = ['cat','genre','release-year','quality','orderby']
	for key in l0pkODK9d5qmZXWcotGHrU:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
		elif mode=='all': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm