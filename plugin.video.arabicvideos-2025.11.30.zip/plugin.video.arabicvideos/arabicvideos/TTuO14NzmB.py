# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from aVsS7DW8Qd import *
SITESURLS = {
			 lCT8hfYUBX4OQMmL(u"ࠬࡇࡈࡘࡃࡎࠫಮ")		:[jQv0du1iVxTgAXCM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨಯ")]
			,fmkZtbRj3ux(u"ࠧࡂࡍࡒࡅࡒ࠭ರ")		:[xdSThjYnuHXAU6M(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬಱ")]
			,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡄࡏ࡜ࡇࡍࠨಲ")		:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸࠪಳ")]
			,rDG9dZoXRhCJcieUSF0KB(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧ಴")	:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡯ࡼࡧ࡭࠯ࡶࡸࡦࡪ࠭ವ")]
			,DpRJnas65uVcO0S17dYG(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨಶ")		:[D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭ಷ")]
			,w8JC1y7Lp3(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩಸ")		:[xdSThjYnuHXAU6M(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮ࡰࡷࡹࡨࡡ࠯ࡶࡹࠫಹ")]
			,A6Sg45ChDR3BJLYfFH(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ಺")		:[vWNRusF46D7Mi8GpZ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡪ࡯ࡨࡾ࡮ࡪ࠮ࡴࡪࡲࡻࠬ಻")]
			,vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ಼ࠪ")	:[DpRJnas65uVcO0S17dYG(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭ಽ")]
			,w8JC1y7Lp3(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩಾ")		:[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨಿ")]
			,erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡄ࡝ࡑࡕࡌࠨೀ")		:[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫࠮ࡢࡻ࡯ࡳࡱ࠴࡮ࡦࡶࠪು")]
			,D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࡇࡕࡋࡓࡃࠪೂ")		:[vWNRusF46D7Mi8GpZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩࡲࡩࡷࡧ࠱ࡧࡴ࠭ೃ")]
			,MFhbWia58mP3su0fk2d(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ೄ")		:[kPCxIUZb1V(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ೅")]
			,vWNRusF46D7Mi8GpZ(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩೆ")		:[vvhR5ozeiJpANyl8fFO3GBw(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨೇ")]
			,MFhbWia58mP3su0fk2d(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪೈ")		:[erqDsJmL3BQHuGtPkcf0X9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡤ࡫ࡰࡥ࠹ࡶ࠮ࡤࡱࡰࠫ೉")]
			,MFhbWia58mP3su0fk2d(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬೊ")		:[erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬೋ")]
			,A6Sg45ChDR3BJLYfFH(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩೌ")		:[dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡱ࠳ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰ್ࠫ")]
			,Gj3rMP1Cb8wHdp49la0(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ೎")		:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯ࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡤ࡮ࡸࡦࠬ೏")]
			,xm6jK1ZMuWq5(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ೐")	:[xm6jK1ZMuWq5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡷࡸ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹࡨࡰࡲࠪ೑")]
			,vWNRusF46D7Mi8GpZ(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ೒")		:[rDG9dZoXRhCJcieUSF0KB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࠪ೓")]
			,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ೔")		:[jQv0du1iVxTgAXCM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨೕ")]
			,JHMxIE4fs1mvQtKW7R(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ೖ")	:[DpRJnas65uVcO0S17dYG(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪ೗")]
			,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೘")		:[vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫ೙")]
			,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ೚")		:[D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡽࡨ࡯࡭ࡢ࠰ࡦࡧࠬ೛")]
			,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ೜")	:[DpRJnas65uVcO0S17dYG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪೝ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬೞ"),JHMxIE4fs1mvQtKW7R(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡣࡵࡧ࡭࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ೟")]
			,VhqD3zp7mUieI8sMQlETH(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩೠ")	:[rDG9dZoXRhCJcieUSF0KB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠹࠳ࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨೡ")]
			,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩೢ")		:[vWNRusF46D7Mi8GpZ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡨࡷࡧ࡭ࡢࡵ࠺࠲ࡳ࡫ࡴࠨೣ")]
			,w8JC1y7Lp3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ೤")		:[weh7SGmuTgXOVRcMo1rlLq(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡦࡶࡰࠪ೥")]
			,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ೦")		:[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰࡨࡻࡸ࠭೧")]
			,lCT8hfYUBX4OQMmL(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ೨")		:[erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨ೩")]
			,A6Sg45ChDR3BJLYfFH(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ೪")		:[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ೫")]
			,xdSThjYnuHXAU6M(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ೬")		:[xm6jK1ZMuWq5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬ೭")]
			,fmkZtbRj3ux(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ೮")		:[Gj3rMP1Cb8wHdp49la0(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ೯")]
			,lCT8hfYUBX4OQMmL(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫ೰")	:[s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠱ࡩࡱ࡯ࡦ࠯ࡰࡨࡻࡸ࠭ೱ")]
			,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫೲ")		:[A6Sg45ChDR3BJLYfFH(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩೳ")]
			,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ೴")	:[VhqD3zp7mUieI8sMQlETH(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫ೵")]
			,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨ೶")		:[Gj3rMP1Cb8wHdp49la0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡵ࠴ࡦࡢࡴࡨࡷࡰࡵ࠮࡯ࡧࡷࠫ೷")]
			,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ೸")		:[DpRJnas65uVcO0S17dYG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩ೹")]
			,w8JC1y7Lp3(u"ࠫࡋࡕࡓࡕࡃࠪ೺")		:[vWNRusF46D7Mi8GpZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩ೻")]
			,xm6jK1ZMuWq5(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧ೼")		:[JHMxIE4fs1mvQtKW7R(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࠱ࡥࡱࡳࡥࡴࡪ࡮ࡥ࡭࠴࡮ࡦࡶࠪ೽")]
			,xdSThjYnuHXAU6M(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ೾")		:[fmkZtbRj3ux(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦ࠳࡬ࡵࡴࡪࡤࡶ࠲ࡺࡶ࠯ࡥࡲࡱࠬ೿")]
			,VhqD3zp7mUieI8sMQlETH(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨഀ")	:[llkFwuCyhaP3sK76qO4T(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡧࡷࡶ࡬ࡦࡸ࠮ࡷ࡫ࡧࡩࡴ࠭ഁ")]
			,xdSThjYnuHXAU6M(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧം")		:[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡩࡣ࡯ࡥࡨ࡯࡭ࡢ࠰ࡰࡩࡩ࡯ࡡࠨഃ")]
			,jQv0du1iVxTgAXCM(u"ࠧࡊࡈࡌࡐࡒ࠭ഄ")		:[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩഅ"),xm6jK1ZMuWq5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪആ"),bQGafNLXyFgsZP6ut(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫഇ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠳࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ഈ"),w8JC1y7Lp3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠿࠳࠯࠳࠼࠴࠳࠸࠴࠯࠳࠵࠶ࠬഉ")]
			,llkFwuCyhaP3sK76qO4T(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩഊ")	:[llkFwuCyhaP3sK76qO4T(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡤࡶࡧࡧ࡬ࡢ࠯ࡷࡺ࠳࡯ࡱࠨഋ")]
			,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪഌ")		:[lCT8hfYUBX4OQMmL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡺ࡫ࡰࡶ࠱ࡧࡦࡳࠧ഍")]
			,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫഎ")		:[xdSThjYnuHXAU6M(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡵ࠯࡭࡬ࡶࡲࡧ࡬࡬࠰ࡦࡳࡲ࠭ഏ")]
			,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬഐ")		:[vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡣࡵࡳࡿࡧ࠮ࡪࡰ࡮ࠫ഑")]
			,MFhbWia58mP3su0fk2d(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨഒ")		:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡪࡺࡴࠧഓ")]
			,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬഔ")	:[JHMxIE4fs1mvQtKW7R(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮࡮ࡣࡶࡥ࠳ࡴࡥࡸࡵࠪക")]
			,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡕࡇࡎࡆࡖࠪഖ")		:[s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧഗ")]
			,vWNRusF46D7Mi8GpZ(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨഘ")		:[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫࠲ࡩࡲࡧࡤࡠࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡰ࡮ࡧ࠳࡮ࡴࡤࡦࡺ࠱࡬ࡹࡳ࡬ࠨങ")]
			,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬച")	:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦ࠴ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧ࠱ࡧࡦࡳࠧഛ")]
			,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬജ")		:[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠲࠺ࡵ࠯࡯ࡼࠫഝ")]
			,MFhbWia58mP3su0fk2d(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠲ࠨഞ")	:[jQv0du1iVxTgAXCM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰ࡩࡳࡷࡻ࡭ࠨട")]
			,yRWQMHxZEz0(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫഠ")	:[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧഡ")]
			,vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡖࡌࡔࡌࡈࡂࠩഢ")		:[bQGafNLXyFgsZP6ut(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧണ")]
			,Gj3rMP1Cb8wHdp49la0(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ത")		:[TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬഥ"),vWNRusF46D7Mi8GpZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ദ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪധ")]
			,MFhbWia58mP3su0fk2d(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪന")		:[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡳࡩࡱࡲࡪࡳ࡫ࡴ࠯ࡱࡱࡰ࡮ࡴࡥࠨഩ")]
			,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡘࡎࡑࡁࡂࡖࠪപ")		:[VhqD3zp7mUieI8sMQlETH(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡬ࡣࡤࡸ࠳ࡴࡥࡵࠩഫ")]
			,VhqD3zp7mUieI8sMQlETH(u"࡚ࠬࡖࡇࡗࡑࠫബ")		:[rDG9dZoXRhCJcieUSF0KB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫഭ")]
			,fmkZtbRj3ux(u"ࠧࡗࡃࡕࡆࡔࡔࠧമ")		:[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰ࠲ࡻࡧࡲࡣࡱࡱ࠲ࡨࡧ࡭ࠨയ")]
			,w8JC1y7Lp3(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭ര")	:[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡲࡸࡧࡥ࡮࠰ࡱࡩࡹ࠭റ")]
			,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬല")		:[vWNRusF46D7Mi8GpZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡴࡦࡣࡰࠫള")]
			,JHMxIE4fs1mvQtKW7R(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧഴ")		:[vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡣࡦࠫവ")]
			,lCT8hfYUBX4OQMmL(u"ࠨ࡛ࡄࡕࡔ࡚ࠧശ")		:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧഷ")]
			,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫസ")		:[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧഹ")]
			,xdSThjYnuHXAU6M(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫഺ")	:[gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮഻ࠩ")]
			,xm6jK1ZMuWq5(u"ࠧࡊࡒࡗ഼࡚ࠬ")			:[wUvcPrYDfISbZolAm83GKEqMyXkn5]
			,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡏ࠶࡙ࠬഽ")			:[wUvcPrYDfISbZolAm83GKEqMyXkn5]
			,yRWQMHxZEz0(u"ࠩࡕࡉࡕࡕࡓࠨാ")		:[rDG9dZoXRhCJcieUSF0KB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪി"),jQv0du1iVxTgAXCM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨീ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩു")]
			,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪൂ")	:[xdSThjYnuHXAU6M(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫൃ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩൄ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ൅")]
			,vWNRusF46D7Mi8GpZ(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧെ")	:[vWNRusF46D7Mi8GpZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩേ"),Gj3rMP1Cb8wHdp49la0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧൈ"),VhqD3zp7mUieI8sMQlETH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ൉")]
			,xdSThjYnuHXAU6M(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫൊ")	:[vWNRusF46D7Mi8GpZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩോ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧൌ"),xdSThjYnuHXAU6M(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ്")]
			,fmkZtbRj3ux(u"ࠫࡐࡕࡄࡊࡡࡖࡓ࡚ࡘࡃࡆࡕࠪൎ")	:[D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯ࠧ൏"),xdSThjYnuHXAU6M(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡱ࡯ࡥ࡫ࠪ൐"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭൑")]
			,xdSThjYnuHXAU6M(u"ࠨࡈࡌࡐࡊ࡙࡟ࡔࡑࡘࡖࡈࡋࡓࠨ൒"):[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱࠩ൓")]
			,Gj3rMP1Cb8wHdp49la0(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩൔ")	:[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧൕ"),DpRJnas65uVcO0S17dYG(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࠯ࡨࡺࡷ࠳ࡹࡴࡰࡴࡨࠫൖ")]
			}
if UD4N8MjVTd:
	SITESURLS[xm6jK1ZMuWq5(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ൗ")]      = [jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ൘"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭൙"),bQGafNLXyFgsZP6ut(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ൚"),llkFwuCyhaP3sK76qO4T(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ൛"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ൜"),jQv0du1iVxTgAXCM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ൝"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ൞"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨൟ"),fmkZtbRj3ux(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩൠ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧൡ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ൢ"),yRWQMHxZEz0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ൣ")]
	SITESURLS[DpRJnas65uVcO0S17dYG(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪ൤")] = [VhqD3zp7mUieI8sMQlETH(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ൥"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ൦"),vWNRusF46D7Mi8GpZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭൧"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ൨"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ൩"),MFhbWia58mP3su0fk2d(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ൪"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ൫"),weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩ൬"),Gj3rMP1Cb8wHdp49la0(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ൭"),vWNRusF46D7Mi8GpZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ൮"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧ൯"),bQGafNLXyFgsZP6ut(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧ൰")]
	SITESURLS[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩ൱")] = [D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ൲"),xdSThjYnuHXAU6M(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ൳"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ൴"),fmkZtbRj3ux(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ൵"),fmkZtbRj3ux(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ൶"),jQv0du1iVxTgAXCM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ൷"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭൸"),bQGafNLXyFgsZP6ut(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ൹"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨൺ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ൻ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬർ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬൽ")]
	SITESURLS[yRWQMHxZEz0(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨൾ")] = [TNw1pBHb8CtSZe0EFxuJqI(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪൿ"),A6Sg45ChDR3BJLYfFH(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ඀"),s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ඁ"),jQv0du1iVxTgAXCM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩං"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩඃ"),jQv0du1iVxTgAXCM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ඄"),w8JC1y7Lp3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨඅ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩආ"),DpRJnas65uVcO0S17dYG(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪඇ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨඈ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧඉ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧඊ")]
else:
	SITESURLS[JHMxIE4fs1mvQtKW7R(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩඋ")]      = [MFhbWia58mP3su0fk2d(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ඌ"),xm6jK1ZMuWq5(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪඍ"),kPCxIUZb1V(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩඎ"),jQv0du1iVxTgAXCM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬඏ"),A6Sg45ChDR3BJLYfFH(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬඐ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨඑ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫඒ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬඓ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ඔ"),JHMxIE4fs1mvQtKW7R(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫඕ"),llkFwuCyhaP3sK76qO4T(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪඖ"),llkFwuCyhaP3sK76qO4T(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪ඗")]
	SITESURLS[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭඘")] = [MFhbWia58mP3su0fk2d(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ඙"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩක"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨඛ"),VhqD3zp7mUieI8sMQlETH(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫග"),xdSThjYnuHXAU6M(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫඝ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧඞ"),A6Sg45ChDR3BJLYfFH(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪඟ"),DpRJnas65uVcO0S17dYG(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫච"),bQGafNLXyFgsZP6ut(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬඡ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪජ"),w8JC1y7Lp3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩඣ"),s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩඤ")]
	SITESURLS[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬඥ")] = [erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫඦ"),it4DKnryZlx(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨට"),DpRJnas65uVcO0S17dYG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧඨ"),bQGafNLXyFgsZP6ut(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඩ"),Gj3rMP1Cb8wHdp49la0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪඪ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ණ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩඬ"),kPCxIUZb1V(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪත"),rDG9dZoXRhCJcieUSF0KB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫථ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩද"),bQGafNLXyFgsZP6ut(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨධ"),A6Sg45ChDR3BJLYfFH(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨන")]
	SITESURLS[erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫ඲")] = [kPCxIUZb1V(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪඳ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧප"),Gj3rMP1Cb8wHdp49la0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ඵ"),xm6jK1ZMuWq5(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩබ"),fmkZtbRj3ux(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩභ"),it4DKnryZlx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬම"),jQv0du1iVxTgAXCM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨඹ"),jQv0du1iVxTgAXCM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩය"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪර"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ඼"),rDG9dZoXRhCJcieUSF0KB(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧල"),VhqD3zp7mUieI8sMQlETH(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧ඾")]
api_python_actions = [it4DKnryZlx(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ඿"),erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧව"),xm6jK1ZMuWq5(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧශ"),bQGafNLXyFgsZP6ut(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪෂ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫස"),xdSThjYnuHXAU6M(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭හ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩළ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ෆ"),xdSThjYnuHXAU6M(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧ෇"),w8JC1y7Lp3(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩ෈"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡇ࡛ࡉࡈ࡛ࡔࡆࡌࡖࠫ෉"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡚ࠩࡉࡇࡉࡁࡄࡊࡈ්ࠫ")]
api_repos_actions = [gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡅࡉࡊࡏࡏࡕࠪ෋"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭෌"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ෍")]
non_videos_actions = [llkFwuCyhaP3sK76qO4T(u"࠭ࡁࡍࡎࠪ෎"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧා"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩැ"),xdSThjYnuHXAU6M(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ෑ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡖࡊࡖࡏࡔࠩි"),it4DKnryZlx(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧී"),lCT8hfYUBX4OQMmL(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨු"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬ෕"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡈࡇࡗࡍࡉ࠭ූ"),w8JC1y7Lp3(u"ࠨࡕࡌࡘࡊ࡙ࡕࡓࡎࡖࠫ෗")]+api_python_actions+api_repos_actions
o4ZShCq8b53OYkUjrAwGDm1pT7PW = Z19pUxa2gfGMNKoDsEuytn85SjFvA
ijmTSzJ1l9Nutf3aoVEZk = y0yvdNOZkiKEg5RLMhoDVQAB9F2
lOuLW0pjdgS4zX = Z19pUxa2gfGMNKoDsEuytn85SjFvA
W1haXcb7tVZ6K = Z19pUxa2gfGMNKoDsEuytn85SjFvA
avprivsnorestrict = Z19pUxa2gfGMNKoDsEuytn85SjFvA
avprivslongperiod = Z19pUxa2gfGMNKoDsEuytn85SjFvA
resolveonly = Z19pUxa2gfGMNKoDsEuytn85SjFvA
wvS5ocTIsy6n0dHiENWf2zUrQ7BjD = Z19pUxa2gfGMNKoDsEuytn85SjFvA
ALLOW_DNS_FIX = b02zsRFX8MweUniGfyPHEZcv7p5WK3
ALLOW_PROXY_FIX = b02zsRFX8MweUniGfyPHEZcv7p5WK3
ALLOW_SHOWDIALOGS_FIX = b02zsRFX8MweUniGfyPHEZcv7p5WK3
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [jQv0du1iVxTgAXCM(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫෘ"),xdSThjYnuHXAU6M(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ෙ"),A6Sg45ChDR3BJLYfFH(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬේ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧෛ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ො"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩෝ"),jQv0du1iVxTgAXCM(u"ࠨ࡛ࡄࡕࡔ࡚ࠧෞ"),it4DKnryZlx(u"࡙ࠩࡅࡗࡈࡏࡏࠩෟ"),kPCxIUZb1V(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ෠"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡕࡇࡎࡆࡖࠪ෡"),DpRJnas65uVcO0S17dYG(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ෢")]
BADWEBSITES += [kPCxIUZb1V(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ෣")]
BADCOMMONIDS = [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫ෤"),llkFwuCyhaP3sK76qO4T(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬ෥")]
GEOLOCATION_DATA = wUvcPrYDfISbZolAm83GKEqMyXkn5
AV_CLIENT_IDS = wUvcPrYDfISbZolAm83GKEqMyXkn5
DNS_SERVERS = [JHMxIE4fs1mvQtKW7R(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ෦"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ෧"),VhqD3zp7mUieI8sMQlETH(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ෨"),VhqD3zp7mUieI8sMQlETH(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭෩"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ෪"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ෫")]
busydialog_active = Z19pUxa2gfGMNKoDsEuytn85SjFvA
dns_succeeded_urls = []
scrapers_succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA