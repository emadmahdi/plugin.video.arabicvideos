# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'GLOBALSEARCH'
UT69hgqoKsWNIwM5zkAYb = '_GLS_'
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq,sbNukjOf4chz):
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==540: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==541: RCmHBOKtejQ8lu4L = fJm93guIcwMYqbCRQ0KdaZsO7oj(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==542: RCmHBOKtejQ8lu4L = NSUCecEOlj(eIRJAgj25bzvNik48puZl3OPUq,iE0GxkBnVRO4NPwleT,sbNukjOf4chz)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==543: RCmHBOKtejQ8lu4L = rv3oCcNAnMhmVx8eSQ0dYDB5()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==548: RCmHBOKtejQ8lu4L = qqolaD2Vm67J8tU9zMGpHjdRvWsh(iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==549: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(eIRJAgj25bzvNik48puZl3OPUq)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder','بحث جديد لجميع المواقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,549)
	mwOxEyYAg63B('link','كيف يعمل بحث جميع المواقع','',543)
	mwOxEyYAg63B('link',JegF7SlMawI03+'==== كلمات البحث المخزنة ===='+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4 = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4:
		ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4 = ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4['__SEQUENCED_COLUMNS__']
		for vli6AtMjqfwmKnP0z1E in reversed(ZNb5RC9YQ3hcBLVsJIS2iHTokwxGj4):
			mwOxEyYAg63B('folder',vli6AtMjqfwmKnP0z1E,wUvcPrYDfISbZolAm83GKEqMyXkn5,549,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vli6AtMjqfwmKnP0z1E)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(vli6AtMjqfwmKnP0z1E):
	if not vli6AtMjqfwmKnP0z1E:
		vli6AtMjqfwmKnP0z1E = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not vli6AtMjqfwmKnP0z1E: return
		vli6AtMjqfwmKnP0z1E = vli6AtMjqfwmKnP0z1E.lower()
	WXLft9mQVHqp = vli6AtMjqfwmKnP0z1E.replace(UT69hgqoKsWNIwM5zkAYb,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	M1PYzHIgEf6qQL3(WXLft9mQVHqp,'_ALL',True)
	mwOxEyYAg63B('link','بحث جماعي للمواقع - '+WXLft9mQVHqp,'search_sites_all',542,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('folder','بحث منفرد للمواقع - '+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,541,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('link',JegF7SlMawI03+'===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder','نتائج البحث مفصلة - '+WXLft9mQVHqp,'opened_sites_all',542,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	mwOxEyYAg63B('folder','نتائج البحث مقسمة - '+WXLft9mQVHqp,'listed_sites_all',542,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,WXLft9mQVHqp)
	return
def M1PYzHIgEf6qQL3(M3cARhqsmFwWTaXz1iOf,QUROnhzxp3a85o7,QoPGl8pSeOJwTHignt):
	if QUROnhzxp3a85o7=='_ALL': VKieOQtmspvcNEFWgA = '_GLS_'
	elif QUROnhzxp3a85o7=='_GOOGLE': VKieOQtmspvcNEFWgA = '_GOS_'
	uuAReMhI4dgLNwKtojfx3bG2mpl = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,M3cARhqsmFwWTaXz1iOf)
	xLKMGWsO3DJY5qRHXEb7 = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,VKieOQtmspvcNEFWgA+M3cARhqsmFwWTaXz1iOf)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,M3cARhqsmFwWTaXz1iOf)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,VKieOQtmspvcNEFWgA+M3cARhqsmFwWTaXz1iOf)
	PHu2kf8xmVUMh4ycrEoIQZX3q7DO6 = uuAReMhI4dgLNwKtojfx3bG2mpl+xLKMGWsO3DJY5qRHXEb7
	if PHu2kf8xmVUMh4ycrEoIQZX3q7DO6 and QoPGl8pSeOJwTHignt: M3cARhqsmFwWTaXz1iOf = VKieOQtmspvcNEFWgA+M3cARhqsmFwWTaXz1iOf
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,M3cARhqsmFwWTaXz1iOf,PHu2kf8xmVUMh4ycrEoIQZX3q7DO6,CCuNYswqArnRpift4)
	return
def kfPj78TywSLnNgr9MHFxp3BZ(QUROnhzxp3a85o7):
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if ug0EmiKYnRT1qeH9MFyr3pO!=1: return
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DETAILED'+QUROnhzxp3a85o7)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DIVIDED'+QUROnhzxp3a85o7)
	if QUROnhzxp3a85o7=='_GOOGLE': P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GOOGLESEARCH_RESULTS')
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def NSUCecEOlj(Sfj9Kxdt05kwbso1GTcmQeORlhqJVi,BNxSyUFknivjmtOY3H,qxlbnSUaG53M6vXWOwf=wUvcPrYDfISbZolAm83GKEqMyXkn5,Plhyo6BKk5AY1QbsH8VzEZ=CF1Ye02AfwbLgM48Vta,UTRMO2K0Qhuwigo8={}):
	z2eqoUN6MDQmVyWd,LYw4ov5PD8Ukcl2su,QoftEq8FuORM9YdwDsGT,Ubp1IJKDEZaLM3oxYWz,YF0R8BVdZSI59QOMpibWLnqt7U16ND = [],{},{},{},{}
	if '_all' in BNxSyUFknivjmtOY3H: QUROnhzxp3a85o7,BC38zNdiIMQe,VKieOQtmspvcNEFWgA = '_ALL','_all','_GLS_'
	elif '_google' in BNxSyUFknivjmtOY3H: QUROnhzxp3a85o7,BC38zNdiIMQe,VKieOQtmspvcNEFWgA = '_GOOGLE','_google','_GOS_'
	if BNxSyUFknivjmtOY3H in ['listed_sites'+BC38zNdiIMQe,'opened_sites'+BC38zNdiIMQe,'closed_sites'+BC38zNdiIMQe]:
		if BNxSyUFknivjmtOY3H=='listed_sites'+BC38zNdiIMQe: z2eqoUN6MDQmVyWd = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,VKieOQtmspvcNEFWgA+Sfj9Kxdt05kwbso1GTcmQeORlhqJVi)
		elif BNxSyUFknivjmtOY3H=='opened_sites'+BC38zNdiIMQe: z2eqoUN6MDQmVyWd = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GLOBALSEARCH_DETAILED'+QUROnhzxp3a85o7,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi)
		elif BNxSyUFknivjmtOY3H=='closed_sites'+BC38zNdiIMQe: z2eqoUN6MDQmVyWd = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,'list','GLOBALSEARCH_DIVIDED'+QUROnhzxp3a85o7,(qxlbnSUaG53M6vXWOwf,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi))
	if not z2eqoUN6MDQmVyWd:
		Kj04L1bcTNuOoUz3Yg = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		OOZ9V4c5uT8gEl = 'هل تريد الآن البحث في جميع المواقع عن \n "'+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+UKFZBQAVXHI5s17LyvuRpCY2+Sfj9Kxdt05kwbso1GTcmQeORlhqJVi+UKFZBQAVXHI5s17LyvuRpCY2+AAByQSLgaZwCsKnvc5eWNmY+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if BNxSyUFknivjmtOY3H=='search_sites'+BC38zNdiIMQe: SLAiUwpDRoZIQfvB7 = OOZ9V4c5uT8gEl
		else: SLAiUwpDRoZIQfvB7 = Kj04L1bcTNuOoUz3Yg+OOZ9V4c5uT8gEl
		ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
		if ug0EmiKYnRT1qeH9MFyr3pO!=1: return
		vk2AWPdaQpzxMuht3ZNqfienVRwL7(uxig7mJanAYQ20,uxig7mJanAYQ20,uxig7mJanAYQ20)
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+'   Search For: [ '+Sfj9Kxdt05kwbso1GTcmQeORlhqJVi+' ]')
		PP8uyOMTsSvrYF = 1
		for g40I3ZXaeJ8qVywt in Plhyo6BKk5AY1QbsH8VzEZ:
			yYuQbE1st5c = UTRMO2K0Qhuwigo8[g40I3ZXaeJ8qVywt] if UTRMO2K0Qhuwigo8 else Sfj9Kxdt05kwbso1GTcmQeORlhqJVi
			try: iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
			except: continue
			LYw4ov5PD8Ukcl2su[g40I3ZXaeJ8qVywt] = []
			hg4F23dunEM56UpCOBk1IzoKHiwXe = '_NODIALOGS_'
			if '-' in g40I3ZXaeJ8qVywt: hg4F23dunEM56UpCOBk1IzoKHiwXe = hg4F23dunEM56UpCOBk1IzoKHiwXe+'_REMEMBERRESULTS__'+g40I3ZXaeJ8qVywt+'_'
			if PP8uyOMTsSvrYF:
				L5jXH0fZ8TvsESR.sleep(0.75)
				YF0R8BVdZSI59QOMpibWLnqt7U16ND[g40I3ZXaeJ8qVywt] = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=JSV3rnwasAZ,args=(yYuQbE1st5c+hg4F23dunEM56UpCOBk1IzoKHiwXe,))
				YF0R8BVdZSI59QOMpibWLnqt7U16ND[g40I3ZXaeJ8qVywt].start()
			else: JSV3rnwasAZ(yYuQbE1st5c+hg4F23dunEM56UpCOBk1IzoKHiwXe)
			hg79cQmoVfMCukiU8ERpT6JqywSrN3(c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt),wUvcPrYDfISbZolAm83GKEqMyXkn5,L5jXH0fZ8TvsESR=1000)
		if PP8uyOMTsSvrYF:
			L5jXH0fZ8TvsESR.sleep(2)
			for g40I3ZXaeJ8qVywt in Plhyo6BKk5AY1QbsH8VzEZ: YF0R8BVdZSI59QOMpibWLnqt7U16ND[g40I3ZXaeJ8qVywt].join(10)
			L5jXH0fZ8TvsESR.sleep(2)
		for g40I3ZXaeJ8qVywt in Plhyo6BKk5AY1QbsH8VzEZ:
			try: iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
			except: continue
			for diW61AocrJSYtmTE8v4nUkH in TTuO14NzmB.menuItemsLIST:
				TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = diW61AocrJSYtmTE8v4nUkH
				if RULru39aExTFy0tzIOGk1ivSM8Xw in LcukPqj3x6f9WDZQh5YJzg:
					if 'IPTV-' in g40I3ZXaeJ8qVywt and (239>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=230 or 289>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=280):
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['IPTV-LIVE']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['IPTV-MOVIES']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['IPTV-SERIES']: continue
						if 'صفحة' not in LcukPqj3x6f9WDZQh5YJzg:
							if   TAlYNXgaM4qzdtVUZKiubvs=='live': g40I3ZXaeJ8qVywt = 'IPTV-LIVE'
							elif TAlYNXgaM4qzdtVUZKiubvs=='video': g40I3ZXaeJ8qVywt = 'IPTV-MOVIES'
							elif TAlYNXgaM4qzdtVUZKiubvs=='folder': g40I3ZXaeJ8qVywt = 'IPTV-SERIES'
						else:
							if   'LIVE' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'IPTV-LIVE'
							elif 'MOVIES' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'IPTV-MOVIES'
							elif 'SERIES' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'IPTV-SERIES'
					elif 'M3U-' in g40I3ZXaeJ8qVywt and 729>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=710:
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['M3U-LIVE']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['M3U-MOVIES']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['M3U-SERIES']: continue
						if 'صفحة' not in LcukPqj3x6f9WDZQh5YJzg:
							if   TAlYNXgaM4qzdtVUZKiubvs=='live': g40I3ZXaeJ8qVywt = 'M3U-LIVE'
							elif TAlYNXgaM4qzdtVUZKiubvs=='video': g40I3ZXaeJ8qVywt = 'M3U-MOVIES'
							elif TAlYNXgaM4qzdtVUZKiubvs=='folder': g40I3ZXaeJ8qVywt = 'M3U-SERIES'
						else:
							if   'LIVE' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'M3U-LIVE'
							elif 'MOVIES' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'M3U-MOVIES'
							elif 'SERIES' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'M3U-SERIES'
					elif 'YOUTUBE-' in g40I3ZXaeJ8qVywt and 149>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=140:
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['YOUTUBE-CHANNELS']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['YOUTUBE-PLAYLISTS']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in LcukPqj3x6f9WDZQh5YJzg or ':: ' in LcukPqj3x6f9WDZQh5YJzg:
							continue
						else:
							if   ooPMZSnrRDG6xNpJHVmgw8IOA1==144 and 'USER' in LcukPqj3x6f9WDZQh5YJzg: g40I3ZXaeJ8qVywt = 'YOUTUBE-CHANNELS'
							elif ooPMZSnrRDG6xNpJHVmgw8IOA1==144 and 'CHNL' in LcukPqj3x6f9WDZQh5YJzg: g40I3ZXaeJ8qVywt = 'YOUTUBE-CHANNELS'
							elif ooPMZSnrRDG6xNpJHVmgw8IOA1==144 and 'LIST' in LcukPqj3x6f9WDZQh5YJzg: g40I3ZXaeJ8qVywt = 'YOUTUBE-PLAYLISTS'
							elif ooPMZSnrRDG6xNpJHVmgw8IOA1==143: g40I3ZXaeJ8qVywt = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in g40I3ZXaeJ8qVywt and 419>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=400:
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['DAILYMOTION-PLAYLISTS']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['DAILYMOTION-CHANNELS']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['DAILYMOTION-VIDEOS']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['DAILYMOTION-LIVES']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['DAILYMOTION-HASHTAGS']: continue
						if   ooPMZSnrRDG6xNpJHVmgw8IOA1 in [401,405]: g40I3ZXaeJ8qVywt = 'DAILYMOTION-PLAYLISTS'
						elif ooPMZSnrRDG6xNpJHVmgw8IOA1 in [402,406]: g40I3ZXaeJ8qVywt = 'DAILYMOTION-CHANNELS'
						elif ooPMZSnrRDG6xNpJHVmgw8IOA1 in [404]: g40I3ZXaeJ8qVywt = 'DAILYMOTION-VIDEOS'
						elif ooPMZSnrRDG6xNpJHVmgw8IOA1 in [415]: g40I3ZXaeJ8qVywt = 'DAILYMOTION-LIVES'
						elif ooPMZSnrRDG6xNpJHVmgw8IOA1 in [416]: g40I3ZXaeJ8qVywt = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in g40I3ZXaeJ8qVywt and 39>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=30:
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['PANET-SERIES']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['PANET-MOVIES']: continue
						if   ooPMZSnrRDG6xNpJHVmgw8IOA1 in [32,39]: g40I3ZXaeJ8qVywt = 'PANET-SERIES'
						elif ooPMZSnrRDG6xNpJHVmgw8IOA1 in [33,39]: g40I3ZXaeJ8qVywt = 'PANET-MOVIES'
					elif 'IFILM-' in g40I3ZXaeJ8qVywt and 29>=ooPMZSnrRDG6xNpJHVmgw8IOA1>=20:
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['IFILM-ARABIC']: continue
						if diW61AocrJSYtmTE8v4nUkH in LYw4ov5PD8Ukcl2su['IFILM-ENGLISH']: continue
						if   '/ar.' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'IFILM-ARABIC'
						elif '/en.' in iE0GxkBnVRO4NPwleT: g40I3ZXaeJ8qVywt = 'IFILM-ENGLISH'
					LYw4ov5PD8Ukcl2su[g40I3ZXaeJ8qVywt].append(diW61AocrJSYtmTE8v4nUkH)
		for g40I3ZXaeJ8qVywt in list(LYw4ov5PD8Ukcl2su.keys()):
			QoftEq8FuORM9YdwDsGT[g40I3ZXaeJ8qVywt] = []
			Ubp1IJKDEZaLM3oxYWz[g40I3ZXaeJ8qVywt] = []
			for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in LYw4ov5PD8Ukcl2su[g40I3ZXaeJ8qVywt]:
				diW61AocrJSYtmTE8v4nUkH = (TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
				if 'صفحة' in LcukPqj3x6f9WDZQh5YJzg and TAlYNXgaM4qzdtVUZKiubvs=='folder': Ubp1IJKDEZaLM3oxYWz[g40I3ZXaeJ8qVywt].append(diW61AocrJSYtmTE8v4nUkH)
				else: QoftEq8FuORM9YdwDsGT[g40I3ZXaeJ8qVywt].append(diW61AocrJSYtmTE8v4nUkH)
		hhNpGx2c54PFHAWVvswaS8,v0vu2XMzSFtbiIB1nHO = [],[]
		GMPtN6d5F74XaDfUg = list(QoftEq8FuORM9YdwDsGT.keys())
		kMim89NBdyrx = EJKdexG6Syr902gUkPlsoRNhM1H(GMPtN6d5F74XaDfUg)
		Npkw0Xclm973TWMjD5 = []
		for g40I3ZXaeJ8qVywt in kMim89NBdyrx:
			if isinstance(g40I3ZXaeJ8qVywt,tuple):
				Npkw0Xclm973TWMjD5 = [g40I3ZXaeJ8qVywt]
				continue
			if g40I3ZXaeJ8qVywt not in Plhyo6BKk5AY1QbsH8VzEZ: continue
			if QoftEq8FuORM9YdwDsGT[g40I3ZXaeJ8qVywt]:
				HS8wRluXs63ZQe = c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt)
				nGFpiZ7fTVILocSw = [('link',QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+'===== '+HS8wRluXs63ZQe+' ====='+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)]
				if 0: iLEArQnk1Fe9M5lgKXPOBJmwqNz = Sfj9Kxdt05kwbso1GTcmQeORlhqJVi+' - '+'بحث'+UKFZBQAVXHI5s17LyvuRpCY2+HS8wRluXs63ZQe
				else: iLEArQnk1Fe9M5lgKXPOBJmwqNz = 'بحث'+UKFZBQAVXHI5s17LyvuRpCY2+HS8wRluXs63ZQe+' - '+Sfj9Kxdt05kwbso1GTcmQeORlhqJVi
				if len(QoftEq8FuORM9YdwDsGT[g40I3ZXaeJ8qVywt])<8: OTathCVKZf43IRSbHnAg1 = []
				else:
					rsD29X5kYeLVUB3 = JegF7SlMawI03+iLEArQnk1Fe9M5lgKXPOBJmwqNz+AAByQSLgaZwCsKnvc5eWNmY
					OTathCVKZf43IRSbHnAg1 = [('folder',VKieOQtmspvcNEFWgA+rsD29X5kYeLVUB3,'closed_sites'+BC38zNdiIMQe,542,wUvcPrYDfISbZolAm83GKEqMyXkn5,g40I3ZXaeJ8qVywt,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)]
				H276HdFWLTVqomf4tsjheJ = QoftEq8FuORM9YdwDsGT[g40I3ZXaeJ8qVywt]+Ubp1IJKDEZaLM3oxYWz[g40I3ZXaeJ8qVywt]
				VqbvoYcFxuJXkBdDm9TCawjsU4Pg5I = Npkw0Xclm973TWMjD5+nGFpiZ7fTVILocSw+H276HdFWLTVqomf4tsjheJ[:7]+OTathCVKZf43IRSbHnAg1
				hhNpGx2c54PFHAWVvswaS8 += VqbvoYcFxuJXkBdDm9TCawjsU4Pg5I
				Jqke4Y8xtSob9zj = [('folder',VKieOQtmspvcNEFWgA+iLEArQnk1Fe9M5lgKXPOBJmwqNz,'closed_sites'+BC38zNdiIMQe,542,wUvcPrYDfISbZolAm83GKEqMyXkn5,g40I3ZXaeJ8qVywt,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)]
				Ko56vGTnEBlIPX = Npkw0Xclm973TWMjD5+Jqke4Y8xtSob9zj
				v0vu2XMzSFtbiIB1nHO += Ko56vGTnEBlIPX
				SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DIVIDED'+QUROnhzxp3a85o7,(g40I3ZXaeJ8qVywt,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi),H276HdFWLTVqomf4tsjheJ,CCuNYswqArnRpift4)
				Npkw0Xclm973TWMjD5 = []
		SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_DETAILED'+QUROnhzxp3a85o7,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi,hhNpGx2c54PFHAWVvswaS8,CCuNYswqArnRpift4)
		P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,Sfj9Kxdt05kwbso1GTcmQeORlhqJVi)
		SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,'GLOBALSEARCH_SPLITTED'+QUROnhzxp3a85o7,VKieOQtmspvcNEFWgA+Sfj9Kxdt05kwbso1GTcmQeORlhqJVi,v0vu2XMzSFtbiIB1nHO,CCuNYswqArnRpift4)
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		z2eqoUN6MDQmVyWd = v0vu2XMzSFtbiIB1nHO if BNxSyUFknivjmtOY3H=='listed_sites'+BC38zNdiIMQe and v0vu2XMzSFtbiIB1nHO else hhNpGx2c54PFHAWVvswaS8
	if BNxSyUFknivjmtOY3H in ['listed_sites'+BC38zNdiIMQe,'opened_sites'+BC38zNdiIMQe,'closed_sites'+BC38zNdiIMQe]:
		for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in z2eqoUN6MDQmVyWd:
			if BNxSyUFknivjmtOY3H in ['listed_sites'+BC38zNdiIMQe,'opened_sites'+BC38zNdiIMQe] and 'صفحة' in LcukPqj3x6f9WDZQh5YJzg and TAlYNXgaM4qzdtVUZKiubvs=='folder': continue
			mwOxEyYAg63B(TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(cc2JaqoYp8m,cc2JaqoYp8m,cc2JaqoYp8m)
	return
def fJm93guIcwMYqbCRQ0KdaZsO7oj(search):
	kMim89NBdyrx = EJKdexG6Syr902gUkPlsoRNhM1H(VVSuXlFIYdLxpCHJ54m)
	for g40I3ZXaeJ8qVywt in kMim89NBdyrx:
		if '-' in g40I3ZXaeJ8qVywt: continue
		if isinstance(g40I3ZXaeJ8qVywt,tuple):
			TTuO14NzmB.menuItemsLIST.append(g40I3ZXaeJ8qVywt)
			continue
		iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
		name = c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt)+' - '+search
		mwOxEyYAg63B('folder',RULru39aExTFy0tzIOGk1ivSM8Xw+name,g40I3ZXaeJ8qVywt,548,'','',search)
	return
def qqolaD2Vm67J8tU9zMGpHjdRvWsh(g40I3ZXaeJ8qVywt,search):
	iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
	JSV3rnwasAZ(search)
	return
def rv3oCcNAnMhmVx8eSQ0dYDB5():
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6('','',mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def ff3qS64RInsMverPdOEzDVa57G9(Sfj9Kxdt05kwbso1GTcmQeORlhqJVi=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	vli6AtMjqfwmKnP0z1E,hg4F23dunEM56UpCOBk1IzoKHiwXe,showDialogs = PLaXN4KSfzcmyu3(Sfj9Kxdt05kwbso1GTcmQeORlhqJVi)
	if not vli6AtMjqfwmKnP0z1E:
		vli6AtMjqfwmKnP0z1E = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not vli6AtMjqfwmKnP0z1E: return
		vli6AtMjqfwmKnP0z1E = vli6AtMjqfwmKnP0z1E.lower()
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+'   Search For: [ '+vli6AtMjqfwmKnP0z1E+' ]')
	LBqdVs9ioWwpMbCm1A = vli6AtMjqfwmKnP0z1E+hg4F23dunEM56UpCOBk1IzoKHiwXe
	if 0: b6rFxAB1vcq78PXkE0GZMtoJgp,WXLft9mQVHqp = vli6AtMjqfwmKnP0z1E+' - ',wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: b6rFxAB1vcq78PXkE0GZMtoJgp,WXLft9mQVHqp = wUvcPrYDfISbZolAm83GKEqMyXkn5,' - '+vli6AtMjqfwmKnP0z1E
	mwOxEyYAg63B('link',JegF7SlMawI03+'مواقع سيرفرات خاصة - قليلة المشاكل'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,157)
	mwOxEyYAg63B('folder','_M3U_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث M3U'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,719,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_IPT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث IPTV'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,239,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_BKR_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع بكرا'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,379,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_ART_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع تونز عربية'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,739,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_KRB_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع قناة كربلاء'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,329,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FH2_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فاصل الثاني'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,599,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_KTV_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع كتكوت تيفي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,819,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_EB1_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع ايجي بيست 1'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,779,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_EB2_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع ايجي بيست 2'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,789,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_IFL_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'  بحث موقع قناة آي فيلم'+WXLft9mQVHqp+lB8tuyg6sxkDVYAaS95K3GI,wUvcPrYDfISbZolAm83GKEqMyXkn5,29,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_AKO_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع أكوام القديم'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,79,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_AKW_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع أكوام الجديد'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,249,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_MRF_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع قناة المعارف'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,49,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SHM_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شوف ماكس'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,59,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('link',JegF7SlMawI03+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,157)
	mwOxEyYAg63B('folder','_LRZ_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع لاروزا'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,709,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FJS_'+b6rFxAB1vcq78PXkE0GZMtoJgp+' بحث موقع فجر شو'+WXLft9mQVHqp+UKFZBQAVXHI5s17LyvuRpCY2,wUvcPrYDfISbZolAm83GKEqMyXkn5,399,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_TVF_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع تيفي فان'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,469,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_LDN_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع لودي نت'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,459,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CMN_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما ناو'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,309,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SHN_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شاهد نيوز'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,589,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A+'_NODIALOGS_')
	mwOxEyYAg63B('folder','_ARS_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع عرب سييد'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,259,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CCB_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما كلوب'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,829,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SH4_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شاهد فوريو'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,119,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A+'_NODIALOGS_')
	mwOxEyYAg63B('folder','_SHT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شوفها تيفي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,649,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_WC1_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع وي سيما 1'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,569,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_WC2_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع وي سيما 2'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,1009,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('link',JegF7SlMawI03+'مواقع سيرفرات عامة - كثيرة المشاكل'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,157)
	mwOxEyYAg63B('folder','_TKT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع تكات'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,949,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FST_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فوستا'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,609,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FBK_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فبركة'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,629,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_YQT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع ياقوت'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,669,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SHB_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شبكتي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,969,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_VRB_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فاربون'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,879,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_BRS_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع برستيج'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,659,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_KRM_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع كرمالك'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,929,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_ANZ_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع انمي زد'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,979,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FSK_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فارسكو'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,999,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_HLC_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع هلا سيما'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,89,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_MST_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع المصطبة'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,869,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SNT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع شوف نت'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,849,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_DR7_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع دراما صح'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,689,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CFR_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما فري'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,839,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CMF_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما فانز'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,99,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CML_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما لايت'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,479,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_C4H_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما 400'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,699,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_ABD_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما عبدو'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,559,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_AKT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع اكوام تيوب'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,859,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_DCF_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع دراما كافيه'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,939,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FTV_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فوشار تيفي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,919,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_CWB_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما وبس'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,989,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_AHK_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع أهواك تيفي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,619,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_SRT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيريس تايم'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,899,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_FVD_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع فوشار فيديو'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,909,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_C4P_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع سيما فور بي'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,889,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_EB4_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع ايجي بيست 4'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,809,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('link',JegF7SlMawI03+'مواقع سيرفرات خاصة - قليلة المشاكل'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,157)
	mwOxEyYAg63B('folder','_YUT_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع يوتيوب'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,149,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	mwOxEyYAg63B('folder','_DLM_'+b6rFxAB1vcq78PXkE0GZMtoJgp+'بحث موقع دايلي موشن'+WXLft9mQVHqp,wUvcPrYDfISbZolAm83GKEqMyXkn5,409,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LBqdVs9ioWwpMbCm1A)
	return