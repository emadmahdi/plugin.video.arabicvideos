# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'LIVETV'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS['PYTHON'][0]
def DDIqhZaAit8Ed9(mode,url):
	if   mode==100: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==101: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f('0',True)
	elif mode==102: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f('1',True)
	elif mode==103: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f('2',True)
	elif mode==104: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f('3',True)
	elif mode==105: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==106: RCmHBOKtejQ8lu4L = UUOhG6SD19FL2AztHln3uT4Xg5d8f('4',True)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder','_M3U_'+'قوائم فيديوهات M3U',wUvcPrYDfISbZolAm83GKEqMyXkn5,762)
	mwOxEyYAg63B('folder','_IPT_'+'قوائم فيديوهات IPTV',wUvcPrYDfISbZolAm83GKEqMyXkn5,761)
	mwOxEyYAg63B('folder','_TV0_'+'قنوات من مواقعها الأصلية',wUvcPrYDfISbZolAm83GKEqMyXkn5,101)
	mwOxEyYAg63B('folder','_TV4_'+'قنوات مختارة من يوتيوب',wUvcPrYDfISbZolAm83GKEqMyXkn5,106)
	mwOxEyYAg63B('folder','_YUT_'+'قنوات عربية من يوتيوب',wUvcPrYDfISbZolAm83GKEqMyXkn5,147)
	mwOxEyYAg63B('folder','_YUT_'+'قنوات أجنبية من يوتيوب',wUvcPrYDfISbZolAm83GKEqMyXkn5,148)
	mwOxEyYAg63B('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',wUvcPrYDfISbZolAm83GKEqMyXkn5,28)
	mwOxEyYAg63B('live','_MRF_'+'قناة المعارف من موقعهم',wUvcPrYDfISbZolAm83GKEqMyXkn5,41)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder','_TV1_'+'قنوات تلفزيونية عامة',wUvcPrYDfISbZolAm83GKEqMyXkn5,102)
	mwOxEyYAg63B('folder','_TV2_'+'قنوات تلفزيونية خاصة',wUvcPrYDfISbZolAm83GKEqMyXkn5,103)
	mwOxEyYAg63B('folder','_TV3_'+'قنوات تلفزيونية للفحص',wUvcPrYDfISbZolAm83GKEqMyXkn5,104)
	return
def UUOhG6SD19FL2AztHln3uT4Xg5d8f(U6OhDV7N1y9c3r4woKE2dW,showDialogs=True):
	UT69hgqoKsWNIwM5zkAYb = '_TV'+U6OhDV7N1y9c3r4woKE2dW+'_'
	COW137cpIhBMYTSiAR9s2Dlzw = {'id':wUvcPrYDfISbZolAm83GKEqMyXkn5,'user':TTuO14NzmB.AV_CLIENT_IDS,'function':'list','menu':U6OhDV7N1y9c3r4woKE2dW}
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',hhD7r1VvaPt3TC06SJjqKRfEid,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-ITEMS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(items)):
			name = items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3] = items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][0],items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][1],items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][2],name,items[kkLhJCU4MQSx7s6gyeOHrRYKtnP3][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for xVwDZbA6EOjpgX0,xG6n4Wq2Ib7YgpiarHUNLQJM0,LTt0Peg4HUB8wSxEn9pZiMWmDc753G,name,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
			if '#' in xVwDZbA6EOjpgX0: continue
			if xVwDZbA6EOjpgX0!='URL': name = name+JegF7SlMawI03+DQCpAXVq6LHJ0aEFR+xVwDZbA6EOjpgX0+AAByQSLgaZwCsKnvc5eWNmY
			url = xVwDZbA6EOjpgX0+';;'+xG6n4Wq2Ib7YgpiarHUNLQJM0+';;'+LTt0Peg4HUB8wSxEn9pZiMWmDc753G+';;'+U6OhDV7N1y9c3r4woKE2dW
			mwOxEyYAg63B('live',UT69hgqoKsWNIwM5zkAYb+wUvcPrYDfISbZolAm83GKEqMyXkn5+name,url,105,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		if showDialogs: mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+'هذه الخدمة مخصصة للمبرمج فقط',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(id):
	xVwDZbA6EOjpgX0,xG6n4Wq2Ib7YgpiarHUNLQJM0,LTt0Peg4HUB8wSxEn9pZiMWmDc753G,U6OhDV7N1y9c3r4woKE2dW = id.split(';;')
	url = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if xVwDZbA6EOjpgX0=='URL': url = LTt0Peg4HUB8wSxEn9pZiMWmDc753G
	elif xVwDZbA6EOjpgX0=='YOUTUBE':
		url = TTuO14NzmB.SITESURLS['YOUTUBE'][0]+'/watch?v='+LTt0Peg4HUB8wSxEn9pZiMWmDc753G
		import oo6FYcUjud
		oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy([url],UdbRGoKhcDeI4lVfns5,'live',url)
		return
	elif xVwDZbA6EOjpgX0=='GA':
		COW137cpIhBMYTSiAR9s2Dlzw = { 'id' : wUvcPrYDfISbZolAm83GKEqMyXkn5, 'user' : TTuO14NzmB.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,COW137cpIhBMYTSiAR9s2Dlzw,wUvcPrYDfISbZolAm83GKEqMyXkn5,False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-1st')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		cookies = QM9sJ7tk0oplqEwHU3DjL64d.cookies
		O3FDpqbfMGoKR4xiA9WBhLv1c = cookies['ASP.NET_SessionId']
		url = QM9sJ7tk0oplqEwHU3DjL64d.headers['Location']
		COW137cpIhBMYTSiAR9s2Dlzw = { 'id' : LTt0Peg4HUB8wSxEn9pZiMWmDc753G , 'user' : TTuO14NzmB.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+O3FDpqbfMGoKR4xiA9WBhLv1c }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,COW137cpIhBMYTSiAR9s2Dlzw,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-2nd')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		url = jj0dZrgiKb.findall('resp":"(http.*?m3u8)(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		hhEH1rcSP0z6Bkqy8OD = url[0][0]
		cKWuEGxtTfrBDj7I5 = url[0][1]
		KbB71MEusc5VAIfY = 'http://38.'+xG6n4Wq2Ib7YgpiarHUNLQJM0+'777/'+LTt0Peg4HUB8wSxEn9pZiMWmDc753G+'_HD.m3u8'+cKWuEGxtTfrBDj7I5
		wlVyjzseu3GAkIaYR4Etg5OJ = KbB71MEusc5VAIfY.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		idWe6NvaXh7C = KbB71MEusc5VAIfY.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		Eu8LWnSt3fyJzIC = ['HD','SD1','SD2']
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [KbB71MEusc5VAIfY,wlVyjzseu3GAkIaYR4Etg5OJ,idWe6NvaXh7C]
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 0
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1: return
		else: url = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	elif xVwDZbA6EOjpgX0=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		COW137cpIhBMYTSiAR9s2Dlzw = { 'id' : LTt0Peg4HUB8wSxEn9pZiMWmDc753G , 'user' : TTuO14NzmB.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : U6OhDV7N1y9c3r4woKE2dW }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST', hhD7r1VvaPt3TC06SJjqKRfEid, COW137cpIhBMYTSiAR9s2Dlzw, headers, False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-3rd')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		url = QM9sJ7tk0oplqEwHU3DjL64d.headers['Location']
		url = url.replace('%20',UKFZBQAVXHI5s17LyvuRpCY2)
		url = url.replace('%3D','=')
		if 'Learn' in LTt0Peg4HUB8wSxEn9pZiMWmDc753G:
			url = url.replace('NTNNile',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			url = url.replace('learning1','Learning')
	elif xVwDZbA6EOjpgX0=='PL':
		COW137cpIhBMYTSiAR9s2Dlzw = { 'id' : LTt0Peg4HUB8wSxEn9pZiMWmDc753G , 'user' : TTuO14NzmB.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : U6OhDV7N1y9c3r4woKE2dW }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST', hhD7r1VvaPt3TC06SJjqKRfEid, COW137cpIhBMYTSiAR9s2Dlzw, wUvcPrYDfISbZolAm83GKEqMyXkn5,False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-4th')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		url = QM9sJ7tk0oplqEwHU3DjL64d.headers['Location']
		headers = {'Referer':QM9sJ7tk0oplqEwHU3DjL64d.headers['Referer']}
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'POST',url, wUvcPrYDfISbZolAm83GKEqMyXkn5,headers , wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-5th')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		items = jj0dZrgiKb.findall('source src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		url = items[0]
	elif xVwDZbA6EOjpgX0 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if xVwDZbA6EOjpgX0=='TA': LTt0Peg4HUB8wSxEn9pZiMWmDc753G = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		COW137cpIhBMYTSiAR9s2Dlzw = { 'id' : LTt0Peg4HUB8wSxEn9pZiMWmDc753G , 'user' : TTuO14NzmB.AV_CLIENT_IDS , 'function' : 'play'+xVwDZbA6EOjpgX0 , 'menu' : U6OhDV7N1y9c3r4woKE2dW }
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'POST',hhD7r1VvaPt3TC06SJjqKRfEid,COW137cpIhBMYTSiAR9s2Dlzw,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-6th')
		if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
		url = QM9sJ7tk0oplqEwHU3DjL64d.headers['Location']
		if xVwDZbA6EOjpgX0=='FM':
			QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'GET', url, wUvcPrYDfISbZolAm83GKEqMyXkn5, wUvcPrYDfISbZolAm83GKEqMyXkn5, False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVETV-PLAY-7th')
			url = QM9sJ7tk0oplqEwHU3DjL64d.headers['Location']
			url = url.replace('https','http')
	yyYuosJmc3QDUGSA(url,UdbRGoKhcDeI4lVfns5,'live')
	return