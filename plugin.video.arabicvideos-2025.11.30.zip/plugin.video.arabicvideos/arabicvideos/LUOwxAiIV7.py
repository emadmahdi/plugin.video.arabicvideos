# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'CIMALIGHT'
UT69hgqoKsWNIwM5zkAYb = '_CML_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['قنوات فضائية']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==470: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==471: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==472: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==473: RCmHBOKtejQ8lu4L = pXt5zYr9H0C(url,text)
	elif mode==474: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==479: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,479,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"content"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?</i>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = title.replace(lB8tuyg6sxkDVYAaS95K3GI,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('cat=online-movies1','cat=online-movies')
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,474)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('/category.php">(.*?)"navslide-divider"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall("'dropdown-menu'(.*?)</ul>",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if title in i6TIRax9v0EDFJs2gVtfzp: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,474)
	return
def FFJX0sguE92DxYGmoQAeV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if 'topvideos.php' in url: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"caret"(.*?)id="pm-grid"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"caret"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if 'topvideos.php' in hhEH1rcSP0z6Bkqy8OD:
				if 'topvideos.php?c=english-movies' in hhEH1rcSP0z6Bkqy8OD: continue
				if 'topvideos.php?c=online-movies1' in hhEH1rcSP0z6Bkqy8OD: continue
				if 'topvideos.php?c=misc' in hhEH1rcSP0z6Bkqy8OD: continue
				if 'topvideos.php?c=tv-channel' in hhEH1rcSP0z6Bkqy8OD: continue
				if 'منذ البداية' in title and 'do=rating' not in hhEH1rcSP0z6Bkqy8OD: continue
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,471)
	else: HPdaS7kenW0m(url)
	return
def HPdaS7kenW0m(url,ySY5NxERP6jeVG=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = []
	if ySY5NxERP6jeVG=='featured_movies':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"container-fluid"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		ppAJI9kDbz5MXa76UEF,kDp3Tb6EBW,zUBdcKFf907yb8axClwNuD5skR = zip(*items)
		items = zip(zUBdcKFf907yb8axClwNuD5skR,ppAJI9kDbz5MXa76UEF,kDp3Tb6EBW)
	elif ySY5NxERP6jeVG=='featured_series':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('المسلسلات المميزة(.*?)<style>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		ppAJI9kDbz5MXa76UEF,kDp3Tb6EBW,zUBdcKFf907yb8axClwNuD5skR = zip(*items)
		items = zip(zUBdcKFf907yb8axClwNuD5skR,ppAJI9kDbz5MXa76UEF,kDp3Tb6EBW)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(data-echo=".*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"BlocksList"(.*?)"titleSectionCon"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="pm-grid"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="pm-related"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('pm-ul-browse-videos(.*?)clearfix',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if not pLHIPUY3TWAeE70: return
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if not items: items = jj0dZrgiKb.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items: items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD).strip('/')
		title = title.replace('ماي سيما',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('مشاهدة',wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
		if 'http' not in cPzpeLXs3jMCltW4ZN9BaYdfQvwS: cPzpeLXs3jMCltW4ZN9BaYdfQvwS = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS.strip('/')
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|حلقة) \d+',title,jj0dZrgiKb.DOTALL)
		if any(value in title for value in SSthyczaHP7fAIoi5):
			title = '_MOD_'+title
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,472,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and 'حلقة' in title:
			title = '_MOD_'+xNVKL75nEZstg4wfXBkySQ[0][0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,473,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/movseries/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,471,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,473,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if ySY5NxERP6jeVG not in ['featured_movies','featured_series']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				if hhEH1rcSP0z6Bkqy8OD=='#': continue
				hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,471)
		EEqHD98QhfezKTg = jj0dZrgiKb.findall('showmore" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if EEqHD98QhfezKTg:
			hhEH1rcSP0z6Bkqy8OD = EEqHD98QhfezKTg[0]
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مشاهدة المزيد',hhEH1rcSP0z6Bkqy8OD,471)
	return
def pXt5zYr9H0C(url,ajCL4NVXu0K5):
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-EPISODES-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	i7swfV8rtlpOd3K6SUDk9yn0P = jj0dZrgiKb.findall('"SeasonsBox"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	items = []
	if i7swfV8rtlpOd3K6SUDk9yn0P and not ajCL4NVXu0K5:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('"series-header".*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0] if cPzpeLXs3jMCltW4ZN9BaYdfQvwS else wUvcPrYDfISbZolAm83GKEqMyXkn5
		IJE2xcV7OWauUKhfik56gXBwltCb = i7swfV8rtlpOd3K6SUDk9yn0P[0]
		items = jj0dZrgiKb.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if len(items)==1: ajCL4NVXu0K5 = items[0][0]
		elif len(items)>1:
			for ajCL4NVXu0K5,title in items: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,473,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,ajCL4NVXu0K5)
	m4z08qk6gJ5lK = jj0dZrgiKb.findall('id="'+ajCL4NVXu0K5+'"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if m4z08qk6gJ5lK and len(items)<2:
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = jj0dZrgiKb.findall('"series-header".*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		cPzpeLXs3jMCltW4ZN9BaYdfQvwS = cPzpeLXs3jMCltW4ZN9BaYdfQvwS[0] if cPzpeLXs3jMCltW4ZN9BaYdfQvwS else wUvcPrYDfISbZolAm83GKEqMyXkn5
		IJE2xcV7OWauUKhfik56gXBwltCb = m4z08qk6gJ5lK[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for hhEH1rcSP0z6Bkqy8OD,title in items:
				title = title.replace('ماي سيما',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('مسلسل',wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,472,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else:
			items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title,cPzpeLXs3jMCltW4ZN9BaYdfQvwS in items:
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+'/'+hhEH1rcSP0z6Bkqy8OD.strip('/')
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,472,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if 'id="pm-related"' in II64TLxj3mbqEyh9pHQ8oAv:
		if items: mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مواضيع ذات صلة',url,471)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<div itemprop="description">(.*?)href=',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		bxiMUQmPRvu = jj0dZrgiKb.findall('<p>(.*?)</p>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu,True): return
	ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('/watch.php','/play.php')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-PLAY-2nd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	DGb6h5Rt7y9p8cPj = []
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('"embedURL" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if hhEH1rcSP0z6Bkqy8OD:
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD[0]
		if hhEH1rcSP0z6Bkqy8OD and hhEH1rcSP0z6Bkqy8OD not in DGb6h5Rt7y9p8cPj:
			DGb6h5Rt7y9p8cPj.append(hhEH1rcSP0z6Bkqy8OD)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named=__embed'
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	items = jj0dZrgiKb.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		if hhEH1rcSP0z6Bkqy8OD not in DGb6h5Rt7y9p8cPj:
			DGb6h5Rt7y9p8cPj.append(hhEH1rcSP0z6Bkqy8OD)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	ZD5n0eJivzWOMxY98dgrumkwRG = url.replace('/watch.php','/downloads.php')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'CIMALIGHT-PLAY-3rd')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"downloadlist"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?<strong>(.*?)</strong>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if hhEH1rcSP0z6Bkqy8OD not in DGb6h5Rt7y9p8cPj:
				DGb6h5Rt7y9p8cPj.append(hhEH1rcSP0z6Bkqy8OD)
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'
				if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = 'http:'+hhEH1rcSP0z6Bkqy8OD
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	xG6n4Wq2Ib7YgpiarHUNLQJM0 = TO3vi2rSZ0LRhKlwgG4qkYFIC(hhD7r1VvaPt3TC06SJjqKRfEid,'url')
	url = xG6n4Wq2Ib7YgpiarHUNLQJM0+'/search.php?keywords='+search
	HPdaS7kenW0m(url,'search')
	return