# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SHAHID4U'
UT69hgqoKsWNIwM5zkAYb = '_SH4_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
headers = {'User-Agent':ZZIDf1A9vE0g86RMq7tpKUrzaij(True)}
i6TIRax9v0EDFJs2gVtfzp = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==110: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==111: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==112: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==113: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url,True)
	elif mode==114: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'FULL_FILTER___'+text)
	elif mode==115: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url,'DEFINED_FILTER___'+text)
	elif mode==116: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url,False)
	elif mode==119: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	FFwVakdM8NvjeJRK3oyQI9ti24 = TO3vi2rSZ0LRhKlwgG4qkYFIC(QM9sJ7tk0oplqEwHU3DjL64d.url,'url')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,119,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر محدد',FFwVakdM8NvjeJRK3oyQI9ti24,115)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فلتر كامل',FFwVakdM8NvjeJRK3oyQI9ti24,114)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'المميزة',FFwVakdM8NvjeJRK3oyQI9ti24,111,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('simple-filter(.*?)adv-filter',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for filter,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
			url = FFwVakdM8NvjeJRK3oyQI9ti24+filter
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,url,111,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,wUvcPrYDfISbZolAm83GKEqMyXkn5,filter)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="dropdown"(.*?)<script>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if title in i6TIRax9v0EDFJs2gVtfzp: continue
			if 'http' not in hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = FFwVakdM8NvjeJRK3oyQI9ti24+hhEH1rcSP0z6Bkqy8OD
			if 'netflix' in hhEH1rcSP0z6Bkqy8OD: title = 'نيتفلكس'
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,111)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,DT402mRilruat3EeIoM6=wUvcPrYDfISbZolAm83GKEqMyXkn5,QM9sJ7tk0oplqEwHU3DjL64d=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not QM9sJ7tk0oplqEwHU3DjL64d: QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70,items,v2v3ase4WBgVjbOnu96PCzlDKi = [],[],[]
	if DT402mRilruat3EeIoM6=='featured': pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('glide__slides(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	else: pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('shows-container(.*?)pagination',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if not items: items = jj0dZrgiKb.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	SSthyczaHP7fAIoi5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		if 'WWE' in title: continue
		if 'javascript' in hhEH1rcSP0z6Bkqy8OD: continue
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD).strip('/')
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) الحلقة \d+',title,jj0dZrgiKb.DOTALL)
		if '/film/' in hhEH1rcSP0z6Bkqy8OD or 'فيلم' in hhEH1rcSP0z6Bkqy8OD or any(value in title for value in SSthyczaHP7fAIoi5):
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,112,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif xNVKL75nEZstg4wfXBkySQ and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0]
			if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,113,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
				v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif '/actor/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,111,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/series/' in hhEH1rcSP0z6Bkqy8OD and '/list' not in url:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'/list'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,111,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/list' in url and 'حلقة' in title:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,112,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,113,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('"pagination"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70 and DT402mRilruat3EeIoM6!='featured':
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		if DT402mRilruat3EeIoM6!='search': items = jj0dZrgiKb.findall('(updateQuery).*?>(.+?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		else: items = jj0dZrgiKb.findall('<li>.*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = title.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(o46hdHaXLqyFwzD,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if DT402mRilruat3EeIoM6!='search':
				hhEH1rcSP0z6Bkqy8OD = url+'&page='+title if '?' in url else url+'?page='+title
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			if title: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,111,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DT402mRilruat3EeIoM6)
	return
def mCwqRg7HpivAQ6S(url,p9GdyhN3BV):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('items d-flex(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if len(pLHIPUY3TWAeE70)>1:
		if '/season/' in pLHIPUY3TWAeE70[0]: xhzIjcYasLwUiFQOrVB3ldvqpng,rNmzwKLcvbTquoFB6 = pLHIPUY3TWAeE70[0],pLHIPUY3TWAeE70[1]
		else: xhzIjcYasLwUiFQOrVB3ldvqpng,rNmzwKLcvbTquoFB6 = pLHIPUY3TWAeE70[1],pLHIPUY3TWAeE70[0]
	else: xhzIjcYasLwUiFQOrVB3ldvqpng,rNmzwKLcvbTquoFB6 = pLHIPUY3TWAeE70[0],pLHIPUY3TWAeE70[0]
	for qbRmVByrJv18 in range(2):
		if p9GdyhN3BV: mode,type,IJE2xcV7OWauUKhfik56gXBwltCb = 116,'folder',xhzIjcYasLwUiFQOrVB3ldvqpng
		else: mode,type,IJE2xcV7OWauUKhfik56gXBwltCb = 112,'video',rNmzwKLcvbTquoFB6
		items = jj0dZrgiKb.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if p9GdyhN3BV and len(items)<2:
			p9GdyhN3BV = False
			continue
		for hhEH1rcSP0z6Bkqy8OD,aBd52O7QsZGbvhngJ1TcI,HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ in items:
			title = aBd52O7QsZGbvhngJ1TcI+UKFZBQAVXHI5s17LyvuRpCY2+HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ
			mwOxEyYAg63B(type,UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,mode)
		break
	if not items and '/episodes' in II64TLxj3mbqEyh9pHQ8oAv:
		wC6fc8LIxARe9yTuYptDqkrQW = jj0dZrgiKb.findall('class="breadcrumb"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if wC6fc8LIxARe9yTuYptDqkrQW:
			IJE2xcV7OWauUKhfik56gXBwltCb = wC6fc8LIxARe9yTuYptDqkrQW[0]
			ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			if len(ppAJI9kDbz5MXa76UEF)>2:
				hhEH1rcSP0z6Bkqy8OD = ppAJI9kDbz5MXa76UEF[2]+'list'
				HPdaS7kenW0m(hhEH1rcSP0z6Bkqy8OD)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="actions(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70: return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	ppAJI9kDbz5MXa76UEF = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	oq92O4kfZxUzwLYJ = '/watch/' in IJE2xcV7OWauUKhfik56gXBwltCb
	download = '/download/' in IJE2xcV7OWauUKhfik56gXBwltCb
	if   oq92O4kfZxUzwLYJ and not download: ZJCy8d5TGvi31Kh2o0lXV,JOYWT2S6DMzwU5ej4R = ppAJI9kDbz5MXa76UEF[0],wUvcPrYDfISbZolAm83GKEqMyXkn5
	elif not oq92O4kfZxUzwLYJ and download: ZJCy8d5TGvi31Kh2o0lXV,JOYWT2S6DMzwU5ej4R = wUvcPrYDfISbZolAm83GKEqMyXkn5,ppAJI9kDbz5MXa76UEF[0]
	elif oq92O4kfZxUzwLYJ and download: ZJCy8d5TGvi31Kh2o0lXV,JOYWT2S6DMzwU5ej4R = ppAJI9kDbz5MXa76UEF[0],ppAJI9kDbz5MXa76UEF[1]
	else: ZJCy8d5TGvi31Kh2o0lXV,JOYWT2S6DMzwU5ej4R = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	if oq92O4kfZxUzwLYJ:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',ZJCy8d5TGvi31Kh2o0lXV,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-PLAY-2nd')
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		m4z08qk6gJ5lK = jj0dZrgiKb.findall('let servers(.*?)player',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
		if m4z08qk6gJ5lK:
			i9eu0gvptXjKMAczZyE = m4z08qk6gJ5lK[0]
			VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('"name":"(.*?)".*?"url":"(.*?)"',i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
			for title,hhEH1rcSP0z6Bkqy8OD in VV7eQk5mj1dBNiHtrcP:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('\\/','/')
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	if download:
		QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',JOYWT2S6DMzwU5ej4R,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-PLAY-3rd')
		xnGN2vER8iQqJkcFt4KWup = QM9sJ7tk0oplqEwHU3DjL64d.content
		m4z08qk6gJ5lK = jj0dZrgiKb.findall('"servers"(.*?)info-container',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
		if m4z08qk6gJ5lK:
			i9eu0gvptXjKMAczZyE = m4z08qk6gJ5lK[0]
			VV7eQk5mj1dBNiHtrcP = jj0dZrgiKb.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',i9eu0gvptXjKMAczZyE,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title,KwSdzRXT0M3VW in VV7eQk5mj1dBNiHtrcP:
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'+'____'+KwSdzRXT0M3VW
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if not search:
		search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not search: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search?s='+search
	HPdaS7kenW0m(url,'search')
	return
def fFLoASm2V96qUBCEHzGJjyc(url):
	url = url.split('/smartemadfilter?')[0]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('adv-filter(.*?)shows-container',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		Q9cBo8ysZbM3L4Ttvd7nF6Nk = jj0dZrgiKb.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		a2acYLTQVdt,wqHOWj2Y6mFI,qqtR56dgVLh3Tr2 = zip(*Q9cBo8ysZbM3L4Ttvd7nF6Nk)
		Q9cBo8ysZbM3L4Ttvd7nF6Nk = zip(wqHOWj2Y6mFI,a2acYLTQVdt,qqtR56dgVLh3Tr2)
	return Q9cBo8ysZbM3L4Ttvd7nF6Nk
def e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb):
	items = jj0dZrgiKb.findall('value="(.*?)".*?>\s*(.*?)\s*<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return items
def HiX3TcPpe8(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	lnpS3fLJa4GiNoctb = url.split('/smartemadfilter?')[0]
	U62oVRpWuriEJAwedHOxStI9m8bCQ = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	url = url.replace(lnpS3fLJa4GiNoctb,U62oVRpWuriEJAwedHOxStI9m8bCQ)
	url = url.replace('/smartemadfilter?','/?')
	return url
rBSDKlQitXZd59qgyJLC = ['quality','year','genre','category']
wqWcXlQsxgJNYpE5T3SRdhm8M = ['category','genre','year']
def mmUxVlf7ZQMjeDE(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='DEFINED_FILTER':
		if wqWcXlQsxgJNYpE5T3SRdhm8M[0]+'=' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = wqWcXlQsxgJNYpE5T3SRdhm8M[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(wqWcXlQsxgJNYpE5T3SRdhm8M[0:-1])):
			if wqWcXlQsxgJNYpE5T3SRdhm8M[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'=' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = wqWcXlQsxgJNYpE5T3SRdhm8M[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+d5TLHSj39awfvFp+'=0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+d5TLHSj39awfvFp+'=0'
		qclt2BMvQu = M2MhYTzotC0.strip('&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
	elif type=='FULL_FILTER':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		if mVhHg8LIlYR5cM9d7PfB==wUvcPrYDfISbZolAm83GKEqMyXkn5: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+mVhHg8LIlYR5cM9d7PfB
		qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها ',qaLFXuDExl8w,111)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',qaLFXuDExl8w,111)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = fFLoASm2V96qUBCEHzGJjyc(url)
	dict = {}
	for name,VaqykB2YmTbCtUDl,IJE2xcV7OWauUKhfik56gXBwltCb in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		name = name.replace('كل ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		items = e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb)
		if '=' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='DEFINED_FILTER':
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<2:
				if VaqykB2YmTbCtUDl==wqWcXlQsxgJNYpE5T3SRdhm8M[-1]:
					qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
					HPdaS7kenW0m(qaLFXuDExl8w)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'DEFINED_FILTER___'+qclt2BMvQu)
				return
			else:
				if VaqykB2YmTbCtUDl==wqWcXlQsxgJNYpE5T3SRdhm8M[-1]:
					qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',qaLFXuDExl8w,111)
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,115,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='FULL_FILTER':
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'=0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'=0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع :'+name,ZD5n0eJivzWOMxY98dgrumkwRG,114,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for value,sslNS0zetni1HDbZRQOCMxJ4AfhaP in items:
			if value=='196533': sslNS0zetni1HDbZRQOCMxJ4AfhaP = 'أفلام نيتفلكس'
			elif value=='196531': sslNS0zetni1HDbZRQOCMxJ4AfhaP = 'مسلسلات نيتفلكس'
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			dict[VaqykB2YmTbCtUDl][value] = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'='+sslNS0zetni1HDbZRQOCMxJ4AfhaP
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'#+dict[VaqykB2YmTbCtUDl]['0']
			title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'+name
			if type=='FULL_FILTER': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,114,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='DEFINED_FILTER' and wqWcXlQsxgJNYpE5T3SRdhm8M[-2]+'=' in yzamv2DUurjwolVq:
				NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'modified_filters')
				ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
				qaLFXuDExl8w = HiX3TcPpe8(ZD5n0eJivzWOMxY98dgrumkwRG)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,qaLFXuDExl8w,111)
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,115,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.replace('=&','=0&')
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&')
	wHOxpbdkJBM0ZC7 = {}
	if '=' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('=')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for key in rBSDKlQitXZd59qgyJLC:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if '%' not in value: value = vvLTYxVfrbDza(value)
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
		elif mode=='all': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.replace('=0','=')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm