# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭Ჭ")
UT69hgqoKsWNIwM5zkAYb = Gj3rMP1Cb8wHdp49la0(u"࠭࡟ࡍࡕࡗࡣࠬᲮ")
aaY7B0Pbr1y9JUQ3InkEpSMflHFWe = R9RNUT6WAPEYjHqtIokxuXs
ssPqWhCJOgGHwTdS = TNw1pBHb8CtSZe0EFxuJqI(u"࠳࠳Ἑ")
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,url,eIRJAgj25bzvNik48puZl3OPUq,sbNukjOf4chz,V9NmnGv2o0ZU5P8F4iqgX7CQJ):
	try: Be4AsSL71xyhHNQYV2wdvJ = str(V9NmnGv2o0ZU5P8F4iqgX7CQJ[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲯ")])
	except: Be4AsSL71xyhHNQYV2wdvJ = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==w8JC1y7Lp3(u"࠴࠺࠵Ἒ"): RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==w8JC1y7Lp3(u"࠵࠻࠷Ἓ"): RCmHBOKtejQ8lu4L = DAJC0Yulx4btHe7Vw9XqRNK(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==w8JC1y7Lp3(u"࠶࠼࠲Ἔ"): RCmHBOKtejQ8lu4L = gpmiW3zk1x4AdnY(eIRJAgj25bzvNik48puZl3OPUq,w8JC1y7Lp3(u"࠶࠼࠲Ἔ"))
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠷࠶࠴Ἕ"): RCmHBOKtejQ8lu4L = gpmiW3zk1x4AdnY(eIRJAgj25bzvNik48puZl3OPUq,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠷࠶࠴Ἕ"))
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==fmkZtbRj3ux(u"࠱࠷࠶἞"): RCmHBOKtejQ8lu4L = NymeARuXJTgQnj9WiO(eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==TNw1pBHb8CtSZe0EFxuJqI(u"࠲࠸࠸἟"): RCmHBOKtejQ8lu4L = pOgCf36uvw9sjmI(url,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠳࠹࠺ἠ"): RCmHBOKtejQ8lu4L = Bb5kGgCXaijtdZvF8prNLsD2Sq(url,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==D2PpKMeZFWrmfxTSs4L1tz(u"࠴࠺࠼ἡ"): RCmHBOKtejQ8lu4L = Z4uXjYL6Bh(url,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==JHMxIE4fs1mvQtKW7R(u"࠵࠻࠾ἢ"): RCmHBOKtejQ8lu4L = D42seT8uXwtpJ15McHE(url,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==xdSThjYnuHXAU6M(u"࠼࠼࠱ἣ"): RCmHBOKtejQ8lu4L = XXE7onrQUM()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠽࠶࠳ἤ"): RCmHBOKtejQ8lu4L = aaKJnmgLQ7qtNFUDI5jxbH()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==llkFwuCyhaP3sK76qO4T(u"࠷࠷࠵ἥ"): RCmHBOKtejQ8lu4L = ilwPmvIGqLfp4MSs(Be4AsSL71xyhHNQYV2wdvJ,eIRJAgj25bzvNik48puZl3OPUq,sbNukjOf4chz)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==jQv0du1iVxTgAXCM(u"࠸࠸࠷ἦ"): RCmHBOKtejQ8lu4L = M6jvoda1gIQuR2r5qH(Be4AsSL71xyhHNQYV2wdvJ,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==lCT8hfYUBX4OQMmL(u"࠹࠹࠹ἧ"): RCmHBOKtejQ8lu4L = j9j0TYJhn6FVCpvUstqbRwo17Q(Be4AsSL71xyhHNQYV2wdvJ,eIRJAgj25bzvNik48puZl3OPUq)
	else: RCmHBOKtejQ8lu4L = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲰ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪᲱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠴࠺࠶Ἠ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲲ"))
	mwOxEyYAg63B(llkFwuCyhaP3sK76qO4T(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲳ"),vvhR5ozeiJpANyl8fFO3GBw(u"่ࠬำๆࠢ฼ุํอฦ๋ࠩᲴ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠵࠻࠸Ἡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲵ"))
	mwOxEyYAg63B(JHMxIE4fs1mvQtKW7R(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲶ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫᲷ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"࠶࠼࠳Ἢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᲸ"))
	mwOxEyYAg63B(JHMxIE4fs1mvQtKW7R(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲹ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪᲺ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"࠷࠶࠵Ἣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᲻"))
	mwOxEyYAg63B(bQGafNLXyFgsZP6ut(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲼"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪᲽ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"࠷࠷࠵Ἤ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪᲾ"))
	mwOxEyYAg63B(lCT8hfYUBX4OQMmL(u"ࠩ࡯࡭ࡳࡱࠧᲿ"),JegF7SlMawI03+xm6jK1ZMuWq5(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᳀")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠺࠻࠼࠽Ἥ"))
	mwOxEyYAg63B(MFhbWia58mP3su0fk2d(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳁"),it4DKnryZlx(u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ᳂"),wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"࠳࠹࠷Ἦ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳃"))
	mwOxEyYAg63B(erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳄"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ᳅"),wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"࠴࠺࠸Ἧ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳆"))
	mwOxEyYAg63B(xdSThjYnuHXAU6M(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳇"),kPCxIUZb1V(u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ᳈"),wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"࠵࠻࠸ἰ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳉"))
	mwOxEyYAg63B(Gj3rMP1Cb8wHdp49la0(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳊"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ᳋"),wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠶࠼࠲ἱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳌"))
	mwOxEyYAg63B(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳍"),w8JC1y7Lp3(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭᳎"),wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"࠷࠶࠵ἲ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳏"))
	mwOxEyYAg63B(vWNRusF46D7Mi8GpZ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᳐"),fmkZtbRj3ux(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᳑"),wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"࠷࠷࠷ἳ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳒"))
	mwOxEyYAg63B(weh7SGmuTgXOVRcMo1rlLq(u"ࠨ࡮࡬ࡲࡰ࠭᳓"),JegF7SlMawI03+kPCxIUZb1V(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᳔")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"࠺࠻࠼࠽ἴ"))
	mwOxEyYAg63B(bQGafNLXyFgsZP6ut(u"ࠪࡪࡴࡲࡤࡦࡴ᳕ࠪ"),xm6jK1ZMuWq5(u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส᳖ࠩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"࠳࠹࠷ἵ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳗"))
	mwOxEyYAg63B(Gj3rMP1Cb8wHdp49la0(u"࠭ࡦࡰ࡮ࡧࡩࡷ᳘࠭"),fmkZtbRj3ux(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ᳙"),wUvcPrYDfISbZolAm83GKEqMyXkn5,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠴࠺࠸ἶ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳚"))
	mwOxEyYAg63B(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳛"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํ᳜ࠫ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,MFhbWia58mP3su0fk2d(u"࠵࠻࠸ἷ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᳝࠭"))
	mwOxEyYAg63B(xdSThjYnuHXAU6M(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳞ࠬ"),xdSThjYnuHXAU6M(u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐᳟ࠧ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠶࠼࠲Ἰ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳠"))
	mwOxEyYAg63B(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳡"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏᳢࠭"),wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"࠷࠶࠵Ἱ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳣ࠧ"))
	mwOxEyYAg63B(MFhbWia58mP3su0fk2d(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳤ࠫ"),rDG9dZoXRhCJcieUSF0KB(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื᳥๊࠭"),wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"࠷࠷࠶Ἲ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳦ࠪ"))
	return
def XXE7onrQUM():
	mwOxEyYAg63B(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡧࡱ࡯ࡨࡪࡸ᳧ࠧ"),w8JC1y7Lp3(u"ࠨࡡࡌࡔ࡙ࡥ᳨ࠧ")+vvhR5ozeiJpANyl8fFO3GBw(u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧᳩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"࠸࠸࠷Ἳ"))
	mwOxEyYAg63B(yRWQMHxZEz0(u"ࠪࡰ࡮ࡴ࡫ࠨᳪ"),JegF7SlMawI03+Gj3rMP1Cb8wHdp49la0(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᳫ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠻࠼࠽࠾Ἴ"))
	for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
		UT69hgqoKsWNIwM5zkAYb = vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡥࡉࡑࠩᳬ")+str(Be4AsSL71xyhHNQYV2wdvJ)+DpRJnas65uVcO0S17dYG(u"࠭࡟ࠨ᳭")
		mwOxEyYAg63B(Gj3rMP1Cb8wHdp49la0(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),UT69hgqoKsWNIwM5zkAYb+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪᳯ")+HiqZ1R8GXDtUzSu[Be4AsSL71xyhHNQYV2wdvJ],wUvcPrYDfISbZolAm83GKEqMyXkn5,rDG9dZoXRhCJcieUSF0KB(u"࠺࠺࠹Ἵ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{xdSThjYnuHXAU6M(u"ࠩࡩࡳࡱࡪࡥࡳࠩᳰ"):Be4AsSL71xyhHNQYV2wdvJ})
	return
def aaKJnmgLQ7qtNFUDI5jxbH():
	mwOxEyYAg63B(weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),w8JC1y7Lp3(u"ࠫࡤࡓ࠳ࡖࡡࠪᳲ")+erqDsJmL3BQHuGtPkcf0X9(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩᳳ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"࠻࠻࠻Ἶ"))
	mwOxEyYAg63B(TNw1pBHb8CtSZe0EFxuJqI(u"࠭࡬ࡪࡰ࡮ࠫ᳴"),JegF7SlMawI03+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᳵ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"࠾࠿࠹࠺Ἷ"))
	for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
		UT69hgqoKsWNIwM5zkAYb = xm6jK1ZMuWq5(u"ࠨࡡࡐ࡙ࠬᳶ")+str(Be4AsSL71xyhHNQYV2wdvJ)+w8JC1y7Lp3(u"ࠩࡢࠫ᳷")
		mwOxEyYAg63B(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳸"),UT69hgqoKsWNIwM5zkAYb+weh7SGmuTgXOVRcMo1rlLq(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭᳹")+HiqZ1R8GXDtUzSu[Be4AsSL71xyhHNQYV2wdvJ],wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"࠽࠶࠶ὀ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{w8JC1y7Lp3(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳺ"):Be4AsSL71xyhHNQYV2wdvJ})
	return
def jWgDwaI7SFNseRcLP9(g40I3ZXaeJ8qVywt):
	global z7QK0CGSnqB3e,ppDPeoTun6xBEUasQi2L1
	iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
	try:
		if s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࡉࡇࡋࡏࡑࠬ᳻") in g40I3ZXaeJ8qVywt: iKL7Z0wdopbjRXM(g40I3ZXaeJ8qVywt)
		else: iKL7Z0wdopbjRXM()
		EUZ4ob3BTng = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	except:
		XWcklrdEuQozqtaK1()
		EUZ4ob3BTng = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	g40I3ZXaeJ8qVywt = c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt)
	if EUZ4ob3BTng:
		hg79cQmoVfMCukiU8ERpT6JqywSrN3(g40I3ZXaeJ8qVywt,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧโึ็ࠤ้๊ริใࠪ᳼"),L5jXH0fZ8TvsESR=DpRJnas65uVcO0S17dYG(u"࠲࠱࠲࠳ὁ"))
		z7QK0CGSnqB3e += UD4N8MjVTd
		ppDPeoTun6xBEUasQi2L1 += erqDsJmL3BQHuGtPkcf0X9(u"ࠨࠢ࠱ࠤࠬ᳽")+g40I3ZXaeJ8qVywt
	else: hg79cQmoVfMCukiU8ERpT6JqywSrN3(g40I3ZXaeJ8qVywt,wUvcPrYDfISbZolAm83GKEqMyXkn5,L5jXH0fZ8TvsESR=VhqD3zp7mUieI8sMQlETH(u"࠲࠲࠳࠴ὂ"))
	return
sxzI2flt78kGXZr = {}
def d8C14ZjXT2xRFbJpVOMkgvihaPys(b2WunxkHmaMhLEp6Dce=y0yvdNOZkiKEg5RLMhoDVQAB9F2):
	global z7QK0CGSnqB3e,ppDPeoTun6xBEUasQi2L1,sxzI2flt78kGXZr
	if not b2WunxkHmaMhLEp6Dce:
		sxzI2flt78kGXZr = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,DpRJnas65uVcO0S17dYG(u"ࠩࡧ࡭ࡨࡺࠧ᳾"),xdSThjYnuHXAU6M(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ᳿"),w8JC1y7Lp3(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩᴀ"))
		if sxzI2flt78kGXZr: return
	ug0EmiKYnRT1qeH9MFyr3pO = T4dIruOctCl2qwYNE0SDyU(s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᴁ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,fmkZtbRj3ux(u"࠭อห๋ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮࠯ࠢึ๎ๆำีࠡษ็ฬึ์วๆฮࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤาะ้ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴࠮้ࠡำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤࡡࡴ࡜࡯ࠩᴂ")+JegF7SlMawI03+bQGafNLXyFgsZP6ut(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯาๅฺࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩᴃ")+AAByQSLgaZwCsKnvc5eWNmY)
	if ug0EmiKYnRT1qeH9MFyr3pO!=UD4N8MjVTd: return
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(uxig7mJanAYQ20,uxig7mJanAYQ20,uxig7mJanAYQ20)
	QwqaUkPGHxV3csEzO5yt = TTuO14NzmB.menuItemsLIST
	z7QK0CGSnqB3e,ppDPeoTun6xBEUasQi2L1,f2fSzUB4jwu9ayPoNZC63vHlnT07d = wTLFCOcM26fmYlW7U,wUvcPrYDfISbZolAm83GKEqMyXkn5,{}
	for g40I3ZXaeJ8qVywt in emNlqsvPnQAjwGHVyx2EXgaWMI7:
		L5jXH0fZ8TvsESR.sleep(UD4N8MjVTd)
		f2fSzUB4jwu9ayPoNZC63vHlnT07d[g40I3ZXaeJ8qVywt] = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=jWgDwaI7SFNseRcLP9,args=(g40I3ZXaeJ8qVywt,))
		f2fSzUB4jwu9ayPoNZC63vHlnT07d[g40I3ZXaeJ8qVywt].start()
	else:
		for g40I3ZXaeJ8qVywt in list(f2fSzUB4jwu9ayPoNZC63vHlnT07d.keys()): f2fSzUB4jwu9ayPoNZC63vHlnT07d[g40I3ZXaeJ8qVywt].join()
	TTuO14NzmB.menuItemsLIST[:] = QwqaUkPGHxV3csEzO5yt
	sxzI2flt78kGXZr = {}
	for g40I3ZXaeJ8qVywt in list(f2fSzUB4jwu9ayPoNZC63vHlnT07d.keys()):
		try: BcMQ2R4EeIXbasuzdODVt0 = TTuO14NzmB.menuItemsDICT[g40I3ZXaeJ8qVywt]
		except: continue
		g40I3ZXaeJ8qVywt = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡡࡏࡗ࡙ࡥࠧᴄ")+c3o9wjJyYsrzqx6kHVthmPOM4A8b(g40I3ZXaeJ8qVywt)
		for TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr in BcMQ2R4EeIXbasuzdODVt0:
			if not LcukPqj3x6f9WDZQh5YJzg: LcukPqj3x6f9WDZQh5YJzg = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩ࠱࠲࠳࠴ࠧᴅ")
			else:
				if LcukPqj3x6f9WDZQh5YJzg.count(vWNRusF46D7Mi8GpZ(u"ࠪࡣࠬᴆ"))>UD4N8MjVTd: LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.split(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡤ࠭ᴇ"),Tb7oymMnpflsSv3eu4Pz2)[Tb7oymMnpflsSv3eu4Pz2]
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࢦࠧᴈ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(s149dk8uh2p7oFzaLxZeI3Or(u"࠭ࠠࡉࡆࠪᴉ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(vWNRusF46D7Mi8GpZ(u"ࠧࡉࡆࠣࠫᴊ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠨโࠪᴋ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(jQv0du1iVxTgAXCM(u"ࠩฬࠫᴌ"),xm6jK1ZMuWq5(u"๋ࠪࠬᴍ")).replace(w8JC1y7Lp3(u"ࠫษ࠭ᴎ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠬ๎ࠧᴏ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(llkFwuCyhaP3sK76qO4T(u"࠭รࠨᴐ"),vWNRusF46D7Mi8GpZ(u"ࠧศࠩᴑ")).replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨวࠪᴒ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩสࠫᴓ")).replace(rDG9dZoXRhCJcieUSF0KB(u"ࠪฦࠬᴔ"),jQv0du1iVxTgAXCM(u"ࠫฬ࠭ᴕ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(fmkZtbRj3ux(u"๊ࠬรࠨᴖ"),rDG9dZoXRhCJcieUSF0KB(u"࠭ไศࠩᴗ")).replace(xdSThjYnuHXAU6M(u"ࠧๅวࠪᴘ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠨๆสࠫᴙ")).replace(w8JC1y7Lp3(u"ࠩ็ฦࠬᴚ"),A6Sg45ChDR3BJLYfFH(u"่ࠪฬ࠭ᴛ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(xm6jK1ZMuWq5(u"ࠫ๓࠭ᴜ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ๑ࠧᴝ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭๏ࠨᴞ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧํࠩᴟ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(llkFwuCyhaP3sK76qO4T(u"ࠨ๒ࠪᴠ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(JHMxIE4fs1mvQtKW7R(u"ࠩ๐ࠫᴡ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠪ๖ࠬᴢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(llkFwuCyhaP3sK76qO4T(u"ࠫ๖࠭ᴣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠬࢂࠧᴤ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(yRWQMHxZEz0(u"࠭ࡾࠨᴥ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(xm6jK1ZMuWq5(u"ࠧศ๊้ࠤ้อ๊็ࠩᴦ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(A6Sg45ChDR3BJLYfFH(u"ࠨีํ้ฬࠦไศ์อࠫᴧ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				aA02loue9XW = [gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩส่฾อศࠨᴨ"),A6Sg45ChDR3BJLYfFH(u"ࠪา๏อไࠨᴩ"),A6Sg45ChDR3BJLYfFH(u"ࠫฬ๊ศ้็ࠪᴪ"),it4DKnryZlx(u"ࠬอไศ่ࠪᴫ"),xdSThjYnuHXAU6M(u"࠭วุใส่ࠬᴬ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧฮษ็๎์࠭ᴭ"),bQGafNLXyFgsZP6ut(u"ࠨษ็฾ฬุࠧᴮ"),Gj3rMP1Cb8wHdp49la0(u"ุࠩห้ำࠧᴯ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪห้ี๊็ࠩᴰ"),yRWQMHxZEz0(u"๊ࠫ๎วๅ์าࠫᴱ"),w8JC1y7Lp3(u"ࠬอไฺษ็้ࠬᴲ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭วฺ็ส่ࠬᴳ")]
				if not any(QoeAC3n71cYrPf2gWlKxBtkb0 in LcukPqj3x6f9WDZQh5YJzg for QoeAC3n71cYrPf2gWlKxBtkb0 in aA02loue9XW): LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(Gj3rMP1Cb8wHdp49la0(u"ࠧศๆࠪᴴ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(JHMxIE4fs1mvQtKW7R(u"ࠨษัี๏࠭ᴵ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩสาึ๏ࠧᴶ")).replace(jQv0du1iVxTgAXCM(u"ࠪหั์ศ๊ࠩᴷ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫฬาๆษ์ࠪᴸ")).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ฿ววๆํ๋ࠬᴹ"),MFhbWia58mP3su0fk2d(u"ู࠭ศศ็๎ࠬᴺ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(bQGafNLXyFgsZP6ut(u"ࠧศฮ้ฬ๏ํࠧᴻ"),yRWQMHxZEz0(u"ࠨษฯ๊อ๐ࠧᴼ")).replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩ฼ีอ๐็ࠨᴽ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠪ฽ึฮ๊ࠨᴾ")).replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠫึ๎ๅศ่ึ๎์࠭ᴿ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠬื่ๆษ้ื๏࠭ᵀ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ฺ࠭าสํ๋ࠬᵁ"),yRWQMHxZEz0(u"ࠧ฻ำห๎ࠬᵂ")).replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨุ๊้๊ࠣำๅษอࠫᵃ"),w8JC1y7Lp3(u"่ࠩืู้ไศฬࠪᵄ")).replace(vWNRusF46D7Mi8GpZ(u"ࠪห฿อๆ๊ࠩᵅ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫฬเว็์ࠪᵆ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(kPCxIUZb1V(u"ࠬะวา์ั๎ࠬᵇ"),rDG9dZoXRhCJcieUSF0KB(u"࠭สศำําࠬᵈ")).replace(MFhbWia58mP3su0fk2d(u"ࠧฯ์ส่ࠥ฿ไๆ์ࠪᵉ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠨะํห้࠭ᵊ")).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"่ࠩ์ุ๐โ๋้ࠪᵋ"),A6Sg45ChDR3BJLYfFH(u"้ࠪํู๊ใ๋ࠪᵌ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(DpRJnas65uVcO0S17dYG(u"ࠫ์์ฯ๊ࠩᵍ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠬํๆะ์ࠪᵎ")).replace(w8JC1y7Lp3(u"࠭็็ัํ๋ࠬᵏ"),vvhR5ozeiJpANyl8fFO3GBw(u"่่ࠧา๎ࠬᵐ")).replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨ๊ฮหห่๊่ࠩᵑ"),A6Sg45ChDR3BJLYfFH(u"๋ࠩฯฬฬโ๋ࠩᵒ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(fmkZtbRj3ux(u"ࠪฮ้๐แำ์๋๊๏ํࠧᵓ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫฯ๊แำ์๋๊ࠬᵔ")).replace(w8JC1y7Lp3(u"ࠬะไโิํ์๋๐็ࠨᵕ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭สๅใี๎ํ์ࠧᵖ")).replace(MFhbWia58mP3su0fk2d(u"้ࠧࠢๆีฯ๎ๆࠨᵗ"),MFhbWia58mP3su0fk2d(u"ࠨ๊ๆีฯ๎ๆࠨᵘ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠩส่าอไ๋้ࠪᵙ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠪัฬ๊๊่ࠩᵚ")).replace(vWNRusF46D7Mi8GpZ(u"๊ࠫ๎ำໍไํࠫᵛ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"๋่ࠬิ์ๅํࠬᵜ")).replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭วๅษ้้๏࠭ᵝ"),xdSThjYnuHXAU6M(u"ࠧศ่่๎ࠬᵞ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(it4DKnryZlx(u"ࠨษ็ุ้๊ำๅษอࠫᵟ"),Gj3rMP1Cb8wHdp49la0(u"่ࠩืู้ไศฬࠪᵠ")).replace(MFhbWia58mP3su0fk2d(u"ࠪห้ฮัศ็ฯࠫᵡ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠫอืวๆฮࠪᵢ")).replace(D2PpKMeZFWrmfxTSs4L1tz(u"้ࠬวาฬ๋๊ࠬᵣ"),it4DKnryZlx(u"࠭ใาฬ๋๊ࠬᵤ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(xm6jK1ZMuWq5(u"ࠧฮำ๋ฬࠬᵥ"),fmkZtbRj3ux(u"ࠨฯิฬࠬᵦ")).replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩส่ฬ์วี์าࠫᵧ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠪห๋อิ๋ัࠪᵨ")).replace(A6Sg45ChDR3BJLYfFH(u"ࠫฬู๊้์๊ࠫᵩ"),llkFwuCyhaP3sK76qO4T(u"ࠬอำ๋๊ํࠫᵪ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(DpRJnas65uVcO0S17dYG(u"ู࠭าส์ࠫᵫ"),lCT8hfYUBX4OQMmL(u"ฺࠧำห๎ࠬᵬ")).replace(llkFwuCyhaP3sK76qO4T(u"ࠨฬิ็๎࠭ᵭ"),yRWQMHxZEz0(u"ࠩอี่๐ࠧᵮ")).replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪฮึ้๊่ࠩᵯ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫฯืใ๋ࠩᵰ")).replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬอไๆุสๅࠬᵱ"),kPCxIUZb1V(u"࠭ๅืษไࠫᵲ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(fmkZtbRj3ux(u"ࠧา์สฺ๏࠭ᵳ"),lCT8hfYUBX4OQMmL(u"ࠨำํห฻ฯࠧᵴ")).replace(VhqD3zp7mUieI8sMQlETH(u"ࠩิ๎ฬ฼็ࠨᵵ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠪี๏อึสࠩᵶ")).replace(xdSThjYnuHXAU6M(u"ࠫฬู๊้์๊ࠫᵷ"),xdSThjYnuHXAU6M(u"ࠬอำ๋๊ํࠫᵸ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ใ้็ํำ๎࠭ᵹ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧไ๊่๎ิ๐ࠧᵺ")).replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠨๅ๋้๏ี๊่ࠩᵻ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩๆ์๊๐ฯ๋ࠩᵼ")).replace(rDG9dZoXRhCJcieUSF0KB(u"ࠪห๋๐ๅ๋ࠩᵽ"),llkFwuCyhaP3sK76qO4T(u"ࠫฬ์ๅ๋ࠩᵾ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠬอๆ๋็ํุ๋࠭ᵿ"),vWNRusF46D7Mi8GpZ(u"࠭ว็็ํุ๋࠭ᶀ")).replace(DpRJnas65uVcO0S17dYG(u"ࠧศ่่ํࠬᶁ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠨษ้้๏ฺๆࠨᶂ")).replace(weh7SGmuTgXOVRcMo1rlLq(u"ࠩส๊๊๐ࠧᶃ"),yRWQMHxZEz0(u"ࠪห๋๋๊ี่ࠪᶄ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫฬ์ๅ๋ึุ้๋࠭ᶅ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬอๆๆ์ื๊ࠬᶆ")).replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭วๅษ้้๏ฺๆࠨᶇ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧศ่่๎ู์ࠧᶈ")).replace(xm6jK1ZMuWq5(u"ࠨษไ่ฬ๋ࠠๆี็ื้อสࠨᶉ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪᶊ"))
				LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).strip(it4DKnryZlx(u"ࠪ࠱ࠬᶋ")).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if LcukPqj3x6f9WDZQh5YJzg not in list(sxzI2flt78kGXZr.keys()): sxzI2flt78kGXZr[LcukPqj3x6f9WDZQh5YJzg] = {}
			sxzI2flt78kGXZr[LcukPqj3x6f9WDZQh5YJzg][g40I3ZXaeJ8qVywt] = [TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,iE0GxkBnVRO4NPwleT,ooPMZSnrRDG6xNpJHVmgw8IOA1,lTqParb4mfMHGYXLVOCN3,G02Gb6uxEgT39wNCJvefMzmFI,eIRJAgj25bzvNik48puZl3OPUq,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,RG73XpOfASe6WT25jsEQxPq4wLr]
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᶌ"),yRWQMHxZEz0(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᶍ"),sxzI2flt78kGXZr,pHC2Aj4kbc3KDN0aZWBey6QV)
	if z7QK0CGSnqB3e>=ssPqWhCJOgGHwTdS: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,bQGafNLXyFgsZP6ut(u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧᶎ")+str(z7QK0CGSnqB3e)+yRWQMHxZEz0(u"ࠧࠡ็๋ๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้้ࠠๆิฬࠦๅีๅ็อูࠥศษ้สࠤ฾อฯส่๊ࠢࠥอไฦ่อี๋๐สࠡ฻้ำ่่ࠦศๆ่์ฬู่้ࠡํ࠾ࠬᶏ")+ppDPeoTun6xBEUasQi2L1)
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,vWNRusF46D7Mi8GpZ(u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧᶐ"))
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(cc2JaqoYp8m,cc2JaqoYp8m,cc2JaqoYp8m)
	sKv7WVYzUI()
	return
def Foq6xbQOeLcKBPzu(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	z2fdMC3QlYO5ar1W0sq = TTuO14NzmB.menuItemsLIST
	TTuO14NzmB.menuItemsLIST[:] = []
	if RCBXDnhK3jHYUvJ and gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᶑ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		RCmHBOKtejQ8lu4L = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡰ࡮ࡹࡴࠨᶒ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫᶓ"),DpRJnas65uVcO0S17dYG(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭ᶔ")+Be4AsSL71xyhHNQYV2wdvJ)
	elif jQv0du1iVxTgAXCM(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᶕ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe or yRWQMHxZEz0(u"ࠧࡠࡘࡒࡈࡤ࠭ᶖ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		import lFWVNcqCio
		SLAiUwpDRoZIQfvB7 = MFhbWia58mP3su0fk2d(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥืำศศ็ࠤฬ๊ศา่ส้ั࠭ᶗ")
		if llkFwuCyhaP3sK76qO4T(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᶘ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			try: lFWVNcqCio.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,fmkZtbRj3ux(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶙ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶚ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᶛ"),SLAiUwpDRoZIQfvB7)
			try: lFWVNcqCio.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᶜ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶝ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᶞ"),SLAiUwpDRoZIQfvB7)
			try: lFWVNcqCio.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,it4DKnryZlx(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶟ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+rDG9dZoXRhCJcieUSF0KB(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶠ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D2PpKMeZFWrmfxTSs4L1tz(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᶡ"),SLAiUwpDRoZIQfvB7)
		if vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡥࡖࡐࡆࡢࠫᶢ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			try: lFWVNcqCio.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,fmkZtbRj3ux(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᶣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶤ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭ᶥ"),SLAiUwpDRoZIQfvB7)
			try: lFWVNcqCio.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᶦ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+xm6jK1ZMuWq5(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶧ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᶨ"),SLAiUwpDRoZIQfvB7)
		RCmHBOKtejQ8lu4L = TTuO14NzmB.menuItemsLIST
		if RCBXDnhK3jHYUvJ: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,vWNRusF46D7Mi8GpZ(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᶩ"),w8JC1y7Lp3(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᶪ")+Be4AsSL71xyhHNQYV2wdvJ,RCmHBOKtejQ8lu4L,pHC2Aj4kbc3KDN0aZWBey6QV)
	TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq
	return RCmHBOKtejQ8lu4L
def iuCEk1znoSe7VrY4IRMTWQ0F(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	z2fdMC3QlYO5ar1W0sq = TTuO14NzmB.menuItemsLIST
	TTuO14NzmB.menuItemsLIST[:] = []
	if RCBXDnhK3jHYUvJ and weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᶫ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		RCmHBOKtejQ8lu4L = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,w8JC1y7Lp3(u"ࠨ࡮࡬ࡷࡹ࠭ᶬ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨᶭ"),kPCxIUZb1V(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪᶮ")+Be4AsSL71xyhHNQYV2wdvJ)
	elif erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡤࡒࡉࡗࡇࡢࠫᶯ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe or gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡥࡖࡐࡆࡢࠫᶰ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		import L7lMpnYoUi
		SLAiUwpDRoZIQfvB7 = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫᶱ")
		if D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᶲ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			try: L7lMpnYoUi.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶳ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶴ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᶵ"),SLAiUwpDRoZIQfvB7)
			try: L7lMpnYoUi.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,weh7SGmuTgXOVRcMo1rlLq(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶶ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶷ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᶸ"),SLAiUwpDRoZIQfvB7)
			try: L7lMpnYoUi.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᶹ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+Gj3rMP1Cb8wHdp49la0(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶺ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᶻ"),SLAiUwpDRoZIQfvB7)
		if lCT8hfYUBX4OQMmL(u"ࠪࡣ࡛ࡕࡄࡠࠩᶼ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			try: L7lMpnYoUi.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,yRWQMHxZEz0(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᶽ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪᶿ"),SLAiUwpDRoZIQfvB7)
			try: L7lMpnYoUi.GxgaJFV3ejs6vlt(Be4AsSL71xyhHNQYV2wdvJ,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᷀"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,hg4F23dunEM56UpCOBk1IzoKHiwXe+lCT8hfYUBX4OQMmL(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷁"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			except: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ᷂࠭"),SLAiUwpDRoZIQfvB7)
		RCmHBOKtejQ8lu4L = TTuO14NzmB.menuItemsLIST
		if RCBXDnhK3jHYUvJ: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,xdSThjYnuHXAU6M(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ᷃"),fmkZtbRj3ux(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ᷄")+Be4AsSL71xyhHNQYV2wdvJ,RCmHBOKtejQ8lu4L,pHC2Aj4kbc3KDN0aZWBey6QV)
	TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq
	return RCmHBOKtejQ8lu4L
def ilwPmvIGqLfp4MSs(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe,wRDutjBFbxc5voYgTsp2OV):
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(hbdwEgkQ6DLYV1TKuioHxyvj,hbdwEgkQ6DLYV1TKuioHxyvj,uxig7mJanAYQ20)
	if wRDutjBFbxc5voYgTsp2OV: d8C14ZjXT2xRFbJpVOMkgvihaPys(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	elif llkFwuCyhaP3sK76qO4T(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᷅") in hg4F23dunEM56UpCOBk1IzoKHiwXe and not wRDutjBFbxc5voYgTsp2OV: d8C14ZjXT2xRFbJpVOMkgvihaPys(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	ZGiOTx20MrczNWpCsdRyQJ71P = hg4F23dunEM56UpCOBk1IzoKHiwXe.replace(xm6jK1ZMuWq5(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ᷆"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷇"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᷈"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if not wRDutjBFbxc5voYgTsp2OV:
		mwOxEyYAg63B(fmkZtbRj3ux(u"ࠩ࡯࡭ࡳࡱࠧ᷉"),xdSThjYnuHXAU6M(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡษ็ว็ูวๆ᷊ࠩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"࠹࠹࠷ὃ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ᷋")+ZGiOTx20MrczNWpCsdRyQJ71P,wUvcPrYDfISbZolAm83GKEqMyXkn5,{xdSThjYnuHXAU6M(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᷌"):Be4AsSL71xyhHNQYV2wdvJ})
		mwOxEyYAg63B(s149dk8uh2p7oFzaLxZeI3Or(u"࠭࡬ࡪࡰ࡮ࠫ᷍"),JegF7SlMawI03+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤ᷎ࠬ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"࠼࠽࠾࠿ὄ"))
		jueS3k8RGHrMdIK = [DpRJnas65uVcO0S17dYG(u"ࠨลไ่ฬ๋᷏ࠧ"),vvhR5ozeiJpANyl8fFO3GBw(u"่ࠩืู้ไศฬ᷐ࠪ"),lCT8hfYUBX4OQMmL(u"ุ้ࠪือ๋ษอࠫ᷑"),DpRJnas65uVcO0S17dYG(u"ࠫอืวๆฮࠪ᷒"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬษืโษ็ࠤํ้ัห๊้ࠫᷓ"),kPCxIUZb1V(u"࠭ัๆุส๊ࠬᷔ"),vWNRusF46D7Mi8GpZ(u"ࠧฤฯาฯ࠲ษฮาࠩᷕ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨี็หุ๊ࠧᷖ"),MFhbWia58mP3su0fk2d(u"่ࠩ์ุ๐โ๊ࠩᷗ"),Gj3rMP1Cb8wHdp49la0(u"ࠪวูํั࠮ลๆฯึ࠭ᷘ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫฬ๊ย็ࠩᷙ"),fmkZtbRj3ux(u"ࠬ฼อไࠩᷚ"),llkFwuCyhaP3sK76qO4T(u"࠭ั๋ษูอࠬᷛ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ็์อๅ้้ำࠨᷜ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ็่ฯ้๐ๆࠨᷝ"),rDG9dZoXRhCJcieUSF0KB(u"ࠩหฯࠥำ๊ࠨᷞ"),xdSThjYnuHXAU6M(u"ࠪำ๏์๊สࠩᷟ"),bQGafNLXyFgsZP6ut(u"ุࠫ์่ศฬࠪᷠ"),Gj3rMP1Cb8wHdp49la0(u"ࠬษฮา๋ࠪᷡ")]
		wRDutjBFbxc5voYgTsp2OV = wTLFCOcM26fmYlW7U
		for ixIcWUqePf4jph in jueS3k8RGHrMdIK:
			wRDutjBFbxc5voYgTsp2OV += UD4N8MjVTd
			mwOxEyYAg63B(DpRJnas65uVcO0S17dYG(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᷢ"),UT69hgqoKsWNIwM5zkAYb+ixIcWUqePf4jph,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠻࠻࠹ὅ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,str(wRDutjBFbxc5voYgTsp2OV),ZGiOTx20MrczNWpCsdRyQJ71P,wUvcPrYDfISbZolAm83GKEqMyXkn5,{xdSThjYnuHXAU6M(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᷣ"):Be4AsSL71xyhHNQYV2wdvJ})
	else:
		Vegxa6Tj3r0udwlkLQ = [bQGafNLXyFgsZP6ut(u"ࠨษไ่ฬ๋ࠧᷤ"),MFhbWia58mP3su0fk2d(u"ࠩࡰࡳࡻ࡯ࡥࠨᷥ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠪๅ๏๊ๅࠨᷦ"),xm6jK1ZMuWq5(u"ࠫๆ๊ๅࠨᷧ")]
		ymR58kPWbDiQ = [erqDsJmL3BQHuGtPkcf0X9(u"๋ࠬำๅี็ࠫᷨ"),TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ᷩ")]
		ccJiPAkNx91VXe = [kPCxIUZb1V(u"ࠧๆีสีา࠭ᷪ"),jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨ็ึีา๐วหࠩᷫ")]
		Jen7oxFcyZ1 = [jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩหีฬ๋ฬࠨᷬ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡷ࡭ࡵࡷࠨᷭ"),xdSThjYnuHXAU6M(u"ࠫฯ๊แำ์๋๊ࠬᷮ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠬะไ๋ใี๎ํ์ࠧᷯ")]
		q2jQ4Hws8hv6 = [pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ว็็ํࠫᷰ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧไำอ์๋࠭ᷱ"),lCT8hfYUBX4OQMmL(u"ࠨๅสีฯ๎ๆࠨᷲ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࡮࡭ࡩࡹࠧᷳ"),rDG9dZoXRhCJcieUSF0KB(u"ࠪ฻ๆ๊ࠧᷴ"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫฬ฽แศๆࠪ᷵")]
		y2u3FGPWw8jx = [JHMxIE4fs1mvQtKW7R(u"ࠬืๅืษ้ࠫ᷶")]
		FEkrl38NI7HGMiB9uCye1hjJU = [it4DKnryZlx(u"࠭วฮัฮ᷷ࠫ"),w8JC1y7Lp3(u"ࠧศะิ᷸ࠫ"),vWNRusF46D7Mi8GpZ(u"ࠨ็๋าึ᷹࠭"),VhqD3zp7mUieI8sMQlETH(u"ࠩฯำ๏ี᷺ࠧ"),jQv0du1iVxTgAXCM(u"้ࠪ฻อแࠨ᷻"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠫาี๊ฬࠩ᷼")]
		PmjSvcuIRs8Wln0fxM = [w8JC1y7Lp3(u"ูࠬไศี็᷽ࠫ"),vvhR5ozeiJpANyl8fFO3GBw(u"࠭ำๅี็๋ࠬ᷾")]
		cLb5jQMXqBJHU1rZNW9Ep6O23aARgt = [bQGafNLXyFgsZP6ut(u"ࠧศ฼ส๊๏᷿࠭"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨ็๋ื๏่้ࠨḀ"),VhqD3zp7mUieI8sMQlETH(u"ࠩๆ่๏ฮࠧḁ"),xdSThjYnuHXAU6M(u"ࠪัๆ๊ࠧḂ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡲࡻࡳࡪࡥࠪḃ")]
		mK9fWYM7uJ60cSLqjokT1Z = [kPCxIUZb1V(u"ࠬอใฬำࠪḄ"),xm6jK1ZMuWq5(u"࠭วี้ิࠫḅ"),w8JC1y7Lp3(u"ࠧๆ็ํึ์࠭Ḇ"),kPCxIUZb1V(u"ࠨษ฼่๎࠭ḇ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"่ࠩาฯอั่ࠩḈ"),vvhR5ozeiJpANyl8fFO3GBw(u"้ࠪำะวาษอࠫḉ"),xdSThjYnuHXAU6M(u"ࠫฬ่่๊ࠩḊ")]
		QkO0JxTHreX = [erqDsJmL3BQHuGtPkcf0X9(u"ࠬอไศ่ࠪḋ"),s149dk8uh2p7oFzaLxZeI3Or(u"࠭อศๆํࠫḌ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠧๆอหฮࠬḍ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠨำสสั࠭Ḏ")]
		OOM0Sw6lYzohLg2A14ucRIByET = [erqDsJmL3BQHuGtPkcf0X9(u"ูࠩั่࠭ḏ"),A6Sg45ChDR3BJLYfFH(u"ࠪ็ํ๋๊ะ์ࠪḐ")]
		uUXHpvwmnT = [pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫึ๐วื้ࠪḑ"),xdSThjYnuHXAU6M(u"้่ࠬา้ࠪḒ"),JHMxIE4fs1mvQtKW7R(u"࠭ๅึษิ฽์࠭ḓ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧี๊อࠫḔ"),A6Sg45ChDR3BJLYfFH(u"ࠨำํห฻ฯࠧḕ")]
		HH6SACMBlysmhDKT1Z = [w8JC1y7Lp3(u"้ࠩ๎ฯ็ไไีࠪḖ"),it4DKnryZlx(u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫḗ"),xdSThjYnuHXAU6M(u"๋ࠫ๐สโๆํ็ุ࠭Ḙ")]
		aacklGtOguEHQNB = [bQGafNLXyFgsZP6ut(u"๋ࠬๅฬๆํ๊ࠬḙ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭วีะสูࠬḚ"),A6Sg45ChDR3BJLYfFH(u"ࠧ็ฮ๋้ࠬḛ")]
		z2zkeZjJRb1Wx0SyLXGVlNq = [vWNRusF46D7Mi8GpZ(u"ࠨสฮࠤา๐ࠧḜ"),DpRJnas65uVcO0S17dYG(u"ࠩ࡯࡭ࡻ࡫ࠧḝ"),kPCxIUZb1V(u"ࠪๆ๋อ็ࠨḞ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫ็์่ศฬࠪḟ")]
		uzNCERAp8MhxlIyT13 = [jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬี๊็ࠩḠ"),s149dk8uh2p7oFzaLxZeI3Or(u"࠭วะ฻ํ๋ࠬḡ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠧำ์สีฬะࠧḢ"),JHMxIE4fs1mvQtKW7R(u"ࠨๆฺ้๏อสࠨḣ"),JHMxIE4fs1mvQtKW7R(u"ࠩา฽ฬวࠧḤ"),yRWQMHxZEz0(u"ࠪๆึอๆࠨḥ"),xdSThjYnuHXAU6M(u"ࠫ็฻ววัࠪḦ"),fmkZtbRj3ux(u"ࠬืหศรࠪḧ"),rDG9dZoXRhCJcieUSF0KB(u"࠭ๅาฮ฼๎์࠭Ḩ"),DpRJnas65uVcO0S17dYG(u"ࠧศาส๊ࠬḩ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠨษึ่ฬ๋ࠧḪ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠩอ์ฬฺ๊ฮࠩḫ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪา฼ฮࠧḬ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫา๎า้์ࠪḭ"),it4DKnryZlx(u"ࠬ฿สษษอࠫḮ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ๅ้ษ็๎ิ࠭ḯ"),lCT8hfYUBX4OQMmL(u"ࠧ็๊ส฽๏࠭Ḱ"),yRWQMHxZEz0(u"ࠨ฻ๅหหีࠧḱ"),JHMxIE4fs1mvQtKW7R(u"ࠩส๊ฬฺ๊ะࠩḲ")]
		n5oFSfs3M9Ug = [JHMxIE4fs1mvQtKW7R(u"ࠪ࠶࠵࠷࠰ࠨḳ"),fmkZtbRj3ux(u"ࠫ࠷࠶࠱࠲ࠩḴ"),MFhbWia58mP3su0fk2d(u"ࠬ࠸࠰࠲࠴ࠪḵ"),yRWQMHxZEz0(u"࠭࠲࠱࠳࠶ࠫḶ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠳࠲࠴࠸ࠬḷ"),fmkZtbRj3ux(u"ࠨ࠴࠳࠵࠺࠭Ḹ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࠵࠴࠶࠼ࠧḹ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪ࠶࠵࠷࠷ࠨḺ"),lCT8hfYUBX4OQMmL(u"ࠫ࠷࠶࠱࠹ࠩḻ"),DpRJnas65uVcO0S17dYG(u"ࠬ࠸࠰࠲࠻ࠪḼ"),JHMxIE4fs1mvQtKW7R(u"࠭࠲࠱࠴࠳ࠫḽ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠧ࠳࠲࠵࠵ࠬḾ"),it4DKnryZlx(u"ࠨ࠴࠳࠶࠷࠭ḿ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩ࠵࠴࠷࠹ࠧṀ"),xdSThjYnuHXAU6M(u"ࠪ࠶࠵࠸࠴ࠨṁ"),yRWQMHxZEz0(u"ࠫ࠷࠶࠲࠶ࠩṂ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬ࠸࠰࠳࠸ࠪṃ"),D2PpKMeZFWrmfxTSs4L1tz(u"࠭࠲࠱࠴࠺ࠫṄ"),bQGafNLXyFgsZP6ut(u"ࠧ࠳࠲࠵࠼ࠬṅ")]
		for LcukPqj3x6f9WDZQh5YJzg in sorted(list(sxzI2flt78kGXZr.keys())):
			QSuoms9tfxPZwgEea = LcukPqj3x6f9WDZQh5YJzg.lower()
			d5TLHSj39awfvFp = []
			if any(value in QSuoms9tfxPZwgEea for value in Vegxa6Tj3r0udwlkLQ): d5TLHSj39awfvFp.append(UD4N8MjVTd)
			if any(value in QSuoms9tfxPZwgEea for value in ymR58kPWbDiQ): d5TLHSj39awfvFp.append(Tb7oymMnpflsSv3eu4Pz2)
			if any(value in QSuoms9tfxPZwgEea for value in ccJiPAkNx91VXe): d5TLHSj39awfvFp.append(MMRBkhnWVJCQwU)
			if any(value in QSuoms9tfxPZwgEea for value in Jen7oxFcyZ1): d5TLHSj39awfvFp.append(R9RNUT6WAPEYjHqtIokxuXs)
			if any(value in QSuoms9tfxPZwgEea for value in q2jQ4Hws8hv6): d5TLHSj39awfvFp.append(ewJ9sTMmXtWH0ANVShQ2)
			if any(value in QSuoms9tfxPZwgEea for value in y2u3FGPWw8jx): d5TLHSj39awfvFp.append(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠻὆"))
			if any(value in QSuoms9tfxPZwgEea for value in FEkrl38NI7HGMiB9uCye1hjJU) and QSuoms9tfxPZwgEea not in [dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨษัี๎࠭Ṇ")]: d5TLHSj39awfvFp.append(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠽὇"))
			if any(value in QSuoms9tfxPZwgEea for value in PmjSvcuIRs8Wln0fxM): d5TLHSj39awfvFp.append(xdSThjYnuHXAU6M(u"࠸Ὀ"))
			if any(value in QSuoms9tfxPZwgEea for value in cLb5jQMXqBJHU1rZNW9Ep6O23aARgt): d5TLHSj39awfvFp.append(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠺Ὁ"))
			if any(value in QSuoms9tfxPZwgEea for value in mK9fWYM7uJ60cSLqjokT1Z): d5TLHSj39awfvFp.append(vWNRusF46D7Mi8GpZ(u"࠳࠳Ὂ"))
			if any(value in QSuoms9tfxPZwgEea for value in QkO0JxTHreX): d5TLHSj39awfvFp.append(xm6jK1ZMuWq5(u"࠴࠵Ὃ"))
			if any(value in QSuoms9tfxPZwgEea for value in OOM0Sw6lYzohLg2A14ucRIByET): d5TLHSj39awfvFp.append(it4DKnryZlx(u"࠵࠷Ὄ"))
			if any(value in QSuoms9tfxPZwgEea for value in uUXHpvwmnT): d5TLHSj39awfvFp.append(DpRJnas65uVcO0S17dYG(u"࠶࠹Ὅ"))
			if any(value in QSuoms9tfxPZwgEea for value in HH6SACMBlysmhDKT1Z): d5TLHSj39awfvFp.append(fmkZtbRj3ux(u"࠷࠴὎"))
			if any(value in QSuoms9tfxPZwgEea for value in aacklGtOguEHQNB): d5TLHSj39awfvFp.append(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠱࠶὏"))
			if any(value in QSuoms9tfxPZwgEea for value in z2zkeZjJRb1Wx0SyLXGVlNq): d5TLHSj39awfvFp.append(xm6jK1ZMuWq5(u"࠲࠸ὐ"))
			if any(value in QSuoms9tfxPZwgEea for value in uzNCERAp8MhxlIyT13): d5TLHSj39awfvFp.append(A6Sg45ChDR3BJLYfFH(u"࠳࠺ὑ"))
			if any(value in QSuoms9tfxPZwgEea for value in n5oFSfs3M9Ug): d5TLHSj39awfvFp.append(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠴࠼ὒ"))
			if not d5TLHSj39awfvFp: d5TLHSj39awfvFp = [kPCxIUZb1V(u"࠵࠾ὓ")]
			for uNYcJXVSEtzBU1GlT7Hwm4MevaAP in d5TLHSj39awfvFp:
				if str(uNYcJXVSEtzBU1GlT7Hwm4MevaAP)==wRDutjBFbxc5voYgTsp2OV:
					mwOxEyYAg63B(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡩࡳࡱࡪࡥࡳࠩṇ"),UT69hgqoKsWNIwM5zkAYb+LcukPqj3x6f9WDZQh5YJzg,LcukPqj3x6f9WDZQh5YJzg,xm6jK1ZMuWq5(u"࠶࠼࠶ὔ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZGiOTx20MrczNWpCsdRyQJ71P+vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṈ"))
	vk2AWPdaQpzxMuht3ZNqfienVRwL7(hbdwEgkQ6DLYV1TKuioHxyvj,hbdwEgkQ6DLYV1TKuioHxyvj,cc2JaqoYp8m)
	return
def M6jvoda1gIQuR2r5qH(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if RCBXDnhK3jHYUvJ:
		mwOxEyYAg63B(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡱ࡯࡮࡬ࠩṉ"),bQGafNLXyFgsZP6ut(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧṊ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"࠽࠶࠵ὕ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,weh7SGmuTgXOVRcMo1rlLq(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫṋ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,{vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṌ"):Be4AsSL71xyhHNQYV2wdvJ})
		mwOxEyYAg63B(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨ࡮࡬ࡲࡰ࠭ṍ"),JegF7SlMawI03+D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧṎ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠹࠺࠻࠼ὖ"))
	z2fdMC3QlYO5ar1W0sq = TTuO14NzmB.menuItemsLIST[:]
	import lFWVNcqCio
	if Be4AsSL71xyhHNQYV2wdvJ:
		if not lFWVNcqCio.lu7ViXewzT4jtDacZKNnF2(Be4AsSL71xyhHNQYV2wdvJ,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		o6JQTieKWIGC8z0y = Foq6xbQOeLcKBPzu(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe)
		KCN5dJHLyWQ7vpc1btgsEwfYi2e = sorted(o6JQTieKWIGC8z0y,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[UD4N8MjVTd].lower())
	else:
		if not lFWVNcqCio.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		if RCBXDnhK3jHYUvJ and DpRJnas65uVcO0S17dYG(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨṏ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			KCN5dJHLyWQ7vpc1btgsEwfYi2e = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡱ࡯ࡳࡵࠩṐ"),kPCxIUZb1V(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬṑ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪṒ"))
		else:
			GGq3XVAFuCnScNdlT47z,KCN5dJHLyWQ7vpc1btgsEwfYi2e,o6JQTieKWIGC8z0y = [],[],[]
			for M9o7QSxNGjn2ctYCA in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
				KCN5dJHLyWQ7vpc1btgsEwfYi2e += Foq6xbQOeLcKBPzu(str(M9o7QSxNGjn2ctYCA),hg4F23dunEM56UpCOBk1IzoKHiwXe)
			for type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in KCN5dJHLyWQ7vpc1btgsEwfYi2e:
				if eIRJAgj25bzvNik48puZl3OPUq not in GGq3XVAFuCnScNdlT47z:
					GGq3XVAFuCnScNdlT47z.append(eIRJAgj25bzvNik48puZl3OPUq)
					wrOoi7At01VugS = type,LcukPqj3x6f9WDZQh5YJzg,eIRJAgj25bzvNik48puZl3OPUq,kPCxIUZb1V(u"࠲࠸࠸ὗ"),mnWZN7g50M,sbNukjOf4chz,hg4F23dunEM56UpCOBk1IzoKHiwXe,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ
					o6JQTieKWIGC8z0y.append(wrOoi7At01VugS)
			KCN5dJHLyWQ7vpc1btgsEwfYi2e = sorted(o6JQTieKWIGC8z0y,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[UD4N8MjVTd].lower())
			if RCBXDnhK3jHYUvJ: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧṓ"),A6Sg45ChDR3BJLYfFH(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬṔ"),KCN5dJHLyWQ7vpc1btgsEwfYi2e,pHC2Aj4kbc3KDN0aZWBey6QV)
	TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e
	ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def j9j0TYJhn6FVCpvUstqbRwo17Q(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if RCBXDnhK3jHYUvJ:
		mwOxEyYAg63B(xm6jK1ZMuWq5(u"ࠩ࡯࡭ࡳࡱࠧṕ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡎ࠵ࡘࠫṖ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"࠹࠹࠹὘"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṗ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,{weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṘ"):Be4AsSL71xyhHNQYV2wdvJ})
		mwOxEyYAg63B(lCT8hfYUBX4OQMmL(u"࠭࡬ࡪࡰ࡮ࠫṙ"),JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṚ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠼࠽࠾࠿Ὑ"))
	z2fdMC3QlYO5ar1W0sq = TTuO14NzmB.menuItemsLIST[:]
	import L7lMpnYoUi
	if Be4AsSL71xyhHNQYV2wdvJ:
		if not L7lMpnYoUi.lu7ViXewzT4jtDacZKNnF2(Be4AsSL71xyhHNQYV2wdvJ,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		o6JQTieKWIGC8z0y = iuCEk1znoSe7VrY4IRMTWQ0F(Be4AsSL71xyhHNQYV2wdvJ,hg4F23dunEM56UpCOBk1IzoKHiwXe)
		KCN5dJHLyWQ7vpc1btgsEwfYi2e = sorted(o6JQTieKWIGC8z0y,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[UD4N8MjVTd].lower())
	else:
		if not L7lMpnYoUi.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		if RCBXDnhK3jHYUvJ and VhqD3zp7mUieI8sMQlETH(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ṛ") not in hg4F23dunEM56UpCOBk1IzoKHiwXe:
			KCN5dJHLyWQ7vpc1btgsEwfYi2e = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,w8JC1y7Lp3(u"ࠩ࡯࡭ࡸࡺࠧṜ"),VhqD3zp7mUieI8sMQlETH(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩṝ"),DpRJnas65uVcO0S17dYG(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧṞ"))
		else:
			GGq3XVAFuCnScNdlT47z,KCN5dJHLyWQ7vpc1btgsEwfYi2e,o6JQTieKWIGC8z0y = [],[],[]
			for M9o7QSxNGjn2ctYCA in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
				KCN5dJHLyWQ7vpc1btgsEwfYi2e += iuCEk1znoSe7VrY4IRMTWQ0F(str(M9o7QSxNGjn2ctYCA),hg4F23dunEM56UpCOBk1IzoKHiwXe)
			for type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in KCN5dJHLyWQ7vpc1btgsEwfYi2e:
				if eIRJAgj25bzvNik48puZl3OPUq not in GGq3XVAFuCnScNdlT47z:
					GGq3XVAFuCnScNdlT47z.append(eIRJAgj25bzvNik48puZl3OPUq)
					wrOoi7At01VugS = type,LcukPqj3x6f9WDZQh5YJzg,eIRJAgj25bzvNik48puZl3OPUq,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠵࠻࠻὚"),mnWZN7g50M,sbNukjOf4chz,hg4F23dunEM56UpCOBk1IzoKHiwXe,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ
					o6JQTieKWIGC8z0y.append(wrOoi7At01VugS)
			KCN5dJHLyWQ7vpc1btgsEwfYi2e = sorted(o6JQTieKWIGC8z0y,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[UD4N8MjVTd].lower())
			if RCBXDnhK3jHYUvJ: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,xm6jK1ZMuWq5(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫṟ"),w8JC1y7Lp3(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩṠ"),KCN5dJHLyWQ7vpc1btgsEwfYi2e,pHC2Aj4kbc3KDN0aZWBey6QV)
	TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e
	ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def pOgCf36uvw9sjmI(group,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	RCBXDnhK3jHYUvJ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	RCmHBOKtejQ8lu4L = []
	H0AjxOiqQ24RmcN5ZpXwEfK = weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧṡ") if kPCxIUZb1V(u"ࠨࡋࡓࡘ࡛࠭Ṣ") in hg4F23dunEM56UpCOBk1IzoKHiwXe else pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡢࡑ࠸࡛࡟ࠨṣ")
	if RCBXDnhK3jHYUvJ: RCmHBOKtejQ8lu4L = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡰ࡮ࡹࡴࠨṤ"),DpRJnas65uVcO0S17dYG(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭ṥ")+H0AjxOiqQ24RmcN5ZpXwEfK[:-UD4N8MjVTd],group)
	if not RCmHBOKtejQ8lu4L:
		for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
			if RCBXDnhK3jHYUvJ: RCmHBOKtejQ8lu4L += o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,VhqD3zp7mUieI8sMQlETH(u"ࠬࡲࡩࡴࡶࠪṦ"),bQGafNLXyFgsZP6ut(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨṧ")+H0AjxOiqQ24RmcN5ZpXwEfK[:-UD4N8MjVTd],lCT8hfYUBX4OQMmL(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩṨ")+H0AjxOiqQ24RmcN5ZpXwEfK+str(Be4AsSL71xyhHNQYV2wdvJ))
			elif H0AjxOiqQ24RmcN5ZpXwEfK==kPCxIUZb1V(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨṩ"): RCmHBOKtejQ8lu4L += Foq6xbQOeLcKBPzu(str(Be4AsSL71xyhHNQYV2wdvJ),xdSThjYnuHXAU6M(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧṪ"))
			elif H0AjxOiqQ24RmcN5ZpXwEfK==kPCxIUZb1V(u"ࠪࡣࡒ࠹ࡕࡠࠩṫ"): RCmHBOKtejQ8lu4L += iuCEk1znoSe7VrY4IRMTWQ0F(str(Be4AsSL71xyhHNQYV2wdvJ),erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṬ"))
		for type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in RCmHBOKtejQ8lu4L:
			if eIRJAgj25bzvNik48puZl3OPUq==group: DQ2dIilnTb4BVuMzgh(type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
		items,VV7eQk5mj1dBNiHtrcP = [],[]
		for type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in TTuO14NzmB.menuItemsLIST:
			Ighyojd2sv1wWP89c = type,LcukPqj3x6f9WDZQh5YJzg[R9RNUT6WAPEYjHqtIokxuXs:],url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,wUvcPrYDfISbZolAm83GKEqMyXkn5
			if Ighyojd2sv1wWP89c not in VV7eQk5mj1dBNiHtrcP:
				VV7eQk5mj1dBNiHtrcP.append(Ighyojd2sv1wWP89c)
				o4oW9wDcsrpHQS816yfIvg = type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ
				items.append(o4oW9wDcsrpHQS816yfIvg)
		RCmHBOKtejQ8lu4L = sorted(items,reverse=Z19pUxa2gfGMNKoDsEuytn85SjFvA,key=lambda key: key[UD4N8MjVTd].lower()[bQGafNLXyFgsZP6ut(u"࠺Ὓ"):])
		if RCBXDnhK3jHYUvJ: SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,yRWQMHxZEz0(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧṭ")+H0AjxOiqQ24RmcN5ZpXwEfK[:-UD4N8MjVTd],group,RCmHBOKtejQ8lu4L,pHC2Aj4kbc3KDN0aZWBey6QV)
	if fmkZtbRj3ux(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨṮ") in hg4F23dunEM56UpCOBk1IzoKHiwXe and len(RCmHBOKtejQ8lu4L)>aaY7B0Pbr1y9JUQ3InkEpSMflHFWe:
		TTuO14NzmB.menuItemsLIST[:] = []
		mwOxEyYAg63B(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṯ"),fmkZtbRj3ux(u"ࠨ࡝ࠪṰ")+JegF7SlMawI03+group+AAByQSLgaZwCsKnvc5eWNmY+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫṱ"),group,bQGafNLXyFgsZP6ut(u"࠷࠶࠶὜"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,H0AjxOiqQ24RmcN5ZpXwEfK+VhqD3zp7mUieI8sMQlETH(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṲ"))
		mwOxEyYAg63B(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṳ"),MFhbWia58mP3su0fk2d(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫṴ"),group,it4DKnryZlx(u"࠱࠷࠷Ὕ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,H0AjxOiqQ24RmcN5ZpXwEfK+TNw1pBHb8CtSZe0EFxuJqI(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṵ"))
		mwOxEyYAg63B(w8JC1y7Lp3(u"ࠧ࡭࡫ࡱ࡯ࠬṶ"),JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ṷ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"࠺࠻࠼࠽὞"))
		RCmHBOKtejQ8lu4L = TTuO14NzmB.menuItemsLIST+kItsbxAFUXc3.sample(RCmHBOKtejQ8lu4L,aaY7B0Pbr1y9JUQ3InkEpSMflHFWe)
	TTuO14NzmB.menuItemsLIST[:] = RCmHBOKtejQ8lu4L
	ik374RHsnw0uAgmLBvGSecIPUo8(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	return
def DAJC0Yulx4btHe7Vw9XqRNK(hg4F23dunEM56UpCOBk1IzoKHiwXe):
	mwOxEyYAg63B(kPCxIUZb1V(u"ࠩࡩࡳࡱࡪࡥࡳࠩṸ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭ṹ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,vvhR5ozeiJpANyl8fFO3GBw(u"࠳࠹࠵Ὗ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫṺ"))
	mwOxEyYAg63B(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡲࡩ࡯࡭ࠪṻ"),JegF7SlMawI03+bQGafNLXyFgsZP6ut(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫṼ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,vWNRusF46D7Mi8GpZ(u"࠼࠽࠾࠿ὠ"))
	mmElzArbhHYuMT43V97 = TTuO14NzmB.menuItemsLIST[:]
	TTuO14NzmB.menuItemsLIST[:] = []
	import hhBlgHtW5I
	hhBlgHtW5I.UUOhG6SD19FL2AztHln3uT4Xg5d8f(s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠱ࠩṽ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	hhBlgHtW5I.UUOhG6SD19FL2AztHln3uT4Xg5d8f(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨ࠳ࠪṾ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	hhBlgHtW5I.UUOhG6SD19FL2AztHln3uT4Xg5d8f(rDG9dZoXRhCJcieUSF0KB(u"ࠩ࠵ࠫṿ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	if JHMxIE4fs1mvQtKW7R(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬẀ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		TTuO14NzmB.menuItemsLIST[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
		if len(TTuO14NzmB.menuItemsLIST)>aaY7B0Pbr1y9JUQ3InkEpSMflHFWe: TTuO14NzmB.menuItemsLIST[:] = kItsbxAFUXc3.sample(TTuO14NzmB.menuItemsLIST,aaY7B0Pbr1y9JUQ3InkEpSMflHFWe)
	TTuO14NzmB.menuItemsLIST[:] = mmElzArbhHYuMT43V97+TTuO14NzmB.menuItemsLIST
	return
def NymeARuXJTgQnj9WiO(hg4F23dunEM56UpCOBk1IzoKHiwXe):
	hg4F23dunEM56UpCOBk1IzoKHiwXe = hg4F23dunEM56UpCOBk1IzoKHiwXe.replace(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẁ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(A6Sg45ChDR3BJLYfFH(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẂ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	headers = { pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪẃ") : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
	url = jQv0du1iVxTgAXCM(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭Ẅ")
	data = {VhqD3zp7mUieI8sMQlETH(u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪẅ"):TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࠸࠴ࠬẆ")}
	data = rqPJzRuUF2L(data)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡋࡊ࡚ࠧẇ"),url,data,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭Ẉ"))
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall(VhqD3zp7mUieI8sMQlETH(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧẉ"),II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[wTLFCOcM26fmYlW7U]
	items = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫẊ"),IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	G92Ci1zIhv6QPKf8dELDB,PWi8LpcmYQaqBnx3uC1yTM5lZ = list(zip(*items))
	I8RHEAqYxcmNrdQFgp7taPZJhvs = []
	acPNXdSRLhUAOuGi2B6ysx3H = [UKFZBQAVXHI5s17LyvuRpCY2,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࠣࠩẋ"),xm6jK1ZMuWq5(u"ࠨࡢࠪẌ"),jQv0du1iVxTgAXCM(u"ࠩ࠯ࠫẍ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ࠲ࠬẎ"),VhqD3zp7mUieI8sMQlETH(u"ࠫ࠿࠭ẏ"),xdSThjYnuHXAU6M(u"ࠬࡁࠧẐ"),it4DKnryZlx(u"ࠨࠧࠣẑ"),it4DKnryZlx(u"ࠧ࠮ࠩẒ")]
	ZneQgCHY0ohA5PStJwdcXkaBGOW = PWi8LpcmYQaqBnx3uC1yTM5lZ+G92Ci1zIhv6QPKf8dELDB
	for kEOCqzTLhsxK6IaJy4 in ZneQgCHY0ohA5PStJwdcXkaBGOW:
		if kEOCqzTLhsxK6IaJy4 in PWi8LpcmYQaqBnx3uC1yTM5lZ: xjVTBpWXNOchkAi16glDobwF = Tb7oymMnpflsSv3eu4Pz2
		if kEOCqzTLhsxK6IaJy4 in G92Ci1zIhv6QPKf8dELDB: xjVTBpWXNOchkAi16glDobwF = R9RNUT6WAPEYjHqtIokxuXs
		NLjuJHYs5Wdpz1Dh = [kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in kEOCqzTLhsxK6IaJy4 for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in acPNXdSRLhUAOuGi2B6ysx3H]
		if any(NLjuJHYs5Wdpz1Dh):
			Q1OIedulYvrCpsfG3gLTbj6ci = NLjuJHYs5Wdpz1Dh.index(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
			sMJYHUaClRE0pGrQm9W = acPNXdSRLhUAOuGi2B6ysx3H[Q1OIedulYvrCpsfG3gLTbj6ci]
			QGRl0jxXc5zf7BCZiJwa3A = wUvcPrYDfISbZolAm83GKEqMyXkn5
			if kEOCqzTLhsxK6IaJy4.count(sMJYHUaClRE0pGrQm9W)>UD4N8MjVTd: TT0R7P1QBUIO,yJRAjSqpaKMhCPWzf2NloT,QGRl0jxXc5zf7BCZiJwa3A = kEOCqzTLhsxK6IaJy4.split(sMJYHUaClRE0pGrQm9W,Tb7oymMnpflsSv3eu4Pz2)
			else: TT0R7P1QBUIO,yJRAjSqpaKMhCPWzf2NloT = kEOCqzTLhsxK6IaJy4.split(sMJYHUaClRE0pGrQm9W,UD4N8MjVTd)
			if len(TT0R7P1QBUIO)>xjVTBpWXNOchkAi16glDobwF: I8RHEAqYxcmNrdQFgp7taPZJhvs.append(TT0R7P1QBUIO.lower())
			if len(yJRAjSqpaKMhCPWzf2NloT)>xjVTBpWXNOchkAi16glDobwF: I8RHEAqYxcmNrdQFgp7taPZJhvs.append(yJRAjSqpaKMhCPWzf2NloT.lower())
			if len(QGRl0jxXc5zf7BCZiJwa3A)>xjVTBpWXNOchkAi16glDobwF: I8RHEAqYxcmNrdQFgp7taPZJhvs.append(QGRl0jxXc5zf7BCZiJwa3A.lower())
		elif len(kEOCqzTLhsxK6IaJy4)>xjVTBpWXNOchkAi16glDobwF: I8RHEAqYxcmNrdQFgp7taPZJhvs.append(kEOCqzTLhsxK6IaJy4.lower())
	for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(Gj3rMP1Cb8wHdp49la0(u"࠽ὡ")): kItsbxAFUXc3.shuffle(I8RHEAqYxcmNrdQFgp7taPZJhvs)
	if TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩẓ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		EWhTG3651yDV7kaZMetjJlH4oYQ = VVSuXlFIYdLxpCHJ54m
	elif yRWQMHxZEz0(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩẔ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		EWhTG3651yDV7kaZMetjJlH4oYQ = [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡍࡕ࡚ࡖࠨẕ")]
		import lFWVNcqCio
		if not lFWVNcqCio.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
	elif A6Sg45ChDR3BJLYfFH(u"ࠫࡤࡓ࠳ࡖࡡࠪẖ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		EWhTG3651yDV7kaZMetjJlH4oYQ = [vWNRusF46D7Mi8GpZ(u"ࠬࡓ࠳ࡖࠩẗ")]
		import L7lMpnYoUi
		if not L7lMpnYoUi.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
	count,yIcaU6PRbGQZtwpOl = wTLFCOcM26fmYlW7U,wTLFCOcM26fmYlW7U
	mwOxEyYAg63B(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẘ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨẙ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,fmkZtbRj3ux(u"࠶࠼࠴ὢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẚ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
	mwOxEyYAg63B(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠩࡩࡳࡱࡪࡥࡳࠩẛ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪẜ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠷࠶࠵ὣ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẝ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
	mwOxEyYAg63B(it4DKnryZlx(u"ࠬࡲࡩ࡯࡭ࠪẞ"),JegF7SlMawI03+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẟ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,yRWQMHxZEz0(u"࠹࠺࠻࠼ὤ"))
	U7A5JDBpEmz2O0cZ = TTuO14NzmB.menuItemsLIST[:]
	TTuO14NzmB.menuItemsLIST[:] = []
	GhCarVo7X8nPkqd2vgtSZw = []
	for kEOCqzTLhsxK6IaJy4 in I8RHEAqYxcmNrdQFgp7taPZJhvs:
		yJRAjSqpaKMhCPWzf2NloT = jj0dZrgiKb.findall(xdSThjYnuHXAU6M(u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧẠ")+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࠥࠪạ")+bQGafNLXyFgsZP6ut(u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭Ả"),kEOCqzTLhsxK6IaJy4,jj0dZrgiKb.DOTALL)
		if yJRAjSqpaKMhCPWzf2NloT: kEOCqzTLhsxK6IaJy4 = kEOCqzTLhsxK6IaJy4.split(yJRAjSqpaKMhCPWzf2NloT[wTLFCOcM26fmYlW7U],UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		qhD79xpH2nlzOmIjC = kEOCqzTLhsxK6IaJy4.replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠪ๕ࠬả"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠫ๓࠭Ấ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬ๑ࠧấ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(lCT8hfYUBX4OQMmL(u"࠭๏ࠨẦ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(w8JC1y7Lp3(u"ࠧํࠩầ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		qhD79xpH2nlzOmIjC = qhD79xpH2nlzOmIjC.replace(bQGafNLXyFgsZP6ut(u"ࠨ๒ࠪẨ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩ๐ࠫẩ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪ๖ࠬẪ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(erqDsJmL3BQHuGtPkcf0X9(u"ࠫฑ࠭ẫ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(xm6jK1ZMuWq5(u"ࠬๆࠧẬ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		if qhD79xpH2nlzOmIjC: GhCarVo7X8nPkqd2vgtSZw.append(qhD79xpH2nlzOmIjC)
	eqNw1rIKuzyGWLpaZmUDnvFi4 = []
	for qbRmVByrJv18 in range(wTLFCOcM26fmYlW7U,rDG9dZoXRhCJcieUSF0KB(u"࠳࠲ὥ")):
		search = kItsbxAFUXc3.sample(GhCarVo7X8nPkqd2vgtSZw,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		if search in eqNw1rIKuzyGWLpaZmUDnvFi4: continue
		eqNw1rIKuzyGWLpaZmUDnvFi4.append(search)
		g40I3ZXaeJ8qVywt = kItsbxAFUXc3.sample(EWhTG3651yDV7kaZMetjJlH4oYQ,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩậ")+str(g40I3ZXaeJ8qVywt)+llkFwuCyhaP3sK76qO4T(u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪẮ")+search)
		iKL7Z0wdopbjRXM,JSV3rnwasAZ,RULru39aExTFy0tzIOGk1ivSM8Xw = Wcfy1tDNEGRu7a9eOY8k4UziJK3xh(g40I3ZXaeJ8qVywt)
		JSV3rnwasAZ(search+xm6jK1ZMuWq5(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ắ"))
		if len(TTuO14NzmB.menuItemsLIST)>wTLFCOcM26fmYlW7U: break
	search = search.replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡢࡑࡔࡊ࡟ࠨẰ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	U7A5JDBpEmz2O0cZ[wTLFCOcM26fmYlW7U][UD4N8MjVTd] = DpRJnas65uVcO0S17dYG(u"ࠪ࡟ࠬằ")+JegF7SlMawI03+search+AAByQSLgaZwCsKnvc5eWNmY+xdSThjYnuHXAU6M(u"ࠫࠥࡀศฮอࠣ฽๋ࡣࠧẲ")
	TTuO14NzmB.menuItemsLIST[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
	if len(TTuO14NzmB.menuItemsLIST)>aaY7B0Pbr1y9JUQ3InkEpSMflHFWe: TTuO14NzmB.menuItemsLIST[:] = kItsbxAFUXc3.sample(TTuO14NzmB.menuItemsLIST,aaY7B0Pbr1y9JUQ3InkEpSMflHFWe)
	TTuO14NzmB.menuItemsLIST[:] = U7A5JDBpEmz2O0cZ+TTuO14NzmB.menuItemsLIST
	return
def Bb5kGgCXaijtdZvF8prNLsD2Sq(PeOluiBMAF82rphksGHEvc,hg4F23dunEM56UpCOBk1IzoKHiwXe):
	PeOluiBMAF82rphksGHEvc = PeOluiBMAF82rphksGHEvc.replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡥࡍࡐࡆࡢࠫẳ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	hg4F23dunEM56UpCOBk1IzoKHiwXe = hg4F23dunEM56UpCOBk1IzoKHiwXe.replace(s149dk8uh2p7oFzaLxZeI3Or(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨẴ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẵ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	d8C14ZjXT2xRFbJpVOMkgvihaPys(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	if not sxzI2flt78kGXZr: return
	if A6Sg45ChDR3BJLYfFH(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪẶ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		mwOxEyYAg63B(rDG9dZoXRhCJcieUSF0KB(u"ࠩࡩࡳࡱࡪࡥࡳࠩặ"),dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪ࡟ࠬẸ")+JegF7SlMawI03+PeOluiBMAF82rphksGHEvc+AAByQSLgaZwCsKnvc5eWNmY+DpRJnas65uVcO0S17dYG(u"ࠫࠥࡀวๅไึ้ࡢ࠭ẹ"),PeOluiBMAF82rphksGHEvc,weh7SGmuTgXOVRcMo1rlLq(u"࠳࠹࠺ὦ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẺ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
		mwOxEyYAg63B(erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẻ"),weh7SGmuTgXOVRcMo1rlLq(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭Ẽ"),PeOluiBMAF82rphksGHEvc,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠴࠺࠻ὧ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẽ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
		mwOxEyYAg63B(TNw1pBHb8CtSZe0EFxuJqI(u"ࠩ࡯࡭ࡳࡱࠧẾ"),JegF7SlMawI03+fmkZtbRj3ux(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨế")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠽࠾࠿࠹Ὠ"))
	for website in sorted(list(sxzI2flt78kGXZr[PeOluiBMAF82rphksGHEvc].keys())):
		TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = sxzI2flt78kGXZr[PeOluiBMAF82rphksGHEvc][website]
		if rDG9dZoXRhCJcieUSF0KB(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ề") in hg4F23dunEM56UpCOBk1IzoKHiwXe or len(sxzI2flt78kGXZr[PeOluiBMAF82rphksGHEvc])==UD4N8MjVTd:
			DQ2dIilnTb4BVuMzgh(TAlYNXgaM4qzdtVUZKiubvs,wUvcPrYDfISbZolAm83GKEqMyXkn5,url,kGBjVWPhaFYEHg7AI81,wUvcPrYDfISbZolAm83GKEqMyXkn5,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			TTuO14NzmB.menuItemsLIST[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
			z2fdMC3QlYO5ar1W0sq,KCN5dJHLyWQ7vpc1btgsEwfYi2e = TTuO14NzmB.menuItemsLIST[:MMRBkhnWVJCQwU],TTuO14NzmB.menuItemsLIST[MMRBkhnWVJCQwU:]
			if SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧề") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
				for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(erqDsJmL3BQHuGtPkcf0X9(u"࠾Ὡ")): kItsbxAFUXc3.shuffle(KCN5dJHLyWQ7vpc1btgsEwfYi2e)
				TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e[:aaY7B0Pbr1y9JUQ3InkEpSMflHFWe]
			else: TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e
		elif MFhbWia58mP3su0fk2d(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧỂ") in hg4F23dunEM56UpCOBk1IzoKHiwXe: mwOxEyYAg63B(fmkZtbRj3ux(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧể"),website,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
	return
def gpmiW3zk1x4AdnY(hg4F23dunEM56UpCOBk1IzoKHiwXe,ooPMZSnrRDG6xNpJHVmgw8IOA1):
	hg4F23dunEM56UpCOBk1IzoKHiwXe = hg4F23dunEM56UpCOBk1IzoKHiwXe.replace(w8JC1y7Lp3(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỄ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(bQGafNLXyFgsZP6ut(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ễ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	LcukPqj3x6f9WDZQh5YJzg,KCN5dJHLyWQ7vpc1btgsEwfYi2e = wUvcPrYDfISbZolAm83GKEqMyXkn5,[]
	mwOxEyYAg63B(TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡪࡴࡲࡤࡦࡴࠪỆ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡠ࠭ệ")+JegF7SlMawI03+LcukPqj3x6f9WDZQh5YJzg+AAByQSLgaZwCsKnvc5eWNmY+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧỈ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,ooPMZSnrRDG6xNpJHVmgw8IOA1,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỉ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
	mwOxEyYAg63B(A6Sg45ChDR3BJLYfFH(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỊ"),A6Sg45ChDR3BJLYfFH(u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨị"),wUvcPrYDfISbZolAm83GKEqMyXkn5,ooPMZSnrRDG6xNpJHVmgw8IOA1,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,DpRJnas65uVcO0S17dYG(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧỌ")+hg4F23dunEM56UpCOBk1IzoKHiwXe)
	mwOxEyYAg63B(xdSThjYnuHXAU6M(u"ࠪࡰ࡮ࡴ࡫ࠨọ"),JegF7SlMawI03+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩỎ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠿࠹࠺࠻Ὢ"))
	z2fdMC3QlYO5ar1W0sq = TTuO14NzmB.menuItemsLIST[:]
	TTuO14NzmB.menuItemsLIST[:] = []
	RCmHBOKtejQ8lu4L = []
	if dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭ỏ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		d8C14ZjXT2xRFbJpVOMkgvihaPys(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		if not sxzI2flt78kGXZr: return
		BXYR5yFOCZ = list(sxzI2flt78kGXZr.keys())
		PeOluiBMAF82rphksGHEvc = kItsbxAFUXc3.sample(BXYR5yFOCZ,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		I8RHEAqYxcmNrdQFgp7taPZJhvs = list(sxzI2flt78kGXZr[PeOluiBMAF82rphksGHEvc].keys())
		website = kItsbxAFUXc3.sample(I8RHEAqYxcmNrdQFgp7taPZJhvs,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = sxzI2flt78kGXZr[PeOluiBMAF82rphksGHEvc][website]
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+kPCxIUZb1V(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩỐ")+website+MFhbWia58mP3su0fk2d(u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪố")+LcukPqj3x6f9WDZQh5YJzg+kPCxIUZb1V(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪỒ")+url+DpRJnas65uVcO0S17dYG(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬồ")+str(kGBjVWPhaFYEHg7AI81))
	elif lCT8hfYUBX4OQMmL(u"ࠪࡣࡎࡖࡔࡗࡡࠪỔ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		import lFWVNcqCio
		if not lFWVNcqCio.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
			RCmHBOKtejQ8lu4L += Foq6xbQOeLcKBPzu(str(Be4AsSL71xyhHNQYV2wdvJ),hg4F23dunEM56UpCOBk1IzoKHiwXe)
		if not RCmHBOKtejQ8lu4L: return
		TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = kItsbxAFUXc3.sample(RCmHBOKtejQ8lu4L,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫổ")+LcukPqj3x6f9WDZQh5YJzg+lCT8hfYUBX4OQMmL(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧỖ")+url+xm6jK1ZMuWq5(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỗ")+str(kGBjVWPhaFYEHg7AI81))
	elif xdSThjYnuHXAU6M(u"ࠧࡠࡏ࠶࡙ࡤ࠭Ộ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		import L7lMpnYoUi
		if not L7lMpnYoUi.lu7ViXewzT4jtDacZKNnF2(wUvcPrYDfISbZolAm83GKEqMyXkn5,y0yvdNOZkiKEg5RLMhoDVQAB9F2): return
		for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
			RCmHBOKtejQ8lu4L += iuCEk1znoSe7VrY4IRMTWQ0F(str(Be4AsSL71xyhHNQYV2wdvJ),hg4F23dunEM56UpCOBk1IzoKHiwXe)
		if not RCmHBOKtejQ8lu4L: return
		TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = kItsbxAFUXc3.sample(RCmHBOKtejQ8lu4L,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+w8JC1y7Lp3(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨộ")+LcukPqj3x6f9WDZQh5YJzg+it4DKnryZlx(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫỚ")+url+rDG9dZoXRhCJcieUSF0KB(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ớ")+str(kGBjVWPhaFYEHg7AI81))
	aiWvFd1srZMhm9gG7cK = LcukPqj3x6f9WDZQh5YJzg
	PR0wyv96khINbzOFSg7GrjAf = []
	for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(wTLFCOcM26fmYlW7U,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠱࠱Ὣ")):
		if kkLhJCU4MQSx7s6gyeOHrRYKtnP3>wTLFCOcM26fmYlW7U: KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+llkFwuCyhaP3sK76qO4T(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫỜ")+LcukPqj3x6f9WDZQh5YJzg+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧờ")+url+JHMxIE4fs1mvQtKW7R(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỞ")+str(kGBjVWPhaFYEHg7AI81))
		TTuO14NzmB.menuItemsLIST[:] = []
		if kGBjVWPhaFYEHg7AI81==Gj3rMP1Cb8wHdp49la0(u"࠳࠵࠷Ὤ") and ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨở") in eIRJAgj25bzvNik48puZl3OPUq: kGBjVWPhaFYEHg7AI81 = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠴࠶࠷Ὥ")
		if kGBjVWPhaFYEHg7AI81==yRWQMHxZEz0(u"࠺࠵࠹Ὦ") and jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨỠ") in eIRJAgj25bzvNik48puZl3OPUq: kGBjVWPhaFYEHg7AI81 = bQGafNLXyFgsZP6ut(u"࠻࠶࠹Ὧ")
		if kGBjVWPhaFYEHg7AI81==xm6jK1ZMuWq5(u"࠶࠺࠴ὰ"): kGBjVWPhaFYEHg7AI81 = bQGafNLXyFgsZP6ut(u"࠸࠹࠲ά")
		vziHL4xVFSD81W7X9Noyrdjb = DQ2dIilnTb4BVuMzgh(TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
		if MFhbWia58mP3su0fk2d(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩỡ") in hg4F23dunEM56UpCOBk1IzoKHiwXe and kGBjVWPhaFYEHg7AI81==A6Sg45ChDR3BJLYfFH(u"࠱࠷࠹ὲ"): del TTuO14NzmB.menuItemsLIST[:MMRBkhnWVJCQwU]
		if D2PpKMeZFWrmfxTSs4L1tz(u"ࠪࡣࡒ࠹ࡕࡠࠩỢ") in hg4F23dunEM56UpCOBk1IzoKHiwXe and kGBjVWPhaFYEHg7AI81==fmkZtbRj3ux(u"࠲࠸࠻έ"): del TTuO14NzmB.menuItemsLIST[:MMRBkhnWVJCQwU]
		KCN5dJHLyWQ7vpc1btgsEwfYi2e[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
		if PR0wyv96khINbzOFSg7GrjAf and rg5W67jZQdSPH0(VhqD3zp7mUieI8sMQlETH(u"ࡹࠬำไใหࠪợ")) in str(KCN5dJHLyWQ7vpc1btgsEwfYi2e) or rg5W67jZQdSPH0(yRWQMHxZEz0(u"ࡺ࠭อๅไ๊ࠫỤ")) in str(KCN5dJHLyWQ7vpc1btgsEwfYi2e):
			LcukPqj3x6f9WDZQh5YJzg = aiWvFd1srZMhm9gG7cK
			KCN5dJHLyWQ7vpc1btgsEwfYi2e[:] = PR0wyv96khINbzOFSg7GrjAf
			break
		aiWvFd1srZMhm9gG7cK = LcukPqj3x6f9WDZQh5YJzg
		PR0wyv96khINbzOFSg7GrjAf = KCN5dJHLyWQ7vpc1btgsEwfYi2e
		if str(KCN5dJHLyWQ7vpc1btgsEwfYi2e).count(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡶࡪࡦࡨࡳࠬụ"))>wTLFCOcM26fmYlW7U: break
		if str(KCN5dJHLyWQ7vpc1btgsEwfYi2e).count(jQv0du1iVxTgAXCM(u"ࠧ࡭࡫ࡹࡩࠬỦ"))>wTLFCOcM26fmYlW7U: break
		if kGBjVWPhaFYEHg7AI81==MFhbWia58mP3su0fk2d(u"࠴࠶࠷ὴ"): break
		if kGBjVWPhaFYEHg7AI81==jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠺࠵࠸ή"): break
		if kGBjVWPhaFYEHg7AI81==lCT8hfYUBX4OQMmL(u"࠶࠾࠷ὶ"): break
		if jQv0du1iVxTgAXCM(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪủ") in hg4F23dunEM56UpCOBk1IzoKHiwXe and KCN5dJHLyWQ7vpc1btgsEwfYi2e: TAlYNXgaM4qzdtVUZKiubvs,LcukPqj3x6f9WDZQh5YJzg,url,kGBjVWPhaFYEHg7AI81,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = kItsbxAFUXc3.sample(KCN5dJHLyWQ7vpc1btgsEwfYi2e,UD4N8MjVTd)[wTLFCOcM26fmYlW7U]
	if not LcukPqj3x6f9WDZQh5YJzg: LcukPqj3x6f9WDZQh5YJzg = A6Sg45ChDR3BJLYfFH(u"ࠩ࠱࠲࠳࠴ࠧỨ")
	elif LcukPqj3x6f9WDZQh5YJzg.count(JHMxIE4fs1mvQtKW7R(u"ࠪࡣࠬứ"))>UD4N8MjVTd: LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.split(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡤ࠭Ừ"),Tb7oymMnpflsSv3eu4Pz2)[Tb7oymMnpflsSv3eu4Pz2]
	LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(vvhR5ozeiJpANyl8fFO3GBw(u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨừ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	LcukPqj3x6f9WDZQh5YJzg = LcukPqj3x6f9WDZQh5YJzg.replace(vvhR5ozeiJpANyl8fFO3GBw(u"࠭࡟ࡎࡑࡇࡣࠬỬ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	z2fdMC3QlYO5ar1W0sq[wTLFCOcM26fmYlW7U][UD4N8MjVTd] = jQv0du1iVxTgAXCM(u"ࠧ࡜ࠩử")+JegF7SlMawI03+LcukPqj3x6f9WDZQh5YJzg+AAByQSLgaZwCsKnvc5eWNmY+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪỮ")
	if A6Sg45ChDR3BJLYfFH(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫữ") in hg4F23dunEM56UpCOBk1IzoKHiwXe:
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(lCT8hfYUBX4OQMmL(u"࠾ί")): kItsbxAFUXc3.shuffle(KCN5dJHLyWQ7vpc1btgsEwfYi2e)
		TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e[:aaY7B0Pbr1y9JUQ3InkEpSMflHFWe]
	else: TTuO14NzmB.menuItemsLIST[:] = z2fdMC3QlYO5ar1W0sq+KCN5dJHLyWQ7vpc1btgsEwfYi2e
	return
def Z4uXjYL6Bh(CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG):
	IclhT46b3w8fqgrMjBG = IclhT46b3w8fqgrMjBG.replace(lCT8hfYUBX4OQMmL(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬỰ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨự"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	zzteuPQcVWYTBviK2pyHmgOCf = IclhT46b3w8fqgrMjBG
	if weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ỳ") in IclhT46b3w8fqgrMjBG:
		zzteuPQcVWYTBviK2pyHmgOCf = IclhT46b3w8fqgrMjBG.split(yRWQMHxZEz0(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧỳ"))[wTLFCOcM26fmYlW7U]
		type = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪỴ")
	elif Gj3rMP1Cb8wHdp49la0(u"ࠨࡘࡒࡈࠬỵ") in CPSJlzbHcvUV2aLoFDEhik8fMTAe: type = JHMxIE4fs1mvQtKW7R(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬỶ")
	elif Gj3rMP1Cb8wHdp49la0(u"ࠪࡐࡎ࡜ࡅࠨỷ") in CPSJlzbHcvUV2aLoFDEhik8fMTAe: type = MFhbWia58mP3su0fk2d(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬỸ")
	mwOxEyYAg63B(erqDsJmL3BQHuGtPkcf0X9(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỹ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࡛࠭ࠨỺ")+JegF7SlMawI03+type+zzteuPQcVWYTBviK2pyHmgOCf+AAByQSLgaZwCsKnvc5eWNmY+w8JC1y7Lp3(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩỻ"),CPSJlzbHcvUV2aLoFDEhik8fMTAe,xdSThjYnuHXAU6M(u"࠷࠶࠸ὸ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ỽ")+IclhT46b3w8fqgrMjBG)
	mwOxEyYAg63B(fmkZtbRj3ux(u"ࠩࡩࡳࡱࡪࡥࡳࠩỽ"),kPCxIUZb1V(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩỾ"),CPSJlzbHcvUV2aLoFDEhik8fMTAe,xm6jK1ZMuWq5(u"࠱࠷࠹ό"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩỿ")+IclhT46b3w8fqgrMjBG)
	mwOxEyYAg63B(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡲࡩ࡯࡭ࠪἀ"),JegF7SlMawI03+s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫἁ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,llkFwuCyhaP3sK76qO4T(u"࠺࠻࠼࠽ὺ"))
	import lFWVNcqCio
	for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
		if llkFwuCyhaP3sK76qO4T(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἂ") in IclhT46b3w8fqgrMjBG: lFWVNcqCio.GxgaJFV3ejs6vlt(str(Be4AsSL71xyhHNQYV2wdvJ),CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		else: lFWVNcqCio.UUOhG6SD19FL2AztHln3uT4Xg5d8f(str(Be4AsSL71xyhHNQYV2wdvJ),CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	TTuO14NzmB.menuItemsLIST[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
	if len(TTuO14NzmB.menuItemsLIST)>(aaY7B0Pbr1y9JUQ3InkEpSMflHFWe+MMRBkhnWVJCQwU): TTuO14NzmB.menuItemsLIST[:] = TTuO14NzmB.menuItemsLIST[:MMRBkhnWVJCQwU]+kItsbxAFUXc3.sample(TTuO14NzmB.menuItemsLIST[MMRBkhnWVJCQwU:],aaY7B0Pbr1y9JUQ3InkEpSMflHFWe)
	return
def D42seT8uXwtpJ15McHE(CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG):
	IclhT46b3w8fqgrMjBG = IclhT46b3w8fqgrMjBG.replace(TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪἃ"),wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(VhqD3zp7mUieI8sMQlETH(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἄ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	zzteuPQcVWYTBviK2pyHmgOCf = IclhT46b3w8fqgrMjBG
	if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪἅ") in IclhT46b3w8fqgrMjBG:
		zzteuPQcVWYTBviK2pyHmgOCf = IclhT46b3w8fqgrMjBG.split(VhqD3zp7mUieI8sMQlETH(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἆ"))[wTLFCOcM26fmYlW7U]
		type = dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨἇ")
	elif JHMxIE4fs1mvQtKW7R(u"࠭ࡖࡐࡆࠪἈ") in CPSJlzbHcvUV2aLoFDEhik8fMTAe: type = yRWQMHxZEz0(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪἉ")
	elif weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡎࡌ࡚ࡊ࠭Ἂ") in CPSJlzbHcvUV2aLoFDEhik8fMTAe: type = weh7SGmuTgXOVRcMo1rlLq(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪἋ")
	mwOxEyYAg63B(JHMxIE4fs1mvQtKW7R(u"ࠪࡪࡴࡲࡤࡦࡴࠪἌ"),JHMxIE4fs1mvQtKW7R(u"ࠫࡠ࠭Ἅ")+JegF7SlMawI03+type+zzteuPQcVWYTBviK2pyHmgOCf+AAByQSLgaZwCsKnvc5eWNmY+jQv0du1iVxTgAXCM(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧἎ"),CPSJlzbHcvUV2aLoFDEhik8fMTAe,yRWQMHxZEz0(u"࠳࠹࠼ύ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,A6Sg45ChDR3BJLYfFH(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἏ")+IclhT46b3w8fqgrMjBG)
	mwOxEyYAg63B(MFhbWia58mP3su0fk2d(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἐ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧἑ"),CPSJlzbHcvUV2aLoFDEhik8fMTAe,w8JC1y7Lp3(u"࠴࠺࠽ὼ"),wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,jQv0du1iVxTgAXCM(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἒ")+IclhT46b3w8fqgrMjBG)
	mwOxEyYAg63B(w8JC1y7Lp3(u"ࠪࡰ࡮ࡴ࡫ࠨἓ"),JegF7SlMawI03+it4DKnryZlx(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩἔ")+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠽࠾࠿࠹ώ"))
	import L7lMpnYoUi
	for Be4AsSL71xyhHNQYV2wdvJ in range(UD4N8MjVTd,ZwUoEtfGv7J6+UD4N8MjVTd):
		if TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬἕ") in IclhT46b3w8fqgrMjBG: L7lMpnYoUi.GxgaJFV3ejs6vlt(str(Be4AsSL71xyhHNQYV2wdvJ),CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		else: L7lMpnYoUi.UUOhG6SD19FL2AztHln3uT4Xg5d8f(str(Be4AsSL71xyhHNQYV2wdvJ),CPSJlzbHcvUV2aLoFDEhik8fMTAe,IclhT46b3w8fqgrMjBG,wUvcPrYDfISbZolAm83GKEqMyXkn5,Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	TTuO14NzmB.menuItemsLIST[:] = rApvZa4l6UI3LCDKunz7S1eG(TTuO14NzmB.menuItemsLIST)
	if len(TTuO14NzmB.menuItemsLIST)>(aaY7B0Pbr1y9JUQ3InkEpSMflHFWe+MMRBkhnWVJCQwU): TTuO14NzmB.menuItemsLIST[:] = TTuO14NzmB.menuItemsLIST[:MMRBkhnWVJCQwU]+kItsbxAFUXc3.sample(TTuO14NzmB.menuItemsLIST[MMRBkhnWVJCQwU:],aaY7B0Pbr1y9JUQ3InkEpSMflHFWe)
	return
def rApvZa4l6UI3LCDKunz7S1eG(lac7beyr8WdKGL4P6CAXgiV):
	pI3CtcE0F5unRJUwWjrSVbzkf9qDsM = []
	for type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ in lac7beyr8WdKGL4P6CAXgiV:
		if rDG9dZoXRhCJcieUSF0KB(u"࠭ีโฯฬࠫ἖") in LcukPqj3x6f9WDZQh5YJzg or rDG9dZoXRhCJcieUSF0KB(u"ࠧึใะ๋ࠬ἗") in LcukPqj3x6f9WDZQh5YJzg or bQGafNLXyFgsZP6ut(u"ࠨࡲࡤ࡫ࡪ࠭Ἐ") in LcukPqj3x6f9WDZQh5YJzg.lower(): continue
		pI3CtcE0F5unRJUwWjrSVbzkf9qDsM.append([type,LcukPqj3x6f9WDZQh5YJzg,url,ooPMZSnrRDG6xNpJHVmgw8IOA1,mnWZN7g50M,sbNukjOf4chz,eIRJAgj25bzvNik48puZl3OPUq,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ])
	return pI3CtcE0F5unRJUwWjrSVbzkf9qDsM