# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
beQiZS9WP3z6gdHy75FMvfpDr = 'IPTV'
ANaRC3c914UdxDrFM = '_IPT_'
RRPFLpAv60TUIVoniqXjCbzmKY = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def IaWOxy5cEw(ooPMZSnrRDG6xNpJHVmgw8IOA1,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq,TAlYNXgaM4qzdtVUZKiubvs,G02Gb6uxEgT39wNCJvefMzmFI,RG73XpOfASe6WT25jsEQxPq4wLr):
	global ANaRC3c914UdxDrFM
	try:
		HAoXLCq8rFjsaPelxNuV = str(RG73XpOfASe6WT25jsEQxPq4wLr['folder'])
		ANaRC3c914UdxDrFM = '_IP'+HAoXLCq8rFjsaPelxNuV+'_'
	except: HAoXLCq8rFjsaPelxNuV = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if   ooPMZSnrRDG6xNpJHVmgw8IOA1==230: lKT2nBXgyoJcN8m4 = FjEdGzo0ki21Wbm6JnhxlcuvZL()
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==231: lKT2nBXgyoJcN8m4 = BZ8sYcn1yxSe9fqTbmjM2lE(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==232: lKT2nBXgyoJcN8m4 = bom0X7rWaqsPEzf(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==233: lKT2nBXgyoJcN8m4 = GxgaJFV3ejs6vlt(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq,G02Gb6uxEgT39wNCJvefMzmFI)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==234: lKT2nBXgyoJcN8m4 = UUOhG6SD19FL2AztHln3uT4Xg5d8f(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq,G02Gb6uxEgT39wNCJvefMzmFI)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==235: lKT2nBXgyoJcN8m4 = lHcaGxFV0wy9UrN7Cv6o5dInLQ(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,TAlYNXgaM4qzdtVUZKiubvs)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==236: lKT2nBXgyoJcN8m4 = oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,True)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==237: lKT2nBXgyoJcN8m4 = MMtqGunbXfZDNcQvmH(HAoXLCq8rFjsaPelxNuV,True)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==238: lKT2nBXgyoJcN8m4 = JrG8cwX0bZQC3mEnA4(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==239: lKT2nBXgyoJcN8m4 = zxTXK1GQm2WUob7AcwCIB0tfS5jNPy(eIRJAgj25bzvNik48puZl3OPUq,HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,G02Gb6uxEgT39wNCJvefMzmFI)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==280: lKT2nBXgyoJcN8m4 = AAMk21ZpiCQ7jImw0fzR5UuG(HAoXLCq8rFjsaPelxNuV,True)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==281: lKT2nBXgyoJcN8m4 = nn5LrYGPyxcTUMlgEZjVzAINahFmSQ(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==282: lKT2nBXgyoJcN8m4 = BkbhctLC81aRx43IDO5jueKYT(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==283: lKT2nBXgyoJcN8m4 = CXIZzoLy4cxeK8(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==285: lKT2nBXgyoJcN8m4 = yH4AvMncjt17xu0GCsL59zQFD(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,eIRJAgj25bzvNik48puZl3OPUq)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==286: lKT2nBXgyoJcN8m4 = X3XyGxV5ELjimuWHgM(HAoXLCq8rFjsaPelxNuV)
	elif ooPMZSnrRDG6xNpJHVmgw8IOA1==289: lKT2nBXgyoJcN8m4 = o93oeyjBgAdiDGNu1ZkJm5XbKn6q(eIRJAgj25bzvNik48puZl3OPUq,HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,G02Gb6uxEgT39wNCJvefMzmFI)
	else: lKT2nBXgyoJcN8m4 = False
	return lKT2nBXgyoJcN8m4
def FjEdGzo0ki21Wbm6JnhxlcuvZL():
	for HAoXLCq8rFjsaPelxNuV in range(1,ZwUoEtfGv7J6+1):
		ANaRC3c914UdxDrFM = '_IP'+str(HAoXLCq8rFjsaPelxNuV)+'_'
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قائمة مجلد '+HiqZ1R8GXDtUzSu[HAoXLCq8rFjsaPelxNuV],wUvcPrYDfISbZolAm83GKEqMyXkn5,280,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	return
def AAMk21ZpiCQ7jImw0fzR5UuG(HAoXLCq8rFjsaPelxNuV=wUvcPrYDfISbZolAm83GKEqMyXkn5,nOwDh0x3sa4FilJCPrWAI2=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if HAoXLCq8rFjsaPelxNuV:
		YoKTOwMI69kDFlEBXri0qLyxNjsng = {'folder':HAoXLCq8rFjsaPelxNuV}
		JEy25ozwY3qhlUP7msWMTH1ktB0NcS = wUvcPrYDfISbZolAm83GKEqMyXkn5
	else:
		YoKTOwMI69kDFlEBXri0qLyxNjsng = wUvcPrYDfISbZolAm83GKEqMyXkn5
		JEy25ozwY3qhlUP7msWMTH1ktB0NcS = wUvcPrYDfISbZolAm83GKEqMyXkn5
	CEXN1j4sDK0FZVuM5vQ = lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2)
	if not CEXN1j4sDK0FZVuM5vQ:
		mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+' إضافة أو تغيير اشتراك'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS+' '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,231,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+' جلب ملفات'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS+' '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,232,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	else:
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'بحث في الملفات'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,289,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_',wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مصنفة مرتبة'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مصنفة من القسم'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_FROM_GROUP_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مصنفة من الاسم'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_FROM_NAME_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مصنفة بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_ORIGINAL_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مجهولة مرتبة'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_UNKNOWN_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'قنوات مجهولة بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_UNKNOWN_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أفلام مصنفة بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_MOVIES_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أفلام مصنفة مرتبة'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_MOVIES_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'مسلسلات مصنفة بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_SERIES_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'مسلسلات مصنفة مرتبة'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_SERIES_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'فيديوهات بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_ORIGINAL_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'فيديوهات مصنفة من القسم'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_FROM_GROUP_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'فيديوهات مصنفة من الاسم'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_FROM_NAME_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'فيديوهات مجهولة بلا ترتيب'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_UNKNOWN_GROUPED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'فيديوهات مجهولة مرتبة'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'VOD_UNKNOWN_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'برامج القنوات (جدول فقط)'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_EPG_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أرشيف القنوات للأيام الماضية'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_TIMESHIFT_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أرشيف برامج القنوات للأيام الماضية'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,'LIVE_ARCHIVED_GROUPED_SORTED',233,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'إضافة أو تغيير اشتراك'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,231,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'جلب ملفات'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,232,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'مسح ملفات'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,237,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'فحص اشتراك'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,236,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'عدد فيديوهات'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,281,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'Referer تغيير'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,286,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'User-Agent تغيير'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,283,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+'استخدم السيرفر الأسرع'+JEy25ozwY3qhlUP7msWMTH1ktB0NcS,wUvcPrYDfISbZolAm83GKEqMyXkn5,282,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,YoKTOwMI69kDFlEBXri0qLyxNjsng)
	return
def oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2=True):
	k34A0NYJIZC7wgHxnPGycofUvWRVE,kBTaqKiyIl54DAg = False,wUvcPrYDfISbZolAm83GKEqMyXkn5
	qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd = Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV)
	if uW9I6hGBzEbNprvYJ50MQHR==wUvcPrYDfISbZolAm83GKEqMyXkn5: return False,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	DDPMgjZIuk = maZGulCg9DRBrYW4HM1tjk6L3(HAoXLCq8rFjsaPelxNuV)
	if p8bzkQ1hP6aUjrRC3DMi:
		yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,'GET',p8bzkQ1hP6aUjrRC3DMi,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,False,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-CHECK_ACCOUNT-1st')
		V6aTvut7ocyb = yBn638aQbxUdpCSA.content
		if yBn638aQbxUdpCSA.succeeded:
			W7WwUJs382HDpKaFPtbB,dpHAUi6sPKOxofM4,GGgy9OYqBAtr,e2jwbypQYIX3,CX7ZINO4Vk3ML5a = 0,0,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
			try:
				YNa9V4WUOHqgoX = dm7KA8MukvxF3iH9CW2ZNc('dict',V6aTvut7ocyb)
				kBTaqKiyIl54DAg = YNa9V4WUOHqgoX['user_info']['status']
				k34A0NYJIZC7wgHxnPGycofUvWRVE = True
				GGgy9OYqBAtr = YNa9V4WUOHqgoX['server_info']['time_now']
			except: pass
			if GGgy9OYqBAtr:
				try:
					rDTIHO4tR3kJXaljG8M5 = L5jXH0fZ8TvsESR.strptime(GGgy9OYqBAtr,'%Y.%m.%d %H:%M:%S')
					W7WwUJs382HDpKaFPtbB = int(L5jXH0fZ8TvsESR.mktime(rDTIHO4tR3kJXaljG8M5))
					dpHAUi6sPKOxofM4 = int(yoJ7t3WpjPkrCmTq-W7WwUJs382HDpKaFPtbB)
					dpHAUi6sPKOxofM4 = int((dpHAUi6sPKOxofM4+900)/1800)*1800
				except: pass
				try:
					rDTIHO4tR3kJXaljG8M5 = L5jXH0fZ8TvsESR.localtime(int(YNa9V4WUOHqgoX['user_info']['created_at']))
					e2jwbypQYIX3 = L5jXH0fZ8TvsESR.strftime('%Y.%m.%d %H:%M:%S',rDTIHO4tR3kJXaljG8M5)
				except: pass
				try:
					rDTIHO4tR3kJXaljG8M5 = L5jXH0fZ8TvsESR.localtime(int(YNa9V4WUOHqgoX['user_info']['exp_date']))
					CX7ZINO4Vk3ML5a = L5jXH0fZ8TvsESR.strftime('%Y.%m.%d %H:%M:%S',rDTIHO4tR3kJXaljG8M5)
				except: pass
			OOnvcPQy85HYA.setSetting('av.iptv.timestamp_'+HAoXLCq8rFjsaPelxNuV,str(yoJ7t3WpjPkrCmTq))
			OOnvcPQy85HYA.setSetting('av.iptv.timediff_'+HAoXLCq8rFjsaPelxNuV,str(dpHAUi6sPKOxofM4))
			try:
				eoj9RE7CmKXTYa = '"server_info":'+V6aTvut7ocyb.split('"server_info":')[1]
				eoj9RE7CmKXTYa = eoj9RE7CmKXTYa.replace(':',': ').replace(',',', ').replace('}}','}')
				ajix0Wy39RlwArb8Jt7CuPSOznp = jj0dZrgiKb.findall('"url": "(.*?)", "port": "(.*?)"',eoj9RE7CmKXTYa,jj0dZrgiKb.DOTALL)
				qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = ajix0Wy39RlwArb8Jt7CuPSOznp[0]
			except: k34A0NYJIZC7wgHxnPGycofUvWRVE = False
			if k34A0NYJIZC7wgHxnPGycofUvWRVE and nOwDh0x3sa4FilJCPrWAI2:
				max = YNa9V4WUOHqgoX['user_info']['max_connections']
				MB3UkiAacgfdG4YhL8pIuZejw = YNa9V4WUOHqgoX['user_info']['active_cons']
				meTV4p2CZgUlkM8GzXJEnBq03i = YNa9V4WUOHqgoX['user_info']['is_trial']
				UcXEosrDlpW = p8bzkQ1hP6aUjrRC3DMi.split('?',1)
				SLAiUwpDRoZIQfvB7 = 'URL:  '+JegF7SlMawI03+p8bzkQ1hP6aUjrRC3DMi+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\n\nStatus:  '+JegF7SlMawI03+kBTaqKiyIl54DAg+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\nTrial:    '+JegF7SlMawI03+str(meTV4p2CZgUlkM8GzXJEnBq03i=='1')+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\nCreated  At:  '+JegF7SlMawI03+e2jwbypQYIX3+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\nExpiry Date:  '+JegF7SlMawI03+CX7ZINO4Vk3ML5a+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\nConnections   ( Active / Maximum ) :  '+JegF7SlMawI03+MB3UkiAacgfdG4YhL8pIuZejw+' / '+max+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\nAllowed Outputs:   '+JegF7SlMawI03+" , ".join(YNa9V4WUOHqgoX['user_info']['allowed_output_formats'])+AAByQSLgaZwCsKnvc5eWNmY
				SLAiUwpDRoZIQfvB7 += '\n\n'+eoj9RE7CmKXTYa
				if kBTaqKiyIl54DAg=='Active': XODdc0rwio9amnFLuIkjRsZ('الاشتراك يعمل بدون مشاكل',SLAiUwpDRoZIQfvB7)
				else: XODdc0rwio9amnFLuIkjRsZ('يبدو أن هناك مشكلة في الاشتراك',SLAiUwpDRoZIQfvB7)
	if p8bzkQ1hP6aUjrRC3DMi and k34A0NYJIZC7wgHxnPGycofUvWRVE and kBTaqKiyIl54DAg=='Active':
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+p8bzkQ1hP6aUjrRC3DMi+' ]')
		J2pEvZCUlm3ugNMk0GATB6hc4wK1 = True
	else:
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,'Checking IPTV URL   [ Does not work ]   [ '+p8bzkQ1hP6aUjrRC3DMi+' ]')
		if nOwDh0x3sa4FilJCPrWAI2: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		J2pEvZCUlm3ugNMk0GATB6hc4wK1 = False
	return J2pEvZCUlm3ugNMk0GATB6hc4wK1,qqp5cKaiRw6jlkN,gdTyD1O4nAsESM
def UUOhG6SD19FL2AztHln3uT4Xg5d8f(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1,n2b8tFjHw9Q,JhbEGQTfy9tH2nRzWO5eKAucIa,nOwDh0x3sa4FilJCPrWAI2=True):
	if not JhbEGQTfy9tH2nRzWO5eKAucIa: JhbEGQTfy9tH2nRzWO5eKAucIa = '1'
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2): return
	rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1)
	rm2P4OqXgZJzeuTdicbl6xH7tU = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list',BpAlbchoSTDu1,n2b8tFjHw9Q)
	HZEKtskx5QPl8 = int(JhbEGQTfy9tH2nRzWO5eKAucIa)*100
	r0VEF9YnpIZq4ao37lPB12SGKN = HZEKtskx5QPl8-100
	for QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in rm2P4OqXgZJzeuTdicbl6xH7tU[r0VEF9YnpIZq4ao37lPB12SGKN:HZEKtskx5QPl8]:
		baRLnWg1Yr56mu0KH = ('GROUPED' in BpAlbchoSTDu1 or BpAlbchoSTDu1=='ALL')
		Ftwnbv3CipUfB8lzAL9hPJIyE = ('GROUPED' not in BpAlbchoSTDu1 and BpAlbchoSTDu1!='ALL')
		if baRLnWg1Yr56mu0KH or Ftwnbv3CipUfB8lzAL9hPJIyE:
			if   'ARCHIVED'  in BpAlbchoSTDu1: TTuO14NzmB.menuItemsLIST.append(['folder',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,238,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ARCHIVED',wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV}])
			elif 'EPG' 		 in BpAlbchoSTDu1: TTuO14NzmB.menuItemsLIST.append(['folder',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,238,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,'FULL_EPG',wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV}])
			elif 'TIMESHIFT' in BpAlbchoSTDu1: TTuO14NzmB.menuItemsLIST.append(['folder',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,238,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,'TIMESHIFT',wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV}])
			elif 'LIVE' 	 in BpAlbchoSTDu1: TTuO14NzmB.menuItemsLIST.append(['live',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,235,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,{'folder':HAoXLCq8rFjsaPelxNuV}])
			else: TTuO14NzmB.menuItemsLIST.append(['video',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,235,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV}])
	m1AwOzcEFSY = len(rm2P4OqXgZJzeuTdicbl6xH7tU)
	elP8drN1Ati4K(HAoXLCq8rFjsaPelxNuV,JhbEGQTfy9tH2nRzWO5eKAucIa,BpAlbchoSTDu1,234,m1AwOzcEFSY,n2b8tFjHw9Q)
	return
def OOEpWP0r7VgA364iaQNnfR(Lv0yfB58Obr94jk6VCqZUPmTa):
	mwOxEyYAg63B('link',Lv0yfB58Obr94jk6VCqZUPmTa+'هذه القائمة إما فارغة أو غير موجودة',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('link',Lv0yfB58Obr94jk6VCqZUPmTa+'أو الخدمة غير موجودة في اشتراكك',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('link',Lv0yfB58Obr94jk6VCqZUPmTa+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	return
def GxgaJFV3ejs6vlt(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1,n2b8tFjHw9Q,JhbEGQTfy9tH2nRzWO5eKAucIa,KKOWge0xadUmt46uDRT9Nro=wUvcPrYDfISbZolAm83GKEqMyXkn5,nOwDh0x3sa4FilJCPrWAI2=True):
	if not JhbEGQTfy9tH2nRzWO5eKAucIa: JhbEGQTfy9tH2nRzWO5eKAucIa = '1'
	Lv0yfB58Obr94jk6VCqZUPmTa = ANaRC3c914UdxDrFM
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2): return False
	if '__SERIES__' in n2b8tFjHw9Q: Ey09iVNSx4jpgwOhGsWd,p9QcdgOXDn60Y8oLkitjzvmES = n2b8tFjHw9Q.split('__SERIES__')
	else: Ey09iVNSx4jpgwOhGsWd,p9QcdgOXDn60Y8oLkitjzvmES = n2b8tFjHw9Q,wUvcPrYDfISbZolAm83GKEqMyXkn5
	rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1)
	CeVGH9TFE45blsZKjJQmahpN0fi = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list',BpAlbchoSTDu1,'__GROUPS__')
	if not CeVGH9TFE45blsZKjJQmahpN0fi: return False
	ddZE3oXJyncm8sVFgDOzHP = []
	for dlmjGAi0wsYW8Q,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in CeVGH9TFE45blsZKjJQmahpN0fi:
		if KKOWge0xadUmt46uDRT9Nro:
			if '__SERIES__' in dlmjGAi0wsYW8Q: Lv0yfB58Obr94jk6VCqZUPmTa = 'SERIES'
			elif '!!__UNKNOWN__!!' in dlmjGAi0wsYW8Q: Lv0yfB58Obr94jk6VCqZUPmTa = 'UNKNOWN'
			elif 'LIVE' in BpAlbchoSTDu1: Lv0yfB58Obr94jk6VCqZUPmTa = 'LIVE'
			else: Lv0yfB58Obr94jk6VCqZUPmTa = 'VIDEOS'
			Lv0yfB58Obr94jk6VCqZUPmTa = ','+JegF7SlMawI03+Lv0yfB58Obr94jk6VCqZUPmTa+': '+AAByQSLgaZwCsKnvc5eWNmY
		if '__SERIES__' in dlmjGAi0wsYW8Q: PKFauI312LUQnWt6XfD0A,Mfmj4kz8ht = dlmjGAi0wsYW8Q.split('__SERIES__')
		else: PKFauI312LUQnWt6XfD0A,Mfmj4kz8ht = dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5
		if not n2b8tFjHw9Q:
			if PKFauI312LUQnWt6XfD0A in ddZE3oXJyncm8sVFgDOzHP: continue
			ddZE3oXJyncm8sVFgDOzHP.append(PKFauI312LUQnWt6XfD0A)
			if 'RANDOM' in KKOWge0xadUmt46uDRT9Nro: mwOxEyYAg63B('folder',Lv0yfB58Obr94jk6VCqZUPmTa+PKFauI312LUQnWt6XfD0A,BpAlbchoSTDu1,167,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
			elif '__SERIES__' in dlmjGAi0wsYW8Q: mwOxEyYAg63B('folder',Lv0yfB58Obr94jk6VCqZUPmTa+PKFauI312LUQnWt6XfD0A,BpAlbchoSTDu1,233,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
			else: mwOxEyYAg63B('folder',Lv0yfB58Obr94jk6VCqZUPmTa+PKFauI312LUQnWt6XfD0A,BpAlbchoSTDu1,234,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
		elif '__SERIES__' in dlmjGAi0wsYW8Q and PKFauI312LUQnWt6XfD0A==Ey09iVNSx4jpgwOhGsWd:
			if Mfmj4kz8ht in ddZE3oXJyncm8sVFgDOzHP: continue
			ddZE3oXJyncm8sVFgDOzHP.append(Mfmj4kz8ht)
			if 'RANDOM' in KKOWge0xadUmt46uDRT9Nro: mwOxEyYAg63B('folder',Lv0yfB58Obr94jk6VCqZUPmTa+Mfmj4kz8ht,BpAlbchoSTDu1,167,wUvcPrYDfISbZolAm83GKEqMyXkn5,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
			else: mwOxEyYAg63B('folder',Lv0yfB58Obr94jk6VCqZUPmTa+Mfmj4kz8ht,BpAlbchoSTDu1,234,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	TTuO14NzmB.menuItemsLIST[:] = sorted(TTuO14NzmB.menuItemsLIST,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV[1].lower())
	if not KKOWge0xadUmt46uDRT9Nro:
		HZEKtskx5QPl8 = int(JhbEGQTfy9tH2nRzWO5eKAucIa)*100
		r0VEF9YnpIZq4ao37lPB12SGKN = HZEKtskx5QPl8-100
		m1AwOzcEFSY = len(TTuO14NzmB.menuItemsLIST)
		TTuO14NzmB.menuItemsLIST[:] = TTuO14NzmB.menuItemsLIST[r0VEF9YnpIZq4ao37lPB12SGKN:HZEKtskx5QPl8]
		elP8drN1Ati4K(HAoXLCq8rFjsaPelxNuV,JhbEGQTfy9tH2nRzWO5eKAucIa,BpAlbchoSTDu1,233,m1AwOzcEFSY,n2b8tFjHw9Q)
	return True
def JrG8cwX0bZQC3mEnA4(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,J3ubnMHdaTGyXlDqKVWcieBf2poU):
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,True): return
	DDPMgjZIuk = maZGulCg9DRBrYW4HM1tjk6L3(HAoXLCq8rFjsaPelxNuV)
	W7WwUJs382HDpKaFPtbB = OOnvcPQy85HYA.getSetting('av.iptv.timestamp_'+HAoXLCq8rFjsaPelxNuV)
	if not W7WwUJs382HDpKaFPtbB or yoJ7t3WpjPkrCmTq-int(W7WwUJs382HDpKaFPtbB)>24*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N:
		J2pEvZCUlm3ugNMk0GATB6hc4wK1,qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,False)
		if not J2pEvZCUlm3ugNMk0GATB6hc4wK1: return
	dpHAUi6sPKOxofM4 = int(OOnvcPQy85HYA.getSetting('av.iptv.timediff_'+HAoXLCq8rFjsaPelxNuV))
	b3bhiw0MFS6rDjlufy8 = OOnvcPQy85HYA.getSetting('av.iptv.server_'+HAoXLCq8rFjsaPelxNuV)
	uW9I6hGBzEbNprvYJ50MQHR = OOnvcPQy85HYA.getSetting('av.iptv.username_'+HAoXLCq8rFjsaPelxNuV)
	u7YQljRpaBeTZxUd = OOnvcPQy85HYA.getSetting('av.iptv.password_'+HAoXLCq8rFjsaPelxNuV)
	WabQqLSs34 = iE0GxkBnVRO4NPwleT.split('/')
	LC78n6uHPhfl1OWVIvQG54AoMXr0 = WabQqLSs34[-1].replace('.ts',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('.m3u8',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if J3ubnMHdaTGyXlDqKVWcieBf2poU=='SHORT_EPG': M6tTiCxXw1hkYel5DBFbOHu4W = 'get_short_epg'
	else: M6tTiCxXw1hkYel5DBFbOHu4W = 'get_simple_data_table'
	p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd = Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV)
	if not uW9I6hGBzEbNprvYJ50MQHR: return
	Go0hUiXHF3ed8D = p8bzkQ1hP6aUjrRC3DMi+'&action='+M6tTiCxXw1hkYel5DBFbOHu4W+'&stream_id='+LC78n6uHPhfl1OWVIvQG54AoMXr0
	V6aTvut7ocyb = PXzMdi7c9ZwNA(CSjWJNDFL0Hl2IA9fYPtoB643TbZ,Go0hUiXHF3ed8D,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-EPG_ITEMS-2nd')
	mclfPUs6Kp = dm7KA8MukvxF3iH9CW2ZNc('dict',V6aTvut7ocyb)
	vKX3FzGVmBQ0TwDh9xUZErdnoug = mclfPUs6Kp['epg_listings']
	iJuCBIc1wPbN = []
	if J3ubnMHdaTGyXlDqKVWcieBf2poU in ['ARCHIVED','TIMESHIFT']:
		for YNa9V4WUOHqgoX in vKX3FzGVmBQ0TwDh9xUZErdnoug:
			if YNa9V4WUOHqgoX['has_archive']==1:
				iJuCBIc1wPbN.append(YNa9V4WUOHqgoX)
				if J3ubnMHdaTGyXlDqKVWcieBf2poU in ['TIMESHIFT']: break
		if not iJuCBIc1wPbN: return
		mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+JegF7SlMawI03+'الملفات الأولي بهذه القائمة قد لا تعمل'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		if J3ubnMHdaTGyXlDqKVWcieBf2poU in ['TIMESHIFT']:
			sscwkem6WEnGpOZar = 2
			hJLyPEimTCA6Ysd07W1vw = sscwkem6WEnGpOZar*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
			iJuCBIc1wPbN = []
			XbYdJx0vpaRTlu8Pw4gN7V9jUf52M = int(int(YNa9V4WUOHqgoX['start_timestamp'])/hJLyPEimTCA6Ysd07W1vw)*hJLyPEimTCA6Ysd07W1vw
			JXOdja2sEvou4U9lgmx = yoJ7t3WpjPkrCmTq+hJLyPEimTCA6Ysd07W1vw
			SZYoq6a9KyBhVbCrM4lUmI = int((JXOdja2sEvou4U9lgmx-XbYdJx0vpaRTlu8Pw4gN7V9jUf52M)/lEzbFoG5rDUpTHXWn0vkdBYAscPa1N)
			for mnDKBYwZl8SM0zk6 in range(SZYoq6a9KyBhVbCrM4lUmI):
				if mnDKBYwZl8SM0zk6>=6:
					if mnDKBYwZl8SM0zk6%sscwkem6WEnGpOZar!=0: continue
					cSNa4z2sH8DLjYO = hJLyPEimTCA6Ysd07W1vw
				else: cSNa4z2sH8DLjYO = hJLyPEimTCA6Ysd07W1vw//2
				adVAlsTKj7JZCnxm8e = XbYdJx0vpaRTlu8Pw4gN7V9jUf52M+mnDKBYwZl8SM0zk6*lEzbFoG5rDUpTHXWn0vkdBYAscPa1N
				YNa9V4WUOHqgoX = {}
				YNa9V4WUOHqgoX['title'] = wUvcPrYDfISbZolAm83GKEqMyXkn5
				rDTIHO4tR3kJXaljG8M5 = L5jXH0fZ8TvsESR.localtime(adVAlsTKj7JZCnxm8e-dpHAUi6sPKOxofM4-lEzbFoG5rDUpTHXWn0vkdBYAscPa1N)
				YNa9V4WUOHqgoX['start'] = L5jXH0fZ8TvsESR.strftime('%Y.%m.%d %H:%M:%S',rDTIHO4tR3kJXaljG8M5)
				YNa9V4WUOHqgoX['start_timestamp'] = str(adVAlsTKj7JZCnxm8e)
				YNa9V4WUOHqgoX['stop_timestamp'] = str(adVAlsTKj7JZCnxm8e+cSNa4z2sH8DLjYO)
				iJuCBIc1wPbN.append(YNa9V4WUOHqgoX)
	elif J3ubnMHdaTGyXlDqKVWcieBf2poU in ['SHORT_EPG','FULL_EPG']: iJuCBIc1wPbN = vKX3FzGVmBQ0TwDh9xUZErdnoug
	if J3ubnMHdaTGyXlDqKVWcieBf2poU=='FULL_EPG' and len(iJuCBIc1wPbN)>0:
		mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+JegF7SlMawI03+'هذه قائمة برامج القنوات (جدول فقط)ـ'+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	lA5fXy6ZO7wpY2R3dVNskUhbzS = []
	v9hnfDaTXN5OLwiQS07CHr2qo3Yd = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel('ListItem.Icon')
	for YNa9V4WUOHqgoX in iJuCBIc1wPbN:
		mAefRpNJ9SQdL1WnXsGykrKg = qXASkvFKaf6HojMIz578WxlVwnCpD9.b64decode(YNa9V4WUOHqgoX['title'])
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		adVAlsTKj7JZCnxm8e = int(YNa9V4WUOHqgoX['start_timestamp'])
		kqEpWH5vmNdneoQjrcA2R8UMti4 = int(YNa9V4WUOHqgoX['stop_timestamp'])
		ccCrj1sF7WaB9n8KL = str(int((kqEpWH5vmNdneoQjrcA2R8UMti4-adVAlsTKj7JZCnxm8e+59)/60))
		KDGYz8thbi2nEMO = YNa9V4WUOHqgoX['start'].replace(UKFZBQAVXHI5s17LyvuRpCY2,':')
		rDTIHO4tR3kJXaljG8M5 = L5jXH0fZ8TvsESR.localtime(adVAlsTKj7JZCnxm8e-lEzbFoG5rDUpTHXWn0vkdBYAscPa1N)
		B3mcKtSR8ZTdU6MkyEv = L5jXH0fZ8TvsESR.strftime('%H:%M',rDTIHO4tR3kJXaljG8M5)
		lJXH2pzkRcZDoUTi = L5jXH0fZ8TvsESR.strftime('%a',rDTIHO4tR3kJXaljG8M5)
		if J3ubnMHdaTGyXlDqKVWcieBf2poU=='SHORT_EPG': mAefRpNJ9SQdL1WnXsGykrKg = QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+B3mcKtSR8ZTdU6MkyEv+' ـ '+mAefRpNJ9SQdL1WnXsGykrKg+AAByQSLgaZwCsKnvc5eWNmY
		elif J3ubnMHdaTGyXlDqKVWcieBf2poU=='TIMESHIFT': mAefRpNJ9SQdL1WnXsGykrKg = lJXH2pzkRcZDoUTi+UKFZBQAVXHI5s17LyvuRpCY2+B3mcKtSR8ZTdU6MkyEv+' ('+ccCrj1sF7WaB9n8KL+'min)'
		else: mAefRpNJ9SQdL1WnXsGykrKg = lJXH2pzkRcZDoUTi+UKFZBQAVXHI5s17LyvuRpCY2+B3mcKtSR8ZTdU6MkyEv+' ('+ccCrj1sF7WaB9n8KL+'min)   '+mAefRpNJ9SQdL1WnXsGykrKg+' ـ'
		if J3ubnMHdaTGyXlDqKVWcieBf2poU in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			aPWjlR6K4MfInqVGJZF = b3bhiw0MFS6rDjlufy8+'/timeshift/'+uW9I6hGBzEbNprvYJ50MQHR+'/'+u7YQljRpaBeTZxUd+'/'+ccCrj1sF7WaB9n8KL+'/'+KDGYz8thbi2nEMO+'/'+LC78n6uHPhfl1OWVIvQG54AoMXr0+'.m3u8'
			if J3ubnMHdaTGyXlDqKVWcieBf2poU=='FULL_EPG': mwOxEyYAg63B('link',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,aPWjlR6K4MfInqVGJZF,9999,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
			else: mwOxEyYAg63B('video',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,aPWjlR6K4MfInqVGJZF,235,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
		lA5fXy6ZO7wpY2R3dVNskUhbzS.append(mAefRpNJ9SQdL1WnXsGykrKg)
	if J3ubnMHdaTGyXlDqKVWcieBf2poU=='SHORT_EPG' and lA5fXy6ZO7wpY2R3dVNskUhbzS: IwrK9zWghnB3Y1JiGmaqR5 = LXoJtpOd2e9ASTGRw8qQ(lA5fXy6ZO7wpY2R3dVNskUhbzS)
	return lA5fXy6ZO7wpY2R3dVNskUhbzS
def BkbhctLC81aRx43IDO5jueKYT(HAoXLCq8rFjsaPelxNuV):
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,True): return
	b3bhiw0MFS6rDjlufy8,NL9ZBsCV6qpQwYt,twR1U8nJDskpSiCXLZ93HKdlvq = wUvcPrYDfISbZolAm83GKEqMyXkn5,0,0
	J2pEvZCUlm3ugNMk0GATB6hc4wK1,qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,False)
	if J2pEvZCUlm3ugNMk0GATB6hc4wK1:
		ifHklnQmuYOJWo3 = QmwBLxaEjpHvU6PAY(qqp5cKaiRw6jlkN)
		NL9ZBsCV6qpQwYt = eva1dqCNwXh5lL3rkTfWSVp(ifHklnQmuYOJWo3[0],int(gdTyD1O4nAsESM))
		rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,'LIVE_GROUPED')
		o8S6NCIcnOlWvdD1hZaVQL = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list','LIVE_GROUPED')
		rm2P4OqXgZJzeuTdicbl6xH7tU = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list','LIVE_GROUPED',o8S6NCIcnOlWvdD1hZaVQL[1])
		iE0GxkBnVRO4NPwleT = rm2P4OqXgZJzeuTdicbl6xH7tU[0][2]
		JJM8dbfyiGjF3eNtOunC5oRY2 = jj0dZrgiKb.findall('://(.*?)/',iE0GxkBnVRO4NPwleT,jj0dZrgiKb.DOTALL)
		JJM8dbfyiGjF3eNtOunC5oRY2 = JJM8dbfyiGjF3eNtOunC5oRY2[0]
		if ':' in JJM8dbfyiGjF3eNtOunC5oRY2: ttsbD9ykVTPNXlU3ErvSBdF8A2HWa,NB6rdToAsbL8Yc = JJM8dbfyiGjF3eNtOunC5oRY2.split(':')
		else: ttsbD9ykVTPNXlU3ErvSBdF8A2HWa,NB6rdToAsbL8Yc = JJM8dbfyiGjF3eNtOunC5oRY2,'80'
		kmHDF5L2adSpbT8vCwirs6Ul = QmwBLxaEjpHvU6PAY(ttsbD9ykVTPNXlU3ErvSBdF8A2HWa)
		twR1U8nJDskpSiCXLZ93HKdlvq = eva1dqCNwXh5lL3rkTfWSVp(kmHDF5L2adSpbT8vCwirs6Ul[0],int(NB6rdToAsbL8Yc))
	if NL9ZBsCV6qpQwYt and twR1U8nJDskpSiCXLZ93HKdlvq:
		SLAiUwpDRoZIQfvB7 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		SLAiUwpDRoZIQfvB7 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+QWLr8ABjev+str(int(twR1U8nJDskpSiCXLZ93HKdlvq*1000))+' ملي ثانية'
		SLAiUwpDRoZIQfvB7 += '\n\n'+'وقت ضائع في السيرفر البديل'+QWLr8ABjev+str(int(NL9ZBsCV6qpQwYt*1000))+' ملي ثانية'
		ckzdJmPICTwop = T4dIruOctCl2qwYNE0SDyU('center','السيرفر الأصلي','السيرفر الأسرع',mvVFtPw8JKpaUdXq06YrEeR7bAk2,SLAiUwpDRoZIQfvB7)
		if ckzdJmPICTwop==1 and NL9ZBsCV6qpQwYt<twR1U8nJDskpSiCXLZ93HKdlvq: b3bhiw0MFS6rDjlufy8 = qqp5cKaiRw6jlkN+':'+gdTyD1O4nAsESM
	else: IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'البرنامج لم يجد السيرفر البديل')
	OOnvcPQy85HYA.setSetting('av.iptv.server_'+HAoXLCq8rFjsaPelxNuV,b3bhiw0MFS6rDjlufy8)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(HAoXLCq8rFjsaPelxNuV,iE0GxkBnVRO4NPwleT,TAlYNXgaM4qzdtVUZKiubvs):
	lVBDruALJz3 = OOnvcPQy85HYA.getSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV)
	tx7Ge9h1UWpZMyP8dIsY = OOnvcPQy85HYA.getSetting('av.iptv.referer_'+HAoXLCq8rFjsaPelxNuV)
	if lVBDruALJz3 or tx7Ge9h1UWpZMyP8dIsY:
		iE0GxkBnVRO4NPwleT += '|'
		if lVBDruALJz3: iE0GxkBnVRO4NPwleT += '&User-Agent='+lVBDruALJz3
		if tx7Ge9h1UWpZMyP8dIsY: iE0GxkBnVRO4NPwleT += '&Referer='+tx7Ge9h1UWpZMyP8dIsY
		iE0GxkBnVRO4NPwleT = iE0GxkBnVRO4NPwleT.replace('|&','|')
	CWMBSziRDwyhN6ObQgr5uIKdp7 = OOnvcPQy85HYA.getSetting('av.iptv.server_'+HAoXLCq8rFjsaPelxNuV)
	if CWMBSziRDwyhN6ObQgr5uIKdp7:
		i9LcQGePqO6zxg2fvjbu7FBZChanEp = jj0dZrgiKb.findall('://(.*?)/',iE0GxkBnVRO4NPwleT,jj0dZrgiKb.DOTALL)
		iE0GxkBnVRO4NPwleT = iE0GxkBnVRO4NPwleT.replace(i9LcQGePqO6zxg2fvjbu7FBZChanEp[0],CWMBSziRDwyhN6ObQgr5uIKdp7)
	yyYuosJmc3QDUGSA(iE0GxkBnVRO4NPwleT,beQiZS9WP3z6gdHy75FMvfpDr,TAlYNXgaM4qzdtVUZKiubvs)
	return
def CXIZzoLy4cxeK8(HAoXLCq8rFjsaPelxNuV):
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	lVBDruALJz3 = OOnvcPQy85HYA.getSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV)
	GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center','استخدام الأصلي','تعديل القديم',lVBDruALJz3,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if GGAzehtRXPwp5LdJEWbsI3ar==1: lVBDruALJz3 = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA('أكتب ـIPTV User-Agent جديد',lVBDruALJz3,True)
	else: lVBDruALJz3 = 'Unknown'
	if lVBDruALJz3==UKFZBQAVXHI5s17LyvuRpCY2:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,lVBDruALJz3,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if GGAzehtRXPwp5LdJEWbsI3ar!=1:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم الإلغاء')
		return
	OOnvcPQy85HYA.setSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV,lVBDruALJz3)
	osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV)
	return
def X3XyGxV5ELjimuWHgM(HAoXLCq8rFjsaPelxNuV):
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	tx7Ge9h1UWpZMyP8dIsY = OOnvcPQy85HYA.getSetting('av.iptv.referer_'+HAoXLCq8rFjsaPelxNuV)
	GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center','استخدام الأصلي','تعديل القديم',tx7Ge9h1UWpZMyP8dIsY,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if GGAzehtRXPwp5LdJEWbsI3ar==1: tx7Ge9h1UWpZMyP8dIsY = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA('أكتب ـIPTV Referer جديد',tx7Ge9h1UWpZMyP8dIsY,True)
	else: tx7Ge9h1UWpZMyP8dIsY = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if tx7Ge9h1UWpZMyP8dIsY==UKFZBQAVXHI5s17LyvuRpCY2:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,tx7Ge9h1UWpZMyP8dIsY,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if GGAzehtRXPwp5LdJEWbsI3ar!=1:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم الإلغاء')
		return
	OOnvcPQy85HYA.setSetting('av.iptv.referer_'+HAoXLCq8rFjsaPelxNuV,tx7Ge9h1UWpZMyP8dIsY)
	osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV)
	return
def Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV,he1N7UR6ScoC=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not he1N7UR6ScoC: he1N7UR6ScoC = OOnvcPQy85HYA.getSetting('av.iptv.url_'+HAoXLCq8rFjsaPelxNuV)
	b3bhiw0MFS6rDjlufy8 = TO3vi2rSZ0LRhKlwgG4qkYFIC(he1N7UR6ScoC,'url')
	uW9I6hGBzEbNprvYJ50MQHR = jj0dZrgiKb.findall('username=(.*?)&',he1N7UR6ScoC+'&',jj0dZrgiKb.DOTALL)
	u7YQljRpaBeTZxUd = jj0dZrgiKb.findall('password=(.*?)&',he1N7UR6ScoC+'&',jj0dZrgiKb.DOTALL)
	if not uW9I6hGBzEbNprvYJ50MQHR or not u7YQljRpaBeTZxUd:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	uW9I6hGBzEbNprvYJ50MQHR = uW9I6hGBzEbNprvYJ50MQHR[0]
	u7YQljRpaBeTZxUd = u7YQljRpaBeTZxUd[0]
	p8bzkQ1hP6aUjrRC3DMi = b3bhiw0MFS6rDjlufy8+'/player_api.php?username='+uW9I6hGBzEbNprvYJ50MQHR+'&password='+u7YQljRpaBeTZxUd
	tyfzs0SaXoUr = b3bhiw0MFS6rDjlufy8+'/get.php?username='+uW9I6hGBzEbNprvYJ50MQHR+'&password='+u7YQljRpaBeTZxUd+'&type=m3u_plus'
	return p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd
def YlpndVN1rTvoZO503S46HDjBb(HAoXLCq8rFjsaPelxNuV,ZZQBzjMRKCb3PW8d79wSN=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	GgvFowRV4l8L1nXurTkCa3bmU = ZZQBzjMRKCb3PW8d79wSN.replace('/','_').replace(':','_').replace('.','_')
	GgvFowRV4l8L1nXurTkCa3bmU = GgvFowRV4l8L1nXurTkCa3bmU.replace('?','_').replace('=','_').replace('&','_')
	GgvFowRV4l8L1nXurTkCa3bmU = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,GgvFowRV4l8L1nXurTkCa3bmU).strip('.m3u')+'.m3u'
	return GgvFowRV4l8L1nXurTkCa3bmU
def BZ8sYcn1yxSe9fqTbmjM2lE(HAoXLCq8rFjsaPelxNuV):
	Xy5DWVx36ZmoGTSkhjYBdrpl = OOnvcPQy85HYA.getSetting('av.iptv.url_'+HAoXLCq8rFjsaPelxNuV)
	NeQ5Z1zGoTrxWvqLS = True
	if Xy5DWVx36ZmoGTSkhjYBdrpl:
		GGAzehtRXPwp5LdJEWbsI3ar = E74G0qBSpwUPLO56fsReHCl('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',JegF7SlMawI03+Xy5DWVx36ZmoGTSkhjYBdrpl+AAByQSLgaZwCsKnvc5eWNmY+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if GGAzehtRXPwp5LdJEWbsI3ar==-1: return
		elif GGAzehtRXPwp5LdJEWbsI3ar==0: Xy5DWVx36ZmoGTSkhjYBdrpl = wUvcPrYDfISbZolAm83GKEqMyXkn5
		elif GGAzehtRXPwp5LdJEWbsI3ar==2:
			GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if GGAzehtRXPwp5LdJEWbsI3ar in [-1,0]: return
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم مسح الرابط')
			NeQ5Z1zGoTrxWvqLS = False
			D4SjxWP12Mq5fs0Fm7 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if NeQ5Z1zGoTrxWvqLS:
		D4SjxWP12Mq5fs0Fm7 = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA('اكتب رابط ـIPTV كاملا',Xy5DWVx36ZmoGTSkhjYBdrpl)
		D4SjxWP12Mq5fs0Fm7 = D4SjxWP12Mq5fs0Fm7.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if not D4SjxWP12Mq5fs0Fm7:
			GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if GGAzehtRXPwp5LdJEWbsI3ar in [-1,0]: return
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم مسح الرابط')
	else:
		p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd = Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV,D4SjxWP12Mq5fs0Fm7)
		if not uW9I6hGBzEbNprvYJ50MQHR: return
		SLAiUwpDRoZIQfvB7 = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		SLAiUwpDRoZIQfvB7 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+b3bhiw0MFS6rDjlufy8+AAByQSLgaZwCsKnvc5eWNmY+'عنوان السيرفر: '
		SLAiUwpDRoZIQfvB7 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+uW9I6hGBzEbNprvYJ50MQHR+AAByQSLgaZwCsKnvc5eWNmY+'اسم المستخدم: '
		SLAiUwpDRoZIQfvB7 += QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+RBAx5K1abuS++'كلمة السر: '
		GGAzehtRXPwp5LdJEWbsI3ar = T4dIruOctCl2qwYNE0SDyU('right',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'الرابط الجديد هو:',JegF7SlMawI03+D4SjxWP12Mq5fs0Fm7+AAByQSLgaZwCsKnvc5eWNmY+'\n\n'+SLAiUwpDRoZIQfvB7)
		if GGAzehtRXPwp5LdJEWbsI3ar!=1:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم الإلغاء')
			return
	OOnvcPQy85HYA.setSetting('av.iptv.url_'+HAoXLCq8rFjsaPelxNuV,D4SjxWP12Mq5fs0Fm7)
	OOnvcPQy85HYA.setSetting('av.iptv.timestamp_'+HAoXLCq8rFjsaPelxNuV,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	OOnvcPQy85HYA.setSetting('av.iptv.timediff_'+HAoXLCq8rFjsaPelxNuV,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	lVBDruALJz3 = OOnvcPQy85HYA.getSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV)
	if not lVBDruALJz3: OOnvcPQy85HYA.setSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV,'Unknown')
	squK1D58eF09XlTR2wY = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,D4SjxWP12Mq5fs0Fm7+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if squK1D58eF09XlTR2wY==1: J2pEvZCUlm3ugNMk0GATB6hc4wK1,qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,True)
	osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV)
	return
def Y9FBXExhs2T50OA(tSszk5Zhc4KwIiFLx2Ue1yv,SSjCyfv9TE74,okHi2pVzSw8vx,usJXCitjNLov,YNSsrVcPa7d6iEjTqwtyDX5HZv,FFmkB3hOineTAdNMsLl,tyfzs0SaXoUr):
	rm2P4OqXgZJzeuTdicbl6xH7tU,ukzWYEeinZq = [],[]
	QxLNh1wkc7A3ROVoz = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for iKT4uUnJygfFlZtLQWVqbdH in tSszk5Zhc4KwIiFLx2Ue1yv:
		if FFmkB3hOineTAdNMsLl%473==0:
			snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,40+int(10*FFmkB3hOineTAdNMsLl/YNSsrVcPa7d6iEjTqwtyDX5HZv),'قراءة الفيديوهات','الفيديو رقم:-',str(FFmkB3hOineTAdNMsLl)+' / '+str(YNSsrVcPa7d6iEjTqwtyDX5HZv))
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return None,None,None
		iE0GxkBnVRO4NPwleT = jj0dZrgiKb.findall('^(.*?)\n+((http|https|rtmp).*?)$',iKT4uUnJygfFlZtLQWVqbdH,jj0dZrgiKb.DOTALL)
		if iE0GxkBnVRO4NPwleT:
			iKT4uUnJygfFlZtLQWVqbdH,iE0GxkBnVRO4NPwleT,vvbZFGz0gj2pLUXVf3yBsH = iE0GxkBnVRO4NPwleT[0]
			iE0GxkBnVRO4NPwleT = iE0GxkBnVRO4NPwleT.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5)
			iKT4uUnJygfFlZtLQWVqbdH = iKT4uUnJygfFlZtLQWVqbdH.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5)
		else:
			ukzWYEeinZq.append({'line':iKT4uUnJygfFlZtLQWVqbdH})
			continue
		Yb9z4uBx2iqeZIHoUDGvlVNLTs,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,dlmjGAi0wsYW8Q,mAefRpNJ9SQdL1WnXsGykrKg,TAlYNXgaM4qzdtVUZKiubvs,b2cK70MyrOgv1umnJpNLCqh4PaWV5 = {},wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,False
		try:
			iKT4uUnJygfFlZtLQWVqbdH,mAefRpNJ9SQdL1WnXsGykrKg = iKT4uUnJygfFlZtLQWVqbdH.rsplit('",',1)
			iKT4uUnJygfFlZtLQWVqbdH = iKT4uUnJygfFlZtLQWVqbdH+'"'
		except:
			try: iKT4uUnJygfFlZtLQWVqbdH,mAefRpNJ9SQdL1WnXsGykrKg = iKT4uUnJygfFlZtLQWVqbdH.rsplit('1,',1)
			except: mAefRpNJ9SQdL1WnXsGykrKg = wUvcPrYDfISbZolAm83GKEqMyXkn5
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['url'] = iE0GxkBnVRO4NPwleT
		KEhwquQ02YSJRtWmveMITrVBOUp = jj0dZrgiKb.findall(' (.*?)="(.*?)"',iKT4uUnJygfFlZtLQWVqbdH,jj0dZrgiKb.DOTALL)
		for j5eZi43FxprNKqGoQz1tV,QoeAC3n71cYrPf2gWlKxBtkb0 in KEhwquQ02YSJRtWmveMITrVBOUp:
			j5eZi43FxprNKqGoQz1tV = j5eZi43FxprNKqGoQz1tV.replace('"',wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
			Yb9z4uBx2iqeZIHoUDGvlVNLTs[j5eZi43FxprNKqGoQz1tV] = QoeAC3n71cYrPf2gWlKxBtkb0.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		mmLqi1sJNxT8GhKrfOZ0zlj4 = list(Yb9z4uBx2iqeZIHoUDGvlVNLTs.keys())
		if not mAefRpNJ9SQdL1WnXsGykrKg:
			if 'name' in mmLqi1sJNxT8GhKrfOZ0zlj4 and Yb9z4uBx2iqeZIHoUDGvlVNLTs['name']: mAefRpNJ9SQdL1WnXsGykrKg = Yb9z4uBx2iqeZIHoUDGvlVNLTs['name']
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['title'] = mAefRpNJ9SQdL1WnXsGykrKg.strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		if 'logo' in mmLqi1sJNxT8GhKrfOZ0zlj4:
			Yb9z4uBx2iqeZIHoUDGvlVNLTs['img'] = Yb9z4uBx2iqeZIHoUDGvlVNLTs['logo']
			del Yb9z4uBx2iqeZIHoUDGvlVNLTs['logo']
		else: Yb9z4uBx2iqeZIHoUDGvlVNLTs['img'] = wUvcPrYDfISbZolAm83GKEqMyXkn5
		if 'group' in mmLqi1sJNxT8GhKrfOZ0zlj4 and Yb9z4uBx2iqeZIHoUDGvlVNLTs['group']: dlmjGAi0wsYW8Q = Yb9z4uBx2iqeZIHoUDGvlVNLTs['group']
		if any(value in iE0GxkBnVRO4NPwleT.lower() for value in QxLNh1wkc7A3ROVoz):
			b2cK70MyrOgv1umnJpNLCqh4PaWV5 = True if 'm3u' not in iE0GxkBnVRO4NPwleT else False
		if b2cK70MyrOgv1umnJpNLCqh4PaWV5 or '__SERIES__' in dlmjGAi0wsYW8Q or '__MOVIES__' in dlmjGAi0wsYW8Q:
			TAlYNXgaM4qzdtVUZKiubvs = 'VOD'
			if '__SERIES__' in dlmjGAi0wsYW8Q: TAlYNXgaM4qzdtVUZKiubvs = TAlYNXgaM4qzdtVUZKiubvs+'_SERIES'
			elif '__MOVIES__' in dlmjGAi0wsYW8Q: TAlYNXgaM4qzdtVUZKiubvs = TAlYNXgaM4qzdtVUZKiubvs+'_MOVIES'
			else: TAlYNXgaM4qzdtVUZKiubvs = TAlYNXgaM4qzdtVUZKiubvs+'_UNKNOWN'
			dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.replace('__SERIES__',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('__MOVIES__',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		else:
			TAlYNXgaM4qzdtVUZKiubvs = 'LIVE'
			if mAefRpNJ9SQdL1WnXsGykrKg in SSjCyfv9TE74: QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa = QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa+'_EPG'
			if mAefRpNJ9SQdL1WnXsGykrKg in okHi2pVzSw8vx: QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa = QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa+'_ARCHIVED'
			if not dlmjGAi0wsYW8Q: TAlYNXgaM4qzdtVUZKiubvs = TAlYNXgaM4qzdtVUZKiubvs+'_UNKNOWN'
			else: TAlYNXgaM4qzdtVUZKiubvs = TAlYNXgaM4qzdtVUZKiubvs+QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa
		dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.strip(UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		if 'LIVE_UNKNOWN' in TAlYNXgaM4qzdtVUZKiubvs: dlmjGAi0wsYW8Q = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in TAlYNXgaM4qzdtVUZKiubvs: dlmjGAi0wsYW8Q = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in TAlYNXgaM4qzdtVUZKiubvs:
			uLlKzMHfPjInFR0T4 = jj0dZrgiKb.findall('(.*?) [Ss]\d+ +[Ee]\d+',Yb9z4uBx2iqeZIHoUDGvlVNLTs['title'],jj0dZrgiKb.DOTALL)
			if uLlKzMHfPjInFR0T4: uLlKzMHfPjInFR0T4 = uLlKzMHfPjInFR0T4[0]
			else: uLlKzMHfPjInFR0T4 = '!!__UNKNOWN_SERIES__!!'
			dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q+'__SERIES__'+uLlKzMHfPjInFR0T4
		if 'id' in mmLqi1sJNxT8GhKrfOZ0zlj4: del Yb9z4uBx2iqeZIHoUDGvlVNLTs['id']
		if 'ID' in mmLqi1sJNxT8GhKrfOZ0zlj4: del Yb9z4uBx2iqeZIHoUDGvlVNLTs['ID']
		if 'name' in mmLqi1sJNxT8GhKrfOZ0zlj4: del Yb9z4uBx2iqeZIHoUDGvlVNLTs['name']
		mAefRpNJ9SQdL1WnXsGykrKg = Yb9z4uBx2iqeZIHoUDGvlVNLTs['title']
		mAefRpNJ9SQdL1WnXsGykrKg = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(mAefRpNJ9SQdL1WnXsGykrKg)
		mAefRpNJ9SQdL1WnXsGykrKg = scgkMzBrbev8C5ZAf4mhKtaj297XL0(mAefRpNJ9SQdL1WnXsGykrKg)
		U9U1zkKTF6JirEWbIYHx,dlmjGAi0wsYW8Q = hhbFESk3pdwoaJNgD(dlmjGAi0wsYW8Q)
		Oo3AYnPBMsGu5kFT407La2xrIdSzN,mAefRpNJ9SQdL1WnXsGykrKg = hhbFESk3pdwoaJNgD(mAefRpNJ9SQdL1WnXsGykrKg)
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['type'] = TAlYNXgaM4qzdtVUZKiubvs
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['context'] = QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['group'] = dlmjGAi0wsYW8Q.upper()
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['title'] = mAefRpNJ9SQdL1WnXsGykrKg.upper()
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['country'] = Oo3AYnPBMsGu5kFT407La2xrIdSzN.upper()
		Yb9z4uBx2iqeZIHoUDGvlVNLTs['language'] = U9U1zkKTF6JirEWbIYHx.upper()
		rm2P4OqXgZJzeuTdicbl6xH7tU.append(Yb9z4uBx2iqeZIHoUDGvlVNLTs)
		FFmkB3hOineTAdNMsLl += 1
	return rm2P4OqXgZJzeuTdicbl6xH7tU,FFmkB3hOineTAdNMsLl,ukzWYEeinZq
def scgkMzBrbev8C5ZAf4mhKtaj297XL0(mAefRpNJ9SQdL1WnXsGykrKg):
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.replace('||','|').replace('___',':').replace('--','-')
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.replace('[[','[').replace(']]',']')
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.replace('((','(').replace('))',')')
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.replace('<<','<').replace('>>','>')
	mAefRpNJ9SQdL1WnXsGykrKg = mAefRpNJ9SQdL1WnXsGykrKg.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	return mAefRpNJ9SQdL1WnXsGykrKg
def YDNgH9hjKIvSLTxwcM(ijsaKr3vTlUO18mBHZbFzeYdg6QV2c,usJXCitjNLov):
	ahonYb6Q9ZVzAfpgK40Gw = {}
	for xNl6RiITCUD2V1zgF0jrEa97b58n in RRPFLpAv60TUIVoniqXjCbzmKY: ahonYb6Q9ZVzAfpgK40Gw[xNl6RiITCUD2V1zgF0jrEa97b58n] = []
	YNSsrVcPa7d6iEjTqwtyDX5HZv = len(ijsaKr3vTlUO18mBHZbFzeYdg6QV2c)
	XX8nHzZG2ekrC = str(YNSsrVcPa7d6iEjTqwtyDX5HZv)
	FFmkB3hOineTAdNMsLl = 0
	ukzWYEeinZq = []
	for Yb9z4uBx2iqeZIHoUDGvlVNLTs in ijsaKr3vTlUO18mBHZbFzeYdg6QV2c:
		if FFmkB3hOineTAdNMsLl%873==0:
			snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,50+int(5*FFmkB3hOineTAdNMsLl/YNSsrVcPa7d6iEjTqwtyDX5HZv),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(FFmkB3hOineTAdNMsLl)+' / '+XX8nHzZG2ekrC)
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return None,None
		dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd = Yb9z4uBx2iqeZIHoUDGvlVNLTs['group'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['context'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['title'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['url'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['img']
		Oo3AYnPBMsGu5kFT407La2xrIdSzN,U9U1zkKTF6JirEWbIYHx,xNl6RiITCUD2V1zgF0jrEa97b58n = Yb9z4uBx2iqeZIHoUDGvlVNLTs['country'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['language'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['type']
		AQ3r26PztnyL4JKweGVOYqC1f = (dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd)
		EPlB06rQYNGxjyg3DqM = False
		if 'LIVE' in xNl6RiITCUD2V1zgF0jrEa97b58n:
			if 'UNKNOWN' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_UNKNOWN_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			elif 'LIVE' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			else: EPlB06rQYNGxjyg3DqM = True
			ahonYb6Q9ZVzAfpgK40Gw['LIVE_ORIGINAL_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
		elif 'VOD' in xNl6RiITCUD2V1zgF0jrEa97b58n:
			if 'UNKNOWN' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_UNKNOWN_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			elif 'MOVIES' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_MOVIES_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			elif 'SERIES' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_SERIES_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			else: EPlB06rQYNGxjyg3DqM = True
			ahonYb6Q9ZVzAfpgK40Gw['VOD_ORIGINAL_GROUPED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
		else: EPlB06rQYNGxjyg3DqM = True
		if EPlB06rQYNGxjyg3DqM: ukzWYEeinZq.append(Yb9z4uBx2iqeZIHoUDGvlVNLTs)
		FFmkB3hOineTAdNMsLl += 1
	WwGBfozOglX0Fy9YKmkI = sorted(ijsaKr3vTlUO18mBHZbFzeYdg6QV2c,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV['title'].lower())
	del ijsaKr3vTlUO18mBHZbFzeYdg6QV2c
	XX8nHzZG2ekrC = str(YNSsrVcPa7d6iEjTqwtyDX5HZv)
	FFmkB3hOineTAdNMsLl = 0
	for Yb9z4uBx2iqeZIHoUDGvlVNLTs in WwGBfozOglX0Fy9YKmkI:
		FFmkB3hOineTAdNMsLl += 1
		if FFmkB3hOineTAdNMsLl%873==0:
			snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,55+int(5*FFmkB3hOineTAdNMsLl/YNSsrVcPa7d6iEjTqwtyDX5HZv),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(FFmkB3hOineTAdNMsLl)+' / '+XX8nHzZG2ekrC)
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return None,None
		xNl6RiITCUD2V1zgF0jrEa97b58n = Yb9z4uBx2iqeZIHoUDGvlVNLTs['type']
		dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd = Yb9z4uBx2iqeZIHoUDGvlVNLTs['group'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['context'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['title'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['url'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['img']
		Oo3AYnPBMsGu5kFT407La2xrIdSzN,U9U1zkKTF6JirEWbIYHx = Yb9z4uBx2iqeZIHoUDGvlVNLTs['country'],Yb9z4uBx2iqeZIHoUDGvlVNLTs['language']
		Qjem0UR5bH89igDZz7 = (dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa+'_TIMESHIFT',mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd)
		AQ3r26PztnyL4JKweGVOYqC1f = (dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd)
		Cmk9arFfIe8 = (Oo3AYnPBMsGu5kFT407La2xrIdSzN,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd)
		rEL57xymJH = (U9U1zkKTF6JirEWbIYHx,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd)
		if 'LIVE' in xNl6RiITCUD2V1zgF0jrEa97b58n:
			if 'UNKNOWN' in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_UNKNOWN_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			else: ahonYb6Q9ZVzAfpgK40Gw['LIVE_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			if 'EPG'		in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_EPG_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			if 'ARCHIVED'	in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_ARCHIVED_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			if 'ARCHIVED'	in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['LIVE_TIMESHIFT_GROUPED_SORTED'].append(Qjem0UR5bH89igDZz7)
			ahonYb6Q9ZVzAfpgK40Gw['LIVE_FROM_NAME_SORTED'].append(Cmk9arFfIe8)
			ahonYb6Q9ZVzAfpgK40Gw['LIVE_FROM_GROUP_SORTED'].append(rEL57xymJH)
		elif 'VOD' in xNl6RiITCUD2V1zgF0jrEa97b58n:
			if   'UNKNOWN'	in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_UNKNOWN_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			elif 'MOVIES'	in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_MOVIES_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			elif 'SERIES'	in xNl6RiITCUD2V1zgF0jrEa97b58n: ahonYb6Q9ZVzAfpgK40Gw['VOD_SERIES_GROUPED_SORTED'].append(AQ3r26PztnyL4JKweGVOYqC1f)
			ahonYb6Q9ZVzAfpgK40Gw['VOD_FROM_NAME_SORTED'].append(Cmk9arFfIe8)
			ahonYb6Q9ZVzAfpgK40Gw['VOD_FROM_GROUP_SORTED'].append(rEL57xymJH)
	return ahonYb6Q9ZVzAfpgK40Gw,ukzWYEeinZq
def hhbFESk3pdwoaJNgD(mAefRpNJ9SQdL1WnXsGykrKg):
	if len(mAefRpNJ9SQdL1WnXsGykrKg)<3: return mAefRpNJ9SQdL1WnXsGykrKg,mAefRpNJ9SQdL1WnXsGykrKg
	ipA3KFmH7WE2GxNR,zGbmUjp4aq1DMNl = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	uQS7YpndFA6axqjr1 = mAefRpNJ9SQdL1WnXsGykrKg
	Md4mr3SvbtCsi6 = mAefRpNJ9SQdL1WnXsGykrKg[:1]
	HCxKJPXT06B8ntz53yR1Q = mAefRpNJ9SQdL1WnXsGykrKg[1:]
	if   Md4mr3SvbtCsi6=='(': zGbmUjp4aq1DMNl = ')'
	elif Md4mr3SvbtCsi6=='[': zGbmUjp4aq1DMNl = ']'
	elif Md4mr3SvbtCsi6=='<': zGbmUjp4aq1DMNl = '>'
	elif Md4mr3SvbtCsi6=='|': zGbmUjp4aq1DMNl = '|'
	if zGbmUjp4aq1DMNl and (zGbmUjp4aq1DMNl in HCxKJPXT06B8ntz53yR1Q):
		Tagnj9rYfJkKV7L,cOSAJxqspZK = HCxKJPXT06B8ntz53yR1Q.split(zGbmUjp4aq1DMNl,1)
		ipA3KFmH7WE2GxNR = Tagnj9rYfJkKV7L
		uQS7YpndFA6axqjr1 = Md4mr3SvbtCsi6+Tagnj9rYfJkKV7L+zGbmUjp4aq1DMNl+UKFZBQAVXHI5s17LyvuRpCY2+cOSAJxqspZK
	elif mAefRpNJ9SQdL1WnXsGykrKg.count('|')>=2:
		Tagnj9rYfJkKV7L,cOSAJxqspZK = mAefRpNJ9SQdL1WnXsGykrKg.split('|',1)
		ipA3KFmH7WE2GxNR = Tagnj9rYfJkKV7L
		uQS7YpndFA6axqjr1 = Tagnj9rYfJkKV7L+' |'+cOSAJxqspZK
	else:
		zGbmUjp4aq1DMNl = jj0dZrgiKb.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',mAefRpNJ9SQdL1WnXsGykrKg,jj0dZrgiKb.DOTALL)
		if not zGbmUjp4aq1DMNl: zGbmUjp4aq1DMNl = jj0dZrgiKb.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',mAefRpNJ9SQdL1WnXsGykrKg,jj0dZrgiKb.DOTALL)
		if not zGbmUjp4aq1DMNl: zGbmUjp4aq1DMNl = jj0dZrgiKb.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',mAefRpNJ9SQdL1WnXsGykrKg,jj0dZrgiKb.DOTALL)
		if zGbmUjp4aq1DMNl:
			Tagnj9rYfJkKV7L,cOSAJxqspZK = mAefRpNJ9SQdL1WnXsGykrKg.split(zGbmUjp4aq1DMNl[0],1)
			ipA3KFmH7WE2GxNR = Tagnj9rYfJkKV7L
			uQS7YpndFA6axqjr1 = Tagnj9rYfJkKV7L+UKFZBQAVXHI5s17LyvuRpCY2+zGbmUjp4aq1DMNl[0]+UKFZBQAVXHI5s17LyvuRpCY2+cOSAJxqspZK
	uQS7YpndFA6axqjr1 = uQS7YpndFA6axqjr1.replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	ipA3KFmH7WE2GxNR = ipA3KFmH7WE2GxNR.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	if not ipA3KFmH7WE2GxNR: ipA3KFmH7WE2GxNR = '!!__UNKNOWN__!!'
	ipA3KFmH7WE2GxNR = ipA3KFmH7WE2GxNR.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	uQS7YpndFA6axqjr1 = uQS7YpndFA6axqjr1.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	return ipA3KFmH7WE2GxNR,uQS7YpndFA6axqjr1
def maZGulCg9DRBrYW4HM1tjk6L3(HAoXLCq8rFjsaPelxNuV):
	DDPMgjZIuk = {}
	lVBDruALJz3 = OOnvcPQy85HYA.getSetting('av.iptv.useragent_'+HAoXLCq8rFjsaPelxNuV)
	if lVBDruALJz3: DDPMgjZIuk['User-Agent'] = lVBDruALJz3
	tx7Ge9h1UWpZMyP8dIsY = OOnvcPQy85HYA.getSetting('av.iptv.referer_'+HAoXLCq8rFjsaPelxNuV)
	if tx7Ge9h1UWpZMyP8dIsY: DDPMgjZIuk['Referer'] = tx7Ge9h1UWpZMyP8dIsY
	return DDPMgjZIuk
def bom0X7rWaqsPEzf(HAoXLCq8rFjsaPelxNuV):
	global usJXCitjNLov,ahonYb6Q9ZVzAfpgK40Gw,dd2PRtAcELnmae3vQ,Bt0XhfUejLkHgJzmGDSdxwiIyulsvq,K6KT4HZbF3EONlLyekoGjUY,o8S6NCIcnOlWvdD1hZaVQL,AKvgn98pThrV6WsPQMfR5xm,RniIt5VhuUcpaNfzZ,m3xVdpGMsIwbiX4R1hJzCNyESck
	p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd = Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV)
	if not uW9I6hGBzEbNprvYJ50MQHR: return
	DDPMgjZIuk = maZGulCg9DRBrYW4HM1tjk6L3(HAoXLCq8rFjsaPelxNuV)
	ckzdJmPICTwop = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if ckzdJmPICTwop!=1: return
	GgvFowRV4l8L1nXurTkCa3bmU = WsgH5OuS41JkZFoRACamNI72jGepln.replace('___','_'+HAoXLCq8rFjsaPelxNuV)
	if 1:
		J2pEvZCUlm3ugNMk0GATB6hc4wK1,qqp5cKaiRw6jlkN,gdTyD1O4nAsESM = oMb0X7DqACvZIWVKne(HAoXLCq8rFjsaPelxNuV,False)
		if not J2pEvZCUlm3ugNMk0GATB6hc4wK1:
			IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not tyfzs0SaXoUr: KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(beQiZS9WP3z6gdHy75FMvfpDr)+'   No IPTV URL found to download IPTV files')
			else: KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(beQiZS9WP3z6gdHy75FMvfpDr)+'   Failed to download IPTV files')
			return
		BYfgqvGzcJRW5 = Yz9CGVI5S3N1mukQfvK0Z(tyfzs0SaXoUr,DDPMgjZIuk,True)
		if not BYfgqvGzcJRW5: return
		open(GgvFowRV4l8L1nXurTkCa3bmU,'wb').write(BYfgqvGzcJRW5)
	else: BYfgqvGzcJRW5 = open(GgvFowRV4l8L1nXurTkCa3bmU,'rb').read()
	if wwMdFkWvcRYiXHB7yDrCqnKb98o and BYfgqvGzcJRW5: BYfgqvGzcJRW5 = BYfgqvGzcJRW5.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	usJXCitjNLov = tt4jsl3YLKexr()
	usJXCitjNLov.create('جلب ملفات ـIPTV جديدة',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,15,'تنظيف الملف الرئيسي',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('"tvg-','" tvg-')
	BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('َ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ً',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ُ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ٌ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('ّ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ِ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ٍ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('ْ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('group-title=','group=').replace('tvg-',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	okHi2pVzSw8vx,SSjCyfv9TE74 = [],[]
	snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if usJXCitjNLov.iscanceled():
		usJXCitjNLov.close()
		return
	iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_series_categories'
	yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',iE0GxkBnVRO4NPwleT,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-CREATE_STREAMS-1st')
	V6aTvut7ocyb = yBn638aQbxUdpCSA.content
	V6aTvut7ocyb = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(V6aTvut7ocyb)
	CrG6OPYAmt3q7Le = jj0dZrgiKb.findall('category_name":"(.*?)"',V6aTvut7ocyb,jj0dZrgiKb.DOTALL)
	del V6aTvut7ocyb
	for dlmjGAi0wsYW8Q in CrG6OPYAmt3q7Le:
		dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.replace('\/','/')
		if ndib93Ol6UojCrEV: dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('group="'+dlmjGAi0wsYW8Q+'"','group="__SERIES__'+dlmjGAi0wsYW8Q+'"')
	del CrG6OPYAmt3q7Le
	snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if usJXCitjNLov.iscanceled():
		usJXCitjNLov.close()
		return
	iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_vod_categories'
	yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',iE0GxkBnVRO4NPwleT,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-CREATE_STREAMS-2nd')
	V6aTvut7ocyb = yBn638aQbxUdpCSA.content
	V6aTvut7ocyb = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(V6aTvut7ocyb)
	V6G7Q8UPgK = jj0dZrgiKb.findall('category_name":"(.*?)"',V6aTvut7ocyb,jj0dZrgiKb.DOTALL)
	del V6aTvut7ocyb
	for dlmjGAi0wsYW8Q in V6G7Q8UPgK:
		dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.replace('\/','/')
		if ndib93Ol6UojCrEV: dlmjGAi0wsYW8Q = dlmjGAi0wsYW8Q.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace('group="'+dlmjGAi0wsYW8Q+'"','group="__MOVIES__'+dlmjGAi0wsYW8Q+'"')
	del V6G7Q8UPgK
	snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if usJXCitjNLov.iscanceled():
		usJXCitjNLov.close()
		return
	iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_live_streams'
	yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',iE0GxkBnVRO4NPwleT,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-CREATE_STREAMS-3rd')
	V6aTvut7ocyb = yBn638aQbxUdpCSA.content
	V6aTvut7ocyb = aqEPtLZ4R8Tbpri2HhQsKl07zdn1c(V6aTvut7ocyb)
	Zl8RcA7qN6TWpHYKh = jj0dZrgiKb.findall('"name":"(.*?)".*?"tv_archive":(.*?),',V6aTvut7ocyb,jj0dZrgiKb.DOTALL)
	for LcukPqj3x6f9WDZQh5YJzg,rjx5GKRBTb2tWAQLiNEnk0O7XyC1dI in Zl8RcA7qN6TWpHYKh:
		if rjx5GKRBTb2tWAQLiNEnk0O7XyC1dI=='1': okHi2pVzSw8vx.append(LcukPqj3x6f9WDZQh5YJzg)
	del Zl8RcA7qN6TWpHYKh
	yyzfHWD81ptSGLqrF2c = jj0dZrgiKb.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',V6aTvut7ocyb,jj0dZrgiKb.DOTALL)
	del V6aTvut7ocyb
	for LcukPqj3x6f9WDZQh5YJzg,qxRXI8MGCUNOQa2w3y in yyzfHWD81ptSGLqrF2c:
		if qxRXI8MGCUNOQa2w3y!='null': SSjCyfv9TE74.append(LcukPqj3x6f9WDZQh5YJzg)
	del yyzfHWD81ptSGLqrF2c
	BYfgqvGzcJRW5 = BYfgqvGzcJRW5.replace(o46hdHaXLqyFwzD,QWLr8ABjev)
	tSszk5Zhc4KwIiFLx2Ue1yv = jj0dZrgiKb.findall('NF:(.+?)'+'#'+'EXTI',BYfgqvGzcJRW5+'\n+'+'#'+'EXTINF:',jj0dZrgiKb.DOTALL)
	if not tSszk5Zhc4KwIiFLx2Ue1yv:
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(beQiZS9WP3z6gdHy75FMvfpDr)+'   Folder:'+HAoXLCq8rFjsaPelxNuV+'   No video links found in IPTV file')
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+QWLr8ABjev+QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+'مجلد رقم '+HAoXLCq8rFjsaPelxNuV)
		usJXCitjNLov.close()
		return
	w1xX8JDip7qtFcjhnGgv2yAS5 = []
	for iKT4uUnJygfFlZtLQWVqbdH in tSszk5Zhc4KwIiFLx2Ue1yv:
		ZZbIHLVyTsNS5v1rdatuCfm4EoP = iKT4uUnJygfFlZtLQWVqbdH.lower()
		if 'adult' in ZZbIHLVyTsNS5v1rdatuCfm4EoP: continue
		if 'xxx' in ZZbIHLVyTsNS5v1rdatuCfm4EoP: continue
		w1xX8JDip7qtFcjhnGgv2yAS5.append(iKT4uUnJygfFlZtLQWVqbdH)
	tSszk5Zhc4KwIiFLx2Ue1yv = w1xX8JDip7qtFcjhnGgv2yAS5
	del w1xX8JDip7qtFcjhnGgv2yAS5
	ETlwDMVo3O5m7WU = 1024*1024
	lLojrw3Na7Dd = 1+len(BYfgqvGzcJRW5)//ETlwDMVo3O5m7WU//10
	del BYfgqvGzcJRW5
	ZZHtRJ1Ek5O6jxTlifVYb9Ns3KUP = len(tSszk5Zhc4KwIiFLx2Ue1yv)
	vu3Gdln9AyIPqQHscihZED8LS74kOj = eE1KCWTrVxhd(tSszk5Zhc4KwIiFLx2Ue1yv,lLojrw3Na7Dd)
	del tSszk5Zhc4KwIiFLx2Ue1yv
	for TvkL6PzYlCNVfUXc2b7K9ZDxg in range(lLojrw3Na7Dd):
		snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,35+int(5*TvkL6PzYlCNVfUXc2b7K9ZDxg/lLojrw3Na7Dd),'تقطيع الملف الرئيسي','الجزء رقم:-',str(TvkL6PzYlCNVfUXc2b7K9ZDxg+1)+' / '+str(lLojrw3Na7Dd))
		if usJXCitjNLov.iscanceled():
			usJXCitjNLov.close()
			return
		Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG = str(vu3Gdln9AyIPqQHscihZED8LS74kOj[TvkL6PzYlCNVfUXc2b7K9ZDxg])
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG = Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(GgvFowRV4l8L1nXurTkCa3bmU+'.00'+str(TvkL6PzYlCNVfUXc2b7K9ZDxg),'wb').write(Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG)
	del vu3Gdln9AyIPqQHscihZED8LS74kOj,Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG
	p8BznlXrGfVku,ijsaKr3vTlUO18mBHZbFzeYdg6QV2c,FFmkB3hOineTAdNMsLl = [],[],0
	for TvkL6PzYlCNVfUXc2b7K9ZDxg in range(lLojrw3Na7Dd):
		if usJXCitjNLov.iscanceled():
			usJXCitjNLov.close()
			return
		Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG = open(GgvFowRV4l8L1nXurTkCa3bmU+'.00'+str(TvkL6PzYlCNVfUXc2b7K9ZDxg),'rb').read()
		L5jXH0fZ8TvsESR.sleep(1)
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(GgvFowRV4l8L1nXurTkCa3bmU+'.00'+str(TvkL6PzYlCNVfUXc2b7K9ZDxg))
		except: pass
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG = Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		vv13wtpIKGPV05NUJjqz = dm7KA8MukvxF3iH9CW2ZNc('list',Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG)
		del Y1IHz9lCQBuktOMoJ5Rjw0LExNKiG
		rm2P4OqXgZJzeuTdicbl6xH7tU,FFmkB3hOineTAdNMsLl,ukzWYEeinZq = Y9FBXExhs2T50OA(vv13wtpIKGPV05NUJjqz,SSjCyfv9TE74,okHi2pVzSw8vx,usJXCitjNLov,ZZHtRJ1Ek5O6jxTlifVYb9Ns3KUP,FFmkB3hOineTAdNMsLl,tyfzs0SaXoUr)
		if usJXCitjNLov.iscanceled():
			usJXCitjNLov.close()
			return
		if not rm2P4OqXgZJzeuTdicbl6xH7tU:
			usJXCitjNLov.close()
			return
		ijsaKr3vTlUO18mBHZbFzeYdg6QV2c += rm2P4OqXgZJzeuTdicbl6xH7tU
		p8BznlXrGfVku += ukzWYEeinZq
	del vv13wtpIKGPV05NUJjqz,rm2P4OqXgZJzeuTdicbl6xH7tU
	ahonYb6Q9ZVzAfpgK40Gw,ukzWYEeinZq = YDNgH9hjKIvSLTxwcM(ijsaKr3vTlUO18mBHZbFzeYdg6QV2c,usJXCitjNLov)
	if usJXCitjNLov.iscanceled():
		usJXCitjNLov.close()
		return
	p8BznlXrGfVku += ukzWYEeinZq
	del ijsaKr3vTlUO18mBHZbFzeYdg6QV2c,ukzWYEeinZq
	Bt0XhfUejLkHgJzmGDSdxwiIyulsvq,K6KT4HZbF3EONlLyekoGjUY,o8S6NCIcnOlWvdD1hZaVQL,AKvgn98pThrV6WsPQMfR5xm,RniIt5VhuUcpaNfzZ = {},{},{},0,0
	yCR6GxHkqbslgc9W8r4zO3NdE = list(ahonYb6Q9ZVzAfpgK40Gw.keys())
	m3xVdpGMsIwbiX4R1hJzCNyESck = len(yCR6GxHkqbslgc9W8r4zO3NdE)*3
	if 1:
		YF0R8BVdZSI59QOMpibWLnqt7U16ND = {}
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1] = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=EE9dWhRwbCIMn8Ho0Ot,args=(BpAlbchoSTDu1,))
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1].start()
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1].join()
		if usJXCitjNLov.iscanceled():
			usJXCitjNLov.close()
			return
	else:
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			EE9dWhRwbCIMn8Ho0Ot(BpAlbchoSTDu1)
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return
	MMtqGunbXfZDNcQvmH(HAoXLCq8rFjsaPelxNuV,False)
	yCR6GxHkqbslgc9W8r4zO3NdE = list(Bt0XhfUejLkHgJzmGDSdxwiIyulsvq.keys())
	dd2PRtAcELnmae3vQ = 0
	if 1:
		YF0R8BVdZSI59QOMpibWLnqt7U16ND = {}
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1] = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=XzpdZ8PwgnIc1bu9AS7yQx4Yo,args=(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1))
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1].start()
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			YF0R8BVdZSI59QOMpibWLnqt7U16ND[BpAlbchoSTDu1].join()
		if usJXCitjNLov.iscanceled():
			usJXCitjNLov.close()
			return
	else:
		for BpAlbchoSTDu1 in yCR6GxHkqbslgc9W8r4zO3NdE:
			XzpdZ8PwgnIc1bu9AS7yQx4Yo(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1)
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return
	TvkL6PzYlCNVfUXc2b7K9ZDxg = 0
	xx30Eoz8dXFPi5t = len(p8BznlXrGfVku)
	rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,'IGNORED')
	for U40MCiFH5QoDdn3cX2 in p8BznlXrGfVku:
		if TvkL6PzYlCNVfUXc2b7K9ZDxg%27==0:
			snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,95+int(5*TvkL6PzYlCNVfUXc2b7K9ZDxg//xx30Eoz8dXFPi5t),'تخزين المهملة','الفيديو رقم:-',str(TvkL6PzYlCNVfUXc2b7K9ZDxg)+' / '+str(xx30Eoz8dXFPi5t))
			if usJXCitjNLov.iscanceled():
				usJXCitjNLov.close()
				return
		SrdxDoWBLbZyCcs30IPNAe2TujH(rwt1XuZ9OpCTc2lyVGS,'IGNORED',str(U40MCiFH5QoDdn3cX2),wUvcPrYDfISbZolAm83GKEqMyXkn5,pHC2Aj4kbc3KDN0aZWBey6QV)
		TvkL6PzYlCNVfUXc2b7K9ZDxg += 1
	SrdxDoWBLbZyCcs30IPNAe2TujH(rwt1XuZ9OpCTc2lyVGS,'IGNORED','__COUNT__',str(xx30Eoz8dXFPi5t),pHC2Aj4kbc3KDN0aZWBey6QV)
	SrdxDoWBLbZyCcs30IPNAe2TujH(rwt1XuZ9OpCTc2lyVGS,'DUMMY','__DUMMY__','1',pHC2Aj4kbc3KDN0aZWBey6QV)
	usJXCitjNLov.close()
	L5jXH0fZ8TvsESR.sleep(1)
	bJu8zxfX6d2mPDMjKBeCN30 = nn5LrYGPyxcTUMlgEZjVzAINahFmSQ(HAoXLCq8rFjsaPelxNuV,False)
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM+'تم جلب ملفات ـIPTV جديدة'+AAByQSLgaZwCsKnvc5eWNmY+'\n\n'+bJu8zxfX6d2mPDMjKBeCN30)
	osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV)
	N2QCj84D9qInlHveBcf6(False)
	ik374RHsnw0uAgmLBvGSecIPUo8(False)
	return
def EE9dWhRwbCIMn8Ho0Ot(BpAlbchoSTDu1):
	global usJXCitjNLov,ahonYb6Q9ZVzAfpgK40Gw,dd2PRtAcELnmae3vQ,Bt0XhfUejLkHgJzmGDSdxwiIyulsvq,K6KT4HZbF3EONlLyekoGjUY,o8S6NCIcnOlWvdD1hZaVQL,AKvgn98pThrV6WsPQMfR5xm,RniIt5VhuUcpaNfzZ,m3xVdpGMsIwbiX4R1hJzCNyESck
	Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1] = {}
	wVf7NCiI4DSkv6BYTM8ruQLKlE2zU,YV3dmBbTl6M4I5xqj = {},[]
	OAEGpIwfYRBTX2gWhvur8o1jZVk = len(ahonYb6Q9ZVzAfpgK40Gw[BpAlbchoSTDu1])
	Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1]['__COUNT__'] = OAEGpIwfYRBTX2gWhvur8o1jZVk
	if OAEGpIwfYRBTX2gWhvur8o1jZVk>0:
		ylOXK4DI3VJBogrdnxuTHtq7,E6F8cKHBdwotZrR4leihqSuWP,XqT6IeBRmYv3NJa,mAkK83JEwNnxbY1Boygset,d01dPXIEcJYtCBn5zu = zip(*ahonYb6Q9ZVzAfpgK40Gw[BpAlbchoSTDu1])
		del E6F8cKHBdwotZrR4leihqSuWP,XqT6IeBRmYv3NJa,mAkK83JEwNnxbY1Boygset
		gv6i2oMSdEbXeHl = list(set(ylOXK4DI3VJBogrdnxuTHtq7))
		for dlmjGAi0wsYW8Q in gv6i2oMSdEbXeHl:
			wVf7NCiI4DSkv6BYTM8ruQLKlE2zU[dlmjGAi0wsYW8Q] = wUvcPrYDfISbZolAm83GKEqMyXkn5
			Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1][dlmjGAi0wsYW8Q] = []
		snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,60+int(15*RniIt5VhuUcpaNfzZ//m3xVdpGMsIwbiX4R1hJzCNyESck),'تصنيع القوائم','الجزء رقم:-',str(RniIt5VhuUcpaNfzZ)+' / '+str(m3xVdpGMsIwbiX4R1hJzCNyESck))
		if usJXCitjNLov.iscanceled(): return
		RniIt5VhuUcpaNfzZ += 1
		aFue1hZ7igq20M = len(gv6i2oMSdEbXeHl)
		del gv6i2oMSdEbXeHl
		YV3dmBbTl6M4I5xqj = list(set(zip(ylOXK4DI3VJBogrdnxuTHtq7,d01dPXIEcJYtCBn5zu)))
		del ylOXK4DI3VJBogrdnxuTHtq7,d01dPXIEcJYtCBn5zu
		for dlmjGAi0wsYW8Q,lTqParb4mfMHGYXLVOCN3 in YV3dmBbTl6M4I5xqj:
			if not wVf7NCiI4DSkv6BYTM8ruQLKlE2zU[dlmjGAi0wsYW8Q] and lTqParb4mfMHGYXLVOCN3: wVf7NCiI4DSkv6BYTM8ruQLKlE2zU[dlmjGAi0wsYW8Q] = lTqParb4mfMHGYXLVOCN3
		snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,60+int(15*RniIt5VhuUcpaNfzZ//m3xVdpGMsIwbiX4R1hJzCNyESck),'تصنيع القوائم','الجزء رقم:-',str(RniIt5VhuUcpaNfzZ)+' / '+str(m3xVdpGMsIwbiX4R1hJzCNyESck))
		if usJXCitjNLov.iscanceled(): return
		RniIt5VhuUcpaNfzZ += 1
		DkY4lXSFezBc = list(wVf7NCiI4DSkv6BYTM8ruQLKlE2zU.keys())
		x692ziLwCRYvml = list(wVf7NCiI4DSkv6BYTM8ruQLKlE2zU.values())
		del wVf7NCiI4DSkv6BYTM8ruQLKlE2zU
		YV3dmBbTl6M4I5xqj = list(zip(DkY4lXSFezBc,x692ziLwCRYvml))
		del DkY4lXSFezBc,x692ziLwCRYvml
		YV3dmBbTl6M4I5xqj = sorted(YV3dmBbTl6M4I5xqj)
	else: RniIt5VhuUcpaNfzZ += 2
	Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1]['__GROUPS__'] = YV3dmBbTl6M4I5xqj
	del YV3dmBbTl6M4I5xqj
	for dlmjGAi0wsYW8Q,QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in ahonYb6Q9ZVzAfpgK40Gw[BpAlbchoSTDu1]:
		Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1][dlmjGAi0wsYW8Q].append((QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd))
	snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,60+int(15*RniIt5VhuUcpaNfzZ//m3xVdpGMsIwbiX4R1hJzCNyESck),'تصنيع القوائم','الجزء رقم:-',str(RniIt5VhuUcpaNfzZ)+' / '+str(m3xVdpGMsIwbiX4R1hJzCNyESck))
	if usJXCitjNLov.iscanceled(): return
	RniIt5VhuUcpaNfzZ += 1
	del ahonYb6Q9ZVzAfpgK40Gw[BpAlbchoSTDu1]
	o8S6NCIcnOlWvdD1hZaVQL[BpAlbchoSTDu1] = list(Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1].keys())
	K6KT4HZbF3EONlLyekoGjUY[BpAlbchoSTDu1] = len(o8S6NCIcnOlWvdD1hZaVQL[BpAlbchoSTDu1])
	AKvgn98pThrV6WsPQMfR5xm += K6KT4HZbF3EONlLyekoGjUY[BpAlbchoSTDu1]
	return
def XzpdZ8PwgnIc1bu9AS7yQx4Yo(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1):
	global usJXCitjNLov,ahonYb6Q9ZVzAfpgK40Gw,dd2PRtAcELnmae3vQ,Bt0XhfUejLkHgJzmGDSdxwiIyulsvq,K6KT4HZbF3EONlLyekoGjUY,o8S6NCIcnOlWvdD1hZaVQL,AKvgn98pThrV6WsPQMfR5xm,RniIt5VhuUcpaNfzZ,m3xVdpGMsIwbiX4R1hJzCNyESck
	rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1)
	for FFmkB3hOineTAdNMsLl in range(1+K6KT4HZbF3EONlLyekoGjUY[BpAlbchoSTDu1]//273):
		ICvei9rVfOSnTk = []
		KGVeTEam08tZIgij6qc1C2xMD = o8S6NCIcnOlWvdD1hZaVQL[BpAlbchoSTDu1][0:273]
		for dlmjGAi0wsYW8Q in KGVeTEam08tZIgij6qc1C2xMD:
			ICvei9rVfOSnTk.append(Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1][dlmjGAi0wsYW8Q])
		SrdxDoWBLbZyCcs30IPNAe2TujH(rwt1XuZ9OpCTc2lyVGS,BpAlbchoSTDu1,KGVeTEam08tZIgij6qc1C2xMD,ICvei9rVfOSnTk,pHC2Aj4kbc3KDN0aZWBey6QV,True)
		dd2PRtAcELnmae3vQ += len(KGVeTEam08tZIgij6qc1C2xMD)
		snqyW34dKikc8eHXJIxDbuzSUtLf(usJXCitjNLov,75+int(20*dd2PRtAcELnmae3vQ//AKvgn98pThrV6WsPQMfR5xm),'تخزين القوائم','القائمة رقم:-',str(dd2PRtAcELnmae3vQ)+' / '+str(AKvgn98pThrV6WsPQMfR5xm))
		if usJXCitjNLov.iscanceled(): return
		del o8S6NCIcnOlWvdD1hZaVQL[BpAlbchoSTDu1][0:273]
	del Bt0XhfUejLkHgJzmGDSdxwiIyulsvq[BpAlbchoSTDu1],o8S6NCIcnOlWvdD1hZaVQL[BpAlbchoSTDu1],K6KT4HZbF3EONlLyekoGjUY[BpAlbchoSTDu1]
	return
def nn5LrYGPyxcTUMlgEZjVzAINahFmSQ(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2=True):
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2): return
	kJaqOBMf8gb = mvVFtPw8JKpaUdXq06YrEeR7bAk2
	bH8xM2fckGACQwe = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,'LIVE_ORIGINAL_GROUPED')
	ONaLejMv9fRbPcWyXJ = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,'VOD_ORIGINAL_GROUPED')
	xx30Eoz8dXFPi5t = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','IGNORED','__COUNT__')
	WWj6nKFRsw = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	PZXqe12QIbd96zEJgroMkjyucBsDS5 = o1oqytTs5j0rx(ONaLejMv9fRbPcWyXJ,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	PNhvKdBSqepf8R2QFnD3rwE7bgxWXH = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','LIVE_GROUPED','__COUNT__')
	NNuYHqR8DePixLU9Cd1mw6pnl = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	y7qr5gZbUVv0HGJFaWM9 = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','VOD_MOVIES_GROUPED','__COUNT__')
	XOykIGZ2MW7aJzt8 = o1oqytTs5j0rx(ONaLejMv9fRbPcWyXJ,'int','VOD_SERIES_GROUPED','__COUNT__')
	wq2MPR1cbkN = o1oqytTs5j0rx(bH8xM2fckGACQwe,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	o8S6NCIcnOlWvdD1hZaVQL = o1oqytTs5j0rx(ONaLejMv9fRbPcWyXJ,'list','VOD_SERIES_GROUPED','__GROUPS__')
	oWutOsHXMCRA9 = []
	for dlmjGAi0wsYW8Q,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in o8S6NCIcnOlWvdD1hZaVQL:
		muvE1FIBODYh9Ti4PnlxG = dlmjGAi0wsYW8Q.split('__SERIES__')[1]
		oWutOsHXMCRA9.append(muvE1FIBODYh9Ti4PnlxG)
	zzHhL4FxUDbCYQWqco2yRj5Edg = len(oWutOsHXMCRA9)
	m1AwOzcEFSY = int(y7qr5gZbUVv0HGJFaWM9)+int(XOykIGZ2MW7aJzt8)+int(wq2MPR1cbkN)+int(NNuYHqR8DePixLU9Cd1mw6pnl)+int(PNhvKdBSqepf8R2QFnD3rwE7bgxWXH)
	bJu8zxfX6d2mPDMjKBeCN30 = wUvcPrYDfISbZolAm83GKEqMyXkn5
	bJu8zxfX6d2mPDMjKBeCN30 += 'قنوات: '+str(PNhvKdBSqepf8R2QFnD3rwE7bgxWXH)
	bJu8zxfX6d2mPDMjKBeCN30 += '   .   أفلام: '+str(y7qr5gZbUVv0HGJFaWM9)
	bJu8zxfX6d2mPDMjKBeCN30 += '\nمسلسلات: '+str(zzHhL4FxUDbCYQWqco2yRj5Edg)
	bJu8zxfX6d2mPDMjKBeCN30 += '   .   حلقات: '+str(XOykIGZ2MW7aJzt8)
	bJu8zxfX6d2mPDMjKBeCN30 += '\nقنوات مجهولة: '+str(NNuYHqR8DePixLU9Cd1mw6pnl)
	bJu8zxfX6d2mPDMjKBeCN30 += '   .   فيدوهات مجهولة: '+str(wq2MPR1cbkN)
	bJu8zxfX6d2mPDMjKBeCN30 += '\nمجموع القنوات: '+str(WWj6nKFRsw)
	bJu8zxfX6d2mPDMjKBeCN30 += '   .   مجموع الفيديوهات: '+str(PZXqe12QIbd96zEJgroMkjyucBsDS5)
	bJu8zxfX6d2mPDMjKBeCN30 += '\n\nمجموع المضافة: '+str(m1AwOzcEFSY)
	bJu8zxfX6d2mPDMjKBeCN30 += '   .   مجموع المهملة: '+str(xx30Eoz8dXFPi5t)
	if nOwDh0x3sa4FilJCPrWAI2: IUaTPEbvz0powmgNSFn4fQhLKRiZ6('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,kJaqOBMf8gb,bJu8zxfX6d2mPDMjKBeCN30)
	fePz97DtNbHSI4BvCiOjnqV = bJu8zxfX6d2mPDMjKBeCN30.replace('\n\n',QWLr8ABjev)
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,'.\tCounts of IPTV videos   Folder: '+HAoXLCq8rFjsaPelxNuV+QWLr8ABjev+fePz97DtNbHSI4BvCiOjnqV)
	return bJu8zxfX6d2mPDMjKBeCN30
def MMtqGunbXfZDNcQvmH(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2=True):
	if nOwDh0x3sa4FilJCPrWAI2:
		ckzdJmPICTwop = T4dIruOctCl2qwYNE0SDyU('center',wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if ckzdJmPICTwop!=1: return
		ZDTgGOuUiW0R = WsgH5OuS41JkZFoRACamNI72jGepln.replace('___','_'+HAoXLCq8rFjsaPelxNuV)
		try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(ZDTgGOuUiW0R)
		except: pass
	ZDTgGOuUiW0R = IH5yWt0FUviS3LRjA2qxJZhQ.replace('___','_'+HAoXLCq8rFjsaPelxNuV)
	try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(ZDTgGOuUiW0R)
	except: pass
	ZDTgGOuUiW0R = ALDNgiYC67Fw8nIMT.replace('___','_'+HAoXLCq8rFjsaPelxNuV)
	try: b7i1PgC8Z4e5BFoHNd9E2UVvfc.remove(ZDTgGOuUiW0R)
	except: pass
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'SECTIONS_IPTV','SECTIONS_IPTV_'+HAoXLCq8rFjsaPelxNuV)
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	N2QCj84D9qInlHveBcf6(False)
	osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV)
	if nOwDh0x3sa4FilJCPrWAI2:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'تم مسح جميع ملفات ـIPTV')
		ik374RHsnw0uAgmLBvGSecIPUo8(False)
	return
def lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV=wUvcPrYDfISbZolAm83GKEqMyXkn5,nOwDh0x3sa4FilJCPrWAI2=True):
	if HAoXLCq8rFjsaPelxNuV:
		rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(str(HAoXLCq8rFjsaPelxNuV),'DUMMY')
		vvbZFGz0gj2pLUXVf3yBsH = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'str','DUMMY','__DUMMY__')
		if vvbZFGz0gj2pLUXVf3yBsH: return True
	else:
		HAoXLCq8rFjsaPelxNuV = '1'
		for JEy25ozwY3qhlUP7msWMTH1ktB0NcS in range(1,ZwUoEtfGv7J6+1):
			rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(str(JEy25ozwY3qhlUP7msWMTH1ktB0NcS),'DUMMY')
			vvbZFGz0gj2pLUXVf3yBsH = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'str','DUMMY','__DUMMY__')
			if vvbZFGz0gj2pLUXVf3yBsH: return True
	if nOwDh0x3sa4FilJCPrWAI2:
		IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+JegF7SlMawI03+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+AAByQSLgaZwCsKnvc5eWNmY)
		kJaqOBMf8gb = 'إضافة وتغيير رابط '+HiqZ1R8GXDtUzSu[1]+' (مجلد '+HiqZ1R8GXDtUzSu[int(HAoXLCq8rFjsaPelxNuV)]+')'
		ckzdJmPICTwop = T4dIruOctCl2qwYNE0SDyU(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,kJaqOBMf8gb,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if ckzdJmPICTwop==1: BZ8sYcn1yxSe9fqTbmjM2lE(HAoXLCq8rFjsaPelxNuV)
	return False
def zxTXK1GQm2WUob7AcwCIB0tfS5jNPy(aAxmj9XyWftkIr3PhTJLDQqlR,HAoXLCq8rFjsaPelxNuV=wUvcPrYDfISbZolAm83GKEqMyXkn5,BpAlbchoSTDu1=wUvcPrYDfISbZolAm83GKEqMyXkn5,JhbEGQTfy9tH2nRzWO5eKAucIa=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not JhbEGQTfy9tH2nRzWO5eKAucIa: JhbEGQTfy9tH2nRzWO5eKAucIa = '1'
	vli6AtMjqfwmKnP0z1E,hg4F23dunEM56UpCOBk1IzoKHiwXe,nOwDh0x3sa4FilJCPrWAI2 = PLaXN4KSfzcmyu3(aAxmj9XyWftkIr3PhTJLDQqlR)
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2): return
	if not vli6AtMjqfwmKnP0z1E:
		vli6AtMjqfwmKnP0z1E = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not vli6AtMjqfwmKnP0z1E: return
	IGThDPsVrf2jtWX0pe5UaE3 = [wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not BpAlbchoSTDu1:
		if not nOwDh0x3sa4FilJCPrWAI2:
			if   '_IPTV-LIVE_' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[1]
			elif '_IPTV-MOVIES' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[2]
			elif '_IPTV-SERIES' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[3]
			else: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[0]
		else:
			IMRueF9PE2j = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			dcDaPVjr5uyEntR4HFqSb = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('أختر البحث المناسب', IMRueF9PE2j)
			if dcDaPVjr5uyEntR4HFqSb==-1: return
			BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[dcDaPVjr5uyEntR4HFqSb]
	vli6AtMjqfwmKnP0z1E = vli6AtMjqfwmKnP0z1E+'_NODIALOGS_'
	if HAoXLCq8rFjsaPelxNuV: o93oeyjBgAdiDGNu1ZkJm5XbKn6q(vli6AtMjqfwmKnP0z1E,HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1,JhbEGQTfy9tH2nRzWO5eKAucIa)
	else:
		for HAoXLCq8rFjsaPelxNuV in range(1,ZwUoEtfGv7J6+1):
			o93oeyjBgAdiDGNu1ZkJm5XbKn6q(vli6AtMjqfwmKnP0z1E,str(HAoXLCq8rFjsaPelxNuV),BpAlbchoSTDu1,JhbEGQTfy9tH2nRzWO5eKAucIa)
		TTuO14NzmB.menuItemsLIST[:] = sorted(TTuO14NzmB.menuItemsLIST,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV[1].lower())
	return
def o93oeyjBgAdiDGNu1ZkJm5XbKn6q(aAxmj9XyWftkIr3PhTJLDQqlR,HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1=wUvcPrYDfISbZolAm83GKEqMyXkn5,JhbEGQTfy9tH2nRzWO5eKAucIa=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not JhbEGQTfy9tH2nRzWO5eKAucIa: JhbEGQTfy9tH2nRzWO5eKAucIa = '1'
	vli6AtMjqfwmKnP0z1E,hg4F23dunEM56UpCOBk1IzoKHiwXe,nOwDh0x3sa4FilJCPrWAI2 = PLaXN4KSfzcmyu3(aAxmj9XyWftkIr3PhTJLDQqlR)
	if not HAoXLCq8rFjsaPelxNuV: return
	if not lu7ViXewzT4jtDacZKNnF2(HAoXLCq8rFjsaPelxNuV,nOwDh0x3sa4FilJCPrWAI2): return
	if not vli6AtMjqfwmKnP0z1E:
		vli6AtMjqfwmKnP0z1E = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
		if not vli6AtMjqfwmKnP0z1E: return
	IGThDPsVrf2jtWX0pe5UaE3 = [wUvcPrYDfISbZolAm83GKEqMyXkn5,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not BpAlbchoSTDu1:
		if not nOwDh0x3sa4FilJCPrWAI2:
			if   '_IPTV-LIVE_' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[1]
			elif '_IPTV-MOVIES' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[2]
			elif '_IPTV-SERIES' in hg4F23dunEM56UpCOBk1IzoKHiwXe: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[3]
			else: BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[0]
		else:
			IMRueF9PE2j = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			dcDaPVjr5uyEntR4HFqSb = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('أختر البحث المناسب', IMRueF9PE2j)
			if dcDaPVjr5uyEntR4HFqSb==-1: return
			BpAlbchoSTDu1 = IGThDPsVrf2jtWX0pe5UaE3[dcDaPVjr5uyEntR4HFqSb]
	kv6aAF2YeyzBx5MUZb7Gsg = vli6AtMjqfwmKnP0z1E.lower()
	rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,'SEARCH')
	lKT2nBXgyoJcN8m4 = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list','SEARCH',(BpAlbchoSTDu1,kv6aAF2YeyzBx5MUZb7Gsg))
	if not lKT2nBXgyoJcN8m4:
		XVpLuAMklb2Gx6v4dFW9K3rR,OgVWM8t2iE4luHxBy = [],[]
		if not BpAlbchoSTDu1: ocv0lz4r6YIyt = [1,2,3,4,5]
		else: ocv0lz4r6YIyt = [IGThDPsVrf2jtWX0pe5UaE3.index(BpAlbchoSTDu1)]
		for TvkL6PzYlCNVfUXc2b7K9ZDxg in ocv0lz4r6YIyt:
			rwt1XuZ9OpCTc2lyVGS = N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,IGThDPsVrf2jtWX0pe5UaE3[TvkL6PzYlCNVfUXc2b7K9ZDxg])
			if TvkL6PzYlCNVfUXc2b7K9ZDxg!=3:
				rm2P4OqXgZJzeuTdicbl6xH7tU = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'dict',IGThDPsVrf2jtWX0pe5UaE3[TvkL6PzYlCNVfUXc2b7K9ZDxg])
				del rm2P4OqXgZJzeuTdicbl6xH7tU['__COUNT__']
				del rm2P4OqXgZJzeuTdicbl6xH7tU['__GROUPS__']
				del rm2P4OqXgZJzeuTdicbl6xH7tU['__SEQUENCED_COLUMNS__']
				o8S6NCIcnOlWvdD1hZaVQL = list(rm2P4OqXgZJzeuTdicbl6xH7tU.keys())
				for dlmjGAi0wsYW8Q in o8S6NCIcnOlWvdD1hZaVQL:
					for QeJRmBObzgiL8ZsvqXF1IlEKY4Gxa,mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in rm2P4OqXgZJzeuTdicbl6xH7tU[dlmjGAi0wsYW8Q]:
						if kv6aAF2YeyzBx5MUZb7Gsg in mAefRpNJ9SQdL1WnXsGykrKg.lower(): OgVWM8t2iE4luHxBy.append((mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd))
					del rm2P4OqXgZJzeuTdicbl6xH7tU[dlmjGAi0wsYW8Q]
				del rm2P4OqXgZJzeuTdicbl6xH7tU
			else: o8S6NCIcnOlWvdD1hZaVQL = o1oqytTs5j0rx(rwt1XuZ9OpCTc2lyVGS,'list',IGThDPsVrf2jtWX0pe5UaE3[TvkL6PzYlCNVfUXc2b7K9ZDxg],'__GROUPS__')
			for dlmjGAi0wsYW8Q in o8S6NCIcnOlWvdD1hZaVQL:
				try: dlmjGAi0wsYW8Q,v9hnfDaTXN5OLwiQS07CHr2qo3Yd = dlmjGAi0wsYW8Q
				except: v9hnfDaTXN5OLwiQS07CHr2qo3Yd = wUvcPrYDfISbZolAm83GKEqMyXkn5
				if kv6aAF2YeyzBx5MUZb7Gsg in dlmjGAi0wsYW8Q.lower():
					if TvkL6PzYlCNVfUXc2b7K9ZDxg!=3: AA7MadzshQtJ = dlmjGAi0wsYW8Q
					else:
						PKFauI312LUQnWt6XfD0A,Mfmj4kz8ht = dlmjGAi0wsYW8Q.split('__SERIES__')
						if kv6aAF2YeyzBx5MUZb7Gsg in PKFauI312LUQnWt6XfD0A.lower(): AA7MadzshQtJ = PKFauI312LUQnWt6XfD0A
						else: AA7MadzshQtJ = Mfmj4kz8ht
					XVpLuAMklb2Gx6v4dFW9K3rR.append((dlmjGAi0wsYW8Q,AA7MadzshQtJ,IGThDPsVrf2jtWX0pe5UaE3[TvkL6PzYlCNVfUXc2b7K9ZDxg],v9hnfDaTXN5OLwiQS07CHr2qo3Yd))
			del o8S6NCIcnOlWvdD1hZaVQL
		XVpLuAMklb2Gx6v4dFW9K3rR = set(XVpLuAMklb2Gx6v4dFW9K3rR)
		OgVWM8t2iE4luHxBy = set(OgVWM8t2iE4luHxBy)
		XVpLuAMklb2Gx6v4dFW9K3rR = sorted(XVpLuAMklb2Gx6v4dFW9K3rR,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV[1])
		OgVWM8t2iE4luHxBy = sorted(OgVWM8t2iE4luHxBy,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV[0])
		SrdxDoWBLbZyCcs30IPNAe2TujH(rwt1XuZ9OpCTc2lyVGS,'SEARCH',(BpAlbchoSTDu1,kv6aAF2YeyzBx5MUZb7Gsg),(XVpLuAMklb2Gx6v4dFW9K3rR,OgVWM8t2iE4luHxBy),pHC2Aj4kbc3KDN0aZWBey6QV)
	else: XVpLuAMklb2Gx6v4dFW9K3rR,OgVWM8t2iE4luHxBy = lKT2nBXgyoJcN8m4
	o8S6NCIcnOlWvdD1hZaVQL = len(XVpLuAMklb2Gx6v4dFW9K3rR)
	wwY9sTnUHupJIMkS6qcgOAt8VWD3 = len(OgVWM8t2iE4luHxBy)
	G02Gb6uxEgT39wNCJvefMzmFI = int(JhbEGQTfy9tH2nRzWO5eKAucIa)
	xYvq5psgRoUiABDy8 = max(0,(G02Gb6uxEgT39wNCJvefMzmFI-1)*100)
	iXYLUDv2oZlt = max(0,G02Gb6uxEgT39wNCJvefMzmFI*100)
	e1mMWD7z5Qtr2dXIyv = max(0,xYvq5psgRoUiABDy8-o8S6NCIcnOlWvdD1hZaVQL)
	bsWvPipVHjGqEJck8RF0AmK = max(0,iXYLUDv2oZlt-o8S6NCIcnOlWvdD1hZaVQL)
	for dlmjGAi0wsYW8Q,AA7MadzshQtJ,vKgrHcMq5CGkaXjiZnfdw2D,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in XVpLuAMklb2Gx6v4dFW9K3rR[xYvq5psgRoUiABDy8:iXYLUDv2oZlt]:
		mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+AA7MadzshQtJ,vKgrHcMq5CGkaXjiZnfdw2D,234,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,'1',dlmjGAi0wsYW8Q,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	del XVpLuAMklb2Gx6v4dFW9K3rR
	for mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,v9hnfDaTXN5OLwiQS07CHr2qo3Yd in OgVWM8t2iE4luHxBy[e1mMWD7z5Qtr2dXIyv:bsWvPipVHjGqEJck8RF0AmK]:
		uqRdhBKgzeJ1ij8 = rjZFa0VMBuPRHg1cIYJpd52oxl4(iE0GxkBnVRO4NPwleT)
		TAlYNXgaM4qzdtVUZKiubvs = 'live'
		if '.mkv' in uqRdhBKgzeJ1ij8 or 'VOD' in BpAlbchoSTDu1: TAlYNXgaM4qzdtVUZKiubvs = 'video'
		mwOxEyYAg63B(TAlYNXgaM4qzdtVUZKiubvs,ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,235,v9hnfDaTXN5OLwiQS07CHr2qo3Yd,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	del OgVWM8t2iE4luHxBy
	elP8drN1Ati4K(HAoXLCq8rFjsaPelxNuV,JhbEGQTfy9tH2nRzWO5eKAucIa,BpAlbchoSTDu1,239,o8S6NCIcnOlWvdD1hZaVQL+wwY9sTnUHupJIMkS6qcgOAt8VWD3,vli6AtMjqfwmKnP0z1E+'_NODIALOGS_')
	return
def elP8drN1Ati4K(HAoXLCq8rFjsaPelxNuV,JhbEGQTfy9tH2nRzWO5eKAucIa,BpAlbchoSTDu1,ooPMZSnrRDG6xNpJHVmgw8IOA1,m1AwOzcEFSY,eIRJAgj25bzvNik48puZl3OPUq):
	if JhbEGQTfy9tH2nRzWO5eKAucIa!='1': mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'صفحة '+str(1),BpAlbchoSTDu1,ooPMZSnrRDG6xNpJHVmgw8IOA1,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(1),eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	if not m1AwOzcEFSY: m1AwOzcEFSY = 0
	bN5cadLEKygADnxfQp4PF = int(m1AwOzcEFSY/100)+1
	for G02Gb6uxEgT39wNCJvefMzmFI in range(2,bN5cadLEKygADnxfQp4PF):
		baRLnWg1Yr56mu0KH = (G02Gb6uxEgT39wNCJvefMzmFI%10==0 or int(JhbEGQTfy9tH2nRzWO5eKAucIa)-4<G02Gb6uxEgT39wNCJvefMzmFI<int(JhbEGQTfy9tH2nRzWO5eKAucIa)+4)
		Ftwnbv3CipUfB8lzAL9hPJIyE = (baRLnWg1Yr56mu0KH and int(JhbEGQTfy9tH2nRzWO5eKAucIa)-40<G02Gb6uxEgT39wNCJvefMzmFI<int(JhbEGQTfy9tH2nRzWO5eKAucIa)+40)
		if str(G02Gb6uxEgT39wNCJvefMzmFI)!=JhbEGQTfy9tH2nRzWO5eKAucIa and (G02Gb6uxEgT39wNCJvefMzmFI%100==0 or Ftwnbv3CipUfB8lzAL9hPJIyE):
			mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'صفحة '+str(G02Gb6uxEgT39wNCJvefMzmFI),BpAlbchoSTDu1,ooPMZSnrRDG6xNpJHVmgw8IOA1,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(G02Gb6uxEgT39wNCJvefMzmFI),eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	if str(bN5cadLEKygADnxfQp4PF)!=JhbEGQTfy9tH2nRzWO5eKAucIa: mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+'أخر صفحة '+str(bN5cadLEKygADnxfQp4PF),BpAlbchoSTDu1,ooPMZSnrRDG6xNpJHVmgw8IOA1,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(bN5cadLEKygADnxfQp4PF),eIRJAgj25bzvNik48puZl3OPUq,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	return
def N6iKMmJf7kcGYEoCOPw(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1):
	if 'SERIES' in BpAlbchoSTDu1 or 'VOD_ORIGINAL' in BpAlbchoSTDu1: rwt1XuZ9OpCTc2lyVGS = ALDNgiYC67Fw8nIMT
	else: rwt1XuZ9OpCTc2lyVGS = IH5yWt0FUviS3LRjA2qxJZhQ
	rwt1XuZ9OpCTc2lyVGS = rwt1XuZ9OpCTc2lyVGS.replace('___','_'+HAoXLCq8rFjsaPelxNuV)
	return rwt1XuZ9OpCTc2lyVGS
def yH4AvMncjt17xu0GCsL59zQFD(HAoXLCq8rFjsaPelxNuV,BpAlbchoSTDu1,n2b8tFjHw9Q):
	p8bzkQ1hP6aUjrRC3DMi,tyfzs0SaXoUr,b3bhiw0MFS6rDjlufy8,uW9I6hGBzEbNprvYJ50MQHR,u7YQljRpaBeTZxUd = Q5CIzwHAy7XG62n40(HAoXLCq8rFjsaPelxNuV)
	if not uW9I6hGBzEbNprvYJ50MQHR: return
	DDPMgjZIuk = maZGulCg9DRBrYW4HM1tjk6L3(HAoXLCq8rFjsaPelxNuV)
	if   BpAlbchoSTDu1=='XTREAM_LIVE_GROUPS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_live_categories'
	elif BpAlbchoSTDu1=='XTREAM_VOD_GROUPS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_vod_categories'
	elif BpAlbchoSTDu1=='XTREAM_SERIES_GROUPS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_series_categories'
	elif BpAlbchoSTDu1=='XTREAM_LIVE_ITEMS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_live_streams&category_id='+n2b8tFjHw9Q
	elif BpAlbchoSTDu1=='XTREAM_VOD_ITEMS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_vod_streams&category_id='+n2b8tFjHw9Q
	elif BpAlbchoSTDu1=='XTREAM_SERIES_ITEMS': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_series&category_id='+n2b8tFjHw9Q
	elif BpAlbchoSTDu1=='XTREAM_EPISODES': iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi+'&action=get_series_info&series_id='+n2b8tFjHw9Q
	else: return
	yBn638aQbxUdpCSA = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',iE0GxkBnVRO4NPwleT,wUvcPrYDfISbZolAm83GKEqMyXkn5,DDPMgjZIuk,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'IPTV-XTREAM_MENUS-1st')
	V6aTvut7ocyb = yBn638aQbxUdpCSA.content
	if ndib93Ol6UojCrEV: V6aTvut7ocyb = V6aTvut7ocyb.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	JVfbkMOSoNF6z3Y24wA8a75qmERc = dm7KA8MukvxF3iH9CW2ZNc('list',V6aTvut7ocyb)
	if 'GROUPS' in BpAlbchoSTDu1:
		BpAlbchoSTDu1 = BpAlbchoSTDu1.replace('_GROUPS','_ITEMS')
		JVfbkMOSoNF6z3Y24wA8a75qmERc = sorted(JVfbkMOSoNF6z3Y24wA8a75qmERc,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV['category_name'].lower())
		for dlmjGAi0wsYW8Q in JVfbkMOSoNF6z3Y24wA8a75qmERc:
			d0yrGP8JuBH = dlmjGAi0wsYW8Q['category_id']
			mAefRpNJ9SQdL1WnXsGykrKg = dlmjGAi0wsYW8Q['category_name']
			mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,BpAlbchoSTDu1,285,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(d0yrGP8JuBH),wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	elif BpAlbchoSTDu1=='XTREAM_SERIES_ITEMS':
		JVfbkMOSoNF6z3Y24wA8a75qmERc = sorted(JVfbkMOSoNF6z3Y24wA8a75qmERc,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV['name'].lower())
		for CiEbkzDWGQJwm in JVfbkMOSoNF6z3Y24wA8a75qmERc:
			mAefRpNJ9SQdL1WnXsGykrKg = CiEbkzDWGQJwm['name']
			lTqParb4mfMHGYXLVOCN3 = CiEbkzDWGQJwm['cover']
			d0yrGP8JuBH = CiEbkzDWGQJwm['series_id']
			mwOxEyYAg63B('folder',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,'XTREAM_EPISODES',285,lTqParb4mfMHGYXLVOCN3,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(d0yrGP8JuBH),wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	elif BpAlbchoSTDu1=='XTREAM_EPISODES':
		lTqParb4mfMHGYXLVOCN3 = JVfbkMOSoNF6z3Y24wA8a75qmERc['info']['cover']
		LcukPqj3x6f9WDZQh5YJzg = JVfbkMOSoNF6z3Y24wA8a75qmERc['info']['name']
		WngYA2G1KjoS6q = JVfbkMOSoNF6z3Y24wA8a75qmERc['episodes']
		for hDLoTpO73SvZIH6k29zYf in WngYA2G1KjoS6q:
			aamzVqdG94xivEPLYu0whc3ZRFSAj = WngYA2G1KjoS6q[hDLoTpO73SvZIH6k29zYf]
			for bhLcpAJ1BxD2wKuTgt9XQmd7 in aamzVqdG94xivEPLYu0whc3ZRFSAj:
				mAefRpNJ9SQdL1WnXsGykrKg = bhLcpAJ1BxD2wKuTgt9XQmd7['title']
				YF5nqJ18Sftud = jj0dZrgiKb.findall('\d+.(S\d+E\d+)',mAefRpNJ9SQdL1WnXsGykrKg,jj0dZrgiKb.DOTALL)
				if YF5nqJ18Sftud: mAefRpNJ9SQdL1WnXsGykrKg = LcukPqj3x6f9WDZQh5YJzg+UKFZBQAVXHI5s17LyvuRpCY2+YF5nqJ18Sftud[0]
				d0yrGP8JuBH = bhLcpAJ1BxD2wKuTgt9XQmd7['id']
				a97yTg5QECFcDN = bhLcpAJ1BxD2wKuTgt9XQmd7['container_extension']
				iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi.split('/player_api.php')[0]+'/series/'+uW9I6hGBzEbNprvYJ50MQHR+'/'+u7YQljRpaBeTZxUd+'/'+str(d0yrGP8JuBH)+'.'+a97yTg5QECFcDN
				mwOxEyYAg63B('video',ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,235,lTqParb4mfMHGYXLVOCN3,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	elif 'ITEMS' in BpAlbchoSTDu1:
		TAlYNXgaM4qzdtVUZKiubvs = 'live' if 'LIVE' in BpAlbchoSTDu1 else 'video'
		JVfbkMOSoNF6z3Y24wA8a75qmERc = sorted(JVfbkMOSoNF6z3Y24wA8a75qmERc,reverse=False,key=lambda j5eZi43FxprNKqGoQz1tV: j5eZi43FxprNKqGoQz1tV['name'].lower())
		for Kl1o78NZjCfJ in JVfbkMOSoNF6z3Y24wA8a75qmERc:
			mAefRpNJ9SQdL1WnXsGykrKg = Kl1o78NZjCfJ['name']
			lTqParb4mfMHGYXLVOCN3 = Kl1o78NZjCfJ['stream_icon']
			d0yrGP8JuBH = Kl1o78NZjCfJ['stream_id']
			try:
				a97yTg5QECFcDN = Kl1o78NZjCfJ['container_extension']
				if a97yTg5QECFcDN: a97yTg5QECFcDN = '.'+a97yTg5QECFcDN
			except: a97yTg5QECFcDN = wUvcPrYDfISbZolAm83GKEqMyXkn5
			if Kl1o78NZjCfJ['stream_type']=='live': xNl6RiITCUD2V1zgF0jrEa97b58n,nra3iY92KRJBsujg7zFPANxM1VHq = wUvcPrYDfISbZolAm83GKEqMyXkn5,'live'
			elif Kl1o78NZjCfJ['stream_type']=='movie': xNl6RiITCUD2V1zgF0jrEa97b58n,nra3iY92KRJBsujg7zFPANxM1VHq = 'movie/','video'
			iE0GxkBnVRO4NPwleT = p8bzkQ1hP6aUjrRC3DMi.split('/player_api.php')[0]+'/'+xNl6RiITCUD2V1zgF0jrEa97b58n+uW9I6hGBzEbNprvYJ50MQHR+'/'+u7YQljRpaBeTZxUd+'/'+str(d0yrGP8JuBH)+a97yTg5QECFcDN
			mwOxEyYAg63B(TAlYNXgaM4qzdtVUZKiubvs,ANaRC3c914UdxDrFM+mAefRpNJ9SQdL1WnXsGykrKg,iE0GxkBnVRO4NPwleT,235,lTqParb4mfMHGYXLVOCN3,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,{'folder':HAoXLCq8rFjsaPelxNuV})
	return
def osx1fZv4A0P8ntk(HAoXLCq8rFjsaPelxNuV):
	nf9YquKAaIstM1B8WvhXLogHTUxi = OOnvcPQy85HYA.getSetting('av.language.provider')
	I1qJPnQey6HXU750DapsEtZdcgofA9 = OOnvcPQy85HYA.getSetting('av.language.code')
	P4B0tvUAVOb5K(bcP2jUx34tG51D6XSNnyWIes,'MENUS_CACHE_'+nf9YquKAaIstM1B8WvhXLogHTUxi+'_'+I1qJPnQey6HXU750DapsEtZdcgofA9,'%_IP'+HAoXLCq8rFjsaPelxNuV+'_%')
	return