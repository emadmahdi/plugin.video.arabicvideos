# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
import bs4 as vWqXEt9hcYxr
UdbRGoKhcDeI4lVfns5 = 'ELCINEMA'
UT69hgqoKsWNIwM5zkAYb = '_ELC_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
headers = {'Referer':hhD7r1VvaPt3TC06SJjqKRfEid}
i6TIRax9v0EDFJs2gVtfzp = []
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==510: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==511: RCmHBOKtejQ8lu4L = UtA76EwvxI(url)
	elif mode==512: RCmHBOKtejQ8lu4L = uCrYKsfnd0Qeq24l31wAV(url)
	elif mode==513: RCmHBOKtejQ8lu4L = dg94cNfleOm1ZkXE0(url)
	elif mode==514: RCmHBOKtejQ8lu4L = dORtxvGBhXAsu3qZF7(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: RCmHBOKtejQ8lu4L = dORtxvGBhXAsu3qZF7(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: RCmHBOKtejQ8lu4L = HHwhAXxP0rMvzpn4t(text)
	elif mode==517: RCmHBOKtejQ8lu4L = MUBHzpg4tYrQa98IAhO(url)
	elif mode==518: RCmHBOKtejQ8lu4L = HHshTJmLE8(url)
	elif mode==519: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	elif mode==520: RCmHBOKtejQ8lu4L = gcpLiKnkVxGvT(url)
	elif mode==521: RCmHBOKtejQ8lu4L = b7YiIvAgul(url)
	elif mode==522: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==523: RCmHBOKtejQ8lu4L = u09ud3ec2wpv(text)
	elif mode==524: RCmHBOKtejQ8lu4L = chk2tzViCIDjWYO9Zg()
	elif mode==525: RCmHBOKtejQ8lu4L = mudoZXhpAB9MyJb0e1D()
	elif mode==526: RCmHBOKtejQ8lu4L = ur2vNdEIF3HDhpKfMP8ZOYwjR()
	elif mode==527: RCmHBOKtejQ8lu4L = gBLQm7KqVJhYH()
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث بموسوعة السينما',wUvcPrYDfISbZolAm83GKEqMyXkn5,519)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'موسوعة الأعمال',wUvcPrYDfISbZolAm83GKEqMyXkn5,525)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'موسوعة الأشخاص',wUvcPrYDfISbZolAm83GKEqMyXkn5,526)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'موسوعة المصنفات',wUvcPrYDfISbZolAm83GKEqMyXkn5,527)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'موسوعة المنوعات',wUvcPrYDfISbZolAm83GKEqMyXkn5,524)
	return
def chk2tzViCIDjWYO9Zg():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' فيديوهات - خاصة',hhD7r1VvaPt3TC06SJjqKRfEid+'/video',520)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فيديوهات - أحدث',hhD7r1VvaPt3TC06SJjqKRfEid+'/video/latest',521)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فيديوهات - أقدم',hhD7r1VvaPt3TC06SJjqKRfEid+'/video/oldest',521)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فيديوهات - أكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid+'/video/views',521)
	return
def mudoZXhpAB9MyJb0e1D():
	AAxvzjDdLKQcSRG8XtYZ = hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup?utf8=%E2%9C%93'
	xxrFMhvSm47QPjTG2y9q8b = AAxvzjDdLKQcSRG8XtYZ+'&type=2&category=1&foreign=false&tag='
	Xq1lsMIy4oB7Vgx = AAxvzjDdLKQcSRG8XtYZ+'&type=2&category=3&foreign=false&tag='
	UUkDCV82lXvZG6gtiMfIPmA3J = AAxvzjDdLKQcSRG8XtYZ+'&type=2&category=1&foreign=true&tag='
	AgfTarbEXsi1RlW = AAxvzjDdLKQcSRG8XtYZ+'&type=2&category=3&foreign=true&tag='
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات أفلام عربي',xxrFMhvSm47QPjTG2y9q8b,511)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات مسلسلات عربي',Xq1lsMIy4oB7Vgx,511)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات أفلام اجنبي',UUkDCV82lXvZG6gtiMfIPmA3J,511)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات مسلسلات اجنبي',AgfTarbEXsi1RlW,511)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس أعمال أبجدي',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/work/alphabet',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس  بلد الإنتاج',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/work/country',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس اللغة',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/work/language',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس مصنفات العمل',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/work/genre',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس سنة الإصدار',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/work/release_year',517)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مواسم - فلتر محدد',hhD7r1VvaPt3TC06SJjqKRfEid+'/seasonals',515)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مواسم - فلتر كامل',hhD7r1VvaPt3TC06SJjqKRfEid+'/seasonals',514)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات - فلتر محدد',hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup',515)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات - فلتر كامل',hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup',514)
	return
def gBLQm7KqVJhYH():
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup',wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	IJE2xcV7OWauUKhfik56gXBwltCb = o3odtVgZJha0qjk8MeF6KW.find('select',attrs={'name':'tag'})
	plQAPdho26aj = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('option')
	for sslNS0zetni1HDbZRQOCMxJ4AfhaP in plQAPdho26aj:
		value = sslNS0zetni1HDbZRQOCMxJ4AfhaP.get('value')
		if not value: continue
		title = sslNS0zetni1HDbZRQOCMxJ4AfhaP.text
		if ndib93Ol6UojCrEV:
			title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			value = value.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,511)
	return
def ur2vNdEIF3HDhpKfMP8ZOYwjR():
	AAxvzjDdLKQcSRG8XtYZ = hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup?utf8=%E2%9C%93'
	mNf0VWq3Fw = AAxvzjDdLKQcSRG8XtYZ+'&type=1&category=&foreign=&tag='
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات أشخاص',mNf0VWq3Fw,511)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس أشخاص أبجدي',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/person/alphabet',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس موطن',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/person/nationality',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس  تاريخ الميلاد',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/person/birth_year',517)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'فهرس  تاريخ الوفاة',hhD7r1VvaPt3TC06SJjqKRfEid+'/index/person/death_year',517)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات - فلتر محدد',hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup',515)
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'مصنفات - فلتر كامل',hhD7r1VvaPt3TC06SJjqKRfEid+'/lineup',514)
	return
def UtA76EwvxI(url):
	if '/seasonals' in url: Q1OIedulYvrCpsfG3gLTbj6ci = 0
	elif '/lineup' in url: Q1OIedulYvrCpsfG3gLTbj6ci = 1
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-LISTS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	qqtR56dgVLh3Tr2 = o3odtVgZJha0qjk8MeF6KW.find_all(class_='jumbo-theater clearfix')
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		title = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('a')[Q1OIedulYvrCpsfG3gLTbj6ci].text
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+IJE2xcV7OWauUKhfik56gXBwltCb.find_all('a')[Q1OIedulYvrCpsfG3gLTbj6ci].get('href')
		if ndib93Ol6UojCrEV:
			title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		if not qqtR56dgVLh3Tr2:
			uCrYKsfnd0Qeq24l31wAV(hhEH1rcSP0z6Bkqy8OD)
			return
		else:
			title = title.replace('قائمة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,512)
	elP8drN1Ati4K(o3odtVgZJha0qjk8MeF6KW,511)
	return
def elP8drN1Ati4K(o3odtVgZJha0qjk8MeF6KW,mode):
	IJE2xcV7OWauUKhfik56gXBwltCb = o3odtVgZJha0qjk8MeF6KW.find(class_='pagination')
	if IJE2xcV7OWauUKhfik56gXBwltCb:
		Io4ZXjVDYOyANEhWerw3H = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('a')
		SmpwJQXx2ICOMgh75LyGWlAoU = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('li')
		fT467VL8eCl2BPhqt = list(zip(Io4ZXjVDYOyANEhWerw3H,SmpwJQXx2ICOMgh75LyGWlAoU))
		qbRmVByrJv18 = -1
		DDTmGWrIla0A74 = len(fT467VL8eCl2BPhqt)
		for cSOpWVb7lXu9MBT,upv0W21cGlgxF7 in fT467VL8eCl2BPhqt:
			qbRmVByrJv18 += 1
			upv0W21cGlgxF7 = upv0W21cGlgxF7['class']
			if 'unavailable' in upv0W21cGlgxF7 or 'current' in upv0W21cGlgxF7: continue
			QSuoms9tfxPZwgEea = cSOpWVb7lXu9MBT.text
			q4zyW5Bpx6Y2O = hhD7r1VvaPt3TC06SJjqKRfEid+cSOpWVb7lXu9MBT.get('href')
			if ndib93Ol6UojCrEV:
				QSuoms9tfxPZwgEea = QSuoms9tfxPZwgEea.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				q4zyW5Bpx6Y2O = q4zyW5Bpx6Y2O.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			if   qbRmVByrJv18==0: QSuoms9tfxPZwgEea = 'أولى'
			elif qbRmVByrJv18==1: QSuoms9tfxPZwgEea = 'سابقة'
			elif qbRmVByrJv18==DDTmGWrIla0A74-2: QSuoms9tfxPZwgEea = 'لاحقة'
			elif qbRmVByrJv18==DDTmGWrIla0A74-1: QSuoms9tfxPZwgEea = 'أخيرة'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+QSuoms9tfxPZwgEea,q4zyW5Bpx6Y2O,mode)
	return
def uCrYKsfnd0Qeq24l31wAV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-TITLES1-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	qqtR56dgVLh3Tr2 = o3odtVgZJha0qjk8MeF6KW.find_all(class_='row')
	items,ooZGMlYybF8aNfAOwps = [],True
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		if not IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='thumbnail-wrapper'): continue
		if ooZGMlYybF8aNfAOwps: ooZGMlYybF8aNfAOwps = False ; continue
		Etd2IGqoAUvkSZTRw8 = []
		ttM6yupWrCHdVYnBOGDSvmRUcjJiE3 = IJE2xcV7OWauUKhfik56gXBwltCb.find_all(class_=['censorship red','censorship purple'])
		for w5Q6Ps12vykl4txjVGMgbFoeS0 in ttM6yupWrCHdVYnBOGDSvmRUcjJiE3:
			si4QrCMy2ognmk9lVhztqH06IDjA = w5Q6Ps12vykl4txjVGMgbFoeS0.find_all('li')[1].text
			if ndib93Ol6UojCrEV:
				si4QrCMy2ognmk9lVhztqH06IDjA = si4QrCMy2ognmk9lVhztqH06IDjA.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			Etd2IGqoAUvkSZTRw8.append(si4QrCMy2ognmk9lVhztqH06IDjA)
		if not BBXMogDz3d(UdbRGoKhcDeI4lVfns5,wUvcPrYDfISbZolAm83GKEqMyXkn5,Etd2IGqoAUvkSZTRw8,False):
			mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('data-src')
			title = IJE2xcV7OWauUKhfik56gXBwltCb.find('h3')
			name = title.find('a').text
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+title.find('a').get('href')
			SSQBUifJEC5gX7IboAzPqh = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='no-margin')
			LkZ8ylcqV1DX = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='legend')
			if SSQBUifJEC5gX7IboAzPqh: SSQBUifJEC5gX7IboAzPqh = SSQBUifJEC5gX7IboAzPqh.text
			if LkZ8ylcqV1DX: LkZ8ylcqV1DX = LkZ8ylcqV1DX.text
			if ndib93Ol6UojCrEV:
				mnWZN7g50M = mnWZN7g50M.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				name = name.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				if SSQBUifJEC5gX7IboAzPqh: SSQBUifJEC5gX7IboAzPqh = SSQBUifJEC5gX7IboAzPqh.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			V9NmnGv2o0ZU5P8F4iqgX7CQJ = {}
			if LkZ8ylcqV1DX: V9NmnGv2o0ZU5P8F4iqgX7CQJ['stars'] = LkZ8ylcqV1DX
			if SSQBUifJEC5gX7IboAzPqh:
				SSQBUifJEC5gX7IboAzPqh = SSQBUifJEC5gX7IboAzPqh.replace(QWLr8ABjev,' .. ')
				V9NmnGv2o0ZU5P8F4iqgX7CQJ['plot'] = SSQBUifJEC5gX7IboAzPqh.replace('...اقرأ المزيد',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if '/work/' in hhEH1rcSP0z6Bkqy8OD:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,516,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name,wUvcPrYDfISbZolAm83GKEqMyXkn5,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
			elif '/person/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,513,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name,wUvcPrYDfISbZolAm83GKEqMyXkn5,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
	elP8drN1Ati4K(o3odtVgZJha0qjk8MeF6KW,512)
	return
def dg94cNfleOm1ZkXE0(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-TITLES2-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	qqtR56dgVLh3Tr2 = o3odtVgZJha0qjk8MeF6KW.find_all('li')
	wqHOWj2Y6mFI,items = [],[]
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		if not IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='thumbnail-wrapper'): continue
		if not IJE2xcV7OWauUKhfik56gXBwltCb.find(class_=['unstyled','unstyled text-center']): continue
		if IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='hide'): continue
		title = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in wqHOWj2Y6mFI: continue
		wqHOWj2Y6mFI.append(name)
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+title.find('a').get('href')
		if '/search/work/' in url: mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('src')
		elif '/search/person/' in url: mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('data-src')
		elif '/search/video/' in url: mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('data-src')
		else: mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('src')
		if ndib93Ol6UojCrEV:
			name = name.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			mnWZN7g50M = mnWZN7g50M.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		items.append((name,hhEH1rcSP0z6Bkqy8OD,mnWZN7g50M))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,hhEH1rcSP0z6Bkqy8OD,mnWZN7g50M in items:
		if '/search/video/' in url: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,522,mnWZN7g50M)
		elif '/search/person/' in url: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,513,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,516,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name)
	return
def HHwhAXxP0rMvzpn4t(text):
	text = text.replace('الإعلان',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('لفيلم',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('الرسمي',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace('إعلان',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('فيلم',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('البرومو',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace('التشويقي',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('لمسلسل',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('مسلسل',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace(':',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(')',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('(',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(',',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace('_',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(';',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('-',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('.',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace('\'',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('\"',wUvcPrYDfISbZolAm83GKEqMyXkn5)
	text = text.replace(fy2aLFcjDnoxIzGi1gp7,UKFZBQAVXHI5s17LyvuRpCY2).replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
	text = text.strip(UKFZBQAVXHI5s17LyvuRpCY2)
	FYwLzMrxUbcX = text.count(UKFZBQAVXHI5s17LyvuRpCY2)+1
	if FYwLzMrxUbcX==1:
		u09ud3ec2wpv(text)
		return
	mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+JegF7SlMawI03+'==== كلمات للبحث ===='+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	bptBSXTcYZ7fkUh09e = text.split(UKFZBQAVXHI5s17LyvuRpCY2)
	R91R6HvMGaCVqjUcELfAPKogx4u = pow(2,FYwLzMrxUbcX)
	w2RWfVh7YA6Syne9QmGJOxZvo1FpbN = []
	def FetsU3bLT2uA(XpKaY2xo6QmFcV3iN9kEqduhMR,zEx7ignuNDr0M6a5lBjAqZF1p34ot):
		if XpKaY2xo6QmFcV3iN9kEqduhMR=='1': return zEx7ignuNDr0M6a5lBjAqZF1p34ot
		return wUvcPrYDfISbZolAm83GKEqMyXkn5
	for qbRmVByrJv18 in range(R91R6HvMGaCVqjUcELfAPKogx4u,0,-1):
		eip6ThYs9tGBaknvRyu2I35d4X = list(FYwLzMrxUbcX*'0'+bin(qbRmVByrJv18)[2:])[-FYwLzMrxUbcX:]
		eip6ThYs9tGBaknvRyu2I35d4X = reversed(eip6ThYs9tGBaknvRyu2I35d4X)
		a1j30LvDQOi7GV8YhKsm = map(FetsU3bLT2uA,eip6ThYs9tGBaknvRyu2I35d4X,bptBSXTcYZ7fkUh09e)
		title = UKFZBQAVXHI5s17LyvuRpCY2.join(filter(None,a1j30LvDQOi7GV8YhKsm))
		if ndib93Ol6UojCrEV: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = title.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		else: HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = title
		if len(HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ)>2 and title not in w2RWfVh7YA6Syne9QmGJOxZvo1FpbN:
			w2RWfVh7YA6Syne9QmGJOxZvo1FpbN.append(title)
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,wUvcPrYDfISbZolAm83GKEqMyXkn5,523,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,title)
	return
def u09ud3ec2wpv(WXLft9mQVHqp):
	if ndib93Ol6UojCrEV:
		WXLft9mQVHqp = WXLft9mQVHqp.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		import arabic_reshaper as P17WOx5wlbmdCgEk2G,bidi.algorithm as HCtXsV0NOcph1Tzl5y7
		WXLft9mQVHqp = P17WOx5wlbmdCgEk2G.ArabicReshaper().reshape(WXLft9mQVHqp)
		WXLft9mQVHqp = HCtXsV0NOcph1Tzl5y7.get_display(WXLft9mQVHqp)
	import ffKsyZnaOw
	WXLft9mQVHqp = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA(KKJDx34POf=WXLft9mQVHqp)
	ffKsyZnaOw.LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(WXLft9mQVHqp)
	return
def MUBHzpg4tYrQa98IAhO(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-INDEXES_LISTS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	IJE2xcV7OWauUKhfik56gXBwltCb = o3odtVgZJha0qjk8MeF6KW.find(class_='list-separator list-title')
	kDp3Tb6EBW = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('a')
	items = []
	for title in kDp3Tb6EBW:
		name = title.text
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+title.get('href')
		if ndib93Ol6UojCrEV:
			name = name.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		if '#' not in hhEH1rcSP0z6Bkqy8OD: items.append((name,hhEH1rcSP0z6Bkqy8OD))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for o4oW9wDcsrpHQS816yfIvg in items:
		name,hhEH1rcSP0z6Bkqy8OD = o4oW9wDcsrpHQS816yfIvg
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,518)
	return
def HHshTJmLE8(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-INDEXES_TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	qqtR56dgVLh3Tr2 = o3odtVgZJha0qjk8MeF6KW.find(class_='expand').find_all('tr')
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		UUNIv6zYfnE4FdJR = IJE2xcV7OWauUKhfik56gXBwltCb.find_all('a')
		if not UUNIv6zYfnE4FdJR: continue
		mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('data-src')
		name = UUNIv6zYfnE4FdJR[1].text
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+UUNIv6zYfnE4FdJR[1].get('href')
		LkZ8ylcqV1DX = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='legend')
		if LkZ8ylcqV1DX: LkZ8ylcqV1DX = LkZ8ylcqV1DX.text
		if ndib93Ol6UojCrEV:
			name = name.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			mnWZN7g50M = mnWZN7g50M.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		V9NmnGv2o0ZU5P8F4iqgX7CQJ = {}
		if LkZ8ylcqV1DX: V9NmnGv2o0ZU5P8F4iqgX7CQJ['stars'] = LkZ8ylcqV1DX
		if '/work/' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,516,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name,wUvcPrYDfISbZolAm83GKEqMyXkn5,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
		elif '/person/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+name,hhEH1rcSP0z6Bkqy8OD,513,mnWZN7g50M,wUvcPrYDfISbZolAm83GKEqMyXkn5,name,wUvcPrYDfISbZolAm83GKEqMyXkn5,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
	elP8drN1Ati4K(o3odtVgZJha0qjk8MeF6KW,518)
	return
def gcpLiKnkVxGvT(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-VIDEOS_LISTS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	kDp3Tb6EBW = o3odtVgZJha0qjk8MeF6KW.find_all(class_='section-title inline')
	ppAJI9kDbz5MXa76UEF = o3odtVgZJha0qjk8MeF6KW.find_all(class_='button green small right')
	items = zip(kDp3Tb6EBW,ppAJI9kDbz5MXa76UEF)
	for title,hhEH1rcSP0z6Bkqy8OD in items:
		title = title.text
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD.get('href')
		if ndib93Ol6UojCrEV:
			title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		title = title.replace(fy2aLFcjDnoxIzGi1gp7,UKFZBQAVXHI5s17LyvuRpCY2).replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,521)
	return
def b7YiIvAgul(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-VIDEOS_TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	DkNcnpw8KrLFZWE1QxsBzydIPh = o3odtVgZJha0qjk8MeF6KW.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	qqtR56dgVLh3Tr2 = DkNcnpw8KrLFZWE1QxsBzydIPh.find_all('li')
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		title = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='title').text
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+IJE2xcV7OWauUKhfik56gXBwltCb.find('a').get('href')
		mnWZN7g50M = IJE2xcV7OWauUKhfik56gXBwltCb.find('img').get('data-src')
		KS5UPc7G4x38Lp = IJE2xcV7OWauUKhfik56gXBwltCb.find(class_='duration').text
		if ndib93Ol6UojCrEV:
			title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			mnWZN7g50M = mnWZN7g50M.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			KS5UPc7G4x38Lp = KS5UPc7G4x38Lp.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		KS5UPc7G4x38Lp = KS5UPc7G4x38Lp.replace(QWLr8ABjev,wUvcPrYDfISbZolAm83GKEqMyXkn5).strip(UKFZBQAVXHI5s17LyvuRpCY2)
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,522,mnWZN7g50M,KS5UPc7G4x38Lp)
	elP8drN1Ati4K(o3odtVgZJha0qjk8MeF6KW,521)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	hhEH1rcSP0z6Bkqy8OD = o3odtVgZJha0qjk8MeF6KW.find(class_='flex-video').find('iframe').get('src')
	if ndib93Ol6UojCrEV: hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy([hhEH1rcSP0z6Bkqy8OD],UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'%20')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search/?q='+search
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-SEARCH-1st')
	if not QM9sJ7tk0oplqEwHU3DjL64d.succeeded:
		mNf0VWq3Fw = hhD7r1VvaPt3TC06SJjqKRfEid+'/search_entity/?q='+search+'&entity=work'
		q4zyW5Bpx6Y2O = hhD7r1VvaPt3TC06SJjqKRfEid+'/search_entity/?q='+search+'&entity=person'
		o6lhI3gZLYS5m9VTNHwpxv1M = hhD7r1VvaPt3TC06SJjqKRfEid+'/search_entity/?q='+search+'&entity=video'
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن أعمال',mNf0VWq3Fw,513,wUvcPrYDfISbZolAm83GKEqMyXkn5,search)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن أشخاص',q4zyW5Bpx6Y2O,513,wUvcPrYDfISbZolAm83GKEqMyXkn5,search)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث عن فيديوهات',o6lhI3gZLYS5m9VTNHwpxv1M,513,wUvcPrYDfISbZolAm83GKEqMyXkn5,search)
		return
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	o3odtVgZJha0qjk8MeF6KW = vWqXEt9hcYxr.BeautifulSoup(II64TLxj3mbqEyh9pHQ8oAv,'html.parser',multi_valued_attributes=None)
	qqtR56dgVLh3Tr2 = o3odtVgZJha0qjk8MeF6KW.find_all(class_='section-title left')
	for IJE2xcV7OWauUKhfik56gXBwltCb in qqtR56dgVLh3Tr2:
		title = IJE2xcV7OWauUKhfik56gXBwltCb.text
		if ndib93Ol6UojCrEV:
			title = title.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		title = title.split('(',1)[0].strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if   'أعمال' in title: hhEH1rcSP0z6Bkqy8OD = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: hhEH1rcSP0z6Bkqy8OD = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: hhEH1rcSP0z6Bkqy8OD = url.replace('/search/','/search/video/')
		else: continue
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,513)
	return
def dORtxvGBhXAsu3qZF7(url,text):
	global tIU8BcnSMHNX6aFdzTJ0Y9KjoO,l0pkODK9d5qmZXWcotGHrU
	if '/seasonals' in url:
		tIU8BcnSMHNX6aFdzTJ0Y9KjoO = ['seasonal','year','category']
		l0pkODK9d5qmZXWcotGHrU = ['seasonal','year','category']
	elif '/lineup' in url:
		tIU8BcnSMHNX6aFdzTJ0Y9KjoO = ['category','foreign','type']
		l0pkODK9d5qmZXWcotGHrU = ['category','foreign','type']
	mmUxVlf7ZQMjeDE(url,text)
	return
def fFLoASm2V96qUBCEHzGJjyc(url):
	url = url.split('/smartemadfilter?')[0]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('form action="/(.*?)</form>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = jj0dZrgiKb.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return Q9cBo8ysZbM3L4Ttvd7nF6Nk
def e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb):
	items = jj0dZrgiKb.findall('<option value="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	return items
def U0r9RGnOsXJ3fDdvepcCSjIt(url):
	lnpS3fLJa4GiNoctb = url.split('/smartemadfilter?')[0]
	U62oVRpWuriEJAwedHOxStI9m8bCQ = TO3vi2rSZ0LRhKlwgG4qkYFIC(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def Z2ZlHegLVw(GGoYRt8OWDUMnqSmfp3yXJl25sz,url):
	NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(GGoYRt8OWDUMnqSmfp3yXJl25sz,'all_filters')
	qaLFXuDExl8w = url+'/smartemadfilter?'+NGik0Ke4WwfT2
	qaLFXuDExl8w = U0r9RGnOsXJ3fDdvepcCSjIt(qaLFXuDExl8w)
	return qaLFXuDExl8w
def mmUxVlf7ZQMjeDE(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==wUvcPrYDfISbZolAm83GKEqMyXkn5: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	else: yzamv2DUurjwolVq,mVhHg8LIlYR5cM9d7PfB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]+'=' not in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0]
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(len(tIU8BcnSMHNX6aFdzTJ0Y9KjoO[0:-1])):
			if tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3]+'=' in yzamv2DUurjwolVq: d5TLHSj39awfvFp = tIU8BcnSMHNX6aFdzTJ0Y9KjoO[kkLhJCU4MQSx7s6gyeOHrRYKtnP3+1]
		M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+d5TLHSj39awfvFp+'=0'
		GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+d5TLHSj39awfvFp+'=0'
		qclt2BMvQu = M2MhYTzotC0.strip('&')+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz.strip('&')
		NGik0Ke4WwfT2 = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+NGik0Ke4WwfT2
	elif type=='ALL_ITEMS_FILTER':
		RBe627VgHJ = g7g1s2CGTSVYO3dle(yzamv2DUurjwolVq,'modified_values')
		RBe627VgHJ = Z6bUG0kDQuFqgzdAa1r(RBe627VgHJ)
		if mVhHg8LIlYR5cM9d7PfB!=wUvcPrYDfISbZolAm83GKEqMyXkn5: mVhHg8LIlYR5cM9d7PfB = g7g1s2CGTSVYO3dle(mVhHg8LIlYR5cM9d7PfB,'modified_filters')
		if mVhHg8LIlYR5cM9d7PfB==wUvcPrYDfISbZolAm83GKEqMyXkn5: ZD5n0eJivzWOMxY98dgrumkwRG = url
		else: ZD5n0eJivzWOMxY98dgrumkwRG = url+'/smartemadfilter?'+mVhHg8LIlYR5cM9d7PfB
		ZD5n0eJivzWOMxY98dgrumkwRG = U0r9RGnOsXJ3fDdvepcCSjIt(ZD5n0eJivzWOMxY98dgrumkwRG)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'أظهار قائمة الفيديو التي تم اختيارها ',ZD5n0eJivzWOMxY98dgrumkwRG,511)
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+' [[   '+RBe627VgHJ+'   ]]',ZD5n0eJivzWOMxY98dgrumkwRG,511)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	Q9cBo8ysZbM3L4Ttvd7nF6Nk = fFLoASm2V96qUBCEHzGJjyc(url)
	dict = {}
	for name,VaqykB2YmTbCtUDl,IJE2xcV7OWauUKhfik56gXBwltCb in Q9cBo8ysZbM3L4Ttvd7nF6Nk:
		name = name.replace('--',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		items = e62dZlfyJaiEnFkz(IJE2xcV7OWauUKhfik56gXBwltCb)
		if '=' not in ZD5n0eJivzWOMxY98dgrumkwRG: ZD5n0eJivzWOMxY98dgrumkwRG = url
		if type=='SPECIFIED_FILTER':
			if VaqykB2YmTbCtUDl not in tIU8BcnSMHNX6aFdzTJ0Y9KjoO: continue
			if d5TLHSj39awfvFp!=VaqykB2YmTbCtUDl: continue
			elif len(items)<2:
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]:
					url = U0r9RGnOsXJ3fDdvepcCSjIt(url)
					uCrYKsfnd0Qeq24l31wAV(url)
				else: mmUxVlf7ZQMjeDE(ZD5n0eJivzWOMxY98dgrumkwRG,'SPECIFIED_FILTER___'+qclt2BMvQu)
				return
			else:
				ZD5n0eJivzWOMxY98dgrumkwRG = U0r9RGnOsXJ3fDdvepcCSjIt(ZD5n0eJivzWOMxY98dgrumkwRG)
				if VaqykB2YmTbCtUDl==tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-1]: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,511)
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',ZD5n0eJivzWOMxY98dgrumkwRG,515,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		elif type=='ALL_ITEMS_FILTER':
			if VaqykB2YmTbCtUDl not in l0pkODK9d5qmZXWcotGHrU: continue
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'=0'
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'=0'
			qclt2BMvQu = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع: '+name,ZD5n0eJivzWOMxY98dgrumkwRG,514,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,qclt2BMvQu)
		dict[VaqykB2YmTbCtUDl] = {}
		for value,sslNS0zetni1HDbZRQOCMxJ4AfhaP in items:
			if sslNS0zetni1HDbZRQOCMxJ4AfhaP in i6TIRax9v0EDFJs2gVtfzp: continue
			if 'مصنفات أخرى' in sslNS0zetni1HDbZRQOCMxJ4AfhaP: continue
			if 'الكل' in sslNS0zetni1HDbZRQOCMxJ4AfhaP: continue
			if 'اللغة' in sslNS0zetni1HDbZRQOCMxJ4AfhaP: continue
			sslNS0zetni1HDbZRQOCMxJ4AfhaP = sslNS0zetni1HDbZRQOCMxJ4AfhaP.replace('قائمة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[VaqykB2YmTbCtUDl][value] = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			M2MhYTzotC0 = yzamv2DUurjwolVq+'&'+VaqykB2YmTbCtUDl+'='+sslNS0zetni1HDbZRQOCMxJ4AfhaP
			GGoYRt8OWDUMnqSmfp3yXJl25sz = mVhHg8LIlYR5cM9d7PfB+'&'+VaqykB2YmTbCtUDl+'='+value
			LOo9qA7Kn0EpCHGX2NU = M2MhYTzotC0+'___'+GGoYRt8OWDUMnqSmfp3yXJl25sz
			if name: title = sslNS0zetni1HDbZRQOCMxJ4AfhaP+' :'+name
			else: title = sslNS0zetni1HDbZRQOCMxJ4AfhaP
			if type=='ALL_ITEMS_FILTER': mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,514,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
			elif type=='SPECIFIED_FILTER' and tIU8BcnSMHNX6aFdzTJ0Y9KjoO[-2]+'=' in yzamv2DUurjwolVq:
				qaLFXuDExl8w = Z2ZlHegLVw(GGoYRt8OWDUMnqSmfp3yXJl25sz,url)
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,qaLFXuDExl8w,511)
			else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,url,515,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,LOo9qA7Kn0EpCHGX2NU)
	return
def g7g1s2CGTSVYO3dle(EU4CrTg3z07fweGHRmZbA,mode):
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.replace('=&','=0&')
	EU4CrTg3z07fweGHRmZbA = EU4CrTg3z07fweGHRmZbA.strip('&')
	wHOxpbdkJBM0ZC7 = {}
	if '=' in EU4CrTg3z07fweGHRmZbA:
		items = EU4CrTg3z07fweGHRmZbA.split('&')
		for o4oW9wDcsrpHQS816yfIvg in items:
			f8fOVWAM0hig9ZeDJbHds,value = o4oW9wDcsrpHQS816yfIvg.split('=')
			wHOxpbdkJBM0ZC7[f8fOVWAM0hig9ZeDJbHds] = value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = wUvcPrYDfISbZolAm83GKEqMyXkn5
	for key in l0pkODK9d5qmZXWcotGHrU:
		if key in list(wHOxpbdkJBM0ZC7.keys()): value = wHOxpbdkJBM0ZC7[key]
		else: value = '0'
		if '%' not in value: value = vvLTYxVfrbDza(value)
		if mode=='modified_values' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+' + '+value
		elif mode=='modified_filters' and value!='0': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
		elif mode=='all_filters': IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm+'&'+key+'='+value
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip(' + ')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.strip('&')
	IIacxECW0M6lSRwGfpFbUJP9d2Lm = IIacxECW0M6lSRwGfpFbUJP9d2Lm.replace('=0','=')
	return IIacxECW0M6lSRwGfpFbUJP9d2Lm
tIU8BcnSMHNX6aFdzTJ0Y9KjoO = []
l0pkODK9d5qmZXWcotGHrU = []