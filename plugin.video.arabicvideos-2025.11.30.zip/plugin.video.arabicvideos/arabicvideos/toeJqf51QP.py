# -*- coding: utf-8 -*-
import sys as Sph0cr2ZWK1atAUw5CTuxoe
Y1FBOey56j8SszRbu4M9nHvWmaUi = Sph0cr2ZWK1atAUw5CTuxoe.version_info [0] == 2
olnphvB0P2Y5D1dGzmxaX7wRq = 2048
NnpY1JPvQ6L = 7
def d8BUchuszKFOig4CSQlDvP2YrMGb (p203COZvrKX):
	global zmT50Cvow3GcuQia9qNseEJKkS
	AAmXseNbnPFOoLpHdzUSlh2fKw = ord (p203COZvrKX [-1])
	uHDEqYc7624fisI = p203COZvrKX [:-1]
	QLljtrxVivF0aShXP3GkA97HTZu = AAmXseNbnPFOoLpHdzUSlh2fKw % len (uHDEqYc7624fisI)
	JIF93knblm2GRrsQMBTjAxyVW1q = uHDEqYc7624fisI [:QLljtrxVivF0aShXP3GkA97HTZu] + uHDEqYc7624fisI [QLljtrxVivF0aShXP3GkA97HTZu:]
	if Y1FBOey56j8SszRbu4M9nHvWmaUi:
		CoIUb4yxTizm9GKJfjQRAWaLn = unicode () .join ([unichr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	else:
		CoIUb4yxTizm9GKJfjQRAWaLn = str () .join ([chr (ord (YYge4HKbQLO9U) - olnphvB0P2Y5D1dGzmxaX7wRq - (lIktGUqxEwmZhgByRuVWDeac + AAmXseNbnPFOoLpHdzUSlh2fKw) % NnpY1JPvQ6L) for lIktGUqxEwmZhgByRuVWDeac, YYge4HKbQLO9U in enumerate (JIF93knblm2GRrsQMBTjAxyVW1q)])
	return eval (CoIUb4yxTizm9GKJfjQRAWaLn)
TNw1pBHb8CtSZe0EFxuJqI,MFhbWia58mP3su0fk2d,vWNRusF46D7Mi8GpZ=d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb,d8BUchuszKFOig4CSQlDvP2YrMGb
xm6jK1ZMuWq5,weh7SGmuTgXOVRcMo1rlLq,D2PpKMeZFWrmfxTSs4L1tz=vWNRusF46D7Mi8GpZ,MFhbWia58mP3su0fk2d,TNw1pBHb8CtSZe0EFxuJqI
xdSThjYnuHXAU6M,rDG9dZoXRhCJcieUSF0KB,jnqzf9WihpUlxmcAEZ1vMLXNu=D2PpKMeZFWrmfxTSs4L1tz,weh7SGmuTgXOVRcMo1rlLq,xm6jK1ZMuWq5
llkFwuCyhaP3sK76qO4T,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,DpRJnas65uVcO0S17dYG=jnqzf9WihpUlxmcAEZ1vMLXNu,rDG9dZoXRhCJcieUSF0KB,xdSThjYnuHXAU6M
erqDsJmL3BQHuGtPkcf0X9,ZiCLpR1Tc5vUlPXDWgmhM6j,kPCxIUZb1V=DpRJnas65uVcO0S17dYG,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz,llkFwuCyhaP3sK76qO4T
jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7,w8JC1y7Lp3,lCT8hfYUBX4OQMmL=kPCxIUZb1V,ZiCLpR1Tc5vUlPXDWgmhM6j,erqDsJmL3BQHuGtPkcf0X9
fmkZtbRj3ux,vvhR5ozeiJpANyl8fFO3GBw,SVQT7vyFXYNMZLRdhGbuJqOslE806n=lCT8hfYUBX4OQMmL,w8JC1y7Lp3,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7
bQGafNLXyFgsZP6ut,gVpGcN7nxEWLri4DvyAZlU3BQM,VhqD3zp7mUieI8sMQlETH=SVQT7vyFXYNMZLRdhGbuJqOslE806n,vvhR5ozeiJpANyl8fFO3GBw,fmkZtbRj3ux
dhzX91Lcgv0PxaYHEOwMTCbItyo2q,xE6cFVGitMk5SAPTsNa7lpYH9Lf,s149dk8uh2p7oFzaLxZeI3Or=VhqD3zp7mUieI8sMQlETH,gVpGcN7nxEWLri4DvyAZlU3BQM,bQGafNLXyFgsZP6ut
it4DKnryZlx,JHMxIE4fs1mvQtKW7R,Gj3rMP1Cb8wHdp49la0=s149dk8uh2p7oFzaLxZeI3Or,xE6cFVGitMk5SAPTsNa7lpYH9Lf,dhzX91Lcgv0PxaYHEOwMTCbItyo2q
A6Sg45ChDR3BJLYfFH,jQv0du1iVxTgAXCM,yRWQMHxZEz0=Gj3rMP1Cb8wHdp49la0,JHMxIE4fs1mvQtKW7R,it4DKnryZlx
import xbmc as te28VJiPB7RXcm6brMUQyKAC3Z,re as jj0dZrgiKb,sys as Sph0cr2ZWK1atAUw5CTuxoe,xbmcaddon as IuYcSnkRMVoxf4LvWht,random as kItsbxAFUXc3,os as b7i1PgC8Z4e5BFoHNd9E2UVvfc,xbmcvfs as XgEUrSsa4QOz2CwDxvHkFeVjoc,time as L5jXH0fZ8TvsESR,pickle as a8avpx1moLl2GqrMQUAt9zibyENYn7,zlib as FSaPuXqyvI24in8rhtEzOoe3,xbmcgui as llfAzdjaVLTbyZW7op9i,xbmcplugin as qsrzODKdEYyo,sqlite3 as plTxfrOsuV4McaF2HPg1BiZ396GXI5,traceback as Zt8esTLkqKnNYI,threading as KoPyu0Aefth,hashlib as vlnTfwNrdtCPUWhcu8Ip,json as bbeLsVCqouaSH53E0XmKh4AnFD
from aVsS7DW8Qd import *
import TTuO14NzmB
UdbRGoKhcDeI4lVfns5 = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩ෬")
ZwHiVtNa5qeP9YAJImX2s170QjK8xT = IuYcSnkRMVoxf4LvWht.Addon().getAddonInfo(xdSThjYnuHXAU6M(u"ࠩࡳࡥࡹ࡮ࠧ෭"))
qIWlOBE8P0FNw7u = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,w8JC1y7Lp3(u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬ෮"))
Sph0cr2ZWK1atAUw5CTuxoe.path.append(qIWlOBE8P0FNw7u)
RyDst4Oxmaqb0U7vljKYI2V = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(Gj3rMP1Cb8wHdp49la0(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥ෯"))
Uy6GWujQiBLhodP = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩ෰"),RyDst4Oxmaqb0U7vljKYI2V,jj0dZrgiKb.DOTALL)
Uy6GWujQiBLhodP = float(Uy6GWujQiBLhodP[wTLFCOcM26fmYlW7U])
A7qlH50rEQ6WtyMUSs1pcP = te28VJiPB7RXcm6brMUQyKAC3Z.Player
dd9vHqKzXCB7Y = llfAzdjaVLTbyZW7op9i.WindowXMLDialog
ndib93Ol6UojCrEV = Uy6GWujQiBLhodP<SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠳࠼ဤ")
wwMdFkWvcRYiXHB7yDrCqnKb98o = Uy6GWujQiBLhodP>w8JC1y7Lp3(u"࠴࠼࠳࠿࠹ဥ")
if wwMdFkWvcRYiXHB7yDrCqnKb98o:
	QrW3v0cdJogNLkp8ub9VmYB5iDRa7E = XgEUrSsa4QOz2CwDxvHkFeVjoc.translatePath(erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ෱"))
	t4YM1wZmaI3Uh7GC5c = te28VJiPB7RXcm6brMUQyKAC3Z.LOGINFO
	LpYS3ndDvXHzwKP,u3UY8xgQZn4FLD6qWXRTyS79djo = kPCxIUZb1V(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨෲ"),fmkZtbRj3ux(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩෳ")
	tRA4gT7GOoCaXJQ = XgEUrSsa4QOz2CwDxvHkFeVjoc.translatePath(VhqD3zp7mUieI8sMQlETH(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ෴"))
	from urllib.parse import unquote as _ix9ZDldLBh6
	LL4sIM7KcyZUvh = lCT8hfYUBX4OQMmL(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ෵")
else:
	QrW3v0cdJogNLkp8ub9VmYB5iDRa7E = te28VJiPB7RXcm6brMUQyKAC3Z.translatePath(llkFwuCyhaP3sK76qO4T(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ෶"))
	t4YM1wZmaI3Uh7GC5c = te28VJiPB7RXcm6brMUQyKAC3Z.LOGNOTICE
	LpYS3ndDvXHzwKP,u3UY8xgQZn4FLD6qWXRTyS79djo = bQGafNLXyFgsZP6ut(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭෷").encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ෸").encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	tRA4gT7GOoCaXJQ = te28VJiPB7RXcm6brMUQyKAC3Z.translatePath(rDG9dZoXRhCJcieUSF0KB(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ෹"))
	from urllib import unquote as _ix9ZDldLBh6
	LL4sIM7KcyZUvh = vWNRusF46D7Mi8GpZ(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ෺").encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
ggvQikMrmRXYdezZuUwj30WOc = Sph0cr2ZWK1atAUw5CTuxoe.argv[wTLFCOcM26fmYlW7U].split(VhqD3zp7mUieI8sMQlETH(u"ࠩ࠲ࠫ෻"))[Tb7oymMnpflsSv3eu4Pz2]
pe9KNyUQmRTj = int(Sph0cr2ZWK1atAUw5CTuxoe.argv[UD4N8MjVTd])
XhGSxvjRAZdU7rEt9JMweQC = Sph0cr2ZWK1atAUw5CTuxoe.argv[Tb7oymMnpflsSv3eu4Pz2]
H9Ip0x1C8DbA2KRWULBwd5Zc = ggvQikMrmRXYdezZuUwj30WOc.split(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࠲ࠬ෼"))[Tb7oymMnpflsSv3eu4Pz2]
D1DBSuO0lLGRbcfCyY = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(kPCxIUZb1V(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ෽")+ggvQikMrmRXYdezZuUwj30WOc+weh7SGmuTgXOVRcMo1rlLq(u"ࠬ࠯ࠧ෾"))
kAXGQe4sH7o3dfLUKv2zlZDM8r09 = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(tRA4gT7GOoCaXJQ,ggvQikMrmRXYdezZuUwj30WOc)
CCrtv6o3mySp = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,bQGafNLXyFgsZP6ut(u"࠭ࡩ࡮ࡣࡪࡩࡸ࠭෿"))
VYPjpbzMoqyd = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(CCrtv6o3mySp,bQGafNLXyFgsZP6ut(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠧ฀"))
eMlUWoPD3pqfjkzsFAdu = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(CCrtv6o3mySp,D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩก"))
jiVY8KaspuyU = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(eMlUWoPD3pqfjkzsFAdu,ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬข"))
TiszRA9jGVP8oQIyl3S = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(QrW3v0cdJogNLkp8ub9VmYB5iDRa7E,weh7SGmuTgXOVRcMo1rlLq(u"ࠪࡱࡪࡪࡩࡢࠩฃ"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠫࡋࡵ࡮ࡵࡵࠪค"),erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨฅ"))
bcP2jUx34tG51D6XSNnyWIes = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫฆ"))
C5VkX6NMYnT2A0PFL = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(kAXGQe4sH7o3dfLUKv2zlZDM8r09,lCT8hfYUBX4OQMmL(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨง"))
ZwHiVtNa5qeP9YAJImX2s170QjK8xT = IuYcSnkRMVoxf4LvWht.Addon().getAddonInfo(s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡲࡤࡸ࡭࠭จ"))
sClMWK2Epu7ac = b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.join(ZwHiVtNa5qeP9YAJImX2s170QjK8xT,MFhbWia58mP3su0fk2d(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩฉ"))
yoJ7t3WpjPkrCmTq = int(L5jXH0fZ8TvsESR.time())
OOnvcPQy85HYA = IuYcSnkRMVoxf4LvWht.Addon(id=ggvQikMrmRXYdezZuUwj30WOc)
gxdpYvkIunQT = OOnvcPQy85HYA.getSetting(xm6jK1ZMuWq5(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧช"))
AAyuoe4wDPR2MgXacG7ZN8zI = Z19pUxa2gfGMNKoDsEuytn85SjFvA if gxdpYvkIunQT==D1DBSuO0lLGRbcfCyY else y0yvdNOZkiKEg5RLMhoDVQAB9F2
def ibEuGXOqxHp(xLDEnp9WdA,E6EKdTRc4U=TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࡄ࠭ซ")):
	if jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬࡃࠧฌ") in xLDEnp9WdA:
		if E6EKdTRc4U in xLDEnp9WdA: ZD5n0eJivzWOMxY98dgrumkwRG,ywtl1CGvpdaIUosAHJf = xLDEnp9WdA.split(E6EKdTRc4U,w8JC1y7Lp3(u"࠵ဦ"))
		else: ZD5n0eJivzWOMxY98dgrumkwRG,ywtl1CGvpdaIUosAHJf = wUvcPrYDfISbZolAm83GKEqMyXkn5,xLDEnp9WdA
		ywtl1CGvpdaIUosAHJf = ywtl1CGvpdaIUosAHJf.split(lCT8hfYUBX4OQMmL(u"࠭ࠦࠨญ"))
		FjUcS938pAH5sZ = {}
		for K2KTRkqVnBdUlagP5bFtZWL0 in ywtl1CGvpdaIUosAHJf:
			NH79yB8ocSkVP2IRdOeE6UrXuh,neGOw8MuxH5gCSk4 = K2KTRkqVnBdUlagP5bFtZWL0.split(erqDsJmL3BQHuGtPkcf0X9(u"ࠧ࠾ࠩฎ"),w8JC1y7Lp3(u"࠶ဧ"))
			FjUcS938pAH5sZ[NH79yB8ocSkVP2IRdOeE6UrXuh] = neGOw8MuxH5gCSk4
	else: ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ = xLDEnp9WdA,{}
	return ZD5n0eJivzWOMxY98dgrumkwRG,FjUcS938pAH5sZ
def LPtVaw9ZF8ureCo(PPV92olpby3x06D):
	V25jaUpo816BHEv,g40I3ZXaeJ8qVywt,A8pPwqbmrhFIRHBoeUyZl = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	PPV92olpby3x06D = PPV92olpby3x06D.replace(LpYS3ndDvXHzwKP,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(u3UY8xgQZn4FLD6qWXRTyS79djo,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	kdJDcbM5FWUAgBs = jj0dZrgiKb.findall(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࠪ࠱࠭ࡡࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇ࠲࠻ࡇ࠶ࡌ࡜࡞ࠪ࡟ࡻࡡࡽ࡜ࡸࠫࠣ࠯ࡡࡡ࡜࠰ࡅࡒࡐࡔࡘ࡜࡞ࠪ࠱࠮ࡄ࠯ࠤࠨฏ"),PPV92olpby3x06D,jj0dZrgiKb.DOTALL)
	if kdJDcbM5FWUAgBs: V25jaUpo816BHEv,g40I3ZXaeJ8qVywt,PPV92olpby3x06D = kdJDcbM5FWUAgBs[wTLFCOcM26fmYlW7U]
	if V25jaUpo816BHEv not in [UKFZBQAVXHI5s17LyvuRpCY2,D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࠯ࠫฐ"),wUvcPrYDfISbZolAm83GKEqMyXkn5]: A8pPwqbmrhFIRHBoeUyZl = MFhbWia58mP3su0fk2d(u"ࠪࡣࡒࡕࡄࡠࠩฑ")
	if g40I3ZXaeJ8qVywt: g40I3ZXaeJ8qVywt = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫࡤ࠭ฒ")+g40I3ZXaeJ8qVywt+VhqD3zp7mUieI8sMQlETH(u"ࠬࡥࠧณ")
	PPV92olpby3x06D = g40I3ZXaeJ8qVywt+A8pPwqbmrhFIRHBoeUyZl+PPV92olpby3x06D
	return PPV92olpby3x06D
def Z6bUG0kDQuFqgzdAa1r(xLDEnp9WdA):
	return _ix9ZDldLBh6(xLDEnp9WdA)
def iH5WqdVauhO(oVMeQXT4FN3GpJCdnwtvO6):
	VS7diUeAyMoE1L = {vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡴࡺࡲࡨࠫด"):wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"ࠧ࡮ࡱࡧࡩࠬต"):wUvcPrYDfISbZolAm83GKEqMyXkn5,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡷࡵࡰࠬถ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,it4DKnryZlx(u"ࠩࡷࡩࡽࡺࠧท"):wUvcPrYDfISbZolAm83GKEqMyXkn5,w8JC1y7Lp3(u"ࠪࡴࡦ࡭ࡥࠨธ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,Gj3rMP1Cb8wHdp49la0(u"ࠫࡳࡧ࡭ࡦࠩน"):wUvcPrYDfISbZolAm83GKEqMyXkn5,VhqD3zp7mUieI8sMQlETH(u"ࠬ࡯࡭ࡢࡩࡨࠫบ"):wUvcPrYDfISbZolAm83GKEqMyXkn5,bQGafNLXyFgsZP6ut(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧป"):wUvcPrYDfISbZolAm83GKEqMyXkn5,erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩผ"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
	if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡁࠪฝ") in oVMeQXT4FN3GpJCdnwtvO6: oVMeQXT4FN3GpJCdnwtvO6 = oVMeQXT4FN3GpJCdnwtvO6.split(vWNRusF46D7Mi8GpZ(u"ࠩࡂࠫพ"),UD4N8MjVTd)[UD4N8MjVTd]
	ZD5n0eJivzWOMxY98dgrumkwRG,ZZHI7hqBPldCcxLg3DyU = ibEuGXOqxHp(oVMeQXT4FN3GpJCdnwtvO6)
	aargs = dict(list(VS7diUeAyMoE1L.items())+list(ZZHI7hqBPldCcxLg3DyU.items()))
	IItNC5sHDnydEgq2YrRu = aargs[pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡱࡴࡪࡥࠨฟ")]
	jawMl1HJN2kZh98B5LPC3nsFxviz = Z6bUG0kDQuFqgzdAa1r(aargs[s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡺࡸ࡬ࠨภ")])
	mM6SdsnRhy0A1YlxieWgVpEzXGo = Z6bUG0kDQuFqgzdAa1r(aargs[vWNRusF46D7Mi8GpZ(u"ࠬࡺࡥࡹࡶࠪม")])
	AdEraLtUnxc5T3z8ej0Rp1JXv9B = Z6bUG0kDQuFqgzdAa1r(aargs[xdSThjYnuHXAU6M(u"࠭ࡰࡢࡩࡨࠫย")])
	BDQKR3CShFoAnN4Uq62fL5v9dws = Z6bUG0kDQuFqgzdAa1r(aargs[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡵࡻࡳࡩࠬร")])
	ecRjk36mZK4gPIXrBqp = Z6bUG0kDQuFqgzdAa1r(aargs[weh7SGmuTgXOVRcMo1rlLq(u"ࠨࡰࡤࡱࡪ࠭ฤ")])
	h4GBW96Iwnra8OopcJKtbA = Z6bUG0kDQuFqgzdAa1r(aargs[jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩ࡬ࡱࡦ࡭ࡥࠨล")])
	zRnumoW1HcMDsYN8r3G9eaU = aargs[VhqD3zp7mUieI8sMQlETH(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫฦ")]
	GhT6YkowuIQrsitES7c2JKyNbn1A = Z6bUG0kDQuFqgzdAa1r(aargs[jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ว")])
	if GhT6YkowuIQrsitES7c2JKyNbn1A: GhT6YkowuIQrsitES7c2JKyNbn1A = eval(GhT6YkowuIQrsitES7c2JKyNbn1A)
	else: GhT6YkowuIQrsitES7c2JKyNbn1A = {}
	if not IItNC5sHDnydEgq2YrRu: BDQKR3CShFoAnN4Uq62fL5v9dws = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬศ") ; IItNC5sHDnydEgq2YrRu = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭࠲࠷࠲ࠪษ")
	return mLh8JBt075iUqNOSDCVFsPIM6KgzGc(BDQKR3CShFoAnN4Uq62fL5v9dws,ecRjk36mZK4gPIXrBqp,jawMl1HJN2kZh98B5LPC3nsFxviz,IItNC5sHDnydEgq2YrRu,h4GBW96Iwnra8OopcJKtbA,AdEraLtUnxc5T3z8ej0Rp1JXv9B,mM6SdsnRhy0A1YlxieWgVpEzXGo,zRnumoW1HcMDsYN8r3G9eaU,GhT6YkowuIQrsitES7c2JKyNbn1A)
def Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5):
	n3Z1lWEXVtvscfpaDUP8z = Sph0cr2ZWK1atAUw5CTuxoe._getframe(UD4N8MjVTd).f_code.co_name
	if not UdbRGoKhcDeI4lVfns5 or not n3Z1lWEXVtvscfpaDUP8z or n3Z1lWEXVtvscfpaDUP8z==s149dk8uh2p7oFzaLxZeI3Or(u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩส"):
		return xm6jK1ZMuWq5(u"ࠨ࡝ࠣࠫห")+H9Ip0x1C8DbA2KRWULBwd5Zc.upper()+xdSThjYnuHXAU6M(u"ࠩࡢࠫฬ")+D1DBSuO0lLGRbcfCyY+bQGafNLXyFgsZP6ut(u"ࠪࡣࠬอ")+str(Uy6GWujQiBLhodP)+TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࠥࡣࠧฮ")
	return llkFwuCyhaP3sK76qO4T(u"ࠬ࠴࡜ࡵࠩฯ")+n3Z1lWEXVtvscfpaDUP8z
def KnPs7aEmR0SGBf2o5wd(RKyqlatE0chfxwJsZ,hU30beEvi6onzCMPS7Q=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if not hU30beEvi6onzCMPS7Q: RKyqlatE0chfxwJsZ,hU30beEvi6onzCMPS7Q = wUvcPrYDfISbZolAm83GKEqMyXkn5,RKyqlatE0chfxwJsZ
	for LAxSXYvhabdyR4zBs in rmE8zBp0Zwc6hTY1DFKMiPfGVNuoRX:
		if LAxSXYvhabdyR4zBs in hU30beEvi6onzCMPS7Q: hU30beEvi6onzCMPS7Q = hU30beEvi6onzCMPS7Q.replace(LAxSXYvhabdyR4zBs,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	hU30beEvi6onzCMPS7Q = hU30beEvi6onzCMPS7Q.replace(D2PpKMeZFWrmfxTSs4L1tz(u"࠭࡜ࡹ࠲࠳ࠫะ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if ndib93Ol6UojCrEV:
		try: hU30beEvi6onzCMPS7Q = hU30beEvi6onzCMPS7Q.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,lCT8hfYUBX4OQMmL(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧั")).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,Gj3rMP1Cb8wHdp49la0(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨา"))
		except: hU30beEvi6onzCMPS7Q = hU30beEvi6onzCMPS7Q.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,s149dk8uh2p7oFzaLxZeI3Or(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩำ"))
	Eo8tVk6PZl9b = t4YM1wZmaI3Uh7GC5c
	sDMqyG0jAOK = [wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5]
	if RKyqlatE0chfxwJsZ: hU30beEvi6onzCMPS7Q = hU30beEvi6onzCMPS7Q.replace(QQ9Zl8PbOd3c4InyWEFmsVp2rDoeM,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(JegF7SlMawI03,wUvcPrYDfISbZolAm83GKEqMyXkn5).replace(AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5)
	else: RKyqlatE0chfxwJsZ = zWVDcOSsdJMU
	NdGEOCnx5J7DKfqgYm,E6EKdTRc4U = gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠪࡠࡹ࠭ิ"),DQCpAXVq6LHJ0aEFR
	HZcKGP6yrvs7wBCYomXLVF3aq4fUQ = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠴࠳ဩ")*UKFZBQAVXHI5s17LyvuRpCY2 if wwMdFkWvcRYiXHB7yDrCqnKb98o else kPCxIUZb1V(u"࠹࠱ဨ")*UKFZBQAVXHI5s17LyvuRpCY2
	Tx6WOfAruY32CZFKokqX1pLRNhJd = R9RNUT6WAPEYjHqtIokxuXs*NdGEOCnx5J7DKfqgYm
	if hU30beEvi6onzCMPS7Q.startswith(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬี")): hU30beEvi6onzCMPS7Q = s149dk8uh2p7oFzaLxZeI3Or(u"ࠬ࠴࡜ࡵࠩึ")+hU30beEvi6onzCMPS7Q
	if GZR3XQMO5J4N7tqEkSwFr6l9L1eb in RKyqlatE0chfxwJsZ: Eo8tVk6PZl9b = te28VJiPB7RXcm6brMUQyKAC3Z.LOGERROR
	if RKyqlatE0chfxwJsZ in [zWVDcOSsdJMU,GZR3XQMO5J4N7tqEkSwFr6l9L1eb]: sDMqyG0jAOK = [hU30beEvi6onzCMPS7Q]
	elif RKyqlatE0chfxwJsZ==WW0AeIrS1dQyvqlnTzO8kaYFc: sDMqyG0jAOK = hU30beEvi6onzCMPS7Q.split(E6EKdTRc4U)
	elif RKyqlatE0chfxwJsZ==SjUOalsknhyeYqI6Tf:
		xJv6NiWUR7DI = hU30beEvi6onzCMPS7Q.split(E6EKdTRc4U)
		sDMqyG0jAOK = [xJv6NiWUR7DI[wTLFCOcM26fmYlW7U]]
		for aJQuONIydj in range(UD4N8MjVTd,len(xJv6NiWUR7DI),Tb7oymMnpflsSv3eu4Pz2):
			try: lfrnN4U8kEvD3tAQHVBc92oMYbGaSg = xJv6NiWUR7DI[aJQuONIydj]+E6EKdTRc4U+xJv6NiWUR7DI[aJQuONIydj+TNw1pBHb8CtSZe0EFxuJqI(u"࠲ဪ")]
			except: lfrnN4U8kEvD3tAQHVBc92oMYbGaSg = xJv6NiWUR7DI[aJQuONIydj]
			sDMqyG0jAOK.append(lfrnN4U8kEvD3tAQHVBc92oMYbGaSg)
	fRyZNTkXqiHDv = sDMqyG0jAOK[wTLFCOcM26fmYlW7U]
	for lltPTydzA5 in sDMqyG0jAOK[UD4N8MjVTd:]:
		if RKyqlatE0chfxwJsZ in [WW0AeIrS1dQyvqlnTzO8kaYFc,SjUOalsknhyeYqI6Tf]: Tx6WOfAruY32CZFKokqX1pLRNhJd += NdGEOCnx5J7DKfqgYm
		fRyZNTkXqiHDv += o46hdHaXLqyFwzD+HZcKGP6yrvs7wBCYomXLVF3aq4fUQ+Tx6WOfAruY32CZFKokqX1pLRNhJd+lltPTydzA5
	if RKyqlatE0chfxwJsZ in [GZR3XQMO5J4N7tqEkSwFr6l9L1eb,WW0AeIrS1dQyvqlnTzO8kaYFc]: fRyZNTkXqiHDv += QWLr8ABjev
	fRyZNTkXqiHDv += xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࠠࡠࠩื")
	if lCT8hfYUBX4OQMmL(u"ุࠧࠦࠩ") in fRyZNTkXqiHDv: fRyZNTkXqiHDv = Z6bUG0kDQuFqgzdAa1r(fRyZNTkXqiHDv)
	te28VJiPB7RXcm6brMUQyKAC3Z.log(fRyZNTkXqiHDv,level=Eo8tVk6PZl9b)
	return
def g9gt4a2MOG3kh0FKmHslfCVP(gAS9ocTOnZQ6slVWhJEKUF0yu):
	try: rC0YJ4awbU2H3LOGt5DIF = plTxfrOsuV4McaF2HPg1BiZ396GXI5.connect(gAS9ocTOnZQ6slVWhJEKUF0yu,check_same_thread=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	except:
		if not b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(kAXGQe4sH7o3dfLUKv2zlZDM8r09):
			b7i1PgC8Z4e5BFoHNd9E2UVvfc.makedirs(kAXGQe4sH7o3dfLUKv2zlZDM8r09)
			rC0YJ4awbU2H3LOGt5DIF = plTxfrOsuV4McaF2HPg1BiZ396GXI5.connect(gAS9ocTOnZQ6slVWhJEKUF0yu,check_same_thread=Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	rC0YJ4awbU2H3LOGt5DIF.text_factory = str
	sXeobuj186Q = rC0YJ4awbU2H3LOGt5DIF.cursor()
	sXeobuj186Q.execute(JHMxIE4fs1mvQtKW7R(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡣ࡮ࡴࡤࡦࡺࡀࡲࡴࠦ࠻ࠨู"))
	sXeobuj186Q.execute(yRWQMHxZEz0(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬࡫ࡳࡵࡲࡦࡡࡦ࡬ࡪࡩ࡫ࡠࡥࡲࡲࡸࡺࡲࡢ࡫ࡱࡸࡸࡃࡹࡦࡵࠣ࠿ฺࠬ"))
	sXeobuj186Q.execute(A6Sg45ChDR3BJLYfFH(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡮ࡴࡻࡲ࡯ࡣ࡯ࡣࡲࡵࡤࡦ࠿ࡒࡊࡋࠦ࠻ࠨ฻"))
	sXeobuj186Q.execute(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡸࡿ࡮ࡤࡪࡵࡳࡳࡵࡵࡴ࠿ࡒࡊࡋࠦ࠻ࠨ฼"))
	rC0YJ4awbU2H3LOGt5DIF.commit()
	return rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q
def lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,zN7af5TCyJWnGwkoHeOZvSdtiEx,q4cdux03vDlz2f56jiPSor1,Qf68q93CRSMIoF=()):
	y7ZhGxrtSX2A4DPEWRj0 = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	timeout = s149dk8uh2p7oFzaLxZeI3Or(u"࠳࠳ါ")
	vv6ITU0LMatNfYyqz = L5jXH0fZ8TvsESR.time()
	import XXRNnfOH3e
	while L5jXH0fZ8TvsESR.time()-vv6ITU0LMatNfYyqz<timeout:
		try:
			if zN7af5TCyJWnGwkoHeOZvSdtiEx: y7ZhGxrtSX2A4DPEWRj0 = sXeobuj186Q.executemany(q4cdux03vDlz2f56jiPSor1,Qf68q93CRSMIoF).fetchall()
			else: y7ZhGxrtSX2A4DPEWRj0 = sXeobuj186Q.execute(q4cdux03vDlz2f56jiPSor1,Qf68q93CRSMIoF).fetchall()
			break
		except Exception as vDfaoJbGd4AEqW:
			if vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡪࡵࠣࡰࡴࡩ࡫ࡦࡦࠪ฽") not in str(vDfaoJbGd4AEqW): break
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,s149dk8uh2p7oFzaLxZeI3Or(u"࠭࠮࡝ࡶࡇࡥࡹࡧࡢࡢࡵࡨࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࠨ฾")+gAS9ocTOnZQ6slVWhJEKUF0yu+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡻ࡭࡫࡮ࠡࡧࡻࡩࡨࡻࡴࡪࡰࡪࠤࡹ࡮ࡩࡴࠢࡶࡸࡦࡺࡥ࡮ࡧࡱࡸࠥࠦࠠࠨ฿")+q4cdux03vDlz2f56jiPSor1)
		rC0YJ4awbU2H3LOGt5DIF.commit()
		L5jXH0fZ8TvsESR.sleep(w8JC1y7Lp3(u"࠳࠲࠷࠻ာ"))
	rC0YJ4awbU2H3LOGt5DIF.commit()
	return y7ZhGxrtSX2A4DPEWRj0
def o1oqytTs5j0rx(gAS9ocTOnZQ6slVWhJEKUF0yu,ZZDoCUyJ5B,rUseLjQK1zEDfNJq4blYOA,EMWfSZHVa4v79BKC=b02zsRFX8MweUniGfyPHEZcv7p5WK3):
	ZtoUCFcjmabu = mGiac9zNRLT(ZZDoCUyJ5B)
	BS6lGOtXcQTLiCZb8oVxrkvmuPKpna = OOnvcPQy85HYA.getSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪเ"))
	if rUseLjQK1zEDfNJq4blYOA not in [pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬแ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡆࡒࡌࠨโ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡕࡒࡉࡕࡖࡈࡈࡤࡍࡏࡐࡉࡏࡉࠬใ")] and gAS9ocTOnZQ6slVWhJEKUF0yu==bcP2jUx34tG51D6XSNnyWIes and EMWfSZHVa4v79BKC!=dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧไ"):
		if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna==bQGafNLXyFgsZP6ut(u"࠭ࡓࡕࡑࡓࠫๅ"): return ZtoUCFcjmabu
		vvbRDXmZEyYa = OOnvcPQy85HYA.getSetting(bQGafNLXyFgsZP6ut(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫๆ"))
		if vvbRDXmZEyYa==jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ็"):
			P4B0tvUAVOb5K(gAS9ocTOnZQ6slVWhJEKUF0yu,rUseLjQK1zEDfNJq4blYOA,EMWfSZHVa4v79BKC)
			return ZtoUCFcjmabu
	JnU8wq0Qfj = wTLFCOcM26fmYlW7U
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna==xm6jK1ZMuWq5(u"ࠩࡏࡍࡒࡏࡔࡆࡆ่ࠪ"): JnU8wq0Qfj = GAXY3gMCpfPZty2cnxUuQ
	rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(gAS9ocTOnZQ6slVWhJEKUF0yu)
	if JnU8wq0Qfj: y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,vWNRusF46D7Mi8GpZ(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤ้ࠪ")+rUseLjQK1zEDfNJq4blYOA+jQv0du1iVxTgAXCM(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ๊࠭")+str(yoJ7t3WpjPkrCmTq+JnU8wq0Qfj)+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࠦ࠻ࠨ๋"))
	y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭์")+rUseLjQK1zEDfNJq4blYOA+xdSThjYnuHXAU6M(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩํ")+str(yoJ7t3WpjPkrCmTq)+xdSThjYnuHXAU6M(u"ࠨࠢ࠾ࠫ๎"))
	if EMWfSZHVa4v79BKC:
		y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,llkFwuCyhaP3sK76qO4T(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ๏")+rUseLjQK1zEDfNJq4blYOA+it4DKnryZlx(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ๐"),(str(EMWfSZHVa4v79BKC),))
		if y7ZhGxrtSX2A4DPEWRj0:
			try:
				UWErGF2TqoQ = FSaPuXqyvI24in8rhtEzOoe3.decompress(y7ZhGxrtSX2A4DPEWRj0[wTLFCOcM26fmYlW7U][wTLFCOcM26fmYlW7U])
				ZtoUCFcjmabu = a8avpx1moLl2GqrMQUAt9zibyENYn7.loads(UWErGF2TqoQ)
			except: pass
	else:
		y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ๑")+rUseLjQK1zEDfNJq4blYOA+it4DKnryZlx(u"ࠬࠨࠠ࠼ࠩ๒"))
		if y7ZhGxrtSX2A4DPEWRj0:
			ZtoUCFcjmabu,ppvQtREIdJ9AnTBuPhe4 = {},[]
			for mHQP9ygj25r,FjUcS938pAH5sZ in y7ZhGxrtSX2A4DPEWRj0:
				Z9e2VLl7DY0 = FSaPuXqyvI24in8rhtEzOoe3.decompress(FjUcS938pAH5sZ)
				FjUcS938pAH5sZ = a8avpx1moLl2GqrMQUAt9zibyENYn7.loads(Z9e2VLl7DY0)
				ZtoUCFcjmabu[mHQP9ygj25r] = FjUcS938pAH5sZ
				ppvQtREIdJ9AnTBuPhe4.append(mHQP9ygj25r)
			if ppvQtREIdJ9AnTBuPhe4:
				ZtoUCFcjmabu[VhqD3zp7mUieI8sMQlETH(u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ๓")] = ppvQtREIdJ9AnTBuPhe4
				if ZZDoCUyJ5B==DpRJnas65uVcO0S17dYG(u"ࠧ࡭࡫ࡶࡸࠬ๔"): ZtoUCFcjmabu = ppvQtREIdJ9AnTBuPhe4
	rC0YJ4awbU2H3LOGt5DIF.close()
	return ZtoUCFcjmabu
def SrdxDoWBLbZyCcs30IPNAe2TujH(gAS9ocTOnZQ6slVWhJEKUF0yu,rUseLjQK1zEDfNJq4blYOA,EMWfSZHVa4v79BKC,ZtoUCFcjmabu,mBMSoEeFiIvalnp2Q6JKstq,Bf1HwxokXIeu8gGtc2Osh45TP6EzY0=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
	BS6lGOtXcQTLiCZb8oVxrkvmuPKpna = OOnvcPQy85HYA.getSetting(it4DKnryZlx(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪ๕"))
	if BS6lGOtXcQTLiCZb8oVxrkvmuPKpna==JHMxIE4fs1mvQtKW7R(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ๖") and mBMSoEeFiIvalnp2Q6JKstq>GAXY3gMCpfPZty2cnxUuQ: mBMSoEeFiIvalnp2Q6JKstq = GAXY3gMCpfPZty2cnxUuQ
	if Bf1HwxokXIeu8gGtc2Osh45TP6EzY0:
		V1VfMqTkXdYulSwF75JPhDgZ,kUcE06vfzoKBLNMVX = [],[]
		for qbRmVByrJv18 in range(len(EMWfSZHVa4v79BKC)):
			UWErGF2TqoQ = a8avpx1moLl2GqrMQUAt9zibyENYn7.dumps(ZtoUCFcjmabu[qbRmVByrJv18])
			wahbIdls1X6AORoGyPqFNx = FSaPuXqyvI24in8rhtEzOoe3.compress(UWErGF2TqoQ)
			V1VfMqTkXdYulSwF75JPhDgZ.append((EMWfSZHVa4v79BKC[qbRmVByrJv18],))
			kUcE06vfzoKBLNMVX.append((mBMSoEeFiIvalnp2Q6JKstq+yoJ7t3WpjPkrCmTq,str(EMWfSZHVa4v79BKC[qbRmVByrJv18]),wahbIdls1X6AORoGyPqFNx))
	else:
		UWErGF2TqoQ = a8avpx1moLl2GqrMQUAt9zibyENYn7.dumps(ZtoUCFcjmabu)
		iwRF1dM8XTKpnY7OhBuvVE = FSaPuXqyvI24in8rhtEzOoe3.compress(UWErGF2TqoQ)
	rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(gAS9ocTOnZQ6slVWhJEKUF0yu)
	y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ๗")+rUseLjQK1zEDfNJq4blYOA+VhqD3zp7mUieI8sMQlETH(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ๘"))
	if Bf1HwxokXIeu8gGtc2Osh45TP6EzY0:
		y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,y0yvdNOZkiKEg5RLMhoDVQAB9F2,JHMxIE4fs1mvQtKW7R(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ๙")+rUseLjQK1zEDfNJq4blYOA+dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭๚"),V1VfMqTkXdYulSwF75JPhDgZ)
		y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,y0yvdNOZkiKEg5RLMhoDVQAB9F2,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ๛")+rUseLjQK1zEDfNJq4blYOA+VhqD3zp7mUieI8sMQlETH(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭๜"),kUcE06vfzoKBLNMVX)
	else:
		if mBMSoEeFiIvalnp2Q6JKstq:
			y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,JHMxIE4fs1mvQtKW7R(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ๝")+rUseLjQK1zEDfNJq4blYOA+fmkZtbRj3ux(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ๞"),(str(EMWfSZHVa4v79BKC),))
			y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ๟")+rUseLjQK1zEDfNJq4blYOA+JHMxIE4fs1mvQtKW7R(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ๠"),(mBMSoEeFiIvalnp2Q6JKstq+yoJ7t3WpjPkrCmTq,str(EMWfSZHVa4v79BKC),iwRF1dM8XTKpnY7OhBuvVE))
		else:
			y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨ๡")+rUseLjQK1zEDfNJq4blYOA+erqDsJmL3BQHuGtPkcf0X9(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭๢"),(iwRF1dM8XTKpnY7OhBuvVE,str(EMWfSZHVa4v79BKC)))
	rC0YJ4awbU2H3LOGt5DIF.close()
	return
def P4B0tvUAVOb5K(gAS9ocTOnZQ6slVWhJEKUF0yu,rUseLjQK1zEDfNJq4blYOA,EMWfSZHVa4v79BKC=b02zsRFX8MweUniGfyPHEZcv7p5WK3):
	rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q = g9gt4a2MOG3kh0FKmHslfCVP(gAS9ocTOnZQ6slVWhJEKUF0yu)
	if EMWfSZHVa4v79BKC==b02zsRFX8MweUniGfyPHEZcv7p5WK3: y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,erqDsJmL3BQHuGtPkcf0X9(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ๣")+rUseLjQK1zEDfNJq4blYOA+jQv0du1iVxTgAXCM(u"ࠩࠥࠤࡀ࠭๤"))
	else:
		VkSR2JBY1f4Toq3y9Exw5vZrQz = (str(EMWfSZHVa4v79BKC),)
		if yRWQMHxZEz0(u"ࠪࠩࠬ๥") in EMWfSZHVa4v79BKC: y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,VhqD3zp7mUieI8sMQlETH(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ๦")+rUseLjQK1zEDfNJq4blYOA+fmkZtbRj3ux(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ๧"),VkSR2JBY1f4Toq3y9Exw5vZrQz)
		else: y7ZhGxrtSX2A4DPEWRj0 = lQ39XPxZLfupRTm(gAS9ocTOnZQ6slVWhJEKUF0yu,rC0YJ4awbU2H3LOGt5DIF,sXeobuj186Q,Z19pUxa2gfGMNKoDsEuytn85SjFvA,D2PpKMeZFWrmfxTSs4L1tz(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭๨")+rUseLjQK1zEDfNJq4blYOA+rDG9dZoXRhCJcieUSF0KB(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ๩"),VkSR2JBY1f4Toq3y9Exw5vZrQz)
	rC0YJ4awbU2H3LOGt5DIF.close()
	return
class iKIMlmaN13GzVckUdBTnbXerJ(): pass
class D8JlSY7NibwpLWxPXAfFgQsd(iKIMlmaN13GzVckUdBTnbXerJ):
	def __init__(xGBhIZ1EXiTudDJ5gwr8):
		xGBhIZ1EXiTudDJ5gwr8.url = wUvcPrYDfISbZolAm83GKEqMyXkn5
		xGBhIZ1EXiTudDJ5gwr8.code = -bQGafNLXyFgsZP6ut(u"࠽࠾ိ")
		xGBhIZ1EXiTudDJ5gwr8.reason = wUvcPrYDfISbZolAm83GKEqMyXkn5
		xGBhIZ1EXiTudDJ5gwr8.content = wUvcPrYDfISbZolAm83GKEqMyXkn5
		xGBhIZ1EXiTudDJ5gwr8.headers = {}
		xGBhIZ1EXiTudDJ5gwr8.cookies = {}
		xGBhIZ1EXiTudDJ5gwr8.succeeded = Z19pUxa2gfGMNKoDsEuytn85SjFvA
def mGiac9zNRLT(KUOoYcT20iCLVgsw1ejzdkHp7XW):
	if KUOoYcT20iCLVgsw1ejzdkHp7XW==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡦ࡬ࡧࡹ࠭๪"): ZtoUCFcjmabu = {}
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==A6Sg45ChDR3BJLYfFH(u"ࠩ࡯࡭ࡸࡺࠧ๫"): ZtoUCFcjmabu = []
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠪࡸࡺࡶ࡬ࡦࠩ๬"): ZtoUCFcjmabu = ()
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡸࡺࡲࠨ๭"): ZtoUCFcjmabu = wUvcPrYDfISbZolAm83GKEqMyXkn5
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬ࡯࡮ࡵࠩ๮"): ZtoUCFcjmabu = wTLFCOcM26fmYlW7U
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡢࡰࡱ࡯ࠫ๯"): ZtoUCFcjmabu = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	elif KUOoYcT20iCLVgsw1ejzdkHp7XW==w8JC1y7Lp3(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ๰"): ZtoUCFcjmabu = D8JlSY7NibwpLWxPXAfFgQsd()
	elif not KUOoYcT20iCLVgsw1ejzdkHp7XW: ZtoUCFcjmabu = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	else: ZtoUCFcjmabu = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	return ZtoUCFcjmabu
def WtlCneczGPY2ODSUrAh5jdsf6m(kWC2XTJtu70mZiBg1Rx):
	xMoiLw2ctbPBhUaSGngKRN63 = OOnvcPQy85HYA.getSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫ๱"))
	wE8xBbfWv0JzSmUHPRFe6nAyh = TTuO14NzmB.AV_CLIENT_IDS.splitlines()
	CViSa73qHn0NrZ8dktxXUTeI9uf2F = wTLFCOcM26fmYlW7U
	DDTmGWrIla0A74 = len(kWC2XTJtu70mZiBg1Rx)
	XJ53bUr4ZD = [Z19pUxa2gfGMNKoDsEuytn85SjFvA]*DDTmGWrIla0A74
	for PnIyc1zoMdFwWsX5 in [yoJ7t3WpjPkrCmTq,yoJ7t3WpjPkrCmTq-D0tF2C71Kej5zrAgB6uMJZsI]:
		Z2bKvVdMLANB7lGcU4hgjJT85fy = str(PnIyc1zoMdFwWsX5*MFhbWia58mP3su0fk2d(u"࠷࠰࠱࠲࠳࠴࠳࠶ု")/weh7SGmuTgXOVRcMo1rlLq(u"࠹࠹࠲࠱࠲࠳ီ"))[wTLFCOcM26fmYlW7U:erqDsJmL3BQHuGtPkcf0X9(u"࠴ူ")]
		if Z2bKvVdMLANB7lGcU4hgjJT85fy!=CViSa73qHn0NrZ8dktxXUTeI9uf2F:
			for aJQuONIydj in range(DDTmGWrIla0A74):
				if not XJ53bUr4ZD[aJQuONIydj]:
					DvyB3Hri17aCIO84YtkQ = Z19pUxa2gfGMNKoDsEuytn85SjFvA
					for oK9Had27sw0DWr1lQkRcTn in wE8xBbfWv0JzSmUHPRFe6nAyh:
						bQUmGIdJzOKT = xm6jK1ZMuWq5(u"࡛ࠩ࠵࠾࠭๲")+kWC2XTJtu70mZiBg1Rx[aJQuONIydj]+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪ࠵࠽ࡃࠧ๳")+oK9Had27sw0DWr1lQkRcTn[-bQGafNLXyFgsZP6ut(u"࠳࠶ေ"):]+D1DBSuO0lLGRbcfCyY+Z2bKvVdMLANB7lGcU4hgjJT85fy
						bQUmGIdJzOKT = vlnTfwNrdtCPUWhcu8Ip.md5(bQUmGIdJzOKT.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)).hexdigest()[:weh7SGmuTgXOVRcMo1rlLq(u"࠵࠵ဲ")]
						if bQUmGIdJzOKT in xMoiLw2ctbPBhUaSGngKRN63:
							DvyB3Hri17aCIO84YtkQ = y0yvdNOZkiKEg5RLMhoDVQAB9F2
							break
					XJ53bUr4ZD[aJQuONIydj] = DvyB3Hri17aCIO84YtkQ
		CViSa73qHn0NrZ8dktxXUTeI9uf2F = Z2bKvVdMLANB7lGcU4hgjJT85fy
	return XJ53bUr4ZD
class VYKkdLDhHgT(A7qlH50rEQ6WtyMUSs1pcP):
	def __init__(xGBhIZ1EXiTudDJ5gwr8): pass
	def GH2wZiLUJK7AuzVfEbngQsD9CTMv(xGBhIZ1EXiTudDJ5gwr8,QyYnhC05DJzdMWP8powG72Fgu):
		xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = Gj3rMP1Cb8wHdp49la0(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ๴") if TTuO14NzmB.lOuLW0pjdgS4zX else wUvcPrYDfISbZolAm83GKEqMyXkn5
		xGBhIZ1EXiTudDJ5gwr8.QyYnhC05DJzdMWP8powG72Fgu = QyYnhC05DJzdMWP8powG72Fgu
		if not TTuO14NzmB.W1haXcb7tVZ6K:
			import zpCIRgy3H2
			zpCIRgy3H2.reWToLljkJG72aSDM0q4uVFwxO(BBpIqDLUVNcW9fZ1eKnrYoka52Cz8X)
	def onPlayBackStopped(xGBhIZ1EXiTudDJ5gwr8): xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = Gj3rMP1Cb8wHdp49la0(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ๵")
	def onPlayBackError(xGBhIZ1EXiTudDJ5gwr8): xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = kPCxIUZb1V(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭๶")
	def onPlayBackEnded(xGBhIZ1EXiTudDJ5gwr8): xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = DpRJnas65uVcO0S17dYG(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ๷")
	def onPlayBackStarted(xGBhIZ1EXiTudDJ5gwr8):
		xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = bQGafNLXyFgsZP6ut(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ๸")
		gFt3WN8sGjo7 = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=xGBhIZ1EXiTudDJ5gwr8.faHBucrCimj65dnIP2KzvEwh7b)
		gFt3WN8sGjo7.start()
	def onAVStarted(xGBhIZ1EXiTudDJ5gwr8):
		if TTuO14NzmB.W1haXcb7tVZ6K: xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = fmkZtbRj3ux(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ๹")
		else: xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = bQGafNLXyFgsZP6ut(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ๺")
	def faHBucrCimj65dnIP2KzvEwh7b(xGBhIZ1EXiTudDJ5gwr8):
		hNbaButAM5oXesFYq = wTLFCOcM26fmYlW7U
		while not eval(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩ๻"),{xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡾࡢ࡮ࡥࠪ๼"):te28VJiPB7RXcm6brMUQyKAC3Z}) and xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt==it4DKnryZlx(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ๽"):
			te28VJiPB7RXcm6brMUQyKAC3Z.sleep(w8JC1y7Lp3(u"࠴࠴࠵࠶ဳ"))
			hNbaButAM5oXesFYq += UD4N8MjVTd
			if hNbaButAM5oXesFYq>weh7SGmuTgXOVRcMo1rlLq(u"࠺࠵ဴ"): return
		if TTuO14NzmB.lOuLW0pjdgS4zX: xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = it4DKnryZlx(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ๾")
		elif TTuO14NzmB.W1haXcb7tVZ6K: xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = xm6jK1ZMuWq5(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ๿")
		elif TTuO14NzmB.ijmTSzJ1l9Nutf3aoVEZk:
			import zpCIRgy3H2
			xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = vvhR5ozeiJpANyl8fFO3GBw(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ຀")
			ICwWPArNgl5tj38ZSYdX(jQv0du1iVxTgAXCM(u"ࠪࡷࡹࡵࡰࠨກ"),y0yvdNOZkiKEg5RLMhoDVQAB9F2)
			lfvUeQL2gYcy8sXnwz = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=zpCIRgy3H2.dXnTSyEAseij,args=(xGBhIZ1EXiTudDJ5gwr8.QyYnhC05DJzdMWP8powG72Fgu,)).start()
			bW65EocNq4SHx70Iv8JDeLYRlzQudj = oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=zpCIRgy3H2.iiGQEx4rS5vJM2te0F3Cl).start()
		else: xGBhIZ1EXiTudDJ5gwr8.TZwiXMoENgajSu5PqQ48FW7kt = Gj3rMP1Cb8wHdp49la0(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬຂ")
def gYWLp6jmkhl2Mo3XdTO9Bu7AV():
	Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	fuQ4pIwb2zr1aHyF0nRTU6eAlNC = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡪࡧࡱࡨࡱࡿࡎࡢ࡯ࡨࠫ຃"))
	try:
		sT3HuVYDzGPmBQJbv4rqUtanK = open(MFhbWia58mP3su0fk2d(u"࠭࠯ࡱࡴࡲࡧ࠴ࡩࡰࡶ࡫ࡱࡪࡴ࠭ຄ"),llkFwuCyhaP3sK76qO4T(u"ࠧࡳࡤࠪ຅")).read()
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: sT3HuVYDzGPmBQJbv4rqUtanK = sT3HuVYDzGPmBQJbv4rqUtanK.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		oMXIbK4tdRxpjAse = jj0dZrgiKb.findall(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡕࡨࡶ࡮ࡧ࡬࠯ࠬࡂ࠾ࠥ࠮࠮ࠫࡁࠬࠨࠬຆ"),sT3HuVYDzGPmBQJbv4rqUtanK,jj0dZrgiKb.IGNORECASE)
		if oMXIbK4tdRxpjAse: Z3n0amhs2wY7AgePXxOStEoKBDjp = oMXIbK4tdRxpjAse[wTLFCOcM26fmYlW7U]
	except: pass
	try:
		import subprocess as h2m70uBJUrjN9RxFqIYkdPc341Dao
		cXuqNYCZtLh2Pfsxz = h2m70uBJUrjN9RxFqIYkdPc341Dao.Popen(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡶࡸࡦࡺࠠ࠮ࡥࠣࠦࠥࠫࡘࠡࠤࠣ࠳ࡸࡺ࡯ࡳࡣࡪࡩ࠴࡫࡭ࡶ࡮ࡤࡸࡪࡪ࠯࠱ࠢ࠾ࠤࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡙ࠠࠦࠣࠦࠥ࠵ࡶࡢࡴ࠲ࡰࡴ࡭ࠧງ"),shell=y0yvdNOZkiKEg5RLMhoDVQAB9F2,stdin=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE,stdout=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE,stderr=h2m70uBJUrjN9RxFqIYkdPc341Dao.PIPE)
		y5yqAs6TeXtOiPYl = cXuqNYCZtLh2Pfsxz.stdout.read()
		if y5yqAs6TeXtOiPYl:
			if wwMdFkWvcRYiXHB7yDrCqnKb98o:
				y5yqAs6TeXtOiPYl = y5yqAs6TeXtOiPYl.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq,w8JC1y7Lp3(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪຈ"))
			y8QoqRrgK6 = jj0dZrgiKb.findall(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࠥ࠮࡜ࡥࡽ࠴࠴ࢂ࠯ࠠࠨຉ"),y5yqAs6TeXtOiPYl,jj0dZrgiKb.IGNORECASE)
			if y8QoqRrgK6: DeMvgROF3AZCN4 = min(y8QoqRrgK6)
	except: pass
	return fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4
def pnhyIzwgbCTmxs(RBAQcos7arNqj38OK6LPxCE=y0yvdNOZkiKEg5RLMhoDVQAB9F2,YakLyiA3MO9dZCjwP7fxE2=Gj3rMP1Cb8wHdp49la0(u"࠸࠸ဵ")):
	MSRtwn1siDoH5pluk = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	if RBAQcos7arNqj38OK6LPxCE:
		GGEcR6ylbVJePu = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,weh7SGmuTgXOVRcMo1rlLq(u"ࠬࡲࡩࡴࡶࠪຊ"),lCT8hfYUBX4OQMmL(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ຋"),lCT8hfYUBX4OQMmL(u"ࠧࡔࡋࡗࡉࡘࡥࡃࡉࡇࡆࡏࠬຌ"))
		if GGEcR6ylbVJePu:
			hhXr9bcDZSgFGT7ApzxUofVwRC,gHh2bAXnxfmIK1,ddasBvFEhwMy3N2Ol9tGmqIjPnSoeC,IfkcR5De6VTtgA8UuKYMQaZx0P1X2 = GGEcR6ylbVJePu
			MSRtwn1siDoH5pluk = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࡮࡬ࡷࡹ࠭ຍ"),bQGafNLXyFgsZP6ut(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬຎ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡗࡎ࡚ࡅࡔࡡ࡙ࡉࡗࡏࡆ࡚ࠩຏ"))
			if MSRtwn1siDoH5pluk: fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4 = MSRtwn1siDoH5pluk
			else: fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4 = gYWLp6jmkhl2Mo3XdTO9Bu7AV()
			if (gHh2bAXnxfmIK1,ddasBvFEhwMy3N2Ol9tGmqIjPnSoeC,IfkcR5De6VTtgA8UuKYMQaZx0P1X2)==(fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4):
				H8dzYTASXGRFQI72Pb = QWLr8ABjev.join(hhXr9bcDZSgFGT7ApzxUofVwRC)
				return H8dzYTASXGRFQI72Pb
	if MSRtwn1siDoH5pluk: fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4 = gYWLp6jmkhl2Mo3XdTO9Bu7AV()
	global JK304McnsgqOvCmWYd6u2,LmqBiIKSnP7tURHE3wluCM
	JK304McnsgqOvCmWYd6u2,LmqBiIKSnP7tURHE3wluCM,HHkTtfg3NpcKhR = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	YakLyiA3MO9dZCjwP7fxE2 = YakLyiA3MO9dZCjwP7fxE2//Tb7oymMnpflsSv3eu4Pz2
	oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=P2nLdA3OrgTqDUYc).start()
	oKC1TfNgGlbj(daemon=y0yvdNOZkiKEg5RLMhoDVQAB9F2,target=C2sGmIfLlwyvViB3W1tabupZqd).start()
	for qbRmVByrJv18 in range(jQv0du1iVxTgAXCM(u"࠷࠰ံ")):
		L5jXH0fZ8TvsESR.sleep(jQv0du1iVxTgAXCM(u"࠰࠯࠷့"))
		if not HHkTtfg3NpcKhR:
			try:
				waOkVXFdcmBbrznH4pZASU = te28VJiPB7RXcm6brMUQyKAC3Z.getInfoLabel(it4DKnryZlx(u"ࠫࡓ࡫ࡴࡸࡱࡵ࡯࠳ࡓࡡࡤࡃࡧࡨࡷ࡫ࡳࡴࠩຐ"))
				if waOkVXFdcmBbrznH4pZASU.count(DpRJnas65uVcO0S17dYG(u"ࠬࡀࠧຑ"))==ewJ9sTMmXtWH0ANVShQ2 and waOkVXFdcmBbrznH4pZASU.count(rDG9dZoXRhCJcieUSF0KB(u"࠭࠰ࠨຒ"))<vWNRusF46D7Mi8GpZ(u"࠺း"):
					waOkVXFdcmBbrznH4pZASU = waOkVXFdcmBbrznH4pZASU.lower().replace(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧ࠻ࠩຓ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
					HHkTtfg3NpcKhR = str(int(waOkVXFdcmBbrznH4pZASU,A6Sg45ChDR3BJLYfFH(u"࠳࠹္")))
			except: pass
		if JK304McnsgqOvCmWYd6u2 and LmqBiIKSnP7tURHE3wluCM and HHkTtfg3NpcKhR: break
	uforYX0HJRVvGUz = [LmqBiIKSnP7tURHE3wluCM,JK304McnsgqOvCmWYd6u2,HHkTtfg3NpcKhR,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,JHMxIE4fs1mvQtKW7R(u"ࠨ࠲࠳࠵࠶࠸࠲࠴࠵࠷࠸࠺࠻࠶࠷࠹࠺ࠫດ")]
	if Z3n0amhs2wY7AgePXxOStEoKBDjp or DeMvgROF3AZCN4:
		oxqfjRu7eGK69S3dpzUDkmctJ8CEW = [(R9RNUT6WAPEYjHqtIokxuXs,Z3n0amhs2wY7AgePXxOStEoKBDjp),(ewJ9sTMmXtWH0ANVShQ2,DeMvgROF3AZCN4)]
		for NH79yB8ocSkVP2IRdOeE6UrXuh,neGOw8MuxH5gCSk4 in oxqfjRu7eGK69S3dpzUDkmctJ8CEW:
			neGOw8MuxH5gCSk4 = neGOw8MuxH5gCSk4.strip(erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࠳ࠫຕ"))
			if neGOw8MuxH5gCSk4:
				if wwMdFkWvcRYiXHB7yDrCqnKb98o: neGOw8MuxH5gCSk4 = neGOw8MuxH5gCSk4.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				neGOw8MuxH5gCSk4 = str(int(vlnTfwNrdtCPUWhcu8Ip.md5(neGOw8MuxH5gCSk4).hexdigest(),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠶࠺်")))
				vDCzM7FdkaNmSspORx694GjunL = [int(neGOw8MuxH5gCSk4[ppTbC4PDLQ263uOqlvIS:ppTbC4PDLQ263uOqlvIS+VhqD3zp7mUieI8sMQlETH(u"࠵࠺ျ")]) for ppTbC4PDLQ263uOqlvIS in range(len(neGOw8MuxH5gCSk4)) if ppTbC4PDLQ263uOqlvIS%VhqD3zp7mUieI8sMQlETH(u"࠵࠺ျ")==wTLFCOcM26fmYlW7U]
				uforYX0HJRVvGUz[NH79yB8ocSkVP2IRdOeE6UrXuh-UD4N8MjVTd] = str(sum(vDCzM7FdkaNmSspORx694GjunL))
	wE8xBbfWv0JzSmUHPRFe6nAyh,pRIeOhEgj3N1HiZ = [],Z19pUxa2gfGMNKoDsEuytn85SjFvA
	for HLDdCsREofqQvwuzKBgJhA1rkl80b3,vDCzM7FdkaNmSspORx694GjunL in enumerate(uforYX0HJRVvGUz):
		if not vDCzM7FdkaNmSspORx694GjunL: continue
		if pRIeOhEgj3N1HiZ and vDCzM7FdkaNmSspORx694GjunL==uforYX0HJRVvGUz[-UD4N8MjVTd]: continue
		pRIeOhEgj3N1HiZ = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		vDCzM7FdkaNmSspORx694GjunL = jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠪ࠴ࠬຖ")*YakLyiA3MO9dZCjwP7fxE2+vDCzM7FdkaNmSspORx694GjunL
		vDCzM7FdkaNmSspORx694GjunL = vDCzM7FdkaNmSspORx694GjunL[-YakLyiA3MO9dZCjwP7fxE2:]
		Splbq1vRiIFgAfZjPt5G48KE9m,G0nKLSw3N7B8eaZysYRHmD4 = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
		JRexofPvr784z2KqhOmApEtjGkZ3X = str(int(MFhbWia58mP3su0fk2d(u"ࠫ࠾࠭ທ")*(YakLyiA3MO9dZCjwP7fxE2+UD4N8MjVTd))-int(vDCzM7FdkaNmSspORx694GjunL))[-YakLyiA3MO9dZCjwP7fxE2:]
		for aJQuONIydj in list(range(wTLFCOcM26fmYlW7U,YakLyiA3MO9dZCjwP7fxE2,R9RNUT6WAPEYjHqtIokxuXs)):
			Splbq1vRiIFgAfZjPt5G48KE9m += JRexofPvr784z2KqhOmApEtjGkZ3X[aJQuONIydj:aJQuONIydj+R9RNUT6WAPEYjHqtIokxuXs]+xm6jK1ZMuWq5(u"ࠬ࠳ࠧຘ")
			G0nKLSw3N7B8eaZysYRHmD4 += str(sum(map(int,vDCzM7FdkaNmSspORx694GjunL[aJQuONIydj:aJQuONIydj+R9RNUT6WAPEYjHqtIokxuXs]))%w8JC1y7Lp3(u"࠶࠶ြ"))
		oK9Had27sw0DWr1lQkRcTn = str(HLDdCsREofqQvwuzKBgJhA1rkl80b3)+Splbq1vRiIFgAfZjPt5G48KE9m+G0nKLSw3N7B8eaZysYRHmD4
		wE8xBbfWv0JzSmUHPRFe6nAyh.append(oK9Had27sw0DWr1lQkRcTn)
	oRCj14aT3pAhec,hhXr9bcDZSgFGT7ApzxUofVwRC = [],[]
	for user in wE8xBbfWv0JzSmUHPRFe6nAyh:
		count = str(str(wE8xBbfWv0JzSmUHPRFe6nAyh).count(user[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠷ွ"):]))
		oRCj14aT3pAhec.append(count+user)
	oRCj14aT3pAhec = sorted(oRCj14aT3pAhec,reverse=y0yvdNOZkiKEg5RLMhoDVQAB9F2,key=lambda key: key[wTLFCOcM26fmYlW7U])
	for user in oRCj14aT3pAhec: hhXr9bcDZSgFGT7ApzxUofVwRC.append(user[UD4N8MjVTd:])
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,kPCxIUZb1V(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩນ"),DpRJnas65uVcO0S17dYG(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭ບ"),[fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4],d2priEnu57KztRsm8wCHZ)
	SrdxDoWBLbZyCcs30IPNAe2TujH(bcP2jUx34tG51D6XSNnyWIes,TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫປ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧຜ"),[hhXr9bcDZSgFGT7ApzxUofVwRC,fuQ4pIwb2zr1aHyF0nRTU6eAlNC,Z3n0amhs2wY7AgePXxOStEoKBDjp,DeMvgROF3AZCN4],d2priEnu57KztRsm8wCHZ)
	for user in TTuO14NzmB.BADCOMMONIDS:
		if user in hhXr9bcDZSgFGT7ApzxUofVwRC: hhXr9bcDZSgFGT7ApzxUofVwRC.remove(user)
	H8dzYTASXGRFQI72Pb = QWLr8ABjev.join(hhXr9bcDZSgFGT7ApzxUofVwRC)
	return H8dzYTASXGRFQI72Pb
def P2nLdA3OrgTqDUYc():
	global JK304McnsgqOvCmWYd6u2
	try:
		import getmac82 as x9Lh2rSBMT
		vtTphFn6g5l8DrPao2zyLcmE = x9Lh2rSBMT.get_mac_address()
		if vtTphFn6g5l8DrPao2zyLcmE.count(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪ࠾ࠬຝ"))==ewJ9sTMmXtWH0ANVShQ2 and vtTphFn6g5l8DrPao2zyLcmE.count(xdSThjYnuHXAU6M(u"ࠫ࠵࠭ພ"))<ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠹ှ"):
			vtTphFn6g5l8DrPao2zyLcmE = vtTphFn6g5l8DrPao2zyLcmE.lower().replace(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡀࠧຟ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			JK304McnsgqOvCmWYd6u2 = str(int(vtTphFn6g5l8DrPao2zyLcmE,s149dk8uh2p7oFzaLxZeI3Or(u"࠲࠸ဿ")))
	except: pass
	return
def C2sGmIfLlwyvViB3W1tabupZqd():
	global LmqBiIKSnP7tURHE3wluCM
	try:
		import getmac95 as KFuyeR2GZJlEgnQ6MC
		N07jKidS1fax = KFuyeR2GZJlEgnQ6MC.get_mac_address()
		if N07jKidS1fax.count(jQv0du1iVxTgAXCM(u"࠭࠺ࠨຠ"))==ewJ9sTMmXtWH0ANVShQ2 and N07jKidS1fax.count(bQGafNLXyFgsZP6ut(u"ࠧ࠱ࠩມ"))<jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠻၀"):
			N07jKidS1fax = N07jKidS1fax.lower().replace(vvhR5ozeiJpANyl8fFO3GBw(u"ࠨ࠼ࠪຢ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			LmqBiIKSnP7tURHE3wluCM = str(int(N07jKidS1fax,TNw1pBHb8CtSZe0EFxuJqI(u"࠴࠺၁")))
	except: pass
	return
def xtowQRgA89lOqs4GKv(KUOoYcT20iCLVgsw1ejzdkHp7XW,xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0,xRVnhbcSF5v1NBQI):
	XubVRNO48BsjJASlmeKwdTCr = str(zQfGP7LOR8YrN04CwgaUvtpb9)[wTLFCOcM26fmYlW7U:fmkZtbRj3ux(u"࠶࠺࠶၂")].replace(QWLr8ABjev,yRWQMHxZEz0(u"ࠩ࡟ࡠࡳ࠭ຣ")).replace(o46hdHaXLqyFwzD,w8JC1y7Lp3(u"ࠪࡠࡡࡸࠧ຤")).replace(fy2aLFcjDnoxIzGi1gp7,UKFZBQAVXHI5s17LyvuRpCY2).replace(DQCpAXVq6LHJ0aEFR,UKFZBQAVXHI5s17LyvuRpCY2)
	if len(str(zQfGP7LOR8YrN04CwgaUvtpb9))>xdSThjYnuHXAU6M(u"࠷࠻࠰၃"): XubVRNO48BsjJASlmeKwdTCr = XubVRNO48BsjJASlmeKwdTCr+xm6jK1ZMuWq5(u"ࠫࠥ࠴࠮࠯ࠩລ")
	FjUcS938pAH5sZ = A6Sg45ChDR3BJLYfFH(u"ࠬ࠴࠮࠯ࠩ຦")
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࠨວ")+KUOoYcT20iCLVgsw1ejzdkHp7XW+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪຨ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(xLDEnp9WdA,xVwDZbA6EOjpgX0)+xm6jK1ZMuWq5(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪຩ")+xVwDZbA6EOjpgX0+w8JC1y7Lp3(u"ࠩࠣࡡࠥࠦࠠࡎࡧࡷ࡬ࡴࡪ࠺ࠡ࡝ࠣࠫສ")+xRVnhbcSF5v1NBQI+xdSThjYnuHXAU6M(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ຫ")+str(XubVRNO48BsjJASlmeKwdTCr)+it4DKnryZlx(u"ࠫࠥࡣࠠࠡࠢࡇࡥࡹࡧ࠺ࠡ࡝ࠣࠫຬ")+FjUcS938pAH5sZ+A6Sg45ChDR3BJLYfFH(u"ࠬࠦ࡝ࠨອ"))
	return
def wBxAjV0NKzMhD2daHCU8TLRbu6lirO(xRVnhbcSF5v1NBQI,ee1bnUyAYLKj9MPQdVJazB2GIv,ZtoUCFcjmabu=wUvcPrYDfISbZolAm83GKEqMyXkn5,zQfGP7LOR8YrN04CwgaUvtpb9=wUvcPrYDfISbZolAm83GKEqMyXkn5,xVwDZbA6EOjpgX0=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: import urllib.request as m2EJSeG47TZg9IUWF1
	else: import urllib2 as m2EJSeG47TZg9IUWF1
	if not zQfGP7LOR8YrN04CwgaUvtpb9: zQfGP7LOR8YrN04CwgaUvtpb9 = {DpRJnas65uVcO0S17dYG(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪຮ"):wUvcPrYDfISbZolAm83GKEqMyXkn5}
	if not ZtoUCFcjmabu: ZtoUCFcjmabu = {}
	RGzrf0M7j3YQLldHE8VsCpbt4U6c = ZtoUCFcjmabu
	DNhXwGLOTi1vICJtuW9MpsF78K = ee1bnUyAYLKj9MPQdVJazB2GIv in TTuO14NzmB.SITESURLS[xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧຯ")]
	if DNhXwGLOTi1vICJtuW9MpsF78K:
		xRVnhbcSF5v1NBQI = MFhbWia58mP3su0fk2d(u"ࠨࡒࡒࡗ࡙࠭ະ")
		zQfGP7LOR8YrN04CwgaUvtpb9[SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡄ࡚࠲ࡋ࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩັ")] = xdSThjYnuHXAU6M(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨາ")
		s4T6tLx8UMYoZ91GXiCVaf = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(ZtoUCFcjmabu)
		import zpCIRgy3H2
		RGzrf0M7j3YQLldHE8VsCpbt4U6c = zpCIRgy3H2.juhIT8SaBn9(s4T6tLx8UMYoZ91GXiCVaf,VhqD3zp7mUieI8sMQlETH(u"࠾࠱࠳࠹࠷࠽࠸࠻࠶၄"))
		ee1bnUyAYLKj9MPQdVJazB2GIv = ee1bnUyAYLKj9MPQdVJazB2GIv+SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫࡄࡻࡳࡦࡴࡀࠫຳ")+wLpPS96U1IKRxFzjVtHZG
	elif xRVnhbcSF5v1NBQI==rDG9dZoXRhCJcieUSF0KB(u"ࠬࡍࡅࡕࠩິ"):
		ee1bnUyAYLKj9MPQdVJazB2GIv = ee1bnUyAYLKj9MPQdVJazB2GIv+rDG9dZoXRhCJcieUSF0KB(u"࠭࠿ࠨີ")+rqPJzRuUF2L(ZtoUCFcjmabu)
		RGzrf0M7j3YQLldHE8VsCpbt4U6c = b02zsRFX8MweUniGfyPHEZcv7p5WK3
	elif xRVnhbcSF5v1NBQI==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡑࡑࡖࡘࠬຶ") and ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࡬ࡶࡳࡳ࠭ື") in str(zQfGP7LOR8YrN04CwgaUvtpb9):
		ZtoUCFcjmabu = bbeLsVCqouaSH53E0XmKh4AnFD.dumps(ZtoUCFcjmabu)
		RGzrf0M7j3YQLldHE8VsCpbt4U6c = str(ZtoUCFcjmabu).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	elif xRVnhbcSF5v1NBQI==rDG9dZoXRhCJcieUSF0KB(u"ࠩࡓࡓࡘຸ࡚ࠧ"):
		ZtoUCFcjmabu = rqPJzRuUF2L(ZtoUCFcjmabu)
		RGzrf0M7j3YQLldHE8VsCpbt4U6c = ZtoUCFcjmabu.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	xtowQRgA89lOqs4GKv(gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡙ࠪࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡏࡑࡇࡑࡣ࡚ࡘࡌࠨູ"),ee1bnUyAYLKj9MPQdVJazB2GIv,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,xVwDZbA6EOjpgX0,xRVnhbcSF5v1NBQI)
	try:
		LUsQT9bpPJ483I17xhvXM = m2EJSeG47TZg9IUWF1.Request(ee1bnUyAYLKj9MPQdVJazB2GIv,headers=zQfGP7LOR8YrN04CwgaUvtpb9,data=RGzrf0M7j3YQLldHE8VsCpbt4U6c)
		lGQxR39dqyUb1YFcCmjZN5EthrpJ = m2EJSeG47TZg9IUWF1.urlopen(LUsQT9bpPJ483I17xhvXM)
		OfFQYdjeBCg3or5W = lGQxR39dqyUb1YFcCmjZN5EthrpJ.read()
		TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = D2PpKMeZFWrmfxTSs4L1tz(u"࠲࠱࠲၅"),kPCxIUZb1V(u"ࠫࡔࡑ຺ࠧ")
	except:
		OfFQYdjeBCg3or5W = wUvcPrYDfISbZolAm83GKEqMyXkn5
		TeuQd8DXNkc0zlYmKF2J,Kw19luY7W2jGgsBa5n4hctLfFS = -UD4N8MjVTd,VhqD3zp7mUieI8sMQlETH(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬົ")
	try:
		if DNhXwGLOTi1vICJtuW9MpsF78K and OfFQYdjeBCg3or5W:
			AwCeIGihEBXjvLtHDxa0KFblQ9T1m7 = {YYaiweEBOS4tVKfQz7mT.lower(): Uh9uHWxapqMCPbAmGngc for YYaiweEBOS4tVKfQz7mT, Uh9uHWxapqMCPbAmGngc in lGQxR39dqyUb1YFcCmjZN5EthrpJ.headers.items()}
			if AwCeIGihEBXjvLtHDxa0KFblQ9T1m7.get(TNw1pBHb8CtSZe0EFxuJqI(u"࠭ࡡࡷ࠯ࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ຼ"))==gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠳࠱࠴ࠬຽ"):
				OfFQYdjeBCg3or5W,TQXKiPhvRf3xjGJBdeCObVIrD2U60w = zpCIRgy3H2.FSLKwjQivEZ80xpTarcoN92UXeO(OfFQYdjeBCg3or5W,vWNRusF46D7Mi8GpZ(u"࠹࠳࠵࠻࠹࠿࠳࠶࠸၆"))
				if TQXKiPhvRf3xjGJBdeCObVIrD2U60w==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡋࡑ࡚ࡆࡒࡉࡅࡡࡗࡍࡒࡋࡓࡕࡃࡐࡔࠬ຾"):
					Kw19luY7W2jGgsBa5n4hctLfFS,TeuQd8DXNkc0zlYmKF2J = erqDsJmL3BQHuGtPkcf0X9(u"ࠩࡌࡲࡻࡧ࡬ࡪࡦࠣࡅࡕࡏࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࠪ຿"),-ewJ9sTMmXtWH0ANVShQ2
					OfFQYdjeBCg3or5W = Kw19luY7W2jGgsBa5n4hctLfFS
	except: OfFQYdjeBCg3or5W = wUvcPrYDfISbZolAm83GKEqMyXkn5
	if wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(OfFQYdjeBCg3or5W,bytes): OfFQYdjeBCg3or5W = OfFQYdjeBCg3or5W.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
	KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࡠࡹࡢࡴࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬເ")+str(TeuQd8DXNkc0zlYmKF2J)+yRWQMHxZEz0(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ແ")+Kw19luY7W2jGgsBa5n4hctLfFS+TNw1pBHb8CtSZe0EFxuJqI(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧໂ")+xVwDZbA6EOjpgX0+gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬໃ")+QEbx35yvreoT2sPDG4k9Fcfa8Z(ee1bnUyAYLKj9MPQdVJazB2GIv,xVwDZbA6EOjpgX0)+it4DKnryZlx(u"ࠧࠡ࡟ࠪໄ"))
	return OfFQYdjeBCg3or5W
def XTweElMAbf4dmqakGRPWY0Z(Yg3lURJL9mOZIBKoMsc15eqkN8Cjt):
	g5eBG9fzWs28NjMnV = str(kItsbxAFUXc3.randrange(weh7SGmuTgXOVRcMo1rlLq(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷၇"),bQGafNLXyFgsZP6ut(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹၈")))
	Z8moybI7Rz96SvBltdFUGQEX3NWAjY = {
		erqDsJmL3BQHuGtPkcf0X9(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤ໅"):wLpPS96U1IKRxFzjVtHZG,
		jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨໆ"):str(Uy6GWujQiBLhodP),
		w8JC1y7Lp3(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ໇"):D1DBSuO0lLGRbcfCyY,
		Gj3rMP1Cb8wHdp49la0(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼ່ࠦ"):D1DBSuO0lLGRbcfCyY,
		pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳ້ࠢ"): D1DBSuO0lLGRbcfCyY,
		TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࡣࡢࡴࡵ࡭ࡪࡸ໊ࠢ"):fmkZtbRj3ux(u"ࠢࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ໋࡙ࠢ"),
		ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠣ࡫ࡳࠦ໌"): fmkZtbRj3ux(u"ࠤࠧࡶࡪࡳ࡯ࡵࡧࠥໍ"),
		s149dk8uh2p7oFzaLxZeI3Or(u"ࠥࠨࡸࡱࡩࡱࡡࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࡣࡸࡿ࡮ࡤࠤ໎"):Z19pUxa2gfGMNKoDsEuytn85SjFvA
	}
	DpE8HUAtIembL = []
	for Z7Qikucg083SpAzqwlDYKCyF in Yg3lURJL9mOZIBKoMsc15eqkN8Cjt:
		mmJANrSUfes5Rw8lyEpMY2HCg = Z8moybI7Rz96SvBltdFUGQEX3NWAjY.copy()
		mmJANrSUfes5Rw8lyEpMY2HCg[llkFwuCyhaP3sK76qO4T(u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ໏")] = Z7Qikucg083SpAzqwlDYKCyF
		mmJANrSUfes5Rw8lyEpMY2HCg[yRWQMHxZEz0(u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ໐")] = {jQv0du1iVxTgAXCM(u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ໑"):Z7Qikucg083SpAzqwlDYKCyF}
		mmJANrSUfes5Rw8lyEpMY2HCg[ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠧࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ໒")] = {it4DKnryZlx(u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ໓"):Z7Qikucg083SpAzqwlDYKCyF}
		DpE8HUAtIembL.append(mmJANrSUfes5Rw8lyEpMY2HCg)
	ZtoUCFcjmabu = {
		MFhbWia58mP3su0fk2d(u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ໔"):weh7SGmuTgXOVRcMo1rlLq(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ໕"),
		vvhR5ozeiJpANyl8fFO3GBw(u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ໖"):g5eBG9fzWs28NjMnV,
		jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ໗"): DpE8HUAtIembL
	}
	zQfGP7LOR8YrN04CwgaUvtpb9 = {VhqD3zp7mUieI8sMQlETH(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ໘"):jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ໙")}
	xLDEnp9WdA = DpRJnas65uVcO0S17dYG(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠸࠮ࡢ࡯ࡳࡰ࡮ࡺࡵࡥࡧ࠱ࡧࡴࡳ࠯࠳࠱࡫ࡸࡹࡶࡡࡱ࡫ࠪ໚")
	rTAHV8ktdmWCDfxP = wBxAjV0NKzMhD2daHCU8TLRbu6lirO(vWNRusF46D7Mi8GpZ(u"ࠩࡓࡓࡘ࡚ࠧ໛"),xLDEnp9WdA,ZtoUCFcjmabu,zQfGP7LOR8YrN04CwgaUvtpb9,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩໜ"))
	return rTAHV8ktdmWCDfxP
def G6pHMXiAZgLBj2FuNwfPWbK8n9soqt(lZ92cS0iDnGC3MRKu6xy):
	ycYFVNgPmEubl = jj0dZrgiKb.sub(fmkZtbRj3ux(u"ࡶࠬ࠮࡜ࡴࠫࠥࠬࡡࡽࠩࠨໝ"), w8JC1y7Lp3(u"ࡷ࠭࡜࠲࡞࡟ࠦࡡ࠸ࠧໞ"), lZ92cS0iDnGC3MRKu6xy)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(TNw1pBHb8CtSZe0EFxuJqI(u"ࡸࠧࠩ࡞ࡺ࠭ࠧ࠮࡜ࡴࠫࠪໟ"), lCT8hfYUBX4OQMmL(u"ࡲࠨ࡞࠴ࡠࡡࠨ࡜࠳ࠩ໠"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(A6Sg45ChDR3BJLYfFH(u"ࡳࠩࠫࡠࡼ࠯ࠢࠩ࡞ࡺ࠭ࠬ໡"), jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࡴࠪࡠ࠶ࡢ࡜ࠣ࡞࠵ࠫ໢"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(D2PpKMeZFWrmfxTSs4L1tz(u"ࡵࠫ࠭ࡢࡳࠪࠤࠫࡠࡸ࠯ࠧ໣"), vvhR5ozeiJpANyl8fFO3GBw(u"ࡶࠬࡢ࠱࡝࡞ࠥࡠ࠷࠭໤"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(llkFwuCyhaP3sK76qO4T(u"ࡷࠨࠨ࡝ࡵࠬࠫ࠭ࡢࡷࠪࠤ໥"), vWNRusF46D7Mi8GpZ(u"ࡸࠢ࡝࠳࡟ࡠࠬࡢ࠲ࠣ໦"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(Gj3rMP1Cb8wHdp49la0(u"ࡲࠣࠪ࡟ࡻ࠮࠭ࠨ࡝ࡵࠬࠦ໧"), VhqD3zp7mUieI8sMQlETH(u"ࡳࠤ࡟࠵ࡡࡢࠧ࡝࠴ࠥ໨"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(kPCxIUZb1V(u"ࡴࠥࠬࡡࡽࠩࠨࠪ࡟ࡻ࠮ࠨ໩"), xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࡵࠦࡡ࠷࡜࡝ࠩ࡟࠶ࠧ໪"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(MFhbWia58mP3su0fk2d(u"ࡶࠧ࠮࡜ࡴࠫࠪࠬࡡࡹࠩࠣ໫"), SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࡷࠨ࡜࠲࡞࡟ࠫࡡ࠸ࠢ໬"), ycYFVNgPmEubl)
	PuDp2frFyx0zUBbMnKcjW7q3a = xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࡸࠧ࡜࡞࡞ࡠࡢࢁࡽࠩࠫ࠽࠰ࡢ࠭໭")
	ycYFVNgPmEubl = jj0dZrgiKb.sub(lCT8hfYUBX4OQMmL(u"ࡲࠨࠪ࡟ࡻ࠮࠮ࠧ໮") + PuDp2frFyx0zUBbMnKcjW7q3a + weh7SGmuTgXOVRcMo1rlLq(u"ࡳࠩࠬࠬࡡࡽࠩࠨ໯"), A6Sg45ChDR3BJLYfFH(u"ࡴࠪࡠ࠶ࡢ࡜࡝࠴࡟࠷ࠬ໰"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(MFhbWia58mP3su0fk2d(u"ࡵࠫ࠭ࡢࡳࠪࠪࠪ໱") + PuDp2frFyx0zUBbMnKcjW7q3a + bQGafNLXyFgsZP6ut(u"ࡶࠬ࠯ࠨ࡝ࡹࠬࠫ໲"), kPCxIUZb1V(u"ࡷ࠭࡜࠲࡞࡟ࡠ࠷ࡢ࠳ࠨ໳"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(weh7SGmuTgXOVRcMo1rlLq(u"ࡸࠧࠩ࡞ࡺ࠭࠭࠭໴") + PuDp2frFyx0zUBbMnKcjW7q3a + rDG9dZoXRhCJcieUSF0KB(u"ࡲࠨࠫࠫࡠࡸ࠯ࠧ໵"), jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࡳࠩ࡟࠵ࡡࡢ࡜࠳࡞࠶ࠫ໶"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(lCT8hfYUBX4OQMmL(u"ࡴࠪࠬࡡࡹࠩࠩࠩ໷") + PuDp2frFyx0zUBbMnKcjW7q3a + ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࡵࠫ࠮࠮࡜ࡴࠫࠪ໸"), vvhR5ozeiJpANyl8fFO3GBw(u"ࡶࠬࡢ࠱࡝࡞࡟࠶ࡡ࠹ࠧ໹"), ycYFVNgPmEubl)
	ycYFVNgPmEubl = jj0dZrgiKb.sub(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࡷ࠭ࠨ࡝ࡹࠬࡠࡡ࠮࡜ࡸࠫࠪ໺"), TNw1pBHb8CtSZe0EFxuJqI(u"ࡸࠧ࡝࠳࡟ࡠࡡࡢ࡜࠳ࠩ໻"), ycYFVNgPmEubl)
	return ycYFVNgPmEubl
def dm7KA8MukvxF3iH9CW2ZNc(ZZDoCUyJ5B,gSsciUCFqN6KWGxBT2t):
	gSsciUCFqN6KWGxBT2t = gSsciUCFqN6KWGxBT2t.replace(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࡯ࡷ࡯ࡰࠬ໼"),JHMxIE4fs1mvQtKW7R(u"ࠨࡐࡲࡲࡪ࠭໽"))
	gSsciUCFqN6KWGxBT2t = gSsciUCFqN6KWGxBT2t.replace(kPCxIUZb1V(u"ࠩࡷࡶࡺ࡫ࠧ໾"),fmkZtbRj3ux(u"ࠪࡘࡷࡻࡥࠨ໿"))
	gSsciUCFqN6KWGxBT2t = gSsciUCFqN6KWGxBT2t.replace(jQv0du1iVxTgAXCM(u"ࠫ࡫ࡧ࡬ࡴࡧࠪༀ"),lCT8hfYUBX4OQMmL(u"ࠬࡌࡡ࡭ࡵࡨࠫ༁"))
	gSsciUCFqN6KWGxBT2t = gSsciUCFqN6KWGxBT2t.replace(MFhbWia58mP3su0fk2d(u"࠭࡜࠰ࠩ༂"),yRWQMHxZEz0(u"ࠧ࠰ࠩ༃"))
	gSsciUCFqN6KWGxBT2t = gSsciUCFqN6KWGxBT2t.replace(VhqD3zp7mUieI8sMQlETH(u"ࠨ࡞ࡵࠫ༄"),w8JC1y7Lp3(u"ࠩ࡟ࡠࡷ࠭༅")).replace(DpRJnas65uVcO0S17dYG(u"ࠪࡠࡳ࠭༆"),kPCxIUZb1V(u"ࠫࡡࡢ࡮ࠨ༇"))
	PsEdYO1Wgn4vVGDo0bclZmRkJN,EUZ4ob3BTng = [],[]
	import ast as DDvqSbRUtK
	try: PsEdYO1Wgn4vVGDo0bclZmRkJN = DDvqSbRUtK.literal_eval(gSsciUCFqN6KWGxBT2t)
	except:
		try:
			gSsciUCFqN6KWGxBT2t = G6pHMXiAZgLBj2FuNwfPWbK8n9soqt(gSsciUCFqN6KWGxBT2t)
			PsEdYO1Wgn4vVGDo0bclZmRkJN = DDvqSbRUtK.literal_eval(gSsciUCFqN6KWGxBT2t)
		except:
			items = jj0dZrgiKb.findall(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࡷ࠭࡜࡜࡝ࡡࡠࡢࡣࠪ࡝࡟ࡿࡠࢀࡡ࡞ࡾ࡟࠭ࡠࢂࢂ࡜ࠩ࡝ࡡ࠭ࡢ࠰࡜ࠪࡾ࡞ࡢ࠱ࡢ࡛࡝࡟ࡠ࠯ࠬ༈"),gSsciUCFqN6KWGxBT2t.strip(erqDsJmL3BQHuGtPkcf0X9(u"࡛࠭࡞ࠩ༉")))
			if items:
				for o4oW9wDcsrpHQS816yfIvg in items:
					try: PsEdYO1Wgn4vVGDo0bclZmRkJN.append(DDvqSbRUtK.literal_eval(o4oW9wDcsrpHQS816yfIvg))
					except: EUZ4ob3BTng.append(o4oW9wDcsrpHQS816yfIvg)
			else: PsEdYO1Wgn4vVGDo0bclZmRkJN = mGiac9zNRLT(ZZDoCUyJ5B)
	return PsEdYO1Wgn4vVGDo0bclZmRkJN
def FIkaBmyEdxSzew3():
	KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
	kdJDcbM5FWUAgBs = jj0dZrgiKb.findall(Gj3rMP1Cb8wHdp49la0(u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧ༊"),PPV92olpby3x06D,jj0dZrgiKb.DOTALL)
	if kdJDcbM5FWUAgBs: PPV92olpby3x06D = PPV92olpby3x06D.split(kdJDcbM5FWUAgBs[wTLFCOcM26fmYlW7U],UD4N8MjVTd)[UD4N8MjVTd]
	Rl9VtN3vWZ8u = L5jXH0fZ8TvsESR.strftime(D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨ་"),L5jXH0fZ8TvsESR.localtime(yoJ7t3WpjPkrCmTq))
	PPV92olpby3x06D = PPV92olpby3x06D+Rl9VtN3vWZ8u
	diW61AocrJSYtmTE8v4nUkH = KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ
	Ye2FIg9kj3d0QvM6y58KtERxuNV = {}
	try:
		if b7i1PgC8Z4e5BFoHNd9E2UVvfc.path.exists(C5VkX6NMYnT2A0PFL):
			YcemO0GJHBz = open(C5VkX6NMYnT2A0PFL,SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡵࡦࠬ༌")).read()
			if YcemO0GJHBz:
				if wwMdFkWvcRYiXHB7yDrCqnKb98o: YcemO0GJHBz = YcemO0GJHBz.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
				Ye2FIg9kj3d0QvM6y58KtERxuNV = dm7KA8MukvxF3iH9CW2ZNc(w8JC1y7Lp3(u"ࠪࡨ࡮ࡩࡴࠨ།"),YcemO0GJHBz)
		B24cf0uV1SMLNI6TwziZ = {}
		for qzy36LhCAowOBWvVsfl90e18Ta in Ye2FIg9kj3d0QvM6y58KtERxuNV:
			if qzy36LhCAowOBWvVsfl90e18Ta!=KUOoYcT20iCLVgsw1ejzdkHp7XW: B24cf0uV1SMLNI6TwziZ[qzy36LhCAowOBWvVsfl90e18Ta] = Ye2FIg9kj3d0QvM6y58KtERxuNV[qzy36LhCAowOBWvVsfl90e18Ta]
			else:
				if PPV92olpby3x06D and PPV92olpby3x06D!=bQGafNLXyFgsZP6ut(u"ࠫ࠳࠴ࠧ༎"):
					RzUcdAPosbJSWDxL = Ye2FIg9kj3d0QvM6y58KtERxuNV[qzy36LhCAowOBWvVsfl90e18Ta]
					if diW61AocrJSYtmTE8v4nUkH in RzUcdAPosbJSWDxL:
						Q1OIedulYvrCpsfG3gLTbj6ci = RzUcdAPosbJSWDxL.index(diW61AocrJSYtmTE8v4nUkH)
						del RzUcdAPosbJSWDxL[Q1OIedulYvrCpsfG3gLTbj6ci]
					KCN5dJHLyWQ7vpc1btgsEwfYi2e = [diW61AocrJSYtmTE8v4nUkH]+RzUcdAPosbJSWDxL
					KCN5dJHLyWQ7vpc1btgsEwfYi2e = KCN5dJHLyWQ7vpc1btgsEwfYi2e[:vWNRusF46D7Mi8GpZ(u"࠹࠵၉")]
					B24cf0uV1SMLNI6TwziZ[qzy36LhCAowOBWvVsfl90e18Ta] = KCN5dJHLyWQ7vpc1btgsEwfYi2e
				else: B24cf0uV1SMLNI6TwziZ[qzy36LhCAowOBWvVsfl90e18Ta] = Ye2FIg9kj3d0QvM6y58KtERxuNV[qzy36LhCAowOBWvVsfl90e18Ta]
		if KUOoYcT20iCLVgsw1ejzdkHp7XW not in list(B24cf0uV1SMLNI6TwziZ.keys()): B24cf0uV1SMLNI6TwziZ[KUOoYcT20iCLVgsw1ejzdkHp7XW] = [diW61AocrJSYtmTE8v4nUkH]
		B24cf0uV1SMLNI6TwziZ = str(B24cf0uV1SMLNI6TwziZ)
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: B24cf0uV1SMLNI6TwziZ = B24cf0uV1SMLNI6TwziZ.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
		open(C5VkX6NMYnT2A0PFL,xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠬࡽࡢࠨ༏")).write(B24cf0uV1SMLNI6TwziZ)
	except:
		import XXRNnfOH3e,tdeCZlJnBw
		XXRNnfOH3e.IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,lCT8hfYUBX4OQMmL(u"࠭ๅีๅ็อࠬ༐"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧศๆหี๋อๅอ๋ࠢะิࠦๅีๅ็อࠥ฿ๆะๅࠣๅ๏ࠦๅๅใࠣฦำืࠠศๆไ๎ิ๐่่ษอࠤ࠳࠴ࠠษ฻าࠤ์ึ็ࠡษ็ีุอไสࠢึ์ๆࠦสู้ิࠤ้้ࠠาีส่ฮࠦรฯำ์ࠤํ็๊่ษࠣฮุะื๋฻ࠣว๋ࠦสฮๆ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰࠱ࠤา๐หࠡ์ฯฬࠥษๆࠡฬัฮฬืࠠฦ็สࠤส฻ไศฯࠣห้๋ไโࠢฦ์๋ࠥำฮ้ࠣฮ๊อๅศࠩ༑"))
		tdeCZlJnBw.AUXqorfzD4HmJ9KdwZYBks2hyxv0et(C5VkX6NMYnT2A0PFL)
	return
def rqPJzRuUF2L(ZtoUCFcjmabu):
	if wwMdFkWvcRYiXHB7yDrCqnKb98o: import urllib.parse as vqN9Y4hc5R1ywZz30FTM
	else: import urllib as vqN9Y4hc5R1ywZz30FTM
	RkSCUQeoAzBrhEcpKmtPMY7 = vqN9Y4hc5R1ywZz30FTM.urlencode(ZtoUCFcjmabu)
	return RkSCUQeoAzBrhEcpKmtPMY7
def yyYuosJmc3QDUGSA(qaLFXuDExl8w,V83w0qv5UYT6peJjKbkL=wUvcPrYDfISbZolAm83GKEqMyXkn5,BDQKR3CShFoAnN4Uq62fL5v9dws=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	Ms9CdjXazVKHvy6 = V83w0qv5UYT6peJjKbkL not in [A6Sg45ChDR3BJLYfFH(u"ࠨࡏ࠶࡙ࠬ༒"),JHMxIE4fs1mvQtKW7R(u"ࠩࡌࡔ࡙࡜ࠧ༓")]
	if not BDQKR3CShFoAnN4Uq62fL5v9dws: BDQKR3CShFoAnN4Uq62fL5v9dws = MFhbWia58mP3su0fk2d(u"ࠪࡺ࡮ࡪࡥࡰࠩ༔")
	VLhKBFOXMf3yk19zPZHugW,ean4QcrRXDl5xg = lCT8hfYUBX4OQMmL(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭༕"),wUvcPrYDfISbZolAm83GKEqMyXkn5
	if len(qaLFXuDExl8w)==MMRBkhnWVJCQwU:
		xLDEnp9WdA,wDChTMKORz8eY5o34kptPJZgc,xoID8Nw0G9X = qaLFXuDExl8w
		if wDChTMKORz8eY5o34kptPJZgc: ean4QcrRXDl5xg = w8JC1y7Lp3(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ༖")+wDChTMKORz8eY5o34kptPJZgc+ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࠠ࡞ࠩ༗")
	else: xLDEnp9WdA,wDChTMKORz8eY5o34kptPJZgc,xoID8Nw0G9X = qaLFXuDExl8w,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	xLDEnp9WdA = xLDEnp9WdA.replace(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠧࠦ࠴࠳༘ࠫ"),UKFZBQAVXHI5s17LyvuRpCY2)
	cUCwLQ3jTsKrNOyR1 = rjZFa0VMBuPRHg1cIYJpd52oxl4(xLDEnp9WdA)
	xLK3kz2aD5 = QEbx35yvreoT2sPDG4k9Fcfa8Z(xLDEnp9WdA)
	if V83w0qv5UYT6peJjKbkL not in [D2PpKMeZFWrmfxTSs4L1tz(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ༙ࠪ"),yRWQMHxZEz0(u"ࠩࡌࡔ࡙࡜ࠧ༚")]:
		if V83w0qv5UYT6peJjKbkL!=yRWQMHxZEz0(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ༛"): xLDEnp9WdA = xLDEnp9WdA.replace(UKFZBQAVXHI5s17LyvuRpCY2,gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࠪ࠸࠰ࠨ༜"))
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࠦࠠࠡࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡱ࡮ࡤࡽ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ༝")+xLK3kz2aD5+xdSThjYnuHXAU6M(u"࠭ࠠ࡞ࠩ༞")+ean4QcrRXDl5xg)
		if cUCwLQ3jTsKrNOyR1==jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠧ࠯࡯࠶ࡹ࠽࠭༟") and V83w0qv5UYT6peJjKbkL not in [rDG9dZoXRhCJcieUSF0KB(u"ࠨࡋࡓࡘ࡛࠭༠"),A6Sg45ChDR3BJLYfFH(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ༡")]:
			import zpCIRgy3H2,XXRNnfOH3e
			Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = zpCIRgy3H2.kjJQbScq69aO4Ko(V83w0qv5UYT6peJjKbkL,xLDEnp9WdA)
			ygOUXKL0h28HawR = len(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL)
			if ygOUXKL0h28HawR>UD4N8MjVTd:
				EcQws7L35GvtIpl0k1gJZWTNPDbmMq = XXRNnfOH3e.ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj(vWNRusF46D7Mi8GpZ(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ༢")+str(ygOUXKL0h28HawR)+gVpGcN7nxEWLri4DvyAZlU3BQM(u"๋ࠫࠥไโࠫࠪ༣"), Eu8LWnSt3fyJzIC)
				if EcQws7L35GvtIpl0k1gJZWTNPDbmMq==-UD4N8MjVTd:
					XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬหไ฻ษฤࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ༤"),it4DKnryZlx(u"࠭ࡃࡢࡰࡦࡩࡱ࠭༥"))
					return VLhKBFOXMf3yk19zPZHugW
			else: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = wTLFCOcM26fmYlW7U
			xLDEnp9WdA = j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
			if Eu8LWnSt3fyJzIC[wTLFCOcM26fmYlW7U]!=fmkZtbRj3ux(u"ࠧ࠮࠳ࠪ༦"):
				KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+TNw1pBHb8CtSZe0EFxuJqI(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡲࡥࡤࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡩࡰࡰ࠽ࠤࡠࠦࠧ༧")+Eu8LWnSt3fyJzIC[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ༨")+xLK3kz2aD5+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠪࠤࡢ࠭༩"))
		if VhqD3zp7mUieI8sMQlETH(u"ࠫ࠴࡯ࡦࡪ࡮ࡰ࠳ࠬ༪") in xLDEnp9WdA: xLDEnp9WdA = xLDEnp9WdA+yRWQMHxZEz0(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ༫")
		elif MFhbWia58mP3su0fk2d(u"࠭ࡨࡵࡶࡳࠫ༬") in xLDEnp9WdA.lower() and yRWQMHxZEz0(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ༭") not in xLDEnp9WdA and w8JC1y7Lp3(u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫ༮") not in xLDEnp9WdA:
			xLDEnp9WdA = xLDEnp9WdA+bQGafNLXyFgsZP6ut(u"ࠩࡿࠫ༯") if xm6jK1ZMuWq5(u"ࠪࢀࠬ༰") not in xLDEnp9WdA else xLDEnp9WdA+vWNRusF46D7Mi8GpZ(u"ࠫࠫ࠭༱")
			if bQGafNLXyFgsZP6ut(u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ༲") not in xLDEnp9WdA and erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ༳") in xLDEnp9WdA.lower(): xLDEnp9WdA += MFhbWia58mP3su0fk2d(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠩࠫ༴")
			if vWNRusF46D7Mi8GpZ(u"ࠨࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࡂ༵࠭") not in xLDEnp9WdA.lower() and V83w0qv5UYT6peJjKbkL not in [ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡌࡔ࡙࡜ࠧ༶"),fmkZtbRj3ux(u"ࠪࡑ࠸࡛༷ࠧ")]: xLDEnp9WdA += dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ༸")
			if rDG9dZoXRhCJcieUSF0KB(u"ࠬࡸࡥࡧࡧࡵࡩࡷࡃ༹ࠧ") not in xLDEnp9WdA.lower(): xLDEnp9WdA += dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࡩࡶࡷࡴࠫ࠭༺")
			if lCT8hfYUBX4OQMmL(u"ࠧࡢࡥࡦࡩࡵࡺ࠭࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠿ࠪ༻") not in xLDEnp9WdA.lower(): xLDEnp9WdA += bQGafNLXyFgsZP6ut(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࡀࡩࡳ࠲ࡡࡳ࠽ࡴࡁ࠵࠴࠹ࠧࠩ༼")
	KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+vWNRusF46D7Mi8GpZ(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡩ࡭ࡳࡧ࡬ࠡࡷࡵࡰࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ༽")+xLK3kz2aD5+DpRJnas65uVcO0S17dYG(u"ࠪࠤࡢ࠭༾"))
	if erqDsJmL3BQHuGtPkcf0X9(u"ࠫࢁ࠭༿") in xLDEnp9WdA: gFLS85qhU4besnJjB,iicI4YvAKpkhgLbMCQzJx = xLDEnp9WdA.split(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠬࢂࠧཀ"))
	else: gFLS85qhU4besnJjB,iicI4YvAKpkhgLbMCQzJx = xLDEnp9WdA,wUvcPrYDfISbZolAm83GKEqMyXkn5
	if xoID8Nw0G9X: FFwVakdM8NvjeJRK3oyQI9ti24, nehcBg4qAl9mGNPZ2MbW7dr5 = iHtxL9eylq(vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨཁ")+cUCwLQ3jTsKrNOyR1,xoID8Nw0G9X,pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠶࠶၊"))
	else: FFwVakdM8NvjeJRK3oyQI9ti24, nehcBg4qAl9mGNPZ2MbW7dr5 = iHtxL9eylq(TNw1pBHb8CtSZe0EFxuJqI(u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩག")+cUCwLQ3jTsKrNOyR1,gFLS85qhU4besnJjB,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"࠷࠰။"))
	xLDEnp9WdA = nehcBg4qAl9mGNPZ2MbW7dr5+pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡾࠪགྷ")+iicI4YvAKpkhgLbMCQzJx
	WGknbPtVgXI6wvAj = llfAzdjaVLTbyZW7op9i.ListItem(path=xLDEnp9WdA)
	BDQKR3CShFoAnN4Uq62fL5v9dws,ecRjk36mZK4gPIXrBqp,jawMl1HJN2kZh98B5LPC3nsFxviz,IItNC5sHDnydEgq2YrRu,h4GBW96Iwnra8OopcJKtbA,AdEraLtUnxc5T3z8ej0Rp1JXv9B,mM6SdsnRhy0A1YlxieWgVpEzXGo,zRnumoW1HcMDsYN8r3G9eaU,GhT6YkowuIQrsitES7c2JKyNbn1A = iH5WqdVauhO(XhGSxvjRAZdU7rEt9JMweQC)
	if V83w0qv5UYT6peJjKbkL not in [A6Sg45ChDR3BJLYfFH(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫང"),vWNRusF46D7Mi8GpZ(u"ࠪࡍࡕ࡚ࡖࠨཅ")]:
		CCbL6KpPM1SQaZuOm = TNw1pBHb8CtSZe0EFxuJqI(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧཆ") if ndib93Ol6UojCrEV else it4DKnryZlx(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࠪཇ")
		WGknbPtVgXI6wvAj.setProperty(CCbL6KpPM1SQaZuOm, wUvcPrYDfISbZolAm83GKEqMyXkn5)
		WGknbPtVgXI6wvAj.setMimeType(JHMxIE4fs1mvQtKW7R(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ཈"))
		if Uy6GWujQiBLhodP<SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠲࠱၌"): WGknbPtVgXI6wvAj.setInfo(xm6jK1ZMuWq5(u"ࠧࡷ࡫ࡧࡩࡴ࠭ཉ"),{fmkZtbRj3ux(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫཊ"):rDG9dZoXRhCJcieUSF0KB(u"ࠩࡰࡳࡻ࡯ࡥࠨཋ")})
		else:
			oVOG4eR9Bx7F0lzSwHP1ycWijT5fv = WGknbPtVgXI6wvAj.getVideoInfoTag()
			oVOG4eR9Bx7F0lzSwHP1ycWijT5fv.setMediaType(fmkZtbRj3ux(u"ࠪࡱࡴࡼࡩࡦࠩཌ"))
		WGknbPtVgXI6wvAj.setArt({bQGafNLXyFgsZP6ut(u"ࠫࡹ࡮ࡵ࡮ࡤࠪཌྷ"):h4GBW96Iwnra8OopcJKtbA,rDG9dZoXRhCJcieUSF0KB(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬཎ"):h4GBW96Iwnra8OopcJKtbA,gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠭ࡢࡢࡰࡱࡩࡷ࠭ཏ"):h4GBW96Iwnra8OopcJKtbA,lCT8hfYUBX4OQMmL(u"ࠧࡧࡣࡱࡥࡷࡺࠧཐ"):h4GBW96Iwnra8OopcJKtbA,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪད"):h4GBW96Iwnra8OopcJKtbA,TNw1pBHb8CtSZe0EFxuJqI(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬདྷ"):h4GBW96Iwnra8OopcJKtbA,TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ན"):h4GBW96Iwnra8OopcJKtbA,weh7SGmuTgXOVRcMo1rlLq(u"ࠫ࡮ࡩ࡯࡯ࠩཔ"):h4GBW96Iwnra8OopcJKtbA})
		if cUCwLQ3jTsKrNOyR1 in [SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ࠴࡭ࡱࡦࠪཕ"),yRWQMHxZEz0(u"࠭࠮࡮࠵ࡸ࠼ࠬབ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࠯࡯࠶ࡹࠬབྷ")]:
			WGknbPtVgXI6wvAj.setContentLookup(y0yvdNOZkiKEg5RLMhoDVQAB9F2)
		else: WGknbPtVgXI6wvAj.setContentLookup(Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		from tdeCZlJnBw import rrI7hTwM9qCzBF2kgHjSVRNE
		if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࡴࡷࡱࡵ࠭མ") in xLDEnp9WdA:
			rrI7hTwM9qCzBF2kgHjSVRNE(erqDsJmL3BQHuGtPkcf0X9(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬཙ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
		elif cUCwLQ3jTsKrNOyR1==llkFwuCyhaP3sK76qO4T(u"ࠪ࠲ࡲࡶࡤࠨཚ") or vvhR5ozeiJpANyl8fFO3GBw(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫཛ") in xLDEnp9WdA:
			rrI7hTwM9qCzBF2kgHjSVRNE(vWNRusF46D7Mi8GpZ(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬཛྷ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
			WGknbPtVgXI6wvAj.setProperty(CCbL6KpPM1SQaZuOm,vvhR5ozeiJpANyl8fFO3GBw(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ཝ"))
			WGknbPtVgXI6wvAj.setProperty(D2PpKMeZFWrmfxTSs4L1tz(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫࠮࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡷࡽࡵ࡫ࠧཞ"),yRWQMHxZEz0(u"ࠨ࡯ࡳࡨࠬཟ"))
		if wDChTMKORz8eY5o34kptPJZgc:
			WGknbPtVgXI6wvAj.setSubtitles([wDChTMKORz8eY5o34kptPJZgc])
	if BDQKR3CShFoAnN4Uq62fL5v9dws==xm6jK1ZMuWq5(u"ࠩࡹ࡭ࡩ࡫࡯ࠨའ") and V83w0qv5UYT6peJjKbkL==erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬཡ"):
		VLhKBFOXMf3yk19zPZHugW = lCT8hfYUBX4OQMmL(u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫར")
		V83w0qv5UYT6peJjKbkL = fmkZtbRj3ux(u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬལ")
	elif BDQKR3CShFoAnN4Uq62fL5v9dws==weh7SGmuTgXOVRcMo1rlLq(u"࠭ࡶࡪࡦࡨࡳࠬཤ") and zRnumoW1HcMDsYN8r3G9eaU.startswith(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧ࠷ࠩཥ")):
		VLhKBFOXMf3yk19zPZHugW = SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ས")
		V83w0qv5UYT6peJjKbkL = V83w0qv5UYT6peJjKbkL+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡢࡈࡑ࠭ཧ")
	if VLhKBFOXMf3yk19zPZHugW!=vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨཨ"): FIkaBmyEdxSzew3()
	lOLcNuSPX5D.GH2wZiLUJK7AuzVfEbngQsD9CTMv(V83w0qv5UYT6peJjKbkL)
	if lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt: return it4DKnryZlx(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬཀྵ")
	FFwVakdM8NvjeJRK3oyQI9ti24.start()
	if BDQKR3CShFoAnN4Uq62fL5v9dws==vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡼࡩࡥࡧࡲࠫཪ") and not zRnumoW1HcMDsYN8r3G9eaU.startswith(yRWQMHxZEz0(u"࠭࠶ࠨཫ")):
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+gVpGcN7nxEWLri4DvyAZlU3BQM(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧཬ")+xLK3kz2aD5+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࠢࡠࠫ཭"))
		qsrzODKdEYyo.setResolvedUrl(pe9KNyUQmRTj,y0yvdNOZkiKEg5RLMhoDVQAB9F2,WGknbPtVgXI6wvAj)
	elif BDQKR3CShFoAnN4Uq62fL5v9dws==bQGafNLXyFgsZP6ut(u"ࠩ࡯࡭ࡻ࡫ࠧ཮"):
		KnPs7aEmR0SGBf2o5wd(zWVDcOSsdJMU,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+Gj3rMP1Cb8wHdp49la0(u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭཯")+xLK3kz2aD5+D2PpKMeZFWrmfxTSs4L1tz(u"ࠫࠥࡣࠧ཰"))
		lOLcNuSPX5D.play(xLDEnp9WdA,WGknbPtVgXI6wvAj)
	n453i9Fwpc6bGMuUa2l = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if VLhKBFOXMf3yk19zPZHugW==vvhR5ozeiJpANyl8fFO3GBw(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩཱࠪ"):
		from wnLHmvyuPp import svhR97HQm3
		n453i9Fwpc6bGMuUa2l = svhR97HQm3(xLDEnp9WdA,cUCwLQ3jTsKrNOyR1,V83w0qv5UYT6peJjKbkL)
		if n453i9Fwpc6bGMuUa2l: FIkaBmyEdxSzew3()
	else:
		CCOaZv7IcwLueUDFi9pWNBEylr5,VLhKBFOXMf3yk19zPZHugW,RRF2BmcAg3jP1qSohl4ZCQd,m3tf6XhJyGFAzT0lIEeKW95LU4DO,JxGL3XloUAK4NdOhVr0 = wTLFCOcM26fmYlW7U,xm6jK1ZMuWq5(u"࠭ࡴࡳ࡫ࡨࡨིࠬ"),Z19pUxa2gfGMNKoDsEuytn85SjFvA,D2PpKMeZFWrmfxTSs4L1tz(u"࠳࠳࠴࠵၎"),DpRJnas65uVcO0S17dYG(u"࠵࠷࠳࠴࠵၍")
		if Ms9CdjXazVKHvy6: import XXRNnfOH3e
		while CCOaZv7IcwLueUDFi9pWNBEylr5<JxGL3XloUAK4NdOhVr0:
			te28VJiPB7RXcm6brMUQyKAC3Z.sleep(m3tf6XhJyGFAzT0lIEeKW95LU4DO)
			CCOaZv7IcwLueUDFi9pWNBEylr5 += m3tf6XhJyGFAzT0lIEeKW95LU4DO
			if lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt==xm6jK1ZMuWq5(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨཱི") and not RRF2BmcAg3jP1qSohl4ZCQd:
				if Ms9CdjXazVKHvy6: XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(lCT8hfYUBX4OQMmL(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊อษาࠤฬ๊แ๋ัํ์ུࠬ"),VhqD3zp7mUieI8sMQlETH(u"ࠩࡖࡹࡨࡩࡥࡴࡵཱུࠪ"),L5jXH0fZ8TvsESR=gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠺࠹࠵၏"))
				KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+kPCxIUZb1V(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧྲྀ")+xLK3kz2aD5+lCT8hfYUBX4OQMmL(u"ࠫࠥࡣࠧཷ")+ean4QcrRXDl5xg)
				RRF2BmcAg3jP1qSohl4ZCQd = y0yvdNOZkiKEg5RLMhoDVQAB9F2
			elif lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt in [xdSThjYnuHXAU6M(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭ླྀ"),JHMxIE4fs1mvQtKW7R(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧཹ")]:
				KnPs7aEmR0SGBf2o5wd(SjUOalsknhyeYqI6Tf,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+weh7SGmuTgXOVRcMo1rlLq(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ེࠣࠫ")+xLK3kz2aD5+jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠨࠢࡠཻࠫ")+ean4QcrRXDl5xg)
				break
			elif lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt==ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡩࡥ࡮ࡲࡥࡥོࠩ"):
				KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+rDG9dZoXRhCJcieUSF0KB(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡰ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ཽࠣࠫ")+xLK3kz2aD5+ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠫࠥࡣࠧཾ")+ean4QcrRXDl5xg)
				if Ms9CdjXazVKHvy6: XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩཿ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ྀࠧ"),L5jXH0fZ8TvsESR=ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠻࠺࠶ၐ"))
				break
			elif lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt==vvhR5ozeiJpANyl8fFO3GBw(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨཱྀ"):
				KnPs7aEmR0SGBf2o5wd(GZR3XQMO5J4N7tqEkSwFr6l9L1eb,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠨࠢࠣࠤࡉ࡫ࡶࡪࡥࡨࠤ࡮ࡹࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ྂ")+xLK3kz2aD5+A6Sg45ChDR3BJLYfFH(u"ࠩࠣࡡࠬྃ"))
				break
		else: VLhKBFOXMf3yk19zPZHugW = s149dk8uh2p7oFzaLxZeI3Or(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷ྄ࠫ")
	if VLhKBFOXMf3yk19zPZHugW in [JHMxIE4fs1mvQtKW7R(u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ྅")] or lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt in [s149dk8uh2p7oFzaLxZeI3Or(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭྆"),fmkZtbRj3ux(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ྇")] or n453i9Fwpc6bGMuUa2l: SwkKZ8pMra5VFs9zbOnf2Gli0YI(V83w0qv5UYT6peJjKbkL)
	else: exec(yRWQMHxZEz0(u"ࠧࡪ࡯ࡳࡳࡷࡺࠠࡹࡤࡰࡧࡀࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬྈ"))
	FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying()
	if not FBe2GQ7zwUmOia and VLhKBFOXMf3yk19zPZHugW not in [ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ྉ")]:
		msg = jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪྊ") if VLhKBFOXMf3yk19zPZHugW==VhqD3zp7mUieI8sMQlETH(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫྋ") else JHMxIE4fs1mvQtKW7R(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬྌ")
		if Ms9CdjXazVKHvy6: XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(kPCxIUZb1V(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩྍ"),msg,L5jXH0fZ8TvsESR=D2PpKMeZFWrmfxTSs4L1tz(u"࠼࠻࠰ၑ"))
		KnPs7aEmR0SGBf2o5wd(WW0AeIrS1dQyvqlnTzO8kaYFc,Qj2AKxXf6C9EwGJSMH3c1Fkp(UdbRGoKhcDeI4lVfns5)+rDG9dZoXRhCJcieUSF0KB(u"࠭ࠠࠡࠢࠪྎ")+msg+gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠧ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪྏ")+xLK3kz2aD5+xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࠢࡠࠫྐ")+ean4QcrRXDl5xg)
	return lOLcNuSPX5D.TZwiXMoENgajSu5PqQ48FW7kt
def rjZFa0VMBuPRHg1cIYJpd52oxl4(xLDEnp9WdA):
	if xm6jK1ZMuWq5(u"ࠩࡂࠫྑ") in xLDEnp9WdA: xLDEnp9WdA = xLDEnp9WdA.split(MFhbWia58mP3su0fk2d(u"ࠪࡃࠬྒ"))[wTLFCOcM26fmYlW7U]
	if VhqD3zp7mUieI8sMQlETH(u"ࠫࢁ࠭ྒྷ") in xLDEnp9WdA: xLDEnp9WdA = xLDEnp9WdA.split(fmkZtbRj3ux(u"ࠬࢂࠧྔ"))[wTLFCOcM26fmYlW7U]
	path = llkFwuCyhaP3sK76qO4T(u"࠭࠯ࠨྕ").join(xLDEnp9WdA.split(llkFwuCyhaP3sK76qO4T(u"ࠧ࠰ࠩྖ"))[Gj3rMP1Cb8wHdp49la0(u"࠹ၒ"):]) if it4DKnryZlx(u"ࠨ࠼࠲࠳ࠬྗ") in xLDEnp9WdA else xLDEnp9WdA
	jba6zThWuQScxdsZImMlL = jj0dZrgiKb.findall(D2PpKMeZFWrmfxTSs4L1tz(u"ࠩ࡟࠲࠭ࡡࡡ࠮ࡼ࠳࠱࠾ࡣࡻ࠳࠮࠷ࢁ࠮࠭྘"),path,jj0dZrgiKb.DOTALL)
	if jba6zThWuQScxdsZImMlL:
		jba6zThWuQScxdsZImMlL = jba6zThWuQScxdsZImMlL[-UD4N8MjVTd]
		vqFeByaIxZC = [VhqD3zp7mUieI8sMQlETH(u"ࠪࡱ࠸ࡻ࠸ࠨྙ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡲࡶ࠴ࠨྚ"),jQv0du1iVxTgAXCM(u"ࠬࡳࡰࡥࠩྛ"),ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡷࡦࡤࡰࠫྜ"),yRWQMHxZEz0(u"ࠧࡢࡸ࡬ࠫྜྷ"),MFhbWia58mP3su0fk2d(u"ࠨࡣࡤࡧࠬྞ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠩࡰ࠷ࡺ࠭ྟ"),TNw1pBHb8CtSZe0EFxuJqI(u"ࠪࡱࡰࡼࠧྠ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠫ࡫ࡲࡶࠨྡ"),JHMxIE4fs1mvQtKW7R(u"ࠬࡳࡰ࠴ࠩྡྷ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"࠭ࡴࡴࠩྣ")]
		if jba6zThWuQScxdsZImMlL in vqFeByaIxZC: return weh7SGmuTgXOVRcMo1rlLq(u"ࠧ࠯ࠩྤ")+jba6zThWuQScxdsZImMlL
	return wUvcPrYDfISbZolAm83GKEqMyXkn5
def SwkKZ8pMra5VFs9zbOnf2Gli0YI(mmJANrSUfes5Rw8lyEpMY2HCg):
	if not TTuO14NzmB.W1haXcb7tVZ6K: mmJANrSUfes5Rw8lyEpMY2HCg += dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠨࡡࡗࡗࠬྥ")
	TTuO14NzmB.SEND_THESE_EVENTS.append(mmJANrSUfes5Rw8lyEpMY2HCg)
	return
def sKv7WVYzUI(lfYsBbqzSkgn08T=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
	QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩྦ"))
	uOtmC6RAsjxNoyUvDh1TrJVQ(lfYsBbqzSkgn08T,lCT8hfYUBX4OQMmL(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ྦྷ"),y0yvdNOZkiKEg5RLMhoDVQAB9F2)
	Sph0cr2ZWK1atAUw5CTuxoe.exit()
def uOtmC6RAsjxNoyUvDh1TrJVQ(lfYsBbqzSkgn08T,av1f8x5yZ9rAsq,jjXDpagEkxQqWBVtwh9Fu1Gmb):
	if av1f8x5yZ9rAsq:
		if gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧྨ") in av1f8x5yZ9rAsq: KnPs7aEmR0SGBf2o5wd(wUvcPrYDfISbZolAm83GKEqMyXkn5,xm6jK1ZMuWq5(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨྩ"))
		else:
			P3yugDKECHbG6p7Wnvq1SU = OOnvcPQy85HYA.getSetting(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧྪ"))
			OOnvcPQy85HYA.setSetting(JHMxIE4fs1mvQtKW7R(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨྫ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
			import zpCIRgy3H2
			zpCIRgy3H2.XWcklrdEuQozqtaK1(av1f8x5yZ9rAsq)
			OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩྫྷ"),P3yugDKECHbG6p7Wnvq1SU)
	vvbRDXmZEyYa = OOnvcPQy85HYA.getSetting(it4DKnryZlx(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ྭ"))
	if vvbRDXmZEyYa==erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡣࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫྮ"): OOnvcPQy85HYA.setSetting(xdSThjYnuHXAU6M(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨྯ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬྰ"))
	elif vvbRDXmZEyYa==ZiCLpR1Tc5vUlPXDWgmhM6j(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ྱ"): OOnvcPQy85HYA.setSetting(MFhbWia58mP3su0fk2d(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫྲ"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
	if OOnvcPQy85HYA.getSetting(s149dk8uh2p7oFzaLxZeI3Or(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫླ")) not in [ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠩࡄ࡙࡙ࡕࠧྴ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡗ࡙ࡕࡐࠨྵ"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠫࡆ࡙ࡋࠨྶ")]: OOnvcPQy85HYA.setSetting(SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨྷ"),fmkZtbRj3ux(u"࠭ࡁࡔࡍࠪྸ"))
	if OOnvcPQy85HYA.getSetting(dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬྐྵ")) not in [kPCxIUZb1V(u"ࠨࡃࡘࡘࡔ࠭ྺ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠩࡖࡘࡔࡖࠧྻ"),DpRJnas65uVcO0S17dYG(u"ࠪࡅࡘࡑࠧྼ")]: OOnvcPQy85HYA.setSetting(erqDsJmL3BQHuGtPkcf0X9(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ྽"),gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠬࡇࡓࡌࠩ྾"))
	kHOncagIz8AB23MlF0 = OOnvcPQy85HYA.getSetting(VhqD3zp7mUieI8sMQlETH(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ྿"))
	Q0lCeRfj3P4BcbELFqhVaw7Ns = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(it4DKnryZlx(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ࿀"))
	if fmkZtbRj3ux(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ࿁") in str(Q0lCeRfj3P4BcbELFqhVaw7Ns) and kHOncagIz8AB23MlF0 in [xm6jK1ZMuWq5(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ࿂"),xdSThjYnuHXAU6M(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ࿃")]:
		L5jXH0fZ8TvsESR.sleep(llkFwuCyhaP3sK76qO4T(u"࠰࠯࠳࠳࠴ၓ"))
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(rDG9dZoXRhCJcieUSF0KB(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨ࿄"))
	if wTLFCOcM26fmYlW7U and pe9KNyUQmRTj>-UD4N8MjVTd:
		qsrzODKdEYyo.setResolvedUrl(pe9KNyUQmRTj,Z19pUxa2gfGMNKoDsEuytn85SjFvA,llfAzdjaVLTbyZW7op9i.ListItem())
		n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a = Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA,Z19pUxa2gfGMNKoDsEuytn85SjFvA
		qsrzODKdEYyo.endOfDirectory(pe9KNyUQmRTj,n453i9Fwpc6bGMuUa2l,VtnP3SszwLg9KuIm,YY6qeIV1xczTkJ9L5B7a)
	if TTuO14NzmB.SEND_THESE_EVENTS: XTweElMAbf4dmqakGRPWY0Z(TTuO14NzmB.SEND_THESE_EVENTS)
	Ak2OpncrYXboPaUlS3 = TTpQfNshcSo()
	ICwWPArNgl5tj38ZSYdX(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡹࡴࡰࡲࠪ࿅"),jjXDpagEkxQqWBVtwh9Fu1Gmb)
	if Ak2OpncrYXboPaUlS3 and not TTuO14NzmB.resolveonly:
		TTuO14NzmB.resolveonly = y0yvdNOZkiKEg5RLMhoDVQAB9F2
		FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying()
		if not FBe2GQ7zwUmOia: QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(w8JC1y7Lp3(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࿆࠭"))
		else:
			m5IZKtrvc3j = ggY6aiDlfmUxkCG()
			if m5IZKtrvc3j:
				import zpCIRgy3H2,XXRNnfOH3e
				for aJQuONIydj in range(wTLFCOcM26fmYlW7U,AxrKk7902DsRe4Vv3fWdwOYI,MMRBkhnWVJCQwU):
					L5jXH0fZ8TvsESR.sleep(MMRBkhnWVJCQwU)
					FBe2GQ7zwUmOia = te28VJiPB7RXcm6brMUQyKAC3Z.Player().isPlaying()
					if not FBe2GQ7zwUmOia:
						XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(erqDsJmL3BQHuGtPkcf0X9(u"ࠧศๆไ๎ิ๐่ࠡษ็่ฬำโࠨ࿇"),s149dk8uh2p7oFzaLxZeI3Or(u"ࠨว็฾ฬวࠠโฯุࠤฬ๊ำ๋ำไีฬะࠧ࿈"),L5jXH0fZ8TvsESR=jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"࠶࠲࠳ၔ"))
						break
				else:
					KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ = iH5WqdVauhO(m5IZKtrvc3j)
					if not any(value in PPV92olpby3x06D for value in zpCIRgy3H2.NOT_TO_TEST_ALL_SERVERS):
						XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(yRWQMHxZEz0(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪ࿉"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨ࿊"),L5jXH0fZ8TvsESR=w8JC1y7Lp3(u"࠹࠸࠴ၕ"))
						L5jXH0fZ8TvsESR.sleep(Tb7oymMnpflsSv3eu4Pz2)
						zpCIRgy3H2.vk2AWPdaQpzxMuht3ZNqfienVRwL7(uxig7mJanAYQ20,uxig7mJanAYQ20,uxig7mJanAYQ20)
						RCmHBOKtejQ8lu4L = zpCIRgy3H2.DQ2dIilnTb4BVuMzgh(KUOoYcT20iCLVgsw1ejzdkHp7XW,PPV92olpby3x06D,xLDEnp9WdA,XmaCeTontNPjwDBzyJIkKA9rRSHfb,mnWZN7g50M,sbNukjOf4chz,UWErGF2TqoQ,QFOD4Gei1zaImpk02q6vBNL3jwctbr,V9NmnGv2o0ZU5P8F4iqgX7CQJ)
						zpCIRgy3H2.vk2AWPdaQpzxMuht3ZNqfienVRwL7(cc2JaqoYp8m,cc2JaqoYp8m,cc2JaqoYp8m)
						XXRNnfOH3e.hg79cQmoVfMCukiU8ERpT6JqywSrN3(xm6jK1ZMuWq5(u"ࠫฬ๊แ๋ัํ์ࠥอไๅษะๆࠬ࿋"),fmkZtbRj3ux(u"ࠬอๆห้์ࠤๆำีࠡษ็ื๏ืแาษอࠫ࿌"),L5jXH0fZ8TvsESR=vWNRusF46D7Mi8GpZ(u"࠺࠹࠵ၖ"))
						lfYsBbqzSkgn08T = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	AeNt1wShKYUqvMWs7P4CjLgm9f5dcb = OOnvcPQy85HYA.getSetting(yRWQMHxZEz0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ࿍"))
	if w8JC1y7Lp3(u"ࠧ࠮ࠩ࿎") in AeNt1wShKYUqvMWs7P4CjLgm9f5dcb:
		AeNt1wShKYUqvMWs7P4CjLgm9f5dcb = AeNt1wShKYUqvMWs7P4CjLgm9f5dcb.replace(xm6jK1ZMuWq5(u"ࠨ࠯ࠪ࿏"),wUvcPrYDfISbZolAm83GKEqMyXkn5)
		OOnvcPQy85HYA.setSetting(xm6jK1ZMuWq5(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭࿐"),AeNt1wShKYUqvMWs7P4CjLgm9f5dcb)
	if lfYsBbqzSkgn08T: te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(it4DKnryZlx(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ࿑"))
	return
def ggY6aiDlfmUxkCG():
	NEDpA34WOz2viGgJauoI = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(TNw1pBHb8CtSZe0EFxuJqI(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡍࡥࡵࡋࡷࡩࡲࡹࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵࠱ࠨࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ࠾ࡠࠨࡴࡪࡶ࡯ࡩࠧ࠲ࠢࡧ࡫࡯ࡩࠧ࠲ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࡡࢂ࠲ࠢࡪࡦࠥ࠾࠶ࢃࠧ࿒"))
	RCmHBOKtejQ8lu4L = bbeLsVCqouaSH53E0XmKh4AnFD.loads(NEDpA34WOz2viGgJauoI)[w8JC1y7Lp3(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ࿓")]
	m5IZKtrvc3j = wUvcPrYDfISbZolAm83GKEqMyXkn5
	try: items = RCmHBOKtejQ8lu4L[A6Sg45ChDR3BJLYfFH(u"࠭ࡩࡵࡧࡰࡷࠬ࿔")]
	except: return wUvcPrYDfISbZolAm83GKEqMyXkn5
	if items:
		for xJAIOQKvfpEH5Mn0Z1yUBqVCWY4,file in enumerate(items):
			path = file[s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡧ࡫࡯ࡩࠬ࿕")]
			if ggvQikMrmRXYdezZuUwj30WOc not in path: continue
			path = path.split(ggvQikMrmRXYdezZuUwj30WOc)[UD4N8MjVTd][UD4N8MjVTd:]
			if path==XhGSxvjRAZdU7rEt9JMweQC: break
		count = RCmHBOKtejQ8lu4L[MFhbWia58mP3su0fk2d(u"ࠨ࡮࡬ࡱ࡮ࡺࡳࠨ࿖")][bQGafNLXyFgsZP6ut(u"ࠩࡷࡳࡹࡧ࡬ࠨ࿗")]
		if xJAIOQKvfpEH5Mn0Z1yUBqVCWY4+UD4N8MjVTd<count: m5IZKtrvc3j = items[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4+UD4N8MjVTd][fmkZtbRj3ux(u"ࠪࡪ࡮ࡲࡥࠨ࿘")]
	return m5IZKtrvc3j
def TTpQfNshcSo():
	QZ0d7OmEhFDrfe = te28VJiPB7RXcm6brMUQyKAC3Z.executeJSONRPC(vWNRusF46D7Mi8GpZ(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥࢁࢂ࠭࿙"))
	z21ptngLbm8wjPrFe3J0NvCAYVIy = Z19pUxa2gfGMNKoDsEuytn85SjFvA if ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠬࡡ࡝ࠨ࿚") in str(QZ0d7OmEhFDrfe) else y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return z21ptngLbm8wjPrFe3J0NvCAYVIy
def ICwWPArNgl5tj38ZSYdX(BHAuOcSaz109Cns6vyUjoPbZN,AUJ80DlB7vuLfwN6gXVqmjOzMH=Z19pUxa2gfGMNKoDsEuytn85SjFvA):
	if BHAuOcSaz109Cns6vyUjoPbZN==pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"࠭ࡳࡵࡱࡳࠫ࿛") and (AUJ80DlB7vuLfwN6gXVqmjOzMH or TTuO14NzmB.busydialog_active):
		if AUJ80DlB7vuLfwN6gXVqmjOzMH: te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(w8JC1y7Lp3(u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠬࠫ࿜"))
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(DpRJnas65uVcO0S17dYG(u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰ࠮࠭࿝"))
		TTuO14NzmB.busydialog_active = Z19pUxa2gfGMNKoDsEuytn85SjFvA
	if BHAuOcSaz109Cns6vyUjoPbZN==D2PpKMeZFWrmfxTSs4L1tz(u"ࠩࡶࡸࡦࡸࡴࠨ࿞") and (AUJ80DlB7vuLfwN6gXVqmjOzMH or not TTuO14NzmB.busydialog_active):
		t3IHWvcajpJAh7N5YVswe = kPCxIUZb1V(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨ࿟") if Uy6GWujQiBLhodP>xdSThjYnuHXAU6M(u"࠵࠼࠴࠹࠺ၗ") else fmkZtbRj3ux(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨ࿠")
		te28VJiPB7RXcm6brMUQyKAC3Z.executebuiltin(jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠬࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࠧ࿡")+t3IHWvcajpJAh7N5YVswe+xdSThjYnuHXAU6M(u"࠭ࠩࠨ࿢"))
		TTuO14NzmB.busydialog_active = y0yvdNOZkiKEg5RLMhoDVQAB9F2
	return
def oKC1TfNgGlbj(*args,**kwargs):
	daemon = kwargs.pop(xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠧࡥࡣࡨࡱࡴࡴࠧ࿣"),Z19pUxa2gfGMNKoDsEuytn85SjFvA)
	zYtMNiWJ8TU = KoPyu0Aefth.Thread(*args,**kwargs)
	try: zYtMNiWJ8TU.setDaemon(daemon)
	except: pass
	try: zYtMNiWJ8TU.daemon = daemon
	except: pass
	return zYtMNiWJ8TU
def TO3vi2rSZ0LRhKlwgG4qkYFIC(Tor7SKmsCPZvL,KUOoYcT20iCLVgsw1ejzdkHp7XW):
	if bQGafNLXyFgsZP6ut(u"ࠨ࠰ࠪ࿤") not in Tor7SKmsCPZvL: return Tor7SKmsCPZvL
	Tor7SKmsCPZvL = Tor7SKmsCPZvL+DpRJnas65uVcO0S17dYG(u"ࠩ࠲ࠫ࿥")
	OQBc0kxweENKCmoZ59jP6RbaHF7G,HeRqJ5o6tlbA7 = Tor7SKmsCPZvL.split(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠪ࠲ࠬ࿦"),lCT8hfYUBX4OQMmL(u"࠶ၘ"))
	mWGRNAqtHswVlXFzu5,YAbd7BJUXQeyrI1hD5lWjNSGLpzxC = HeRqJ5o6tlbA7.split(it4DKnryZlx(u"ࠫ࠴࠭࿧"),Gj3rMP1Cb8wHdp49la0(u"࠷ၙ"))
	yeYP4jSHQzW3fgdMO5NT6V = OQBc0kxweENKCmoZ59jP6RbaHF7G+jQv0du1iVxTgAXCM(u"ࠬ࠴ࠧ࿨")+mWGRNAqtHswVlXFzu5
	if KUOoYcT20iCLVgsw1ejzdkHp7XW in [xdSThjYnuHXAU6M(u"࠭ࡨࡰࡵࡷࠫ࿩"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠧ࡯ࡣࡰࡩࠬ࿪")] and D2PpKMeZFWrmfxTSs4L1tz(u"ࠨ࠱ࠪ࿫") in yeYP4jSHQzW3fgdMO5NT6V: yeYP4jSHQzW3fgdMO5NT6V = yeYP4jSHQzW3fgdMO5NT6V.rsplit(jQv0du1iVxTgAXCM(u"ࠩ࠲ࠫ࿬"),VhqD3zp7mUieI8sMQlETH(u"࠱ၚ"))[UD4N8MjVTd]
	if KUOoYcT20iCLVgsw1ejzdkHp7XW==erqDsJmL3BQHuGtPkcf0X9(u"ࠪࡲࡦࡳࡥࠨ࿭") and A6Sg45ChDR3BJLYfFH(u"ࠫ࠳࠭࿮") in yeYP4jSHQzW3fgdMO5NT6V:
		A0As2PBEqupYmJcLKt7 = yeYP4jSHQzW3fgdMO5NT6V.split(yRWQMHxZEz0(u"ࠬ࠴ࠧ࿯"))
		YakLyiA3MO9dZCjwP7fxE2 = len(A0As2PBEqupYmJcLKt7)
		if erqDsJmL3BQHuGtPkcf0X9(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ࿰") in yeYP4jSHQzW3fgdMO5NT6V: A0As2PBEqupYmJcLKt7 = pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ࿱")
		elif YakLyiA3MO9dZCjwP7fxE2<=Tb7oymMnpflsSv3eu4Pz2: A0As2PBEqupYmJcLKt7 = A0As2PBEqupYmJcLKt7[wTLFCOcM26fmYlW7U]
		elif YakLyiA3MO9dZCjwP7fxE2>=MMRBkhnWVJCQwU: A0As2PBEqupYmJcLKt7 = A0As2PBEqupYmJcLKt7[UD4N8MjVTd]
		if len(A0As2PBEqupYmJcLKt7)>UD4N8MjVTd: yeYP4jSHQzW3fgdMO5NT6V = A0As2PBEqupYmJcLKt7
	return yeYP4jSHQzW3fgdMO5NT6V
def iHtxL9eylq(filename=xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻ࠸ࠨ࿲"), content=None, b5b2hWRe0IKc4YnNyqZw9a3X7lMt=s149dk8uh2p7oFzaLxZeI3Or(u"࠲࠲ၛ"), hFt2upbzdCYg4ly=None):
	hAuDSMRgITXybNaizctBkdQ3pfU8sE, host_ip, I2GEwvyqi903KxH6mlNcS1DBsR, NosM0peHjn5UEkqr9Q = w8JC1y7Lp3(u"࠶࠴ၝ"), JHMxIE4fs1mvQtKW7R(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ࿳"), MFhbWia58mP3su0fk2d(u"࠹࠺࠶࠰࠱ၞ"), gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠷࠸࠽࠾࠿ၜ")
	import socket as kkTDvdS6LY24nsjJMp3ba5uQmiX
	if wwMdFkWvcRYiXHB7yDrCqnKb98o:
		import http.server as E0rzBcfln6qUh15mCIp8
		import http.client as eXQnp9kaRH0uh3A
		from urllib.parse import urlparse as paseEOxUF3cPgS2Q5djnGL7Zml6w1i
	else:
		import BaseHTTPServer as E0rzBcfln6qUh15mCIp8
		import httplib as eXQnp9kaRH0uh3A
		from urlparse import urlparse as paseEOxUF3cPgS2Q5djnGL7Zml6w1i
	if hFt2upbzdCYg4ly is None: hFt2upbzdCYg4ly = []
	class ZOE7ciV0JnBDya(E0rzBcfln6qUh15mCIp8.BaseHTTPRequestHandler):
		def _2guSN6jKPC5Tryo7nqf(bEkFlihtL7jPn2IHZdsx):
			EWocI9yug7aCGqMDhT8HiknK6BQA = bEkFlihtL7jPn2IHZdsx.server
			path = paseEOxUF3cPgS2Q5djnGL7Zml6w1i(bEkFlihtL7jPn2IHZdsx.path).path
			Eb6I4LWXGvD7laiAeZsmRowVPu = TNw1pBHb8CtSZe0EFxuJqI(u"ࠥ࠳ࠧ࿴") + EWocI9yug7aCGqMDhT8HiknK6BQA.filename
			return path == Eb6I4LWXGvD7laiAeZsmRowVPu or (path.startswith(Eb6I4LWXGvD7laiAeZsmRowVPu) and path[len(Eb6I4LWXGvD7laiAeZsmRowVPu):len(Eb6I4LWXGvD7laiAeZsmRowVPu)+xdSThjYnuHXAU6M(u"࠶ၟ")] in (jQv0du1iVxTgAXCM(u"ࠦࠧ࿵"), s149dk8uh2p7oFzaLxZeI3Or(u"ࠧࡅࠢ࿶"), gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࠨࠦࠣ࿷"), llkFwuCyhaP3sK76qO4T(u"ࠢࡽࠤ࿸")))
		def do_HEAD(bEkFlihtL7jPn2IHZdsx):
			bEkFlihtL7jPn2IHZdsx.send_response(yRWQMHxZEz0(u"࠸࠰࠱ၠ") if bEkFlihtL7jPn2IHZdsx._2guSN6jKPC5Tryo7nqf() else lCT8hfYUBX4OQMmL(u"࠴࠱࠶ၡ"))
			bEkFlihtL7jPn2IHZdsx.end_headers()
		def do_GET(bEkFlihtL7jPn2IHZdsx):
			EWocI9yug7aCGqMDhT8HiknK6BQA = bEkFlihtL7jPn2IHZdsx.server
			if not bEkFlihtL7jPn2IHZdsx._2guSN6jKPC5Tryo7nqf():
				bEkFlihtL7jPn2IHZdsx.send_response(A6Sg45ChDR3BJLYfFH(u"࠵࠲࠷ၢ"))
				bEkFlihtL7jPn2IHZdsx.end_headers()
				return
			if EWocI9yug7aCGqMDhT8HiknK6BQA.redirect:
				bEkFlihtL7jPn2IHZdsx.send_response(DpRJnas65uVcO0S17dYG(u"࠵࠳࠶ၣ"))
				bEkFlihtL7jPn2IHZdsx.send_header(erqDsJmL3BQHuGtPkcf0X9(u"ࠣࡎࡲࡧࡦࡺࡩࡰࡰࠥ࿹"), EWocI9yug7aCGqMDhT8HiknK6BQA.content)
				bEkFlihtL7jPn2IHZdsx.end_headers()
			else:
				bEkFlihtL7jPn2IHZdsx.send_response(vvhR5ozeiJpANyl8fFO3GBw(u"࠵࠴࠵ၤ"))
				t3oe4rjuvpMQKwRnbkTaqYsAI6i5 = EWocI9yug7aCGqMDhT8HiknK6BQA.filename.lower()
				FeQPk9AgfY = (vvhR5ozeiJpANyl8fFO3GBw(u"ࠤࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡷࡰࡧ࠲ࡦࡶࡰ࡭ࡧ࠱ࡱࡵ࡫ࡧࡶࡴ࡯ࠦ࿺") if t3oe4rjuvpMQKwRnbkTaqYsAI6i5.endswith((jQv0du1iVxTgAXCM(u"ࠥࡱ࠸ࡻࠢ࿻"),llkFwuCyhaP3sK76qO4T(u"ࠦࡲ࠹ࡵ࠹ࠤ࿼")))
						else weh7SGmuTgXOVRcMo1rlLq(u"ࠧࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡨࡦࡹࡨࠬࡺࡰࡰࠧ࿽") if t3oe4rjuvpMQKwRnbkTaqYsAI6i5.endswith(ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠨ࡭ࡱࡦࠥ࿾"))
						else Gj3rMP1Cb8wHdp49la0(u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡵࡣࡵࡧࡷ࠱ࡸࡺࡲࡦࡣࡰࠦ࿿"))
				bEkFlihtL7jPn2IHZdsx.send_header(kPCxIUZb1V(u"ࠣࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠢက"), FeQPk9AgfY)
				bEkFlihtL7jPn2IHZdsx.end_headers()
				data = EWocI9yug7aCGqMDhT8HiknK6BQA.content
				if isinstance(data, str):
					try: data = data.encode(pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠤࡸࡸ࡫࠳࠸ࠣခ"))
					except: pass
				bEkFlihtL7jPn2IHZdsx.wfile.write(data)
			if b5b2hWRe0IKc4YnNyqZw9a3X7lMt:
				def tMjg9xlJQ6():
					L5jXH0fZ8TvsESR.sleep(b5b2hWRe0IKc4YnNyqZw9a3X7lMt)
					EWocI9yug7aCGqMDhT8HiknK6BQA.stop()
				oKC1TfNgGlbj(target=tMjg9xlJQ6, daemon=llkFwuCyhaP3sK76qO4T(u"ࡖࡵࡹࡪၪ")).start()
	class uZExD0KkrFcAP(E0rzBcfln6qUh15mCIp8.HTTPServer):
		b7R5L4dNjmAugx62fYzUkW = fmkZtbRj3ux(u"ࡗࡶࡺ࡫ၫ")
		def __init__(bEkFlihtL7jPn2IHZdsx):
			EEVa9fcPWtkzFKRx3Hg2XleonTu04 = set(hFt2upbzdCYg4ly)
			VBg4P6R109k2Y3In = set(range(I2GEwvyqi903KxH6mlNcS1DBsR, NosM0peHjn5UEkqr9Q + jnqzf9WihpUlxmcAEZ1vMLXNu(u"࠵ၥ"))) - EEVa9fcPWtkzFKRx3Hg2XleonTu04
			if not VBg4P6R109k2Y3In: raise RuntimeError(JHMxIE4fs1mvQtKW7R(u"ࠥࡒࡴࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡳࡳࡷࡺࡳࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡴࡤࡲ࡬࡫ࠠࡼࡿ࠰ࡿࢂࠨဂ").format(I2GEwvyqi903KxH6mlNcS1DBsR, NosM0peHjn5UEkqr9Q))
			while gVpGcN7nxEWLri4DvyAZlU3BQM(u"ࡘࡷࡻࡥၬ"):
				host_port = kItsbxAFUXc3.choice(list(VBg4P6R109k2Y3In))
				ydHSGDhXMWYr83BRF5ZsV = kkTDvdS6LY24nsjJMp3ba5uQmiX.socket(kkTDvdS6LY24nsjJMp3ba5uQmiX.AF_INET, kkTDvdS6LY24nsjJMp3ba5uQmiX.SOCK_STREAM)
				try:
					ydHSGDhXMWYr83BRF5ZsV.bind((host_ip, host_port))
					ydHSGDhXMWYr83BRF5ZsV.close()
					break
				except:
					ydHSGDhXMWYr83BRF5ZsV.close()
					VBg4P6R109k2Y3In.remove(host_port)
					if not VBg4P6R109k2Y3In: raise RuntimeError(jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠦࡆࡲ࡬ࠡࡲࡲࡶࡹࡹࠠࡪࡰࠣࡸ࡭࡫ࠠࡳࡣࡱ࡫ࡪࠦࡻࡾ࠯ࡾࢁࠥࡧࡲࡦࠢࡥࡹࡸࡿࠢဃ").format(I2GEwvyqi903KxH6mlNcS1DBsR, NosM0peHjn5UEkqr9Q))
			E0rzBcfln6qUh15mCIp8.HTTPServer.__init__(bEkFlihtL7jPn2IHZdsx, (host_ip, host_port), ZOE7ciV0JnBDya)
			bEkFlihtL7jPn2IHZdsx.host_ip = host_ip
			bEkFlihtL7jPn2IHZdsx.host_port = host_port
			bEkFlihtL7jPn2IHZdsx.filename = filename
			bEkFlihtL7jPn2IHZdsx.content = content
			bEkFlihtL7jPn2IHZdsx.redirect = isinstance(content, str) and content.startswith((bQGafNLXyFgsZP6ut(u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨင"),pbqVnrxuf3ymhKDsQ4e9XMdEt8Rowz(u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣစ")))
			bEkFlihtL7jPn2IHZdsx.running = D2PpKMeZFWrmfxTSs4L1tz(u"ࡋࡧ࡬ࡴࡧၭ")
			bEkFlihtL7jPn2IHZdsx.fileurl = kPCxIUZb1V(u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡼࡿ࠽ࡿࢂ࠵ࡻࡾࠤဆ").format(host_ip, host_port, filename)
		def start(bEkFlihtL7jPn2IHZdsx):
			if bEkFlihtL7jPn2IHZdsx.running: return
			bEkFlihtL7jPn2IHZdsx.running = Gj3rMP1Cb8wHdp49la0(u"࡚ࡲࡶࡧၮ")
			oKC1TfNgGlbj(target=bEkFlihtL7jPn2IHZdsx.serve_forever, kwargs={ZiCLpR1Tc5vUlPXDWgmhM6j(u"ࠣࡲࡲࡰࡱࡥࡩ࡯ࡶࡨࡶࡻࡧ࡬ࠣဇ"): gVpGcN7nxEWLri4DvyAZlU3BQM(u"࠵࠴࠵ၦ")}, daemon=rDG9dZoXRhCJcieUSF0KB(u"ࡔࡳࡷࡨၯ")).start()
			if hAuDSMRgITXybNaizctBkdQ3pfU8sE:
				def tMjg9xlJQ6():
					L5jXH0fZ8TvsESR.sleep(hAuDSMRgITXybNaizctBkdQ3pfU8sE)
					bEkFlihtL7jPn2IHZdsx.stop()
				oKC1TfNgGlbj(target=tMjg9xlJQ6, daemon=fmkZtbRj3ux(u"ࡕࡴࡸࡩၰ")).start()
		def stop(bEkFlihtL7jPn2IHZdsx):
			if not bEkFlihtL7jPn2IHZdsx.running: return
			bEkFlihtL7jPn2IHZdsx.running = it4DKnryZlx(u"ࡈࡤࡰࡸ࡫ၱ")
			try:
				bEkFlihtL7jPn2IHZdsx.shutdown()
				bEkFlihtL7jPn2IHZdsx.server_close()
			except: pass
	FFwVakdM8NvjeJRK3oyQI9ti24 = uZExD0KkrFcAP()
	hFt2upbzdCYg4ly.append(FFwVakdM8NvjeJRK3oyQI9ti24.host_port)
	return FFwVakdM8NvjeJRK3oyQI9ti24, FFwVakdM8NvjeJRK3oyQI9ti24.fileurl
def QEbx35yvreoT2sPDG4k9Fcfa8Z(xLDEnp9WdA,xVwDZbA6EOjpgX0=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	VvSIUJlTz92GhbYaNu1PDkR0MpnZ = [jFTLNAGkBI6mZWD3Ua2ehwpoyVb4H7(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬဈ"),jnqzf9WihpUlxmcAEZ1vMLXNu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜ࠫဉ"),Gj3rMP1Cb8wHdp49la0(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬည"),rDG9dZoXRhCJcieUSF0KB(u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭ဋ"),VhqD3zp7mUieI8sMQlETH(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨဌ"),DpRJnas65uVcO0S17dYG(u"ࠧࡆ࡚ࡆࡐ࡚ࡊࡅࡔࠩဍ"),JHMxIE4fs1mvQtKW7R(u"ࠨࡈࡄ࡚ࡔࡘࡉࡕࡇࡖࠫဎ"),VhqD3zp7mUieI8sMQlETH(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨဏ"),jQv0du1iVxTgAXCM(u"ࠪࡑࡊࡔࡕࡔࠩတ"),xE6cFVGitMk5SAPTsNa7lpYH9Lf(u"ࠫࡉࡏࡁࡍࡑࡊࡗࠬထ"),D2PpKMeZFWrmfxTSs4L1tz(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧဒ"),A6Sg45ChDR3BJLYfFH(u"࠭ࡉࡑࡖ࡙ࠫဓ"),erqDsJmL3BQHuGtPkcf0X9(u"ࠧࡎ࠵ࡘࠫန"),Gj3rMP1Cb8wHdp49la0(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨပ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"ࠩࡕࡅࡓࡊࡏࡎࡕࠪဖ"),vvhR5ozeiJpANyl8fFO3GBw(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬဗ")]
	dT7CBnc3EsMp = rjZFa0VMBuPRHg1cIYJpd52oxl4(xLDEnp9WdA)
	z2n3Nc6IVsQB9rPHJFU = xLDEnp9WdA
	if dT7CBnc3EsMp or D2PpKMeZFWrmfxTSs4L1tz(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡺ࡮ࡪࡥࡰࠩဘ") in xLDEnp9WdA or not xVwDZbA6EOjpgX0 or any(bzknSulmrdHw6AspVe0T in xVwDZbA6EOjpgX0 for bzknSulmrdHw6AspVe0T in VvSIUJlTz92GhbYaNu1PDkR0MpnZ): z2n3Nc6IVsQB9rPHJFU = TO3vi2rSZ0LRhKlwgG4qkYFIC(xLDEnp9WdA,dhzX91Lcgv0PxaYHEOwMTCbItyo2q(u"ࠬࡻࡲ࡭ࠩမ"))+xm6jK1ZMuWq5(u"࠭࠯࠯࠰࠱࠲࠳࠭ယ")
	return z2n3Nc6IVsQB9rPHJFU
def mLh8JBt075iUqNOSDCVFsPIM6KgzGc(*args):
    def BKtmSe5oFfpNUPG6vYClL2zbWcA(NzXAxGM5kTrfHOsQE):
        if isinstance(NzXAxGM5kTrfHOsQE, list): return [BKtmSe5oFfpNUPG6vYClL2zbWcA(qbRmVByrJv18) for qbRmVByrJv18 in NzXAxGM5kTrfHOsQE]
        if isinstance(NzXAxGM5kTrfHOsQE, tuple): return tuple(BKtmSe5oFfpNUPG6vYClL2zbWcA(qbRmVByrJv18) for qbRmVByrJv18 in NzXAxGM5kTrfHOsQE)
        if ndib93Ol6UojCrEV and isinstance(NzXAxGM5kTrfHOsQE, unicode): return NzXAxGM5kTrfHOsQE.encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
        if wwMdFkWvcRYiXHB7yDrCqnKb98o and isinstance(NzXAxGM5kTrfHOsQE, bytes): return NzXAxGM5kTrfHOsQE.decode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
        return NzXAxGM5kTrfHOsQE
    e18JKsfFclnNABQgiLMCP9qky0Sv = tuple(BKtmSe5oFfpNUPG6vYClL2zbWcA(DX0eijvnRQxBH) for DX0eijvnRQxBH in args)
    return e18JKsfFclnNABQgiLMCP9qky0Sv[DpRJnas65uVcO0S17dYG(u"࠰ၨ")] if len(e18JKsfFclnNABQgiLMCP9qky0Sv) == JHMxIE4fs1mvQtKW7R(u"࠷ၧ") else e18JKsfFclnNABQgiLMCP9qky0Sv
wE8xBbfWv0JzSmUHPRFe6nAyh = o1oqytTs5j0rx(bcP2jUx34tG51D6XSNnyWIes,vWNRusF46D7Mi8GpZ(u"ࠧ࡭࡫ࡶࡸࠬရ"),xdSThjYnuHXAU6M(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫလ"),fmkZtbRj3ux(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧဝ"))
if wE8xBbfWv0JzSmUHPRFe6nAyh:
	hhXr9bcDZSgFGT7ApzxUofVwRC,gHh2bAXnxfmIK1,ddasBvFEhwMy3N2Ol9tGmqIjPnSoeC,IfkcR5De6VTtgA8UuKYMQaZx0P1X2 = wE8xBbfWv0JzSmUHPRFe6nAyh
	TTuO14NzmB.AV_CLIENT_IDS = QWLr8ABjev.join(hhXr9bcDZSgFGT7ApzxUofVwRC)
if not TTuO14NzmB.AV_CLIENT_IDS: TTuO14NzmB.AV_CLIENT_IDS = pnhyIzwgbCTmxs()
lOLcNuSPX5D = VYKkdLDhHgT()
TTuO14NzmB.lOuLW0pjdgS4zX,TTuO14NzmB.W1haXcb7tVZ6K,TTuO14NzmB.ijmTSzJ1l9Nutf3aoVEZk,TTuO14NzmB.o4ZShCq8b53OYkUjrAwGDm1pT7PW,TTuO14NzmB.avprivsnorestrict,TTuO14NzmB.avprivslongperiod = WtlCneczGPY2ODSUrAh5jdsf6m([DpRJnas65uVcO0S17dYG(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫသ"),kPCxIUZb1V(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬဟ"),it4DKnryZlx(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪဠ"),SVQT7vyFXYNMZLRdhGbuJqOslE806n(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧအ"),xm6jK1ZMuWq5(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡬࡮ࡇ࡚ࡊ࡜ࡅ࡙ࠩဢ"),fmkZtbRj3ux(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧဣ")])
wLpPS96U1IKRxFzjVtHZG = TTuO14NzmB.AV_CLIENT_IDS.splitlines()[wTLFCOcM26fmYlW7U][-xdSThjYnuHXAU6M(u"࠳࠶ၩ"):]