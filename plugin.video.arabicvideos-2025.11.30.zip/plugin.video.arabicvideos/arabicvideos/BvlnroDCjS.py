﻿# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
def DDIqhZaAit8Ed9(ooPMZSnrRDG6xNpJHVmgw8IOA1,pie9gXum687lZb):
	if pie9gXum687lZb==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	if ooPMZSnrRDG6xNpJHVmgw8IOA1==1:
		Z4fIB0elNwD3EnY = llfAzdjaVLTbyZW7op9i.getCurrentWindowDialogId()
		mlwSDqc5fo7RpeUH8X = llfAzdjaVLTbyZW7op9i.Window(Z4fIB0elNwD3EnY)
		pie9gXum687lZb = ixCwD64eNn8zKkm2Jb(pie9gXum687lZb)
		mlwSDqc5fo7RpeUH8X.getControl(311).setLabel(pie9gXum687lZb)
	if ooPMZSnrRDG6xNpJHVmgw8IOA1==0:
		KUOoYcT20iCLVgsw1ejzdkHp7XW='X'
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: XrnslmMLza2k3Hg8JDx9P5Ybvuhy = isinstance(pie9gXum687lZb,str)
		else: XrnslmMLza2k3Hg8JDx9P5Ybvuhy = isinstance(pie9gXum687lZb,unicode)
		if XrnslmMLza2k3Hg8JDx9P5Ybvuhy==True: KUOoYcT20iCLVgsw1ejzdkHp7XW='U'
		a8bZmsKXS5IiLw1ForW=str(type(pie9gXum687lZb))+UKFZBQAVXHI5s17LyvuRpCY2+pie9gXum687lZb+UKFZBQAVXHI5s17LyvuRpCY2+KUOoYcT20iCLVgsw1ejzdkHp7XW+UKFZBQAVXHI5s17LyvuRpCY2
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(0,len(pie9gXum687lZb),1):
			a8bZmsKXS5IiLw1ForW += hex(ord(pie9gXum687lZb[kkLhJCU4MQSx7s6gyeOHrRYKtnP3])).replace('0x',wUvcPrYDfISbZolAm83GKEqMyXkn5)+UKFZBQAVXHI5s17LyvuRpCY2
		pie9gXum687lZb = ixCwD64eNn8zKkm2Jb(pie9gXum687lZb)
		KUOoYcT20iCLVgsw1ejzdkHp7XW='X'
		if wwMdFkWvcRYiXHB7yDrCqnKb98o: XrnslmMLza2k3Hg8JDx9P5Ybvuhy = isinstance(pie9gXum687lZb, str)
		else: XrnslmMLza2k3Hg8JDx9P5Ybvuhy = isinstance(pie9gXum687lZb, unicode)
		if XrnslmMLza2k3Hg8JDx9P5Ybvuhy==True: KUOoYcT20iCLVgsw1ejzdkHp7XW='U'
		omH4d8Vz0nwAehKasUxQPkgLb=str(type(pie9gXum687lZb))+UKFZBQAVXHI5s17LyvuRpCY2+pie9gXum687lZb+UKFZBQAVXHI5s17LyvuRpCY2+KUOoYcT20iCLVgsw1ejzdkHp7XW+UKFZBQAVXHI5s17LyvuRpCY2
		for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(0,len(pie9gXum687lZb),1):
			omH4d8Vz0nwAehKasUxQPkgLb += hex(ord(pie9gXum687lZb[kkLhJCU4MQSx7s6gyeOHrRYKtnP3])).replace('0x',wUvcPrYDfISbZolAm83GKEqMyXkn5)+UKFZBQAVXHI5s17LyvuRpCY2
	return