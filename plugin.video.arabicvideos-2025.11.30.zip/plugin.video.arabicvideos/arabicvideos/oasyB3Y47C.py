# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'MOVS4U'
UT69hgqoKsWNIwM5zkAYb = '_M4U_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
i6TIRax9v0EDFJs2gVtfzp = ['انواع افلام','جودات افلام']
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==380: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==381: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==382: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==383: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==389: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,389,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'المميزة',hhD7r1VvaPt3TC06SJjqKRfEid,381,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'featured')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الجانبية',hhD7r1VvaPt3TC06SJjqKRfEid,381,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'sider')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVS4U-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	items = jj0dZrgiKb.findall('<header>.*?<h2>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in range(len(items)):
		title = items[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhD7r1VvaPt3TC06SJjqKRfEid,381,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'latest'+str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4))
	IJE2xcV7OWauUKhfik56gXBwltCb = wUvcPrYDfISbZolAm83GKEqMyXkn5
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="menu"(.*?)id="contenedor"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb += pLHIPUY3TWAeE70[0]
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="sidebar(.*?)aside',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70: IJE2xcV7OWauUKhfik56gXBwltCb += pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	ooZGMlYybF8aNfAOwps = True
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if title=='الأعلى مشاهدة':
			if ooZGMlYybF8aNfAOwps:
				title = 'الافلام '+title
				ooZGMlYybF8aNfAOwps = False
			else: title = 'المسلسلات '+title
		if title not in i6TIRax9v0EDFJs2gVtfzp:
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,381)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,type):
	IJE2xcV7OWauUKhfik56gXBwltCb,items = [],[]
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVS4U-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if type=='search':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="search-page"(.*?)class="sidebar',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
			items = jj0dZrgiKb.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif type=='sider':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="widget(.*?)class="widget',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		CUuoz0cPV76rGqEdNT = jj0dZrgiKb.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,DGEMLXJQUt3PoYgVCfT7lbk80ujx9,Eu8LWnSt3fyJzIC = zip(*CUuoz0cPV76rGqEdNT)
		items = zip(DGEMLXJQUt3PoYgVCfT7lbk80ujx9,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,Eu8LWnSt3fyJzIC)
	elif type=='featured':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="slider-movies-tvshows"(.*?)<header>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	elif 'latest' in type:
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = int(type[-1:])
		II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('<header>','<end><start>')
		II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('<div class="sidebar','<end><div class="sidebar')
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('<start>(.*?)<end>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
		if xJAIOQKvfpEH5Mn0Z1yUBqVCWY4==2: items = jj0dZrgiKb.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	else:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="content"(.*?)class="(pagination|sidebar)',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if pLHIPUY3TWAeE70:
			IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0][0]
			if '/collection/' in url:
				items = jj0dZrgiKb.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			elif '/quality/' in url:
				items = jj0dZrgiKb.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	if not items and IJE2xcV7OWauUKhfik56gXBwltCb:
		items = jj0dZrgiKb.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title in items:
		if 'serie' in title:
			title = jj0dZrgiKb.findall('^(.*?)<.*?serie">(.*?)<',title,jj0dZrgiKb.DOTALL)
			title = title[0][1]
			if title in v2v3ase4WBgVjbOnu96PCzlDKi: continue
			v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
			title = '_MOD_'+title
		HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ = jj0dZrgiKb.findall('^(.*?)<',title,jj0dZrgiKb.DOTALL)
		if HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ: title = HvPuaWlf9LgJbYj4h8p5Dy2V3qtQ[0]
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if '/tvshows/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,383,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/episodes/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,383,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/seasons/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,383,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif '/collection/' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,381,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,382,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		jxmwZeCtFYMVHyghqDbc3SrBfQ = pLHIPUY3TWAeE70[0][0]
		dnAqeU2LoCD0ZPljtO5uWGp6 = pLHIPUY3TWAeE70[0][1]
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0][2]
		items = jj0dZrgiKb.findall("href='(.*?)'.*?>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if title==wUvcPrYDfISbZolAm83GKEqMyXkn5 or title==dnAqeU2LoCD0ZPljtO5uWGp6: continue
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,381,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('/page/'+title+'/','/page/'+dnAqeU2LoCD0ZPljtO5uWGp6+'/')
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'اخر صفحة '+dnAqeU2LoCD0ZPljtO5uWGp6,hhEH1rcSP0z6Bkqy8OD,381,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,type)
	return
def mCwqRg7HpivAQ6S(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVS4U-EPISODES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	bxiMUQmPRvu = jj0dZrgiKb.findall('class="C rated".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu,False):
		mwOxEyYAg63B('link',UT69hgqoKsWNIwM5zkAYb+'المسلسل للكبار والمبرمج منعه',wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		ZD5n0eJivzWOMxY98dgrumkwRG = jj0dZrgiKb.findall('''class='item'><a href="(.*?)"''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		if ZD5n0eJivzWOMxY98dgrumkwRG:
			ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG[1]
			mCwqRg7HpivAQ6S(ZD5n0eJivzWOMxY98dgrumkwRG)
			return
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''class='episodios'(.*?)id="cast"''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,xNVKL75nEZstg4wfXBkySQ,hhEH1rcSP0z6Bkqy8OD,name in items:
			title = xNVKL75nEZstg4wfXBkySQ+' : '+name+' الحلقة'
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,382)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVS4U-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	bxiMUQmPRvu = jj0dZrgiKb.findall('class="C rated".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0][0]
		items = jj0dZrgiKb.findall("data-url='(.*?)'.*?class='server'>(.*?)<",IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__watch'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="remodal"(.*?)class="remodal-close"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD+'?named='+title+'__download'
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/?s='+search
	HPdaS7kenW0m(url,'search')
	return