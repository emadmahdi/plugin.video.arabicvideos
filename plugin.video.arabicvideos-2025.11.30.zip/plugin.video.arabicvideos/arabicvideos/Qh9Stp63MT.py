# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'MOVIZLAND'
headers = { 'User-Agent' : wUvcPrYDfISbZolAm83GKEqMyXkn5 }
UT69hgqoKsWNIwM5zkAYb = '_MVZ_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
wkbMLZA1UPQtRnDcmri7qyHz = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][1]
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==180: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==181: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,text)
	elif mode==182: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==183: RCmHBOKtejQ8lu4L = mCwqRg7HpivAQ6S(url)
	elif mode==188: RCmHBOKtejQ8lu4L = C1Lh7bWnItdwZ8()
	elif mode==189: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def C1Lh7bWnItdwZ8():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	IUaTPEbvz0powmgNSFn4fQhLKRiZ6(wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,mvVFtPw8JKpaUdXq06YrEeR7bAk2,message)
	return
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,189,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'بوكس اوفيس موفيز لاند',hhD7r1VvaPt3TC06SJjqKRfEid,181,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'box-office')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أحدث الافلام',hhD7r1VvaPt3TC06SJjqKRfEid,181,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'latest-movies')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'تليفزيون موفيز لاند',hhD7r1VvaPt3TC06SJjqKRfEid,181,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'tv')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'الاكثر مشاهدة',hhD7r1VvaPt3TC06SJjqKRfEid,181,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'top-views')
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'أقوى الافلام الحالية',hhD7r1VvaPt3TC06SJjqKRfEid,181,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'top-movies')
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-MENU-1st')
	items = jj0dZrgiKb.findall('<h2><a href="(.*?)".*?">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,181)
	return II64TLxj3mbqEyh9pHQ8oAv
def HPdaS7kenW0m(url,type=wUvcPrYDfISbZolAm83GKEqMyXkn5):
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	elif type=='box-office': IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	elif type=='top-movies': IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('btn-2-overlay(.*?)<style>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	elif type=='top-views': IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	elif type=='tv': IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	else: IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
	if type in ['top-views','top-movies']:
		items = jj0dZrgiKb.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	else: items = jj0dZrgiKb.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	v2v3ase4WBgVjbOnu96PCzlDKi = []
	F1wxEktW8Dpi5YbsAm = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C,DxOAJGpP9gmy3WXVkTucdeiw4F in items:
		if type in ['top-views','top-movies']:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,q4zyW5Bpx6Y2O,title = cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C,DxOAJGpP9gmy3WXVkTucdeiw4F
		else: cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title,hhEH1rcSP0z6Bkqy8OD,q4zyW5Bpx6Y2O = cPzpeLXs3jMCltW4ZN9BaYdfQvwS,Px8NBrt4vuzDFLfcw,oZkUpQhtGPKDNJdlImW9C,DxOAJGpP9gmy3WXVkTucdeiw4F
		hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
		hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD.replace('?view=true',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('بجوده ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if 'الحلقة' in title or 'الحلقه' in title:
			xNVKL75nEZstg4wfXBkySQ = jj0dZrgiKb.findall('(.*?) (الحلقة|الحلقه) \d+',title,jj0dZrgiKb.DOTALL)
			if xNVKL75nEZstg4wfXBkySQ:
				title = '_MOD_' + xNVKL75nEZstg4wfXBkySQ[0][0]
				if title not in v2v3ase4WBgVjbOnu96PCzlDKi:
					mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,183,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
					v2v3ase4WBgVjbOnu96PCzlDKi.append(title)
		elif any(value in title for value in F1wxEktW8Dpi5YbsAm):
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD + '?servers=' + q4zyW5Bpx6Y2O
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,182,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else:
			hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD + '?servers=' + q4zyW5Bpx6Y2O
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,183,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if type==wUvcPrYDfISbZolAm83GKEqMyXkn5:
		items = jj0dZrgiKb.findall('\n<li><a href="(.*?)".*?>(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			title = title.replace('الصفحة ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
			if title!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+title,hhEH1rcSP0z6Bkqy8OD,181)
	return
def mCwqRg7HpivAQ6S(url):
	ZD5n0eJivzWOMxY98dgrumkwRG = url.split('?servers=')[0]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-EPISODES-1st')
	IJE2xcV7OWauUKhfik56gXBwltCb = jj0dZrgiKb.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	title,vziHL4xVFSD81W7X9Noyrdjb,cPzpeLXs3jMCltW4ZN9BaYdfQvwS = IJE2xcV7OWauUKhfik56gXBwltCb[0]
	name = jj0dZrgiKb.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,jj0dZrgiKb.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="episodesNumbers"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD in items:
			hhEH1rcSP0z6Bkqy8OD = Z6bUG0kDQuFqgzdAa1r(hhEH1rcSP0z6Bkqy8OD)
			title = jj0dZrgiKb.findall('(الحلقة|الحلقه)-([0-9]+)',hhEH1rcSP0z6Bkqy8OD.split('/')[-2],jj0dZrgiKb.DOTALL)
			if not title: title = jj0dZrgiKb.findall('()-([0-9]+)',hhEH1rcSP0z6Bkqy8OD.split('/')[-2],jj0dZrgiKb.DOTALL)
			if title: title = UKFZBQAVXHI5s17LyvuRpCY2 + title[0][1]
			else: title = wUvcPrYDfISbZolAm83GKEqMyXkn5
			title = name + ' - ' + 'الحلقة' + title
			title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,182,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if not items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',wUvcPrYDfISbZolAm83GKEqMyXkn5).replace('بجوده ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,url,182,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	wwH9NWv8LbqMyo1IQElsXU = url.split('?servers=')
	ZD5n0eJivzWOMxY98dgrumkwRG = wwH9NWv8LbqMyo1IQElsXU[0]
	del wwH9NWv8LbqMyo1IQElsXU[0]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-PLAY-1st')
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('font-size: 25px;" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)[0]
	if hhEH1rcSP0z6Bkqy8OD not in wwH9NWv8LbqMyo1IQElsXU: wwH9NWv8LbqMyo1IQElsXU.append(hhEH1rcSP0z6Bkqy8OD)
	j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = []
	for hhEH1rcSP0z6Bkqy8OD in wwH9NWv8LbqMyo1IQElsXU:
		if '://moshahda.' in hhEH1rcSP0z6Bkqy8OD:
			SS4FcIujetOiGxZpdHN3rMms9 = hhEH1rcSP0z6Bkqy8OD
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(SS4FcIujetOiGxZpdHN3rMms9+'?named=Main')
	for hhEH1rcSP0z6Bkqy8OD in wwH9NWv8LbqMyo1IQElsXU:
		if '://vb.movizland.' in hhEH1rcSP0z6Bkqy8OD:
			II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,hhEH1rcSP0z6Bkqy8OD,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-PLAY-2nd')
			II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.decode(iYJabyEm07Fu15xqSWUhV).encode(t3jo0Wv6mHQ1ypIgfUd7KO5EhLADq)
			II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			II64TLxj3mbqEyh9pHQ8oAv = II64TLxj3mbqEyh9pHQ8oAv.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
			if pLHIPUY3TWAeE70:
				AE7VM9Itbw2Be5hmXQSJW08LkrPy,lI7nrTA6abMO = [],[]
				if len(pLHIPUY3TWAeE70)==1:
					title = wUvcPrYDfISbZolAm83GKEqMyXkn5
					IJE2xcV7OWauUKhfik56gXBwltCb = II64TLxj3mbqEyh9pHQ8oAv
				else:
					for IJE2xcV7OWauUKhfik56gXBwltCb in pLHIPUY3TWAeE70:
						i9eu0gvptXjKMAczZyE = jj0dZrgiKb.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
						if i9eu0gvptXjKMAczZyE: IJE2xcV7OWauUKhfik56gXBwltCb = 'src="/uploads/13721411411.png"  \n  ' + i9eu0gvptXjKMAczZyE[0][1]
						i9eu0gvptXjKMAczZyE = jj0dZrgiKb.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
						if i9eu0gvptXjKMAczZyE: IJE2xcV7OWauUKhfik56gXBwltCb = 'src="/uploads/13721411411.png"  \n  ' + i9eu0gvptXjKMAczZyE[0]
						i9eu0gvptXjKMAczZyE = jj0dZrgiKb.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
						if i9eu0gvptXjKMAczZyE: IJE2xcV7OWauUKhfik56gXBwltCb = i9eu0gvptXjKMAczZyE[0] + '  \n  src="/uploads/13721411411.png"'
						AXrOSkp4tC = jj0dZrgiKb.findall('<(.*?)http://up.movizland.(online|com)/uploads/',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
						title = jj0dZrgiKb.findall('> *([^<>]+) *<',AXrOSkp4tC[0][0],jj0dZrgiKb.DOTALL)
						title = UKFZBQAVXHI5s17LyvuRpCY2.join(title)
						title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
						title = title.replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2).replace(lB8tuyg6sxkDVYAaS95K3GI,UKFZBQAVXHI5s17LyvuRpCY2)
						AE7VM9Itbw2Be5hmXQSJW08LkrPy.append(title)
					EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('أختر الفيديو المطلوب:', AE7VM9Itbw2Be5hmXQSJW08LkrPy)
					if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1 : return
					title = AE7VM9Itbw2Be5hmXQSJW08LkrPy[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
					IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
				hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('href="(http://moshahda\..*?/\w+.html)"',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				tw9FbeZ65yAlYsDJSIEc = hhEH1rcSP0z6Bkqy8OD[0]
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(tw9FbeZ65yAlYsDJSIEc+'?named=Forum')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('ـ',wUvcPrYDfISbZolAm83GKEqMyXkn5)
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				IJE2xcV7OWauUKhfik56gXBwltCb = IJE2xcV7OWauUKhfik56gXBwltCb.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				vvp1yfeiwxRWJrlHangSCmE = jj0dZrgiKb.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
				for ND3cz6jEYRmPOdk2V4fHhrAyl0ti in vvp1yfeiwxRWJrlHangSCmE:
					type = jj0dZrgiKb.findall(' typetype="(.*?)" ',ND3cz6jEYRmPOdk2V4fHhrAyl0ti)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = wUvcPrYDfISbZolAm83GKEqMyXkn5
					items = jj0dZrgiKb.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',ND3cz6jEYRmPOdk2V4fHhrAyl0ti,jj0dZrgiKb.DOTALL)
					for JJwVmjGHcrE0eLDugbAB23MIhyoxX,hhEH1rcSP0z6Bkqy8OD in items:
						title = jj0dZrgiKb.findall('(\w+[ \w]*)<',JJwVmjGHcrE0eLDugbAB23MIhyoxX)
						title = title[-1]
						hhEH1rcSP0z6Bkqy8OD = hhEH1rcSP0z6Bkqy8OD + '?named=' + title + type
						j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD)
	qaLFXuDExl8w = ZD5n0eJivzWOMxY98dgrumkwRG.replace(hhD7r1VvaPt3TC06SJjqKRfEid,wkbMLZA1UPQtRnDcmri7qyHz)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,qaLFXuDExl8w,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-PLAY-3rd')
	items = jj0dZrgiKb.findall('" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if items:
		wn0h7fPT5Hm3CVQ9eJKc = items[-1]
		j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(wn0h7fPT5Hm3CVQ9eJKc+'?named=Mobile')
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,headers,wUvcPrYDfISbZolAm83GKEqMyXkn5,'MOVIZLAND-SEARCH-1st')
	items = jj0dZrgiKb.findall('<option value="(.*?)">(.*?)</option>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	jkRTfVm6zoBp9WH7 = [ wUvcPrYDfISbZolAm83GKEqMyXkn5 ]
	jQAMvhgGXN2oWuK9i1BqEZCyH = [ 'الكل وبدون فلتر' ]
	for d5TLHSj39awfvFp,title in items:
		jkRTfVm6zoBp9WH7.append(d5TLHSj39awfvFp)
		jQAMvhgGXN2oWuK9i1BqEZCyH.append(title)
	if d5TLHSj39awfvFp:
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('اختر الفلتر المناسب:', jQAMvhgGXN2oWuK9i1BqEZCyH)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1 : return
		d5TLHSj39awfvFp = jkRTfVm6zoBp9WH7[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	else: d5TLHSj39awfvFp = wUvcPrYDfISbZolAm83GKEqMyXkn5
	url = hhD7r1VvaPt3TC06SJjqKRfEid + '/?s='+search+'&mcat='+d5TLHSj39awfvFp
	HPdaS7kenW0m(url)
	return