# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'EGYBESTVIP'
UT69hgqoKsWNIwM5zkAYb = '_EGV_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
def DDIqhZaAit8Ed9(mode,url,sbNukjOf4chz,text):
	if   mode==220: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==221: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url,sbNukjOf4chz)
	elif mode==222: RCmHBOKtejQ8lu4L = FFJX0sguE92DxYGmoQAeV(url)
	elif mode==223: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==224: RCmHBOKtejQ8lu4L = mmUxVlf7ZQMjeDE(url)
	elif mode==229: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,229,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBEST-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="i i-home"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)"(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,222)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="ba(.*?)<script',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		for title,hhEH1rcSP0z6Bkqy8OD in items:
			mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,221)
		mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
		items = jj0dZrgiKb.findall('href="(.*?)".*?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if 'html' not in hhEH1rcSP0z6Bkqy8OD: continue
			if not hhEH1rcSP0z6Bkqy8OD.endswith('/'): mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,221)
	return II64TLxj3mbqEyh9pHQ8oAv
def FFJX0sguE92DxYGmoQAeV(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-SUBMENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="rs_scroll"(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?</i>(.*?)</a>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,224)
	return
def mmUxVlf7ZQMjeDE(url):
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'الجميع',url,221)
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-FILTERS_MENU-1st')
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="sub_nav(.*?)id="movies',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".+?>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title in items:
			if hhEH1rcSP0z6Bkqy8OD=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,221)
	else: HPdaS7kenW0m(url)
	return
def HPdaS7kenW0m(url,sbNukjOf4chz='1'):
	if sbNukjOf4chz==wUvcPrYDfISbZolAm83GKEqMyXkn5: sbNukjOf4chz = '1'
	if '/search' in url or '?' in url: ZD5n0eJivzWOMxY98dgrumkwRG = url + '&'
	else: ZD5n0eJivzWOMxY98dgrumkwRG = url + '?'
	ZD5n0eJivzWOMxY98dgrumkwRG = ZD5n0eJivzWOMxY98dgrumkwRG + 'page=' + sbNukjOf4chz
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(d2priEnu57KztRsm8wCHZ,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		pLHIPUY3TWAeE70=jj0dZrgiKb.findall('class="pda"(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[-1]
	elif '/series/' in url:
		pLHIPUY3TWAeE70=jj0dZrgiKb.findall('class="owl-carousel owl-carousel(.*?)div',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	else:
		pLHIPUY3TWAeE70=jj0dZrgiKb.findall('id="movies(.*?)</div>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[-1]
	items = jj0dZrgiKb.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title in items:
		title = mS56vX0aHqVOgJBIoYiAM8hcnZrKE3(title)
		if '/movie/' in hhEH1rcSP0z6Bkqy8OD or '/episode' in hhEH1rcSP0z6Bkqy8OD:
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD.rstrip('/'),223,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		else:
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,221,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	if len(items)>=16:
		YfoAFq6cZNPl = ['/movies','/tv','/search','/trending']
		sbNukjOf4chz = int(sbNukjOf4chz)
		if any(value in url for value in YfoAFq6cZNPl):
			for NNSq6gCGnKv in range(0,1000,100):
				if int(sbNukjOf4chz/100)*100==NNSq6gCGnKv:
					for kkLhJCU4MQSx7s6gyeOHrRYKtnP3 in range(NNSq6gCGnKv,NNSq6gCGnKv+100,10):
						if int(sbNukjOf4chz/10)*10==kkLhJCU4MQSx7s6gyeOHrRYKtnP3:
							for baRB6e0DNoXZswMqYVfzL857W in range(kkLhJCU4MQSx7s6gyeOHrRYKtnP3,kkLhJCU4MQSx7s6gyeOHrRYKtnP3+10,1):
								if not sbNukjOf4chz==baRB6e0DNoXZswMqYVfzL857W and baRB6e0DNoXZswMqYVfzL857W!=0:
									mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+str(baRB6e0DNoXZswMqYVfzL857W),url,221,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(baRB6e0DNoXZswMqYVfzL857W))
						elif kkLhJCU4MQSx7s6gyeOHrRYKtnP3!=0: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+str(kkLhJCU4MQSx7s6gyeOHrRYKtnP3),url,221,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(kkLhJCU4MQSx7s6gyeOHrRYKtnP3))
						else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+str(1),url,221,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(1))
				elif NNSq6gCGnKv!=0: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+str(NNSq6gCGnKv),url,221,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(NNSq6gCGnKv))
				else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'صفحة '+str(1),url,221)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	Eu8LWnSt3fyJzIC,j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL = [],[]
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-PLAY-1st')
	bxiMUQmPRvu = jj0dZrgiKb.findall('<td>التصنيف</td>.*?">(.*?)<',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if bxiMUQmPRvu and BBXMogDz3d(UdbRGoKhcDeI4lVfns5,url,bxiMUQmPRvu): return
	rkwBQ0MDtLKWa,PIaBHUc2CAvig5tTyfL6qGd4u3jN = wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5
	YYhPwcDmOZgM,a9meuCIMnz = II64TLxj3mbqEyh9pHQ8oAv,II64TLxj3mbqEyh9pHQ8oAv
	X7rvEiJtaIucBLd6 = jj0dZrgiKb.findall('show_dl api" href="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if X7rvEiJtaIucBLd6:
		for hhEH1rcSP0z6Bkqy8OD in X7rvEiJtaIucBLd6:
			if '/watch/' in hhEH1rcSP0z6Bkqy8OD: rkwBQ0MDtLKWa = hhEH1rcSP0z6Bkqy8OD
			elif '/download/' in hhEH1rcSP0z6Bkqy8OD: PIaBHUc2CAvig5tTyfL6qGd4u3jN = hhEH1rcSP0z6Bkqy8OD
		if rkwBQ0MDtLKWa!=wUvcPrYDfISbZolAm83GKEqMyXkn5: YYhPwcDmOZgM = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,rkwBQ0MDtLKWa,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-PLAY-2nd')
		if PIaBHUc2CAvig5tTyfL6qGd4u3jN!=wUvcPrYDfISbZolAm83GKEqMyXkn5: a9meuCIMnz = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,PIaBHUc2CAvig5tTyfL6qGd4u3jN,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-PLAY-3rd')
	sOIVqtd7fGP9c2M0lXhNRZ = jj0dZrgiKb.findall('id="video".*?data-src="(.*?)"',YYhPwcDmOZgM,jj0dZrgiKb.DOTALL)
	if sOIVqtd7fGP9c2M0lXhNRZ:
		ZD5n0eJivzWOMxY98dgrumkwRG = sOIVqtd7fGP9c2M0lXhNRZ[0]
		if ZD5n0eJivzWOMxY98dgrumkwRG!=wUvcPrYDfISbZolAm83GKEqMyXkn5 and 'uploaded.egybest.download' in ZD5n0eJivzWOMxY98dgrumkwRG and '/?id=_' not in ZD5n0eJivzWOMxY98dgrumkwRG:
			xnGN2vER8iQqJkcFt4KWup = KhrsqbGoiyLzXR3Et(sBTeylAtiQXpFW9wjM5C1m,ZD5n0eJivzWOMxY98dgrumkwRG,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-PLAY-4th')
			xxIDROgXZhHuMFpe4Ctf1QlPrdn = jj0dZrgiKb.findall('source src="(.*?)" title="(.*?)"',xnGN2vER8iQqJkcFt4KWup,jj0dZrgiKb.DOTALL)
			if xxIDROgXZhHuMFpe4Ctf1QlPrdn:
				for hhEH1rcSP0z6Bkqy8OD,KwSdzRXT0M3VW in xxIDROgXZhHuMFpe4Ctf1QlPrdn:
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD+'?named=ed.egybest.do__watch__mp4__'+KwSdzRXT0M3VW)
			else:
				xG6n4Wq2Ib7YgpiarHUNLQJM0 = ZD5n0eJivzWOMxY98dgrumkwRG.split('/')[2]
				j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(ZD5n0eJivzWOMxY98dgrumkwRG+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__watch')
		elif ZD5n0eJivzWOMxY98dgrumkwRG!=wUvcPrYDfISbZolAm83GKEqMyXkn5:
			xG6n4Wq2Ib7YgpiarHUNLQJM0 = ZD5n0eJivzWOMxY98dgrumkwRG.split('/')[2]
			j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(ZD5n0eJivzWOMxY98dgrumkwRG+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__watch')
	Cidz7Hb3jkID4Tc2QV1r = jj0dZrgiKb.findall('<table class="dls_table(.*?)</table>',a9meuCIMnz,jj0dZrgiKb.DOTALL)
	if Cidz7Hb3jkID4Tc2QV1r:
		Cidz7Hb3jkID4Tc2QV1r = Cidz7Hb3jkID4Tc2QV1r[0]
		XzG4rhjVFZDU6ibn0l283cpa = jj0dZrgiKb.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',Cidz7Hb3jkID4Tc2QV1r,jj0dZrgiKb.DOTALL)
		if XzG4rhjVFZDU6ibn0l283cpa:
			for KwSdzRXT0M3VW,hhEH1rcSP0z6Bkqy8OD in XzG4rhjVFZDU6ibn0l283cpa:
				if 'myegyvip' not in hhEH1rcSP0z6Bkqy8OD: continue
				if hhEH1rcSP0z6Bkqy8OD.count('/')>=2:
					xG6n4Wq2Ib7YgpiarHUNLQJM0 = hhEH1rcSP0z6Bkqy8OD.split('/')[2]
					j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL.append(hhEH1rcSP0z6Bkqy8OD+'?named='+xG6n4Wq2Ib7YgpiarHUNLQJM0+'__download__mp4__'+KwSdzRXT0M3VW)
	KCN5dJHLyWQ7vpc1btgsEwfYi2e = []
	for hhEH1rcSP0z6Bkqy8OD in j4SbRmpU6HBVn1NEtuK0D8YkFz9cWL:
		KCN5dJHLyWQ7vpc1btgsEwfYi2e.append(hhEH1rcSP0z6Bkqy8OD)
	import oo6FYcUjud
	oo6FYcUjud.cHrt1OASYbxJpzEN3KLRWjGFy(KCN5dJHLyWQ7vpc1btgsEwfYi2e,UdbRGoKhcDeI4lVfns5,'video',url)
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	LBqdVs9ioWwpMbCm1A = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	II64TLxj3mbqEyh9pHQ8oAv = KhrsqbGoiyLzXR3Et(D0tF2C71Kej5zrAgB6uMJZsI,hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'EGYBESTVIP-SEARCH-1st')
	wkKMJqu0VaeWm = jj0dZrgiKb.findall('name="_token" value="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if wkKMJqu0VaeWm:
		url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search?_token='+wkKMJqu0VaeWm[0]+'&q='+LBqdVs9ioWwpMbCm1A
		HPdaS7kenW0m(url)
	return