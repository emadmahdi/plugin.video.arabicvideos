# -*- coding: utf-8 -*-
from zpCIRgy3H2 import *
UdbRGoKhcDeI4lVfns5 = 'SHIAVOICE'
UT69hgqoKsWNIwM5zkAYb = '_SHV_'
hhD7r1VvaPt3TC06SJjqKRfEid = TTuO14NzmB.SITESURLS[UdbRGoKhcDeI4lVfns5][0]
headers = {'User-Agent':None}
def DDIqhZaAit8Ed9(mode,url,text):
	if   mode==310: RCmHBOKtejQ8lu4L = x6zs7UWPvmuecZOHqtgAVnbwCE()
	elif mode==311: RCmHBOKtejQ8lu4L = HPdaS7kenW0m(url)
	elif mode==312: RCmHBOKtejQ8lu4L = lHcaGxFV0wy9UrN7Cv6o5dInLQ(url)
	elif mode==313: RCmHBOKtejQ8lu4L = VAKic9ulHo0TwDWZvp6OtFX(url)
	elif mode==314: RCmHBOKtejQ8lu4L = FEkrl38NI7HGMiB9uCye1hjJU(text)
	elif mode==319: RCmHBOKtejQ8lu4L = LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(text)
	else: RCmHBOKtejQ8lu4L = False
	return RCmHBOKtejQ8lu4L
def x6zs7UWPvmuecZOHqtgAVnbwCE():
	mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+'بحث في الموقع',wUvcPrYDfISbZolAm83GKEqMyXkn5,319,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'_REMEMBERRESULTS_')
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(sBTeylAtiQXpFW9wjM5C1m,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-MENU-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('id="menulinks"(.*?)</ul>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	items = jj0dZrgiKb.findall('<h5>(.*?)</h5>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL|jj0dZrgiKb.IGNORECASE)
	for xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in range(len(items)):
		title = items[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4].strip(UKFZBQAVXHI5s17LyvuRpCY2)
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhD7r1VvaPt3TC06SJjqKRfEid,314,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,str(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4+1))
	mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+'مقاطع شهر',hhD7r1VvaPt3TC06SJjqKRfEid,314,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'0')
	mwOxEyYAg63B('link',JegF7SlMawI03+' ===== ===== ===== '+AAByQSLgaZwCsKnvc5eWNmY,wUvcPrYDfISbZolAm83GKEqMyXkn5,9999)
	items = jj0dZrgiKb.findall('href="(.*?)".*?<B>(.*?)</B>',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
		mwOxEyYAg63B('folder',UdbRGoKhcDeI4lVfns5+'_SCRIPT_'+UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,311)
	return II64TLxj3mbqEyh9pHQ8oAv
def FEkrl38NI7HGMiB9uCye1hjJU(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',hhD7r1VvaPt3TC06SJjqKRfEid,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-LATEST-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	if xJAIOQKvfpEH5Mn0Z1yUBqVCWY4=='0':
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="tab-content"(.*?)</table>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		items = jj0dZrgiKb.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,name,title in items:
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			title = title+' ('+name+')'
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312)
	elif xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in ['1','2','3']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(<h5>.*?)<div class="col-lg',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		kLrNfiDKyxBT7 = int(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)-1
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[kLrNfiDKyxBT7]
		if xJAIOQKvfpEH5Mn0Z1yUBqVCWY4=='1': items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		else: items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title,name in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			title = title+' ('+name+')'
			mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,311,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	elif xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 in ['4','5','6']:
		pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('(<h5>.*?)</table>',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
		xJAIOQKvfpEH5Mn0Z1yUBqVCWY4 = int(xJAIOQKvfpEH5Mn0Z1yUBqVCWY4)-4
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[xJAIOQKvfpEH5Mn0Z1yUBqVCWY4]
		items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,hhX9f8bY1aIRxnWpvKlNquUVZ,title,QSuoms9tfxPZwgEea in items:
			cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			hhX9f8bY1aIRxnWpvKlNquUVZ = hhX9f8bY1aIRxnWpvKlNquUVZ.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			QSuoms9tfxPZwgEea = QSuoms9tfxPZwgEea.strip(UKFZBQAVXHI5s17LyvuRpCY2)
			if hhX9f8bY1aIRxnWpvKlNquUVZ: name = hhX9f8bY1aIRxnWpvKlNquUVZ
			else: name = QSuoms9tfxPZwgEea
			title = title+' ('+name+')'
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	return
def HPdaS7kenW0m(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-TITLES-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('ibox-heading"(.*?)class="float-right',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	if 'catsum-mobile' in IJE2xcV7OWauUKhfik56gXBwltCb:
		items = jj0dZrgiKb.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		if items:
			for cPzpeLXs3jMCltW4ZN9BaYdfQvwS,hhEH1rcSP0z6Bkqy8OD,title,count in items:
				cPzpeLXs3jMCltW4ZN9BaYdfQvwS = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+cPzpeLXs3jMCltW4ZN9BaYdfQvwS
				hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
				count = count.replace(' الصوتية: ',':')
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				title = title+' ('+count+')'
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,311,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
	else:
		items = jj0dZrgiKb.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
		for hhEH1rcSP0z6Bkqy8OD,title,tow32OaLZPXpCMJ6TNR5147c0,KS5UPc7G4x38Lp in items:
			if title==wUvcPrYDfISbZolAm83GKEqMyXkn5 or tow32OaLZPXpCMJ6TNR5147c0==wUvcPrYDfISbZolAm83GKEqMyXkn5: continue
			hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
			title = title+' ('+KS5UPc7G4x38Lp+')'
			mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312)
	if not items: mCwqRg7HpivAQ6S(II64TLxj3mbqEyh9pHQ8oAv)
	return
def mCwqRg7HpivAQ6S(II64TLxj3mbqEyh9pHQ8oAv):
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="ibox-content"(.*?)class="pagination',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title,name,count,KS5UPc7G4x38Lp in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		title = title+' ('+name+')'
		mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312,wUvcPrYDfISbZolAm83GKEqMyXkn5,KS5UPc7G4x38Lp)
	return
def VAKic9ulHo0TwDWZvp6OtFX(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-SEARCH_ITEMS-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="ibox-content p-1"(.*?)class="ibox-content"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not pLHIPUY3TWAeE70:
		HPdaS7kenW0m(url)
		return
	IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
	items = jj0dZrgiKb.findall('href="(.*?)".*?<strong>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
	for hhEH1rcSP0z6Bkqy8OD,title in items:
		hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+'/'+hhEH1rcSP0z6Bkqy8OD
		title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
		if '/play-' in hhEH1rcSP0z6Bkqy8OD: mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312)
		else: mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,311)
	return
def lHcaGxFV0wy9UrN7Cv6o5dInLQ(url):
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(D0tF2C71Kej5zrAgB6uMJZsI,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-PLAY-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('<audio.*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if not hhEH1rcSP0z6Bkqy8OD: hhEH1rcSP0z6Bkqy8OD = jj0dZrgiKb.findall('<video.*?src="(.*?)"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	hhEH1rcSP0z6Bkqy8OD = hhD7r1VvaPt3TC06SJjqKRfEid+hhEH1rcSP0z6Bkqy8OD[0]
	yyYuosJmc3QDUGSA(hhEH1rcSP0z6Bkqy8OD,UdbRGoKhcDeI4lVfns5,'video')
	return
def LLQjDdwuU7ZJlMOrFXRS2pif9yB5Kx(search):
	search,plQAPdho26aj,showDialogs = PLaXN4KSfzcmyu3(search)
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: search = BPqorNHKYQ7Lv5WTpcgXzld3kSwnA()
	if search==wUvcPrYDfISbZolAm83GKEqMyXkn5: return
	search = search.replace(UKFZBQAVXHI5s17LyvuRpCY2,'+')
	E4eSuONpMdz = ['&t=a','&t=c','&t=s']
	if showDialogs:
		OS1m8LEAYzNwnd9qBkMhRoTr7QyK = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		EcQws7L35GvtIpl0k1gJZWTNPDbmMq = ceaYWmBtFEoCgTZiVHqXQ04L1IkvPj('موقع صوت الشيعة - أختر البحث', OS1m8LEAYzNwnd9qBkMhRoTr7QyK)
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq == -1: return
	elif '_SHIAVOICE-PERSONS_' in plQAPdho26aj: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 0
	elif '_SHIAVOICE-ALBUMS_' in plQAPdho26aj: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 1
	elif '_SHIAVOICE-AUDIOS_' in plQAPdho26aj: EcQws7L35GvtIpl0k1gJZWTNPDbmMq = 2
	else: return
	type = E4eSuONpMdz[EcQws7L35GvtIpl0k1gJZWTNPDbmMq]
	url = hhD7r1VvaPt3TC06SJjqKRfEid+'/search.php?q='+search+type
	QM9sJ7tk0oplqEwHU3DjL64d = umVATL4QpG1RxtrvX7bNS2cYoB(d2priEnu57KztRsm8wCHZ,'GET',url,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,wUvcPrYDfISbZolAm83GKEqMyXkn5,'SHIAVOICE-SEARCH-1st')
	II64TLxj3mbqEyh9pHQ8oAv = QM9sJ7tk0oplqEwHU3DjL64d.content
	pLHIPUY3TWAeE70 = jj0dZrgiKb.findall('class="ibox-content"(.*?)class="ibox-content"',II64TLxj3mbqEyh9pHQ8oAv,jj0dZrgiKb.DOTALL)
	if pLHIPUY3TWAeE70:
		IJE2xcV7OWauUKhfik56gXBwltCb = pLHIPUY3TWAeE70[0]
		if EcQws7L35GvtIpl0k1gJZWTNPDbmMq in [0,1]:
			items = jj0dZrgiKb.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,cPzpeLXs3jMCltW4ZN9BaYdfQvwS,title,name in items:
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				title = title+' ('+name+')'
				mwOxEyYAg63B('folder',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,313,cPzpeLXs3jMCltW4ZN9BaYdfQvwS)
		elif EcQws7L35GvtIpl0k1gJZWTNPDbmMq==2:
			items = jj0dZrgiKb.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',IJE2xcV7OWauUKhfik56gXBwltCb,jj0dZrgiKb.DOTALL)
			for hhEH1rcSP0z6Bkqy8OD,title,name in items:
				title = title.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				name = name.strip(UKFZBQAVXHI5s17LyvuRpCY2)
				title = title+' ('+name+')'
				mwOxEyYAg63B('video',UT69hgqoKsWNIwM5zkAYb+title,hhEH1rcSP0z6Bkqy8OD,312)
	return