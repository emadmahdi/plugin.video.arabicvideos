# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'DAILYMOTION'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_DLM_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
paGcF7RvtOxsUKiVX0rmMLdhjol4 = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][1]
SKEDPtFf0am9wNuT5hWl = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][2]
def WdRmv9kTtLnfZ24(mode,url,text,type,Q8A5HyT1fGNxZv4X3V7eC):
	if	 mode==400: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==401: lfZmugQCFKLGT05AH29IsMiho = y20Nb75aFd6GuzwnO9kcJYqRSZ(url,text)
	elif mode==402: lfZmugQCFKLGT05AH29IsMiho = hsS3EgAtbGPTOdLlmKZcJ8(url,text)
	elif mode==403: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url,text)
	elif mode==404: lfZmugQCFKLGT05AH29IsMiho = DEC3QfmjRwX(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==405: lfZmugQCFKLGT05AH29IsMiho = EL9scOiM0a(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==406: lfZmugQCFKLGT05AH29IsMiho = tZ4zDOlV3ueroTw2E1(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==407: lfZmugQCFKLGT05AH29IsMiho = uj8dIsBfAC3NDpqRtgbiQyOor9(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==408: lfZmugQCFKLGT05AH29IsMiho = U5AuQdtwPJjxZ2oT8X61zeYEsHipf(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==409: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==411: lfZmugQCFKLGT05AH29IsMiho = sT5QtBHWfmMhZiIA6Eo4(url,text)
	elif mode==414: lfZmugQCFKLGT05AH29IsMiho = sEQrXWiMY4F8w(text)
	elif mode==415: lfZmugQCFKLGT05AH29IsMiho = B0qwGpviSKxmnzIyCtjR6U95X2E1l(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==416: lfZmugQCFKLGT05AH29IsMiho = MmvjbT7wQ0iaB94YGhPuDJdp5kUFfg(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==417: lfZmugQCFKLGT05AH29IsMiho = Jsw6FMVDNGBPIqu9eo5WT32(url,Q8A5HyT1fGNxZv4X3V7eC)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الرئيسية',SebHIf2jL1TBgrMKJu,414)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن فيديوهات',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'videos?sortBy=','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن آخر الفيديوهات',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن الفيديوهات الأكثر مشاهدة',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن قوائم التشغيل',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'playlists','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن مستخدم',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'channels','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن بث حي',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'lives','_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن هاشتاك',SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,'hashtags','_REMEMBERRESULTS_')
	return
def hsS3EgAtbGPTOdLlmKZcJ8(url,p4eaQhLns5):
	if '/dm_' in url:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,False,SebHIf2jL1TBgrMKJu,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = Bc5IUelt4sWvMXTdy.headers
		if 'Location' in list(headers.keys()): url = j1IFsik4ouNePZr+headers['Location']
	p4eaQhLns5 = E7r8hUCVvTiFQW0dBGXjxcy+p4eaQhLns5+XOVRfitWJP1zL3p2CMYF
	p4eaQhLns5 = ZvUTXs1mktA(p4eaQhLns5)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: بث حي',url,411,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'channel_lives_now')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: آخر الفيديوهات',url+'/videos',408)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: المميزة',url,411,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'channel_featured_videos')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: قوائم التشغيل',url+'/playlists',407)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: قنوات ذات صلة',url,411,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'channel_related_channel')
	return
def ZvUTXs1mktA(title):
	title = title.rstrip('\\').strip(qE4nB3mKWHs).replace('\\\\','\\')
	title = a549mfV8gnzXpwlFr(title)
	return title
def rRCw3hfy2Kq5l(url,ICdePB60NZQxnFSaAylmciEUH):
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ([url],tfX4sO3hy2H1IbKG,'video',url)
	return
def DEC3QfmjRwX(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = SebHIf2jL1TBgrMKJu
	search = search.split('/videos')[0]
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	if sort==SebHIf2jL1TBgrMKJu: pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysortmethod',SebHIf2jL1TBgrMKJu)
	else: pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = j1IFsik4ouNePZr+'/search/'+search+'/videos'
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"videos"(.*?)"VideoConnection"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,title,UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5,lEeAaSobjWc,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+id
			title = ZvUTXs1mktA(title)
			ICdePB60NZQxnFSaAylmciEUH = UyHsqGeaC5izr0ToDnRXb6NA1f4+'::'+p4eaQhLns5
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,ICdePB60NZQxnFSaAylmciEUH)
		if '"hasNextPage":true' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,404,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def EL9scOiM0a(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	url = j1IFsik4ouNePZr+'/search/'+search+'/playlists'
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for id,name,J2pZKfGyx1OM9,UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count in items:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = ZvUTXs1mktA(title)
		ICdePB60NZQxnFSaAylmciEUH = UyHsqGeaC5izr0ToDnRXb6NA1f4+'::'+p4eaQhLns5
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,401,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,ICdePB60NZQxnFSaAylmciEUH)
	if '"hasNextPage":true' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,405,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def tZ4zDOlV3ueroTw2E1(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	url = j1IFsik4ouNePZr+'/search/'+search+'/channels'
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"channels"(.*?)"ChannelConnection"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,name,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+id
			title = 'USER:  '+name
			title = ZvUTXs1mktA(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,402,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,name)
		if '"hasNextPage":true' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,406,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def sEQrXWiMY4F8w(Ulh8poeWS2XDHP6Y0KBgLi1):
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['home']['neon']['sections']['edges']
		if not Ulh8poeWS2XDHP6Y0KBgLi1:
			kN4ZQWL5xO = []
			for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
				wOp3mS2saByx1 = Vt4GYUDZbN3gz1['node']['title']
				if wOp3mS2saByx1 not in kN4ZQWL5xO: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+wOp3mS2saByx1,SebHIf2jL1TBgrMKJu,414,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,wOp3mS2saByx1)
				kN4ZQWL5xO.append(wOp3mS2saByx1)
		else:
			for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
				wOp3mS2saByx1 = Vt4GYUDZbN3gz1['node']['title']
				if wOp3mS2saByx1==Ulh8poeWS2XDHP6Y0KBgLi1:
					ZZlCd1JkTe = Vt4GYUDZbN3gz1['node']['components']['edges']
					for NNf1rMiPgK0AIWHsdoDJxZj3BbtC in ZZlCd1JkTe:
						lEeAaSobjWc = str(NNf1rMiPgK0AIWHsdoDJxZj3BbtC['node']['duration'])
						title = a549mfV8gnzXpwlFr(NNf1rMiPgK0AIWHsdoDJxZj3BbtC['node']['title'])
						title = title.replace('\/','/')
						bieV3FGhU7kgY9vqpIKtxnL5 = NNf1rMiPgK0AIWHsdoDJxZj3BbtC['node']['xid']
						tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = NNf1rMiPgK0AIWHsdoDJxZj3BbtC['node']['thumbnailx480']
						tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
						cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+bieV3FGhU7kgY9vqpIKtxnL5
						QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
	return
def B0qwGpviSKxmnzIyCtjR6U95X2E1l(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	url = j1IFsik4ouNePZr+'/search/'+search+'/lives'
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		try: PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['search']['lives']['edges']
		except: PPDA7XsQHiw6 = []
		for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
			name = Vt4GYUDZbN3gz1['node']['title']
			name = a549mfV8gnzXpwlFr(name)
			bieV3FGhU7kgY9vqpIKtxnL5 = Vt4GYUDZbN3gz1['node']['xid']
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+bieV3FGhU7kgY9vqpIKtxnL5
			QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'LIVE: '+name,cOn6JqZlmQbjtT,403)
		if '"hasNextPage":true' in PC1spMeyAUmWKluc7Sahod4YVQIw:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,415,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def I7XAMyNvEnm4kspKGrShwYfB5dJRH0(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	url = j1IFsik4ouNePZr+'/search/'+search+'/topics'
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		try: PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['search']['topics']['edges']
		except: PPDA7XsQHiw6 = []
		for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
			name = Vt4GYUDZbN3gz1['node']['name']
			bieV3FGhU7kgY9vqpIKtxnL5 = Vt4GYUDZbN3gz1['node']['xid']
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/topic/'+bieV3FGhU7kgY9vqpIKtxnL5
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'TOPIC: '+name,cOn6JqZlmQbjtT,413)
		if '"hasNextPage":true' in PC1spMeyAUmWKluc7Sahod4YVQIw:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,412,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def xXm2NMulyqJpZn(url,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	bieV3FGhU7kgY9vqpIKtxnL5 = url.split('/')[-1]
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mytopicid',bieV3FGhU7kgY9vqpIKtxnL5)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['topic']['videos']['edges']
		for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
			lEeAaSobjWc = str(Vt4GYUDZbN3gz1['node']['duration'])
			title = a549mfV8gnzXpwlFr(Vt4GYUDZbN3gz1['node']['title'])
			title = title.replace('\/','/')
			bieV3FGhU7kgY9vqpIKtxnL5 = Vt4GYUDZbN3gz1['node']['xid']
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = Vt4GYUDZbN3gz1['node']['thumbnailx480']
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+bieV3FGhU7kgY9vqpIKtxnL5
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
		if '"hasNextPage":true' in PC1spMeyAUmWKluc7Sahod4YVQIw:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,413,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC)
	return
def y20Nb75aFd6GuzwnO9kcJYqRSZ(url,ICdePB60NZQxnFSaAylmciEUH):
	id = url.split('/')[-1]
	UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5 = ICdePB60NZQxnFSaAylmciEUH.split('::',1)
	cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+UyHsqGeaC5izr0ToDnRXb6NA1f4
	p4eaQhLns5 = ZvUTXs1mktA(p4eaQhLns5)
	title = E7r8hUCVvTiFQW0dBGXjxcy+'OWNER:  '+p4eaQhLns5+XOVRfitWJP1zL3p2CMYF
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,402,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,p4eaQhLns5)
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('myplaylistid',id)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"collection_videos"(.*?)"SectionEdge"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,title,lEeAaSobjWc,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5 in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+id
			title = ZvUTXs1mktA(title)
			ICdePB60NZQxnFSaAylmciEUH = UyHsqGeaC5izr0ToDnRXb6NA1f4+'::'+p4eaQhLns5
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,ICdePB60NZQxnFSaAylmciEUH)
	return
def U5AuQdtwPJjxZ2oT8X61zeYEsHipf(url,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	byFGvxhKuI9HU7ceAaMr3N4 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mychannelid',byFGvxhKuI9HU7ceAaMr3N4)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysortmethod',sort)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,title,lEeAaSobjWc,UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+id
			title = ZvUTXs1mktA(title)
			ICdePB60NZQxnFSaAylmciEUH = UyHsqGeaC5izr0ToDnRXb6NA1f4+'::'+p4eaQhLns5
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,ICdePB60NZQxnFSaAylmciEUH)
		if '"hasNextPage":true' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,408,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC)
	return
def uj8dIsBfAC3NDpqRtgbiQyOor9(url,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	byFGvxhKuI9HU7ceAaMr3N4 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mychannelid',byFGvxhKuI9HU7ceAaMr3N4)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysortmethod',sort)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,name,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count,J2pZKfGyx1OM9,UyHsqGeaC5izr0ToDnRXb6NA1f4,p4eaQhLns5 in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = ZvUTXs1mktA(title)
			ICdePB60NZQxnFSaAylmciEUH = UyHsqGeaC5izr0ToDnRXb6NA1f4+'::'+p4eaQhLns5
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,401,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,ICdePB60NZQxnFSaAylmciEUH)
		if '"hasNextPage":true' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,407,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC)
	return
def sT5QtBHWfmMhZiIA6Eo4(url,ZjKNuqw0a8):
	byFGvxhKuI9HU7ceAaMr3N4 = url.split('/')[3]
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mychannelid',byFGvxhKuI9HU7ceAaMr3N4)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	qBSk8jvUxpCf5AEXL0wPdM = ddWZPUnz9Cljm.loads(LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	try: items = qBSk8jvUxpCf5AEXL0wPdM['data']['channel'][ZjKNuqw0a8]['edges']
	except: items = []
	if not items: QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'لا توجد نتائج',SebHIf2jL1TBgrMKJu,9999)
	else:
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			pp20s8ZV3SgqGf5Nk = JJSOAkTZIib4eswDo51pFuqvK['node']
			bieV3FGhU7kgY9vqpIKtxnL5 = pp20s8ZV3SgqGf5Nk['xid']
			keys = list(pp20s8ZV3SgqGf5Nk.keys())
			YBlmbIANkXn9WMSvCahGTr = pp20s8ZV3SgqGf5Nk['__typename'].lower()
			if YBlmbIANkXn9WMSvCahGTr=='channel':
				name = pp20s8ZV3SgqGf5Nk['name']
				gmO4sLCFTbB3 = pp20s8ZV3SgqGf5Nk['displayName']
				title = 'USER:  '+gmO4sLCFTbB3
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = pp20s8ZV3SgqGf5Nk['coverURLx375']
			else:
				name = pp20s8ZV3SgqGf5Nk['channel']['name']
				gmO4sLCFTbB3 = pp20s8ZV3SgqGf5Nk['channel']['displayName']
				title = pp20s8ZV3SgqGf5Nk['title']
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = pp20s8ZV3SgqGf5Nk['thumbnailx360']
				if YBlmbIANkXn9WMSvCahGTr=='live': title = 'LIVE:  '+title
			title = ZvUTXs1mktA(title)
			ICdePB60NZQxnFSaAylmciEUH = name+'::'+gmO4sLCFTbB3
			if psS8dmb912iRBgGc7qOPyCZ6:
				title = title.encode(Tv08xsf9HOqunIVUPdK1)
				ICdePB60NZQxnFSaAylmciEUH = ICdePB60NZQxnFSaAylmciEUH.encode(Tv08xsf9HOqunIVUPdK1)
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			if YBlmbIANkXn9WMSvCahGTr=='channel':
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+bieV3FGhU7kgY9vqpIKtxnL5
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,402,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,ICdePB60NZQxnFSaAylmciEUH)
			else:
				if YBlmbIANkXn9WMSvCahGTr=='video': lEeAaSobjWc = str(pp20s8ZV3SgqGf5Nk['duration'])
				else: lEeAaSobjWc = SebHIf2jL1TBgrMKJu
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+bieV3FGhU7kgY9vqpIKtxnL5
				QUzFYoapm9jx(YBlmbIANkXn9WMSvCahGTr,FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,ICdePB60NZQxnFSaAylmciEUH)
	return
def MmvjbT7wQ0iaB94YGhPuDJdp5kUFfg(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mysearchwords',search)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagelimit','40')
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	url = j1IFsik4ouNePZr+'/search/'+search+'/hashtags'
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		try: PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['search']['hashtags']['edges']
		except: PPDA7XsQHiw6 = []
		for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
			name = Vt4GYUDZbN3gz1['node']['name']
			name = a549mfV8gnzXpwlFr(name)
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/hashtag/'+name[1:]
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'HSHTG: '+name,cOn6JqZlmQbjtT,417)
		if '"hasNextPage":true' in PC1spMeyAUmWKluc7Sahod4YVQIw:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,416,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,search)
	return
def Jsw6FMVDNGBPIqu9eo5WT32(url,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	name = url.split('/')[-1]
	pbmcw9i1kfuNIQzJ7aGd3l0 = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('myhashtagname',name)
	pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.replace('mypagenumber',Q8A5HyT1fGNxZv4X3V7eC)
	PC1spMeyAUmWKluc7Sahod4YVQIw = tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0)
	if PC1spMeyAUmWKluc7Sahod4YVQIw:
		eF84MrKlobOytXSpzDWhnsBYAjxZ6Q = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',PC1spMeyAUmWKluc7Sahod4YVQIw)
		PPDA7XsQHiw6 = eF84MrKlobOytXSpzDWhnsBYAjxZ6Q['data']['contentFeed']['edges']
		for Vt4GYUDZbN3gz1 in PPDA7XsQHiw6:
			lEeAaSobjWc = str(Vt4GYUDZbN3gz1['node']['post']['duration'])
			title = a549mfV8gnzXpwlFr(Vt4GYUDZbN3gz1['node']['post']['title'])
			title = title.replace('\/','/')
			bieV3FGhU7kgY9vqpIKtxnL5 = Vt4GYUDZbN3gz1['node']['post']['xid']
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = Vt4GYUDZbN3gz1['node']['post']['thumbnailx480']
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/video/'+bieV3FGhU7kgY9vqpIKtxnL5
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,403,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
		if '"hasNextPage":true' in PC1spMeyAUmWKluc7Sahod4YVQIw:
			Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)+1)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+Q8A5HyT1fGNxZv4X3V7eC,url,416,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC)
	return
def tXA3f9DMHLQvuzKImndsiB80e(pbmcw9i1kfuNIQzJ7aGd3l0,search=SebHIf2jL1TBgrMKJu):
	if QBOMjKifEAFD: pbmcw9i1kfuNIQzJ7aGd3l0 = pbmcw9i1kfuNIQzJ7aGd3l0.encode(Tv08xsf9HOqunIVUPdK1)
	y3yvo2SVze = adj210XgOP64zfvwC9NJUAW()
	headers = {"Authorization":y3yvo2SVze,"Origin":j1IFsik4ouNePZr}
	if search:
		VK4jU2G3s1PwkticQYyLoW = SKEDPtFf0am9wNuT5hWl
		headers.update({'Content-Type':'application/json','Referer':j1IFsik4ouNePZr+'/','X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		VK4jU2G3s1PwkticQYyLoW = paGcF7RvtOxsUKiVX0rmMLdhjol4
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',paGcF7RvtOxsUKiVX0rmMLdhjol4,pbmcw9i1kfuNIQzJ7aGd3l0,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'DAILYMOTION-GET_PAGEDATA-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def adj210XgOP64zfvwC9NJUAW():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'DAILYMOTION-GET_AUTHINTICATION-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	gecWnsH7IKM = X2XorVqHjLkWeCchY4u9fSz.findall('apiClientId.*?return"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	gecWnsH7IKM = gecWnsH7IKM[wvkDqmNZlJU52isXo]
	ppO1ZBX2fYVPon87eM = X2XorVqHjLkWeCchY4u9fSz.findall('apiClientSecret.*?return"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	ppO1ZBX2fYVPon87eM = ppO1ZBX2fYVPon87eM[wvkDqmNZlJU52isXo]
	L2LAgowfWvj9l4cD7tFhRP = 'https://graphql.api.dailymotion.com/oauth/token'
	rFcq5TVBDXKWxIbOlQJ = 'client_credentials'
	data = {'client_id':gecWnsH7IKM,'client_secret':ppO1ZBX2fYVPon87eM,'grant_type':rFcq5TVBDXKWxIbOlQJ}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',L2LAgowfWvj9l4cD7tFhRP,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	T8NpsG9g3H2txf1wndRSW = X2XorVqHjLkWeCchY4u9fSz.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	kpcRm9u6qNlGYFrBvSELH2P8MOZjws,J2xLWjwbyvVcTPi1GntKfO9zZMSU5Y = T8NpsG9g3H2txf1wndRSW[0]
	y3yvo2SVze = J2xLWjwbyvVcTPi1GntKfO9zZMSU5Y+" "+kpcRm9u6qNlGYFrBvSELH2P8MOZjws
	return y3yvo2SVze
def yEPLitfHnvAdz0I9SVoC(search,ZZW5QJxjDlBLpGHA=SebHIf2jL1TBgrMKJu):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not ZZW5QJxjDlBLpGHA and showDialogs:
		SCTWwXlV1gJNPh = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('موقع ديلي موشن - اختر البحث',SCTWwXlV1gJNPh)
		if QQea1XbjZDEMhp==-1: return
		elif QQea1XbjZDEMhp==0: ZZW5QJxjDlBLpGHA = 'videos?sortBy='
		elif QQea1XbjZDEMhp==1: ZZW5QJxjDlBLpGHA = 'videos?sortBy=RECENT'
		elif QQea1XbjZDEMhp==2: ZZW5QJxjDlBLpGHA = 'videos?sortBy=VIEW_COUNT'
		elif QQea1XbjZDEMhp==3: ZZW5QJxjDlBLpGHA = 'playlists'
		elif QQea1XbjZDEMhp==4: ZZW5QJxjDlBLpGHA = 'channels'
		elif QQea1XbjZDEMhp==5: ZZW5QJxjDlBLpGHA = 'lives'
		elif QQea1XbjZDEMhp==6: ZZW5QJxjDlBLpGHA = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in ndiZQ7oLFkV1W: ZZW5QJxjDlBLpGHA = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in ndiZQ7oLFkV1W: ZZW5QJxjDlBLpGHA = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in ndiZQ7oLFkV1W: ZZW5QJxjDlBLpGHA = 'channels'
	elif '_DAILYMOTION-LIVES_' in ndiZQ7oLFkV1W: ZZW5QJxjDlBLpGHA = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in ndiZQ7oLFkV1W: ZZW5QJxjDlBLpGHA = 'hashtags'
	elif not ZZW5QJxjDlBLpGHA: ZZW5QJxjDlBLpGHA = 'videos?sortBy='
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	if 'videos' in ZZW5QJxjDlBLpGHA: DEC3QfmjRwX(search+'/'+ZZW5QJxjDlBLpGHA)
	elif 'playlists' in ZZW5QJxjDlBLpGHA: EL9scOiM0a(search)
	elif 'channels' in ZZW5QJxjDlBLpGHA: tZ4zDOlV3ueroTw2E1(search)
	elif 'lives' in ZZW5QJxjDlBLpGHA: B0qwGpviSKxmnzIyCtjR6U95X2E1l(search)
	elif 'hashtags' in ZZW5QJxjDlBLpGHA: MmvjbT7wQ0iaB94YGhPuDJdp5kUFfg(search)
	return