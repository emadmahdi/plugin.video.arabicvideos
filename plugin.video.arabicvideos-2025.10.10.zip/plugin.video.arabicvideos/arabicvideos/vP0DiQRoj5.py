﻿# -*- coding: utf-8 -*-
from RSdDifzoPG import *
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,MJyPBqd6N1iTDKprGbHC4x9VZ):
	if MJyPBqd6N1iTDKprGbHC4x9VZ==SebHIf2jL1TBgrMKJu: return
	if hL9fngBAu7XzOx==1:
		bzm4Erfg2BlnHMyAqR9u = G5OVsSktWRJQu8h4T.getCurrentWindowDialogId()
		jiceYtxZk6gVURuAvsz = G5OVsSktWRJQu8h4T.Window(bzm4Erfg2BlnHMyAqR9u)
		MJyPBqd6N1iTDKprGbHC4x9VZ = rrHKfkJjxnw5gCR4pcGUqb8BXSzdL(MJyPBqd6N1iTDKprGbHC4x9VZ)
		jiceYtxZk6gVURuAvsz.getControl(311).setLabel(MJyPBqd6N1iTDKprGbHC4x9VZ)
	if hL9fngBAu7XzOx==0:
		kpiJl1MHXD5='X'
		if QBOMjKifEAFD: tWRK3QeIVhjGYlmSwbxT6uDvnF = isinstance(MJyPBqd6N1iTDKprGbHC4x9VZ,str)
		else: tWRK3QeIVhjGYlmSwbxT6uDvnF = isinstance(MJyPBqd6N1iTDKprGbHC4x9VZ,unicode)
		if tWRK3QeIVhjGYlmSwbxT6uDvnF==True: kpiJl1MHXD5='U'
		z9EQ4J2StV6s1Fe=str(type(MJyPBqd6N1iTDKprGbHC4x9VZ))+qE4nB3mKWHs+MJyPBqd6N1iTDKprGbHC4x9VZ+qE4nB3mKWHs+kpiJl1MHXD5+qE4nB3mKWHs
		for YHnALfql8hprDu in range(0,len(MJyPBqd6N1iTDKprGbHC4x9VZ),1):
			z9EQ4J2StV6s1Fe += hex(ord(MJyPBqd6N1iTDKprGbHC4x9VZ[YHnALfql8hprDu])).replace('0x',SebHIf2jL1TBgrMKJu)+qE4nB3mKWHs
		MJyPBqd6N1iTDKprGbHC4x9VZ = rrHKfkJjxnw5gCR4pcGUqb8BXSzdL(MJyPBqd6N1iTDKprGbHC4x9VZ)
		kpiJl1MHXD5='X'
		if QBOMjKifEAFD: tWRK3QeIVhjGYlmSwbxT6uDvnF = isinstance(MJyPBqd6N1iTDKprGbHC4x9VZ, str)
		else: tWRK3QeIVhjGYlmSwbxT6uDvnF = isinstance(MJyPBqd6N1iTDKprGbHC4x9VZ, unicode)
		if tWRK3QeIVhjGYlmSwbxT6uDvnF==True: kpiJl1MHXD5='U'
		iRJuKOmfxE1cX5nr=str(type(MJyPBqd6N1iTDKprGbHC4x9VZ))+qE4nB3mKWHs+MJyPBqd6N1iTDKprGbHC4x9VZ+qE4nB3mKWHs+kpiJl1MHXD5+qE4nB3mKWHs
		for YHnALfql8hprDu in range(0,len(MJyPBqd6N1iTDKprGbHC4x9VZ),1):
			iRJuKOmfxE1cX5nr += hex(ord(MJyPBqd6N1iTDKprGbHC4x9VZ[YHnALfql8hprDu])).replace('0x',SebHIf2jL1TBgrMKJu)+qE4nB3mKWHs
	return