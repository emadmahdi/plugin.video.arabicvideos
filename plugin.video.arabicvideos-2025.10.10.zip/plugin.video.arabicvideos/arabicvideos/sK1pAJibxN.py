# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
wvkDqmNZlJU52isXo = sTGtHVyhQ9cJU37zxo2O(u"࠵৤")
nyUIsfd53EGot9vbj0XDeq = Izy1PvclrYx4eSVWn0L5phZbq(u"࠷৥")
JhTts2R43AxkM8bYanKVy = nyUIsfd53EGot9vbj0XDeq+nyUIsfd53EGot9vbj0XDeq
fuCbjVag7vU908J2Yqx5Th = JhTts2R43AxkM8bYanKVy+nyUIsfd53EGot9vbj0XDeq
K7cnfQMS6BPvI4LGmCsRp8bUlJ9 = fuCbjVag7vU908J2Yqx5Th+nyUIsfd53EGot9vbj0XDeq
vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs = K7cnfQMS6BPvI4LGmCsRp8bUlJ9+nyUIsfd53EGot9vbj0XDeq
SebHIf2jL1TBgrMKJu = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࠪए")
qE4nB3mKWHs = VOALf8iYEnMdK0g(u"ࠪࠤࠬऐ")
nlNC2gJDBZMed63TxqphA1vrXm8Hy = qE4nB3mKWHs*JhTts2R43AxkM8bYanKVy
cc07eWdgrbB4xJfVCANFSk = qE4nB3mKWHs*fuCbjVag7vU908J2Yqx5Th
saNjmrfQDGgltv = qE4nB3mKWHs*K7cnfQMS6BPvI4LGmCsRp8bUlJ9
UTvNakRFQC = None
BBX9RAuxnyGZ4WIF2TrhYeom3 = Ns6AJKH7DGpr19Wl5C3nF(u"࡙ࡸࡵࡦਇ")
mrhSYXH2P8bO3eJAa9n = uqLUBHepfM3l6AyIzTJh80a(u"ࡌࡡ࡭ࡵࡨਈ")
HHXhQTUO86ALyZ2JgzbDx907kMvcsp = uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡹࡸࡵࡦࠩऑ")
QxUz8vH0AsPG3OgF = ALwOspNtXxZrz3PEKku(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
BdrZqlitGvEM = czvu7VQCZodkMf(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
cXPe6vn1aUtFzH79WEwVmCBO0db = tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
E7r8hUCVvTiFQW0dBGXjxcy = wPnfgxKZdAv6T10(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
QNR6tCevIGEZKX3rAVsP = zpx2fPNKk6Ms38eD1vcO(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
ABPdDcWgCfUIoNh5J12v = VOALf8iYEnMdK0g(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
sl31OczQjiXJrxTDNG = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
VHMKXt35iIAkdPZEpzWOuFj98SC4 = l7kBpMw5Qn(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
XOVRfitWJP1zL3p2CMYF = VOALf8iYEnMdK0g(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
Tv08xsf9HOqunIVUPdK1 = bcNqYtfET5l92dLGjyZSPe(u"ࠧࡶࡶࡩ࠼ࠬछ")
GOrf6A4JzH7uyLCEIiKVhoQFm = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
B7NYRr4wPgsZzx9kSGAD = C3w6qluao7EzUxJgMGBtV(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
QO1UyS3zvJFIdlCgT0Kx96wLA4a5i = bcNqYtfET5l92dLGjyZSPe(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
QoGw3aixFSvDVcue0lyLHrJd = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
AAThlKoOtk0dz1sBZpPRbiV2vIe = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡋࡒࡓࡑࡕࠫठ")
xm5RwaXzSDh71KvJE3ceMBY = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
u43PVWjh7t9YwI = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧ࡝ࡰࠪढ")
vvm0bR6z8NK5wUg2l9jqrJu = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ࡞ࡵࠫण")
lFEvMxzSH2y7tYR = l7kBpMw5Qn(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
rUXOf6E7gdNecQb4IMlTkwa8K = fp6KV7DlS8QYniUczHdmZChL(u"࠱০")
d3fTgSb8zZExBkiW21a0q = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠱࠰࠸১")
H51HsxQPUVducILaojwRzFnv = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠳࠸২")
Qe02A9DRtqJvzuCFdEgHGYwSVcZMo8 = ALwOspNtXxZrz3PEKku(u"࠶࠴৩")
rSFYNVO4KkHnlLwTpCmPW = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠵࠵৪")
dcENpSQ7KJrTbVDuL = gCkRKGhwcx26v(u"࠶࠸࠰৫")
m7x2zfI5LH39BkU = [
						 DQIrVcKuY6bJv(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,bcNqYtfET5l92dLGjyZSPe(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,wPnfgxKZdAv6T10(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,HCiWF4jV1Q8(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,l7kBpMw5Qn(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,DQIrVcKuY6bJv(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,bcNqYtfET5l92dLGjyZSPe(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,gCkRKGhwcx26v(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
tCbWnseyEhDF3xMuj = m7x2zfI5LH39BkU+[
				 t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,czvu7VQCZodkMf(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,iDhLkZS6XBagNCQfs9tq2(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,zpx2fPNKk6Ms38eD1vcO(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,wPnfgxKZdAv6T10(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,VOALf8iYEnMdK0g(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
BBQX5whPbKgHNRqpnt2oM = [
						 l7kBpMw5Qn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,iDhLkZS6XBagNCQfs9tq2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
wenmP3hMQEXB8gRcIyOH2A7ai = vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
LNTg8tIPV9bh3YOvxGCQoylBzdEJi = [ALwOspNtXxZrz3PEKku(u"ุࠩๅึ࠭े"),iDhLkZS6XBagNCQfs9tq2(u"ࠪวํ๊ࠧै"),HADrRCz9QgU4xudPJIqYb70(u"ࠫะอๆ๋ࠩॉ"),ALwOspNtXxZrz3PEKku(u"ࠬัวๅอࠪॊ"),Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ัศส฼ࠫो"),uqLUBHepfM3l6AyIzTJh80a(u"ࠧฯษ่ืࠬौ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠨีสำ्ุ࠭"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩึหอ฿ࠧॎ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪฯฬ๋ๆࠨॏ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫฯอำฺࠩॐ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬ฿วีำࠪ॑")]
wAlczrKTqLQUD4B = iDhLkZS6XBagNCQfs9tq2(u"࠼࠰৬")
O1HZ23lDNf5YFo0 = DQIrVcKuY6bJv(u"࠶࠱৭")*wAlczrKTqLQUD4B
mQJAf43IqSPa8HBTxRnL = l7kBpMw5Qn(u"࠳࠶৮")*O1HZ23lDNf5YFo0
A4uCoHBr5G2fZjzlTw8EpsxLN = czvu7VQCZodkMf(u"࠵࠳৯")*mQJAf43IqSPa8HBTxRnL
RycFd7wZBiNhJjOPIGKp = wvkDqmNZlJU52isXo
B3vhTYqOtgUCAzPW = iDhLkZS6XBagNCQfs9tq2(u"࠶࠴ৰ")*wAlczrKTqLQUD4B
vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu = JhTts2R43AxkM8bYanKVy*O1HZ23lDNf5YFo0
QfG1xIZ4hpq3ezPXt7VbvglUcB = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠵࠻ৱ")*O1HZ23lDNf5YFo0
iHR47eol8wB3Z = fuCbjVag7vU908J2Yqx5Th*mQJAf43IqSPa8HBTxRnL
CtRZoJqPXV = sTGtHVyhQ9cJU37zxo2O(u"࠸࠶৲")*mQJAf43IqSPa8HBTxRnL
dgvz7toK3Sil1CNUpPOaW58L9uJqY = vMhFypGLHZJbdX4O7oc3W8x(u"࠷࠲৳")*A4uCoHBr5G2fZjzlTw8EpsxLN
jCPlGJAyS97u8ROadFzX = O1HZ23lDNf5YFo0
q0lM2sKjIRuZyLkx = [fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),iDhLkZS6XBagNCQfs9tq2(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),DQIrVcKuY6bJv(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),AGlW9LqKN3Dvo(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
q0lM2sKjIRuZyLkx += [Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),DQIrVcKuY6bJv(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),C3w6qluao7EzUxJgMGBtV(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
nn7lLD1YgJjrZ2cAqStyON = [vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),bcNqYtfET5l92dLGjyZSPe(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),wPnfgxKZdAv6T10(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),bcNqYtfET5l92dLGjyZSPe(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),l7kBpMw5Qn(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
nn7lLD1YgJjrZ2cAqStyON += [HADrRCz9QgU4xudPJIqYb70(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),wPnfgxKZdAv6T10(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),HADrRCz9QgU4xudPJIqYb70(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),HADrRCz9QgU4xudPJIqYb70(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
ttDeRQ3bKpfUIBd6jPFy = [AGlW9LqKN3Dvo(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),HCiWF4jV1Q8(u"ࠫࡋࡕࡓࡕࡃࠪ६"),czvu7VQCZodkMf(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),ALwOspNtXxZrz3PEKku(u"࡙࠭ࡂࡓࡒࡘࠬ८"),bcNqYtfET5l92dLGjyZSPe(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),DQIrVcKuY6bJv(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),TVnqDYzWoM2UfHp0dchJ(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
ttDeRQ3bKpfUIBd6jPFy += [wPnfgxKZdAv6T10(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),HADrRCz9QgU4xudPJIqYb70(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),TVnqDYzWoM2UfHp0dchJ(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),AGlW9LqKN3Dvo(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),bcNqYtfET5l92dLGjyZSPe(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
ttDeRQ3bKpfUIBd6jPFy += [C3w6qluao7EzUxJgMGBtV(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),wPnfgxKZdAv6T10(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),bcNqYtfET5l92dLGjyZSPe(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),sTGtHVyhQ9cJU37zxo2O(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
ttDeRQ3bKpfUIBd6jPFy += [ASkvf27etUK0(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),AGlW9LqKN3Dvo(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),DQIrVcKuY6bJv(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),VOALf8iYEnMdK0g(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),DQIrVcKuY6bJv(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),TVnqDYzWoM2UfHp0dchJ(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
ttDeRQ3bKpfUIBd6jPFy += [DQIrVcKuY6bJv(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),DQIrVcKuY6bJv(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),gCkRKGhwcx26v(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),DQIrVcKuY6bJv(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),iDhLkZS6XBagNCQfs9tq2(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
kJ5eUFqAbxW = [zpx2fPNKk6Ms38eD1vcO(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),zpx2fPNKk6Ms38eD1vcO(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),fp6KV7DlS8QYniUczHdmZChL(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
kJ5eUFqAbxW += [tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),HCiWF4jV1Q8(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),zpx2fPNKk6Ms38eD1vcO(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
bHVThUqlANJkcY9DWLou1i = [ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+q0lM2sKjIRuZyLkx+[AGlW9LqKN3Dvo(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+nn7lLD1YgJjrZ2cAqStyON+[Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+ttDeRQ3bKpfUIBd6jPFy+[bcNqYtfET5l92dLGjyZSPe(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+kJ5eUFqAbxW
vZrolBwqWR = [NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
efTHGrVFWtBps5yQqjR6xc4 = [sTGtHVyhQ9cJU37zxo2O(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),C3w6qluao7EzUxJgMGBtV(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
XXm3WGOfpIdTVR14EjLPlqxoU = [HADrRCz9QgU4xudPJIqYb70(u"ࠩࡐ࠷࡚࠭ঢ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡍࡕ࡚ࡖࠨণ"),TVnqDYzWoM2UfHp0dchJ(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡏࡆࡊࡎࡐࠫথ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
HgQRO0JoeykPaGCT15p9u7Yhwr  = [l7kBpMw5Qn(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),HADrRCz9QgU4xudPJIqYb70(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),VOALf8iYEnMdK0g(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
HgQRO0JoeykPaGCT15p9u7Yhwr += [TVnqDYzWoM2UfHp0dchJ(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),VOALf8iYEnMdK0g(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
HgQRO0JoeykPaGCT15p9u7Yhwr += [ASkvf27etUK0(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),fp6KV7DlS8QYniUczHdmZChL(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
HgQRO0JoeykPaGCT15p9u7Yhwr += [C3w6qluao7EzUxJgMGBtV(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),C3w6qluao7EzUxJgMGBtV(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
HgQRO0JoeykPaGCT15p9u7Yhwr += [AGlW9LqKN3Dvo(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
ZI7EsuNhqglU4pBJcHoRKmnPWfb2 = list(filter(lambda UKDT87NFpZYyLzHhuqrlWJt: UKDT87NFpZYyLzHhuqrlWJt not in HgQRO0JoeykPaGCT15p9u7Yhwr+vZrolBwqWR+efTHGrVFWtBps5yQqjR6xc4+XXm3WGOfpIdTVR14EjLPlqxoU,bHVThUqlANJkcY9DWLou1i))
ehtRkZ2gDKFELmIuOaA = ZI7EsuNhqglU4pBJcHoRKmnPWfb2+XXm3WGOfpIdTVR14EjLPlqxoU
ET1o47LkJSlCjMhAOHVzKNs53i8Gr = ZI7EsuNhqglU4pBJcHoRKmnPWfb2+HgQRO0JoeykPaGCT15p9u7Yhwr
RjqxpwMymsZ7v6cGhLlBn52zi = ET1o47LkJSlCjMhAOHVzKNs53i8Gr+vZrolBwqWR
eJyScsgaRtx3XwFHlDYqNmO7r = ehtRkZ2gDKFELmIuOaA+vZrolBwqWR
WXEwOFmiG9ntb4Kxg7L0MP5 = [l7kBpMw5Qn(u"ࠩࡄࡏࡔࡇࡍࠨষ"),sTGtHVyhQ9cJU37zxo2O(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡎࡌࡉࡍࡏࠪহ"),AGlW9LqKN3Dvo(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),wPnfgxKZdAv6T10(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),bcNqYtfET5l92dLGjyZSPe(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),VOALf8iYEnMdK0g(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),ASkvf27etUK0(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),l7kBpMw5Qn(u"ࠫࡒ࠹ࡕࠨী"),fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡏࡐࡕࡘࠪু"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡂࡐࡍࡕࡅࠬূ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [DQIrVcKuY6bJv(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡤࡏࡆࡍࡡࠪে"),gCkRKGhwcx26v(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),TVnqDYzWoM2UfHp0dchJ(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),HADrRCz9QgU4xudPJIqYb70(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),C3w6qluao7EzUxJgMGBtV(u"ࠫࡤࡓࡕࠨৎ"),HADrRCz9QgU4xudPJIqYb70(u"ࠬࡥࡉࡑࠩ৏"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),ALwOspNtXxZrz3PEKku(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
bIygl6aHxhtGFwZ = [ALwOspNtXxZrz3PEKku(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),czvu7VQCZodkMf(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),C3w6qluao7EzUxJgMGBtV(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),bcNqYtfET5l92dLGjyZSPe(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
YeMym27LE6 = [wvkDqmNZlJU52isXo,VOALf8iYEnMdK0g(u"࠱࠶࠲৴"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠲࠸࠳ਃ"),TVnqDYzWoM2UfHp0dchJ(u"࠵࠼࠶ਆ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠱࠺࠲৻"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠵࠺࠵৾"),bcNqYtfET5l92dLGjyZSPe(u"࠲࠹࠲ਂ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠴࠵࠳ৼ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠷࠹࠶৿"),VOALf8iYEnMdK0g(u"࠵࠳࠳৵"),bcNqYtfET5l92dLGjyZSPe(u"࠸࠴࠵ਅ"),HADrRCz9QgU4xudPJIqYb70(u"࠻࠲࠱৺"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠻࠳࠱ਁ"),czvu7VQCZodkMf(u"࠷࠷࠴৽"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠹࠹࠴਄"),iDhLkZS6XBagNCQfs9tq2(u"࠶࠶࠱࠱৹"),ASkvf27etUK0(u"࠽࠾࠿࠰৸"),czvu7VQCZodkMf(u"࠳࠳࠶࠵৶"),VOALf8iYEnMdK0g(u"࠴࠴࠽࠶৷"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠷࠰࠱਀")]
JXh2G7m5dZiFEj3HMSRB8we = [ALwOspNtXxZrz3PEKku(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),HCiWF4jV1Q8(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),ALwOspNtXxZrz3PEKku(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),gCkRKGhwcx26v(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),wPnfgxKZdAv6T10(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ")]