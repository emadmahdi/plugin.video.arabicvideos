# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'CIMAFANS'
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_CMF_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==90: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==91: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx(url)
	elif mode==92: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==94: lfZmugQCFKLGT05AH29IsMiho = K6W3ZDiCchTvt48oVF9re()
	elif mode==95: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==99: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,99,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المضاف حديثا',SebHIf2jL1TBgrMKJu,94)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الأحدث',j1IFsik4ouNePZr+'/?type=latest',91)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الأعلى تقيماً',j1IFsik4ouNePZr+'/?type=imdb',91)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الأكثر مشاهدة',j1IFsik4ouNePZr+'/?type=view',91)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المثبت',j1IFsik4ouNePZr+'/?type=pin',91)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جديد الأفلام',j1IFsik4ouNePZr+'/?type=newMovies',91)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جديد الحلقات',j1IFsik4ouNePZr+'/?type=newEpisodes',91)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'CIMAFANS-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="mainmenu(.*?)nav',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	jgvMWZhtPlBT = ['افلام للكبار فقط']
	for cOn6JqZlmQbjtT,title in items:
		title = title.strip(qE4nB3mKWHs)
		if not any(value in title for value in jgvMWZhtPlBT):
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,91)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="f-cats"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		title = title.strip(qE4nB3mKWHs)
		if not any(value in title for value in jgvMWZhtPlBT):
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,91)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def JJeq4MVI8NtCWkaOiQLTybrzUx(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMAFANS-ITEMS-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	else:
		headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'CIMAFANS-ITEMS-2nd')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="movies-items(.*?)class="listfoot"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	else: drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	items = X2XorVqHjLkWeCchY4u9fSz.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة [0-9]+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx:
				title = '_MOD_'+Wj39BaH6oEmstx[0]
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,95,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
		elif '/video/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,92,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,91,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<a href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,91)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'CIMAFANS-EPISODES-1st')
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0]
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="episodes-panel(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		name = X2XorVqHjLkWeCchY4u9fSz.findall('itemprop="title">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if name: name = name[1]
		else:
			name = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Label')
			if XOVRfitWJP1zL3p2CMYF in name: name = name.split(XOVRfitWJP1zL3p2CMYF,1)[1]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?name">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name+' - '+title,cOn6JqZlmQbjtT,92,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('class="movietitle"><a href="(.*?)">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if yyfSKmso8APbUwvq3HLXgz0D: cOn6JqZlmQbjtT,title = yyfSKmso8APbUwvq3HLXgz0D[0]
		else: cOn6JqZlmQbjtT,title = url,name
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,92,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os,oZ5N80OrMg4tn37 = [],[]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'CIMAFANS-PLAY-1st')
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('text-shadow: none;">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="links-panel(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?__download'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('nav-tabs"(.*?)video-panel-more',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('id="(.*?)".*?embed src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,cOn6JqZlmQbjtT in items:
			title = 'سيرفر '+id
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-server-src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in items:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
			cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT)
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def K6W3ZDiCchTvt48oVF9re():
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'CIMAFANS-LATEST-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="index-last-movie(.*?)id="index-slider-movie',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if '/video/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,92,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,91,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + '/search.php?t='+search
	JJeq4MVI8NtCWkaOiQLTybrzUx(url)
	return