﻿# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ALMAAREF'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_MRF_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def WdRmv9kTtLnfZ24(mode,url,text,Q8A5HyT1fGNxZv4X3V7eC):
	if   mode==40: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==41: lfZmugQCFKLGT05AH29IsMiho = PZbvLVAspF6rS1xhkm8W()
	elif mode==42: lfZmugQCFKLGT05AH29IsMiho = w1h0ifXNRLyYUFstSvD(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==43: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==44: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(text,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==49: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,49)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'البث الحي لقناة المعارف',SebHIf2jL1TBgrMKJu,41)
	w1h0ifXNRLyYUFstSvD(SebHIf2jL1TBgrMKJu,'1')
	return
def nIezLKAdO4H1jTSEuJXtsxmaC8WN5(ndiZQ7oLFkV1W,kTi9EVqP8mUOGXfv6D):
	search,sort,umU6RZ2DvLlpPFA,kgy9Zm5TCvYHjE3PVQ,l7sSoQUBz4JYHn2Gqej = SebHIf2jL1TBgrMKJu,[],[],[],[]
	fNnuAzFsXhBKCco9JZeVUvd7Ya,E70rBFHDnGRPXMp = lhC3Axj8TQSsRWeu0k(ndiZQ7oLFkV1W)
	for OSEMFXaUVI1eqHhQYmbKPdJAnrk in list(E70rBFHDnGRPXMp.keys()):
		value = E70rBFHDnGRPXMp[OSEMFXaUVI1eqHhQYmbKPdJAnrk]
		if not value: continue
		if   OSEMFXaUVI1eqHhQYmbKPdJAnrk=='sort': sort = [value]
		elif OSEMFXaUVI1eqHhQYmbKPdJAnrk=='series': umU6RZ2DvLlpPFA = [value]
		elif OSEMFXaUVI1eqHhQYmbKPdJAnrk=='search': search = value
		elif OSEMFXaUVI1eqHhQYmbKPdJAnrk=='category': kgy9Zm5TCvYHjE3PVQ = [value]
		elif OSEMFXaUVI1eqHhQYmbKPdJAnrk=='specialist': l7sSoQUBz4JYHn2Gqej = [value]
	BXupmlPQvMIrweKqkG = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":kgy9Zm5TCvYHjE3PVQ,"specialist":l7sSoQUBz4JYHn2Gqej,"series":umU6RZ2DvLlpPFA,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(kTi9EVqP8mUOGXfv6D)}}
	BXupmlPQvMIrweKqkG = ddWZPUnz9Cljm.dumps(BXupmlPQvMIrweKqkG)
	cOn6JqZlmQbjtT = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',cOn6JqZlmQbjtT,BXupmlPQvMIrweKqkG,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	data = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	return data
def w1h0ifXNRLyYUFstSvD(ndiZQ7oLFkV1W,level):
	cuoYjfNMPnmhQgtFE = nIezLKAdO4H1jTSEuJXtsxmaC8WN5(ndiZQ7oLFkV1W,'1')
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = cuoYjfNMPnmhQgtFE['facets']
	if level=='1':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb['video_categories']
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<div(.*?)/div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',JJSOAkTZIib4eswDo51pFuqvK+'<',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if not yyfSKmso8APbUwvq3HLXgz0D: yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('data-value=\\"(.*?)\\">(.*?)<',JJSOAkTZIib4eswDo51pFuqvK+'<',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			kgy9Zm5TCvYHjE3PVQ,title = yyfSKmso8APbUwvq3HLXgz0D[0]
			if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
			if not ndiZQ7oLFkV1W: QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,42,SebHIf2jL1TBgrMKJu,'2','?category='+kgy9Zm5TCvYHjE3PVQ)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,42,SebHIf2jL1TBgrMKJu,'2',ndiZQ7oLFkV1W+'&category='+kgy9Zm5TCvYHjE3PVQ)
	if level=='2':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb['specialist']
		items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for l7sSoQUBz4JYHn2Gqej,title in items:
			if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
			if not l7sSoQUBz4JYHn2Gqej: title = title = 'الجميع'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,42,SebHIf2jL1TBgrMKJu,'3',ndiZQ7oLFkV1W+'&specialist='+l7sSoQUBz4JYHn2Gqej)
	elif level=='3':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb['series']
		items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for umU6RZ2DvLlpPFA,title in items:
			if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
			if not umU6RZ2DvLlpPFA: title = title = 'الجميع'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,42,SebHIf2jL1TBgrMKJu,'4',ndiZQ7oLFkV1W+'&series='+umU6RZ2DvLlpPFA)
	elif level=='4':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb['sort_video']
		items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for sort,title in items:
			if not sort: continue
			if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,44,SebHIf2jL1TBgrMKJu,'1',ndiZQ7oLFkV1W+'&sort='+sort)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(ndiZQ7oLFkV1W,kTi9EVqP8mUOGXfv6D):
	cuoYjfNMPnmhQgtFE = nIezLKAdO4H1jTSEuJXtsxmaC8WN5(ndiZQ7oLFkV1W,kTi9EVqP8mUOGXfv6D)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = cuoYjfNMPnmhQgtFE['template']
	items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,43,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = cuoYjfNMPnmhQgtFE['facets']['pagination']
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-page="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for Q8A5HyT1fGNxZv4X3V7eC,title in items:
		if kTi9EVqP8mUOGXfv6D==Q8A5HyT1fGNxZv4X3V7eC: continue
		if psS8dmb912iRBgGc7qOPyCZ6: title = a549mfV8gnzXpwlFr(title)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,SebHIf2jL1TBgrMKJu,44,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,ndiZQ7oLFkV1W)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMAAREF-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('<video src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('youtube_url.*?(http.*?)&',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qOGEcWZIwex2fK = []
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0].replace('\/','/')
		qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def PZbvLVAspF6rS1xhkm8W():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/البث-المباشر-6',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMAAREF-LIVE-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	url = X2XorVqHjLkWeCchY4u9fSz.findall('data-item=.*?(http.*?)&',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	url = url[0].replace('\/','/')
	nxW9asAySzOt2foFGT4LwmHNl8uZ(url,tfX4sO3hy2H1IbKG,'live')
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	AAcKCurspIkFEDnjU3i = False
	if search==SebHIf2jL1TBgrMKJu:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		AAcKCurspIkFEDnjU3i = True
	if search==SebHIf2jL1TBgrMKJu: return
	if not AAcKCurspIkFEDnjU3i: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA('?search='+search,'1')
	else: w1h0ifXNRLyYUFstSvD('?search='+search,'1')
	return