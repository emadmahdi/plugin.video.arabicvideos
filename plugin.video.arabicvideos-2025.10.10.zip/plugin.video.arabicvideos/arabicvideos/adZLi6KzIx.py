# -*- coding: utf-8 -*-
from RSdDifzoPG import *
import bs4 as YlD2BEyGa5HJAzuNvLt1VejmUF0S
tfX4sO3hy2H1IbKG = 'ELCINEMA'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_ELC_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
headers = {'Referer':j1IFsik4ouNePZr}
jgvMWZhtPlBT = []
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==510: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==511: lfZmugQCFKLGT05AH29IsMiho = zFKfl6eqviJxsYQyAbjPZgR7k(url)
	elif mode==512: lfZmugQCFKLGT05AH29IsMiho = sduaBqF7cj(url)
	elif mode==513: lfZmugQCFKLGT05AH29IsMiho = z8xgYpVRCS0woq4UZ(url)
	elif mode==514: lfZmugQCFKLGT05AH29IsMiho = JJSUHLPVqYCAa(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: lfZmugQCFKLGT05AH29IsMiho = JJSUHLPVqYCAa(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: lfZmugQCFKLGT05AH29IsMiho = I7XKfhoUYL(text)
	elif mode==517: lfZmugQCFKLGT05AH29IsMiho = nnplL0VjC3TRYbtPUqXrHQFka5E4vM(url)
	elif mode==518: lfZmugQCFKLGT05AH29IsMiho = l6l54GtSEfoARIs8XZ3pLWJ(url)
	elif mode==519: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	elif mode==520: lfZmugQCFKLGT05AH29IsMiho = IXPjUYgwEnpKh(url)
	elif mode==521: lfZmugQCFKLGT05AH29IsMiho = JsoWV6Xu0zkBEew7(url)
	elif mode==522: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==523: lfZmugQCFKLGT05AH29IsMiho = xiIDlcrZUn6voRbXwYhmSWAg2ue(text)
	elif mode==524: lfZmugQCFKLGT05AH29IsMiho = pDezkEMdySrQJv7()
	elif mode==525: lfZmugQCFKLGT05AH29IsMiho = xKPWGa0QmlhNu6cRy8ATUnt()
	elif mode==526: lfZmugQCFKLGT05AH29IsMiho = uNXzirIj1OMbmdReB()
	elif mode==527: lfZmugQCFKLGT05AH29IsMiho = ffivRL0nEswxd9JX7ICt()
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث بموسوعة السينما',SebHIf2jL1TBgrMKJu,519)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'موسوعة الأعمال',SebHIf2jL1TBgrMKJu,525)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'موسوعة الأشخاص',SebHIf2jL1TBgrMKJu,526)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'موسوعة المصنفات',SebHIf2jL1TBgrMKJu,527)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'موسوعة المنوعات',SebHIf2jL1TBgrMKJu,524)
	return
def pDezkEMdySrQJv7():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' فيديوهات - خاصة',j1IFsik4ouNePZr+'/video',520)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فيديوهات - أحدث',j1IFsik4ouNePZr+'/video/latest',521)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فيديوهات - أقدم',j1IFsik4ouNePZr+'/video/oldest',521)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فيديوهات - أكثر مشاهدة',j1IFsik4ouNePZr+'/video/views',521)
	return
def xKPWGa0QmlhNu6cRy8ATUnt():
	Fo64BaVLt3JeUGTOrD = j1IFsik4ouNePZr+'/lineup?utf8=%E2%9C%93'
	wzsncSkLWJ2uA0y = Fo64BaVLt3JeUGTOrD+'&type=2&category=1&foreign=false&tag='
	iZa1YhVlDu8ztApKEFL = Fo64BaVLt3JeUGTOrD+'&type=2&category=3&foreign=false&tag='
	NaAhPOmQ8EiFR3yBIL0ZJ = Fo64BaVLt3JeUGTOrD+'&type=2&category=1&foreign=true&tag='
	uXagPZjpWLeiUf4hR301w9SKOYQNb = Fo64BaVLt3JeUGTOrD+'&type=2&category=3&foreign=true&tag='
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات أفلام عربي',wzsncSkLWJ2uA0y,511)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات مسلسلات عربي',iZa1YhVlDu8ztApKEFL,511)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات أفلام اجنبي',NaAhPOmQ8EiFR3yBIL0ZJ,511)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات مسلسلات اجنبي',uXagPZjpWLeiUf4hR301w9SKOYQNb,511)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس أعمال أبجدي',j1IFsik4ouNePZr+'/index/work/alphabet',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس  بلد الإنتاج',j1IFsik4ouNePZr+'/index/work/country',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس اللغة',j1IFsik4ouNePZr+'/index/work/language',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس مصنفات العمل',j1IFsik4ouNePZr+'/index/work/genre',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس سنة الإصدار',j1IFsik4ouNePZr+'/index/work/release_year',517)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مواسم - فلتر محدد',j1IFsik4ouNePZr+'/seasonals',515)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مواسم - فلتر كامل',j1IFsik4ouNePZr+'/seasonals',514)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات - فلتر محدد',j1IFsik4ouNePZr+'/lineup',515)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات - فلتر كامل',j1IFsik4ouNePZr+'/lineup',514)
	return
def ffivRL0nEswxd9JX7ICt():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/lineup',SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = rUexZSI47j2HOLplM5.find('select',attrs={'name':'tag'})
	ndiZQ7oLFkV1W = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('option')
	for OSEMFXaUVI1eqHhQYmbKPdJAnrk in ndiZQ7oLFkV1W:
		value = OSEMFXaUVI1eqHhQYmbKPdJAnrk.get('value')
		if not value: continue
		title = OSEMFXaUVI1eqHhQYmbKPdJAnrk.text
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.encode(Tv08xsf9HOqunIVUPdK1)
			value = value.encode(Tv08xsf9HOqunIVUPdK1)
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',SebHIf2jL1TBgrMKJu)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,511)
	return
def uNXzirIj1OMbmdReB():
	Fo64BaVLt3JeUGTOrD = j1IFsik4ouNePZr+'/lineup?utf8=%E2%9C%93'
	MbB627EAZoDSzr9x5j = Fo64BaVLt3JeUGTOrD+'&type=1&category=&foreign=&tag='
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات أشخاص',MbB627EAZoDSzr9x5j,511)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس أشخاص أبجدي',j1IFsik4ouNePZr+'/index/person/alphabet',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس موطن',j1IFsik4ouNePZr+'/index/person/nationality',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس  تاريخ الميلاد',j1IFsik4ouNePZr+'/index/person/birth_year',517)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فهرس  تاريخ الوفاة',j1IFsik4ouNePZr+'/index/person/death_year',517)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات - فلتر محدد',j1IFsik4ouNePZr+'/lineup',515)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مصنفات - فلتر كامل',j1IFsik4ouNePZr+'/lineup',514)
	return
def zFKfl6eqviJxsYQyAbjPZgR7k(url):
	if '/seasonals' in url: ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = 0
	elif '/lineup' in url: ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = 1
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-LISTS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cuoYjfNMPnmhQgtFE = rUexZSI47j2HOLplM5.find_all(class_='jumbo-theater clearfix')
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		title = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('a')[ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp].text
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('a')[ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp].get('href')
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
		if not cuoYjfNMPnmhQgtFE:
			sduaBqF7cj(cOn6JqZlmQbjtT)
			return
		else:
			title = title.replace('قائمة ',SebHIf2jL1TBgrMKJu)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,512)
	yfYnbslBTKrRvO0Zki(rUexZSI47j2HOLplM5,511)
	return
def yfYnbslBTKrRvO0Zki(rUexZSI47j2HOLplM5,mode):
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = rUexZSI47j2HOLplM5.find(class_='pagination')
	if drRnSgoBtKWjmU5FH4ZCIVhzqNb:
		eaklSdVyqFvZ = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('a')
		jjrly1wx6vRG9qc0LmDOda = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('li')
		PUkIHZsr7L0NajBVlo = list(zip(eaklSdVyqFvZ,jjrly1wx6vRG9qc0LmDOda))
		XM3KUmO1QJxlv84bgFTHsjdNt0kYq = -1
		r8rTQdMpy79wz = len(PUkIHZsr7L0NajBVlo)
		for gH3ueoxVGv8DhOW,R5E7JfPaVUeKNzSTAix in PUkIHZsr7L0NajBVlo:
			XM3KUmO1QJxlv84bgFTHsjdNt0kYq += 1
			R5E7JfPaVUeKNzSTAix = R5E7JfPaVUeKNzSTAix['class']
			if 'unavailable' in R5E7JfPaVUeKNzSTAix or 'current' in R5E7JfPaVUeKNzSTAix: continue
			dxwMtG2cpSBbCVe6HqIfDZn = gH3ueoxVGv8DhOW.text
			Sn3lefFys4XLgp8JiRvV = j1IFsik4ouNePZr+gH3ueoxVGv8DhOW.get('href')
			if psS8dmb912iRBgGc7qOPyCZ6:
				dxwMtG2cpSBbCVe6HqIfDZn = dxwMtG2cpSBbCVe6HqIfDZn.encode(Tv08xsf9HOqunIVUPdK1)
				Sn3lefFys4XLgp8JiRvV = Sn3lefFys4XLgp8JiRvV.encode(Tv08xsf9HOqunIVUPdK1)
			if   XM3KUmO1QJxlv84bgFTHsjdNt0kYq==0: dxwMtG2cpSBbCVe6HqIfDZn = 'أولى'
			elif XM3KUmO1QJxlv84bgFTHsjdNt0kYq==1: dxwMtG2cpSBbCVe6HqIfDZn = 'سابقة'
			elif XM3KUmO1QJxlv84bgFTHsjdNt0kYq==r8rTQdMpy79wz-2: dxwMtG2cpSBbCVe6HqIfDZn = 'لاحقة'
			elif XM3KUmO1QJxlv84bgFTHsjdNt0kYq==r8rTQdMpy79wz-1: dxwMtG2cpSBbCVe6HqIfDZn = 'أخيرة'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+dxwMtG2cpSBbCVe6HqIfDZn,Sn3lefFys4XLgp8JiRvV,mode)
	return
def sduaBqF7cj(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-TITLES1-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cuoYjfNMPnmhQgtFE = rUexZSI47j2HOLplM5.find_all(class_='row')
	items,cZs2GKDIAnwSryJ0R7m3 = [],True
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		if not drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='thumbnail-wrapper'): continue
		if cZs2GKDIAnwSryJ0R7m3: cZs2GKDIAnwSryJ0R7m3 = False ; continue
		c05OPiMwIANzTlHaeRjspytgoJCEmL = []
		WRAdkw15iNgF2T = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all(class_=['censorship red','censorship purple'])
		for txRXWzbja7empvAC8fcsok1BOd0SqY in WRAdkw15iNgF2T:
			F8TsvzGhQnWyerV5jdLaOxE27 = txRXWzbja7empvAC8fcsok1BOd0SqY.find_all('li')[1].text
			if psS8dmb912iRBgGc7qOPyCZ6:
				F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.encode(Tv08xsf9HOqunIVUPdK1)
			c05OPiMwIANzTlHaeRjspytgoJCEmL.append(F8TsvzGhQnWyerV5jdLaOxE27)
		if not HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,SebHIf2jL1TBgrMKJu,c05OPiMwIANzTlHaeRjspytgoJCEmL,False):
			i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('data-src')
			title = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('h3')
			name = title.find('a').text
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+title.find('a').get('href')
			ZbRuM62EJrpLS80BQqWevFC = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='no-margin')
			WXIw8qlGt9m6cKUV4Ap = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='legend')
			if ZbRuM62EJrpLS80BQqWevFC: ZbRuM62EJrpLS80BQqWevFC = ZbRuM62EJrpLS80BQqWevFC.text
			if WXIw8qlGt9m6cKUV4Ap: WXIw8qlGt9m6cKUV4Ap = WXIw8qlGt9m6cKUV4Ap.text
			if psS8dmb912iRBgGc7qOPyCZ6:
				i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.encode(Tv08xsf9HOqunIVUPdK1)
				name = name.encode(Tv08xsf9HOqunIVUPdK1)
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
				if ZbRuM62EJrpLS80BQqWevFC: ZbRuM62EJrpLS80BQqWevFC = ZbRuM62EJrpLS80BQqWevFC.encode(Tv08xsf9HOqunIVUPdK1)
			q0HoRKzxwkDFaj3P8r19JBTIACM = {}
			if WXIw8qlGt9m6cKUV4Ap: q0HoRKzxwkDFaj3P8r19JBTIACM['stars'] = WXIw8qlGt9m6cKUV4Ap
			if ZbRuM62EJrpLS80BQqWevFC:
				ZbRuM62EJrpLS80BQqWevFC = ZbRuM62EJrpLS80BQqWevFC.replace(u43PVWjh7t9YwI,' .. ')
				q0HoRKzxwkDFaj3P8r19JBTIACM['plot'] = ZbRuM62EJrpLS80BQqWevFC.replace('...اقرأ المزيد',SebHIf2jL1TBgrMKJu)
			if '/work/' in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,516,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name,SebHIf2jL1TBgrMKJu,q0HoRKzxwkDFaj3P8r19JBTIACM)
			elif '/person/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,513,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name,SebHIf2jL1TBgrMKJu,q0HoRKzxwkDFaj3P8r19JBTIACM)
	yfYnbslBTKrRvO0Zki(rUexZSI47j2HOLplM5,512)
	return
def z8xgYpVRCS0woq4UZ(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-TITLES2-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cuoYjfNMPnmhQgtFE = rUexZSI47j2HOLplM5.find_all('li')
	EOVC5HvpA3dNJcx,items = [],[]
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		if not drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='thumbnail-wrapper'): continue
		if not drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_=['unstyled','unstyled text-center']): continue
		if drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='hide'): continue
		title = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in EOVC5HvpA3dNJcx: continue
		EOVC5HvpA3dNJcx.append(name)
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+title.find('a').get('href')
		if '/search/work/' in url: i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('src')
		elif '/search/person/' in url: i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('data-src')
		elif '/search/video/' in url: i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('data-src')
		else: i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('src')
		if psS8dmb912iRBgGc7qOPyCZ6:
			name = name.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
			i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.encode(Tv08xsf9HOqunIVUPdK1)
		name = name.strip(qE4nB3mKWHs)
		items.append((name,cOn6JqZlmQbjtT,i3iEyeZ8BQmpDNornRVxTzwdYcX7))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,cOn6JqZlmQbjtT,i3iEyeZ8BQmpDNornRVxTzwdYcX7 in items:
		if '/search/video/' in url: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,522,i3iEyeZ8BQmpDNornRVxTzwdYcX7)
		elif '/search/person/' in url: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,513,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,516,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name)
	return
def I7XKfhoUYL(text):
	text = text.replace('الإعلان',SebHIf2jL1TBgrMKJu).replace('لفيلم',SebHIf2jL1TBgrMKJu).replace('الرسمي',SebHIf2jL1TBgrMKJu)
	text = text.replace('إعلان',SebHIf2jL1TBgrMKJu).replace('فيلم',SebHIf2jL1TBgrMKJu).replace('البرومو',SebHIf2jL1TBgrMKJu)
	text = text.replace('التشويقي',SebHIf2jL1TBgrMKJu).replace('لمسلسل',SebHIf2jL1TBgrMKJu).replace('مسلسل',SebHIf2jL1TBgrMKJu)
	text = text.replace(':',SebHIf2jL1TBgrMKJu).replace(')',SebHIf2jL1TBgrMKJu).replace('(',SebHIf2jL1TBgrMKJu).replace(',',SebHIf2jL1TBgrMKJu)
	text = text.replace('_',SebHIf2jL1TBgrMKJu).replace(';',SebHIf2jL1TBgrMKJu).replace('-',SebHIf2jL1TBgrMKJu).replace('.',SebHIf2jL1TBgrMKJu)
	text = text.replace('\'',SebHIf2jL1TBgrMKJu).replace('\"',SebHIf2jL1TBgrMKJu)
	text = text.replace(saNjmrfQDGgltv,qE4nB3mKWHs).replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	text = text.strip(qE4nB3mKWHs)
	LYQjRdDgPZI8xKB4Few = text.count(qE4nB3mKWHs)+1
	if LYQjRdDgPZI8xKB4Few==1:
		xiIDlcrZUn6voRbXwYhmSWAg2ue(text)
		return
	QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+E7r8hUCVvTiFQW0dBGXjxcy+'==== كلمات للبحث ===='+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Ra0oQktbiZ1p2 = text.split(qE4nB3mKWHs)
	uOFNK2bAJDB8079doHkEgj5RUX = pow(2,LYQjRdDgPZI8xKB4Few)
	CCr9ypxBPZ8vqo = []
	def CpIXS7QRKPMVlyWLcO(TJfF2PRpZyC5cvj,aapPBMl1evmfxJkw4T0HhX7):
		if TJfF2PRpZyC5cvj=='1': return aapPBMl1evmfxJkw4T0HhX7
		return SebHIf2jL1TBgrMKJu
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(uOFNK2bAJDB8079doHkEgj5RUX,0,-1):
		CpBb4wItPykx3fov5E = list(LYQjRdDgPZI8xKB4Few*'0'+bin(XM3KUmO1QJxlv84bgFTHsjdNt0kYq)[2:])[-LYQjRdDgPZI8xKB4Few:]
		CpBb4wItPykx3fov5E = reversed(CpBb4wItPykx3fov5E)
		WH0t1DnbcwFPNrzumfGZkJgYQqElyV = map(CpIXS7QRKPMVlyWLcO,CpBb4wItPykx3fov5E,Ra0oQktbiZ1p2)
		title = qE4nB3mKWHs.join(filter(None,WH0t1DnbcwFPNrzumfGZkJgYQqElyV))
		if psS8dmb912iRBgGc7qOPyCZ6: sABprza7wEOC0Fd3PTQ = title.decode(Tv08xsf9HOqunIVUPdK1)
		else: sABprza7wEOC0Fd3PTQ = title
		if len(sABprza7wEOC0Fd3PTQ)>2 and title not in CCr9ypxBPZ8vqo:
			CCr9ypxBPZ8vqo.append(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,523,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,title)
	return
def xiIDlcrZUn6voRbXwYhmSWAg2ue(cQajTFxr5OL8KbgyN0):
	if psS8dmb912iRBgGc7qOPyCZ6:
		cQajTFxr5OL8KbgyN0 = cQajTFxr5OL8KbgyN0.decode(Tv08xsf9HOqunIVUPdK1)
		import arabic_reshaper as xxA1sprdROoSmDB,bidi.algorithm as uXI7kZeJaUibBQ3n6coz1
		cQajTFxr5OL8KbgyN0 = xxA1sprdROoSmDB.ArabicReshaper().reshape(cQajTFxr5OL8KbgyN0)
		cQajTFxr5OL8KbgyN0 = uXI7kZeJaUibBQ3n6coz1.get_display(cQajTFxr5OL8KbgyN0)
	import x3xyuCUV0G
	cQajTFxr5OL8KbgyN0 = zWKdm3kV2ItwYrgH1BZyRON(h01hVuNmEIJ35vl=cQajTFxr5OL8KbgyN0)
	x3xyuCUV0G.yEPLitfHnvAdz0I9SVoC(cQajTFxr5OL8KbgyN0)
	return
def nnplL0VjC3TRYbtPUqXrHQFka5E4vM(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-INDEXES_LISTS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = rUexZSI47j2HOLplM5.find(class_='list-separator list-title')
	wDrcdftqyO = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('a')
	items = []
	for title in wDrcdftqyO:
		name = title.text
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+title.get('href')
		if psS8dmb912iRBgGc7qOPyCZ6:
			name = name.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
		if '#' not in cOn6JqZlmQbjtT: items.append((name,cOn6JqZlmQbjtT))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for JJSOAkTZIib4eswDo51pFuqvK in items:
		name,cOn6JqZlmQbjtT = JJSOAkTZIib4eswDo51pFuqvK
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,518)
	return
def l6l54GtSEfoARIs8XZ3pLWJ(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-INDEXES_TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cuoYjfNMPnmhQgtFE = rUexZSI47j2HOLplM5.find(class_='expand').find_all('tr')
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		E5Ra7sTiBDSNl = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find_all('a')
		if not E5Ra7sTiBDSNl: continue
		i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('data-src')
		name = E5Ra7sTiBDSNl[1].text
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+E5Ra7sTiBDSNl[1].get('href')
		WXIw8qlGt9m6cKUV4Ap = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='legend')
		if WXIw8qlGt9m6cKUV4Ap: WXIw8qlGt9m6cKUV4Ap = WXIw8qlGt9m6cKUV4Ap.text
		if psS8dmb912iRBgGc7qOPyCZ6:
			name = name.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
			i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.encode(Tv08xsf9HOqunIVUPdK1)
		q0HoRKzxwkDFaj3P8r19JBTIACM = {}
		if WXIw8qlGt9m6cKUV4Ap: q0HoRKzxwkDFaj3P8r19JBTIACM['stars'] = WXIw8qlGt9m6cKUV4Ap
		if '/work/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,516,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name,SebHIf2jL1TBgrMKJu,q0HoRKzxwkDFaj3P8r19JBTIACM)
		elif '/person/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,513,i3iEyeZ8BQmpDNornRVxTzwdYcX7,SebHIf2jL1TBgrMKJu,name,SebHIf2jL1TBgrMKJu,q0HoRKzxwkDFaj3P8r19JBTIACM)
	yfYnbslBTKrRvO0Zki(rUexZSI47j2HOLplM5,518)
	return
def IXPjUYgwEnpKh(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-VIDEOS_LISTS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	wDrcdftqyO = rUexZSI47j2HOLplM5.find_all(class_='section-title inline')
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = rUexZSI47j2HOLplM5.find_all(class_='button green small right')
	items = zip(wDrcdftqyO,uLdRirAZJKoSgPqNUjm84WXE5cn3aT)
	for title,cOn6JqZlmQbjtT in items:
		title = title.text
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT.get('href')
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
		title = title.replace(saNjmrfQDGgltv,qE4nB3mKWHs).replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,521)
	return
def JsoWV6Xu0zkBEew7(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-VIDEOS_TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	r2rv04USafhj = rUexZSI47j2HOLplM5.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	cuoYjfNMPnmhQgtFE = r2rv04USafhj.find_all('li')
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		title = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='title').text
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('a').get('href')
		i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find('img').get('data-src')
		lEeAaSobjWc = drRnSgoBtKWjmU5FH4ZCIVhzqNb.find(class_='duration').text
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.encode(Tv08xsf9HOqunIVUPdK1)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
			i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.encode(Tv08xsf9HOqunIVUPdK1)
			lEeAaSobjWc = lEeAaSobjWc.encode(Tv08xsf9HOqunIVUPdK1)
		lEeAaSobjWc = lEeAaSobjWc.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,522,i3iEyeZ8BQmpDNornRVxTzwdYcX7,lEeAaSobjWc)
	yfYnbslBTKrRvO0Zki(rUexZSI47j2HOLplM5,521)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cOn6JqZlmQbjtT = rUexZSI47j2HOLplM5.find(class_='flex-video').find('iframe').get('src')
	if psS8dmb912iRBgGc7qOPyCZ6: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.encode(Tv08xsf9HOqunIVUPdK1)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ([cOn6JqZlmQbjtT],tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'%20')
	url = j1IFsik4ouNePZr+'/search/?q='+search
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-SEARCH-1st')
	if not Bc5IUelt4sWvMXTdy.succeeded:
		MbB627EAZoDSzr9x5j = j1IFsik4ouNePZr+'/search_entity/?q='+search+'&entity=work'
		Sn3lefFys4XLgp8JiRvV = j1IFsik4ouNePZr+'/search_entity/?q='+search+'&entity=person'
		ebHUErYIspRKC1Z = j1IFsik4ouNePZr+'/search_entity/?q='+search+'&entity=video'
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن أعمال',MbB627EAZoDSzr9x5j,513,SebHIf2jL1TBgrMKJu,search)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن أشخاص',Sn3lefFys4XLgp8JiRvV,513,SebHIf2jL1TBgrMKJu,search)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث عن فيديوهات',ebHUErYIspRKC1Z,513,SebHIf2jL1TBgrMKJu,search)
		return
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	rUexZSI47j2HOLplM5 = YlD2BEyGa5HJAzuNvLt1VejmUF0S.BeautifulSoup(LCK8lO2yRWaTVEQcdjPXAzpFBe9,'html.parser',multi_valued_attributes=None)
	cuoYjfNMPnmhQgtFE = rUexZSI47j2HOLplM5.find_all(class_='section-title left')
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
		title = drRnSgoBtKWjmU5FH4ZCIVhzqNb.text
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.encode(Tv08xsf9HOqunIVUPdK1)
		title = title.split('(',1)[0].strip(qE4nB3mKWHs)
		if   'أعمال' in title: cOn6JqZlmQbjtT = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: cOn6JqZlmQbjtT = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: cOn6JqZlmQbjtT = url.replace('/search/','/search/video/')
		else: continue
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,513)
	return
def JJSUHLPVqYCAa(url,text):
	global PD0JksfFrlMUtG6OWVLgdiY8o5b,CIHKiYt9osw4SyjMfhP0rZ8
	if '/seasonals' in url:
		PD0JksfFrlMUtG6OWVLgdiY8o5b = ['seasonal','year','category']
		CIHKiYt9osw4SyjMfhP0rZ8 = ['seasonal','year','category']
	elif '/lineup' in url:
		PD0JksfFrlMUtG6OWVLgdiY8o5b = ['category','foreign','type']
		CIHKiYt9osw4SyjMfhP0rZ8 = ['category','foreign','type']
	vimwpBGoVK3EZrUkjPL(url,text)
	return
def OU0dGs5xyz9KH3o7(url):
	url = url.split('/smartemadfilter?')[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('form action="/(.*?)</form>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return BJheYUDK3EOyfPR24
def TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb):
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<option value="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return items
def s7GugCDv4lrB(url):
	iiXk0elDVoLTZ8HUAaB = url.split('/smartemadfilter?')[0]
	BDku1TovVtpfmhL9Ryde4nNQ = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def lK1iTLw36udVDefoz(hW2bu9H1KJCkPlfr,url):
	LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'all_filters')
	iGxH2fsuScPtkJb7ECg = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
	iGxH2fsuScPtkJb7ECg = s7GugCDv4lrB(iGxH2fsuScPtkJb7ECg)
	return iGxH2fsuScPtkJb7ECg
def vimwpBGoVK3EZrUkjPL(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if PD0JksfFrlMUtG6OWVLgdiY8o5b[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[0]
		for YHnALfql8hprDu in range(len(PD0JksfFrlMUtG6OWVLgdiY8o5b[0:-1])):
			if PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
	elif type=='ALL_ITEMS_FILTER':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'/smartemadfilter?'+wk0AjSOpcRB
		qg7Nr1dCaD = s7GugCDv4lrB(qg7Nr1dCaD)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',qg7Nr1dCaD,511)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',qg7Nr1dCaD,511)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	BJheYUDK3EOyfPR24 = OU0dGs5xyz9KH3o7(url)
	dict = {}
	for name,oIi8QaPyZBr1mvUcsh,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		name = name.replace('--',SebHIf2jL1TBgrMKJu)
		items = TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='SPECIFIED_FILTER':
			if oIi8QaPyZBr1mvUcsh not in PD0JksfFrlMUtG6OWVLgdiY8o5b: continue
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<2:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]:
					url = s7GugCDv4lrB(url)
					sduaBqF7cj(url)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'SPECIFIED_FILTER___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				qg7Nr1dCaD = s7GugCDv4lrB(qg7Nr1dCaD)
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,511)
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,515,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='ALL_ITEMS_FILTER':
			if oIi8QaPyZBr1mvUcsh not in CIHKiYt9osw4SyjMfhP0rZ8: continue
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع: '+name,qg7Nr1dCaD,514,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			if 'مصنفات أخرى' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			if 'الكل' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			if 'اللغة' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			OSEMFXaUVI1eqHhQYmbKPdJAnrk = OSEMFXaUVI1eqHhQYmbKPdJAnrk.replace('قائمة ',SebHIf2jL1TBgrMKJu)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			if name: title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'+name
			else: title = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			if type=='ALL_ITEMS_FILTER': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,514,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='SPECIFIED_FILTER' and PD0JksfFrlMUtG6OWVLgdiY8o5b[-2]+'=' in EH6SWa3KmUw7c18RF:
				iGxH2fsuScPtkJb7ECg = lK1iTLw36udVDefoz(hW2bu9H1KJCkPlfr,url)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,511)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,515,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.replace('=&','=0&')
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	for key in CIHKiYt9osw4SyjMfhP0rZ8:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all_filters': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('=0','=')
	return hIyBYfuc8oTsEZ
PD0JksfFrlMUtG6OWVLgdiY8o5b = []
CIHKiYt9osw4SyjMfhP0rZ8 = []