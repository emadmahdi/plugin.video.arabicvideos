# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'GOOGLESEARCH'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_GOS_'
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf):
	if   hL9fngBAu7XzOx==1010: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif hL9fngBAu7XzOx==1011: lfZmugQCFKLGT05AH29IsMiho = wUnj3lTk5gR9sD(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1012: lfZmugQCFKLGT05AH29IsMiho = MNz57XPGa24S0rWkl6jKxtDQp(vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1013: lfZmugQCFKLGT05AH29IsMiho = Hf6muiMKy8J()
	elif hL9fngBAu7XzOx==1014: lfZmugQCFKLGT05AH29IsMiho = KweGzZoiNCkAuqsP3(vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1015: lfZmugQCFKLGT05AH29IsMiho = sch4Rkg58xzWmY07yN(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1016: lfZmugQCFKLGT05AH29IsMiho = ZbprDgi7OE8zRYGXqj1T4(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1018: lfZmugQCFKLGT05AH29IsMiho = w8z9YTVjN2xH1q6RoWLctMsrye(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==1019: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(Yg36raSGA02uUXEPMF7itZd9KcWf,False)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder','بحث جوجل جديد',SebHIf2jL1TBgrMKJu,1019)
	QUzFYoapm9jx('link','كيف يعمل بحث جوجل','',1013)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'==== كلمات البحث المخزنة ===='+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	d2dMvQFSBYIq1C8sNezGT = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if d2dMvQFSBYIq1C8sNezGT:
		d2dMvQFSBYIq1C8sNezGT = d2dMvQFSBYIq1C8sNezGT['__SEQUENCED_COLUMNS__']
		for IsqopSjwNr6W4klVD32JR1nhf in reversed(d2dMvQFSBYIq1C8sNezGT):
			QUzFYoapm9jx('folder',IsqopSjwNr6W4klVD32JR1nhf,SebHIf2jL1TBgrMKJu,1019,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,IsqopSjwNr6W4klVD32JR1nhf)
	return
def w8z9YTVjN2xH1q6RoWLctMsrye(search):
	yEPLitfHnvAdz0I9SVoC(search,True)
	GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def yEPLitfHnvAdz0I9SVoC(search,Q1HVieGY9N=False):
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	cQajTFxr5OL8KbgyN0 = search.replace(FFe0IfYj65szqgLHkNpBPJnRQEmZo,SebHIf2jL1TBgrMKJu).lower()
	jjL6lCfYNu,dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = [],[],[]
	if not Q1HVieGY9N:
		jjL6lCfYNu = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GOOGLESEARCH_RESULTS',cQajTFxr5OL8KbgyN0)
		if jjL6lCfYNu: dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = jjL6lCfYNu
	if Q1HVieGY9N or not jjL6lCfYNu:
		import x3xyuCUV0G
		x3xyuCUV0G.dQzyh672wCc(cQajTFxr5OL8KbgyN0,'_GOOGLE',True)
		imLDv3zg204xIwTjcqQM = RiYnaWbSo2gHpK3k6fPrDA(cQajTFxr5OL8KbgyN0)
		for JJSOAkTZIib4eswDo51pFuqvK in imLDv3zg204xIwTjcqQM:
			name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S = JJSOAkTZIib4eswDo51pFuqvK
			if GJ4kbYnxcHa6NIOuA7X20S in bHVThUqlANJkcY9DWLou1i: dWh0DSZa3R.append(JJSOAkTZIib4eswDo51pFuqvK)
			else: ZkwV90DBqHYPUyJpXmc3.append(JJSOAkTZIib4eswDo51pFuqvK)
		dWh0DSZa3R = sorted(dWh0DSZa3R,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[wvkDqmNZlJU52isXo])
		ZkwV90DBqHYPUyJpXmc3 = sorted(ZkwV90DBqHYPUyJpXmc3,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[wvkDqmNZlJU52isXo])
		pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'GOOGLESEARCH_RESULTS',cQajTFxr5OL8KbgyN0,[dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3],CtRZoJqPXV)
		pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DETAILED_GOOGLE',cQajTFxr5OL8KbgyN0)
		x3xyuCUV0G.dQzyh672wCc(cQajTFxr5OL8KbgyN0,'_GOOGLE',False)
		pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+cQajTFxr5OL8KbgyN0+"')")
		if dWh0DSZa3R: gge5CmAcldwv0('','',lFEvMxzSH2y7tYR,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(dWh0DSZa3R))+'  مواقع')
		else: dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = RQOupnsW9bAc4M2GKFIfDed6NxySJ(cQajTFxr5OL8KbgyN0,mrhSYXH2P8bO3eJAa9n)
	QUzFYoapm9jx('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('folder','بحث منفرد لمواقع جوجل',SebHIf2jL1TBgrMKJu,1011,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder','نتائج البحث مفصلة - '+cQajTFxr5OL8KbgyN0,'opened_sites_google',1012,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('folder','نتائج البحث مقسمة - '+cQajTFxr5OL8KbgyN0,'listed_sites_google',1012,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder','مواقع جوجل ('+str(len(dWh0DSZa3R))+') - '+cQajTFxr5OL8KbgyN0,'',1016,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('link','إعادة بحث جوجل - '+cQajTFxr5OL8KbgyN0,'',1018,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,search)
	return
def ZbprDgi7OE8zRYGXqj1T4(cQajTFxr5OL8KbgyN0):
	dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = RQOupnsW9bAc4M2GKFIfDed6NxySJ(cQajTFxr5OL8KbgyN0)
	if not dWh0DSZa3R and not ZkwV90DBqHYPUyJpXmc3: return
	e86lkLsKUpdWZIjE = {}
	for name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S in dWh0DSZa3R: e86lkLsKUpdWZIjE[GJ4kbYnxcHa6NIOuA7X20S] = name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S
	K03lsMX2cU9IgNYenTZfm8S = list(e86lkLsKUpdWZIjE.keys())
	import x3xyuCUV0G
	Ef0RPFcwJO5k1 = x3xyuCUV0G.Lx9EoVFmp6PsyenMdBuOq23(K03lsMX2cU9IgNYenTZfm8S)
	for GJ4kbYnxcHa6NIOuA7X20S in Ef0RPFcwJO5k1:
		if isinstance(GJ4kbYnxcHa6NIOuA7X20S,tuple):
			qFsuKN7ngp.menuItemsLIST.append(GJ4kbYnxcHa6NIOuA7X20S)
			continue
		name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S = e86lkLsKUpdWZIjE[GJ4kbYnxcHa6NIOuA7X20S]
		o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
		QUzFYoapm9jx('folder',RTtiozFdb3kamGMqwcL4EgCyAhOS+name,cOn6JqZlmQbjtT,1014,vMN2xELQtgXYZ4Geu3z5ci,'',GJ4kbYnxcHa6NIOuA7X20S)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'مواقع بجوجل غير موجودة بالبرنامج'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,1015)
	ZkwV90DBqHYPUyJpXmc3 = sorted(ZkwV90DBqHYPUyJpXmc3,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[wvkDqmNZlJU52isXo])
	for name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S in ZkwV90DBqHYPUyJpXmc3:
		QUzFYoapm9jx('link','_GOS_'+name,cOn6JqZlmQbjtT,1015,vMN2xELQtgXYZ4Geu3z5ci,'',GJ4kbYnxcHa6NIOuA7X20S)
	return
def RQOupnsW9bAc4M2GKFIfDed6NxySJ(cQajTFxr5OL8KbgyN0,VzOM30UGKlQvF2k4xt=BBX9RAuxnyGZ4WIF2TrhYeom3):
	dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = [],[]
	if VzOM30UGKlQvF2k4xt:
		jjL6lCfYNu = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GOOGLESEARCH_RESULTS',cQajTFxr5OL8KbgyN0)
		if jjL6lCfYNu: dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = jjL6lCfYNu
	if not dWh0DSZa3R and not ZkwV90DBqHYPUyJpXmc3: gge5CmAcldwv0('','',lFEvMxzSH2y7tYR,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3
def MNz57XPGa24S0rWkl6jKxtDQp(Pj1F9klBYh3zoTHivEUgVIOw8L,cQajTFxr5OL8KbgyN0):
	dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = RQOupnsW9bAc4M2GKFIfDed6NxySJ(cQajTFxr5OL8KbgyN0)
	if not dWh0DSZa3R and not ZkwV90DBqHYPUyJpXmc3: return
	HsGionFRpj8OgaJqbykxwCWVZ0h,uumhdGxHCM3YqT97NVcP8e2kza = [],{}
	for name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S in dWh0DSZa3R:
		HsGionFRpj8OgaJqbykxwCWVZ0h.append(GJ4kbYnxcHa6NIOuA7X20S)
		uumhdGxHCM3YqT97NVcP8e2kza[GJ4kbYnxcHa6NIOuA7X20S] = dRqebsCYVQvxP(text)
	import x3xyuCUV0G
	x3xyuCUV0G.oRju3krYanIAQt7O4(cQajTFxr5OL8KbgyN0,Pj1F9klBYh3zoTHivEUgVIOw8L,SebHIf2jL1TBgrMKJu,HsGionFRpj8OgaJqbykxwCWVZ0h,uumhdGxHCM3YqT97NVcP8e2kza)
	return
def wUnj3lTk5gR9sD(cQajTFxr5OL8KbgyN0):
	dWh0DSZa3R,ZkwV90DBqHYPUyJpXmc3 = RQOupnsW9bAc4M2GKFIfDed6NxySJ(cQajTFxr5OL8KbgyN0)
	if not dWh0DSZa3R and not ZkwV90DBqHYPUyJpXmc3: return
	e86lkLsKUpdWZIjE = {}
	for name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S in dWh0DSZa3R:
		e86lkLsKUpdWZIjE[GJ4kbYnxcHa6NIOuA7X20S] = name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S
	K03lsMX2cU9IgNYenTZfm8S = list(e86lkLsKUpdWZIjE.keys())
	import x3xyuCUV0G
	Ef0RPFcwJO5k1 = x3xyuCUV0G.Lx9EoVFmp6PsyenMdBuOq23(K03lsMX2cU9IgNYenTZfm8S)
	for GJ4kbYnxcHa6NIOuA7X20S in Ef0RPFcwJO5k1:
		if isinstance(GJ4kbYnxcHa6NIOuA7X20S,tuple):
			qFsuKN7ngp.menuItemsLIST.append(GJ4kbYnxcHa6NIOuA7X20S)
			continue
		name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S = e86lkLsKUpdWZIjE[GJ4kbYnxcHa6NIOuA7X20S]
		o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
		text = dRqebsCYVQvxP(text)
		name = name+' - '+cQajTFxr5OL8KbgyN0
		QUzFYoapm9jx('folder',RTtiozFdb3kamGMqwcL4EgCyAhOS+name,GJ4kbYnxcHa6NIOuA7X20S,548,vMN2xELQtgXYZ4Geu3z5ci,'',text)
	return
def dRqebsCYVQvxP(title):
	Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة)',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	sABprza7wEOC0Fd3PTQ = Wj39BaH6oEmstx[0][0] if Wj39BaH6oEmstx else title
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return sABprza7wEOC0Fd3PTQ
def RiYnaWbSo2gHpK3k6fPrDA(search):
	search = search.replace(qE4nB3mKWHs,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	qg7Nr1dCaD = url+'&start=0&num=100&tbm=vid&udm=7'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'GOOGLESEARCH-SEARCH-1st')
	if not Bc5IUelt4sWvMXTdy.succeeded: return []
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	ZPDv9OClk2cnEigHY = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(Q8ueUH69goFIxnE2V1,'googlesearch')
	if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(ZPDv9OClk2cnEigHY):
		try: E2xjtKaMXdC3NDoTm7f5Wkev.makedirs(ZPDv9OClk2cnEigHY)
		except: pass
	items = []
	cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cuoYjfNMPnmhQgtFE:
		for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
			cOn6JqZlmQbjtT,title,text,i3iEyeZ8BQmpDNornRVxTzwdYcX7,name = drRnSgoBtKWjmU5FH4ZCIVhzqNb
			i3iEyeZ8BQmpDNornRVxTzwdYcX7 = ''
			items.append([cOn6JqZlmQbjtT,title,text,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7])
	else:
		qg7Nr1dCaD = url+'&start=0&num=200'
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET::SCRAPERS',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'GOOGLESEARCH-SEARCH-2nd')
		if not Bc5IUelt4sWvMXTdy.succeeded: return []
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not cuoYjfNMPnmhQgtFE: cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = xjVJ0o7mF86tCDagkbNcrTAR4UH('list',drRnSgoBtKWjmU5FH4ZCIVhzqNb)
			if len(drRnSgoBtKWjmU5FH4ZCIVhzqNb)>17:
				cOn6JqZlmQbjtT = drRnSgoBtKWjmU5FH4ZCIVhzqNb[17]
				title,text,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7 = drRnSgoBtKWjmU5FH4ZCIVhzqNb[31][0:4]
				items.append([cOn6JqZlmQbjtT,title,text,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7])
	NwcmuaUOvoBLfrGW,mmyWhMCdGJPz5I0AarYDNQ7lpjtu = [],[]
	for JJSOAkTZIib4eswDo51pFuqvK in items:
		cOn6JqZlmQbjtT,title,text,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7 = JJSOAkTZIib4eswDo51pFuqvK
		name = name.strip(' ')
		if not name: name = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
		name = YRPMivXNVUgu0FSsOICQnTZ2r(name)
		if 'http://' in i3iEyeZ8BQmpDNornRVxTzwdYcX7 or 'https://' in i3iEyeZ8BQmpDNornRVxTzwdYcX7: vMN2xELQtgXYZ4Geu3z5ci = i3iEyeZ8BQmpDNornRVxTzwdYcX7
		elif 'data:image/' in i3iEyeZ8BQmpDNornRVxTzwdYcX7 and ';base64,' in i3iEyeZ8BQmpDNornRVxTzwdYcX7:
			kVonYeDHO31QLtIMXchsd0T6flE8PF = X2XorVqHjLkWeCchY4u9fSz.findall('data:image/(\w+);base64,',i3iEyeZ8BQmpDNornRVxTzwdYcX7)
			kVonYeDHO31QLtIMXchsd0T6flE8PF = kVonYeDHO31QLtIMXchsd0T6flE8PF[0]
			vMN2xELQtgXYZ4Geu3z5ci = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(ZPDv9OClk2cnEigHY,name+'.'+kVonYeDHO31QLtIMXchsd0T6flE8PF)
			if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(vMN2xELQtgXYZ4Geu3z5ci):
				i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.replace('\\u003d','=')
				i3iEyeZ8BQmpDNornRVxTzwdYcX7 = i3iEyeZ8BQmpDNornRVxTzwdYcX7.replace('data:image/'+kVonYeDHO31QLtIMXchsd0T6flE8PF+';base64,','')
				wwnVphYSEs = ej3oxQLc68OIY.b64decode(i3iEyeZ8BQmpDNornRVxTzwdYcX7)
				open(vMN2xELQtgXYZ4Geu3z5ci,'wb').write(wwnVphYSEs)
		else: vMN2xELQtgXYZ4Geu3z5ci = ''
		GJ4kbYnxcHa6NIOuA7X20S = AhrOBDi8NkFWJf7V35jYnLm(name,cOn6JqZlmQbjtT)
		if GJ4kbYnxcHa6NIOuA7X20S not in mmyWhMCdGJPz5I0AarYDNQ7lpjtu:
			mmyWhMCdGJPz5I0AarYDNQ7lpjtu.append(GJ4kbYnxcHa6NIOuA7X20S)
			name = dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S)
			NwcmuaUOvoBLfrGW.append([name,cOn6JqZlmQbjtT,title,text,vMN2xELQtgXYZ4Geu3z5ci,GJ4kbYnxcHa6NIOuA7X20S])
	return NwcmuaUOvoBLfrGW
def KweGzZoiNCkAuqsP3(cOn6JqZlmQbjtT,GJ4kbYnxcHa6NIOuA7X20S):
	o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
	if RTtiozFdb3kamGMqwcL4EgCyAhOS: o6aYtV2fpKOCDJ()
	else: sch4Rkg58xzWmY07yN()
	return
def Hf6muiMKy8J():
	gge5CmAcldwv0('','',lFEvMxzSH2y7tYR,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def sch4Rkg58xzWmY07yN(GJ4kbYnxcHa6NIOuA7X20S=''):
	gge5CmAcldwv0('','',GJ4kbYnxcHa6NIOuA7X20S,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def AhrOBDi8NkFWJf7V35jYnLm(name,cOn6JqZlmQbjtT):
	MG47Re6lK1i8n3gzJ2tEPNChD = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	dxwMtG2cpSBbCVe6HqIfDZn = name.lower()
	WH0t1DnbcwFPNrzumfGZkJgYQqElyV = ''
	for key in list(MG47Re6lK1i8n3gzJ2tEPNChD.keys()):
		if key.lower() in dxwMtG2cpSBbCVe6HqIfDZn: WH0t1DnbcwFPNrzumfGZkJgYQqElyV = MG47Re6lK1i8n3gzJ2tEPNChD[key]
	if not WH0t1DnbcwFPNrzumfGZkJgYQqElyV:
		Sn3lefFys4XLgp8JiRvV = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'url')
		for GJ4kbYnxcHa6NIOuA7X20S in list(qFsuKN7ngp.SITESURLS.keys()):
			ebHUErYIspRKC1Z = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qFsuKN7ngp.SITESURLS[GJ4kbYnxcHa6NIOuA7X20S][0],'url')
			if Sn3lefFys4XLgp8JiRvV==ebHUErYIspRKC1Z: WH0t1DnbcwFPNrzumfGZkJgYQqElyV = GJ4kbYnxcHa6NIOuA7X20S
	if not WH0t1DnbcwFPNrzumfGZkJgYQqElyV:
		dxwMtG2cpSBbCVe6HqIfDZn = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
		for GJ4kbYnxcHa6NIOuA7X20S in list(qFsuKN7ngp.SITESURLS.keys()):
			dqI9uOQCa1zHW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qFsuKN7ngp.SITESURLS[GJ4kbYnxcHa6NIOuA7X20S][0],'name')
			if dxwMtG2cpSBbCVe6HqIfDZn==dqI9uOQCa1zHW: WH0t1DnbcwFPNrzumfGZkJgYQqElyV = GJ4kbYnxcHa6NIOuA7X20S
	if not WH0t1DnbcwFPNrzumfGZkJgYQqElyV: WH0t1DnbcwFPNrzumfGZkJgYQqElyV = name
	WH0t1DnbcwFPNrzumfGZkJgYQqElyV = WH0t1DnbcwFPNrzumfGZkJgYQqElyV.upper()
	return WH0t1DnbcwFPNrzumfGZkJgYQqElyV