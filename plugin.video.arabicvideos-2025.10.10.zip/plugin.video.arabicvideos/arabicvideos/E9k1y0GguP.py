# -*- coding: utf-8 -*-
from RSdDifzoPG import *
pliQLY2RfzaWc = 'FAVORITES'
def m1pvQKO9uURy8BP6zFYE0DL5VSlb(hL9fngBAu7XzOx,Y5aocS7P8KTev6g):
	if   hL9fngBAu7XzOx==270: hoVT09XER3Jp6sL5 = v5bLpYrNEozxBaR3cJyV(Y5aocS7P8KTev6g)
	else: hoVT09XER3Jp6sL5 = False
	return hoVT09XER3Jp6sL5
def CDREpFuBf7ONV8ej4qwKm2J9Ysd(za6XoDpqQx953L,Y5aocS7P8KTev6g,nFWH76KhTj):
	if not za6XoDpqQx953L: return
	if   nFWH76KhTj=='UP1'	: OtFZSco8QWfDun(Y5aocS7P8KTev6g,True,nyUIsfd53EGot9vbj0XDeq)
	elif nFWH76KhTj=='DOWN1'	: OtFZSco8QWfDun(Y5aocS7P8KTev6g,False,nyUIsfd53EGot9vbj0XDeq)
	elif nFWH76KhTj=='UP4'	: OtFZSco8QWfDun(Y5aocS7P8KTev6g,True,K7cnfQMS6BPvI4LGmCsRp8bUlJ9)
	elif nFWH76KhTj=='DOWN4'	: OtFZSco8QWfDun(Y5aocS7P8KTev6g,False,K7cnfQMS6BPvI4LGmCsRp8bUlJ9)
	elif nFWH76KhTj=='ADD1'	: EErBg0YLAtFCShOXvjZqGkmuw9(Y5aocS7P8KTev6g)
	elif nFWH76KhTj=='REMOVE1': Q4QAdOlBJapNcoH1LZv(Y5aocS7P8KTev6g)
	elif nFWH76KhTj=='DELETELIST': jT6k87qdEzArJ(Y5aocS7P8KTev6g)
	return
def v5bLpYrNEozxBaR3cJyV(Y5aocS7P8KTev6g):
	fOvbZi0eUThMK5S73jFcxHQaYL = ZpSQqawGY1MiRyUstH2e7JBfrNPV5T()
	if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
		try:
			NA3WCGys0OtjVzMkTcP = fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]
			if wvkDqmNZlJU52isXo and Y5aocS7P8KTev6g in ['5','11','12','13']:
				for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW in NA3WCGys0OtjVzMkTcP:
					if GG8ETpSO0xyUZC7VJeP1sIk52WrN=='video':
						QUzFYoapm9jx('video',E7r8hUCVvTiFQW0dBGXjxcy+'تشغيل من الأعلى إلى الأسفل'+XOVRfitWJP1zL3p2CMYF,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L)
						QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
						break
			for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW in NA3WCGys0OtjVzMkTcP:
				QUzFYoapm9jx(GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW)
		except:
			fOvbZi0eUThMK5S73jFcxHQaYL = Pvf1zMmXRJnipdHDbFeV4r(NnA1JBy7DVvFqcm)
			NA3WCGys0OtjVzMkTcP = fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]
			for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW in NA3WCGys0OtjVzMkTcP:
				QUzFYoapm9jx(GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW)
	return
def EErBg0YLAtFCShOXvjZqGkmuw9(Y5aocS7P8KTev6g):
	GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
	if Y5aocS7P8KTev6g in ['5','11','12','13'] and GG8ETpSO0xyUZC7VJeP1sIk52WrN!='video':
		gge5CmAcldwv0('','',lFEvMxzSH2y7tYR,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	XWF8TzhJ1AyCnLQMNdgx = GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,MQcCbiOnpXkdwNfIe8Vj7ZuRW
	fOvbZi0eUThMK5S73jFcxHQaYL = ZpSQqawGY1MiRyUstH2e7JBfrNPV5T()
	pZNxJkvgRt6IT2M = {}
	for wzfsER3WB4ki in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
		if wzfsER3WB4ki!=Y5aocS7P8KTev6g: pZNxJkvgRt6IT2M[wzfsER3WB4ki] = fOvbZi0eUThMK5S73jFcxHQaYL[wzfsER3WB4ki]
		else:
			if xzpZLdkW2Ol and xzpZLdkW2Ol!='..':
				pVCiWcQ8h9ejJ0I2x1HyAtPf7aL = fOvbZi0eUThMK5S73jFcxHQaYL[wzfsER3WB4ki]
				if XWF8TzhJ1AyCnLQMNdgx in pVCiWcQ8h9ejJ0I2x1HyAtPf7aL:
					VMmJOLAbqul = pVCiWcQ8h9ejJ0I2x1HyAtPf7aL.index(XWF8TzhJ1AyCnLQMNdgx)
					del pVCiWcQ8h9ejJ0I2x1HyAtPf7aL[VMmJOLAbqul]
				c0ckSvjeEuCGU578fdyRYhmHlOat = pVCiWcQ8h9ejJ0I2x1HyAtPf7aL+[XWF8TzhJ1AyCnLQMNdgx]
				pZNxJkvgRt6IT2M[wzfsER3WB4ki] = c0ckSvjeEuCGU578fdyRYhmHlOat
			else: pZNxJkvgRt6IT2M[wzfsER3WB4ki] = fOvbZi0eUThMK5S73jFcxHQaYL[wzfsER3WB4ki]
	if Y5aocS7P8KTev6g not in list(pZNxJkvgRt6IT2M.keys()): pZNxJkvgRt6IT2M[Y5aocS7P8KTev6g] = [XWF8TzhJ1AyCnLQMNdgx]
	QQlnD8fGY7A03VMsujOLXK = str(pZNxJkvgRt6IT2M)
	if QBOMjKifEAFD: QQlnD8fGY7A03VMsujOLXK = QQlnD8fGY7A03VMsujOLXK.encode(Tv08xsf9HOqunIVUPdK1)
	open(NnA1JBy7DVvFqcm,'wb').write(QQlnD8fGY7A03VMsujOLXK)
	return
def Q4QAdOlBJapNcoH1LZv(Y5aocS7P8KTev6g):
	GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
	XWF8TzhJ1AyCnLQMNdgx = GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,MQcCbiOnpXkdwNfIe8Vj7ZuRW
	fOvbZi0eUThMK5S73jFcxHQaYL = ZpSQqawGY1MiRyUstH2e7JBfrNPV5T()
	if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()) and XWF8TzhJ1AyCnLQMNdgx in fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]:
		fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g].remove(XWF8TzhJ1AyCnLQMNdgx)
		if len(fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g])==wvkDqmNZlJU52isXo: del fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]
		QQlnD8fGY7A03VMsujOLXK = str(fOvbZi0eUThMK5S73jFcxHQaYL)
		if QBOMjKifEAFD: QQlnD8fGY7A03VMsujOLXK = QQlnD8fGY7A03VMsujOLXK.encode(Tv08xsf9HOqunIVUPdK1)
		open(NnA1JBy7DVvFqcm,'wb').write(QQlnD8fGY7A03VMsujOLXK)
	return
def OtFZSco8QWfDun(Y5aocS7P8KTev6g,HDuA8zVxtPj7Sg,IOd7CfS3PE):
	GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
	XWF8TzhJ1AyCnLQMNdgx = GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,MQcCbiOnpXkdwNfIe8Vj7ZuRW
	fOvbZi0eUThMK5S73jFcxHQaYL = ZpSQqawGY1MiRyUstH2e7JBfrNPV5T()
	if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
		pVCiWcQ8h9ejJ0I2x1HyAtPf7aL = fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]
		if XWF8TzhJ1AyCnLQMNdgx not in pVCiWcQ8h9ejJ0I2x1HyAtPf7aL: return
		p95WruwZIyOg0S3PfocnmzL = len(pVCiWcQ8h9ejJ0I2x1HyAtPf7aL)
		for k67x1WiUM34JdvBYLFwpe2 in range(wvkDqmNZlJU52isXo,IOd7CfS3PE):
			PQ0UtMpnql3T6sc8XFfd7amWrRi4 = pVCiWcQ8h9ejJ0I2x1HyAtPf7aL.index(XWF8TzhJ1AyCnLQMNdgx)
			if HDuA8zVxtPj7Sg: mnZIk68l05p7Cce = PQ0UtMpnql3T6sc8XFfd7amWrRi4-nyUIsfd53EGot9vbj0XDeq
			else: mnZIk68l05p7Cce = PQ0UtMpnql3T6sc8XFfd7amWrRi4+nyUIsfd53EGot9vbj0XDeq
			if mnZIk68l05p7Cce>=p95WruwZIyOg0S3PfocnmzL: mnZIk68l05p7Cce = mnZIk68l05p7Cce-p95WruwZIyOg0S3PfocnmzL
			if mnZIk68l05p7Cce<wvkDqmNZlJU52isXo: mnZIk68l05p7Cce = mnZIk68l05p7Cce+p95WruwZIyOg0S3PfocnmzL
			pVCiWcQ8h9ejJ0I2x1HyAtPf7aL.insert(mnZIk68l05p7Cce, pVCiWcQ8h9ejJ0I2x1HyAtPf7aL.pop(PQ0UtMpnql3T6sc8XFfd7amWrRi4))
		fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g] = pVCiWcQ8h9ejJ0I2x1HyAtPf7aL
		QQlnD8fGY7A03VMsujOLXK = str(fOvbZi0eUThMK5S73jFcxHQaYL)
		if QBOMjKifEAFD: QQlnD8fGY7A03VMsujOLXK = QQlnD8fGY7A03VMsujOLXK.encode(Tv08xsf9HOqunIVUPdK1)
		open(NnA1JBy7DVvFqcm,'wb').write(QQlnD8fGY7A03VMsujOLXK)
	return
def c3dTv8EC1rzwl5RVAWH6YqjG9iOab(Y5aocS7P8KTev6g):
	if Y5aocS7P8KTev6g in ['1','2','3','4']: kOL3MEnU9emCsp2VGwiS,gQK49tx1CNeUOboaj = 'مفضلة',Y5aocS7P8KTev6g
	elif Y5aocS7P8KTev6g in ['5']: kOL3MEnU9emCsp2VGwiS,gQK49tx1CNeUOboaj = 'تشغيل','1'
	elif Y5aocS7P8KTev6g in ['11']: kOL3MEnU9emCsp2VGwiS,gQK49tx1CNeUOboaj = 'تشغيل','2'
	else: kOL3MEnU9emCsp2VGwiS,gQK49tx1CNeUOboaj = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	keG09YwarCOi7qcBfgTbUmSL1X8W5 = kOL3MEnU9emCsp2VGwiS+qE4nB3mKWHs+gQK49tx1CNeUOboaj
	return keG09YwarCOi7qcBfgTbUmSL1X8W5
def jT6k87qdEzArJ(Y5aocS7P8KTev6g):
	keG09YwarCOi7qcBfgTbUmSL1X8W5 = c3dTv8EC1rzwl5RVAWH6YqjG9iOab(Y5aocS7P8KTev6g)
	ffIQynE7HP3 = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هل تريد فعلا مسح جميع محتويات قائمة '+keG09YwarCOi7qcBfgTbUmSL1X8W5+' ؟!')
	if ffIQynE7HP3!=1: return
	fOvbZi0eUThMK5S73jFcxHQaYL = ZpSQqawGY1MiRyUstH2e7JBfrNPV5T()
	if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
		del fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]
		QQlnD8fGY7A03VMsujOLXK = str(fOvbZi0eUThMK5S73jFcxHQaYL)
		if QBOMjKifEAFD: QQlnD8fGY7A03VMsujOLXK = QQlnD8fGY7A03VMsujOLXK.encode(Tv08xsf9HOqunIVUPdK1)
		open(NnA1JBy7DVvFqcm,'wb').write(QQlnD8fGY7A03VMsujOLXK)
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم مسح جميع محتويات قائمة '+keG09YwarCOi7qcBfgTbUmSL1X8W5)
	return
def ZpSQqawGY1MiRyUstH2e7JBfrNPV5T():
	fOvbZi0eUThMK5S73jFcxHQaYL = {}
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(NnA1JBy7DVvFqcm):
		OJWU5A0d9LohRQFkx = open(NnA1JBy7DVvFqcm,'rb').read()
		if QBOMjKifEAFD: OJWU5A0d9LohRQFkx = OJWU5A0d9LohRQFkx.decode(Tv08xsf9HOqunIVUPdK1)
		fOvbZi0eUThMK5S73jFcxHQaYL = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',OJWU5A0d9LohRQFkx)
	return fOvbZi0eUThMK5S73jFcxHQaYL
def Zv2NyktKEjS(fOvbZi0eUThMK5S73jFcxHQaYL,XWF8TzhJ1AyCnLQMNdgx,cZpwfuO6A8SMzGiDjmWFy):
	GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW = XWF8TzhJ1AyCnLQMNdgx
	if not hL9fngBAu7XzOx: GG8ETpSO0xyUZC7VJeP1sIk52WrN,hL9fngBAu7XzOx = 'folder','260'
	KKbueGS4Ln,Y5aocS7P8KTev6g = [],SebHIf2jL1TBgrMKJu
	if 'context=' in EWTFwqJoXHGSjsRfhOI5YLM:
		h2gDiWABIF37yZpsQtujvRlNkerMa1 = X2XorVqHjLkWeCchY4u9fSz.findall('context=(\d+)',EWTFwqJoXHGSjsRfhOI5YLM,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if h2gDiWABIF37yZpsQtujvRlNkerMa1: Y5aocS7P8KTev6g = str(h2gDiWABIF37yZpsQtujvRlNkerMa1[wvkDqmNZlJU52isXo])
	if hL9fngBAu7XzOx=='270':
		Y5aocS7P8KTev6g = za6XoDpqQx953L
		if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
			keG09YwarCOi7qcBfgTbUmSL1X8W5 = c3dTv8EC1rzwl5RVAWH6YqjG9iOab(Y5aocS7P8KTev6g)
			KKbueGS4Ln.append(('مسح قائمة '+keG09YwarCOi7qcBfgTbUmSL1X8W5,'RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_DELETELIST'+')'))
	else:
		if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()):
			count = len(fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g])
			if count>nyUIsfd53EGot9vbj0XDeq: KKbueGS4Ln.append(('تحريك 1 للأعلى','RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_UP1)'))
			if count>K7cnfQMS6BPvI4LGmCsRp8bUlJ9: KKbueGS4Ln.append(('تحريك 4 للأعلى','RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_UP4)'))
			if count>nyUIsfd53EGot9vbj0XDeq: KKbueGS4Ln.append(('تحريك 1 للأسفل','RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_DOWN1)'))
			if count>K7cnfQMS6BPvI4LGmCsRp8bUlJ9: KKbueGS4Ln.append(('تحريك 4 للأسفل','RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_DOWN4)'))
		for Y5aocS7P8KTev6g in ['1','2','3','4','5','11']:
			keG09YwarCOi7qcBfgTbUmSL1X8W5 = c3dTv8EC1rzwl5RVAWH6YqjG9iOab(Y5aocS7P8KTev6g)
			if Y5aocS7P8KTev6g in list(fOvbZi0eUThMK5S73jFcxHQaYL.keys()) and XWF8TzhJ1AyCnLQMNdgx in fOvbZi0eUThMK5S73jFcxHQaYL[Y5aocS7P8KTev6g]:
				KKbueGS4Ln.append(('مسح من '+keG09YwarCOi7qcBfgTbUmSL1X8W5,'RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_REMOVE1)'))
			else: KKbueGS4Ln.append(('إضافة ل'+keG09YwarCOi7qcBfgTbUmSL1X8W5,'RunPlugin('+cZpwfuO6A8SMzGiDjmWFy+'&context='+Y5aocS7P8KTev6g+'_ADD1)'))
	gut39MaSksfKTw = []
	for iRj7hkXewFAzLcpPy,Gx8KXPa7B9t64n in KKbueGS4Ln:
		iRj7hkXewFAzLcpPy = QNR6tCevIGEZKX3rAVsP+iRj7hkXewFAzLcpPy+XOVRfitWJP1zL3p2CMYF
		gut39MaSksfKTw.append((iRj7hkXewFAzLcpPy,Gx8KXPa7B9t64n,))
	return gut39MaSksfKTw