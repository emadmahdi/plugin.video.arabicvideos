# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ARABICTOONS'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_ART_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==730: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==731: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==732: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==733: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==734: lfZmugQCFKLGT05AH29IsMiho = rxWlBzjGSsVheNYucR3g(url)
	elif mode==735: lfZmugQCFKLGT05AH29IsMiho = kkSAusbhc7iO3845UHWBJ6Z(url)
	elif mode==739: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,739,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'افلام',j1IFsik4ouNePZr+'/movies.php',731)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات',j1IFsik4ouNePZr+'/cartoon.php',734)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مميزة',j1IFsik4ouNePZr+'/top.php',735)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أحدث الأفلام المضافة',j1IFsik4ouNePZr,731,'','','LATEST_MOVIES')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أحدث المسلسلات المضافة',j1IFsik4ouNePZr,731,'','','LATEST_SERIES')
	return
def rxWlBzjGSsVheNYucR3g(url):
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الكل',url,731)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-SERIES_SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('label="navigation"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("href='(.*?)'>(.*?)</a>",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = 'حرف '+title
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,731)
	return
def kkSAusbhc7iO3845UHWBJ6Z(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-SERIES_FEATURED-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="slider"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			title = title.strip(qE4nB3mKWHs)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,733,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,pbmcw9i1kfuNIQzJ7aGd3l0):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("class='moviesBlocks(.*?)list-group",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if pbmcw9i1kfuNIQzJ7aGd3l0=='LATEST_SERIES': drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[1]
	else: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
		title = title.strip(qE4nB3mKWHs)
		if 'movies.php' in url or pbmcw9i1kfuNIQzJ7aGd3l0=='LATEST_MOVIES':
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,732,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,733,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[-1]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title.strip(qE4nB3mKWHs)
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,731)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("class='moviesBlocks(.*?)script",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,QoM9jpdrNx4CZgXPY3vcU in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			title = title.strip(qE4nB3mKWHs)
			title = title+qE4nB3mKWHs+QoM9jpdrNx4CZgXPY3vcU.strip(qE4nB3mKWHs)
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,732,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('source src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
		cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0]
		if 'Referer=' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'|Referer=https://www.arabic-toons.com'
		qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=__embed')
	else:
		gN3Zy64SACrKaqFTBdDELtQxWk = X2XorVqHjLkWeCchY4u9fSz.findall(r'dynamique.*?}\);', LCK8lO2yRWaTVEQcdjPXAzpFBe9, X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not gN3Zy64SACrKaqFTBdDELtQxWk: gN3Zy64SACrKaqFTBdDELtQxWk = X2XorVqHjLkWeCchY4u9fSz.findall(r'dynamique.*?}\)', LCK8lO2yRWaTVEQcdjPXAzpFBe9, X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if gN3Zy64SACrKaqFTBdDELtQxWk:
			FoXVR4vZfTsgerG27aYb0pqC = gN3Zy64SACrKaqFTBdDELtQxWk[0]
			nwxZMEtrohO7YJDk = dict(X2XorVqHjLkWeCchY4u9fSz.findall(r'(\w+):\s*"([^"]+)"', FoXVR4vZfTsgerG27aYb0pqC))
			yN4EPtXBMcqTuKGkHo = X2XorVqHjLkWeCchY4u9fSz.search(r'const\s+(\w+)', FoXVR4vZfTsgerG27aYb0pqC)
			vaNAKXHVj0mLPW9I68213R = yN4EPtXBMcqTuKGkHo.group(1) if yN4EPtXBMcqTuKGkHo else ""
			keys = X2XorVqHjLkWeCchY4u9fSz.findall(r'\$\{' + vaNAKXHVj0mLPW9I68213R + r'\.(\w+)\}', FoXVR4vZfTsgerG27aYb0pqC)
			if nwxZMEtrohO7YJDk and keys:
				cOn6JqZlmQbjtT = "%s://%s/%s?%s" % (nwxZMEtrohO7YJDk[keys[0]], nwxZMEtrohO7YJDk[keys[1]], nwxZMEtrohO7YJDk[keys[2]], nwxZMEtrohO7YJDk[keys[3]])
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=__embed')
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'%20')
	bQGVWFxKS4D6p9YC7XPyA8Os = [SebHIf2jL1TBgrMKJu,'m']
	JFsnEmbRzSf8aVy5GZ9k = ['مسلسلات','افلام']
	if showDialogs:
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر النوع المطلوب:', JFsnEmbRzSf8aVy5GZ9k)
		if QQea1XbjZDEMhp==-1: return
	else: QQea1XbjZDEMhp = 0
	type = bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
	url = j1IFsik4ouNePZr+'/livesearch.php?'+type+'&q='+search
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABICTOONS-SEARCH-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)
		if type=='m': QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,732)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,733)
	return