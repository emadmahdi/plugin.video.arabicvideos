# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'FASELHD2'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_FH2_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][wvkDqmNZlJU52isXo]
jgvMWZhtPlBT = ['FaselHD']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==590: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==591: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==592: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==593: lfZmugQCFKLGT05AH29IsMiho = oaylPZ1DvdTh54(url,text)
	elif mode==599: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	VK4jU2G3s1PwkticQYyLoW = j1IFsik4ouNePZr
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',VK4jU2G3s1PwkticQYyLoW,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD2-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',VK4jU2G3s1PwkticQYyLoW,599,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<h3>(.*?)<.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qqai0c7OSNreCszImF23EhYV1KnXLx = wvkDqmNZlJU52isXo
	for title,cOn6JqZlmQbjtT in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr
		title = title.strip(qE4nB3mKWHs)
		if any(value in title for value in jgvMWZhtPlBT): continue
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,591,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured'+str(qqai0c7OSNreCszImF23EhYV1KnXLx))
		qqai0c7OSNreCszImF23EhYV1KnXLx += nyUIsfd53EGot9vbj0XDeq
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"main-menu"(.*?)</nav>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
		Ay2QFpLmwX30lriJnIHYG = X2XorVqHjLkWeCchY4u9fSz.findall('<li (.*?)</li>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for utk5Dor0c4fOpClX9gZI62NK in Ay2QFpLmwX30lriJnIHYG:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',utk5Dor0c4fOpClX9gZI62NK,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,591)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,ZZW5QJxjDlBLpGHA=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD2-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = []
	if 'featured' in ZZW5QJxjDlBLpGHA:
		qqai0c7OSNreCszImF23EhYV1KnXLx = ZZW5QJxjDlBLpGHA[-nyUIsfd53EGot9vbj0XDeq]
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"boxes--holder"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[int(qqai0c7OSNreCszImF23EhYV1KnXLx)]
	elif ZZW5QJxjDlBLpGHA=='filters':
		k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('\\/','/').replace('\\"','"')]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"boxes--holder"(.*?)"pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	aLlVEzy8XR62 = []
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		title = title.strip(qE4nB3mKWHs)
		try: title = title.encode(GOrf6A4JzH7uyLCEIiKVhoQFm).decode(Tv08xsf9HOqunIVUPdK1)
		except: pass
		title = cvlHmV1Kr0FIYSjNnM(title)
		if any(value in title.lower() for value in jgvMWZhtPlBT): continue
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '/movseries/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,591,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx:
			title = '_MOD_'+Wj39BaH6oEmstx[0][0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,593,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif any(value in title for value in YT8EVG4D1vOubScAHUazRNB5): QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,592,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,593,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if ZZW5QJxjDlBLpGHA=='filters':
		aOcSDH75NIYFk8fP = X2XorVqHjLkWeCchY4u9fSz.findall('"more_button_page":(.*?),',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if aOcSDH75NIYFk8fP:
			count = aOcSDH75NIYFk8fP[0]
			cOn6JqZlmQbjtT = url+'/offset/'+count
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة أخرى',cOn6JqZlmQbjtT,591,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
	elif 'featured' not in ZZW5QJxjDlBLpGHA:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = cvlHmV1Kr0FIYSjNnM(title)
				cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,591,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'details4')
	return
def oaylPZ1DvdTh54(url,data=SebHIf2jL1TBgrMKJu):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD2-SEASONS_EPISODES-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = '"EpisodesList"'+Bc5IUelt4sWvMXTdy.content+'</div>'
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD2-SEASONS_EPISODES-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	i3iEyeZ8BQmpDNornRVxTzwdYcX7 = X2XorVqHjLkWeCchY4u9fSz.findall('"inner--image"><img src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = i3iEyeZ8BQmpDNornRVxTzwdYcX7[wvkDqmNZlJU52isXo] if i3iEyeZ8BQmpDNornRVxTzwdYcX7 else SebHIf2jL1TBgrMKJu
	items = []
	if not data:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"SeasonsList"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if len(items)>1:
				for vdYW0jGmuUQCMq3no9KRs,yZfHYbEdxgemqNFoL8OSrR,title in items:
					cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					bIGXajdcK6PQBs = 'season='+yZfHYbEdxgemqNFoL8OSrR+'&post_id='+vdYW0jGmuUQCMq3no9KRs
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,593,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,bIGXajdcK6PQBs)
		data = BBX9RAuxnyGZ4WIF2TrhYeom3
	if data and len(items)<JhTts2R43AxkM8bYanKVy:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"EpisodesList"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<em>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,o7MeOx6PDA1d,sABprza7wEOC0Fd3PTQ in items:
				title = o7MeOx6PDA1d+qE4nB3mKWHs+sABprza7wEOC0Fd3PTQ
				title = title.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,592,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	url = url.strip('/')+'/watch/'
	qOGEcWZIwex2fK,r4v9gIZARuz10a,zKhpx40Tsegb5ivIf = [],[],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD2-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Vy5bgtTnfZmI9OJ4sDr1 = X2XorVqHjLkWeCchY4u9fSz.findall('العمر :.*?<strong">(.*?)</strong>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Vy5bgtTnfZmI9OJ4sDr1 and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,Vy5bgtTnfZmI9OJ4sDr1): return
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('<iframe src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=__embed')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"main--contents"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for bNWgancpjqo2,vdYW0jGmuUQCMq3no9KRs,title in items:
			title = title.strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+vdYW0jGmuUQCMq3no9KRs+'&i='+bNWgancpjqo2
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+title+'__watch')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"downloads"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name in items:
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+name+'__download')
	for lgX3GQwmTisx9tjMSPFUeEZ in qOGEcWZIwex2fK:
		cOn6JqZlmQbjtT,name = lgX3GQwmTisx9tjMSPFUeEZ.split('?named')
		if cOn6JqZlmQbjtT not in r4v9gIZARuz10a:
			r4v9gIZARuz10a.append(cOn6JqZlmQbjtT)
			zKhpx40Tsegb5ivIf.append(lgX3GQwmTisx9tjMSPFUeEZ)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(zKhpx40Tsegb5ivIf,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	VK4jU2G3s1PwkticQYyLoW = j1IFsik4ouNePZr
	url = VK4jU2G3s1PwkticQYyLoW+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'details5')
	return