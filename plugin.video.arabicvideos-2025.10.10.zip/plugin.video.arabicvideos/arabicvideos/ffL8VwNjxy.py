# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ALARAB'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_KLA_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==10: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==11: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==12: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==13: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==14: lfZmugQCFKLGT05AH29IsMiho = K6W3ZDiCchTvt48oVF9re()
	elif mode==15: lfZmugQCFKLGT05AH29IsMiho = vIY2kEZgiypeFhr6dS7tCs81oMu0()
	elif mode==16: lfZmugQCFKLGT05AH29IsMiho = DMRrsW5XoALhmCbJIcQn0ewa9()
	elif mode==19: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,19,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'آخر الإضافات',SebHIf2jL1TBgrMKJu,14)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان',SebHIf2jL1TBgrMKJu,15)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'ALARAB-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('id="nav-slider"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	y5qzXAYG4ne = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',y5qzXAYG4ne,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,11)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="navbar"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	Q4idDwN25EKRJCajSyc = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',Q4idDwN25EKRJCajSyc,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,11)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def vIY2kEZgiypeFhr6dS7tCs81oMu0():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جميع المسلسلات العربية',j1IFsik4ouNePZr+'/view-8/مسلسلات-عربية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات السنة الأخيرة',SebHIf2jL1TBgrMKJu,16)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان الأخيرة 1',j1IFsik4ouNePZr+'/view-8/مسلسلات-رمضان-2022',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان الأخيرة 2',j1IFsik4ouNePZr+'/view-8/مسلسلات-رمضان-2023',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2023',j1IFsik4ouNePZr+'/ramadan2023/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2022',j1IFsik4ouNePZr+'/ramadan2022/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2021',j1IFsik4ouNePZr+'/ramadan2021/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2020',j1IFsik4ouNePZr+'/ramadan2020/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2019',j1IFsik4ouNePZr+'/ramadan2019/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2018',j1IFsik4ouNePZr+'/ramadan2018/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2017',j1IFsik4ouNePZr+'/ramadan2017/مصرية',11)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات رمضان 2016',j1IFsik4ouNePZr+'/ramadan2016/مصرية',11)
	return
def K6W3ZDiCchTvt48oVF9re():
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,True,'ALARAB-LATEST-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('heading-top(.*?)div class=',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]+k2pC30UArFeg7Ru9tGiZlSmzQ[1]
	items=X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
		if 'series' in url: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,11,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,12,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,True,True,'ALARAB-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('video-category(.*?)right_content',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	qpkP6YyXi07ea9AcEH2Ozsl = False
	items = X2XorVqHjLkWeCchY4u9fSz.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62,DF7AOoSqL9jK6Gs8NtZHkUTzrYwd = [],[]
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		if title==SebHIf2jL1TBgrMKJu: title = cOn6JqZlmQbjtT.split('/')[-1].replace('-',qE4nB3mKWHs)
		N6zTbPqn0IFo9 = X2XorVqHjLkWeCchY4u9fSz.findall('(\d+)',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if N6zTbPqn0IFo9: N6zTbPqn0IFo9 = int(N6zTbPqn0IFo9[0])
		else: N6zTbPqn0IFo9 = 0
		DF7AOoSqL9jK6Gs8NtZHkUTzrYwd.append([tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9])
	DF7AOoSqL9jK6Gs8NtZHkUTzrYwd = sorted(DF7AOoSqL9jK6Gs8NtZHkUTzrYwd, reverse=True, key=lambda key: key[3])
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9 in DF7AOoSqL9jK6Gs8NtZHkUTzrYwd:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',SebHIf2jL1TBgrMKJu)
		title = title.replace('عالية على العرب',SebHIf2jL1TBgrMKJu)
		title = title.replace('مشاهدة مباشرة',SebHIf2jL1TBgrMKJu)
		title = title.replace('اون لاين',SebHIf2jL1TBgrMKJu)
		title = title.replace('اونلاين',SebHIf2jL1TBgrMKJu)
		title = title.replace('بجودة عالية',SebHIf2jL1TBgrMKJu)
		title = title.replace('جودة عالية',SebHIf2jL1TBgrMKJu)
		title = title.replace('بدون تحميل',SebHIf2jL1TBgrMKJu)
		title = title.replace('على العرب',SebHIf2jL1TBgrMKJu)
		title = title.replace('مباشرة',SebHIf2jL1TBgrMKJu)
		title = title.strip(qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		title = '_MOD_'+title
		sABprza7wEOC0Fd3PTQ = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx: sABprza7wEOC0Fd3PTQ = Wj39BaH6oEmstx[0]
		if sABprza7wEOC0Fd3PTQ not in aLlVEzy8XR62:
			aLlVEzy8XR62.append(sABprza7wEOC0Fd3PTQ)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,cOn6JqZlmQbjtT,13,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				qpkP6YyXi07ea9AcEH2Ozsl = True
			elif 'series' in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,11,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				qpkP6YyXi07ea9AcEH2Ozsl = True
			else:
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,12,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				qpkP6YyXi07ea9AcEH2Ozsl = True
	if qpkP6YyXi07ea9AcEH2Ozsl:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,Q8A5HyT1fGNxZv4X3V7eC in items:
			url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+Q8A5HyT1fGNxZv4X3V7eC,url,11)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'ALARAB-EPISODES-1st')
	umU6RZ2DvLlpPFA = X2XorVqHjLkWeCchY4u9fSz.findall('href="(/series.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qg7Nr1dCaD = j1IFsik4ouNePZr+umU6RZ2DvLlpPFA[0]
	lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,url,SebHIf2jL1TBgrMKJu,headers,True,'ALARAB-PLAY-1st')
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('class="resp-iframe" src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if qg7Nr1dCaD:
		qg7Nr1dCaD = qg7Nr1dCaD[0]
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('^(http.*?)(http.*?)$',qg7Nr1dCaD,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			cZs2GKDIAnwSryJ0R7m3 = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0][0]
			RBLIFCn0VMetmhGvXpkDWOTsigxQ,LLeV4UjfKH1 = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0][1].rsplit('/',1)
			iGxH2fsuScPtkJb7ECg = RBLIFCn0VMetmhGvXpkDWOTsigxQ+'?named=__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(iGxH2fsuScPtkJb7ECg)
			vz42ouckGgElI = cZs2GKDIAnwSryJ0R7m3+LLeV4UjfKH1
		else:
			O3XeD9sgNyH = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,False,'ALARAB-PLAY-2nd')
			qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('"src": "(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if qg7Nr1dCaD:
				qg7Nr1dCaD = qg7Nr1dCaD[0]+'?named=__watch__m3u8'
				bQGVWFxKS4D6p9YC7XPyA8Os.append(qg7Nr1dCaD)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('searchBox(.*?)<style>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if qg7Nr1dCaD:
			qg7Nr1dCaD = qg7Nr1dCaD[0]+'?named=__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(qg7Nr1dCaD)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def DMRrsW5XoALhmCbJIcQn0ewa9():
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,True,'ALARAB-RAMADAN-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="content_sec"(.*?)id="left_content"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	ErfPBhwtCK8q3ID = X2XorVqHjLkWeCchY4u9fSz.findall('/ramadan([0-9]+)/',str(items),X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	ErfPBhwtCK8q3ID = ErfPBhwtCK8q3ID[0]
	for cOn6JqZlmQbjtT,title in items:
		url = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)+qE4nB3mKWHs+ErfPBhwtCK8q3ID
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,11)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + "/q/" + t2WLY7DxIZs
	lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return