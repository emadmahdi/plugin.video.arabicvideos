# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from sK1pAJibxN import *
SITESURLS = {
			 uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡇࡈࡘࡃࡎࠫே")		:[C3w6qluao7EzUxJgMGBtV(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨை")]
			,Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࡂࡍࡒࡅࡒ࠭௉")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬொ")]
			,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡄࡏ࡜ࡇࡍࠨோ")		:[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸࠪௌ")]
			,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋ்ࠧ")	:[ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡯ࡼࡧ࡭࠯ࡶࡸࡦࡪ࠭௎")]
			,fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ௏")		:[bcNqYtfET5l92dLGjyZSPe(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭ௐ")]
			,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩ௑")		:[DQIrVcKuY6bJv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮ࡰࡷࡹࡨࡡ࠯ࡶࡹࠫ௒")]
			,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ௓")		:[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡪ࡯ࡨࡾ࡮ࡪ࠮ࡴࡪࡲࡻࠬ௔")]
			,sTGtHVyhQ9cJU37zxo2O(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ௕")	:[zpx2fPNKk6Ms38eD1vcO(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭௖")]
			,Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩௗ")		:[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ௘")]
			,gCkRKGhwcx26v(u"ࠩࡄ࡝ࡑࡕࡌࠨ௙")		:[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫࠮ࡢࡻ࡯ࡳࡱ࠴࡮ࡦࡶࠪ௚")]
			,sTGtHVyhQ9cJU37zxo2O(u"ࠫࡇࡕࡋࡓࡃࠪ௛")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩࡲࡩࡷࡧ࠱ࡧࡴ࠭௜")]
			,l7kBpMw5Qn(u"࠭ࡂࡓࡕࡗࡉࡏ࠭௝")		:[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ௞")]
			,HADrRCz9QgU4xudPJIqYb70(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ௟")		:[uqLUBHepfM3l6AyIzTJh80a(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ௠")]
			,C3w6qluao7EzUxJgMGBtV(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪ௡")		:[HADrRCz9QgU4xudPJIqYb70(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡤ࡫ࡰࡥ࠹ࡶ࠮ࡤࡱࡰࠫ௢")]
			,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ௣")		:[fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬ௤")]
			,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ௥")		:[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡱ࠳ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ௦")]
			,ALwOspNtXxZrz3PEKku(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ௧")		:[bcNqYtfET5l92dLGjyZSPe(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯ࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡤ࡮ࡸࡦࠬ௨")]
			,bcNqYtfET5l92dLGjyZSPe(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ௩")	:[vMhFypGLHZJbdX4O7oc3W8x(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡷࡸ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹࡨࡰࡲࠪ௪")]
			,l7kBpMw5Qn(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ௫")		:[zpx2fPNKk6Ms38eD1vcO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࠪ௬")]
			,wPnfgxKZdAv6T10(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ௭")		:[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡧࡴࡨࡩ࠳ࡼࡩࡱࠩ௮")]
			,DQIrVcKuY6bJv(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௯")	:[Ns6AJKH7DGpr19Wl5C3nF(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪ௰")]
			,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭௱")		:[l7kBpMw5Qn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫ௲")]
			,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ௳")		:[iDhLkZS6XBagNCQfs9tq2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡽࡨ࡯࡭ࡢ࠰ࡦࡧࠬ௴")]
			,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ௵")	:[zpx2fPNKk6Ms38eD1vcO(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ௶"),l7kBpMw5Qn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ௷"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡣࡵࡧ࡭࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ௸")]
			,Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩ௹")	:[DQIrVcKuY6bJv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠹࠳ࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨ௺")]
			,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ௻")		:[TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡨࡷࡧ࡭ࡢࡵ࠺࠲ࡳ࡫ࡴࠨ௼")]
			,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ௽")		:[t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡦࡶࡰࠪ௾")]
			,czvu7VQCZodkMf(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ௿")		:[ASkvf27etUK0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽ࠳ࡨࡥࡴࡶࠪఀ")]
			,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩఁ")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨం")]
			,zpx2fPNKk6Ms38eD1vcO(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫః")		:[j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪఄ")]
			,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬఅ")		:[HADrRCz9QgU4xudPJIqYb70(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬఆ")]
			,TVnqDYzWoM2UfHp0dchJ(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨఇ")		:[qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧఈ")]
			,gCkRKGhwcx26v(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫఉ")	:[sTGtHVyhQ9cJU37zxo2O(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠱ࡩࡱ࡯ࡦ࠯ࡰࡨࡻࡸ࠭ఊ")]
			,sTGtHVyhQ9cJU37zxo2O(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫఋ")		:[TVnqDYzWoM2UfHp0dchJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩఌ")]
			,TVnqDYzWoM2UfHp0dchJ(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ఍")	:[iDhLkZS6XBagNCQfs9tq2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫఎ")]
			,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨఏ")		:[Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡵ࠴ࡦࡢࡴࡨࡷࡰࡵ࠮࡯ࡧࡷࠫఐ")]
			,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ఑")		:[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩఒ")]
			,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡋࡕࡓࡕࡃࠪఓ")		:[vMhFypGLHZJbdX4O7oc3W8x(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩఔ")]
			,DQIrVcKuY6bJv(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧక")		:[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࠱ࡥࡱࡳࡥࡴࡪ࡮ࡥ࡭࠴࡮ࡦࡶࠪఖ")]
			,TVnqDYzWoM2UfHp0dchJ(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪగ")		:[ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦ࠳࡬ࡵࡴࡪࡤࡶ࠲ࡺࡶ࠯ࡥࡲࡱࠬఘ")]
			,HCiWF4jV1Q8(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨఙ")	:[DQIrVcKuY6bJv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡧࡷࡶ࡬ࡦࡸ࠮ࡷ࡫ࡧࡩࡴ࠭చ")]
			,vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧఛ")		:[C3w6qluao7EzUxJgMGBtV(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡩࡣ࡯ࡥࡨ࡯࡭ࡢ࠰ࡰࡩࡩ࡯ࡡࠨజ")]
			,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡊࡈࡌࡐࡒ࠭ఝ")		:[iDhLkZS6XBagNCQfs9tq2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩఞ"),HADrRCz9QgU4xudPJIqYb70(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪట"),AGlW9LqKN3Dvo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫఠ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠳࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭డ"),C3w6qluao7EzUxJgMGBtV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠿࠳࠯࠳࠼࠴࠳࠸࠴࠯࠳࠵࠶ࠬఢ")]
			,HCiWF4jV1Q8(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩణ")	:[AGlW9LqKN3Dvo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡤࡶࡧࡧ࡬ࡢ࠯ࡷࡺ࠳࡯ࡱࠨత")]
			,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪథ")		:[gCkRKGhwcx26v(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡺ࡫ࡰࡶ࠱ࡧࡦࡳࠧద")]
			,C3w6qluao7EzUxJgMGBtV(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫధ")		:[wPnfgxKZdAv6T10(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡵ࠯࡭࡬ࡶࡲࡧ࡬࡬࠰ࡦࡳࡲ࠭న")]
			,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ఩")		:[uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡣࡵࡳࡿࡧ࠮ࡪࡰ࡮ࠫప")]
			,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨఫ")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡰ࡮ࡴ࡫ࠨబ")]
			,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬభ")	:[Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮࡮ࡣࡶࡥ࠳ࡴࡥࡸࡵࠪమ")]
			,Ns6AJKH7DGpr19Wl5C3nF(u"ࠫࡕࡇࡎࡆࡖࠪయ")		:[czvu7VQCZodkMf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧర")]
			,zpx2fPNKk6Ms38eD1vcO(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨఱ")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫࠲ࡩࡲࡧࡤࡠࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡰ࡮ࡧ࠳࡮ࡴࡤࡦࡺ࠱࡬ࡹࡳ࡬ࠨల")]
			,zpx2fPNKk6Ms38eD1vcO(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬళ")	:[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦ࠴ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧ࠱ࡧࡦࡳࠧఴ")]
			,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬవ")		:[l7kBpMw5Qn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹࠺ࡵ࠯ࡦࡤࡽࠬశ")]
			,ypO63g8oJEsDnPBHSuU7lMTZr(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠲ࠨష")	:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰ࡩࡳࡷࡻ࡭ࠨస")]
			,czvu7VQCZodkMf(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫహ")	:[TVnqDYzWoM2UfHp0dchJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧ఺")]
			,fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡖࡌࡔࡌࡈࡂࠩ఻")		:[uqLUBHepfM3l6AyIzTJh80a(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼ఼ࠧ")]
			,AGlW9LqKN3Dvo(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ఽ")		:[NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬా"),wPnfgxKZdAv6T10(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ి"),l7kBpMw5Qn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪీ")]
			,C3w6qluao7EzUxJgMGBtV(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪు")		:[j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡳࡩࡱࡲࡪࡳ࡫ࡴ࠯ࡱࡱࡰ࡮ࡴࡥࠨూ")]
			,czvu7VQCZodkMf(u"ࠪࡘࡎࡑࡁࡂࡖࠪృ")		:[bcNqYtfET5l92dLGjyZSPe(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡬ࡣࡤࡸ࠳ࡴࡥࡵࠩౄ")]
			,zpx2fPNKk6Ms38eD1vcO(u"࡚ࠬࡖࡇࡗࡑࠫ౅")		:[j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫె")]
			,TVnqDYzWoM2UfHp0dchJ(u"ࠧࡗࡃࡕࡆࡔࡔࠧే")		:[vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰ࠲ࡻࡧࡲࡣࡱࡱ࠲ࡨࡧ࡭ࠨై")]
			,Gykx0wL3XrlWaujsqKP9n2Q(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭౉")	:[uqLUBHepfM3l6AyIzTJh80a(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡲࡸࡧࡥ࡮࠰ࡱࡩࡹ࠭ొ")]
			,HCiWF4jV1Q8(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬో")		:[Ns6AJKH7DGpr19Wl5C3nF(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡳࡩࡱࡺࠫౌ")]
			,czvu7VQCZodkMf(u"࠭ࡗࡆࡅࡌࡑࡆ࠸్ࠧ")		:[HADrRCz9QgU4xudPJIqYb70(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡥ࡯࡭ࡨࡱࠧ౎")]
			,DQIrVcKuY6bJv(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ౏")		:[fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ౐")]
			,ASkvf27etUK0(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ౑")		:[Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ౒")]
			,wPnfgxKZdAv6T10(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ౓")	:[Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩ౔")]
			,bcNqYtfET5l92dLGjyZSPe(u"ࠧࡊࡒࡗౕ࡚ࠬ")			:[SebHIf2jL1TBgrMKJu]
			,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡏ࠶ౖ࡙ࠬ")			:[SebHIf2jL1TBgrMKJu]
			,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡕࡉࡕࡕࡓࠨ౗")		:[ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪౘ"),gCkRKGhwcx26v(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨౙ"),wPnfgxKZdAv6T10(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩౚ")]
			,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪ౛")	:[VOALf8iYEnMdK0g(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ౜"),sTGtHVyhQ9cJU37zxo2O(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩౝ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ౞")]
			,VOALf8iYEnMdK0g(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧ౟")	:[HADrRCz9QgU4xudPJIqYb70(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩౠ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧౡ"),ASkvf27etUK0(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨౢ")]
			,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫౣ")	:[qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ౤"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ౥"),zpx2fPNKk6Ms38eD1vcO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ౦")]
			,gCkRKGhwcx26v(u"ࠫࡐࡕࡄࡊࡡࡖࡓ࡚ࡘࡃࡆࡕࠪ౧")	:[czvu7VQCZodkMf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯ࠧ౨"),HADrRCz9QgU4xudPJIqYb70(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡱ࡯ࡥ࡫ࠪ౩"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭౪")]
			,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡈࡌࡐࡊ࡙࡟ࡔࡑࡘࡖࡈࡋࡓࠨ౫"):[Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱࠩ౬")]
			,ASkvf27etUK0(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ౭")	:[wPnfgxKZdAv6T10(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ౮"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࠯ࡨࡺࡷ࠳ࡹࡴࡰࡴࡨࠫ౯")]
			}
if nyUIsfd53EGot9vbj0XDeq:
	SITESURLS[Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭౰")]      = [l7kBpMw5Qn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ౱"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭౲"),bcNqYtfET5l92dLGjyZSPe(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ౳"),wPnfgxKZdAv6T10(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ౴"),czvu7VQCZodkMf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ౵"),uqLUBHepfM3l6AyIzTJh80a(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ౶"),zpx2fPNKk6Ms38eD1vcO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ౷"),uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ౸"),wPnfgxKZdAv6T10(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ౹"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ౺"),zpx2fPNKk6Ms38eD1vcO(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭౻"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡺࡱࡸࡸࡺࡨࡥ࡯ࡵ࡬࡫ࠬ౼")]
	SITESURLS[DQIrVcKuY6bJv(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪ౽")] = [wPnfgxKZdAv6T10(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ౾"),l7kBpMw5Qn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ౿"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ಀ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩಁ"),iDhLkZS6XBagNCQfs9tq2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩಂ"),gCkRKGhwcx26v(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬಃ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ಄"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩಅ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪಆ"),zpx2fPNKk6Ms38eD1vcO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨಇ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧಈ"),wPnfgxKZdAv6T10(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭ಉ")]
	SITESURLS[bcNqYtfET5l92dLGjyZSPe(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩಊ")] = [C3w6qluao7EzUxJgMGBtV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨಋ"),zpx2fPNKk6Ms38eD1vcO(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬಌ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ಍"),AGlW9LqKN3Dvo(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧಎ"),ALwOspNtXxZrz3PEKku(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧಏ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪಐ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭಑"),iDhLkZS6XBagNCQfs9tq2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧಒ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨಓ"),TVnqDYzWoM2UfHp0dchJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ಔ"),TVnqDYzWoM2UfHp0dchJ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬಕ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡹࡰࡷࡷࡹࡧ࡫࡮ࡴ࡫ࡪࠫಖ")]
	SITESURLS[czvu7VQCZodkMf(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨಗ")] = [AGlW9LqKN3Dvo(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪಘ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧಙ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ಚ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩಛ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩಜ"),TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬಝ"),gCkRKGhwcx26v(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨಞ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩಟ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪಠ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨಡ"),gCkRKGhwcx26v(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧಢ"),ALwOspNtXxZrz3PEKku(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭ಣ")]
else:
	SITESURLS[DQIrVcKuY6bJv(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩತ")]      = [Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ಥ"),czvu7VQCZodkMf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪದ"),gCkRKGhwcx26v(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩಧ"),bcNqYtfET5l92dLGjyZSPe(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬನ"),C3w6qluao7EzUxJgMGBtV(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ಩"),ASkvf27etUK0(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨಪ"),l7kBpMw5Qn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫಫ"),wPnfgxKZdAv6T10(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬಬ"),zpx2fPNKk6Ms38eD1vcO(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ಭ"),VOALf8iYEnMdK0g(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫಮ"),HCiWF4jV1Q8(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪಯ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡾࡵࡵࡵࡷࡥࡩࡳࡹࡩࡨࠩರ")]
	SITESURLS[czvu7VQCZodkMf(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭ಱ")] = [l7kBpMw5Qn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬಲ"),HCiWF4jV1Q8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩಳ"),zpx2fPNKk6Ms38eD1vcO(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ಴"),fp6KV7DlS8QYniUczHdmZChL(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫವ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫಶ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧಷ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪಸ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫಹ"),bcNqYtfET5l92dLGjyZSPe(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ಺"),gCkRKGhwcx26v(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ಻"),bcNqYtfET5l92dLGjyZSPe(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴ಼ࠩ"),iDhLkZS6XBagNCQfs9tq2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡽࡴࡻࡴࡶࡤࡨࡲࡸ࡯ࡧࠨಽ")]
	SITESURLS[TVnqDYzWoM2UfHp0dchJ(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬಾ")] = [l7kBpMw5Qn(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫಿ"),iDhLkZS6XBagNCQfs9tq2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨೀ"),iDhLkZS6XBagNCQfs9tq2(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧು"),iDhLkZS6XBagNCQfs9tq2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪೂ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪೃ"),iDhLkZS6XBagNCQfs9tq2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ೄ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ೅"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪೆ"),iDhLkZS6XBagNCQfs9tq2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫೇ"),TVnqDYzWoM2UfHp0dchJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩೈ"),bcNqYtfET5l92dLGjyZSPe(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ೉"),czvu7VQCZodkMf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡼࡳࡺࡺࡵࡣࡧࡱࡷ࡮࡭ࠧೊ")]
	SITESURLS[Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫೋ")] = [ASkvf27etUK0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪೌ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺ್ࠧ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭೎"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ೏"),bcNqYtfET5l92dLGjyZSPe(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ೐"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ೑"),iDhLkZS6XBagNCQfs9tq2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ೒"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ೓"),sTGtHVyhQ9cJU37zxo2O(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ೔"),ALwOspNtXxZrz3PEKku(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨೕ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧೖ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭೗")]
api_python_actions = [fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ೘"),zpx2fPNKk6Ms38eD1vcO(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ೙"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ೚"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ೛"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ೜"),VOALf8iYEnMdK0g(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ೝ"),l7kBpMw5Qn(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩೞ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭೟"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧೠ"),l7kBpMw5Qn(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩೡ"),zpx2fPNKk6Ms38eD1vcO(u"ࠨࡇ࡛ࡉࡈ࡛ࡔࡆࡌࡖࠫೢ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࡑࡗࡎࡍࠧೣ")]
api_repos_actions = [C3w6qluao7EzUxJgMGBtV(u"ࠪࡅࡉࡊࡏࡏࡕࠪ೤"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭೥"),TVnqDYzWoM2UfHp0dchJ(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ೦")]
non_videos_actions = [uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡁࡍࡎࠪ೧"),l7kBpMw5Qn(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ೨"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ೩"),ASkvf27etUK0(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭೪"),DQIrVcKuY6bJv(u"ࠪࡖࡊࡖࡏࡔࠩ೫"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧ೬"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨ೭"),bcNqYtfET5l92dLGjyZSPe(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬ೮"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡈࡇࡗࡍࡉ࠭೯"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡕࡌࡘࡊ࡙ࡕࡓࡎࡖࠫ೰")]+api_python_actions+api_repos_actions
PGAlYK9BwWR = mrhSYXH2P8bO3eJAa9n
rrhvjIPfCsFXxqwHcQeES8JROG = BBX9RAuxnyGZ4WIF2TrhYeom3
ueAEcjiKlYqUV9d6nxXfo2CW = mrhSYXH2P8bO3eJAa9n
cHRgqtTNOuFn7DwJZ5d0h = mrhSYXH2P8bO3eJAa9n
avprivsnorestrict = mrhSYXH2P8bO3eJAa9n
avprivslongperiod = mrhSYXH2P8bO3eJAa9n
resolveonly = mrhSYXH2P8bO3eJAa9n
JJLAs5tXyUnSDGP = mrhSYXH2P8bO3eJAa9n
ALLOW_DNS_FIX = UTvNakRFQC
ALLOW_PROXY_FIX = UTvNakRFQC
ALLOW_SHOWDIALOGS_FIX = UTvNakRFQC
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫೱ"),zpx2fPNKk6Ms38eD1vcO(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ೲ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬೳ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ೴"),gCkRKGhwcx26v(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭೵"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ೶"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ೷"),Ns6AJKH7DGpr19Wl5C3nF(u"࡙ࠩࡅࡗࡈࡏࡏࠩ೸"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ೹"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡕࡇࡎࡆࡖࠪ೺"),ASkvf27etUK0(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ೻")]
BADWEBSITES += [tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ೼")]
BADCOMMONIDS = [gCkRKGhwcx26v(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫ೽"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬ೾")]
GEOLOCATION_DATA = SebHIf2jL1TBgrMKJu
AV_CLIENT_IDS = SebHIf2jL1TBgrMKJu
DNS_SERVERS = [ALwOspNtXxZrz3PEKku(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ೿"),l7kBpMw5Qn(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫഀ"),gCkRKGhwcx26v(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬഁ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ം"),DQIrVcKuY6bJv(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧഃ"),gCkRKGhwcx26v(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨഄ")]
busydialog_active = mrhSYXH2P8bO3eJAa9n
dns_succeeded_urls = []