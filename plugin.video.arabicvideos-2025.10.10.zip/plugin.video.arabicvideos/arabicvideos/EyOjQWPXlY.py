# -*- coding: utf-8 -*-
from RSdDifzoPG import *
pliQLY2RfzaWc = 'M3U'
f7FNoaT5AZL0VhnP = '_M3U_'
ppP12W3axbZF86XwDjinKueHMv = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
yyvVPZaFGkocX3LmSQ4eK = 4
def m1pvQKO9uURy8BP6zFYE0DL5VSlb(hL9fngBAu7XzOx,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf,GG8ETpSO0xyUZC7VJeP1sIk52WrN,adUemWgVECPGjZ1tX6lK2L3rzoORy4,MQcCbiOnpXkdwNfIe8Vj7ZuRW):
	global f7FNoaT5AZL0VhnP
	try:
		CVchuNWFazQbtmLE = str(MQcCbiOnpXkdwNfIe8Vj7ZuRW['folder'])
		f7FNoaT5AZL0VhnP = '_MU'+CVchuNWFazQbtmLE+'_'
	except: CVchuNWFazQbtmLE = SebHIf2jL1TBgrMKJu
	try: UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k = str(MQcCbiOnpXkdwNfIe8Vj7ZuRW['sequence'])
	except: UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k = SebHIf2jL1TBgrMKJu
	if   hL9fngBAu7XzOx==710: hoVT09XER3Jp6sL5 = iAtpmB1Qx3MhyKoUJRI6c()
	elif hL9fngBAu7XzOx==711: hoVT09XER3Jp6sL5 = IImhCotAy905xK7eBr1G6LRP(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	elif hL9fngBAu7XzOx==712: hoVT09XER3Jp6sL5 = ggcORVmIBx(CVchuNWFazQbtmLE)
	elif hL9fngBAu7XzOx==713: hoVT09XER3Jp6sL5 = r80WK6hJtdjaqwM(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf,adUemWgVECPGjZ1tX6lK2L3rzoORy4)
	elif hL9fngBAu7XzOx==714: hoVT09XER3Jp6sL5 = JJeq4MVI8NtCWkaOiQLTybrzUx(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf,adUemWgVECPGjZ1tX6lK2L3rzoORy4)
	elif hL9fngBAu7XzOx==715: hoVT09XER3Jp6sL5 = rRCw3hfy2Kq5l(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,GG8ETpSO0xyUZC7VJeP1sIk52WrN)
	elif hL9fngBAu7XzOx==716: hoVT09XER3Jp6sL5 = oL5YqnzjGwctAVpDZigOMkvC(CVchuNWFazQbtmLE,True)
	elif hL9fngBAu7XzOx==717: hoVT09XER3Jp6sL5 = Obn8a1c0P32FV6zHwjysokY(CVchuNWFazQbtmLE,True)
	elif hL9fngBAu7XzOx==718: hoVT09XER3Jp6sL5 = iyfkT8aDIvxCwMH3NrPzlghFJtYV(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==719: hoVT09XER3Jp6sL5 = Iyzm1FgGlSh0qUXVQCAHWbk3249JR(Yg36raSGA02uUXEPMF7itZd9KcWf,CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,adUemWgVECPGjZ1tX6lK2L3rzoORy4)
	elif hL9fngBAu7XzOx==720: hoVT09XER3Jp6sL5 = v5bLpYrNEozxBaR3cJyV(CVchuNWFazQbtmLE,True)
	elif hL9fngBAu7XzOx==721: hoVT09XER3Jp6sL5 = WJiMQRqo3gNOrLcw8X(CVchuNWFazQbtmLE)
	elif hL9fngBAu7XzOx==722: hoVT09XER3Jp6sL5 = DCAZNpaiQ1YHqBoXK6(CVchuNWFazQbtmLE)
	elif hL9fngBAu7XzOx==723: hoVT09XER3Jp6sL5 = JJpv8LUw4RNVlcEnim930gBbYfSq2d(CVchuNWFazQbtmLE)
	elif hL9fngBAu7XzOx==726: hoVT09XER3Jp6sL5 = DFu9XabE8s7NjfiVrhzWBpO(CVchuNWFazQbtmLE)
	elif hL9fngBAu7XzOx==729: hoVT09XER3Jp6sL5 = dOEXcDAyeZbv7rg(Yg36raSGA02uUXEPMF7itZd9KcWf,CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,adUemWgVECPGjZ1tX6lK2L3rzoORy4)
	else: hoVT09XER3Jp6sL5 = False
	return hoVT09XER3Jp6sL5
def iAtpmB1Qx3MhyKoUJRI6c():
	for CVchuNWFazQbtmLE in range(1,wenmP3hMQEXB8gRcIyOH2A7ai+1):
		f7FNoaT5AZL0VhnP = '_MU'+str(CVchuNWFazQbtmLE)+'_'
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قائمة مجلد '+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[CVchuNWFazQbtmLE],SebHIf2jL1TBgrMKJu,720,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	return
def v5bLpYrNEozxBaR3cJyV(CVchuNWFazQbtmLE=SebHIf2jL1TBgrMKJu,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=SebHIf2jL1TBgrMKJu):
	if CVchuNWFazQbtmLE:
		nbSRIUJfEXsqwiZB8HdCGuT = {'folder':CVchuNWFazQbtmLE}
		q1ycA8Oh4SbHdgL = SebHIf2jL1TBgrMKJu
	else:
		nbSRIUJfEXsqwiZB8HdCGuT = SebHIf2jL1TBgrMKJu
		q1ycA8Oh4SbHdgL = SebHIf2jL1TBgrMKJu
	j6jXbqQLUgfxPu = dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA)
	if not j6jXbqQLUgfxPu:
		QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+QNR6tCevIGEZKX3rAVsP+' إضافة وتغيير رابط'+q1ycA8Oh4SbHdgL+qE4nB3mKWHs+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[1]+' '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,711,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE,'sequence':1})
		QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+QNR6tCevIGEZKX3rAVsP+' جلب ملفات'+q1ycA8Oh4SbHdgL+' '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,712,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	else:
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'بحث في الملفات'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,729,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_',SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مصنفة مرتبة'+q1ycA8Oh4SbHdgL,'LIVE_GROUPED_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مصنفة من القسم'+q1ycA8Oh4SbHdgL,'LIVE_FROM_GROUP_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مصنفة من الاسم'+q1ycA8Oh4SbHdgL,'LIVE_FROM_NAME_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مصنفة بلا ترتيب'+q1ycA8Oh4SbHdgL,'LIVE_GROUPED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات بلا ترتيب'+q1ycA8Oh4SbHdgL,'LIVE_ORIGINAL_GROUPED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مجهولة مرتبة'+q1ycA8Oh4SbHdgL,'LIVE_UNKNOWN_GROUPED_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'قنوات مجهولة بلا ترتيب'+q1ycA8Oh4SbHdgL,'LIVE_UNKNOWN_GROUPED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'فيديوهات بلا ترتيب'+q1ycA8Oh4SbHdgL,'VOD_ORIGINAL_GROUPED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'فيديوهات مصنفة القسم'+q1ycA8Oh4SbHdgL,'VOD_FROM_GROUP_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'فيديوهات مصنفة من الاسم'+q1ycA8Oh4SbHdgL,'VOD_FROM_NAME_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'فيديوهات مجهولة بلا ترتيب'+q1ycA8Oh4SbHdgL,'VOD_UNKNOWN_GROUPED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'فيديوهات مجهولة مرتبة'+q1ycA8Oh4SbHdgL,'VOD_UNKNOWN_GROUPED_SORTED',713,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
		QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'إضافة وتغيير رابط'+q1ycA8Oh4SbHdgL+qE4nB3mKWHs+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[aiqnPAQRgtxh6u3Y5I27],SebHIf2jL1TBgrMKJu,711,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE,'sequence':aiqnPAQRgtxh6u3Y5I27})
	QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'جلب ملفات'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,712,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
	QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'مسح ملفات'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,717,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
	QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'عدد فيديوهات'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,721,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
	QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'Referer تغيير'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,726,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
	QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+'User-Agent تغيير'+q1ycA8Oh4SbHdgL,SebHIf2jL1TBgrMKJu,723,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,nbSRIUJfEXsqwiZB8HdCGuT)
	return
def oL5YqnzjGwctAVpDZigOMkvC(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	kQB0TCo4EeOvLIbcy,dTK1xazXvUQpsrg = False,SebHIf2jL1TBgrMKJu
	UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0 = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	pAMdWhXF4ixZs0vVSz2cRleCaPB,xHiS9Y7KpJrNVB,H3HVM6sZ9BWY5tjTnSv8,CXGdzKU5sZ2RLioarDJAugQ7O0Tx,lzieKYdcgvQxw35Ta2ZHUso = SqmJXwBQbok1apUIn(CVchuNWFazQbtmLE)
	if CXGdzKU5sZ2RLioarDJAugQ7O0Tx==SebHIf2jL1TBgrMKJu: return False,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	P63kUYjgATfKD = hxofMi1gL6FCEZqOXrctV9(CVchuNWFazQbtmLE)
	if pAMdWhXF4ixZs0vVSz2cRleCaPB:
		wVjeLJoR86yKY0PtSZWqfNHUz42 = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET',pAMdWhXF4ixZs0vVSz2cRleCaPB,SebHIf2jL1TBgrMKJu,P63kUYjgATfKD,False,SebHIf2jL1TBgrMKJu,'M3U-CHECK_ACCOUNT-1st')
		UqYxVcpsELuPR6tbCB4y173e8WAoT = wVjeLJoR86yKY0PtSZWqfNHUz42.content
		if wVjeLJoR86yKY0PtSZWqfNHUz42.succeeded:
			HALPdNfFuv1,VdGS5R1bnoZLcO7,qdgW7nLUhSp,SCadw4qBrFQ6V,PPJWnBRYycrZwFLkXtOmQv4D = 0,0,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
			try:
				AbwEWmFzZuaps1NhMiJUoQ5XD = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',UqYxVcpsELuPR6tbCB4y173e8WAoT)
				dTK1xazXvUQpsrg = AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['status']
				kQB0TCo4EeOvLIbcy = True
				qdgW7nLUhSp = AbwEWmFzZuaps1NhMiJUoQ5XD['server_info']['time_now']
			except: pass
			if qdgW7nLUhSp:
				try:
					aN1Yyq6VwxhGtSdBvgJRzsZ = uv8V4fE7j9pmgFr3wnDL.strptime(qdgW7nLUhSp,'%Y.%m.%d %H:%M:%S')
					HALPdNfFuv1 = int(uv8V4fE7j9pmgFr3wnDL.mktime(aN1Yyq6VwxhGtSdBvgJRzsZ))
					VdGS5R1bnoZLcO7 = int(H3a6hvAgeNctTiXF8d1uELfPr4y-HALPdNfFuv1)
					VdGS5R1bnoZLcO7 = int((VdGS5R1bnoZLcO7+900)/1800)*1800
				except: pass
				try:
					aN1Yyq6VwxhGtSdBvgJRzsZ = uv8V4fE7j9pmgFr3wnDL.localtime(int(AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['created_at']))
					SCadw4qBrFQ6V = uv8V4fE7j9pmgFr3wnDL.strftime('%Y.%m.%d %H:%M:%S',aN1Yyq6VwxhGtSdBvgJRzsZ)
				except: pass
				try:
					aN1Yyq6VwxhGtSdBvgJRzsZ = uv8V4fE7j9pmgFr3wnDL.localtime(int(AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['exp_date']))
					PPJWnBRYycrZwFLkXtOmQv4D = uv8V4fE7j9pmgFr3wnDL.strftime('%Y.%m.%d %H:%M:%S',aN1Yyq6VwxhGtSdBvgJRzsZ)
				except: pass
			MMAUZiw4CoJ8.setSetting('av.m3u.timestamp_'+CVchuNWFazQbtmLE,str(H3a6hvAgeNctTiXF8d1uELfPr4y))
			MMAUZiw4CoJ8.setSetting('av.m3u.timediff_'+CVchuNWFazQbtmLE,str(VdGS5R1bnoZLcO7))
			try:
				YY176KTrmM = '"server_info":'+UqYxVcpsELuPR6tbCB4y173e8WAoT.split('"server_info":')[1]
				YY176KTrmM = YY176KTrmM.replace(':',': ').replace(',',', ').replace('}}','}')
				m2Yq9b8CrFhHBIU = X2XorVqHjLkWeCchY4u9fSz.findall('"url": "(.*?)", "port": "(.*?)"',YY176KTrmM,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0 = m2Yq9b8CrFhHBIU[0]
			except: kQB0TCo4EeOvLIbcy = False
			if kQB0TCo4EeOvLIbcy and FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
				max = AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['max_connections']
				HEhdKeDr1zypMwLvxWPGf = AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['active_cons']
				AAiGvduXKJ = AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['is_trial']
				lIDPqcOJgdpHu = pAMdWhXF4ixZs0vVSz2cRleCaPB.split('?',1)
				FKe1TxU27G4SPo8hDER = 'URL:  '+E7r8hUCVvTiFQW0dBGXjxcy+pAMdWhXF4ixZs0vVSz2cRleCaPB+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\n\nStatus:  '+E7r8hUCVvTiFQW0dBGXjxcy+dTK1xazXvUQpsrg+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\nTrial:    '+E7r8hUCVvTiFQW0dBGXjxcy+str(AAiGvduXKJ=='1')+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\nCreated  At:  '+E7r8hUCVvTiFQW0dBGXjxcy+SCadw4qBrFQ6V+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\nExpiry Date:  '+E7r8hUCVvTiFQW0dBGXjxcy+PPJWnBRYycrZwFLkXtOmQv4D+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\nConnections   ( Active / Maximum ) :  '+E7r8hUCVvTiFQW0dBGXjxcy+HEhdKeDr1zypMwLvxWPGf+' / '+max+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\nAllowed Outputs:   '+E7r8hUCVvTiFQW0dBGXjxcy+" , ".join(AbwEWmFzZuaps1NhMiJUoQ5XD['user_info']['allowed_output_formats'])+XOVRfitWJP1zL3p2CMYF
				FKe1TxU27G4SPo8hDER += '\n\n'+YY176KTrmM
				if dTK1xazXvUQpsrg=='Active': zQgdTIC74ov('الاشتراك يعمل بدون مشاكل',FKe1TxU27G4SPo8hDER)
				else: zQgdTIC74ov('يبدو أن هناك مشكلة في الاشتراك',FKe1TxU27G4SPo8hDER)
	if pAMdWhXF4ixZs0vVSz2cRleCaPB and kQB0TCo4EeOvLIbcy and dTK1xazXvUQpsrg=='Active':
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+pAMdWhXF4ixZs0vVSz2cRleCaPB+' ]')
		EvLGmlhQNf1oe9b = True
	else:
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,'Checking M3U URL   [ Does not work ]   [ '+pAMdWhXF4ixZs0vVSz2cRleCaPB+' ]')
		if FZNQDXyeGo4fLUhR0dqPuBTEaIminA: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		EvLGmlhQNf1oe9b = False
	return EvLGmlhQNf1oe9b,UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0
def JJeq4MVI8NtCWkaOiQLTybrzUx(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz,Ieu9n6qE7r8AzT0ZRcyVl1mbj,mXTGIsJyaU4q,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	if not mXTGIsJyaU4q: mXTGIsJyaU4q = '1'
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA): return
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz)
	aHSGtr4TUoicgN3dzAVhClX2O9Y = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list',dbUDOSJX503jGWNHp6uz,Ieu9n6qE7r8AzT0ZRcyVl1mbj)
	pW4DPFU9OMn176HYlzZ0Q2dK = int(mXTGIsJyaU4q)*100
	EXmzDT7PweCousbJ9j1HUN5KI = pW4DPFU9OMn176HYlzZ0Q2dK-100
	for za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 in aHSGtr4TUoicgN3dzAVhClX2O9Y[EXmzDT7PweCousbJ9j1HUN5KI:pW4DPFU9OMn176HYlzZ0Q2dK]:
		FL3csJ942OehdbEo1m = ('GROUPED' in dbUDOSJX503jGWNHp6uz or dbUDOSJX503jGWNHp6uz=='ALL')
		LLQB8PpgaKUncRFqeS = ('GROUPED' not in dbUDOSJX503jGWNHp6uz and dbUDOSJX503jGWNHp6uz!='ALL')
		if FL3csJ942OehdbEo1m or LLQB8PpgaKUncRFqeS:
			if   'ARCHIVED'  in dbUDOSJX503jGWNHp6uz: qFsuKN7ngp.menuItemsLIST.append(['folder',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,718,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,'ARCHIVED',SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE}])
			elif 'EPG' 		 in dbUDOSJX503jGWNHp6uz: qFsuKN7ngp.menuItemsLIST.append(['folder',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,718,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,'FULL_EPG',SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE}])
			elif 'TIMESHIFT' in dbUDOSJX503jGWNHp6uz: qFsuKN7ngp.menuItemsLIST.append(['folder',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,718,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,'TIMESHIFT',SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE}])
			elif 'LIVE' 	 in dbUDOSJX503jGWNHp6uz: qFsuKN7ngp.menuItemsLIST.append(['live',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,715,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,za6XoDpqQx953L,{'folder':CVchuNWFazQbtmLE}])
			else: qFsuKN7ngp.menuItemsLIST.append(['video',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,715,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE}])
	pLDVsUXPZYvHS = len(aHSGtr4TUoicgN3dzAVhClX2O9Y)
	yfYnbslBTKrRvO0Zki(CVchuNWFazQbtmLE,mXTGIsJyaU4q,dbUDOSJX503jGWNHp6uz,714,pLDVsUXPZYvHS,Ieu9n6qE7r8AzT0ZRcyVl1mbj)
	return
def XlnJkgOdiVqTSe9BR83p0t51McZ(cFa47iSxqWvDHK):
	QUzFYoapm9jx('link',cFa47iSxqWvDHK+'هذه القائمة إما فارغة أو غير موجودة',SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('link',cFa47iSxqWvDHK+'أو الخدمة غير موجودة في اشتراكك',SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('link',cFa47iSxqWvDHK+'أو رابط M3U الذي أنت أضفته غير صحيح',SebHIf2jL1TBgrMKJu,9999)
	return
def r80WK6hJtdjaqwM(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz,Ieu9n6qE7r8AzT0ZRcyVl1mbj,mXTGIsJyaU4q,hgCzwec7t9=SebHIf2jL1TBgrMKJu,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	if not mXTGIsJyaU4q: mXTGIsJyaU4q = '1'
	cFa47iSxqWvDHK = f7FNoaT5AZL0VhnP
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA): return False
	if '__SERIES__' in Ieu9n6qE7r8AzT0ZRcyVl1mbj: HHvhf1OWxArXJFka6t7Bdb,VBEkv7WfQazcdFGKl1YuRsjh = Ieu9n6qE7r8AzT0ZRcyVl1mbj.split('__SERIES__')
	else: HHvhf1OWxArXJFka6t7Bdb,VBEkv7WfQazcdFGKl1YuRsjh = Ieu9n6qE7r8AzT0ZRcyVl1mbj,SebHIf2jL1TBgrMKJu
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz)
	E39uQUTpgcVCX64x1roPfRO5jWwkv = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list',dbUDOSJX503jGWNHp6uz,'__GROUPS__')
	if not E39uQUTpgcVCX64x1roPfRO5jWwkv: return False
	E7ikl4fBcaGWKQqyH = []
	for qEkx9gCLD8PvWuNf4lXTKsZebcwH,jF4H926vaGi3CVU5 in E39uQUTpgcVCX64x1roPfRO5jWwkv:
		if '===== ===== =====' in qEkx9gCLD8PvWuNf4lXTKsZebcwH:
			QUzFYoapm9jx('link',cFa47iSxqWvDHK+qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,9999)
			QUzFYoapm9jx('link',cFa47iSxqWvDHK+qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,9999)
			continue
		if hgCzwec7t9:
			if '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: cFa47iSxqWvDHK = 'SERIES'
			elif '!!__UNKNOWN__!!' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: cFa47iSxqWvDHK = 'UNKNOWN'
			elif 'LIVE' in dbUDOSJX503jGWNHp6uz: cFa47iSxqWvDHK = 'LIVE'
			else: cFa47iSxqWvDHK = 'VIDEOS'
			cFa47iSxqWvDHK = ','+E7r8hUCVvTiFQW0dBGXjxcy+cFa47iSxqWvDHK+': '+XOVRfitWJP1zL3p2CMYF
		if '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: b5fdsaWxAPRhMvSkVjzrJ9,rrNMbkBl0dR = qEkx9gCLD8PvWuNf4lXTKsZebcwH.split('__SERIES__')
		else: b5fdsaWxAPRhMvSkVjzrJ9,rrNMbkBl0dR = qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu
		if not Ieu9n6qE7r8AzT0ZRcyVl1mbj:
			if b5fdsaWxAPRhMvSkVjzrJ9 in E7ikl4fBcaGWKQqyH: continue
			E7ikl4fBcaGWKQqyH.append(b5fdsaWxAPRhMvSkVjzrJ9)
			if 'RANDOM' in hgCzwec7t9: QUzFYoapm9jx('folder',cFa47iSxqWvDHK+b5fdsaWxAPRhMvSkVjzrJ9,dbUDOSJX503jGWNHp6uz,168,SebHIf2jL1TBgrMKJu,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
			elif '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: QUzFYoapm9jx('folder',cFa47iSxqWvDHK+b5fdsaWxAPRhMvSkVjzrJ9,dbUDOSJX503jGWNHp6uz,713,SebHIf2jL1TBgrMKJu,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
			else: QUzFYoapm9jx('folder',cFa47iSxqWvDHK+b5fdsaWxAPRhMvSkVjzrJ9,dbUDOSJX503jGWNHp6uz,714,SebHIf2jL1TBgrMKJu,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
		elif '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH and b5fdsaWxAPRhMvSkVjzrJ9==HHvhf1OWxArXJFka6t7Bdb:
			if rrNMbkBl0dR in E7ikl4fBcaGWKQqyH: continue
			E7ikl4fBcaGWKQqyH.append(rrNMbkBl0dR)
			if 'RANDOM' in hgCzwec7t9: QUzFYoapm9jx('folder',cFa47iSxqWvDHK+rrNMbkBl0dR,dbUDOSJX503jGWNHp6uz,168,SebHIf2jL1TBgrMKJu,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
			else: QUzFYoapm9jx('folder',cFa47iSxqWvDHK+rrNMbkBl0dR,dbUDOSJX503jGWNHp6uz,714,jF4H926vaGi3CVU5,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	qFsuKN7ngp.menuItemsLIST[:] = sorted(qFsuKN7ngp.menuItemsLIST,reverse=False,key=lambda WbCSjAfYNB95pXz8awDqRZo: WbCSjAfYNB95pXz8awDqRZo[1].lower())
	if not hgCzwec7t9:
		pW4DPFU9OMn176HYlzZ0Q2dK = int(mXTGIsJyaU4q)*100
		EXmzDT7PweCousbJ9j1HUN5KI = pW4DPFU9OMn176HYlzZ0Q2dK-100
		pLDVsUXPZYvHS = len(qFsuKN7ngp.menuItemsLIST)
		qFsuKN7ngp.menuItemsLIST[:] = qFsuKN7ngp.menuItemsLIST[EXmzDT7PweCousbJ9j1HUN5KI:pW4DPFU9OMn176HYlzZ0Q2dK]
		yfYnbslBTKrRvO0Zki(CVchuNWFazQbtmLE,mXTGIsJyaU4q,dbUDOSJX503jGWNHp6uz,713,pLDVsUXPZYvHS,Ieu9n6qE7r8AzT0ZRcyVl1mbj)
	return True
def iyfkT8aDIvxCwMH3NrPzlghFJtYV(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,xAoktWqLPu024nj6biMU):
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,True): return
	P63kUYjgATfKD = hxofMi1gL6FCEZqOXrctV9(CVchuNWFazQbtmLE)
	HALPdNfFuv1 = MMAUZiw4CoJ8.getSetting('av.m3u.timestamp_'+CVchuNWFazQbtmLE)
	if not HALPdNfFuv1 or H3a6hvAgeNctTiXF8d1uELfPr4y-int(HALPdNfFuv1)>24*O1HZ23lDNf5YFo0:
		EvLGmlhQNf1oe9b,UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0 = oL5YqnzjGwctAVpDZigOMkvC(CVchuNWFazQbtmLE,False)
		if not EvLGmlhQNf1oe9b: return
	VdGS5R1bnoZLcO7 = int(MMAUZiw4CoJ8.getSetting('av.m3u.timediff_'+CVchuNWFazQbtmLE))
	H3HVM6sZ9BWY5tjTnSv8 = MMAUZiw4CoJ8.getSetting('av.m3u.server_'+CVchuNWFazQbtmLE)
	CXGdzKU5sZ2RLioarDJAugQ7O0Tx = MMAUZiw4CoJ8.getSetting('av.m3u.username_'+CVchuNWFazQbtmLE)
	lzieKYdcgvQxw35Ta2ZHUso = MMAUZiw4CoJ8.getSetting('av.m3u.password_'+CVchuNWFazQbtmLE)
	k3p2Tf6Gi5wIAr = vCsnpu14Zi7qUEQg3Tl50h.split('/')
	M0MropDdnmYtKWP3cklQfBjLa = k3p2Tf6Gi5wIAr[-1].replace('.ts',SebHIf2jL1TBgrMKJu).replace('.m3u8',SebHIf2jL1TBgrMKJu)
	if xAoktWqLPu024nj6biMU=='SHORT_EPG': vtauUMEyGI2xmBb9VnNc = 'get_short_epg'
	else: vtauUMEyGI2xmBb9VnNc = 'get_simple_data_table'
	pAMdWhXF4ixZs0vVSz2cRleCaPB,xHiS9Y7KpJrNVB,H3HVM6sZ9BWY5tjTnSv8,CXGdzKU5sZ2RLioarDJAugQ7O0Tx,lzieKYdcgvQxw35Ta2ZHUso = SqmJXwBQbok1apUIn(CVchuNWFazQbtmLE)
	if not CXGdzKU5sZ2RLioarDJAugQ7O0Tx: return
	y5yLH7vzsC4rAlmhW6ZF1xobfj9 = pAMdWhXF4ixZs0vVSz2cRleCaPB+'&action='+vtauUMEyGI2xmBb9VnNc+'&stream_id='+M0MropDdnmYtKWP3cklQfBjLa
	UqYxVcpsELuPR6tbCB4y173e8WAoT = OOHZils0Xw8DgSnbR7(RycFd7wZBiNhJjOPIGKp,y5yLH7vzsC4rAlmhW6ZF1xobfj9,SebHIf2jL1TBgrMKJu,P63kUYjgATfKD,SebHIf2jL1TBgrMKJu,'M3U-EPG_ITEMS-2nd')
	M782nmJwgjvZhdGT1xaDlU9c = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',UqYxVcpsELuPR6tbCB4y173e8WAoT)
	JSqAj4usypd9ciWXCm3v = M782nmJwgjvZhdGT1xaDlU9c['epg_listings']
	nwyLxm59BibWH = []
	if xAoktWqLPu024nj6biMU in ['ARCHIVED','TIMESHIFT']:
		for AbwEWmFzZuaps1NhMiJUoQ5XD in JSqAj4usypd9ciWXCm3v:
			if AbwEWmFzZuaps1NhMiJUoQ5XD['has_archive']==1:
				nwyLxm59BibWH.append(AbwEWmFzZuaps1NhMiJUoQ5XD)
				if xAoktWqLPu024nj6biMU in ['TIMESHIFT']: break
		if not nwyLxm59BibWH: return
		QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+E7r8hUCVvTiFQW0dBGXjxcy+'الملفات الأولي بهذه القائمة قد لا تعمل'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		if xAoktWqLPu024nj6biMU in ['TIMESHIFT']:
			QV7zv9ig6h5ZqdKyp = 2
			Xd5kFurD1wRzW = QV7zv9ig6h5ZqdKyp*O1HZ23lDNf5YFo0
			nwyLxm59BibWH = []
			nnJ9Q0CFRvd7 = int(int(AbwEWmFzZuaps1NhMiJUoQ5XD['start_timestamp'])/Xd5kFurD1wRzW)*Xd5kFurD1wRzW
			ZZv2KUrfks0N9mwSxOldMgEAJ = H3a6hvAgeNctTiXF8d1uELfPr4y+Xd5kFurD1wRzW
			dsKVSRUkoZ5mvfEnwOlJ489 = int((ZZv2KUrfks0N9mwSxOldMgEAJ-nnJ9Q0CFRvd7)/O1HZ23lDNf5YFo0)
			for w9PHIy57MmhkK4tFRuUYgJxpOeqVor in range(dsKVSRUkoZ5mvfEnwOlJ489):
				if w9PHIy57MmhkK4tFRuUYgJxpOeqVor>=6:
					if w9PHIy57MmhkK4tFRuUYgJxpOeqVor%QV7zv9ig6h5ZqdKyp!=0: continue
					soykuDEOSCFTbX9dic12KZmI = Xd5kFurD1wRzW
				else: soykuDEOSCFTbX9dic12KZmI = Xd5kFurD1wRzW//2
				ZWq2jesNEJS9Omyo1h = nnJ9Q0CFRvd7+w9PHIy57MmhkK4tFRuUYgJxpOeqVor*O1HZ23lDNf5YFo0
				AbwEWmFzZuaps1NhMiJUoQ5XD = {}
				AbwEWmFzZuaps1NhMiJUoQ5XD['title'] = SebHIf2jL1TBgrMKJu
				aN1Yyq6VwxhGtSdBvgJRzsZ = uv8V4fE7j9pmgFr3wnDL.localtime(ZWq2jesNEJS9Omyo1h-VdGS5R1bnoZLcO7-O1HZ23lDNf5YFo0)
				AbwEWmFzZuaps1NhMiJUoQ5XD['start'] = uv8V4fE7j9pmgFr3wnDL.strftime('%Y.%m.%d %H:%M:%S',aN1Yyq6VwxhGtSdBvgJRzsZ)
				AbwEWmFzZuaps1NhMiJUoQ5XD['start_timestamp'] = str(ZWq2jesNEJS9Omyo1h)
				AbwEWmFzZuaps1NhMiJUoQ5XD['stop_timestamp'] = str(ZWq2jesNEJS9Omyo1h+soykuDEOSCFTbX9dic12KZmI)
				nwyLxm59BibWH.append(AbwEWmFzZuaps1NhMiJUoQ5XD)
	elif xAoktWqLPu024nj6biMU in ['SHORT_EPG','FULL_EPG']: nwyLxm59BibWH = JSqAj4usypd9ciWXCm3v
	if xAoktWqLPu024nj6biMU=='FULL_EPG' and len(nwyLxm59BibWH)>0:
		QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+E7r8hUCVvTiFQW0dBGXjxcy+'هذه قائمة برامج القنوات (جدول فقط)ـ'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	EEOIM2tbFDzHuYlNX0efCp6iLR = []
	jF4H926vaGi3CVU5 = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Icon')
	for AbwEWmFzZuaps1NhMiJUoQ5XD in nwyLxm59BibWH:
		rrHSg187s0u35X9tMG = ej3oxQLc68OIY.b64decode(AbwEWmFzZuaps1NhMiJUoQ5XD['title'])
		if QBOMjKifEAFD: rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.decode(Tv08xsf9HOqunIVUPdK1)
		ZWq2jesNEJS9Omyo1h = int(AbwEWmFzZuaps1NhMiJUoQ5XD['start_timestamp'])
		U0ULhmJj4BCo1pzlbP = int(AbwEWmFzZuaps1NhMiJUoQ5XD['stop_timestamp'])
		EfligrUbYt6CxO3j8n7ZVLXJ4 = str(int((U0ULhmJj4BCo1pzlbP-ZWq2jesNEJS9Omyo1h+59)/60))
		rclOL57kpju = AbwEWmFzZuaps1NhMiJUoQ5XD['start'].replace(qE4nB3mKWHs,':')
		aN1Yyq6VwxhGtSdBvgJRzsZ = uv8V4fE7j9pmgFr3wnDL.localtime(ZWq2jesNEJS9Omyo1h-O1HZ23lDNf5YFo0)
		KWzyZLGkfaSplA1u8 = uv8V4fE7j9pmgFr3wnDL.strftime('%H:%M',aN1Yyq6VwxhGtSdBvgJRzsZ)
		srZe0nJEtxMFzPf31Y8dCah4yiOX = uv8V4fE7j9pmgFr3wnDL.strftime('%a',aN1Yyq6VwxhGtSdBvgJRzsZ)
		if xAoktWqLPu024nj6biMU=='SHORT_EPG': rrHSg187s0u35X9tMG = QNR6tCevIGEZKX3rAVsP+KWzyZLGkfaSplA1u8+' ـ '+rrHSg187s0u35X9tMG+XOVRfitWJP1zL3p2CMYF
		elif xAoktWqLPu024nj6biMU=='TIMESHIFT': rrHSg187s0u35X9tMG = srZe0nJEtxMFzPf31Y8dCah4yiOX+qE4nB3mKWHs+KWzyZLGkfaSplA1u8+' ('+EfligrUbYt6CxO3j8n7ZVLXJ4+'min)'
		else: rrHSg187s0u35X9tMG = srZe0nJEtxMFzPf31Y8dCah4yiOX+qE4nB3mKWHs+KWzyZLGkfaSplA1u8+' ('+EfligrUbYt6CxO3j8n7ZVLXJ4+'min)   '+rrHSg187s0u35X9tMG+' ـ'
		if xAoktWqLPu024nj6biMU in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			dlZ195BgFfe7mL = H3HVM6sZ9BWY5tjTnSv8+'/timeshift/'+CXGdzKU5sZ2RLioarDJAugQ7O0Tx+'/'+lzieKYdcgvQxw35Ta2ZHUso+'/'+EfligrUbYt6CxO3j8n7ZVLXJ4+'/'+rclOL57kpju+'/'+M0MropDdnmYtKWP3cklQfBjLa+'.m3u8'
			if xAoktWqLPu024nj6biMU=='FULL_EPG': QUzFYoapm9jx('link',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,dlZ195BgFfe7mL,9999,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
			else: QUzFYoapm9jx('video',f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,dlZ195BgFfe7mL,715,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
		EEOIM2tbFDzHuYlNX0efCp6iLR.append(rrHSg187s0u35X9tMG)
	if xAoktWqLPu024nj6biMU=='SHORT_EPG' and EEOIM2tbFDzHuYlNX0efCp6iLR: KEiSh3WLeMCX = Vfr2yFLvzdP0gJM5E4XjQbo(EEOIM2tbFDzHuYlNX0efCp6iLR)
	return EEOIM2tbFDzHuYlNX0efCp6iLR
def DCAZNpaiQ1YHqBoXK6(CVchuNWFazQbtmLE):
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,True): return
	H3HVM6sZ9BWY5tjTnSv8,acX47dl0UMyrT6qSmWO,ssuvZPz1DaUTIGiOyfWj7LVFJ2SN = SebHIf2jL1TBgrMKJu,0,0
	EvLGmlhQNf1oe9b,UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0 = oL5YqnzjGwctAVpDZigOMkvC(CVchuNWFazQbtmLE,False)
	if EvLGmlhQNf1oe9b:
		HN8GqSCbM4kKfweDcz59VOLTa7ZBdF = VbuRTd8mqrlspv2OCktGMSDya1Y(UUdEYmW0r3KCVcoI96TPNb4ln)
		acX47dl0UMyrT6qSmWO = ybWszHAnQkBxjVUDJha47(HN8GqSCbM4kKfweDcz59VOLTa7ZBdF[0],int(oBEhRy5bGlrvPXtwWLUYcg0))
		yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,'LIVE_GROUPED')
		ImXON32Eg40ZbwJB6 = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list','LIVE_GROUPED')
		aHSGtr4TUoicgN3dzAVhClX2O9Y = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list','LIVE_GROUPED',ImXON32Eg40ZbwJB6[1])
		vCsnpu14Zi7qUEQg3Tl50h = aHSGtr4TUoicgN3dzAVhClX2O9Y[0][2]
		AFkcB5RWN8SnMLsiX2HlGe0qTm6 = X2XorVqHjLkWeCchY4u9fSz.findall('://(.*?)/',vCsnpu14Zi7qUEQg3Tl50h,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		AFkcB5RWN8SnMLsiX2HlGe0qTm6 = AFkcB5RWN8SnMLsiX2HlGe0qTm6[0]
		if ':' in AFkcB5RWN8SnMLsiX2HlGe0qTm6: Tl5obFPxXBIVfUeCrHg0auyJAi318,uKJYwyUsa7NSGLXdog3T = AFkcB5RWN8SnMLsiX2HlGe0qTm6.split(':')
		else: Tl5obFPxXBIVfUeCrHg0auyJAi318,uKJYwyUsa7NSGLXdog3T = AFkcB5RWN8SnMLsiX2HlGe0qTm6,'80'
		os7HSg15JiWu0kmxz = VbuRTd8mqrlspv2OCktGMSDya1Y(Tl5obFPxXBIVfUeCrHg0auyJAi318)
		ssuvZPz1DaUTIGiOyfWj7LVFJ2SN = ybWszHAnQkBxjVUDJha47(os7HSg15JiWu0kmxz[0],int(uKJYwyUsa7NSGLXdog3T))
	if acX47dl0UMyrT6qSmWO and ssuvZPz1DaUTIGiOyfWj7LVFJ2SN:
		FKe1TxU27G4SPo8hDER = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		FKe1TxU27G4SPo8hDER += '\n\n'+'وقت ضائع في السيرفر الأصلي'+u43PVWjh7t9YwI+str(int(ssuvZPz1DaUTIGiOyfWj7LVFJ2SN*1000))+' ملي ثانية'
		FKe1TxU27G4SPo8hDER += '\n\n'+'وقت ضائع في السيرفر البديل'+u43PVWjh7t9YwI+str(int(acX47dl0UMyrT6qSmWO*1000))+' ملي ثانية'
		ffIQynE7HP3 = vvubxo631m2zYC('center','السيرفر الأصلي','السيرفر الأسرع',lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
		if ffIQynE7HP3==1 and acX47dl0UMyrT6qSmWO<ssuvZPz1DaUTIGiOyfWj7LVFJ2SN: H3HVM6sZ9BWY5tjTnSv8 = UUdEYmW0r3KCVcoI96TPNb4ln+':'+oBEhRy5bGlrvPXtwWLUYcg0
	else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'البرنامج لم يجد السيرفر البديل')
	MMAUZiw4CoJ8.setSetting('av.m3u.server_'+CVchuNWFazQbtmLE,H3HVM6sZ9BWY5tjTnSv8)
	return
def rRCw3hfy2Kq5l(CVchuNWFazQbtmLE,vCsnpu14Zi7qUEQg3Tl50h,GG8ETpSO0xyUZC7VJeP1sIk52WrN):
	CRbA6Tk21vPOIgVxKLsMdfrH8ey = MMAUZiw4CoJ8.getSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE)
	VEwlNCbSM5diDpFmP9Zeza4q2 = MMAUZiw4CoJ8.getSetting('av.m3u.referer_'+CVchuNWFazQbtmLE)
	if CRbA6Tk21vPOIgVxKLsMdfrH8ey or VEwlNCbSM5diDpFmP9Zeza4q2:
		vCsnpu14Zi7qUEQg3Tl50h += '|'
		if CRbA6Tk21vPOIgVxKLsMdfrH8ey: vCsnpu14Zi7qUEQg3Tl50h += '&User-Agent='+CRbA6Tk21vPOIgVxKLsMdfrH8ey
		if VEwlNCbSM5diDpFmP9Zeza4q2: vCsnpu14Zi7qUEQg3Tl50h += '&Referer='+VEwlNCbSM5diDpFmP9Zeza4q2
		vCsnpu14Zi7qUEQg3Tl50h = vCsnpu14Zi7qUEQg3Tl50h.replace('|&','|')
	nxW9asAySzOt2foFGT4LwmHNl8uZ(vCsnpu14Zi7qUEQg3Tl50h,pliQLY2RfzaWc,GG8ETpSO0xyUZC7VJeP1sIk52WrN)
	return
def JJpv8LUw4RNVlcEnim930gBbYfSq2d(CVchuNWFazQbtmLE):
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	CRbA6Tk21vPOIgVxKLsMdfrH8ey = MMAUZiw4CoJ8.getSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE)
	oyr9VZsOdg2PkRH = vvubxo631m2zYC('center','استخدام الأصلي','تعديل القديم',CRbA6Tk21vPOIgVxKLsMdfrH8ey,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if oyr9VZsOdg2PkRH==1: CRbA6Tk21vPOIgVxKLsMdfrH8ey = zWKdm3kV2ItwYrgH1BZyRON('أكتب ـM3U User-Agent جديد',CRbA6Tk21vPOIgVxKLsMdfrH8ey,True)
	else: CRbA6Tk21vPOIgVxKLsMdfrH8ey = 'Unknown'
	if CRbA6Tk21vPOIgVxKLsMdfrH8ey==qE4nB3mKWHs:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oyr9VZsOdg2PkRH = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,CRbA6Tk21vPOIgVxKLsMdfrH8ey,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if oyr9VZsOdg2PkRH!=1:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم الإلغاء')
		return
	MMAUZiw4CoJ8.setSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE,CRbA6Tk21vPOIgVxKLsMdfrH8ey)
	Pf2ucAvMDr38qy(CVchuNWFazQbtmLE)
	return
def DFu9XabE8s7NjfiVrhzWBpO(CVchuNWFazQbtmLE):
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	VEwlNCbSM5diDpFmP9Zeza4q2 = MMAUZiw4CoJ8.getSetting('av.m3u.referer_'+CVchuNWFazQbtmLE)
	oyr9VZsOdg2PkRH = vvubxo631m2zYC('center','استخدام الأصلي','تعديل القديم',VEwlNCbSM5diDpFmP9Zeza4q2,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if oyr9VZsOdg2PkRH==1: VEwlNCbSM5diDpFmP9Zeza4q2 = zWKdm3kV2ItwYrgH1BZyRON('أكتب ـM3U Referer جديد',VEwlNCbSM5diDpFmP9Zeza4q2,True)
	else: VEwlNCbSM5diDpFmP9Zeza4q2 = SebHIf2jL1TBgrMKJu
	if VEwlNCbSM5diDpFmP9Zeza4q2==qE4nB3mKWHs:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oyr9VZsOdg2PkRH = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,VEwlNCbSM5diDpFmP9Zeza4q2,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if oyr9VZsOdg2PkRH!=1:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم الإلغاء')
		return
	MMAUZiw4CoJ8.setSetting('av.m3u.referer_'+CVchuNWFazQbtmLE,VEwlNCbSM5diDpFmP9Zeza4q2)
	Pf2ucAvMDr38qy(CVchuNWFazQbtmLE)
	return
def SqmJXwBQbok1apUIn(CVchuNWFazQbtmLE,hDzMjSOPsa879ykW2Nlbqe6=SebHIf2jL1TBgrMKJu):
	if not koW0PD6fS8Y4NLzK9brAB2HhMVOa: koW0PD6fS8Y4NLzK9brAB2HhMVOa = MMAUZiw4CoJ8.getSetting('av.m3u.url_'+CVchuNWFazQbtmLE)
	H3HVM6sZ9BWY5tjTnSv8 = EDmwsQf1Px9k8h04oAHuObdnyrTGU(koW0PD6fS8Y4NLzK9brAB2HhMVOa,'url')
	CXGdzKU5sZ2RLioarDJAugQ7O0Tx = X2XorVqHjLkWeCchY4u9fSz.findall('username=(.*?)&',koW0PD6fS8Y4NLzK9brAB2HhMVOa+'&',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	lzieKYdcgvQxw35Ta2ZHUso = X2XorVqHjLkWeCchY4u9fSz.findall('password=(.*?)&',koW0PD6fS8Y4NLzK9brAB2HhMVOa+'&',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not CXGdzKU5sZ2RLioarDJAugQ7O0Tx or not lzieKYdcgvQxw35Ta2ZHUso:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	CXGdzKU5sZ2RLioarDJAugQ7O0Tx = CXGdzKU5sZ2RLioarDJAugQ7O0Tx[0]
	lzieKYdcgvQxw35Ta2ZHUso = lzieKYdcgvQxw35Ta2ZHUso[0]
	pAMdWhXF4ixZs0vVSz2cRleCaPB = H3HVM6sZ9BWY5tjTnSv8+'/player_api.php?username='+CXGdzKU5sZ2RLioarDJAugQ7O0Tx+'&password='+lzieKYdcgvQxw35Ta2ZHUso
	xHiS9Y7KpJrNVB = H3HVM6sZ9BWY5tjTnSv8+'/get.php?username='+CXGdzKU5sZ2RLioarDJAugQ7O0Tx+'&password='+lzieKYdcgvQxw35Ta2ZHUso+'&type=m3u_plus'
	return pAMdWhXF4ixZs0vVSz2cRleCaPB,xHiS9Y7KpJrNVB,H3HVM6sZ9BWY5tjTnSv8,CXGdzKU5sZ2RLioarDJAugQ7O0Tx,lzieKYdcgvQxw35Ta2ZHUso
def FXqfn2Ke9ywQ0txSGVN4bO(CVchuNWFazQbtmLE,ssp2bNVOYFIRljkyLZdHS6=SebHIf2jL1TBgrMKJu):
	Clf580vZO9Syic37 = ssp2bNVOYFIRljkyLZdHS6.replace('/','_').replace(':','_').replace('.','_')
	Clf580vZO9Syic37 = Clf580vZO9Syic37.replace('?','_').replace('=','_').replace('&','_')
	Clf580vZO9Syic37 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,Clf580vZO9Syic37).strip('.m3u')+'.m3u'
	return Clf580vZO9Syic37
def IImhCotAy905xK7eBr1G6LRP(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k):
	t3rq0wILWG8yV9YkonF4H = MMAUZiw4CoJ8.getSetting('av.m3u.url_'+CVchuNWFazQbtmLE+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	rG8BVHeuxMZdQvcXRP64LohKUEA1m = True
	if t3rq0wILWG8yV9YkonF4H:
		oyr9VZsOdg2PkRH = omIUAxNupsBHY0SGnJXzijltOyV('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',E7r8hUCVvTiFQW0dBGXjxcy+t3rq0wILWG8yV9YkonF4H+XOVRfitWJP1zL3p2CMYF+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if oyr9VZsOdg2PkRH==-1: return
		elif oyr9VZsOdg2PkRH==0: t3rq0wILWG8yV9YkonF4H = SebHIf2jL1TBgrMKJu
		elif oyr9VZsOdg2PkRH==2:
			oyr9VZsOdg2PkRH = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oyr9VZsOdg2PkRH in [-1,0]: return
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم مسح الرابط')
			rG8BVHeuxMZdQvcXRP64LohKUEA1m = False
			Z2Z1kslugY6iBAJw = SebHIf2jL1TBgrMKJu
	if rG8BVHeuxMZdQvcXRP64LohKUEA1m:
		Z2Z1kslugY6iBAJw = zWKdm3kV2ItwYrgH1BZyRON('اكتب رابط M3U كاملا',t3rq0wILWG8yV9YkonF4H)
		Z2Z1kslugY6iBAJw = Z2Z1kslugY6iBAJw.strip(qE4nB3mKWHs)
		if not Z2Z1kslugY6iBAJw:
			oyr9VZsOdg2PkRH = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oyr9VZsOdg2PkRH in [-1,0]: return
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم مسح الرابط')
		else:
			FKe1TxU27G4SPo8hDER = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			oyr9VZsOdg2PkRH = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'الرابط الجديد هو:',E7r8hUCVvTiFQW0dBGXjxcy+Z2Z1kslugY6iBAJw+XOVRfitWJP1zL3p2CMYF+'\n\n'+FKe1TxU27G4SPo8hDER)
			if oyr9VZsOdg2PkRH!=1:
				gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم الإلغاء')
				return
	MMAUZiw4CoJ8.setSetting('av.m3u.url_'+CVchuNWFazQbtmLE+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,Z2Z1kslugY6iBAJw)
	CRbA6Tk21vPOIgVxKLsMdfrH8ey = MMAUZiw4CoJ8.getSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE)
	if not CRbA6Tk21vPOIgVxKLsMdfrH8ey: MMAUZiw4CoJ8.setSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE,'Unknown')
	Pf2ucAvMDr38qy(CVchuNWFazQbtmLE)
	return
def JTZWsXjuNSrondg8cikfFEl5yq(mKguiz74rjwFLT1,DDbuBePlNwoUxC9qX45pFZ3z,uMml6tfO795iA8F,TxESQX19JtZrI4PF7sO3LVhdG,z9KGjXMWVyf0IemDZrwET,JINEq9VpDmzYy18AGKBu,xHiS9Y7KpJrNVB):
	aHSGtr4TUoicgN3dzAVhClX2O9Y,xxYWKpwVkeyENaA2zCPQf = [],[]
	WWuq10YTpDGMv3hmI7AacVjPJ = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for Ok5XpynWJh1eoRb2mvsGN7uEaKVHI in mKguiz74rjwFLT1:
		if JINEq9VpDmzYy18AGKBu%473==0:
			mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,40+int(10*JINEq9VpDmzYy18AGKBu/z9KGjXMWVyf0IemDZrwET),'قراءة الفيديوهات','الفيديو رقم:-',str(JINEq9VpDmzYy18AGKBu)+' / '+str(z9KGjXMWVyf0IemDZrwET))
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return None,None,None
		vCsnpu14Zi7qUEQg3Tl50h = X2XorVqHjLkWeCchY4u9fSz.findall('^(.*?)\n+((http|https|rtmp).*?)$',Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if vCsnpu14Zi7qUEQg3Tl50h:
			Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,vCsnpu14Zi7qUEQg3Tl50h,LAfHT4nUXqtMPm0y7uIR6OeBC = vCsnpu14Zi7qUEQg3Tl50h[0]
			vCsnpu14Zi7qUEQg3Tl50h = vCsnpu14Zi7qUEQg3Tl50h.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu)
			Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu)
		else:
			xxYWKpwVkeyENaA2zCPQf.append({'line':Ok5XpynWJh1eoRb2mvsGN7uEaKVHI})
			continue
		K463XmjqPLCTWwh7Sxr5zpkitRM,za6XoDpqQx953L,qEkx9gCLD8PvWuNf4lXTKsZebcwH,rrHSg187s0u35X9tMG,GG8ETpSO0xyUZC7VJeP1sIk52WrN,exckWH8MfoqFUAJI21gSQinud = {},SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,False
		try:
			Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,rrHSg187s0u35X9tMG = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.rsplit('",',1)
			Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI+'"'
		except:
			try: Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,rrHSg187s0u35X9tMG = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.rsplit('1,',1)
			except: rrHSg187s0u35X9tMG = SebHIf2jL1TBgrMKJu
		K463XmjqPLCTWwh7Sxr5zpkitRM['url'] = vCsnpu14Zi7qUEQg3Tl50h
		k7EQOW48tFaihSCDw9R = X2XorVqHjLkWeCchY4u9fSz.findall(' (.*?)="(.*?)"',Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for WbCSjAfYNB95pXz8awDqRZo,pJrRgH0Bvej2dNPzbSa1 in k7EQOW48tFaihSCDw9R:
			WbCSjAfYNB95pXz8awDqRZo = WbCSjAfYNB95pXz8awDqRZo.replace('"',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			K463XmjqPLCTWwh7Sxr5zpkitRM[WbCSjAfYNB95pXz8awDqRZo] = pJrRgH0Bvej2dNPzbSa1.strip(qE4nB3mKWHs)
		Gl1NAskXm5bfnLZctWr8V = list(K463XmjqPLCTWwh7Sxr5zpkitRM.keys())
		if not rrHSg187s0u35X9tMG:
			if 'name' in Gl1NAskXm5bfnLZctWr8V and K463XmjqPLCTWwh7Sxr5zpkitRM['name']: rrHSg187s0u35X9tMG = K463XmjqPLCTWwh7Sxr5zpkitRM['name']
		K463XmjqPLCTWwh7Sxr5zpkitRM['title'] = rrHSg187s0u35X9tMG.strip(qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		if 'logo' in Gl1NAskXm5bfnLZctWr8V:
			K463XmjqPLCTWwh7Sxr5zpkitRM['img'] = K463XmjqPLCTWwh7Sxr5zpkitRM['logo']
			del K463XmjqPLCTWwh7Sxr5zpkitRM['logo']
		else: K463XmjqPLCTWwh7Sxr5zpkitRM['img'] = SebHIf2jL1TBgrMKJu
		if 'group' in Gl1NAskXm5bfnLZctWr8V and K463XmjqPLCTWwh7Sxr5zpkitRM['group']: qEkx9gCLD8PvWuNf4lXTKsZebcwH = K463XmjqPLCTWwh7Sxr5zpkitRM['group']
		if any(value in vCsnpu14Zi7qUEQg3Tl50h.lower() for value in WWuq10YTpDGMv3hmI7AacVjPJ):
			exckWH8MfoqFUAJI21gSQinud = True if 'm3u' not in vCsnpu14Zi7qUEQg3Tl50h else False
		if exckWH8MfoqFUAJI21gSQinud or '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH or '__MOVIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH:
			GG8ETpSO0xyUZC7VJeP1sIk52WrN = 'VOD'
			if '__SERIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: GG8ETpSO0xyUZC7VJeP1sIk52WrN = GG8ETpSO0xyUZC7VJeP1sIk52WrN+'_SERIES'
			elif '__MOVIES__' in qEkx9gCLD8PvWuNf4lXTKsZebcwH: GG8ETpSO0xyUZC7VJeP1sIk52WrN = GG8ETpSO0xyUZC7VJeP1sIk52WrN+'_MOVIES'
			else: GG8ETpSO0xyUZC7VJeP1sIk52WrN = GG8ETpSO0xyUZC7VJeP1sIk52WrN+'_UNKNOWN'
			qEkx9gCLD8PvWuNf4lXTKsZebcwH = qEkx9gCLD8PvWuNf4lXTKsZebcwH.replace('__SERIES__',SebHIf2jL1TBgrMKJu).replace('__MOVIES__',SebHIf2jL1TBgrMKJu)
		else:
			GG8ETpSO0xyUZC7VJeP1sIk52WrN = 'LIVE'
			if rrHSg187s0u35X9tMG in DDbuBePlNwoUxC9qX45pFZ3z: za6XoDpqQx953L = za6XoDpqQx953L+'_EPG'
			if rrHSg187s0u35X9tMG in uMml6tfO795iA8F: za6XoDpqQx953L = za6XoDpqQx953L+'_ARCHIVED'
			if not qEkx9gCLD8PvWuNf4lXTKsZebcwH: GG8ETpSO0xyUZC7VJeP1sIk52WrN = GG8ETpSO0xyUZC7VJeP1sIk52WrN+'_UNKNOWN'
			else: GG8ETpSO0xyUZC7VJeP1sIk52WrN = GG8ETpSO0xyUZC7VJeP1sIk52WrN+za6XoDpqQx953L
		qEkx9gCLD8PvWuNf4lXTKsZebcwH = qEkx9gCLD8PvWuNf4lXTKsZebcwH.strip(qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		if 'LIVE_UNKNOWN' in GG8ETpSO0xyUZC7VJeP1sIk52WrN: qEkx9gCLD8PvWuNf4lXTKsZebcwH = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in GG8ETpSO0xyUZC7VJeP1sIk52WrN: qEkx9gCLD8PvWuNf4lXTKsZebcwH = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in GG8ETpSO0xyUZC7VJeP1sIk52WrN:
			E12rsLvqC5eyKtUZdAgYJ3QDuOwITx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) [Ss]\d+ +[Ee]\d+',K463XmjqPLCTWwh7Sxr5zpkitRM['title'],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if E12rsLvqC5eyKtUZdAgYJ3QDuOwITx: E12rsLvqC5eyKtUZdAgYJ3QDuOwITx = E12rsLvqC5eyKtUZdAgYJ3QDuOwITx[0]
			else: E12rsLvqC5eyKtUZdAgYJ3QDuOwITx = '!!__UNKNOWN_SERIES__!!'
			qEkx9gCLD8PvWuNf4lXTKsZebcwH = qEkx9gCLD8PvWuNf4lXTKsZebcwH+'__SERIES__'+E12rsLvqC5eyKtUZdAgYJ3QDuOwITx
		if 'id' in Gl1NAskXm5bfnLZctWr8V: del K463XmjqPLCTWwh7Sxr5zpkitRM['id']
		if 'ID' in Gl1NAskXm5bfnLZctWr8V: del K463XmjqPLCTWwh7Sxr5zpkitRM['ID']
		if 'name' in Gl1NAskXm5bfnLZctWr8V: del K463XmjqPLCTWwh7Sxr5zpkitRM['name']
		rrHSg187s0u35X9tMG = K463XmjqPLCTWwh7Sxr5zpkitRM['title']
		rrHSg187s0u35X9tMG = a549mfV8gnzXpwlFr(rrHSg187s0u35X9tMG)
		rrHSg187s0u35X9tMG = wfRd0Hh9JmpYu(rrHSg187s0u35X9tMG)
		ttC3zIcXElwLhWiDkbmquVy7,qEkx9gCLD8PvWuNf4lXTKsZebcwH = ggdljT76ocOLYIADQBbVhmzqMiWu(qEkx9gCLD8PvWuNf4lXTKsZebcwH)
		JQlqefcybY1hSBgNumI6DxzVE52O,rrHSg187s0u35X9tMG = ggdljT76ocOLYIADQBbVhmzqMiWu(rrHSg187s0u35X9tMG)
		K463XmjqPLCTWwh7Sxr5zpkitRM['type'] = GG8ETpSO0xyUZC7VJeP1sIk52WrN
		K463XmjqPLCTWwh7Sxr5zpkitRM['context'] = za6XoDpqQx953L
		K463XmjqPLCTWwh7Sxr5zpkitRM['group'] = qEkx9gCLD8PvWuNf4lXTKsZebcwH.upper()
		K463XmjqPLCTWwh7Sxr5zpkitRM['title'] = rrHSg187s0u35X9tMG.upper()
		K463XmjqPLCTWwh7Sxr5zpkitRM['country'] = JQlqefcybY1hSBgNumI6DxzVE52O.upper()
		K463XmjqPLCTWwh7Sxr5zpkitRM['language'] = ttC3zIcXElwLhWiDkbmquVy7.upper()
		aHSGtr4TUoicgN3dzAVhClX2O9Y.append(K463XmjqPLCTWwh7Sxr5zpkitRM)
		JINEq9VpDmzYy18AGKBu += 1
	return aHSGtr4TUoicgN3dzAVhClX2O9Y,JINEq9VpDmzYy18AGKBu,xxYWKpwVkeyENaA2zCPQf
def wfRd0Hh9JmpYu(rrHSg187s0u35X9tMG):
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.replace('||','|').replace('___',':').replace('--','-')
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.replace('[[','[').replace(']]',']')
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.replace('((','(').replace('))',')')
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.replace('<<','<').replace('>>','>')
	rrHSg187s0u35X9tMG = rrHSg187s0u35X9tMG.strip(qE4nB3mKWHs)
	return rrHSg187s0u35X9tMG
def LZ8VGeTu4QrWdlPU1A(DzdGTF1veQqxMVX3KEmJ,TxESQX19JtZrI4PF7sO3LVhdG,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k):
	V3Q8TLNlwWKYB4FX7DJGfi = {}
	for ChbLEDv14OikR in ppP12W3axbZF86XwDjinKueHMv: V3Q8TLNlwWKYB4FX7DJGfi[ChbLEDv14OikR+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k] = []
	z9KGjXMWVyf0IemDZrwET = len(DzdGTF1veQqxMVX3KEmJ)
	ty6J93gkVDLN4WhTRwzQAxUEuc1aH = str(z9KGjXMWVyf0IemDZrwET)
	JINEq9VpDmzYy18AGKBu = 0
	xxYWKpwVkeyENaA2zCPQf = []
	for K463XmjqPLCTWwh7Sxr5zpkitRM in DzdGTF1veQqxMVX3KEmJ:
		if JINEq9VpDmzYy18AGKBu%873==0:
			mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,50+int(5*JINEq9VpDmzYy18AGKBu/z9KGjXMWVyf0IemDZrwET),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(JINEq9VpDmzYy18AGKBu)+' / '+ty6J93gkVDLN4WhTRwzQAxUEuc1aH)
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return None,None
		qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 = K463XmjqPLCTWwh7Sxr5zpkitRM['group'],K463XmjqPLCTWwh7Sxr5zpkitRM['context'],K463XmjqPLCTWwh7Sxr5zpkitRM['title'],K463XmjqPLCTWwh7Sxr5zpkitRM['url'],K463XmjqPLCTWwh7Sxr5zpkitRM['img']
		JQlqefcybY1hSBgNumI6DxzVE52O,ttC3zIcXElwLhWiDkbmquVy7,ChbLEDv14OikR = K463XmjqPLCTWwh7Sxr5zpkitRM['country'],K463XmjqPLCTWwh7Sxr5zpkitRM['language'],K463XmjqPLCTWwh7Sxr5zpkitRM['type']
		gLU3rkfZHhCKsGcBjDaq = (qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5)
		H03a4NPlfLzQjDtnF5S = False
		if 'LIVE' in ChbLEDv14OikR:
			if 'UNKNOWN' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_UNKNOWN_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			elif 'LIVE' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			else: H03a4NPlfLzQjDtnF5S = True
			V3Q8TLNlwWKYB4FX7DJGfi['LIVE_ORIGINAL_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
		elif 'VOD' in ChbLEDv14OikR:
			if 'UNKNOWN' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_UNKNOWN_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			elif 'MOVIES' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_MOVIES_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			elif 'SERIES' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_SERIES_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			else: H03a4NPlfLzQjDtnF5S = True
			V3Q8TLNlwWKYB4FX7DJGfi['VOD_ORIGINAL_GROUPED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
		else: H03a4NPlfLzQjDtnF5S = True
		if H03a4NPlfLzQjDtnF5S: xxYWKpwVkeyENaA2zCPQf.append(K463XmjqPLCTWwh7Sxr5zpkitRM)
		JINEq9VpDmzYy18AGKBu += 1
	yoRCbw5cTiSYQd41jlx7FOhWa2u = sorted(DzdGTF1veQqxMVX3KEmJ,reverse=False,key=lambda WbCSjAfYNB95pXz8awDqRZo: WbCSjAfYNB95pXz8awDqRZo['title'].lower())
	del DzdGTF1veQqxMVX3KEmJ
	ty6J93gkVDLN4WhTRwzQAxUEuc1aH = str(z9KGjXMWVyf0IemDZrwET)
	JINEq9VpDmzYy18AGKBu = 0
	for K463XmjqPLCTWwh7Sxr5zpkitRM in yoRCbw5cTiSYQd41jlx7FOhWa2u:
		JINEq9VpDmzYy18AGKBu += 1
		if JINEq9VpDmzYy18AGKBu%873==0:
			mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,55+int(5*JINEq9VpDmzYy18AGKBu/z9KGjXMWVyf0IemDZrwET),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(JINEq9VpDmzYy18AGKBu)+' / '+ty6J93gkVDLN4WhTRwzQAxUEuc1aH)
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return None,None
		ChbLEDv14OikR = K463XmjqPLCTWwh7Sxr5zpkitRM['type']
		qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 = K463XmjqPLCTWwh7Sxr5zpkitRM['group'],K463XmjqPLCTWwh7Sxr5zpkitRM['context'],K463XmjqPLCTWwh7Sxr5zpkitRM['title'],K463XmjqPLCTWwh7Sxr5zpkitRM['url'],K463XmjqPLCTWwh7Sxr5zpkitRM['img']
		JQlqefcybY1hSBgNumI6DxzVE52O,ttC3zIcXElwLhWiDkbmquVy7 = K463XmjqPLCTWwh7Sxr5zpkitRM['country'],K463XmjqPLCTWwh7Sxr5zpkitRM['language']
		RSxlk8XyKTIQpns1HPrObN = (qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L+'_TIMESHIFT',rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5)
		gLU3rkfZHhCKsGcBjDaq = (qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5)
		afKPdIzMYm2n3HB9X = (JQlqefcybY1hSBgNumI6DxzVE52O,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5)
		U9fqJbdYK3Ivenpy = (ttC3zIcXElwLhWiDkbmquVy7,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5)
		if 'LIVE' in ChbLEDv14OikR:
			if 'UNKNOWN' in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_UNKNOWN_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			else: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			if 'EPG'		in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_EPG_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			if 'ARCHIVED'	in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_ARCHIVED_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			if 'ARCHIVED'	in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['LIVE_TIMESHIFT_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(RSxlk8XyKTIQpns1HPrObN)
			V3Q8TLNlwWKYB4FX7DJGfi['LIVE_FROM_NAME_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(afKPdIzMYm2n3HB9X)
			V3Q8TLNlwWKYB4FX7DJGfi['LIVE_FROM_GROUP_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(U9fqJbdYK3Ivenpy)
		elif 'VOD' in ChbLEDv14OikR:
			if   'UNKNOWN'	in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_UNKNOWN_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			elif 'MOVIES'	in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_MOVIES_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			elif 'SERIES'	in ChbLEDv14OikR: V3Q8TLNlwWKYB4FX7DJGfi['VOD_SERIES_GROUPED_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(gLU3rkfZHhCKsGcBjDaq)
			V3Q8TLNlwWKYB4FX7DJGfi['VOD_FROM_NAME_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(afKPdIzMYm2n3HB9X)
			V3Q8TLNlwWKYB4FX7DJGfi['VOD_FROM_GROUP_SORTED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k].append(U9fqJbdYK3Ivenpy)
	return V3Q8TLNlwWKYB4FX7DJGfi,xxYWKpwVkeyENaA2zCPQf
def ggdljT76ocOLYIADQBbVhmzqMiWu(rrHSg187s0u35X9tMG):
	if len(rrHSg187s0u35X9tMG)<3: return rrHSg187s0u35X9tMG,rrHSg187s0u35X9tMG
	VGbhaOkIY8AJpR6LsM7fmSCQwDq,ppX2trKLBUq = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	YYtvKUkmz3LQqdIM = rrHSg187s0u35X9tMG
	VNXwEF79hsopbLYKjv16dqfH = rrHSg187s0u35X9tMG[:1]
	baT1rwCiRc0xWE = rrHSg187s0u35X9tMG[1:]
	if   VNXwEF79hsopbLYKjv16dqfH=='(': ppX2trKLBUq = ')'
	elif VNXwEF79hsopbLYKjv16dqfH=='[': ppX2trKLBUq = ']'
	elif VNXwEF79hsopbLYKjv16dqfH=='<': ppX2trKLBUq = '>'
	elif VNXwEF79hsopbLYKjv16dqfH=='|': ppX2trKLBUq = '|'
	if ppX2trKLBUq and (ppX2trKLBUq in baT1rwCiRc0xWE):
		eM65grEvmFqzYxsoD10,IAqs1dxYi0w = baT1rwCiRc0xWE.split(ppX2trKLBUq,1)
		VGbhaOkIY8AJpR6LsM7fmSCQwDq = eM65grEvmFqzYxsoD10
		YYtvKUkmz3LQqdIM = VNXwEF79hsopbLYKjv16dqfH+eM65grEvmFqzYxsoD10+ppX2trKLBUq+qE4nB3mKWHs+IAqs1dxYi0w
	elif rrHSg187s0u35X9tMG.count('|')>=2:
		eM65grEvmFqzYxsoD10,IAqs1dxYi0w = rrHSg187s0u35X9tMG.split('|',1)
		VGbhaOkIY8AJpR6LsM7fmSCQwDq = eM65grEvmFqzYxsoD10
		YYtvKUkmz3LQqdIM = eM65grEvmFqzYxsoD10+' |'+IAqs1dxYi0w
	else:
		ppX2trKLBUq = X2XorVqHjLkWeCchY4u9fSz.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',rrHSg187s0u35X9tMG,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not ppX2trKLBUq: ppX2trKLBUq = X2XorVqHjLkWeCchY4u9fSz.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',rrHSg187s0u35X9tMG,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not ppX2trKLBUq: ppX2trKLBUq = X2XorVqHjLkWeCchY4u9fSz.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',rrHSg187s0u35X9tMG,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if ppX2trKLBUq:
			eM65grEvmFqzYxsoD10,IAqs1dxYi0w = rrHSg187s0u35X9tMG.split(ppX2trKLBUq[0],1)
			VGbhaOkIY8AJpR6LsM7fmSCQwDq = eM65grEvmFqzYxsoD10
			YYtvKUkmz3LQqdIM = eM65grEvmFqzYxsoD10+qE4nB3mKWHs+ppX2trKLBUq[0]+qE4nB3mKWHs+IAqs1dxYi0w
	YYtvKUkmz3LQqdIM = YYtvKUkmz3LQqdIM.replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	VGbhaOkIY8AJpR6LsM7fmSCQwDq = VGbhaOkIY8AJpR6LsM7fmSCQwDq.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	if not VGbhaOkIY8AJpR6LsM7fmSCQwDq: VGbhaOkIY8AJpR6LsM7fmSCQwDq = '!!__UNKNOWN__!!'
	VGbhaOkIY8AJpR6LsM7fmSCQwDq = VGbhaOkIY8AJpR6LsM7fmSCQwDq.strip(qE4nB3mKWHs)
	YYtvKUkmz3LQqdIM = YYtvKUkmz3LQqdIM.strip(qE4nB3mKWHs)
	return VGbhaOkIY8AJpR6LsM7fmSCQwDq,YYtvKUkmz3LQqdIM
def hxofMi1gL6FCEZqOXrctV9(CVchuNWFazQbtmLE):
	P63kUYjgATfKD = {}
	CRbA6Tk21vPOIgVxKLsMdfrH8ey = MMAUZiw4CoJ8.getSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE)
	if CRbA6Tk21vPOIgVxKLsMdfrH8ey: P63kUYjgATfKD['User-Agent'] = CRbA6Tk21vPOIgVxKLsMdfrH8ey
	VEwlNCbSM5diDpFmP9Zeza4q2 = MMAUZiw4CoJ8.getSetting('av.m3u.referer_'+CVchuNWFazQbtmLE)
	if VEwlNCbSM5diDpFmP9Zeza4q2: P63kUYjgATfKD['Referer'] = VEwlNCbSM5diDpFmP9Zeza4q2
	return P63kUYjgATfKD
def YHjoSvZRmBdGp3XzW4htIa0bg(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k):
	global TxESQX19JtZrI4PF7sO3LVhdG,V3Q8TLNlwWKYB4FX7DJGfi,p3heFX4Na8nJsAG1xBIf,jd4V35APerZpcGMotJHfSl78U,mmrGAxPo2aBlptcuCvfVsTQ,ImXON32Eg40ZbwJB6,D0BX2FYQzeLiqxlm,V2pbLS7POHAZJNog9ckqEQa8R4me,BufzX3nLhT9r18sJK
	xHiS9Y7KpJrNVB = MMAUZiw4CoJ8.getSetting('av.m3u.url_'+CVchuNWFazQbtmLE+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	CRbA6Tk21vPOIgVxKLsMdfrH8ey = MMAUZiw4CoJ8.getSetting('av.m3u.useragent_'+CVchuNWFazQbtmLE)
	P63kUYjgATfKD = {'User-Agent':CRbA6Tk21vPOIgVxKLsMdfrH8ey}
	Clf580vZO9Syic37 = RIUgY7kyPSuNqftO3W8Dl.replace('___','_'+CVchuNWFazQbtmLE+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	if 1:
		EvLGmlhQNf1oe9b,UUdEYmW0r3KCVcoI96TPNb4ln,oBEhRy5bGlrvPXtwWLUYcg0 = True,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
		if not EvLGmlhQNf1oe9b:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not xHiS9Y7KpJrNVB: z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+'   No M3U URL found to download M3U files')
			else: z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(pliQLY2RfzaWc)+'   Failed to download M3U files')
			return
		ctH7zvYeoKI8Vp2OGaSgd51s = VUchIzntr5E(xHiS9Y7KpJrNVB,P63kUYjgATfKD,True)
		if not ctH7zvYeoKI8Vp2OGaSgd51s: return
		open(Clf580vZO9Syic37,'wb').write(ctH7zvYeoKI8Vp2OGaSgd51s)
	else: ctH7zvYeoKI8Vp2OGaSgd51s = open(Clf580vZO9Syic37,'rb').read()
	if QBOMjKifEAFD and ctH7zvYeoKI8Vp2OGaSgd51s: ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.decode(Tv08xsf9HOqunIVUPdK1)
	TxESQX19JtZrI4PF7sO3LVhdG = fy567LYZh4gGdeSJN()
	TxESQX19JtZrI4PF7sO3LVhdG.create('جلب ملفات M3U جديدة',SebHIf2jL1TBgrMKJu)
	mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,15,'تنظيف الملف الرئيسي',SebHIf2jL1TBgrMKJu)
	ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.replace('"tvg-','" tvg-')
	ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.replace('َ',SebHIf2jL1TBgrMKJu).replace('ً',SebHIf2jL1TBgrMKJu).replace('ُ',SebHIf2jL1TBgrMKJu).replace('ٌ',SebHIf2jL1TBgrMKJu)
	ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.replace('ّ',SebHIf2jL1TBgrMKJu).replace('ِ',SebHIf2jL1TBgrMKJu).replace('ٍ',SebHIf2jL1TBgrMKJu).replace('ْ',SebHIf2jL1TBgrMKJu)
	ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.replace('group-title=','group=').replace('tvg-',SebHIf2jL1TBgrMKJu)
	uMml6tfO795iA8F,DDbuBePlNwoUxC9qX45pFZ3z = [],[]
	ctH7zvYeoKI8Vp2OGaSgd51s = ctH7zvYeoKI8Vp2OGaSgd51s.replace(vvm0bR6z8NK5wUg2l9jqrJu,u43PVWjh7t9YwI)
	mKguiz74rjwFLT1 = X2XorVqHjLkWeCchY4u9fSz.findall('NF:(.+?)'+'#'+'EXTI',ctH7zvYeoKI8Vp2OGaSgd51s+'\n+'+'#'+'EXTINF:',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not mKguiz74rjwFLT1:
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(pliQLY2RfzaWc)+'   Folder:'+CVchuNWFazQbtmLE+'  Sequence:'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k+'   No video links found in M3U file')
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+'مجلد رقم '+CVchuNWFazQbtmLE+'      رابط رقم '+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k+XOVRfitWJP1zL3p2CMYF)
		TxESQX19JtZrI4PF7sO3LVhdG.close()
		return
	aQgH4xqum9eInoVX = []
	for Ok5XpynWJh1eoRb2mvsGN7uEaKVHI in mKguiz74rjwFLT1:
		jjwuypZNHTRDKQ1X = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.lower()
		if 'adult' in jjwuypZNHTRDKQ1X: continue
		if 'xxx' in jjwuypZNHTRDKQ1X: continue
		aQgH4xqum9eInoVX.append(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI)
	mKguiz74rjwFLT1 = aQgH4xqum9eInoVX
	del aQgH4xqum9eInoVX
	if 'iptv-org' in xHiS9Y7KpJrNVB:
		aQgH4xqum9eInoVX,pBGOUzmSykwuEbTLe4fV0a3KdnH = [],[]
		for Ok5XpynWJh1eoRb2mvsGN7uEaKVHI in mKguiz74rjwFLT1:
			ImXON32Eg40ZbwJB6 = X2XorVqHjLkWeCchY4u9fSz.findall('group="(.*?)"',Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if ImXON32Eg40ZbwJB6:
				ImXON32Eg40ZbwJB6 = ImXON32Eg40ZbwJB6[0]
				WQP40nrH23cmSlDxEJaijGduLO7b6 = ImXON32Eg40ZbwJB6.split(';')
				if 'region' in xHiS9Y7KpJrNVB: F6NuK82qhAdB4yWcMoC71ZXDJO5H = '1_'
				elif 'category' in xHiS9Y7KpJrNVB: F6NuK82qhAdB4yWcMoC71ZXDJO5H = '2_'
				elif 'language' in xHiS9Y7KpJrNVB: F6NuK82qhAdB4yWcMoC71ZXDJO5H = '3_'
				elif 'country' in xHiS9Y7KpJrNVB: F6NuK82qhAdB4yWcMoC71ZXDJO5H = '4_'
				else: F6NuK82qhAdB4yWcMoC71ZXDJO5H = '5_'
				enYtk0xlgHKprqLECRF = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.replace('group="'+ImXON32Eg40ZbwJB6+'"','group="'+F6NuK82qhAdB4yWcMoC71ZXDJO5H+'~'+E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF+'"')
				aQgH4xqum9eInoVX.append(enYtk0xlgHKprqLECRF)
				for qEkx9gCLD8PvWuNf4lXTKsZebcwH in WQP40nrH23cmSlDxEJaijGduLO7b6:
					enYtk0xlgHKprqLECRF = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.replace('group="'+ImXON32Eg40ZbwJB6+'"','group="'+F6NuK82qhAdB4yWcMoC71ZXDJO5H+qEkx9gCLD8PvWuNf4lXTKsZebcwH+'"')
					aQgH4xqum9eInoVX.append(enYtk0xlgHKprqLECRF)
			else: aQgH4xqum9eInoVX.append(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI)
		mKguiz74rjwFLT1 = aQgH4xqum9eInoVX
		del aQgH4xqum9eInoVX,pBGOUzmSykwuEbTLe4fV0a3KdnH
	D93EKTFGOe = 1024*1024
	Vca2RSWuHUCsp34fkXMiy6b = 1+len(ctH7zvYeoKI8Vp2OGaSgd51s)//D93EKTFGOe//10
	del ctH7zvYeoKI8Vp2OGaSgd51s
	T8s0L57kwBq = len(mKguiz74rjwFLT1)
	pBGOUzmSykwuEbTLe4fV0a3KdnH = f1sy2meG8IhuvdMjKJQBWw7(mKguiz74rjwFLT1,Vca2RSWuHUCsp34fkXMiy6b)
	del mKguiz74rjwFLT1
	for k67x1WiUM34JdvBYLFwpe2 in range(Vca2RSWuHUCsp34fkXMiy6b):
		mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,35+int(5*k67x1WiUM34JdvBYLFwpe2/Vca2RSWuHUCsp34fkXMiy6b),'تقطيع الملف الرئيسي','الجزء رقم:-',str(k67x1WiUM34JdvBYLFwpe2+1)+' / '+str(Vca2RSWuHUCsp34fkXMiy6b))
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
		bTQe4rw8XoaKzsULOgM = str(pBGOUzmSykwuEbTLe4fV0a3KdnH[k67x1WiUM34JdvBYLFwpe2])
		if QBOMjKifEAFD: bTQe4rw8XoaKzsULOgM = bTQe4rw8XoaKzsULOgM.encode(Tv08xsf9HOqunIVUPdK1)
		open(Clf580vZO9Syic37+'.00'+str(k67x1WiUM34JdvBYLFwpe2),'wb').write(bTQe4rw8XoaKzsULOgM)
	del pBGOUzmSykwuEbTLe4fV0a3KdnH,bTQe4rw8XoaKzsULOgM
	QU5RHtrM3lGzNq9ghIfFJs,DzdGTF1veQqxMVX3KEmJ,JINEq9VpDmzYy18AGKBu = [],[],0
	for k67x1WiUM34JdvBYLFwpe2 in range(Vca2RSWuHUCsp34fkXMiy6b):
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
		bTQe4rw8XoaKzsULOgM = open(Clf580vZO9Syic37+'.00'+str(k67x1WiUM34JdvBYLFwpe2),'rb').read()
		uv8V4fE7j9pmgFr3wnDL.sleep(1)
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(Clf580vZO9Syic37+'.00'+str(k67x1WiUM34JdvBYLFwpe2))
		except: pass
		if QBOMjKifEAFD: bTQe4rw8XoaKzsULOgM = bTQe4rw8XoaKzsULOgM.decode(Tv08xsf9HOqunIVUPdK1)
		vlJfuk6ZwC85cFig = xjVJ0o7mF86tCDagkbNcrTAR4UH('list',bTQe4rw8XoaKzsULOgM)
		del bTQe4rw8XoaKzsULOgM
		aHSGtr4TUoicgN3dzAVhClX2O9Y,JINEq9VpDmzYy18AGKBu,xxYWKpwVkeyENaA2zCPQf = JTZWsXjuNSrondg8cikfFEl5yq(vlJfuk6ZwC85cFig,DDbuBePlNwoUxC9qX45pFZ3z,uMml6tfO795iA8F,TxESQX19JtZrI4PF7sO3LVhdG,T8s0L57kwBq,JINEq9VpDmzYy18AGKBu,xHiS9Y7KpJrNVB)
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
		if not aHSGtr4TUoicgN3dzAVhClX2O9Y:
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
		DzdGTF1veQqxMVX3KEmJ += aHSGtr4TUoicgN3dzAVhClX2O9Y
		QU5RHtrM3lGzNq9ghIfFJs += xxYWKpwVkeyENaA2zCPQf
	del vlJfuk6ZwC85cFig,aHSGtr4TUoicgN3dzAVhClX2O9Y
	V3Q8TLNlwWKYB4FX7DJGfi,xxYWKpwVkeyENaA2zCPQf = LZ8VGeTu4QrWdlPU1A(DzdGTF1veQqxMVX3KEmJ,TxESQX19JtZrI4PF7sO3LVhdG,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
		TxESQX19JtZrI4PF7sO3LVhdG.close()
		return
	QU5RHtrM3lGzNq9ghIfFJs += xxYWKpwVkeyENaA2zCPQf
	del DzdGTF1veQqxMVX3KEmJ,xxYWKpwVkeyENaA2zCPQf
	jd4V35APerZpcGMotJHfSl78U,mmrGAxPo2aBlptcuCvfVsTQ,ImXON32Eg40ZbwJB6,D0BX2FYQzeLiqxlm,V2pbLS7POHAZJNog9ckqEQa8R4me = {},{},{},0,0
	bZFtLi6SYskoC2X0Iyj31Ql = list(V3Q8TLNlwWKYB4FX7DJGfi.keys())
	BufzX3nLhT9r18sJK = len(bZFtLi6SYskoC2X0Iyj31Ql)*3
	if 1:
		QcTV9751tpx = {}
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz] = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=VKGyT8Lg7uUjMQcBwp23arS1Io,args=(dbUDOSJX503jGWNHp6uz,))
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz].start()
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz].join()
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
	else:
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			VKGyT8Lg7uUjMQcBwp23arS1Io(dbUDOSJX503jGWNHp6uz)
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return
	f7f1DXkG4ZiE2n6Pe0j(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,False)
	bZFtLi6SYskoC2X0Iyj31Ql = list(jd4V35APerZpcGMotJHfSl78U.keys())
	p3heFX4Na8nJsAG1xBIf = 0
	if 1:
		QcTV9751tpx = {}
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz] = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=vIT7y8guxOZEdJR,args=(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz))
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz].start()
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			QcTV9751tpx[dbUDOSJX503jGWNHp6uz].join()
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
			TxESQX19JtZrI4PF7sO3LVhdG.close()
			return
	else:
		for dbUDOSJX503jGWNHp6uz in bZFtLi6SYskoC2X0Iyj31Ql:
			vIT7y8guxOZEdJR(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz)
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return
	k67x1WiUM34JdvBYLFwpe2 = 0
	WWv4N3mIgiBwex = len(QU5RHtrM3lGzNq9ghIfFJs)
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,'IGNORED')
	for eY8LUPO9TEc in QU5RHtrM3lGzNq9ghIfFJs:
		if k67x1WiUM34JdvBYLFwpe2%27==0:
			mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,95+int(5*k67x1WiUM34JdvBYLFwpe2//WWv4N3mIgiBwex),'تخزين المهملة','الفيديو رقم:-',str(k67x1WiUM34JdvBYLFwpe2)+' / '+str(WWv4N3mIgiBwex))
			if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled():
				TxESQX19JtZrI4PF7sO3LVhdG.close()
				return
		pmvtYQxwN2EB7W(yyskMENq7ti2p,'IGNORED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,str(eY8LUPO9TEc),SebHIf2jL1TBgrMKJu,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
		k67x1WiUM34JdvBYLFwpe2 += 1
	pmvtYQxwN2EB7W(yyskMENq7ti2p,'IGNORED_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__',str(WWv4N3mIgiBwex),dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	TxESQX19JtZrI4PF7sO3LVhdG.close()
	uv8V4fE7j9pmgFr3wnDL.sleep(1)
	Pf2ucAvMDr38qy(CVchuNWFazQbtmLE)
	return
def VKGyT8Lg7uUjMQcBwp23arS1Io(dbUDOSJX503jGWNHp6uz):
	global TxESQX19JtZrI4PF7sO3LVhdG,V3Q8TLNlwWKYB4FX7DJGfi,p3heFX4Na8nJsAG1xBIf,jd4V35APerZpcGMotJHfSl78U,mmrGAxPo2aBlptcuCvfVsTQ,ImXON32Eg40ZbwJB6,D0BX2FYQzeLiqxlm,V2pbLS7POHAZJNog9ckqEQa8R4me,BufzX3nLhT9r18sJK
	jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz] = {}
	ahLqySofKkJgR,kAKRLYizD68tw5 = {},[]
	Pj8ShR3prmMt = len(V3Q8TLNlwWKYB4FX7DJGfi[dbUDOSJX503jGWNHp6uz])
	jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz]['__COUNT__'] = Pj8ShR3prmMt
	if Pj8ShR3prmMt>0:
		zxwpYD6bmeGV9NZMS2QHO0,AWhQZyY3tSos1qBJ,FFvhnei3sxqM8fVRjmz216aO,i4iRd0QCf8LA3gtm2WG,RMsxZq52Q38Hvo0jkF7 = zip(*V3Q8TLNlwWKYB4FX7DJGfi[dbUDOSJX503jGWNHp6uz])
		del AWhQZyY3tSos1qBJ,FFvhnei3sxqM8fVRjmz216aO,i4iRd0QCf8LA3gtm2WG
		WQP40nrH23cmSlDxEJaijGduLO7b6 = list(set(zxwpYD6bmeGV9NZMS2QHO0))
		for qEkx9gCLD8PvWuNf4lXTKsZebcwH in WQP40nrH23cmSlDxEJaijGduLO7b6:
			ahLqySofKkJgR[qEkx9gCLD8PvWuNf4lXTKsZebcwH] = SebHIf2jL1TBgrMKJu
			jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz][qEkx9gCLD8PvWuNf4lXTKsZebcwH] = []
		mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,60+int(15*V2pbLS7POHAZJNog9ckqEQa8R4me//BufzX3nLhT9r18sJK),'تصنيع القوائم','الجزء رقم:-',str(V2pbLS7POHAZJNog9ckqEQa8R4me)+' / '+str(BufzX3nLhT9r18sJK))
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled(): return
		V2pbLS7POHAZJNog9ckqEQa8R4me += 1
		rRYsGahCKZN4tFP = len(WQP40nrH23cmSlDxEJaijGduLO7b6)
		del WQP40nrH23cmSlDxEJaijGduLO7b6
		kAKRLYizD68tw5 = list(set(zip(zxwpYD6bmeGV9NZMS2QHO0,RMsxZq52Q38Hvo0jkF7)))
		del zxwpYD6bmeGV9NZMS2QHO0,RMsxZq52Q38Hvo0jkF7
		for qEkx9gCLD8PvWuNf4lXTKsZebcwH,PivTAZtgp1QB in kAKRLYizD68tw5:
			if not ahLqySofKkJgR[qEkx9gCLD8PvWuNf4lXTKsZebcwH] and PivTAZtgp1QB: ahLqySofKkJgR[qEkx9gCLD8PvWuNf4lXTKsZebcwH] = PivTAZtgp1QB
		mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,60+int(15*V2pbLS7POHAZJNog9ckqEQa8R4me//BufzX3nLhT9r18sJK),'تصنيع القوائم','الجزء رقم:-',str(V2pbLS7POHAZJNog9ckqEQa8R4me)+' / '+str(BufzX3nLhT9r18sJK))
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled(): return
		V2pbLS7POHAZJNog9ckqEQa8R4me += 1
		VoTxRtPwqu = list(ahLqySofKkJgR.keys())
		Y4MLObZTfeB = list(ahLqySofKkJgR.values())
		del ahLqySofKkJgR
		kAKRLYizD68tw5 = list(zip(VoTxRtPwqu,Y4MLObZTfeB))
		del VoTxRtPwqu,Y4MLObZTfeB
		kAKRLYizD68tw5 = sorted(kAKRLYizD68tw5)
	else: V2pbLS7POHAZJNog9ckqEQa8R4me += 2
	jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz]['__GROUPS__'] = kAKRLYizD68tw5
	del kAKRLYizD68tw5
	for qEkx9gCLD8PvWuNf4lXTKsZebcwH,za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 in V3Q8TLNlwWKYB4FX7DJGfi[dbUDOSJX503jGWNHp6uz]:
		jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz][qEkx9gCLD8PvWuNf4lXTKsZebcwH].append((za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5))
	mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,60+int(15*V2pbLS7POHAZJNog9ckqEQa8R4me//BufzX3nLhT9r18sJK),'تصنيع القوائم','الجزء رقم:-',str(V2pbLS7POHAZJNog9ckqEQa8R4me)+' / '+str(BufzX3nLhT9r18sJK))
	if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled(): return
	V2pbLS7POHAZJNog9ckqEQa8R4me += 1
	del V3Q8TLNlwWKYB4FX7DJGfi[dbUDOSJX503jGWNHp6uz]
	ImXON32Eg40ZbwJB6[dbUDOSJX503jGWNHp6uz] = list(jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz].keys())
	mmrGAxPo2aBlptcuCvfVsTQ[dbUDOSJX503jGWNHp6uz] = len(ImXON32Eg40ZbwJB6[dbUDOSJX503jGWNHp6uz])
	D0BX2FYQzeLiqxlm += mmrGAxPo2aBlptcuCvfVsTQ[dbUDOSJX503jGWNHp6uz]
	return
def vIT7y8guxOZEdJR(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz):
	global TxESQX19JtZrI4PF7sO3LVhdG,V3Q8TLNlwWKYB4FX7DJGfi,p3heFX4Na8nJsAG1xBIf,jd4V35APerZpcGMotJHfSl78U,mmrGAxPo2aBlptcuCvfVsTQ,ImXON32Eg40ZbwJB6,D0BX2FYQzeLiqxlm,V2pbLS7POHAZJNog9ckqEQa8R4me,BufzX3nLhT9r18sJK
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz)
	for JINEq9VpDmzYy18AGKBu in range(1+mmrGAxPo2aBlptcuCvfVsTQ[dbUDOSJX503jGWNHp6uz]//273):
		pGE9c843KUiM5bAvInfS2JQC = []
		o5pY68fwW2CamGSOuLjktNX = ImXON32Eg40ZbwJB6[dbUDOSJX503jGWNHp6uz][0:273]
		for qEkx9gCLD8PvWuNf4lXTKsZebcwH in o5pY68fwW2CamGSOuLjktNX:
			pGE9c843KUiM5bAvInfS2JQC.append(jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz][qEkx9gCLD8PvWuNf4lXTKsZebcwH])
		pmvtYQxwN2EB7W(yyskMENq7ti2p,dbUDOSJX503jGWNHp6uz,o5pY68fwW2CamGSOuLjktNX,pGE9c843KUiM5bAvInfS2JQC,dgvz7toK3Sil1CNUpPOaW58L9uJqY,True)
		p3heFX4Na8nJsAG1xBIf += len(o5pY68fwW2CamGSOuLjktNX)
		mm8riWX1U9q(TxESQX19JtZrI4PF7sO3LVhdG,75+int(20*p3heFX4Na8nJsAG1xBIf//D0BX2FYQzeLiqxlm),'تخزين القوائم','القائمة رقم:-',str(p3heFX4Na8nJsAG1xBIf)+' / '+str(D0BX2FYQzeLiqxlm))
		if TxESQX19JtZrI4PF7sO3LVhdG.iscanceled(): return
		del ImXON32Eg40ZbwJB6[dbUDOSJX503jGWNHp6uz][0:273]
	del jd4V35APerZpcGMotJHfSl78U[dbUDOSJX503jGWNHp6uz],ImXON32Eg40ZbwJB6[dbUDOSJX503jGWNHp6uz],mmrGAxPo2aBlptcuCvfVsTQ[dbUDOSJX503jGWNHp6uz]
	return
def s6uKbyBp8YxiHrq3Ev7C(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	CnRhvpTuPUbrofDZM2qI = 'عدد فيديوهات جميع الروابط'
	ZyLhq6dYpme = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,'LIVE_ORIGINAL_GROUPED')
	is4YU5EgTtNo = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,'VOD_ORIGINAL_GROUPED')
	if UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k:
		CnRhvpTuPUbrofDZM2qI = 'عدد فيديوهات رابط '+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[int(UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)]
		UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k = '_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k
	WWv4N3mIgiBwex = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','IGNORED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	Jofq0ZvKseuBd = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','LIVE_ORIGINAL_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	wlASrk21nYmGheZQvf6ctq = xVYs5tfGpcvz1Br4Sel(is4YU5EgTtNo,'int','VOD_ORIGINAL_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	r7mtLhvyjenPZ1BVgN8 = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','LIVE_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	QTObcy8xdVYgnUjz6mvhIL7HSZJolF = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','LIVE_UNKNOWN_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	r1rPWRjfNQT = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','VOD_MOVIES_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	ZN3no0zDU2KGJYE6 = xVYs5tfGpcvz1Br4Sel(is4YU5EgTtNo,'int','VOD_SERIES_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	O29cLxpGNM3V4Ss1fad0r7nRi8eBoh = xVYs5tfGpcvz1Br4Sel(ZyLhq6dYpme,'int','VOD_UNKNOWN_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__COUNT__')
	ImXON32Eg40ZbwJB6 = xVYs5tfGpcvz1Br4Sel(is4YU5EgTtNo,'list','VOD_SERIES_GROUPED'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,'__GROUPS__')
	gJ0zaMkdf47KTtjR1ENmoOLwxUiXY = []
	for qEkx9gCLD8PvWuNf4lXTKsZebcwH,jF4H926vaGi3CVU5 in ImXON32Eg40ZbwJB6:
		tqpW4BVDReybgL0 = qEkx9gCLD8PvWuNf4lXTKsZebcwH.split('__SERIES__')[1]
		gJ0zaMkdf47KTtjR1ENmoOLwxUiXY.append(tqpW4BVDReybgL0)
	ggyKTwNjZV18x5etPSdJOf = len(gJ0zaMkdf47KTtjR1ENmoOLwxUiXY)
	pLDVsUXPZYvHS = int(r1rPWRjfNQT)+int(ZN3no0zDU2KGJYE6)+int(O29cLxpGNM3V4Ss1fad0r7nRi8eBoh)+int(QTObcy8xdVYgnUjz6mvhIL7HSZJolF)+int(r7mtLhvyjenPZ1BVgN8)
	XUu9xTvBEqReZ5mrAQp = SebHIf2jL1TBgrMKJu
	XUu9xTvBEqReZ5mrAQp += 'قنوات: '+str(r7mtLhvyjenPZ1BVgN8)
	XUu9xTvBEqReZ5mrAQp += '   .   أفلام: '+str(r1rPWRjfNQT)
	XUu9xTvBEqReZ5mrAQp += '\nمسلسلات: '+str(ggyKTwNjZV18x5etPSdJOf)
	XUu9xTvBEqReZ5mrAQp += '   .   حلقات: '+str(ZN3no0zDU2KGJYE6)
	XUu9xTvBEqReZ5mrAQp += '\nقنوات مجهولة: '+str(QTObcy8xdVYgnUjz6mvhIL7HSZJolF)
	XUu9xTvBEqReZ5mrAQp += '   .   فيدوهات مجهولة: '+str(O29cLxpGNM3V4Ss1fad0r7nRi8eBoh)
	XUu9xTvBEqReZ5mrAQp += '\nمجموع القنوات: '+str(Jofq0ZvKseuBd)
	XUu9xTvBEqReZ5mrAQp += '   .   مجموع الفيديوهات: '+str(wlASrk21nYmGheZQvf6ctq)
	XUu9xTvBEqReZ5mrAQp += '\n\nمجموع المضافة: '+str(pLDVsUXPZYvHS)
	XUu9xTvBEqReZ5mrAQp += '   .   مجموع المهملة: '+str(WWv4N3mIgiBwex)
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA: gge5CmAcldwv0('center',SebHIf2jL1TBgrMKJu,CnRhvpTuPUbrofDZM2qI,XUu9xTvBEqReZ5mrAQp)
	G7GKtPizZb = XUu9xTvBEqReZ5mrAQp.replace('\n\n',u43PVWjh7t9YwI)
	if not UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k: UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k = 'All'
	else: UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k = UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k[1]
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,'.\tCounts of M3U videos   Folder: '+CVchuNWFazQbtmLE+'   Sequence: '+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k+u43PVWjh7t9YwI+G7GKtPizZb)
	return XUu9xTvBEqReZ5mrAQp
def f7f1DXkG4ZiE2n6Pe0j(CVchuNWFazQbtmLE,UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
		ffIQynE7HP3 = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if ffIQynE7HP3!=1: return
		VV8fleh2QBp1vxkZq = RIUgY7kyPSuNqftO3W8Dl.replace('___','_'+CVchuNWFazQbtmLE+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(VV8fleh2QBp1vxkZq)
		except: pass
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,SebHIf2jL1TBgrMKJu)
	if UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k:
		DoKr7UzMlHJwyFc = []
		for MhBc9lwxakEogGsZYjV6u in ppP12W3axbZF86XwDjinKueHMv:
			DoKr7UzMlHJwyFc.append(MhBc9lwxakEogGsZYjV6u+'_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
		pk7IJW8X5Zo(yyskMENq7ti2p,'LINK_'+UzbfPJTmVAF3eXIZiLM5EnRyxvdG0k)
	else:
		DoKr7UzMlHJwyFc = ppP12W3axbZF86XwDjinKueHMv
		pk7IJW8X5Zo(yyskMENq7ti2p,'DUMMY')
		pk7IJW8X5Zo(yyskMENq7ti2p,'GROUPS')
		pk7IJW8X5Zo(yyskMENq7ti2p,'ITEMS')
		pk7IJW8X5Zo(yyskMENq7ti2p,'SEARCH')
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'SECTIONS_M3U','SECTIONS_M3U_'+CVchuNWFazQbtmLE)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for dbUDOSJX503jGWNHp6uz in DoKr7UzMlHJwyFc:
		pk7IJW8X5Zo(yyskMENq7ti2p,dbUDOSJX503jGWNHp6uz)
	GGeyKjEOzHdn2I4BkXglo37(False)
	Pf2ucAvMDr38qy(CVchuNWFazQbtmLE)
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم مسح جميع ملفات ـM3U')
	return
def dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE=SebHIf2jL1TBgrMKJu,FZNQDXyeGo4fLUhR0dqPuBTEaIminA=True):
	if CVchuNWFazQbtmLE:
		yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(str(CVchuNWFazQbtmLE),'DUMMY')
		LAfHT4nUXqtMPm0y7uIR6OeBC = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'str','DUMMY','__DUMMY__')
		if LAfHT4nUXqtMPm0y7uIR6OeBC: return True
	else:
		CVchuNWFazQbtmLE = '1'
		for q1ycA8Oh4SbHdgL in range(1,wenmP3hMQEXB8gRcIyOH2A7ai+1):
			yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(str(q1ycA8Oh4SbHdgL),'DUMMY')
			LAfHT4nUXqtMPm0y7uIR6OeBC = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'str','DUMMY','__DUMMY__')
			if LAfHT4nUXqtMPm0y7uIR6OeBC: return True
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
		rrNejwXt5kDVYTPKB8b0Z1HlWR2hL = 'https://iptv-org.github.io/iptv/index.region.m3u'
		xFXEY84J9U5N = 'https://iptv-org.github.io/iptv/index.category.m3u'
		kktodrni5lhGpTwSZz3RemYy9 = 'https://iptv-org.github.io/iptv/index.language.m3u'
		lW9Bxjeo5Ap4UcP8I = 'https://iptv-org.github.io/iptv/index.country.m3u'
		hhYyTzP54Rg3ncQO8WU9X2L = rrNejwXt5kDVYTPKB8b0Z1HlWR2hL+u43PVWjh7t9YwI+xFXEY84J9U5N+u43PVWjh7t9YwI+kktodrni5lhGpTwSZz3RemYy9+u43PVWjh7t9YwI+lW9Bxjeo5Ap4UcP8I
		ffIQynE7HP3 = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+E7r8hUCVvTiFQW0dBGXjxcy+'http://github.com/iptv-org/iptv'+XOVRfitWJP1zL3p2CMYF+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+E7r8hUCVvTiFQW0dBGXjxcy+hhYyTzP54Rg3ncQO8WU9X2L+XOVRfitWJP1zL3p2CMYF,profile='confirm_smallfont')
		if ffIQynE7HP3==1:
			MMAUZiw4CoJ8.setSetting('av.m3u.url_'+str(CVchuNWFazQbtmLE)+'_1',rrNejwXt5kDVYTPKB8b0Z1HlWR2hL)
			MMAUZiw4CoJ8.setSetting('av.m3u.url_'+str(CVchuNWFazQbtmLE)+'_2',xFXEY84J9U5N)
			MMAUZiw4CoJ8.setSetting('av.m3u.url_'+str(CVchuNWFazQbtmLE)+'_3',kktodrni5lhGpTwSZz3RemYy9)
			MMAUZiw4CoJ8.setSetting('av.m3u.url_'+str(CVchuNWFazQbtmLE)+'_4',lW9Bxjeo5Ap4UcP8I)
			ffIQynE7HP3 = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if ffIQynE7HP3==1:
				c761tPKXus2i3J = ggcORVmIBx(CVchuNWFazQbtmLE)
				return c761tPKXus2i3J
		else:
			CnRhvpTuPUbrofDZM2qI = 'إضافة وتغيير رابط '+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[1]+' (مجلد '+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[int(CVchuNWFazQbtmLE)]+')'
			ffIQynE7HP3 = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,CnRhvpTuPUbrofDZM2qI,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. ثانيا أنقر على إضافة رابط أو اشتراك M3U .. ثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if ffIQynE7HP3==1: IImhCotAy905xK7eBr1G6LRP(CVchuNWFazQbtmLE,'1')
	return False
def Iyzm1FgGlSh0qUXVQCAHWbk3249JR(LX9pxsWyJIEgC,CVchuNWFazQbtmLE=SebHIf2jL1TBgrMKJu,dbUDOSJX503jGWNHp6uz=SebHIf2jL1TBgrMKJu,mXTGIsJyaU4q=SebHIf2jL1TBgrMKJu):
	if not mXTGIsJyaU4q: mXTGIsJyaU4q = '1'
	IsqopSjwNr6W4klVD32JR1nhf,V7o8RyDJNnF50GpbLsPjdUwefH,FZNQDXyeGo4fLUhR0dqPuBTEaIminA = sKhzPm0oUq7LO3Wk5Q(LX9pxsWyJIEgC)
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA): return
	if not IsqopSjwNr6W4klVD32JR1nhf:
		IsqopSjwNr6W4klVD32JR1nhf = zWKdm3kV2ItwYrgH1BZyRON()
		if not IsqopSjwNr6W4klVD32JR1nhf: return
	Czs1fEboR0uJ9XxIvVNcYTZgpjGt6 = [SebHIf2jL1TBgrMKJu,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dbUDOSJX503jGWNHp6uz:
		if not FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
			if   '_M3U-LIVE_' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[1]
			elif '_M3U-MOVIES' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[2]
			elif '_M3U-SERIES' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[3]
			else: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[0]
		else:
			qlLzyaXbOBu = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			wE4CUOSMetbRmWB6Pn = KKxHoL6iq4dst79zCUP215lYgMOreG('أختر البحث المناسب', qlLzyaXbOBu)
			if wE4CUOSMetbRmWB6Pn==-1: return
			dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[wE4CUOSMetbRmWB6Pn]
	IsqopSjwNr6W4klVD32JR1nhf = IsqopSjwNr6W4klVD32JR1nhf+'_NODIALOGS_'
	if CVchuNWFazQbtmLE: dOEXcDAyeZbv7rg(IsqopSjwNr6W4klVD32JR1nhf,CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz,mXTGIsJyaU4q)
	else:
		for CVchuNWFazQbtmLE in range(1,wenmP3hMQEXB8gRcIyOH2A7ai+1):
			dOEXcDAyeZbv7rg(IsqopSjwNr6W4klVD32JR1nhf,str(CVchuNWFazQbtmLE),dbUDOSJX503jGWNHp6uz,mXTGIsJyaU4q)
		qFsuKN7ngp.menuItemsLIST[:] = sorted(qFsuKN7ngp.menuItemsLIST,reverse=False,key=lambda WbCSjAfYNB95pXz8awDqRZo: WbCSjAfYNB95pXz8awDqRZo[1].lower())
	return
def dOEXcDAyeZbv7rg(LX9pxsWyJIEgC,CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz=SebHIf2jL1TBgrMKJu,mXTGIsJyaU4q=SebHIf2jL1TBgrMKJu):
	if not mXTGIsJyaU4q: mXTGIsJyaU4q = '1'
	IsqopSjwNr6W4klVD32JR1nhf,V7o8RyDJNnF50GpbLsPjdUwefH,FZNQDXyeGo4fLUhR0dqPuBTEaIminA = sKhzPm0oUq7LO3Wk5Q(LX9pxsWyJIEgC)
	if not CVchuNWFazQbtmLE: return
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA): return
	if not IsqopSjwNr6W4klVD32JR1nhf:
		IsqopSjwNr6W4klVD32JR1nhf = zWKdm3kV2ItwYrgH1BZyRON()
		if not IsqopSjwNr6W4klVD32JR1nhf: return
	Czs1fEboR0uJ9XxIvVNcYTZgpjGt6 = [SebHIf2jL1TBgrMKJu,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dbUDOSJX503jGWNHp6uz:
		if not FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
			if   '_M3U-LIVE_' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[1]
			elif '_M3U-MOVIES' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[2]
			elif '_M3U-SERIES' in V7o8RyDJNnF50GpbLsPjdUwefH: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[3]
			else: dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[0]
		else:
			qlLzyaXbOBu = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			wE4CUOSMetbRmWB6Pn = KKxHoL6iq4dst79zCUP215lYgMOreG('أختر البحث المناسب', qlLzyaXbOBu)
			if wE4CUOSMetbRmWB6Pn==-1: return
			dbUDOSJX503jGWNHp6uz = Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[wE4CUOSMetbRmWB6Pn]
	YYJprywl3CuLa = IsqopSjwNr6W4klVD32JR1nhf.lower()
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,'SEARCH')
	hoVT09XER3Jp6sL5 = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list','SEARCH',(dbUDOSJX503jGWNHp6uz,YYJprywl3CuLa))
	if not hoVT09XER3Jp6sL5:
		UiuPn2TVclhWA6MN9YJm,hDfMjduAXxN502K3mwZPgeG4vLS = [],[]
		if not dbUDOSJX503jGWNHp6uz: FCqo62ZudHNmkwQeJ1a4 = [1,2,3,4,5]
		else: FCqo62ZudHNmkwQeJ1a4 = [Czs1fEboR0uJ9XxIvVNcYTZgpjGt6.index(dbUDOSJX503jGWNHp6uz)]
		for k67x1WiUM34JdvBYLFwpe2 in FCqo62ZudHNmkwQeJ1a4:
			if k67x1WiUM34JdvBYLFwpe2!=3:
				aHSGtr4TUoicgN3dzAVhClX2O9Y = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'dict',Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[k67x1WiUM34JdvBYLFwpe2])
				del aHSGtr4TUoicgN3dzAVhClX2O9Y['__COUNT__']
				del aHSGtr4TUoicgN3dzAVhClX2O9Y['__GROUPS__']
				del aHSGtr4TUoicgN3dzAVhClX2O9Y['__SEQUENCED_COLUMNS__']
				ImXON32Eg40ZbwJB6 = list(aHSGtr4TUoicgN3dzAVhClX2O9Y.keys())
				for qEkx9gCLD8PvWuNf4lXTKsZebcwH in ImXON32Eg40ZbwJB6:
					for za6XoDpqQx953L,rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 in aHSGtr4TUoicgN3dzAVhClX2O9Y[qEkx9gCLD8PvWuNf4lXTKsZebcwH]:
						if YYJprywl3CuLa in rrHSg187s0u35X9tMG.lower(): hDfMjduAXxN502K3mwZPgeG4vLS.append((rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5))
					del aHSGtr4TUoicgN3dzAVhClX2O9Y[qEkx9gCLD8PvWuNf4lXTKsZebcwH]
				del aHSGtr4TUoicgN3dzAVhClX2O9Y
			else: ImXON32Eg40ZbwJB6 = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'list',Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[k67x1WiUM34JdvBYLFwpe2],'__GROUPS__')
			for qEkx9gCLD8PvWuNf4lXTKsZebcwH in ImXON32Eg40ZbwJB6:
				try: qEkx9gCLD8PvWuNf4lXTKsZebcwH,jF4H926vaGi3CVU5 = qEkx9gCLD8PvWuNf4lXTKsZebcwH
				except: jF4H926vaGi3CVU5 = SebHIf2jL1TBgrMKJu
				if YYJprywl3CuLa in qEkx9gCLD8PvWuNf4lXTKsZebcwH.lower():
					if k67x1WiUM34JdvBYLFwpe2!=3: z4wcs2tpSvWqa = qEkx9gCLD8PvWuNf4lXTKsZebcwH
					else:
						b5fdsaWxAPRhMvSkVjzrJ9,rrNMbkBl0dR = qEkx9gCLD8PvWuNf4lXTKsZebcwH.split('__SERIES__')
						if YYJprywl3CuLa in b5fdsaWxAPRhMvSkVjzrJ9.lower(): z4wcs2tpSvWqa = b5fdsaWxAPRhMvSkVjzrJ9
						else: z4wcs2tpSvWqa = rrNMbkBl0dR
					UiuPn2TVclhWA6MN9YJm.append((qEkx9gCLD8PvWuNf4lXTKsZebcwH,z4wcs2tpSvWqa,Czs1fEboR0uJ9XxIvVNcYTZgpjGt6[k67x1WiUM34JdvBYLFwpe2],jF4H926vaGi3CVU5))
			del ImXON32Eg40ZbwJB6
		UiuPn2TVclhWA6MN9YJm = set(UiuPn2TVclhWA6MN9YJm)
		hDfMjduAXxN502K3mwZPgeG4vLS = set(hDfMjduAXxN502K3mwZPgeG4vLS)
		UiuPn2TVclhWA6MN9YJm = sorted(UiuPn2TVclhWA6MN9YJm,reverse=False,key=lambda WbCSjAfYNB95pXz8awDqRZo: WbCSjAfYNB95pXz8awDqRZo[1])
		hDfMjduAXxN502K3mwZPgeG4vLS = sorted(hDfMjduAXxN502K3mwZPgeG4vLS,reverse=False,key=lambda WbCSjAfYNB95pXz8awDqRZo: WbCSjAfYNB95pXz8awDqRZo[0])
		pmvtYQxwN2EB7W(yyskMENq7ti2p,'SEARCH',(dbUDOSJX503jGWNHp6uz,YYJprywl3CuLa),(UiuPn2TVclhWA6MN9YJm,hDfMjduAXxN502K3mwZPgeG4vLS),dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	else: UiuPn2TVclhWA6MN9YJm,hDfMjduAXxN502K3mwZPgeG4vLS = hoVT09XER3Jp6sL5
	ImXON32Eg40ZbwJB6 = len(UiuPn2TVclhWA6MN9YJm)
	fxMiW1q5sApw24c0d9VNerl8zGY = len(hDfMjduAXxN502K3mwZPgeG4vLS)
	adUemWgVECPGjZ1tX6lK2L3rzoORy4 = int(mXTGIsJyaU4q)
	wwxHNXFZTD4f1Gs = max(0,(adUemWgVECPGjZ1tX6lK2L3rzoORy4-1)*100)
	g0lkG2S5MwcdZEehT = max(0,adUemWgVECPGjZ1tX6lK2L3rzoORy4*100)
	w1wKovczg6At = max(0,wwxHNXFZTD4f1Gs-ImXON32Eg40ZbwJB6)
	oTS6A9mCNQdblXYZs = max(0,g0lkG2S5MwcdZEehT-ImXON32Eg40ZbwJB6)
	for qEkx9gCLD8PvWuNf4lXTKsZebcwH,z4wcs2tpSvWqa,N0NY1HxbQISypLj6,jF4H926vaGi3CVU5 in UiuPn2TVclhWA6MN9YJm[wwxHNXFZTD4f1Gs:g0lkG2S5MwcdZEehT]:
		QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+z4wcs2tpSvWqa,N0NY1HxbQISypLj6,714,jF4H926vaGi3CVU5,'1',qEkx9gCLD8PvWuNf4lXTKsZebcwH,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	del UiuPn2TVclhWA6MN9YJm
	for rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,jF4H926vaGi3CVU5 in hDfMjduAXxN502K3mwZPgeG4vLS[w1wKovczg6At:oTS6A9mCNQdblXYZs]:
		MjI3zt17oL4KUkBE5RaqbrJcv6s = j1HGJPrFA3tTfLxayDCgIpE7Q(vCsnpu14Zi7qUEQg3Tl50h)
		GG8ETpSO0xyUZC7VJeP1sIk52WrN = 'live'
		if '.mkv' in MjI3zt17oL4KUkBE5RaqbrJcv6s or 'VOD' in dbUDOSJX503jGWNHp6uz: GG8ETpSO0xyUZC7VJeP1sIk52WrN = 'video'
		QUzFYoapm9jx(GG8ETpSO0xyUZC7VJeP1sIk52WrN,f7FNoaT5AZL0VhnP+rrHSg187s0u35X9tMG,vCsnpu14Zi7qUEQg3Tl50h,715,jF4H926vaGi3CVU5,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	del hDfMjduAXxN502K3mwZPgeG4vLS
	yfYnbslBTKrRvO0Zki(CVchuNWFazQbtmLE,mXTGIsJyaU4q,dbUDOSJX503jGWNHp6uz,719,ImXON32Eg40ZbwJB6+fxMiW1q5sApw24c0d9VNerl8zGY,IsqopSjwNr6W4klVD32JR1nhf+'_NODIALOGS_')
	return
def yfYnbslBTKrRvO0Zki(CVchuNWFazQbtmLE,mXTGIsJyaU4q,dbUDOSJX503jGWNHp6uz,hL9fngBAu7XzOx,pLDVsUXPZYvHS,Yg36raSGA02uUXEPMF7itZd9KcWf):
	if not mXTGIsJyaU4q: mXTGIsJyaU4q = '1'
	if mXTGIsJyaU4q!='1': QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'صفحة '+str(1),dbUDOSJX503jGWNHp6uz,hL9fngBAu7XzOx,SebHIf2jL1TBgrMKJu,str(1),Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	if not pLDVsUXPZYvHS: pLDVsUXPZYvHS = 0
	T1yeYmbAHniEKCxjpIv5WR8rVODgsf = int(pLDVsUXPZYvHS/100)+1
	for adUemWgVECPGjZ1tX6lK2L3rzoORy4 in range(2,T1yeYmbAHniEKCxjpIv5WR8rVODgsf):
		FL3csJ942OehdbEo1m = (adUemWgVECPGjZ1tX6lK2L3rzoORy4%10==0 or int(mXTGIsJyaU4q)-4<adUemWgVECPGjZ1tX6lK2L3rzoORy4<int(mXTGIsJyaU4q)+4)
		LLQB8PpgaKUncRFqeS = (FL3csJ942OehdbEo1m and int(mXTGIsJyaU4q)-40<adUemWgVECPGjZ1tX6lK2L3rzoORy4<int(mXTGIsJyaU4q)+40)
		if str(adUemWgVECPGjZ1tX6lK2L3rzoORy4)!=mXTGIsJyaU4q and (adUemWgVECPGjZ1tX6lK2L3rzoORy4%100==0 or LLQB8PpgaKUncRFqeS):
			QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'صفحة '+str(adUemWgVECPGjZ1tX6lK2L3rzoORy4),dbUDOSJX503jGWNHp6uz,hL9fngBAu7XzOx,SebHIf2jL1TBgrMKJu,str(adUemWgVECPGjZ1tX6lK2L3rzoORy4),Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	if str(T1yeYmbAHniEKCxjpIv5WR8rVODgsf)!=mXTGIsJyaU4q: QUzFYoapm9jx('folder',f7FNoaT5AZL0VhnP+'أخر صفحة '+str(T1yeYmbAHniEKCxjpIv5WR8rVODgsf),dbUDOSJX503jGWNHp6uz,hL9fngBAu7XzOx,SebHIf2jL1TBgrMKJu,str(T1yeYmbAHniEKCxjpIv5WR8rVODgsf),Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,{'folder':CVchuNWFazQbtmLE})
	return
def vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,dbUDOSJX503jGWNHp6uz):
	yyskMENq7ti2p = iZHe2ulY46PhoEm9tOaNcvG5SM.replace('___','_'+CVchuNWFazQbtmLE)
	return yyskMENq7ti2p
def ggcORVmIBx(CVchuNWFazQbtmLE):
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,SebHIf2jL1TBgrMKJu)
	ffIQynE7HP3 = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if ffIQynE7HP3!=1: return False
	Obn8a1c0P32FV6zHwjysokY(CVchuNWFazQbtmLE,False)
	ejfbCJU7sDMERxlWnXYF = [0]
	for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
		ssp2bNVOYFIRljkyLZdHS6 = MMAUZiw4CoJ8.getSetting('av.m3u.url_'+CVchuNWFazQbtmLE+'_'+str(aiqnPAQRgtxh6u3Y5I27))
		if ssp2bNVOYFIRljkyLZdHS6: YHjoSvZRmBdGp3XzW4htIa0bg(CVchuNWFazQbtmLE,str(aiqnPAQRgtxh6u3Y5I27))
		ejfbCJU7sDMERxlWnXYF.append(0)
	for dbUDOSJX503jGWNHp6uz in ppP12W3axbZF86XwDjinKueHMv:
		CkoKLUGjywnzl04vm2DX,EONh8ti9m45z2Vbf,IFshtJeDVOWNr2kERHU,gFRYC7Hv0rAD1wOLpm3tlJ8Wqo,ahLqySofKkJgR = 0,{},[],[],[]
		for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
			N0NY1HxbQISypLj6 = dbUDOSJX503jGWNHp6uz+'_'+str(aiqnPAQRgtxh6u3Y5I27)
			V3Q8TLNlwWKYB4FX7DJGfi = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'dict',N0NY1HxbQISypLj6)
			try:
				uuDf4eL21i = V3Q8TLNlwWKYB4FX7DJGfi['__GROUPS__']
				w9PHIy57MmhkK4tFRuUYgJxpOeqVor = V3Q8TLNlwWKYB4FX7DJGfi['__COUNT__']
			except: uuDf4eL21i,w9PHIy57MmhkK4tFRuUYgJxpOeqVor = [],'0'
			for o8FWiPY2OSXamCgMlb95vB0 in uuDf4eL21i:
				qEkx9gCLD8PvWuNf4lXTKsZebcwH,PivTAZtgp1QB = o8FWiPY2OSXamCgMlb95vB0
				aHSGtr4TUoicgN3dzAVhClX2O9Y = V3Q8TLNlwWKYB4FX7DJGfi[qEkx9gCLD8PvWuNf4lXTKsZebcwH]
				if qEkx9gCLD8PvWuNf4lXTKsZebcwH not in gFRYC7Hv0rAD1wOLpm3tlJ8Wqo:
					gFRYC7Hv0rAD1wOLpm3tlJ8Wqo.append(qEkx9gCLD8PvWuNf4lXTKsZebcwH)
					ahLqySofKkJgR.append(o8FWiPY2OSXamCgMlb95vB0)
					EONh8ti9m45z2Vbf[qEkx9gCLD8PvWuNf4lXTKsZebcwH] = []
				EONh8ti9m45z2Vbf[qEkx9gCLD8PvWuNf4lXTKsZebcwH] += aHSGtr4TUoicgN3dzAVhClX2O9Y
			pk7IJW8X5Zo(yyskMENq7ti2p,N0NY1HxbQISypLj6)
			pmvtYQxwN2EB7W(yyskMENq7ti2p,N0NY1HxbQISypLj6,'__COUNT__',w9PHIy57MmhkK4tFRuUYgJxpOeqVor,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
			ejfbCJU7sDMERxlWnXYF[aiqnPAQRgtxh6u3Y5I27] += int(w9PHIy57MmhkK4tFRuUYgJxpOeqVor)
		for qEkx9gCLD8PvWuNf4lXTKsZebcwH in gFRYC7Hv0rAD1wOLpm3tlJ8Wqo:
			aHSGtr4TUoicgN3dzAVhClX2O9Y = list(set(EONh8ti9m45z2Vbf[qEkx9gCLD8PvWuNf4lXTKsZebcwH]))
			if 'SORTED' in dbUDOSJX503jGWNHp6uz: aHSGtr4TUoicgN3dzAVhClX2O9Y = sorted(aHSGtr4TUoicgN3dzAVhClX2O9Y,reverse=False,key=lambda key: key[1].lower())
			CkoKLUGjywnzl04vm2DX += len(aHSGtr4TUoicgN3dzAVhClX2O9Y)
			IFshtJeDVOWNr2kERHU.append(aHSGtr4TUoicgN3dzAVhClX2O9Y)
		pmvtYQxwN2EB7W(yyskMENq7ti2p,dbUDOSJX503jGWNHp6uz,'__COUNT__',str(CkoKLUGjywnzl04vm2DX),dgvz7toK3Sil1CNUpPOaW58L9uJqY)
		pmvtYQxwN2EB7W(yyskMENq7ti2p,dbUDOSJX503jGWNHp6uz,'__GROUPS__',ahLqySofKkJgR,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
		pmvtYQxwN2EB7W(yyskMENq7ti2p,dbUDOSJX503jGWNHp6uz,gFRYC7Hv0rAD1wOLpm3tlJ8Wqo,IFshtJeDVOWNr2kERHU,dgvz7toK3Sil1CNUpPOaW58L9uJqY,True)
	o3oBAHJ4fZ2MqWDtCYFixaGe0S7 = False
	for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
		if int(ejfbCJU7sDMERxlWnXYF[aiqnPAQRgtxh6u3Y5I27])>0:
			ssp2bNVOYFIRljkyLZdHS6 = MMAUZiw4CoJ8.getSetting('av.m3u.url_'+CVchuNWFazQbtmLE+'_'+str(aiqnPAQRgtxh6u3Y5I27))
			pmvtYQxwN2EB7W(yyskMENq7ti2p,'LINK_'+str(aiqnPAQRgtxh6u3Y5I27),'__LINK__',ssp2bNVOYFIRljkyLZdHS6,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
			o3oBAHJ4fZ2MqWDtCYFixaGe0S7 = True
	pmvtYQxwN2EB7W(yyskMENq7ti2p,'DUMMY','__DUMMY__','DUMMY',dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	if not o3oBAHJ4fZ2MqWDtCYFixaGe0S7:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم جلب ملفات M3U جديدة')
	WJiMQRqo3gNOrLcw8X(CVchuNWFazQbtmLE)
	GGeyKjEOzHdn2I4BkXglo37(False)
	GLXqHD847n2jOVZaNEz9mFUIR31x(False)
	return True
def WJiMQRqo3gNOrLcw8X(CVchuNWFazQbtmLE):
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,SebHIf2jL1TBgrMKJu)
	if not dd30zMZ2hmuvQb96irALtl(CVchuNWFazQbtmLE,True): return
	for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
		ssp2bNVOYFIRljkyLZdHS6 = xVYs5tfGpcvz1Br4Sel(yyskMENq7ti2p,'str','LINK_'+str(aiqnPAQRgtxh6u3Y5I27),'__LINK__')
		if ssp2bNVOYFIRljkyLZdHS6: XUu9xTvBEqReZ5mrAQp = s6uKbyBp8YxiHrq3Ev7C(CVchuNWFazQbtmLE,str(aiqnPAQRgtxh6u3Y5I27))
	s6uKbyBp8YxiHrq3Ev7C(CVchuNWFazQbtmLE,SebHIf2jL1TBgrMKJu)
	return
def Obn8a1c0P32FV6zHwjysokY(CVchuNWFazQbtmLE,FZNQDXyeGo4fLUhR0dqPuBTEaIminA):
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
		ffIQynE7HP3 = vvubxo631m2zYC('center',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if ffIQynE7HP3!=1: return
	yyskMENq7ti2p = vKOjotpTIr7zSYnu9DZVa0JsF(CVchuNWFazQbtmLE,SebHIf2jL1TBgrMKJu)
	try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(yyskMENq7ti2p)
	except: pass
	for aiqnPAQRgtxh6u3Y5I27 in range(1,yyvVPZaFGkocX3LmSQ4eK+1):
		LEv8pF9IaWcQf61djgCUOVY = RIUgY7kyPSuNqftO3W8Dl.replace('___','_'+CVchuNWFazQbtmLE+'_'+str(aiqnPAQRgtxh6u3Y5I27))
		RnKTcNHtaP9bOBuJZU702mDV = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,LEv8pF9IaWcQf61djgCUOVY)
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(RnKTcNHtaP9bOBuJZU702mDV)
		except: pass
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'SECTIONS_M3U','SECTIONS_M3U_'+CVchuNWFazQbtmLE)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if FZNQDXyeGo4fLUhR0dqPuBTEaIminA:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم مسح جميع ملفات ـM3U')
		GLXqHD847n2jOVZaNEz9mFUIR31x(False)
	return
def Pf2ucAvMDr38qy(CVchuNWFazQbtmLE):
	ggIn1Sau9CVP = MMAUZiw4CoJ8.getSetting('av.language.provider')
	mKkRoI20d3SAXWMYD = MMAUZiw4CoJ8.getSetting('av.language.code')
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'MENUS_CACHE_'+ggIn1Sau9CVP+'_'+mKkRoI20d3SAXWMYD,'%_MU'+CVchuNWFazQbtmLE+'_%')
	return
jBwIrZRbcgQnUM = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}