# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SERIES4WATCH'
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SFW_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==210: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==211: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==212: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==213: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==214: lfZmugQCFKLGT05AH29IsMiho = lAzqBi6R3pLKJS9mhcgE1NvZd(url)
	elif mode==215: lfZmugQCFKLGT05AH29IsMiho = gTqYlAwsPh4OoxRMUi1eKvuNC5(url)
	elif mode==218: lfZmugQCFKLGT05AH29IsMiho = ANUq0yBljxf9kbzgeI5PEw()
	elif mode==219: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def ANUq0yBljxf9kbzgeI5PEw():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'الموقع تغير بالكامل',message)
	return
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,219,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	url = j1IFsik4ouNePZr+'/getpostsPin?type=one&data=pin&limit=25'
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',url,211)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('FiltersButtons(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-get="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		url = j1IFsik4ouNePZr+'/getposts?type=one&data='+cOn6JqZlmQbjtT
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,211)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('navigation-menu(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	jgvMWZhtPlBT = ['مسلسلات انمي','الرئيسية']
	for cOn6JqZlmQbjtT,title in items:
		title = title.strip(qE4nB3mKWHs)
		if not any(value in title for value in jgvMWZhtPlBT):
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,211)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('MediaGrid"(.*?)class="pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		else: return
	items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	BmVW5JQ7kafuTCg9DHZ3 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if '/series/' in cOn6JqZlmQbjtT: continue
		cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT).strip('/')
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.strip(qE4nB3mKWHs)
		if '/film/' in cOn6JqZlmQbjtT or any(value in title for value in BmVW5JQ7kafuTCg9DHZ3):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,212,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/episode/' in cOn6JqZlmQbjtT and 'الحلقة' in title:
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0]
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,213,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,213,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
			if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,211)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	TGhkzsgPbMo,items,DF7AOoSqL9jK6Gs8NtZHkUTzrYwd = -1,[],[]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-EPISODES-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('ti-list-numbered(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		cuoYjfNMPnmhQgtFE = SebHIf2jL1TBgrMKJu.join(k2pC30UArFeg7Ru9tGiZlSmzQ)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',cuoYjfNMPnmhQgtFE,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	items.append(url)
	items = set(items)
	for cOn6JqZlmQbjtT in items:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.strip('/')
		title = '_MOD_' + cOn6JqZlmQbjtT.split('/')[-1].replace('-',qE4nB3mKWHs)
		N6zTbPqn0IFo9 = X2XorVqHjLkWeCchY4u9fSz.findall('الحلقة-(\d+)',cOn6JqZlmQbjtT.split('/')[-1],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if N6zTbPqn0IFo9: N6zTbPqn0IFo9 = N6zTbPqn0IFo9[0]
		else: N6zTbPqn0IFo9 = '0'
		DF7AOoSqL9jK6Gs8NtZHkUTzrYwd.append([cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9])
	items = sorted(DF7AOoSqL9jK6Gs8NtZHkUTzrYwd, reverse=False, key=lambda key: int(key[2]))
	tcJ7YDMGrVHkPu3EeUC5 = str(items).count('/season/')
	TGhkzsgPbMo = str(items).count('/episode/')
	if tcJ7YDMGrVHkPu3EeUC5>1 and TGhkzsgPbMo>0 and '/season/' not in url:
		for cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9 in items:
			if '/season/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,213)
	else:
		for cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9 in items:
			if '/season/' not in cOn6JqZlmQbjtT: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,212)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	YY9GyjxZl6 = url.split('/')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		qg7Nr1dCaD = url.replace(YY9GyjxZl6[3],'watch')
		O3XeD9sgNyH = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-PLAY-2nd')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="servers-list(.*?)</div>',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if items:
				id = X2XorVqHjLkWeCchY4u9fSz.findall('post_id=(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if id:
					byFGvxhKuI9HU7ceAaMr3N4 = id[0]
					for cOn6JqZlmQbjtT,title in items:
						cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/?postid='+byFGvxhKuI9HU7ceAaMr3N4+'&serverid='+cOn6JqZlmQbjtT+'?named='+title+'__watch'
						bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
			else:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('data-embedd=".*?(http.*?)("|&quot;)',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for cOn6JqZlmQbjtT,fNnuAzFsXhBKCco9JZeVUvd7Ya in items:
					bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	if '/download/' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		qg7Nr1dCaD = url.replace(YY9GyjxZl6[3],'download')
		O3XeD9sgNyH = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-PLAY-3rd')
		id = X2XorVqHjLkWeCchY4u9fSz.findall('postId:"(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if id:
			byFGvxhKuI9HU7ceAaMr3N4 = id[0]
			REIkboX9NtlZCSU3A = { 'User-Agent':SebHIf2jL1TBgrMKJu , 'X-Requested-With':'XMLHttpRequest' }
			qg7Nr1dCaD = j1IFsik4ouNePZr + '/ajaxCenter?_action=getdownloadlinks&postId='+byFGvxhKuI9HU7ceAaMr3N4
			O3XeD9sgNyH = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,'SERIES4WATCH-PLAY-4th')
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<h3.*?(\d+)(.*?)</div>',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if k2pC30UArFeg7Ru9tGiZlSmzQ:
				for Nob4AmgUxHeP8qrhtWdz5J0XFi,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
					items = X2XorVqHjLkWeCchY4u9fSz.findall('<td>(.*?)<.*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for name,cOn6JqZlmQbjtT in items:
						bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT+'?named='+name+'__download'+'____'+Nob4AmgUxHeP8qrhtWdz5J0XFi)
			else:
				k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<h6(.*?)</table>',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = [O3XeD9sgNyH]
				for drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
					name = SebHIf2jL1TBgrMKJu
					items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for cOn6JqZlmQbjtT in items:
						YdzfwOyPb2gxT37B9Dm = '&&' + cOn6JqZlmQbjtT.split('/')[2].lower() + '&&'
						YdzfwOyPb2gxT37B9Dm = YdzfwOyPb2gxT37B9Dm.replace('.com&&',SebHIf2jL1TBgrMKJu).replace('.co&&',SebHIf2jL1TBgrMKJu)
						YdzfwOyPb2gxT37B9Dm = YdzfwOyPb2gxT37B9Dm.replace('.net&&',SebHIf2jL1TBgrMKJu).replace('.org&&',SebHIf2jL1TBgrMKJu)
						YdzfwOyPb2gxT37B9Dm = YdzfwOyPb2gxT37B9Dm.replace('.live&&',SebHIf2jL1TBgrMKJu).replace('.online&&',SebHIf2jL1TBgrMKJu)
						YdzfwOyPb2gxT37B9Dm = YdzfwOyPb2gxT37B9Dm.replace('&&hd.',SebHIf2jL1TBgrMKJu).replace('&&www.',SebHIf2jL1TBgrMKJu)
						YdzfwOyPb2gxT37B9Dm = YdzfwOyPb2gxT37B9Dm.replace('&&',SebHIf2jL1TBgrMKJu)
						cOn6JqZlmQbjtT = cOn6JqZlmQbjtT + '?named=' + name + YdzfwOyPb2gxT37B9Dm + '__download'
						bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + '/search?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return