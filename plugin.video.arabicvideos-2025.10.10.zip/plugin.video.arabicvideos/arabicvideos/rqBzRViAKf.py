# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'CIMALIGHT'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_CML_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['قنوات فضائية']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==470: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==471: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==472: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==473: lfZmugQCFKLGT05AH29IsMiho = JZvYADs6nb0zV4WU7RM1So8X5dIp(url,text)
	elif mode==474: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==479: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,479,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"content"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		title = title.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('cat=online-movies1','cat=online-movies')
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,474)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('/category.php">(.*?)"navslide-divider"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("'dropdown-menu'(.*?)</ul>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if title in jgvMWZhtPlBT: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,474)
	return
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'topvideos.php' in url: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"caret"(.*?)id="pm-grid"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"caret"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if 'topvideos.php' in cOn6JqZlmQbjtT:
				if 'topvideos.php?c=english-movies' in cOn6JqZlmQbjtT: continue
				if 'topvideos.php?c=online-movies1' in cOn6JqZlmQbjtT: continue
				if 'topvideos.php?c=misc' in cOn6JqZlmQbjtT: continue
				if 'topvideos.php?c=tv-channel' in cOn6JqZlmQbjtT: continue
				if 'منذ البداية' in title and 'do=rating' not in cOn6JqZlmQbjtT: continue
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,471)
	else: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,pbmcw9i1kfuNIQzJ7aGd3l0=SebHIf2jL1TBgrMKJu):
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = []
	if pbmcw9i1kfuNIQzJ7aGd3l0=='featured_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"container-fluid"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO,KdUYL4pPQsIt23h0qzb91JHi = zip(*items)
		items = zip(KdUYL4pPQsIt23h0qzb91JHi,uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO)
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('المسلسلات المميزة(.*?)<style>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO,KdUYL4pPQsIt23h0qzb91JHi = zip(*items)
		items = zip(KdUYL4pPQsIt23h0qzb91JHi,uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(data-echo=".*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"BlocksList"(.*?)"titleSectionCon"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="pm-grid"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="pm-related"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pm-ul-browse-videos(.*?)clearfix',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT).strip('/')
		title = title.replace('ماي سيما',SebHIf2jL1TBgrMKJu).replace('مشاهدة',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
		if 'http' not in tncvzBN0kyrqEHlhIPGSoX4ugA3CDs: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = VK4jU2G3s1PwkticQYyLoW+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.strip('/')
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة) \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			title = '_MOD_'+title
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,472,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and 'حلقة' in title:
			title = '_MOD_'+Wj39BaH6oEmstx[0][0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,473,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/movseries/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,471,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,473,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if pbmcw9i1kfuNIQzJ7aGd3l0 not in ['featured_movies','featured_series']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT=='#': continue
				cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
				title = cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,471)
		UEGO1pCKJNl9xo2tyr = X2XorVqHjLkWeCchY4u9fSz.findall('showmore" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if UEGO1pCKJNl9xo2tyr:
			cOn6JqZlmQbjtT = UEGO1pCKJNl9xo2tyr[0]
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مشاهدة المزيد',cOn6JqZlmQbjtT,471)
	return
def JZvYADs6nb0zV4WU7RM1So8X5dIp(url,yZfHYbEdxgemqNFoL8OSrR):
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-EPISODES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"SeasonsBox"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	items = []
	if Eky7GUxAVIQMn3ip0DOHrSYJ and not yZfHYbEdxgemqNFoL8OSrR:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('"series-header".*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0] if tncvzBN0kyrqEHlhIPGSoX4ugA3CDs else SebHIf2jL1TBgrMKJu
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(items)==1: yZfHYbEdxgemqNFoL8OSrR = items[0][0]
		elif len(items)>1:
			for yZfHYbEdxgemqNFoL8OSrR,title in items: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,473,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,yZfHYbEdxgemqNFoL8OSrR)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('id="'+yZfHYbEdxgemqNFoL8OSrR+'"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe and len(items)<2:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('"series-header".*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0] if tncvzBN0kyrqEHlhIPGSoX4ugA3CDs else SebHIf2jL1TBgrMKJu
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if items:
			for cOn6JqZlmQbjtT,title in items:
				title = title.replace('ماي سيما',SebHIf2jL1TBgrMKJu).replace('مسلسل',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,472,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,472,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if 'id="pm-related"' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		if items: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مواضيع ذات صلة',url,471)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<div itemprop="description">(.*?)href=',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('<p>(.*?)</p>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa,True): return
	qg7Nr1dCaD = url.replace('/watch.php','/play.php')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-PLAY-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Y9j6urtRye74N1PAiMUOLwDVWmc = []
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"embedURL" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		if cOn6JqZlmQbjtT and cOn6JqZlmQbjtT not in Y9j6urtRye74N1PAiMUOLwDVWmc:
			Y9j6urtRye74N1PAiMUOLwDVWmc.append(cOn6JqZlmQbjtT)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named=__embed'
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	items = X2XorVqHjLkWeCchY4u9fSz.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if cOn6JqZlmQbjtT not in Y9j6urtRye74N1PAiMUOLwDVWmc:
			Y9j6urtRye74N1PAiMUOLwDVWmc.append(cOn6JqZlmQbjtT)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	qg7Nr1dCaD = url.replace('/watch.php','/downloads.php')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMALIGHT-PLAY-3rd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"downloadlist"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<strong>(.*?)</strong>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if cOn6JqZlmQbjtT not in Y9j6urtRye74N1PAiMUOLwDVWmc:
				Y9j6urtRye74N1PAiMUOLwDVWmc.append(cOn6JqZlmQbjtT)
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
				bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(j1IFsik4ouNePZr,'url')
	url = YdzfwOyPb2gxT37B9Dm+'/search.php?keywords='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return