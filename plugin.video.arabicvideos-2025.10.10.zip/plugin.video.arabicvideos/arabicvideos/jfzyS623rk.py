# -*- coding: utf-8 -*-
from RSdDifzoPG import *
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
tfX4sO3hy2H1IbKG = 'AKOAM'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_AKO_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
M69nuvKfxWeP05rG1JiEjkaYtIbNT = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==70: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==71: lfZmugQCFKLGT05AH29IsMiho = dUIVBjNyP31C(url)
	elif mode==72: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==73: lfZmugQCFKLGT05AH29IsMiho = zJO7hVLjAGQWa0XI9pPwF4morZ(url)
	elif mode==74: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==79: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,79,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'سلسلة افلام',SebHIf2jL1TBgrMKJu,79,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'سلسلة افلام')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'سلاسل منوعة',SebHIf2jL1TBgrMKJu,79,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'سلسلة')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	jgvMWZhtPlBT = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKOAM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="partions"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT:
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,71)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def dUIVBjNyP31C(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKOAM-CATEGORIES-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('sect_parts(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.strip(qE4nB3mKWHs)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,72)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جميع الفروع',url,72)
	else: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,SebHIf2jL1TBgrMKJu)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('section_title featured_title(.*?)subjects-crousel',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='search':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('akoam_result(.*?)<script',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='more':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('section_title more_title(.*?)footer_bottom_services',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('navigation(.*?)<script',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items and k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		title = cvlHmV1Kr0FIYSjNnM(title)
		if any(value in title for value in M69nuvKfxWeP05rG1JiEjkaYtIbNT): QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,73,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,73,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("</li><li >.*?href='(.*?)'>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,72,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
	return
def ctAKMEZeD7oq8xXLR6kS23aO(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAM-SECTIONS-2nd')
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('"href","(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qg7Nr1dCaD = qg7Nr1dCaD[1]
	return qg7Nr1dCaD
def zJO7hVLjAGQWa0XI9pPwF4morZ(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAM-SECTIONS-1st')
	AAuso76ah3jqcNTz8bvxp9l1r5RX = X2XorVqHjLkWeCchY4u9fSz.findall('"(https*://akwam.net/\w+.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	kk0uJyDYjF6ez = X2XorVqHjLkWeCchY4u9fSz.findall('"(https*://underurl.com/\w+.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if AAuso76ah3jqcNTz8bvxp9l1r5RX or kk0uJyDYjF6ez:
		if AAuso76ah3jqcNTz8bvxp9l1r5RX: iGxH2fsuScPtkJb7ECg = AAuso76ah3jqcNTz8bvxp9l1r5RX[0]
		elif kk0uJyDYjF6ez: iGxH2fsuScPtkJb7ECg = ctAKMEZeD7oq8xXLR6kS23aO(kk0uJyDYjF6ez[0])
		iGxH2fsuScPtkJb7ECg = kLEi7mYT5wBM4DHsgWy8(iGxH2fsuScPtkJb7ECg)
		import J0TSd9lzne
		if '/series/' in iGxH2fsuScPtkJb7ECg or '/shows/' in iGxH2fsuScPtkJb7ECg: J0TSd9lzne.LRb6nEvgqXwITMc80r1Vt(iGxH2fsuScPtkJb7ECg)
		else: J0TSd9lzne.rRCw3hfy2Kq5l(iGxH2fsuScPtkJb7ECg)
		return
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,73)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ:
		i9yzUqgAW2Zap1h4Lm('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	name = name.strip(qE4nB3mKWHs)
	if 'sub_epsiode_title' in drRnSgoBtKWjmU5FH4ZCIVhzqNb:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		ZK1wWETelPp = X2XorVqHjLkWeCchY4u9fSz.findall('sub_file_title\'>(.*?) - <i>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		items = []
		for filename in ZK1wWETelPp:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',SebHIf2jL1TBgrMKJu) ]
	count = 0
	HFThJNteGZsSR5CD7rimbjPq,F0DBkvQEWaPXLUSVh = [],[]
	size = len(items)
	for title,filename in items:
		MPt7xfvWsZSVk3upBH2YAFQXj = SebHIf2jL1TBgrMKJu
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: MPt7xfvWsZSVk3upBH2YAFQXj = filename.split('.')[-1]
		title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		HFThJNteGZsSR5CD7rimbjPq.append(title)
		F0DBkvQEWaPXLUSVh.append(count)
		count += 1
	if size>0:
		if any(value in name for value in M69nuvKfxWeP05rG1JiEjkaYtIbNT):
			if size==1:
				QQea1XbjZDEMhp = 0
			else:
				QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر الفيديو المناسب:', HFThJNteGZsSR5CD7rimbjPq)
				if QQea1XbjZDEMhp == -1: return
			rRCw3hfy2Kq5l(url+'?section='+str(1+F0DBkvQEWaPXLUSVh[size-QQea1XbjZDEMhp-1]))
		else:
			for YHnALfql8hprDu in reversed(range(size)):
				title = name + ' - ' + HFThJNteGZsSR5CD7rimbjPq[YHnALfql8hprDu]
				title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				cOn6JqZlmQbjtT = url + '?section='+str(size-YHnALfql8hprDu)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,74,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الرابط ليس فيديو',SebHIf2jL1TBgrMKJu,9999,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qg7Nr1dCaD,Wj39BaH6oEmstx = url.split('?section=')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,True,SebHIf2jL1TBgrMKJu,'AKOAM-PLAY_AKOAM-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	x7MK8HSh9YqdAuFO23Q = k2pC30UArFeg7Ru9tGiZlSmzQ[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	x7MK8HSh9YqdAuFO23Q = x7MK8HSh9YqdAuFO23Q + 'direct_link_box'
	cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('epsoide_box(.*?)direct_link_box',x7MK8HSh9YqdAuFO23Q,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	Wj39BaH6oEmstx = len(cuoYjfNMPnmhQgtFE)-int(Wj39BaH6oEmstx)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = cuoYjfNMPnmhQgtFE[Wj39BaH6oEmstx]
	qOGEcWZIwex2fK = []
	KdOfMQURPyC6nb2Wq = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = X2XorVqHjLkWeCchY4u9fSz.findall("class='download_btn.*?href='(.*?)'",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT in items:
		qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=________akoam')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for ggQT1FymYshbEWNKorkzDdZXH,cOn6JqZlmQbjtT in items:
		ggQT1FymYshbEWNKorkzDdZXH = ggQT1FymYshbEWNKorkzDdZXH.split('/')[-1]
		ggQT1FymYshbEWNKorkzDdZXH = ggQT1FymYshbEWNKorkzDdZXH.split('.')[0]
		if ggQT1FymYshbEWNKorkzDdZXH in KdOfMQURPyC6nb2Wq:
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+KdOfMQURPyC6nb2Wq[ggQT1FymYshbEWNKorkzDdZXH]+'________akoam')
		else: qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+ggQT1FymYshbEWNKorkzDdZXH+'________akoam')
	if not qOGEcWZIwex2fK:
		message = X2XorVqHjLkWeCchY4u9fSz.findall('sub-no-file.*?\n(.*?)\n',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if message: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'رسالة من الموقع الاصلي',message[0])
	else:
		import dBWq3E7PZC
		dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'%20')
	url = j1IFsik4ouNePZr + '/search/'+t2WLY7DxIZs
	lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return