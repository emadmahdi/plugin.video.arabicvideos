# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = ALwOspNtXxZrz3PEKku(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
FFe0IfYj65szqgLHkNpBPJnRQEmZo = gCkRKGhwcx26v(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
OgwlPyruLnfxTB8p2jbU = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(TPamrY4p9IEN,TVnqDYzWoM2UfHp0dchJ(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
bXumoYAgcRVQO3FzCN6 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(TPamrY4p9IEN,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
h2gJU0dQj9eM1xNfaTVDb = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,sTGtHVyhQ9cJU37zxo2O(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),VOALf8iYEnMdK0g(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
YOmNaivkgtUozl39u5C7ErGe = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
BuifWzd6sRQUq4m3cxTvJ = czvu7VQCZodkMf(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
vvxLkCGpw2eFZ71DWu = tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
mviRTZnKNaIk = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
GQ4qdriFYJ = VOALf8iYEnMdK0g(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
qd4RCM9tZn0IwHhTE3J5bV = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
FpQaiHrgK45Inf0LeuslB2 = Q8ueUH69goFIxnE2V1
Dd3EBhTnOR = LdX87mwIzyBM
Iw1o5ejk2XNGHcJCugn4fFqSa = bbXNHlqO2VBxsEe
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx):
	if   hL9fngBAu7XzOx==HCiWF4jV1Q8(u"࠹࠷࠴ࣉ"): lfZmugQCFKLGT05AH29IsMiho = flEcYRJOiX3Kuyqt9jC()
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠺࠸࠶࣊"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(OgwlPyruLnfxTB8p2jbU,BBX9RAuxnyGZ4WIF2TrhYeom3,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠻࠹࠸࣋"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(bXumoYAgcRVQO3FzCN6,BBX9RAuxnyGZ4WIF2TrhYeom3,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==czvu7VQCZodkMf(u"࠼࠺࠳࣌"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(h2gJU0dQj9eM1xNfaTVDb,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠽࠴࠵࣍"): lfZmugQCFKLGT05AH29IsMiho = LmJtBTUs3N(BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠷࠵࠷࣎"): lfZmugQCFKLGT05AH29IsMiho = HL9aEc8glvhVjiuQTt5ryPID2SYJ(BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==zpx2fPNKk6Ms38eD1vcO(u"࠸࠶࠹࣏"): lfZmugQCFKLGT05AH29IsMiho = IBqDfzvHen1soE(BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==l7kBpMw5Qn(u"࠹࠸࠴࣐"): lfZmugQCFKLGT05AH29IsMiho = PPphxgJkMb()
	elif hL9fngBAu7XzOx==wPnfgxKZdAv6T10(u"࠺࠹࠶࣑"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(YOmNaivkgtUozl39u5C7ErGe,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==wPnfgxKZdAv6T10(u"࠻࠺࠸࣒"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(BuifWzd6sRQUq4m3cxTvJ,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠼࠻࠳࣓"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(vvxLkCGpw2eFZ71DWu,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==HADrRCz9QgU4xudPJIqYb70(u"࠽࠵࠵ࣔ"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(mviRTZnKNaIk,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠷࠶࠷ࣕ"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(GQ4qdriFYJ,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠸࠷࠹ࣖ"): lfZmugQCFKLGT05AH29IsMiho = VS8fuikmreJGgW6cdLOq2yz(qd4RCM9tZn0IwHhTE3J5bV,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠹࠸࠻ࣗ"): lfZmugQCFKLGT05AH29IsMiho = c2E0dxOULZCRo4Ke(BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==DQIrVcKuY6bJv(u"࠺࠹࠽ࣘ"): lfZmugQCFKLGT05AH29IsMiho = UUxolRzFNrA();xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==AGlW9LqKN3Dvo(u"࠵࠵࠾࠰ࣙ"): lfZmugQCFKLGT05AH29IsMiho = V7B0LR62Z59Eawmy3prYdPbeG8tF()
	elif hL9fngBAu7XzOx==VOALf8iYEnMdK0g(u"࠶࠶࠸࠲ࣚ"): lfZmugQCFKLGT05AH29IsMiho = tcM0XJjxslgZ(BBX9RAuxnyGZ4WIF2TrhYeom3);xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==HADrRCz9QgU4xudPJIqYb70(u"࠷࠰࠹࠴ࣛ"): lfZmugQCFKLGT05AH29IsMiho = eIiZyAfn8u();xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠱࠱࠺࠶ࣜ"): lfZmugQCFKLGT05AH29IsMiho = umnDjsBiP8HwfMZ40eAlbU();xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠲࠲࠻࠸ࣝ"): lfZmugQCFKLGT05AH29IsMiho = IBJElLU4FzO();xIJC3P7Gy1UpO0bmfKqQRer(lfZmugQCFKLGT05AH29IsMiho)
	elif hL9fngBAu7XzOx==HADrRCz9QgU4xudPJIqYb70(u"࠳࠳࠼࠺ࣞ"): lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif hL9fngBAu7XzOx==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠴࠴࠽࠼ࣟ"): lfZmugQCFKLGT05AH29IsMiho = x6x3LPl0Jj9ZfVcatKbyznqr2MYiXO()
	else: lfZmugQCFKLGT05AH29IsMiho = mrhSYXH2P8bO3eJAa9n
	return lfZmugQCFKLGT05AH29IsMiho
def x6x3LPl0Jj9ZfVcatKbyznqr2MYiXO():
	A4d05PotiJvVZwaWjELn = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠵࠵࠸࠴࣠")*cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠵࠵࠸࠴࣠")
	OWyq9BTcz1dKevmG7F6JgYiruoAZ = L89QpfNav5RrOZXYqliW()//A4d05PotiJvVZwaWjELn
	DevrXNsHoPAF806k = OWyq9BTcz1dKevmG7F6JgYiruoAZ<fp6KV7DlS8QYniUczHdmZChL(u"࠺࠶࣡")
	size = E7r8hUCVvTiFQW0dBGXjxcy+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+XOVRfitWJP1zL3p2CMYF
	if DevrXNsHoPAF806k:
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,iDhLkZS6XBagNCQfs9tq2(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,uqLUBHepfM3l6AyIzTJh80a(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return DevrXNsHoPAF806k
def xIJC3P7Gy1UpO0bmfKqQRer(L6gBVcUknMYil4RjQImrHyDwEoWd):
	if L6gBVcUknMYil4RjQImrHyDwEoWd: GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx(DQIrVcKuY6bJv(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),SebHIf2jL1TBgrMKJu,ALwOspNtXxZrz3PEKku(u"࠷࠰࠹࠸࣢"))
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"࠷࠶࠲ࣣ"))
	QUzFYoapm9jx(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),sTGtHVyhQ9cJU37zxo2O(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),SebHIf2jL1TBgrMKJu,HADrRCz9QgU4xudPJIqYb70(u"࠸࠶࠳ࣤ"))
	QUzFYoapm9jx(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),SebHIf2jL1TBgrMKJu,HADrRCz9QgU4xudPJIqYb70(u"࠳࠳࠼࠵ࣥ"))
	return
def V7B0LR62Z59Eawmy3prYdPbeG8tF():
	RigSynMzovh0H3c6,O3nMiVr9NJwIW5s6KG2YyEafQBZm = YYxNnmPkqM9hcZg2(FpQaiHrgK45Inf0LeuslB2)
	VVui8jp6mB5PbUzK1d3g,BBQdaLrK5GAhMvW = YYxNnmPkqM9hcZg2(Dd3EBhTnOR)
	RwG3qrHsucaiYQAx,arqmR2lM4xICY8OKuZtWkn = q5WoBw7x9sIFDEt(Iw1o5ejk2XNGHcJCugn4fFqSa)
	CCY7anjUg3,FFNcd8CyvMxVJ0kZOPBWY = RigSynMzovh0H3c6+VVui8jp6mB5PbUzK1d3g+RwG3qrHsucaiYQAx,O3nMiVr9NJwIW5s6KG2YyEafQBZm+BBQdaLrK5GAhMvW+arqmR2lM4xICY8OKuZtWkn
	UUzT05qiwxXItYSFJsefyNbDjEpB = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࠣࠬࠬࠚ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RigSynMzovh0H3c6)+HCiWF4jV1Q8(u"ࠪࠤ࠲ࠦࠧࠛ")+str(O3nMiVr9NJwIW5s6KG2YyEafQBZm)+HCiWF4jV1Q8(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	l4vqDU9ocLa7YIKhdi6zxF = DQIrVcKuY6bJv(u"ࠬࠦࠨࠨࠝ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(VVui8jp6mB5PbUzK1d3g)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࠠ࠮ࠢࠪࠞ")+str(BBQdaLrK5GAhMvW)+bcNqYtfET5l92dLGjyZSPe(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	DQp8F9BmtE7s4OJk5i = zpx2fPNKk6Ms38eD1vcO(u"ࠨࠢࠫࠫࠠ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RwG3qrHsucaiYQAx)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(arqmR2lM4xICY8OKuZtWkn)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	EEU2vH4cBfo5T3dPe9 = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࠥ࠮ࠧࠣ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(CCY7anjUg3)+fp6KV7DlS8QYniUczHdmZChL(u"ࠬࠦ࠭ࠡࠩࠤ")+str(FFNcd8CyvMxVJ0kZOPBWY)+HADrRCz9QgU4xudPJIqYb70(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	QUzFYoapm9jx(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠴࠴࠽࠺ࣦ"))
	QUzFYoapm9jx(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),E7r8hUCVvTiFQW0dBGXjxcy+gCkRKGhwcx26v(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"࠽࠾࠿࠹ࣧ"))
	QUzFYoapm9jx(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+iDhLkZS6XBagNCQfs9tq2(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+UUzT05qiwxXItYSFJsefyNbDjEpB,SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"࠶࠶࠸࠲ࣨ"))
	QUzFYoapm9jx(HADrRCz9QgU4xudPJIqYb70(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+l7kBpMw5Qn(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+l4vqDU9ocLa7YIKhdi6zxF,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠷࠰࠹࠴ࣩ"))
	QUzFYoapm9jx(HADrRCz9QgU4xudPJIqYb70(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+qeYIw0BNTL9bGJnosacQ1DtVR(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+DQp8F9BmtE7s4OJk5i,SebHIf2jL1TBgrMKJu,zpx2fPNKk6Ms38eD1vcO(u"࠱࠱࠺࠶࣪"))
	QUzFYoapm9jx(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠲࠲࠻࠸࣫"))
	return
def IBJElLU4FzO():
	L6gBVcUknMYil4RjQImrHyDwEoWd = mrhSYXH2P8bO3eJAa9n
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb:
		EeNyOfDmkYAw = umnDjsBiP8HwfMZ40eAlbU()
		XXmzdnMFV2WDQeiZxbrY6Ha1N = VS8fuikmreJGgW6cdLOq2yz(LdX87mwIzyBM,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
		L6gBVcUknMYil4RjQImrHyDwEoWd = EeNyOfDmkYAw and XXmzdnMFV2WDQeiZxbrY6Ha1N
		if L6gBVcUknMYil4RjQImrHyDwEoWd: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ASkvf27etUK0(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ALwOspNtXxZrz3PEKku(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return L6gBVcUknMYil4RjQImrHyDwEoWd
def eIiZyAfn8u():
	import WW03V9yQKJ
	WW03V9yQKJ.Q7EINd1XV6MliUczOr4vtfjs3APg()
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),iDhLkZS6XBagNCQfs9tq2(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = VS8fuikmreJGgW6cdLOq2yz(LdX87mwIzyBM,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
		if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,uqLUBHepfM3l6AyIzTJh80a(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def umnDjsBiP8HwfMZ40eAlbU():
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(VOALf8iYEnMdK0g(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"ࠧิฦส่ࠬ࠻"),gCkRKGhwcx26v(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
		try:
			E2xjtKaMXdC3NDoTm7f5Wkev.remove(bbXNHlqO2VBxsEe)
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE = BBX9RAuxnyGZ4WIF2TrhYeom3
		except: pass
		if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def V7B0LR62Z59Eawmy3prYdPbeG8tF():
	RigSynMzovh0H3c6,O3nMiVr9NJwIW5s6KG2YyEafQBZm = YYxNnmPkqM9hcZg2(FpQaiHrgK45Inf0LeuslB2)
	VVui8jp6mB5PbUzK1d3g,BBQdaLrK5GAhMvW = YYxNnmPkqM9hcZg2(Dd3EBhTnOR)
	RwG3qrHsucaiYQAx,arqmR2lM4xICY8OKuZtWkn = q5WoBw7x9sIFDEt(Iw1o5ejk2XNGHcJCugn4fFqSa)
	CCY7anjUg3,FFNcd8CyvMxVJ0kZOPBWY = RigSynMzovh0H3c6+VVui8jp6mB5PbUzK1d3g+RwG3qrHsucaiYQAx,O3nMiVr9NJwIW5s6KG2YyEafQBZm+BBQdaLrK5GAhMvW+arqmR2lM4xICY8OKuZtWkn
	UUzT05qiwxXItYSFJsefyNbDjEpB = HADrRCz9QgU4xudPJIqYb70(u"ࠫࠥ࠮ࠧ࠿")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RigSynMzovh0H3c6)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࠦ࠭ࠡࠩࡀ")+str(O3nMiVr9NJwIW5s6KG2YyEafQBZm)+wPnfgxKZdAv6T10(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	l4vqDU9ocLa7YIKhdi6zxF = C3w6qluao7EzUxJgMGBtV(u"ࠧࠡࠪࠪࡂ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(VVui8jp6mB5PbUzK1d3g)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࠢ࠰ࠤࠬࡃ")+str(BBQdaLrK5GAhMvW)+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	DQp8F9BmtE7s4OJk5i = HCiWF4jV1Q8(u"ࠪࠤ࠭࠭ࡅ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RwG3qrHsucaiYQAx)+DQIrVcKuY6bJv(u"ࠫࠥ࠳ࠠࠨࡆ")+str(arqmR2lM4xICY8OKuZtWkn)+l7kBpMw5Qn(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	EEU2vH4cBfo5T3dPe9 = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࠠࠩࠩࡈ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(CCY7anjUg3)+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࠡ࠯ࠣࠫࡉ")+str(FFNcd8CyvMxVJ0kZOPBWY)+fp6KV7DlS8QYniUczHdmZChL(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	QUzFYoapm9jx(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+ALwOspNtXxZrz3PEKku(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"࠳࠳࠼࠹࣬"))
	QUzFYoapm9jx(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),E7r8hUCVvTiFQW0dBGXjxcy+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,l7kBpMw5Qn(u"࠼࠽࠾࠿࣭"))
	QUzFYoapm9jx(czvu7VQCZodkMf(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+bcNqYtfET5l92dLGjyZSPe(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+UUzT05qiwxXItYSFJsefyNbDjEpB,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"࠵࠵࠾࠱࣮"))
	QUzFYoapm9jx(VOALf8iYEnMdK0g(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+ypO63g8oJEsDnPBHSuU7lMTZr(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+l4vqDU9ocLa7YIKhdi6zxF,SebHIf2jL1TBgrMKJu,iDhLkZS6XBagNCQfs9tq2(u"࠶࠶࠸࠳࣯"))
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+TVnqDYzWoM2UfHp0dchJ(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+DQp8F9BmtE7s4OJk5i,SebHIf2jL1TBgrMKJu,HADrRCz9QgU4xudPJIqYb70(u"࠷࠰࠹࠵ࣰ"))
	QUzFYoapm9jx(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,VOALf8iYEnMdK0g(u"࠱࠱࠺࠷ࣱ"))
	return
def flEcYRJOiX3Kuyqt9jC():
	RigSynMzovh0H3c6,O3nMiVr9NJwIW5s6KG2YyEafQBZm = YYxNnmPkqM9hcZg2(OgwlPyruLnfxTB8p2jbU)
	VVui8jp6mB5PbUzK1d3g,BBQdaLrK5GAhMvW = YYxNnmPkqM9hcZg2(bXumoYAgcRVQO3FzCN6)
	RwG3qrHsucaiYQAx,arqmR2lM4xICY8OKuZtWkn = YYxNnmPkqM9hcZg2(h2gJU0dQj9eM1xNfaTVDb)
	CCY7anjUg3,FFNcd8CyvMxVJ0kZOPBWY = q5WoBw7x9sIFDEt(ivOwEroeDmMKau)
	CCY7anjUg3 -= t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠴࠸࠻࠺࠹ࣲ")
	FFNcd8CyvMxVJ0kZOPBWY -= nyUIsfd53EGot9vbj0XDeq
	sCwoI6tacuXvUAqOb3 = str(E2xjtKaMXdC3NDoTm7f5Wkev.listdir(qNJcywXjKbdP8ihIrZ5CBaVl))
	t4i29P0sETuyd5MQqcIzWNnBVhOK = sCwoI6tacuXvUAqOb3.count(HCiWF4jV1Q8(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+sCwoI6tacuXvUAqOb3.count(sTGtHVyhQ9cJU37zxo2O(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	UUzT05qiwxXItYSFJsefyNbDjEpB = TVnqDYzWoM2UfHp0dchJ(u"࡙ࠩࠣࠬࠬ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RigSynMzovh0H3c6)+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࠤ࠲࡚ࠦࠧ")+str(O3nMiVr9NJwIW5s6KG2YyEafQBZm)+HADrRCz9QgU4xudPJIqYb70(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	l4vqDU9ocLa7YIKhdi6zxF = vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࠦࠨࠨ࡜")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(VVui8jp6mB5PbUzK1d3g)+sTGtHVyhQ9cJU37zxo2O(u"࠭ࠠ࠮ࠢࠪ࡝")+str(BBQdaLrK5GAhMvW)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	DQp8F9BmtE7s4OJk5i = ASkvf27etUK0(u"ࠨࠢࠫࠫ࡟")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RwG3qrHsucaiYQAx)+ASkvf27etUK0(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(arqmR2lM4xICY8OKuZtWkn)+DQIrVcKuY6bJv(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	EEU2vH4cBfo5T3dPe9 = sTGtHVyhQ9cJU37zxo2O(u"ࠫࠥ࠮ࠧࡢ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(CCY7anjUg3)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬ࠯ࠧࡣ")
	PuxtnYZAfCVJhB = AGlW9LqKN3Dvo(u"࠭ࠠࠩࠩࡤ")+str(t4i29P0sETuyd5MQqcIzWNnBVhOK)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	p95WruwZIyOg0S3PfocnmzL = RigSynMzovh0H3c6+VVui8jp6mB5PbUzK1d3g+RwG3qrHsucaiYQAx+CCY7anjUg3
	w9PHIy57MmhkK4tFRuUYgJxpOeqVor = O3nMiVr9NJwIW5s6KG2YyEafQBZm+BBQdaLrK5GAhMvW+arqmR2lM4xICY8OKuZtWkn+FFNcd8CyvMxVJ0kZOPBWY+t4i29P0sETuyd5MQqcIzWNnBVhOK
	Yg36raSGA02uUXEPMF7itZd9KcWf = ALwOspNtXxZrz3PEKku(u"ࠨࠢࠫࠫࡦ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(p95WruwZIyOg0S3PfocnmzL)+sTGtHVyhQ9cJU37zxo2O(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(w9PHIy57MmhkK4tFRuUYgJxpOeqVor)+czvu7VQCZodkMf(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	QUzFYoapm9jx(uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠹࠷࠹ࣳ"))
	QUzFYoapm9jx(wPnfgxKZdAv6T10(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),E7r8hUCVvTiFQW0dBGXjxcy+TVnqDYzWoM2UfHp0dchJ(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"࠼࠽࠾࠿ࣴ"))
	QUzFYoapm9jx(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+UUzT05qiwxXItYSFJsefyNbDjEpB,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"࠻࠹࠷ࣵ"))
	QUzFYoapm9jx(TVnqDYzWoM2UfHp0dchJ(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+bcNqYtfET5l92dLGjyZSPe(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+l4vqDU9ocLa7YIKhdi6zxF,SebHIf2jL1TBgrMKJu,Izy1PvclrYx4eSVWn0L5phZbq(u"࠼࠺࠲ࣶ"))
	QUzFYoapm9jx(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+iDhLkZS6XBagNCQfs9tq2(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+DQp8F9BmtE7s4OJk5i,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"࠽࠴࠴ࣷ"))
	QUzFYoapm9jx(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+VOALf8iYEnMdK0g(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"࠷࠵࠶ࣸ"))
	QUzFYoapm9jx(wPnfgxKZdAv6T10(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+ypO63g8oJEsDnPBHSuU7lMTZr(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+PuxtnYZAfCVJhB,SebHIf2jL1TBgrMKJu,ALwOspNtXxZrz3PEKku(u"࠸࠶࠹ࣹ"))
	return
def PPphxgJkMb():
	H8gM0nTJzeGQdv7DAWmPSsUqVl6 = BBX9RAuxnyGZ4WIF2TrhYeom3 if TVnqDYzWoM2UfHp0dchJ(u"ࠫ࠴࠭ࡷ") in bnPKxNoAtLQaOC0iSg else mrhSYXH2P8bO3eJAa9n
	if not H8gM0nTJzeGQdv7DAWmPSsUqVl6:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Ns6AJKH7DGpr19Wl5C3nF(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	UmEZCgu87JB = MMAUZiw4CoJ8.getSetting(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not UmEZCgu87JB: UUxolRzFNrA()
	RigSynMzovh0H3c6,O3nMiVr9NJwIW5s6KG2YyEafQBZm = YYxNnmPkqM9hcZg2(YOmNaivkgtUozl39u5C7ErGe)
	VVui8jp6mB5PbUzK1d3g,BBQdaLrK5GAhMvW = YYxNnmPkqM9hcZg2(BuifWzd6sRQUq4m3cxTvJ)
	RwG3qrHsucaiYQAx,arqmR2lM4xICY8OKuZtWkn = YYxNnmPkqM9hcZg2(vvxLkCGpw2eFZ71DWu)
	CCY7anjUg3,FFNcd8CyvMxVJ0kZOPBWY = YYxNnmPkqM9hcZg2(mviRTZnKNaIk)
	Xa5wJh1PrpCmUEAKqo,t4i29P0sETuyd5MQqcIzWNnBVhOK = YYxNnmPkqM9hcZg2(GQ4qdriFYJ)
	SYmiyWpZeoCRBGXjAEdzq1Or94,iNskhuBHKt3yPDUWdom = YYxNnmPkqM9hcZg2(qd4RCM9tZn0IwHhTE3J5bV)
	UUzT05qiwxXItYSFJsefyNbDjEpB = HADrRCz9QgU4xudPJIqYb70(u"ࠧࠡࠪࠪࡺ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RigSynMzovh0H3c6)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࠢ࠰ࠤࠬࡻ")+str(O3nMiVr9NJwIW5s6KG2YyEafQBZm)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	l4vqDU9ocLa7YIKhdi6zxF = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࠤ࠭࠭ࡽ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(VVui8jp6mB5PbUzK1d3g)+C3w6qluao7EzUxJgMGBtV(u"ࠫࠥ࠳ࠠࠨࡾ")+str(BBQdaLrK5GAhMvW)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	DQp8F9BmtE7s4OJk5i = Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࠠࠩࠩࢀ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(RwG3qrHsucaiYQAx)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࠡ࠯ࠣࠫࢁ")+str(arqmR2lM4xICY8OKuZtWkn)+HADrRCz9QgU4xudPJIqYb70(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	EEU2vH4cBfo5T3dPe9 = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࠣࠬࠬࢃ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(CCY7anjUg3)+AGlW9LqKN3Dvo(u"ࠪࠤ࠲ࠦࠧࢄ")+str(FFNcd8CyvMxVJ0kZOPBWY)+fp6KV7DlS8QYniUczHdmZChL(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	PuxtnYZAfCVJhB = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࠦࠨࠨࢆ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(Xa5wJh1PrpCmUEAKqo)+VOALf8iYEnMdK0g(u"࠭ࠠ࠮ࠢࠪࢇ")+str(t4i29P0sETuyd5MQqcIzWNnBVhOK)+TVnqDYzWoM2UfHp0dchJ(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	gvqLHzbZ3CR2Aw = ASkvf27etUK0(u"ࠨࠢࠫࠫࢉ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(SYmiyWpZeoCRBGXjAEdzq1Or94)+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(iNskhuBHKt3yPDUWdom)+DQIrVcKuY6bJv(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	p95WruwZIyOg0S3PfocnmzL = RigSynMzovh0H3c6+VVui8jp6mB5PbUzK1d3g+RwG3qrHsucaiYQAx+CCY7anjUg3+Xa5wJh1PrpCmUEAKqo+SYmiyWpZeoCRBGXjAEdzq1Or94
	w9PHIy57MmhkK4tFRuUYgJxpOeqVor = O3nMiVr9NJwIW5s6KG2YyEafQBZm+BBQdaLrK5GAhMvW+arqmR2lM4xICY8OKuZtWkn+FFNcd8CyvMxVJ0kZOPBWY+t4i29P0sETuyd5MQqcIzWNnBVhOK+iNskhuBHKt3yPDUWdom
	Yg36raSGA02uUXEPMF7itZd9KcWf = wPnfgxKZdAv6T10(u"ࠫࠥ࠮ࠧࢌ")+QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(p95WruwZIyOg0S3PfocnmzL)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࠦ࠭ࠡࠩࢍ")+str(w9PHIy57MmhkK4tFRuUYgJxpOeqVor)+Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	QUzFYoapm9jx(ALwOspNtXxZrz3PEKku(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"࠹࠸࠼ࣺ"))
	QUzFYoapm9jx(czvu7VQCZodkMf(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠺࠹࠼ࣻ"))
	QUzFYoapm9jx(AGlW9LqKN3Dvo(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),E7r8hUCVvTiFQW0dBGXjxcy+czvu7VQCZodkMf(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠽࠾࠿࠹ࣼ"))
	QUzFYoapm9jx(bcNqYtfET5l92dLGjyZSPe(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+bcNqYtfET5l92dLGjyZSPe(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+UUzT05qiwxXItYSFJsefyNbDjEpB,SebHIf2jL1TBgrMKJu,iDhLkZS6XBagNCQfs9tq2(u"࠼࠻࠱ࣽ"))
	QUzFYoapm9jx(bcNqYtfET5l92dLGjyZSPe(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+ASkvf27etUK0(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+l4vqDU9ocLa7YIKhdi6zxF,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"࠽࠵࠳ࣾ"))
	QUzFYoapm9jx(l7kBpMw5Qn(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+uqLUBHepfM3l6AyIzTJh80a(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+DQp8F9BmtE7s4OJk5i,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"࠷࠶࠵ࣿ"))
	QUzFYoapm9jx(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+EEU2vH4cBfo5T3dPe9,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠸࠷࠷ऀ"))
	QUzFYoapm9jx(DQIrVcKuY6bJv(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+HADrRCz9QgU4xudPJIqYb70(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+PuxtnYZAfCVJhB,SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠹࠸࠹ँ"))
	QUzFYoapm9jx(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+gvqLHzbZ3CR2Aw,SebHIf2jL1TBgrMKJu,HCiWF4jV1Q8(u"࠺࠹࠻ं"))
	return
def tcM0XJjxslgZ(showDialogs):
	if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,fp6KV7DlS8QYniUczHdmZChL(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	ZaKrSJuvYBykLG5N3j7TxHFd,VlQyPpikJDOYToUN98zsXbGH16gqKA = [],wvkDqmNZlJU52isXo
	for IkTGuAPoFlsQbq,oolnTdsiw16gtzaN,yR0pjKCZcVe4WmxSawLz in E2xjtKaMXdC3NDoTm7f5Wkev.walk(Q8ueUH69goFIxnE2V1,topdown=mrhSYXH2P8bO3eJAa9n):
		iA1QKSkrRMLvChJ32I = len(yR0pjKCZcVe4WmxSawLz)
		if iA1QKSkrRMLvChJ32I>TVnqDYzWoM2UfHp0dchJ(u"࠹࠵࠶ः"): ZaKrSJuvYBykLG5N3j7TxHFd.append(oolnTdsiw16gtzaN)
		VlQyPpikJDOYToUN98zsXbGH16gqKA += iA1QKSkrRMLvChJ32I
	sYhnTS6U10fZFe = VlQyPpikJDOYToUN98zsXbGH16gqKA>VOALf8iYEnMdK0g(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = E7r8hUCVvTiFQW0dBGXjxcy+ALwOspNtXxZrz3PEKku(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(VlQyPpikJDOYToUN98zsXbGH16gqKA)+ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+XOVRfitWJP1zL3p2CMYF
		if not ZaKrSJuvYBykLG5N3j7TxHFd and not sYhnTS6U10fZFe: sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: sLhog1knUIF4fNOjY2zJqQ7cxArb = nyUIsfd53EGot9vbj0XDeq
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
		if sYhnTS6U10fZFe: VS8fuikmreJGgW6cdLOq2yz(IkTGuAPoFlsQbq,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
		elif ZaKrSJuvYBykLG5N3j7TxHFd:
			for oolnTdsiw16gtzaN in ZaKrSJuvYBykLG5N3j7TxHFd: VS8fuikmreJGgW6cdLOq2yz(oolnTdsiw16gtzaN,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	return
def UUxolRzFNrA():
	L6gBVcUknMYil4RjQImrHyDwEoWd = mrhSYXH2P8bO3eJAa9n
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,zpx2fPNKk6Ms38eD1vcO(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==-qeYIw0BNTL9bGJnosacQ1DtVR(u"࠷अ"): return
	if sLhog1knUIF4fNOjY2zJqQ7cxArb:
		import subprocess as xzDyTRiG0BNtAu3okUgFEnM4
		try:
			xzDyTRiG0BNtAu3okUgFEnM4.Popen(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡷࡺ࠭ࢧ"))
			L6gBVcUknMYil4RjQImrHyDwEoWd = BBX9RAuxnyGZ4WIF2TrhYeom3
		except: pass
		if L6gBVcUknMYil4RjQImrHyDwEoWd:
			dJu7az8lLqCHT6gkt = YOmNaivkgtUozl39u5C7ErGe+qE4nB3mKWHs+BuifWzd6sRQUq4m3cxTvJ+qE4nB3mKWHs+vvxLkCGpw2eFZ71DWu+qE4nB3mKWHs+mviRTZnKNaIk+qE4nB3mKWHs+GQ4qdriFYJ+qE4nB3mKWHs+qd4RCM9tZn0IwHhTE3J5bV
			csAe5dymia6HtJpfF = xzDyTRiG0BNtAu3okUgFEnM4.Popen(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+dJu7az8lLqCHT6gkt+bcNqYtfET5l92dLGjyZSPe(u"ࠬࠨࠧࢩ"),shell=BBX9RAuxnyGZ4WIF2TrhYeom3,stdin=xzDyTRiG0BNtAu3okUgFEnM4.PIPE,stdout=xzDyTRiG0BNtAu3okUgFEnM4.PIPE,stderr=xzDyTRiG0BNtAu3okUgFEnM4.PIPE)
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HCiWF4jV1Q8(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return L6gBVcUknMYil4RjQImrHyDwEoWd
def QCVMHSNzBoGP6AJk4Ye17jEIrdw9D(p95WruwZIyOg0S3PfocnmzL):
	for UKDT87NFpZYyLzHhuqrlWJt in [iDhLkZS6XBagNCQfs9tq2(u"ࠨࡄࠪࢬ"),HCiWF4jV1Q8(u"ࠩࡎࡆࠬࢭ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡑࡇ࠭ࢮ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡌࡈࠧࢯ"),uqLUBHepfM3l6AyIzTJh80a(u"࡚ࠬࡂࠨࢰ")]:
		if p95WruwZIyOg0S3PfocnmzL<Izy1PvclrYx4eSVWn0L5phZbq(u"࠱࠱࠴࠷आ"): break
		else: p95WruwZIyOg0S3PfocnmzL /= gCkRKGhwcx26v(u"࠲࠲࠵࠸࠳࠶इ")
	Yg36raSGA02uUXEPMF7itZd9KcWf = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(p95WruwZIyOg0S3PfocnmzL,UKDT87NFpZYyLzHhuqrlWJt)
	return Yg36raSGA02uUXEPMF7itZd9KcWf
def YYxNnmPkqM9hcZg2(s3sAXFMKNySkWV96tZ=Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧ࠯ࠩࢲ")):
	global PWSwhlr0cC,sskGEF6HAa
	PWSwhlr0cC,sskGEF6HAa = wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
	def yyNvKYe49SVlcFGAQ7O2sg(s3sAXFMKNySkWV96tZ):
		global PWSwhlr0cC,sskGEF6HAa
		if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(s3sAXFMKNySkWV96tZ):
			if wvkDqmNZlJU52isXo and t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(E2xjtKaMXdC3NDoTm7f5Wkev):
				for GyODq3KjeBC0cg29Qx1Z68JUVL in E2xjtKaMXdC3NDoTm7f5Wkev.scandir(s3sAXFMKNySkWV96tZ):
					if GyODq3KjeBC0cg29Qx1Z68JUVL.is_dir(follow_symlinks=mrhSYXH2P8bO3eJAa9n):
						yyNvKYe49SVlcFGAQ7O2sg(GyODq3KjeBC0cg29Qx1Z68JUVL.path)
					elif GyODq3KjeBC0cg29Qx1Z68JUVL.is_file(follow_symlinks=mrhSYXH2P8bO3eJAa9n):
						PWSwhlr0cC += GyODq3KjeBC0cg29Qx1Z68JUVL.stat().st_size
						sskGEF6HAa += nyUIsfd53EGot9vbj0XDeq
			else:
				for GyODq3KjeBC0cg29Qx1Z68JUVL in E2xjtKaMXdC3NDoTm7f5Wkev.listdir(s3sAXFMKNySkWV96tZ):
					jrQko9aChnyI5S6F0tDOY = E2xjtKaMXdC3NDoTm7f5Wkev.path.abspath(E2xjtKaMXdC3NDoTm7f5Wkev.path.join(s3sAXFMKNySkWV96tZ,GyODq3KjeBC0cg29Qx1Z68JUVL))
					if E2xjtKaMXdC3NDoTm7f5Wkev.path.isdir(jrQko9aChnyI5S6F0tDOY):
						yyNvKYe49SVlcFGAQ7O2sg(jrQko9aChnyI5S6F0tDOY)
					elif E2xjtKaMXdC3NDoTm7f5Wkev.path.isfile(jrQko9aChnyI5S6F0tDOY):
						p95WruwZIyOg0S3PfocnmzL,w9PHIy57MmhkK4tFRuUYgJxpOeqVor = q5WoBw7x9sIFDEt(jrQko9aChnyI5S6F0tDOY)
						PWSwhlr0cC += p95WruwZIyOg0S3PfocnmzL
						sskGEF6HAa += w9PHIy57MmhkK4tFRuUYgJxpOeqVor
		return
	try: yyNvKYe49SVlcFGAQ7O2sg(s3sAXFMKNySkWV96tZ)
	except: pass
	return PWSwhlr0cC,sskGEF6HAa
def HL9aEc8glvhVjiuQTt5ryPID2SYJ(showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,E7r8hUCVvTiFQW0dBGXjxcy+zpx2fPNKk6Ms38eD1vcO(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+u43PVWjh7t9YwI+xxRyYsrSCzjifvH4cIqgldeOo(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+u43PVWjh7t9YwI+gCkRKGhwcx26v(u"ࠫฤࠧࠡࠨࢶ")+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return
	JsxG6vUX59lFEND = VS8fuikmreJGgW6cdLOq2yz(OgwlPyruLnfxTB8p2jbU,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
	TJ5MKfdsYeDFgN9zaEhXViAor = VS8fuikmreJGgW6cdLOq2yz(bXumoYAgcRVQO3FzCN6,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
	X1XmlNpe98zFdaEO = VS8fuikmreJGgW6cdLOq2yz(h2gJU0dQj9eM1xNfaTVDb,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	wmCG5raIkUHihQ68fO93y = LmJtBTUs3N(mrhSYXH2P8bO3eJAa9n)
	UyzXSEH1rgilJ9PwNGx7K = IBqDfzvHen1soE(mrhSYXH2P8bO3eJAa9n)
	succeeded = all([JsxG6vUX59lFEND,TJ5MKfdsYeDFgN9zaEhXViAor,X1XmlNpe98zFdaEO,wmCG5raIkUHihQ68fO93y,UyzXSEH1rgilJ9PwNGx7K])
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ASkvf27etUK0(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def c2E0dxOULZCRo4Ke(showDialogs):
	if showDialogs:
		dJu7az8lLqCHT6gkt = YOmNaivkgtUozl39u5C7ErGe+u43PVWjh7t9YwI+BuifWzd6sRQUq4m3cxTvJ+u43PVWjh7t9YwI+vvxLkCGpw2eFZ71DWu+u43PVWjh7t9YwI+mviRTZnKNaIk+u43PVWjh7t9YwI+GQ4qdriFYJ+u43PVWjh7t9YwI+qd4RCM9tZn0IwHhTE3J5bV
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,E7r8hUCVvTiFQW0dBGXjxcy+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+dJu7az8lLqCHT6gkt+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return
	JsxG6vUX59lFEND = VS8fuikmreJGgW6cdLOq2yz(YOmNaivkgtUozl39u5C7ErGe,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	TJ5MKfdsYeDFgN9zaEhXViAor = VS8fuikmreJGgW6cdLOq2yz(BuifWzd6sRQUq4m3cxTvJ,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	X1XmlNpe98zFdaEO = VS8fuikmreJGgW6cdLOq2yz(vvxLkCGpw2eFZ71DWu,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	wmCG5raIkUHihQ68fO93y = VS8fuikmreJGgW6cdLOq2yz(mviRTZnKNaIk,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	UyzXSEH1rgilJ9PwNGx7K = VS8fuikmreJGgW6cdLOq2yz(GQ4qdriFYJ,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	t2trYGAcZefqQ5yF = VS8fuikmreJGgW6cdLOq2yz(qd4RCM9tZn0IwHhTE3J5bV,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	succeeded = all([JsxG6vUX59lFEND,TJ5MKfdsYeDFgN9zaEhXViAor,X1XmlNpe98zFdaEO,wmCG5raIkUHihQ68fO93y,UyzXSEH1rgilJ9PwNGx7K,t2trYGAcZefqQ5yF])
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,czvu7VQCZodkMf(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def LmJtBTUs3N(showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,E7r8hUCVvTiFQW0dBGXjxcy+iDhLkZS6XBagNCQfs9tq2(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=sTGtHVyhQ9cJU37zxo2O(u"࠳ई"): return Izy1PvclrYx4eSVWn0L5phZbq(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = gCkRKGhwcx26v(u"ࡘࡷࡻࡥऊ")
		FFkBWYseogf6EUmRPMy5A = Y7oqZy4HgtlDIxsJ.connect(ivOwEroeDmMKau)
		FFkBWYseogf6EUmRPMy5A.text_factory = str
		BuvcGxfSUokM5EV = FFkBWYseogf6EUmRPMy5A.cursor()
		BuvcGxfSUokM5EV.execute(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		BuvcGxfSUokM5EV.execute(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		BuvcGxfSUokM5EV.execute(ALwOspNtXxZrz3PEKku(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		FFkBWYseogf6EUmRPMy5A.commit()
		BuvcGxfSUokM5EV.execute(AGlW9LqKN3Dvo(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		FFkBWYseogf6EUmRPMy5A.close()
	except: succeeded = gCkRKGhwcx26v(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,gCkRKGhwcx26v(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def IBqDfzvHen1soE(showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+u43PVWjh7t9YwI+u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return ASkvf27etUK0(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = xxRyYsrSCzjifvH4cIqgldeOo(u"ࡔࡳࡷࡨऍ")
	for file in E2xjtKaMXdC3NDoTm7f5Wkev.listdir(qNJcywXjKbdP8ihIrZ5CBaVl):
		if vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		CtexHAfSL1bodO5zuBh8Kj6ypm = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(qNJcywXjKbdP8ihIrZ5CBaVl,file)
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(CtexHAfSL1bodO5zuBh8Kj6ypm)
		except Exception as kQhFMNbH2U:
			succeeded = vMhFypGLHZJbdX4O7oc3W8x(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,str(kQhFMNbH2U))
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HCiWF4jV1Q8(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded