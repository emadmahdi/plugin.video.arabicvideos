# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ALFATIMI'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_FTM_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
ppN3tSIU9hu2i4j = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
jmTOBWxntrCpX5Gd6 = ['3030','628']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==60: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==61: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==62: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==63: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==64: lfZmugQCFKLGT05AH29IsMiho = x8qjyGVUInXLb2H0lioYCdRDhO6(text)
	elif mode==69: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,69,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'ما يتم مشاهدته الان',j1IFsik4ouNePZr,64,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'recent_viewed_vids')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الاكثر مشاهدة',j1IFsik4ouNePZr,64,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'most_viewed_vids')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'اضيفت مؤخرا',j1IFsik4ouNePZr,64,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'recently_added_vids')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فيديو عشوائي',j1IFsik4ouNePZr,64,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'random_vids')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'افلام ومسلسلات',j1IFsik4ouNePZr,61,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'-1')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'البرامج الدينية',j1IFsik4ouNePZr,61,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'-2')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'English Videos',j1IFsik4ouNePZr,61,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'-3')
	return SebHIf2jL1TBgrMKJu
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,kgy9Zm5TCvYHjE3PVQ):
	EdOlIXrDZmMhVRJe8W0Fnap = SebHIf2jL1TBgrMKJu
	if kgy9Zm5TCvYHjE3PVQ not in ['-1','-2','-3']: EdOlIXrDZmMhVRJe8W0Fnap = '?cat='+kgy9Zm5TCvYHjE3PVQ
	qg7Nr1dCaD = j1IFsik4ouNePZr+'/menu_level.php'+EdOlIXrDZmMhVRJe8W0Fnap
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALFATIMI-TITLES-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qqsZ4cK7GdYwVfBohF2XSD,qpkP6YyXi07ea9AcEH2Ozsl = False,False
	for cOn6JqZlmQbjtT,title,count in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.strip(qE4nB3mKWHs)
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
		EdOlIXrDZmMhVRJe8W0Fnap = X2XorVqHjLkWeCchY4u9fSz.findall('cat=(.*?)&',cOn6JqZlmQbjtT,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
		if kgy9Zm5TCvYHjE3PVQ==EdOlIXrDZmMhVRJe8W0Fnap: qqsZ4cK7GdYwVfBohF2XSD = True
		elif qqsZ4cK7GdYwVfBohF2XSD 	or (kgy9Zm5TCvYHjE3PVQ=='-1' and EdOlIXrDZmMhVRJe8W0Fnap in ppN3tSIU9hu2i4j)  						or (kgy9Zm5TCvYHjE3PVQ=='-2' and EdOlIXrDZmMhVRJe8W0Fnap not in jmTOBWxntrCpX5Gd6 and EdOlIXrDZmMhVRJe8W0Fnap not in ppN3tSIU9hu2i4j)  						or (kgy9Zm5TCvYHjE3PVQ=='-3' and EdOlIXrDZmMhVRJe8W0Fnap in jmTOBWxntrCpX5Gd6):
							if count=='1': QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,63)
							else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,61,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,EdOlIXrDZmMhVRJe8W0Fnap)
							qpkP6YyXi07ea9AcEH2Ozsl = True
	if not qpkP6YyXi07ea9AcEH2Ozsl: LRb6nEvgqXwITMc80r1Vt(url)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,True,'ALFATIMI-EPISODES-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pagination(.*?)id="footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	cOn6JqZlmQbjtT = SebHIf2jL1TBgrMKJu
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,cOn6JqZlmQbjtT in items:
		title = title.replace('Add',SebHIf2jL1TBgrMKJu).replace('to Quicklist',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,63,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('(.*?)div',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb=k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	drRnSgoBtKWjmU5FH4ZCIVhzqNb=X2XorVqHjLkWeCchY4u9fSz.findall('pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	items=X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	qg7Nr1dCaD = url.split('?')[0]
	for cOn6JqZlmQbjtT,gH3ueoxVGv8DhOW in items:
		cOn6JqZlmQbjtT = qg7Nr1dCaD + cOn6JqZlmQbjtT
		title = cvlHmV1Kr0FIYSjNnM(gH3ueoxVGv8DhOW)
		title = 'صفحة ' + title
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,62)
	return cOn6JqZlmQbjtT
def rRCw3hfy2Kq5l(url):
	if 'videos.php' in url: url = LRb6nEvgqXwITMc80r1Vt(url)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,True,'ALFATIMI-PLAY-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('playlistfile:"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	nxW9asAySzOt2foFGT4LwmHNl8uZ(url,tfX4sO3hy2H1IbKG,'video')
	return
def x8qjyGVUInXLb2H0lioYCdRDhO6(kgy9Zm5TCvYHjE3PVQ):
	BXupmlPQvMIrweKqkG = { 'mode' : kgy9Zm5TCvYHjE3PVQ }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = zzM3SJI56FnHqsRGAXe(BXupmlPQvMIrweKqkG)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		title = title.strip(qE4nB3mKWHs)
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,63,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + '/search_result.php?query=' + t2WLY7DxIZs
	LRb6nEvgqXwITMc80r1Vt(url)
	return