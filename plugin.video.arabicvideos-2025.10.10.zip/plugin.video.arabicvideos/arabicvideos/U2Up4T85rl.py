# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SHIAVOICE'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SHV_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
headers = {'User-Agent':None}
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==310: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==311: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==312: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==313: lfZmugQCFKLGT05AH29IsMiho = VfTjPe4B6myounKxgI1(url)
	elif mode==314: lfZmugQCFKLGT05AH29IsMiho = K6W3ZDiCchTvt48oVF9re(text)
	elif mode==319: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,319,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="menulinks"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<h5>(.*?)</h5>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
	for qqai0c7OSNreCszImF23EhYV1KnXLx in range(len(items)):
		title = items[qqai0c7OSNreCszImF23EhYV1KnXLx].strip(qE4nB3mKWHs)
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,j1IFsik4ouNePZr,314,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,str(qqai0c7OSNreCszImF23EhYV1KnXLx+1))
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مقاطع شهر',j1IFsik4ouNePZr,314,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'0')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<B>(.*?)</B>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,311)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def K6W3ZDiCchTvt48oVF9re(qqai0c7OSNreCszImF23EhYV1KnXLx):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-LATEST-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if qqai0c7OSNreCszImF23EhYV1KnXLx=='0':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="tab-content"(.*?)</table>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title.strip(qE4nB3mKWHs)
			name = name.strip(qE4nB3mKWHs)
			title = title+' ('+name+')'
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312)
	elif qqai0c7OSNreCszImF23EhYV1KnXLx in ['1','2','3']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(<h5>.*?)<div class="col-lg',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		lsybeWiOfM0mwXhgn7DvH2A = int(qqai0c7OSNreCszImF23EhYV1KnXLx)-1
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[lsybeWiOfM0mwXhgn7DvH2A]
		if qqai0c7OSNreCszImF23EhYV1KnXLx=='1': items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		else: items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,name in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title.strip(qE4nB3mKWHs)
			name = name.strip(qE4nB3mKWHs)
			title = title+' ('+name+')'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,311,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	elif qqai0c7OSNreCszImF23EhYV1KnXLx in ['4','5','6']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(<h5>.*?)</table>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		qqai0c7OSNreCszImF23EhYV1KnXLx = int(qqai0c7OSNreCszImF23EhYV1KnXLx)-4
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[qqai0c7OSNreCszImF23EhYV1KnXLx]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,SSzVkjJwMRLbP5FnN1xes83Tty,title,dxwMtG2cpSBbCVe6HqIfDZn in items:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title.strip(qE4nB3mKWHs)
			SSzVkjJwMRLbP5FnN1xes83Tty = SSzVkjJwMRLbP5FnN1xes83Tty.strip(qE4nB3mKWHs)
			dxwMtG2cpSBbCVe6HqIfDZn = dxwMtG2cpSBbCVe6HqIfDZn.strip(qE4nB3mKWHs)
			if SSzVkjJwMRLbP5FnN1xes83Tty: name = SSzVkjJwMRLbP5FnN1xes83Tty
			else: name = dxwMtG2cpSBbCVe6HqIfDZn
			title = title+' ('+name+')'
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('ibox-heading"(.*?)class="float-right',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if 'catsum-mobile' in drRnSgoBtKWjmU5FH4ZCIVhzqNb:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if items:
			for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title,count in items:
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = j1IFsik4ouNePZr+'/'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
				count = count.replace(' الصوتية: ',':')
				title = title.strip(qE4nB3mKWHs)
				title = title+' ('+count+')'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,311,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title,s8sR9u2XWiAmPqMN,lEeAaSobjWc in items:
			if title==SebHIf2jL1TBgrMKJu or s8sR9u2XWiAmPqMN==SebHIf2jL1TBgrMKJu: continue
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title+' ('+lEeAaSobjWc+')'
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312)
	if not items: LRb6nEvgqXwITMc80r1Vt(LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	return
def LRb6nEvgqXwITMc80r1Vt(LCK8lO2yRWaTVEQcdjPXAzpFBe9):
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="ibox-content"(.*?)class="pagination',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title,name,count,lEeAaSobjWc in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)
		name = name.strip(qE4nB3mKWHs)
		title = title+' ('+name+')'
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312,SebHIf2jL1TBgrMKJu,lEeAaSobjWc)
	return
def VfTjPe4B6myounKxgI1(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-SEARCH_ITEMS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="ibox-content p-1"(.*?)class="ibox-content"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ:
		yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
		return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<strong>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)
		if '/play-' in cOn6JqZlmQbjtT: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,311)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('<audio.*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('<video.*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT[0]
	nxW9asAySzOt2foFGT4LwmHNl8uZ(cOn6JqZlmQbjtT,tfX4sO3hy2H1IbKG,'video')
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	yoESesqL7O0aBb9HR = ['&t=a','&t=c','&t=s']
	if showDialogs:
		kn43fuNLeQS7gJtG2lqh = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('موقع صوت الشيعة - أختر البحث', kn43fuNLeQS7gJtG2lqh)
		if QQea1XbjZDEMhp == -1: return
	elif '_SHIAVOICE-PERSONS_' in ndiZQ7oLFkV1W: QQea1XbjZDEMhp = 0
	elif '_SHIAVOICE-ALBUMS_' in ndiZQ7oLFkV1W: QQea1XbjZDEMhp = 1
	elif '_SHIAVOICE-AUDIOS_' in ndiZQ7oLFkV1W: QQea1XbjZDEMhp = 2
	else: return
	type = yoESesqL7O0aBb9HR[QQea1XbjZDEMhp]
	url = j1IFsik4ouNePZr+'/search.php?q='+search+type
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHIAVOICE-SEARCH-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="ibox-content"(.*?)class="ibox-content"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		if QQea1XbjZDEMhp in [0,1]:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,name in items:
				title = title.strip(qE4nB3mKWHs)
				name = name.strip(qE4nB3mKWHs)
				title = title+' ('+name+')'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,313,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif QQea1XbjZDEMhp==2:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title,name in items:
				title = title.strip(qE4nB3mKWHs)
				name = name.strip(qE4nB3mKWHs)
				title = title+' ('+name+')'
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,312)
	return