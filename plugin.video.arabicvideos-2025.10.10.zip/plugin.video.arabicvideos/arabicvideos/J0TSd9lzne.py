# -*- coding: utf-8 -*-
from RSdDifzoPG import *
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
tfX4sO3hy2H1IbKG = 'AKWAM'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_AKW_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
AdtNM4OHCUIkL = SebHIf2jL1TBgrMKJu
jgvMWZhtPlBT = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==240: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==241: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==242: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==243: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==244: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FILTERS___'+text)
	elif mode==245: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'CATEGORIES___'+text)
	elif mode==246: lfZmugQCFKLGT05AH29IsMiho = irB6L1M7ksDyn0ToWI2A(url)
	elif mode==247: lfZmugQCFKLGT05AH29IsMiho = wfBe0qLFEsX9mZopPiW(url)
	elif mode==248: lfZmugQCFKLGT05AH29IsMiho = eFRVWYu7nkaPNd()
	elif mode==249: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def eFRVWYu7nkaPNd():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAM-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	SS4Nf8t6a1mkyqiBYn = X2XorVqHjLkWeCchY4u9fSz.findall('home-site-btn-container.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if SS4Nf8t6a1mkyqiBYn: SS4Nf8t6a1mkyqiBYn = SS4Nf8t6a1mkyqiBYn[0]
	else: SS4Nf8t6a1mkyqiBYn = j1IFsik4ouNePZr
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',SS4Nf8t6a1mkyqiBYn,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAM-MENU-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,249,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',j1IFsik4ouNePZr,246)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',j1IFsik4ouNePZr,247)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',SS4Nf8t6a1mkyqiBYn,241,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	C6XetRpgL0jIUWausErYnq = X2XorVqHjLkWeCchY4u9fSz.findall('recently-container.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	cOn6JqZlmQbjtT = C6XetRpgL0jIUWausErYnq[0]
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أضيف حديثا',cOn6JqZlmQbjtT,241)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
		if name in jgvMWZhtPlBT: continue
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,cOn6JqZlmQbjtT,241)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			title = name+qE4nB3mKWHs+title
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,241)
	return
def irB6L1M7ksDyn0ToWI2A(website=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKWAM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu(.*?)<nav',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?text">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT:
				title = title+' مصنفة'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,245)
		if website==SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def wfBe0qLFEsX9mZopPiW(website=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKWAM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu(.*?)<nav',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?text">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT:
				title = title+' مفلترة'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,244)
		if website==SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('swiper-container(.*?)swiper-button-prev',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="widget"(.*?)main-footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not items:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
			if '/series/' in cOn6JqZlmQbjtT or '/shows/' in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,242,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			elif '/movies/' in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,243,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			elif '/games/' not in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,243,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,241)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'%20')
	url = j1IFsik4ouNePZr + '/search?q='+t2WLY7DxIZs
	lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Icon')
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'رابط التشغيل',url,243,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('-episodes">(.*?)<div class="widget-4',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		EiadFrl0bx3uWPqGmIkHNQp = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in EiadFrl0bx3uWPqGmIkHNQp:
			title = title.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,242,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,243,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,True,'AKWAM-PLAY-1st')
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('badge-danger.*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	zwA9GVoWeIT7lZdH6 = X2XorVqHjLkWeCchY4u9fSz.findall('li><a href="#(.*?)".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq,cuoYjfNMPnmhQgtFE,JH7rPRZ9u3A6lTOd = [],[],[],[]
	if zwA9GVoWeIT7lZdH6:
		MPt7xfvWsZSVk3upBH2YAFQXj = 'mp4'
		for hYWURwpIKyd,lcbjBn3FdZxC1059A4Kqvi2pugJOa in zwA9GVoWeIT7lZdH6:
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('tab-content quality" id="'+hYWURwpIKyd+'".*?</div>.\s*</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			cuoYjfNMPnmhQgtFE.append(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
			JH7rPRZ9u3A6lTOd.append(lcbjBn3FdZxC1059A4Kqvi2pugJOa)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="qualities(.*?)<h3.*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb,filename = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			yy3UqGQkP85FaLw = ['zip','rar','txt','pdf','htm','tar','iso','html']
			MPt7xfvWsZSVk3upBH2YAFQXj = filename.rsplit('.',1)[1].strip(qE4nB3mKWHs)
			if MPt7xfvWsZSVk3upBH2YAFQXj in yy3UqGQkP85FaLw:
				gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'الملف ليس فيديو ولا صوت')
				return
		cuoYjfNMPnmhQgtFE.append(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
		JH7rPRZ9u3A6lTOd.append(SebHIf2jL1TBgrMKJu)
	for YHnALfql8hprDu in range(len(cuoYjfNMPnmhQgtFE)):
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?icon-(.*?)"',cuoYjfNMPnmhQgtFE[YHnALfql8hprDu],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,Z4dOBoSMkuetC8zymG in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			if 'torrent' in Z4dOBoSMkuetC8zymG: continue
			elif 'download' in Z4dOBoSMkuetC8zymG: type = 'download'
			elif 'play' in Z4dOBoSMkuetC8zymG: type = 'watch'
			else: type = 'unknown'
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named=__'+type+'____'+JH7rPRZ9u3A6lTOd[YHnALfql8hprDu]+'__akwam'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def vimwpBGoVK3EZrUkjPL(url,filter):
	PD0JksfFrlMUtG6OWVLgdiY8o5b = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='CATEGORIES':
		if PD0JksfFrlMUtG6OWVLgdiY8o5b[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[0]
		for YHnALfql8hprDu in range(len(PD0JksfFrlMUtG6OWVLgdiY8o5b[0:-1])):
			if PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'all')
		qg7Nr1dCaD = url+'?'+LnwzHFAVsfO2Go
	elif type=='FILTERS':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'all')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'?'+wk0AjSOpcRB
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها',qg7Nr1dCaD,241,SebHIf2jL1TBgrMKJu,'1')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',qg7Nr1dCaD,241,SebHIf2jL1TBgrMKJu,'1')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,True,'AKWAM-FILTERS_MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<form id(.*?)</form>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	dict = {}
	for oIi8QaPyZBr1mvUcsh,name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<option(.*?)>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='CATEGORIES':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<=1:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'CATEGORIES___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,241,SebHIf2jL1TBgrMKJu,'1')
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,245,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FILTERS':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع : '+name,qg7Nr1dCaD,244,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			if 'value' not in value: value = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			else: value = X2XorVqHjLkWeCchY4u9fSz.findall('"(.*?)"',value,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' : '#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' : '+name
			if type=='FILTERS': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,244,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='CATEGORIES' and PD0JksfFrlMUtG6OWVLgdiY8o5b[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'all')
				iGxH2fsuScPtkJb7ECg = url+'?'+LnwzHFAVsfO2Go
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,241,SebHIf2jL1TBgrMKJu,'1')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,245,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	CIHKiYt9osw4SyjMfhP0rZ8 = ['section','category','rating','year','language','formats','quality']
	for key in CIHKiYt9osw4SyjMfhP0rZ8:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	return hIyBYfuc8oTsEZ