# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'MOVS4U'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_M4U_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['انواع افلام','جودات افلام']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==380: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==381: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==382: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==383: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==389: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,389,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',j1IFsik4ouNePZr,381,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجانبية',j1IFsik4ouNePZr,381,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'sider')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MOVS4U-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<header>.*?<h2>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for qqai0c7OSNreCszImF23EhYV1KnXLx in range(len(items)):
		title = items[qqai0c7OSNreCszImF23EhYV1KnXLx]
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,j1IFsik4ouNePZr,381,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'latest'+str(qqai0c7OSNreCszImF23EhYV1KnXLx))
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu"(.*?)id="contenedor"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb += k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="sidebar(.*?)aside',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb += k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	cZs2GKDIAnwSryJ0R7m3 = True
	for cOn6JqZlmQbjtT,title in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		if title=='الأعلى مشاهدة':
			if cZs2GKDIAnwSryJ0R7m3:
				title = 'الافلام '+title
				cZs2GKDIAnwSryJ0R7m3 = False
			else: title = 'المسلسلات '+title
		if title not in jgvMWZhtPlBT:
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,381)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type):
	drRnSgoBtKWjmU5FH4ZCIVhzqNb,items = [],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MOVS4U-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if type=='search':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="search-page"(.*?)class="sidebar',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='sider':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="widget(.*?)class="widget',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		MdaC7qXkHnIS = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		bQGVWFxKS4D6p9YC7XPyA8Os,cr1ok5Ww9FQh,HFThJNteGZsSR5CD7rimbjPq = zip(*MdaC7qXkHnIS)
		items = zip(cr1ok5Ww9FQh,bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq)
	elif type=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="slider-movies-tvshows"(.*?)<header>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif 'latest' in type:
		qqai0c7OSNreCszImF23EhYV1KnXLx = int(type[-1:])
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('<header>','<end><start>')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('<div class="sidebar','<end><div class="sidebar')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<start>(.*?)<end>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[qqai0c7OSNreCszImF23EhYV1KnXLx]
		if qqai0c7OSNreCszImF23EhYV1KnXLx==2: items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="content"(.*?)class="(pagination|sidebar)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0][0]
			if '/collection/' in url:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			elif '/quality/' in url:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items and drRnSgoBtKWjmU5FH4ZCIVhzqNb:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if 'serie' in title:
			title = X2XorVqHjLkWeCchY4u9fSz.findall('^(.*?)<.*?serie">(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			title = title[0][1]
			if title in aLlVEzy8XR62: continue
			aLlVEzy8XR62.append(title)
			title = '_MOD_'+title
		sABprza7wEOC0Fd3PTQ = X2XorVqHjLkWeCchY4u9fSz.findall('^(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if sABprza7wEOC0Fd3PTQ: title = sABprza7wEOC0Fd3PTQ[0]
		title = cvlHmV1Kr0FIYSjNnM(title)
		if '/tvshows/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,383,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/episodes/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,383,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/seasons/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,383,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/collection/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,381,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,382,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		r1qBRmv8sD = k2pC30UArFeg7Ru9tGiZlSmzQ[0][0]
		fxsz7SuMvhHdQ6EkaOITt9lW5X = k2pC30UArFeg7Ru9tGiZlSmzQ[0][1]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0][2]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("href='(.*?)'.*?>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title==SebHIf2jL1TBgrMKJu or title==fxsz7SuMvhHdQ6EkaOITt9lW5X: continue
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,381,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('/page/'+title+'/','/page/'+fxsz7SuMvhHdQ6EkaOITt9lW5X+'/')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'اخر صفحة '+fxsz7SuMvhHdQ6EkaOITt9lW5X,cOn6JqZlmQbjtT,381,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MOVS4U-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('class="C rated".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa,False):
		QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المسلسل للكبار والمبرمج منعه',SebHIf2jL1TBgrMKJu,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('''class='item'><a href="(.*?)"''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if qg7Nr1dCaD:
			qg7Nr1dCaD = qg7Nr1dCaD[1]
			LRb6nEvgqXwITMc80r1Vt(qg7Nr1dCaD)
			return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''class='episodios'(.*?)id="cast"''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,Wj39BaH6oEmstx,cOn6JqZlmQbjtT,name in items:
			title = Wj39BaH6oEmstx+' : '+name+' الحلقة'
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,382)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MOVS4U-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('class="C rated".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0][0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("data-url='(.*?)'.*?class='server'>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="remodal"(.*?)class="remodal-close"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return