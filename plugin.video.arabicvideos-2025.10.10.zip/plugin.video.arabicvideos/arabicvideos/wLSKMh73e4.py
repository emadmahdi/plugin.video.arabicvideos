# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'AKWAMTUBE'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_AKT_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['الرئيسية','يلا شوت','افلام بحسب النوع']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==850: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==851: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==852: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==853: lfZmugQCFKLGT05AH29IsMiho = CsVyWa8pw0oiQ79zEl(url)
	elif mode==859: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAMTUBE-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,859,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"primary-links"(.*?)</u',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,851)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"list-categories"(.*?)</u',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT.lstrip('/')
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,851)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAMTUBE-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"home-content"(.*?)"footer"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('"overlay"','"duration"><')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		aLlVEzy8XR62 = []
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,cOn6JqZlmQbjtT,title in items:
			title = title.strip(' ')
			title = cvlHmV1Kr0FIYSjNnM(title)
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if 0 and 'episodes' not in kpiJl1MHXD5 and Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0][0]
				title = title.replace('اون لاين',SebHIf2jL1TBgrMKJu)
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,853,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,852,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''["']pagination["'](.*?)["']footer["']''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,851,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
	return
def CsVyWa8pw0oiQ79zEl(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAMTUBE-SERIES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="eplist"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		EiadFrl0bx3uWPqGmIkHNQp = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in EiadFrl0bx3uWPqGmIkHNQp:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,872)
	else:
		cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"category".*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if cOn6JqZlmQbjtT:
			cOn6JqZlmQbjtT = xuCTZaNtMVwFs(cOn6JqZlmQbjtT[0])
			yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(cOn6JqZlmQbjtT,'episodes')
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKWAMTUBE-PLAY-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'hash=' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		U1RP0Fyg8QoGL4waApm = X2XorVqHjLkWeCchY4u9fSz.findall('hash=(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		U1RP0Fyg8QoGL4waApm = list(set(U1RP0Fyg8QoGL4waApm))
		for BHvXNYSAsJ0dLy4MCw3ilODxIrGtT in U1RP0Fyg8QoGL4waApm:
			cnS3aMO4lEXQFWPGfqe = []
			YY9GyjxZl6 = BHvXNYSAsJ0dLy4MCw3ilODxIrGtT.split('__')
			for jdIsVqWvu6ibCGo7Tf2t5YUEOPm in YY9GyjxZl6:
				try:
					jdIsVqWvu6ibCGo7Tf2t5YUEOPm = ej3oxQLc68OIY.b64decode(jdIsVqWvu6ibCGo7Tf2t5YUEOPm+'=')
					if QBOMjKifEAFD: jdIsVqWvu6ibCGo7Tf2t5YUEOPm = jdIsVqWvu6ibCGo7Tf2t5YUEOPm.decode(Tv08xsf9HOqunIVUPdK1)
					cnS3aMO4lEXQFWPGfqe.append(jdIsVqWvu6ibCGo7Tf2t5YUEOPm)
				except: pass
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = '>'.join(cnS3aMO4lEXQFWPGfqe)
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT.splitlines()
			for cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
				if ' => ' in cOn6JqZlmQbjtT:
					title,cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split(' => ')
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
					qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	elif 'post_id' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		B8vJbFtznDGZ6ASw0V2 = X2XorVqHjLkWeCchY4u9fSz.findall("post_id = '(.*?)'",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if B8vJbFtznDGZ6ASw0V2:
			B8vJbFtznDGZ6ASw0V2 = B8vJbFtznDGZ6ASw0V2[0]
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/wp-admin/admin-ajax.php?action=video_info&post_id='+B8vJbFtznDGZ6ASw0V2
			Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',cOn6JqZlmQbjtT,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-PLAY-2nd')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('"name":"(.*?)","src":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if not uLdRirAZJKoSgPqNUjm84WXE5cn3aT: uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('"(src)":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for name,cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('\\/','/')
				cOn6JqZlmQbjtT = xuCTZaNtMVwFs(cOn6JqZlmQbjtT)
				if name=='src': name = ''
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+name+'__watch')
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return