# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'MYCIMA'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_MCM_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['مصارعة حرة','wwe']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==360: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==361: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==362: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==363: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url,text)
	elif mode==364: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'CATEGORIES___'+text)
	elif mode==365: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FILTERS___'+text)
	elif mode==366: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==369: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text,url)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',j1IFsik4ouNePZr,369,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',j1IFsik4ouNePZr+'/AjaxCenter/RightBar',364)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',j1IFsik4ouNePZr+'/AjaxCenter/RightBar',365)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-MENU-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu-item.*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title==SebHIf2jL1TBgrMKJu: continue
			if any(value in title.lower() for value in jgvMWZhtPlBT): continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,366)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('hoverable activable(.*?)hoverable activable',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,366,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'class="Slider--Grid"' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',url,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="list--Tabsui"(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,361)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(wwLYf6uzSUMkv8TnB,type=SebHIf2jL1TBgrMKJu):
	if '::' in wwLYf6uzSUMkv8TnB:
		iGxH2fsuScPtkJb7ECg,url = wwLYf6uzSUMkv8TnB.split('::')
		YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(iGxH2fsuScPtkJb7ECg,'url')
		url = YdzfwOyPb2gxT37B9Dm+url
	else: url,iGxH2fsuScPtkJb7ECg = wwLYf6uzSUMkv8TnB,wwLYf6uzSUMkv8TnB
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if type=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='filters':
		k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('\\/','/').replace('\\"','"')]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			if any(value in title.lower() for value in jgvMWZhtPlBT): continue
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = a549mfV8gnzXpwlFr(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = a549mfV8gnzXpwlFr(title)
			title = title.replace('مشاهدة ',SebHIf2jL1TBgrMKJu)
			if '/series/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,363,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			elif 'حلقة' in title:
				Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) +حلقة +\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if Wj39BaH6oEmstx: title = '_MOD_' + Wj39BaH6oEmstx[0]
				if title not in aLlVEzy8XR62:
					aLlVEzy8XR62.append(title)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,363,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else:
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,362,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		if type=='filters':
			aOcSDH75NIYFk8fP = X2XorVqHjLkWeCchY4u9fSz.findall('"more_button_page":(.*?),',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if aOcSDH75NIYFk8fP:
				count = aOcSDH75NIYFk8fP[0]
				cOn6JqZlmQbjtT = url+'/offset/'+count
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة أخرى',cOn6JqZlmQbjtT,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
		elif type==SebHIf2jL1TBgrMKJu:
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if k2pC30UArFeg7Ru9tGiZlSmzQ:
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
				items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for cOn6JqZlmQbjtT,title in items:
					title = 'صفحة '+cvlHmV1Kr0FIYSjNnM(title)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,361)
	return
def LRb6nEvgqXwITMc80r1Vt(url,type=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = kLEi7mYT5wBM4DHsgWy8(LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	name = X2XorVqHjLkWeCchY4u9fSz.findall('itemprop="item" href=".*?/series/(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if name: name = name[-1].replace('-',qE4nB3mKWHs).strip('/')
	if 'موسم' in name and type==SebHIf2jL1TBgrMKJu:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
	else: name = name
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="Seasons--Episodes"(.*?)</singlesection',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		if type==SebHIf2jL1TBgrMKJu:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,363,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'episodes')
		if len(qFsuKN7ngp.menuItemsLIST)==0:
			Q4idDwN25EKRJCajSyc = X2XorVqHjLkWeCchY4u9fSz.findall('class="Episodes--Seasons--Episodes"(.*?)&&',drRnSgoBtKWjmU5FH4ZCIVhzqNb+'&&',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Q4idDwN25EKRJCajSyc: drRnSgoBtKWjmU5FH4ZCIVhzqNb = Q4idDwN25EKRJCajSyc[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<episodeTitle>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = title.strip(qE4nB3mKWHs)
				title = name+' - '+title
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,362)
	if len(qFsuKN7ngp.menuItemsLIST)==0:
		title = X2XorVqHjLkWeCchY4u9fSz.findall('<title>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',SebHIf2jL1TBgrMKJu).replace('مشاهدة ',SebHIf2jL1TBgrMKJu)
		else: title = 'ملف التشغيل'
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,362)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa:
		S5u2RZG3yCOl9gp8D4JVoa = [S5u2RZG3yCOl9gp8D4JVoa[0][0],S5u2RZG3yCOl9gp8D4JVoa[0][1]]
		if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-url="(.*?)".*?strong>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name in items:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if name=='سيرفر ماي سيما': name = 'mycima'
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="List--Download(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,lcbjBn3FdZxC1059A4Kqvi2pugJOa in items:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			lcbjBn3FdZxC1059A4Kqvi2pugJOa = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',lcbjBn3FdZxC1059A4Kqvi2pugJOa,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if lcbjBn3FdZxC1059A4Kqvi2pugJOa: lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa[0]
			else: lcbjBn3FdZxC1059A4Kqvi2pugJOa = SebHIf2jL1TBgrMKJu
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named=mycima'+'__download'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search,rTOz6fQRDJgaidY4Pt=SebHIf2jL1TBgrMKJu):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	bQGVWFxKS4D6p9YC7XPyA8Os = ['/list','/','/list/series','/list/anime','/list/tv']
	JFsnEmbRzSf8aVy5GZ9k = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر النوع المطلوب:', JFsnEmbRzSf8aVy5GZ9k)
		if QQea1XbjZDEMhp==-1: return
	else: QQea1XbjZDEMhp = 0
	if rTOz6fQRDJgaidY4Pt==SebHIf2jL1TBgrMKJu:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,False,SebHIf2jL1TBgrMKJu,'MYCIMA-SEARCH-1st')
		rTOz6fQRDJgaidY4Pt = Bc5IUelt4sWvMXTdy.headers['Location']
		rTOz6fQRDJgaidY4Pt = rTOz6fQRDJgaidY4Pt.strip('/')
	qg7Nr1dCaD = rTOz6fQRDJgaidY4Pt+'/search/'+search+bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
	return
def vimwpBGoVK3EZrUkjPL(wwLYf6uzSUMkv8TnB,filter):
	if '??' in wwLYf6uzSUMkv8TnB: url = wwLYf6uzSUMkv8TnB.split('//getposts??')[0]
	else: url = wwLYf6uzSUMkv8TnB
	filter = filter.replace('_FORGETRESULTS_',SebHIf2jL1TBgrMKJu)
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='CATEGORIES':
		if KrX5dieyIm6p0UBAoFbCQY[0]+'==' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = KrX5dieyIm6p0UBAoFbCQY[0]
		for YHnALfql8hprDu in range(len(KrX5dieyIm6p0UBAoFbCQY[0:-1])):
			if KrX5dieyIm6p0UBAoFbCQY[YHnALfql8hprDu]+'==' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = KrX5dieyIm6p0UBAoFbCQY[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+kgy9Zm5TCvYHjE3PVQ+'==0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+kgy9Zm5TCvYHjE3PVQ+'==0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&&')+'___'+hW2bu9H1KJCkPlfr.strip('&&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'//getposts??'+LnwzHFAVsfO2Go
	elif type=='FILTERS':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'//getposts??'+wk0AjSOpcRB
		vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(qg7Nr1dCaD,wwLYf6uzSUMkv8TnB)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',vz42ouckGgElI,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',vz42ouckGgElI,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'MYCIMA-FILTERS_MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('\\"','"').replace('\\/','/')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<mycima--filter(.*?)</mycima--filter>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',drRnSgoBtKWjmU5FH4ZCIVhzqNb+'<filterbox',X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	dict = {}
	for oIi8QaPyZBr1mvUcsh,name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		name = a549mfV8gnzXpwlFr(name)
		if 'interest' in oIi8QaPyZBr1mvUcsh: continue
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '==' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='CATEGORIES':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<=1:
				if oIi8QaPyZBr1mvUcsh==KrX5dieyIm6p0UBAoFbCQY[-1]: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'CATEGORIES___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(qg7Nr1dCaD,wwLYf6uzSUMkv8TnB)
				if oIi8QaPyZBr1mvUcsh==KrX5dieyIm6p0UBAoFbCQY[-1]:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',vz42ouckGgElI,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,364,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FILTERS':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+oIi8QaPyZBr1mvUcsh+'==0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+oIi8QaPyZBr1mvUcsh+'==0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name+': الجميع',qg7Nr1dCaD,365,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql+'_FORGETRESULTS_')
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			name = a549mfV8gnzXpwlFr(name)
			OSEMFXaUVI1eqHhQYmbKPdJAnrk = a549mfV8gnzXpwlFr(OSEMFXaUVI1eqHhQYmbKPdJAnrk)
			if value=='r' or value=='nc-17': continue
			if any(value in OSEMFXaUVI1eqHhQYmbKPdJAnrk.lower() for value in jgvMWZhtPlBT): continue
			if 'http' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			if 'الكل' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			if 'n-a' in value: continue
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk==SebHIf2jL1TBgrMKJu: OSEMFXaUVI1eqHhQYmbKPdJAnrk = value
			o7MeOx6PDA1d = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			SSzVkjJwMRLbP5FnN1xes83Tty = X2XorVqHjLkWeCchY4u9fSz.findall('<name>(.*?)</name>',OSEMFXaUVI1eqHhQYmbKPdJAnrk,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if SSzVkjJwMRLbP5FnN1xes83Tty: o7MeOx6PDA1d = SSzVkjJwMRLbP5FnN1xes83Tty[0]
			sABprza7wEOC0Fd3PTQ = name+': '+o7MeOx6PDA1d
			dict[oIi8QaPyZBr1mvUcsh][value] = sABprza7wEOC0Fd3PTQ
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+oIi8QaPyZBr1mvUcsh+'=='+o7MeOx6PDA1d
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+oIi8QaPyZBr1mvUcsh+'=='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			if type=='FILTERS':
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,url,365,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and KrX5dieyIm6p0UBAoFbCQY[-2]+'==' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				iGxH2fsuScPtkJb7ECg = url+'//getposts??'+LnwzHFAVsfO2Go
				vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(iGxH2fsuScPtkJb7ECg,wwLYf6uzSUMkv8TnB)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,vz42ouckGgElI,361,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,url,364,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
KrX5dieyIm6p0UBAoFbCQY = ['genre','release-year','nation']
pLFecJvwthCVzxfoijl2UnOG = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def SYewG3Mo6biOIQmH0NP2KWj(qg7Nr1dCaD,iGxH2fsuScPtkJb7ECg):
	if '/AjaxCenter/RightBar' in qg7Nr1dCaD: qg7Nr1dCaD = qg7Nr1dCaD.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	qg7Nr1dCaD = qg7Nr1dCaD.replace('//getposts??','::/AjaxCenter/Filtering/')
	qg7Nr1dCaD = qg7Nr1dCaD.replace('==','/')
	qg7Nr1dCaD = qg7Nr1dCaD.replace('&&','/')
	return qg7Nr1dCaD
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&&')
	sezY2ok3RI69Oahwu7LCQAGUitZH,hIyBYfuc8oTsEZ = {},SebHIf2jL1TBgrMKJu
	if '==' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('==')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	for key in pLFecJvwthCVzxfoijl2UnOG:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&&'+key+'=='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&&'+key+'=='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&&')
	return hIyBYfuc8oTsEZ