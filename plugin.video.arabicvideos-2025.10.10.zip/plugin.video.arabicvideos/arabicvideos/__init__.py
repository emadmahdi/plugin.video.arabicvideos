# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from SSCitzlpRq import *
tfX4sO3hy2H1IbKG = iDhLkZS6XBagNCQfs9tq2(u"ࠧࡊࡐࡌࡘࠬኻ")
q3pa7y0fEM6KFHmDlb = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨኼ")
kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
hhUXrunoxlSpv5mif64jWe2E3DA = int(A9x6WFVrq3cG8)
BMyb581fzrTX = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪኽ"))
BMyb581fzrTX = BMyb581fzrTX.replace(RVDd7BHXajCMPpNksx81nSAhzYq,SebHIf2jL1TBgrMKJu).replace(FhvNwRL5BAMa,SebHIf2jL1TBgrMKJu)
if hhUXrunoxlSpv5mif64jWe2E3DA==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠷࠼࠰ዣ"): LMuQDNp8c9VkAWP4YofZBXj = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫኾ")+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+fp6KV7DlS8QYniUczHdmZChL(u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ኿")+bjfOp7nz3IHklMhUvLgd1xC+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠦ࡝ࠨዀ")
else:
	emU0N6XCtvHdD2WKpf = kLEi7mYT5wBM4DHsgWy8(EWTFwqJoXHGSjsRfhOI5YLM).replace(E7r8hUCVvTiFQW0dBGXjxcy,SebHIf2jL1TBgrMKJu).replace(QNR6tCevIGEZKX3rAVsP,SebHIf2jL1TBgrMKJu)
	emU0N6XCtvHdD2WKpf = emU0N6XCtvHdD2WKpf.replace(XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
	emU0N6XCtvHdD2WKpf = emU0N6XCtvHdD2WKpf.replace(saNjmrfQDGgltv,qE4nB3mKWHs).replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	LMuQDNp8c9VkAWP4YofZBXj = uqLUBHepfM3l6AyIzTJh80a(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬ዁")+BMyb581fzrTX+bcNqYtfET5l92dLGjyZSPe(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧዂ")+A9x6WFVrq3cG8+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨዃ")+emU0N6XCtvHdD2WKpf+VOALf8iYEnMdK0g(u"ࠩࠣࡡࠬዄ")
z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,q3pa7y0fEM6KFHmDlb+u43PVWjh7t9YwI+yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+LMuQDNp8c9VkAWP4YofZBXj)
if Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡣࠬዅ") in QdZVWe64OSKPfuXnz81m2qoHAJID: KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ = QdZVWe64OSKPfuXnz81m2qoHAJID.split(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡤ࠭዆"),nyUIsfd53EGot9vbj0XDeq)
else: KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ = QdZVWe64OSKPfuXnz81m2qoHAJID,SebHIf2jL1TBgrMKJu
qFsuKN7ngp.JJLAs5tXyUnSDGP,yamjrsOAG4iFfQkuW1JXbZ0Dgq7z = mrhSYXH2P8bO3eJAa9n,SebHIf2jL1TBgrMKJu
if KgLR54vJkSH30D7UOTrFoPq in [C3w6qluao7EzUxJgMGBtV(u"ࠬ࠷ࠧ዇"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࠲ࠨወ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࠴ࠩዉ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࠶ࠪዊ"),HADrRCz9QgU4xudPJIqYb70(u"ࠩ࠸ࠫዋ"),HCiWF4jV1Q8(u"ࠪ࠵࠶࠭ዌ"),sTGtHVyhQ9cJU37zxo2O(u"ࠫ࠶࠸ࠧው"),AGlW9LqKN3Dvo(u"ࠬ࠷࠳ࠨዎ")] and (cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡁࡅࡆࠪዏ") in z4drqDgH1Cy7uwtTl6MVJ or gCkRKGhwcx26v(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧዐ") in z4drqDgH1Cy7uwtTl6MVJ or HADrRCz9QgU4xudPJIqYb70(u"ࠨࡗࡓࠫዑ") in z4drqDgH1Cy7uwtTl6MVJ or DQIrVcKuY6bJv(u"ࠩࡇࡓ࡜ࡔࠧዒ") in z4drqDgH1Cy7uwtTl6MVJ):
	from E9k1y0GguP import CDREpFuBf7ONV8ej4qwKm2J9Ysd
	CDREpFuBf7ONV8ej4qwKm2J9Ysd(QdZVWe64OSKPfuXnz81m2qoHAJID,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ)
	MMAUZiw4CoJ8.setSetting(l7kBpMw5Qn(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧዓ"),EWTFwqJoXHGSjsRfhOI5YLM)
	qFsuKN7ngp.JJLAs5tXyUnSDGP = BBX9RAuxnyGZ4WIF2TrhYeom3
elif not ptIsx9oHqB0dXK and hhUXrunoxlSpv5mif64jWe2E3DA in [bcNqYtfET5l92dLGjyZSPe(u"࠸࠳࠶ዤ"),bcNqYtfET5l92dLGjyZSPe(u"࠷࠲࠷ዥ")]:
	yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q = str(q0HoRKzxwkDFaj3P8r19JBTIACM[DQIrVcKuY6bJv(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዔ")])
	tfX4sO3hy2H1IbKG = vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡏࡐࡕࡘࠪዕ") if hhUXrunoxlSpv5mif64jWe2E3DA==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠳࠵࠸ዦ") else l7kBpMw5Qn(u"࠭ࡍ࠴ࡗࠪዖ")
	BOzeVQA1mus5PCXGivnYqpNox2w = tfX4sO3hy2H1IbKG.lower()
	YIgWR5Sj3cVXaEuqhkHo = MMAUZiw4CoJ8.getSetting(ALwOspNtXxZrz3PEKku(u"ࠧࡢࡸ࠱ࠫ዗")+BOzeVQA1mus5PCXGivnYqpNox2w+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ዘ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)
	ONbf0C7vAzg = MMAUZiw4CoJ8.getSetting(HADrRCz9QgU4xudPJIqYb70(u"ࠩࡤࡺ࠳࠭ዙ")+BOzeVQA1mus5PCXGivnYqpNox2w+l7kBpMw5Qn(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ዚ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)
	if YIgWR5Sj3cVXaEuqhkHo or ONbf0C7vAzg:
		pfhH2objgVkI7eycn += bcNqYtfET5l92dLGjyZSPe(u"ࠫࢁ࠭ዛ")
		if YIgWR5Sj3cVXaEuqhkHo: pfhH2objgVkI7eycn += HADrRCz9QgU4xudPJIqYb70(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫዜ")+YIgWR5Sj3cVXaEuqhkHo
		if ONbf0C7vAzg: pfhH2objgVkI7eycn += fp6KV7DlS8QYniUczHdmZChL(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩዝ")+ONbf0C7vAzg
		pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.replace(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࡽࠨࠪዞ"),sTGtHVyhQ9cJU37zxo2O(u"ࠨࡾࠪዟ"))
	CpoHWMeAENlJ80YnO4 = MMAUZiw4CoJ8.getSetting(HCiWF4jV1Q8(u"ࠩࡤࡺ࠳࠭ዠ")+BOzeVQA1mus5PCXGivnYqpNox2w+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬዡ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)
	if CpoHWMeAENlJ80YnO4:
		zDOqMEQNd8eIZix = X2XorVqHjLkWeCchY4u9fSz.findall(DQIrVcKuY6bJv(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧዢ"),pfhH2objgVkI7eycn,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.replace(zDOqMEQNd8eIZix[wvkDqmNZlJU52isXo],CpoHWMeAENlJ80YnO4)
	nxW9asAySzOt2foFGT4LwmHNl8uZ(pfhH2objgVkI7eycn,tfX4sO3hy2H1IbKG,kpiJl1MHXD5)
else:
	import RSdDifzoPG
	try: RSdDifzoPG.z1nDE0xaqpj9gSfKmwyH(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM,hhUXrunoxlSpv5mif64jWe2E3DA,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ,BMyb581fzrTX)
	except Exception as ddZqPF6aCp2Uwxh: yamjrsOAG4iFfQkuW1JXbZ0Dgq7z = HkQJ95ahZMwW0OtpKU2X.format_exc()
KhcZt43LXbAro(qFsuKN7ngp.JJLAs5tXyUnSDGP,yamjrsOAG4iFfQkuW1JXbZ0Dgq7z)