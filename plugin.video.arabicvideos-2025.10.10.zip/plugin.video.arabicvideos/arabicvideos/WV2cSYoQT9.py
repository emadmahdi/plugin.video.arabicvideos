# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SHAHID4U'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SH4_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
headers = {'User-Agent':b6rmBauMc3HqTev0t(True)}
jgvMWZhtPlBT = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==110: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==111: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==112: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==113: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url,True)
	elif mode==114: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FULL_FILTER___'+text)
	elif mode==115: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'DEFINED_FILTER___'+text)
	elif mode==116: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url,False)
	elif mode==119: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(Bc5IUelt4sWvMXTdy.url,'url')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,119,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',VK4jU2G3s1PwkticQYyLoW,115)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',VK4jU2G3s1PwkticQYyLoW,114)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',VK4jU2G3s1PwkticQYyLoW,111,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('simple-filter(.*?)adv-filter',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for filter,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			url = VK4jU2G3s1PwkticQYyLoW+filter
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,111,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,filter)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="dropdown"(.*?)<script>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			if title in jgvMWZhtPlBT: continue
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
			if 'netflix' in cOn6JqZlmQbjtT: title = 'نيتفلكس'
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,111)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,z9XqWIL1ZS4amgJK=SebHIf2jL1TBgrMKJu,Bc5IUelt4sWvMXTdy=SebHIf2jL1TBgrMKJu):
	if not Bc5IUelt4sWvMXTdy: Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ,items,aLlVEzy8XR62 = [],[],[]
	if z9XqWIL1ZS4amgJK=='featured': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('glide__slides(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('shows-container(.*?)pagination',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		if 'WWE' in title: continue
		if 'javascript' in cOn6JqZlmQbjtT: continue
		cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT).strip('/')
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.strip(qE4nB3mKWHs)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '/film/' in cOn6JqZlmQbjtT or 'فيلم' in cOn6JqZlmQbjtT or any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,112,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + Wj39BaH6oEmstx[0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,113,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/actor/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,111,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/series/' in cOn6JqZlmQbjtT and '/list' not in url:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'/list'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,111,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/list' in url and 'حلقة' in title:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,112,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,113,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ and z9XqWIL1ZS4amgJK!='featured':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		if z9XqWIL1ZS4amgJK!='search': items = X2XorVqHjLkWeCchY4u9fSz.findall('(updateQuery).*?>(.+?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		else: items = X2XorVqHjLkWeCchY4u9fSz.findall('<li>.*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu)
			title = title.strip(qE4nB3mKWHs)
			if z9XqWIL1ZS4amgJK!='search':
				cOn6JqZlmQbjtT = url+'&page='+title if '?' in url else url+'?page='+title
			title = cvlHmV1Kr0FIYSjNnM(title)
			if title: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,111,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,z9XqWIL1ZS4amgJK)
	return
def LRb6nEvgqXwITMc80r1Vt(url,yFxq2W9tVr8j1):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('items d-flex(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if len(k2pC30UArFeg7Ru9tGiZlSmzQ)>1:
		if '/season/' in k2pC30UArFeg7Ru9tGiZlSmzQ[0]: DmS9dwGqQIfP6sv,EiadFrl0bx3uWPqGmIkHNQp = k2pC30UArFeg7Ru9tGiZlSmzQ[0],k2pC30UArFeg7Ru9tGiZlSmzQ[1]
		else: DmS9dwGqQIfP6sv,EiadFrl0bx3uWPqGmIkHNQp = k2pC30UArFeg7Ru9tGiZlSmzQ[1],k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	else: DmS9dwGqQIfP6sv,EiadFrl0bx3uWPqGmIkHNQp = k2pC30UArFeg7Ru9tGiZlSmzQ[0],k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(2):
		if yFxq2W9tVr8j1: mode,type,drRnSgoBtKWjmU5FH4ZCIVhzqNb = 116,'folder',DmS9dwGqQIfP6sv
		else: mode,type,drRnSgoBtKWjmU5FH4ZCIVhzqNb = 112,'video',EiadFrl0bx3uWPqGmIkHNQp
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if yFxq2W9tVr8j1 and len(items)<2:
			yFxq2W9tVr8j1 = False
			continue
		for cOn6JqZlmQbjtT,o7MeOx6PDA1d,sABprza7wEOC0Fd3PTQ in items:
			title = o7MeOx6PDA1d+qE4nB3mKWHs+sABprza7wEOC0Fd3PTQ
			QUzFYoapm9jx(type,FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,mode)
		break
	if not items and '/episodes' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		HuWE2wVTFIO6k4 = X2XorVqHjLkWeCchY4u9fSz.findall('class="breadcrumb"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if HuWE2wVTFIO6k4:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = HuWE2wVTFIO6k4[0]
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if len(uLdRirAZJKoSgPqNUjm84WXE5cn3aT)>2:
				cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[2]+'list'
				yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(cOn6JqZlmQbjtT)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="actions(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	f3IBiJMES2Y7 = '/watch/' in drRnSgoBtKWjmU5FH4ZCIVhzqNb
	download = '/download/' in drRnSgoBtKWjmU5FH4ZCIVhzqNb
	if   f3IBiJMES2Y7 and not download: cc6R5oLjVt,QYrEHI8OWK6awe3C47VSf = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0],SebHIf2jL1TBgrMKJu
	elif not f3IBiJMES2Y7 and download: cc6R5oLjVt,QYrEHI8OWK6awe3C47VSf = SebHIf2jL1TBgrMKJu,uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0]
	elif f3IBiJMES2Y7 and download: cc6R5oLjVt,QYrEHI8OWK6awe3C47VSf = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0],uLdRirAZJKoSgPqNUjm84WXE5cn3aT[1]
	else: cc6R5oLjVt,QYrEHI8OWK6awe3C47VSf = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	if f3IBiJMES2Y7:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',cc6R5oLjVt,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-PLAY-2nd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
		BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('let servers(.*?)player',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		if BRdnHfWTrhFe:
			Q4idDwN25EKRJCajSyc = BRdnHfWTrhFe[0]
			IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('"name":"(.*?)".*?"url":"(.*?)"',Q4idDwN25EKRJCajSyc,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for title,cOn6JqZlmQbjtT in IkJNp71Hyu0PwFAXMTsOc:
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('\\/','/')
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
				bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	if download:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',QYrEHI8OWK6awe3C47VSf,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-PLAY-3rd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
		BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"servers"(.*?)info-container',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if BRdnHfWTrhFe:
			Q4idDwN25EKRJCajSyc = BRdnHfWTrhFe[0]
			IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',Q4idDwN25EKRJCajSyc,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title,lcbjBn3FdZxC1059A4Kqvi2pugJOa in IkJNp71Hyu0PwFAXMTsOc:
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'+'____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
				bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/search?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return
def OU0dGs5xyz9KH3o7(url):
	url = url.split('/smartemadfilter?')[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	BJheYUDK3EOyfPR24 = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('adv-filter(.*?)shows-container',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		dx2YaptQXPWhD,EOVC5HvpA3dNJcx,cuoYjfNMPnmhQgtFE = zip(*BJheYUDK3EOyfPR24)
		BJheYUDK3EOyfPR24 = zip(EOVC5HvpA3dNJcx,dx2YaptQXPWhD,cuoYjfNMPnmhQgtFE)
	return BJheYUDK3EOyfPR24
def TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb):
	items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>\s*(.*?)\s*<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return items
def WiI8urkKJYDwTfygBe2psH(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	iiXk0elDVoLTZ8HUAaB = url.split('/smartemadfilter?')[0]
	BDku1TovVtpfmhL9Ryde4nNQ = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	url = url.replace(iiXk0elDVoLTZ8HUAaB,BDku1TovVtpfmhL9Ryde4nNQ)
	url = url.replace('/smartemadfilter?','/?')
	return url
GJUdZFt2Q1HukDo7zjwx4cqpl = ['quality','year','genre','category']
ONFLiPpH2XZDKwqY3 = ['category','genre','year']
def vimwpBGoVK3EZrUkjPL(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='DEFINED_FILTER':
		if ONFLiPpH2XZDKwqY3[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = ONFLiPpH2XZDKwqY3[0]
		for YHnALfql8hprDu in range(len(ONFLiPpH2XZDKwqY3[0:-1])):
			if ONFLiPpH2XZDKwqY3[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = ONFLiPpH2XZDKwqY3[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
	elif type=='FULL_FILTER':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'/smartemadfilter?'+wk0AjSOpcRB
		iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',iGxH2fsuScPtkJb7ECg,111)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',iGxH2fsuScPtkJb7ECg,111)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	BJheYUDK3EOyfPR24 = OU0dGs5xyz9KH3o7(url)
	dict = {}
	for name,oIi8QaPyZBr1mvUcsh,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		name = name.replace('كل ',SebHIf2jL1TBgrMKJu)
		items = TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='DEFINED_FILTER':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<2:
				if oIi8QaPyZBr1mvUcsh==ONFLiPpH2XZDKwqY3[-1]:
					iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
					yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(iGxH2fsuScPtkJb7ECg)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'DEFINED_FILTER___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				if oIi8QaPyZBr1mvUcsh==ONFLiPpH2XZDKwqY3[-1]:
					iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',iGxH2fsuScPtkJb7ECg,111)
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,115,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FULL_FILTER':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع :'+name,qg7Nr1dCaD,114,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if value=='196533': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'أفلام نيتفلكس'
			elif value=='196531': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'مسلسلات نيتفلكس'
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'+name
			if type=='FULL_FILTER': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,114,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='DEFINED_FILTER' and ONFLiPpH2XZDKwqY3[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
				iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,111)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,115,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.replace('=&','=0&')
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	for key in GJUdZFt2Q1HukDo7zjwx4cqpl:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('=0','=')
	return hIyBYfuc8oTsEZ