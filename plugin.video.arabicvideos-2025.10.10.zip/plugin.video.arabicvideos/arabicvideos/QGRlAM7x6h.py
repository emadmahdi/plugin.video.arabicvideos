# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'YOUTUBE'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_YUT_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
oxK68yHWVFUm = 0
def WdRmv9kTtLnfZ24(mode,url,text,type,Q8A5HyT1fGNxZv4X3V7eC,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7):
	if	 mode==140: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==141: lfZmugQCFKLGT05AH29IsMiho = XPOTIAiFwf6HMprdmKJjsnvR(url,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7)
	elif mode==143: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url,type)
	elif mode==144: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC,text)
	elif mode==145: lfZmugQCFKLGT05AH29IsMiho = ZNqsH8j70p4L9ciF(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==147: lfZmugQCFKLGT05AH29IsMiho = UtWNw5Du0CHlFPVoibjTLSqQMZYnId()
	elif mode==148: lfZmugQCFKLGT05AH29IsMiho = iQcSd5p9sTu16nrDvRfaBUtkzM()
	elif mode==149: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	if 0:
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قائمة 1',j1IFsik4ouNePZr+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قائمة 2',j1IFsik4ouNePZr+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'شخص',j1IFsik4ouNePZr+'/user/TCNofficial',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'موقع',j1IFsik4ouNePZr+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'حساب',j1IFsik4ouNePZr+'/@TheSocialCTV',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'العاب',j1IFsik4ouNePZr+'/gaming',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'افلام',j1IFsik4ouNePZr+'/feed/storefront',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مختارات',j1IFsik4ouNePZr+'/feed/guide_builder',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قصيرة',j1IFsik4ouNePZr+'/shorts',144,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'تصفح',j1IFsik4ouNePZr+'/youtubei/v1/guide?key=',144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'رئيسية',j1IFsik4ouNePZr+SebHIf2jL1TBgrMKJu,144)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'رائج',j1IFsik4ouNePZr+'/feed/trending?bp=',144)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,149,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الرائجة',j1IFsik4ouNePZr+'/feed/trending',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'التصفح',j1IFsik4ouNePZr+'/youtubei/v1/guide?key=',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'القصيرة',j1IFsik4ouNePZr+'/shorts',144,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مختارات يوتيوب',j1IFsik4ouNePZr+'/feed/guide_builder',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مختارات البرنامج',SebHIf2jL1TBgrMKJu,290)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: قنوات عربية',SebHIf2jL1TBgrMKJu,147)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: قنوات أجنبية',SebHIf2jL1TBgrMKJu,148)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: افلام عربية',j1IFsik4ouNePZr+'/results?search_query=فيلم',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: افلام اجنبية',j1IFsik4ouNePZr+'/results?search_query=movie',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: مسرحيات عربية',j1IFsik4ouNePZr+'/results?search_query=مسرحية',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: مسلسلات عربية',j1IFsik4ouNePZr+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: مسلسلات اجنبية',j1IFsik4ouNePZr+'/results?search_query=series&sp=EgIQAw==',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: مسلسلات كارتون',j1IFsik4ouNePZr+'/results?search_query=كارتون&sp=EgIQAw==',144)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث: خطبة المرجعية',j1IFsik4ouNePZr+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def XPOTIAiFwf6HMprdmKJjsnvR(url,name,i3iEyeZ8BQmpDNornRVxTzwdYcX7):
	name = wpbqld5hCR72i6cWNeQI(name)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'CHNL:  '+name,url,144,i3iEyeZ8BQmpDNornRVxTzwdYcX7)
	return
def UtWNw5Du0CHlFPVoibjTLSqQMZYnId():
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(j1IFsik4ouNePZr+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def iQcSd5p9sTu16nrDvRfaBUtkzM():
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(j1IFsik4ouNePZr+'/results?search_query=tv&sp=EgJAAQ==')
	return
def rRCw3hfy2Kq5l(url,type):
	url = url.split('&',1)[0]
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ([url],tfX4sO3hy2H1IbKG,type,url)
	return
def IIPtxo1ebhOi(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp):
	level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp.split('::')
	C0QLqaM3fpzbd84Wx5NItDkoVlPum,N4yihsl9bIQjZHda = [],[]
	if '/youtubei/v1/browse' in url: C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['onResponseReceivedCommands']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['entries']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['items'][3]['guideSectionRenderer']['items']")
	JsxG6vUX59lFEND,IIRHmGU9Ar,pJeGnoU63xya1OW0QBzif4XATrwM5R = HMmbUagYjCXiu1qF48zPZQIdhNl9S(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	if level=='1' and JsxG6vUX59lFEND:
		if len(IIRHmGU9Ar)>1 and 'search_query' not in url:
			for qqpUrHmkIeDZhYtE5LvuOaTGfw06bx in range(len(IIRHmGU9Ar)):
				slJGkLFTdA0eRWrHzIgn3p41Qa = str(qqpUrHmkIeDZhYtE5LvuOaTGfw06bx)
				C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['reloadContinuationItemsCommand']['continuationItems']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['command']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]")
				Vsn3f1CA8FIu0krNclSDWP5v9YQaE,JJSOAkTZIib4eswDo51pFuqvK,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(IIRHmGU9Ar,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
				if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: N4yihsl9bIQjZHda.append([JJSOAkTZIib4eswDo51pFuqvK,url,'2::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::0::0'])
			C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yccc['continuationEndpoint']")
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE,JJSOAkTZIib4eswDo51pFuqvK,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
			if Vsn3f1CA8FIu0krNclSDWP5v9YQaE and N4yihsl9bIQjZHda and 'continuationCommand' in list(JJSOAkTZIib4eswDo51pFuqvK.keys()):
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/my_main_page_shorts_link'
				N4yihsl9bIQjZHda.append([JJSOAkTZIib4eswDo51pFuqvK,cOn6JqZlmQbjtT,'1::0::0::0'])
	return IIRHmGU9Ar,JsxG6vUX59lFEND,N4yihsl9bIQjZHda,pJeGnoU63xya1OW0QBzif4XATrwM5R
def jIT3X5aeu2i8(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,IIRHmGU9Ar,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp):
	level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp.split('::')
	C0QLqaM3fpzbd84Wx5NItDkoVlPum,B4dkOHe8Q1KWY52l = [],[]
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[0]['itemSectionRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['reloadContinuationItemsCommand']['continuationItems']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd["+slJGkLFTdA0eRWrHzIgn3p41Qa+"]")
	TJ5MKfdsYeDFgN9zaEhXViAor,wY8s1drX4Vnj5UvKyLD,rc7VFxUfaXL0jBlt5AzNd = HMmbUagYjCXiu1qF48zPZQIdhNl9S(IIRHmGU9Ar,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	if level=='2' and TJ5MKfdsYeDFgN9zaEhXViAor:
		if len(wY8s1drX4Vnj5UvKyLD)>1:
			for qqpUrHmkIeDZhYtE5LvuOaTGfw06bx in range(len(wY8s1drX4Vnj5UvKyLD)):
				bE4Tmp2dZBonHt1rVvluXMLwPjCci = str(qqpUrHmkIeDZhYtE5LvuOaTGfw06bx)
				C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['richSectionRenderer']['content']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['richItemRenderer']['content']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]")
				Vsn3f1CA8FIu0krNclSDWP5v9YQaE,JJSOAkTZIib4eswDo51pFuqvK,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(wY8s1drX4Vnj5UvKyLD,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
				if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: B4dkOHe8Q1KWY52l.append([JJSOAkTZIib4eswDo51pFuqvK,url,'3::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::0'])
			C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yddd[1]")
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE,JJSOAkTZIib4eswDo51pFuqvK,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(IIRHmGU9Ar,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
			if Vsn3f1CA8FIu0krNclSDWP5v9YQaE and B4dkOHe8Q1KWY52l and 'continuationItemRenderer' in list(JJSOAkTZIib4eswDo51pFuqvK.keys()):
				B4dkOHe8Q1KWY52l.append([JJSOAkTZIib4eswDo51pFuqvK,url,'3::0::0::0'])
	return wY8s1drX4Vnj5UvKyLD,TJ5MKfdsYeDFgN9zaEhXViAor,B4dkOHe8Q1KWY52l,rc7VFxUfaXL0jBlt5AzNd
def tQuMK7earGYpR(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,wY8s1drX4Vnj5UvKyLD,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp):
	level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp.split('::')
	C0QLqaM3fpzbd84Wx5NItDkoVlPum,EZHk5gbjLv = [],[]
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['reelShelfRenderer']['items']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee["+bE4Tmp2dZBonHt1rVvluXMLwPjCci+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yeee")
	X1XmlNpe98zFdaEO,J4UAkrPo0p1NHzE26ZvIVxTfqFs,MDQEPGFJckxyBI = HMmbUagYjCXiu1qF48zPZQIdhNl9S(wY8s1drX4Vnj5UvKyLD,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	if level=='3' and X1XmlNpe98zFdaEO:
		if len(J4UAkrPo0p1NHzE26ZvIVxTfqFs)>0:
			for qqpUrHmkIeDZhYtE5LvuOaTGfw06bx in range(len(J4UAkrPo0p1NHzE26ZvIVxTfqFs)):
				ccKIevwkQxiyHjEC36Xlu1Uzp = str(qqpUrHmkIeDZhYtE5LvuOaTGfw06bx)
				C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yfff["+ccKIevwkQxiyHjEC36Xlu1Uzp+"]['richItemRenderer']['content']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yfff["+ccKIevwkQxiyHjEC36Xlu1Uzp+"]['gameCardRenderer']['game']")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yfff["+ccKIevwkQxiyHjEC36Xlu1Uzp+"]['itemSectionRenderer']['contents'][0]")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yfff["+ccKIevwkQxiyHjEC36Xlu1Uzp+"]")
				C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yfff")
				Vsn3f1CA8FIu0krNclSDWP5v9YQaE,JJSOAkTZIib4eswDo51pFuqvK,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(J4UAkrPo0p1NHzE26ZvIVxTfqFs,SebHIf2jL1TBgrMKJu,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
				if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: EZHk5gbjLv.append([JJSOAkTZIib4eswDo51pFuqvK,url,'4::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp])
	return J4UAkrPo0p1NHzE26ZvIVxTfqFs,X1XmlNpe98zFdaEO,EZHk5gbjLv,MDQEPGFJckxyBI
def HMmbUagYjCXiu1qF48zPZQIdhNl9S(VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45,ZAmg6fMwxVIWKGSeJzsnE):
	sOjDmdR1VXo9tNiAP8xYaknJrGBb42,AAojFVQnsyKMd7PhbxI45 = VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45
	IIRHmGU9Ar,AAojFVQnsyKMd7PhbxI45 = VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45
	wY8s1drX4Vnj5UvKyLD,AAojFVQnsyKMd7PhbxI45 = VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45
	J4UAkrPo0p1NHzE26ZvIVxTfqFs,AAojFVQnsyKMd7PhbxI45 = VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45
	JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0 = VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45
	count = len(ZAmg6fMwxVIWKGSeJzsnE)
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(count):
		try:
			l8AB4uTRC5baWN13LiKOSHqx7FJ9Y = eval(ZAmg6fMwxVIWKGSeJzsnE[XM3KUmO1QJxlv84bgFTHsjdNt0kYq])
			return True,l8AB4uTRC5baWN13LiKOSHqx7FJ9Y,XM3KUmO1QJxlv84bgFTHsjdNt0kYq+1
		except: pass
	return False,SebHIf2jL1TBgrMKJu,0
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp=SebHIf2jL1TBgrMKJu,data=SebHIf2jL1TBgrMKJu):
	N4yihsl9bIQjZHda,B4dkOHe8Q1KWY52l,EZHk5gbjLv = [],[],[]
	if '::' not in ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp: ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '1::0::0::0'
	level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp.split('::')
	if level=='4': level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = '1',slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp
	data = data.replace('_REMEMBERRESULTS_',SebHIf2jL1TBgrMKJu)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9,sOjDmdR1VXo9tNiAP8xYaknJrGBb42,bIGXajdcK6PQBs = QPsG5tjT89ozbDKm0vUk421nLAIOyx(url,data)
	ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = level+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
	if level in ['1','2','3']:
		IIRHmGU9Ar,JsxG6vUX59lFEND,N4yihsl9bIQjZHda,pJeGnoU63xya1OW0QBzif4XATrwM5R = IIPtxo1ebhOi(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
		if not JsxG6vUX59lFEND: return
		O3nMiVr9NJwIW5s6KG2YyEafQBZm = len(N4yihsl9bIQjZHda)
		if O3nMiVr9NJwIW5s6KG2YyEafQBZm<2:
			if level=='1': level = '2'
			N4yihsl9bIQjZHda = []
	ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = level+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
	if level in ['2','3']:
		wY8s1drX4Vnj5UvKyLD,TJ5MKfdsYeDFgN9zaEhXViAor,B4dkOHe8Q1KWY52l,rc7VFxUfaXL0jBlt5AzNd = jIT3X5aeu2i8(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,IIRHmGU9Ar,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
		if not TJ5MKfdsYeDFgN9zaEhXViAor: return
		BBQdaLrK5GAhMvW = len(B4dkOHe8Q1KWY52l)
		if BBQdaLrK5GAhMvW<2:
			if level=='2': level = '3'
			B4dkOHe8Q1KWY52l = []
	ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = level+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
	if level in ['3']:
		J4UAkrPo0p1NHzE26ZvIVxTfqFs,X1XmlNpe98zFdaEO,EZHk5gbjLv,MDQEPGFJckxyBI = tQuMK7earGYpR(sOjDmdR1VXo9tNiAP8xYaknJrGBb42,wY8s1drX4Vnj5UvKyLD,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
		if not X1XmlNpe98zFdaEO: return
		arqmR2lM4xICY8OKuZtWkn = len(EZHk5gbjLv)
	for JJSOAkTZIib4eswDo51pFuqvK,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp in N4yihsl9bIQjZHda+B4dkOHe8Q1KWY52l+EZHk5gbjLv:
		L6gBVcUknMYil4RjQImrHyDwEoWd = EEvQOetAwfpYZg3G07DhXa6SH(JJSOAkTZIib4eswDo51pFuqvK,url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	return
def EEvQOetAwfpYZg3G07DhXa6SH(JJSOAkTZIib4eswDo51pFuqvK,url=SebHIf2jL1TBgrMKJu,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp=SebHIf2jL1TBgrMKJu):
	if '::' in ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp: level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp.split('::')
	else: level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = '1','0','0','0'
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count,lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI,H7H8J04OekwM2flRIYhSQP,OTzFQ0Yjwan1x7M2iIcVUu = RpshrAO53dG4lPTx7nMJa2u9cISVmg(JJSOAkTZIib4eswDo51pFuqvK)
	QQVYoSRMmZLsrtqiKFjybP2aDOu963 = '/videos?' in cOn6JqZlmQbjtT or '/streams?' in cOn6JqZlmQbjtT or '/playlists?' in cOn6JqZlmQbjtT
	zsqSWN2A7e10fJG = '/channels?' in cOn6JqZlmQbjtT or '/shorts?' in cOn6JqZlmQbjtT
	if QQVYoSRMmZLsrtqiKFjybP2aDOu963 or zsqSWN2A7e10fJG: cOn6JqZlmQbjtT = url
	QQVYoSRMmZLsrtqiKFjybP2aDOu963 = 'watch?v=' not in cOn6JqZlmQbjtT and '/playlist?list=' not in cOn6JqZlmQbjtT
	zsqSWN2A7e10fJG = '/gaming' not in cOn6JqZlmQbjtT  and '/feed/storefront' not in cOn6JqZlmQbjtT
	if ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp[0:5]=='3::0::' and QQVYoSRMmZLsrtqiKFjybP2aDOu963 and zsqSWN2A7e10fJG: cOn6JqZlmQbjtT = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in cOn6JqZlmQbjtT:
		level,slJGkLFTdA0eRWrHzIgn3p41Qa,bE4Tmp2dZBonHt1rVvluXMLwPjCci,ccKIevwkQxiyHjEC36Xlu1Uzp = '1','0','0','0'
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = SebHIf2jL1TBgrMKJu
	bIGXajdcK6PQBs = SebHIf2jL1TBgrMKJu
	if '/youtubei/v1/browse' in cOn6JqZlmQbjtT or '/youtubei/v1/search' in cOn6JqZlmQbjtT or '/my_main_page_shorts_link' in url:
		data = MMAUZiw4CoJ8.getSetting('av.youtube.data')
		if data.count(':::')==4:
			AAmD2u4qpZxbz86gFW7iICthjrBG,key,eaY8WbvQ1MJc6VSi4,f3ErTW2DPaK4HS6kRQ8,pHtWj513aey2KLi097S84rxqzUJNPs = data.split(':::')
			bIGXajdcK6PQBs = AAmD2u4qpZxbz86gFW7iICthjrBG+':::'+key+':::'+eaY8WbvQ1MJc6VSi4+':::'+f3ErTW2DPaK4HS6kRQ8+':::'+OTzFQ0Yjwan1x7M2iIcVUu
			if '/my_main_page_shorts_link' in url and not cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = url
			else: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?key='+key
	if not title:
		global oxK68yHWVFUm
		oxK68yHWVFUm += 1
		title = 'فيديوهات '+str(oxK68yHWVFUm)
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '3'+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
	if not Vsn3f1CA8FIu0krNclSDWP5v9YQaE: return False
	elif 'searchPyvRenderer' in str(JJSOAkTZIib4eswDo51pFuqvK): return False
	elif '/about' in cOn6JqZlmQbjtT: return False
	elif '/community' in cOn6JqZlmQbjtT: return False
	elif 'continuationItemRenderer' in list(JJSOAkTZIib4eswDo51pFuqvK.keys()) or 'continuationCommand' in list(JJSOAkTZIib4eswDo51pFuqvK.keys()):
		if int(level)>1: level = str(int(level)-1)
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = level+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+':: '+'صفحة أخرى',cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,bIGXajdcK6PQBs)
	elif '/search' in cOn6JqZlmQbjtT:
		title = ':: '+title
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '3'+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
		url = url.replace('/search',SebHIf2jL1TBgrMKJu)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,145,SebHIf2jL1TBgrMKJu,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not cOn6JqZlmQbjtT:
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '3'+'::'+slJGkLFTdA0eRWrHzIgn3p41Qa+'::'+bE4Tmp2dZBonHt1rVvluXMLwPjCci+'::'+ccKIevwkQxiyHjEC36Xlu1Uzp
		title = ':: '+title
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,bIGXajdcK6PQBs)
	elif '/browse' in cOn6JqZlmQbjtT and url==j1IFsik4ouNePZr:
		title = ':: '+title
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '2::0::0::0'
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,bIGXajdcK6PQBs)
	elif not cOn6JqZlmQbjtT and 'horizontalMovieListRenderer' in str(JJSOAkTZIib4eswDo51pFuqvK):
		title = ':: '+title
		ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '3::0::0::0'
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	elif 'messageRenderer' in str(JJSOAkTZIib4eswDo51pFuqvK):
		QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,SebHIf2jL1TBgrMKJu,9999)
	elif A02AqFZ7KrvtJpNUdXgHElTs1mWMI:
		QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+A02AqFZ7KrvtJpNUdXgHElTs1mWMI+title,cOn6JqZlmQbjtT,143,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	elif '/playlist?list=' in cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('&playnext=1',SebHIf2jL1TBgrMKJu)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'LIST'+count+':  '+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	elif '/shorts/' in cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('&list=',1)[0]
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,143,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
	elif '/watch?v=' in cOn6JqZlmQbjtT:
		if '&list=' in cOn6JqZlmQbjtT and count:
			TMRP9oatmlBnuHcGUeZ = cOn6JqZlmQbjtT.split('&list=',1)[1]
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/playlist?list='+TMRP9oatmlBnuHcGUeZ
			ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = '1::0::0::0'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'LIST'+count+':  '+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
		else:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('&list=',1)[0]
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,143,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
	elif '/channel/' in cOn6JqZlmQbjtT or '/c/' in cOn6JqZlmQbjtT or ('/@' in cOn6JqZlmQbjtT and cOn6JqZlmQbjtT.count('/')==3):
		if psS8dmb912iRBgGc7qOPyCZ6:
			title = title.decode(Tv08xsf9HOqunIVUPdK1).encode('raw_unicode_escape')
			title = a549mfV8gnzXpwlFr(title)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'CHNL'+count+':  '+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	elif '/user/' in cOn6JqZlmQbjtT:
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'USER'+count+':  '+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	else:
		if not cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = url
		title = ':: '+title
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,144,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,bIGXajdcK6PQBs)
	return True
def RpshrAO53dG4lPTx7nMJa2u9cISVmg(JJSOAkTZIib4eswDo51pFuqvK):
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count,lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI,H7H8J04OekwM2flRIYhSQP,pHtWj513aey2KLi097S84rxqzUJNPs = False,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	if not isinstance(JJSOAkTZIib4eswDo51pFuqvK,dict): return Vsn3f1CA8FIu0krNclSDWP5v9YQaE,title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count,lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI,H7H8J04OekwM2flRIYhSQP,pHtWj513aey2KLi097S84rxqzUJNPs
	for leyTmnxYvM5N8PSQida1 in list(JJSOAkTZIib4eswDo51pFuqvK.keys()):
		SgNa2xUM3OYBjp0 = JJSOAkTZIib4eswDo51pFuqvK[leyTmnxYvM5N8PSQida1]
		if isinstance(SgNa2xUM3OYBjp0,dict): break
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['header']['richListHeaderRenderer']['title']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['headline']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['unplayableText']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['formattedTitle']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['title']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['title']['runs'][0]['text']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['text']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['text']['runs'][0]['text']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['title']['content']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['title']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("item['title']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("item['reelWatchEndpoint']['videoId']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,title,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("item['commandMetadata']['webCommandMetadata']['url']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,cOn6JqZlmQbjtT,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnail']['thumbnails'][0]['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['videoCountShortText']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['videoCountText']['runs'][0]['text']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['videoCount']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,count,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['lengthText']['simpleText']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,lEeAaSobjWc,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	C0QLqaM3fpzbd84Wx5NItDkoVlPum = []
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	C0QLqaM3fpzbd84Wx5NItDkoVlPum.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,pHtWj513aey2KLi097S84rxqzUJNPs,N6zTbPqn0IFo9 = HMmbUagYjCXiu1qF48zPZQIdhNl9S(JJSOAkTZIib4eswDo51pFuqvK,SgNa2xUM3OYBjp0,C0QLqaM3fpzbd84Wx5NItDkoVlPum)
	if 'LIVE' in lEeAaSobjWc: lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI = SebHIf2jL1TBgrMKJu,'LIVE:  '
	if 'مباشر' in lEeAaSobjWc: lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI = SebHIf2jL1TBgrMKJu,'LIVE:  '
	if 'badges' in list(SgNa2xUM3OYBjp0.keys()):
		N7OYhrV9SeEAg = str(SgNa2xUM3OYBjp0['badges'])
		if 'Free with Ads' in N7OYhrV9SeEAg: H7H8J04OekwM2flRIYhSQP = '$:  '
		if 'LIVE' in N7OYhrV9SeEAg: A02AqFZ7KrvtJpNUdXgHElTs1mWMI = 'LIVE:  '
		if 'Buy' in N7OYhrV9SeEAg or 'Rent' in N7OYhrV9SeEAg: H7H8J04OekwM2flRIYhSQP = '$$:  '
		if dHGcuCNYJWI53yrvAOT80(u'مباشر') in N7OYhrV9SeEAg: A02AqFZ7KrvtJpNUdXgHElTs1mWMI = 'LIVE:  '
		if dHGcuCNYJWI53yrvAOT80(u'شراء') in N7OYhrV9SeEAg: H7H8J04OekwM2flRIYhSQP = '$$:  '
		if dHGcuCNYJWI53yrvAOT80(u'استئجار') in N7OYhrV9SeEAg: H7H8J04OekwM2flRIYhSQP = '$$:  '
		if dHGcuCNYJWI53yrvAOT80(u'إعلانات') in N7OYhrV9SeEAg: H7H8J04OekwM2flRIYhSQP = '$:  '
	cOn6JqZlmQbjtT = a549mfV8gnzXpwlFr(cOn6JqZlmQbjtT)
	if cOn6JqZlmQbjtT and 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.split('?')[0]
	if  tncvzBN0kyrqEHlhIPGSoX4ugA3CDs and 'http' not in tncvzBN0kyrqEHlhIPGSoX4ugA3CDs: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = 'https:'+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
	title = a549mfV8gnzXpwlFr(title)
	if H7H8J04OekwM2flRIYhSQP: title = H7H8J04OekwM2flRIYhSQP+title
	lEeAaSobjWc = lEeAaSobjWc.replace(',',SebHIf2jL1TBgrMKJu)
	count = count.replace(',',SebHIf2jL1TBgrMKJu)
	count = X2XorVqHjLkWeCchY4u9fSz.findall('\d+',count)
	if count: count = count[0]
	else: count = SebHIf2jL1TBgrMKJu
	return True,title,cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,count,lEeAaSobjWc,A02AqFZ7KrvtJpNUdXgHElTs1mWMI,H7H8J04OekwM2flRIYhSQP,pHtWj513aey2KLi097S84rxqzUJNPs
def QPsG5tjT89ozbDKm0vUk421nLAIOyx(url,data=SebHIf2jL1TBgrMKJu,pbmcw9i1kfuNIQzJ7aGd3l0=SebHIf2jL1TBgrMKJu):
	if pbmcw9i1kfuNIQzJ7aGd3l0==SebHIf2jL1TBgrMKJu: pbmcw9i1kfuNIQzJ7aGd3l0 = 'ytInitialData'
	YIgWR5Sj3cVXaEuqhkHo = b6rmBauMc3HqTev0t()
	REIkboX9NtlZCSU3A = {'User-Agent':YIgWR5Sj3cVXaEuqhkHo,'Cookie':'PREF=hl=ar'}
	global MMAUZiw4CoJ8
	if not data: data = MMAUZiw4CoJ8.getSetting('av.youtube.data')
	if data.count(':::')==4: AAmD2u4qpZxbz86gFW7iICthjrBG,key,eaY8WbvQ1MJc6VSi4,f3ErTW2DPaK4HS6kRQ8,pHtWj513aey2KLi097S84rxqzUJNPs = data.split(':::')
	else: AAmD2u4qpZxbz86gFW7iICthjrBG,key,eaY8WbvQ1MJc6VSi4,f3ErTW2DPaK4HS6kRQ8,pHtWj513aey2KLi097S84rxqzUJNPs = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	bIGXajdcK6PQBs = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":eaY8WbvQ1MJc6VSi4}}}
	if url==j1IFsik4ouNePZr+'/shorts' or '/my_main_page_shorts_link' in url:
		url = j1IFsik4ouNePZr+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		bIGXajdcK6PQBs['sequenceParams'] = AAmD2u4qpZxbz86gFW7iICthjrBG
		bIGXajdcK6PQBs = str(bIGXajdcK6PQBs)
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',url,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = j1IFsik4ouNePZr+'/youtubei/v1/guide?key='+key
		bIGXajdcK6PQBs = str(bIGXajdcK6PQBs)
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',url,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and AAmD2u4qpZxbz86gFW7iICthjrBG:
		bIGXajdcK6PQBs['continuation'] = pHtWj513aey2KLi097S84rxqzUJNPs
		bIGXajdcK6PQBs['context']['client']['visitorData'] = AAmD2u4qpZxbz86gFW7iICthjrBG
		bIGXajdcK6PQBs = str(bIGXajdcK6PQBs)
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',url,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and f3ErTW2DPaK4HS6kRQ8:
		REIkboX9NtlZCSU3A.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':eaY8WbvQ1MJc6VSi4})
		REIkboX9NtlZCSU3A.update({'Cookie':'VISITOR_INFO1_LIVE='+f3ErTW2DPaK4HS6kRQ8})
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'YOUTUBE-GET_PAGE_DATA-6th')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('"innertubeApiKey".*?"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.I)
	if yyfSKmso8APbUwvq3HLXgz0D: key = yyfSKmso8APbUwvq3HLXgz0D[0]
	yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('"cver".*?"value".*?"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.I)
	if yyfSKmso8APbUwvq3HLXgz0D: eaY8WbvQ1MJc6VSi4 = yyfSKmso8APbUwvq3HLXgz0D[0]
	yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall('"visitorData".*?"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.I)
	if yyfSKmso8APbUwvq3HLXgz0D: AAmD2u4qpZxbz86gFW7iICthjrBG = yyfSKmso8APbUwvq3HLXgz0D[0]
	cookies = Bc5IUelt4sWvMXTdy.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): f3ErTW2DPaK4HS6kRQ8 = cookies['VISITOR_INFO1_LIVE']
	dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = AAmD2u4qpZxbz86gFW7iICthjrBG+':::'+key+':::'+eaY8WbvQ1MJc6VSi4+':::'+f3ErTW2DPaK4HS6kRQ8+':::'+pHtWj513aey2KLi097S84rxqzUJNPs
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ytInitialData' and 'ytInitialData' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		GGpaVyUA5QRXJdsgw0xTbB = X2XorVqHjLkWeCchY4u9fSz.findall('window\["ytInitialData"\] = ({.*?});',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not GGpaVyUA5QRXJdsgw0xTbB: GGpaVyUA5QRXJdsgw0xTbB = X2XorVqHjLkWeCchY4u9fSz.findall('var ytInitialData = ({.*?});',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		OJ6iuWZlsBycXNVS3EK1AoQ = xjVJ0o7mF86tCDagkbNcrTAR4UH('str',GGpaVyUA5QRXJdsgw0xTbB[0])
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='ytInitialGuideData' and 'ytInitialGuideData' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		GGpaVyUA5QRXJdsgw0xTbB = X2XorVqHjLkWeCchY4u9fSz.findall('var ytInitialGuideData = ({.*?});',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		OJ6iuWZlsBycXNVS3EK1AoQ = xjVJ0o7mF86tCDagkbNcrTAR4UH('str',GGpaVyUA5QRXJdsgw0xTbB[0])
	elif '</script>' not in LCK8lO2yRWaTVEQcdjPXAzpFBe9: OJ6iuWZlsBycXNVS3EK1AoQ = xjVJ0o7mF86tCDagkbNcrTAR4UH('str',LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	else: OJ6iuWZlsBycXNVS3EK1AoQ = SebHIf2jL1TBgrMKJu
	if 0:
		sOjDmdR1VXo9tNiAP8xYaknJrGBb42 = str(OJ6iuWZlsBycXNVS3EK1AoQ)
		if QBOMjKifEAFD: sOjDmdR1VXo9tNiAP8xYaknJrGBb42 = sOjDmdR1VXo9tNiAP8xYaknJrGBb42.encode(Tv08xsf9HOqunIVUPdK1)
		open('S:\\0000emad.dat','wb').write(sOjDmdR1VXo9tNiAP8xYaknJrGBb42)
	MMAUZiw4CoJ8.setSetting('av.youtube.data',dP6f4SeYIyJuGjvHmUQRiq9WzabCgc)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9,OJ6iuWZlsBycXNVS3EK1AoQ,dP6f4SeYIyJuGjvHmUQRiq9WzabCgc
def ZNqsH8j70p4L9ciF(url,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp):
	search = zWKdm3kV2ItwYrgH1BZyRON()
	if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	qg7Nr1dCaD = url+'/search?query='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD,ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	qg7Nr1dCaD = j1IFsik4ouNePZr+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in ndiZQ7oLFkV1W: wgLuoU4rCQqMSHyJb0Tkl = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in ndiZQ7oLFkV1W: wgLuoU4rCQqMSHyJb0Tkl = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in ndiZQ7oLFkV1W: wgLuoU4rCQqMSHyJb0Tkl = '&sp=EgIQAg%253D%253D'
		else: wgLuoU4rCQqMSHyJb0Tkl = SebHIf2jL1TBgrMKJu
		iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD+wgLuoU4rCQqMSHyJb0Tkl
	else:
		iobPLUAOTn3d5tRrSEZDueFGwqW7s,W0me84kvMOraFAzu,sABprza7wEOC0Fd3PTQ = [],[],SebHIf2jL1TBgrMKJu
		hb5skc7T8m3 = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		I1UYF6ckdvhVZbMyXnjEB27DTfeSa = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		w5EINK1mOfxTQdMRZC7q69 = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر البحث المناسب',hb5skc7T8m3)
		if w5EINK1mOfxTQdMRZC7q69 == -1: return
		qqEFdL1B6xamA = I1UYF6ckdvhVZbMyXnjEB27DTfeSa[w5EINK1mOfxTQdMRZC7q69]
		LCK8lO2yRWaTVEQcdjPXAzpFBe9,zt4C1riXE0RfZhKTgyP,data = QPsG5tjT89ozbDKm0vUk421nLAIOyx(qg7Nr1dCaD+qqEFdL1B6xamA)
		if zt4C1riXE0RfZhKTgyP:
			try:
				QswcKkr0nfHiAqdt = zt4C1riXE0RfZhKTgyP['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for CFWf8uZyjQg2bn6SmqNP5iL7YwMTcB in range(len(QswcKkr0nfHiAqdt)):
					group = QswcKkr0nfHiAqdt[CFWf8uZyjQg2bn6SmqNP5iL7YwMTcB]['searchFilterGroupRenderer']['filters']
					for P0cO9IQJ5AmnXxpqCuj in range(len(group)):
						SgNa2xUM3OYBjp0 = group[P0cO9IQJ5AmnXxpqCuj]['searchFilterRenderer']
						if 'navigationEndpoint' in list(SgNa2xUM3OYBjp0.keys()):
							cOn6JqZlmQbjtT = SgNa2xUM3OYBjp0['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('\u0026','&')
							title = SgNa2xUM3OYBjp0['tooltip']
							title = title.replace('البحث عن ',SebHIf2jL1TBgrMKJu)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								sABprza7wEOC0Fd3PTQ = title
								Sn3lefFys4XLgp8JiRvV = cOn6JqZlmQbjtT
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',SebHIf2jL1TBgrMKJu)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								sABprza7wEOC0Fd3PTQ = title
								Sn3lefFys4XLgp8JiRvV = cOn6JqZlmQbjtT
							if 'Sort by' in title: continue
							iobPLUAOTn3d5tRrSEZDueFGwqW7s.append(a549mfV8gnzXpwlFr(title))
							W0me84kvMOraFAzu.append(cOn6JqZlmQbjtT)
			except: pass
		if not sABprza7wEOC0Fd3PTQ: Ca13hcDRyTFXpJrfEmZq8Uve = SebHIf2jL1TBgrMKJu
		else:
			iobPLUAOTn3d5tRrSEZDueFGwqW7s = ['بدون فلتر',sABprza7wEOC0Fd3PTQ]+iobPLUAOTn3d5tRrSEZDueFGwqW7s
			W0me84kvMOraFAzu = [SebHIf2jL1TBgrMKJu,Sn3lefFys4XLgp8JiRvV]+W0me84kvMOraFAzu
			ywSoYEbfvTI0XVROCiUJdWa6 = KKxHoL6iq4dst79zCUP215lYgMOreG('موقع يوتيوب - اختر الفلتر',iobPLUAOTn3d5tRrSEZDueFGwqW7s)
			if ywSoYEbfvTI0XVROCiUJdWa6 == -1: return
			Ca13hcDRyTFXpJrfEmZq8Uve = W0me84kvMOraFAzu[ywSoYEbfvTI0XVROCiUJdWa6]
		if Ca13hcDRyTFXpJrfEmZq8Uve: iGxH2fsuScPtkJb7ECg = j1IFsik4ouNePZr+Ca13hcDRyTFXpJrfEmZq8Uve
		elif qqEFdL1B6xamA: iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD+qqEFdL1B6xamA
		else: iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(iGxH2fsuScPtkJb7ECg)
	return