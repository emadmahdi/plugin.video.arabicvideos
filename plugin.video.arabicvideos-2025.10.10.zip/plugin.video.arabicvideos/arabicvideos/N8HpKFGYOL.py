# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ALMSTBA'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_MST_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['الرئيسية','يلا شوت']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==860: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==861: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==862: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==863: lfZmugQCFKLGT05AH29IsMiho = JZvYADs6nb0zV4WU7RM1So8X5dIp(url,text)
	elif mode==869: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr+'/indx1/',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,869,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"primary-links"(.*?)</u',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,861)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"list-categories"(.*?)<script',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT.lstrip('/')
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,861)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,ZZW5QJxjDlBLpGHA=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"home-content"(.*?)"footer"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('"overlay"','"duration"><')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		aLlVEzy8XR62 = []
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc,cOn6JqZlmQbjtT,title in items:
			title = title.strip(' ')
			title = cvlHmV1Kr0FIYSjNnM(title)
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if 'episodes' not in ZZW5QJxjDlBLpGHA and Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0][0]
				title = title.replace('اون لاين',SebHIf2jL1TBgrMKJu)
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,863,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,862,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,lEeAaSobjWc)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''["']pagination["'](.*?)["']footer["']''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		ZZW5QJxjDlBLpGHA = 'episodes_pages' if 'episodes' in ZZW5QJxjDlBLpGHA else 'pages'
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,861,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ZZW5QJxjDlBLpGHA)
	else:
		AeOBXUYP39mH5yuNxdRkVSJb = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination__next.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if AeOBXUYP39mH5yuNxdRkVSJb:
			cOn6JqZlmQbjtT = AeOBXUYP39mH5yuNxdRkVSJb[0]
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة لاحقة',cOn6JqZlmQbjtT,861,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ZZW5QJxjDlBLpGHA)
	return
def JZvYADs6nb0zV4WU7RM1So8X5dIp(url,yZfHYbEdxgemqNFoL8OSrR):
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-EPISODES_SEASONS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"episodes-container"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	i3iEyeZ8BQmpDNornRVxTzwdYcX7 = X2XorVqHjLkWeCchY4u9fSz.findall('"thumbnailUrl":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = i3iEyeZ8BQmpDNornRVxTzwdYcX7[0] if i3iEyeZ8BQmpDNornRVxTzwdYcX7 else SebHIf2jL1TBgrMKJu
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('\/','/')
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs += '|Referer='+j1IFsik4ouNePZr
	items = []
	N3zkg2cZqIHShYXdUMfCl5aDQ = False
	if Eky7GUxAVIQMn3ip0DOHrSYJ and not yZfHYbEdxgemqNFoL8OSrR:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-tab="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for yZfHYbEdxgemqNFoL8OSrR,title in items:
			yZfHYbEdxgemqNFoL8OSrR = yZfHYbEdxgemqNFoL8OSrR.strip('#')
			if len(items)>1: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,863,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,yZfHYbEdxgemqNFoL8OSrR)
			else: N3zkg2cZqIHShYXdUMfCl5aDQ = True
	else: N3zkg2cZqIHShYXdUMfCl5aDQ = True
	if N3zkg2cZqIHShYXdUMfCl5aDQ or not yZfHYbEdxgemqNFoL8OSrR:
		if not yZfHYbEdxgemqNFoL8OSrR: BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"tab-content.*?id="(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		else: BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"tab-content.*?id="'+yZfHYbEdxgemqNFoL8OSrR+'"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if BRdnHfWTrhFe:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('./')
				title = title.replace('</em><span>',qE4nB3mKWHs)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,862,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK,ff281j5nDJ0iK = [],[]
	qg7Nr1dCaD = url.strip('/')+'/?do=watch'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('iframe src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',cOn6JqZlmQbjtT,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-PLAY-2nd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
		Sn3lefFys4XLgp8JiRvV = X2XorVqHjLkWeCchY4u9fSz.findall('iframe src="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		Sn3lefFys4XLgp8JiRvV = Sn3lefFys4XLgp8JiRvV[0] if Sn3lefFys4XLgp8JiRvV else cOn6JqZlmQbjtT
		Sn3lefFys4XLgp8JiRvV = cvlHmV1Kr0FIYSjNnM(Sn3lefFys4XLgp8JiRvV)
		if Sn3lefFys4XLgp8JiRvV not in ff281j5nDJ0iK:
			ff281j5nDJ0iK.append(Sn3lefFys4XLgp8JiRvV)
			YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(Sn3lefFys4XLgp8JiRvV,'name')
			Sn3lefFys4XLgp8JiRvV = Sn3lefFys4XLgp8JiRvV+'?named='+YdzfwOyPb2gxT37B9Dm+'__embed'
			qOGEcWZIwex2fK.append(Sn3lefFys4XLgp8JiRvV)
	headers = {'Referer':url}
	vdYW0jGmuUQCMq3no9KRs = X2XorVqHjLkWeCchY4u9fSz.findall('post_id:(\d+)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	miVEOrhJQgv5LG7ajR0pnt = j1IFsik4ouNePZr+'/wp-admin/admin-ajax.php?action=video_info&post_id='+vdYW0jGmuUQCMq3no9KRs[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',miVEOrhJQgv5LG7ajR0pnt,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ALMSTBA-PLAY-3rd')
	O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"src":"(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('\/','/')
		if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
			ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
			YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch'
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"Download" target="_blank" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
			ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
			YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__download'
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return