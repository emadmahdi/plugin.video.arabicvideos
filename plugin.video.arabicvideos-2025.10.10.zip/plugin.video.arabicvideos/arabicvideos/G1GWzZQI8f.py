# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'KATKOUTE'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_KTK_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['الصفحة الرئيسية','Sign in','الأقسام']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==670: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==671: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==672: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==673: lfZmugQCFKLGT05AH29IsMiho = JZvYADs6nb0zV4WU7RM1So8X5dIp(url,text)
	elif mode==674: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==679: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,679,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"navslide-divider"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,mode)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	items = dUIVBjNyP31C(j1IFsik4ouNePZr+'/watch/browse.html')
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,674,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def dUIVBjNyP31C(url):
	yLTJ2AUPMDwXc = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','KATKOUTE','CATEGORIES')
	if yLTJ2AUPMDwXc: return yLTJ2AUPMDwXc
	yLTJ2AUPMDwXc = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-CATEGORIES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"category-header"(.*?)<footer>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		yLTJ2AUPMDwXc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if yLTJ2AUPMDwXc: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'KATKOUTE','CATEGORIES',yLTJ2AUPMDwXc,iHR47eol8wB3Z)
	return yLTJ2AUPMDwXc
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"caret"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('"presentation"','</ul>')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = [(SebHIf2jL1TBgrMKJu,drRnSgoBtKWjmU5FH4ZCIVhzqNb)]
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' فرز أو فلتر أو ترتيب '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		for bCsfqPwXyzihR1nm,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if bCsfqPwXyzihR1nm: bCsfqPwXyzihR1nm = bCsfqPwXyzihR1nm+': '
			for cOn6JqZlmQbjtT,title in items:
				title = bCsfqPwXyzihR1nm+title
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,671)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-category-subcats"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(items)<30:
			QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
			for cOn6JqZlmQbjtT,title in items:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,671)
	if not Eky7GUxAVIQMn3ip0DOHrSYJ and not BRdnHfWTrhFe: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,pbmcw9i1kfuNIQzJ7aGd3l0=SebHIf2jL1TBgrMKJu):
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-TITLES-1st')
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-TITLES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	drRnSgoBtKWjmU5FH4ZCIVhzqNb,items = SebHIf2jL1TBgrMKJu,[]
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc: items.append((SebHIf2jL1TBgrMKJu,cOn6JqZlmQbjtT,title))
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-video-watch-featured"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(k2pC30UArFeg7Ru9tGiZlSmzQ)>1: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[1]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc: items.append((SebHIf2jL1TBgrMKJu,cOn6JqZlmQbjtT,title))
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(data-echo=".*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if drRnSgoBtKWjmU5FH4ZCIVhzqNb and not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: return
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,672,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,672,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx:
			title = '_MOD_' + Wj39BaH6oEmstx[0][0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,673,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/movseries/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,671,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,673,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if cOn6JqZlmQbjtT=='#': continue
			if 'http' not in cOn6JqZlmQbjtT:
				qg7Nr1dCaD = url.rsplit('/',1)[0]
				cOn6JqZlmQbjtT = qg7Nr1dCaD+'/'+cOn6JqZlmQbjtT.strip('/')
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,671,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,pbmcw9i1kfuNIQzJ7aGd3l0)
	return
def JZvYADs6nb0zV4WU7RM1So8X5dIp(url,yZfHYbEdxgemqNFoL8OSrR):
	QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'تشغيل الفيديو',url,672)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	yLTJ2AUPMDwXc = dUIVBjNyP31C(j1IFsik4ouNePZr+'/watch/browse.html')
	ipvIY7hkTuKyxjcMZ4XCVRwB,iK2pCEboIOst57uLqBz,aS8MkCgitYAwBU7oy16IZpXjq = zip(*yLTJ2AUPMDwXc)
	ae5GmVQiYsq = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-EPISODES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-video-heading"(.*?)id="player"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			if cOn6JqZlmQbjtT not in ipvIY7hkTuKyxjcMZ4XCVRwB:
				JJSOAkTZIib4eswDo51pFuqvK = (cOn6JqZlmQbjtT,title)
				ae5GmVQiYsq.append(JJSOAkTZIib4eswDo51pFuqvK)
		if len(ae5GmVQiYsq)==1:
			cOn6JqZlmQbjtT,title = ae5GmVQiYsq[0]
			yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(cOn6JqZlmQbjtT,'new_episodes')
			return
		else:
			for cOn6JqZlmQbjtT,title in ae5GmVQiYsq:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,671,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'new_episodes')
	if not ae5GmVQiYsq: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'new_episodes')
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'KATKOUTE-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('sources:(.*?)flashplayer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('file: "(.*?)".*?label: "(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,lcbjBn3FdZxC1059A4Kqvi2pugJOa in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named=__watch__'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('"embedded-video".*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not uLdRirAZJKoSgPqNUjm84WXE5cn3aT: uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall("file: '(.*?)'",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
		cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0]
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
		qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=__embed')
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/watch/search.php?keywords='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return