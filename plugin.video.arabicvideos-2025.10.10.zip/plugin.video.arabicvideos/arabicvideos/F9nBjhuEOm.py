# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'FAJERSHOW'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_FJS_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==390: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==391: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==392: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==393: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==399: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,399,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FAJERSHOW-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<header>.*?<h2>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for qqai0c7OSNreCszImF23EhYV1KnXLx in range(len(items)):
		title = items[qqai0c7OSNreCszImF23EhYV1KnXLx]
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,j1IFsik4ouNePZr,391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'latest'+str(qqai0c7OSNreCszImF23EhYV1KnXLx))
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مختارات عشوائية',j1IFsik4ouNePZr,391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'randoms')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أعلى الأفلام تقييماً',j1IFsik4ouNePZr,391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'top_imdb_movies')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أعلى المسلسلات تقييماً',j1IFsik4ouNePZr,391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'top_imdb_series')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام مميزة',j1IFsik4ouNePZr+'/movies',391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured_movies')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مميزة',j1IFsik4ouNePZr+'/tvshows',391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured_tvshows')
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu"(.*?)id="contenedor"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb += k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/movies',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FAJERSHOW-MENU-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="releases"(.*?)aside',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb += k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	cZs2GKDIAnwSryJ0R7m3 = True
	for cOn6JqZlmQbjtT,title in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		if title=='الأعلى مشاهدة':
			if cZs2GKDIAnwSryJ0R7m3:
				title = 'الافلام '+title
				cZs2GKDIAnwSryJ0R7m3 = False
			else: title = 'المسلسلات '+title
		if title not in jgvMWZhtPlBT:
			if title=='أفلام': QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,j1IFsik4ouNePZr+'/movies',391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'all_movies_tvshows')
			elif title=='مسلسلات': QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,j1IFsik4ouNePZr+'/tvshows',391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'all_movies_tvshows')
			else: QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,391)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type):
	drRnSgoBtKWjmU5FH4ZCIVhzqNb,items = [],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FAJERSHOW-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if type in ['featured_movies','featured_tvshows']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="content"(.*?)id="archive-content"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif type=='all_movies_tvshows':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="archive-content"(.*?)class="pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif type=='top_imdb_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='top_imdb_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("class='top-imdb-list tright(.*?)footer",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='search':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="search-page"(.*?)class="sidebar',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='sider':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="widget(.*?)class="widget',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		eUuRqsfnW8y2BS5cCG4ZhgODJj = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		bQGVWFxKS4D6p9YC7XPyA8Os,cr1ok5Ww9FQh,HFThJNteGZsSR5CD7rimbjPq = zip(*eUuRqsfnW8y2BS5cCG4ZhgODJj)
		items = zip(cr1ok5Ww9FQh,bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq)
	elif type=='randoms':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="slider-movies-tvshows"(.*?)<header>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif 'latest' in type:
		qqai0c7OSNreCszImF23EhYV1KnXLx = int(type[-1:])
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('<header>','<end><start>')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('</div></div></div>','</div></div></div><end>')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<start>(.*?)<end>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[qqai0c7OSNreCszImF23EhYV1KnXLx]
		if qqai0c7OSNreCszImF23EhYV1KnXLx==6:
			eUuRqsfnW8y2BS5cCG4ZhgODJj = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			cr1ok5Ww9FQh,HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = zip(*eUuRqsfnW8y2BS5cCG4ZhgODJj)
			items = zip(cr1ok5Ww9FQh,bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="content"(.*?)class="(pagination|sidebar)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0][0]
			if '/collection/' in url:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			elif '/quality/' in url:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items and drRnSgoBtKWjmU5FH4ZCIVhzqNb:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = X2XorVqHjLkWeCchY4u9fSz.findall('^(.*?)<.*?serie">(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			title = title[0][1]
			if title in aLlVEzy8XR62: continue
			aLlVEzy8XR62.append(title)
			title = '_MOD_'+title
		sABprza7wEOC0Fd3PTQ = X2XorVqHjLkWeCchY4u9fSz.findall('^(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if sABprza7wEOC0Fd3PTQ: title = sABprza7wEOC0Fd3PTQ[0]
		title = cvlHmV1Kr0FIYSjNnM(title)
		if '/tvshows/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,393,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/episodes/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,393,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/seasons/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,393,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/collection/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,391,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,392,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type not in ['featured_movies','featured_tvshows']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,391,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	url = url.replace(YdzfwOyPb2gxT37B9Dm,j1IFsik4ouNePZr)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FAJERSHOW-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('class="C rated".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,392,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = r3jPAgNdhp(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FAJERSHOW-PLAY-1st')
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('class="C rated".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0][0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for type,BHvXNYSAsJ0dLy4MCw3ilODxIrGtT,qHSFVCX0JKMtwP,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+BHvXNYSAsJ0dLy4MCw3ilODxIrGtT+'&nume='+qHSFVCX0JKMtwP+'&type='+type
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,lcbjBn3FdZxC1059A4Kqvi2pugJOa,kWK265p4lZFTBSwbPJ in items:
			if '=' in tncvzBN0kyrqEHlhIPGSoX4ugA3CDs:
				nZ9d0f6mF3ugEJlj = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.split('=')[1]
				title = EDmwsQf1Px9k8h04oAHuObdnyrTGU(nZ9d0f6mF3ugEJlj,'host')
			else: title = SebHIf2jL1TBgrMKJu
			title = kWK265p4lZFTBSwbPJ+qE4nB3mKWHs+title
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return