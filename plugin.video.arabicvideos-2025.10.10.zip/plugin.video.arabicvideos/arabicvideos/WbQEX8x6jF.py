# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = HADrRCz9QgU4xudPJIqYb70(u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ᱀")
FFe0IfYj65szqgLHkNpBPJnRQEmZo = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡢࡐࡘ࡚࡟ࠨ᱁")
zYEXxHIZtvkcBON14A = K7cnfQMS6BPvI4LGmCsRp8bUlJ9
KOCngPG546u9sH7DU3tvQTJZeNrX = ASkvf27etUK0(u"࠶࠶Ậ")
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,url,Yg36raSGA02uUXEPMF7itZd9KcWf,Q8A5HyT1fGNxZv4X3V7eC,q0HoRKzxwkDFaj3P8r19JBTIACM):
	try: yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q = str(q0HoRKzxwkDFaj3P8r19JBTIACM[l7kBpMw5Qn(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱂")])
	except: yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q = SebHIf2jL1TBgrMKJu
	if   hL9fngBAu7XzOx==Izy1PvclrYx4eSVWn0L5phZbq(u"࠷࠶࠱ậ"): lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠱࠷࠳Ắ"): lfZmugQCFKLGT05AH29IsMiho = e5Hfy1rMLi6AZETzhcmgQV23IpjqNS(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==Ns6AJKH7DGpr19Wl5C3nF(u"࠲࠸࠵ắ"): lfZmugQCFKLGT05AH29IsMiho = fyn0H5ZT8FMrxcb3sCI(Yg36raSGA02uUXEPMF7itZd9KcWf,Ns6AJKH7DGpr19Wl5C3nF(u"࠲࠸࠵ắ"))
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠳࠹࠷Ằ"): lfZmugQCFKLGT05AH29IsMiho = fyn0H5ZT8FMrxcb3sCI(Yg36raSGA02uUXEPMF7itZd9KcWf,iDhLkZS6XBagNCQfs9tq2(u"࠳࠹࠷Ằ"))
	elif hL9fngBAu7XzOx==Gykx0wL3XrlWaujsqKP9n2Q(u"࠴࠺࠹ằ"): lfZmugQCFKLGT05AH29IsMiho = TvmC1xz0o8N(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==Izy1PvclrYx4eSVWn0L5phZbq(u"࠵࠻࠻Ẳ"): lfZmugQCFKLGT05AH29IsMiho = lca0SEUG9MOZvIrd4bAoJLfzkejxm(url,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠶࠼࠶ẳ"): lfZmugQCFKLGT05AH29IsMiho = rJsqbOw0DP(url,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠷࠶࠸Ẵ"): lfZmugQCFKLGT05AH29IsMiho = LBcWq2Dl4T9ezsi(url,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==sTGtHVyhQ9cJU37zxo2O(u"࠱࠷࠺ẵ"): lfZmugQCFKLGT05AH29IsMiho = U2WklgqxyOV4wb7mL1TBz9PAGRHi(url,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==xxRyYsrSCzjifvH4cIqgldeOo(u"࠸࠸࠴Ặ"): lfZmugQCFKLGT05AH29IsMiho = IIsn4p1SUdCc85X9OqR()
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠹࠹࠶ặ"): lfZmugQCFKLGT05AH29IsMiho = Jc7rpMQDjP3LuUlSCyGvKT()
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠺࠺࠸Ẹ"): lfZmugQCFKLGT05AH29IsMiho = HyW2UGYTFSO51NvwBALjl(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,Yg36raSGA02uUXEPMF7itZd9KcWf,Q8A5HyT1fGNxZv4X3V7eC)
	elif hL9fngBAu7XzOx==fp6KV7DlS8QYniUczHdmZChL(u"࠻࠻࠺ẹ"): lfZmugQCFKLGT05AH29IsMiho = xoZmMRPbpiNKH7zFXsGWC(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==zpx2fPNKk6Ms38eD1vcO(u"࠼࠼࠵Ẻ"): lfZmugQCFKLGT05AH29IsMiho = SPN2KynQpc(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,Yg36raSGA02uUXEPMF7itZd9KcWf)
	else: lfZmugQCFKLGT05AH29IsMiho = mrhSYXH2P8bO3eJAa9n
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᱃"),bcNqYtfET5l92dLGjyZSPe(u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭᱄"),SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"࠷࠶࠲ẻ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᱅"))
	QUzFYoapm9jx(uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᱆"),HADrRCz9QgU4xudPJIqYb70(u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ᱇"),SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"࠱࠷࠴Ẽ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,gCkRKGhwcx26v(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱈"))
	QUzFYoapm9jx(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱉"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ᱊"),SebHIf2jL1TBgrMKJu,tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲࠸࠶ẽ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᱋"))
	QUzFYoapm9jx(zpx2fPNKk6Ms38eD1vcO(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᱌"),sTGtHVyhQ9cJU37zxo2O(u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭ᱍ"),SebHIf2jL1TBgrMKJu,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠳࠹࠸Ế"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱎ"))
	QUzFYoapm9jx(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱏ"),l7kBpMw5Qn(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᱐"),SebHIf2jL1TBgrMKJu,Gykx0wL3XrlWaujsqKP9n2Q(u"࠺࠺࠸ế"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭᱑"))
	QUzFYoapm9jx(gCkRKGhwcx26v(u"ࠬࡲࡩ࡯࡭ࠪ᱒"),E7r8hUCVvTiFQW0dBGXjxcy+ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᱓")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,l7kBpMw5Qn(u"࠽࠾࠿࠹Ề"))
	QUzFYoapm9jx(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᱔"),czvu7VQCZodkMf(u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ᱕"),SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"࠶࠼࠳ề"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᱖"))
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱗"),bcNqYtfET5l92dLGjyZSPe(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ᱘"),SebHIf2jL1TBgrMKJu,zpx2fPNKk6Ms38eD1vcO(u"࠷࠶࠴Ể"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱙"))
	QUzFYoapm9jx(DQIrVcKuY6bJv(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱚ"),ASkvf27etUK0(u"ࠧใี่ࠤ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧᱛ"),SebHIf2jL1TBgrMKJu,Gykx0wL3XrlWaujsqKP9n2Q(u"࠱࠷࠴ể"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱜ"))
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱝ"),TVnqDYzWoM2UfHp0dchJ(u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪᱞ"),SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"࠲࠸࠵Ễ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱟ"))
	QUzFYoapm9jx(C3w6qluao7EzUxJgMGBtV(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱠ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩᱡ"),SebHIf2jL1TBgrMKJu,HADrRCz9QgU4xudPJIqYb70(u"࠳࠹࠸ễ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,AGlW9LqKN3Dvo(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱢ"))
	QUzFYoapm9jx(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱣ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᱤ"),SebHIf2jL1TBgrMKJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠺࠺࠺Ệ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,iDhLkZS6XBagNCQfs9tq2(u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱥ"))
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠫࡱ࡯࡮࡬ࠩᱦ"),E7r8hUCVvTiFQW0dBGXjxcy+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᱧ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠽࠾࠿࠹ệ"))
	QUzFYoapm9jx(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱨ"),iDhLkZS6XBagNCQfs9tq2(u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬᱩ"),SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠶࠼࠳Ỉ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱪ"))
	QUzFYoapm9jx(AGlW9LqKN3Dvo(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱫ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᱬ"),SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"࠷࠶࠴ỉ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱭ"))
	QUzFYoapm9jx(C3w6qluao7EzUxJgMGBtV(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᱮ"),TVnqDYzWoM2UfHp0dchJ(u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧᱯ"),SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"࠱࠷࠴Ị"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱰ"))
	QUzFYoapm9jx(ALwOspNtXxZrz3PEKku(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱱ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪᱲ"),SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"࠲࠸࠵ị"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,l7kBpMw5Qn(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᱳ"))
	QUzFYoapm9jx(AGlW9LqKN3Dvo(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᱴ"),HCiWF4jV1Q8(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥฮอฬࠢ฼ุํอฦ๋ࠩᱵ"),SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠳࠹࠸Ọ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱶ"))
	QUzFYoapm9jx(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱷ"),HCiWF4jV1Q8(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᱸ"),SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"࠺࠺࠹ọ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,AGlW9LqKN3Dvo(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱹ"))
	return
def IIsn4p1SUdCc85X9OqR():
	QUzFYoapm9jx(VOALf8iYEnMdK0g(u"ࠪࡪࡴࡲࡤࡦࡴࠪᱺ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡤࡏࡐࡕࡡࠪᱻ")+wPnfgxKZdAv6T10(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪᱼ"),SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"࠻࠻࠺Ỏ"))
	QUzFYoapm9jx(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡬ࡪࡰ࡮ࠫᱽ"),E7r8hUCVvTiFQW0dBGXjxcy+czvu7VQCZodkMf(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᱾")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,gCkRKGhwcx26v(u"࠾࠿࠹࠺ỏ"))
	for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
		FFe0IfYj65szqgLHkNpBPJnRQEmZo = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡡࡌࡔࠬ᱿")+str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡢࠫᲀ")
		QUzFYoapm9jx(TVnqDYzWoM2UfHp0dchJ(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲁ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+C3w6qluao7EzUxJgMGBtV(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᲂ")+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q],SebHIf2jL1TBgrMKJu,VOALf8iYEnMdK0g(u"࠽࠶࠵Ố"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲃ"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
	return
def Jc7rpMQDjP3LuUlSCyGvKT():
	QUzFYoapm9jx(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᲄ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᲅ")+AGlW9LqKN3Dvo(u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬᲆ"),SebHIf2jL1TBgrMKJu,Izy1PvclrYx4eSVWn0L5phZbq(u"࠷࠷࠷ố"))
	QUzFYoapm9jx(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࡯࡭ࡳࡱࠧᲇ"),E7r8hUCVvTiFQW0dBGXjxcy+HCiWF4jV1Q8(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᲈ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,wPnfgxKZdAv6T10(u"࠺࠻࠼࠽Ồ"))
	for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
		FFe0IfYj65szqgLHkNpBPJnRQEmZo = HCiWF4jV1Q8(u"ࠫࡤࡓࡕࠨᲉ")+str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)+iDhLkZS6XBagNCQfs9tq2(u"ࠬࡥࠧᲊ")
		QUzFYoapm9jx(uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲋"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ᲌")+LNTg8tIPV9bh3YOvxGCQoylBzdEJi[yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q],SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"࠹࠹࠹ồ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,{Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᲍"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
	return
def Dbj3650e1gNiHx(GJ4kbYnxcHa6NIOuA7X20S):
	global z2zOcFnESZAbd4we8q,YdAi58t0NeZx
	o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
	try:
		if DQIrVcKuY6bJv(u"ࠩࡌࡊࡎࡒࡍࠨ᲎") in GJ4kbYnxcHa6NIOuA7X20S: o6aYtV2fpKOCDJ(GJ4kbYnxcHa6NIOuA7X20S)
		else: o6aYtV2fpKOCDJ()
		Ll91GJzBph3VUFnq0wmDSxXProeHZt = mrhSYXH2P8bO3eJAa9n
	except:
		OZINRkynbpYDKiTqHVoces9XEMCxtP()
		Ll91GJzBph3VUFnq0wmDSxXProeHZt = BBX9RAuxnyGZ4WIF2TrhYeom3
	GJ4kbYnxcHa6NIOuA7X20S = dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S)
	if Ll91GJzBph3VUFnq0wmDSxXProeHZt:
		i9yzUqgAW2Zap1h4Lm(GJ4kbYnxcHa6NIOuA7X20S,C3w6qluao7EzUxJgMGBtV(u"ࠪๅู๊ࠠๅๆฦืๆ࠭᲏"),uv8V4fE7j9pmgFr3wnDL=Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠵࠴࠵࠶Ổ"))
		z2zOcFnESZAbd4we8q += nyUIsfd53EGot9vbj0XDeq
		YdAi58t0NeZx += TVnqDYzWoM2UfHp0dchJ(u"ࠫࠥ࠴ࠠࠨᲐ")+GJ4kbYnxcHa6NIOuA7X20S
	else: i9yzUqgAW2Zap1h4Lm(GJ4kbYnxcHa6NIOuA7X20S,SebHIf2jL1TBgrMKJu,uv8V4fE7j9pmgFr3wnDL=wPnfgxKZdAv6T10(u"࠵࠵࠶࠰ổ"))
	return
E2Et4cHoxzqKU89pDvwjn = {}
def tS7CBRdygrhzEPL1pXuOx6(mGhRK2QOHrd0Izv=BBX9RAuxnyGZ4WIF2TrhYeom3):
	global z2zOcFnESZAbd4we8q,YdAi58t0NeZx,E2Et4cHoxzqKU89pDvwjn
	if not mGhRK2QOHrd0Izv:
		E2Et4cHoxzqKU89pDvwjn = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡪࡩࡤࡶࠪᲑ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧᲒ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬᲓ"))
		if E2Et4cHoxzqKU89pDvwjn: return
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᲔ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩะฮ๎ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱࠲ู๊ࠥโฯุࠤฬ๊ศา่ส้ัࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰࠱ࠤ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࡝ࡰ࡟ࡲࠬᲕ")+E7r8hUCVvTiFQW0dBGXjxcy+AGlW9LqKN3Dvo(u"๋้ࠪࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬᲖ")+XOVRfitWJP1zL3p2CMYF)
	if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return
	ko5ymgwaUtVilrPc3jpWhKJ(QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF)
	mDEwMh9cHl401X = qFsuKN7ngp.menuItemsLIST
	z2zOcFnESZAbd4we8q,YdAi58t0NeZx,threads = wvkDqmNZlJU52isXo,SebHIf2jL1TBgrMKJu,{}
	for GJ4kbYnxcHa6NIOuA7X20S in RjqxpwMymsZ7v6cGhLlBn52zi:
		uv8V4fE7j9pmgFr3wnDL.sleep(nyUIsfd53EGot9vbj0XDeq)
		threads[GJ4kbYnxcHa6NIOuA7X20S] = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=Dbj3650e1gNiHx,args=(GJ4kbYnxcHa6NIOuA7X20S,))
		threads[GJ4kbYnxcHa6NIOuA7X20S].start()
	else:
		for GJ4kbYnxcHa6NIOuA7X20S in list(threads.keys()): threads[GJ4kbYnxcHa6NIOuA7X20S].join()
	qFsuKN7ngp.menuItemsLIST[:] = mDEwMh9cHl401X
	E2Et4cHoxzqKU89pDvwjn = {}
	for GJ4kbYnxcHa6NIOuA7X20S in list(threads.keys()):
		try: TwijM4xE6OCDcVU8 = qFsuKN7ngp.menuItemsDICT[GJ4kbYnxcHa6NIOuA7X20S]
		except: continue
		GJ4kbYnxcHa6NIOuA7X20S = wPnfgxKZdAv6T10(u"ࠫࡤࡒࡓࡕࡡࠪᲗ")+dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S)
		for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW in TwijM4xE6OCDcVU8:
			if not xzpZLdkW2Ol: xzpZLdkW2Ol = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬ࠴࠮࠯࠰ࠪᲘ")
			else:
				if xzpZLdkW2Ol.count(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭࡟ࠨᲙ"))>nyUIsfd53EGot9vbj0XDeq: xzpZLdkW2Ol = xzpZLdkW2Ol.split(czvu7VQCZodkMf(u"ࠧࡠࠩᲚ"),JhTts2R43AxkM8bYanKVy)[JhTts2R43AxkM8bYanKVy]
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(gCkRKGhwcx26v(u"ࠨࢢࠪᲛ"),SebHIf2jL1TBgrMKJu).replace(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࠣࡌࡉ࠭Ნ"),SebHIf2jL1TBgrMKJu).replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡌࡉࠦࠧᲝ"),SebHIf2jL1TBgrMKJu)
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(wPnfgxKZdAv6T10(u"ࠫๅ࠭Პ"),SebHIf2jL1TBgrMKJu).replace(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬฯࠧᲟ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠭็ࠨᲠ")).replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧลࠩᲡ"),DQIrVcKuY6bJv(u"ࠨ๊ࠪᲢ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(wPnfgxKZdAv6T10(u"ࠩฦࠫᲣ"),zpx2fPNKk6Ms38eD1vcO(u"ࠪหࠬᲤ")).replace(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫส࠭Ქ"),sTGtHVyhQ9cJU37zxo2O(u"ࠬอࠧᲦ")).replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ยࠨᲧ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧศࠩᲨ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨๆฦࠫᲩ"),czvu7VQCZodkMf(u"ࠩ็หࠬᲪ")).replace(czvu7VQCZodkMf(u"่ࠪส࠭Ძ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"้ࠫอࠧᲬ")).replace(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"๊ࠬยࠨᲭ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭ไศࠩᲮ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧ๏ࠩᲯ"),SebHIf2jL1TBgrMKJu).replace(ASkvf27etUK0(u"ࠨํࠪᲰ"),SebHIf2jL1TBgrMKJu).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ๒ࠫᲱ"),SebHIf2jL1TBgrMKJu).replace(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪ๐ࠬᲲ"),SebHIf2jL1TBgrMKJu)
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(iDhLkZS6XBagNCQfs9tq2(u"ࠫ๕࠭Ჳ"),SebHIf2jL1TBgrMKJu).replace(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬ๓ࠧᲴ"),SebHIf2jL1TBgrMKJu).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭๒ࠨᲵ"),SebHIf2jL1TBgrMKJu).replace(VOALf8iYEnMdK0g(u"ࠧ๒ࠩᲶ"),SebHIf2jL1TBgrMKJu)
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡾࠪᲷ"),SebHIf2jL1TBgrMKJu).replace(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࢁࠫᲸ"),SebHIf2jL1TBgrMKJu)
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(AGlW9LqKN3Dvo(u"ࠪหํ์ࠠๅษํ๊ࠬᲹ"),SebHIf2jL1TBgrMKJu).replace(zpx2fPNKk6Ms38eD1vcO(u"ุࠫ๐ๅศࠢ็ห๏ะࠧᲺ"),SebHIf2jL1TBgrMKJu)
				StPCeNDFHA0vqVIwTikErjyMWJ6ZY1 = [Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬอไฺษหࠫ᲻"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ฮ๋ษ็ࠫ᲼"),HADrRCz9QgU4xudPJIqYb70(u"ࠧศๆห์๊࠭Ჽ"),HCiWF4jV1Q8(u"ࠨษ็ห๋࠭Ჾ"),bcNqYtfET5l92dLGjyZSPe(u"ࠩส฻ๆอไࠨᲿ"),zpx2fPNKk6Ms38eD1vcO(u"ࠪัฬ๊๊่ࠩ᳀"),l7kBpMw5Qn(u"ࠫฬฺ๊ศิࠪ᳁"),C3w6qluao7EzUxJgMGBtV(u"ࠬ฻วๅฯࠪ᳂"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠭วๅัํ๊ࠬ᳃"),fp6KV7DlS8QYniUczHdmZChL(u"ࠧๆ๊ส่๏ีࠧ᳄"),gCkRKGhwcx26v(u"ࠨษ็฽ฬ๊ๅࠨ᳅"),DQIrVcKuY6bJv(u"ࠩส฽๊อไࠨ᳆")]
				if not any(pJrRgH0Bvej2dNPzbSa1 in xzpZLdkW2Ol for pJrRgH0Bvej2dNPzbSa1 in StPCeNDFHA0vqVIwTikErjyMWJ6ZY1): xzpZLdkW2Ol = xzpZLdkW2Ol.replace(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪห้࠭᳇"),SebHIf2jL1TBgrMKJu)
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠫฬิั๋ࠩ᳈"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬอฮา๋ࠪ᳉")).replace(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭วอ่หํࠬ᳊"),iDhLkZS6XBagNCQfs9tq2(u"ࠧศฮ้ฬ๏࠭᳋")).replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨ฻สส้๐็ࠨ᳌"),TVnqDYzWoM2UfHp0dchJ(u"ࠩ฼หห๊๊ࠨ᳍"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(HCiWF4jV1Q8(u"ࠪหั์ศ๋้ࠪ᳎"),gCkRKGhwcx26v(u"ࠫฬาๆษ์ࠪ᳏")).replace(wPnfgxKZdAv6T10(u"ࠬ฿ัษ์๊ࠫ᳐"),ASkvf27etUK0(u"ู࠭าสํࠫ᳑")).replace(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧา๊่หู๋๊่ࠩ᳒"),bcNqYtfET5l92dLGjyZSPe(u"ࠨำ๋้ฬ์ำ๋ࠩ᳓"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ฽ีอ๐็ࠨ᳔"),VOALf8iYEnMdK0g(u"ࠪ฾ึฮ๊ࠨ᳕")).replace(VOALf8iYEnMdK0g(u"ࠫํࠦๅิๆึ่ฬะ᳖ࠧ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"๋ࠬำๅี็หฯ᳗࠭")).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ว฻ษ้ํ᳘ࠬ"),czvu7VQCZodkMf(u"ࠧศ฼ส๊๏᳙࠭"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠨฬสี๏ิ๊ࠨ᳚"),VOALf8iYEnMdK0g(u"ࠩอหึ๐ฮࠨ᳛")).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪา๏อไࠡ฻็้๏᳜࠭"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠫำ๐วๅ᳝ࠩ")).replace(Izy1PvclrYx4eSVWn0L5phZbq(u"๋่ࠬิ์ๅ๎์᳞࠭"),Ns6AJKH7DGpr19Wl5C3nF(u"࠭ๅ้ีํๆ๎᳟࠭"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(zpx2fPNKk6Ms38eD1vcO(u"่่ࠧาํࠬ᳠"),fp6KV7DlS8QYniUczHdmZChL(u"ࠨ้้ำ๏࠭᳡")).replace(wPnfgxKZdAv6T10(u"๊๊ࠩิ๐็ࠨ᳢"),gCkRKGhwcx26v(u"๋๋ࠪี๊ࠨ᳣")).replace(ALwOspNtXxZrz3PEKku(u"ࠫํัววไํ᳤๋ࠬ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ๎หศศๅ๎᳥ࠬ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(VOALf8iYEnMdK0g(u"࠭สๅ์ไึ๏๎ๆ᳦๋้ࠪ"),AGlW9LqKN3Dvo(u"ࠧหๆไึ๏๎ๆࠨ᳧")).replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨฬ็ๅื๐่็์᳨๊ࠫ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩอ่ๆุ๊้่ࠪᳩ")).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪ์้ࠥัห๊้ࠫᳪ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫํ้ัห๊้ࠫᳫ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬอไฮษ็๎์࠭ᳬ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠭อศๆํ๋᳭ࠬ")).replace(VOALf8iYEnMdK0g(u"ࠧๆ๊ึ໐็๐ࠧᳮ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ็๋ื๏่้ࠨᳯ")).replace(wPnfgxKZdAv6T10(u"ࠩส่ฬ์ๅ๋ࠩᳰ"),ALwOspNtXxZrz3PEKku(u"ࠪห๋๋๊ࠨᳱ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(Ns6AJKH7DGpr19Wl5C3nF(u"ࠫฬ๊ๅิๆึ่ฬะࠧᳲ"),iDhLkZS6XBagNCQfs9tq2(u"๋ࠬำๅี็หฯ࠭ᳳ")).replace(VOALf8iYEnMdK0g(u"࠭วๅสิห๊าࠧ᳴"),AGlW9LqKN3Dvo(u"ࠧษำส้ั࠭ᳵ")).replace(HADrRCz9QgU4xudPJIqYb70(u"ࠨๅสีฯ๎ๆࠨᳶ"),C3w6qluao7EzUxJgMGBtV(u"ࠩๆีฯ๎ๆࠨ᳷"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(sTGtHVyhQ9cJU37zxo2O(u"ࠪัึ๎ศࠨ᳸"),HADrRCz9QgU4xudPJIqYb70(u"ࠫาืศࠨ᳹")).replace(bcNqYtfET5l92dLGjyZSPe(u"ࠬอไศ่สุ๏ีࠧᳺ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭ว็ษื๎ิ࠭᳻")).replace(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧศีํ์๏ํࠧ᳼"),DQIrVcKuY6bJv(u"ࠨษึ๎ํ๐ࠧ᳽"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩ฼ีอ๏ࠧ᳾"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ฽ึฮ๊ࠨ᳿")).replace(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫฯืใ๊ࠩᴀ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬะัไ์ࠪᴁ")).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭สาๅํ๋ࠬᴂ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧหำๆ๎ࠬᴃ")).replace(bcNqYtfET5l92dLGjyZSPe(u"ࠨษ็้฻อแࠨᴄ"),czvu7VQCZodkMf(u"ฺ่ࠩฬ็ࠧᴅ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(HADrRCz9QgU4xudPJIqYb70(u"ࠪี๏อึ๋ࠩᴆ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫึ๐วืหࠪᴇ")).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠬื๊ศุ๊ࠫᴈ"),DQIrVcKuY6bJv(u"࠭ั๋ษูอࠬᴉ")).replace(HADrRCz9QgU4xudPJIqYb70(u"ࠧศีํ์๏ํࠧᴊ"),czvu7VQCZodkMf(u"ࠨษึ๎ํ๐ࠧᴋ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(iDhLkZS6XBagNCQfs9tq2(u"ࠩๆ์๊๐ฯ๊ࠩᴌ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ็ํ๋๊ะ์ࠪᴍ")).replace(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"่ࠫ๎ๅ๋ัํ๋ࠬᴎ"),xxRyYsrSCzjifvH4cIqgldeOo(u"้่ࠬๆ์า๎ࠬᴏ")).replace(l7kBpMw5Qn(u"࠭ว็์่๎ࠬᴐ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧศ่่๎ࠬᴑ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨษ้๎๊๐ิ็ࠩᴒ"),AGlW9LqKN3Dvo(u"ࠩส๊๊๐ิ็ࠩᴓ")).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪห๋๋้ࠨᴔ"),sTGtHVyhQ9cJU37zxo2O(u"ࠫฬ์ๅ๋ึ้ࠫᴕ")).replace(gCkRKGhwcx26v(u"ࠬอๆๆ์ࠪᴖ"),TVnqDYzWoM2UfHp0dchJ(u"࠭ว็็ํุ๋࠭ᴗ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(zpx2fPNKk6Ms38eD1vcO(u"ࠧศ่่๎ู์ิ็ࠩᴘ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨษ้้๏ฺๆࠨᴙ")).replace(sTGtHVyhQ9cJU37zxo2O(u"ࠩส่ฬ์ๅ๋ึ้ࠫᴚ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪห๋๋๊ี่ࠪᴛ")).replace(czvu7VQCZodkMf(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫᴜ"),VOALf8iYEnMdK0g(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ᴝ"))
				xzpZLdkW2Ol = xzpZLdkW2Ol.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).strip(ASkvf27etUK0(u"࠭࠭ࠨᴞ")).strip(qE4nB3mKWHs)
			if xzpZLdkW2Ol not in list(E2Et4cHoxzqKU89pDvwjn.keys()): E2Et4cHoxzqKU89pDvwjn[xzpZLdkW2Ol] = {}
			E2Et4cHoxzqKU89pDvwjn[xzpZLdkW2Ol][GJ4kbYnxcHa6NIOuA7X20S] = [GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,PivTAZtgp1QB,adUemWgVECPGjZ1tX6lK2L3rzoORy4,Yg36raSGA02uUXEPMF7itZd9KcWf,za6XoDpqQx953L,MQcCbiOnpXkdwNfIe8Vj7ZuRW]
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,DQIrVcKuY6bJv(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨᴟ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭ᴠ"),E2Et4cHoxzqKU89pDvwjn,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	if z2zOcFnESZAbd4we8q>=KOCngPG546u9sH7DU3tvQTJZeNrX: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,sTGtHVyhQ9cJU37zxo2O(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪᴡ")+str(z2zOcFnESZAbd4we8q)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࠤ๊๎โฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์์้ะศุ่่๊ࠢษࠡีหฬ์อฺࠠษาอ๋ࠥๆࠡษ็ษ๋ะั็์อࠤ฾์ฯไ๋ࠢห้๋่ศไ฼ࠤ์๐࠺ࠨᴢ")+YdAi58t0NeZx)
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,AGlW9LqKN3Dvo(u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪᴣ"))
	ko5ymgwaUtVilrPc3jpWhKJ(cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db)
	LbTfk6oJPiSGpVMU()
	return
def cfbQZ4eOxy7Kg2aVCq(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH):
	AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
	mBPv6wX4Tt = qFsuKN7ngp.menuItemsLIST
	qFsuKN7ngp.menuItemsLIST[:] = []
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 and fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᴤ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
		lfZmugQCFKLGT05AH29IsMiho = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,bcNqYtfET5l92dLGjyZSPe(u"࠭࡬ࡪࡵࡷࠫᴥ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᴦ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩᴧ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)
	elif ASkvf27etUK0(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᴨ") not in V7o8RyDJNnF50GpbLsPjdUwefH or Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡣ࡛ࡕࡄࡠࠩᴩ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
		import EEMpr2e8JS
		FKe1TxU27G4SPo8hDER = AGlW9LqKN3Dvo(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡำึหห๊ࠠศๆหี๋อๅอࠩᴪ")
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡥࡌࡊࡘࡈࡣࠬᴫ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			try: EEMpr2e8JS.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᴬ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴭ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᴮ"),FKe1TxU27G4SPo8hDER)
			try: EEMpr2e8JS.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,l7kBpMw5Qn(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᴯ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴰ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,wPnfgxKZdAv6T10(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᴱ"),FKe1TxU27G4SPo8hDER)
			try: EEMpr2e8JS.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,HADrRCz9QgU4xudPJIqYb70(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᴲ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+iDhLkZS6XBagNCQfs9tq2(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴳ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,VOALf8iYEnMdK0g(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᴴ"),FKe1TxU27G4SPo8hDER)
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡡ࡙ࡓࡉࡥࠧᴵ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			try: EEMpr2e8JS.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᴶ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+HADrRCz9QgU4xudPJIqYb70(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴷ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᴸ"),FKe1TxU27G4SPo8hDER)
			try: EEMpr2e8JS.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᴹ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴺ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬᴻ"),FKe1TxU27G4SPo8hDER)
		lfZmugQCFKLGT05AH29IsMiho = qFsuKN7ngp.menuItemsLIST
		if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᴼ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪᴽ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,lfZmugQCFKLGT05AH29IsMiho,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt
	return lfZmugQCFKLGT05AH29IsMiho
def jh0MuVYlXsbUztTCRG(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH):
	AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
	mBPv6wX4Tt = qFsuKN7ngp.menuItemsLIST
	qFsuKN7ngp.menuItemsLIST[:] = []
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 and Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᴾ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
		lfZmugQCFKLGT05AH29IsMiho = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,ASkvf27etUK0(u"ࠫࡱ࡯ࡳࡵࠩᴿ"),iDhLkZS6XBagNCQfs9tq2(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᵀ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᵁ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q)
	elif DQIrVcKuY6bJv(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᵂ") not in V7o8RyDJNnF50GpbLsPjdUwefH or v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡡ࡙ࡓࡉࡥࠧᵃ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
		import EyOjQWPXlY
		FKe1TxU27G4SPo8hDER = vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦัิษษ่ࠥอไษำ้ห๊าࠧᵄ")
		if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡣࡑࡏࡖࡆࡡࠪᵅ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			try: EyOjQWPXlY.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᵆ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+gCkRKGhwcx26v(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵇ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᵈ"),FKe1TxU27G4SPo8hDER)
			try: EyOjQWPXlY.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᵉ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+VOALf8iYEnMdK0g(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵊ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᵋ"),FKe1TxU27G4SPo8hDER)
			try: EyOjQWPXlY.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,AGlW9LqKN3Dvo(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᵌ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+bcNqYtfET5l92dLGjyZSPe(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵍ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᵎ"),FKe1TxU27G4SPo8hDER)
		if HCiWF4jV1Q8(u"࠭࡟ࡗࡑࡇࡣࠬᵏ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			try: EyOjQWPXlY.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᵐ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+C3w6qluao7EzUxJgMGBtV(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵑ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᵒ"),FKe1TxU27G4SPo8hDER)
			try: EyOjQWPXlY.r80WK6hJtdjaqwM(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,DQIrVcKuY6bJv(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᵓ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,V7o8RyDJNnF50GpbLsPjdUwefH+l7kBpMw5Qn(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵔ"),mrhSYXH2P8bO3eJAa9n)
			except: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩᵕ"),FKe1TxU27G4SPo8hDER)
		lfZmugQCFKLGT05AH29IsMiho = qFsuKN7ngp.menuItemsLIST
		if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,HCiWF4jV1Q8(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᵖ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧᵗ")+yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,lfZmugQCFKLGT05AH29IsMiho,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt
	return lfZmugQCFKLGT05AH29IsMiho
def HyW2UGYTFSO51NvwBALjl(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH,lVRitp5hnJgwbNEk):
	ko5ymgwaUtVilrPc3jpWhKJ(BdrZqlitGvEM,BdrZqlitGvEM,QxUz8vH0AsPG3OgF)
	if lVRitp5hnJgwbNEk: tS7CBRdygrhzEPL1pXuOx6(mrhSYXH2P8bO3eJAa9n)
	elif Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᵘ") in V7o8RyDJNnF50GpbLsPjdUwefH and not lVRitp5hnJgwbNEk: tS7CBRdygrhzEPL1pXuOx6(BBX9RAuxnyGZ4WIF2TrhYeom3)
	i1Bl7oO9gDFKp = V7o8RyDJNnF50GpbLsPjdUwefH.replace(wPnfgxKZdAv6T10(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᵙ"),SebHIf2jL1TBgrMKJu).replace(gCkRKGhwcx26v(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵚ"),SebHIf2jL1TBgrMKJu).replace(zpx2fPNKk6Ms38eD1vcO(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵛ"),SebHIf2jL1TBgrMKJu)
	if not lVRitp5hnJgwbNEk:
		QUzFYoapm9jx(sTGtHVyhQ9cJU37zxo2O(u"ࠬࡲࡩ࡯࡭ࠪᵜ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭สฮัํฯ่ࠥวว็ฬࠤฬ๊รใีส้ࠬᵝ"),SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"࠼࠼࠳Ỗ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᵞ")+i1Bl7oO9gDFKp,SebHIf2jL1TBgrMKJu,{iDhLkZS6XBagNCQfs9tq2(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵟ"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
		QUzFYoapm9jx(iDhLkZS6XBagNCQfs9tq2(u"ࠩ࡯࡭ࡳࡱࠧᵠ"),E7r8hUCVvTiFQW0dBGXjxcy+C3w6qluao7EzUxJgMGBtV(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᵡ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"࠿࠹࠺࠻ỗ"))
		yLTJ2AUPMDwXc = [vMhFypGLHZJbdX4O7oc3W8x(u"ࠫศ็ไศ็ࠪᵢ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"๋ࠬำๅี็หฯ࠭ᵣ"),fp6KV7DlS8QYniUczHdmZChL(u"࠭ๅิำะ๎ฬะࠧᵤ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧษำส้ั࠭ᵥ"),wPnfgxKZdAv6T10(u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧᵦ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩิ้฻อๆࠨᵧ"),czvu7VQCZodkMf(u"ࠪวาีห࠮ลัีࠬᵨ"),zpx2fPNKk6Ms38eD1vcO(u"ุ๊ࠫวิๆࠪᵩ"),Gykx0wL3XrlWaujsqKP9n2Q(u"๋่ࠬิ์ๅํࠬᵪ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭รี้ิ࠱ศ้หาࠩᵫ"),HADrRCz9QgU4xudPJIqYb70(u"ࠧศๆล๊ࠬᵬ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨุะ็ࠬᵭ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩิ๎ฬ฼ษࠨᵮ"),sTGtHVyhQ9cJU37zxo2O(u"๊ࠪ๏ะแๅๅึࠫᵯ"),Izy1PvclrYx4eSVWn0L5phZbq(u"๊๋ࠫหๅ์้ࠫᵰ"),iDhLkZS6XBagNCQfs9tq2(u"ࠬฮหࠡฯํࠫᵱ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ฯ๋่ํอࠬᵲ"),l7kBpMw5Qn(u"ࠧิ่๋หฯ࠭ᵳ"),czvu7VQCZodkMf(u"ࠨลัี๎࠭ᵴ")]
		lVRitp5hnJgwbNEk = wvkDqmNZlJU52isXo
		for RuvkhqltKIwF8z2 in yLTJ2AUPMDwXc:
			lVRitp5hnJgwbNEk += nyUIsfd53EGot9vbj0XDeq
			QUzFYoapm9jx(DQIrVcKuY6bJv(u"ࠩࡩࡳࡱࡪࡥࡳࠩᵵ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+RuvkhqltKIwF8z2,SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"࠷࠷࠵Ộ"),SebHIf2jL1TBgrMKJu,str(lVRitp5hnJgwbNEk),i1Bl7oO9gDFKp,SebHIf2jL1TBgrMKJu,{uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵶ"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
	else:
		Lrvxcz7y2ldkUP58FsnqwWAQCBtS = [zpx2fPNKk6Ms38eD1vcO(u"ࠫฬ็ไศ็ࠪᵷ"),C3w6qluao7EzUxJgMGBtV(u"ࠬࡳ࡯ࡷ࡫ࡨࠫᵸ"),gCkRKGhwcx26v(u"࠭แ๋ๆ่ࠫᵹ"),HCiWF4jV1Q8(u"ࠧโๆ่ࠫᵺ")]
		CsVyWa8pw0oiQ79zEl = [Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ็ึุ่๊ࠧᵻ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡶࡩࡷ࡯ࡥࡴࠩᵼ")]
		tDwK8ZIX1djM9J76P = [iDhLkZS6XBagNCQfs9tq2(u"ุ้ࠪอัฮࠩᵽ"),C3w6qluao7EzUxJgMGBtV(u"ู๊ࠫัฮ์สฮࠬᵾ")]
		WVHakgMLs5P3q0z = [vMhFypGLHZJbdX4O7oc3W8x(u"ࠬฮัศ็ฯࠫᵿ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡳࡩࡱࡺࠫᶀ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧหๆไึ๏๎ๆࠨᶁ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨฬ็๎ๆุ๊้่ࠪᶂ")]
		gB91pHSZRriowyaskmd78YM = [Ns6AJKH7DGpr19Wl5C3nF(u"ࠩส๊๊๐ࠧᶃ"),TVnqDYzWoM2UfHp0dchJ(u"ࠪ็ึะ่็ࠩᶄ"),ALwOspNtXxZrz3PEKku(u"่ࠫอัห๊้ࠫᶅ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡱࡩࡥࡵࠪᶆ"),ASkvf27etUK0(u"࠭ืโๆࠪᶇ"),DQIrVcKuY6bJv(u"ࠧศูไห้࠭ᶈ")]
		DMRrsW5XoALhmCbJIcQn0ewa9 = [ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨำฺ่ฬ์ࠧᶉ")]
		K6W3ZDiCchTvt48oVF9re = [TVnqDYzWoM2UfHp0dchJ(u"ࠩสัิัࠧᶊ"),TVnqDYzWoM2UfHp0dchJ(u"ࠪหำืࠧᶋ"),AGlW9LqKN3Dvo(u"๊ࠫ๎ฮาࠩᶌ"),ALwOspNtXxZrz3PEKku(u"ࠬาฯ๋ัࠪᶍ"),wPnfgxKZdAv6T10(u"࠭ๅืษไࠫᶎ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧฮัํฯࠬᶏ")]
		CCEvYSfw02gR = [vMhFypGLHZJbdX4O7oc3W8x(u"ࠨี็หุ๊ࠧᶐ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩึุ่๊็ࠨᶑ")]
		vpAuGJdYq0w1xnmKOQrB3ybF4zLUeh = [C3w6qluao7EzUxJgMGBtV(u"ࠪห฿อๆ๋ࠩᶒ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"๊ࠫ๎ำ๋ไ์ࠫᶓ"),DQIrVcKuY6bJv(u"้ࠬไ๋สࠪᶔ"),VOALf8iYEnMdK0g(u"࠭อโๆࠪᶕ"),ASkvf27etUK0(u"ࠧ࡮ࡷࡶ࡭ࡨ࠭ᶖ")]
		TctFVarD0UpL7SwJ9nbZH1euBGv2zP = [ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨษๆฯึ࠭ᶗ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩสุ์ืࠧᶘ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"้๊ࠪ๐า่ࠩᶙ"),gCkRKGhwcx26v(u"ࠫฬ฿ไ๊ࠩᶚ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"๋ࠬฮหษิ๋ࠬᶛ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ๅฯฬสีฬะࠧᶜ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠧศไ๋ํࠬᶝ")]
		QVslKq4W1LEtevH8bZg905mzUC2u = [HADrRCz9QgU4xudPJIqYb70(u"ࠨษ็ห๋࠭ᶞ"),sTGtHVyhQ9cJU37zxo2O(u"ࠩะห้๐ࠧᶟ"),ASkvf27etUK0(u"้ࠪะฮสࠨᶠ"),l7kBpMw5Qn(u"ࠫึอฦอࠩᶡ")]
		q2kN8UuWZrytC5z = [t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ฼อไࠩᶢ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ใ้็ํำ๏࠭ᶣ")]
		V3VoMSu8ONt5w = [C3w6qluao7EzUxJgMGBtV(u"ࠧา์สฺ์࠭ᶤ"),ALwOspNtXxZrz3PEKku(u"ࠨๅ๋ี์࠭ᶥ"),zpx2fPNKk6Ms38eD1vcO(u"ู่ࠩฬืู่ࠩᶦ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ุࠪํะࠧᶧ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠫึ๐วืหࠪᶨ")]
		HPnyl5mwU2J1tMuEGW4gf7 = [C3w6qluao7EzUxJgMGBtV(u"ࠬ์๊หใ็็ุ࠭ᶩ"),sTGtHVyhQ9cJU37zxo2O(u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧᶪ"),ASkvf27etUK0(u"ࠧ็์อๅ้๐ใิࠩᶫ")]
		JF5xabfXrA6ldqPH9R = [l7kBpMw5Qn(u"ࠨ็่ฯ้๐ๆࠨᶬ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩสุำอีࠨᶭ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"๊ࠪั๎ๅࠨᶮ")]
		PZbvLVAspF6rS1xhkm8W = [ALwOspNtXxZrz3PEKku(u"ࠫอัࠠฮ์ࠪᶯ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡲࡩࡷࡧࠪᶰ"),Ns6AJKH7DGpr19Wl5C3nF(u"࠭โ็ษ๊ࠫᶱ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧใ่๋หฯ࠭ᶲ")]
		kkFv7HcTGVuqp8yWPjL1Uz23XI = [v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨัํ๊ࠬᶳ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠩสำ฾๐็ࠨᶴ"),ASkvf27etUK0(u"ࠪึ๏อัศฬࠪᶵ"),C3w6qluao7EzUxJgMGBtV(u"้ࠫ฽ๅ๋ษอࠫᶶ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬีูศรࠪᶷ"),wPnfgxKZdAv6T10(u"࠭โาษ้ࠫᶸ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧใืสสิ࠭ᶹ"),AGlW9LqKN3Dvo(u"ࠨำฮหฦ࠭ᶺ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"่ࠩีั฿๊่ࠩᶻ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪหีอๆࠨᶼ"),bcNqYtfET5l92dLGjyZSPe(u"ࠫฬูไศ็ࠪᶽ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬะ่ศึํัࠬᶾ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ฮุสࠪᶿ"),l7kBpMw5Qn(u"ࠧฮ๊ี์๏࠭᷀"),czvu7VQCZodkMf(u"ࠨ฻อฬฬะࠧ᷁"),vMhFypGLHZJbdX4O7oc3W8x(u"่ࠩ์ฬ๊๊ะ᷂ࠩ"),C3w6qluao7EzUxJgMGBtV(u"๊ࠪํอู๋ࠩ᷃"),AGlW9LqKN3Dvo(u"ࠫ฾่ววัࠪ᷄"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬอๆศึํำࠬ᷅")]
		yHR8QYPdE3zuGqrkbUXWC = [j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࠲࠱࠳࠳ࠫ᷆"),HCiWF4jV1Q8(u"ࠧ࠳࠲࠴࠵ࠬ᷇"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨ࠴࠳࠵࠷࠭᷈"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࠵࠴࠶࠹ࠧ᷉"),TVnqDYzWoM2UfHp0dchJ(u"ࠪ࠶࠵࠷࠴ࠨ᷊"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࠷࠶࠱࠶ࠩ᷋"),gCkRKGhwcx26v(u"ࠬ࠸࠰࠲࠸ࠪ᷌"),czvu7VQCZodkMf(u"࠭࠲࠱࠳࠺ࠫ᷍"),l7kBpMw5Qn(u"ࠧ࠳࠲࠴࠼᷎ࠬ"),ASkvf27etUK0(u"ࠨ࠴࠳࠵࠾᷏࠭"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠩ࠵࠴࠷࠶᷐ࠧ"),bcNqYtfET5l92dLGjyZSPe(u"ࠪ࠶࠵࠸࠱ࠨ᷑"),AGlW9LqKN3Dvo(u"ࠫ࠷࠶࠲࠳ࠩ᷒"),C3w6qluao7EzUxJgMGBtV(u"ࠬ࠸࠰࠳࠵ࠪᷓ"),TVnqDYzWoM2UfHp0dchJ(u"࠭࠲࠱࠴࠷ࠫᷔ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧ࠳࠲࠵࠹ࠬᷕ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨ࠴࠳࠶࠻࠭ᷖ"),bcNqYtfET5l92dLGjyZSPe(u"ࠩ࠵࠴࠷࠽ࠧᷗ"),czvu7VQCZodkMf(u"ࠪ࠶࠵࠸࠸ࠨᷘ")]
		for xzpZLdkW2Ol in sorted(list(E2Et4cHoxzqKU89pDvwjn.keys())):
			dxwMtG2cpSBbCVe6HqIfDZn = xzpZLdkW2Ol.lower()
			kgy9Zm5TCvYHjE3PVQ = []
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in Lrvxcz7y2ldkUP58FsnqwWAQCBtS): kgy9Zm5TCvYHjE3PVQ.append(nyUIsfd53EGot9vbj0XDeq)
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in CsVyWa8pw0oiQ79zEl): kgy9Zm5TCvYHjE3PVQ.append(JhTts2R43AxkM8bYanKVy)
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in tDwK8ZIX1djM9J76P): kgy9Zm5TCvYHjE3PVQ.append(fuCbjVag7vU908J2Yqx5Th)
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in WVHakgMLs5P3q0z): kgy9Zm5TCvYHjE3PVQ.append(K7cnfQMS6BPvI4LGmCsRp8bUlJ9)
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in gB91pHSZRriowyaskmd78YM): kgy9Zm5TCvYHjE3PVQ.append(vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs)
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in DMRrsW5XoALhmCbJIcQn0ewa9): kgy9Zm5TCvYHjE3PVQ.append(fp6KV7DlS8QYniUczHdmZChL(u"࠷ộ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in K6W3ZDiCchTvt48oVF9re) and dxwMtG2cpSBbCVe6HqIfDZn not in [qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫฬิั๊ࠩᷙ")]: kgy9Zm5TCvYHjE3PVQ.append(TVnqDYzWoM2UfHp0dchJ(u"࠹Ớ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in CCEvYSfw02gR): kgy9Zm5TCvYHjE3PVQ.append(vMhFypGLHZJbdX4O7oc3W8x(u"࠻ớ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in vpAuGJdYq0w1xnmKOQrB3ybF4zLUeh): kgy9Zm5TCvYHjE3PVQ.append(czvu7VQCZodkMf(u"࠽Ờ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in TctFVarD0UpL7SwJ9nbZH1euBGv2zP): kgy9Zm5TCvYHjE3PVQ.append(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠶࠶ờ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in QVslKq4W1LEtevH8bZg905mzUC2u): kgy9Zm5TCvYHjE3PVQ.append(VOALf8iYEnMdK0g(u"࠷࠱Ở"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in q2kN8UuWZrytC5z): kgy9Zm5TCvYHjE3PVQ.append(AGlW9LqKN3Dvo(u"࠱࠳ở"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in V3VoMSu8ONt5w): kgy9Zm5TCvYHjE3PVQ.append(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠲࠵Ỡ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in HPnyl5mwU2J1tMuEGW4gf7): kgy9Zm5TCvYHjE3PVQ.append(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠳࠷ỡ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in JF5xabfXrA6ldqPH9R): kgy9Zm5TCvYHjE3PVQ.append(Gykx0wL3XrlWaujsqKP9n2Q(u"࠴࠹Ợ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in PZbvLVAspF6rS1xhkm8W): kgy9Zm5TCvYHjE3PVQ.append(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠵࠻ợ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in kkFv7HcTGVuqp8yWPjL1Uz23XI): kgy9Zm5TCvYHjE3PVQ.append(bcNqYtfET5l92dLGjyZSPe(u"࠶࠽Ụ"))
			if any(value in dxwMtG2cpSBbCVe6HqIfDZn for value in yHR8QYPdE3zuGqrkbUXWC): kgy9Zm5TCvYHjE3PVQ.append(vMhFypGLHZJbdX4O7oc3W8x(u"࠷࠸ụ"))
			if not kgy9Zm5TCvYHjE3PVQ: kgy9Zm5TCvYHjE3PVQ = [qeYIw0BNTL9bGJnosacQ1DtVR(u"࠱࠺Ủ")]
			for EdOlIXrDZmMhVRJe8W0Fnap in kgy9Zm5TCvYHjE3PVQ:
				if str(EdOlIXrDZmMhVRJe8W0Fnap)==lVRitp5hnJgwbNEk:
					QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷚ"),FFe0IfYj65szqgLHkNpBPJnRQEmZo+xzpZLdkW2Ol,xzpZLdkW2Ol,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠲࠸࠹ủ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,i1Bl7oO9gDFKp+tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷛ"))
	ko5ymgwaUtVilrPc3jpWhKJ(BdrZqlitGvEM,BdrZqlitGvEM,cXPe6vn1aUtFzH79WEwVmCBO0db)
	return
def xoZmMRPbpiNKH7zFXsGWC(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH):
	AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7:
		QUzFYoapm9jx(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧ࡭࡫ࡱ࡯ࠬᷜ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡏࡐࡕࡘࠪᷝ"),SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠹࠹࠸Ứ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,l7kBpMw5Qn(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᷞ"),SebHIf2jL1TBgrMKJu,{HCiWF4jV1Q8(u"ࠪࡪࡴࡲࡤࡦࡴࠪᷟ"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
		QUzFYoapm9jx(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡱ࡯࡮࡬ࠩᷠ"),E7r8hUCVvTiFQW0dBGXjxcy+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᷡ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"࠼࠽࠾࠿ứ"))
	mBPv6wX4Tt = qFsuKN7ngp.menuItemsLIST[:]
	import EEMpr2e8JS
	if yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q:
		if not EEMpr2e8JS.dd30zMZ2hmuvQb96irALtl(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		rN634aJ2Tv5DsgSMhyEF0I8b = cfbQZ4eOxy7Kg2aVCq(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH)
		NNR4sgnwr2H = sorted(rN634aJ2Tv5DsgSMhyEF0I8b,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq].lower())
	else:
		if not EEMpr2e8JS.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 and HADrRCz9QgU4xudPJIqYb70(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᷢ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			NNR4sgnwr2H = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,zpx2fPNKk6Ms38eD1vcO(u"ࠧ࡭࡫ࡶࡸࠬᷣ"),l7kBpMw5Qn(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᷤ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭ᷥ"))
		else:
			pjrA26XocVFu8,NNR4sgnwr2H,rN634aJ2Tv5DsgSMhyEF0I8b = [],[],[]
			for nRH8oOyGBXp637Ss9DTINaheqjW2lU in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
				NNR4sgnwr2H += cfbQZ4eOxy7Kg2aVCq(str(nRH8oOyGBXp637Ss9DTINaheqjW2lU),V7o8RyDJNnF50GpbLsPjdUwefH)
			for type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in NNR4sgnwr2H:
				if Yg36raSGA02uUXEPMF7itZd9KcWf not in pjrA26XocVFu8:
					pjrA26XocVFu8.append(Yg36raSGA02uUXEPMF7itZd9KcWf)
					ffmwgMkzGhURJT = type,xzpZLdkW2Ol,Yg36raSGA02uUXEPMF7itZd9KcWf,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠵࠻࠻Ừ"),i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,V7o8RyDJNnF50GpbLsPjdUwefH,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM
					rN634aJ2Tv5DsgSMhyEF0I8b.append(ffmwgMkzGhURJT)
			NNR4sgnwr2H = sorted(rN634aJ2Tv5DsgSMhyEF0I8b,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq].lower())
			if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,ALwOspNtXxZrz3PEKku(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᷦ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᷧ"),NNR4sgnwr2H,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H
	GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def SPN2KynQpc(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH):
	AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7:
		QUzFYoapm9jx(VOALf8iYEnMdK0g(u"ࠬࡲࡩ࡯࡭ࠪᷨ"),HADrRCz9QgU4xudPJIqYb70(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡑ࠸࡛ࠧᷩ"),SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"࠼࠼࠵ừ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,HADrRCz9QgU4xudPJIqYb70(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᷪ"),SebHIf2jL1TBgrMKJu,{wPnfgxKZdAv6T10(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᷫ"):yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q})
		QUzFYoapm9jx(zpx2fPNKk6Ms38eD1vcO(u"ࠩ࡯࡭ࡳࡱࠧᷬ"),E7r8hUCVvTiFQW0dBGXjxcy+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᷭ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"࠿࠹࠺࠻Ử"))
	mBPv6wX4Tt = qFsuKN7ngp.menuItemsLIST[:]
	import EyOjQWPXlY
	if yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q:
		if not EyOjQWPXlY.dd30zMZ2hmuvQb96irALtl(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		rN634aJ2Tv5DsgSMhyEF0I8b = jh0MuVYlXsbUztTCRG(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q,V7o8RyDJNnF50GpbLsPjdUwefH)
		NNR4sgnwr2H = sorted(rN634aJ2Tv5DsgSMhyEF0I8b,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq].lower())
	else:
		if not EyOjQWPXlY.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 and DQIrVcKuY6bJv(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᷮ") not in V7o8RyDJNnF50GpbLsPjdUwefH:
			NNR4sgnwr2H = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡲࡩࡴࡶࠪᷯ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᷰ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᷱ"))
		else:
			pjrA26XocVFu8,NNR4sgnwr2H,rN634aJ2Tv5DsgSMhyEF0I8b = [],[],[]
			for nRH8oOyGBXp637Ss9DTINaheqjW2lU in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
				NNR4sgnwr2H += jh0MuVYlXsbUztTCRG(str(nRH8oOyGBXp637Ss9DTINaheqjW2lU),V7o8RyDJNnF50GpbLsPjdUwefH)
			for type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in NNR4sgnwr2H:
				if Yg36raSGA02uUXEPMF7itZd9KcWf not in pjrA26XocVFu8:
					pjrA26XocVFu8.append(Yg36raSGA02uUXEPMF7itZd9KcWf)
					ffmwgMkzGhURJT = type,xzpZLdkW2Ol,Yg36raSGA02uUXEPMF7itZd9KcWf,sTGtHVyhQ9cJU37zxo2O(u"࠱࠷࠷ử"),i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,V7o8RyDJNnF50GpbLsPjdUwefH,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM
					rN634aJ2Tv5DsgSMhyEF0I8b.append(ffmwgMkzGhURJT)
			NNR4sgnwr2H = sorted(rN634aJ2Tv5DsgSMhyEF0I8b,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq].lower())
			if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,zpx2fPNKk6Ms38eD1vcO(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᷲ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᷳ"),NNR4sgnwr2H,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H
	GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def lca0SEUG9MOZvIrd4bAoJLfzkejxm(group,V7o8RyDJNnF50GpbLsPjdUwefH):
	AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
	lfZmugQCFKLGT05AH29IsMiho = []
	RoHsPmqjypLx5UTAvbI = l7kBpMw5Qn(u"ࠪࡣࡎࡖࡔࡗࡡࠪᷴ") if l7kBpMw5Qn(u"ࠫࡎࡖࡔࡗࠩ᷵") in V7o8RyDJNnF50GpbLsPjdUwefH else DQIrVcKuY6bJv(u"ࠬࡥࡍ࠴ࡗࡢࠫ᷶")
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: lfZmugQCFKLGT05AH29IsMiho = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭࡬ࡪࡵࡷ᷷ࠫ"),zpx2fPNKk6Ms38eD1vcO(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔ᷸ࠩ")+RoHsPmqjypLx5UTAvbI[:-nyUIsfd53EGot9vbj0XDeq],group)
	if not lfZmugQCFKLGT05AH29IsMiho:
		for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
			if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: lfZmugQCFKLGT05AH29IsMiho += xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,DQIrVcKuY6bJv(u"ࠨ࡮࡬ࡷࡹ᷹࠭"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖ᷺ࠫ")+RoHsPmqjypLx5UTAvbI[:-nyUIsfd53EGot9vbj0XDeq],VOALf8iYEnMdK0g(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ᷻")+RoHsPmqjypLx5UTAvbI+str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q))
			elif RoHsPmqjypLx5UTAvbI==iDhLkZS6XBagNCQfs9tq2(u"ࠫࡤࡏࡐࡕࡘࡢࠫ᷼"): lfZmugQCFKLGT05AH29IsMiho += cfbQZ4eOxy7Kg2aVCq(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),C3w6qluao7EzUxJgMGBtV(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡ᷽ࠪ"))
			elif RoHsPmqjypLx5UTAvbI==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭࡟ࡎ࠵ࡘࡣࠬ᷾"): lfZmugQCFKLGT05AH29IsMiho += jh0MuVYlXsbUztTCRG(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣ᷿ࠬ"))
		for type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in lfZmugQCFKLGT05AH29IsMiho:
			if Yg36raSGA02uUXEPMF7itZd9KcWf==group: GkAg0ZqR2cnPW9wvUtfj(type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
		items,IkJNp71Hyu0PwFAXMTsOc = [],[]
		for type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in qFsuKN7ngp.menuItemsLIST:
			d1xDpeFH4VuNB7W60O = type,xzpZLdkW2Ol[K7cnfQMS6BPvI4LGmCsRp8bUlJ9:],url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,SebHIf2jL1TBgrMKJu
			if d1xDpeFH4VuNB7W60O not in IkJNp71Hyu0PwFAXMTsOc:
				IkJNp71Hyu0PwFAXMTsOc.append(d1xDpeFH4VuNB7W60O)
				JJSOAkTZIib4eswDo51pFuqvK = type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM
				items.append(JJSOAkTZIib4eswDo51pFuqvK)
		lfZmugQCFKLGT05AH29IsMiho = sorted(items,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq].lower()[fp6KV7DlS8QYniUczHdmZChL(u"࠶Ữ"):])
		if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪḀ")+RoHsPmqjypLx5UTAvbI[:-nyUIsfd53EGot9vbj0XDeq],group,lfZmugQCFKLGT05AH29IsMiho,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	if tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫḁ") in V7o8RyDJNnF50GpbLsPjdUwefH and len(lfZmugQCFKLGT05AH29IsMiho)>zYEXxHIZtvkcBON14A:
		qFsuKN7ngp.menuItemsLIST[:] = []
		QUzFYoapm9jx(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡪࡴࡲࡤࡦࡴࠪḂ"),ASkvf27etUK0(u"ࠫࡠ࠭ḃ")+E7r8hUCVvTiFQW0dBGXjxcy+group+XOVRfitWJP1zL3p2CMYF+czvu7VQCZodkMf(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧḄ"),group,l7kBpMw5Qn(u"࠳࠹࠹ữ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,RoHsPmqjypLx5UTAvbI+uqLUBHepfM3l6AyIzTJh80a(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḅ"))
		QUzFYoapm9jx(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḆ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧḇ"),group,vMhFypGLHZJbdX4O7oc3W8x(u"࠴࠺࠺Ự"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,RoHsPmqjypLx5UTAvbI+Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḈ"))
		QUzFYoapm9jx(AGlW9LqKN3Dvo(u"ࠪࡰ࡮ࡴ࡫ࠨḉ"),E7r8hUCVvTiFQW0dBGXjxcy+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩḊ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,iDhLkZS6XBagNCQfs9tq2(u"࠽࠾࠿࠹ự"))
		lfZmugQCFKLGT05AH29IsMiho = qFsuKN7ngp.menuItemsLIST+JO7n9zxwdgIStrTjR.sample(lfZmugQCFKLGT05AH29IsMiho,zYEXxHIZtvkcBON14A)
	qFsuKN7ngp.menuItemsLIST[:] = lfZmugQCFKLGT05AH29IsMiho
	GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def e5Hfy1rMLi6AZETzhcmgQV23IpjqNS(V7o8RyDJNnF50GpbLsPjdUwefH):
	QUzFYoapm9jx(czvu7VQCZodkMf(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḋ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩḌ"),SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠶࠼࠱Ỳ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧḍ"))
	QUzFYoapm9jx(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࡮࡬ࡲࡰ࠭Ḏ"),E7r8hUCVvTiFQW0dBGXjxcy+TVnqDYzWoM2UfHp0dchJ(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḏ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"࠿࠹࠺࠻ỳ"))
	Y7vr01NAnCXbM3IRkDqEcB = qFsuKN7ngp.menuItemsLIST[:]
	qFsuKN7ngp.menuItemsLIST[:] = []
	import P460HkVtCB
	P460HkVtCB.JJeq4MVI8NtCWkaOiQLTybrzUx(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪ࠴ࠬḐ"),mrhSYXH2P8bO3eJAa9n)
	P460HkVtCB.JJeq4MVI8NtCWkaOiQLTybrzUx(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࠶࠭ḑ"),mrhSYXH2P8bO3eJAa9n)
	P460HkVtCB.JJeq4MVI8NtCWkaOiQLTybrzUx(sTGtHVyhQ9cJU37zxo2O(u"ࠬ࠸ࠧḒ"),mrhSYXH2P8bO3eJAa9n)
	if xxRyYsrSCzjifvH4cIqgldeOo(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨḓ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		qFsuKN7ngp.menuItemsLIST[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
		if len(qFsuKN7ngp.menuItemsLIST)>zYEXxHIZtvkcBON14A: qFsuKN7ngp.menuItemsLIST[:] = JO7n9zxwdgIStrTjR.sample(qFsuKN7ngp.menuItemsLIST,zYEXxHIZtvkcBON14A)
	qFsuKN7ngp.menuItemsLIST[:] = Y7vr01NAnCXbM3IRkDqEcB+qFsuKN7ngp.menuItemsLIST
	return
def TvmC1xz0o8N(V7o8RyDJNnF50GpbLsPjdUwefH):
	V7o8RyDJNnF50GpbLsPjdUwefH = V7o8RyDJNnF50GpbLsPjdUwefH.replace(czvu7VQCZodkMf(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḔ"),SebHIf2jL1TBgrMKJu).replace(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḕ"),SebHIf2jL1TBgrMKJu)
	headers = { fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ḗ") : SebHIf2jL1TBgrMKJu }
	url = Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩḗ")
	data = {sTGtHVyhQ9cJU37zxo2O(u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭Ḙ"):cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬ࠻࠰ࠨḙ")}
	data = zzM3SJI56FnHqsRGAXe(data)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(B3vhTYqOtgUCAzPW,sTGtHVyhQ9cJU37zxo2O(u"࠭ࡇࡆࡖࠪḚ"),url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩḛ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall(czvu7VQCZodkMf(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪḜ"),LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
	items = X2XorVqHjLkWeCchY4u9fSz.findall(fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧḝ"),drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	bJuHIpRcxj4GUA,iRUQFINgpwM0xdtbfAqCj2 = list(zip(*items))
	X7N3fvV2iWjQtkRu4lI5yqO = []
	O8T1KDdVHGvkuJ5I = [qE4nB3mKWHs,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࠦࠬḞ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫࡥ࠭ḟ"),VOALf8iYEnMdK0g(u"ࠬ࠲ࠧḠ"),AGlW9LqKN3Dvo(u"࠭࠮ࠨḡ"),ASkvf27etUK0(u"ࠧ࠻ࠩḢ"),C3w6qluao7EzUxJgMGBtV(u"ࠨ࠽ࠪḣ"),sTGtHVyhQ9cJU37zxo2O(u"ࠤࠪࠦḤ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ࠱ࠬḥ")]
	wf1M5VKrZBPFONemQaJicxLbE2vs34 = iRUQFINgpwM0xdtbfAqCj2+bJuHIpRcxj4GUA
	for dd0cX6fx3L58 in wf1M5VKrZBPFONemQaJicxLbE2vs34:
		if dd0cX6fx3L58 in iRUQFINgpwM0xdtbfAqCj2: bbHjloaTVEJPdfpr9zSv7WZN = JhTts2R43AxkM8bYanKVy
		if dd0cX6fx3L58 in bJuHIpRcxj4GUA: bbHjloaTVEJPdfpr9zSv7WZN = K7cnfQMS6BPvI4LGmCsRp8bUlJ9
		yYnUhLG7CXbKMcVmzxN0RD = [YHnALfql8hprDu in dd0cX6fx3L58 for YHnALfql8hprDu in O8T1KDdVHGvkuJ5I]
		if any(yYnUhLG7CXbKMcVmzxN0RD):
			ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = yYnUhLG7CXbKMcVmzxN0RD.index(BBX9RAuxnyGZ4WIF2TrhYeom3)
			jWKlEs9XxJoZO8mYzgUM = O8T1KDdVHGvkuJ5I[ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp]
			igDaTG5CNxWvlY61pyuXs = SebHIf2jL1TBgrMKJu
			if dd0cX6fx3L58.count(jWKlEs9XxJoZO8mYzgUM)>nyUIsfd53EGot9vbj0XDeq: oo9UBltQsArSVbROfuDa1Tz,FHcJtE7Kz4oknB1a,igDaTG5CNxWvlY61pyuXs = dd0cX6fx3L58.split(jWKlEs9XxJoZO8mYzgUM,JhTts2R43AxkM8bYanKVy)
			else: oo9UBltQsArSVbROfuDa1Tz,FHcJtE7Kz4oknB1a = dd0cX6fx3L58.split(jWKlEs9XxJoZO8mYzgUM,nyUIsfd53EGot9vbj0XDeq)
			if len(oo9UBltQsArSVbROfuDa1Tz)>bbHjloaTVEJPdfpr9zSv7WZN: X7N3fvV2iWjQtkRu4lI5yqO.append(oo9UBltQsArSVbROfuDa1Tz.lower())
			if len(FHcJtE7Kz4oknB1a)>bbHjloaTVEJPdfpr9zSv7WZN: X7N3fvV2iWjQtkRu4lI5yqO.append(FHcJtE7Kz4oknB1a.lower())
			if len(igDaTG5CNxWvlY61pyuXs)>bbHjloaTVEJPdfpr9zSv7WZN: X7N3fvV2iWjQtkRu4lI5yqO.append(igDaTG5CNxWvlY61pyuXs.lower())
		elif len(dd0cX6fx3L58)>bbHjloaTVEJPdfpr9zSv7WZN: X7N3fvV2iWjQtkRu4lI5yqO.append(dd0cX6fx3L58.lower())
	for YHnALfql8hprDu in range(C3w6qluao7EzUxJgMGBtV(u"࠹Ỵ")): JO7n9zxwdgIStrTjR.shuffle(X7N3fvV2iWjQtkRu4lI5yqO)
	if bcNqYtfET5l92dLGjyZSPe(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬḦ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		zX6ibgOpKdjP3H9N = ehtRkZ2gDKFELmIuOaA
	elif vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬḧ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		zX6ibgOpKdjP3H9N = [Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡉࡑࡖ࡙ࠫḨ")]
		import EEMpr2e8JS
		if not EEMpr2e8JS.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
	elif wPnfgxKZdAv6T10(u"ࠧࡠࡏ࠶࡙ࡤ࠭ḩ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		zX6ibgOpKdjP3H9N = [AGlW9LqKN3Dvo(u"ࠨࡏ࠶࡙ࠬḪ")]
		import EyOjQWPXlY
		if not EyOjQWPXlY.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
	count,J7TrH6yM4qkbfU = wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
	QUzFYoapm9jx(ALwOspNtXxZrz3PEKku(u"ࠩࡩࡳࡱࡪࡥࡳࠩḫ"),l7kBpMw5Qn(u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫḬ"),SebHIf2jL1TBgrMKJu,l7kBpMw5Qn(u"࠲࠸࠷ỵ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḭ")+V7o8RyDJNnF50GpbLsPjdUwefH)
	QUzFYoapm9jx(wPnfgxKZdAv6T10(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḮ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭ḯ"),SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"࠳࠹࠸Ỷ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḰ")+V7o8RyDJNnF50GpbLsPjdUwefH)
	QUzFYoapm9jx(HADrRCz9QgU4xudPJIqYb70(u"ࠨ࡮࡬ࡲࡰ࠭ḱ"),E7r8hUCVvTiFQW0dBGXjxcy+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḲ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"࠼࠽࠾࠿ỷ"))
	afXplzCSjo3q = qFsuKN7ngp.menuItemsLIST[:]
	qFsuKN7ngp.menuItemsLIST[:] = []
	RRcIH1dbfJArZjqv = []
	for dd0cX6fx3L58 in X7N3fvV2iWjQtkRu4lI5yqO:
		FHcJtE7Kz4oknB1a = X2XorVqHjLkWeCchY4u9fSz.findall(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪḳ")+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࠨ࠭Ḵ")+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩḵ"),dd0cX6fx3L58,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if FHcJtE7Kz4oknB1a: dd0cX6fx3L58 = dd0cX6fx3L58.split(FHcJtE7Kz4oknB1a[wvkDqmNZlJU52isXo],nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		IcGEbyk409X = dd0cX6fx3L58.replace(l7kBpMw5Qn(u"࠭๑ࠨḶ"),SebHIf2jL1TBgrMKJu).replace(sTGtHVyhQ9cJU37zxo2O(u"ࠧ๏ࠩḷ"),SebHIf2jL1TBgrMKJu).replace(ASkvf27etUK0(u"ࠨํࠪḸ"),SebHIf2jL1TBgrMKJu).replace(zpx2fPNKk6Ms38eD1vcO(u"ࠩ๒ࠫḹ"),SebHIf2jL1TBgrMKJu).replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠪ๐ࠬḺ"),SebHIf2jL1TBgrMKJu)
		IcGEbyk409X = IcGEbyk409X.replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫ๕࠭ḻ"),SebHIf2jL1TBgrMKJu).replace(TVnqDYzWoM2UfHp0dchJ(u"ࠬ๓ࠧḼ"),SebHIf2jL1TBgrMKJu).replace(Gykx0wL3XrlWaujsqKP9n2Q(u"࠭๒ࠨḽ"),SebHIf2jL1TBgrMKJu).replace(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧญࠩḾ"),SebHIf2jL1TBgrMKJu).replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠨโࠪḿ"),SebHIf2jL1TBgrMKJu)
		if IcGEbyk409X: RRcIH1dbfJArZjqv.append(IcGEbyk409X)
	nAgDeZQbzYVFrL4mIlN2 = []
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(wvkDqmNZlJU52isXo,sTGtHVyhQ9cJU37zxo2O(u"࠶࠵Ỹ")):
		search = JO7n9zxwdgIStrTjR.sample(RRcIH1dbfJArZjqv,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		if search in nAgDeZQbzYVFrL4mIlN2: continue
		nAgDeZQbzYVFrL4mIlN2.append(search)
		GJ4kbYnxcHa6NIOuA7X20S = JO7n9zxwdgIStrTjR.sample(zX6ibgOpKdjP3H9N,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+wPnfgxKZdAv6T10(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬṀ")+str(GJ4kbYnxcHa6NIOuA7X20S)+sTGtHVyhQ9cJU37zxo2O(u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭ṁ")+search)
		o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
		bbdzlgnS4vI7oK8puT3fBeO50(search+zpx2fPNKk6Ms38eD1vcO(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩṂ"))
		if len(qFsuKN7ngp.menuItemsLIST)>wvkDqmNZlJU52isXo: break
	search = search.replace(DQIrVcKuY6bJv(u"ࠬࡥࡍࡐࡆࡢࠫṃ"),SebHIf2jL1TBgrMKJu)
	afXplzCSjo3q[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq] = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࡛࠭ࠨṄ")+E7r8hUCVvTiFQW0dBGXjxcy+search+XOVRfitWJP1zL3p2CMYF+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࠡ࠼หัะูࠦ็࡟ࠪṅ")
	qFsuKN7ngp.menuItemsLIST[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
	if len(qFsuKN7ngp.menuItemsLIST)>zYEXxHIZtvkcBON14A: qFsuKN7ngp.menuItemsLIST[:] = JO7n9zxwdgIStrTjR.sample(qFsuKN7ngp.menuItemsLIST,zYEXxHIZtvkcBON14A)
	qFsuKN7ngp.menuItemsLIST[:] = afXplzCSjo3q+qFsuKN7ngp.menuItemsLIST
	return
def rJsqbOw0DP(qbour1DVTMwvR84yKe0BkXmfjZc,V7o8RyDJNnF50GpbLsPjdUwefH):
	qbour1DVTMwvR84yKe0BkXmfjZc = qbour1DVTMwvR84yKe0BkXmfjZc.replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡡࡐࡓࡉࡥࠧṆ"),SebHIf2jL1TBgrMKJu)
	V7o8RyDJNnF50GpbLsPjdUwefH = V7o8RyDJNnF50GpbLsPjdUwefH.replace(gCkRKGhwcx26v(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṇ"),SebHIf2jL1TBgrMKJu).replace(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṈ"),SebHIf2jL1TBgrMKJu)
	tS7CBRdygrhzEPL1pXuOx6(mrhSYXH2P8bO3eJAa9n)
	if not E2Et4cHoxzqKU89pDvwjn: return
	if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ṉ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		QUzFYoapm9jx(TVnqDYzWoM2UfHp0dchJ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṊ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࡛࠭ࠨṋ")+E7r8hUCVvTiFQW0dBGXjxcy+qbour1DVTMwvR84yKe0BkXmfjZc+XOVRfitWJP1zL3p2CMYF+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩṌ"),qbour1DVTMwvR84yKe0BkXmfjZc,C3w6qluao7EzUxJgMGBtV(u"࠶࠼࠶ỹ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ṍ")+V7o8RyDJNnF50GpbLsPjdUwefH)
		QUzFYoapm9jx(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡩࡳࡱࡪࡥࡳࠩṎ"),C3w6qluao7EzUxJgMGBtV(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩṏ"),qbour1DVTMwvR84yKe0BkXmfjZc,HADrRCz9QgU4xudPJIqYb70(u"࠷࠶࠷Ỻ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṐ")+V7o8RyDJNnF50GpbLsPjdUwefH)
		QUzFYoapm9jx(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡲࡩ࡯࡭ࠪṑ"),E7r8hUCVvTiFQW0dBGXjxcy+ASkvf27etUK0(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫṒ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"࠹࠺࠻࠼ỻ"))
	for website in sorted(list(E2Et4cHoxzqKU89pDvwjn[qbour1DVTMwvR84yKe0BkXmfjZc].keys())):
		type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = E2Et4cHoxzqKU89pDvwjn[qbour1DVTMwvR84yKe0BkXmfjZc][website]
		if Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩṓ") in V7o8RyDJNnF50GpbLsPjdUwefH or len(E2Et4cHoxzqKU89pDvwjn[qbour1DVTMwvR84yKe0BkXmfjZc])==nyUIsfd53EGot9vbj0XDeq:
			GkAg0ZqR2cnPW9wvUtfj(type,SebHIf2jL1TBgrMKJu,url,BEFCHNZ3JTUr4engVIxQo,SebHIf2jL1TBgrMKJu,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)
			qFsuKN7ngp.menuItemsLIST[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
			mBPv6wX4Tt,NNR4sgnwr2H = qFsuKN7ngp.menuItemsLIST[:fuCbjVag7vU908J2Yqx5Th],qFsuKN7ngp.menuItemsLIST[fuCbjVag7vU908J2Yqx5Th:]
			if Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪṔ") in V7o8RyDJNnF50GpbLsPjdUwefH:
				for YHnALfql8hprDu in range(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠺Ỽ")): JO7n9zxwdgIStrTjR.shuffle(NNR4sgnwr2H)
				qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H[:zYEXxHIZtvkcBON14A]
			else: qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H
		elif j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪṕ") in V7o8RyDJNnF50GpbLsPjdUwefH: QUzFYoapm9jx(czvu7VQCZodkMf(u"ࠪࡪࡴࡲࡤࡦࡴࠪṖ"),website,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
	return
def fyn0H5ZT8FMrxcb3sCI(V7o8RyDJNnF50GpbLsPjdUwefH,hL9fngBAu7XzOx):
	V7o8RyDJNnF50GpbLsPjdUwefH = V7o8RyDJNnF50GpbLsPjdUwefH.replace(l7kBpMw5Qn(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ṗ"),SebHIf2jL1TBgrMKJu).replace(VOALf8iYEnMdK0g(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṘ"),SebHIf2jL1TBgrMKJu)
	xzpZLdkW2Ol,NNR4sgnwr2H = SebHIf2jL1TBgrMKJu,[]
	QUzFYoapm9jx(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ṙ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧ࡜ࠩṚ")+E7r8hUCVvTiFQW0dBGXjxcy+xzpZLdkW2Ol+XOVRfitWJP1zL3p2CMYF+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪṛ"),SebHIf2jL1TBgrMKJu,hL9fngBAu7XzOx,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṜ")+V7o8RyDJNnF50GpbLsPjdUwefH)
	QUzFYoapm9jx(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡪࡴࡲࡤࡦࡴࠪṝ"),ASkvf27etUK0(u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫṞ"),SebHIf2jL1TBgrMKJu,hL9fngBAu7XzOx,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṟ")+V7o8RyDJNnF50GpbLsPjdUwefH)
	QUzFYoapm9jx(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࡬ࡪࡰ࡮ࠫṠ"),E7r8hUCVvTiFQW0dBGXjxcy+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṡ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,AGlW9LqKN3Dvo(u"࠻࠼࠽࠾ỽ"))
	mBPv6wX4Tt = qFsuKN7ngp.menuItemsLIST[:]
	qFsuKN7ngp.menuItemsLIST[:] = []
	lfZmugQCFKLGT05AH29IsMiho = []
	if uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩṢ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		tS7CBRdygrhzEPL1pXuOx6(mrhSYXH2P8bO3eJAa9n)
		if not E2Et4cHoxzqKU89pDvwjn: return
		L4Zx3yAEz8GNW2nSXr1J56aDpjBeTf = list(E2Et4cHoxzqKU89pDvwjn.keys())
		qbour1DVTMwvR84yKe0BkXmfjZc = JO7n9zxwdgIStrTjR.sample(L4Zx3yAEz8GNW2nSXr1J56aDpjBeTf,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		X7N3fvV2iWjQtkRu4lI5yqO = list(E2Et4cHoxzqKU89pDvwjn[qbour1DVTMwvR84yKe0BkXmfjZc].keys())
		website = JO7n9zxwdgIStrTjR.sample(X7N3fvV2iWjQtkRu4lI5yqO,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = E2Et4cHoxzqKU89pDvwjn[qbour1DVTMwvR84yKe0BkXmfjZc][website]
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ALwOspNtXxZrz3PEKku(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤࠬṣ")+website+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ṥ")+xzpZLdkW2Ol+wPnfgxKZdAv6T10(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭ṥ")+url+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨṦ")+str(BEFCHNZ3JTUr4engVIxQo))
	elif zpx2fPNKk6Ms38eD1vcO(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭ṧ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		import EEMpr2e8JS
		if not EEMpr2e8JS.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
			lfZmugQCFKLGT05AH29IsMiho += cfbQZ4eOxy7Kg2aVCq(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),V7o8RyDJNnF50GpbLsPjdUwefH)
		if not lfZmugQCFKLGT05AH29IsMiho: return
		type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = JO7n9zxwdgIStrTjR.sample(lfZmugQCFKLGT05AH29IsMiho,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+sTGtHVyhQ9cJU37zxo2O(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧṨ")+xzpZLdkW2Ol+vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪṩ")+url+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬṪ")+str(BEFCHNZ3JTUr4engVIxQo))
	elif gCkRKGhwcx26v(u"ࠪࡣࡒ࠹ࡕࡠࠩṫ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		import EyOjQWPXlY
		if not EyOjQWPXlY.dd30zMZ2hmuvQb96irALtl(SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3): return
		for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
			lfZmugQCFKLGT05AH29IsMiho += jh0MuVYlXsbUztTCRG(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),V7o8RyDJNnF50GpbLsPjdUwefH)
		if not lfZmugQCFKLGT05AH29IsMiho: return
		type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = JO7n9zxwdgIStrTjR.sample(lfZmugQCFKLGT05AH29IsMiho,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫṬ")+xzpZLdkW2Ol+gCkRKGhwcx26v(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧṭ")+url+zpx2fPNKk6Ms38eD1vcO(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩṮ")+str(BEFCHNZ3JTUr4engVIxQo))
	tWVwOluce1fnYD4JdkbL = xzpZLdkW2Ol
	SblFPaLxohUEO5gAusj = []
	for YHnALfql8hprDu in range(wvkDqmNZlJU52isXo,C3w6qluao7EzUxJgMGBtV(u"࠴࠴Ỿ")):
		if YHnALfql8hprDu>wvkDqmNZlJU52isXo: z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+iDhLkZS6XBagNCQfs9tq2(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧṯ")+xzpZLdkW2Ol+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪṰ")+url+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬṱ")+str(BEFCHNZ3JTUr4engVIxQo))
		qFsuKN7ngp.menuItemsLIST[:] = []
		if BEFCHNZ3JTUr4engVIxQo==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠶࠸࠺ỿ") and t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫṲ") in Yg36raSGA02uUXEPMF7itZd9KcWf: BEFCHNZ3JTUr4engVIxQo = TVnqDYzWoM2UfHp0dchJ(u"࠷࠹࠳ἀ")
		if BEFCHNZ3JTUr4engVIxQo==uqLUBHepfM3l6AyIzTJh80a(u"࠽࠱࠵ἁ") and uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫṳ") in Yg36raSGA02uUXEPMF7itZd9KcWf: BEFCHNZ3JTUr4engVIxQo = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠷࠲࠵ἂ")
		if BEFCHNZ3JTUr4engVIxQo==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠲࠶࠷ἃ"): BEFCHNZ3JTUr4engVIxQo = zpx2fPNKk6Ms38eD1vcO(u"࠴࠼࠵ἄ")
		fNnuAzFsXhBKCco9JZeVUvd7Ya = GkAg0ZqR2cnPW9wvUtfj(type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
		if ASkvf27etUK0(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬṴ") in V7o8RyDJNnF50GpbLsPjdUwefH and BEFCHNZ3JTUr4engVIxQo==ASkvf27etUK0(u"࠴࠺࠼ἅ"): del qFsuKN7ngp.menuItemsLIST[:fuCbjVag7vU908J2Yqx5Th]
		if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࡟ࡎ࠵ࡘࡣࠬṵ") in V7o8RyDJNnF50GpbLsPjdUwefH and BEFCHNZ3JTUr4engVIxQo==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠵࠻࠾ἆ"): del qFsuKN7ngp.menuItemsLIST[:fuCbjVag7vU908J2Yqx5Th]
		NNR4sgnwr2H[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
		if SblFPaLxohUEO5gAusj and dHGcuCNYJWI53yrvAOT80(bcNqYtfET5l92dLGjyZSPe(u"ࡵࠨฯ็ๆฮ࠭Ṷ")) in str(NNR4sgnwr2H) or dHGcuCNYJWI53yrvAOT80(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࡶࠩะ่็ํࠧṷ")) in str(NNR4sgnwr2H):
			xzpZLdkW2Ol = tWVwOluce1fnYD4JdkbL
			NNR4sgnwr2H[:] = SblFPaLxohUEO5gAusj
			break
		tWVwOluce1fnYD4JdkbL = xzpZLdkW2Ol
		SblFPaLxohUEO5gAusj = NNR4sgnwr2H
		if str(NNR4sgnwr2H).count(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡹ࡭ࡩ࡫࡯ࠨṸ"))>wvkDqmNZlJU52isXo: break
		if str(NNR4sgnwr2H).count(Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡰ࡮ࡼࡥࠨṹ"))>wvkDqmNZlJU52isXo: break
		if BEFCHNZ3JTUr4engVIxQo==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠷࠹࠳ἇ"): break
		if BEFCHNZ3JTUr4engVIxQo==ypO63g8oJEsDnPBHSuU7lMTZr(u"࠽࠱࠴Ἀ"): break
		if BEFCHNZ3JTUr4engVIxQo==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲࠺࠳Ἁ"): break
		if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ṻ") in V7o8RyDJNnF50GpbLsPjdUwefH and NNR4sgnwr2H: type,xzpZLdkW2Ol,url,BEFCHNZ3JTUr4engVIxQo,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = JO7n9zxwdgIStrTjR.sample(NNR4sgnwr2H,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
	if not xzpZLdkW2Ol: xzpZLdkW2Ol = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࠴࠮࠯࠰ࠪṻ")
	elif xzpZLdkW2Ol.count(Izy1PvclrYx4eSVWn0L5phZbq(u"࠭࡟ࠨṼ"))>nyUIsfd53EGot9vbj0XDeq: xzpZLdkW2Ol = xzpZLdkW2Ol.split(l7kBpMw5Qn(u"ࠧࡠࠩṽ"),JhTts2R43AxkM8bYanKVy)[JhTts2R43AxkM8bYanKVy]
	xzpZLdkW2Ol = xzpZLdkW2Ol.replace(VOALf8iYEnMdK0g(u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫṾ"),SebHIf2jL1TBgrMKJu)
	xzpZLdkW2Ol = xzpZLdkW2Ol.replace(czvu7VQCZodkMf(u"ࠩࡢࡑࡔࡊ࡟ࠨṿ"),SebHIf2jL1TBgrMKJu)
	mBPv6wX4Tt[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq] = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࡟ࠬẀ")+E7r8hUCVvTiFQW0dBGXjxcy+xzpZLdkW2Ol+XOVRfitWJP1zL3p2CMYF+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࠥࡀวๅไึ้ࡢ࠭ẁ")
	if iDhLkZS6XBagNCQfs9tq2(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧẂ") in V7o8RyDJNnF50GpbLsPjdUwefH:
		for YHnALfql8hprDu in range(czvu7VQCZodkMf(u"࠺Ἂ")): JO7n9zxwdgIStrTjR.shuffle(NNR4sgnwr2H)
		qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H[:zYEXxHIZtvkcBON14A]
	else: qFsuKN7ngp.menuItemsLIST[:] = mBPv6wX4Tt+NNR4sgnwr2H
	return
def LBcWq2Dl4T9ezsi(bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6):
	HeYgp2ziS7cFGQlx0rX6 = HeYgp2ziS7cFGQlx0rX6.replace(HCiWF4jV1Q8(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨẃ"),SebHIf2jL1TBgrMKJu).replace(TVnqDYzWoM2UfHp0dchJ(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẄ"),SebHIf2jL1TBgrMKJu)
	kLjmGEwhSiy873RY5PcsM1zln9VQ = HeYgp2ziS7cFGQlx0rX6
	if ASkvf27etUK0(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩẅ") in HeYgp2ziS7cFGQlx0rX6:
		kLjmGEwhSiy873RY5PcsM1zln9VQ = HeYgp2ziS7cFGQlx0rX6.split(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪẆ"))[wvkDqmNZlJU52isXo]
		type = l7kBpMw5Qn(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ẇ")
	elif sTGtHVyhQ9cJU37zxo2O(u"࡛ࠫࡕࡄࠨẈ") in bnYHea4UJ09u3Qdt1olj6ksPZc: type = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨẉ")
	elif l7kBpMw5Qn(u"࠭ࡌࡊࡘࡈࠫẊ") in bnYHea4UJ09u3Qdt1olj6ksPZc: type = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨẋ")
	QUzFYoapm9jx(zpx2fPNKk6Ms38eD1vcO(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẌ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩ࡞ࠫẍ")+E7r8hUCVvTiFQW0dBGXjxcy+type+kLjmGEwhSiy873RY5PcsM1zln9VQ+XOVRfitWJP1zL3p2CMYF+VOALf8iYEnMdK0g(u"ࠪࠤ࠿อไใี่ࡡࠬẎ"),bnYHea4UJ09u3Qdt1olj6ksPZc,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠳࠹࠻Ἃ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẏ")+HeYgp2ziS7cFGQlx0rX6)
	QUzFYoapm9jx(uqLUBHepfM3l6AyIzTJh80a(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẐ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬẑ"),bnYHea4UJ09u3Qdt1olj6ksPZc,l7kBpMw5Qn(u"࠴࠺࠼Ἄ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬẒ")+HeYgp2ziS7cFGQlx0rX6)
	QUzFYoapm9jx(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨ࡮࡬ࡲࡰ࠭ẓ"),E7r8hUCVvTiFQW0dBGXjxcy+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧẔ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"࠽࠾࠿࠹Ἅ"))
	import EEMpr2e8JS
	for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
		if iDhLkZS6XBagNCQfs9tq2(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫẕ") in HeYgp2ziS7cFGQlx0rX6: EEMpr2e8JS.r80WK6hJtdjaqwM(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6,SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n)
		else: EEMpr2e8JS.JJeq4MVI8NtCWkaOiQLTybrzUx(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6,SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n)
	qFsuKN7ngp.menuItemsLIST[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
	if len(qFsuKN7ngp.menuItemsLIST)>(zYEXxHIZtvkcBON14A+fuCbjVag7vU908J2Yqx5Th): qFsuKN7ngp.menuItemsLIST[:] = qFsuKN7ngp.menuItemsLIST[:fuCbjVag7vU908J2Yqx5Th]+JO7n9zxwdgIStrTjR.sample(qFsuKN7ngp.menuItemsLIST[fuCbjVag7vU908J2Yqx5Th:],zYEXxHIZtvkcBON14A)
	return
def U2WklgqxyOV4wb7mL1TBz9PAGRHi(bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6):
	HeYgp2ziS7cFGQlx0rX6 = HeYgp2ziS7cFGQlx0rX6.replace(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẖ"),SebHIf2jL1TBgrMKJu).replace(wPnfgxKZdAv6T10(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẗ"),SebHIf2jL1TBgrMKJu)
	kLjmGEwhSiy873RY5PcsM1zln9VQ = HeYgp2ziS7cFGQlx0rX6
	if Izy1PvclrYx4eSVWn0L5phZbq(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ẘ") in HeYgp2ziS7cFGQlx0rX6:
		kLjmGEwhSiy873RY5PcsM1zln9VQ = HeYgp2ziS7cFGQlx0rX6.split(AGlW9LqKN3Dvo(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧẙ"))[wvkDqmNZlJU52isXo]
		type = vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫẚ")
	elif Izy1PvclrYx4eSVWn0L5phZbq(u"࡙ࠩࡓࡉ࠭ẛ") in bnYHea4UJ09u3Qdt1olj6ksPZc: type = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭ẜ")
	elif v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡑࡏࡖࡆࠩẝ") in bnYHea4UJ09u3Qdt1olj6ksPZc: type = TVnqDYzWoM2UfHp0dchJ(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭ẞ")
	QUzFYoapm9jx(ALwOspNtXxZrz3PEKku(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẟ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࡜ࠩẠ")+E7r8hUCVvTiFQW0dBGXjxcy+type+kLjmGEwhSiy873RY5PcsM1zln9VQ+XOVRfitWJP1zL3p2CMYF+czvu7VQCZodkMf(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪạ"),bnYHea4UJ09u3Qdt1olj6ksPZc,uqLUBHepfM3l6AyIzTJh80a(u"࠶࠼࠸Ἆ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧẢ")+HeYgp2ziS7cFGQlx0rX6)
	QUzFYoapm9jx(HCiWF4jV1Q8(u"ࠪࡪࡴࡲࡤࡦࡴࠪả"),HADrRCz9QgU4xudPJIqYb70(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪẤ"),bnYHea4UJ09u3Qdt1olj6ksPZc,Gykx0wL3XrlWaujsqKP9n2Q(u"࠷࠶࠹Ἇ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪấ")+HeYgp2ziS7cFGQlx0rX6)
	QUzFYoapm9jx(ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭࡬ࡪࡰ࡮ࠫẦ"),E7r8hUCVvTiFQW0dBGXjxcy+uqLUBHepfM3l6AyIzTJh80a(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬầ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠹࠺࠻࠼ἐ"))
	import EyOjQWPXlY
	for yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q in range(nyUIsfd53EGot9vbj0XDeq,wenmP3hMQEXB8gRcIyOH2A7ai+nyUIsfd53EGot9vbj0XDeq):
		if zpx2fPNKk6Ms38eD1vcO(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨẨ") in HeYgp2ziS7cFGQlx0rX6: EyOjQWPXlY.r80WK6hJtdjaqwM(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6,SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n)
		else: EyOjQWPXlY.JJeq4MVI8NtCWkaOiQLTybrzUx(str(yyYfnpuAIXNk7GzsLcEvKjDd0WUQ5q),bnYHea4UJ09u3Qdt1olj6ksPZc,HeYgp2ziS7cFGQlx0rX6,SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n)
	qFsuKN7ngp.menuItemsLIST[:] = YYwmZkr3hqQA9o5sFxfS8g(qFsuKN7ngp.menuItemsLIST)
	if len(qFsuKN7ngp.menuItemsLIST)>(zYEXxHIZtvkcBON14A+fuCbjVag7vU908J2Yqx5Th): qFsuKN7ngp.menuItemsLIST[:] = qFsuKN7ngp.menuItemsLIST[:fuCbjVag7vU908J2Yqx5Th]+JO7n9zxwdgIStrTjR.sample(qFsuKN7ngp.menuItemsLIST[fuCbjVag7vU908J2Yqx5Th:],zYEXxHIZtvkcBON14A)
	return
def YYwmZkr3hqQA9o5sFxfS8g(U503PkKrlyxL1BzoQsW):
	gCjpY65VthzNHrmJ7AOXkxq2lPbWe = []
	for type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in U503PkKrlyxL1BzoQsW:
		if ASkvf27etUK0(u"ุࠩๅาฯࠧẩ") in xzpZLdkW2Ol or Ns6AJKH7DGpr19Wl5C3nF(u"ูࠪๆำ็ࠨẪ") in xzpZLdkW2Ol or czvu7VQCZodkMf(u"ࠫࡵࡧࡧࡦࠩẫ") in xzpZLdkW2Ol.lower(): continue
		gCjpY65VthzNHrmJ7AOXkxq2lPbWe.append([type,xzpZLdkW2Ol,url,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM])
	return gCjpY65VthzNHrmJ7AOXkxq2lPbWe