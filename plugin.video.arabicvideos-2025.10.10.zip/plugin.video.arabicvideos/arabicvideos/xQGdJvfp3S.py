# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from SSCitzlpRq import *
class rcuCiA7YDd3MSbkmEwnpht(MSGnwoeiRcVCW64Ja):
	def __init__(sYhGUD7CrxpWtj,*aargs,**kkwargs):
		sYhGUD7CrxpWtj.choiceID = -nyUIsfd53EGot9vbj0XDeq
	def onClick(sYhGUD7CrxpWtj,tsSJRcjM6naTyfQiz3WIv2lKEUN):
		if tsSJRcjM6naTyfQiz3WIv2lKEUN>=vMhFypGLHZJbdX4O7oc3W8x(u"࠺࠲࠴࠴ઝ"): sYhGUD7CrxpWtj.choiceID = tsSJRcjM6naTyfQiz3WIv2lKEUN-vMhFypGLHZJbdX4O7oc3W8x(u"࠺࠲࠴࠴ઝ")
		sYhGUD7CrxpWtj.nncTmIeaM5b1HkA9h()
	def ec0UwG9BX3isqZNAW(sYhGUD7CrxpWtj,*aargs):
		sYhGUD7CrxpWtj.button0,sYhGUD7CrxpWtj.button1,sYhGUD7CrxpWtj.button2 = aargs[wvkDqmNZlJU52isXo],aargs[nyUIsfd53EGot9vbj0XDeq],aargs[JhTts2R43AxkM8bYanKVy]
		sYhGUD7CrxpWtj.header,sYhGUD7CrxpWtj.text = aargs[fuCbjVag7vU908J2Yqx5Th],aargs[K7cnfQMS6BPvI4LGmCsRp8bUlJ9]
		sYhGUD7CrxpWtj.profile,sYhGUD7CrxpWtj.direction = aargs[iDhLkZS6XBagNCQfs9tq2(u"࠷ઞ")],aargs[sTGtHVyhQ9cJU37zxo2O(u"࠹ટ")]
		sYhGUD7CrxpWtj.buttonstimeout,sYhGUD7CrxpWtj.closetimeout = aargs[fp6KV7DlS8QYniUczHdmZChL(u"࠼ડ")],aargs[ALwOspNtXxZrz3PEKku(u"࠼ઠ")]
		if sYhGUD7CrxpWtj.buttonstimeout>wvkDqmNZlJU52isXo or sYhGUD7CrxpWtj.closetimeout>sTGtHVyhQ9cJU37zxo2O(u"࠶ઢ"): sYhGUD7CrxpWtj.enable_progressbar = BBX9RAuxnyGZ4WIF2TrhYeom3
		else: sYhGUD7CrxpWtj.enable_progressbar = mrhSYXH2P8bO3eJAa9n
		sYhGUD7CrxpWtj.image_filename = AAVyWBIugYpewaqKDGRn.replace(C3w6qluao7EzUxJgMGBtV(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧਉ"),sTGtHVyhQ9cJU37zxo2O(u"ࠨࡡࠪਊ")+str(uv8V4fE7j9pmgFr3wnDL.time())+gCkRKGhwcx26v(u"ࠩࡢࠫ਋"))
		sYhGUD7CrxpWtj.image_filename = sYhGUD7CrxpWtj.image_filename.replace(bcNqYtfET5l92dLGjyZSPe(u"ࠪࡠࡡ࠭਌"),C3w6qluao7EzUxJgMGBtV(u"ࠫࡡࡢ࡜࡝ࠩ਍")).replace(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬ࠵࠯ࠨ਎"),DQIrVcKuY6bJv(u"࠭࠯࠰࠱࠲ࠫਏ"))
		sYhGUD7CrxpWtj.image_height = LmUvI1AcCtBe3j0JW(sYhGUD7CrxpWtj.button0,sYhGUD7CrxpWtj.button1,sYhGUD7CrxpWtj.button2,sYhGUD7CrxpWtj.header,sYhGUD7CrxpWtj.text,sYhGUD7CrxpWtj.profile,sYhGUD7CrxpWtj.direction,sYhGUD7CrxpWtj.enable_progressbar,sYhGUD7CrxpWtj.image_filename)
		sYhGUD7CrxpWtj.show()
		sYhGUD7CrxpWtj.getControl(Izy1PvclrYx4eSVWn0L5phZbq(u"࠹࠱࠷࠳ણ")).setImage(sYhGUD7CrxpWtj.image_filename)
		sYhGUD7CrxpWtj.getControl(zpx2fPNKk6Ms38eD1vcO(u"࠺࠲࠸࠴ત")).setHeight(sYhGUD7CrxpWtj.image_height)
		if not sYhGUD7CrxpWtj.button1 and sYhGUD7CrxpWtj.button0 and sYhGUD7CrxpWtj.button2: sYhGUD7CrxpWtj.getControl(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠼࠴࠶࠸દ")).setPosition(-Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠶࠷࠶ધ"),VOALf8iYEnMdK0g(u"࠲થ"))
		return sYhGUD7CrxpWtj.image_filename,sYhGUD7CrxpWtj.image_height
	def CCX7FwVYhcnqx3T0osy(sYhGUD7CrxpWtj):
		if sYhGUD7CrxpWtj.buttonstimeout:
			sYhGUD7CrxpWtj.th1 = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=sYhGUD7CrxpWtj.BfgVq7yvMe6rl1sEK8hPJ5)
			sYhGUD7CrxpWtj.th1.start()
		else: sYhGUD7CrxpWtj.QX3syvimg6thAND7bVpI5W9wnHJU()
	def BfgVq7yvMe6rl1sEK8hPJ5(sYhGUD7CrxpWtj):
		sYhGUD7CrxpWtj.getControl(DQIrVcKuY6bJv(u"࠾࠶࠲࠱ન")).setEnabled(BBX9RAuxnyGZ4WIF2TrhYeom3)
		for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(nyUIsfd53EGot9vbj0XDeq,sYhGUD7CrxpWtj.buttonstimeout+nyUIsfd53EGot9vbj0XDeq):
			uv8V4fE7j9pmgFr3wnDL.sleep(nyUIsfd53EGot9vbj0XDeq)
			xCb5v7U9OGLQM2u = int(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠷࠰࠱઩")*XM3KUmO1QJxlv84bgFTHsjdNt0kYq/sYhGUD7CrxpWtj.buttonstimeout)
			sYhGUD7CrxpWtj.VNwxkU0SoZEi(xCb5v7U9OGLQM2u)
			if sYhGUD7CrxpWtj.choiceID>uqLUBHepfM3l6AyIzTJh80a(u"࠰પ"): break
		sYhGUD7CrxpWtj.QX3syvimg6thAND7bVpI5W9wnHJU()
	def fTDdUrb5uI2JpcsEBlHZQG38Vo9N(sYhGUD7CrxpWtj):
		if sYhGUD7CrxpWtj.closetimeout:
			sYhGUD7CrxpWtj.th2 = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=sYhGUD7CrxpWtj.c7cTk98BKzRZtCH5nD)
			sYhGUD7CrxpWtj.th2.start()
		else: sYhGUD7CrxpWtj.QX3syvimg6thAND7bVpI5W9wnHJU()
	def c7cTk98BKzRZtCH5nD(sYhGUD7CrxpWtj):
		sYhGUD7CrxpWtj.getControl(HADrRCz9QgU4xudPJIqYb70(u"࠺࠲࠵࠴ફ")).setEnabled(BBX9RAuxnyGZ4WIF2TrhYeom3)
		uv8V4fE7j9pmgFr3wnDL.sleep(sYhGUD7CrxpWtj.buttonstimeout)
		for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(sYhGUD7CrxpWtj.closetimeout-nyUIsfd53EGot9vbj0XDeq,-nyUIsfd53EGot9vbj0XDeq,-nyUIsfd53EGot9vbj0XDeq):
			uv8V4fE7j9pmgFr3wnDL.sleep(nyUIsfd53EGot9vbj0XDeq)
			xCb5v7U9OGLQM2u = int(ASkvf27etUK0(u"࠳࠳࠴બ")*XM3KUmO1QJxlv84bgFTHsjdNt0kYq/sYhGUD7CrxpWtj.closetimeout)
			sYhGUD7CrxpWtj.VNwxkU0SoZEi(xCb5v7U9OGLQM2u)
			if sYhGUD7CrxpWtj.choiceID>wvkDqmNZlJU52isXo: break
		if sYhGUD7CrxpWtj.closetimeout>wvkDqmNZlJU52isXo: sYhGUD7CrxpWtj.choiceID = AGlW9LqKN3Dvo(u"࠴࠴ભ")
		sYhGUD7CrxpWtj.nncTmIeaM5b1HkA9h()
	def VNwxkU0SoZEi(sYhGUD7CrxpWtj,xCb5v7U9OGLQM2u):
		sYhGUD7CrxpWtj.precent = xCb5v7U9OGLQM2u
		sYhGUD7CrxpWtj.getControl(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠽࠵࠸࠰મ")).setPercent(sYhGUD7CrxpWtj.precent)
	def QX3syvimg6thAND7bVpI5W9wnHJU(sYhGUD7CrxpWtj):
		if sYhGUD7CrxpWtj.button0: sYhGUD7CrxpWtj.getControl(zpx2fPNKk6Ms38eD1vcO(u"࠾࠶࠱࠱ય")).setEnabled(BBX9RAuxnyGZ4WIF2TrhYeom3)
		if sYhGUD7CrxpWtj.button1: sYhGUD7CrxpWtj.getControl(fp6KV7DlS8QYniUczHdmZChL(u"࠿࠰࠲࠳ર")).setEnabled(BBX9RAuxnyGZ4WIF2TrhYeom3)
		if sYhGUD7CrxpWtj.button2: sYhGUD7CrxpWtj.getControl(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠹࠱࠳࠵઱")).setEnabled(BBX9RAuxnyGZ4WIF2TrhYeom3)
	def nncTmIeaM5b1HkA9h(sYhGUD7CrxpWtj):
		sYhGUD7CrxpWtj.close()
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(sYhGUD7CrxpWtj.image_filename)
		except: pass
def gge5CmAcldwv0(*aargs,**kkwargs):
	if aargs:
		direction = aargs[wvkDqmNZlJU52isXo]
		hYWURwpIKyd = aargs[nyUIsfd53EGot9vbj0XDeq]
		if not direction: direction = Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࡤࡧࡱࡸࡪࡸࠧਐ")
		if not hYWURwpIKyd: hYWURwpIKyd = AGlW9LqKN3Dvo(u"ࠨษึฮ๊ืวาࠩ਑")
		xfH5SDIPY0WNhb3zFrc = aargs[JhTts2R43AxkM8bYanKVy]
		sLjle5myuEXSiFHJ = u43PVWjh7t9YwI.join(aargs[TVnqDYzWoM2UfHp0dchJ(u"࠴લ"):])
	else: direction,hYWURwpIKyd,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ = SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"ࠩࡒࡏࠬ਒"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	omIUAxNupsBHY0SGnJXzijltOyV(direction,SebHIf2jL1TBgrMKJu,hYWURwpIKyd,SebHIf2jL1TBgrMKJu,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,**kkwargs)
	return
def vvubxo631m2zYC(*aargs,**kkwargs):
	direction = aargs[wvkDqmNZlJU52isXo]
	baJO5pE6kWgmKuXPTIl4HfrteZQAN7 = aargs[nyUIsfd53EGot9vbj0XDeq]
	PRDxtEeg86L = aargs[JhTts2R43AxkM8bYanKVy]
	if PRDxtEeg86L or baJO5pE6kWgmKuXPTIl4HfrteZQAN7: RRf7ZyOrbCUmtFXs9AkT4a1v = BBX9RAuxnyGZ4WIF2TrhYeom3
	else: RRf7ZyOrbCUmtFXs9AkT4a1v = mrhSYXH2P8bO3eJAa9n
	xfH5SDIPY0WNhb3zFrc = aargs[fuCbjVag7vU908J2Yqx5Th]
	sLjle5myuEXSiFHJ = aargs[K7cnfQMS6BPvI4LGmCsRp8bUlJ9]
	if not direction: direction = ASkvf27etUK0(u"ࠪࡧࡪࡴࡴࡦࡴࠪਓ")
	if not baJO5pE6kWgmKuXPTIl4HfrteZQAN7: baJO5pE6kWgmKuXPTIl4HfrteZQAN7 = HCiWF4jV1Q8(u"่๊ࠫวࠡࠢࡑࡳࠬਔ")
	if not PRDxtEeg86L: PRDxtEeg86L = gCkRKGhwcx26v(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧਕ")
	if len(aargs)>=ALwOspNtXxZrz3PEKku(u"࠹઴"): sLjle5myuEXSiFHJ += u43PVWjh7t9YwI+aargs[ASkvf27etUK0(u"࠷ળ")]
	if len(aargs)>=gCkRKGhwcx26v(u"࠻વ"): sLjle5myuEXSiFHJ += u43PVWjh7t9YwI+aargs[Izy1PvclrYx4eSVWn0L5phZbq(u"࠻શ")]
	x5BZ9SJfFAWV743cgCvoUamse = omIUAxNupsBHY0SGnJXzijltOyV(direction,baJO5pE6kWgmKuXPTIl4HfrteZQAN7,SebHIf2jL1TBgrMKJu,PRDxtEeg86L,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,**kkwargs)
	if x5BZ9SJfFAWV743cgCvoUamse==-Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠷ષ") and RRf7ZyOrbCUmtFXs9AkT4a1v: x5BZ9SJfFAWV743cgCvoUamse = -nyUIsfd53EGot9vbj0XDeq
	elif x5BZ9SJfFAWV743cgCvoUamse==-nyUIsfd53EGot9vbj0XDeq and not RRf7ZyOrbCUmtFXs9AkT4a1v: x5BZ9SJfFAWV743cgCvoUamse = mrhSYXH2P8bO3eJAa9n
	elif x5BZ9SJfFAWV743cgCvoUamse==wvkDqmNZlJU52isXo: x5BZ9SJfFAWV743cgCvoUamse = mrhSYXH2P8bO3eJAa9n
	elif x5BZ9SJfFAWV743cgCvoUamse==JhTts2R43AxkM8bYanKVy: x5BZ9SJfFAWV743cgCvoUamse = BBX9RAuxnyGZ4WIF2TrhYeom3
	return x5BZ9SJfFAWV743cgCvoUamse
def KKxHoL6iq4dst79zCUP215lYgMOreG(*aargs,**kkwargs):
	return G5OVsSktWRJQu8h4T.Dialog().select(*aargs,**kkwargs)
def i9yzUqgAW2Zap1h4Lm(*aargs,**kkwargs):
	xfH5SDIPY0WNhb3zFrc = aargs[wvkDqmNZlJU52isXo]
	sLjle5myuEXSiFHJ = aargs[nyUIsfd53EGot9vbj0XDeq]
	eHv54YKunQpUE3 = kkwargs[ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡴࡪ࡯ࡨࠫਖ")] if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡵ࡫ࡰࡩࠬਗ") in list(kkwargs.keys()) else bcNqYtfET5l92dLGjyZSPe(u"࠱࠱࠲࠳સ")
	DRPoCzNmEJgxvuil6bneSHLdAtQ = aargs[JhTts2R43AxkM8bYanKVy] if len(aargs)>JhTts2R43AxkM8bYanKVy and fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡶ࡬ࡱࡪ࠭ਘ") not in aargs[JhTts2R43AxkM8bYanKVy] else v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩਙ")
	DGpUszFj8mJ = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=juS4eTstZhJqGw,args=(xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,DRPoCzNmEJgxvuil6bneSHLdAtQ,eHv54YKunQpUE3))
	DGpUszFj8mJ.start()
	return
def juS4eTstZhJqGw(xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,DRPoCzNmEJgxvuil6bneSHLdAtQ,eHv54YKunQpUE3):
	rz8lqojv7F2RIUWkwEZAp = DRPoCzNmEJgxvuil6bneSHLdAtQ.replace(C3w6qluao7EzUxJgMGBtV(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪਚ"),SebHIf2jL1TBgrMKJu)
	import RyvhfqnkAZ
	name = RyvhfqnkAZ.MlNunOcdK41Qo59rIakEmgPx(BBX9RAuxnyGZ4WIF2TrhYeom3,rz8lqojv7F2RIUWkwEZAp+uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠥ࠳ࠠࠨਛ")+xfH5SDIPY0WNhb3zFrc+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠦ࠭ࠡࠩਜ")+sLjle5myuEXSiFHJ)
	name = RyvhfqnkAZ.YRPMivXNVUgu0FSsOICQnTZ2r(name)
	image_filename = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(P6JuCgySDkci19Tp,name+Izy1PvclrYx4eSVWn0L5phZbq(u"࠭࠮ࡱࡰࡪࠫਝ"))
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(image_filename):
		if DRPoCzNmEJgxvuil6bneSHLdAtQ==vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧਞ"): image_height = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠲࠳࠺હ")
		elif DRPoCzNmEJgxvuil6bneSHLdAtQ==gCkRKGhwcx26v(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬਟ"): image_height = fp6KV7DlS8QYniUczHdmZChL(u"࠴࠴࠴઺")
	else: image_height = LmUvI1AcCtBe3j0JW(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,DRPoCzNmEJgxvuil6bneSHLdAtQ,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࡯ࡩ࡫ࡺࠧਠ"),mrhSYXH2P8bO3eJAa9n,image_filename)
	KnD35XEScrxp1ldRuPHyo = MSGnwoeiRcVCW64Ja(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪਡ"),rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬਢ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠬ࠽࠲࠱ࡲࠪਣ"))
	KnD35XEScrxp1ldRuPHyo.show()
	if DRPoCzNmEJgxvuil6bneSHLdAtQ==DQIrVcKuY6bJv(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪਤ"):
		KnD35XEScrxp1ldRuPHyo.getControl(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠽࠵࠺࠰઼")).setHeight(Gykx0wL3XrlWaujsqKP9n2Q(u"࠵࠵࠺઻"))
		KnD35XEScrxp1ldRuPHyo.getControl(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠹࠱࠶࠳િ")).setPosition(DQIrVcKuY6bJv(u"࠺࠻ઽ"),-xxRyYsrSCzjifvH4cIqgldeOo(u"࠾࠰ા"))
		KnD35XEScrxp1ldRuPHyo.getControl(gCkRKGhwcx26v(u"࠺࠲࠸࠴ી")).setPosition(gCkRKGhwcx26v(u"࠳࠵࠴ુ"),-j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠹࠴ૂ"))
		KnD35XEScrxp1ldRuPHyo.getControl(Ns6AJKH7DGpr19Wl5C3nF(u"࠺࠰࠱ૅ")).setPosition(vMhFypGLHZJbdX4O7oc3W8x(u"࠽࠵ૃ"),-vMhFypGLHZJbdX4O7oc3W8x(u"࠸࠻ૄ"))
	KnD35XEScrxp1ldRuPHyo.getControl(AGlW9LqKN3Dvo(u"࠴࠱࠳૆")).setVisible(mrhSYXH2P8bO3eJAa9n)
	KnD35XEScrxp1ldRuPHyo.getControl(bcNqYtfET5l92dLGjyZSPe(u"࠵࠲࠵ે")).setVisible(mrhSYXH2P8bO3eJAa9n)
	KnD35XEScrxp1ldRuPHyo.getControl(Izy1PvclrYx4eSVWn0L5phZbq(u"࠻࠳࠹࠵ૈ")).setImage(image_filename)
	KnD35XEScrxp1ldRuPHyo.getControl(fp6KV7DlS8QYniUczHdmZChL(u"࠼࠴࠺࠶ૉ")).setHeight(image_height)
	uv8V4fE7j9pmgFr3wnDL.sleep(eHv54YKunQpUE3//C3w6qluao7EzUxJgMGBtV(u"࠵࠵࠶࠰࠯࠲૊"))
	return
def zQgdTIC74ov(*aargs,**kkwargs):
	xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,profile,direction = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਥ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ࡮ࡨࡪࡹ࠭ਦ")
	if len(aargs)>=nyUIsfd53EGot9vbj0XDeq: xfH5SDIPY0WNhb3zFrc = aargs[wvkDqmNZlJU52isXo]
	if len(aargs)>=JhTts2R43AxkM8bYanKVy: sLjle5myuEXSiFHJ = aargs[nyUIsfd53EGot9vbj0XDeq]
	if len(aargs)>=fuCbjVag7vU908J2Yqx5Th: profile = aargs[JhTts2R43AxkM8bYanKVy]
	if len(aargs)>=K7cnfQMS6BPvI4LGmCsRp8bUlJ9: direction = aargs[fuCbjVag7vU908J2Yqx5Th]
	return M8wEz43vLgdl(direction,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,profile)
def Vfr2yFLvzdP0gJM5E4XjQbo(*aargs,**kkwargs):
	return G5OVsSktWRJQu8h4T.Dialog().contextmenu(*aargs,**kkwargs)
def jHS9WuMxcs475RPkwpErteQI(*aargs,**kkwargs):
	return G5OVsSktWRJQu8h4T.Dialog().browseSingle(*aargs,**kkwargs)
def HeEDq925biGjVFmn8Y6wCgRO3(*aargs,**kkwargs):
	return G5OVsSktWRJQu8h4T.Dialog().input(*aargs,**kkwargs)
def fy567LYZh4gGdeSJN(*aargs,**kkwargs):
	return G5OVsSktWRJQu8h4T.DialogProgress(*aargs,**kkwargs)
def omIUAxNupsBHY0SGnJXzijltOyV(direction,button0=SebHIf2jL1TBgrMKJu,button1=SebHIf2jL1TBgrMKJu,button2=SebHIf2jL1TBgrMKJu,xfH5SDIPY0WNhb3zFrc=SebHIf2jL1TBgrMKJu,sLjle5myuEXSiFHJ=SebHIf2jL1TBgrMKJu,profile=l7kBpMw5Qn(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫਧ"),LLz46habRQ0GcVdlyeiF7MuqY=wvkDqmNZlJU52isXo,ibg5jYU76xwuL=wvkDqmNZlJU52isXo):
	if not direction: direction = ASkvf27etUK0(u"ࠪࡧࡪࡴࡴࡦࡴࠪਨ")
	KnD35XEScrxp1ldRuPHyo = rcuCiA7YDd3MSbkmEwnpht(sTGtHVyhQ9cJU37zxo2O(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭਩"),rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,iDhLkZS6XBagNCQfs9tq2(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ਪ"),zpx2fPNKk6Ms38eD1vcO(u"࠭࠷࠳࠲ࡳࠫਫ"))
	KnD35XEScrxp1ldRuPHyo.ec0UwG9BX3isqZNAW(button0,button1,button2,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,profile,direction,LLz46habRQ0GcVdlyeiF7MuqY,ibg5jYU76xwuL)
	if LLz46habRQ0GcVdlyeiF7MuqY>wvkDqmNZlJU52isXo: KnD35XEScrxp1ldRuPHyo.CCX7FwVYhcnqx3T0osy()
	if ibg5jYU76xwuL>wvkDqmNZlJU52isXo: KnD35XEScrxp1ldRuPHyo.fTDdUrb5uI2JpcsEBlHZQG38Vo9N()
	if LLz46habRQ0GcVdlyeiF7MuqY==wvkDqmNZlJU52isXo and ibg5jYU76xwuL==wvkDqmNZlJU52isXo: KnD35XEScrxp1ldRuPHyo.QX3syvimg6thAND7bVpI5W9wnHJU()
	KnD35XEScrxp1ldRuPHyo.doModal()
	x5BZ9SJfFAWV743cgCvoUamse = KnD35XEScrxp1ldRuPHyo.choiceID
	return x5BZ9SJfFAWV743cgCvoUamse
def M8wEz43vLgdl(direction,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,profile=sTGtHVyhQ9cJU37zxo2O(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਬ")):
	if not direction: direction = wPnfgxKZdAv6T10(u"ࠨ࡮ࡨࡪࡹ࠭ਭ")
	KnD35XEScrxp1ldRuPHyo = MSGnwoeiRcVCW64Ja(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬਮ"),rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,l7kBpMw5Qn(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫਯ"),zpx2fPNKk6Ms38eD1vcO(u"ࠫ࠼࠸࠰ࡱࠩਰ"))
	image_filename = AAVyWBIugYpewaqKDGRn.replace(wPnfgxKZdAv6T10(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ਱"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭࡟ࠨਲ")+str(uv8V4fE7j9pmgFr3wnDL.time())+iDhLkZS6XBagNCQfs9tq2(u"ࠧࡠࠩਲ਼"))
	image_filename = image_filename.replace(DQIrVcKuY6bJv(u"ࠨ࡞࡟ࠫ਴"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࡟ࡠࡡࡢࠧਵ")).replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠪ࠳࠴࠭ਸ਼"),l7kBpMw5Qn(u"ࠫ࠴࠵࠯࠰ࠩ਷"))
	image_height = LmUvI1AcCtBe3j0JW(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xfH5SDIPY0WNhb3zFrc,sLjle5myuEXSiFHJ,profile,direction,mrhSYXH2P8bO3eJAa9n,image_filename)
	KnD35XEScrxp1ldRuPHyo.show()
	KnD35XEScrxp1ldRuPHyo.getControl(ypO63g8oJEsDnPBHSuU7lMTZr(u"࠾࠶࠵࠱ો")).setHeight(image_height)
	KnD35XEScrxp1ldRuPHyo.getControl(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠿࠰࠶࠲ૌ")).setImage(image_filename)
	hG5zd1tIw6YZrTpeQuNPDvg = KnD35XEScrxp1ldRuPHyo.doModal()
	try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(image_filename)
	except: pass
	return hG5zd1tIw6YZrTpeQuNPDvg
def LmUvI1AcCtBe3j0JW(IAde17rNHUk,y9UK4O2vhkr5iaXeRpQTDdCw,uCnRZp5LGv61g,mVP1EsO9TYHX6,Yg36raSGA02uUXEPMF7itZd9KcWf,gAwLHrUqKY6tZVcOh,myoSjiaU1Q3M,ka2bJK5t683cxzlF,xTy789mirzJf21):
	pp6ruCt2whWxbyQznVcSBvUja5HT8 = E2xjtKaMXdC3NDoTm7f5Wkev.path.dirname(xTy789mirzJf21)
	if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(pp6ruCt2whWxbyQznVcSBvUja5HT8):
		try: E2xjtKaMXdC3NDoTm7f5Wkev.makedirs(pp6ruCt2whWxbyQznVcSBvUja5HT8)
		except: pass
	gxHiyhrj96uWOSb5DzU3eNT = EZTSgt5u81BkF4yhPp3odXRiOAxan(gAwLHrUqKY6tZVcOh)
	ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo = pxlSIi2uVmEvD6njz1h(gxHiyhrj96uWOSb5DzU3eNT,IAde17rNHUk,y9UK4O2vhkr5iaXeRpQTDdCw,uCnRZp5LGv61g,mVP1EsO9TYHX6,Yg36raSGA02uUXEPMF7itZd9KcWf,gAwLHrUqKY6tZVcOh,myoSjiaU1Q3M,ka2bJK5t683cxzlF,xTy789mirzJf21)
	return ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo
def EZTSgt5u81BkF4yhPp3odXRiOAxan(gAwLHrUqKY6tZVcOh):
	hORKiVQTgv0I9wA = vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
	ddo510iPQFSUgKGq3IDrftWjxLksbJ = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠲࠱્")
	nkDHZzRBol2O = TVnqDYzWoM2UfHp0dchJ(u"࠳࠲૎")
	vFUdWHwCQVrS4KxyRIg30poNE = wvkDqmNZlJU52isXo
	AnFHjVD2tYvMaQZRWrhsUmc1f = AGlW9LqKN3Dvo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬਸ")
	v6K9kHiwcyLrYURxlapD4Vn = wvkDqmNZlJU52isXo
	JLgu1Yxv7Vl3wsoD9nC4dNIr = wPnfgxKZdAv6T10(u"࠳࠼૏")
	wkOJVU3PZoTi0D9X4I6zAh = AGlW9LqKN3Dvo(u"࠶࠴ૐ")
	QjlCb8iJzVU1XO3a6 = wPnfgxKZdAv6T10(u"࠼૑")
	W1Ry0gajibrs35 = BBX9RAuxnyGZ4WIF2TrhYeom3
	HHryJpgFLdCVvZ6zaDP9 = uqLUBHepfM3l6AyIzTJh80a(u"࠸࠽࠵૒")
	j4tkWE2M1eOhlH0wboxAqQJcpdDv = tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠺࠱࠱૓")
	iTKAgZMJrqtQeR = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠵࠱૔")
	iO2M4PTW5m = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠳࠺࠳૕")
	qq5s4TcUKfz0AvuwmC = xxRyYsrSCzjifvH4cIqgldeOo(u"࠴࠻૖")
	yJNxPCEib9B5 = vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
	vz3s65dg0MwN1KSBD9HWpFuP = wvkDqmNZlJU52isXo
	EmhFfr8YKlNXBM0idjPVk5zaUwC = uqLUBHepfM3l6AyIzTJh80a(u"࠶࠵૗")
	GG4IBLDKUAarc8PdxXCw = [uqLUBHepfM3l6AyIzTJh80a(u"࠹࠶૚"),sTGtHVyhQ9cJU37zxo2O(u"࠷࠷૘"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠷࠾૙")]
	from PIL import ImageDraw as QI3O9TxBZq8rshbt6KuED2iyzvJVFg,ImageFont as LknU0Q5lDacKWVBr6vg8PmHJj9,Image as JNRHvAFDg4KsEf
	if fp6KV7DlS8QYniUczHdmZChL(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬਹ") in gAwLHrUqKY6tZVcOh:
		if gAwLHrUqKY6tZVcOh==C3w6qluao7EzUxJgMGBtV(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ਺"):
			W7fYAGHOQETreI = qeYIw0BNTL9bGJnosacQ1DtVR(u"࠱࠲࠹૛")
			AnFHjVD2tYvMaQZRWrhsUmc1f = HCiWF4jV1Q8(u"ࠨ࡮ࡨࡪࡹ࠭਻")
			W1Ry0gajibrs35 = mrhSYXH2P8bO3eJAa9n
		elif gAwLHrUqKY6tZVcOh==tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ਼࠭"):
			W7fYAGHOQETreI = xxRyYsrSCzjifvH4cIqgldeOo(u"࡙ࠪࡕࡖࡅࡓࠩ਽")
			AnFHjVD2tYvMaQZRWrhsUmc1f = HCiWF4jV1Q8(u"ࠫࡷ࡯ࡧࡩࡶࠪਾ")
			vFUdWHwCQVrS4KxyRIg30poNE = wPnfgxKZdAv6T10(u"࠲࠲૜")
		jAEmVwnsF7apgTQROli8Dv = VOALf8iYEnMdK0g(u"࠹࠵࠴૝")
		GG4IBLDKUAarc8PdxXCw = [v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠶࠷૞"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠶࠷૞"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠶࠷૞")]
		nkDHZzRBol2O = VOALf8iYEnMdK0g(u"࠶࠵૟")
		ddo510iPQFSUgKGq3IDrftWjxLksbJ = wvkDqmNZlJU52isXo
		wkOJVU3PZoTi0D9X4I6zAh = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠷࠶ૠ")
		JLgu1Yxv7Vl3wsoD9nC4dNIr = qeYIw0BNTL9bGJnosacQ1DtVR(u"࠹࠵ૡ")
	elif gAwLHrUqKY6tZVcOh==czvu7VQCZodkMf(u"ࠬࡳࡥ࡯ࡷࡢ࡭ࡹ࡫࡭ࠨਿ"):
		GG4IBLDKUAarc8PdxXCw,jAEmVwnsF7apgTQROli8Dv,W7fYAGHOQETreI = [wPnfgxKZdAv6T10(u"࠴࠻૤"),wPnfgxKZdAv6T10(u"࠴࠻૤"),wPnfgxKZdAv6T10(u"࠴࠻૤")],wPnfgxKZdAv6T10(u"࠲࠱࠲ૢ"),gCkRKGhwcx26v(u"࠳࠷࠳ૣ")
		v6K9kHiwcyLrYURxlapD4Vn,wkOJVU3PZoTi0D9X4I6zAh,JLgu1Yxv7Vl3wsoD9nC4dNIr, = wvkDqmNZlJU52isXo,-DQIrVcKuY6bJv(u"࠴࠶૥"),-uqLUBHepfM3l6AyIzTJh80a(u"࠷࠵૦")
		ddo510iPQFSUgKGq3IDrftWjxLksbJ = wvkDqmNZlJU52isXo
		mTJOE2VygwdoCHfrMR5qjtz = JNRHvAFDg4KsEf.open(p1ENioYkXrGnM2Pqu)
		y4ykitIPNef = JNRHvAFDg4KsEf.new(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡒࡈࡄࡄࠫੀ"),(jAEmVwnsF7apgTQROli8Dv,W7fYAGHOQETreI),(VOALf8iYEnMdK0g(u"࠷࠻࠵૧"),wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo,VOALf8iYEnMdK0g(u"࠷࠻࠵૧")))
	elif gAwLHrUqKY6tZVcOh==wPnfgxKZdAv6T10(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੁ"): GG4IBLDKUAarc8PdxXCw,W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = [xxRyYsrSCzjifvH4cIqgldeOo(u"࠴࠻૫"),Ns6AJKH7DGpr19Wl5C3nF(u"࠸࠴૨"),gCkRKGhwcx26v(u"࠲࠱૩")],Gykx0wL3XrlWaujsqKP9n2Q(u"࠸࠴࠵૬"),bcNqYtfET5l92dLGjyZSPe(u"࠺࠲࠳૪")
	elif gAwLHrUqKY6tZVcOh==AGlW9LqKN3Dvo(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ੂ"): GG4IBLDKUAarc8PdxXCw,W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = [TVnqDYzWoM2UfHp0dchJ(u"࠸࠸૮"),sTGtHVyhQ9cJU37zxo2O(u"࠲࠹૰"),iDhLkZS6XBagNCQfs9tq2(u"࠶࠹૭")],xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠲࠳૱"),DQIrVcKuY6bJv(u"࠿࠰࠱૯")
	elif gAwLHrUqKY6tZVcOh==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ੃"): GG4IBLDKUAarc8PdxXCw,W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = [AGlW9LqKN3Dvo(u"࠸࠼૵"),VOALf8iYEnMdK0g(u"࠵࠵૲"),TVnqDYzWoM2UfHp0dchJ(u"࠶࠽૴")],wPnfgxKZdAv6T10(u"࠻࠰࠱૶"),ASkvf27etUK0(u"࠼࠴࠵૳")
	elif gAwLHrUqKY6tZVcOh==zpx2fPNKk6Ms38eD1vcO(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭੄"): W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠷࠵࠲૷"),vMhFypGLHZJbdX4O7oc3W8x(u"࠲࠴࠺࠴૸")
	elif gAwLHrUqKY6tZVcOh==uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ੅"): W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = gCkRKGhwcx26v(u"࡛ࠬࡐࡑࡇࡕࠫ੆"),Ns6AJKH7DGpr19Wl5C3nF(u"࠳࠵࠻࠵ૹ")
	elif gAwLHrUqKY6tZVcOh==wPnfgxKZdAv6T10(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੇ"): GG4IBLDKUAarc8PdxXCw,W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = [gCkRKGhwcx26v(u"࠸࠸૽"),uqLUBHepfM3l6AyIzTJh80a(u"࠲࠴૾"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠵࠽ૻ")],NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺࠸࠵ૺ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶࠸࠷࠱ૼ")
	elif gAwLHrUqKY6tZVcOh==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪੈ"): GG4IBLDKUAarc8PdxXCw,W7fYAGHOQETreI,jAEmVwnsF7apgTQROli8Dv = [iDhLkZS6XBagNCQfs9tq2(u"࠵࠼ଁ"),uqLUBHepfM3l6AyIzTJh80a(u"࠶࠸ଂ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠳࠻଀")],Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡗࡓࡔࡊࡘࠧ੉"),zpx2fPNKk6Ms38eD1vcO(u"࠲࠴࠺࠴૿")
	xh3FgaRLCPKY6,VGzDiWkrF8XoQLe1Tyv4,QicUGekJZCp1gw84uh6TvYD = GG4IBLDKUAarc8PdxXCw
	vvur9Ma1VpSbfQIRwyqNFAO7 = LknU0Q5lDacKWVBr6vg8PmHJj9.truetype(rrzstBgpPX,size=xh3FgaRLCPKY6)
	cHrFyj9sVUz = LknU0Q5lDacKWVBr6vg8PmHJj9.truetype(rrzstBgpPX,size=VGzDiWkrF8XoQLe1Tyv4)
	yHdpaWBmxAS71efKPhQDbj = LknU0Q5lDacKWVBr6vg8PmHJj9.truetype(rrzstBgpPX,size=QicUGekJZCp1gw84uh6TvYD)
	mm1HsM4SyjhFAZtW7TGd8uBPV = jAEmVwnsF7apgTQROli8Dv-wkOJVU3PZoTi0D9X4I6zAh*JhTts2R43AxkM8bYanKVy
	Qi6KxNOEmnutGbHPeaWc9ZAvh3 = JNRHvAFDg4KsEf.new(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡕࡋࡇࡇࠧ੊"),(mm1HsM4SyjhFAZtW7TGd8uBPV,uqLUBHepfM3l6AyIzTJh80a(u"࠶࠶࠰ଃ")),(zpx2fPNKk6Ms38eD1vcO(u"࠸࠵࠶଄"),zpx2fPNKk6Ms38eD1vcO(u"࠸࠵࠶଄"),zpx2fPNKk6Ms38eD1vcO(u"࠸࠵࠶଄"),wvkDqmNZlJU52isXo))
	xCTjSHWvRqbYk = QI3O9TxBZq8rshbt6KuED2iyzvJVFg.Draw(Qi6KxNOEmnutGbHPeaWc9ZAvh3)
	e0bTNJiIcSgphHxZ,PheUWi76HGsT4AQI2oxp = xCTjSHWvRqbYk.textsize(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬੋ"),font=vvur9Ma1VpSbfQIRwyqNFAO7)
	cYJI217Bpdg50UEn,F06FnVHrTfRdiK9hMJeaEmXt = xCTjSHWvRqbYk.textsize(zpx2fPNKk6Ms38eD1vcO(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ੌ"),font=cHrFyj9sVUz)
	g4g38AQcm0x5VL = {l7kBpMw5Qn(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡮ࡡࡳࡣ࡮ࡥࡹ੍࠭"):mrhSYXH2P8bO3eJAa9n,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡳࡶࡲࡳࡳࡷࡺ࡟࡭࡫ࡪࡥࡹࡻࡲࡦࡵࠪ੎"):BBX9RAuxnyGZ4WIF2TrhYeom3,TVnqDYzWoM2UfHp0dchJ(u"ࠧࡂࡔࡄࡆࡎࡉࠠࡍࡋࡊࡅ࡙࡛ࡒࡆࠢࡄࡐࡑࡇࡈࠨ੏"):mrhSYXH2P8bO3eJAa9n}
	from arabic_reshaper import ArabicReshaper as dd08vKCnuDZjtkXNayMU
	b4DqhmZaQFNrsVXKJBSpuz = dd08vKCnuDZjtkXNayMU(configuration=g4g38AQcm0x5VL)
	gxHiyhrj96uWOSb5DzU3eNT = {}
	UbMvOdYJhr9 = locals()
	for WbCSjAfYNB95pXz8awDqRZo in UbMvOdYJhr9: gxHiyhrj96uWOSb5DzU3eNT[WbCSjAfYNB95pXz8awDqRZo] = UbMvOdYJhr9[WbCSjAfYNB95pXz8awDqRZo]
	return gxHiyhrj96uWOSb5DzU3eNT
def pxlSIi2uVmEvD6njz1h(gxHiyhrj96uWOSb5DzU3eNT,IAde17rNHUk,y9UK4O2vhkr5iaXeRpQTDdCw,uCnRZp5LGv61g,mVP1EsO9TYHX6,Yg36raSGA02uUXEPMF7itZd9KcWf,gAwLHrUqKY6tZVcOh,myoSjiaU1Q3M,ka2bJK5t683cxzlF,xTy789mirzJf21):
	for WbCSjAfYNB95pXz8awDqRZo in gxHiyhrj96uWOSb5DzU3eNT: globals()[WbCSjAfYNB95pXz8awDqRZo] = gxHiyhrj96uWOSb5DzU3eNT[WbCSjAfYNB95pXz8awDqRZo]
	global qq5s4TcUKfz0AvuwmC,yJNxPCEib9B5
	if gAwLHrUqKY6tZVcOh!=Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ੐"):
		dI1DwAcTRCWzQKEYukmxb = MMAUZiw4CoJ8.getSetting(TVnqDYzWoM2UfHp0dchJ(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪੑ"))
		if dI1DwAcTRCWzQKEYukmxb:
			if IAde17rNHUk==Izy1PvclrYx4eSVWn0L5phZbq(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬ੒"): IAde17rNHUk = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࡞࡫ࡳࠨ੓")
			elif IAde17rNHUk==xxRyYsrSCzjifvH4cIqgldeOo(u"้ࠬไศࠢࠣࡒࡴ࠭੔"): IAde17rNHUk = TVnqDYzWoM2UfHp0dchJ(u"࠭ࡎࡰࠩ੕")
			if y9UK4O2vhkr5iaXeRpQTDdCw==czvu7VQCZodkMf(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩ੖"): y9UK4O2vhkr5iaXeRpQTDdCw = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࡛ࡨࡷࠬ੗")
			elif y9UK4O2vhkr5iaXeRpQTDdCw==fp6KV7DlS8QYniUczHdmZChL(u"ࠩๆ่ฬࠦࠠࡏࡱࠪ੘"): y9UK4O2vhkr5iaXeRpQTDdCw = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡒࡴ࠭ਖ਼")
			if uCnRZp5LGv61g==uqLUBHepfM3l6AyIzTJh80a(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ਗ਼"): uCnRZp5LGv61g = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬ࡟ࡥࡴࠩਜ਼")
			elif uCnRZp5LGv61g==gCkRKGhwcx26v(u"࠭ใๅษࠣࠤࡓࡵࠧੜ"): uCnRZp5LGv61g = C3w6qluao7EzUxJgMGBtV(u"ࠧࡏࡱࠪ੝")
			import RyvhfqnkAZ
			hoVT09XER3Jp6sL5 = RyvhfqnkAZ.rA6GfOLgTFNzvRPQ1nViDlps7k9([IAde17rNHUk,y9UK4O2vhkr5iaXeRpQTDdCw,uCnRZp5LGv61g,mVP1EsO9TYHX6,Yg36raSGA02uUXEPMF7itZd9KcWf])
			if hoVT09XER3Jp6sL5: IAde17rNHUk,y9UK4O2vhkr5iaXeRpQTDdCw,uCnRZp5LGv61g,mVP1EsO9TYHX6,Yg36raSGA02uUXEPMF7itZd9KcWf = hoVT09XER3Jp6sL5
	if psS8dmb912iRBgGc7qOPyCZ6:
		Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.decode(Tv08xsf9HOqunIVUPdK1)
		mVP1EsO9TYHX6 = mVP1EsO9TYHX6.decode(Tv08xsf9HOqunIVUPdK1)
		IAde17rNHUk = IAde17rNHUk.decode(Tv08xsf9HOqunIVUPdK1)
		y9UK4O2vhkr5iaXeRpQTDdCw = y9UK4O2vhkr5iaXeRpQTDdCw.decode(Tv08xsf9HOqunIVUPdK1)
		uCnRZp5LGv61g = uCnRZp5LGv61g.decode(Tv08xsf9HOqunIVUPdK1)
	sPBlMINk4Dot36RTYOK = mVP1EsO9TYHX6.count(u43PVWjh7t9YwI)+nyUIsfd53EGot9vbj0XDeq
	MVGIseFwHuDg6hLP = ddo510iPQFSUgKGq3IDrftWjxLksbJ+sPBlMINk4Dot36RTYOK*(PheUWi76HGsT4AQI2oxp+vFUdWHwCQVrS4KxyRIg30poNE)-vFUdWHwCQVrS4KxyRIg30poNE
	if Yg36raSGA02uUXEPMF7itZd9KcWf:
		JVblp8OqUczMfG1IjBFH7w6h = F06FnVHrTfRdiK9hMJeaEmXt+QjlCb8iJzVU1XO3a6
		r0BvisyHuU2 = b4DqhmZaQFNrsVXKJBSpuz.reshape(Yg36raSGA02uUXEPMF7itZd9KcWf)
		if W1Ry0gajibrs35:
			qKbSIyj1BQs73vkfXV5e = ooEzhMgUTsqdA9xPy2NmvBFkQ(xCTjSHWvRqbYk,cHrFyj9sVUz,r0BvisyHuU2,VGzDiWkrF8XoQLe1Tyv4,mm1HsM4SyjhFAZtW7TGd8uBPV,JVblp8OqUczMfG1IjBFH7w6h)
			POHX7hb4nNu32IvJ = Y2qMZ1vaTkWtjH9f7uBi3wyI(qKbSIyj1BQs73vkfXV5e)
			tSICvhUHak9DYzd = POHX7hb4nNu32IvJ.count(u43PVWjh7t9YwI)+nyUIsfd53EGot9vbj0XDeq
			AkN7R6OrbqJ0tF21eSZszoE = JLgu1Yxv7Vl3wsoD9nC4dNIr+tSICvhUHak9DYzd*JVblp8OqUczMfG1IjBFH7w6h-QjlCb8iJzVU1XO3a6
		else:
			AkN7R6OrbqJ0tF21eSZszoE = JLgu1Yxv7Vl3wsoD9nC4dNIr+F06FnVHrTfRdiK9hMJeaEmXt
			POHX7hb4nNu32IvJ = r0BvisyHuU2.split(u43PVWjh7t9YwI)[wvkDqmNZlJU52isXo]
			qKbSIyj1BQs73vkfXV5e = r0BvisyHuU2.split(u43PVWjh7t9YwI)[wvkDqmNZlJU52isXo]
	else: AkN7R6OrbqJ0tF21eSZszoE = JLgu1Yxv7Vl3wsoD9nC4dNIr
	nnKRlvNS57paBryID = vz3s65dg0MwN1KSBD9HWpFuP+EmhFfr8YKlNXBM0idjPVk5zaUwC
	if ka2bJK5t683cxzlF:
		VP7oLMNA5IKhT = j4tkWE2M1eOhlH0wboxAqQJcpdDv-HHryJpgFLdCVvZ6zaDP9
		nnKRlvNS57paBryID += VP7oLMNA5IKhT
	else: VP7oLMNA5IKhT = wvkDqmNZlJU52isXo
	if IAde17rNHUk or y9UK4O2vhkr5iaXeRpQTDdCw or uCnRZp5LGv61g: nnKRlvNS57paBryID += iTKAgZMJrqtQeR
	ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo = W7fYAGHOQETreI if W7fYAGHOQETreI!=uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡗࡓࡔࡊࡘࠧਫ਼") else MVGIseFwHuDg6hLP+AkN7R6OrbqJ0tF21eSZszoE+nnKRlvNS57paBryID
	Qi6KxNOEmnutGbHPeaWc9ZAvh3 = JNRHvAFDg4KsEf.new(sTGtHVyhQ9cJU37zxo2O(u"ࠩࡕࡋࡇࡇࠧ੟"),(jAEmVwnsF7apgTQROli8Dv,ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo),(VOALf8iYEnMdK0g(u"࠲࠶࠷ଅ"),VOALf8iYEnMdK0g(u"࠲࠶࠷ଅ"),VOALf8iYEnMdK0g(u"࠲࠶࠷ଅ"),wvkDqmNZlJU52isXo))
	ABgthxl5LosRqjJXp = QI3O9TxBZq8rshbt6KuED2iyzvJVFg.Draw(Qi6KxNOEmnutGbHPeaWc9ZAvh3)
	dWgOPAbtEQwyJhavzDUx = ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo-MVGIseFwHuDg6hLP-nnKRlvNS57paBryID-JLgu1Yxv7Vl3wsoD9nC4dNIr
	if not y9UK4O2vhkr5iaXeRpQTDdCw and IAde17rNHUk and uCnRZp5LGv61g:
		qq5s4TcUKfz0AvuwmC += qeYIw0BNTL9bGJnosacQ1DtVR(u"࠲࠲࠸ଆ")
		yJNxPCEib9B5 -= gCkRKGhwcx26v(u"࠳࠴࠴ଇ")
	import bidi.algorithm as uXI7kZeJaUibBQ3n6coz1
	if mVP1EsO9TYHX6:
		fD9dkRGzc7S0umJL8QVZxes1Fn6lY = ddo510iPQFSUgKGq3IDrftWjxLksbJ
		mVP1EsO9TYHX6 = uXI7kZeJaUibBQ3n6coz1.get_display(b4DqhmZaQFNrsVXKJBSpuz.reshape(mVP1EsO9TYHX6))
		mKguiz74rjwFLT1 = mVP1EsO9TYHX6.splitlines()
		for Ok5XpynWJh1eoRb2mvsGN7uEaKVHI in mKguiz74rjwFLT1:
			if Ok5XpynWJh1eoRb2mvsGN7uEaKVHI:
				Q8wSGtoRLTyfci,ZHKpA51gd7rmIFkVJOviWsUG06 = ABgthxl5LosRqjJXp.textsize(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,font=vvur9Ma1VpSbfQIRwyqNFAO7)
				if AnFHjVD2tYvMaQZRWrhsUmc1f==iDhLkZS6XBagNCQfs9tq2(u"ࠪࡧࡪࡴࡴࡦࡴࠪ੠"): nCphtFzqvOkZReAV7xUEX1 = hORKiVQTgv0I9wA+(jAEmVwnsF7apgTQROli8Dv-Q8wSGtoRLTyfci)/JhTts2R43AxkM8bYanKVy
				elif AnFHjVD2tYvMaQZRWrhsUmc1f==DQIrVcKuY6bJv(u"ࠫࡷ࡯ࡧࡩࡶࠪ੡"): nCphtFzqvOkZReAV7xUEX1 = hORKiVQTgv0I9wA+jAEmVwnsF7apgTQROli8Dv-Q8wSGtoRLTyfci-nkDHZzRBol2O
				elif AnFHjVD2tYvMaQZRWrhsUmc1f==VOALf8iYEnMdK0g(u"ࠬࡲࡥࡧࡶࠪ੢"): nCphtFzqvOkZReAV7xUEX1 = hORKiVQTgv0I9wA+nkDHZzRBol2O
				ABgthxl5LosRqjJXp.text((nCphtFzqvOkZReAV7xUEX1,fD9dkRGzc7S0umJL8QVZxes1Fn6lY),Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,font=vvur9Ma1VpSbfQIRwyqNFAO7,fill=gCkRKGhwcx26v(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭੣"))
			fD9dkRGzc7S0umJL8QVZxes1Fn6lY += xh3FgaRLCPKY6+vFUdWHwCQVrS4KxyRIg30poNE
	if IAde17rNHUk or y9UK4O2vhkr5iaXeRpQTDdCw or uCnRZp5LGv61g:
		ffOP80tCi7vsGAI6jErow = MVGIseFwHuDg6hLP+dWgOPAbtEQwyJhavzDUx+JLgu1Yxv7Vl3wsoD9nC4dNIr+VP7oLMNA5IKhT+vz3s65dg0MwN1KSBD9HWpFuP
		if IAde17rNHUk:
			IAde17rNHUk = uXI7kZeJaUibBQ3n6coz1.get_display(b4DqhmZaQFNrsVXKJBSpuz.reshape(IAde17rNHUk))
			nnw1zyRGTgH4WbkECMeXKsYNq2iuS,cv0gRthIoWOFJaENCdrBw91zbViUeP = ABgthxl5LosRqjJXp.textsize(IAde17rNHUk,font=yHdpaWBmxAS71efKPhQDbj)
			CCyYd3rplvw5 = qq5s4TcUKfz0AvuwmC+wvkDqmNZlJU52isXo*(yJNxPCEib9B5+iO2M4PTW5m)+(iO2M4PTW5m-nnw1zyRGTgH4WbkECMeXKsYNq2iuS)/JhTts2R43AxkM8bYanKVy
			ABgthxl5LosRqjJXp.text((CCyYd3rplvw5,ffOP80tCi7vsGAI6jErow),IAde17rNHUk,font=yHdpaWBmxAS71efKPhQDbj,fill=bcNqYtfET5l92dLGjyZSPe(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ੤"))
		if y9UK4O2vhkr5iaXeRpQTDdCw:
			y9UK4O2vhkr5iaXeRpQTDdCw = uXI7kZeJaUibBQ3n6coz1.get_display(b4DqhmZaQFNrsVXKJBSpuz.reshape(y9UK4O2vhkr5iaXeRpQTDdCw))
			G6fm1R5OgUCdM4ArWZu83Qxy0eIs,jxm4n5FOeHC = ABgthxl5LosRqjJXp.textsize(y9UK4O2vhkr5iaXeRpQTDdCw,font=yHdpaWBmxAS71efKPhQDbj)
			c6cIVOrU2hF0XuQK = qq5s4TcUKfz0AvuwmC+nyUIsfd53EGot9vbj0XDeq*(yJNxPCEib9B5+iO2M4PTW5m)+(iO2M4PTW5m-G6fm1R5OgUCdM4ArWZu83Qxy0eIs)/JhTts2R43AxkM8bYanKVy
			ABgthxl5LosRqjJXp.text((c6cIVOrU2hF0XuQK,ffOP80tCi7vsGAI6jErow),y9UK4O2vhkr5iaXeRpQTDdCw,font=yHdpaWBmxAS71efKPhQDbj,fill=v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡻࡨࡰࡱࡵࡷࠨ੥"))
		if uCnRZp5LGv61g:
			uCnRZp5LGv61g = uXI7kZeJaUibBQ3n6coz1.get_display(b4DqhmZaQFNrsVXKJBSpuz.reshape(uCnRZp5LGv61g))
			guKBOUVWNmY9kPDhFw1qzJTybM,j5uMWSnFR8eXpt = ABgthxl5LosRqjJXp.textsize(uCnRZp5LGv61g,font=yHdpaWBmxAS71efKPhQDbj)
			Zyq87f59RJPpOGrT4dSFQ0oMYv1a = qq5s4TcUKfz0AvuwmC+JhTts2R43AxkM8bYanKVy*(yJNxPCEib9B5+iO2M4PTW5m)+(iO2M4PTW5m-guKBOUVWNmY9kPDhFw1qzJTybM)/JhTts2R43AxkM8bYanKVy
			ABgthxl5LosRqjJXp.text((Zyq87f59RJPpOGrT4dSFQ0oMYv1a,ffOP80tCi7vsGAI6jErow),uCnRZp5LGv61g,font=yHdpaWBmxAS71efKPhQDbj,fill=TVnqDYzWoM2UfHp0dchJ(u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ੦"))
	if Yg36raSGA02uUXEPMF7itZd9KcWf:
		rKBxknVcitpLmEOjqMCeQ0S95globh,gJoQju7Ar1wDvNZ2qLVEcP3yCX9Ii = [],[]
		qKbSIyj1BQs73vkfXV5e = LJmlHM46nQT2AfCXcNdUBPE(qKbSIyj1BQs73vkfXV5e)
		NHx7IUu2YZPDnbJ9XRs8Ej1p6ci0yV = qKbSIyj1BQs73vkfXV5e.split(ALwOspNtXxZrz3PEKku(u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ੧"))
		for BveNJA6QTcHk in NHx7IUu2YZPDnbJ9XRs8Ej1p6ci0yV:
			Ghws39P7kfCZop8VTqXJtjR6Oe = myoSjiaU1Q3M
			if   j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭੨") in BveNJA6QTcHk: Ghws39P7kfCZop8VTqXJtjR6Oe = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡲࡥࡧࡶࠪ੩")
			elif v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ੪") in BveNJA6QTcHk: Ghws39P7kfCZop8VTqXJtjR6Oe = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭੫")
			elif czvu7VQCZodkMf(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ੬") in BveNJA6QTcHk: Ghws39P7kfCZop8VTqXJtjR6Oe = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡦࡩࡳࡺࡥࡳࠩ੭")
			dBsZlza0SKjYF1hCH5e3 = BveNJA6QTcHk
			T8I2wCbgMxu7iOLpQaPFyARBXn6USd = X2XorVqHjLkWeCchY4u9fSz.findall(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ੮"),BveNJA6QTcHk,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for OrqevmSMUfg1QEhHusdzxJL in T8I2wCbgMxu7iOLpQaPFyARBXn6USd: dBsZlza0SKjYF1hCH5e3 = dBsZlza0SKjYF1hCH5e3.replace(OrqevmSMUfg1QEhHusdzxJL,SebHIf2jL1TBgrMKJu)
			if dBsZlza0SKjYF1hCH5e3==SebHIf2jL1TBgrMKJu: Q8wSGtoRLTyfci,ZHKpA51gd7rmIFkVJOviWsUG06 = wvkDqmNZlJU52isXo,JVblp8OqUczMfG1IjBFH7w6h
			else: Q8wSGtoRLTyfci,ZHKpA51gd7rmIFkVJOviWsUG06 = ABgthxl5LosRqjJXp.textsize(dBsZlza0SKjYF1hCH5e3,font=cHrFyj9sVUz)
			if   Ghws39P7kfCZop8VTqXJtjR6Oe==Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡱ࡫ࡦࡵࠩ੯"): PyfkU3nXCpSJlMuQTGBawYLIoj = v6K9kHiwcyLrYURxlapD4Vn+wkOJVU3PZoTi0D9X4I6zAh
			elif Ghws39P7kfCZop8VTqXJtjR6Oe==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡸࡩࡨࡪࡷࠫੰ"): PyfkU3nXCpSJlMuQTGBawYLIoj = v6K9kHiwcyLrYURxlapD4Vn+wkOJVU3PZoTi0D9X4I6zAh+mm1HsM4SyjhFAZtW7TGd8uBPV-Q8wSGtoRLTyfci
			elif Ghws39P7kfCZop8VTqXJtjR6Oe==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ੱ"): PyfkU3nXCpSJlMuQTGBawYLIoj = v6K9kHiwcyLrYURxlapD4Vn+wkOJVU3PZoTi0D9X4I6zAh+(mm1HsM4SyjhFAZtW7TGd8uBPV-Q8wSGtoRLTyfci)/JhTts2R43AxkM8bYanKVy
			if PyfkU3nXCpSJlMuQTGBawYLIoj<wkOJVU3PZoTi0D9X4I6zAh: PyfkU3nXCpSJlMuQTGBawYLIoj = v6K9kHiwcyLrYURxlapD4Vn+wkOJVU3PZoTi0D9X4I6zAh
			rKBxknVcitpLmEOjqMCeQ0S95globh.append(PyfkU3nXCpSJlMuQTGBawYLIoj)
			gJoQju7Ar1wDvNZ2qLVEcP3yCX9Ii.append(Q8wSGtoRLTyfci)
		PyfkU3nXCpSJlMuQTGBawYLIoj = rKBxknVcitpLmEOjqMCeQ0S95globh[wvkDqmNZlJU52isXo]
		ApK3cJfOvExSdhz2w7910IjnHyVWR = qKbSIyj1BQs73vkfXV5e.split(l7kBpMw5Qn(u"ࠧࡠࡵࡶࡷࡤ࠭ੲ"))
		dHplPE83Aab = (xxRyYsrSCzjifvH4cIqgldeOo(u"࠵࠹࠺ଈ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠵࠹࠺ଈ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠵࠹࠺ଈ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠵࠹࠺ଈ"))
		hguLS8VIq7aK = dHplPE83Aab
		l52Gn9gMUKQ4dTAsb6OJ3tYE,qqayCv1fQe = wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
		n1nqxBO3bV0RFtYEUzvI8cpCGyX = mrhSYXH2P8bO3eJAa9n
		jhV0eQ6SOl4yFnfrxHv5PAbNM = wvkDqmNZlJU52isXo
		ohUrZglwjWf4itJ2EDkvV = MVGIseFwHuDg6hLP+JLgu1Yxv7Vl3wsoD9nC4dNIr/JhTts2R43AxkM8bYanKVy
		if AkN7R6OrbqJ0tF21eSZszoE<(dWgOPAbtEQwyJhavzDUx+JLgu1Yxv7Vl3wsoD9nC4dNIr):
			cKmhgCW6eFbq2IGfYxM9T = (dWgOPAbtEQwyJhavzDUx+JLgu1Yxv7Vl3wsoD9nC4dNIr-AkN7R6OrbqJ0tF21eSZszoE)/JhTts2R43AxkM8bYanKVy
			ohUrZglwjWf4itJ2EDkvV = MVGIseFwHuDg6hLP+JLgu1Yxv7Vl3wsoD9nC4dNIr+cKmhgCW6eFbq2IGfYxM9T-F06FnVHrTfRdiK9hMJeaEmXt/JhTts2R43AxkM8bYanKVy
		for Ok5XpynWJh1eoRb2mvsGN7uEaKVHI in ApK3cJfOvExSdhz2w7910IjnHyVWR:
			if not Ok5XpynWJh1eoRb2mvsGN7uEaKVHI or (Ok5XpynWJh1eoRb2mvsGN7uEaKVHI and ord(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI[wvkDqmNZlJU52isXo])==AGlW9LqKN3Dvo(u"࠺࠺࠸࠷࠺ଉ")): continue
			t9FxODyiug1LXcekSa7 = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫੳ"),nyUIsfd53EGot9vbj0XDeq)
			IeoqJMiCZDlyPSN84Y = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬੴ"),nyUIsfd53EGot9vbj0XDeq)
			QhmdbpuMON5WCHXloBzRtKf = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧੵ"),nyUIsfd53EGot9vbj0XDeq)
			n0Est1akYTBClRIKSFwdx = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(HCiWF4jV1Q8(u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ੶"),nyUIsfd53EGot9vbj0XDeq)
			bsu38OMNBDhwyLGkzPd90le26QXKJ = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ੷"),nyUIsfd53EGot9vbj0XDeq)
			WjCJDnMm0QK3BytzAT = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(DQIrVcKuY6bJv(u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ੸"),nyUIsfd53EGot9vbj0XDeq)
			DNIg9WRjv1l = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI.split(zpx2fPNKk6Ms38eD1vcO(u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭੹"),nyUIsfd53EGot9vbj0XDeq)
			if len(t9FxODyiug1LXcekSa7)>nyUIsfd53EGot9vbj0XDeq:
				jhV0eQ6SOl4yFnfrxHv5PAbNM += nyUIsfd53EGot9vbj0XDeq
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = t9FxODyiug1LXcekSa7[nyUIsfd53EGot9vbj0XDeq]
				l52Gn9gMUKQ4dTAsb6OJ3tYE = wvkDqmNZlJU52isXo
				PyfkU3nXCpSJlMuQTGBawYLIoj = rKBxknVcitpLmEOjqMCeQ0S95globh[jhV0eQ6SOl4yFnfrxHv5PAbNM]
				qqayCv1fQe += JVblp8OqUczMfG1IjBFH7w6h
				n1nqxBO3bV0RFtYEUzvI8cpCGyX = mrhSYXH2P8bO3eJAa9n
			elif len(IeoqJMiCZDlyPSN84Y)>nyUIsfd53EGot9vbj0XDeq:
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = IeoqJMiCZDlyPSN84Y[nyUIsfd53EGot9vbj0XDeq]
				hguLS8VIq7aK = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI[wvkDqmNZlJU52isXo:HCiWF4jV1Q8(u"࠽ଊ")]
				hguLS8VIq7aK = ASkvf27etUK0(u"ࠨࠥࠪ੺")+hguLS8VIq7aK[JhTts2R43AxkM8bYanKVy:]
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = Ok5XpynWJh1eoRb2mvsGN7uEaKVHI[bcNqYtfET5l92dLGjyZSPe(u"࠿ଋ"):]
			elif len(QhmdbpuMON5WCHXloBzRtKf)>nyUIsfd53EGot9vbj0XDeq:
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = QhmdbpuMON5WCHXloBzRtKf[nyUIsfd53EGot9vbj0XDeq]
				hguLS8VIq7aK = dHplPE83Aab
			elif len(n0Est1akYTBClRIKSFwdx)>nyUIsfd53EGot9vbj0XDeq:
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = n0Est1akYTBClRIKSFwdx[nyUIsfd53EGot9vbj0XDeq]
				n1nqxBO3bV0RFtYEUzvI8cpCGyX = BBX9RAuxnyGZ4WIF2TrhYeom3
				l52Gn9gMUKQ4dTAsb6OJ3tYE = gJoQju7Ar1wDvNZ2qLVEcP3yCX9Ii[jhV0eQ6SOl4yFnfrxHv5PAbNM]
			elif len(bsu38OMNBDhwyLGkzPd90le26QXKJ)>Gykx0wL3XrlWaujsqKP9n2Q(u"࠱ଌ"): Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = bsu38OMNBDhwyLGkzPd90le26QXKJ[nyUIsfd53EGot9vbj0XDeq]
			elif len(WjCJDnMm0QK3BytzAT)>sTGtHVyhQ9cJU37zxo2O(u"࠲଍"): Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = WjCJDnMm0QK3BytzAT[nyUIsfd53EGot9vbj0XDeq]
			elif len(DNIg9WRjv1l)>ALwOspNtXxZrz3PEKku(u"࠳଎"): Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = DNIg9WRjv1l[nyUIsfd53EGot9vbj0XDeq]
			if Ok5XpynWJh1eoRb2mvsGN7uEaKVHI:
				q9qiQFTc7EugGk6h2xRJPYsAUXv = ohUrZglwjWf4itJ2EDkvV+qqayCv1fQe
				Ok5XpynWJh1eoRb2mvsGN7uEaKVHI = uXI7kZeJaUibBQ3n6coz1.get_display(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI)
				Q8wSGtoRLTyfci,ZHKpA51gd7rmIFkVJOviWsUG06 = ABgthxl5LosRqjJXp.textsize(Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,font=cHrFyj9sVUz)
				if n1nqxBO3bV0RFtYEUzvI8cpCGyX: l52Gn9gMUKQ4dTAsb6OJ3tYE -= Q8wSGtoRLTyfci
				vxdft15CZhg2Jc = PyfkU3nXCpSJlMuQTGBawYLIoj+l52Gn9gMUKQ4dTAsb6OJ3tYE
				ABgthxl5LosRqjJXp.text((vxdft15CZhg2Jc,q9qiQFTc7EugGk6h2xRJPYsAUXv),Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,font=cHrFyj9sVUz,fill=hguLS8VIq7aK)
				if gAwLHrUqKY6tZVcOh==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ੻"): ABgthxl5LosRqjJXp.text((vxdft15CZhg2Jc+nyUIsfd53EGot9vbj0XDeq,q9qiQFTc7EugGk6h2xRJPYsAUXv+nyUIsfd53EGot9vbj0XDeq),Ok5XpynWJh1eoRb2mvsGN7uEaKVHI,font=cHrFyj9sVUz,fill=hguLS8VIq7aK)
				if not n1nqxBO3bV0RFtYEUzvI8cpCGyX: l52Gn9gMUKQ4dTAsb6OJ3tYE += Q8wSGtoRLTyfci
				if q9qiQFTc7EugGk6h2xRJPYsAUXv>dWgOPAbtEQwyJhavzDUx+JVblp8OqUczMfG1IjBFH7w6h: break
	if gAwLHrUqKY6tZVcOh==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭੼"):
		Y8fDzoMVix3UAdGWQbKPr = mTJOE2VygwdoCHfrMR5qjtz.copy()
		uv8V4fE7j9pmgFr3wnDL.sleep(fp6KV7DlS8QYniUczHdmZChL(u"࠳࠲࠵࠻ଏ"))
		Y8fDzoMVix3UAdGWQbKPr.paste(y4ykitIPNef,(wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo),mask=Qi6KxNOEmnutGbHPeaWc9ZAvh3)
	else: Y8fDzoMVix3UAdGWQbKPr = Qi6KxNOEmnutGbHPeaWc9ZAvh3
	if psS8dmb912iRBgGc7qOPyCZ6: xTy789mirzJf21 = xTy789mirzJf21.decode(Tv08xsf9HOqunIVUPdK1)
	try: Y8fDzoMVix3UAdGWQbKPr.save(xTy789mirzJf21)
	except UnicodeError:
		if psS8dmb912iRBgGc7qOPyCZ6:
			xTy789mirzJf21 = xTy789mirzJf21.encode(Tv08xsf9HOqunIVUPdK1)
			Y8fDzoMVix3UAdGWQbKPr.save(xTy789mirzJf21)
	return ZZeRAvE2Nk36Icp1s9qrjLHf5YmPo
def ooEzhMgUTsqdA9xPy2NmvBFkQ(xCTjSHWvRqbYk,cHrFyj9sVUz,xUHzD7IdGanNMkB,NmI9l5xH8Fep1iVSGOW,mm1HsM4SyjhFAZtW7TGd8uBPV,XX8xQ4H6gEoKMIm37cjdwDGsZek):
	wTOkIxqyaYpUzcRG8sQ7MHCS,cP2lx1WIm5KZoVa,rfe978YbZ4HDIMy3hd5KOjklPX = SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo,vMhFypGLHZJbdX4O7oc3W8x(u"࠵࠺࠶࠰࠱ଐ")
	xUHzD7IdGanNMkB = xUHzD7IdGanNMkB.replace(VOALf8iYEnMdK0g(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ੽"),DQIrVcKuY6bJv(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ੾"))
	FFvKGBkufzQhlpqnSCZEO1 = mm1HsM4SyjhFAZtW7TGd8uBPV-NmI9l5xH8Fep1iVSGOW*JhTts2R43AxkM8bYanKVy
	for OhZTyXAqPu8mx in xUHzD7IdGanNMkB.splitlines():
		cP2lx1WIm5KZoVa += XX8xQ4H6gEoKMIm37cjdwDGsZek
		qjfoG0TiY2yms94SZBHp1vChQkA6aX,zQr4H6vtyg3WjD = wvkDqmNZlJU52isXo,SebHIf2jL1TBgrMKJu
		for dde3ADztfVo6ahSWsnELBygPl0ZJG in OhZTyXAqPu8mx.split(qE4nB3mKWHs):
			OOJFngbm9ofTyvhqdAQZ = Y2qMZ1vaTkWtjH9f7uBi3wyI(qE4nB3mKWHs+dde3ADztfVo6ahSWsnELBygPl0ZJG)
			OuaC03JKLp4RiyAwsD1d,oq1IceYwWNkBf = xCTjSHWvRqbYk.textsize(OOJFngbm9ofTyvhqdAQZ,font=cHrFyj9sVUz)
			if qjfoG0TiY2yms94SZBHp1vChQkA6aX+OuaC03JKLp4RiyAwsD1d<FFvKGBkufzQhlpqnSCZEO1:
				if not zQr4H6vtyg3WjD: zQr4H6vtyg3WjD += dde3ADztfVo6ahSWsnELBygPl0ZJG
				else: zQr4H6vtyg3WjD += qE4nB3mKWHs+dde3ADztfVo6ahSWsnELBygPl0ZJG
				qjfoG0TiY2yms94SZBHp1vChQkA6aX += OuaC03JKLp4RiyAwsD1d
			else:
				if OuaC03JKLp4RiyAwsD1d<FFvKGBkufzQhlpqnSCZEO1:
					zQr4H6vtyg3WjD += HADrRCz9QgU4xudPJIqYb70(u"࠭࡜࡯ࠢࠪ੿")+dde3ADztfVo6ahSWsnELBygPl0ZJG
					cP2lx1WIm5KZoVa += XX8xQ4H6gEoKMIm37cjdwDGsZek
					qjfoG0TiY2yms94SZBHp1vChQkA6aX = OuaC03JKLp4RiyAwsD1d
				else:
					while OuaC03JKLp4RiyAwsD1d>FFvKGBkufzQhlpqnSCZEO1:
						for k67x1WiUM34JdvBYLFwpe2 in range(nyUIsfd53EGot9vbj0XDeq,len(qE4nB3mKWHs+dde3ADztfVo6ahSWsnELBygPl0ZJG),nyUIsfd53EGot9vbj0XDeq):
							nHaoMWFAuBp = qE4nB3mKWHs+dde3ADztfVo6ahSWsnELBygPl0ZJG[:k67x1WiUM34JdvBYLFwpe2]
							mbp2gq3a9WnYlu = dde3ADztfVo6ahSWsnELBygPl0ZJG[k67x1WiUM34JdvBYLFwpe2:]
							CSk3QBTjmWpiGtgEPJ8eU5dNLo = Y2qMZ1vaTkWtjH9f7uBi3wyI(nHaoMWFAuBp)
							ffSFLBhcTZr,lTPbeiW6ZpzaX0NGJr = xCTjSHWvRqbYk.textsize(CSk3QBTjmWpiGtgEPJ8eU5dNLo,font=cHrFyj9sVUz)
							if qjfoG0TiY2yms94SZBHp1vChQkA6aX+ffSFLBhcTZr>FFvKGBkufzQhlpqnSCZEO1:
								uRmTYGMcCvkNHWpOaiVw5 = OuaC03JKLp4RiyAwsD1d-ffSFLBhcTZr
								zQr4H6vtyg3WjD += nHaoMWFAuBp+u43PVWjh7t9YwI
								cP2lx1WIm5KZoVa += XX8xQ4H6gEoKMIm37cjdwDGsZek
								OuaC03JKLp4RiyAwsD1d = uRmTYGMcCvkNHWpOaiVw5
								if uRmTYGMcCvkNHWpOaiVw5>FFvKGBkufzQhlpqnSCZEO1:
									qjfoG0TiY2yms94SZBHp1vChQkA6aX = wvkDqmNZlJU52isXo
									dde3ADztfVo6ahSWsnELBygPl0ZJG = mbp2gq3a9WnYlu
								else:
									qjfoG0TiY2yms94SZBHp1vChQkA6aX = uRmTYGMcCvkNHWpOaiVw5
									zQr4H6vtyg3WjD += mbp2gq3a9WnYlu
								break
				if cP2lx1WIm5KZoVa>rfe978YbZ4HDIMy3hd5KOjklPX: break
		wTOkIxqyaYpUzcRG8sQ7MHCS += u43PVWjh7t9YwI+zQr4H6vtyg3WjD
		if cP2lx1WIm5KZoVa>rfe978YbZ4HDIMy3hd5KOjklPX: break
	wTOkIxqyaYpUzcRG8sQ7MHCS = wTOkIxqyaYpUzcRG8sQ7MHCS[nyUIsfd53EGot9vbj0XDeq:]
	wTOkIxqyaYpUzcRG8sQ7MHCS = wTOkIxqyaYpUzcRG8sQ7MHCS.replace(bcNqYtfET5l92dLGjyZSPe(u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ઀"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩઁ"))
	return wTOkIxqyaYpUzcRG8sQ7MHCS
def Y2qMZ1vaTkWtjH9f7uBi3wyI(dde3ADztfVo6ahSWsnELBygPl0ZJG):
	if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࡞ࠫં") in dde3ADztfVo6ahSWsnELBygPl0ZJG and qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡡࠬઃ") in dde3ADztfVo6ahSWsnELBygPl0ZJG:
		T8I2wCbgMxu7iOLpQaPFyARBXn6USd = [XOVRfitWJP1zL3p2CMYF,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ઄"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭અ"),AGlW9LqKN3Dvo(u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨઆ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪઇ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ࡝ࡕࡘࡑࡣࠧઈ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩઉ"),l7kBpMw5Qn(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫઊ"),TVnqDYzWoM2UfHp0dchJ(u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭ઋ")]
		e7bl3rO1ojzSuFfR = X2XorVqHjLkWeCchY4u9fSz.findall(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬઌ"),dde3ADztfVo6ahSWsnELBygPl0ZJG,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		AfUqeZNjKdtCknRJ5z9lo617 = X2XorVqHjLkWeCchY4u9fSz.findall(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨઍ"),dde3ADztfVo6ahSWsnELBygPl0ZJG,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		gG4YtD53Bvwdsm = T8I2wCbgMxu7iOLpQaPFyARBXn6USd+e7bl3rO1ojzSuFfR+AfUqeZNjKdtCknRJ5z9lo617
		for OrqevmSMUfg1QEhHusdzxJL in gG4YtD53Bvwdsm: dde3ADztfVo6ahSWsnELBygPl0ZJG = dde3ADztfVo6ahSWsnELBygPl0ZJG.replace(OrqevmSMUfg1QEhHusdzxJL,SebHIf2jL1TBgrMKJu)
	return dde3ADztfVo6ahSWsnELBygPl0ZJG
def LJmlHM46nQT2AfCXcNdUBPE(Yg36raSGA02uUXEPMF7itZd9KcWf):
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(u43PVWjh7t9YwI,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ઎"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡝ࡕࡘࡑࡣࠧએ"),HCiWF4jV1Q8(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪઐ"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(zpx2fPNKk6Ms38eD1vcO(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪઑ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭઒"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭ઓ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩઔ"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(czvu7VQCZodkMf(u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩક"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬખ"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(XOVRfitWJP1zL3p2CMYF,uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫગ"))
	t1SgzRZL8DGmQo4kdrJKNc0FPvj = X2XorVqHjLkWeCchY4u9fSz.findall(VOALf8iYEnMdK0g(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬઘ"),Yg36raSGA02uUXEPMF7itZd9KcWf,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for jjTqbFCyGs0zkZNrQp in t1SgzRZL8DGmQo4kdrJKNc0FPvj: Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.replace(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬઙ")+jjTqbFCyGs0zkZNrQp+C3w6qluao7EzUxJgMGBtV(u"ࠬࡣࠧચ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧછ")+jjTqbFCyGs0zkZNrQp+bcNqYtfET5l92dLGjyZSPe(u"ࠧࡠࠩજ"))
	return Yg36raSGA02uUXEPMF7itZd9KcWf