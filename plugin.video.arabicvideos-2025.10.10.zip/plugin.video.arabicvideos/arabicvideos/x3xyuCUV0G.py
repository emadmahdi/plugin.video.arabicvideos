# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'GLOBALSEARCH'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_GLS_'
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf,Q8A5HyT1fGNxZv4X3V7eC):
	if   hL9fngBAu7XzOx==540: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif hL9fngBAu7XzOx==541: lfZmugQCFKLGT05AH29IsMiho = KERSXDlvmWexFz(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==542: lfZmugQCFKLGT05AH29IsMiho = oRju3krYanIAQt7O4(Yg36raSGA02uUXEPMF7itZd9KcWf,vCsnpu14Zi7qUEQg3Tl50h,Q8A5HyT1fGNxZv4X3V7eC)
	elif hL9fngBAu7XzOx==543: lfZmugQCFKLGT05AH29IsMiho = Hf6muiMKy8J()
	elif hL9fngBAu7XzOx==548: lfZmugQCFKLGT05AH29IsMiho = ItGFOflZ16gVQ0yq58P2wuCHMjYhXr(vCsnpu14Zi7qUEQg3Tl50h,Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==549: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(Yg36raSGA02uUXEPMF7itZd9KcWf)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder','بحث جديد لجميع المواقع',SebHIf2jL1TBgrMKJu,549)
	QUzFYoapm9jx('link','كيف يعمل بحث جميع المواقع','',543)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'==== كلمات البحث المخزنة ===='+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	d2dMvQFSBYIq1C8sNezGT = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if d2dMvQFSBYIq1C8sNezGT:
		d2dMvQFSBYIq1C8sNezGT = d2dMvQFSBYIq1C8sNezGT['__SEQUENCED_COLUMNS__']
		for IsqopSjwNr6W4klVD32JR1nhf in reversed(d2dMvQFSBYIq1C8sNezGT):
			QUzFYoapm9jx('folder',IsqopSjwNr6W4klVD32JR1nhf,SebHIf2jL1TBgrMKJu,549,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,IsqopSjwNr6W4klVD32JR1nhf)
	return
def yEPLitfHnvAdz0I9SVoC(IsqopSjwNr6W4klVD32JR1nhf):
	if not IsqopSjwNr6W4klVD32JR1nhf:
		IsqopSjwNr6W4klVD32JR1nhf = zWKdm3kV2ItwYrgH1BZyRON()
		if not IsqopSjwNr6W4klVD32JR1nhf: return
		IsqopSjwNr6W4klVD32JR1nhf = IsqopSjwNr6W4klVD32JR1nhf.lower()
	cQajTFxr5OL8KbgyN0 = IsqopSjwNr6W4klVD32JR1nhf.replace(FFe0IfYj65szqgLHkNpBPJnRQEmZo,SebHIf2jL1TBgrMKJu)
	dQzyh672wCc(cQajTFxr5OL8KbgyN0,'_ALL',True)
	QUzFYoapm9jx('link','بحث جماعي للمواقع - '+cQajTFxr5OL8KbgyN0,'search_sites_all',542,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('folder','بحث منفرد للمواقع - '+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,541,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder','نتائج البحث مفصلة - '+cQajTFxr5OL8KbgyN0,'opened_sites_all',542,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	QUzFYoapm9jx('folder','نتائج البحث مقسمة - '+cQajTFxr5OL8KbgyN0,'listed_sites_all',542,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,cQajTFxr5OL8KbgyN0)
	return
def dQzyh672wCc(LxYK9rzJEB4ObgV6w1N2SufRj,P3tyYHTlqnhgLfO0DzQ,xH0f4k6EWumUc5rB1IaZtzRn):
	if P3tyYHTlqnhgLfO0DzQ=='_ALL': U87kmdbyecZrqGRxgKXLlV1FtN = '_GLS_'
	elif P3tyYHTlqnhgLfO0DzQ=='_GOOGLE': U87kmdbyecZrqGRxgKXLlV1FtN = '_GOS_'
	w362w5g8LFyjKmSz = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,LxYK9rzJEB4ObgV6w1N2SufRj)
	hldIVoavMri5wqC0eupmEBPx8KTJ4Z = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,U87kmdbyecZrqGRxgKXLlV1FtN+LxYK9rzJEB4ObgV6w1N2SufRj)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,LxYK9rzJEB4ObgV6w1N2SufRj)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,U87kmdbyecZrqGRxgKXLlV1FtN+LxYK9rzJEB4ObgV6w1N2SufRj)
	ntfscuGXRmohVZNzEBvPQ1SI7D4j0e = w362w5g8LFyjKmSz+hldIVoavMri5wqC0eupmEBPx8KTJ4Z
	if ntfscuGXRmohVZNzEBvPQ1SI7D4j0e and xH0f4k6EWumUc5rB1IaZtzRn: LxYK9rzJEB4ObgV6w1N2SufRj = U87kmdbyecZrqGRxgKXLlV1FtN+LxYK9rzJEB4ObgV6w1N2SufRj
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,LxYK9rzJEB4ObgV6w1N2SufRj,ntfscuGXRmohVZNzEBvPQ1SI7D4j0e,CtRZoJqPXV)
	return
def xfvRgHOZDr0ESTo2hnWMdlLGQVwkCX(P3tyYHTlqnhgLfO0DzQ):
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if sLhog1knUIF4fNOjY2zJqQ7cxArb!=1: return
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DETAILED'+P3tyYHTlqnhgLfO0DzQ)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DIVIDED'+P3tyYHTlqnhgLfO0DzQ)
	if P3tyYHTlqnhgLfO0DzQ=='_GOOGLE': pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GOOGLESEARCH_RESULTS')
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def oRju3krYanIAQt7O4(xlBDgsw5ra,Dedx50TsnfK2SZyh1laUtcJNQu9,BrUMS7OdhcT3vLZigmQKfJW4=SebHIf2jL1TBgrMKJu,cHfZv61wm8t5AL=ET1o47LkJSlCjMhAOHVzKNs53i8Gr,PtCxpETOiscy2={}):
	SAuemF91LlRCNzv8p63dqMyIiWsjU,OGlXtc7ouHfPrps3yLb425M,ULTHvOKPFG8EYr07Db,q20kDdrO6s,QcTV9751tpx = [],{},{},{},{}
	if '_all' in Dedx50TsnfK2SZyh1laUtcJNQu9: P3tyYHTlqnhgLfO0DzQ,Pj1F9klBYh3zoTHivEUgVIOw8L,U87kmdbyecZrqGRxgKXLlV1FtN = '_ALL','_all','_GLS_'
	elif '_google' in Dedx50TsnfK2SZyh1laUtcJNQu9: P3tyYHTlqnhgLfO0DzQ,Pj1F9klBYh3zoTHivEUgVIOw8L,U87kmdbyecZrqGRxgKXLlV1FtN = '_GOOGLE','_google','_GOS_'
	if Dedx50TsnfK2SZyh1laUtcJNQu9 in ['listed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,'opened_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,'closed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L]:
		if Dedx50TsnfK2SZyh1laUtcJNQu9=='listed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L: SAuemF91LlRCNzv8p63dqMyIiWsjU = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,U87kmdbyecZrqGRxgKXLlV1FtN+xlBDgsw5ra)
		elif Dedx50TsnfK2SZyh1laUtcJNQu9=='opened_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L: SAuemF91LlRCNzv8p63dqMyIiWsjU = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GLOBALSEARCH_DETAILED'+P3tyYHTlqnhgLfO0DzQ,xlBDgsw5ra)
		elif Dedx50TsnfK2SZyh1laUtcJNQu9=='closed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L: SAuemF91LlRCNzv8p63dqMyIiWsjU = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,'list','GLOBALSEARCH_DIVIDED'+P3tyYHTlqnhgLfO0DzQ,(BrUMS7OdhcT3vLZigmQKfJW4,xlBDgsw5ra))
	if not SAuemF91LlRCNzv8p63dqMyIiWsjU:
		ImZCD5zky03 = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		nLsfxayhBYdjHovlORpe9uEm6SFAgc = 'هل تريد الآن البحث في جميع المواقع عن \n "'+QNR6tCevIGEZKX3rAVsP+qE4nB3mKWHs+xlBDgsw5ra+qE4nB3mKWHs+XOVRfitWJP1zL3p2CMYF+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if Dedx50TsnfK2SZyh1laUtcJNQu9=='search_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L: FKe1TxU27G4SPo8hDER = nLsfxayhBYdjHovlORpe9uEm6SFAgc
		else: FKe1TxU27G4SPo8hDER = ImZCD5zky03+nLsfxayhBYdjHovlORpe9uEm6SFAgc
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=1: return
		ko5ymgwaUtVilrPc3jpWhKJ(QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF)
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+'   Search For: [ '+xlBDgsw5ra+' ]')
		d9dwiyWF4KeTjoZf = 1
		for GJ4kbYnxcHa6NIOuA7X20S in cHfZv61wm8t5AL:
			tPxYUNesXqLZn5d3FrImCEQ0KbS2a = PtCxpETOiscy2[GJ4kbYnxcHa6NIOuA7X20S] if PtCxpETOiscy2 else xlBDgsw5ra
			try: o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
			except: continue
			OGlXtc7ouHfPrps3yLb425M[GJ4kbYnxcHa6NIOuA7X20S] = []
			V7o8RyDJNnF50GpbLsPjdUwefH = '_NODIALOGS_'
			if '-' in GJ4kbYnxcHa6NIOuA7X20S: V7o8RyDJNnF50GpbLsPjdUwefH = V7o8RyDJNnF50GpbLsPjdUwefH+'_REMEMBERRESULTS__'+GJ4kbYnxcHa6NIOuA7X20S+'_'
			if d9dwiyWF4KeTjoZf:
				uv8V4fE7j9pmgFr3wnDL.sleep(0.75)
				QcTV9751tpx[GJ4kbYnxcHa6NIOuA7X20S] = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=bbdzlgnS4vI7oK8puT3fBeO50,args=(tPxYUNesXqLZn5d3FrImCEQ0KbS2a+V7o8RyDJNnF50GpbLsPjdUwefH,))
				QcTV9751tpx[GJ4kbYnxcHa6NIOuA7X20S].start()
			else: bbdzlgnS4vI7oK8puT3fBeO50(tPxYUNesXqLZn5d3FrImCEQ0KbS2a+V7o8RyDJNnF50GpbLsPjdUwefH)
			i9yzUqgAW2Zap1h4Lm(dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S),SebHIf2jL1TBgrMKJu,uv8V4fE7j9pmgFr3wnDL=1000)
		if d9dwiyWF4KeTjoZf:
			uv8V4fE7j9pmgFr3wnDL.sleep(2)
			for GJ4kbYnxcHa6NIOuA7X20S in cHfZv61wm8t5AL: QcTV9751tpx[GJ4kbYnxcHa6NIOuA7X20S].join(10)
			uv8V4fE7j9pmgFr3wnDL.sleep(2)
		for GJ4kbYnxcHa6NIOuA7X20S in cHfZv61wm8t5AL:
			try: o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
			except: continue
			for j18fCtiQLUPRKD0vOzYVe in qFsuKN7ngp.menuItemsLIST:
				GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = j18fCtiQLUPRKD0vOzYVe
				if RTtiozFdb3kamGMqwcL4EgCyAhOS in xzpZLdkW2Ol:
					if 'IPTV-' in GJ4kbYnxcHa6NIOuA7X20S and (239>=hL9fngBAu7XzOx>=230 or 289>=hL9fngBAu7XzOx>=280):
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['IPTV-LIVE']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['IPTV-MOVIES']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['IPTV-SERIES']: continue
						if 'صفحة' not in xzpZLdkW2Ol:
							if   GG8ETpSO0xyUZC7VJeP1sIk52WrN=='live': GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-LIVE'
							elif GG8ETpSO0xyUZC7VJeP1sIk52WrN=='video': GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-MOVIES'
							elif GG8ETpSO0xyUZC7VJeP1sIk52WrN=='folder': GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-SERIES'
						else:
							if   'LIVE' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-LIVE'
							elif 'MOVIES' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-MOVIES'
							elif 'SERIES' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'IPTV-SERIES'
					elif 'M3U-' in GJ4kbYnxcHa6NIOuA7X20S and 729>=hL9fngBAu7XzOx>=710:
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['M3U-LIVE']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['M3U-MOVIES']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['M3U-SERIES']: continue
						if 'صفحة' not in xzpZLdkW2Ol:
							if   GG8ETpSO0xyUZC7VJeP1sIk52WrN=='live': GJ4kbYnxcHa6NIOuA7X20S = 'M3U-LIVE'
							elif GG8ETpSO0xyUZC7VJeP1sIk52WrN=='video': GJ4kbYnxcHa6NIOuA7X20S = 'M3U-MOVIES'
							elif GG8ETpSO0xyUZC7VJeP1sIk52WrN=='folder': GJ4kbYnxcHa6NIOuA7X20S = 'M3U-SERIES'
						else:
							if   'LIVE' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'M3U-LIVE'
							elif 'MOVIES' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'M3U-MOVIES'
							elif 'SERIES' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'M3U-SERIES'
					elif 'YOUTUBE-' in GJ4kbYnxcHa6NIOuA7X20S and 149>=hL9fngBAu7XzOx>=140:
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['YOUTUBE-CHANNELS']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['YOUTUBE-PLAYLISTS']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in xzpZLdkW2Ol or ':: ' in xzpZLdkW2Ol:
							continue
						else:
							if   hL9fngBAu7XzOx==144 and 'USER' in xzpZLdkW2Ol: GJ4kbYnxcHa6NIOuA7X20S = 'YOUTUBE-CHANNELS'
							elif hL9fngBAu7XzOx==144 and 'CHNL' in xzpZLdkW2Ol: GJ4kbYnxcHa6NIOuA7X20S = 'YOUTUBE-CHANNELS'
							elif hL9fngBAu7XzOx==144 and 'LIST' in xzpZLdkW2Ol: GJ4kbYnxcHa6NIOuA7X20S = 'YOUTUBE-PLAYLISTS'
							elif hL9fngBAu7XzOx==143: GJ4kbYnxcHa6NIOuA7X20S = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in GJ4kbYnxcHa6NIOuA7X20S and 419>=hL9fngBAu7XzOx>=400:
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['DAILYMOTION-PLAYLISTS']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['DAILYMOTION-CHANNELS']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['DAILYMOTION-VIDEOS']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['DAILYMOTION-LIVES']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['DAILYMOTION-HASHTAGS']: continue
						if   hL9fngBAu7XzOx in [401,405]: GJ4kbYnxcHa6NIOuA7X20S = 'DAILYMOTION-PLAYLISTS'
						elif hL9fngBAu7XzOx in [402,406]: GJ4kbYnxcHa6NIOuA7X20S = 'DAILYMOTION-CHANNELS'
						elif hL9fngBAu7XzOx in [404]: GJ4kbYnxcHa6NIOuA7X20S = 'DAILYMOTION-VIDEOS'
						elif hL9fngBAu7XzOx in [415]: GJ4kbYnxcHa6NIOuA7X20S = 'DAILYMOTION-LIVES'
						elif hL9fngBAu7XzOx in [416]: GJ4kbYnxcHa6NIOuA7X20S = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in GJ4kbYnxcHa6NIOuA7X20S and 39>=hL9fngBAu7XzOx>=30:
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['PANET-SERIES']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['PANET-MOVIES']: continue
						if   hL9fngBAu7XzOx in [32,39]: GJ4kbYnxcHa6NIOuA7X20S = 'PANET-SERIES'
						elif hL9fngBAu7XzOx in [33,39]: GJ4kbYnxcHa6NIOuA7X20S = 'PANET-MOVIES'
					elif 'IFILM-' in GJ4kbYnxcHa6NIOuA7X20S and 29>=hL9fngBAu7XzOx>=20:
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['IFILM-ARABIC']: continue
						if j18fCtiQLUPRKD0vOzYVe in OGlXtc7ouHfPrps3yLb425M['IFILM-ENGLISH']: continue
						if   '/ar.' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'IFILM-ARABIC'
						elif '/en.' in vCsnpu14Zi7qUEQg3Tl50h: GJ4kbYnxcHa6NIOuA7X20S = 'IFILM-ENGLISH'
					OGlXtc7ouHfPrps3yLb425M[GJ4kbYnxcHa6NIOuA7X20S].append(j18fCtiQLUPRKD0vOzYVe)
		for GJ4kbYnxcHa6NIOuA7X20S in list(OGlXtc7ouHfPrps3yLb425M.keys()):
			ULTHvOKPFG8EYr07Db[GJ4kbYnxcHa6NIOuA7X20S] = []
			q20kDdrO6s[GJ4kbYnxcHa6NIOuA7X20S] = []
			for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in OGlXtc7ouHfPrps3yLb425M[GJ4kbYnxcHa6NIOuA7X20S]:
				j18fCtiQLUPRKD0vOzYVe = (GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
				if 'صفحة' in xzpZLdkW2Ol and GG8ETpSO0xyUZC7VJeP1sIk52WrN=='folder': q20kDdrO6s[GJ4kbYnxcHa6NIOuA7X20S].append(j18fCtiQLUPRKD0vOzYVe)
				else: ULTHvOKPFG8EYr07Db[GJ4kbYnxcHa6NIOuA7X20S].append(j18fCtiQLUPRKD0vOzYVe)
		M3eGrXckljFs,oNBMAU3Fmd87rzwb = [],[]
		K03lsMX2cU9IgNYenTZfm8S = list(ULTHvOKPFG8EYr07Db.keys())
		Ef0RPFcwJO5k1 = Lx9EoVFmp6PsyenMdBuOq23(K03lsMX2cU9IgNYenTZfm8S)
		zGBPXhsgptE3O9 = []
		for GJ4kbYnxcHa6NIOuA7X20S in Ef0RPFcwJO5k1:
			if isinstance(GJ4kbYnxcHa6NIOuA7X20S,tuple):
				zGBPXhsgptE3O9 = [GJ4kbYnxcHa6NIOuA7X20S]
				continue
			if GJ4kbYnxcHa6NIOuA7X20S not in cHfZv61wm8t5AL: continue
			if ULTHvOKPFG8EYr07Db[GJ4kbYnxcHa6NIOuA7X20S]:
				T3T9ZskymVB5YraMl = dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S)
				eoTH8bqtUnf = [('link',QNR6tCevIGEZKX3rAVsP+'===== '+T3T9ZskymVB5YraMl+' ====='+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)]
				if 0: IeXxt9YbyJAv4sBmMWNqacS = xlBDgsw5ra+' - '+'بحث'+qE4nB3mKWHs+T3T9ZskymVB5YraMl
				else: IeXxt9YbyJAv4sBmMWNqacS = 'بحث'+qE4nB3mKWHs+T3T9ZskymVB5YraMl+' - '+xlBDgsw5ra
				if len(ULTHvOKPFG8EYr07Db[GJ4kbYnxcHa6NIOuA7X20S])<8: ZN8bITGkuiV = []
				else:
					fuVrkC9DngHMmLRq2sGhU3TB1ZJy = E7r8hUCVvTiFQW0dBGXjxcy+IeXxt9YbyJAv4sBmMWNqacS+XOVRfitWJP1zL3p2CMYF
					ZN8bITGkuiV = [('folder',U87kmdbyecZrqGRxgKXLlV1FtN+fuVrkC9DngHMmLRq2sGhU3TB1ZJy,'closed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,542,SebHIf2jL1TBgrMKJu,GJ4kbYnxcHa6NIOuA7X20S,xlBDgsw5ra,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)]
				ff8tL1AO652K = ULTHvOKPFG8EYr07Db[GJ4kbYnxcHa6NIOuA7X20S]+q20kDdrO6s[GJ4kbYnxcHa6NIOuA7X20S]
				pL4uDJCbEiT57YSMm = zGBPXhsgptE3O9+eoTH8bqtUnf+ff8tL1AO652K[:7]+ZN8bITGkuiV
				M3eGrXckljFs += pL4uDJCbEiT57YSMm
				iS8Ynf0d5kwNEZcrDxLBM = [('folder',U87kmdbyecZrqGRxgKXLlV1FtN+IeXxt9YbyJAv4sBmMWNqacS,'closed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,542,SebHIf2jL1TBgrMKJu,GJ4kbYnxcHa6NIOuA7X20S,xlBDgsw5ra,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)]
				RveMdZL6Pim = zGBPXhsgptE3O9+iS8Ynf0d5kwNEZcrDxLBM
				oNBMAU3Fmd87rzwb += RveMdZL6Pim
				pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DIVIDED'+P3tyYHTlqnhgLfO0DzQ,(GJ4kbYnxcHa6NIOuA7X20S,xlBDgsw5ra),ff8tL1AO652K,CtRZoJqPXV)
				zGBPXhsgptE3O9 = []
		pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_DETAILED'+P3tyYHTlqnhgLfO0DzQ,xlBDgsw5ra,M3eGrXckljFs,CtRZoJqPXV)
		pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,xlBDgsw5ra)
		pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,'GLOBALSEARCH_SPLITTED'+P3tyYHTlqnhgLfO0DzQ,U87kmdbyecZrqGRxgKXLlV1FtN+xlBDgsw5ra,oNBMAU3Fmd87rzwb,CtRZoJqPXV)
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		SAuemF91LlRCNzv8p63dqMyIiWsjU = oNBMAU3Fmd87rzwb if Dedx50TsnfK2SZyh1laUtcJNQu9=='listed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L and oNBMAU3Fmd87rzwb else M3eGrXckljFs
	if Dedx50TsnfK2SZyh1laUtcJNQu9 in ['listed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,'opened_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,'closed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L]:
		for GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM in SAuemF91LlRCNzv8p63dqMyIiWsjU:
			if Dedx50TsnfK2SZyh1laUtcJNQu9 in ['listed_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L,'opened_sites'+Pj1F9klBYh3zoTHivEUgVIOw8L] and 'صفحة' in xzpZLdkW2Ol and GG8ETpSO0xyUZC7VJeP1sIk52WrN=='folder': continue
			QUzFYoapm9jx(GG8ETpSO0xyUZC7VJeP1sIk52WrN,xzpZLdkW2Ol,vCsnpu14Zi7qUEQg3Tl50h,hL9fngBAu7XzOx,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,Yg36raSGA02uUXEPMF7itZd9KcWf,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
	ko5ymgwaUtVilrPc3jpWhKJ(cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db)
	return
def KERSXDlvmWexFz(search):
	Ef0RPFcwJO5k1 = Lx9EoVFmp6PsyenMdBuOq23(ehtRkZ2gDKFELmIuOaA)
	for GJ4kbYnxcHa6NIOuA7X20S in Ef0RPFcwJO5k1:
		if '-' in GJ4kbYnxcHa6NIOuA7X20S: continue
		if isinstance(GJ4kbYnxcHa6NIOuA7X20S,tuple):
			qFsuKN7ngp.menuItemsLIST.append(GJ4kbYnxcHa6NIOuA7X20S)
			continue
		o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
		name = dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S)+' - '+search
		QUzFYoapm9jx('folder',RTtiozFdb3kamGMqwcL4EgCyAhOS+name,GJ4kbYnxcHa6NIOuA7X20S,548,'','',search)
	return
def ItGFOflZ16gVQ0yq58P2wuCHMjYhXr(GJ4kbYnxcHa6NIOuA7X20S,search):
	o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S)
	bbdzlgnS4vI7oK8puT3fBeO50(search)
	return
def Hf6muiMKy8J():
	gge5CmAcldwv0('','',lFEvMxzSH2y7tYR,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def yCY459wgTzt8cm(xlBDgsw5ra=SebHIf2jL1TBgrMKJu):
	IsqopSjwNr6W4klVD32JR1nhf,V7o8RyDJNnF50GpbLsPjdUwefH,showDialogs = sKhzPm0oUq7LO3Wk5Q(xlBDgsw5ra)
	if not IsqopSjwNr6W4klVD32JR1nhf:
		IsqopSjwNr6W4klVD32JR1nhf = zWKdm3kV2ItwYrgH1BZyRON()
		if not IsqopSjwNr6W4klVD32JR1nhf: return
		IsqopSjwNr6W4klVD32JR1nhf = IsqopSjwNr6W4klVD32JR1nhf.lower()
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+'   Search For: [ '+IsqopSjwNr6W4klVD32JR1nhf+' ]')
	t2WLY7DxIZs = IsqopSjwNr6W4klVD32JR1nhf+V7o8RyDJNnF50GpbLsPjdUwefH
	if 0: mmpyaourk1qh,cQajTFxr5OL8KbgyN0 = IsqopSjwNr6W4klVD32JR1nhf+' - ',SebHIf2jL1TBgrMKJu
	else: mmpyaourk1qh,cQajTFxr5OL8KbgyN0 = SebHIf2jL1TBgrMKJu,' - '+IsqopSjwNr6W4klVD32JR1nhf
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'مواقع سيرفرات خاصة - قليلة المشاكل'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,157)
	QUzFYoapm9jx('folder','_M3U_'+mmpyaourk1qh+'بحث M3U'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,719,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_IPT_'+mmpyaourk1qh+'بحث IPTV'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,239,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_BKR_'+mmpyaourk1qh+'بحث موقع بكرا'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,379,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_ART_'+mmpyaourk1qh+'بحث موقع تونز عربية'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,739,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_KRB_'+mmpyaourk1qh+'بحث موقع قناة كربلاء'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,329,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FH2_'+mmpyaourk1qh+'بحث موقع فاصل الثاني'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,599,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_KTV_'+mmpyaourk1qh+'بحث موقع كتكوت تيفي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,819,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_EB1_'+mmpyaourk1qh+'بحث موقع ايجي بيست 1'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,779,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_EB2_'+mmpyaourk1qh+'بحث موقع ايجي بيست 2'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,789,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_IFL_'+mmpyaourk1qh+'  بحث موقع قناة آي فيلم'+cQajTFxr5OL8KbgyN0+nlNC2gJDBZMed63TxqphA1vrXm8Hy,SebHIf2jL1TBgrMKJu,29,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_AKO_'+mmpyaourk1qh+'بحث موقع أكوام القديم'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,79,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_AKW_'+mmpyaourk1qh+'بحث موقع أكوام الجديد'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,249,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_MRF_'+mmpyaourk1qh+'بحث موقع قناة المعارف'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,49,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SHM_'+mmpyaourk1qh+'بحث موقع شوف ماكس'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,59,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,157)
	QUzFYoapm9jx('folder','_LRZ_'+mmpyaourk1qh+'بحث موقع لاروزا'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,709,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FJS_'+mmpyaourk1qh+' بحث موقع فجر شو'+cQajTFxr5OL8KbgyN0+qE4nB3mKWHs,SebHIf2jL1TBgrMKJu,399,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_TVF_'+mmpyaourk1qh+'بحث موقع تيفي فان'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,469,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_LDN_'+mmpyaourk1qh+'بحث موقع لودي نت'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,459,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CMN_'+mmpyaourk1qh+'بحث موقع سيما ناو'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,309,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SHN_'+mmpyaourk1qh+'بحث موقع شاهد نيوز'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,589,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs+'_NODIALOGS_')
	QUzFYoapm9jx('folder','_ARS_'+mmpyaourk1qh+'بحث موقع عرب سييد'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,259,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CCB_'+mmpyaourk1qh+'بحث موقع سيما كلوب'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,829,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SH4_'+mmpyaourk1qh+'بحث موقع شاهد فوريو'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,119,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs+'_NODIALOGS_')
	QUzFYoapm9jx('folder','_SHT_'+mmpyaourk1qh+'بحث موقع شوفها تيفي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,649,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_WC1_'+mmpyaourk1qh+'بحث موقع وي سيما 1'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,569,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_WC2_'+mmpyaourk1qh+'بحث موقع وي سيما 2'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,1009,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'مواقع سيرفرات عامة - كثيرة المشاكل'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,157)
	QUzFYoapm9jx('folder','_TKT_'+mmpyaourk1qh+'بحث موقع تكات'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,949,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FST_'+mmpyaourk1qh+'بحث موقع فوستا'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,609,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FBK_'+mmpyaourk1qh+'بحث موقع فبركة'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,629,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_YQT_'+mmpyaourk1qh+'بحث موقع ياقوت'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,669,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SHB_'+mmpyaourk1qh+'بحث موقع شبكتي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,969,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_VRB_'+mmpyaourk1qh+'بحث موقع فاربون'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,879,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_BRS_'+mmpyaourk1qh+'بحث موقع برستيج'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,659,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_KRM_'+mmpyaourk1qh+'بحث موقع كرمالك'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,929,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_ANZ_'+mmpyaourk1qh+'بحث موقع انمي زد'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,979,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FSK_'+mmpyaourk1qh+'بحث موقع فارسكو'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,999,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_HLC_'+mmpyaourk1qh+'بحث موقع هلا سيما'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,89,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_MST_'+mmpyaourk1qh+'بحث موقع المصطبة'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,869,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SNT_'+mmpyaourk1qh+'بحث موقع شوف نت'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,849,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_DR7_'+mmpyaourk1qh+'بحث موقع دراما صح'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,689,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CFR_'+mmpyaourk1qh+'بحث موقع سيما فري'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,839,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CMF_'+mmpyaourk1qh+'بحث موقع سيما فانز'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,99,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CML_'+mmpyaourk1qh+'بحث موقع سيما لايت'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,479,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_C4H_'+mmpyaourk1qh+'بحث موقع سيما 400'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,699,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_ABD_'+mmpyaourk1qh+'بحث موقع سيما عبدو'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,559,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_AKT_'+mmpyaourk1qh+'بحث موقع اكوام تيوب'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,859,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_DCF_'+mmpyaourk1qh+'بحث موقع دراما كافيه'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,939,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FTV_'+mmpyaourk1qh+'بحث موقع فوشار تيفي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,919,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_CWB_'+mmpyaourk1qh+'بحث موقع سيما وبس'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,989,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_AHK_'+mmpyaourk1qh+'بحث موقع أهواك تيفي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,619,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_SRT_'+mmpyaourk1qh+'بحث موقع سيريس تايم'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,899,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_FVD_'+mmpyaourk1qh+'بحث موقع فوشار فيديو'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,909,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_C4P_'+mmpyaourk1qh+'بحث موقع سيما فور بي'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,889,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_EB4_'+mmpyaourk1qh+'بحث موقع ايجي بيست 4'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,809,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+'مواقع سيرفرات خاصة - قليلة المشاكل'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,157)
	QUzFYoapm9jx('folder','_YUT_'+mmpyaourk1qh+'بحث موقع يوتيوب'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,149,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	QUzFYoapm9jx('folder','_DLM_'+mmpyaourk1qh+'بحث موقع دايلي موشن'+cQajTFxr5OL8KbgyN0,SebHIf2jL1TBgrMKJu,409,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,t2WLY7DxIZs)
	return