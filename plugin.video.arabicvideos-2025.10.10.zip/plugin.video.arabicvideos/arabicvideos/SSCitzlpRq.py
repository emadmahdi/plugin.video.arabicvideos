# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
import xbmc as if5dy2h0nsDVlukoQ7NUFqx4cGEW,re as X2XorVqHjLkWeCchY4u9fSz,sys as yMqHPpxSEAFIwKecXdi40r8zL53,xbmcaddon as zEAv9DdhYJikZsrIC1p5cxF8H,random as JO7n9zxwdgIStrTjR,os as E2xjtKaMXdC3NDoTm7f5Wkev,xbmcvfs as eEobpYW3xM1,time as uv8V4fE7j9pmgFr3wnDL,pickle as LvuY3rd5OqjNAhKy6ERcM2imCnSTsG,zlib as kLtsvDVQ0SZmTjhBG9uW,xbmcgui as G5OVsSktWRJQu8h4T,xbmcplugin as mKerP0GFQHJbM1hzR5ntxUVpdqTk,sqlite3 as Y7oqZy4HgtlDIxsJ,traceback as HkQJ95ahZMwW0OtpKU2X,threading as ZKuP5G1IzjRHOLa,hashlib as Z9w7UrhMLl,json as ddWZPUnz9Cljm
from sK1pAJibxN import *
import qFsuKN7ngp
tfX4sO3hy2H1IbKG = HADrRCz9QgU4xudPJIqYb70(u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩഅ")
rcI3PdxEKSNo5VQYGf9hBTsWnyAi81 = zEAv9DdhYJikZsrIC1p5cxF8H.Addon().getAddonInfo(C3w6qluao7EzUxJgMGBtV(u"ࠩࡳࡥࡹ࡮ࠧആ"))
oLIAqpQJuKZ6V7eY = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,zpx2fPNKk6Ms38eD1vcO(u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬഇ"))
yMqHPpxSEAFIwKecXdi40r8zL53.path.append(oLIAqpQJuKZ6V7eY)
bjfOp7nz3IHklMhUvLgd1xC = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥഈ"))
zzGetSI9yqnbZh = X2XorVqHjLkWeCchY4u9fSz.findall(gCkRKGhwcx26v(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩഉ"),bjfOp7nz3IHklMhUvLgd1xC,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
zzGetSI9yqnbZh = float(zzGetSI9yqnbZh[wvkDqmNZlJU52isXo])
yMIqCQzL2KF4uRxA9mP6DHhb7JEY = if5dy2h0nsDVlukoQ7NUFqx4cGEW.Player
MSGnwoeiRcVCW64Ja = G5OVsSktWRJQu8h4T.WindowXMLDialog
psS8dmb912iRBgGc7qOPyCZ6 = zzGetSI9yqnbZh<HADrRCz9QgU4xudPJIqYb70(u"࠷࠹༂")
QBOMjKifEAFD = zzGetSI9yqnbZh>ALwOspNtXxZrz3PEKku(u"࠱࠹࠰࠼࠽༃")
if QBOMjKifEAFD:
	sJY2SoapBKT5dE4MAirZw78G1X = eEobpYW3xM1.translatePath(HADrRCz9QgU4xudPJIqYb70(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧഊ"))
	Lvrc7Obu9VG = if5dy2h0nsDVlukoQ7NUFqx4cGEW.LOGINFO
	RVDd7BHXajCMPpNksx81nSAhzYq,FhvNwRL5BAMa = Izy1PvclrYx4eSVWn0L5phZbq(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨഋ"),VOALf8iYEnMdK0g(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩഌ")
	NMobgjvE4Y6IxqhD8zPyaOk = eEobpYW3xM1.translatePath(HADrRCz9QgU4xudPJIqYb70(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ഍"))
	from urllib.parse import unquote as _OZzEj8uFsDTgLiWp60H5fh3
	ccEJD9RQU8XkilMz = wPnfgxKZdAv6T10(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫഎ")
else:
	sJY2SoapBKT5dE4MAirZw78G1X = if5dy2h0nsDVlukoQ7NUFqx4cGEW.translatePath(HADrRCz9QgU4xudPJIqYb70(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬഏ"))
	Lvrc7Obu9VG = if5dy2h0nsDVlukoQ7NUFqx4cGEW.LOGNOTICE
	RVDd7BHXajCMPpNksx81nSAhzYq,FhvNwRL5BAMa = DQIrVcKuY6bJv(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ഐ").encode(Tv08xsf9HOqunIVUPdK1),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ഑").encode(Tv08xsf9HOqunIVUPdK1)
	NMobgjvE4Y6IxqhD8zPyaOk = if5dy2h0nsDVlukoQ7NUFqx4cGEW.translatePath(HADrRCz9QgU4xudPJIqYb70(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨഒ"))
	from urllib import unquote as _OZzEj8uFsDTgLiWp60H5fh3
	ccEJD9RQU8XkilMz = VOALf8iYEnMdK0g(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩഓ").encode(Tv08xsf9HOqunIVUPdK1)
WYGV2HQo6sfnqSDZEcK9Cu4TP = yMqHPpxSEAFIwKecXdi40r8zL53.argv[wvkDqmNZlJU52isXo].split(zpx2fPNKk6Ms38eD1vcO(u"ࠩ࠲ࠫഔ"))[JhTts2R43AxkM8bYanKVy]
BrOCluwtd1veo0a7EMbqVFXZgjQRL2 = int(yMqHPpxSEAFIwKecXdi40r8zL53.argv[nyUIsfd53EGot9vbj0XDeq])
EWTFwqJoXHGSjsRfhOI5YLM = yMqHPpxSEAFIwKecXdi40r8zL53.argv[JhTts2R43AxkM8bYanKVy]
NpxGjKwzfvnUaRZ2s = WYGV2HQo6sfnqSDZEcK9Cu4TP.split(Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࠲ࠬക"))[JhTts2R43AxkM8bYanKVy]
xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(ALwOspNtXxZrz3PEKku(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫഖ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+VOALf8iYEnMdK0g(u"ࠬ࠯ࠧഗ"))
LdX87mwIzyBM = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(NMobgjvE4Y6IxqhD8zPyaOk,WYGV2HQo6sfnqSDZEcK9Cu4TP)
Q8ueUH69goFIxnE2V1 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡩ࡮ࡣࡪࡩࡸ࠭ഘ"))
P6JuCgySDkci19Tp = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(Q8ueUH69goFIxnE2V1,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠧങ"))
QRqysNUeaPv5wmDx1Ti = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(Q8ueUH69goFIxnE2V1,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩച"))
AAVyWBIugYpewaqKDGRn = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(QRqysNUeaPv5wmDx1Ti,vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬഛ"))
rrzstBgpPX = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(sJY2SoapBKT5dE4MAirZw78G1X,TVnqDYzWoM2UfHp0dchJ(u"ࠪࡱࡪࡪࡩࡢࠩജ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡋࡵ࡮ࡵࡵࠪഝ"),ALwOspNtXxZrz3PEKku(u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨഞ"))
E8Eo9FKSM5bhgRYlCWZHqPmt = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫട"))
dUj4HNoGp91APu6itnl3BCc = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨഠ"))
rcI3PdxEKSNo5VQYGf9hBTsWnyAi81 = zEAv9DdhYJikZsrIC1p5cxF8H.Addon().getAddonInfo(AGlW9LqKN3Dvo(u"ࠨࡲࡤࡸ࡭࠭ഡ"))
p1ENioYkXrGnM2Pqu = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩഢ"))
H3a6hvAgeNctTiXF8d1uELfPr4y = int(uv8V4fE7j9pmgFr3wnDL.time())
MMAUZiw4CoJ8 = zEAv9DdhYJikZsrIC1p5cxF8H.Addon(id=WYGV2HQo6sfnqSDZEcK9Cu4TP)
iY12hQM8RU = MMAUZiw4CoJ8.getSetting(uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧണ"))
ptIsx9oHqB0dXK = mrhSYXH2P8bO3eJAa9n if iY12hQM8RU==xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV else BBX9RAuxnyGZ4WIF2TrhYeom3
def lhC3Axj8TQSsRWeu0k(pfhH2objgVkI7eycn,ZPo8Gl4iTpNHb6z5e3=vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡄ࠭ത")):
	if ASkvf27etUK0(u"ࠬࡃࠧഥ") in pfhH2objgVkI7eycn:
		if ZPo8Gl4iTpNHb6z5e3 in pfhH2objgVkI7eycn: qg7Nr1dCaD,uLGMRsj1cr2havbkYxeOVXWTKUmd8 = pfhH2objgVkI7eycn.split(ZPo8Gl4iTpNHb6z5e3,xxRyYsrSCzjifvH4cIqgldeOo(u"࠲༄"))
		else: qg7Nr1dCaD,uLGMRsj1cr2havbkYxeOVXWTKUmd8 = SebHIf2jL1TBgrMKJu,pfhH2objgVkI7eycn
		uLGMRsj1cr2havbkYxeOVXWTKUmd8 = uLGMRsj1cr2havbkYxeOVXWTKUmd8.split(bcNqYtfET5l92dLGjyZSPe(u"࠭ࠦࠨദ"))
		bIGXajdcK6PQBs = {}
		for gklHJaWXUx9TeLFA2IfbqGc0Y5t1m in uLGMRsj1cr2havbkYxeOVXWTKUmd8:
			BXCThrgedxOyF2N,NNZoTVqIcEG6l = gklHJaWXUx9TeLFA2IfbqGc0Y5t1m.split(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠾ࠩധ"),iDhLkZS6XBagNCQfs9tq2(u"࠳༅"))
			bIGXajdcK6PQBs[BXCThrgedxOyF2N] = NNZoTVqIcEG6l
	else: qg7Nr1dCaD,bIGXajdcK6PQBs = pfhH2objgVkI7eycn,{}
	return qg7Nr1dCaD,bIGXajdcK6PQBs
def wpbqld5hCR72i6cWNeQI(r7h8wgIzXZkaDTVqB5tOS3n):
	VXLDdrYbQOEW,GJ4kbYnxcHa6NIOuA7X20S,pEJAs4Dxzihn02VOMU58LH = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	r7h8wgIzXZkaDTVqB5tOS3n = r7h8wgIzXZkaDTVqB5tOS3n.replace(RVDd7BHXajCMPpNksx81nSAhzYq,SebHIf2jL1TBgrMKJu).replace(FhvNwRL5BAMa,SebHIf2jL1TBgrMKJu)
	yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall(bcNqYtfET5l92dLGjyZSPe(u"ࠨࠪ࠱࠭ࡡࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇ࠲࠻ࡇ࠶ࡌ࡜࡞ࠪ࡟ࡻࡡࡽ࡜ࡸࠫࠣ࠯ࡡࡡ࡜࠰ࡅࡒࡐࡔࡘ࡜࡞ࠪ࠱࠮ࡄ࠯ࠤࠨന"),r7h8wgIzXZkaDTVqB5tOS3n,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if yyfSKmso8APbUwvq3HLXgz0D: VXLDdrYbQOEW,GJ4kbYnxcHa6NIOuA7X20S,r7h8wgIzXZkaDTVqB5tOS3n = yyfSKmso8APbUwvq3HLXgz0D[wvkDqmNZlJU52isXo]
	if VXLDdrYbQOEW not in [qE4nB3mKWHs,czvu7VQCZodkMf(u"ࠩ࠯ࠫഩ"),SebHIf2jL1TBgrMKJu]: pEJAs4Dxzihn02VOMU58LH = wPnfgxKZdAv6T10(u"ࠪࡣࡒࡕࡄࡠࠩപ")
	if GJ4kbYnxcHa6NIOuA7X20S: GJ4kbYnxcHa6NIOuA7X20S = iDhLkZS6XBagNCQfs9tq2(u"ࠫࡤ࠭ഫ")+GJ4kbYnxcHa6NIOuA7X20S+fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡥࠧബ")
	r7h8wgIzXZkaDTVqB5tOS3n = GJ4kbYnxcHa6NIOuA7X20S+pEJAs4Dxzihn02VOMU58LH+r7h8wgIzXZkaDTVqB5tOS3n
	return r7h8wgIzXZkaDTVqB5tOS3n
def kLEi7mYT5wBM4DHsgWy8(pfhH2objgVkI7eycn):
	return _OZzEj8uFsDTgLiWp60H5fh3(pfhH2objgVkI7eycn)
def wrLGxbJiM4NzluAvI7KPojmYteD(pEj4bkH7u0et5fJA92M):
	zfgtsYkQDEFH = {HADrRCz9QgU4xudPJIqYb70(u"࠭ࡴࡺࡲࡨࠫഭ"):SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠧ࡮ࡱࡧࡩࠬമ"):SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡷࡵࡰࠬയ"):SebHIf2jL1TBgrMKJu,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡷࡩࡽࡺࠧര"):SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡴࡦ࡭ࡥࠨറ"):SebHIf2jL1TBgrMKJu,wPnfgxKZdAv6T10(u"ࠫࡳࡧ࡭ࡦࠩല"):SebHIf2jL1TBgrMKJu,gCkRKGhwcx26v(u"ࠬ࡯࡭ࡢࡩࡨࠫള"):SebHIf2jL1TBgrMKJu,zpx2fPNKk6Ms38eD1vcO(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧഴ"):SebHIf2jL1TBgrMKJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩവ"):SebHIf2jL1TBgrMKJu}
	if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡁࠪശ") in pEj4bkH7u0et5fJA92M: pEj4bkH7u0et5fJA92M = pEj4bkH7u0et5fJA92M.split(fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡂࠫഷ"),nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
	qg7Nr1dCaD,AAfx9GWjgMF = lhC3Axj8TQSsRWeu0k(pEj4bkH7u0et5fJA92M)
	aargs = dict(list(zfgtsYkQDEFH.items())+list(AAfx9GWjgMF.items()))
	JkU3CPaXYE0fhRAq1rTLGcd4y72jz = aargs[l7kBpMw5Qn(u"ࠪࡱࡴࡪࡥࠨസ")]
	yxmwHSQDJg4b = kLEi7mYT5wBM4DHsgWy8(aargs[gCkRKGhwcx26v(u"ࠫࡺࡸ࡬ࠨഹ")])
	sx6BvORYmAQp3L9Kbof8 = kLEi7mYT5wBM4DHsgWy8(aargs[AGlW9LqKN3Dvo(u"ࠬࡺࡥࡹࡶࠪഺ")])
	h4KqERCZpW6aPLmUyw9BSOjtFndl = kLEi7mYT5wBM4DHsgWy8(aargs[tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡰࡢࡩࡨ഻ࠫ")])
	Ih0wKBLCeSNGPvg7tc6A = kLEi7mYT5wBM4DHsgWy8(aargs[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡵࡻࡳࡩ഼ࠬ")])
	ccAodmkDjX1RpSOt4v9l7 = kLEi7mYT5wBM4DHsgWy8(aargs[VOALf8iYEnMdK0g(u"ࠨࡰࡤࡱࡪ࠭ഽ")])
	Ozx5aq04MlbHkAESeCRcT21vWXPuJ = kLEi7mYT5wBM4DHsgWy8(aargs[HADrRCz9QgU4xudPJIqYb70(u"ࠩ࡬ࡱࡦ࡭ࡥࠨാ")])
	IQig08Vy3HboGunElR = aargs[VOALf8iYEnMdK0g(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫി")]
	h7HJPDRI2Qdi1lKFVGAYe608ZE4zt = kLEi7mYT5wBM4DHsgWy8(aargs[vMhFypGLHZJbdX4O7oc3W8x(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ീ")])
	if h7HJPDRI2Qdi1lKFVGAYe608ZE4zt: h7HJPDRI2Qdi1lKFVGAYe608ZE4zt = eval(h7HJPDRI2Qdi1lKFVGAYe608ZE4zt)
	else: h7HJPDRI2Qdi1lKFVGAYe608ZE4zt = {}
	if not JkU3CPaXYE0fhRAq1rTLGcd4y72jz: Ih0wKBLCeSNGPvg7tc6A = uqLUBHepfM3l6AyIzTJh80a(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬു") ; JkU3CPaXYE0fhRAq1rTLGcd4y72jz = Izy1PvclrYx4eSVWn0L5phZbq(u"࠭࠲࠷࠲ࠪൂ")
	return Ih0wKBLCeSNGPvg7tc6A,ccAodmkDjX1RpSOt4v9l7,yxmwHSQDJg4b,JkU3CPaXYE0fhRAq1rTLGcd4y72jz,Ozx5aq04MlbHkAESeCRcT21vWXPuJ,h4KqERCZpW6aPLmUyw9BSOjtFndl,sx6BvORYmAQp3L9Kbof8,IQig08Vy3HboGunElR,h7HJPDRI2Qdi1lKFVGAYe608ZE4zt
def yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG):
	xx28maMbKCf = yMqHPpxSEAFIwKecXdi40r8zL53._getframe(nyUIsfd53EGot9vbj0XDeq).f_code.co_name
	if not tfX4sO3hy2H1IbKG or not xx28maMbKCf or xx28maMbKCf==Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩൃ"):
		return t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨ࡝ࠣࠫൄ")+NpxGjKwzfvnUaRZ2s.upper()+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡢࠫ൅")+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+AGlW9LqKN3Dvo(u"ࠪࡣࠬെ")+str(zzGetSI9yqnbZh)+TVnqDYzWoM2UfHp0dchJ(u"ࠫࠥࡣࠧേ")
	return NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬ࠴࡜ࡵࠩൈ")+xx28maMbKCf
def z82vTVp1xik0HBSenuENU5fRAD3(ghkDw9n6vVUZx7,SlMkfbvj8BuRsGydepihKFOHAIL=SebHIf2jL1TBgrMKJu):
	if not SlMkfbvj8BuRsGydepihKFOHAIL: ghkDw9n6vVUZx7,SlMkfbvj8BuRsGydepihKFOHAIL = SebHIf2jL1TBgrMKJu,ghkDw9n6vVUZx7
	SlMkfbvj8BuRsGydepihKFOHAIL = SlMkfbvj8BuRsGydepihKFOHAIL.replace(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭࡜ࡹ࠲࠳ࠫ൉"),SebHIf2jL1TBgrMKJu)
	if psS8dmb912iRBgGc7qOPyCZ6:
		try: SlMkfbvj8BuRsGydepihKFOHAIL = SlMkfbvj8BuRsGydepihKFOHAIL.decode(Tv08xsf9HOqunIVUPdK1,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧൊ")).encode(Tv08xsf9HOqunIVUPdK1,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨോ"))
		except: SlMkfbvj8BuRsGydepihKFOHAIL = SlMkfbvj8BuRsGydepihKFOHAIL.encode(Tv08xsf9HOqunIVUPdK1,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩൌ"))
	K1KygtoLrUei7EBvZIcDWNT = Lvrc7Obu9VG
	P7SQWVY4x1vm9tnANdiB = [SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu]
	if ghkDw9n6vVUZx7: SlMkfbvj8BuRsGydepihKFOHAIL = SlMkfbvj8BuRsGydepihKFOHAIL.replace(QNR6tCevIGEZKX3rAVsP,SebHIf2jL1TBgrMKJu).replace(E7r8hUCVvTiFQW0dBGXjxcy,SebHIf2jL1TBgrMKJu).replace(XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu)
	else: ghkDw9n6vVUZx7 = QO1UyS3zvJFIdlCgT0Kx96wLA4a5i
	zlMhmRicednXNAGLKqDBY1g,ZPo8Gl4iTpNHb6z5e3 = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡠࡹ്࠭"),cc07eWdgrbB4xJfVCANFSk
	cDuO1raYjgzSCVU7poi = zpx2fPNKk6Ms38eD1vcO(u"࠸࠷༇")*qE4nB3mKWHs if QBOMjKifEAFD else iDhLkZS6XBagNCQfs9tq2(u"࠶࠵༆")*qE4nB3mKWHs
	SxMY0qDjiheQgLFT = K7cnfQMS6BPvI4LGmCsRp8bUlJ9*zlMhmRicednXNAGLKqDBY1g
	if SlMkfbvj8BuRsGydepihKFOHAIL.startswith(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬൎ")): SlMkfbvj8BuRsGydepihKFOHAIL = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬ࠴࡜ࡵࠩ൏")+SlMkfbvj8BuRsGydepihKFOHAIL
	if AAThlKoOtk0dz1sBZpPRbiV2vIe in ghkDw9n6vVUZx7: K1KygtoLrUei7EBvZIcDWNT = if5dy2h0nsDVlukoQ7NUFqx4cGEW.LOGERROR
	if ghkDw9n6vVUZx7 in [QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,AAThlKoOtk0dz1sBZpPRbiV2vIe]: P7SQWVY4x1vm9tnANdiB = [SlMkfbvj8BuRsGydepihKFOHAIL]
	elif ghkDw9n6vVUZx7==xm5RwaXzSDh71KvJE3ceMBY: P7SQWVY4x1vm9tnANdiB = SlMkfbvj8BuRsGydepihKFOHAIL.split(ZPo8Gl4iTpNHb6z5e3)
	elif ghkDw9n6vVUZx7==QoGw3aixFSvDVcue0lyLHrJd:
		CFLcUmZSiEr2QMh9KRqb = SlMkfbvj8BuRsGydepihKFOHAIL.split(ZPo8Gl4iTpNHb6z5e3)
		P7SQWVY4x1vm9tnANdiB = [CFLcUmZSiEr2QMh9KRqb[wvkDqmNZlJU52isXo]]
		for WTxpgC1F98bcI5Am in range(nyUIsfd53EGot9vbj0XDeq,len(CFLcUmZSiEr2QMh9KRqb),JhTts2R43AxkM8bYanKVy):
			try: tE8UhwVFsa5dR3A = CFLcUmZSiEr2QMh9KRqb[WTxpgC1F98bcI5Am]+ZPo8Gl4iTpNHb6z5e3+CFLcUmZSiEr2QMh9KRqb[WTxpgC1F98bcI5Am+czvu7VQCZodkMf(u"࠶༈")]
			except: tE8UhwVFsa5dR3A = CFLcUmZSiEr2QMh9KRqb[WTxpgC1F98bcI5Am]
			P7SQWVY4x1vm9tnANdiB.append(tE8UhwVFsa5dR3A)
	Wb3f9TI12Ag68MCkSdiwyHc = P7SQWVY4x1vm9tnANdiB[wvkDqmNZlJU52isXo]
	for peItaQ6PDKEWvUBxAbYgrZ in P7SQWVY4x1vm9tnANdiB[nyUIsfd53EGot9vbj0XDeq:]:
		if ghkDw9n6vVUZx7 in [xm5RwaXzSDh71KvJE3ceMBY,QoGw3aixFSvDVcue0lyLHrJd]: SxMY0qDjiheQgLFT += zlMhmRicednXNAGLKqDBY1g
		Wb3f9TI12Ag68MCkSdiwyHc += vvm0bR6z8NK5wUg2l9jqrJu+cDuO1raYjgzSCVU7poi+SxMY0qDjiheQgLFT+peItaQ6PDKEWvUBxAbYgrZ
	if ghkDw9n6vVUZx7 in [AAThlKoOtk0dz1sBZpPRbiV2vIe,xm5RwaXzSDh71KvJE3ceMBY]: Wb3f9TI12Ag68MCkSdiwyHc += u43PVWjh7t9YwI
	Wb3f9TI12Ag68MCkSdiwyHc += DQIrVcKuY6bJv(u"࠭ࠠࡠࠩ൐")
	if C3w6qluao7EzUxJgMGBtV(u"ࠧࠦࠩ൑") in Wb3f9TI12Ag68MCkSdiwyHc: Wb3f9TI12Ag68MCkSdiwyHc = kLEi7mYT5wBM4DHsgWy8(Wb3f9TI12Ag68MCkSdiwyHc)
	if5dy2h0nsDVlukoQ7NUFqx4cGEW.log(Wb3f9TI12Ag68MCkSdiwyHc,level=K1KygtoLrUei7EBvZIcDWNT)
	return
def G2YXQ79epEWqfMO6zlIcHb(ttegIyhA5pV0DKZ4CXdLFU):
	try: FFkBWYseogf6EUmRPMy5A = Y7oqZy4HgtlDIxsJ.connect(ttegIyhA5pV0DKZ4CXdLFU,check_same_thread=mrhSYXH2P8bO3eJAa9n)
	except:
		if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(LdX87mwIzyBM):
			E2xjtKaMXdC3NDoTm7f5Wkev.makedirs(LdX87mwIzyBM)
			FFkBWYseogf6EUmRPMy5A = Y7oqZy4HgtlDIxsJ.connect(ttegIyhA5pV0DKZ4CXdLFU,check_same_thread=mrhSYXH2P8bO3eJAa9n)
	FFkBWYseogf6EUmRPMy5A.text_factory = str
	BuvcGxfSUokM5EV = FFkBWYseogf6EUmRPMy5A.cursor()
	BuvcGxfSUokM5EV.execute(ALwOspNtXxZrz3PEKku(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡣ࡮ࡴࡤࡦࡺࡀࡲࡴࠦ࠻ࠨ൒"))
	BuvcGxfSUokM5EV.execute(zpx2fPNKk6Ms38eD1vcO(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬࡫ࡳࡵࡲࡦࡡࡦ࡬ࡪࡩ࡫ࡠࡥࡲࡲࡸࡺࡲࡢ࡫ࡱࡸࡸࡃࡹࡦࡵࠣ࠿ࠬ൓"))
	BuvcGxfSUokM5EV.execute(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡮ࡴࡻࡲ࡯ࡣ࡯ࡣࡲࡵࡤࡦ࠿ࡒࡊࡋࠦ࠻ࠨൔ"))
	BuvcGxfSUokM5EV.execute(TVnqDYzWoM2UfHp0dchJ(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡸࡿ࡮ࡤࡪࡵࡳࡳࡵࡵࡴ࠿ࡒࡊࡋࠦ࠻ࠨൕ"))
	FFkBWYseogf6EUmRPMy5A.commit()
	return FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV
def DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,HHQuEjL250XT6GmRVisn7czlBO,kNmnfeXIgWOV1h4BQZ0dDR,bH3Gx0lKBa1hTPIu5Nz4q=()):
	GYJ52aCZBjbtgLS = UTvNakRFQC
	timeout = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠷࠰༉")
	hykr9bYviRP02tZzAG7fl3 = uv8V4fE7j9pmgFr3wnDL.time()
	import xQGdJvfp3S
	while uv8V4fE7j9pmgFr3wnDL.time()-hykr9bYviRP02tZzAG7fl3<timeout:
		try:
			if HHQuEjL250XT6GmRVisn7czlBO: GYJ52aCZBjbtgLS = BuvcGxfSUokM5EV.executemany(kNmnfeXIgWOV1h4BQZ0dDR,bH3Gx0lKBa1hTPIu5Nz4q).fetchall()
			else: GYJ52aCZBjbtgLS = BuvcGxfSUokM5EV.execute(kNmnfeXIgWOV1h4BQZ0dDR,bH3Gx0lKBa1hTPIu5Nz4q).fetchall()
			break
		except Exception as xCkBoYLfMGK1USrRZcetPO9WEiz:
			if C3w6qluao7EzUxJgMGBtV(u"ࠬࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡪࡵࠣࡰࡴࡩ࡫ࡦࡦࠪൖ") not in str(xCkBoYLfMGK1USrRZcetPO9WEiz): break
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,wPnfgxKZdAv6T10(u"࠭࠮࡝ࡶࡇࡥࡹࡧࡢࡢࡵࡨࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࠨൗ")+ttegIyhA5pV0DKZ4CXdLFU+Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡻ࡭࡫࡮ࠡࡧࡻࡩࡨࡻࡴࡪࡰࡪࠤࡹ࡮ࡩࡴࠢࡶࡸࡦࡺࡥ࡮ࡧࡱࡸࠥࠦࠠࠨ൘")+kNmnfeXIgWOV1h4BQZ0dDR)
		FFkBWYseogf6EUmRPMy5A.commit()
		uv8V4fE7j9pmgFr3wnDL.sleep(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠰࠯࠴࠸༊"))
	FFkBWYseogf6EUmRPMy5A.commit()
	return GYJ52aCZBjbtgLS
def xVYs5tfGpcvz1Br4Sel(ttegIyhA5pV0DKZ4CXdLFU,zQPURo9E0JK,eebNZFCGsvBzm2YwRK04WhJgOM,TMEbpug8yWtNeK6dmchjniZ3=UTvNakRFQC):
	qqTB9mr0Av7jKg3UOYzLl = wiPWy3I4UZ(zQPURo9E0JK)
	pRF2UtDTMJwESfOhPde1y = MMAUZiw4CoJ8.getSetting(iDhLkZS6XBagNCQfs9tq2(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ൙"))
	if eebNZFCGsvBzm2YwRK04WhJgOM not in [wPnfgxKZdAv6T10(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ൚"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡆࡒࡌࠨ൛"),ALwOspNtXxZrz3PEKku(u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡕࡒࡉࡕࡖࡈࡈࡤࡍࡏࡐࡉࡏࡉࠬ൜")] and ttegIyhA5pV0DKZ4CXdLFU==E8Eo9FKSM5bhgRYlCWZHqPmt and TMEbpug8yWtNeK6dmchjniZ3!=zpx2fPNKk6Ms38eD1vcO(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ൝"):
		if pRF2UtDTMJwESfOhPde1y==ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡓࡕࡑࡓࠫ൞"): return qqTB9mr0Av7jKg3UOYzLl
		UmEZCgu87JB = MMAUZiw4CoJ8.getSetting(iDhLkZS6XBagNCQfs9tq2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫൟ"))
		if UmEZCgu87JB==gCkRKGhwcx26v(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨൠ"):
			pk7IJW8X5Zo(ttegIyhA5pV0DKZ4CXdLFU,eebNZFCGsvBzm2YwRK04WhJgOM,TMEbpug8yWtNeK6dmchjniZ3)
			return qqTB9mr0Av7jKg3UOYzLl
	sF5oMfyVYcgHZqLlBuIeGjpbTkaR = wvkDqmNZlJU52isXo
	if pRF2UtDTMJwESfOhPde1y==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪൡ"): sF5oMfyVYcgHZqLlBuIeGjpbTkaR = jCPlGJAyS97u8ROadFzX
	FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(ttegIyhA5pV0DKZ4CXdLFU)
	if sF5oMfyVYcgHZqLlBuIeGjpbTkaR: GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪൢ")+eebNZFCGsvBzm2YwRK04WhJgOM+uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭ൣ")+str(H3a6hvAgeNctTiXF8d1uELfPr4y+sF5oMfyVYcgHZqLlBuIeGjpbTkaR)+sTGtHVyhQ9cJU37zxo2O(u"ࠬࠦ࠻ࠨ൤"))
	GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,TVnqDYzWoM2UfHp0dchJ(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭൥")+eebNZFCGsvBzm2YwRK04WhJgOM+HCiWF4jV1Q8(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩ൦")+str(H3a6hvAgeNctTiXF8d1uELfPr4y)+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࠢ࠾ࠫ൧"))
	if TMEbpug8yWtNeK6dmchjniZ3:
		GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,iDhLkZS6XBagNCQfs9tq2(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ൨")+eebNZFCGsvBzm2YwRK04WhJgOM+czvu7VQCZodkMf(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ൩"),(str(TMEbpug8yWtNeK6dmchjniZ3),))
		if GYJ52aCZBjbtgLS:
			try:
				sLjle5myuEXSiFHJ = kLtsvDVQ0SZmTjhBG9uW.decompress(GYJ52aCZBjbtgLS[wvkDqmNZlJU52isXo][wvkDqmNZlJU52isXo])
				qqTB9mr0Av7jKg3UOYzLl = LvuY3rd5OqjNAhKy6ERcM2imCnSTsG.loads(sLjle5myuEXSiFHJ)
			except: pass
	else:
		GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,sTGtHVyhQ9cJU37zxo2O(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ൪")+eebNZFCGsvBzm2YwRK04WhJgOM+l7kBpMw5Qn(u"ࠬࠨࠠ࠼ࠩ൫"))
		if GYJ52aCZBjbtgLS:
			qqTB9mr0Av7jKg3UOYzLl,DUmVxYvyC7Zs1KOoPz4BEc9f6R = {},[]
			for EWBNXn38crZsGh6axVK,bIGXajdcK6PQBs in GYJ52aCZBjbtgLS:
				l4vqDU9ocLa7YIKhdi6zxF = kLtsvDVQ0SZmTjhBG9uW.decompress(bIGXajdcK6PQBs)
				bIGXajdcK6PQBs = LvuY3rd5OqjNAhKy6ERcM2imCnSTsG.loads(l4vqDU9ocLa7YIKhdi6zxF)
				qqTB9mr0Av7jKg3UOYzLl[EWBNXn38crZsGh6axVK] = bIGXajdcK6PQBs
				DUmVxYvyC7Zs1KOoPz4BEc9f6R.append(EWBNXn38crZsGh6axVK)
			if DUmVxYvyC7Zs1KOoPz4BEc9f6R:
				qqTB9mr0Av7jKg3UOYzLl[DQIrVcKuY6bJv(u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ൬")] = DUmVxYvyC7Zs1KOoPz4BEc9f6R
				if zQPURo9E0JK==ALwOspNtXxZrz3PEKku(u"ࠧ࡭࡫ࡶࡸࠬ൭"): qqTB9mr0Av7jKg3UOYzLl = DUmVxYvyC7Zs1KOoPz4BEc9f6R
	FFkBWYseogf6EUmRPMy5A.close()
	return qqTB9mr0Av7jKg3UOYzLl
def pmvtYQxwN2EB7W(ttegIyhA5pV0DKZ4CXdLFU,eebNZFCGsvBzm2YwRK04WhJgOM,TMEbpug8yWtNeK6dmchjniZ3,qqTB9mr0Av7jKg3UOYzLl,exWfRbVLj49dFumONvtyMkDcIYJT,o1mvIetsH5JhCA2fqcVPaQ=mrhSYXH2P8bO3eJAa9n):
	pRF2UtDTMJwESfOhPde1y = MMAUZiw4CoJ8.getSetting(Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ൮"))
	if pRF2UtDTMJwESfOhPde1y==czvu7VQCZodkMf(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ൯") and exWfRbVLj49dFumONvtyMkDcIYJT>jCPlGJAyS97u8ROadFzX: exWfRbVLj49dFumONvtyMkDcIYJT = jCPlGJAyS97u8ROadFzX
	if o1mvIetsH5JhCA2fqcVPaQ:
		GhdtAy1o3Ru8z5WvkUFQ6ES,Oag9YZSMIHR = [],[]
		for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(len(TMEbpug8yWtNeK6dmchjniZ3)):
			sLjle5myuEXSiFHJ = LvuY3rd5OqjNAhKy6ERcM2imCnSTsG.dumps(qqTB9mr0Av7jKg3UOYzLl[XM3KUmO1QJxlv84bgFTHsjdNt0kYq])
			SZMyFm9bTYfjEagD0Ar7phuvH = kLtsvDVQ0SZmTjhBG9uW.compress(sLjle5myuEXSiFHJ)
			GhdtAy1o3Ru8z5WvkUFQ6ES.append((TMEbpug8yWtNeK6dmchjniZ3[XM3KUmO1QJxlv84bgFTHsjdNt0kYq],))
			Oag9YZSMIHR.append((exWfRbVLj49dFumONvtyMkDcIYJT+H3a6hvAgeNctTiXF8d1uELfPr4y,str(TMEbpug8yWtNeK6dmchjniZ3[XM3KUmO1QJxlv84bgFTHsjdNt0kYq]),SZMyFm9bTYfjEagD0Ar7phuvH))
	else:
		sLjle5myuEXSiFHJ = LvuY3rd5OqjNAhKy6ERcM2imCnSTsG.dumps(qqTB9mr0Av7jKg3UOYzLl)
		EtWUKJQnlT1dXkH5IGAy9NV3Mqf8 = kLtsvDVQ0SZmTjhBG9uW.compress(sLjle5myuEXSiFHJ)
	FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(ttegIyhA5pV0DKZ4CXdLFU)
	GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ൰")+eebNZFCGsvBzm2YwRK04WhJgOM+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ൱"))
	if o1mvIetsH5JhCA2fqcVPaQ:
		GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,BBX9RAuxnyGZ4WIF2TrhYeom3,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ൲")+eebNZFCGsvBzm2YwRK04WhJgOM+xxRyYsrSCzjifvH4cIqgldeOo(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭൳"),GhdtAy1o3Ru8z5WvkUFQ6ES)
		GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,BBX9RAuxnyGZ4WIF2TrhYeom3,ASkvf27etUK0(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ൴")+eebNZFCGsvBzm2YwRK04WhJgOM+C3w6qluao7EzUxJgMGBtV(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭൵"),Oag9YZSMIHR)
	else:
		if exWfRbVLj49dFumONvtyMkDcIYJT:
			GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,gCkRKGhwcx26v(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ൶")+eebNZFCGsvBzm2YwRK04WhJgOM+iDhLkZS6XBagNCQfs9tq2(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ൷"),(str(TMEbpug8yWtNeK6dmchjniZ3),))
			GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ൸")+eebNZFCGsvBzm2YwRK04WhJgOM+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ൹"),(exWfRbVLj49dFumONvtyMkDcIYJT+H3a6hvAgeNctTiXF8d1uELfPr4y,str(TMEbpug8yWtNeK6dmchjniZ3),EtWUKJQnlT1dXkH5IGAy9NV3Mqf8))
		else:
			GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨൺ")+eebNZFCGsvBzm2YwRK04WhJgOM+HADrRCz9QgU4xudPJIqYb70(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭ൻ"),(EtWUKJQnlT1dXkH5IGAy9NV3Mqf8,str(TMEbpug8yWtNeK6dmchjniZ3)))
	FFkBWYseogf6EUmRPMy5A.close()
	return
def pk7IJW8X5Zo(ttegIyhA5pV0DKZ4CXdLFU,eebNZFCGsvBzm2YwRK04WhJgOM,TMEbpug8yWtNeK6dmchjniZ3=UTvNakRFQC):
	FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(ttegIyhA5pV0DKZ4CXdLFU)
	if TMEbpug8yWtNeK6dmchjniZ3==UTvNakRFQC: GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪർ")+eebNZFCGsvBzm2YwRK04WhJgOM+C3w6qluao7EzUxJgMGBtV(u"ࠩࠥࠤࡀ࠭ൽ"))
	else:
		NKjPgcyufMsHzb75SLRrX = (str(TMEbpug8yWtNeK6dmchjniZ3),)
		if vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࠩࠬൾ") in TMEbpug8yWtNeK6dmchjniZ3: GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,gCkRKGhwcx26v(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫൿ")+eebNZFCGsvBzm2YwRK04WhJgOM+gCkRKGhwcx26v(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ඀"),NKjPgcyufMsHzb75SLRrX)
		else: GYJ52aCZBjbtgLS = DDs457eAxbRkrgKPHLw(ttegIyhA5pV0DKZ4CXdLFU,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,VOALf8iYEnMdK0g(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ඁ")+eebNZFCGsvBzm2YwRK04WhJgOM+Ns6AJKH7DGpr19Wl5C3nF(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧං"),NKjPgcyufMsHzb75SLRrX)
	FFkBWYseogf6EUmRPMy5A.close()
	return
class XXgLou42O0pJr1UsQIEwkP(): pass
class HvawcTdL3fq785XunkRDGE2FP(XXgLou42O0pJr1UsQIEwkP):
	def __init__(sYhGUD7CrxpWtj):
		sYhGUD7CrxpWtj.url = SebHIf2jL1TBgrMKJu
		sYhGUD7CrxpWtj.code = -ASkvf27etUK0(u"࠺࠻་")
		sYhGUD7CrxpWtj.reason = SebHIf2jL1TBgrMKJu
		sYhGUD7CrxpWtj.content = SebHIf2jL1TBgrMKJu
		sYhGUD7CrxpWtj.headers = {}
		sYhGUD7CrxpWtj.cookies = {}
		sYhGUD7CrxpWtj.succeeded = mrhSYXH2P8bO3eJAa9n
def wiPWy3I4UZ(kpiJl1MHXD5):
	if kpiJl1MHXD5==DQIrVcKuY6bJv(u"ࠨࡦ࡬ࡧࡹ࠭ඃ"): qqTB9mr0Av7jKg3UOYzLl = {}
	elif kpiJl1MHXD5==wPnfgxKZdAv6T10(u"ࠩ࡯࡭ࡸࡺࠧ඄"): qqTB9mr0Av7jKg3UOYzLl = []
	elif kpiJl1MHXD5==fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡸࡺࡶ࡬ࡦࠩඅ"): qqTB9mr0Av7jKg3UOYzLl = ()
	elif kpiJl1MHXD5==iDhLkZS6XBagNCQfs9tq2(u"ࠫࡸࡺࡲࠨආ"): qqTB9mr0Av7jKg3UOYzLl = SebHIf2jL1TBgrMKJu
	elif kpiJl1MHXD5==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬ࡯࡮ࡵࠩඇ"): qqTB9mr0Av7jKg3UOYzLl = wvkDqmNZlJU52isXo
	elif kpiJl1MHXD5==ASkvf27etUK0(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨඈ"): qqTB9mr0Av7jKg3UOYzLl = HvawcTdL3fq785XunkRDGE2FP()
	elif not kpiJl1MHXD5: qqTB9mr0Av7jKg3UOYzLl = UTvNakRFQC
	else: qqTB9mr0Av7jKg3UOYzLl = UTvNakRFQC
	return qqTB9mr0Av7jKg3UOYzLl
def YKG71Ft6ZlBHkTIgxEOySX2Qq(EcC92ZIQJAxS7wHvoMeFLWp3uORYst):
	E1OwUYq7TaD5t2XA3VMpF8yd9exrWB = MMAUZiw4CoJ8.getSetting(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪඉ"))
	unO2AmyCfZFXzp8H3 = qFsuKN7ngp.AV_CLIENT_IDS.splitlines()
	ZKVciBP5k2Af8 = wvkDqmNZlJU52isXo
	r8rTQdMpy79wz = len(EcC92ZIQJAxS7wHvoMeFLWp3uORYst)
	Oq984VWDjZQYUTSlo73i = [mrhSYXH2P8bO3eJAa9n]*r8rTQdMpy79wz
	for OWvMyIjZd18bfpB5Yi60qkr in [H3a6hvAgeNctTiXF8d1uELfPr4y,H3a6hvAgeNctTiXF8d1uELfPr4y-vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu]:
		DNi97vph1HT3SaxotdwYKjLq6bz = str(OWvMyIjZd18bfpB5Yi60qkr*l7kBpMw5Qn(u"࠴࠴࠵࠶࠰࠱࠰࠳།")/gCkRKGhwcx26v(u"࠶࠶࠶࠵࠶࠰༌"))[wvkDqmNZlJU52isXo:l7kBpMw5Qn(u"࠸༎")]
		if DNi97vph1HT3SaxotdwYKjLq6bz!=ZKVciBP5k2Af8:
			for WTxpgC1F98bcI5Am in range(r8rTQdMpy79wz):
				if not Oq984VWDjZQYUTSlo73i[WTxpgC1F98bcI5Am]:
					L6gBVcUknMYil4RjQImrHyDwEoWd = mrhSYXH2P8bO3eJAa9n
					for ERTCSts1aoqJcrlbWw9p in unO2AmyCfZFXzp8H3:
						bbaXVANHDQM5ykTurUjlch = HCiWF4jV1Q8(u"ࠨ࡚࠴࠽ࠬඊ")+EcC92ZIQJAxS7wHvoMeFLWp3uORYst[WTxpgC1F98bcI5Am]+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩ࠴࠼ࡂ࠭උ")+ERTCSts1aoqJcrlbWw9p[-gCkRKGhwcx26v(u"࠷࠺༏"):]+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+DNi97vph1HT3SaxotdwYKjLq6bz
						bbaXVANHDQM5ykTurUjlch = Z9w7UrhMLl.md5(bbaXVANHDQM5ykTurUjlch.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()[:gCkRKGhwcx26v(u"࠹࠲༐")]
						if bbaXVANHDQM5ykTurUjlch in E1OwUYq7TaD5t2XA3VMpF8yd9exrWB:
							L6gBVcUknMYil4RjQImrHyDwEoWd = BBX9RAuxnyGZ4WIF2TrhYeom3
							break
					Oq984VWDjZQYUTSlo73i[WTxpgC1F98bcI5Am] = L6gBVcUknMYil4RjQImrHyDwEoWd
		ZKVciBP5k2Af8 = DNi97vph1HT3SaxotdwYKjLq6bz
	return Oq984VWDjZQYUTSlo73i
class cQz8gGB5DYb0(yMIqCQzL2KF4uRxA9mP6DHhb7JEY):
	def __init__(sYhGUD7CrxpWtj): pass
	def ULDCkHiJr1Pa6YeyNp(sYhGUD7CrxpWtj,zzAyFWoHq0n):
		sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = HADrRCz9QgU4xudPJIqYb70(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫඌ") if qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW else SebHIf2jL1TBgrMKJu
		sYhGUD7CrxpWtj.zzAyFWoHq0n = zzAyFWoHq0n
		if not qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h:
			import RSdDifzoPG
			RSdDifzoPG.zGBSOdsWh8uLHbfw9qmxlioR7tDpy(B3vhTYqOtgUCAzPW)
	def onPlayBackStopped(sYhGUD7CrxpWtj): sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = HCiWF4jV1Q8(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫඍ")
	def onPlayBackError(sYhGUD7CrxpWtj): sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = l7kBpMw5Qn(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬඎ")
	def onPlayBackEnded(sYhGUD7CrxpWtj): sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = l7kBpMw5Qn(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ඏ")
	def onPlayBackStarted(sYhGUD7CrxpWtj):
		sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨඐ")
		ooWU7FESxrq = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=sYhGUD7CrxpWtj.UpKmHsrz9DZ3vbg)
		ooWU7FESxrq.start()
	def onAVStarted(sYhGUD7CrxpWtj):
		if qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h: sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩඑ")
		else: sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = TVnqDYzWoM2UfHp0dchJ(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪඒ")
	def UpKmHsrz9DZ3vbg(sYhGUD7CrxpWtj):
		G2GK8AxnsRJhwZB = wvkDqmNZlJU52isXo
		while not eval(wPnfgxKZdAv6T10(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨඓ"),{AGlW9LqKN3Dvo(u"ࠫࡽࡨ࡭ࡤࠩඔ"):if5dy2h0nsDVlukoQ7NUFqx4cGEW}) and sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj==sTGtHVyhQ9cJU37zxo2O(u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭ඕ"):
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.sleep(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠱࠱࠲࠳༑"))
			G2GK8AxnsRJhwZB += nyUIsfd53EGot9vbj0XDeq
			if G2GK8AxnsRJhwZB>VOALf8iYEnMdK0g(u"࠷࠲༒"): return
		if qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW: sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧඖ")
		elif qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h: sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ඗")
		elif qFsuKN7ngp.rrhvjIPfCsFXxqwHcQeES8JROG:
			import RSdDifzoPG
			sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = C3w6qluao7EzUxJgMGBtV(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ඘")
			InkX1ZEcl3yBf(wPnfgxKZdAv6T10(u"ࠩࡶࡸࡴࡶࠧ඙"),BBX9RAuxnyGZ4WIF2TrhYeom3)
			wAN6XeWdEL0 = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=RSdDifzoPG.YyqPk3DKne2FUf8RgC,args=(sYhGUD7CrxpWtj.zzAyFWoHq0n,)).start()
			EifNuSGmjg8BAo = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=RSdDifzoPG.T9UcRu2AJVBnDg3SFfQKwL6js).start()
		else: sYhGUD7CrxpWtj.CSf51aVe2YWHTUQAv87odsRmhtj = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫක")
def UUr1GlbQW9djom8O6wVp():
	OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	ih2dUNwGxIVv80tDaC = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪඛ"))
	try:
		BB8FThO5uGIiCKMs0evlq4pz = open(czvu7VQCZodkMf(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬග"),TVnqDYzWoM2UfHp0dchJ(u"࠭ࡲࡣࠩඝ")).read()
		if QBOMjKifEAFD: BB8FThO5uGIiCKMs0evlq4pz = BB8FThO5uGIiCKMs0evlq4pz.decode(Tv08xsf9HOqunIVUPdK1)
		PfxaBidcr4tF0nJEZwGS7HVm6IvhC = X2XorVqHjLkWeCchY4u9fSz.findall(czvu7VQCZodkMf(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫඞ"),BB8FThO5uGIiCKMs0evlq4pz,X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		if PfxaBidcr4tF0nJEZwGS7HVm6IvhC: OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY = PfxaBidcr4tF0nJEZwGS7HVm6IvhC[wvkDqmNZlJU52isXo]
	except: pass
	try:
		import subprocess as xzDyTRiG0BNtAu3okUgFEnM4
		qDCoXBSULufYwprzmvbjHTJE41GcK = xzDyTRiG0BNtAu3okUgFEnM4.Popen(DQIrVcKuY6bJv(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭ඟ"),shell=BBX9RAuxnyGZ4WIF2TrhYeom3,stdin=xzDyTRiG0BNtAu3okUgFEnM4.PIPE,stdout=xzDyTRiG0BNtAu3okUgFEnM4.PIPE,stderr=xzDyTRiG0BNtAu3okUgFEnM4.PIPE)
		jZOvYMGXibVDT7KJzx5W34NwayU = qDCoXBSULufYwprzmvbjHTJE41GcK.stdout.read()
		if jZOvYMGXibVDT7KJzx5W34NwayU:
			if QBOMjKifEAFD:
				jZOvYMGXibVDT7KJzx5W34NwayU = jZOvYMGXibVDT7KJzx5W34NwayU.decode(Tv08xsf9HOqunIVUPdK1,zpx2fPNKk6Ms38eD1vcO(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩච"))
			cM3nwFYAOup4DhaWKfkzGNiXb16 = X2XorVqHjLkWeCchY4u9fSz.findall(zpx2fPNKk6Ms38eD1vcO(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧඡ"),jZOvYMGXibVDT7KJzx5W34NwayU,X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
			if cM3nwFYAOup4DhaWKfkzGNiXb16: Jz3xh0uerkBl2Wd5PsR49TDv = min(cM3nwFYAOup4DhaWKfkzGNiXb16)
	except: pass
	return ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv
def GN2SztT85ChvfWxJbdoUa(HH1pTVkf2oF7U4ZKSQGMBr=BBX9RAuxnyGZ4WIF2TrhYeom3,zmWBb6RMtEhNw7j1HrdI9pTyVnXve=Izy1PvclrYx4eSVWn0L5phZbq(u"࠵࠵༓")):
	cqsyL5vlAg3XMuZ4bnEt = BBX9RAuxnyGZ4WIF2TrhYeom3
	if HH1pTVkf2oF7U4ZKSQGMBr:
		TTf9DWeu1c6z4Gri = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡱ࡯ࡳࡵࠩජ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨඣ"),HADrRCz9QgU4xudPJIqYb70(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫඤ"))
		if TTf9DWeu1c6z4Gri:
			sVGM49BtqDdTgc1wNCLv3eWIkxQEO6,hlReJLdPnZKAiwpBa4,qkdtH74QsV53KEweDbnvFSy,orUTaWs6uKGPmMICNkpXJEYH2vD0n = TTf9DWeu1c6z4Gri
			cqsyL5vlAg3XMuZ4bnEt = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,gCkRKGhwcx26v(u"ࠧ࡭࡫ࡶࡸࠬඥ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫඦ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨට"))
			if cqsyL5vlAg3XMuZ4bnEt: ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv = cqsyL5vlAg3XMuZ4bnEt
			else: ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv = UUr1GlbQW9djom8O6wVp()
			if (hlReJLdPnZKAiwpBa4,qkdtH74QsV53KEweDbnvFSy,orUTaWs6uKGPmMICNkpXJEYH2vD0n)==(ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv):
				mmBkrR9tdVMIhGbn = u43PVWjh7t9YwI.join(sVGM49BtqDdTgc1wNCLv3eWIkxQEO6)
				return mmBkrR9tdVMIhGbn
	if cqsyL5vlAg3XMuZ4bnEt: ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv = UUr1GlbQW9djom8O6wVp()
	global q41y2VMAsW9vPRfhK,URyaQuChf5rzsme0x4BwjlGPTtoF1E
	q41y2VMAsW9vPRfhK,URyaQuChf5rzsme0x4BwjlGPTtoF1E,HT1r4KFbJeMDp5i = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	zmWBb6RMtEhNw7j1HrdI9pTyVnXve = zmWBb6RMtEhNw7j1HrdI9pTyVnXve//JhTts2R43AxkM8bYanKVy
	yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=IvWe2a5718s6Fdy3riRmLqc).start()
	yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=UBk1otCrsbyihjeEm).start()
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(zpx2fPNKk6Ms38eD1vcO(u"࠴࠴༔")):
		uv8V4fE7j9pmgFr3wnDL.sleep(DQIrVcKuY6bJv(u"࠴࠳࠻༕"))
		if not HT1r4KFbJeMDp5i:
			try:
				PiWAB5sTqI1D = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(HADrRCz9QgU4xudPJIqYb70(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨඨ"))
				if PiWAB5sTqI1D.count(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫ࠿࠭ඩ"))==vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs and PiWAB5sTqI1D.count(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬ࠶ࠧඪ"))<Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠾༖"):
					PiWAB5sTqI1D = PiWAB5sTqI1D.lower().replace(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭࠺ࠨණ"),SebHIf2jL1TBgrMKJu)
					HT1r4KFbJeMDp5i = str(int(PiWAB5sTqI1D,TVnqDYzWoM2UfHp0dchJ(u"࠷࠶༗")))
			except: pass
		if q41y2VMAsW9vPRfhK and URyaQuChf5rzsme0x4BwjlGPTtoF1E and HT1r4KFbJeMDp5i: break
	hNw9PT8KvXiZGMpzxJae2LYQDj = [URyaQuChf5rzsme0x4BwjlGPTtoF1E,q41y2VMAsW9vPRfhK,HT1r4KFbJeMDp5i,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪඬ")]
	if OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY or Jz3xh0uerkBl2Wd5PsR49TDv:
		ISVu2fkjF9ptwBLH8o0JcYWDa365z = [(K7cnfQMS6BPvI4LGmCsRp8bUlJ9,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY),(vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs,Jz3xh0uerkBl2Wd5PsR49TDv)]
		for BXCThrgedxOyF2N,NNZoTVqIcEG6l in ISVu2fkjF9ptwBLH8o0JcYWDa365z:
			NNZoTVqIcEG6l = NNZoTVqIcEG6l.strip(bcNqYtfET5l92dLGjyZSPe(u"ࠨ࠲ࠪත"))
			if NNZoTVqIcEG6l:
				if QBOMjKifEAFD: NNZoTVqIcEG6l = NNZoTVqIcEG6l.encode(Tv08xsf9HOqunIVUPdK1)
				NNZoTVqIcEG6l = str(int(Z9w7UrhMLl.md5(NNZoTVqIcEG6l).hexdigest(),HCiWF4jV1Q8(u"࠳࠷༘")))
				HOGsi5WVEdxeSJ41RKoC = [int(NNZoTVqIcEG6l[O5Q30hwf4Jke:O5Q30hwf4Jke+gCkRKGhwcx26v(u"࠲࠷༙")]) for O5Q30hwf4Jke in range(len(NNZoTVqIcEG6l)) if O5Q30hwf4Jke%gCkRKGhwcx26v(u"࠲࠷༙")==wvkDqmNZlJU52isXo]
				hNw9PT8KvXiZGMpzxJae2LYQDj[BXCThrgedxOyF2N-nyUIsfd53EGot9vbj0XDeq] = str(sum(HOGsi5WVEdxeSJ41RKoC))
	unO2AmyCfZFXzp8H3,KRAL1Xg7GeUPYvTh6zytqMnxcj0HoE = [],mrhSYXH2P8bO3eJAa9n
	for HEY6Pwlj8CB,HOGsi5WVEdxeSJ41RKoC in enumerate(hNw9PT8KvXiZGMpzxJae2LYQDj):
		if not HOGsi5WVEdxeSJ41RKoC: continue
		if KRAL1Xg7GeUPYvTh6zytqMnxcj0HoE and HOGsi5WVEdxeSJ41RKoC==hNw9PT8KvXiZGMpzxJae2LYQDj[-nyUIsfd53EGot9vbj0XDeq]: continue
		KRAL1Xg7GeUPYvTh6zytqMnxcj0HoE = BBX9RAuxnyGZ4WIF2TrhYeom3
		HOGsi5WVEdxeSJ41RKoC = vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࠳ࠫථ")*zmWBb6RMtEhNw7j1HrdI9pTyVnXve+HOGsi5WVEdxeSJ41RKoC
		HOGsi5WVEdxeSJ41RKoC = HOGsi5WVEdxeSJ41RKoC[-zmWBb6RMtEhNw7j1HrdI9pTyVnXve:]
		E8Ca5IQUvnedAoOyqRjXYLJb7GKs,wwxAgYqEmd6Mj7cbDC0F = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
		cfGFlA6zp97 = str(int(DQIrVcKuY6bJv(u"ࠪ࠽ࠬද")*(zmWBb6RMtEhNw7j1HrdI9pTyVnXve+nyUIsfd53EGot9vbj0XDeq))-int(HOGsi5WVEdxeSJ41RKoC))[-zmWBb6RMtEhNw7j1HrdI9pTyVnXve:]
		for WTxpgC1F98bcI5Am in list(range(wvkDqmNZlJU52isXo,zmWBb6RMtEhNw7j1HrdI9pTyVnXve,K7cnfQMS6BPvI4LGmCsRp8bUlJ9)):
			E8Ca5IQUvnedAoOyqRjXYLJb7GKs += cfGFlA6zp97[WTxpgC1F98bcI5Am:WTxpgC1F98bcI5Am+K7cnfQMS6BPvI4LGmCsRp8bUlJ9]+VOALf8iYEnMdK0g(u"ࠫ࠲࠭ධ")
			wwxAgYqEmd6Mj7cbDC0F += str(sum(map(int,HOGsi5WVEdxeSJ41RKoC[WTxpgC1F98bcI5Am:WTxpgC1F98bcI5Am+K7cnfQMS6BPvI4LGmCsRp8bUlJ9]))%v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠳࠳༚"))
		ERTCSts1aoqJcrlbWw9p = str(HEY6Pwlj8CB)+E8Ca5IQUvnedAoOyqRjXYLJb7GKs+wwxAgYqEmd6Mj7cbDC0F
		unO2AmyCfZFXzp8H3.append(ERTCSts1aoqJcrlbWw9p)
	W9xjJXpYr8IPyd0hs45Z7USnHbK,sVGM49BtqDdTgc1wNCLv3eWIkxQEO6 = [],[]
	for user in unO2AmyCfZFXzp8H3:
		count = str(str(unO2AmyCfZFXzp8H3).count(user[v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠴༛"):]))
		W9xjJXpYr8IPyd0hs45Z7USnHbK.append(count+user)
	W9xjJXpYr8IPyd0hs45Z7USnHbK = sorted(W9xjJXpYr8IPyd0hs45Z7USnHbK,reverse=BBX9RAuxnyGZ4WIF2TrhYeom3,key=lambda key: key[wvkDqmNZlJU52isXo])
	for user in W9xjJXpYr8IPyd0hs45Z7USnHbK: sVGM49BtqDdTgc1wNCLv3eWIkxQEO6.append(user[nyUIsfd53EGot9vbj0XDeq:])
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨන"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ඲"),[ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv],QfG1xIZ4hpq3ezPXt7VbvglUcB)
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,AGlW9LqKN3Dvo(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪඳ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ප"),[sVGM49BtqDdTgc1wNCLv3eWIkxQEO6,ih2dUNwGxIVv80tDaC,OHUpWzDGv6r0yPdxRu7Awt1hK5FaNY,Jz3xh0uerkBl2Wd5PsR49TDv],QfG1xIZ4hpq3ezPXt7VbvglUcB)
	for user in qFsuKN7ngp.BADCOMMONIDS:
		if user in sVGM49BtqDdTgc1wNCLv3eWIkxQEO6: sVGM49BtqDdTgc1wNCLv3eWIkxQEO6.remove(user)
	mmBkrR9tdVMIhGbn = u43PVWjh7t9YwI.join(sVGM49BtqDdTgc1wNCLv3eWIkxQEO6)
	return mmBkrR9tdVMIhGbn
def IvWe2a5718s6Fdy3riRmLqc():
	global q41y2VMAsW9vPRfhK
	try:
		import getmac82 as TyhRALjnaklspoEdmJSIgiFz
		sSH8Tmp1XNbUVD = TyhRALjnaklspoEdmJSIgiFz.get_mac_address()
		if sSH8Tmp1XNbUVD.count(Ns6AJKH7DGpr19Wl5C3nF(u"ࠩ࠽ࠫඵ"))==vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs and sSH8Tmp1XNbUVD.count(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࠴ࠬබ"))<Gykx0wL3XrlWaujsqKP9n2Q(u"࠽༜"):
			sSH8Tmp1XNbUVD = sSH8Tmp1XNbUVD.lower().replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠫ࠿࠭භ"),SebHIf2jL1TBgrMKJu)
			q41y2VMAsW9vPRfhK = str(int(sSH8Tmp1XNbUVD,sTGtHVyhQ9cJU37zxo2O(u"࠶࠼༝")))
	except: pass
	return
def UBk1otCrsbyihjeEm():
	global URyaQuChf5rzsme0x4BwjlGPTtoF1E
	try:
		import getmac95 as zTgeB69yJtEYLaPwqQoCvWD
		mhIGQvRrpCeysOPc6U0fxW3 = zTgeB69yJtEYLaPwqQoCvWD.get_mac_address()
		if mhIGQvRrpCeysOPc6U0fxW3.count(TVnqDYzWoM2UfHp0dchJ(u"ࠬࡀࠧම"))==vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs and mhIGQvRrpCeysOPc6U0fxW3.count(Ns6AJKH7DGpr19Wl5C3nF(u"࠭࠰ࠨඹ"))<bcNqYtfET5l92dLGjyZSPe(u"࠿༞"):
			mhIGQvRrpCeysOPc6U0fxW3 = mhIGQvRrpCeysOPc6U0fxW3.lower().replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࠻ࠩය"),SebHIf2jL1TBgrMKJu)
			URyaQuChf5rzsme0x4BwjlGPTtoF1E = str(int(mhIGQvRrpCeysOPc6U0fxW3,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠱࠷༟")))
	except: pass
	return
def gNEVvUpHfrcun0Q68(kpiJl1MHXD5,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6,oHSdD2N140BnjWsOk):
	for F1NtCTopn4wAOhBSY8XqUJQD2 in JXh2G7m5dZiFEj3HMSRB8we:
		if F1NtCTopn4wAOhBSY8XqUJQD2 in pfhH2objgVkI7eycn: pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.replace(F1NtCTopn4wAOhBSY8XqUJQD2,SebHIf2jL1TBgrMKJu)
		if F1NtCTopn4wAOhBSY8XqUJQD2 in gTnyji0CwRW81: gTnyji0CwRW81 = gTnyji0CwRW81.replace(F1NtCTopn4wAOhBSY8XqUJQD2,SebHIf2jL1TBgrMKJu)
	REIkboX9NtlZCSU3A = str(gTnyji0CwRW81)[wvkDqmNZlJU52isXo:AGlW9LqKN3Dvo(u"࠳࠷࠳༠")].replace(u43PVWjh7t9YwI,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡞࡟ࡲࠬර")).replace(vvm0bR6z8NK5wUg2l9jqrJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ࡟ࡠࡷ࠭඼")).replace(saNjmrfQDGgltv,qE4nB3mKWHs).replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs)
	if len(str(gTnyji0CwRW81))>Ns6AJKH7DGpr19Wl5C3nF(u"࠴࠸࠴༡"): REIkboX9NtlZCSU3A = REIkboX9NtlZCSU3A+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࠤ࠳࠴࠮ࠨල")
	bIGXajdcK6PQBs = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࠳࠴࠮ࠨ඾")
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,gCkRKGhwcx26v(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࠧ඿")+kpiJl1MHXD5+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩව")+pfhH2objgVkI7eycn+l7kBpMw5Qn(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩශ")+qh4B9VQZCbXr0DRknFmi7J6+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪෂ")+oHSdD2N140BnjWsOk+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬස")+str(REIkboX9NtlZCSU3A)+iDhLkZS6XBagNCQfs9tq2(u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪහ")+bIGXajdcK6PQBs+vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࠥࡣࠧළ"))
	return
def nnyt5esYvlQ0zUZCJW4bgiAB2uxFL(oHSdD2N140BnjWsOk,RqSeJOZW6Bg8,qqTB9mr0Av7jKg3UOYzLl=SebHIf2jL1TBgrMKJu,gTnyji0CwRW81=SebHIf2jL1TBgrMKJu,qh4B9VQZCbXr0DRknFmi7J6=SebHIf2jL1TBgrMKJu):
	if QBOMjKifEAFD: import urllib.request as pfTzSjbR9B
	else: import urllib2 as pfTzSjbR9B
	if not gTnyji0CwRW81: gTnyji0CwRW81 = {qeYIw0BNTL9bGJnosacQ1DtVR(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩෆ"):SebHIf2jL1TBgrMKJu}
	if not qqTB9mr0Av7jKg3UOYzLl: qqTB9mr0Av7jKg3UOYzLl = {}
	X7XuLMTp3fUgYnH6eFB5zP = qqTB9mr0Av7jKg3UOYzLl
	TQgoVIpwAjq6l = RqSeJOZW6Bg8 in qFsuKN7ngp.SITESURLS[AGlW9LqKN3Dvo(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෇")]
	if TQgoVIpwAjq6l:
		oHSdD2N140BnjWsOk = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡑࡑࡖࡘࠬ෈")
		gTnyji0CwRW81[wPnfgxKZdAv6T10(u"ࠨࡃ࡙࠱ࡊࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠨ෉")] = Gykx0wL3XrlWaujsqKP9n2Q(u"࡙ࠩࡩࡷࡹࡩࡰࡰࠣ࠵࠳࠶්ࠧ")
		I6Kk8GXBhuEgns7pNdbJfr = ddWZPUnz9Cljm.dumps(qqTB9mr0Av7jKg3UOYzLl)
		import RSdDifzoPG
		X7XuLMTp3fUgYnH6eFB5zP = RSdDifzoPG.B1BD67cV8sYopU24Wrhxw(I6Kk8GXBhuEgns7pNdbJfr,sTGtHVyhQ9cJU37zxo2O(u"࠻࠵࠷࠽࠴࠺࠵࠸࠺༢"))
		RqSeJOZW6Bg8 = RqSeJOZW6Bg8+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡃࡺࡹࡥࡳ࠿ࠪ෋")+hAd4IGxEFmnpwg
	elif oHSdD2N140BnjWsOk==wPnfgxKZdAv6T10(u"ࠫࡌࡋࡔࠨ෌"):
		RqSeJOZW6Bg8 = pfhH2objgVkI7eycn+TVnqDYzWoM2UfHp0dchJ(u"ࠬࡅࠧ෍")+zzM3SJI56FnHqsRGAXe(qqTB9mr0Av7jKg3UOYzLl)
		X7XuLMTp3fUgYnH6eFB5zP = UTvNakRFQC
	elif oHSdD2N140BnjWsOk==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡐࡐࡕࡗࠫ෎") and ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧ࡫ࡵࡲࡲࠬා") in str(gTnyji0CwRW81):
		qqTB9mr0Av7jKg3UOYzLl = ddWZPUnz9Cljm.dumps(qqTB9mr0Av7jKg3UOYzLl)
		X7XuLMTp3fUgYnH6eFB5zP = str(qqTB9mr0Av7jKg3UOYzLl).encode(Tv08xsf9HOqunIVUPdK1)
	elif oHSdD2N140BnjWsOk==qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡒࡒࡗ࡙࠭ැ"):
		qqTB9mr0Av7jKg3UOYzLl = zzM3SJI56FnHqsRGAXe(qqTB9mr0Av7jKg3UOYzLl)
		X7XuLMTp3fUgYnH6eFB5zP = qqTB9mr0Av7jKg3UOYzLl.encode(Tv08xsf9HOqunIVUPdK1)
	gNEVvUpHfrcun0Q68(HADrRCz9QgU4xudPJIqYb70(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧෑ"),RqSeJOZW6Bg8,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6,oHSdD2N140BnjWsOk)
	try:
		fie9zpGPmCNH = pfTzSjbR9B.Request(RqSeJOZW6Bg8,headers=gTnyji0CwRW81,data=X7XuLMTp3fUgYnH6eFB5zP)
		Vq3XpLGKo4zlSR59wBrhjAbcamJDie = pfTzSjbR9B.urlopen(fie9zpGPmCNH)
		i39emuhJVLH8AfSIdo4 = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.read()
		bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠶࠵࠶༣"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡓࡐ࠭ි")
	except:
		i39emuhJVLH8AfSIdo4 = SebHIf2jL1TBgrMKJu
		bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = -nyUIsfd53EGot9vbj0XDeq,VOALf8iYEnMdK0g(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫී")
	try:
		if TQgoVIpwAjq6l and i39emuhJVLH8AfSIdo4:
			bkzomAh93gO1HMsqWT8faLdiUR = {OL7InSQdMpsFA0.lower(): zzpMrn7D0KCjtNqRuoQILvO83 for OL7InSQdMpsFA0, zzpMrn7D0KCjtNqRuoQILvO83 in Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers.items()}
			if bkzomAh93gO1HMsqWT8faLdiUR.get(iDhLkZS6XBagNCQfs9tq2(u"ࠬࡧࡶ࠮ࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬු"))==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫ෕"):
				i39emuhJVLH8AfSIdo4,PXWrg9Tz56VAmM1ocG2 = RSdDifzoPG.DHLWKi5fq3gyUAvc7ZE21(i39emuhJVLH8AfSIdo4,HADrRCz9QgU4xudPJIqYb70(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼༤"))
				if PXWrg9Tz56VAmM1ocG2==HCiWF4jV1Q8(u"ࠧࡊࡐ࡙ࡅࡑࡏࡄࡠࡖࡌࡑࡊ࡙ࡔࡂࡏࡓࠫූ"):
					JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz,bY3gNleaHWrMKDw = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡄࡔࡎࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠩ෗"),-vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
					i39emuhJVLH8AfSIdo4 = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz
	except: i39emuhJVLH8AfSIdo4 = SebHIf2jL1TBgrMKJu
	if QBOMjKifEAFD and isinstance(i39emuhJVLH8AfSIdo4,bytes): i39emuhJVLH8AfSIdo4 = i39emuhJVLH8AfSIdo4.decode(Tv08xsf9HOqunIVUPdK1)
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,iDhLkZS6XBagNCQfs9tq2(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫෘ")+str(bY3gNleaHWrMKDw)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬෙ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ේ")+qh4B9VQZCbXr0DRknFmi7J6+vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫෛ")+RqSeJOZW6Bg8+uqLUBHepfM3l6AyIzTJh80a(u"࠭ࠠ࡞ࠩො"))
	return i39emuhJVLH8AfSIdo4
def FdjHEQn68kzOB9UZ3WoRfLr(pnmkjy9g2Bs0oDVzwdO5v):
	BmAv6IdzPXjTn9tFkfY1EwNUDCgp = str(JO7n9zxwdgIStrTjR.randrange(zpx2fPNKk6Ms38eD1vcO(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴༥"),HCiWF4jV1Q8(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽༦")))
	tWDBxYNGdTJvK8Ep632l40eSZnyiA = {
		tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣෝ"):hAd4IGxEFmnpwg,
		HADrRCz9QgU4xudPJIqYb70(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧෞ"):str(zzGetSI9yqnbZh),
		t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢෟ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,
		fp6KV7DlS8QYniUczHdmZChL(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥ෠"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,
		NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ෡"): xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,
		cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨ෢"):Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨ෣"),
		v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠢࡪࡲࠥ෤"): vMhFypGLHZJbdX4O7oc3W8x(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ෥"),
		Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣ෦"):mrhSYXH2P8bO3eJAa9n
	}
	VuIrMx6HJwDsacOEz5RXvW = []
	for QUWsbGoFmngMKlTpz7id in pnmkjy9g2Bs0oDVzwdO5v:
		DDj8NqZIHVmeMUTk = tWDBxYNGdTJvK8Ep632l40eSZnyiA.copy()
		DDj8NqZIHVmeMUTk[ALwOspNtXxZrz3PEKku(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ෧")] = QUWsbGoFmngMKlTpz7id
		DDj8NqZIHVmeMUTk[t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ෨")] = {AGlW9LqKN3Dvo(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ෩"):QUWsbGoFmngMKlTpz7id}
		DDj8NqZIHVmeMUTk[ASkvf27etUK0(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ෪")] = {Gykx0wL3XrlWaujsqKP9n2Q(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ෫"):QUWsbGoFmngMKlTpz7id}
		VuIrMx6HJwDsacOEz5RXvW.append(DDj8NqZIHVmeMUTk)
	qqTB9mr0Av7jKg3UOYzLl = {
		VOALf8iYEnMdK0g(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ෬"):gCkRKGhwcx26v(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧ෭"),
		xxRyYsrSCzjifvH4cIqgldeOo(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ෮"):BmAv6IdzPXjTn9tFkfY1EwNUDCgp,
		t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ෯"): VuIrMx6HJwDsacOEz5RXvW
	}
	gTnyji0CwRW81 = {cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ෰"):ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ෱")}
	pfhH2objgVkI7eycn = HCiWF4jV1Q8(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩෲ")
	YD0R1z8ldmipE = nnyt5esYvlQ0zUZCJW4bgiAB2uxFL(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡒࡒࡗ࡙࠭ෳ"),pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,ALwOspNtXxZrz3PEKku(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ෴"))
	return YD0R1z8ldmipE
def XakdNYy7EbqiSr5ZKBeF8HCDtAQL(e9BvxdAEl7CzWSiaROuy):
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(C3w6qluao7EzUxJgMGBtV(u"ࡵࠫ࠭ࡢࡳࠪࠤࠫࡠࡼ࠯ࠧ෵"), bcNqYtfET5l92dLGjyZSPe(u"ࡶࠬࡢ࠱࡝࡞ࠥࡠ࠷࠭෶"), e9BvxdAEl7CzWSiaROuy)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(ASkvf27etUK0(u"ࡷ࠭ࠨ࡝ࡹࠬࠦ࠭ࡢࡳࠪࠩ෷"), HCiWF4jV1Q8(u"ࡸࠧ࡝࠳࡟ࡠࠧࡢ࠲ࠨ෸"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࡲࠨࠪ࡟ࡻ࠮ࠨࠨ࡝ࡹࠬࠫ෹"), Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࡳࠩ࡟࠵ࡡࡢࠢ࡝࠴ࠪ෺"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(AGlW9LqKN3Dvo(u"ࡴࠪࠬࡡࡹࠩࠣࠪ࡟ࡷ࠮࠭෻"), xxRyYsrSCzjifvH4cIqgldeOo(u"ࡵࠫࡡ࠷࡜࡝ࠤ࡟࠶ࠬ෼"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(HCiWF4jV1Q8(u"ࡶࠧ࠮࡜ࡴࠫࠪࠬࡡࡽࠩࠣ෽"), Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࡷࠨ࡜࠲࡞࡟ࠫࡡ࠸ࠢ෾"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࡸࠢࠩ࡞ࡺ࠭ࠬ࠮࡜ࡴࠫࠥ෿"), tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࡲࠣ࡞࠴ࡠࡡ࠭࡜࠳ࠤ฀"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࡳࠤࠫࡠࡼ࠯ࠧࠩ࡞ࡺ࠭ࠧก"), cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࡴࠥࡠ࠶ࡢ࡜ࠨ࡞࠵ࠦข"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࡵࠦ࠭ࡢࡳࠪࠩࠫࡠࡸ࠯ࠢฃ"), HCiWF4jV1Q8(u"ࡶࠧࡢ࠱࡝࡞ࠪࡠ࠷ࠨค"), k81kYcVrPNC6wFGO9lmaX)
	SSbYWIfVDZj61t9 = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࡷ࡛࠭࡝࡝࡟ࡡࢀࢃࠨࠪ࠼࠯ࡡࠬฅ")
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(TVnqDYzWoM2UfHp0dchJ(u"ࡸࠧࠩ࡞ࡺ࠭࠭࠭ฆ") + SSbYWIfVDZj61t9 + czvu7VQCZodkMf(u"ࡲࠨࠫࠫࡠࡼ࠯ࠧง"), czvu7VQCZodkMf(u"ࡳࠩ࡟࠵ࡡࡢ࡜࠳࡞࠶ࠫจ"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࡴࠪࠬࡡࡹࠩࠩࠩฉ") + SSbYWIfVDZj61t9 + Gykx0wL3XrlWaujsqKP9n2Q(u"ࡵࠫ࠮࠮࡜ࡸࠫࠪช"), AGlW9LqKN3Dvo(u"ࡶࠬࡢ࠱࡝࡞࡟࠶ࡡ࠹ࠧซ"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(Ns6AJKH7DGpr19Wl5C3nF(u"ࡷ࠭ࠨ࡝ࡹࠬࠬࠬฌ") + SSbYWIfVDZj61t9 + tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࡸࠧࠪࠪ࡟ࡷ࠮࠭ญ"), v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࡲࠨ࡞࠴ࡠࡡࡢ࠲࡝࠵ࠪฎ"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࡳࠩࠫࡠࡸ࠯ࠨࠨฏ") + SSbYWIfVDZj61t9 + l7kBpMw5Qn(u"ࡴࠪ࠭࠭ࡢࡳࠪࠩฐ"), C3w6qluao7EzUxJgMGBtV(u"ࡵࠫࡡ࠷࡜࡝࡞࠵ࡠ࠸࠭ฑ"), k81kYcVrPNC6wFGO9lmaX)
	k81kYcVrPNC6wFGO9lmaX = X2XorVqHjLkWeCchY4u9fSz.sub(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࡶࠬ࠮࡜ࡸࠫ࡟ࡠ࠭ࡢࡷࠪࠩฒ"), TVnqDYzWoM2UfHp0dchJ(u"ࡷ࠭࡜࠲࡞࡟ࡠࡡࡢ࠲ࠨณ"), k81kYcVrPNC6wFGO9lmaX)
	return k81kYcVrPNC6wFGO9lmaX
def xjVJ0o7mF86tCDagkbNcrTAR4UH(zQPURo9E0JK,X9naxNqy0ICz3cG5up4ZmQi2OSlTU):
	X9naxNqy0ICz3cG5up4ZmQi2OSlTU = X9naxNqy0ICz3cG5up4ZmQi2OSlTU.replace(fp6KV7DlS8QYniUczHdmZChL(u"࠭࡮ࡶ࡮࡯ࠫด"),C3w6qluao7EzUxJgMGBtV(u"ࠧࡏࡱࡱࡩࠬต"))
	X9naxNqy0ICz3cG5up4ZmQi2OSlTU = X9naxNqy0ICz3cG5up4ZmQi2OSlTU.replace(fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡶࡵࡹࡪ࠭ถ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡗࡶࡺ࡫ࠧท"))
	X9naxNqy0ICz3cG5up4ZmQi2OSlTU = X9naxNqy0ICz3cG5up4ZmQi2OSlTU.replace(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡪࡦࡲࡳࡦࠩธ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡋࡧ࡬ࡴࡧࠪน"))
	X9naxNqy0ICz3cG5up4ZmQi2OSlTU = X9naxNqy0ICz3cG5up4ZmQi2OSlTU.replace(sTGtHVyhQ9cJU37zxo2O(u"ࠬࡢ࠯ࠨบ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠭࠯ࠨป"))
	X9naxNqy0ICz3cG5up4ZmQi2OSlTU = X9naxNqy0ICz3cG5up4ZmQi2OSlTU.replace(bcNqYtfET5l92dLGjyZSPe(u"ࠧ࡝ࡴࠪผ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨ࡞࡟ࡶࠬฝ")).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࡟ࡲࠬพ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡠࡡࡴࠧฟ"))
	hgQ0j5peEy9I8f,Ll91GJzBph3VUFnq0wmDSxXProeHZt = [],[]
	import ast as yv0LHDVcqrdaow1Sf3
	try: hgQ0j5peEy9I8f = yv0LHDVcqrdaow1Sf3.literal_eval(X9naxNqy0ICz3cG5up4ZmQi2OSlTU)
	except:
		try:
			X9naxNqy0ICz3cG5up4ZmQi2OSlTU = XakdNYy7EbqiSr5ZKBeF8HCDtAQL(X9naxNqy0ICz3cG5up4ZmQi2OSlTU)
			hgQ0j5peEy9I8f = yv0LHDVcqrdaow1Sf3.literal_eval(X9naxNqy0ICz3cG5up4ZmQi2OSlTU)
		except:
			items = X2XorVqHjLkWeCchY4u9fSz.findall(wPnfgxKZdAv6T10(u"ࡶࠬࡢ࡛࡜ࡠ࡟ࡡࡢ࠰࡜࡞ࡾ࡟ࡿࡠࡤࡽ࡞ࠬ࡟ࢁࢁࡢࠨ࡜ࡠࠬࡡ࠯ࡢࠩࡽ࡝ࡡ࠰ࡡࡡ࡜࡞࡟࠮ࠫภ"),X9naxNqy0ICz3cG5up4ZmQi2OSlTU.strip(ALwOspNtXxZrz3PEKku(u"ࠬࡡ࡝ࠨม")))
			if items:
				for JJSOAkTZIib4eswDo51pFuqvK in items:
					try: hgQ0j5peEy9I8f.append(yv0LHDVcqrdaow1Sf3.literal_eval(JJSOAkTZIib4eswDo51pFuqvK))
					except: Ll91GJzBph3VUFnq0wmDSxXProeHZt.append(JJSOAkTZIib4eswDo51pFuqvK)
			else: hgQ0j5peEy9I8f = wiPWy3I4UZ(zQPURo9E0JK)
	return hgQ0j5peEy9I8f
def u0utoq8TOyQU():
	kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
	yyfSKmso8APbUwvq3HLXgz0D = X2XorVqHjLkWeCchY4u9fSz.findall(ASkvf27etUK0(u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭ย"),r7h8wgIzXZkaDTVqB5tOS3n,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if yyfSKmso8APbUwvq3HLXgz0D: r7h8wgIzXZkaDTVqB5tOS3n = r7h8wgIzXZkaDTVqB5tOS3n.split(yyfSKmso8APbUwvq3HLXgz0D[wvkDqmNZlJU52isXo],nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
	U7yr2NnMsiFV3jchOXDHQ = uv8V4fE7j9pmgFr3wnDL.strftime(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧร"),uv8V4fE7j9pmgFr3wnDL.localtime(H3a6hvAgeNctTiXF8d1uELfPr4y))
	r7h8wgIzXZkaDTVqB5tOS3n = r7h8wgIzXZkaDTVqB5tOS3n+U7yr2NnMsiFV3jchOXDHQ
	j18fCtiQLUPRKD0vOzYVe = kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(dUj4HNoGp91APu6itnl3BCc):
		zOWDhrxp8XRV5jFuT1 = open(dUj4HNoGp91APu6itnl3BCc,ASkvf27etUK0(u"ࠨࡴࡥࠫฤ")).read()
		if QBOMjKifEAFD: zOWDhrxp8XRV5jFuT1 = zOWDhrxp8XRV5jFuT1.decode(Tv08xsf9HOqunIVUPdK1)
		zOWDhrxp8XRV5jFuT1 = xjVJ0o7mF86tCDagkbNcrTAR4UH(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡧ࡭ࡨࡺࠧล"),zOWDhrxp8XRV5jFuT1)
	else: zOWDhrxp8XRV5jFuT1 = {}
	WCdaRXT1Kty2vmHOkNgbo7zcMp = {}
	for ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U in list(zOWDhrxp8XRV5jFuT1.keys()):
		if ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U!=kpiJl1MHXD5: WCdaRXT1Kty2vmHOkNgbo7zcMp[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U] = zOWDhrxp8XRV5jFuT1[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U]
		else:
			if r7h8wgIzXZkaDTVqB5tOS3n and r7h8wgIzXZkaDTVqB5tOS3n!=iDhLkZS6XBagNCQfs9tq2(u"ࠪ࠲࠳࠭ฦ"):
				nB3XmeVYPNR9tCxy4rj1GvqsHMISFl = zOWDhrxp8XRV5jFuT1[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U]
				if j18fCtiQLUPRKD0vOzYVe in nB3XmeVYPNR9tCxy4rj1GvqsHMISFl:
					ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp = nB3XmeVYPNR9tCxy4rj1GvqsHMISFl.index(j18fCtiQLUPRKD0vOzYVe)
					del nB3XmeVYPNR9tCxy4rj1GvqsHMISFl[ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp]
				NNR4sgnwr2H = [j18fCtiQLUPRKD0vOzYVe]+nB3XmeVYPNR9tCxy4rj1GvqsHMISFl
				NNR4sgnwr2H = NNR4sgnwr2H[:TVnqDYzWoM2UfHp0dchJ(u"࠶࠲༧")]
				WCdaRXT1Kty2vmHOkNgbo7zcMp[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U] = NNR4sgnwr2H
			else: WCdaRXT1Kty2vmHOkNgbo7zcMp[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U] = zOWDhrxp8XRV5jFuT1[ff8Y2zNtH4xKJSd6ZC7goqXE3bl10U]
	if kpiJl1MHXD5 not in list(WCdaRXT1Kty2vmHOkNgbo7zcMp.keys()): WCdaRXT1Kty2vmHOkNgbo7zcMp[kpiJl1MHXD5] = [j18fCtiQLUPRKD0vOzYVe]
	WCdaRXT1Kty2vmHOkNgbo7zcMp = str(WCdaRXT1Kty2vmHOkNgbo7zcMp)
	if QBOMjKifEAFD: WCdaRXT1Kty2vmHOkNgbo7zcMp = WCdaRXT1Kty2vmHOkNgbo7zcMp.encode(Tv08xsf9HOqunIVUPdK1)
	open(dUj4HNoGp91APu6itnl3BCc,gCkRKGhwcx26v(u"ࠫࡼࡨࠧว")).write(WCdaRXT1Kty2vmHOkNgbo7zcMp)
	return
def zzM3SJI56FnHqsRGAXe(qqTB9mr0Av7jKg3UOYzLl):
	if QBOMjKifEAFD: import urllib.parse as dR0UMx5Dm9qzeLNoj7pfKk
	else: import urllib as dR0UMx5Dm9qzeLNoj7pfKk
	qXW0D7sU3BrFfS = dR0UMx5Dm9qzeLNoj7pfKk.urlencode(qqTB9mr0Av7jKg3UOYzLl)
	return qXW0D7sU3BrFfS
def nxW9asAySzOt2foFGT4LwmHNl8uZ(iGxH2fsuScPtkJb7ECg,mm2TpqnjEk0DCOfrvQPd=SebHIf2jL1TBgrMKJu,Ih0wKBLCeSNGPvg7tc6A=SebHIf2jL1TBgrMKJu):
	CfLloBu613GmV0qyv = mm2TpqnjEk0DCOfrvQPd not in [Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡓ࠳ࡖࠩศ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡉࡑࡖ࡙ࠫษ")]
	if not Ih0wKBLCeSNGPvg7tc6A: Ih0wKBLCeSNGPvg7tc6A = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡷ࡫ࡧࡩࡴ࠭ส")
	Lxa0ukOn2Kh43YvA,T1Th0xNXAnMD2m7pL4Ye6sjSciJHf,wsMrNm7dQi = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪห"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	if len(iGxH2fsuScPtkJb7ECg)==fuCbjVag7vU908J2Yqx5Th:
		pfhH2objgVkI7eycn,A54Kg3z01X,wsMrNm7dQi = iGxH2fsuScPtkJb7ECg
		if A54Kg3z01X: T1Th0xNXAnMD2m7pL4Ye6sjSciJHf = ASkvf27etUK0(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫฬ")+A54Kg3z01X+HCiWF4jV1Q8(u"ࠪࠤࡢ࠭อ")
	else: pfhH2objgVkI7eycn,A54Kg3z01X,wsMrNm7dQi = iGxH2fsuScPtkJb7ECg,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠪ࠸࠰ࠨฮ"),qE4nB3mKWHs)
	stQZoj85K3HPTUq2pCDAbaGSXLJw = j1HGJPrFA3tTfLxayDCgIpE7Q(pfhH2objgVkI7eycn)
	if mm2TpqnjEk0DCOfrvQPd not in [t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧฯ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡉࡑࡖ࡙ࠫะ")]:
		if mm2TpqnjEk0DCOfrvQPd!=v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩั"): pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.replace(qE4nB3mKWHs,C3w6qluao7EzUxJgMGBtV(u"ࠨࠧ࠵࠴ࠬา"))
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨำ")+pfhH2objgVkI7eycn+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࠤࡢ࠭ิ")+T1Th0xNXAnMD2m7pL4Ye6sjSciJHf)
		if stQZoj85K3HPTUq2pCDAbaGSXLJw==uqLUBHepfM3l6AyIzTJh80a(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪี") and mm2TpqnjEk0DCOfrvQPd not in [TVnqDYzWoM2UfHp0dchJ(u"ࠬࡏࡐࡕࡘࠪึ"),vMhFypGLHZJbdX4O7oc3W8x(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧื")]:
			import RSdDifzoPG,xQGdJvfp3S
			HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = RSdDifzoPG.YBCFjeH81s4Gxlgki(mm2TpqnjEk0DCOfrvQPd,pfhH2objgVkI7eycn)
			C4257GIxAk = len(bQGVWFxKS4D6p9YC7XPyA8Os)
			if C4257GIxAk>nyUIsfd53EGot9vbj0XDeq:
				QQea1XbjZDEMhp = xQGdJvfp3S.KKxHoL6iq4dst79zCUP215lYgMOreG(DQIrVcKuY6bJv(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨุ")+str(C4257GIxAk)+wPnfgxKZdAv6T10(u"ࠨ่่ࠢๆ࠯ูࠧ"), HFThJNteGZsSR5CD7rimbjPq)
				if QQea1XbjZDEMhp==-nyUIsfd53EGot9vbj0XDeq:
					xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(bcNqYtfET5l92dLGjyZSPe(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ฺࠧ"),wPnfgxKZdAv6T10(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪ฻"))
					return Lxa0ukOn2Kh43YvA
			else: QQea1XbjZDEMhp = wvkDqmNZlJU52isXo
			pfhH2objgVkI7eycn = bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
			if HFThJNteGZsSR5CD7rimbjPq[wvkDqmNZlJU52isXo]!=gCkRKGhwcx26v(u"ࠫ࠲࠷ࠧ฼"):
				z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ฽")+HFThJNteGZsSR5CD7rimbjPq[QQea1XbjZDEMhp]+C3w6qluao7EzUxJgMGBtV(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ฾")+pfhH2objgVkI7eycn+bcNqYtfET5l92dLGjyZSPe(u"ࠧࠡ࡟ࠪ฿"))
		if bcNqYtfET5l92dLGjyZSPe(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩเ") in pfhH2objgVkI7eycn: pfhH2objgVkI7eycn = pfhH2objgVkI7eycn+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩแ")
		elif DQIrVcKuY6bJv(u"ࠪ࡬ࡹࡺࡰࠨโ") in pfhH2objgVkI7eycn.lower() and v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫใ") not in pfhH2objgVkI7eycn and DQIrVcKuY6bJv(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪไ") not in pfhH2objgVkI7eycn:
			pfhH2objgVkI7eycn = pfhH2objgVkI7eycn+VOALf8iYEnMdK0g(u"࠭ࡼࠨๅ") if DQIrVcKuY6bJv(u"ࠧࡽࠩๆ") not in pfhH2objgVkI7eycn else pfhH2objgVkI7eycn+C3w6qluao7EzUxJgMGBtV(u"ࠨࠨࠪ็")
			if C3w6qluao7EzUxJgMGBtV(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃ่ࠧ") not in pfhH2objgVkI7eycn and NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳้ࠬ") in pfhH2objgVkI7eycn.lower(): pfhH2objgVkI7eycn += l7kBpMw5Qn(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠦࠨ๊")
			if qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿๋ࠪ") not in pfhH2objgVkI7eycn.lower() and mm2TpqnjEk0DCOfrvQPd not in [Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡉࡑࡖ࡙ࠫ์"),wPnfgxKZdAv6T10(u"ࠧࡎ࠵ࡘࠫํ")]: pfhH2objgVkI7eycn += qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ๎")
			if uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫ๏") not in pfhH2objgVkI7eycn.lower(): pfhH2objgVkI7eycn += Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪ๐")
			if C3w6qluao7EzUxJgMGBtV(u"ࠫࡦࡩࡣࡦࡲࡷ࠱ࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡃࠧ๑") not in pfhH2objgVkI7eycn.lower(): pfhH2objgVkI7eycn += wPnfgxKZdAv6T10(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫࠽ࡦࡰ࠯ࡥࡷࡁࡱ࠾࠲࠱࠽ࠫ࠭๒")
	z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+gCkRKGhwcx26v(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ๓")+pfhH2objgVkI7eycn+TVnqDYzWoM2UfHp0dchJ(u"ࠧࠡ࡟ࠪ๔"))
	vwlhc9QSiILKHuBZAR7TYr2pkbJDys = G5OVsSktWRJQu8h4T.ListItem()
	Ih0wKBLCeSNGPvg7tc6A,ccAodmkDjX1RpSOt4v9l7,yxmwHSQDJg4b,JkU3CPaXYE0fhRAq1rTLGcd4y72jz,Ozx5aq04MlbHkAESeCRcT21vWXPuJ,h4KqERCZpW6aPLmUyw9BSOjtFndl,sx6BvORYmAQp3L9Kbof8,IQig08Vy3HboGunElR,h7HJPDRI2Qdi1lKFVGAYe608ZE4zt = wrLGxbJiM4NzluAvI7KPojmYteD(EWTFwqJoXHGSjsRfhOI5YLM)
	if mm2TpqnjEk0DCOfrvQPd not in [cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ๕"),zpx2fPNKk6Ms38eD1vcO(u"ࠩࡌࡔ࡙࡜ࠧ๖")]:
		if psS8dmb912iRBgGc7qOPyCZ6: wLmNlQ5RcWrH4i76pOCnayDI = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭๗")
		else: wLmNlQ5RcWrH4i76pOCnayDI = HCiWF4jV1Q8(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ๘")
		vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setProperty(wLmNlQ5RcWrH4i76pOCnayDI, SebHIf2jL1TBgrMKJu)
		vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setMimeType(HADrRCz9QgU4xudPJIqYb70(u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪ๙"))
		if zzGetSI9yqnbZh<AGlW9LqKN3Dvo(u"࠴࠳༨"): vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setInfo(wPnfgxKZdAv6T10(u"࠭ࡶࡪࡦࡨࡳࠬ๚"),{Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ๛"):j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࡯ࡲࡺ࡮࡫ࠧ๜")})
		else:
			jmV23CqcvkQROo = vwlhc9QSiILKHuBZAR7TYr2pkbJDys.getVideoInfoTag()
			jmV23CqcvkQROo.setMediaType(gCkRKGhwcx26v(u"ࠩࡰࡳࡻ࡯ࡥࠨ๝"))
		vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setArt({ALwOspNtXxZrz3PEKku(u"ࠪࡸ࡭ࡻ࡭ࡣࠩ๞"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡵࡵࡳࡵࡧࡵࠫ๟"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ๠"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,DQIrVcKuY6bJv(u"࠭ࡦࡢࡰࡤࡶࡹ࠭๡"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ๢"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,TVnqDYzWoM2UfHp0dchJ(u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ๣"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ๤"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ,vMhFypGLHZJbdX4O7oc3W8x(u"ࠪ࡭ࡨࡵ࡮ࠨ๥"):Ozx5aq04MlbHkAESeCRcT21vWXPuJ})
		if stQZoj85K3HPTUq2pCDAbaGSXLJw in [t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࠳ࡳࡰࡥࠩ๦"),bcNqYtfET5l92dLGjyZSPe(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ๧")]:
			vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setContentLookup(BBX9RAuxnyGZ4WIF2TrhYeom3)
			pfhH2objgVkI7eycn = pfhH2objgVkI7eycn+qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡼࠨ๨") if AGlW9LqKN3Dvo(u"ࠧࡽࠩ๩") not in pfhH2objgVkI7eycn else pfhH2objgVkI7eycn.strip(TVnqDYzWoM2UfHp0dchJ(u"ࠨࠨࠪ๪"))+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࠩࠫ๫")
			pfhH2objgVkI7eycn += ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡖࡦࡴࡧࡦ࠿ࠩࠫ๬")
		else: vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setContentLookup(mrhSYXH2P8bO3eJAa9n)
		from WW03V9yQKJ import j3jFtGCKvzmOBwaX2ibogEx4JRqQD
		if gCkRKGhwcx26v(u"ࠫࡷࡺ࡭ࡱࠩ๭") in pfhH2objgVkI7eycn:
			j3jFtGCKvzmOBwaX2ibogEx4JRqQD(ASkvf27etUK0(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ๮"),mrhSYXH2P8bO3eJAa9n)
		elif stQZoj85K3HPTUq2pCDAbaGSXLJw==HADrRCz9QgU4xudPJIqYb70(u"࠭࠮࡮ࡲࡧࠫ๯") or wPnfgxKZdAv6T10(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ๰") in pfhH2objgVkI7eycn:
			j3jFtGCKvzmOBwaX2ibogEx4JRqQD(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๱"),mrhSYXH2P8bO3eJAa9n)
			vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setProperty(wLmNlQ5RcWrH4i76pOCnayDI,sTGtHVyhQ9cJU37zxo2O(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๲"))
			vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setProperty(HCiWF4jV1Q8(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ๳"),gCkRKGhwcx26v(u"ࠫࡲࡶࡤࠨ๴"))
		if A54Kg3z01X:
			vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setSubtitles([A54Kg3z01X])
	if Ih0wKBLCeSNGPvg7tc6A==HADrRCz9QgU4xudPJIqYb70(u"ࠬࡼࡩࡥࡧࡲࠫ๵") and mm2TpqnjEk0DCOfrvQPd==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ๶"):
		Lxa0ukOn2Kh43YvA = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ๷")
		mm2TpqnjEk0DCOfrvQPd = ALwOspNtXxZrz3PEKku(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ๸")
	elif Ih0wKBLCeSNGPvg7tc6A==ALwOspNtXxZrz3PEKku(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๹") and IQig08Vy3HboGunElR.startswith(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪ࠺ࠬ๺")):
		Lxa0ukOn2Kh43YvA = ASkvf27etUK0(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ๻")
		mm2TpqnjEk0DCOfrvQPd = mm2TpqnjEk0DCOfrvQPd+HCiWF4jV1Q8(u"ࠬࡥࡄࡍࠩ๼")
	if Lxa0ukOn2Kh43YvA!=t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫ๽"): u0utoq8TOyQU()
	gTxb4eGlNOM8Ams0n7ZUjEFq.ULDCkHiJr1Pa6YeyNp(mm2TpqnjEk0DCOfrvQPd)
	if gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj: return TVnqDYzWoM2UfHp0dchJ(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ๾")
	if Ih0wKBLCeSNGPvg7tc6A==gCkRKGhwcx26v(u"ࠨࡸ࡬ࡨࡪࡵࠧ๿") and not IQig08Vy3HboGunElR.startswith(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࠹ࠫ຀")):
		vwlhc9QSiILKHuBZAR7TYr2pkbJDys.setPath(pfhH2objgVkI7eycn)
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪກ")+pfhH2objgVkI7eycn+wPnfgxKZdAv6T10(u"ࠫࠥࡣࠧຂ"))
		mKerP0GFQHJbM1hzR5ntxUVpdqTk.setResolvedUrl(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,BBX9RAuxnyGZ4WIF2TrhYeom3,vwlhc9QSiILKHuBZAR7TYr2pkbJDys)
	elif Ih0wKBLCeSNGPvg7tc6A==zpx2fPNKk6Ms38eD1vcO(u"ࠬࡲࡩࡷࡧࠪ຃"):
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+iDhLkZS6XBagNCQfs9tq2(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩຄ")+pfhH2objgVkI7eycn+wPnfgxKZdAv6T10(u"ࠧࠡ࡟ࠪ຅"))
		gTxb4eGlNOM8Ams0n7ZUjEFq.play(pfhH2objgVkI7eycn,vwlhc9QSiILKHuBZAR7TYr2pkbJDys)
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	if Lxa0ukOn2Kh43YvA==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ຆ"):
		from skVjdKL9Zv import MybkE8Hu0PUnXVafFWYmiAr
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = MybkE8Hu0PUnXVafFWYmiAr(pfhH2objgVkI7eycn,stQZoj85K3HPTUq2pCDAbaGSXLJw,mm2TpqnjEk0DCOfrvQPd)
		if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: u0utoq8TOyQU()
	else:
		EXNR98wTJuhj,Lxa0ukOn2Kh43YvA,rkLGPMmE3TDjzdZnC8ucQ0Ji,kSedjoBVAgpqwJE5hbZxFa1IGi,Eq69nua05F = wvkDqmNZlJU52isXo,bcNqYtfET5l92dLGjyZSPe(u"ࠩࡷࡶ࡮࡫ࡤࠨງ"),mrhSYXH2P8bO3eJAa9n,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠵࠵࠶࠰༪"),czvu7VQCZodkMf(u"࠷࠹࠵࠶࠰༩")
		if CfLloBu613GmV0qyv: import xQGdJvfp3S
		while EXNR98wTJuhj<Eq69nua05F:
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.sleep(kSedjoBVAgpqwJE5hbZxFa1IGi)
			EXNR98wTJuhj += kSedjoBVAgpqwJE5hbZxFa1IGi
			if gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫຈ") and not rkLGPMmE3TDjzdZnC8ucQ0Ji:
				if CfLloBu613GmV0qyv: xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(VOALf8iYEnMdK0g(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨຉ"),bcNqYtfET5l92dLGjyZSPe(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ຊ"),uv8V4fE7j9pmgFr3wnDL=HADrRCz9QgU4xudPJIqYb70(u"࠼࠻࠰༫"))
				z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+l7kBpMw5Qn(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ຋")+pfhH2objgVkI7eycn+fp6KV7DlS8QYniUczHdmZChL(u"ࠧࠡ࡟ࠪຌ")+T1Th0xNXAnMD2m7pL4Ye6sjSciJHf)
				rkLGPMmE3TDjzdZnC8ucQ0Ji = BBX9RAuxnyGZ4WIF2TrhYeom3
			elif gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj in [ALwOspNtXxZrz3PEKku(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩຍ"),VOALf8iYEnMdK0g(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪຎ")]:
				z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+HADrRCz9QgU4xudPJIqYb70(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧຏ")+pfhH2objgVkI7eycn+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࠥࡣࠧຐ")+T1Th0xNXAnMD2m7pL4Ye6sjSciJHf)
				break
			elif gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj==AGlW9LqKN3Dvo(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬຑ"):
				z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+C3w6qluao7EzUxJgMGBtV(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧຒ")+pfhH2objgVkI7eycn+C3w6qluao7EzUxJgMGBtV(u"ࠧࠡ࡟ࠪຓ")+T1Th0xNXAnMD2m7pL4Ye6sjSciJHf)
				if CfLloBu613GmV0qyv: xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬດ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪຕ"),uv8V4fE7j9pmgFr3wnDL=Gykx0wL3XrlWaujsqKP9n2Q(u"࠽࠵࠱༬"))
				break
			elif gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj==zpx2fPNKk6Ms38eD1vcO(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫຖ"):
				z82vTVp1xik0HBSenuENU5fRAD3(AAThlKoOtk0dz1sBZpPRbiV2vIe,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩທ")+pfhH2objgVkI7eycn+l7kBpMw5Qn(u"ࠬࠦ࡝ࠨຘ"))
				break
		else: Lxa0ukOn2Kh43YvA = vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧນ")
	if Lxa0ukOn2Kh43YvA in [Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧບ")] or gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj in [Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩປ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪຜ")] or Vsn3f1CA8FIu0krNclSDWP5v9YQaE: zzcbV5F4iSjM2(mm2TpqnjEk0DCOfrvQPd)
	else: exec(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡼࡧࡳࡣ࠼ࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨຝ"))
	FFDWySVhCkJ8j = if5dy2h0nsDVlukoQ7NUFqx4cGEW.Player().isPlaying()
	if not FFDWySVhCkJ8j and Lxa0ukOn2Kh43YvA not in [C3w6qluao7EzUxJgMGBtV(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩພ")]:
		msg = fp6KV7DlS8QYniUczHdmZChL(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ຟ") if Lxa0ukOn2Kh43YvA==Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧຠ") else qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨມ")
		if CfLloBu613GmV0qyv: xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(AGlW9LqKN3Dvo(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬຢ"),msg,uv8V4fE7j9pmgFr3wnDL=tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠷࠶࠲༭"))
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+bcNqYtfET5l92dLGjyZSPe(u"ࠩࠣࠤࠥ࠭ຣ")+msg+Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭຤")+pfhH2objgVkI7eycn+l7kBpMw5Qn(u"ࠫࠥࡣࠧລ")+T1Th0xNXAnMD2m7pL4Ye6sjSciJHf)
	return gTxb4eGlNOM8Ams0n7ZUjEFq.CSf51aVe2YWHTUQAv87odsRmhtj
def j1HGJPrFA3tTfLxayDCgIpE7Q(pfhH2objgVkI7eycn):
	if bcNqYtfET5l92dLGjyZSPe(u"ࠬࡅࠧ຦") in pfhH2objgVkI7eycn: pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.split(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭࠿ࠨວ"))[wvkDqmNZlJU52isXo]
	if bcNqYtfET5l92dLGjyZSPe(u"ࠧࡽࠩຨ") in pfhH2objgVkI7eycn: pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.split(fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡾࠪຩ"))[wvkDqmNZlJU52isXo]
	path = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࠲ࠫສ").join(pfhH2objgVkI7eycn.split(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࠳ࠬຫ"))[sTGtHVyhQ9cJU37zxo2O(u"࠴༮"):]) if ALwOspNtXxZrz3PEKku(u"ࠫ࠿࠵࠯ࠨຬ") in pfhH2objgVkI7eycn else pfhH2objgVkI7eycn
	JbsjfDwqU1Y = X2XorVqHjLkWeCchY4u9fSz.findall(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡢ࠮ࠩ࡝ࡤ࠱ࡿ࠶࠭࠺࡟ࡾ࠶࠱࠺ࡽࠪࠩອ"),path,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if JbsjfDwqU1Y:
		JbsjfDwqU1Y = JbsjfDwqU1Y[-nyUIsfd53EGot9vbj0XDeq]
		ueEYyKaRqh2nZLs1ol0NJQDmbIGOW = [wPnfgxKZdAv6T10(u"࠭࡭࠴ࡷ࠻ࠫຮ"),bcNqYtfET5l92dLGjyZSPe(u"ࠧ࡮ࡲ࠷ࠫຯ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨ࡯ࡳࡨࠬະ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡺࡩࡧࡳࠧັ"),DQIrVcKuY6bJv(u"ࠪࡥࡻ࡯ࠧາ"),C3w6qluao7EzUxJgMGBtV(u"ࠫࡦࡧࡣࠨຳ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࡳ࠳ࡶࠩິ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭࡭࡬ࡸࠪີ"),ALwOspNtXxZrz3PEKku(u"ࠧࡧ࡮ࡹࠫຶ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨ࡯ࡳ࠷ࠬື"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡷࡷຸࠬ")]
		if JbsjfDwqU1Y in ueEYyKaRqh2nZLs1ol0NJQDmbIGOW: return DQIrVcKuY6bJv(u"ࠪ࠲ູࠬ")+JbsjfDwqU1Y
	return SebHIf2jL1TBgrMKJu
def zzcbV5F4iSjM2(DDj8NqZIHVmeMUTk):
	if not qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h: DDj8NqZIHVmeMUTk += AGlW9LqKN3Dvo(u"ࠫࡤ࡚ࡓࠨ຺")
	qFsuKN7ngp.SEND_THESE_EVENTS.append(DDj8NqZIHVmeMUTk)
	return
def LbTfk6oJPiSGpVMU(GpilnwYMeUq4xu6SFA=mrhSYXH2P8bO3eJAa9n):
	O4ObE1qjpmvBIZn5dPT67Xfzc9A = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(uqLUBHepfM3l6AyIzTJh80a(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬົ"))
	KhcZt43LXbAro(GpilnwYMeUq4xu6SFA,C3w6qluao7EzUxJgMGBtV(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩຼ"))
	yMqHPpxSEAFIwKecXdi40r8zL53.exit()
def KhcZt43LXbAro(GpilnwYMeUq4xu6SFA,yamjrsOAG4iFfQkuW1JXbZ0Dgq7z):
	if yamjrsOAG4iFfQkuW1JXbZ0Dgq7z:
		if gCkRKGhwcx26v(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪຽ") in yamjrsOAG4iFfQkuW1JXbZ0Dgq7z: z82vTVp1xik0HBSenuENU5fRAD3(SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫ຾"))
		else:
			rr1vBYypiKkhH7UcL4qfJRNnXm5Q = MMAUZiw4CoJ8.getSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ຿"))
			MMAUZiw4CoJ8.setSetting(czvu7VQCZodkMf(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫເ"),SebHIf2jL1TBgrMKJu)
			import RSdDifzoPG
			RSdDifzoPG.OZINRkynbpYDKiTqHVoces9XEMCxtP(yamjrsOAG4iFfQkuW1JXbZ0Dgq7z)
			MMAUZiw4CoJ8.setSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬແ"),rr1vBYypiKkhH7UcL4qfJRNnXm5Q)
	UmEZCgu87JB = MMAUZiw4CoJ8.getSetting(l7kBpMw5Qn(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩໂ"))
	if UmEZCgu87JB==HADrRCz9QgU4xudPJIqYb70(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧໃ"): MMAUZiw4CoJ8.setSetting(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫໄ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ໅"))
	elif UmEZCgu87JB==zpx2fPNKk6Ms38eD1vcO(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩໆ"): MMAUZiw4CoJ8.setSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ໇"),SebHIf2jL1TBgrMKJu)
	if MMAUZiw4CoJ8.getSetting(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹ່ࠧ")) not in [C3w6qluao7EzUxJgMGBtV(u"ࠬࡇࡕࡕࡑ້ࠪ"),TVnqDYzWoM2UfHp0dchJ(u"࠭ࡓࡕࡑࡓ໊ࠫ"),HADrRCz9QgU4xudPJIqYb70(u"ࠧࡂࡕࡎ໋ࠫ")]: MMAUZiw4CoJ8.setSetting(C3w6qluao7EzUxJgMGBtV(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ໌"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡄࡗࡐ࠭ໍ"))
	if MMAUZiw4CoJ8.getSetting(bcNqYtfET5l92dLGjyZSPe(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ໎")) not in [HADrRCz9QgU4xudPJIqYb70(u"ࠫࡆ࡛ࡔࡐࠩ໏"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࡙ࠬࡔࡐࡒࠪ໐"),VOALf8iYEnMdK0g(u"࠭ࡁࡔࡍࠪ໑")]: MMAUZiw4CoJ8.setSetting(C3w6qluao7EzUxJgMGBtV(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ໒"),zpx2fPNKk6Ms38eD1vcO(u"ࠨࡃࡖࡏࠬ໓"))
	eqmvUIDz5M = MMAUZiw4CoJ8.getSetting(C3w6qluao7EzUxJgMGBtV(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ໔"))
	xbpe62PFARlCEfW = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭໕"))
	if vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ໖") in str(xbpe62PFARlCEfW) and eqmvUIDz5M in [j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ໗"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ໘")]:
		uv8V4fE7j9pmgFr3wnDL.sleep(czvu7VQCZodkMf(u"࠲࠱࠵࠵࠶༯"))
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(HCiWF4jV1Q8(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡗࡪࡺࡖࡪࡧࡺࡑࡴࡪࡥࠩ࠲ࠬࠫ໙"))
	if wvkDqmNZlJU52isXo and BrOCluwtd1veo0a7EMbqVFXZgjQRL2>-nyUIsfd53EGot9vbj0XDeq:
		mKerP0GFQHJbM1hzR5ntxUVpdqTk.setResolvedUrl(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,mrhSYXH2P8bO3eJAa9n,G5OVsSktWRJQu8h4T.ListItem())
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc = mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n
		mKerP0GFQHJbM1hzR5ntxUVpdqTk.endOfDirectory(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc)
	if qFsuKN7ngp.SEND_THESE_EVENTS: FdjHEQn68kzOB9UZ3WoRfLr(qFsuKN7ngp.SEND_THESE_EVENTS)
	Z1adiVz3wQkbEXI9MYqmFnJ = LL1ZoBAmMuEwq()
	InkX1ZEcl3yBf(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡵࡷࡳࡵ࠭໚"),mrhSYXH2P8bO3eJAa9n)
	if Z1adiVz3wQkbEXI9MYqmFnJ and not qFsuKN7ngp.resolveonly:
		qFsuKN7ngp.resolveonly = BBX9RAuxnyGZ4WIF2TrhYeom3
		FFDWySVhCkJ8j = if5dy2h0nsDVlukoQ7NUFqx4cGEW.Player().isPlaying()
		if not FFDWySVhCkJ8j: O4ObE1qjpmvBIZn5dPT67Xfzc9A = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩ໛"))
		else:
			J0fpQvX2EKYTm9oy1OxL3BsPA = WR07Lq5QodIA()
			if J0fpQvX2EKYTm9oy1OxL3BsPA:
				import RSdDifzoPG,xQGdJvfp3S
				for WTxpgC1F98bcI5Am in range(wvkDqmNZlJU52isXo,dcENpSQ7KJrTbVDuL,fuCbjVag7vU908J2Yqx5Th):
					uv8V4fE7j9pmgFr3wnDL.sleep(fuCbjVag7vU908J2Yqx5Th)
					FFDWySVhCkJ8j = if5dy2h0nsDVlukoQ7NUFqx4cGEW.Player().isPlaying()
					if not FFDWySVhCkJ8j:
						xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫໜ"),DQIrVcKuY6bJv(u"ࠫสฺ๊ศรࠣๅา฻ࠠศๆึ๎ึ็ัศฬࠪໝ"),uv8V4fE7j9pmgFr3wnDL=sTGtHVyhQ9cJU37zxo2O(u"࠸࠴࠵༰"))
						break
				else:
					kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = wrLGxbJiM4NzluAvI7KPojmYteD(J0fpQvX2EKYTm9oy1OxL3BsPA)
					if not any(value in r7h8wgIzXZkaDTVqB5tOS3n for value in RSdDifzoPG.NOT_TO_TEST_ALL_SERVERS):
						xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬอไโ์า๎ํࠦวๅๆสั็࠭ໞ"),wPnfgxKZdAv6T10(u"࠭แฮืࠣะ๊๐ูࠡษ็ื๏ืแาษอࠫໟ"),uv8V4fE7j9pmgFr3wnDL=vMhFypGLHZJbdX4O7oc3W8x(u"࠻࠺࠶༱"))
						uv8V4fE7j9pmgFr3wnDL.sleep(JhTts2R43AxkM8bYanKVy)
						if psS8dmb912iRBgGc7qOPyCZ6:
							pfhH2objgVkI7eycn = pfhH2objgVkI7eycn.encode(Tv08xsf9HOqunIVUPdK1)
						RSdDifzoPG.ko5ymgwaUtVilrPc3jpWhKJ(QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF,QxUz8vH0AsPG3OgF)
						lfZmugQCFKLGT05AH29IsMiho = RSdDifzoPG.GkAg0ZqR2cnPW9wvUtfj(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
						RSdDifzoPG.ko5ymgwaUtVilrPc3jpWhKJ(cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db,cXPe6vn1aUtFzH79WEwVmCBO0db)
						xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(C3w6qluao7EzUxJgMGBtV(u"ࠧศๆไ๎ิ๐่ࠡษ็่ฬำโࠨ໠"),bcNqYtfET5l92dLGjyZSPe(u"ࠨษ้ฮ์๏ࠠโฯุࠤฬ๊ำ๋ำไีฬะࠧ໡"),uv8V4fE7j9pmgFr3wnDL=xxRyYsrSCzjifvH4cIqgldeOo(u"࠼࠻࠰༲"))
						GpilnwYMeUq4xu6SFA = mrhSYXH2P8bO3eJAa9n
	qrvUApFodEiBV = MMAUZiw4CoJ8.getSetting(wPnfgxKZdAv6T10(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭໢"))
	if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ࠱ࠬ໣") in qrvUApFodEiBV:
		qrvUApFodEiBV = qrvUApFodEiBV.replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫ࠲࠭໤"),SebHIf2jL1TBgrMKJu)
		MMAUZiw4CoJ8.setSetting(ASkvf27etUK0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ໥"),qrvUApFodEiBV)
	if GpilnwYMeUq4xu6SFA: if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(HADrRCz9QgU4xudPJIqYb70(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ໦"))
	return
def WR07Lq5QodIA():
	rlF8tCzhWPYJDkE = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(VOALf8iYEnMdK0g(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡉࡨࡸࡎࡺࡥ࡮ࡵࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ࠺࡜ࠤࡷ࡭ࡹࡲࡥࠣ࠮ࠥࡪ࡮ࡲࡥࠣ࠮ࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࡝ࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪ໧"))
	lfZmugQCFKLGT05AH29IsMiho = ddWZPUnz9Cljm.loads(rlF8tCzhWPYJDkE)[HADrRCz9QgU4xudPJIqYb70(u"ࠨࡴࡨࡷࡺࡲࡴࠨ໨")]
	J0fpQvX2EKYTm9oy1OxL3BsPA = SebHIf2jL1TBgrMKJu
	try: items = lfZmugQCFKLGT05AH29IsMiho[VOALf8iYEnMdK0g(u"ࠩ࡬ࡸࡪࡳࡳࠨ໩")]
	except: return SebHIf2jL1TBgrMKJu
	if items:
		for qqai0c7OSNreCszImF23EhYV1KnXLx,file in enumerate(items):
			path = file[TVnqDYzWoM2UfHp0dchJ(u"ࠪࡪ࡮ࡲࡥࠨ໪")]
			if WYGV2HQo6sfnqSDZEcK9Cu4TP not in path: continue
			path = path.split(WYGV2HQo6sfnqSDZEcK9Cu4TP)[nyUIsfd53EGot9vbj0XDeq][nyUIsfd53EGot9vbj0XDeq:]
			if path==EWTFwqJoXHGSjsRfhOI5YLM: break
		count = lfZmugQCFKLGT05AH29IsMiho[uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡱ࡯࡭ࡪࡶࡶࠫ໫")][Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡺ࡯ࡵࡣ࡯ࠫ໬")]
		if qqai0c7OSNreCszImF23EhYV1KnXLx+nyUIsfd53EGot9vbj0XDeq<count: J0fpQvX2EKYTm9oy1OxL3BsPA = items[qqai0c7OSNreCszImF23EhYV1KnXLx+nyUIsfd53EGot9vbj0XDeq][j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡦࡪ࡮ࡨࠫ໭")]
	return J0fpQvX2EKYTm9oy1OxL3BsPA
def LL1ZoBAmMuEwq():
	O4ObE1qjpmvBIZn5dPT67Xfzc9A = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࡽࡾࠩ໮"))
	LlCrcJivEjzYs9u73M4 = mrhSYXH2P8bO3eJAa9n if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ࡝ࡠࠫ໯") in str(O4ObE1qjpmvBIZn5dPT67Xfzc9A) else BBX9RAuxnyGZ4WIF2TrhYeom3
	return LlCrcJivEjzYs9u73M4
def InkX1ZEcl3yBf(EmtzgUT5y7MfIV,qZzde6h53Qrxv1sNTcul=mrhSYXH2P8bO3eJAa9n):
	if EmtzgUT5y7MfIV==ASkvf27etUK0(u"ࠩࡶࡸࡴࡶࠧ໰") and (qZzde6h53Qrxv1sNTcul or qFsuKN7ngp.busydialog_active):
		if qZzde6h53Qrxv1sNTcul: if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(ALwOspNtXxZrz3PEKku(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ໱"))
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(iDhLkZS6XBagNCQfs9tq2(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠪࠩ໲"))
		qFsuKN7ngp.busydialog_active = mrhSYXH2P8bO3eJAa9n
	if EmtzgUT5y7MfIV==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡹࡴࡢࡴࡷࠫ໳") and (qZzde6h53Qrxv1sNTcul or not qFsuKN7ngp.busydialog_active):
		KnD35XEScrxp1ldRuPHyo = zpx2fPNKk6Ms38eD1vcO(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫ໴") if zzGetSI9yqnbZh>gCkRKGhwcx26v(u"࠷࠷࠯࠻࠼༳") else ASkvf27etUK0(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫ໵")
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(gCkRKGhwcx26v(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪ໶")+KnD35XEScrxp1ldRuPHyo+sTGtHVyhQ9cJU37zxo2O(u"ࠩࠬࠫ໷"))
		qFsuKN7ngp.busydialog_active = BBX9RAuxnyGZ4WIF2TrhYeom3
	return
def yrEnWvjhd5o8GKY1FU42A(*args,**d7Cbs4wfJYvx6tlQWUnaHzcAKmeZ5r):
	daemon = d7Cbs4wfJYvx6tlQWUnaHzcAKmeZ5r.pop(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡨࡦ࡫࡭ࡰࡰࠪ໸"),mrhSYXH2P8bO3eJAa9n)
	DGpUszFj8mJ = ZKuP5G1IzjRHOLa.Thread(*args,**d7Cbs4wfJYvx6tlQWUnaHzcAKmeZ5r)
	DGpUszFj8mJ.daemon = daemon
	return DGpUszFj8mJ
unO2AmyCfZFXzp8H3 = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡱ࡯ࡳࡵࠩ໹"),uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ໺"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫ໻"))
if unO2AmyCfZFXzp8H3:
	sVGM49BtqDdTgc1wNCLv3eWIkxQEO6,hlReJLdPnZKAiwpBa4,qkdtH74QsV53KEweDbnvFSy,orUTaWs6uKGPmMICNkpXJEYH2vD0n = unO2AmyCfZFXzp8H3
	qFsuKN7ngp.AV_CLIENT_IDS = u43PVWjh7t9YwI.join(sVGM49BtqDdTgc1wNCLv3eWIkxQEO6)
if not qFsuKN7ngp.AV_CLIENT_IDS: qFsuKN7ngp.AV_CLIENT_IDS = GN2SztT85ChvfWxJbdoUa()
gTxb4eGlNOM8Ams0n7ZUjEFq = cQz8gGB5DYb0()
qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW,qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h,qFsuKN7ngp.rrhvjIPfCsFXxqwHcQeES8JROG,qFsuKN7ngp.PGAlYK9BwWR,qFsuKN7ngp.avprivsnorestrict,qFsuKN7ngp.avprivslongperiod = YKG71Ft6ZlBHkTIgxEOySX2Qq([Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ໼"),zpx2fPNKk6Ms38eD1vcO(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩ໽"),HADrRCz9QgU4xudPJIqYb70(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ໾"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ໿"),l7kBpMw5Qn(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡰࡲࡄࡗࡇ࡙ࡉ࡝࠭ༀ"),sTGtHVyhQ9cJU37zxo2O(u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ༁")])
hAd4IGxEFmnpwg = qFsuKN7ngp.AV_CLIENT_IDS.splitlines()[wvkDqmNZlJU52isXo][-sTGtHVyhQ9cJU37zxo2O(u"࠲࠵༴"):]