# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'LIVETV'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS['PYTHON'][0]
def WdRmv9kTtLnfZ24(mode,url):
	if   mode==100: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==101: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx('0',True)
	elif mode==102: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx('1',True)
	elif mode==103: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx('2',True)
	elif mode==104: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx('3',True)
	elif mode==105: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==106: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx('4',True)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder','_M3U_'+'قوائم فيديوهات M3U',SebHIf2jL1TBgrMKJu,762)
	QUzFYoapm9jx('folder','_IPT_'+'قوائم فيديوهات IPTV',SebHIf2jL1TBgrMKJu,761)
	QUzFYoapm9jx('folder','_TV0_'+'قنوات من مواقعها الأصلية',SebHIf2jL1TBgrMKJu,101)
	QUzFYoapm9jx('folder','_TV4_'+'قنوات مختارة من يوتيوب',SebHIf2jL1TBgrMKJu,106)
	QUzFYoapm9jx('folder','_YUT_'+'قنوات عربية من يوتيوب',SebHIf2jL1TBgrMKJu,147)
	QUzFYoapm9jx('folder','_YUT_'+'قنوات أجنبية من يوتيوب',SebHIf2jL1TBgrMKJu,148)
	QUzFYoapm9jx('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',SebHIf2jL1TBgrMKJu,28)
	QUzFYoapm9jx('live','_MRF_'+'قناة المعارف من موقعهم',SebHIf2jL1TBgrMKJu,41)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder','_TV1_'+'قنوات تلفزيونية عامة',SebHIf2jL1TBgrMKJu,102)
	QUzFYoapm9jx('folder','_TV2_'+'قنوات تلفزيونية خاصة',SebHIf2jL1TBgrMKJu,103)
	QUzFYoapm9jx('folder','_TV3_'+'قنوات تلفزيونية للفحص',SebHIf2jL1TBgrMKJu,104)
	return
def JJeq4MVI8NtCWkaOiQLTybrzUx(utk5Dor0c4fOpClX9gZI62NK,showDialogs=True):
	FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_TV'+utk5Dor0c4fOpClX9gZI62NK+'_'
	BXupmlPQvMIrweKqkG = {'id':SebHIf2jL1TBgrMKJu,'user':qFsuKN7ngp.AV_CLIENT_IDS,'function':'list','menu':utk5Dor0c4fOpClX9gZI62NK}
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',j1IFsik4ouNePZr,BXupmlPQvMIrweKqkG,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'LIVETV-ITEMS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		for YHnALfql8hprDu in range(len(items)):
			name = items[YHnALfql8hprDu][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[YHnALfql8hprDu] = items[YHnALfql8hprDu][0],items[YHnALfql8hprDu][1],items[YHnALfql8hprDu][2],name,items[YHnALfql8hprDu][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for qh4B9VQZCbXr0DRknFmi7J6,YdzfwOyPb2gxT37B9Dm,byFGvxhKuI9HU7ceAaMr3N4,name,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			if '#' in qh4B9VQZCbXr0DRknFmi7J6: continue
			if qh4B9VQZCbXr0DRknFmi7J6!='URL': name = name+E7r8hUCVvTiFQW0dBGXjxcy+cc07eWdgrbB4xJfVCANFSk+qh4B9VQZCbXr0DRknFmi7J6+XOVRfitWJP1zL3p2CMYF
			url = qh4B9VQZCbXr0DRknFmi7J6+';;'+YdzfwOyPb2gxT37B9Dm+';;'+byFGvxhKuI9HU7ceAaMr3N4+';;'+utk5Dor0c4fOpClX9gZI62NK
			QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SebHIf2jL1TBgrMKJu+name,url,105,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		if showDialogs: QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'هذه الخدمة مخصصة للمبرمج فقط',SebHIf2jL1TBgrMKJu,9999)
	return
def rRCw3hfy2Kq5l(id):
	qh4B9VQZCbXr0DRknFmi7J6,YdzfwOyPb2gxT37B9Dm,byFGvxhKuI9HU7ceAaMr3N4,utk5Dor0c4fOpClX9gZI62NK = id.split(';;')
	url = SebHIf2jL1TBgrMKJu
	if qh4B9VQZCbXr0DRknFmi7J6=='URL': url = byFGvxhKuI9HU7ceAaMr3N4
	elif qh4B9VQZCbXr0DRknFmi7J6=='YOUTUBE':
		url = qFsuKN7ngp.SITESURLS['YOUTUBE'][0]+'/watch?v='+byFGvxhKuI9HU7ceAaMr3N4
		import dBWq3E7PZC
		dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ([url],tfX4sO3hy2H1IbKG,'live',url)
		return
	elif qh4B9VQZCbXr0DRknFmi7J6=='GA':
		BXupmlPQvMIrweKqkG = { 'id' : SebHIf2jL1TBgrMKJu, 'user' : qFsuKN7ngp.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : SebHIf2jL1TBgrMKJu }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,BXupmlPQvMIrweKqkG,SebHIf2jL1TBgrMKJu,False,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-1st')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		cookies = Bc5IUelt4sWvMXTdy.cookies
		XpCghP9BbGNYQmK8I0dsVc = cookies['ASP.NET_SessionId']
		url = Bc5IUelt4sWvMXTdy.headers['Location']
		BXupmlPQvMIrweKqkG = { 'id' : byFGvxhKuI9HU7ceAaMr3N4 , 'user' : qFsuKN7ngp.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : SebHIf2jL1TBgrMKJu }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+XpCghP9BbGNYQmK8I0dsVc }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,BXupmlPQvMIrweKqkG,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-2nd')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		url = X2XorVqHjLkWeCchY4u9fSz.findall('resp":"(http.*?m3u8)(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		cOn6JqZlmQbjtT = url[0][0]
		zYqMXwfDLRNxWPIZ3o91H6b0 = url[0][1]
		FbJAy8xQMwO15 = 'http://38.'+YdzfwOyPb2gxT37B9Dm+'777/'+byFGvxhKuI9HU7ceAaMr3N4+'_HD.m3u8'+zYqMXwfDLRNxWPIZ3o91H6b0
		QOvxqBotp5AYaPJWhCEMki7z0F = FbJAy8xQMwO15.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		XXgrPOulZR2Sq7 = FbJAy8xQMwO15.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		HFThJNteGZsSR5CD7rimbjPq = ['HD','SD1','SD2']
		bQGVWFxKS4D6p9YC7XPyA8Os = [FbJAy8xQMwO15,QOvxqBotp5AYaPJWhCEMki7z0F,XXgrPOulZR2Sq7]
		QQea1XbjZDEMhp = 0
		if QQea1XbjZDEMhp == -1: return
		else: url = bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
	elif qh4B9VQZCbXr0DRknFmi7J6=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		BXupmlPQvMIrweKqkG = { 'id' : byFGvxhKuI9HU7ceAaMr3N4 , 'user' : qFsuKN7ngp.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : utk5Dor0c4fOpClX9gZI62NK }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST', j1IFsik4ouNePZr, BXupmlPQvMIrweKqkG, headers, False,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-3rd')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		url = Bc5IUelt4sWvMXTdy.headers['Location']
		url = url.replace('%20',qE4nB3mKWHs)
		url = url.replace('%3D','=')
		if 'Learn' in byFGvxhKuI9HU7ceAaMr3N4:
			url = url.replace('NTNNile',SebHIf2jL1TBgrMKJu)
			url = url.replace('learning1','Learning')
	elif qh4B9VQZCbXr0DRknFmi7J6=='PL':
		BXupmlPQvMIrweKqkG = { 'id' : byFGvxhKuI9HU7ceAaMr3N4 , 'user' : qFsuKN7ngp.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : utk5Dor0c4fOpClX9gZI62NK }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST', j1IFsik4ouNePZr, BXupmlPQvMIrweKqkG, SebHIf2jL1TBgrMKJu,False,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-4th')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		url = Bc5IUelt4sWvMXTdy.headers['Location']
		headers = {'Referer':Bc5IUelt4sWvMXTdy.headers['Referer']}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'POST',url, SebHIf2jL1TBgrMKJu,headers , SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-5th')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		items = X2XorVqHjLkWeCchY4u9fSz.findall('source src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		url = items[0]
	elif qh4B9VQZCbXr0DRknFmi7J6 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if qh4B9VQZCbXr0DRknFmi7J6=='TA': byFGvxhKuI9HU7ceAaMr3N4 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		BXupmlPQvMIrweKqkG = { 'id' : byFGvxhKuI9HU7ceAaMr3N4 , 'user' : qFsuKN7ngp.AV_CLIENT_IDS , 'function' : 'play'+qh4B9VQZCbXr0DRknFmi7J6 , 'menu' : utk5Dor0c4fOpClX9gZI62NK }
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'POST',j1IFsik4ouNePZr,BXupmlPQvMIrweKqkG,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-6th')
		if not Bc5IUelt4sWvMXTdy.succeeded:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		url = Bc5IUelt4sWvMXTdy.headers['Location']
		if qh4B9VQZCbXr0DRknFmi7J6=='FM':
			Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET', url, SebHIf2jL1TBgrMKJu, SebHIf2jL1TBgrMKJu, False,SebHIf2jL1TBgrMKJu,'LIVETV-PLAY-7th')
			url = Bc5IUelt4sWvMXTdy.headers['Location']
			url = url.replace('https','http')
	nxW9asAySzOt2foFGT4LwmHNl8uZ(url,tfX4sO3hy2H1IbKG,'live')
	return