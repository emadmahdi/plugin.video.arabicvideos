# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SHAHID4U2'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SH2_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
headers = {'User-Agent':b6rmBauMc3HqTev0t(True)}
jgvMWZhtPlBT = []
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==1090: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==1091: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==1092: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==1093: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url,text)
	elif mode==1094: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FULL_FILTER___'+text)
	elif mode==1095: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'DEFINED_FILTER___'+text)
	elif mode==1099: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = j1IFsik4ouNePZr
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,1099,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',VK4jU2G3s1PwkticQYyLoW,1095)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',VK4jU2G3s1PwkticQYyLoW,1094)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',VK4jU2G3s1PwkticQYyLoW,1091,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"main-menu"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			if title in jgvMWZhtPlBT: continue
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
			if 'netflix' in cOn6JqZlmQbjtT: title = 'نيتفلكس'
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1091)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,z9XqWIL1ZS4amgJK=SebHIf2jL1TBgrMKJu,Bc5IUelt4sWvMXTdy=SebHIf2jL1TBgrMKJu):
	if not Bc5IUelt4sWvMXTdy: Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ,items,aLlVEzy8XR62 = [],[],[]
	if z9XqWIL1ZS4amgJK=='featured': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"Slides--Main"(.*?)"filterTabs"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"BlocksHolder"(.*?)"pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?title="(.*?)".*?data-src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		if 'WWE' in title: continue
		if 'javascript' in cOn6JqZlmQbjtT: continue
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.strip(qE4nB3mKWHs)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '/film/' in cOn6JqZlmQbjtT or 'فيلم' in cOn6JqZlmQbjtT or any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1092,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + Wj39BaH6oEmstx[0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1093,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/actor/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1091,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/series/' in cOn6JqZlmQbjtT and '/list' not in url:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'/list'
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1091,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/list' in url and 'حلقة' in title:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1092,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1093,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ and not z9XqWIL1ZS4amgJK:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<li>.*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			if title: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,1091,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,z9XqWIL1ZS4amgJK)
	return
def LRb6nEvgqXwITMc80r1Vt(url,Auzx9pK5jDH0wi3EyCTVvoXg1Y2WB):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="w-100(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="EpisodesList"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		ZXzOqKCNLir = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
		TZhUn4jWpX0YBOg1Eix = ZXzOqKCNLir.count('/season/')+ZXzOqKCNLir.count('/series/')
		vQa3CyrAnT24L8ZWUGIKPkRigdOp = ZXzOqKCNLir.count('href')-TZhUn4jWpX0YBOg1Eix
		if len(k2pC30UArFeg7Ru9tGiZlSmzQ)==JhTts2R43AxkM8bYanKVy:
			myB74DAG8LCE6vTsKfJPx = k2pC30UArFeg7Ru9tGiZlSmzQ[nyUIsfd53EGot9vbj0XDeq]
			SBvz3peNHmqf8t9j = myB74DAG8LCE6vTsKfJPx.count('/season/')+myB74DAG8LCE6vTsKfJPx.count('/series/')
			NDjaYk0dTVCHtUI = myB74DAG8LCE6vTsKfJPx.count('href=')-SBvz3peNHmqf8t9j
		else: myB74DAG8LCE6vTsKfJPx,SBvz3peNHmqf8t9j,NDjaYk0dTVCHtUI = SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
		if not Auzx9pK5jDH0wi3EyCTVvoXg1Y2WB:
			if TZhUn4jWpX0YBOg1Eix>nyUIsfd53EGot9vbj0XDeq: drRnSgoBtKWjmU5FH4ZCIVhzqNb = ZXzOqKCNLir
			elif SBvz3peNHmqf8t9j>nyUIsfd53EGot9vbj0XDeq: drRnSgoBtKWjmU5FH4ZCIVhzqNb = myB74DAG8LCE6vTsKfJPx
		if not drRnSgoBtKWjmU5FH4ZCIVhzqNb:
			if vQa3CyrAnT24L8ZWUGIKPkRigdOp: drRnSgoBtKWjmU5FH4ZCIVhzqNb = ZXzOqKCNLir
			elif NDjaYk0dTVCHtUI: drRnSgoBtKWjmU5FH4ZCIVhzqNb = myB74DAG8LCE6vTsKfJPx
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<.*?<em>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,o7MeOx6PDA1d,sABprza7wEOC0Fd3PTQ in items:
			title = o7MeOx6PDA1d+qE4nB3mKWHs+sABprza7wEOC0Fd3PTQ
			if '/season/' not in cOn6JqZlmQbjtT and '/series/' not in cOn6JqZlmQbjtT: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1092)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1093,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'season')
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	qOGEcWZIwex2fK,B6BsHXWZwD = [],[]
	cc6R5oLjVt = X2XorVqHjLkWeCchY4u9fSz.findall('class="watch" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	QYrEHI8OWK6awe3C47VSf = X2XorVqHjLkWeCchY4u9fSz.findall('class="download" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cc6R5oLjVt:
		cc6R5oLjVt = cc6R5oLjVt[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',cc6R5oLjVt,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-PLAY-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"watch"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('data-watch="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT in B6BsHXWZwD: continue
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
				B6BsHXWZwD.append(cOn6JqZlmQbjtT)
	if QYrEHI8OWK6awe3C47VSf:
		QYrEHI8OWK6awe3C47VSf = QYrEHI8OWK6awe3C47VSf[0].replace('//','/').replace(':/','://').rstrip('/')+'/'
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',QYrEHI8OWK6awe3C47VSf,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-PLAY-3rd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"DownList"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<quality>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT in B6BsHXWZwD: continue
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
				B6BsHXWZwD.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return
def OU0dGs5xyz9KH3o7(url):
	url = url.split('/smartemadfilter?')[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHAHID4U2-GET_FILTERS_BLOCKS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	BJheYUDK3EOyfPR24 = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('adv-filter(.*?)shows-container',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		dx2YaptQXPWhD,EOVC5HvpA3dNJcx,cuoYjfNMPnmhQgtFE = zip(*BJheYUDK3EOyfPR24)
		BJheYUDK3EOyfPR24 = zip(EOVC5HvpA3dNJcx,dx2YaptQXPWhD,cuoYjfNMPnmhQgtFE)
	return BJheYUDK3EOyfPR24
def TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb):
	items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>\s*(.*?)\s*<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return items
def WiI8urkKJYDwTfygBe2psH(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	iiXk0elDVoLTZ8HUAaB = url.split('/smartemadfilter?')[0]
	BDku1TovVtpfmhL9Ryde4nNQ = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	url = url.replace(iiXk0elDVoLTZ8HUAaB,BDku1TovVtpfmhL9Ryde4nNQ)
	url = url.replace('/smartemadfilter?','/?')
	return url
GJUdZFt2Q1HukDo7zjwx4cqpl = ['quality','year','genre','category']
ONFLiPpH2XZDKwqY3 = ['category','genre','year']
def vimwpBGoVK3EZrUkjPL(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='DEFINED_FILTER':
		if ONFLiPpH2XZDKwqY3[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = ONFLiPpH2XZDKwqY3[0]
		for YHnALfql8hprDu in range(len(ONFLiPpH2XZDKwqY3[0:-1])):
			if ONFLiPpH2XZDKwqY3[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = ONFLiPpH2XZDKwqY3[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
	elif type=='FULL_FILTER':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'/smartemadfilter?'+wk0AjSOpcRB
		iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',iGxH2fsuScPtkJb7ECg,1091)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',iGxH2fsuScPtkJb7ECg,1091)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	BJheYUDK3EOyfPR24 = OU0dGs5xyz9KH3o7(url)
	dict = {}
	for name,oIi8QaPyZBr1mvUcsh,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		name = name.replace('كل ',SebHIf2jL1TBgrMKJu)
		items = TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='DEFINED_FILTER':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<2:
				if oIi8QaPyZBr1mvUcsh==ONFLiPpH2XZDKwqY3[-1]:
					iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
					yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(iGxH2fsuScPtkJb7ECg)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'DEFINED_FILTER___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				if oIi8QaPyZBr1mvUcsh==ONFLiPpH2XZDKwqY3[-1]:
					iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',iGxH2fsuScPtkJb7ECg,1091)
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,1095,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FULL_FILTER':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع :'+name,qg7Nr1dCaD,1094,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if value=='196533': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'أفلام نيتفلكس'
			elif value=='196531': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'مسلسلات نيتفلكس'
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'+name
			if type=='FULL_FILTER': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,1094,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='DEFINED_FILTER' and ONFLiPpH2XZDKwqY3[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
				iGxH2fsuScPtkJb7ECg = WiI8urkKJYDwTfygBe2psH(qg7Nr1dCaD)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,1091)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,1095,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.replace('=&','=0&')
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	for key in GJUdZFt2Q1HukDo7zjwx4cqpl:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('=0','=')
	return hIyBYfuc8oTsEZ