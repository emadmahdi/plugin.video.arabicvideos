# -*- coding: utf-8 -*-
from RSdDifzoPG import *
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
tfX4sO3hy2H1IbKG = 'AKOAMCAM'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_AKC_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['مصارعة']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==350: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==351: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==352: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==353: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==354: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FILTERS___'+text)
	elif mode==355: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'CATEGORIES___'+text)
	elif mode==356: lfZmugQCFKLGT05AH29IsMiho = irB6L1M7ksDyn0ToWI2A(url)
	elif mode==357: lfZmugQCFKLGT05AH29IsMiho = wfBe0qLFEsX9mZopPiW(url)
	elif mode==359: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+QNR6tCevIGEZKX3rAVsP+'هذا الموقع مغلق'+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,8)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,359,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',j1IFsik4ouNePZr,356)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',j1IFsik4ouNePZr,357)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKOAMCAM-MENU-1st')
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('recently-container.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if qg7Nr1dCaD: qg7Nr1dCaD = qg7Nr1dCaD[0]
	else: qg7Nr1dCaD = j1IFsik4ouNePZr
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'اضيف حديثا',qg7Nr1dCaD,351)
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('@id":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if qg7Nr1dCaD: qg7Nr1dCaD = qg7Nr1dCaD[0]
	else: qg7Nr1dCaD = j1IFsik4ouNePZr
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',qg7Nr1dCaD,351,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-categories-list(.*?)main-categories-list',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?class="font.*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,351)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="categories-box(.*?)<footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
			if title not in jgvMWZhtPlBT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,351)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def irB6L1M7ksDyn0ToWI2A(website=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKOAMCAM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu(.*?)<nav',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?text">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT:
				title = title+' مصنفة'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,355)
		if website==SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def wfBe0qLFEsX9mZopPiW(website=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'AKOAMCAM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="menu(.*?)<nav',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?text">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title not in jgvMWZhtPlBT:
				title = title+' مفلترة'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,354)
		if website==SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(RycFd7wZBiNhJjOPIGKp,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('swiper-container(.*?)swiper-button-prev',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="container"(.*?)main-footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		aLlVEzy8XR62 = []
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|الحلقه) \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if Wj39BaH6oEmstx:
					title = '_MOD_' + Wj39BaH6oEmstx[0][0]
					if title not in aLlVEzy8XR62:
						QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,352,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
						aLlVEzy8XR62.append(title)
			elif 'مسلسل' in title:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,352,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,353,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href=["\'](.*?)["\'].*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,351)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + '/?s='+t2WLY7DxIZs
	lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAMCAM-EPISODES-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('text-white">الحلقات(.*?)<header',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		EiadFrl0bx3uWPqGmIkHNQp = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in EiadFrl0bx3uWPqGmIkHNQp:
			if 'الحلقة' in title or 'الحلقه' in title: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,353,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Icon')
		if LCK8lO2yRWaTVEQcdjPXAzpFBe9.count('<title>')>1: title = X2XorVqHjLkWeCchY4u9fSz.findall('<title>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[1]
		else: title = 'رابط التشغيل'
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,353,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq = [],[]
	RjiZSasH9e = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKOAMCAM-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = RjiZSasH9e.content
	B8vJbFtznDGZ6ASw0V2 = X2XorVqHjLkWeCchY4u9fSz.findall('post_id=(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if B8vJbFtznDGZ6ASw0V2:
		B8vJbFtznDGZ6ASw0V2 = B8vJbFtznDGZ6ASw0V2[0]
		headers = {'User-Agent':SebHIf2jL1TBgrMKJu,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':B8vJbFtznDGZ6ASw0V2}
		qg7Nr1dCaD = j1IFsik4ouNePZr+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		FYtQmWeLnlzjOsPbvf9uKgq2x = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'POST',qg7Nr1dCaD,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKOAMCAM-PLAY-1st')
		O3XeD9sgNyH = FYtQmWeLnlzjOsPbvf9uKgq2x.content
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-server="(.*?)".*?class="text">(.*?)<',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for IIU5djzb1RCg7QwYauEHvMcrGDA0Bt,name in items:
			cOn6JqZlmQbjtT = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?postid='+B8vJbFtznDGZ6ASw0V2+'&serverid='+IIU5djzb1RCg7QwYauEHvMcrGDA0Bt+'?named='+name+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
			HFThJNteGZsSR5CD7rimbjPq.append(name)
		qg7Nr1dCaD = j1IFsik4ouNePZr+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		FYtQmWeLnlzjOsPbvf9uKgq2x = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'POST',qg7Nr1dCaD,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'AKOAMCAM-PLAY-1st')
		O3XeD9sgNyH = FYtQmWeLnlzjOsPbvf9uKgq2x.content
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?class="text">(.*?)<',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
			HFThJNteGZsSR5CD7rimbjPq.append(title)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def vimwpBGoVK3EZrUkjPL(url,filter):
	PD0JksfFrlMUtG6OWVLgdiY8o5b = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='CATEGORIES':
		if PD0JksfFrlMUtG6OWVLgdiY8o5b[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[0]
		for YHnALfql8hprDu in range(len(PD0JksfFrlMUtG6OWVLgdiY8o5b[0:-1])):
			if PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'all')
		qg7Nr1dCaD = url+'?'+LnwzHFAVsfO2Go
	elif type=='FILTERS':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'all')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'?'+wk0AjSOpcRB
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها',qg7Nr1dCaD,351,SebHIf2jL1TBgrMKJu,'1')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',qg7Nr1dCaD,351,SebHIf2jL1TBgrMKJu,'1')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<form id(.*?)</form>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	dict = {}
	for oIi8QaPyZBr1mvUcsh,name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<option(.*?)>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='CATEGORIES':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<=1:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'CATEGORIES___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,351,SebHIf2jL1TBgrMKJu,'1')
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,355,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FILTERS':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع : '+name,qg7Nr1dCaD,354,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			if 'value' not in value: value = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			else: value = X2XorVqHjLkWeCchY4u9fSz.findall('"(.*?)"',value,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' : '#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' : '+name
			if type=='FILTERS': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,354,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='CATEGORIES' and PD0JksfFrlMUtG6OWVLgdiY8o5b[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'all')
				iGxH2fsuScPtkJb7ECg = url+'?'+LnwzHFAVsfO2Go
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,351,SebHIf2jL1TBgrMKJu,'1')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,355,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	CIHKiYt9osw4SyjMfhP0rZ8 = ['cat','genre','release-year','quality','orderby']
	for key in CIHKiYt9osw4SyjMfhP0rZ8:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	return hIyBYfuc8oTsEZ