# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = HCiWF4jV1Q8(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ଑")
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,vCsnpu14Zi7qUEQg3Tl50h):
	if   hL9fngBAu7XzOx==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠳࠴࠲ட"): lfZmugQCFKLGT05AH29IsMiho = MMj9IUcmQ2DSO3p6VwlNsi0EoeyBP()
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠴࠵࠴஠"): lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(vCsnpu14Zi7qUEQg3Tl50h)
	elif hL9fngBAu7XzOx==fp6KV7DlS8QYniUczHdmZChL(u"࠵࠶࠶஡"): lfZmugQCFKLGT05AH29IsMiho = DDoxKlyAPj5hwp()
	elif hL9fngBAu7XzOx==l7kBpMw5Qn(u"࠶࠷࠸஢"): lfZmugQCFKLGT05AH29IsMiho = uz9HRhvks02pbVB6IN1FaSJr3wld()
	else: lfZmugQCFKLGT05AH29IsMiho = mrhSYXH2P8bO3eJAa9n
	return lfZmugQCFKLGT05AH29IsMiho
def rRCw3hfy2Kq5l(vCsnpu14Zi7qUEQg3Tl50h):
	nxW9asAySzOt2foFGT4LwmHNl8uZ(vCsnpu14Zi7qUEQg3Tl50h,tfX4sO3hy2H1IbKG,Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡶࡪࡦࡨࡳࠬ଒"))
	return
def uz9HRhvks02pbVB6IN1FaSJr3wld():
	FKe1TxU27G4SPo8hDER = czvu7VQCZodkMf(u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ଓ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧଔ"),FKe1TxU27G4SPo8hDER)
	return
def MMj9IUcmQ2DSO3p6VwlNsi0EoeyBP():
	QUzFYoapm9jx(wPnfgxKZdAv6T10(u"ࠩ࡯࡭ࡳࡱࠧକ"),TVnqDYzWoM2UfHp0dchJ(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨଖ"),SebHIf2jL1TBgrMKJu,sTGtHVyhQ9cJU37zxo2O(u"࠷࠸࠹ண"))
	QUzFYoapm9jx(wPnfgxKZdAv6T10(u"ࠫࡱ࡯࡮࡬ࠩଗ"),ASkvf27etUK0(u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬଘ"),SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"࠸࠹࠲த"))
	QUzFYoapm9jx(ASkvf27etUK0(u"࠭࡬ࡪࡰ࡮ࠫଙ"),E7r8hUCVvTiFQW0dBGXjxcy+C3w6qluao7EzUxJgMGBtV(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ଚ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,ASkvf27etUK0(u"࠿࠹࠺࠻஥"))
	zRZLKeF32sQ1ax7X = XJ2enkobgZLFxH0jmv()
	ip6xldXWS7jtymbPQOv28LY = E2xjtKaMXdC3NDoTm7f5Wkev.stat(zRZLKeF32sQ1ax7X).st_mtime
	sCwoI6tacuXvUAqOb3 = []
	if QBOMjKifEAFD: vxrMGCzSZH46X = E2xjtKaMXdC3NDoTm7f5Wkev.listdir(zRZLKeF32sQ1ax7X.encode(Tv08xsf9HOqunIVUPdK1))
	else: vxrMGCzSZH46X = E2xjtKaMXdC3NDoTm7f5Wkev.listdir(zRZLKeF32sQ1ax7X.decode(Tv08xsf9HOqunIVUPdK1))
	for LEv8pF9IaWcQf61djgCUOVY in vxrMGCzSZH46X:
		if QBOMjKifEAFD: LEv8pF9IaWcQf61djgCUOVY = LEv8pF9IaWcQf61djgCUOVY.decode(Tv08xsf9HOqunIVUPdK1)
		if not LEv8pF9IaWcQf61djgCUOVY.startswith(HCiWF4jV1Q8(u"ࠨࡨ࡬ࡰࡪࡥࠧଛ")): continue
		W6lRqLmp90zr = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(zRZLKeF32sQ1ax7X,LEv8pF9IaWcQf61djgCUOVY)
		ip6xldXWS7jtymbPQOv28LY = E2xjtKaMXdC3NDoTm7f5Wkev.path.getmtime(W6lRqLmp90zr)
		sCwoI6tacuXvUAqOb3.append([LEv8pF9IaWcQf61djgCUOVY,ip6xldXWS7jtymbPQOv28LY])
	sCwoI6tacuXvUAqOb3 = sorted(sCwoI6tacuXvUAqOb3,reverse=BBX9RAuxnyGZ4WIF2TrhYeom3,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq])
	for LEv8pF9IaWcQf61djgCUOVY,ip6xldXWS7jtymbPQOv28LY in sCwoI6tacuXvUAqOb3:
		if psS8dmb912iRBgGc7qOPyCZ6:
			try: LEv8pF9IaWcQf61djgCUOVY = LEv8pF9IaWcQf61djgCUOVY.decode(Tv08xsf9HOqunIVUPdK1)
			except: pass
			LEv8pF9IaWcQf61djgCUOVY = LEv8pF9IaWcQf61djgCUOVY.encode(Tv08xsf9HOqunIVUPdK1)
		W6lRqLmp90zr = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(zRZLKeF32sQ1ax7X,LEv8pF9IaWcQf61djgCUOVY)
		QUzFYoapm9jx(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡹ࡭ࡩ࡫࡯ࠨଜ"),LEv8pF9IaWcQf61djgCUOVY,W6lRqLmp90zr,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠳࠴࠳஦"))
	return
def XJ2enkobgZLFxH0jmv():
	zRZLKeF32sQ1ax7X = MMAUZiw4CoJ8.getSetting(uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ଝ"))
	if zRZLKeF32sQ1ax7X: return zRZLKeF32sQ1ax7X
	MMAUZiw4CoJ8.setSetting(DQIrVcKuY6bJv(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧଞ"),LdX87mwIzyBM)
	return LdX87mwIzyBM
def DDoxKlyAPj5hwp():
	zRZLKeF32sQ1ax7X = XJ2enkobgZLFxH0jmv()
	J0JAvCbo6c93H8DresWL = vvubxo631m2zYC(VOALf8iYEnMdK0g(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଟ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪଠ"),QNR6tCevIGEZKX3rAVsP+zRZLKeF32sQ1ax7X+XOVRfitWJP1zL3p2CMYF+uqLUBHepfM3l6AyIzTJh80a(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨଡ"))
	if J0JAvCbo6c93H8DresWL==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲஧"):
		CAseDEuJGyX9H7jPRhZ = jHS9WuMxcs475RPkwpErteQI(wPnfgxKZdAv6T10(u"࠵ந"),HCiWF4jV1Q8(u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬଢ"),C3w6qluao7EzUxJgMGBtV(u"ࠩ࡯ࡳࡨࡧ࡬ࠨଣ"),SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n,BBX9RAuxnyGZ4WIF2TrhYeom3,zRZLKeF32sQ1ax7X)
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(DQIrVcKuY6bJv(u"ࠪࡧࡪࡴࡴࡦࡴࠪତ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,sTGtHVyhQ9cJU37zxo2O(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨଥ"),QNR6tCevIGEZKX3rAVsP+zRZLKeF32sQ1ax7X+XOVRfitWJP1zL3p2CMYF+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭ଦ"))
		if sLhog1knUIF4fNOjY2zJqQ7cxArb==HCiWF4jV1Q8(u"࠴ன"):
			MMAUZiw4CoJ8.setSetting(xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩଧ"),CAseDEuJGyX9H7jPRhZ)
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l7kBpMw5Qn(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨନ"))
	return
def MybkE8Hu0PUnXVafFWYmiAr(vCsnpu14Zi7qUEQg3Tl50h,stQZoj85K3HPTUq2pCDAbaGSXLJw=SebHIf2jL1TBgrMKJu,website=SebHIf2jL1TBgrMKJu):
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+TVnqDYzWoM2UfHp0dchJ(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ଩")+vCsnpu14Zi7qUEQg3Tl50h+AGlW9LqKN3Dvo(u"ࠩࠣࡡࠬପ"))
	if not stQZoj85K3HPTUq2pCDAbaGSXLJw: stQZoj85K3HPTUq2pCDAbaGSXLJw = j1HGJPrFA3tTfLxayDCgIpE7Q(vCsnpu14Zi7qUEQg3Tl50h)
	zRZLKeF32sQ1ax7X = XJ2enkobgZLFxH0jmv()
	WbC0S7lwP6ODR3cJKBQ = MlNunOcdK41Qo59rIakEmgPx(mrhSYXH2P8bO3eJAa9n)
	LEv8pF9IaWcQf61djgCUOVY = WbC0S7lwP6ODR3cJKBQ.replace(qE4nB3mKWHs,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡣࠬଫ"))
	LEv8pF9IaWcQf61djgCUOVY = YRPMivXNVUgu0FSsOICQnTZ2r(LEv8pF9IaWcQf61djgCUOVY)
	LEv8pF9IaWcQf61djgCUOVY = Ns6AJKH7DGpr19Wl5C3nF(u"ࠫ࡫࡯࡬ࡦࡡࠪବ")+str(int(H3a6hvAgeNctTiXF8d1uELfPr4y))[-NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠸ப"):]+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡥࠧଭ")+LEv8pF9IaWcQf61djgCUOVY+stQZoj85K3HPTUq2pCDAbaGSXLJw
	Uw9fdpoCO4NqjTHs1bQzarR0M6 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(zRZLKeF32sQ1ax7X,LEv8pF9IaWcQf61djgCUOVY)
	P63kUYjgATfKD = {}
	P63kUYjgATfKD[Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨମ")] = SebHIf2jL1TBgrMKJu
	P63kUYjgATfKD[zpx2fPNKk6Ms38eD1vcO(u"ࠧࡂࡥࡦࡩࡵࡺࠧଯ")] = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࠬ࠲࠮ࠬର")
	vCsnpu14Zi7qUEQg3Tl50h = vCsnpu14Zi7qUEQg3Tl50h.replace(HCiWF4jV1Q8(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ଱"),SebHIf2jL1TBgrMKJu)
	if Ns6AJKH7DGpr19Wl5C3nF(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨଲ") in vCsnpu14Zi7qUEQg3Tl50h:
		qg7Nr1dCaD,YIgWR5Sj3cVXaEuqhkHo = vCsnpu14Zi7qUEQg3Tl50h.rsplit(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩଳ"),TVnqDYzWoM2UfHp0dchJ(u"࠶஫"))
		YIgWR5Sj3cVXaEuqhkHo = YIgWR5Sj3cVXaEuqhkHo.replace(sTGtHVyhQ9cJU37zxo2O(u"ࠬࢂࠧ଴"),SebHIf2jL1TBgrMKJu).replace(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࠦࠨଵ"),SebHIf2jL1TBgrMKJu)
	else: qg7Nr1dCaD,YIgWR5Sj3cVXaEuqhkHo = vCsnpu14Zi7qUEQg3Tl50h,None
	if not YIgWR5Sj3cVXaEuqhkHo: YIgWR5Sj3cVXaEuqhkHo = b6rmBauMc3HqTev0t()
	if YIgWR5Sj3cVXaEuqhkHo: P63kUYjgATfKD[sTGtHVyhQ9cJU37zxo2O(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଶ")] = YIgWR5Sj3cVXaEuqhkHo
	if czvu7VQCZodkMf(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪଷ") in qg7Nr1dCaD: qg7Nr1dCaD,ONbf0C7vAzg = qg7Nr1dCaD.rsplit(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫସ"),ASkvf27etUK0(u"࠷஬"))
	else: qg7Nr1dCaD,ONbf0C7vAzg = qg7Nr1dCaD,SebHIf2jL1TBgrMKJu
	qg7Nr1dCaD = qg7Nr1dCaD.strip(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࢀࠬହ")).strip(ASkvf27etUK0(u"ࠫࠫ࠭଺")).strip(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࢂࠧ଻")).strip(xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࠦࠨ଼"))
	ONbf0C7vAzg = ONbf0C7vAzg.replace(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡽࠩଽ"),SebHIf2jL1TBgrMKJu).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࠨࠪା"),SebHIf2jL1TBgrMKJu)
	if ONbf0C7vAzg:	P63kUYjgATfKD[sTGtHVyhQ9cJU37zxo2O(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪି")] = ONbf0C7vAzg
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+C3w6qluao7EzUxJgMGBtV(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୀ")+qg7Nr1dCaD+DQIrVcKuY6bJv(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧୁ")+str(P63kUYjgATfKD)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬୂ")+Uw9fdpoCO4NqjTHs1bQzarR0M6+Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࠠ࡞ࠩୃ"))
	A4d05PotiJvVZwaWjELn = ALwOspNtXxZrz3PEKku(u"࠱࠱࠴࠷஭")*ALwOspNtXxZrz3PEKku(u"࠱࠱࠴࠷஭")
	OWyq9BTcz1dKevmG7F6JgYiruoAZ = L89QpfNav5RrOZXYqliW()//A4d05PotiJvVZwaWjELn
	if not OWyq9BTcz1dKevmG7F6JgYiruoAZ:
		M8wEz43vLgdl(TVnqDYzWoM2UfHp0dchJ(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ୄ"),DQIrVcKuY6bJv(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨ୅"),gCkRKGhwcx26v(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭୆"),uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭େ"))
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬୈ"))
		return mrhSYXH2P8bO3eJAa9n
	if stQZoj85K3HPTUq2pCDAbaGSXLJw==uqLUBHepfM3l6AyIzTJh80a(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ୉"):
		HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = YBCFjeH81s4Gxlgki(tfX4sO3hy2H1IbKG,qg7Nr1dCaD,P63kUYjgATfKD)
		if len(HFThJNteGZsSR5CD7rimbjPq)==ypO63g8oJEsDnPBHSuU7lMTZr(u"࠱ம"):
			i9yzUqgAW2Zap1h4Lm(Ns6AJKH7DGpr19Wl5C3nF(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪ୊"),SebHIf2jL1TBgrMKJu)
			return mrhSYXH2P8bO3eJAa9n
		elif len(HFThJNteGZsSR5CD7rimbjPq)==TVnqDYzWoM2UfHp0dchJ(u"࠳ய"): QQea1XbjZDEMhp = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠳ர")
		elif len(HFThJNteGZsSR5CD7rimbjPq)>DQIrVcKuY6bJv(u"࠵ற"):
			QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG(gCkRKGhwcx26v(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬୋ"), HFThJNteGZsSR5CD7rimbjPq)
			if QQea1XbjZDEMhp == -ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶ல") :
				i9yzUqgAW2Zap1h4Lm(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫୌ"),SebHIf2jL1TBgrMKJu)
				return mrhSYXH2P8bO3eJAa9n
		qg7Nr1dCaD = bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
	u2kRdwh9bIJi0Kc = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠶ள")
	import requests as GQHhfr5kocClg6
	if stQZoj85K3HPTUq2pCDAbaGSXLJw==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ୍"):
		Uw9fdpoCO4NqjTHs1bQzarR0M6 = Uw9fdpoCO4NqjTHs1bQzarR0M6.rsplit(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ୎"))[wvkDqmNZlJU52isXo]+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࠳ࡳࡰ࠵ࠩ୏")
		wVjeLJoR86yKY0PtSZWqfNHUz42 = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,AGlW9LqKN3Dvo(u"ࠬࡍࡅࡕࠩ୐"),qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,P63kUYjgATfKD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,iDhLkZS6XBagNCQfs9tq2(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭୑"))
		eKEG5XyLvzRxODJ9FNsQI3fm2A = wVjeLJoR86yKY0PtSZWqfNHUz42.content
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall(HADrRCz9QgU4xudPJIqYb70(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ୒"),eKEG5XyLvzRxODJ9FNsQI3fm2A+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨ࡞ࡱࡠࡷ࠭୓"),X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ୔")+qg7Nr1dCaD+C3w6qluao7EzUxJgMGBtV(u"ࠪࠤࡢ࠭୕"))
			return mrhSYXH2P8bO3eJAa9n
		cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[wvkDqmNZlJU52isXo]
		if not cOn6JqZlmQbjtT.startswith(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࡭ࡺࡴࡱࠩୖ")):
			if cOn6JqZlmQbjtT.startswith(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࠵࠯ࠨୗ")): cOn6JqZlmQbjtT = qg7Nr1dCaD.split(HADrRCz9QgU4xudPJIqYb70(u"࠭࠺ࠨ୘"),AGlW9LqKN3Dvo(u"࠱ழ"))[wvkDqmNZlJU52isXo]+l7kBpMw5Qn(u"ࠧ࠻ࠩ୙")+cOn6JqZlmQbjtT
			elif cOn6JqZlmQbjtT.startswith(TVnqDYzWoM2UfHp0dchJ(u"ࠨ࠱ࠪ୚")): cOn6JqZlmQbjtT = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qg7Nr1dCaD,ASkvf27etUK0(u"ࠩࡸࡶࡱ࠭୛"))+cOn6JqZlmQbjtT
			else: cOn6JqZlmQbjtT = qg7Nr1dCaD.rsplit(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࠳ࠬଡ଼"),gCkRKGhwcx26v(u"࠲வ"))[wvkDqmNZlJU52isXo]+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫ࠴࠭ଢ଼")+cOn6JqZlmQbjtT
		wVjeLJoR86yKY0PtSZWqfNHUz42 = GQHhfr5kocClg6.request(TVnqDYzWoM2UfHp0dchJ(u"ࠬࡍࡅࡕࠩ୞"),cOn6JqZlmQbjtT,headers=P63kUYjgATfKD,verify=mrhSYXH2P8bO3eJAa9n)
		uWi4nYOj9tBJD1mVXz = wVjeLJoR86yKY0PtSZWqfNHUz42.content
		au3SNlPgMzKU4F6CVoAmbxG = len(uWi4nYOj9tBJD1mVXz)
		oXgY1PJ2SjTxN5Uz6 = len(uLdRirAZJKoSgPqNUjm84WXE5cn3aT)
		u2kRdwh9bIJi0Kc = au3SNlPgMzKU4F6CVoAmbxG*oXgY1PJ2SjTxN5Uz6
	else:
		au3SNlPgMzKU4F6CVoAmbxG = tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠳ஶ")*A4d05PotiJvVZwaWjELn
		wVjeLJoR86yKY0PtSZWqfNHUz42 = GQHhfr5kocClg6.request(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡇࡆࡖࠪୟ"),qg7Nr1dCaD,headers=P63kUYjgATfKD,verify=mrhSYXH2P8bO3eJAa9n,stream=BBX9RAuxnyGZ4WIF2TrhYeom3)
		if v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨୠ") in wVjeLJoR86yKY0PtSZWqfNHUz42.headers: u2kRdwh9bIJi0Kc = int(wVjeLJoR86yKY0PtSZWqfNHUz42.headers[VOALf8iYEnMdK0g(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩୡ")])
		oXgY1PJ2SjTxN5Uz6 = int(u2kRdwh9bIJi0Kc//au3SNlPgMzKU4F6CVoAmbxG)
	ILuE0g786D9e2YWiNGTm = int(u2kRdwh9bIJi0Kc//A4d05PotiJvVZwaWjELn)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠴ஷ")
	if u2kRdwh9bIJi0Kc<ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶࠶࠶࠰࠱ஸ"):
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+zpx2fPNKk6Ms38eD1vcO(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୢ")+qg7Nr1dCaD+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧୣ")+str(ILuE0g786D9e2YWiNGTm)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ୤")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୥")+Uw9fdpoCO4NqjTHs1bQzarR0M6+ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࠠ࡞ࠩ୦"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩ୧"))
		return mrhSYXH2P8bO3eJAa9n
	kPE7UWAL4FgibC8XhzlI31yVnr = C3w6qluao7EzUxJgMGBtV(u"࠹࠶࠰ஹ")
	SSTv2YhZ5cotG = OWyq9BTcz1dKevmG7F6JgYiruoAZ-ILuE0g786D9e2YWiNGTm
	if SSTv2YhZ5cotG<kPE7UWAL4FgibC8XhzlI31yVnr:
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୨")+qg7Nr1dCaD+ASkvf27etUK0(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭୩")+str(ILuE0g786D9e2YWiNGTm)+VOALf8iYEnMdK0g(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ୪")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠥࡓࡂࠡ࠯ࠣࠫ୫")+str(kPE7UWAL4FgibC8XhzlI31yVnr)+TVnqDYzWoM2UfHp0dchJ(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୬")+Uw9fdpoCO4NqjTHs1bQzarR0M6+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࠠ࡞ࠩ୭"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,HCiWF4jV1Q8(u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧ୮"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧ୯")+str(ILuE0g786D9e2YWiNGTm)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨ୰")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+DQIrVcKuY6bJv(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪୱ")+str(kPE7UWAL4FgibC8XhzlI31yVnr)+Ns6AJKH7DGpr19Wl5C3nF(u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭୲"))
		return mrhSYXH2P8bO3eJAa9n
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ୳"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Ns6AJKH7DGpr19Wl5C3nF(u"࠭็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥลࠧ୴"),HCiWF4jV1Q8(u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠฮฮ่๋ࠥะโา์หหࠥ࠭୵")+str(ILuE0g786D9e2YWiNGTm)+iDhLkZS6XBagNCQfs9tq2(u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦสใำํฬฬࠦࠧ୶")+str(OWyq9BTcz1dKevmG7F6JgYiruoAZ)+qeYIw0BNTL9bGJnosacQ1DtVR(u"้ࠩࠣ๏เวษษํฮࠥ๎็ัษࠣห้๋ไโࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠๅๆอั๊๐ไࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦลๅ๋ࠣะ์อาไࠢ࠱ࠤ์๊ࠠศ่อࠤ๊ะรไัࠣ์ฯื๊ะࠢส่ฬูสๆำสีࠥฮสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣรࠬ୷"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb!=ALwOspNtXxZrz3PEKku(u"࠷஺"):
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ୸"))
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭୹")+qg7Nr1dCaD+sTGtHVyhQ9cJU37zxo2O(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ୺")+Uw9fdpoCO4NqjTHs1bQzarR0M6+ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࠠ࡞ࠩ୻"))
		return mrhSYXH2P8bO3eJAa9n
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+C3w6qluao7EzUxJgMGBtV(u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬ୼"))
	ukn6WYrSGcIORhDeHl2dfw0EMq = fy567LYZh4gGdeSJN()
	ukn6WYrSGcIORhDeHl2dfw0EMq.create(Uw9fdpoCO4NqjTHs1bQzarR0M6,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ୽"))
	ZsWnthFi6JzbyGxX = BBX9RAuxnyGZ4WIF2TrhYeom3
	GhdtAy1o3Ru8z5WvkUFQ6ES = uv8V4fE7j9pmgFr3wnDL.time()
	if not qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,czvu7VQCZodkMf(u"ࠩหือฮฺࠠั่ࠤฬ๊สษำ฼ࠤฯ๋ࠠฦๆ฽หฦࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ୾"))
		return mrhSYXH2P8bO3eJAa9n
	if QBOMjKifEAFD: VV8fleh2QBp1vxkZq = open(Uw9fdpoCO4NqjTHs1bQzarR0M6,Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡻࡧ࠭୿"))
	else: VV8fleh2QBp1vxkZq = open(Uw9fdpoCO4NqjTHs1bQzarR0M6.decode(Tv08xsf9HOqunIVUPdK1),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡼࡨࠧ஀"))
	if stQZoj85K3HPTUq2pCDAbaGSXLJw==l7kBpMw5Qn(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁"):
		for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠱஻"),oXgY1PJ2SjTxN5Uz6+NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠱஻")):
			cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[XM3KUmO1QJxlv84bgFTHsjdNt0kYq-fp6KV7DlS8QYniUczHdmZChL(u"࠲஼")]
			if not cOn6JqZlmQbjtT.startswith(bcNqYtfET5l92dLGjyZSPe(u"࠭ࡨࡵࡶࡳࠫஂ")):
				if cOn6JqZlmQbjtT.startswith(czvu7VQCZodkMf(u"ࠧ࠰࠱ࠪஃ")): cOn6JqZlmQbjtT = qg7Nr1dCaD.split(AGlW9LqKN3Dvo(u"ࠨ࠼ࠪ஄"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠳஽"))[wvkDqmNZlJU52isXo]+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩ࠽ࠫஅ")+cOn6JqZlmQbjtT
				elif cOn6JqZlmQbjtT.startswith(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࠳ࠬஆ")): cOn6JqZlmQbjtT = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qg7Nr1dCaD,uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡺࡸ࡬ࠨஇ"))+cOn6JqZlmQbjtT
				else: cOn6JqZlmQbjtT = qg7Nr1dCaD.rsplit(AGlW9LqKN3Dvo(u"ࠬ࠵ࠧஈ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠴ா"))[wvkDqmNZlJU52isXo]+vMhFypGLHZJbdX4O7oc3W8x(u"࠭࠯ࠨஉ")+cOn6JqZlmQbjtT
			wVjeLJoR86yKY0PtSZWqfNHUz42 = GQHhfr5kocClg6.request(fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡈࡇࡗࠫஊ"),cOn6JqZlmQbjtT,headers=P63kUYjgATfKD,verify=mrhSYXH2P8bO3eJAa9n)
			uWi4nYOj9tBJD1mVXz = wVjeLJoR86yKY0PtSZWqfNHUz42.content
			wVjeLJoR86yKY0PtSZWqfNHUz42.close()
			VV8fleh2QBp1vxkZq.write(uWi4nYOj9tBJD1mVXz)
			NHZTEWhbMPzrQwXJ7vj95a = uv8V4fE7j9pmgFr3wnDL.time()
			PzCF9m7tVU51B2uhQHT0YlN3j = NHZTEWhbMPzrQwXJ7vj95a-GhdtAy1o3Ru8z5WvkUFQ6ES
			v9JVj3AwogPXQCxUYyRNOz7E60fm = PzCF9m7tVU51B2uhQHT0YlN3j//XM3KUmO1QJxlv84bgFTHsjdNt0kYq
			Fn0NAVel1fBZTyPzMGLHmvYwqUr = v9JVj3AwogPXQCxUYyRNOz7E60fm*(oXgY1PJ2SjTxN5Uz6+Gykx0wL3XrlWaujsqKP9n2Q(u"࠵ி"))
			II31SeXPWJ47L0NfxhBoOF = Fn0NAVel1fBZTyPzMGLHmvYwqUr-PzCF9m7tVU51B2uhQHT0YlN3j
			mm8riWX1U9q(ukn6WYrSGcIORhDeHl2dfw0EMq,int(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠷࠰࠱ு")*XM3KUmO1QJxlv84bgFTHsjdNt0kYq//(oXgY1PJ2SjTxN5Uz6+AGlW9LqKN3Dvo(u"࠶ீ"))),sTGtHVyhQ9cJU37zxo2O(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ஋"),C3w6qluao7EzUxJgMGBtV(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ஌"),str(XM3KUmO1QJxlv84bgFTHsjdNt0kYq*au3SNlPgMzKU4F6CVoAmbxG//A4d05PotiJvVZwaWjELn)+C3w6qluao7EzUxJgMGBtV(u"ࠪ࠳ࠬ஍")+str(ILuE0g786D9e2YWiNGTm)+DQIrVcKuY6bJv(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩஎ")+uv8V4fE7j9pmgFr3wnDL.strftime(l7kBpMw5Qn(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢஏ"),uv8V4fE7j9pmgFr3wnDL.gmtime(II31SeXPWJ47L0NfxhBoOF))+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࠠแࠩஐ"))
			if ukn6WYrSGcIORhDeHl2dfw0EMq.iscanceled():
				ZsWnthFi6JzbyGxX = mrhSYXH2P8bO3eJAa9n
				break
	else:
		XM3KUmO1QJxlv84bgFTHsjdNt0kYq = fp6KV7DlS8QYniUczHdmZChL(u"࠰ூ")
		for uWi4nYOj9tBJD1mVXz in wVjeLJoR86yKY0PtSZWqfNHUz42.iter_content(chunk_size=au3SNlPgMzKU4F6CVoAmbxG):
			VV8fleh2QBp1vxkZq.write(uWi4nYOj9tBJD1mVXz)
			XM3KUmO1QJxlv84bgFTHsjdNt0kYq = XM3KUmO1QJxlv84bgFTHsjdNt0kYq+sTGtHVyhQ9cJU37zxo2O(u"࠲௃")
			NHZTEWhbMPzrQwXJ7vj95a = uv8V4fE7j9pmgFr3wnDL.time()
			PzCF9m7tVU51B2uhQHT0YlN3j = NHZTEWhbMPzrQwXJ7vj95a-GhdtAy1o3Ru8z5WvkUFQ6ES
			v9JVj3AwogPXQCxUYyRNOz7E60fm = PzCF9m7tVU51B2uhQHT0YlN3j/XM3KUmO1QJxlv84bgFTHsjdNt0kYq
			Fn0NAVel1fBZTyPzMGLHmvYwqUr = v9JVj3AwogPXQCxUYyRNOz7E60fm*(oXgY1PJ2SjTxN5Uz6+sTGtHVyhQ9cJU37zxo2O(u"࠳௄"))
			II31SeXPWJ47L0NfxhBoOF = Fn0NAVel1fBZTyPzMGLHmvYwqUr-PzCF9m7tVU51B2uhQHT0YlN3j
			mm8riWX1U9q(ukn6WYrSGcIORhDeHl2dfw0EMq,int(czvu7VQCZodkMf(u"࠵࠵࠶ெ")*XM3KUmO1QJxlv84bgFTHsjdNt0kYq/(oXgY1PJ2SjTxN5Uz6+l7kBpMw5Qn(u"࠴௅"))),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ஑"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨஒ"),str(XM3KUmO1QJxlv84bgFTHsjdNt0kYq*au3SNlPgMzKU4F6CVoAmbxG//A4d05PotiJvVZwaWjELn)+uqLUBHepfM3l6AyIzTJh80a(u"ࠩ࠲ࠫஓ")+str(ILuE0g786D9e2YWiNGTm)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨஔ")+uv8V4fE7j9pmgFr3wnDL.strftime(bcNqYtfET5l92dLGjyZSPe(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨக"),uv8V4fE7j9pmgFr3wnDL.gmtime(II31SeXPWJ47L0NfxhBoOF))+vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࠦเࠨ஖"))
			if ukn6WYrSGcIORhDeHl2dfw0EMq.iscanceled():
				ZsWnthFi6JzbyGxX = mrhSYXH2P8bO3eJAa9n
				break
		wVjeLJoR86yKY0PtSZWqfNHUz42.close()
	VV8fleh2QBp1vxkZq.close()
	ukn6WYrSGcIORhDeHl2dfw0EMq.close()
	if not ZsWnthFi6JzbyGxX:
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ஗")+qg7Nr1dCaD+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ஘")+Uw9fdpoCO4NqjTHs1bQzarR0M6+l7kBpMw5Qn(u"ࠨࠢࡠࠫங"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,iDhLkZS6XBagNCQfs9tq2(u"ࠩหัุฮุࠠๆห็ࠥะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪச"))
		return BBX9RAuxnyGZ4WIF2TrhYeom3
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+wPnfgxKZdAv6T10(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ஛")+qg7Nr1dCaD+l7kBpMw5Qn(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫஜ")+Uw9fdpoCO4NqjTHs1bQzarR0M6+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࠦ࡝ࠨ஝"))
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬஞ"))
	return BBX9RAuxnyGZ4WIF2TrhYeom3