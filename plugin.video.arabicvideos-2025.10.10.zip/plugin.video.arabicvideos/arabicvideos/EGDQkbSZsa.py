# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'CIMACLUP'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_CMC_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['موقع نتفليكس']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==490: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==491: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==492: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==493: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==494: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==499: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text,url)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	VK4jU2G3s1PwkticQYyLoW = VK4jU2G3s1PwkticQYyLoW[0].strip('/')
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(VK4jU2G3s1PwkticQYyLoW,'url')
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"filter AjaxifyFilter"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-filter="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/wp-content/themes/old/filter/'+cOn6JqZlmQbjtT+'.php'
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,491)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام',VK4jU2G3s1PwkticQYyLoW+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات',VK4jU2G3s1PwkticQYyLoW+'/category/مسلسلات/مسلسلات-اجنبى',494,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="navigation-menu"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if cOn6JqZlmQbjtT=='/': continue
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
		if title in jgvMWZhtPlBT: continue
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,491)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"filter"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,491)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,z9XqWIL1ZS4amgJK=SebHIf2jL1TBgrMKJu):
	items = []
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	if '.php' in url: drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
	elif '?s=' in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"blocks(.*?)"manifest"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"Blocks(.*?)"manifest"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if not drRnSgoBtKWjmU5FH4ZCIVhzqNb: return
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) حلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not Wj39BaH6oEmstx: Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not Wj39BaH6oEmstx or any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,492,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and 'حلقة' in title:
			title = '_MOD_' + Wj39BaH6oEmstx[0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,493,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,493,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
			if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,491)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('"ButtonsBarCo".*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if qg7Nr1dCaD:
		qg7Nr1dCaD = qg7Nr1dCaD[0]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-EPISODES-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('"img-responsive" src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if tncvzBN0kyrqEHlhIPGSoX4ugA3CDs: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0]
	else: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Thumb')
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"filter"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"Blocks(.*?)class="pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ and '/series/' not in url:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,493,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	elif BRdnHfWTrhFe:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if items:
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
				title = title.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,492,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = cvlHmV1Kr0FIYSjNnM(title)
				title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
				if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,491)
	return
def rRCw3hfy2Kq5l(url):
	qg7Nr1dCaD = url.strip('/')+'/?view=1'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMACLUP-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	vdYW0jGmuUQCMq3no9KRs = X2XorVqHjLkWeCchY4u9fSz.findall("data: 'q=(.*?)&",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	vdYW0jGmuUQCMq3no9KRs = vdYW0jGmuUQCMq3no9KRs[0]
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"serversList"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-server="(.*?)">(.*?)</li>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for bNWgancpjqo2,title in items:
			title = title.strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/wp-content/themes/old/servers/server.php?q='+vdYW0jGmuUQCMq3no9KRs+'&i='+bNWgancpjqo2+'?named='+title+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"embedServer".*?SRC="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if cOn6JqZlmQbjtT:
		title = 'مفضل'
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]+'?named=__embed__'+title
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"downloadsList"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<td>(.*?)</td>.*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,cOn6JqZlmQbjtT in items:
			title = title.strip(qE4nB3mKWHs)
			if 'anavidz' in cOn6JqZlmQbjtT: sABprza7wEOC0Fd3PTQ = '__خاص'
			else: sABprza7wEOC0Fd3PTQ = SebHIf2jL1TBgrMKJu
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'+sABprza7wEOC0Fd3PTQ
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search,VK4jU2G3s1PwkticQYyLoW=SebHIf2jL1TBgrMKJu):
	if not VK4jU2G3s1PwkticQYyLoW: VK4jU2G3s1PwkticQYyLoW = j1IFsik4ouNePZr
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = VK4jU2G3s1PwkticQYyLoW+'/index.php?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return