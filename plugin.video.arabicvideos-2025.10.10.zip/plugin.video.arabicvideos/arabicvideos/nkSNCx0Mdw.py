# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ARBLIONZ'
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_ARL_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==200: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==201: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==202: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==203: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==204: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FILTERS___'+text)
	elif mode==205: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'CATEGORIES___'+text)
	elif mode==209: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,209,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',j1IFsik4ouNePZr,205)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',j1IFsik4ouNePZr,204)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مميزة',j1IFsik4ouNePZr+'??trending',201)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام مميزة',j1IFsik4ouNePZr+'??trending_movies',201)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مميزة',j1IFsik4ouNePZr+'??trending_series',201)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الصفحة الرئيسية',j1IFsik4ouNePZr+'??mainpage',201)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,True,SebHIf2jL1TBgrMKJu,'ARBLIONZ-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('categories-tabs(.*?)MainRow',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-get="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for filter,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/ajax/home/more?filter='+filter
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,201)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('navigation-menu(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
		title = title.strip(qE4nB3mKWHs)
		if not any(value in title for value in jgvMWZhtPlBT):
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,201)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url):
	if '??' in url: url,type = url.split('??')
	else: type = SebHIf2jL1TBgrMKJu
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,True,SebHIf2jL1TBgrMKJu,'ARBLIONZ-TITLES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
	if 'getposts' in url: k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9]
	elif type=='trending':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='trending_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='trending_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='111mainpage':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="container page-content"(.*?)class="tabs"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('page-content(.*?)main-footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BmVW5JQ7kafuTCg9DHZ3 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = X2XorVqHjLkWeCchY4u9fSz.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT,p6aRNk2W0vDYV1C4Ms7xjgiwALIqd,wDrcdftqyO = zip(*items)
		items = zip(p6aRNk2W0vDYV1C4Ms7xjgiwALIqd,uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO)
	aLlVEzy8XR62 = []
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,title in items:
		if '/series/' in cOn6JqZlmQbjtT: continue
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.strip('/')
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.strip(qE4nB3mKWHs)
		if '/film/' in cOn6JqZlmQbjtT or any(value in title for value in BmVW5JQ7kafuTCg9DHZ3):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,202,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/episode/' in cOn6JqZlmQbjtT and 'الحلقة' in title:
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0]
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,203,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
		elif '/pack/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT+'/films',201,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,203,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type in [SebHIf2jL1TBgrMKJu,'mainpage']:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href=["\'](http.*?)["\'].*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				cOn6JqZlmQbjtT = cvlHmV1Kr0FIYSjNnM(cOn6JqZlmQbjtT)
				title = cvlHmV1Kr0FIYSjNnM(title)
				title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
				if 'search?s=' in url:
					KBTdGwWj2rfvPqcukRCVtx = cOn6JqZlmQbjtT.split('page=')[1]
					QQulDOXcqESiG02LT96I1gsB = url.split('page=')[1]
					cOn6JqZlmQbjtT = url.replace('page='+QQulDOXcqESiG02LT96I1gsB,'page='+KBTdGwWj2rfvPqcukRCVtx)
				if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,201)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	TGhkzsgPbMo,items,DF7AOoSqL9jK6Gs8NtZHkUTzrYwd = -1,[],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,True,SebHIf2jL1TBgrMKJu,'ARBLIONZ-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('ti-list-numbered(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		DF7AOoSqL9jK6Gs8NtZHkUTzrYwd = []
		cuoYjfNMPnmhQgtFE = SebHIf2jL1TBgrMKJu.join(k2pC30UArFeg7Ru9tGiZlSmzQ)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',cuoYjfNMPnmhQgtFE,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	items.append(url)
	items = set(items)
	for cOn6JqZlmQbjtT in items:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.strip('/')
		title = '_MOD_' + cOn6JqZlmQbjtT.split('/')[-1].replace('-',qE4nB3mKWHs)
		N6zTbPqn0IFo9 = X2XorVqHjLkWeCchY4u9fSz.findall('الحلقة-(\d+)',cOn6JqZlmQbjtT.split('/')[-1],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if N6zTbPqn0IFo9: N6zTbPqn0IFo9 = N6zTbPqn0IFo9[0]
		else: N6zTbPqn0IFo9 = '0'
		DF7AOoSqL9jK6Gs8NtZHkUTzrYwd.append([cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9])
	items = sorted(DF7AOoSqL9jK6Gs8NtZHkUTzrYwd, reverse=False, key=lambda key: int(key[2]))
	tcJ7YDMGrVHkPu3EeUC5 = str(items).count('/season/')
	TGhkzsgPbMo = str(items).count('/episode/')
	if tcJ7YDMGrVHkPu3EeUC5>1 and TGhkzsgPbMo>0 and '/season/' not in url:
		for cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9 in items:
			if '/season/' in cOn6JqZlmQbjtT:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,203)
	else:
		for cOn6JqZlmQbjtT,title,N6zTbPqn0IFo9 in items:
			if '/season/' not in cOn6JqZlmQbjtT:
				title = kLEi7mYT5wBM4DHsgWy8(title)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,202)
	return
def rRCw3hfy2Kq5l(url):
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	YY9GyjxZl6 = url.split('/')
	rTOz6fQRDJgaidY4Pt = j1IFsik4ouNePZr
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,True,True,'ARBLIONZ-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
	id = X2XorVqHjLkWeCchY4u9fSz.findall('postId:"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not id: id = X2XorVqHjLkWeCchY4u9fSz.findall('post_id=(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not id: id = X2XorVqHjLkWeCchY4u9fSz.findall('post-id="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if id: id = id[0]
	if '/watch/' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		qg7Nr1dCaD = url.replace(YY9GyjxZl6[3],'watch')
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,True,True,'ARBLIONZ-PLAY-2nd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
		HQghJb68Le5Mn9UkKif7srjdS = X2XorVqHjLkWeCchY4u9fSz.findall('data-embedd="(.*?)".*?alt="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('data-embedd=".*?(http.*?)("|&quot;)',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		jBNVO4mlMbhpWKzo6ay723Gnk5tIdA = X2XorVqHjLkWeCchY4u9fSz.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',O3XeD9sgNyH)
		amYdOI85lBn2JiqXpA6 = X2XorVqHjLkWeCchY4u9fSz.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		StMvVDkQX5h860wKZNdmqH = X2XorVqHjLkWeCchY4u9fSz.findall('server="(.*?)".*?<span>(.*?)<',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		items = HQghJb68Le5Mn9UkKif7srjdS+IkJNp71Hyu0PwFAXMTsOc+jBNVO4mlMbhpWKzo6ay723Gnk5tIdA+OB8CxFSIPWGuZtUv6jhH5+amYdOI85lBn2JiqXpA6+StMvVDkQX5h860wKZNdmqH
		if not items:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('<span>(.*?)</span>.*?src="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
			items = [(aapPBMl1evmfxJkw4T0HhX7,TJfF2PRpZyC5cvj) for TJfF2PRpZyC5cvj,aapPBMl1evmfxJkw4T0HhX7 in items]
		for YdzfwOyPb2gxT37B9Dm,title in items:
			if '.png' in YdzfwOyPb2gxT37B9Dm: continue
			if '.jpg' in YdzfwOyPb2gxT37B9Dm: continue
			if '&quot;' in YdzfwOyPb2gxT37B9Dm: continue
			lcbjBn3FdZxC1059A4Kqvi2pugJOa = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if lcbjBn3FdZxC1059A4Kqvi2pugJOa:
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = lcbjBn3FdZxC1059A4Kqvi2pugJOa[0]
				if lcbjBn3FdZxC1059A4Kqvi2pugJOa in title: title = title.replace(lcbjBn3FdZxC1059A4Kqvi2pugJOa+'p',SebHIf2jL1TBgrMKJu).replace(lcbjBn3FdZxC1059A4Kqvi2pugJOa,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			else: lcbjBn3FdZxC1059A4Kqvi2pugJOa = SebHIf2jL1TBgrMKJu
			if YdzfwOyPb2gxT37B9Dm.isdigit():
				cOn6JqZlmQbjtT = rTOz6fQRDJgaidY4Pt+'/?postid='+id+'&serverid='+YdzfwOyPb2gxT37B9Dm+'?named='+title+'__watch'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			else:
				if 'http' not in YdzfwOyPb2gxT37B9Dm: YdzfwOyPb2gxT37B9Dm = 'http:'+YdzfwOyPb2gxT37B9Dm
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if lcbjBn3FdZxC1059A4Kqvi2pugJOa: lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa[0]
				else: lcbjBn3FdZxC1059A4Kqvi2pugJOa = SebHIf2jL1TBgrMKJu
				cOn6JqZlmQbjtT = YdzfwOyPb2gxT37B9Dm+'?named=__watch'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	if 'DownloadNow' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		REIkboX9NtlZCSU3A = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		qg7Nr1dCaD = url+'/download'
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,True,SebHIf2jL1TBgrMKJu,'ARBLIONZ-PLAY-3rd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<ul class="download-items(.*?)</ul>',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,name,lcbjBn3FdZxC1059A4Kqvi2pugJOa in items:
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__download'+'____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
				bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	elif '/download/' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		REIkboX9NtlZCSU3A = { 'User-Agent':SebHIf2jL1TBgrMKJu , 'X-Requested-With':'XMLHttpRequest' }
		qg7Nr1dCaD = rTOz6fQRDJgaidY4Pt + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,True,True,'ARBLIONZ-PLAY-4th')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
		if 'download-btns' in O3XeD9sgNyH:
			jBNVO4mlMbhpWKzo6ay723Gnk5tIdA = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for iGxH2fsuScPtkJb7ECg in jBNVO4mlMbhpWKzo6ay723Gnk5tIdA:
				if '/page/' not in iGxH2fsuScPtkJb7ECg and 'http' in iGxH2fsuScPtkJb7ECg:
					iGxH2fsuScPtkJb7ECg = iGxH2fsuScPtkJb7ECg+'?named=__download'
					bQGVWFxKS4D6p9YC7XPyA8Os.append(iGxH2fsuScPtkJb7ECg)
				elif '/page/' in iGxH2fsuScPtkJb7ECg:
					lcbjBn3FdZxC1059A4Kqvi2pugJOa = SebHIf2jL1TBgrMKJu
					Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',iGxH2fsuScPtkJb7ECg,SebHIf2jL1TBgrMKJu,headers,True,True,'ARBLIONZ-PLAY-5th')
					Sw85trvyzV9XGAoHCsK2eYDF = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
					cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('(<strong>.*?)-----',Sw85trvyzV9XGAoHCsK2eYDF,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for x4g9crK67hA1mGNHiPazFOUsCMY3l in cuoYjfNMPnmhQgtFE:
						z9zLvHh6OZFJp3KWgeVx0Catr8 = SebHIf2jL1TBgrMKJu
						OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('<strong>(.*?)</strong>',x4g9crK67hA1mGNHiPazFOUsCMY3l,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						for naFEhtX1g3iL in OB8CxFSIPWGuZtUv6jhH5:
							JJSOAkTZIib4eswDo51pFuqvK = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',naFEhtX1g3iL,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
							if JJSOAkTZIib4eswDo51pFuqvK:
								lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+JJSOAkTZIib4eswDo51pFuqvK[0]
								break
						for naFEhtX1g3iL in reversed(OB8CxFSIPWGuZtUv6jhH5):
							JJSOAkTZIib4eswDo51pFuqvK = X2XorVqHjLkWeCchY4u9fSz.findall('\w\w+',naFEhtX1g3iL,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
							if JJSOAkTZIib4eswDo51pFuqvK:
								z9zLvHh6OZFJp3KWgeVx0Catr8 = JJSOAkTZIib4eswDo51pFuqvK[0]
								break
						amYdOI85lBn2JiqXpA6 = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',x4g9crK67hA1mGNHiPazFOUsCMY3l,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						for VV8rutp4on in amYdOI85lBn2JiqXpA6:
							VV8rutp4on = VV8rutp4on+'?named='+z9zLvHh6OZFJp3KWgeVx0Catr8+'__download'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
							bQGVWFxKS4D6p9YC7XPyA8Os.append(VV8rutp4on)
		elif 'slow-motion' in O3XeD9sgNyH:
			O3XeD9sgNyH = O3XeD9sgNyH.replace('<h6 ','==END== ==START==')+'==END=='
			O3XeD9sgNyH = O3XeD9sgNyH.replace('<h3 ','==END== ==START==')+'==END=='
			KDSFx56ugn3 = X2XorVqHjLkWeCchY4u9fSz.findall('==START==(.*?)==END==',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if KDSFx56ugn3:
				for x4g9crK67hA1mGNHiPazFOUsCMY3l in KDSFx56ugn3:
					if 'href=' not in x4g9crK67hA1mGNHiPazFOUsCMY3l: continue
					C7E8gRQMe4jAUDdW26zYuf = SebHIf2jL1TBgrMKJu
					OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('slow-motion">(.*?)<',x4g9crK67hA1mGNHiPazFOUsCMY3l,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for naFEhtX1g3iL in OB8CxFSIPWGuZtUv6jhH5:
						JJSOAkTZIib4eswDo51pFuqvK = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',naFEhtX1g3iL,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						if JJSOAkTZIib4eswDo51pFuqvK:
							C7E8gRQMe4jAUDdW26zYuf = '____'+JJSOAkTZIib4eswDo51pFuqvK[0]
							break
					OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('<td>(.*?)</td>.*?href="(http.*?)"',x4g9crK67hA1mGNHiPazFOUsCMY3l,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					if OB8CxFSIPWGuZtUv6jhH5:
						for z9zLvHh6OZFJp3KWgeVx0Catr8,XL2OzmN6r1A5Vh893pnKMy470xQei in OB8CxFSIPWGuZtUv6jhH5:
							XL2OzmN6r1A5Vh893pnKMy470xQei = XL2OzmN6r1A5Vh893pnKMy470xQei+'?named='+z9zLvHh6OZFJp3KWgeVx0Catr8+'__download'+C7E8gRQMe4jAUDdW26zYuf
							bQGVWFxKS4D6p9YC7XPyA8Os.append(XL2OzmN6r1A5Vh893pnKMy470xQei)
					else:
						OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?http.*?)".*?name">(.*?)<',x4g9crK67hA1mGNHiPazFOUsCMY3l,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						for XL2OzmN6r1A5Vh893pnKMy470xQei,z9zLvHh6OZFJp3KWgeVx0Catr8 in OB8CxFSIPWGuZtUv6jhH5:
							XL2OzmN6r1A5Vh893pnKMy470xQei = XL2OzmN6r1A5Vh893pnKMy470xQei.strip(qE4nB3mKWHs)+'?named='+z9zLvHh6OZFJp3KWgeVx0Catr8+'__download'+C7E8gRQMe4jAUDdW26zYuf
							bQGVWFxKS4D6p9YC7XPyA8Os.append(XL2OzmN6r1A5Vh893pnKMy470xQei)
			else:
				OB8CxFSIPWGuZtUv6jhH5 = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(\w+)<',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for XL2OzmN6r1A5Vh893pnKMy470xQei,z9zLvHh6OZFJp3KWgeVx0Catr8 in OB8CxFSIPWGuZtUv6jhH5:
					XL2OzmN6r1A5Vh893pnKMy470xQei = XL2OzmN6r1A5Vh893pnKMy470xQei.strip(qE4nB3mKWHs)+'?named='+z9zLvHh6OZFJp3KWgeVx0Catr8+'__download'
					bQGVWFxKS4D6p9YC7XPyA8Os.append(XL2OzmN6r1A5Vh893pnKMy470xQei)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/alz',SebHIf2jL1TBgrMKJu,headers,True,SebHIf2jL1TBgrMKJu,'ARBLIONZ-SEARCH-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content.encode(Tv08xsf9HOqunIVUPdK1)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('chevron-select(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if showDialogs and k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		haM0jZUfqQGykrsJcO1,mYQN0fqEDbCUz18wKchdu76oieOxn = [],[]
		for kgy9Zm5TCvYHjE3PVQ,title in items:
			haM0jZUfqQGykrsJcO1.append(kgy9Zm5TCvYHjE3PVQ)
			mYQN0fqEDbCUz18wKchdu76oieOxn.append(title)
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر الفلتر المناسب:', mYQN0fqEDbCUz18wKchdu76oieOxn)
		if QQea1XbjZDEMhp == -1 : return
		kgy9Zm5TCvYHjE3PVQ = haM0jZUfqQGykrsJcO1[QQea1XbjZDEMhp]
	else: kgy9Zm5TCvYHjE3PVQ = SebHIf2jL1TBgrMKJu
	url = j1IFsik4ouNePZr + '/search?s='+search+'&category='+kgy9Zm5TCvYHjE3PVQ+'&page=1'
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def vimwpBGoVK3EZrUkjPL(url,filter):
	PD0JksfFrlMUtG6OWVLgdiY8o5b = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='CATEGORIES':
		if PD0JksfFrlMUtG6OWVLgdiY8o5b[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[0]
		for YHnALfql8hprDu in range(len(PD0JksfFrlMUtG6OWVLgdiY8o5b[0:-1])):
			if PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'/getposts?'+LnwzHFAVsfO2Go
	elif type=='FILTERS':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'/getposts?'+wk0AjSOpcRB
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',qg7Nr1dCaD,201)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',qg7Nr1dCaD,201)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url+'/alz',SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'ARBLIONZ-FILTERS_MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('AjaxFilteringData(.*?)FilterWord',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	dict = {}
	for name,oIi8QaPyZBr1mvUcsh,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		name = name.replace('اختيار ',SebHIf2jL1TBgrMKJu)
		name = name.replace('سنة الإنتاج','السنة')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('value="(.*?)".*?</div>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='CATEGORIES':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<=1:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'CATEGORIES___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع ',qg7Nr1dCaD,201)
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع ',qg7Nr1dCaD,205,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FILTERS':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع :'+name,qg7Nr1dCaD,204,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			OSEMFXaUVI1eqHhQYmbKPdJAnrk = OSEMFXaUVI1eqHhQYmbKPdJAnrk.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu)
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'+name
			if type=='FILTERS': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,204,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='CATEGORIES' and PD0JksfFrlMUtG6OWVLgdiY8o5b[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				iGxH2fsuScPtkJb7ECg = url+'/getposts?'+LnwzHFAVsfO2Go
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,201)
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,205,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.replace('=&','=0&')
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	CIHKiYt9osw4SyjMfhP0rZ8 = ['category','release-year','genre','Quality']
	for key in CIHKiYt9osw4SyjMfhP0rZ8:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('=0','=')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('Quality','quality')
	return hIyBYfuc8oTsEZ