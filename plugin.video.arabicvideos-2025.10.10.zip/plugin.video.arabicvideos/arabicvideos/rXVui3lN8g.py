# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SHABAKATY'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SHB_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['الصفحة الرئيسية','Sign in','تسجيل']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==960: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==961: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==962: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==963: lfZmugQCFKLGT05AH29IsMiho = JZvYADs6nb0zV4WU7RM1So8X5dIp(url,text)
	elif mode==964: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==969: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,969,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"navslide-wrap"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,964)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('/category.php">(.*?)"navslide-divider"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("'dropdown-menu'(.*?)</ul>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for Q4idDwN25EKRJCajSyc in k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace(Q4idDwN25EKRJCajSyc,SebHIf2jL1TBgrMKJu)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			if title=='جديد الأفلام': title = 'المضاف حديثا'
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,964)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"menu-category"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,961)
	return
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"caret"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('"presentation"','</ul>')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = [(SebHIf2jL1TBgrMKJu,drRnSgoBtKWjmU5FH4ZCIVhzqNb)]
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' فرز أو فلتر أو ترتيب '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		for bCsfqPwXyzihR1nm,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if bCsfqPwXyzihR1nm: bCsfqPwXyzihR1nm = bCsfqPwXyzihR1nm+': '
			for cOn6JqZlmQbjtT,title in items:
				title = bCsfqPwXyzihR1nm+title
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,961)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-category-subcats"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(items)<30:
			QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
			for cOn6JqZlmQbjtT,title in items:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,961)
	if not Eky7GUxAVIQMn3ip0DOHrSYJ and not BRdnHfWTrhFe: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,pbmcw9i1kfuNIQzJ7aGd3l0=SebHIf2jL1TBgrMKJu):
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-TITLES-1st')
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-TITLES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	drRnSgoBtKWjmU5FH4ZCIVhzqNb,items = SebHIf2jL1TBgrMKJu,[]
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc: items.append((SebHIf2jL1TBgrMKJu,cOn6JqZlmQbjtT,title))
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-carousel_featured"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(k2pC30UArFeg7Ru9tGiZlSmzQ)>1: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[1]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"video-grid"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if drRnSgoBtKWjmU5FH4ZCIVhzqNb and not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('"thumb".*?<a href="(.*?)".*?alt="(.*?)" data-src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: return
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
		title = cvlHmV1Kr0FIYSjNnM(title)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,962,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,962,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx:
			title = '_MOD_' + Wj39BaH6oEmstx[0][0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,963,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,963,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if 1:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("'pagination'(.*?)</div>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT=='#': continue
				title = cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,961)
	return
def JZvYADs6nb0zV4WU7RM1So8X5dIp(url,yZfHYbEdxgemqNFoL8OSrR):
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-EPISODES_SEASONS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Thumb')
	items = []
	N3zkg2cZqIHShYXdUMfCl5aDQ = False
	if 0 and Eky7GUxAVIQMn3ip0DOHrSYJ and not yZfHYbEdxgemqNFoL8OSrR:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for yZfHYbEdxgemqNFoL8OSrR,title in items:
			yZfHYbEdxgemqNFoL8OSrR = yZfHYbEdxgemqNFoL8OSrR.strip('#')
			if len(items)>1: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,963,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,yZfHYbEdxgemqNFoL8OSrR)
			else: N3zkg2cZqIHShYXdUMfCl5aDQ = True
	else: N3zkg2cZqIHShYXdUMfCl5aDQ = True
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"eplist"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe and N3zkg2cZqIHShYXdUMfCl5aDQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('''href=["'](.*?)["'].*?title=['"](.*?)['"]''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace('</em><span>',qE4nB3mKWHs)
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,962,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK,ff281j5nDJ0iK = [],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'post_id:' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		vdYW0jGmuUQCMq3no9KRs = X2XorVqHjLkWeCchY4u9fSz.findall('post_id:(\d+)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		miVEOrhJQgv5LG7ajR0pnt = j1IFsik4ouNePZr+'/wp-admin/admin-ajax.php?action=video_info&post_id='+vdYW0jGmuUQCMq3no9KRs[0]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',miVEOrhJQgv5LG7ajR0pnt,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-PLAY-2nd')
		O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('"src":"(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('\/','/')
			if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
				ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
				YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch'
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	elif 'post_id:' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('id="player".*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
		BHvXNYSAsJ0dLy4MCw3ilODxIrGtT = cOn6JqZlmQbjtT.split('post=')[1]
		BHvXNYSAsJ0dLy4MCw3ilODxIrGtT = ej3oxQLc68OIY.b64decode(BHvXNYSAsJ0dLy4MCw3ilODxIrGtT)
		if QBOMjKifEAFD: BHvXNYSAsJ0dLy4MCw3ilODxIrGtT = BHvXNYSAsJ0dLy4MCw3ilODxIrGtT.decode(Tv08xsf9HOqunIVUPdK1)
		BHvXNYSAsJ0dLy4MCw3ilODxIrGtT = xjVJ0o7mF86tCDagkbNcrTAR4UH('dict',BHvXNYSAsJ0dLy4MCw3ilODxIrGtT)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = BHvXNYSAsJ0dLy4MCw3ilODxIrGtT['servers']
		wDrcdftqyO = list(uLdRirAZJKoSgPqNUjm84WXE5cn3aT.keys())
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = list(uLdRirAZJKoSgPqNUjm84WXE5cn3aT.values())
		eUuRqsfnW8y2BS5cCG4ZhgODJj = zip(wDrcdftqyO,uLdRirAZJKoSgPqNUjm84WXE5cn3aT)
		for title,cOn6JqZlmQbjtT in eUuRqsfnW8y2BS5cCG4ZhgODJj:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	else:
		qg7Nr1dCaD = url.replace('watch.php','play.php')
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHABAKATY-PLAY-3rd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('"embedURL" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if 0 and cOn6JqZlmQbjtT:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
			if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
				ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
				YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__embed'
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-servers"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('embed-url="(.*?)".*?<strong>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
					ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
					YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch'
					qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
		if 'pm-download' not in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			qg7Nr1dCaD = url.replace('watch.php','downloads.php')
			Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,False,'SHABAKATY-PLAY-4th')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pm-download(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<strong>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT not in ff281j5nDJ0iK:
					ff281j5nDJ0iK.append(cOn6JqZlmQbjtT)
					YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__download'
					qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return