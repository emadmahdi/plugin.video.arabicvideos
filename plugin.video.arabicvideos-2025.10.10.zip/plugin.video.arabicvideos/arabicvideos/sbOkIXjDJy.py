# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'EGYBESTVIP'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_EGV_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,Q8A5HyT1fGNxZv4X3V7eC,text):
	if   mode==220: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==221: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==222: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==223: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==224: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url)
	elif mode==229: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,229,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="i i-home"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,222)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="ba(.*?)<script',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,cOn6JqZlmQbjtT in items:
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,221)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if 'html' not in cOn6JqZlmQbjtT: continue
			if not cOn6JqZlmQbjtT.endswith('/'): QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,221)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def xwWavftjMBT0nJDsuz2g(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="rs_scroll"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,224)
	return
def vimwpBGoVK3EZrUkjPL(url):
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',url,221)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-FILTERS_MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="sub_nav(.*?)id="movies',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".+?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if cOn6JqZlmQbjtT=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,221)
	else: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC='1'):
	if Q8A5HyT1fGNxZv4X3V7eC==SebHIf2jL1TBgrMKJu: Q8A5HyT1fGNxZv4X3V7eC = '1'
	if '/search' in url or '?' in url: qg7Nr1dCaD = url + '&'
	else: qg7Nr1dCaD = url + '?'
	qg7Nr1dCaD = qg7Nr1dCaD + 'page=' + Q8A5HyT1fGNxZv4X3V7eC
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('class="pda"(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[-1]
	elif '/series/' in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('class="owl-carousel owl-carousel(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('id="movies(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[-1]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		if '/movie/' in cOn6JqZlmQbjtT or '/episode' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT.rstrip('/'),223,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,221,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if len(items)>=16:
		xlczft35Fj = ['/movies','/tv','/search','/trending']
		Q8A5HyT1fGNxZv4X3V7eC = int(Q8A5HyT1fGNxZv4X3V7eC)
		if any(value in url for value in xlczft35Fj):
			for zuZRBycj38NmlOv2F in range(0,1000,100):
				if int(Q8A5HyT1fGNxZv4X3V7eC/100)*100==zuZRBycj38NmlOv2F:
					for YHnALfql8hprDu in range(zuZRBycj38NmlOv2F,zuZRBycj38NmlOv2F+100,10):
						if int(Q8A5HyT1fGNxZv4X3V7eC/10)*10==YHnALfql8hprDu:
							for SV13WDT8kwsRMbQ9FvYPG in range(YHnALfql8hprDu,YHnALfql8hprDu+10,1):
								if not Q8A5HyT1fGNxZv4X3V7eC==SV13WDT8kwsRMbQ9FvYPG and SV13WDT8kwsRMbQ9FvYPG!=0:
									QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+str(SV13WDT8kwsRMbQ9FvYPG),url,221,SebHIf2jL1TBgrMKJu,str(SV13WDT8kwsRMbQ9FvYPG))
						elif YHnALfql8hprDu!=0: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+str(YHnALfql8hprDu),url,221,SebHIf2jL1TBgrMKJu,str(YHnALfql8hprDu))
						else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+str(1),url,221,SebHIf2jL1TBgrMKJu,str(1))
				elif zuZRBycj38NmlOv2F!=0: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+str(zuZRBycj38NmlOv2F),url,221,SebHIf2jL1TBgrMKJu,str(zuZRBycj38NmlOv2F))
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+str(1),url,221)
	return
def rRCw3hfy2Kq5l(url):
	HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = [],[]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-PLAY-1st')
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('<td>التصنيف</td>.*?">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	gY8EUCBP1Ic0pdbi4uDmL,hlrEy6z0WDIajAiJ9tPGuUs = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	HJ7r9tpvc2P3,B1yiJVSkvzxICRwt = LCK8lO2yRWaTVEQcdjPXAzpFBe9,LCK8lO2yRWaTVEQcdjPXAzpFBe9
	U9Gu85cN76CREW2zyQq = X2XorVqHjLkWeCchY4u9fSz.findall('show_dl api" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if U9Gu85cN76CREW2zyQq:
		for cOn6JqZlmQbjtT in U9Gu85cN76CREW2zyQq:
			if '/watch/' in cOn6JqZlmQbjtT: gY8EUCBP1Ic0pdbi4uDmL = cOn6JqZlmQbjtT
			elif '/download/' in cOn6JqZlmQbjtT: hlrEy6z0WDIajAiJ9tPGuUs = cOn6JqZlmQbjtT
		if gY8EUCBP1Ic0pdbi4uDmL!=SebHIf2jL1TBgrMKJu: HJ7r9tpvc2P3 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,gY8EUCBP1Ic0pdbi4uDmL,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-PLAY-2nd')
		if hlrEy6z0WDIajAiJ9tPGuUs!=SebHIf2jL1TBgrMKJu: B1yiJVSkvzxICRwt = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,hlrEy6z0WDIajAiJ9tPGuUs,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-PLAY-3rd')
	JByVLQNFbxAtw1hUmITMR9aZPC4 = X2XorVqHjLkWeCchY4u9fSz.findall('id="video".*?data-src="(.*?)"',HJ7r9tpvc2P3,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if JByVLQNFbxAtw1hUmITMR9aZPC4:
		qg7Nr1dCaD = JByVLQNFbxAtw1hUmITMR9aZPC4[0]
		if qg7Nr1dCaD!=SebHIf2jL1TBgrMKJu and 'uploaded.egybest.download' in qg7Nr1dCaD and '/?id=_' not in qg7Nr1dCaD:
			O3XeD9sgNyH = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-PLAY-4th')
			H3eVK10lY8mt = X2XorVqHjLkWeCchY4u9fSz.findall('source src="(.*?)" title="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if H3eVK10lY8mt:
				for cOn6JqZlmQbjtT,lcbjBn3FdZxC1059A4Kqvi2pugJOa in H3eVK10lY8mt:
					bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT+'?named=ed.egybest.do__watch__mp4__'+lcbjBn3FdZxC1059A4Kqvi2pugJOa)
			else:
				YdzfwOyPb2gxT37B9Dm = qg7Nr1dCaD.split('/')[2]
				bQGVWFxKS4D6p9YC7XPyA8Os.append(qg7Nr1dCaD+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch')
		elif qg7Nr1dCaD!=SebHIf2jL1TBgrMKJu:
			YdzfwOyPb2gxT37B9Dm = qg7Nr1dCaD.split('/')[2]
			bQGVWFxKS4D6p9YC7XPyA8Os.append(qg7Nr1dCaD+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch')
	imft4zUhGTybnZ = X2XorVqHjLkWeCchY4u9fSz.findall('<table class="dls_table(.*?)</table>',B1yiJVSkvzxICRwt,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if imft4zUhGTybnZ:
		imft4zUhGTybnZ = imft4zUhGTybnZ[0]
		Xx0Jp6cQ7DyGugWY4bti = X2XorVqHjLkWeCchY4u9fSz.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',imft4zUhGTybnZ,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if Xx0Jp6cQ7DyGugWY4bti:
			for lcbjBn3FdZxC1059A4Kqvi2pugJOa,cOn6JqZlmQbjtT in Xx0Jp6cQ7DyGugWY4bti:
				if 'myegyvip' not in cOn6JqZlmQbjtT: continue
				if cOn6JqZlmQbjtT.count('/')>=2:
					YdzfwOyPb2gxT37B9Dm = cOn6JqZlmQbjtT.split('/')[2]
					bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__download__mp4__'+lcbjBn3FdZxC1059A4Kqvi2pugJOa)
	NNR4sgnwr2H = []
	for cOn6JqZlmQbjtT in bQGVWFxKS4D6p9YC7XPyA8Os:
		NNR4sgnwr2H.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(NNR4sgnwr2H,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'+')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBESTVIP-SEARCH-1st')
	pHtWj513aey2KLi097S84rxqzUJNPs = X2XorVqHjLkWeCchY4u9fSz.findall('name="_token" value="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if pHtWj513aey2KLi097S84rxqzUJNPs:
		url = j1IFsik4ouNePZr+'/search?_token='+pHtWj513aey2KLi097S84rxqzUJNPs[0]+'&q='+t2WLY7DxIZs
		yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return