# -*- coding: utf-8 -*-
from RSdDifzoPG import *
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
tfX4sO3hy2H1IbKG = 'PANET'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_PNT_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
def WdRmv9kTtLnfZ24(mode,url,Q8A5HyT1fGNxZv4X3V7eC,text):
	if   mode==30: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==31: lfZmugQCFKLGT05AH29IsMiho = dUIVBjNyP31C(url,'3')
	elif mode==32: lfZmugQCFKLGT05AH29IsMiho = JJeq4MVI8NtCWkaOiQLTybrzUx(url)
	elif mode==33: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==35: lfZmugQCFKLGT05AH29IsMiho = dUIVBjNyP31C(url,'1')
	elif mode==36: lfZmugQCFKLGT05AH29IsMiho = dUIVBjNyP31C(url,'2')
	elif mode==37: lfZmugQCFKLGT05AH29IsMiho = dUIVBjNyP31C(url,'4')
	elif mode==38: lfZmugQCFKLGT05AH29IsMiho = PZbvLVAspF6rS1xhkm8W()
	elif mode==39: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text,Q8A5HyT1fGNxZv4X3V7eC)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('live',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قناة هلا من موقع بانيت',SebHIf2jL1TBgrMKJu,38)
	return SebHIf2jL1TBgrMKJu
def dUIVBjNyP31C(url,select=SebHIf2jL1TBgrMKJu):
	type = url.split('/')[3]
	if type=='mosalsalat':
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'PANET-CATEGORIES-1st')
		if select=='3':
			k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('categoriesMenu(.*?)seriesForm',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb= k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items=X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,name in items:
				if 'كليبات مضحكة' in name: continue
				url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
				name = name.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,32)
		if select=='4':
			k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('video-details-panel(.*?)v></a></div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb= k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items=X2XorVqHjLkWeCchY4u9fSz.findall('panet-thumbnail" href="(.*?)".*?src="(.*?)".*?panet-info">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
				url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
				title = title.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,32,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type=='movies':
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'PANET-CATEGORIES-2nd')
		if select=='1':
			k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('moviesGender(.*?)select',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items=X2XorVqHjLkWeCchY4u9fSz.findall('option><option value="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for value,name in items:
				url = j1IFsik4ouNePZr + '/movies/genre/' + value
				name = name.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,32)
		elif select=='2':
			k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('moviesActor(.*?)select',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items=X2XorVqHjLkWeCchY4u9fSz.findall('option><option value="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for value,name in items:
				name = name.strip(qE4nB3mKWHs)
				url = j1IFsik4ouNePZr + '/movies/actor/' + value
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,32)
	return
def JJeq4MVI8NtCWkaOiQLTybrzUx(url):
	type = url.split('/')[3]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'PANET-ITEMS-1st')
	if 'home' in url: type='episodes'
	if type=='mosalsalat':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('panet-thumbnails(.*?)panet-pagination',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)""><img src="(.*?)".*?h2>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,name in items:
				url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
				name = name.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,32,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type=='movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('advBarMars(.+?)panet-pagination',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('panet-thumbnail.*?href="(.*?)"><img src="(.*?)" alt="(.+?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,name in items:
			name = name.strip(qE4nB3mKWHs)
			url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,33,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type=='episodes':
		Q8A5HyT1fGNxZv4X3V7eC = url.split('/')[-1]
		if Q8A5HyT1fGNxZv4X3V7eC=='1':
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('advBarMars(.+?)advBarMars',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('panet-thumbnail.*?href="(.*?)"><img src="(.*?)".*?panet-title">(.*?)</div.*?panet-info">(.*?)</div',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			count = 0
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,Wj39BaH6oEmstx,title in items:
				count += 1
				if count==10: break
				name = title + ' - ' + Wj39BaH6oEmstx
				url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,33,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('advBarMars.*?advBarMars(.+?)panet-pagination',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('panet-thumbnail.*?href="(.*?)""><img src="(.*?)".*?panet-title"><h2>(.*?)</h2.*?panet-info"><h2>(.*?)</h2',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,Wj39BaH6oEmstx in items:
			Wj39BaH6oEmstx = Wj39BaH6oEmstx.strip(qE4nB3mKWHs)
			title = title.strip(qE4nB3mKWHs)
			name = title + ' - ' + Wj39BaH6oEmstx
			url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,33,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('glyphicon-chevron-right(.+?)data-revive-zoneid="4"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,Q8A5HyT1fGNxZv4X3V7eC in items:
		url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
		name = 'صفحة ' + Q8A5HyT1fGNxZv4X3V7eC
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+name,url,32)
	return
def rRCw3hfy2Kq5l(url):
	if 'mosalsalat' in url:
		url = j1IFsik4ouNePZr + '/mosalsalat/v1/seriesLink/' + url.split('/')[-1]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'PANET-PLAY-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		items = X2XorVqHjLkWeCchY4u9fSz.findall('url":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		url = items[0]
		url = url.replace('\/','/')
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'PANET-PLAY-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		items = X2XorVqHjLkWeCchY4u9fSz.findall('contentURL" content="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		url = items[0]
	nxW9asAySzOt2foFGT4LwmHNl8uZ(url,tfX4sO3hy2H1IbKG,'video')
	return
def yEPLitfHnvAdz0I9SVoC(search,Q8A5HyT1fGNxZv4X3V7eC=SebHIf2jL1TBgrMKJu):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'%20')
	yoqiDxh3sAnwJ1FI90Gk4Hvuf = ['movies','series']
	if not Q8A5HyT1fGNxZv4X3V7eC: Q8A5HyT1fGNxZv4X3V7eC = '1'
	else: Q8A5HyT1fGNxZv4X3V7eC,type = Q8A5HyT1fGNxZv4X3V7eC.split('/')
	if showDialogs:
		JFsnEmbRzSf8aVy5GZ9k = [ 'بحث عن افلام' , 'بحث عن مسلسلات']
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('موقع بانيت - اختر البحث', JFsnEmbRzSf8aVy5GZ9k)
		if QQea1XbjZDEMhp == -1 : return
		type = yoqiDxh3sAnwJ1FI90Gk4Hvuf[QQea1XbjZDEMhp]
	else:
		if '_PANET-MOVIES_' in ndiZQ7oLFkV1W: type = 'movies'
		elif '_PANET-SERIES_' in ndiZQ7oLFkV1W: type = 'series'
		else: return
	headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
	data = {'query':t2WLY7DxIZs , 'searchDomain':type}
	if Q8A5HyT1fGNxZv4X3V7eC!='1': data['from'] = Q8A5HyT1fGNxZv4X3V7eC
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',j1IFsik4ouNePZr+'/search',data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'PANET-SEARCH-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items=X2XorVqHjLkWeCchY4u9fSz.findall('title":"(.*?)".*?link":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		for title,cOn6JqZlmQbjtT in items:
			url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT.replace('\/','/')
			if '/movies/' in url: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فيلم '+title,url,33)
			elif '/series/' in url:
				url = url.replace('/series/','/mosalsalat/')
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسل '+title,url+'/1',32)
	count=X2XorVqHjLkWeCchY4u9fSz.findall('"total":(.*?)}',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if count:
		eaklSdVyqFvZ = int(  (int(count[0])+9)   /10 )+1
		for gH3ueoxVGv8DhOW in range(1,eaklSdVyqFvZ):
			gH3ueoxVGv8DhOW = str(gH3ueoxVGv8DhOW)
			if gH3ueoxVGv8DhOW!=Q8A5HyT1fGNxZv4X3V7eC:
				QUzFYoapm9jx('folder','صفحة '+gH3ueoxVGv8DhOW,SebHIf2jL1TBgrMKJu,39,SebHIf2jL1TBgrMKJu,gH3ueoxVGv8DhOW+'/'+type,search)
	return
def PZbvLVAspF6rS1xhkm8W():
	cOn6JqZlmQbjtT = 'aHR0cDovL2dzdHJlYW00LnBhbmV0LmNvLmlsL2VkZ2VfYWJyL2hhbGFUVi9wbGF5bGlzdC5tM3U4'
	cOn6JqZlmQbjtT = ej3oxQLc68OIY.b64decode(cOn6JqZlmQbjtT)
	cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.decode(Tv08xsf9HOqunIVUPdK1)
	nxW9asAySzOt2foFGT4LwmHNl8uZ(cOn6JqZlmQbjtT,tfX4sO3hy2H1IbKG,'live')
	return