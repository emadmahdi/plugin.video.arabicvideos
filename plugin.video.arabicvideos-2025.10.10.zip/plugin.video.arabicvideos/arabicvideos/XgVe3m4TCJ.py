# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'HALACIMA'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_HLC_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==80: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==81: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==82: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==83: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==89: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'HALACIMA-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(j1IFsik4ouNePZr,'url')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,89,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-content(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-name="(.*?)".*?</i>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for z9XqWIL1ZS4amgJK,title in items:
		cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/ajax/getItem?item='+z9XqWIL1ZS4amgJK+'&Ajax=1'
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,81)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"nav-main"(.*?)</nav>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if cOn6JqZlmQbjtT=='#': continue
		if title in jgvMWZhtPlBT: continue
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,81)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,z9XqWIL1ZS4amgJK=SebHIf2jL1TBgrMKJu):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		qg7Nr1dCaD,bIGXajdcK6PQBs = lhC3Axj8TQSsRWeu0k(url)
		REIkboX9NtlZCSU3A = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',qg7Nr1dCaD,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'HALACIMA-TITLES-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9]
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'HALACIMA-TITLES-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		if z9XqWIL1ZS4amgJK=='featured':
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"container"(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		elif '"section-post mb-10"' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"section-post mb-10"(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		else:
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<article(.*?)"pagination"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not k2pC30UArFeg7Ru9tGiZlSmzQ: return
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if not items:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT).strip('/')
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '/series/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,83,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif 'سلاسل' not in url and any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,82,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and 'الحلقة' in title:
			title = '_MOD_' + Wj39BaH6oEmstx[0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,83,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/movies/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,81,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,83,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if z9XqWIL1ZS4amgJK==SebHIf2jL1TBgrMKJu:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)<footer',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT=="": continue
				if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'هناك المزيد',url,81)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'HALACIMA-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"getSeasonsBySeries(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"list-episodes"(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ and '/series/' not in url:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,83,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	elif BRdnHfWTrhFe:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('"image" src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,82,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qg7Nr1dCaD = url.replace('/movies/','/watch_movies/')
	qg7Nr1dCaD = qg7Nr1dCaD.replace('/episodes/','/watch_episodes/')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'HALACIMA-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qg7Nr1dCaD,'url')
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"servers"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		B8vJbFtznDGZ6ASw0V2 = X2XorVqHjLkWeCchY4u9fSz.findall('postID = "(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		B8vJbFtznDGZ6ASw0V2 = B8vJbFtznDGZ6ASw0V2[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for YdzfwOyPb2gxT37B9Dm,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/ajax/getPlayer?server='+YdzfwOyPb2gxT37B9Dm+'&postID='+B8vJbFtznDGZ6ASw0V2+'&Ajax=1'
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"downs"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__download'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'-')
	url = j1IFsik4ouNePZr+'/search/'+search+'.html'
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return