# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'ARABSEED'
headers = {'User-Agent':b6rmBauMc3HqTev0t()}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_ARS_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==250: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==251: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==252: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==253: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==254: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'CATEGORIES___'+text)
	elif mode==255: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'FILTERS___'+text)
	elif mode==256: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url,text)
	elif mode==259: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/main',SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,259,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',j1IFsik4ouNePZr+'/category/اخرى',254)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',j1IFsik4ouNePZr+'/category/اخرى',255)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',j1IFsik4ouNePZr+'/main',251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured_main')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جديد الأفلام',j1IFsik4ouNePZr+'/main',251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'new_movies')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'جديد الحلقات',j1IFsik4ouNePZr+'/main',251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'new_episodes')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المضاف حديثاً',j1IFsik4ouNePZr+'/latest',251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'lastest')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"menu__bar hide__md"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	Q4idDwN25EKRJCajSyc = BRdnHfWTrhFe[wvkDqmNZlJU52isXo]
	IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)<',Q4idDwN25EKRJCajSyc,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc:
		if '/category/' not in cOn6JqZlmQbjtT: continue
		title = cvlHmV1Kr0FIYSjNnM(title)
		if title not in jgvMWZhtPlBT and title!=SebHIf2jL1TBgrMKJu:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,251)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def xwWavftjMBT0nJDsuz2g(url,type):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'class="SliderInSection' in LCK8lO2yRWaTVEQcdjPXAzpFBe9: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الأكثر مشاهدة',url,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'most')
	if 'class="MainSlides' in LCK8lO2yRWaTVEQcdjPXAzpFBe9: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',url,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
	if 'class="LinksList' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="LinksList(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			if len(k2pC30UArFeg7Ru9tGiZlSmzQ)>1 and type=='new_episodes': drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[1]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				sABprza7wEOC0Fd3PTQ = X2XorVqHjLkWeCchY4u9fSz.findall('</i>(.*?)<span>(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				try: GhdtAy1o3Ru8z5WvkUFQ6ES = sABprza7wEOC0Fd3PTQ[0][0].replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				except: GhdtAy1o3Ru8z5WvkUFQ6ES = SebHIf2jL1TBgrMKJu
				try: Oag9YZSMIHR = sABprza7wEOC0Fd3PTQ[0][1].replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				except: Oag9YZSMIHR = SebHIf2jL1TBgrMKJu
				sABprza7wEOC0Fd3PTQ = GhdtAy1o3Ru8z5WvkUFQ6ES+qE4nB3mKWHs+Oag9YZSMIHR
				if '<strong>' in title:
					PYqBFLuscM1krDj6lG5eWxJTU = X2XorVqHjLkWeCchY4u9fSz.findall('</i>(.*?)<',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					if PYqBFLuscM1krDj6lG5eWxJTU: sABprza7wEOC0Fd3PTQ = PYqBFLuscM1krDj6lG5eWxJTU[0]
				if not sABprza7wEOC0Fd3PTQ:
					PYqBFLuscM1krDj6lG5eWxJTU = X2XorVqHjLkWeCchY4u9fSz.findall('alt="(.*?)"',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					if PYqBFLuscM1krDj6lG5eWxJTU: sABprza7wEOC0Fd3PTQ = PYqBFLuscM1krDj6lG5eWxJTU[0]
				if sABprza7wEOC0Fd3PTQ:
					if 'key=' in cOn6JqZlmQbjtT: type = cOn6JqZlmQbjtT.split('key=')[1]
					else: type = 'newest'
					sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ.strip(qE4nB3mKWHs)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,cOn6JqZlmQbjtT,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,type)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,ZZW5QJxjDlBLpGHA):
	mAVqwSh62Dg5kU,data,items = 'GET',SebHIf2jL1TBgrMKJu,[]
	if ZZW5QJxjDlBLpGHA=='filters':
		if '?' in url:
			r1spDEX3MRQzFtmoJlOTLvV4yqxU7,bIGXajdcK6PQBs = 'POST',{}
			qg7Nr1dCaD,dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = url.split('?')
			P7SQWVY4x1vm9tnANdiB = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.split('&')
			for byUztE9qAGgCOlov8RB in P7SQWVY4x1vm9tnANdiB:
				key,value = byUztE9qAGgCOlov8RB.split('=')
				bIGXajdcK6PQBs[key] = value
			if P7SQWVY4x1vm9tnANdiB: mAVqwSh62Dg5kU,url,data = r1spDEX3MRQzFtmoJlOTLvV4yqxU7,qg7Nr1dCaD,bIGXajdcK6PQBs
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,mAVqwSh62Dg5kU,url,data,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if ZZW5QJxjDlBLpGHA=='filters': k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9]
	elif 'featured' in ZZW5QJxjDlBLpGHA: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="MainSlides(.*?)class="LinksList',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif ZZW5QJxjDlBLpGHA=='new_movies': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif ZZW5QJxjDlBLpGHA=='new_episodes': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif ZZW5QJxjDlBLpGHA=='most': k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="SliderInSection(.*?)class="LinksList',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"blocks__section(.*?)"paginate"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if 'featured' in ZZW5QJxjDlBLpGHA:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		qqpUrHmkIeDZhYtE5LvuOaTGfw06bx = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if qqpUrHmkIeDZhYtE5LvuOaTGfw06bx:
			bQGVWFxKS4D6p9YC7XPyA8Os,HFThJNteGZsSR5CD7rimbjPq,RT17XiFGudMhHeomA6,cr1ok5Ww9FQh = zip(*qqpUrHmkIeDZhYtE5LvuOaTGfw06bx)
			items = zip(bQGVWFxKS4D6p9YC7XPyA8Os,cr1ok5Ww9FQh,HFThJNteGZsSR5CD7rimbjPq)
	else:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		if 'WWE' in title: continue
		title = cvlHmV1Kr0FIYSjNnM(title)
		if 'الحلقة' in title:
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) الحلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0]
				if title not in aLlVEzy8XR62:
					aLlVEzy8XR62.append(title)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,253,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,252,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif '/selary/' in cOn6JqZlmQbjtT or 'مسلسل' in title:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,253,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,252,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if nyUIsfd53EGot9vbj0XDeq:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"paginate"(.*?)</section>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ZZW5QJxjDlBLpGHA)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('"poster__single".*?data-src="(.*?)".*?alt="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: return
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(qE4nB3mKWHs)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(qE4nB3mKWHs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"episodes__list boxs__wrapper(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,Wj39BaH6oEmstx in items:
			title = name+' - حلقة رقم '+Wj39BaH6oEmstx
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,252,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'ملف التشغيل',url,252,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def ZiLlPcuJE5Cw(title,cOn6JqZlmQbjtT):
	sABprza7wEOC0Fd3PTQ = X2XorVqHjLkWeCchY4u9fSz.findall('[a-zA-Z-]+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if sABprza7wEOC0Fd3PTQ: title = sABprza7wEOC0Fd3PTQ[0]
	else: title = title+qE4nB3mKWHs+EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
	title = title.replace('عرب سيد',SebHIf2jL1TBgrMKJu).replace('مباشر',SebHIf2jL1TBgrMKJu).replace('مشاهدة',SebHIf2jL1TBgrMKJu)
	title = title.replace('ٍ',SebHIf2jL1TBgrMKJu)
	title = title.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	return title
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	headers = {'Referer':YdzfwOyPb2gxT37B9Dm}
	qOGEcWZIwex2fK = []
	QYrEHI8OWK6awe3C47VSf = X2XorVqHjLkWeCchY4u9fSz.findall('href="([^"]*)" class="btton download__btn"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if QYrEHI8OWK6awe3C47VSf:
		QYrEHI8OWK6awe3C47VSf = QYrEHI8OWK6awe3C47VSf[0]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',QYrEHI8OWK6awe3C47VSf,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"tabs__holder(.*?)</section>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,o7MeOx6PDA1d,sABprza7wEOC0Fd3PTQ in items:
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = X2XorVqHjLkWeCchY4u9fSz.findall('\d+',sABprza7wEOC0Fd3PTQ,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = '__'+lcbjBn3FdZxC1059A4Kqvi2pugJOa[0] if lcbjBn3FdZxC1059A4Kqvi2pugJOa else SebHIf2jL1TBgrMKJu
				if '/l/' in cOn6JqZlmQbjtT:
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('/l/')[1]
					cOn6JqZlmQbjtT = ej3oxQLc68OIY.b64decode(cOn6JqZlmQbjtT)
					if QBOMjKifEAFD: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.decode(Tv08xsf9HOqunIVUPdK1)
				cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+o7MeOx6PDA1d+'__download'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	cc6R5oLjVt = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" class="btton watch__btn"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if wvkDqmNZlJU52isXo and cc6R5oLjVt:
		cc6R5oLjVt = cc6R5oLjVt[0]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',cc6R5oLjVt,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"watch__area"(.*?)<section',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" class="btton download__btn"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def JHTv3IOqiEsFWxmzpk(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	qg7Nr1dCaD = Bc5IUelt4sWvMXTdy.url
	YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(qg7Nr1dCaD,'url')
	headers['Referer'] = YdzfwOyPb2gxT37B9Dm+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	bQGVWFxKS4D6p9YC7XPyA8Os,C3IQwLuqsSZ8JvmNPG96B = [],[]
	gY8EUCBP1Ic0pdbi4uDmL,WzUatikLfVu5j3ZvE,qIWktsVdxOuNEYmn2e4 = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	hlrEy6z0WDIajAiJ9tPGuUs,iaQ981rvSjEVRybgHkth,BQCd4U91yRWotLHfhPI = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	OeZwgyoQMNL5 = X2XorVqHjLkWeCchY4u9fSz.findall('"WatchButtons"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if OeZwgyoQMNL5:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = OeZwgyoQMNL5[wvkDqmNZlJU52isXo]
		if '<form' in drRnSgoBtKWjmU5FH4ZCIVhzqNb:
			C3IQwLuqsSZ8JvmNPG96B = X2XorVqHjLkWeCchY4u9fSz.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if C3IQwLuqsSZ8JvmNPG96B:
				mAVqwSh62Dg5kU = 'POST'
				for QUWsbGoFmngMKlTpz7id,name,value in C3IQwLuqsSZ8JvmNPG96B:
					if 'wpost' in name: gY8EUCBP1Ic0pdbi4uDmL,WzUatikLfVu5j3ZvE,qIWktsVdxOuNEYmn2e4 = QUWsbGoFmngMKlTpz7id,name,value
					elif 'dpost' in name: hlrEy6z0WDIajAiJ9tPGuUs,iaQ981rvSjEVRybgHkth,BQCd4U91yRWotLHfhPI = QUWsbGoFmngMKlTpz7id,name,value
				WgSjaRBZhItJfU = WzUatikLfVu5j3ZvE+'='+qIWktsVdxOuNEYmn2e4
				fOFTnGDZzhuCA0PYbd8v = iaQ981rvSjEVRybgHkth+'='+BQCd4U91yRWotLHfhPI
		else:
			C3IQwLuqsSZ8JvmNPG96B = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if C3IQwLuqsSZ8JvmNPG96B:
				mAVqwSh62Dg5kU = 'GET'
				for cOn6JqZlmQbjtT in C3IQwLuqsSZ8JvmNPG96B:
					if 'wpost' in cOn6JqZlmQbjtT: gY8EUCBP1Ic0pdbi4uDmL = cOn6JqZlmQbjtT
					elif 'dpost' in cOn6JqZlmQbjtT: hlrEy6z0WDIajAiJ9tPGuUs = cOn6JqZlmQbjtT
				WgSjaRBZhItJfU = SebHIf2jL1TBgrMKJu
				fOFTnGDZzhuCA0PYbd8v = SebHIf2jL1TBgrMKJu
	if gY8EUCBP1Ic0pdbi4uDmL:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,mAVqwSh62Dg5kU,gY8EUCBP1Ic0pdbi4uDmL,WgSjaRBZhItJfU,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="WatcherArea(.*?</ul>)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			x7MK8HSh9YqdAuFO23Q = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			x7MK8HSh9YqdAuFO23Q = x7MK8HSh9YqdAuFO23Q.replace('</ul>','<h3>')
			x7MK8HSh9YqdAuFO23Q = x7MK8HSh9YqdAuFO23Q.replace('<h3>','<h3><h3>')
			cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('<h3>.*?(\d+)(.*?)<h3>',x7MK8HSh9YqdAuFO23Q,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if not cuoYjfNMPnmhQgtFE: cuoYjfNMPnmhQgtFE = [(SebHIf2jL1TBgrMKJu,x7MK8HSh9YqdAuFO23Q)]
			for lcbjBn3FdZxC1059A4Kqvi2pugJOa,drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
				if lcbjBn3FdZxC1059A4Kqvi2pugJOa: lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
				items = X2XorVqHjLkWeCchY4u9fSz.findall('data-link="(.*?)".*?<span>(.*?)</span>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for cOn6JqZlmQbjtT,name in items:
					if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__watch'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
					bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
		if uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			cOn6JqZlmQbjtT,lcbjBn3FdZxC1059A4Kqvi2pugJOa = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0]
			name = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
			if '%' in lcbjBn3FdZxC1059A4Kqvi2pugJOa: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__embed__'
			else: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+name+'__embed____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	if hlrEy6z0WDIajAiJ9tPGuUs:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,mAVqwSh62Dg5kU,hlrEy6z0WDIajAiJ9tPGuUs,fOFTnGDZzhuCA0PYbd8v,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-PLAY-3rd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="DownloadArea(.*?)<script src=',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			x7MK8HSh9YqdAuFO23Q = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('class="DownloadServers(.*?)</ul>',x7MK8HSh9YqdAuFO23Q,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for cOn6JqZlmQbjtT,title,lcbjBn3FdZxC1059A4Kqvi2pugJOa in items:
					if not cOn6JqZlmQbjtT: continue
					if 'reviewstation' in cOn6JqZlmQbjtT: continue
					cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT)
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
					bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	ffQUSsmZVB6edNI = str(bQGVWFxKS4D6p9YC7XPyA8Os)
	yy3UqGQkP85FaLw = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in ffQUSsmZVB6edNI for value in yy3UqGQkP85FaLw):
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search: search = zWKdm3kV2ItwYrgH1BZyRON()
	if not search: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/find/?word='+search+'&type='
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return
def vimwpBGoVK3EZrUkjPL(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='CATEGORIES':
		if KrX5dieyIm6p0UBAoFbCQY[0]+'==' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = KrX5dieyIm6p0UBAoFbCQY[0]
		for YHnALfql8hprDu in range(len(KrX5dieyIm6p0UBAoFbCQY[0:-1])):
			if KrX5dieyIm6p0UBAoFbCQY[YHnALfql8hprDu]+'==' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = KrX5dieyIm6p0UBAoFbCQY[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+kgy9Zm5TCvYHjE3PVQ+'==0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+kgy9Zm5TCvYHjE3PVQ+'==0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&&')+'___'+hW2bu9H1KJCkPlfr.strip('&&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'//getposts??'+LnwzHFAVsfO2Go
	elif type=='FILTERS':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'//getposts??'+wk0AjSOpcRB
		vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(qg7Nr1dCaD)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',vz42ouckGgElI,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',vz42ouckGgElI,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'POST',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'ARABSEED-FILTERS_MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	JdZT36miXuqY = X2XorVqHjLkWeCchY4u9fSz.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	lv7MDEjrfmJkFcIy2x8Pw0Uo = X2XorVqHjLkWeCchY4u9fSz.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	BJheYUDK3EOyfPR24 = JdZT36miXuqY+lv7MDEjrfmJkFcIy2x8Pw0Uo
	dict = {}
	for name,oIi8QaPyZBr1mvUcsh,drRnSgoBtKWjmU5FH4ZCIVhzqNb in BJheYUDK3EOyfPR24:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('data-rate="(.*?)".*?<em>(.*?)</em>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			items = []
			for OSEMFXaUVI1eqHhQYmbKPdJAnrk,value in IkJNp71Hyu0PwFAXMTsOc: items.append([OSEMFXaUVI1eqHhQYmbKPdJAnrk,SebHIf2jL1TBgrMKJu,value])
			oIi8QaPyZBr1mvUcsh = 'rate'
			name = 'التقييم'
		else: oIi8QaPyZBr1mvUcsh = items[0][1]
		if '==' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='CATEGORIES':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<=1:
				if oIi8QaPyZBr1mvUcsh==KrX5dieyIm6p0UBAoFbCQY[-1]: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'CATEGORIES___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(qg7Nr1dCaD)
				if oIi8QaPyZBr1mvUcsh==KrX5dieyIm6p0UBAoFbCQY[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع ',vz42ouckGgElI,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع ',qg7Nr1dCaD,254,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='FILTERS':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+oIi8QaPyZBr1mvUcsh+'==0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+oIi8QaPyZBr1mvUcsh+'==0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع :'+name,qg7Nr1dCaD,255,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for OSEMFXaUVI1eqHhQYmbKPdJAnrk,fNnuAzFsXhBKCco9JZeVUvd7Ya,value in items:
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			if 'الكل' in OSEMFXaUVI1eqHhQYmbKPdJAnrk: continue
			OSEMFXaUVI1eqHhQYmbKPdJAnrk = cvlHmV1Kr0FIYSjNnM(OSEMFXaUVI1eqHhQYmbKPdJAnrk)
			o7MeOx6PDA1d,sABprza7wEOC0Fd3PTQ = OSEMFXaUVI1eqHhQYmbKPdJAnrk,OSEMFXaUVI1eqHhQYmbKPdJAnrk
			sABprza7wEOC0Fd3PTQ = name+': '+o7MeOx6PDA1d
			dict[oIi8QaPyZBr1mvUcsh][value] = sABprza7wEOC0Fd3PTQ
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&&'+oIi8QaPyZBr1mvUcsh+'=='+o7MeOx6PDA1d
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&&'+oIi8QaPyZBr1mvUcsh+'=='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			if type=='FILTERS':
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,url,255,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='CATEGORIES' and KrX5dieyIm6p0UBAoFbCQY[-2]+'==' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				iGxH2fsuScPtkJb7ECg = url+'//getposts??'+LnwzHFAVsfO2Go
				vz42ouckGgElI = SYewG3Mo6biOIQmH0NP2KWj(iGxH2fsuScPtkJb7ECg)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,vz42ouckGgElI,251,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,url,254,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
KrX5dieyIm6p0UBAoFbCQY = ['category','country','release-year']
pLFecJvwthCVzxfoijl2UnOG = ['category','country','genre','release-year','language','quality','rate']
def SYewG3Mo6biOIQmH0NP2KWj(url):
	xAhsKXwCemZva4pfF7OgSY3 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',xAhsKXwCemZva4pfF7OgSY3)
	url = url.replace('/category/اخرى',SebHIf2jL1TBgrMKJu)
	if xAhsKXwCemZva4pfF7OgSY3 not in url: url = url+xAhsKXwCemZva4pfF7OgSY3
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&&')
	sezY2ok3RI69Oahwu7LCQAGUitZH,hIyBYfuc8oTsEZ = {},SebHIf2jL1TBgrMKJu
	if '==' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('==')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	for key in pLFecJvwthCVzxfoijl2UnOG:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&&'+key+'=='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&&'+key+'=='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&&')
	return hIyBYfuc8oTsEZ