# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'IFILM'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_IFL_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
paGcF7RvtOxsUKiVX0rmMLdhjol4 = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][1]
SKEDPtFf0am9wNuT5hWl = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][2]
odONbvVr9716G0zyw = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][3]
def WdRmv9kTtLnfZ24(mode,url,Q8A5HyT1fGNxZv4X3V7eC,text):
	if   mode==20: lfZmugQCFKLGT05AH29IsMiho = opQO7EDjmTt0Z1y5INGrCK63()
	elif mode==21: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA(url)
	elif mode==22: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==23: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==24: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url,text)
	elif mode==25: lfZmugQCFKLGT05AH29IsMiho = xxtmFU9lKjR1SvE(url)
	elif mode==27: lfZmugQCFKLGT05AH29IsMiho = PZbvLVAspF6rS1xhkm8W(url)
	elif mode==28: lfZmugQCFKLGT05AH29IsMiho = dbBOlXE4GUIVLPijQz()
	elif mode==29: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def opQO7EDjmTt0Z1y5INGrCK63():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'عربي',j1IFsik4ouNePZr,21,SebHIf2jL1TBgrMKJu,'101')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'English',paGcF7RvtOxsUKiVX0rmMLdhjol4,21,SebHIf2jL1TBgrMKJu,'101')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فارسى',SKEDPtFf0am9wNuT5hWl,21,SebHIf2jL1TBgrMKJu,'101')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فارسى 2',odONbvVr9716G0zyw,21,SebHIf2jL1TBgrMKJu,'101')
	return
def dbBOlXE4GUIVLPijQz():
	QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'عربي',j1IFsik4ouNePZr,27)
	QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'English',paGcF7RvtOxsUKiVX0rmMLdhjol4,27)
	QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فارسى',SKEDPtFf0am9wNuT5hWl,27)
	QUzFYoapm9jx('live',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فارسى 2',odONbvVr9716G0zyw,27)
	return
def EEXPfIxMNny1QzZt6gKkA(kO7xDdTlFGERwh5p1zf3i):
	tfX4sO3hy2H1IbKG = kO7xDdTlFGERwh5p1zf3i
	if kO7xDdTlFGERwh5p1zf3i=='IFILM-ARABIC': kO7xDdTlFGERwh5p1zf3i = j1IFsik4ouNePZr
	elif kO7xDdTlFGERwh5p1zf3i=='IFILM-ENGLISH': kO7xDdTlFGERwh5p1zf3i = paGcF7RvtOxsUKiVX0rmMLdhjol4
	else: tfX4sO3hy2H1IbKG = SebHIf2jL1TBgrMKJu
	kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(kO7xDdTlFGERwh5p1zf3i)
	if kWK265p4lZFTBSwbPJ=='ar' or tfX4sO3hy2H1IbKG=='IFILM-ARABIC':
		FaloOr3LqH0Xgn9Q51 = 'بحث في الموقع'
		SSzVkjJwMRLbP5FnN1xes83Tty = 'مسلسلات - حالية'
		dxwMtG2cpSBbCVe6HqIfDZn = 'مسلسلات - أحدث'
		dqI9uOQCa1zHW = 'مسلسلات - أبجدي'
		P7vYOylQi9zLWwkrN = 'بث حي آي فيلم'
		lMhz8xPpm14 = 'أفلام'
		qPwoItA4JEyj0vZ5LbNRDYUWFX = 'موسيقى'
		Db4yfOUoCa9 = 'برامج'
	elif kWK265p4lZFTBSwbPJ=='en' or tfX4sO3hy2H1IbKG=='IFILM-ENGLISH':
		FaloOr3LqH0Xgn9Q51 = 'Search in site'
		SSzVkjJwMRLbP5FnN1xes83Tty = 'Series - Current'
		dxwMtG2cpSBbCVe6HqIfDZn = 'Series - Latest'
		dqI9uOQCa1zHW = 'Series - Alphabet'
		P7vYOylQi9zLWwkrN = 'Live iFilm channel'
		lMhz8xPpm14 = 'Movies'
		qPwoItA4JEyj0vZ5LbNRDYUWFX = 'Music'
		Db4yfOUoCa9 = 'Shows'
	elif kWK265p4lZFTBSwbPJ in ['fa','fa2']:
		FaloOr3LqH0Xgn9Q51 = 'جستجو در سایت'
		SSzVkjJwMRLbP5FnN1xes83Tty = 'سريال - جاری'
		dxwMtG2cpSBbCVe6HqIfDZn = 'سريال - آخرین'
		dqI9uOQCa1zHW = 'سريال - الفبا'
		P7vYOylQi9zLWwkrN = 'پخش زنده اي فيلم'
		lMhz8xPpm14 = 'فيلم'
		qPwoItA4JEyj0vZ5LbNRDYUWFX = 'موسيقى'
		Db4yfOUoCa9 = 'برنامه ها'
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+FaloOr3LqH0Xgn9Q51,kO7xDdTlFGERwh5p1zf3i,29,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('live',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+P7vYOylQi9zLWwkrN,kO7xDdTlFGERwh5p1zf3i,27)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	utk5Dor0c4fOpClX9gZI62NK = ['Series','Program','Music']
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,kO7xDdTlFGERwh5p1zf3i+'/home',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ=X2XorVqHjLkWeCchY4u9fSz.findall('button-menu(.*?)/Contact',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if any(value in cOn6JqZlmQbjtT for value in utk5Dor0c4fOpClX9gZI62NK):
				url = kO7xDdTlFGERwh5p1zf3i+cOn6JqZlmQbjtT
				if 'Series' in cOn6JqZlmQbjtT:
					QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,url,22,SebHIf2jL1TBgrMKJu,'100')
					QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+dxwMtG2cpSBbCVe6HqIfDZn,url,22,SebHIf2jL1TBgrMKJu,'101')
					QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+dqI9uOQCa1zHW,url,22,SebHIf2jL1TBgrMKJu,'201')
				elif 'Film' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+lMhz8xPpm14,url,22,SebHIf2jL1TBgrMKJu,'100')
				elif 'Music' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+qPwoItA4JEyj0vZ5LbNRDYUWFX,url,25,SebHIf2jL1TBgrMKJu,'101')
				elif 'Program' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+Db4yfOUoCa9,url,22,SebHIf2jL1TBgrMKJu,'101')
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def xxtmFU9lKjR1SvE(url):
	kO7xDdTlFGERwh5p1zf3i = WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-MUSIC_MENU-1st')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('Music-tools-header(.*?)Music-body',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	title = X2XorVqHjLkWeCchY4u9fSz.findall('<p>(.*?)</p>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,22,SebHIf2jL1TBgrMKJu,'101')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		cOn6JqZlmQbjtT = kO7xDdTlFGERwh5p1zf3i + cOn6JqZlmQbjtT
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,23,SebHIf2jL1TBgrMKJu,'101')
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC):
	kO7xDdTlFGERwh5p1zf3i = WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url)
	kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(url)
	type = url.split('/')[-1]
	ct1UTmBRfzkjPGqp3g4lC756XAwO = str(int(Q8A5HyT1fGNxZv4X3V7eC)//100)
	Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)%100)
	if type=='Series' and Q8A5HyT1fGNxZv4X3V7eC=='0':
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-TITLES-1st')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('serial-body(.*?)class="row',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			title = a549mfV8gnzXpwlFr(title)
			title = cvlHmV1Kr0FIYSjNnM(title)
			cOn6JqZlmQbjtT = kO7xDdTlFGERwh5p1zf3i + cOn6JqZlmQbjtT
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = kO7xDdTlFGERwh5p1zf3i + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,23,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ct1UTmBRfzkjPGqp3g4lC756XAwO+'01')
	Y2Pqj3W6NBtgUrDLFHJchE=0
	if type=='Series': kgy9Zm5TCvYHjE3PVQ='3'
	if type=='Film': kgy9Zm5TCvYHjE3PVQ='5'
	if type=='Program': kgy9Zm5TCvYHjE3PVQ='7'
	if type in ['Series','Program','Film'] and Q8A5HyT1fGNxZv4X3V7eC!='0':
		qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Home/PageingItem?category='+kgy9Zm5TCvYHjE3PVQ+'&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&orderby='+ct1UTmBRfzkjPGqp3g4lC756XAwO
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-TITLES-2nd')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for id,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			title = a549mfV8gnzXpwlFr(title)
			title = title.replace('\\',SebHIf2jL1TBgrMKJu)
			title = title.replace('"',SebHIf2jL1TBgrMKJu)
			Y2Pqj3W6NBtgUrDLFHJchE += 1
			cOn6JqZlmQbjtT = kO7xDdTlFGERwh5p1zf3i + '/' + type + '/Content/' + id
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = kO7xDdTlFGERwh5p1zf3i + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			if type=='Film': QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,24,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ct1UTmBRfzkjPGqp3g4lC756XAwO+'01')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,23,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,ct1UTmBRfzkjPGqp3g4lC756XAwO+'01')
	if type=='Music':
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,kO7xDdTlFGERwh5p1zf3i+'/Music/Index?page='+Q8A5HyT1fGNxZv4X3V7eC,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-TITLES-3rd')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pagination-demo(.*?)pagination-demo',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			Y2Pqj3W6NBtgUrDLFHJchE += 1
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = kO7xDdTlFGERwh5p1zf3i + tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			cOn6JqZlmQbjtT = kO7xDdTlFGERwh5p1zf3i + cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,23,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,'101')
	if Y2Pqj3W6NBtgUrDLFHJchE>20:
		title='صفحة '
		if kWK265p4lZFTBSwbPJ=='en': title = 'Page '
		if kWK265p4lZFTBSwbPJ=='fa': title = 'صفحه '
		if kWK265p4lZFTBSwbPJ=='fa2': title = 'صفحه '
		for V9rGNtohIC7JuPXKD02Q5MHv in range(1,11) :
			if not Q8A5HyT1fGNxZv4X3V7eC==str(V9rGNtohIC7JuPXKD02Q5MHv):
				GRSUnFbHBuvP9ksNLqgjX = '0'+str(V9rGNtohIC7JuPXKD02Q5MHv)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title+str(V9rGNtohIC7JuPXKD02Q5MHv),url,22,SebHIf2jL1TBgrMKJu,ct1UTmBRfzkjPGqp3g4lC756XAwO+GRSUnFbHBuvP9ksNLqgjX[-2:])
	return
def LRb6nEvgqXwITMc80r1Vt(url,Q8A5HyT1fGNxZv4X3V7eC):
	if not Q8A5HyT1fGNxZv4X3V7eC: Q8A5HyT1fGNxZv4X3V7eC = 0
	kO7xDdTlFGERwh5p1zf3i = WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url)
	mm2TpqnjEk0DCOfrvQPd = WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url)
	kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(url)
	YY9GyjxZl6 = url.split('/')
	id,type = YY9GyjxZl6[-1],YY9GyjxZl6[3]
	ct1UTmBRfzkjPGqp3g4lC756XAwO = str(int(Q8A5HyT1fGNxZv4X3V7eC)//100)
	Q8A5HyT1fGNxZv4X3V7eC = str(int(Q8A5HyT1fGNxZv4X3V7eC)%100)
	Y2Pqj3W6NBtgUrDLFHJchE = 0
	if type=='Series':
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-1st')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		title = ' - الحلقة '
		if kWK265p4lZFTBSwbPJ=='en': title = ' - Episode '
		if kWK265p4lZFTBSwbPJ=='fa': title = ' - قسمت '
		if kWK265p4lZFTBSwbPJ=='fa2': title = ' - قسمت '
		if kWK265p4lZFTBSwbPJ=='fa': Z8zcSA0MIjsNEvLYdmeBCl7rqHKPR = SebHIf2jL1TBgrMKJu
		else: Z8zcSA0MIjsNEvLYdmeBCl7rqHKPR = kWK265p4lZFTBSwbPJ
		YxljFrB4CKTQZoEkJta2u = X2XorVqHjLkWeCchY4u9fSz.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for name,count,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT in items:
			for Wj39BaH6oEmstx in range(int(count),0,-1):
				QSEokHmAOpU1zadMRD = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs + Z8zcSA0MIjsNEvLYdmeBCl7rqHKPR + id + '/' + str(Wj39BaH6oEmstx) + '.png'
				SSzVkjJwMRLbP5FnN1xes83Tty = name + title + str(Wj39BaH6oEmstx)
				SSzVkjJwMRLbP5FnN1xes83Tty = cvlHmV1Kr0FIYSjNnM(SSzVkjJwMRLbP5FnN1xes83Tty)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,url,24,QSEokHmAOpU1zadMRD,SebHIf2jL1TBgrMKJu,str(Wj39BaH6oEmstx))
	elif type=='Program':
		qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&orderby=1'
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-2nd')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		title = ' - الحلقة '
		if kWK265p4lZFTBSwbPJ=='en': title = ' - Episode '
		if kWK265p4lZFTBSwbPJ=='fa': title = ' - قسمت '
		if kWK265p4lZFTBSwbPJ=='fa2': title = ' - قسمت '
		for Wj39BaH6oEmstx,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,AkpRNPh2sLg0TFfY1m9tQq46iv,name in items:
			Y2Pqj3W6NBtgUrDLFHJchE += 1
			QSEokHmAOpU1zadMRD = mm2TpqnjEk0DCOfrvQPd + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			name = a549mfV8gnzXpwlFr(name)
			SSzVkjJwMRLbP5FnN1xes83Tty = name + title + str(Wj39BaH6oEmstx)
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,qg7Nr1dCaD,24,QSEokHmAOpU1zadMRD,SebHIf2jL1TBgrMKJu,str(Y2Pqj3W6NBtgUrDLFHJchE))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Music/GetTracksBy?id='+str(id)+'&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&type=0'
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-3rd')
			items = X2XorVqHjLkWeCchY4u9fSz.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,name,title in items:
				Y2Pqj3W6NBtgUrDLFHJchE += 1
				QSEokHmAOpU1zadMRD = mm2TpqnjEk0DCOfrvQPd + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				SSzVkjJwMRLbP5FnN1xes83Tty = name + ' - ' + title
				SSzVkjJwMRLbP5FnN1xes83Tty = SSzVkjJwMRLbP5FnN1xes83Tty.strip(qE4nB3mKWHs)
				SSzVkjJwMRLbP5FnN1xes83Tty = a549mfV8gnzXpwlFr(SSzVkjJwMRLbP5FnN1xes83Tty)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,qg7Nr1dCaD,24,QSEokHmAOpU1zadMRD,SebHIf2jL1TBgrMKJu,str(Y2Pqj3W6NBtgUrDLFHJchE))
		elif 'Clips' in url:
			qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Music/GetTracksBy?id=0&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&type=15'
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-4th')
			items = X2XorVqHjLkWeCchY4u9fSz.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,cOn6JqZlmQbjtT in items:
				Y2Pqj3W6NBtgUrDLFHJchE += 1
				QSEokHmAOpU1zadMRD = mm2TpqnjEk0DCOfrvQPd + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				SSzVkjJwMRLbP5FnN1xes83Tty = title.strip(qE4nB3mKWHs)
				SSzVkjJwMRLbP5FnN1xes83Tty = a549mfV8gnzXpwlFr(SSzVkjJwMRLbP5FnN1xes83Tty)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,qg7Nr1dCaD,24,QSEokHmAOpU1zadMRD,SebHIf2jL1TBgrMKJu,str(Y2Pqj3W6NBtgUrDLFHJchE))
		elif 'category' in url:
			if 'category=6' in url:
				qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Music/GetTracksBy?id=0&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&type=6'
				LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				qg7Nr1dCaD = kO7xDdTlFGERwh5p1zf3i+'/Music/GetTracksBy?id=0&page='+Q8A5HyT1fGNxZv4X3V7eC+'&size=30&type=4'
				LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-EPISODES-6th')
			items = X2XorVqHjLkWeCchY4u9fSz.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,name,title in items:
				Y2Pqj3W6NBtgUrDLFHJchE += 1
				QSEokHmAOpU1zadMRD = mm2TpqnjEk0DCOfrvQPd + xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				SSzVkjJwMRLbP5FnN1xes83Tty = name + ' - ' + title
				SSzVkjJwMRLbP5FnN1xes83Tty = SSzVkjJwMRLbP5FnN1xes83Tty.strip(qE4nB3mKWHs)
				SSzVkjJwMRLbP5FnN1xes83Tty = a549mfV8gnzXpwlFr(SSzVkjJwMRLbP5FnN1xes83Tty)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+SSzVkjJwMRLbP5FnN1xes83Tty,qg7Nr1dCaD,24,QSEokHmAOpU1zadMRD,SebHIf2jL1TBgrMKJu,str(Y2Pqj3W6NBtgUrDLFHJchE))
	if type=='Music' or type=='Program':
		if Y2Pqj3W6NBtgUrDLFHJchE>25:
			title='صفحة '
			if kWK265p4lZFTBSwbPJ=='en': title = ' Page '
			if kWK265p4lZFTBSwbPJ=='fa': title = ' صفحه '
			if kWK265p4lZFTBSwbPJ=='fa2': title = ' صفحه '
			for V9rGNtohIC7JuPXKD02Q5MHv in range(1,11):
				if not Q8A5HyT1fGNxZv4X3V7eC==str(V9rGNtohIC7JuPXKD02Q5MHv):
					GRSUnFbHBuvP9ksNLqgjX = '0'+str(V9rGNtohIC7JuPXKD02Q5MHv)
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title+str(V9rGNtohIC7JuPXKD02Q5MHv),url,23,SebHIf2jL1TBgrMKJu,ct1UTmBRfzkjPGqp3g4lC756XAwO+GRSUnFbHBuvP9ksNLqgjX[-2:])
	return
def rRCw3hfy2Kq5l(url,Wj39BaH6oEmstx):
	mm2TpqnjEk0DCOfrvQPd = WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url)
	HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = [],[]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-PLAY-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(url)
		YY9GyjxZl6 = url.split('/')
		id,type = YY9GyjxZl6[-1],YY9GyjxZl6[3]
		cOn6JqZlmQbjtT = items[0][0]+kWK265p4lZFTBSwbPJ+id+'/,'+Wj39BaH6oEmstx+','+Wj39BaH6oEmstx+'_'+items[0][2]
		HFThJNteGZsSR5CD7rimbjPq.append('m3u8')
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(url)
		YY9GyjxZl6 = url.split('/')
		id,type = YY9GyjxZl6[-1],YY9GyjxZl6[3]
		cOn6JqZlmQbjtT = items[0][0]+kWK265p4lZFTBSwbPJ+id+'/'+Wj39BaH6oEmstx+items[0][2]
		HFThJNteGZsSR5CD7rimbjPq.append('mp4 url')
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('source src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT in items:
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('//','/')
		HFThJNteGZsSR5CD7rimbjPq.append('mp4 src')
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('VideoAddress":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		cOn6JqZlmQbjtT = items[int(Wj39BaH6oEmstx)-1]
		cOn6JqZlmQbjtT = mm2TpqnjEk0DCOfrvQPd+xuCTZaNtMVwFs(cOn6JqZlmQbjtT)
		HFThJNteGZsSR5CD7rimbjPq.append('mp4 address')
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('VoiceAddress":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		cOn6JqZlmQbjtT = items[int(Wj39BaH6oEmstx)-1]
		cOn6JqZlmQbjtT = mm2TpqnjEk0DCOfrvQPd+xuCTZaNtMVwFs(cOn6JqZlmQbjtT)
		HFThJNteGZsSR5CD7rimbjPq.append('mp3 address')
		bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	if len(bQGVWFxKS4D6p9YC7XPyA8Os)==1: cOn6JqZlmQbjtT = bQGVWFxKS4D6p9YC7XPyA8Os[0]
	else:
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر الفيديو المناسب:', HFThJNteGZsSR5CD7rimbjPq)
		if QQea1XbjZDEMhp == -1 : return
		cOn6JqZlmQbjtT = bQGVWFxKS4D6p9YC7XPyA8Os[QQea1XbjZDEMhp]
	nxW9asAySzOt2foFGT4LwmHNl8uZ(cOn6JqZlmQbjtT,tfX4sO3hy2H1IbKG,'video')
	return
def WsDxJNoCM7nwpHGKTPBqmEjvrhRu(url):
	if j1IFsik4ouNePZr in url: GJ4kbYnxcHa6NIOuA7X20S = j1IFsik4ouNePZr
	elif paGcF7RvtOxsUKiVX0rmMLdhjol4 in url: GJ4kbYnxcHa6NIOuA7X20S = paGcF7RvtOxsUKiVX0rmMLdhjol4
	elif SKEDPtFf0am9wNuT5hWl in url: GJ4kbYnxcHa6NIOuA7X20S = SKEDPtFf0am9wNuT5hWl
	elif odONbvVr9716G0zyw in url: GJ4kbYnxcHa6NIOuA7X20S = odONbvVr9716G0zyw
	else: GJ4kbYnxcHa6NIOuA7X20S = SebHIf2jL1TBgrMKJu
	return GJ4kbYnxcHa6NIOuA7X20S
def npgMRyClQqWi1V3Y9xJAa(url):
	if   j1IFsik4ouNePZr in url: kWK265p4lZFTBSwbPJ = 'ar'
	elif paGcF7RvtOxsUKiVX0rmMLdhjol4 in url: kWK265p4lZFTBSwbPJ = 'en'
	elif SKEDPtFf0am9wNuT5hWl in url: kWK265p4lZFTBSwbPJ = 'fa'
	elif odONbvVr9716G0zyw in url: kWK265p4lZFTBSwbPJ = 'fa2'
	else: kWK265p4lZFTBSwbPJ = SebHIf2jL1TBgrMKJu
	return kWK265p4lZFTBSwbPJ
def PZbvLVAspF6rS1xhkm8W(url):
	kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(url)
	qg7Nr1dCaD = url + '/Home/Live'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-LIVE-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	items = X2XorVqHjLkWeCchY4u9fSz.findall('source src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	iGxH2fsuScPtkJb7ECg = items[0]
	nxW9asAySzOt2foFGT4LwmHNl8uZ(iGxH2fsuScPtkJb7ECg,tfX4sO3hy2H1IbKG,'live')
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search:
		search = zWKdm3kV2ItwYrgH1BZyRON()
		if not search: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'+')
	if showDialogs:
		oZ5N80OrMg4tn37 = [ j1IFsik4ouNePZr , paGcF7RvtOxsUKiVX0rmMLdhjol4 , SKEDPtFf0am9wNuT5hWl , odONbvVr9716G0zyw ]
		JFsnEmbRzSf8aVy5GZ9k = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر اللغة المناسبة:', JFsnEmbRzSf8aVy5GZ9k)
		if QQea1XbjZDEMhp == -1 : return
		website = oZ5N80OrMg4tn37[QQea1XbjZDEMhp]
	else:
		if '_IFILM-ARABIC_' in ndiZQ7oLFkV1W: website = j1IFsik4ouNePZr
		elif '_IFILM-ENGLISH_' in ndiZQ7oLFkV1W: website = paGcF7RvtOxsUKiVX0rmMLdhjol4
		else: website = SebHIf2jL1TBgrMKJu
	if not website: return
	kWK265p4lZFTBSwbPJ = npgMRyClQqWi1V3Y9xJAa(website)
	qg7Nr1dCaD = website + "/Home/Search?searchstring=" + t2WLY7DxIZs
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'IFILM-SEARCH-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,kgy9Zm5TCvYHjE3PVQ,id,title in items:
			if kgy9Zm5TCvYHjE3PVQ in ['3','7']:
				title = title.replace('\\',SebHIf2jL1TBgrMKJu)
				title = title.replace('"',SebHIf2jL1TBgrMKJu)
				if kgy9Zm5TCvYHjE3PVQ=='3':
					type = 'Series'
					if kWK265p4lZFTBSwbPJ=='ar': name = 'مسلسل : '
					elif kWK265p4lZFTBSwbPJ=='en': name = 'Series : '
					elif kWK265p4lZFTBSwbPJ=='fa': name = 'سريال ها : '
					elif kWK265p4lZFTBSwbPJ=='fa2': name = 'سريال ها : '
				elif kgy9Zm5TCvYHjE3PVQ=='5':
					type = 'Film'
					if kWK265p4lZFTBSwbPJ=='ar': name = 'فيلم : '
					elif kWK265p4lZFTBSwbPJ=='en': name = 'Movie : '
					elif kWK265p4lZFTBSwbPJ=='fa': name = 'فيلم : '
					elif kWK265p4lZFTBSwbPJ=='fa2': name = 'فلم ها : '
				elif kgy9Zm5TCvYHjE3PVQ=='7':
					type = 'Program'
					if kWK265p4lZFTBSwbPJ=='ar': name = 'برنامج : '
					elif kWK265p4lZFTBSwbPJ=='en': name = 'Program : '
					elif kWK265p4lZFTBSwbPJ=='fa': name = 'برنامه ها : '
					elif kWK265p4lZFTBSwbPJ=='fa2': name = 'برنامه ها : '
				title = name + title
				cOn6JqZlmQbjtT = website + '/' + type + '/Content/' + id
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = xuCTZaNtMVwFs(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = website+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,23,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,'101')
	return