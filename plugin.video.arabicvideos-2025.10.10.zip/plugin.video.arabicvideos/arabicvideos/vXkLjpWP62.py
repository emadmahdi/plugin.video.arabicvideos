# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'VIDEONSAEM'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_VNS_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','Show more','قصة عشق','عروض المصارعة الحرة مترجم']
headers = {'Referer':j1IFsik4ouNePZr}
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==1030: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==1031: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==1032: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==1033: lfZmugQCFKLGT05AH29IsMiho = JZvYADs6nb0zV4WU7RM1So8X5dIp(url,text)
	elif mode==1034: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==1039: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,1039,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''["']navslide-wrap["'](.*?)</ul>''',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if title in jgvMWZhtPlBT: continue
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1034)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('/category.php">(.*?)"navslide-divider"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('''["']dropdown-menu["'](.*?)</ul>''',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for Q4idDwN25EKRJCajSyc in k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace(Q4idDwN25EKRJCajSyc,SebHIf2jL1TBgrMKJu)
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if not title: continue
		if title in jgvMWZhtPlBT: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1034)
	return
def xwWavftjMBT0nJDsuz2g(url):
	HQghJb68Le5Mn9UkKif7srjdS,IkJNp71Hyu0PwFAXMTsOc = [],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-SUBMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Eky7GUxAVIQMn3ip0DOHrSYJ = X2XorVqHjLkWeCchY4u9fSz.findall('"caret"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Eky7GUxAVIQMn3ip0DOHrSYJ and '.php' in str(Eky7GUxAVIQMn3ip0DOHrSYJ):
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = Eky7GUxAVIQMn3ip0DOHrSYJ[0]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('"presentation"','</ul>')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = [(SebHIf2jL1TBgrMKJu,drRnSgoBtKWjmU5FH4ZCIVhzqNb)]
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' فرز أو فلتر أو ترتيب '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		for bCsfqPwXyzihR1nm,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
			HQghJb68Le5Mn9UkKif7srjdS = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if bCsfqPwXyzihR1nm: bCsfqPwXyzihR1nm = bCsfqPwXyzihR1nm+': '
			for cOn6JqZlmQbjtT,title in HQghJb68Le5Mn9UkKif7srjdS:
				title = bCsfqPwXyzihR1nm+title
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1031)
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-category-subcats"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if BRdnHfWTrhFe:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if 1 or len(IkJNp71Hyu0PwFAXMTsOc)<30:
			if HQghJb68Le5Mn9UkKif7srjdS: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
			for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc:
				if title in jgvMWZhtPlBT: continue
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1031)
	if not Eky7GUxAVIQMn3ip0DOHrSYJ and not BRdnHfWTrhFe: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,pbmcw9i1kfuNIQzJ7aGd3l0=SebHIf2jL1TBgrMKJu):
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		REIkboX9NtlZCSU3A = headers.copy()
		REIkboX9NtlZCSU3A['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',url,data,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-TITLES-1st')
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-TITLES-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	drRnSgoBtKWjmU5FH4ZCIVhzqNb,items = SebHIf2jL1TBgrMKJu,[]
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	if pbmcw9i1kfuNIQzJ7aGd3l0=='ajax-search':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
		IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in IkJNp71Hyu0PwFAXMTsOc: items.append((SebHIf2jL1TBgrMKJu,cOn6JqZlmQbjtT,title))
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-carousel_featured"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_movies':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"row pm-ul-browse-videos(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(k2pC30UArFeg7Ru9tGiZlSmzQ)>1: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[1]
	elif pbmcw9i1kfuNIQzJ7aGd3l0=='featured_series':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pm-grid"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	if drRnSgoBtKWjmU5FH4ZCIVhzqNb and not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: return
	aLlVEzy8XR62 = []
	YT8EVG4D1vOubScAHUazRNB5 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cOn6JqZlmQbjtT,title,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs += '|Referer='+j1IFsik4ouNePZr
		if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
		title = cvlHmV1Kr0FIYSjNnM(title)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if pbmcw9i1kfuNIQzJ7aGd3l0=='episodes' or any(value in title for value in YT8EVG4D1vOubScAHUazRNB5):
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1032,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif pbmcw9i1kfuNIQzJ7aGd3l0=='new_episodes':
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1032,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx:
			title = '_MOD_' + Wj39BaH6oEmstx[0][0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1033,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,1033,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if 1:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT=='#': continue
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/'+cOn6JqZlmQbjtT.strip('/')
				title = cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,1031,'','',pbmcw9i1kfuNIQzJ7aGd3l0)
	return
def JZvYADs6nb0zV4WU7RM1So8X5dIp(url,yZfHYbEdxgemqNFoL8OSrR):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-EPISODES_SEASONS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="eplist"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		EiadFrl0bx3uWPqGmIkHNQp = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in EiadFrl0bx3uWPqGmIkHNQp:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,872)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<dt>(.*?)<dt>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if cOn6JqZlmQbjtT:
				yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(cOn6JqZlmQbjtT[-1],'episodes')
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK,ff281j5nDJ0iK = [],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'VIDEONSAEM-PLAY-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'hash=' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		U1RP0Fyg8QoGL4waApm = X2XorVqHjLkWeCchY4u9fSz.findall('hash=(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		U1RP0Fyg8QoGL4waApm = list(set(U1RP0Fyg8QoGL4waApm))
		for BHvXNYSAsJ0dLy4MCw3ilODxIrGtT in U1RP0Fyg8QoGL4waApm:
			cnS3aMO4lEXQFWPGfqe = []
			YY9GyjxZl6 = BHvXNYSAsJ0dLy4MCw3ilODxIrGtT.split('__')
			for jdIsVqWvu6ibCGo7Tf2t5YUEOPm in YY9GyjxZl6:
				try:
					jdIsVqWvu6ibCGo7Tf2t5YUEOPm = ej3oxQLc68OIY.b64decode(jdIsVqWvu6ibCGo7Tf2t5YUEOPm+'=')
					if QBOMjKifEAFD: jdIsVqWvu6ibCGo7Tf2t5YUEOPm = jdIsVqWvu6ibCGo7Tf2t5YUEOPm.decode(Tv08xsf9HOqunIVUPdK1)
					cnS3aMO4lEXQFWPGfqe.append(jdIsVqWvu6ibCGo7Tf2t5YUEOPm)
				except: pass
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = '>'.join(cnS3aMO4lEXQFWPGfqe)
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT.splitlines()
			for cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
				if ' => ' in cOn6JqZlmQbjtT:
					title,cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split(' => ')
					cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__watch'
					qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/search.php?keywords='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return