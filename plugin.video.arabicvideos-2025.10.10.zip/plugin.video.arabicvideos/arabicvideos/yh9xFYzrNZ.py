# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'FASELHD1'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_FH1_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['جوائز الأوسكار','المراجعات','wwe']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==570: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==571: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==572: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==573: lfZmugQCFKLGT05AH29IsMiho = oaylPZ1DvdTh54(url,text)
	elif mode==576: lfZmugQCFKLGT05AH29IsMiho = TOFltPsNmbCZa7Gk684x3h()
	elif mode==579: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('link',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'لماذا الموقع بطيء',SebHIf2jL1TBgrMKJu,576)
	VK4jU2G3s1PwkticQYyLoW,url = j1IFsik4ouNePZr,j1IFsik4ouNePZr
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD1-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',VK4jU2G3s1PwkticQYyLoW,579,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',VK4jU2G3s1PwkticQYyLoW,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured1')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('class="h3">(.*?)<.*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for title,cOn6JqZlmQbjtT in items:
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'details1')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"menu-primary"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		Ay2QFpLmwX30lriJnIHYG = X2XorVqHjLkWeCchY4u9fSz.findall('<li (.*?)</li>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		eZCry9QiD8 = [SebHIf2jL1TBgrMKJu,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		XM3KUmO1QJxlv84bgFTHsjdNt0kYq = 0
		for utk5Dor0c4fOpClX9gZI62NK in Ay2QFpLmwX30lriJnIHYG:
			if XM3KUmO1QJxlv84bgFTHsjdNt0kYq>0: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)<',utk5Dor0c4fOpClX9gZI62NK,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				if cOn6JqZlmQbjtT=='#': continue
				if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
				if title==SebHIf2jL1TBgrMKJu: continue
				if any(value in title.lower() for value in jgvMWZhtPlBT): continue
				title = eZCry9QiD8[XM3KUmO1QJxlv84bgFTHsjdNt0kYq]+title
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'details2')
			XM3KUmO1QJxlv84bgFTHsjdNt0kYq += 1
	return
def TOFltPsNmbCZa7Gk684x3h():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD1-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	BRdnHfWTrhFe = X2XorVqHjLkWeCchY4u9fSz.findall('class="h4">(.*?)</div>(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not BRdnHfWTrhFe: return
	if type=='filters':
		k2pC30UArFeg7Ru9tGiZlSmzQ = [LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"homeSlide"(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		p6aRNk2W0vDYV1C4Ms7xjgiwALIqd,uLdRirAZJKoSgPqNUjm84WXE5cn3aT,wDrcdftqyO = zip(*items)
		items = zip(uLdRirAZJKoSgPqNUjm84WXE5cn3aT,p6aRNk2W0vDYV1C4Ms7xjgiwALIqd,wDrcdftqyO)
	elif type=='featured2':
		title,drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type=='details2' and len(BRdnHfWTrhFe)>1:
		title = BRdnHfWTrhFe[0][0]
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured2')
		title = BRdnHfWTrhFe[1][0]
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'details3')
		return
	else:
		title,drRnSgoBtKWjmU5FH4ZCIVhzqNb = BRdnHfWTrhFe[-1]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		if any(value in title.lower() for value in jgvMWZhtPlBT): continue
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = a549mfV8gnzXpwlFr(tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.split('?resize=')[0]
		title = cvlHmV1Kr0FIYSjNnM(title)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|حلقة).\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if '/collections/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,571,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		elif Wj39BaH6oEmstx and type==SebHIf2jL1TBgrMKJu:
			title = '_MOD_'+Wj39BaH6oEmstx[0][0]
			title = title.strip(' –')
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,573,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif 'episodes/' in cOn6JqZlmQbjtT or 'movies/' in cOn6JqZlmQbjtT or 'hindi/' in cOn6JqZlmQbjtT:
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,572,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,573,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type=='filters':
		aOcSDH75NIYFk8fP = X2XorVqHjLkWeCchY4u9fSz.findall('"more_button_page":(.*?),',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if aOcSDH75NIYFk8fP:
			count = aOcSDH75NIYFk8fP[0]
			cOn6JqZlmQbjtT = url+'/offset/'+count
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة أخرى',cOn6JqZlmQbjtT,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filters')
	elif 'details' in type:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall("class='pagination(.*?)</div>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall("href='(.*?)'.*?>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = 'صفحة '+cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,571,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'details4')
	return
def oaylPZ1DvdTh54(url,type=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD1-SEASONS_EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	DmS9dwGqQIfP6sv = False
	if not type:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"seasonList"(.*?)"container"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if len(items)>1:
				VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
				DmS9dwGqQIfP6sv = True
				for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,name,title in items:
					name = cvlHmV1Kr0FIYSjNnM(name)
					if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+cOn6JqZlmQbjtT
					title = name+' - '+title
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,573,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,SebHIf2jL1TBgrMKJu,'episodes')
	if type=='episodes' or not DmS9dwGqQIfP6sv:
		i3iEyeZ8BQmpDNornRVxTzwdYcX7 = X2XorVqHjLkWeCchY4u9fSz.findall('"posterImg".*?src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if i3iEyeZ8BQmpDNornRVxTzwdYcX7: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = i3iEyeZ8BQmpDNornRVxTzwdYcX7[0]
		else: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = SebHIf2jL1TBgrMKJu
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"epAll"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = title.strip(qE4nB3mKWHs)
				title = cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,572,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	qOGEcWZIwex2fK,r4v9gIZARuz10a,zKhpx40Tsegb5ivIf = [],[],[]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'FASELHD1-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	Vy5bgtTnfZmI9OJ4sDr1 = X2XorVqHjLkWeCchY4u9fSz.findall('مستوى المشاهدة.*?">(.*?)</span>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if Vy5bgtTnfZmI9OJ4sDr1:
		S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('"tag">(.*?)</a>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"videoRow"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('&img=')[0]
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named=__embed')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="streamHeader(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("href = '(.*?)'.*?</i>(.*?)</a>",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('&img=')[0]
			name = name.strip(qE4nB3mKWHs)
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+name+'__watch')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="downloadLinks(.*?)blackwindow',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</span>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,name in items:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('&img=')[0]
			qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+name+'__download')
	for lgX3GQwmTisx9tjMSPFUeEZ in qOGEcWZIwex2fK:
		cOn6JqZlmQbjtT,name = lgX3GQwmTisx9tjMSPFUeEZ.split('?named')
		if cOn6JqZlmQbjtT not in r4v9gIZARuz10a:
			r4v9gIZARuz10a.append(cOn6JqZlmQbjtT)
			zKhpx40Tsegb5ivIf.append(lgX3GQwmTisx9tjMSPFUeEZ)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(zKhpx40Tsegb5ivIf,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	qg7Nr1dCaD = j1IFsik4ouNePZr+'/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(qg7Nr1dCaD,'details5')
	return