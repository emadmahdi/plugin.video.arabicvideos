# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'MOVIZLAND'
headers = { 'User-Agent' : SebHIf2jL1TBgrMKJu }
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_MVZ_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
paGcF7RvtOxsUKiVX0rmMLdhjol4 = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][1]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==180: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==181: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==182: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==183: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==188: lfZmugQCFKLGT05AH29IsMiho = ANUq0yBljxf9kbzgeI5PEw()
	elif mode==189: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def ANUq0yBljxf9kbzgeI5PEw():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,message)
	return
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,189,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بوكس اوفيس موفيز لاند',j1IFsik4ouNePZr,181,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'box-office')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أحدث الافلام',j1IFsik4ouNePZr,181,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'latest-movies')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'تليفزيون موفيز لاند',j1IFsik4ouNePZr,181,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'tv')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الاكثر مشاهدة',j1IFsik4ouNePZr,181,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'top-views')
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أقوى الافلام الحالية',j1IFsik4ouNePZr,181,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'top-movies')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-MENU-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<h2><a href="(.*?)".*?">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,181)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	elif type=='box-office': drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	elif type=='top-movies': drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('btn-2-overlay(.*?)<style>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	elif type=='top-views': drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	elif type=='tv': drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	else: drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
	if type in ['top-views','top-movies']:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else: items = X2XorVqHjLkWeCchY4u9fSz.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	BmVW5JQ7kafuTCg9DHZ3 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45,ipw6XMKtVFfudJOsjnzxayLo2bc8 in items:
		if type in ['top-views','top-movies']:
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,cOn6JqZlmQbjtT,Sn3lefFys4XLgp8JiRvV,title = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45,ipw6XMKtVFfudJOsjnzxayLo2bc8
		else: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title,cOn6JqZlmQbjtT,Sn3lefFys4XLgp8JiRvV = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,VFukSqDl4vCZ1fOc3gKALp7,AAojFVQnsyKMd7PhbxI45,ipw6XMKtVFfudJOsjnzxayLo2bc8
		cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT)
		cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace('?view=true',SebHIf2jL1TBgrMKJu)
		title = cvlHmV1Kr0FIYSjNnM(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',SebHIf2jL1TBgrMKJu).replace('بجوده ',SebHIf2jL1TBgrMKJu)
		title = title.strip(qE4nB3mKWHs)
		if 'الحلقة' in title or 'الحلقه' in title:
			Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|الحلقه) \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if Wj39BaH6oEmstx:
				title = '_MOD_' + Wj39BaH6oEmstx[0][0]
				if title not in aLlVEzy8XR62:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,183,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
					aLlVEzy8XR62.append(title)
		elif any(value in title for value in BmVW5JQ7kafuTCg9DHZ3):
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT + '?servers=' + Sn3lefFys4XLgp8JiRvV
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,182,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT + '?servers=' + Sn3lefFys4XLgp8JiRvV
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,183,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if type==SebHIf2jL1TBgrMKJu:
		items = X2XorVqHjLkWeCchY4u9fSz.findall('\n<li><a href="(.*?)".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
			if title!=SebHIf2jL1TBgrMKJu:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,181)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	qg7Nr1dCaD = url.split('?servers=')[0]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-EPISODES-1st')
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = X2XorVqHjLkWeCchY4u9fSz.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	title,fNnuAzFsXhBKCco9JZeVUvd7Ya,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = drRnSgoBtKWjmU5FH4ZCIVhzqNb[0]
	name = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="episodesNumbers"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in items:
			cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT)
			title = X2XorVqHjLkWeCchY4u9fSz.findall('(الحلقة|الحلقه)-([0-9]+)',cOn6JqZlmQbjtT.split('/')[-2],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if not title: title = X2XorVqHjLkWeCchY4u9fSz.findall('()-([0-9]+)',cOn6JqZlmQbjtT.split('/')[-2],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if title: title = qE4nB3mKWHs + title[0][1]
			else: title = SebHIf2jL1TBgrMKJu
			title = name + ' - ' + 'الحلقة' + title
			title = cvlHmV1Kr0FIYSjNnM(title)
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,182,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	if not items:
		title = cvlHmV1Kr0FIYSjNnM(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',SebHIf2jL1TBgrMKJu).replace('بجوده ',SebHIf2jL1TBgrMKJu)
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,182,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	HYAf5Oxa7RIjDSodeNrpm6 = url.split('?servers=')
	qg7Nr1dCaD = HYAf5Oxa7RIjDSodeNrpm6[0]
	del HYAf5Oxa7RIjDSodeNrpm6[0]
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-PLAY-1st')
	cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('font-size: 25px;" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	if cOn6JqZlmQbjtT not in HYAf5Oxa7RIjDSodeNrpm6: HYAf5Oxa7RIjDSodeNrpm6.append(cOn6JqZlmQbjtT)
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	for cOn6JqZlmQbjtT in HYAf5Oxa7RIjDSodeNrpm6:
		if '://moshahda.' in cOn6JqZlmQbjtT:
			owbvgREOSrPJmjiXxukeG = cOn6JqZlmQbjtT
			bQGVWFxKS4D6p9YC7XPyA8Os.append(owbvgREOSrPJmjiXxukeG+'?named=Main')
	for cOn6JqZlmQbjtT in HYAf5Oxa7RIjDSodeNrpm6:
		if '://vb.movizland.' in cOn6JqZlmQbjtT:
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,cOn6JqZlmQbjtT,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-PLAY-2nd')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.decode(B7NYRr4wPgsZzx9kSGAD).encode(Tv08xsf9HOqunIVUPdK1)
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if k2pC30UArFeg7Ru9tGiZlSmzQ:
				ISeA5mVBKjOrCF9n,jur15x2kUH0BOZdoApYgIV = [],[]
				if len(k2pC30UArFeg7Ru9tGiZlSmzQ)==1:
					title = SebHIf2jL1TBgrMKJu
					drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
				else:
					for drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
						Q4idDwN25EKRJCajSyc = X2XorVqHjLkWeCchY4u9fSz.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						if Q4idDwN25EKRJCajSyc: drRnSgoBtKWjmU5FH4ZCIVhzqNb = 'src="/uploads/13721411411.png"  \n  ' + Q4idDwN25EKRJCajSyc[0][1]
						Q4idDwN25EKRJCajSyc = X2XorVqHjLkWeCchY4u9fSz.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						if Q4idDwN25EKRJCajSyc: drRnSgoBtKWjmU5FH4ZCIVhzqNb = 'src="/uploads/13721411411.png"  \n  ' + Q4idDwN25EKRJCajSyc[0]
						Q4idDwN25EKRJCajSyc = X2XorVqHjLkWeCchY4u9fSz.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						if Q4idDwN25EKRJCajSyc: drRnSgoBtKWjmU5FH4ZCIVhzqNb = Q4idDwN25EKRJCajSyc[0] + '  \n  src="/uploads/13721411411.png"'
						peQXWgyvcI = X2XorVqHjLkWeCchY4u9fSz.findall('<(.*?)http://up.movizland.(online|com)/uploads/',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						title = X2XorVqHjLkWeCchY4u9fSz.findall('> *([^<>]+) *<',peQXWgyvcI[0][0],X2XorVqHjLkWeCchY4u9fSz.DOTALL)
						title = qE4nB3mKWHs.join(title)
						title = title.strip(qE4nB3mKWHs)
						title = title.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
						ISeA5mVBKjOrCF9n.append(title)
					QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('أختر الفيديو المطلوب:', ISeA5mVBKjOrCF9n)
					if QQea1XbjZDEMhp == -1 : return
					title = ISeA5mVBKjOrCF9n[QQea1XbjZDEMhp]
					drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[QQea1XbjZDEMhp]
				cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(http://moshahda\..*?/\w+.html)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				Khmk15fDsST43jVJv6g = cOn6JqZlmQbjtT[0]
				bQGVWFxKS4D6p9YC7XPyA8Os.append(Khmk15fDsST43jVJv6g+'?named=Forum')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('ـ',SebHIf2jL1TBgrMKJu)
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				drRnSgoBtKWjmU5FH4ZCIVhzqNb = drRnSgoBtKWjmU5FH4ZCIVhzqNb.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				NNAmDpH5wtOJPLCcB7reb4sg8 = X2XorVqHjLkWeCchY4u9fSz.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for lNrMhxBvzSVOqtXFU in NNAmDpH5wtOJPLCcB7reb4sg8:
					type = X2XorVqHjLkWeCchY4u9fSz.findall(' typetype="(.*?)" ',lNrMhxBvzSVOqtXFU)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = SebHIf2jL1TBgrMKJu
					items = X2XorVqHjLkWeCchY4u9fSz.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',lNrMhxBvzSVOqtXFU,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for MMEdI2WKVwCOQu8,cOn6JqZlmQbjtT in items:
						title = X2XorVqHjLkWeCchY4u9fSz.findall('(\w+[ \w]*)<',MMEdI2WKVwCOQu8)
						title = title[-1]
						cOn6JqZlmQbjtT = cOn6JqZlmQbjtT + '?named=' + title + type
						bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD.replace(j1IFsik4ouNePZr,paGcF7RvtOxsUKiVX0rmMLdhjol4)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,iGxH2fsuScPtkJb7ECg,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-PLAY-3rd')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		kG8awcAxsqrUnO = items[-1]
		bQGVWFxKS4D6p9YC7XPyA8Os.append(kG8awcAxsqrUnO+'?named=Mobile')
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,'MOVIZLAND-SEARCH-1st')
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<option value="(.*?)">(.*?)</option>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	haM0jZUfqQGykrsJcO1 = [ SebHIf2jL1TBgrMKJu ]
	mYQN0fqEDbCUz18wKchdu76oieOxn = [ 'الكل وبدون فلتر' ]
	for kgy9Zm5TCvYHjE3PVQ,title in items:
		haM0jZUfqQGykrsJcO1.append(kgy9Zm5TCvYHjE3PVQ)
		mYQN0fqEDbCUz18wKchdu76oieOxn.append(title)
	if kgy9Zm5TCvYHjE3PVQ:
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('اختر الفلتر المناسب:', mYQN0fqEDbCUz18wKchdu76oieOxn)
		if QQea1XbjZDEMhp == -1 : return
		kgy9Zm5TCvYHjE3PVQ = haM0jZUfqQGykrsJcO1[QQea1XbjZDEMhp]
	else: kgy9Zm5TCvYHjE3PVQ = SebHIf2jL1TBgrMKJu
	url = j1IFsik4ouNePZr + '/?s='+search+'&mcat='+kgy9Zm5TCvYHjE3PVQ
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return