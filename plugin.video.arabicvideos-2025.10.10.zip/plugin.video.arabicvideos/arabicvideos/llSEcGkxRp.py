# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'SHOOFMAX'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_SHM_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
paGcF7RvtOxsUKiVX0rmMLdhjol4 = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][1]
SKEDPtFf0am9wNuT5hWl = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][2]
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==50: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==51: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==52: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==53: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==55: lfZmugQCFKLGT05AH29IsMiho = pUgvYesHWqx7fuom1AVaFZ()
	elif mode==56: lfZmugQCFKLGT05AH29IsMiho = dyHC1awmnoRv8Ft3UJxcq()
	elif mode==57: lfZmugQCFKLGT05AH29IsMiho = XbcsqfLxQa6gWTPwKFj2dACYm4lvM(url,1)
	elif mode==58: lfZmugQCFKLGT05AH29IsMiho = XbcsqfLxQa6gWTPwKFj2dACYm4lvM(url,2)
	elif mode==59: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,59,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المسلسلات',SebHIf2jL1TBgrMKJu,56)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الافلام',SebHIf2jL1TBgrMKJu,55)
	return SebHIf2jL1TBgrMKJu
def pUgvYesHWqx7fuom1AVaFZ():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام مرتبة بسنة الإنتاج',j1IFsik4ouNePZr+'/movie/1/yop',57)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام مرتبة بالأفضل تقييم',j1IFsik4ouNePZr+'/movie/1/review',57)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أفلام مرتبة بالأكثر مشاهدة',j1IFsik4ouNePZr+'/movie/1/views',57)
	return
def dyHC1awmnoRv8Ft3UJxcq():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مرتبة بسنة الإنتاج',j1IFsik4ouNePZr+'/series/1/yop',57)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مرتبة بالأفضل تقييم',j1IFsik4ouNePZr+'/series/1/review',57)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسلات مرتبة بالأكثر مشاهدة',j1IFsik4ouNePZr+'/series/1/views',57)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url):
	if '?' in url:
		YY9GyjxZl6 = url.split('?')
		url = YY9GyjxZl6[0]
		filter = '?' + xuCTZaNtMVwFs(YY9GyjxZl6[1],'=&:/%')
	else: filter = SebHIf2jL1TBgrMKJu
	type,Q8A5HyT1fGNxZv4X3V7eC,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': LWsBIERzV9ADfKaNwg='فيلم'
		elif type=='series': LWsBIERzV9ADfKaNwg='مسلسل'
		url = j1IFsik4ouNePZr + '/genre/filter/' + xuCTZaNtMVwFs(LWsBIERzV9ADfKaNwg) + '/' + Q8A5HyT1fGNxZv4X3V7eC + '/' + sort + filter
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHOOFMAX-TITLES-1st')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		Y2Pqj3W6NBtgUrDLFHJchE=0
		for id,title,PPCksqZWlgLbRYHwfo5BUt1G3I,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
			Y2Pqj3W6NBtgUrDLFHJchE += 1
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = SKEDPtFf0am9wNuT5hWl + '/v2/img/program/main/' + tncvzBN0kyrqEHlhIPGSoX4ugA3CDs + '-2.jpg'
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr + '/program/' + id
			if type=='movie': QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,53,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			if type=='series': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسل '+title,cOn6JqZlmQbjtT+'?ep='+PPCksqZWlgLbRYHwfo5BUt1G3I+'='+title+'='+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,52,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else:
		if type=='movie': LWsBIERzV9ADfKaNwg='movies'
		elif type=='series': LWsBIERzV9ADfKaNwg='series'
		url = paGcF7RvtOxsUKiVX0rmMLdhjol4 + '/json/selected/' + sort + '-' + LWsBIERzV9ADfKaNwg + '-WW.json'
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHOOFMAX-TITLES-2nd')
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		Y2Pqj3W6NBtgUrDLFHJchE=0
		for id,PPCksqZWlgLbRYHwfo5BUt1G3I,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			Y2Pqj3W6NBtgUrDLFHJchE += 1
			tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = paGcF7RvtOxsUKiVX0rmMLdhjol4 + '/img/program/' + tncvzBN0kyrqEHlhIPGSoX4ugA3CDs + '-2.jpg'
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr + '/program/' + id
			if type=='movie': QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,53,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			elif type=='series': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'مسلسل '+title,cOn6JqZlmQbjtT+'?ep='+PPCksqZWlgLbRYHwfo5BUt1G3I+'='+title+'='+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,52,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	title='صفحة '
	if Y2Pqj3W6NBtgUrDLFHJchE==16:
		for V9rGNtohIC7JuPXKD02Q5MHv in range(1,13) :
			if not Q8A5HyT1fGNxZv4X3V7eC==str(V9rGNtohIC7JuPXKD02Q5MHv):
				url = j1IFsik4ouNePZr+'/genre/filter/'+type+'/'+str(V9rGNtohIC7JuPXKD02Q5MHv)+'/'+sort+filter
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title+str(V9rGNtohIC7JuPXKD02Q5MHv),url,51)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	YY9GyjxZl6 = url.split('=')
	PPCksqZWlgLbRYHwfo5BUt1G3I = int(YY9GyjxZl6[1])
	name = kLEi7mYT5wBM4DHsgWy8(YY9GyjxZl6[2])
	name = name.replace('_MOD_مسلسل ',SebHIf2jL1TBgrMKJu)
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = YY9GyjxZl6[3]
	url = url.split('?')[0]
	if PPCksqZWlgLbRYHwfo5BUt1G3I==0:
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(QfG1xIZ4hpq3ezPXt7VbvglUcB,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHOOFMAX-EPISODES-1st')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<select(.*?)</select>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('option value="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		PPCksqZWlgLbRYHwfo5BUt1G3I = int(items[-1])
	for Wj39BaH6oEmstx in range(PPCksqZWlgLbRYHwfo5BUt1G3I,0,-1):
		cOn6JqZlmQbjtT = url + '?ep=' + str(Wj39BaH6oEmstx)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(Wj39BaH6oEmstx)
		QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,53,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHOOFMAX-PLAY-1st')
	VCxnzjctluBQR7dg4h2bXEPI = X2XorVqHjLkWeCchY4u9fSz.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if VCxnzjctluBQR7dg4h2bXEPI:
		uv8V4fE7j9pmgFr3wnDL = VCxnzjctluBQR7dg4h2bXEPI[1].replace('T',saNjmrfQDGgltv)
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+u43PVWjh7t9YwI+uv8V4fE7j9pmgFr3wnDL)
		return
	yOsYJEoFZi8vQRIr9cV,EejnbcIYXvp = [],[]
	DDS2j4g1pJiNzqlf0ncQRrUwKTmX = X2XorVqHjLkWeCchY4u9fSz.findall('var origin_link = "(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	vSlhzP5xU3M4iy9G = X2XorVqHjLkWeCchY4u9fSz.findall('var backup_origin_link = "(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)[0]
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('hls: (.*?)_link\+"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for YdzfwOyPb2gxT37B9Dm,cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
		if 'backup' in YdzfwOyPb2gxT37B9Dm:
			YdzfwOyPb2gxT37B9Dm = 'backup server'
			url = vSlhzP5xU3M4iy9G + cOn6JqZlmQbjtT
		else:
			YdzfwOyPb2gxT37B9Dm = 'main server'
			url = DDS2j4g1pJiNzqlf0ncQRrUwKTmX + cOn6JqZlmQbjtT
		if '.m3u8' in url:
			yOsYJEoFZi8vQRIr9cV.append(url)
			EejnbcIYXvp.append('m3u8  '+YdzfwOyPb2gxT37B9Dm)
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	uLdRirAZJKoSgPqNUjm84WXE5cn3aT += X2XorVqHjLkWeCchY4u9fSz.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for YdzfwOyPb2gxT37B9Dm,cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
		filename = cOn6JqZlmQbjtT.split('/')[-1]
		filename = filename.replace('fallback',SebHIf2jL1TBgrMKJu)
		filename = filename.replace('.mp4',SebHIf2jL1TBgrMKJu)
		filename = filename.replace('-',SebHIf2jL1TBgrMKJu)
		if 'backup' in YdzfwOyPb2gxT37B9Dm:
			YdzfwOyPb2gxT37B9Dm = 'backup server'
			url = vSlhzP5xU3M4iy9G + cOn6JqZlmQbjtT
		else:
			YdzfwOyPb2gxT37B9Dm = 'main server'
			url = DDS2j4g1pJiNzqlf0ncQRrUwKTmX + cOn6JqZlmQbjtT
		yOsYJEoFZi8vQRIr9cV.append(url)
		EejnbcIYXvp.append('mp4  '+YdzfwOyPb2gxT37B9Dm+nlNC2gJDBZMed63TxqphA1vrXm8Hy+filename)
	QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG('Select Video Quality:', EejnbcIYXvp)
	if QQea1XbjZDEMhp == -1 : return
	url = yOsYJEoFZi8vQRIr9cV[QQea1XbjZDEMhp]
	nxW9asAySzOt2foFGT4LwmHNl8uZ(url,tfX4sO3hy2H1IbKG,'video')
	return
def XbcsqfLxQa6gWTPwKFj2dACYm4lvM(url,type):
	if 'series' in url: qg7Nr1dCaD = j1IFsik4ouNePZr + '/genre/مسلسل'
	else: qg7Nr1dCaD = j1IFsik4ouNePZr + '/genre/فيلم'
	qg7Nr1dCaD = xuCTZaNtMVwFs(qg7Nr1dCaD)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = ObKau0SHZBTmrRAzeEtfGFUg9vs(iHR47eol8wB3Z,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'SHOOFMAX-FILTERS-1st')
	if type==1: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('subgenre(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	elif type==2: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('country(.*?)div',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('option value="(.*?)">(.*?)</option',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if type==1:
		for ZCDtuGz4Qi,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url+'?subgenre='+ZCDtuGz4Qi,58)
	elif type==2:
		url,ZCDtuGz4Qi = url.split('?')
		for LHwNEhkMb92Kpf8UtuQTP3a6S,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url+'?country='+LHwNEhkMb92Kpf8UtuQTP3a6S+'&'+ZCDtuGz4Qi,51)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if not search: search = zWKdm3kV2ItwYrgH1BZyRON()
	if not search: return
	t2WLY7DxIZs = search.replace(qE4nB3mKWHs,'%20')
	url = j1IFsik4ouNePZr+'/search?q='+t2WLY7DxIZs
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,True,SebHIf2jL1TBgrMKJu,'SHOOFMAX-SEARCH-2nd')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('general-body(.*?)search-bottom-padding',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if items:
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			url = j1IFsik4ouNePZr + cOn6JqZlmQbjtT
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+xuCTZaNtMVwFs(title)+'='+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,52,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				else:
					title = '_MOD_فيلم '+title
					QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,53,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return