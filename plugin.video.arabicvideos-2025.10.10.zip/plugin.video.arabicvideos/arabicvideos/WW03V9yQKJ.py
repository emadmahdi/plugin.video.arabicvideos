# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ཆ")
def WdRmv9kTtLnfZ24(hL9fngBAu7XzOx,Yg36raSGA02uUXEPMF7itZd9KcWf=SebHIf2jL1TBgrMKJu):
	if   hL9fngBAu7XzOx==uqLUBHepfM3l6AyIzTJh80a(u"࠴ሞ"): p9h8MwzJrT(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==l7kBpMw5Qn(u"࠶ሟ"): pass
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠸ሠ"): CQgMI2jYDy4F(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==l7kBpMw5Qn(u"࠳ሡ"): iVH7IgXKGob4P9calwu2qypsARD()
	elif hL9fngBAu7XzOx==DQIrVcKuY6bJv(u"࠵ሢ"): LHuCGNODMjrmvEp9Wt8SoA1Ys4Bz(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠷ሣ"): pVamYQnj9WFrSq27GfgI1ZRkPy6JA()
	elif hL9fngBAu7XzOx==uqLUBHepfM3l6AyIzTJh80a(u"࠹ሤ"): KoyNkpQM6uU0S()
	elif hL9fngBAu7XzOx==fp6KV7DlS8QYniUczHdmZChL(u"࠻ሥ"): D17MRSNzQH()
	elif hL9fngBAu7XzOx==wPnfgxKZdAv6T10(u"࠽ሦ"): xkY4yGJS8rIozj1qgdvf()
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠷࠵࠱ሧ"): tw95nibYF3rfE()
	elif hL9fngBAu7XzOx==VOALf8iYEnMdK0g(u"࠱࠶࠳ረ"): ga97vGsW5xkUpC2NBtf4ejO8zALQlw()
	elif hL9fngBAu7XzOx==xxRyYsrSCzjifvH4cIqgldeOo(u"࠲࠷࠵ሩ"): iOWEHkzFSlwun0hK58GC7()
	elif hL9fngBAu7XzOx==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠳࠸࠷ሪ"): k7l3AJYoO5bqKrihRDw41GEMcP()
	elif hL9fngBAu7XzOx==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠴࠹࠹ራ"): YlRWog6MbDF4vyVSKuXwq1hJ5k()
	elif hL9fngBAu7XzOx==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠵࠺࠻ሬ"): q07AsXUzebnuiRM()
	elif hL9fngBAu7XzOx==uqLUBHepfM3l6AyIzTJh80a(u"࠶࠻࠶ር"): dezSqHTNvxYj()
	elif hL9fngBAu7XzOx==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠷࠵࠸ሮ"): C0K29doLUXGWHqTf1IBnYwNypmP()
	elif hL9fngBAu7XzOx==VOALf8iYEnMdK0g(u"࠱࠶࠺ሯ"): Q4dSrWoHny0mO9YVKM()
	elif hL9fngBAu7XzOx==sTGtHVyhQ9cJU37zxo2O(u"࠲࠷࠼ሰ"): soYe8JFVziP3j1QhSK(BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠳࠺࠴ሱ"): QTIuOolE2qKCeYVH()
	elif hL9fngBAu7XzOx==wPnfgxKZdAv6T10(u"࠴࠻࠶ሲ"): pYx59CRH8hay3gfF4TblDMso0WAIJ()
	elif hL9fngBAu7XzOx==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠵࠼࠸ሳ"): ENy7SiaD8eW1UIP5BXTrGcOCpuoF([Yg36raSGA02uUXEPMF7itZd9KcWf],BBX9RAuxnyGZ4WIF2TrhYeom3,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
	elif hL9fngBAu7XzOx==uqLUBHepfM3l6AyIzTJh80a(u"࠶࠽࠳ሴ"): j3jFtGCKvzmOBwaX2ibogEx4JRqQD(wPnfgxKZdAv6T10(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬཇ"),BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠷࠷࠵ስ"): j3jFtGCKvzmOBwaX2ibogEx4JRqQD(l7kBpMw5Qn(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ཈"),BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠱࠸࠷ሶ"): YoeJjvyzlW0dbB3MS5cm9R()
	elif hL9fngBAu7XzOx==sTGtHVyhQ9cJU37zxo2O(u"࠲࠹࠹ሷ"): R3LqdQWNhpe7JbGOY8my06SDTvunU()
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠳࠺࠻ሸ"): uuaYAFK9ygvDrxtUHWnXfbMBCl(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫཉ"))
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠴࠻࠾ሹ"): uuaYAFK9ygvDrxtUHWnXfbMBCl(l7kBpMw5Qn(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨཊ"))
	elif hL9fngBAu7XzOx==C3w6qluao7EzUxJgMGBtV(u"࠵࠾࠶ሺ"): Q7EINd1XV6MliUczOr4vtfjs3APg()
	elif hL9fngBAu7XzOx==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠶࠿࠱ሻ"): nny3lzpxCoD7UjPcE()
	elif hL9fngBAu7XzOx==sTGtHVyhQ9cJU37zxo2O(u"࠷࠹࠳ሼ"): G31G6JWXoLzO8S0UV72bl()
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠱࠺࠵ሽ"): GyTWvMeE3VwPBO7D()
	elif hL9fngBAu7XzOx==czvu7VQCZodkMf(u"࠲࠻࠷ሾ"): cTDpCNI2Hw9S()
	elif hL9fngBAu7XzOx==Ns6AJKH7DGpr19Wl5C3nF(u"࠳࠼࠹ሿ"): SeC7hYyzXjT3x1Qq08On()
	elif hL9fngBAu7XzOx==vMhFypGLHZJbdX4O7oc3W8x(u"࠴࠽࠻ቀ"): CCGlDkuMwS6TtH5P1iNpWocb9()
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠵࠾࠽ቁ"): yDopAblUa7Lnvir1h()
	elif hL9fngBAu7XzOx==sTGtHVyhQ9cJU37zxo2O(u"࠶࠿࠸ቂ"): CgDNiVkIEcqbwjP1LWB4()
	elif hL9fngBAu7XzOx==gCkRKGhwcx26v(u"࠷࠹࠺ቃ"): nFbZJXqSB640misAlepjzTIk()
	elif hL9fngBAu7XzOx==zpx2fPNKk6Ms38eD1vcO(u"࠳࠵࠲ቄ"): akrE2X076qQKeLFsYSj(Yg36raSGA02uUXEPMF7itZd9KcWf)
	elif hL9fngBAu7XzOx==ASkvf27etUK0(u"࠴࠶࠴ቅ"): PDRwMfC9Xu4A()
	elif hL9fngBAu7XzOx==HCiWF4jV1Q8(u"࠵࠷࠶ቆ"): xLkKiDtd0HC6()
	elif hL9fngBAu7XzOx==xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠸࠸ቇ"): Xcbn7RKDCNiGZEVfSFyOl9Mxz6B()
	elif hL9fngBAu7XzOx==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠷࠹࠻ቈ"): DX7IhEGYMzWe9qA()
	elif hL9fngBAu7XzOx==fp6KV7DlS8QYniUczHdmZChL(u"࠸࠺࠶቉"): UrNpagjyiLOqhPT6VMB8XGv74AQt(mrhSYXH2P8bO3eJAa9n)
	elif hL9fngBAu7XzOx==bcNqYtfET5l92dLGjyZSPe(u"࠹࠴࠸ቊ"): eex4VdtZ9fUsJhB7(BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠳࠵࠺ቋ"): mRknYiNMy0x()
	elif hL9fngBAu7XzOx==DQIrVcKuY6bJv(u"࠴࠶࠼ቌ"): GnQhi9CoBMkX7(VOALf8iYEnMdK0g(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧཋ"),BBX9RAuxnyGZ4WIF2TrhYeom3,BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==xxRyYsrSCzjifvH4cIqgldeOo(u"࠷࠳࠴ቍ"): rru21CMlfSTNXdei()
	elif hL9fngBAu7XzOx==Gykx0wL3XrlWaujsqKP9n2Q(u"࠸࠴࠶቎"): kS50JqBhl81Fb()
	elif hL9fngBAu7XzOx==czvu7VQCZodkMf(u"࠹࠵࠸቏"): CQPERlTrs3S1md()
	elif hL9fngBAu7XzOx==l7kBpMw5Qn(u"࠺࠶࠳ቐ"): ixVpUjGf5SQ(dUj4HNoGp91APu6itnl3BCc)
	elif hL9fngBAu7XzOx==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠻࠰࠵ቑ"): ixVpUjGf5SQ(NnA1JBy7DVvFqcm)
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠵࠱࠷ቒ"): eMYjWPac0KBIrQ7D6h4NRi()
	elif hL9fngBAu7XzOx==TVnqDYzWoM2UfHp0dchJ(u"࠶࠲࠹ቓ"): GGeyKjEOzHdn2I4BkXglo37(BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠷࠳࠻ቔ"): APY9XQqg62N37yweKLi1Cd()
	elif hL9fngBAu7XzOx==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠸࠴࠽ቕ"): vCSp54h1JnN7W9KOd8wtXlaRf()
	elif hL9fngBAu7XzOx==Ns6AJKH7DGpr19Wl5C3nF(u"࠵࠵࠸࠰ቖ"): PP5OKYfmdngbcl0LW()
	elif hL9fngBAu7XzOx==iDhLkZS6XBagNCQfs9tq2(u"࠶࠶࠲࠲቗"): SxeODtAwbILFXoQy62YrWJ3R1gPTUN()
	elif hL9fngBAu7XzOx==DQIrVcKuY6bJv(u"࠷࠰࠳࠴ቘ"): uuaYAFK9ygvDrxtUHWnXfbMBCl(uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨཌ"))
	elif hL9fngBAu7XzOx==DQIrVcKuY6bJv(u"࠱࠱࠴࠶቙"): rKiEG68Zq3RcSxj5g()
	elif hL9fngBAu7XzOx==Ns6AJKH7DGpr19Wl5C3nF(u"࠲࠲࠵࠸ቚ"): nZsMNoSJmxeuWOdQUcCR4lBa(BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def nZsMNoSJmxeuWOdQUcCR4lBa(showDialogs=mrhSYXH2P8bO3eJAa9n):
	MBwh2HtDEZSYxrCpd = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(TVnqDYzWoM2UfHp0dchJ(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡧࡦࡲࡥ࠯࡭ࡨࡽࡧࡵࡡࡳࡦ࡯ࡥࡾࡵࡵࡵࡵࠥࢁࢂ࠭ཌྷ"))
	MBwh2HtDEZSYxrCpd = ddWZPUnz9Cljm.loads(MBwh2HtDEZSYxrCpd)[t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬཎ")][AGlW9LqKN3Dvo(u"࠭ࡶࡢ࡮ࡸࡩࠬཏ")]
	choice,DpzKcQfPAtHR = JhTts2R43AxkM8bYanKVy,MBwh2HtDEZSYxrCpd[:]
	if showDialogs:
		UevbqyjO89H5BTCdzfpEZYSXFP0G2N = DQIrVcKuY6bJv(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡ็ไ฽้ฯ้ࠠฬ฼้้࠭ཐ") if gCkRKGhwcx26v(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨད") in MBwh2HtDEZSYxrCpd else j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣฯ๎โโหࠪདྷ")
		choice = omIUAxNupsBHY0SGnJXzijltOyV(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡧࡪࡴࡴࡦࡴࠪན"),HCiWF4jV1Q8(u"ࠫำื่อࠩཔ"),l7kBpMw5Qn(u"ࠬห๊ใษไࠫཕ"),xxRyYsrSCzjifvH4cIqgldeOo(u"࠭สี฼ํ่ࠬབ"),lFEvMxzSH2y7tYR,E7r8hUCVvTiFQW0dBGXjxcy+UevbqyjO89H5BTCdzfpEZYSXFP0G2N+XOVRfitWJP1zL3p2CMYF+u43PVWjh7t9YwI+u43PVWjh7t9YwI+DQIrVcKuY6bJv(u"่ࠧา๊ࠤฬู๊่์ไอࠥะำๆฯࠣฬฬูสฯัส้๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦวๅ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊ฯࠦสิฬฺ๎฾ࠦร็ࠢอ฽๊๊ࠠษฯฮࠤๆ๐ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦร้ࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะใหสࠣีุอไสࠢ็่๊ฮัๆฮࠣฬฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧབྷ"))
	if choice==JhTts2R43AxkM8bYanKVy and qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨམ") not in MBwh2HtDEZSYxrCpd: DpzKcQfPAtHR = [HCiWF4jV1Q8(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩཙ")]+MBwh2HtDEZSYxrCpd
	elif choice==nyUIsfd53EGot9vbj0XDeq and DQIrVcKuY6bJv(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪཚ") in MBwh2HtDEZSYxrCpd:
		DpzKcQfPAtHR = MBwh2HtDEZSYxrCpd[:]
		DpzKcQfPAtHR.remove(fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫཛ"))
	if DpzKcQfPAtHR!=MBwh2HtDEZSYxrCpd:
		DpzKcQfPAtHR = str(DpzKcQfPAtHR).replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠧ࠭ࠢཛྷ"),l7kBpMw5Qn(u"࠭ࠢࠨཝ"))
		lfZmugQCFKLGT05AH29IsMiho = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(bcNqYtfET5l92dLGjyZSPe(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠩཞ")+DpzKcQfPAtHR+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡿࢀࠫཟ"))
		if showDialogs:
			if sTGtHVyhQ9cJU37zxo2O(u"ࠩࡷࡶࡺ࡫ࠧའ") in str(lfZmugQCFKLGT05AH29IsMiho): gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧཡ"))
			else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,iDhLkZS6XBagNCQfs9tq2(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩར"))
	return
def rKiEG68Zq3RcSxj5g():
	emIQYsN6huF = MMAUZiw4CoJ8.getSetting(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩལ"))
	message = iDhLkZS6XBagNCQfs9tq2(u"࠭วๅำๅ้ࠥอไๆฯาำࠥำวๅ์สࠤ์๎ࠠ࠻ࠢࠣࠤࠬཤ")+str(emIQYsN6huF)+gCkRKGhwcx26v(u"ࠧࠡ࡭ࡥࡴࡸ࠭ཥ") if emIQYsN6huF else bcNqYtfET5l92dLGjyZSPe(u"ࠨษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡ็อ์็็ษࠡฯส่๏อࠧས")
	message = E7r8hUCVvTiFQW0dBGXjxcy+message+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩ࡟ࡲ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅࠢฦ์ࠥะฺ๋์ิࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠨཧ")+XOVRfitWJP1zL3p2CMYF
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡧࡪࡴࡴࡦࡴࠪཨ"),TVnqDYzWoM2UfHp0dchJ(u"ࠫำื่อࠩཀྵ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬห๊ใษไࠫཪ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭สี฼ํ่ࠬཫ"),lFEvMxzSH2y7tYR,message+AGlW9LqKN3Dvo(u"ࠧ࡝ࡰ࡟ࡲฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤ์๐ฺࠠ็็๎ฮ๊ࠦใ๊่ࠤอํวࠡษ็ฬึ์วๆฮࠣฬฬิส๋ษิࠤศ฿ไ๊ࠢฯ์ิฯࠠๆฬ๋ๅึฯࠠๅำๅ้ࠥอไอ๊าอࠥอไั์ࠣห๋ะࠠหฯาำ์ࠦแ๋๊ࠢิ์ࠦวๅึสุฮࠦ࠮࠯๋๋ࠢีอࠠๆ฻้ห์ูࠦ็ั่หࠥะโ้็ࠣห๋ะࠠษฬื฾๏๊ࠠโ์า๎ํࠦแศ่ࠣห้ฮั็ษ่ะ๊ࠥๆࠡ์ึวฺ้้่ࠠࠣห้า่ะหࠣห้ะ๊ࠡฬิ๎ิํวࠡๆฦ๊ࠥอไษำ้ห๊าࠠิ๊ไࠤ๏ิสศำࠣห้า่ะหࠣวํะ่ๆษอ๎่๐วࠡ࠰࠱ࠤ฾๊ๅศࠢส๊์๊ࠦอสࠣหำะ๊ศำࠣี็๋ࠠอ๊าอࠥ฻ฺ๋ำࠣษีอࠠไษ้ฮࠥอไฦ่อี๋ะฺ่ࠠา็ࠥฮื๋ศฬࠤศ๎ࠠใๆํ่ฮ࠭ཬ"))
	if wE4CUOSMetbRmWB6Pn in [-HCiWF4jV1Q8(u"࠳ቛ"),Ns6AJKH7DGpr19Wl5C3nF(u"࠳ቜ")]: return
	if wE4CUOSMetbRmWB6Pn==iDhLkZS6XBagNCQfs9tq2(u"࠵ቝ"):
		emIQYsN6huF = SebHIf2jL1TBgrMKJu
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊ใษไࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫ཭"))
	else:
		items = [AGlW9LqKN3Dvo(u"ࠩ࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫ཮"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠪ࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ཯"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭཰"),l7kBpMw5Qn(u"ࠬ࠷࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཱ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࠱࠳࠷࠳ࠤࡰࡨࡰࡴིࠩ"),l7kBpMw5Qn(u"ࠧ࠲࠷࠳࠴ࠥࡱࡢࡱࡵཱིࠪ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨ࠳࠺࠹࠵ࠦ࡫ࡣࡲࡶུࠫ"),gCkRKGhwcx26v(u"ࠩ࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷཱུࠬ"),gCkRKGhwcx26v(u"ࠪ࠶࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ྲྀ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫ࠸࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧཷ"),czvu7VQCZodkMf(u"ࠬ࠹࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨླྀ"),ASkvf27etUK0(u"࠭࠴࠱࠲࠳ࠤࡰࡨࡰࡴࠩཹ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠵࠷࠳࠴ࠥࡱࡢࡱࡵེࠪ"),czvu7VQCZodkMf(u"ࠨ࠷࠳࠴࠵ࠦ࡫ࡣࡲࡶཻࠫ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࠹࠴࠵࠶ࠠ࡬ࡤࡳࡷོࠬ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪ࠻࠵࠶࠰ࠡ࡭ࡥࡴࡸཽ࠭"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫ࠽࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧཾ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࠿࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཿ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭࠱࠱࠲࠳࠴ࠥࡱࡢࡱࡵྀࠪ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧ࠲࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶཱྀࠫ"),ALwOspNtXxZrz3PEKku(u"ࠨ࠳࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬྂ"),gCkRKGhwcx26v(u"ࠩ࠼࠽࠾࠿࠹ࠡ࡭ࡥࡴࡸ࠭ྃ")]
		QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG(HCiWF4jV1Q8(u"ࠪหำะัࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡษ็้๋อำษห྄ࠪ"),items)
		if QQea1XbjZDEMhp==-wPnfgxKZdAv6T10(u"࠶቞"): return
		emIQYsN6huF = str(items[QQea1XbjZDEMhp][:-Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠻቟")])
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"๋ࠫาอหࠢ฼้้๐ษࠡฬื฾๏๊้ࠠฬะำ๏ีࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࡠࡳࡢ࡮ࠨ྅")+E7r8hUCVvTiFQW0dBGXjxcy+emIQYsN6huF+Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࠦ࡫ࡣࡲࡶࠫ྆")+XOVRfitWJP1zL3p2CMYF)
	MMAUZiw4CoJ8.setSetting(AGlW9LqKN3Dvo(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ྇"),emIQYsN6huF)
	return
def SxeODtAwbILFXoQy62YrWJ3R1gPTUN(VzOM30UGKlQvF2k4xt=mrhSYXH2P8bO3eJAa9n):
	LlCrcJivEjzYs9u73M4 = LL1ZoBAmMuEwq()
	UevbqyjO89H5BTCdzfpEZYSXFP0G2N = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ์฼้้࠭ྈ") if LlCrcJivEjzYs9u73M4 else xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใ่ࠢฮํ่แࠨྉ")
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(ALwOspNtXxZrz3PEKku(u"ࠩࡦࡩࡳࡺࡥࡳࠩྊ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪาึ๎ฬࠨྋ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫส๐โศใࠪྌ"),DQIrVcKuY6bJv(u"ࠬะิ฻์็ࠫྍ"),lFEvMxzSH2y7tYR,E7r8hUCVvTiFQW0dBGXjxcy+UevbqyjO89H5BTCdzfpEZYSXFP0G2N+XOVRfitWJP1zL3p2CMYF+u43PVWjh7t9YwI+HADrRCz9QgU4xudPJIqYb70(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭ྎ"))
	if wE4CUOSMetbRmWB6Pn==nyUIsfd53EGot9vbj0XDeq: O4ObE1qjpmvBIZn5dPT67Xfzc9A = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(ALwOspNtXxZrz3PEKku(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬྏ"))
	elif wE4CUOSMetbRmWB6Pn==JhTts2R43AxkM8bYanKVy: O4ObE1qjpmvBIZn5dPT67Xfzc9A = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧྐ"))
	if wE4CUOSMetbRmWB6Pn in [nyUIsfd53EGot9vbj0XDeq,JhTts2R43AxkM8bYanKVy]:
		if iDhLkZS6XBagNCQfs9tq2(u"ࠩࡷࡶࡺ࡫ࠧྑ") in str(O4ObE1qjpmvBIZn5dPT67Xfzc9A): gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,zpx2fPNKk6Ms38eD1vcO(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧྒ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HCiWF4jV1Q8(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩྒྷ"))
	return
def PP5OKYfmdngbcl0LW():
	url = qFsuKN7ngp.SITESURLS[l7kBpMw5Qn(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧྔ")][ALwOspNtXxZrz3PEKku(u"࠰በ")]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡇࡆࡖࠪྕ"),url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬྖ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	sCwoI6tacuXvUAqOb3 = X2XorVqHjLkWeCchY4u9fSz.findall(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨྗ"),LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	sCwoI6tacuXvUAqOb3 = sorted(sCwoI6tacuXvUAqOb3,reverse=BBX9RAuxnyGZ4WIF2TrhYeom3)
	QQea1XbjZDEMhp = KKxHoL6iq4dst79zCUP215lYgMOreG(HCiWF4jV1Q8(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫ྘"),sCwoI6tacuXvUAqOb3)
	if QQea1XbjZDEMhp>=v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠱ቡ"):
		yevr71ItSRqEgTcbYjUOwoNkufQp6 = url.rsplit(TVnqDYzWoM2UfHp0dchJ(u"ࠪ࠳ࠬྙ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠳ቢ"))[ALwOspNtXxZrz3PEKku(u"࠳ባ")]+fp6KV7DlS8QYniUczHdmZChL(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬྚ")+sCwoI6tacuXvUAqOb3[QQea1XbjZDEMhp]+AGlW9LqKN3Dvo(u"ࠬ࠴ࡺࡪࡲࠪྛ")
		succeeded = BI3uEGAW19xTZwi87(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫྜ"),yevr71ItSRqEgTcbYjUOwoNkufQp6,BBX9RAuxnyGZ4WIF2TrhYeom3)
		if succeeded:
			MMAUZiw4CoJ8.setSetting(uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫྜྷ"),SebHIf2jL1TBgrMKJu)
			sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨฬ่ࠤฯัศ๋ฬࠣษฺีวาࠢๅำ๏๋ࠠๅๆหี๋อๅอࠢ࠱࠲๊ࠥใ็ࠢหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬฯำฯ๋อࠣะ๊๐ูࠡษ็ฬึอๅอࠢหหุะฮะษ่ࠤวิัࠡวุำฬืࠠๆฬ๋ๅึࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅ้ำหࠥอไษำ้ห๊าࠠภࠣࠤࠫྞ"))
			if sLhog1knUIF4fNOjY2zJqQ7cxArb: GnQhi9CoBMkX7(Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧྟ"),BBX9RAuxnyGZ4WIF2TrhYeom3,BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def APY9XQqg62N37yweKLi1Cd():
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,uqLUBHepfM3l6AyIzTJh80a(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭ྠ"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb:
		MMAUZiw4CoJ8.setSetting(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩྡ"),SebHIf2jL1TBgrMKJu)
		MMAUZiw4CoJ8.setSetting(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬྡྷ"),SebHIf2jL1TBgrMKJu)
		MMAUZiw4CoJ8.setSetting(wPnfgxKZdAv6T10(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪྣ"),SebHIf2jL1TBgrMKJu)
		MMAUZiw4CoJ8.setSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨྤ"),SebHIf2jL1TBgrMKJu)
		MMAUZiw4CoJ8.setSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪྥ"),SebHIf2jL1TBgrMKJu)
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l7kBpMw5Qn(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫྦ"))
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def eMYjWPac0KBIrQ7D6h4NRi():
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,HADrRCz9QgU4xudPJIqYb70(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨྦྷ"),VOALf8iYEnMdK0g(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧྨ"))
	kkHrpxZmdYPM = Ta7zPgmdrNZIvqxo5(mrhSYXH2P8bO3eJAa9n)
	NaSIYnH51CcudMtvV2hi87Lf = u43PVWjh7t9YwI
	m5rLORKtck8PNQndMvq7U9 = QNR6tCevIGEZKX3rAVsP+ASkvf27etUK0(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩྩ")+XOVRfitWJP1zL3p2CMYF
	ZPen0vQk1Hdh6gyLSO3KERiMaGqX = u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+wPnfgxKZdAv6T10(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪྪ")+XOVRfitWJP1zL3p2CMYF+vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࡝ࡰ࡟ࡲࠬྫ")
	for id,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ESvoylf2GA5ni8HXstaDcF43,rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq,reason in reversed(kkHrpxZmdYPM):
		if id==vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࠲ࠪྫྷ"):
			OqIAWEyTkJrhaL8s7gb,RRQeJupBdtIogH2MNiK = rtfbXCjOD8pdgFSn7zTous2wY5y.split(uqLUBHepfM3l6AyIzTJh80a(u"ࠩ࡟ࡲࡀࡁࠧྭ"))
			continue
		if NaSIYnH51CcudMtvV2hi87Lf!=u43PVWjh7t9YwI: NaSIYnH51CcudMtvV2hi87Lf += ZPen0vQk1Hdh6gyLSO3KERiMaGqX
		ImZCD5zky03 = gCkRKGhwcx26v(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩྮ")+QNR6tCevIGEZKX3rAVsP+id+C3w6qluao7EzUxJgMGBtV(u"ࠫࠥࡀࠠࠨྯ")+ALwOspNtXxZrz3PEKku(u"ࠬอไิฦส่ࠥࡀࠠࠨྰ")+XOVRfitWJP1zL3p2CMYF+ESvoylf2GA5ni8HXstaDcF43
		nLsfxayhBYdjHovlORpe9uEm6SFAgc = Gykx0wL3XrlWaujsqKP9n2Q(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧྱ")+QNR6tCevIGEZKX3rAVsP+fp6KV7DlS8QYniUczHdmZChL(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪྲ")+XOVRfitWJP1zL3p2CMYF+rtfbXCjOD8pdgFSn7zTous2wY5y
		Wjq1b2FoladZ58nEiOGc = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࡝ࡕࡘࡑࡣࠧླ")+QNR6tCevIGEZKX3rAVsP+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩส่ำ฽รࠡ࠼ࠣࠫྴ")+XOVRfitWJP1zL3p2CMYF+gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq
		O4OUpIVQWSlBbkx5oqj = iDhLkZS6XBagNCQfs9tq2(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫྵ")+QNR6tCevIGEZKX3rAVsP+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭ྶ")+XOVRfitWJP1zL3p2CMYF+reason
		NaSIYnH51CcudMtvV2hi87Lf += ImZCD5zky03+nLsfxayhBYdjHovlORpe9uEm6SFAgc+u43PVWjh7t9YwI+m5rLORKtck8PNQndMvq7U9+u43PVWjh7t9YwI+Wjq1b2FoladZ58nEiOGc+O4OUpIVQWSlBbkx5oqj+u43PVWjh7t9YwI
	M8wEz43vLgdl(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡸࡩࡨࡪࡷࠫྷ"),RRQeJupBdtIogH2MNiK,NaSIYnH51CcudMtvV2hi87Lf,HCiWF4jV1Q8(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧྸ"))
	return
def ixVpUjGf5SQ(file):
	if file==NnA1JBy7DVvFqcm: oz7FxrDOEJIYHGmMv = DQIrVcKuY6bJv(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧྐྵ")
	elif file==dUj4HNoGp91APu6itnl3BCc: oz7FxrDOEJIYHGmMv = fp6KV7DlS8QYniUczHdmZChL(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨྺ")
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(l7kBpMw5Qn(u"ࠩࡦࡩࡳࡺࡥࡳࠩྻ"),TVnqDYzWoM2UfHp0dchJ(u"ุ้ࠪำࠧྼ"),sTGtHVyhQ9cJU37zxo2O(u"ࠫส฻ไศฯࠪ྽"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬิั้ฮࠪ྾"),lFEvMxzSH2y7tYR,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ྿")+oz7FxrDOEJIYHGmMv+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ࿀"))
	if wE4CUOSMetbRmWB6Pn==xxRyYsrSCzjifvH4cIqgldeOo(u"࠴ቤ"):
		if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(file):
			try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(file)
			except: pass
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ALwOspNtXxZrz3PEKku(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭࿁")+oz7FxrDOEJIYHGmMv)
	elif wE4CUOSMetbRmWB6Pn==xxRyYsrSCzjifvH4cIqgldeOo(u"࠶ብ"):
		data = Pvf1zMmXRJnipdHDbFeV4r(file)
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ࿂")+oz7FxrDOEJIYHGmMv)
	return
def kS50JqBhl81Fb():
	if zzGetSI9yqnbZh<j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠷࠸ቦ"):
		FKe1TxU27G4SPo8hDER = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭࿃")+str(zzGetSI9yqnbZh)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ࿄")
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
		return
	xbpe62PFARlCEfW = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(fp6KV7DlS8QYniUczHdmZChL(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ࿅"))
	cjgL0TptRom1DZeFIlC6kM5K = RCHMOS7Qre9bm([TVnqDYzWoM2UfHp0dchJ(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࿆ࠬ")])
	fLDQYSwx2chU,fTnMltcwxdBh9Z8QFsGEqV7Ak,cITdbviEeBq6ZPYzHNrs0j,ooCX9JQZ8pgUBLx6fvWaPR,pPI26dcUx01QaqVFfTn9,DV2rvjxntu,HKDqLNUXlsb2 = cjgL0TptRom1DZeFIlC6kM5K[HADrRCz9QgU4xudPJIqYb70(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿇")]
	if fLDQYSwx2chU or t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ࿈") not in str(xbpe62PFARlCEfW):
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ࿉"))
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = CQPERlTrs3S1md()
		if not Vsn3f1CA8FIu0krNclSDWP5v9YQaE: return
	nX1fcGsDgR53yQkiUB(BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def nX1fcGsDgR53yQkiUB(showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3):
	xbpe62PFARlCEfW = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(zpx2fPNKk6Ms38eD1vcO(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭࿊"))
	if wPnfgxKZdAv6T10(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ࿋") not in str(xbpe62PFARlCEfW):
		if showDialogs:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,zpx2fPNKk6Ms38eD1vcO(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ࿌"))
		return
	D6Dzew7Zsbtg2ArW04npUQPOMFNko = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,DQIrVcKuY6bJv(u"࠭ࡡࡥࡦࡲࡲࡸ࠭࿍"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿎"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨ࠹࠵࠴ࡵ࠭࿏"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪ࿐"))
	if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(D6Dzew7Zsbtg2ArW04npUQPOMFNko): return
	zOWDhrxp8XRV5jFuT1 = open(D6Dzew7Zsbtg2ArW04npUQPOMFNko,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡶࡧ࠭࿑")).read()
	if QBOMjKifEAFD: zOWDhrxp8XRV5jFuT1 = zOWDhrxp8XRV5jFuT1.decode(Tv08xsf9HOqunIVUPdK1)
	HkCmGbips9yaI = X2XorVqHjLkWeCchY4u9fSz.findall(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ࿒"),zOWDhrxp8XRV5jFuT1,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	fcWBXkd9j3,OhEuG5lyF8AepHa = HkCmGbips9yaI[wvkDqmNZlJU52isXo]
	Xein8UzfCRFljg = l7kBpMw5Qn(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭࿓")+fcWBXkd9j3+bcNqYtfET5l92dLGjyZSPe(u"࠭ࠬࠨ࿔")+OhEuG5lyF8AepHa+ASkvf27etUK0(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ࿕")
	if showDialogs:
		Uo73DPymTLvSMHaCfejB = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(ASkvf27etUK0(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭࿖"))
		if Uo73DPymTLvSMHaCfejB==HADrRCz9QgU4xudPJIqYb70(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ࿗"): eqmvUIDz5M = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪๆํอฦๆࠢส่่ะวษหࠪ࿘")
		elif Uo73DPymTLvSMHaCfejB==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ࿙"): eqmvUIDz5M = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ࿚")
		else: eqmvUIDz5M = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭โ้ษษ้ࠥษฮา๋ࠪ࿛")
		wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(wPnfgxKZdAv6T10(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿜"),C3w6qluao7EzUxJgMGBtV(u"ࠨไ๋หห๋ࠠฤะิํࠬ࿝"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ࿞"),HADrRCz9QgU4xudPJIqYb70(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ࿟"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ࿠")+eqmvUIDz5M,vMhFypGLHZJbdX4O7oc3W8x(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨ࿡")+QNR6tCevIGEZKX3rAVsP+ALwOspNtXxZrz3PEKku(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪ࿢")+XOVRfitWJP1zL3p2CMYF)
		if wE4CUOSMetbRmWB6Pn==l7kBpMw5Qn(u"࠱ቧ"): YY6z0r3F9WOcIHflZP1LgC = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ࿣")
		elif wE4CUOSMetbRmWB6Pn==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠳ቨ"): YY6z0r3F9WOcIHflZP1LgC = HADrRCz9QgU4xudPJIqYb70(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ࿤")
		else: YY6z0r3F9WOcIHflZP1LgC = SebHIf2jL1TBgrMKJu
	else:
		Uo73DPymTLvSMHaCfejB = MMAUZiw4CoJ8.getSetting(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ࿥"))
		if   Uo73DPymTLvSMHaCfejB==SebHIf2jL1TBgrMKJu: wE4CUOSMetbRmWB6Pn = zpx2fPNKk6Ms38eD1vcO(u"࠲ቩ")
		elif Uo73DPymTLvSMHaCfejB==Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭࿦"): wE4CUOSMetbRmWB6Pn = C3w6qluao7EzUxJgMGBtV(u"࠴ቪ")
		elif Uo73DPymTLvSMHaCfejB==l7kBpMw5Qn(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ࿧"): wE4CUOSMetbRmWB6Pn = xxRyYsrSCzjifvH4cIqgldeOo(u"࠶ቫ")
		YY6z0r3F9WOcIHflZP1LgC = Uo73DPymTLvSMHaCfejB
	if   wE4CUOSMetbRmWB6Pn==HADrRCz9QgU4xudPJIqYb70(u"࠵ቬ"): ZtW7yDQ01cr6UwS5H = ALwOspNtXxZrz3PEKku(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩ࿨")
	elif wE4CUOSMetbRmWB6Pn==Izy1PvclrYx4eSVWn0L5phZbq(u"࠷ቭ"): ZtW7yDQ01cr6UwS5H = vMhFypGLHZJbdX4O7oc3W8x(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪ࿩")
	elif wE4CUOSMetbRmWB6Pn==l7kBpMw5Qn(u"࠲ቮ"): ZtW7yDQ01cr6UwS5H = HADrRCz9QgU4xudPJIqYb70(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫ࿪")
	else: return
	MMAUZiw4CoJ8.setSetting(wPnfgxKZdAv6T10(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭࿫"),YY6z0r3F9WOcIHflZP1LgC)
	MJAD2VFkKsjd0yiCn = TVnqDYzWoM2UfHp0dchJ(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ࿬")+ZtW7yDQ01cr6UwS5H+DQIrVcKuY6bJv(u"ࠪ࠰ࠬ࿭")+OhEuG5lyF8AepHa+iDhLkZS6XBagNCQfs9tq2(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭࿮")
	WCdaRXT1Kty2vmHOkNgbo7zcMp = zOWDhrxp8XRV5jFuT1.replace(Xein8UzfCRFljg,MJAD2VFkKsjd0yiCn)
	if QBOMjKifEAFD: WCdaRXT1Kty2vmHOkNgbo7zcMp = WCdaRXT1Kty2vmHOkNgbo7zcMp.encode(Tv08xsf9HOqunIVUPdK1)
	open(D6Dzew7Zsbtg2ArW04npUQPOMFNko,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡽࡢࠨ࿯")).write(WCdaRXT1Kty2vmHOkNgbo7zcMp)
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,bcNqYtfET5l92dLGjyZSPe(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ࿰")+ZtW7yDQ01cr6UwS5H+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࠡ࡟ࠪ࿱"))
	if showDialogs: if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(gCkRKGhwcx26v(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ࿲"))
	return
def rru21CMlfSTNXdei():
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,czvu7VQCZodkMf(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ࿳"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==ALwOspNtXxZrz3PEKku(u"࠲ቯ"): D17MRSNzQH()
	return
def xkY4yGJS8rIozj1qgdvf():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l7kBpMw5Qn(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭࿴"))
	return
def mRknYiNMy0x():
	ImZCD5zky03 = QNR6tCevIGEZKX3rAVsP+VOALf8iYEnMdK0g(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨ࿵")+XOVRfitWJP1zL3p2CMYF
	ImZCD5zky03 += ALwOspNtXxZrz3PEKku(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫ࿶")
	ImZCD5zky03 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷࠫ࿷")+XOVRfitWJP1zL3p2CMYF
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = QNR6tCevIGEZKX3rAVsP+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨ࿸")+XOVRfitWJP1zL3p2CMYF
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += HADrRCz9QgU4xudPJIqYb70(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬ࿹")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩ࿺")+XOVRfitWJP1zL3p2CMYF
	FKe1TxU27G4SPo8hDER = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ࿻")+ImZCD5zky03+AGlW9LqKN3Dvo(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ࿼")+nLsfxayhBYdjHovlORpe9uEm6SFAgc
	M8wEz43vLgdl(Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡸࡩࡨࡪࡷࠫ࿽"),SebHIf2jL1TBgrMKJu,FKe1TxU27G4SPo8hDER)
	return
def UrNpagjyiLOqhPT6VMB8XGv74AQt(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7):
	zGBSOdsWh8uLHbfw9qmxlioR7tDpy(RycFd7wZBiNhJjOPIGKp)
	kkHrpxZmdYPM = Ta7zPgmdrNZIvqxo5(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7)
	for DDj8NqZIHVmeMUTk in [ASkvf27etUK0(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ࿾"),DQIrVcKuY6bJv(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ࿿"),HCiWF4jV1Q8(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭က"),VOALf8iYEnMdK0g(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨခ")]:
		if DDj8NqZIHVmeMUTk in qFsuKN7ngp.SEND_THESE_EVENTS: qFsuKN7ngp.SEND_THESE_EVENTS.remove(DDj8NqZIHVmeMUTk)
	zzcbV5F4iSjM2(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ဂ"))
	id,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ESvoylf2GA5ni8HXstaDcF43,rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq,reason = kkHrpxZmdYPM[wvkDqmNZlJU52isXo]
	OqIAWEyTkJrhaL8s7gb,RRQeJupBdtIogH2MNiK = rtfbXCjOD8pdgFSn7zTous2wY5y.split(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡡࡴ࠻࠼ࠩဃ"))
	nLsfxayhBYdjHovlORpe9uEm6SFAgc,Wjq1b2FoladZ58nEiOGc,O4OUpIVQWSlBbkx5oqj = gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq.split(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡢ࡮࠼࠽ࠪင"))
	TYVdfat34lk2OnM89BKRwi1XJ = BBX9RAuxnyGZ4WIF2TrhYeom3
	while TYVdfat34lk2OnM89BKRwi1XJ:
		hhaz3iWVYpSN7qBPHG0vfrxtscTL2o = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"࠭ฮา๊ฯࠫစ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ဆ"),HADrRCz9QgU4xudPJIqYb70(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩဇ"),HCiWF4jV1Q8(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩဈ"),nLsfxayhBYdjHovlORpe9uEm6SFAgc)
		if hhaz3iWVYpSN7qBPHG0vfrxtscTL2o==l7kBpMw5Qn(u"࠴ተ"): jYUVH6OnsA = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪ฽ํีษࠨဉ"),SebHIf2jL1TBgrMKJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫည"),Wjq1b2FoladZ58nEiOGc,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩဋ"))
		elif hhaz3iWVYpSN7qBPHG0vfrxtscTL2o==AGlW9LqKN3Dvo(u"࠴ቱ"): CQgMI2jYDy4F()
		else: TYVdfat34lk2OnM89BKRwi1XJ = mrhSYXH2P8bO3eJAa9n
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def DX7IhEGYMzWe9qA():
	Q7EINd1XV6MliUczOr4vtfjs3APg()
	YjMBFHJVIDZ12Tz7ovrlQXqR5Kit = MMAUZiw4CoJ8.getSetting(HCiWF4jV1Q8(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬဌ"))
	FKe1TxU27G4SPo8hDER = {}
	FKe1TxU27G4SPo8hDER[Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡂࡗࡗࡓࠬဍ")] = iDhLkZS6XBagNCQfs9tq2(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧဎ")
	FKe1TxU27G4SPo8hDER[ALwOspNtXxZrz3PEKku(u"ࠩࡖࡘࡔࡖࠧဏ")] = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩတ")
	FKe1TxU27G4SPo8hDER[Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬထ")] = vMhFypGLHZJbdX4O7oc3W8x(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ဒ")+str(jCPlGJAyS97u8ROadFzX/DQIrVcKuY6bJv(u"࠺࠵ቲ"))+xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࠠะไํๆฮࠦแใูࠪဓ")
	nnCLF4srqhfH = FKe1TxU27G4SPo8hDER[YjMBFHJVIDZ12Tz7ovrlQXqR5Kit]
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"ࠧไษืࠤࠬန")+str(jCPlGJAyS97u8ROadFzX/ALwOspNtXxZrz3PEKku(u"࠻࠶ታ"))+vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࠢาๆ๏่ษࠨပ"),wPnfgxKZdAv6T10(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨဖ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪษ๏่วโࠢๆห๊๊ࠧဗ"),nnCLF4srqhfH,DQIrVcKuY6bJv(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧဘ"))
	if wE4CUOSMetbRmWB6Pn==zpx2fPNKk6Ms38eD1vcO(u"࠶ቴ"): d8Lgy3I2DctzX7GEVbPeZh = ALwOspNtXxZrz3PEKku(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭မ")
	elif wE4CUOSMetbRmWB6Pn==Gykx0wL3XrlWaujsqKP9n2Q(u"࠱ት"): d8Lgy3I2DctzX7GEVbPeZh = wPnfgxKZdAv6T10(u"࠭ࡁࡖࡖࡒࠫယ")
	elif wE4CUOSMetbRmWB6Pn==Gykx0wL3XrlWaujsqKP9n2Q(u"࠳ቶ"): d8Lgy3I2DctzX7GEVbPeZh = ASkvf27etUK0(u"ࠧࡔࡖࡒࡔࠬရ")
	else: d8Lgy3I2DctzX7GEVbPeZh = SebHIf2jL1TBgrMKJu
	if d8Lgy3I2DctzX7GEVbPeZh:
		MMAUZiw4CoJ8.setSetting(fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧလ"),d8Lgy3I2DctzX7GEVbPeZh)
		ez5Wi3wmGPoYtXH = FKe1TxU27G4SPo8hDER[d8Lgy3I2DctzX7GEVbPeZh]
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ez5Wi3wmGPoYtXH)
	return
def Xcbn7RKDCNiGZEVfSFyOl9Mxz6B():
	FKe1TxU27G4SPo8hDER = {}
	FKe1TxU27G4SPo8hDER[HADrRCz9QgU4xudPJIqYb70(u"ࠩࡄ࡙࡙ࡕࠧဝ")] = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨသ")
	FKe1TxU27G4SPo8hDER[TVnqDYzWoM2UfHp0dchJ(u"ࠫࡆ࡙ࡋࠨဟ")] = wPnfgxKZdAv6T10(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩဠ")
	FKe1TxU27G4SPo8hDER[wPnfgxKZdAv6T10(u"࠭ࡓࡕࡑࡓࠫအ")] = HCiWF4jV1Q8(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪဢ")
	TQVNY4udi7GlUIeCZc9yfBWKgMjaL = MMAUZiw4CoJ8.getSetting(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨဣ"))
	YjMBFHJVIDZ12Tz7ovrlQXqR5Kit = MMAUZiw4CoJ8.getSetting(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬဤ"))
	nnCLF4srqhfH = FKe1TxU27G4SPo8hDER[YjMBFHJVIDZ12Tz7ovrlQXqR5Kit]+TQVNY4udi7GlUIeCZc9yfBWKgMjaL
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨဥ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪဦ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬห๊ใษไࠤ่อๅๅࠩဧ"),nnCLF4srqhfH,AGlW9LqKN3Dvo(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪဨ"))
	if wE4CUOSMetbRmWB6Pn==sTGtHVyhQ9cJU37zxo2O(u"࠲ቷ"): d8Lgy3I2DctzX7GEVbPeZh = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡂࡕࡎࠫဩ")
	elif wE4CUOSMetbRmWB6Pn==czvu7VQCZodkMf(u"࠴ቸ"): d8Lgy3I2DctzX7GEVbPeZh = sTGtHVyhQ9cJU37zxo2O(u"ࠨࡃࡘࡘࡔ࠭ဪ")
	elif wE4CUOSMetbRmWB6Pn==NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶ቹ"): d8Lgy3I2DctzX7GEVbPeZh = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡖࡘࡔࡖࠧါ")
	if wE4CUOSMetbRmWB6Pn in [NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶ቻ"),ASkvf27etUK0(u"࠶ቺ")]:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ"),HADrRCz9QgU4xudPJIqYb70(u"ุࠫ๐ัโำ࠽ࠤࠬိ")+qFsuKN7ngp.DNS_SERVERS[nyUIsfd53EGot9vbj0XDeq],uqLUBHepfM3l6AyIzTJh80a(u"ู๊ࠬาใิ࠾ࠥ࠭ီ")+qFsuKN7ngp.DNS_SERVERS[wvkDqmNZlJU52isXo],SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬု"))
		if sLhog1knUIF4fNOjY2zJqQ7cxArb==HCiWF4jV1Q8(u"࠱ቼ"): iBh7RYSxUfWzVa2Jb = qFsuKN7ngp.DNS_SERVERS[wvkDqmNZlJU52isXo]
		else: iBh7RYSxUfWzVa2Jb = qFsuKN7ngp.DNS_SERVERS[nyUIsfd53EGot9vbj0XDeq]
	elif wE4CUOSMetbRmWB6Pn==AGlW9LqKN3Dvo(u"࠳ች"): iBh7RYSxUfWzVa2Jb = SebHIf2jL1TBgrMKJu
	else: d8Lgy3I2DctzX7GEVbPeZh = SebHIf2jL1TBgrMKJu
	if d8Lgy3I2DctzX7GEVbPeZh:
		MMAUZiw4CoJ8.setSetting(ASkvf27etUK0(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪူ"),d8Lgy3I2DctzX7GEVbPeZh)
		MMAUZiw4CoJ8.setSetting(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨေ"),iBh7RYSxUfWzVa2Jb)
		ez5Wi3wmGPoYtXH = FKe1TxU27G4SPo8hDER[d8Lgy3I2DctzX7GEVbPeZh]+iBh7RYSxUfWzVa2Jb
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ez5Wi3wmGPoYtXH)
	return
def xLkKiDtd0HC6():
	YjMBFHJVIDZ12Tz7ovrlQXqR5Kit = MMAUZiw4CoJ8.getSetting(czvu7VQCZodkMf(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧဲ"))
	FKe1TxU27G4SPo8hDER = {}
	FKe1TxU27G4SPo8hDER[VOALf8iYEnMdK0g(u"ࠪࡅ࡚࡚ࡏࠨဳ")] = DQIrVcKuY6bJv(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬဴ")
	FKe1TxU27G4SPo8hDER[Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡇࡓࡌࠩဵ")] = HCiWF4jV1Q8(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧံ")
	FKe1TxU27G4SPo8hDER[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡔࡖࡒࡔ့ࠬ")] = fp6KV7DlS8QYniUczHdmZChL(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪး")
	nnCLF4srqhfH = FKe1TxU27G4SPo8hDER[YjMBFHJVIDZ12Tz7ovrlQXqR5Kit]
	wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,czvu7VQCZodkMf(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯ္ࠧ"),l7kBpMw5Qn(u"ࠪฮูเ๊ๅࠢอ่็อฦ်๋ࠩ"),l7kBpMw5Qn(u"ࠫส๐โศใࠣ็ฬ๋ไࠨျ"),nnCLF4srqhfH,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨြ"))
	if wE4CUOSMetbRmWB6Pn==ASkvf27etUK0(u"࠲ቾ"): d8Lgy3I2DctzX7GEVbPeZh = bcNqYtfET5l92dLGjyZSPe(u"࠭ࡁࡔࡍࠪွ")
	elif wE4CUOSMetbRmWB6Pn==zpx2fPNKk6Ms38eD1vcO(u"࠴ቿ"): d8Lgy3I2DctzX7GEVbPeZh = AGlW9LqKN3Dvo(u"ࠧࡂࡗࡗࡓࠬှ")
	elif wE4CUOSMetbRmWB6Pn==fp6KV7DlS8QYniUczHdmZChL(u"࠶ኀ"): d8Lgy3I2DctzX7GEVbPeZh = wPnfgxKZdAv6T10(u"ࠨࡕࡗࡓࡕ࠭ဿ")
	else: d8Lgy3I2DctzX7GEVbPeZh = SebHIf2jL1TBgrMKJu
	if d8Lgy3I2DctzX7GEVbPeZh:
		MMAUZiw4CoJ8.setSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ၀"),d8Lgy3I2DctzX7GEVbPeZh)
		ez5Wi3wmGPoYtXH = FKe1TxU27G4SPo8hDER[d8Lgy3I2DctzX7GEVbPeZh]
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ez5Wi3wmGPoYtXH)
	return
def vCSp54h1JnN7W9KOd8wtXlaRf():
	nzZt4wRlgBL8 = MMAUZiw4CoJ8.getSetting(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ၁"))
	if nzZt4wRlgBL8==iDhLkZS6XBagNCQfs9tq2(u"ࠫࡘ࡚ࡏࡑࠩ၂"): header = AGlW9LqKN3Dvo(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ၃")
	else: header = qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ၄")
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧฦ์ๅหๆ࠭၅"),wPnfgxKZdAv6T10(u"ࠨฬไ฽๏๊ࠧ၆"),header,iDhLkZS6XBagNCQfs9tq2(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭၇"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==-NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶ኁ"): return
	elif sLhog1knUIF4fNOjY2zJqQ7cxArb:
		MMAUZiw4CoJ8.setSetting(VOALf8iYEnMdK0g(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ၈"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡆ࡛ࡔࡐࠩ၉"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HADrRCz9QgU4xudPJIqYb70(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ၊"))
	else:
		MMAUZiw4CoJ8.setSetting(ASkvf27etUK0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭။"),AGlW9LqKN3Dvo(u"ࠧࡔࡖࡒࡔࠬ၌"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ၍"))
	return
def p9h8MwzJrT(Yg36raSGA02uUXEPMF7itZd9KcWf):
	if Yg36raSGA02uUXEPMF7itZd9KcWf!=SebHIf2jL1TBgrMKJu:
		Yg36raSGA02uUXEPMF7itZd9KcWf = rrHKfkJjxnw5gCR4pcGUqb8BXSzdL(Yg36raSGA02uUXEPMF7itZd9KcWf)
		Yg36raSGA02uUXEPMF7itZd9KcWf = Yg36raSGA02uUXEPMF7itZd9KcWf.decode(Tv08xsf9HOqunIVUPdK1).encode(Tv08xsf9HOqunIVUPdK1)
		bzm4Erfg2BlnHMyAqR9u = czvu7VQCZodkMf(u"࠷࠰࠲࠲࠶ኂ")
		jiceYtxZk6gVURuAvsz = G5OVsSktWRJQu8h4T.Window(bzm4Erfg2BlnHMyAqR9u)
		jiceYtxZk6gVURuAvsz.getControl(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠳࠲࠳ኃ")).setLabel(Yg36raSGA02uUXEPMF7itZd9KcWf)
	return
a87Kvm9gYSODAsRzyw3UoZ10pc = [
			 l7kBpMw5Qn(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢ၎")
			,ALwOspNtXxZrz3PEKku(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭၏")
			,fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ၐ")
			,czvu7VQCZodkMf(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧၑ")
			,tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧၒ")
			,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩၓ")
			,DQIrVcKuY6bJv(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧၔ")+vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࠦࠫၕ")+AGlW9LqKN3Dvo(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩၖ")
			,iDhLkZS6XBagNCQfs9tq2(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧၗ")
			,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨၘ")
			,VOALf8iYEnMdK0g(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧၙ")
			,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧ࡟ࡠࡡࡢࡣ࠭ၚ")
			,VOALf8iYEnMdK0g(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ၛ")
			,bcNqYtfET5l92dLGjyZSPe(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬၜ")
			,l7kBpMw5Qn(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨၝ")
			]
def TcOJwazbDi05EuNe(byUztE9qAGgCOlov8RB):
	if gCkRKGhwcx26v(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩၞ") in byUztE9qAGgCOlov8RB and Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၟ") in byUztE9qAGgCOlov8RB: return BBX9RAuxnyGZ4WIF2TrhYeom3
	for Yg36raSGA02uUXEPMF7itZd9KcWf in a87Kvm9gYSODAsRzyw3UoZ10pc:
		if Yg36raSGA02uUXEPMF7itZd9KcWf in byUztE9qAGgCOlov8RB: return BBX9RAuxnyGZ4WIF2TrhYeom3
	return mrhSYXH2P8bO3eJAa9n
def vKPxCYXMJ6uhr(data):
	Ml0PQ4Cw6fFa1ybmXh = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠹ኅ") if QBOMjKifEAFD else wPnfgxKZdAv6T10(u"࠲࠷ኄ")
	data = data.replace(xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠴ኆ")*qE4nB3mKWHs,Ml0PQ4Cw6fFa1ybmXh*qE4nB3mKWHs)
	data = data.replace(VOALf8iYEnMdK0g(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬၠ"),iDhLkZS6XBagNCQfs9tq2(u"ࠧ࠻ࠢࠪၡ"))
	bIGXajdcK6PQBs = SebHIf2jL1TBgrMKJu
	for byUztE9qAGgCOlov8RB in data.splitlines():
		nncTmIeaM5b1HkA9h = X2XorVqHjLkWeCchY4u9fSz.findall(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧၢ"),byUztE9qAGgCOlov8RB,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if nncTmIeaM5b1HkA9h: byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(nncTmIeaM5b1HkA9h[wvkDqmNZlJU52isXo],SebHIf2jL1TBgrMKJu)
		bIGXajdcK6PQBs += u43PVWjh7t9YwI+byUztE9qAGgCOlov8RB
	return bIGXajdcK6PQBs
def akrE2X076qQKeLFsYSj(Wy7oUxkTXCg2cOw10dDZI):
	if ALwOspNtXxZrz3PEKku(u"ࠩࡒࡐࡉ࠭ၣ") in Wy7oUxkTXCg2cOw10dDZI:
		vCL51PYWyVQcjmIKoJXgtnANx0lU = DM3tJCGvZk0sn4brxShAHwWfgio
		header = C3w6qluao7EzUxJgMGBtV(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪၤ")
	else:
		vCL51PYWyVQcjmIKoJXgtnANx0lU = ASIWYZHDvLfX05Ghxj2qEiJuy4U6b
		header = AGlW9LqKN3Dvo(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫၥ")
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,header,xxRyYsrSCzjifvH4cIqgldeOo(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨၦ"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb!=C3w6qluao7EzUxJgMGBtV(u"࠵ኇ"): return
	YasPmkLM7qFX3eVTv8i65CA9U,VNz5CrbpgDoGWlZ2A1hvUw0M = [],Izy1PvclrYx4eSVWn0L5phZbq(u"࠵ኈ")
	size,count = q5WoBw7x9sIFDEt(vCL51PYWyVQcjmIKoJXgtnANx0lU)
	file = open(vCL51PYWyVQcjmIKoJXgtnANx0lU,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡲࡣࠩၧ"))
	if size>ASkvf27etUK0(u"࠱࠱࠲࠵࠴࠵ኊ"): file.seek(-Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠷࠰࠱࠳࠳࠴኉"),E2xjtKaMXdC3NDoTm7f5Wkev.SEEK_END)
	data = file.read()
	file.close()
	if QBOMjKifEAFD: data = data.decode(Tv08xsf9HOqunIVUPdK1)
	data = vKPxCYXMJ6uhr(data)
	P7SQWVY4x1vm9tnANdiB = data.split(u43PVWjh7t9YwI)
	for byUztE9qAGgCOlov8RB in reversed(P7SQWVY4x1vm9tnANdiB):
		MZ19WDBP03HsIg8bFGX5fSNz2cp6rn = TcOJwazbDi05EuNe(byUztE9qAGgCOlov8RB)
		if MZ19WDBP03HsIg8bFGX5fSNz2cp6rn: continue
		byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩၨ"),QNR6tCevIGEZKX3rAVsP+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫၩ")+XOVRfitWJP1zL3p2CMYF)
		byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩၪ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ၫ")+iDhLkZS6XBagNCQfs9tq2(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫၬ")+XOVRfitWJP1zL3p2CMYF)
		m2SWyvKUHsENRMFah5Axlnj = SebHIf2jL1TBgrMKJu
		WBtIiPD7RUXhOelNvVCFYHEm = X2XorVqHjLkWeCchY4u9fSz.findall(C3w6qluao7EzUxJgMGBtV(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬၭ"),byUztE9qAGgCOlov8RB,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if WBtIiPD7RUXhOelNvVCFYHEm:
			byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][wvkDqmNZlJU52isXo],WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq]).replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][JhTts2R43AxkM8bYanKVy],SebHIf2jL1TBgrMKJu)
			m2SWyvKUHsENRMFah5Axlnj = WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq]
		else:
			WBtIiPD7RUXhOelNvVCFYHEm = X2XorVqHjLkWeCchY4u9fSz.findall(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ၮ"),byUztE9qAGgCOlov8RB,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if WBtIiPD7RUXhOelNvVCFYHEm:
				byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq],SebHIf2jL1TBgrMKJu)
				m2SWyvKUHsENRMFah5Axlnj = WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][wvkDqmNZlJU52isXo]
		if m2SWyvKUHsENRMFah5Axlnj: byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(m2SWyvKUHsENRMFah5Axlnj,E7r8hUCVvTiFQW0dBGXjxcy+m2SWyvKUHsENRMFah5Axlnj+XOVRfitWJP1zL3p2CMYF)
		YasPmkLM7qFX3eVTv8i65CA9U.append(byUztE9qAGgCOlov8RB)
		if len(str(YasPmkLM7qFX3eVTv8i65CA9U))>DQIrVcKuY6bJv(u"࠶࠲࠴࠴࠵ኋ"): break
	YasPmkLM7qFX3eVTv8i65CA9U = reversed(YasPmkLM7qFX3eVTv8i65CA9U)
	RrwOD3FTaV2 = u43PVWjh7t9YwI.join(YasPmkLM7qFX3eVTv8i65CA9U)
	M8wEz43vLgdl(czvu7VQCZodkMf(u"ࠧ࡭ࡧࡩࡸࠬၯ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬၰ"),RrwOD3FTaV2,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬၱ"))
	return
def nFbZJXqSB640misAlepjzTIk():
	dzLJrAqOBuWVpbKaUtFijgnvXCDfeT = open(jwze0TH4ZKbrp,vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡶࡧ࠭ၲ")).read()
	if QBOMjKifEAFD: dzLJrAqOBuWVpbKaUtFijgnvXCDfeT = dzLJrAqOBuWVpbKaUtFijgnvXCDfeT.decode(Tv08xsf9HOqunIVUPdK1)
	dzLJrAqOBuWVpbKaUtFijgnvXCDfeT = dzLJrAqOBuWVpbKaUtFijgnvXCDfeT.replace(C3w6qluao7EzUxJgMGBtV(u"ࠫࡡࡺࠧၳ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧၴ"))
	cjgL0TptRom1DZeFIlC6kM5K = X2XorVqHjLkWeCchY4u9fSz.findall(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧၵ"),dzLJrAqOBuWVpbKaUtFijgnvXCDfeT,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for byUztE9qAGgCOlov8RB in cjgL0TptRom1DZeFIlC6kM5K:
		dzLJrAqOBuWVpbKaUtFijgnvXCDfeT = dzLJrAqOBuWVpbKaUtFijgnvXCDfeT.replace(byUztE9qAGgCOlov8RB,QNR6tCevIGEZKX3rAVsP+byUztE9qAGgCOlov8RB+XOVRfitWJP1zL3p2CMYF)
	zQgdTIC74ov(sTGtHVyhQ9cJU37zxo2O(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨၶ"),dzLJrAqOBuWVpbKaUtFijgnvXCDfeT)
	return
def CgDNiVkIEcqbwjP1LWB4():
	ImZCD5zky03 = sTGtHVyhQ9cJU37zxo2O(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪၷ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ၸ")
	Wjq1b2FoladZ58nEiOGc = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ၹ")
	FKe1TxU27G4SPo8hDER = ImZCD5zky03+uqLUBHepfM3l6AyIzTJh80a(u"ࠫ࠿ࠦࠧၺ")+nLsfxayhBYdjHovlORpe9uEm6SFAgc+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࠦ࠮ࠡࠩၻ")+Wjq1b2FoladZ58nEiOGc
	M8wEz43vLgdl(ASkvf27etUK0(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၼ"),lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪၽ"))
	return
def OmVwKTdykGa3xXsECzW(type,FKe1TxU27G4SPo8hDER,showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3,url=SebHIf2jL1TBgrMKJu,qh4B9VQZCbXr0DRknFmi7J6=SebHIf2jL1TBgrMKJu,Yg36raSGA02uUXEPMF7itZd9KcWf=SebHIf2jL1TBgrMKJu,MweoNQmW1hD8zOxcSlsFq496t=SebHIf2jL1TBgrMKJu):
	ggYWZeb94wjEaciK6p3tIylqBRmo = BBX9RAuxnyGZ4WIF2TrhYeom3
	if not qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW:
		if showDialogs:
			LImrP8VeDoTAHafyXv1id = (iDhLkZS6XBagNCQfs9tq2(u"ࠨษ็ื฼ื࠺ࠨၾ") in FKe1TxU27G4SPo8hDER and cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩส่๊้ว็࠼ࠪၿ") in FKe1TxU27G4SPo8hDER and fp6KV7DlS8QYniUczHdmZChL(u"ࠪห้๋ไโ࠼ࠪႀ") in FKe1TxU27G4SPo8hDER and C3w6qluao7EzUxJgMGBtV(u"ࠫฬ๊ฮุลࠪႁ") in FKe1TxU27G4SPo8hDER and bcNqYtfET5l92dLGjyZSPe(u"ࠬอไๆืาี࠿࠭ႂ") in FKe1TxU27G4SPo8hDER)
			if not LImrP8VeDoTAHafyXv1id: ggYWZeb94wjEaciK6p3tIylqBRmo = vvubxo631m2zYC(sTGtHVyhQ9cJU37zxo2O(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ႃ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,AGlW9LqKN3Dvo(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫႄ"),FKe1TxU27G4SPo8hDER.replace(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨ࡞࡟ࡲࠬႅ"),u43PVWjh7t9YwI))
	elif showDialogs:
		FKe1TxU27G4SPo8hDER = HCiWF4jV1Q8(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩႆ")
		eK1RIonWBVy7D428L5zdhw3v = vvubxo631m2zYC(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡧࡪࡴࡴࡦࡴࠪႇ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,VOALf8iYEnMdK0g(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫႈ")+sTGtHVyhQ9cJU37zxo2O(u"ࠬࠦࠠ࠲࠱࠸ࠫႉ"),Izy1PvclrYx4eSVWn0L5phZbq(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫႊ"))
		SVTKQhLIxm6Ey2p0 = vvubxo631m2zYC(bcNqYtfET5l92dLGjyZSPe(u"ࠧࡤࡧࡱࡸࡪࡸࠧႋ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨႌ")+ALwOspNtXxZrz3PEKku(u"ࠩࠣࠤ࠷࠵࠵ࠨႍ"),l7kBpMw5Qn(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨႎ"))
		AyfRYVHpwFNaZQCg5mBLuds01 = vvubxo631m2zYC(vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႏ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ႐")+HCiWF4jV1Q8(u"࠭ࠠࠡ࠵࠲࠹ࠬ႑"),TVnqDYzWoM2UfHp0dchJ(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ႒"))
		tXsuFkj84l0NKCD3 = vvubxo631m2zYC(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ႓"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ႔")+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࠤࠥ࠺࠯࠶ࠩ႕"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ႖"))
		ggYWZeb94wjEaciK6p3tIylqBRmo = vvubxo631m2zYC(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ႗"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭႘")+ALwOspNtXxZrz3PEKku(u"ࠧࠡࠢ࠸࠳࠺࠭႙"),HADrRCz9QgU4xudPJIqYb70(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ႚ"))
	Jd0sLEiXIyWUkZARTo1xSqvpCYHgP = GN2SztT85ChvfWxJbdoUa(mrhSYXH2P8bO3eJAa9n)
	yfCVeg51RS4iWkEtulXbo93N8xGZ = HCiWF4jV1Q8(u"ࠩࡄ࡚࠿ࠦࠧႛ")+Jd0sLEiXIyWUkZARTo1xSqvpCYHgP+bcNqYtfET5l92dLGjyZSPe(u"ࠪ࠱ࠬႜ")+type
	T7WkNqJxpR9Lgj86UGeoihY = BBX9RAuxnyGZ4WIF2TrhYeom3 if ASkvf27etUK0(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧႝ") in Yg36raSGA02uUXEPMF7itZd9KcWf else mrhSYXH2P8bO3eJAa9n
	if not ggYWZeb94wjEaciK6p3tIylqBRmo:
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ႞"))
		return mrhSYXH2P8bO3eJAa9n
	ws5ZL3mqhd4 = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(wPnfgxKZdAv6T10(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ႟"))
	FKe1TxU27G4SPo8hDER += uqLUBHepfM3l6AyIzTJh80a(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭Ⴀ")+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࠢ࠽ࡠࡡࡴࠧႡ")
	FKe1TxU27G4SPo8hDER += wPnfgxKZdAv6T10(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪႢ")+Jd0sLEiXIyWUkZARTo1xSqvpCYHgP+AGlW9LqKN3Dvo(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩႣ")+bjfOp7nz3IHklMhUvLgd1xC+sTGtHVyhQ9cJU37zxo2O(u"ࠫࠥࡀ࡜࡝ࡰࠪႤ")
	FKe1TxU27G4SPo8hDER += AGlW9LqKN3Dvo(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪႥ")+ws5ZL3mqhd4
	ddP5p4NZtgjFrMnl8vHcLb1kT9VA = H28lnJ4fI3wadG()
	ddP5p4NZtgjFrMnl8vHcLb1kT9VA = xuCTZaNtMVwFs(ddP5p4NZtgjFrMnl8vHcLb1kT9VA)
	if ddP5p4NZtgjFrMnl8vHcLb1kT9VA: FKe1TxU27G4SPo8hDER += xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨႦ")+ddP5p4NZtgjFrMnl8vHcLb1kT9VA
	if url: FKe1TxU27G4SPo8hDER += ASkvf27etUK0(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫႧ")+url
	if qh4B9VQZCbXr0DRknFmi7J6: FKe1TxU27G4SPo8hDER += C3w6qluao7EzUxJgMGBtV(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨႨ")+qh4B9VQZCbXr0DRknFmi7J6
	FKe1TxU27G4SPo8hDER += gCkRKGhwcx26v(u"ࠩࠣ࠾ࡡࡢ࡮ࠨႩ")
	if showDialogs: i9yzUqgAW2Zap1h4Lm(VOALf8iYEnMdK0g(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩႪ"),TVnqDYzWoM2UfHp0dchJ(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭Ⴋ"))
	if T7WkNqJxpR9Lgj86UGeoihY:
		if tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬႬ") in Yg36raSGA02uUXEPMF7itZd9KcWf: cgyjWTaQmVRvCNqHU1pXe9FhOP = DM3tJCGvZk0sn4brxShAHwWfgio
		else: cgyjWTaQmVRvCNqHU1pXe9FhOP = ASIWYZHDvLfX05Ghxj2qEiJuy4U6b
		if not E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(cgyjWTaQmVRvCNqHU1pXe9FhOP):
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫႭ"))
			return mrhSYXH2P8bO3eJAa9n
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,fp6KV7DlS8QYniUczHdmZChL(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬႮ"))
		YasPmkLM7qFX3eVTv8i65CA9U,VNz5CrbpgDoGWlZ2A1hvUw0M = [],AGlW9LqKN3Dvo(u"࠲ኌ")
		file = open(cgyjWTaQmVRvCNqHU1pXe9FhOP,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡴࡥࠫႯ"))
		size,count = q5WoBw7x9sIFDEt(cgyjWTaQmVRvCNqHU1pXe9FhOP)
		if size>Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠶࠴࠶࠶࠰࠱ኍ"): file.seek(-Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠶࠴࠶࠶࠰࠱ኍ"),E2xjtKaMXdC3NDoTm7f5Wkev.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(Tv08xsf9HOqunIVUPdK1)
		data = vKPxCYXMJ6uhr(data)
		P7SQWVY4x1vm9tnANdiB = data.splitlines()
		for byUztE9qAGgCOlov8RB in reversed(P7SQWVY4x1vm9tnANdiB):
			MZ19WDBP03HsIg8bFGX5fSNz2cp6rn = TcOJwazbDi05EuNe(byUztE9qAGgCOlov8RB)
			if MZ19WDBP03HsIg8bFGX5fSNz2cp6rn: continue
			WBtIiPD7RUXhOelNvVCFYHEm = X2XorVqHjLkWeCchY4u9fSz.findall(gCkRKGhwcx26v(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩႰ"),byUztE9qAGgCOlov8RB,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if WBtIiPD7RUXhOelNvVCFYHEm:
				byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][wvkDqmNZlJU52isXo],WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq]).replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][JhTts2R43AxkM8bYanKVy],SebHIf2jL1TBgrMKJu)
			else:
				WBtIiPD7RUXhOelNvVCFYHEm = X2XorVqHjLkWeCchY4u9fSz.findall(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪႱ"),byUztE9qAGgCOlov8RB,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if WBtIiPD7RUXhOelNvVCFYHEm: byUztE9qAGgCOlov8RB = byUztE9qAGgCOlov8RB.replace(WBtIiPD7RUXhOelNvVCFYHEm[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq],SebHIf2jL1TBgrMKJu)
			YasPmkLM7qFX3eVTv8i65CA9U.append(byUztE9qAGgCOlov8RB)
			if len(str(YasPmkLM7qFX3eVTv8i65CA9U))>HCiWF4jV1Q8(u"࠶࠺࠷࠰࠱࠲኎"): break
		YasPmkLM7qFX3eVTv8i65CA9U = reversed(YasPmkLM7qFX3eVTv8i65CA9U)
		RrwOD3FTaV2 = VOALf8iYEnMdK0g(u"ࠫࡡࡸ࡜࡯ࠩႲ").join(YasPmkLM7qFX3eVTv8i65CA9U)
	elif MweoNQmW1hD8zOxcSlsFq496t: RrwOD3FTaV2 = MweoNQmW1hD8zOxcSlsFq496t
	else: RrwOD3FTaV2 = SebHIf2jL1TBgrMKJu
	url = qFsuKN7ngp.SITESURLS[l7kBpMw5Qn(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬႳ")][JhTts2R43AxkM8bYanKVy]
	BXupmlPQvMIrweKqkG = {iDhLkZS6XBagNCQfs9tq2(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧႴ"):yfCVeg51RS4iWkEtulXbo93N8xGZ,TVnqDYzWoM2UfHp0dchJ(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨႵ"):FKe1TxU27G4SPo8hDER,wPnfgxKZdAv6T10(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩႶ"):RrwOD3FTaV2}
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡓࡓࡘ࡚ࠧႷ"),url,BXupmlPQvMIrweKqkG,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭Ⴘ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡸ࡫࡮ࡥࡡࡶࡹࡨࡩࡥࡦࡦࡨࡨࠬႹ") in LCK8lO2yRWaTVEQcdjPXAzpFBe9: Vsn3f1CA8FIu0krNclSDWP5v9YQaE = BBX9RAuxnyGZ4WIF2TrhYeom3
	else: Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	if showDialogs:
		if Vsn3f1CA8FIu0krNclSDWP5v9YQaE:
			i9yzUqgAW2Zap1h4Lm(AGlW9LqKN3Dvo(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨႺ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧႻ"))
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,gCkRKGhwcx26v(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭Ⴜ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪႽ"))
		else:
			i9yzUqgAW2Zap1h4Lm(wPnfgxKZdAv6T10(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭Ⴞ"),wPnfgxKZdAv6T10(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫႿ"))
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩჀ"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def ga97vGsW5xkUpC2NBtf4ejO8zALQlw():
	ImZCD5zky03 = C3w6qluao7EzUxJgMGBtV(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡴࡳࡣࡱࡷࡱࡧࡴࡦࠢࡰࡩࡳࡻࠠࡪࡶࡨࡱࡸࠦࡴࡰࠢࡤࠤࡱࡧ࡮ࡨࡷࡤ࡫ࡪࠦ࡯ࡵࡪࡨࡶࠥࡺࡨࡢࡰࠣࡅࡷࡧࡢࡪࡥࠣ࠲࠳ࠦࡏࡳࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡡ࡯ࡦࠣࡸࡪࡾࡴࠡࡁࠤࠫჁ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = VOALf8iYEnMdK0g(u"࠭็ๅࠢอี๏ีࠠหำฯ้ฮࠦโ้ษษ้ࠥอไษำ้ห๊าࠠฦๆ์ࠤ้เษࠡลัี๎ฺ๋ࠦำࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡว฻๋ฬืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠣรࠦ࠭Ⴢ")
	choice = omIUAxNupsBHY0SGnJXzijltOyV(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡤࡧࡱࡸࡪࡸࠧჃ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨะิ์ัࠦࡅࡹ࡫ࡷࠫჄ"),bcNqYtfET5l92dLGjyZSPe(u"ࠩࡗࡶࡦࡴࡳ࡭ࡣࡷࡩࠥะัอ็ฬࠫჅ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ฽ึฮ๊ࠡࡃࡵࡥࡧ࡯ࡣࠨ჆"),lFEvMxzSH2y7tYR,ImZCD5zky03+gCkRKGhwcx26v(u"ࠫࡡࡴ࡜࡯ࠩჇ")+nLsfxayhBYdjHovlORpe9uEm6SFAgc)
	if choice in [-VOALf8iYEnMdK0g(u"࠶኏"),HADrRCz9QgU4xudPJIqYb70(u"࠶ነ")]: return
	elif choice==NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠱ኑ"):
		import hfr1DHCban
		hfr1DHCban.MHyNdSeIfcrR5UG3Zp4Oh8WAB6E()
		return
	uuIDQbF0BPGcgaMyw9fH6 = BBX9RAuxnyGZ4WIF2TrhYeom3
	while uuIDQbF0BPGcgaMyw9fH6:
		uuIDQbF0BPGcgaMyw9fH6 = mrhSYXH2P8bO3eJAa9n
		message = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬหะศࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦหๆࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใ฽๎ึࠦวๅฮ็ำࠥหไ๊ࠢฦ๎ࠥาไะࠢฮห๋๐ࠠโ์๊ࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦหๆࠢห฽ิํวࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤสึวࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢ็หࠥะุ่ำ่่ࠣࠦ࠮࠯ࠢสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤ࠳࠴ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้ํู่ࠡษ็ะ฿ืวโ์ࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠโฬะࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤฤࠧࠧ჈")
		choice = omIUAxNupsBHY0SGnJXzijltOyV(AGlW9LqKN3Dvo(u"࠭ࡣࡦࡰࡷࡩࡷ࠭჉"),AGlW9LqKN3Dvo(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪ჊"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩ჋"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠣษ๋าไ๋ิํࠫ჌"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠪ฽ิู๋้๋ࠠีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠨჍ"),message,profile=DQIrVcKuY6bJv(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ჎"))
		if choice==ASkvf27etUK0(u"࠳ኒ"):
			message = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡸ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡵࡱࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡳ࡬࡫ࡱࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠ࡝ࠤࡄࡶ࡮ࡧ࡬࡝ࠤࠣࡪࡴࡴࡴࠡ࠰࠱ࠤࡆࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡࡋࡩࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢ࠱࠲࡚ࠥࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡡࡴ࡜࡯ࠢࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠ࡯ࡱࡺࠤࡹࡵࠠࡰࡲࡨࡲࠥࡺࡨࡦࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡀࠣࠪ჏")
			choice = omIUAxNupsBHY0SGnJXzijltOyV(fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ა"),ALwOspNtXxZrz3PEKku(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪბ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩგ"),ASkvf27etUK0(u"ࠩࡄࡶࡦࡨࡩࡤࠢ฼ีอ๐ࠧდ"),gCkRKGhwcx26v(u"ࠪࡑ࡮ࡹࡳࡪࡰࡪࠤࡆࡸࡡࡣ࡫ࡦࠤࡋࡵ࡮ࡵࠢࠩࠤ࡙࡫ࡸࡵࠩე"),message,profile=HCiWF4jV1Q8(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩვ"))
			if choice==vMhFypGLHZJbdX4O7oc3W8x(u"࠴ና"): uuIDQbF0BPGcgaMyw9fH6 = BBX9RAuxnyGZ4WIF2TrhYeom3
		if choice==Gykx0wL3XrlWaujsqKP9n2Q(u"࠴ኔ"): KoyNkpQM6uU0S()
	return
def k7l3AJYoO5bqKrihRDw41GEMcP():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫზ"))
	return
def YlRWog6MbDF4vyVSKuXwq1hJ5k():
	FKe1TxU27G4SPo8hDER = uqLUBHepfM3l6AyIzTJh80a(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭თ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
	return
def q07AsXUzebnuiRM():
	FKe1TxU27G4SPo8hDER = AGlW9LqKN3Dvo(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫი")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
	return
def dezSqHTNvxYj():
	FKe1TxU27G4SPo8hDER = fp6KV7DlS8QYniUczHdmZChL(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬკ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫლ"),FKe1TxU27G4SPo8hDER)
	return
def C0K29doLUXGWHqTf1IBnYwNypmP():
	FKe1TxU27G4SPo8hDER = uqLUBHepfM3l6AyIzTJh80a(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨმ")
	M8wEz43vLgdl(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫნ"),lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER,wPnfgxKZdAv6T10(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨო"))
	return
def Q4dSrWoHny0mO9YVKM():
	ImZCD5zky03 = ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧპ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩჟ")
	Wjq1b2FoladZ58nEiOGc = czvu7VQCZodkMf(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩრ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ImZCD5zky03,nLsfxayhBYdjHovlORpe9uEm6SFAgc,Wjq1b2FoladZ58nEiOGc)
	return
def Q7EINd1XV6MliUczOr4vtfjs3APg():
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪს")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡠࡳࡢ࡮ࠨტ") + vMhFypGLHZJbdX4O7oc3W8x(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪუ") + str(dgvz7toK3Sil1CNUpPOaW58L9uJqY/ypO63g8oJEsDnPBHSuU7lMTZr(u"࠺࠵ን")/ypO63g8oJEsDnPBHSuU7lMTZr(u"࠺࠵ን")/j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠷࠺ኖ")/wPnfgxKZdAv6T10(u"࠹࠰ኗ")) + xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࠦิ่ำࠪფ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬქ") + str(CtRZoJqPXV/NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶࠱ኘ")/NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶࠱ኘ")/HADrRCz9QgU4xudPJIqYb70(u"࠳࠶ኙ")) + Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࠡ์๋้ࠬღ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + wPnfgxKZdAv6T10(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬყ") + str(iHR47eol8wB3Z/wPnfgxKZdAv6T10(u"࠸࠳ኚ")/wPnfgxKZdAv6T10(u"࠸࠳ኚ")/TVnqDYzWoM2UfHp0dchJ(u"࠵࠸ኛ")) + HADrRCz9QgU4xudPJIqYb70(u"ࠩࠣ๎ํ๋ࠧშ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + VOALf8iYEnMdK0g(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬჩ") + str(QfG1xIZ4hpq3ezPXt7VbvglUcB/NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺࠵ኜ")/NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺࠵ኜ")) + NUbVrRi4nq6BXmAOcM1zGtgJ(u"ูࠫࠥวฺหࠪც")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩძ") + str(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu/ASkvf27etUK0(u"࠻࠶ኝ")/ASkvf27etUK0(u"࠻࠶ኝ")) + iDhLkZS6XBagNCQfs9tq2(u"࠭ࠠิษ฼อࠬწ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + ALwOspNtXxZrz3PEKku(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨჭ") + str(B3vhTYqOtgUCAzPW/xxRyYsrSCzjifvH4cIqgldeOo(u"࠼࠰ኞ")) + HADrRCz9QgU4xudPJIqYb70(u"ࠨࠢาๆ๏่ษࠨხ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += u43PVWjh7t9YwI + bcNqYtfET5l92dLGjyZSPe(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫჯ") + str(RycFd7wZBiNhJjOPIGKp) + sTGtHVyhQ9cJU37zxo2O(u"ࠪࠤิ่๊ใหࠪჰ")
	nLsfxayhBYdjHovlORpe9uEm6SFAgc += v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡡࡴ࡜࡯ࠩჱ") + vMhFypGLHZJbdX4O7oc3W8x(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩჲ") + str(QfG1xIZ4hpq3ezPXt7VbvglUcB/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")) + AGlW9LqKN3Dvo(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧჳ") + str(iHR47eol8wB3Z/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")/qeYIw0BNTL9bGJnosacQ1DtVR(u"࠳࠶አ")) + ASkvf27etUK0(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭ჴ") + str(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")) + Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬჵ") + str(B3vhTYqOtgUCAzPW/vMhFypGLHZJbdX4O7oc3W8x(u"࠶࠱ኟ")) + C3w6qluao7EzUxJgMGBtV(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫჶ") + str(RycFd7wZBiNhJjOPIGKp) + Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࠤิ่๊ใหࠪჷ")
	M8wEz43vLgdl(TVnqDYzWoM2UfHp0dchJ(u"ࠫࡷ࡯ࡧࡩࡶࠪჸ"),gCkRKGhwcx26v(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪჹ"),nLsfxayhBYdjHovlORpe9uEm6SFAgc,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩჺ"))
	return
def nny3lzpxCoD7UjPcE():
	FKe1TxU27G4SPo8hDER = ALwOspNtXxZrz3PEKku(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ჻")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
	return
def G31G6JWXoLzO8S0UV72bl():
	FKe1TxU27G4SPo8hDER = fp6KV7DlS8QYniUczHdmZChL(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩჼ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
	return
def GyTWvMeE3VwPBO7D():
	FKe1TxU27G4SPo8hDER = bcNqYtfET5l92dLGjyZSPe(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭ჽ")
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER)
	return
def cTDpCNI2Hw9S():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,czvu7VQCZodkMf(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨჾ"))
	j3jFtGCKvzmOBwaX2ibogEx4JRqQD(bcNqYtfET5l92dLGjyZSPe(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫჿ"),BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def SeC7hYyzXjT3x1Qq08On():
	FKe1TxU27G4SPo8hDER  = xxRyYsrSCzjifvH4cIqgldeOo(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧᄀ")
	FKe1TxU27G4SPo8hDER += l7kBpMw5Qn(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ᄁ")
	FKe1TxU27G4SPo8hDER += u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+AGlW9LqKN3Dvo(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫᄂ")+XOVRfitWJP1zL3p2CMYF+u43PVWjh7t9YwI
	FKe1TxU27G4SPo8hDER += DQIrVcKuY6bJv(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨᄃ")
	M8wEz43vLgdl(AGlW9LqKN3Dvo(u"ࠩࡵ࡭࡬࡮ࡴࠨᄄ"),lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᄅ"))
	FKe1TxU27G4SPo8hDER = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧᄆ")
	FKe1TxU27G4SPo8hDER += u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+l7kBpMw5Qn(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫᄇ")+XOVRfitWJP1zL3p2CMYF
	FKe1TxU27G4SPo8hDER += AGlW9LqKN3Dvo(u"࠭࡜࡯࡞ࡱࠫᄈ")+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨᄉ")
	FKe1TxU27G4SPo8hDER += u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪᄊ")+XOVRfitWJP1zL3p2CMYF
	FKe1TxU27G4SPo8hDER += tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩ࡟ࡲࡡࡴࠧᄋ")+wPnfgxKZdAv6T10(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫᄌ")
	FKe1TxU27G4SPo8hDER += E7r8hUCVvTiFQW0dBGXjxcy+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭ᄍ")+XOVRfitWJP1zL3p2CMYF
	M8wEz43vLgdl(vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡸࡩࡨࡪࡷࠫᄎ"),lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER,ALwOspNtXxZrz3PEKku(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄏ"))
	return
def CCGlDkuMwS6TtH5P1iNpWocb9():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧᄐ"),zpx2fPNKk6Ms38eD1vcO(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢิืฬฬไ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫᄑ")+E7r8hUCVvTiFQW0dBGXjxcy+TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫᄒ")+XOVRfitWJP1zL3p2CMYF+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪᄓ")+E7r8hUCVvTiFQW0dBGXjxcy+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪᄔ")+XOVRfitWJP1zL3p2CMYF)
	return
def LHuCGNODMjrmvEp9Wt8SoA1Ys4Bz(showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3):
	if not showDialogs: showDialogs = BBX9RAuxnyGZ4WIF2TrhYeom3
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡍࡅࡕࠩᄕ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬᄖ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᄗ"))
	if not Bc5IUelt4sWvMXTdy.succeeded:
		SUTHc2IOsV6ue = mrhSYXH2P8bO3eJAa9n
		WbC0S7lwP6ODR3cJKBQ = MlNunOcdK41Qo59rIakEmgPx(mrhSYXH2P8bO3eJAa9n)
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭ᄘ")+WbC0S7lwP6ODR3cJKBQ+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡠࠫᄙ"))
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧᄚ"))
	else:
		SUTHc2IOsV6ue = BBX9RAuxnyGZ4WIF2TrhYeom3
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨᄛ"))
	if not SUTHc2IOsV6ue and showDialogs: iOWEHkzFSlwun0hK58GC7()
	return SUTHc2IOsV6ue
def iOWEHkzFSlwun0hK58GC7():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,czvu7VQCZodkMf(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫᄜ"))
	Hi8avrqwgI3()
	return
def CQgMI2jYDy4F(Yg36raSGA02uUXEPMF7itZd9KcWf=SebHIf2jL1TBgrMKJu):
	T7WkNqJxpR9Lgj86UGeoihY = BBX9RAuxnyGZ4WIF2TrhYeom3
	if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩᄝ") not in Yg36raSGA02uUXEPMF7itZd9KcWf:
		T7WkNqJxpR9Lgj86UGeoihY = mrhSYXH2P8bO3eJAa9n
		wE4CUOSMetbRmWB6Pn = omIUAxNupsBHY0SGnJXzijltOyV(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄞ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠨะิ์ั࠭ᄟ"),C3w6qluao7EzUxJgMGBtV(u"ࠩศีุอไࠡ็ื็้ฯࠧᄠ"),VOALf8iYEnMdK0g(u"ࠪษึูวๅࠢิืฬ๊ษࠨᄡ"),lFEvMxzSH2y7tYR,HADrRCz9QgU4xudPJIqYb70(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧᄢ"))
		if wE4CUOSMetbRmWB6Pn in [-zpx2fPNKk6Ms38eD1vcO(u"࠳ኡ"),gCkRKGhwcx26v(u"࠳ኢ")]: return
		elif wE4CUOSMetbRmWB6Pn==sTGtHVyhQ9cJU37zxo2O(u"࠵ኣ"):
			T7WkNqJxpR9Lgj86UGeoihY = BBX9RAuxnyGZ4WIF2TrhYeom3
			Yg36raSGA02uUXEPMF7itZd9KcWf = HADrRCz9QgU4xudPJIqYb70(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨᄣ")
	if T7WkNqJxpR9Lgj86UGeoihY:
		if C3w6qluao7EzUxJgMGBtV(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭ᄤ") not in Yg36raSGA02uUXEPMF7itZd9KcWf:
			sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(DQIrVcKuY6bJv(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄥ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,bcNqYtfET5l92dLGjyZSPe(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨᄦ"),iDhLkZS6XBagNCQfs9tq2(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩᄧ"))
			if sLhog1knUIF4fNOjY2zJqQ7cxArb!=wPnfgxKZdAv6T10(u"࠶ኤ"):
				gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭ᄨ"),ASkvf27etUK0(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧᄩ"))
				return
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้ห๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩᄪ"))
	FKe1TxU27G4SPo8hDER = zWKdm3kV2ItwYrgH1BZyRON(header=zpx2fPNKk6Ms38eD1vcO(u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧᄫ"),source=tfX4sO3hy2H1IbKG)
	if not FKe1TxU27G4SPo8hDER: return
	if T7WkNqJxpR9Lgj86UGeoihY: type = ASkvf27etUK0(u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨᄬ")
	else: type = bcNqYtfET5l92dLGjyZSPe(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩᄭ")
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = OmVwKTdykGa3xXsECzW(type,FKe1TxU27G4SPo8hDER,BBX9RAuxnyGZ4WIF2TrhYeom3,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬᄮ"),Yg36raSGA02uUXEPMF7itZd9KcWf)
	return
def iVH7IgXKGob4P9calwu2qypsARD():
	Yg36raSGA02uUXEPMF7itZd9KcWf = VOALf8iYEnMdK0g(u"๋ࠪีอࠠศๆหี๋อๅอࠢ็หࠥ๐่อั่ࠣ์ࠦร๋ࠢึ๎ึ็ัࠡ์ึฮ฻๐แࠡลํࠤ๊ำส้์สฮ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡำ๋หอ฽้ࠠฬู้๏์ࠠๅ็ะฮํ๐วห่ࠢีๆ๎ูสࠢ฼่๎ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ࠮ࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠๆีว์ู้ࠦ็ࠢฦ๎๋ࠥอห๊ํหฯࠦสๆࠢอั๊๐ไ่ษࠣ฽้๏ࠠิ์ิๅึอส๊่ࠡ์ฬู่ࠡะสีั๐ษࠡࠤ่์ฬูู่ࠡิๅࠥัวๅอࠥ࠲ࠥาๅ๋฻ࠣห้ษำๆษฤࠤํอไๆษิ็ฬะ้ࠠษ็ูํื้ࠠษ็ฺ้๋่าษอࠤ์๐ࠠฯษุอࠥฮวึฯสฬ์อ࠮ࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦ็ฬ๊็ࠥำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠥࡊࡍࡄࡃࠣษีอࠠไษ้ࠤ้ี๊ไࠢื็ํ๏ࠠฯษุอࠥฮวๅำ๋หอ฽้ࠠษ็ฮ฻อๅ๋่ࠣห้ิวาฮํอࠥ็วๅำฯหฦࠦวๅฬ๋หฺ๊ࠠๆ฻ࠣษิอัส๊ࠢิ์ࠦวๅีํีๆืวห๋ࠢห้๋่ศไ฼ࠤฬ๊ฮศำฯ๎ฮ࠴่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้ࠢหฬุอืส่ࠢฮฺ็อࠡๆ่์ฬู่ࠡษ็์๏ฮࠧᄯ")
	M8wEz43vLgdl(iDhLkZS6XBagNCQfs9tq2(u"ࠫࡷ࡯ࡧࡩࡶࠪᄰ"),HCiWF4jV1Q8(u"ࠬำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠬᄱ"),Yg36raSGA02uUXEPMF7itZd9KcWf,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄲ"))
	Yg36raSGA02uUXEPMF7itZd9KcWf = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡪࡲࡷࡹࠦࡡ࡯ࡻࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴࡴࠠࡢࡰࡼࠤࡸ࡫ࡲࡷࡧࡵ࠲ࠥࡏࡴࠡࡱࡱࡰࡾࠦࡵࡴࡧࡶࠤࡱ࡯࡮࡬ࡵࠣࡸࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷ࡬ࡦࡺࠠࡸࡣࡶࠤࡺࡶ࡬ࡰࡣࡧࡩࡩࠦࡴࡰࠢࡳࡳࡵࡻ࡬ࡢࡴࠣࡳࡳࡲࡩ࡯ࡧࠣࡺ࡮ࡪࡥࡰࠢ࡫ࡳࡸࡺࡩ࡯ࡩࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡅࡱࡲࠠࡵࡴࡤࡨࡪࡳࡡࡳ࡭ࡶ࠰ࠥࡼࡩࡥࡧࡲࡷ࠱ࠦࡴࡳࡣࡧࡩࠥࡴࡡ࡮ࡧࡶ࠰ࠥࡹࡥࡳࡸ࡬ࡧࡪࠦ࡭ࡢࡴ࡮ࡷ࠱ࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࡧࡧࠤࡼࡵࡲ࡬࠮ࠣࡰࡴ࡭࡯ࡴࠢࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࡩࠦࡨࡦࡴࡨ࡭ࡳࠦࡢࡦ࡮ࡲࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪ࡯ࡲࠡࡴࡨࡷࡵ࡫ࡣࡵ࡫ࡹࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡤࡱࡰࡴࡦࡴࡩࡦࡵ࠱ࠤ࡙࡮ࡥࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡦࡱ࡫ࠠࡧࡱࡵࠤࡼ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡳࡵࡲࡥࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤ࠸ࡸࡤࠡࡲࡤࡶࡹࡿࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡘࡧࠣࡹࡷ࡭ࡥࠡࡣ࡯ࡰࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡱࡺࡲࡪࡸࡳ࠭ࠢࡷࡳࠥࡸࡥࡤࡱࡪࡲ࡮ࢀࡥࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫ࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥࡽࡩࡵࡪ࡬ࡲࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡸࡥࠡ࡮ࡲࡧࡦࡺࡥࡥࠢࡶࡳࡲ࡫ࡷࡩࡧࡵࡩࠥ࡫࡬ࡴࡧࠣࡳࡳࠦࡴࡩࡧࠣࡻࡪࡨࠠࡰࡴࠣࡺ࡮ࡪࡥࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡦࡸࡥࠡࡨࡵࡳࡲࠦ࡯ࡵࡪࡨࡶࠥࡼࡡࡳ࡫ࡲࡹࡸࠦࡳࡪࡶࡨࡷ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡦࡴࡹࠡ࡮ࡨ࡫ࡦࡲࠠࡪࡵࡶࡹࡪࡹࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡭ࡦࡦ࡬ࡥࠥ࡬ࡩ࡭ࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥ࡮࡯ࡴࡶࡨࡶࡸ࠴ࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡤࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳ࠰ࠪᄳ")
	M8wEz43vLgdl(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࡮ࡨࡪࡹ࠭ᄴ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡇ࡭࡬࡯ࡴࡢ࡮ࠣࡑ࡮ࡲ࡬ࡦࡰࡱ࡭ࡺࡳࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡅࡨࡺࠠࠩࡆࡐࡇࡆ࠯ࠧᄵ"),Yg36raSGA02uUXEPMF7itZd9KcWf,wPnfgxKZdAv6T10(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᄶ"))
	return
def pYx59CRH8hay3gfF4TblDMso0WAIJ():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,wPnfgxKZdAv6T10(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩᄷ"))
	GyTWvMeE3VwPBO7D()
	return
def R3LqdQWNhpe7JbGOY8my06SDTvunU():
	rVpslfXux9yMg = {}
	vdLsc2f3YDuFkUTQGebtNOE,ttjvKC04GzV9duIJ,RR36tXfUo9zI7DpeGawqbMv = loygsJjU3Yv5OQ6(mrhSYXH2P8bO3eJAa9n)
	ImZCD5zky03,nLsfxayhBYdjHovlORpe9uEm6SFAgc,Wjq1b2FoladZ58nEiOGc,O4OUpIVQWSlBbkx5oqj,aBqv0bwgZFEJAY8o9cLmHSMnWrO26G,nvqOCh20GkMINK8,AfxwIEheyMn18 = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	ImZCD5zky03 = nlNC2gJDBZMed63TxqphA1vrXm8Hy.join(ttjvKC04GzV9duIJ)
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = nlNC2gJDBZMed63TxqphA1vrXm8Hy.join(RR36tXfUo9zI7DpeGawqbMv)
	icmGsqgVjIS,SmxUkp9wI3A1gq6R0t,uYCdL4nB6JQryG3MfxaF9XoUR2S = vdLsc2f3YDuFkUTQGebtNOE
	for GJ4kbYnxcHa6NIOuA7X20S,IKFNtUcgWwALu9o,ffyuLams8KJojGh9SlT3nBzNg in SmxUkp9wI3A1gq6R0t:
		ffyuLams8KJojGh9SlT3nBzNg = a549mfV8gnzXpwlFr(ffyuLams8KJojGh9SlT3nBzNg)
		ffyuLams8KJojGh9SlT3nBzNg = ffyuLams8KJojGh9SlT3nBzNg.strip(qE4nB3mKWHs).strip(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࠦ࠮ࠨᄸ"))
		ZHQM345iJfFqrhl6tuCB2jnSVzgIU = GJ4kbYnxcHa6NIOuA7X20S.replace(vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᄹ"),iDhLkZS6XBagNCQfs9tq2(u"ࠧࡂࡒࡌࠫᄺ"))
		O4OUpIVQWSlBbkx5oqj += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+ZHQM345iJfFqrhl6tuCB2jnSVzgIU+vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࠼ࠣࠫᄻ")+XOVRfitWJP1zL3p2CMYF+ffyuLams8KJojGh9SlT3nBzNg+u43PVWjh7t9YwI
		if IKFNtUcgWwALu9o.isdigit(): rVpslfXux9yMg[GJ4kbYnxcHa6NIOuA7X20S] = int(IKFNtUcgWwALu9o)
	TEJzYBxRgvVOShAPyec836mDlQ1Kbn,zC9DEboYrATf7w,MMfHET0IRWCjqZKFbu = list(zip(*SmxUkp9wI3A1gq6R0t))
	for GJ4kbYnxcHa6NIOuA7X20S in sorted(eJyScsgaRtx3XwFHlDYqNmO7r):
		if GJ4kbYnxcHa6NIOuA7X20S not in TEJzYBxRgvVOShAPyec836mDlQ1Kbn:
			O4OUpIVQWSlBbkx5oqj += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+GJ4kbYnxcHa6NIOuA7X20S+fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࠽ࠤࠬᄼ")+XOVRfitWJP1zL3p2CMYF+HCiWF4jV1Q8(u"่ࠪฬ๊้ࠦฮาࠫᄽ")+u43PVWjh7t9YwI
			if GJ4kbYnxcHa6NIOuA7X20S not in qFsuKN7ngp.non_videos_actions: Wjq1b2FoladZ58nEiOGc += nlNC2gJDBZMed63TxqphA1vrXm8Hy+GJ4kbYnxcHa6NIOuA7X20S
	for ffyuLams8KJojGh9SlT3nBzNg,VNz5CrbpgDoGWlZ2A1hvUw0M in icmGsqgVjIS:
		ffyuLams8KJojGh9SlT3nBzNg = a549mfV8gnzXpwlFr(ffyuLams8KJojGh9SlT3nBzNg)
		aBqv0bwgZFEJAY8o9cLmHSMnWrO26G += ffyuLams8KJojGh9SlT3nBzNg+zpx2fPNKk6Ms38eD1vcO(u"ࠫ࠿ࠦࠧᄾ")+E7r8hUCVvTiFQW0dBGXjxcy+str(VNz5CrbpgDoGWlZ2A1hvUw0M)+XOVRfitWJP1zL3p2CMYF+cc07eWdgrbB4xJfVCANFSk
	ImZCD5zky03 = ImZCD5zky03.strip(qE4nB3mKWHs)
	nLsfxayhBYdjHovlORpe9uEm6SFAgc = nLsfxayhBYdjHovlORpe9uEm6SFAgc.strip(qE4nB3mKWHs)
	Wjq1b2FoladZ58nEiOGc = Wjq1b2FoladZ58nEiOGc.strip(qE4nB3mKWHs)
	AJgmbMr3SGTZ2qduYLleEPk0HjO = ImZCD5zky03+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࠦࠠ࠯࠰ࠣࠤࠬᄿ")+nLsfxayhBYdjHovlORpe9uEm6SFAgc
	qqjc93BdmFrWRHe  = xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ๅ้ษๅ฽ࠥา๊ะหุࠣ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦࠨๆ่ࠣห้ษใฬำࠣษ้๏ࠠศๆฦๆ้࠯ࠧᅀ")+u43PVWjh7t9YwI+iDhLkZS6XBagNCQfs9tq2(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊่็ࠣๅ์๐ࠠๆ่ࠣ฽๋ีใ๊ࠡ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ๎ไศ่๊ࠢࠥอไๆ๊ๅ฽ࠬᅁ")+u43PVWjh7t9YwI
	qqjc93BdmFrWRHe += E7r8hUCVvTiFQW0dBGXjxcy+AJgmbMr3SGTZ2qduYLleEPk0HjO+XOVRfitWJP1zL3p2CMYF+Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡞ࡱࡠࡳ࠭ᅂ")
	qqjc93BdmFrWRHe += HADrRCz9QgU4xudPJIqYb70(u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅ่๊ࠢ์อࠠศๆหี๋อๅอࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่ࠡࠪีฯฮษࠡลหะิ๐ࠩࠨᅃ")+u43PVWjh7t9YwI+Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊้ࠠฮ๋ำ๋ࠥิไๆฬࠤ฾์ฯไࠢฦ์ࠥ็๊ࠡษ็้ํู่ࠡล๋ࠤๆ๐ࠠศๆหี๋อๅอࠩᅄ")+u43PVWjh7t9YwI
	Wjq1b2FoladZ58nEiOGc = nlNC2gJDBZMed63TxqphA1vrXm8Hy.join(sorted(Wjq1b2FoladZ58nEiOGc.split(nlNC2gJDBZMed63TxqphA1vrXm8Hy)))
	qqjc93BdmFrWRHe += E7r8hUCVvTiFQW0dBGXjxcy+Wjq1b2FoladZ58nEiOGc+XOVRfitWJP1zL3p2CMYF
	Yf8QptHulWweaUI7SJR5kP4m6hi9zd,QPro9wnVl7,IIugs1eqNQyDr,mWVplxKnLDtQH2EeXOUq7P = ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶እ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶እ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶እ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠶እ")
	all = rVpslfXux9yMg[Ns6AJKH7DGpr19Wl5C3nF(u"ࠫࡆࡒࡌࠨᅅ")]
	if xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᅆ") in list(rVpslfXux9yMg.keys()): Yf8QptHulWweaUI7SJR5kP4m6hi9zd = rVpslfXux9yMg[wPnfgxKZdAv6T10(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᅇ")]
	if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨᅈ") in list(rVpslfXux9yMg.keys()): QPro9wnVl7 = rVpslfXux9yMg[bcNqYtfET5l92dLGjyZSPe(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩᅉ")]
	if v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ᅊ") in list(rVpslfXux9yMg.keys()): IIugs1eqNQyDr = rVpslfXux9yMg[sTGtHVyhQ9cJU37zxo2O(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧᅋ")]
	if tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡗࡋࡐࡐࡕࠪᅌ") in list(rVpslfXux9yMg.keys()): mWVplxKnLDtQH2EeXOUq7P = rVpslfXux9yMg[HCiWF4jV1Q8(u"ࠬࡘࡅࡑࡑࡖࠫᅍ")]
	KMWTrCxmav29Xpe = all-Yf8QptHulWweaUI7SJR5kP4m6hi9zd-QPro9wnVl7-IIugs1eqNQyDr-mWVplxKnLDtQH2EeXOUq7P
	fNnuAzFsXhBKCco9JZeVUvd7Ya,oyD9Gl4S5TUIEuBC = uYCdL4nB6JQryG3MfxaF9XoUR2S[wvkDqmNZlJU52isXo]
	fNnuAzFsXhBKCco9JZeVUvd7Ya,bz25BdV7tE = uYCdL4nB6JQryG3MfxaF9XoUR2S[nyUIsfd53EGot9vbj0XDeq]
	mqcDEAYM1b8 = oyD9Gl4S5TUIEuBC-bz25BdV7tE
	AfxwIEheyMn18 += QNR6tCevIGEZKX3rAVsP+str(bz25BdV7tE)+XOVRfitWJP1zL3p2CMYF+Gykx0wL3XrlWaujsqKP9n2Q(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪᅎ")
	AfxwIEheyMn18 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(mqcDEAYM1b8)+XOVRfitWJP1zL3p2CMYF+ALwOspNtXxZrz3PEKku(u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫᅏ")
	AfxwIEheyMn18 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(oyD9Gl4S5TUIEuBC)+XOVRfitWJP1zL3p2CMYF+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩᅐ")
	AfxwIEheyMn18 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(len(uYCdL4nB6JQryG3MfxaF9XoUR2S[tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲ኦ"):]))+XOVRfitWJP1zL3p2CMYF+Ns6AJKH7DGpr19Wl5C3nF(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧᅑ")
	for LHwNEhkMb92Kpf8UtuQTP3a6S,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP in uYCdL4nB6JQryG3MfxaF9XoUR2S[l7kBpMw5Qn(u"࠳ኧ"):]:
		LHwNEhkMb92Kpf8UtuQTP3a6S = a549mfV8gnzXpwlFr(LHwNEhkMb92Kpf8UtuQTP3a6S)
		LHwNEhkMb92Kpf8UtuQTP3a6S = LHwNEhkMb92Kpf8UtuQTP3a6S.strip(qE4nB3mKWHs).strip(VOALf8iYEnMdK0g(u"ࠪࠤ࠳࠭ᅒ"))
		AfxwIEheyMn18 += LHwNEhkMb92Kpf8UtuQTP3a6S+VOALf8iYEnMdK0g(u"ࠫ࠿ࠦࠧᅓ")+E7r8hUCVvTiFQW0dBGXjxcy+str(Jd0sLEiXIyWUkZARTo1xSqvpCYHgP)+XOVRfitWJP1zL3p2CMYF+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࠦࠠࠡࠩᅔ")
	nvqOCh20GkMINK8 += QNR6tCevIGEZKX3rAVsP+str(KMWTrCxmav29Xpe)+XOVRfitWJP1zL3p2CMYF+Gykx0wL3XrlWaujsqKP9n2Q(u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫᅕ")
	nvqOCh20GkMINK8 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(Yf8QptHulWweaUI7SJR5kP4m6hi9zd)+XOVRfitWJP1zL3p2CMYF+DQIrVcKuY6bJv(u"ุࠧๆหหฯࠦำ๋ำไีࠥࡇࡐࡊࠢ࠽ࠤࠬᅖ")
	nvqOCh20GkMINK8 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(mWVplxKnLDtQH2EeXOUq7P)+XOVRfitWJP1zL3p2CMYF+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫᅗ")
	nvqOCh20GkMINK8 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(QPro9wnVl7)+XOVRfitWJP1zL3p2CMYF+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭ᅘ")
	nvqOCh20GkMINK8 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(IIugs1eqNQyDr)+XOVRfitWJP1zL3p2CMYF+ALwOspNtXxZrz3PEKku(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩᅙ")
	nvqOCh20GkMINK8 += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+str(len(icmGsqgVjIS))+XOVRfitWJP1zL3p2CMYF+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫᅚ")
	nvqOCh20GkMINK8 += HADrRCz9QgU4xudPJIqYb70(u"ࠬࡢ࡮࡝ࡰࠪᅛ")+aBqv0bwgZFEJAY8o9cLmHSMnWrO26G
	M8wEz43vLgdl(vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅜ"),iDhLkZS6XBagNCQfs9tq2(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨᅝ"),nvqOCh20GkMINK8,gCkRKGhwcx26v(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᅞ"))
	M8wEz43vLgdl(l7kBpMw5Qn(u"ࠩࡦࡩࡳࡺࡥࡳࠩᅟ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"้ࠪํอโฺࠢสุฯเไหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ᅠ"),qqjc93BdmFrWRHe,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᅡ"))
	M8wEz43vLgdl(wPnfgxKZdAv6T10(u"ࠬࡲࡥࡧࡶࠪᅢ"),zpx2fPNKk6Ms38eD1vcO(u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡษึฮำีๅหࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨᅣ"),O4OUpIVQWSlBbkx5oqj,HADrRCz9QgU4xudPJIqYb70(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᅤ"))
	return
def yDopAblUa7Lnvir1h():
	FKe1TxU27G4SPo8hDER = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰࠪᅥ")+QNR6tCevIGEZKX3rAVsP+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᅦ")+XOVRfitWJP1zL3p2CMYF+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࠬᅧ")+QNR6tCevIGEZKX3rAVsP+wPnfgxKZdAv6T10(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࠬᅨ")+XOVRfitWJP1zL3p2CMYF+sTGtHVyhQ9cJU37zxo2O(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤ๊฿ไ้็สฮࠥอไษำ้ห๊าࠧᅩ")
	M8wEz43vLgdl(vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅪ"),lFEvMxzSH2y7tYR,FKe1TxU27G4SPo8hDER,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᅫ"))
	return
def PDRwMfC9Xu4A():
	FKe1TxU27G4SPo8hDER = HCiWF4jV1Q8(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ᅬ")+u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+qFsuKN7ngp.SITESURLS[gCkRKGhwcx26v(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨᅭ")][wvkDqmNZlJU52isXo]+XOVRfitWJP1zL3p2CMYF+uqLUBHepfM3l6AyIzTJh80a(u"ࠪࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠧᅮ")+E7r8hUCVvTiFQW0dBGXjxcy+qFsuKN7ngp.SITESURLS[TVnqDYzWoM2UfHp0dchJ(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪᅯ")][nyUIsfd53EGot9vbj0XDeq]+XOVRfitWJP1zL3p2CMYF
	FKe1TxU27G4SPo8hDER += NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬᅰ")+E7r8hUCVvTiFQW0dBGXjxcy+qFsuKN7ngp.SITESURLS[bcNqYtfET5l92dLGjyZSPe(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬᅱ")][wvkDqmNZlJU52isXo]+XOVRfitWJP1zL3p2CMYF+C3w6qluao7EzUxJgMGBtV(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫᅲ")+E7r8hUCVvTiFQW0dBGXjxcy+qFsuKN7ngp.SITESURLS[TVnqDYzWoM2UfHp0dchJ(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧᅳ")][nyUIsfd53EGot9vbj0XDeq]+XOVRfitWJP1zL3p2CMYF
	FKe1TxU27G4SPo8hDER += fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬᅴ")+u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+qFsuKN7ngp.SITESURLS[fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡊࡎࡒࡅࡔࡡࡖࡓ࡚ࡘࡃࡆࡕࠪᅵ")][wvkDqmNZlJU52isXo]+XOVRfitWJP1zL3p2CMYF
	M8wEz43vLgdl(VOALf8iYEnMdK0g(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᅶ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫᅷ"),FKe1TxU27G4SPo8hDER,TVnqDYzWoM2UfHp0dchJ(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᅸ"))
	return
def uuaYAFK9ygvDrxtUHWnXfbMBCl(rZfSI25q6beDARK8sO4x):
	if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ᅹ")+rZfSI25q6beDARK8sO4x+zpx2fPNKk6Ms38eD1vcO(u"ࠨࠫࠪᅺ"), BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def KoyNkpQM6uU0S():
	InkX1ZEcl3yBf(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡶࡸࡴࡶࠧᅻ"))
	if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(iDhLkZS6XBagNCQfs9tq2(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤᅼ"))
	return
def pVamYQnj9WFrSq27GfgI1ZRkPy6JA():
	if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(ASkvf27etUK0(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪᅽ"), BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def QTIuOolE2qKCeYVH():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HADrRCz9QgU4xudPJIqYb70(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬᅾ"))
	return
def tw95nibYF3rfE():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩᅿ"))
	return
def CQPERlTrs3S1md(lgITq70uZ6=HCiWF4jV1Q8(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᆀ"),showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3):
	xbpe62PFARlCEfW = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(DQIrVcKuY6bJv(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫᆁ"))
	data = ddWZPUnz9Cljm.loads(xbpe62PFARlCEfW)
	Ymz8j2WfXe9E = data[HADrRCz9QgU4xudPJIqYb70(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᆂ")][ALwOspNtXxZrz3PEKku(u"ࠪࡺࡦࡲࡵࡦࠩᆃ")]
	if psS8dmb912iRBgGc7qOPyCZ6: Ymz8j2WfXe9E = Ymz8j2WfXe9E.encode(Tv08xsf9HOqunIVUPdK1)
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,bcNqYtfET5l92dLGjyZSPe(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩᆄ")+Ymz8j2WfXe9E+HADrRCz9QgU4xudPJIqYb70(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧᆅ")+lgITq70uZ6+ASkvf27etUK0(u"࠭ࠠภࠣࠪᆆ"))
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=ASkvf27etUK0(u"࠳ከ"): return mrhSYXH2P8bO3eJAa9n
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,zd7N5GPrQwXxSLus4l,WWZzOD4Nq5k0grYyom7 = WGgEi9DhonNslwABVz5CY4eOjLPTpI(lgITq70uZ6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	if Vsn3f1CA8FIu0krNclSDWP5v9YQaE:
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩᆇ"))
		WH0t1DnbcwFPNrzumfGZkJgYQqElyV = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(VOALf8iYEnMdK0g(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬᆈ")+lgITq70uZ6+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࠥࢁࢂ࠭ᆉ"))
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = BBX9RAuxnyGZ4WIF2TrhYeom3 if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡓࡐ࠭ᆊ") in WH0t1DnbcwFPNrzumfGZkJgYQqElyV else mrhSYXH2P8bO3eJAa9n
		uv8V4fE7j9pmgFr3wnDL.sleep(bcNqYtfET5l92dLGjyZSPe(u"࠴ኩ"))
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫᆋ"))
	elif showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,NUbVrRi4nq6BXmAOcM1zGtgJ(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧᆌ"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def Hi8avrqwgI3():
	url = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫᆍ")
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡈࡇࡗࠫᆎ"),url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫᆏ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	MezPnB9b23Q7J5dYiUTFpmGR = X2XorVqHjLkWeCchY4u9fSz.findall(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨᆐ"),LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	MezPnB9b23Q7J5dYiUTFpmGR = MezPnB9b23Q7J5dYiUTFpmGR[wvkDqmNZlJU52isXo].split(Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࠱ࠬᆑ"))[wvkDqmNZlJU52isXo]
	jUGtPpk8HDXWFu2xozsOmn3BS = str(zzGetSI9yqnbZh)
	O4OUpIVQWSlBbkx5oqj = DQIrVcKuY6bJv(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᆒ")+QNR6tCevIGEZKX3rAVsP+MezPnB9b23Q7J5dYiUTFpmGR+XOVRfitWJP1zL3p2CMYF
	O4OUpIVQWSlBbkx5oqj += xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡢ࡮࡝ࡰࠪᆓ")+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆔ")+QNR6tCevIGEZKX3rAVsP+jUGtPpk8HDXWFu2xozsOmn3BS+XOVRfitWJP1zL3p2CMYF
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,O4OUpIVQWSlBbkx5oqj)
	return
def yOH2RJjgEK8PSc6AkqGwM5eWfFQVl():
	G2VO6fKhjer,xPRu6p34Bsyi1,vef4tJCYx8MZhbEmao = mrhSYXH2P8bO3eJAa9n,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	yyDO0Wq3SerF2UdBG5Mjn86Efab,eAwhfQlYEXOSW4H76a51B,lv9fYZdVgyTtPo5BRH3XQFI6E = mrhSYXH2P8bO3eJAa9n,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	jTbhIPnNXKwRtGQOZumSUAFv = [qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᆕ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪᆖ"),czvu7VQCZodkMf(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆗ")]
	cjgL0TptRom1DZeFIlC6kM5K = RCHMOS7Qre9bm(jTbhIPnNXKwRtGQOZumSUAFv)
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in jTbhIPnNXKwRtGQOZumSUAFv:
		if WYGV2HQo6sfnqSDZEcK9Cu4TP not in list(cjgL0TptRom1DZeFIlC6kM5K.keys()): continue
		fLDQYSwx2chU,aosTJx4jVAZ08Rrvfp2z,A0doz8gTbeEy63p9PDhN,RUj0cvlgXi3GWDmQL4Pp2CkB,ALUNh3HRrOEDu,pzLtoCWJ8vkPnjs6lreUfd7yib,cf9WryKTdQSim6kaIXJvE = cjgL0TptRom1DZeFIlC6kM5K[WYGV2HQo6sfnqSDZEcK9Cu4TP]
		if WYGV2HQo6sfnqSDZEcK9Cu4TP==TVnqDYzWoM2UfHp0dchJ(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᆘ"):
			yyDO0Wq3SerF2UdBG5Mjn86Efab = fLDQYSwx2chU
			eAwhfQlYEXOSW4H76a51B = aosTJx4jVAZ08Rrvfp2z+HCiWF4jV1Q8(u"ࠫࠥࠦࠠࠡࠪࠣࠫᆙ")+dPlNiRwGQK4bz(pzLtoCWJ8vkPnjs6lreUfd7yib)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࠦࠩࠨᆚ")
			lv9fYZdVgyTtPo5BRH3XQFI6E = RUj0cvlgXi3GWDmQL4Pp2CkB
		elif WYGV2HQo6sfnqSDZEcK9Cu4TP==qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨᆛ"):
			G2VO6fKhjer = G2VO6fKhjer or fLDQYSwx2chU
			xPRu6p34Bsyi1 += tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᆜ")+aosTJx4jVAZ08Rrvfp2z+VOALf8iYEnMdK0g(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨᆝ")+dPlNiRwGQK4bz(pzLtoCWJ8vkPnjs6lreUfd7yib)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࠣ࠭ࠬᆞ")
			vef4tJCYx8MZhbEmao += uqLUBHepfM3l6AyIzTJh80a(u"ࠪࠤࠥ࠲ࠠࠡࠩᆟ")+RUj0cvlgXi3GWDmQL4Pp2CkB
		elif WYGV2HQo6sfnqSDZEcK9Cu4TP==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᆠ"):
			CZpnDhcmSdEaH60B1yP2g9FkoX = fLDQYSwx2chU
			UCGVWlpDnt0vwu1ezy = aosTJx4jVAZ08Rrvfp2z+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࠦࠠࠡࠢࠫࠤࠬᆡ")+dPlNiRwGQK4bz(pzLtoCWJ8vkPnjs6lreUfd7yib)+VOALf8iYEnMdK0g(u"࠭ࠠࠪࠩᆢ")
			RlnvaZu5KFQxIX1yrw9A7oU3qJY = RUj0cvlgXi3GWDmQL4Pp2CkB
	xPRu6p34Bsyi1 = xPRu6p34Bsyi1.strip(fp6KV7DlS8QYniUczHdmZChL(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᆣ"))
	vef4tJCYx8MZhbEmao = vef4tJCYx8MZhbEmao.strip(czvu7VQCZodkMf(u"ࠨࠢࠣ࠰ࠥࠦࠧᆤ"))
	UUzT05qiwxXItYSFJsefyNbDjEpB  = C3w6qluao7EzUxJgMGBtV(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧᆥ")+QNR6tCevIGEZKX3rAVsP+lv9fYZdVgyTtPo5BRH3XQFI6E+XOVRfitWJP1zL3p2CMYF
	UUzT05qiwxXItYSFJsefyNbDjEpB += u43PVWjh7t9YwI+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆦ")+QNR6tCevIGEZKX3rAVsP+eAwhfQlYEXOSW4H76a51B+XOVRfitWJP1zL3p2CMYF
	UUzT05qiwxXItYSFJsefyNbDjEpB += fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡡࡴ࡜࡯ࠩᆧ")+ALwOspNtXxZrz3PEKku(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪᆨ")+QNR6tCevIGEZKX3rAVsP+vef4tJCYx8MZhbEmao+XOVRfitWJP1zL3p2CMYF
	UUzT05qiwxXItYSFJsefyNbDjEpB += u43PVWjh7t9YwI+HADrRCz9QgU4xudPJIqYb70(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨᆩ")+QNR6tCevIGEZKX3rAVsP+xPRu6p34Bsyi1+XOVRfitWJP1zL3p2CMYF
	UUzT05qiwxXItYSFJsefyNbDjEpB += C3w6qluao7EzUxJgMGBtV(u"ࠧ࡝ࡰ࡟ࡲࠬᆪ")+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬᆫ")+QNR6tCevIGEZKX3rAVsP+RlnvaZu5KFQxIX1yrw9A7oU3qJY+XOVRfitWJP1zL3p2CMYF
	UUzT05qiwxXItYSFJsefyNbDjEpB += u43PVWjh7t9YwI+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪᆬ")+QNR6tCevIGEZKX3rAVsP+UCGVWlpDnt0vwu1ezy+XOVRfitWJP1zL3p2CMYF
	fLDQYSwx2chU = yyDO0Wq3SerF2UdBG5Mjn86Efab or G2VO6fKhjer
	if fLDQYSwx2chU:
		header = HCiWF4jV1Q8(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬᆭ")
		l4vqDU9ocLa7YIKhdi6zxF = HADrRCz9QgU4xudPJIqYb70(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬᆮ")
	else:
		header = fp6KV7DlS8QYniUczHdmZChL(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ᆯ")
		l4vqDU9ocLa7YIKhdi6zxF = VOALf8iYEnMdK0g(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨᆰ")
	DQp8F9BmtE7s4OJk5i = vMhFypGLHZJbdX4O7oc3W8x(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨᆱ")
	EEU2vH4cBfo5T3dPe9 = UUzT05qiwxXItYSFJsefyNbDjEpB+ALwOspNtXxZrz3PEKku(u"ࠨ࡞ࡱࡠࡳ࠭ᆲ")+l4vqDU9ocLa7YIKhdi6zxF+ASkvf27etUK0(u"ࠩ࡟ࡲࡡࡴࠧᆳ")+DQp8F9BmtE7s4OJk5i
	M8wEz43vLgdl(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡶ࡮࡭ࡨࡵࠩᆴ"),header,EEU2vH4cBfo5T3dPe9,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᆵ"))
	return fLDQYSwx2chU
def BI3uEGAW19xTZwi87(WYGV2HQo6sfnqSDZEcK9Cu4TP,cf9WryKTdQSim6kaIXJvE,showDialogs):
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,VOALf8iYEnMdK0g(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨᆶ"))
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return mrhSYXH2P8bO3eJAa9n
	qKeQuLGY0sZ7SNbl9mCVgOhofd3 = VUchIzntr5E(cf9WryKTdQSim6kaIXJvE,{},showDialogs)
	if qKeQuLGY0sZ7SNbl9mCVgOhofd3:
		vzYbDMr8A7O = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(TPamrY4p9IEN,WYGV2HQo6sfnqSDZEcK9Cu4TP)
		VS8fuikmreJGgW6cdLOq2yz(vzYbDMr8A7O,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
		import zipfile as oYLtrAmD1GdZp5V08wXf4vBiSIK,io as YsimacJOfvCb
		ggdZWQkFh1mpPEV5fw8 = YsimacJOfvCb.BytesIO(qKeQuLGY0sZ7SNbl9mCVgOhofd3)
		try:
			YxoCZ4ER1Ti6cgjwXFQNt3Hy = oYLtrAmD1GdZp5V08wXf4vBiSIK.ZipFile(ggdZWQkFh1mpPEV5fw8)
			YxoCZ4ER1Ti6cgjwXFQNt3Hy.extractall(TPamrY4p9IEN)
			uv8V4fE7j9pmgFr3wnDL.sleep(nyUIsfd53EGot9vbj0XDeq)
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᆷ"))
			uv8V4fE7j9pmgFr3wnDL.sleep(nyUIsfd53EGot9vbj0XDeq)
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE = QeL8HcaGkswlFyXWRP1KVDBO(WYGV2HQo6sfnqSDZEcK9Cu4TP)
		except: Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
	if showDialogs:
		if Vsn3f1CA8FIu0krNclSDWP5v9YQaE: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,AGlW9LqKN3Dvo(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫᆸ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ᆹ"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def j3jFtGCKvzmOBwaX2ibogEx4JRqQD(WYGV2HQo6sfnqSDZEcK9Cu4TP,showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3):
	if showDialogs==SebHIf2jL1TBgrMKJu: showDialogs = BBX9RAuxnyGZ4WIF2TrhYeom3
	PPBUm9HAawonq8SgzpNxeJ = YcR81moSla([WYGV2HQo6sfnqSDZEcK9Cu4TP])
	c2G5evzX8YOLa7V96IUBxPCHM0k,pVrPZglEOYjcBRMnGCxS = PPBUm9HAawonq8SgzpNxeJ[WYGV2HQo6sfnqSDZEcK9Cu4TP]
	if pVrPZglEOYjcBRMnGCxS:
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = BBX9RAuxnyGZ4WIF2TrhYeom3
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,fp6KV7DlS8QYniUczHdmZChL(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫᆺ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+C3w6qluao7EzUxJgMGBtV(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ᆻ"))
	else:
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(DQIrVcKuY6bJv(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆼ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,SebHIf2jL1TBgrMKJu+WYGV2HQo6sfnqSDZEcK9Cu4TP+wPnfgxKZdAv6T10(u"ࠬࠦ࡜࡯࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ์ฬ๊ศา่ส้ัࠦศฮษฯอ๊ࠥ็ศࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩᆽ"))
		if sLhog1knUIF4fNOjY2zJqQ7cxArb==Gykx0wL3XrlWaujsqKP9n2Q(u"࠵ኪ"):
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(DQIrVcKuY6bJv(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ᆾ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࠪࠩᆿ"))
			uv8V4fE7j9pmgFr3wnDL.sleep(uqLUBHepfM3l6AyIzTJh80a(u"࠶ካ"))
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(gCkRKGhwcx26v(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨᇀ"))
			uv8V4fE7j9pmgFr3wnDL.sleep(TVnqDYzWoM2UfHp0dchJ(u"࠷ኬ"))
			while if5dy2h0nsDVlukoQ7NUFqx4cGEW.getCondVisibility(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ᇁ")): uv8V4fE7j9pmgFr3wnDL.sleep(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠱ክ"))
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE = QeL8HcaGkswlFyXWRP1KVDBO(WYGV2HQo6sfnqSDZEcK9Cu4TP)
			if showDialogs and Vsn3f1CA8FIu0krNclSDWP5v9YQaE: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HADrRCz9QgU4xudPJIqYb70(u"ࠪฮ๊ࠦแฮืࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪᇂ"))
			elif showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l7kBpMw5Qn(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭ᇃ"))
	return Vsn3f1CA8FIu0krNclSDWP5v9YQaE
def soYe8JFVziP3j1QhSK(showDialogs):
	if not showDialogs: sLhog1knUIF4fNOjY2zJqQ7cxArb = BBX9RAuxnyGZ4WIF2TrhYeom3
	else: sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(wPnfgxKZdAv6T10(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᇄ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢฦ๊ࠥะืๅส้๋ࠣࠦใ้ัํࠤๆำี๊ࠡอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡมࠪᇅ"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==HADrRCz9QgU4xudPJIqYb70(u"࠲ኮ"):
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪᇆ"))
		if showDialogs:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨᇇ"))
	return
def D17MRSNzQH():
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,sTGtHVyhQ9cJU37zxo2O(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᇈ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᇉ"))
	Hi8avrqwgI3()
	fLDQYSwx2chU = yOH2RJjgEK8PSc6AkqGwM5eWfFQVl()
	if fLDQYSwx2chU:
		eex4VdtZ9fUsJhB7(BBX9RAuxnyGZ4WIF2TrhYeom3)
		soYe8JFVziP3j1QhSK(BBX9RAuxnyGZ4WIF2TrhYeom3)
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def QeL8HcaGkswlFyXWRP1KVDBO(WYGV2HQo6sfnqSDZEcK9Cu4TP):
	lfZmugQCFKLGT05AH29IsMiho = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(wPnfgxKZdAv6T10(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧᇊ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᇋ"))
	succeeded = BBX9RAuxnyGZ4WIF2TrhYeom3 if ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡏࡌࠩᇌ") in lfZmugQCFKLGT05AH29IsMiho else mrhSYXH2P8bO3eJAa9n
	return succeeded
def w7DGq2AkLH(WYGV2HQo6sfnqSDZEcK9Cu4TP):
	lfZmugQCFKLGT05AH29IsMiho = if5dy2h0nsDVlukoQ7NUFqx4cGEW.executeJSONRPC(gCkRKGhwcx26v(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᇍ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧᇎ"))
	succeeded = BBX9RAuxnyGZ4WIF2TrhYeom3 if ALwOspNtXxZrz3PEKku(u"ࠩࡒࡏࠬᇏ") in lfZmugQCFKLGT05AH29IsMiho else mrhSYXH2P8bO3eJAa9n
	return succeeded
def WGgEi9DhonNslwABVz5CY4eOjLPTpI(WYGV2HQo6sfnqSDZEcK9Cu4TP,showDialogs,M3RlXf0CtkYd1Ea,cjgL0TptRom1DZeFIlC6kM5K=None):
	sLhog1knUIF4fNOjY2zJqQ7cxArb,succeeded,zd7N5GPrQwXxSLus4l,aosTJx4jVAZ08Rrvfp2z = BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᇐ"),SebHIf2jL1TBgrMKJu
	if not cjgL0TptRom1DZeFIlC6kM5K: cjgL0TptRom1DZeFIlC6kM5K = RCHMOS7Qre9bm([WYGV2HQo6sfnqSDZEcK9Cu4TP])
	if WYGV2HQo6sfnqSDZEcK9Cu4TP in list(cjgL0TptRom1DZeFIlC6kM5K.keys()):
		fLDQYSwx2chU,aosTJx4jVAZ08Rrvfp2z,A0doz8gTbeEy63p9PDhN,RUj0cvlgXi3GWDmQL4Pp2CkB,ALUNh3HRrOEDu,pzLtoCWJ8vkPnjs6lreUfd7yib,cf9WryKTdQSim6kaIXJvE = cjgL0TptRom1DZeFIlC6kM5K[WYGV2HQo6sfnqSDZEcK9Cu4TP]
		if pzLtoCWJ8vkPnjs6lreUfd7yib==sTGtHVyhQ9cJU37zxo2O(u"ࠫ࡬ࡵ࡯ࡥࠩᇑ"):
			succeeded,zd7N5GPrQwXxSLus4l = BBX9RAuxnyGZ4WIF2TrhYeom3,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭ᇒ")
			if M3RlXf0CtkYd1Ea and showDialogs:
				sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,gCkRKGhwcx26v(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ᇓ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา๋ࠪᇔ"))
				if sLhog1knUIF4fNOjY2zJqQ7cxArb:
					succeeded = BI3uEGAW19xTZwi87(WYGV2HQo6sfnqSDZEcK9Cu4TP,cf9WryKTdQSim6kaIXJvE,mrhSYXH2P8bO3eJAa9n)
					if succeeded:
						zd7N5GPrQwXxSLus4l = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᇕ")
						if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᇖ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
					else:
						zd7N5GPrQwXxSLus4l = gCkRKGhwcx26v(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᇗ")
						gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,C3w6qluao7EzUxJgMGBtV(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᇘ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
		else:
			if showDialogs:
				if pzLtoCWJ8vkPnjs6lreUfd7yib==ASkvf27etUK0(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᇙ"): FKe1TxU27G4SPo8hDER = qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ๅห๊ๅๅฮ࠭ᇚ")
				elif pzLtoCWJ8vkPnjs6lreUfd7yib==xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡰ࡮ࡧࠫᇛ"): FKe1TxU27G4SPo8hDER = VOALf8iYEnMdK0g(u"ࠨไา๎๊ฯࠧᇜ")
				elif pzLtoCWJ8vkPnjs6lreUfd7yib==bcNqYtfET5l92dLGjyZSPe(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᇝ"): FKe1TxU27G4SPo8hDER = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ᇞ")
				sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,uqLUBHepfM3l6AyIzTJh80a(u"ࠫ์ึ็ࠡษ็ษ฻อแสࠢࠪᇟ")+FKe1TxU27G4SPo8hDER+wPnfgxKZdAv6T10(u"ࠬࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠภࠣ࡟ࡲࡡࡴࠧᇠ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
			if not sLhog1knUIF4fNOjY2zJqQ7cxArb: zd7N5GPrQwXxSLus4l = DQIrVcKuY6bJv(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨᇡ")
			else:
				if pzLtoCWJ8vkPnjs6lreUfd7yib==Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩᇢ"):
					succeeded = QeL8HcaGkswlFyXWRP1KVDBO(WYGV2HQo6sfnqSDZEcK9Cu4TP)
					if succeeded:
						zd7N5GPrQwXxSLus4l = iDhLkZS6XBagNCQfs9tq2(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩᇣ")
						if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,bcNqYtfET5l92dLGjyZSPe(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧᇤ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
					elif showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ypO63g8oJEsDnPBHSuU7lMTZr(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ᇥ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
				elif pzLtoCWJ8vkPnjs6lreUfd7yib in [wPnfgxKZdAv6T10(u"ࠫࡴࡲࡤࠨᇦ"),TVnqDYzWoM2UfHp0dchJ(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᇧ")]:
					succeeded = BI3uEGAW19xTZwi87(WYGV2HQo6sfnqSDZEcK9Cu4TP,cf9WryKTdQSim6kaIXJvE,mrhSYXH2P8bO3eJAa9n)
					if succeeded:
						if pzLtoCWJ8vkPnjs6lreUfd7yib==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡯࡭ࡦࠪᇨ"): zd7N5GPrQwXxSLus4l = ALwOspNtXxZrz3PEKku(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨᇩ")
						elif pzLtoCWJ8vkPnjs6lreUfd7yib==DQIrVcKuY6bJv(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩᇪ"): zd7N5GPrQwXxSLus4l = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᇫ")
						aosTJx4jVAZ08Rrvfp2z = RUj0cvlgXi3GWDmQL4Pp2CkB
						if showDialogs:
							if zd7N5GPrQwXxSLus4l==HADrRCz9QgU4xudPJIqYb70(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫᇬ"): gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨᇭ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
							elif zd7N5GPrQwXxSLus4l==ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨᇮ"): gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,HADrRCz9QgU4xudPJIqYb70(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧᇯ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
					elif showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,sTGtHVyhQ9cJU37zxo2O(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪᇰ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
	elif showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ᇱ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
	return succeeded,zd7N5GPrQwXxSLus4l,aosTJx4jVAZ08Rrvfp2z
def GnQhi9CoBMkX7(WYGV2HQo6sfnqSDZEcK9Cu4TP,showDialogs,BIntN6U7XD):
	SSpe2lotnNdZIiHAmgKqc = Y7oqZy4HgtlDIxsJ.connect(LL0FBaOIs7DRvzw1Y)
	SSpe2lotnNdZIiHAmgKqc.text_factory = str
	BuvcGxfSUokM5EV = SSpe2lotnNdZIiHAmgKqc.cursor()
	succeeded,nqlm8fwcjtGVgx2oLM39HAPNZR = BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n
	try:
		xDKHZnsJa327Mzl6phicRkuLNXBT = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᇲ")
		BuvcGxfSUokM5EV.execute(AGlW9LqKN3Dvo(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᇳ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+AGlW9LqKN3Dvo(u"ࠫࠧࠦ࠻ࠨᇴ"))
		GYJ52aCZBjbtgLS = BuvcGxfSUokM5EV.fetchall()
		if GYJ52aCZBjbtgLS and xDKHZnsJa327Mzl6phicRkuLNXBT not in str(GYJ52aCZBjbtgLS): BuvcGxfSUokM5EV.execute(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩᇵ")+xDKHZnsJa327Mzl6phicRkuLNXBT+AGlW9LqKN3Dvo(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᇶ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+DQIrVcKuY6bJv(u"ࠧࠣࠢ࠾ࠫᇷ"))
		NqDVyHGhL0EekF = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫᇸ") if psS8dmb912iRBgGc7qOPyCZ6 else HCiWF4jV1Q8(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨᇹ")
		BuvcGxfSUokM5EV.execute(ASkvf27etUK0(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫᇺ")+NqDVyHGhL0EekF+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᇻ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+gCkRKGhwcx26v(u"ࠬࠨࠠ࠼ࠩᇼ"))
		GYJ52aCZBjbtgLS = BuvcGxfSUokM5EV.fetchall()
		if GYJ52aCZBjbtgLS:
			if showDialogs: sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Izy1PvclrYx4eSVWn0L5phZbq(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪᇽ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧᇾ")+E7r8hUCVvTiFQW0dBGXjxcy+VOALf8iYEnMdK0g(u"ࠨ่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢࠪᇿ")+XOVRfitWJP1zL3p2CMYF+HCiWF4jV1Q8(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧሀ"))
			else: sLhog1knUIF4fNOjY2zJqQ7cxArb = nyUIsfd53EGot9vbj0XDeq
			if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
				nqlm8fwcjtGVgx2oLM39HAPNZR = BBX9RAuxnyGZ4WIF2TrhYeom3
				BuvcGxfSUokM5EV.execute(iDhLkZS6XBagNCQfs9tq2(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩሁ")+NqDVyHGhL0EekF+ASkvf27etUK0(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩሂ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+C3w6qluao7EzUxJgMGBtV(u"ࠬࠨࠠ࠼ࠩሃ"))
		elif BIntN6U7XD:
			if showDialogs: sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ASkvf27etUK0(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪሄ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+bcNqYtfET5l92dLGjyZSPe(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧህ")+E7r8hUCVvTiFQW0dBGXjxcy+DQIrVcKuY6bJv(u"ࠨ่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ሆ")+XOVRfitWJP1zL3p2CMYF+C3w6qluao7EzUxJgMGBtV(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧሇ"))
			else: sLhog1knUIF4fNOjY2zJqQ7cxArb = nyUIsfd53EGot9vbj0XDeq
			if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
				nqlm8fwcjtGVgx2oLM39HAPNZR = BBX9RAuxnyGZ4WIF2TrhYeom3
				if psS8dmb912iRBgGc7qOPyCZ6: BuvcGxfSUokM5EV.execute(VOALf8iYEnMdK0g(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩለ")+NqDVyHGhL0EekF+fp6KV7DlS8QYniUczHdmZChL(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫሉ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࠨࠩࠡ࠽ࠪሊ"))
				else: BuvcGxfSUokM5EV.execute(uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬላ")+NqDVyHGhL0EekF+wPnfgxKZdAv6T10(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫሌ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+wPnfgxKZdAv6T10(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨል"))
	except: succeeded = mrhSYXH2P8bO3eJAa9n
	SSpe2lotnNdZIiHAmgKqc.commit()
	SSpe2lotnNdZIiHAmgKqc.close()
	if nqlm8fwcjtGVgx2oLM39HAPNZR:
		uv8V4fE7j9pmgFr3wnDL.sleep(czvu7VQCZodkMf(u"࠳ኯ"))
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ሎ"))
		uv8V4fE7j9pmgFr3wnDL.sleep(uqLUBHepfM3l6AyIzTJh80a(u"࠴ኰ"))
		if showDialogs:
			if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,AGlW9LqKN3Dvo(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫሏ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
			else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬሐ")+WYGV2HQo6sfnqSDZEcK9Cu4TP)
	return nqlm8fwcjtGVgx2oLM39HAPNZR
def ENy7SiaD8eW1UIP5BXTrGcOCpuoF(jTbhIPnNXKwRtGQOZumSUAFv,showDialogs,M3RlXf0CtkYd1Ea,BIntN6U7XD):
	cjgL0TptRom1DZeFIlC6kM5K = RCHMOS7Qre9bm(jTbhIPnNXKwRtGQOZumSUAFv)
	EEKw6FX9roBTkYnpzRtb = mrhSYXH2P8bO3eJAa9n
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in jTbhIPnNXKwRtGQOZumSUAFv:
		succeeded,zd7N5GPrQwXxSLus4l,aosTJx4jVAZ08Rrvfp2z = WGgEi9DhonNslwABVz5CY4eOjLPTpI(WYGV2HQo6sfnqSDZEcK9Cu4TP,showDialogs,M3RlXf0CtkYd1Ea,cjgL0TptRom1DZeFIlC6kM5K)
		nqlm8fwcjtGVgx2oLM39HAPNZR = GnQhi9CoBMkX7(WYGV2HQo6sfnqSDZEcK9Cu4TP,showDialogs,BIntN6U7XD)
		if nqlm8fwcjtGVgx2oLM39HAPNZR: EEKw6FX9roBTkYnpzRtb = BBX9RAuxnyGZ4WIF2TrhYeom3
	if EEKw6FX9roBTkYnpzRtb:
		uv8V4fE7j9pmgFr3wnDL.sleep(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠵኱"))
		if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(xxRyYsrSCzjifvH4cIqgldeOo(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩሑ"))
		uv8V4fE7j9pmgFr3wnDL.sleep(uqLUBHepfM3l6AyIzTJh80a(u"࠶ኲ"))
	if showDialogs:
		if len(jTbhIPnNXKwRtGQOZumSUAFv)>cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠷ኳ"): gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,fp6KV7DlS8QYniUczHdmZChL(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬሒ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,sTGtHVyhQ9cJU37zxo2O(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫሓ")+jTbhIPnNXKwRtGQOZumSUAFv[C3w6qluao7EzUxJgMGBtV(u"࠰ኴ")])
	return
def eex4VdtZ9fUsJhB7(showDialogs):
	G9GfbsZtoF8TuQhJ6UERrHNp3emxC = [qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ሔ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫሕ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧሖ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫሗ")]
	xxqHnOB6eN5X7LGMa3 = [HCiWF4jV1Q8(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧመ"),C3w6qluao7EzUxJgMGBtV(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧሙ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪሚ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪማ"),C3w6qluao7EzUxJgMGBtV(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪሜ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧም")]
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in xxqHnOB6eN5X7LGMa3: w7DGq2AkLH(WYGV2HQo6sfnqSDZEcK9Cu4TP)
	ENy7SiaD8eW1UIP5BXTrGcOCpuoF(G9GfbsZtoF8TuQhJ6UERrHNp3emxC,showDialogs,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	return