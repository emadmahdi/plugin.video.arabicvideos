# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'BOKRA'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_BKR_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
jgvMWZhtPlBT = ['افلام للكبار','بكرا TV']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==370: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==371: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==372: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==374: lfZmugQCFKLGT05AH29IsMiho = LLOxfehDnVzcG263aHFNlBUvXPqr1o(url)
	elif mode==375: lfZmugQCFKLGT05AH29IsMiho = TctFVarD0UpL7SwJ9nbZH1euBGv2zP(url)
	elif mode==376: lfZmugQCFKLGT05AH29IsMiho = PU4SvriwgDRKdm(0,url)
	elif mode==377: lfZmugQCFKLGT05AH29IsMiho = PU4SvriwgDRKdm(1,url)
	elif mode==379: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-MENU-1st')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,379,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('right-side(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',j1IFsik4ouNePZr,375)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الأحدث',j1IFsik4ouNePZr,376)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قائمة الممثلين',j1IFsik4ouNePZr,374)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="container"(.*?)top-menu',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items[7:]:
			title = title.strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371)
		for cOn6JqZlmQbjtT,title in items[0:7]:
			title = title.strip(qE4nB3mKWHs)
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371)
	return
def LLOxfehDnVzcG263aHFNlBUvXPqr1o(website=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-ACTORSMENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="row cat Tags"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			if 'http' in cOn6JqZlmQbjtT: continue
			else: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371)
	return
def TctFVarD0UpL7SwJ9nbZH1euBGv2zP(website=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-FEATURED-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"MainContent"(.*?)main-title2',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('://',':///').replace('//','/').replace(qE4nB3mKWHs,'%20')
				QUzFYoapm9jx('video',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,372,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def PU4SvriwgDRKdm(id,website=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-WATCHINGNOW-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-title2(.*?)class="row',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[id]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			if not any(value in title for value in jgvMWZhtPlBT):
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('://',':///').replace('//','/').replace(qE4nB3mKWHs,'%20')
				QUzFYoapm9jx('video',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,372,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,LWsBIERzV9ADfKaNwg=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if 'vidpage_' in url:
		cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('href="(/Album-.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if cOn6JqZlmQbjtT:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT[0]
			yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(cOn6JqZlmQbjtT)
			return
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class=" subcats"(.*?)class="col-md-3',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if LWsBIERzV9ADfKaNwg==SebHIf2jL1TBgrMKJu and k2pC30UArFeg7Ru9tGiZlSmzQ and k2pC30UArFeg7Ru9tGiZlSmzQ[0].count('href')>1:
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',url,371,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'titles')
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)" title="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			cOn6JqZlmQbjtT = j1IFsik4ouNePZr+'/'+cOn6JqZlmQbjtT
			title = title.strip(qE4nB3mKWHs)
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371)
	else:
		aLlVEzy8XR62 = []
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="col-md-3(.*?)col-xs-12',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="col-sm-8"(.*?)col-xs-12',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
				title = title.strip(qE4nB3mKWHs)
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.replace('://',':///').replace('//','/').replace(qE4nB3mKWHs,'%20')
				if '/al_' in cOn6JqZlmQbjtT:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) - +الحلقة +\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					if Wj39BaH6oEmstx: title = '_MOD_مسلسل '+Wj39BaH6oEmstx[0]
					if title not in aLlVEzy8XR62:
						aLlVEzy8XR62.append(title)
						QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,372,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="pagination(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('class="".*?href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
				title = 'صفحة '+cvlHmV1Kr0FIYSjNnM(title)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,371,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'titles')
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	S5u2RZG3yCOl9gp8D4JVoa = X2XorVqHjLkWeCchY4u9fSz.findall('label-success mrg-btm-5 ">(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if S5u2RZG3yCOl9gp8D4JVoa and HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,url,S5u2RZG3yCOl9gp8D4JVoa): return
	iGxH2fsuScPtkJb7ECg = SebHIf2jL1TBgrMKJu
	qg7Nr1dCaD = X2XorVqHjLkWeCchY4u9fSz.findall('var url = "(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if qg7Nr1dCaD: qg7Nr1dCaD = qg7Nr1dCaD[0]
	else: qg7Nr1dCaD = url.replace('/vidpage_','/Play/')
	if 'http' not in qg7Nr1dCaD: qg7Nr1dCaD = j1IFsik4ouNePZr+qg7Nr1dCaD
	qg7Nr1dCaD = qg7Nr1dCaD.strip('-')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(B3vhTYqOtgUCAzPW,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'BOKRA-PLAY-2nd')
	O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
	iGxH2fsuScPtkJb7ECg = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if iGxH2fsuScPtkJb7ECg:
		iGxH2fsuScPtkJb7ECg = iGxH2fsuScPtkJb7ECg[-1]
		if 'http' not in iGxH2fsuScPtkJb7ECg: iGxH2fsuScPtkJb7ECg = 'http:'+iGxH2fsuScPtkJb7ECg
		if '/PLAY/' not in qg7Nr1dCaD:
			if 'embed.min.js' in iGxH2fsuScPtkJb7ECg:
				PdCr0knSxu2Mzl = X2XorVqHjLkWeCchY4u9fSz.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				if PdCr0knSxu2Mzl:
					EG6jDQ1Vk2HLshUluKMo3e9vwBO, Bg2PLMGAsXpKT0Rz3Ziuho54fJNtd = PdCr0knSxu2Mzl[0]
					iGxH2fsuScPtkJb7ECg = EDmwsQf1Px9k8h04oAHuObdnyrTGU(iGxH2fsuScPtkJb7ECg,'url')+'/v2/'+EG6jDQ1Vk2HLshUluKMo3e9vwBO+'/config/'+Bg2PLMGAsXpKT0Rz3Ziuho54fJNtd+'.json'
		import dBWq3E7PZC
		dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ([iGxH2fsuScPtkJb7ECg],tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/Search/'+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return