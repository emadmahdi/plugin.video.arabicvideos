# -*- coding: utf-8 -*-
import sys as yMqHPpxSEAFIwKecXdi40r8zL53
KloRq6tO2cirWNEFVkavSn3PXUyA = yMqHPpxSEAFIwKecXdi40r8zL53.version_info [0] == 2
aonjRKDYFb6xiCLE = 2048
S1glUOBJbXGevd = 7
def VtiFm82KYRj7WlB04e1kn3Svas (ZmICME9bPsr2FoNxq0k1Q):
	global aYkQFMUOAsh
	zRXd3ktrU60yKDNwbmivMAB8OYIhe = ord (ZmICME9bPsr2FoNxq0k1Q [-1])
	IIbuEagFn2t = ZmICME9bPsr2FoNxq0k1Q [:-1]
	wpmOgR5c3AzVehy9BT = zRXd3ktrU60yKDNwbmivMAB8OYIhe % len (IIbuEagFn2t)
	al7CFvVNjWfJ04LmGPOdyM5UTRs = IIbuEagFn2t [:wpmOgR5c3AzVehy9BT] + IIbuEagFn2t [wpmOgR5c3AzVehy9BT:]
	if KloRq6tO2cirWNEFVkavSn3PXUyA:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = unicode () .join ([unichr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	else:
		KKbqGudesSfOjvzLxNCFgEtMBP8nh = str () .join ([chr (ord (vCleFtJugj6Hn7K82SNksbZ03cz1) - aonjRKDYFb6xiCLE - (SSEOIGZKn2RU8Lb + zRXd3ktrU60yKDNwbmivMAB8OYIhe) % S1glUOBJbXGevd) for SSEOIGZKn2RU8Lb, vCleFtJugj6Hn7K82SNksbZ03cz1 in enumerate (al7CFvVNjWfJ04LmGPOdyM5UTRs)])
	return eval (KKbqGudesSfOjvzLxNCFgEtMBP8nh)
Izy1PvclrYx4eSVWn0L5phZbq,qeYIw0BNTL9bGJnosacQ1DtVR,VOALf8iYEnMdK0g=VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas,VtiFm82KYRj7WlB04e1kn3Svas
vMhFypGLHZJbdX4O7oc3W8x,gCkRKGhwcx26v,sTGtHVyhQ9cJU37zxo2O=VOALf8iYEnMdK0g,qeYIw0BNTL9bGJnosacQ1DtVR,Izy1PvclrYx4eSVWn0L5phZbq
fp6KV7DlS8QYniUczHdmZChL,Ns6AJKH7DGpr19Wl5C3nF,v532vWgiKz8Z7IEhJeXLCp6A9wnM=sTGtHVyhQ9cJU37zxo2O,gCkRKGhwcx26v,vMhFypGLHZJbdX4O7oc3W8x
uqLUBHepfM3l6AyIzTJh80a,wPnfgxKZdAv6T10,HADrRCz9QgU4xudPJIqYb70=v532vWgiKz8Z7IEhJeXLCp6A9wnM,Ns6AJKH7DGpr19Wl5C3nF,fp6KV7DlS8QYniUczHdmZChL
TVnqDYzWoM2UfHp0dchJ,bcNqYtfET5l92dLGjyZSPe,iDhLkZS6XBagNCQfs9tq2=HADrRCz9QgU4xudPJIqYb70,wPnfgxKZdAv6T10,uqLUBHepfM3l6AyIzTJh80a
l7kBpMw5Qn,DQIrVcKuY6bJv,tX7u5idnzTVNva3PlmJD1I80rxch4=iDhLkZS6XBagNCQfs9tq2,bcNqYtfET5l92dLGjyZSPe,TVnqDYzWoM2UfHp0dchJ
Gykx0wL3XrlWaujsqKP9n2Q,NUbVrRi4nq6BXmAOcM1zGtgJ,AGlW9LqKN3Dvo=tX7u5idnzTVNva3PlmJD1I80rxch4,DQIrVcKuY6bJv,l7kBpMw5Qn
xxRyYsrSCzjifvH4cIqgldeOo,ASkvf27etUK0,ALwOspNtXxZrz3PEKku=AGlW9LqKN3Dvo,NUbVrRi4nq6BXmAOcM1zGtgJ,Gykx0wL3XrlWaujsqKP9n2Q
j2eKYcTFGf7q9XVgJCUukrtiAEs,HCiWF4jV1Q8,zpx2fPNKk6Ms38eD1vcO=ALwOspNtXxZrz3PEKku,ASkvf27etUK0,xxRyYsrSCzjifvH4cIqgldeOo
C3w6qluao7EzUxJgMGBtV,czvu7VQCZodkMf,ypO63g8oJEsDnPBHSuU7lMTZr=zpx2fPNKk6Ms38eD1vcO,HCiWF4jV1Q8,j2eKYcTFGf7q9XVgJCUukrtiAEs
t0FTYwCdi8jVaDu4EWBzUKbGLl,Ju4YmhHgrMt0SpVCqOlBfQRDGby,cH6vtRYxN51hXlbjDzn2esfg0Vokaq=ypO63g8oJEsDnPBHSuU7lMTZr,czvu7VQCZodkMf,C3w6qluao7EzUxJgMGBtV
from SSCitzlpRq import *
from xQGdJvfp3S import *
import base64 as ej3oxQLc68OIY
tfX4sO3hy2H1IbKG = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐ༵ࠩ")
if QBOMjKifEAFD:
	bnPKxNoAtLQaOC0iSg = eEobpYW3xM1.translatePath(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ༶"))
	qNJcywXjKbdP8ihIrZ5CBaVl = eEobpYW3xM1.translatePath(Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮༷ࠧ"))
	LL0FBaOIs7DRvzw1Y = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,ASkvf27etUK0(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭༸"),wPnfgxKZdAv6T10(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫༹ࠧ"),Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ༺"))
	TSo3zCDwlHX8Ry152QkWFU0AIvex9 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,wPnfgxKZdAv6T10(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ༻"),VOALf8iYEnMdK0g(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ༼"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ༽"))
	ivOwEroeDmMKau = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ༾"),zpx2fPNKk6Ms38eD1vcO(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭༿"),xxRyYsrSCzjifvH4cIqgldeOo(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬཀ"))
	from urllib.parse import quote as _bMHNxk92Bwil7
else:
	bnPKxNoAtLQaOC0iSg = if5dy2h0nsDVlukoQ7NUFqx4cGEW.translatePath(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧཁ"))
	qNJcywXjKbdP8ihIrZ5CBaVl = if5dy2h0nsDVlukoQ7NUFqx4cGEW.translatePath(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫག"))
	LL0FBaOIs7DRvzw1Y = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪགྷ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫང"),wPnfgxKZdAv6T10(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨཅ"))
	TSo3zCDwlHX8Ry152QkWFU0AIvex9 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,ALwOspNtXxZrz3PEKku(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ཆ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧཇ"),ALwOspNtXxZrz3PEKku(u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭཈"))
	ivOwEroeDmMKau = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩཉ"),ALwOspNtXxZrz3PEKku(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪཊ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩཋ"))
	from urllib import quote as _bMHNxk92Bwil7
ASIWYZHDvLfX05Ghxj2qEiJuy4U6b = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(qNJcywXjKbdP8ihIrZ5CBaVl,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬཌ"))
DM3tJCGvZk0sn4brxShAHwWfgio = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(qNJcywXjKbdP8ihIrZ5CBaVl,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡰࡵࡤࡪ࠰ࡲࡰࡩ࠴࡬ࡰࡩࠪཌྷ"))
Ugs2uOYmCiTe4Vrfy1zIaFdKQLP = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,ASkvf27etUK0(u"ࠬ࡯ࡰࡵࡸ࠴ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧཎ"))
O60OuGpUnELoZdfNqIkM935vXjy = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,gCkRKGhwcx26v(u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨཏ"))
iZHe2ulY46PhoEm9tOaNcvG5SM = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,iDhLkZS6XBagNCQfs9tq2(u"ࠧ࡮࠵ࡸࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧཐ"))
NnA1JBy7DVvFqcm = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷ࠳ࡪࡡࡵࠩད"))
Cm2AsjSwVb = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,l7kBpMw5Qn(u"ࠩ࡬ࡴࡹࡼࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫདྷ"))
RIUgY7kyPSuNqftO3W8Dl = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,ALwOspNtXxZrz3PEKku(u"ࠪࡱ࠸ࡻࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫན"))
H89ROLBIpC6xENc7kh3Fd4wlQtWXP = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,l7kBpMw5Qn(u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭པ"))
VgcCXWtshDeiG1lmAMBb3w80 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,HADrRCz9QgU4xudPJIqYb70(u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨཕ"))
zcFNA9n0b7qZrwf63kxumUSTWaMo2 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪབ"))
SsauT49YLOtnGfCAyBKob = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫབྷ"))
NNU7L4e8gr3zhp2kRIXxZt1 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,VOALf8iYEnMdK0g(u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨམ"))
qb5p71oLleV = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭ཙ"))
lUPW4qD1NG7B = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪཚ"))
gRBQPAfrHk = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,bcNqYtfET5l92dLGjyZSPe(u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪཛ"))
jwze0TH4ZKbrp = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬཛྷ"))
TPamrY4p9IEN = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,ASkvf27etUK0(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ཝ"))
RDe3KW1pbmjV4xZ0wfcrFu58iQg6 = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,ASkvf27etUK0(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩཞ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬཟ"),WYGV2HQo6sfnqSDZEcK9Cu4TP)
bbXNHlqO2VBxsEe = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(RDe3KW1pbmjV4xZ0wfcrFu58iQg6,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨའ"))
UhVo2EkBpMC = set(qFsuKN7ngp.BADWEBSITES)
RjqxpwMymsZ7v6cGhLlBn52zi = [JJSOAkTZIib4eswDo51pFuqvK for JJSOAkTZIib4eswDo51pFuqvK in RjqxpwMymsZ7v6cGhLlBn52zi if JJSOAkTZIib4eswDo51pFuqvK not in UhVo2EkBpMC]
ET1o47LkJSlCjMhAOHVzKNs53i8Gr = [JJSOAkTZIib4eswDo51pFuqvK for JJSOAkTZIib4eswDo51pFuqvK in ET1o47LkJSlCjMhAOHVzKNs53i8Gr if JJSOAkTZIib4eswDo51pFuqvK not in UhVo2EkBpMC]
bHVThUqlANJkcY9DWLou1i = [JJSOAkTZIib4eswDo51pFuqvK for JJSOAkTZIib4eswDo51pFuqvK in bHVThUqlANJkcY9DWLou1i if JJSOAkTZIib4eswDo51pFuqvK not in UhVo2EkBpMC]
ehtRkZ2gDKFELmIuOaA = [JJSOAkTZIib4eswDo51pFuqvK for JJSOAkTZIib4eswDo51pFuqvK in ehtRkZ2gDKFELmIuOaA if JJSOAkTZIib4eswDo51pFuqvK not in UhVo2EkBpMC]
eJyScsgaRtx3XwFHlDYqNmO7r = [JJSOAkTZIib4eswDo51pFuqvK for JJSOAkTZIib4eswDo51pFuqvK in eJyScsgaRtx3XwFHlDYqNmO7r if JJSOAkTZIib4eswDo51pFuqvK not in UhVo2EkBpMC]
class BU0NzOhc2Cv7V9WMLEQRq():
	def __init__(sYhGUD7CrxpWtj,showDialogs=mrhSYXH2P8bO3eJAa9n,logErrors=BBX9RAuxnyGZ4WIF2TrhYeom3):
		sYhGUD7CrxpWtj.showDialogs = showDialogs
		sYhGUD7CrxpWtj.logErrors = logErrors
		sYhGUD7CrxpWtj.finishedLIST,sYhGUD7CrxpWtj.failedLIST = [],[]
		sYhGUD7CrxpWtj.statusDICT,sYhGUD7CrxpWtj.resultsDICT = {},{}
		sYhGUD7CrxpWtj.processesLIST = []
		sYhGUD7CrxpWtj.starttimeDICT,sYhGUD7CrxpWtj.finishtimeDICT,sYhGUD7CrxpWtj.elpasedtimeDICT = {},{},{}
	def bbKpGqOy9lNjFduSUXYnHe3Pik(sYhGUD7CrxpWtj,fwDM2gXmtlpNsi4aPv,khjB9e254lrqciA7vHp03Gosxa,*aargs):
		fwDM2gXmtlpNsi4aPv = str(fwDM2gXmtlpNsi4aPv)
		sYhGUD7CrxpWtj.statusDICT[fwDM2gXmtlpNsi4aPv] = Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫཡ")
		if sYhGUD7CrxpWtj.showDialogs: i9yzUqgAW2Zap1h4Lm(SebHIf2jL1TBgrMKJu,fwDM2gXmtlpNsi4aPv)
		DGpUszFj8mJ = yrEnWvjhd5o8GKY1FU42A(daemon=BBX9RAuxnyGZ4WIF2TrhYeom3,target=sYhGUD7CrxpWtj.rjO9iAYRwZDb5KPygf,args=(fwDM2gXmtlpNsi4aPv,khjB9e254lrqciA7vHp03Gosxa,aargs))
		sYhGUD7CrxpWtj.processesLIST.append(DGpUszFj8mJ)
		return DGpUszFj8mJ
	def Y3WXTHPjwo1Z(sYhGUD7CrxpWtj,fwDM2gXmtlpNsi4aPv,khjB9e254lrqciA7vHp03Gosxa,*aargs):
		DGpUszFj8mJ = sYhGUD7CrxpWtj.bbKpGqOy9lNjFduSUXYnHe3Pik(fwDM2gXmtlpNsi4aPv,khjB9e254lrqciA7vHp03Gosxa,*aargs)
		DGpUszFj8mJ.start()
	def rjO9iAYRwZDb5KPygf(sYhGUD7CrxpWtj,fwDM2gXmtlpNsi4aPv,khjB9e254lrqciA7vHp03Gosxa,aargs):
		fwDM2gXmtlpNsi4aPv = str(fwDM2gXmtlpNsi4aPv)
		sYhGUD7CrxpWtj.starttimeDICT[fwDM2gXmtlpNsi4aPv] = uv8V4fE7j9pmgFr3wnDL.time()
		try:
			sYhGUD7CrxpWtj.resultsDICT[fwDM2gXmtlpNsi4aPv] = khjB9e254lrqciA7vHp03Gosxa(*aargs)
			if czvu7VQCZodkMf(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬར") in str(khjB9e254lrqciA7vHp03Gosxa) and not sYhGUD7CrxpWtj.resultsDICT[fwDM2gXmtlpNsi4aPv].succeeded: LbTfk6oJPiSGpVMU()
			sYhGUD7CrxpWtj.finishedLIST.append(fwDM2gXmtlpNsi4aPv)
			sYhGUD7CrxpWtj.statusDICT[fwDM2gXmtlpNsi4aPv] = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧལ")
		except Exception as kQhFMNbH2U:
			if sYhGUD7CrxpWtj.logErrors:
				yamjrsOAG4iFfQkuW1JXbZ0Dgq7z = HkQJ95ahZMwW0OtpKU2X.format_exc()
				if yamjrsOAG4iFfQkuW1JXbZ0Dgq7z!=HCiWF4jV1Q8(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩཤ"): yMqHPpxSEAFIwKecXdi40r8zL53.stderr.write(yamjrsOAG4iFfQkuW1JXbZ0Dgq7z)
			sYhGUD7CrxpWtj.failedLIST.append(fwDM2gXmtlpNsi4aPv)
			sYhGUD7CrxpWtj.statusDICT[fwDM2gXmtlpNsi4aPv] = HCiWF4jV1Q8(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧཥ")
		sYhGUD7CrxpWtj.finishtimeDICT[fwDM2gXmtlpNsi4aPv] = uv8V4fE7j9pmgFr3wnDL.time()
		sYhGUD7CrxpWtj.elpasedtimeDICT[fwDM2gXmtlpNsi4aPv] = sYhGUD7CrxpWtj.finishtimeDICT[fwDM2gXmtlpNsi4aPv] - sYhGUD7CrxpWtj.starttimeDICT[fwDM2gXmtlpNsi4aPv]
	def oh1EefzLUF(sYhGUD7CrxpWtj):
		for qDCoXBSULufYwprzmvbjHTJE41GcK in sYhGUD7CrxpWtj.processesLIST:
			qDCoXBSULufYwprzmvbjHTJE41GcK.start()
	def dlQKj7kWX8enP1viNuaEBULtD9OcAy(sYhGUD7CrxpWtj):
		while vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩས") in list(sYhGUD7CrxpWtj.statusDICT.values()): uv8V4fE7j9pmgFr3wnDL.sleep(czvu7VQCZodkMf(u"࠷ᕽ"))
def WRvTPUM6gVodE51():
	if not ptIsx9oHqB0dXK: return NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬཧ")
	ry8UXpZPlTwuBvVgsDjktfeIKzEL = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨཨ")
	pr48bMBimXA9h6P7vlsEOWTQ = [AGlW9LqKN3Dvo(u"ࠫ࠽࠴࠵࠯࠲ࠪཀྵ"),l7kBpMw5Qn(u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩཪ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫཫ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫཬ"),DQIrVcKuY6bJv(u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ཭"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭཮"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ཯"),czvu7VQCZodkMf(u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ཰"),gCkRKGhwcx26v(u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ཱࠩ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ིࠪ"),TVnqDYzWoM2UfHp0dchJ(u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ཱིࠫ"),iDhLkZS6XBagNCQfs9tq2(u"ࠨ࠴࠳࠶࠹࠴࠰࠸࠰࠵࠴ུࠬ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩ࠵࠴࠷࠻࠮࠱࠷࠱࠴࠺ཱུ࠭")]
	GXgVjUnZcLbAe43d7Civ = pr48bMBimXA9h6P7vlsEOWTQ[-nyUIsfd53EGot9vbj0XDeq]
	X74YPbO9dnScrKpNvIBAlZ1Vf6ia = ZFztKMGiCmdNLyewoW4A96TJsf5R(GXgVjUnZcLbAe43d7Civ)
	I7KXcwvm5xtrZzQ = ZFztKMGiCmdNLyewoW4A96TJsf5R(xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV)
	if I7KXcwvm5xtrZzQ>X74YPbO9dnScrKpNvIBAlZ1Vf6ia:
		ry8UXpZPlTwuBvVgsDjktfeIKzEL = vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪྲྀ")
	return ry8UXpZPlTwuBvVgsDjktfeIKzEL
def YnFwHlkv9We3iEPqzpSOR(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7):
	aa7hMXY6GJUKISNQj9TEt,b8vi9XVU7J4eKYRQgBmnNT5dckf = SebHIf2jL1TBgrMKJu,mrhSYXH2P8bO3eJAa9n
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7: aa7hMXY6GJUKISNQj9TEt = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡸࡺࡲࠨཷ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪླྀ"),DQIrVcKuY6bJv(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨཹ"))
	if not aa7hMXY6GJUKISNQj9TEt:
		pfhH2objgVkI7eycn = qFsuKN7ngp.SITESURLS[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡑ࡛ࡗࡌࡔࡔེࠧ")][tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠹ᕾ")]
		IbRUyxhZBYz = {NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡷࡶࡩࡷཻ࠭"):qFsuKN7ngp.AV_CLIENT_IDS,Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡹࡩࡷࡹࡩࡰࡰོࠪ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV}
		aa7hMXY6GJUKISNQj9TEt = nnyt5esYvlQ0zUZCJW4bgiAB2uxFL(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡔࡔ࡙ࡔࠨཽ"),pfhH2objgVkI7eycn,IbRUyxhZBYz,SebHIf2jL1TBgrMKJu,wPnfgxKZdAv6T10(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡣࡕ࡟ࡔࡉࡑࡑࡣࡈࡕࡄࡆ࠯࠴ࡷࡹ࠭ཾ"))
		zzcbV5F4iSjM2(qFsuKN7ngp.api_python_actions[vMhFypGLHZJbdX4O7oc3W8x(u"࠺ᕿ")])
		if aa7hMXY6GJUKISNQj9TEt: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,AGlW9LqKN3Dvo(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪཿ"),TVnqDYzWoM2UfHp0dchJ(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨྀ"),aa7hMXY6GJUKISNQj9TEt,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
		b8vi9XVU7J4eKYRQgBmnNT5dckf = BBX9RAuxnyGZ4WIF2TrhYeom3
	if aa7hMXY6GJUKISNQj9TEt:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
		exec(aa7hMXY6GJUKISNQj9TEt,globals(),locals())
		qFsuKN7ngp.SITESURLS.update(NEW_SITESURLS)
		qFsuKN7ngp.BADSCRAPERS = list(set(qFsuKN7ngp.BADSCRAPERS+NEW_BADSCRAPERS))
		qFsuKN7ngp.BADCOMMONIDS = list(set(qFsuKN7ngp.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV in list(NEW_BADWEBSITES.keys()): qFsuKN7ngp.BADWEBSITES += NEW_BADWEBSITES[xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV]
	return b8vi9XVU7J4eKYRQgBmnNT5dckf
def EsQLYc249F0():
	try: E2xjtKaMXdC3NDoTm7f5Wkev.makedirs(LdX87mwIzyBM)
	except: pass
	wj37a2JnVp4u16vClTBg8YOQreILq = WRvTPUM6gVodE51()
	if wj37a2JnVp4u16vClTBg8YOQreILq==HCiWF4jV1Q8(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋཱྀࠧ"): z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,DQIrVcKuY6bJv(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧྂ")+EWTFwqJoXHGSjsRfhOI5YLM+DQIrVcKuY6bJv(u"ࠩࠣࡡࠬྃ"))
	else: z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤࠥࡌࡕࡍࡎ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠ྄ࠦࠧ")+EWTFwqJoXHGSjsRfhOI5YLM+AGlW9LqKN3Dvo(u"ࠫࠥࡣࠧ྅"))
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,wPnfgxKZdAv6T10(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬ྆")+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV)
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ASkvf27etUK0(u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ྇"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬྈ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭ྉ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬྊ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨྋ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧྌ"),uqLUBHepfM3l6AyIzTJh80a(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪྍ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,sTGtHVyhQ9cJU37zxo2O(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩྎ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭ྏ"))
	MMAUZiw4CoJ8.setSetting(Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨྐ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(AGlW9LqKN3Dvo(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫྑ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(VOALf8iYEnMdK0g(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ྒ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧྒྷ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨྔ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨྕ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬྖ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨྗ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(HCiWF4jV1Q8(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭྘"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(l7kBpMw5Qn(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫྙ"),SebHIf2jL1TBgrMKJu)
	MMAUZiw4CoJ8.setSetting(VOALf8iYEnMdK0g(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ྚ"),SebHIf2jL1TBgrMKJu)
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,uqLUBHepfM3l6AyIzTJh80a(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ྛ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ྜ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,czvu7VQCZodkMf(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ྜྷ"))
	pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,gCkRKGhwcx26v(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪྞ"))
	GGeyKjEOzHdn2I4BkXglo37(mrhSYXH2P8bO3eJAa9n)
	zGBSOdsWh8uLHbfw9qmxlioR7tDpy(RycFd7wZBiNhJjOPIGKp)
	import WW03V9yQKJ
	WW03V9yQKJ.j3jFtGCKvzmOBwaX2ibogEx4JRqQD(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩྟ"),mrhSYXH2P8bO3eJAa9n)
	WW03V9yQKJ.j3jFtGCKvzmOBwaX2ibogEx4JRqQD(fp6KV7DlS8QYniUczHdmZChL(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ྠ"),mrhSYXH2P8bO3eJAa9n)
	WW03V9yQKJ.j3jFtGCKvzmOBwaX2ibogEx4JRqQD(ASkvf27etUK0(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡩࡪࡲࡶࡥࡨࡦ࡬ࡶࡪࡩࡴࠨྡ"),mrhSYXH2P8bO3eJAa9n)
	WW03V9yQKJ.eex4VdtZ9fUsJhB7(BBX9RAuxnyGZ4WIF2TrhYeom3)
	WW03V9yQKJ.nZsMNoSJmxeuWOdQUcCR4lBa(mrhSYXH2P8bO3eJAa9n)
	if wj37a2JnVp4u16vClTBg8YOQreILq==bcNqYtfET5l92dLGjyZSPe(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬྡྷ"):
		ozd2DGF8PR73cwJj0SOUmZNuXH(BBX9RAuxnyGZ4WIF2TrhYeom3,[E8Eo9FKSM5bhgRYlCWZHqPmt])
	else:
		ozd2DGF8PR73cwJj0SOUmZNuXH(mrhSYXH2P8bO3eJAa9n,[])
		WW03V9yQKJ.PDRwMfC9Xu4A()
		try:
			BBHvFfXS5Pg = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྣ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྤ"),ASkvf27etUK0(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬྥ"),wPnfgxKZdAv6T10(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྦ"))
			yLqCz45QXYZ7mxOtH26u = zEAv9DdhYJikZsrIC1p5cxF8H.Addon(id=C3w6qluao7EzUxJgMGBtV(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧྦྷ"))
			yLqCz45QXYZ7mxOtH26u.setSetting(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪྨ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࡌࡡ࡭ࡵࡨࠫྩ"))
		except: pass
		try:
			BBHvFfXS5Pg = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,VOALf8iYEnMdK0g(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྪ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྫ"),l7kBpMw5Qn(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨྫྷ"),l7kBpMw5Qn(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྭ"))
			yLqCz45QXYZ7mxOtH26u = zEAv9DdhYJikZsrIC1p5cxF8H.Addon(id=ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪྮ"))
			yLqCz45QXYZ7mxOtH26u.setSetting(vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧྯ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬ࠹ࠧྰ"))
		except: pass
		try:
			BBHvFfXS5Pg = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,wPnfgxKZdAv6T10(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨྱ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫྲ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨླ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨྴ"))
			yLqCz45QXYZ7mxOtH26u = zEAv9DdhYJikZsrIC1p5cxF8H.Addon(id=ALwOspNtXxZrz3PEKku(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪྵ"))
			yLqCz45QXYZ7mxOtH26u.setSetting(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩྶ"),czvu7VQCZodkMf(u"ࠬ࠸ࠧྷ"))
		except: pass
	qqTB9mr0Av7jKg3UOYzLl = Pvf1zMmXRJnipdHDbFeV4r(dUj4HNoGp91APu6itnl3BCc)
	qqTB9mr0Av7jKg3UOYzLl = Pvf1zMmXRJnipdHDbFeV4r(NnA1JBy7DVvFqcm)
	WW03V9yQKJ.nX1fcGsDgR53yQkiUB(mrhSYXH2P8bO3eJAa9n)
	MMAUZiw4CoJ8.setSetting(HCiWF4jV1Q8(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪྸ"),xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV)
	GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def w14FX6gYVdAZMtU(hhUXrunoxlSpv5mif64jWe2E3DA):
	b8vi9XVU7J4eKYRQgBmnNT5dckf = YnFwHlkv9We3iEPqzpSOR(BBX9RAuxnyGZ4WIF2TrhYeom3)
	if b8vi9XVU7J4eKYRQgBmnNT5dckf:
		return
	efZCUm5pBaw98YTtH3bnv12hoEAIy = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬྐྵ")))
	efZCUm5pBaw98YTtH3bnv12hoEAIy = wvkDqmNZlJU52isXo if not efZCUm5pBaw98YTtH3bnv12hoEAIy else int(efZCUm5pBaw98YTtH3bnv12hoEAIy)
	if not efZCUm5pBaw98YTtH3bnv12hoEAIy or not wvkDqmNZlJU52isXo<=H3a6hvAgeNctTiXF8d1uELfPr4y-efZCUm5pBaw98YTtH3bnv12hoEAIy<=vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu:
		MMAUZiw4CoJ8.setSetting(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭ྺ"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
		zGBSOdsWh8uLHbfw9qmxlioR7tDpy(RycFd7wZBiNhJjOPIGKp)
		return
	WHBNVnQLkcwya09JGmRu = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫྻ")))
	WHBNVnQLkcwya09JGmRu = wvkDqmNZlJU52isXo if not WHBNVnQLkcwya09JGmRu else int(WHBNVnQLkcwya09JGmRu)
	MUL8j7T4uxr916Kv5 = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬྼ")))
	MUL8j7T4uxr916Kv5 = wvkDqmNZlJU52isXo if not MUL8j7T4uxr916Kv5 else int(MUL8j7T4uxr916Kv5)
	if not WHBNVnQLkcwya09JGmRu or not MUL8j7T4uxr916Kv5 or not wvkDqmNZlJU52isXo<=H3a6hvAgeNctTiXF8d1uELfPr4y-MUL8j7T4uxr916Kv5<=WHBNVnQLkcwya09JGmRu:
		deQu2Dwo9mMSi4tG(BBX9RAuxnyGZ4WIF2TrhYeom3,WHBNVnQLkcwya09JGmRu)
		return
	uuoj4CqT8YFhgGNmi0SP = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(Ns6AJKH7DGpr19Wl5C3nF(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫ྽")))
	uuoj4CqT8YFhgGNmi0SP = wvkDqmNZlJU52isXo if not uuoj4CqT8YFhgGNmi0SP else int(uuoj4CqT8YFhgGNmi0SP)
	if not uuoj4CqT8YFhgGNmi0SP or not wvkDqmNZlJU52isXo<=H3a6hvAgeNctTiXF8d1uELfPr4y-uuoj4CqT8YFhgGNmi0SP<=QfG1xIZ4hpq3ezPXt7VbvglUcB:
		MMAUZiw4CoJ8.setSetting(vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬ྾"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
		YnFwHlkv9We3iEPqzpSOR(mrhSYXH2P8bO3eJAa9n)
		return
	if mrhSYXH2P8bO3eJAa9n:
		aAk3HCDudiVSREWz6x2PQ7sN = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ྿")))
		aAk3HCDudiVSREWz6x2PQ7sN = wvkDqmNZlJU52isXo if not aAk3HCDudiVSREWz6x2PQ7sN else int(aAk3HCDudiVSREWz6x2PQ7sN)
		if not aAk3HCDudiVSREWz6x2PQ7sN or not wvkDqmNZlJU52isXo<=H3a6hvAgeNctTiXF8d1uELfPr4y-aAk3HCDudiVSREWz6x2PQ7sN<=iHR47eol8wB3Z:
			MMAUZiw4CoJ8.setSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ࿀"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
	return
def deQu2Dwo9mMSi4tG(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7,WHBNVnQLkcwya09JGmRu):
	RJUTQ6qu2kwIOEA9 = nyUIsfd53EGot9vbj0XDeq
	YBIkH2FTzyK0rpRiLZ7 = mrhSYXH2P8bO3eJAa9n if qFsuKN7ngp.PGAlYK9BwWR else BBX9RAuxnyGZ4WIF2TrhYeom3
	if YBIkH2FTzyK0rpRiLZ7:
		if not WHBNVnQLkcwya09JGmRu: AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 = mrhSYXH2P8bO3eJAa9n
		kkHrpxZmdYPM = Ta7zPgmdrNZIvqxo5(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7)
		if len(kkHrpxZmdYPM)>nyUIsfd53EGot9vbj0XDeq:
			z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,AGlW9LqKN3Dvo(u"ࠨ࠰࡟ࡸࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ࿁")+EWTFwqJoXHGSjsRfhOI5YLM+C3w6qluao7EzUxJgMGBtV(u"ࠩࠣࡡࠬ࿂"))
			fwDM2gXmtlpNsi4aPv,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ESvoylf2GA5ni8HXstaDcF43,rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = kkHrpxZmdYPM[wvkDqmNZlJU52isXo]
			OqIAWEyTkJrhaL8s7gb,RRQeJupBdtIogH2MNiK = rtfbXCjOD8pdgFSn7zTous2wY5y.split(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࡠࡳࡁ࠻ࠨ࿃"))
			del kkHrpxZmdYPM[wvkDqmNZlJU52isXo]
			rR5J7y16ku3nEoBSLbF = JO7n9zxwdgIStrTjR.sample(kkHrpxZmdYPM,nyUIsfd53EGot9vbj0XDeq)
			fwDM2gXmtlpNsi4aPv,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ESvoylf2GA5ni8HXstaDcF43,rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = rR5J7y16ku3nEoBSLbF[wvkDqmNZlJU52isXo]
			ESvoylf2GA5ni8HXstaDcF43 = wPnfgxKZdAv6T10(u"ࠫࡠࡘࡔࡍ࡟ࠪ࿄")+QNR6tCevIGEZKX3rAVsP+gCkRKGhwcx26v(u"ࠬࠦ࠺ࠡࠩ࿅")+fwDM2gXmtlpNsi4aPv+XOVRfitWJP1zL3p2CMYF+ESvoylf2GA5ni8HXstaDcF43
			gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะ࿆ࠬ")
			vAOJtnhNyIlUiT2 = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧศๆอฬึ฿วหࠩ࿇")
			button0,button1 = rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq
			zwA9GVoWeIT7lZdH6 = [button0,button1,vAOJtnhNyIlUiT2]
			WarvGKnc1uLAsx2 = nyUIsfd53EGot9vbj0XDeq if qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h else VOALf8iYEnMdK0g(u"࠳࠳ᖀ")
			x5BZ9SJfFAWV743cgCvoUamse = -tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠼ᖁ")
			while x5BZ9SJfFAWV743cgCvoUamse<wvkDqmNZlJU52isXo:
				kx4bODRSKeLQshPZp = JO7n9zxwdgIStrTjR.sample(zwA9GVoWeIT7lZdH6,fuCbjVag7vU908J2Yqx5Th)
				x5BZ9SJfFAWV743cgCvoUamse = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,kx4bODRSKeLQshPZp[wvkDqmNZlJU52isXo],kx4bODRSKeLQshPZp[nyUIsfd53EGot9vbj0XDeq],kx4bODRSKeLQshPZp[JhTts2R43AxkM8bYanKVy],OqIAWEyTkJrhaL8s7gb,ESvoylf2GA5ni8HXstaDcF43,fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿈"),WarvGKnc1uLAsx2,uqLUBHepfM3l6AyIzTJh80a(u"࠺࠵ᖂ"))
				if x5BZ9SJfFAWV743cgCvoUamse==NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠶࠶ᖃ"): break
				import WW03V9yQKJ
				if x5BZ9SJfFAWV743cgCvoUamse>=wvkDqmNZlJU52isXo and kx4bODRSKeLQshPZp[x5BZ9SJfFAWV743cgCvoUamse]==zwA9GVoWeIT7lZdH6[nyUIsfd53EGot9vbj0XDeq]:
					WW03V9yQKJ.CQgMI2jYDy4F()
					if x5BZ9SJfFAWV743cgCvoUamse>=wvkDqmNZlJU52isXo: x5BZ9SJfFAWV743cgCvoUamse = -j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠿ᖄ")
				elif x5BZ9SJfFAWV743cgCvoUamse>=wvkDqmNZlJU52isXo and kx4bODRSKeLQshPZp[x5BZ9SJfFAWV743cgCvoUamse]==zwA9GVoWeIT7lZdH6[JhTts2R43AxkM8bYanKVy]:
					WW03V9yQKJ.UrNpagjyiLOqhPT6VMB8XGv74AQt(mrhSYXH2P8bO3eJAa9n)
				if x5BZ9SJfFAWV743cgCvoUamse==-nyUIsfd53EGot9vbj0XDeq: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,QNR6tCevIGEZKX3rAVsP+Ns6AJKH7DGpr19Wl5C3nF(u"ࠩัีําࠠฯูฦࠫ࿉")+XOVRfitWJP1zL3p2CMYF+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ࿊"))
			RJUTQ6qu2kwIOEA9 = nyUIsfd53EGot9vbj0XDeq
		else: RJUTQ6qu2kwIOEA9 = wvkDqmNZlJU52isXo
	MMAUZiw4CoJ8.setSetting(czvu7VQCZodkMf(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭࿋"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ࿌"),ASkvf27etUK0(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ࿍"),RJUTQ6qu2kwIOEA9,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	return
def DMWBoHbLsFx9P6h(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM,hhUXrunoxlSpv5mif64jWe2E3DA,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ):
	if KgLR54vJkSH30D7UOTrFoPq in [tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࠲ࠩ࿎"),TVnqDYzWoM2UfHp0dchJ(u"ࠨ࠴ࠪ࿏"),ALwOspNtXxZrz3PEKku(u"ࠩ࠶ࠫ࿐"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࠸ࠬ࿑"),VOALf8iYEnMdK0g(u"ࠫ࠺࠭࿒"),TVnqDYzWoM2UfHp0dchJ(u"ࠬ࠷࠱ࠨ࿓"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࠱࠳ࠩ࿔"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࠲࠵ࠪ࿕")] and z4drqDgH1Cy7uwtTl6MVJ:
		import E9k1y0GguP
		E9k1y0GguP.CDREpFuBf7ONV8ej4qwKm2J9Ysd(QdZVWe64OSKPfuXnz81m2qoHAJID,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ)
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n,EWTFwqJoXHGSjsRfhOI5YLM)
	elif KgLR54vJkSH30D7UOTrFoPq==ALwOspNtXxZrz3PEKku(u"ࠨ࠸ࠪ࿖"):
		import RSdDifzoPG,xQGdJvfp3S
		if z4drqDgH1Cy7uwtTl6MVJ==fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ࿗"): xQGdJvfp3S.i9yzUqgAW2Zap1h4Lm(fp6KV7DlS8QYniUczHdmZChL(u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪ࿘"),l7kBpMw5Qn(u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫ࿙"),uv8V4fE7j9pmgFr3wnDL=zpx2fPNKk6Ms38eD1vcO(u"࠲࠱࠲࠳ᖅ"))
		elif z4drqDgH1Cy7uwtTl6MVJ==HADrRCz9QgU4xudPJIqYb70(u"ࠬࡊࡅࡍࡇࡗࡉࠬ࿚"): QFYHD0lmU6PtTWaqE5NyuziX72(vCsnpu14Zi7qUEQg3Tl50h,mrhSYXH2P8bO3eJAa9n)
		lfZmugQCFKLGT05AH29IsMiho = RSdDifzoPG.GkAg0ZqR2cnPW9wvUtfj(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,hhUXrunoxlSpv5mif64jWe2E3DA,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
		if z4drqDgH1Cy7uwtTl6MVJ==zpx2fPNKk6Ms38eD1vcO(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ࿛"): LbTfk6oJPiSGpVMU()
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧ࠸ࠩ࿜"):
		import x3xyuCUV0G
		x3xyuCUV0G.xfvRgHOZDr0ESTo2hnWMdlLGQVwkCX(VOALf8iYEnMdK0g(u"ࠨࡡࡄࡐࡑ࠭࿝"))
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==ASkvf27etUK0(u"ࠩ࠻ࠫ࿞"): if5dy2h0nsDVlukoQ7NUFqx4cGEW.executebuiltin(czvu7VQCZodkMf(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ࿟")+WYGV2HQo6sfnqSDZEcK9Cu4TP+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ࿠")+str(A9x6WFVrq3cG8)+vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ࿡"))
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==Ns6AJKH7DGpr19Wl5C3nF(u"࠭࠹ࠨ࿢"):
		GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3)
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==ALwOspNtXxZrz3PEKku(u"ࠧ࠲࠲ࠪ࿣"):
		import x3xyuCUV0G
		x3xyuCUV0G.xfvRgHOZDr0ESTo2hnWMdlLGQVwkCX(wPnfgxKZdAv6T10(u"ࠨࡡࡊࡓࡔࡍࡌࡆࠩ࿤"))
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩ࠴࠸ࠬ࿥"): GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3,iDhLkZS6XBagNCQfs9tq2(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡘࡊࡓࡐࠨ࿦"))
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==gCkRKGhwcx26v(u"ࠫ࠶࠻ࠧ࿧"): GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3,zpx2fPNKk6Ms38eD1vcO(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪ࿨"))
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==HCiWF4jV1Q8(u"࠭࠱࠷ࠩ࿩"): GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3,TVnqDYzWoM2UfHp0dchJ(u"ࠧࡎࡇࡑ࡙ࡤࡊࡅࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭࿪"))
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==VOALf8iYEnMdK0g(u"ࠨ࠳࠺ࠫ࿫"): GLXqHD847n2jOVZaNEz9mFUIR31x(BBX9RAuxnyGZ4WIF2TrhYeom3,sTGtHVyhQ9cJU37zxo2O(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ࿬"))
	elif QdZVWe64OSKPfuXnz81m2qoHAJID==HCiWF4jV1Q8(u"ࠪ࠵࠽࠭࿭"):
		emIQYsN6huF = MMAUZiw4CoJ8.getSetting(fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨ࿮"))
		MMAUZiw4CoJ8.setSetting(czvu7VQCZodkMf(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ࿯"),VOALf8iYEnMdK0g(u"࠭࠭ࠨ࿰")+emIQYsN6huF)
	if QdZVWe64OSKPfuXnz81m2qoHAJID in [Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧ࠺ࠩ࿱"),zpx2fPNKk6Ms38eD1vcO(u"ࠨ࠳࠷ࠫ࿲"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩ࠴࠹ࠬ࿳"),czvu7VQCZodkMf(u"ࠪ࠵࠻࠭࿴"),ASkvf27etUK0(u"ࠫ࠶࠽ࠧ࿵")]: LbTfk6oJPiSGpVMU(BBX9RAuxnyGZ4WIF2TrhYeom3)
	return
def z1nDE0xaqpj9gSfKmwyH(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM,hhUXrunoxlSpv5mif64jWe2E3DA,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ,BMyb581fzrTX):
	if ptIsx9oHqB0dXK: EsQLYc249F0()
	if QdZVWe64OSKPfuXnz81m2qoHAJID: DMWBoHbLsFx9P6h(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM,hhUXrunoxlSpv5mif64jWe2E3DA,KgLR54vJkSH30D7UOTrFoPq,z4drqDgH1Cy7uwtTl6MVJ)
	w14FX6gYVdAZMtU(hhUXrunoxlSpv5mif64jWe2E3DA)
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc = BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n
	L1Lq3GluKv5FAitpDQV9We2fy74xO = QTNiaIpbyx9(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM,hhUXrunoxlSpv5mif64jWe2E3DA,BMyb581fzrTX,Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc)
	odLO18Mr9qjbEeY2iTFBctxPNH,UmEZCgu87JB,rrjsfD95phKG0VLRqN,WbC0S7lwP6ODR3cJKBQ,wgdZrhaPvi,wjKMktnSaA1C,B8BlgJiNM0Lvh,M0bEAcxwO5jF3htyBav9uHDg86zGq = L1Lq3GluKv5FAitpDQV9We2fy74xO
	if odLO18Mr9qjbEeY2iTFBctxPNH: return
	if UmEZCgu87JB==DQIrVcKuY6bJv(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬ࿶"): zGBSOdsWh8uLHbfw9qmxlioR7tDpy(RycFd7wZBiNhJjOPIGKp)
	InkX1ZEcl3yBf(TVnqDYzWoM2UfHp0dchJ(u"࠭ࡳࡵࡣࡵࡸࠬ࿷"))
	if MMAUZiw4CoJ8.getSetting(VOALf8iYEnMdK0g(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭࿸")) not in [Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡃࡘࡘࡔ࠭࿹"),DQIrVcKuY6bJv(u"ࠩࡖࡘࡔࡖࠧ࿺"),fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ࿻")]:
		MMAUZiw4CoJ8.setSetting(l7kBpMw5Qn(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ࿼"),TVnqDYzWoM2UfHp0dchJ(u"ࠬࡇࡕࡕࡑࠪ࿽"))
	if not MMAUZiw4CoJ8.getSetting(Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭࿾")): MMAUZiw4CoJ8.setSetting(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧ࿿"),qFsuKN7ngp.DNS_SERVERS[wvkDqmNZlJU52isXo])
	lfZmugQCFKLGT05AH29IsMiho = GkAg0ZqR2cnPW9wvUtfj(kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM)
	if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪက") in sLjle5myuEXSiFHJ: eGPxskK6XRr = BBX9RAuxnyGZ4WIF2TrhYeom3
	if kpiJl1MHXD5==VOALf8iYEnMdK0g(u"ࠩࡩࡳࡱࡪࡥࡳࠩခ"):
		if WbC0S7lwP6ODR3cJKBQ!=xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪ࠲࠳࠭ဂ") and wgdZrhaPvi: u0utoq8TOyQU()
		if BrOCluwtd1veo0a7EMbqVFXZgjQRL2>-nyUIsfd53EGot9vbj0XDeq:
			ccJi3jZ8VGsQ7KxhpBHRFvd = [wvkDqmNZlJU52isXo,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠳࠸ᖇ"),Izy1PvclrYx4eSVWn0L5phZbq(u"࠴࠻ᖈ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠵࠾ᖉ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠳࠸ᖆ"),HCiWF4jV1Q8(u"࠳࠵ᖌ"),DQIrVcKuY6bJv(u"࠺࠶ᖊ"),fp6KV7DlS8QYniUczHdmZChL(u"࠻࠳ᖋ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠲࠳࠳ᖍ")]
			if (xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,TVnqDYzWoM2UfHp0dchJ(u"ࠫ࡮ࡴࡴࠨဃ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨင"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫစ")) or hhUXrunoxlSpv5mif64jWe2E3DA not in ccJi3jZ8VGsQ7KxhpBHRFvd) and not qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW:
				from hfr1DHCban import Na01egzcrOu
				rMOgEikz6Tu7pGZj23J,KNbUscV38oyL1qrBfk9Zav = bfJxkXF5Gm8746sOTuN(Na01egzcrOu)
				odLO18Mr9qjbEeY2iTFBctxPNH = Ck2EhrtHy6LFW0f(rrjsfD95phKG0VLRqN,rMOgEikz6Tu7pGZj23J,Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc)
				if rMOgEikz6Tu7pGZj23J and wjKMktnSaA1C:
					if KNbUscV38oyL1qrBfk9Zav: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,ALwOspNtXxZrz3PEKku(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ဆ")+B8BlgJiNM0Lvh+ALwOspNtXxZrz3PEKku(u"ࠨࡡࠪဇ")+M0bEAcxwO5jF3htyBav9uHDg86zGq,rrjsfD95phKG0VLRqN,rMOgEikz6Tu7pGZj23J,QfG1xIZ4hpq3ezPXt7VbvglUcB)
					else: pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨဈ")+B8BlgJiNM0Lvh+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡣࠬဉ")+M0bEAcxwO5jF3htyBav9uHDg86zGq,rrjsfD95phKG0VLRqN)
			else:
				mKerP0GFQHJbM1hzR5ntxUVpdqTk.addDirectoryItem(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧည")+WYGV2HQo6sfnqSDZEcK9Cu4TP+iDhLkZS6XBagNCQfs9tq2(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬဋ"),G5OVsSktWRJQu8h4T.ListItem(TVnqDYzWoM2UfHp0dchJ(u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬဌ")))
				mKerP0GFQHJbM1hzR5ntxUVpdqTk.addDirectoryItem(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,ALwOspNtXxZrz3PEKku(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪဍ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+zpx2fPNKk6Ms38eD1vcO(u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨဎ"),G5OVsSktWRJQu8h4T.ListItem(ALwOspNtXxZrz3PEKku(u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨဏ")))
			mKerP0GFQHJbM1hzR5ntxUVpdqTk.endOfDirectory(BrOCluwtd1veo0a7EMbqVFXZgjQRL2,Vsn3f1CA8FIu0krNclSDWP5v9YQaE,eGPxskK6XRr,nt3kyWOAE5aKMXc)
	return
def zGBSOdsWh8uLHbfw9qmxlioR7tDpy(xJpVbMQkKgdeC):
	if tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬတ") in str(qFsuKN7ngp.SEND_THESE_EVENTS): return
	FFYmVXbuhTQLs3Gc = mrhSYXH2P8bO3eJAa9n if xJpVbMQkKgdeC else BBX9RAuxnyGZ4WIF2TrhYeom3
	if not FFYmVXbuhTQLs3Gc:
		q7D3PX40wNga = HZAmYXguczSBkOnM1jpdaEPqW7KfI(MMAUZiw4CoJ8.getSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬထ")))
		q7D3PX40wNga = wvkDqmNZlJU52isXo if not q7D3PX40wNga else int(q7D3PX40wNga)
		if not q7D3PX40wNga or not wvkDqmNZlJU52isXo<=H3a6hvAgeNctTiXF8d1uELfPr4y-q7D3PX40wNga<=xJpVbMQkKgdeC: FFYmVXbuhTQLs3Gc = BBX9RAuxnyGZ4WIF2TrhYeom3
	if not FFYmVXbuhTQLs3Gc:
		ssYSL0Ez5KBOCrc89uyWP = MMAUZiw4CoJ8.getSetting(zpx2fPNKk6Ms38eD1vcO(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪဒ"))
		if ssYSL0Ez5KBOCrc89uyWP in [SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬဓ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭န")]: FFYmVXbuhTQLs3Gc = BBX9RAuxnyGZ4WIF2TrhYeom3
	if not FFYmVXbuhTQLs3Gc:
		Rdhs5DYPqZNLn0ce9S = MMAUZiw4CoJ8.getSetting(bcNqYtfET5l92dLGjyZSPe(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫပ"))
		FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(E8Eo9FKSM5bhgRYlCWZHqPmt)
		ldt43SOpIjLor5XHv = DDs457eAxbRkrgKPHLw(E8Eo9FKSM5bhgRYlCWZHqPmt,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡪࡦࠣ࠿ࠬဖ"))
		ldt43SOpIjLor5XHv = ldt43SOpIjLor5XHv[tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲ᖎ")][tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠲ᖎ")]
		FFkBWYseogf6EUmRPMy5A.close()
		epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(bcNqYtfET5l92dLGjyZSPe(u"࠸ᖏ")*Rdhs5DYPqZNLn0ce9S.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
		epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(Izy1PvclrYx4eSVWn0L5phZbq(u"࠵࠹ᖐ")*epc09LarU7XkVgqZjMnRhydH.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
		epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(l7kBpMw5Qn(u"࠶࠿ᖑ")*epc09LarU7XkVgqZjMnRhydH.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
		epc09LarU7XkVgqZjMnRhydH = str(int(epc09LarU7XkVgqZjMnRhydH[AGlW9LqKN3Dvo(u"࠳ᖓ"):Izy1PvclrYx4eSVWn0L5phZbq(u"࠲࠴ᖔ")],xxRyYsrSCzjifvH4cIqgldeOo(u"࠳࠹ᖕ")))[:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠿ᖒ")]
		if epc09LarU7XkVgqZjMnRhydH!=ldt43SOpIjLor5XHv: FFYmVXbuhTQLs3Gc = BBX9RAuxnyGZ4WIF2TrhYeom3
	if FFYmVXbuhTQLs3Gc: axEdyXqh0wbVo3s5TS2WBmAM(mrhSYXH2P8bO3eJAa9n)
	return
def YYsnUMzptN0FJw19ruihSI6qf(bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz,qh4B9VQZCbXr0DRknFmi7J6,showDialogs):
	GJ4kbYnxcHa6NIOuA7X20S = qh4B9VQZCbXr0DRknFmi7J6.split(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࠱ࠬဗ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo] if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࠲࠭ဘ") in qh4B9VQZCbXr0DRknFmi7J6 else qh4B9VQZCbXr0DRknFmi7J6
	if not showDialogs or qh4B9VQZCbXr0DRknFmi7J6 in m7x2zfI5LH39BkU: return mrhSYXH2P8bO3eJAa9n
	rr1vBYypiKkhH7UcL4qfJRNnXm5Q = MMAUZiw4CoJ8.getSetting(iDhLkZS6XBagNCQfs9tq2(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭မ"))
	MMAUZiw4CoJ8.setSetting(xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧယ"),SebHIf2jL1TBgrMKJu)
	rQJyipuFO7U9qXVEH6hd = bY3gNleaHWrMKDw in [Izy1PvclrYx4eSVWn0L5phZbq(u"࠽ᖙ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠵࠶࠶࠰࠲ᖗ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠴࠵࠵࠶࠲ᖖ"),czvu7VQCZodkMf(u"࠶࠶࠰࠶࠶ᖘ")]
	if qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡀࡷࡶࡩࡷࡃࠧရ") in JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz.split(AGlW9LqKN3Dvo(u"ࠨࡁࡸࡷࡪࡸ࠽ࠨလ"),fp6KV7DlS8QYniUczHdmZChL(u"࠱ᖚ"))[qeYIw0BNTL9bGJnosacQ1DtVR(u"࠱ᖛ")]+HCiWF4jV1Q8(u"ࠩࠬࠫဝ")
	hhYqWfc64ZkNp = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz.lower()
	P1L6Ur5d8ymIFlGo0zxN9vbe = bY3gNleaHWrMKDw in [wvkDqmNZlJU52isXo,bcNqYtfET5l92dLGjyZSPe(u"࠵࠵࠺ᖞ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠳࠳࠴࠻࠷ᖜ"),HCiWF4jV1Q8(u"࠴࠵࠶ᖝ")]
	N93qAeLZIk1waDKryOPjEphHYC = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫသ") in hhYqWfc64ZkNp
	qljvkVx6LXTGyMhKN = gCkRKGhwcx26v(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫဟ") in hhYqWfc64ZkNp
	TRQSEcr9gvqOdKzAo0HFDMw1Ip6iy = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬဠ") in hhYqWfc64ZkNp
	DWsY8kCBwFQgN3H1PlSoIJMd = TVnqDYzWoM2UfHp0dchJ(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨအ") in hhYqWfc64ZkNp
	aNerkt0RKCUiPLup3EVf = ASkvf27etUK0(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡲ࡯ࡳࡴ࡫ࡱ࡫ࠥࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠢࡦ࡬ࡪࡩ࡫ࠨဢ") in hhYqWfc64ZkNp
	O7ZljCgQoiy2waTBmS8cGKR6HXV = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡿ࡯ࡶࡴࠣࡲࡪࡺࡷࡰࡴ࡮ࠤࡩ࡫ࡶࡪࡥࡨࡷࠬဣ") in hhYqWfc64ZkNp
	MNueRG4Cz8D2TQFBhSXxianlj1AtO = MMAUZiw4CoJ8.getSetting(HADrRCz9QgU4xudPJIqYb70(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧဤ"))
	r2wm0BOAUYz7faosk5L1 = MMAUZiw4CoJ8.getSetting(czvu7VQCZodkMf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ဥ"))
	YOEjaSucqDI3e5UBimhd7vAC = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭ဦ")
	rL3U4Pljso = C3w6qluao7EzUxJgMGBtV(u"ࠬࡋࡲࡳࡱࡵࠤࠬဧ")+str(bY3gNleaHWrMKDw)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭࠺ࠡࠩဨ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz
	rL3U4Pljso = kLEi7mYT5wBM4DHsgWy8(rL3U4Pljso)
	if any([P1L6Ur5d8ymIFlGo0zxN9vbe,N93qAeLZIk1waDKryOPjEphHYC,qljvkVx6LXTGyMhKN,TRQSEcr9gvqOdKzAo0HFDMw1Ip6iy,DWsY8kCBwFQgN3H1PlSoIJMd,aNerkt0RKCUiPLup3EVf,O7ZljCgQoiy2waTBmS8cGKR6HXV]): YOEjaSucqDI3e5UBimhd7vAC += v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧဩ")
	if rQJyipuFO7U9qXVEH6hd: YOEjaSucqDI3e5UBimhd7vAC += gCkRKGhwcx26v(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨဪ")
	rL3U4Pljso = u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+rL3U4Pljso+XOVRfitWJP1zL3p2CMYF
	if MNueRG4Cz8D2TQFBhSXxianlj1AtO==HADrRCz9QgU4xudPJIqYb70(u"ࠩࡄࡗࡐ࠭ါ") or r2wm0BOAUYz7faosk5L1==C3w6qluao7EzUxJgMGBtV(u"ࠪࡅࡘࡑࠧာ"):
		YOEjaSucqDI3e5UBimhd7vAC += u43PVWjh7t9YwI+QNR6tCevIGEZKX3rAVsP+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦ࠭ိ")+XOVRfitWJP1zL3p2CMYF
	qqob7QneZkf2M9Tc08BJY1HW = mrhSYXH2P8bO3eJAa9n
	if MNueRG4Cz8D2TQFBhSXxianlj1AtO==ALwOspNtXxZrz3PEKku(u"ࠬࡇࡓࡌࠩီ") or r2wm0BOAUYz7faosk5L1==DQIrVcKuY6bJv(u"࠭ࡁࡔࡍࠪု"):
		x5BZ9SJfFAWV743cgCvoUamse = omIUAxNupsBHY0SGnJXzijltOyV(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡤࡧࡱࡸࡪࡸࠧူ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨะิ์ั࠭ေ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩศีุอไࠡๆ็้อืๅอࠩဲ"),bcNqYtfET5l92dLGjyZSPe(u"ࠪฮฺ๊๊ฮࠢสฺ่๊ใๅหࠪဳ"),GJ4kbYnxcHa6NIOuA7X20S+cc07eWdgrbB4xJfVCANFSk+dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S),YOEjaSucqDI3e5UBimhd7vAC+u43PVWjh7t9YwI+rL3U4Pljso)
		if x5BZ9SJfFAWV743cgCvoUamse==nyUIsfd53EGot9vbj0XDeq:
			from WW03V9yQKJ import CQgMI2jYDy4F
			CQgMI2jYDy4F()
		elif x5BZ9SJfFAWV743cgCvoUamse==JhTts2R43AxkM8bYanKVy: qqob7QneZkf2M9Tc08BJY1HW = BBX9RAuxnyGZ4WIF2TrhYeom3
	else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,GJ4kbYnxcHa6NIOuA7X20S+cc07eWdgrbB4xJfVCANFSk+dPlNiRwGQK4bz(GJ4kbYnxcHa6NIOuA7X20S),YOEjaSucqDI3e5UBimhd7vAC,rL3U4Pljso)
	MMAUZiw4CoJ8.setSetting(TVnqDYzWoM2UfHp0dchJ(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬဴ"),rr1vBYypiKkhH7UcL4qfJRNnXm5Q)
	return qqob7QneZkf2M9Tc08BJY1HW
def ozd2DGF8PR73cwJj0SOUmZNuXH(Y6T3IJNAg8Vp2cZo1LP9dORW=mrhSYXH2P8bO3eJAa9n,Vp4DPrTqcU=[]):
	zhluPSIbVHwvD3QOA1x = [dUj4HNoGp91APu6itnl3BCc,NnA1JBy7DVvFqcm]+Vp4DPrTqcU
	for YOaRApygTvD38oLSGqPsBzMCW6w in E2xjtKaMXdC3NDoTm7f5Wkev.listdir(LdX87mwIzyBM):
		if Y6T3IJNAg8Vp2cZo1LP9dORW and (YOaRApygTvD38oLSGqPsBzMCW6w.startswith(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࡯ࡰࡵࡸࠪဵ")) or YOaRApygTvD38oLSGqPsBzMCW6w.startswith(uqLUBHepfM3l6AyIzTJh80a(u"࠭࡭࠴ࡷࠪံ"))): continue
		if YOaRApygTvD38oLSGqPsBzMCW6w.startswith(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡧ࡫࡯ࡩࡤ့࠭")): continue
		eurCtopiD0sS = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,YOaRApygTvD38oLSGqPsBzMCW6w)
		if eurCtopiD0sS in zhluPSIbVHwvD3QOA1x: continue
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(eurCtopiD0sS)
		except: pass
	if Q8ueUH69goFIxnE2V1 not in zhluPSIbVHwvD3QOA1x: VS8fuikmreJGgW6cdLOq2yz(Q8ueUH69goFIxnE2V1,BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
	uv8V4fE7j9pmgFr3wnDL.sleep(iDhLkZS6XBagNCQfs9tq2(u"࠶ᖟ"))
	return
def QQEYakfoF6gSqvsb7(Gf2yBp9ek4QtDxmKbwFU3JuzWAO,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J=BBX9RAuxnyGZ4WIF2TrhYeom3,Cft4OB0gVpiLcwz8Won=BBX9RAuxnyGZ4WIF2TrhYeom3):
	pfhH2objgVkI7eycn = pfhH2objgVkI7eycn+VOALf8iYEnMdK0g(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨး")+Gf2yBp9ek4QtDxmKbwFU3JuzWAO
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J,Cft4OB0gVpiLcwz8Won)
	if pfhH2objgVkI7eycn in Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content: Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded = mrhSYXH2P8bO3eJAa9n
	if not Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		LbTfk6oJPiSGpVMU()
	return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
def ct20qQBgZHKfAWh37LY61sX9xFCn(pfhH2objgVkI7eycn):
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡊࡉ္࡙࠭"),pfhH2objgVkI7eycn,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3,SebHIf2jL1TBgrMKJu,TVnqDYzWoM2UfHp0dchJ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷ်ࠫ"),BBX9RAuxnyGZ4WIF2TrhYeom3,mrhSYXH2P8bO3eJAa9n)
	gGpkYMUVJHEsf3doh0l6IDeq8cFXj = []
	if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
		L8fysFp941j = X2XorVqHjLkWeCchY4u9fSz.findall(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧျ"),YD0R1z8ldmipE)
		if L8fysFp941j: YD0R1z8ldmipE = u43PVWjh7t9YwI.join(L8fysFp941j)
		Dwr8HRjSeX = YD0R1z8ldmipE.replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu).strip(u43PVWjh7t9YwI).split(u43PVWjh7t9YwI)
		gGpkYMUVJHEsf3doh0l6IDeq8cFXj = []
		for Gf2yBp9ek4QtDxmKbwFU3JuzWAO in Dwr8HRjSeX:
			if Gf2yBp9ek4QtDxmKbwFU3JuzWAO.count(VOALf8iYEnMdK0g(u"ࠬ࠴ࠧြ"))==fuCbjVag7vU908J2Yqx5Th: gGpkYMUVJHEsf3doh0l6IDeq8cFXj.append(Gf2yBp9ek4QtDxmKbwFU3JuzWAO)
	return gGpkYMUVJHEsf3doh0l6IDeq8cFXj
def zTxpAmytobeOiNM4l(*aargs):
	iq5t9BxpRrC4ELTd3 = ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵ࡶ࠳࠱ࡂࡶࡪࡷࡵࡦࡵࡷࡁࡩ࡯ࡳࡱ࡮ࡤࡽࡵࡸ࡯ࡹ࡫ࡨࡷࠫࡶࡲࡰࡺࡼࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡴࡪ࡯ࡨࡳࡺࡺ࠽࠲࠲࠳࠴࠵ࠬࡳࡴ࡮ࡀࡽࡪࡹࠦ࡭࡫ࡰ࡭ࡹࡃ࠱࠱ࠨࡦࡳࡺࡴࡴࡳࡻࡀࡒࡑ࠲ࡂࡆ࠮ࡇࡉ࠱ࡌࡒ࠭ࡉࡅ࠰࡙ࡘࠧွ")
	NLDvChKXeMl1PE7x46tBj = czvu7VQCZodkMf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡰࡱࡶࡸࡪࡸ࡫ࡪࡦ࠲ࡳࡵ࡫࡮ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡱࡦ࡯࡮࠰ࡊࡗࡘࡕ࡙࠮ࡵࡺࡷࠫှ")
	kkdmeiZIqJx = ct20qQBgZHKfAWh37LY61sX9xFCn(NLDvChKXeMl1PE7x46tBj)
	gGpkYMUVJHEsf3doh0l6IDeq8cFXj = ct20qQBgZHKfAWh37LY61sX9xFCn(iq5t9BxpRrC4ELTd3)
	jdiDs2haWJQ = kkdmeiZIqJx+gGpkYMUVJHEsf3doh0l6IDeq8cFXj
	z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+fp6KV7DlS8QYniUczHdmZChL(u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧဿ")+str(len(kkdmeiZIqJx))+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࠮ࠫ၀")+str(len(gGpkYMUVJHEsf3doh0l6IDeq8cFXj))+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࠤࡢ࠭၁"))
	Gf2yBp9ek4QtDxmKbwFU3JuzWAO = MMAUZiw4CoJ8.getSetting(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ၂"))
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = HvawcTdL3fq785XunkRDGE2FP()
	MMAUZiw4CoJ8.setSetting(l7kBpMw5Qn(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ၃"),SebHIf2jL1TBgrMKJu)
	if Gf2yBp9ek4QtDxmKbwFU3JuzWAO or jdiDs2haWJQ:
		fwDM2gXmtlpNsi4aPv,EXNR98wTJuhj = wvkDqmNZlJU52isXo,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠷࠰ᖠ")
		cZwUNRq4YpLD5JA9VkWSGmz7 = len(jdiDs2haWJQ)
		aaT7HkwF6eI3b5dXM8Cg9J = EXNR98wTJuhj
		if cZwUNRq4YpLD5JA9VkWSGmz7>aaT7HkwF6eI3b5dXM8Cg9J: lyZ219iBAT6Lh = aaT7HkwF6eI3b5dXM8Cg9J
		else: lyZ219iBAT6Lh = cZwUNRq4YpLD5JA9VkWSGmz7
		scxIoAphPbq5iJlQZCHz = JO7n9zxwdgIStrTjR.sample(jdiDs2haWJQ,lyZ219iBAT6Lh)
		if Gf2yBp9ek4QtDxmKbwFU3JuzWAO: scxIoAphPbq5iJlQZCHz = [Gf2yBp9ek4QtDxmKbwFU3JuzWAO]+scxIoAphPbq5iJlQZCHz
		X8OoDphecAiusWqS2YNd6zIT5xvG = BU0NzOhc2Cv7V9WMLEQRq(mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
		GhdtAy1o3Ru8z5WvkUFQ6ES = uv8V4fE7j9pmgFr3wnDL.time()
		while uv8V4fE7j9pmgFr3wnDL.time()-GhdtAy1o3Ru8z5WvkUFQ6ES<=EXNR98wTJuhj and not X8OoDphecAiusWqS2YNd6zIT5xvG.finishedLIST:
			if fwDM2gXmtlpNsi4aPv<lyZ219iBAT6Lh:
				Gf2yBp9ek4QtDxmKbwFU3JuzWAO = scxIoAphPbq5iJlQZCHz[fwDM2gXmtlpNsi4aPv]
				X8OoDphecAiusWqS2YNd6zIT5xvG.Y3WXTHPjwo1Z(fwDM2gXmtlpNsi4aPv,QQEYakfoF6gSqvsb7,Gf2yBp9ek4QtDxmKbwFU3JuzWAO,*aargs)
			uv8V4fE7j9pmgFr3wnDL.sleep(vMhFypGLHZJbdX4O7oc3W8x(u"࠰࠯࠹࠸ᖡ"))
			fwDM2gXmtlpNsi4aPv += nyUIsfd53EGot9vbj0XDeq
			z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+DQIrVcKuY6bJv(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ၄")+Gf2yBp9ek4QtDxmKbwFU3JuzWAO+C3w6qluao7EzUxJgMGBtV(u"ࠧࠡ࡟ࠪ၅"))
		finishedLIST = X8OoDphecAiusWqS2YNd6zIT5xvG.finishedLIST
		if finishedLIST:
			resultsDICT = X8OoDphecAiusWqS2YNd6zIT5xvG.resultsDICT
			uBTX9opfdte35LWQ1VgDn6lIb7U = finishedLIST[wvkDqmNZlJU52isXo]
			Vq3XpLGKo4zlSR59wBrhjAbcamJDie = resultsDICT[uBTX9opfdte35LWQ1VgDn6lIb7U]
			Gf2yBp9ek4QtDxmKbwFU3JuzWAO = scxIoAphPbq5iJlQZCHz[int(uBTX9opfdte35LWQ1VgDn6lIb7U)]
			MMAUZiw4CoJ8.setSetting(bcNqYtfET5l92dLGjyZSPe(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ၆"),Gf2yBp9ek4QtDxmKbwFU3JuzWAO)
			if uBTX9opfdte35LWQ1VgDn6lIb7U!=wvkDqmNZlJU52isXo: z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ၇")+Gf2yBp9ek4QtDxmKbwFU3JuzWAO+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࠤࡢ࠭၈"))
			else: z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭၉")+Gf2yBp9ek4QtDxmKbwFU3JuzWAO+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࠦ࡝ࠨ၊"))
	return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
def IbCEgvyprwhM08u3RJLUl6q9O1S(ofSjvyFl1zIx,tbjSgf4uz78qdrAvkxLiRhMcwQ,sYFTiQRchNEuzxqrSmb=BBX9RAuxnyGZ4WIF2TrhYeom3):
	NApMnG3QlV9Y5s2tRzhEqfWv8I1 = ofSjvyFl1zIx.create_connection
	def WrMDfS3KcZxPwg(ka5mXw42fvCtK1Ozh3IYHQD9lqyJ,*aargs,**kkwargs):
		N71BmUdWCthRJbrzXcg08ilSHs5,d5XtyASDoe61 = ka5mXw42fvCtK1Ozh3IYHQD9lqyJ
		ip = VbuRTd8mqrlspv2OCktGMSDya1Y(N71BmUdWCthRJbrzXcg08ilSHs5,tbjSgf4uz78qdrAvkxLiRhMcwQ)
		if ip: N71BmUdWCthRJbrzXcg08ilSHs5 = ip[wvkDqmNZlJU52isXo]
		elif sYFTiQRchNEuzxqrSmb:
			if tbjSgf4uz78qdrAvkxLiRhMcwQ in qFsuKN7ngp.DNS_SERVERS: qFsuKN7ngp.DNS_SERVERS.remove(tbjSgf4uz78qdrAvkxLiRhMcwQ)
			if qFsuKN7ngp.DNS_SERVERS:
				HDNhcrxjbyQwS5m1 = qFsuKN7ngp.DNS_SERVERS[wvkDqmNZlJU52isXo]
				ip = VbuRTd8mqrlspv2OCktGMSDya1Y(N71BmUdWCthRJbrzXcg08ilSHs5,HDNhcrxjbyQwS5m1)
				if ip: N71BmUdWCthRJbrzXcg08ilSHs5 = ip[wvkDqmNZlJU52isXo]
		if ip: qFsuKN7ngp.dns_succeeded_urls.append(N71BmUdWCthRJbrzXcg08ilSHs5)
		ka5mXw42fvCtK1Ozh3IYHQD9lqyJ = (N71BmUdWCthRJbrzXcg08ilSHs5,d5XtyASDoe61)
		return NApMnG3QlV9Y5s2tRzhEqfWv8I1(ka5mXw42fvCtK1Ozh3IYHQD9lqyJ,*aargs,**kkwargs)
	ofSjvyFl1zIx.create_connection = WrMDfS3KcZxPwg
	return NApMnG3QlV9Y5s2tRzhEqfWv8I1
def ZJiNstIC5uTRhzFBbLxX1aQ4d(pfhH2objgVkI7eycn):
	Dp0xkKyA6jWq,iJTtZSByVeAIKh = pfhH2objgVkI7eycn.split(HCiWF4jV1Q8(u"࠭࠯ࠨ။"))[JhTts2R43AxkM8bYanKVy],Gykx0wL3XrlWaujsqKP9n2Q(u"࠹࠲ᖢ")
	if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧ࠻ࠩ၌") in Dp0xkKyA6jWq: Dp0xkKyA6jWq,iJTtZSByVeAIKh = Dp0xkKyA6jWq.split(HADrRCz9QgU4xudPJIqYb70(u"ࠨ࠼ࠪ၍"))
	k30WHmwxg1PKBbeZIEq5y = sTGtHVyhQ9cJU37zxo2O(u"ࠩ࠲ࠫ၎")+AGlW9LqKN3Dvo(u"ࠪ࠳ࠬ၏").join(pfhH2objgVkI7eycn.split(DQIrVcKuY6bJv(u"ࠫ࠴࠭ၐ"))[v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠵ᖣ"):])
	pbmcw9i1kfuNIQzJ7aGd3l0 = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡍࡅࡕࠢࠪၑ")+k30WHmwxg1PKBbeZIEq5y+Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭ၒ")
	pbmcw9i1kfuNIQzJ7aGd3l0 += vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧၓ")+Dp0xkKyA6jWq+HADrRCz9QgU4xudPJIqYb70(u"ࠨ࡞ࡵࡠࡳ࠭ၔ")
	pbmcw9i1kfuNIQzJ7aGd3l0 += iDhLkZS6XBagNCQfs9tq2(u"ࠩ࡟ࡶࡡࡴࠧၕ")
	from socket import socket as bvtc8KLZV4uRnJh0Q1I7,AF_INET as LknU0Q5lDacKWVBr6vg8PmHJj9,SOCK_STREAM as JNRHvAFDg4KsEf
	try:
		w8wxfpkyDK2R7nh = bvtc8KLZV4uRnJh0Q1I7(LknU0Q5lDacKWVBr6vg8PmHJj9,JNRHvAFDg4KsEf)
		w8wxfpkyDK2R7nh.connect((Dp0xkKyA6jWq,iJTtZSByVeAIKh))
		w8wxfpkyDK2R7nh.send(pbmcw9i1kfuNIQzJ7aGd3l0.encode(Tv08xsf9HOqunIVUPdK1))
		AnPspETof0uxgR1jQ9vrqZy = w8wxfpkyDK2R7nh.recv(C3w6qluao7EzUxJgMGBtV(u"࠸࠵࠿࠶ᖥ")*C3w6qluao7EzUxJgMGBtV(u"࠴࠴࠷࠺ᖤ"))
		YD0R1z8ldmipE = repr(AnPspETof0uxgR1jQ9vrqZy)
	except: YD0R1z8ldmipE = SebHIf2jL1TBgrMKJu
	return YD0R1z8ldmipE
def EDmwsQf1Px9k8h04oAHuObdnyrTGU(IIHsbDu7K1U38AZaodhqk0QTX,kpiJl1MHXD5):
	if Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪ࠲ࠬၖ") not in IIHsbDu7K1U38AZaodhqk0QTX: return IIHsbDu7K1U38AZaodhqk0QTX
	IIHsbDu7K1U38AZaodhqk0QTX = IIHsbDu7K1U38AZaodhqk0QTX+sTGtHVyhQ9cJU37zxo2O(u"ࠫ࠴࠭ၗ")
	SSKdE8QAZVFYj4t7s6fJomv,QdoClVu4cqOIiWYmhrgzEjDAM = IIHsbDu7K1U38AZaodhqk0QTX.split(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬ࠴ࠧၘ"),Ns6AJKH7DGpr19Wl5C3nF(u"࠶ᖦ"))
	gtTL8zIBmA7fNpkYC,XpvTnrwmBaOtf3geD9UQoK76lMhi = QdoClVu4cqOIiWYmhrgzEjDAM.split(ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭࠯ࠨၙ"),ASkvf27etUK0(u"࠷ᖧ"))
	CCmUps0BYLihTRoxWtnOdgfuF = SSKdE8QAZVFYj4t7s6fJomv+vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠯ࠩၚ")+gtTL8zIBmA7fNpkYC
	if kpiJl1MHXD5 in [l7kBpMw5Qn(u"ࠨࡪࡲࡷࡹ࠭ၛ"),DQIrVcKuY6bJv(u"ࠩࡱࡥࡲ࡫ࠧၜ")] and vMhFypGLHZJbdX4O7oc3W8x(u"ࠪ࠳ࠬၝ") in CCmUps0BYLihTRoxWtnOdgfuF: CCmUps0BYLihTRoxWtnOdgfuF = CCmUps0BYLihTRoxWtnOdgfuF.rsplit(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫ࠴࠭ၞ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠱ᖨ"))[nyUIsfd53EGot9vbj0XDeq]
	if kpiJl1MHXD5==sTGtHVyhQ9cJU37zxo2O(u"ࠬࡴࡡ࡮ࡧࠪၟ") and Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭࠮ࠨၠ") in CCmUps0BYLihTRoxWtnOdgfuF:
		k3kDnIiqJ15lLhzQUyBba6xfvHVp7 = CCmUps0BYLihTRoxWtnOdgfuF.split(iDhLkZS6XBagNCQfs9tq2(u"ࠧ࠯ࠩၡ"))
		zmWBb6RMtEhNw7j1HrdI9pTyVnXve = len(k3kDnIiqJ15lLhzQUyBba6xfvHVp7)
		if v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ၢ") in CCmUps0BYLihTRoxWtnOdgfuF: k3kDnIiqJ15lLhzQUyBba6xfvHVp7 = wPnfgxKZdAv6T10(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧၣ")
		elif zmWBb6RMtEhNw7j1HrdI9pTyVnXve<=JhTts2R43AxkM8bYanKVy: k3kDnIiqJ15lLhzQUyBba6xfvHVp7 = k3kDnIiqJ15lLhzQUyBba6xfvHVp7[wvkDqmNZlJU52isXo]
		elif zmWBb6RMtEhNw7j1HrdI9pTyVnXve>=fuCbjVag7vU908J2Yqx5Th: k3kDnIiqJ15lLhzQUyBba6xfvHVp7 = k3kDnIiqJ15lLhzQUyBba6xfvHVp7[nyUIsfd53EGot9vbj0XDeq]
		if len(k3kDnIiqJ15lLhzQUyBba6xfvHVp7)>nyUIsfd53EGot9vbj0XDeq: CCmUps0BYLihTRoxWtnOdgfuF = k3kDnIiqJ15lLhzQUyBba6xfvHVp7
	return CCmUps0BYLihTRoxWtnOdgfuF
def dHGcuCNYJWI53yrvAOT80(B1r5WYAudRUtVQKaIlenhNjFmwf):
	rtXUvuospZfOGzig7FJ18xE = repr(B1r5WYAudRUtVQKaIlenhNjFmwf.encode(Tv08xsf9HOqunIVUPdK1)).replace(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠥࠫࠧၤ"),SebHIf2jL1TBgrMKJu)
	return rtXUvuospZfOGzig7FJ18xE
def rrHKfkJjxnw5gCR4pcGUqb8BXSzdL(PYVl8aUmTHrbGO1wD0t):
	H3NuQfnMgv8bKikEa = SebHIf2jL1TBgrMKJu
	if psS8dmb912iRBgGc7qOPyCZ6: PYVl8aUmTHrbGO1wD0t = PYVl8aUmTHrbGO1wD0t.decode(Tv08xsf9HOqunIVUPdK1)
	from unicodedata import decomposition as dd08vKCnuDZjtkXNayMU
	for oiW2cCEdQ8uB6 in PYVl8aUmTHrbGO1wD0t:
		if   oiW2cCEdQ8uB6==Gykx0wL3XrlWaujsqKP9n2Q(u"ࡹࠬศࠧၥ"): p4pxZEYiyRw = HADrRCz9QgU4xudPJIqYb70(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭ၦ")
		elif oiW2cCEdQ8uB6==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࡻࠧฤࠩၧ"): p4pxZEYiyRw = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨၨ")
		elif oiW2cCEdQ8uB6==xxRyYsrSCzjifvH4cIqgldeOo(u"ࡶࠩวࠫၩ"): p4pxZEYiyRw = vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪၪ")
		elif oiW2cCEdQ8uB6==zpx2fPNKk6Ms38eD1vcO(u"ࡸࠫส࠭ၫ"): p4pxZEYiyRw = VOALf8iYEnMdK0g(u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬၬ")
		elif oiW2cCEdQ8uB6==l7kBpMw5Qn(u"ࡺ࠭ฦࠨၭ"): p4pxZEYiyRw = xxRyYsrSCzjifvH4cIqgldeOo(u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧၮ")
		else:
			OH5mTQvaRW2XUy1nS8IlV97ZAKNJo = dd08vKCnuDZjtkXNayMU(oiW2cCEdQ8uB6)
			if qE4nB3mKWHs in OH5mTQvaRW2XUy1nS8IlV97ZAKNJo: p4pxZEYiyRw = DQIrVcKuY6bJv(u"ࠧ࡝࡞ࡸࠫၯ")+OH5mTQvaRW2XUy1nS8IlV97ZAKNJo.split(qE4nB3mKWHs,nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
			else:
				p4pxZEYiyRw = ASkvf27etUK0(u"ࠨ࠲࠳࠴࠵࠭ၰ")+hex(ord(oiW2cCEdQ8uB6)).replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࠳ࡼࠬၱ"),SebHIf2jL1TBgrMKJu)
				p4pxZEYiyRw = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡠࡡࡻࠧၲ")+p4pxZEYiyRw[-K7cnfQMS6BPvI4LGmCsRp8bUlJ9:]
		H3NuQfnMgv8bKikEa += p4pxZEYiyRw
	H3NuQfnMgv8bKikEa = H3NuQfnMgv8bKikEa.replace(l7kBpMw5Qn(u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬၳ"),iDhLkZS6XBagNCQfs9tq2(u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭ၴ"))
	if psS8dmb912iRBgGc7qOPyCZ6: H3NuQfnMgv8bKikEa = H3NuQfnMgv8bKikEa.decode(bcNqYtfET5l92dLGjyZSPe(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧၵ")).encode(Tv08xsf9HOqunIVUPdK1)
	else: H3NuQfnMgv8bKikEa = H3NuQfnMgv8bKikEa.encode(Tv08xsf9HOqunIVUPdK1).decode(ALwOspNtXxZrz3PEKku(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨၶ"))
	return H3NuQfnMgv8bKikEa
def zWKdm3kV2ItwYrgH1BZyRON(header=j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨၷ"),h01hVuNmEIJ35vl=SebHIf2jL1TBgrMKJu,jjscKgB41MFJPDECumnXxpf=mrhSYXH2P8bO3eJAa9n,source=SebHIf2jL1TBgrMKJu):
	sLjle5myuEXSiFHJ = HeEDq925biGjVFmn8Y6wCgRO3(header,h01hVuNmEIJ35vl,type=G5OVsSktWRJQu8h4T.INPUT_ALPHANUM)
	sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ.strip(qE4nB3mKWHs).replace(saNjmrfQDGgltv,qE4nB3mKWHs).replace(cc07eWdgrbB4xJfVCANFSk,qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
	if not sLjle5myuEXSiFHJ and not jjscKgB41MFJPDECumnXxpf:
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ၸ")+sLjle5myuEXSiFHJ+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࠦࠬၹ"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,sTGtHVyhQ9cJU37zxo2O(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧၺ"))
		return SebHIf2jL1TBgrMKJu
	if sLjle5myuEXSiFHJ not in [SebHIf2jL1TBgrMKJu,qE4nB3mKWHs]:
		sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ.strip(qE4nB3mKWHs)
		sLjle5myuEXSiFHJ = rrHKfkJjxnw5gCR4pcGUqb8BXSzdL(sLjle5myuEXSiFHJ)
	if source!=C3w6qluao7EzUxJgMGBtV(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧၻ") and HC5h0TIwPOU76oVLcp(Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨၼ"),SebHIf2jL1TBgrMKJu,[sLjle5myuEXSiFHJ],mrhSYXH2P8bO3eJAa9n):
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪၽ")+sLjle5myuEXSiFHJ+iDhLkZS6XBagNCQfs9tq2(u"ࠨࠤࠪၾ"))
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫၿ"))
		return SebHIf2jL1TBgrMKJu
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,ALwOspNtXxZrz3PEKku(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ႀ")+sLjle5myuEXSiFHJ+uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠧ࠭ႁ"))
	return sLjle5myuEXSiFHJ
def YBCFjeH81s4Gxlgki(tfX4sO3hy2H1IbKG,qg7Nr1dCaD,REIkboX9NtlZCSU3A={}):
	pfhH2objgVkI7eycn,CCpl8OaFYN,tFTrYa8QIGpu13kRo,C1yvpquagDHdSQMsOY3LTf6n2heP = qg7Nr1dCaD,{},{},SebHIf2jL1TBgrMKJu
	if qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࢂࠧႂ") in qg7Nr1dCaD: pfhH2objgVkI7eycn,CCpl8OaFYN = lhC3Axj8TQSsRWeu0k(qg7Nr1dCaD,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡼࠨႃ"))
	ALE0lPrgks631qxC9Q = list(set(list(REIkboX9NtlZCSU3A.keys())+list(CCpl8OaFYN.keys())))
	for BXCThrgedxOyF2N in ALE0lPrgks631qxC9Q:
		if BXCThrgedxOyF2N in list(CCpl8OaFYN.keys()): tFTrYa8QIGpu13kRo[BXCThrgedxOyF2N] = CCpl8OaFYN[BXCThrgedxOyF2N]
		else: tFTrYa8QIGpu13kRo[BXCThrgedxOyF2N] = REIkboX9NtlZCSU3A[BXCThrgedxOyF2N]
	if HCiWF4jV1Q8(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫႄ") not in ALE0lPrgks631qxC9Q: tFTrYa8QIGpu13kRo[iDhLkZS6XBagNCQfs9tq2(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬႅ")] = b6rmBauMc3HqTev0t()
	if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪႆ") not in ALE0lPrgks631qxC9Q: tFTrYa8QIGpu13kRo[wPnfgxKZdAv6T10(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫႇ")] = EDmwsQf1Px9k8h04oAHuObdnyrTGU(pfhH2objgVkI7eycn,TVnqDYzWoM2UfHp0dchJ(u"ࠫࡺࡸ࡬ࠨႈ"))
	if AGlW9LqKN3Dvo(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧႉ") not in ALE0lPrgks631qxC9Q: tFTrYa8QIGpu13kRo[HADrRCz9QgU4xudPJIqYb70(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨႊ")] = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡦࡰ࠯ࡥࡷࡁࡱ࠾࠲࠱࠽ࠬႋ")
	for BXCThrgedxOyF2N in list(tFTrYa8QIGpu13kRo.keys()): C1yvpquagDHdSQMsOY3LTf6n2heP += xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࠨࠪႌ")+BXCThrgedxOyF2N+sTGtHVyhQ9cJU37zxo2O(u"ࠩࡀႍࠫ")+tFTrYa8QIGpu13kRo[BXCThrgedxOyF2N]
	if C1yvpquagDHdSQMsOY3LTf6n2heP: C1yvpquagDHdSQMsOY3LTf6n2heP = HADrRCz9QgU4xudPJIqYb70(u"ࠪࢀࠬႎ")+C1yvpquagDHdSQMsOY3LTf6n2heP[nyUIsfd53EGot9vbj0XDeq:]
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(B3vhTYqOtgUCAzPW,ALwOspNtXxZrz3PEKku(u"ࠫࡌࡋࡔࠨႏ"),pfhH2objgVkI7eycn,SebHIf2jL1TBgrMKJu,tFTrYa8QIGpu13kRo,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ႐"),mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
	if gCkRKGhwcx26v(u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ႑") not in YD0R1z8ldmipE: return [HCiWF4jV1Q8(u"ࠧ࠮࠳ࠪ႒")],[pfhH2objgVkI7eycn+C1yvpquagDHdSQMsOY3LTf6n2heP]
	if NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ႓") in YD0R1z8ldmipE: return [bcNqYtfET5l92dLGjyZSPe(u"ࠩ࠰࠵ࠬ႔")],[pfhH2objgVkI7eycn+C1yvpquagDHdSQMsOY3LTf6n2heP]
	if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ႕") in YD0R1z8ldmipE: return [uqLUBHepfM3l6AyIzTJh80a(u"ࠫ࠲࠷ࠧ႖")],[pfhH2objgVkI7eycn+C1yvpquagDHdSQMsOY3LTf6n2heP]
	HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os,qKFVnkoLMlE3j,GGWDKFVAj7pbm = [],[],[],[]
	P7SQWVY4x1vm9tnANdiB = X2XorVqHjLkWeCchY4u9fSz.findall(C3w6qluao7EzUxJgMGBtV(u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠲ࡏࡎࡇ࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭႗"),YD0R1z8ldmipE+u43PVWjh7t9YwI,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not P7SQWVY4x1vm9tnANdiB: return [Gykx0wL3XrlWaujsqKP9n2Q(u"࠭࠭࠲ࠩ႘")],[pfhH2objgVkI7eycn+C1yvpquagDHdSQMsOY3LTf6n2heP]
	for peItaQ6PDKEWvUBxAbYgrZ,IIHsbDu7K1U38AZaodhqk0QTX in P7SQWVY4x1vm9tnANdiB:
		WsoQkLHm1ayh,emIQYsN6huF,lcbjBn3FdZxC1059A4Kqvi2pugJOa = {},-HCiWF4jV1Q8(u"࠲ᖩ"),-HCiWF4jV1Q8(u"࠲ᖩ")
		UPkfbZE4NARs6h8zviJOYplQ = SebHIf2jL1TBgrMKJu
		B0iOSpPGmRjg8zQ4XHfnD7CecVxZqY = peItaQ6PDKEWvUBxAbYgrZ.split(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧ࠭ࠩ႙"))
		for Zth7i2v1xI6TKpcP in B0iOSpPGmRjg8zQ4XHfnD7CecVxZqY:
			if iDhLkZS6XBagNCQfs9tq2(u"ࠨ࠿ࠪႚ") in Zth7i2v1xI6TKpcP:
				BXCThrgedxOyF2N,NNZoTVqIcEG6l = Zth7i2v1xI6TKpcP.split(ASkvf27etUK0(u"ࠩࡀࠫႛ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠳ᖪ"))
				WsoQkLHm1ayh[BXCThrgedxOyF2N.lower()] = NNZoTVqIcEG6l
		if NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧႜ") in peItaQ6PDKEWvUBxAbYgrZ.lower():
			emIQYsN6huF = int(WsoQkLHm1ayh[vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨႝ")])//tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠴࠴࠷࠺ᖫ")
			UPkfbZE4NARs6h8zviJOYplQ += str(emIQYsN6huF)+sTGtHVyhQ9cJU37zxo2O(u"ࠬࡱࡢࡱࡵࠣࠤࠬ႞")
		elif ASkvf27etUK0(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ႟") in peItaQ6PDKEWvUBxAbYgrZ.lower():
			emIQYsN6huF = int(WsoQkLHm1ayh[qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪႠ")])//gCkRKGhwcx26v(u"࠵࠵࠸࠴ᖬ")
			UPkfbZE4NARs6h8zviJOYplQ += str(emIQYsN6huF)+Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨႡ")
		if DQIrVcKuY6bJv(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭Ⴂ") in peItaQ6PDKEWvUBxAbYgrZ.lower():
			lcbjBn3FdZxC1059A4Kqvi2pugJOa = int(WsoQkLHm1ayh[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧႣ")].split(TVnqDYzWoM2UfHp0dchJ(u"ࠫࡽ࠭Ⴄ"))[nyUIsfd53EGot9vbj0XDeq])
			UPkfbZE4NARs6h8zviJOYplQ += str(lcbjBn3FdZxC1059A4Kqvi2pugJOa)+nlNC2gJDBZMed63TxqphA1vrXm8Hy
		UPkfbZE4NARs6h8zviJOYplQ = UPkfbZE4NARs6h8zviJOYplQ.strip(nlNC2gJDBZMed63TxqphA1vrXm8Hy)
		if not UPkfbZE4NARs6h8zviJOYplQ: UPkfbZE4NARs6h8zviJOYplQ = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭Ⴅ")
		if not IIHsbDu7K1U38AZaodhqk0QTX.startswith(fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡨࡵࡶࡳࠫႦ")):
			if IIHsbDu7K1U38AZaodhqk0QTX.startswith(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠰࠱ࠪႧ")): IIHsbDu7K1U38AZaodhqk0QTX = pfhH2objgVkI7eycn.split(C3w6qluao7EzUxJgMGBtV(u"ࠨ࠼ࠪႨ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩ࠽ࠫႩ")+IIHsbDu7K1U38AZaodhqk0QTX
			elif IIHsbDu7K1U38AZaodhqk0QTX.startswith(DQIrVcKuY6bJv(u"ࠪ࠳ࠬႪ")): IIHsbDu7K1U38AZaodhqk0QTX = EDmwsQf1Px9k8h04oAHuObdnyrTGU(pfhH2objgVkI7eycn,fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡺࡸ࡬ࠨႫ"))+IIHsbDu7K1U38AZaodhqk0QTX
			else: IIHsbDu7K1U38AZaodhqk0QTX = pfhH2objgVkI7eycn.rsplit(C3w6qluao7EzUxJgMGBtV(u"ࠬ࠵ࠧႬ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]+DQIrVcKuY6bJv(u"࠭࠯ࠨႭ")+IIHsbDu7K1U38AZaodhqk0QTX
		if C3w6qluao7EzUxJgMGBtV(u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩႮ") in list(WsoQkLHm1ayh.keys()):
			Sn3lefFys4XLgp8JiRvV = WsoQkLHm1ayh[HCiWF4jV1Q8(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪႯ")]
			Sn3lefFys4XLgp8JiRvV = Sn3lefFys4XLgp8JiRvV.replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࠥࠫႰ"),SebHIf2jL1TBgrMKJu).replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠥࠫࠧႱ"),SebHIf2jL1TBgrMKJu).split(l7kBpMw5Qn(u"ࠫࠨ࠭Ⴒ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
			stQZoj85K3HPTUq2pCDAbaGSXLJw = j1HGJPrFA3tTfLxayDCgIpE7Q(Sn3lefFys4XLgp8JiRvV)
			if stQZoj85K3HPTUq2pCDAbaGSXLJw: sABprza7wEOC0Fd3PTQ = UPkfbZE4NARs6h8zviJOYplQ+nlNC2gJDBZMed63TxqphA1vrXm8Hy+stQZoj85K3HPTUq2pCDAbaGSXLJw
			else: sABprza7wEOC0Fd3PTQ = UPkfbZE4NARs6h8zviJOYplQ
			sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࠦࠠࡑࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩࠬႳ")
			sABprza7wEOC0Fd3PTQ = sABprza7wEOC0Fd3PTQ+nlNC2gJDBZMed63TxqphA1vrXm8Hy+EDmwsQf1Px9k8h04oAHuObdnyrTGU(Sn3lefFys4XLgp8JiRvV,AGlW9LqKN3Dvo(u"࠭࡮ࡢ࡯ࡨࠫႴ"))
			HFThJNteGZsSR5CD7rimbjPq.append(sABprza7wEOC0Fd3PTQ)
			bQGVWFxKS4D6p9YC7XPyA8Os.append(Sn3lefFys4XLgp8JiRvV)
			qKFVnkoLMlE3j.append(lcbjBn3FdZxC1059A4Kqvi2pugJOa)
			GGWDKFVAj7pbm.append(emIQYsN6huF)
		IIHsbDu7K1U38AZaodhqk0QTX = IIHsbDu7K1U38AZaodhqk0QTX.split(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧࠤࠩႵ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
		stQZoj85K3HPTUq2pCDAbaGSXLJw = j1HGJPrFA3tTfLxayDCgIpE7Q(IIHsbDu7K1U38AZaodhqk0QTX)
		if stQZoj85K3HPTUq2pCDAbaGSXLJw: UPkfbZE4NARs6h8zviJOYplQ = UPkfbZE4NARs6h8zviJOYplQ+nlNC2gJDBZMed63TxqphA1vrXm8Hy+stQZoj85K3HPTUq2pCDAbaGSXLJw
		UPkfbZE4NARs6h8zviJOYplQ = UPkfbZE4NARs6h8zviJOYplQ+nlNC2gJDBZMed63TxqphA1vrXm8Hy+EDmwsQf1Px9k8h04oAHuObdnyrTGU(IIHsbDu7K1U38AZaodhqk0QTX,uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡰࡤࡱࡪ࠭Ⴖ"))
		HFThJNteGZsSR5CD7rimbjPq.append(UPkfbZE4NARs6h8zviJOYplQ)
		bQGVWFxKS4D6p9YC7XPyA8Os.append(IIHsbDu7K1U38AZaodhqk0QTX)
		qKFVnkoLMlE3j.append(lcbjBn3FdZxC1059A4Kqvi2pugJOa)
		GGWDKFVAj7pbm.append(emIQYsN6huF)
	eUuRqsfnW8y2BS5cCG4ZhgODJj = list(zip(HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os,qKFVnkoLMlE3j,GGWDKFVAj7pbm))
	eUuRqsfnW8y2BS5cCG4ZhgODJj = sorted(eUuRqsfnW8y2BS5cCG4ZhgODJj, reverse=BBX9RAuxnyGZ4WIF2TrhYeom3, key=lambda key: key[fuCbjVag7vU908J2Yqx5Th])
	HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os,qKFVnkoLMlE3j,GGWDKFVAj7pbm = list(zip(*eUuRqsfnW8y2BS5cCG4ZhgODJj))
	HFThJNteGZsSR5CD7rimbjPq,bQGVWFxKS4D6p9YC7XPyA8Os = list(HFThJNteGZsSR5CD7rimbjPq),list(bQGVWFxKS4D6p9YC7XPyA8Os)
	jur15x2kUH0BOZdoApYgIV = []
	for IIHsbDu7K1U38AZaodhqk0QTX in bQGVWFxKS4D6p9YC7XPyA8Os: jur15x2kUH0BOZdoApYgIV.append(IIHsbDu7K1U38AZaodhqk0QTX+C1yvpquagDHdSQMsOY3LTf6n2heP)
	QoSfGTXFUJali8zxbq49h3 = list(zip(jur15x2kUH0BOZdoApYgIV,[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡧࡹࡲࡳࡹࠨႷ")]*len(jur15x2kUH0BOZdoApYgIV),GGWDKFVAj7pbm))
	OMXSgGTxnr = ec9ywhrLSqmN87FMKIQPxOuoU(tfX4sO3hy2H1IbKG,QoSfGTXFUJali8zxbq49h3)
	if OMXSgGTxnr:
		cOn6JqZlmQbjtT,fNnuAzFsXhBKCco9JZeVUvd7Ya,emIQYsN6huF = OMXSgGTxnr[ALwOspNtXxZrz3PEKku(u"࠵ᖭ")]
		index = jur15x2kUH0BOZdoApYgIV.index(cOn6JqZlmQbjtT)
		title = HFThJNteGZsSR5CD7rimbjPq[index]
		HFThJNteGZsSR5CD7rimbjPq,jur15x2kUH0BOZdoApYgIV = [title],[cOn6JqZlmQbjtT]
	return HFThJNteGZsSR5CD7rimbjPq,jur15x2kUH0BOZdoApYgIV
def VbuRTd8mqrlspv2OCktGMSDya1Y(N71BmUdWCthRJbrzXcg08ilSHs5,tbjSgf4uz78qdrAvkxLiRhMcwQ=SebHIf2jL1TBgrMKJu):
	if not tbjSgf4uz78qdrAvkxLiRhMcwQ: tbjSgf4uz78qdrAvkxLiRhMcwQ = qFsuKN7ngp.DNS_SERVERS[wvkDqmNZlJU52isXo]
	if N71BmUdWCthRJbrzXcg08ilSHs5.replace(C3w6qluao7EzUxJgMGBtV(u"ࠪ࠲ࠬႸ"),SebHIf2jL1TBgrMKJu).isdigit(): return [N71BmUdWCthRJbrzXcg08ilSHs5]
	from struct import pack as onye3A1Rxs8rPJ9Dd,unpack_from as WjGUCLQYns
	from socket import socket as bvtc8KLZV4uRnJh0Q1I7,AF_INET as LknU0Q5lDacKWVBr6vg8PmHJj9,SOCK_DGRAM as fKwDLomWuM
	try:
		tWv6zmgCPir4 = onye3A1Rxs8rPJ9Dd(l7kBpMw5Qn(u"ࠦࡃࡎࠢႹ"), cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠷࠲࠱࠶࠼ᖮ"))
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡄࡈࠣႺ"), wPnfgxKZdAv6T10(u"࠲࠶࠸ᖯ"))
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(DQIrVcKuY6bJv(u"ࠨ࠾ࡉࠤႻ"), nyUIsfd53EGot9vbj0XDeq)
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(DQIrVcKuY6bJv(u"ࠢ࠿ࡊࠥႼ"), wvkDqmNZlJU52isXo)
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠣࡀࡋࠦႽ"), wvkDqmNZlJU52isXo)
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠤࡁࡌࠧႾ"), wvkDqmNZlJU52isXo)
		if QBOMjKifEAFD: khIWax3ucplR9HOfUtBYweME = N71BmUdWCthRJbrzXcg08ilSHs5.split(uqLUBHepfM3l6AyIzTJh80a(u"ࠪ࠲ࠬႿ"))
		else: khIWax3ucplR9HOfUtBYweME = N71BmUdWCthRJbrzXcg08ilSHs5.decode(Tv08xsf9HOqunIVUPdK1).split(ALwOspNtXxZrz3PEKku(u"ࠫ࠳࠭Ⴠ"))
		for WWakrdEIqngcLKTuJ4Fyj7Ne3 in khIWax3ucplR9HOfUtBYweME:
			lOUt3jiZ4euyAzxVmLDRrv5079kBC = WWakrdEIqngcLKTuJ4Fyj7Ne3.encode(Tv08xsf9HOqunIVUPdK1)
			tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(gCkRKGhwcx26v(u"ࠧࡈࠢჁ"), len(WWakrdEIqngcLKTuJ4Fyj7Ne3))
			for tjMWgfS1IXB2zsPQTVCwDxH in WWakrdEIqngcLKTuJ4Fyj7Ne3:
				tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡣࠣჂ"), tjMWgfS1IXB2zsPQTVCwDxH.encode(Tv08xsf9HOqunIVUPdK1))
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠢࡃࠤჃ"), wvkDqmNZlJU52isXo)
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠣࡀࡋࠦჄ"), nyUIsfd53EGot9vbj0XDeq)
		tWv6zmgCPir4 += onye3A1Rxs8rPJ9Dd(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠤࡁࡌࠧჅ"), nyUIsfd53EGot9vbj0XDeq)
		Bj32CSnNfeLvGx4E85Hd1iK = bvtc8KLZV4uRnJh0Q1I7(LknU0Q5lDacKWVBr6vg8PmHJj9,fKwDLomWuM)
		Bj32CSnNfeLvGx4E85Hd1iK.sendto(bytes(tWv6zmgCPir4),(tbjSgf4uz78qdrAvkxLiRhMcwQ,czvu7VQCZodkMf(u"࠶࠵ᖰ")))
		Bj32CSnNfeLvGx4E85Hd1iK.settimeout(Izy1PvclrYx4eSVWn0L5phZbq(u"࠸ᖱ"))
		qqTB9mr0Av7jKg3UOYzLl, cJ1sE6UlPwC = Bj32CSnNfeLvGx4E85Hd1iK.recvfrom(xxRyYsrSCzjifvH4cIqgldeOo(u"࠴࠴࠷࠺ᖲ"))
		Bj32CSnNfeLvGx4E85Hd1iK.close()
		njYCG0a31foByZ8DFI29m7liVeuH = WjGUCLQYns(VOALf8iYEnMdK0g(u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ჆"), qqTB9mr0Av7jKg3UOYzLl, wvkDqmNZlJU52isXo)
		jjbMGsZciJYEKw5zq2rQC = njYCG0a31foByZ8DFI29m7liVeuH[fuCbjVag7vU908J2Yqx5Th]
		lIbetSBAy9Ln4zr = len(N71BmUdWCthRJbrzXcg08ilSHs5)+Gykx0wL3XrlWaujsqKP9n2Q(u"࠵࠽ᖳ")
		rtfbXCjOD8pdgFSn7zTous2wY5y = []
		for _gouIb4ln5PrLFXjxNa7ftOm in range(jjbMGsZciJYEKw5zq2rQC):
			kFuoKhBqS6UYWZL85ts09JMGNic = lIbetSBAy9Ln4zr
			hNT2FLAY4Ke5 = nyUIsfd53EGot9vbj0XDeq
			BItTDxg2Uso40vnqPV5MHNA8cp = mrhSYXH2P8bO3eJAa9n
			while BBX9RAuxnyGZ4WIF2TrhYeom3:
				tjMWgfS1IXB2zsPQTVCwDxH = WjGUCLQYns(ALwOspNtXxZrz3PEKku(u"ࠦࡃࡈࠢჇ"), qqTB9mr0Av7jKg3UOYzLl, kFuoKhBqS6UYWZL85ts09JMGNic)[wvkDqmNZlJU52isXo]
				if tjMWgfS1IXB2zsPQTVCwDxH == wvkDqmNZlJU52isXo:
					kFuoKhBqS6UYWZL85ts09JMGNic += nyUIsfd53EGot9vbj0XDeq
					break
				if tjMWgfS1IXB2zsPQTVCwDxH >= cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠶࠿࠲ᖴ"):
					vT5QISakOE9nhwlBM1 = WjGUCLQYns(l7kBpMw5Qn(u"ࠧࡄࡂࠣ჈"), qqTB9mr0Av7jKg3UOYzLl, kFuoKhBqS6UYWZL85ts09JMGNic + nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
					kFuoKhBqS6UYWZL85ts09JMGNic = ((tjMWgfS1IXB2zsPQTVCwDxH << ASkvf27etUK0(u"࠾ᖵ")) + vT5QISakOE9nhwlBM1 - 0xc000) - nyUIsfd53EGot9vbj0XDeq
					BItTDxg2Uso40vnqPV5MHNA8cp = BBX9RAuxnyGZ4WIF2TrhYeom3
				kFuoKhBqS6UYWZL85ts09JMGNic += nyUIsfd53EGot9vbj0XDeq
				if BItTDxg2Uso40vnqPV5MHNA8cp == mrhSYXH2P8bO3eJAa9n: hNT2FLAY4Ke5 += nyUIsfd53EGot9vbj0XDeq
			if BItTDxg2Uso40vnqPV5MHNA8cp == BBX9RAuxnyGZ4WIF2TrhYeom3: hNT2FLAY4Ke5 += nyUIsfd53EGot9vbj0XDeq
			lIbetSBAy9Ln4zr = lIbetSBAy9Ln4zr + hNT2FLAY4Ke5
			qrNMivAhBLKRPJ107xDsY = WjGUCLQYns(wPnfgxKZdAv6T10(u"ࠨ࠾ࡉࡊࡌࡌࠧ჉"), qqTB9mr0Av7jKg3UOYzLl, lIbetSBAy9Ln4zr)
			lIbetSBAy9Ln4zr = lIbetSBAy9Ln4zr + l7kBpMw5Qn(u"࠱࠱ᖶ")
			B6RlAPVSZnXM = qrNMivAhBLKRPJ107xDsY[wvkDqmNZlJU52isXo]
			fLo9mGqPzQdsXEUiZ3 = qrNMivAhBLKRPJ107xDsY[fuCbjVag7vU908J2Yqx5Th]
			if B6RlAPVSZnXM == nyUIsfd53EGot9vbj0XDeq:
				G0ljYJ3ERcd5kiAZQ8tNpgn7TMIS = WjGUCLQYns(HADrRCz9QgU4xudPJIqYb70(u"ࠢ࠿ࠤ჊")+bcNqYtfET5l92dLGjyZSPe(u"ࠣࡄࠥ჋")*fLo9mGqPzQdsXEUiZ3, qqTB9mr0Av7jKg3UOYzLl, lIbetSBAy9Ln4zr)
				ip = SebHIf2jL1TBgrMKJu
				for tjMWgfS1IXB2zsPQTVCwDxH in G0ljYJ3ERcd5kiAZQ8tNpgn7TMIS: ip += str(tjMWgfS1IXB2zsPQTVCwDxH) + czvu7VQCZodkMf(u"ࠩ࠱ࠫ჌")
				ip = ip[wvkDqmNZlJU52isXo:-nyUIsfd53EGot9vbj0XDeq]
				rtfbXCjOD8pdgFSn7zTous2wY5y.append(ip)
			if B6RlAPVSZnXM in [nyUIsfd53EGot9vbj0XDeq,JhTts2R43AxkM8bYanKVy,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠸ᖹ"),Gykx0wL3XrlWaujsqKP9n2Q(u"࠺ᖺ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"࠳࠸ᖸ"),ALwOspNtXxZrz3PEKku(u"࠳࠺ᖷ")]: lIbetSBAy9Ln4zr = lIbetSBAy9Ln4zr + fLo9mGqPzQdsXEUiZ3
	except: rtfbXCjOD8pdgFSn7zTous2wY5y = []
	if not rtfbXCjOD8pdgFSn7zTous2wY5y: z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ASkvf27etUK0(u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩჍ")+N71BmUdWCthRJbrzXcg08ilSHs5+gCkRKGhwcx26v(u"ࠫࠥࡣࠧ჎"))
	return rtfbXCjOD8pdgFSn7zTous2wY5y
def HC5h0TIwPOU76oVLcp(tfX4sO3hy2H1IbKG,pfhH2objgVkI7eycn,S5u2RZG3yCOl9gp8D4JVoa,showDialogs=BBX9RAuxnyGZ4WIF2TrhYeom3):
	if qFsuKN7ngp.avprivsnorestrict or not S5u2RZG3yCOl9gp8D4JVoa: return mrhSYXH2P8bO3eJAa9n
	w18vS4fDFaiEY60NxZTHUOuc = [DQIrVcKuY6bJv(u"ࠬࡧࡤࡶ࡮ࡷࠫ჏"),iDhLkZS6XBagNCQfs9tq2(u"࠭࠱࠹࠭ࠪა"),l7kBpMw5Qn(u"ࠧࡹࡺࠪბ"),HADrRCz9QgU4xudPJIqYb70(u"ࠨࡲࡲࡶࡳ࠭გ"),wPnfgxKZdAv6T10(u"ࠩࡶࡩࡽ࠭დ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡲࡸ࡬ࡷࠨე"),sTGtHVyhQ9cJU37zxo2O(u"ࠫࡲࡧࡴࡶࡴࡨࠫვ"),l7kBpMw5Qn(u"้ࠬศศำࠪზ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ศศๆ฽ࠫთ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧศสสั๏࠭ი"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠨฮ้ืࠬკ"),HCiWF4jV1Q8(u"่้๋ࠩ๎ูࠨლ")]
	if tfX4sO3hy2H1IbKG!=AGlW9LqKN3Dvo(u"ࠪࡆࡔࡑࡒࡂࠩმ"): w18vS4fDFaiEY60NxZTHUOuc += [NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡷࡀࠧნ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡀࡲࠨო"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡲ࠮ࠩპ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧ࠮ࡴࠪჟ"),C3w6qluao7EzUxJgMGBtV(u"ࠨ࠯ࡰࡥࠬრ"),HADrRCz9QgU4xudPJIqYb70(u"ࠩࡰࡥ࠲࠭ს")]
	for F8TsvzGhQnWyerV5jdLaOxE27 in S5u2RZG3yCOl9gp8D4JVoa:
		F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.lower()
		if wPnfgxKZdAv6T10(u"ࠪ࡫ࡪࡺ࠮ࡱࡪࡳࡃࠬტ") in F8TsvzGhQnWyerV5jdLaOxE27: continue
		if vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧუ") in F8TsvzGhQnWyerV5jdLaOxE27: continue
		if NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭ფ") in F8TsvzGhQnWyerV5jdLaOxE27: continue
		if zpx2fPNKk6Ms38eD1vcO(u"࠭อๅไฬࠫქ") in F8TsvzGhQnWyerV5jdLaOxE27: continue
		if VOALf8iYEnMdK0g(u"ࠧ฻์ิࠤ๊฻ๆโࠩღ") in F8TsvzGhQnWyerV5jdLaOxE27: continue
		F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.replace(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨลࠪყ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩสࠫშ")).replace(iDhLkZS6XBagNCQfs9tq2(u"ࠪษࠬჩ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫฬ࠭ც")).replace(HADrRCz9QgU4xudPJIqYb70(u"ࠬศࠧძ"),t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭วࠨწ")).replace(ASkvf27etUK0(u"ࠧ๏ࠩჭ"),SebHIf2jL1TBgrMKJu).replace(bcNqYtfET5l92dLGjyZSPe(u"ࠨํࠪხ"),SebHIf2jL1TBgrMKJu)
		F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.replace(vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ๒ࠫჯ"),SebHIf2jL1TBgrMKJu).replace(C3w6qluao7EzUxJgMGBtV(u"ࠪ๔ࠬჰ"),SebHIf2jL1TBgrMKJu).replace(DQIrVcKuY6bJv(u"ࠫ๒࠭ჱ"),SebHIf2jL1TBgrMKJu).replace(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ๗ࠧჲ"),SebHIf2jL1TBgrMKJu)
		F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.replace(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭เࠨჳ"),SebHIf2jL1TBgrMKJu).replace(sTGtHVyhQ9cJU37zxo2O(u"ࠧ࠻ࠩჴ"),SebHIf2jL1TBgrMKJu)
		if psS8dmb912iRBgGc7qOPyCZ6: F8TsvzGhQnWyerV5jdLaOxE27 = F8TsvzGhQnWyerV5jdLaOxE27.decode(Tv08xsf9HOqunIVUPdK1).encode(Tv08xsf9HOqunIVUPdK1)
		GHxtCS7ou1WTKgdiV5360sU = X2XorVqHjLkWeCchY4u9fSz.findall(zpx2fPNKk6Ms38eD1vcO(u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮࠭ࠬჵ"),F8TsvzGhQnWyerV5jdLaOxE27,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		vq6Pph5ATEg3yZs8ODul = mrhSYXH2P8bO3eJAa9n
		for G5GseIX3urLCyNOgMhvEKq0pladj in GHxtCS7ou1WTKgdiV5360sU:
			if len(G5GseIX3urLCyNOgMhvEKq0pladj)==JhTts2R43AxkM8bYanKVy:
				vq6Pph5ATEg3yZs8ODul = BBX9RAuxnyGZ4WIF2TrhYeom3
				break
		if F8TsvzGhQnWyerV5jdLaOxE27 in [v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡵࠫჶ")] or vq6Pph5ATEg3yZs8ODul or any(value in F8TsvzGhQnWyerV5jdLaOxE27 for value in w18vS4fDFaiEY60NxZTHUOuc):
			z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+l7kBpMw5Qn(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩჷ")+pfhH2objgVkI7eycn+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࠥࡣࠧჸ"))
			if showDialogs: i9yzUqgAW2Zap1h4Lm(lFEvMxzSH2y7tYR,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧჹ"))
			return BBX9RAuxnyGZ4WIF2TrhYeom3
	return mrhSYXH2P8bO3eJAa9n
def b6rmBauMc3HqTev0t(iPrvmHoVR1bGcaSIA0wkLf892=BBX9RAuxnyGZ4WIF2TrhYeom3):
	if iPrvmHoVR1bGcaSIA0wkLf892:
		YIgWR5Sj3cVXaEuqhkHo = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ࡳࡵࡴࠪჺ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬ჻"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫჼ"))
		if YIgWR5Sj3cVXaEuqhkHo: return YIgWR5Sj3cVXaEuqhkHo
	sLjle5myuEXSiFHJ = SebHIf2jL1TBgrMKJu
	if wvkDqmNZlJU52isXo and Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
		C4257GIxAk = YD0R1z8ldmipE.count(sTGtHVyhQ9cJU37zxo2O(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪჽ"))
		if C4257GIxAk>l7kBpMw5Qn(u"࠽࠶ᖻ"):
			sLjle5myuEXSiFHJ = X2XorVqHjLkWeCchY4u9fSz.findall(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬჾ"),YD0R1z8ldmipE,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ[wvkDqmNZlJU52isXo]
	if not sLjle5myuEXSiFHJ:
		XXz1rTFUKDSvIk53MCY6AwZiflQpdE = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪჿ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭ᄀ"))
		sLjle5myuEXSiFHJ = open(XXz1rTFUKDSvIk53MCY6AwZiflQpdE,iDhLkZS6XBagNCQfs9tq2(u"࠭ࡲࡣࠩᄁ")).read()
		if QBOMjKifEAFD: sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ.decode(Tv08xsf9HOqunIVUPdK1)
		sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ.replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu)
	OCbGzukTm4IcrQE0 = X2XorVqHjLkWeCchY4u9fSz.findall(HCiWF4jV1Q8(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨᄂ"),sLjle5myuEXSiFHJ,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	OOgJbjCyQcWPzMYwR2rstlIXKG = []
	for peItaQ6PDKEWvUBxAbYgrZ in OCbGzukTm4IcrQE0:
		vg36QOz52uUwAVI84D = peItaQ6PDKEWvUBxAbYgrZ.lower()
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩᄃ") in vg36QOz52uUwAVI84D: continue
		if DQIrVcKuY6bJv(u"ࠩࡸࡦࡺࡴࡴࡶࠩᄄ") in vg36QOz52uUwAVI84D: continue
		if cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪᄅ") in vg36QOz52uUwAVI84D: continue
		if Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫࡨࡸ࡯ࡴࠩᄆ") in vg36QOz52uUwAVI84D: continue
		OOgJbjCyQcWPzMYwR2rstlIXKG.append(peItaQ6PDKEWvUBxAbYgrZ)
	YIgWR5Sj3cVXaEuqhkHo = JO7n9zxwdgIStrTjR.sample(OOgJbjCyQcWPzMYwR2rstlIXKG,nyUIsfd53EGot9vbj0XDeq)
	YIgWR5Sj3cVXaEuqhkHo = YIgWR5Sj3cVXaEuqhkHo[wvkDqmNZlJU52isXo]
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,wPnfgxKZdAv6T10(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪᄇ"),fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩᄈ"),YIgWR5Sj3cVXaEuqhkHo,QfG1xIZ4hpq3ezPXt7VbvglUcB)
	return YIgWR5Sj3cVXaEuqhkHo
def OZINRkynbpYDKiTqHVoces9XEMCxtP(yamjrsOAG4iFfQkuW1JXbZ0Dgq7z=SebHIf2jL1TBgrMKJu):
	if qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX==mrhSYXH2P8bO3eJAa9n: return
	if not yamjrsOAG4iFfQkuW1JXbZ0Dgq7z: yamjrsOAG4iFfQkuW1JXbZ0Dgq7z = HkQJ95ahZMwW0OtpKU2X.format_exc()
	if DQIrVcKuY6bJv(u"ࠧࡔࡻࡶࡸࡪࡳࡅࡹ࡫ࡷࠫᄉ") in yamjrsOAG4iFfQkuW1JXbZ0Dgq7z or NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫᄊ") in yamjrsOAG4iFfQkuW1JXbZ0Dgq7z: return
	if yamjrsOAG4iFfQkuW1JXbZ0Dgq7z!=Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᄋ"): yMqHPpxSEAFIwKecXdi40r8zL53.stderr.write(yamjrsOAG4iFfQkuW1JXbZ0Dgq7z)
	P7SQWVY4x1vm9tnANdiB = yamjrsOAG4iFfQkuW1JXbZ0Dgq7z.splitlines()
	ddZqPF6aCp2Uwxh = P7SQWVY4x1vm9tnANdiB[-v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠷ᖼ")]
	MzsNamAtLBHIywVSkFEnQpXgO = open(ASIWYZHDvLfX05Ghxj2qEiJuy4U6b,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡶࡧ࠭ᄌ")).read()
	if QBOMjKifEAFD: MzsNamAtLBHIywVSkFEnQpXgO = MzsNamAtLBHIywVSkFEnQpXgO.decode(Tv08xsf9HOqunIVUPdK1)
	MzsNamAtLBHIywVSkFEnQpXgO = MzsNamAtLBHIywVSkFEnQpXgO[-AGlW9LqKN3Dvo(u"࠸࠱࠲࠳ᖽ"):]
	ZPo8Gl4iTpNHb6z5e3 = sTGtHVyhQ9cJU37zxo2O(u"ࠫࡂ࠭ᄍ")*TVnqDYzWoM2UfHp0dchJ(u"࠲࠲࠳ᖾ")
	if ZPo8Gl4iTpNHb6z5e3 in MzsNamAtLBHIywVSkFEnQpXgO: MzsNamAtLBHIywVSkFEnQpXgO = MzsNamAtLBHIywVSkFEnQpXgO.rsplit(ZPo8Gl4iTpNHb6z5e3,nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
	if ddZqPF6aCp2Uwxh in MzsNamAtLBHIywVSkFEnQpXgO: MzsNamAtLBHIywVSkFEnQpXgO = MzsNamAtLBHIywVSkFEnQpXgO.rsplit(ddZqPF6aCp2Uwxh,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
	to8rNmXKiC3upgcwnxejvUAy4 = X2XorVqHjLkWeCchY4u9fSz.findall(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫᄎ"),MzsNamAtLBHIywVSkFEnQpXgO,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for tpXfY4KAgTkZeV0NnP8UL,qh4B9VQZCbXr0DRknFmi7J6 in reversed(to8rNmXKiC3upgcwnxejvUAy4):
		if qh4B9VQZCbXr0DRknFmi7J6: break
	else: qh4B9VQZCbXr0DRknFmi7J6 = gCkRKGhwcx26v(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ᄏ")
	AAtipVkQ9I2qJDo,peItaQ6PDKEWvUBxAbYgrZ,khjB9e254lrqciA7vHp03Gosxa = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw = gCkRKGhwcx26v(u"ࠧ࡜ࡔࡗࡐࡢ࠭ᄐ")+QNR6tCevIGEZKX3rAVsP+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨษ็า฼ษ࠺ࠡࠢࠪᄑ")+XOVRfitWJP1zL3p2CMYF+ddZqPF6aCp2Uwxh
	yFUtCXfqId = TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᄒ")+QNR6tCevIGEZKX3rAVsP+uqLUBHepfM3l6AyIzTJh80a(u"ࠪห้๋ีะำ࠽ࠤࠥ࠭ᄓ")+XOVRfitWJP1zL3p2CMYF+qh4B9VQZCbXr0DRknFmi7J6
	for jvmeZAixpXf in reversed(P7SQWVY4x1vm9tnANdiB):
		if t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫᄔ") in jvmeZAixpXf and t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᄕ") in jvmeZAixpXf: break
	jvmeZAixpXf = X2XorVqHjLkWeCchY4u9fSz.findall(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩᄖ"),jvmeZAixpXf,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if jvmeZAixpXf:
		AAtipVkQ9I2qJDo,peItaQ6PDKEWvUBxAbYgrZ,khjB9e254lrqciA7vHp03Gosxa = jvmeZAixpXf[wvkDqmNZlJU52isXo]
		if Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧ࠰ࠩᄗ") in AAtipVkQ9I2qJDo: AAtipVkQ9I2qJDo = AAtipVkQ9I2qJDo.rsplit(DQIrVcKuY6bJv(u"ࠨ࠱ࠪᄘ"),nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
		else: AAtipVkQ9I2qJDo = AAtipVkQ9I2qJDo.rsplit(zpx2fPNKk6Ms38eD1vcO(u"ࠩ࡟ࡠࠬᄙ"),nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
		e8gTJW9dMiAwy = ALwOspNtXxZrz3PEKku(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩᄚ")+QNR6tCevIGEZKX3rAVsP+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫฬ๊ๅๅใ࠽ࠤࠥ࠭ᄛ")+XOVRfitWJP1zL3p2CMYF+AAtipVkQ9I2qJDo
		qc9JOXgfoV2 = sTGtHVyhQ9cJU37zxo2O(u"ࠬࡡࡒࡕࡎࡠࠫᄜ")+QNR6tCevIGEZKX3rAVsP+TVnqDYzWoM2UfHp0dchJ(u"࠭วๅีฺี࠿ࠦࠠࠨᄝ")+XOVRfitWJP1zL3p2CMYF+peItaQ6PDKEWvUBxAbYgrZ
		Q6HrtaLkvz3PhpuGceIWnb = DQIrVcKuY6bJv(u"ࠧ࡜ࡔࡗࡐࡢ࠭ᄞ")+QNR6tCevIGEZKX3rAVsP+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨษ็้่อๆ࠻ࠢࠣࠫᄟ")+XOVRfitWJP1zL3p2CMYF+khjB9e254lrqciA7vHp03Gosxa
		EkGWho9dHP1xw = e8gTJW9dMiAwy+u43PVWjh7t9YwI+qc9JOXgfoV2+u43PVWjh7t9YwI+Q6HrtaLkvz3PhpuGceIWnb+u43PVWjh7t9YwI+yFUtCXfqId+u43PVWjh7t9YwI+k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw
		LLda9ToAVE = qc9JOXgfoV2+u43PVWjh7t9YwI+yFUtCXfqId+u43PVWjh7t9YwI+k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw+u43PVWjh7t9YwI+e8gTJW9dMiAwy+u43PVWjh7t9YwI+Q6HrtaLkvz3PhpuGceIWnb
		BWlV14ovbMkdf = qc9JOXgfoV2+u43PVWjh7t9YwI+k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw+u43PVWjh7t9YwI+e8gTJW9dMiAwy+u43PVWjh7t9YwI+Q6HrtaLkvz3PhpuGceIWnb
	else:
		e8gTJW9dMiAwy,qc9JOXgfoV2,Q6HrtaLkvz3PhpuGceIWnb = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
		EkGWho9dHP1xw = yFUtCXfqId+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ࡟ࡲࡡࡴࠧᄠ")+k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw
		LLda9ToAVE = yFUtCXfqId+AGlW9LqKN3Dvo(u"ࠪࡠࡳࡢ࡮ࠨᄡ")+k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw
		BWlV14ovbMkdf = k0rQvJ6YVBhl31uOtP9xWjdoS8bnCw
	jsarofG5c1yuWd6UPvhY72DQm = l7kBpMw5Qn(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨᄢ")+u43PVWjh7t9YwI
	AMtTYuN2Hfx4r5J = LLRmHupxYC2JwINeoc()
	F4yaj72dsGqc = []
	lfZmugQCFKLGT05AH29IsMiho = AMtTYuN2Hfx4r5J[zpx2fPNKk6Ms38eD1vcO(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᄣ")]
	I7KXcwvm5xtrZzQ = ZFztKMGiCmdNLyewoW4A96TJsf5R(xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV)
	if DQIrVcKuY6bJv(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᄤ") in list(AMtTYuN2Hfx4r5J.keys()):
		for iY12hQM8RU,TRGiZbOhvtIEyo60FJ5gaVApcdkmn,CCFXl016yeLI7itr2RkswSzEM in lfZmugQCFKLGT05AH29IsMiho:
			F4yaj72dsGqc = max(F4yaj72dsGqc,TRGiZbOhvtIEyo60FJ5gaVApcdkmn)
		if I7KXcwvm5xtrZzQ<F4yaj72dsGqc:
			xfH5SDIPY0WNhb3zFrc = VOALf8iYEnMdK0g(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪᄥ")
			x5BZ9SJfFAWV743cgCvoUamse = omIUAxNupsBHY0SGnJXzijltOyV(TVnqDYzWoM2UfHp0dchJ(u"ࠨࡴ࡬࡫࡭ࡺࠧᄦ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ᄧ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠪฮาี๊ฬࠩᄨ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫำื่อࠩᄩ"),jsarofG5c1yuWd6UPvhY72DQm+xfH5SDIPY0WNhb3zFrc,EkGWho9dHP1xw)
			if x5BZ9SJfFAWV743cgCvoUamse==nyUIsfd53EGot9vbj0XDeq:
				import WW03V9yQKJ
				WW03V9yQKJ.eex4VdtZ9fUsJhB7(BBX9RAuxnyGZ4WIF2TrhYeom3)
				LbTfk6oJPiSGpVMU()
			elif x5BZ9SJfFAWV743cgCvoUamse==JhTts2R43AxkM8bYanKVy: LbTfk6oJPiSGpVMU()
	meW7jZ9QgCT1qwix = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,sTGtHVyhQ9cJU37zxo2O(u"ࠬࡲࡩࡴࡶࠪᄪ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩᄫ"),zpx2fPNKk6Ms38eD1vcO(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩᄬ"))
	if not meW7jZ9QgCT1qwix: meW7jZ9QgCT1qwix = []
	LLda9ToAVE = LLda9ToAVE.replace(u43PVWjh7t9YwI,wPnfgxKZdAv6T10(u"ࠨ࡞࡟ࡲࠬᄭ")).replace(fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᄮ"),SebHIf2jL1TBgrMKJu).replace(QNR6tCevIGEZKX3rAVsP,SebHIf2jL1TBgrMKJu).replace(XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu)
	BWlV14ovbMkdf = BWlV14ovbMkdf.replace(u43PVWjh7t9YwI,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡠࡡࡴࠧᄯ")).replace(bcNqYtfET5l92dLGjyZSPe(u"ࠫࡠࡘࡔࡍ࡟ࠪᄰ"),SebHIf2jL1TBgrMKJu).replace(QNR6tCevIGEZKX3rAVsP,SebHIf2jL1TBgrMKJu).replace(XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu)
	UUcV6MNkJdOBWgHLDqI7l = xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࡀ࠺ࠨᄱ")+BWlV14ovbMkdf
	if UUcV6MNkJdOBWgHLDqI7l in meW7jZ9QgCT1qwix:
		xfH5SDIPY0WNhb3zFrc = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫᄲ")
		gge5CmAcldwv0(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᄳ"),SebHIf2jL1TBgrMKJu,jsarofG5c1yuWd6UPvhY72DQm+xfH5SDIPY0WNhb3zFrc,EkGWho9dHP1xw)
		return
	TAnBVWjgCG9ZxJ0RYou = str(zzGetSI9yqnbZh).split(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ࠰ࠪᄴ"))[wvkDqmNZlJU52isXo]
	pfhH2objgVkI7eycn = qFsuKN7ngp.SITESURLS[iDhLkZS6XBagNCQfs9tq2(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᄵ")][wPnfgxKZdAv6T10(u"࠸ᖿ")]
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡔࡔ࡙ࡔࠨᄶ"),pfhH2objgVkI7eycn,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬᄷ"),mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
	TTDrFxtQMKaS = X2XorVqHjLkWeCchY4u9fSz.findall(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬᄸ"),YD0R1z8ldmipE,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for dd4ylMxwDUFiz7,BxMeSIUPFGL2OHzkusDwvJAcX,In0Si52ReAubD4zw6TrCcx,CCtxKwQ5grsE2e1mNJLD9 in TTDrFxtQMKaS:
		dd4ylMxwDUFiz7 = dd4ylMxwDUFiz7.split(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࠫࠨᄹ"))
		In0Si52ReAubD4zw6TrCcx = In0Si52ReAubD4zw6TrCcx.split(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࠬࠩᄺ"))
		CCtxKwQ5grsE2e1mNJLD9 = CCtxKwQ5grsE2e1mNJLD9.split(C3w6qluao7EzUxJgMGBtV(u"ࠨ࠭ࠪᄻ"))
		if peItaQ6PDKEWvUBxAbYgrZ in dd4ylMxwDUFiz7 and ddZqPF6aCp2Uwxh==BxMeSIUPFGL2OHzkusDwvJAcX and xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV in In0Si52ReAubD4zw6TrCcx and TAnBVWjgCG9ZxJ0RYou in CCtxKwQ5grsE2e1mNJLD9:
			xfH5SDIPY0WNhb3zFrc = AGlW9LqKN3Dvo(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧᄼ")
			sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(AGlW9LqKN3Dvo(u"ࠪࡶ࡮࡭ࡨࡵࠩᄽ"),HCiWF4jV1Q8(u"ࠫำื่อࠩᄾ"),sTGtHVyhQ9cJU37zxo2O(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩᄿ"),jsarofG5c1yuWd6UPvhY72DQm+xfH5SDIPY0WNhb3zFrc,EkGWho9dHP1xw)
			if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq: gge5CmAcldwv0(DQIrVcKuY6bJv(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᅀ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,xfH5SDIPY0WNhb3zFrc)
			return
	xfH5SDIPY0WNhb3zFrc = gCkRKGhwcx26v(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧᅁ")
	choice = omIUAxNupsBHY0SGnJXzijltOyV(Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡴ࡬࡫࡭ࡺࠧᅂ"),AGlW9LqKN3Dvo(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ᅃ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪฮาี๊ฬࠢฯึห๐ࠧᅄ"),iDhLkZS6XBagNCQfs9tq2(u"ࠫฯำฯ๋อࠣห้ฮั็ษ่ะࠬᅅ"),jsarofG5c1yuWd6UPvhY72DQm+xfH5SDIPY0WNhb3zFrc,EkGWho9dHP1xw)
	if choice==nyUIsfd53EGot9vbj0XDeq:
		YnFwHlkv9We3iEPqzpSOR(mrhSYXH2P8bO3eJAa9n)
		i9yzUqgAW2Zap1h4Lm(czvu7VQCZodkMf(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠣห้าาว์ࠪᅆ"),bcNqYtfET5l92dLGjyZSPe(u"࠭ํࡔࡷࡦࡧࡪࡹࡳࠨᅇ"),uv8V4fE7j9pmgFr3wnDL=AGlW9LqKN3Dvo(u"࠺࠹࠵ᗀ"))
		LbTfk6oJPiSGpVMU()
	elif choice==JhTts2R43AxkM8bYanKVy:
		import WW03V9yQKJ
		WW03V9yQKJ.eex4VdtZ9fUsJhB7(BBX9RAuxnyGZ4WIF2TrhYeom3)
		LbTfk6oJPiSGpVMU()
	sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡤࡧࡱࡸࡪࡸࠧᅈ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,wPnfgxKZdAv6T10(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩᅉ"))
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq: T7WkNqJxpR9Lgj86UGeoihY = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬᅊ")
	else:
		gge5CmAcldwv0(HCiWF4jV1Q8(u"ࠪࡧࡪࡴࡴࡦࡴࠪᅋ"),SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,QNR6tCevIGEZKX3rAVsP+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫฯ๋ࠠฦๆ฽หฦࠦลาีส่ࠥอไฯูฦࠫᅌ")+XOVRfitWJP1zL3p2CMYF+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨᅍ"))
		return
	SlMkfbvj8BuRsGydepihKFOHAIL = LLda9ToAVE
	import WW03V9yQKJ
	Vsn3f1CA8FIu0krNclSDWP5v9YQaE = WW03V9yQKJ.OmVwKTdykGa3xXsECzW(C3w6qluao7EzUxJgMGBtV(u"࠭ࡅࡳࡴࡲࡶࡸ࠭ᅎ"),SlMkfbvj8BuRsGydepihKFOHAIL,BBX9RAuxnyGZ4WIF2TrhYeom3,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧᅏ"),T7WkNqJxpR9Lgj86UGeoihY)
	if Vsn3f1CA8FIu0krNclSDWP5v9YQaE and T7WkNqJxpR9Lgj86UGeoihY:
		meW7jZ9QgCT1qwix.append(UUcV6MNkJdOBWgHLDqI7l)
		pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,czvu7VQCZodkMf(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫᅐ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫᅑ"),meW7jZ9QgCT1qwix,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
	return
def umfaRSP3VH6L(qqTB9mr0Av7jKg3UOYzLl,filename=UTvNakRFQC):
	uv8V4fE7j9pmgFr3wnDL.sleep(ASkvf27etUK0(u"࠴࠳࠶࠲࠶ᗁ"))
	if QBOMjKifEAFD: qqTB9mr0Av7jKg3UOYzLl = qqTB9mr0Av7jKg3UOYzLl.encode(Tv08xsf9HOqunIVUPdK1)
	if not filename: YOaRApygTvD38oLSGqPsBzMCW6w = sTGtHVyhQ9cJU37zxo2O(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪᅒ")+str(uv8V4fE7j9pmgFr3wnDL.time())+czvu7VQCZodkMf(u"ࠫ࠳ࡪࡡࡵࠩᅓ")
	else: YOaRApygTvD38oLSGqPsBzMCW6w = Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬᅔ")+filename+TVnqDYzWoM2UfHp0dchJ(u"࠭࠮ࡥࡣࡷࠫᅕ")
	open(YOaRApygTvD38oLSGqPsBzMCW6w,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡸࡤࠪᅖ")).write(qqTB9mr0Av7jKg3UOYzLl)
	return
def Ta7zPgmdrNZIvqxo5(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7):
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7:
		kkHrpxZmdYPM = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,wPnfgxKZdAv6T10(u"ࠨ࡮࡬ࡷࡹ࠭ᅗ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᅘ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ᅙ"))
		if kkHrpxZmdYPM: return kkHrpxZmdYPM
	pfhH2objgVkI7eycn = qFsuKN7ngp.SITESURLS[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᅚ")][HCiWF4jV1Q8(u"࠺ᗂ")]
	Jd0sLEiXIyWUkZARTo1xSqvpCYHgP = GN2SztT85ChvfWxJbdoUa(mrhSYXH2P8bO3eJAa9n) if not AKxLVCjqYbBQ2WUGtgsovmfkS9lD7 else qFsuKN7ngp.AV_CLIENT_IDS
	ddP5p4NZtgjFrMnl8vHcLb1kT9VA = H28lnJ4fI3wadG()
	LHwNEhkMb92Kpf8UtuQTP3a6S = ddP5p4NZtgjFrMnl8vHcLb1kT9VA.split(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬ࠲ࠧᅛ"))[JhTts2R43AxkM8bYanKVy]
	WByRiAujNJ = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,l7kBpMw5Qn(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᅜ"))
	Fcw9JqUG3RxmO1grdjupQo = z5SoD7t0jGaPfR()
	IbRUyxhZBYz = {Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡶࡵࡨࡶࠬᅝ"):Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ALwOspNtXxZrz3PEKku(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᅞ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,DQIrVcKuY6bJv(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᅟ"):LHwNEhkMb92Kpf8UtuQTP3a6S,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪ࡭ࡩࡹࠧᅠ"):Td0evpwjJFMAOa(Fcw9JqUG3RxmO1grdjupQo)}
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,czvu7VQCZodkMf(u"ࠫࡕࡕࡓࡕࠩᅡ"),pfhH2objgVkI7eycn,IbRUyxhZBYz,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ALwOspNtXxZrz3PEKku(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠳࠱ࡴࡶࠪᅢ"))
	kkHrpxZmdYPM = []
	if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
		kkHrpxZmdYPM = YD0R1z8ldmipE.replace(bcNqYtfET5l92dLGjyZSPe(u"࠭࡜࡝ࡴࠪᅣ"),u43PVWjh7t9YwI).replace(ALwOspNtXxZrz3PEKku(u"ࠧ࡝࡞ࡱࠫᅤ"),u43PVWjh7t9YwI).replace(AGlW9LqKN3Dvo(u"ࠨ࡞ࡵࡠࡳ࠭ᅥ"),u43PVWjh7t9YwI).replace(vvm0bR6z8NK5wUg2l9jqrJu,u43PVWjh7t9YwI)
		kkHrpxZmdYPM = X2XorVqHjLkWeCchY4u9fSz.findall(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬᅦ"),kkHrpxZmdYPM,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if kkHrpxZmdYPM:
			kkHrpxZmdYPM = sorted(kkHrpxZmdYPM,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: int(key[wvkDqmNZlJU52isXo]))
			fwDM2gXmtlpNsi4aPv,Jd0sLEiXIyWUkZARTo1xSqvpCYHgP,ESvoylf2GA5ni8HXstaDcF43,rtfbXCjOD8pdgFSn7zTous2wY5y,gXtxYDA8jpUI5daPfRlwV4mhLZ0Cq,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = kkHrpxZmdYPM[wvkDqmNZlJU52isXo]
			YMq74OjUDNtbAeG80dzRIy1nVgSrPL = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz if qFsuKN7ngp.avprivslongperiod else ESvoylf2GA5ni8HXstaDcF43
			MMAUZiw4CoJ8.setSetting(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬᅧ"),YMq74OjUDNtbAeG80dzRIy1nVgSrPL)
			pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,zpx2fPNKk6Ms38eD1vcO(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩᅨ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᅩ"),kkHrpxZmdYPM,QfG1xIZ4hpq3ezPXt7VbvglUcB)
			MMAUZiw4CoJ8.setSetting(czvu7VQCZodkMf(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨᅪ"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
	return kkHrpxZmdYPM
def f1sy2meG8IhuvdMjKJQBWw7(B0iOSpPGmRjg8zQ4XHfnD7CecVxZqY,L8vF1ABbl6zk4cQJESgesoHZYwi=wvkDqmNZlJU52isXo,dL4GpknZfyFPWC7Kz5utTVHb0g9rc=wvkDqmNZlJU52isXo):
	if L8vF1ABbl6zk4cQJESgesoHZYwi and not dL4GpknZfyFPWC7Kz5utTVHb0g9rc: dL4GpknZfyFPWC7Kz5utTVHb0g9rc = len(B0iOSpPGmRjg8zQ4XHfnD7CecVxZqY)//L8vF1ABbl6zk4cQJESgesoHZYwi
	WA9ik8QvIESthyK51pZUl0,XM3KUmO1QJxlv84bgFTHsjdNt0kYq,iIdLcnW1m53wqCe = [],-nyUIsfd53EGot9vbj0XDeq,wvkDqmNZlJU52isXo
	for Zth7i2v1xI6TKpcP in B0iOSpPGmRjg8zQ4XHfnD7CecVxZqY:
		if iIdLcnW1m53wqCe%dL4GpknZfyFPWC7Kz5utTVHb0g9rc==wvkDqmNZlJU52isXo:
			XM3KUmO1QJxlv84bgFTHsjdNt0kYq += nyUIsfd53EGot9vbj0XDeq
			WA9ik8QvIESthyK51pZUl0.append([])
		WA9ik8QvIESthyK51pZUl0[XM3KUmO1QJxlv84bgFTHsjdNt0kYq].append(Zth7i2v1xI6TKpcP)
		iIdLcnW1m53wqCe += nyUIsfd53EGot9vbj0XDeq
	return WA9ik8QvIESthyK51pZUl0
def B85GT1UQRXIPuesqvz(YOaRApygTvD38oLSGqPsBzMCW6w,qqTB9mr0Av7jKg3UOYzLl):
	CtexHAfSL1bodO5zuBh8Kj6ypm = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,YOaRApygTvD38oLSGqPsBzMCW6w)
	if nyUIsfd53EGot9vbj0XDeq or VOALf8iYEnMdK0g(u"ࠧࡊࡒࡗ࡚ࡤ࠭ᅫ") not in YOaRApygTvD38oLSGqPsBzMCW6w or vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡏ࠶࡙ࡤ࠭ᅬ") not in YOaRApygTvD38oLSGqPsBzMCW6w: sLjle5myuEXSiFHJ = str(qqTB9mr0Av7jKg3UOYzLl)
	else:
		WA9ik8QvIESthyK51pZUl0 = f1sy2meG8IhuvdMjKJQBWw7(qqTB9mr0Av7jKg3UOYzLl,ALwOspNtXxZrz3PEKku(u"࠾ᗃ"))
		sLjle5myuEXSiFHJ = SebHIf2jL1TBgrMKJu
		for hLODHYMZBx9vK7W4sm in WA9ik8QvIESthyK51pZUl0:
			sLjle5myuEXSiFHJ += str(hLODHYMZBx9vK7W4sm)+C3w6qluao7EzUxJgMGBtV(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨᅭ")
		sLjle5myuEXSiFHJ = sLjle5myuEXSiFHJ.strip(bcNqYtfET5l92dLGjyZSPe(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᅮ"))
	EtWUKJQnlT1dXkH5IGAy9NV3Mqf8 = kLtsvDVQ0SZmTjhBG9uW.compress(sLjle5myuEXSiFHJ)
	open(CtexHAfSL1bodO5zuBh8Kj6ypm,czvu7VQCZodkMf(u"ࠫࡼࡨࠧᅯ")).write(EtWUKJQnlT1dXkH5IGAy9NV3Mqf8)
	return
def qEwT8MDadI9YyeAN4(zQPURo9E0JK,YOaRApygTvD38oLSGqPsBzMCW6w):
	if zQPURo9E0JK==ASkvf27etUK0(u"ࠬࡪࡩࡤࡶࠪᅰ"): qqTB9mr0Av7jKg3UOYzLl = {}
	elif zQPURo9E0JK==TVnqDYzWoM2UfHp0dchJ(u"࠭࡬ࡪࡵࡷࠫᅱ"): qqTB9mr0Av7jKg3UOYzLl = []
	elif zQPURo9E0JK==wPnfgxKZdAv6T10(u"ࠧࡴࡶࡵࠫᅲ"): qqTB9mr0Av7jKg3UOYzLl = SebHIf2jL1TBgrMKJu
	elif zQPURo9E0JK==gCkRKGhwcx26v(u"ࠨ࡫ࡱࡸࠬᅳ"): qqTB9mr0Av7jKg3UOYzLl = wvkDqmNZlJU52isXo
	else: qqTB9mr0Av7jKg3UOYzLl = UTvNakRFQC
	CtexHAfSL1bodO5zuBh8Kj6ypm = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,YOaRApygTvD38oLSGqPsBzMCW6w)
	EtWUKJQnlT1dXkH5IGAy9NV3Mqf8 = open(CtexHAfSL1bodO5zuBh8Kj6ypm,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡵࡦࠬᅴ")).read()
	sLjle5myuEXSiFHJ = kLtsvDVQ0SZmTjhBG9uW.decompress(EtWUKJQnlT1dXkH5IGAy9NV3Mqf8)
	if C3w6qluao7EzUxJgMGBtV(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᅵ") not in sLjle5myuEXSiFHJ: qqTB9mr0Av7jKg3UOYzLl = eval(sLjle5myuEXSiFHJ)
	else:
		WA9ik8QvIESthyK51pZUl0 = sLjle5myuEXSiFHJ.split(vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪᅶ"))
		del sLjle5myuEXSiFHJ
		qqTB9mr0Av7jKg3UOYzLl = []
		ENDL1sXV4hj8PIld3B7oqr6Oc = BU0NzOhc2Cv7V9WMLEQRq()
		fwDM2gXmtlpNsi4aPv = wvkDqmNZlJU52isXo
		for hLODHYMZBx9vK7W4sm in WA9ik8QvIESthyK51pZUl0:
			ENDL1sXV4hj8PIld3B7oqr6Oc.bbKpGqOy9lNjFduSUXYnHe3Pik(str(fwDM2gXmtlpNsi4aPv),eval,hLODHYMZBx9vK7W4sm)
			fwDM2gXmtlpNsi4aPv += nyUIsfd53EGot9vbj0XDeq
		del WA9ik8QvIESthyK51pZUl0
		ENDL1sXV4hj8PIld3B7oqr6Oc.oh1EefzLUF()
		ENDL1sXV4hj8PIld3B7oqr6Oc.dlQKj7kWX8enP1viNuaEBULtD9OcAy()
		PnXLQMlcfWiSKJasg2v5tF = list(ENDL1sXV4hj8PIld3B7oqr6Oc.resultsDICT.keys())
		GPSklsXx9jtpiI046TYWJ1Q3Be = sorted(PnXLQMlcfWiSKJasg2v5tF,reverse=mrhSYXH2P8bO3eJAa9n,key=lambda key: int(key))
		for fwDM2gXmtlpNsi4aPv in GPSklsXx9jtpiI046TYWJ1Q3Be:
			qqTB9mr0Av7jKg3UOYzLl += ENDL1sXV4hj8PIld3B7oqr6Oc.resultsDICT[fwDM2gXmtlpNsi4aPv]
	return qqTB9mr0Av7jKg3UOYzLl
def cDQ0ouAmIeNEwtlf25rs6xbO(WYGV2HQo6sfnqSDZEcK9Cu4TP):
	C3AhZ1bxduDl = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(bnPKxNoAtLQaOC0iSg,gCkRKGhwcx26v(u"ࠬࡧࡤࡥࡱࡱࡷࠬᅷ"),WYGV2HQo6sfnqSDZEcK9Cu4TP,bcNqYtfET5l92dLGjyZSPe(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩᅸ"))
	try: oeBf5xsKV7ID0 = open(C3AhZ1bxduDl,iDhLkZS6XBagNCQfs9tq2(u"ࠧࡳࡤࠪᅹ")).read()
	except:
		nvHOTFshgl7CpXdaQE1tJjrSuB = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(sJY2SoapBKT5dE4MAirZw78G1X,AGlW9LqKN3Dvo(u"ࠨࡣࡧࡨࡴࡴࡳࠨᅺ"),WYGV2HQo6sfnqSDZEcK9Cu4TP,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬᅻ"))
		try: oeBf5xsKV7ID0 = open(nvHOTFshgl7CpXdaQE1tJjrSuB,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡶࡧ࠭ᅼ")).read()
		except: return SebHIf2jL1TBgrMKJu,[]
	if QBOMjKifEAFD: oeBf5xsKV7ID0 = oeBf5xsKV7ID0.decode(Tv08xsf9HOqunIVUPdK1)
	edfFQkBVDGhbS1HYJ7vqO = X2XorVqHjLkWeCchY4u9fSz.findall(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨᅽ"),oeBf5xsKV7ID0,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
	if not edfFQkBVDGhbS1HYJ7vqO: return SebHIf2jL1TBgrMKJu,[]
	logkat81nBD,LzcXtnuWklIy = edfFQkBVDGhbS1HYJ7vqO[wvkDqmNZlJU52isXo],ZFztKMGiCmdNLyewoW4A96TJsf5R(edfFQkBVDGhbS1HYJ7vqO[wvkDqmNZlJU52isXo])
	return logkat81nBD,LzcXtnuWklIy
def LLRmHupxYC2JwINeoc():
	lDp7C13BzOQXIKNRUgxEaH2e = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,czvu7VQCZodkMf(u"ࠬࡪࡩࡤࡶࠪᅾ"),iDhLkZS6XBagNCQfs9tq2(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫᅿ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨᆀ"))
	if lDp7C13BzOQXIKNRUgxEaH2e: return lDp7C13BzOQXIKNRUgxEaH2e
	AMtTYuN2Hfx4r5J,lDp7C13BzOQXIKNRUgxEaH2e = {},{}
	to8rNmXKiC3upgcwnxejvUAy4 = [qFsuKN7ngp.SITESURLS[sTGtHVyhQ9cJU37zxo2O(u"ࠨࡔࡈࡔࡔ࡙ࠧᆁ")][wvkDqmNZlJU52isXo]]
	if zzGetSI9yqnbZh>iDhLkZS6XBagNCQfs9tq2(u"࠱࠸࠰࠼࠽ᗄ"): to8rNmXKiC3upgcwnxejvUAy4.append(qFsuKN7ngp.SITESURLS[iDhLkZS6XBagNCQfs9tq2(u"ࠩࡕࡉࡕࡕࡓࠨᆂ")][nyUIsfd53EGot9vbj0XDeq])
	if QBOMjKifEAFD: to8rNmXKiC3upgcwnxejvUAy4.append(qFsuKN7ngp.SITESURLS[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡖࡊࡖࡏࡔࠩᆃ")][JhTts2R43AxkM8bYanKVy])
	for aa2AKif5RkPQrb6 in to8rNmXKiC3upgcwnxejvUAy4:
		Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡌࡋࡔࠨᆄ"),aa2AKif5RkPQrb6,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,sTGtHVyhQ9cJU37zxo2O(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩᆅ"))
		if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
			YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
			RaWlJbVIOtTUp0 = aa2AKif5RkPQrb6.rsplit(fp6KV7DlS8QYniUczHdmZChL(u"࠭࠯ࠨᆆ"),bcNqYtfET5l92dLGjyZSPe(u"࠲ᗅ"))[wvkDqmNZlJU52isXo]
			H5KwnTUMIAB2bX1FCZ9j83 = X2XorVqHjLkWeCchY4u9fSz.findall(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᆇ"),YD0R1z8ldmipE,X2XorVqHjLkWeCchY4u9fSz.DOTALL|X2XorVqHjLkWeCchY4u9fSz.IGNORECASE)
			for WYGV2HQo6sfnqSDZEcK9Cu4TP,VGRMBzqDLdgE1ujhp0coKFsl in H5KwnTUMIAB2bX1FCZ9j83:
				wP3N7FdsHvAK = RaWlJbVIOtTUp0+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ࠱ࠪᆈ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+AGlW9LqKN3Dvo(u"ࠩ࠲ࠫᆉ")+WYGV2HQo6sfnqSDZEcK9Cu4TP+sTGtHVyhQ9cJU37zxo2O(u"ࠪ࠱ࠬᆊ")+VGRMBzqDLdgE1ujhp0coKFsl+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫ࠳ࢀࡩࡱࠩᆋ")
				if WYGV2HQo6sfnqSDZEcK9Cu4TP not in list(AMtTYuN2Hfx4r5J.keys()):
					AMtTYuN2Hfx4r5J[WYGV2HQo6sfnqSDZEcK9Cu4TP] = []
					lDp7C13BzOQXIKNRUgxEaH2e[WYGV2HQo6sfnqSDZEcK9Cu4TP] = []
				IWZxyR26iNCPSXY1vTfk = ZFztKMGiCmdNLyewoW4A96TJsf5R(VGRMBzqDLdgE1ujhp0coKFsl)
				AMtTYuN2Hfx4r5J[WYGV2HQo6sfnqSDZEcK9Cu4TP].append((VGRMBzqDLdgE1ujhp0coKFsl,IWZxyR26iNCPSXY1vTfk,wP3N7FdsHvAK))
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in list(AMtTYuN2Hfx4r5J.keys()):
		lDp7C13BzOQXIKNRUgxEaH2e[WYGV2HQo6sfnqSDZEcK9Cu4TP] = sorted(AMtTYuN2Hfx4r5J[WYGV2HQo6sfnqSDZEcK9Cu4TP],reverse=BBX9RAuxnyGZ4WIF2TrhYeom3,key=lambda key: key[nyUIsfd53EGot9vbj0XDeq])
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,HCiWF4jV1Q8(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪᆌ"),fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᆍ"),lDp7C13BzOQXIKNRUgxEaH2e,QfG1xIZ4hpq3ezPXt7VbvglUcB)
	return lDp7C13BzOQXIKNRUgxEaH2e
def ZFztKMGiCmdNLyewoW4A96TJsf5R(VGRMBzqDLdgE1ujhp0coKFsl):
	IWZxyR26iNCPSXY1vTfk = []
	eZCry9QiD8 = VGRMBzqDLdgE1ujhp0coKFsl.split(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧ࠯ࠩᆎ"))
	for wOp3mS2saByx1 in eZCry9QiD8:
		lOUt3jiZ4euyAzxVmLDRrv5079kBC = X2XorVqHjLkWeCchY4u9fSz.findall(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ࡞ࡧ࠯ࢁࡡ࡜ࠬ࡞࠰ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࠬᆏ"),wOp3mS2saByx1,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		cnS3aMO4lEXQFWPGfqe = []
		for WWakrdEIqngcLKTuJ4Fyj7Ne3 in lOUt3jiZ4euyAzxVmLDRrv5079kBC:
			if WWakrdEIqngcLKTuJ4Fyj7Ne3.isdigit(): WWakrdEIqngcLKTuJ4Fyj7Ne3 = int(WWakrdEIqngcLKTuJ4Fyj7Ne3)
			cnS3aMO4lEXQFWPGfqe.append(WWakrdEIqngcLKTuJ4Fyj7Ne3)
		IWZxyR26iNCPSXY1vTfk.append(cnS3aMO4lEXQFWPGfqe)
	return IWZxyR26iNCPSXY1vTfk
def POw4nTvZNupIh0zcatX82sg(IWZxyR26iNCPSXY1vTfk):
	VGRMBzqDLdgE1ujhp0coKFsl = SebHIf2jL1TBgrMKJu
	for wOp3mS2saByx1 in IWZxyR26iNCPSXY1vTfk:
		for WWakrdEIqngcLKTuJ4Fyj7Ne3 in wOp3mS2saByx1: VGRMBzqDLdgE1ujhp0coKFsl += str(WWakrdEIqngcLKTuJ4Fyj7Ne3)
		VGRMBzqDLdgE1ujhp0coKFsl += Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩ࠱ࠫᆐ")
	VGRMBzqDLdgE1ujhp0coKFsl = VGRMBzqDLdgE1ujhp0coKFsl.strip(HADrRCz9QgU4xudPJIqYb70(u"ࠪ࠲ࠬᆑ"))
	return VGRMBzqDLdgE1ujhp0coKFsl
def RCHMOS7Qre9bm(jTbhIPnNXKwRtGQOZumSUAFv):
	cjgL0TptRom1DZeFIlC6kM5K = {}
	AMtTYuN2Hfx4r5J = LLRmHupxYC2JwINeoc()
	PPBUm9HAawonq8SgzpNxeJ = YcR81moSla(jTbhIPnNXKwRtGQOZumSUAFv)
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in jTbhIPnNXKwRtGQOZumSUAFv:
		if WYGV2HQo6sfnqSDZEcK9Cu4TP not in list(AMtTYuN2Hfx4r5J.keys()): continue
		lDp7C13BzOQXIKNRUgxEaH2e = AMtTYuN2Hfx4r5J[WYGV2HQo6sfnqSDZEcK9Cu4TP]
		RUj0cvlgXi3GWDmQL4Pp2CkB,ALUNh3HRrOEDu,cf9WryKTdQSim6kaIXJvE = lDp7C13BzOQXIKNRUgxEaH2e[wvkDqmNZlJU52isXo]
		aosTJx4jVAZ08Rrvfp2z,A0doz8gTbeEy63p9PDhN = cDQ0ouAmIeNEwtlf25rs6xbO(WYGV2HQo6sfnqSDZEcK9Cu4TP)
		c2G5evzX8YOLa7V96IUBxPCHM0k,pVrPZglEOYjcBRMnGCxS = PPBUm9HAawonq8SgzpNxeJ[WYGV2HQo6sfnqSDZEcK9Cu4TP]
		bbYqyzCKeIJoOfWFjnrHavT5skZ = ALUNh3HRrOEDu>A0doz8gTbeEy63p9PDhN and c2G5evzX8YOLa7V96IUBxPCHM0k
		fLDQYSwx2chU = BBX9RAuxnyGZ4WIF2TrhYeom3
		if not c2G5evzX8YOLa7V96IUBxPCHM0k: EypiGUg62xbzjB = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᆒ")
		elif not pVrPZglEOYjcBRMnGCxS: EypiGUg62xbzjB = sTGtHVyhQ9cJU37zxo2O(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᆓ")
		elif bbYqyzCKeIJoOfWFjnrHavT5skZ: EypiGUg62xbzjB = wPnfgxKZdAv6T10(u"࠭࡯࡭ࡦࠪᆔ")
		else:
			EypiGUg62xbzjB = wPnfgxKZdAv6T10(u"ࠧࡨࡱࡲࡨࠬᆕ")
			fLDQYSwx2chU = mrhSYXH2P8bO3eJAa9n
		cjgL0TptRom1DZeFIlC6kM5K[WYGV2HQo6sfnqSDZEcK9Cu4TP] = fLDQYSwx2chU,aosTJx4jVAZ08Rrvfp2z,A0doz8gTbeEy63p9PDhN,RUj0cvlgXi3GWDmQL4Pp2CkB,ALUNh3HRrOEDu,EypiGUg62xbzjB,cf9WryKTdQSim6kaIXJvE
	return cjgL0TptRom1DZeFIlC6kM5K
def mm8riWX1U9q(ukn6WYrSGcIORhDeHl2dfw0EMq,hkGm1DZKvfqMx,ZGzgNiY7mdJDSQUOhnrByb8x=SebHIf2jL1TBgrMKJu,qc9JOXgfoV2=SebHIf2jL1TBgrMKJu,dd4ylMxwDUFiz7=SebHIf2jL1TBgrMKJu):
	if psS8dmb912iRBgGc7qOPyCZ6: ukn6WYrSGcIORhDeHl2dfw0EMq.update(hkGm1DZKvfqMx,ZGzgNiY7mdJDSQUOhnrByb8x,qc9JOXgfoV2,dd4ylMxwDUFiz7)
	else: ukn6WYrSGcIORhDeHl2dfw0EMq.update(hkGm1DZKvfqMx,ZGzgNiY7mdJDSQUOhnrByb8x+u43PVWjh7t9YwI+qc9JOXgfoV2+u43PVWjh7t9YwI+dd4ylMxwDUFiz7)
	return
def FFk7B1OjDJzyL3vs4hIY(mMyqAQY70pJCcZSTxWrX2wEGluI):
	def LAMQaGqkWot5rYxz(xaucqoQ1S2NRXlWrvi,aapPBMl1evmfxJkw4T0HhX7,kKL87PVH14ox5=j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠣᆖ")):
		return ((xaucqoQ1S2NRXlWrvi == wvkDqmNZlJU52isXo) and kKL87PVH14ox5[wvkDqmNZlJU52isXo]) or (LAMQaGqkWot5rYxz(xaucqoQ1S2NRXlWrvi // aapPBMl1evmfxJkw4T0HhX7, aapPBMl1evmfxJkw4T0HhX7, kKL87PVH14ox5).lstrip(kKL87PVH14ox5[wvkDqmNZlJU52isXo]) + kKL87PVH14ox5[xaucqoQ1S2NRXlWrvi % aapPBMl1evmfxJkw4T0HhX7])
	def TrFPieNmQskj5(GljkJwe2YnOPLThmKczN9sg, TJfF2PRpZyC5cvj, zt4C1riXE0RfZhKTgyP, OL7InSQdMpsFA0, BNKJCjIUhXifs2tlbxLr37=UTvNakRFQC, QswcKkr0nfHiAqdt=UTvNakRFQC, nYAPfRHmG7S9Ca5LFQt2ui=UTvNakRFQC):
		while (zt4C1riXE0RfZhKTgyP):
			zt4C1riXE0RfZhKTgyP-=czvu7VQCZodkMf(u"࠳ᗆ")
			if (OL7InSQdMpsFA0[zt4C1riXE0RfZhKTgyP]): GljkJwe2YnOPLThmKczN9sg = X2XorVqHjLkWeCchY4u9fSz.sub(ASkvf27etUK0(u"ࠤ࡟ࡠࡧࠨᆗ") + LAMQaGqkWot5rYxz(zt4C1riXE0RfZhKTgyP, TJfF2PRpZyC5cvj) + sTGtHVyhQ9cJU37zxo2O(u"ࠥࡠࡡࡨࠢᆘ"),  OL7InSQdMpsFA0[zt4C1riXE0RfZhKTgyP], GljkJwe2YnOPLThmKczN9sg)
		return GljkJwe2YnOPLThmKczN9sg
	mMyqAQY70pJCcZSTxWrX2wEGluI = mMyqAQY70pJCcZSTxWrX2wEGluI.split(iDhLkZS6XBagNCQfs9tq2(u"ࠫࢂ࠮ࠧᆙ"))[nyUIsfd53EGot9vbj0XDeq]
	mMyqAQY70pJCcZSTxWrX2wEGluI = mMyqAQY70pJCcZSTxWrX2wEGluI.rsplit(bcNqYtfET5l92dLGjyZSPe(u"ࠬࡹࡰ࡭࡫ࡷࠫᆚ"))[wvkDqmNZlJU52isXo]+TVnqDYzWoM2UfHp0dchJ(u"ࠨࡳࡱ࡮࡬ࡸ࠭࠭ࡼࠨࠫࠬࠦᆛ")
	U2576Uz4TvfRDEqX1QidOSI = eval(VOALf8iYEnMdK0g(u"ࠧࡶࡰࡳࡥࡨࡱࠨࠨᆜ")+mMyqAQY70pJCcZSTxWrX2wEGluI,{C3w6qluao7EzUxJgMGBtV(u"ࠨࡤࡤࡷࡪࡔࠧᆝ"):LAMQaGqkWot5rYxz,Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡸࡲࡵࡧࡣ࡬ࠩᆞ"):TrFPieNmQskj5})
	return U2576Uz4TvfRDEqX1QidOSI
def gKhlUrP9zdOG(code):
	_ev5P4h2y8TNsqwdOGA7cp61JMfV3=fp6KV7DlS8QYniUczHdmZChL(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜࠮࠳ࠧᆟ")
	def rtyVZ9YdQhkJq8ni(QswcKkr0nfHiAqdt,BNKJCjIUhXifs2tlbxLr37,b4URFXqy6Dm0NuTwKtVk8Z):
		jr5yNXAYvK = list(_ev5P4h2y8TNsqwdOGA7cp61JMfV3)
		FXimHAoU3WsTjfDznC = jr5yNXAYvK[wPnfgxKZdAv6T10(u"࠳ᗇ"):BNKJCjIUhXifs2tlbxLr37]
		YHnALfql8hprDu = jr5yNXAYvK[HCiWF4jV1Q8(u"࠴ᗈ"):b4URFXqy6Dm0NuTwKtVk8Z]
		QswcKkr0nfHiAqdt = list(QswcKkr0nfHiAqdt)[::-HADrRCz9QgU4xudPJIqYb70(u"࠶ᗉ")]
		SV13WDT8kwsRMbQ9FvYPG = zpx2fPNKk6Ms38eD1vcO(u"࠶ᗊ")
		for zt4C1riXE0RfZhKTgyP,aapPBMl1evmfxJkw4T0HhX7 in enumerate(QswcKkr0nfHiAqdt):
			if aapPBMl1evmfxJkw4T0HhX7 in FXimHAoU3WsTjfDznC: SV13WDT8kwsRMbQ9FvYPG = SV13WDT8kwsRMbQ9FvYPG + FXimHAoU3WsTjfDznC.index(aapPBMl1evmfxJkw4T0HhX7)*BNKJCjIUhXifs2tlbxLr37**zt4C1riXE0RfZhKTgyP
		OL7InSQdMpsFA0 = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠦࠧᆠ")
		while SV13WDT8kwsRMbQ9FvYPG > HCiWF4jV1Q8(u"࠰ᗋ"):
			OL7InSQdMpsFA0 = YHnALfql8hprDu[SV13WDT8kwsRMbQ9FvYPG%b4URFXqy6Dm0NuTwKtVk8Z] + OL7InSQdMpsFA0
			SV13WDT8kwsRMbQ9FvYPG = (SV13WDT8kwsRMbQ9FvYPG - (SV13WDT8kwsRMbQ9FvYPG%b4URFXqy6Dm0NuTwKtVk8Z))//b4URFXqy6Dm0NuTwKtVk8Z
		return int(OL7InSQdMpsFA0) or czvu7VQCZodkMf(u"࠱ᗌ")
	def GGeXsvHNRS2uzCw0YT(FXimHAoU3WsTjfDznC,u,zuZRBycj38NmlOv2F,Hfsgl3nTP2iAOXj5DEMzK8J9apU,BNKJCjIUhXifs2tlbxLr37,nYAPfRHmG7S9Ca5LFQt2ui):
		nYAPfRHmG7S9Ca5LFQt2ui = ASkvf27etUK0(u"ࠧࠨᆡ");
		YHnALfql8hprDu = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠲ᗍ")
		while YHnALfql8hprDu < len(FXimHAoU3WsTjfDznC):
			SV13WDT8kwsRMbQ9FvYPG = wPnfgxKZdAv6T10(u"࠳ᗎ")
			F9FokjuiKTBmgc = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࠢᆢ")
			while FXimHAoU3WsTjfDznC[YHnALfql8hprDu] is not zuZRBycj38NmlOv2F[BNKJCjIUhXifs2tlbxLr37]:
				F9FokjuiKTBmgc = SebHIf2jL1TBgrMKJu.join([F9FokjuiKTBmgc,FXimHAoU3WsTjfDznC[YHnALfql8hprDu]])
				YHnALfql8hprDu = YHnALfql8hprDu + Gykx0wL3XrlWaujsqKP9n2Q(u"࠵ᗏ")
			while SV13WDT8kwsRMbQ9FvYPG < len(zuZRBycj38NmlOv2F):
				F9FokjuiKTBmgc = F9FokjuiKTBmgc.replace(zuZRBycj38NmlOv2F[SV13WDT8kwsRMbQ9FvYPG],str(SV13WDT8kwsRMbQ9FvYPG))
				SV13WDT8kwsRMbQ9FvYPG = SV13WDT8kwsRMbQ9FvYPG + ASkvf27etUK0(u"࠶ᗐ")
			nYAPfRHmG7S9Ca5LFQt2ui = SebHIf2jL1TBgrMKJu.join([nYAPfRHmG7S9Ca5LFQt2ui,SebHIf2jL1TBgrMKJu.join(map(chr, [rtyVZ9YdQhkJq8ni(F9FokjuiKTBmgc,BNKJCjIUhXifs2tlbxLr37,Gykx0wL3XrlWaujsqKP9n2Q(u"࠷࠰ᗑ")) - Hfsgl3nTP2iAOXj5DEMzK8J9apU]))])
			YHnALfql8hprDu = YHnALfql8hprDu + C3w6qluao7EzUxJgMGBtV(u"࠱ᗒ")
		return nYAPfRHmG7S9Ca5LFQt2ui
	code = code.replace(l7kBpMw5Qn(u"ࠧ࡝ࡰࠪᆣ"),SebHIf2jL1TBgrMKJu).replace(zpx2fPNKk6Ms38eD1vcO(u"ࠨ࡞ࡵࠫᆤ"),SebHIf2jL1TBgrMKJu)
	SdeoJ4gRl8O5ErCvKjpmhNP = X2XorVqHjLkWeCchY4u9fSz.findall(uqLUBHepfM3l6AyIzTJh80a(u"ࠩ࡟ࢁࡡ࠮ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭࠱࠮࡜ࡥ࠭ࠬࡠ࠮ࡢࠩࠨᆥ"),code,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if SdeoJ4gRl8O5ErCvKjpmhNP:
		SdeoJ4gRl8O5ErCvKjpmhNP = list(SdeoJ4gRl8O5ErCvKjpmhNP[Ns6AJKH7DGpr19Wl5C3nF(u"࠱ᗓ")])
		for RS6rsgBiCWMacEV9DfJUQpjzZ,code in enumerate(SdeoJ4gRl8O5ErCvKjpmhNP):
			if code.isdigit(): SdeoJ4gRl8O5ErCvKjpmhNP[RS6rsgBiCWMacEV9DfJUQpjzZ] = int(code)
			else: SdeoJ4gRl8O5ErCvKjpmhNP[RS6rsgBiCWMacEV9DfJUQpjzZ] = code.replace(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡠࠧ࠭ᆦ"),SebHIf2jL1TBgrMKJu)
		mmZrqwYy6d5f8InXL09topUeEic = GGeXsvHNRS2uzCw0YT(*SdeoJ4gRl8O5ErCvKjpmhNP)
		return mmZrqwYy6d5f8InXL09topUeEic
	return SebHIf2jL1TBgrMKJu
def PD4hzOB5L7fqKuV8d9mn(pfhH2objgVkI7eycn,jkqVAv5IBawzCZ3Q=SebHIf2jL1TBgrMKJu):
	if jkqVAv5IBawzCZ3Q==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡱࡵࡷࡦࡴࠪᆧ"): pfhH2objgVkI7eycn = X2XorVqHjLkWeCchY4u9fSz.sub(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡆ࠳࡚࡞ࡽ࠵ࢁࠬᆨ"),lambda B6phRCz91a8PFK5JZui0Qtwm: B6phRCz91a8PFK5JZui0Qtwm.group(wvkDqmNZlJU52isXo).lower(),pfhH2objgVkI7eycn)
	elif jkqVAv5IBawzCZ3Q==bcNqYtfET5l92dLGjyZSPe(u"࠭ࡵࡱࡲࡨࡶࠬᆩ"): pfhH2objgVkI7eycn = X2XorVqHjLkWeCchY4u9fSz.sub(AGlW9LqKN3Dvo(u"ࡲࠨࠧ࡞࠴࠲࠿ࡡ࠮ࡼࡠࡿ࠷ࢃࠧᆪ"),lambda B6phRCz91a8PFK5JZui0Qtwm: B6phRCz91a8PFK5JZui0Qtwm.group(wvkDqmNZlJU52isXo).upper(),pfhH2objgVkI7eycn)
	return pfhH2objgVkI7eycn
def YcR81moSla(jTbhIPnNXKwRtGQOZumSUAFv):
	bGn4kfcHWvxeaOSjh3Pidwzq,LlCrcJivEjzYs9u73M4 = mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n
	FFkBWYseogf6EUmRPMy5A = Y7oqZy4HgtlDIxsJ.connect(LL0FBaOIs7DRvzw1Y)
	FFkBWYseogf6EUmRPMy5A.text_factory = str
	BuvcGxfSUokM5EV = FFkBWYseogf6EUmRPMy5A.cursor()
	if len(jTbhIPnNXKwRtGQOZumSUAFv)==nyUIsfd53EGot9vbj0XDeq: U8afVq5u0rJkw6ZyLdWIExKANXC2bg = l7kBpMw5Qn(u"ࠨࠪࠥࠫᆫ")+jTbhIPnNXKwRtGQOZumSUAFv[wvkDqmNZlJU52isXo]+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࠥ࠭ࠬᆬ")
	else: U8afVq5u0rJkw6ZyLdWIExKANXC2bg = str(tuple(jTbhIPnNXKwRtGQOZumSUAFv))
	BuvcGxfSUokM5EV.execute(ASkvf27etUK0(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡪࡴࡡࡣ࡮ࡨࡨࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦࡉࡏࠢࠪᆭ")+U8afVq5u0rJkw6ZyLdWIExKANXC2bg+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࠥࡁࠧᆮ"))
	GYJ52aCZBjbtgLS = BuvcGxfSUokM5EV.fetchall()
	FFkBWYseogf6EUmRPMy5A.close()
	PPBUm9HAawonq8SgzpNxeJ = {}
	for WYGV2HQo6sfnqSDZEcK9Cu4TP in jTbhIPnNXKwRtGQOZumSUAFv: PPBUm9HAawonq8SgzpNxeJ[WYGV2HQo6sfnqSDZEcK9Cu4TP] = (mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	for WYGV2HQo6sfnqSDZEcK9Cu4TP,LlCrcJivEjzYs9u73M4 in GYJ52aCZBjbtgLS:
		bGn4kfcHWvxeaOSjh3Pidwzq = BBX9RAuxnyGZ4WIF2TrhYeom3
		LlCrcJivEjzYs9u73M4 = LlCrcJivEjzYs9u73M4==nyUIsfd53EGot9vbj0XDeq
		PPBUm9HAawonq8SgzpNxeJ[WYGV2HQo6sfnqSDZEcK9Cu4TP] = (bGn4kfcHWvxeaOSjh3Pidwzq,LlCrcJivEjzYs9u73M4)
	return PPBUm9HAawonq8SgzpNxeJ
def Pvf1zMmXRJnipdHDbFeV4r(AAtipVkQ9I2qJDo):
	lfZmugQCFKLGT05AH29IsMiho = SebHIf2jL1TBgrMKJu
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(AAtipVkQ9I2qJDo):
		zOWDhrxp8XRV5jFuT1 = open(AAtipVkQ9I2qJDo,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡸࡢࠨᆯ")).read()
		if QBOMjKifEAFD: zOWDhrxp8XRV5jFuT1 = zOWDhrxp8XRV5jFuT1.decode(Tv08xsf9HOqunIVUPdK1)
		OOkCVz5M8JRsGbjxvKuI = xjVJ0o7mF86tCDagkbNcrTAR4UH(C3w6qluao7EzUxJgMGBtV(u"࠭ࡤࡪࡥࡷࠫᆰ"),zOWDhrxp8XRV5jFuT1)
		if OOkCVz5M8JRsGbjxvKuI:
			lfZmugQCFKLGT05AH29IsMiho = {}
			for BXCThrgedxOyF2N in OOkCVz5M8JRsGbjxvKuI.keys():
				lfZmugQCFKLGT05AH29IsMiho[BXCThrgedxOyF2N] = []
				for ZY5mU1H4MJg8ESVjWIbOeCsuG6 in OOkCVz5M8JRsGbjxvKuI[BXCThrgedxOyF2N]:
					kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
					kpiJl1MHXD5 = ZY5mU1H4MJg8ESVjWIbOeCsuG6[wvkDqmNZlJU52isXo]
					r7h8wgIzXZkaDTVqB5tOS3n = ZY5mU1H4MJg8ESVjWIbOeCsuG6[nyUIsfd53EGot9vbj0XDeq]
					r7h8wgIzXZkaDTVqB5tOS3n = wpbqld5hCR72i6cWNeQI(r7h8wgIzXZkaDTVqB5tOS3n)
					pfhH2objgVkI7eycn = ZY5mU1H4MJg8ESVjWIbOeCsuG6[JhTts2R43AxkM8bYanKVy]
					A9x6WFVrq3cG8 = ZY5mU1H4MJg8ESVjWIbOeCsuG6[fuCbjVag7vU908J2Yqx5Th]
					i3iEyeZ8BQmpDNornRVxTzwdYcX7 = ZY5mU1H4MJg8ESVjWIbOeCsuG6[K7cnfQMS6BPvI4LGmCsRp8bUlJ9]
					Q8A5HyT1fGNxZv4X3V7eC = ZY5mU1H4MJg8ESVjWIbOeCsuG6[zpx2fPNKk6Ms38eD1vcO(u"࠷ᗔ")]
					if len(ZY5mU1H4MJg8ESVjWIbOeCsuG6)>czvu7VQCZodkMf(u"࠹ᗕ"): sLjle5myuEXSiFHJ = ZY5mU1H4MJg8ESVjWIbOeCsuG6[czvu7VQCZodkMf(u"࠹ᗕ")]
					if len(ZY5mU1H4MJg8ESVjWIbOeCsuG6)>NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠻ᗖ"): QdZVWe64OSKPfuXnz81m2qoHAJID = ZY5mU1H4MJg8ESVjWIbOeCsuG6[NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠻ᗖ")]
					if len(ZY5mU1H4MJg8ESVjWIbOeCsuG6)>NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠽ᗗ"): q0HoRKzxwkDFaj3P8r19JBTIACM = ZY5mU1H4MJg8ESVjWIbOeCsuG6[NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠽ᗗ")]
					if AAtipVkQ9I2qJDo==NnA1JBy7DVvFqcm: fc7B6843Pyw2MWhp5ZHT91ArzNOu = kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,SebHIf2jL1TBgrMKJu,q0HoRKzxwkDFaj3P8r19JBTIACM
					else: fc7B6843Pyw2MWhp5ZHT91ArzNOu = kpiJl1MHXD5,r7h8wgIzXZkaDTVqB5tOS3n,pfhH2objgVkI7eycn,A9x6WFVrq3cG8,i3iEyeZ8BQmpDNornRVxTzwdYcX7,Q8A5HyT1fGNxZv4X3V7eC,sLjle5myuEXSiFHJ,QdZVWe64OSKPfuXnz81m2qoHAJID,q0HoRKzxwkDFaj3P8r19JBTIACM
					lfZmugQCFKLGT05AH29IsMiho[BXCThrgedxOyF2N].append(fc7B6843Pyw2MWhp5ZHT91ArzNOu)
		WCdaRXT1Kty2vmHOkNgbo7zcMp = str(lfZmugQCFKLGT05AH29IsMiho)
		if QBOMjKifEAFD: WCdaRXT1Kty2vmHOkNgbo7zcMp = WCdaRXT1Kty2vmHOkNgbo7zcMp.encode(Tv08xsf9HOqunIVUPdK1)
		open(AAtipVkQ9I2qJDo,AGlW9LqKN3Dvo(u"ࠧࡸࡤࠪᆱ")).write(WCdaRXT1Kty2vmHOkNgbo7zcMp)
	return lfZmugQCFKLGT05AH29IsMiho
def t75SIGFhEMn0WUOCr2be(GJ4kbYnxcHa6NIOuA7X20S):
	ZHQM345iJfFqrhl6tuCB2jnSVzgIU = GJ4kbYnxcHa6NIOuA7X20S.split(gCkRKGhwcx26v(u"ࠨ࠯ࠪᆲ"),nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
	o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	if   ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HCiWF4jV1Q8(u"ࠩࡄࡌ࡜ࡇࡋࠨᆳ")		:	from bfvqBlEGW5			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HADrRCz9QgU4xudPJIqYb70(u"ࠪࡅࡐࡕࡁࡎࠩᆴ")		:	from jfzyS623rk			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ᆵ")	:	from wOmCMclVWB		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡇࡋࡘࡃࡐࠫᆶ")		:	from J0TSd9lzne			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩᆷ")	:	from wLSKMh73e4		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HCiWF4jV1Q8(u"ࠧࡂࡎࡄࡖࡆࡈࠧᆸ")	:	from ffL8VwNjxy			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==czvu7VQCZodkMf(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪᆹ")	:	from JNFVbshDcf		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬᆺ")	: 	from X0kQBg9cfI		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬᆻ")	:	from XX3OPvtWYM		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬᆼ")	:	from N8HpKFGYOL		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==bcNqYtfET5l92dLGjyZSPe(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧᆽ")	:	from BBMpA2NRw6		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==DQIrVcKuY6bJv(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫᆾ"):	from fYTWMhpk9R	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==iDhLkZS6XBagNCQfs9tq2(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩᆿ")	:	from D0DGvxVLgT		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡃ࡜ࡐࡔࡒࠧᇀ")		:	from MmDlbAO65u			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡅࡓࡐࡘࡁࠨᇁ")		:	from EMk7P3BKnp			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪᇂ")	:	from ygktil4CVG			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==bcNqYtfET5l92dLGjyZSPe(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬᇃ")	:	from H6F2oWVZj5		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬᇄ")	:	from XMFUBuRInE			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HADrRCz9QgU4xudPJIqYb70(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᇅ")	:	from kf8r3A4UXW			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᇆ")	:	from xi7b4vsFgq		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪᇇ")	:	from XX5FsMNao2		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HADrRCz9QgU4xudPJIqYb70(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨᇈ"):	from F6JLP5TgK7	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᇉ")	:	from EGDQkbSZsa		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᇊ")	:	from JzOxDwfjm3		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==wPnfgxKZdAv6T10(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧᇋ")	:	from eJl1xtrYaB		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᇌ")	:	from rqBzRViAKf		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==TVnqDYzWoM2UfHp0dchJ(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᇍ")	:	from VuHZ1fDQWL		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==l7kBpMw5Qn(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪᇎ")	:	from MV7qIKhwtc		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==bcNqYtfET5l92dLGjyZSPe(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧᇏ"):	from LOYM9FRZic	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ᇐ")	:	from xSMYJe5EB7		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ALwOspNtXxZrz3PEKku(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬᇑ")	:	from tt4rXiPs6G		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ALwOspNtXxZrz3PEKku(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭ᇒ")	:	from TG1X8oLmnQ		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᇓ")	:	from T2QqUJnS8H		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩᇔ")	:	from TaQRkKxj2g		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HADrRCz9QgU4xudPJIqYb70(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪᇕ")	:	from haioEsrFGP		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫᇖ")	:	from FZ0UnMWjif		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫᇗ")	:	from Wg1w6PDOTM		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫᇘ")	:	from gSEqy9T4w0			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧᇙ")	:	from adZLi6KzIx		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==iDhLkZS6XBagNCQfs9tq2(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩᇚ")	:	from AoJ7fIYSsj		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==zpx2fPNKk6Ms38eD1vcO(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨᇛ")	:	from vcL86XGfwU		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==wPnfgxKZdAv6T10(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫᇜ")	:	from F9nBjhuEOm		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪᇝ")	:	from xhYRTP1dvj		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᇞ")	:	from yh9xFYzrNZ		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==TVnqDYzWoM2UfHp0dchJ(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ᇟ")	:	from Doy2bi5zOk		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==bcNqYtfET5l92dLGjyZSPe(u"ࠬࡌࡏࡔࡖࡄࠫᇠ")		:	from PPB7RdE24O			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧᇡ")	:	from LwWGMHUh8n		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩᇢ")	:	from R6uLWgeHfC		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HCiWF4jV1Q8(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭ᇣ"):	from ZiBsPv4g2j	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HCiWF4jV1Q8(u"ࠩࡊࡓࡔࡍࡌࡆࡕࡈࡅࡗࡉࡈࠨᇤ"):	from GQ2Kyq8Cbr	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬᇥ")	:	from XgVe3m4TCJ		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ALwOspNtXxZrz3PEKku(u"ࠫࡎࡌࡉࡍࡏࠪᇦ")		:	from spYHOU52VM			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡏࡐࡕࡘࠪᇧ")		:	from EEMpr2e8JS			import v5bLpYrNEozxBaR3cJyV as o6aYtV2fpKOCDJ,Iyzm1FgGlSh0qUXVQCAHWbk3249JR as bbdzlgnS4vI7oK8puT3fBeO50,f7FNoaT5AZL0VhnP as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==DQIrVcKuY6bJv(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩᇨ")	:	from R2KspmfUn8		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==czvu7VQCZodkMf(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩᇩ")	:	from IVBDouiWYK		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪᇪ")	:	from G1GWzZQI8f		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==czvu7VQCZodkMf(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪᇫ")	:	from AAvU5T6BIn		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==czvu7VQCZodkMf(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪᇬ")	:	from dlA5NILmGB			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==TVnqDYzWoM2UfHp0dchJ(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬᇭ")	:	from VXQT3RqZaD		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==wPnfgxKZdAv6T10(u"ࠬࡓ࠳ࡖࠩᇮ")		:	from EyOjQWPXlY			import v5bLpYrNEozxBaR3cJyV as o6aYtV2fpKOCDJ,Iyzm1FgGlSh0qUXVQCAHWbk3249JR as bbdzlgnS4vI7oK8puT3fBeO50,f7FNoaT5AZL0VhnP as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==DQIrVcKuY6bJv(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩᇯ")	:	from ggp1Z20Evh		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ALwOspNtXxZrz3PEKku(u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧᇰ")	:	from UYBLflSimt			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==C3w6qluao7EzUxJgMGBtV(u"ࠨࡏ࡜ࡇࡎࡓࡁࠨᇱ")	:	from I84IR9qnDj			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡓࡅࡓࡋࡔࠨᇲ")		:	from n3GUDNM79i			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ASkvf27etUK0(u"ࠪࡕࡋࡏࡌࡎࠩᇳ")		:	from tjFgsLbCD6			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==ASkvf27etUK0(u"ࠫࡘࡋࡒࡊࡇࡖࡘࡎࡓࡅࠨᇴ"):	from ZHE2r51JCg		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==bcNqYtfET5l92dLGjyZSPe(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨᇵ")	:	from rXVui3lN8g		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᇶ")	:	from WV2cSYoQT9		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪᇷ")	:	from nUpSzh6lqe		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬᇸ"):	from SxHOckoamj		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬᇹ")	:	from U2Up4T85rl		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==zpx2fPNKk6Ms38eD1vcO(u"ࠪࡗࡍࡕࡆࡉࡃࠪᇺ")	:	from G4Habmw8jS			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ᇻ")	:	from llSEcGkxRp		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==HCiWF4jV1Q8(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧᇼ")	:	from F80OPtmueW		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==C3w6qluao7EzUxJgMGBtV(u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨᇽ")	:	from PvpBUt5MyF		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧᇾ")	:	from ybO16tl9fd			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠨࡖ࡙ࡊ࡚ࡔࠧᇿ")		:	from UAoEVCRMqT			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==DQIrVcKuY6bJv(u"࡙ࠩࡅࡗࡈࡏࡏࠩሀ")	:	from uuXPkzDrSo			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==xxRyYsrSCzjifvH4cIqgldeOo(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧሁ"):	from vXkLjpWP62		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬሂ")	:	from jyIU01FHNn		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==zpx2fPNKk6Ms38eD1vcO(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ሃ")	:	from xmFMAqLGnz		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==vMhFypGLHZJbdX4O7oc3W8x(u"࡙࠭ࡂࡓࡒࡘࠬሄ")		:	from WYz6Zvmtn8			import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==fp6KV7DlS8QYniUczHdmZChL(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨህ")	:	from QGRlAM7x6h		import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	elif ZHQM345iJfFqrhl6tuCB2jnSVzgIU==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧሆ"):	from zbrxR9FMiX	import EEXPfIxMNny1QzZt6gKkA as o6aYtV2fpKOCDJ,yEPLitfHnvAdz0I9SVoC as bbdzlgnS4vI7oK8puT3fBeO50,FFe0IfYj65szqgLHkNpBPJnRQEmZo as RTtiozFdb3kamGMqwcL4EgCyAhOS
	return o6aYtV2fpKOCDJ,bbdzlgnS4vI7oK8puT3fBeO50,RTtiozFdb3kamGMqwcL4EgCyAhOS
def VUchIzntr5E(yybRlA0YcZIGSJ2szD,gTnyji0CwRW81,showDialogs):
	z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,ALwOspNtXxZrz3PEKku(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧሇ")+yybRlA0YcZIGSJ2szD+HCiWF4jV1Q8(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ለ")+str(gTnyji0CwRW81)+VOALf8iYEnMdK0g(u"ࠫࠥࡣࠧሉ"))
	ukn6WYrSGcIORhDeHl2dfw0EMq = fy567LYZh4gGdeSJN()
	ukn6WYrSGcIORhDeHl2dfw0EMq.create(lFEvMxzSH2y7tYR,TVnqDYzWoM2UfHp0dchJ(u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧሊ"))
	A4d05PotiJvVZwaWjELn = DQIrVcKuY6bJv(u"࠷࠰࠳࠶ᗘ")*DQIrVcKuY6bJv(u"࠷࠰࠳࠶ᗘ")
	ZupUP01bDhkxm8MiFadJ7QBEY = l7kBpMw5Qn(u"࠱ᗙ")*A4d05PotiJvVZwaWjELn
	import requests as GQHhfr5kocClg6
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = GQHhfr5kocClg6.get(yybRlA0YcZIGSJ2szD,stream=BBX9RAuxnyGZ4WIF2TrhYeom3,headers=gTnyji0CwRW81)
	P8UfQXnK0TVWbDdiJB = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie.close()
	HudeJ6E1Vv5mIbqnXAr8whBNa = bytes()
	if not P8UfQXnK0TVWbDdiJB:
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ALwOspNtXxZrz3PEKku(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩላ"))
		ukn6WYrSGcIORhDeHl2dfw0EMq.close()
	else:
		if bcNqYtfET5l92dLGjyZSPe(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨሌ") not in list(P8UfQXnK0TVWbDdiJB.keys()): LEkt3G4KCNjFqHhinlpZDMaTIQVu = wvkDqmNZlJU52isXo
		else: LEkt3G4KCNjFqHhinlpZDMaTIQVu = int(P8UfQXnK0TVWbDdiJB[ALwOspNtXxZrz3PEKku(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩል")])
		ILuE0g786D9e2YWiNGTm = str(int(TVnqDYzWoM2UfHp0dchJ(u"࠳࠳࠴࠵ᗛ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu/A4d05PotiJvVZwaWjELn)/ALwOspNtXxZrz3PEKku(u"࠲࠲࠳࠴࠳࠶ᗚ"))
		oXgY1PJ2SjTxN5Uz6 = int(LEkt3G4KCNjFqHhinlpZDMaTIQVu/ZupUP01bDhkxm8MiFadJ7QBEY)+nyUIsfd53EGot9vbj0XDeq
		if j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩሎ") in list(P8UfQXnK0TVWbDdiJB.keys()) and LEkt3G4KCNjFqHhinlpZDMaTIQVu>A4d05PotiJvVZwaWjELn:
			BM8LxO3yITQjwiaDuUqVN5o = BBX9RAuxnyGZ4WIF2TrhYeom3
			jsiZ3kNT0obLMthS = []
			PfWDI0xHn6gZE73pvi = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠴࠴ᗜ")
			jsiZ3kNT0obLMthS.append(str(wvkDqmNZlJU52isXo*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+zpx2fPNKk6Ms38eD1vcO(u"ࠪ࠱ࠬሏ")+str(nyUIsfd53EGot9vbj0XDeq*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(nyUIsfd53EGot9vbj0XDeq*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࠲࠭ሐ")+str(JhTts2R43AxkM8bYanKVy*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(JhTts2R43AxkM8bYanKVy*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬ࠳ࠧሑ")+str(fuCbjVag7vU908J2Yqx5Th*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(fuCbjVag7vU908J2Yqx5Th*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+VOALf8iYEnMdK0g(u"࠭࠭ࠨሒ")+str(K7cnfQMS6BPvI4LGmCsRp8bUlJ9*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(K7cnfQMS6BPvI4LGmCsRp8bUlJ9*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧ࠮ࠩሓ")+str(HADrRCz9QgU4xudPJIqYb70(u"࠹ᗝ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(Ns6AJKH7DGpr19Wl5C3nF(u"࠺ᗞ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨ࠯ࠪሔ")+str(sTGtHVyhQ9cJU37zxo2O(u"࠼ᗟ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(zpx2fPNKk6Ms38eD1vcO(u"࠷ᗡ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+Ns6AJKH7DGpr19Wl5C3nF(u"ࠩ࠰ࠫሕ")+str(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠷ᗠ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(Ns6AJKH7DGpr19Wl5C3nF(u"࠺ᗣ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪ࠱ࠬሖ")+str(Ns6AJKH7DGpr19Wl5C3nF(u"࠺ᗢ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(xxRyYsrSCzjifvH4cIqgldeOo(u"࠽ᗥ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫ࠲࠭ሗ")+str(Ns6AJKH7DGpr19Wl5C3nF(u"࠽ᗤ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi-nyUIsfd53EGot9vbj0XDeq))
			jsiZ3kNT0obLMthS.append(str(Gykx0wL3XrlWaujsqKP9n2Q(u"࠿ᗦ")*LEkt3G4KCNjFqHhinlpZDMaTIQVu//PfWDI0xHn6gZE73pvi)+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࠳ࠧመ"))
			G8nPHwFsXA = float(oXgY1PJ2SjTxN5Uz6)/PfWDI0xHn6gZE73pvi
			Etvi9r5PauDX37FTWOn10Qm6sdpj = G8nPHwFsXA/int(nyUIsfd53EGot9vbj0XDeq+G8nPHwFsXA)
		else:
			BM8LxO3yITQjwiaDuUqVN5o = mrhSYXH2P8bO3eJAa9n
			PfWDI0xHn6gZE73pvi = nyUIsfd53EGot9vbj0XDeq
			Etvi9r5PauDX37FTWOn10Qm6sdpj = nyUIsfd53EGot9vbj0XDeq
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,Ns6AJKH7DGpr19Wl5C3nF(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧሙ")+str(BM8LxO3yITQjwiaDuUqVN5o)+zpx2fPNKk6Ms38eD1vcO(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩሚ")+str(LEkt3G4KCNjFqHhinlpZDMaTIQVu)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࠢࡠࠫማ"))
		XM3KUmO1QJxlv84bgFTHsjdNt0kYq,BPuAN0e6OpodLRzU4ymcqgYW7rQ = wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
		for iIdLcnW1m53wqCe in range(PfWDI0xHn6gZE73pvi):
			REIkboX9NtlZCSU3A = gTnyji0CwRW81.copy()
			if BM8LxO3yITQjwiaDuUqVN5o: REIkboX9NtlZCSU3A[tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࡕࡥࡳ࡭ࡥࠨሜ")] = Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪም")+jsiZ3kNT0obLMthS[iIdLcnW1m53wqCe]
			Vq3XpLGKo4zlSR59wBrhjAbcamJDie = GQHhfr5kocClg6.get(yybRlA0YcZIGSJ2szD,stream=BBX9RAuxnyGZ4WIF2TrhYeom3,headers=REIkboX9NtlZCSU3A,timeout=v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠳࠱࠲ᗧ"))
			for X3XhpY6kJxltvWaPnHBDAdK9yUMTew in Vq3XpLGKo4zlSR59wBrhjAbcamJDie.iter_content(chunk_size=ZupUP01bDhkxm8MiFadJ7QBEY):
				if ukn6WYrSGcIORhDeHl2dfw0EMq.iscanceled():
					z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫሞ"))
					break
				XM3KUmO1QJxlv84bgFTHsjdNt0kYq += Etvi9r5PauDX37FTWOn10Qm6sdpj
				HudeJ6E1Vv5mIbqnXAr8whBNa += X3XhpY6kJxltvWaPnHBDAdK9yUMTew
				if not BPuAN0e6OpodLRzU4ymcqgYW7rQ: BPuAN0e6OpodLRzU4ymcqgYW7rQ = len(X3XhpY6kJxltvWaPnHBDAdK9yUMTew)
				if LEkt3G4KCNjFqHhinlpZDMaTIQVu: mm8riWX1U9q(ukn6WYrSGcIORhDeHl2dfw0EMq,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠲࠲࠳ᗨ")*XM3KUmO1QJxlv84bgFTHsjdNt0kYq//oXgY1PJ2SjTxN5Uz6,sTGtHVyhQ9cJU37zxo2O(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ሟ"),str(fp6KV7DlS8QYniUczHdmZChL(u"࠳࠳࠴࠳࠶ᗩ")*BPuAN0e6OpodLRzU4ymcqgYW7rQ*XM3KUmO1QJxlv84bgFTHsjdNt0kYq//ZupUP01bDhkxm8MiFadJ7QBEY//fp6KV7DlS8QYniUczHdmZChL(u"࠳࠳࠴࠳࠶ᗩ"))+uqLUBHepfM3l6AyIzTJh80a(u"࠭ࠠ࠰ࠢࠪሠ")+ILuE0g786D9e2YWiNGTm+TVnqDYzWoM2UfHp0dchJ(u"ࠧࠡࡏࡅࠫሡ"))
				else: mm8riWX1U9q(ukn6WYrSGcIORhDeHl2dfw0EMq,BPuAN0e6OpodLRzU4ymcqgYW7rQ*XM3KUmO1QJxlv84bgFTHsjdNt0kYq//ZupUP01bDhkxm8MiFadJ7QBEY,TVnqDYzWoM2UfHp0dchJ(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ሢ"),str(qeYIw0BNTL9bGJnosacQ1DtVR(u"࠴࠴࠵࠴࠰ᗪ")*BPuAN0e6OpodLRzU4ymcqgYW7rQ*XM3KUmO1QJxlv84bgFTHsjdNt0kYq//ZupUP01bDhkxm8MiFadJ7QBEY//qeYIw0BNTL9bGJnosacQ1DtVR(u"࠴࠴࠵࠴࠰ᗪ"))+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࠣࡑࡇ࠭ሣ"))
			Vq3XpLGKo4zlSR59wBrhjAbcamJDie.close()
		ukn6WYrSGcIORhDeHl2dfw0EMq.close()
		if len(HudeJ6E1Vv5mIbqnXAr8whBNa)<LEkt3G4KCNjFqHhinlpZDMaTIQVu and LEkt3G4KCNjFqHhinlpZDMaTIQVu>wvkDqmNZlJU52isXo:
			z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭ሤ")+str(len(HudeJ6E1Vv5mIbqnXAr8whBNa)//A4d05PotiJvVZwaWjELn)+HADrRCz9QgU4xudPJIqYb70(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩሥ")+ILuE0g786D9e2YWiNGTm+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠦࡍࡃࠢࡠࠫሦ"))
			x5BZ9SJfFAWV743cgCvoUamse = omIUAxNupsBHY0SGnJXzijltOyV(SebHIf2jL1TBgrMKJu,xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫሧ"),ALwOspNtXxZrz3PEKku(u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧረ"),AGlW9LqKN3Dvo(u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪሩ"),lFEvMxzSH2y7tYR,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭ሪ")+str(len(HudeJ6E1Vv5mIbqnXAr8whBNa)//A4d05PotiJvVZwaWjELn)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩራ")+ILuE0g786D9e2YWiNGTm+wPnfgxKZdAv6T10(u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭ሬ"))
			if x5BZ9SJfFAWV743cgCvoUamse==JhTts2R43AxkM8bYanKVy: HudeJ6E1Vv5mIbqnXAr8whBNa = VUchIzntr5E(yybRlA0YcZIGSJ2szD,gTnyji0CwRW81,showDialogs)
			elif x5BZ9SJfFAWV743cgCvoUamse==nyUIsfd53EGot9vbj0XDeq: z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,ASkvf27etUK0(u"ࠬ࠴࡜ࡵࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫር"))
			else: return SebHIf2jL1TBgrMKJu
			if not HudeJ6E1Vv5mIbqnXAr8whBNa: return SebHIf2jL1TBgrMKJu
		else: z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,bcNqYtfET5l92dLGjyZSPe(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪሮ")+ILuE0g786D9e2YWiNGTm+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࠡࡏࡅࠤࡢ࠭ሯ"))
	return HudeJ6E1Vv5mIbqnXAr8whBNa
def dhSGzo73Ca2(tfX4sO3hy2H1IbKG):
	return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
def H28lnJ4fI3wadG(ip=SebHIf2jL1TBgrMKJu):
	if qFsuKN7ngp.GEOLOCATION_DATA: return qFsuKN7ngp.GEOLOCATION_DATA
	s1suoWBTNcHbRCVFMnDJImx,LHwNEhkMb92Kpf8UtuQTP3a6S,JJgGwtdUfr0jxCkEQ1Luq4cIZb,PxVT0KinrBj4sz7HLkbU6,mVUkEiIa2GKwC,BzrUA83SFft = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	pfhH2objgVkI7eycn = ASkvf27etUK0(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫሰ")+ip+TVnqDYzWoM2UfHp0dchJ(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧሱ")
	gTnyji0CwRW81 = {AGlW9LqKN3Dvo(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧሲ"):SebHIf2jL1TBgrMKJu}
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,gCkRKGhwcx26v(u"ࠫࡌࡋࡔࠨሳ"),pfhH2objgVkI7eycn,SebHIf2jL1TBgrMKJu,gTnyji0CwRW81,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨሴ"))
	if not Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		pfhH2objgVkI7eycn = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱ࠯ࡤࡴ࡮࠴ࡣࡰ࡯࠲࡮ࡸࡵ࡮࠰ࠩስ")+ip+HADrRCz9QgU4xudPJIqYb70(u"ࠧࡀࡨ࡬ࡩࡱࡪࡳ࠾ࡳࡸࡩࡷࡿࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠲ࡣࡪࡶࡼ࠰ࡴ࡬ࡦࡴࡧࡷࠫሶ")
		Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu,uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡉࡈࡘࠬሷ"),pfhH2objgVkI7eycn,SebHIf2jL1TBgrMKJu,gTnyji0CwRW81,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,AGlW9LqKN3Dvo(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠴ࡱࡨࠬሸ"))
	if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
		irF8BHsREyVKtWZLSfgnb65k = ddWZPUnz9Cljm.loads(LCK8lO2yRWaTVEQcdjPXAzpFBe9)
		MsKqD0ELNlZG = list(irF8BHsREyVKtWZLSfgnb65k.keys())
		if czvu7VQCZodkMf(u"ࠪ࡭ࡵ࠭ሹ") in MsKqD0ELNlZG: ip = irF8BHsREyVKtWZLSfgnb65k[bcNqYtfET5l92dLGjyZSPe(u"ࠫ࡮ࡶࠧሺ")]
		if tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨሻ") in MsKqD0ELNlZG: s1suoWBTNcHbRCVFMnDJImx = irF8BHsREyVKtWZLSfgnb65k[Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩሼ")]
		if wPnfgxKZdAv6T10(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨሽ") in MsKqD0ELNlZG: LHwNEhkMb92Kpf8UtuQTP3a6S = irF8BHsREyVKtWZLSfgnb65k[ASkvf27etUK0(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩሾ")]
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨሿ") in MsKqD0ELNlZG: JJgGwtdUfr0jxCkEQ1Luq4cIZb = irF8BHsREyVKtWZLSfgnb65k[C3w6qluao7EzUxJgMGBtV(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩቀ")]
		if czvu7VQCZodkMf(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫቁ") in MsKqD0ELNlZG: PxVT0KinrBj4sz7HLkbU6 = irF8BHsREyVKtWZLSfgnb65k[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬቂ")]
		if wPnfgxKZdAv6T10(u"࠭ࡣࡪࡶࡼࠫቃ") in MsKqD0ELNlZG: mVUkEiIa2GKwC = irF8BHsREyVKtWZLSfgnb65k[l7kBpMw5Qn(u"ࠧࡤ࡫ࡷࡽࠬቄ")]
		if NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡳࡸࡩࡷࡿࠧቅ") in MsKqD0ELNlZG: ip = irF8BHsREyVKtWZLSfgnb65k[wPnfgxKZdAv6T10(u"ࠩࡴࡹࡪࡸࡹࠨቆ")]
		if Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨቇ") in MsKqD0ELNlZG: JJgGwtdUfr0jxCkEQ1Luq4cIZb = irF8BHsREyVKtWZLSfgnb65k[uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩቈ")]
		if Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩ቉") in MsKqD0ELNlZG: PxVT0KinrBj4sz7HLkbU6 = irF8BHsREyVKtWZLSfgnb65k[NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪቊ")]
		if ALwOspNtXxZrz3PEKku(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩቋ") in MsKqD0ELNlZG:
			BzrUA83SFft = irF8BHsREyVKtWZLSfgnb65k[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪቌ")][xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡸࡸࡨ࠭ቍ")]
			if BzrUA83SFft[wvkDqmNZlJU52isXo] not in [czvu7VQCZodkMf(u"ࠪ࠱ࠬ቎"),iDhLkZS6XBagNCQfs9tq2(u"ࠫ࠰࠭቏")]: BzrUA83SFft = iDhLkZS6XBagNCQfs9tq2(u"ࠬ࠱ࠧቐ")+BzrUA83SFft
		if l7kBpMw5Qn(u"࠭࡯ࡧࡨࡶࡩࡹ࠭ቑ") in MsKqD0ELNlZG:
			BzrUA83SFft = irF8BHsREyVKtWZLSfgnb65k[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࡰࡨࡩࡷࡪࡺࠧቒ")]
			if BzrUA83SFft>=t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠴ᗫ"): BzrUA83SFft = zpx2fPNKk6Ms38eD1vcO(u"ࠨ࠭ࠪቓ")+uv8V4fE7j9pmgFr3wnDL.strftime(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠤࠨࡌ࠿ࠫࡍࠣቔ"),uv8V4fE7j9pmgFr3wnDL.gmtime(BzrUA83SFft))
			else: BzrUA83SFft = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪ࠱ࠬቕ")+uv8V4fE7j9pmgFr3wnDL.strftime(HCiWF4jV1Q8(u"ࠦࠪࡎ࠺ࠦࡏࠥቖ"),uv8V4fE7j9pmgFr3wnDL.gmtime(-BzrUA83SFft))
	TuU2RyExd3SMBC = ip+HADrRCz9QgU4xudPJIqYb70(u"ࠬ࠲ࠧ቗")+s1suoWBTNcHbRCVFMnDJImx+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࠬࠨቘ")+LHwNEhkMb92Kpf8UtuQTP3a6S+HADrRCz9QgU4xudPJIqYb70(u"ࠧ࠭ࠩ቙")+PxVT0KinrBj4sz7HLkbU6+bcNqYtfET5l92dLGjyZSPe(u"ࠨ࠮ࠪቚ")+mVUkEiIa2GKwC+ALwOspNtXxZrz3PEKku(u"ࠩ࠯ࠫቛ")+BzrUA83SFft
	TuU2RyExd3SMBC = TuU2RyExd3SMBC.encode(Tv08xsf9HOqunIVUPdK1)
	if QBOMjKifEAFD: TuU2RyExd3SMBC = TuU2RyExd3SMBC.decode(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫቜ"))
	qFsuKN7ngp.GEOLOCATION_DATA = a549mfV8gnzXpwlFr(TuU2RyExd3SMBC)
	return qFsuKN7ngp.GEOLOCATION_DATA
def sKhzPm0oUq7LO3Wk5Q(b19OtBH8hT4GWSZwDRuxiAjX):
	RqosCYQOWJ3jKdiy5Eu0lrHfp12,showDialogs = SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3
	if b19OtBH8hT4GWSZwDRuxiAjX.count(ALwOspNtXxZrz3PEKku(u"ࠫࡤ࠭ቝ"))>=JhTts2R43AxkM8bYanKVy:
		b19OtBH8hT4GWSZwDRuxiAjX,RqosCYQOWJ3jKdiy5Eu0lrHfp12 = b19OtBH8hT4GWSZwDRuxiAjX.split(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡥࠧ቞"),nyUIsfd53EGot9vbj0XDeq)
		RqosCYQOWJ3jKdiy5Eu0lrHfp12 = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭࡟ࠨ቟")+RqosCYQOWJ3jKdiy5Eu0lrHfp12
		if qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬበ") in RqosCYQOWJ3jKdiy5Eu0lrHfp12: showDialogs = mrhSYXH2P8bO3eJAa9n
		else: showDialogs = BBX9RAuxnyGZ4WIF2TrhYeom3
	return b19OtBH8hT4GWSZwDRuxiAjX,RqosCYQOWJ3jKdiy5Eu0lrHfp12,showDialogs
def z5SoD7t0jGaPfR():
	WByRiAujNJ = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧቡ"))
	Fcw9JqUG3RxmO1grdjupQo = wvkDqmNZlJU52isXo
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(WByRiAujNJ):
		for YOaRApygTvD38oLSGqPsBzMCW6w in E2xjtKaMXdC3NDoTm7f5Wkev.listdir(WByRiAujNJ):
			if czvu7VQCZodkMf(u"ࠩ࠱ࡴࡾࡵࠧቢ") in YOaRApygTvD38oLSGqPsBzMCW6w: continue
			if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨባ") in YOaRApygTvD38oLSGqPsBzMCW6w: continue
			jrQko9aChnyI5S6F0tDOY = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(WByRiAujNJ,YOaRApygTvD38oLSGqPsBzMCW6w)
			mdKPiE0tvXrWJSDI8R2fLnC4ho1,C4257GIxAk = q5WoBw7x9sIFDEt(jrQko9aChnyI5S6F0tDOY)
			Fcw9JqUG3RxmO1grdjupQo += mdKPiE0tvXrWJSDI8R2fLnC4ho1
	return Fcw9JqUG3RxmO1grdjupQo
def axEdyXqh0wbVo3s5TS2WBmAM(showDialogs):
	YYbwuvkBZgRXlDerztWFa03simKU9c = MMAUZiw4CoJ8.getSetting(fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩቤ"))
	pUcXIs7y5xlZmvT4dDjK = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡹࡴࡳࠩብ"),zpx2fPNKk6Ms38eD1vcO(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫቦ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩቧ"))
	SuO86iwCVRzgLhGQWZkxj9FqM,TEXOFIu7eU1zg205lN4YnK6JAt3b = YYbwuvkBZgRXlDerztWFa03simKU9c,pUcXIs7y5xlZmvT4dDjK
	SmuXsTiQcy0L7OJpMPNKt,Oq984VWDjZQYUTSlo73i = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	if ASkvf27etUK0(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪቨ") not in str(qFsuKN7ngp.SEND_THESE_EVENTS):
		pfhH2objgVkI7eycn = qFsuKN7ngp.SITESURLS[ASkvf27etUK0(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩቩ")][fuCbjVag7vU908J2Yqx5Th]
		ddP5p4NZtgjFrMnl8vHcLb1kT9VA = H28lnJ4fI3wadG()
		LHwNEhkMb92Kpf8UtuQTP3a6S = ddP5p4NZtgjFrMnl8vHcLb1kT9VA.split(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪ࠰ࠬቪ"))[JhTts2R43AxkM8bYanKVy]
		Fcw9JqUG3RxmO1grdjupQo = z5SoD7t0jGaPfR()
		IbRUyxhZBYz = {l7kBpMw5Qn(u"ࠫࡺࡹࡥࡳࠩቫ"):qFsuKN7ngp.AV_CLIENT_IDS,DQIrVcKuY6bJv(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ቬ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,ASkvf27etUK0(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧቭ"):LHwNEhkMb92Kpf8UtuQTP3a6S,ALwOspNtXxZrz3PEKku(u"ࠧࡪࡦࡶࠫቮ"):Td0evpwjJFMAOa(Fcw9JqUG3RxmO1grdjupQo)}
		Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡒࡒࡗ࡙࠭ቯ"),pfhH2objgVkI7eycn,IbRUyxhZBYz,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ተ"))
		if not Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
			if YYbwuvkBZgRXlDerztWFa03simKU9c in [SebHIf2jL1TBgrMKJu,C3w6qluao7EzUxJgMGBtV(u"ࠪࡒࡊ࡝ࠧቱ")]: SuO86iwCVRzgLhGQWZkxj9FqM = czvu7VQCZodkMf(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቲ")
			elif YYbwuvkBZgRXlDerztWFa03simKU9c==bcNqYtfET5l92dLGjyZSPe(u"ࠬࡕࡌࡅࠩታ"): SuO86iwCVRzgLhGQWZkxj9FqM = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬቴ")
		else:
			iYdHZ25vQXBgjKuRzM = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
			iYdHZ25vQXBgjKuRzM = xjVJ0o7mF86tCDagkbNcrTAR4UH(AGlW9LqKN3Dvo(u"ࠧ࡭࡫ࡶࡸࠬት"),iYdHZ25vQXBgjKuRzM)
			iYdHZ25vQXBgjKuRzM = sorted(iYdHZ25vQXBgjKuRzM,reverse=BBX9RAuxnyGZ4WIF2TrhYeom3,key=lambda key: int(key[wvkDqmNZlJU52isXo]))
			Oq984VWDjZQYUTSlo73i,TEXOFIu7eU1zg205lN4YnK6JAt3b = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
			for mmZrlKJc3uEIi,dfjGy4N6gWtvAl10U,SlMkfbvj8BuRsGydepihKFOHAIL in iYdHZ25vQXBgjKuRzM:
				if mmZrlKJc3uEIi==gCkRKGhwcx26v(u"ࠨ࠲ࠪቶ"):
					Oq984VWDjZQYUTSlo73i += SlMkfbvj8BuRsGydepihKFOHAIL+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ࠽࠾ࠬቷ")
					continue
				if TEXOFIu7eU1zg205lN4YnK6JAt3b: TEXOFIu7eU1zg205lN4YnK6JAt3b += u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+VOALf8iYEnMdK0g(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩቸ")+XOVRfitWJP1zL3p2CMYF+fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡡࡴ࡜࡯ࠩቹ")
				NKJA6YIsv9Qtpy5m4exg8clPwjb = SlMkfbvj8BuRsGydepihKFOHAIL.split(u43PVWjh7t9YwI)[wvkDqmNZlJU52isXo]
				l7lKiwqvUPHZysMfXt = fp6KV7DlS8QYniUczHdmZChL(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩቺ") if dfjGy4N6gWtvAl10U else SebHIf2jL1TBgrMKJu
				TEXOFIu7eU1zg205lN4YnK6JAt3b += SlMkfbvj8BuRsGydepihKFOHAIL.replace(NKJA6YIsv9Qtpy5m4exg8clPwjb,QNR6tCevIGEZKX3rAVsP+NKJA6YIsv9Qtpy5m4exg8clPwjb+l7lKiwqvUPHZysMfXt+XOVRfitWJP1zL3p2CMYF)+u43PVWjh7t9YwI
			TEXOFIu7eU1zg205lN4YnK6JAt3b = u43PVWjh7t9YwI+TEXOFIu7eU1zg205lN4YnK6JAt3b+sTGtHVyhQ9cJU37zxo2O(u"࠭࡜࡯࡞ࡱࠫቻ")
			Oq984VWDjZQYUTSlo73i = Oq984VWDjZQYUTSlo73i.strip(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࠻࠼ࠪቼ"))
			SmuXsTiQcy0L7OJpMPNKt = MMAUZiw4CoJ8.getSetting(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫች"))
			if TEXOFIu7eU1zg205lN4YnK6JAt3b==pUcXIs7y5xlZmvT4dDjK and YYbwuvkBZgRXlDerztWFa03simKU9c in [Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡒࡐࡉ࠭ቾ"),ASkvf27etUK0(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩቿ")]: SuO86iwCVRzgLhGQWZkxj9FqM = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡔࡒࡄࠨኀ")
			else: SuO86iwCVRzgLhGQWZkxj9FqM = AGlW9LqKN3Dvo(u"ࠬࡔࡅࡘࠩኁ")
			pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,gCkRKGhwcx26v(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫኂ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩኃ"),TEXOFIu7eU1zg205lN4YnK6JAt3b,dgvz7toK3Sil1CNUpPOaW58L9uJqY)
			MMAUZiw4CoJ8.setSetting(wPnfgxKZdAv6T10(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩኄ"),Td0evpwjJFMAOa(H3a6hvAgeNctTiXF8d1uELfPr4y))
			MMAUZiw4CoJ8.setSetting(uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬኅ"),Oq984VWDjZQYUTSlo73i)
			epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(sTGtHVyhQ9cJU37zxo2O(u"࠺ᗬ")*Oq984VWDjZQYUTSlo73i.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
			epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(uqLUBHepfM3l6AyIzTJh80a(u"࠷࠴ᗭ")*epc09LarU7XkVgqZjMnRhydH.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
			epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠱࠺ᗮ")*epc09LarU7XkVgqZjMnRhydH.encode(Tv08xsf9HOqunIVUPdK1)).hexdigest()
			FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(E8Eo9FKSM5bhgRYlCWZHqPmt)
			DDs457eAxbRkrgKPHLw(E8Eo9FKSM5bhgRYlCWZHqPmt,FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV,mrhSYXH2P8bO3eJAa9n,ALwOspNtXxZrz3PEKku(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠬኆ")+str(int(epc09LarU7XkVgqZjMnRhydH[l7kBpMw5Qn(u"࠵ᗰ"):Izy1PvclrYx4eSVWn0L5phZbq(u"࠴࠶ᗱ")],wPnfgxKZdAv6T10(u"࠵࠻ᗲ")))[:NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺ᗯ")]+wPnfgxKZdAv6T10(u"ࠫࠥࡁࠧኇ"))
			FFkBWYseogf6EUmRPMy5A.close()
		g0L6UWHnv7s8MtyFpS4ubXxQA3zr9o = BBX9RAuxnyGZ4WIF2TrhYeom3 if Oq984VWDjZQYUTSlo73i!=SmuXsTiQcy0L7OJpMPNKt else mrhSYXH2P8bO3eJAa9n
		if g0L6UWHnv7s8MtyFpS4ubXxQA3zr9o:
			Dlxvp7AgdHXKam3PcUWtwhVIBrkG10 = qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h
			qFsuKN7ngp.ueAEcjiKlYqUV9d6nxXfo2CW,qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h,qFsuKN7ngp.rrhvjIPfCsFXxqwHcQeES8JROG,qFsuKN7ngp.PGAlYK9BwWR,qFsuKN7ngp.avprivsnorestrict,qFsuKN7ngp.avprivslongperiod = YKG71Ft6ZlBHkTIgxEOySX2Qq([cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ኈ"),l7kBpMw5Qn(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ኉"),sTGtHVyhQ9cJU37zxo2O(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬኊ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩኋ"),sTGtHVyhQ9cJU37zxo2O(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡮ࡰࡉ࡜ࡅࡗࡇ࡛ࠫኌ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩኍ")])
			CnJcMtQ7zhuoUG = qFsuKN7ngp.cHRgqtTNOuFn7DwJZ5d0h
			if not Dlxvp7AgdHXKam3PcUWtwhVIBrkG10 and CnJcMtQ7zhuoUG and j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩ኎") in qFsuKN7ngp.SEND_THESE_EVENTS:
				qFsuKN7ngp.SEND_THESE_EVENTS.remove(czvu7VQCZodkMf(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪ኏"))
				qFsuKN7ngp.SEND_THESE_EVENTS.append(NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨነ"))
			elif Dlxvp7AgdHXKam3PcUWtwhVIBrkG10 and not CnJcMtQ7zhuoUG and vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩኑ") in qFsuKN7ngp.SEND_THESE_EVENTS:
				qFsuKN7ngp.SEND_THESE_EVENTS.remove(TVnqDYzWoM2UfHp0dchJ(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪኒ"))
				qFsuKN7ngp.SEND_THESE_EVENTS.append(czvu7VQCZodkMf(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧና"))
			GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	if showDialogs:
		if SuO86iwCVRzgLhGQWZkxj9FqM in [xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩኔ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪን")]:
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,fp6KV7DlS8QYniUczHdmZChL(u"ࠬํๆศๅู้้ࠣไสࠢไ๎ࠥา็ศิๆࠤํํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅีๅ็อ่ࠥฯࠡ์ๆ์๋ࠦำษส๊หࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥอไาษ๋ฮึࠦวๅะสูࠥฮใࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅลึ่ฬฺ้่ࠠา็ࠬኖ"))
		else:
			M8wEz43vLgdl(wPnfgxKZdAv6T10(u"࠭ࡲࡪࡩ࡫ࡸࠬኗ"),HCiWF4jV1Q8(u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪኘ"),TEXOFIu7eU1zg205lN4YnK6JAt3b,VOALf8iYEnMdK0g(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩኙ"))
			SuO86iwCVRzgLhGQWZkxj9FqM = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡒࡐࡉ࠭ኚ")
	if SuO86iwCVRzgLhGQWZkxj9FqM!=YYbwuvkBZgRXlDerztWFa03simKU9c:
		MMAUZiw4CoJ8.setSetting(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨኛ"),SuO86iwCVRzgLhGQWZkxj9FqM)
		GLXqHD847n2jOVZaNEz9mFUIR31x(mrhSYXH2P8bO3eJAa9n)
	return
def ybWszHAnQkBxjVUDJha47(N71BmUdWCthRJbrzXcg08ilSHs5,d5XtyASDoe61):
	import socket as bvtc8KLZV4uRnJh0Q1I7
	Bj32CSnNfeLvGx4E85Hd1iK = bvtc8KLZV4uRnJh0Q1I7.socket(bvtc8KLZV4uRnJh0Q1I7.AF_INET,bvtc8KLZV4uRnJh0Q1I7.SOCK_STREAM)
	Bj32CSnNfeLvGx4E85Hd1iK.settimeout(fuCbjVag7vU908J2Yqx5Th)
	try:
		GhdtAy1o3Ru8z5WvkUFQ6ES = uv8V4fE7j9pmgFr3wnDL.time()
		Bj32CSnNfeLvGx4E85Hd1iK.connect((N71BmUdWCthRJbrzXcg08ilSHs5,d5XtyASDoe61))
		Oag9YZSMIHR = uv8V4fE7j9pmgFr3wnDL.time()
		glTG84M01v2 = round((Oag9YZSMIHR-GhdtAy1o3Ru8z5WvkUFQ6ES)*DQIrVcKuY6bJv(u"࠶࠶࠰࠱ᗳ"))
	except: glTG84M01v2 = -nyUIsfd53EGot9vbj0XDeq
	Bj32CSnNfeLvGx4E85Hd1iK.close()
	return glTG84M01v2
def GGeyKjEOzHdn2I4BkXglo37(showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,zpx2fPNKk6Ms38eD1vcO(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪኜ"))
	else: sLhog1knUIF4fNOjY2zJqQ7cxArb = BBX9RAuxnyGZ4WIF2TrhYeom3
	if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
		for YOaRApygTvD38oLSGqPsBzMCW6w in E2xjtKaMXdC3NDoTm7f5Wkev.listdir(LdX87mwIzyBM):
			if YOaRApygTvD38oLSGqPsBzMCW6w.endswith(fp6KV7DlS8QYniUczHdmZChL(u"ࠬ࠴ࡤࡣࠩኝ")) and j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ࡤࡢࡶࡤࠫኞ") in YOaRApygTvD38oLSGqPsBzMCW6w:
				ttegIyhA5pV0DKZ4CXdLFU = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(LdX87mwIzyBM,YOaRApygTvD38oLSGqPsBzMCW6w)
				FFkBWYseogf6EUmRPMy5A,BuvcGxfSUokM5EV = G2YXQ79epEWqfMO6zlIcHb(ttegIyhA5pV0DKZ4CXdLFU)
				BuvcGxfSUokM5EV.execute(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪኟ"))
				BuvcGxfSUokM5EV.execute(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭አ"))
				BuvcGxfSUokM5EV.execute(Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬኡ"))
				BuvcGxfSUokM5EV.execute(gCkRKGhwcx26v(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ኢ"))
				BuvcGxfSUokM5EV.execute(HADrRCz9QgU4xudPJIqYb70(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬኣ"))
				FFkBWYseogf6EUmRPMy5A.commit()
				FFkBWYseogf6EUmRPMy5A.close()
		if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,C3w6qluao7EzUxJgMGBtV(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ኤ"))
	return
def ko5ymgwaUtVilrPc3jpWhKJ(XrESiZq4TCBHhGAPFne9Rdas3jWpo,iiIdeFSp23tX,showDialogs):
	if XrESiZq4TCBHhGAPFne9Rdas3jWpo!=BdrZqlitGvEM:
		if XrESiZq4TCBHhGAPFne9Rdas3jWpo==HHXhQTUO86ALyZ2JgzbDx907kMvcsp: qFsuKN7ngp.ALLOW_DNS_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
		elif XrESiZq4TCBHhGAPFne9Rdas3jWpo==QxUz8vH0AsPG3OgF: qFsuKN7ngp.ALLOW_DNS_FIX = mrhSYXH2P8bO3eJAa9n
		elif XrESiZq4TCBHhGAPFne9Rdas3jWpo==cXPe6vn1aUtFzH79WEwVmCBO0db: qFsuKN7ngp.ALLOW_DNS_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
	if iiIdeFSp23tX!=BdrZqlitGvEM:
		if iiIdeFSp23tX==HHXhQTUO86ALyZ2JgzbDx907kMvcsp: qFsuKN7ngp.ALLOW_PROXY_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
		elif iiIdeFSp23tX==QxUz8vH0AsPG3OgF: qFsuKN7ngp.ALLOW_PROXY_FIX = mrhSYXH2P8bO3eJAa9n
		elif iiIdeFSp23tX==cXPe6vn1aUtFzH79WEwVmCBO0db: qFsuKN7ngp.ALLOW_PROXY_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
	if showDialogs!=BdrZqlitGvEM:
		if showDialogs==HHXhQTUO86ALyZ2JgzbDx907kMvcsp: qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
		elif showDialogs==QxUz8vH0AsPG3OgF: qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX = mrhSYXH2P8bO3eJAa9n
		elif showDialogs==cXPe6vn1aUtFzH79WEwVmCBO0db: qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX = BBX9RAuxnyGZ4WIF2TrhYeom3
	return
def ntebSIVEDQU(website,IzqYJFrLOnX,KlEtUjAGBZbVrW5X1=UTvNakRFQC):
	xZhHnofNSBC0G = ASkvf27etUK0(u"࠷࠰ᗴ")
	q0O5ExKSGH = [sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),bcNqYtfET5l92dLGjyZSPe(u"࠲࠲ᗶ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠷ᗷ"),bcNqYtfET5l92dLGjyZSPe(u"࠲࠲ᗶ"),sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),sTGtHVyhQ9cJU37zxo2O(u"࠱ᗵ"),vMhFypGLHZJbdX4O7oc3W8x(u"࠷ᗷ")]
	ffeshXj9PYZtqr4DTHNnRAak0x2Cv = []
	VbkcgyWT6eoBNapKm = [iDhLkZS6XBagNCQfs9tq2(u"࠳ᗸ")]*xZhHnofNSBC0G
	kiq6EaTcsQS0pZhmJdoNDglALF4Mb = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,VOALf8iYEnMdK0g(u"࠭ࡤࡪࡥࡷࠫእ"),tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩኦ"))
	for KSF5WbLB14MkvZJ9pX in list(kiq6EaTcsQS0pZhmJdoNDglALF4Mb.keys()):
		if website not in KSF5WbLB14MkvZJ9pX: continue
		GJ4kbYnxcHa6NIOuA7X20S,f1fMdeDEUvPaFZVqpthYrT = KSF5WbLB14MkvZJ9pX.split(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠨࡡࡢࠫኧ"))
		VbkcgyWT6eoBNapKm[int(f1fMdeDEUvPaFZVqpthYrT)] = kiq6EaTcsQS0pZhmJdoNDglALF4Mb[KSF5WbLB14MkvZJ9pX]
	for WTxpgC1F98bcI5Am in range(xZhHnofNSBC0G):
		if WTxpgC1F98bcI5Am in qFsuKN7ngp.BADSCRAPERS+IzqYJFrLOnX: continue
		if WTxpgC1F98bcI5Am==KlEtUjAGBZbVrW5X1: VbkcgyWT6eoBNapKm[WTxpgC1F98bcI5Am] = VbkcgyWT6eoBNapKm[WTxpgC1F98bcI5Am]+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠵ᗹ")
		if VbkcgyWT6eoBNapKm[WTxpgC1F98bcI5Am]<qeYIw0BNTL9bGJnosacQ1DtVR(u"࠸ᗺ"): ffeshXj9PYZtqr4DTHNnRAak0x2Cv += [WTxpgC1F98bcI5Am]*q0O5ExKSGH[WTxpgC1F98bcI5Am]
	if not ffeshXj9PYZtqr4DTHNnRAak0x2Cv:
		for WTxpgC1F98bcI5Am in range(xZhHnofNSBC0G):
			VbkcgyWT6eoBNapKm[WTxpgC1F98bcI5Am] = ASkvf27etUK0(u"࠶ᗻ")
			if WTxpgC1F98bcI5Am in qFsuKN7ngp.BADSCRAPERS+IzqYJFrLOnX: continue
			ffeshXj9PYZtqr4DTHNnRAak0x2Cv += [WTxpgC1F98bcI5Am]*q0O5ExKSGH[WTxpgC1F98bcI5Am]
	for WTxpgC1F98bcI5Am in qFsuKN7ngp.BADSCRAPERS: VbkcgyWT6eoBNapKm[WTxpgC1F98bcI5Am] = iDhLkZS6XBagNCQfs9tq2(u"࠹࠺࠻࠼ᗼ")
	g2gxnrjWtCsK5hizGDR7yfk4NabZ = []
	for WTxpgC1F98bcI5Am in range(xZhHnofNSBC0G): g2gxnrjWtCsK5hizGDR7yfk4NabZ.append(website+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡢࡣࠬከ")+str(WTxpgC1F98bcI5Am))
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,czvu7VQCZodkMf(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬኩ"),g2gxnrjWtCsK5hizGDR7yfk4NabZ,VbkcgyWT6eoBNapKm,mQJAf43IqSPa8HBTxRnL*Izy1PvclrYx4eSVWn0L5phZbq(u"࠶ᗽ"),BBX9RAuxnyGZ4WIF2TrhYeom3)
	return ffeshXj9PYZtqr4DTHNnRAak0x2Cv
def UqgKptMNenkfsTYxFBzGSr(oHSdD2N140BnjWsOk,qg7Nr1dCaD,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,bY3gNleaHWrMKDw=SebHIf2jL1TBgrMKJu,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz=SebHIf2jL1TBgrMKJu,IzqYJFrLOnX=[]):
	website = qh4B9VQZCbXr0DRknFmi7J6.split(NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫ࠲࠭ኪ"))[wvkDqmNZlJU52isXo]
	jPGJ5x23Fzb0QCq7Ol4YMu = ntebSIVEDQU(website,IzqYJFrLOnX)
	CFLcUmZSiEr2QMh9KRqb = []
	if website==v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧካ"):
		if wvkDqmNZlJU52isXo in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [wvkDqmNZlJU52isXo]
		if nyUIsfd53EGot9vbj0XDeq in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [nyUIsfd53EGot9vbj0XDeq]
		if JhTts2R43AxkM8bYanKVy in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [JhTts2R43AxkM8bYanKVy]
		if fuCbjVag7vU908J2Yqx5Th in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [fuCbjVag7vU908J2Yqx5Th]*tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠳࠳ᗾ")
		if K7cnfQMS6BPvI4LGmCsRp8bUlJ9 in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [K7cnfQMS6BPvI4LGmCsRp8bUlJ9]*vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*iDhLkZS6XBagNCQfs9tq2(u"࠴࠴ᗿ")
		if NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺ᘀ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠺ᘀ")]
		if fp6KV7DlS8QYniUczHdmZChL(u"࠼ᘁ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [fp6KV7DlS8QYniUczHdmZChL(u"࠼ᘁ")]
	elif website==zpx2fPNKk6Ms38eD1vcO(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨኬ"):
		if fuCbjVag7vU908J2Yqx5Th in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [fuCbjVag7vU908J2Yqx5Th]*ALwOspNtXxZrz3PEKku(u"࠷࠰ᘂ")
	elif website==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪክ"):
		if K7cnfQMS6BPvI4LGmCsRp8bUlJ9 in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [K7cnfQMS6BPvI4LGmCsRp8bUlJ9]*vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*xxRyYsrSCzjifvH4cIqgldeOo(u"࠱࠱ᘃ")
	elif website==Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩኮ"):
		if sTGtHVyhQ9cJU37zxo2O(u"࠺ᘄ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [sTGtHVyhQ9cJU37zxo2O(u"࠺ᘄ")]*l7kBpMw5Qn(u"࠳࠳ᘅ")
	elif website==j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪኯ"):
		if nyUIsfd53EGot9vbj0XDeq in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [nyUIsfd53EGot9vbj0XDeq]
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠴࠴ᘆ")
	elif website==NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡋࡔࡕࡇࡍࡇࡖࡉࡆࡘࡃࡉࠩኰ"):
		if K7cnfQMS6BPvI4LGmCsRp8bUlJ9 in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [K7cnfQMS6BPvI4LGmCsRp8bUlJ9]*vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
	elif website==Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ኱"):
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*zpx2fPNKk6Ms38eD1vcO(u"࠵࠵ᘇ")
		if tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠻ᘈ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠻ᘈ")]
		if tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠽ᘉ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠽ᘉ")]
		if czvu7VQCZodkMf(u"࠸ᘊ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [czvu7VQCZodkMf(u"࠸ᘊ")]
	elif website==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧኲ"):
		if HCiWF4jV1Q8(u"࠷ᘋ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [HCiWF4jV1Q8(u"࠷ᘋ")]
		if wPnfgxKZdAv6T10(u"࠹ᘌ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [wPnfgxKZdAv6T10(u"࠹ᘌ")]
	elif website==HCiWF4jV1Q8(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨኳ"):
		if nyUIsfd53EGot9vbj0XDeq in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [nyUIsfd53EGot9vbj0XDeq]
		if K7cnfQMS6BPvI4LGmCsRp8bUlJ9 in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [K7cnfQMS6BPvI4LGmCsRp8bUlJ9]*vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠴࠴ᘍ")
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"࠺ᘎ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [ypO63g8oJEsDnPBHSuU7lMTZr(u"࠺ᘎ")]
		if VOALf8iYEnMdK0g(u"࠼ᘏ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [VOALf8iYEnMdK0g(u"࠼ᘏ")]
	elif website==HADrRCz9QgU4xudPJIqYb70(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩኴ"):
		if nyUIsfd53EGot9vbj0XDeq in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [nyUIsfd53EGot9vbj0XDeq]
		if vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs]*VOALf8iYEnMdK0g(u"࠷࠰ᘐ")
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"࠸ᘑ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [ypO63g8oJEsDnPBHSuU7lMTZr(u"࠸ᘑ")]
		if ASkvf27etUK0(u"࠺ᘒ") in jPGJ5x23Fzb0QCq7Ol4YMu: CFLcUmZSiEr2QMh9KRqb += [ASkvf27etUK0(u"࠺ᘒ")]*cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠳࠳ᘓ")
	if CFLcUmZSiEr2QMh9KRqb: jPGJ5x23Fzb0QCq7Ol4YMu = CFLcUmZSiEr2QMh9KRqb
	if jPGJ5x23Fzb0QCq7Ol4YMu:
		Nf3CJoHQOtSGXq4ysc5dPDIWlRB = JO7n9zxwdgIStrTjR.sample(jPGJ5x23Fzb0QCq7Ol4YMu,nyUIsfd53EGot9vbj0XDeq)[wvkDqmNZlJU52isXo]
	else: Nf3CJoHQOtSGXq4ysc5dPDIWlRB = -nyUIsfd53EGot9vbj0XDeq
	dNvtZ0M29TrjR = VOALf8iYEnMdK0g(u"ࠨีํีๆืࠠาไ่ࠤࠬኵ")+str(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)
	z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭኶")+str(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)+ALwOspNtXxZrz3PEKku(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ኷")+str(bY3gNleaHWrMKDw)+HCiWF4jV1Q8(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬኸ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz+sTGtHVyhQ9cJU37zxo2O(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኹ")+qh4B9VQZCbXr0DRknFmi7J6+uqLUBHepfM3l6AyIzTJh80a(u"࠭ࠠ࡞࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫኺ")+qg7Nr1dCaD+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࠡ࡟ࠪኻ"))
	update = BBX9RAuxnyGZ4WIF2TrhYeom3
	if Nf3CJoHQOtSGXq4ysc5dPDIWlRB==wvkDqmNZlJU52isXo:
		scraperserver = zpx2fPNKk6Ms38eD1vcO(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠵ࠬኼ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = TVnqDYzWoM2UfHp0dchJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠱࠶࠲ࡧ࠶࠷࡬࠱࠮ࡥ࠸࠼ࡦ࠳࠴࠱࠴࠴࠱ࡦࡧ࠸࠵࠯ࡨ࠽࠷࠹ࡣࡢࡨ࠻࠹࠽࠹࠴ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫኽ")
		vz42ouckGgElI = qg7Nr1dCaD+czvu7VQCZodkMf(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኾ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ኿")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==nyUIsfd53EGot9vbj0XDeq:
		scraperserver = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠳ࠩዀ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = vMhFypGLHZJbdX4O7oc3W8x(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨ዁")
		vz42ouckGgElI = qg7Nr1dCaD+zpx2fPNKk6Ms38eD1vcO(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧዂ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዃ")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==JhTts2R43AxkM8bYanKVy:
		scraperserver = HCiWF4jV1Q8(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ዄ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࡀ࡭ࡱࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩዅ")
		vz42ouckGgElI = qg7Nr1dCaD+ALwOspNtXxZrz3PEKku(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ዆")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ዇")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==fuCbjVag7vU908J2Yqx5Th:
		scraperserver = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨወ")
		iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD.replace(C3w6qluao7EzUxJgMGBtV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩዉ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩዊ"))
		vz42ouckGgElI = vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴࡪࡻࡰ࠯ࡥࡲࡱ࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠫࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡋࡧ࡬ࡴࡧࠩࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰࠫࡻࡲ࡭࠿ࠪዋ")+xuCTZaNtMVwFs(iGxH2fsuScPtkJb7ECg)
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡋࡊ࡚ࠧዌ"),vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==K7cnfQMS6BPvI4LGmCsRp8bUlJ9:
		scraperserver = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫው")
		vz42ouckGgElI = AGlW9LqKN3Dvo(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵ࠰ࡦࡳࡲ࠵࠿ࡵࡱ࡮ࡩࡳࡃࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠧࡲࡵࡳࡽࡿࡃࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡹࡷࡲ࠽ࠨዎ")+xuCTZaNtMVwFs(qg7Nr1dCaD)
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(ASkvf27etUK0(u"࠭ࡇࡆࡖࠪዏ"),vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
		try:
			aFuIU1RDMv98SkYocqNZCKLGlf.content = xjVJ0o7mF86tCDagkbNcrTAR4UH(VOALf8iYEnMdK0g(u"ࠧࡥ࡫ࡦࡸࠬዐ"),aFuIU1RDMv98SkYocqNZCKLGlf.content)
			aFuIU1RDMv98SkYocqNZCKLGlf.content = aFuIU1RDMv98SkYocqNZCKLGlf.content[j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡴࡨࡷࡺࡲࡴࠨዑ")]
		except: pass
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs:
		scraperserver = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠱ࠨዒ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = l7kBpMw5Qn(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡋࡏࠪࡧࡸ࡯ࡸࡵࡨࡶࡂࡌࡡ࡭ࡵࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨዓ")
		vz42ouckGgElI = qg7Nr1dCaD+C3w6qluao7EzUxJgMGBtV(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫዔ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+ASkvf27etUK0(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዕ")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==AGlW9LqKN3Dvo(u"࠹ᘔ"):
		scraperserver = sTGtHVyhQ9cJU37zxo2O(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠳ࠪዖ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = AGlW9LqKN3Dvo(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫ዗")
		vz42ouckGgElI = qg7Nr1dCaD+bcNqYtfET5l92dLGjyZSPe(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨዘ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩዙ")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==zpx2fPNKk6Ms38eD1vcO(u"࠻ᘕ"):
		scraperserver = iDhLkZS6XBagNCQfs9tq2(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠸ࠧዚ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = ASkvf27etUK0(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨዛ")
		vz42ouckGgElI = qg7Nr1dCaD+iDhLkZS6XBagNCQfs9tq2(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዜ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+C3w6qluao7EzUxJgMGBtV(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ዝ")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==bcNqYtfET5l92dLGjyZSPe(u"࠽ᘖ"):
		scraperserver = vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠶ࠫዞ")
		vz42ouckGgElI = HADrRCz9QgU4xudPJIqYb70(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠯ࡷ࠳࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠦࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩዟ")+xuCTZaNtMVwFs(qg7Nr1dCaD)
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡊࡉ࡙࠭ዠ"),vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	elif Nf3CJoHQOtSGXq4ysc5dPDIWlRB==sTGtHVyhQ9cJU37zxo2O(u"࠿ᘗ"):
		scraperserver = gCkRKGhwcx26v(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠳ࠩዡ")
		W0U8xXcKoiC39FeajkP6Vfr2mSQ = Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡸࡥࡵࡷࡵࡲࡤࡶࡡࡨࡧࡢࡷࡴࡻࡲࡤࡧࡀࡸࡷࡻࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬዢ")
		vz42ouckGgElI = qg7Nr1dCaD+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዣ")+W0U8xXcKoiC39FeajkP6Vfr2mSQ+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ዤ")
		aFuIU1RDMv98SkYocqNZCKLGlf = KXpxBQE2LP(oHSdD2N140BnjWsOk,vz42ouckGgElI,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n)
	else:
		scraperserver,vz42ouckGgElI = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
		aFuIU1RDMv98SkYocqNZCKLGlf = HvawcTdL3fq785XunkRDGE2FP()
		update = mrhSYXH2P8bO3eJAa9n
	TX2kUwOYDuehbzIRaFm3 = (qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡷࡧࡵ࡭࡫ࡿ࠮ࡩࡶࡰࡰࡄࡸࡥࡥ࡫ࡵࡩࡨࡺ࠽ࠨዥ") in qg7Nr1dCaD)
	if TX2kUwOYDuehbzIRaFm3: aFuIU1RDMv98SkYocqNZCKLGlf.succeeded = mrhSYXH2P8bO3eJAa9n
	if update and not aFuIU1RDMv98SkYocqNZCKLGlf.succeeded:
		ntebSIVEDQU(website,[],Nf3CJoHQOtSGXq4ysc5dPDIWlRB)
		if len(list(set(jPGJ5x23Fzb0QCq7Ol4YMu)))>nyUIsfd53EGot9vbj0XDeq:
			sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨๆ็วุ็ࠠิ์ิๅึࠦๅฺษ็ะฮࠦวๅฯฯฬࠥืโๆࠢࠪዦ")+str(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࠣๅู๊ࠠโ์ࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠠ࠯࠰๋้ࠣࠦสา์าࠤ๊ำว้ๆฬࠤฯาว้ิࠣห้ำฬษ่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦำ๋ำไี๋ࠥฮหๆไࠤฤࠧࠧዧ"))
			if sLhog1knUIF4fNOjY2zJqQ7cxArb==nyUIsfd53EGot9vbj0XDeq:
				IzqYJFrLOnX.append(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)
				aFuIU1RDMv98SkYocqNZCKLGlf = UqgKptMNenkfsTYxFBzGSr(oHSdD2N140BnjWsOk,qg7Nr1dCaD,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz,IzqYJFrLOnX)
				return aFuIU1RDMv98SkYocqNZCKLGlf
	aFuIU1RDMv98SkYocqNZCKLGlf.scrapernumber = str(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)
	scraperserver = scraperserver+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࠤ࠿ࠦࠧየ")+str(Nf3CJoHQOtSGXq4ysc5dPDIWlRB)
	aFuIU1RDMv98SkYocqNZCKLGlf.scraperserver = scraperserver
	aFuIU1RDMv98SkYocqNZCKLGlf.scraperurl = vz42ouckGgElI
	if aFuIU1RDMv98SkYocqNZCKLGlf.succeeded:
		z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫዩ")+scraperserver+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዪ")+qh4B9VQZCbXr0DRknFmi7J6+DQIrVcKuY6bJv(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬያ")+qg7Nr1dCaD+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࠡ࡟ࠪዬ"))
		i9yzUqgAW2Zap1h4Lm(ALwOspNtXxZrz3PEKku(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪይ"),dNvtZ0M29TrjR,uv8V4fE7j9pmgFr3wnDL=wPnfgxKZdAv6T10(u"࠱࠱࠲࠳ᘘ"))
	else:
		z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+iDhLkZS6XBagNCQfs9tq2(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ዮ")+scraperserver+Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪዯ")+str(aFuIU1RDMv98SkYocqNZCKLGlf.code)+uqLUBHepfM3l6AyIzTJh80a(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ደ")+aFuIU1RDMv98SkYocqNZCKLGlf.reason+vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዱ")+qh4B9VQZCbXr0DRknFmi7J6+NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬዲ")+qg7Nr1dCaD+HCiWF4jV1Q8(u"ࠧࠡ࡟ࠪዳ"))
		i9yzUqgAW2Zap1h4Lm(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨใื่ฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪዴ"),dNvtZ0M29TrjR,uv8V4fE7j9pmgFr3wnDL=HADrRCz9QgU4xudPJIqYb70(u"࠲࠲࠳࠴ᘙ"))
	return aFuIU1RDMv98SkYocqNZCKLGlf
def ObKau0SHZBTmrRAzeEtfGFUg9vs(pRF2UtDTMJwESfOhPde1y,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,showDialogs,qh4B9VQZCbXr0DRknFmi7J6):
	if not qqTB9mr0Av7jKg3UOYzLl or isinstance(qqTB9mr0Av7jKg3UOYzLl,dict): oHSdD2N140BnjWsOk = TVnqDYzWoM2UfHp0dchJ(u"ࠩࡊࡉ࡙࠭ድ")
	else:
		oHSdD2N140BnjWsOk = gCkRKGhwcx26v(u"ࠪࡔࡔ࡙ࡔࠨዶ")
		qqTB9mr0Av7jKg3UOYzLl = kLEi7mYT5wBM4DHsgWy8(qqTB9mr0Av7jKg3UOYzLl)
		XXaOJtUeolu,qqTB9mr0Av7jKg3UOYzLl = lhC3Axj8TQSsRWeu0k(qqTB9mr0Av7jKg3UOYzLl)
	Vq3XpLGKo4zlSR59wBrhjAbcamJDie = WMx8v0FVCjlhcQKRwdX1s(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,BBX9RAuxnyGZ4WIF2TrhYeom3,showDialogs,qh4B9VQZCbXr0DRknFmi7J6)
	YD0R1z8ldmipE = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
	YD0R1z8ldmipE = str(YD0R1z8ldmipE)
	return YD0R1z8ldmipE
def wwpNDOqdIZuUzTy5b7X(pfhH2objgVkI7eycn):
	fhypxdiRVAkouFq = pfhH2objgVkI7eycn.split(AGlW9LqKN3Dvo(u"ࠫࢁࢂࠧዷ"))
	qg7Nr1dCaD,WMKSy1qfGhFckpTawe2lE5,ooOMXGnTYPA81,sVXdfNbq3va7P = fhypxdiRVAkouFq[wvkDqmNZlJU52isXo],UTvNakRFQC,UTvNakRFQC,BBX9RAuxnyGZ4WIF2TrhYeom3
	for Zth7i2v1xI6TKpcP in fhypxdiRVAkouFq:
		if ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪዸ") in Zth7i2v1xI6TKpcP: WMKSy1qfGhFckpTawe2lE5 = Zth7i2v1xI6TKpcP[AGlW9LqKN3Dvo(u"࠳࠴ᘚ"):]
		elif TVnqDYzWoM2UfHp0dchJ(u"࠭ࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩዹ") in Zth7i2v1xI6TKpcP: ooOMXGnTYPA81 = Zth7i2v1xI6TKpcP[czvu7VQCZodkMf(u"࠼ᘛ"):]
		elif AGlW9LqKN3Dvo(u"ࠧࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዺ") in Zth7i2v1xI6TKpcP: sVXdfNbq3va7P = mrhSYXH2P8bO3eJAa9n
	return qg7Nr1dCaD,WMKSy1qfGhFckpTawe2lE5,ooOMXGnTYPA81,sVXdfNbq3va7P
def bNB21o6HMPshGQFR98x(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,BT6iI7a3vbGM,ETM820OIgWZyRbG,ttnjrL1sNAq9eEhdD3MY,gTnyji0CwRW81=SebHIf2jL1TBgrMKJu):
	o60Fx9LCWq4TdtQgAcikmhbN5w = EDmwsQf1Px9k8h04oAHuObdnyrTGU(pfhH2objgVkI7eycn,czvu7VQCZodkMf(u"ࠨࡷࡵࡰࠬዻ"))
	iBh7RYSxUfWzVa2Jb = MMAUZiw4CoJ8.getSetting(gCkRKGhwcx26v(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫዼ")+BT6iI7a3vbGM)
	if o60Fx9LCWq4TdtQgAcikmhbN5w==iBh7RYSxUfWzVa2Jb: MMAUZiw4CoJ8.setSetting(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬዽ")+BT6iI7a3vbGM,SebHIf2jL1TBgrMKJu)
	if iBh7RYSxUfWzVa2Jb: iGxH2fsuScPtkJb7ECg = pfhH2objgVkI7eycn.replace(o60Fx9LCWq4TdtQgAcikmhbN5w,iBh7RYSxUfWzVa2Jb)
	else:
		iGxH2fsuScPtkJb7ECg = pfhH2objgVkI7eycn
		iBh7RYSxUfWzVa2Jb = o60Fx9LCWq4TdtQgAcikmhbN5w
	ooSekfpJr7jAgbXIT = WMx8v0FVCjlhcQKRwdX1s(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,iGxH2fsuScPtkJb7ECg,SebHIf2jL1TBgrMKJu,gTnyji0CwRW81,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨዾ"))
	YD0R1z8ldmipE = ooSekfpJr7jAgbXIT.content
	if QBOMjKifEAFD:
		try: YD0R1z8ldmipE = YD0R1z8ldmipE.decode(Tv08xsf9HOqunIVUPdK1,wPnfgxKZdAv6T10(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬዿ"))
		except: pass
	if not ooSekfpJr7jAgbXIT.succeeded or ttnjrL1sNAq9eEhdD3MY not in YD0R1z8ldmipE:
		ETM820OIgWZyRbG = ETM820OIgWZyRbG.replace(qE4nB3mKWHs,gCkRKGhwcx26v(u"࠭ࠫࠨጀ"))
		qg7Nr1dCaD = iDhLkZS6XBagNCQfs9tq2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬጁ")+ETM820OIgWZyRbG
		REIkboX9NtlZCSU3A = {sTGtHVyhQ9cJU37zxo2O(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬጂ"):SebHIf2jL1TBgrMKJu}
		jBpoP97yUegruqxbE = WMx8v0FVCjlhcQKRwdX1s(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,HCiWF4jV1Q8(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ጃ"))
		if jBpoP97yUegruqxbE.succeeded:
			YD0R1z8ldmipE = jBpoP97yUegruqxbE.content
			if QBOMjKifEAFD:
				try: YD0R1z8ldmipE = YD0R1z8ldmipE.decode(Tv08xsf9HOqunIVUPdK1,wPnfgxKZdAv6T10(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪጄ"))
				except: pass
			uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall(gCkRKGhwcx26v(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬጅ"),YD0R1z8ldmipE,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			b1ZXcxj3L8oHBfN5Yukqt9wU = [iBh7RYSxUfWzVa2Jb]
			WY0TcqfRnZo4mNFuLE = [HCiWF4jV1Q8(u"ࠬࡧࡰ࡬ࠩጆ"),ALwOspNtXxZrz3PEKku(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ጇ"),TVnqDYzWoM2UfHp0dchJ(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨገ"),uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩጉ"),czvu7VQCZodkMf(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫጊ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡴ࡭ࡶࠧጋ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡦࡺ࡬ࡢࡳࠪጌ"),VOALf8iYEnMdK0g(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪግ"),wPnfgxKZdAv6T10(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭ጎ"),iDhLkZS6XBagNCQfs9tq2(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩጏ"),bcNqYtfET5l92dLGjyZSPe(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪጐ"),czvu7VQCZodkMf(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫ጑"),VOALf8iYEnMdK0g(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭ጒ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭ጓ"),sTGtHVyhQ9cJU37zxo2O(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩጔ"),uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩጕ")]
			for IIHsbDu7K1U38AZaodhqk0QTX in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
				if any(value in IIHsbDu7K1U38AZaodhqk0QTX for value in WY0TcqfRnZo4mNFuLE): continue
				iBh7RYSxUfWzVa2Jb = EDmwsQf1Px9k8h04oAHuObdnyrTGU(IIHsbDu7K1U38AZaodhqk0QTX,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡶࡴ࡯ࠫ጖"))
				if iBh7RYSxUfWzVa2Jb in b1ZXcxj3L8oHBfN5Yukqt9wU: continue
				if len(b1ZXcxj3L8oHBfN5Yukqt9wU)==czvu7VQCZodkMf(u"࠽ᘜ"):
					z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ጗")+BT6iI7a3vbGM+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧጘ")+o60Fx9LCWq4TdtQgAcikmhbN5w+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࠤࡢ࠭ጙ"))
					MMAUZiw4CoJ8.setSetting(DQIrVcKuY6bJv(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭ጚ")+BT6iI7a3vbGM,SebHIf2jL1TBgrMKJu)
					break
				b1ZXcxj3L8oHBfN5Yukqt9wU.append(iBh7RYSxUfWzVa2Jb)
				iGxH2fsuScPtkJb7ECg = pfhH2objgVkI7eycn.replace(o60Fx9LCWq4TdtQgAcikmhbN5w,iBh7RYSxUfWzVa2Jb)
				ooSekfpJr7jAgbXIT = WMx8v0FVCjlhcQKRwdX1s(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,iGxH2fsuScPtkJb7ECg,SebHIf2jL1TBgrMKJu,gTnyji0CwRW81,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩጛ"))
				YD0R1z8ldmipE = ooSekfpJr7jAgbXIT.content
				if ooSekfpJr7jAgbXIT.succeeded and ttnjrL1sNAq9eEhdD3MY in YD0R1z8ldmipE:
					z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ጜ")+BT6iI7a3vbGM+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭ጝ")+iBh7RYSxUfWzVa2Jb+C3w6qluao7EzUxJgMGBtV(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ጞ")+o60Fx9LCWq4TdtQgAcikmhbN5w+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࠣࡡࠬጟ"))
					MMAUZiw4CoJ8.setSetting(l7kBpMw5Qn(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬጠ")+BT6iI7a3vbGM,iBh7RYSxUfWzVa2Jb)
					break
	return iBh7RYSxUfWzVa2Jb,iGxH2fsuScPtkJb7ECg,ooSekfpJr7jAgbXIT
def dPlNiRwGQK4bz(sLjle5myuEXSiFHJ):
	hCmHlYVrpSzseWBG37NytUbOT = {
	 vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡦ࡮ࡷࡢ࡭ࠪጡ")				:t0FTYwCdi8jVaDu4EWBzUKbGLl(u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧጢ")
	,Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ࡡ࡬ࡱࡤࡱࠬጣ")				:wPnfgxKZdAv6T10(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫጤ")
	,ASkvf27etUK0(u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪጥ")				:HCiWF4jV1Q8(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪጦ")
	,czvu7VQCZodkMf(u"ࠪࡥࡰࡽࡡ࡮ࠩጧ")				:vMhFypGLHZJbdX4O7oc3W8x(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨጨ")
	,tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࡧ࡫ࡸࡣࡰࡸࡺࡨࡥࠨጩ")			:bcNqYtfET5l92dLGjyZSPe(u"࠭ๅ้ไ฼ࠤฬ้่ศ็ࠣฮ๏๎ศࠨጪ")
	,iDhLkZS6XBagNCQfs9tq2(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧጫ")				:iDhLkZS6XBagNCQfs9tq2(u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨጬ")
	,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫጭ")				:iDhLkZS6XBagNCQfs9tq2(u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩጮ")
	,zpx2fPNKk6Ms38eD1vcO(u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧጯ")			:TVnqDYzWoM2UfHp0dchJ(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨጰ")
	,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨጱ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫጲ")
	,bcNqYtfET5l92dLGjyZSPe(u"ࠨࡣ࡯ࡱࡸࡺࡢࡢࠩጳ")				:qeYIw0BNTL9bGJnosacQ1DtVR(u"่ࠩ์็฿ࠠศๆู่฼ฮษࠨጴ")
	,sTGtHVyhQ9cJU37zxo2O(u"ࠪࡥࡳ࡯࡭ࡦࡼ࡬ࡨࠬጵ")				:C3w6qluao7EzUxJgMGBtV(u"๊ࠫ๎โฺࠢส๊๊๐ࠠำัࠪጶ")
	,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪጷ")			:xxRyYsrSCzjifvH4cIqgldeOo(u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨጸ")
	,zpx2fPNKk6Ms38eD1vcO(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩጹ")				:HADrRCz9QgU4xudPJIqYb70(u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨጺ")
	,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫጻ")				:l7kBpMw5Qn(u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫጼ")
	,vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡦࡿ࡬ࡰ࡮ࠪጽ")				:qeYIw0BNTL9bGJnosacQ1DtVR(u"๋่ࠬใ฻ࠣว๏๊่ๅࠩጾ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡢࡰ࡭ࡵࡥࠬጿ")				:uqLUBHepfM3l6AyIzTJh80a(u"ࠧๆ๊ๅ฽ࠥฮใาษࠪፀ")
	,C3w6qluao7EzUxJgMGBtV(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨፁ")				:Gykx0wL3XrlWaujsqKP9n2Q(u"่ࠩ์็฿ࠠษำึฮ๏าࠧፂ")
	,C3w6qluao7EzUxJgMGBtV(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫፃ")				:Gykx0wL3XrlWaujsqKP9n2Q(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫፄ")
	,DQIrVcKuY6bJv(u"ࠬࡩࡩ࡮ࡣ࠷ࡴࠬፅ")				:v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึࠦศ๋ࠩፆ")
	,TVnqDYzWoM2UfHp0dchJ(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧፇ")				:v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪፈ")
	,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫፉ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫፊ")
	,ASkvf27etUK0(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ፋ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ፌ")
	,sTGtHVyhQ9cJU37zxo2O(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬፍ")			:l7kBpMw5Qn(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬፎ")
	,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪፏ")				:ypO63g8oJEsDnPBHSuU7lMTZr(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪፐ")
	,ASkvf27etUK0(u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬፑ")				:l7kBpMw5Qn(u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬፒ")
	,gCkRKGhwcx26v(u"ࠬࡩࡩ࡮ࡣࡩࡶࡪ࡫ࠧፓ")				:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไี๏࠭ፔ")
	,iDhLkZS6XBagNCQfs9tq2(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪፕ")			:uqLUBHepfM3l6AyIzTJh80a(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩፖ")
	,HCiWF4jV1Q8(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪፗ")				:tX7u5idnzTVNva3PlmJD1I80rxch4(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪፘ")
	,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡨ࡯࡭ࡢࡹࡥࡥࡸ࠭ፙ")				:DQIrVcKuY6bJv(u"๋่ࠬใ฻ࠣื๏๋ว๊ࠡหืࠬፚ")
	,C3w6qluao7EzUxJgMGBtV(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ፛")			:czvu7VQCZodkMf(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠩ፜")
	,czvu7VQCZodkMf(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨ፝")	:gCkRKGhwcx26v(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤู๊สฯั่๎๋࠭፞")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡪࡤࡷ࡭ࡺࡡࡨࡵࠪ፟")	:TVnqDYzWoM2UfHp0dchJ(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦ็ศึอห่࠭፠")
	,AGlW9LqKN3Dvo(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡰ࡮ࡼࡥࡴࠩ፡")	:qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็หหูืࠧ።")
	,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ፣"):ASkvf27etUK0(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ፤")
	,TVnqDYzWoM2UfHp0dchJ(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡵࡱࡳ࡭ࡨࡹࠧ፥")	:HCiWF4jV1Q8(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬ፦")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩ፧")	:t0FTYwCdi8jVaDu4EWBzUKbGLl(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ፨")
	,qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ፩")				:l7kBpMw5Qn(u"ࠧๆฬ๋ๆๆ࠭፪")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡦࡵࡥࡲࡧࡣࡢࡨࡨࠫ፫")			:C3w6qluao7EzUxJgMGBtV(u"่ࠩ์็฿ࠠะำส้ฬࠦใศใํ๋ࠬ፬")
	,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ፭")				:Izy1PvclrYx4eSVWn0L5phZbq(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ፮")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭፯")				:fp6KV7DlS8QYniUczHdmZChL(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ፰")
	,wPnfgxKZdAv6T10(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ፱")				:HADrRCz9QgU4xudPJIqYb70(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ፲")
	,ASkvf27etUK0(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ፳")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭፴")
	,wPnfgxKZdAv6T10(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭፵")				:xxRyYsrSCzjifvH4cIqgldeOo(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨ፶")
	,wPnfgxKZdAv6T10(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨ፷")				:zpx2fPNKk6Ms38eD1vcO(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪ፸")
	,NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ፹")			:Izy1PvclrYx4eSVWn0L5phZbq(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ፺")
	,AGlW9LqKN3Dvo(u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫ፻")				:DQIrVcKuY6bJv(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫ፼")
	,HCiWF4jV1Q8(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ፽")				:Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭፾")
	,AGlW9LqKN3Dvo(u"ࠧࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢࠩ፿")				:fp6KV7DlS8QYniUczHdmZChL(u"ࠨ็๋ๆ฾ࠦๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧᎀ")
	,l7kBpMw5Qn(u"ࠩࡨࡰ࡮࡬ࡶࡪࡦࡨࡳࠬᎁ")			:bcNqYtfET5l92dLGjyZSPe(u"้ࠪํู่ࠡล็๎ๆࠦแ๋ัํ์ࠬᎂ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬᎃ")				:t0FTYwCdi8jVaDu4EWBzUKbGLl(u"๋่ࠬใ฻ࠣๅอืใสࠩᎄ")
	,zpx2fPNKk6Ms38eD1vcO(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᎅ")				:HADrRCz9QgU4xudPJIqYb70(u"ࠧโึ็ࠫᎆ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡨࡤ࡮ࡪࡸࡳࡩࡱࡺࠫᎇ")			:iDhLkZS6XBagNCQfs9tq2(u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧᎈ")
	,TVnqDYzWoM2UfHp0dchJ(u"ࠪࡪࡦࡸࡥࡴ࡭ࡲࠫᎉ")				:Ns6AJKH7DGpr19Wl5C3nF(u"๊ࠫ๎โฺࠢไหึูใ้ࠩᎊ")
	,czvu7VQCZodkMf(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧᎋ")				:tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨᎌ")
	,AGlW9LqKN3Dvo(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩᎍ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫᎎ")
	,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡩࡳࡱࡪࡥࡳࠩᎏ")				:zpx2fPNKk6Ms38eD1vcO(u"้ࠪั๊ฯࠨ᎐")
	,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫ࡫ࡵࡳࡵࡣࠪ᎑")				:vMhFypGLHZJbdX4O7oc3W8x(u"๋่ࠬใ฻ࠣๅํูสศࠩ᎒")
	,HADrRCz9QgU4xudPJIqYb70(u"࠭ࡦࡶࡰࡲࡲࡹࡼࠧ᎓")				:Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧๆ๊ๅ฽ࠥ็ๆ้่ࠣฮ๏็๊ࠨ᎔")
	,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡨࡸࡷ࡭ࡧࡲࡵࡸࠪ᎕")				:Gykx0wL3XrlWaujsqKP9n2Q(u"่ࠩ์็฿ࠠโ๊ืหึࠦส๋ใํࠫ᎖")
	,HCiWF4jV1Q8(u"ࠪࡪࡺࡹࡨࡢࡴࡹ࡭ࡩ࡫࡯ࠨ᎗")			:VOALf8iYEnMdK0g(u"๊ࠫ๎โฺࠢไ์ูอัࠡใํำ๏๎ࠧ᎘")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠬ࡭࡯ࡰࡦࠪ᎙")					:C3w6qluao7EzUxJgMGBtV(u"࠭ฬ๋ัࠪ᎚")
	,DQIrVcKuY6bJv(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ᎛")				:iDhLkZS6XBagNCQfs9tq2(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ᎜")
	,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠩ࡫ࡩࡱࡧ࡬ࠨ᎝")				:fp6KV7DlS8QYniUczHdmZChL(u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭᎞")
	,ALwOspNtXxZrz3PEKku(u"ࠫ࡮࡬ࡩ࡭࡯ࠪ᎟")				:Izy1PvclrYx4eSVWn0L5phZbq(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩᎠ")
	,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬᎡ")			:xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩᎢ")
	,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨᎣ")		:Izy1PvclrYx4eSVWn0L5phZbq(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧᎤ")
	,TVnqDYzWoM2UfHp0dchJ(u"ࠪ࡭ࡵࡺࡶࠨᎥ")					:v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡎࡖࡔࡗࠩᎦ")
	,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨᎧ")			:zpx2fPNKk6Ms38eD1vcO(u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪᎨ")
	,uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᎩ")			:v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬᎪ")
	,bcNqYtfET5l92dLGjyZSPe(u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧᎫ")			:czvu7VQCZodkMf(u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩᎬ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧᎭ")			:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨᎮ")
	,DQIrVcKuY6bJv(u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨᎯ")				:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩᎰ")
	,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᎱ")				:iDhLkZS6XBagNCQfs9tq2(u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭Ꮂ")
	,TVnqDYzWoM2UfHp0dchJ(u"ࠪ࡯࡮ࡸ࡭ࡢ࡮࡮ࠫᎳ")				:iDhLkZS6XBagNCQfs9tq2(u"๊ࠫ๎โฺࠢๆี๊อไไࠩᎴ")
	,wPnfgxKZdAv6T10(u"ࠬࡲࡡࡳࡱࡽࡥࠬᎵ")				:qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫᎶ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨᎷ")				:uqLUBHepfM3l6AyIzTJh80a(u"ࠨ็็ๅࠬᎸ")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠩ࡯࡭ࡻ࡫ࠧᎹ")					:bcNqYtfET5l92dLGjyZSPe(u"ࠪๆ๋อษࠨᎺ")
	,gCkRKGhwcx26v(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫᎻ")				:DQIrVcKuY6bJv(u"๋ࠬไโࠩᎼ")
	,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧᎽ")				:uqLUBHepfM3l6AyIzTJh80a(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭Ꮎ")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠨ࡯࠶ࡹࠬᎿ")					:HCiWF4jV1Q8(u"ࠩࡐ࠷࡚࠭Ꮐ")
	,vMhFypGLHZJbdX4O7oc3W8x(u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬᏁ")				:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧᏂ")
	,wPnfgxKZdAv6T10(u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩᏃ")			:bcNqYtfET5l92dLGjyZSPe(u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩᏄ")
	,uqLUBHepfM3l6AyIzTJh80a(u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫᏅ")			:Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭Ꮖ")
	,Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡰࡥࡸࡧࡶࡪࡦࡨࡳࠬᏇ")			:tX7u5idnzTVNva3PlmJD1I80rxch4(u"้ࠪํู่ࠡ็สืฬࠦแ๋ัํ์ࠬᏈ")
	,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᏉ")				:VOALf8iYEnMdK0g(u"๋ࠬแใ๊าࠫᏊ")
	,vMhFypGLHZJbdX4O7oc3W8x(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭Ꮛ")				:C3w6qluao7EzUxJgMGBtV(u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩᏌ")
	,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨᏍ")				:HADrRCz9QgU4xudPJIqYb70(u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩᏎ")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡳࡱࡪࠧᏏ")					:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫ็ี๊ๆࠩᏐ")
	,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡶࡡ࡯ࡧࡷࠫᏑ")				:Gykx0wL3XrlWaujsqKP9n2Q(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᏒ")
	,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭Ꮣ")			:AGlW9LqKN3Dvo(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫᏔ")
	,ALwOspNtXxZrz3PEKku(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨᏕ")			:iDhLkZS6XBagNCQfs9tq2(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨᏖ")
	,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡶ࡬ࡩ࡭࡯ࠪᏗ")				:vMhFypGLHZJbdX4O7oc3W8x(u"๋่ࠬใ฻ࠣ็๏๎ࠠโ์็้ࠬᏘ")
	,gCkRKGhwcx26v(u"࠭ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧࠪᏙ")			:gCkRKGhwcx26v(u"ࠧๆ๊ๅ฽ู๊ࠥา์ึࠤฯอ๊ๆࠩᏚ")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡵ࡫ࡥࡧࡧ࡫ࡢࡶࡼࠫᏛ")			:cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"่ࠩ์็฿ࠠีสๆฮ๏࠭Ꮬ")
	,sTGtHVyhQ9cJU37zxo2O(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬᏝ")				:czvu7VQCZodkMf(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭Ꮮ")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠲ࠨᏟ")			:ASkvf27etUK0(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠡ࠴ࠪᏠ")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫᏡ")			:zpx2fPNKk6Ms38eD1vcO(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩᏢ")
	,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬᏣ")			:HADrRCz9QgU4xudPJIqYb70(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬᏤ")
	,iDhLkZS6XBagNCQfs9tq2(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧᏥ")		:xxRyYsrSCzjifvH4cIqgldeOo(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭Ꮶ")
	,t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩᏧ")		:czvu7VQCZodkMf(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩᏨ")
	,Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬᏩ")	:DQIrVcKuY6bJv(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩᏪ")
	,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪᏫ")				:VOALf8iYEnMdK0g(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭Ꮼ")
	,VOALf8iYEnMdK0g(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧᏭ")				:ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭Ꮾ")
	,sTGtHVyhQ9cJU37zxo2O(u"ࠧࡴࡪࡲࡳ࡫ࡴࡥࡵࠩᏯ")				:cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨ็๋ๆ฾ࠦิ้ใ๊ࠣฯ࠭Ᏸ")
	,fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫᏱ")				:DQIrVcKuY6bJv(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩᏲ")
	,ALwOspNtXxZrz3PEKku(u"ࠫࡹ࡯࡫ࡢࡣࡷࠫᏳ")				:sTGtHVyhQ9cJU37zxo2O(u"๋่ࠬใ฻ࠣฮ่อสࠨᏴ")
	,VOALf8iYEnMdK0g(u"࠭ࡴࡷࡨࡸࡲࠬᏵ")				:v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ᏶")
	,iDhLkZS6XBagNCQfs9tq2(u"ࠨࡸࡤࡶࡧࡵ࡮ࠨ᏷")				:Gykx0wL3XrlWaujsqKP9n2Q(u"่ࠩ์็฿ࠠโษิฬํ์ࠧᏸ")
	,HADrRCz9QgU4xudPJIqYb70(u"ࠪࡺ࡮ࡪࡥࡰࠩᏹ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫๆ๐ฯ๋๊ࠪᏺ")
	,C3w6qluao7EzUxJgMGBtV(u"ࠬࡼࡩࡥࡧࡲࡲࡸࡧࡥ࡮ࠩᏻ")			:czvu7VQCZodkMf(u"࠭ๅ้ไ฼ࠤๆ๐ฯุ๋๊๊ࠣอฦๆࠩᏼ")
	,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠱ࠨᏽ")				:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠲ࠩ᏾")
	,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠴ࠪ᏿")				:ypO63g8oJEsDnPBHSuU7lMTZr(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠵ࠫ᐀")
	,vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡾࡧࡱࡰࡶࠪᐁ")				:j2eKYcTFGf7q9XVgJCUukrtiAEs(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩᐂ")
	,NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᐃ")				:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬᐄ")
	,vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᐅ")		:czvu7VQCZodkMf(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭ᐆ")
	,sTGtHVyhQ9cJU37zxo2O(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧᐇ")	:vMhFypGLHZJbdX4O7oc3W8x(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨᐈ")
	,ASkvf27etUK0(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ᐉ")		:Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ᐊ")
	,DQIrVcKuY6bJv(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐋ")			:DQIrVcKuY6bJv(u"ࠨ็๋ห็฿ࠠๆ่ࠣ๎ํะ๊้สࠪᐌ")
	}
	WcEPvUnVu9BjX7mb1Yg = sLjle5myuEXSiFHJ.lower()
	for key in list(hCmHlYVrpSzseWBG37NytUbOT.keys()):
		FVGnULWhvKXBcJ5z7ERM29 = key.lower()
		if WcEPvUnVu9BjX7mb1Yg==FVGnULWhvKXBcJ5z7ERM29:
			sLjle5myuEXSiFHJ = hCmHlYVrpSzseWBG37NytUbOT[key]
			break
	return sLjle5myuEXSiFHJ
def GLXqHD847n2jOVZaNEz9mFUIR31x(ppsYErBdCikHU,dHcKhPT3MXQwr=SebHIf2jL1TBgrMKJu):
	qFsuKN7ngp.JJLAs5tXyUnSDGP = BBX9RAuxnyGZ4WIF2TrhYeom3
	if not dHcKhPT3MXQwr and ppsYErBdCikHU: dHcKhPT3MXQwr = wPnfgxKZdAv6T10(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪᐍ")
	MMAUZiw4CoJ8.setSetting(sTGtHVyhQ9cJU37zxo2O(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᐎ"),dHcKhPT3MXQwr)
	return
def xuCTZaNtMVwFs(pfhH2objgVkI7eycn,ghbCdAYaE76DHlywzPXoeNr=t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫ࠿࠵ࠧᐏ")):
	return _bMHNxk92Bwil7(pfhH2objgVkI7eycn,ghbCdAYaE76DHlywzPXoeNr)
def CiUEbOuVPR2ro7x5akwIeQt1q8SYdj(QoM9jpdrNx4CZgXPY3vcU):
	if QoM9jpdrNx4CZgXPY3vcU in [SebHIf2jL1TBgrMKJu,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬ࠶ࠧᐐ"),wvkDqmNZlJU52isXo]: return SebHIf2jL1TBgrMKJu
	QoM9jpdrNx4CZgXPY3vcU = int(QoM9jpdrNx4CZgXPY3vcU)
	zKJ4ktUXgP0Bj29vFwMLhy8aYb = QoM9jpdrNx4CZgXPY3vcU^iHR47eol8wB3Z
	V7joeR4zEhTvlArHK2y8WF = QoM9jpdrNx4CZgXPY3vcU^QfG1xIZ4hpq3ezPXt7VbvglUcB
	LLeV4UjfKH1 = QoM9jpdrNx4CZgXPY3vcU^vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu
	hG5zd1tIw6YZrTpeQuNPDvg = str(zKJ4ktUXgP0Bj29vFwMLhy8aYb)+str(V7joeR4zEhTvlArHK2y8WF)+str(LLeV4UjfKH1)
	return hG5zd1tIw6YZrTpeQuNPDvg
def J3S47dEU2Hhz6c(QoM9jpdrNx4CZgXPY3vcU):
	if QoM9jpdrNx4CZgXPY3vcU in [SebHIf2jL1TBgrMKJu,wPnfgxKZdAv6T10(u"࠭࠰ࠨᐑ"),wvkDqmNZlJU52isXo]: return SebHIf2jL1TBgrMKJu
	QoM9jpdrNx4CZgXPY3vcU = str(QoM9jpdrNx4CZgXPY3vcU)
	hG5zd1tIw6YZrTpeQuNPDvg = SebHIf2jL1TBgrMKJu
	if len(QoM9jpdrNx4CZgXPY3vcU)==l7kBpMw5Qn(u"࠶࠻ᘝ"):
		zKJ4ktUXgP0Bj29vFwMLhy8aYb,V7joeR4zEhTvlArHK2y8WF,LLeV4UjfKH1 = QoM9jpdrNx4CZgXPY3vcU[wvkDqmNZlJU52isXo:K7cnfQMS6BPvI4LGmCsRp8bUlJ9],QoM9jpdrNx4CZgXPY3vcU[K7cnfQMS6BPvI4LGmCsRp8bUlJ9:bcNqYtfET5l92dLGjyZSPe(u"࠿ᘞ")],QoM9jpdrNx4CZgXPY3vcU[bcNqYtfET5l92dLGjyZSPe(u"࠿ᘞ"):]
		zKJ4ktUXgP0Bj29vFwMLhy8aYb = int(zKJ4ktUXgP0Bj29vFwMLhy8aYb)^vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu
		V7joeR4zEhTvlArHK2y8WF = int(V7joeR4zEhTvlArHK2y8WF)^QfG1xIZ4hpq3ezPXt7VbvglUcB
		LLeV4UjfKH1 = int(LLeV4UjfKH1)^iHR47eol8wB3Z
		if zKJ4ktUXgP0Bj29vFwMLhy8aYb==V7joeR4zEhTvlArHK2y8WF==LLeV4UjfKH1: hG5zd1tIw6YZrTpeQuNPDvg = str(zKJ4ktUXgP0Bj29vFwMLhy8aYb*AGlW9LqKN3Dvo(u"࠶࠱ᘟ"))
	return hG5zd1tIw6YZrTpeQuNPDvg
def Td0evpwjJFMAOa(QoM9jpdrNx4CZgXPY3vcU,a8L6gndFTXEQsyWVlzefqUj5IZA=Gykx0wL3XrlWaujsqKP9n2Q(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᐒ")):
	if QoM9jpdrNx4CZgXPY3vcU==SebHIf2jL1TBgrMKJu: return SebHIf2jL1TBgrMKJu
	QoM9jpdrNx4CZgXPY3vcU = int(QoM9jpdrNx4CZgXPY3vcU)+int(a8L6gndFTXEQsyWVlzefqUj5IZA)
	zKJ4ktUXgP0Bj29vFwMLhy8aYb = QoM9jpdrNx4CZgXPY3vcU^iHR47eol8wB3Z
	V7joeR4zEhTvlArHK2y8WF = QoM9jpdrNx4CZgXPY3vcU^QfG1xIZ4hpq3ezPXt7VbvglUcB
	LLeV4UjfKH1 = QoM9jpdrNx4CZgXPY3vcU^vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu
	hG5zd1tIw6YZrTpeQuNPDvg = str(zKJ4ktUXgP0Bj29vFwMLhy8aYb)+str(V7joeR4zEhTvlArHK2y8WF)+str(LLeV4UjfKH1)
	return hG5zd1tIw6YZrTpeQuNPDvg
def HZAmYXguczSBkOnM1jpdaEPqW7KfI(QoM9jpdrNx4CZgXPY3vcU,a8L6gndFTXEQsyWVlzefqUj5IZA=zpx2fPNKk6Ms38eD1vcO(u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪᐓ")):
	if QoM9jpdrNx4CZgXPY3vcU==SebHIf2jL1TBgrMKJu: return SebHIf2jL1TBgrMKJu
	QoM9jpdrNx4CZgXPY3vcU = str(QoM9jpdrNx4CZgXPY3vcU)
	zmWBb6RMtEhNw7j1HrdI9pTyVnXve = int(len(QoM9jpdrNx4CZgXPY3vcU)/fuCbjVag7vU908J2Yqx5Th)
	zKJ4ktUXgP0Bj29vFwMLhy8aYb = int(QoM9jpdrNx4CZgXPY3vcU[wvkDqmNZlJU52isXo:zmWBb6RMtEhNw7j1HrdI9pTyVnXve])^iHR47eol8wB3Z
	V7joeR4zEhTvlArHK2y8WF = int(QoM9jpdrNx4CZgXPY3vcU[zmWBb6RMtEhNw7j1HrdI9pTyVnXve:JhTts2R43AxkM8bYanKVy*zmWBb6RMtEhNw7j1HrdI9pTyVnXve])^QfG1xIZ4hpq3ezPXt7VbvglUcB
	LLeV4UjfKH1 = int(QoM9jpdrNx4CZgXPY3vcU[JhTts2R43AxkM8bYanKVy*zmWBb6RMtEhNw7j1HrdI9pTyVnXve:fuCbjVag7vU908J2Yqx5Th*zmWBb6RMtEhNw7j1HrdI9pTyVnXve])^vkFJH3Xa6TQf4Y82Ls1OgrmPhnqu
	hG5zd1tIw6YZrTpeQuNPDvg = SebHIf2jL1TBgrMKJu
	if zKJ4ktUXgP0Bj29vFwMLhy8aYb==V7joeR4zEhTvlArHK2y8WF==LLeV4UjfKH1: hG5zd1tIw6YZrTpeQuNPDvg = str(int(zKJ4ktUXgP0Bj29vFwMLhy8aYb)-int(a8L6gndFTXEQsyWVlzefqUj5IZA))
	return hG5zd1tIw6YZrTpeQuNPDvg
def YyqPk3DKne2FUf8RgC(zzAyFWoHq0n):
	y9yZ8MStRnHsVLYDchpEm = qFsuKN7ngp.SITESURLS[j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᐔ")][t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠹ᘠ")]
	dvkyXLIFESl4b = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(rcI3PdxEKSNo5VQYGf9hBTsWnyAi81,AGlW9LqKN3Dvo(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ᐕ"),fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡸࡱࡩ࡯ࡵࠪᐖ"),Gykx0wL3XrlWaujsqKP9n2Q(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ᐗ"),bcNqYtfET5l92dLGjyZSPe(u"࠭࠷࠳࠲ࡳࠫᐘ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩᐙ"))
	YHuQ2kN59aADIgMtoEmCWOLh,ICWnSiy09ht5DvYbpsO = q5WoBw7x9sIFDEt(dvkyXLIFESl4b)
	YHuQ2kN59aADIgMtoEmCWOLh = Td0evpwjJFMAOa(YHuQ2kN59aADIgMtoEmCWOLh,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᐚ"))
	llSo9A8mI35w = {ASkvf27etUK0(u"ࠩ࡬ࡨࡸ࠭ᐛ"):t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪࡈࡎࡇࡌࡐࡉࠪᐜ"),wPnfgxKZdAv6T10(u"ࠫࡺࡹࡲࠨᐝ"):qFsuKN7ngp.AV_CLIENT_IDS,AGlW9LqKN3Dvo(u"ࠬࡼࡥࡳࠩᐞ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,zpx2fPNKk6Ms38eD1vcO(u"࠭ࡳࡤࡴࠪᐟ"):zzAyFWoHq0n,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡴ࡫ࡽࠫᐠ"):YHuQ2kN59aADIgMtoEmCWOLh}
	MM9p0hKeJXwyYV2unERT4rN = {v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᐡ"):t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᐢ")}
	pMrPwuBbnz320QkxGHI7NqgsTjf9dt = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡔࡔ࡙ࡔࠨᐣ"),y9yZ8MStRnHsVLYDchpEm,llSo9A8mI35w,MM9p0hKeJXwyYV2unERT4rN,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,vMhFypGLHZJbdX4O7oc3W8x(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬᐤ"))
	fNoCvJActQs2lnKzPYdhSMy3 = pMrPwuBbnz320QkxGHI7NqgsTjf9dt.content
	try:
		if not fNoCvJActQs2lnKzPYdhSMy3: ypoX9i4BRCO1JdlLMguIYUEc
		x23jgkJBLfqA70 = xjVJ0o7mF86tCDagkbNcrTAR4UH(wPnfgxKZdAv6T10(u"ࠬࡪࡩࡤࡶࠪᐥ"),fNoCvJActQs2lnKzPYdhSMy3)
		JEhXQablAyf = x23jgkJBLfqA70[cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭࡭ࡴࡩࠪᐦ")]
		IuXfvAOPr5hd9G8tBslo = x23jgkJBLfqA70[czvu7VQCZodkMf(u"ࠧࡴࡧࡦࠫᐧ")]
		EuRKxGmCMYa01Q9ANJj6 = x23jgkJBLfqA70[C3w6qluao7EzUxJgMGBtV(u"ࠨࡵࡷࡴࠬᐨ")]
		IuXfvAOPr5hd9G8tBslo = int(HZAmYXguczSBkOnM1jpdaEPqW7KfI(IuXfvAOPr5hd9G8tBslo,Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᐩ")))
		EuRKxGmCMYa01Q9ANJj6 = int(HZAmYXguczSBkOnM1jpdaEPqW7KfI(EuRKxGmCMYa01Q9ANJj6,HADrRCz9QgU4xudPJIqYb70(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᐪ")))
		for i9nszpHoLSvIEGCUel in range(IuXfvAOPr5hd9G8tBslo,wvkDqmNZlJU52isXo,-EuRKxGmCMYa01Q9ANJj6):
			if not eval(l7kBpMw5Qn(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩᐫ"),{zpx2fPNKk6Ms38eD1vcO(u"ࠬࡾࡢ࡮ࡥࠪᐬ"):if5dy2h0nsDVlukoQ7NUFqx4cGEW}): ypoX9i4BRCO1JdlLMguIYUEc
			i9yzUqgAW2Zap1h4Lm(ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬᐭ"),str(i9nszpHoLSvIEGCUel)+vMhFypGLHZJbdX4O7oc3W8x(u"ࠧࠡࠢฮห๋๐ษࠨᐮ"),uv8V4fE7j9pmgFr3wnDL=bcNqYtfET5l92dLGjyZSPe(u"࠳࠳࠴ᘡ")*EuRKxGmCMYa01Q9ANJj6)
			if5dy2h0nsDVlukoQ7NUFqx4cGEW.sleep(TVnqDYzWoM2UfHp0dchJ(u"࠴࠴࠵࠶ᘢ")*EuRKxGmCMYa01Q9ANJj6)
		if eval(zpx2fPNKk6Ms38eD1vcO(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ᐯ"),{TVnqDYzWoM2UfHp0dchJ(u"ࠩࡻࡦࡲࡩࠧᐰ"):if5dy2h0nsDVlukoQ7NUFqx4cGEW}):
			JEhXQablAyf = JEhXQablAyf.replace(u43PVWjh7t9YwI,HCiWF4jV1Q8(u"ࠪࡠࡡࡴࠧᐱ")).replace(vvm0bR6z8NK5wUg2l9jqrJu,ALwOspNtXxZrz3PEKku(u"ࠫࡡࡢࡲࠨᐲ"))
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠬิั้ฮࠪᐳ"),lFEvMxzSH2y7tYR,JEhXQablAyf)
		ypoX9i4BRCO1JdlLMguIYUEc
	except: exec(uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᐴ"),{t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࡹࡤࡰࡧࠬᐵ"):if5dy2h0nsDVlukoQ7NUFqx4cGEW})
	return
def T9UcRu2AJVBnDg3SFfQKwL6js():
	exec(gCkRKGhwcx26v(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᐶ"),{Ns6AJKH7DGpr19Wl5C3nF(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᐷ"):G5OVsSktWRJQu8h4T,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡼࡧࡳࡣࠨᐸ"):if5dy2h0nsDVlukoQ7NUFqx4cGEW})
	return
def q5WoBw7x9sIFDEt(AAtipVkQ9I2qJDo):
	mdKPiE0tvXrWJSDI8R2fLnC4ho1,C4257GIxAk = wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(AAtipVkQ9I2qJDo):
		try: mdKPiE0tvXrWJSDI8R2fLnC4ho1 = E2xjtKaMXdC3NDoTm7f5Wkev.path.getsize(AAtipVkQ9I2qJDo)
		except: pass
		if not mdKPiE0tvXrWJSDI8R2fLnC4ho1:
			try: mdKPiE0tvXrWJSDI8R2fLnC4ho1 = E2xjtKaMXdC3NDoTm7f5Wkev.stat(AAtipVkQ9I2qJDo).st_size
			except: pass
		if not mdKPiE0tvXrWJSDI8R2fLnC4ho1:
			try:
				from pathlib import Path as Cp0c6qgW23XNbmFMynDS
				mdKPiE0tvXrWJSDI8R2fLnC4ho1 = Cp0c6qgW23XNbmFMynDS(AAtipVkQ9I2qJDo).stat().st_size
			except: pass
		if mdKPiE0tvXrWJSDI8R2fLnC4ho1: C4257GIxAk = nyUIsfd53EGot9vbj0XDeq
	return mdKPiE0tvXrWJSDI8R2fLnC4ho1,C4257GIxAk
def QFYHD0lmU6PtTWaqE5NyuziX72(l6QJY7Iz8w41N,showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l6QJY7Iz8w41N+v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡡࡴ࡜࡯ࠩᐹ")+E7r8hUCVvTiFQW0dBGXjxcy+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩᐺ")+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠵ᘣ"): return mrhSYXH2P8bO3eJAa9n
	succeeded = BBX9RAuxnyGZ4WIF2TrhYeom3
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(l6QJY7Iz8w41N):
		try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(l6QJY7Iz8w41N.decode(Tv08xsf9HOqunIVUPdK1))
		except:
			try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(vULjWeONfQx)
			except Exception as kQhFMNbH2U:
				succeeded = mrhSYXH2P8bO3eJAa9n
				if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,str(kQhFMNbH2U))
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,ALwOspNtXxZrz3PEKku(u"࠭แีๆอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭ᐻ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᐼ"))
	return succeeded
def VS8fuikmreJGgW6cdLOq2yz(kCom7yqHgr,t8VvFQa5gxyi,showDialogs):
	if showDialogs:
		sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,kCom7yqHgr+czvu7VQCZodkMf(u"ࠨ࡞ࡱࡠࡳ࠭ᐽ")+E7r8hUCVvTiFQW0dBGXjxcy+zpx2fPNKk6Ms38eD1vcO(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧᐾ")+XOVRfitWJP1zL3p2CMYF)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb!=nyUIsfd53EGot9vbj0XDeq: return mrhSYXH2P8bO3eJAa9n
	succeeded = BBX9RAuxnyGZ4WIF2TrhYeom3
	if E2xjtKaMXdC3NDoTm7f5Wkev.path.exists(kCom7yqHgr):
		for IkTGuAPoFlsQbq,RhAx8igYHozFLQWUV,sCwoI6tacuXvUAqOb3 in E2xjtKaMXdC3NDoTm7f5Wkev.walk(kCom7yqHgr,topdown=mrhSYXH2P8bO3eJAa9n):
			for AAtipVkQ9I2qJDo in sCwoI6tacuXvUAqOb3:
				CtexHAfSL1bodO5zuBh8Kj6ypm = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(IkTGuAPoFlsQbq,AAtipVkQ9I2qJDo)
				try: E2xjtKaMXdC3NDoTm7f5Wkev.remove(CtexHAfSL1bodO5zuBh8Kj6ypm)
				except Exception as kQhFMNbH2U:
					succeeded = mrhSYXH2P8bO3eJAa9n
					if showDialogs: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,str(kQhFMNbH2U))
			if t8VvFQa5gxyi:
				for dir in RhAx8igYHozFLQWUV:
					vzYbDMr8A7O = E2xjtKaMXdC3NDoTm7f5Wkev.path.join(IkTGuAPoFlsQbq,dir)
					try: E2xjtKaMXdC3NDoTm7f5Wkev.rmdir(vzYbDMr8A7O)
					except: pass
		if t8VvFQa5gxyi:
			try: E2xjtKaMXdC3NDoTm7f5Wkev.rmdir(IkTGuAPoFlsQbq)
			except: pass
	if showDialogs:
		if succeeded: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,l7kBpMw5Qn(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᐿ"))
		else: gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,DQIrVcKuY6bJv(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭ᑀ"))
	return succeeded
def r3jPAgNdhp(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6):
	qg7Nr1dCaD,WMKSy1qfGhFckpTawe2lE5,ooOMXGnTYPA81,sVXdfNbq3va7P = wwpNDOqdIZuUzTy5b7X(pfhH2objgVkI7eycn)
	Zth7i2v1xI6TKpcP = oHSdD2N140BnjWsOk,qg7Nr1dCaD,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81
	if pRF2UtDTMJwESfOhPde1y<zpx2fPNKk6Ms38eD1vcO(u"࠵ᘤ"):
		pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᑁ"),Zth7i2v1xI6TKpcP)
		pRF2UtDTMJwESfOhPde1y = -pRF2UtDTMJwESfOhPde1y
	if pRF2UtDTMJwESfOhPde1y>DQIrVcKuY6bJv(u"࠶ᘥ"):
		YD0R1z8ldmipE = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,DQIrVcKuY6bJv(u"࠭ࡳࡵࡴࠪᑂ"),DQIrVcKuY6bJv(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᑃ"),Zth7i2v1xI6TKpcP)
		if YD0R1z8ldmipE:
			gNEVvUpHfrcun0Q68(C3w6qluao7EzUxJgMGBtV(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭ᑄ"),pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6,oHSdD2N140BnjWsOk)
			return YD0R1z8ldmipE
	YD0R1z8ldmipE = nnyt5esYvlQ0zUZCJW4bgiAB2uxFL(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6)
	if YD0R1z8ldmipE and pRF2UtDTMJwESfOhPde1y: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,iDhLkZS6XBagNCQfs9tq2(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᑅ"),Zth7i2v1xI6TKpcP,YD0R1z8ldmipE,pRF2UtDTMJwESfOhPde1y)
	return YD0R1z8ldmipE
def ec9ywhrLSqmN87FMKIQPxOuoU(tfX4sO3hy2H1IbKG,kuDAhFqRBxCpSL75Ocb0VGozfgW6I,VLKTI6bAOf5cSglQrtWFxadoDj80e=wvkDqmNZlJU52isXo):
	LLicNOaQRov = MMAUZiw4CoJ8.getSetting(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧᑆ"))
	if LLicNOaQRov and Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫ࠲࠭ᑇ") not in LLicNOaQRov: qrvUApFodEiBV,CoHtXgrDlB = int(LLicNOaQRov),BBX9RAuxnyGZ4WIF2TrhYeom3
	elif VLKTI6bAOf5cSglQrtWFxadoDj80e: qrvUApFodEiBV,CoHtXgrDlB = VLKTI6bAOf5cSglQrtWFxadoDj80e,mrhSYXH2P8bO3eJAa9n
	else: return []
	JIl4QFLkRqnCgMtDazfx,zuOTXWVtxS = [],SebHIf2jL1TBgrMKJu
	wnmpQg9URdGOqIZAxbJSY4,BAD0JH72UV,NNS02rAZ1gKRYXhWzpBvIj4PxnbUaD,xxmnZ7YMLpXNzS4w5IRQEvGKgC = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo,wvkDqmNZlJU52isXo
	kuDAhFqRBxCpSL75Ocb0VGozfgW6I = sorted(kuDAhFqRBxCpSL75Ocb0VGozfgW6I,reverse=BBX9RAuxnyGZ4WIF2TrhYeom3,key=lambda key: (key[nyUIsfd53EGot9vbj0XDeq],key[JhTts2R43AxkM8bYanKVy]))
	for stream,s9OtJYphRLFm21,emIQYsN6huF in kuDAhFqRBxCpSL75Ocb0VGozfgW6I+[[SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo]]:
		if s9OtJYphRLFm21==zuOTXWVtxS:
			if emIQYsN6huF>qrvUApFodEiBV: BAD0JH72UV,xxmnZ7YMLpXNzS4w5IRQEvGKgC = stream,emIQYsN6huF
			elif not wnmpQg9URdGOqIZAxbJSY4: wnmpQg9URdGOqIZAxbJSY4,NNS02rAZ1gKRYXhWzpBvIj4PxnbUaD = stream,emIQYsN6huF
		else:
			if BAD0JH72UV or wnmpQg9URdGOqIZAxbJSY4:
				if wnmpQg9URdGOqIZAxbJSY4: JIl4QFLkRqnCgMtDazfx.append([wnmpQg9URdGOqIZAxbJSY4,zuOTXWVtxS,NNS02rAZ1gKRYXhWzpBvIj4PxnbUaD])
				elif BAD0JH72UV: JIl4QFLkRqnCgMtDazfx.append([BAD0JH72UV,zuOTXWVtxS,xxmnZ7YMLpXNzS4w5IRQEvGKgC])
			if emIQYsN6huF>qrvUApFodEiBV:
				BAD0JH72UV,xxmnZ7YMLpXNzS4w5IRQEvGKgC = stream,emIQYsN6huF
				wnmpQg9URdGOqIZAxbJSY4,NNS02rAZ1gKRYXhWzpBvIj4PxnbUaD = SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo
			else:
				BAD0JH72UV,xxmnZ7YMLpXNzS4w5IRQEvGKgC = SebHIf2jL1TBgrMKJu,wvkDqmNZlJU52isXo
				wnmpQg9URdGOqIZAxbJSY4,NNS02rAZ1gKRYXhWzpBvIj4PxnbUaD = stream,emIQYsN6huF
		zuOTXWVtxS = s9OtJYphRLFm21
	if CoHtXgrDlB:
		Vq39vIXOWoEugjTG5Cc4QJNkMy,xErea2hDBnkiIdLb3zsVQWjNm,l1GWo5YRcwZnBM = zip(*JIl4QFLkRqnCgMtDazfx)
		bivh0jwqdK1xkYep = [qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡳࡰ࠵ࠩᑈ"),fp6KV7DlS8QYniUczHdmZChL(u"࠭࡭ࡱࡦࠪᑉ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠧࡵࡵࠪᑊ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࡯࠶ࡹࠬᑋ")]
		for s9OtJYphRLFm21 in bivh0jwqdK1xkYep:
			if s9OtJYphRLFm21 in xErea2hDBnkiIdLb3zsVQWjNm:
				index = xErea2hDBnkiIdLb3zsVQWjNm.index(s9OtJYphRLFm21)
				JIl4QFLkRqnCgMtDazfx = [[Vq39vIXOWoEugjTG5Cc4QJNkMy[index],xErea2hDBnkiIdLb3zsVQWjNm[index],l1GWo5YRcwZnBM[index]]]
				break
	return JIl4QFLkRqnCgMtDazfx
def Lx9EoVFmp6PsyenMdBuOq23(K03lsMX2cU9IgNYenTZfm8S):
	Ef0RPFcwJO5k1,zGBPXhsgptE3O9 = [],UTvNakRFQC
	for GJ4kbYnxcHa6NIOuA7X20S in bHVThUqlANJkcY9DWLou1i:
		if GJ4kbYnxcHa6NIOuA7X20S==ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪᑌ"): zGBPXhsgptE3O9 = (cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡰ࡮ࡴ࡫ࠨᑍ"),E7r8hUCVvTiFQW0dBGXjxcy+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫᑎ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,uqLUBHepfM3l6AyIzTJh80a(u"࠱࠶࠹ᘦ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)
		elif GJ4kbYnxcHa6NIOuA7X20S==zpx2fPNKk6Ms38eD1vcO(u"ࠬࡓࡉ࡙ࡇࡇࠫᑏ"): zGBPXhsgptE3O9 = (NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭࡬ࡪࡰ࡮ࠫᑐ"),E7r8hUCVvTiFQW0dBGXjxcy+HCiWF4jV1Q8(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭ᑑ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,ypO63g8oJEsDnPBHSuU7lMTZr(u"࠲࠷࠺ᘧ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)
		elif GJ4kbYnxcHa6NIOuA7X20S==uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡒࡘࡆࡑࡏࡃࠨᑒ"): zGBPXhsgptE3O9 = (qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࡯࡭ࡳࡱࠧᑓ"),E7r8hUCVvTiFQW0dBGXjxcy+Izy1PvclrYx4eSVWn0L5phZbq(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪᑔ")+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,gCkRKGhwcx26v(u"࠳࠸࠻ᘨ"),SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu)
		if GJ4kbYnxcHa6NIOuA7X20S not in K03lsMX2cU9IgNYenTZfm8S: continue
		if zGBPXhsgptE3O9:
			Ef0RPFcwJO5k1.append(zGBPXhsgptE3O9)
			zGBPXhsgptE3O9 = UTvNakRFQC
		if GJ4kbYnxcHa6NIOuA7X20S not in [NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᑕ"),HCiWF4jV1Q8(u"ࠬࡓࡉ࡙ࡇࡇࠫᑖ"),sTGtHVyhQ9cJU37zxo2O(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ᑗ")]: Ef0RPFcwJO5k1.append(GJ4kbYnxcHa6NIOuA7X20S)
	return Ef0RPFcwJO5k1
def TgZvju0xEsR2MwJD5G(O2RtN4S3oXsvVxQLg0bfH,args=[]):
	MM9p0hKeJXwyYV2unERT4rN = {C3w6qluao7EzUxJgMGBtV(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᑘ"):xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᑙ")}
	tUw8zDnHEJAIBT2m6WL179ZChKk4,UTAZijHKcXWNrPsfJdz2yDx70nw,lR1iYbvTXdB8A9aNj4qOxehW7KFU = l7kBpMw5Qn(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨᑚ"),Ns6AJKH7DGpr19Wl5C3nF(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩᑛ"),int(uv8V4fE7j9pmgFr3wnDL.time())
	lXiGpMArTN3KaLb0zBvWc5tR8DmqFe = tUw8zDnHEJAIBT2m6WL179ZChKk4+hAd4IGxEFmnpwg+str(lR1iYbvTXdB8A9aNj4qOxehW7KFU)+xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV+UTAZijHKcXWNrPsfJdz2yDx70nw
	epc09LarU7XkVgqZjMnRhydH = Z9w7UrhMLl.md5(lXiGpMArTN3KaLb0zBvWc5tR8DmqFe.encode(uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡺࡺࡦ࠹ࠩᑜ"))).hexdigest()[:xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠶ᘩ")]
	llSo9A8mI35w = {ALwOspNtXxZrz3PEKku(u"ࠬࡰࡳࡤࡱࡧࡩࠬᑝ"):O2RtN4S3oXsvVxQLg0bfH,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡡࡳࡩࡶࠫᑞ"):args,gCkRKGhwcx26v(u"ࠧࡶࡵࡨࡶࠬᑟ"):hAd4IGxEFmnpwg,gCkRKGhwcx26v(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᑠ"):xchOLrvK1o6J8aYzR7Q5PAmBMSCsHV,HADrRCz9QgU4xudPJIqYb70(u"ࠩ࡬ࡨࡸ࠭ᑡ"):epc09LarU7XkVgqZjMnRhydH}
	oxbKrvMETlg2s = qFsuKN7ngp.SITESURLS[Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᑢ")][sTGtHVyhQ9cJU37zxo2O(u"࠵࠵ᘪ")]
	pMrPwuBbnz320QkxGHI7NqgsTjf9dt = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,TVnqDYzWoM2UfHp0dchJ(u"ࠫࡕࡕࡓࡕࠩᑣ"),oxbKrvMETlg2s,llSo9A8mI35w,MM9p0hKeJXwyYV2unERT4rN,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,DQIrVcKuY6bJv(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧᑤ"))
	fNoCvJActQs2lnKzPYdhSMy3 = pMrPwuBbnz320QkxGHI7NqgsTjf9dt.content
	return fNoCvJActQs2lnKzPYdhSMy3
def yG7NFviD5AJH(S1eOZmQNf8qChgLW5nFr7TXVKMy,timeout,H67HMuy2CJ14NZFeg3W,nOHkJPpb47cwMAiyuRNX6S,FFpy2WQ1r0AqV):
	ZsWnthFi6JzbyGxX = mrhSYXH2P8bO3eJAa9n
	for rrz2yFwQfuVnAqmexEs5 in S1eOZmQNf8qChgLW5nFr7TXVKMy:
		rrz2yFwQfuVnAqmexEs5.start()
		uv8V4fE7j9pmgFr3wnDL.sleep(H67HMuy2CJ14NZFeg3W)
		ZsWnthFi6JzbyGxX = FFpy2WQ1r0AqV()
		if ZsWnthFi6JzbyGxX: break
	else:
		dcRX6Q98n4hySqVC2Yo = int(timeout-len(S1eOZmQNf8qChgLW5nFr7TXVKMy)*H67HMuy2CJ14NZFeg3W)
		if dcRX6Q98n4hySqVC2Yo>wvkDqmNZlJU52isXo:
			for fNnuAzFsXhBKCco9JZeVUvd7Ya in range(dcRX6Q98n4hySqVC2Yo//nOHkJPpb47cwMAiyuRNX6S):
				uv8V4fE7j9pmgFr3wnDL.sleep(nOHkJPpb47cwMAiyuRNX6S)
				ZsWnthFi6JzbyGxX = FFpy2WQ1r0AqV()
				if ZsWnthFi6JzbyGxX: break
	for rrz2yFwQfuVnAqmexEs5 in S1eOZmQNf8qChgLW5nFr7TXVKMy:
		try: rrz2yFwQfuVnAqmexEs5.join(H67HMuy2CJ14NZFeg3W)
		except: pass
	return ZsWnthFi6JzbyGxX
def L89QpfNav5RrOZXYqliW(jAkyVvZYFCle4PUHzWJX=NMobgjvE4Y6IxqhD8zPyaOk):
	p14ptSMxr9EbQnJFqN8Thuc37I6v0e = iDhLkZS6XBagNCQfs9tq2(u"࠶࠶࠲࠵ᘫ")
	ggMBbEjLNFcKtIleiCrsn0GhaVv = wvkDqmNZlJU52isXo
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv:
		try:
			import shutil as O5Gn9E2VcrXQf1lAtmoKBUqbIR4
			ggMBbEjLNFcKtIleiCrsn0GhaVv = O5Gn9E2VcrXQf1lAtmoKBUqbIR4.disk_usage(jAkyVvZYFCle4PUHzWJX).free
		except: pass
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv and hasattr(E2xjtKaMXdC3NDoTm7f5Wkev,fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡳࡵࡣࡷࡺ࡫ࡹࠧᑥ")):
		try:
			eWC9JR2bPySXnvYk = E2xjtKaMXdC3NDoTm7f5Wkev.statvfs(jAkyVvZYFCle4PUHzWJX)
			ggMBbEjLNFcKtIleiCrsn0GhaVv = eWC9JR2bPySXnvYk.f_frsize * eWC9JR2bPySXnvYk.f_bavail
		except: pass
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv and hasattr(E2xjtKaMXdC3NDoTm7f5Wkev,TVnqDYzWoM2UfHp0dchJ(u"ࠧࡧࡵࡷࡥࡹࡼࡦࡴࠩᑦ")):
		try:
			eWC9JR2bPySXnvYk = E2xjtKaMXdC3NDoTm7f5Wkev.fstatvfs(jAkyVvZYFCle4PUHzWJX)
			ggMBbEjLNFcKtIleiCrsn0GhaVv = eWC9JR2bPySXnvYk.f_frsize * eWC9JR2bPySXnvYk.f_bavail
		except: pass
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv and yMqHPpxSEAFIwKecXdi40r8zL53.platform == uqLUBHepfM3l6AyIzTJh80a(u"ࠨࡹ࡬ࡲ࠸࠸ࠧᑧ"):
		try:
			import ctypes as fzbr7gslInjN019yT5oYEwBS4i
			vykmiBIZbHGoM4cD2jdw73TVleu = fzbr7gslInjN019yT5oYEwBS4i.c_ulonglong(wvkDqmNZlJU52isXo)
			fzbr7gslInjN019yT5oYEwBS4i.windll.kernel32.GetDiskFreeSpaceExW(fzbr7gslInjN019yT5oYEwBS4i.c_wchar_p(jAkyVvZYFCle4PUHzWJX),None,None,fzbr7gslInjN019yT5oYEwBS4i.pointer(vykmiBIZbHGoM4cD2jdw73TVleu))
			ggMBbEjLNFcKtIleiCrsn0GhaVv = vykmiBIZbHGoM4cD2jdw73TVleu.value
		except: pass
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv:
		try:
			YvQsw9hHf5ILrnVT4xcJPpjBt = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel(zpx2fPNKk6Ms38eD1vcO(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬᑨ"))
			QkzH0aLCMlAWBZ = X2XorVqHjLkWeCchY4u9fSz.findall(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡠࡩ࠱ࠨࡀ࠼࡟࠲ࡡࡪࠫࠪࡁࠪᑩ"),YvQsw9hHf5ILrnVT4xcJPpjBt,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if QkzH0aLCMlAWBZ:
				QkzH0aLCMlAWBZ = float(QkzH0aLCMlAWBZ[ASkvf27etUK0(u"࠶ᘬ")])
				if   czvu7VQCZodkMf(u"࡙ࠫ࠭ᑪ") in YvQsw9hHf5ILrnVT4xcJPpjBt: ggMBbEjLNFcKtIleiCrsn0GhaVv = QkzH0aLCMlAWBZ*p14ptSMxr9EbQnJFqN8Thuc37I6v0e**K7cnfQMS6BPvI4LGmCsRp8bUlJ9
				elif ASkvf27etUK0(u"ࠬࡍࠧᑫ") in YvQsw9hHf5ILrnVT4xcJPpjBt: ggMBbEjLNFcKtIleiCrsn0GhaVv = QkzH0aLCMlAWBZ*p14ptSMxr9EbQnJFqN8Thuc37I6v0e**fuCbjVag7vU908J2Yqx5Th
				elif Izy1PvclrYx4eSVWn0L5phZbq(u"࠭ࡍࠨᑬ") in YvQsw9hHf5ILrnVT4xcJPpjBt: ggMBbEjLNFcKtIleiCrsn0GhaVv = QkzH0aLCMlAWBZ*p14ptSMxr9EbQnJFqN8Thuc37I6v0e**JhTts2R43AxkM8bYanKVy
				elif Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡌࠩᑭ") in YvQsw9hHf5ILrnVT4xcJPpjBt: ggMBbEjLNFcKtIleiCrsn0GhaVv = QkzH0aLCMlAWBZ*p14ptSMxr9EbQnJFqN8Thuc37I6v0e
				else: ggMBbEjLNFcKtIleiCrsn0GhaVv = QkzH0aLCMlAWBZ
		except: pass
	if not ggMBbEjLNFcKtIleiCrsn0GhaVv: ggMBbEjLNFcKtIleiCrsn0GhaVv = Izy1PvclrYx4eSVWn0L5phZbq(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ᘭ")
	return int(ggMBbEjLNFcKtIleiCrsn0GhaVv)
def loygsJjU3Yv5OQ6(AKxLVCjqYbBQ2WUGtgsovmfkS9lD7):
	if AKxLVCjqYbBQ2WUGtgsovmfkS9lD7:
		ss8iea1XS5Ru03PcHTyMhDx6ApnGd = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨ࡮࡬ࡷࡹ࠭ᑮ"),DQIrVcKuY6bJv(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᑯ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨᑰ"))
		if ss8iea1XS5Ru03PcHTyMhDx6ApnGd: return ss8iea1XS5Ru03PcHTyMhDx6ApnGd
	BXupmlPQvMIrweKqkG = {fp6KV7DlS8QYniUczHdmZChL(u"ࠫࡦ࠭ᑱ"):czvu7VQCZodkMf(u"ࠬࡧࠧᑲ")}
	url = qFsuKN7ngp.SITESURLS[sTGtHVyhQ9cJU37zxo2O(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᑳ")][nyUIsfd53EGot9vbj0XDeq]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,iDhLkZS6XBagNCQfs9tq2(u"ࠧࡑࡑࡖࡘࠬᑴ"),url,BXupmlPQvMIrweKqkG,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ALwOspNtXxZrz3PEKku(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡋࡊ࡚࡟ࡔࡋࡗࡉࡘࡥࡕࡔࡃࡊࡉ࠲࠷ࡳࡵࠩᑵ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩᑶ"),iDhLkZS6XBagNCQfs9tq2(u"࡙ࠪࡘࡇࠧᑷ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(wPnfgxKZdAv6T10(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬᑸ"),VOALf8iYEnMdK0g(u"࡛ࠬࡋࠨᑹ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(wPnfgxKZdAv6T10(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ᑺ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡖࡃࡈࠫᑻ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(HADrRCz9QgU4xudPJIqYb70(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧᑼ"),ASkvf27etUK0(u"ࠩࡎࡗࡆ࠭ᑽ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᑾ"),AGlW9LqKN3Dvo(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩᑿ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(gCkRKGhwcx26v(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ᒀ"),TVnqDYzWoM2UfHp0dchJ(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨᒁ"))
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = LCK8lO2yRWaTVEQcdjPXAzpFBe9.replace(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡠࡡࡢࠫᒂ"),nlNC2gJDBZMed63TxqphA1vrXm8Hy)
	try: vdLsc2f3YDuFkUTQGebtNOE = xjVJ0o7mF86tCDagkbNcrTAR4UH(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨ࡮࡬ࡷࡹ࠭ᒃ"),LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	except:
		gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,wPnfgxKZdAv6T10(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩᒄ"))
		return
	icmGsqgVjIS,SmxUkp9wI3A1gq6R0t,uYCdL4nB6JQryG3MfxaF9XoUR2S = vdLsc2f3YDuFkUTQGebtNOE
	ttjvKC04GzV9duIJ,RR36tXfUo9zI7DpeGawqbMv = [],[]
	for GJ4kbYnxcHa6NIOuA7X20S,IKFNtUcgWwALu9o,ffyuLams8KJojGh9SlT3nBzNg in SmxUkp9wI3A1gq6R0t:
		if IKFNtUcgWwALu9o.isdigit(): IKFNtUcgWwALu9o = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ᒅ") if int(IKFNtUcgWwALu9o)>xxRyYsrSCzjifvH4cIqgldeOo(u"࠶࠲ᘮ") else bcNqYtfET5l92dLGjyZSPe(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭ᒆ")
		if GJ4kbYnxcHa6NIOuA7X20S not in qFsuKN7ngp.non_videos_actions:
			if   IKFNtUcgWwALu9o==czvu7VQCZodkMf(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᒇ"): ttjvKC04GzV9duIJ.append(GJ4kbYnxcHa6NIOuA7X20S)
			elif IKFNtUcgWwALu9o==ALwOspNtXxZrz3PEKku(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᒈ"): RR36tXfUo9zI7DpeGawqbMv.append(GJ4kbYnxcHa6NIOuA7X20S)
	pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᒉ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡕࡌࡘࡊ࡙࡟ࡖࡕࡄࡋࡊ࠭ᒊ"),[vdLsc2f3YDuFkUTQGebtNOE,ttjvKC04GzV9duIJ,RR36tXfUo9zI7DpeGawqbMv],QfG1xIZ4hpq3ezPXt7VbvglUcB)
	return vdLsc2f3YDuFkUTQGebtNOE,ttjvKC04GzV9duIJ,RR36tXfUo9zI7DpeGawqbMv
def WMx8v0FVCjlhcQKRwdX1s(pRF2UtDTMJwESfOhPde1y,oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J=SebHIf2jL1TBgrMKJu,Cft4OB0gVpiLcwz8Won=SebHIf2jL1TBgrMKJu):
	if qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠩ࠽࠾ࠬᒋ") in oHSdD2N140BnjWsOk: oHSdD2N140BnjWsOk,kpiJl1MHXD5 = oHSdD2N140BnjWsOk.split(TVnqDYzWoM2UfHp0dchJ(u"ࠪ࠾࠿࠭ᒌ"))
	else: oHSdD2N140BnjWsOk,kpiJl1MHXD5 = oHSdD2N140BnjWsOk,czvu7VQCZodkMf(u"ࠫࠬᒍ")
	qg7Nr1dCaD,WMKSy1qfGhFckpTawe2lE5,ooOMXGnTYPA81,sVXdfNbq3va7P = wwpNDOqdIZuUzTy5b7X(pfhH2objgVkI7eycn)
	gn8cDhTyKj5d = gTnyji0CwRW81.copy() if isinstance(gTnyji0CwRW81,dict) else gTnyji0CwRW81
	Zth7i2v1xI6TKpcP = oHSdD2N140BnjWsOk,qg7Nr1dCaD,qqTB9mr0Av7jKg3UOYzLl,gn8cDhTyKj5d,h1uNjAk9KeCHWQcJy
	if pRF2UtDTMJwESfOhPde1y<wvkDqmNZlJU52isXo:
		pk7IJW8X5Zo(E8Eo9FKSM5bhgRYlCWZHqPmt,czvu7VQCZodkMf(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᒎ"),Zth7i2v1xI6TKpcP)
		pRF2UtDTMJwESfOhPde1y = -pRF2UtDTMJwESfOhPde1y
	if pRF2UtDTMJwESfOhPde1y>wvkDqmNZlJU52isXo:
		Vq3XpLGKo4zlSR59wBrhjAbcamJDie = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,l7kBpMw5Qn(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᒏ"),Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᒐ"),Zth7i2v1xI6TKpcP)
		if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
			gNEVvUpHfrcun0Q68(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᒑ"),qg7Nr1dCaD,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,qh4B9VQZCbXr0DRknFmi7J6,oHSdD2N140BnjWsOk)
			return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
	if kpiJl1MHXD5==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࠫᒒ"): Vq3XpLGKo4zlSR59wBrhjAbcamJDie = UqgKptMNenkfsTYxFBzGSr(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6)
	else: Vq3XpLGKo4zlSR59wBrhjAbcamJDie = KXpxBQE2LP(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J,Cft4OB0gVpiLcwz8Won)
	if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.succeeded:
		if Ns6AJKH7DGpr19Wl5C3nF(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᒓ") in qh4B9VQZCbXr0DRknFmi7J6: Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content = mg6jxoaQdJXcyV2Ri5tPp7AO3DKf(Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content,wPnfgxKZdAv6T10(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࡤࡎࡔࡎࡎࡢࡩࡳࡩ࡯ࡥࡧࡵࠫᒔ"))
		if Vq3XpLGKo4zlSR59wBrhjAbcamJDie.scrape: pRF2UtDTMJwESfOhPde1y = iHR47eol8wB3Z
		if pRF2UtDTMJwESfOhPde1y and Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content: pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,bcNqYtfET5l92dLGjyZSPe(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᒕ"),Zth7i2v1xI6TKpcP,Vq3XpLGKo4zlSR59wBrhjAbcamJDie,pRF2UtDTMJwESfOhPde1y)
	return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
def nkRZesXDW9610JvGEaYjwzb(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,data,headers,allow_redirects,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J,Cft4OB0gVpiLcwz8Won):
	if data==SebHIf2jL1TBgrMKJu: data = {}
	if headers==SebHIf2jL1TBgrMKJu: headers = {}
	DJxFmjpI2U6SzRG = BBX9RAuxnyGZ4WIF2TrhYeom3 if allow_redirects in [SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3] else mrhSYXH2P8bO3eJAa9n
	dN1yCrxi3FXHS = BBX9RAuxnyGZ4WIF2TrhYeom3 if showDialogs in [SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3] else mrhSYXH2P8bO3eJAa9n
	nDFrWsp5qN = BBX9RAuxnyGZ4WIF2TrhYeom3 if TTXV9lZ8qW6G4J in [SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3] else mrhSYXH2P8bO3eJAa9n
	VsyuARB7wrIa1zmphWxGHo0 = BBX9RAuxnyGZ4WIF2TrhYeom3 if Cft4OB0gVpiLcwz8Won in [SebHIf2jL1TBgrMKJu,BBX9RAuxnyGZ4WIF2TrhYeom3] else mrhSYXH2P8bO3eJAa9n
	bIGXajdcK6PQBs = data
	REIkboX9NtlZCSU3A = headers
	dN1yCrxi3FXHS = dN1yCrxi3FXHS if qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX==UTvNakRFQC else qFsuKN7ngp.ALLOW_SHOWDIALOGS_FIX
	nDFrWsp5qN = nDFrWsp5qN if qFsuKN7ngp.ALLOW_DNS_FIX==UTvNakRFQC else qFsuKN7ngp.ALLOW_DNS_FIX
	VsyuARB7wrIa1zmphWxGHo0 = VsyuARB7wrIa1zmphWxGHo0 if qFsuKN7ngp.ALLOW_PROXY_FIX==UTvNakRFQC else qFsuKN7ngp.ALLOW_PROXY_FIX
	if qh4B9VQZCbXr0DRknFmi7J6==DQIrVcKuY6bJv(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡋࡑࡗ࡙ࡇࡌࡍࡡࡒࡐࡉࡥࡒࡆࡎࡈࡅࡘࡋ࠭࠲ࡵࡷࠫᒖ"): REIkboX9NtlZCSU3A = {}
	else:
		zE4rynh3GOm = list(REIkboX9NtlZCSU3A.keys())
		if ALwOspNtXxZrz3PEKku(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᒗ") not in zE4rynh3GOm: REIkboX9NtlZCSU3A[ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᒘ")] = gCkRKGhwcx26v(u"ࠩ࡫ࡸࡹࡶࠧᒙ")
		if AGlW9LqKN3Dvo(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᒚ") not in zE4rynh3GOm: REIkboX9NtlZCSU3A[VOALf8iYEnMdK0g(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᒛ")] = b6rmBauMc3HqTev0t(BBX9RAuxnyGZ4WIF2TrhYeom3)
	return oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,nDFrWsp5qN,VsyuARB7wrIa1zmphWxGHo0
def KXpxBQE2LP(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J=SebHIf2jL1TBgrMKJu,Cft4OB0gVpiLcwz8Won=SebHIf2jL1TBgrMKJu):
	zYqMXwfDLRNxWPIZ3o91H6b0 = nkRZesXDW9610JvGEaYjwzb(oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,showDialogs,qh4B9VQZCbXr0DRknFmi7J6,TTXV9lZ8qW6G4J,Cft4OB0gVpiLcwz8Won)
	oHSdD2N140BnjWsOk,pfhH2objgVkI7eycn,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,nDFrWsp5qN,VsyuARB7wrIa1zmphWxGHo0 = zYqMXwfDLRNxWPIZ3o91H6b0
	qg7Nr1dCaD,WMKSy1qfGhFckpTawe2lE5,ooOMXGnTYPA81,sVXdfNbq3va7P = wwpNDOqdIZuUzTy5b7X(pfhH2objgVkI7eycn)
	tbjSgf4uz78qdrAvkxLiRhMcwQ = MMAUZiw4CoJ8.getSetting(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬᒜ"))
	r2wm0BOAUYz7faosk5L1 = MMAUZiw4CoJ8.getSetting(Ns6AJKH7DGpr19Wl5C3nF(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᒝ"))
	MNueRG4Cz8D2TQFBhSXxianlj1AtO = MMAUZiw4CoJ8.getSetting(sTGtHVyhQ9cJU37zxo2O(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᒞ"))
	jPGJ5x23Fzb0QCq7Ol4YMu = [cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶࠫᒟ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᒠ"),ALwOspNtXxZrz3PEKku(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨᒡ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫᒢ"),gCkRKGhwcx26v(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧᒣ"),DQIrVcKuY6bJv(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰࠩᒤ")]
	Q9OcWd0I6f = BBX9RAuxnyGZ4WIF2TrhYeom3 if any(value in pfhH2objgVkI7eycn for value in jPGJ5x23Fzb0QCq7Ol4YMu) else mrhSYXH2P8bO3eJAa9n
	if Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࠧࡷࡵࡰࡂ࠭ᒥ") in qg7Nr1dCaD and Q9OcWd0I6f: gdOAzT9FrUpkML1yJuf5Kc4iP = qg7Nr1dCaD.rsplit(fp6KV7DlS8QYniUczHdmZChL(u"ࠨࠨࡸࡶࡱࡃࠧᒦ"),nyUIsfd53EGot9vbj0XDeq)[nyUIsfd53EGot9vbj0XDeq]
	else: gdOAzT9FrUpkML1yJuf5Kc4iP = SebHIf2jL1TBgrMKJu
	I82FyjGuxqRH0wadACToEYPfbUVNe = qFsuKN7ngp.SITESURLS[bcNqYtfET5l92dLGjyZSPe(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᒧ")]
	TQgoVIpwAjq6l = qg7Nr1dCaD in I82FyjGuxqRH0wadACToEYPfbUVNe or gdOAzT9FrUpkML1yJuf5Kc4iP in I82FyjGuxqRH0wadACToEYPfbUVNe
	sca62gS5iCWAr4we7uMPp = qFsuKN7ngp.SITESURLS[ASkvf27etUK0(u"ࠪࡖࡊࡖࡏࡔࠩᒨ")]
	zBas86vVUg30ldLYhKo2Dm = qg7Nr1dCaD in sca62gS5iCWAr4we7uMPp or gdOAzT9FrUpkML1yJuf5Kc4iP in sca62gS5iCWAr4we7uMPp
	I9EF3ZbmzWgqM8JLGwsdkAjhTuyae = TQgoVIpwAjq6l or zBas86vVUg30ldLYhKo2Dm
	aaKxjiJWrm4Io0wU = mrhSYXH2P8bO3eJAa9n
	TeqLPpbG5OR7Ztl01jCrfAa2EY6NvU = BBX9RAuxnyGZ4WIF2TrhYeom3
	OP5dj4YLRU13a6X = WMKSy1qfGhFckpTawe2lE5==None and ooOMXGnTYPA81==None and not Q9OcWd0I6f
	if OP5dj4YLRU13a6X and I9EF3ZbmzWgqM8JLGwsdkAjhTuyae:
		if TQgoVIpwAjq6l:
			ckVelEQImGd = I82FyjGuxqRH0wadACToEYPfbUVNe.index(qg7Nr1dCaD)
			JmnxlP9N1z3e8IjoTEOYh = qFsuKN7ngp.SITESURLS[AGlW9LqKN3Dvo(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩᒩ")][ckVelEQImGd]
			tlL01Pyq4FQxp = qFsuKN7ngp.SITESURLS[qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪᒪ")][ckVelEQImGd]
			M7MJCgyIQDYZiuTRFKsj59mH = qFsuKN7ngp.SITESURLS[ALwOspNtXxZrz3PEKku(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫᒫ")][ckVelEQImGd]
			QUWsbGoFmngMKlTpz7id = qFsuKN7ngp.api_python_actions[ckVelEQImGd]
			if QUWsbGoFmngMKlTpz7id==fp6KV7DlS8QYniUczHdmZChL(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩᒬ"): nDFrWsp5qN,VsyuARB7wrIa1zmphWxGHo0,TeqLPpbG5OR7Ztl01jCrfAa2EY6NvU = mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n
			elif QUWsbGoFmngMKlTpz7id==TVnqDYzWoM2UfHp0dchJ(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᒭ"): aaKxjiJWrm4Io0wU = BBX9RAuxnyGZ4WIF2TrhYeom3
		elif zBas86vVUg30ldLYhKo2Dm:
			ckVelEQImGd = sca62gS5iCWAr4we7uMPp.index(qg7Nr1dCaD)
			JmnxlP9N1z3e8IjoTEOYh = qFsuKN7ngp.SITESURLS[t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠶࠭ᒮ")][ckVelEQImGd]
			tlL01Pyq4FQxp = qFsuKN7ngp.SITESURLS[sTGtHVyhQ9cJU37zxo2O(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧᒯ")][ckVelEQImGd]
			M7MJCgyIQDYZiuTRFKsj59mH = qFsuKN7ngp.SITESURLS[Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠳ࠨᒰ")][ckVelEQImGd]
			QUWsbGoFmngMKlTpz7id = qFsuKN7ngp.api_repos_actions[ckVelEQImGd]
	if ooOMXGnTYPA81==SebHIf2jL1TBgrMKJu: ooOMXGnTYPA81 = tbjSgf4uz78qdrAvkxLiRhMcwQ
	elif ooOMXGnTYPA81==None and r2wm0BOAUYz7faosk5L1 in [HCiWF4jV1Q8(u"ࠬࡇࡕࡕࡑࠪᒱ"),C3w6qluao7EzUxJgMGBtV(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᒲ")] and nDFrWsp5qN: ooOMXGnTYPA81 = tbjSgf4uz78qdrAvkxLiRhMcwQ
	if TQgoVIpwAjq6l or zBas86vVUg30ldLYhKo2Dm: EXNR98wTJuhj = uqLUBHepfM3l6AyIzTJh80a(u"࠴࠳ᘯ")
	elif Q9OcWd0I6f: EXNR98wTJuhj = tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠹࠴ᘰ")
	elif qh4B9VQZCbXr0DRknFmi7J6 in m7x2zfI5LH39BkU: EXNR98wTJuhj = wPnfgxKZdAv6T10(u"࠵࠵ᘱ")
	elif qh4B9VQZCbXr0DRknFmi7J6==HCiWF4jV1Q8(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒳ"): EXNR98wTJuhj = t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠷࠶ᘲ")
	elif qh4B9VQZCbXr0DRknFmi7J6==HADrRCz9QgU4xudPJIqYb70(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒴ"): EXNR98wTJuhj = DQIrVcKuY6bJv(u"࠸࠰ᘳ")
	elif gCkRKGhwcx26v(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫᒵ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠷࠱ᘴ")
	elif NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠪࡗࡍࡕࡆࡉࡃࠪᒶ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = Izy1PvclrYx4eSVWn0L5phZbq(u"࠸࠷ᘵ")
	elif cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫᒷ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = uqLUBHepfM3l6AyIzTJh80a(u"࠴࠸ᘶ")
	elif gCkRKGhwcx26v(u"ࠬࡇࡈࡘࡃࡎࠫᒸ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = czvu7VQCZodkMf(u"࠵࠴ᘷ")
	elif fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᒹ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = sTGtHVyhQ9cJU37zxo2O(u"࠶࠵ᘸ")
	elif zpx2fPNKk6Ms38eD1vcO(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ᒺ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠸࠶ᘹ")
	elif j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠨࡃࡎࡓࡆࡓࠧᒻ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠸࠵ᘺ")
	elif iDhLkZS6XBagNCQfs9tq2(u"ࠩࡄࡏ࡜ࡇࡍࠨᒼ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = HADrRCz9QgU4xudPJIqYb70(u"࠳࠱ᘻ")
	elif j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᒽ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = qeYIw0BNTL9bGJnosacQ1DtVR(u"࠳࠲ᘼ")
	elif wPnfgxKZdAv6T10(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ᒾ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = DQIrVcKuY6bJv(u"࠸࠳ᘽ")
	elif gCkRKGhwcx26v(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧᒿ") in qh4B9VQZCbXr0DRknFmi7J6: EXNR98wTJuhj = czvu7VQCZodkMf(u"࠷࠴ᘾ")
	else: EXNR98wTJuhj = C3w6qluao7EzUxJgMGBtV(u"࠵࠺ᘿ")
	XLY9HF6hmec0o = (WMKSy1qfGhFckpTawe2lE5!=None)
	OgxmZDYiM6q3UbCvPhy48QuX = (ooOMXGnTYPA81!=None and r2wm0BOAUYz7faosk5L1!=uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡓࡕࡑࡓࠫᓀ"))
	if XLY9HF6hmec0o and not Q9OcWd0I6f: i9yzUqgAW2Zap1h4Lm(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧหใ฼๎้ࠦศา๊ๆื๏ࠦัใ็ࠪᓁ"),WMKSy1qfGhFckpTawe2lE5)
	elif OgxmZDYiM6q3UbCvPhy48QuX: i9yzUqgAW2Zap1h4Lm(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠨฬไ฽๏๊ࠠࡅࡐࡖࠤึ่ๅࠨᓂ"),ooOMXGnTYPA81)
	if XLY9HF6hmec0o:
		Dwr8HRjSeX = {bcNqYtfET5l92dLGjyZSPe(u"ࠤ࡫ࡸࡹࡶࠢᓃ"):WMKSy1qfGhFckpTawe2lE5,cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠥ࡬ࡹࡺࡰࡴࠤᓄ"):WMKSy1qfGhFckpTawe2lE5}
		MDI8kepoh0m = WMKSy1qfGhFckpTawe2lE5
	else: Dwr8HRjSeX,MDI8kepoh0m = {},SebHIf2jL1TBgrMKJu
	if OgxmZDYiM6q3UbCvPhy48QuX:
		import urllib3.util.connection as ofSjvyFl1zIx
		NApMnG3QlV9Y5s2tRzhEqfWv8I1 = IbCEgvyprwhM08u3RJLUl6q9O1S(ofSjvyFl1zIx,tbjSgf4uz78qdrAvkxLiRhMcwQ,BBX9RAuxnyGZ4WIF2TrhYeom3)
	NNImzA1uokhPeSrBLdsDHwEqMU2lK6,yFUtCXfqId,r1spDEX3MRQzFtmoJlOTLvV4yqxU7,bidX1q0Me5tKC7Yv98BAHrQGZLV,w50bYA8L7lvs,irHaOSRfz5c1TgJQ2EX,verify = DJxFmjpI2U6SzRG,qh4B9VQZCbXr0DRknFmi7J6,oHSdD2N140BnjWsOk,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n,mrhSYXH2P8bO3eJAa9n,sVXdfNbq3va7P
	if aaKxjiJWrm4Io0wU: w50bYA8L7lvs = BBX9RAuxnyGZ4WIF2TrhYeom3
	if I9EF3ZbmzWgqM8JLGwsdkAjhTuyae or DJxFmjpI2U6SzRG: NNImzA1uokhPeSrBLdsDHwEqMU2lK6 = mrhSYXH2P8bO3eJAa9n
	bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = -nyUIsfd53EGot9vbj0XDeq,Gykx0wL3XrlWaujsqKP9n2Q(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫᓅ")
	pZEIXTrQyjbgU = mrhSYXH2P8bO3eJAa9n
	if not qFsuKN7ngp.FORWARDS_HOSTNAMES: qFsuKN7ngp.FORWARDS_HOSTNAMES = xVYs5tfGpcvz1Br4Sel(E8Eo9FKSM5bhgRYlCWZHqPmt,ALwOspNtXxZrz3PEKku(u"ࠬࡪࡩࡤࡶࠪᓆ"),gCkRKGhwcx26v(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠵ࠫᓇ"),qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᓈ"))
	CoH1KMEFy6A0j = []
	while qg7Nr1dCaD not in CoH1KMEFy6A0j and qg7Nr1dCaD in list(qFsuKN7ngp.FORWARDS_HOSTNAMES.keys()):
		CoH1KMEFy6A0j.append(qg7Nr1dCaD)
		qg7Nr1dCaD = qFsuKN7ngp.FORWARDS_HOSTNAMES[qg7Nr1dCaD]
	r2DznEpvjQV5TNoCdZ0q = bIGXajdcK6PQBs
	if TQgoVIpwAjq6l:
		r1spDEX3MRQzFtmoJlOTLvV4yqxU7 = Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡒࡒࡗ࡙࠭ᓉ")
		REIkboX9NtlZCSU3A[xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡄ࡚࠲ࡋ࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᓊ")] = uqLUBHepfM3l6AyIzTJh80a(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᓋ")
		xoK7MXLeQVkD = ddWZPUnz9Cljm.dumps(bIGXajdcK6PQBs)
		r2DznEpvjQV5TNoCdZ0q = B1BD67cV8sYopU24Wrhxw(xoK7MXLeQVkD,Izy1PvclrYx4eSVWn0L5phZbq(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ᙀ"))
		qg7Nr1dCaD = qg7Nr1dCaD+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠫࡄࡻࡳࡦࡴࡀࠫᓌ")+hAd4IGxEFmnpwg
	import requests as GQHhfr5kocClg6
	for XM3KUmO1QJxlv84bgFTHsjdNt0kYq in range(Gykx0wL3XrlWaujsqKP9n2Q(u"࠿ᙁ")):
		Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
		if XM3KUmO1QJxlv84bgFTHsjdNt0kYq:
			yFUtCXfqId = fp6KV7DlS8QYniUczHdmZChL(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭ᓍ")
			try: Vq3XpLGKo4zlSR59wBrhjAbcamJDie.close()
			except: pass
		if Q9OcWd0I6f or not XLY9HF6hmec0o: gNEVvUpHfrcun0Q68(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓ࡝ࡶࡒࡔࡊࡔ࡟ࡖࡔࡏࠫᓎ"),qg7Nr1dCaD,r2DznEpvjQV5TNoCdZ0q,REIkboX9NtlZCSU3A,yFUtCXfqId,r1spDEX3MRQzFtmoJlOTLvV4yqxU7)
		iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD
		try:
			Vq3XpLGKo4zlSR59wBrhjAbcamJDie = GQHhfr5kocClg6.request(r1spDEX3MRQzFtmoJlOTLvV4yqxU7,qg7Nr1dCaD,data=r2DznEpvjQV5TNoCdZ0q,headers=REIkboX9NtlZCSU3A,verify=verify,allow_redirects=NNImzA1uokhPeSrBLdsDHwEqMU2lK6,timeout=EXNR98wTJuhj,proxies=Dwr8HRjSeX)
			if ypO63g8oJEsDnPBHSuU7lMTZr(u"࠳࠱࠲ᙂ")<=Vq3XpLGKo4zlSR59wBrhjAbcamJDie.status_code<=C3w6qluao7EzUxJgMGBtV(u"࠴࠻࠼ᙃ"):
				if not bidX1q0Me5tKC7Yv98BAHrQGZLV:
					cOn6JqZlmQbjtT = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers.get(qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᓏ")) or Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers.get(vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᓐ")) or SebHIf2jL1TBgrMKJu
					if cOn6JqZlmQbjtT: qg7Nr1dCaD = cOn6JqZlmQbjtT.strip(HCiWF4jV1Q8(u"ࠩ࠽ࠫᓑ"))
					else: bidX1q0Me5tKC7Yv98BAHrQGZLV = BBX9RAuxnyGZ4WIF2TrhYeom3
					if not bidX1q0Me5tKC7Yv98BAHrQGZLV: qg7Nr1dCaD = qg7Nr1dCaD.encode(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᓒ"),AGlW9LqKN3Dvo(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᓓ")).decode(Tv08xsf9HOqunIVUPdK1,j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᓔ"))
					if I9EF3ZbmzWgqM8JLGwsdkAjhTuyae and Vq3XpLGKo4zlSR59wBrhjAbcamJDie.status_code==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠵࠳࠻ᙄ"):
						NNImzA1uokhPeSrBLdsDHwEqMU2lK6 = DJxFmjpI2U6SzRG
						r1spDEX3MRQzFtmoJlOTLvV4yqxU7 = oHSdD2N140BnjWsOk
						bidX1q0Me5tKC7Yv98BAHrQGZLV = BBX9RAuxnyGZ4WIF2TrhYeom3
						J6HMml49YfaN0GD
				if not bidX1q0Me5tKC7Yv98BAHrQGZLV or DJxFmjpI2U6SzRG:
					if ASkvf27etUK0(u"࠭ࡨࡵࡶࡳࠫᓕ") not in qg7Nr1dCaD:
						CCmUps0BYLihTRoxWtnOdgfuF = EDmwsQf1Px9k8h04oAHuObdnyrTGU(iGxH2fsuScPtkJb7ECg,C3w6qluao7EzUxJgMGBtV(u"ࠧࡶࡴ࡯ࠫᓖ"))
						qg7Nr1dCaD = CCmUps0BYLihTRoxWtnOdgfuF+TVnqDYzWoM2UfHp0dchJ(u"ࠨ࠱ࠪᓗ")+qg7Nr1dCaD.lstrip(HCiWF4jV1Q8(u"ࠩ࠲ࠫᓘ"))
				if qg7Nr1dCaD!=iGxH2fsuScPtkJb7ECg:
					qFsuKN7ngp.FORWARDS_HOSTNAMES[iGxH2fsuScPtkJb7ECg] = qg7Nr1dCaD
					pZEIXTrQyjbgU = BBX9RAuxnyGZ4WIF2TrhYeom3
				if not bidX1q0Me5tKC7Yv98BAHrQGZLV:
					M7ecDnvPI5BOtyXs = Vq3XpLGKo4zlSR59wBrhjAbcamJDie
					if j1HGJPrFA3tTfLxayDCgIpE7Q(qg7Nr1dCaD): bidX1q0Me5tKC7Yv98BAHrQGZLV = BBX9RAuxnyGZ4WIF2TrhYeom3
			elif t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠹࠺࠶ᙆ")<=Vq3XpLGKo4zlSR59wBrhjAbcamJDie.status_code<=t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠸࠽࠾ᙅ"): w50bYA8L7lvs = BBX9RAuxnyGZ4WIF2TrhYeom3
			else: bidX1q0Me5tKC7Yv98BAHrQGZLV = BBX9RAuxnyGZ4WIF2TrhYeom3
			if not bidX1q0Me5tKC7Yv98BAHrQGZLV and not DJxFmjpI2U6SzRG and M7ecDnvPI5BOtyXs.headers: Vq3XpLGKo4zlSR59wBrhjAbcamJDie = M7ecDnvPI5BOtyXs
			iGxH2fsuScPtkJb7ECg = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.url
			bY3gNleaHWrMKDw = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.status_code
			JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.reason
			Vq3XpLGKo4zlSR59wBrhjAbcamJDie.raise_for_status()
			Vsn3f1CA8FIu0krNclSDWP5v9YQaE = BBX9RAuxnyGZ4WIF2TrhYeom3
		except GQHhfr5kocClg6.exceptions.HTTPError as kQhFMNbH2U:
			pass
		except GQHhfr5kocClg6.exceptions.Timeout as kQhFMNbH2U:
			if psS8dmb912iRBgGc7qOPyCZ6: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = str(kQhFMNbH2U.message).split(TVnqDYzWoM2UfHp0dchJ(u"ࠪ࠾ࠥ࠭ᓙ"))[nyUIsfd53EGot9vbj0XDeq]
			else: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = str(kQhFMNbH2U).split(Gykx0wL3XrlWaujsqKP9n2Q(u"ࠫ࠿ࠦࠧᓚ"))[nyUIsfd53EGot9vbj0XDeq]
		except GQHhfr5kocClg6.exceptions.ConnectionError as kQhFMNbH2U:
			try: ddZqPF6aCp2Uwxh = kQhFMNbH2U.message[wvkDqmNZlJU52isXo]
			except: ddZqPF6aCp2Uwxh = str(kQhFMNbH2U)
			pSNHZsGchiyv83OKzrCwbxdol = X2XorVqHjLkWeCchY4u9fSz.findall(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢᓛ"),ddZqPF6aCp2Uwxh)
			if not pSNHZsGchiyv83OKzrCwbxdol: pSNHZsGchiyv83OKzrCwbxdol = X2XorVqHjLkWeCchY4u9fSz.findall(HADrRCz9QgU4xudPJIqYb70(u"ࠨࠬࠡࡧࡵࡶࡴࡸ࡜ࠩࠪ࡟ࡨ࠰࠯ࠬࠡࠩࠫ࠲࠯ࡅࠩࠨࠤᓜ"),ddZqPF6aCp2Uwxh)
			if not pSNHZsGchiyv83OKzrCwbxdol:
				MWlbwPs63u7FhTHU4xZKAgQ = X2XorVqHjLkWeCchY4u9fSz.findall(C3w6qluao7EzUxJgMGBtV(u"ࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠻࠰࠭ࡃ࠭ࡢࡤࠬࠫ࠽ࠦᓝ"),ddZqPF6aCp2Uwxh)
				if MWlbwPs63u7FhTHU4xZKAgQ: pSNHZsGchiyv83OKzrCwbxdol = [MWlbwPs63u7FhTHU4xZKAgQ[wvkDqmNZlJU52isXo][nyUIsfd53EGot9vbj0XDeq],MWlbwPs63u7FhTHU4xZKAgQ[wvkDqmNZlJU52isXo][wvkDqmNZlJU52isXo]]
			if not pSNHZsGchiyv83OKzrCwbxdol: pSNHZsGchiyv83OKzrCwbxdol = X2XorVqHjLkWeCchY4u9fSz.findall(l7kBpMw5Qn(u"ࠣ࠼ࠫࡠࡩ࠱ࠩ࠻ࠢࠫ࠲࠯ࡅࠩࠨࠤᓞ"),ddZqPF6aCp2Uwxh)
			if not pSNHZsGchiyv83OKzrCwbxdol: pSNHZsGchiyv83OKzrCwbxdol = X2XorVqHjLkWeCchY4u9fSz.findall(iDhLkZS6XBagNCQfs9tq2(u"ࠤࠣࠬࡡࡪࠫࠪ࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᓟ"),ddZqPF6aCp2Uwxh)
			try: bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = pSNHZsGchiyv83OKzrCwbxdol[wvkDqmNZlJU52isXo]
			except: bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = -JhTts2R43AxkM8bYanKVy,ddZqPF6aCp2Uwxh
		except GQHhfr5kocClg6.exceptions.RequestException as kQhFMNbH2U:
			if psS8dmb912iRBgGc7qOPyCZ6: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = kQhFMNbH2U.message
			else: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = str(kQhFMNbH2U)
		except:
			try: bY3gNleaHWrMKDw = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.status_code
			except: pass
			try: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.reason
			except: pass
		JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = str(JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz)
		z82vTVp1xik0HBSenuENU5fRAD3(QO1UyS3zvJFIdlCgT0Kx96wLA4a5i,Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡢࡴࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᓠ")+str(bY3gNleaHWrMKDw)+gCkRKGhwcx26v(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᓡ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz+j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᓢ")+qh4B9VQZCbXr0DRknFmi7J6+tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᓣ")+pfhH2objgVkI7eycn+Ns6AJKH7DGpr19Wl5C3nF(u"ࠧࠡ࡟ࠪᓤ"))
		if OP5dj4YLRU13a6X and I9EF3ZbmzWgqM8JLGwsdkAjhTuyae and not w50bYA8L7lvs and bY3gNleaHWrMKDw!=vMhFypGLHZJbdX4O7oc3W8x(u"࠷࠶࠰ᙇ") and vMhFypGLHZJbdX4O7oc3W8x(u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫᓥ") not in qg7Nr1dCaD:
			if qg7Nr1dCaD not in [JmnxlP9N1z3e8IjoTEOYh,tlL01Pyq4FQxp,M7MJCgyIQDYZiuTRFKsj59mH]: qg7Nr1dCaD,w50bYA8L7lvs = JmnxlP9N1z3e8IjoTEOYh,mrhSYXH2P8bO3eJAa9n
			elif qg7Nr1dCaD==JmnxlP9N1z3e8IjoTEOYh: qg7Nr1dCaD,w50bYA8L7lvs = tlL01Pyq4FQxp,mrhSYXH2P8bO3eJAa9n
			elif qg7Nr1dCaD==tlL01Pyq4FQxp: qg7Nr1dCaD,w50bYA8L7lvs = M7MJCgyIQDYZiuTRFKsj59mH,BBX9RAuxnyGZ4WIF2TrhYeom3
			continue
		if not bidX1q0Me5tKC7Yv98BAHrQGZLV and Vsn3f1CA8FIu0krNclSDWP5v9YQaE: continue
		break
	bY3gNleaHWrMKDw = int(bY3gNleaHWrMKDw)
	if not Vsn3f1CA8FIu0krNclSDWP5v9YQaE:
		glTG84M01v2 = ybWszHAnQkBxjVUDJha47(fp6KV7DlS8QYniUczHdmZChL(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪᓦ"),sTGtHVyhQ9cJU37zxo2O(u"࠾࠰ᙈ"))
		if glTG84M01v2==-nyUIsfd53EGot9vbj0XDeq:
			z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,sTGtHVyhQ9cJU37zxo2O(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࠡࡆࡌࡗࡈࡕࡎࡏࡇࡆࡘࡊࡊࠠࠡࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡷࡳࠥࡺࡨࡦࠢ࡬ࡲࡹ࡫ࡲ࡯ࡧࡷࠤࠦࠧࠧᓧ"))
			gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,gCkRKGhwcx26v(u"้๊ࠫริใࠣะ์อาไࠢ฽๎ึࠦๅาส๋฻ࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐ำหะา้ࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลฺัสำฬะࠠอ้สึฺ่๋ࠦำูࠣา๐อสࠢ࡟ࡲࡡࡴࠠๅฯ็ࠤฬ๊ๅีๅ็อࠥะรไัࠣว๋ࠦฬ่ษี็๋ࠥัษฺ๊ࠤอ฽ั๋ไฬࠤฺำ๊ฮหࠣฬฬ๊ล็ฬิ๊ฯ่ࠦโ์๊ࠤฬ๊ล็ฬิ๊ฯࠦสฺ็็ࠤอ฻่าหࠣะ๏ีษࠨᓨ"))
			LbTfk6oJPiSGpVMU()
			return Vq3XpLGKo4zlSR59wBrhjAbcamJDie
	if not Vsn3f1CA8FIu0krNclSDWP5v9YQaE and CoH1KMEFy6A0j:
		for url in CoH1KMEFy6A0j:
			if url in list(qFsuKN7ngp.FORWARDS_HOSTNAMES.keys()):
				del qFsuKN7ngp.FORWARDS_HOSTNAMES[url]
				pZEIXTrQyjbgU = BBX9RAuxnyGZ4WIF2TrhYeom3
	if pZEIXTrQyjbgU:
		pmvtYQxwN2EB7W(E8Eo9FKSM5bhgRYlCWZHqPmt,VOALf8iYEnMdK0g(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠴ࠪᓩ"),v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᓪ"),qFsuKN7ngp.FORWARDS_HOSTNAMES,iHR47eol8wB3Z)
		qFsuKN7ngp.FORWARDS_HOSTNAMES = {}
	if ooOMXGnTYPA81!=None and r2wm0BOAUYz7faosk5L1!=ALwOspNtXxZrz3PEKku(u"ࠧࡔࡖࡒࡔࠬᓫ"): ofSjvyFl1zIx.create_connection = NApMnG3QlV9Y5s2tRzhEqfWv8I1
	if r2wm0BOAUYz7faosk5L1==fp6KV7DlS8QYniUczHdmZChL(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨᓬ") and nDFrWsp5qN: ooOMXGnTYPA81 = None
	if not Vsn3f1CA8FIu0krNclSDWP5v9YQaE and WMKSy1qfGhFckpTawe2lE5==None and qh4B9VQZCbXr0DRknFmi7J6 not in m7x2zfI5LH39BkU:
		yamjrsOAG4iFfQkuW1JXbZ0Dgq7z = HkQJ95ahZMwW0OtpKU2X.format_exc()
		if yamjrsOAG4iFfQkuW1JXbZ0Dgq7z!=sTGtHVyhQ9cJU37zxo2O(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᓭ"): yMqHPpxSEAFIwKecXdi40r8zL53.stderr.write(yamjrsOAG4iFfQkuW1JXbZ0Dgq7z)
	jBpoP97yUegruqxbE = HvawcTdL3fq785XunkRDGE2FP()
	if Q9OcWd0I6f: iGxH2fsuScPtkJb7ECg = gdOAzT9FrUpkML1yJuf5Kc4iP
	if not iGxH2fsuScPtkJb7ECg: iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD
	jBpoP97yUegruqxbE.url = iGxH2fsuScPtkJb7ECg
	jBpoP97yUegruqxbE.scrape = Q9OcWd0I6f
	try:
		tFTrYa8QIGpu13kRo = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers
		if not tFTrYa8QIGpu13kRo.get(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᓮ")) and not tFTrYa8QIGpu13kRo.get(bcNqYtfET5l92dLGjyZSPe(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᓯ")): tFTrYa8QIGpu13kRo.headers[TVnqDYzWoM2UfHp0dchJ(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᓰ")] = iGxH2fsuScPtkJb7ECg
	except: tFTrYa8QIGpu13kRo = {}
	try:
		i39emuhJVLH8AfSIdo4 = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.content
		if TQgoVIpwAjq6l and i39emuhJVLH8AfSIdo4:
			bkzomAh93gO1HMsqWT8faLdiUR = {OL7InSQdMpsFA0.lower(): zzpMrn7D0KCjtNqRuoQILvO83 for OL7InSQdMpsFA0, zzpMrn7D0KCjtNqRuoQILvO83 in Vq3XpLGKo4zlSR59wBrhjAbcamJDie.headers.items()}
			if bkzomAh93gO1HMsqWT8faLdiUR.get(czvu7VQCZodkMf(u"࠭ࡡࡷ࠯ࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ᓱ"))==Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠳࠱࠴ࠬᓲ"):
				i39emuhJVLH8AfSIdo4,PXWrg9Tz56VAmM1ocG2 = DHLWKi5fq3gyUAvc7ZE21(i39emuhJVLH8AfSIdo4,TVnqDYzWoM2UfHp0dchJ(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷ᙉ"))
				if PXWrg9Tz56VAmM1ocG2==vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡋࡑ࡚ࡆࡒࡉࡅࡡࡗࡍࡒࡋࡓࡕࡃࡐࡔࠬᓳ"):
					JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz,bY3gNleaHWrMKDw = NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࡌࡲࡻࡧ࡬ࡪࡦࠣࡅࡕࡏࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࠪᓴ"),-vgZfTlcQjDGVREy3kPA2r0Oxq1JwBs
					Vsn3f1CA8FIu0krNclSDWP5v9YQaE = mrhSYXH2P8bO3eJAa9n
					i39emuhJVLH8AfSIdo4 = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz
	except: i39emuhJVLH8AfSIdo4 = SebHIf2jL1TBgrMKJu
	if QBOMjKifEAFD and isinstance(i39emuhJVLH8AfSIdo4,bytes):
		try: i39emuhJVLH8AfSIdo4 = i39emuhJVLH8AfSIdo4.decode(Tv08xsf9HOqunIVUPdK1)
		except: i39emuhJVLH8AfSIdo4 = i39emuhJVLH8AfSIdo4.decode(GOrf6A4JzH7uyLCEIiKVhoQFm)
	if TQgoVIpwAjq6l and i39emuhJVLH8AfSIdo4 and wPnfgxKZdAv6T10(u"࠷࠸࠴ᙋ")<=bY3gNleaHWrMKDw<=TVnqDYzWoM2UfHp0dchJ(u"࠶࠻࠼ᙊ"): JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = i39emuhJVLH8AfSIdo4
	try: xsghdF3HKAz9ZGYLvaD7 = Vq3XpLGKo4zlSR59wBrhjAbcamJDie.cookies.get_dict()
	except: xsghdF3HKAz9ZGYLvaD7 = {}
	try: Vq3XpLGKo4zlSR59wBrhjAbcamJDie.close()
	except: pass
	jBpoP97yUegruqxbE.code = bY3gNleaHWrMKDw
	jBpoP97yUegruqxbE.reason = JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz
	jBpoP97yUegruqxbE.content = i39emuhJVLH8AfSIdo4
	jBpoP97yUegruqxbE.headers = tFTrYa8QIGpu13kRo
	jBpoP97yUegruqxbE.cookies = xsghdF3HKAz9ZGYLvaD7
	jBpoP97yUegruqxbE.succeeded = Vsn3f1CA8FIu0krNclSDWP5v9YQaE
	jBpoP97yUegruqxbE.scrapernumber = SebHIf2jL1TBgrMKJu
	jBpoP97yUegruqxbE.scraperserver = SebHIf2jL1TBgrMKJu
	jBpoP97yUegruqxbE.scraperurl = SebHIf2jL1TBgrMKJu
	if psS8dmb912iRBgGc7qOPyCZ6 or isinstance(jBpoP97yUegruqxbE.content,str): bbR2BJG4kDjpLFM0Stvx53PT = jBpoP97yUegruqxbE.content.lower()
	else: bbR2BJG4kDjpLFM0Stvx53PT = SebHIf2jL1TBgrMKJu
	QQVYoSRMmZLsrtqiKFjybP2aDOu963 = (xxRyYsrSCzjifvH4cIqgldeOo(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᓵ") in bbR2BJG4kDjpLFM0Stvx53PT or czvu7VQCZodkMf(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᓶ") in bbR2BJG4kDjpLFM0Stvx53PT) and bbR2BJG4kDjpLFM0Stvx53PT.count(xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᓷ"))>JhTts2R43AxkM8bYanKVy and qeYIw0BNTL9bGJnosacQ1DtVR(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᓸ") not in qh4B9VQZCbXr0DRknFmi7J6 and Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬᓹ") not in qh4B9VQZCbXr0DRknFmi7J6 and HADrRCz9QgU4xudPJIqYb70(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪᓺ") not in bbR2BJG4kDjpLFM0Stvx53PT and not Q9OcWd0I6f
	TX2kUwOYDuehbzIRaFm3 = (ASkvf27etUK0(u"ࠩࡹࡩࡷ࡯ࡦࡺ࠰࡫ࡸࡲࡲ࠿ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠿ࠪᓻ") in iGxH2fsuScPtkJb7ECg)
	if bY3gNleaHWrMKDw==ASkvf27etUK0(u"࠵࠴࠵ᙌ") and (QQVYoSRMmZLsrtqiKFjybP2aDOu963 or TX2kUwOYDuehbzIRaFm3):
		jBpoP97yUegruqxbE.succeeded = mrhSYXH2P8bO3eJAa9n
	if jBpoP97yUegruqxbE.succeeded and OP5dj4YLRU13a6X and I9EF3ZbmzWgqM8JLGwsdkAjhTuyae:
		DDj8NqZIHVmeMUTk = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫᓼ")+bIGXajdcK6PQBs[gCkRKGhwcx26v(u"ࠫ࡯ࡵࡢࠨᓽ")].upper().replace(uqLUBHepfM3l6AyIzTJh80a(u"ࠬࡍࡅࡕࠩᓾ"),SebHIf2jL1TBgrMKJu) if aaKxjiJWrm4Io0wU else QUWsbGoFmngMKlTpz7id
		zzcbV5F4iSjM2(DDj8NqZIHVmeMUTk)
	if not jBpoP97yUegruqxbE.succeeded and OP5dj4YLRU13a6X:
		zsqSWN2A7e10fJG = (Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᓿ") in bbR2BJG4kDjpLFM0Stvx53PT and v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩᔀ") in bbR2BJG4kDjpLFM0Stvx53PT)
		fO5aqDP6vKjyYRgWAxE4G0u1p39l = (Ns6AJKH7DGpr19Wl5C3nF(u"ࠨ࠷ࠣࡷࡪࡩࠧᔁ") in bbR2BJG4kDjpLFM0Stvx53PT and sTGtHVyhQ9cJU37zxo2O(u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪᔂ") in bbR2BJG4kDjpLFM0Stvx53PT)
		OsGeuHjAtDIY = (bY3gNleaHWrMKDw in [czvu7VQCZodkMf(u"࠸࠵࠹ᙍ")] and C3w6qluao7EzUxJgMGBtV(u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭ᔃ") in bbR2BJG4kDjpLFM0Stvx53PT)
		LSe1NsCEqH = (v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭ᔄ") in bbR2BJG4kDjpLFM0Stvx53PT and vMhFypGLHZJbdX4O7oc3W8x(u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩᔅ") in bbR2BJG4kDjpLFM0Stvx53PT)
		pLvVmMtwk527OiZGXfysl9zu4PQJ = (uqLUBHepfM3l6AyIzTJh80a(u"࠭ࡗࡓࡑࡑࡋࡤ࡜ࡅࡓࡕࡌࡓࡓࡥࡎࡖࡏࡅࡉࡗ࠭ᔆ") in JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz or iDhLkZS6XBagNCQfs9tq2(u"ࠧࡸࡴࡲࡲ࡬ࠦࡶࡦࡴࡶ࡭ࡴࡴࠠ࡯ࡷࡰࡦࡪࡸࠧᔇ") in JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz)
		if   QQVYoSRMmZLsrtqiKFjybP2aDOu963: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᔈ")
		elif zsqSWN2A7e10fJG: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᔉ")
		elif fO5aqDP6vKjyYRgWAxE4G0u1p39l: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪᔊ")
		elif OsGeuHjAtDIY: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡧࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠬᔋ")
		elif LSe1NsCEqH: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = Ns6AJKH7DGpr19Wl5C3nF(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧᔌ")
		elif TX2kUwOYDuehbzIRaFm3: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = TVnqDYzWoM2UfHp0dchJ(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡱ࡮ࡹࡳࡪࡰࡪࠤ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠡࡥ࡫ࡩࡨࡱࠧᔍ")
		elif pLvVmMtwk527OiZGXfysl9zu4PQJ: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = ASkvf27etUK0(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡾࡵࡵࡳࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣࡨࡪࡼࡩࡤࡧࡶࠫᔎ")
		else: JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz = str(JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz)
		if qh4B9VQZCbXr0DRknFmi7J6 in BBQX5whPbKgHNRqpnt2oM: pass
		elif qh4B9VQZCbXr0DRknFmi7J6 in m7x2zfI5LH39BkU:
			z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+HCiWF4jV1Q8(u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᔏ")+str(bY3gNleaHWrMKDw)+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᔐ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz+TVnqDYzWoM2UfHp0dchJ(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᔑ")+qh4B9VQZCbXr0DRknFmi7J6+Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᔒ")+qg7Nr1dCaD+bcNqYtfET5l92dLGjyZSPe(u"ࠬࠦ࡝ࠨᔓ"))
		else: z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+C3w6qluao7EzUxJgMGBtV(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᔔ")+str(bY3gNleaHWrMKDw)+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᔕ")+JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz+xxRyYsrSCzjifvH4cIqgldeOo(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᔖ")+qh4B9VQZCbXr0DRknFmi7J6+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᔗ")+qg7Nr1dCaD+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࠤࡢ࠭ᔘ"))
		ciyNextMQs0f972w5 = gdOAzT9FrUpkML1yJuf5Kc4iP if Q9OcWd0I6f else kLEi7mYT5wBM4DHsgWy8(qg7Nr1dCaD)
		if psS8dmb912iRBgGc7qOPyCZ6 and isinstance(ciyNextMQs0f972w5,unicode): ciyNextMQs0f972w5 = ciyNextMQs0f972w5.encode(Tv08xsf9HOqunIVUPdK1)
		if I9EF3ZbmzWgqM8JLGwsdkAjhTuyae: ciyNextMQs0f972w5 = ciyNextMQs0f972w5.split(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫ࠴࠭ᔙ"))[-nyUIsfd53EGot9vbj0XDeq]
		vXgwEOp9Ptb71h6rFkMjIVqzBnHN = str(JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz)+VOALf8iYEnMdK0g(u"ࠬࡢ࡮ࠩࠩᔚ")+ciyNextMQs0f972w5+TVnqDYzWoM2UfHp0dchJ(u"࠭ࠩࠨᔛ")
		if any([QQVYoSRMmZLsrtqiKFjybP2aDOu963,zsqSWN2A7e10fJG,fO5aqDP6vKjyYRgWAxE4G0u1p39l,OsGeuHjAtDIY,LSe1NsCEqH,TX2kUwOYDuehbzIRaFm3,pLvVmMtwk527OiZGXfysl9zu4PQJ]) and VsyuARB7wrIa1zmphWxGHo0:
			if not pLvVmMtwk527OiZGXfysl9zu4PQJ:
				jBpoP97yUegruqxbE.code = -fuCbjVag7vU908J2Yqx5Th
				hEzuQcWjadx18ZJ = j2eKYcTFGf7q9XVgJCUukrtiAEs(u"่ࠧา๊ࠤฬ๊ีโฯฬࠤ้อ๋ࠠ็ๆ๊ࠥาไษ้สࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳࠴ࠠๅล้ࠤ฾๊๊่ษ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢํ้๋฿ࠠษำส้ัࠦวๅๅ๋้อ๐่หำ้๋ࠣࠦฬๅสࠣ์ๆะอ๊ࠡสืฯิฯศ็๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢสฺ่็อศฬࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤ๏ูสุ์฼ࠤศ์๋ࠠฯส์้ࠦวิฬัำฬ๋ࠠฦ่อี๋ะࠠฤะิํ๊ࠥสอษ๋ึࠥํะศࠢส่าาศࠡ࠰࠱ࠤ้้ๆࠡๆสࠤ๏๎ฬะู้ࠢฬ์ࠠฤ่๋ࠣีํࠠศๆ่ัฬ๎ไสࠢึ์ๆࠦส็ฮะࡠࡳ࠭ᔜ")+QNR6tCevIGEZKX3rAVsP+NUbVrRi4nq6BXmAOcM1zGtgJ(u"ࠨࡇࡵࡶࡴࡸࠠࡄࡱࡧࡩ࠿ࠦࠠࠨᔝ")+str(jBpoP97yUegruqxbE.code)+XOVRfitWJP1zL3p2CMYF+u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+ypO63g8oJEsDnPBHSuU7lMTZr(u"๊่ࠩࠥะั๋ั้๋ࠣࠦศา่ส้ัูࠦๆษาࠤศ์๋ࠠฯส์้ࠦสอษ๋ึࠥํะศࠢส่าาศࠡมࠤࠫᔞ")+XOVRfitWJP1zL3p2CMYF
			else:
				jBpoP97yUegruqxbE.code = -K7cnfQMS6BPvI4LGmCsRp8bUlJ9
				hEzuQcWjadx18ZJ = iDhLkZS6XBagNCQfs9tq2(u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥะๅ็฻ࠣๅฯำࠠษ฻ูࠤฺ็อศฬࠣห้หๆหำ้ฮࠥอไืำ๋ี๏ฯࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤฯ้่็่๊ࠢࠥอไาษ๋ฮึูࠦ็ัๆࠤศ๎ࠠๆ่ࠣฬึ์วๆฮࠣ฽๋ีใࠡล๋ࠤ๊์ࠠอ้สึࠥ฿ๆะๅࠣ࠲࠳ู่ࠦ์ไฮ์ࠦวๅฯ่ห๏ฯࠠืัࠣห้็๊า๊ึหฯࠦรู้ࠢำࠥอไหฮึืࠥษุ่ࠡาࠤฬ๊ศาษ่ะࠥอไๆฦำ๎ฮࠦ࠮࠯ࠢ็ั้ࠦวๅ็ื็้ฯ๋ࠠฮหࠤส๐โศใ๋ࠣีํࠠศๆะ้ฬ๐ษࠡษ็าฬ฽ฦส࡞ࡱࠫᔟ")+QNR6tCevIGEZKX3rAVsP+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠫࡊࡸࡲࡰࡴࠣࡇࡴࡪࡥ࠻ࠢࠣࠫᔠ")+str(jBpoP97yUegruqxbE.code)+XOVRfitWJP1zL3p2CMYF+u43PVWjh7t9YwI+E7r8hUCVvTiFQW0dBGXjxcy+HADrRCz9QgU4xudPJIqYb70(u"ࠬํไࠡฬิ๎ิࠦๅ็ࠢหี๋อๅอࠢ฼้ฬีࠠฤ่ࠣ๎าอ่ๅࠢสืฯิฯศ็ࠣษ๋ะั็ฬࠣวำื้ࠡๆอะฬ๎า้ࠡำ๋ࠥอไฮ็ส๎ฮࠦฟࠢࠩᔡ")+XOVRfitWJP1zL3p2CMYF
			sLhog1knUIF4fNOjY2zJqQ7cxArb = vvubxo631m2zYC(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,hEzuQcWjadx18ZJ)
			if sLhog1knUIF4fNOjY2zJqQ7cxArb:
				aFuIU1RDMv98SkYocqNZCKLGlf = UqgKptMNenkfsTYxFBzGSr(oHSdD2N140BnjWsOk,qg7Nr1dCaD,r2DznEpvjQV5TNoCdZ0q,REIkboX9NtlZCSU3A,DJxFmjpI2U6SzRG,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6,bY3gNleaHWrMKDw,JsAE6V2gT9MPtdDb4vSO1Gju7YrmFz)
				if aFuIU1RDMv98SkYocqNZCKLGlf.succeeded: return aFuIU1RDMv98SkYocqNZCKLGlf
		sLhog1knUIF4fNOjY2zJqQ7cxArb = BBX9RAuxnyGZ4WIF2TrhYeom3
		if (r2wm0BOAUYz7faosk5L1==cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࡁࡔࡍࠪᔢ") or MNueRG4Cz8D2TQFBhSXxianlj1AtO==Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠧࡂࡕࡎࠫᔣ")) and (nDFrWsp5qN or VsyuARB7wrIa1zmphWxGHo0):
			sLhog1knUIF4fNOjY2zJqQ7cxArb = YYsnUMzptN0FJw19ruihSI6qf(bY3gNleaHWrMKDw,vXgwEOp9Ptb71h6rFkMjIVqzBnHN,qh4B9VQZCbXr0DRknFmi7J6,dN1yCrxi3FXHS)
			if sLhog1knUIF4fNOjY2zJqQ7cxArb and r2wm0BOAUYz7faosk5L1==t0FTYwCdi8jVaDu4EWBzUKbGLl(u"ࠨࡃࡖࡏࠬᔤ"): r2wm0BOAUYz7faosk5L1 = fp6KV7DlS8QYniUczHdmZChL(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᔥ")
			else: r2wm0BOAUYz7faosk5L1 = uqLUBHepfM3l6AyIzTJh80a(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᔦ")
			if sLhog1knUIF4fNOjY2zJqQ7cxArb and MNueRG4Cz8D2TQFBhSXxianlj1AtO==uqLUBHepfM3l6AyIzTJh80a(u"ࠫࡆ࡙ࡋࠨᔧ"): MNueRG4Cz8D2TQFBhSXxianlj1AtO = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᔨ")
			else: MNueRG4Cz8D2TQFBhSXxianlj1AtO = czvu7VQCZodkMf(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨᔩ")
			MMAUZiw4CoJ8.setSetting(tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᔪ"),r2wm0BOAUYz7faosk5L1)
			MMAUZiw4CoJ8.setSetting(Ns6AJKH7DGpr19Wl5C3nF(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᔫ"),MNueRG4Cz8D2TQFBhSXxianlj1AtO)
		if sLhog1knUIF4fNOjY2zJqQ7cxArb:
			if bY3gNleaHWrMKDw==bcNqYtfET5l92dLGjyZSPe(u"࠽ᙎ") and Ns6AJKH7DGpr19Wl5C3nF(u"ࠩ࡫ࡸࡹࡶࡳࠨᔬ") in qg7Nr1dCaD and TeqLPpbG5OR7Ztl01jCrfAa2EY6NvU:
				if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪᔭ"),Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᔮ"),uv8V4fE7j9pmgFr3wnDL=ALwOspNtXxZrz3PEKku(u"࠸࠰࠱࠲ᙏ"))
				iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᔯ")
				ooSekfpJr7jAgbXIT = KXpxBQE2LP(oHSdD2N140BnjWsOk,iGxH2fsuScPtkJb7ECg,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,dN1yCrxi3FXHS,fp6KV7DlS8QYniUczHdmZChL(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧᔰ"))
				if ooSekfpJr7jAgbXIT.succeeded:
					jBpoP97yUegruqxbE = ooSekfpJr7jAgbXIT
					z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+HCiWF4jV1Q8(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᔱ")+qh4B9VQZCbXr0DRknFmi7J6+gCkRKGhwcx26v(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᔲ")+pfhH2objgVkI7eycn+zpx2fPNKk6Ms38eD1vcO(u"ࠩࠣࡡࠬᔳ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(NUbVrRi4nq6BXmAOcM1zGtgJ(u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧᔴ"),Izy1PvclrYx4eSVWn0L5phZbq(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᔵ"),uv8V4fE7j9pmgFr3wnDL=TVnqDYzWoM2UfHp0dchJ(u"࠲࠱࠲࠳ᙐ"))
				else:
					z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+VOALf8iYEnMdK0g(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᔶ")+qh4B9VQZCbXr0DRknFmi7J6+VOALf8iYEnMdK0g(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᔷ")+pfhH2objgVkI7eycn+Izy1PvclrYx4eSVWn0L5phZbq(u"ࠧࠡ࡟ࠪᔸ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫᔹ"),vMhFypGLHZJbdX4O7oc3W8x(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᔺ"),uv8V4fE7j9pmgFr3wnDL=wPnfgxKZdAv6T10(u"࠳࠲࠳࠴ᙑ"))
			if not jBpoP97yUegruqxbE.succeeded and MNueRG4Cz8D2TQFBhSXxianlj1AtO in [czvu7VQCZodkMf(u"ࠪࡅ࡚࡚ࡏࠨᔻ"),gCkRKGhwcx26v(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᔼ")] and VsyuARB7wrIa1zmphWxGHo0:
				if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(Ns6AJKH7DGpr19Wl5C3nF(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬᔽ"),HADrRCz9QgU4xudPJIqYb70(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᔾ"),uv8V4fE7j9pmgFr3wnDL=Ns6AJKH7DGpr19Wl5C3nF(u"࠴࠳࠴࠵ᙒ"))
				ooSekfpJr7jAgbXIT = zTxpAmytobeOiNM4l(oHSdD2N140BnjWsOk,qg7Nr1dCaD,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,dN1yCrxi3FXHS,qh4B9VQZCbXr0DRknFmi7J6)
				if ooSekfpJr7jAgbXIT.succeeded:
					jBpoP97yUegruqxbE = ooSekfpJr7jAgbXIT
					z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ALwOspNtXxZrz3PEKku(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᔿ")+qh4B9VQZCbXr0DRknFmi7J6+vMhFypGLHZJbdX4O7oc3W8x(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᕀ")+pfhH2objgVkI7eycn+vMhFypGLHZJbdX4O7oc3W8x(u"ࠩࠣࡡࠬᕁ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(czvu7VQCZodkMf(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩᕂ"),bcNqYtfET5l92dLGjyZSPe(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᕃ"),uv8V4fE7j9pmgFr3wnDL=wPnfgxKZdAv6T10(u"࠵࠴࠵࠶ᙓ"))
				else:
					z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᕄ")+qh4B9VQZCbXr0DRknFmi7J6+t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᕅ")+pfhH2objgVkI7eycn+bcNqYtfET5l92dLGjyZSPe(u"ࠧࠡ࡟ࠪᕆ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᕇ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᕈ"),uv8V4fE7j9pmgFr3wnDL=gCkRKGhwcx26v(u"࠶࠵࠶࠰ᙔ"))
			if not jBpoP97yUegruqxbE.succeeded and r2wm0BOAUYz7faosk5L1 in [fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡅ࡚࡚ࡏࠨᕉ"),gCkRKGhwcx26v(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᕊ")] and nDFrWsp5qN:
				if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(Ju4YmhHgrMt0SpVCqOlBfQRDGby(u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᕋ"),C3w6qluao7EzUxJgMGBtV(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᕌ"),uv8V4fE7j9pmgFr3wnDL=wPnfgxKZdAv6T10(u"࠷࠶࠰࠱ᙕ"))
				iGxH2fsuScPtkJb7ECg = qg7Nr1dCaD+HADrRCz9QgU4xudPJIqYb70(u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬᕍ")
				ooSekfpJr7jAgbXIT = KXpxBQE2LP(oHSdD2N140BnjWsOk,iGxH2fsuScPtkJb7ECg,qqTB9mr0Av7jKg3UOYzLl,gTnyji0CwRW81,h1uNjAk9KeCHWQcJy,dN1yCrxi3FXHS,v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠺ࡴࡩࠩᕎ"))
				if ooSekfpJr7jAgbXIT.succeeded:
					jBpoP97yUegruqxbE = ooSekfpJr7jAgbXIT
					z82vTVp1xik0HBSenuENU5fRAD3(QoGw3aixFSvDVcue0lyLHrJd,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+tX7u5idnzTVNva3PlmJD1I80rxch4(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩᕏ")+tbjSgf4uz78qdrAvkxLiRhMcwQ+fp6KV7DlS8QYniUczHdmZChL(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᕐ")+qh4B9VQZCbXr0DRknFmi7J6+fp6KV7DlS8QYniUczHdmZChL(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᕑ")+pfhH2objgVkI7eycn+uqLUBHepfM3l6AyIzTJh80a(u"ࠬࠦ࡝ࠨᕒ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(AGlW9LqKN3Dvo(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧᕓ"),sTGtHVyhQ9cJU37zxo2O(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᕔ"),uv8V4fE7j9pmgFr3wnDL=tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠸࠰࠱࠲ᙖ"))
				else:
					z82vTVp1xik0HBSenuENU5fRAD3(xm5RwaXzSDh71KvJE3ceMBY,yzlN1I6eAYJBP8tKw9(tfX4sO3hy2H1IbKG)+ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬᕕ")+tbjSgf4uz78qdrAvkxLiRhMcwQ+cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᕖ")+qh4B9VQZCbXr0DRknFmi7J6+Gykx0wL3XrlWaujsqKP9n2Q(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᕗ")+pfhH2objgVkI7eycn+Ns6AJKH7DGpr19Wl5C3nF(u"ࠫࠥࡣࠧᕘ"))
					if dN1yCrxi3FXHS: i9yzUqgAW2Zap1h4Lm(VOALf8iYEnMdK0g(u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬᕙ"),ypO63g8oJEsDnPBHSuU7lMTZr(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᕚ"),uv8V4fE7j9pmgFr3wnDL=czvu7VQCZodkMf(u"࠲࠱࠲࠳ᙗ"))
		if MNueRG4Cz8D2TQFBhSXxianlj1AtO==xxRyYsrSCzjifvH4cIqgldeOo(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᕛ") or r2wm0BOAUYz7faosk5L1==DQIrVcKuY6bJv(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᕜ"): dN1yCrxi3FXHS = mrhSYXH2P8bO3eJAa9n
		if not jBpoP97yUegruqxbE.succeeded:
			if dN1yCrxi3FXHS: qqob7QneZkf2M9Tc08BJY1HW = YYsnUMzptN0FJw19ruihSI6qf(bY3gNleaHWrMKDw,vXgwEOp9Ptb71h6rFkMjIVqzBnHN,qh4B9VQZCbXr0DRknFmi7J6,dN1yCrxi3FXHS)
			if jBpoP97yUegruqxbE.code!=ALwOspNtXxZrz3PEKku(u"࠳࠲࠳ᙘ") and qh4B9VQZCbXr0DRknFmi7J6 not in tCbWnseyEhDF3xMuj and HCiWF4jV1Q8(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭ᕝ") not in qh4B9VQZCbXr0DRknFmi7J6: LbTfk6oJPiSGpVMU()
	if MMAUZiw4CoJ8.getSetting(v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᕞ")) not in [Izy1PvclrYx4eSVWn0L5phZbq(u"ࠫࡆ࡛ࡔࡐࠩᕟ"),cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࡙ࠬࡔࡐࡒࠪᕠ"),NUbVrRi4nq6BXmAOcM1zGtgJ(u"࠭ࡁࡔࡍࠪᕡ")]: MMAUZiw4CoJ8.setSetting(zpx2fPNKk6Ms38eD1vcO(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᕢ"),C3w6qluao7EzUxJgMGBtV(u"ࠨࡃࡖࡏࠬᕣ"))
	if MMAUZiw4CoJ8.getSetting(HCiWF4jV1Q8(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᕤ")) not in [fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡅ࡚࡚ࡏࠨᕥ"),j2eKYcTFGf7q9XVgJCUukrtiAEs(u"ࠫࡘ࡚ࡏࡑࠩᕦ"),xxRyYsrSCzjifvH4cIqgldeOo(u"ࠬࡇࡓࡌࠩᕧ")]: MMAUZiw4CoJ8.setSetting(bcNqYtfET5l92dLGjyZSPe(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᕨ"),zpx2fPNKk6Ms38eD1vcO(u"ࠧࡂࡕࡎࠫᕩ"))
	return jBpoP97yUegruqxbE
def utB0ZqFnejvcSyb2oKPOH5TLrMhw8d(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, WhE7sDH4RQXrV):
	OqSezpdXVU2fFh5kRt8, WhE7sDH4RQXrV = list(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc), WhE7sDH4RQXrV & 0xFFFFFFFF
	for YHnALfql8hprDu in range(len(OqSezpdXVU2fFh5kRt8)-nyUIsfd53EGot9vbj0XDeq, wvkDqmNZlJU52isXo, -nyUIsfd53EGot9vbj0XDeq):
		WhE7sDH4RQXrV = (WhE7sDH4RQXrV * czvu7VQCZodkMf(u"࠴࠺࠻࠺࠵࠳࠷ᙚ") + vMhFypGLHZJbdX4O7oc3W8x(u"࠳࠳࠵࠸࠿࠰࠵࠴࠵࠷ᙙ")) & 0xFFFFFFFF
		OqSezpdXVU2fFh5kRt8[YHnALfql8hprDu], OqSezpdXVU2fFh5kRt8[WhE7sDH4RQXrV % (YHnALfql8hprDu + nyUIsfd53EGot9vbj0XDeq)] = OqSezpdXVU2fFh5kRt8[WhE7sDH4RQXrV % (YHnALfql8hprDu + nyUIsfd53EGot9vbj0XDeq)], OqSezpdXVU2fFh5kRt8[YHnALfql8hprDu]
	return C3w6qluao7EzUxJgMGBtV(u"ࠨࠩᕪ").join(OqSezpdXVU2fFh5kRt8)
def gB1SVe4dRtocyqJMwvI(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, mF783LY5yfMg, GUpdylXbzu5nFht62mVcRLJ):
	A5NOqsiIgGtwjM4Y1HUJdfroS9Q = xxRyYsrSCzjifvH4cIqgldeOo(u"ࠩࠪᕫ").join(chr(YHnALfql8hprDu) for YHnALfql8hprDu in range(t0FTYwCdi8jVaDu4EWBzUKbGLl(u"࠶࠺࠼ᙛ")))
	if not QBOMjKifEAFD: A5NOqsiIgGtwjM4Y1HUJdfroS9Q = A5NOqsiIgGtwjM4Y1HUJdfroS9Q.decode(fp6KV7DlS8QYniUczHdmZChL(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᕬ"))
	CCnvoLWiDqwh5kM = utB0ZqFnejvcSyb2oKPOH5TLrMhw8d(A5NOqsiIgGtwjM4Y1HUJdfroS9Q, mF783LY5yfMg)
	mNog0eWhPvkRfyCSI4862KjaAHq = utB0ZqFnejvcSyb2oKPOH5TLrMhw8d(CCnvoLWiDqwh5kM, mF783LY5yfMg)
	zdjnMvtLArVsHKCQpXFxR6ZBO = dict(zip(CCnvoLWiDqwh5kM,mNog0eWhPvkRfyCSI4862KjaAHq)) if not GUpdylXbzu5nFht62mVcRLJ else dict(zip(mNog0eWhPvkRfyCSI4862KjaAHq,CCnvoLWiDqwh5kM))
	dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = HCiWF4jV1Q8(u"ࠫࠬᕭ").join(zdjnMvtLArVsHKCQpXFxR6ZBO.get(zt4C1riXE0RfZhKTgyP,zt4C1riXE0RfZhKTgyP) for zt4C1riXE0RfZhKTgyP in dP6f4SeYIyJuGjvHmUQRiq9WzabCgc)
	return dP6f4SeYIyJuGjvHmUQRiq9WzabCgc
def NpdkYXCVjwSx(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, mF783LY5yfMg):
	WH0t1DnbcwFPNrzumfGZkJgYQqElyV, KsxO9R5z2negpH1JScPIk8riCL, y8YzVxDouU9SnvBhWXCd2KlkFtjs = [], wvkDqmNZlJU52isXo, wvkDqmNZlJU52isXo
	e9WFpY0CgkZjlcEfr6NRJsn = [TVnqDYzWoM2UfHp0dchJ(u"࠶࠶ᙜ")-int(QswcKkr0nfHiAqdt) for QswcKkr0nfHiAqdt in str(mF783LY5yfMg)[::-nyUIsfd53EGot9vbj0XDeq]]
	EiXfUP0KuxDMr1S = int(ASkvf27etUK0(u"ࠬ࠿ࠧᕮ")*len(str(mF783LY5yfMg)))//fuCbjVag7vU908J2Yqx5Th-mF783LY5yfMg
	mF783LY5yfMg, EiXfUP0KuxDMr1S = mF783LY5yfMg % v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠸࠵࠷ᙝ"), EiXfUP0KuxDMr1S % v532vWgiKz8Z7IEhJeXLCp6A9wnM(u"࠸࠵࠷ᙝ")
	while KsxO9R5z2negpH1JScPIk8riCL < len(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc):
		BsoUy62ta3mKXJ5ueiG = e9WFpY0CgkZjlcEfr6NRJsn[y8YzVxDouU9SnvBhWXCd2KlkFtjs%len(e9WFpY0CgkZjlcEfr6NRJsn)]
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc[KsxO9R5z2negpH1JScPIk8riCL : KsxO9R5z2negpH1JScPIk8riCL + BsoUy62ta3mKXJ5ueiG]
		WH0t1DnbcwFPNrzumfGZkJgYQqElyV += [(ord(zt4C1riXE0RfZhKTgyP)^mF783LY5yfMg)^EiXfUP0KuxDMr1S for zt4C1riXE0RfZhKTgyP in drRnSgoBtKWjmU5FH4ZCIVhzqNb][::-nyUIsfd53EGot9vbj0XDeq]
		KsxO9R5z2negpH1JScPIk8riCL += BsoUy62ta3mKXJ5ueiG
		y8YzVxDouU9SnvBhWXCd2KlkFtjs += nyUIsfd53EGot9vbj0XDeq
	suUMZiPl4QARqrHBy = chr if QBOMjKifEAFD else unichr
	dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"࠭ࠧᕯ").join([suUMZiPl4QARqrHBy(zt4C1riXE0RfZhKTgyP) for zt4C1riXE0RfZhKTgyP in WH0t1DnbcwFPNrzumfGZkJgYQqElyV])
	return dP6f4SeYIyJuGjvHmUQRiq9WzabCgc
def B1BD67cV8sYopU24Wrhxw(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc,WhE7sDH4RQXrV,XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK=wvkDqmNZlJU52isXo):
	if nyUIsfd53EGot9vbj0XDeq:
		if isinstance(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, bytes): dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.decode(uqLUBHepfM3l6AyIzTJh80a(u"ࠧࡶࡶࡩ࠼ࠬᕰ"))
		CZp6gROz47DXMPHufW2io = uv8V4fE7j9pmgFr3wnDL.time()+XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK if XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK>wvkDqmNZlJU52isXo else uv8V4fE7j9pmgFr3wnDL.time()
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࡶࠤࡾࢁࢁࢂࡼࡼࡿࠥᕱ").format(int(CZp6gROz47DXMPHufW2io), dP6f4SeYIyJuGjvHmUQRiq9WzabCgc)
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = NpdkYXCVjwSx(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, WhE7sDH4RQXrV)
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.encode(uqLUBHepfM3l6AyIzTJh80a(u"ࠩࡸࡸ࡫࠾ࠧᕲ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = kLtsvDVQ0SZmTjhBG9uW.compress(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc)
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.decode(cH6vtRYxN51hXlbjDzn2esfg0Vokaq(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᕳ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = gB1SVe4dRtocyqJMwvI(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, WhE7sDH4RQXrV, ALwOspNtXxZrz3PEKku(u"ࡆࡢ࡮ࡶࡩᙞ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.encode(sTGtHVyhQ9cJU37zxo2O(u"ࠫࡺࡺࡦ࠹ࠩᕴ"))
	return dP6f4SeYIyJuGjvHmUQRiq9WzabCgc
def DHLWKi5fq3gyUAvc7ZE21(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc,WhE7sDH4RQXrV,XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK=wvkDqmNZlJU52isXo):
	PXWrg9Tz56VAmM1ocG2 = qeYIw0BNTL9bGJnosacQ1DtVR(u"ࠬࡌࡁࡊࡎࡈࡈࠬᕵ")
	if nyUIsfd53EGot9vbj0XDeq:
		if isinstance(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, bytes): dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.decode(tX7u5idnzTVNva3PlmJD1I80rxch4(u"࠭ࡵࡵࡨ࠻ࠫᕶ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = gB1SVe4dRtocyqJMwvI(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, WhE7sDH4RQXrV, xxRyYsrSCzjifvH4cIqgldeOo(u"ࡕࡴࡸࡩᙟ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.encode(vMhFypGLHZJbdX4O7oc3W8x(u"ࠧ࡭ࡣࡷ࡭ࡳ࠷ࠧᕷ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = kLtsvDVQ0SZmTjhBG9uW.decompress(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc)
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.decode(VOALf8iYEnMdK0g(u"ࠨࡷࡷࡪ࠽࠭ᕸ"))
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = NpdkYXCVjwSx(dP6f4SeYIyJuGjvHmUQRiq9WzabCgc, WhE7sDH4RQXrV)
		CZp6gROz47DXMPHufW2io, dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.split(Izy1PvclrYx4eSVWn0L5phZbq(u"ࠩࡿࢀࢁ࠭ᕹ"), nyUIsfd53EGot9vbj0XDeq)
		PXWrg9Tz56VAmM1ocG2 = ypO63g8oJEsDnPBHSuU7lMTZr(u"ࠪࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ᕺ")
		if XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK>wvkDqmNZlJU52isXo:
			VZBckgO7Gehb = uv8V4fE7j9pmgFr3wnDL.time()-int(CZp6gROz47DXMPHufW2io)
			if abs(VZBckgO7Gehb)>XTuGBP3Fjtlb5rLRpSn7V9D2gsEyK: PXWrg9Tz56VAmM1ocG2 = VOALf8iYEnMdK0g(u"ࠫࡎࡔࡖࡂࡎࡌࡈࡤ࡚ࡉࡎࡇࡖࡘࡆࡓࡐࠨᕻ")
		dP6f4SeYIyJuGjvHmUQRiq9WzabCgc = dP6f4SeYIyJuGjvHmUQRiq9WzabCgc.encode(DQIrVcKuY6bJv(u"ࠬࡻࡴࡧ࠺ࠪᕼ"))
	return dP6f4SeYIyJuGjvHmUQRiq9WzabCgc,PXWrg9Tz56VAmM1ocG2
from RyvhfqnkAZ import *