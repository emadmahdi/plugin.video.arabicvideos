# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'CIMANOW'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_CMN_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['قائمتي']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==300: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==301: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==302: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif mode==303: lfZmugQCFKLGT05AH29IsMiho = fg0SVX9tonC(url)
	elif mode==304: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==305: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==306: lfZmugQCFKLGT05AH29IsMiho = TOFltPsNmbCZa7Gk684x3h()
	elif mode==309: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,309,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr+'/home',SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<header(.*?)</header>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		title = title.strip(qE4nB3mKWHs)
		if not any(value in title for value in jgvMWZhtPlBT):
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,301)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	xwWavftjMBT0nJDsuz2g(j1IFsik4ouNePZr+'/home',LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def TOFltPsNmbCZa7Gk684x3h():
	gge5CmAcldwv0(SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,lFEvMxzSH2y7tYR,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def xwWavftjMBT0nJDsuz2g(url,LCK8lO2yRWaTVEQcdjPXAzpFBe9=SebHIf2jL1TBgrMKJu):
	if not LCK8lO2yRWaTVEQcdjPXAzpFBe9:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-SUBMENU-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	qqai0c7OSNreCszImF23EhYV1KnXLx = 0
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<section>.*?</section>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
		qqai0c7OSNreCszImF23EhYV1KnXLx += 1
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,DDXgol1wnE,cOn6JqZlmQbjtT in items:
			title = title.strip(qE4nB3mKWHs)
			if title==SebHIf2jL1TBgrMKJu: title = 'بووووو'
			if 'em><a' not in DDXgol1wnE:
				if drRnSgoBtKWjmU5FH4ZCIVhzqNb.count('/category/')>0:
					yLTJ2AUPMDwXc = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
					for cOn6JqZlmQbjtT in yLTJ2AUPMDwXc:
						title = cOn6JqZlmQbjtT.split('/')[-2]
						QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,301)
					continue
				else: cOn6JqZlmQbjtT = url+'?sequence='+str(qqai0c7OSNreCszImF23EhYV1KnXLx)
			if not any(value in title for value in jgvMWZhtPlBT):
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,302)
	else: yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,LCK8lO2yRWaTVEQcdjPXAzpFBe9=SebHIf2jL1TBgrMKJu):
	if LCK8lO2yRWaTVEQcdjPXAzpFBe9==SebHIf2jL1TBgrMKJu:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-TITLES-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if '?sequence=' in url:
		url,qqai0c7OSNreCszImF23EhYV1KnXLx = url.split('?sequence=')
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('(<section>.*?</section>)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[int(qqai0c7OSNreCszImF23EhYV1KnXLx)-1]
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"posts"(.*?)</body>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for cOn6JqZlmQbjtT,data,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs in items:
		title = X2XorVqHjLkWeCchY4u9fSz.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if title: title = title[0][2].replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		if not title or title==SebHIf2jL1TBgrMKJu:
			title = X2XorVqHjLkWeCchY4u9fSz.findall('title">.*?</em>(.*?)<',data,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if title: title = title[0].replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			if not title or title==SebHIf2jL1TBgrMKJu:
				title = X2XorVqHjLkWeCchY4u9fSz.findall('title">(.*?)<',data,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				title = title[0].replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
		title = cvlHmV1Kr0FIYSjNnM(title)
		title = title.replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		if title not in aLlVEzy8XR62:
			aLlVEzy8XR62.append(title)
			Q4idDwN25EKRJCajSyc = cOn6JqZlmQbjtT+data+tncvzBN0kyrqEHlhIPGSoX4ugA3CDs
			if '/selary/' in Q4idDwN25EKRJCajSyc or 'مسلسل' in Q4idDwN25EKRJCajSyc or '"episode"' in Q4idDwN25EKRJCajSyc:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,303,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,305,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"pagination"(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('<li><a href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,302)
	return
def fg0SVX9tonC(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-SEASONS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	name = X2XorVqHjLkWeCchY4u9fSz.findall('<title>(.*?)</title>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',SebHIf2jL1TBgrMKJu).replace('Cima Now',SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs).replace(nlNC2gJDBZMed63TxqphA1vrXm8Hy,qE4nB3mKWHs)
		name = name.split('الحلقة')[0].strip(qE4nB3mKWHs)+' - '
	else: name = SebHIf2jL1TBgrMKJu
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('<section(.*?)</section>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(items)>1:
			for cOn6JqZlmQbjtT,title in items:
				title = name+title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,304)
		elif len(items)==1:
			cOn6JqZlmQbjtT,title = items[0]
			LRb6nEvgqXwITMc80r1Vt(cOn6JqZlmQbjtT)
		else: LRb6nEvgqXwITMc80r1Vt(url)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if '/selary/' not in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"episodes"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			title = 'الحلقة '+title
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,305)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"details"(.*?)"related"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[wvkDqmNZlJU52isXo]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,305,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	X3urSPRtHLcC = X2XorVqHjLkWeCchY4u9fSz.findall('class="shine" href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if X3urSPRtHLcC:
		YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(X3urSPRtHLcC[0],'url')
		headers = {'Referer':YdzfwOyPb2gxT37B9Dm}
	else: headers = SebHIf2jL1TBgrMKJu
	qg7Nr1dCaD = url+'watching/'
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',qg7Nr1dCaD,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMANOW-PLAY-5th')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"download"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
			lcbjBn3FdZxC1059A4Kqvi2pugJOa = X2XorVqHjLkWeCchY4u9fSz.findall('\d\d\d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if lcbjBn3FdZxC1059A4Kqvi2pugJOa:
				lcbjBn3FdZxC1059A4Kqvi2pugJOa = '____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa[0]
				title = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
			else: lcbjBn3FdZxC1059A4Kqvi2pugJOa = SebHIf2jL1TBgrMKJu
			Sn3lefFys4XLgp8JiRvV = cOn6JqZlmQbjtT+'?named='+title+'__download'+lcbjBn3FdZxC1059A4Kqvi2pugJOa
			bQGVWFxKS4D6p9YC7XPyA8Os.append(Sn3lefFys4XLgp8JiRvV)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('"watch"(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = X2XorVqHjLkWeCchY4u9fSz.findall('"embed".*?src="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT in uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = 'http:'+cOn6JqZlmQbjtT
			title = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__embed'
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
		uLdRirAZJKoSgPqNUjm84WXE5cn3aT = [j1IFsik4ouNePZr+'/wp-content/themes/Cima%20Now%20New/core.php']
		if uLdRirAZJKoSgPqNUjm84WXE5cn3aT:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp,id,title in items:
				title = title.replace(u43PVWjh7t9YwI,SebHIf2jL1TBgrMKJu).strip(qE4nB3mKWHs)
				cOn6JqZlmQbjtT = uLdRirAZJKoSgPqNUjm84WXE5cn3aT[0]+'?action=switch&index='+ZC8P0GVfhuKtdzWFvoiUqSs5T3Dp+'&id='+id+'?named='+title+'__watch'
				bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr + '/?s='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	return