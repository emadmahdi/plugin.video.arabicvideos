# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'CIMA4U'
headers = {'User-Agent':SebHIf2jL1TBgrMKJu}
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_C4U_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def WdRmv9kTtLnfZ24(mode,url,text):
	if   mode==420: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==421: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,text)
	elif mode==422: lfZmugQCFKLGT05AH29IsMiho = fg0SVX9tonC(url)
	elif mode==423: lfZmugQCFKLGT05AH29IsMiho = LRb6nEvgqXwITMc80r1Vt(url)
	elif mode==424: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: lfZmugQCFKLGT05AH29IsMiho = vimwpBGoVK3EZrUkjPL(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==427: lfZmugQCFKLGT05AH29IsMiho = kqJ7XBfE9GdroZ2PtT0IpVHWY(url)
	elif mode==429: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	VK4jU2G3s1PwkticQYyLoW = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	VK4jU2G3s1PwkticQYyLoW = VK4jU2G3s1PwkticQYyLoW[0].strip('/')
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(VK4jU2G3s1PwkticQYyLoW,'url')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'بحث في الموقع',SebHIf2jL1TBgrMKJu,429,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'_REMEMBERRESULTS_')
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر محدد',VK4jU2G3s1PwkticQYyLoW,425)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'فلتر كامل',VK4jU2G3s1PwkticQYyLoW,424)
	QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الرئيسية',VK4jU2G3s1PwkticQYyLoW,421)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('NavigationMenu(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('href="*(.*?)"*>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for cOn6JqZlmQbjtT,title in items:
		if title in jgvMWZhtPlBT: continue
		if '/actors' in cOn6JqZlmQbjtT: title = 'أفلام النجوم'
		elif '/netflix' in cOn6JqZlmQbjtT: title = 'أفلام ومسلسلات نيتفلكس'
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,421)
	QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'قائمة تفصيلية',VK4jU2G3s1PwkticQYyLoW,427)
	return
def kqJ7XBfE9GdroZ2PtT0IpVHWY(website=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('FilteringTitle(.*?)PageTitle',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for kgy9Zm5TCvYHjE3PVQ,id,cOn6JqZlmQbjtT,title in items:
		if title in jgvMWZhtPlBT: continue
		if 'netflix-movies' in cOn6JqZlmQbjtT: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in cOn6JqZlmQbjtT: title = 'مسلسلات نيتفلكس'
		QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,kgy9Zm5TCvYHjE3PVQ+'|'+id)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,z9XqWIL1ZS4amgJK=SebHIf2jL1TBgrMKJu):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-TITLES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	if not z9XqWIL1ZS4amgJK or '|' in z9XqWIL1ZS4amgJK:
		if '|' not in z9XqWIL1ZS4amgJK: mdnhDS8IOLfcM = SebHIf2jL1TBgrMKJu
		else: mdnhDS8IOLfcM = '/archive/'+z9XqWIL1ZS4amgJK
		ZPo8Gl4iTpNHb6z5e3 = False
		if 'PinSlider' in LCK8lO2yRWaTVEQcdjPXAzpFBe9:
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المميزة',url,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'featured')
			ZPo8Gl4iTpNHb6z5e3 = True
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('PageTitle(.*?)PageContent',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			Q4idDwN25EKRJCajSyc = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			IkJNp71Hyu0PwFAXMTsOc = X2XorVqHjLkWeCchY4u9fSz.findall('data-tab="(.*?)".*?<span>(.*?)<',Q4idDwN25EKRJCajSyc,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for mqKYaelW4or7HsuOU,sABprza7wEOC0Fd3PTQ in IkJNp71Hyu0PwFAXMTsOc:
				Sn3lefFys4XLgp8JiRvV = VK4jU2G3s1PwkticQYyLoW+'/ajaxcenter/action/HomepageLoader/tab/'+mqKYaelW4or7HsuOU+mdnhDS8IOLfcM+'/'
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+sABprza7wEOC0Fd3PTQ,Sn3lefFys4XLgp8JiRvV,421)
				ZPo8Gl4iTpNHb6z5e3 = True
		if ZPo8Gl4iTpNHb6z5e3: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	if z9XqWIL1ZS4amgJK=='featured':
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('PinSlider(.*?)MultiFilter',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if not k2pC30UArFeg7Ru9tGiZlSmzQ: k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('PinSlider(.*?)PageTitle',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		else: drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = LCK8lO2yRWaTVEQcdjPXAzpFBe9
	elif '/filter/' in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('PageContent(.*?)class="*pagination"*',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	elif '/actors' in url:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('PageContent(.*?)class="*pagination"*',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	else:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('Cima4uBlocks(.*?)</li></ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ: drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		else: drRnSgoBtKWjmU5FH4ZCIVhzqNb = SebHIf2jL1TBgrMKJu
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if not items: items = X2XorVqHjLkWeCchY4u9fSz.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	aLlVEzy8XR62 = []
	for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
		if not title: continue
		if '?news=' in cOn6JqZlmQbjtT: continue
		title = title.replace('مشاهدة ',SebHIf2jL1TBgrMKJu)
		title = cvlHmV1Kr0FIYSjNnM(title)
		Wj39BaH6oEmstx = X2XorVqHjLkWeCchY4u9fSz.findall('(.*?) حلقة \d+',title,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if Wj39BaH6oEmstx and 'حلقة' in title:
			title = '_MOD_' + Wj39BaH6oEmstx[0]
			if title not in aLlVEzy8XR62:
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,422,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				aLlVEzy8XR62.append(title)
		elif '/actor/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,421,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,422,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('pagination(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ and z9XqWIL1ZS4amgJK!='featured':
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = cvlHmV1Kr0FIYSjNnM(title)
			title = title.replace('الصفحة ',SebHIf2jL1TBgrMKJu)
			if title!=SebHIf2jL1TBgrMKJu: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'صفحة '+title,cOn6JqZlmQbjtT,421)
	UEGO1pCKJNl9xo2tyr = X2XorVqHjLkWeCchY4u9fSz.findall('</li><a href="(.*?)".*?>(.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if UEGO1pCKJNl9xo2tyr:
		cOn6JqZlmQbjtT,title = UEGO1pCKJNl9xo2tyr[0]
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,421)
	return
def fg0SVX9tonC(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-SEASONS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="WatchNow".*?href="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		url = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-SEASONS-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('SeasonsSections(.*?)</div></div></div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if '/tag/' in url or '/actor' in url:
		yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
	elif k2pC30UArFeg7Ru9tGiZlSmzQ:
		tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = if5dy2h0nsDVlukoQ7NUFqx4cGEW.getInfoLabel('ListItem.Thumb')
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall("href='(.*?)'>(.*?)<",drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		BBchPaOE8MY7CKnpj = ['مسلسل','موسم','برنامج','حلقة']
		for cOn6JqZlmQbjtT,title in items:
			if any(value in title for value in BBchPaOE8MY7CKnpj):
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,423,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,426,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else: LRb6nEvgqXwITMc80r1Vt(url)
	return
def LRb6nEvgqXwITMc80r1Vt(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = X2XorVqHjLkWeCchY4u9fSz.findall('"background-image:url\((.*?)\)',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if tncvzBN0kyrqEHlhIPGSoX4ugA3CDs: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs[0]
	else: tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = SebHIf2jL1TBgrMKJu
	HuWE2wVTFIO6k4 = X2XorVqHjLkWeCchY4u9fSz.findall('EpisodesSection(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if HuWE2wVTFIO6k4:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = HuWE2wVTFIO6k4[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title,Wj39BaH6oEmstx in items:
			title = title+qE4nB3mKWHs+Wj39BaH6oEmstx
			QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,426,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'رابط التشغيل',url,426,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
	return
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,headers,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	urGOi5MSH6D7PobQEp = Bc5IUelt4sWvMXTdy.url
	if psS8dmb912iRBgGc7qOPyCZ6: urGOi5MSH6D7PobQEp = urGOi5MSH6D7PobQEp.encode(Tv08xsf9HOqunIVUPdK1)
	VK4jU2G3s1PwkticQYyLoW = EDmwsQf1Px9k8h04oAHuObdnyrTGU(urGOi5MSH6D7PobQEp,'url')
	bQGVWFxKS4D6p9YC7XPyA8Os = []
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('WatchSection(.*?)</div></div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('data-link="(.*?)".*? />(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for IIU5djzb1RCg7QwYauEHvMcrGDA0Bt,title in items:
			title = title.strip(qE4nB3mKWHs)
			if 'myvid' in title.lower(): title = 'خاص '+title
			cOn6JqZlmQbjtT = VK4jU2G3s1PwkticQYyLoW+'/structure/server.php?id='+IIU5djzb1RCg7QwYauEHvMcrGDA0Bt+'?named='+title+'__watch'
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu)
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('DownloadServers(.*?)</div></div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*? />(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.strip(qE4nB3mKWHs)
			if 'myvid' in title.lower(): sABprza7wEOC0Fd3PTQ = '__خاص'
			else: sABprza7wEOC0Fd3PTQ = SebHIf2jL1TBgrMKJu
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT+'?named='+title+'__download'+sABprza7wEOC0Fd3PTQ
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.replace(vvm0bR6z8NK5wUg2l9jqrJu,SebHIf2jL1TBgrMKJu)
			bQGVWFxKS4D6p9YC7XPyA8Os.append(cOn6JqZlmQbjtT)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(bQGVWFxKS4D6p9YC7XPyA8Os,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(search):
	search,ndiZQ7oLFkV1W,showDialogs = sKhzPm0oUq7LO3Wk5Q(search)
	if search==SebHIf2jL1TBgrMKJu: search = zWKdm3kV2ItwYrgH1BZyRON()
	if search==SebHIf2jL1TBgrMKJu: return
	search = search.replace(qE4nB3mKWHs,'+')
	url = j1IFsik4ouNePZr+'/Search?q='+search
	yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,'search')
	return
def OU0dGs5xyz9KH3o7(url):
	if 'smartemadfilter' not in url: url = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('MultiFilter(.*?)PageTitle',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
	BJheYUDK3EOyfPR24 = X2XorVqHjLkWeCchY4u9fSz.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return BJheYUDK3EOyfPR24
def TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb):
	items = X2XorVqHjLkWeCchY4u9fSz.findall('data-id="(.*?)".*?</div>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	return items
def s7GugCDv4lrB(url):
	iiXk0elDVoLTZ8HUAaB = url.split('/smartemadfilter?')[0]
	BDku1TovVtpfmhL9Ryde4nNQ = EDmwsQf1Px9k8h04oAHuObdnyrTGU(url,'url')
	url = url.replace(iiXk0elDVoLTZ8HUAaB,BDku1TovVtpfmhL9Ryde4nNQ)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
PD0JksfFrlMUtG6OWVLgdiY8o5b = ['category','types','release-year']
CIHKiYt9osw4SyjMfhP0rZ8 = ['Quality','release-year','types','category']
def vimwpBGoVK3EZrUkjPL(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==SebHIf2jL1TBgrMKJu: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	else: EH6SWa3KmUw7c18RF,wk0AjSOpcRB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global PD0JksfFrlMUtG6OWVLgdiY8o5b
			PD0JksfFrlMUtG6OWVLgdiY8o5b = PD0JksfFrlMUtG6OWVLgdiY8o5b[1:]
		if PD0JksfFrlMUtG6OWVLgdiY8o5b[0]+'=' not in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[0]
		for YHnALfql8hprDu in range(len(PD0JksfFrlMUtG6OWVLgdiY8o5b[0:-1])):
			if PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu]+'=' in EH6SWa3KmUw7c18RF: kgy9Zm5TCvYHjE3PVQ = PD0JksfFrlMUtG6OWVLgdiY8o5b[YHnALfql8hprDu+1]
		UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+kgy9Zm5TCvYHjE3PVQ+'=0'
		L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9.strip('&')+'___'+hW2bu9H1KJCkPlfr.strip('&')
		LnwzHFAVsfO2Go = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		qg7Nr1dCaD = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
	elif type=='ALL_ITEMS_FILTER':
		GN1JTvzClSs = iUhuldq0me2a(EH6SWa3KmUw7c18RF,'modified_values')
		GN1JTvzClSs = kLEi7mYT5wBM4DHsgWy8(GN1JTvzClSs)
		if wk0AjSOpcRB!=SebHIf2jL1TBgrMKJu: wk0AjSOpcRB = iUhuldq0me2a(wk0AjSOpcRB,'modified_filters')
		if wk0AjSOpcRB==SebHIf2jL1TBgrMKJu: qg7Nr1dCaD = url
		else: qg7Nr1dCaD = url+'/smartemadfilter?'+wk0AjSOpcRB
		qg7Nr1dCaD = s7GugCDv4lrB(qg7Nr1dCaD)
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'أظهار قائمة الفيديو التي تم اختيارها ',qg7Nr1dCaD,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filter')
		QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+' [[   '+GN1JTvzClSs+'   ]]',qg7Nr1dCaD,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filter')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	BJheYUDK3EOyfPR24 = OU0dGs5xyz9KH3o7(url)
	dict = {}
	for name,drRnSgoBtKWjmU5FH4ZCIVhzqNb,oIi8QaPyZBr1mvUcsh in BJheYUDK3EOyfPR24:
		if '/category/' in url and oIi8QaPyZBr1mvUcsh=='category': continue
		name = name.replace('--',SebHIf2jL1TBgrMKJu)
		items = TJzv9sXFkwIbftAir0REZHnYO1(drRnSgoBtKWjmU5FH4ZCIVhzqNb)
		if '=' not in qg7Nr1dCaD: qg7Nr1dCaD = url
		if type=='SPECIFIED_FILTER':
			if kgy9Zm5TCvYHjE3PVQ!=oIi8QaPyZBr1mvUcsh: continue
			elif len(items)<2:
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]:
					url = s7GugCDv4lrB(url)
					yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url)
				else: vimwpBGoVK3EZrUkjPL(qg7Nr1dCaD,'SPECIFIED_FILTER___'+L6xuGTevZQFjgoN05EHYzkVDMnql)
				return
			else:
				qg7Nr1dCaD = s7GugCDv4lrB(qg7Nr1dCaD)
				if oIi8QaPyZBr1mvUcsh==PD0JksfFrlMUtG6OWVLgdiY8o5b[-1]: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filter')
				else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع',qg7Nr1dCaD,425,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		elif type=='ALL_ITEMS_FILTER':
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'=0'
			L6xuGTevZQFjgoN05EHYzkVDMnql = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'الجميع :'+name,qg7Nr1dCaD,424,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,L6xuGTevZQFjgoN05EHYzkVDMnql)
		dict[oIi8QaPyZBr1mvUcsh] = {}
		for value,OSEMFXaUVI1eqHhQYmbKPdJAnrk in items:
			if value=='196533': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'أفلام نيتفلكس'
			elif value=='196531': OSEMFXaUVI1eqHhQYmbKPdJAnrk = 'مسلسلات نيتفلكس'
			if OSEMFXaUVI1eqHhQYmbKPdJAnrk in jgvMWZhtPlBT: continue
			dict[oIi8QaPyZBr1mvUcsh][value] = OSEMFXaUVI1eqHhQYmbKPdJAnrk
			UszS4HoN5TgK9 = EH6SWa3KmUw7c18RF+'&'+oIi8QaPyZBr1mvUcsh+'='+OSEMFXaUVI1eqHhQYmbKPdJAnrk
			hW2bu9H1KJCkPlfr = wk0AjSOpcRB+'&'+oIi8QaPyZBr1mvUcsh+'='+value
			ekRd8AFWNzbpm3qUGOyi9JhrTCjf = UszS4HoN5TgK9+'___'+hW2bu9H1KJCkPlfr
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'#+dict[oIi8QaPyZBr1mvUcsh]['0']
			title = OSEMFXaUVI1eqHhQYmbKPdJAnrk+' :'+name
			if type=='ALL_ITEMS_FILTER': QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,424,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
			elif type=='SPECIFIED_FILTER' and PD0JksfFrlMUtG6OWVLgdiY8o5b[-2]+'=' in EH6SWa3KmUw7c18RF:
				LnwzHFAVsfO2Go = iUhuldq0me2a(hW2bu9H1KJCkPlfr,'modified_filters')
				iGxH2fsuScPtkJb7ECg = url+'/smartemadfilter?'+LnwzHFAVsfO2Go
				iGxH2fsuScPtkJb7ECg = s7GugCDv4lrB(iGxH2fsuScPtkJb7ECg)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,iGxH2fsuScPtkJb7ECg,421,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'filter')
			else: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,url,425,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,ekRd8AFWNzbpm3qUGOyi9JhrTCjf)
	return
def iUhuldq0me2a(XtQ5cesqPJAz3h,mode):
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.replace('=&','=0&')
	XtQ5cesqPJAz3h = XtQ5cesqPJAz3h.strip('&')
	sezY2ok3RI69Oahwu7LCQAGUitZH = {}
	if '=' in XtQ5cesqPJAz3h:
		items = XtQ5cesqPJAz3h.split('&')
		for JJSOAkTZIib4eswDo51pFuqvK in items:
			vaNAKXHVj0mLPW9I68213R,value = JJSOAkTZIib4eswDo51pFuqvK.split('=')
			sezY2ok3RI69Oahwu7LCQAGUitZH[vaNAKXHVj0mLPW9I68213R] = value
	hIyBYfuc8oTsEZ = SebHIf2jL1TBgrMKJu
	for key in CIHKiYt9osw4SyjMfhP0rZ8:
		if key in list(sezY2ok3RI69Oahwu7LCQAGUitZH.keys()): value = sezY2ok3RI69Oahwu7LCQAGUitZH[key]
		else: value = '0'
		if '%' not in value: value = xuCTZaNtMVwFs(value)
		if mode=='modified_values' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+' + '+value
		elif mode=='modified_filters' and value!='0': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
		elif mode=='all': hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ+'&'+key+'='+value
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip(' + ')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.strip('&')
	hIyBYfuc8oTsEZ = hIyBYfuc8oTsEZ.replace('=0','=')
	return hIyBYfuc8oTsEZ