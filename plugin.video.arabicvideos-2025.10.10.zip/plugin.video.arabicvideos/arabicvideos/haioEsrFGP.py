# -*- coding: utf-8 -*-
from RSdDifzoPG import *
tfX4sO3hy2H1IbKG = 'EGYBEST3'
FFe0IfYj65szqgLHkNpBPJnRQEmZo = '_EB3_'
j1IFsik4ouNePZr = qFsuKN7ngp.SITESURLS[tfX4sO3hy2H1IbKG][0]
jgvMWZhtPlBT = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def WdRmv9kTtLnfZ24(mode,url,Q8A5HyT1fGNxZv4X3V7eC,text):
	if   mode==790: lfZmugQCFKLGT05AH29IsMiho = EEXPfIxMNny1QzZt6gKkA()
	elif mode==791: lfZmugQCFKLGT05AH29IsMiho = yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==792: lfZmugQCFKLGT05AH29IsMiho = xwWavftjMBT0nJDsuz2g(url)
	elif mode==793: lfZmugQCFKLGT05AH29IsMiho = rRCw3hfy2Kq5l(url)
	elif mode==796: lfZmugQCFKLGT05AH29IsMiho = oaylPZ1DvdTh54(url,Q8A5HyT1fGNxZv4X3V7eC)
	elif mode==799: lfZmugQCFKLGT05AH29IsMiho = yEPLitfHnvAdz0I9SVoC(text)
	else: lfZmugQCFKLGT05AH29IsMiho = False
	return lfZmugQCFKLGT05AH29IsMiho
def EEXPfIxMNny1QzZt6gKkA():
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(iHR47eol8wB3Z,'GET',j1IFsik4ouNePZr,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-MENU-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('list-pages(.*?)fa-folder',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?<span>(.*?)</span>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.strip(qE4nB3mKWHs)
			if any(value in title for value in jgvMWZhtPlBT): continue
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791)
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-article(.*?)social-box',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('main-title.*?">(.*?)<.*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for title,cOn6JqZlmQbjtT in items:
			title = title.strip(qE4nB3mKWHs)
			if any(value in title for value in jgvMWZhtPlBT): continue
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791,SebHIf2jL1TBgrMKJu,'mainmenu')
		QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-menu(.*?)</ul>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for cOn6JqZlmQbjtT,title in items:
			title = title.strip(qE4nB3mKWHs)
			if any(value in title for value in jgvMWZhtPlBT): continue
			if 'http' not in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = j1IFsik4ouNePZr+cOn6JqZlmQbjtT
			QUzFYoapm9jx('folder',tfX4sO3hy2H1IbKG+'_SCRIPT_'+FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791)
	return LCK8lO2yRWaTVEQcdjPXAzpFBe9
def oaylPZ1DvdTh54(url,type=SebHIf2jL1TBgrMKJu):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-SEASONS_EPISODES-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-article".*?">(.*?)<(.*?)article',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		DmS9dwGqQIfP6sv,EiadFrl0bx3uWPqGmIkHNQp,items = SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,[]
		for name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in k2pC30UArFeg7Ru9tGiZlSmzQ:
			if 'حلقات' in name: EiadFrl0bx3uWPqGmIkHNQp = drRnSgoBtKWjmU5FH4ZCIVhzqNb
			if 'مواسم' in name: DmS9dwGqQIfP6sv = drRnSgoBtKWjmU5FH4ZCIVhzqNb
		if DmS9dwGqQIfP6sv and not type:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',DmS9dwGqQIfP6sv,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if len(items)>1:
				for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
					QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,796,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,'season')
		if EiadFrl0bx3uWPqGmIkHNQp and len(items)<2:
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',EiadFrl0bx3uWPqGmIkHNQp,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			if items:
				for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
					QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,793,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
			else:
				items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',EiadFrl0bx3uWPqGmIkHNQp,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
				for cOn6JqZlmQbjtT,title in items:
					QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,793)
	return
def yZ0TV4xQFGqhfnDOScHl8dX2iIMrA(url,type=SebHIf2jL1TBgrMKJu):
	qrvUApFodEiBV,start,ZZW5QJxjDlBLpGHA,select,t5071oRZiTf3FLQNyeulnJ = 0,0,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu
	if 'pagination' in type:
		C6sOK1BVidGek,data = lhC3Axj8TQSsRWeu0k(url)
		qrvUApFodEiBV = int(data['limit'])
		start = int(data['start'])
		ZZW5QJxjDlBLpGHA = data['type']
		select = data['select']
		bIGXajdcK6PQBs = 'limit='+str(qrvUApFodEiBV)+'&start='+str(start)+'&type='+ZZW5QJxjDlBLpGHA+'&select='+select
		REIkboX9NtlZCSU3A = {'Content-Type':'application/x-www-form-urlencoded'}
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',C6sOK1BVidGek,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-TITLES-1st')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		O3XeD9sgNyH = 'blocks'+LCK8lO2yRWaTVEQcdjPXAzpFBe9+'article'
	else:
		Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-TITLES-2nd')
		LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
		O3XeD9sgNyH = LCK8lO2yRWaTVEQcdjPXAzpFBe9
		code = X2XorVqHjLkWeCchY4u9fSz.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if code:
			code = code[0].replace('var',SebHIf2jL1TBgrMKJu).replace(qE4nB3mKWHs,SebHIf2jL1TBgrMKJu).replace("'",SebHIf2jL1TBgrMKJu).replace(';','&')
			fNnuAzFsXhBKCco9JZeVUvd7Ya,data = lhC3Axj8TQSsRWeu0k('?'+code)
			qrvUApFodEiBV = int(data['limit'])
			start = int(data['start'])
			ZZW5QJxjDlBLpGHA = data['type']
			select = data['select']
			t5071oRZiTf3FLQNyeulnJ = data['ajaxurl']
			bIGXajdcK6PQBs = 'limit='+str(qrvUApFodEiBV)+'&start='+str(start)+'&type='+ZZW5QJxjDlBLpGHA+'&select='+select
			C6sOK1BVidGek = j1IFsik4ouNePZr+t5071oRZiTf3FLQNyeulnJ
			REIkboX9NtlZCSU3A = {'Content-Type':'application/x-www-form-urlencoded'}
			Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(QfG1xIZ4hpq3ezPXt7VbvglUcB,'POST',C6sOK1BVidGek,bIGXajdcK6PQBs,REIkboX9NtlZCSU3A,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-TITLES-3rd')
			O3XeD9sgNyH = Bc5IUelt4sWvMXTdy.content
			O3XeD9sgNyH = 'blocks'+O3XeD9sgNyH+'article'
	items,maLkfvKbCnyS4EjXG87,XtQ5cesqPJAz3h = [],False,False
	if not type:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-content(.*?)</div>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?</i>(.*?)</a>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,title in items:
				title = title.strip(qE4nB3mKWHs)
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791,SebHIf2jL1TBgrMKJu,'submenu')
				maLkfvKbCnyS4EjXG87 = True
	if not type:
		XtQ5cesqPJAz3h = XbcsqfLxQa6gWTPwKFj2dACYm4lvM(LCK8lO2yRWaTVEQcdjPXAzpFBe9)
	if not maLkfvKbCnyS4EjXG87 and not XtQ5cesqPJAz3h:
		k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('blocks(.*?)article',O3XeD9sgNyH,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if k2pC30UArFeg7Ru9tGiZlSmzQ:
			drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs,title in items:
				tncvzBN0kyrqEHlhIPGSoX4ugA3CDs = tncvzBN0kyrqEHlhIPGSoX4ugA3CDs.strip(u43PVWjh7t9YwI)
				cOn6JqZlmQbjtT = kLEi7mYT5wBM4DHsgWy8(cOn6JqZlmQbjtT)
				if '/selary/' in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				elif 'مسلسل' in cOn6JqZlmQbjtT and 'حلقة' not in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,796,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				elif 'موسم' in cOn6JqZlmQbjtT and 'حلقة' not in cOn6JqZlmQbjtT: QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,796,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
				else: QUzFYoapm9jx('video',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,793,tncvzBN0kyrqEHlhIPGSoX4ugA3CDs)
		r8rTQdMpy79wz = 12
		data = X2XorVqHjLkWeCchY4u9fSz.findall('class="(load-more.*?)<',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if len(items)==r8rTQdMpy79wz and (data or 'pagination' in type):
			bIGXajdcK6PQBs = 'limit='+str(r8rTQdMpy79wz)+'&start='+str(start+r8rTQdMpy79wz)+'&type='+ZZW5QJxjDlBLpGHA+'&select='+select
			qg7Nr1dCaD = C6sOK1BVidGek+'?next=page&'+bIGXajdcK6PQBs
			QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+'المزيد',qg7Nr1dCaD,791,SebHIf2jL1TBgrMKJu,'pagination_'+type)
	return
def XbcsqfLxQa6gWTPwKFj2dACYm4lvM(LCK8lO2yRWaTVEQcdjPXAzpFBe9):
	XtQ5cesqPJAz3h = False
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('main-article(.*?)article',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		cuoYjfNMPnmhQgtFE = X2XorVqHjLkWeCchY4u9fSz.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if cuoYjfNMPnmhQgtFE: QUzFYoapm9jx('link',E7r8hUCVvTiFQW0dBGXjxcy+' ===== ===== ===== '+XOVRfitWJP1zL3p2CMYF,SebHIf2jL1TBgrMKJu,9999)
		for kgy9Zm5TCvYHjE3PVQ,name,drRnSgoBtKWjmU5FH4ZCIVhzqNb in cuoYjfNMPnmhQgtFE:
			name = name.strip(qE4nB3mKWHs)
			items = X2XorVqHjLkWeCchY4u9fSz.findall('href="(.*?)">(.*?)<',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
			for cOn6JqZlmQbjtT,value in items:
				title = name+':  '+value
				QUzFYoapm9jx('folder',FFe0IfYj65szqgLHkNpBPJnRQEmZo+title,cOn6JqZlmQbjtT,791,SebHIf2jL1TBgrMKJu,'filter')
				XtQ5cesqPJAz3h = True
	return XtQ5cesqPJAz3h
def rRCw3hfy2Kq5l(url):
	Bc5IUelt4sWvMXTdy = WMx8v0FVCjlhcQKRwdX1s(RycFd7wZBiNhJjOPIGKp,'GET',url,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,SebHIf2jL1TBgrMKJu,'EGYBEST3-PLAY-1st')
	LCK8lO2yRWaTVEQcdjPXAzpFBe9 = Bc5IUelt4sWvMXTdy.content
	qOGEcWZIwex2fK,B6BsHXWZwD = [],[]
	items = X2XorVqHjLkWeCchY4u9fSz.findall('server-item.*?data-code="(.*?)"',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	for EJdeYCbv2rmtGRhxIMg in items:
		KKGvsxcymk74FjDlhC = ej3oxQLc68OIY.b64decode(EJdeYCbv2rmtGRhxIMg)
		if QBOMjKifEAFD: KKGvsxcymk74FjDlhC = KKGvsxcymk74FjDlhC.decode(Tv08xsf9HOqunIVUPdK1)
		cOn6JqZlmQbjtT = X2XorVqHjLkWeCchY4u9fSz.findall('src="(.*?)"',KKGvsxcymk74FjDlhC,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		if cOn6JqZlmQbjtT:
			cOn6JqZlmQbjtT = cOn6JqZlmQbjtT[0]
			if cOn6JqZlmQbjtT not in B6BsHXWZwD:
				B6BsHXWZwD.append(cOn6JqZlmQbjtT)
				YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__watch')
	k2pC30UArFeg7Ru9tGiZlSmzQ = X2XorVqHjLkWeCchY4u9fSz.findall('class="downloads(.*?)</section>',LCK8lO2yRWaTVEQcdjPXAzpFBe9,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
	if k2pC30UArFeg7Ru9tGiZlSmzQ:
		drRnSgoBtKWjmU5FH4ZCIVhzqNb = k2pC30UArFeg7Ru9tGiZlSmzQ[0]
		items = X2XorVqHjLkWeCchY4u9fSz.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',drRnSgoBtKWjmU5FH4ZCIVhzqNb,X2XorVqHjLkWeCchY4u9fSz.DOTALL)
		for lcbjBn3FdZxC1059A4Kqvi2pugJOa,cOn6JqZlmQbjtT in items:
			if cOn6JqZlmQbjtT not in B6BsHXWZwD:
				if '/?url=' in cOn6JqZlmQbjtT: cOn6JqZlmQbjtT = cOn6JqZlmQbjtT.split('/?url=')[1]
				B6BsHXWZwD.append(cOn6JqZlmQbjtT)
				YdzfwOyPb2gxT37B9Dm = EDmwsQf1Px9k8h04oAHuObdnyrTGU(cOn6JqZlmQbjtT,'name')
				qOGEcWZIwex2fK.append(cOn6JqZlmQbjtT+'?named='+YdzfwOyPb2gxT37B9Dm+'__download____'+lcbjBn3FdZxC1059A4Kqvi2pugJOa)
	import dBWq3E7PZC
	dBWq3E7PZC.egUEyPqk4Xfnl8JtTmoSRcrbBYhQ(qOGEcWZIwex2fK,tfX4sO3hy2H1IbKG,'video',url)
	return
def yEPLitfHnvAdz0I9SVoC(text):
	return