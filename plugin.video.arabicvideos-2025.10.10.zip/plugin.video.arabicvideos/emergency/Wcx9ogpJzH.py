# -*- coding: utf-8 -*-
import sys as shwSAqX5dk9N7Q1
AxKzWCV8kSwPG = shwSAqX5dk9N7Q1.version_info [0] == 2
D7ti8H3K4Gf5nVv = 2048
x25Vc8ktmRJQ7P6S0GsjI = 7
def fvbF0zwouLXiTESWnH (VSo7Ilq3gLfdvWF8mRrNbs1aw0HKJ):
	global n9ASP0qXxtDd3
	XXR0hqeP7QYVxrAdzT1CSJ3NHL = ord (VSo7Ilq3gLfdvWF8mRrNbs1aw0HKJ [-1])
	OQmq3kSdRp9Lf58Mra7BYx0ewv4 = VSo7Ilq3gLfdvWF8mRrNbs1aw0HKJ [:-1]
	GcbYI6JHK9CXzFPlesQg7p8A3O = XXR0hqeP7QYVxrAdzT1CSJ3NHL % len (OQmq3kSdRp9Lf58Mra7BYx0ewv4)
	Ffa8xRNyvl16XnU4T0mbB75CK = OQmq3kSdRp9Lf58Mra7BYx0ewv4 [:GcbYI6JHK9CXzFPlesQg7p8A3O] + OQmq3kSdRp9Lf58Mra7BYx0ewv4 [GcbYI6JHK9CXzFPlesQg7p8A3O:]
	if AxKzWCV8kSwPG:
		iioYbZqBzRpsHLf9ySmA = unicode () .join ([unichr (ord (IIJmFHvoB5R9LkwZrpeTEYuflO) - D7ti8H3K4Gf5nVv - (RStgey31sC7H6uhPXEQxaW + XXR0hqeP7QYVxrAdzT1CSJ3NHL) % x25Vc8ktmRJQ7P6S0GsjI) for RStgey31sC7H6uhPXEQxaW, IIJmFHvoB5R9LkwZrpeTEYuflO in enumerate (Ffa8xRNyvl16XnU4T0mbB75CK)])
	else:
		iioYbZqBzRpsHLf9ySmA = str () .join ([chr (ord (IIJmFHvoB5R9LkwZrpeTEYuflO) - D7ti8H3K4Gf5nVv - (RStgey31sC7H6uhPXEQxaW + XXR0hqeP7QYVxrAdzT1CSJ3NHL) % x25Vc8ktmRJQ7P6S0GsjI) for RStgey31sC7H6uhPXEQxaW, IIJmFHvoB5R9LkwZrpeTEYuflO in enumerate (Ffa8xRNyvl16XnU4T0mbB75CK)])
	return eval (iioYbZqBzRpsHLf9ySmA)
FUnxhBINQCER4dr29lL13uf,HHoYXqfmygc6tbakNlTdAsj3e,SjVEuMAYapCKh=fvbF0zwouLXiTESWnH,fvbF0zwouLXiTESWnH,fvbF0zwouLXiTESWnH
splMDxz8bJeT4,Bp3MrQkwG875f1IvuPNgZVjY,X5quC7wg1l63tZcGp94BiQnJe0xHr=SjVEuMAYapCKh,HHoYXqfmygc6tbakNlTdAsj3e,FUnxhBINQCER4dr29lL13uf
PyGknJqXUOEHN,NdJhSgG3QAuOV8tx4aMkl,ecVEQBZF9RPS0s3igx=X5quC7wg1l63tZcGp94BiQnJe0xHr,Bp3MrQkwG875f1IvuPNgZVjY,splMDxz8bJeT4
Z96DFLfxObsyIpCEjWaY85gr0eH,gnV6yqprD9vxOAL0SEtRMsJ1,M6NQ7Ydty9mxHoAlURVK2JsOqTzac=ecVEQBZF9RPS0s3igx,NdJhSgG3QAuOV8tx4aMkl,PyGknJqXUOEHN
iBERSucw418DTot6P9bWkKmsCdnGNz,da2FeZI5wgM1sQNkrKpf0EAB,nnOcL691Yk5P2Ti=M6NQ7Ydty9mxHoAlURVK2JsOqTzac,gnV6yqprD9vxOAL0SEtRMsJ1,Z96DFLfxObsyIpCEjWaY85gr0eH
VpXrJZvtxIMUG2PFzhYbnOQiL,hDaezT4QC5H1Zut,awnIWZxjlPDL3ON=nnOcL691Yk5P2Ti,da2FeZI5wgM1sQNkrKpf0EAB,iBERSucw418DTot6P9bWkKmsCdnGNz
c86BurSztN,zeBA41YmvyM,oA8jxeUYWJNRSwXBmKirP=awnIWZxjlPDL3ON,hDaezT4QC5H1Zut,VpXrJZvtxIMUG2PFzhYbnOQiL
GGfpgnj7VswDmX6xPIqUlht,mk7Ey1CHidTfXcx3Mro,dQi1fumWEJcYlXN8e6wThgzn=oA8jxeUYWJNRSwXBmKirP,zeBA41YmvyM,c86BurSztN
TGu28FWmDN,nNYxkBQ3FzHAsy,Wi53RMs0N7ICt8Q=dQi1fumWEJcYlXN8e6wThgzn,mk7Ey1CHidTfXcx3Mro,GGfpgnj7VswDmX6xPIqUlht
RRk5ISDpdvhugZOL2yzQqCa6s,aeWVqAL0jKGUwtPr,nZCBzxNycI9qt4RwDXl8LUmro7YW=Wi53RMs0N7ICt8Q,nNYxkBQ3FzHAsy,TGu28FWmDN
cjap9k4NZFsBIhJ6Qvud,VwkK0Sfaj1R7,Caf4AoYwGdQHVuc7bFhDRjWs1zPByM=nZCBzxNycI9qt4RwDXl8LUmro7YW,aeWVqAL0jKGUwtPr,RRk5ISDpdvhugZOL2yzQqCa6s
import xbmc as VgMbSZwhKPufzJAi6X2q,xbmcgui as IEuQ2sD6dVHgtPcUJAXrf,sys as shwSAqX5dk9N7Q1,os as xOVXGiyZl83Iw4qWnSRCBg1kK,requests as qDZ1o6NpJMhgIRAHixbrY84OwTvneQ,re as llSvm80ILwRWQHE9G3ndsMbaeZ6px,xbmcvfs as JmXZToc4z3tv,base64 as RqI974yXLnc8FKOa165om,time as cF6WjpkQVt8HuLCwGzmESUTa3
oceVwPi0xy = VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࠫࠬࠀ")
def GGxWKq7MCHhv4A8E(request):
	Li21lnStOAoXkVNJyjrmQdDeUPbuv = VwkK0Sfaj1R7(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==SjVEuMAYapCKh(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): VgMbSZwhKPufzJAi6X2q.executebuiltin(hDaezT4QC5H1Zut(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+Li21lnStOAoXkVNJyjrmQdDeUPbuv+GGfpgnj7VswDmX6xPIqUlht(u"ࠨࠫࠪࠄ"))
	elif request==splMDxz8bJeT4(u"ࠩࡶࡸࡴࡶࠧࠅ"): VgMbSZwhKPufzJAi6X2q.executebuiltin(awnIWZxjlPDL3ON(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+Li21lnStOAoXkVNJyjrmQdDeUPbuv+Bp3MrQkwG875f1IvuPNgZVjY(u"ࠫ࠮࠭ࠇ"))
	return
def Ewi5PYoDKrshtF3pHjI1gUuGc(hhD2nAQMktr6E4JI7dpcRWFjiNV0G,KBkoyPpfWTLc3CNdJGUH,rc3JYnvjluB7TtWR,tEemMWQ0IlTrJXhdSgvB6,text):
	if not KBkoyPpfWTLc3CNdJGUH: KBkoyPpfWTLc3CNdJGUH = GGfpgnj7VswDmX6xPIqUlht(u"้ࠬไศࠩࠈ")
	if not rc3JYnvjluB7TtWR: rc3JYnvjluB7TtWR = c86BurSztN(u"࠭ๆฺ็ࠪࠉ")
	if not tEemMWQ0IlTrJXhdSgvB6: tEemMWQ0IlTrJXhdSgvB6 = VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if S5YX1iKkvz: eCNxBHQz0r4K2vAjmF8go = IEuQ2sD6dVHgtPcUJAXrf.Dialog().yesno(tEemMWQ0IlTrJXhdSgvB6,text,oceVwPi0xy,oceVwPi0xy,KBkoyPpfWTLc3CNdJGUH,rc3JYnvjluB7TtWR)
	else: eCNxBHQz0r4K2vAjmF8go = IEuQ2sD6dVHgtPcUJAXrf.Dialog().yesno(tEemMWQ0IlTrJXhdSgvB6,text,KBkoyPpfWTLc3CNdJGUH,rc3JYnvjluB7TtWR)
	return eCNxBHQz0r4K2vAjmF8go
def jmaTzWRGoZqE(hhD2nAQMktr6E4JI7dpcRWFjiNV0G,VvFTlRKij1fO83PMCcwq9aoxmbWNdz,tEemMWQ0IlTrJXhdSgvB6,text):
	if not tEemMWQ0IlTrJXhdSgvB6: tEemMWQ0IlTrJXhdSgvB6 = PyGknJqXUOEHN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return IEuQ2sD6dVHgtPcUJAXrf.Dialog().ok(tEemMWQ0IlTrJXhdSgvB6,text)
def CqkHjm3whQZiF9bEXGDep4cRrW0(tEemMWQ0IlTrJXhdSgvB6=NdJhSgG3QAuOV8tx4aMkl(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),sCqMcPZUD7NwJTtFILR=oceVwPi0xy):
	fqNJt3UcMum = IEuQ2sD6dVHgtPcUJAXrf.Dialog().input(tEemMWQ0IlTrJXhdSgvB6,sCqMcPZUD7NwJTtFILR,type=IEuQ2sD6dVHgtPcUJAXrf.INPUT_ALPHANUM)
	fqNJt3UcMum = fqNJt3UcMum.strip(c86BurSztN(u"ࠪࠤࠬࠍ")).replace(M6NQ7Ydty9mxHoAlURVK2JsOqTzac(u"ࠫࠥࠦࠠࠡࠩࠎ"),TGu28FWmDN(u"ࠬࠦࠧࠏ")).replace(da2FeZI5wgM1sQNkrKpf0EAB(u"࠭ࠠࠡࠢࠪࠐ"),nnOcL691Yk5P2Ti(u"ࠧࠡࠩࠑ")).replace(nnOcL691Yk5P2Ti(u"ࠨࠢࠣࠫࠒ"),M6NQ7Ydty9mxHoAlURVK2JsOqTzac(u"ࠩࠣࠫࠓ"))
	return fqNJt3UcMum
def islb3czQTXjJqOA7hwuYHnWygo58Bp(mw9NZPREuOdkFLY):
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,splMDxz8bJeT4(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if eCNxBHQz0r4K2vAjmF8go!=SjVEuMAYapCKh(u"࠱ࢫ"): return
	if not xOVXGiyZl83Iw4qWnSRCBg1kK.path.exists(mw9NZPREuOdkFLY):
		jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oA8jxeUYWJNRSwXBmKirP(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = CqkHjm3whQZiF9bEXGDep4cRrW0(FUnxhBINQCER4dr29lL13uf(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	s2QMWbgpoLhr8 = VgMbSZwhKPufzJAi6X2q.getInfoLabel(NdJhSgG3QAuOV8tx4aMkl(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+mk7Ey1CHidTfXcx3Mro(u"ࠧࠪࠩ࠘"))
	file = open(mw9NZPREuOdkFLY,hDaezT4QC5H1Zut(u"ࠨࡴࡥࠫ࠙"))
	uTJGwDkOaUMgIe = xOVXGiyZl83Iw4qWnSRCBg1kK.path.getsize(mw9NZPREuOdkFLY)
	if uTJGwDkOaUMgIe>aeWVqAL0jKGUwtPr(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-aeWVqAL0jKGUwtPr(u"࠴࠲࠴࠴࠵࠶ࢬ"),xOVXGiyZl83Iw4qWnSRCBg1kK.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(ecVEQBZF9RPS0s3igx(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	H6R4FIu7WcCVUtEP5gJQzSM81so = llSvm80ILwRWQHE9G3ndsMbaeZ6px.findall(HHoYXqfmygc6tbakNlTdAsj3e(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,llSvm80ILwRWQHE9G3ndsMbaeZ6px.DOTALL)
	if not H6R4FIu7WcCVUtEP5gJQzSM81so: H6R4FIu7WcCVUtEP5gJQzSM81so = llSvm80ILwRWQHE9G3ndsMbaeZ6px.findall(splMDxz8bJeT4(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,llSvm80ILwRWQHE9G3ndsMbaeZ6px.DOTALL)
	if not H6R4FIu7WcCVUtEP5gJQzSM81so: H6R4FIu7WcCVUtEP5gJQzSM81so = llSvm80ILwRWQHE9G3ndsMbaeZ6px.findall(da2FeZI5wgM1sQNkrKpf0EAB(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,llSvm80ILwRWQHE9G3ndsMbaeZ6px.DOTALL)
	H6R4FIu7WcCVUtEP5gJQzSM81so = H6R4FIu7WcCVUtEP5gJQzSM81so[da2FeZI5wgM1sQNkrKpf0EAB(u"࠲ࢭ")] if H6R4FIu7WcCVUtEP5gJQzSM81so else c86BurSztN(u"࠭࠰࠱࠲࠳ࠫࠞ")
	H6R4FIu7WcCVUtEP5gJQzSM81so = H6R4FIu7WcCVUtEP5gJQzSM81so.split(aeWVqAL0jKGUwtPr(u"ࠧ࡝ࡰࠪࠟ"),Bp3MrQkwG875f1IvuPNgZVjY(u"࠴ࢮ"))[nnOcL691Yk5P2Ti(u"࠴ࢯ")]
	if S5YX1iKkvz: H6R4FIu7WcCVUtEP5gJQzSM81so = H6R4FIu7WcCVUtEP5gJQzSM81so.encode(PyGknJqXUOEHN(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	gasWbDXvLJ2iHoKkNVRwpn = nNYxkBQ3FzHAsy(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+H6R4FIu7WcCVUtEP5gJQzSM81so+PyGknJqXUOEHN(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += dQi1fumWEJcYlXN8e6wThgzn(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+H6R4FIu7WcCVUtEP5gJQzSM81so+nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࠬࠦ࠺ࠨࠤ")+zeBA41YmvyM(u"࠭࡜࡯ࠩࠥ")+c86BurSztN(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+s2QMWbgpoLhr8+dQi1fumWEJcYlXN8e6wThgzn(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(FUnxhBINQCER4dr29lL13uf(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	DDHzq8c1FZ9uEhI = RqI974yXLnc8FKOa165om.b64encode(data)
	tl93oeLbHFUadqyck6SwZBMD = {nNYxkBQ3FzHAsy(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):gasWbDXvLJ2iHoKkNVRwpn,VwkK0Sfaj1R7(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,M6NQ7Ydty9mxHoAlURVK2JsOqTzac(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):DDHzq8c1FZ9uEhI}
	U9enE16HBPcKZqpwQ7 = splMDxz8bJeT4(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	frl39CUyiQZevqOV = qDZ1o6NpJMhgIRAHixbrY84OwTvneQ.request(SjVEuMAYapCKh(u"ࠧࡑࡑࡖࡘࠬ࠭"),U9enE16HBPcKZqpwQ7,data=tl93oeLbHFUadqyck6SwZBMD)
	if frl39CUyiQZevqOV.status_code==dQi1fumWEJcYlXN8e6wThgzn(u"࠷࠶࠰ࢰ"): jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,cjap9k4NZFsBIhJ6Qvud(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,ecVEQBZF9RPS0s3igx(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def NyTYCx4LG6kvB1d7IR():
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,RRk5ISDpdvhugZOL2yzQqCa6s(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if eCNxBHQz0r4K2vAjmF8go!=nnOcL691Yk5P2Ti(u"࠷ࢱ"): return
	nfETR7praDUGO40dqISyYmkN2ogJ = pWhmViw0tR8TxMZDKj9Jec2luLSC(vhk1iIQBfsHwyMCAx7U8V,SjVEuMAYapCKh(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,GGfpgnj7VswDmX6xPIqUlht(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,ecVEQBZF9RPS0s3igx(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def EIrVheUR5uaTwXDOCgbJcFi40W9d():
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,iBERSucw418DTot6P9bWkKmsCdnGNz(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if eCNxBHQz0r4K2vAjmF8go!=nnOcL691Yk5P2Ti(u"࠱ࢲ"): return
	nfETR7praDUGO40dqISyYmkN2ogJ = kfUu4cJmE72R9g(cTJPIbMnUaDxyOgihfVG1m580L9,c86BurSztN(u"ࡕࡴࡸࡩࣈ"),c86BurSztN(u"ࡕࡴࡸࡩࣈ"),PyGknJqXUOEHN(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,dQi1fumWEJcYlXN8e6wThgzn(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,zeBA41YmvyM(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def pWhmViw0tR8TxMZDKj9Jec2luLSC(etgON5xJasSG8IzM32X,rFXz08YKG6T7kfBZdvaiSL3):
	nfETR7praDUGO40dqISyYmkN2ogJ = aeWVqAL0jKGUwtPr(u"ࡖࡵࡹࡪࣉ")
	if rFXz08YKG6T7kfBZdvaiSL3:
		eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,nZCBzxNycI9qt4RwDXl8LUmro7YW(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if eCNxBHQz0r4K2vAjmF8go!=nNYxkBQ3FzHAsy(u"࠲ࢳ"): return
	if xOVXGiyZl83Iw4qWnSRCBg1kK.path.exists(etgON5xJasSG8IzM32X):
		try: xOVXGiyZl83Iw4qWnSRCBg1kK.remove(etgON5xJasSG8IzM32X)
		except Exception as nt3hR8YlCmujeW15vQIafN2zgOHV0:
			nfETR7praDUGO40dqISyYmkN2ogJ = gnV6yqprD9vxOAL0SEtRMsJ1(u"ࡉࡥࡱࡹࡥ࣊")
			if rFXz08YKG6T7kfBZdvaiSL3: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,str(nt3hR8YlCmujeW15vQIafN2zgOHV0))
	if rFXz08YKG6T7kfBZdvaiSL3:
		if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,c86BurSztN(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,PyGknJqXUOEHN(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return nfETR7praDUGO40dqISyYmkN2ogJ
def kfUu4cJmE72R9g(moMAOEdfwJvSans50,bFKTzdxUp6q3hrBcIZN1CPlQeH4g,aAqfDouMQ4tgLsmS5N1h0ZETXCnBx,rFXz08YKG6T7kfBZdvaiSL3):
	nfETR7praDUGO40dqISyYmkN2ogJ = TGu28FWmDN(u"ࡘࡷࡻࡥ࣋")
	if rFXz08YKG6T7kfBZdvaiSL3:
		eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,moMAOEdfwJvSans50+ecVEQBZF9RPS0s3igx(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if eCNxBHQz0r4K2vAjmF8go!=HHoYXqfmygc6tbakNlTdAsj3e(u"࠳ࢴ"): return
	if xOVXGiyZl83Iw4qWnSRCBg1kK.path.exists(moMAOEdfwJvSans50):
		for FSfIZ4pXWH6TVk,IIAFPNlJnVqT3j7,cIvyMW4oeUS92jz in xOVXGiyZl83Iw4qWnSRCBg1kK.walk(moMAOEdfwJvSans50,topdown=Z96DFLfxObsyIpCEjWaY85gr0eH(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for AEgWzrO2IlKD6QeP9m in cIvyMW4oeUS92jz:
				c23QKzvL7VH9APyfoDSeEa0dhg = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(FSfIZ4pXWH6TVk,AEgWzrO2IlKD6QeP9m)
				try: xOVXGiyZl83Iw4qWnSRCBg1kK.remove(c23QKzvL7VH9APyfoDSeEa0dhg)
				except Exception as nt3hR8YlCmujeW15vQIafN2zgOHV0:
					nfETR7praDUGO40dqISyYmkN2ogJ = da2FeZI5wgM1sQNkrKpf0EAB(u"ࡌࡡ࡭ࡵࡨ࣍")
					if rFXz08YKG6T7kfBZdvaiSL3: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,str(nt3hR8YlCmujeW15vQIafN2zgOHV0))
			if bFKTzdxUp6q3hrBcIZN1CPlQeH4g:
				for nGAsQDSxIUm8w3e9YjZaHv2 in IIAFPNlJnVqT3j7:
					dJw9osNR3M8fBlm0QALO2Ip4TX = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(FSfIZ4pXWH6TVk,nGAsQDSxIUm8w3e9YjZaHv2)
					try: xOVXGiyZl83Iw4qWnSRCBg1kK.rmdir(dJw9osNR3M8fBlm0QALO2Ip4TX)
					except: pass
		if aAqfDouMQ4tgLsmS5N1h0ZETXCnBx:
			try: xOVXGiyZl83Iw4qWnSRCBg1kK.rmdir(FSfIZ4pXWH6TVk)
			except: pass
	if rFXz08YKG6T7kfBZdvaiSL3:
		if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,splMDxz8bJeT4(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,Z96DFLfxObsyIpCEjWaY85gr0eH(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return nfETR7praDUGO40dqISyYmkN2ogJ
def FnhOWsNIZcf():
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if eCNxBHQz0r4K2vAjmF8go!=oA8jxeUYWJNRSwXBmKirP(u"࠴ࢵ"): return
	nfETR7praDUGO40dqISyYmkN2ogJ = kfUu4cJmE72R9g(EVUvoQxGD134eLTf7KwnH2pzsjMYm,nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࡕࡴࡸࡩ࣏"),PyGknJqXUOEHN(u"ࡆࡢ࡮ࡶࡩ࣎"),nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࡕࡴࡸࡩ࣏"))
	if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,aeWVqAL0jKGUwtPr(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,VwkK0Sfaj1R7(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def jwfCavgcRBSLsebqtMPZri9V7():
	U9enE16HBPcKZqpwQ7 = dQi1fumWEJcYlXN8e6wThgzn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	frl39CUyiQZevqOV = qDZ1o6NpJMhgIRAHixbrY84OwTvneQ.request(VwkK0Sfaj1R7(u"ࠬࡍࡅࡕࠩࡀ"),U9enE16HBPcKZqpwQ7)
	ttcBmiFhJHDdXEr8wVj72uL = frl39CUyiQZevqOV.content
	ttcBmiFhJHDdXEr8wVj72uL = ttcBmiFhJHDdXEr8wVj72uL.decode(TGu28FWmDN(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	cIvyMW4oeUS92jz = llSvm80ILwRWQHE9G3ndsMbaeZ6px.findall(ecVEQBZF9RPS0s3igx(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),ttcBmiFhJHDdXEr8wVj72uL,llSvm80ILwRWQHE9G3ndsMbaeZ6px.DOTALL)
	cIvyMW4oeUS92jz = sorted(cIvyMW4oeUS92jz,reverse=cjap9k4NZFsBIhJ6Qvud(u"ࡖࡵࡹࡪ࣐"))
	WrpYgMbfCi7BsVvoUXQ8S30hOAn4 = IEuQ2sD6dVHgtPcUJAXrf.Dialog().select(awnIWZxjlPDL3ON(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),cIvyMW4oeUS92jz)
	if WrpYgMbfCi7BsVvoUXQ8S30hOAn4==-Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"࠵ࢶ"): return
	filename = cIvyMW4oeUS92jz[WrpYgMbfCi7BsVvoUXQ8S30hOAn4]
	if S5YX1iKkvz: filename = filename.encode(zeBA41YmvyM(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	S4DhHGl3FvCNYjIEo7X9AeVWnMJZ = U9enE16HBPcKZqpwQ7.rsplit(NdJhSgG3QAuOV8tx4aMkl(u"ࠪ࠳ࠬࡅ"),SjVEuMAYapCKh(u"࠶ࢷ"))[TGu28FWmDN(u"࠶ࢸ")]+PyGknJqXUOEHN(u"ࠫ࠴࠭ࡆ")+c86BurSztN(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+Wi53RMs0N7ICt8Q(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	nfETR7praDUGO40dqISyYmkN2ogJ = VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࡉࡥࡱࡹࡥ࣑")
	frl39CUyiQZevqOV = qDZ1o6NpJMhgIRAHixbrY84OwTvneQ.request(RRk5ISDpdvhugZOL2yzQqCa6s(u"ࠧࡈࡇࡗࠫࡉ"),S4DhHGl3FvCNYjIEo7X9AeVWnMJZ)
	if frl39CUyiQZevqOV.status_code==X5quC7wg1l63tZcGp94BiQnJe0xHr(u"࠲࠱࠲ࢹ"):
		LntCiSOkMrVfuDeFWv = frl39CUyiQZevqOV.content
		import zipfile as PKEC1OHmYDaz,io as hJOSnoZgxPX5GQejiz0mAkq
		YUXpE19RQO0zoSvnsuljBh2 = hJOSnoZgxPX5GQejiz0mAkq.BytesIO(LntCiSOkMrVfuDeFWv)
		kfUu4cJmE72R9g(IgMTfBNn7sJjp1vG5c6kA8deCrFt,Bp3MrQkwG875f1IvuPNgZVjY(u"࡙ࡸࡵࡦ࣓"),Bp3MrQkwG875f1IvuPNgZVjY(u"࡙ࡸࡵࡦ࣓"),awnIWZxjlPDL3ON(u"ࡊࡦࡲࡳࡦ࣒"))
		XFgG4dsvPeQbDhwA9qMIWZuTip507H = PKEC1OHmYDaz.ZipFile(YUXpE19RQO0zoSvnsuljBh2)
		XFgG4dsvPeQbDhwA9qMIWZuTip507H.extractall(dyP4el9rviBSkJs53uLz68CbY)
		cF6WjpkQVt8HuLCwGzmESUTa3.sleep(awnIWZxjlPDL3ON(u"࠲ࢺ"))
		VgMbSZwhKPufzJAi6X2q.executebuiltin(X5quC7wg1l63tZcGp94BiQnJe0xHr(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		cF6WjpkQVt8HuLCwGzmESUTa3.sleep(da2FeZI5wgM1sQNkrKpf0EAB(u"࠳ࢻ"))
		bY52qG0HDfexgCzOJhI = VgMbSZwhKPufzJAi6X2q.executeJSONRPC(Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+oA8jxeUYWJNRSwXBmKirP(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࠫࡔࡑࠧࡍ") in bY52qG0HDfexgCzOJhI: nfETR7praDUGO40dqISyYmkN2ogJ = zeBA41YmvyM(u"࡚ࡲࡶࡧࣔ")
	if nfETR7praDUGO40dqISyYmkN2ogJ:
		jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,Wi53RMs0N7ICt8Q(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = Bp3MrQkwG875f1IvuPNgZVjY(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		lBRK7zIh2ePYi8b(msg)
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,gnV6yqprD9vxOAL0SEtRMsJ1(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def lBRK7zIh2ePYi8b(msg=nNYxkBQ3FzHAsy(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,VwkK0Sfaj1R7(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),Wi53RMs0N7ICt8Q(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),oceVwPi0xy,msg)
	if eCNxBHQz0r4K2vAjmF8go==-Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"࠴ࢼ"): return
	RaMTrikUqLO87fdxNlge = nNYxkBQ3FzHAsy(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if eCNxBHQz0r4K2vAjmF8go else RRk5ISDpdvhugZOL2yzQqCa6s(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	nfETR7praDUGO40dqISyYmkN2ogJ = M6NQ7Ydty9mxHoAlURVK2JsOqTzac(u"ࡆࡢ࡮ࡶࡩࣕ")
	BBPZ9mfowbyTF = hDaezT4QC5H1Zut(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	cc1HCq5spZPgldktIuEhTj9wm = splMDxz8bJeT4(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if S5YX1iKkvz else nnOcL691Yk5P2Ti(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as wwgEQJb4yGauNprdA3f
		PPDpibCFkuw0or381sY = wwgEQJb4yGauNprdA3f.connect(W0VRuTz1qCbNmYrvZQcL5)
		PPDpibCFkuw0or381sY.text_factory = str
		qAektSxCobaFTvNLy = PPDpibCFkuw0or381sY.cursor()
		qAektSxCobaFTvNLy.execute(oA8jxeUYWJNRSwXBmKirP(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+cjap9k4NZFsBIhJ6Qvud(u"ࠪࠦࠥࡁ࡚ࠧ"))
		AA9x3mPOBl = qAektSxCobaFTvNLy.fetchall()
		if AA9x3mPOBl and BBPZ9mfowbyTF not in str(AA9x3mPOBl): qAektSxCobaFTvNLy.execute(hDaezT4QC5H1Zut(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+BBPZ9mfowbyTF+RRk5ISDpdvhugZOL2yzQqCa6s(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+c86BurSztN(u"࠭ࠢࠡ࠽ࠪ࡝"))
		qAektSxCobaFTvNLy.execute(aeWVqAL0jKGUwtPr(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+cc1HCq5spZPgldktIuEhTj9wm+c86BurSztN(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+hDaezT4QC5H1Zut(u"ࠩࠥࠤࡀ࠭ࡠ"))
		AA9x3mPOBl = qAektSxCobaFTvNLy.fetchall()
		QUOwqlRSjirDFa0vWzcH5kEIMLJX9m = gnV6yqprD9vxOAL0SEtRMsJ1(u"ࡈࡤࡰࡸ࡫ࣗ") if AA9x3mPOBl else c86BurSztN(u"ࡕࡴࡸࡩࣖ")
		if not QUOwqlRSjirDFa0vWzcH5kEIMLJX9m and gnV6yqprD9vxOAL0SEtRMsJ1(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in RaMTrikUqLO87fdxNlge: qAektSxCobaFTvNLy.execute(TGu28FWmDN(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+cc1HCq5spZPgldktIuEhTj9wm+SjVEuMAYapCKh(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+oA8jxeUYWJNRSwXBmKirP(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif QUOwqlRSjirDFa0vWzcH5kEIMLJX9m and SjVEuMAYapCKh(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in RaMTrikUqLO87fdxNlge:
			if S5YX1iKkvz: qAektSxCobaFTvNLy.execute(nNYxkBQ3FzHAsy(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+cc1HCq5spZPgldktIuEhTj9wm+da2FeZI5wgM1sQNkrKpf0EAB(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+SjVEuMAYapCKh(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: qAektSxCobaFTvNLy.execute(mk7Ey1CHidTfXcx3Mro(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+cc1HCq5spZPgldktIuEhTj9wm+SjVEuMAYapCKh(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+Z075Z2IfQCNzmeDtKLOAbRTlVk8nu+oA8jxeUYWJNRSwXBmKirP(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		PPDpibCFkuw0or381sY.commit()
		PPDpibCFkuw0or381sY.close()
		nfETR7praDUGO40dqISyYmkN2ogJ = GGfpgnj7VswDmX6xPIqUlht(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if nfETR7praDUGO40dqISyYmkN2ogJ:
		cF6WjpkQVt8HuLCwGzmESUTa3.sleep(FUnxhBINQCER4dr29lL13uf(u"࠵ࢽ"))
		VgMbSZwhKPufzJAi6X2q.executebuiltin(GGfpgnj7VswDmX6xPIqUlht(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		cF6WjpkQVt8HuLCwGzmESUTa3.sleep(zeBA41YmvyM(u"࠶ࢾ"))
		jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,da2FeZI5wgM1sQNkrKpf0EAB(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,nNYxkBQ3FzHAsy(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def ntu8eExPWT3Z0imsgo9K5NY1I():
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if eCNxBHQz0r4K2vAjmF8go!=mk7Ey1CHidTfXcx3Mro(u"࠷ࢿ"): return
	VY7a2bj5x4IkSuNosq3 = kfUu4cJmE72R9g(FFShotrRPk6QBgOpMUYxEC7A,awnIWZxjlPDL3ON(u"࡙ࡸࡵࡦࣚ"),dQi1fumWEJcYlXN8e6wThgzn(u"ࡊࡦࡲࡳࡦࣙ"),dQi1fumWEJcYlXN8e6wThgzn(u"ࡊࡦࡲࡳࡦࣙ"))
	iTdBZlkVFyaqHEOG3NjefSA4hruWR = kfUu4cJmE72R9g(N1HSf78RD5O4hbke,nNYxkBQ3FzHAsy(u"ࡔࡳࡷࡨࣜ"),Wi53RMs0N7ICt8Q(u"ࡌࡡ࡭ࡵࡨࣛ"),Wi53RMs0N7ICt8Q(u"ࡌࡡ࡭ࡵࡨࣛ"))
	xZW5IsDRutaivBPJ9 = kfUu4cJmE72R9g(SB9hAT4L6IiQJdZV8qsFj50C3W,mk7Ey1CHidTfXcx3Mro(u"ࡖࡵࡹࡪࣞ"),nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࡇࡣ࡯ࡷࡪࣝ"),nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࡇࡣ࡯ࡷࡪࣝ"))
	GB9wWCfDadiy6s78mnzlpjLcP = zzARSbietdxjT91D(awnIWZxjlPDL3ON(u"ࡗࡶࡺ࡫ࣟ"))
	Azm2wSq87uNWv6BFydKg = QLOsBITcN5e()
	nfETR7praDUGO40dqISyYmkN2ogJ = all([VY7a2bj5x4IkSuNosq3,iTdBZlkVFyaqHEOG3NjefSA4hruWR,xZW5IsDRutaivBPJ9,GB9wWCfDadiy6s78mnzlpjLcP,Azm2wSq87uNWv6BFydKg])
	if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,c86BurSztN(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,FUnxhBINQCER4dr29lL13uf(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def Ivg4wMnO83eE0j1lXQbxDr9sKi():
	eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,TGu28FWmDN(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if eCNxBHQz0r4K2vAjmF8go!=X5quC7wg1l63tZcGp94BiQnJe0xHr(u"࠱ࣀ"): return
	jtWSqMAKsr4kgP1IZoQxTuO5GfCwXn = hDaezT4QC5H1Zut(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	j6AmcCyTOhlZ42L7tkEH = VwkK0Sfaj1R7(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	V0FWeO453GBTaLiMXqmpwbCDjt = oA8jxeUYWJNRSwXBmKirP(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	NT42GIXErchgBfQnbR = GGfpgnj7VswDmX6xPIqUlht(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	V2OR5WPz0yk9FaSX4fH6u7LMANJvcm = Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	lWL4j6QSyMcUokh8a0ueTC5bRm = NdJhSgG3QAuOV8tx4aMkl(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	VY7a2bj5x4IkSuNosq3 = kfUu4cJmE72R9g(jtWSqMAKsr4kgP1IZoQxTuO5GfCwXn,zeBA41YmvyM(u"࡙ࡸࡵࡦ࣡"),VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࡊࡦࡲࡳࡦ࣠"),VpXrJZvtxIMUG2PFzhYbnOQiL(u"ࡊࡦࡲࡳࡦ࣠"))
	iTdBZlkVFyaqHEOG3NjefSA4hruWR = kfUu4cJmE72R9g(j6AmcCyTOhlZ42L7tkEH,c86BurSztN(u"ࡔࡳࡷࡨࣣ"),hDaezT4QC5H1Zut(u"ࡌࡡ࡭ࡵࡨ࣢"),hDaezT4QC5H1Zut(u"ࡌࡡ࡭ࡵࡨ࣢"))
	xZW5IsDRutaivBPJ9 = kfUu4cJmE72R9g(V0FWeO453GBTaLiMXqmpwbCDjt,c86BurSztN(u"ࡖࡵࡹࡪࣥ"),cjap9k4NZFsBIhJ6Qvud(u"ࡇࡣ࡯ࡷࡪࣤ"),cjap9k4NZFsBIhJ6Qvud(u"ࡇࡣ࡯ࡷࡪࣤ"))
	GB9wWCfDadiy6s78mnzlpjLcP = kfUu4cJmE72R9g(NT42GIXErchgBfQnbR,c86BurSztN(u"ࡘࡷࡻࡥࣧ"),GGfpgnj7VswDmX6xPIqUlht(u"ࡉࡥࡱࡹࡥࣦ"),GGfpgnj7VswDmX6xPIqUlht(u"ࡉࡥࡱࡹࡥࣦ"))
	Azm2wSq87uNWv6BFydKg = kfUu4cJmE72R9g(V2OR5WPz0yk9FaSX4fH6u7LMANJvcm,RRk5ISDpdvhugZOL2yzQqCa6s(u"࡚ࡲࡶࡧࣩ"),NdJhSgG3QAuOV8tx4aMkl(u"ࡋࡧ࡬ࡴࡧࣨ"),NdJhSgG3QAuOV8tx4aMkl(u"ࡋࡧ࡬ࡴࡧࣨ"))
	P5z9c8RG6dFyxKSmtfagoN = kfUu4cJmE72R9g(lWL4j6QSyMcUokh8a0ueTC5bRm,oA8jxeUYWJNRSwXBmKirP(u"ࡕࡴࡸࡩ࣫"),cjap9k4NZFsBIhJ6Qvud(u"ࡆࡢ࡮ࡶࡩ࣪"),cjap9k4NZFsBIhJ6Qvud(u"ࡆࡢ࡮ࡶࡩ࣪"))
	nfETR7praDUGO40dqISyYmkN2ogJ = all([VY7a2bj5x4IkSuNosq3,iTdBZlkVFyaqHEOG3NjefSA4hruWR,xZW5IsDRutaivBPJ9,GB9wWCfDadiy6s78mnzlpjLcP,Azm2wSq87uNWv6BFydKg,P5z9c8RG6dFyxKSmtfagoN])
	if nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,da2FeZI5wgM1sQNkrKpf0EAB(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,NdJhSgG3QAuOV8tx4aMkl(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def zzARSbietdxjT91D(rFXz08YKG6T7kfBZdvaiSL3):
	nfETR7praDUGO40dqISyYmkN2ogJ = Wi53RMs0N7ICt8Q(u"ࡖࡵࡹࡪ࣬")
	if rFXz08YKG6T7kfBZdvaiSL3:
		eCNxBHQz0r4K2vAjmF8go = Ewi5PYoDKrshtF3pHjI1gUuGc(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,dQi1fumWEJcYlXN8e6wThgzn(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if eCNxBHQz0r4K2vAjmF8go!=PyGknJqXUOEHN(u"࠲ࣁ"): return
	try:
		import sqlite3 as wwgEQJb4yGauNprdA3f
		i1XdnpD9GCH05w3 = wwgEQJb4yGauNprdA3f.connect(DolwIiW0CneMQXuGpK9kjUq)
		i1XdnpD9GCH05w3.text_factory = str
		qAektSxCobaFTvNLy = i1XdnpD9GCH05w3.cursor()
		qAektSxCobaFTvNLy.execute(ecVEQBZF9RPS0s3igx(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		qAektSxCobaFTvNLy.execute(gnV6yqprD9vxOAL0SEtRMsJ1(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		qAektSxCobaFTvNLy.execute(dQi1fumWEJcYlXN8e6wThgzn(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		i1XdnpD9GCH05w3.commit()
		qAektSxCobaFTvNLy.execute(oA8jxeUYWJNRSwXBmKirP(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		i1XdnpD9GCH05w3.close()
	except: nfETR7praDUGO40dqISyYmkN2ogJ = GGfpgnj7VswDmX6xPIqUlht(u"ࡉࡥࡱࡹࡥ࣭")
	if rFXz08YKG6T7kfBZdvaiSL3 and nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,X5quC7wg1l63tZcGp94BiQnJe0xHr(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return nfETR7praDUGO40dqISyYmkN2ogJ
def QLOsBITcN5e():
	nfETR7praDUGO40dqISyYmkN2ogJ = Bp3MrQkwG875f1IvuPNgZVjY(u"ࡘࡷࡻࡥ࣮")
	for file in xOVXGiyZl83Iw4qWnSRCBg1kK.listdir(BTWpMXLsh9PY):
		if aeWVqAL0jKGUwtPr(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or HHoYXqfmygc6tbakNlTdAsj3e(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		c23QKzvL7VH9APyfoDSeEa0dhg = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(BTWpMXLsh9PY,file)
		try:
			xOVXGiyZl83Iw4qWnSRCBg1kK.remove(c23QKzvL7VH9APyfoDSeEa0dhg)
		except Exception as nt3hR8YlCmujeW15vQIafN2zgOHV0:
			nfETR7praDUGO40dqISyYmkN2ogJ = mk7Ey1CHidTfXcx3Mro(u"ࡋࡧ࡬ࡴࡧ࣯")
			if rFXz08YKG6T7kfBZdvaiSL3 and nfETR7praDUGO40dqISyYmkN2ogJ: jmaTzWRGoZqE(oceVwPi0xy,oceVwPi0xy,oceVwPi0xy,str(nt3hR8YlCmujeW15vQIafN2zgOHV0))
	return nfETR7praDUGO40dqISyYmkN2ogJ
GGxWKq7MCHhv4A8E(GGfpgnj7VswDmX6xPIqUlht(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
WGmxjHIKp4yJ5BYC7dF6 = shwSAqX5dk9N7Q1.argv[Z96DFLfxObsyIpCEjWaY85gr0eH(u"࠳ࣂ")]
Z075Z2IfQCNzmeDtKLOAbRTlVk8nu = aeWVqAL0jKGUwtPr(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
kfjhndxs36zUFgHJyl7bmEi2q = VgMbSZwhKPufzJAi6X2q.getInfoLabel(cjap9k4NZFsBIhJ6Qvud(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
tT4JWRcQ6LNq = llSvm80ILwRWQHE9G3ndsMbaeZ6px.findall(oA8jxeUYWJNRSwXBmKirP(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),kfjhndxs36zUFgHJyl7bmEi2q,llSvm80ILwRWQHE9G3ndsMbaeZ6px.DOTALL)
tT4JWRcQ6LNq = float(tT4JWRcQ6LNq[nnOcL691Yk5P2Ti(u"࠳ࣃ")])
S5YX1iKkvz = tT4JWRcQ6LNq<da2FeZI5wgM1sQNkrKpf0EAB(u"࠵࠾ࣄ")
iHxWaOzjeINKrEqsb65T3 = tT4JWRcQ6LNq>mk7Ey1CHidTfXcx3Mro(u"࠶࠾࠮࠺࠻ࣅ")
if iHxWaOzjeINKrEqsb65T3:
	BTWpMXLsh9PY = JmXZToc4z3tv.translatePath(VpXrJZvtxIMUG2PFzhYbnOQiL(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	CABEzyFTG4c5oLj = JmXZToc4z3tv.translatePath(X5quC7wg1l63tZcGp94BiQnJe0xHr(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	w40M8bVRyzDfB3ck6Hh5WNPtiaeqK2 = JmXZToc4z3tv.translatePath(nNYxkBQ3FzHAsy(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	W0VRuTz1qCbNmYrvZQcL5 = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,aeWVqAL0jKGUwtPr(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),ecVEQBZF9RPS0s3igx(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),Z96DFLfxObsyIpCEjWaY85gr0eH(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	BTWpMXLsh9PY = VgMbSZwhKPufzJAi6X2q.translatePath(hDaezT4QC5H1Zut(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	CABEzyFTG4c5oLj = VgMbSZwhKPufzJAi6X2q.translatePath(nZCBzxNycI9qt4RwDXl8LUmro7YW(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	w40M8bVRyzDfB3ck6Hh5WNPtiaeqK2 = VgMbSZwhKPufzJAi6X2q.translatePath(Bp3MrQkwG875f1IvuPNgZVjY(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	W0VRuTz1qCbNmYrvZQcL5 = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,VwkK0Sfaj1R7(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),SjVEuMAYapCKh(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),nNYxkBQ3FzHAsy(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
QN2iEBvToS8wG7zRFZs1KYcnaJf = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,GGfpgnj7VswDmX6xPIqUlht(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),PyGknJqXUOEHN(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),Z075Z2IfQCNzmeDtKLOAbRTlVk8nu)
vhk1iIQBfsHwyMCAx7U8V = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(QN2iEBvToS8wG7zRFZs1KYcnaJf,Bp3MrQkwG875f1IvuPNgZVjY(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
cTJPIbMnUaDxyOgihfVG1m580L9 = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(w40M8bVRyzDfB3ck6Hh5WNPtiaeqK2,Z075Z2IfQCNzmeDtKLOAbRTlVk8nu)
SB9hAT4L6IiQJdZV8qsFj50C3W = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),dQi1fumWEJcYlXN8e6wThgzn(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
dyP4el9rviBSkJs53uLz68CbY = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,PyGknJqXUOEHN(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
IgMTfBNn7sJjp1vG5c6kA8deCrFt = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(dyP4el9rviBSkJs53uLz68CbY,Z075Z2IfQCNzmeDtKLOAbRTlVk8nu)
FFShotrRPk6QBgOpMUYxEC7A = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(dyP4el9rviBSkJs53uLz68CbY,nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࠪࡸࡪࡳࡰࠨ࢙"))
N1HSf78RD5O4hbke = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(dyP4el9rviBSkJs53uLz68CbY,c86BurSztN(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
DolwIiW0CneMQXuGpK9kjUq = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(CABEzyFTG4c5oLj,GGfpgnj7VswDmX6xPIqUlht(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),Z96DFLfxObsyIpCEjWaY85gr0eH(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),hDaezT4QC5H1Zut(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
EVUvoQxGD134eLTf7KwnH2pzsjMYm = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(cTJPIbMnUaDxyOgihfVG1m580L9,Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
fWHymJk4h2PtbqDTdzgMN6Qn = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(BTWpMXLsh9PY,NdJhSgG3QAuOV8tx4aMkl(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
P9w7vLu84AeSbUXngsy = xOVXGiyZl83Iw4qWnSRCBg1kK.path.join(BTWpMXLsh9PY,TGu28FWmDN(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   WGmxjHIKp4yJ5BYC7dF6==nZCBzxNycI9qt4RwDXl8LUmro7YW(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: islb3czQTXjJqOA7hwuYHnWygo58Bp(fWHymJk4h2PtbqDTdzgMN6Qn)
elif WGmxjHIKp4yJ5BYC7dF6==X5quC7wg1l63tZcGp94BiQnJe0xHr(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: islb3czQTXjJqOA7hwuYHnWygo58Bp(P9w7vLu84AeSbUXngsy)
elif WGmxjHIKp4yJ5BYC7dF6==FUnxhBINQCER4dr29lL13uf(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: NyTYCx4LG6kvB1d7IR()
elif WGmxjHIKp4yJ5BYC7dF6==Caf4AoYwGdQHVuc7bFhDRjWs1zPByM(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: EIrVheUR5uaTwXDOCgbJcFi40W9d()
elif WGmxjHIKp4yJ5BYC7dF6==VwkK0Sfaj1R7(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: ntu8eExPWT3Z0imsgo9K5NY1I()
elif WGmxjHIKp4yJ5BYC7dF6==ecVEQBZF9RPS0s3igx(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: Ivg4wMnO83eE0j1lXQbxDr9sKi()
elif WGmxjHIKp4yJ5BYC7dF6==TGu28FWmDN(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: jwfCavgcRBSLsebqtMPZri9V7()
elif WGmxjHIKp4yJ5BYC7dF6==hDaezT4QC5H1Zut(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: lBRK7zIh2ePYi8b()
elif WGmxjHIKp4yJ5BYC7dF6==GGfpgnj7VswDmX6xPIqUlht(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: FnhOWsNIZcf()
GGxWKq7MCHhv4A8E(da2FeZI5wgM1sQNkrKpf0EAB(u"࠭ࡳࡵࡱࡳࠫࢪ"))